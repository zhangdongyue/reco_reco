#include <vector>
#include <string>
#include <fstream>
#include <set>
#include "boost/concept_check.hpp"

#include "base/testing/gtest.h"
#include "base/common/scoped_ptr.h"
#include "reco/bizc/meta_info/light_meta_info_updator.h"

#include "base/file/file_util.h"
#include "base/encoding/line_escape.h"

DECLARE_string(meta_kafka_topic);
DECLARE_string(meta_kafka_group_id);
DECLARE_int32(meta_kafka_partition);
DECLARE_int32(meta_kafka_data_version);
DECLARE_string(meta_kafka_brokers);
namespace reco {
class MetaInfoUpdatorTest: public testing::Test {
 public:
  virtual void SetUp() {
    FLAGS_meta_kafka_topic = "meta_update_info";
    FLAGS_meta_kafka_group_id = "video_server_em21";
    FLAGS_meta_kafka_partition = 32;
    FLAGS_meta_kafka_data_version = 1;
    FLAGS_meta_kafka_brokers = "11.251.176.1:9092,11.251.176.21:9092,11.251.176.2:9092,11.251.176.3:9092,11.251.176.49:9092,11.251.176.51:9092,11.251.176.54:9092,11.251.176.5:9092,11.251.176.8:9092,11.251.176.9:9092";  // NOLINT
  }

  virtual void TearDown() {
  }
};

TEST_F(MetaInfoUpdatorTest, LoadFromFile) {
  reco::LightMetaInfoUpdator* meta_info_updator = new reco::LightMetaInfoUpdator();
  struct {
    uint64 item_id;
    uint64 show_cnt;
    uint64 click_cnt;
  } cases[] = {
    {11347024340124172028lu, 835, 165},
  };
  int n = ARRAYSIZE_UNSAFE(cases);
  reco::MetaInfo meta_info;
  for (int i = 0; i < n; ++i) {
    meta_info_updator->GetMetaInfo(cases[i].item_id, &meta_info);
    ASSERT_EQ(cases[i].show_cnt, meta_info.show_count);
    ASSERT_EQ(cases[i].click_cnt, meta_info.click_count);
  }
}
}
