#pragma once

#include "reco/base/common/atomic.h"
#include <utility>
#include <vector>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>

#include "base/container/dense_hash_map.h"
#include "base/file/file_path.h"
#include "base/testing/gtest.h"
#include "base/thread/sync.h"
#include "base/thread/thread.h"
#include "base/thread/thread_pool.h"
#include "serving_base/expiry_map/expiry_map.h"

#include "reco/bizc/proto/meta_update.pb.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace kafka {
class Consumer;
}

struct MetaInfo {
  MetaInfo() {
    Clear();
  }

  void Clear() {
    hot_level  = 0;
    pr_level   = 0;
    item_quality = reco::kNormalItemq;
    spider_score = 0;
    site_level = reco::kMidQualitySite;
    time_level = reco::kBadTimeliness;
    sensitive_type = reco::kNoSensitive;
    show_count = 0;
    click_count = 0;
    duration = 70;
    p_ctr = -1;
  }

  // 热门得分
  int hot_level;
  // PR 得分
  int pr_level;
  // 质量度
  int item_quality;
  // 爬虫抓取的数据计算的得分, 根据爬虫抓取的外站数据辅助排序
  float spider_score;
  // 站点等级
  reco::SiteLevel site_level;
  // 时效性等级
  reco::TimeLevel time_level;
  // 敏感类型
  reco::SensitiveType sensitive_type;
  // 展现数
  uint64 show_count;
  // 点击数
  uint64 click_count;
  // 平均阅读时长
  int duration;
  // 预估的 ctrq
  float p_ctr;

  int new_pr;

  int new_itemq;
};

// singleton usage
class LightMetaInfoUpdator {
 public:
  LightMetaInfoUpdator();
  virtual ~LightMetaInfoUpdator();

  bool GetMetaInfo(uint64 item_id, MetaInfo* meta_info) const;

  void Start(const base::FilePath& dir);

 protected:
  bool LoadMetaData();

 private:
  // update item meta from redis
  void UpdateMetaThread();

  void ParseMeta(const uint64 item_id,
                 const std::unordered_map<std::string, std::string>& field_values,
                 MetaInfo* meta);

  void BackupMsg(const reco::MetaUpdateInfo &meta_msg);

  void DumpBackupMeta();

  // update meta item thread
  thread::Thread update_meta_thread_;
  std::atomic_bool update_meta_thread_stop_;
  thread::Mutex update_meta_mutex_;

  // DynamicDict<std::unordered_map<uint64, MetaInfo>>  item_meta_info_;
  base::dense_hash_map<uint64, MetaInfo> *item_meta_info_;
  std::unordered_map<std::string, std::string> meta_data_dump_;

  reco::kafka::Consumer* meta_consumer_;
  // serving_base::ExpiryMap<uint64, bool> *missing_meta_items_;
  int64 meta_msg_start_sec_;

  mutable std::atomic<uint64> meta_req_cnt_;
  mutable std::atomic<uint64> meta_missing_cnt_;

  friend class LightMetaInfoUpdatorTest;
};

inline bool LightMetaInfoUpdator::GetMetaInfo(uint64 item_id, MetaInfo* meta_info) const {
  meta_req_cnt_++;
  auto it = item_meta_info_->find(item_id);
  if (it != item_meta_info_->end()) {
    *meta_info = it->second;
    return true;
  }
  meta_missing_cnt_++;
  return false;
}
}  // namespace reco
