#include "reco/bizc/meta_info/light_meta_info_updator.h"

#include <set>

#include "base/common/basic_types.h"
#include "base/file/memory_mapped_file.h"
#include "base/encoding/line_escape.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/file/file_stream.h"
#include "base/thread/thread.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "serving_base/utility/timer.h"
#include "serving_base/utility/time_helper.h"

#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/bizc/common/item_level_define.h"

// kafka
DEFINE_string(meta_kafka_topic, "meta_info_test", "");
DEFINE_string(meta_kafka_group_id, "meta_update_test", "");
DEFINE_int32(meta_kafka_partition, 10, "");
DEFINE_int32(meta_kafka_data_version, -1, "");
DEFINE_string(meta_kafka_brokers, "", "");

DEFINE_string(meta_data_root, "../data", "");
DEFINE_string(meta_dump_file, "meta_dump_file", "");

DEFINE_double_counter(meta, meta_lack_ratio, 0, "meta redis 查询错误的比例");
DEFINE_int64_counter(meta, meta_update_cnt, 0, "");

namespace reco {

LightMetaInfoUpdator::LightMetaInfoUpdator() {
  item_meta_info_ = new base::dense_hash_map<uint64, MetaInfo>();
  item_meta_info_->set_empty_key(0u);

  update_meta_thread_stop_ = false;
  meta_req_cnt_ = 1;
  meta_missing_cnt_ = 1;
  meta_msg_start_sec_ = 0;

  LoadMetaData();
  update_meta_thread_.Start(NewCallback(this, &LightMetaInfoUpdator::UpdateMetaThread));
  LOG(INFO) << "update meta thread started.";
}

LightMetaInfoUpdator::~LightMetaInfoUpdator() {
  update_meta_thread_stop_ = true;
  update_meta_thread_.Join();
}

void LightMetaInfoUpdator::ParseMeta(const uint64 item_id,
                                const std::unordered_map<std::string, std::string>& field_values,
                                MetaInfo* meta) {
  int value = 0;
  auto iter = field_values.find(reco::item_level::kTimeLevelField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->time_level = reco::TimeLevel(value);
    }
  }

  iter = field_values.find(reco::item_level::kSiteLevelField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->site_level = reco::SiteLevel(value);
    }
  }

  iter = field_values.find(reco::item_level::kHotLevelField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      value = std::min(reco::item_level::kManualHotScoreThres, value);
      meta->hot_level = value;
    }
  }

  iter = field_values.find(reco::item_level::kPRScoreField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->pr_level = value;
    }
  }

  iter = field_values.find(reco::item_level::kStatItemqField);
  if (iter != field_values.end()
      && base::StringToInt(iter->second, &value)
      && reco::kBadItemq <= value
      && value < reco::kBoundaryItemq) {
    meta->item_quality = value;
  } else {
    meta->item_quality = reco::kNormalItemq;
  }

  iter = field_values.find(reco::item_level::kSensitiveTypeField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->sensitive_type = reco::SensitiveType(value);
    }
  }

  // iter = field_values.find(reco::item_level::kShowCountField);
  iter = field_values.find(reco::item_level::kShowField);
  if (iter != field_values.end()) {
    if (!base::StringToUint64(iter->second, &meta->show_count)) {
      meta->show_count = 0;
    }
  }

  // iter = field_values.find(reco::item_level::kClickCountField);
  iter = field_values.find(reco::item_level::kClickField);
  if (iter != field_values.end()) {
    if (!base::StringToUint64(iter->second, &meta->click_count)) {
      meta->click_count = 0;
    }
  }

  iter = field_values.find(reco::item_level::kDurationField);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &meta->duration)) {
      meta->duration = 70;
    }
  }

  // iter = field_values.find(reco::item_level::kClickCountField);
  iter = field_values.find("new_pr");
  if (iter != field_values.end()) {
    int32 new_pr = 0;
    if (base::StringToInt(iter->second, &new_pr)) {
      meta->new_pr = new_pr;
    } else {
      meta->new_pr = 0;
    }
  }

  iter = field_values.find(reco::item_level::kSpiderScoreField);
  if (iter != field_values.end()) {
    double spider_score = 0;
    base::StringToDouble(iter->second, &spider_score);
    meta->spider_score = (float)spider_score;
  } else {
    int spider_comment = 0;
    iter = field_values.find(reco::item_level::kSpiderCommentCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_comment);
    }
    int spider_up = 0;
    iter = field_values.find(reco::item_level::kSpiderUpCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_up);
    }
    int spider_down = 0;
    iter = field_values.find(reco::item_level::kSpiderDownCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_down);
    }
    int spider_read_count = 0;
    iter = field_values.find(reco::item_level::kSpiderReadCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_read_count);
    }
    meta->spider_score = static_cast<float>(spider_comment) * 2 + static_cast<float>(spider_up) * 1.5
        + static_cast<float>(spider_down) * 0.5 + static_cast<float>(spider_read_count);
  }

  // add by wangye
  iter = field_values.find(reco::item_level::kCtrqField);
  if (iter != field_values.end()) {
    double p_ctr = 0.0;
    if (base::StringToDouble(iter->second, &p_ctr)) {
      meta->p_ctr = p_ctr;
    } else {
      meta->p_ctr = 0.0;
    }
  }
  iter = field_values.find("NewItemq");
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &meta->new_itemq)) {
      meta->new_itemq = -1;
    }
  }
}

bool LightMetaInfoUpdator::LoadMetaData() {
  const base::FilePath base_dir(FLAGS_meta_data_root);
  const base::FilePath meta_file_path = base_dir.Append(FLAGS_meta_dump_file);
  if (base::file_util::PathExists(meta_file_path)) {
    LOG(INFO) << "begin to load meta file:" << meta_file_path.value();
    std::vector<std::string> lines;
    base::file_util::ReadFileToLines(meta_file_path, &lines);
    if (lines.size() < 1e4) {
      LOG(FATAL) << "meta data too small:" << lines.size();
      return false;
    } else if (lines.size() < 1e5) {
      LOG(ERROR) << "meta data too small:" << lines.size();
    }

    const std::string start_time = lines[0];
    uint64 timestamp = 0;
    if (serving_base::TimeHelper::StringToTimestamp(lines[0], "%Y-%m-%d %H:%M:%S", &timestamp)) {
      meta_msg_start_sec_ = timestamp / 1e6;
    }

    std::unordered_map<std::string, std::string> field_values;
    std::vector<std::string> item_data;
    std::vector<std::string> meta_data;
    std::vector<std::string> key_val;
    MetaInfo meta;
    uint64 item_id = 0;
    for (auto i = 2u; i < lines.size(); ++i) {
      field_values.clear();
      item_data.clear();
      meta_data.clear();

      // item_id:k|v,k|v...
      base::SplitString(lines[i], ":", &item_data);
      if (item_data.size() < 2 || !base::StringToUint64(item_data[0], &item_id)) {
        LOG(ERROR) << "item id error:" << lines[i];
        continue;
      }

      meta_data_dump_[item_data[0]] = item_data[1];

      base::SplitString(item_data[1], ",", &meta_data);
      for (auto j = 0u; j < meta_data.size(); ++j) {
        key_val.clear();
        base::SplitString(meta_data[j], "|", &key_val);
        if (key_val.size() == 2) {
          field_values[key_val[0]] = key_val[1];
        }
      }

      meta.Clear();
      ParseMeta(item_id, field_values, &meta);
      (*item_meta_info_)[item_id] = meta;
    }
    LOG(INFO) << "end to load meta file:" << item_meta_info_->size();
  } else {
    LOG(FATAL) << "meta file not fount:" << meta_file_path.value();
    return false;
  }

  return true;
}

void LightMetaInfoUpdator::UpdateMetaThread() {
  LOG(INFO) << "meta update thread begins to run";

  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_meta_kafka_topic;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = FLAGS_meta_kafka_group_id;
  options.partition_num = FLAGS_meta_kafka_partition;
  options.start_timestamp = meta_msg_start_sec_ - 30 * 60;  // -60 min
  meta_consumer_ = new reco::kafka::Consumer(FLAGS_meta_kafka_brokers, options);
  CHECK_NOTNULL(meta_consumer_);

  LOG(INFO) << "msg begin stamp is:" << options.start_timestamp;

  reco::kafka::Message msg;
  reco::MetaUpdateInfo meta_msg;
  std::unordered_map<std::string, std::string> field_values;
  MetaInfo meta;
  uint64 update_cnt = 0;
  uint64 item_id = 0;
  int64 backup_stamp = base::GetTimestamp();

  while (!update_meta_thread_stop_) {
    msg.Clear();
    if (!meta_consumer_->Consume(&msg)) {
      base::SleepForSeconds(1);
      continue;
    }

    VLOG(2) << "meta, prt:" << msg.partition << ", off:" << msg.offset
            << ", key:" << msg.key << ", time:" << msg.timestamp_ms;

    meta_msg.Clear();
    if (!meta_msg.ParseFromString(msg.content)) {
      LOG(ERROR) << "parse msg error, key:" << msg.key;
      continue;
    }

    if (meta_msg.version() != FLAGS_meta_kafka_data_version) {
      LOG_EVERY_N(INFO, 10000) << "meta message version error:" << meta_msg.version();
      continue;
    }

    COUNTERS_meta__meta_update_cnt.Increase(1);
    item_id = 0;
    if (!base::StringToUint64(meta_msg.item_id(), &item_id)) {
      LOG(ERROR) << "item id error:" << meta_msg.item_id();
      continue;
    }

    field_values.clear();
    BackupMsg(meta_msg);

    if (meta_msg.fields_size() > 0) {
      for (auto i = 0; i < meta_msg.fields_size(); ++i) {
        field_values[meta_msg.fields(i).key()] = meta_msg.fields(i).val();
      }

      if (!field_values.empty()) {
        meta.Clear();
        ParseMeta(item_id, field_values, &meta);
        (*item_meta_info_)[item_id] = meta;
      }
    }

    if (++update_cnt % 2000 == 0) {
      COUNTERS_meta__meta_lack_ratio.Reset(meta_missing_cnt_ * 1.0 / meta_req_cnt_);
    }

    // min
    const int64 cur_stamp = base::GetTimestamp();

    if (cur_stamp - backup_stamp > 16 * 60 * 1e6) {
      backup_stamp = cur_stamp;
      DumpBackupMeta();
    }
  }

  LOG(INFO) << "meta update thread end running";
}

void LightMetaInfoUpdator::BackupMsg(const reco::MetaUpdateInfo &meta_msg) {
  if (meta_msg.fields_size() <= 0) {
    return;
  }

  std::string value;
  for (auto i = 0; i < meta_msg.fields_size(); ++i) {
    value += meta_msg.fields(i).key() + "|" + meta_msg.fields(i).val() + ",";
  }

  meta_data_dump_[meta_msg.item_id()] = value;

  return;
}

void LightMetaInfoUpdator::DumpBackupMeta() {
  LOG(INFO) << "begin to backup meta data";

  const base::FilePath base_dir(FLAGS_meta_data_root);
  const base::FilePath meta_file_path = base_dir.Append(FLAGS_meta_dump_file);
  const base::FilePath meta_file_path_new = base_dir.Append(FLAGS_meta_dump_file + ".new");

  base::FileStream fs;
  if (fs.Open(meta_file_path_new, base::PLATFORM_FILE_OPEN_ALWAYS | base::PLATFORM_FILE_WRITE) != base::OK) {
    LOG(ERROR) << "open file err:" << meta_file_path_new.value();
    return;
  }

  // date time
  std::string date;
  if (!serving_base::TimeHelper::TimestampToString(
          base::GetTimestamp(), serving_base::TimeHelper::kSecond, &date)) {
    LOG(ERROR) << "time to string err.";
    fs.Close();
    return;
  };

  int64 len = 0;
  date += "\n";
  len = fs.WriteUntilComplete(const_cast<char*>(date.data()), static_cast<int64>(date.size()));

  std::string line;
  for (auto it = meta_data_dump_.begin(); it != meta_data_dump_.end(); ++it) {
    line = it->first + ":" + it->second + "\n";
    len = fs.WriteUntilComplete(const_cast<char*>(line.data()), static_cast<int64>(line.size()));
  }

  fs.Close();

  if (base::file_util::Move(meta_file_path_new, meta_file_path)) {
    LOG(INFO) << "backup meta data succ:" << meta_data_dump_.size();
  } else {
    LOG(ERROR) << "backup meta data fail:" << meta_file_path_new.value();
  }

  return;
}
}  // namespace reco
