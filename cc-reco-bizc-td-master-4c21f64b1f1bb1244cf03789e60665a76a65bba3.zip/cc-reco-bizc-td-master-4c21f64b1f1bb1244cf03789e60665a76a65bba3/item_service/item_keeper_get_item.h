#pragma once

#include <string>
#include <vector>
#include "base/common/base.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/bizc/item_service/get_item.h"

namespace net {
namespace rpc {
class RpcGroup;
}
}

namespace reco {

// NOTE: not thread safe
class ItemKeeperGetItem : public BaseGetItem {
 public:
  // item_keeper_ips, multiple ip joined by ","
  // cache size: lru cache size, set to <=0 will not use cache
  ItemKeeperGetItem(const std::string& item_keeper_ips, int item_keeper_port);
  ItemKeeperGetItem(const std::string& item_keeper_ips, int item_keeper_port, int cache_size);
  virtual ~ItemKeeperGetItem();

 protected:
  virtual void GetRecoItemsImpl(const std::vector<uint64>& item_ids, std::vector<reco::RecoItem>* reco_items);

  void InitConnect(const std::string& item_keeper_ips, int item_keeper_port);

 private:
  static const int kRpcTimeout = 30000;
  net::rpc::RpcGroup* rpc_group_;
  reco::itemkeeper::ItemKeeper::Stub *rpc_stub_;
};
}  // namespace reco

