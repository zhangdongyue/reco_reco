#include "reco/bizc/item_service/hbase_pool_set_media_feedback.h"

#include "base/common/sleep.h"
#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/strings/string_number_conversions.h"

namespace reco {

HBasePoolSetMediaFeedback::HBasePoolSetMediaFeedback(const std::string& hbase_table_name) {
  table_name_ = hbase_table_name;
}

HBasePoolSetMediaFeedback::~HBasePoolSetMediaFeedback() {
}

bool HBasePoolSetMediaFeedback::SetMediaFeedback(const std::string& media_name,
                                                 const reco::MediaFeedback& value) {
  CHECK(value.IsInitialized());
  std::string str;
  CHECK(value.SerializeToString(&str));
  std::string row_key = media_name;
  int retry = 0;
  bool succ = false;
  while (retry++ < kRetryTimes) {
    reco::hbase::HBaseAutoCli cli(10);
    if (!cli.Get()) {
      continue;
    }
    if (cli.Get()->Insert(table_name_, row_key, "data", "media_feedback", str)) {
      succ = true;
      break;
    } else {
      LOG(ERROR) << "set media to hbase failed!";
      continue;
    }
  }
  return succ;
}

}  // namespace reco
