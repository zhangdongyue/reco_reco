#include "reco/bizc/item_service/hbase_pool_set_sim.h"

#include <string>
#include <vector>
#include "base/common/base.h"
#include "base/strings/string_printf.h"

namespace reco {

std::string HBasePoolSetSim::kColumn = "list_global";
std::string HBasePoolSetSim::kColumnOld = "list";
std::string HBasePoolSetSim::kFamily = "sim";

HBasePoolSetSim::HBasePoolSetSim(std::string table) {
  table_ = table;
}

HBasePoolSetSim::~HBasePoolSetSim() {
}

bool HBasePoolSetSim::SetSim(uint64 item_id, const std::vector<SimResult>& sim_result) {
  std::string row_key = base::StringPrintf("%lu", item_id);

  std::string value;
  for (size_t i = 0; i < sim_result.size(); ++i) {
    value.append(base::StringPrintf("%lu:%d:%f", sim_result[i].item_id, sim_result[i].level,
                                    sim_result[i].score));
    if (i != sim_result.size()) value.append(",");
  }

  int retry = 0;
  bool succ = false;
  while (retry++ < kRetryTimes) {
    reco::hbase::HBaseAutoCli cli(10);
    if (!cli.Get()) {
      continue;
    }
    if (cli.Get()->Insert(table_, row_key, kFamily, kColumn, value)) {
      succ = true;
      break;
    } else {
      LOG(ERROR) << "set sim result to hbase failed!";
      continue;
    }
  }

  // LOG(INFO) << base::StringPrintf("set key:%s, value=%s", row_key.c_str(), value.c_str());
  return succ;
}

bool HBasePoolSetSim::SetSim(uint64 item_id, const std::vector<uint64>& sim_result) {
  std::string row_key = base::StringPrintf("%lu", item_id);

  std::string value;
  for (size_t i = 0; i < sim_result.size(); ++i) {
    value.append(base::StringPrintf("%lu", sim_result[i]));
    if (i != sim_result.size() - 1) value.append(",");
  }

  int retry = 0;
  bool succ = false;
  while (retry++ < kRetryTimes) {
    reco::hbase::HBaseAutoCli cli(10);
    if (!cli.Get()) {
      continue;
    }
    if (cli.Get()->Insert(table_, row_key, kFamily, kColumnOld, value)) {
      succ = true;
      break;
    } else {
      LOG(ERROR) << "set sim result to hbase failed!";
      continue;
    }
  }

  // LOG(INFO) << base::StringPrintf("set key:%s, value=%s", row_key.c_str(), value.c_str());
  return succ;
}
}  // namespace reco
