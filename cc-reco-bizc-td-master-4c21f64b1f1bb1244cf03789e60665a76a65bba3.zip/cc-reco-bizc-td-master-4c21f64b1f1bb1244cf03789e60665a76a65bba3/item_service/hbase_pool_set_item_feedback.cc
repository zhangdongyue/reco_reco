#include "reco/bizc/item_service/hbase_pool_set_item_feedback.h"

#include "base/common/sleep.h"
#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/strings/string_number_conversions.h"

namespace reco {

HBasePoolSetItemFeedback::HBasePoolSetItemFeedback(const std::string& hbase_table_name) {
  table_name_ = hbase_table_name;
}

HBasePoolSetItemFeedback::~HBasePoolSetItemFeedback() {
}

bool HBasePoolSetItemFeedback::SetItemFeedback(uint64 item_id, const reco::ItemFeedback& value) {
  CHECK(value.IsInitialized());
  std::string str;
  CHECK(value.SerializeToString(&str));
  std::string row_key = base::Uint64ToString(item_id);
  int retry = 0;
  bool succ = false;
  while (retry++ < kRetryTimes) {
    reco::hbase::HBaseAutoCli cli(10);
    if (!cli.Get()) {
      continue;
    }
    if (cli.Get()->Insert(table_name_, row_key, "data", "item_feedback", str)) {
      succ = true;
      break;
    } else {
      LOG(ERROR) << "set item to hbase failed!";
      continue;
    }
  }
  return succ;
}
}  // namespace reco
