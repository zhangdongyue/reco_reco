#pragma once

#include <string>
#include <vector>
#include "base/common/base.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/get_item.h"

namespace reco {

// NOTE: not thread safe
class HBaseGetItem : public BaseGetItem {
 public:
  // cache size: lru cache size, set to <=0 will not use cache
  explicit HBaseGetItem(const std::string& hbase_table_name);
  HBaseGetItem(const std::string& hbase_table_name, int cache_size);
  virtual ~HBaseGetItem();

 protected:
  virtual void GetRecoItemsImpl(const std::vector<uint64>& item_ids, std::vector<reco::RecoItem>* reco_items);

 private:
  std::string table_name_;
};
}  // namespace reco
