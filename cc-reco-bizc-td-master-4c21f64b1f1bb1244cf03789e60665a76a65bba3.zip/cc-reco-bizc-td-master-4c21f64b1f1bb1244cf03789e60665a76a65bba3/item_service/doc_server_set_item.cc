#include <string>
#include <vector>
#include "reco/bizc/item_service/doc_server_set_item.h"
#include "base/container/lru_cache.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "net/rpc_util/rpc_group.h"

namespace reco {

DocServerSetItem::DocServerSetItem(const std::string& doc_server_ips, int doc_server_port) {
  std::vector<std::string> flds;
  base::SplitString(doc_server_ips, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    int timeout = 1000;
    net::rpc::RpcGroup::Options options;
    options.max_retry_times = 1;
    options.timeout = timeout;
    net::rpc::RpcGroup::ServerInfo si(flds[i], doc_server_port, timeout);
    options.servers.push_back(si);
    auto rpc_group = new net::rpc::RpcGroup(options);
    CHECK(rpc_group->Connect());
    auto rpc_stub = new reco::docserver::RecoDocService::Stub(rpc_group);
    rpc_stubs_.push_back(rpc_stub);
    rpc_groups_.push_back(rpc_group);
  }
}

DocServerSetItem::~DocServerSetItem() {
  for (size_t i = 0; i < rpc_stubs_.size(); ++i) {
    delete rpc_stubs_[i];
  }
  for (size_t i = 0; i < rpc_groups_.size(); ++i) {
    delete rpc_groups_[i];
  }
}

bool DocServerSetItem::SetRecoItem(const RecoItem& reco_item) {
  CHECK(reco_item.IsInitialized());

  reco::doc::UpdateDBRecoItemRequest request;
  request.add_item()->CopyFrom(reco_item);

  for (size_t i = 0; i < rpc_groups_.size(); ++i) {
    net::rpc::RpcClientController controller;
    reco::doc::UpdateDBRecoItemResponse response;
    rpc_stubs_[i]->UpdateDBRecoItem(&controller, &request, &response, NULL);
    controller.Wait();
    if (controller.status() != net::rpc::RpcController::kOk) {
      LOG(ERROR) << "get reco item failed: " << controller.error_text();
      return false;
    }
    if (!response.success(0)) {
      LOG(ERROR) << "update doc server item failed";
      return false;
    }
  }
  return true;
}

}  // namespace reco

