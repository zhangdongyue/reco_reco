#include "reco/bizc/item_service/hbase_get_media_feedback.h"

#include <map>
#include "reco/bizc/item_service/define.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/common/sleep.h"

namespace reco {

HBaseGetMediaFeedback::HBaseGetMediaFeedback(const std::string& hbase_table_name) {
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited()) << "init hbase pool first";
  table_name_ = hbase_table_name;
}

HBaseGetMediaFeedback::~HBaseGetMediaFeedback() {
}

bool HBaseGetMediaFeedback::GetMediaFeedback(const std::string& media_name, reco::MediaFeedback* result) {
  std::vector<std::string> media_names;
  media_names.push_back(media_name);

  std::vector<reco::MediaFeedback> results;
  std::vector<bool> rets;
  GetMediaFeedback(media_names, &rets, &results);

  if (rets[0]) {
    result->Swap(&(results[0]));
  }
  return rets[0];
}

void HBaseGetMediaFeedback::GetMediaFeedback(const std::vector<std::string>& media_names,
                                             std::vector<bool>* rets,
                                             std::vector<reco::MediaFeedback>* result) {
  rets->clear();
  rets->resize(media_names.size(), false);
  result->clear();
  result->resize(media_names.size());

  if (media_names.empty()) {
    return;
  }

  std::vector<std::string> result_str;
  GetRawResult(media_names, rets, &result_str);
  CHECK_EQ(rets->size(), result_str.size());
  CHECK_EQ(media_names.size(), result_str.size());
  result->resize(result_str.size());
  for (size_t i = 0; i < result_str.size(); ++i) {
    if (!rets->at(i)) continue;
    if (!result->at(i).ParseFromString(result_str[i])) {
      LOG(ERROR) << base::StringPrintf("false for parseing proto for media feedback: %s", media_names[i].c_str()); // NOLINT
      rets->at(i) = false;
    }
  }
}

void HBaseGetMediaFeedback::GetRawResult(const std::vector<std::string>& item_keys,
                                         std::vector<bool>* rets,
                                         std::vector<std::string>* result) {
  std::map<std::string, std::map<std::string, std::string> > row_map;
  int retry = 0;
  rets->clear();
  result->clear();
  rets->resize(item_keys.size(), false);
  result->resize(item_keys.size(), "");

  while (retry++ < 3) {
    reco::hbase::HBaseAutoCli cli = reco::hbase::HBaseAutoCli(10);
    reco::hbase::HBaseCli* client = cli.Get();
    if (client == NULL) {
      continue;
    }
    if (client->BatchGetByKeys(table_name_, item_keys, &row_map)) {
      break;
    } else {
      continue;
    }
  }

  if (retry >= 3) {
    std::string buf;
    base::FastJoinStrings(item_keys, ",", &buf);
    LOG(ERROR) << "batch get failed! and drop current task: " << buf;
    return;
  }

  for (size_t i = 0; i < item_keys.size(); ++i) {
    auto it = row_map.find(item_keys[i]);
    if (it == row_map.end()) continue;

    auto it2 = it->second.find("data:media_feedback");
    if (it2 == it->second.end()) {
      LOG(ERROR) << "canot find media feedback for row key: " << item_keys[i];
      continue;
    }
    rets->at(i) = true;
    result->at(i) = it2->second;
  }
}
}  // namespace reco
