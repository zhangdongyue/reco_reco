#include "reco/bizc/item_service/hbase_pool_set_item_attr.h"

#include <string>
#include "base/common/base.h"

namespace reco {

const std::string HBasePoolSetItemAttr::kTrue = "true";
const std::string HBasePoolSetItemAttr::kFalse = "false";
HBasePoolSetItemAttr::HBasePoolSetItemAttr(const std::string& hbase_table_name) {
  table_name_ = hbase_table_name;
  attr_num_ = ARRAYSIZE_UNSAFE(reco::item_attr::kAllSuffix);
}

HBasePoolSetItemAttr::~HBasePoolSetItemAttr() {
}
}  // namespace reco
