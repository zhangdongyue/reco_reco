#include "reco/bizc/item_service/hbase_set_item_attr.h"

#include <string>
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/strings/string_number_conversions.h"

namespace reco {

const std::string HBaseSetItemAttr::kTrue = "true";
const std::string HBaseSetItemAttr::kFalse = "false";
HBaseSetItemAttr::HBaseSetItemAttr(const std::string& hbase_table_name) {
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited()) << "init hbase pool first";

  table_name_ = hbase_table_name;
  attr_num_ = ARRAYSIZE_UNSAFE(reco::item_attr::kAllSuffix);
}

HBaseSetItemAttr::~HBaseSetItemAttr() {
}
}  // namespace reco
