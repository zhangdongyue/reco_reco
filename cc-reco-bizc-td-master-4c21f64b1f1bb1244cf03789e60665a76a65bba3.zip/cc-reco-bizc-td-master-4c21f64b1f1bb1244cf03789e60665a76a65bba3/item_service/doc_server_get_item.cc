#include <string>
#include <vector>
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "net/rpc_util/rpc_group.h"

namespace reco {
DocServerGetItem::DocServerGetItem(const std::string& doc_server_ips, int doc_server_port) {
  InitConnect(doc_server_ips, doc_server_port);
}

DocServerGetItem::DocServerGetItem(const std::string& doc_server_ips, int doc_server_port, int cache_size)
  : BaseGetItem(cache_size) {
  InitConnect(doc_server_ips, doc_server_port);
}

DocServerGetItem::~DocServerGetItem() {
  delete rpc_stub_;
  delete rpc_group_;
}

void DocServerGetItem::InitConnect(const std::string& doc_server_ips, int doc_server_port) {
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = kRpcTimeout;
  std::vector<std::string> flds;
  base::SplitString(doc_server_ips, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], doc_server_port, kRpcTimeout);
    options.servers.push_back(si);
  }

  rpc_group_ = new net::rpc::RpcGroup(options);
  CHECK(rpc_group_->Connect());
  rpc_stub_ = new reco::docserver::RecoDocService::Stub(rpc_group_);
}

void DocServerGetItem::GetRecoItemsImpl(const std::vector<uint64>& item_ids,
                                        std::vector<reco::RecoItem>* reco_items) {
  reco::doc::ItemDocRequest request;
  for (int i = 0; i < (int)item_ids.size(); ++i) {
    const uint64 id = item_ids[i];
    RecoItem item;
    if (!ReadCache(id, &item)) {
      request.add_item_id(id);
    } else {
      reco_items->push_back(item);
    }
  }

  if (request.item_id_size() == 0) {
    return;
  } else {
  }


  net::rpc::RpcClientController controller;
  controller.SetTimeout(kRpcTimeout);
  reco::doc::ItemDocResponse response;
  // rpc_stub_->GetRecoItemInfo(&controller, &request, &response, NULL);
  rpc_stub_->GetItemDocInfo(&controller, &request, &response, NULL);
  controller.Wait();
  if (controller.status() != net::rpc::RpcController::kOk) {
    LOG(ERROR) << "get reco item failed: " << controller.error_text();
    return;
  }

  for (int i = 0; i < response.reco_item_size(); ++i) {
    reco_items->push_back(response.reco_item(i));
    WriteCache(response.reco_item(i).identity().item_id(),
               response.reco_item(i));
  }
}
}  // namespace reco

