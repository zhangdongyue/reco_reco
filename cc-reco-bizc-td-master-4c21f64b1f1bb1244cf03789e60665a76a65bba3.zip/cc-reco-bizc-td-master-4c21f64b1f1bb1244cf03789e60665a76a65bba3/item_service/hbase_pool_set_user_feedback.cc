#include "reco/bizc/item_service/hbase_pool_set_user_feedback.h"

#include "base/common/sleep.h"
#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/strings/string_number_conversions.h"

namespace reco {

HBasePoolSetUserFeedback::HBasePoolSetUserFeedback(const std::string& hbase_table_name) {
  table_name_ = hbase_table_name;
}

HBasePoolSetUserFeedback::~HBasePoolSetUserFeedback() {
}

bool HBasePoolSetUserFeedback::SetUserFeedback(uint64 user_id, const reco::UserFeedback& value) {
  CHECK(value.IsInitialized());
  std::string str;
  CHECK(value.SerializeToString(&str));
  std::string row_key = base::Uint64ToString(user_id);
  int retry = 0;
  bool succ = false;
  while (retry++ < kRetryTimes) {
    reco::hbase::HBaseAutoCli cli(10);
    if (!cli.Get()) {
      continue;
    }
    if (cli.Get()->Insert(table_name_, row_key, "data", "user_feedback", str)) {
      succ = true;
      break;
    } else {
      LOG(ERROR) << "set user to hbase failed!";
      continue;
    }
  }
  return succ;
}

}  // namespace reco
