#pragma once

#include <string>
#include "base/common/base.h"
#include "base/testing/gtest_prod.h"
#include "reco/bizc/proto/feedback.pb.h"
#include "reco/bizc/item_service/define.h"

namespace reco {
// NOTE: thread safe
class HBasePoolSetItemFeedback {
 public:
  explicit HBasePoolSetItemFeedback(const std::string& hbase_table_name);
  ~HBasePoolSetItemFeedback();

  bool SetItemFeedback(uint64 item_id, const reco::ItemFeedback& value);

 private:
  static const int kRetryTimes = 3;
  static const int kReconnectTimes = 10;

  std::string table_name_;
};
}  // namespace reco

