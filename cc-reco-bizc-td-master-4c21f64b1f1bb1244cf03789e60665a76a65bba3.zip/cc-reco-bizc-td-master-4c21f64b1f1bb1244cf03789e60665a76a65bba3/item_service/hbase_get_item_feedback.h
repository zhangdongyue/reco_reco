#pragma once
#include <string>
#include <vector>
#include "base/common/base.h"
#include "reco/bizc/proto/feedback.pb.h"

namespace reco {
namespace hbase {
class HBaseCli;
}  // namespace hbase
// NOTE: not thread safe
class HBaseGetItemFeedback {
 public:
  // cache size: lru cache size, set to <=0 will not use cache
  explicit HBaseGetItemFeedback(const std::string& hbase_table_name);
  ~HBaseGetItemFeedback();

  bool GetItemFeedback(uint64 item_id, reco::ItemFeedback* result);

  void GetItemFeedback(const std::vector<uint64>& item_ids,
                       std::vector<bool>* rets, std::vector<reco::ItemFeedback>* result);

 private:
  void GetRawResult(const std::vector<std::string>& row_keys,
                    std::vector<bool>* rets,
                    std::vector<std::string>* result);

  std::string table_name_;
};
}  // namespace reco
