#include "reco/bizc/item_service/hbase_pool_get_sim.h"

#include <map>
#include <string>
#include <vector>
#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

namespace reco {

HBasePoolGetSim::HBasePoolGetSim(const std::string& hbase_table_name) {
  table_name_ = hbase_table_name;
  reco::hbase::HBasePoolIns::instance().Init();
}

HBasePoolGetSim::~HBasePoolGetSim() {
}

bool HBasePoolGetSim::GetSimItem(uint64 item_id, std::vector<uint64>* sims) {
  std::vector<uint64> item_ids;
  item_ids.push_back(item_id);

  std::vector<bool> rets;
  std::vector<std::vector<uint64>> sim_matrix;
  GetSimItems(item_ids, &rets, &sim_matrix);
  if (rets[0]) {
    sims->swap(sim_matrix[0]);
  }
  return rets[0];
}

void HBasePoolGetSim::GetSimItems(const std::vector<std::string>& item_str_ids, std::vector<bool>* rets,
                                std::vector<std::vector<uint64>>* sim_matrix) {
  std::vector<uint64> item_ids(item_str_ids.size(), 0);
  for (size_t i = 0; i < item_str_ids.size(); ++i) {
    uint64 id = 0;
    if (base::StringToUint64(item_str_ids[i], &id)) {
      item_ids[i] = id;
    }
  }
  GetSimItems(item_ids, rets, sim_matrix);
}

void HBasePoolGetSim::GetRowMap(const std::vector<std::string>& item_keys,
                                std::map<std::string, std::map<std::string, std::string> >* row_map) {
  // must deal with duplicate id in item_ids
  int retry = 0;
  while (retry++ < 3) {
    reco::hbase::HBaseAutoCli cli(10);
    if (!cli.Get()) {
      continue;
    }

    if (cli.Get()->BatchGetByKeys(table_name_, item_keys, row_map)) {
      break;
    } else {
      LOG(WARNING) << "get item from hbase failed!";
      continue;
    }
  }
}

void HBasePoolGetSim::GetSimItems(const std::vector<uint64>& item_ids, std::vector<bool>* rets,
                                  std::vector<std::vector<uint64> >* sim_matrix) {
  std::vector<std::vector<SimResult> > matrix;
  GetSimItems(item_ids, rets, &matrix);

  sim_matrix->clear();
  sim_matrix->resize(matrix.size());

  for (size_t i = 0; i < matrix.size(); ++i) {
    if (!rets->at(i)) continue;
    sim_matrix->at(i).reserve(matrix[i].size());
    std::vector<uint64>& sim_vec = sim_matrix->at(i);
    for (size_t j = 0; j < matrix[i].size(); ++j) {
      if (matrix[i][j].level > 2) continue;
      sim_vec.push_back(matrix[i][j].item_id);
    }
  }
}

inline bool parse_sim_result(const std::string& line, SimResult* result) {
  std::vector<std::string> flds;
  base::SplitString(line, ":", &flds);

  if (flds.size() < 2) {
    LOG(ERROR) << "erro fld: " << line << " size:" << flds.size();
    return false;
  }

  if (!base::StringToUint64(flds[0], &result->item_id)) {
    LOG(ERROR) << "erro itemid: " << flds[0];
    return false;
  }

  double score;
  if (flds.size() == 2) {
    if (!base::StringToDouble(flds[1], &score)) {
      LOG(ERROR) << "erro score: " << flds[1];
      return false;
    }
    result->level = 1;
  } else {
    if (!base::StringToInt(flds[1], &result->level)) {
      LOG(ERROR) << "erro level: " << flds[1];
      return false;
    }

    if (!base::StringToDouble(flds[2], &score)) {
      LOG(ERROR) << "erro score: " << flds[2];
      return false;
    }
  }
  result->score = score;
  return true;
}

bool HBasePoolGetSim::GetSimItem(uint64 item_id, std::vector<SimResult>* sims) {
  std::vector<uint64> item_ids;
  item_ids.push_back(item_id);

  std::vector<bool> rets;
  std::vector<std::vector<SimResult>> sim_matrix;
  GetSimItems(item_ids, &rets, &sim_matrix);
  if (rets[0]) {
    sims->swap(sim_matrix[0]);
  }
  return rets[0];
}

bool HBasePoolGetSim::GetSimItemByFingerPrint(uint64 item_id, std::vector<SimResult>* sims) {
  std::vector<uint64> item_ids;
  item_ids.push_back(item_id);
  std::vector<bool> rets;
  std::vector<std::vector<SimResult> > sim_matrix;
  GetSimItemsByFingerPrint(item_ids, &rets, &sim_matrix);
  if (rets[0]) {
    sims->swap(sim_matrix[0]);
  }
  return rets[0];
}

void HBasePoolGetSim::GetSimItemsByFingerPrint(const std::vector<uint64>& item_ids, std::vector<bool>* rets,
                                               std::vector<std::vector<SimResult> >* sim_matrix) {
  std::vector<std::string> item_keys;
  for (int i = 0; i < (int)item_ids.size(); ++i) {
    item_keys.push_back(base::Uint64ToString(item_ids[i]));
  }
  sim_matrix->resize(item_ids.size());
  rets->resize(item_ids.size());

  std::map<std::string, std::map<std::string, std::string> > row_map;
  GetRowMap(item_keys, &row_map);

  std::vector<std::string> flds;
  std::vector<std::string> flds2;
  SimResult sim_result;
  for (size_t i = 0; i < item_ids.size(); ++i) {
    if (rets->at(i)) continue;
    uint64 id = item_ids[i];
    std::string key = base::Uint64ToString(id);
    auto it = row_map.find(key);
    if (it == row_map.end()) continue;
    auto it2 = it->second.find("sim:zhiwen_sim");
    if (it2 == it->second.end()) {
      continue;
    }

    flds.clear();
    base::SplitString(it2->second, ",", & flds);
    sim_matrix->at(i).reserve(flds.size());
    for (size_t j = 0; j < flds.size(); ++j) {
      if (flds[j].size() < 2) continue;
      if (!parse_sim_result(flds[j], &sim_result)) continue;
      sim_matrix->at(i).push_back(sim_result);
    }

    rets->at(i) = true;
  }
}

void HBasePoolGetSim::GetSimItems(const std::vector<std::string>& item_str_ids, std::vector<bool>* rets,
                                  std::vector<std::vector<SimResult> >* sim_matrix) {
  std::vector<uint64> item_ids(item_str_ids.size(), 0);
  for (size_t i = 0; i < item_str_ids.size(); ++i) {
    uint64 id = 0;
    if (base::StringToUint64(item_str_ids[i], &id)) {
      item_ids[i] = id;
    }
  }
  GetSimItems(item_ids, rets, sim_matrix);
}

void HBasePoolGetSim::GetSimItems(const std::vector<uint64>& item_ids, std::vector<bool>* rets,
                                  std::vector<std::vector<SimResult> >* sim_matrix) {
  rets->clear();
  rets->resize(item_ids.size(), false);
  sim_matrix->clear();
  sim_matrix->resize(item_ids.size());

  // must deal with duplicate id in item_ids
  std::vector<std::string> item_keys;
  for (int i = 0; i < (int)item_ids.size(); ++i) {
    item_keys.push_back(base::Uint64ToString(item_ids[i]));
  }

  if (item_keys.empty()) {
    return;
  }

  std::map<std::string, std::map<std::string, std::string> > row_map;
  GetRowMap(item_keys, &row_map);

  std::vector<std::string> flds;
  std::vector<std::string> flds2;
  SimResult sim_result;
  for (size_t i = 0; i < item_ids.size(); ++i) {
    if (rets->at(i)) continue;
    uint64 id = item_ids[i];
    std::string key = base::Uint64ToString(id);
    auto it = row_map.find(key);
    if (it == row_map.end()) continue;
    auto it2 = it->second.find("sim:list_global_incr");
    if (it2 == it->second.end()) {
      // LOG(ERROR) << "canot find proto for key: " << key;
      continue;
    }

    flds.clear();
    base::SplitString(it2->second, ",", & flds);
    sim_matrix->at(i).reserve(flds.size());
    for (size_t j = 0; j < flds.size(); ++j) {
      if (flds[j].size() < 2) continue;
      if (!parse_sim_result(flds[j], &sim_result)) continue;
      sim_matrix->at(i).push_back(sim_result);
    }

    rets->at(i) = true;
  }
}


void HBasePoolGetSim::GetSimItemsAndParent(const std::vector<uint64>& item_ids, std::vector<bool>* rets,
                                           std::vector<std::vector<SimResult> >* sim_matrix,
                                           std::vector<uint64>* parent_vec) {
  rets->clear();
  rets->resize(item_ids.size(), false);
  sim_matrix->clear();
  sim_matrix->resize(item_ids.size());
  parent_vec->clear();
  parent_vec->resize(item_ids.size());

  // must deal with duplicate id in item_ids
  std::vector<std::string> item_keys;
  for (int i = 0; i < (int)item_ids.size(); ++i) {
    item_keys.push_back(base::Uint64ToString(item_ids[i]));
  }

  if (item_keys.empty()) {
    return;
  }

  std::map<std::string, std::map<std::string, std::string> > row_map;
  GetRowMap(item_keys, &row_map);

  std::vector<std::string> flds;
  std::vector<std::string> flds2;
  SimResult sim_result;
  uint64 parent_id;
  for (size_t i = 0; i < item_ids.size(); ++i) {
    if (rets->at(i)) continue;
    uint64 id = item_ids[i];
    std::string key = base::Uint64ToString(id);
    auto it = row_map.find(key);
    if (it == row_map.end()) continue;

    auto it2 = it->second.find("sim:list_global_incr");
    if (it2 != it->second.end()) {
      flds.clear();
      base::SplitString(it2->second, ",", & flds);
      sim_matrix->at(i).reserve(flds.size());
      for (size_t j = 0; j < flds.size(); ++j) {
        if (!parse_sim_result(flds[j], &sim_result)) continue;
        sim_matrix->at(i).push_back(sim_result);
      }
    }

    parent_vec->at(i) = id;
    it2 = it->second.find("sim:parentid");
    if (it2 != it->second.end()) {
      if (base::StringToUint64(it2->second, &parent_id)) {
        parent_vec->at(i) = parent_id;
      }
    }

    rets->at(i) = true;
  }
}

bool HBasePoolGetSim::GetParentId(uint64 item_id, uint64* parent_id) {
  // must deal with duplicate id in item_ids
  std::vector<std::string> item_keys;
  std::string key = base::Uint64ToString(item_id);
  item_keys.push_back(key);
  if (item_keys.empty()) return false;
  std::map<std::string, std::map<std::string, std::string> > row_map;
  GetRowMap(item_keys, &row_map);
  auto it = row_map.find(key);
  if (it == row_map.end()) return false;
  auto it2 = it->second.find("sim:parentid");
  if (it2 == it->second.end()) {
    LOG(ERROR) << "cannot find parent id for key:\t" << key;
    return false;
  }
  if (!base::StringToUint64(it2->second, parent_id)) {
    LOG(INFO) << "cannot parse parent id:\t" << it2->second;
    return false;
  }
  return true;
}
}  // namespace reco
