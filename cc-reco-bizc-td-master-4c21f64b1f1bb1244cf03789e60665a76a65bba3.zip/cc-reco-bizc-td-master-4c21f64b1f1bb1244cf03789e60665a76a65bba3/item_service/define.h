#pragma once
#include "base/common/base.h"

namespace reco {
namespace item_attr {
enum {
  kContentAttr = 0,
  kUcBrowserDeliverSetting = 1,
  kUcBrowserDisplaySetting = 2,
  kQualityAttr,
  kIsValid,
  kTitle,
  kExpireTime,
  kThirdPartyUrl,
  kDaoLiuUrlIsOk,
  kGaoDePOI,
  kShowSource,
  kVideoMetaSetting,
  kContent,
  kChannelIds,
  kHasReviewed,
  kTag,
  kShowTag,
  kCategory,
  kVideoAttr,
  kVideoStorageInfo,
  kItemQualityAttr,
};

// extern const char* kAllSuffix[];
static const char* kAllSuffix[] __attribute__((unused)) = {"content_attr", "uc_browser_deliver_setting",
  "uc_browser_display_setting", "quality_attr", "is_valid", "title", "expire_time", "third_party_url",
  "dao_liu_url_is_ok", "gaode_poi", "show_source", "video_meta_settings", "content", "channel_id",
  "has_reviewed", "tag", "show_tag", "category", "video_attr", "video_storage_info", "quality_attr"};

static const int kAllAttr[] __attribute__((unused)) =  {kContentAttr, kUcBrowserDeliverSetting,
  kUcBrowserDisplaySetting, kQualityAttr, kIsValid, kTitle, kExpireTime, kThirdPartyUrl, kDaoLiuUrlIsOk,
  kGaoDePOI, kShowSource, kVideoMetaSetting, kContent, kChannelIds, kHasReviewed, kTag, kShowTag, kCategory,
  kVideoAttr, kVideoStorageInfo, kItemQualityAttr};
}

struct SimResult {
  uint64 item_id;
  int level;
  float score;
};
}
