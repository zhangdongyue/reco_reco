#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/proto/item.pb.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/file/file_util.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_int32(get_manner, 0, "0:doc server; 1: item keeper; 2: hbase");

DEFINE_string(doc_server_ips, "11.251.203.139", "host of doc server");
DEFINE_int32(doc_server_port, 20013, "doc server port");

DEFINE_string(item_keeper_ips, "11.251.202.129", "item keeper");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");

DEFINE_string(reco_item_table, "tb_reco_item", "");

DEFINE_string(item_id, "", "");
DEFINE_string(item_id_file, "", "");

DEFINE_bool(batch, false, "");
DEFINE_bool(print_reco_item, false, "");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");

  reco::BaseGetItem* get_item = NULL;
  if (FLAGS_get_manner == 0) {
    get_item = new reco::DocServerGetItem(FLAGS_doc_server_ips, FLAGS_doc_server_port);
  } else if (FLAGS_get_manner == 1) {
    get_item = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips, FLAGS_item_keeper_port);
  } else if (FLAGS_get_manner == 2) {
    get_item = new reco::HBaseGetItem(FLAGS_reco_item_table);
  }

  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }

  if (FLAGS_batch) {
    std::vector<reco::RecoItem> reco_items;
    get_item->GetRecoItems(item_id_list, &reco_items);
    for (size_t i = 0; i < reco_items.size(); ++i) {
      if (FLAGS_print_reco_item) {
        LOG(INFO) << reco_items[i].Utf8DebugString();
      }
    }
    LOG(INFO) << "get " << reco_items.size() << " items from " << item_id_list.size() << " ids";
  } else {
    uint64 got_cnt = 0;
    for (int i = 0; i < (int)item_id_list.size(); ++i) {
      reco::RecoItem reco_item;
      uint64 item_id;
      if (!base::StringToUint64(item_id_list[i], &item_id)) {
        continue;
      }
      if (!get_item->GetRecoItem(item_id, &reco_item)) {
        LOG(ERROR) << "failed to get reco item: " << item_id;
        continue;
      }
      ++got_cnt;
      if (FLAGS_print_reco_item) {
        LOG(INFO) << reco_item.Utf8DebugString();
      }
    }
    LOG(INFO) << "get " << got_cnt << " items from " << item_id_list.size() << " ids";
  }

  delete get_item;
}
