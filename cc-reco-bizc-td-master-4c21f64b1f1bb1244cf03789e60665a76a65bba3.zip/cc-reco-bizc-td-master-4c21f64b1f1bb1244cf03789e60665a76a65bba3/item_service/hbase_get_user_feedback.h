#pragma once
#include <string>
#include <vector>
#include "base/common/base.h"
#include "reco/bizc/proto/feedback.pb.h"

namespace reco {
namespace hbase {
class HBaseCli;
}  // namespace hbase
// NOTE: not thread safe
class HBaseGetUserFeedback {
 public:
  // cache size: lru cache size, set to <=0 will not use cache
  explicit HBaseGetUserFeedback(const std::string& hbase_table_name);
  ~HBaseGetUserFeedback();

  bool GetUserFeedback(uint64 user_id, reco::UserFeedback* result);

  void GetUserFeedback(const std::vector<uint64>& user_ids,
                     std::vector<bool>* rets, std::vector<reco::UserFeedback>* result);

 private:
  void GetRawResult(const std::vector<std::string>& row_keys,
                    std::vector<bool>* rets,
                    std::vector<std::string>* result);

  std::string table_name_;
};
}  // namespace reco
