#pragma once

#include <string>
#include "base/common/base.h"
#include "base/testing/gtest_prod.h"
#include "reco/bizc/proto/feedback.pb.h"
#include "reco/bizc/item_service/define.h"

namespace reco {
// NOTE: thread safe
class HBasePoolSetMediaFeedback {
 public:
  explicit HBasePoolSetMediaFeedback(const std::string& hbase_table_name);
  ~HBasePoolSetMediaFeedback();

  bool SetMediaFeedback(const std::string& media_name, const reco::MediaFeedback& value);

 private:
  static const int kRetryTimes = 3;
  static const int kReconnectTimes = 10;

  std::string table_name_;
};
}  // namespace reco

