#include "reco/bizc/item_service/hbase_set_item.h"
#include <string>
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"

namespace reco {

HBaseSetItem::HBaseSetItem(const std::string& hbase_table_name) {
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited()) << "init hbase pool first";
  table_name_ = hbase_table_name;
}

HBaseSetItem::~HBaseSetItem() {
}

bool HBaseSetItem::SetRecoItem(const RecoItem& reco_item) {
  CHECK(reco_item.IsInitialized());
  std::string item_key = base::Uint64ToString(reco_item.identity().item_id());

  std::string serialized;
  CHECK(reco_item.SerializeToString(&serialized));

  return Write(item_key, "data", "proto", serialized);
}

bool HBaseSetItem::Write(const std::string& row_key, const std::string& column_family, const std::string& col,
                         const std::string& value) {
  int retry = 0;
  bool succ = false;
  while (retry++ < kRetryTimes) {
    reco::hbase::HBaseAutoCli cli = reco::hbase::HBaseAutoCli(10);
    reco::hbase::HBaseCli* client = cli.Get();
    if (client == NULL) {
      continue;
    }
    if (client->Insert(table_name_, row_key, column_family, col, value)) {
      succ = true;
      break;
    } else {
      continue;
    }
  }
  return succ;
}
}  // namespace reco
