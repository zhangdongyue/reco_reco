#pragma once

#include <string>
#include "base/common/base.h"
#include "reco/bizc/proto/item.pb.h"
#include "base/testing/gtest_prod.h"

namespace net {
namespace rpc {
class RpcGroup;
}
}

namespace reco {
namespace hbase {
class HBaseCli;
}  // namespace hbase

class HBaseSetItem {
 public:
  explicit HBaseSetItem(const std::string& hbase_table_name);
  ~HBaseSetItem();

  // 写入一条 reco item 记录，设置不成功返回 false,
  // NOTE：内部会调用 reco_item 的 Isvalid 检查，不通过会 CHECK
  bool SetRecoItem(const RecoItem& reco_item);

 private:
  static const int kRetryTimes = 3;
  static const int kReconnectTimes = 10;

  bool Write(const std::string& key, const std::string& column_family, const std::string& col,
             const std::string& value);

  std::string table_name_;

  FRIEND_TEST(ContentAttrTest, HBaseSet);
};
}  // namespace reco

