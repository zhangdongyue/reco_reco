#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/bizc/item_service/doc_server_set_item.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/hbase_set_item.h"
#include "reco/bizc/item_service/hbase_set_item_attr.h"
#include "reco/bizc/item_service/hbase_get_item_attr.h"
#include "reco/bizc/item_service/hbase_pool_get_sim.h"
#include "reco/bizc/item_service/hbase_pool_set_sim.h"
#include "reco/bizc/item_service/define.h"
#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "base/common/base.h"
#include "base/time/time.h"
#include "base/random/pseudo_random.h"
#include "base/hash_function/term.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/common/sleep.h"

DEFINE_string(doc_server_ips, "11.251.177.90", "host of hbase server");
DEFINE_int32(doc_server_port, 20013, "port of hbase thrift2 service");
DEFINE_string(hbase_item_table, "tb_test_reco_item", "hbase table");
DEFINE_string(hbase_sim_table, "tb_sim_item_test", "hbase sim table");

namespace reco {
namespace hbase {
DECLARE_string(hbase_thrift_ips);
}
class ItemServiceTest : public testing::Test {
 public:
  void SetUp() {
    reco::hbase::FLAGS_hbase_thrift_ips="11.251.181.33:9090";
    static struct {
      uint64 item_id;
      bool succ;
    } cases[] = {
      // {1, false},
      {14014151457875540297ul, true},
      {7721436043300852221ul, true},
      {16532556084727525712ul, true},
      // {2, false},
      {1800862579268744372ul, true},
      {3413267208801171767ul, true},
      // {7, false},
      {12996586625377005608ul, true},
      {1493845547665206326ul, true},
      {2473235934901962009ul, true},
      {9731607073849682633ul, true},
    };
    for (int i = 0; i < (int)ARRAYSIZE_UNSAFE(cases); ++i) {
      cases_.push_back(std::make_pair(cases[i].item_id, cases[i].succ));
      // test cache
      cases_.push_back(std::make_pair(cases[i].item_id, cases[i].succ));
      cases_.push_back(std::make_pair(cases[i].item_id, cases[i].succ));
    }
    reco::hbase::HBasePoolIns::instance().Init();
    CHECK(reco::hbase::HBasePoolIns::instance().is_inited());
  }
  void TearDown() {
  }

  reco::RecoItem CreateNewItem(uint64 item_id) {
    reco::RawItem raw_item;

    base::Time now = base::Time::Now();
    raw_item.mutable_identity()->set_app_token("app");
    raw_item.mutable_identity()->set_item_id(item_id);
    raw_item.mutable_identity()->set_type(reco::kNews);
    raw_item.mutable_identity()->set_outer_id("outer");

    raw_item.set_is_valid(true);
    raw_item.set_is_webview(false);
    raw_item.add_category("1");

    raw_item.set_title("abcdedss");
    raw_item.set_content("");
    raw_item.set_source("sina");

    reco::RecoItem reco_item;
    reco_item.mutable_raw_item()->CopyFrom(raw_item);
    reco_item.mutable_identity()->set_app_token("app");
    reco_item.mutable_identity()->set_item_id(item_id);
    reco_item.mutable_identity()->set_type(reco::kNews);
    reco_item.mutable_identity()->set_outer_id("outer");
    reco_item.set_is_valid(true);
    now.ToStringInSeconds(reco_item.mutable_create_time());
    reco_item.set_title(raw_item.title());
    reco_item.set_content(raw_item.content());
    reco_item.set_source(raw_item.source());
    reco_item.add_category("1");

    return reco_item;
  }

  std::vector<std::pair<uint64, bool>> cases_;
};

// TEST_F(ItemServiceTest, DocServerGetNoCache) {
//   reco::DocServerGetItem get_item(FLAGS_doc_server_ips, FLAGS_doc_server_port, 0);
//   std::vector<uint64> item_ids;
//   std::vector<bool> rets;
//   std::vector<reco::RecoItem> reco_items;
//   for (size_t i = 0; i < cases_.size(); ++i) {
//     uint64 item_id = cases_[i].first;
//     item_ids.push_back(item_id);
//     reco::RecoItem reco_item;
//     bool ret = get_item.GetRecoItem(item_id, &reco_item, false);
//     ASSERT_EQ(cases_[i].second, ret);
//     if (ret) {
//       ASSERT_EQ(item_id, reco_item.identity().item_id());
//     }
//   }
//   get_item.GetRecoItems(item_ids, &rets, &reco_items, false);
//   ASSERT_EQ(rets.size(), reco_items.size());
//   for (size_t i = 0; i < cases_.size(); ++i) {
//     uint64 item_id = cases_[i].first;
//     ASSERT_EQ(cases_[i].second, rets[i]) << item_id;
//     if (rets[i]) {
//       ASSERT_EQ(item_id, reco_items[i].identity().item_id()) << item_id;
//     }
//   }
// }
//
// TEST_F(ItemServiceTest, DocServerGetCache) {
//   reco::DocServerGetItem get_item(FLAGS_doc_server_ips, FLAGS_doc_server_port, 100);
//   std::vector<uint64> item_ids;
//   std::vector<bool> rets;
//   std::vector<reco::RecoItem> reco_items;
//   for (size_t i = 0; i < cases_.size(); ++i) {
//     uint64 item_id = cases_[i].first;
//     item_ids.push_back(item_id);
//     reco::RecoItem reco_item;
//     bool ret = get_item.GetRecoItem(item_id, &reco_item, false);
//     ASSERT_EQ(cases_[i].second, ret);
//     if (ret) {
//       ASSERT_EQ(item_id, reco_item.identity().item_id());
//     }
//   }
//   get_item.GetRecoItems(item_ids, &rets, &reco_items, false);
//   ASSERT_EQ(rets.size(), reco_items.size());
//   for (size_t i = 0; i < cases_.size(); ++i) {
//     uint64 item_id = cases_[i].first;
//     ASSERT_EQ(cases_[i].second, rets[i]);
//     if (rets[i]) {
//       ASSERT_EQ(item_id, reco_items[i].identity().item_id());
//     }
//   }
// }

// TEST_F(ItemServiceTest, HBaseGetNoCache) {
//   reco::HBaseGetItem get_item(FLAGS_hbase_item_table, 0);
//   std::vector<uint64> item_ids;
//   std::vector<bool> rets;
//   std::vector<reco::RecoItem> reco_items;
//   for (size_t i = 0; i < cases_.size(); ++i) {
//     uint64 item_id = cases_[i].first;
//     item_ids.push_back(item_id);
//     reco::RecoItem reco_item;
//     bool ret = get_item.GetRecoItem(item_id, &reco_item);
//     ASSERT_EQ(cases_[i].second, ret) << item_id;
//     if (ret) {
//       ASSERT_EQ(item_id, reco_item.identity().item_id());
//     }
//   }
//   get_item.GetRecoItems(item_ids, &rets, &reco_items);
//   ASSERT_EQ(rets.size(), reco_items.size());
//   for (size_t i = 0; i < cases_.size(); ++i) {
//     uint64 item_id = cases_[i].first;
//     ASSERT_EQ(cases_[i].second, rets[i]) << item_id;
//     if (rets[i]) {
//       ASSERT_EQ(item_id, reco_items[i].identity().item_id()) << item_id;
//     }
//   }
// }
//
// TEST_F(ItemServiceTest, HBaseGetCache) {
//   reco::HBaseGetItem get_item(FLAGS_hbase_item_table, 100);
//   std::vector<uint64> item_ids;
//   std::vector<bool> rets;
//   std::vector<reco::RecoItem> reco_items;
//   for (size_t i = 0; i < cases_.size(); ++i) {
//     uint64 item_id = cases_[i].first;
//     item_ids.push_back(item_id);
//     reco::RecoItem reco_item;
//     bool ret = get_item.GetRecoItem(item_id, &reco_item);
//     ASSERT_EQ(cases_[i].second, ret);
//     if (ret) {
//       ASSERT_EQ(item_id, reco_item.identity().item_id());
//     }
//   }
//   get_item.GetRecoItems(item_ids, &rets, &reco_items);
//   ASSERT_EQ(rets.size(), reco_items.size());
//   for (size_t i = 0; i < cases_.size(); ++i) {
//     uint64 item_id = cases_[i].first;
//     ASSERT_EQ(cases_[i].second, rets[i]);
//     if (rets[i]) {
//       ASSERT_EQ(item_id, reco_items[i].identity().item_id());
//     }
//   }
// }

// TEST_F(ItemServiceTest, HBaseSet) {
//   reco::HBaseGetItem get_item(FLAGS_hbase_item_table, 0);
//   reco::HBaseSetItem set_item(FLAGS_hbase_item_table);
//   for (size_t i = 0; i < cases_.size(); ++i) {
//     if (!cases_[i].second) continue;
//     uint64 item_id = cases_[i].first;
//     reco::RecoItem reco_item1;
//     // ASSERT_TRUE(get_item.GetRecoItem(item_id, &reco_item1));
//
//     ASSERT_TRUE(set_item.SetRecoItem(reco_item1));
//
//     reco::RecoItem reco_item2;
//     ASSERT_TRUE(get_item.GetRecoItem(item_id, &reco_item2));
//
//     std::string str1, str2;
//     ASSERT_TRUE(reco_item1.SerializeToString(&str1));
//     ASSERT_TRUE(reco_item2.SerializeToString(&str2));
//     LOG(ERROR) << str1.size() << ":" << str2.size();
//     ASSERT_STREQ(str1.c_str(), str2.c_str());
//   }
//
//   base::PseudoRandom random;
//   reco::RecoItem item1 = CreateNewItem(random.GetInt(50, 10000));
//   set_item.SetRecoItem(item1);
//   reco::RecoItem item2;
//   get_item.GetRecoItem(item1.identity().item_id(), &item2);
//   std::string str1, str2;
//   ASSERT_TRUE(item1.SerializeToString(&str1));
//   ASSERT_TRUE(item2.SerializeToString(&str2));
//   ASSERT_STREQ(str1.c_str(), str2.c_str());
// }
//
// TEST_F(ItemServiceTest, DocServerSet) {
//   reco::DocServerGetItem get_item(FLAGS_doc_server_ips, FLAGS_doc_server_port, 0);
//   reco::DocServerSetItem set_item(FLAGS_doc_server_ips, FLAGS_doc_server_port);
//
//   for (size_t i = 0; i < cases_.size(); ++i) {
//     if (!cases_[i].second) continue;
//     uint64 item_id = cases_[i].first;
//     reco::RecoItem reco_item1;
//     // ASSERT_TRUE(get_item.GetRecoItem(item_id, &reco_item1, false));
//
//     ASSERT_TRUE(set_item.SetRecoItem(reco_item1));
//
//     reco::RecoItem reco_item2;
//     ASSERT_TRUE(get_item.GetRecoItem(item_id, &reco_item2, false));
//
//     std::string str1, str2;
//     ASSERT_TRUE(reco_item1.SerializeToString(&str1));
//     ASSERT_TRUE(reco_item2.SerializeToString(&str2));
//     LOG(ERROR) << str1.size() << ":" << str2.size();
//     ASSERT_STREQ(str1.c_str(), str2.c_str());
//   }
//
//   base::PseudoRandom random;
//   reco::RecoItem item1 = CreateNewItem(random.GetInt(50, 10000));
//   set_item.SetRecoItem(item1);
//   reco::RecoItem item2;
//   get_item.GetRecoItem(item1.identity().item_id(), &item2, false);
//   std::string str1, str2;
//   ASSERT_TRUE(item1.SerializeToString(&str1));
//   ASSERT_TRUE(item2.SerializeToString(&str2));
//   ASSERT_STREQ(str1.c_str(), str2.c_str());
// }


// TEST(ItemAttrTest, HBaseSet) {
//   reco::HBaseSetItemAttr set_item_attr(FLAGS_hbase_item_field_table);
//
//   reco::HBaseGetItemAttr get_item_attr(FLAGS_hbase_item_field_table);
//   reco::UcBrowserDeliverSetting deliver;
//   deliver.add_province("prov");
//   deliver.add_city("city");
//   deliver.add_ve("ve");
//   deliver.add_fr("fr");
//   deliver.add_isp("isp");
//   deliver.add_nt("nt");
//   deliver.add_sv("sv");
//
//   reco::UcBrowserDisplaySetting display;
//   struct {
//     uint64 item_id;
//     std::string content_attr;
//     std::string tag;
//     int daoliu_type;
//
//     std::string third_party_url;
//     std::string expire_time;
//     std::string title;
//
//     bool is_valid;
//     bool is_ok;
//   } cases[] = {
//     {1, "2,0,0,0,0,0,2", "tag1", 0, "http://url", "2016-03-31 00:00:00", "title1", false, false},
//     {2, "0,2,0,0,0,0,2", "tag2", 1, "http://url2", "2016-03-31 01:00:00", "title2", false, true},
//     {3, "0,0,2,0,0,0,0", "tag3", 2, "http://url3", "2016-03-31 02:00:00", "title3", true, false},
//     {4, "2,0,1,0,0,0,0", "tag4", 3, "http://url4", "2016-03-31 03:00:00", "title4", true, true}
//   };
//
//   int num = ARRAYSIZE_UNSAFE(cases);
//
//   std::vector<std::string> flds;
//   std::vector<reco::ContentAttr> setted_items_attr;
//   setted_items_attr.resize(num);
//
//   reco::ContentAttr::ContentAttrLevel attr_values[] = { reco::ContentAttr::kSureNo,
//     reco::ContentAttr::kSuspect, reco::ContentAttr::kSureYes };
//   for (int i = 0; i < num; ++i) {
//     flds.clear();
//     base::SplitString(cases[i].content_attr, ",", &flds);
//     ASSERT_EQ(flds.size(), 7u);
//
//     reco::ContentAttr content_attr;
//     content_attr.set_erro_title(attr_values[base::ParseIntOrDie(flds[0])]);
//     content_attr.set_advertorial(attr_values[base::ParseIntOrDie(flds[1])]);
//     content_attr.set_short_content(attr_values[base::ParseIntOrDie(flds[2])]);
//     content_attr.set_dedup_paragraph(attr_values[base::ParseIntOrDie(flds[3])]);
//     content_attr.set_dirty(attr_values[base::ParseIntOrDie(flds[4])]);
//     content_attr.set_politics(attr_values[base::ParseIntOrDie(flds[5])]);
//     content_attr.set_bluffing_title(attr_values[base::ParseIntOrDie(flds[6])]);
//
//     // content_attr
//     ASSERT_TRUE(set_item_attr.SetItemAttr(cases[i].item_id, reco::item_attr::kContentAttr, content_attr));
//     // uc browser deliver setting
//     deliver.clear_tag();
//     deliver.add_tag(cases[i].tag);
//     ASSERT_TRUE(set_item_attr.SetItemAttr(cases[i].item_id, reco::item_attr::kUcBrowserDeliverSetting,
//                                           deliver));
//
//     // uc diplay setting
//     display.set_daoliu_type(cases[i].daoliu_type);
//     ASSERT_TRUE(set_item_attr.SetItemAttr(cases[i].item_id, reco::item_attr::kUcBrowserDisplaySetting,
//                                           display));
//
//     // thrird party url
//     ASSERT_TRUE(set_item_attr.SetItemAttr(cases[i].item_id, reco::item_attr::kThirdPartyUrl,
//                                           cases[i].third_party_url));
//
//     // expire time
//     ASSERT_TRUE(set_item_attr.SetItemAttr(cases[i].item_id, reco::item_attr::kExpireTime,
//                                           cases[i].expire_time));
//     // title
//     ASSERT_TRUE(set_item_attr.SetItemAttr(cases[i].item_id, reco::item_attr::kTitle,
//                                           cases[i].title));
//
//     // is_valid
//     ASSERT_TRUE(set_item_attr.SetItemAttr(cases[i].item_id, reco::item_attr::kIsValid,
//                                           cases[i].is_valid));
//
//     // dao liu url is ok
//     ASSERT_TRUE(set_item_attr.SetItemAttr(cases[i].item_id, reco::item_attr::kDaoLiuUrlIsOk,
//                                           cases[i].is_ok));
//
//     // get back for cmp
//     reco::ContentAttr cur_content_attr;
//     // content attr
//     ASSERT_TRUE(get_item_attr.GetItemAttr(cases[i].item_id,
//                                           reco::item_attr::kContentAttr, &cur_content_attr));
//
//     ASSERT_EQ(cur_content_attr.erro_title(), content_attr.erro_title()) << cases[i].item_id;
//     ASSERT_EQ(cur_content_attr.advertorial(), content_attr.advertorial()) << cases[i].item_id;
//     ASSERT_EQ(cur_content_attr.short_content(), content_attr.short_content()) << cases[i].item_id;
//     ASSERT_EQ(cur_content_attr.dedup_paragraph(), content_attr.dedup_paragraph()) << cases[i].item_id;
//     ASSERT_EQ(cur_content_attr.dirty(), content_attr.dirty()) << cases[i].item_id;
//     ASSERT_EQ(cur_content_attr.politics(), content_attr.politics()) << cases[i].item_id;
//     ASSERT_EQ(cur_content_attr.bluffing_title(), content_attr.bluffing_title()) << cases[i].item_id;
//
//     reco::UcBrowserDeliverSetting deliver_setting;
//     ASSERT_TRUE(get_item_attr.GetItemAttr(cases[i].item_id, reco::item_attr::kUcBrowserDeliverSetting,
//                                           &deliver_setting));
//     ASSERT_EQ(deliver_setting.DebugString(), deliver.DebugString());
//
//     reco::UcBrowserDisplaySetting display_setting;
//     ASSERT_TRUE(get_item_attr.GetItemAttr(cases[i].item_id, reco::item_attr::kUcBrowserDisplaySetting,
//                                           &display_setting));
//     ASSERT_EQ(display_setting.DebugString(), display.DebugString());
//
//     std::string url;
//     ASSERT_TRUE(get_item_attr.GetItemAttr(cases[i].item_id, reco::item_attr::kThirdPartyUrl, &url));
//     ASSERT_EQ(cases[i].third_party_url, url);
//
//     std::string expire_time;
//     ASSERT_TRUE(get_item_attr.GetItemAttr(cases[i].item_id, reco::item_attr::kExpireTime,
//                                           &expire_time));
//     ASSERT_EQ(cases[i].expire_time, expire_time);
//
//     std::string title;
//     ASSERT_TRUE(get_item_attr.GetItemAttr(cases[i].item_id, reco::item_attr::kTitle, &title));
//     ASSERT_EQ(cases[i].title, title);
//
//     bool is_valid;
//     ASSERT_TRUE(get_item_attr.GetItemAttr(cases[i].item_id, reco::item_attr::kIsValid, &is_valid));
//     ASSERT_EQ(cases[i].is_valid, is_valid);
//
//     bool is_ok;
//     ASSERT_TRUE(get_item_attr.GetItemAttr(cases[i].item_id, reco::item_attr::kDaoLiuUrlIsOk, &is_ok));
//     ASSERT_EQ(cases[i].is_ok, is_ok);
//   }
// }

TEST(SimTest, ParentIdGetSet) {
  reco::hbase::FLAGS_hbase_thrift_ips="11.251.181.33:9090";
  reco::hbase::HBasePoolIns::instance().Init();
  reco::HBasePoolGetSim get_sim(FLAGS_hbase_sim_table);
  struct {
    std::string item_id;
    std::string  parent_id;
  } cases[] = {
    {"1338123179526407956", "17071504637505694456"},
  };

  int num = ARRAYSIZE_UNSAFE(cases);

  for (int i = 0; i < num; ++i) {
    uint64 item_id;
    base::StringToUint64(cases[i].item_id, &item_id);
    uint64 parent_id_ori;
    base::StringToUint64(cases[i].parent_id, &parent_id_ori);
    uint64 parent_id = 0;
    if (!get_sim.GetParentId(item_id, &parent_id)) {
      LOG(ERROR) << "fail to get parent id:\t" << item_id;
    }
    ASSERT_EQ(parent_id, parent_id_ori) << cases[i].item_id;
  }
}

TEST(SimTest, PoolSetTest) {
  reco::hbase::FLAGS_hbase_thrift_ips="11.251.181.33:9090";
  reco::hbase::HBasePoolIns::instance().Init();
  reco::HBasePoolGetSim get_sim(FLAGS_hbase_sim_table);
  reco::HBasePoolSetSim set_sim(FLAGS_hbase_sim_table);
  struct {
    std::string item_id;
    std::string sim_value;
  } cases[] = {
    {"862", "111:1:0.9,112:2:0.7,113:3:0.1"},
  };

  int num = ARRAYSIZE_UNSAFE(cases);

  std::vector<std::string> flds;
  std::vector<uint64> sim_ids;
  std::vector<SimResult> sim_values;
  for (int i = 0; i < num; ++i) {
    uint64 item_id;
    ASSERT_TRUE(base::StringToUint64(cases[i].item_id, &item_id));
    flds.clear();
    base::SplitString(cases[i].sim_value, ",", &flds);

    sim_values.clear();
    sim_ids.clear();
    for (size_t j = 0; j < flds.size(); ++j) {
      SimResult re;
      std::vector<std::string> elements;
      base::SplitString(flds[j], ":", &elements);
      ASSERT_EQ(elements.size(), 3u);
      ASSERT_TRUE(base::StringToUint64(elements[0], &re.item_id));
      ASSERT_TRUE(base::StringToInt(elements[1], &re.level));
      double score = 0;
      ASSERT_TRUE(base::StringToDouble(elements[2], &score));
      re.score = score;
      sim_values.push_back(re);
      if (re.level > 2) continue;
      sim_ids.push_back(re.item_id);
    }
    ASSERT_TRUE(set_sim.SetSim(item_id, sim_values));
    std::vector<SimResult> sim_values_in_hbase;
    ASSERT_TRUE(get_sim.GetSimItem(item_id, &sim_values_in_hbase));
    ASSERT_EQ(sim_values.size(), sim_values_in_hbase.size());

    std::unordered_map<uint64, SimResult> dict;
    for (size_t j = 0; j < sim_values.size(); ++j) {
      dict[sim_values[j].item_id] = sim_values[j];
    }

    for (size_t j = 0; j < sim_values.size(); ++j) {
      auto it = dict.find(sim_values_in_hbase[j].item_id);
      ASSERT_TRUE(it != dict.end());
    }

    std::vector<uint64> sim_ids_in_hbase;
    ASSERT_TRUE(get_sim.GetSimItem(item_id, &sim_ids_in_hbase));
    ASSERT_EQ(sim_ids.size(), sim_ids_in_hbase.size());

    std::unordered_map<uint64, int> dict2;
    for (size_t j = 0; j < sim_ids.size(); ++j) {
      dict2[sim_ids[j]] = j;
    }

    for (size_t j = 0; j < sim_ids.size(); ++j) {
      auto it = dict2.find(sim_ids_in_hbase[j]);
      ASSERT_TRUE(it != dict2.end());
    }
  }
}
}
