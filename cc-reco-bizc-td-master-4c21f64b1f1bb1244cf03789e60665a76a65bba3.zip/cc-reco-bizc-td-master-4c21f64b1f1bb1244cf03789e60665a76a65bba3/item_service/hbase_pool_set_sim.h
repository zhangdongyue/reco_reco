#pragma once

#include <string>
#include <vector>
#include "base/common/base.h"
#include "base/testing/gtest_prod.h"
#include "reco/bizc/item_service/define.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

namespace reco {

// NOTE: thread safe
class HBasePoolSetSim {
 public:
  explicit HBasePoolSetSim(std::string table);
  ~HBasePoolSetSim();

  bool SetSim(uint64 item_id, const std::vector<SimResult>& sim_result);

  // old value usage
  bool SetSim(uint64 item_id, const std::vector<uint64>& sim_result);

 private:
  static const int kRetryTimes = 3;

  std::string table_;

  static std::string kFamily;
  static std::string kColumn;
  static std::string kColumnOld;
};
}  // namespace reco

