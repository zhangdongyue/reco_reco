#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include "base/common/base.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/sleep.h"
#include "reco/bizc/proto/item.pb.h"
#include "base/common/gflags.h"
#include "reco/base/hbase_c/api/hbase_client.h"

namespace reco {
namespace hbase {
class HBaseCli;
}  // namespace hbase
// NOTE: not thread safe
class HBaseGetItemAttr {
 public:
  // cache size: lru cache size, set to <=0 will not use cache
  explicit HBaseGetItemAttr(const std::string& hbase_table_name);
  ~HBaseGetItemAttr();

  template<typename T>
  bool GetItemAttr(uint64 item_id, int attr_enum, T* result);

  template<typename T>
  void GetItemAttr(const std::vector<uint64>& item_ids, int attr_enum,
                   std::vector<bool>* rets, std::vector<T>* result);

  bool GetItemAttr(uint64 item_id, int attr_enum, std::string* result);

  void GetItemAttr(const std::vector<uint64>& item_ids, int attr_enum,
                   std::vector<bool>* rets, std::vector<std::string>* result);

  bool GetItemAttr(uint64 item_ids, int attr_enum, bool* result);

  void GetItemAttr(const std::vector<uint64>& item_ids, int attr_enum,
                   std::vector<bool>* rets, std::vector<bool>* result);

  void GetAllAttr(uint64 item_id, std::vector<bool>* rets, std::vector<std::string>* result);
 private:
  void GetRawResult(const std::vector<std::string>& row_keys,
                    std::vector<bool>* rets,
                    std::vector<std::string>* result);

  std::string table_name_;
  int attr_num_;
};

template<typename T>
bool HBaseGetItemAttr::GetItemAttr(uint64 item_id, int attr_enum, T* result) {
  std::vector<uint64> item_ids;
  item_ids.push_back(item_id);

  std::vector<T> results;
  std::vector<bool> rets;
  GetItemAttr(item_ids, attr_enum, &rets, &results);

  if (rets[0]) {
    result->Swap(&(results[0]));
  }
  return rets[0];
}

template<typename T>
void HBaseGetItemAttr::GetItemAttr(const std::vector<uint64>& item_ids, int attr_enum,
                                   std::vector<bool>* rets, std::vector<T>* result) {
  std::vector<std::string> result_str;
  GetItemAttr(item_ids, attr_enum, rets, &result_str);
  CHECK_EQ(rets->size(), result_str.size());
  CHECK_EQ(item_ids.size(), result_str.size());

  result->resize(result_str.size());
  for (size_t i = 0; i < result_str.size(); ++i) {
    if (!rets->at(i)) continue;

    if (!result->at(i).ParseFromString(result_str[i])) {
      LOG(ERROR) << base::StringPrintf("false for parseing proto for item: %lu, attr enum=%d",
                                       item_ids[i], attr_enum);
      rets->at(i) = false;
    }
  }
}
}  // namespace reco
