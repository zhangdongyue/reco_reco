#pragma once

#include <string>
#include <vector>
#include <map>
#include "base/common/base.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/define.h"
#include "base/common/gflags.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/sync.h"
#include "base/common/closure.h"
#include "base/time/timestamp.h"

namespace reco {

// NOTE: thread safe
class HBasePoolGetSim {
 public:
  // cache size: lru cache size, set to <=0 will not use cache
  explicit HBasePoolGetSim(const std::string& hbase_table_name);
  ~HBasePoolGetSim();

  // 获取一条 sim 记录，获取不到返回 false,
  bool GetSimItem(uint64 item_id, std::vector<uint64>* sims);

  // 获取一批 sim 记录，每条是否成功获取在 rets 中指明
  void GetSimItems(const std::vector<uint64>& item_ids, std::vector<bool>* rets,
                   std::vector<std::vector<uint64> >* sims);

  // 接口接受 string 数组，如果 parse uint64 失败，对应的 rets 元素为 false
  void GetSimItems(const std::vector<std::string>& item_str_ids, std::vector<bool>* rets,
                    std::vector<std::vector<uint64>>* sims);

  // 获取一条 sim 记录，获取不到返回 false
  bool GetSimItem(uint64 item_id, std::vector<SimResult>* sims);

  // 获取一条 sim 记录，获取不到返回 false,
  bool GetSimItemByFingerPrint(uint64 item_id, std::vector<SimResult>* sims);
  void GetSimItemsByFingerPrint(const std::vector<uint64>& item_ids, std::vector<bool>* rets,
                                std::vector<std::vector<SimResult> >* sim_matrix);


  // 获取一批 sim 记录，每条是否成功获取在 rets 中指明
  void GetSimItems(const std::vector<uint64>& item_ids, std::vector<bool>* rets,
                   std::vector<std::vector<SimResult> >* sims);
  // 获取 sim 及 parent
  void GetSimItemsAndParent(const std::vector<uint64>& item_ids, std::vector<bool>* rets,
                            std::vector<std::vector<SimResult> >* sims, std::vector<uint64>* parent_vec);

  // 接口接受 string 数组，如果 parse uint64 失败，对应的 rets 元素为 false
  void GetSimItems(const std::vector<std::string>& item_str_ids, std::vector<bool>* rets,
                    std::vector<std::vector<SimResult> >* sims);

  // 获取 parent id, 获取不到返回 false,
  bool GetParentId(uint64 item_id, uint64* parent_id);

  void GetRowMap(const std::vector<std::string>& item_keys,
                 std::map<std::string, std::map<std::string, std::string> >* row_map);

  std::string table_name_;
};
}  // namespace reco
