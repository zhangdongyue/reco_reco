#include "reco/bizc/item_service/item_keeper_get_item.h"
#include <string>
#include <vector>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "net/rpc_util/rpc_group.h"

namespace reco {
ItemKeeperGetItem::ItemKeeperGetItem(const std::string& item_keeper_ips, int item_keeper_port) {
  InitConnect(item_keeper_ips, item_keeper_port);
}

ItemKeeperGetItem::ItemKeeperGetItem(const std::string& item_keeper_ips, int item_keeper_port, int cache_size)
  : BaseGetItem(cache_size) {
  InitConnect(item_keeper_ips, item_keeper_port);
}

ItemKeeperGetItem::~ItemKeeperGetItem() {
  delete rpc_stub_;
  delete rpc_group_;
}

void ItemKeeperGetItem::InitConnect(const std::string& item_keeper_ips, int item_keeper_port) {
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = kRpcTimeout;
  std::vector<std::string> flds;
  base::SplitString(item_keeper_ips, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], item_keeper_port, kRpcTimeout);
    options.servers.push_back(si);
  }

  rpc_group_ = new net::rpc::RpcGroup(options);
  CHECK(rpc_group_->Connect());
  rpc_stub_ = new reco::itemkeeper::ItemKeeper::Stub(rpc_group_);
}

void ItemKeeperGetItem::GetRecoItemsImpl(const std::vector<uint64>& item_ids,
                                         std::vector<reco::RecoItem>* reco_items) {
  reco::itemkeeper::GetRecoItemRequest request;
  for (size_t i = 0; i < item_ids.size(); ++i) {
    const uint64 id = item_ids[i];
    RecoItem item;
    if (!ReadCache(id, &item)) {
      request.add_item_id(id);
    } else {
      reco_items->push_back(item);
    }
  }

  if (request.item_id_size() == 0) {
    return;
  }

  net::rpc::RpcClientController controller;
  controller.SetTimeout(kRpcTimeout);
  reco::itemkeeper::GetRecoItemResponse response;
  rpc_stub_->getRecoItem(&controller, &request, &response, NULL);
  controller.Wait();
  if (controller.status() != net::rpc::RpcController::kOk) {
    LOG(ERROR) << "get reco item failed: " << controller.error_text();
    return;
  }

  for (int i = 0; i < response.reco_item_size(); ++i) {
    reco_items->push_back(response.reco_item(i));
    WriteCache(response.reco_item(i).identity().item_id(),
               response.reco_item(i));
  }
}
}  // namespace reco

