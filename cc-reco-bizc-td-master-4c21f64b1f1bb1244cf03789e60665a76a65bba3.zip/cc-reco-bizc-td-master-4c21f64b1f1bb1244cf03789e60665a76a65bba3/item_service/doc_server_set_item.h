#pragma once

#include <string>
#include <vector>
#include "base/common/base.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/reco_doc_server.pb.h"

namespace net {
namespace rpc {
class RpcGroup;
}
}

namespace reco {

// NOTE: not thread safe
class DocServerSetItem {
 public:
  DocServerSetItem(const std::string& doc_server_ips, int doc_server_port);
  ~DocServerSetItem();

  // 写入一条 reco item 记录，设置不成功返回 false,
  // NOTE：内部会调用 reco_item 的 Isvalid 检查，不通过会 CHECK
  bool SetRecoItem(const reco::RecoItem& reco_item);

 private:
  std::vector<net::rpc::RpcGroup*> rpc_groups_;
  std::vector<reco::docserver::RecoDocService::Stub*> rpc_stubs_;
};
}  // namespace reco

