#pragma once

#include <string>
#include <vector>
#include <algorithm>
#include "base/common/base.h"
#include "reco/bizc/proto/item.pb.h"
#include "base/container/lru_cache.h"
#include "base/strings/string_number_conversions.h"

namespace reco {

// NOTE: not thread safe
class BaseGetItem {
 public:
  // doc_server_ips, multiple ip joined by ","
  // cache size: lru cache size, set to <=0 will not use cache
  BaseGetItem() {
    cache_ = NULL;
  }

  explicit BaseGetItem(int cache_size) {
    cache_ = NULL;
    if (cache_size > 0) {
      cache_ = new base::LRUCache<uint64, reco::RecoItem>(cache_size, false);
    }
  }

  virtual ~BaseGetItem() {
    if (cache_) {
      delete cache_;
    }
  }

  // 获取一条 reco item 记录，获取不到返回 false,
  // clear_raw_item 是否清空 RecoItem 里包含的 RawItem 域
  // 底层 rpc 协议里默认是会清空 RawItem 的以节省带宽，因此需要加控制
  virtual bool GetRecoItem(uint64 item_id, reco::RecoItem* reco_item) {
    std::vector<uint64> item_ids;
    item_ids.push_back(item_id);

    std::vector<reco::RecoItem> reco_items;
    GetRecoItems(item_ids, &reco_items);
    if (!reco_items.empty()) {
      reco_item->Swap(&(reco_items[0]));
      return true;
    } else {
      return false;
    }
  }

  // 获取一批 reco item 记录，每条是否成功获取在 rets 中指明
  // NOTE: item_ids 与 reco item 不保证一一对应
  virtual void GetRecoItems(const std::vector<uint64>& item_ids, std::vector<reco::RecoItem>* reco_items) {
    std::vector<uint64> ids(item_ids);
    std::sort(ids.begin(), ids.end());
    auto last = std::unique(ids.begin(), ids.end());
    ids.erase(last, ids.end());
    if (ids.size() > reco_items->size()) {
      reco_items->reserve(ids.size());
    }

    std::vector<uint64> step;
    step.reserve(kBatchSize);
    for (size_t i = 0; i < ids.size(); i += kBatchSize) {
      size_t j = std::min(i + kBatchSize, ids.size());
      // LOG(INFO) << i << "," << j << "," << ids.size();
      step.clear();
      step.assign(ids.begin() + i, ids.begin() + j);
      GetRecoItemsImpl(step, reco_items);
      // LOG(INFO) << step.size() << "," << reco_items->size();
    }
  }

  // 接口接受 string 数组，如果 parse uint64 失败，对应的 rets 元素为 false
  // NOTE: item_ids 与 reco item 不保证一一对应
  virtual void GetRecoItems(const std::vector<std::string>& item_str_ids,
                            std::vector<reco::RecoItem>* reco_items) {
    std::vector<uint64> item_ids(item_str_ids.size(), 0);
    for (size_t i = 0; i < item_str_ids.size(); ++i) {
      uint64 id = 0;
      if (base::StringToUint64(item_str_ids[i], &id)) {
        item_ids[i] = id;
      }
    }
    GetRecoItems(item_ids, reco_items);
  }

 protected:
  bool ReadCache(const uint64 item_id, reco::RecoItem* reco_item) {
    if (cache_ != NULL) {
      return cache_->Get(item_id, reco_item);
    } else {
      return false;
    }
  }

  void WriteCache(const uint64 item_id, const reco::RecoItem& reco_item) {
    if (cache_) {
      cache_->Add(item_id, reco_item);
    }
  }

  virtual void GetRecoItemsImpl(const std::vector<uint64>& item_ids,
                                std::vector<reco::RecoItem>* reco_items) = 0;
 protected:
  static const int kBatchSize = 10;
  base::LRUCache<uint64, reco::RecoItem>* cache_;
};
}  // namespace reco

