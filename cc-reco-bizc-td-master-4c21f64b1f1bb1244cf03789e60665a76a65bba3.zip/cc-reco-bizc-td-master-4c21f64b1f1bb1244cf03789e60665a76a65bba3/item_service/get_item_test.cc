#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/define.h"
#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "base/common/base.h"
#include "base/time/time.h"
#include "base/time/scoped_timer.h"
#include "base/random/pseudo_random.h"
#include "base/hash_function/term.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/common/sleep.h"

namespace reco {
namespace hbase {
DECLARE_string(hbase_thrift_ips);
DECLARE_int32(hbase_pool_size);
}
}

DEFINE_string(doc_server_ips, "11.251.203.139", "host of doc server");
DEFINE_int32(doc_server_port, 20013, "port doc server");
DEFINE_string(item_keeper_ips, "11.251.202.129", "item keeper");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");
DEFINE_string(reco_item_table, "tb_reco_item", "table name");

class ItemServiceTest : public testing::Test {
 public:
  void SetUp() {
    reco::hbase::FLAGS_hbase_thrift_ips = "11.251.181.33:9090,11.251.181.38:9090,11.251.181.42:9090,11.251.181.48:9090,"  // NOLINT
        "11.251.183.81:9090,11.251.183.82:9090,11.251.183.83:9090,11.251.183.104:9090,"
        "11.251.183.106:9090,11.251.183.107:9090";
    reco::hbase::FLAGS_hbase_pool_size = 10;

    static struct {
      uint64 item_id;
      bool succ;
    } cases[] = {
      {1, false},
      {2, false},
      {3, false},
      {1863284743212515685ul, true},
      {17805552226828101825ul, true},
      {18093579027701629643ul, true},
      {4120653118779463642ul, true},
      {16184372969513220041ul, true},
      {3678617542170916855ul, true},
      {5366996860010298290ul, true},
      {17877336524401949575ul, true},
      {1277326626121698444ul, true},
      {8102934211704513602ul, true},
    };
    // 每个 case 被重复 3 次
    for (int i = 0; i < (int)ARRAYSIZE_UNSAFE(cases); ++i) {
      cases_.push_back(std::make_pair(cases[i].item_id, cases[i].succ));
      cases_.push_back(std::make_pair(cases[i].item_id, cases[i].succ));
      cases_.push_back(std::make_pair(cases[i].item_id, cases[i].succ));
    }

    ds_get_item_ = new reco::DocServerGetItem(FLAGS_doc_server_ips, FLAGS_doc_server_port);
    ds_get_item_cache_ = new reco::DocServerGetItem(FLAGS_doc_server_ips,
                                                    FLAGS_doc_server_port, 1000);
    ik_get_item_ = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips, FLAGS_item_keeper_port);
    ik_get_item_cache_ = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips,
                                                    FLAGS_item_keeper_port, 1000);
    hb_get_item_ = new reco::HBaseGetItem(FLAGS_reco_item_table);
    hb_get_item_cache_ = new reco::HBaseGetItem(FLAGS_reco_item_table, 1000);
  }

  void TearDown() {
    delete ds_get_item_;
    delete ds_get_item_cache_;
    delete ik_get_item_;
    delete ik_get_item_cache_;
    delete hb_get_item_;
    delete hb_get_item_cache_;
  }

  std::vector<std::pair<uint64, bool>> cases_;
  reco::DocServerGetItem* ds_get_item_;
  reco::DocServerGetItem* ds_get_item_cache_;
  reco::ItemKeeperGetItem* ik_get_item_;
  reco::ItemKeeperGetItem* ik_get_item_cache_;
  reco::HBaseGetItem* hb_get_item_;
  reco::HBaseGetItem* hb_get_item_cache_;
};

TEST_F(ItemServiceTest, GetItem) {
  reco::RecoItem reco_item;
  std::vector<uint64> item_ids;
  std::vector<std::string> item_id_strs;
  std::vector<reco::RecoItem> reco_items;

  for (int iter = 0; iter < 6; ++iter) {
    reco::BaseGetItem* get_item = NULL;
    switch (iter) {
      case 0:
        get_item = ds_get_item_;
        break;
      case 1:
        get_item = ds_get_item_cache_;
        break;
      case 2:
        get_item = ik_get_item_;
        break;
      case 3:
        get_item = ik_get_item_cache_;
        break;
      case 4:
        get_item = hb_get_item_;
        break;
      case 5:
        get_item = hb_get_item_cache_;
        break;
      default:
        ASSERT_TRUE(false);
        break;
    }
    // test GetRecoItem(uint64 item_id, reco::RecoItem* reco_item, bool clear_raw_item)
    for (size_t i = 0; i < cases_.size(); ++i) {
      uint64 item_id = cases_[i].first;
      ASSERT_EQ(cases_[i].second, get_item->GetRecoItem(item_id, &reco_item)) << iter;
    }

    item_ids.clear();
    item_id_strs.clear();
    for (size_t i = 0; i < cases_.size(); ++i) {
      uint64 item_id = cases_[i].first;
      item_ids.push_back(item_id);
      item_id_strs.push_back(base::Uint64ToString(item_id));
    }

    double time_elapsed;
    {
      base::ScopedTimer scoped_timer(&time_elapsed);
      // test GetRecoItems vector of uint64
      reco_items.clear();
      get_item->GetRecoItems(item_ids, &reco_items);
      ASSERT_EQ(10u, reco_items.size()) << iter;
      // test GetRecoItems vector of string
      reco_items.clear();
      get_item->GetRecoItems(item_id_strs, &reco_items);
      ASSERT_EQ(10u, reco_items.size()) << iter;
    }
    LOG(INFO) << "iter: " << iter << " cost " << time_elapsed;
  }
}

