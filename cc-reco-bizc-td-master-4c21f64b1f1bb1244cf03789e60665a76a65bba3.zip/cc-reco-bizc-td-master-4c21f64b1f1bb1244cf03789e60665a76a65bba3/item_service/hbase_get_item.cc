#include "reco/bizc/item_service/hbase_get_item.h"

#include <map>
#include <string>
#include <vector>
#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

namespace reco {

HBaseGetItem::HBaseGetItem(const std::string& hbase_table_name) {
  table_name_ = hbase_table_name;
  reco::hbase::HBasePoolIns::instance().Init();
}

HBaseGetItem::HBaseGetItem(const std::string& hbase_table_name, int cache_size)
  : BaseGetItem(cache_size) {
  table_name_ = hbase_table_name;
  reco::hbase::HBasePoolIns::instance().Init();
}

HBaseGetItem::~HBaseGetItem() {
}

void HBaseGetItem::GetRecoItemsImpl(const std::vector<uint64>& item_ids,
                                std::vector<reco::RecoItem>* reco_items) {
  std::vector<std::string> item_keys;
  for (size_t i = 0; i < item_ids.size(); ++i) {
    const uint64 id = item_ids[i];
    RecoItem item;
    if (!ReadCache(id, &item)) {
      item_keys.push_back(base::Uint64ToString(id));
    } else {
      reco_items->push_back(item);
    }
  }

  if (item_keys.empty()) {
    return;
  }

  std::map<std::string, std::map<std::string, std::string> > row_map;
  int retry = 0;
  while (retry++ < 2) {
    reco::hbase::HBaseAutoCli cli(10);
    if (!cli.Get()) {
      continue;
    }

    if (cli.Get()->BatchGetByKeys(table_name_, item_keys, &row_map)) {
      break;
    } else {
      LOG(WARNING) << "get item from hbase failed!";
      continue;
    }
  }

  for (auto it = row_map.begin(); it != row_map.end(); ++it) {
    auto it2 = it->second.find("data:proto");
    if (it2 == it->second.end()) {
      continue;
    }
    RecoItem item;
    if (!item.ParseFromString(it2->second)) {
      continue;
    }

    reco_items->push_back(item);
    WriteCache(item.identity().item_id(), item);
  }
}
}  // namespace reco

