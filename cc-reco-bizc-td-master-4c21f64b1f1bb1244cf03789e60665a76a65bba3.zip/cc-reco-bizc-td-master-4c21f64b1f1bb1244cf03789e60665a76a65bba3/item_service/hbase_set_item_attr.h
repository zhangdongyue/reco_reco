#pragma once

#include <string>
#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "base/testing/gtest_prod.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/define.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/common/sleep.h"

namespace reco {
namespace hbase {
class HBaseCli;
}  // namespace hbase

// NOTE: not thread safe
class HBaseSetItemAttr {
 public:
  explicit HBaseSetItemAttr(const std::string& hbase_table_name);
  ~HBaseSetItemAttr();

  bool SetItemAttr(uint64 item_id, int attr_enum, bool value);
  bool SetItemAttr(uint64 item_id, int attr_enum, const std::string& value);
  template<typename T> bool SetItemAttr(uint64 item_id, int attr_enum, const T& value);

 private:
  static const int kRetryTimes = 3;
  static const int kReconnectTimes = 10;
  static const std::string kTrue;
  static const std::string kFalse;

  std::string table_name_;
  int attr_num_;
  FRIEND_TEST(ContentAttrTest, HBaseSet);
};

inline bool HBaseSetItemAttr::SetItemAttr(uint64 item_id, int attr_enum, bool value) {
  return SetItemAttr(item_id, attr_enum, value?kTrue:kFalse);
}

inline bool HBaseSetItemAttr::SetItemAttr(uint64 item_id, int attr_enum, const std::string& value) {
  if (attr_enum < 0 || attr_enum >= attr_num_) {
    LOG(ERROR) << "erro attr enum: " << attr_enum;
    return false;
  }

  std::string row_key = base::StringPrintf("%lu_%s", item_id, reco::item_attr::kAllSuffix[attr_enum]);

  int retry = 0;
  bool succ = false;
  while (retry++ < kRetryTimes) {
    reco::hbase::HBaseAutoCli cli = reco::hbase::HBaseAutoCli(10);
    reco::hbase::HBaseCli* client = cli.Get();
    if (client == NULL) {
      continue;
    }
    if (client->Insert(table_name_, row_key, "data", "machine", value)) {
      succ = true;
      break;
    } else {
      continue;
    }
  }
  return succ;
}

template<typename T>
bool HBaseSetItemAttr::SetItemAttr(uint64 item_id, int attr_enum, const T& value) {
  CHECK(value.IsInitialized());

  std::string str;
  CHECK(value.SerializeToString(&str));

  return SetItemAttr(item_id, attr_enum, str);
}
}  // namespace reco

