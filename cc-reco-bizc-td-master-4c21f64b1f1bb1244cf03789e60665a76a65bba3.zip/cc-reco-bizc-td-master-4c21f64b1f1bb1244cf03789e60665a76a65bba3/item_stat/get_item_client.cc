#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/item_stat/hbase_item_stat.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/file/file_util.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

#include "reco/base/hbase_c/api/hbase_client_pool.h"

DEFINE_string(hbase_table, "tb_item_statistics", "hbase table");

DEFINE_string(item_id, "", "");
DEFINE_string(item_id_file, "", "");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");

  std::string line;
  std::string key;
  std::string value;
  std::vector<std::string> flds;

  reco::hbase::HBasePoolIns::instance().Init();

  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }

  reco::item_stat::HBaseItemStat item_stat;

  std::set<uint64> id_set;
  for (int i = 0; i < (int)item_id_list.size(); ++i) {
    uint64 item_id = base::ParseUint64OrDie(item_id_list[i]);
    id_set.insert(item_id);

    float score;
    if (!item_stat.GetItemScore(item_id, &score)) {
      LOG(ERROR) << "get item stat failed: " << item_id;
    }
    std::cout << item_id << "\t" << score << std::endl;
  }

  std::unordered_map<uint64, float> score_map;
  LOG(INFO) << item_stat.GetItemScores(id_set, &score_map);
  for (auto it = score_map.begin(); it != score_map.end(); ++it) {
    std::cout << it->first << "\t" << it->second << std::endl;
  }


}
