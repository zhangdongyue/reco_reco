#include "reco/bizc/item_stat/hbase_item_stat.h"
#include "base/container/lru_cache.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"
#include "extend/json/jansson/jansson.h"

namespace reco {
namespace item_stat {

DEFINE_string(item_stat_table, "tb_item_statistics", "");

HBaseItemStat::HBaseItemStat() {
  reco::hbase::HBaseAutoCli cli = reco::hbase::HBaseAutoCli(10);
  CHECK(cli.Get() != NULL) << "hbase connect pool not init";
}

bool HBaseItemStat::ParseStat(const std::map<std::string, std::string>& str_map,
                              int* show, int* click, int* dislike, int* share, int* fav) {
  *show = 0;
  *click = 0;
  *dislike = 0;
  *share = 0;
  *fav = 0;

  auto it = str_map.find("data:show_count");
  if (it != str_map.end()) {
    GetShowCount(it->second, show);
  }
  
  it = str_map.find("data:user_action");
  if (it != str_map.end()) {
    GetActionCount(it->second, click, dislike, share, fav);
  }

  return (*show + *click + *dislike + *share + *fav) > 0;
}

bool HBaseItemStat::GetItemScore(uint64 item_id, float* score) {
  ItemAction action;
  if (!GetItemAction(item_id, &action)) {
    return false;
  }

  *score = 0;
  CalcScore(action, score);
  return true;
}

bool HBaseItemStat::GetItemAction(uint64 item_id, ItemAction* item_action) {
  reco::hbase::HBaseAutoCli cli = reco::hbase::HBaseAutoCli(10);
  reco::hbase::HBaseCli* client = cli.Get();
  if (client == NULL) {
    LOG(ERROR) << "get hbase client pool error";
    return false;
  }
  std::map<std::string, std::string> str_map;
  client->GetByKey(FLAGS_item_stat_table, base::Uint64ToString(item_id), &str_map);

  return ParseStat(str_map,
            &(item_action->show),
            &(item_action->click),
            &(item_action->dislike),
            &(item_action->share),
            &(item_action->fav));
}

int HBaseItemStat::GetItemScores(const std::set<uint64>& item_id_set,
                                 std::unordered_map<uint64, float>* score_map) {
  static const size_t kBatchSize = 1000;
  std::vector<std::string> keys;
  int total_get = 0;
  for (auto it = item_id_set.begin(); it != item_id_set.end(); ++it) {
    if (keys.size() > kBatchSize) {
      total_get += GetItemScores(keys, score_map);
      keys.clear();
    }
    keys.push_back(base::Uint64ToString(*it));
    LOG_EVERY_N(INFO, 200000) << "item id: " << *it << ", total get: " << total_get;
  }
  if (keys.size() > 0) {
    total_get += GetItemScores(keys, score_map);
  }
  return total_get;
}

int HBaseItemStat::GetItemActions(const std::set<uint64>& item_id_set,
                                 std::unordered_map<uint64, ItemAction>* action_map) {
  static const size_t kBatchSize = 1000;
  std::vector<std::string> keys;
  int total_get = 0;
  for (auto it = item_id_set.begin(); it != item_id_set.end(); ++it) {
    if (keys.size() > kBatchSize) {
      total_get += GetItemActions(keys, action_map);
      keys.clear();
    }
    keys.push_back(base::Uint64ToString(*it));
    LOG_EVERY_N(INFO, 10000) << "item id: " << *it << ", total get: " << total_get;
  }
  if (keys.size() > 0) {
    total_get += GetItemActions(keys, action_map);
  }
  return total_get;
}

int HBaseItemStat::GetItemScores(const std::vector<std::string>& item_id_vec,
                                 std::unordered_map<uint64, float>* score_map) {
  std::unordered_map<uint64, ItemAction> action_map;
  GetItemActions(item_id_vec, &action_map);
  score_map->clear();
  int total_get = 0;
  for (auto it = action_map.begin(); it != action_map.end(); ++it) {
    const ItemAction& action = it->second;
    float score;
    CalcScore(action, &score);
    if (score > 0) {
      ++total_get;
      score_map->insert(std::make_pair(it->first, score));
    }
  }

  return total_get;
}

int HBaseItemStat::GetItemActions(const std::vector<std::string>& item_id_vec,
                                 std::unordered_map<uint64, ItemAction>* action_map) {
  int total_get = 0;
  reco::hbase::HBaseAutoCli cli = reco::hbase::HBaseAutoCli(10);
  reco::hbase::HBaseCli* client = cli.Get();
  if (client == NULL) {
    LOG(ERROR) << "get hbase client pool error";
    return total_get;
  }

  std::map<std::string, std::map<std::string, std::string> > row_map;
  client->BatchGetByKeys(FLAGS_item_stat_table, item_id_vec, &row_map);

  for (auto it = row_map.begin(); it != row_map.end(); ++it) {
    if (it->first.empty()) continue;
    uint64 item_id;
    if (!base::StringToUint64(it->first, &item_id)) {
      LOG(WARNING) << it->first << " is not item id: " << it->first;
      continue;
    }
    ItemAction action;
    if (ParseStat(it->second, &(action.show), &(action.click),
              &(action.dislike), &(action.share), &(action.fav))) {
      action_map->insert(std::make_pair(item_id, action));
      ++total_get;
    }
  }

  return total_get;
}

void HBaseItemStat::GetShowCount(const std::string& json_str, int* show_count) {
  *show_count = 0;
  json_error_t json_error;
  json_t *json = json_loads(json_str.c_str(), &json_error);
  if (json == NULL) {
    LOG(WARNING) << "Failed to load line: " << json_error.line;
    return;
  }

  if (json_array_size(json) != 2) {
    LOG(ERROR) << "not array, " << json_str;
    return;
  }
  json_t* data = json_array_get(json, 1);
  if (!json_is_integer(data)) {
    LOG(WARNING) << "show count json object has no id, json: " << json_str;
    return;
  }

  *show_count = json_integer_value(data);

  json_decref(json);
}

void HBaseItemStat::GetActionCount(const std::string& json_str,
                                   int* click, int* dislike, int* share, int* fav) {
  *click = 0;
  *dislike = 0;
  *share = 0;
  *fav = 0;

  json_error_t json_error;
  json_t *json = json_loads(json_str.c_str(), &json_error);
  if (json == NULL) {
    LOG(WARNING) << "Failed to load line: " << json_error.line;
    return;
  }

  if (json_array_size(json) != 2) {
    LOG(ERROR) << "not array, " << json_str;
    return;
  }
  json_t* obj = json_array_get(json, 1);
  if (!json_is_object(obj)) {
    LOG(WARNING) << "action json is not object, json: " << json_str;
    return;
  }

  json_t* data = json_object_get(obj, "click");
  if (json_integer_value(data)) {
    *click = json_integer_value(data);
  }

  data = json_object_get(obj, "disLike");
  if (json_integer_value(data)) {
    *dislike = json_integer_value(data);
  }

  data = json_object_get(obj, "share");
  if (json_integer_value(data)) {
    *share = json_integer_value(data);
  }

  data = json_object_get(obj, "fav");
  if (json_integer_value(data)) {
    *fav = json_integer_value(data);
  }

  json_decref(json);
}

}  // namespace item_stat
}  // namespace reco

