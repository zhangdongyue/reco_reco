#pragma once

#include <string>
#include <vector>

#include "base/thread/thread.h"
#include "reco/base/common/singleton.h"
#include "reco/base/zkconfig/dynamic_dict.h"
#include "reco/bizc/reco_index/news_index_ha3.h"

namespace reco {
namespace item_stat {

class HBaseItemStat;

class ItemStatCollection {
 public:
  ItemStatCollection();
  ~ItemStatCollection();

  void Run(reco::NewsIndex* news_index);

  void GetItemScore(uint64 item_id, float* score) {
    *score = 0;
    auto dict = item_stat_dict_->GetDict();
    auto it = dict->find(item_id);
    if (it != dict->end()) {
      *score = it->second;
    }
  }

  void GetItemScoreByItemId(int item_id, float* score);

 private:
  void MonitorItemStat();

 private:
  thread::Thread monitor_thread_;

  std::atomic_bool logic_run_;
  reco::NewsIndex *news_index_;

  HBaseItemStat* item_stat_;
  reco::zkconfig::DynamicDict<std::unordered_map<uint64, float>>* item_stat_dict_;

  DISALLOW_COPY_AND_ASSIGN(ItemStatCollection);
};

typedef reco::common::singleton_default<ItemStatCollection> ItemStatCollector;

}  // namespace item_stat
}  // namespace reco
