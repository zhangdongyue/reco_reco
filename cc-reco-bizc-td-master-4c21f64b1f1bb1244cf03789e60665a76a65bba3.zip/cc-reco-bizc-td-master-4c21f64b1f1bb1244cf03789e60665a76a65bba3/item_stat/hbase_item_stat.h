#pragma once

#include <set>
#include <map>
#include <unordered_map>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/testing/gtest_prod.h"

namespace reco {
namespace hbase {
class HBaseCli;
}  // namespace hbase

namespace item_stat {

struct ItemAction {
  ItemAction() {
    show = 0;
    click = 0;
    dislike = 0;
    share = 0;
    fav = 0;
  }

  int32 show;
  int32 click;
  int32 dislike;
  int32 share;
  int32 fav;
};

// NOTE: not thread safe
// 实现 client 访问hbase 相关表
// 没有缓存功能。使用方建议用 item_stat_collection.h
class HBaseItemStat {
 public:
  HBaseItemStat();
  ~HBaseItemStat() {};

  // 获取一条 reco item 记录，获取不到返回 false,
  // score: range [0, 100], -1 if not exist. 
  bool GetItemScore(uint64 item_id, float* score);
  bool GetItemAction(uint64 item_id, ItemAction* item_action);

  int GetItemScores(const std::set<uint64>& item_id_set,
                    std::unordered_map<uint64, float>* score_map);
  int GetItemActions(const std::set<uint64>& item_id_set,
                     std::unordered_map<uint64, ItemAction>* action_map);

  int GetItemScores(const std::vector<std::string>& item_id_vec,
                    std::unordered_map<uint64, float>* score_map);
  int GetItemActions(const std::vector<std::string>& item_id_vec,
                     std::unordered_map<uint64, ItemAction>* action_map);

  static void GetShowCount(const std::string& json_str, int* show_count);
  static void GetActionCount(const std::string& json_str, int* click, int* dislike, int* share, int* fav);

 private:
  static bool ParseStat(const std::map<std::string, std::string>& str_map,
                        int* show, int *click, int* dislike, int* share, int* fav);

  static bool CalcScore(int show, int click, int dislike, int share, int fav, float* score) {
    *score = double(click) / double(show + 1);
    return *score > 0;
  }
  static bool CalcScore(const ItemAction& action, float* score) {
    return CalcScore(action.show, action.click, action.dislike, action.share, action.fav, score);
  }

  std::string table_name_;
};
}  // namespace item_stat
}  // namespace reco
