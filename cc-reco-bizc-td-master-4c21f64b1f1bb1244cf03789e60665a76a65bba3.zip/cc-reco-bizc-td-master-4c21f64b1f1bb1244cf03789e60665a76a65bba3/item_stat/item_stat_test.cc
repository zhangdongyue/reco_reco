#include "reco/bizc/item_stat/hbase_item_stat.h"
#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "base/common/base.h"
#include "base/time/time.h"

namespace reco {
namespace item_stat {

TEST(ItemStatTest, ParseJson) {
  std::string str = "[3061356,{\"share\":10,\"duration\":845124,\"fav\":12,\"disLike\":204,\"event_time\":1440140870555000,\"click\":25676}]";
  int share, fav, dislike, click;
  HBaseItemStat::GetActionCount(str, &click, &dislike, &share, &fav);
  ASSERT_EQ(share, 10);
  ASSERT_EQ(fav, 12);
  ASSERT_EQ(dislike, 204);
  ASSERT_EQ(click, 25676);

  str = "[1888408,2637275]";
  int show;
  HBaseItemStat::GetShowCount(str, &show);
  ASSERT_EQ(show, 2637275);
}

}  // namespace item_stat
}  // namespace reco
