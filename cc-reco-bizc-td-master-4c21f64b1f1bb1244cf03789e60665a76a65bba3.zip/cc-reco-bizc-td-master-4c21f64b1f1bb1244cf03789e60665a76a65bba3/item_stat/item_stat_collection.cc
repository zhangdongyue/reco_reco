#include "reco/bizc/item_stat/item_stat_collection.h"

#include "reco/bizc/item_stat/hbase_item_stat.h"
#include "base/time/time.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

DEFINE_int32(update_stat_interval_second, -1, "stat 更新线程运行的时间间隔(秒), 设为 -1 不运行此线程");

namespace reco {
namespace item_stat {

ItemStatCollection::ItemStatCollection() {
  logic_run_ = false;
  news_index_ = NULL;

  item_stat_dict_ = new reco::zkconfig::DynamicDict<std::unordered_map<uint64, float>>();
}

ItemStatCollection::~ItemStatCollection() {
  news_index_ = NULL;
  if (logic_run_) {
    logic_run_ = false;
    monitor_thread_.Join();
    delete item_stat_;
  }

  delete item_stat_dict_;
}

void ItemStatCollection::Run(reco::NewsIndex* news_index) {
  CHECK_NOTNULL(news_index);

  if (!logic_run_ && FLAGS_update_stat_interval_second > 0) {
    logic_run_ = true;
    reco::hbase::HBasePoolIns::instance().Init();
    item_stat_ = new HBaseItemStat();
    monitor_thread_.Start(NewCallback(this, &ItemStatCollection::MonitorItemStat));
    news_index_ = news_index;
  }
  return;
}

void ItemStatCollection::MonitorItemStat() {
  while (logic_run_) {
    LOG(INFO) << "update loop begins to run";

    int min_doc = news_index_->MinDocLocalId();
    int max_doc = news_index_->MaxDocLocalId();

    boost::shared_ptr<std::unordered_map<uint64, float>> shared_pt(new std::unordered_map<uint64, float>());

    std::set<uint64> item_id_set;
    for (auto doc_id = max_doc; doc_id >= min_doc; --doc_id) {
      uint64 item_id;
      if (!news_index_->GetItemIdByItemId(item_id, &item_id)
          || !news_index_->IsValidByItemId(item_id)) {
        continue;
      }
      item_id_set.insert(item_id);
    }

    int total = item_stat_->GetItemScores(item_id_set, shared_pt.get());
    LOG(INFO) << item_id_set.size() << " index items, got stat: " << total;
    item_stat_dict_->Swap(shared_pt);

    base::SleepForSeconds(FLAGS_update_stat_interval_second);
  }  // while
}

void ItemStatCollection::GetItemScoreByItemId(int item_id, float* score) {
  *score = 0;
  uint64 item_id;
  if (news_index_->GetItemIdByItemId(item_id, &item_id)) {
    GetItemScore(item_id, score);
  }
}

}  // namespace item_stat
}  // namespace reco
