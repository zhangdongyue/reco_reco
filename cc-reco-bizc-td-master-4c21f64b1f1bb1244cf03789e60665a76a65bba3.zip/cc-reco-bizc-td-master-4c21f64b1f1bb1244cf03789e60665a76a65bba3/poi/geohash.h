#pragma once
#include <string>
#include <vector>
#include "base/common/base.h"
#include "base/common/logging.h"

namespace reco {
namespace poi {
struct GeoCoord {
  GeoCoord() {
    latitude = 0;
    longitude = 0;
    north = 0;
    east = 0;
    south = 0;
    west = 0;
  }
  GeoCoord(double lat, double lng,
           double n, double e, double s, double w) {
    latitude = lat;
    longitude = lng;
    north = n;
    east = e;
    south = s;
    west = w;
  }
  double latitude;
  double longitude;

  double north;
  double east;
  double south;
  double west;
};

enum Direction {
  kNorth  = 0,
  kEast = 1,
  kSouth = 2,
  kWest = 3,
};

class GeoHash {
 public:
  GeoHash() {}
  ~GeoHash() {}

  // Creates a the hash at the specified precision. If precision is set to 0.
  // or less than it defaults to 12.
  static bool Encode(double latitude, double longitude, int precision, std::string *hash_value);

  // Get the latitude and longitude used to create the hash along with
  // the bounding box for the encoded coordinate.
  static bool Decode(const std::string &hash_value, GeoCoord *geo_coord);

  // Get array of geohashes that represent the neighbors of the passed
  // in value. The neighbors are indexed as followed:
  // N, NE, E, SE, S, SW, W, NW
  static bool GetNeighbors(const std::string &hash, std::vector<std::string> *neighbors);

  // 两点间， 在地球表面的直达距离（不考虑障碍物） ， 单位 千米
  static double GetDistance(double lat1, double lng1, double lat2, double lng2);

 private:
  static bool GetNeighbor(const std::string &hash, Direction direction, std::string *neighbor);

 private:
  static const double kMaxLatitude;
  static const double kMinLatitude;
  static const double kMaxLongitude;
  static const double kMinLongitude;

  static const std::string kEvenBorders[];
  static const std::string kOddBorders[];
  static const std::string kEvenNeighbors[];
  static const std::string kOddNeighbors[];

  static const std::string kCharMap;

  static const double EARTH_RADIUS;
  static const double kPi;
};
}
}
