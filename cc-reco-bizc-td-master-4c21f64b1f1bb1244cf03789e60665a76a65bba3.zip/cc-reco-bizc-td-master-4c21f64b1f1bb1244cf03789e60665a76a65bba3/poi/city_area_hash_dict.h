#pragma once
#include "reco/base/common/atomic.h"
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include "base/common/base.h"
#include "reco/base/common/singleton.h"
#include "base/thread/sync.h"
#include "reco/bizc/proto/item.pb.h"

namespace wolong {
namespace common {
class Location;
}
}

namespace reco {
namespace poi {
struct AreaBaseInfo {
  std::string area_name;
  std::vector<uint32> area_types;
  std::string gaode_area_id;
};

struct AreaInfo {
  AreaInfo() {
    Clear();
  }

  void Clear() {
    province.clear();
    city.clear();
    district.clear();
    area.clear();
    district_id = 0;
    area_id = 0;
  }

  // 省名, 如 浙江
  std::string province;
  // 城市名，如 杭州
  std::string city;
  // 区名，如 海淀
  std::string district;
  // 商圈名, 如 五道口
  std::string area;

  int64 district_id;
  int64 area_id;
};

class CityAreaHashDict {
 public:
  CityAreaHashDict() {}
  explicit CityAreaHashDict(const std::string &data_dir);
  ~CityAreaHashDict();

  // 载入词表
  bool Load(const std::string &data_dir);
  // 通过经纬度查询商圈信息
  bool GetAreaInfoByCoord(double latitude, double longitude, AreaInfo* area_info);
  // 通过经纬度查询行政区划信息
  bool SearchLocationByCoord(double latitude, double longitude, AreaInfo* area_info);
  // 通过商圈 ID 查询商圈信息
  bool GetAreaBaseInfoByAreaID(int64 area_id, AreaBaseInfo* area_base_info);
  // 通过行政区划 ID 查询 行政区划名称
  bool GetAdminNameByID(int64 id, std::string *name);
  // bool GetAreaNameByID(int64 id, std::string *name);

  // 获取附近的商圈
  bool GetNeighborAreaInfoByCoord(double latitude, double longitude, AreaInfo* area_info);

  // 由行政区划返回气泡坐标
  bool GetAdminCoordinate(int64 admin_id, double *latitude, double *longitude);

  // 由行政区划 id 返回所有子行政区划 id
  bool GetSubAdminIDs(int64 id, std::unordered_set<int64> *sub_ids);

 public:
  // 通过高德 POI 信息获取文章的区县和商圈 ID
  void GetItemAreaID(const reco::GaoDePOI &gaode_poi,
                     std::unordered_set<int64> *area_ids);

  void GetItemAreaID(const reco::GaoDePOI &gaode_poi,
                     std::unordered_set<int64> *area_ids,
                     std::unordered_set<int64> *district_ids);

  void AddAreaIDByPOIInfo(const reco::GaoDePOIInfo &poi_info,
                          std::unordered_set<int64> *area_ids,
                          std::unordered_set<int64> *district_ids);

  int64 GetCityIDByDistrictID(int64 district_id);

  // 是否为直辖市
  static bool IsDirectCity(int64 prov_id) {
    return (prov_id == 110000 || prov_id == 310000 || prov_id == 120000 || prov_id == 500000);
  }

  static int64 TranferToCityID(int64 region_id) {
    int64 district_id = (region_id > 10000000) ? region_id / 100 : region_id;
    int64 prov_id = district_id / 10000 * 10000;
    int64 city_id = IsDirectCity(prov_id) ? prov_id : district_id / 100 * 100;
    return city_id;
  }

 private:
  bool LoadAreaHashFile(const std::string &path);
  bool LoadAreaInfoFile(const std::string &path);
  bool LoadAdminDivisionFile(const std::string &path);
  bool LoadnRegionCodeMappingFile(const std::string &path);
  void UpdateSubAdminDivisionInfo();

 private:
  struct AdminDivisionInfo {
    AdminDivisionInfo() {
      name.clear();
      sub_admin_divisions.clear();
      latitude = -1;
      longitude = -1;
    }
    std::string name;
    std::unordered_set<int64> sub_admin_divisions;
    double latitude;
    double longitude;
  };
  std::unordered_map<std::string, int64> hash_area_id_map_;
  std::unordered_map<int64, AreaBaseInfo> area_id_info_map_;
  std::unordered_map<std::string, int64> gaode_area_id_map_;
  std::unordered_map<int64, AdminDivisionInfo> admin_division_infos_;
  std::unordered_map<uint32, int64> region_code_map_;
  wolong::common::Location *location_searcher_;

  static const std::unordered_set<uint32> kBlackPOIType;
  static std::atomic<bool> is_dict_loaded_;
  static thread::Mutex mutex_;
};

typedef reco::common::singleton_default<CityAreaHashDict> CityAreaHashSearcher;
}
}
