#include "reco/bizc/poi/city_area_hash_dict.h"
#include <iostream>
#include <fstream>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/hash_function/term.h"
#include "wolong/common/location/location.h"
#include "reco/bizc/poi/geohash.h"

namespace reco {
DEFINE_int32(geo_hash_precision, 8, "Geo Hash 算法的精度");

namespace poi {

DEFINE_string(area_hash_file, "all_city_area_hash.txt", "");
DEFINE_string(area_info_file, "all_city_area_info.txt", "");
DEFINE_string(admin_division_file, "administrative_division.txt", "");
DEFINE_string(region_code_mapping_file, "region_code_mapping.txt", "");

std::atomic<bool> CityAreaHashDict::is_dict_loaded_(false);
thread::Mutex CityAreaHashDict::mutex_;
const std::unordered_set<uint32> CityAreaHashDict::kBlackPOIType = {
  1,    // 汽车服务
  2,    // 汽车销售
  3,    // 汽车维修
  4,    // 摩托车服务
  8,    // 体育休闲服务
  9,    // 医疗保健服务
  10,   // 住宿服务
  11,   // 风景名胜
  13,   // 政府机构及社会团体
  14,   // 科教文化服务
  15,   // 交通设施服务
  17,   // 公司企业
};

CityAreaHashDict::CityAreaHashDict(const std::string &data_dir) : location_searcher_(NULL) {
  CHECK(Load(data_dir)) << "load dict fail: " << data_dir;
}

CityAreaHashDict::~CityAreaHashDict() {
  delete location_searcher_;
}

bool CityAreaHashDict::Load(const std::string &data_dir) {
  if (is_dict_loaded_) return true;
  mutex_.Lock();
  const std::string &area_hash_path = data_dir + "/" + FLAGS_area_hash_file;
  const std::string &area_info_path = data_dir + "/" + FLAGS_area_info_file;
  const std::string &admin_division_path = data_dir + "/" + FLAGS_admin_division_file;
  const std::string &region_code_mapping_path = data_dir + "/" + FLAGS_region_code_mapping_file;
  if (!LoadAreaHashFile(area_hash_path) ||
      !LoadAreaInfoFile(area_info_path) ||
      !LoadAdminDivisionFile(admin_division_path) ||
      !LoadnRegionCodeMappingFile(region_code_mapping_path)) {
    return false;
  }
  UpdateSubAdminDivisionInfo();

  location_searcher_ = new wolong::common::Location();
  is_dict_loaded_ = true;
  mutex_.Unlock();
  return true;
}

bool CityAreaHashDict::LoadnRegionCodeMappingFile(const std::string &path) {
  region_code_map_.clear();
  std::ifstream fin(path);
  if (!fin.is_open()) {
    LOG(ERROR) << "open region code mapping file fail: " << path;
    return false;
  }

  std::string line;
  std::vector<std::string> fields;
  int64 region_id;
  while (std::getline(fin, line)) {
    fields.clear();
    base::SplitString(line, "\t", &fields);
    if (fields.size() < 2u) continue;
    const std::string &str_code = fields[0];
    uint32 code = wolong::common::Location::CodeStringToUint32(str_code);
    if (!base::StringToInt64(fields[1], &region_id)) continue;
    region_code_map_[code] = region_id;
  }
  fin.close();
  LOG(INFO) << "load region code mapping file success: " << region_code_map_.size();
  return true;
}

bool CityAreaHashDict::LoadAreaHashFile(const std::string &path) {
  hash_area_id_map_.clear();
  std::ifstream fin(path);
  if (!fin.is_open()) {
    LOG(ERROR) << "open area hash file fail: " << path;
    return false;
  }

  std::string line;
  std::vector<std::string> fields;
  int64 area_id;
  while (std::getline(fin, line)) {
    fields.clear();
    base::SplitString(line, "\t", &fields);
    if (fields.size() < 2u) continue;
    const std::string &hash = fields[0];
    if (!base::StringToInt64(fields[1], &area_id)) continue;
    hash_area_id_map_[hash] = area_id;
  }
  fin.close();
  LOG(INFO) << "load area hash file success: " << hash_area_id_map_.size();
  return true;
}

bool CityAreaHashDict::LoadAreaInfoFile(const std::string &path) {
  area_id_info_map_.clear();
  gaode_area_id_map_.clear();

  std::ifstream fin(path);
  if (!fin.is_open()) {
    LOG(ERROR) << "open area info file fail: " << path;
    return false;
  }

  std::string line;
  std::vector<std::string> fields;
  int64 area_id;
  while (std::getline(fin, line)) {
    fields.clear();
    base::SplitString(line, "\t", &fields);
    if (fields.size() < 4u) continue;
    if (!base::StringToInt64(fields[0], &area_id)) continue;
    const std::string &area_name = fields[1];
    const std::string &area_type = fields[2];
    const std::string &gaode_area_id = fields[3];

    std::vector<std::string> tokens;
    base::SplitString(area_type, "|", &tokens);

    AreaBaseInfo area_info;
    area_info.area_name = area_name;
    area_info.gaode_area_id = gaode_area_id;
    for (size_t i = 0; i < tokens.size(); ++i) {
      uint32 type;
      if (base::StringToUint(tokens[i], &type)) {
        area_info.area_types.push_back(type);
      }
    }
    area_id_info_map_[area_id] = area_info;
    gaode_area_id_map_[gaode_area_id] = area_id;
  }
  fin.close();
  LOG(INFO) << "load area info file success: " << area_id_info_map_.size();
  return true;
}

bool CityAreaHashDict::LoadAdminDivisionFile(const std::string &path) {
  admin_division_infos_.clear();
  std::ifstream fin(path);
  if (!fin.is_open()) {
    LOG(ERROR) << "open admin division file fail: " << path;
    return false;
  }

  std::string line;
  std::vector<std::string> fields;
  int64 id;
  while (std::getline(fin, line)) {
    fields.clear();
    base::SplitString(line, "\t", &fields);
    if (fields.size() < 2u) continue;
    if (!base::StringToInt64(fields[0], &id)) continue;
    std::string &admin_name = fields[1];
    AdminDivisionInfo &admin_info = admin_division_infos_.insert(
        std::make_pair(id, AdminDivisionInfo())).first->second;
    admin_info.name = admin_name;

    if (fields.size() >= 4) {
      double latitude, longitude;
      if (base::StringToDouble(fields[2], &latitude) &&
          base::StringToDouble(fields[3], &longitude)) {
        admin_info.latitude = latitude;
        admin_info.longitude = longitude;
      }
    }
  }
  fin.close();
  LOG(INFO) << "load admin division file success: " << admin_division_infos_.size();
  return true;
}

void CityAreaHashDict::UpdateSubAdminDivisionInfo() {
  for (auto iter = admin_division_infos_.begin(); iter != admin_division_infos_.end(); ++iter) {
    int64 id = iter->first;
    // 省级 id
    if (id % 10000 == 0) continue;
    // 市级 id
    if (id % 100 == 0) {
      int64 prov_id = id / 10000 * 10000;
      auto prov_iter = admin_division_infos_.find(prov_id);
      if (prov_iter == admin_division_infos_.end()) {
        LOG(WARNING) << "prov_id not found: " << id;
        continue;
      }
      prov_iter->second.sub_admin_divisions.insert(id);
    } else {
      // 区县 id
      int64 city_id = id / 100 * 100;
      auto city_iter = admin_division_infos_.find(city_id);
      if (city_iter == admin_division_infos_.end()) {
        LOG(WARNING) << "city_id not found: " << id;
        continue;
      }
      city_iter->second.sub_admin_divisions.insert(id);
    }
  }

  for (auto iter = area_id_info_map_.begin(); iter != area_id_info_map_.end(); ++iter) {
    int64 area_id = iter->first;
    int64 district_id = area_id / 100;
    auto district_iter = admin_division_infos_.find(district_id);
    if (district_iter == admin_division_infos_.end()) {
      LOG(WARNING) << "district_id not found: " << area_id;
      continue;
    }
    district_iter->second.sub_admin_divisions.insert(area_id);
  }
}

bool CityAreaHashDict::GetAreaInfoByCoord(double latitude, double longitude, AreaInfo* area_info) {
  area_info->Clear();

  std::string hash;
  if (!GeoHash::Encode(latitude, longitude, FLAGS_geo_hash_precision, &hash)) {
    LOG(WARNING) << "geohash encode fail: " << latitude << ", " << longitude;
    return false;
  }
  auto hash_iter = hash_area_id_map_.find(hash);
  if (hash_iter == hash_area_id_map_.end()) {
    VLOG(1) << "hash not found in hash area dict: " << hash;
    return SearchLocationByCoord(latitude, longitude, area_info);
  }

  int64 area_id = hash_iter->second;
  auto area_iter = area_id_info_map_.find(area_id);
  if (area_iter == area_id_info_map_.end()) {
    LOG(ERROR) << "area id not found in area info dict: " << area_id;
    return false;
  }

  int64 district_id = area_id / 100;
  if (GetAdminNameByID(district_id, &(area_info->district))) {
    area_info->district_id = district_id;
  }
  int64 city_id = district_id / 100 * 100;
  GetAdminNameByID(city_id, &(area_info->city));
  int64 prov_id = district_id / 10000 * 10000;
  GetAdminNameByID(prov_id, &(area_info->province));

  AreaBaseInfo &base_info = area_iter->second;
  area_info->area_id = area_id;
  area_info->area = base_info.area_name;
  return true;
}

bool CityAreaHashDict::SearchLocationByCoord(double latitude, double longitude, AreaInfo* area_info) {
  area_info->Clear();

  wolong::common::LocationPoint point;
  if (!location_searcher_->Search(latitude, longitude, &point)) {
    LOG_EVERY_N(INFO, 5000) << base::StringPrintf("location fail, lat: %f lng: %f", latitude, longitude);
    return false;
  }

  auto region_iter = region_code_map_.find(point.region_code);
  if (region_iter == region_code_map_.end()) {
    LOG_EVERY_N(INFO, 5000)
        << base::StringPrintf("region not found in dict, lat: %f lng: %f", latitude, longitude);
    return false;
  }

  area_info->district_id = region_iter->second;
  int64 prov_id = area_info->district_id / 10000 * 10000;
  if (!GetAdminNameByID(prov_id, &(area_info->province))) {
    LOG_EVERY_N(WARNING, 5000) << "pid not found in admin_division_map: " << prov_id;
    return false;
  }

  int64 city_id = area_info->district_id / 100 * 100;
  if (city_id == prov_id) return true;
  if (!GetAdminNameByID(city_id, &(area_info->city))) {
    LOG_EVERY_N(WARNING, 2000) << "cid not found in admin_division_map: " << city_id;
    return false;
  }

  if (area_info->district_id == city_id) return true;
  if (!GetAdminNameByID(area_info->district_id, &(area_info->district))) {
    LOG_EVERY_N(WARNING, 2000) << "district_id not found in admin_division_map: " << area_info->district_id;
    return false;
  }
  return true;
}

bool CityAreaHashDict::GetAdminNameByID(int64 id, std::string *name) {
  auto iter = admin_division_infos_.find(id);
  if (iter == admin_division_infos_.end()) return false;
  *name = iter->second.name;
  return true;
}

// bool CityAreaHashDict::GetAreaNameByID(int64 id, std::string *name) {
//   if (id > 1e7) {
//     reco::poi::AreaInfo area_info;
//     if (!GetAreaInfoByAreaID(id, &area_info)) {
//       return false;
//     }
//     *name = area_info.area;
//   } else {
//     if (!GetAdminNameByID(id, name)) {
//       return false;
//     }
//   }
//   return true;
// }

bool CityAreaHashDict::GetAreaBaseInfoByAreaID(int64 area_id, AreaBaseInfo *area_base_info) {
  auto iter = area_id_info_map_.find(area_id);
  if (iter == area_id_info_map_.end()) return false;
  *area_base_info = iter->second;
  return true;
}

void CityAreaHashDict::AddAreaIDByPOIInfo(const reco::GaoDePOIInfo &poi_info,
                                          std::unordered_set<int64> *area_ids,
                                          std::unordered_set<int64> *district_ids) {
  // 区县
  int64 district_id;
  if (poi_info.has_adcode() && base::StringToInt64(poi_info.adcode(), &district_id) &&
      district_id > 0) {
    district_ids->insert(district_id);
  }
  if (!poi_info.has_x() || !poi_info.has_y()) {
    return;
  }
  // 商圈
  reco::poi::AreaInfo area_info;
  if (!reco::poi::CityAreaHashSearcher::instance().GetAreaInfoByCoord(
          poi_info.y(), poi_info.x(), &area_info)) {
    return;
  }
  if (area_info.district_id > 0) {
    district_ids->insert(area_info.district_id);
  }
  if (area_info.area_id) {
    area_ids->insert(area_info.area_id);
  }
}

void CityAreaHashDict::GetItemAreaID(const reco::GaoDePOI &gaode_poi,
                                     std::unordered_set<int64> *area_ids,
                                     std::unordered_set<int64> *district_ids) {
  area_ids->clear();
  district_ids->clear();

  // POI filter
  if (gaode_poi.poi_poiinfos_size() > 0) {
    for (int i = 0; i < gaode_poi.poi_poiinfos_size(); ++i) {
      auto &poi_info = gaode_poi.poi_poiinfos(i);
      if (!poi_info.has_poitype() || poi_info.poitype().empty()) {
        continue;
      }
      std::vector<std::string> fields;
      base::SplitString(poi_info.poitype(), "|", &fields);
      int poi_type;
      for (size_t j = 0; j < fields.size(); ++j) {
        if (!base::StringToInt(fields[j], &poi_type)) {
          continue;
        }
        if (kBlackPOIType.find(poi_type / 10000) != kBlackPOIType.end()) {
          return;
        }
      }
    }
  }

  int64 district_id;
  for (int i = 0; i < gaode_poi.quxian_poiinfos_size(); ++i) {
    AddAreaIDByPOIInfo(gaode_poi.quxian_poiinfos(i), area_ids, district_ids);
  }
  for (int i = 0; i < gaode_poi.shangquan_poiinfos_size(); ++i) {
    auto &shangquan_poiinfo = gaode_poi.shangquan_poiinfos(i);
    if (shangquan_poiinfo.has_adcode() &&
        base::StringToInt64(shangquan_poiinfo.adcode(), &district_id) &&
        district_id > 0) {
      district_ids->insert(district_id);
    }
    if (shangquan_poiinfo.has_id()) {
      auto gaode_id = shangquan_poiinfo.id();
      auto area_id_iter = gaode_area_id_map_.find(gaode_id);
      if (area_id_iter != gaode_area_id_map_.end()) {
        int64 area_id = area_id_iter->second;
        area_ids->insert(area_id);
        district_id = area_id / 100;
        district_ids->insert(district_id);
      }
    }
  }
  for (int i = 0; i < gaode_poi.poi_poiinfos_size(); ++i) {
    AddAreaIDByPOIInfo(gaode_poi.poi_poiinfos(i), area_ids, district_ids);
  }
}

void CityAreaHashDict::GetItemAreaID(const reco::GaoDePOI &gaode_poi,
                                     std::unordered_set<int64> *area_ids) {
  area_ids->clear();
  std::unordered_set<int64> ids0, ids1;
  GetItemAreaID(gaode_poi, &ids0, &ids1);
  area_ids->insert(ids0.begin(), ids0.end());
  area_ids->insert(ids1.begin(), ids1.end());

  std::unordered_set<int64> city_ids;
  for (auto iter = area_ids->begin(); iter != area_ids->end(); ++iter) {
    int64 city_id = TranferToCityID(*iter);
    city_ids.insert(city_id);
  }
  // 多个城市的话，则返回失败
  if (city_ids.size() > 1) {
    area_ids->clear();
  }
}

int64 CityAreaHashDict::GetCityIDByDistrictID(int64 district_id) {
  return district_id / 100 * 100;
}

// bool CityAreaHashDict::GetNeighborAreaInfoByCoord(double latitude, double longitude, AreaInfo* area_info) {
//   std::string hash;
//   if (!GeoHash::Encode(latitude, longitude, FLAGS_geo_hash_precision, &hash)) {
//     LOG(WARNING) << "geohash encode fail: " << latitude << ", " << longitude;
//     return false;
//   }
//   std::unordered_set<std::string> hash_dedups;
//   std::vector<std::string> all_neighbors;
//   std::vector<std::string> neighbors;
//   all_neighbors.push_back(hash);
//   hash_dedups.insert(hash);
//
//   int index = 0;
//   while (index < (int)all_neighbors.size()) {
//     const std::string &hash = all_neighbors[index];
//     auto hash_iter = hash_area_id_map_.find(hash);
//     if (hash_iter != hash_area_id_map_.end()) {
//       auto area_iter = area_id_info_map_.find(hash_iter->second);
//       if (area_iter != area_id_info_map_.end()) {
//         *area_info = area_iter->second;
//         return true;
//       }
//     }
//
//     neighbors.clear();
//     if (GeoHash::GetNeighbors(hash, &neighbors)) {
//       for (size_t i = 0; i < neighbors.size(); ++i) {
//         if (hash_dedups.find(neighbors[i]) != hash_dedups.end()) {
//           continue;
//         }
//         all_neighbors.push_back(neighbors[i]);
//         hash_dedups.insert(neighbors[i]);
//       }
//     }
//     ++index;
//   }
//   return true;
// }

bool CityAreaHashDict::GetAdminCoordinate(int64 admin_id, double *latitude, double *longitude) {
  auto iter = admin_division_infos_.find(admin_id);
  if (iter == admin_division_infos_.end()) return false;
  *latitude = iter->second.latitude;
  *longitude = iter->second.longitude;
  return true;
}

bool CityAreaHashDict::GetSubAdminIDs(int64 id, std::unordered_set<int64> *sub_ids) {
  sub_ids->clear();
  if (id < 100000 || id > 999999) return false;
  if (IsDirectCity(id)) {
    auto iter = admin_division_infos_.find(id);
    for (auto sub_iter = iter->second.sub_admin_divisions.begin();
         sub_iter != iter->second.sub_admin_divisions.end(); ++sub_iter) {
      int64 sub_id = *sub_iter;
      auto sub_id_iter = admin_division_infos_.find(sub_id);
      if (sub_id_iter == admin_division_infos_.end()) continue;
      sub_ids->insert(sub_id_iter->second.sub_admin_divisions.begin(),
                      sub_id_iter->second.sub_admin_divisions.end());
    }
  } else {
    auto iter = admin_division_infos_.find(id);
    if (iter == admin_division_infos_.end()) {
      return false;
    }
    sub_ids->insert(iter->second.sub_admin_divisions.begin(),
                    iter->second.sub_admin_divisions.end());
  }
  return true;
}
}
}
