#include "reco/bizc/poi/geometry.h"
#include <iostream>
#include "base/common/base.h"
#include "base/testing/gtest.h"
#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace poi {

TEST(GeometryTest, CompareToZero) {
  double x = 1e-13;
  ASSERT_EQ(0, CompareToZero(x));
}

TEST(GeometryTest, PointInPolygon) {
  Polygon polygon;
  polygon.AddPoint(Point(0, 0));
  polygon.AddPoint(Point(0, 1));
  polygon.AddPoint(Point(1, 1));
  polygon.AddPoint(Point(1, 0));
  ASSERT_TRUE(PointInPolygon(Point(0.5, 0.5), polygon));
}

TEST(GeometryTest, GetIntersection) {
  Line a = Line(Point(0, 0), Point(1, 0));
  Line b = Line(Point(0.5, 1), Point(0.5, 2));
  Point ret;
  ASSERT_TRUE(GetIntersection(a, b, &ret));
  ASSERT_EQ(ret.x, 0.5);
  ASSERT_EQ(ret.y, 0);
  Segment seg = Segment(Point(0.5, 1), Point(0.5, 2));
  ASSERT_FALSE(GetIntersection(a, seg, &ret));
  seg.s.y = -1;
  ASSERT_TRUE(GetIntersection(a, seg, &ret));
  ASSERT_EQ(ret.x, 0.5);
  ASSERT_EQ(ret.y, 0);
}

TEST(GeometryTest, RoundOff) {
  double a = 1.23456;
  ASSERT_EQ(CompareToZero(Ceil(a, 1) - 1.3), 0);
  ASSERT_EQ(CompareToZero(Ceil(a, 2) - 1.24), 0);
  ASSERT_EQ(CompareToZero(Ceil(a, 3) - 1.235), 0);
  ASSERT_EQ(CompareToZero(Ceil(a, 4) - 1.2346), 0);

  ASSERT_EQ(CompareToZero(Floor(a, 1) - 1.2), 0);
  ASSERT_EQ(CompareToZero(Floor(a, 2) - 1.23), 0);
  ASSERT_EQ(CompareToZero(Floor(a, 3) - 1.234), 0);
  ASSERT_EQ(CompareToZero(Floor(a, 4) - 1.2345), 0);
}

TEST(GeometryTest, ConvertPolygonToPoints) {
  Polygon polygon;

  std::string str = "111.700003,40.828768;111.700191,40.828868;111.715388,40.832044;111.715765,40.831969;"
                    "111.715984,40.831216;111.717373,40.827596;111.718200,40.825309;111.718136,40.825203;"
                    "111.717828,40.825108;111.712919,40.824020;111.708815,40.823103;111.703288,40.821844;"
                    "111.703023,40.821866;111.702822,40.822056;111.700743,40.826659;111.699958,40.828619;"
                    "111.700003,40.828768";
  std::vector<std::string> tokens;
  base::SplitString(str, ";", &tokens);
  for (size_t i = 0; i < tokens.size(); ++i) {
    std::vector<std::string> sub_tokens;
    base::SplitString(tokens[i], ",", &sub_tokens);
    if (sub_tokens.size() < 2) {
      continue;
    }
    double x, y;
    if (!base::StringToDouble(sub_tokens[0], &x)) {
      continue;
    }
    if (!base::StringToDouble(sub_tokens[1], &y)) {
      continue;
    }
    polygon.AddPoint(Point(x, y));
    std::cout << x << "\t" << y << std::endl;
  }
  std::cout << "points" << std::endl;
  std::vector<Point> ret = ConvertPolygonToPoints(polygon, 3);
  for (size_t i = 0; i < ret.size(); ++i) {
    std::cout << ret[i].x << "\t" << ret[i].y << std::endl;
  }
}
}
}
