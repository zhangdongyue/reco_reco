#include "reco/bizc/poi/geohash.h"
#include <iostream>
#include "base/common/base.h"
#include "base/testing/gtest.h"
#include "base/common/gflags.h"

namespace reco {
namespace poi {
class GeoHashTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    geo_hash_ = new GeoHash;
  }

  virtual void TearDown() {
    delete geo_hash_;
  }

  GeoHash *geo_hash_;
};

void CheckGeoCoord(const GeoCoord& left, const GeoCoord &right) {
  EXPECT_DOUBLE_EQ(left.latitude, right.latitude) << left.latitude << ", " << right.latitude;
  EXPECT_DOUBLE_EQ(left.longitude, right.longitude) << left.longitude << ", " << right.longitude;
  EXPECT_DOUBLE_EQ(left.north, right.north) << left.north << ", " << right.north;
  EXPECT_DOUBLE_EQ(left.east, right.east) << left.east << ", " << right.east;
  EXPECT_DOUBLE_EQ(left.south, right.south) << left.south << ", " << right.south;
  EXPECT_DOUBLE_EQ(left.west, right.west) << left.west << ", " << right.west;
}

TEST_F(GeoHashTest, Encode) {
  struct TestCase {
    double latitude;
    double longitude;
    int precision;
    std::string hash_str;
  } cases[] = {
    {42.60498046875, -5.60302734375, 5, "ezs42"},
    {40.018141, -105.274858, 12, "9xj5smj4w40m"},
    {40.018141, -105.274858, 2, "9x"},
    {40.018141, -105.274858, 0, "9xj5sm"},
  };

  std::string hash_str;
  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(cases); ++i) {
    EXPECT_TRUE(geo_hash_->Encode(cases[i].latitude, cases[i].longitude, cases[i].precision, &hash_str));
    EXPECT_STREQ(hash_str.c_str(), cases[i].hash_str.c_str());
  }
}

TEST_F(GeoHashTest, Decode) {
  struct TestCase {
    std::string hash_str;
    GeoCoord coord;
  } cases[] = {
    {"ezs42", GeoCoord(42.60498046875, -5.60302734375, 42.626953125, -5.5810546875, 42.5830078125, -5.625)},
    {"ezs42gx", GeoCoord(42.602920532226562, -5.5817413330078125, 42.603607177734375,
                         -5.581054687500000, 42.60223388671875, -5.582427978515625)},
    {"9xj5smj4w40", GeoCoord(40.018140748143196, -105.27485780417919, 40.01814141869545,
                             -105.27485713362694, 40.018140077590942, -105.27485847473145)},
  };

  GeoCoord coord;
  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(cases); ++i) {
    EXPECT_TRUE(geo_hash_->Decode(cases[i].hash_str, &coord));
    CheckGeoCoord(coord, cases[i].coord);
  }
}

TEST_F(GeoHashTest, GetNeighbors) {
  struct TestCase {
    std::string hash_str;
    std::string neighbors[8];
  } cases[] = {
    {"ezs42", {"ezs48", "ezs49", "ezs43", "ezs41", "ezs40", "ezefp", "ezefr", "ezefx"}, },
    {"9xj5smj4w40m", {"9xj5smj4w40q", "9xj5smj4w40w", "9xj5smj4w40t", "9xj5smj4w40s",
                      "9xj5smj4w40k", "9xj5smj4w40h", "9xj5smj4w40j", "9xj5smj4w40n"}},
  };
  std::vector<std::string> neighbors;
  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(cases); ++i) {
    EXPECT_TRUE(geo_hash_->GetNeighbors(cases[i].hash_str, &neighbors));
    EXPECT_EQ(neighbors.size(), 8u);
    for (size_t j = 0; j < neighbors.size(); ++j) {
      EXPECT_STREQ(neighbors[j].c_str(), cases[i].neighbors[j].c_str());
    }
  }
}
}
}
