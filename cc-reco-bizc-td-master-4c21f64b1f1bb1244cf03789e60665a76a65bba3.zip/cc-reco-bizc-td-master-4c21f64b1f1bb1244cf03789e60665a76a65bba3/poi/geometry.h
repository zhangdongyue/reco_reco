#pragma once
#include <math.h>
#include <string>
#include <vector>
#include "base/common/base.h"
#include "base/common/logging.h"

namespace reco {
namespace poi {
// 点
struct Point {
  Point(double xx, double yy) {
    x = xx;
    y = yy;
  }
  Point() {
    x = 0;
    y = 0;
  }
  double x;
  double y;

  Point operator +(const Point& b) const {
    return Point(x + b.x, y + b.y);
  }
  Point operator -(const Point& b) const {
    return Point(x - b.x, y - b.y);
  }
  // 叉积
  double operator ^(const Point& b) const {
    return x * b.y - y * b.x;
  }
  // 点积
  double operator *(const Point& b) const {
    return x * b.x + y * b.y;
  }
};

// 直线
struct Line {
  Line(Point x, Point y) {
    s = x;
    e = y;
  }
  Point s;
  Point e;
};

// 线段
struct Segment {
  Segment(Point x, Point y) {
    s = x;
    e = y;
  }
  Point s;
  Point e;
};

class Polygon {
 public:
  Polygon();
  explicit Polygon(const std::vector<Point>& points);
  // 逆时针加入点
  void AddPoint(const Point& point);
  const std::vector<Point>* GetPoints() const;
  const Point GetPoint(int index) const;
  int GetPointsNum();

 private:
  std::vector<Point> points_;
};

// 等于 0 返回 0
// 大于 0 返回 1
// 小于 0 返回 -1
int CompareToZero(double x);
// 点是否在多边形内
bool PointInPolygon(const Point& point, Polygon polygon);
// 求两直线交点
bool GetIntersection(const Line& line_a, const Line& line_b, Point* point);
// 求直线与线段交点
bool GetIntersection(const Line& line, const Segment& segment, Point* point);
// 求直线与多边形交点
bool GetIntersection(const Line& line, Polygon polygon, std::vector<Point>* points);

// 把一个多边形转换成点集合 有一定精度
std::vector<Point> ConvertPolygonToPoints(Polygon polygon, int precision);

// 按精度向上近似
double Ceil(double x, int precision);
// 按精度向下近似
double Floor(double x, int precision);
}
}
