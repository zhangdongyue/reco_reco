#include "reco/bizc/poi/geohash.h"
#include <math.h>
#include <iostream>
#include <utility>

namespace reco {
namespace poi {

const double GeoHash::kMaxLatitude = 90;
const double GeoHash::kMinLatitude = -90;
const double GeoHash::kMaxLongitude = 180;
const double GeoHash::kMinLongitude = -180;

const std::string GeoHash::kCharMap = "0123456789bcdefghjkmnpqrstuvwxyz";
const std::string GeoHash::kEvenBorders[] = {"prxz", "bcfguvyz", "028b", "0145hjnp"};
const std::string GeoHash::kOddBorders[] = {"bcfguvyz", "prxz", "0145hjnp", "028b"};
const std::string GeoHash::kEvenNeighbors[] = {
  "p0r21436x8zb9dcf5h7kjnmqesgutwvy",
  "bc01fg45238967deuvhjyznpkmstqrwx",
  "14365h7k9dcfesgujnmqp0r2twvyx8zb",
  "238967debc01fg45kmstqrwxuvhjyznp",
};
const std::string GeoHash::kOddNeighbors[] = {
  "bc01fg45238967deuvhjyznpkmstqrwx",
  "p0r21436x8zb9dcf5h7kjnmqesgutwvy",
  "238967debc01fg45kmstqrwxuvhjyznp",
  "14365h7k9dcfesgujnmqp0r2twvyx8zb",
};

const double GeoHash::EARTH_RADIUS = 6378.137;
const double GeoHash::kPi = acos(-1);
#define rad(d) (d * kPi / 180.0)

bool GeoHash::Encode(double latitude, double longitude, int precision, std::string *hash_value) {
  hash_value->clear();
  if (latitude > kMaxLatitude || latitude < kMinLatitude) {
    LOG(INFO) << "latitude out of range: " << latitude;
    return false;
  }
  if (longitude > kMaxLongitude || longitude < kMinLongitude) {
    LOG(INFO) << "longitude out of range: " << longitude;
    return false;
  }
  if (precision < 1 || precision > 12) {
    precision = 6;
  }

  hash_value->resize(precision);
  std::pair<double, double> lat_interval(kMaxLatitude, kMinLatitude);
  std::pair<double, double> lng_interval(kMaxLongitude, kMinLongitude);
  std::pair<double, double> *interval;

  double coord, mid;
  bool is_even = true;
  uint32 hash_char = 0;
  for (int i = 1; i <= precision * 5; i++) {
    if (is_even) {
      interval = &lng_interval;
      coord = longitude;
    } else {
      interval = &lat_interval;
      coord = latitude;
    }

    mid = (interval->first + interval->second) / 2;
    hash_char = hash_char << 1;
    if (coord > mid) {
      interval->second = mid;
      hash_char |= 0x01;
    } else {
      interval->first = mid;
    }

    if (!(i % 5)) {
      (*hash_value)[(i - 1) / 5] = kCharMap[hash_char];
      hash_char = 0;
    }
    is_even = !is_even;
  }
  return true;
}

bool GeoHash::Decode(const std::string &hash_value, GeoCoord *geo_coord) {
  CHECK(geo_coord);
  if (hash_value.empty()) return false;

  std::pair<double, double> lat_interval(kMaxLatitude, kMinLatitude);
  std::pair<double, double> lng_interval(kMaxLongitude, kMinLongitude);
  std::pair<double, double> *interval;

  bool is_even = true;
  for (size_t i = 0; i < hash_value.length(); ++i) {
    size_t pos = kCharMap.find(hash_value[i]);
    if (pos == std::string::npos) return false;

    // Interpret the last 5 bits of the integer
    for (int j = 0; j < 5; j++) {
      interval = is_even ? &lng_interval : &lat_interval;
      double delta = (interval->first - interval->second) / 2;
      if ((pos << j) & 0x0010) {
        interval->second += delta;
      } else {
        interval->first -= delta;
      }
      is_even = !is_even;
    }
  }

  geo_coord->latitude = lat_interval.first - ((lat_interval.first - lat_interval.second) / 2.0);
  geo_coord->longitude = lng_interval.first - ((lng_interval.first - lng_interval.second) / 2.0);
  geo_coord->north = lat_interval.first;
  geo_coord->east = lng_interval.first;
  geo_coord->south = lat_interval.second;
  geo_coord->west = lng_interval.second;
  return true;
}

bool GeoHash::GetNeighbor(const std::string &hash, Direction direction, std::string *neighbor_hash) {
  if (hash.empty()) return false;
  bool is_odd = hash.length() % 2;
  const std::string *border = is_odd ? kOddBorders : kEvenBorders;
  const std::string *neighbor = is_odd ? kOddNeighbors : kEvenNeighbors;

  char last_char = hash[hash.length() - 1];
  *neighbor_hash = hash.substr(0, hash.length() - 1);
  size_t pos = border[direction].find(last_char);
  if (pos != std::string::npos) {
    if (!GetNeighbor(hash.substr(0, hash.length() - 1), direction, neighbor_hash)) {
      return false;
    }
  }

  pos = neighbor[direction].find(last_char);
  if (pos == std::string::npos) {
    return false;
  }
  (*neighbor_hash) += kCharMap[pos];
  return true;
}

bool GeoHash::GetNeighbors(const std::string &hash, std::vector<std::string> *neighbors) {
  neighbors->clear();
  Direction directions[4] = {kNorth, kEast, kSouth, kWest};
  std::string neighbor;

  for (int i = 0; i < 4; ++i) {
    neighbor.clear();
    if (!GetNeighbor(hash, directions[i], &neighbor)) {
      return false;
    }
    neighbors->push_back(neighbor);

    neighbor.clear();
    if (!GetNeighbor(neighbors->back(), directions[(i+1)%4], &neighbor)) {
      return false;
    }
    neighbors->push_back(neighbor);
  }
  return true;
}

double GeoHash::GetDistance(double lat1, double lng1, double lat2, double lng2) {
  double radLat1 = rad(lat1);
  double radLat2 = rad(lat2);
  double a = radLat1 - radLat2;
  double b = rad(lng1) - rad(lng2);
  double s = 2 * asin(sqrt(pow(sin(a/2), 2) +
                           cos(radLat1) * cos(radLat2)* pow(sin(b/2), 2)));
  s = s * EARTH_RADIUS;
  s = round(s * 10000) / 10000;
  return s;
}
}
}
