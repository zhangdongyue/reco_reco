#include "reco/bizc/poi/geometry.h"
#include <algorithm>

namespace reco {
namespace poi {
Polygon::Polygon() {
  points_.clear();
}

Polygon::Polygon(const std::vector<Point>& points) {
  points_ = points;
}

void Polygon::AddPoint(const Point& point) {
  points_.push_back(point);
}

const std::vector<Point>* Polygon::GetPoints() const {
  return &points_;
}

int Polygon::GetPointsNum() {
  return points_.size();
}

const Point Polygon::GetPoint(int index) const {
  return points_[index];
}

bool compare(const Point &a, const Point &b) {
  return a.x < b.x;
}

double Direction(Point p1, Point p2, Point p) {
  return (p1.x - p.x)*(p2.y - p.y) - (p2.x - p.x) * (p1.y - p.y);
}

bool PointOnSegment(Point p, Segment seg) {
  Point p1 = seg.s;
  Point p2 = seg.e;
  DLOG(INFO) << p.x << ", " << p.y;
  DLOG(INFO) << p1.x << ", " << p1.y;
  DLOG(INFO) << p2.x << ", " << p2.y;
  DLOG(INFO) << Direction(p, p1, p2);
  DLOG(INFO) << CompareToZero(Direction(p, p1, p2));
  if (CompareToZero(Direction(p, p1, p2)) != 0) {
    return false;
  }
  double max = p1.x > p2.x ? p1.x : p2.x;
  double min = p1.x < p2.x ? p1.x : p2.x;
  double max1 = p1.y > p2.y ? p1.y : p2.y;
  double min1 = p1.y < p2.y ? p1.y : p2.y;
  return (CompareToZero(p.x - min) >= 0 &&
          CompareToZero(p.x - max) <= 0 &&
          CompareToZero(p.y - min1) >= 0 &&
          CompareToZero(p.y - max1) <= 0);
}

bool PointInPolygon(const Point& point, Polygon polygon) {
  int j = polygon.GetPointsNum() - 1;
  bool oddNodes = false;
  for (int i = 0; i < polygon.GetPointsNum(); i++) {
    auto point_i = polygon.GetPoint(i);
    auto point_j = polygon.GetPoint(j);
    // 如果在边线上，也视为在多边形内
    if (PointOnSegment(point, Segment(point_i, point_j))) {
      return true;
    }
    if (((point_i.y < point.y && point_j.y >= point.y) || (point_j.y < point.y && point_i.y >= point.y))
        && (point_i.x <= point.x || point_j.x <= point.x)) {
      oddNodes ^= (point_i.x + (point.y-point_i.y) / (point_j.y - point_i.y) * (point_j.x - point_i.x)
                   < point.x);
    }
    j = i;
  }
  return oddNodes;
}

int CompareToZero(double x) {
  static const double eps = 1.0e-12;
  if (fabs(x) < eps) return 0;
  if (x < 0) {
    return -1;
  } else {
    return 1;
  }
}

bool GetIntersection(const Line& line_a, const Line& line_b, Point* point) {
  *point = line_a.s;
  // 重合或平行
  if (CompareToZero((line_a.s - line_a.e) ^ (line_b.s - line_b.e)) == 0) {
    return false;
  }
  double t = ((line_a.s - line_b.s) ^ (line_b.s - line_b.e)) /
      ((line_a.s - line_a.e) ^ (line_b.s - line_b.e));
  point->x += (line_a.e.x - line_a.s.x) * t;
  point->y += (line_a.e.y - line_a.s.y) * t;
  return true;
}

bool GetIntersection(const Line& line, const Segment& segment, Point* point) {
  if (CompareToZero((segment.s - line.e)^(line.s-line.e)) *
      CompareToZero((segment.e - line.e)^(line.s-line.e)) <= 0) {
    return GetIntersection(line, Line(segment.s, segment.e), point);
  }
  return false;
}

bool GetIntersection(const Line& line, Polygon polygon, std::vector<Point>* points) {
  points->clear();
  int j = polygon.GetPointsNum() - 1;
  Point p;
  for (int i = 0; i < polygon.GetPointsNum(); ++i) {
    auto seg = Segment(polygon.GetPoint(j), polygon.GetPoint(i));
    if (GetIntersection(line, seg, &p)) {
      points->push_back(p);
    }
    j = i;
  }
  return !points->empty();
}

double Ceil(double x, int precision) {
  double temp = x * pow(10, precision);
  temp = ceil(temp);
  return (temp * pow(10, -precision));
}

double Floor(double x, int precision) {
  double temp = x * pow(10, precision);
  temp = floor(temp);
  return (temp * pow(10, -precision));
}

std::vector<Point> ConvertPolygonToPoints(Polygon polygon, int precision) {
  auto points = polygon.GetPoints();
  double max_y = 0;
  double min_y = 99999999999;
  for (size_t i = 0; i < points->size(); ++i) {
    DLOG(INFO) << "polygon: " << points->at(i).x << "," << points->at(i).y;
    max_y = std::max(points->at(i).y, max_y);
    min_y = std::min(points->at(i).y, min_y);
  }
  // 标准化精度
  max_y = Floor(max_y, precision);
  min_y = Ceil(min_y, precision);
  double step = pow(10, -precision);

  DLOG(INFO) << "min_y: " << min_y << ", max_y: " << max_y << " precision: " << step;

  std::vector<Point> ret;
  for (double y = min_y; CompareToZero(y - max_y) != 1; y += step) {
    Line line = Line(Point(0.0, y), Point(1.0, y));
    DLOG(INFO) << "y: " << y;
    std::vector<Point> intersections;
    GetIntersection(line, polygon, &intersections);
    if (intersections.size() > 1) {
      // 按 x 排序
      std::sort(intersections.begin(), intersections.end(), compare);
      for (size_t i = 0; i < intersections.size() - 1; ++i) {
        // 如果线段中点在多边形内，那么这个线段就在多边形内
        Point mid = Point(intersections[i].x * 0.5 + intersections[i + 1].x * 0.5,
                          intersections[i].y * 0.5 + intersections[i + 1].y * 0.5);
        DLOG(INFO) << "seg: (" << intersections[i].x << ", " << intersections[i].y << ") "
                  << "(" << intersections[i + 1].x << ", " << intersections[i + 1].y << ") ";
        if (PointInPolygon(mid, polygon)) {
          DLOG(INFO) << "point: " << "(" << mid.x << ", " << mid.y << ") in polygon";
          for (double x = Ceil(intersections[i].x, precision);
               CompareToZero(x - Floor(intersections[i + 1].x, precision)) != 1;
               x += step) {
            ret.push_back(Point(x, intersections[i].y));
          }
        }
      }
    }
  }
  return ret;
}
}
}
