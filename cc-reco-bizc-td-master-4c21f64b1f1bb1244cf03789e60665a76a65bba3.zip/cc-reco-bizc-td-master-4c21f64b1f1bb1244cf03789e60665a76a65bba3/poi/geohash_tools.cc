#include "reco/bizc/poi/geohash.h"
#include <iostream>
#include <iomanip>
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"

DEFINE_bool(decode_geohash, false, "using method of decode geohash");
DEFINE_bool(encode_geohash, false, "using method of encode geohash");
DEFINE_bool(get_neighbor, false, "given hash return neighbors");
DEFINE_bool(calc_distance, false, "given two points calc distance");

void Encode() {
  reco::poi::GeoHash geo_hash;
  std::string line;
  std::vector<std::string> fields;
  double latitude, longitude;
  uint32 precision;
  std::cerr << "format: latitude,longitude,precision" << std::endl;
  std::string hash_value;
  while (std::getline(std::cin, line)) {
    fields.clear();
    base::SplitString(line, ",", &fields);
    if (fields.size() < 3u) continue;
    if (!base::StringToDouble(fields[0], &latitude) ||
        !base::StringToDouble(fields[1], &longitude) ||
        !base::StringToUint(fields[2], &precision)) continue;

    if (!reco::poi::GeoHash::Encode(latitude, longitude, precision, &hash_value)) continue;
    std::cout << hash_value << std::endl;
  }
}

void Decode() {
  std::string line;
  reco::poi::GeoCoord coord;
  std::cout << setiosflags(std::ios::fixed);
  while (std::getline(std::cin, line)) {
    if (!reco::poi::GeoHash::Decode(line, &coord)) continue;
    std::cout << std::setprecision(6) << coord.latitude << '\t'
              << std::setprecision(6) << coord.longitude << std::endl;
    std::cout << std::setprecision(6) << coord.north << '\t'
              << std::setprecision(6) << coord.east << '\t'
              << std::setprecision(6) << coord.south << '\t'
              << std::setprecision(6) << coord.west << std::endl;
  }
}

void GetNeighbors() {
  std::string line;
  std::vector<std::string> neighbors;
  while (std::getline(std::cin, line)) {
    if (!reco::poi::GeoHash::GetNeighbors(line, &neighbors)) continue;
    for (size_t i = 0; i < neighbors.size(); ++i) {
      std::cout << neighbors[i] << std::endl;
    }
  }
}

void CalcDistance() {
  std::string line;
  std::vector<std::string> fields;
  double latitude[2], longitude[2];
  int idx = 0;
  while (std::getline(std::cin, line)) {
    fields.clear();
    base::SplitString(line, ",", &fields);
    if (fields.size() < 2u) continue;
    if (!base::StringToDouble(fields[0], &latitude[idx]) ||
        !base::StringToDouble(fields[1], &longitude[idx])) continue;
    if (idx == 1) {
      double distance = reco::poi::GeoHash::GetDistance(latitude[0], longitude[0], latitude[1], longitude[1]);
      std::cout << distance << std::endl;
      idx = 0;
    } else {
      ++idx;
    }
  }
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  if (FLAGS_encode_geohash) Encode();
  else if (FLAGS_decode_geohash) Decode();
  else if (FLAGS_get_neighbor) GetNeighbors();
  else if (FLAGS_calc_distance) CalcDistance();

  return 0;
}
