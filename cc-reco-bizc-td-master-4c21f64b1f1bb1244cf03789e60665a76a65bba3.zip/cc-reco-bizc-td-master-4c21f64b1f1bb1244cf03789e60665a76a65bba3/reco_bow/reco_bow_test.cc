#include "reco/bizc/reco_bow/reco_bow.h"

#include "base/testing/gtest.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"

TEST(RecoBow, TestRecoBow) {
  struct {
    std::string title;
    std::string category;
  } cases[] = {
    {"这60条公交今晚延时 最迟至1点", "社会"},
    {"截止11点 沪深两市主力资金流向", "财经"},
    {"衡阳至北京每天一航班 中午12点05分起飞北京", "社会"},
    {"小米今日下午2点发全新产品：等风来", "科技"},
    {"北京交管局：平安夜 晚高峰下午3点开始", "国内"},
    {"巴萨全队抵达马德里 北京时间周六23点开球", "体育"},
  };
  
  reco::RecoBow reco_bow;
  int num = ARRAYSIZE_UNSAFE(cases);

  std::vector<std::pair<std::string, double>> bow;
  for (int i = 0; i < num; ++i) {
    bow.clear();
    std::cout << cases[i].title << " --> ";
    reco_bow.ExtractBow(cases[i].category, cases[i].title, "", 1000, &bow);
    for (auto it = bow.begin(); it != bow.end(); ++it) {
      std::cout << it->first << ":" << it->second << " ";
    }
    std::cout << std::endl;
  }
}
