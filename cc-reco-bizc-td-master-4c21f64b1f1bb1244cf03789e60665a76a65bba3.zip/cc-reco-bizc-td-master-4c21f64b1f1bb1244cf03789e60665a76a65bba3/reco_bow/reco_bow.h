#pragma once
#include "reco/base/common/atomic.h"
#include <string>
#include <vector>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>

#include "base/file/file_path.h"
#include "base/thread/sync.h"

namespace nlp {
namespace term {
class TermContainer;
}

namespace segment {
class Segmenter;
}

namespace postag {
class PosTagger;
}

namespace ner {
class Ner;
}

namespace time {
class TimeRecognizer;
}

}  // namespace nlp

namespace reco {

namespace ner {
class RecoNer;
}

namespace splice {
class RecoSplicer;
}

struct WordInfo {
  std::string literal;
  int tf;
  float weight;
};

class RecoBow {
 public:
  RecoBow(bool do_splice = true);
  ~RecoBow();

  void ExtractBow(const std::string& category,
                  const std::string& title,
                  const std::string& content,
                  int topn,
                  std::vector<std::pair<std::string, double>>* bow);

 private:
  void ProcessText(const std::string& category, const std::string& orig_text,
                   std::unordered_map<std::string, double>* tf);

  // 加载词表, 用于抽取 manual_lable
  bool LoadDict();
 private:
  static const char* kTermBlackFile;
  static const char* kBasicTermBlackFile;

  nlp::segment::Segmenter *segmenter_;
  nlp::postag::PosTagger* postagger_;
  nlp::ner::Ner* ner_;
  nlp::time::TimeRecognizer* time_recognizer_;

  reco::splice::RecoSplicer* splicer_;
  reco::ner::RecoNer* reco_ner_;

  // 黑名单, 出现在此名单里的词不作为 keyword 等特征
  std::unordered_set<uint64> black_term_dict_;
  std::unordered_set<uint64> basic_black_term_dict_;

  static std::atomic<bool> global_init_;
  static thread::Mutex mutex_;
};

}  // namespace vertical
