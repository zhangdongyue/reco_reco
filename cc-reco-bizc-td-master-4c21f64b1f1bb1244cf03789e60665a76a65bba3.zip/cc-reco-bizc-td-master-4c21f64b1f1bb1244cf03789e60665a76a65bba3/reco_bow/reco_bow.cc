#include "reco/bizc/reco_bow/reco_bow.h"

#include <cmath>
#include <algorithm>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <functional>

#include "reco/bizc/reco_bow/topn.h"
#include "reco/bizc/reco_splice/reco_splice.h"
#include "reco/bizc/reco_ner/reco_ner.h"
#include "reco/bizc/proto/item.pb.h"
#include "nlp/segment/segmenter.h"
#include "nlp/common/nlp_util.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "nlp/time/time_recognizer.h"
#include "base/hash_function/term.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/utf_string_conversions.h"
#include "base/time/time.h"
#include "reco/bizc/reco_ner/reco_ner.h"

DEFINE_string(reco_bow_data_dir, "serving/reco/data/cdoc_convertor", "");

namespace reco {

const char* RecoBow::kTermBlackFile = "term_black.txt";
const char* RecoBow::kBasicTermBlackFile = "basic_term_black.txt";

std::atomic<bool> RecoBow::global_init_(false);
thread::Mutex RecoBow::mutex_;

static bool postag_rule(int postag) {
  using namespace nlp::term;  // NOLINT
  static const int kPostagNum = 40;
  static int postag_set[kPostagNum];
  static int postag_blist[] = {
    kTime, kConjunction, kAdverb, kExclamation,
    kPosition, kPrefix, kNumber, kNumberQuantity,
    kPreposition, kQuantity, kPronoun, kAuxiliary, kPunctuation,
    kAdjective, kWhiteSpace
  };
  static bool first = true;
  // multi-thread not safe
  if (first) {
    memset(postag_set, 0, kPostagNum * sizeof(int));
    int num_of_blist = sizeof(postag_blist)/sizeof(int);
    for (int i = 0; i < num_of_blist; i++) {
      postag_set[postag_blist[i]] = 1;
    }
    first = false;
  }
  return (postag_set[postag] == 1);
}

static bool entity_rule(int entity) {
  using namespace nlp::term;  // NOLINT
  static const int kEntityNum = 255;
  static int entity_set[kEntityNum];
  static int entity_blist[] = {
    kIdiom, kProductSN, kPhrase, kEntityOther, kBookSN,
    kVideoSN, kSoftwareVN,
  };
  static bool first = true;
  // multi-thread not safe
  if (first) {
    memset(entity_set, 0, kEntityNum * sizeof(int));
    int num_of_blist = sizeof(entity_blist)/sizeof(int);
    for (int i = 0; i < num_of_blist; i++) {
      entity_set[entity_blist[i]] = 1;
    }
    first = false;
  }
  return (entity_set[entity] == 1);
}

RecoBow::RecoBow(bool do_splice) {
  segmenter_ = new nlp::segment::Segmenter;
  postagger_ = new nlp::postag::PosTagger;
  ner_ = new nlp::ner::Ner;
  time_recognizer_ = new nlp::time::TimeRecognizer;
  splicer_ = NULL;
  if (do_splice) {
    splicer_ = new reco::splice::RecoSplicer;
  }

  reco_ner_ = new reco::ner::RecoNer;
  CHECK(LoadDict());
}

RecoBow::~RecoBow() {
  delete segmenter_;
  delete postagger_;
  delete ner_;
  delete time_recognizer_;
  delete splicer_;
  delete reco_ner_;
}

bool RecoBow::LoadDict() {
  base::FilePath root_dir(FLAGS_reco_bow_data_dir.c_str());
  base::FilePath term_black_file = root_dir.Append(kTermBlackFile);
  base::FilePath basic_term_black_file = root_dir.Append(kBasicTermBlackFile);

  std::vector<std::string> lines;

  // load black list
  lines.clear();
  CHECK(base::file_util::ReadFileToLines(term_black_file, &lines));
  black_term_dict_.clear();
  for (int i = 0; i < (int)lines.size(); ++i) {
    std::string str = nlp::util::NormalizeLine(lines[i]);
    black_term_dict_.insert(base::CalcTermSign(str.c_str(), str.size()));
  }

  // load basic black list
  lines.clear();
  CHECK(base::file_util::ReadFileToLines(basic_term_black_file, &lines));
  basic_black_term_dict_.clear();
  for (int i = 0; i < (int)lines.size(); ++i) {
    std::string str = nlp::util::NormalizeLine(lines[i]);
    basic_black_term_dict_.insert(base::CalcTermSign(str.c_str(), str.size()));
  }

  // 加载地域词典
  mutex_.Lock();
  if (!global_init_) {
    CHECK(nlp::time::TimeRecognizer::LoadDict());
  }
  global_init_ = true;
  mutex_.Unlock();

  return true;
}

void RecoBow::ProcessText(const std::string& category, const std::string& orig_text,
                          std::unordered_map<std::string, double>* tf) {
  std::string str = nlp::util::NormalizeLine(orig_text);
  if (str.empty() || str == " ") {
    return;
  }

  nlp::term::TermContainer container;
  CHECK(segmenter_->SegmentT(str, &container));
  CHECK(postagger_->PosTagT(str, &container));
  CHECK(ner_->DetectEntityT(str, &container));

  std::vector<nlp::time::TimeEntity> times;
  time_recognizer_->DetectTime(base::Time::Now(), str, container, &times);
  std::unordered_set<int> time_idx;
  for (size_t i = 0; i < times.size(); ++i) {
    for (size_t j = 0; j < times[i].term_indices.size(); ++j) {
      time_idx.insert(times[i].term_indices[j]);
    }
  }

  for (int i = 0; i < container.basic_term_num(); ++i) {
    const nlp::term::TermInfo& info = container.basic_term_info(i);
    base::Slice term = info.term(str);
    if (time_idx.count(i) > 0) {
      continue;
    }
    if (info.entity_index == -1) {
      if (info.rune_len == 1) {
        continue;
      }
      if (nlp::rune::is_rune_type(info.rune_type, nlp::rune::kNumber)
          || nlp::rune::is_rune_type(info.rune_type, nlp::rune::kWhiteSpace)
          || nlp::rune::is_rune_type(info.rune_type, nlp::rune::kPunctuation)
          || nlp::rune::is_rune_type(info.rune_type, nlp::rune::kStopWord)) {
        continue;
      }
      uint64 sign = base::CalcTermSign(term.data(), (int)term.size());
      if (basic_black_term_dict_.find(sign) != basic_black_term_dict_.end()) {
        continue;
      }
    } else {
      continue;
    }
    if (postag_rule(info.enum_postag)) {
      (*tf)[term.as_string()] += 0.3;
    } else {
      (*tf)[term.as_string()] += 1;
    }
  }

  std::unordered_map<std::string, int> bigram_phrases;
  std::unordered_map<std::string, int> trigram_phrases;
  if (splicer_ != NULL && !splicer_->SpliceT(str, str.size(), container, &bigram_phrases, &trigram_phrases)) {
    LOG(WARNING) << "failed to extract splice";
    bigram_phrases.clear();
    trigram_phrases.clear();
  }

  for(auto iter = bigram_phrases.begin(); iter != bigram_phrases.end(); ++iter) {
    int char_num = 0;
    if (! base::GetUTF8CharNum(iter->first, &char_num)) {
      LOG(WARNING) << "get phrase char num failed";
      continue;
    }
    if (char_num > 10) {
      continue;
    }
    uint64 sign = base::CalcTermSign(iter->first.c_str(), (int)iter->first.size());
    if (black_term_dict_.find(sign) == black_term_dict_.end()) {
      (*tf)[iter->first] += iter->second;
    }
  }

  for(auto iter = trigram_phrases.begin(); iter != trigram_phrases.end(); ++iter) {
    int char_num = 0;
    if (! base::GetUTF8CharNum(iter->first, &char_num)) {
      LOG(WARNING) << "get phrase char num failed";
      continue;
    }
    if (char_num > 10) {
      continue;
    }
    uint64 sign = base::CalcTermSign(iter->first.c_str(), (int)iter->first.size());
    if (black_term_dict_.find(sign) == black_term_dict_.end()) {
      (*tf)[iter->first] += iter->second;
    }
  }

  // 提取 reco ner
  nlp::util::ConstructMixTerms(str, false, &container);
  for (int j = 0; j < container.entity_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.entity_term_info(j);
    base::Slice term = info.term(str);
    if (entity_rule(info.enum_entity)) {
      (*tf)[term.as_string()] += 0.5;
    } else {
      (*tf)[term.as_string()] += 1;
    }
  }

  std::vector<base::Slice> reco_entities;
  std::vector<base::Slice> results;
  if (!reco_ner_->DetectEntity(str, container,
                               category,
                               &results, &reco_entities)) {
    LOG(WARNING) << "detect reco entity fail";
  }
  for (int j = 0; j < (int)reco_entities.size(); ++j) {
    (*tf)[reco_entities[j].as_string()] += 1;
  }
}

void RecoBow::ExtractBow(const std::string& category,
                         const std::string& title,
                         const std::string& content,
                         int topn, std::vector<std::pair<std::string, double>>* bow) {
  std::unordered_map<std::string, double> tf;
  ProcessText(category, title, &tf);
  // for (auto it = tf.begin(); it != tf.end(); ++it) {
  //   it->second *= 5;
  // }
  ProcessText(category, content, &tf);
  for (auto it = tf.begin(); it != tf.end(); ++it) {
    it->second = int(it->second + 1);
  }

  // std::string nor_title = nlp::util::NormalizeLine(title);
  // std::string nor_content = nlp::util::NormalizeLine(content);
  TopN<std::string> top(topn);
  for (auto it = tf.begin(); it != tf.end(); ++it) {
    top.add(it->first, it->second);
  }
  bow->clear();
  top.get_top_n(bow);
}
}  // namespace reco
