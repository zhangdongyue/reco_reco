#include <unistd.h>

#include <algorithm>
#include <fstream>
#include <string>
#include <queue>
#include <vector>
#include <math.h>
#include <unordered_set>
#include <unordered_map>

template<class T>
class TopN {
 public:
  TopN(int heap_size) : kHeapSize(heap_size) {}
  ~TopN() {} 

  void add(const T elem, double score) {
    topn_.push(std::make_pair(score, elem));
    if ((int)topn_.size() > kHeapSize) {
      topn_.pop();
    }
  }

  // 按照 score 从大到小排序
  void get_top_n(std::vector<T>* list) {
    list->clear();
    list->resize(topn_.size());
    auto it = list->rbegin();
    while (!topn_.empty()) {
      *it++ = topn_.top().second;
      topn_.pop();
    }
  }

  // 按照 score 从大到小排序
  void get_top_n(std::vector<std::pair<T, double> >* list) {
    list->clear();
    list->resize(topn_.size());
    auto it = list->rbegin();
    while (!topn_.empty()) {
      it->first = topn_.top().second;
      it->second = topn_.top().first;
      ++it;
      topn_.pop();
    }
  }

 private:
  std::priority_queue<std::pair<double, T>,
      std::vector<std::pair<double, T> >,
      std::greater<std::pair<double, T> > > topn_;
  const int kHeapSize;
};

