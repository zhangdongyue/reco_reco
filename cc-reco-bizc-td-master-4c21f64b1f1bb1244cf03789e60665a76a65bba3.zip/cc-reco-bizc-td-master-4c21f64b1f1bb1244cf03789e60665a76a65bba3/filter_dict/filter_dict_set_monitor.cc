#include "reco/bizc/filter_dict/filter_dict_set_monitor.h"

#include <cstdatomic>
#include <string>
#include <vector>
#include <unordered_map>
#include <fstream>
#include <utility>

//#include "reco/bizc/proto/index_aux_data.pb.h"
#include "base/common/basic_types.h"
#include "base/strings/string_util.h"
//#include "base/common/closure.h"
//#include "base/encoding/line_escape.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/file/memory_mapped_file.h"
//#include "base/strings/string_number_conversions.h"
//#include "nlp/common/nlp_util.h"

namespace reco {
namespace common {

FilterDictSetMonitor::FilterDictSetMonitor() {
  const_cast<base::dense_hash_set<std::string>*>(filter_dict_.GetDict())->set_empty_key("");
  filter_dict_.GetInactiveDict()->set_empty_key("");
}

void FilterDictSetMonitor::LoadFile() {
  while (!filter_dict_.CanSwitch()) {
    LOG(INFO) << "can't swith, sleep.";
    base::SleepForSeconds(10);
  }

  LOG(INFO) << "begin to load file:" << file_path_.ToString();
  auto dict = filter_dict_.GetInactiveDict();
  dict->clear();
  dict->set_empty_key("");

  if (base::file_util::PathExists(file_path_)) {
    std::vector<std::string> lines;
    base::file_util::ReadFileToLines(file_path_, &lines);
    for (auto i = 0u; i < lines.size(); ++i) {
      base::TrimWhitespaces(&lines[i]);
      if (!lines[i].empty())
        dict->insert(lines[i]);
    }
  }

  filter_dict_.SwitchDict();
  LOG(INFO) << "end to load file:" << file_path_.ToString();

  return;
}
}
}
