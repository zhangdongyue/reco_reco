#pragma once
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include "base/common/basic_types.h"
#include "reco/bizc/reco_index/news_index.h"

namespace reco {
class NewsIndex;
namespace news_map {

struct POIItemInfo {
  ItemInfo item_info;
  std::string area_name;
  int64 area_id;
};

class UpdateNewsMap {
 public:
  explicit UpdateNewsMap(const reco::NewsIndex* news_index);
  ~UpdateNewsMap() {}

  void Update(std::unordered_map<int64, std::vector<ItemInfo> > *news_map_index);

  static bool IsNewsMapCity(int64 city_id);
  static bool IsSameCity(int64 city_a, int64 city_b);

 private:
  void GetNewsMap(int64 area_id, std::vector<ItemInfo> *poi_items);
  void GetLocalNewsCandidates(int64 area_id, std::vector<ItemInfo> *candidates);

  bool FilterByItemQuality(const ItemInfo &item);
  bool FilterBySensitive(const ItemInfo &item);
  bool IsGeneralFiltered(const ItemInfo &item);

  int CalcRecoScore(const ItemInfo &item);
  bool GetAreaInfo(const ItemInfo &item, std::string *area_name, int64 *area_id);

  bool IsSimilarFea(const std::unordered_map<std::string, float>& fea1,
                    const std::unordered_map<std::string, float>& fea2);
  void GetItemSimFeas(uint64 item_id, std::unordered_map<std::string, float>* reco_feas);
  void DiversityFilter(const std::vector<ItemInfo> &org_candidates,
                       std::vector<ItemInfo> *candidates);

 private:
  const reco::NewsIndex* news_index_;
  static const int kMinPOIItemSize = 3;
  static const int kRecoScoreFactor = 1000000;
  static const std::unordered_set<int64> kNewsMapCitySet;
  static const std::unordered_set<std::string> kValideCategorySet;
};
}
}
