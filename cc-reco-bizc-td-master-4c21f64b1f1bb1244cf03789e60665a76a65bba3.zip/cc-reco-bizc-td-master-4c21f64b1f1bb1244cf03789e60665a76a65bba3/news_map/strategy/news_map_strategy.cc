#include "reco/bizc/news_map/strategy/news_map_strategy.h"
#include <algorithm>
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/poi/city_area_hash_dict.h"
#include "reco/bizc/region/region_dict.h"

DEFINE_int32(update_news_map_interval_second, 30, "update news map interval second");

namespace reco {
namespace news_map {

NewsMapStrategy::NewsMapStrategy() {
  update_news_map_thread_stop_ = false;
  news_map_updater_ = NULL;
}

NewsMapStrategy::~NewsMapStrategy() {
}

void NewsMapStrategy::Start(const reco::NewsIndex* index) {
  if (FLAGS_update_news_map_interval_second < 0) {
    return;
  }

  news_index_ = index;
  news_map_updater_ = new UpdateNewsMap(news_index_);

  // 先主动调用一次更新
  LOG(INFO) << "begin to update news map";
  UpdateNewsMapProcess();
  LOG(INFO) << "first time update news map done, and sort thread started.";

  update_news_map_thread_.Start(NewCallback(this, &reco::news_map::NewsMapStrategy::UpdateNewsMapThread));
}

void NewsMapStrategy::Stop() {
  update_news_map_thread_stop_ = true;
  if (FLAGS_update_news_map_interval_second >= 0) {
    update_news_map_thread_.Join();
  }

  if (news_map_updater_) {
    delete news_map_updater_;
    news_map_updater_ = NULL;
  }

  news_index_ = NULL;
}

void NewsMapStrategy::UpdateNewsMapThread() {
  static int64 last_timestamp = 0;

  while (!update_news_map_thread_stop_) {
    if (base::GetTimestamp() - last_timestamp > FLAGS_update_news_map_interval_second * 1e6) {
      LOG(INFO) << "update news map because sleep time up";
      last_timestamp = base::GetTimestamp();

      if (!UpdateNewsMapProcess()) {
        LOG(ERROR) << "update news map failed";
      }
    }

    base::SleepForSeconds(1);
  }
}

bool NewsMapStrategy::UpdateNewsMapProcess() {
  thread::AutoLock lock(&update_news_map_mutex_);
  if (!IsIndexDictCanSwitch()) {
    LOG(WARNING) << "not ready for switch";
    return true;
  }
  std::unordered_map<int64, std::vector<ItemInfo> >* news_map_index = news_map_index_.GetInactiveDict();
  if (!news_map_index) {
    LOG(INFO) << "news map index failed";
    return false;
  }
  news_map_index->clear();
  news_map_updater_->Update(news_map_index);
  news_map_index_.SwitchDict();
  return true;
}

bool NewsMapStrategy::IsIndexDictCanSwitch() {
  return news_map_index_.CanSwitch();
}

void NewsMapStrategy::GetNewsMap(const reco::leafserver::NewsMapRequest* request,
                                 reco::leafserver::NewsMapResponse* response) {
  CHECK(request && response);
  if (request->request_type() == reco::leafserver::NewsMapRequest::kGetUserPOIInfo) {
    GetUserPOIInfo(request, response);
  } else if (request->request_type() == reco::leafserver::NewsMapRequest::kGetPOINewsCount) {
    GetPOINewsCount(request, response);
  } else if (request->request_type() == reco::leafserver::NewsMapRequest::kGetPOINewsList) {
    GetPOINewsList(request, response);
  }
}

void NewsMapStrategy::GetUserPOIInfo(const reco::leafserver::NewsMapRequest* request,
                                     reco::leafserver::NewsMapResponse* response) {
  // 优选使用用户主动选择的城市
  int64 adcode = -1;
  if (request->has_channel_region_id() && !request->channel_region_id().empty()) {
    std::string literal;
    std::string str_adcode = reco::common::RegionSearcher::instance().
        SearchRegionCodeCorrespondAdcode(request->channel_region_id());
    if (base::StringToInt64(str_adcode, &adcode)) {
      if (!reco::poi::CityAreaHashSearcher::instance().GetAdminNameByID(adcode, &literal)) {
        LOG(WARNING) << "get admin name fail: " << adcode;
        return;
      }
      if (!UpdateNewsMap::IsNewsMapCity(adcode)) {
        LOG(WARNING) << "not in news map city list: " << adcode;
        return;
      }
      auto poi_tag = response->mutable_poi_tag();
      poi_tag->set_id(adcode);
      poi_tag->set_literal(literal);
      poi_tag->set_poi_tag_type(reco::leafserver::POITag::kCityPOITag);
      response->set_success(true);
    } else {
      LOG(WARNING) << "convert to adcode fail: " << request->channel_region_id();
    }
  } else {
    VLOG(1) << "channel region id empty";
  }

  if (!request->has_uc_user_param()) {
    VLOG(1) << "request has no uc_user_param";
    return;
  }
  auto &uc_user_param = request->uc_user_param();
  if (!uc_user_param.has_latitude() || !uc_user_param.has_longitude()) {
    VLOG(1) << "request has no latitude or longitude";
    return;
  }

  // 根据经纬度进行定位
  const double &latitude = uc_user_param.latitude();
  const double &longitude = uc_user_param.longitude();
  reco::poi::AreaInfo area_info;
  if (!reco::poi::CityAreaHashSearcher::instance().GetAreaInfoByCoord(latitude, longitude, &area_info)) {
    VLOG(1) << "get area info by coord fail: " << latitude << ", " << longitude;
    return;
  }

  if (area_info.area_id > 0) {
    int64 region_id = area_info.area_id / 100;
    // 用户主动选择的城市和定位到的城市不一致，以主动选择的城市为准
    if (adcode > 0 && !UpdateNewsMap::IsSameCity(region_id, adcode)) {
      VLOG(1) << "region_id not same: " << region_id << ", " << adcode;
      return;
    }
    // 不在热点地图城市列表中，则返回失败
    if (!UpdateNewsMap::IsNewsMapCity(region_id)) {
      VLOG(1) << "region not in news map city list: " << region_id;
      return;
    }

    std::string literal;
    int64 prov_id = region_id / 10000 * 10000;
    if (poi::CityAreaHashDict::IsDirectCity(prov_id)) {
      // 直辖市的话，province 填的是市名
      literal = area_info.province + area_info.district + area_info.area;
    } else {
      literal = area_info.city + area_info.district + area_info.area;
    }
    auto poi_tag = response->mutable_poi_tag();
    poi_tag->set_id(area_info.area_id);
    poi_tag->set_literal(literal);
    poi_tag->set_poi_tag_type(reco::leafserver::POITag::kShangQuanPOITag);
    response->set_success(true);
    return;
  }

  if (area_info.district_id > 0) {
    // 用户主动选择的城市和定位到的城市不一致，以主动选择的城市为准
    if (adcode > 0 && !UpdateNewsMap::IsSameCity(area_info.district_id, adcode)) return;
    // 不在热点地图城市列表中，则返回失败
    if (!UpdateNewsMap::IsNewsMapCity(area_info.district_id)) return;
    std::string literal;
    int prov_id = area_info.district_id / 10000 * 10000;
    if (poi::CityAreaHashDict::IsDirectCity(prov_id)) {
      // 直辖市的话，province 填的是市名
      literal = area_info.province + area_info.district;
    } else {
      literal = area_info.city + area_info.district;
    }
    auto poi_tag = response->mutable_poi_tag();
    poi_tag->set_id(area_info.district_id);
    poi_tag->set_literal(literal);
    poi_tag->set_poi_tag_type(reco::leafserver::POITag::kDistrictPOITag);
    response->set_success(true);
  }
  LOG(INFO) << response->Utf8DebugString();
}

bool NewsMapStrategy::GetRegionIDFromRequest(const reco::leafserver::NewsMapRequest* request,
                                             int64 *region_id) {
  if (!request->has_region_id() && !request->has_channel_region_id()) {
    LOG(ERROR) << "region_id and channel_region_id both empty";
    return false;
  }

  if (!request->has_channel_region_id() || request->channel_region_id().empty()) {
    *region_id = request->region_id();
    if ((*region_id) < 0) return false;
    return true;
  }

  int64 adcode;
  std::string str_adcode = reco::common::RegionSearcher::instance().SearchRegionCodeCorrespondAdcode(
      request->channel_region_id());
  if (!base::StringToInt64(str_adcode, &adcode)) {
    *region_id = request->region_id();
    if ((*region_id) < 0) return false;
    return true;
  }

  *region_id = adcode;
  // 如果 region_id 和 channel_region_id 冲突的话，以 channel_region_id 为准
  if (request->has_region_id()) {
    int64 raw_region_id = request->region_id();
    if (poi::CityAreaHashDict::IsDirectCity(raw_region_id)) {
      if ((raw_region_id / 10000) == (adcode / 10000)) {
        *region_id = raw_region_id;
      }
    } else {
      if ((raw_region_id / 100) == (adcode / 100)) {
        *region_id = raw_region_id;
      }
    }
  }
  return true;
}

void NewsMapStrategy::GetPOINewsCount(const reco::leafserver::NewsMapRequest* request,
                                      reco::leafserver::NewsMapResponse* response) {
  int64 region_id;
  if (!GetRegionIDFromRequest(request, &region_id)) {
    response->set_success(false);
    response->set_err_message("request region id is invalid !");
    LOG(INFO) << "get POI news count fail: region_id setting error";
    return;
  }

  int64 district_id = (region_id > 10000000) ? region_id / 100 : region_id;
  int64 prov_id = district_id / 10000 * 10000;
  int64 city_id = poi::CityAreaHashDict::IsDirectCity(prov_id) ? prov_id : district_id / 100 * 100;

  std::unordered_set<int64> next_layer_region_ids;
  reco::poi::CityAreaHashSearcher::instance().GetSubAdminIDs(city_id, &next_layer_region_ids);
  if (next_layer_region_ids.size() == 0) {
    response->set_success(false);
    response->set_err_message("request region id has no next layer!");
    LOG(INFO) << "get POI news count fail: next layer null";
    return;
  }

  auto dict = news_map_index_.GetDict();
  for (auto it = next_layer_region_ids.begin(); it != next_layer_region_ids.end(); ++it) {
    double lng, lat;
    if (!reco::poi::CityAreaHashSearcher::instance().GetAdminCoordinate(*it, &lat, &lng) ||
        (lng == 0 || lat == 0)) {
      LOG(WARNING) << "get admin coordinate fail: " << *it;
      continue;
    }

    int news_count = 0;
    auto it_tmp = dict->find(*it);
    if (it_tmp != dict->end()) {
      news_count = (int)it_tmp->second.size();
    }

    if (news_count > 0) {
      auto poi_news_count = response->add_poi_news_count();
      poi_news_count->set_latitude(lat);
      poi_news_count->set_longitude(lng);
      poi_news_count->set_news_count(news_count);

      std::string literal;
      reco::poi::CityAreaHashSearcher::instance().GetAdminNameByID(*it, &literal);
      auto poi_tag = poi_news_count->mutable_poi_tag();
      poi_tag->set_id(*it);
      poi_tag->set_literal(literal);
      poi_tag->set_poi_tag_type(reco::leafserver::POITag::kDistrictPOITag);
    }
    LOG(INFO) << "get news count success: " << request->region_id()
              << ", next_layer_region_ids: " << *it << ", lng: " << lng << ", lat: " << lat
              << ", news_count: " << news_count;
  }
  if (response->poi_news_count_size() > 0) {
    response->set_success(true);
  }
}

void NewsMapStrategy::GetPOINewsList(const reco::leafserver::NewsMapRequest* request,
                                     reco::leafserver::NewsMapResponse* response) {
  if (!request->has_region_id() || request->region_id() <= 0) {
    std::string err_msg = "region id is invalid";
    response->set_err_message(err_msg);
    LOG(INFO) << "get POI news list fail: " + err_msg;
    return;
  }

  int64 region_id = request->region_id();
  auto dict = news_map_index_.GetDict();
  auto it = dict->find(region_id);
  if (it == dict->end() || it->second.empty()) {
    std::string err_msg = "region id has no poi news: " + region_id;
    response->set_err_message(err_msg);
    LOG(INFO) << "get POI news list fail: " + err_msg;
    return;
  }

  std::vector<std::string> title_unigrams;
  std::vector<reco::Category> categories;
  std::string snd_category_str;

  const std::vector<ItemInfo>* item_info = &(it->second);
  for (auto it = item_info->begin(); it != item_info->end(); it++) {
    auto poi_item = response->add_poi_items();
    poi_item->set_item_id(it->item_id);
    poi_item->set_outer_id(base::Uint64ToString(it->item_id));
    poi_item->set_reco_id(request->reco_id());
    poi_item->set_parent_id(news_index_->GetParentId(it->item_id));
    int64 timestamp = news_index_->GetCreateTimestampByItemId(it->item_id);
    poi_item->set_create_timestamp(timestamp);
    if (timestamp > 0) {
      base::Time time = base::Time::FromDoubleT(timestamp / base::Time::kMicrosecondsPerSecond);
      time.ToStringInSeconds(poi_item->mutable_create_time());
    }

    title_unigrams.clear();
    if (!news_index_->GetAreaUnigramsByDocId(it->doc_id, adsindexing::kTitleArea, &title_unigrams)) { }
    poi_item->set_title(base::JoinStrings(title_unigrams, ""));

    poi_item->set_strategy_type(it->strategy_type);
    poi_item->set_show_num(it->show_num);
    poi_item->set_click_num(it->click_num);
    poi_item->set_reco_score(it->reco_score);

    categories.clear();
    snd_category_str.clear();
    if (!news_index_->GetCategoriesByItemId(it->item_id, &categories)) {
      LOG(ERROR) << "failed to get title id" << it->item_id;
    }
    for (int j = 0; j < (int)categories.size(); ++j) {
      poi_item->add_category(categories[j].category());
      if (categories[j].level() == 1) {
        snd_category_str = categories[j].category();
      }
    }

    GaoDePOI gaode_poi;
    if (news_index_->GetGaoDePOIByDocId(it->doc_id, &gaode_poi)) {
      if (gaode_poi.shangquan_poiinfos_size() > 0) {
        auto &literal = gaode_poi.shangquan_poiinfos(0).name();
        auto subscript = poi_item->mutable_subscript();
        subscript->set_type(reco::kRegionHotSubscript);
        subscript->set_desc(literal);
      }
    }
  }

  if (response->poi_items_size() > 0) {
    response->set_success(true);
  }
}
}  // namespace news_map
}  // namespace reco
