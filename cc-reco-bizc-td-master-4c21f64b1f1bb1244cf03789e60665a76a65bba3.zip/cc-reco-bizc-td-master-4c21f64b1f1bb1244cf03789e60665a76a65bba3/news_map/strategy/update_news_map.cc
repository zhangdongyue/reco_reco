#include "reco/bizc/news_map/strategy/update_news_map.h"
#include <algorithm>
#include <functional>
#include "reco/bizc/poi/city_area_hash_dict.h"

namespace reco {
namespace leafserver {

DECLARE_double(mid_timelevel_boost);
DECLARE_double(low_timelevel_boost);
}

namespace news_map {
const std::unordered_set<int64> UpdateNewsMap::kNewsMapCitySet = {
  110000,   // 北京
  310000,   // 上海
  440100,   // 广州
  440300,   // 深圳
  330100,   // 杭州
};

bool UpdateNewsMap::IsNewsMapCity(int64 city_id) {
  int64 prov_id = city_id / 10000 * 10000;
  bool is_direct_city = poi::CityAreaHashDict::IsDirectCity(prov_id);
  int64 region_id = is_direct_city ? prov_id : (city_id / 100 * 100);
  if (kNewsMapCitySet.find(region_id) != kNewsMapCitySet.end()) return true;
  return false;
}

bool UpdateNewsMap::IsSameCity(int64 city_a, int64 city_b) {
  int64 prov_a = city_a / 10000 * 10000;
  int64 prov_b = city_b / 10000 * 10000;
  int64 city_id_a = poi::CityAreaHashDict::IsDirectCity(prov_a) ? prov_a : (city_a / 100 * 100);
  int64 city_id_b = poi::CityAreaHashDict::IsDirectCity(prov_b) ? prov_b : (city_b / 100 * 100);
  return (city_id_a == city_id_b);
}

const std::unordered_set<std::string> UpdateNewsMap::kValideCategorySet = {"国内", "社会"};

UpdateNewsMap::UpdateNewsMap(const reco::NewsIndex* news_index) : news_index_(news_index) {
}

void UpdateNewsMap::Update(std::unordered_map<int64, std::vector<ItemInfo> >* news_map_index) {
  CHECK(news_map_index);
  news_map_index->clear();

  std::vector<ItemInfo> poi_items;
  for (auto city_iter = kNewsMapCitySet.begin(); city_iter != kNewsMapCitySet.end(); ++city_iter) {
    int64 city_id = *city_iter;
    std::unordered_set<int64> district_ids;
    reco::poi::CityAreaHashSearcher::instance().GetSubAdminIDs(city_id, &district_ids);

    for (auto district_iter = district_ids.begin(); district_iter != district_ids.end(); ++district_iter) {
      int64 district_id = *district_iter;
      poi_items.clear();
      GetNewsMap(district_id, &poi_items);
      if ((int)poi_items.size() > kMinPOIItemSize) {
        news_map_index->insert(make_pair(district_id, poi_items));
      }

      std::unordered_set<int64> area_ids;
      reco::poi::CityAreaHashSearcher::instance().GetSubAdminIDs(district_id, &area_ids);
      for (auto area_iter = area_ids.begin(); area_iter != area_ids.end(); ++area_iter) {
        int64 area_id = *area_iter;
        poi_items.clear();
        news_map_index->insert(make_pair(area_id, poi_items));
      }
    }
  }
}
bool NewsMapItemSortFunc(const ItemInfo& left, const ItemInfo& right) {
  if (left.ctr != right.ctr) return left.ctr > right.ctr;
  if (left.time_level != right.time_level) return left.time_level > right.time_level;
  if (left.hot_level  != right.hot_level)  return left.hot_level > right.hot_level;
  if (left.spider_score != right.spider_score) return left.spider_score > right.spider_score;
  if (left.site_level != right.site_level) return left.site_level > right.site_level;
  if (left.create_timestamp != right.create_timestamp) return left.create_timestamp > right.create_timestamp;
  return left.doc_id < right.doc_id;
}

void UpdateNewsMap::GetNewsMap(int64 area_id, std::vector<ItemInfo> *poi_items) {
  poi_items->clear();
  GetLocalNewsCandidates(area_id, poi_items);

  std::sort(poi_items->begin(), poi_items->end(), std::greater<ItemInfo>());
}

void UpdateNewsMap::GetLocalNewsCandidates(int64 area_id, std::vector<ItemInfo> *candidates) {
  candidates->clear();
  const std::vector<ItemInfo>* items = news_index_->GetPOIDefaultReco(area_id);
  if (!items) {
    LOG(INFO) << "no items, area_id:" << area_id;
    return;
  }

  std::vector<ItemInfo> org_candidates;
  std::unordered_set<uint64> dedup_dict;
  for (size_t i = 0; i < items->size(); ++i) {
    const ItemInfo& item = (*items)[i];
    if (dedup_dict.find(item.item_id) != dedup_dict.end()) {
      VLOG(1) << "item deduped: " << item.item_id;
      continue;
    }

    if (FilterByItemQuality(item)) {
      VLOG(1) << "filtered by quality: " << item.item_id;
      continue;
    }

    if (FilterBySensitive(item)) {
      VLOG(1) << "filtered by sensitive: " << item.item_id;
      continue;
    }

    if (IsGeneralFiltered(item)) {
      VLOG(1) << "general filtered: " << item.item_id;
      continue;
    }

    org_candidates.push_back(item);
    org_candidates.back().strategy_type = reco::kGeo;
    org_candidates.back().reco_score = CalcRecoScore(item);

    const std::set<uint64>* sim_items = news_index_->GetSimItemIds(item.item_id);
    if (sim_items != NULL) {
      for (auto it = sim_items->begin(); it != sim_items->end(); ++it) {
        dedup_dict.insert(*it);
      }
    }
  }

  DiversityFilter(org_candidates, candidates);
}

void UpdateNewsMap::DiversityFilter(const std::vector<ItemInfo> &org_candidates,
                                    std::vector<ItemInfo> *candidates) {
  std::vector<std::unordered_map<std::string, float> > item_feas_vec(org_candidates.size());
  for (size_t i = 0; i < org_candidates.size(); ++i) {
    GetItemSimFeas(org_candidates[i].item_id, &(item_feas_vec[i]));
  }
  for (size_t i = 0; i < org_candidates.size(); ++i) {
    bool is_filtered = false;
    for (int j = i - 1; j >= 0; --j) {
      if (IsSimilarFea(item_feas_vec[i], item_feas_vec[j])) {
        VLOG(1) << "filtered by sim fea: " << org_candidates[i].item_id << ", " << org_candidates[j].item_id;
        is_filtered = true;
        break;
      }
    }
    if (is_filtered) continue;
    candidates->push_back(org_candidates[i]);
  }
}


int UpdateNewsMap::CalcRecoScore(const ItemInfo &item) {
  double reco_score = item.ctr;

  // 时效性调权
  if (item.time_level == reco::kMidTimeliness) {
    reco_score *= (1 + reco::leafserver::FLAGS_mid_timelevel_boost);
  } else if (item.time_level == reco::kBadTimeliness) {
    reco_score *= (1 + reco::leafserver::FLAGS_low_timelevel_boost);
  }

  // 对非国内，社会分类进行降权
  if (kValideCategorySet.find(item.category) == kValideCategorySet.end()) {
    static const double kCategoryDecay = -0.3;
    reco_score *= (1 + kCategoryDecay);
  }

  reco_score = std::max(0.0, std::min(1.0, reco_score));
  int score = static_cast<int>(reco_score * kRecoScoreFactor + 0.5);
  score = std::min(kRecoScoreFactor - 1, score);
  return score;
}

bool UpdateNewsMap::FilterByItemQuality(const ItemInfo &item) {
  reco::ContentAttr content_attr;
  bool is_trival = true;
  if (news_index_->GetContentAttrByDocId(item.doc_id, &content_attr, &is_trival) && !is_trival) {
    reco::ContentAttr::ContentAttrLevel level_thres = reco::ContentAttr::kSuspect;
    if (content_attr.has_erro_title()
        && content_attr.erro_title() >= level_thres) {
      return true;
    }
    if (content_attr.has_advertorial()
        && content_attr.advertorial() >= level_thres) {
      return true;
    }
    if (content_attr.has_short_content()
        && content_attr.short_content() >= level_thres) {
      return true;
    }
    if (content_attr.has_dedup_paragraph()
        && content_attr.dedup_paragraph() >= level_thres) {
      return true;
    }
    // NOTE(jianhuang) 标题党先只影响一线城市
    // TODO(jianhuang) 影响太大的化，放开限制，后续在后处理限制下发条数
    if (content_attr.has_bluffing_title()
        && content_attr.bluffing_title() >= reco::ContentAttr::kSuspect) {
      return true;
    }
    // NOTE(jianhuang) 低俗不下发：大城市 / 新用户 / 对低俗反感
    if (content_attr.has_dirty()
        && content_attr.dirty() >= reco::ContentAttr::kSuspect) {
      return true;
    }
  }
  return false;
}

bool UpdateNewsMap::FilterBySensitive(const ItemInfo &item) {
  if (item.sensitive_type == reco::kNoSensitive) return false;
  if (item.sensitive_type == reco::kCopyrightSensitive) return true;
  if (item.sensitive_type == reco::kHighPoliticsSensitive) return true;
  if (item.sensitive_type == reco::kPoliticsSensitive) return true;
  return false;
}

bool UpdateNewsMap::IsGeneralFiltered(const ItemInfo &item) {
  if (!news_index_->HasCheckedBySimServer(item.item_id)) {
    VLOG(2) << item.item_id << " has not checked by sim server.";
    return true;
  }

  if (item.category == "未分类") {
    return true;
  }

  if (kValideCategorySet.find(item.category) == kValideCategorySet.end()) {
    std::vector<int64> region_ids;
    if (!news_index_->GetTitleRegionIdByDocId(item.doc_id, &region_ids) ||
        region_ids.empty()) {
      return true;
    }
  }

  // 天气类的时效性不超过 24 小时
  bool has_weather_tag = false;
  reco::FeatureVector fea_vec;
  if (news_index_->GetFeatureVectorByItemId(item.item_id, reco::common::kSemanticTag, &fea_vec)) {
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      const reco::Feature& fea = fea_vec.feature(i);
      auto &tag_with_label = fea.literal();
      std::string tag = tag_with_label;
      if (base::StartsWith(tag_with_label, "label2:", true)) {
        tag = tag_with_label.substr(7);
      }
      if (tag == "天气") {
        has_weather_tag = true;
        break;
      }
    }
  }
  if (has_weather_tag) {
    if (item.time_level < reco::kGoodTimeliness) {
      VLOG(1) << "local channel filter, weather timeout: " << item.item_id;
      return true;
    }
  }

  if (item.show_num > 500 && item.ctr < 0.01) {
    return true;
  }
  return false;
}

bool UpdateNewsMap::GetAreaInfo(const ItemInfo &item,
                                std::string *area_name, int64 *area_id) {
  reco::GaoDePOI gaode_poi;
  if (!news_index_->GetGaoDePOIByDocId(item.doc_id, &gaode_poi)) {
    return false;
  }

  std::unordered_set<int64> area_ids;
  std::unordered_set<int64> district_ids;
  reco::poi::CityAreaHashSearcher::instance().GetItemAreaID(gaode_poi, &area_ids, &district_ids);
  if (area_ids.empty() || area_ids.size() > 1) return false;

  *area_id = *(area_ids.begin());
  reco::poi::AreaBaseInfo area_base_info;
  if (!reco::poi::CityAreaHashSearcher::instance().GetAreaBaseInfoByAreaID(*area_id, &area_base_info)) {
    return false;
  }
  *area_name = area_base_info.area_name;
  return true;
}

void UpdateNewsMap::GetItemSimFeas(uint64 item_id, std::unordered_map<std::string, float>* reco_feas) {
  reco_feas->clear();
  if (item_id == 0) return;

  // 获取 item 的 keyword 特征，用于本次推荐的相似性计算
  reco::FeatureVector kw_feas;
  if (!news_index_->GetFeatureVectorByItemId(item_id, reco::common::kKeyword, &kw_feas)) {
    LOG_EVERY_N(INFO, 100) << "get feature fail, itemid:" << item_id;
    return;
  }
  for (int i = 0; i < kw_feas.feature_size(); ++i) {
    const reco::Feature& fea = kw_feas.feature(i);
    (*reco_feas)[fea.literal()] += fea.weight();
  }
}

bool UpdateNewsMap::IsSimilarFea(const std::unordered_map<std::string, float>& fea1,
                                 const std::unordered_map<std::string, float>& fea2) {
  if (fea1.empty() || fea2.empty()) return false;

  float fea_wt1 = 0;
  float fea_wt2 = 0;
  for (auto iter1 = fea1.begin(); iter1 != fea1.end(); ++iter1) {
    fea_wt1 += iter1->second;
  }
  for (auto iter2 = fea2.begin(); iter2 != fea2.end(); ++iter2) {
    fea_wt2 += iter2->second;
  }

  if (fea_wt1 <= 0 || fea_wt2 <= 0) return true;

  float sim_wt1 = 0;
  float sim_wt2 = 0;
  for (auto iter1 = fea1.begin(); iter1 != fea1.end(); ++iter1) {
    auto iter2 = fea2.find(iter1->first);
    if (iter2 != fea2.end()) {
      sim_wt1 += iter1->second;
      sim_wt2 += iter2->second;
    }
  }
  const float kSimilarRatio = 0.75;
  if (sim_wt1 / fea_wt1 >= kSimilarRatio && sim_wt2 / fea_wt2 >= kSimilarRatio) {
    return true;
  }
  return false;
}

}
}
