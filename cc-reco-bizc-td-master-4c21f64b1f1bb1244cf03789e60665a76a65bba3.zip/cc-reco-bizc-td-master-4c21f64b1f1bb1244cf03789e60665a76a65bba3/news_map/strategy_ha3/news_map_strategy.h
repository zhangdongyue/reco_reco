#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include "base/common/base.h"
#include "base/time/time.h"
#include "reco/bizc/reco_index_ha3/news_index_ha3.h"
#include "base/common/basic_types.h"
#include "reco/base/common/singleton.h"
#include "reco/bizc/news_map/proto/news_map.pb.h"
#include "reco/bizc/news_map/strategy_ha3/update_news_map.h"

namespace reco {
class NewsIndex;
namespace news_map {

class NewsMapStrategy {
 public:
  NewsMapStrategy();
  ~NewsMapStrategy();

  void Start(reco::NewsIndex* index);
  void Stop();

  void GetNewsMap(const reco::leafserver::NewsMapRequest* request,
                  reco::leafserver::NewsMapResponse* response);

 private:
  void GetUserPOIInfo(const reco::leafserver::NewsMapRequest* request,
                      reco::leafserver::NewsMapResponse* response);
  void GetPOINewsCount(const reco::leafserver::NewsMapRequest* request,
                       reco::leafserver::NewsMapResponse* response);
  void GetPOINewsList(const reco::leafserver::NewsMapRequest* request,
                      reco::leafserver::NewsMapResponse* response);

  void UpdateNewsMapThread();
  // 新闻地图数据更新接口
  bool UpdateNewsMapProcess();
  bool IsIndexDictCanSwitch();

  bool GetRegionIDFromRequest(const reco::leafserver::NewsMapRequest* request,
                              int64 *region_id);

 private:
  reco::NewsIndex* news_index_;

  // update news map thread
  thread::Thread update_news_map_thread_;
  std::atomic_bool update_news_map_thread_stop_;
  thread::Mutex update_news_map_mutex_;

  DynamicDict<std::unordered_map<int64, std::vector<ItemInfo> > > news_map_index_;

  UpdateNewsMap *news_map_updater_;

  DISALLOW_COPY_AND_ASSIGN(NewsMapStrategy);
};

typedef reco::common::singleton_default<NewsMapStrategy> NewsMapProc;
}
}
