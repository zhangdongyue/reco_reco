#pragma once
#include "reco/bizc/news_map/proto/news_map.pb.h"

namespace reco {
class NewsIndex;

namespace news_map {
struct GlobalData;
class NewsMapStrategy;

class NewsMapController {
 public:
  explicit NewsMapController();
  ~NewsMapController();

  void GetNewsMap(const reco::leafserver::NewsMapRequest* request,
                  reco::leafserver::NewsMapResponse* response);

 private:
  GlobalData* global_data_;
  reco::NewsIndex *news_index_;
};
}
}
