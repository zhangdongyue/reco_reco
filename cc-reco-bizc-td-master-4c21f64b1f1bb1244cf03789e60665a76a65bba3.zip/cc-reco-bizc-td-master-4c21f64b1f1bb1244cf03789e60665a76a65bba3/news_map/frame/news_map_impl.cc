#include <string>
#include "reco/bizc/news_map/frame/news_map_impl.h"
#include "reco/bizc/news_map/frame/global_data.h"
#include "reco/bizc/news_map/frame/news_map_controller.h"

namespace reco {
namespace news_map {

NewsMapImpl::NewsMapImpl() {
}

NewsMapImpl::~NewsMapImpl() {
}

void NewsMapImpl::GetNewsMap(stumy::RpcController* controller,
                             const reco::leafserver::NewsMapRequest* request,
                             reco::leafserver::NewsMapResponse* response,
                             Closure* done) {
  ScopedClosure scoped_closure(done);
  response->set_success(false);
  response->set_reco_id(request->reco_id());

  std::string err_message;
  NewsMapController* news_map_controller = NewsMapDataManager::GetControllerItem();

  if (news_map_controller == NULL) {
    err_message = "news map server busy[news_map_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  news_map_controller->GetNewsMap(request, response);
  NewsMapDataManager::ReleaseControllerItem(news_map_controller);
}
}
}
