#include "reco/bizc/news_map/frame/news_map_controller.h"
#include "reco/bizc/reco_index/news_index_ha3.h"
#include "reco/bizc/news_map/frame/global_data.h"
#include "reco/bizc/news_map/strategy/news_map_strategy.h"

namespace reco {
namespace news_map {

NewsMapController::NewsMapController() {
  global_data_ = NewsMapDataManager::GetGlobalData();
  CHECK_NOTNULL(global_data_);
}

NewsMapController::~NewsMapController() {
  delete global_data_;
}

void NewsMapController::GetNewsMap(const reco::leafserver::NewsMapRequest* request,
                                   reco::leafserver::NewsMapResponse* response) {
  LOG(INFO) << request->Utf8DebugString();
  reco::news_map::NewsMapProc::instance().GetNewsMap(request, response);
}
}
}
