#include "base/common/base.h"
#include "serving_base/utility/signal.h"

#include "reco/bizc/index_monitor/api/index_monitor.h"

#include "reco/bizc/news_map/frame/global_data.h"
#include "reco/bizc/news_map/frame/news_map_impl.h"
#include "reco/bizc/news_map/frame/news_map_controller.h"
#include "reco/bizc/poi/city_area_hash_dict.h"
#include "reco/bizc/news_map/strategy/news_map_strategy.h"

DEFINE_int32(thread_num, 40, "thread num");
DEFINE_int32(port, 20024, "the port on which the serving application listens");
DEFINE_string(data_dir, "../data", "");

namespace reco {
namespace leafserver {
DEFINE_double(mid_timelevel_boost, -0.2, "");
DEFINE_double(low_timelevel_boost, -0.4, "");
DEFINE_double(jingpin_item_boost, 0.1, "high item reco score boost.");
DEFINE_double(rubbish_item_boost, -0.1, "midlow item reco score boost.");
DEFINE_double(hot_item_boost, 0.04, "manual item reco score boost.");
DEFINE_double(veryhigh_quality_item_boost, 0.04, "very high item reco score boost.");
DEFINE_double(high_quality_item_boost, 0.02, "high item reco score boost.");
DEFINE_double(midhigh_quality_item_boost, 0, "midhigh item reco score boost.");
DEFINE_double(midlow_quality_item_boost, -0.02, "midlow item reco score boost.");
DEFINE_double(low_quality_item_boost, -0.04, "low item reco score boost.");
}
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "news map server");

  CHECK(reco::poi::CityAreaHashSearcher::instance().Load(FLAGS_data_dir));

  reco::index_monitor::IndexMonitor monitor;
  monitor.Start();
  LOG(INFO) << "index monitor started";

  adsindexing::Index* index = monitor.GetIndex();
  reco::news_map::GlobalData global_data(index);
  LOG(INFO) << "global data init";

  serving_base::DataManangerConfig config;
  config.controller_item_num = FLAGS_thread_num;
  reco::news_map::NewsMapDataManager::Initialize(config, &global_data);
  LOG(INFO) << "data manager init";

  reco::news_map::NewsMapProc::instance().Start(global_data.news_index);

  reco::news_map::NewsMapImpl service;
  serving_base::ServerFrameConfig server_frame_config;
  server_frame_config.rpc_threads_num = FLAGS_thread_num;
  server_frame_config.rpc_server_port = FLAGS_port;
  server_frame_config.service = &service;
  server_frame_config.dict_manager = reco::news_map::NewsMapDataManager::GetDictManager();

  serving_base::ServerFrame server_frame(server_frame_config);
  server_frame.Start();
  LOG(INFO) << "server frame start";

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();
  server_frame.Stop();
  LOG(INFO) << "server frame stop";

  reco::news_map::NewsMapProc::instance().Stop();

  reco::news_map::NewsMapDataManager::Release();
  LOG(INFO) << "data manager release";

  std::cout << "server safe quit" << std::endl;
  return 0;
}
