#pragma once
namespace serving_base {
template<typename Controller, typename GlobalData>
class DataManager;
}

namespace reco {
class NewsIndex;
namespace news_map {

class NewsMapController;
struct GlobalData;
typedef serving_base::DataManager<NewsMapController, GlobalData> NewsMapDataManager;

struct GlobalData {
  GlobalData() {}
  explicit GlobalData(adsindexing::Index *ext_index);
  ~GlobalData();

 public:
  const adsindexing::Index* index;
  reco::NewsIndex *news_index;
  bool is_ext_index;
};
}
}
