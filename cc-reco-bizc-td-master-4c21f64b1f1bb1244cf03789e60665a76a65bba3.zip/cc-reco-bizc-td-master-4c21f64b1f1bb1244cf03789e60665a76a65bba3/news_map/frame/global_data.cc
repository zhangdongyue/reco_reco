#include "reco/bizc/news_map/frame/global_data.h"
#include "reco/bizc/reco_index/news_index_ha3.h"

namespace reco {
namespace news_map {

GlobalData::GlobalData(adsindexing::Index *ext_index)
    : index(ext_index), is_ext_index(true) {
  CHECK(index) << "index should not be NULL";
  news_index = reco::InitializeNewsIndex(index);
}

GlobalData::~GlobalData() {
  if (!is_ext_index) delete index;
  if (news_index) delete news_index;
}
}
}
