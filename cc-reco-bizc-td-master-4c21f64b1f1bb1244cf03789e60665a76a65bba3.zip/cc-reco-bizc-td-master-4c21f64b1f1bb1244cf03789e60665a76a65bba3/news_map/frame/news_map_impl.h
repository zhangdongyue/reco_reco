#pragma once
#include "reco/bizc/news_map/proto/news_map.pb.h"

namespace reco {
namespace news_map {

class NewsMapImpl : public NewsMapService {
 public:
  NewsMapImpl();
  virtual ~NewsMapImpl();

  virtual void GetNewsMap(stumy::RpcController* controller,
                          const reco::leafserver::NewsMapRequest* request,
                          reco::leafserver::NewsMapResponse* response,
                          Closure* done);
};
}
}
