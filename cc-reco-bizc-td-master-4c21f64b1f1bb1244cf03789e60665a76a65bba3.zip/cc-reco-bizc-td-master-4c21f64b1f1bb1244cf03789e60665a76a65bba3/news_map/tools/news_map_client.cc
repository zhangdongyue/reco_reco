#include <iostream>
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/time/timestamp.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "reco/bizc/news_map/proto/news_map.pb.h"

DEFINE_string(server_ip, "127.0.0.1", "server ip");
DEFINE_int32(server_port, 20001, "server port");

DEFINE_int32(request_type, 0, "");

DEFINE_string(user_id, "", "user id");
DEFINE_string(app_token, "uc-iflow", "doc server ip");

DEFINE_string(province, "广东", "province name");
DEFINE_string(city, "广州", "city name");
DEFINE_double(user_latitude, 0, "");
DEFINE_double(user_longitude, 0, "");

DEFINE_int64(city_region_id, 110000, "city region id");
DEFINE_int64(district_region_id, 440103, "district region id");
DEFINE_int64(shangquan_region_id, 11010823, "shangquan region id");

bool GetPOINewsCount(std::vector<reco::leafserver::POINewsCount> *poi_news_counts) {
  uint64 uid;
  CHECK(base::StringToUint64(FLAGS_user_id, &uid));
  std::string key = base::StringPrintf("uid-%lu-%ld", uid, base::GetTimestamp());
  uint64 reco_id = base::CalcTermSign(key.c_str(), key.size());

  reco::UserIdentity user;
  user.set_user_id(uid);
  user.set_app_token(FLAGS_app_token);
  user.set_outer_id(FLAGS_user_id);

  reco::leafserver::UcBrowserUserParam param;
  param.set_province(FLAGS_province);
  param.set_city(FLAGS_city);
  param.set_latitude(FLAGS_user_latitude);
  param.set_longitude(FLAGS_user_longitude);

  reco::leafserver::NewsMapRequest request;
  reco::leafserver::NewsMapResponse response;

  request.set_request_type(reco::leafserver::NewsMapRequest::kGetPOINewsCount);
  request.set_reco_id(base::Uint64ToString(reco_id));
  request.mutable_user()->CopyFrom(user);
  request.set_region_id(FLAGS_city_region_id);

  net::rpc::RpcClientChannel channel(FLAGS_server_ip.c_str(), FLAGS_server_port);
  CHECK(channel.Connect());
  reco::news_map::NewsMapService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  stub.GetNewsMap(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "get news map fail.";
    return false;
  }

  for (int i = 0; i < response.poi_news_count_size(); ++i) {
    poi_news_counts->push_back(response.poi_news_count(i));
  }
  return true;
}

bool GetPOINewsList(const reco::leafserver::POINewsCount &poi_news_count) {
  uint64 uid;
  CHECK(base::StringToUint64(FLAGS_user_id, &uid));
  std::string key = base::StringPrintf("uid-%lu-%ld", uid, base::GetTimestamp());
  uint64 reco_id = base::CalcTermSign(key.c_str(), key.size());

  reco::UserIdentity user;
  user.set_user_id(uid);
  user.set_app_token(FLAGS_app_token);
  user.set_outer_id(FLAGS_user_id);

  reco::leafserver::UcBrowserUserParam param;
  param.set_province(FLAGS_province);
  param.set_city(FLAGS_city);
  param.set_latitude(FLAGS_user_latitude);
  param.set_longitude(FLAGS_user_longitude);

  reco::leafserver::NewsMapRequest request;
  reco::leafserver::NewsMapResponse response;

  request.set_request_type(reco::leafserver::NewsMapRequest::kGetPOINewsList);
  request.set_reco_id(base::Uint64ToString(reco_id));
  request.mutable_user()->CopyFrom(user);
  request.set_region_id(poi_news_count.poi_tag().id());

  net::rpc::RpcClientChannel channel(FLAGS_server_ip.c_str(), FLAGS_server_port);
  CHECK(channel.Connect());
  reco::news_map::NewsMapService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  stub.GetNewsMap(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "get news map fail.";
    return false;
  }

  std::cout << poi_news_count.poi_tag().literal() << std::endl;
  for (int i = 0; i < response.poi_items_size(); ++i) {
    auto &item = response.poi_items(i);
    std::string str_category;
    for (int j = 0; j < item.category_size(); ++j) {
      str_category += item.category(j) + ",";
    }
    std::string subscript;
    if (item.has_subscript()) {
      subscript = item.subscript().desc();
    }
    std::cout << item.item_id() << '\t'
              << item.title() << '\t'
              << str_category << '\t'
              << item.create_time() << '\t'
              << (double)item.click_num() / item.show_num() << '\t'
              << subscript << '\t'
              << item.click_num() << '\t' << item.show_num() << '\t'
              << std::endl;
  }
  return true;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "news map client");
  if (FLAGS_request_type == 3) {
    std::vector<reco::leafserver::POINewsCount> poi_news_counts;
    GetPOINewsCount(&poi_news_counts);
    for (size_t i = 0; i < poi_news_counts.size(); ++i) {
      GetPOINewsList(poi_news_counts[i]);
    }
    return 0;
  }

  uint64 uid;
  CHECK(base::StringToUint64(FLAGS_user_id, &uid));
  std::string key = base::StringPrintf("uid-%lu-%ld", uid, base::GetTimestamp());
  uint64 reco_id = base::CalcTermSign(key.c_str(), key.size());

  reco::UserIdentity user;
  user.set_user_id(uid);
  user.set_app_token(FLAGS_app_token);
  user.set_outer_id(FLAGS_user_id);

  reco::leafserver::UcBrowserUserParam param;
  param.set_province(FLAGS_province);
  param.set_city(FLAGS_city);
  param.set_latitude(FLAGS_user_latitude);
  param.set_longitude(FLAGS_user_longitude);

  reco::leafserver::NewsMapRequest request;
  reco::leafserver::NewsMapResponse response;
  if (FLAGS_request_type == 0) {
    request.set_request_type(reco::leafserver::NewsMapRequest::kGetUserPOIInfo);
    request.set_reco_id(base::Uint64ToString(reco_id));
    request.mutable_user()->CopyFrom(user);
    request.mutable_uc_user_param()->CopyFrom(param);
  } else if (FLAGS_request_type == 1) {
    request.set_request_type(reco::leafserver::NewsMapRequest::kGetPOINewsCount);
    request.set_reco_id(base::Uint64ToString(reco_id));
    request.mutable_user()->CopyFrom(user);
    request.set_region_id(FLAGS_city_region_id);
  } else if (FLAGS_request_type == 2) {
    request.set_request_type(reco::leafserver::NewsMapRequest::kGetPOINewsList);
    request.set_reco_id(base::Uint64ToString(reco_id));
    request.mutable_user()->CopyFrom(user);
    request.set_region_id(FLAGS_shangquan_region_id);
  }
  std::cout << request.Utf8DebugString() << std::endl;

  net::rpc::RpcClientChannel channel(FLAGS_server_ip.c_str(), FLAGS_server_port);
  CHECK(channel.Connect());
  reco::news_map::NewsMapService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  stub.GetNewsMap(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "get news map fail.";
  }
  if (FLAGS_request_type == 0) {
    std::cout << response.Utf8DebugString() << std::endl;
  } else if (FLAGS_request_type == 1) {
    std::cout << response.Utf8DebugString() << std::endl;
  } else if (FLAGS_request_type == 2) {
    if (!response.success()) {
      std::cout << response.Utf8DebugString() << std::endl;
    } else {
      for (int i = 0; i < response.poi_items_size(); ++i) {
        auto &item = response.poi_items(i);
        std::string str_category;
        for (int j = 0; j < item.category_size(); ++j) {
          str_category += item.category(j) + ",";
        }
        std::string subscript;
        if (item.has_subscript()) {
          subscript = item.subscript().desc();
        }
        std::cout << item.item_id() << '\t'
                  << item.title() << '\t'
                  << str_category << '\t'
                  << item.create_time() << '\t'
                  << (double)item.click_num() / item.show_num() << '\t'
                  << subscript << '\t'
                  << item.click_num() << '\t' << item.show_num() << '\t'
                  << std::endl;
      }
    }
  }
  return 0;
}
