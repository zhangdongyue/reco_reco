#pragma once

#include "reco/base/common/atomic.h"
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <utility>

#include "base/common/basic_types.h"
#include "reco/bizc/reco_index_ha3/dynamic_dict.h"
#include "reco/bizc/reco_index_ha3/file_monitor.h"
#include "base/container/dense_hash_set.h"

namespace base {
class FilePath;
}

namespace reco {
namespace common {
class FilterDictSetMonitor : public FileMonitor {
 public:
  FilterDictSetMonitor();

  virtual ~FilterDictSetMonitor() {}

  // override
  virtual void LoadFile();

  const base::dense_hash_set<std::string>* GetDict() {
    return filter_dict_.GetDict();
  }

 private:
  DynamicDict<base::dense_hash_set<std::string>> filter_dict_;
};
}
}
