#include "reco/bizc/filter_dict_ha3/common_filter.h"

namespace reco {
namespace common {
DEFINE_string(black_source_file, "black_source_file.txt", "");
DEFINE_string(white_source_file, "white_source_file.txt", "");
DEFINE_string(main_city_file, "main_city_file.txt", "");
DEFINE_string(politics_source_file, "politics_source_file.txt", "");
DEFINE_string(reviewed_filter_city_dict, "reviewed_filter_city.txt", "");

CommonFilter::CommonFilter(const std::string &data_dir)
    : black_source_dict(NULL), white_source_dict(NULL), main_city_dict(NULL) {
  black_source_dict = new FilterDictSetMonitor();
  black_source_dict->StartMonitorFile(base::FilePath(data_dir).Append(FLAGS_black_source_file));

  white_source_dict = new FilterDictSetMonitor();
  white_source_dict->StartMonitorFile(base::FilePath(data_dir).Append(FLAGS_white_source_file));

  main_city_dict = new FilterDictSetMonitor();
  main_city_dict->StartMonitorFile(base::FilePath(data_dir).Append(FLAGS_main_city_file));

  politics_source_dict = new FilterDictSetMonitor();
  politics_source_dict->StartMonitorFile(base::FilePath(data_dir).Append(FLAGS_politics_source_file));

  reviewed_filter_city = new FilterDictSetMonitor();
  reviewed_filter_city->StartMonitorFile(base::FilePath(data_dir).Append(FLAGS_reviewed_filter_city_dict));
}

CommonFilter::~CommonFilter() {
  if (black_source_dict) {
    black_source_dict->StopMonitorFile();
    delete black_source_dict;
    black_source_dict = NULL;
  }

  if (white_source_dict) {
    white_source_dict->StopMonitorFile();
    delete white_source_dict;
    white_source_dict = NULL;
  }

  if (main_city_dict) {
    main_city_dict->StopMonitorFile();
    delete main_city_dict;
    main_city_dict = NULL;
  }

  if (politics_source_dict) {
    politics_source_dict->StopMonitorFile();
    delete politics_source_dict;
    politics_source_dict = NULL;
  }

  if (reviewed_filter_city) {
    reviewed_filter_city->StopMonitorFile();
    delete reviewed_filter_city;
    reviewed_filter_city = NULL;
  }
}
}
}
