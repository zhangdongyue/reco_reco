#pragma once

#include <string>

#include "reco/bizc/filter_dict_ha3/filter_dict_set_monitor.h"

namespace reco {
namespace common {
struct CommonFilter {
  CommonFilter(const std::string &data_dir);
  ~CommonFilter();

  FilterDictSetMonitor *black_source_dict;
  FilterDictSetMonitor *white_source_dict;
  FilterDictSetMonitor *main_city_dict;
  FilterDictSetMonitor *politics_source_dict;
  FilterDictSetMonitor *reviewed_filter_city;
};
}
}
