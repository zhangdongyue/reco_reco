1. 仓库定位和主要模块介绍
==========================================

本仓库用于维护业务相关的基础模块，
比如 proto 定义，常量定义，业务公用基础组建等

"bizc" 的含义是 biz common

本仓库的原则
a. cc-reco-X 的其他模块中仅依赖 cc-reco-base

目前已有模块如下
├── common
    两类内容放到这里 define 和 util
    define 提供了需要给其他模块共享的定义
    util 提供了一些小工具（如果有明确功能的大工具请移出）
├── filter_dict
    业务过滤功能模块
├── index_monitor
    动态索引入库
├── item_service
    封装了基于 hbase 和 doc server 的 item 读写模块 
├── item_stat
    封装了基于 hbase 的 item 统计信息获取模块
├── news_map
    热点地图模块
├── poi
    地理位置点相关的基础功能，如 geohash 等
├── proto
    各种业务相关的 proto
├── reco_bow
    针对推荐场景的词向量模块
├── reco_index
    索引
├── reco_ner
    针对推荐场景的专名模块
├── reco_plsa
    针对推荐场景的 plsa 模块
├── reco_retrieval
    触发模块，后续会废弃
├── reco_splice
    针对推荐场景的词粘结模块
├── region
    地名相关的基础模块
└── user_lib
    封装了对 user server 和 profile server 用户信息的读取

2. 仓库本地配置
==========================================

首先需要 git clone git@gitlab.alibaba-inc.com:sm-xss/cc-pub.git
cc-pub 仓库提供了编译环境和基础库。请认真阅读 cc-pub 的 README

git clone git@gitlab.alibaba-inc.com:sm-xss/cc-reco-bizc.git
会得到 cc-reco-bizc 目录

在 cc-pub 下面新建一个 reco 文件夹 （reco 目录会被 cc-pub 这个仓库忽略）
然后通过符号链接或者 mv 的方式，把 cc-reco-bizc 仓库放到 reco 子目录下
最终目录结构如下

cc-pub
 ├──reco
     ├──bizc  -> cc-reco-bizc
