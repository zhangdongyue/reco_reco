#include "reco/bizc/reco_index/meta_info_algo.h"

#include <algorithm>
#include <string>
#include <utility>

#include "base/time/time.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/reco_index/news_index.h"
#include "serving_base/utility/timer.h"

DEFINE_int32(yuanchuang_wemedia_item_incr_show, 5000, "good wemedia item show incr num.");
DEFINE_double(wemedia_default_ctr, 0.15, "wemedia incr stats's ctr.");
DEFINE_double(source_ctr_influence_ratio, 0.2, "source ctr influence ratio");
DEFINE_int32(wemedia_show_ctrl_threshold, 1000000, "wemedia show ctrl threshold");
DEFINE_int32(wemedia_show_ctrl_max_threshold, 8000000, "wemedia show ctrl max threshold");
DEFINE_double(wemedia_show_ctrl_good_media_alpha, 0.20, "wemedia show ctrl good media alpha");
DEFINE_double(wemedia_show_ctrl_normal_media_alpha, 0.25, "wemedia show ctrl normal media alpha");
DEFINE_double(wemedia_show_ctrl_low_media_alpha, 0.30, "wemedia show ctrl low media alpha");
DEFINE_double(wemedia_show_ctrl_bad_media_alpha, 0.35, "wemedia show ctrl bad media alpha");
DEFINE_double(wemedia_show_ctrl_quality_suspect_alpha, 0.35, "wemedia show ctrl quality suspect bad alpha");
DEFINE_double(wemedia_show_ctrl_quality_sure_alpha, 0.45, "wemedia show ctrl quality sure bad alpha");
DEFINE_double(wemedia_show_ctrl_max_threshold_alpha, 0.3f, "wemedia show ctrl max threshold alpha");
DEFINE_double(wemedia_init_ctr_weight, 1.5, "wemedia init ctr weight");
DEFINE_double(wemedia_bad_itemq_boost, 0.7, "wemedia bad itemq boost");
DEFINE_double(wemedia_low_quality_ratio_boost, 0.8, "wemedia low quality ratio boost");
DEFINE_double(wemedia_much_low_quality_boost, 0.8, "wemedia mutch low quality boost");

namespace reco {

WemediaBooster::WemediaBooster(const NewsIndex* news_index) {
  news_index_ = news_index;
}

WemediaBooster::~WemediaBooster() {}

bool WemediaBooster::WemediaBoost(const ItemInfo& item_info, int32* incr_show, int32* incr_click) {
  std::string wemedia_person;
  if (!news_index_->GetWeMediaPersonByDocId(item_info.doc_id, &wemedia_person)) {
    return false;
  }
  if (news_index_->IsYuanchuangDocId(item_info.doc_id)) {
    (*incr_show) += FLAGS_yuanchuang_wemedia_item_incr_show;
  }
  float ctr = FLAGS_wemedia_default_ctr;
  IndexDictManager::WemediaMeta wemedia_meta;
  if (news_index_->GetWemediaMeta(wemedia_person, &wemedia_meta)
      && wemedia_meta.normal_show_num > 100000) {
    ctr = wemedia_meta.normal_ctr * FLAGS_wemedia_init_ctr_weight;
    ctr = std::max(0.01f, ctr);
    VLOG(2) << "wemedia_meta_init: " << wemedia_person
              << ", " << item_info.item_id << ", " << wemedia_person
              << ", " << wemedia_meta.normal_ctr
              << ", " << ctr
              << ", " << wemedia_meta.low_quality_ratio
              << ", " << wemedia_meta.low_show_num
              << ", " << wemedia_meta.normal_show_num;
  }
  VLOG(2) << "wemedia_boost: item_id=" << item_info.item_id
          << ", incr_show=" << *incr_show
          << ", ctr:" << ctr;
  (*incr_click) = (*incr_show) * ctr;

  return true;
}

void WemediaBooster::QuantityControl(ItemInfo* item_info) {
  // 自媒体控量
  if (item_info->is_source_wemedia && item_info->show_num > FLAGS_wemedia_show_ctrl_threshold) {
    double alpha = FLAGS_wemedia_show_ctrl_normal_media_alpha;
    if (item_info->media_level >= reco::kGoodMedia) {
      alpha = FLAGS_wemedia_show_ctrl_good_media_alpha;
    } else if (item_info->media_level == reco::kNormalMedia) {
      alpha = FLAGS_wemedia_show_ctrl_normal_media_alpha;
    } else if (item_info->media_level == reco::kLowMedia) {
      alpha = FLAGS_wemedia_show_ctrl_low_media_alpha;
    } else if (item_info->media_level == reco::kBadMedia) {
      alpha = FLAGS_wemedia_show_ctrl_bad_media_alpha;
    }
    if (item_info->show_num > FLAGS_wemedia_show_ctrl_max_threshold) {
      alpha = std::max(alpha, FLAGS_wemedia_show_ctrl_max_threshold_alpha);
    }

    reco::ContentAttr content_attr;
    bool is_trival;
    news_index_->GetContentAttrByDocId(item_info->doc_id, &content_attr, &is_trival);
    if (!is_trival) {
      // 都设置了默认值了
      if (content_attr.erro_title() == reco::ContentAttr::kSuspect
          || content_attr.advertorial() == reco::ContentAttr::kSuspect
          || content_attr.short_content() == reco::ContentAttr::kSuspect
          || content_attr.dedup_paragraph() == reco::ContentAttr::kSuspect
          || content_attr.dirty() == reco::ContentAttr::kSuspect
          || content_attr.politics() == reco::ContentAttr::kSuspect
          || content_attr.bluffing_title() == reco::ContentAttr::kSuspect) {
        alpha = FLAGS_wemedia_show_ctrl_quality_suspect_alpha;
      }
      if (content_attr.erro_title() == reco::ContentAttr::kSureYes
          || content_attr.advertorial() == reco::ContentAttr::kSureYes
          || content_attr.short_content() == reco::ContentAttr::kSureYes
          || content_attr.dedup_paragraph() == reco::ContentAttr::kSureYes
          || content_attr.dirty() == reco::ContentAttr::kSureYes
          || content_attr.politics() == reco::ContentAttr::kSureYes
          || content_attr.bluffing_title() == reco::ContentAttr::kSureYes) {
        alpha = FLAGS_wemedia_show_ctrl_quality_sure_alpha;
      }
    }

    double ctr_boost = std::max(0.05, std::min(1.0, 1 - alpha
                      * std::log(item_info->show_num * 1.0 / FLAGS_wemedia_show_ctrl_threshold)));
    item_info->ctr *= ctr_boost;
    VLOG(2) << "wemedia_ctr " << base::StringPrintf("%lu %d %.4f %.4f %.4f %.4f %.4f %d %d",
                                 item_info->item_id, item_info->media_level,
                                 alpha, ctr_boost, item_info->ctr, item_info->ctr * ctr_boost,
                                 item_info->ctr, item_info->show_num, item_info->click_num);
  }
  // 文章质量降权
  if (item_info->itemq < 3 && item_info->show_num >= 100000) {
    item_info->ctr *= FLAGS_wemedia_bad_itemq_boost;
  }
  // 自媒体质量降权
  std::string wemedia_person;
  if (news_index_->GetWeMediaPersonByDocId(item_info->doc_id, &wemedia_person)) {
    IndexDictManager::WemediaMeta wemedia_meta;
    bool low_quality_ratio = false;
    bool low_quality_much_deliver = false;
    if (news_index_->GetWemediaMeta(wemedia_person, &wemedia_meta)
        && wemedia_meta.normal_show_num > 100000) {
      if (wemedia_meta.low_quality_ratio >= 0.8) {
        item_info->ctr *= FLAGS_wemedia_low_quality_ratio_boost;
        low_quality_ratio = true;
      }
      if (wemedia_meta.low_show_num > 2 * wemedia_meta.normal_show_num) {
        item_info->ctr *= FLAGS_wemedia_much_low_quality_boost;
        low_quality_much_deliver = true;
      }
    }
    VLOG(2) << "wemedia_a_ctr: " << item_info->item_id
            << ", " << wemedia_person
            << ", " << wemedia_meta.normal_ctr
            << ", " << item_info->ctr
            << ", " << wemedia_meta.low_quality_ratio
            << ", " << wemedia_meta.low_show_num
            << ", " << wemedia_meta.normal_show_num
            << ", " << low_quality_ratio
            << ", " << low_quality_much_deliver;
  }
}

// ------ DefaultCtrCalculator

DefaultCtrCalculator::DefaultCtrCalculator(const NewsIndex* news_index) {
  news_index_ = news_index;
}

DefaultCtrCalculator::~DefaultCtrCalculator() {}

void DefaultCtrCalculator::Train(const std::vector<reco::ItemInfo>& items) {
  base::Time expire_time = base::Time::Now() - base::TimeDelta::FromDays(30);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  serving_base::Timer timer;
  timer.Start();
  // 基于类别 / 源 的数据统计
  std::unordered_map<std::string, std::pair<uint64, uint64> > feature_stats;
  std::string source;
  for (size_t idx = 0; idx < items.size(); ++idx) {
    const ItemInfo& item = items[idx];
    // 过滤条件
    if (item.create_timestamp < expire_timestamp) continue;
    const std::string& category = item.category;
    if (category.empty()) continue;
    const std::string& sub_category = item.sub_category;
    if (item.show_num < item.click_num) continue;
    // 生成单维度特征特征
    std::vector<std::string> features;
    if (!sub_category.empty()) {
      features.push_back("C2:" + category + "," + sub_category);
    }
    features.push_back("C:" + category);

    if (news_index_->GetSourceByDocId(item.doc_id, &source) && !source.empty()) {
      features.push_back("S:" + source);
    }
    std::string source_media;
    if ((news_index_->GetOrigSourceMediaByDocId(item.doc_id, &source_media) && !source_media.empty())
      || (news_index_->GetSourceMediaByDocId(item.doc_id, &source_media) && !source_media.empty())) {
      features.push_back("M:" + source_media);
    }
    // 生成组合特征
    if (!source_media.empty()) {
      features.push_back("M_C:" + source_media + "," + category);
    }
    if (!source_media.empty() && !sub_category.empty()) {
      features.push_back("M_C2:" + source_media + "," + category + "," + sub_category);
    }
    // 特征统计
    for (auto feature = features.begin(); feature != features.end(); ++feature) {
      feature_stats[*feature].first += item.show_num;
      feature_stats[*feature].second += item.click_num;
    }
  }

  // 计算特征的平均点击率
  for (auto iter = feature_stats.begin(); iter != feature_stats.end(); ++iter) {
    if (iter->second.first < 10000) continue;
    float ctr = std::min(1.0f, iter->second.second * 1.0f / iter->second.first);
    feature_ctr_map_.insert(std::make_pair(iter->first, ctr));
    VLOG(2) << "fea: " << iter->first
            << " " << iter->second.first << " " << iter->second.second << " " << ctr;
  }
  LOG(INFO) << "feature state of default rank, time=" << timer.Stop() << " us";
}

float DefaultCtrCalculator::Predict(const reco::ItemInfo& item_info) {
  float item_ctr = 0;
  float item_ratio = 0;
  const int32 kConfidenceShowNum = 1000;
  // 根据 item 后验数据的充分性，确定各维度的影响因子
  if (item_info.show_num > 0) {
    item_ctr = std::min(item_info.click_num * 1.0f / item_info.show_num, 1.0f);
    item_ratio = std::pow(item_info.show_num * 1.0f / kConfidenceShowNum, 0.5);
  }

  // 类别维度数据: 生成类别特征，获取特征值
  std::vector<std::string> category_feature;
  const std::string& category = item_info.category;
  const std::string& sub_category = item_info.sub_category;
  if (!sub_category.empty()) {
    category_feature.push_back("C2:" + category + "," + sub_category);
  }
  category_feature.push_back("C:" + category);

  std::string cate_fea;
  float category_ctr = SquashFeatureValue(feature_ctr_map_, category_feature, &cate_fea);

  // 源维度数据
  float source_ctr = 0;
  std::string source;
  if (news_index_->GetSourceByDocId(item_info.doc_id, &source) && !source.empty()) {
    auto source_iter = feature_ctr_map_.find("S:" + source);
    if (source_iter != feature_ctr_map_.end()) {
      source_ctr = source_iter->second;
    }
  }

  // 媒体维度数据：生成特征，获取特征值
  std::vector<std::string> media_feature;
  std::string source_media;
  if ((news_index_->GetOrigSourceMediaByDocId(item_info.doc_id, &source_media) && !source_media.empty())
     || (news_index_->GetSourceMediaByDocId(item_info.doc_id, &source_media) && !source_media.empty())) {
    if (!sub_category.empty()) {
      media_feature.push_back("M_C2:" + source_media + "," + category + "," + sub_category);
    }

    media_feature.push_back("M_C:" + source_media + "," + category);
    media_feature.push_back("M:" + source_media);
  }
  std::string media_cate_fea;
  float media_cate_ctr = SquashFeatureValue(feature_ctr_map_, media_feature, &media_cate_fea);

  // 综合 merge
  float source_infl_ratio = (1 - item_ratio) * FLAGS_source_ctr_influence_ratio;
  float category_infl_ratio = 1 - item_ratio - source_infl_ratio;

  float ctr =
    item_ctr * item_ratio + source_ctr * source_infl_ratio + category_ctr * category_infl_ratio;
  if (std::abs(media_cate_ctr) > 1e-6) {
    ctr = item_ctr * item_ratio + (1 - item_ratio) * media_cate_ctr;
  }
  VLOG(2) << "default_item_ctr " << base::StringPrintf("%lu %d %.4f %d %d"
                                    " %.4f (%s:%.4f) (%s:%.4f) (%s:%.4f)",
                                    item_info.item_id, item_info.time_level, ctr,
                                    item_info.show_num, item_info.click_num,
                                    item_ctr,
                                    source.c_str(), source_ctr,
                                    cate_fea.c_str(), category_ctr,
                                    media_cate_fea.c_str(), media_cate_ctr);
  return ctr;
}

float DefaultCtrCalculator::SquashFeatureValue(const std::unordered_map<std::string, float>& feature_model,
                                               const std::vector<std::string>& features,
                                               std::string* feature) {
  for (auto i = features.begin(); i != features.end(); ++i) {
    auto iter = feature_model.find(*i);
    if (iter != feature_model.end()) {
      *feature = iter->first;
      return iter->second;
    }
  }
  return 0.0f;
}

}  // namespace reco
