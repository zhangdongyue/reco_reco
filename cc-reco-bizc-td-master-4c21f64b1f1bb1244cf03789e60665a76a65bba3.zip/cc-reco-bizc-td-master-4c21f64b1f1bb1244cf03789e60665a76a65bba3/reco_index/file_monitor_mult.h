#pragma once

#include <cstdatomic>
#include <string>
#include <vector>

#include "base/common/sleep.h"
#include "base/thread/thread.h"
#include "base/file/file_path.h"
#include "base/common/closure.h"
#include "base/time/time.h"
#include "base/file/platform_file.h"

namespace reco {

template<class D>
class MultFileMonitor {
 public:
  MultFileMonitor() : stopped_(false), running_(false) {}

  virtual ~MultFileMonitor() {
    if (running_) {
      CHECK(stopped_);
    }
  }

  typedef void (D::*LoadFileFunc)(const base::FilePath&);

  // API 函数,传入一个文件路径/重载间隔/重载调用的函数,就会开始监控改文件变化
  // 为了兼容各种启动顺序要求,调用本函数的时候,会先执行一次文件加载,再返回
  bool AddFileMonitor(const base::FilePath& file_path, int reload_interval, LoadFileFunc LoadFile) {
    if (stopped_) return false;

    running_ = true;

    // execute LoadFileFunc once
    ((D*)this->*LoadFile)(file_path);  // NOLINT

    thread::Thread* thd = new thread::Thread();
    threads_.push_back(thd);
    thd->Start(::NewCallback(this, &MultFileMonitor::MonitorThread, file_path, reload_interval, LoadFile));
    return true;
  }

  void StopMultFileMonitor() {
    stopped_ = true;
    for (auto it = threads_.begin(); it != threads_.end(); it++) {
      (*it)->Join();
    }
  }

 private:
  virtual void MonitorThread(base::FilePath file_path, int reload_interval, LoadFileFunc LoadFile) {
    LOG(INFO) << "start monitor thread for file " << file_path.ToString();

    base::Time last_modify_time = base::Time::UnixEpoch();
    while (!stopped_) {
      base::PlatformFileError error_code;
      base::PlatformFile platform_file = base::CreatePlatformFile(file_path,
                                                  base::PLATFORM_FILE_OPEN|base::PLATFORM_FILE_READ,
                                                  NULL, &error_code);
      if (error_code != base::PLATFORM_FILE_OK) {
        LOG(ERROR) << "failed to open: " << file_path.ToString();
        base::SleepForSeconds(kSleepSeconds);
        continue;
      }

      base::PlatformFileInfo platform_file_info;
      if (!base::GetPlatformFileInfo(platform_file, &platform_file_info)) {
        LOG(ERROR) << "failed to get file info: " << file_path.ToString();
        base::ClosePlatformFile(platform_file);
        base::SleepForSeconds(kSleepSeconds);
        continue;
      }

      bool modified = platform_file_info.last_modified > last_modify_time;
      if (modified) {
        std::string time_str;
        last_modify_time.ToStringInSeconds(&time_str);
        LOG(INFO) << "modified since " << time_str << ", start reading new version...";

        ((D*)this->*LoadFile)(file_path);  // NOLINT

        last_modify_time = platform_file_info.last_modified;
        LOG(INFO) << "done loading new version of file " << file_path.ToString();
      } else {
        base::SleepForSeconds(reload_interval);
      }

      bool suc = base::ClosePlatformFile(platform_file);
      if (!suc) {
        LOG(ERROR) << "failed to close: " << file_path.ToString();
      }
    }

    LOG(INFO) << "monitor thread stopped for file " << file_path.ToString();
  }

  static const int64 kSleepSeconds = 5;
  std::vector<thread::Thread*> threads_;

  std::atomic_bool stopped_;
  std::atomic_bool running_;
};
}  // namespace reco
