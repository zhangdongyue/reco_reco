#pragma once

#include "reco/base/common/atomic.h"
#include <string>

#include "base/common/sleep.h"
#include "base/thread/thread.h"
#include "base/file/file_path.h"
#include "base/common/closure.h"
#include "base/time/time.h"
#include "base/file/platform_file.h"

namespace reco {
/**
 * 监控词表，自动重载
 * 这个类主要实现监控文件修改状态的功能，
 * 词表加载需要继承类重载实现 LoadFile 方法
 *
 * 可以参考 reco_index/source_manager.h
 * 使用方法
 * 1. 继承 FileNonitor 并重载 LoadFile
 * 2. 程序启动时调用 StartMonitorFile 来启动监控线程
 * 3. 程序退出前调用 StopMonitorFile 来结束监控线程
 *
 * 2 和 3 本来希望放在构造和析构函数里自动完成
 * 但由于构造和析构顺序的问题，会造成 core，遂放弃
 *
 */
class FileMonitor {
 public:
  // file_path 要监控的文件路径
  FileMonitor() : stopped_(true), loaded_(false) {}

  virtual ~FileMonitor() {
    // NOTE: 如果这里 check 了，说明没有调用 StopMonitorFile
    CHECK(stopped_);
  }

  virtual void LoadFile() {
    CHECK(false);  // can't use this version
  }

  // NOTE: 不能放在构造函数里，而要单拎出来。
  // 因为在构造函数里的话，基类对象先构造，此时派生类还不存在，
  // LoadFile 不能取到正确的版本
  void StartMonitorFile(const base::FilePath& file_path) {
    file_path_ = file_path;
    stopped_ = false;
    // 启动加载线程
    thread_.Start(::NewCallback(this, &FileMonitor::MonitorThread));
    // 等待 LoadFile 在线程中被执行一次
    while (!loaded_) {
      base::SleepForSeconds(1);
    }
  }

  // NOTE: 不能放在析构函数里，而要单拎出来。
  // 因为在析构函数里的话，派生类对象先析构，此时基类里 Join 时调用派生类的 LoadFile 会空指针
  void StopMonitorFile() {
    if (!stopped_) {
      stopped_ = true;
      thread_.Join();
    }
  }

 protected:
  virtual void MonitorThread() {
    LOG(INFO) << "start monitor thread for file " << file_path_.ToString();
    while (!stopped_) {
      base::PlatformFileError error_code;
      base::PlatformFile platform_file =
          base::CreatePlatformFile(file_path_,
                                   base::PLATFORM_FILE_OPEN|base::PLATFORM_FILE_READ,
                                   NULL, &error_code);
      if (error_code != base::PLATFORM_FILE_OK) {
        LOG_EVERY_N(WARNING, 1) << "failed to open: " << file_path_.ToString();
        // NOTE(Heguan): 为了方便部署,改成启动时没有文件也可以
        // if (!loaded_) {
        //   // 启动的时候必须文件存在
        //   CHECK(false);
        // }
        base::SleepForSeconds(kSleepSeconds);
        continue;
      }

      base::PlatformFileInfo platform_file_info;
      if (!base::GetPlatformFileInfo(platform_file, &platform_file_info)) {
        LOG(ERROR) << "failed to get info: " << file_path_.ToString();
        base::ClosePlatformFile(platform_file);
        base::SleepForSeconds(kSleepSeconds);
        continue;
      }

      std::string time_str;
      platform_file_info.last_modified.ToStringInSeconds(&time_str);
      // LOG(INFO) << "modify time: " << time_str;
      bool modified = platform_file_info.last_modified > last_modify_time_;
      if (modified) {
        last_modify_time_.ToStringInSeconds(&time_str);
        LOG(INFO) << "modified since " << time_str << ", start reading new version...";
        LoadFile();
        last_modify_time_ = platform_file_info.last_modified;
        LOG(INFO) << "done loading new version of file " << file_path_.ToString();
        loaded_ = true;
      } else {
        base::SleepForSeconds(kSleepSeconds);
      }

      bool suc = base::ClosePlatformFile(platform_file);
      if (!suc) {
        LOG(ERROR) << "failed to close: " << file_path_.ToString();
      }
    }

    LOG(INFO) << "monitor thread stopped for file " << file_path_.ToString();
  }

  // 不敢睡太久，否则在结束线程的时候也要等这么久
  static const int64 kSleepSeconds = 5;

  base::FilePath file_path_;
  thread::Thread thread_;
  std::atomic_bool stopped_;
  std::atomic_bool loaded_;
  base::Time last_modify_time_;
};
}  // namespace reco
