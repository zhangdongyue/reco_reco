#pragma once

#include <string>
#include <vector>
#include <set>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/bizc/reco_index/filter_rule.h"
#include "reco/bizc/proto/index_aux_data.pb.h"
#include "base/common/basic_types.h"
#include "base/container/dense_hash_map.h"
#include "base/hash_function/term.h"

namespace reco {
namespace dm {

void LoadSourceInfoDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct ItemRule {
  int64 auto_id;

  // 列表之内是或的关系，列表之间是与的关系
  std::unordered_set<std::string> category;
  std::unordered_set<std::string> keyword;
  std::unordered_set<std::string> basic_tag;
  std::unordered_set<std::string> semantic_tag;
  std::unordered_set<std::string> source;
  std::unordered_set<std::string> source_media;

  // 可以动态填充的 tag
  std::unordered_set<int64> extra_tag;

  std::unordered_set<int64> item_type;
  std::unordered_set<int64> style_type;
  std::unordered_set<int64> media_level;
  std::unordered_set<int64> is_source_wemedia;

  ItemRule(): auto_id(0) {}

  bool Match(const ItemRule & obj);

  void Clear() {
    is_source_wemedia.clear();
    category.clear();
    keyword.clear();
    basic_tag.clear();
    semantic_tag.clear();
    source.clear();
    source_media.clear();

    extra_tag.clear();

    item_type.clear();
    style_type.clear();
    media_level.clear();
  }

  void CopyFrom(const ItemRule & rule) {
    Clear();
    auto_id = rule.auto_id;

    for (auto iter = rule.category.begin(); iter != rule.category.end(); ++iter) {
      category.insert(*iter);
    }
    for (auto iter = rule.keyword.begin(); iter != rule.keyword.end(); ++iter) {
      keyword.insert(*iter);
    }
    for (auto iter = rule.basic_tag.begin(); iter != rule.basic_tag.end(); ++iter) {
      basic_tag.insert(*iter);
    }
    for (auto iter = rule.semantic_tag.begin(); iter != rule.semantic_tag.end(); ++iter) {
      semantic_tag.insert(*iter);
    }
    for (auto iter = rule.source.begin(); iter != rule.source.end(); ++iter) {
      source.insert(*iter);
    }
    for (auto iter = rule.source_media.begin(); iter != rule.source_media.end(); ++iter) {
      source_media.insert(*iter);
    }
    for (auto iter = rule.extra_tag.begin(); iter != rule.extra_tag.end(); ++iter) {
      extra_tag.insert(*iter);
    }
    for (auto iter = rule.item_type.begin(); iter != rule.item_type.end(); ++iter) {
      item_type.insert(*iter);
    }
    for (auto iter = rule.style_type.begin(); iter != rule.style_type.end(); ++iter) {
      style_type.insert(*iter);
    }
    for (auto iter = rule.media_level.begin(); iter != rule.media_level.end(); ++iter) {
      media_level.insert(*iter);
    }
    for (auto iter = rule.is_source_wemedia.begin(); iter != rule.is_source_wemedia.end(); ++iter) {
      is_source_wemedia.insert(*iter);
    }
  }
};

struct ChannelRule {
  int64 channel_id;
  std::vector<ItemRule> permit_list;
  std::vector<ItemRule> forbid_list;
};

struct FilterRule {
  int64 filter_id;
  std::unordered_set<int64> channel_set;
  int64 type;  // 0: in set (default), 1: out of set
  std::vector<ItemRule> match_list;
  std::vector<ItemRule> except_list;
};

struct ChannelRuleIndex {
  std::unordered_map<std::string, std::unordered_set<int64> > category;
  std::unordered_map<std::string, std::unordered_set<int64> > keyword;
  std::unordered_map<std::string, std::unordered_set<int64> > basic_tag;
  std::unordered_map<std::string, std::unordered_set<int64> > semantic_tag;
  std::unordered_map<std::string, std::unordered_set<int64> > source;
  std::unordered_map<std::string, std::unordered_set<int64> > source_media;

  std::unordered_map<int64, std::unordered_set<int64> > item_type;
  std::unordered_map<int64, std::unordered_set<int64> > style_type;
  std::unordered_map<int64, std::unordered_set<int64> > media_level;
  std::unordered_map<int64, std::unordered_set<int64> > is_source_wemedia;
  std::unordered_map<int64, std::unordered_set<int64> > extra_tag;
};

struct ChannelItemtypeDict {
  std::unordered_map<unsigned, std::vector<int64> > white_itemtype_channel_map_;
  std::unordered_map<unsigned, std::vector<int64> > black_itemtype_channel_map_;
};

void LoadChannelItemtypeDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct ExpoRatioNeeded {
  double min;
  double max;
  ExpoRatioNeeded():min(0.0), max(1.0) {}
};
typedef std::unordered_map<int32, ExpoRatioNeeded> UgcExpoRatioNeededDict;
void LoadUgcExpoRatioNeededDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);


struct UgcItemScoreDict {
  std::unordered_map<uint64, std::unordered_map<int64, double> > ugc_item_score_;
};
void LoadUgcItemScoreDict(base::FilePath path, void* dict_address, bool* suc, int64 cnt);

typedef std::unordered_map<int64, std::unordered_set<int64> > ChannelSubordinateMap;

// 频道规则匹配器
struct ChannelItemRuleEngine {
  // 规则正排集
  std::unordered_map<int64, ChannelRule> channel_rule_map;
  // 正向规则索引
  ChannelRuleIndex channel_rule_index_permit;
  // 过滤规则索引
  ChannelRuleIndex channel_rule_index_forbid;
  // 运营频道集合
  std::unordered_set<int64> manual_channels;
  // 聚合频道索引， channel id: channel id list
  ChannelSubordinateMap channel_subordinates_map;
};

// 频道规则字典
struct ChannelItemRuleGalleryDict {
  // Leaf 频道规则索引
  ChannelItemRuleEngine leaf_channel_engine;
  // Video 频道规则索引
  ChannelItemRuleEngine video_channel_engine;
  // Leaf 多分类扩召回规则索引
  ChannelItemRuleEngine leaf_extend_channel_engine;
  // 全局频道过滤规则
  std::vector<FilterRule> filter_rules;
};

void LoadChannelItemRuleGalleryDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

enum MediaQuantityType {
  kMediaNone = -1,
  kMediaDocManual = 0,
  kMediaVideoManual = 1,
  kMediaDocBeginner = 10,
  kMediaVideoBeginner = 11,
};

enum SourceLevelType {
  kSourceLevelUnknown = 0,
  kSourceLevelD = 1,
  kSourceLevelC = 2,
  kSourceLevelB = 3,
  kSourceLevelA = 4,
  kSourceLevelS = 5,
};

struct MediaQuantityInfo {
  // 种子源名称
  std::string source;
  // 媒体保量类型
  int64 protect_type;
  // 预估保量流量
  int64 protect_capacity;
  // 发文量, 过去 7 天平均日下发量
  int64 expect_daily_deliever_num;
  // 分级
  int64 source_level;

  // 当日已下发量 (from meta updator)
  int64 deliever_num;

  // 当日保量策略下发量 (from meta updator)
  int64 assurance_deliever_num;

  // 种子源签名 (signed by source field for looking up)
  uint64 source_sign;

  // 限制分类下发（白名单方式）
  std::unordered_set<std::string> category;

  MediaQuantityInfo() : source(std::string()), protect_type(kMediaNone), protect_capacity(0),
                        expect_daily_deliever_num(0), source_level(kSourceLevelUnknown),
                        deliever_num(0), assurance_deliever_num(0), source_sign(0) {}

  MediaQuantityInfo(std::string source_, int64 protect_type_, int64 protect_capacity_,
                    int64 expect_daily_deliever_num_, int64 source_level_,
                    int64 deliever_num_, int64 assurance_deliever_num_) :
    source(source_), protect_type(protect_type_), protect_capacity(protect_capacity_),
    expect_daily_deliever_num(expect_daily_deliever_num_), source_level(source_level_),
    deliever_num(deliever_num_), assurance_deliever_num(assurance_deliever_num_) {
    source_sign = base::CalcTermSign(source_.c_str(), source_.size());
  }

  void UpdateSign() {
    source_sign = base::CalcTermSign(source.c_str(), source.size());
  }

  void Clear() {
    source = std::string();
    protect_type = kMediaNone;
    protect_capacity = 0;
    expect_daily_deliever_num = 0;
    source_level = kSourceLevelUnknown;
    deliever_num = 0;
    assurance_deliever_num = 0;
    source_sign = 0;
    category.clear();
  }
};

// 两级索引，规则 = dict [种子源签名] [保量类型]
typedef std::unordered_map<uint64, std::unordered_map<int64, MediaQuantityInfo> > MediaQuantityInfoDict;
void LoadMediaQuantityInfoDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
}

class DynamicDictContainer {
 public:
  DynamicDictContainer() {}
  ~DynamicDictContainer() {}
  static void RegisterAndLoadAllDict();
  static const char* kChannelItemtypeFile_;
  static const char* kChannelItemRuleFile_;
  static const char* kMediaQuantityInfoFile_;
  static const char* kUgcExpoRatioNeededFile_;
  static const char* kUgcItemScoreFile_;
};
}
