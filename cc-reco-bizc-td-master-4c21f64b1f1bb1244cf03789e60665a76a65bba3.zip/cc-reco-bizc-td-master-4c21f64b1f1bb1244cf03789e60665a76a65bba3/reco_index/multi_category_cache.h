#pragma once
#include <vector>
#include <string>

#include "reco/bizc/proto/common.pb.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/common/basic_types.h"
#include "base/strings/string_printf.h"
#include "base/hash_function/term.h"

namespace reco {
// thread safe
class MultiCategoryCache {
 public:
  MultiCategoryCache();
  ~MultiCategoryCache();

 public:
  void Add(uint64 item_id, const MultiCategory& multi_category);

  void Add(uint64 item_id, const ItemCategory& item_category);

  // NOTE: level2 名字不同 没必要和一级合在一起
  // return: -1:item 不在 cache 中, 0: item 在 cache 中, category 不在, 1 category 在 score 可用
  int Find(uint64 item_id, const std::string& category, float* score) {
    int dummy = 0;
    if (!item_dict_->FindSilently(item_id, &dummy)) return -1;

    uint64 sign = generate_sign(item_id, category);
    if (category_score_->FindSilently(sign, score)) return 1;

    return 0;
  }

 private:
  uint64 generate_sign(uint64 item_id, const std::string& category) {
    std::string key = base::StringPrintf("%lu_%s", item_id, category.c_str());
    return base::CalcTermSign(key.c_str(), key.size());
  }

  static serving_base::ExpiryMap<uint64, float>* category_score_;
  static serving_base::ExpiryMap<uint64, int>* item_dict_;
};
}
