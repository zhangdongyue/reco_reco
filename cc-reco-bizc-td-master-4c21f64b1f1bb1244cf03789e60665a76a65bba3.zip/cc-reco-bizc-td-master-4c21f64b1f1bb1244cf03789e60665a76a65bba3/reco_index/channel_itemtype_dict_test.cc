#include "reco/bizc/reco_index/channel_itemtype_dict.h"

#include <sstream>
#include "base/testing/gtest.h"
#include "base/common/logging.h"

namespace reco {
class GlobalEnvironment : public testing::Environment {
 public:
  virtual void SetUp() {
    DynamicDictContainer::RegisterAndLoadAllDict();
    reco::dm::DictManagerSingleton::instance().LoadAllDicts();
  }

  virtual void TearDown() {}
};

class ChannelItemtypeDictTest : public testing::Test {
 public:
  virtual void SetUp() {}
  virtual void TearDown() {}
};

TEST_F(ChannelItemtypeDictTest, Basic) {
  ChannelItemtypeDict channel_itemtype_dict;
  std::unordered_set<int64> channels;
  std::unordered_set<int64> manual_channels;
  ItemPattern obj;

  obj.category.insert("娱乐-电影");
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_GT(channels.count(10021), 0u);

  obj.Clear();
  channels.clear();
  obj.category.insert("娱乐-电视");
  obj.extra_tag.insert(1);
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_EQ(channels.count(10021), 0u);
}

TEST_F(ChannelItemtypeDictTest, Expanded) {
  ChannelItemtypeDict channel_itemtype_dict;
  std::unordered_set<int64> channels;
  std::unordered_set<int64> manual_channels;
  ItemPattern obj;

  obj.category.insert("汽车");
  obj.basic_tag.insert("豪车");
  for (auto i = 0u; i < 50000; ++i) {
    channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
    ASSERT_GT(channels.count(10040), 0u);
  }

  obj.Clear();
  channels.clear();
  obj.category.insert("社会");
  obj.extra_tag.insert(1);
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafExtendChannelRule, manual_channels, &channels);
  ASSERT_GT(channels.count(640374), 0u);

  obj.Clear();
  channels.clear();
  obj.category.insert("娱乐");
  obj.item_type.insert(30);
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kVideoChannelRule, manual_channels, &channels);
  ASSERT_GT(channels.count(1089289174), 0u);

  obj.Clear();
  channels.clear();
  obj.category.insert("体育-nba");
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_EQ(channels.count(10043), 0u);
  obj.category.insert("体育");
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_GT(channels.count(10043), 0u);

  obj.Clear();
  channels.clear();
  obj.category.insert("体育");
  obj.extra_tag.insert(1);
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_EQ(channels.count(10043), 0u);

  obj.Clear();
  channels.clear();
  obj.category.insert("自媒体");
  obj.is_source_wemedia.insert(1);
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_GT(channels.count(10088), 0u);

  channels.clear();
  obj.Clear();
  obj.is_source_wemedia.insert(0);
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_EQ(channels.count(10088), 0u);
}

TEST_F(ChannelItemtypeDictTest, Subordinate) {
  ChannelItemtypeDict channel_itemtype_dict;
  std::unordered_set<int64> channels;
  std::unordered_set<int64> manual_channels;
  ItemPattern obj;

  obj.category.insert("汽车");
  obj.item_type.insert(1);
  obj.basic_tag.insert("豪车");
  for (auto i = 0u; i < 50000; ++i) {
    channels.clear();
    channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
    ASSERT_GT(channels.count(10040), 0u);
    ASSERT_GT(channels.count(11110), 0u);
    ASSERT_EQ(channels.count(11111), 0u);
    channel_itemtype_dict.AggregateSubordinateChannels(kLeafChannelRule, &channels);
    ASSERT_GT(channels.count(10040), 0u);
    ASSERT_GT(channels.count(11110), 0u);
    ASSERT_GT(channels.count(11111), 0u);
  }
}

TEST_F(ChannelItemtypeDictTest, GlobalFilter) {
  ChannelItemtypeDict channel_itemtype_dict;
  std::unordered_set<int64> channels;
  std::unordered_set<int64> manual_channels;
  ItemPattern obj;

  obj.Clear();
  channels.clear();
  obj.category.insert("测试");
  obj.category.insert("枚举禁止");
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_GT(channels.count(30000), 0u);
  ASSERT_GT(channels.count(30001), 0u);
  channel_itemtype_dict.RemoveForbidChannelsInside(obj, &channels);
  ASSERT_EQ(channels.count(30000), 0u);
  ASSERT_GT(channels.count(30001), 0u);
  obj.item_type.insert(30);
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_GT(channels.count(30000), 0u);
  ASSERT_GT(channels.count(30001), 0u);
  channel_itemtype_dict.RemoveForbidChannelsInside(obj, &channels);
  ASSERT_GT(channels.count(30000), 0u);
  ASSERT_GT(channels.count(30001), 0u);

  obj.Clear();
  channels.clear();
  obj.category.insert("测试");
  obj.category.insert("例外禁止");
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_GT(channels.count(30002), 0u);
  ASSERT_GT(channels.count(30003), 0u);
  channel_itemtype_dict.RemoveForbidChannelsInside(obj, &channels);
  ASSERT_EQ(channels.count(30002), 0u);
  ASSERT_GT(channels.count(30003), 0u);

  obj.Clear();
  channels.clear();
  obj.category.insert("测试");
  obj.category.insert("枚举失效");
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_GT(channels.count(30000), 0u);
  ASSERT_GT(channels.count(30001), 0u);
  channel_itemtype_dict.RemoveForbidChannelsInside(obj, &channels);
  ASSERT_GT(channels.count(30000), 0u);
  ASSERT_GT(channels.count(30001), 0u);

  obj.Clear();
  channels.clear();
  obj.category.insert("测试");
  obj.category.insert("通配过滤");
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_GT(channels.count(30002), 0u);
  ASSERT_GT(channels.count(30003), 0u);
  channel_itemtype_dict.RemoveForbidChannelsInside(obj, &channels);
  ASSERT_GT(channels.count(30002), 0u);
  ASSERT_GT(channels.count(30003), 0u);
  obj.item_type.insert(30);
  channel_itemtype_dict.GetChannelsFromItemRule(obj, kLeafChannelRule, manual_channels, &channels);
  ASSERT_GT(channels.count(30002), 0u);
  ASSERT_GT(channels.count(30003), 0u);
  channel_itemtype_dict.RemoveForbidChannelsInside(obj, &channels);
  ASSERT_EQ(channels.count(30002), 0u);
  ASSERT_EQ(channels.count(30003), 0u);
}
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "channel_itemtype_dict test");
  testing::InitGoogleTest(&argc, argv);
  testing::AddGlobalTestEnvironment(new reco::GlobalEnvironment);
  return RUN_ALL_TESTS();
}
