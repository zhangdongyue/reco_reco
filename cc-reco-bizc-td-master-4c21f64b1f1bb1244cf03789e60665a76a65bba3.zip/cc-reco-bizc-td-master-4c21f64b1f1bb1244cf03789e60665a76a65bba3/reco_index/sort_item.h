#pragma once

#include <cstdatomic>
#include <cmath>
#include <string>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <map>
#include <boost/shared_ptr.hpp>

#include "reco/bizc/common/wrapped_category.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/reco_index/subscribe_channel.h"
#include "reco/bizc/reco_index/index_dict_manager.h"
#include "reco/bizc/reco_index/source_manager.h"
#include "reco/bizc/reco_index/channel_itemtype_dict.h"
#include "reco/bizc/reco_index/media_quantity_assurance.h"
#include "reco/bizc/reco_index/dynamic_dict_container.h"

#include "reco/bizc/proto/index_aux_data.pb.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "ads_index/api/public.h"
#include "ads_index/proto/index.pb.h"
#include "reco/bizc/proto/time_axis_type.pb.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/testing/gtest.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/sync.h"
#include "base/thread/thread.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/reco_index/extractor.h"

namespace base {
class PseudoRandom;
}

namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;
class IndexDictManager;
class SimItem;

namespace leafserver {
class ExternalApi;
}
namespace videoserver {
class ExternalApi;
}

// item 排序线程的运行周期
DECLARE_int32(sort_item_interval_second);
struct ItemFea {
  std::vector<std::pair<std::string, float> > keyword_info;
  std::vector<std::pair<std::string, float> > tag_info;
  std::vector<std::pair<std::string, float> > topic_info;
  std::vector<std::pair<std::string, float> > category_info;
};

struct ItemsFeature {
  std::vector<ItemFea> items_fea;
  base::dense_hash_map<uint64, int> items_index;
};

/**
 * 新闻的索引，主要功能有
 * 1. 封装了 adsindex，提供 api 查询跟推荐相关的信息
 * 2. 内部独立线程更新新闻的 meta 信息 （可以关闭此线程）
 * 3. 内部独立线程热门新闻的索引（可以关闭此线程）
 */
class SortItem {
 public:
  SortItem(const reco::NewsIndex* news_index,
           reco::SimItem* sim_item,
           SourceManager* source_manager);
  ~SortItem();

  // 返回的类别信息是 Category 形式的，带父级类别
  void GetCategories(int level, std::vector<reco::Category>* categories) const;
  // 返回的视频类别信息是 Category 形式的，带父级类别
  void GetVideoCategories(int level, std::vector<reco::Category>* categories) const;

  // 获取默认推荐
  const std::vector<ItemInfo>* GetDefaultReco() const;
  // 获取分类下的默认推荐
  const std::vector<ItemInfo>* GetDefaultReco(const reco::Category& category, bool timely = false) const;
  // 获取 channel 下的默认推荐, region_id 只对 channel_id 为本地频道时生效, 不是本地频道时，请取值-1
  // only_video 对非视频频道生效, only_video == true 时返回的 ItemInfo 只有纯视频
  const std::vector<ItemInfo>* GetDefaultReco(int64 channel_id, int64 region_id, bool only_video) const;

  // 获取分类下的视频默认推荐
  const std::vector<ItemInfo>* GetVideoDefaultReco(const reco::Category& category) const;
  // 获取频道下的视频默认推荐
  const std::vector<ItemInfo>* GetVideoDefaultReco(const int64 channel_id,
                                                   bool explore = false,
                                                   bool is_fully_shown = false) const;
  // 默认主题推荐
  const std::vector<ItemInfo>* GetSubjectDefaultReco() const;

  // 获取剧集下面所有的 item 列表
  const std::vector<ItemInfo>* GetItemsByYoukuShowId(const std::string& show_id) const;

  bool ContainInCategoryQueue(const reco::Category& category, int32 doc_id) const;
  bool GetItemTimeAxisInfoByItemId(uint64 item_id, time_axis::TimeAxisInfo *timeaxis_info) const;

  bool CheckVideo2ndChannel(int64 channel_id) const {
    auto dict_ptr = const_cast<ChannelItemtypeDict*>(&channel_itemtype_dict_);
    // 二级视频频道检查
    if (dict_ptr->CheckVideo2ndChannel(channel_id)) return true;
    return false;
  }
  bool GetLatestNewsByEventName(const std::string& event_name, uint64* latest_item_id,
          time_axis::TimeAxisInfo* timeaxis_info) const;

  bool GetItemIdByYoukuVideoId(uint64 youku_video_id, uint64 *item_id) const;

  std::map<int64, ChannelRule> DumpChannelRules() const {
    return channel_itemtype_dict_.DumpChannelRules();
  }

  bool IsYoukuShowItem(const ItemInfo& item);

  const std::unordered_map<uint64, UcBrowserDeliverSetting>* GetUcbSettingDict() const {
    return item_ucb_setting_dict_.GetDict();
  }

  const std::unordered_map<uint64, reco::LocalBreaking>* GetItemBreakingDict() const {
    return item_breaking_dict_.GetDict();
  }
  const std::vector<ItemInfo>* GetGuaranteeQuantityReco(const reco::Category& category) const;

  const std::vector<ItemInfo>* GetVideoGuaranteeQuantityReco(const reco::Category& category) const;

  // 根据 item_id 获取视频所在的 subject_id
  bool GetSubjectIdByItemId(uint64 item_id, uint64 *subject_id) const;
  // 更新 item_id 对应的 subject_id
  void UpdateItemToSubjectDict(const std::vector<ItemInfo>& all_items);

  const std::vector<ItemInfo>* GetMiningStrategyReco(int32 strategy) const;

  // 根据 item_id 获取主题的 video tag feature
  const reco::FeatureVector* GetSubjectVideoTagFeatureByItemId(uint64 item_id) const;
  // 更新 subject 对应的 video tag feature
  void UpdateSubjectVideoTagFeatureDict(const std::vector<ItemInfo>& all_items);
 private:
  // 更新 News 索引
  bool SortItemLoop();
  bool SortOperItemLoop();

  // 获取 ucb 默认推荐
  const std::vector<ItemInfo>* GetUCBDefaultReco() const;
  // 获取 hot card 默认推荐
  const std::vector<ItemInfo>* GetHotCardDefaultReco() const;
  // 获取精品文章的默认推荐
  const std::vector<ItemInfo>* GetJingpinDefaultReco() const;
  // 获取热点视频
  // const std::vector<ItemInfo>* GetHotVideoDefaultReco() const;
  // 获取本地频道的默认推荐
  const std::vector<ItemInfo>* GetLocalDefaultReco(int64 region_id) const;
  // 获取基于 POI 的默认推荐
  const std::vector<ItemInfo>* GetPOIDefaultReco(int64 area_id) const;
  // 获取某地突发事件的默认推荐
  const std::vector<ItemInfo>* GetLocalBreakingDefaultReco(int64 region_id) const;
  const std::unordered_map<std::string, std::unordered_set<uint64>>* GetWeMediaItemsDict() const;
  // 获取对应 index_type 和 tag 的当日新闻数量
  int GetTodayNewsNum() const;
  int GetTodayNewsNum(const reco::Category& category) const;
  bool FinanceStockFilter(const ItemInfo& item);
  void GetKeyItems(const std::vector<ItemInfo>& all_items,
                   std::vector<ItemInfo>* key_items) const;
 private:
  struct NewsQueue {
    // int match_hot_news_num;
    int today_news_num;
    // 默认排序 （考虑时效性的基础上按热度排序)
    std::vector<ItemInfo> indexs;
    // 按时间排序
    std::vector<ItemInfo> timely_indexs;

    std::unordered_set<int32> item_doc_ids;
    NewsQueue() : today_news_num(0) {}

    const std::vector<ItemInfo>* GetIndex() const {
      return &indexs;
    }

    std::vector<ItemInfo>* MutableIndex() {
      return &indexs;
    }

    const std::vector<ItemInfo>* GetTimelyIndex() const {
      return &timely_indexs;
    }

    std::vector<ItemInfo>* MutableTimelyIndex() {
      return &timely_indexs;
    }

    void SetItemDocIDs() {
      item_doc_ids.clear();
      for (size_t i = 0; i < indexs.size(); ++i) {
        item_doc_ids.insert(indexs[i].doc_id);
      }
    }

    bool Contain(int32 doc_id) const {
      return (item_doc_ids.find(doc_id) != item_doc_ids.end());
    }

    void Clear() {
      today_news_num = 0;
      indexs.clear();
      timely_indexs.clear();
      item_doc_ids.clear();
    }
  };

  // 源下所有信息，用于离散化
  struct SourceInfo {
    std::string source_name;
    std::vector<double> values;
    std::vector<double> value_boundaries;
    std::vector<double> times;
    std::vector<double> time_boundaries;
    float scale;
    float shift;
  };

  // 热门新闻索引
  typedef std::unordered_map<reco::common::WrappedCategory, NewsQueue,
          reco::common::CategoryHash> CategoryMap;
  typedef std::unordered_map<int64, NewsQueue> ChannelMap;
  typedef std::unordered_map<std::string, std::vector<ItemInfo>> ShowInfoMap;

  typedef std::unordered_map<int32, std::vector<ItemInfo> > MiningStrategyMap;

 private:
  // 今日新闻数
  int GetTodayNewsNum(const std::vector<ItemInfo>& item_list);

  void FillWeMediaItemsDict(const std::vector<ItemInfo>& all_items,
                            std::unordered_map<std::string, std::unordered_set<uint64> >* wemedia_items_dict);

  // sort items by app and category
  void SortItemThread();
  void SortOperItemThread();

  void FillSourceRuleChain(std::vector<ItemInfo>* items,
                           std::unordered_map<uint64, RuleChain>* buffer);
 private:
  void GetAllItems(std::vector<ItemInfo>* items, int max_save_num);
  void GetAllOperItems(std::vector<ItemInfo>* items, int max_save_num);
  void GetFilteredItems(std::unordered_set<uint64>* filtered_items) const;
  void PrintItems(const std::vector<ItemInfo>& items) const;
  void SortCategoryItems(const std::vector<ItemInfo>& all_items,
                         CategoryMap* category_index,
                         CategoryMap* video_category_index,
                         CategoryMap* media_quantity_index,
                         CategoryMap* video_media_quantity_index);
  void SortChannelItems(const std::vector<ItemInfo>& all_items,
                        CategoryMap* category_index,
                        ChannelMap* channel_index,
                        ChannelMap* region_index,
                        ChannelMap* poi_index);

  // 过滤最差的一批低质 item
  bool FilterBadItem(const ItemInfo& item);
  void PrintFilterDebug(const ItemInfo& item, const std::string& reason);
  bool AddToRegionQueue(const ItemInfo& item, ChannelMap* region_index, ChannelMap* poi_index);
  void AddToPOIQueue(const ItemInfo& item, ChannelMap* poi_index);
  void SortRegionItems(const std::string& now_str, ChannelMap* region_index, ChannelMap* poi_index);
  void SortHumorItems(const std::vector<ItemInfo>& all_items,
                      CategoryMap* category_index, int max_save_num);
  void SortSpecialItems(const std::vector<ItemInfo>& all_items,
                        ChannelMap* channel_index, int max_save_num);
  void SortJingpinItems(const std::vector<ItemInfo>& all_items,
                        NewsQueue* news_queue, int max_save_num);
  void SortYoukuShowItems(const std::vector<ItemInfo>& youku_show_items,
                             ShowInfoMap* show_video_index);
  void SortSubjectItems(const std::vector<ItemInfo>& all_items, NewsQueue* news_queue);
  void SortZZDItems(const std::vector<ItemInfo>& all_items, NewsQueue* news_queue,
      std::vector<ItemInfo>* youku_show_queue);

  void SortUCBItems(const std::vector<ItemInfo>& all_items,
                    NewsQueue* news_queue, NewsQueue* hot_queue);

  // docs 是按 doc id 排序，按照 item info 信息重新排序
  // 过滤幽默类型和专题类型
  void SortDocsIntoItems(const std::vector<int32>& docs, const std::vector<ItemInfo>& all_items,
                         std::vector<ItemInfo>* items, int max_save_num);
  void ExtractCategoryItems(const std::vector<ItemInfo>& all_items, const reco::Category& category,
                            std::vector<ItemInfo>* items, std::vector<ItemInfo>* video_items,
                            int max_save_num);

  bool IsIndexDictCanSwitch();

  void UpdateTimeAxisDict();
  void UpdateYoukuIdDict(const std::vector<ItemInfo>& all_items);
  void UpdateLocalBreakingItems(const ChannelMap* region_index);

  int CalcIndexScore(const ItemInfo& item, bool use_predict_ctr, int* miss) const;

  bool IsVideoChannel(int64 channel_id) const {
    return ChannelItemtypeDict::IsVideoChannel(channel_id);
  }

 private:
  void SortVideoItems(const std::vector<ItemInfo>& all_items,
                      ChannelMap* channel_video_index,
                      ChannelMap* channel_video_explore_index,
                      ChannelMap* channel_video_fully_shown_index);

  void CollectVideoItemChannelIds(const ItemInfo &item,
                                  const std::vector<int64> &seed_channel_ids,
                                  std::unordered_set<int64> *channel_ids);

  // 视频加入到某个具体的队列，里面有去重、限制队列长度、是否进行 ctr 过滤这三个逻辑
  void AddToVideoQueue(const ItemInfo& item, NewsQueue* video_queue,
                       int max_size, float ctr_thr);

  void SortChannelVideoItems(ChannelMap* channel_video_index,
                             ChannelMap* channel_video_explore_index,
                             ChannelMap* channel_video_fully_shown_index);

  void SortUgcVideoItems(const std::vector<ItemInfo>& all_items,
                         ChannelMap* ugc_video_index,
                         ChannelMap* ugc_video_explore_index);

  void SortUgcChannelVideoItems(ChannelMap* ugc_video_index,
                                ChannelMap* ugc_video_explore_index);

  // 根据配置文件，按比例出各池子中的 item
  void SortYouCaiItems(std::vector<ItemInfo>* items);
  // 合并各池子中的 item
  bool MergeYouCaiItems(std::unordered_map<int, std::list<ItemInfo> > & pool_items,
                        std::vector<ItemInfo>& items);
  int GetYouCaiProbPool(const std::unordered_map<int, std::list<ItemInfo> >& pool_items,
                        std::unordered_map<int, float>& pool_prob,
                        int* prob_pool, int prob_pool_len);


  bool GetUgcItemModelScore(const int64 channel_id, std::vector<ItemInfo>& all_items);

  bool FilterVideoItem(const ItemInfo& item);

  bool FilterUgcVideoItem(int64 channel_id, const ItemInfo& item);
 private:
  void ExtractItemFea(const std::vector<ItemInfo>& all_items);

  void ExtractQuantityItems(const std::string& category,
                            const std::vector<ItemInfo> & items,
                            const std::vector<ItemInfo> & video_items,
                            std::vector<ItemInfo>* quantity_items,
                            std::vector<ItemInfo>* quantity_video_items);

  // 填充语义信息
  void FillItemAttr(std::vector<ItemInfo>& all_items);
  int GetItemIndex(uint64 item_id) const;
  const ItemFea& GetItemFea(int index) const;

  float WilsonIntervalRatio(int numerator, int denominator);

  // 综合主题下 TOPN 子文视频计算主题 CTR ITEMQ 等信息
  bool CalcSubjectMergeMsg(ItemInfo* item);

 private:
  static const int64 kNoRecoChannelIds[];
  static const char* kPictureCategories[];
  static const std::string kExtraTagNoneLocal;

  // 资讯类视频的分类和频道的对应关系
  static const std::unordered_map<std::string, int64> kVideoCategoryToChannel;
  // 视频的分类和视频二级频道的对应关系
  static const std::unordered_map<std::string, int64> kVideoCategoryToVideoSecondChannel;
  // 本地源不能下发的分类
  static const std::unordered_set<std::string> kLocalSourceRejectCategories;
  // 机器文章的 producer 集合
  static const std::unordered_set<std::string> kMachineProducerSet;
  // 竞品媒体集合
  static const std::unordered_set<std::string> kCompeteSourceMediaSet;

  static const char* kSimItemPrefix;
  static const int kSpiderBins = 50;
  // 最多保存该类型前 TopN 条结果
  static const int kMaxSavePerCate = 25000;
  // 最多保留的视频队列的长度
  static const int kMaxSaveVideoChannel = kMaxSavePerCate * 20;
  // 最多保存该类型前 TopN 条结果
  static const int kMaxSaveTotal = 30000 * 100;

  // 视频入队列的最低 ctr 和 show 门限
  static const float kMinVideoCtrThr = 0.05;
  static const int kMinVideoShowThr = 300;
  // 热门视频最低 hot_level 门限
  static const int kVideoHotLevelThr = 20;

  static const char* kExtendCategoryFile;

  void NormalizeSpiderScore(std::vector<ItemInfo>* items) const;

  void AddMultiCategoryChannels(const ItemInfo & item,
                                const ::google::protobuf::RepeatedPtrField<ItemCategory> & candidates,
                                std::unordered_set<int64>* candidate_channels,
                                std::unordered_map<int64, std::pair<std::string, std::string> >* inc);

  void BuildMiningStrategyItemDict();

  // sort item thread
  thread::Thread sort_item_thread_;
  thread::Thread sort_oper_item_thread_;
  std::atomic_bool sort_item_thread_stop_;
  std::atomic_long index_doc_;

  std::unordered_set<int64> no_reco_channel_ids_;
  std::unordered_set<int64> humor_channel_ids_;
  std::unordered_set<std::string> picture_categories_;

  thread::Mutex sort_item_mutex_;
  thread::Mutex sort_oper_item_mutex_;

  DynamicDict<NewsQueue> app_index_;  // ZZD 索引
  DynamicDict<NewsQueue> ucb_index_;  // uc browser 索引
  DynamicDict<NewsQueue> hot_card_index_;  // uc browser 索引
  // DynamicDict<NewsQueue> hot_video_index_;  // 热门视频索引
  DynamicDict<CategoryMap>  category_index_;  // 类别索引
  DynamicDict<ChannelMap>   channel_index_;  // 频道索引
  DynamicDict<NewsQueue>    jingpin_index_;  // 精品文章索引
  DynamicDict<NewsQueue> subject_index_;
  DynamicDict<ShowInfoMap>  youku_show_video_index_;  // 从节目 id (youku_show_id) 到视频的索引

  DynamicDict<ChannelMap>   region_index_;   // 地域新闻索引
  DynamicDict<ChannelMap>   poi_index_;        // POI 新闻索引
  DynamicDict<ChannelMap>   local_breaking_index_;  // 本地突发事件索引

  DynamicDict<ChannelMap>   channel_video_index_;           // 视频及视频二级频道索引
  DynamicDict<ChannelMap>   channel_video_explore_index_;   // 展现不充分视频索引
  DynamicDict<ChannelMap>   channel_video_fully_shown_index_;   // 展现充分视频索引
  DynamicDict<CategoryMap>  video_category_index_;          // 视频的类别索引

  DynamicDict<CategoryMap>  media_quantity_index_;                // 保量类别索引
  DynamicDict<CategoryMap>  video_media_quantity_index_;          // 视频保量类别索引
  DynamicDict<ChannelMap>   ugc_video_index_;           // ugc 视频及视频二级频道索引
  DynamicDict<ChannelMap>   ugc_video_explore_index_;           // ugc 视频及视频二级频道索引

  DynamicDict<std::unordered_map<uint64, time_axis::TimeAxisInfo> > timeaxis_dict_;
  DynamicDict<std::unordered_map<std::string, std::unordered_set<uint64>>> wemedia_items_dict_;
  DynamicDict<std::unordered_map<std::string,
          std::pair<uint64, time_axis::TimeAxisInfo> > > timeaxis_latest_news_dict_;

  DynamicDict<std::unordered_map<uint64, uint64> > youku_video_id_dict_;
  DynamicDict<std::unordered_map<uint64, UcBrowserDeliverSetting> > item_ucb_setting_dict_;

  DynamicDict<std::vector<uint64>> subject_dict_;

  DynamicDict<std::unordered_map<uint64, uint64> > item_to_subject_dict_;

  DynamicDict<std::unordered_map<uint64, reco::FeatureVector> > subject_video_tag_feature_dict_;

  // 保存 item 的本地突发属性
  // 这个量不大，因为只会保留当前识别到突发事件的 item，每天估计最多小几千
  DynamicDict<std::unordered_map<uint64, reco::LocalBreaking> > item_breaking_dict_;

  // 保存离线挖掘出来的结果
  MiningStrategyMap mining_strategy_item_;

  // 中间数据
  std::vector<ItemInfo> all_items_;
  ItemsFeature items_feature_;
  std::unordered_set<uint64> filtered_items_;
  const NewsIndex* news_index_;
  const adsindexing::Index* index_;
  base::PseudoRandom* random_;

  const IndexDictManager* dict_manager_;
  SimItem* sim_item_;
  SubscribeChannel* subs_channel_;
  SourceManager* source_manager_;
  ChannelItemtypeDict channel_itemtype_dict_;

  FRIEND_TEST(CDocIndexTest, UCBTest);
  FRIEND_TEST(NewsIndexTest, TestAddMultiCategoryChannel);
  friend class NewsIndex;
  friend class reco::leafserver::ExternalApi;
  friend class reco::videoserver::ExternalApi;
};
}  // namespace reco

#include "reco/bizc/reco_index/sort_item-inl.h"
