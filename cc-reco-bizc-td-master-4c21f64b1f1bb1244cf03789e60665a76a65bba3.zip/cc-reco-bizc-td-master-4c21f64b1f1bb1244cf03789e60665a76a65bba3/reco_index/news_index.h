#pragma once

#include <cstdatomic>
#include <cmath>
#include <string>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <set>
#include <map>

// #include "reco/base/include/recommending.h"
#include "reco/bizc/common/index_util.h"
#include "reco/bizc/common/appname_define.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/reco_index/subscribe_channel.h"
#include "reco/bizc/reco_index/index_dict_manager.h"
#include "reco/bizc/reco_index/source_manager.h"
#include "reco/bizc/reco_index/dynamic_dict_container.h"
#include "reco/bizc/reco_index/multi_category_cache.h"
// #include "reco/bizc/reco_index/video_stat_info_updator.h"
// #include "reco/bizc/reco_index/origin_info_updator.h"
#include "reco/bizc/reco_index/sort_item.h"
#include "reco/bizc/proto/index_aux_data.pb.h"
#include "reco/bizc/proto/ha3_item.pb.h"
#include "ads_index/api/public.h"
#include "ads_index/proto/index.pb.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/testing/gtest.h"
#include "base/thread/sync.h"
#include "base/thread/thread.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"

namespace adsindexing {
class Index;
}

namespace reco {
namespace searchserver {
class IFlowRanker;
class Ranker;
}

namespace leafserver {
class ExternalApi;
}
namespace videoserver {
class ExternalApi;
}

class NewsIndex;
class IndexDictManager;
class SimItem;
class MetaInfoUpdator;
class SortItem;

struct ItemAttachDataExt {
  int level;
  ItemAttachDataExt(): level(-1) {}
};

// 只能通过该函数初始化, 调用方需要 delete
NewsIndex* InitializeNewsIndex(const adsindexing::Index* index);

/**
 * 新闻的索引，主要功能有
 * 1. 封装了 adsindex，提供 api 查询跟推荐相关的信息
 * 2. 内部独立线程更新新闻的 meta 信息 （可以关闭此线程）
 * 3. 内部独立线程热门新闻的索引（可以关闭此线程）
 */
class NewsIndex {
 public:
  // ~NewsIndex() {};
  ~NewsIndex();

  ///////////// 底层索引信息 ///////////////////////////
  const adsindexing::Index* GetAdsIndex() const { return index_; }  // NOLINT
  int32 MinDocLocalId() const { return index_->MinDocLocalId(); }  // NOLINT
  int32 GetDocNum() const { return index_->GetDocNum(); }  // NOLINT
  int32 MaxDocLocalId() const {return index_->MaxDocLocalId(); }  // NOLINT

  ///////////// 基本信息 ///////////////////////////
  // 从 DocID 得到 ItemId
  bool GetItemIdByDocId(int32 doc_id, uint64* item_id) const;
  // 从 ItemId 得到 DocID
  bool GetDocIdByItemId(uint64 item_id, int32* doc_id) const;
  // 从 DocID 得到 Item Type
  bool GetItemTypeByDocId(int32 doc_id, reco::ItemType* item_type) const;
  // 从 ItemId 得到 Item Type
  bool GetItemTypeByItemId(uint64 item_id, reco::ItemType* item_type) const;
  // 从 ItemID 得到 unigrams
  bool GetAreaUnigramsByItemId(uint64 item_id, adsindexing::DocAreaType area_type,
                              std::vector<std::string>* unigrams) const;
  // NOTE: 建议用 GetAreaUnigramsByItemId 这个接口，内部有针对 item id 的缓存
  // 从 DocID 得到 unigrams
  bool GetAreaUnigramsByDocId(int32 doc_id, adsindexing::DocAreaType area_type,
                              std::vector<std::string>* unigrams) const;
  // 得到 doc mask
  uint32 GetDocMaskByItemId(uint64 item_id) const;

  // 通过 item id/doc_id 获取 ItemInfo.
  // |only_basic|:
  //    为 true 则只返回 ItemInfo 里的 item_id, item_type, doc_id 这三个字段,
  //    为 false 会进一步查询 meta 信息
  bool GetItemInfoByItemId(uint64 item_id, ItemInfo* item_info, bool only_basic) const;
  bool GetItemInfoByDocId(int32 doc_id, ItemInfo* item_info, bool only_basic) const;
  bool GetItemInfoHa3ByDocId(int32 doc_id, ItemInfoHa3* item_info) const;
  // NOTE: 需要已经填充了 item id， item type， doc id 字段
  // TODO(jianhuang) 后续提供 批量接口, BatchGetMetaInfos
  bool GetMetaInfo(uint64 item_id, ItemInfo *item) const;
  // 从 ItemId 获得 title 原文
  bool GetItemTitleByItemId(uint64 item_id, std::string* title) const;
  bool GetItemTitleByDocId(int32 doc_id, std::string* title) const;
  // 从 ItemId 获得 youku_show_id
  bool GetYoukuShowIDByItemId(uint64 item_id, std::string* youku_show_id) const;
  bool GetYoukuShowIDByDocId(int32 doc_id, std::string* youku_show_id) const;
  bool GetItemBidwordByItemId(uint64 item_id, std::string* bidword) const;
  bool GetItemContentByItemId(uint64 item_id, std::string* content) const;
  bool GetItemRawSummaryByItemId(uint64 item_id, std::string* summary) const;
  // 时间单位都是微秒，除以 base::time::kMicrosecondsPerSecond 等常量可以换算成其他时间单位
  // 可以认为是发布时间。有发布时间用发布时间，否则用爬虫抓取时间， 单位微秒
  int64 GetCreateTimestampByItemId(uint64 item_id) const;
  int64 GetCreateTimestampByDocId(int32 docid) const;
  // 失效时间
  int64 GetExpireTimestampByItemId(uint64 item_id) const;
  // 待废弃
  int64 GetPublishSecondByItemId(uint64 item_id) const;
  // 抓取时间
  int64 GetCrawlTimestampByDocId(int32 docid) const;
  int64 GetCrawlTimestampByItemId(uint64 item_id) const;
  // Special Article 相关
  bool GetPreviewIdsByItemId(uint64 item_id, std::unordered_set<uint64>* preview_ids) const;
  bool GetContainIdsByItemId(uint64 item_id, std::unordered_set<uint64>* contain_ids) const;

  // 正文长度和段落数
  int32 GetContentLengthByDocId(int32 docid) const;
  int32 GetParagraphNumByDocId(int32 docid) const;
  // 图片个数
  int32 GetImageCountByDocId(int32 docid) const;
  int32 GetImageCountByItemId(uint64 item_id) const;
  bool GetImageByDocId(int32 doc_id, std::vector<uint64>* image) const;

  // 小说 ID
  bool GetNovelIdByDocId(int32 docid, std::string* novel_id) const;
  bool GetNovelIdByItemId(uint64 item_id, std::string* novel_id) const;
  void GetDocsByNovelId(const std::string& novel_id, std::vector<int32>* doc_id_list,
                        uint64 max_return_size = 0) const;

  // 小说更新时间
  int64 GetNovelUpdateTimestampByDocId(int32 docid) const;
  int64 GetNovelUpdateTimestampByItemId(uint64 item_id) const;

  // 视频个数
  int32 GetVideoCountByDocId(int32 docid) const;
  int32 GetVideoCountByItemId(uint64 item_id) const;
  // 视频总播放时长
  int32 GetTotalVideoLengthByDocId(int32 docid) const;
  int32 GetTotalVideoLengthByItemId(uint64 item_id) const;
  // 视频低俗级别
  VideoAttr::VideoVulgarLevel GetVideoVulgarLevelByDocId(int32 docid) const;
  // 视频质量级别
  VideoAttr::VideoQualityLevel GetVideoQualityLevelByDocId(int32 docid) const;
  // title 长度
  int32 GetTitleLengthByDocId(int32 docid) const;

  // 是否原创
  bool IsYuanchuangDocId(int32 docid) const;
  bool IsYuanchuangItemId(uint64 item_id) const;

  // 视频是否包含自存储地址
  bool HasVideoStorageInfoByDocId(int32 docid) const;
  bool HasVideoStorageInfoByItemId(uint64 item_id) const;

  // 视频自存储状态
  // -1 表示获取失败
  // 0 表示未去水印
  // 1 表示已经去水印
  int GetVideoStorageInfoStatusByDocId(int32 docid) const;
  int GetVideoStorageInfoStatusByItemId(uint64 item_id) const;

  // 获取优酷视频的 ID
  bool GetYoukuVideoIdByDocId(int32 docid, uint64* youku_video_id) const;
  bool GetYoukuVideoIdByItemId(uint64 item_id, uint64* youku_video_id) const;
  bool GetItemIdByYoukuVideoId(uint64 youku_video_id, uint64 *item_id) const;

  // 视频封面图黑边比例 0.0 表示无黑边
  float GetVideoBlackEdgeRatioByDocId(int32 docid) const;
  float GetVideoBlackEdgeRatioByItemId(uint64 item_id) const;

  int32 GetVideoWidthByDocId(int32 docid) const;
  int32 GetVideoWidthByItemId(uint64 item_id) const;

  int32 GetVideoHeightByDocId(int32 docid) const;
  int32 GetVideoHeightByItemId(uint64 item_id) const;

  int32 GetVideoColorsByDocId(int32 docid) const;
  int32 GetVideoColorsByItemId(uint64 item_id) const;

  bool IsVideoLargeCardDocId(int32 docid) const;
  bool IsVideoLargeCardItemId(uint64 item_id) const;

  // 视频封面图清晰度分数
  float GetVideoPosterClarityByDocId(int32 docid) const;
  float GetVideoPosterClarityItemId(uint64 item_id) const;

  bool GetVideoPosterProblemInfoByDocId(int32 docid, std::set<std::string> *problems) const;
  bool GetVideoPosterProblemInfoByItemId(uint64 item_id, std::set<std::string> *problems) const;

  bool GetVideoPlayControlByDocId(int32 docid, reco::VideoPlayControl *video_play_control) const;
  bool GetVideoPlayControlByItemId(uint64 item_id, reco::VideoPlayControl *video_play_control) const;

  bool GetParagraphByDocId(int32 doc_id, std::vector<uint64>* paragraph) const;

  uint64 GetWholeContentHashByDocId(int32 doc_id) const;

  // 是否经过人工审查
  bool GetHasReviewedByDocId(int32 doc_id) const;
  bool GetHasReviewedByItemId(uint64 item_id) const;

  ///////////// 类别信息 ///////////////////////////
  // 获得指定 app 指定层级的所有类别信息
  // 返回的类别信息是 Category 形式的，带父级类别
  void GetCategories(int level, std::vector<reco::Category>* categories) const;
  // 返回视频的类别信息是 Category 形式的，带父级类别
  void GetVideoCategories(int level, std::vector<reco::Category>* categories) const;
  // 返回本 item id 的类别信息
  bool GetCategoriesByItemId(uint64 item_id, std::vector<reco::Category>* categories) const;
  // 直接 append 调用方负责 categories 的 clear
  bool GetCategoriesByDocId(int32 doc_id, std::vector<std::string>* categories) const;
  bool GetCategoriesByItemId(uint64 item_id, std::vector<std::string>* categories) const;

  bool GetMultiCategoriesByDocId(int32 doc_id, MultiCategory* multi_category) const;
  bool GetMultiCategoriesByItemId(uint64 item_id, MultiCategory* multi_category) const;

  bool GetCategoryScore(uint64 item_id, const reco::Category& category, float* score) const;
  bool GetCategoryScore(uint64 item_id, const std::string& category, float* score) const;

    // 获取本 item id 的 source
  bool GetSourceByItemId(uint64 item_id, std::string* source) const;
  bool GetSourceByDocId(int32 doc_id, std::string* source) const;

  bool GetOrigMediaRiskTypeByItemId(uint64 item_id, int32* orig_media_risk_type) const;
  bool GetOrigMediaRiskTypeByDocId(int32 doc_id, int32* orig_media_risk_type) const;

  // 获取 app token / producer
  bool GetProducerByDocId(int32 doc_id, std::string* app_token) const;
  // item mining quality attr 相关, 返回 -1 表示不存在
  int32 GetJingpinScoreByDocId(int32 doc_id) const;

  bool GetOrigSourceByItemId(uint64 item_id, std::string* orig_source) const;
  bool GetOrigSourceByDocId(int32 doc_id, std::string* orig_source) const;

  bool GetShowSourceByItemId(uint64 item_id, std::string* show_source) const;
  bool GetShowSourceByDocId(int32 doc_id, std::string* show_source) const;
  bool GetFilterChainByItemId(uint64 item_id,
                              RuleChain* filter_chain) const;

  bool GetSourceMediaByItemId(uint64 item_id, std::string* source_media) const;
  bool GetSourceMediaByDocId(int32 doc_id, std::string* source_media) const;

  bool GetOrigSourceMediaByItemId(uint64 item_id, std::string* orig_source_media) const;
  bool GetOrigSourceMediaByDocId(int32 doc_id, std::string* orig_source_media) const;
  // 获取类别下对应媒体等级的媒体数量
  int32 GetCateMediaLevelNum(const std::string& cate_level) const;

  // 获取优酷渠道视频的二审状态
  bool GetYoukuAuditStatusByItemId(uint64 item_id) const;
  ///////////// 获取推荐信息 ///////////////////////////
  // 获取默认推荐
  const std::vector<ItemInfo>* GetDefaultReco() const;
  // 获取分类下的默认推荐
  const std::vector<ItemInfo>* GetDefaultReco(const reco::Category& category, bool timely = false) const;
  const std::vector<ItemInfo>* GetGuaranteeQuantityReco(const reco::Category& category) const;
  const std::vector<ItemInfo>* GetVideoGuaranteeQuantityReco(const reco::Category& category) const;
  // 获取 channel 下的默认推荐, region_id 只对 channel_id 为本地频道时生效, 不是本地频道时，请取值-1
  // only_video 对非视频频道生效, only_video == true 时返回的 ItemInfo 只有纯视频
  const std::vector<ItemInfo>* GetDefaultReco(int64 channel_id, int64 region_id, bool only_video) const;
  // 获取分类下的视频默认推荐
  const std::vector<ItemInfo>* GetVideoDefaultReco(const reco::Category& category) const;

  // 获取频道下的视频默认推荐
  const std::vector<ItemInfo>* GetVideoDefaultReco(const int64 channel_id,
                                                   bool explore = false,
                                                   bool is_fully_shown = false) const;
  // 获取 ucb 默认推荐
  const std::vector<ItemInfo>* GetUCBDefaultReco() const;
  // 获取热门卡片
  const std::vector<ItemInfo>* GetHotCardDefaultReco() const;
  // 获取精品文章的默认推荐
  const std::vector<ItemInfo>* GetJingpinDefaultReco() const;
  // 获取主题的默认推荐
  const std::vector<ItemInfo>* GetSubjectDefaultReco() const;
  // 热门视频
  // const std::vector<ItemInfo>* GetHotVideoDefaultReco() const;
  // 获取本地频道的默认推荐
  const std::vector<ItemInfo>* GetLocalDefaultReco(int64 region_id) const;
  // 获取基于 POI 的默认推荐
  const std::vector<ItemInfo>* GetPOIDefaultReco(int64 area_id) const;
  // 获取本地突发事件的默认推荐
  const std::vector<ItemInfo>* GetLocalBreakingDefaultReco(int64 region_id) const;
  // 获取本地突发事件 item 的突发属性词典
  const std::unordered_map<uint64, reco::LocalBreaking>* GetItemBreakingDict() const {
    return sort_item_->GetItemBreakingDict();
  }
  const std::unordered_map<std::string, std::unordered_set<uint64>>* GetWeMediaItemsDict() const;
  // 获取剧集 id（youku_show_id）相关的索引
  const std::vector<ItemInfo>* GetItemsByYoukuShowId(const std::string& youku_show_id) const;
  // 获取离线挖掘的新闻
  const std::vector<ItemInfo>* GetMiningStrategyReco(int32 strategy) const;

  // 获取对应 index_type 和 tag 的当日新闻数量
  int GetTodayNewsNum() const;
  int GetTodayNewsNum(const reco::Category& category) const;

  // 获取给定新闻在 某个时间/某个 channel 下的优先级，非置顶新闻直接返回 0
  // time 的格式应该满足 yyyy-MM-dd HH:mm:ss  格式，否则不保证结果的准确性
  int GetPriority(int32 doc_id, const std::string& time, int64 channel_id) const;

  // 性能优化需要
  // 谨慎使用，1 分钟内可能修改失效
  const std::unordered_map<uint64, UcBrowserDeliverSetting>* GetUcbSettingDict() const {
    return sort_item_->GetUcbSettingDict();
  }

  bool GetGroupInfoByDocId(int32 doc_id, ItemGroupInfo* group_info) const;
  bool GetUCBSettingByItemId(uint64 item_id, UcBrowserDeliverSetting* ucb_setting) const;
  bool GetItemQualityAttrByItemId(uint64 item_id, ItemQualityAttr* quality_attr) const;
  int32 GetOrgiItemQByItemId(uint64 item_id) const;
  bool GetOrgiItemQByItemId(uint64 item_id, int32* poster_itemq) const;
  // 标题里的核心标签. 返回的 core tags 已经按照标签的权重排序了
  // return false 表示没有核心标签.
  bool GetTitleCoreTagsByItemId(uint64 item_id, std::vector<std::string>* core_tags) const;

  int32 GetUCBStyleTypeByDocId(int32 doc_id) const;
  std::string GetUCBEditorNameByDocId(int32 doc_id) const;

  ///////////// 特征信息 ///////////////////////////
  bool GetFeatureStringByDocId(int32 doc_id, reco::common::FeatureType type,
    std::string* literal, std::string* feature, double* norm2) const;

  // 从索引 ID 得到特征 (会填充特征的 type, literal, weight)
  bool GetFeatureMapByDocId(int32 doc_id, reco::common::FeatureType type,
                            std::map<std::string, double>* feature,
                            double* norm2) const;
  // 从 item id 得到特征 (会填充特征的 type, literal, weight)
  bool GetFeatureVectorByItemId(uint64 item_id, reco::common::FeatureType type,
                                reco::FeatureVector* feature) const;
  // 从 item id 得到视频 tag 特征
  bool GetVideoTagFeatureVectorByItemId(uint64 item_id, reco::FeatureVector* feature) const;

  // 获取 lda topic
  bool GetTitleLdaTopicByItemId(uint64 item_id, reco::FeatureVector* feature) const;
  void GetDocsByTitleLdaTopic(const std::string& topic, std::vector<int32>* doc_id_list,
                        uint64 max_return_size = 0) const;

  // 获取 item_id 对应的 sim_item ids
  const std::set<uint64>* GetSimItemIds(uint64 item_id) const;
  // bool GetSimItemIds(uint64 item_id, std::vector<uint64>* sim_ids) const;
  bool HasCheckedBySimServer(uint64 item_id) const;
  uint64 GetParentId(uint64 item_id) const;
  ///////////// 正确性校验 ///////////////////////////
  // 到索引中重新检查 ItemInfo 的信息是否正确
  bool IsValidByItemId(uint64 item_id) const;
  bool IsValidByDocId(int32 docid) const;

  bool IsManualByItemId(uint64 item_id) const;
  bool IsManualByDocId(int32 docid) const;

  // 是否过期
  bool IsExpiredByItemId(uint64 item_id, int64 now_timestamp) const;
  bool IsExpiredByDocId(int32 docid, int64 now_timestamp) const;

  // 对特定渠道是否有效
  bool IsValidInAppByItemId(uint64 item_id, reco::common::AppNames app) const;
  bool IsValidInAppByDocId(int32 docid, reco::common::AppNames app) const;

  // 直接 append, 调用方负责 channels 的 clear
  bool GetChannelsByDocId(int32 doc_id, std::vector<int64>* channels) const;

  bool GetRegionIdByDocId(int32 doc_id, std::vector<int64>* region_ids) const;
  bool GetRestrictRegionIdByDocId(int32 doc_id, std::vector<int64> *restrict_region_ids) const;
  bool GetTitleRegionIdByDocId(int32 doc_id, std::vector<int64>* region_ids) const;

  bool GetSubscriptsByDocId(int32 doc_id, ItemSubscipts *subscripts) const;
  bool GetShowTagByDocId(int32 doc_id, std::vector<std::string> *show_tags) const;
  bool GetShowTagByItemId(uint64 item_id, std::vector<std::string> *show_tags) const;

  void GetDocsByChannelId(uint64 channel_id, std::vector<int32>* doc_id_list) const;
  void GetDocsByAppToken(const std::string& app_token, std::vector<int32>* doc_id_list) const;
  void GetDocsByCategory(const std::string& category, int level, std::vector<int32>* doc_id_list,
                         uint64 max_return_size = 0) const;
  void GetDocsByMultiCategory(const std::string& category, int level, std::vector<int32>* doc_id_list) const;
  void GetDocsByKeywordOrTag(const std::string& word, std::vector<int32>* doc_id_list) const;
  void SetTagCache(const std::string& tag, std::vector<int32>* doc_id_list);
  bool GetTagCache(const std::string& tag, std::vector<int32>* doc_id_list) const;
  void AsyncProcessTag();

  void GetDocsByTag(const std::string& tag, std::vector<int32>* doc_id_list,
                    uint64 max_return_size = 0) const;
  void GetDocsByTag(const std::string& tag, std::vector<int32>* doc_id_list,
                    reco::ItemType item_type,
                    uint64 max_return_size = 0) const;
  void GetDocsByShowTag(const std::string& tag,
                        std::vector<int32>* doc_id_list, uint64 max_return_size = 0) const;
  void GetDocsBySource(const std::string& source,
                       std::vector<int32>* doc_id_list, uint64 max_return_size = 0) const;
  void GetDocsByTerm(const std::string& term, std::vector<int32>* doc_id_list) const;
  void GetDocsByItemType(int32 item_type, std::vector<int32>* doc_id_list) const;
  void GetDocsByRegionID(const std::string &region_id, std::vector<int32>* doc_id_list) const;
  void GetDocsByWeMedia(std::vector<int32>* doc_id_list) const;
  // 查询 ContentAttr 属性， 建议 attr 只能针对一个 content 属性进行设置
  void GetDocsByContentAttr(const reco::ContentAttr& attr,
                            std::vector<int32>* doc_id_list) const;
  // 有些 item 里记录了这条新闻是从哪条 query 抓取回来的， 这个接口可以把他们检索出来
  void GetDocsBySpiderQuery(const std::string& query,
                            std::vector<int32>* doc_id_list) const;


  // category 数组到 Category 的转换
  void ConvertToCategoryProto(const std::vector<std::string>& categories, int level,
                              reco::Category* category) const;

  bool GetWeMediaPersonByDocId(int32 doc_id, std::string* wemedia_person) const;
  bool GetWeMediaPersonByItemId(uint64 item_id, std::string* wemedia_person) const;

  std::vector<reco::index_data::SourceInfo> SearchWemediaAuthor(const std::string& query,
                                                                bool filter_unpub) const;

  // is_trival 为 true 表示 ContentAttr 里所有属性都为 0， 不需要做处理
  bool GetContentAttrByDocId(int32 doc_id, ContentAttr* content_attr, bool* is_trival) const;
  bool GetContentAttrByItemId(uint64 item_id, ContentAttr* content_attr, bool* is_trival) const;

  bool GetGaoDePOIByDocId(int32 doc_id, GaoDePOI* gaode_poi) const;
  bool GetGaoDePOIByItemId(uint64 item_id, GaoDePOI* gaode_poi) const;

  // 对于 ItemType 为 kTimeAxisPage 的内容，通过 doc_id 获取整个时间轴的信息
  bool GetTimeAxisResultsByDocId(int32 doc_id, time_axis::TimeAxisResults *time_axis_results) const;

  bool ContainInCategoryQueue(const reco::Category& category, int32 doc_id) const;

  // 通过 item_id 查找其所在的时间轴
  bool GetItemTimeAxisInfoByItemId(uint64 item_id, time_axis::TimeAxisInfo *timeaxis_info) const;
  bool GetLatestNewsByEventName(const std::string& event_name, uint64* latest_item_id,
          time_axis::TimeAxisInfo* timeaxis_info) const;

  bool GetVideoStatInfoByItemId(uint64 item_id, VideoStatInfo* info) const;

  // bool GetOriginInfoByItemId(uint64 item_id, uint64* origin_item_id) const;

  // bool GetYCInfoByItemId(uint64 item_id, uint64* yc_item_id) const;

  bool GetWemediaMeta(const std::string& source, IndexDictManager::WemediaMeta* meta) const;

  bool CheckVideo2ndChannel(int64 channel_id) {
    if (sort_item_) {
      return sort_item_->CheckVideo2ndChannel(channel_id);
    }
    return false;
  }
  std::map<int64, ChannelRule> DumpChannelRules() const {
    return sort_item_->DumpChannelRules();
  }

  int64 GetPublishSecond(int32 docid) const;
  // 只能得到事件名字
  bool GetEventTagByDocId(int32 doc_id, std::vector<std::string> *event_tags) const;
  bool GetEventTagByItemId(uint64 item_id, std::vector<std::string> *event_tags) const;
  void GetDocsByEventTag(const std::string& tag, std::vector<int32>* doc_id_list,
                         uint64 max_return_size = 0) const;
  // 得到事件名字和文章 id
  bool GetEventTagInfoByDocId(int32 doc_id, std::vector<reco::EventTagInfo> *event_tags) const;
  bool GetEventTagInfoByItemId(uint64 item_id, std::vector<reco::EventTagInfo> *event_tags) const;

  void SetItemAttr(uint64 item_id, ItemsFeature& items_feature) const;
  int GetItemIndex(uint64 item_id) const;
  const ItemFea& GetItemFea(int index) const;

  bool GetSubjectSubItemByItemId(uint64 item_id, reco::SubjectSubItems* subject_sub_items) const;

  // 获取 item 对应的 subject_id
  bool GetSubjectIdByItemId(uint64 item_id, uint64* subject_id) const;

  // 获取 subject 对应的 video tag feature
  const reco::FeatureVector* GetSubjectVideoTagFeatureByItemId(uint64 item_id) const;

  // 得到本地突发事件
  bool GetLocalBreakingByDocId(int32 doc_id, reco::LocalBreaking* local_breaking) const;
  bool GetLocalBreakingByItemId(uint64 item_id, reco::LocalBreaking* local_breaking) const;
  bool ContainLocalBreakingByItemId(uint64 item_id) const;

  // 获取保量相关信息, in: type, item; out: media_quantity_info, item_limit 返回值 true: 表示有保量信息
  bool GetItemQuantityInfo(const QueueType & type,
                           const ItemInfo & item,
                           MediaQuantityInfo* media_quantity_info,
                           int64* item_limit) const {
    return MediaQuantityInfoIns::instance().GetItemQuantityInfo(
             type, item, media_quantity_info, item_limit);
  }

  bool GetSubjectSubItemIds(uint64 item_id, std::vector<uint64>* subject_sub_itemids) const;
  int32 GetAppTokenBitsByDocId(int32 doc_id) const;
  int32 GetAppTokenBitsByItemId(uint64 item_id) const;
  bool GetAppTokenRuleBitsByDocId(int32 doc_id, std::string *rule_bits) const;
  bool GetAppTokenRuleBitsByItemId(uint64 item_id, std::string *rule_bits) const;
  int32 GetFirstNScreenFilterByDocId(int32 doc_id) const;
  int32 GetFirstNScreenFilterByItemId(uint64 item_id) const;
  int64 GetSourcePublishPlatformByDocId(uint64 doc_id) const;
  int64 GetSourcePublishPlatformByItemId(uint64 item_id) const;

  int32 GetItemResolutionByDocId(uint64 doc_id) const;
  int32 GetItemResolutionByItemId(uint64 item_id) const;

  bool GetItemAttachDataExtByItemId(const uint64& item_id, ItemAttachDataExt* item_attach_data_ext) const;
  bool GetItemContentPoolIdsByItemId(const uint64& item_id, std::vector<int>* content_pool_ids) const;
  bool GetItemContentPoolIdsByItemId(const uint64& item_id, std::string* content_pool_ids) const;

 private:
  // 今日新闻数
  int GetTodayNewsNum(const std::vector<ItemInfo>& item_list);

  // 时间
  // NOTE 只作为内部使用，防止外部 item 失效使用老时间
  int64 GetExpireTimestamp(int32 docid) const;
  // doc 合并
  void UnionDocs(adsindexing::DocIterator* doc_iter1,
                 adsindexing::DocIterator* doc_iter2,
                 std::vector<int32>* doc_id_list, size_t max_num = 0) const;
  // doc 交集
  void MixDocs(adsindexing::DocIterator* doc_iter1,
               adsindexing::DocIterator* doc_iter2,
               std::vector<int32>* doc_id_list, size_t max_num = 0) const;

  // 解析出来的视频 tag 是不带前缀的，并且如果审核过，只取前缀是 manual 的 tag
  void ParseVideoTagFeatureVector(uint64 item_id,
                                  const reco::FeatureVector& raw_feature,
                                  reco::FeatureVector *real_feature) const;

  // 解析 item attach data ext
  bool ParseItemAttachDataExt(const uint64& item_id,
                              const std::string& item_attach_data_ext_attr,
                              ItemAttachDataExt* item_attach_data_ext) const;

 private:
  static const char* kSourceFile;
  friend NewsIndex* InitializeNewsIndex(const adsindexing::Index* index);

  explicit NewsIndex(const adsindexing::Index* index);

  const adsindexing::Index* index_;

  uint64 kExpireTimestampSign;
  uint64 kCreateTimestampSign;
  uint64 kCrawlTimestampSign;
  uint64 kPublishSecondSign;
  uint64 kAppTokenSign;
  uint64 kCategorySign;
  uint64 kSourceSign;
  uint64 kOrigSourceSign;
  uint64 kSourceMediaSign;
  uint64 kOrigSourceMediaSign;
  uint64 kItemTypeSign;
  uint64 kOuterIdSign;
  uint64 kKeywordListSign;
  uint64 kKeywordNormSign;
  uint64 kTopicListSign;
  uint64 kTopicNormSign;
  uint64 kPlsaTopicListSign;
  uint64 kPlsaTopicNormSign;
  uint64 kTitleLdaTopicListSign;
  uint64 kTitleLdaTopicNormSign;
  uint64 kWordvecListSign;
  uint64 kWordvecNormSign;
  uint64 kTagListSign;
  uint64 kTagNormSign;
  uint64 kSemanticTagListSign;
  uint64 kSemanticTagNormSign;
  uint64 kChannelSign;
  uint64 kPrioritySign;
  uint64 kNovelIdSign;
  uint64 kNovelUpdateTimeSign;
  uint64 kImageCountSign;
  uint64 kVideoCountSign;
  uint64 kContentLengthSign;
  uint64 kParagraphNumSign;
  uint64 kVideoLengthSign;
  uint64 kVideoVulgarLevelSign;
  uint64 kVideoQualityLevelSign;
  uint64 kTitleLengthSign;
  uint64 kRegionSign;
  uint64 kRestrictRegionSign;
  uint64 kTitleRegionSign;
  uint64 kRawSummarySign;
  uint64 kSpecialPreviewIdListSign;
  uint64 kSpecialContainIdListSign;
  uint64 kUCBSettingSign;
  uint64 kItemQualityAttrSign;
  uint64 kPosteriorItemQSign;
  uint64 kUCBStyleTypeSign;
  uint64 kUCBEditorNameSign;
  uint64 kItemSubscriptsSign;
  uint64 kWeMediaPersonSign;
  uint64 kJingpinScoreSign;
  uint64 kItemIsYuanchuangSign;
  uint64 kContentAttrSign;
  uint64 kImageHashSign;
  uint64 kParagraphHashSign;
  uint64 kWholeContentHashKeySign;
  uint64 kGaoDePOISign;
  uint64 kTimeAxisResultsSign;
  uint64 kItemShowTagSign;
  uint64 kHasVideoStorageInfoSign;
  uint64 kVideoStorageInfoStatusSign;
  uint64 kYoukuVideoIdSign;
  uint64 kItemHasReviewedSign;
  uint64 kMultiCategorySign;
  uint64 kVideoBlackEdgeRatioSign;
  uint64 kVideoPosterProblemInfoSign;
  uint64 kVideoPosterClaritySign;
  uint64 kItemEventTagSign;
  uint64 kItemEventTagInfoSign;
  uint64 kVideoPlayControlSign;
  uint64 kOrigMediaRiskTypeSign;
  uint64 kManualNewsSign;
  uint64 kYoukuShowIDSign;
  uint64 kYoukuAuditStatusSign;
  uint64 kSubjectItemsSign;
  uint64 kLocalBreakingSign;
  uint64 kGroupInfoSign;
  uint64 kVideoWidthSign;
  uint64 kVideoHeightSign;
  uint64 kVideoColorsSign;
  uint64 kAppTokenBitsSign;
  uint64 kAppTokenRuleBitsSign;
  uint64 kFirstNScreenFilterSign;
  uint64 kSourcePublishPlatformSign;
  uint64 kVideoResolutionSign;
  uint64 kItemAttachDataExtSign;

  static const int64 kTimestampInFuture;

  serving_base::ExpiryMap<std::string, reco::FeatureVector>* item_fea_expiry_map_;
  serving_base::ExpiryMap<std::string, std::vector<std::string> >* item_unigram_expiry_map_;
  serving_base::ExpiryMap<uint64, UcBrowserDeliverSetting>* item_ucbsetting_expiry_map_;
  serving_base::ExpiryMap<uint64, ItemQualityAttr>* item_quality_expiry_map_;
  serving_base::ExpiryMap<uint64, std::vector<std::string> >* item_title_core_tags_expiry_map_;
  serving_base::ExpiryMap<std::string, std::vector<int32> >* tag_doc_list_expiry_map_;
  serving_base::ExpiryMap<uint64, ItemAttachDataExt>* item_attach_data_ext_expiry_map_;
  MultiCategoryCache* multi_category_cache_;

  SimItem* sim_item_;
  MetaInfoUpdator* meta_info_updator_;
  // VideoStatInfoUpdator* video_stat_info_updator_;
  // OriginInfoUpdator* origin_info_updator_;
  SourceManager* source_manager_;
  SortItem* sort_item_;
  const IndexDictManager* dict_manager_;
  thread::BlockingQueue<std::string> tag_queue_;
  thread::Mutex tag_mutex_;
  thread::ThreadPool* tag_async_pool;
  std::atomic<int64> tag_call_num_;
  std::atomic<int64> tag_hit_cache_num_;
  std::atomic<int64> last_tag_hit_cache_num_;
  std::atomic<int32> tag_hit_percent_;

  FRIEND_TEST(CDocIndexTest, UCBTest);
  // FRIEND_TEST(NewsIndexTest, BasicInfo);
  friend class SimItem;
  friend class MetaInfoUpdator;
  friend class NewsIndexTest;
  friend class SortItem;
  friend class reco::searchserver::IFlowRanker;
  friend class reco::searchserver::Ranker;
  friend class reco::leafserver::ExternalApi;
  friend class reco::videoserver::ExternalApi;
};
}  // namespace reco

#include "reco/bizc/reco_index/news_index-inl.h"
