#include <vector>
#include <string>
#include <fstream>
#include <set>
#include <algorithm>

#include "reco/bizc/reco_index/source_manager.h"
#include "base/file/file_util.h"
#include "base/encoding/line_escape.h"
#include "base/random/pseudo_random.h"
#include "serving_base/utility/timer.h"

namespace reco {

TEST(SourceManager, Load) {
  SourceManager source_manager;
  source_manager.StartMonitorFile("reco/bizc/reco_index/test_data/source_info.data");
  std::vector<reco::index_data::SourceInfo> results =
      source_manager.SearchWemediaAuthor("小道互联网", false);
  for (size_t i = 0; i < results.size(); ++i) {
    LOG(ERROR) << results[i].Utf8DebugString();
  }
  for (int i = 0; i < 10; ++i) {
    CHECK(base::file_util::TouchFile("reco/bizc/reco_index/test_data/source_info.data",
                          base::Time::Now(), base::Time::Now()));
    base::SleepForSeconds(10);
  }
  source_manager.StopMonitorFile();
}

struct Inner {
  std::string cate;
  std::string sub_cate;
  float lr_score;
};

struct Item {
  uint64 item_id;
  Inner* inner;
  Inner* operator->() const {  // never throws
    return inner;
  }
};

struct ItemHeavy {
  uint64 item_id;
  std::string cate;
  std::string sub_cate;
  float lr_score;
};


bool comp1(const Item &a, const Item &b) {
  return a->lr_score < b->lr_score;
}

bool comp2(const ItemHeavy &a, const ItemHeavy &b) {
  return a.lr_score < b.lr_score;
}

TEST(SourceManager, test) {
  base::PseudoRandom random;
  std::vector<ItemHeavy> item_info;
  std::vector<Item> item;
  for (int i = 0; i < 10000; ++i) {
    float score = random.GetDouble();

    ItemHeavy i1;
    i1.item_id = i;
    i1.cate = "科技";
    i1.sub_cate = "互联网";
    i1.lr_score = score;
    item_info.push_back(i1);

    Item i2;
    i2.item_id = i;
    i2.inner = new Inner();
    i2->cate = "科技";
    i2->sub_cate = "互联网";
  }

  serving_base::Timer timer;

  timer.Start();
  std::sort(item_info.begin(), item_info.end(), comp2);
  LOG(INFO) << "heavy item sort cost:" << timer.Stop() << "us";

  timer.Start();
  std::sort(item.begin(), item.end(), comp1);
  LOG(INFO) << "light item sort cost:" << timer.Stop() << "us";
}
}  // namespace reco
