#pragma once
#include <vector>
#include <string>

#include "reco/bizc/reco_index/news_index.h"
#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"

#include "base/file/file_util.h"
#include "base/encoding/line_escape.h"

#include "ads_index/api/public.h"
#include "ads_index/dynamic_index/dynamic_index.h"
#include "ads_index/mix_index/mix_index.h"
#include "ads_index/proto/index.pb.h"

namespace reco {
class ItemCDocConvertor;
// thread unsafe
class MockIndexBuilder {
 public:
  MockIndexBuilder();
  ~MockIndexBuilder();

  void AddDoc(int item_type, uint64 item_id,
              const std::string& title,
              const std::string& category,
              const std::string& source,
              const std::string& keyword);

  void AddDoc(const reco::RecoItem& item) {
    items_.push_back(item);
  }

  // 动态增加 item 到索引中
  void AddItemOnline(const std::vector<reco::RecoItem>& items);

  // index_dir: index dir to put index data in
  // static_dict_filename: ads_index/api/data/static_dict.dat
  void BuildIndex(const std::string& index_dir,
                  const std::string& static_dict_filename);

  const reco::NewsIndex* GetNewsIndex() {
    return news_index_;
  }

 private:
  std::vector<reco::RecoItem> items_;
  adsindexing::DynamicIndex* index_;
  reco::NewsIndex* news_index_;
  base::Time now_;

  reco::ItemCDocConvertor* cdoc_convertor_;
};
}  // reco
