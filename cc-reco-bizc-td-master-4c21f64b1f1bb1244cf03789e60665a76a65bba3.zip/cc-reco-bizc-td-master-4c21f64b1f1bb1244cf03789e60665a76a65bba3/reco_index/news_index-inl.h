#pragma once

#include <cstdatomic>
#include <cmath>
#include <set>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>

#include "reco/base/common/uri_process.h"
#include "reco/bizc/common/channel_define.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/reco_index/sort_item.h"
#include "ads_index/api/public.h"
#include "ads_index/proto/index.pb.h"
#include "base/strings/string_split.h"
#include "reco/bizc/common/index_util.h"
#include "extend/json/jansson/jansson.h"

namespace adsindexing {
class Index;
}

namespace reco {
inline bool NewsIndex::GetItemIdByDocId(int32 doc_id, uint64* item_id) const {
  const adsindexing::DocInfo* doc_info = index_->GetDocInfo(doc_id);
  if (doc_info == NULL) return false;
  *item_id = doc_info->key_sign;
  return true;
}

inline bool NewsIndex::GetDocIdByItemId(uint64 item_id, int32* doc_id) const {
  int id = index_->DocLocalIDFromKeySign(item_id);
  if (id == -1) {
    return false;
  }
  *doc_id = id;
  return true;
}

  // 从索引 ID 得到 Item Type
inline bool NewsIndex::GetItemTypeByDocId(int32 doc_id, reco::ItemType* item_type) const {
  int64 attr = index_->GetIntAttr(kItemTypeSign, doc_id, reco::kNone);
  if (reco::ItemType_IsValid(attr) && attr != 255) {
    *item_type = static_cast<reco::ItemType>(attr);
    return true;
  }
  return false;
}

inline bool NewsIndex::GetAreaUnigramsByItemId(uint64 item_id, adsindexing::DocAreaType area_type,
                              std::vector<std::string>* unigrams) const {
  std::string cache_key = base::StringPrintf("%lu_%d", item_id, area_type);
  if (item_unigram_expiry_map_->FindSilently(cache_key, unigrams)) {
    return true;
  }

  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;

  suc = GetAreaUnigramsByDocId(doc_id, area_type, unigrams);
  if (suc) {
    item_unigram_expiry_map_->Add(cache_key, *unigrams);
  }
  return suc;
}


inline bool NewsIndex::GetAreaUnigramsByDocId(int32 doc_id,
                                              adsindexing::DocAreaType area_type,
                                              std::vector<std::string>* unigrams) const {
  CHECK_NOTNULL(unigrams);
  unigrams->clear();

  scoped_ptr<adsindexing::HitIterator> hit(index_->NewHitIterator(doc_id));
  const std::vector<adsindexing::HitIterator::DocArea>& areas = hit->GetAllDocArea();
  for (size_t i = 0; i < areas.size(); ++i) {
    if (areas[i].type == area_type) {
      hit->GetRawUnigrams(areas[i].begin, areas[i].end, index_, unigrams);
      break;
    }
  }

  return true;
}

inline bool NewsIndex::GetItemTypeByItemId(uint64 item_id, reco::ItemType* item_type) const {
  int32 doc_id = 0;
  if (!GetDocIdByItemId(item_id, &doc_id)) return false;
  if (!GetItemTypeByDocId(doc_id, item_type)) return false;
  return true;
}

inline bool NewsIndex::GetPreviewIdsByItemId(uint64 item_id, std::unordered_set<uint64>* preview_ids) const {
  preview_ids->clear();
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  std::string preview_str = index_->GetStringAttr(kSpecialPreviewIdListSign, doc_id, "");
  std::vector<std::string> id_list;
  base::SplitString(preview_str, ",", &id_list);
  uint64 id;
  for (int i = 0; i < (int)id_list.size(); ++i) {
    if (base::StringToUint64(id_list[i], &id)) {
      preview_ids->insert(id);
    }
  }
  return true;
}

inline bool NewsIndex::GetContainIdsByItemId(uint64 item_id, std::unordered_set<uint64>* contain_ids) const {
  contain_ids->clear();
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  std::string contain_str = index_->GetStringAttr(kSpecialContainIdListSign, doc_id, "");
  std::vector<std::string> id_list;
  base::SplitString(contain_str, ",", &id_list);
  uint64 id;
  for (int i = 0; i < (int)id_list.size(); ++i) {
    if (base::StringToUint64(id_list[i], &id)) {
      contain_ids->insert(id);
    }
  }
  return true;
}

inline bool NewsIndex::GetItemBidwordByItemId(uint64 item_id, std::string* bidword) const {
  std::vector<std::string> unigrams;
  bool suc = GetAreaUnigramsByItemId(item_id, adsindexing::kBidWordArea, &unigrams);
  if (!suc) return false;

  base::FastJoinStrings(unigrams, "", bidword);

  return true;
}

inline bool NewsIndex::GetItemContentByItemId(uint64 item_id, std::string* content) const {
  std::vector<std::string> unigrams;
  bool suc = GetAreaUnigramsByItemId(item_id, adsindexing::kContentArea, &unigrams);
  if (!suc) return false;

  base::FastJoinStrings(unigrams, "", content);

  return true;
}

inline bool NewsIndex::GetItemRawSummaryByItemId(uint64 item_id, std::string* content) const {
  content->clear();
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  *content = index_->GetStringAttr(kRawSummarySign, doc_id, "");
  return !content->empty();
}

inline bool NewsIndex::GetItemInfoByItemId(uint64 item_id, ItemInfo* item_info, bool only_basic) const {
  if (!GetDocIdByItemId(item_id, &(item_info->doc_id))) {
    return false;
  }
  return GetItemInfoByDocId(item_info->doc_id, item_info, only_basic);
}

inline bool NewsIndex::GetItemInfoByDocId(int32 doc_id, ItemInfo* item_info, bool only_basic) const {
  if (!GetItemIdByDocId(doc_id, &(item_info->item_id))) {
    return false;
  }
  VLOG(1) << "doc_id:" << doc_id << ", item_id:" << item_info->item_id;
  if (!GetItemTypeByDocId(doc_id, &(item_info->item_type))) {
    return false;
  }
  VLOG(1) << "item_id:" << item_info->item_id << ", item_type:" << item_info->item_type;
  item_info->doc_id = doc_id;
  if (only_basic) return true;

  if (!GetMetaInfo(item_info->item_id, item_info)) {
    return false;
  }

  std::vector<std::string> categories;
  if (!GetCategoriesByDocId(doc_id, &categories) || categories.empty()) {
    LOG(ERROR) << "item has no category, " << item_info->item_id;
    return false;
  }
  item_info->category = categories[0];
  if (categories.size() > 1u) {
    item_info->sub_category = categories[1];
  }
  item_info->create_timestamp = GetCreateTimestampByDocId(doc_id);

  std::string source_media;
  if (!GetSourceMediaByDocId(doc_id, &source_media)) {
    // LOG(WARNING) << "can't get source media, doc_id: " << doc_id;
  }
  item_info->source_media_sign = base::CalcTermSign(source_media.c_str(), source_media.size());
  std::string orig_source_media;
  if (!GetOrigSourceMediaByDocId(doc_id, &orig_source_media)) {
    // LOG(WARNING) << "can't get orig source media, doc_id: " << doc_id;
  }
  item_info->orig_source_media_sign = base::CalcTermSign(orig_source_media.c_str(), orig_source_media.size());

  // 初始源媒体风险
  int32 orig_media_risk_type;
  GetOrigMediaRiskTypeByDocId(doc_id, &orig_media_risk_type);
  item_info->orig_media_risk_type = orig_media_risk_type;

  // 种子源签名
  std::string source;
  if (!GetSourceByDocId(doc_id, &source)) {
    // LOG(WARNING) << "can't get source, doc_id: " << doc_id;
  }
  item_info->source_sign = base::CalcTermSign(source.c_str(), source.size());

  static const char* wemedia_source = "cp_wemedia_uc_";
  static const size_t wemedia_size = strlen(wemedia_source);
  if (source.size() >= wemedia_size) {
    size_t i = 0;
    for (; i < wemedia_size; ++i) {
      if (source[i] != wemedia_source[i]) {
        break;
      }
    }
    item_info->is_source_wemedia = (i == wemedia_size);
  }

  // calc media level
  if (item_info->is_source_wemedia) {
    item_info->media_level = reco::kNormalMedia;
  } else {
    item_info->media_level = reco::kLowMedia;
  }
  // 机构媒体：用 类别 + "\t" + 名称 做 key 进行查找
  auto const cate_media_level_map = dict_manager_->GetCategoryMediaLevelMap();
  const std::string used_media = (!orig_source_media.empty()) ? orig_source_media : source_media;
  const std::string cate_media = item_info->category + "\t" + used_media;
  auto level_iter = cate_media_level_map->find(cate_media);
  if (level_iter == cate_media_level_map->end()) {
    level_iter = cate_media_level_map->find("全部\t" + used_media);
  }
  if (level_iter != cate_media_level_map->end()) {
    item_info->media_level = level_iter->second;
  }

  item_info->first_n_hide = GetFirstNScreenFilterByDocId(doc_id);
  std::string rule_bits;
  int bitnum = GetAppTokenBitsByDocId(doc_id);
  if (bitnum > 0 && GetAppTokenRuleBitsByDocId(doc_id, &rule_bits)) {
    size_t size = rule_bits.size() * 8;
    item_info->app_rule_mask.resize(size, false);
    boost::from_block_range(rule_bits.begin(), rule_bits.end(), item_info->app_rule_mask);
  } else {
    item_info->app_rule_mask.resize(0, false);
  }
  return true;
}

inline bool NewsIndex::GetItemInfoHa3ByDocId(int32 doc_id, ItemInfoHa3* item_info) const {
  item_info->set_keyword_norm(index_->GetFloatAttr(kKeywordNormSign, doc_id, 0.0));
  item_info->set_plsa_topic_norm(index_->GetFloatAttr(kPlsaTopicNormSign, doc_id, 0.0));
  item_info->set_semantic_tag_norm(index_->GetFloatAttr(kSemanticTagNormSign, doc_id, 0.0));
  item_info->set_tag_norm(index_->GetFloatAttr(kTagNormSign, doc_id, 0.0));
  item_info->set_topic_norm(index_->GetFloatAttr(kTopicNormSign, doc_id, 0.0));
  item_info->set_video_black_edge_ratio(index_->GetFloatAttr(kVideoBlackEdgeRatioSign, doc_id, 0.0));
  item_info->set_video_poster_clarity(index_->GetFloatAttr(kVideoPosterClaritySign, doc_id, 0.0));
  item_info->set_wordvec_norm(index_->GetFloatAttr(kWordvecNormSign, doc_id, 0.0));

  item_info->set_content_attr(static_cast<int>(index_->GetIntAttr(kContentAttrSign, doc_id, 0)));
  item_info->set_content_length(static_cast<int>(index_->GetIntAttr(kContentLengthSign, doc_id, 0)));

  item_info->set_crawl_timestamp(index_->GetIntAttr(kCrawlTimestampSign, doc_id, 0));
  item_info->set_create_timestamp(index_->GetIntAttr(kCreateTimestampSign, doc_id, 0));

  item_info->set_docmask(*(index_->GetDocMask(doc_id)));
  item_info->set_expire_timestamp(index_->GetIntAttr(kExpireTimestampSign, doc_id, 0));
  item_info->set_has_video_storage_info(static_cast<int>(
          index_->GetIntAttr(kHasVideoStorageInfoSign, doc_id, 0)));
  item_info->set_image_count(static_cast<int>(index_->GetIntAttr(kImageCountSign, doc_id, 0)));
  item_info->set_item_has_reviewed(static_cast<int>(index_->GetIntAttr(kItemHasReviewedSign, doc_id, 0)));
  item_info->set_item_is_yuanchuang(static_cast<int>(index_->GetIntAttr(kItemIsYuanchuangSign, doc_id, 0)));

  ItemType it;
  if (GetItemTypeByDocId(doc_id, &it)) {
    item_info->set_item_type(it);
  } else {
    item_info->set_item_type(kNone);
  }

  item_info->set_jingpin_score(static_cast<int>(index_->GetIntAttr(kJingpinScoreSign, doc_id, 0)));
  item_info->set_novel_update_time(static_cast<int>(index_->GetIntAttr(kNovelUpdateTimeSign, doc_id, 0)));
  item_info->set_paragraph_num(static_cast<int>(index_->GetIntAttr(kParagraphNumSign, doc_id, 0)));
  item_info->set_posterior_item_q(static_cast<int>(index_->GetIntAttr(kPosteriorItemQSign, doc_id, 0)));
  item_info->set_publish_time(static_cast<int>(index_->GetIntAttr(kPublishSecondSign, doc_id, 0)));
  item_info->set_title_length(static_cast<int>(index_->GetIntAttr(kTitleLengthSign, doc_id, 0)));
  item_info->set_ucbr_style_type(static_cast<int>(index_->GetIntAttr(kUCBStyleTypeSign, doc_id, 0)));
  item_info->set_video_count(static_cast<int>(index_->GetIntAttr(kVideoCountSign, doc_id, 0)));
  item_info->set_video_length(static_cast<int>(index_->GetIntAttr(kVideoLengthSign, doc_id, 0)));
  item_info->set_video_quality_level(static_cast<int>(index_->GetIntAttr(kVideoQualityLevelSign, doc_id, 0)));
  item_info->set_video_storage_info_status(
      static_cast<int>(index_->GetIntAttr(kVideoStorageInfoStatusSign, doc_id, 0)));
  item_info->set_video_vulgar_level(static_cast<int>(index_->GetIntAttr(kVideoVulgarLevelSign, doc_id, 0)));

  item_info->set_app_token(index_->GetStringAttr(kAppTokenSign, doc_id, ""));
  item_info->set_image_hash(index_->GetStringAttr(kImageHashSign, doc_id, ""));
  item_info->set_item_subscripts(reco::common::EncodeUrlComponent(index_->GetStringAttr(kItemSubscriptsSign,
        doc_id, "")));
  item_info->set_novel_id(index_->GetStringAttr(kNovelIdSign, doc_id, ""));
  item_info->set_orig_source_media(index_->GetStringAttr(kOrigSourceMediaSign, doc_id, ""));
  item_info->set_orig_source(index_->GetStringAttr(kOrigSourceSign, doc_id, ""));
  item_info->set_outer_id(index_->GetStringAttr(kOuterIdSign, doc_id, ""));
  item_info->set_paragraph_hash(index_->GetStringAttr(kParagraphHashSign, doc_id, ""));
  item_info->set_raw_summary(index_->GetStringAttr(kRawSummarySign, doc_id, ""));
  item_info->set_region_from_title(index_->GetStringAttr(kTitleRegionSign, doc_id, ""));
  item_info->set_region_restrict(index_->GetStringAttr(kRestrictRegionSign, doc_id, ""));
  item_info->set_region(index_->GetStringAttr(kRegionSign, doc_id, ""));
  item_info->set_source_media(index_->GetStringAttr(kSourceMediaSign, doc_id, ""));
  item_info->set_source(index_->GetStringAttr(kSourceSign, doc_id, ""));
  item_info->set_ucb_editor_name(index_->GetStringAttr(kUCBEditorNameSign, doc_id, ""));
  item_info->set_wemedia_person(index_->GetStringAttr(kWeMediaPersonSign, doc_id, ""));
  item_info->set_youku_video_id(index_->GetStringAttr(kYoukuVideoIdSign, doc_id, ""));
  item_info->set_priority(index_->GetStringAttr(kPrioritySign, doc_id, ""));
  item_info->set_special_contain_item_list(index_->GetStringAttr(kSpecialContainIdListSign, doc_id, ""));
  item_info->set_special_prevew_item_list(index_->GetStringAttr(kSpecialPreviewIdListSign, doc_id, ""));
  item_info->set_video_poster_problem_info(index_->GetStringAttr(kVideoPosterProblemInfoSign, doc_id, ""));
  item_info->set_category(index_->GetStringAttr(kCategorySign, doc_id, ""));
  item_info->set_channel(index_->GetStringAttr(kChannelSign, doc_id, ""));
  item_info->set_item_event_tag(index_->GetStringAttr(kItemEventTagSign, doc_id, ""));
  item_info->set_item_show_tag(index_->GetStringAttr(kItemShowTagSign, doc_id, ""));
  item_info->set_gaode_poi(reco::common::EncodeUrlComponent(index_->GetStringAttr(kGaoDePOISign,
        doc_id, "")));
  item_info->set_item_quality_attr(
      reco::common::EncodeUrlComponent(index_->GetStringAttr(kItemQualityAttrSign, doc_id, "")));
  item_info->set_time_axis_results(reco::common::EncodeUrlComponent(
          index_->GetStringAttr(kTimeAxisResultsSign, doc_id, "")));
  item_info->set_ucbr_deliver(reco::common::EncodeUrlComponent(index_->GetStringAttr(kUCBSettingSign,
        doc_id, "")));
  item_info->set_category_candidates(reco::common::EncodeUrlComponent(
          index_->GetStringAttr(kMultiCategorySign, doc_id, "")));

  item_info->set_subject_sub_items(index_->GetStringAttr(kSubjectItemsSign, doc_id, ""));
  item_info->set_local_breaking(reco::common::EncodeUrlComponent(
        index_->GetStringAttr(kLocalBreakingSign, doc_id, "")));

  std::string title;
  if (GetItemTitleByDocId(doc_id, &title)) {
    item_info->set_title(title);
  } else {
    item_info->set_title("");
  }

  uint64 item_id = 0u;
  if (GetItemIdByDocId(doc_id, &item_id)) {
    item_info->set_item_id(item_id);
  } else {
    return false;
  }

  std::string content;
  if (!GetItemContentByItemId(item_id, &content)) {
    content="";
  }
  item_info->set_content(content);

  std::string literal_str;
  std::string feature_str;
  double norm;
  if (GetFeatureStringByDocId(doc_id, reco::common::kKeyword, &literal_str, &feature_str, &norm)) {
    item_info->set_keyword_list(literal_str);
    item_info->set_keyword_feature_list(feature_str);
  } else {
    item_info->set_keyword_list("");
    item_info->set_keyword_feature_list("");
  }

  if (GetFeatureStringByDocId(doc_id, reco::common::kPlsaTopic, &literal_str, &feature_str, &norm)) {
    item_info->set_plsa_topic_list(literal_str);
    item_info->set_plsa_topic_feature_list(feature_str);
  } else {
    item_info->set_plsa_topic_list("");
    item_info->set_plsa_topic_feature_list("");
  }

  if (GetFeatureStringByDocId(doc_id, reco::common::kSemanticTag, &literal_str, &feature_str, &norm)) {
    item_info->set_semantic_tag_list(literal_str);
    item_info->set_semantic_tag_feature_list(feature_str);
  } else {
    item_info->set_semantic_tag_list("");
    item_info->set_semantic_tag_feature_list("");
  }

  if (GetFeatureStringByDocId(doc_id, reco::common::kTag, &literal_str, &feature_str, &norm)) {
    item_info->set_tag_list(literal_str);
    item_info->set_tag_feature_list(feature_str);
  } else {
    item_info->set_tag_list("");
    item_info->set_tag_feature_list("");
  }

  if (GetFeatureStringByDocId(doc_id, reco::common::kTopic, &literal_str, &feature_str, &norm)) {
    item_info->set_topic_list(literal_str);
    item_info->set_topic_feature_list(feature_str);
  } else {
    item_info->set_topic_list("");
    item_info->set_topic_feature_list("");
  }

  if (GetFeatureStringByDocId(doc_id, reco::common::kWordvec, &literal_str, &feature_str, &norm)) {
    item_info->set_wordvec_list(literal_str);
    item_info->set_wordvec_feature_list(feature_str);
  } else {
    item_info->set_wordvec_list("");
    item_info->set_wordvec_feature_list("");
  }

  return true;
}

inline bool NewsIndex::IsValidByItemId(uint64 item_id) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return false;
  return IsValidByDocId(docid);
}

inline bool NewsIndex::IsValidByDocId(int32 docid) const {
  if (*(index_->GetDocMask(docid)) & adsindexing::kDocMaskInvalid) {
    return false;
  }

  if (*(index_->GetDocMask(docid)) & reco::common::kDocFilterServer) {
    return false;
  }

  return true;
}

inline bool NewsIndex::IsManualByItemId(uint64 item_id) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return false;
  return IsManualByDocId(docid);
}

inline bool NewsIndex::IsManualByDocId(int32 docid) const {
  int64 manual = -1;
  manual = index_->GetIntAttr(kManualNewsSign, docid, -1);
  if (manual > 0) {
    return true;
  }
  return false;
}

inline bool NewsIndex::IsExpiredByItemId(uint64 item_id, int64 now_timestamp) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return true;
  return now_timestamp >= GetExpireTimestamp(docid);
}

inline bool NewsIndex::IsExpiredByDocId(int32 docid, int64 now_timestamp) const {
  return now_timestamp >= GetExpireTimestamp(docid);
}

inline bool NewsIndex::IsValidInAppByItemId(uint64 item_id, reco::common::AppNames app) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return false;
  return IsValidInAppByDocId(docid, app);
}

inline bool NewsIndex::IsValidInAppByDocId(int32 docid, reco::common::AppNames app) const {
  switch (app) {
    case reco::common::kUcToutiao:
      return !(*(index_->GetDocMask(docid)) & reco::common::kDocMaskAppToutiao);
    case reco::common::kHuawei:
      return !(*(index_->GetDocMask(docid)) & reco::common::kDocMaskAppHuawei);
    case reco::common::kSamsung:
      return !(*(index_->GetDocMask(docid)) & reco::common::kDocMaskAppSamsung);
    case reco::common::kMeizu:
      return !(*(index_->GetDocMask(docid)) & reco::common::kDocMaskAppMeizu);
    case reco::common::kTuDouIflow:
      return !(*(index_->GetDocMask(docid)) & reco::common::kDocMaskAppTuDouIflow);
    case reco::common::kTuDouPCIflow:
      return !(*(index_->GetDocMask(docid)) & reco::common::kDocMaskAppTuDouIflow);
    case reco::common::kYouKuIflow:
      return (!(*(index_->GetDocMask(docid)) & reco::common::kDocMaskAppTuDouIflow)) &&
             (!(*(index_->GetDocMask(docid)) & reco::common::kDocMaskAppYoukuIflow));
    default:
      return true;
  }
}

inline uint32 NewsIndex::GetDocMaskByItemId(uint64 item_id) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return 0;
  return *(index_->GetDocMask(docid));
}

inline int64 NewsIndex::GetCreateTimestampByItemId(uint64 item_id) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return 0;
  return GetCreateTimestampByDocId(docid);
}

inline int64 NewsIndex::GetExpireTimestampByItemId(uint64 item_id) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return kTimestampInFuture;
  return GetExpireTimestamp(docid);
}

inline int64 NewsIndex::GetCreateTimestampByDocId(int32 docid) const {
  return index_->GetIntAttr(kCreateTimestampSign, docid, 0);
}

inline int64 NewsIndex::GetCrawlTimestampByDocId(int32 docid) const {
  return index_->GetIntAttr(kCrawlTimestampSign, docid, 0);
}

inline int64 NewsIndex::GetCrawlTimestampByItemId(uint64 item_id) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return 0;
  return GetCrawlTimestampByDocId(docid);
}

inline int64 NewsIndex::GetExpireTimestamp(int32 docid) const {
  if (!*(index_->GetDocMask(docid)) & reco::common::kDocMaskTimeWhiteList) {
    return kTimestampInFuture;
  }
  return index_->GetIntAttr(kExpireTimestampSign, docid, kTimestampInFuture);
}

inline int64 NewsIndex::GetPublishSecond(int32 docid) const {
  return index_->GetIntAttr(kPublishSecondSign, docid, 0);
}

inline int64 NewsIndex::GetPublishSecondByItemId(uint64 item_id) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return 0;
  return GetPublishSecond(docid);
}

inline bool NewsIndex::GetRegionIdByDocId(int32 doc_id, std::vector<int64>* region_ids) const {
  region_ids->clear();
  std::string ret_region = index_->GetStringAttr(kRegionSign, doc_id, "");
  if (ret_region.empty()) return false;
  std::vector<std::string> fields;
  base::SplitString(ret_region, ";", &fields);
  int64 region_id;
  for (size_t i = 0; i < fields.size(); ++i) {
    if (base::StringToInt64(fields[i], &region_id)) {
      region_ids->push_back(region_id);
    }
  }
  return true;
}

inline bool NewsIndex::GetRestrictRegionIdByDocId(int32 doc_id,
                                                  std::vector<int64> *restrict_region_ids) const {
  restrict_region_ids->clear();
  std::string ret_region = index_->GetStringAttr(kRestrictRegionSign, doc_id, "");
  if (ret_region.empty()) return false;
  std::vector<std::string> fields;
  base::SplitString(ret_region, ";", &fields);
  int64 region_id;
  for (size_t i = 0; i < fields.size(); ++i) {
    if (base::StringToInt64(fields[i], &region_id)) {
      restrict_region_ids->push_back(region_id);
    }
  }
  return true;
}


inline bool NewsIndex::GetYoukuShowIDByItemId(uint64 item_id, std::string* youku_show_id) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return false;
  return GetYoukuShowIDByDocId(docid, youku_show_id);
}

inline bool NewsIndex::GetYoukuShowIDByDocId(int32 doc_id, std::string* youku_show_id) const {
  if (youku_show_id == NULL) return false;
  youku_show_id->clear();
  *youku_show_id = index_->GetStringAttr(kYoukuShowIDSign, doc_id, "");
  if (youku_show_id->empty()) {
    return false;
  }
  return true;
}

inline bool NewsIndex::GetTitleRegionIdByDocId(int32 doc_id, std::vector<int64>* region_ids) const {
  region_ids->clear();
  std::string ret_region = index_->GetStringAttr(kTitleRegionSign, doc_id, "");
  if (ret_region.empty()) return false;
  std::vector<std::string> fields;
  base::SplitString(ret_region, ";", &fields);
  int64 region_id;
  for (size_t i = 0; i < fields.size(); ++i) {
    if (base::StringToInt64(fields[i], &region_id)) {
      region_ids->push_back(region_id);
    }
  }
  return true;
}

inline int NewsIndex::GetTodayNewsNum() const {
  return sort_item_->GetTodayNewsNum();
}

inline int NewsIndex::GetTodayNewsNum(const reco::Category& category) const {
  return sort_item_->GetTodayNewsNum(category);
}

inline bool NewsIndex::GetSubscriptsByDocId(int32 doc_id, ItemSubscipts *subscripts) const {
  CHECK_NOTNULL(subscripts);
  std::string attr = index_->GetStringAttr(kItemSubscriptsSign, doc_id, "");
  if (attr.empty()) return false;
  if (!subscripts->ParseFromString(attr)) return false;
  return true;
}

inline bool NewsIndex::GetGroupInfoByDocId(int32 doc_id, ItemGroupInfo* group_info) const {
  std::string attr = index_->GetStringAttr(kGroupInfoSign, doc_id, "");
  if (attr.empty()) return false;
  if (!group_info->ParseFromString(attr)) return false;
  return true;
}

inline bool NewsIndex::GetShowTagByDocId(int32 doc_id, std::vector<std::string> *show_tags) const {
  show_tags->clear();
  std::string show_tag_list = index_->GetStringAttr(kItemShowTagSign, doc_id, "");
  if (show_tag_list.empty()) return false;
  base::SplitString(show_tag_list, "|", show_tags);
  return true;
}

inline bool NewsIndex::GetShowTagByItemId(uint64 item_id, std::vector<std::string> *show_tags) const {
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  return GetShowTagByDocId(doc_id, show_tags);
}

inline bool NewsIndex::GetEventTagByDocId(int32 doc_id, std::vector<std::string> *event_tags) const {
  event_tags->clear();
  std::string event_tag_list = index_->GetStringAttr(kItemEventTagSign, doc_id, "");
  if (event_tag_list.empty()) return false;
  base::SplitString(event_tag_list, "|", event_tags);
  return (int)event_tags->size() > 0;
}

inline bool NewsIndex::GetEventTagByItemId(uint64 item_id, std::vector<std::string> *event_tags) const {
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  return GetEventTagByDocId(doc_id, event_tags);
}

inline bool NewsIndex::GetEventTagInfoByDocId(int32 doc_id,
    std::vector<reco::EventTagInfo> *event_tags) const {
  event_tags->clear();
  std::string event_tag_list = index_->GetStringAttr(kItemEventTagInfoSign, doc_id, "");
  if (event_tag_list.empty()) return false;

  std::vector<std::string> event_tag_vec;
  base::SplitString(event_tag_list, "|", &event_tag_vec);
  for (int i = 0; i < (int)event_tag_vec.size(); ++i) {
    reco::EventTagInfo eti;
    if (eti.ParseFromString(event_tag_vec[i])) {
      event_tags->push_back(eti);
    }
  }
  return (int)event_tags->size() > 0;
}
inline bool NewsIndex::GetEventTagInfoByItemId(uint64 item_id,
  std::vector<reco::EventTagInfo> *event_tags) const {
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  return GetEventTagInfoByDocId(doc_id, event_tags);
}

inline bool NewsIndex::GetHasReviewedByDocId(int32 doc_id) const {
  return index_->GetIntAttr(kItemHasReviewedSign, doc_id, 0);
}

inline bool NewsIndex::GetHasReviewedByItemId(uint64 item_id) const {
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) return false;
  return GetHasReviewedByDocId(doc_id);
}

inline int32 NewsIndex::GetTotalVideoLengthByDocId(int32 docid) const {
  return index_->GetIntAttr(kVideoLengthSign, docid, -1);
}

inline int32 NewsIndex::GetTotalVideoLengthByItemId(uint64 item_id) const {
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) return 0;
  return GetTotalVideoLengthByDocId(doc_id);
}

inline VideoAttr::VideoVulgarLevel NewsIndex::GetVideoVulgarLevelByDocId(int32 docid) const {
  return (VideoAttr::VideoVulgarLevel)index_->GetIntAttr(kVideoVulgarLevelSign, docid, 0);
}

inline VideoAttr::VideoQualityLevel NewsIndex::GetVideoQualityLevelByDocId(int32 docid) const {
  return (VideoAttr::VideoQualityLevel)index_->GetIntAttr(kVideoQualityLevelSign, docid, 0);
}

inline int32 NewsIndex::GetTitleLengthByDocId(int32 docid) const {
  return index_->GetIntAttr(kTitleLengthSign, docid, -1);
}

inline bool NewsIndex::GetCategoriesByDocId(int32 docid, std::vector<std::string>* categories) const {
  std::string category = index_->GetStringAttr(kCategorySign, docid, "");
  if (category.empty()) return false;
  categories->clear();
  base::SplitString(category, "\t", categories);
  return true;
}

inline bool NewsIndex::GetCategoriesByItemId(uint64 item_id, std::vector<std::string>* categories) const {
  // 从索引中获取文章类别
  int32 doc_id;
  if (GetDocIdByItemId(item_id, &doc_id) && GetCategoriesByDocId(doc_id, categories)) {
    return true;
  }
  // 从外部索引数据获取文章类别
  auto const itemid_category_map = dict_manager_->GetExtendItemCategoryMap();
  auto i = itemid_category_map->find(item_id);
  if (i != itemid_category_map->end()) {
    (*categories) = i->second;
    return true;
  }
  return false;
}

inline bool NewsIndex::GetMultiCategoriesByDocId(int32 docid,
                                                 MultiCategory* multi_category) const {
  std::string buf = index_->GetStringAttr(kMultiCategorySign, docid, "");
  if (buf.empty()) return false;

  return multi_category->ParseFromString(buf);
}

inline void NewsIndex::ConvertToCategoryProto(const std::vector<std::string>& categories, int level,
                                              reco::Category* category) const {
  category->Clear();
  if (level >= (int)categories.size() || level < 0) {
    LOG(ERROR) << "error level: " << level;
    return;
  }
  category->set_level(level);
  category->set_category(categories[level]);
  for (int i = 0; i < level; ++i) {
    category->add_parents(categories[i]);
  }
}

inline const std::vector<ItemInfo>* NewsIndex::GetDefaultReco() const {
  return sort_item_->GetDefaultReco();
}
inline const std::unordered_map<std::string,
       std::unordered_set<uint64>>* NewsIndex::GetWeMediaItemsDict() const {
  return sort_item_->GetWeMediaItemsDict();
}

inline const std::vector<ItemInfo>* NewsIndex::GetUCBDefaultReco() const {
  return sort_item_->GetUCBDefaultReco();
}

inline const std::vector<ItemInfo>* NewsIndex::GetHotCardDefaultReco() const {
  return sort_item_->GetHotCardDefaultReco();
}

inline const std::vector<ItemInfo>* NewsIndex::GetJingpinDefaultReco() const {
  return sort_item_->GetJingpinDefaultReco();
}

inline const std::vector<ItemInfo>* NewsIndex::GetSubjectDefaultReco() const {
  return sort_item_->GetSubjectDefaultReco();
}

// inline const std::vector<ItemInfo>* NewsIndex::GetHotVideoDefaultReco() const {
//   return sort_item_->GetHotVideoDefaultReco();
// }

inline const std::vector<ItemInfo>* NewsIndex::GetDefaultReco(const reco::Category& category,
                                                              bool timely) const {
  return sort_item_->GetDefaultReco(category, timely);
}

inline const std::vector<ItemInfo>* NewsIndex::GetGuaranteeQuantityReco(const reco::Category& category)
  const {
  return sort_item_->GetGuaranteeQuantityReco(category);
}

inline const std::vector<ItemInfo>* NewsIndex::GetVideoGuaranteeQuantityReco(const reco::Category& category)
  const {
  return sort_item_->GetVideoGuaranteeQuantityReco(category);
}

inline const std::vector<ItemInfo>* NewsIndex::GetVideoDefaultReco(const reco::Category& category) const {
  return sort_item_->GetVideoDefaultReco(category);
}

inline const std::vector<ItemInfo>* NewsIndex::GetLocalDefaultReco(int64 region_id) const {
  return sort_item_->GetLocalDefaultReco(region_id);
}

inline const std::vector<ItemInfo>* NewsIndex::GetPOIDefaultReco(int64 area_id) const {
  return sort_item_->GetPOIDefaultReco(area_id);
}

inline const std::vector<ItemInfo>* NewsIndex::GetLocalBreakingDefaultReco(int64 region_id) const {
  return sort_item_->GetLocalBreakingDefaultReco(region_id);
}

inline const std::vector<ItemInfo>* NewsIndex::GetDefaultReco(int64 channel_id, int64 region_id,
                                                              bool only_video) const {
  return sort_item_->GetDefaultReco(channel_id, region_id, only_video);
}

inline const std::vector<ItemInfo>* NewsIndex::GetVideoDefaultReco(const int64 channel_id,
                                                                   bool explore,
                                                                   bool is_fully_shown) const {
  return sort_item_->GetVideoDefaultReco(channel_id, explore, is_fully_shown);
}

inline const std::vector<ItemInfo>* NewsIndex::GetItemsByYoukuShowId(const std::string& youku_show_id) const {
  return sort_item_->GetItemsByYoukuShowId(youku_show_id);
}

inline const std::vector<ItemInfo>* NewsIndex::GetMiningStrategyReco(int32 strategy) const {
  return sort_item_->GetMiningStrategyReco(strategy);
}

inline int32 NewsIndex::GetUCBStyleTypeByDocId(int32 docid) const {
  return index_->GetIntAttr(kUCBStyleTypeSign, docid, -1);
}

inline std::string NewsIndex::GetUCBEditorNameByDocId(int32 doc_id) const {
  return index_->GetStringAttr(kUCBEditorNameSign, doc_id, "");
}

inline bool NewsIndex::GetCategoriesByItemId(uint64 item_id, std::vector<reco::Category>* categories) const {
  std::vector<std::string> str_categories;
  if (!GetCategoriesByItemId(item_id, &str_categories))
    return false;

  categories->resize(str_categories.size());
  for (int i = 0; i < (int)str_categories.size(); ++i) {
    ConvertToCategoryProto(str_categories, i, &(categories->at(i)));
  }
  return true;
}

inline bool NewsIndex::GetCategoryScore(uint64 item_id, const reco::Category& category, float* score) const {
  return GetCategoryScore(item_id, category.category(), score);
}

inline bool NewsIndex::GetCategoryScore(uint64 item_id, const std::string& category, float* score) const {
  // get from cache first
  int status = multi_category_cache_->Find(item_id, category, score);
  if (status == 0) {
    return false;
  } else if (status == 1) {
    return true;
  }

  MultiCategory multi_category;
  GetMultiCategoriesByItemId(item_id, &multi_category);
  multi_category_cache_->Add(item_id, multi_category);

  status = multi_category_cache_->Find(item_id, category, score);
  if (status == -1) {
    LOG(INFO) << "cannot find item: " << item_id;
  }

  return status == 1;
}

inline bool NewsIndex::GetMultiCategoriesByItemId(uint64 item_id,
                                                  MultiCategory* multi_category) const {
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }

  return GetMultiCategoriesByDocId(doc_id, multi_category);
}

inline bool NewsIndex::GetSourceByDocId(int32 doc_id, std::string* source) const {
  source->clear();
  *source = index_->GetStringAttr(kSourceSign, doc_id, "");
  if (source->empty()) return false;
  return true;
}

inline bool NewsIndex::GetSourceByItemId(uint64 item_id, std::string* source) const {
  source->clear();
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  *source = index_->GetStringAttr(kSourceSign, doc_id, "");
  if (source->empty()) return false;
  return true;
}

inline bool NewsIndex::GetOrigMediaRiskTypeByItemId(uint64 item_id, int32* orig_media_risk_type) const {
  *orig_media_risk_type = -1;
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  *orig_media_risk_type = index_->GetIntAttr(kOrigMediaRiskTypeSign, doc_id, -1);
  if (*orig_media_risk_type < 0) {
    return false;
  }
  return true;
}

inline bool NewsIndex::GetOrigMediaRiskTypeByDocId(int32 doc_id, int32* orig_media_risk_type) const {
  *orig_media_risk_type = -1;
  *orig_media_risk_type = index_->GetIntAttr(kOrigMediaRiskTypeSign, doc_id, -1);
  if (*orig_media_risk_type < 0) {
    return false;
  }
  return true;
}

inline bool NewsIndex::GetWeMediaPersonByItemId(uint64 item_id, std::string* wemedia_person) const {
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  return GetWeMediaPersonByDocId(doc_id, wemedia_person);
}

inline bool NewsIndex::GetWeMediaPersonByDocId(int32 doc_id, std::string* wemedia_person) const {
  *wemedia_person = index_->GetStringAttr(kWeMediaPersonSign, doc_id, "");
  if (wemedia_person->empty()) return false;
  return true;
}

inline std::vector<reco::index_data::SourceInfo>
NewsIndex::SearchWemediaAuthor(const std::string& query, bool filter_unpub) const {
  return source_manager_->SearchWemediaAuthor(query, filter_unpub);
}

inline bool NewsIndex::GetProducerByDocId(int32 doc_id, std::string* producer) const {
  *producer = index_->GetStringAttr(kAppTokenSign, doc_id, "");
  if (producer->empty()) return false;
  return true;
}

inline bool NewsIndex::GetOrigSourceByDocId(int32 doc_id, std::string* orig_source) const {
  orig_source->clear();
  *orig_source = index_->GetStringAttr(kOrigSourceSign, doc_id, "");
  if (orig_source->empty()) return false;
  return true;
}

inline bool NewsIndex::GetOrigSourceByItemId(uint64 item_id, std::string* orig_source) const {
  orig_source->clear();
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  *orig_source = index_->GetStringAttr(kOrigSourceSign, doc_id, "");
  if (orig_source->empty()) return false;
  return true;
}

inline bool NewsIndex::GetShowSourceByDocId(int32 doc_id, std::string* show_source) const {
  show_source->clear();
  std::string source;
  if (!GetSourceByDocId(doc_id, &source)) {
    return false;
  }
  *show_source = source_manager_->GetShowSource(source);
  return true;
}

inline bool NewsIndex::GetShowSourceByItemId(uint64 item_id, std::string* show_source) const {
  show_source->clear();
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  return GetShowSourceByDocId(doc_id, show_source);
}

inline bool NewsIndex::GetSourceMediaByDocId(int32 doc_id, std::string* source_media) const {
  source_media->clear();
  *source_media = index_->GetStringAttr(kSourceMediaSign, doc_id, "");
  if (source_media->empty()) return false;
  return true;
}

inline bool NewsIndex::GetSourceMediaByItemId(uint64 item_id, std::string* source_media) const {
  source_media->clear();
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  return GetSourceMediaByDocId(doc_id, source_media);
}

inline bool NewsIndex::GetOrigSourceMediaByDocId(int32 doc_id, std::string* orig_source_media) const {
  orig_source_media->clear();
  *orig_source_media = index_->GetStringAttr(kOrigSourceMediaSign, doc_id, "");
  if (orig_source_media->empty()) return false;
  return true;
}

inline bool NewsIndex::GetOrigSourceMediaByItemId(uint64 item_id, std::string* orig_source_media) const {
  orig_source_media->clear();
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  return GetOrigSourceMediaByDocId(doc_id, orig_source_media);
}

inline int NewsIndex::GetPriority(int32 doc_id, const std::string& time, int64 channel_id) const {
  const int kDefaultPriority = 0;
  std::string priority_info = index_->GetStringAttr(kPrioritySign, doc_id, "");
  if (priority_info.empty()) return kDefaultPriority;

  std::vector<std::string> flds;
  base::SplitString(priority_info, "\n", &flds);
  int64 id;
  int priority;
  std::vector<std::string> cols;
  for (int i = 0; i < (int)flds.size(); ++i) {
    cols.clear();
    base::SplitString(flds[i], "\t", &cols);
    if (cols.size() != 4
        || !base::StringToInt64(cols[1], &id)
        || !base::StringToInt(cols[0], &priority)) {
      LOG(ERROR) << "priority format error, " << flds[i];
      continue;
    }
    if (channel_id == id) {
      if (cols[2] <= time && time <= cols[3]) {
        return priority;
      } else {
        break;
      }
    }
  }

  return kDefaultPriority;
}

inline bool NewsIndex::GetChannelsByDocId(int32 doc_id, std::vector<int64>* channel_ids) const {
  channel_ids->clear();
  std::string channel = index_->GetStringAttr(kChannelSign, doc_id, "");
  if (channel.empty()) return false;
  std::vector<std::string> flds;
  base::SplitString(channel, "\t", &flds);
  int64 id;
  for (int i = 0; i < (int)flds.size(); ++i) {
    if (!base::StringToInt64(flds[i], &id)) {
      LOG(ERROR) << "err channel id: " << flds[i];
      continue;
    }
    channel_ids->push_back(id);
  }
  return !channel_ids->empty();
}

inline int32 NewsIndex::GetImageCountByDocId(int32 docid) const {
  return index_->GetIntAttr(kImageCountSign, docid, 0);
}

inline int32 NewsIndex::GetContentLengthByDocId(int32 docid) const {
  return index_->GetIntAttr(kContentLengthSign, docid, -1);
}

inline int32 NewsIndex::GetParagraphNumByDocId(int32 docid) const {
  return index_->GetIntAttr(kParagraphNumSign, docid, -1);
}

inline bool NewsIndex::GetNovelIdByDocId(int32 docid, std::string* novel_id) const {
  *novel_id = index_->GetStringAttr(kNovelIdSign, docid, "");
  return !novel_id->empty();
}

inline bool NewsIndex::GetNovelIdByItemId(uint64 item_id, std::string* novel_id) const {
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  return GetNovelIdByDocId(doc_id, novel_id);
}

inline int64 NewsIndex::GetNovelUpdateTimestampByDocId(int32 docid) const {
  return index_->GetIntAttr(kNovelUpdateTimeSign, docid, 0);
}

inline int64 NewsIndex::GetNovelUpdateTimestampByItemId(uint64 item_id) const {
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return 0;
  }
  return index_->GetIntAttr(kNovelUpdateTimeSign, doc_id, 0);
}

inline int32 NewsIndex::GetVideoCountByDocId(int32 docid) const {
  return index_->GetIntAttr(kVideoCountSign, docid, 0);
}

inline int32 NewsIndex::GetVideoCountByItemId(uint64 item_id) const {
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return 0;
  }
  return index_->GetIntAttr(kVideoCountSign, doc_id, 0);
}

inline int32 NewsIndex::GetJingpinScoreByDocId(int32 docid) const {
  return index_->GetIntAttr(kJingpinScoreSign, docid, -1);
}

inline bool NewsIndex::IsYuanchuangDocId(int32 docid) const {
  return index_->GetIntAttr(kItemIsYuanchuangSign, docid, 0);
}

inline bool NewsIndex::IsYuanchuangItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;
  return IsYuanchuangDocId(doc_id);
}

inline bool NewsIndex::HasVideoStorageInfoByDocId(int32 docid) const {
  return index_->GetIntAttr(kHasVideoStorageInfoSign, docid, 0);
}

inline bool NewsIndex::HasVideoStorageInfoByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;
  return HasVideoStorageInfoByDocId(doc_id);
}

inline int NewsIndex::GetVideoStorageInfoStatusByDocId(int32 docid) const {
  return index_->GetIntAttr(kVideoStorageInfoStatusSign, docid, -1);
}

inline int NewsIndex::GetVideoStorageInfoStatusByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return -1;
  return GetVideoStorageInfoStatusByDocId(doc_id);
}

inline bool NewsIndex::GetItemIdByYoukuVideoId(uint64 youku_video_id, uint64 *item_id) const {
  return sort_item_->GetItemIdByYoukuVideoId(youku_video_id, item_id);
}

inline bool NewsIndex::GetYoukuVideoIdByDocId(int32 docid, uint64* youku_video_id) const {
  std::string value = index_->GetStringAttr(kYoukuVideoIdSign, docid, "");
  if (value.empty()) return false;
  return base::StringToUint64(value, youku_video_id);
}

inline bool NewsIndex::GetYoukuVideoIdByItemId(uint64 item_id, uint64* youku_video_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;
  return GetYoukuVideoIdByDocId(doc_id, youku_video_id);
}

inline float NewsIndex::GetVideoBlackEdgeRatioByDocId(int32 docid) const {
  return index_->GetFloatAttr(kVideoBlackEdgeRatioSign, docid, 0.0);
}

inline float NewsIndex::GetVideoBlackEdgeRatioByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return 0.0;
  return GetVideoBlackEdgeRatioByDocId(doc_id);
}

inline int32 NewsIndex::GetVideoWidthByDocId(int32 doc_id) const {
  return index_->GetIntAttr(kVideoWidthSign, doc_id, 0);
}

inline int32 NewsIndex::GetVideoWidthByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return 0;
  return GetVideoWidthByDocId(doc_id);
}

inline int32 NewsIndex::GetVideoHeightByDocId(int32 doc_id) const {
  return index_->GetIntAttr(kVideoHeightSign, doc_id, 0);
}

inline int32 NewsIndex::GetVideoHeightByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return 0;
  return GetVideoHeightByDocId(doc_id);
}

inline int32 NewsIndex::GetVideoColorsByDocId(int32 doc_id) const {
  return index_->GetIntAttr(kVideoColorsSign, doc_id, 0);
}

inline int32 NewsIndex::GetVideoColorsByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return 0;
  return GetVideoColorsByDocId(doc_id);
}

inline bool NewsIndex::IsVideoLargeCardDocId(int32 docid) const {
  std::set<std::string> problems;
  return (GetVideoWidthByDocId(docid) >= 448
          && GetVideoHeightByDocId(docid) >= 252
          && GetVideoColorsByDocId(docid) >= 8
          && GetVideoBlackEdgeRatioByDocId(docid) < 0.18
          && GetVideoWidthByDocId(docid) > GetVideoHeightByDocId(docid)
          && (!GetVideoPosterProblemInfoByDocId(docid, &problems)));
}

inline bool NewsIndex::IsVideoLargeCardItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;
  return IsVideoLargeCardDocId(doc_id);
}

inline float NewsIndex::GetVideoPosterClarityByDocId(int32 docid) const {
  return index_->GetFloatAttr(kVideoPosterClaritySign, docid, 0.0);
}

inline float NewsIndex::GetVideoPosterClarityItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return 0.0;
  return GetVideoPosterClarityByDocId(doc_id);
}

inline bool NewsIndex::GetVideoPosterProblemInfoByDocId(int32 docid, std::set<std::string> *problems) const {
  std::string value = index_->GetStringAttr(kVideoPosterProblemInfoSign, docid, "");
  if (value.empty()) return false;
  problems->clear();
  std::vector<std::string> tokens;
  base::SplitString(value, ",", &tokens);
  for (size_t i = 0; i < tokens.size(); ++i) {
    problems->insert(tokens[i]);
  }
  return !problems->empty();
}

inline bool NewsIndex::GetVideoPosterProblemInfoByItemId(uint64 item_id,
                                                         std::set<std::string> *problems) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;
  return GetVideoPosterProblemInfoByDocId(doc_id, problems);
}

inline bool NewsIndex::GetVideoPlayControlByDocId(int32 docid,
                                                  reco::VideoPlayControl *video_play_control) const {
  std::string value = index_->GetStringAttr(kVideoPlayControlSign, docid, "");
  if (value.empty()) return false;
  if (!video_play_control->ParseFromString(value)) return false;
  return true;
}
inline bool NewsIndex::GetVideoPlayControlByItemId(uint64 item_id,
                                                   reco::VideoPlayControl *video_play_control) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;
  return GetVideoPlayControlByDocId(doc_id, video_play_control);
}

inline int32 NewsIndex::GetImageCountByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return 0;

  return index_->GetIntAttr(kImageCountSign, doc_id, 0);
}

inline bool NewsIndex::GetMetaInfo(uint64 item_id, ItemInfo *item) const {
  return meta_info_updator_->GetMetaInfo(item_id, item);
}

inline const std::set<uint64>* NewsIndex::GetSimItemIds(uint64 item_id) const {
  return sim_item_->GetSimItemIds(item_id);
}
/*
inline bool NewsIndex::GetSimItemIds(uint64 item_id, std::vector<uint64>* sim_ids) const {
  return sim_item_->GetSimItemIds(item_id, sim_ids);
}
*/
inline bool NewsIndex::HasCheckedBySimServer(uint64 item_id) const {
  return sim_item_->HasCheckedBySimServer(item_id);
}

inline bool NewsIndex::GetImageByDocId(int32 doc_id, std::vector<uint64>* image) const {
  std::string str = index_->GetStringAttr(kImageHashSign, doc_id, "");
  if (str.empty()) return false;

  std::vector<std::string> tokens;
  base::SplitString(str, ",", &tokens);

  image->reserve(tokens.size());
  int64 hash = 0;
  for (int i = 0; i < (int)tokens.size(); ++i) {
    if (!base::StringToInt64(tokens[i], &hash)) continue;
    if (hash == 0) continue;
    image->push_back(hash);
  }
  return true;
}

inline bool NewsIndex::GetParagraphByDocId(int32 doc_id, std::vector<uint64>* paragraph) const {
  std::string str = index_->GetStringAttr(kParagraphHashSign, doc_id, "");
  if (str.empty()) return false;

  std::vector<std::string> tokens;
  base::SplitString(str, ",", &tokens);

  paragraph->reserve(tokens.size());
  int64 hash = 0;
  for (int i = 0; i < (int)tokens.size(); ++i) {
    if (!base::StringToInt64(tokens[i], &hash)) continue;
    if (hash == 0) continue;
    paragraph->push_back(static_cast<uint64>(hash));
  }
  return true;
}

inline uint64 NewsIndex::GetWholeContentHashByDocId(int32 doc_id) const {
  const std::string&str = index_->GetStringAttr(kWholeContentHashKeySign, doc_id, "0");
  int64 content_hash;
  if (!base::StringToInt64(str, &content_hash)) {
    return 0;
  }
  return content_hash;
}

inline uint64 NewsIndex::GetParentId(uint64 item_id) const {
  return sim_item_->GetParent(item_id);
}

inline bool NewsIndex::GetContentAttrByDocId(int32 doc_id, ContentAttr* content_attr, bool* is_trival) const {
  CHECK_NOTNULL(content_attr);
  int64 attr = index_->GetIntAttr(kContentAttrSign, doc_id, 0);
  reco::common::UnPackContentAttr(attr, content_attr);
  *is_trival = (attr == 0);
  return true;
}

inline bool NewsIndex::GetContentAttrByItemId(uint64 item_id, ContentAttr* content_attr,
                                              bool* is_trival) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return false;
  return GetContentAttrByDocId(docid, content_attr, is_trival);
}

inline bool NewsIndex::GetGaoDePOIByItemId(uint64 item_id, GaoDePOI* gaode_poi) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return false;
  return GetGaoDePOIByDocId(docid, gaode_poi);
}

inline bool NewsIndex::GetGaoDePOIByDocId(int32 docid, GaoDePOI* gaode_poi) const {
  CHECK_NOTNULL(gaode_poi);
  std::string attr = index_->GetStringAttr(kGaoDePOISign, docid, "");
  if (attr.empty()) return false;
  if (!gaode_poi->ParseFromString(attr)) return false;
  return true;
}

inline bool NewsIndex::GetTimeAxisResultsByDocId(int32 doc_id,
                                                 time_axis::TimeAxisResults *time_axis_results) const {
  CHECK_NOTNULL(time_axis_results);
  std::string attr = index_->GetStringAttr(kTimeAxisResultsSign, doc_id, "");
  if (attr.empty()) return false;
  if (!time_axis_results->ParseFromString(attr)) return false;
  return true;
}

inline bool NewsIndex::GetFilterChainByItemId(uint64 item_id,
                                              RuleChain* filter_chain) const {
  std::string source;
  if (!GetSourceByItemId(item_id, &source)) {
    return false;
  }
  if (!source_manager_->GetSourceRuleChain(source, filter_chain)) {
    return false;
  }
  return true;
}

inline bool NewsIndex::GetItemTimeAxisInfoByItemId(uint64 item_id,
                                                   time_axis::TimeAxisInfo *timeaxis_info) const {
  return sort_item_->GetItemTimeAxisInfoByItemId(item_id, timeaxis_info);
}

inline bool NewsIndex::GetLatestNewsByEventName(const std::string& event_name, uint64* latest_item_id,
        time_axis::TimeAxisInfo* timeaxis_info) const {
  return sort_item_->GetLatestNewsByEventName(event_name, latest_item_id, timeaxis_info);
}

inline bool NewsIndex::GetVideoStatInfoByItemId(uint64 item_id, VideoStatInfo* info) const {
  if (meta_info_updator_ == NULL) {
    return false;
  }
  return meta_info_updator_->GetVideoStatInfo(item_id, info);
}

/*
inline bool NewsIndex::GetOriginInfoByItemId(uint64 item_id, uint64* origin_item_id) const {
  if (origin_info_updator_ == NULL) {
    return false;
  }
  return origin_info_updator_->GetOriginInfo(item_id, origin_item_id);
}

inline bool NewsIndex::GetYCInfoByItemId(uint64 item_id, uint64* yc_item_id) const {
  if (origin_info_updator_ == NULL) {
    return false;
  }
  return origin_info_updator_->GetYCInfo(item_id, yc_item_id);
}
*/

inline bool NewsIndex::GetItemQualityAttrByItemId(uint64 item_id, ItemQualityAttr* quality_attr) const {
  CHECK_NOTNULL(quality_attr);
  if (item_quality_expiry_map_->FindSilently(item_id, quality_attr)) {
    return true;
  }

  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;

  std::string attr = index_->GetStringAttr(kItemQualityAttrSign, doc_id, "");
  if (attr.empty()) return false;
  if (!quality_attr->ParseFromString(attr)) return false;

  item_quality_expiry_map_->Add(item_id, *quality_attr);
  return true;
}

inline bool NewsIndex::GetTitleCoreTagsByItemId(uint64 item_id, std::vector<std::string>* core_tags) const {
  core_tags->clear();
  if (item_title_core_tags_expiry_map_->FindSilently(item_id, core_tags)) {
    return !core_tags->empty();
  }

  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;

  // 下面开始不能提前 return
  std::vector<std::string> show_tags;
  if (GetShowTagByDocId(doc_id, &show_tags) && !show_tags.empty()) {
    std::string title;
    if (GetItemTitleByDocId(doc_id, &title)) {
      for (size_t i = 0; i < show_tags.size(); ++i) {
        if (title.find(show_tags[i]) != std::string::npos) {
          // show tags 已经按照重要性排序了
          core_tags->push_back(show_tags[i]);
        }
      }
    }
  }

  // core_tag 为空也必须缓存
  item_title_core_tags_expiry_map_->Add(item_id, *core_tags);
  return !core_tags->empty();
}

inline int32 NewsIndex::GetOrgiItemQByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return 0;
  int32 orgi_itemq;
  if (!GetOrgiItemQByItemId(item_id, &orgi_itemq)) return 0;
  return orgi_itemq;
}

inline  bool NewsIndex::GetOrgiItemQByItemId(uint64 item_id, int32* orgi_itemq) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;
  int32 itemq_t = index_->GetIntAttr(kPosteriorItemQSign, doc_id, -1);
  if (itemq_t >= 0) {
    *orgi_itemq = itemq_t;
    return true;
  }
  return false;
}

inline bool NewsIndex::GetWemediaMeta(const std::string& source,
                                      IndexDictManager::WemediaMeta* meta) const {
  auto newbee_dict = dict_manager_->GetWemediaMetaMap()->find(source);
  if (newbee_dict == dict_manager_->GetWemediaMetaMap()->end())
    return false;
  (*meta) = newbee_dict->second;
  return true;
}

inline int32 NewsIndex::GetCateMediaLevelNum(const std::string& cate_level) const {
  const base::dense_hash_map<std::string, int32>* media_level_dict = dict_manager_->GetCateMediaLevelNumMap();
  auto iter = media_level_dict->find(cate_level);
  if (iter == media_level_dict->end()) return 0;
  return iter->second;
}

inline bool NewsIndex::GetYoukuAuditStatusByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;
  std::string andit_status = index_->GetStringAttr(kYoukuAuditStatusSign , doc_id, "");
  if (andit_status == "allowed")
    return true;
  return false;
}

inline bool NewsIndex::GetSubjectSubItemByItemId(uint64 item_id,
                                                 reco::SubjectSubItems* subject_sub_items) const {
  CHECK_NOTNULL(subject_sub_items);

  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;

  std::string attr = index_->GetStringAttr(kSubjectItemsSign, doc_id, "");
  if (attr.empty()) {
    return false;
  }
  if (!subject_sub_items->ParseFromString(attr)) {
    return false;
  }

  return true;
}

inline bool NewsIndex::GetSubjectSubItemIds(uint64 item_id, std::vector<uint64>* subject_sub_itemids) const {
  reco::SubjectSubItems sub_items;
  if (!GetSubjectSubItemByItemId(item_id, &sub_items)) {
    return false;
  }

  subject_sub_itemids->clear();
  for (int j = 0; j < sub_items.sub_items_size(); ++j) {
    const SubjectSubItem& item = sub_items.sub_items(j);
    subject_sub_itemids->push_back(item.item_id());
  }
  return true;
}

inline bool NewsIndex::GetSubjectIdByItemId(uint64 item_id, uint64* subject_id) const {
  return sort_item_->GetSubjectIdByItemId(item_id, subject_id);
}

inline const reco::FeatureVector* NewsIndex::GetSubjectVideoTagFeatureByItemId(uint64 item_id) const {
  return sort_item_->GetSubjectVideoTagFeatureByItemId(item_id);
}

inline bool NewsIndex::GetLocalBreakingByItemId(uint64 item_id, reco::LocalBreaking* local_breaking) const {
  int32 docid = index_->DocLocalIDFromKeySign(item_id);
  if (docid == -1) return false;
  return GetLocalBreakingByDocId(docid, local_breaking);
}

inline bool NewsIndex::GetLocalBreakingByDocId(int32 docid, reco::LocalBreaking* local_breaking) const {
  CHECK_NOTNULL(local_breaking);
  std::string attr = index_->GetStringAttr(kLocalBreakingSign, docid, "");
  if (attr.empty()) return false;
  if (!local_breaking->ParseFromString(attr)) return false;
  return true;
}

inline bool NewsIndex::ContainLocalBreakingByItemId(uint64 item_id) const {
  auto const item_breaking_dict = sort_item_->GetItemBreakingDict();
  return item_breaking_dict->find(item_id) != item_breaking_dict->end();
}

inline int32 NewsIndex::GetAppTokenBitsByDocId(int32 doc_id) const {
  return index_->GetIntAttr(kAppTokenBitsSign, doc_id, -1);
}

inline int32 NewsIndex::GetAppTokenBitsByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  if (!GetDocIdByItemId(item_id, &doc_id)) return -1;
  return GetAppTokenBitsByDocId(doc_id);
}

inline bool NewsIndex::GetAppTokenRuleBitsByDocId(int32 doc_id, std::string *rule_bits) const {
  rule_bits->clear();
  *rule_bits = index_->GetStringAttr(kAppTokenRuleBitsSign, doc_id, "");
  if (rule_bits->empty()) return false;
  return true;
}

inline bool NewsIndex::GetAppTokenRuleBitsByItemId(uint64 item_id, std::string* rule_bits) const {
  int32 doc_id = 0;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  return GetAppTokenRuleBitsByDocId(doc_id, rule_bits);
}

inline int32 NewsIndex::GetFirstNScreenFilterByDocId(int32 doc_id) const {
  return index_->GetIntAttr(kFirstNScreenFilterSign, doc_id, -1);
}

inline int32 NewsIndex::GetFirstNScreenFilterByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  if (!GetDocIdByItemId(item_id, &doc_id)) return -1;
  return GetFirstNScreenFilterByDocId(doc_id);
}

inline int64 NewsIndex::GetSourcePublishPlatformByDocId(uint64 doc_id) const {
  return index_->GetIntAttr(kSourcePublishPlatformSign, doc_id, 0);
}

inline int64 NewsIndex::GetSourcePublishPlatformByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  if (!GetDocIdByItemId(item_id, &doc_id)) return 0;
  return GetSourcePublishPlatformByDocId(doc_id);
}

inline int32 NewsIndex::GetItemResolutionByDocId(uint64 doc_id) const {
  return index_->GetIntAttr(kVideoResolutionSign, doc_id, reco::kNoResolution);
}

inline int32 NewsIndex::GetItemResolutionByItemId(uint64 item_id) const {
  int32 doc_id = 0;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return reco::kNoResolution;
  }
  return GetItemResolutionByDocId(doc_id);
}

inline bool NewsIndex::GetItemContentPoolIdsByItemId(const uint64& item_id,
                                                     std::vector<int>* content_pool_ids) const {
  content_pool_ids->clear();
  // 运营划分物料等级
  ItemAttachDataExt item_attach_data_ext;
  if (GetItemAttachDataExtByItemId(item_id, &item_attach_data_ext)) {
    content_pool_ids->push_back(item_attach_data_ext.level);
  }
  // 其他物料等级
  // 自定义的或者非运营需求的物料划分方式
  // todo
  return content_pool_ids->size() > 0;
}

inline bool NewsIndex::GetItemContentPoolIdsByItemId(const uint64& item_id,
                                                     std::string* content_pool_ids) const {
  content_pool_ids->clear();
  std::vector<int> pool_ids;
  if (!GetItemContentPoolIdsByItemId(item_id, &pool_ids)) return false;
  for(size_t i = 0; i < pool_ids.size(); i++) {
    if (i == 0) {
      content_pool_ids->append(base::IntToString(pool_ids[i]));
    } else {
      content_pool_ids->append("|" + base::IntToString(pool_ids[i]));
    }
  }
  return !content_pool_ids->empty();
}

inline bool NewsIndex::GetItemAttachDataExtByItemId(const uint64& item_id,
                                                    ItemAttachDataExt* item_attach_data_ext) const {
  CHECK_NOTNULL(item_attach_data_ext);
  if (item_attach_data_ext_expiry_map_->FindSilently(item_id, item_attach_data_ext)) {
    return true;
  }

  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;

  std::string attr = index_->GetStringAttr(kItemAttachDataExtSign, doc_id, "");
  if (attr.empty()) return false;
  if (!ParseItemAttachDataExt(item_id, attr, item_attach_data_ext)) return false;

  item_attach_data_ext_expiry_map_->Add(item_id, *item_attach_data_ext);
  return true;
}

inline bool NewsIndex::ParseItemAttachDataExt(const uint64& item_id,
                                    const std::string& item_attach_data_ext_attr,
                                    ItemAttachDataExt* item_attach_data_ext) const {
  VLOG(1) << item_id << " has item_attach_data_ext : " << item_attach_data_ext_attr;
  json_error_t json_error;
  json_t *json = json_loads(item_attach_data_ext_attr.c_str(), &json_error);
  if (json == NULL) {
    LOG(WARNING) << item_id << " get item_attach_data_ext Failed!: " << json_error.line
                 << ", error: " << json_error.text << ", item_attach_data_ext: " << item_attach_data_ext_attr;
    json_decref(json);
    return false;
  }
  json_t* level_json = json_object_get(json, "level");
  if (!json_is_integer(level_json)) {
    json_type type = level_json == NULL ? JSON_NULL : json_typeof(level_json);
    LOG(WARNING) << item_id << " item_attach_data_ext level_json type is not int:" << type;
    json_decref(json);
    return false;
  }
  item_attach_data_ext->level = json_integer_value(level_json);
  json_decref(json);
  return true;
}
}  // namespace reco
