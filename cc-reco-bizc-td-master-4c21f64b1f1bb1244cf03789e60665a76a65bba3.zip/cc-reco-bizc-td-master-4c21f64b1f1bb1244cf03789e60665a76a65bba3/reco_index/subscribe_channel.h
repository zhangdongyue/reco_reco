#pragma once
#include <unordered_map>
#include <vector>
#include <string>
#include <unordered_set>

#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/reco_index/item_info.h"
#include "base/thread/sync.h"
#include "base/thread/thread.h"
#include "base/thread/thread_pool.h"
#include "base/testing/gtest.h"
#include "base/file/file_path.h"

namespace reco {
class NewsIndex;
// 每个频道，可以设置若干默认订阅词，
// 索引更新时，除了根据 channelid 绑定频道，还可以通过此类提供的订阅接口绑定
class SubscribeChannel {
 public:
  explicit SubscribeChannel(const NewsIndex* news_index);
  ~SubscribeChannel() {}

  // 更新内部维护的频道订阅结果
  void UpdateSubscribeResult();

  // 返回 doc id 可以进入哪些订阅词频道
  bool GetSubsChannelIds(int32 doc_id, std::unordered_set<int64> *channel_ids);

  void Clear() {
    channel_docs_.clear();
  }

 private:
  static const int64 kSubscribeChannelIds[];

  void InitChannelWords() {
    // 目前量少，只要 hard code
    channel_words_[27254244].push_back("欧洲杯");
    channel_words_[23154031].push_back("奥运");
    channel_words_[23154031].push_back("奥运会");
    // 王宝强频道
    channel_words_[1404457531636].push_back("王宝强");
    channel_words_[1404457531636].push_back("马蓉");
    channel_words_[1404457531636].push_back("宋喆");
  }

  bool IsSubscribed(int64 channel_id, int32 doc_id) {
    auto it = channel_docs_.find(channel_id);
    if (it == channel_docs_.end()) {
      return false;
    }
    if (it->second.find(doc_id) == it->second.end()) {
      return false;
    } else {
      return true;
    }
  }

  std::unordered_map<int64, std::unordered_set<int32> > channel_docs_;
  const NewsIndex* news_index_;
  std::unordered_map<int64, std::vector<std::string> > channel_words_;
};
}
