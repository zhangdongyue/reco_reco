#include "reco/bizc/reco_index/multi_category_cache.h"

#include <vector>
#include "serving_base/expiry_map/expiry_map.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {

serving_base::ExpiryMap<uint64, float>* MultiCategoryCache::category_score_ =
    new serving_base::ExpiryMap<uint64, float>(3600 * 4);

serving_base::ExpiryMap<uint64, int>* MultiCategoryCache::item_dict_ =
    new serving_base::ExpiryMap<uint64, int>(3600 * 4);

MultiCategoryCache::MultiCategoryCache() {}

MultiCategoryCache::~MultiCategoryCache() {}

void MultiCategoryCache::Add(uint64 item_id, const MultiCategory& multi_category) {
  item_dict_->IfNotFoundThenAdd(item_id, 0);
  for (int i = 0; i < multi_category.category_candidates_size(); ++i) {
    Add(item_id, multi_category.category_candidates(i));
  }
}

void MultiCategoryCache::Add(uint64 item_id, const ItemCategory& item_category) {
  item_dict_->IfNotFoundThenAdd(item_id, 0);
  uint64 sign = generate_sign(item_id, item_category.level1());
  category_score_->Add(sign, item_category.level1_score());
  for (int j = 0; j < item_category.level2_size(); ++j) {
    uint64 sign = generate_sign(item_id, item_category.level2(j));
    category_score_->Add(sign, item_category.level2_score(j));
  }
}
}
