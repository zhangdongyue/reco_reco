#include <algorithm>
#include <fstream>
#include "reco/bizc/reco_index/dynamic_dict_container.h"
#include "reco/bizc/reco_index/channel_itemtype_dict.h"
#include "reco/bizc/reco_index/media_quantity_assurance.h"
#include "third_party/yaml-cpp/include/yaml-cpp/yaml.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/encoding/line_escape.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/memory_mapped_file.h"
#include "nlp/common/nlp_util.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"

namespace reco {

DEFINE_int64(server_request_num_per_day, 600000000L, "服务器每天的刷新量");
DEFINE_double(text_guarantee_deliver_ratio_max, 0.35, "保量最大比例");
DEFINE_double(text_guarantee_deliver_ratio, 0.1, "文本保量下发比例");
DECLARE_string(target_server);

namespace dm {

#define DM_LOAD_DICT(var) reco::dm::DictManagerSingleton::instance().ReloadByDictName(#var)
const char* kDeletedSuffix = "_DELETE";

void LoadUgcExpoRatioNeededDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<UgcExpoRatioNeededDict>* dynamic_dict =
    reinterpret_cast<DynamicDict<UgcExpoRatioNeededDict>* >(dict_address);
  // 新 dict
  boost::shared_ptr<UgcExpoRatioNeededDict> p_new_dict(new UgcExpoRatioNeededDict());
  auto & new_dict = *p_new_dict;

  int64 count = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }

    base::TrimWhitespaces(&lines[i]);
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() < 3) continue;
    int32 pool_id = 0;
    if (!tokens[0].empty() &&  tokens[0] != "NULL" && !base::StringToInt(tokens[0], &pool_id)) {
      LOG(ERROR) << path.value() << " pool id " << lines[i];
      continue;
    }
    ExpoRatioNeeded expo_ratio_needed;
    if (!tokens[1].empty() &&  tokens[1] != "NULL"
        && !base::StringToDouble(tokens[1], &expo_ratio_needed.min)) {
      LOG(ERROR) << path.value() << " min ratio " << lines[i];
      continue;
    }
    if (!tokens[2].empty() &&  tokens[2] != "NULL"
        && !base::StringToDouble(tokens[2], &expo_ratio_needed.max)) {
      LOG(ERROR) << path.value() << " max ratio " << lines[i];
      continue;
    }
    new_dict[pool_id] = expo_ratio_needed;
    ++count;
  }
  LOG(INFO) << "insert " << count <<  " items into ugc_expo_ratio_needed_dict";

  // swap dict
  dynamic_dict->Swap(p_new_dict);
  *suc = true;
  *cnt = count;
}

void LoadUgcItemScoreDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<UgcItemScoreDict>* dynamic_dict =
      reinterpret_cast<DynamicDict<UgcItemScoreDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<UgcItemScoreDict> new_dict(new UgcItemScoreDict());

  // 处理逻辑
  int64 count = 0;
  auto& ugc_item_score = new_dict->ugc_item_score_;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() != 2u || tokens[0].empty()) {
      LOG(ERROR) << "invalid ugc item score input line: " << lines[i]
                 << ", size=" << tokens.size();
      continue;
    }

    uint64 item_id = 0;
    if (!base::StringToUint64(tokens[0], &item_id)) {
      VLOG(1) << base::StringPrintf("item_id:%lu convert error", item_id);
      continue;
    }

    std::vector<std::string> channel_scores_vec;
    base::SplitString(tokens[1], " ", &channel_scores_vec);
    std::unordered_map<int64, double> channel_score;
    for (auto it = channel_scores_vec.begin(); it != channel_scores_vec.end(); ++it) {
      std::vector<std::string> vec;
      int64 channel_id;
      double score;
      base::SplitString(*it, ":", &vec);
      if (vec.size() != 2u ||
          !base::StringToInt64(vec[0], &channel_id) ||
          !base::StringToDouble(vec[1], &score)) {
        VLOG(1) << "channel or score convert error:" << *it;
        continue;
      }
      if (channel_score.find(channel_id) == channel_score.end()) {
        channel_score.insert(std::make_pair(channel_id, score));
      }
    }
    if (channel_score.size() == 0u) {
      continue;
    }

    if (ugc_item_score.find(item_id) == ugc_item_score.end()) {
      ugc_item_score.insert(std::make_pair(item_id, channel_score));
      VLOG(1) << "insert item_id:" << item_id << "->" << channel_score.size();
    }
    ++count;
  }
  LOG(INFO) << "insert " << ugc_item_score.size() << " items into ugc_item_score";
  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

void LoadChannelItemtypeDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<ChannelItemtypeDict>* dynamic_dict =
      reinterpret_cast<DynamicDict<ChannelItemtypeDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<ChannelItemtypeDict> new_dict(new ChannelItemtypeDict());

  // 处理逻辑
  auto& white_itemtype_channel = new_dict->white_itemtype_channel_map_;
  auto& black_itemtype_channel = new_dict->black_itemtype_channel_map_;

  int64 count = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }

    std::vector<std::string> tokens;
    base::SplitString(lines[i], ":", &tokens);
    if (tokens.size() != 3) {
      continue;
    }

    std::vector<std::string> sub_tokens;
    base::SplitString(tokens[2], ",", &sub_tokens);

    int64 channelid = 0;
    if (!base::StringToInt64(tokens[0], &channelid)) {
      LOG(ERROR) << path.value() << " channelid field error: " << lines[i];
      continue;
    }
    ++count;

    bool is_white = tokens[1] == "white";
    for (size_t j = 0; j < sub_tokens.size(); ++j) {
      unsigned itemtype = 0;
      if (!base::StringToUint(sub_tokens[j], &itemtype)) {
        LOG(ERROR) << path.value() << " itemtype field error: " << lines[i];
        continue;
      }
      is_white ? white_itemtype_channel[channelid].push_back(itemtype) :
         black_itemtype_channel[channelid].push_back(itemtype);
    }
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

void LoadChannelItemRuleGalleryDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  std::ifstream fin(path.value().c_str());
  YAML::Parser parser(fin);
  YAML::Node doc;
  try {
    parser.GetNextDocument(doc);
  } catch(YAML::ParserException & e) {
    LOG(WARNING) << "Yaml file " << path.value() << " load failed: " << e.what();
    *suc = false;
    return;
  }

  if (doc.Type() != YAML::NodeType::Sequence) {
    LOG(WARNING) << "Yaml node format error: not Sequence";
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<ChannelItemRuleGalleryDict>* dynamic_dict =
      reinterpret_cast<DynamicDict<ChannelItemRuleGalleryDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<ChannelItemRuleGalleryDict> new_dict(new ChannelItemRuleGalleryDict());

  // 处理逻辑
  for (auto i = 0u; i < doc.size(); i++) {
    try {
      RuleType rule_type;
      int64 rule_id;
      if (!reco::ChannelItemtypeDict::ParseRuleTypeFromYAML(doc[i], &rule_type, &rule_id)) {
        continue;
      }
      ChannelRule channel_rule;
      FilterRule filter_rule;
      switch (rule_type) {
        case reco::kLeafChannelRule:
          channel_rule.channel_id = rule_id;
          if (reco::ChannelItemtypeDict::ParseRuleFromYAML(doc[i], &channel_rule,
              &new_dict->leaf_channel_engine.channel_rule_index_permit,
              &new_dict->leaf_channel_engine.channel_rule_index_forbid,
              &new_dict->leaf_channel_engine.manual_channels,
              &new_dict->leaf_channel_engine.channel_subordinates_map)) {
            if (new_dict->leaf_channel_engine.channel_rule_map.find(rule_id)
                != new_dict->leaf_channel_engine.channel_rule_map.end()) {
              LOG(WARNING) << "leaf channel rule conflict at:" << rule_id;
              continue;
            }
            new_dict->leaf_channel_engine.channel_rule_map[rule_id] = channel_rule;
            LOG(INFO) << "leaf channel loaded success at:" << rule_id;
            ++(*cnt);
          }
          break;
        case reco::kVideoChannelRule:
          channel_rule.channel_id = rule_id;
          if (reco::ChannelItemtypeDict::ParseRuleFromYAML(doc[i], &channel_rule,
              &new_dict->video_channel_engine.channel_rule_index_permit,
              &new_dict->video_channel_engine.channel_rule_index_forbid,
              &new_dict->video_channel_engine.manual_channels,
              &new_dict->video_channel_engine.channel_subordinates_map)) {
            if (new_dict->video_channel_engine.channel_rule_map.find(rule_id)
                != new_dict->video_channel_engine.channel_rule_map.end()) {
              LOG(WARNING) << "video channel rule conflict at:" << rule_id;
              continue;
            }
            new_dict->video_channel_engine.channel_rule_map[rule_id] = channel_rule;
            LOG(INFO) << "video channel loaded success at:" << rule_id;
            ++(*cnt);
          }
          break;
        case reco::kLeafExtendChannelRule:
          channel_rule.channel_id = rule_id;
          if (reco::ChannelItemtypeDict::ParseRuleFromYAML(doc[i], &channel_rule,
              &new_dict->leaf_extend_channel_engine.channel_rule_index_permit,
              &new_dict->leaf_extend_channel_engine.channel_rule_index_forbid,
              &new_dict->leaf_extend_channel_engine.manual_channels,
              &new_dict->leaf_extend_channel_engine.channel_subordinates_map)) {
            if (new_dict->leaf_extend_channel_engine.channel_rule_map.find(rule_id)
                != new_dict->leaf_extend_channel_engine.channel_rule_map.end()) {
              LOG(WARNING) << "leaf extend channel rule conflict at:" << rule_id;
              continue;
            }
            new_dict->leaf_extend_channel_engine.channel_rule_map[rule_id] = channel_rule;
            LOG(INFO) << "leaf extend channel loaded success at:" << rule_id;
            ++(*cnt);
          }
          break;
        case reco::kFilterRule:
          filter_rule.filter_id = rule_id;
          if (reco::ChannelItemtypeDict::ParseFilterFromYAML(doc[i], &filter_rule)) {
            new_dict->filter_rules.push_back(filter_rule);
            LOG(INFO) << "filter loaded success at:" << rule_id;
            ++(*cnt);
          }
          break;
        default:
          break;
      }
    } catch(YAML::ParserException & e) {
      LOG(WARNING) << "Yaml Parsing failed: " << e.what();
    }
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
}

void LoadMediaQuantityInfoDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  std::ifstream fin(path.value().c_str());
  YAML::Parser parser(fin);
  YAML::Node doc;
  try {
    parser.GetNextDocument(doc);
  } catch(YAML::ParserException & e) {
    LOG(WARNING) << "Yaml file " << path.value() << " load failed: " << e.what();
    *suc = false;
    return;
  }

  if (doc.Type() != YAML::NodeType::Sequence) {
    LOG(WARNING) << "Yaml node format error: not Sequence";
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<MediaQuantityInfoDict>* dynamic_dict =
    reinterpret_cast<DynamicDict<MediaQuantityInfoDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<MediaQuantityInfoDict> p_new_dict(new MediaQuantityInfoDict());
  auto & new_dict = *p_new_dict;

  int64 count = 0;
  int64 quantity = 0L;
  // 处理逻辑
  for (auto i = 0u; i < doc.size(); i++) {
    try {
      MediaQuantityInfo media_quantity_info;
      if (reco::MediaQuantityInfoDict::ParseFromYAML(doc[i], &media_quantity_info)) {
        if (new_dict.find(media_quantity_info.source_sign) == new_dict.end()) {
          new_dict.insert(std::make_pair<uint64, std::unordered_map<int64, MediaQuantityInfo> >(
                            media_quantity_info.source_sign, {}));
        }
        new_dict[media_quantity_info.source_sign][media_quantity_info.protect_type] = media_quantity_info;
        if (media_quantity_info.protect_type == reco::dm::kMediaDocManual
            || media_quantity_info.protect_type == reco::dm::kMediaDocBeginner) {
          quantity += media_quantity_info.protect_capacity;
        }
        ++count;
      }
    } catch(YAML::ParserException & e) {
      LOG(WARNING) << "Yaml Parsing failed: " << e.what();
    }
  }

  // swap dict
  dynamic_dict->Swap(p_new_dict);
  *suc = true;
  *cnt = count;
  FLAGS_text_guarantee_deliver_ratio = std::min(FLAGS_text_guarantee_deliver_ratio_max,
                                                quantity * 1.0 / FLAGS_server_request_num_per_day);
  LOG(INFO) << "suc load media_quantity file. media conf num" << count
            << ", text quantity: " << quantity
            << ", text gd percent: " << FLAGS_text_guarantee_deliver_ratio;
}

}  // namespace dm

const char* DynamicDictContainer::kChannelItemRuleFile_   = "channel_itemrule.yml";
const char* DynamicDictContainer::kMediaQuantityInfoFile_ = "media_quantity_rule.yaml";
const char* DynamicDictContainer::kUgcExpoRatioNeededFile_ = "ugc_expo_ratio_needed.txt";
const char* DynamicDictContainer::kUgcItemScoreFile_ = "ugc_item_score.txt";

void DynamicDictContainer::RegisterAndLoadAllDict() {
  DM_REGISTER_CUSTOMER_DICT(reco::dm::ChannelItemRuleGalleryDict,
                            reco::DynamicDictContainer::kChannelItemRuleFile_,
                            reco::dm::LoadChannelItemRuleGalleryDict);
  DM_LOAD_DICT(reco::DynamicDictContainer::kChannelItemRuleFile_);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::MediaQuantityInfoDict,
                            reco::DynamicDictContainer::kMediaQuantityInfoFile_,
                            reco::dm::LoadMediaQuantityInfoDict);
  DM_LOAD_DICT(reco::DynamicDictContainer::kMediaQuantityInfoFile_);

  if (FLAGS_target_server == "video_server") {

    DM_REGISTER_CUSTOMER_DICT(reco::dm::UgcExpoRatioNeededDict,
                              reco::DynamicDictContainer::kUgcExpoRatioNeededFile_,
                              reco::dm::LoadUgcExpoRatioNeededDict);
    DM_LOAD_DICT(reco::DynamicDictContainer::kUgcExpoRatioNeededFile_);


    DM_REGISTER_CUSTOMER_DICT(reco::dm::UgcItemScoreDict,
                              reco::DynamicDictContainer::kUgcItemScoreFile_,
                              reco::dm::LoadUgcItemScoreDict);
    DM_LOAD_DICT(reco::DynamicDictContainer::kUgcItemScoreFile_);

    DM_REGISTER_CUSTOMER_DICT(reco::filter::UgcWhiteSourceDict,
                              reco::filter::DynamicDictContainer::kUgcWhiteSourceFile,
                              reco::filter::LoadUgcWhiteSourceDict);
    DM_LOAD_DICT(reco::filter::DynamicDictContainer::kUgcWhiteSourceFile);
  }
}
}
