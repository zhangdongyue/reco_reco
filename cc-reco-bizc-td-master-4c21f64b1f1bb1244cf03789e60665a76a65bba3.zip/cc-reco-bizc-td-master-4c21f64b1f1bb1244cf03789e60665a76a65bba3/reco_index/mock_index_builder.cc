#include "reco/bizc/reco_index/mock_index_builder.h"

#include "reco/bizc/reco_index/news_index.h"
#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"

#include "base/file/file_util.h"
#include "base/encoding/line_escape.h"

#include "ads_index/api/public.h"
#include "ads_index/dynamic_index/dynamic_index.h"
#include "ads_index/mix_index/mix_index.h"
#include "ads_index/proto/index.pb.h"

namespace reco {

MockIndexBuilder::MockIndexBuilder() {
  cdoc_convertor_ = new ItemCDocConvertor();
}

MockIndexBuilder::~MockIndexBuilder() {
}

void MockIndexBuilder::AddDoc(int item_type, uint64 item_id, const std::string& title,
                              const std::string& category, const std::string& source,
                              const std::string& keyword) {
  reco::RecoItem item;
  item.mutable_identity()->set_app_token("app");
  item.mutable_identity()->set_item_id(item_id);
  item.mutable_identity()->set_outer_id("item1");
  item.mutable_identity()->set_type(reco::ItemType(item_type));

  item.set_is_valid(true);
  base::Time now = base::Time::Now();
  now.ToStringInSeconds(item.mutable_create_time());
  item.set_title(title);
  item.set_content("this is content");
  item.set_source(source);
  item.add_category(category);

  FeatureVector* feature_vector;
  Feature* fea;

  feature_vector = item.mutable_keyword();
  feature_vector->set_norm(2);
  fea = feature_vector->add_feature();
  fea->set_item_type(kNews);
  fea->set_literal(keyword);
  fea->set_weight(1);

  items_.push_back(item);
}

void MockIndexBuilder::BuildIndex(const std::string& index_dir,
                  const std::string& static_dict_filename) {
  adsindexing::DynamicIndexOptions options;
  options.unigram_num_bits = 10;
  options.bigram_num_bits = 10;
  options.doc_num_bits = 8;
  options.history_dir = index_dir;
  options.static_dict_filename = static_dict_filename;
  index_ = adsindexing::GenDynamicIndex(&options);

  std::vector<std::string> compressed_cdocs;
  for (auto it = items_.begin(); it != items_.end(); ++it) {
    const reco::RecoItem& reco_item = *it;
    adsindexing::IndexDocInfo cdoc;
    std::string compressed_cdoc;
    CHECK(cdoc_convertor_->ConvertToCDoc(reco_item, &cdoc) &&
          adsindexing::GetCompressionCDoc(cdoc, &compressed_cdoc));
    compressed_cdocs.push_back(compressed_cdoc);
  }
  CHECK(index_->AddCDocs(0, compressed_cdocs));
  index_->LogStatus();
  ::google::FlushLogFiles(::google::INFO);
  news_index_ = InitializeNewsIndex(index_);
  // news_index_->SortItemNew();
}

void MockIndexBuilder::AddItemOnline(const std::vector<reco::RecoItem>& items) {
  CHECK_NOTNULL(index_);
  CHECK_NOTNULL(cdoc_convertor_);

  std::vector<std::string> compressed_cdocs;
  for (auto it = items.begin(); it != items.end(); ++it) {
    const reco::RecoItem& reco_item = *it;
    adsindexing::IndexDocInfo cdoc;
    std::string compressed_cdoc;
    CHECK(cdoc_convertor_->ConvertToCDoc(reco_item, &cdoc) &&
          adsindexing::GetCompressionCDoc(cdoc, &compressed_cdoc));
    compressed_cdocs.push_back(compressed_cdoc);
  }
  CHECK(index_->AddCDocs(0, compressed_cdocs));
  index_->LogStatus();
  ::google::FlushLogFiles(::google::INFO);
}
}  // reco
