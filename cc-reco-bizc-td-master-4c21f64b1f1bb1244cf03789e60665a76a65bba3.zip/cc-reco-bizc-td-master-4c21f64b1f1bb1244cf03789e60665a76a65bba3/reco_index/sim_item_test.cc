#include <vector>
#include <string>
#include <fstream>
#include <set>
#include "boost/concept_check.hpp"

#include "base/testing/gtest.h"
#include "base/common/scoped_ptr.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/sim_item.h"
#include "reco/bizc/reco_index/meta_info_updator.h"

// #include "reco/serv/reco_leaf/strategy/click_reco.h"
#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"

#include "base/file/file_util.h"
#include "base/encoding/line_escape.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/bizc/reco_index/mock_index_builder.h"

#include "ads_index/api/public.h"
#include "ads_index/dynamic_index/dynamic_index.h"
#include "ads_index/mix_index/mix_index.h"
#include "ads_index/proto/index.pb.h"

DEFINE_string(test_sim_index_dir, "reco/bizc/reco_index/test_data", "");

namespace reco {
class SimItemTest: public testing::Test {
 public:
  virtual void SetUp() {
    using namespace reco;  // NOLINT
    FLAGS_update_sim_item_interval_second = -1;
    FLAGS_update_meta_interval_second = -1;
    now_ = base::Time::Now();
    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(1);
      item.mutable_identity()->set_outer_id("item1");
      item.mutable_identity()->set_type(reco::kNews);

      item.set_is_valid(true);
      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("this is title");
      item.set_content("this is content");
      item.set_source("sina");
      item.add_category("体育");
      item.add_category("nba");

      builder_.AddDoc(item);
    }
    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(2);
      item.mutable_identity()->set_outer_id("item2");
      item.mutable_identity()->set_type(reco::kNews);

      item.set_is_valid(true);
      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("this is title 2");
      item.set_content("this is content 2");
      item.set_source("sina");
      item.add_category("体育");
      item.add_category("cba");

      builder_.AddDoc(item);
    }
    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(3);
      item.mutable_identity()->set_outer_id("item3");
      item.mutable_identity()->set_type(reco::kNews);

      item.set_is_valid(true);
      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("this is title 3");
      item.set_content("this is content 3");
      item.set_source("sina");
      item.add_category("社会");

      builder_.AddDoc(item);
    }
    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(4);
      item.mutable_identity()->set_outer_id("item4");
      item.mutable_identity()->set_type(reco::kNews);

      item.set_is_valid(true);
      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("this is title 4");
      item.set_content("this is content 5");
      item.set_source("sina");
      item.add_category("社会");

      builder_.AddDoc(item);
    }

    builder_.BuildIndex(FLAGS_test_sim_index_dir,
                        "ads_index/api/data/static_dict.dat");
    news_index_ = builder_.GetNewsIndex();
    CHECK_NOTNULL(news_index_);
    LOG(INFO) << base::StringPrintf("init news index finished!");

    // build sim file
    std::vector<reco::index_data::SimData> sim_datas;
    sim_datas.push_back(reco::index_data::SimData());
    sim_datas.back().set_item_id(1lu);
    sim_datas.back().add_sim_ids(2lu);

    sim_datas.push_back(reco::index_data::SimData());
    sim_datas.back().set_item_id(2lu);

    sim_datas.push_back(reco::index_data::SimData());
    sim_datas.back().set_item_id(4lu);
    sim_datas.back().add_sim_ids(3lu);

    base::FilePath dir(FLAGS_test_sim_index_dir);
    std::ofstream fout(dir.Append(reco::SimItem::kSimItemFile).value(),
                       std::ofstream::out | std::ofstream::binary);
    int size = 0;
    char buffer[1024];
    for (size_t i = 0; i < sim_datas.size(); ++i) {
      size = sim_datas[i].ByteSize();
      CHECK(sim_datas[i].SerializeToArray(&buffer, size));
      fout.write(reinterpret_cast<const char*>(&size), sizeof(size));
      fout.write(buffer, size);
    }

    // redis connect
    reco::redis::FLAGS_redis_pool_ips = "100.81.1.68:6500,100.81.2.180:6500,100.81.4.141:6500";
    redis_ = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);
  }

  virtual void TearDown() {
  }

  virtual const reco::NewsIndex* GetNewsIndex() {
    return news_index_;
  }

  reco::redis::RedisCli* GetRedis() {
    return redis_;
  }

  const base::Time& GetNowTime() const {
    return now_;
  }

  reco::MockIndexBuilder* mutable_builder() {
    return &builder_;
  }
 private:
  const reco::NewsIndex* news_index_;
  base::Time now_;
  reco::MockIndexBuilder builder_;
  reco::redis::RedisCliPool *redis_pool_;
  reco::redis::RedisCli *redis_;
};

TEST_F(SimItemTest, LoadFromFile) {
  struct {
    uint64 item_id;
    std::string sim_ids;
  } cases[] = {
    {1, "2"},
    {4, "3"},
    {2, ""},
    {3, "-1"},
  };
  int n = ARRAYSIZE_UNSAFE(cases);
  // clear value in redis
  for (int i = 0; i < n; ++i) {
    std::string key = base::StringPrintf("SIM-%lu", cases[i].item_id);
    int status = GetRedis()->Exist(key);
    if (status == 0) {
      ASSERT_TRUE(GetRedis()->Del(key));
    }
  }

  const reco::NewsIndex* index = GetNewsIndex();
  reco::SimItem* sim_item = new reco::SimItem(index);
  ASSERT_TRUE(sim_item->LoadFromFile(base::FilePath(FLAGS_test_sim_index_dir)));

  std::vector<std::string> flds;
  std::set<uint64> id_set;
  for (int i = 0; i < n; ++i) {
    flds.clear();
    base::SplitString(cases[i].sim_ids, "\t", &flds);
    if (flds.size() == 1 && flds[0] == "-1") {
      const std::vector<uint64>* sims = sim_item->GetSimItemIds(cases[i].item_id);
      ASSERT_TRUE(sims == NULL) << cases[i].item_id << " " << sims->size();
      continue;
    }

    id_set.clear();
    for (size_t j = 0; j < flds.size(); ++j) {
      if (flds[j].empty()) continue;
      id_set.insert(base::ParseUint64OrDie(flds[j]));
    }

    const std::vector<uint64>* sims = sim_item->GetSimItemIds(cases[i].item_id);
    ASSERT_TRUE(sims != NULL);
    ASSERT_EQ(sims->size(), id_set.size()) << cases[i].item_id;
    for (size_t j = 0; j < sims->size(); ++j) {
      ASSERT_TRUE(id_set.find(sims->at(j)) != id_set.end());
    }
  }
}

TEST_F(SimItemTest, UpdateSimThread) {
  const reco::NewsIndex* index = GetNewsIndex();
  scoped_ptr<reco::SimItem> sim_item(new reco::SimItem(index));
  // write some sims ids in redis
  struct {
    uint64 item_id;
    std::string sim_ids_in_file;
    std::string sim_ids_in_redis;
  } cases[] {
    {1lu, "2", "2\t3"},
    {2lu, "", "1\t3"},
    {3lu, "-1", "1\t4"},
    {4lu, "3", "2\t3"},
  };
  int n = ARRAYSIZE_UNSAFE(cases);
  // clear value in redis
  for (int i = 0; i < n; ++i) {
    std::string key = base::StringPrintf("SIM-%lu", cases[i].item_id);
    int status = GetRedis()->Exist(key);
    if (status == 0) {
      ASSERT_TRUE(GetRedis()->Del(key));
    }
  }

  // test file result
  ASSERT_TRUE(sim_item->LoadFromFile(base::FilePath(FLAGS_test_sim_index_dir)));
  std::unordered_set<uint64> id_set;
  std::vector<std::string> flds;
  for (int i = 0; i < n; ++i) {
    flds.clear();
    base::SplitString(cases[i].sim_ids_in_file, "\t", &flds);
    if (flds.size() == 1 && flds[0] == "-1") {
      const std::vector<uint64>* sims = sim_item->GetSimItemIds(cases[i].item_id);
      ASSERT_TRUE(sims == NULL) << cases[i].item_id << " " << sims->size();
      continue;
    }

    id_set.clear();
    for (size_t j = 0; j < flds.size(); ++j) {
      if (flds[j].empty()) continue;
      id_set.insert(base::ParseUint64OrDie(flds[j]));
    }

    const std::vector<uint64>* sims = sim_item->GetSimItemIds(cases[i].item_id);
    ASSERT_TRUE(sims != NULL);

    ASSERT_EQ(sims->size(), id_set.size());
    for (size_t j = 0; j < sims->size(); ++j) {
      ASSERT_TRUE(id_set.find(sims->at(j)) != id_set.end());
    }
  }

  FLAGS_update_sim_item_interval_second = 1;
  sim_item->update_sim_item_thread_.Start(NewCallback(sim_item.get(), &SimItem::UpdateThread));
  for (int i = 0; i < n; ++i) {
    ASSERT_TRUE(GetRedis()->SetEx(base::StringPrintf("SIM-%lu", cases[i].item_id),
                                  cases[i].sim_ids_in_redis, 1800));
  }

  // base::SleepForSeconds(61);
  // // 第一次遍历 n 个 item 仍然是 file 中的结果，应为增量更新从新的 item 开始
  // for (int i = 0; i < n; ++i) {
  //   flds.clear();
  //   base::SplitString(cases[i].sim_ids_in_file, "\t", &flds);
  //   if (flds.size() == 1 && flds[0] == "-1") {
  //     const std::vector<uint64>* sims = sim_item->GetSimItemIds(cases[i].item_id);
  //     ASSERT_TRUE(sims == NULL) << cases[i].item_id << " " << sims->size();
  //     continue;
  //   }

  //   id_set.clear();
  //   for (size_t j = 0; j < flds.size(); ++j) {
  //     if (flds[j].empty()) continue;
  //     id_set.insert(base::ParseUint64OrDie(flds[j]));
  //   }

  //   const std::vector<uint64>* sims = sim_item->GetSimItemIds(cases[i].item_id);
  //   ASSERT_TRUE(sims != NULL);

  //   ASSERT_TRUE(sims != NULL) << cases[i].item_id;
  //   ASSERT_EQ(sims->size(), id_set.size()) << cases[i].item_id << " value:" << cases[i].sim_ids_in_file;
  //   for (size_t j = 0; j < sims->size(); ++j) {
  //     ASSERT_TRUE(id_set.find(sims->at(j)) != id_set.end());
  //   }
  // }

  // incr some items
  std::set<uint64> need_update_set;
  {
    std::vector<reco::RecoItem> incr_items;
    incr_items.push_back(reco::RecoItem());
    incr_items.back().mutable_identity()->set_app_token("app");
    incr_items.back().mutable_identity()->set_item_id(5);
    incr_items.back().mutable_identity()->set_outer_id("item5");
    incr_items.back().mutable_identity()->set_type(reco::kNews);

    incr_items.back().set_is_valid(true);
    GetNowTime().ToStringInSeconds(incr_items.back().mutable_create_time());
    incr_items.back().set_title("this is title 5");
    incr_items.back().set_content("this is content 5");
    incr_items.back().set_source("sina");
    incr_items.back().add_category("社会");

    ASSERT_TRUE(GetRedis()->SetEx("SIM-5", "1\t2\t3", 120));
    mutable_builder()->AddItemOnline(incr_items);
    need_update_set.insert(1lu);
    need_update_set.insert(2lu);
    need_update_set.insert(3lu);
  }

  base::SleepForSeconds(61);

  // 第 2 次遍历 n 个 item 中有部分是 redis 中的结果
  for (int i = 0; i < n; ++i) {
    flds.clear();
    // if (need_update_set.find(cases[i].item_id) != need_update_set.end()) {
    //   base::SplitString(cases[i].sim_ids_in_redis, "\t", &flds);
    // } else {
    //   base::SplitString(cases[i].sim_ids_in_file, "\t", &flds);
    // }
    base::SplitString(cases[i].sim_ids_in_redis, "\t", &flds);

    if (flds.size() == 1 && flds[0] == "-1") {
      const std::vector<uint64>* sims = sim_item->GetSimItemIds(cases[i].item_id);
      ASSERT_TRUE(sims == NULL) << cases[i].item_id << " " << sims->size();
      continue;
    }

    id_set.clear();
    for (size_t j = 0; j < flds.size(); ++j) {
      if (flds[j].empty()) continue;
      id_set.insert(base::ParseUint64OrDie(flds[j]));
    }

    const std::vector<uint64>* sims = sim_item->GetSimItemIds(cases[i].item_id);
    ASSERT_TRUE(sims != NULL) << cases[i].item_id;
    ASSERT_EQ(sims->size(), id_set.size()) << cases[i].item_id;
    for (size_t j = 0; j < sims->size(); ++j) {
      ASSERT_TRUE(id_set.find(sims->at(j)) != id_set.end());
    }
  }
}
}  // namespace reco
