#pragma once
#include <string>
#include <vector>
#include <set>
#include <unordered_set>
#include "base/common/basic_types.h"
#include "reco/bizc/sim_lib/sim_struct.h"

namespace reco {
namespace sim_lib {
class SimLib;
}

class SimItem {
 public:
  SimItem();
  ~SimItem();

 public:
  void Start();
  void Stop();
  void GetYuanChuangItems(std::unordered_set<uint64>* filtered_items) {
    return;
  }

  const std::set<uint64>* GetSimItemIds(uint64 item_id) const;

  // bool GetSimItemIds(uint64 item_id, std::vector<uint64>* sim_ids) const;

  bool GetSimElems(uint64 item_id, std::vector<reco::sim_lib::SimElem>* sim_elems) const;

  uint64 GetParent(uint64 item_id) const;

  bool HasCheckedBySimServer(uint64 item_id) const;

 private:

  reco::sim_lib::SimLib* sim_lib_;
};
}
