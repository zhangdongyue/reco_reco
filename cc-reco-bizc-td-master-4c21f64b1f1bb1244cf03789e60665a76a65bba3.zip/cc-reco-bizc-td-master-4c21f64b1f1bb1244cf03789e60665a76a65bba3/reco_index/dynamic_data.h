#pragma once
#include <boost/shared_ptr.hpp>
#include <memory>

#include "base/common/basic_types.h"
#include "base/thread/sync.h"

namespace wolong {
namespace olm {

// 线程安全的可动态加载(拷贝)的数据结构.
// 典型应用方法:
// 使用线程每次通过 GetDict() 方法获取最新的字典.
// 更新线程通过 SafeCopy() 方法更新字典内容.
// 使用线程和更新线程互不影响.
template <class Dict>
class DynamicData {
 public:
  DynamicData() : data_(new Dict) {}
  explicit DynamicData(const Dict& dict) : data_(new Dict) {
    SafeCopy(dict);
  }
  ~DynamicData() {}
 public:
  const boost::shared_ptr<Dict> GetDict(void) const;
  boost::shared_ptr<Dict> GetMutableDict(void);
  void SafeCopy(const Dict& dict);
 private:
  boost::shared_ptr<Dict> data_;
  thread::Mutex reload_mutex_;
  mutable thread::Mutex access_mutex_;

  DISALLOW_COPY_AND_ASSIGN(DynamicData<Dict>);
};

template<class Dict>
void DynamicData<Dict>::SafeCopy(const Dict& dict) {
  thread::AutoLock lock_reload(&reload_mutex_);
  boost::shared_ptr<Dict> tmp_dict(new Dict);
  *tmp_dict = dict;
  {
    thread::AutoLock lock_access(&access_mutex_);
    data_.swap(tmp_dict);
    CHECK(data_.unique());
  }
}

template<class Dict>
const boost::shared_ptr<Dict> DynamicData<Dict>::GetDict(void) const {
  thread::AutoLock lock_access(&access_mutex_);
  return data_;
}

template<class Dict>
boost::shared_ptr<Dict> DynamicData<Dict>::GetMutableDict(void) {
  thread::AutoLock lock_access(&access_mutex_);
  return data_;
}

}  // namespace
}  // namespace
