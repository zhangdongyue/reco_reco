#include <vector>
#include <string>
#include <fstream>
#include <set>
#include "boost/concept_check.hpp"

#include "base/testing/gtest.h"
#include "base/common/scoped_ptr.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/meta_info_updator.h"
#include "reco/bizc/reco_index/sim_item.h"

// #include "reco/serv/reco_leaf/strategy/click_reco.h"
#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"

#include "base/file/file_util.h"
#include "base/encoding/line_escape.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/bizc/reco_index/mock_index_builder.h"

#include "ads_index/api/public.h"
#include "ads_index/dynamic_index/dynamic_index.h"
#include "ads_index/mix_index/mix_index.h"
#include "ads_index/proto/index.pb.h"

DEFINE_string(test_meta_index_dir, "reco/bizc/reco_index/test_data", "");

namespace reco {

class MetaInfoUpdatorTest: public testing::Test {
 public:
  virtual void SetUp() {
    using namespace reco;  // NOLINT
    FLAGS_update_sim_item_interval_second = -1;
    FLAGS_update_meta_interval_second = -1;
    now_ = base::Time::Now();
    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(1);
      item.mutable_identity()->set_outer_id("item1");
      item.mutable_identity()->set_type(reco::kNews);

      item.set_is_valid(true);
      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("this is title");
      item.set_content("this is content");
      item.set_source("sina");
      item.add_category("体育");
      item.add_category("nba");

      builder_.AddDoc(item);
    }
    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(2);
      item.mutable_identity()->set_outer_id("item2");
      item.mutable_identity()->set_type(reco::kNews);

      item.set_is_valid(true);
      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("this is title 2");
      item.set_content("this is content 2");
      item.set_source("sina");
      item.add_category("体育");
      item.add_category("cba");

      builder_.AddDoc(item);
    }
    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(3);
      item.mutable_identity()->set_outer_id("item3");
      item.mutable_identity()->set_type(reco::kNews);

      item.set_is_valid(true);
      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("this is title 3");
      item.set_content("this is content 3");
      item.set_source("sina");
      item.add_category("社会");

      builder_.AddDoc(item);
    }
    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(4);
      item.mutable_identity()->set_outer_id("item4");
      item.mutable_identity()->set_type(reco::kNews);

      item.set_is_valid(true);
      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("this is title 4");
      item.set_content("this is content 5");
      item.set_source("sina");
      item.add_category("社会");

      builder_.AddDoc(item);
    }

    builder_.BuildIndex(FLAGS_test_meta_index_dir,
                        "ads_index/api/data/static_dict.dat");
    news_index_ = builder_.GetNewsIndex();
    CHECK_NOTNULL(news_index_);
    LOG(INFO) << base::StringPrintf("init news index finished!");

    // build meta info file
    std::vector<reco::index_data::MetaData> meta_info_datas;
    meta_info_datas.push_back(reco::index_data::MetaData());
    meta_info_datas.back().set_item_id(1lu);
    meta_info_datas.back().set_show_cnt(1);
    meta_info_datas.back().set_click_cnt(1);
    meta_info_datas.back().set_share_cnt(1);
    meta_info_datas.back().set_fav_cnt(1);

    meta_info_datas.push_back(reco::index_data::MetaData());
    meta_info_datas.back().set_item_id(2lu);
    meta_info_datas.back().set_show_cnt(2);
    meta_info_datas.back().set_click_cnt(2);
    meta_info_datas.back().set_share_cnt(2);
    meta_info_datas.back().set_fav_cnt(2);

    meta_info_datas.push_back(reco::index_data::MetaData());
    meta_info_datas.back().set_item_id(3lu);
    meta_info_datas.back().set_show_cnt(3);
    meta_info_datas.back().set_click_cnt(3);
    meta_info_datas.back().set_share_cnt(3);
    meta_info_datas.back().set_fav_cnt(3);

    meta_info_datas.push_back(reco::index_data::MetaData());
    meta_info_datas.back().set_item_id(4lu);
    meta_info_datas.back().set_show_cnt(4);
    meta_info_datas.back().set_click_cnt(4);
    meta_info_datas.back().set_share_cnt(4);
    meta_info_datas.back().set_fav_cnt(4);

    base::FilePath dir(FLAGS_test_meta_index_dir);
    std::ofstream fout(dir.Append(reco::MetaInfoUpdator::kMetaInfoFile).value(),
                       std::ofstream::out | std::ofstream::binary);
    int size = 0;
    char buffer[1024];
    for (size_t i = 0; i < meta_info_datas.size(); ++i) {
      size = meta_info_datas[i].ByteSize();
      CHECK(meta_info_datas[i].SerializeToArray(&buffer, size));
      fout.write(reinterpret_cast<const char*>(&size), sizeof(size));
      fout.write(buffer, size);
    }

    reco::redis::FLAGS_redis_pool_ips = "100.81.1.68:6500,100.81.2.180:6500,100.81.4.141:6500";
    reco::redis::RedisCli *redis = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);
    boost::ignore_unused_variable_warning(redis);
  }

  virtual void TearDown() {
  }

  virtual const reco::NewsIndex* GetNewsIndex() {
    return news_index_;
  }

  const base::Time& GetNowTime() const {
    return now_;
  }

 private:
  const reco::NewsIndex* news_index_;
  base::Time now_;
  reco::MockIndexBuilder builder_;
};

TEST_F(MetaInfoUpdatorTest, LoadFromFile) {
  const reco::NewsIndex* index = GetNewsIndex();
  reco::MetaInfoUpdator* meta_info_updator = new reco::MetaInfoUpdator(index, NULL, NULL);
  ASSERT_TRUE(meta_info_updator->LoadFromFile(base::FilePath(FLAGS_test_meta_index_dir)));
  struct {
    uint64 item_id;
    uint64 show_cnt;
    uint64 click_cnt;
    uint64 share_cnt;
    uint64 fav_cnt;
  } cases[] = {
    {1, 1, 1, 1, 1},
    {2, 2, 2, 2, 2},
    {3, 3, 3, 3, 3},
    {4, 4, 4, 4, 4},
  };
  int n = ARRAYSIZE_UNSAFE(cases);
  reco::ItemInfo item_info;
  for (int i = 0; i < n; ++i) {
    meta_info_updator->GetMetaInfo(cases[i].item_id, &item_info);
    ASSERT_EQ(cases[i].item_id, item_info.item_id);
  }
}
}
