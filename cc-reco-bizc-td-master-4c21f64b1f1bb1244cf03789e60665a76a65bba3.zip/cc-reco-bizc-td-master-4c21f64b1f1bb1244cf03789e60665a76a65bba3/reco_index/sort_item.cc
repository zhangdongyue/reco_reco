#include "reco/bizc/reco_index/sort_item.h"

#include <functional>
#include <utility>
#include <cmath>
#include <algorithm>
#include <limits>
#include <map>
#include <set>
#include <vector>
#include <list>

#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/sim_item.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/common/channel_define.h"
#include "reco/bizc/common/wrapped_category.h"
#include "nlp/common/nlp_util.h"
#include "base/common/sleep.h"
#include "base/time/time.h"
#include "base/math/discrete.h"
#include "base/time/timestamp.h"
#include "base/hash_function/url.h"
#include "base/hash_function/term.h"
#include "base/encoding/line_escape.h"
#include "base/strings/string_split.h"
#include "base/common/basic_types.h"
#include "base/common/scoped_ptr.h"
#include "base/container/dense_hash_set.h"
#include "base/strings/string_printf.h"
#include "base/strings/utf_char_iterator.h"
#include "base/random/pseudo_random.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/bizc/poi/geohash.h"
#include "reco/bizc/poi/city_area_hash_dict.h"
#include "reco/bizc/region/region_dict.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"

namespace reco {

DECLARE_string(target_server);

DEFINE_int32(sort_oper_item_interval_second, 30, "oper item 排序线程运行的时间间隔, 设为 -1 不运行此线程");
DEFINE_int32(sort_item_interval_second, -1, "item 排序线程运行的时间间隔(秒), 设为 -1 不运行此线程");
DEFINE_int32(sort_item_doc_delta, 1000, "item 排序线程运行的文档增量, 新增文档数量大于此阈值则立即运行");
DEFINE_bool(throw_dedup_item_in_index, false, "是否直接丢弃相似的 item");
DEFINE_bool(index_test_env, false, "测试环境");

DEFINE_int32(floor_hot_thresh, 10, "floor hot thresh");
DEFINE_int32(floor_pr_thresh, 8, "floor pr thresh");
DEFINE_double(suspect_rubbish_video_ctr_thr, 0.05, "疑似低质的视频ctr必须超过阈值才会入队");

DEFINE_bool(open_poi_queue_switch, false, "是否开启 POI 队列");
DEFINE_bool(open_local_breaking_queue_switch, false, "是否开启 本地突发 队列");
DEFINE_bool(open_time_axis_switch, false, "是否开启时间轴");
DEFINE_bool(open_youku_show_sort_switch, false, "是否开启优酷追查");
DEFINE_bool(dizhi_filter_wemedia, true, "是否开启自媒体过滤");
DEFINE_bool(dizhi_filter_compete_source, true, "是否开启竞品过滤");
DEFINE_bool(dizhi_filter_compete_media, true, "是否开启竞品媒体过滤");
DEFINE_int32(dizhi_low_new_itemq_thresh, 20, "dizhi low_new_itemq_thresh");
DEFINE_bool(open_debug_filter_bad_item, false, "是否开启 debug filter bad item");
DEFINE_bool(dizhi_tag_and_category_filter, true, "是否开启 dizhi tag and category filter");
DEFINE_bool(index_sort_use_predict_ctr, true, "");

DECLARE_int32(video_confidence_show_num);
DEFINE_int32(max_fea, 50, "");
DEFINE_int32(guarantee_deliver_time_threshold_in_hour, 48, "发布时间在若干小时以内文章进入保量队列");
DEFINE_int64_counter(reco_index, manual_item_num, 0, "运营拉链长度");

DEFINE_int64_counter(reco_index, sort_item_cost, 0, "");
DEFINE_int64_counter(reco_index, doc_total, 0, "");
DEFINE_double_counter(reco_index, vid_lack_ratio, 0, "视频 vid 缺失率");

DEFINE_int32(ugc_explore_day_limit, 3, "几天内的视频入 ugc explore 队列");
DEFINE_int32(ugc_explore_thresh, 100, "explore 召回阈值");

const int64 SortItem::kNoRecoChannelIds[] = {0};
const char* SortItem::kPictureCategories[] = {"美女写真", "宠物", "动漫", "摄影"};
std::unordered_map<std::string, int64> GetVideoCategoryToChannel() {
  std::unordered_map<std::string, int64> video_category_to_channel;
  video_category_to_channel["体育"] = reco::common::kSportChannelId;
  video_category_to_channel["娱乐"] = reco::common::kEntertainmentChannelId;
  video_category_to_channel["军事"] = reco::common::kMilitaryChannelId;
  return video_category_to_channel;
}

const std::unordered_map<std::string, int64> SortItem::kVideoCategoryToChannel = GetVideoCategoryToChannel();

const std::unordered_set<std::string> SortItem::kLocalSourceRejectCategories = {
  "娱乐", "体育", "科技", "汽车", "国际", "军事", "财经"};
const std::unordered_set<std::string> SortItem::kMachineProducerSet =
  {"uc", "tudou", "cp_wemedia_youtu", "cp_chaoxi", "cp_gaode"};
const std::unordered_set<std::string> SortItem::kCompeteSourceMediaSet = {"一点资讯", "腾讯网", "微信自媒体"};

SortItem::SortItem(const reco::NewsIndex* news_index,
                   reco::SimItem* sim_item,
                   SourceManager* source_manager) {
  news_index_ = news_index;
  index_ = news_index_->GetAdsIndex();
  sim_item_ = sim_item;
  source_manager_ = source_manager;
  random_ = new base::PseudoRandom(base::GetTimestamp());

  // 初始化抽特征类
  reco::reco_index::WDExtractor::Instance().Init(news_index_);
  reco::ml::WDUserFeature::Instance().Init();
  reco::ml::WDItemFeature::Instance().Init(NULL, NULL);

  subs_channel_ = new SubscribeChannel(news_index_);
  dict_manager_ = IndexDictManager::GetInstance();
  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(kNoRecoChannelIds); i++) {
    no_reco_channel_ids_.insert(kNoRecoChannelIds[i]);
  }

  humor_channel_ids_.insert(reco::common::kHumorWordChannelId);
  humor_channel_ids_.insert(reco::common::kHumorPicChannelId);
  humor_channel_ids_.insert(reco::common::kHumorWordTouTiaoChannelId);

  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(kPictureCategories); i++) {
    picture_categories_.insert(kPictureCategories[i]);
  }

  sort_item_thread_stop_ = false;
  all_items_.reserve(kMaxSaveTotal + 1);
  items_feature_.items_index.set_empty_key(0);
  items_feature_.items_fea.reserve(kMaxSaveTotal + 1);

  if (FLAGS_sort_oper_item_interval_second > 0) {
    SortOperItemLoop();
    LOG(INFO) << "first time sort oper item done, and sort oper thread started.";
    sort_oper_item_thread_.Start(NewCallback(this, &SortItem::SortOperItemThread));
  }
  if (FLAGS_sort_item_interval_second > 0) {
    // 先主动调用一次更新
    SortItemLoop();
    LOG(INFO) << "first time sort item done, and sort thread started.";
    sort_item_thread_.Start(NewCallback(this, &SortItem::SortItemThread));
  }
  // 构建离线挖掘策略的结果
  BuildMiningStrategyItemDict();
}

SortItem::~SortItem() {
  LOG(INFO) << "release";

  sort_item_thread_stop_ = true;
  if (FLAGS_sort_item_interval_second > 0) {
    sort_item_thread_.Join();
  }

  if (FLAGS_sort_oper_item_interval_second > 0) {
    sort_oper_item_thread_.Join();
  }

  delete subs_channel_;
  delete random_;
}

bool VideoItemSortFunc(const ItemInfo& left, const ItemInfo& right) {
  if (left.ctr != right.ctr) return left.ctr > right.ctr;
  if (left.spider_score != right.spider_score) return left.spider_score > right.spider_score;
  // 视频不考虑时效性
  // if (left.time_level != right.time_level) return left.time_level > right.time_level;
  if (left.itemq != right.itemq) return left.itemq > right.itemq;
  if (left.hot_level  != right.hot_level)  return left.hot_level > right.hot_level;
  if (left.site_level != right.site_level) return left.site_level > right.site_level;
  if (left.create_timestamp != right.create_timestamp) return left.create_timestamp > right.create_timestamp;
  return left.doc_id < right.doc_id;
}

bool UgcVideoItemSortFunc(const ItemInfo& left, const ItemInfo& right) {
  if (left.itemq != right.itemq) return left.itemq > right.itemq;
  if (left.ctr != right.ctr) return left.ctr > right.ctr;
  if (left.spider_score != right.spider_score) return left.spider_score > right.spider_score;
  if (left.hot_level != right.hot_level) return left.hot_level > right.hot_level;
  if (left.site_level != right.site_level) return left.site_level > right.site_level;
  if (left.create_timestamp != right.create_timestamp) return left.create_timestamp > right.create_timestamp;
  return left.doc_id < right.doc_id;
}

bool SubjectItemSortFunc(const ItemInfo& left, const ItemInfo& right) {
  if (left.wilson_ctr != right.wilson_ctr) return left.wilson_ctr > right.wilson_ctr;
  if (left.ctr != right.ctr) return left.ctr > right.ctr;
  if (left.spider_score != right.spider_score) return left.spider_score > right.spider_score;
  // 视频不考虑时效性
  // if (left.time_level != right.time_level) return left.time_level > right.time_level;
  if (left.new_itemq != right.new_itemq) return left.new_itemq > right.new_itemq;
  if (left.itemq != right.itemq) return left.itemq > right.itemq;
  if (left.hot_level  != right.hot_level)  return left.hot_level > right.hot_level;
  if (left.site_level != right.site_level) return left.site_level > right.site_level;
  if (left.create_timestamp != right.create_timestamp) return left.create_timestamp > right.create_timestamp;
  return left.doc_id < right.doc_id;
}

bool LocalItemSortFunc(const ItemInfo& left, const ItemInfo& right) {
  if (left.index_score != right.index_score) return left.index_score > right.index_score;

  if (left.time_level != right.time_level) return left.time_level > right.time_level;
  if (left.ctr != right.ctr) return left.ctr > right.ctr;
  if (left.itemq != right.itemq) return left.itemq > right.itemq;
  if (left.hot_level  != right.hot_level)  return left.hot_level > right.hot_level;
  if (left.spider_score != right.spider_score) return left.spider_score > right.spider_score;
  if (left.site_level != right.site_level) return left.site_level > right.site_level;
  if (left.create_timestamp != right.create_timestamp) return left.create_timestamp > right.create_timestamp;
  return left.doc_id < right.doc_id;
}

bool MediaQuantityItemSortFunc(const ItemInfo& left, const ItemInfo& right) {
  if (left.media_quantity_score != right.media_quantity_score)
    return left.media_quantity_score > right.media_quantity_score;
  if (left.ctr != right.ctr) return left.ctr > right.ctr;
  if (left.spider_score != right.spider_score) return left.spider_score > right.spider_score;
  if (left.time_level != right.time_level) return left.time_level > right.time_level;
  if (left.itemq != right.itemq) return left.itemq > right.itemq;
  if (left.hot_level  != right.hot_level)  return left.hot_level > right.hot_level;
  if (left.site_level != right.site_level) return left.site_level > right.site_level;
  if (left.create_timestamp != right.create_timestamp) return left.create_timestamp > right.create_timestamp;
  return left.doc_id < right.doc_id;
}

bool MediaQuantityVideoItemSortFunc(const ItemInfo& left, const ItemInfo& right) {
  if (left.media_quantity_score != right.media_quantity_score)
    return left.media_quantity_score > right.media_quantity_score;
  if (left.ctr != right.ctr) return left.ctr > right.ctr;
  if (left.spider_score != right.spider_score) return left.spider_score > right.spider_score;
  // 视频不考虑时效性
  // if (left.time_level != right.time_level) return left.time_level > right.time_level;
  if (left.itemq != right.itemq) return left.itemq > right.itemq;
  if (left.hot_level  != right.hot_level)  return left.hot_level > right.hot_level;
  if (left.site_level != right.site_level) return left.site_level > right.site_level;
  if (left.create_timestamp != right.create_timestamp) return left.create_timestamp > right.create_timestamp;
  return left.doc_id < right.doc_id;
}

// 希望按照发布时间从新到旧排序
bool ShowItemSortFunc(const ItemInfo& left, const ItemInfo& right) {
  if (left.create_timestamp != right.create_timestamp) {
    return left.create_timestamp < right.create_timestamp;
  }
  return left.doc_id <= right.doc_id;
}

bool NewsItemSortFunc(const ItemInfo& left, const ItemInfo& right) {
  if (left.index_score != right.index_score) return left.index_score > right.index_score;

  if (left.time_level != right.time_level) return left.time_level > right.time_level;
  if (left.ctr != right.ctr) return left.ctr > right.ctr;
  if (left.itemq != right.itemq) return left.itemq > right.itemq;
  if (left.hot_level  != right.hot_level)  return left.hot_level > right.hot_level;
  if (left.site_level != right.site_level) return left.site_level > right.site_level;
  if (left.create_timestamp != right.create_timestamp) return left.create_timestamp > right.create_timestamp;
  return left.doc_id < right.doc_id;
}

bool NewsItemTimeSortFunc(const ItemInfo& left, const ItemInfo& right) {
  if (left.create_timestamp != right.create_timestamp) {
    return left.create_timestamp > right.create_timestamp;
  }
  return left.doc_id >= right.doc_id;
}

bool UCBItemSortFunc(const std::pair<int, const ItemInfo*>& left,
                     const std::pair<int, const ItemInfo*>& right) {
  const ItemInfo* left_item = left.second;
  const ItemInfo* right_item = right.second;
  if (left.first != right.first) {
    return left.first > right.first;
  }
  CHECK(left_item != NULL && right_item != NULL);
  if (left_item->create_timestamp != right_item->create_timestamp) {
    return left_item->create_timestamp > right_item->create_timestamp;
  }
  return left_item->doc_id <= right_item->doc_id;
}

bool HumorItemSortFunc(const ItemInfo& left,
                           const ItemInfo& right) {
  if (left.time_level != right.time_level) return left.time_level > right.time_level;
  if (left.spider_score != right.spider_score) return left.spider_score > right.spider_score;
  if (left.itemq != right.itemq) return left.itemq > right.itemq;
  if (left.create_timestamp != right.create_timestamp) return left.create_timestamp > right.create_timestamp;
  return left.doc_id <= right.doc_id;
}

void SortItem::BuildMiningStrategyItemDict() {
  // for every strategy
  //   for every item
  //     if ok, push back
  auto const dict = dict_manager_->GetMiningStrategyItem();
  if (dict == NULL) return;
  int64 now_timestamp = base::GetTimestamp();
  for (auto iter = dict->begin(); iter != dict->end(); ++iter) {
    int32 strategy = iter->first;
    const std::vector<uint64>& item_ids = iter->second;
    int get_info_fail_item = 0;
    int invalid_item = 0;
    int expired_item = 0;
    std::vector<ItemInfo>& item_list = mining_strategy_item_[strategy];
    for (size_t i = 0; i < item_ids.size(); ++i) {
      ItemInfo item;
      if (!news_index_->GetItemInfoByItemId(item_ids[i], &item, false)) {
        ++get_info_fail_item;
        continue;
      }
      if (!news_index_->IsValidByDocId(item.doc_id)) {
        ++invalid_item;
        continue;
      }
      if (news_index_->IsExpiredByDocId(item.doc_id, now_timestamp)) {
        ++expired_item;
        continue;
      }
      item_list.push_back(item);
    }
    std::sort(item_list.begin(), item_list.end(), NewsItemTimeSortFunc);
    LOG(INFO) << "build mining strategy: " << strategy
              << " index, size : " << item_list.size()
              << " get info fail size : " << get_info_fail_item
              << " invalid size : " << invalid_item
              << " expired size : " << expired_item;
  }
}

bool SortItem::IsYoukuShowItem(const ItemInfo& item) {
  std::string youku_show_id = "";
  // 追剧类(item_type=30 && show_id is not empty
  if (item.item_type == reco::kPureVideo &&
      news_index_->GetYoukuShowIDByItemId(item.item_id, &youku_show_id)) {
    return true;
  } else {
    return false;
  }
}
//////////////////////////////////////////////////////////////////////////
// // News Index 相关
void SortItem::SortOperItemThread() {
  while (!sort_item_thread_stop_) {
    while (!ucb_index_.CanSwitch()) {
      LOG(INFO) << "ucb index dict not ready to switch";
      base::SleepForSeconds(1);
    }

    if (!SortOperItemLoop()) {
      LOG(ERROR) << "sort oper item failed";
    }

    base::SleepForSeconds(FLAGS_sort_oper_item_interval_second);
  }
}

void SortItem::SortItemThread() {
  index_doc_ = 0;
  sort_item_thread_stop_ = false;
  // 运行条件
  // 1. sort_item_thread_stop_ = false
  // 2. index doc 数量
  while (!sort_item_thread_stop_) {
    while (!IsIndexDictCanSwitch()) {
      LOG(INFO) << "sort dict not ready to switch";
      base::SleepForSeconds(30);
    }

    // 新文档数量达到一定阈值，立即运行
    if (index_->GetDocNum() - index_doc_ > FLAGS_sort_item_doc_delta) {
      LOG(INFO) << "sort items becase doc increment > delta";
      if (!SortItemLoop()) {
        LOG(ERROR) << "sort item failed";
      }
      index_doc_ = index_->GetDocNum();
      continue;
    } else {
      LOG(INFO) << "sort items becase sleep time up";
      if (!SortItemLoop()) {
        LOG(ERROR) << "sort item failed";
      }
      index_doc_ = index_->GetDocNum();
    }
    base::SleepForSeconds(FLAGS_sort_item_interval_second);
  }
}

bool SortItem::SortOperItemLoop() {
  LOG(INFO) << "begin to sort oper item.";
  COUNTERS_reco_index__doc_total.Reset(index_->GetDocNum());

  serving_base::Timer timer;
  timer.Start();

  thread::AutoLock lock(&sort_oper_item_mutex_);
  if (index_->GetDocNum() == 0) {
    LOG(INFO) << "news index has null item";
    return true;
  }

  std::vector<ItemInfo> all_oper_items;
  GetAllOperItems(&all_oper_items, kMaxSaveTotal);

  NewsQueue*  ucb_index = ucb_index_.GetInactiveDict();
  ucb_index->Clear();
  NewsQueue*  hot_card_index = hot_card_index_.GetInactiveDict();
  hot_card_index->Clear();
  SortUCBItems(all_oper_items, ucb_index, hot_card_index);
  ucb_index_.SwitchDict();
  hot_card_index_.SwitchDict();

  LOG(INFO) << "end to sort oper item, cost " << timer.Stop() / 1e3 << " ms.";

  return true;
}

bool SortItem::SortItemLoop() {
  LOG(INFO) << "begin to sort item.";
  serving_base::Timer timer;
  timer.Start();

  thread::AutoLock lock(&sort_item_mutex_);
  if (index_->GetDocNum() == 0) {
    LOG(INFO) << "news index has null item";
    return true;
  }

  if (!IsIndexDictCanSwitch()) {
    LOG(WARNING) << "not ready for switch";
    return true;
  }

  NewsQueue*  app_index = app_index_.GetInactiveDict();
  app_index->Clear();

  NewsQueue*  jingpin_index = jingpin_index_.GetInactiveDict();
  jingpin_index->Clear();
  CategoryMap*  category_index = category_index_.GetInactiveDict();
  category_index->clear();
  ChannelMap *channel_index = channel_index_.GetInactiveDict();
  channel_index->clear();
  ChannelMap *region_index = region_index_.GetInactiveDict();
  region_index->clear();
  ChannelMap *poi_index = poi_index_.GetInactiveDict();
  poi_index->clear();
  std::unordered_map<std::string, std::unordered_set<uint64>>* wemedia_items_dict
      = wemedia_items_dict_.GetInactiveDict();

  // 短视频相关
  // NewsQueue* hot_video_index = hot_video_index_.GetInactiveDict();
  // hot_video_index->Clear();
  ChannelMap *channel_video_index = channel_video_index_.GetInactiveDict();
  channel_video_index->clear();
  ChannelMap *channel_video_explore_index = channel_video_explore_index_.GetInactiveDict();
  channel_video_explore_index->clear();
  ChannelMap *channel_video_fully_shown_index = channel_video_fully_shown_index_.GetInactiveDict();
  channel_video_fully_shown_index->clear();
  CategoryMap*  video_category_index = video_category_index_.GetInactiveDict();
  video_category_index->clear();
  NewsQueue*  subject_index = subject_index_.GetInactiveDict();
  subject_index->Clear();
  ShowInfoMap*  show_video_index = youku_show_video_index_.GetInactiveDict();
  show_video_index->clear();

  ChannelMap *ugc_video_index = ugc_video_index_.GetInactiveDict();
  ugc_video_index->clear();
  ChannelMap *ugc_video_explore_index = ugc_video_explore_index_.GetInactiveDict();
  ugc_video_explore_index->clear();

  // 媒体保量相关
  CategoryMap*  media_quantity_index = media_quantity_index_.GetInactiveDict();
  media_quantity_index->clear();
  CategoryMap*  video_media_quantity_index = video_media_quantity_index_.GetInactiveDict();
  video_media_quantity_index->clear();

  // 访问 redis 获得被原创保护过滤掉的文章
  filtered_items_.clear();
  GetFilteredItems(&filtered_items_);

  // 获取索引当前所有可用的 item
  all_items_.clear();
  GetAllItems(&all_items_, kMaxSaveTotal);

  // 填充语义信息
  FillItemAttr(all_items_);

  FillWeMediaItemsDict(all_items_, wemedia_items_dict);

  // 精品
  SortJingpinItems(all_items_, jingpin_index, kMaxSavePerCate);

  // 主题排序
  SortSubjectItems(all_items_, subject_index);

  // 子文对应的主题
  UpdateItemToSubjectDict(*(subject_index->GetIndex()));

  // 主题的视频标签
  UpdateSubjectVideoTagFeatureDict(*(subject_index->GetIndex()));

  // 热点视频
  // SortHotVideoItems(all_items_, hot_video_index);

  // get and sort zzd index
  std::vector<ItemInfo> youku_show_items;
  SortZZDItems(all_items_, app_index, &youku_show_items);

  // get and sort humor index
  SortHumorItems(all_items_, category_index, kMaxSavePerCate);

  // get and sort special index
  SortSpecialItems(all_items_, channel_index, kMaxSavePerCate);

  // get and sort category index
  SortCategoryItems(*(app_index->GetIndex()), category_index, video_category_index,
                    media_quantity_index, video_media_quantity_index);

  // 电视剧信息(首先用于追剧功能）
  SortYoukuShowItems(youku_show_items, show_video_index);

  // get and sort channel index
  SortChannelItems(*(app_index->GetIndex()), category_index, channel_index,
                   region_index, poi_index);

  // update local breaking index
  if (FLAGS_open_local_breaking_queue_switch) {
    UpdateLocalBreakingItems(region_index);
  }

  // get and sort video index
  SortVideoItems(*(app_index->GetIndex()), channel_video_index, channel_video_explore_index
                 , channel_video_fully_shown_index);

  // get and sort ugc video index
  SortUgcVideoItems(*(app_index->GetIndex()), ugc_video_index, ugc_video_explore_index);

  ExtractItemFea(all_items_);

  std::unordered_map<uint64, RuleChain> buffer;
  FillSourceRuleChain(app_index->MutableIndex(), &buffer);
  FillSourceRuleChain(jingpin_index->MutableIndex(), &buffer);
  // ucb 不做
  for (auto it = category_index->begin(); it != category_index->end(); ++it) {
    FillSourceRuleChain(it->second.MutableIndex(), &buffer);
  }
  for (auto it = channel_index->begin(); it != channel_index->end(); ++it) {
    FillSourceRuleChain(it->second.MutableIndex(), &buffer);
  }
  for (auto it = region_index->begin(); it != region_index->end(); ++it) {
    FillSourceRuleChain(it->second.MutableIndex(), &buffer);
  }
  for (auto it = channel_video_index->begin(); it != channel_video_index->end(); ++it) {
    FillSourceRuleChain(it->second.MutableIndex(), &buffer);
  }
  for (auto it = ugc_video_index->begin(); it != ugc_video_index->end(); ++it) {
    FillSourceRuleChain(it->second.MutableIndex(), &buffer);
  }
  for (auto it = ugc_video_explore_index->begin(); it != ugc_video_explore_index->end(); ++it) {
    FillSourceRuleChain(it->second.MutableIndex(), &buffer);
  }


  UpdateTimeAxisDict();
  // TODO(suzhewen): 临时做法： youku video id 和 item id 的映射关系
  UpdateYoukuIdDict(*(app_index->GetIndex()));

  // 如果没有单独的运营文章更新线程，则通用的更新流程里面更新运营文章
  if (FLAGS_sort_oper_item_interval_second < 0) {
    NewsQueue*  ucb_index = ucb_index_.GetInactiveDict();
    ucb_index->Clear();
    NewsQueue*  hot_card_index = hot_card_index_.GetInactiveDict();
    hot_card_index->Clear();
    SortUCBItems(all_items_, ucb_index, hot_card_index);
    ucb_index_.SwitchDict();
    hot_card_index_.SwitchDict();
  }

  wemedia_items_dict_.SwitchDict();
  app_index_.SwitchDict();
  channel_index_.SwitchDict();
  region_index_.SwitchDict();
  category_index_.SwitchDict();
  jingpin_index_.SwitchDict();
  subject_index_.SwitchDict();
  // hot_video_index_.SwitchDict();
  youku_show_video_index_.SwitchDict();
  poi_index_.SwitchDict();

  channel_video_index_.SwitchDict();
  channel_video_explore_index_.SwitchDict();
  channel_video_fully_shown_index_.SwitchDict();

  video_category_index_.SwitchDict();
  media_quantity_index_.SwitchDict();
  video_media_quantity_index_.SwitchDict();

  ugc_video_index_.SwitchDict();
  ugc_video_explore_index_.SwitchDict();

  COUNTERS_reco_index__sort_item_cost.Reset(timer.Stop()/1e6);
  LOG(INFO) << "end to sort item. time cost : " << timer.Stop();

  return true;
}

void SortItem::NormalizeSpiderScore(std::vector<ItemInfo>* items) const {
  LOG(INFO) << "normalize spider score, candidate size " << items->size();
  std::map<std::string, SourceInfo> source_map;
  std::map<uint64, std::string> id2source;
  for (int i = 0; i < (int)items->size(); ++i) {
    const ItemInfo& item_info = items->at(i);
    std::string source;
    if (!news_index_->GetSourceByItemId(item_info.item_id, &source) || source.empty()) {
      LOG(ERROR) << "failed to get source, " << item_info.item_id;
      continue;
    }
    if (item_info.item_type != reco::kHumor) {
      LOG(ERROR) << "not humor type, " << item_info.item_id;
      continue;
    }
    id2source[item_info.item_id] = source;

    SourceInfo& st = source_map[source];

    st.values.push_back(item_info.spider_score);
    st.times.push_back(news_index_->GetCreateTimestampByDocId(item_info.doc_id));
  }

  LOG(INFO) << "total source " << id2source.size() << ", totol source info " << source_map.size();

  for (auto it = source_map.begin(); it != source_map.end(); ++it) {
    SourceInfo& st = it->second;
    LOG(INFO) << it->first << " score vector: " << st.values.size() << ", time vector: " << st.times.size();
    st.value_boundaries.clear();
    st.time_boundaries.clear();
    if (base::math::EqualRangePartition(st.values, kSpiderBins, &st.value_boundaries)) {
      LOG(INFO) << it->first << " discrete using spider score";
    } else if (base::math::EqualRangePartition(st.times, kSpiderBins, &st.time_boundaries)) {
      LOG(INFO) << it->first << " discrete using time";
    } else {
      st.value_boundaries.clear();
      st.time_boundaries.clear();
      LOG(INFO) << it->first << " catnnot be discreted";
    }
  }

  for (int i = 0; i < (int)items->size(); ++i) {
    ItemInfo& item_info = (*items)[i];
    auto it = id2source.find(item_info.item_id);
    if (it == id2source.end()) {
      item_info.spider_score = 0;
      continue;
    }
    const std::string& source = it->second;
    const SourceInfo& st = source_map[source];
    int score_type = 0;
    if (!st.value_boundaries.empty()) {
      item_info.spider_score = base::math::Discretize(item_info.spider_score, st.value_boundaries);
      score_type = 1;
    } else if (!st.time_boundaries.empty()) {
      int64 time = news_index_->GetCreateTimestampByDocId(item_info.doc_id);
      item_info.spider_score = base::math::Discretize(time, st.time_boundaries);
      score_type = 2;
    } else {
      item_info.spider_score = kSpiderBins/2;
    }

    VLOG(1) << item_info.item_id << " " << item_info.spider_score << " " << score_type;
  }
}

int SortItem::GetTodayNewsNum(const std::vector<ItemInfo>& item_list) {
  base::Time now = base::Time::Now();
  base::Time::Exploded exploded;
  now.LocalExplode(&exploded);
  int end_day = exploded.day_of_month;
  int end_month = exploded.month;

  int today_news = 0;
  for (int i = 0; i < (int)item_list.size(); ++i) {
    if (!news_index_->IsValidByDocId(item_list[i].doc_id)) continue;
    int64 timestamp = news_index_->GetCreateTimestampByDocId(item_list[i].doc_id);
    if (timestamp == 0) continue;

    base::Time item_time = base::Time::FromDoubleT(timestamp / base::Time::kMicrosecondsPerSecond);
    item_time.LocalExplode(&exploded);
    if (end_day == exploded.day_of_month && end_month == exploded.month) {  // 当天新闻
      ++today_news;
    }
  }
  return today_news;
}

void SortItem::SortDocsIntoItems(const std::vector<int32>& docs,
                                 const std::vector<ItemInfo>& all_items,
                                 std::vector<ItemInfo>* items,
                                 int max_save_num) {
  items->clear();
  items->reserve(max_save_num);

  std::unordered_map<int32, int> docid_pos_map;
  for (int i = 0; i < (int)all_items.size(); ++i) {
    const ItemInfo& item_info = all_items.at(i);
    docid_pos_map.insert(std::make_pair(item_info.doc_id, i));
  }

  int64 now_timestamp = base::GetTimestamp();
  int64 invalid_item = 0;
  int64 filtered_item = 0;
  int64 meta_miss_item = 0;
  items->clear();
  std::string app_token;
  for (int i = 0; i < (int)docs.size(); ++i) {
    if ((int)items->size() >= max_save_num) break;
    // 已经按 docid 从小到大，即文档从新到旧排序
    int32 docid = docs[i];

    if (!news_index_->IsValidByDocId(docid)) {
      ++invalid_item;
      continue;
    }

    if (news_index_->IsExpiredByDocId(docid, now_timestamp)) {
      ++filtered_item;
      continue;
    }

    if (news_index_->IsManualByDocId(docid)) {
      continue;
    }

    ItemInfo item;
    auto iter = docid_pos_map.find(docid);
    if (iter != docid_pos_map.end()) {
      item = all_items[iter->second];
    } else if (!news_index_->GetItemInfoByDocId(docid, &item, false)) {
      ++meta_miss_item;
      continue;
    }

    if (item.item_type == reco::kHumor
        || item.item_type == reco::kSpecial
        || item.item_type == reco::kPureVideo) {
      ++filtered_item;
      continue;
    }


    items->push_back(item);
  }
  std::sort(items->begin(), items->end(), NewsItemSortFunc);

  LOG(INFO) << "news index update done. "
            << ". qualified item num: " << items->size()
            << ". invalid item num: " << invalid_item
            << ". meta miss item num: " << meta_miss_item
            << ". filtered item num: " << filtered_item;
}

void SortItem::ExtractCategoryItems(const std::vector<ItemInfo>& all_items,
                                    const reco::Category& raw_category,
                                    std::vector<ItemInfo>* items,
                                    std::vector<ItemInfo>* video_items,
                                    int max_save_num) {
  items->clear();
  video_items->clear();

  std::string first_category;
  std::string sub_category;
  if (raw_category.parents_size() == 0) {
    first_category = raw_category.category();
  } else {
    first_category = raw_category.parents(0);
    sub_category = raw_category.category();
  }

  static const std::unordered_set<int> kCategoryFilteredItemtypeSet
      = {reco::kHumor, reco::kSpecial, reco::kApp, reco::kGoods};

  std::string wemedia_person;
  int64 manual_filter_item = 0;
  int64 itemtype_filter_item = 0;
  int64 channel_filter_item = 0;

  std::unordered_set<uint64> dedup_items;
  std::unordered_set<uint64> dedup_video_items;
  std::vector<int> dedup_filtered_idx_vec;
  std::vector<int64> channels;
  for (int i = 0; i < (int)all_items.size(); ++i) {
    if ((int)items->size() >= max_save_num &&
        (int)video_items->size() >= max_save_num) break;

    const ItemInfo& item = all_items.at(i);

    bool cate_match = ((item.category == first_category)
                       && (sub_category.empty() || item.sub_category == sub_category));
    if (!cate_match) continue;

    if (news_index_->IsManualByDocId(item.doc_id)) {
      ++manual_filter_item;
      continue;
    }

    if (kCategoryFilteredItemtypeSet.find(item.item_type) != kCategoryFilteredItemtypeSet.end()) {
      ++itemtype_filter_item;
      continue;
    }

    // NOTE(suzhewen): 过滤源为本地频道的文章，待上线地域限制后再去掉
    channels.clear();
    bool has_local_channel = false;
    if (news_index_->GetChannelsByDocId(item.doc_id, &channels)) {
      for (size_t ch_idx = 0; ch_idx < channels.size(); ++ch_idx) {
        if (channels[ch_idx] == reco::common::kLocalChannelId) {
          has_local_channel = true;
          break;
        }
      }
    }

    if (has_local_channel) {
      ++channel_filter_item;
      continue;
    }

    std::vector<ItemInfo> *item_infos;
    std::unordered_set<uint64> *dedups;
    if (item.item_type == reco::kPureVideo) {
      item_infos = video_items;
      dedups = &dedup_video_items;
    } else {
      item_infos = items;
      dedups = &dedup_items;
    }

    if (!item.is_source_wemedia
        && item.new_pr == 0
        && item.itemq < reco::kJingpinItemq
        && dedups->find(item.item_id) != dedups->end()) {
      dedup_filtered_idx_vec.push_back(i);
      continue;
    }

    dedups->insert(item.item_id);
    const std::set<uint64>* sim_items = sim_item_->GetSimItemIds(item.item_id);
    if (sim_items != NULL) {
      for (auto it = sim_items->begin(); it != sim_items->end(); ++it) {
        dedups->insert(*it);
      }
    }
    item_infos->push_back(item);
  }

  int dedup_filter_item = dedup_filtered_idx_vec.size();
  if (!FLAGS_throw_dedup_item_in_index) {
    for (size_t i = 0; i < dedup_filtered_idx_vec.size(); ++i) {
      if ((int)items->size() >= max_save_num &&
          (int)video_items->size() >= max_save_num) break;
      int pos = dedup_filtered_idx_vec[i];
      if (all_items[pos].item_type == reco::kPureVideo) {
        if ((int)video_items->size() < max_save_num) {
          video_items->push_back(all_items[pos]);
          --dedup_filter_item;
        }
      } else {
        if ((int)items->size() < max_save_num) {
          items->push_back(all_items[pos]);
          --dedup_filter_item;
        }
      }
    }
  }

  LOG(INFO) << "category index update done"
            << ", category: [" << first_category << ", " << sub_category << "]"
            << ", qualified item num: " << items->size()
            << ", qualified video item num: " << video_items->size()
            << ", dedup filter item num: " << dedup_filter_item
            << ", manual filter item num: " << manual_filter_item
            << ", itemtype filter item num: " << itemtype_filter_item;
}

void SortItem::GetAllOperItems(std::vector<ItemInfo>* items, int max_save_num) {
  items->clear();
  items->reserve(max_save_num);
  int64 now_timestamp = base::GetTimestamp();
  int64 invalid_item = 0;
  int64 expired_item = 0;
  int64 meta_miss_item = 0;
  int predict_miss = 0;

  for (int docid = index_->MinDocLocalId(); docid < index_->MaxDocLocalId(); ++docid) {
    if ((int)items->size() >= max_save_num) break;
    // 已经按 docid 从小到大，即文档从新到旧排序
    if (!news_index_->IsValidByDocId(docid)) {
      ++invalid_item;
      continue;
    }
    if (news_index_->IsExpiredByDocId(docid, now_timestamp)) {
      ++expired_item;
      continue;
    }

    // 机器新闻跳过
    if (!news_index_->IsManualByDocId(docid)) {
      continue;
    }

    ItemInfo item;
    if (!news_index_->GetItemInfoByDocId(docid, &item, false)) {
      ++meta_miss_item;
      // continue;
    }

    item.index_score = CalcIndexScore(item, FLAGS_index_sort_use_predict_ctr, &predict_miss);
    items->push_back(item);
  }
  LOG(INFO) << "get all oper items, save item num: " << items->size()
            << ". invalid item num: " << invalid_item
            << ". meta miss item num: " << meta_miss_item
            << ". expire item num: " << expired_item
            << ". predict miss item num: " << predict_miss;
}

float SortItem::WilsonIntervalRatio(int numerator, int denominator) {
  if (numerator == 0 or denominator == 0) {
    return 0.0;
  }
  float n = static_cast<float>(denominator);
  float p = static_cast<float>(numerator) / static_cast<float>(denominator);
  p = std::max(p, 0.0f);
  p = std::min(p, 1.0f);
  float z = 1.96;
  float result_numerator = n * p + z * z / 2 - z * sqrt(n * p * (1 - p) + z * z / 4);
  float result_denominator = n + z * z;
  float result = result_numerator / result_denominator;
  result = std::max(result, 0.0f);
  result = std::min(result, 1.0f);
  return result;
}

int SortItem::GetItemIndex(uint64 item_id) const {
  auto iter = items_feature_.items_index.find(item_id);
  if (iter != items_feature_.items_index.end()) {
    return iter->second;
  }
  return -1;
}

const ItemFea& SortItem::GetItemFea(int index) const {
  return items_feature_.items_fea.at(index);
}


void SortItem::FillItemAttr(std::vector<ItemInfo>& all_items) {
  if (FLAGS_target_server == "video_server") return;
  for (size_t index = 0; index < all_items.size(); ++index) {
    news_index_->SetItemAttr(all_items[index].item_id, items_feature_);

    // wilson_ctr
    all_items[index].wilson_ctr = -1.0;
    if (all_items[index].show_num > 0) {
      all_items[index].wilson_ctr =
        WilsonIntervalRatio(all_items[index].click_num, all_items[index].show_num);
    }
  }
  return;
}

void SortItem::GetAllItems(std::vector<ItemInfo>* items, int max_save_num) {
  items->clear();
  items->reserve(max_save_num);

  int64 now_timestamp = base::GetTimestamp();
  int64 invalid_item = 0;
  int64 expired_item = 0;
  int64 meta_miss_item = 0;
  int64 bad_item_filter = 0;
  int64 unmatched_filter = 0;
  int64 stock_reco_filter = 0;
  int predict_miss = 0;
  for (int docid = index_->MinDocLocalId(); docid < index_->MaxDocLocalId(); ++docid) {
    // 已经按 docid 从小到大，即文档从新到旧排序
    if (!news_index_->IsValidByDocId(docid)) {
      ++invalid_item;
      continue;
    }

    if (news_index_->IsExpiredByDocId(docid, now_timestamp)) {
      ++expired_item;
      continue;
    }

    ItemInfo item;
    if (!news_index_->GetItemInfoByDocId(docid, &item, false)) {
      ++meta_miss_item;
      continue;
    }

    // 财经频道股票类规则过滤
    if (item.item_type <= reco::kPictureNews) {
      if (FinanceStockFilter(item)) {
        ++stock_reco_filter;
        continue;
      }
    }

    bool is_video_item = item.item_type == reco::kPureVideo || item.item_type == reco::kThemeVideo;
    if (FLAGS_target_server == "video_server") {
      // video server 只保留视频
      if (!is_video_item) {
        ++unmatched_filter;
        continue;
      }
    } else if (FLAGS_target_server == "leaf_server") {
      // 过滤掉机器新闻中的视频
      if (!news_index_->IsManualByDocId(docid)
          && item.category != "美女"
          && is_video_item) {
        ++unmatched_filter;
        continue;
      }
    }

    // 对于 new_pr 不为 0 的热门文章补召回
    if ((int)items->size() >= max_save_num && item.new_pr == 0) {
      continue;
    }

    if (item.item_type == reco::kTimeAxisPage) {
      ++invalid_item;
      continue;
    }

    if (item.category != "美女图片" && FilterBadItem(item)) {
      ++bad_item_filter;
      continue;
    }

    item.index_score = CalcIndexScore(item, FLAGS_index_sort_use_predict_ctr, &predict_miss);

    items->push_back(item);
  }

  LOG(INFO) << "get all items, save item num: " << items->size()
            << ". invalid item num: " << invalid_item
            << ". meta miss item num: " << meta_miss_item
            << ". expire item num: " << expired_item
            << ". unmatched item num: " << unmatched_filter
            << ". bad item filter num: " << bad_item_filter
            << ". stock reco filter: " << stock_reco_filter
            << ". predict miss item num: " << predict_miss;
}

void SortItem::GetKeyItems(const std::vector<ItemInfo>& all_items,
                              std::vector<ItemInfo>* key_items) const {
  // 获取 group 信息
  std::vector<reco::ItemGroupInfo> group_vec;
  group_vec.resize(all_items.size());
  for (size_t i = 0; i < all_items.size(); ++i) {
    const ItemInfo& item = all_items.at(i);
    ItemGroupInfo& group = group_vec.at(i);
    news_index_->GetGroupInfoByDocId(item.doc_id, &group);
  }

  int has_group_id = 0;
  int is_key_item = 0;

  // 获取 group 关联的 item 集合
  base::dense_hash_map<uint64, std::vector<int>> group_items;
  group_items.set_empty_key(0);
  for (size_t i = 0; i < all_items.size(); ++i) {
    const ItemInfo& item = all_items.at(i);
    if (news_index_->IsManualByDocId(item.doc_id)) {
      VLOG(1) << "is manual " << item.item_id;
      key_items->push_back(item);
      continue;
    }
    const ItemGroupInfo& group = group_vec.at(i);
    if (!group.has_group_id()) {
      key_items->push_back(item);
      VLOG(1) << "has no group id " << item.item_id;
      continue;
    }
    ++has_group_id;
    auto iter = group_items.find(group.group_id());
    if (iter == group_items.end()) {
      iter = group_items.insert(std::make_pair(group.group_id(),
                                               std::vector<int>())).first;
    }
    iter->second.push_back(i);
  }

  // 每个 group 选取核心 item
  for (auto iter = group_items.begin(); iter != group_items.end(); ++iter) {
    const std::vector<int>& idx_vec = iter->second;
    if (idx_vec.empty()) continue;
    int key_idx = idx_vec.at(0);
    bool key_item_exist = false;
    for (size_t i = 0; i < idx_vec.size(); ++i) {
      const reco::ItemGroupInfo& group = group_vec.at(idx_vec[i]);
      if (group.has_is_keyitem() && group.is_keyitem()) {
        key_idx = idx_vec[i];
        key_item_exist = true;
        break;
      }
    }
    if (key_item_exist) {
      is_key_item++;
    } else {
      VLOG(1) << "key item not exist group_id " << iter->first;
    }
    const ItemInfo& key_item = all_items.at(key_idx);
    key_items->push_back(key_item);
  }
  LOG(INFO) << "all items " << all_items.size()
    << " has_group_id " << has_group_id << " key_item_exist " << is_key_item;
}

void SortItem::UpdateYoukuIdDict(const std::vector<ItemInfo>& all_items) {
  if (FLAGS_target_server != "video_server") return;

  auto youku_video_id_dict = youku_video_id_dict_.GetInactiveDict();
  youku_video_id_dict->clear();

  uint64 youku_video_id;
  uint64 total_video_num = 0;
  uint64 miss_vid_video_num = 0;
  uint64 uc_storage_num = 0;
  for (int i = 0; i < (int)all_items.size(); ++i) {
    const ItemInfo& item = all_items[i];
    if (item.item_type != reco::kPureVideo) continue;
    ++total_video_num;
    VLOG(2) << "video item\t" << item.item_id << "\t" << item.show_num << "\t" << item.click_num;

    if (item.is_source_wemedia || news_index_->HasVideoStorageInfoByItemId(item.item_id)) {
      ++uc_storage_num;
      VLOG(2) << "have uc storage item\t" << item.item_id;
    }

    if (!news_index_->GetYoukuVideoIdByDocId(item.doc_id, &youku_video_id)) {
      VLOG(2) << "miss vid item\t" << item.item_id;
      ++miss_vid_video_num;
      continue;
    }
    VLOG(2) << "have vid item\t" << item.item_id << "\t" << youku_video_id;
    (*youku_video_id_dict)[youku_video_id] = item.item_id;
  }
  double lack_ratio = static_cast<double>(miss_vid_video_num) / (total_video_num + 1);
  COUNTERS_reco_index__vid_lack_ratio.Reset(lack_ratio);
  LOG(INFO) << "update youku id dict success, vid_dict_size: " << youku_video_id_dict->size()
            << ", total_video_num: " << total_video_num
            << ", miss_vid_video_num: " << miss_vid_video_num
            << ", uc_storage_num: " << uc_storage_num;
  youku_video_id_dict_.SwitchDict();
}

void SortItem::UpdateItemToSubjectDict(const std::vector<ItemInfo>& subject_items) {
  if (FLAGS_target_server != "video_server") return;

  auto item_to_subject_dict = item_to_subject_dict_.GetInactiveDict();
  item_to_subject_dict->clear();

  static const int kMaxSubItemNum = 30;
  static const int kMinSubjectViewNum = 1000;
  static const float kMinSubjectCtr = 0.01;
  static const float kMinSubjectWilsonCtr = 0.03;

  int filter_by_view_num = 0;
  int filter_by_ctr = 0;
  int non_sub_item = 0;
  for (int i = 0; i < (int)subject_items.size(); ++i) {
    const ItemInfo& item = subject_items[i];
    if (item.show_num < kMinSubjectViewNum) {
      ++filter_by_view_num;
      continue;
    }
    if (item.ctr < kMinSubjectCtr && item.wilson_ctr < kMinSubjectWilsonCtr) {
      ++filter_by_ctr;
      continue;
    }
    reco::SubjectSubItems subject_sub_items;
    if (!news_index_->GetSubjectSubItemByItemId(item.item_id, &subject_sub_items)) {
      ++non_sub_item;
      continue;
    }
    for (int j = 0; j < subject_sub_items.sub_items_size() && j < kMaxSubItemNum; ++j) {
      const SubjectSubItem& sub_item = subject_sub_items.sub_items(j);
      if (!sub_item.has_item_id()) continue;
      (*item_to_subject_dict)[sub_item.item_id()] = item.item_id;
    }
  }
  LOG(INFO) << "update item to subject dict success, item_to_subject_dict_size: "
            << item_to_subject_dict->size()
            << ", total_subject_num: " << subject_items.size()
            << ", filter_by_view_num: " << filter_by_view_num
            << ", filter_by_ctr: " << filter_by_ctr
            << ", non_sub_item: " << non_sub_item;
  item_to_subject_dict_.SwitchDict();
}

void SortItem::UpdateSubjectVideoTagFeatureDict(const std::vector<ItemInfo>& subject_items) {
  if (FLAGS_target_server != "video_server") return;

  auto subject_video_tag_feature_dict = subject_video_tag_feature_dict_.GetInactiveDict();
  subject_video_tag_feature_dict->clear();

  for (int i = 0; i < (int)subject_items.size(); ++i) {
    const ItemInfo& item = subject_items[i];
    reco::FeatureVector fevtag;
    if (news_index_->GetVideoTagFeatureVectorByItemId(item.item_id, &fevtag)) {
      (*subject_video_tag_feature_dict)[item.item_id] = fevtag;
    }
  }
  LOG(INFO) << "update subject video tag feature dict success, subject_video_tag_feature_dict_size: "
            << subject_video_tag_feature_dict->size()
            << ", total_subject_num: " << subject_items.size();
  subject_video_tag_feature_dict_.SwitchDict();
}

void SortItem::UpdateTimeAxisDict() {
  if (!FLAGS_open_time_axis_switch) return;

  auto timeaxis_dict = timeaxis_dict_.GetInactiveDict();
  timeaxis_dict->clear();
  auto timeaxis_latest_news_dict = timeaxis_latest_news_dict_.GetInactiveDict();
  timeaxis_latest_news_dict->clear();

  std::vector<int32> doc_id_list;
  news_index_->GetDocsByItemType(reco::kTimeAxisPage, &doc_id_list);
  if (doc_id_list.empty()) {
    VLOG(1) << "get no time axis item";
    return;
  }

  int64 now_timestamp = base::GetTimestamp();
  uint64 item_id;
  for (size_t k = 0; k < doc_id_list.size(); ++k) {
    int32 doc_id = doc_id_list[k];
    if (!news_index_->GetItemIdByDocId(doc_id, &item_id)) {
      VLOG(1) << "get item id from doc_id fail: " << doc_id;
      continue;
    }
    if (!news_index_->IsValidByDocId(doc_id)) {
      VLOG(1) << "doc not valid: " << item_id;
      continue;
    }
    if (news_index_->IsExpiredByDocId(doc_id, now_timestamp)) {
      VLOG(1) << "doc expired: " << item_id;
      continue;
    }

    reco::time_axis::TimeAxisResults time_axis_results;
    if (!news_index_->GetTimeAxisResultsByDocId(doc_id, &time_axis_results)) {
      VLOG(1) << "get time axis result fail: " << item_id;
      continue;
    }
    auto &name = time_axis_results.raw_req().event_name();
    // auto id = time_axis_results.raw_req().time_axis_id();

    reco::time_axis::TimeAxisInfo timeaxis_info;
    timeaxis_info.set_id(item_id);
    timeaxis_info.set_name(name);

    for (int i = 0; i < time_axis_results.nodes_size(); ++i) {
      auto &node = time_axis_results.nodes(i);
      uint64 master_item_id = node.master_item().item_id();
      // 加入主节点
      timeaxis_dict->insert(std::make_pair(master_item_id, timeaxis_info));

      // 加入转载节点
      for (int j = 0; j < node.slave_items_size(); ++j) {
        uint64 slave_item_id = node.slave_items(j).item_id();
        timeaxis_dict->insert(std::make_pair(slave_item_id, timeaxis_info));
      }

      // 加入最新进展结果
      if (i == 0) {
        timeaxis_latest_news_dict->insert(std::make_pair(name,
               std::make_pair(master_item_id, timeaxis_info)));
        VLOG(1) << "time_axis_name:" << name << ", first master result:" << master_item_id;
      }
    }
    VLOG(1) << "get time axis info success: " << item_id << '\t'
            << nlp::util::NormalizeLine(time_axis_results.Utf8DebugString());
  }
  LOG(INFO) << "update item time axis info success: " << doc_id_list.size()
            << ", " << timeaxis_dict->size()
            << ", timeaxis_latest_news_dict:" << timeaxis_latest_news_dict->size();
  timeaxis_dict_.SwitchDict();
  if (timeaxis_latest_news_dict->size() > 0) {
    timeaxis_latest_news_dict_.SwitchDict();
  }
}

void SortItem::SortZZDItems(const std::vector<ItemInfo>& all_items,
                            NewsQueue* queue,
                            std::vector<ItemInfo>* youku_show_items_ptr) {
  std::vector<ItemInfo>* items = queue->MutableIndex();
  items->clear();
  items->reserve(all_items.size());
  youku_show_items_ptr->clear();

  int64 filtered_by_itemtype = 0;
  int64 filtered_by_producer = 0;
  int64 filtered_by_itemq = 0;
  int64 filtered_by_yuanchuang = 0;
  for (int i = 0; i < (int)all_items.size(); ++i) {
    const ItemInfo& item = all_items[i];
    if (item.item_type == reco::kHumor
        || item.item_type == reco::kSpecial
        || item.item_type == reco::kNovel) {
      ++filtered_by_itemtype;
      VLOG(3) << "filter humor:" << item.item_id;
      continue;
    }
    if (news_index_->IsManualByDocId(item.doc_id)) {
      ++filtered_by_producer;
      VLOG(3) << "filter manual:" << item.item_id;
      continue;
    }
    if (!FLAGS_index_test_env && item.item_type != reco::kPureVideo) {
      int64 crawl_timestamp = news_index_->GetCrawlTimestampByDocId(item.doc_id);
      int64 create_timestamp = news_index_->GetCreateTimestampByDocId(item.doc_id);
      base::TimeDelta delta = base::TimeDelta::FromMicroseconds(crawl_timestamp - create_timestamp);
      if (delta.InDays() > 3 || delta.InDays() < -3) {
        ++filtered_by_itemq;
        VLOG(3) << "DEBUG, time filter, " << item.item_id << ", " << delta.InDays();
        continue;
      }
    }
    if (!FLAGS_index_test_env
        && item.item_type != reco::kPureVideo
        && item.time_level == reco::kBadTimeliness
        && (item.show_num < 100 || item.ctr < 0.008)) {
      ++filtered_by_itemq;
      VLOG(3) << "filter video:" << item.item_id;
      continue;
    }
    if (item.itemq < reco::kJingpinItemq
        && item.new_pr <= 0
        && filtered_items_.find(item.item_id) != filtered_items_.end()
        && !news_index_->IsYuanchuangDocId(item.doc_id)) {
      ++filtered_by_yuanchuang;
      VLOG(3) << "filter yuanchuang:" << item.item_id;
      continue;
    }

    if (IsYoukuShowItem(item)) {
      youku_show_items_ptr->push_back(item);
      VLOG(3) << "push youku queue:" << item.item_id;
    } else {
      items->push_back(item);
      VLOG(3) << "zzd index:" << item.item_id;
    }
  }
  std::sort(items->begin(), items->end(), NewsItemSortFunc);
  int group_filter = 0;
  // if (FLAGS_target_server == "leaf_server") {
    std::vector<ItemInfo> swap_items;
    GetKeyItems(*items, &swap_items);
    group_filter = items->size() - swap_items.size();
    items->swap(swap_items);
    std::sort(items->begin(), items->end(), NewsItemSortFunc);
  // }

  // PrintItems(*items);

  queue->today_news_num = GetTodayNewsNum(*items);

  LOG(INFO) << "zzd index update done. all items: "  << all_items.size()
            << ", filtered by itemtype: " << filtered_by_itemtype
            << ", filtered by producer: " << filtered_by_producer
            << ", filtered by yuanchuang, " << filtered_by_yuanchuang
            << ", filtered by itemq, " << filtered_by_itemq
            << ", group filter, " << group_filter
            << ", remain items: " << items->size()
            << ", today items: " << queue->today_news_num
            << ", youku show items: " << youku_show_items_ptr->size();
}

void SortItem::SortUCBItems(const std::vector<ItemInfo>& all_items, NewsQueue* queue, NewsQueue* hot_queue) {
  std::vector<ItemInfo>* items = queue->MutableIndex();
  std::vector<ItemInfo>* hot_items = hot_queue->MutableIndex();
  items->clear();

  base::Time curr_time = base::Time::Now();
  std::string str_curr_time;
  curr_time.ToStringInSeconds(&str_curr_time);

  auto ucb_setting_dict = item_ucb_setting_dict_.GetInactiveDict();
  ucb_setting_dict->clear();

  int64 producer_filtered_item = 0;
  int64 publish_filtered_item = 0;
  int64 quantity_filtered_item = 0;
  int64 ineffective_filtered_item = 0;
  UcBrowserDeliverSetting ucb_setting;
  std::vector<std::pair<int, const ItemInfo*> > sort_items;
  std::vector<int64> channel_ids;
  for (int i = 0; i < (int)all_items.size(); ++i) {
    const ItemInfo& item = all_items[i];
    // 过滤所有机器新闻
    if (!news_index_->IsManualByDocId(item.doc_id)) {
      ++producer_filtered_item;
      continue;
    }
    if (!news_index_->GetUCBSettingByItemId(item.item_id, &ucb_setting)) {
      LOG(WARNING) << "item has no ucb setting, " << item.item_id;
      continue;
    }

    base::Time item_time =
        base::Time::FromDoubleT(item.create_timestamp / base::Time::kMicrosecondsPerSecond);
    // 未发布过滤
    if (ucb_setting.has_is_published() && !ucb_setting.is_published()) {
      ++publish_filtered_item;
      continue;
    }
    // 不在生效时间内过滤
    if ((ucb_setting.has_start_time() && ucb_setting.start_time() > str_curr_time)
        || (ucb_setting.has_end_time() && ucb_setting.end_time() < str_curr_time)) {
      ++ineffective_filtered_item;
      continue;
    }
    // 过滤不用下发的新闻
    if (ucb_setting.has_quantity() && ucb_setting.quantity() == 0) {
      ++quantity_filtered_item;
      continue;
    }

    // 使用 start_time 作为真实的 item time
    if (ucb_setting.has_start_time() &&
        !base::Time::FromStringInSeconds(ucb_setting.start_time().c_str(), &item_time)) {
      LOG(WARNING) << "ucb setting start format error, " << item.item_id;
      continue;
    }
    // 粗排得分计算
    channel_ids.clear();
    bool hit_reco_channel = false;
    if (news_index_->GetChannelsByDocId(item.doc_id, &channel_ids)) {
      for (size_t k = 0; k < channel_ids.size(); ++k) {
        if (channel_ids[k] == 100) {
          hit_reco_channel = true;
          break;
        }
      }
    }
    int score  = -1 * std::min(24 * 30, std::max((curr_time - item_time).InHours(), 0));
    if (ucb_setting.is_banner()) {
      score += std::numeric_limits<int>::max() / 10;

    } else if (ucb_setting.has_importance()
               && ucb_setting.importance() == 1) {
      score += std::numeric_limits<int>::max() / 100;

    } else if (ucb_setting.has_oper_src_area()
               && ucb_setting.oper_src_area() == reco::kWholeDeliver) {
      if (ucb_setting.tag_size() == 0) {
        score += std::numeric_limits<int>::max() / 200;
      } else {
        score += std::numeric_limits<int>::max() / 500;
      }
    }
    if (hit_reco_channel) {
      score += std::numeric_limits<int>::max() / 500;
    }
    if (item.item_type == reco::kSpecial) {
      score += std::numeric_limits<int>::max() / 1000;
    }

    ucb_setting_dict->insert(std::make_pair(item.item_id, ucb_setting));
    if (item.item_type == reco::kSpecial) {
      VLOG(1) << "item_id:" << item.item_id << ", type kSpecial";
    }
    sort_items.push_back(std::make_pair(score, &item));
  }

  std::sort(sort_items.begin(), sort_items.end(), UCBItemSortFunc);

  for (int i = 0; i < (int)sort_items.size(); ++i) {
    const ItemInfo& item = *(sort_items[i].second);
    if (item.item_type != reco::kHotCard) {
      items->push_back(item);
    } else {
      hot_items->push_back(item);
    }
  }
  queue->today_news_num = GetTodayNewsNum(*items);

  item_ucb_setting_dict_.SwitchDict();

  LOG(INFO) << "ucb index update done. all items: "  << all_items.size()
            << ", producer filtered items: " << producer_filtered_item
            << ", publish filtered items: " << publish_filtered_item
            << ", quantity filtered items: " << quantity_filtered_item
            << ", ineffective filtered items: " << ineffective_filtered_item
            << ", remain items: " << items->size();
  COUNTERS_reco_index__manual_item_num.Reset(items->size());
}

void SortItem::SortHumorItems(const std::vector<ItemInfo>& all_items,
                              CategoryMap* category_index, int max_save_num) {
  if (FLAGS_target_server == "video_server") return;

  std::vector<ItemInfo> items(max_save_num);
  items.reserve(max_save_num);
  int64 filtered_item = 0;
  items.clear();
  for (int i = 0; i < (int)all_items.size(); ++i) {
    if ((int)items.size() >= max_save_num) break;
    const ItemInfo& item_info = all_items[i];
    if (item_info.item_type != reco::kHumor) {
      ++filtered_item;
      continue;
    }
    items.push_back(item_info);
  }
  NormalizeSpiderScore(&items);
  std::sort(items.begin(), items.end(), HumorItemSortFunc);

  std::vector<ItemInfo> word_items;
  std::vector<ItemInfo> picture_items;
  std::vector<ItemInfo> toutiao_humor_items;

  std::vector<int64> channel_ids;
  std::unordered_set<int64> channel_ids_set;
  for (int i = 0; i < (int)items.size(); ++i) {
    channel_ids.clear();
    channel_ids_set.clear();
    // 头条搞笑频道
    if (news_index_->GetChannelsByDocId(items[i].doc_id, &channel_ids)) {
      for (size_t idx = 0; idx < channel_ids.size(); ++idx) {
        channel_ids_set.insert(channel_ids[idx]);
        if (channel_ids[idx] == reco::common::kHumorWordTouTiaoChannelId) {
          toutiao_humor_items.push_back(items[i]);
        }
      }
    }

    int img_cnt = news_index_->GetImageCountByItemId(items[i].item_id);
    if (img_cnt == 0) {
      // 段子频道
      word_items.push_back(items[i]);
    } else {
      // 趣图频道
      std::string content;
      news_index_->GetItemContentByItemId(items[i].item_id, &content);
      int char_num = 0;
      if (base::GetUTF8CharNum(content, &char_num)
          && char_num < 20
          && channel_ids_set.count(reco::common::kHumorPicChannelId) > 0) {
        std::string source;
        if (news_index_->GetSourceByItemId(items[i].item_id, &source)) {
          if ((source.find("奇趣百科_") == 0
               || source.find("UC搞笑_") == 0
               || source == "奇趣百科长文_漫画")
              && source != "奇趣百科_秘密") {
            picture_items.push_back(items[i]);
          }
        }
      }
    }
  }

  reco::Category word_category, picture_category, toutiao_humor_category;

  std::vector<std::string> categories;
  categories.push_back("幽默");
  categories.push_back("段子");
  news_index_->ConvertToCategoryProto(categories, 1, &word_category);

  categories.clear();
  categories.push_back("幽默");
  categories.push_back("趣图");
  news_index_->ConvertToCategoryProto(categories, 1, &picture_category);

  categories.clear();
  categories.push_back("幽默");
  categories.push_back("头条搞笑");
  news_index_->ConvertToCategoryProto(categories, 1, &toutiao_humor_category);

  NewsQueue& word_queue = (*category_index)[reco::common::WrappedCategory(word_category)];
  word_queue.MutableIndex()->swap(word_items);
  word_queue.today_news_num = GetTodayNewsNum(*word_queue.GetIndex());
  word_queue.MutableTimelyIndex()->assign(word_queue.GetIndex()->begin(), word_queue.GetIndex()->end());
  std::sort(word_queue.MutableTimelyIndex()->begin(), word_queue.MutableTimelyIndex()->end(),
            NewsItemTimeSortFunc);
  LOG(INFO) << base::StringPrintf("sort category [%s], default docs [%d], timely docs [%d], today news [%d]",
                                  reco::common::WrappedCategory(word_category).ToString().c_str(),
                                  (int)word_queue.GetIndex()->size(),
                                  (int)word_queue.GetTimelyIndex()->size(),
                                  word_queue.today_news_num);

  NewsQueue& picture_queue = (*category_index)[reco::common::WrappedCategory(picture_category)];
  picture_queue.MutableIndex()->swap(picture_items);
  picture_queue.MutableTimelyIndex()->assign(picture_queue.GetIndex()->begin(),
                                             picture_queue.GetIndex()->end());
  picture_queue.today_news_num = GetTodayNewsNum(*picture_queue.GetIndex());
  std::sort(picture_queue.MutableTimelyIndex()->begin(), picture_queue.MutableTimelyIndex()->end(),
            NewsItemTimeSortFunc);
  LOG(INFO) << base::StringPrintf("sort category [%s], default docs [%d], timely docs [%d], today news [%d]",
                                  reco::common::WrappedCategory(picture_category).ToString().c_str(),
                                  (int)picture_queue.GetIndex()->size(),
                                  (int)picture_queue.GetTimelyIndex()->size(),
                                  picture_queue.today_news_num);

  NewsQueue& toutiao_humor_queue = (*category_index)[reco::common::WrappedCategory(toutiao_humor_category)];
  toutiao_humor_queue.MutableIndex()->swap(toutiao_humor_items);
  toutiao_humor_queue.MutableTimelyIndex()->assign(toutiao_humor_queue.GetIndex()->begin(),
                                                   toutiao_humor_queue.GetIndex()->end());
  toutiao_humor_queue.today_news_num = GetTodayNewsNum(*toutiao_humor_queue.GetIndex());
  std::sort(toutiao_humor_queue.MutableTimelyIndex()->begin(),
            toutiao_humor_queue.MutableTimelyIndex()->end(),
            NewsItemTimeSortFunc);
  LOG(INFO) << base::StringPrintf("sort category [%s], default docs [%d], timely docs [%d], today news [%d]",
                                  reco::common::WrappedCategory(toutiao_humor_category).ToString().c_str(),
                                  (int)toutiao_humor_queue.GetIndex()->size(),
                                  (int)toutiao_humor_queue.GetTimelyIndex()->size(),
                                  toutiao_humor_queue.today_news_num);

  LOG(INFO) << "humor index update done. "
            << ". qualified item num: " << items.size()
            << ". filtered item num: " << filtered_item;
}


void SortItem::SortSpecialItems(const std::vector<ItemInfo>& all_items,
                                ChannelMap* channel_index, int max_save_num) {
  if (FLAGS_target_server == "video_server") return;

  NewsQueue& queue = (*channel_index)[reco::common::kSpecialChannelId];
  std::vector<ItemInfo>* items = queue.MutableIndex();

  items->clear();
  items->reserve(max_save_num);
  int64 filtered_item = 0;
  items->clear();
  std::string producer;
  for (int i = 0; i < (int)all_items.size(); ++i) {
    if ((int)items->size() >= max_save_num) break;
    const ItemInfo& item = all_items[i];
    if (item.item_type != reco::kSpecial) {
      ++filtered_item;
      continue;
    }
    if (!news_index_->GetProducerByDocId(item.doc_id, &producer)
        || (producer != reco::common::kZZDProducer && producer != reco::common::kZZDOpProducer)) {
      ++filtered_item;
      continue;
    }
    items->push_back(item);
  }

  std::sort(items->begin(), items->end(), NewsItemTimeSortFunc);

  queue.today_news_num = GetTodayNewsNum(*items);

  LOG(INFO) << "special index update done. "
            << ". qualified item num: " << items->size()
            << ". today item num: " << queue.today_news_num
            << ". filtered item num: " << filtered_item;
}

bool SortItem::AddToRegionQueue(const ItemInfo& item, ChannelMap* region_index, ChannelMap* poi_index) {
  std::vector<int64> region_ids;
  if (!news_index_->GetRegionIdByDocId(item.doc_id, &region_ids)) {
    VLOG(1) << "get region id by doc id fail, item_id: " << item.item_id;
    return false;
  }

  static const std::unordered_set<int64> kPOIRegionIds = {10, 20, 28, 571, 21, 755};
  bool add_to_poi_queue = false;
  for (size_t k = 0; k < region_ids.size(); ++k) {
    NewsQueue& region_queue = (*region_index)[region_ids[k]];
    if ((int)region_queue.GetIndex()->size() < kMaxSavePerCate) {
      region_queue.MutableIndex()->push_back(item);
    }
    if (kPOIRegionIds.find(region_ids[k]) != kPOIRegionIds.end()) {
      add_to_poi_queue = true;
    }
  }
  if (FLAGS_open_poi_queue_switch && add_to_poi_queue) {
    AddToPOIQueue(item, poi_index);
  }
  return true;
}

void SortItem::AddToPOIQueue(const ItemInfo &item, ChannelMap *poi_index) {
  GaoDePOI gaode_poi;
  if (!news_index_->GetGaoDePOIByDocId(item.doc_id, &gaode_poi)) {
    VLOG(2) << "get GaoDe POI by doc_id fail, item_id: " << item.item_id;
    return;
  }
  VLOG(1) << "get GaoDe POI by doc_id, item_id: " << item.item_id
          << ", " << nlp::util::NormalizeLine(gaode_poi.Utf8DebugString());

  std::unordered_set<int64> area_ids;
  reco::poi::CityAreaHashSearcher::instance().GetItemAreaID(gaode_poi, &area_ids);
  for (auto iter = area_ids.begin(); iter != area_ids.end(); ++iter) {
    NewsQueue &poi_queue = (*poi_index)[*iter];
    if ((int)poi_queue.GetIndex()->size() < kMaxSavePerCate) {
      poi_queue.MutableIndex()->push_back(item);
      VLOG(1) << "add to poi index: " << item.item_id << "\t" << *iter
              << '\t' << item.hot_level << '\t' << item.ctr;
    }
  }
}

void SortItem::UpdateLocalBreakingItems(const ChannelMap* region_index) {
  auto local_breaking_index = local_breaking_index_.GetInactiveDict();
  local_breaking_index->clear();
  auto item_breaking_dict = item_breaking_dict_.GetInactiveDict();
  item_breaking_dict->clear();

  std::unordered_set<uint64> processed_items;
  std::unordered_map<uint64, reco::LocalBreaking> all_item_breaking;

  std::unordered_set<uint64> deduped;

  for (auto rg_it = region_index->begin(); rg_it != region_index->end(); ++rg_it) {
    int64 region_id = rg_it->first;
    const std::vector<ItemInfo>* items = rg_it->second.GetIndex();
    std::unordered_map<uint64, std::vector<ItemInfo> > event_items;

    for (auto idx_it = items->begin(); idx_it != items->end(); ++idx_it) {
      const ItemInfo& item = *idx_it;
      // 没处理过
      if (processed_items.find(item.item_id) == processed_items.end()) {
        // 是否有突发事件属性
        reco::LocalBreaking local_breaking;
        if (!news_index_->GetLocalBreakingByDocId(item.doc_id, &local_breaking)) {
          VLOG(1) << "get local breaking by doc id fail, item id: " << item.item_id;
        } else if (local_breaking.breaking_infos_size() == 0) {
          VLOG(1) << "local breaking empty, item id: " << item.item_id;
        } else {
          // 是本地突发事件
          all_item_breaking.insert(std::make_pair(item.item_id, local_breaking));
        }
        processed_items.insert(item.item_id);
      }

      // 没有突发事件属性
      auto breaking_it = all_item_breaking.find(item.item_id);
      if (breaking_it == all_item_breaking.end()) {
        continue;
      }

      std::string str_region_id = reco::common::RegionDict::GetStrRegionCodeByIntCode(region_id);

      // 遍历每一个事件属性(分地域), 将本地域的事件记录下来
      for (int i = 0; i < breaking_it->second.breaking_infos_size(); ++i) {
        auto breaking_info = breaking_it->second.breaking_infos(i);
        // 非本地域，跳过
        if (!breaking_info.has_region() || breaking_info.region() != str_region_id) {
          continue;
        }

        // 将 item 写到对应事件 map
        auto event_it = event_items.find(breaking_info.event_id());
        std::vector<ItemInfo>* tmp_result;
        if (event_it == event_items.end()) {
          tmp_result = &(event_items.insert(std::make_pair(breaking_info.event_id(),
                                                           std::vector<ItemInfo>())).first->second);
        } else {
          tmp_result = &(event_it->second);
        }
        tmp_result->push_back(item);
      }
    }
    // 本地没有突发事件
    if (event_items.size() == 0) {
      LOG(INFO) << "no local breaking events at region, " << region_id;
      continue;
    }

    // 过滤掉无效事件
    std::unordered_set<uint64> valid_events;
    for (auto e_it = event_items.begin(); e_it != event_items.end(); ++e_it) {
      VLOG(1) << "processing event, " << e_it->first;
      bool expired = false;
      for (size_t i = 0; i < e_it->second.size(); ++i) {
        uint64 item_id = e_it->second[i].item_id;
        auto breaking_it = all_item_breaking.find(item_id);
        if (breaking_it == all_item_breaking.end()) {
          continue;
        }
        if (breaking_it->second.breaking_infos_size() == 0) {
          continue;
        }
        base::Time stop_time;
        base::Time::FromStringInSeconds(breaking_it->second.breaking_infos(0).stop_time().c_str(),
                                        &stop_time);
        if (base::Time::Now() >= stop_time) {
          expired = true;
          break;
        }
      }
      if (!expired) {
        valid_events.insert(e_it->first);
      } else {
        VLOG(1) << "event expired " << e_it->first;
      }
    }

    // 将有效事件的所有 item 写入索引，更新 item 对应突发属性词典
    NewsQueue& breaking_queue = (*local_breaking_index)[region_id];
    for (auto it = valid_events.begin(); it != valid_events.end(); ++it) {
      auto e_it = event_items.find(*it);
      if (e_it == event_items.end()) {
        continue;
      }
      for (size_t i = 0; i < e_it->second.size(); ++i) {
        auto item = e_it->second[i];
        auto breaking_it = all_item_breaking.find(item.item_id);
        if (breaking_it == all_item_breaking.end()) {
          continue;
        }
        if (deduped.find(item.item_id) == deduped.end()) {
          // TODO(xx): fix kMaxSavePerCate
          if ((int)breaking_queue.GetIndex()->size() < kMaxSavePerCate) {
            breaking_queue.MutableIndex()->push_back(item);
            item_breaking_dict->insert(std::make_pair(item.item_id, breaking_it->second));
            VLOG(1) << "insert item " << item.item_id << " to event " << *it
                    << " called " << breaking_it->second.breaking_infos(0).event_literal()
                    << " reliability " << breaking_it->second.breaking_infos(0).reliability();
          }
          deduped.insert(item.item_id);
        }
      }
    }
    LOG(INFO) << "region: " << region_id << " event size " << breaking_queue.GetIndex()->size();
  }

  local_breaking_index_.SwitchDict();
  item_breaking_dict_.SwitchDict();
}

void SortItem::AddToVideoQueue(const ItemInfo& item,
                               NewsQueue* video_queue,
                               int max_size,
                               float ctr_thr) {
  if (item.ctr < ctr_thr) return;

  // 如果已经入过队了，不再重复入队
  if (!video_queue->GetIndex()->empty() &&
      video_queue->GetIndex()->back().item_id == item.item_id) {
    return;
  }

  if ((int)video_queue->GetIndex()->size() < max_size) {
    video_queue->MutableIndex()->push_back(item);
  }
}

bool SortItem::FilterVideoItem(const ItemInfo& item) {
  // 过滤非视频的内容
  if (item.item_type != kPureVideo) return true;

  // 过滤长度超过 30 分钟的视频
  static const int kMaxVideoLength = 60 * 30;
  const int video_length = news_index_->GetTotalVideoLengthByDocId(item.doc_id);
  if (video_length > kMaxVideoLength) {
    VLOG(1) << "this video is too long: " << item.item_id;
    return true;
  }

  // NOTE(zhuzekun): 一定要加上 > 0 因为如果获取不到视频长度，默认是 0
  if (video_length > 0 && video_length <= 5) {
    VLOG(1) << "video length too short: " << item.item_id;
    return true;
  }

  // 如果疑似低质的视频展现比较充分了，但是 ctr 还是很低，就不再入队
  if (item.show_num > 150 &&
      item.ctr < FLAGS_suspect_rubbish_video_ctr_thr &&
      news_index_->GetVideoQualityLevelByDocId(item.doc_id) == VideoAttr::kSuspectRubbish) {
    VLOG(1) << "filtered by rubbish video with low ctr: " << item.item_id
            << "\t" << item.show_num << "\t" << item.ctr;
    return true;
  }
  return false;
}

bool SortItem::FilterUgcVideoItem(int64 channel_id, const ItemInfo& item) {
  auto dy_dict = DM_GET_DICT(reco::filter::UgcWhiteSourceDict,
            reco::filter::DynamicDictContainer::kUgcWhiteSourceFile);
  if (dy_dict == NULL || !dy_dict.get()) {
    LOG(ERROR) << "UgcWhiteSourceDict is NULL";
    return false;
  }

  std::string key = base::StringPrintf("%d_%ld", reco::common::kTuDouIflow,
      channel_id);

  auto& dict = dy_dict->dict;
  if (dict.empty()) {
    return false;
  }

  auto iter = dict.find(key);
  if (iter == dict.end()) {
    return false;
  }

  std::string source;
  if (!news_index_->GetSourceByItemId(item.item_id, &source)) {
    return false;
  }

  if (iter->second.find(source) == iter->second.end()) {
    return true;
  }

  return false;
}

void SortItem::PrintFilterDebug(const ItemInfo& item, const std::string& reason) {
  if (!FLAGS_open_debug_filter_bad_item) return;
  reco::ContentAttr content_attr;
  bool is_trival;
  int erro_title = -1;
  int advertorial = -1;
  int short_content = -1;
  int dedup_paragraph = -1;
  int dirty = -1;
  int politics = -1;
  int bluffing_title = -1;
  news_index_->GetContentAttrByDocId(item.doc_id, &content_attr, &is_trival);
  if (content_attr.has_erro_title()) erro_title = content_attr.erro_title();
  if (content_attr.has_advertorial()) advertorial = content_attr.advertorial();
  if (content_attr.has_short_content()) short_content = content_attr.short_content();
  if (content_attr.has_dedup_paragraph()) dedup_paragraph = content_attr.dedup_paragraph();
  if (content_attr.has_dirty()) dirty = content_attr.dirty();
  if (content_attr.has_politics()) politics = content_attr.politics();
  if (content_attr.has_bluffing_title()) bluffing_title = content_attr.bluffing_title();
  std::string title;
  std::string source;
  std::string source_media;
  news_index_->GetItemTitleByItemId(item.item_id, &title);
  news_index_->GetSourceByItemId(item.item_id, &source);
  news_index_->GetSourceMediaByItemId(item.item_id, &source_media);
  LOG(INFO) << "dizhidebug:\t" << item.item_id << "\t"
            << "reason\t" << reason << "\t"
            << title << "\t"
            << source << "\t"
            << source_media << "\t"
            << "\tshow\t" << item.show_num
            << "\tclick\t" << item.click_num
            << "\tctr\t" << item.ctr
            << "\tavg_duration\t" << item.duration
            << "\titemq\t" << item.itemq
            << "\tcategory\t" << item.category
            << "\tmedia_level\t" << item.media_level
            << "\tsite_level\t" << item.site_level
            << "\terro_title\t" << erro_title
            << "\tadvertorial\t" << advertorial
            << "\tshort_content\t" << short_content
            << "\tdedup_paragraph\t" << dedup_paragraph
            << "\tdirty\t" << dirty
            << "\tpolitics\t" << politics
            << "\tbluffing_title\t" << bluffing_title;
}

// 过滤最差的一批低质 item
bool SortItem::FilterBadItem(const ItemInfo& item) {
  if (FLAGS_index_test_env) return false;
  // 视频不做过滤
  if (item.item_type == reco::kPureVideo || item.item_type == reco::kThemeVideo) return false;

  // 运营豁免
  if (news_index_->IsManualByDocId(item.doc_id)) {
    return false;
  }
  int32 orgi_itemq = -1;
  if (!news_index_->GetOrgiItemQByItemId(item.item_id, &orgi_itemq)) {
    orgi_itemq = -1;
  }
  if (FLAGS_dizhi_filter_wemedia && item.is_source_wemedia) {
    if (item.media_level == reco::MediaLevel::kBadMedia
        && item.site_level == reco::SiteLevel::kBadQualitySite
        && item.itemq < reco::kNormalItemq) {
      // PrintFilterDebug(item, "shuangzuidi && zimeiti");
      return true;
    } else if (item.media_level <= reco::MediaLevel::kLowMedia
               && item.site_level <= reco::SiteLevel::kMidQualitySite
               && orgi_itemq > -1
               && orgi_itemq <= FLAGS_dizhi_low_new_itemq_thresh) {
      // PrintFilterDebug(item, "shuangzhongdi && zimeiti && low itemq");
      return true;
    }
  }

  // 股票 类过滤垃圾内容
  if (item.category == "财经" && item.sub_category == "股票") {
    if (item.is_source_wemedia
        && item.media_level <= reco::kNormalMedia
        && item.hot_level < 10) {
      return true;
    }
    if (!item.is_source_wemedia
        && item.media_level <= reco::kLowMedia
        && item.hot_level < 10) {
      return true;
    }
    if (item.hot_level < 20
        && item.media_level != reco::kSuperMedia
        && news_index_->GetImageCountByDocId(item.doc_id) == 0) {
      return true;
    }
  }
  // 手机 类过滤垃圾内容
  if (item.category == "科技" && item.sub_category == "手机") {
    if (item.is_source_wemedia
        && item.media_level <= reco::kLowMedia
        && item.hot_level < 10) {
      return true;
    }
    if (!item.is_source_wemedia
        && item.media_level <= reco::kBadMedia
        && item.hot_level < 10) {
      return true;
    }
  }

  bool is_trival;
  reco::ContentAttr content_attr;
  news_index_->GetContentAttrByDocId(item.doc_id, &content_attr, &is_trival);
  if (is_trival) return false;

  // 如果是本地突发事件，不做空短过滤
  reco::LocalBreaking local_breaking;
  bool is_local_breaking = news_index_->GetLocalBreakingByDocId(item.doc_id, &local_breaking);

  int low_quality_score = 0;
  if (content_attr.has_severity() && content_attr.severity() != 0 && content_attr.severity() >= 3) {
    low_quality_score = 3;
  } else if ((!is_local_breaking && content_attr.short_content() == reco::ContentAttr::kSureYes)
             || content_attr.dedup_paragraph() == reco::ContentAttr::kSureYes
             || content_attr.advertorial() == reco::ContentAttr::kSureYes) {
    low_quality_score = 3;
  } else if (content_attr.erro_title() == reco::ContentAttr::kSureYes
             || content_attr.politics() == reco::ContentAttr::kSureYes
             || content_attr.dirty() == reco::ContentAttr::kSureYes
             || content_attr.bluffing_title() == reco::ContentAttr::kSureYes
             || content_attr.short_content() == reco::ContentAttr::kSuspect
             || content_attr.dedup_paragraph() == reco::ContentAttr::kSuspect
             || content_attr.advertorial() == reco::ContentAttr::kSuspect) {
    low_quality_score = 2;
  } else if (content_attr.erro_title() == reco::ContentAttr::kSuspect
             || content_attr.politics() == reco::ContentAttr::kSuspect
             || content_attr.dirty() == reco::ContentAttr::kSuspect
             || content_attr.bluffing_title() == reco::ContentAttr::kSuspect) {
    low_quality_score = 1;
  }

  if (low_quality_score == 0) return false;

  // low quality 最高的文章直接过滤
  if (low_quality_score >= 3) {
    // PrintFilterDebug(item, "low quality >= 3.");
    return true;
  }

  // 根据低质分数及媒体权威性的过滤
  bool is_less_normal_media = false;
  if ((item.is_source_wemedia && item.media_level <= reco::MediaLevel::kNormalMedia)
      || (!item.is_source_wemedia && item.media_level <= reco::MediaLevel::kLowMedia)) {
    is_less_normal_media = true;
  }
  if (low_quality_score >= 2
      && is_less_normal_media
      && item.site_level <= reco::SiteLevel::kMidQualitySite) {
    // PrintFilterDebug(item, "shuangzhongdi && queding");
    return true;
  }
  if (low_quality_score >= 1
      && item.media_level == reco::MediaLevel::kBadMedia
      && item.site_level == reco::SiteLevel::kBadQualitySite
      && item.itemq <= reco::kNormalItemq) {
    // PrintFilterDebug(item, "shuangzuidi && suspect");
    return true;
  }

  // 竞品低质做严格打压
  std::string source;
  if (FLAGS_dizhi_filter_compete_source
      && low_quality_score >= 1
      && news_index_->GetSourceByDocId(item.doc_id, &source)
      && (source.find("天天快报-文本-竞品") != std::string::npos
          || source.find("今日头条-文本-竞品") != std::string::npos)) {
    // PrintFilterDebug(item, "compete_source low item filter.");
    return true;
  }
  if (FLAGS_dizhi_filter_compete_media
      && news_index_->GetSourceMediaByDocId(item.doc_id, &source)
      && kCompeteSourceMediaSet.find(source) != kCompeteSourceMediaSet.end()
      && low_quality_score >= 1) {
    // PrintFilterDebug(item, "compete_media low item filter.");
    return true;
  }

  const std::unordered_map<std::string, int>* dizhi_tag_map = dict_manager_->GetDizhiTagMap();
  const std::unordered_map<std::string, int>* dizhi_category_map = dict_manager_->GetDizhiCategoryMap();

  bool hit_dizhi = false;
  if (FLAGS_dizhi_tag_and_category_filter
      && dizhi_category_map->size() > 0) {
    if (dizhi_category_map->find(item.category) != dizhi_category_map->end()) {
      hit_dizhi = true;
    } else if (dizhi_category_map->find(item.sub_category) != dizhi_category_map->end()) {
      hit_dizhi = true;
    }
  }
  if (FLAGS_dizhi_tag_and_category_filter
      && !hit_dizhi) {
    reco::FeatureVector fea_vec;
    if (dizhi_tag_map->size() > 0
        && news_index_->GetFeatureVectorByItemId(item.item_id, reco::common::kTag, &fea_vec)
        && fea_vec.feature_size() > 0) {
      for (int i = 0; i < fea_vec.feature_size(); ++i) {
        std::string tag = fea_vec.feature(i).literal();
        if (dizhi_tag_map->find(tag) == dizhi_tag_map->end()) {
          continue;
        } else {
          hit_dizhi = true;
          break;
        }
      }
    }
  }

  if (hit_dizhi) {
    bool is_less_low_media = false;
    if ((item.is_source_wemedia && item.media_level < reco::MediaLevel::kNormalMedia)
        || (!item.is_source_wemedia && item.media_level < reco::MediaLevel::kLowMedia)) {
      is_less_low_media = true;
    }

    if (low_quality_score >= 1
        || (item.itemq <= reco::kBadItemq
            && item.itemq > 0
            && item.media_level <= reco::MediaLevel::kLowMedia)
        || (orgi_itemq <= FLAGS_dizhi_low_new_itemq_thresh
            && orgi_itemq > -1
            && item.is_source_wemedia)
        || (is_less_low_media
            &&  item.itemq < reco::kNormalItemq
            && item.site_level < reco::SiteLevel::kMidQualitySite)) {
      // PrintFilterDebug(item, "dizhi_tag#");
      return true;
    }
  }
  return false;
};

void SortItem::CollectVideoItemChannelIds(const ItemInfo &item,
                                          const std::vector<int64> &seed_channel_ids,
                                          std::unordered_set<int64> *channel_ids) {
  channel_ids->clear();
  channel_ids->insert(common::kVideoChannelId);

  // 根据视频分类来组织二级频道
  std::unordered_set<int64> extra_channels;
  std::unordered_set<int64> manual_channels;
  for (auto i = 0u; i < seed_channel_ids.size(); ++i) manual_channels.insert(seed_channel_ids[i]);

  channel_itemtype_dict_.GetVideoChannelsFromItemRule(item, manual_channels,
                                                      &extra_channels, news_index_);
  // 进行聚合频道召回
  channel_itemtype_dict_.AggregateSubordinateChannels(reco::kVideoChannelRule, &extra_channels);

  for (auto iter = extra_channels.begin(); iter != extra_channels.end(); ++iter) {
    // 疑似低质视频不进入二级频道
    if (news_index_->GetVideoQualityLevelByDocId(item.doc_id) != VideoAttr::kNormal) {
      VLOG(1) << "filtered by not normal video: " << item.item_id;
    } else {
      channel_ids->insert(*iter);
      VLOG(2) << base::StringPrintf("add to video channel [channel: %lu][item: %lu][ctr: %f][category: %s]",
                                    *iter, item.item_id, item.ctr, item.category.c_str());
    }
  }

  // 进行全局 channel 规则过滤
  channel_itemtype_dict_.RemoveForbidChannels(item, channel_ids, news_index_);

  // 如果热点视频是体育、军事、娱乐分类，加入到对应的频道内
  if (item.hot_level >= kVideoHotLevelThr) {
    channel_ids->insert(common::kHotChannelId);
    auto ch_iter = kVideoCategoryToChannel.find(item.category);
    if (ch_iter != kVideoCategoryToChannel.end()) {
      channel_ids->insert(ch_iter->second);
    }
  }
}

void SortItem::SortVideoItems(const std::vector<ItemInfo>& all_items,
                              ChannelMap* channel_video_index,
                              ChannelMap* channel_video_explore_index,
                              ChannelMap* channel_video_fully_shown_index) {
  std::vector<int64> seed_channel_ids;
  std::unordered_set<int64> candidate_channels;
  for (int i = 0; i < (int)all_items.size(); ++i) {
    const ItemInfo& item = all_items[i];
    if (FilterVideoItem(item)) { continue; }

    seed_channel_ids.clear();
    candidate_channels.clear();
    if (!news_index_->GetChannelsByDocId(item.doc_id, &seed_channel_ids)) {
      LOG(ERROR) << "get channels by doc id error, doc_id: " << item.doc_id;
      continue;
    }
    // NOTE(suzhewen): 过滤本地源的内容
    if (seed_channel_ids.size() == 1 && seed_channel_ids.front() == common::kLocalChannelId) {
      VLOG(1) << "filtered by local channel video: " << item.item_id;
      continue;
    }

    CollectVideoItemChannelIds(item, seed_channel_ids, &candidate_channels);
    for (auto ch_iter = candidate_channels.begin(); ch_iter != candidate_channels.end(); ++ch_iter) {
      int64 channel_id = *ch_iter;
      if (channel_id == common::kVideoChannelId) {
        if (item.show_num > FLAGS_video_confidence_show_num) {
          NewsQueue &video_queue = (*channel_video_index)[channel_id];
          AddToVideoQueue(item, &video_queue, kMaxSaveVideoChannel, 0.01);
        } else {
          NewsQueue &video_queue = (*channel_video_explore_index)[channel_id];
          AddToVideoQueue(item, &video_queue, kMaxSavePerCate * 2, 0.05);
        }
        if (item.show_num > FLAGS_video_confidence_show_num * 10) {
          NewsQueue &video_queue = (*channel_video_fully_shown_index)[channel_id];
          AddToVideoQueue(item, &video_queue, kMaxSaveVideoChannel, 0.1);
        }
      } else {
        if (CheckVideo2ndChannel(channel_id)) {
          NewsQueue &video_queue = (*channel_video_index)[channel_id];
          AddToVideoQueue(item, &video_queue, kMaxSavePerCate * 8, 0.03);
        }
      }
    }
  }

  SortChannelVideoItems(channel_video_index, channel_video_explore_index, channel_video_fully_shown_index);
}

void SortItem::SortChannelVideoItems(ChannelMap* channel_video_index,
                                     ChannelMap* channel_video_explore_index,
                                     ChannelMap* channel_video_fully_shown_index) {
  for (auto it = channel_video_index->begin(); it != channel_video_index->end(); ++it) {
    NewsQueue& queue = it->second;
    std::vector<ItemInfo>* items = queue.MutableIndex();
    std::sort(items->begin(), items->end(), VideoItemSortFunc);
    queue.today_news_num = GetTodayNewsNum(*queue.GetIndex());
    LOG(INFO) << base::StringPrintf("channel video [%ld], docs[%d], today news [%d]",
                                    it->first, (int)queue.GetIndex()->size(), queue.today_news_num);
  }

  for (auto it = channel_video_explore_index->begin(); it != channel_video_explore_index->end(); ++it) {
    NewsQueue& queue = it->second;
    std::vector<ItemInfo>* items = queue.MutableIndex();
    std::sort(items->begin(), items->end(), VideoItemSortFunc);
    queue.today_news_num = GetTodayNewsNum(*queue.GetIndex());
    LOG(INFO) << base::StringPrintf("explore channel video [%ld], docs[%d], today news [%d]",
                                    it->first, (int)queue.GetIndex()->size(), queue.today_news_num);
  }

  for (auto it = channel_video_fully_shown_index->begin();
       it != channel_video_fully_shown_index->end(); ++it) {
    NewsQueue& queue = it->second;
    std::vector<ItemInfo>* items = queue.MutableIndex();
    std::sort(items->begin(), items->end(), VideoItemSortFunc);
    queue.today_news_num = GetTodayNewsNum(*queue.GetIndex());
    LOG(INFO) << base::StringPrintf("fully shown channel video [%ld], docs[%d], today news [%d]",
                                    it->first, (int)queue.GetIndex()->size(), queue.today_news_num);
  }
}

void SortItem::SortUgcVideoItems(const std::vector<ItemInfo>& all_items,
                                 ChannelMap* ugc_video_index,
                                 ChannelMap* ugc_video_explore_index) {
  CHECK(ugc_video_index);
  CHECK(ugc_video_explore_index);

  std::vector<int64> seed_channel_ids;
  std::unordered_set<int64> candidate_channels;

  int32 item_count = 0;
  int32 filtered_count = 0;

  base::Time explore_limit_time =
    base::Time::Now() - base::TimeDelta::FromDays(FLAGS_ugc_explore_day_limit);
  int64 explore_limit_ts = explore_limit_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  for (int i = 0; i < (int)all_items.size(); ++i) {
    const ItemInfo& item = all_items[i];
    if (FilterVideoItem(item)) { continue; }

    seed_channel_ids.clear();
    candidate_channels.clear();
    if (!news_index_->GetChannelsByDocId(item.doc_id, &seed_channel_ids)) {
      LOG(ERROR) << "get channels by doc id error, doc_id: " << item.doc_id;
      continue;
    }

    // NOTE(suzhewen): 过滤本地源的内容
    if (seed_channel_ids.size() == 1 && seed_channel_ids.front() == common::kLocalChannelId) {
      VLOG(1) << "filtered by local channel video: " << item.item_id;
      continue;
    }
    CollectVideoItemChannelIds(item, seed_channel_ids, &candidate_channels);

    // 过滤非 ugc 视频
    if (candidate_channels.find(reco::common::kWanghongChannelId) == candidate_channels.end() &&
        candidate_channels.find(reco::common::kYouCaiUgcChannelId) == candidate_channels.end()) {
      continue;
    }

    ++item_count;

    for (auto ch_iter = candidate_channels.begin(); ch_iter != candidate_channels.end(); ++ch_iter) {
      int64 channel_id = *ch_iter;

      if (FilterUgcVideoItem(channel_id, item)) {
        ++filtered_count;
        continue;
      }

      if (channel_id == common::kWanghongChannelId ||
          channel_id == common::kYouCaiUgcChannelId) {

        ItemInfo* mutable_item = const_cast<ItemInfo*>(&item);
        news_index_->GetMetaInfo(item.item_id, mutable_item);

        // normal
        {
          // TODO(lixiang01) 有才索引的构建与排序暂时先复用网红的方法
          if (channel_id == common::kYouCaiUgcChannelId) {
            NewsQueue &video_queue = (*ugc_video_index)[channel_id];
            AddToVideoQueue(item, &video_queue, kMaxSavePerCate * 8, 0.0);
            VLOG(1) << "add to youcai hot index: " << item.item_id << ", channel_id:" << channel_id;
          } else {
            NewsQueue &video_queue = (*ugc_video_index)[channel_id];
            AddToVideoQueue(item, &video_queue, kMaxSavePerCate * 8, 0.03);
          }
        }

        // explore
        if (mutable_item->show_num < FLAGS_ugc_explore_thresh &&
            item.create_timestamp > explore_limit_ts) {
          NewsQueue &video_queue = (*ugc_video_explore_index)[channel_id];
          if (channel_id == common::kYouCaiUgcChannelId) {
            VLOG(1) << "add to youcai explore index: " << item.item_id << ", channel_id:" << channel_id;
          }
          AddToVideoQueue(*mutable_item, &video_queue, kMaxSavePerCate * 4, 0.0);
        }
      }
    }
  }  // for

  LOG(INFO) << "recalled total ugc items:" << item_count
            << "filterd:" << filtered_count;

  SortUgcChannelVideoItems(ugc_video_index, ugc_video_explore_index);
}

void SortItem::SortUgcChannelVideoItems(ChannelMap* ugc_video_index,
                                        ChannelMap* ugc_video_explore_index) {
  for (auto it = ugc_video_index->begin(); it != ugc_video_index->end(); ++it) {
    int64 channel_id = it->first;
    NewsQueue& queue = it->second;
    std::vector<ItemInfo>* items = queue.MutableIndex();

    // TODO(lixiang01) 有才索引的构建与排序暂时先复用网红的方法
    if (channel_id == reco::common::kYouCaiUgcChannelId) {
      GetUgcItemModelScore(reco::common::kWanghongChannelId, *items);
      SortYouCaiItems(items);
    } else {
      GetUgcItemModelScore(channel_id, *items);
      std::sort(items->begin(), items->end(), UgcVideoItemSortFunc);
    }

    queue.today_news_num = GetTodayNewsNum(*queue.GetIndex());
    LOG(INFO) << base::StringPrintf("channel id: [%ld], docs[%d], today news [%d]",
                                    it->first, (int)queue.GetIndex()->size(), queue.today_news_num);
  }

  unsigned pthread_id = pthread_self();
  for (auto it = ugc_video_explore_index->begin(); it != ugc_video_explore_index->end(); ++it) {
    NewsQueue& queue = it->second;
    std::vector<ItemInfo>* items = queue.MutableIndex();

    srand(unsigned(time(NULL)) + pthread_id);
    std::random_shuffle(items->begin(), items->end());

    queue.today_news_num = GetTodayNewsNum(*queue.GetIndex());
    LOG(INFO) << base::StringPrintf("ugc explore channel id: [%ld], docs[%d], today news [%d]",
                                    it->first, (int)queue.GetIndex()->size(), queue.today_news_num);
  }
}

void SortItem::SortYouCaiItems(std::vector<ItemInfo>* items) {
  std::sort(items->begin(), items->end(), UgcVideoItemSortFunc);
  auto dict = DM_GET_DICT(reco::dm::UgcExpoRatioNeededDict,
                          reco::DynamicDictContainer::kUgcExpoRatioNeededFile_);
  if (dict == NULL || dict->size() == 0) {
    LOG(ERROR) << "UgcExpoRatioNeededDict is NULL or size = 0";
    return;
  }
  // 对 items 根据池子分桶
  std::unordered_map<int, std::list<ItemInfo> > pool_items;
  std::vector<int> content_pool_ids;
  for (auto item = items->begin(); item != items->end(); ++item) {
    content_pool_ids.clear();
    int pool_id = -1;
    if (news_index_->GetItemContentPoolIdsByItemId(item->item_id, &content_pool_ids)) {
      if (content_pool_ids.size() > 1) {
        LOG(WARNING) << "expo manager content pool id size > 1:"
                     << item->item_id << ", " << content_pool_ids.size();
      }
      if (dict->find(content_pool_ids[0]) != dict->end()) {
        pool_id = content_pool_ids[0];
      }
    }
    auto it = pool_items.find(pool_id);
    if (it == pool_items.end()) {
      std::list<ItemInfo> tmp;
      tmp.push_back(*item);
      pool_items.insert(std::make_pair(pool_id, tmp));
    } else {
      it->second.push_back(*item);
    }
  }
  for (auto it = pool_items.begin(); it != pool_items.end(); ++it) {
    LOG(INFO) << base::StringPrintf("pool_id:%d, items count:%lu", it->first, it->second.size());
  }
  std::vector<ItemInfo> items_tmp;
  if (MergeYouCaiItems(pool_items, items_tmp)) {
    items->swap(items_tmp);
  }
  LOG(INFO) << base::StringPrintf("get youcai items count:%lu", items->size());
}

bool SortItem::MergeYouCaiItems(std::unordered_map<int, std::list<ItemInfo> >& pool_items,
                                std::vector<ItemInfo>& items) {
  auto dict = DM_GET_DICT(reco::dm::UgcExpoRatioNeededDict,
                          reco::DynamicDictContainer::kUgcExpoRatioNeededFile_);
  if (dict == NULL || dict->size() == 0) {
    LOG(ERROR) << "UgcExpoRatioNeededDict is NULL or size = 0";
    return false;
  }
  LOG(INFO) << base::StringPrintf("UgcExpoRatioNeededDict size:%lu", dict->size());

  // 计算各池子中 item 在索引中的比重，把结果写入 pool_prob
  std::unordered_map<int, float> pool_prob;
  for (auto jt = dict->begin(); jt != dict->end(); ++jt) {
    auto kt = pool_prob.find(jt->first);
    if (kt == pool_prob.end()) {
      float prob = jt->second.min;
      pool_prob.insert(std::make_pair(jt->first, prob));
      LOG(INFO) << base::StringPrintf("pool_id:%d, pool_prob:%f", jt->first, prob);
    }
  }
  double total_prob = 0;
  bool flag = false;
  for (auto it = pool_items.begin(); it != pool_items.end(); ++it) {
    if (it->second.size() == 0) continue;
    auto jt = pool_prob.find(it->first);
    if (jt != pool_prob.end()) {
      total_prob += jt->second;
    }
    if (it->first == -1) {
      flag = true;
    }
  }
  if (flag) {
    pool_prob.insert(std::make_pair(-1, std::max(0.01, 1.0 - total_prob)));
  }

  // 各桶按概率归并
  int prob_pool[100];
  memset(prob_pool, 0, sizeof(prob_pool));
  int pool_count = 0;
  while ((pool_count = GetYouCaiProbPool(pool_items,
                                         pool_prob,
                                         prob_pool,
                                         sizeof(prob_pool) / sizeof(prob_pool[0]))) > 0) {
    bool stop = false;
    while (!stop) {
      if (pool_count == 1) {
        int pool_id = prob_pool[0];
        while (pool_items[pool_id].size() > 0) {
          if (pool_items[pool_id].size() == 0) {
            LOG(ERROR) << base::StringPrintf("youcai item merge error, front item is null");
            stop = true;
            continue;
          }
          items.push_back(pool_items[pool_id].front());
          pool_items[pool_id].pop_front();
        }
        stop = true;
      } else {
        const int rand = static_cast<int>(99 * random_->GetDouble());
        const int pool_id = prob_pool[rand];
        if (pool_items[pool_id].size() == 0) {
          LOG(ERROR) << base::StringPrintf("youcai item merge error, front item is null");
          stop = true;
          continue;
        }
        items.push_back(pool_items[pool_id].front());
        pool_items[pool_id].pop_front();
        if (pool_items[pool_id].size() == 0) {
          stop = true;
        }
      }
    }
  }
  return true;
}

int SortItem::GetYouCaiProbPool(const std::unordered_map<int, std::list<ItemInfo> >& pool_items,
                                std::unordered_map<int, float>& pool_prob,
                                int* prob_pool, int prob_pool_len) {
  int total_pool = 0;
  float total_prob = 0.0;
  for (auto it = pool_items.begin(); it != pool_items.end(); ++it) {
    if (it->second.size() > 0) {
      ++total_pool;
      auto jt = pool_prob.find(it->first);
      if (jt != pool_prob.end()) {
        total_prob += jt->second;
      }
    }
  }
  if (total_prob < 1e-6) {
    LOG(INFO) << base::StringPrintf("error: total_prob:%f", total_prob);
    return 0;
  }

  int index = 0;
  for (auto it = pool_items.begin(); it != pool_items.end(); ++ it) {
    if (it->second.size() > 0) {
      auto jt = pool_prob.find(it->first);
      if (jt == pool_prob.end()) {
        LOG(ERROR) << base::StringPrintf("get pool:%d prob failed", it->first);
        continue;
      }
      int count = static_cast<int>(1 + prob_pool_len * jt->second / total_prob);
      LOG(INFO) << base::StringPrintf("pool_id:%d, pool_prob:%d/%d", it->first, count, prob_pool_len);
      while (count--) {
        if (index < prob_pool_len) {
          prob_pool[index++] = it->first;
        }
      }
    }
  }

  for (int i = 0; i < prob_pool_len; ++i) {
    LOG(INFO) << base::StringPrintf("prob_pool[%d] = %d", i, prob_pool[i]);
  }

  return total_pool;
}

bool SortItem::GetUgcItemModelScore(const int64 channel_id, std::vector<ItemInfo>& all_items) {
  auto dict = DM_GET_DICT(reco::dm::UgcItemScoreDict, reco::DynamicDictContainer::kUgcItemScoreFile_);
  if (dict == NULL) {
    LOG(ERROR) << "UgcItemScoreDict is NULL";
    return false;
  }
  auto& item_dict_score = const_cast<std::unordered_map<uint64,
                                    std::unordered_map<int64, double> >& > (dict->ugc_item_score_);

  for (auto it = all_items.begin(); it != all_items.end(); ++it) {
    // TODO(lixiang01): 对新视频默认赋值为 0 不公平
    double score = 0.0;
    auto jt = item_dict_score.find(it->item_id);
    if (jt != item_dict_score.end()) {
      auto kt = jt->second.find(channel_id);
      if (kt != jt->second.end()) {
        score = kt->second;
      }
    }
    // add to items
    it->itemq = static_cast<int>(score * 1e8);
    VLOG(1) << base::StringPrintf("item_id:%lu, channel_id:%lu, itemq:%d",
        it->item_id, channel_id, it->itemq);
  }
  LOG(INFO) << base::StringPrintf("channel_id:%lu, total items:%lu", channel_id, all_items.size());
  return true;
}

void SortItem::AddMultiCategoryChannels(const ItemInfo & item,
                                        const ::google::protobuf::RepeatedPtrField<ItemCategory> & candidates,
                                        std::unordered_set<int64>* candidate_channels,
                                        std::unordered_map<int64, std::pair<std::string, std::string> >* inc) {
  serving_base::Timer timer;
  timer.Start();

  const base::dense_hash_map<std::string, std::unordered_set<std::string> >* extend_category_dict =
      dict_manager_->GetExtendCategoryMap();
  std::unordered_set<std::string> extend_cate;
  std::vector<std::string> item_cate = {item.category};
  if (!item.sub_category.empty()) {
    item_cate.push_back(item.category + "-" + item.sub_category);
  }
  for (auto i = 0u; i < item_cate.size(); ++i) {
    auto iter = extend_category_dict->find(item_cate[i]);
    if (iter != extend_category_dict->end()) {
      for (auto iter_cand = iter->second.begin(); iter_cand != iter->second.end(); ++iter_cand) {
        extend_cate.insert(*iter_cand);
      }
    }
  }

  ItemInfo expand_item = item;
  for (int i = 0; i < candidates.size(); ++i) {
    if (extend_cate.count(candidates.Get(i).level1()) > 0) {
      expand_item.category = candidates.Get(i).level1();
      std::unordered_set<int64> tmp_channels;
      channel_itemtype_dict_.GetLeafExtendChannelsFromItemRule(expand_item, &tmp_channels, news_index_);
      for (auto iter = tmp_channels.begin(); iter != tmp_channels.end(); ++iter) {
        candidate_channels->insert(*iter);
        inc->insert(std::make_pair(*iter, std::make_pair(candidates.Get(i).level1(), std::string())));
      }
    }
    for (int j = 0; j < candidates.Get(i).level2_size(); ++j) {
      std::string str = candidates.Get(i).level1() + "-" + candidates.Get(i).level2(j);
      if (extend_cate.count(str) > 0) {
        expand_item.sub_category = candidates.Get(i).level2(j);
        std::unordered_set<int64> tmp_channels;
        channel_itemtype_dict_.GetLeafExtendChannelsFromItemRule(expand_item, &tmp_channels, news_index_);
        for (auto iter = tmp_channels.begin(); iter != tmp_channels.end(); ++iter) {
          candidate_channels->insert(*iter);
          inc->insert(std::make_pair(*iter, std::make_pair(candidates.Get(i).level1(),
                                                           candidates.Get(i).level2(j))));
        }
      }
    }
  }
  VLOG(2) << "cate extend cost:" << timer.Stop() << " us";
}

void SortItem::SortChannelItems(const std::vector<ItemInfo>& all_items,
                                CategoryMap* category_index,
                                ChannelMap* channel_index,
                                ChannelMap* region_index,
                                ChannelMap* poi_index) {
  if (FLAGS_target_server == "video_server") return;

  subs_channel_->UpdateSubscribeResult();
  std::unordered_set<int64> candidate_channels;
  std::unordered_set<int64> manual_channels;
  std::vector<int64> channel_ids;
  std::vector<int64> extra_tags;
  // auto& black_itemtype_channel = *channel_itemtype_dict_.GetBlackItemtypeChannel().get();
  auto dict = DM_GET_DICT(reco::dm::ChannelItemtypeDict, reco::DynamicDictContainer::kChannelItemtypeFile_);

  std::unordered_map<int64, std::pair<std::string, std::string> > incr_channel;
  for (int i = 0; i < (int)all_items.size(); ++i) {
    const ItemInfo& item = all_items[i];
    candidate_channels.clear();
    manual_channels.clear();
    channel_ids.clear();
    incr_channel.clear();

    if (i % 10000 == 0) {
      LOG(INFO) << i << " channel items indexed";
    }

    // 纯视频走单独的建队列逻辑
    if (item.item_type == kPureVideo) {
      continue;
    }


    if (!news_index_->GetChannelsByDocId(item.doc_id, &channel_ids)) {
      LOG(ERROR) << "get channels by doc id error, doc_id: " << item.doc_id;
      continue;
    }

    // 暂时用于指定频道过滤包含本地频道的新闻
    bool has_org_local_channel = false;
    bool has_local_channel = false;
    // 加入所属的频道
    for (int j = 0; j < (int)channel_ids.size(); ++j) {
      VLOG(3) << "item:" << item.item_id << ", channel:" << channel_ids[j];
      // NOTE(zhuzekun) 一些视频会投放在 reco 频道
      // if (channel_ids[j] == reco::common::kRecoChannelId) continue;
      if (channel_ids[j] == reco::common::kLocalChannelId) {
        has_org_local_channel = true;
        if (AddToRegionQueue(item, region_index, poi_index)) {
          has_local_channel = true;
        }
        continue;
      }
      manual_channels.insert(channel_ids[j]);
    }
    subs_channel_->GetSubsChannelIds(item.doc_id, &manual_channels);
    manual_channels.erase(reco::common::kHotChannelId);

    // 热门新闻同时加入热门新闻频道 自媒体不加入热点频道
    // NOTE(suzhewen): 本地频道和视频的热度计算逻辑与普通热度不同，不放入热门频道
    if ((item.hot_level >= FLAGS_floor_hot_thresh)
        && item.site_level != reco::kBadQualitySite
        && item.item_type != reco::kPureVideo
        && !item.is_source_wemedia
        && !has_local_channel) {
      candidate_channels.insert(reco::common::kHotChannelId);
    }

    extra_tags.clear();
    // NOTE(suzhewen): 不对本地源的数据进行扩展，待加上地域限制后再去掉
    if (!has_local_channel) {
      // 根据类别扩触发到 match 的频道
      static const std::unordered_set<int64> kExtendChannelCategories
        = {reco::kNews, reco::kPicture, reco::kPictureNews, reco::kReading};
      if (kExtendChannelCategories.find(item.item_type) != kExtendChannelCategories.end()) {
        MultiCategory multi_category;
        if (news_index_->GetMultiCategoriesByItemId(item.item_id, &multi_category)) {
          MultiCategory multi_category;
          if (news_index_->GetMultiCategoriesByItemId(item.item_id, &multi_category)) {
            const ::google::protobuf::RepeatedPtrField<ItemCategory>& candidates =
              multi_category.category_candidates();
            AddMultiCategoryChannels(item, candidates, &candidate_channels, &incr_channel);
          }
        }
      }
    } else {
      extra_tags.push_back(kIsLocalChannel);
    }

    // 进行 channel 规则召回
    channel_itemtype_dict_.GetLeafChannelsFromItemRule(item, manual_channels, &candidate_channels,
                                                       extra_tags, news_index_);
    // 进行聚合频道召回
    channel_itemtype_dict_.AggregateSubordinateChannels(reco::kLeafChannelRule, &candidate_channels);

    // 进行全局 channel 规则过滤
    channel_itemtype_dict_.RemoveForbidChannels(item, &candidate_channels, news_index_);

    // 将 item 放入 channel 倒排索引内
    for (auto cand_iter = candidate_channels.begin(); cand_iter != candidate_channels.end(); ++cand_iter) {
      NewsQueue& channel_queue = (*channel_index)[*cand_iter];
      if ((int)channel_queue.GetIndex()->size() < kMaxSavePerCate) {
        // NOTE: 判断是不是因为多分类加进来的，修改分类
        auto it = incr_channel.find(*cand_iter);
        channel_queue.MutableIndex()->push_back(item);
        VLOG(3) << "channel:" << *cand_iter << "item:" << item.item_id;
        if (it != incr_channel.end()) {
          channel_queue.MutableIndex()->back().category = it->second.first;
          // channel_queue.MutableIndex()->back().orig_category = item.category + "-" + item.sub_category;
          if (!it->second.second.empty()) {
            channel_queue.MutableIndex()->back().sub_category = it->second.second;
          } else {
            channel_queue.MutableIndex()->back().sub_category = "";
          }
        }
      }
    }
  }

  for (auto iter = humor_channel_ids_.begin(); iter != humor_channel_ids_.end(); ++iter) {
    channel_index->insert(std::make_pair(*iter, NewsQueue()));
  }
  // channel 找出置顶的新闻
  // NOTE(jianhuang) 置顶暂时在更新索引的时候设置.
  // 如果后续反馈不够灵敏，可以考虑在每次推荐请求的时候过一遍索引
  std::string now_str;
  base::Time now_t = base::Time::Now();
  now_t.ToStringInSeconds(&now_str);
  std::vector<int64> item_channels;
  std::vector<std::string> categories;
  for (auto ch_it = channel_index->begin(); ch_it != channel_index->end(); ++ch_it) {
    std::vector<ItemInfo>* items = ch_it->second.MutableIndex();
    if (humor_channel_ids_.find(ch_it->first) != humor_channel_ids_.end()) {
      // 幽默频道按外站数据排序
      items->clear();
      categories.clear();
      if (ch_it->first == reco::common::kHumorWordChannelId) {
        categories.push_back("幽默");
        categories.push_back("段子");
      } else if (ch_it->first == reco::common::kHumorPicChannelId) {
        categories.push_back("幽默");
        categories.push_back("趣图");
      } else if (ch_it->first == reco::common::kHumorWordTouTiaoChannelId) {
        categories.push_back("幽默");
        categories.push_back("头条搞笑");
      }
      reco::Category category;
      news_index_->ConvertToCategoryProto(categories, 1, &category);
      const NewsQueue& queue = (*category_index)[reco::common::WrappedCategory(category)];
      items->assign(queue.GetIndex()->begin(), queue.GetIndex()->end());
    } else {
      // 其他推荐子频道按 item level 排序
      std::sort(items->begin(), items->end(), NewsItemSortFunc);
    }
  }

  // 计算今日新闻数
  for (auto ch_it = channel_index->begin(); ch_it != channel_index->end(); ++ch_it) {
    NewsQueue& channel_queue = ch_it->second;
    channel_queue.today_news_num = GetTodayNewsNum(*channel_queue.GetIndex());
    LOG(INFO) << base::StringPrintf("channel_id [%ld], docs [%d], today news [%d]",
                                    ch_it->first,
                                    (int)channel_queue.GetIndex()->size(),
                                    channel_queue.today_news_num);
  }
  subs_channel_->Clear();
  SortRegionItems(now_str, region_index, poi_index);
}

void SortItem::SortRegionItems(const std::string& now_str, ChannelMap* region_index, ChannelMap* poi_index) {
  for (auto rg_it = region_index->begin(); rg_it != region_index->end(); ++rg_it) {
    int64 region_id = rg_it->first;
    std::string str_region_id = reco::common::RegionDict::GetStrRegionCodeByIntCode(region_id);
    NewsQueue& region_queue = rg_it->second;
    std::vector<ItemInfo>* items = region_queue.MutableIndex();
    // 在市级队列中加入对应省份的新闻
    if (!reco::common::RegionSearcher::instance().IsShengFenCode(str_region_id)) {
      std::string str_prov_id = reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(
          str_region_id);
      int64 prov_id;
      if (base::StringToInt64(str_prov_id, &prov_id)) {
        auto prov_iter = region_index->find(prov_id);
        if (prov_iter != region_index->end()) {
          NewsQueue& prov_queue = prov_iter->second;
          std::vector<ItemInfo>* prov_items = prov_queue.MutableIndex();
          items->insert(items->end(), prov_items->begin(), prov_items->end());
        }
      }
    }
    std::sort(items->begin(), items->end(), LocalItemSortFunc);
    region_queue.today_news_num = GetTodayNewsNum(*region_queue.GetIndex());
    VLOG(1) << base::StringPrintf("local channel region_id [%ld], docs[%d], today news [%d]",
                                    region_id,
                                    (int)rg_it->second.GetIndex()->size(),
                                    region_queue.today_news_num);
  }

  for (auto poi_it = poi_index->begin(); poi_it != poi_index->end(); ++poi_it) {
    int64 area_id = poi_it->first;
    std::string area_name;
    if (area_id > 1e7) {
      reco::poi::AreaBaseInfo area_base_info;
      if (!reco::poi::CityAreaHashSearcher::instance().GetAreaBaseInfoByAreaID(area_id, &area_base_info)) {
        continue;
      }
      area_name = "area: " + area_base_info.area_name;
    } else {
      std::string admin_name;
      if (!reco::poi::CityAreaHashSearcher::instance().GetAdminNameByID(area_id, &admin_name)) {
        continue;
      }
      area_name = "district: " + admin_name;
    }
    NewsQueue& poi_queue = poi_it->second;
    std::vector<ItemInfo>* items = poi_queue.MutableIndex();
    std::sort(items->begin(), items->end(), LocalItemSortFunc);
    VLOG(1) << base::StringPrintf("poi news queue name [%s], docs[%lu]",
                                    area_name.c_str(), items->size());
  }
}

void SortItem::SortCategoryItems(const std::vector<ItemInfo>& all_items,
                                 CategoryMap* category_index,
                                 CategoryMap* video_category_index,
                                 CategoryMap* media_quantity_index,
                                 CategoryMap* video_media_quantity_index) {
  std::unordered_set<std::string> category_set;
  std::vector<std::string> categories;
  for (int i = 0; i < (int)all_items.size(); ++i) {
    const ItemInfo& item_info = all_items[i];
    categories.clear();
    if (!news_index_->GetCategoriesByDocId(item_info.doc_id, &categories)) {
      LOG(ERROR) << "no category in doc, id: " << item_info.doc_id;
      continue;
    }
    category_set.insert(base::JoinStrings(categories, "\t"));
  }

  std::vector<ItemInfo> items;
  std::vector<ItemInfo> video_items;
  std::vector<ItemInfo> quantity_items;
  std::vector<ItemInfo> quantity_video_items;

  for (auto jt = category_set.begin(); jt != category_set.end(); ++jt) {
    // 本地类别单独索引
    if ((*jt) == reco::common::kLocalCategory) continue;

    categories.clear();
    base::SplitString(*jt, "\t", &categories);
    for (int i = 0; i < (int)categories.size(); ++i) {
      // 根据 app_token 和 category 触发文档，结果序列按 docid 从小到到排序，docid 小的文档新
      reco::Category category;
      news_index_->ConvertToCategoryProto(categories, i, &category);
      if (category_index->find(reco::common::WrappedCategory(category)) != category_index->end()) {
        // 多个二级类别的一级类别会被重复计算, 所以一级类别只进行一次
        continue;
      }

      // 从总索引里面抽取满足类别需求的 item 列表
      items.clear();
      video_items.clear();
      ExtractCategoryItems(all_items, category, &items, &video_items, kMaxSavePerCate);

      // 将符合条件的图文和视频内容分别加入保量 item 列表
      ExtractQuantityItems(category.category(), items, video_items, &quantity_items, &quantity_video_items);

      if (!items.empty()) {
        // 放入到类别索引中
        NewsQueue& queue = (*category_index)[reco::common::WrappedCategory(category)];
        queue.today_news_num = GetTodayNewsNum(items);
        queue.MutableIndex()->swap(items);
        if (category.parents_size() == 0) queue.SetItemDocIDs();

        LOG(INFO) << base::StringPrintf("category [%s], default docs [%d], today news [%d], ",
                                        reco::common::WrappedCategory(category).ToString().c_str(),
                                        (int)queue.GetIndex()->size(),
                                        queue.today_news_num);

        if (picture_categories_.find(categories[i]) != picture_categories_.end()) {
          queue.MutableTimelyIndex()->assign(queue.GetIndex()->begin(), queue.GetIndex()->end());
          std::sort(queue.MutableTimelyIndex()->begin(), queue.MutableTimelyIndex()->end(),
                    NewsItemTimeSortFunc);
          LOG(INFO) << base::StringPrintf("timely sort category [%s], default docs [%d], today news [%d]",
                                          reco::common::WrappedCategory(category).ToString().c_str(),
                                          (int)queue.GetTimelyIndex()->size(),
                                          queue.today_news_num);
        }
      }

      // 放入视频分类队列
      if (!video_items.empty()) {
        std::sort(video_items.begin(), video_items.end(), VideoItemSortFunc);
        NewsQueue& video_queue = (*video_category_index)[reco::common::WrappedCategory(category)];
        video_queue.today_news_num = GetTodayNewsNum(video_items);
        video_queue.MutableIndex()->swap(video_items);
        if (category.parents_size() == 0) video_queue.SetItemDocIDs();

        LOG(INFO) << base::StringPrintf("video category [%s], default docs [%d], today news [%d]",
                                        reco::common::WrappedCategory(category).ToString().c_str(),
                                        (int)video_queue.GetIndex()->size(),
                                        video_queue.today_news_num);
      }

      // 放入图文分类保量队列
      if (!quantity_items.empty()) {
        std::sort(quantity_items.begin(), quantity_items.end(), MediaQuantityItemSortFunc);
        NewsQueue& quantity_queue = (*media_quantity_index)[reco::common::WrappedCategory(category)];
        quantity_queue.today_news_num = GetTodayNewsNum(quantity_items);
        quantity_queue.MutableIndex()->swap(quantity_items);
        if (category.parents_size() == 0) quantity_queue.SetItemDocIDs();

        LOG(INFO) << base::StringPrintf("media quantity category [%s], default docs [%d], today news [%d]",
                                        reco::common::WrappedCategory(category).ToString().c_str(),
                                        (int)quantity_queue.GetIndex()->size(),
                                        quantity_queue.today_news_num);
      }

      // 放入视频分类保量队列
      if (!quantity_video_items.empty()) {
        std::sort(quantity_video_items.begin(), quantity_video_items.end(), MediaQuantityVideoItemSortFunc);
        NewsQueue& quantity_video_queue =
          (*video_media_quantity_index)[reco::common::WrappedCategory(category)];
        quantity_video_queue.today_news_num = GetTodayNewsNum(quantity_video_items);
        quantity_video_queue.MutableIndex()->swap(quantity_video_items);
        if (category.parents_size() == 0) quantity_video_queue.SetItemDocIDs();

        LOG(INFO) << base::StringPrintf(
                    "media quantity video category [%s], default docs [%d], today news [%d]",
                    reco::common::WrappedCategory(category).ToString().c_str(),
                    (int)quantity_video_queue.GetIndex()->size(),
                    quantity_video_queue.today_news_num);
      }
    }
  }
}

/*
void SortItem::SortHotVideoItems(const std::vector<ItemInfo>& all_items, NewsQueue* news_queue) {
  news_queue->MutableIndex()->clear();
  auto now_time = base::Time::Now();
  for (size_t i = 0; i < all_items.size(); ++i) {
    if ((int)news_queue->GetIndex()->size() >= kMaxSaveVideoChannel) break;
    const ItemInfo& item = all_items[i];
    if (item.item_type != reco::kPureVideo) continue;
    auto item_time = base::Time::FromDoubleT(item.create_timestamp / base::Time::kMicrosecondsPerSecond);
    auto gap = now_time - item_time;
    if (gap.InHours() > 24) continue;
    if (item.hot_level > 0) {
      AddToVideoQueue(item, news_queue, kMaxSaveVideoChannel, false);
    }
  }
  std::vector<ItemInfo>* items = news_queue->MutableIndex();
  std::sort(items->begin(), items->end(), VideoItemSortFunc);
  news_queue->today_news_num = GetTodayNewsNum(*news_queue->GetIndex());
  LOG(INFO) << base::StringPrintf("hot video channel docs[%d], today news [%d]",
                                  (int)news_queue->GetIndex()->size(), news_queue->today_news_num);
}
*/

void SortItem::SortSubjectItems(const std::vector<ItemInfo>& all_items, NewsQueue* news_queue) {
  news_queue->MutableIndex()->clear();
  int bad_filter_num = 0;
  int high_ctr_num = 0;
  int subitem_filter_num = 0;
  for (size_t i = 0; i < all_items.size(); ++i) {
    if ((int)news_queue->GetIndex()->size() >= kMaxSaveVideoChannel) break;
    if (all_items[i].item_type != reco::kThemeVideo) {
      continue;
    }
    ItemInfo item = all_items[i];
    VLOG(1) << "get subject id succ: " << item.item_id;
    if (!CalcSubjectMergeMsg(&item)) {
      ++subitem_filter_num;
      VLOG(1) << base::StringPrintf("subject filter lack subtem docs[%lu], show_num[%d]"
                                      " click_num[%d] ctr[%f] wilson_ctr[%f]",
                                  item.item_id, item.show_num, item.click_num, item.ctr, item.wilson_ctr);
      continue;
    }
    if (item.show_num > 10000 && item.ctr < 0.005 && item.wilson_ctr < 0.02) {
      ++bad_filter_num;
      VLOG(1) << base::StringPrintf("subject filter bad docs[%lu], show_num[%d]"
                                      " click_num[%d] ctr[%f] wilson_ctr[%f]",
                                  item.item_id, item.show_num, item.click_num, item.ctr, item.wilson_ctr);
      continue;
    }
    if (item.ctr > 0.08) {
      ++high_ctr_num;
      VLOG(1) << base::StringPrintf("subject high ctr docs[%lu], show_num[%d]"
                                      " click_num[%d] ctr[%f] wilson_ctr[%f]",
                                  item.item_id, item.show_num, item.click_num, item.ctr, item.wilson_ctr);
    }
    news_queue->MutableIndex()->push_back(item);
  }
  // 主题综合子文 ctr 做排序
  std::vector<ItemInfo>* items = news_queue->MutableIndex();
  std::sort(items->begin(), items->end(), SubjectItemSortFunc);
  news_queue->today_news_num = GetTodayNewsNum(*news_queue->GetIndex());
  LOG(INFO) << base::StringPrintf("subject save docs[%d], today news [%d]"
                                  " subitem filter[%d] bad filter[%d] high ctr[%d]",
                                  (int)news_queue->GetIndex()->size(), news_queue->today_news_num,
                                  subitem_filter_num, bad_filter_num, high_ctr_num);
}

bool SortItem::CalcSubjectMergeMsg(ItemInfo* item_pr) {
  ItemInfo& item = *item_pr;
  static const int kMaxMergeSubItemNum = 5;
  reco::SubjectSubItems subject_sub_items;
  if (!news_index_->GetSubjectSubItemByItemId(item.item_id, &subject_sub_items)) {
    return false;
  }
  // 过滤子文不够 5 个的主题
  if (subject_sub_items.sub_items_size() < 5) {
    return false;
  }
  std::vector<ItemInfo> sub_items;
  for (int j = 0; j < subject_sub_items.sub_items_size() && j < kMaxMergeSubItemNum; ++j) {
    const SubjectSubItem& sub_item = subject_sub_items.sub_items(j);
    if (!sub_item.has_item_id()) continue;
    ItemInfo sub_item_info;
    news_index_->GetItemInfoByItemId(sub_item.item_id(), &sub_item_info, false);
    if (sub_item_info.show_num > sub_item_info.click_num) {
      sub_item_info.ctr = (5.0 + sub_item_info.click_num) / (100.0 + sub_item_info.show_num);
    } else {
      sub_item_info.show_num = 0;
      sub_item_info.click_num = 0;
      sub_item_info.ctr = 0.05;
    }
    sub_item_info.ctr = std::min(sub_item_info.ctr, 0.3f);
    sub_items.push_back(sub_item_info);
  }
  std::sort(sub_items.begin(), sub_items.end(), std::greater<ItemInfo>());
  int total_show_num = 0;
  int total_click_num = 0;
  float subject_ctr = 0.05;
  if (item.show_num > item.click_num) {
    subject_ctr = std::min((5.0 + item.click_num) / (100.0 + item.show_num), 0.2);
  }
  float max_ctr = std::min(subject_ctr, 0.2f);
  float total_itemq_value = 0;
  float total_itemq_num = 0;
  for (int j = 0; j < (int)sub_items.size() && j < kMaxMergeSubItemNum; ++j) {
    ItemInfo &item_info = sub_items[j];
    if (item_info.item_id == 0) continue;
    float weight = 1.0;
    if (j >= 3) {
      weight = std::max(0.0, 0.5 - std::max(0, j - 3) * 0.2);
    }
    total_show_num += item_info.show_num * weight;
    total_click_num += item_info.click_num * weight;
    max_ctr = std::max(max_ctr, item_info.ctr * weight);
    total_itemq_value += item_info.new_itemq * weight;
    total_itemq_num += 1.0 * weight;
  }
  float total_ctr = std::min((5.0 + total_click_num) / (100.0 + total_show_num), 0.3);
  float merge_ctr = std::max(subject_ctr, (float)(total_ctr * 0.5)) * 0.8 + max_ctr * 0.2;
  float itemq = total_itemq_value / (0.0001 + total_itemq_num);

  // XXX: 暂时先把主题的 merge_ctr 存储在 wilson_ctr 字段上
  item.wilson_ctr = merge_ctr;
  item.new_itemq = itemq;

  return true;
}

void SortItem::SortYoukuShowItems(const std::vector<ItemInfo>& youku_show_items,
                                  ShowInfoMap* show_video_index) {
  if (!FLAGS_open_youku_show_sort_switch) return;
  std::vector<ItemInfo> youku_show_items_sorted(youku_show_items);
  std::sort(youku_show_items_sorted.begin(), youku_show_items_sorted.end(), NewsItemSortFunc);

  for (int i = 0; i < (int)youku_show_items_sorted.size(); ++i) {
    const ItemInfo& item = youku_show_items_sorted[i];
    std::string show_id;
    if (news_index_->GetYoukuShowIDByItemId(item.item_id, &show_id)) {
      std::vector<ItemInfo>& show_items = (*show_video_index)[show_id];
      show_items.push_back(item);
    }
  }

  for (auto it = show_video_index->begin(); it != show_video_index->end(); ++it) {
    std::vector<ItemInfo>& show_items = it->second;
    std::sort(show_items.begin(), show_items.end(), ShowItemSortFunc);
  }
}

void SortItem::SortJingpinItems(const std::vector<ItemInfo>& all_items,
                                NewsQueue* queue, int max_save_num) {
  if (FLAGS_target_server == "video_server") return;
  std::vector<ItemInfo>* hit_items = queue->MutableIndex();

  hit_items->clear();
  for (size_t idx = 0; idx < all_items.size(); ++idx) {
    if ((int)hit_items->size() > max_save_num) break;
    const ItemInfo& item = all_items[idx];
    reco::ItemQualityAttr item_quality_attr;
    if (!news_index_->GetItemQualityAttrByItemId(item.item_id, &item_quality_attr))
      continue;
    if (item_quality_attr.manual_jingpin_level() > 0) {
      hit_items->push_back(item);
    }
  }

  std::sort(hit_items->begin(), hit_items->end(), NewsItemSortFunc);

  queue->today_news_num = GetTodayNewsNum(*hit_items);

  LOG(INFO) << "jingpin index update done. "
            << ". qualified item num: " << hit_items->size()
            << ". today item num: " << queue->today_news_num;
}

void SortItem::FillWeMediaItemsDict(
    const std::vector<ItemInfo>& all_items,
    std::unordered_map<std::string, std::unordered_set<uint64>>* wemedia_items_dict) {

  wemedia_items_dict->clear();

  std::unordered_set<uint64> preview_ids;
  std::string wemedia_person;
  for (int i = 0; i < (int)all_items.size(); ++i) {
    const ItemInfo& item_info = all_items[i];
    // 将 item id 填充到对应自媒体人的名下
    if (news_index_->GetWeMediaPersonByDocId(item_info.doc_id, &wemedia_person)) {
      // AddWeMediaItem(wemedia_person, item_info.item_id, wemedia_items_dict);
      (*wemedia_items_dict)[wemedia_person].insert(item_info.item_id);
      continue;
    }
    // 多媒体卡片，该卡片隶属所有子文的自媒体人
    if (item_info.item_type != reco::kWeMediaCard) continue;
    if (!news_index_->GetPreviewIdsByItemId(item_info.item_id, &preview_ids)) continue;
    for (auto id_iter = preview_ids.begin(); id_iter != preview_ids.end(); ++id_iter) {
      if (news_index_->GetWeMediaPersonByDocId(*id_iter, &wemedia_person)) {
        // AddWeMediaItem(wemedia_person, item_info.item_id, wemedia_items_dict);
        (*wemedia_items_dict)[wemedia_person].insert(item_info.item_id);
      }
    }
  }

  LOG(INFO) << "total wemedia person num, " << wemedia_items_dict->size();
}

bool SortItem::IsIndexDictCanSwitch() {
  return (app_index_.CanSwitch()
          // && ucb_index_.CanSwitch()
          && category_index_.CanSwitch()
          // && hot_video_index_.CanSwitch()
          && channel_index_.CanSwitch()
          && region_index_.CanSwitch()
          && poi_index_.CanSwitch()
          && channel_video_index_.CanSwitch()
          && channel_video_explore_index_.CanSwitch()
          && ugc_video_index_.CanSwitch()
          && ugc_video_explore_index_.CanSwitch()
          && channel_video_fully_shown_index_.CanSwitch()
          && video_category_index_.CanSwitch()
          && subject_index_.CanSwitch());
}

void SortItem::GetFilteredItems(std::unordered_set<uint64>* filtered_items) const {
  sim_item_->GetYuanChuangItems(filtered_items);
}

void SortItem::FillSourceRuleChain(std::vector<ItemInfo>* items,
                                   std::unordered_map<uint64, RuleChain>* buffer) {
  for (size_t i = 0; i < items->size(); ++i) {
    uint64 item_id = items->at(i).item_id;
    auto it = buffer->find(item_id);
    if (it != buffer->end()) {
      items->at(i).source_rule_chain = it->second;
      continue;
    }

    std::string source;
    if (!news_index_->GetSourceByItemId(item_id, &source)) {
      continue;
    }

    RuleChain rule;
    if (source_manager_->GetSourceRuleChain(source, &rule)) {
      items->at(i).source_rule_chain = rule;
      buffer->insert(std::make_pair(item_id, rule));
    }
  }
}

void SortItem::ExtractItemFea(const std::vector<ItemInfo>& all_items) {
  serving_base::Timer timer;
  timer.Start();
  for (size_t i = 0; i < all_items.size(); ++i) {
    uint64 item_id = all_items[i].item_id;
    reco::reco_index::WDExtractor::Instance().ExtractItemDynamicFeaByIndex(item_id);
  }
  LOG(INFO) << "extract item dynamic fea time cost : " << timer.Stop();

  reco::reco_index::WDExtractor::Instance().Switch();

  return;
}

void SortItem::ExtractQuantityItems(const std::string& category,
                                    const std::vector<ItemInfo> & items,
                                    const std::vector<ItemInfo> & video_items,
                                    std::vector<ItemInfo>* quantity_items,
                                    std::vector<ItemInfo>* quantity_video_items) {
  quantity_items->clear();
  quantity_video_items->clear();
  base::Time time_thres = base::Time::Now()
      - base::TimeDelta::FromHours(FLAGS_guarantee_deliver_time_threshold_in_hour);
  int64 thres_timestamp = time_thres.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int32 filtered_num = 0;
  int32 other_num = 0;
  for (auto i = 0u; i < items.size(); ++i) {
    double score = 0.0;
    // 如果是 48 小时之前的文章，不进入保量队列
    if (items[i].create_timestamp < thres_timestamp) {
      VLOG(1) << "quantity queue " << items[i].item_id << " " << items[i].create_timestamp
              << " " << thres_timestamp;
      ++filtered_num;
      continue;
    }
    if (MediaQuantityInfoIns::instance().GetItemQuantityScore(
          category, reco::kQueueDoc, items[i], &score)) {
      ItemInfo item = items[i];
      item.media_quantity_score = score;
      // publish
      quantity_items->push_back(item);
    } else {
      ++other_num;
    }
  }
  VLOG(2) << category << " quantity queue size: " << quantity_items->size()
          << " filtered: " << filtered_num << " other:" << other_num;
  other_num = 0;
  for (auto i = 0u; i < video_items.size(); ++i) {
    double score = 0.0;
    if (MediaQuantityInfoIns::instance().GetItemQuantityScore(
          category, reco::kQueueVideo, video_items[i], &score)) {
      ItemInfo item = video_items[i];
      item.media_quantity_score = score;
      quantity_video_items->push_back(item);
    } else {
      ++other_num;
    }
  }
  VLOG(2) << category << " video quantity queue size: " << quantity_video_items->size()
            << " filtered: " << filtered_num << " other:" << other_num;
}

bool SortItem::FinanceStockFilter(const ItemInfo& item) {
  if (item.category != "财经") return false;
  reco::FeatureVector feature_vector;
  news_index_->GetFeatureVectorByItemId(item.item_id, reco::common::FeatureType::kSemanticTag,
                                        &feature_vector);
  bool has_stock_tags = false;
  for (int feature_index = 0; feature_index < feature_vector.feature_size(); ++feature_index) {
    const reco::Feature& feature = feature_vector.feature(feature_index);
    if (feature.literal().find("炒股指南") != std::string::npos) {
      has_stock_tags = true;
      break;
    }
  }
  if (has_stock_tags) {
    return true;
  }
  // 财经频道过滤 股票类自媒体非 SA 机构媒体非 SAB 的文章
  if (item.sub_category == "股票" && item.media_level == kBadMedia) {
    return true;
  }
  return false;
}

void SortItem::PrintItems(const std::vector<ItemInfo>& items) const {
  for (size_t i = 0; i < items.size(); ++i) {
    const ItemInfo& item = items.at(i);
    std::string source;
    std::string title;
    if (!news_index_->GetSourceByDocId(item.doc_id, &source)) {
      source = "source";
    }
    if (!news_index_->GetItemTitleByDocId(item.doc_id, &title)) {
      title = "title";
    }
    // if (item.category != "财经" && item.category != "科技") continue;
    LOG(INFO)
        << base::StringPrintf("DEBUG\t%lu\t%s\t%s\t%d\t%d\t%.4f\t%d\t%d\t%d\t%s\t%s",
                              item.item_id, item.category.c_str(),
                              item.sub_category.c_str(),
                              item.show_num, item.click_num, item.ctr, item.predict_ctr,
                              item.media_level, item.hot_level,
                              source.c_str(), title.c_str());
  }
}

}  // namespace reco
