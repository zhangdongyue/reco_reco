#include <vector>
#include <string>

#include "base/testing/gtest.h"
#include "reco/bizc/reco_index/index_dict_manager.h"

namespace reco {

DECLARE_string(reco_index_dict_dir);
DEFINE_string(news_index_data_dir, "reco/bizc/reco_index/test_data", "index dir for news index data");

class IndexDictManager_Test : public testing::Test {
 public:
  void SetUp() {
    FLAGS_reco_index_dict_dir = "serving/reco/data/reco_leaf/";
    dict_manager_ = IndexDictManager::GetInstance();
  }

 public:
  void TearDown() {
  }
  const IndexDictManager* dict_manager_;
};

TEST_F(IndexDictManager_Test, LoadExtendItemidCategoryFile) {
  auto const item_category_map = dict_manager_->GetExtendItemCategoryMap();
  ASSERT_TRUE(item_category_map != NULL);
  EXPECT_EQ(2u, item_category_map->size());

  uint64 itemid = 10001UL;
  auto iter = item_category_map->find(itemid);
  ASSERT_TRUE(iter != item_category_map->end());
  EXPECT_EQ(iter->second.size(), 1u);
  EXPECT_EQ(iter->second[0], "科技");

  itemid = 10002UL;
  iter = item_category_map->find(itemid);
  ASSERT_TRUE(iter != item_category_map->end());
  EXPECT_EQ(iter->second.size(), 2u);
  EXPECT_EQ(iter->second[0], "体育");
  EXPECT_EQ(iter->second[1], "nba");
}
}  // end of namespace reco

