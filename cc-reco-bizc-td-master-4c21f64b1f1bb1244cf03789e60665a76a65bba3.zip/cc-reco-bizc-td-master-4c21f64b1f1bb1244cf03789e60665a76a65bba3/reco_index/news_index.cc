#include "reco/bizc/reco_index/news_index.h"

#include <functional>
#include <utility>
#include <cmath>
#include <algorithm>
#include <limits>

#include "reco/bizc/common/attr_key_define.h"
#include "reco/bizc/reco_index/sim_item.h"
#include "reco/bizc/reco_index/meta_info_updator.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/time/time.h"
#include "base/math/discrete.h"
#include "base/time/timestamp.h"
#include "base/hash_function/url.h"
#include "base/hash_function/term.h"
#include "base/encoding/line_escape.h"
#include "base/strings/string_split.h"
#include "base/common/basic_types.h"
#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"
#include "base/strings/utf_char_iterator.h"
#include "nlp/common/nlp_util.h"

// DEFINE_int64_counter(index, GetDocsByTagWithType_Num, 0, "GetDocsByTagWithType_Num");
// DEFINE_int64_counter(index, GetDocsByTagWithType_HitCache_Num, 0, "GetDocsByTagWithType_HitCache_Num");

namespace reco {
DEFINE_int32(item_fea_cache_seconds, 1800, "item fea / title 缓存时常，模型大量请求item fea 和 title");
DEFINE_int32(item_ucbsetting_cache_seconds, 60, "item ucb setting cache seconds");
DEFINE_int32(tag_doc_list_cache_seconds, 600, "tag doc list cache seconds");
DEFINE_int32(tag_doc_candidate_size, 100000, "tag doc candidate size");
DEFINE_int32(tag_doc_list_cache_size, 5000, "tag doc list cache size");
DEFINE_int32(tag_doc_async_thread_num, 2, "tag doc async thread num");
DEFINE_bool(simple_init_mode, false, "if set , do not start any updating");

DEFINE_string(news_index_data_dir, "reco/bizc/reco_index/test_data/", "index dir for news index data");
DEFINE_string(target_server, "", "news index target server");
DEFINE_int32(max_feature, 50, "");

#define RELEASE_PTR(name) \
  if (name) { delete name; name = NULL; }

#define CALC_SIGN(attr) \
base::CalcTermSign(attr, strlen(attr))

#define GEN_SIM_ITEM_KEY(item_id) \
base::StringPrintf("SIM-%lu", item_id)

#define GEN_WHOLE_SIM_ITEM_KEY(item_id) \
base::StringPrintf("WSIM-%lu", item_id)

NewsIndex* InitializeNewsIndex(const adsindexing::Index* index) {
  NewsIndex *news_index = new NewsIndex(index);
  return news_index;
}

const int64 NewsIndex::kTimestampInFuture = base::GetTimestamp()
  + base::Time::kMicrosecondsPerDay * 365 * 1000;
const char* NewsIndex::kSourceFile = "source_info.data";

NewsIndex::NewsIndex(const adsindexing::Index* index) {
  using namespace reco::common::attr_key;  // NOLINT
  index_ = index;

  // 一千年以后, 用来判断失效的，不能删
  // 放在 sim 和 meta 启动之前，否则独立线程更新索引的时候，
  // 这个值还没有设置，会引起文档过期

  kExpireTimestampSign = CALC_SIGN(kExpireTimestamp);
  kCreateTimestampSign = CALC_SIGN(kPublishTimestamp);
  kCrawlTimestampSign = CALC_SIGN(kCrawlTimestamp);
  kPublishSecondSign = CALC_SIGN(kPublishTimeInSeconds);

  kItemTypeSign = CALC_SIGN(kItemType);
  kAppTokenSign = CALC_SIGN(kAppToken);
  kOuterIdSign = CALC_SIGN(kOuterId);
  kCategorySign = CALC_SIGN(kCategory);
  kMultiCategorySign = CALC_SIGN(kCategoryCandidates);
  kSourceSign = CALC_SIGN(kSource);
  kOrigSourceSign = CALC_SIGN(kOrigSource);
  kSourceMediaSign = CALC_SIGN(kSourceMedia);
  kOrigSourceMediaSign = CALC_SIGN(kOrigSourceMedia);
  kChannelSign = CALC_SIGN(kChannel);
  kPrioritySign = CALC_SIGN(kPriority);

  kKeywordListSign = CALC_SIGN(kKeywordList);
  kKeywordNormSign = CALC_SIGN(kKeywordNorm);
  kTopicListSign = CALC_SIGN(kTopicList);
  kTopicNormSign = CALC_SIGN(kTopicNorm);
  kPlsaTopicListSign = CALC_SIGN(kPlsaTopicList);
  kPlsaTopicNormSign = CALC_SIGN(kPlsaTopicNorm);
  kTitleLdaTopicListSign = CALC_SIGN(kTitleLdaTopicList);
  kTitleLdaTopicNormSign = CALC_SIGN(kTitleLdaTopicNorm);
  kWordvecListSign = CALC_SIGN(kWordvecList);
  kWordvecNormSign = CALC_SIGN(kWordvecNorm);
  kTagListSign = CALC_SIGN(kTagList);
  kTagNormSign = CALC_SIGN(kTagNorm);
  kSemanticTagListSign = CALC_SIGN(kSemanticTagList);
  kSemanticTagNormSign = CALC_SIGN(kSemanticTagNorm);
  kRegionSign = CALC_SIGN(kRegion);
  kRestrictRegionSign = CALC_SIGN(kRegionRestrict);
  kTitleRegionSign = CALC_SIGN(kRegionFromTitle);
  kRawSummarySign = CALC_SIGN(kRawSummary);
  kSpecialPreviewIdListSign = CALC_SIGN(kSpecialPreviewIdList);
  kSpecialContainIdListSign = CALC_SIGN(kSpecialContainIdList);
  kContentLengthSign = CALC_SIGN(kContentLength);
  kParagraphNumSign = CALC_SIGN(kParagraphNum);
  kUCBSettingSign = CALC_SIGN(kUcBrowserDeliverSetting);
  kItemQualityAttrSign = CALC_SIGN(kItemQualityAttr);
  kPosteriorItemQSign = CALC_SIGN(kPosteriorItemQ);
  kUCBStyleTypeSign = CALC_SIGN(kUcBrowserStyleType);
  kUCBEditorNameSign = CALC_SIGN(kUCBEditorName);
  kNovelIdSign = CALC_SIGN(kNovelId);
  kNovelUpdateTimeSign = CALC_SIGN(kNovelUpdateTime);
  kImageCountSign = CALC_SIGN(kImageCount);
  kVideoCountSign = CALC_SIGN(kVideoCount);
  kVideoLengthSign = CALC_SIGN(kVideoLength);
  kVideoVulgarLevelSign = CALC_SIGN(kVideoVulgarLevel);
  kVideoQualityLevelSign = CALC_SIGN(kVideoQualityLevel);
  kTitleLengthSign = CALC_SIGN(kTitleLength);
  kItemSubscriptsSign = CALC_SIGN(kItemSubscripts);
  kWeMediaPersonSign = CALC_SIGN(kWeMediaPerson);
  kJingpinScoreSign = CALC_SIGN(kJingpinScore);
  kItemIsYuanchuangSign = CALC_SIGN(kItemIsYuanchuang);
  kContentAttrSign = CALC_SIGN(kContentAttr);
  kImageHashSign = CALC_SIGN(kImageHash);
  kParagraphHashSign = CALC_SIGN(kParagraphHash);
  kWholeContentHashKeySign = CALC_SIGN(kSimHash);
  kGaoDePOISign = CALC_SIGN(kGaoDePOI);
  kTimeAxisResultsSign = CALC_SIGN(kTimeAxisResults);
  kItemShowTagSign = CALC_SIGN(kItemShowTag);
  kHasVideoStorageInfoSign = CALC_SIGN(kHasVideoStorageInfo);
  kVideoStorageInfoStatusSign= CALC_SIGN(kVideoStorageInfoStatus);
  kYoukuVideoIdSign = CALC_SIGN(kYoukuVideoId);
  kItemHasReviewedSign = CALC_SIGN(kItemHasReviewed);
  kVideoBlackEdgeRatioSign = CALC_SIGN(kVideoBlackEdgeRatio);
  kVideoPosterProblemInfoSign = CALC_SIGN(kVideoPosterProblemInfo);
  kVideoPosterClaritySign = CALC_SIGN(kVideoPosterClarity);
  kItemEventTagSign = CALC_SIGN(kItemEventTag);
  kItemEventTagInfoSign = CALC_SIGN(kItemEventTagInfo);
  kVideoPlayControlSign = CALC_SIGN(kVideoPlayControl);
  kOrigMediaRiskTypeSign = CALC_SIGN(kOrigMediaRiskType);
  kManualNewsSign = CALC_SIGN(kManualNews);
  kYoukuShowIDSign = CALC_SIGN(kYoukuShowID);
  kYoukuAuditStatusSign = CALC_SIGN(kYoukuAuditStatus);
  kSubjectItemsSign = CALC_SIGN(kSubjectSubItems);
  kLocalBreakingSign = CALC_SIGN(kLocalBreaking);
  kGroupInfoSign = CALC_SIGN(kGroupInfo);
  kVideoWidthSign = CALC_SIGN(kVideoWidth);
  kVideoHeightSign = CALC_SIGN(kVideoHeight);
  kVideoColorsSign = CALC_SIGN(kVideoColors);
  kAppTokenBitsSign = CALC_SIGN(kAppTokenBits);
  kAppTokenRuleBitsSign = CALC_SIGN(kAppTokenRuleBits);
  kFirstNScreenFilterSign = CALC_SIGN(kFirstNScreenFilter);
  kSourcePublishPlatformSign = CALC_SIGN(kSourcePublishPlatform);
  kVideoResolutionSign = CALC_SIGN(kVideoResolution);
  kItemAttachDataExtSign = CALC_SIGN(kItemAttachDataExt);

  item_fea_expiry_map_ =
      new serving_base::ExpiryMap<std::string, reco::FeatureVector>(FLAGS_item_fea_cache_seconds);
  item_unigram_expiry_map_ =
      new serving_base::ExpiryMap<std::string, std::vector<std::string> >(FLAGS_item_fea_cache_seconds);
  item_ucbsetting_expiry_map_ =
      new serving_base::ExpiryMap<uint64, UcBrowserDeliverSetting>(FLAGS_item_ucbsetting_cache_seconds);
  item_quality_expiry_map_ =
      new serving_base::ExpiryMap<uint64, ItemQualityAttr>(FLAGS_item_fea_cache_seconds);
  item_title_core_tags_expiry_map_ =
      new serving_base::ExpiryMap<uint64, std::vector<std::string> >(FLAGS_item_fea_cache_seconds);
  tag_doc_list_expiry_map_ =
      new serving_base::ExpiryMap<std::string, std::vector<int32> >(FLAGS_tag_doc_list_cache_seconds);
  item_attach_data_ext_expiry_map_ =
      new serving_base::ExpiryMap<uint64, ItemAttachDataExt>(FLAGS_item_fea_cache_seconds);

  dict_manager_ = IndexDictManager::GetInstance();

  DynamicDictContainer::RegisterAndLoadAllDict();

  if (FLAGS_simple_init_mode) {
    LOG(WARNING) << "donot start any updating!";
    return;
  }

  sim_item_ = new SimItem();
  sim_item_->Start();

  /*
  origin_info_updator_ = new OriginInfoUpdator(this);
  thread::Thread load_origin_info_thread;
  load_origin_info_thread.Start(NewCallback(origin_info_updator_, &OriginInfoUpdator::Start));
  */

  // meta_info_updator_ = new MetaInfoUpdator(this, sim_item_, origin_info_updator_);
  meta_info_updator_ = new MetaInfoUpdator(this, sim_item_);
  base::FilePath path = base::FilePath(FLAGS_news_index_data_dir);
  thread::Thread load_meta_info_thread;
  load_meta_info_thread.Start(NewCallback<MetaInfoUpdator, const base::FilePath&>
                              (meta_info_updator_, &MetaInfoUpdator::Start, path));

  /*
  video_stat_info_updator_ = new VideoStatInfoUpdator(this);
  thread::Thread load_video_stat_info_thread;
  load_video_stat_info_thread.Start(NewCallback(video_stat_info_updator_, &VideoStatInfoUpdator::Start));
  */

  source_manager_ = new SourceManager();
  source_manager_->StartMonitorFile(base::FilePath(FLAGS_news_index_data_dir).Append(kSourceFile));


  load_meta_info_thread.Join();
  // load_video_stat_info_thread.Join();
  multi_category_cache_ = new MultiCategoryCache();
  sort_item_ = new SortItem(this, sim_item_, source_manager_);
  tag_async_pool = new thread::ThreadPool(FLAGS_tag_doc_async_thread_num);
  for (int i = 0; i < FLAGS_tag_doc_async_thread_num; ++i) {
    tag_async_pool->AddTask(::NewCallback(this, &NewsIndex::AsyncProcessTag));
  }
  tag_call_num_ = 0;
  tag_hit_cache_num_ = 0;
  last_tag_hit_cache_num_ = 0;
}

NewsIndex::~NewsIndex() {
  LOG(INFO) << "news index destructor.";

  tag_queue_.Close();
  tag_async_pool->JoinAll();
  RELEASE_PTR(tag_async_pool);

  RELEASE_PTR(sort_item_);
  // RELEASE_PTR(video_stat_info_updator_);

  sim_item_->Stop();
  RELEASE_PTR(sim_item_);
  RELEASE_PTR(meta_info_updator_);
  // RELEASE_PTR(origin_info_updator_);

  /*
  RELEASE_PTR(item_fea_expiry_map_);
  RELEASE_PTR(item_unigram_expiry_map_);
  RELEASE_PTR(item_ucbsetting_expiry_map_);
  RELEASE_PTR(item_quality_expiry_map_);
  RELEASE_PTR(item_title_core_tags_expiry_map_);
  RELEASE_PTR(tag_doc_list_expiry_map_);
  RELEASE_PTR(item_attach_data_ext_expiry_map_);
  source_manager_->StopMonitorFile();
  RELEASE_PTR(source_manager_);
  */
}

//////////////////////////////////////////////////////////////////////////
// // News Index 相关
int NewsIndex::GetTodayNewsNum(const std::vector<ItemInfo>& item_list) {
  base::Time now = base::Time::Now();
  base::Time::Exploded exploded;
  now.LocalExplode(&exploded);
  int end_day = exploded.day_of_month;
  int end_month = exploded.month;

  int today_news = 0;
  for (int i = 0; i < (int)item_list.size(); ++i) {
    if (!IsValidByDocId(item_list[i].doc_id)) continue;
    int64 timestamp = GetCreateTimestampByDocId(item_list[i].doc_id);
    if (timestamp == 0) continue;

    base::Time item_time = base::Time::FromDoubleT(timestamp / base::Time::kMicrosecondsPerSecond);
    item_time.LocalExplode(&exploded);
    if (end_day == exploded.day_of_month && end_month == exploded.month) {  // 当天新闻
      ++today_news;
    }
  }
  return today_news;
}

void NewsIndex::GetDocsByItemType(int32 item_type, std::vector<int32>* doc_id_list) const {
  doc_id_list->clear();
  std::string aterm = reco::common::GetItemTypePayloadTerm(item_type);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(aterm, adsindexing::kUnigramTerm));
  if (doc_iter.get() == NULL) {
    LOG(ERROR) << "no doc hit item type " << item_type;
    return;
  }
  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
  }
}

void NewsIndex::GetDocsByCategory(const std::string& category, int level,
                                  std::vector<int32>* doc_id_list,
                                  uint64 max_return_size) const {
  doc_id_list->clear();
  std::string cterm = reco::common::GetCategoryPayloadTerm(category, level);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(cterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    VLOG(1) << base::StringPrintf("no doc hit category: %s in level: %d", category.c_str(), level);
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
    if (max_return_size > 0 && doc_id_list->size() >= max_return_size) {
      break;
    }
  }
}

void NewsIndex::GetDocsByMultiCategory(const std::string& category, int level,
                                       std::vector<int32>* doc_id_list) const {
  doc_id_list->clear();
  std::string mcterm = reco::common::GetCategoryCandidatesPayloadTerm(category, level);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(mcterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    LOG(ERROR) << base::StringPrintf("no doc hit  category: %s in level: %d", category.c_str(), level);
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
  }
}

void NewsIndex::GetDocsByChannelId(uint64 channel_id, std::vector<int32>* doc_id_list) const {
  doc_id_list->clear();
  std::string sterm = reco::common::GetChannelPayloadTerm(channel_id);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(sterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    LOG(ERROR) << base::StringPrintf("no doc hit  channel_id: %lu",
      channel_id);
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
  }
}
void NewsIndex::GetDocsByAppToken(const std::string& app_token, std::vector<int32>* doc_id_list) const {
  doc_id_list->clear();
  std::string sterm = reco::common::GetAppTokenPayloadTerm(app_token);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(sterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    LOG(ERROR) << base::StringPrintf("no doc hit  app_token: %s",
      app_token.c_str());
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
  }
}

void NewsIndex::GetDocsByRegionID(const std::string &region_id, std::vector<int32>* doc_id_list) const {
  doc_id_list->clear();
  std::string tterm = reco::common::GetRegionIDPayloadTerm(region_id);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(tterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    LOG(ERROR) << base::StringPrintf("no doc hit  region_id: %s", region_id.c_str());
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
  }
}

void NewsIndex::SetTagCache(const std::string& tag, std::vector<int32>* doc_id_list) {
  if (doc_id_list == NULL) {
    return;
  }
  thread::AutoLock lock(&tag_mutex_);
  tag_doc_list_expiry_map_->Add(tag, *doc_id_list);
}

bool NewsIndex::GetTagCache(const std::string& tag, std::vector<int32>* doc_id_list) const {
  if (doc_id_list == NULL) {
    return false;
  }
  if (tag_doc_list_expiry_map_->FindSilently(tag, doc_id_list)) {
    return true;
  }
  return false;
}

void NewsIndex::AsyncProcessTag() {
  while (!tag_queue_.Closed() || !tag_queue_.Empty()) {
    std::string tag;
    if (tag_queue_.Empty()) {
      // LOG(INFO) << "[tag_hit] tag queue empty";
      base::SleepForSeconds(1);
      continue;
    }
    int status = tag_queue_.TimedTake(10, &tag);
    // LOG(INFO) << "[tag_hit] get tag from queue: " << tag;
    // LOG(INFO) << "[tag_hit] tag_queue size : " << tag_queue_.Size();

    if (status != 1) {
      LOG(ERROR) << "[tag_hit] unknown erro occured: " << status;
      continue;
    }
    std::vector<int32> doc_id_list;
    if (GetTagCache(tag, &doc_id_list)) {
      // LOG(INFO) << "[tag_hit] tag hit, not process : " << tag;
      continue;
    }
    doc_id_list.clear();
    std::string tterm;
    if (base::StartsWith(tag, "label:", true)) {
      tterm = reco::common::GetFeaturePayloadTerm(tag, reco::common::kTag);
    } else {
      tterm = reco::common::GetFeaturePayloadTerm("label:" + tag, reco::common::kTag);
    }
    {
      scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(tterm, adsindexing::kUnigramTerm));

      if (doc_iter.get() == NULL) {
        LOG(WARNING) << "[tag_hit] no doc hit tag: " + tag << ",ttterm: " << tterm;
        continue;
      }
      while (!doc_iter->Done()) {
        int doc = doc_iter->GetDocLocalId();
        doc_id_list.push_back(doc);
        doc_iter->Next();
        if (FLAGS_tag_doc_candidate_size > 0 && (int)doc_id_list.size() >= FLAGS_tag_doc_candidate_size) {
          break;
        }
      }
    }
    std::vector<int32> cache_id_list;
    for (size_t i = 0; i < doc_id_list.size(); ++i) {
      int32 doc = doc_id_list.at(i);
      reco::ItemType doc_item_type;
      if (GetItemTypeByDocId(doc, &doc_item_type) &&
          doc_item_type != reco::kPureVideo) {
        continue;
      }
      cache_id_list.push_back(doc);
      if (FLAGS_tag_doc_list_cache_size > 0 && (int)cache_id_list.size() >= FLAGS_tag_doc_list_cache_size) {
        break;
      }
    }
    SetTagCache(tag, &cache_id_list);
    // LOG(INFO) << "[tag_hit] tag cache set, tag : " << tag << " list size : " << cache_id_list.size();
  }
}

void NewsIndex::GetDocsByTag(const std::string& tag, std::vector<int32>* doc_id_list,
                             uint64 max_return_size) const {
  doc_id_list->clear();
  std::string tterm;
  if (base::StartsWith(tag, "label:", true)) {
    tterm = reco::common::GetFeaturePayloadTerm(tag, reco::common::kTag);
  } else {
    tterm = reco::common::GetFeaturePayloadTerm("label:" + tag, reco::common::kTag);
  }
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(tterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    LOG(WARNING) << "no doc hit tag: " + tag << ",ttterm: " << tterm;
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
    if (max_return_size > 0 && doc_id_list->size() >= max_return_size) {
      break;
    }
  }
}

void NewsIndex::GetDocsByTag(const std::string& tag, std::vector<int32>* doc_id_list,
                             reco::ItemType item_type,
                             uint64 max_return_size) const {
  // COUNTERS_index__GetDocsByTagWithType_Num.Increase(1);
  std::atomic<int64>& num = const_cast<std::atomic<int64>& >(tag_call_num_);
  ++num;
  if (num % 1000 == 0) {
    std::atomic<int64>& last_num = const_cast<std::atomic<int64>& >(last_tag_hit_cache_num_);
    int64 hit_num = const_cast<std::atomic<int64>& >(tag_hit_cache_num_);
    int64 diff_num = tag_hit_cache_num_ - last_num;
    last_num = hit_num;
    std::atomic<int32>& hit_percent = const_cast<std::atomic<int32>& >(tag_hit_percent_);
    double hit_ratio = (double)(diff_num) / 1000.0;
    hit_percent = (int32)(hit_ratio * 100);
    LOG(INFO) << "[tag_hit] call num : " << num
              <<" hit num : " << tag_hit_cache_num_
              <<" diff num : " << diff_num
              <<" hit ratio : " << hit_ratio
              <<" hit percent : " << hit_percent;
  }
  if (item_type == reco::kPureVideo) {
    std::vector<int32> res_list;
    if (GetTagCache(tag, &res_list)) {
      doc_id_list->swap(res_list);
      // COUNTERS_index__GetDocsByTagWithType_HitCache_Num.Increase(1);
      std::atomic<int64>& tag_num = const_cast<std::atomic<int64>& >(tag_hit_cache_num_);
      ++tag_num;
      return;
    } else {
      std::string& msg = const_cast<std::string&>(tag);
      thread::BlockingQueue<std::string>& queue =
          const_cast<thread::BlockingQueue<std::string>& >(tag_queue_);
      queue.Put(msg);
      // LOG(INFO) << "[tag_hit] put tag in queue : " << msg;
    }
  }
  if (tag_hit_percent_ < 80) {
    std::vector<int32> swap_doc_id_list;
    GetDocsByTag(tag, &swap_doc_id_list, max_return_size);
    for (size_t i = 0; i < swap_doc_id_list.size(); ++i) {
      reco::ItemType doc_item_type;
      if (GetItemTypeByDocId(swap_doc_id_list.at(i), &doc_item_type) &&
          doc_item_type == item_type) {
        doc_id_list->push_back(swap_doc_id_list.at(i));
      }
    }
  }
}

void NewsIndex::GetDocsByEventTag(const std::string& tag, std::vector<int32>* doc_id_list,
                                  uint64 max_return_size) const {
  doc_id_list->clear();
  std::string tterm = reco::common::GetEventTagPayloadTerm(tag);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(tterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    LOG(WARNING) << "no doc hit tag: " + tag << ",ttterm: " << tterm;
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
    if (max_return_size > 0 && doc_id_list->size() >= max_return_size) {
      break;
    }
  }
}

void NewsIndex::GetDocsByShowTag(const std::string& tag,
                                 std::vector<int32>* doc_id_list, uint64 max_return_size) const {
  doc_id_list->clear();
  std::string tterm = reco::common::GetShowTagPayloadTerm(tag);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(tterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    LOG(WARNING) << "no doc hit tag: " + tag << ",ttterm: " << tterm;
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
    if (max_return_size > 0 && doc_id_list->size() >= max_return_size) {
      break;
    }
  }
}

void NewsIndex::GetDocsBySource(const std::string& source,
                                std::vector<int32>* doc_id_list, uint64 max_return_size) const {
  doc_id_list->clear();
  // source
  std::string sterm = reco::common::GetSourcePayloadTerm(source);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(sterm, adsindexing::kUnigramTerm));
  if (doc_iter == NULL) {
    VLOG(1) << base::StringPrintf("no doc hit  source: %s", source.c_str());
    return;
  }
  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
    if (max_return_size > 0 && doc_id_list->size() >= max_return_size) {
      break;
    }
  }
}

void NewsIndex::GetDocsByWeMedia(std::vector<int32>* doc_id_list) const {
  doc_id_list->clear();
  std::string tterm = reco::common::GetWeMediaPayloadTerm();
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(tterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    LOG(ERROR) << base::StringPrintf("no doc is wemedia");
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
  }
}

void NewsIndex::GetDocsByTerm(const std::string& term, std::vector<int32>* doc_id_list) const {
  doc_id_list->clear();
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(term, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    // LOG(WARNING) << "no doc hit term: " << term;
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
  }
}

void NewsIndex::GetDocsByKeywordOrTag(const std::string& word, std::vector<int32>* doc_id_list) const {
  doc_id_list->clear();
  std::string tterm;
  if (base::StartsWith(word, "label:", true)) {
    tterm = reco::common::GetFeaturePayloadTerm(word, reco::common::kTag);
  } else {
    tterm = reco::common::GetFeaturePayloadTerm("label:" + word, reco::common::kTag);
  }

  adsindexing::DocIterator* doc_iter1 = index_->NewDocIterator(tterm, adsindexing::kUnigramTerm);
  if (doc_iter1 == NULL) {
    LOG(ERROR) << "no doc hit tag: " + word << ",ttterm: " << tterm;
  }
  scoped_ptr<adsindexing::DocIterator> doc_iter1_ptr(doc_iter1);

  std::string wterm = reco::common::GetFeaturePayloadTerm(word, reco::common::kKeyword);
  adsindexing::DocIterator* doc_iter2 = index_->NewDocIterator(wterm, adsindexing::kUnigramTerm);
  if (doc_iter2 == NULL) {
    LOG(ERROR) << "no doc hit keyword: " + word << ",ttterm: " << wterm;
  }
  scoped_ptr<adsindexing::DocIterator> doc_iter2_ptr(doc_iter2);

  UnionDocs(doc_iter1, doc_iter2, doc_id_list, 0);
}

bool NewsIndex::GetTitleLdaTopicByItemId(uint64 item_id, reco::FeatureVector* feature) const {
  if (!GetFeatureVectorByItemId(item_id, reco::common::kTitleLdaTopic, feature)) {
    return false;
  }
  return true;
}

void NewsIndex::GetDocsByTitleLdaTopic(const std::string& topic,
                                       std::vector<int32>* doc_id_list,
                                       uint64 max_return_size) const {
  doc_id_list->clear();
  std::string nterm = reco::common::GetTitleLdaTopicPayloadTerm(topic);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(nterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    LOG(WARNING) << "no doc hit lda topic: " << topic << ", nterm: " << nterm;
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
    if (max_return_size > 0 && doc_id_list->size() >= max_return_size) {
      break;
    }
  }
}

bool NewsIndex::GetVideoTagFeatureVectorByItemId(uint64 item_id, reco::FeatureVector* feature) const {
  reco::FeatureVector raw_feature;
  if (!GetFeatureVectorByItemId(item_id, reco::common::kTag, &raw_feature)) {
    return false;
  }
  ParseVideoTagFeatureVector(item_id, raw_feature, feature);
  return true;
}

bool NewsIndex::GetFeatureVectorByItemId(uint64 item_id, reco::common::FeatureType type,
                                         reco::FeatureVector* feature) const {
  std::string cache_key = base::StringPrintf("%lu_%d", item_id, type);
  if (item_fea_expiry_map_->FindSilently(cache_key, feature)) {
    return true;
  }
  using namespace reco::common;  // NOLINT
  int32 doc_id;
  if (!GetDocIdByItemId(item_id, &doc_id)) {
    return false;
  }
  reco::ItemType item_type;
  if (!GetItemTypeByDocId(doc_id, &item_type)) {
    return false;
  }

  std::string keys;
  float norm = 0;
  switch (type) {
    case kKeyword:
      keys = index_->GetStringAttr(kKeywordListSign, doc_id, "");
      norm = index_->GetFloatAttr(kKeywordNormSign, doc_id, 0);
      break;
    case kTopic:
      keys = index_->GetStringAttr(kTopicListSign, doc_id, "");
      norm = index_->GetFloatAttr(kTopicNormSign, doc_id, 0);
      break;
    case kPlsaTopic:
      keys = index_->GetStringAttr(kPlsaTopicListSign, doc_id, "");
      norm = index_->GetFloatAttr(kPlsaTopicNormSign, doc_id, 0);
      break;
    case kTitleLdaTopic:
      keys = index_->GetStringAttr(kTitleLdaTopicListSign, doc_id, "");
      norm = index_->GetFloatAttr(kTitleLdaTopicNormSign, doc_id, 0);
      break;
    case kWordvec:
      keys = index_->GetStringAttr(kWordvecListSign, doc_id, "");
      norm = index_->GetFloatAttr(kWordvecNormSign, doc_id, 0);
      break;
    case kTag:
      keys = index_->GetStringAttr(kTagListSign, doc_id, "");
      norm = index_->GetFloatAttr(kTagNormSign, doc_id, 0);
      break;
    case kSemanticTag:
      keys = index_->GetStringAttr(kSemanticTagListSign, doc_id, "");
      norm = index_->GetFloatAttr(kSemanticTagNormSign, doc_id, 0);
      break;
    default:
      return false;
  }
  if (keys == "" || norm < 1e-7) {
    return false;
  }
  std::vector<std::string> key_list;
  base::SplitString(keys, "\t", &key_list);
  feature->Clear();
  for (int i = 0; i < (int)key_list.size(); ++i) {
    const std::string& key = key_list[i];
    auto fea = feature->add_feature();
    fea->set_item_type(item_type);
    fea->set_weight(index_->GetFloatAttr(key, doc_id, 0));
    fea->set_literal(key);
  }
  feature->set_norm(norm);
  item_fea_expiry_map_->Add(cache_key, *feature);
  return true;
}

void NewsIndex::ParseVideoTagFeatureVector(uint64 item_id,
                                           const reco::FeatureVector& raw_feature,
                                           reco::FeatureVector *real_feature) const {
  real_feature->Clear();
  bool manual_checked = false;
  for (int i = 0; i < raw_feature.feature_size(); ++i) {
    const std::string &raw_tag = raw_feature.feature(i).literal();
    std::vector<std::string> tokens;
    base::SplitString(raw_tag, ":", &tokens);
    if (tokens.size() > 1 && tokens[0] == "manual") {
      manual_checked = true;
      break;
    }
  }
  for (int i = 0; i < raw_feature.feature_size(); ++i) {
    const std::string &raw_tag = raw_feature.feature(i).literal();
    std::vector<std::string> tokens;
    base::SplitString(raw_tag, ":", &tokens);
    std::string real_tag = "";
    if (tokens.size() <= 1) {
      // 没有前缀的直接认为是正确的 tag
      real_tag = tokens[0];
    } else if (!manual_checked && (tokens[0] == "label" || tokens[0] == "manual")) {
      real_tag = tokens[1];
    } else if (manual_checked && tokens[0] == "manual") {
      real_tag = tokens[1];
    }
    if (!real_tag.empty()) {
      auto fea = real_feature->add_feature();
      fea->CopyFrom(raw_feature.feature(i));
      fea->set_literal(real_tag);
    }
  }
}

bool NewsIndex::GetFeatureMapByDocId(int32 doc_id, reco::common::FeatureType type,
                                     std::map<std::string, double>* feature,
                                     double* norm2) const {
  using namespace reco::common;  // NOLINT
  std::string keys;
  float norm = 0;
  switch (type) {
    case kKeyword:
      keys = index_->GetStringAttr(kKeywordListSign, doc_id, "");
      norm = index_->GetFloatAttr(kKeywordNormSign, doc_id, 0);
      break;
    case kTopic:
      keys = index_->GetStringAttr(kTopicListSign, doc_id, "");
      norm = index_->GetFloatAttr(kTopicNormSign, doc_id, 0);
      break;
    case kPlsaTopic:
      keys = index_->GetStringAttr(kPlsaTopicListSign, doc_id, "");
      norm = index_->GetFloatAttr(kPlsaTopicNormSign, doc_id, 0);
      break;
    case kWordvec:
      keys = index_->GetStringAttr(kWordvecListSign, doc_id, "");
      norm = index_->GetFloatAttr(kWordvecNormSign, doc_id, 0);
      break;
    case kTag:
      keys = index_->GetStringAttr(kTagListSign, doc_id, "");
      norm = index_->GetFloatAttr(kTagNormSign, doc_id, 0);
      break;
    case kSemanticTag:
      keys = index_->GetStringAttr(kSemanticTagListSign, doc_id, "");
      norm = index_->GetFloatAttr(kSemanticTagNormSign, doc_id, 0);
      break;
    default:
      return false;
  }
  if (keys == "" || norm < 1e-7) {
    return false;
  }
  std::vector<std::string> key_list;
  base::SplitString(keys, "\t", &key_list);
  feature->clear();
  for (int i = 0; i < (int)key_list.size(); ++i) {
    const std::string& key = key_list[i];
    float weight = index_->GetFloatAttr(key, doc_id, 0);
    feature->insert(std::make_pair(key, weight));
  }
  *norm2 = norm;
  return true;
}

bool NewsIndex::GetFeatureStringByDocId(int32 doc_id, reco::common::FeatureType type,
  std::string* literal, std::string* feature_str, double* norm2) const {
  using namespace reco::common;  // NOLINT
  std::string keys;
  float norm = 0;
  switch (type) {
    case kKeyword:
      keys = index_->GetStringAttr(kKeywordListSign, doc_id, "");
      norm = index_->GetFloatAttr(kKeywordNormSign, doc_id, 0);
      break;
    case kTopic:
      keys = index_->GetStringAttr(kTopicListSign, doc_id, "");
      norm = index_->GetFloatAttr(kTopicNormSign, doc_id, 0);
      break;
    case kPlsaTopic:
      keys = index_->GetStringAttr(kPlsaTopicListSign, doc_id, "");
      norm = index_->GetFloatAttr(kPlsaTopicNormSign, doc_id, 0);
      break;
    case kWordvec:
      keys = index_->GetStringAttr(kWordvecListSign, doc_id, "");
      norm = index_->GetFloatAttr(kWordvecNormSign, doc_id, 0);
      break;
    case kTag:
      keys = index_->GetStringAttr(kTagListSign, doc_id, "");
      norm = index_->GetFloatAttr(kTagNormSign, doc_id, 0);
      break;
    case kSemanticTag:
      keys = index_->GetStringAttr(kSemanticTagListSign, doc_id, "");
      norm = index_->GetFloatAttr(kSemanticTagNormSign, doc_id, 0);
      break;
    default:
      return false;
  }
  if (keys == "" || norm < 1e-7) {
    return false;
  }

  *literal = keys;

  std::vector<std::string> key_list;
  base::SplitString(keys, "\t", &key_list);

  std::ostringstream oss;
  for (int i = 0; i < (int)key_list.size(); ++i) {
    const std::string& key = key_list[i];
    float weight = index_->GetFloatAttr(key, doc_id, 0);
    oss << std::setiosflags(std::ios::fixed) << std::setprecision(6) << weight;

    if (i != (int)key_list.size()-1) {
      oss << "\t";
    }
  }

  *feature_str = oss.str();
  *norm2 = norm;

  return true;
}

void NewsIndex::GetCategories(int level, std::vector<reco::Category>* categories) const {
  return sort_item_->GetCategories(level, categories);
}

void NewsIndex::GetVideoCategories(int level, std::vector<reco::Category>* categories) const {
  return sort_item_->GetVideoCategories(level, categories);
}

bool NewsIndex::GetUCBSettingByItemId(uint64 item_id, UcBrowserDeliverSetting* ucb_setting) const {
  CHECK_NOTNULL(ucb_setting);
  if (item_ucbsetting_expiry_map_->FindSilently(item_id, ucb_setting)) {
    return true;
  }

  int32 doc_id = 0;
  bool suc = GetDocIdByItemId(item_id, &doc_id);
  if (!suc) return false;

  std::string attr = index_->GetStringAttr(kUCBSettingSign, doc_id, "");
  if (attr.empty()) return false;
  if (!ucb_setting->ParseFromString(attr)) return false;

  item_ucbsetting_expiry_map_->Add(item_id, *ucb_setting);
  return true;
}

bool NewsIndex::GetItemTitleByItemId(uint64 item_id, std::string* title) const {
  std::vector<std::string> unigrams;
  if (!GetAreaUnigramsByItemId(item_id, adsindexing::kTitleArea, &unigrams)) return false;
  base::FastJoinStrings(unigrams, "", title);
  return true;
}

bool NewsIndex::GetItemTitleByDocId(int32 doc_id, std::string* title) const {
  std::vector<std::string> unigrams;
  if (!GetAreaUnigramsByDocId(doc_id, adsindexing::kTitleArea, &unigrams)) return false;
  base::FastJoinStrings(unigrams, "", title);
  return true;
}

bool NewsIndex::ContainInCategoryQueue(const reco::Category& category, int32 doc_id) const {
  return sort_item_->ContainInCategoryQueue(category, doc_id);
}

void NewsIndex::GetDocsByContentAttr(const reco::ContentAttr& attr,
                                     std::vector<int32>* doc_id_list) const {
  // 非 0 的位设置 mask
  uint64 mask = reco::common::ContentAttrMask(attr);
  uint64 attr_bit = 0;
  reco::common::PackContentAttr(attr, &attr_bit);
  uint64 masked_val = mask & attr_bit;
  std::set<uint64> bits;
  for (uint64 i = 1; i < (1 << reco::common::kMaxAttrShift); ++i) {
    // mask 的位取传入的值，其他位取循环值
    bits.insert((i & (~mask)) | masked_val);
  }

  std::vector<int32> doc_ids;
  for (auto it = bits.begin(); it != bits.end(); ++it) {
    std::string term = reco::common::GetContentAttrPayloadTerm(*it);
    std::vector<int32> tmp;
    GetDocsByTerm(term, &tmp);
    if (tmp.empty()) continue;

    std::vector<int32> old;
    old.swap(doc_ids);
    doc_ids.resize(old.size() + tmp.size());
    std::merge(tmp.begin(), tmp.end(), old.begin(), old.end(), doc_ids.begin());
  }
  auto it = std::unique(doc_ids.begin(), doc_ids.end());
  doc_ids.resize(std::distance(doc_ids.begin(), it));
  std::swap(*doc_id_list, doc_ids);
}

void NewsIndex::GetDocsBySpiderQuery(const std::string& query, std::vector<int32>* doc_id_list) const {
  doc_id_list->clear();
  std::string sterm = reco::common::GetSpiderQueryPayloadTerm(query);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(sterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
  }
}

void NewsIndex::GetDocsByNovelId(const std::string& novel_id,
                                 std::vector<int32>* doc_id_list,
                                 uint64 max_return_size) const {
  doc_id_list->clear();
  std::string nterm = reco::common::GetNovelIdPayloadTerm(novel_id);
  scoped_ptr<adsindexing::DocIterator> doc_iter(index_->NewDocIterator(nterm, adsindexing::kUnigramTerm));

  if (doc_iter.get() == NULL) {
    LOG(WARNING) << "no doc hit novel id: " << novel_id << ", nterm: " << nterm;
    return;
  }

  while (!doc_iter->Done()) {
    int doc = doc_iter->GetDocLocalId();
    doc_id_list->push_back(doc);
    doc_iter->Next();
    if (max_return_size > 0 && doc_id_list->size() >= max_return_size) {
      break;
    }
  }
}

void NewsIndex::MixDocs(adsindexing::DocIterator* doc_iter1,
                        adsindexing::DocIterator* doc_iter2,
                        std::vector<int32>* doc_id_list, size_t max_num) const {
  if (doc_iter1 != NULL && doc_iter2 != NULL) {
    while (!doc_iter1->Done() && !doc_iter2->Done()) {
      if (max_num > 0 && doc_id_list->size() >= max_num) break;
      int doc1 = doc_iter1->GetDocLocalId();
      int doc2 = doc_iter2->GetDocLocalId();
      if (doc1 == doc2) {
        doc_id_list->push_back(doc1);
        doc_iter1->Next();
        doc_iter2->Next();
      } else if (doc1 < doc2) {
        doc_iter1->Next();
      } else {
        doc_iter2->Next();
      }
    }
  }
}

void NewsIndex::UnionDocs(adsindexing::DocIterator* doc_iter1,
                          adsindexing::DocIterator* doc_iter2,
                          std::vector<int32>* doc_id_list, size_t max_num) const {
  if (doc_iter1 != NULL && doc_iter2 != NULL) {
    while (!doc_iter1->Done() && !doc_iter2->Done()) {
      if (max_num > 0 && doc_id_list->size() >= max_num) break;
      int doc1 = doc_iter1->GetDocLocalId();
      int doc2 = doc_iter2->GetDocLocalId();
      if (doc1 == doc2) {
        doc_id_list->push_back(doc1);
        doc_iter1->Next();
        doc_iter2->Next();
      } else if (doc1 < doc2) {
        doc_id_list->push_back(doc1);
        doc_iter1->Next();
      } else {
        doc_id_list->push_back(doc2);
        doc_iter2->Next();
      }
    }
  }

  if (doc_iter1 != NULL) {
    while (!doc_iter1->Done()) {
      if (max_num > 0 && doc_id_list->size() >= max_num) break;
      int doc1 = doc_iter1->GetDocLocalId();
      doc_id_list->push_back(doc1);
      doc_iter1->Next();
    }
  }

  if (doc_iter2 != NULL) {
    while (!doc_iter2->Done()) {
      if (max_num > 0 && doc_id_list->size() >= max_num) break;
      int doc2 = doc_iter2->GetDocLocalId();
      doc_id_list->push_back(doc2);
      doc_iter2->Next();
    }
  }
}

int NewsIndex::GetItemIndex(uint64 item_id) const {
  return sort_item_->GetItemIndex(item_id);
}

const ItemFea& NewsIndex::GetItemFea(int index) const {
  return sort_item_->GetItemFea(index);
}

void NewsIndex::SetItemAttr(uint64 item_id, ItemsFeature& items_feature) const {
  auto iter = items_feature.items_index.find(item_id);

  if (iter != items_feature.items_index.end()) {
    return;
  }
  ItemFea item_feature;
  // keyword
  reco::FeatureVector keyword;
  GetFeatureVectorByItemId(item_id, reco::common::kKeyword, &keyword);
  for (int i = 0; i < keyword.feature_size() && i < FLAGS_max_feature; ++i) {
    auto& item_fea = keyword.feature(i);
    if (item_fea.literal().empty()) continue;
    item_feature.keyword_info.push_back(std::pair<std::string, float>(item_fea.literal(), item_fea.weight()));
  }
  // tag
  reco::FeatureVector tag;
  GetFeatureVectorByItemId(item_id, reco::common::kTag, &tag);
  for (int i = 0; i < tag.feature_size() && i < FLAGS_max_feature; ++i) {
    auto& item_fea = tag.feature(i);
    if (item_fea.literal().empty()) continue;
    item_feature.tag_info.push_back(std::pair<std::string, float>(item_fea.literal(), item_fea.weight()));
  }

  // topic
  reco::FeatureVector topic;
  GetFeatureVectorByItemId(item_id, reco::common::kTopic, &topic);
  for (int i = 0; i < topic.feature_size() && i < FLAGS_max_feature; ++i) {
    auto& item_fea = topic.feature(i);
    if (item_fea.literal().empty()) continue;
    item_feature.topic_info.push_back(std::pair<std::string, float>(item_fea.literal(), item_fea.weight()));
  }

  // category
  std::vector<reco::Category> categories;
  GetCategoriesByItemId(item_id, &categories);
  int count =  std::min(categories.size(), (size_t)FLAGS_max_feature);
  float weight = 1.0 / count;
  for (size_t i = 0; i < categories.size() && i < (size_t)FLAGS_max_feature; ++i) {
    if (categories[i].category().empty()) continue;
    item_feature.category_info.push_back(std::pair<std::string, float>(categories[i].category(), weight));
  }

  items_feature.items_fea.push_back(item_feature);
  int index = items_feature.items_fea.size() - 1;
  items_feature.items_index.insert(std::make_pair(item_id, index));
  return;
}
}
