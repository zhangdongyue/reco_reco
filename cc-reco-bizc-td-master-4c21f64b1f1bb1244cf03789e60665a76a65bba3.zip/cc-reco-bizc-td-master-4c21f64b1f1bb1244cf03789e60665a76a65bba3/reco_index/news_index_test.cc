#include <vector>
#include <string>

#include "base/testing/gtest.h"
#include "reco/bizc/reco_index/news_index.h"

#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"
// #include "reco/module/cdoc_convertor/server/global_data.h"
#include "reco/bizc/reco_index/multi_category_cache.h"
#include "reco/bizc/reco_index/sort_item.h"
#include "reco/module/item_level/base/base.h"
#include "reco/module/item_level/base/redis_util.h"
#include "reco/module/item_level/base/connection_manager.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

#include "base/file/file_util.h"
#include "base/encoding/line_escape.h"
#include "ads_index/api/public.h"
#include "ads_index/dynamic_index/dynamic_index.h"
#include "ads_index/mix_index/mix_index.h"
#include "ads_index/proto/index.pb.h"

DEFINE_string(index_dir, "reco/bizc/reco_index/test_data", "");
DEFINE_string(hbase_item_attr_table, "tb_item_field", "hbase item attr table name");
DECLARE_int32(sort_item_interval_second);
// DECLARE_string(reco_item_feature_data_dir);
DECLARE_string(reco_region_data_dir);
DECLARE_string(itemlevel_redis_ip);
DECLARE_string(search_server_ips);
DECLARE_int32(search_server_port);

namespace reco {
DECLARE_string(reco_index_dict_dir);
class NewsIndexTest : public testing::Test {
 public:
  static void SetUpTestCase() {
    using namespace reco;  // NOLINT
    // FLAGS_reco_item_feature_data_dir = "serving/reco/data/cdoc_convertor/";
    FLAGS_reco_region_data_dir = "serving/reco/data/cdoc_convertor/";
    FLAGS_reco_index_dict_dir = "serving/reco/data/reco_leaf/";

    FLAGS_itemlevel_redis_ip = "100.81.1.68:6500,100.81.2.180:6500,100.81.4.141:6500";
    FLAGS_search_server_ips="";
    CHECK(reco::item_level::ConnectionManager::InitConnection());
    FLAGS_update_meta_interval_second = 120;

    // reco::GlobalData::Instance().Init();
    reco::hbase::HBasePoolIns::instance().Init();
    CHECK(reco::hbase::HBasePoolIns::instance().is_inited()) << "init hbase pool first";
    LOG(INFO) << "hbase client pool init done!";

    base::Time now = base::Time::Now();
    {
      reco::RecoItem item;
      auto multi_category = item.mutable_multi_category();
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(101);
      item.mutable_identity()->set_outer_id("item1");
      item.mutable_identity()->set_type(reco::kNews);
      item.mutable_identity()->set_producer("uc");

      item.set_is_valid(true);
      now.ToStringInSeconds(item.mutable_create_time());
      item.set_title("this is title");
      item.set_content("this is content");
      item.set_source("sina");
      item.set_orig_source("tencent");
      item.set_source_media("新浪");
      item.set_orig_source_media("腾讯");
      item.add_category("体育");
      item.add_category("nba");

      auto category = multi_category->add_category_candidates();
      category->set_level1("体育");
      category->set_level1_score(1.0);
      category->add_level2("cba");
      category->add_level2_score(0.8);
      category->add_level2("nba");
      category->add_level2_score(0.8);

      auto category2 = multi_category->add_category_candidates();
      category2->set_level1("娱乐");
      category2->set_level1_score(1.0);
      category2->add_level2("明星");
      category2->add_level2_score(0.8);

      FeatureVector* feature_vector;
      Feature* fea;

      feature_vector = item.mutable_keyword();
      feature_vector->set_norm(2);
      fea = feature_vector->add_feature();
      fea->set_item_type(kNews);
      fea->set_literal("keyword1");
      fea->set_weight(1);

      feature_vector = item.mutable_topic();
      feature_vector->set_norm(2);
      fea = feature_vector->add_feature();
      fea->set_item_type(kNews);
      fea->set_literal("topic1");
      fea->set_weight(1);

      feature_vector = item.mutable_wordvec();
      feature_vector->set_norm(2);
      fea = feature_vector->add_feature();
      fea->set_item_type(kNews);
      fea->set_literal("wordvec1");
      fea->set_weight(1);

      feature_vector = item.mutable_tag();
      feature_vector->set_norm(2);
      fea = feature_vector->add_feature();
      fea->set_item_type(kNews);
      fea->set_literal("tag1");
      fea->set_weight(1);

      item.add_synonymous_tags("synonymous_tag");

      content_attrs_.push_back(reco::ContentAttr());
      content_attrs_.back().set_advertorial(reco::ContentAttr::kSureYes);
      content_attrs_.back().set_erro_title(reco::ContentAttr::kSureYes);
      content_attrs_.back().set_short_content(reco::ContentAttr::kSureYes);
      content_attrs_.back().set_dedup_paragraph(reco::ContentAttr::kSureNo);
      content_attrs_.back().set_dirty(reco::ContentAttr::kSureYes);
      content_attrs_.back().set_politics(reco::ContentAttr::kSureNo);
      content_attrs_.back().set_bluffing_title(reco::ContentAttr::kSureYes);
      gaode_pois_.push_back(reco::GaoDePOI());
      gaode_pois_.back().add_poi_poiinfos()->set_id("id");
      gaode_pois_.back().add_poi_poiinfos()->set_adcode("adcode");
      gaode_pois_.back().add_poi_poiinfos()->set_new_keytype("new_keytype");
      gaode_pois_.back().add_poi_poiinfos()->set_poitype("poitype");
      gaode_pois_.back().add_poi_poiinfos()->set_x(1.0);
      gaode_pois_.back().add_poi_poiinfos()->set_y(1.1);

      item.mutable_raw_item()->mutable_content_attr()->CopyFrom(content_attrs_.back());
      item.mutable_raw_item()->mutable_gaode_poi()->CopyFrom(gaode_pois_.back());
      items_.push_back(item);

      // item level set
      reco::item_level::ItemLevelInfo item_level_info;
      item_level_info.item_id = item.identity().item_id();
      item_level_info.time_level = reco::kMidTimeliness;
      item_levels_.push_back(item_level_info);
    }
    reco::item_level::RedisUtil redis_util;
    redis_util.BatchWriteItemLevel(item_levels_);
    InitializeIndex();
  }

  static void TearDownTestCase() {
    delete news_index_;
    delete index_;
    LOG(INFO) << "tear dwon!";
  }

  static adsindexing::DynamicIndex* index_;
  static reco::NewsIndex* news_index_;
  static std::vector<reco::RecoItem> items_;
  static std::vector<reco::item_level::ItemLevelInfo> item_levels_;
  static std::vector<reco::ContentAttr> content_attrs_;
  static std::vector<reco::GaoDePOI> gaode_pois_;
 private:
  static void InitializeIndex() {
    adsindexing::DynamicIndexOptions options;
    options.unigram_num_bits = 10;
    options.bigram_num_bits = 10;
    options.doc_num_bits = 8;
    options.history_dir = FLAGS_index_dir;
    options.static_dict_filename = "ads_index/api/data/static_dict.dat";
    index_ = new adsindexing::DynamicIndex(options);

    reco::ItemCDocConvertor cdoc_convertor;
    std::vector<std::string> compressed_cdocs;
    int orig_num = index_->GetDocNum();
    for (auto it = items_.begin(); it != items_.end(); ++it) {
      const reco::RecoItem& reco_item = *it;
      adsindexing::IndexDocInfo cdoc;
      std::string compressed_cdoc;
      CHECK(cdoc_convertor.ConvertToCDoc(reco_item, &cdoc) &&
          adsindexing::GetCompressionCDoc(cdoc, &compressed_cdoc));
      compressed_cdocs.push_back(compressed_cdoc);
      // LOG(INFO) << cdoc.Utf8DebugString();
    }
    CHECK(index_->AddCDocs(0, compressed_cdocs));
    index_->LogStatus();
    ::google::FlushLogFiles(::google::INFO);
    CHECK_EQ((int)items_.size(), index_->GetDocNum() - orig_num);
    FLAGS_sort_item_interval_second = 1;
    news_index_ = InitializeNewsIndex(index_);

    LOG(INFO) << "finish build index";
  }
};

adsindexing::DynamicIndex* NewsIndexTest::index_;
reco::NewsIndex* NewsIndexTest::news_index_;
std::vector<reco::RecoItem> NewsIndexTest::items_;
std::vector<reco::ContentAttr> NewsIndexTest::content_attrs_;
std::vector<reco::GaoDePOI> NewsIndexTest::gaode_pois_;
std::vector<reco::item_level::ItemLevelInfo> NewsIndexTest::item_levels_;

TEST_F(NewsIndexTest, BasicInfo) {
  const reco::NewsIndex* index = news_index_;
  int32 doc_id = 0;
  uint64 item_id = 0;
  std::string outer_id;
  reco::ItemType item_type;
  ItemInfo item_info1;
  ItemInfo item_info2;

  EXPECT_TRUE(index->GetDocIdByItemId(101, &doc_id));
  EXPECT_TRUE(index->GetItemIdByDocId(doc_id, &item_id));
  EXPECT_TRUE(index->GetItemTypeByDocId(doc_id, &item_type));
  EXPECT_TRUE(index->GetItemInfoByItemId(item_id, &item_info1, true));
  EXPECT_TRUE(index->GetItemInfoByDocId(doc_id, &item_info2, true));

  EXPECT_EQ(item_id, 101u);
  EXPECT_EQ(item_type, reco::kNews);
  EXPECT_EQ(item_id, item_info1.item_id);
  EXPECT_EQ(item_type, item_info1.item_type);
}

TEST_F(NewsIndexTest, Category) {
  const reco::NewsIndex* index = news_index_;
  std::vector<reco::Category> categories;
  EXPECT_TRUE(index->GetCategoriesByItemId(101, &categories));
  EXPECT_EQ(categories.size(), 2u);
  EXPECT_STREQ(WrappedCategory(categories[0]).ToString().c_str(), "体育");
  EXPECT_STREQ(WrappedCategory(categories[1]).ToString().c_str(), "体育\tnba");

  bool find = false;
  for (size_t i = 0; i < categories.size(); ++i) {
    if (WrappedCategory(categories[i]).ToString() == "体育\tnba") {
      find = true;
      break;
    }
  }
  ASSERT_TRUE(find);

  // get category from external file
  std::vector<std::string> str_cates;
  EXPECT_TRUE(index->GetCategoriesByItemId(10001, &str_cates));
  EXPECT_EQ(str_cates.size(), 1u);
  EXPECT_EQ(str_cates[0], "科技");

  EXPECT_TRUE(index->GetCategoriesByItemId(10002, &str_cates));
  EXPECT_EQ(str_cates.size(), 2u);
  EXPECT_EQ(str_cates[0], "体育");
  EXPECT_EQ(str_cates[1], "nba");

  EXPECT_TRUE(index->GetCategoriesByItemId(10002, &categories));
  EXPECT_EQ(categories.size(), 2u);
  EXPECT_STREQ(WrappedCategory(categories[0]).ToString().c_str(), "体育");
  EXPECT_STREQ(WrappedCategory(categories[1]).ToString().c_str(), "体育\tnba");

  // multi category
  reco::MultiCategory multi_category;
  EXPECT_TRUE(index->GetMultiCategoriesByItemId(101, &multi_category));
  EXPECT_EQ(multi_category.category_candidates_size(), 2);
  std::unordered_map<std::string, int> find_dict;
  for (int i = 0; i < multi_category.category_candidates_size(); ++i) {
    find_dict.insert(std::make_pair(multi_category.category_candidates(i).level1(), 0));
    for (int j = 0; j < multi_category.category_candidates(i).level2_size(); ++j) {
      find_dict.insert(std::make_pair(multi_category.category_candidates(i).level2(j), 1));
    }
  }
  ASSERT_EQ(find_dict["体育"], 0);
  ASSERT_EQ(find_dict["cba"], 1);
  ASSERT_EQ(find_dict["nba"], 1);
  ASSERT_EQ(find_dict["娱乐"], 0);
  ASSERT_EQ(find_dict["明星"], 1);
}

TEST_F(NewsIndexTest, GetDocByCategory) {
  const reco::NewsIndex* index = news_index_;
  std::vector<reco::Category> categories;
  struct {
    std::string category;
    int level;
    std::string docs;
  } cases[] = {
    {"体育", 0, "101"},
    {"nba", 1, "101"},
    {"cba", 1, ""},
    {"娱乐", 0, ""},
  };
  int num = ARRAYSIZE_UNSAFE(cases);
  std::vector<int> doc_list;
  std::unordered_set<uint64> true_set;
  std::unordered_set<uint64> find_set;

  for (int i = 0; i < num; ++i) {
    std::vector<std::string> flds;
    base::SplitString(cases[i].docs, ",", &flds);
    true_set.clear();
    for (int j = 0; j < (int)flds.size(); ++j) {
      if (flds[j].empty()) continue;
      uint64 item_id = 0;
      ASSERT_TRUE(base::StringToUint64(flds[j], &item_id));
      true_set.insert(item_id);
    }

    doc_list.clear();
    find_set.clear();
    index->GetDocsByCategory(cases[i].category, cases[i].level, &doc_list);
    for (int j = 0; j < (int)doc_list.size(); ++j) {
      uint64 item_id = 0;
      index->GetItemIdByDocId(doc_list[j], &item_id);
      if (item_id < 100) continue;
      find_set.insert(item_id);
    }

    ASSERT_EQ(find_set.size(), true_set.size());
    for (auto it = find_set.begin(); it != find_set.end(); ++it) {
      auto it2 = true_set.find(*it);
      ASSERT_TRUE(it2!= true_set.end());
    }
  }

  // multi category
  struct {
    std::string multi_category;
    int level;
    std::string docs;
  } cases2[] = {
    {"体育", 0, "101"},
    {"nba", 1, "101"},
    {"cba", 1, "101"},
    {"游泳", 1, ""},
    {"娱乐", 0, "101"},
    {"明星", 1, "101"},
    {"电影", 1, ""},
  };
  num = ARRAYSIZE_UNSAFE(cases2);

  for (int i = 0; i < num; ++i) {
    std::vector<std::string> flds;
    base::SplitString(cases2[i].docs, ",", &flds);
    true_set.clear();
    for (int j = 0; j < (int)flds.size(); ++j) {
      if (flds[j].empty()) continue;
      uint64 item_id = 0;
      ASSERT_TRUE(base::StringToUint64(flds[j], &item_id));
      true_set.insert(item_id);
    }

    doc_list.clear();
    find_set.clear();
    index->GetDocsByMultiCategory(cases2[i].multi_category, cases2[i].level, &doc_list);
    for (int j = 0; j < (int)doc_list.size(); ++j) {
      uint64 item_id = 0;
      index->GetItemIdByDocId(doc_list[j], &item_id);
      find_set.insert(item_id);
    }

    ASSERT_EQ(find_set.size(), true_set.size()) << cases2[i].multi_category;
    for (auto it = find_set.begin(); it != find_set.end(); ++it) {
      auto it2 = true_set.find(*it);
      ASSERT_TRUE(it2!= true_set.end());
    }
  }
}

TEST_F(NewsIndexTest, Source) {
  const reco::NewsIndex* index = news_index_;
  std::string result;
  EXPECT_TRUE(index->GetSourceByItemId(101, &result));
  EXPECT_STREQ(result.c_str(), "sina");

  EXPECT_TRUE(index->GetOrigSourceByItemId(101, &result));
  EXPECT_STREQ(result.c_str(), "tencent");

  EXPECT_TRUE(index->GetSourceMediaByItemId(101, &result));
  EXPECT_STREQ(result.c_str(), "新浪");

  EXPECT_TRUE(index->GetOrigSourceMediaByItemId(101, &result));
  EXPECT_STREQ(result.c_str(), "腾讯");
}

TEST_F(NewsIndexTest, GetItemByTag) {
  const reco::NewsIndex* index = news_index_;
  std::vector<int32> doc_ids;
  uint64 item_id;

  index->GetDocsByTag("tag1", &doc_ids);
  // 存量索引，历史数据里有很多文档
  for (size_t i = 0; i < doc_ids.size(); ++i) {
    if (!index->IsValidByDocId(doc_ids[i])) {
      continue;
    }
    ASSERT_TRUE(index->GetItemIdByDocId(doc_ids[i], &item_id));
    EXPECT_EQ(item_id, 101ul);
  }

  doc_ids.clear();
  index->GetDocsByTag("synonymous_tag", &doc_ids);
  for (size_t i = 0; i < doc_ids.size(); ++i) {
    if (!index->IsValidByDocId(doc_ids[i])) {
      continue;
    }
    ASSERT_TRUE(index->GetItemIdByDocId(doc_ids[i], &item_id));
    EXPECT_EQ(item_id, 101ul);
  }
}

TEST_F(NewsIndexTest, DefaultReco) {
  const reco::NewsIndex* index = news_index_;
  const std::vector<ItemInfo>* default_reco = index->GetDefaultReco();
  ASSERT_EQ(default_reco->size(), 1u);
  ASSERT_EQ(default_reco->at(0).item_id, 101u);

  reco::Category category;
  category.set_level(0);
  category.set_category("体育");
  default_reco = index->GetDefaultReco(category);
  ASSERT_EQ(default_reco->size(), 1u);
  ASSERT_EQ(default_reco->at(0).item_id, 101u);

  category.Clear();
  category.set_level(1);
  category.set_category("nba");
  category.add_parents("体育");
  default_reco = index->GetDefaultReco(category);
  ASSERT_EQ(default_reco->size(), 1u);
  ASSERT_EQ(default_reco->at(0).item_id, 101u);
}

TEST_F(NewsIndexTest, GetFeatureByDocId) {
  const reco::NewsIndex* index = news_index_;
  int32 doc_id = 0;
  EXPECT_TRUE(index->GetDocIdByItemId(101, &doc_id));
  std::map<std::string, double> features;
  double norm2;

  features.clear();
  EXPECT_TRUE(index->GetFeatureMapByDocId(doc_id, reco::common::kKeyword, &features, &norm2));
  EXPECT_EQ(features.size(), 1u);
  EXPECT_STREQ(features.begin()->first.c_str(), "keyword1");
  EXPECT_DOUBLE_EQ(features.begin()->second, 1.0);
  EXPECT_DOUBLE_EQ(norm2, 2.0);

  features.clear();
  EXPECT_TRUE(index->GetFeatureMapByDocId(doc_id, reco::common::kTopic, &features, &norm2));
  EXPECT_EQ(features.size(), 1u);
  EXPECT_STREQ(features.begin()->first.c_str(), "topic1");
  EXPECT_DOUBLE_EQ(features.begin()->second, 1.0);
  EXPECT_DOUBLE_EQ(norm2, 2.0);

  features.clear();
  EXPECT_TRUE(index->GetFeatureMapByDocId(doc_id, reco::common::kWordvec, &features, &norm2));
  EXPECT_EQ(features.size(), 1u);
  EXPECT_STREQ(features.begin()->first.c_str(), "wordvec1");
  EXPECT_DOUBLE_EQ(features.begin()->second, 1.0);
  EXPECT_DOUBLE_EQ(norm2, 2.0);

  features.clear();
  EXPECT_TRUE(index->GetFeatureMapByDocId(doc_id, reco::common::kTag, &features, &norm2));
  EXPECT_EQ(features.size(), 1u);
  EXPECT_STREQ(features.begin()->first.c_str(), "tag1");
  EXPECT_DOUBLE_EQ(features.begin()->second, 1.0);
  EXPECT_DOUBLE_EQ(norm2, 2.0);
}

TEST_F(NewsIndexTest, GetFeatureByItemId) {
  const reco::NewsIndex* index = news_index_;
  reco::FeatureVector features;

  features.Clear();
  EXPECT_TRUE(index->GetFeatureVectorByItemId(101, reco::common::kKeyword, &features));
  EXPECT_EQ(features.feature_size(), 1);
  EXPECT_STREQ(features.feature(0).literal().c_str(), "keyword1");
  EXPECT_DOUBLE_EQ(features.feature(0).weight(), 1.0);
  EXPECT_DOUBLE_EQ(features.norm(), 2.0);

  features.Clear();
  EXPECT_TRUE(index->GetFeatureVectorByItemId(101, reco::common::kTopic, &features));
  EXPECT_EQ(features.feature_size(), 1);
  EXPECT_STREQ(features.feature(0).literal().c_str(), "topic1");
  EXPECT_DOUBLE_EQ(features.feature(0).weight(), 1.0);
  EXPECT_DOUBLE_EQ(features.norm(), 2.0);

  features.Clear();
  EXPECT_TRUE(index->GetFeatureVectorByItemId(101, reco::common::kWordvec, &features));
  EXPECT_EQ(features.feature_size(), 1);
  EXPECT_STREQ(features.feature(0).literal().c_str(), "wordvec1");
  EXPECT_DOUBLE_EQ(features.feature(0).weight(), 1.0);
  EXPECT_DOUBLE_EQ(features.norm(), 2.0);

  features.Clear();
  EXPECT_TRUE(index->GetFeatureVectorByItemId(101, reco::common::kTag, &features));
  EXPECT_EQ(features.feature_size(), 1);
  EXPECT_STREQ(features.feature(0).literal().c_str(), "tag1");
  EXPECT_DOUBLE_EQ(features.feature(0).weight(), 1.0);
  EXPECT_DOUBLE_EQ(features.norm(), 2.0);
}

TEST_F(NewsIndexTest, ContentAttr) {
  const reco::NewsIndex* index = news_index_;
  reco::ContentAttr content_attr;
  bool is_trival;
  const std::vector<reco::RecoItem>& items = items_;
  const std::vector<reco::ContentAttr>& attrs = content_attrs_;
  for (size_t i = 0; i < items.size(); ++i) {
    uint64 item_id = items[i].identity().item_id();
    index->GetContentAttrByItemId(item_id, &content_attr, &is_trival);
    ASSERT_EQ(content_attr.DebugString(), attrs[i].DebugString());
  }
}

TEST_F(NewsIndexTest, GaoDePOI) {
  const reco::NewsIndex* index = news_index_;
  reco::GaoDePOI gaode_poi;
  const std::vector<reco::RecoItem>& items = items_;
  const std::vector<reco::GaoDePOI>& all_gaode_pois = gaode_pois_;
  for (size_t i = 0; i < items.size(); ++i) {
    uint64 item_id = items[i].identity().item_id();
    index->GetGaoDePOIByItemId(item_id, &gaode_poi);
    ASSERT_EQ(gaode_poi.DebugString(), all_gaode_pois[i].DebugString());
  }
}

TEST_F(NewsIndexTest, TestMultiCategoryCache) {
  reco::MultiCategoryCache cache;
  const std::vector<reco::RecoItem>& items = items_;
  for (size_t i = 0; i < items.size(); ++i) {
    for (int j = 0; j < items[i].multi_category().category_candidates_size(); ++j) {
      cache.Add(items[i].identity().item_id(), items[i].multi_category().category_candidates(j));
    }
  }

  float score = 0;
  for (size_t i = 0; i < items.size(); ++i) {
    for (int j = 0; j < items[i].multi_category().category_candidates_size(); ++j) {
      ASSERT_TRUE(cache.Find(items[i].identity().item_id(), items[i].multi_category().category_candidates(j).level1(), &score));  // NOLINT
      ASSERT_DOUBLE_EQ(static_cast<double>(score), items[i].multi_category().category_candidates(j).level1_score());  // NOLINT
      for (int k = 0; k < items[i].multi_category().category_candidates(j).level2_size(); ++k) {
        ASSERT_TRUE(cache.Find(items[i].identity().item_id(), items[i].multi_category().category_candidates(j).level2(k), &score));  // NOLINT
        ASSERT_DOUBLE_EQ(static_cast<double>(score), items[i].multi_category().category_candidates(j).level2_score(k));  // NOLINT
      }
    }
  }

  // test cache in index
  const reco::NewsIndex* index = news_index_;
  reco::Category category;
  for (size_t i = 0; i < items.size(); ++i) {
    for (int j = 0; j < items[i].multi_category().category_candidates_size(); ++j) {
      float score = 0;
      category.Clear();
      category.set_level(0);
      category.set_category(items[i].multi_category().category_candidates(j).level1());
      ASSERT_TRUE(index->GetCategoryScore(items[i].identity().item_id(), category, &score));
      ASSERT_DOUBLE_EQ(static_cast<double>(score), items[i].multi_category().category_candidates(j).level1_score());  // NOLINT

      category.set_category("财经");
      ASSERT_TRUE(!index->GetCategoryScore(items[i].identity().item_id(), category, &score));

      category.set_level(1);
      category.add_parents(category.category());
      for (int k = 0; k < items[i].multi_category().category_candidates(j).level2_size(); ++k) {
        category.set_category(items[i].multi_category().category_candidates(j).level2(k));
        ASSERT_TRUE(index->GetCategoryScore(items[i].identity().item_id(), category, &score));
        ASSERT_DOUBLE_EQ(static_cast<double>(score), items[i].multi_category().category_candidates(j).level2_score(k));  // NOLINT

        category.set_category("美股");
        ASSERT_TRUE(!index->GetCategoryScore(items[i].identity().item_id(), category, &score));
      }
    }
  }
}

/*
TEST_F(NewsIndexTest, TestAddMultiCategoryChannel) {
  std::unordered_set<std::string> category_dict;
  category_dict.insert("科技-互联网");
  category_dict.insert("科技");
  category_dict.insert("财经");
  category_dict.insert("财经-股票");
  ::google::protobuf::RepeatedPtrField<ItemCategory> candidates;

  auto item_category = candidates.Add();
  item_category->set_level1("科技");
  item_category->set_level1_score(1.0);
  item_category->add_level2("互联网");
  item_category->add_level2_score(1.0);
  item_category->add_level2("手机");
  item_category->add_level2_score(1.0);

  item_category = candidates.Add();
  item_category->set_level1("财经");
  item_category->set_level1_score(1.0);
  item_category->add_level2("股票");
  item_category->add_level2_score(1.0);
  item_category->add_level2("经济民生");
  item_category->add_level2_score(1.0);

  item_category = candidates.Add();
  item_category->set_level1("国际");
  item_category->set_level1_score(1.0);

  base::dense_hash_map<std::string, int64> category_channel_map;
  category_channel_map.set_empty_key("");
  category_channel_map["科技"] = 0;
  category_channel_map["科技-互联网"] = 1;
  category_channel_map["科技-手机"] = 2;
  category_channel_map["财经"] = 3;
  category_channel_map["财经-经济民生"] = 4;
  category_channel_map["财经-股票"] = 5;
  category_channel_map["国际"] = 6;

  std::unordered_set<int64> candidate_channels;
  candidate_channels.insert(3);
  candidate_channels.insert(5);
  std::unordered_map<int64, std::pair<std::string, std::string> > incr_channel;
  SortItem::AddMultiCategoryChannels(category_dict, candidates, category_channel_map,
                                     &candidate_channels, &incr_channel);
  ASSERT_EQ(candidate_channels.size(), 4u);
  ASSERT_TRUE(candidate_channels.find(0) != candidate_channels.end());
  ASSERT_TRUE(candidate_channels.find(1) != candidate_channels.end());
  ASSERT_TRUE(candidate_channels.find(3) != candidate_channels.end());
  ASSERT_TRUE(candidate_channels.find(5) != candidate_channels.end());

  ASSERT_TRUE(incr_channel.find(5) == incr_channel.end());
  ASSERT_TRUE(incr_channel.find(3) == incr_channel.end());
  ASSERT_TRUE(incr_channel.find(0) != incr_channel.end());
  ASSERT_TRUE(incr_channel.find(1) != incr_channel.end());
  ASSERT_EQ(incr_channel.find(0)->second.first, "科技");
  ASSERT_EQ(incr_channel.find(1)->second.first, "科技");
  ASSERT_EQ(incr_channel.find(1)->second.second, "互联网");
}
*/
}
