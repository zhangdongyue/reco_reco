#pragma once

#include "reco/base/common/atomic.h"
#include <string>
#include <memory>

#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/time/timestamp.h"
#include "base/time/time.h"
#include "base/thread/sync.h"
#include "base/strings/string_printf.h"

namespace reco {

template <class Dict>
class DynamicDict {
 public:
  DynamicDict() {
    active_id_ = 1;
    dicts_[0] = new Dict();
    dicts_[1] = new Dict();
    prev_switch_timestamp_ = 0;
    kMinSwitchIntervalInSeconds = 30;
  }

  explicit DynamicDict(int64 switch_interval) {
    active_id_ = 1;
    dicts_[0] = new Dict();
    dicts_[1] = new Dict();
    prev_switch_timestamp_ = 0;
    kMinSwitchIntervalInSeconds = switch_interval;
  }

  ~DynamicDict() {
    delete dicts_[0];
    delete dicts_[1];
  }

  const Dict* GetDict() const {
    return dicts_[active_id_];
  }

  Dict* GetInactiveDict() {
    return dicts_[1 - active_id_];
  }

  bool CanSwitch() {
    int64 cur_timestamp = base::GetTimestamp();
    int64 interval = (cur_timestamp - prev_switch_timestamp_) / base::Time::kMicrosecondsPerSecond;
    if (interval < kMinSwitchIntervalInSeconds) {
      // LOG(ERROR) << "reload too frequently, interval " << interval << " > " << kMinSwitchIntervalInSeconds;
      return false;
    } else {
      return true;
    }
  }

  bool SwitchDict() {
    thread::AutoLock lock(&mutex_);
    if (!CanSwitch()) {
      return false;
    }
    active_id_ = 1 - active_id_;
    prev_switch_timestamp_ = base::GetTimestamp();
    return true;
  }

 private:
  // 切换字典的间隔只要不小于该值，使用都是安全的
  int64 kMinSwitchIntervalInSeconds;
  Dict* dicts_[2];
  int64 prev_switch_timestamp_;
  thread::Mutex mutex_;
  std::atomic_int active_id_;

  DISALLOW_COPY_AND_ASSIGN(DynamicDict<Dict>);
};

}  // namespace
