#include <unordered_map>
#include <utility>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <fstream>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/encoding/line_escape.h"
#include "base/strings/string_printf.h"
#include "reco/bizc/proto/reco_log.pb.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/process/process_util.h"
#include "base/container/dense_hash_map.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"
#include "reco/bizc/reco_index/news_index.h"
#include "base/file/file_util.h"

#include "reco/bizc/reco_index/extractor.h"

namespace reco {
namespace reco_index {

void WDExtractor::ExtractUserDynamicFea(const reco::ml::WDInfo& wd_info,
                                        std::vector<reco::model_server::FeatureInfo>* dynamic_feas) {
  reco::ml::WDUserFeature::Instance().ExtractUserDynamicFea(wd_info, dynamic_feas);
  return;
}

void WDExtractor::ExtractUserDynamicFea(const reco::user::UserInfo& user_info,
                                        std::vector<reco::model_server::FeatureInfo>* dynamic_feas) {
  reco::ml::WDUserFeature::Instance().ExtractUserDynamicFea(user_info, dynamic_feas);
  return;
}

void WDExtractor::ExtractUserStaticFea(const reco::user::UserInfo& user_info) {
  // 抽特征
  std::vector<reco::model_server::FeatureInfo> user_feas;
  reco::ml::WDUserFeature::Instance().ExtractUserStaticFea(user_info, &user_feas);
  // 写缓存
  uint64 user_id = user_info.identity().user_id();
  thread::WriterAutoLock lock(&u_mutex_);
  u_fea_cache_[user_id] = user_feas;
  return;
}

bool WDExtractor::NeedExtractUserStaticFea(const uint64 user_id) {
  thread::ReaderAutoLock lock(&u_mutex_);
  return u_fea_cache_.find(user_id) == u_fea_cache_.end();
}

void WDExtractor::GetUserStaticFea(const uint64 user_id,
                                   std::vector<reco::model_server::FeatureInfo>* wd_feas) {
  thread::ReaderAutoLock lock(&u_mutex_);
  auto find = u_fea_cache_.find(user_id);
  if (find != u_fea_cache_.end()) {
    wd_feas->insert(wd_feas->end(), find->second.begin(), find->second.end());
  }

  return;
}

void WDExtractor::GetItemFeaByIndex(const uint64 item_id,
                                   std::vector<reco::model_server::FeatureInfo>* wd_feas) {
  auto find = item_dynamic_fea_cache_[act_id_].find(item_id);
  if (find != item_dynamic_fea_cache_[act_id_].end()) {
    wd_feas->insert(wd_feas->end(), find->second.begin(), find->second.end());
  }

  return;
}

void WDExtractor::GetItemFeaByIndex(const reco::ml::WDInfo& wd_info,
                                   std::vector<reco::model_server::FeatureInfo>* wd_feas) {
  if (wd_info.show_num > 0) {
    reco::ml::GetItemCtrFea(wd_info.show_num, wd_info.click_num, wd_feas);
    return;
  }

  auto find = item_dynamic_fea_cache_[act_id_].find(wd_info.item_id);
  if (find != item_dynamic_fea_cache_[act_id_].end()) {
    wd_feas->insert(wd_feas->end(), find->second.begin(), find->second.end());
  }

  return;
}



void WDExtractor::ExtractItemDynamicFeaByIndex(const uint64 item_id) {
  std::vector<reco::model_server::FeatureInfo> wd_feas;
  reco::ItemInfo item_info;
  news_index_->GetItemInfoByItemId(item_id, &item_info, false);

  reco::ml::WDInfo wd_info;
  wd_info.item_id = item_id;
  wd_info.show_num = item_info.show_num;
  wd_info.click_num = item_info.click_num;
  reco::ml::WDItemFeature::Instance().ExtractItemDynamicFeaByExternal(wd_info, &wd_feas);

  int32 no_act_id = 1 - act_id_;
  item_dynamic_fea_cache_[no_act_id][item_id] = wd_feas;

  return;
}

void WDExtractor::Switch() {
  // 切换 cache id
  act_id_ = 1 - act_id_;
  has_ready_ = true;
  // 进行 item fea cache 之间的同步
  int32 no_act_id = 1 - act_id_;
  const std::unordered_map<uint64, std::vector<reco::model_server::FeatureInfo>>
      &act_dynamic_dict = item_dynamic_fea_cache_[act_id_];
  std::unordered_map<uint64, std::vector<reco::model_server::FeatureInfo>>
      &no_act_dynamic_dict = item_dynamic_fea_cache_[no_act_id];
  for (auto item = act_dynamic_dict.begin(); item != act_dynamic_dict.end(); ++item) {
    if (no_act_dynamic_dict.find(item->first) == no_act_dynamic_dict.end()) {
      no_act_dynamic_dict[item->first] = item->second;
    }
  }

  LOG(INFO) << "switch has ready : " << has_ready_
            << " no_act_dynamic_dict_size :" << no_act_dynamic_dict.size()
            << " act_dynamic_dict_size : " << act_dynamic_dict.size();
}
}  // namespace reco_index
}  // namespace reco
