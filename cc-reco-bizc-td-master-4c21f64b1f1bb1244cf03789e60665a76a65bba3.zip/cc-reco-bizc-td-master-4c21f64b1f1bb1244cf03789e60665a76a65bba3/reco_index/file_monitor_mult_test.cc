#include <unordered_set>
#include <cstdlib>

#include "base/testing/gtest.h"
#include "base/common/gflags.h"
#include "base/common/sleep.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "reco/bizc/reco_index/file_monitor_mult.h"
#include "reco/bizc/reco_index/dynamic_dict.h"

// ****************************
// 本测试程序演示了如何使用动态字典 DynamicDict 类和 MultFileMonitor 类来完成多个文件的监控和更新
// 测试程序演示了同时监控两个文件
// ***************************

using namespace std;  // NOLINT
using namespace reco;  // NOLINT

DEFINE_string(path1, "", "");
DEFINE_string(path2, "", "");

// MultFileMonitor 是一个模板类,继承的时候需要用继承类来实例化
class GlobalData: public MultFileMonitor<GlobalData> {
 public:
  // 设置动态字典的最小切换间隔为 1 秒,方便测试
  GlobalData(): list1_(1), list2_(1) {}

  ~GlobalData() {
    // 不管有没有启动 Monitor ,安全退出的时候都应该调用这个函数来等待线程结束
    StopMultFileMonitor();
  }

  void Init() {
    // API 函数,增加监控文件,设定路径/重载间隔/重载时调用的函数
    AddFileMonitor(FLAGS_path1, 2, &GlobalData::LoadList1);
    base::SleepForSeconds(1);
    AddFileMonitor(FLAGS_path2, 2, &GlobalData::LoadList2);
  }

  // 对外提供数据的接口
  const std::unordered_set<std::string>* GetList1() {
    return list1_.GetDict();
  }
  const std::unordered_set<std::string>* GetList2() {
    return list2_.GetDict();
  }

 private:
  void LoadList1(const base::FilePath& path) {
    LOG(INFO) << "excuting LoadList1.";
    std::vector<std::string> lines;
    if (!base::file_util::PathExists(path) || !base::file_util::ReadFileToLines(path, &lines)) {
      LOG(ERROR) << "read file failed." << path.value();
      return;
    }

    std::unordered_set<std::string>* list = list1_.GetInactiveDict();
    list->clear();
    for (int i = 0; i < (int)lines.size(); ++i) {
      list->insert(lines[i]);
    }
    list1_.SwitchDict();
  }

  void LoadList2(const base::FilePath& path) {
    LOG(INFO) << "excuting LoadList2.";
    std::vector<std::string> lines;
    if (!base::file_util::PathExists(path) || !base::file_util::ReadFileToLines(path, &lines)) {
      LOG(ERROR) << "read file failed." << path.value();
      return;
    }

    std::unordered_set<std::string>* list = list2_.GetInactiveDict();
    list->clear();
    for (int i = 0; i < (int)lines.size(); ++i) {
      list->insert(lines[i]);
    }
    list2_.SwitchDict();
  }

 private:
  DynamicDict<std::unordered_set<std::string> > list1_;
  DynamicDict<std::unordered_set<std::string> > list2_;
};

#if 0
int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "");

  const string test_str1 = "111";
  const string test_str2 = "aaa";

  GlobalData Obj;
  Obj.Init();

  const std::unordered_set<std::string>* list1;
  const std::unordered_set<std::string>* list2;
  while (true) {
    // 测试程序循环运行的时候,修改监控的文件,可以从日志中看到变化
    list1 = Obj.GetList1();
    list2 = Obj.GetList2();

    if (list1->find(test_str1) != list1->end()) {
      LOG(INFO) << "found in list1!";
    }
    if (list2->find(test_str2) != list2->end()) {
      LOG(INFO) << "found in list2!";
    }
    base::SleepForSeconds(5);
  }

  return 0;
}
#endif

class MultFM_Test : public testing::Test {
 public:
  void SetUp() {
    FLAGS_path1 = "/tmp/1";
    FLAGS_path2 = "/tmp/2";

    system("echo > /tmp/1");
    system("echo > /tmp/2");

    Obj.Init();
  }

  void TearDown() {
    system("rm -f /tmp/1");
    system("rm -f /tmp/2");
  }

  GlobalData Obj;
};

TEST_F(MultFM_Test, TwoFileCase) {
  const string test_str1 = "111";
  const string test_str2 = "aaa";

  auto list1 = Obj.GetList1();
  auto list2 = Obj.GetList2();
  EXPECT_TRUE(list1->find(test_str1) == list1->end());
  EXPECT_TRUE(list2->find(test_str2) == list2->end());

  system("echo '111' > /tmp/1");
  base::SleepForSeconds(3);
  list1 = Obj.GetList1();
  EXPECT_TRUE(list1->find(test_str1) != list1->end());

  system("echo 'aaa' > /tmp/2");
  base::SleepForSeconds(3);
  list2 = Obj.GetList2();
  EXPECT_TRUE(list2->find(test_str2) != list2->end());

  system("echo '222' > /tmp/1");
  system("echo 'bbb' > /tmp/2");
  base::SleepForSeconds(3);
  list1 = Obj.GetList1();
  list2 = Obj.GetList2();
  EXPECT_TRUE(list1->find(test_str1) == list1->end());
  EXPECT_TRUE(list2->find(test_str2) == list2->end());
}

