#include <iostream>
#include <set>
#include <map>
#include <algorithm>

#include "reco/nlp_server/parser/general_query_parser.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/hbase_set_item_attr.h"
#include "base/testing/gtest.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"

#include "nlp/common/nlp_util.h"
#include "query/tree/query_tree.h"
#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"
#include "reco/module/cdoc_convertor/convertor/raw_item_convertor.h"
#include "reco/bizc/reco_index/news_index.h"

// #include "wolong/adinc/proto/adinc.pb.h"
// #include "wolong/adinc/api/public.h"

#include "ads_index/api/public.h"
#include "ads_index/dynamic_index/dynamic_index.h"
#include "ads_index/api/cdoc_convertor.pb.h"
// #include "ads_index/proto/index.pb.h"

DEFINE_string(hbase_ip, "100.85.69.80", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase port");
DEFINE_string(hbase_item_attr_table, "tb_item_field", "hbase item attr table name");
DEFINE_string(hbase_item_table, "tb_reco_item", "host of hbase server");
DEFINE_uint64(item_id, 0, "item id");
DECLARE_int32(sort_item_interval_second);

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");
namespace reco {

using serving_base::mysql_util::DbConnManager;

class CDocIndexTest : public testing::Test {
 public:
  void SetUp() {
    serving_base::mysql_util::DbConnManager::Option db_option;
    db_option.host = FLAGS_db_host;
    db_option.user = FLAGS_db_user;
    db_option.passwd = FLAGS_db_passwd;
    db_option.schema = FLAGS_schema;
    DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(db_option);
    raw_convertor = new reco::RawItemConvertor(FLAGS_hbase_item_table, db_manager);
    cdoc_convertor = new reco::ItemCDocConvertor();
  }
  void TearDown() {
    delete raw_convertor;
    delete cdoc_convertor;
  }

  void RawItemGenerator(uint64 item_id, const char* title, reco::RawItem* raw_item);
  std::string CDocGenerator(uint64 item_id, const char* title);

 public:
  reco::RawItemConvertor* raw_convertor;
  reco::ItemCDocConvertor* cdoc_convertor;
  // reco::NewsIndex* news_index;
};


void CDocIndexTest::RawItemGenerator(uint64 item_id, const char* title, reco::RawItem* raw_item) {
  reco::NewsImage image;
  image.set_url("xxx");
  image.set_simhash(1111);
  image.set_width(640);
  image.set_height(480);

  raw_item->mutable_identity()->set_app_token("uc");
  raw_item->mutable_identity()->set_item_id(item_id);
  raw_item->mutable_identity()->set_type(reco::kNews);
  raw_item->mutable_identity()->set_outer_id("outer");
  raw_item->set_is_valid(true);
  raw_item->set_title(title);
  raw_item->set_source("zzd");
  raw_item->set_content("ab");
  raw_item->set_create_time("2016-01-01 00:00:00");
  raw_item->set_publish_time("2016-01-01 00:00:00");
  raw_item->set_is_webview(false);
  raw_item->add_image()->CopyFrom(image);
  *raw_item->add_category() = "娱乐";
  CHECK(raw_item->IsInitialized());
}

std::string CDocIndexTest::CDocGenerator(uint64 item_id, const char* title) {
  reco::RawItem raw_item;
  RawItemGenerator(item_id, title, &raw_item);

  reco::RecoItem reco_item;
  CHECK(raw_convertor->ConvertToRecoItem(raw_item, &reco_item));

  adsindexing::ConvertInfo convert_info;
  adsindexing::IndexDocInfo cdoc;
  std::string compressed_cdoc;
  CHECK(cdoc_convertor->ConvertToCDoc(reco_item, &cdoc)
        && adsindexing::GetCompressionCDoc(cdoc, &compressed_cdoc));

  return compressed_cdoc;
}

#define CALC_SIGN(attr) \
      base::CalcTermSign(attr, strlen(attr))
// 普通的 AR 需要在样例索引上做召回测试, 这里主要测试自定义排序
TEST_F(CDocIndexTest, FakeCase) {
  static struct {
    uint64 item_id;
    const char* title;
  } docs[] = {
    {1, "123abc"},
  };

  auto dynamic_index = adsindexing::GenDynamicIndex();
  std::vector<std::string> cdocs;
  for (int i = 0; i < (int)ARRAYSIZE_UNSAFE(docs); ++i) {
    cdocs.push_back(CDocGenerator(docs[i].item_id, docs[i].title));
  }
  CHECK(dynamic_index->AddCDocs(0, cdocs));

  reco::NewsIndex* news_index = reco::InitializeNewsIndex(dynamic_index);
  int32 doc_id = 0;
  ASSERT_TRUE(news_index->GetDocIdByItemId(1, &doc_id));
  uint64 key = CALC_SIGN(reco::common::attr_key::kImageHash);

  std::string value = dynamic_index->GetStringAttr(key, doc_id, "");
  LOG(ERROR) << value;

  key = CALC_SIGN(reco::common::attr_key::kImageCount);
  LOG(ERROR) << dynamic_index->GetIntAttr(key, doc_id, 256);
  delete dynamic_index;
  delete news_index;
}

TEST_F(CDocIndexTest, RealCase) {
  uint64 item_id = FLAGS_item_id;
  if (item_id == 0u) return;

  reco::HBaseGetItem get_item(FLAGS_hbase_item_table, 0);

  reco::RecoItem org_reco_item;
  ASSERT_TRUE(get_item.GetRecoItem(item_id, &org_reco_item));

  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(db_option);
  reco::RawItemConvertor item_convertor(FLAGS_hbase_item_table, db_manager);
  reco::RecoItem reco_item;
  CHECK(item_convertor.ConvertToRecoItem(org_reco_item.raw_item(), &reco_item));

  adsindexing::ConvertInfo convert_info;
  adsindexing::IndexDocInfo cdoc;
  reco::ItemCDocConvertor cdoc_convertor;
  std::string compressed_cdoc;
  CHECK(cdoc_convertor.ConvertToCDoc(reco_item, &cdoc)
        && adsindexing::GetCompressionCDoc(cdoc, &compressed_cdoc));

  auto dynamic_index = adsindexing::GenDynamicIndex();
  std::vector<std::string> cdocs;
  cdocs.push_back(compressed_cdoc);
  CHECK(dynamic_index->AddCDocs(0, cdocs));

  reco::NewsIndex* news_index = reco::InitializeNewsIndex(dynamic_index);
  int32 doc_id = 0;
  ASSERT_TRUE(news_index->GetDocIdByItemId(reco_item.identity().item_id(), &doc_id));
  uint64 key = CALC_SIGN(reco::common::attr_key::kImageHash);

  std::string value = dynamic_index->GetStringAttr(key, doc_id, "");
  LOG(ERROR) << value;

  key = CALC_SIGN(reco::common::attr_key::kImageCount);
  LOG(ERROR) << dynamic_index->GetIntAttr(key, doc_id, 256);
  delete dynamic_index;
  delete news_index;
}

TEST_F(CDocIndexTest, UCBTest) {
  reco::HBaseSetItemAttr* set_item_attr = new HBaseSetItemAttr(FLAGS_hbase_item_attr_table);

  // first item
  uint64 item_id = 2u;
  reco::RawItem raw_item;
  RawItemGenerator(item_id, "ucb 测试", &raw_item);
  raw_item.mutable_identity()->set_app_token(reco::common::kUCBProducer);
  raw_item.mutable_identity()->set_producer(reco::common::kUCBProducer);
  reco::UcBrowserDeliverSetting ucb_setting;
  *ucb_setting.add_province() = "福建";
  *ucb_setting.add_city() = "漳州";
  ucb_setting.set_quantity(1000);
  ucb_setting.set_is_published(true);
  ASSERT_TRUE(set_item_attr->SetItemAttr(item_id, reco::item_attr::kUcBrowserDeliverSetting, ucb_setting));

  raw_item.mutable_uc_browser_deliver_setting()->CopyFrom(ucb_setting);
  reco::RecoItem reco_item;
  CHECK(raw_convertor->ConvertToRecoItem(raw_item, &reco_item));
  adsindexing::ConvertInfo convert_info;
  adsindexing::IndexDocInfo cdoc;
  std::string compressed_cdoc;
  CHECK(cdoc_convertor->ConvertToCDoc(reco_item, &cdoc)
        && adsindexing::GetCompressionCDoc(cdoc, &compressed_cdoc));
  std::vector<std::string> cdocs;
  cdocs.push_back(compressed_cdoc);

  // second item
  uint64 item_id_2 = 3u;
  reco::UcBrowserDeliverSetting ucb_setting_2;
  ucb_setting_2.CopyFrom(ucb_setting);
  ucb_setting_2.set_is_banner(true);
  ASSERT_TRUE(set_item_attr->SetItemAttr(item_id_2, reco::item_attr::kUcBrowserDeliverSetting,
                                         ucb_setting_2));
  raw_item.mutable_uc_browser_deliver_setting()->CopyFrom(ucb_setting_2);
  raw_item.mutable_identity()->set_item_id(item_id_2);
  raw_item.mutable_identity()->set_type(reco::kSpecial);
  std::string content_json_str;
  content_json_str.append("[");
  std::vector<uint64> expect_ids;
  bool first = true;
  for (int k = 10; k < 15; ++k) {
    expect_ids.push_back(k);
    if (first) {
      first = false;
    } else {
      content_json_str.append(",");
    }
    content_json_str.append(base::StringPrintf("{\"id\":\"%d\"}", k));
  }
  content_json_str.append("]");
  raw_item.set_content(content_json_str);
  CHECK(raw_convertor->ConvertToRecoItem(raw_item, &reco_item));
  CHECK(cdoc_convertor->ConvertToCDoc(reco_item, &cdoc)
        && adsindexing::GetCompressionCDoc(cdoc, &compressed_cdoc));
  cdocs.push_back(compressed_cdoc);

  auto dynamic_index = adsindexing::GenDynamicIndex();
  CHECK(dynamic_index->AddCDocs(0, cdocs));
  FLAGS_sort_item_interval_second = 1;
  reco::NewsIndex* news_index = reco::InitializeNewsIndex(dynamic_index);

  // test the first item's ucb_setting is ok?
  int32 doc_id = 0;
  ASSERT_TRUE(news_index->GetDocIdByItemId(item_id, &doc_id));
  reco::UcBrowserDeliverSetting ret_ucb_setting;
  CHECK(news_index->GetUCBSettingByItemId(item_id, &ret_ucb_setting));
  ASSERT_EQ(ret_ucb_setting.Utf8DebugString(), ucb_setting.Utf8DebugString());
  LOG(INFO) << nlp::util::NormalizeLine(ret_ucb_setting.Utf8DebugString());

  // test the second item's content is ok?
  std::unordered_set<uint64> id_list;
  ASSERT_TRUE(news_index->GetContainIdsByItemId(item_id_2, &id_list));
  ASSERT_EQ(id_list.size(), expect_ids.size());
  for (int i = 0; i < (int)expect_ids.size(); ++i) {
    ASSERT_TRUE(id_list.find(expect_ids[i]) != id_list.end());
  }

  // test the banner is on the top
  const std::vector<ItemInfo>* ucb_items = news_index->GetUCBDefaultReco();
  ASSERT_TRUE(ucb_items != NULL);
  ASSERT_EQ(ucb_items->at(0).item_id, item_id_2);
  ASSERT_EQ(ucb_items->at(1).item_id, item_id);

  uint64 key = CALC_SIGN(reco::common::attr_key::kImageHash);
  std::string value = dynamic_index->GetStringAttr(key, doc_id, "");
  LOG(INFO) << value;

  key = CALC_SIGN(reco::common::attr_key::kImageCount);
  LOG(INFO) << dynamic_index->GetIntAttr(key, doc_id, 256);
  delete news_index;
  delete set_item_attr;
  delete dynamic_index;
}

}  // namespace reco
