#pragma once

#include <cstdatomic>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <set>

#include "base/time/time.h"
#include "base/thread/thread.h"
#include "base/file/file_path.h"
#include "base/common/logging.h"
#include "reco/base/dict_manager/dynamic_dict.h"
#include "reco/bizc/common/channel_define.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/reco_index/dynamic_dict_container.h"
#include "third_party/yaml-cpp/include/yaml-cpp/yaml.h"

using reco::dm::ItemRule;
using reco::dm::ChannelRule;
using reco::dm::ChannelRuleIndex;
using reco::dm::FilterRule;

namespace reco {
class NewsIndex;

typedef struct reco::dm::ItemRule ItemPattern;

enum RuleType {
  kLeafChannelRule = 0,
  kVideoChannelRule = 1,
  kLeafExtendChannelRule = 2,
  kFilterRule = 3,
};

enum RecallType {
  kNoneRecall           = 0x0,  // 语义是禁止频道召回，这个毫无意义，只做保留标记
  kManualRecall         = 0x1,  // 0001，人工召回
  kRuleRecall           = 0x2,  // 0010，规则召回
  kRuleWithManualRecall = 0x3,  // 0011，规则 或 人工召回
};

enum ExtraTag {
  kIsLocalChannel = 1,  // 本地频道标记
};

class ChannelItemtypeDict {
 public:
  ChannelItemtypeDict();
  ~ChannelItemtypeDict();

  // 二级频道建设
 public:
  void GetLeafChannelsFromItemRule(const ItemInfo & item,
                                   const std::unordered_set<int64> & manual_channels,
                                   std::unordered_set<int64> *channels,
                                   const std::vector<int64> extra_tags,
                                   const reco::NewsIndex* news_index = NULL) {
    GetChannelsFromItemRule(item, kLeafChannelRule, manual_channels, channels, extra_tags, news_index);
  }

  void GetVideoChannelsFromItemRule(const ItemInfo & item,
                                    const std::unordered_set<int64> & manual_channels,
                                    std::unordered_set<int64> *channels,
                                    const reco::NewsIndex* news_index = NULL) {
    std::vector<int64> extra_tags;
    GetChannelsFromItemRule(item, kVideoChannelRule, manual_channels, channels, extra_tags, news_index);
  }
  void GetLeafExtendChannelsFromItemRule(const ItemInfo & item,
                                         std::unordered_set<int64> *channels,
                                         const reco::NewsIndex* news_index = NULL) {
    std::unordered_set<int64> manual_channels;
    std::vector<int64> extra_tags;
    GetChannelsFromItemRule(item, kLeafExtendChannelRule, manual_channels, channels, extra_tags, news_index);
  }

  std::map<int64, ChannelRule> DumpChannelRules(RuleType rule_type = kVideoChannelRule) const;

  static bool CheckVideo2ndChannel(int64 channel_id) {
    auto dict = DM_GET_DICT(reco::dm::ChannelItemRuleGalleryDict,
                            reco::DynamicDictContainer::kChannelItemRuleFile_);
    auto& manual_channels = const_cast<std::unordered_set<int64> &>(
                              dict->video_channel_engine.manual_channels);
    // 判断视频运营频道
    if (manual_channels.count(channel_id) > 0) {
      return true;
    }
    // 判断视频规则频道
    auto& channel_rule_map = const_cast<std::unordered_map<int64, ChannelRule>& >(
                               dict->video_channel_engine.channel_rule_map);
    return (channel_rule_map.find(channel_id) != channel_rule_map.end());
  }

  static bool IsVideoChannel(int64 channel_id) {
    if (channel_id == reco::common::kVideoChannelId || channel_id == reco::common::kThirdVideoChannelId) {
      return true;
    }
    return CheckVideo2ndChannel(channel_id);
  }

  // 全局过滤规则
  void RemoveForbidChannels(const ItemInfo & item,
                            std::unordered_set<int64> *channels,
                            const reco::NewsIndex* news_index = NULL);

  void AggregateSubordinateChannels(RuleType rule_type, std::unordered_set<int64> *channels);

  // Yaml 规则类型判断，返回 false 表示规则类型非法，返回 true 表示合法，并通过参数返回 rule_type 和 rule_id
  static bool ParseRuleTypeFromYAML(const YAML::Node & node, RuleType* rule_type, int64* rule_id);

  // YAML 的读取过程
  static bool ParseRuleFromYAML(const YAML::Node & node,
                                ChannelRule * channel_rule,
                                ChannelRuleIndex * channel_rule_index_permit,
                                ChannelRuleIndex * channel_rule_index_forbid,
                                std::unordered_set<int64> * manual_channels,
                                reco::dm::ChannelSubordinateMap * channel_subordinates_map);

  static bool ParseFilterFromYAML(const YAML::Node & node,
                                  reco::dm::FilterRule * filter_rule);

 private:
  inline void DoManualRecall(const std::unordered_set<int64> & manual_channels,
                      const std::unordered_set<int64> manual_channel_permit,
                      std::unordered_set<int64> *channels) {
    for (auto iter = manual_channels.begin(); iter != manual_channels.end(); ++iter) {
      if (manual_channel_permit.count(*iter) > 0) {
        channels->insert(*iter);
      }
    }
  }

  void GetChannelsFromItemRule(const ItemInfo & item,
                               RuleType rule_type,
                               const std::unordered_set<int64> & manual_channels,
                               std::unordered_set<int64> *channels,
                               const std::vector<int64> & extra_tags,
                               const reco::NewsIndex* news_index = NULL);

  void ExtractPatternFromItemInfo(const ItemInfo & item,
                                  ItemPattern *obj,
                                  const std::vector<int64> extra_tags,
                                  const reco::NewsIndex* news_index = NULL);

  void ChannelFMM(const ItemPattern & obj,
                  std::unordered_set<int64> & seed_channels,
                  std::unordered_map<int64, ChannelRule> & channel_rule_map,
                  std::unordered_set<int64> *channels);

  void GetRelatedChannels(const ItemPattern & obj,
                          RuleType rule_type,
                          std::unordered_set<int64> * channels);

  void GetChannelsFromItemRule(const ItemPattern & obj,
                               RuleType rule_type,
                               const std::unordered_set<int64> & manual_channels,
                               std::unordered_set<int64> *channels);

  void RemoveForbidChannelsInside(const ItemPattern & obj, std::unordered_set<int64> *channels);

  void GetDirtyChannels(const ItemPattern & obj,
                        reco::dm::FilterRule & filter,
                        std::unordered_set<int64> * channels,
                        std::vector<int64> * dirty_channels);

  void AggregateSubordinateChannelsInside(reco::dm::ChannelSubordinateMap & channel_subordinates_map,
                                          std::unordered_set<int64> *channels);

  static bool GetYamlNodeString(const YAML::Node & node, std::string * data);

  static bool GetYamlNodeInt64(const YAML::Node & node, int64 * data);

  FRIEND_TEST(ChannelItemtypeDictTest, Basic);
  FRIEND_TEST(ChannelItemtypeDictTest, Expanded);
  FRIEND_TEST(ChannelItemtypeDictTest, Subordinate);
  FRIEND_TEST(ChannelItemtypeDictTest, GlobalFilter);
};
}
