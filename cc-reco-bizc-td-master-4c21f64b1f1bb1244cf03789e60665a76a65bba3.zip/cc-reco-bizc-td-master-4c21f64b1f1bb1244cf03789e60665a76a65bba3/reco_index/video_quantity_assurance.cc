#include "reco/bizc/reco_index/video_quantity_assurance.h"

#include <cstdatomic>
#include <string>
#include <vector>
#include <unordered_map>
#include <fstream>
#include <utility>
#include "reco/bizc/proto/index_aux_data.pb.h"
#include "reco/bizc/reco_index/news_index.h"
#include "base/common/basic_types.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/encoding/line_escape.h"
#include "base/common/closure.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/memory_mapped_file.h"
#include "nlp/common/nlp_util.h"

#define DM_LOAD_DICT(var) reco::dm::DictManagerSingleton::instance().ReloadByDictName(#var)

namespace reco {

const char* VideoQuantityAssurance::kQuantityAssuranceFile_ = "quantity_assurance_source.txt";

VideoQuantityAssurance::VideoQuantityAssurance() {
}

VideoQuantityAssurance::~VideoQuantityAssurance() {
}

void VideoQuantityAssurance::Init() {
  DM_REGISTER_COMMON_DICT(UnorderedMapStrInt, kQuantityAssuranceFile_);
  DM_LOAD_DICT(kQuantityAssuranceFile_);
}

bool VideoQuantityAssurance::IsGeneralSource(const std::string& source) {
  auto source_dict = GetQuantityAssuranceSource();
  auto iter = source_dict->find(source);
  if (iter == source_dict->end()) {
    return false;
  } else {
    if (static_cast<QuantityAssuranceType>(iter->second) == kGeneral) {
      return true;
    }
    return false;
  }
}

bool VideoQuantityAssurance::IsOverseaSource(const std::string& source) {
  auto source_dict = GetQuantityAssuranceSource();
  auto iter = source_dict->find(source);
  if (iter == source_dict->end()) {
    return false;
  } else {
    if (static_cast<QuantityAssuranceType>(iter->second) == kOversea) {
      return true;
    }
    return false;
  }
}
}
