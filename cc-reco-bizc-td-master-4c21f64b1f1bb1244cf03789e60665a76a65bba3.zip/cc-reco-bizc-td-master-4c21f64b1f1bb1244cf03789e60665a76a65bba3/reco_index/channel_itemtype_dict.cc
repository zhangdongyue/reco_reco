#include <deque>
#include <fstream>

#include "reco/bizc/reco_index/channel_itemtype_dict.h"
#include "reco/bizc/reco_index/news_index.h"

#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "base/file/platform_file.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "serving_base/utility/timer.h"


namespace reco {

ChannelItemtypeDict::ChannelItemtypeDict() {
}

ChannelItemtypeDict::~ChannelItemtypeDict() {
}

bool ChannelItemtypeDict::ParseRuleTypeFromYAML(const YAML::Node & node,
                                                RuleType* rule_type, int64* rule_id) {
  if (rule_type == NULL || rule_id == NULL) {
    return false;
  }

  if (node.Type() != YAML::NodeType::Map) {
    LOG(WARNING) << "Yaml node format erroe: not Map";
    return false;
  }

  if (node.FindValue("leaf_channel_id")
      && ChannelItemtypeDict::GetYamlNodeInt64(node["leaf_channel_id"], rule_id)) {
    *rule_type = kLeafChannelRule;
    return true;
  } else if (node.FindValue("video_channel_id")
             && ChannelItemtypeDict::GetYamlNodeInt64(node["video_channel_id"], rule_id)) {
    *rule_type = kVideoChannelRule;
    return true;
  } else if (node.FindValue("leaf_extend_channel_id")
             && ChannelItemtypeDict::GetYamlNodeInt64(node["leaf_extend_channel_id"], rule_id)) {
    *rule_type = kLeafExtendChannelRule;
    return true;
  } else if (node.FindValue("filter_id")
             && ChannelItemtypeDict::GetYamlNodeInt64(node["filter_id"], rule_id)) {
    *rule_type = kFilterRule;
    return true;
  }
  return false;
}


bool ChannelItemtypeDict::ParseRuleFromYAML(const YAML::Node & node,
                                            ChannelRule * channel_rule,
                                            ChannelRuleIndex * channel_rule_index_permit,
                                            ChannelRuleIndex * channel_rule_index_forbid,
                                            std::unordered_set<int64> * manual_channels,
                                            reco::dm::ChannelSubordinateMap * channel_subordinates_map) {
  // 支持空规则，空规则用于允许直接由种子平台绑定的频道
  int64 recall_type = 0;
  if (node.FindValue("recall_type")
      && ChannelItemtypeDict::GetYamlNodeInt64(node["recall_type"], &recall_type)) {
    // 加入运营频道列表中，支持人工绑定召回
    if (recall_type & kManualRecall) {
      manual_channels->insert(channel_rule->channel_id);
      LOG(INFO) << "manual channel_id:" << channel_rule->channel_id;
    }

    // 对不做规则召回的频道，不入频道规则引擎
    if (!(recall_type & kRuleRecall)) {
      LOG(INFO) << "pure manual channel_id:" << channel_rule->channel_id;
      return false;
    }
  }

  // 支持频道聚合，即在一个频道中召回其他多个频道由规则匹配来的内容
  if (node.FindValue("subordinate")) {
    const YAML::Node& nodes = node["subordinate"];
    if (nodes.Type() != YAML::NodeType::Sequence) {
      LOG(WARNING) << "Yaml node format error: not Sequence, subordinate";
      return false;
    }
    for (auto i = 0u; i < nodes.size(); ++i) {
      int64 pattern = 0;
      if (!ChannelItemtypeDict::GetYamlNodeInt64(nodes[i], &pattern)) {
        continue;
      }
      if (channel_subordinates_map->count(pattern) <= 0) {
        channel_subordinates_map->insert(
          std::make_pair(pattern, std::unordered_set<int64>()));
      }
      channel_subordinates_map->at(pattern).insert(channel_rule->channel_id);
    }
  }

  // String 列表类型 key
  static std::vector<std::string> keys_string = {
    "category",
    "keyword",
    "basic_tag",
    "semantic_tag",
    "source",
    "source_media",
  };

  // Int64 列表类型 key
  static std::vector<std::string> keys_int64 = {
    "item_type",
    "style_type",
    "media_level",
    "is_source_wemedia",
    "extra_tag",
  };

  channel_rule->permit_list.clear();
  channel_rule->forbid_list.clear();

  std::unordered_map<std::string, std::vector<ItemRule> *> rule_type = {
    {"permit", &channel_rule->permit_list},
    {"forbid", &channel_rule->forbid_list}
  };

  std::unordered_map<std::string, ChannelRuleIndex *> index_type = {
    {"permit", channel_rule_index_permit},
    {"forbid", channel_rule_index_forbid}
  };

  for (auto iter = rule_type.begin(); iter != rule_type.end(); ++iter) {
    if (!node.FindValue(iter->first)) {
      continue;
    }
    const YAML::Node& nodes = node[iter->first];
    if (nodes.Type() != YAML::NodeType::Sequence) {
      LOG(WARNING) << "Yaml node format error: not Sequence, " << iter->first;
      return false;
    }

    ChannelRuleIndex * channel_rule_index = index_type[iter->first];
    std::vector<ItemRule> & rules = *iter->second;
    rules.resize(nodes.size());

    // 索引 String 列表类型绑定
    std::vector<std::unordered_map<std::string, std::unordered_set<int64> > *> index_string = {
      &channel_rule_index->category,
      &channel_rule_index->keyword,
      &channel_rule_index->basic_tag,
      &channel_rule_index->semantic_tag,
      &channel_rule_index->source,
      &channel_rule_index->source_media,
    };

    // 索引 Int64 列表类型绑定
    std::vector<std::unordered_map<int64, std::unordered_set<int64> > *> index_int64 = {
      &channel_rule_index->item_type,
      &channel_rule_index->style_type,
      &channel_rule_index->media_level,
      &channel_rule_index->is_source_wemedia,
      &channel_rule_index->extra_tag,
    };

    for (auto i = 0u; i < nodes.size(); ++i) {
      LOG(INFO) << iter->first << " rule " << i << ":";
      if (nodes[i].Type() != YAML::NodeType::Map) {
        LOG(WARNING) << "Yaml node format error: not Map, " << i;
        continue;
      }

      rules[i].auto_id = i;
      // String 列表类型绑定
      std::vector<std::unordered_set<std::string> *> model_string = {
        &rules[i].category,
        &rules[i].keyword,
        &rules[i].basic_tag,
        &rules[i].semantic_tag,
        &rules[i].source,
        &rules[i].source_media,
      };

      // Int64 列表类型绑定
      std::vector<std::unordered_set<int64> *> model_int64 = {
        &rules[i].item_type,
        &rules[i].style_type,
        &rules[i].media_level,
        &rules[i].is_source_wemedia,
        &rules[i].extra_tag,
      };

      // String 列表类型解析
      for (auto j = 0u; j < keys_string.size(); ++j) {
        if (!nodes[i].FindValue(keys_string[j])) {
          continue;
        }
        const YAML::Node& nlist = nodes[i][keys_string[j]];
        if (nlist.Type() != YAML::NodeType::Sequence) {
          LOG(WARNING) << "Yaml node format error: not Sequence"
                       << ", i:" << i << ", " << keys_string[j];
          continue;
        }

        for (auto k = 0u; k < nlist.size(); ++k) {
          std::string pattern;
          if (!ChannelItemtypeDict::GetYamlNodeString(nlist[k], &pattern)) {
            continue;
          }

          model_string[j]->insert(pattern);
          if (index_string[j]->find(pattern) == index_string[j]->end()) {
            std::unordered_set<int64> channels = {channel_rule->channel_id};
            index_string[j]->insert(std::make_pair(pattern, channels));
          } else {
            (*index_string[j])[pattern].insert(channel_rule->channel_id);
          }
          VLOG(1) << keys_string[j] << ":" << pattern;
        }
      }

      // Int64 列表类型解析
      for (auto j = 0u; j < keys_int64.size(); ++j) {
        if (!nodes[i].FindValue(keys_int64[j])) {
          continue;
        }
        const YAML::Node& nlist = nodes[i][keys_int64[j]];
        if (nlist.Type() != YAML::NodeType::Sequence) {
          LOG(WARNING) << "Yaml node format error: not Sequence"
                       << ", i:" << i << ", " << keys_string[j];
          continue;
        }

        for (auto k = 0u; k < nlist.size(); ++k) {
          int64 pattern;
          if (!ChannelItemtypeDict::GetYamlNodeInt64(nlist[k], &pattern)) {
            continue;
          }

          model_int64[j]->insert(pattern);
          if (index_int64[j]->find(pattern) == index_int64[j]->end()) {
            index_int64[j]->insert(std::make_pair(pattern, std::unordered_set<int64>()));
          }
          index_int64[j]->at(pattern).insert(channel_rule->channel_id);
          LOG(INFO) << keys_int64[j] << ":" << pattern;
        }
      }
    }
  }

  return true;
}

bool ChannelItemtypeDict::ParseFilterFromYAML(const YAML::Node & node, reco::dm::FilterRule * filter_rule) {
  // String 列表类型 key
  static std::vector<std::string> keys_string = {
    "category",
    "keyword",
    "basic_tag",
    "semantic_tag",
    "source",
    "source_media",
  };

  // Int64 列表类型 key
  static std::vector<std::string> keys_int64 = {
    "item_type",
    "style_type",
    "media_level",
    "is_source_wemedia",
    "extra_tag",
  };

  filter_rule->type = 0;
  filter_rule->match_list.clear();
  filter_rule->except_list.clear();
  filter_rule->channel_set.clear();

  if (node.FindValue("channel_set")) {
    const YAML::Node& nodes = node["channel_set"];
    if (nodes.Type() != YAML::NodeType::Sequence) {
      LOG(WARNING) << "Yaml node format error: not Sequence, channel_set";
      return false;
    }

    for (auto i = 0u; i < nodes.size(); ++i) {
      int64 channel_id = 0;
      if (!ChannelItemtypeDict::GetYamlNodeInt64(nodes[i], &channel_id)) {
        continue;
      }
      filter_rule->channel_set.insert(channel_id);
      LOG(INFO) << "channel_id:" << channel_id;
    }
  }

  if (node.FindValue("type")) {
    std::string pattern;
    if (ChannelItemtypeDict::GetYamlNodeString(node["type"], &pattern)) {
      if (pattern == "out_set") {
        filter_rule->type = 1;
      }
    }
  }

  std::unordered_map<std::string, std::vector<ItemRule> *> rule_type = {
    {"match", &filter_rule->match_list},
    {"except", &filter_rule->except_list},
  };

  for (auto iter = rule_type.begin(); iter != rule_type.end(); ++iter) {
    if (!node.FindValue(iter->first)) {
      continue;
    }
    const YAML::Node& nodes = node[iter->first];
    if (nodes.Type() != YAML::NodeType::Sequence) {
      LOG(WARNING) << "Yaml node format error: not Sequence, " << iter->first;
      return false;
    }

    std::vector<ItemRule> & rules = *iter->second;
    rules.resize(nodes.size());

    for (auto i = 0u; i < nodes.size(); ++i) {
      LOG(INFO) << iter->first << " rule " << i << ":";
      if (nodes[i].Type() != YAML::NodeType::Map) {
        LOG(WARNING) << "Yaml node format error: not Map, " << i;
        continue;
      }

      rules[i].auto_id = i;
      // String 列表类型绑定
      std::vector<std::unordered_set<std::string> *> model_string = {
        &rules[i].category,
        &rules[i].keyword,
        &rules[i].basic_tag,
        &rules[i].semantic_tag,
        &rules[i].source,
        &rules[i].source_media,
      };

      // Int64 列表类型绑定
      std::vector<std::unordered_set<int64> *> model_int64 = {
        &rules[i].item_type,
        &rules[i].style_type,
        &rules[i].media_level,
        &rules[i].is_source_wemedia,
        &rules[i].extra_tag,
      };

      // String 列表类型解析
      for (auto j = 0u; j < keys_string.size(); ++j) {
        if (!nodes[i].FindValue(keys_string[j])) {
          continue;
        }
        const YAML::Node& nlist = nodes[i][keys_string[j]];
        if (nlist.Type() != YAML::NodeType::Sequence) {
          LOG(WARNING) << "Yaml node format error: not Sequence"
                       << ", i:" << i << ", " << keys_string[j];
          continue;
        }

        for (auto k = 0u; k < nlist.size(); ++k) {
          std::string pattern;
          if (!ChannelItemtypeDict::GetYamlNodeString(nlist[k], &pattern)) {
            continue;
          }
          model_string[j]->insert(pattern);
          LOG(INFO) << keys_string[j] << ":" << pattern;
        }
      }

      // Int64 列表类型解析
      for (auto j = 0u; j < keys_int64.size(); ++j) {
        if (!nodes[i].FindValue(keys_int64[j])) {
          continue;
        }
        const YAML::Node& nlist = nodes[i][keys_int64[j]];
        if (nlist.Type() != YAML::NodeType::Sequence) {
          LOG(WARNING) << "Yaml node format error: not Sequence"
                       << ", i:" << i << ", key:" << keys_string[j];
          continue;
        }

        for (auto k = 0u; k < nlist.size(); ++k) {
          int64 pattern;
          if (!ChannelItemtypeDict::GetYamlNodeInt64(nlist[k], &pattern)) {
            continue;
          }
          model_int64[j]->insert(pattern);
          LOG(INFO) << keys_int64[j] << ":" << pattern;
        }
      }
    }
  }
  return true;
}


void ChannelItemtypeDict::ExtractPatternFromItemInfo(const ItemInfo & item,
                                                     ItemPattern *obj,
                                                     const std::vector<int64> extra_tags,
                                                     const reco::NewsIndex* news_index) {
  CHECK(obj != NULL);
  obj->Clear();

  // 分类等基本信息
  obj->auto_id = item.item_id;
  obj->category.insert(item.category);
  if (!item.sub_category.empty()) {
    obj->category.insert(item.category + "-" + item.sub_category);
  }
  obj->item_type.insert(item.item_type);
  obj->media_level.insert(item.media_level);
  if (item.is_source_wemedia) {
    obj->is_source_wemedia.insert(1);
  } else {
    obj->is_source_wemedia.insert(0);
  }

  // 需要从 news_index 中查询额外信息
  if (news_index != NULL) {
    // 标签类规则
    std::vector<reco::common::FeatureType> feature_types = {reco::common::kKeyword,
                                                            reco::common::kTag,
                                                            reco::common::kSemanticTag};
    std::vector<std::unordered_set<std::string> *> patterns = {&obj->keyword,
                                                                 &obj->basic_tag,
                                                                 &obj->semantic_tag};
    for (auto i = 0u; i < feature_types.size(); ++i) {
      std::map<std::string, double> item_feature;
      double item_norm2;
      news_index->GetFeatureMapByDocId(item.doc_id, feature_types[i], &item_feature, &item_norm2);
      for (auto iter_fea = item_feature.begin(); iter_fea != item_feature.end(); ++iter_fea) {
        std::string tag = iter_fea->first;
        std::vector<std::string> string_pair;
        base::SplitString(iter_fea->first, ":", &string_pair);
        if (string_pair.size() > 1) {
          tag = string_pair[1];
        }
        patterns[i]->insert(tag);
      }
    }

    std::string source;
    news_index->GetSourceByDocId(item.doc_id, &source);
    if (!source.empty()) {
      obj->source.insert(source);
    }

    std::string source_media;
    news_index->GetSourceMediaByDocId(item.doc_id, &source_media);
    if (!source_media.empty()) {
      obj->source_media.insert(source_media);
    }

    int64 style_type = news_index->GetUCBStyleTypeByDocId(item.doc_id);
    if (style_type >= 0) {
      obj->style_type.insert(style_type);
    }
  }

  for (auto i = 0u; i < extra_tags.size(); ++i) {
    obj->extra_tag.insert(extra_tags[i]);
  }
}


bool ItemRule::Match(const ItemRule & obj) {
  // string 特征模板
  std::vector<std::unordered_set<std::string> *> model_string = {
      const_cast<std::unordered_set<std::string>*> (&category),
      const_cast<std::unordered_set<std::string>*> (&keyword),
      const_cast<std::unordered_set<std::string>*> (&basic_tag),
      const_cast<std::unordered_set<std::string>*> (&semantic_tag),
      const_cast<std::unordered_set<std::string>*> (&source),
      const_cast<std::unordered_set<std::string>*> (&source_media),
  };

  // string 目标匹配
  std::vector<std::unordered_set<std::string> *> pattern_string = {
      const_cast<std::unordered_set<std::string>*> (&obj.category),
      const_cast<std::unordered_set<std::string>*> (&obj.keyword),
      const_cast<std::unordered_set<std::string>*> (&obj.basic_tag),
      const_cast<std::unordered_set<std::string>*> (&obj.semantic_tag),
      const_cast<std::unordered_set<std::string>*> (&obj.source),
      const_cast<std::unordered_set<std::string>*> (&obj.source_media),
  };

  // int64 特征模板
  std::vector<std::unordered_set<int64> *> model_int64 = {
    const_cast<std::unordered_set<int64>*> (&extra_tag),
    const_cast<std::unordered_set<int64>*> (&item_type),
    const_cast<std::unordered_set<int64>*> (&style_type),
    const_cast<std::unordered_set<int64>*> (&media_level),
    const_cast<std::unordered_set<int64>*> (&is_source_wemedia),
  };

  // int64 目标匹配
  std::vector<std::unordered_set<int64> *> pattern_int64 = {
    const_cast<std::unordered_set<int64>*> (&obj.extra_tag),
    const_cast<std::unordered_set<int64>*> (&obj.item_type),
    const_cast<std::unordered_set<int64>*> (&obj.style_type),
    const_cast<std::unordered_set<int64>*> (&obj.media_level),
    const_cast<std::unordered_set<int64>*> (&obj.is_source_wemedia),
  };

  bool checked = false;
  for (auto i = 0u; i < model_int64.size(); ++i) {
    if (!model_int64[i]->empty()) {
      bool found = false;
      checked = true;
      for (auto iter = pattern_int64[i]->begin(); !found && iter != pattern_int64[i]->end(); ++iter) {
        if (model_int64[i]->find(*iter) != model_int64[i]->end()) {
          found = true;
        }
      }
      if (!found) {
        return false;
      }
    }
  }

  for (auto i = 0u; i < model_string.size(); ++i) {
    if (!model_string[i]->empty()) {
      bool found = false;
      checked = true;
      for (auto iter = pattern_string[i]->begin(); !found && iter != pattern_string[i]->end(); ++iter) {
        if (model_string[i]->find(*iter) != model_string[i]->end()) {
          found = true;
        }
      }
      if (!found) {
        return false;
      }
    }
  }
  return checked;
}


void ChannelItemtypeDict::GetRelatedChannels(const ItemPattern & obj,
                                             RuleType rule_type,
                                             std::unordered_set<int64> * channels) {
  // string 类型绑定
  std::vector<std::unordered_set<std::string> *> pattern_string = {
    const_cast<std::unordered_set<std::string>*> (&obj.category),
    const_cast<std::unordered_set<std::string>*> (&obj.keyword),
    const_cast<std::unordered_set<std::string>*> (&obj.basic_tag),
    const_cast<std::unordered_set<std::string>*> (&obj.semantic_tag),
    const_cast<std::unordered_set<std::string>*> (&obj.source),
    const_cast<std::unordered_set<std::string>*> (&obj.source_media),
  };

  // int64 类型绑定
  std::vector<std::unordered_set<int64> *> pattern_int64 = {
    const_cast<std::unordered_set<int64>*> (&obj.item_type),
    const_cast<std::unordered_set<int64>*> (&obj.style_type),
    const_cast<std::unordered_set<int64>*> (&obj.media_level),
    const_cast<std::unordered_set<int64>*> (&obj.is_source_wemedia),
    // 在 channel 候选阶段，不匹配 extra tag ，减少候选集规模
    // const_cast<std::unordered_set<std::string>*> (&obj.extra_tag),
  };

  std::vector<ChannelRuleIndex *> channel_rule_index_list;
  auto dict = DM_GET_DICT(reco::dm::ChannelItemRuleGalleryDict,
                          reco::DynamicDictContainer::kChannelItemRuleFile_);
  switch (rule_type) {
    case reco::kLeafChannelRule:
      channel_rule_index_list.push_back(const_cast<reco::dm::ChannelRuleIndex* >(
                                          &(dict->leaf_channel_engine.channel_rule_index_permit)));
      channel_rule_index_list.push_back(const_cast<reco::dm::ChannelRuleIndex* >(
                                          &(dict->leaf_channel_engine.channel_rule_index_forbid)));
      break;
    case reco::kVideoChannelRule:
      channel_rule_index_list.push_back(const_cast<reco::dm::ChannelRuleIndex* >(
                                          &(dict->video_channel_engine.channel_rule_index_permit)));
      channel_rule_index_list.push_back(const_cast<reco::dm::ChannelRuleIndex* >(
                                          &(dict->video_channel_engine.channel_rule_index_forbid)));
      break;
    case reco::kLeafExtendChannelRule:
      channel_rule_index_list.push_back(const_cast<reco::dm::ChannelRuleIndex* >(
                                          &(dict->leaf_extend_channel_engine.channel_rule_index_permit)));
      channel_rule_index_list.push_back(const_cast<reco::dm::ChannelRuleIndex* >(
                                          &(dict->leaf_extend_channel_engine.channel_rule_index_forbid)));
      break;
    default:
      return;
  };

  // 获取涉及的 channel 集合
  for (auto i_type = 0u; i_type < channel_rule_index_list.size(); ++i_type) {
    auto& channel_rule_index = *channel_rule_index_list[i_type];

    // 索引 String 列表类型绑定
    std::vector<std::unordered_map<std::string, std::unordered_set<int64> > *> index_string = {
      &channel_rule_index.category,
      &channel_rule_index.keyword,
      &channel_rule_index.basic_tag,
      &channel_rule_index.semantic_tag,
      &channel_rule_index.source,
      &channel_rule_index.source_media,
    };

    // 索引 Int64 列表类型绑定
    std::vector<std::unordered_map<int64, std::unordered_set<int64> > *> index_int64 = {
      &channel_rule_index.item_type,
      &channel_rule_index.style_type,
      &channel_rule_index.media_level,
      &channel_rule_index.is_source_wemedia,
      // 在 channel 候选阶段，不匹配 extra tag ，减少候选集规模
      // &channel_rule_index.extra_tag,
    };

    for (auto i = 0u; i < pattern_string.size(); ++i) {
      if (!pattern_string[i]->empty()) {
        for (auto iter = pattern_string[i]->begin(); iter != pattern_string[i]->end(); ++iter) {
          auto channel_map = index_string[i]->find(*iter);
          if (channel_map != index_string[i]->end()) {
            for (auto it_channel = channel_map->second.begin();
                 it_channel != channel_map->second.end(); ++it_channel) {
              channels->insert(*it_channel);
            }
          }
        }
      }
    }

    for (auto i = 0u; i < pattern_int64.size(); ++i) {
      if (!pattern_int64[i]->empty()) {
        for (auto iter = pattern_int64[i]->begin(); iter != pattern_int64[i]->end(); ++iter) {
          auto channel_map = index_int64[i]->find(*iter);
          if (channel_map != index_int64[i]->end()) {
            for (auto it_channel = channel_map->second.begin();
                 it_channel != channel_map->second.end(); ++it_channel) {
              channels->insert(*it_channel);
            }
          }
        }
      }
    }
  }
}


void ChannelItemtypeDict::ChannelFMM(const ItemPattern & obj,
                                     std::unordered_set<int64> & seed_channels,
                                     std::unordered_map<int64, ChannelRule> & channel_rule_map,
                                     std::unordered_set<int64> *channels) {
  CHECK(channels != NULL);

  // 遍历规则集，取出所有匹配的频道
  for (auto iter = seed_channels.begin(); iter != seed_channels.end(); ++iter) {
    if (channel_rule_map.find(*iter) == channel_rule_map.end()) {
      continue;
    }

    int64 permit_rule_id = -1;
    int64 forbid_rule_id = -1;

    for (auto i = 0u; forbid_rule_id < 0
         && i < channel_rule_map[*iter].forbid_list.size(); ++i) {
      if (channel_rule_map[*iter].forbid_list[i].Match(obj)) {
        forbid_rule_id = i;
      }
    }

    for (auto i = 0u; forbid_rule_id < 0 && permit_rule_id < 0
         && i < channel_rule_map[*iter].permit_list.size(); ++i) {
      if (channel_rule_map[*iter].permit_list[i].Match(obj)) {
        permit_rule_id = i;
      }
    }

    if (permit_rule_id >= 0) {
      channels->insert(*iter);
      VLOG(3)  << "[PERMIT] item_id:" << obj.auto_id
               << ", channel id:" << *iter
               << ", by rule:" << permit_rule_id;
    } else if (forbid_rule_id >= 0) {
      VLOG(3)  << "[FORBID] item_id:" << obj.auto_id
               << ", channel id:" << *iter
               << ", by rule:" << forbid_rule_id;
    }
  }
}


void ChannelItemtypeDict::GetChannelsFromItemRule(const ItemPattern & obj,
                                                  RuleType rule_type,
                                                  const std::unordered_set<int64> & manual_channels,
                                                  std::unordered_set<int64> *channels) {
  CHECK(channels != NULL);
  serving_base::Timer timer;
  timer.Start();

  std::unordered_set<int64> seed_channels;
  GetRelatedChannels(obj, rule_type, &seed_channels);
  for (auto iter = seed_channels.begin(); iter != seed_channels.end(); ++iter) {
    VLOG(3) << "seed channel introduce:" << *iter;
  }

  auto dict = DM_GET_DICT(reco::dm::ChannelItemRuleGalleryDict,
                          reco::DynamicDictContainer::kChannelItemRuleFile_);
  switch (rule_type) {
    case reco::kLeafChannelRule:
      ChannelFMM(obj, seed_channels,
                 const_cast<std::unordered_map<int64, ChannelRule>&>(
                   dict->leaf_channel_engine.channel_rule_map),
                 channels);
      DoManualRecall(manual_channels, dict->leaf_channel_engine.manual_channels, channels);
      break;
    case reco::kVideoChannelRule:
      ChannelFMM(obj, seed_channels,
                 const_cast<std::unordered_map<int64, ChannelRule>&>(
                   dict->video_channel_engine.channel_rule_map),
                 channels);
      DoManualRecall(manual_channels, dict->video_channel_engine.manual_channels, channels);
      break;
    case reco::kLeafExtendChannelRule:
      ChannelFMM(obj, seed_channels,
                 const_cast<std::unordered_map<int64, ChannelRule>&>(
                   dict->leaf_extend_channel_engine.channel_rule_map),
                 channels);
      DoManualRecall(manual_channels, dict->leaf_extend_channel_engine.manual_channels, channels);
      break;
    default:
      break;
  }
  for (auto iter = channels->begin(); iter != channels->end(); ++iter) {
    VLOG(3) << "candidate channel insert:" << *iter;
  }

  VLOG(4) << "channel rule matching cost:" << timer.Stop() << " us";
}


void ChannelItemtypeDict::GetChannelsFromItemRule(const ItemInfo & item,
                                                  RuleType rule_type,
                                                  const std::unordered_set<int64> & manual_channels,
                                                  std::unordered_set<int64> *channels,
                                                  const std::vector<int64> & extra_tags,
                                                  const reco::NewsIndex* news_index) {
  ItemPattern obj;
  ExtractPatternFromItemInfo(item, &obj, extra_tags, news_index);
  GetChannelsFromItemRule(obj, rule_type, manual_channels, channels);
}


void ChannelItemtypeDict::RemoveForbidChannels(const ItemInfo & item,
                                               std::unordered_set<int64> *channels,
                                               const reco::NewsIndex* news_index) {
  if (channels == NULL || channels->size() <= 0) {
    return;
  }

  std::vector<int64> extra_tags;
  ItemPattern obj;
  ExtractPatternFromItemInfo(item, &obj, extra_tags, news_index);
  RemoveForbidChannelsInside(obj, channels);
}

void ChannelItemtypeDict::RemoveForbidChannelsInside(const ItemPattern & obj,
                                                     std::unordered_set<int64> *channels) {
  if (channels == NULL || channels->size() <= 0) {
    return;
  }
  auto dict = DM_GET_DICT(reco::dm::ChannelItemRuleGalleryDict,
                          reco::DynamicDictContainer::kChannelItemRuleFile_);
  auto& filter_rules = const_cast<std::vector<reco::dm::FilterRule>& >(dict->filter_rules);

  for (auto i = 0u; i < filter_rules.size(); ++i) {
    std::vector<int64> channels_to_delete;
    GetDirtyChannels(obj, filter_rules[i], channels, &channels_to_delete);
    for (auto j = 0u; j < channels_to_delete.size(); ++j) {
      channels->erase(channels_to_delete[j]);
    }
  }
}


void ChannelItemtypeDict::GetDirtyChannels(const ItemPattern & obj,
                                           reco::dm::FilterRule & filter,
                                           std::unordered_set<int64> * channels,
                                           std::vector<int64> * dirty_channels) {
  dirty_channels->clear();

  int64 match_rule_id = -1;
  int64 except_rule_id = -1;

  for (auto i = 0u; except_rule_id < 0
       && i < filter.except_list.size(); ++i) {
    if (filter.except_list[i].Match(obj)) {
      except_rule_id = i;
    }
  }

  for (auto i = 0u; except_rule_id < 0 && match_rule_id < 0
       && i < filter.match_list.size(); ++i) {
    if (filter.match_list[i].Match(obj)) {
      match_rule_id = i;
    }
  }

  if (match_rule_id >= 0) {
      for (auto iter = channels->begin(); iter != channels->end(); ++iter) {
        if (filter.type == 0 && filter.channel_set.count(*iter) > 0) {
          // 枚举模式，只匹配规则中涉及到的 channel
          dirty_channels->push_back(*iter);
        } else if (filter.type == 1 && filter.channel_set.count(*iter) == 0) {
          // 例外模式，匹配所有规则中未涉及到的 channel
          dirty_channels->push_back(*iter);
        }
      }
      for (auto i = 0u; i < dirty_channels->size(); ++i) {
        VLOG(4)  << "[MATCH] item_id:" << obj.auto_id
                 << ", filter id:" << filter.filter_id
                 << ", by rule:" << match_rule_id;
      }
  } else if (except_rule_id >= 0) {
    VLOG(4)  << "[EXCEPT] item_id:" << obj.auto_id
             << ", filter id:" << filter.filter_id
             << ", by rule:" << except_rule_id;
  }
}

void ChannelItemtypeDict::AggregateSubordinateChannelsInside(
      reco::dm::ChannelSubordinateMap & channel_subordinates_map,
      std::unordered_set<int64> *channels) {
  std::deque<int64> channel_expand_queue;
  for (auto iter = channels->begin(); iter != channels->end(); ++iter) {
    channel_expand_queue.push_back(*iter);
  }

  while (!channel_expand_queue.empty()) {
    int64 channel_id = channel_expand_queue.front();
    channel_expand_queue.pop_front();
    if (channel_subordinates_map.find(channel_id) != channel_subordinates_map.end()) {
      for (auto it_sub = channel_subordinates_map[channel_id].begin();
           it_sub !=  channel_subordinates_map[channel_id].end(); ++it_sub) {
        if (channels->count(*it_sub) <= 0) {
          channel_expand_queue.push_back(*it_sub);
        }
      }
    }
    channels->insert(channel_id);
  }
}

void ChannelItemtypeDict::AggregateSubordinateChannels(RuleType rule_type,
                                                       std::unordered_set<int64> *channels) {
  auto dict = DM_GET_DICT(reco::dm::ChannelItemRuleGalleryDict,
                          reco::DynamicDictContainer::kChannelItemRuleFile_);
  switch (rule_type) {
    case reco::kLeafChannelRule:
      AggregateSubordinateChannelsInside(
        const_cast<reco::dm::ChannelSubordinateMap&>(
          dict->leaf_channel_engine.channel_subordinates_map),
        channels);
      break;
    case reco::kVideoChannelRule:
      AggregateSubordinateChannelsInside(
        const_cast<reco::dm::ChannelSubordinateMap&>(
          dict->video_channel_engine.channel_subordinates_map),
        channels);
      break;
    case reco::kLeafExtendChannelRule:
      AggregateSubordinateChannelsInside(
        const_cast<reco::dm::ChannelSubordinateMap&>(
          dict->leaf_extend_channel_engine.channel_subordinates_map),
        channels);
      break;
    default:
      break;
  }
}

bool ChannelItemtypeDict::GetYamlNodeString(const YAML::Node & node, std::string* data) {
  if (data == NULL) return false;
  if (node.Type() != YAML::NodeType::Scalar) {
    LOG(WARNING) << "Yaml node format error: not Scalar";
    return false;
  }
  try {
    node >> *data;
  } catch(YAML::ParserException & e) {
    *data = "";
    LOG(WARNING) << "Yaml load failed: " << e.what();
    return false;
  }
  return true;
}

bool ChannelItemtypeDict::GetYamlNodeInt64(const YAML::Node & node, int64* data) {
  std::string data_str;
  if (!ChannelItemtypeDict::GetYamlNodeString(node, &data_str)) {
    return false;
  }
  if (!base::StringToInt64(data_str, data)) {
    return false;
  }
  return true;
}

std::map<int64, ChannelRule> ChannelItemtypeDict::DumpChannelRules(RuleType rule_type) const {
  std::map<int64, ChannelRule> dump_channel_map;
  auto dict = DM_GET_DICT(reco::dm::ChannelItemRuleGalleryDict,
                          reco::DynamicDictContainer::kChannelItemRuleFile_);
  std::unordered_map<int64, ChannelRule> *channel_rule_map = NULL;

  switch (rule_type) {
    case reco::kLeafChannelRule:
      channel_rule_map = const_cast<std::unordered_map<int64, ChannelRule>* >(
                           &dict->leaf_channel_engine.channel_rule_map);
      break;
    case reco::kVideoChannelRule:
      channel_rule_map = const_cast<std::unordered_map<int64, ChannelRule>* >(
                           &dict->video_channel_engine.channel_rule_map);
      break;
    case reco::kLeafExtendChannelRule:
      channel_rule_map = const_cast<std::unordered_map<int64, ChannelRule>* >(
                           &dict->leaf_extend_channel_engine.channel_rule_map);
      break;
    default:
      return dump_channel_map;
  }
  if (channel_rule_map == NULL) {
    return dump_channel_map;
  }

  for (auto iter = channel_rule_map->begin(); iter != channel_rule_map->end(); ++iter) {
    ChannelRule channel_rule;
    channel_rule.channel_id = iter->second.channel_id;
    for (auto i = 0u; i < iter->second.permit_list.size(); ++i) {
      ItemRule rule;
      rule.CopyFrom(iter->second.permit_list[i]);
      channel_rule.permit_list.push_back(rule);
    }
    for (auto i = 0u; i < iter->second.forbid_list.size(); ++i) {
      ItemRule rule;
      rule.CopyFrom(iter->second.forbid_list[i]);
      channel_rule.forbid_list.push_back(rule);
    }
    dump_channel_map.insert(std::make_pair(iter->first, channel_rule));
  }
  return dump_channel_map;
}
}
