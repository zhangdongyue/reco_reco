#pragma once

#include <string>
#include <vector>
#include "base/common/base.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto_arpc/reco_doc_server.pb.h"
#include "reco/bizc/item_service/get_item.h"
#include "client_pool/ArpcClientPool.h"
//#include "arpc/CommonMacros.h"
//#include "arpc/RPCInterface.h"

namespace reco {

// NOTE: not thread safe
class DocServerGetItem : public BaseGetItem {
 public:
  // doc_server_ips, multiple ip joined by ","
  // cache size: lru cache size, set to <=0 will not use cache
  DocServerGetItem(const std::string& doc_server_ips, int doc_server_port);
  DocServerGetItem(const std::string& doc_server_ips, int doc_server_port, int cache_size);
  virtual ~DocServerGetItem();

 protected:
  virtual void GetRecoItemsImpl(const std::vector<uint64>& item_ids,
                                std::vector<reco::RecoItem>* reco_items);

  void InitConnect(const std::string& doc_server_ips, int doc_server_port);

 private:
  static const int kRpcTimeout = 10000;

  arpc_client_pool::client_pool::ArpcClientPool<reco::docserver::RecoDocService_Stub> *conn_pool_;
  
//  net::rpc::RpcGroup* rpc_group_;
//  reco::docserver::RecoDocService::Stub *rpc_stub_;
};
}  // namespace reco

