#include <string>
#include <vector>
#include "arpc/ANetRPCController.h"
#include "client_pool/ArpcClientPool.h"
#include "reco/bizc/item_service_arpc/doc_server_get_item.h"
#include "reco/bizc/proto_arpc/reco_doc_server.pb.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/base.h"

using namespace arpc;
using namespace arpc_client_pool::client_pool;

namespace reco {
DocServerGetItem::DocServerGetItem(const std::string& doc_server_ips, int doc_server_port) {
    conn_pool_ = NULL;
  InitConnect(doc_server_ips, doc_server_port);
}

DocServerGetItem::DocServerGetItem(const std::string& doc_server_ips, int doc_server_port, int cache_size)
  : BaseGetItem(cache_size) {
  conn_pool_ = NULL;
  InitConnect(doc_server_ips, doc_server_port);
}

DocServerGetItem::~DocServerGetItem() {
  if(conn_pool_) {
    delete conn_pool_;
  }
}

void DocServerGetItem::InitConnect(const std::string& doc_server_ips, int doc_server_port) {
  if(conn_pool_){
    cout << "doc server conn pool already init" << endl;
    return;
  }

  std::vector<std::string> flds;
  base::SplitString(doc_server_ips, ",", &flds); 
  PoolParams params;
  params.clientCount = 10 * (int)flds.size();

  std::set<StubInfo> stub_info;
  for (const auto& ip : flds) {
    stub_info.insert(StubInfo(ip, doc_server_port));
  }

  conn_pool_ = new ArpcClientPool<reco::docserver::RecoDocService_Stub>;
  if (!conn_pool_->init(params, stub_info)) {
    cout << "doc server conn pool init failed." << endl;
    return;
  }
}

void DocServerGetItem::GetRecoItemsImpl(const std::vector<uint64>& item_ids,
                                        std::vector<reco::RecoItem>* reco_items) {
  if(!conn_pool_){
    LOG(INFO) <<"doc server conn pool not init";
    return;
  }

  auto stub_ptr = conn_pool_->get();
  if(!stub_ptr || !stub_ptr->stub()){
    LOG(INFO) <<"doc server conn pool get stub fail";
    return;    
  }

  reco::doc::RecoItemRequest request;
  request.set_clear_raw_item(false);
  for (int i = 0; i < (int)item_ids.size(); ++i) {
    const uint64 id = item_ids[i];
    RecoItem item;
    if (!ReadCache(id, &item)) {
      request.add_item_id(id);
    } else {
      reco_items->push_back(item);
    }
  }

  if (request.item_id_size() == 0) {
    return;
  } else {
  }

  ANetRPCController controller;
  controller.SetExpireTime(kRpcTimeout);

  reco::doc::RecoItemResponse response;
  stub_ptr->stub()->GetRecoItemInfo(&controller, &request, &response, NULL);

  int err_code = controller.GetErrorCode();
  if(controller.Failed() || err_code != arpc::ARPC_ERROR_NONE){
    LOG(ERROR) << "get reco item failed: " << controller.ErrorText()
        << " ip=" << stub_ptr->info().ip();
    return;
  }

  for (int i = 0; i < response.item_size(); ++i) {
    reco_items->push_back(response.item(i));
    WriteCache(response.item(i).identity().item_id(),
               response.item(i));
  }
}
}  // namespace reco

