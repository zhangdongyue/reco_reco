#include <iostream>
#include <unordered_map>
#include <fstream>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "client_pool/ArpcClientPool.h"
#include "arpc/RPCChannelBase.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/time/timestamp.h"
#include "serving_base/utility/time_helper.h"
#include "reco/bizc/common/wrapped_category.h"
#include "reco/bizc/proto/query_reco_type.pb.h"
#include "reco/bizc/proto_arpc/query_reco_server.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "google/protobuf/text_format.h"

DEFINE_string(user_id, "0", "user id");
DEFINE_string(app_token, "uc-iflow", "app token");
DEFINE_string(utdid, "", "");
DEFINE_string(acpf_type, "", "");
DEFINE_string(tacid, "", "");
DEFINE_string(tuicid, "", "");
DEFINE_string(sn, "", "");
DEFINE_string(imei, "", "");
DEFINE_bool(is_new, false, "");
DEFINE_string(server_spec, "11.140.18.230:20088", "query server rpc");
DEFINE_string(server_ip, "11.140.18.230", "query server ip");
DEFINE_int32(server_port, 20088, "query server port");

using namespace arpc_client_pool::client_pool;
using namespace reco::queryreco;

int main(int argc, char **argv) {
    base::InitApp(&argc, &argv, "user info client");
    
	ARPC_CLIENT_POOL_LOG_CONFIG("alog.conf");
    arpc_client_pool::client_pool::ArpcClientPool<reco::queryreco::RecommendService_Stub> query_conn_pool;
    PoolParams params;
    params.clientCount = 1;
    params.version = 0;
    //params.connectTimeout = 1000000;
    std::set<StubInfo> stub_info;
    stub_info.insert(StubInfo(FLAGS_server_ip, FLAGS_server_port));

    bool ret = query_conn_pool.init(params, stub_info);
    cout << "init result:" << ret << endl;
    auto stub_ptr = query_conn_pool.get();
    //static_cast<arpc::RPCChannelBase*>(stub_ptr->stub()->channel())->SetVersion(0);
    

    /*
    auto transport = new anet::Transport(1);
    transport->setTimeoutLoopInterval(1000);
    auto rpcChannelManager = new arpc::ANetRPCChannelManager(transport);
    transport->start();
    google::protobuf::RpcChannel* channel = rpcChannelManager->OpenChannel("tcp:" + FLAGS_server_spec,
                                                                                false, 100, 100000, false);
    static_cast<arpc::RPCChannelBase*>(channel)->SetVersion(0);
    reco::queryreco::RecommendService_Stub *stub = new reco::queryreco::RecommendService_Stub(channel, google::protobuf::Service::STUB_OWNS_CHANNEL);
    */

    uint64 user_id;
    CHECK(base::StringToUint64(FLAGS_user_id, &user_id));
    reco::UserIdentity user;
    user.set_app_token(FLAGS_app_token);
    user.set_outer_id(FLAGS_user_id);
    user.set_user_id(user_id);
    if (!FLAGS_utdid.empty()) {
        user.set_utdid(FLAGS_utdid);
    }
    if (!FLAGS_utdid.empty()) {
        user.set_utdid(FLAGS_utdid);
    }
    if (!FLAGS_acpf_type.empty()) {
        user.set_acpf_type(FLAGS_acpf_type);
    }
    if (!FLAGS_tacid.empty()) {
        user.set_tacid(FLAGS_tacid);
    }
    if (!FLAGS_tuicid.empty()) {
        user.set_tuicid(FLAGS_tuicid);
    }
    if (!FLAGS_sn.empty()) {
        user.set_sn(FLAGS_sn);
    }
    if (!FLAGS_imei.empty()) {
        user.set_imei(FLAGS_imei);
    }
    if (!FLAGS_is_new) {
        user.set_is_new(FLAGS_is_new);
    }

    RecommendRequest request;
    request.mutable_user()->CopyFrom(user);
    request.set_return_num(10);
    request.set_is_new_user(false);
    request.set_reco_id("11894133197414486022");
    RecommendResponse response;
    arpc::ANetRPCController cntler;
    cntler.Reset();
    cntler.SetExpireTime(10000);

    int err_code = cntler.GetErrorCode();

    stub_ptr->stub()->recommend(&cntler, &request, &response, NULL);

    if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
        cout << "ERROR" << " rpc failed:" << err_code << endl;
        cout << "error text :" << cntler.ErrorText() << endl;
    }

    string line;
	google::protobuf::TextFormat::PrintToString(response, &line);
    cout << response.ShortDebugString() << endl;
	cout << line << endl;

    return 0;
}

