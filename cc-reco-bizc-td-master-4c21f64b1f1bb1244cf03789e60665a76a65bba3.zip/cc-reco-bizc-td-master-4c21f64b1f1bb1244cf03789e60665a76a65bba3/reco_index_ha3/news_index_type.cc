#include "reco/bizc/reco_index_ha3/news_index_type.h"
#include "reco/base/common/uri_process.h"

namespace reco {
  ItemInfoFull::ItemInfoFull(const reco::presort::PbItemInfoIndex& arg) {
    keyword_norm_ = arg.keyword_norm();
    plsa_topic_norm_ = arg.plsa_topic_norm();
    semantic_tag_norm_ = arg.semantic_tag_norm();
    tag_norm_ = arg.tag_norm();
    topic_norm_ = arg.topic_norm();
    video_black_edge_ratio_ = arg.video_black_edge_ratio();
    wordvec_norm_ = arg.wordvec_norm();
    content_attr_ = arg.content_attr();
    content_length_ = arg.content_length();
    crawl_timestamp_ = arg.crawl_timestamp();
    create_timestamp_ = arg.create_timestamp();
    docmask_ = arg.docmask();
    expire_timestamp_ = arg.expire_timestamp();
    has_video_storage_info_ = arg.has_video_storage_info();
    image_count_ = arg.image_count();
    item_has_reviewed_ = arg.item_has_reviewed();
    item_is_yuanchuang_ = arg.item_is_yuanchuang();
    item_type_ = arg.item_type();
    jingpin_score_ = arg.jingpin_score();
    novel_update_time_ = arg.novel_update_time();
    paragraph_num_ = arg.paragraph_num();
    popularity_ = arg.popularity();
    posterior_item_q_ = arg.posterior_item_q();
    publish_time_ = arg.publish_time();
    term_feature_version_ = arg.term_feature_version();
    title_length_ = arg.title_length();
    ucbr_style_type_ = arg.ucbr_style_type();
    video_count_ = arg.video_count();
    video_length_ = arg.video_length();
    video_quality_level_ = arg.video_quality_level();
    video_storage_info_status_ = arg.video_storage_info_status();
    video_vulgar_level_ = arg.video_vulgar_level();
    app_token_ = arg.app_token();
    image_hash_ = arg.image_hash();
    item_subscripts_ = arg.item_subscripts();
    keyword_feature_list_ = arg.keyword_feature_list();
    keyword_list_ = arg.keyword_list();
    novel_id_ = arg.novel_id();
    orig_source_media_ = arg.orig_source_media();
    orig_source_ = arg.orig_source();
    outer_id_ = arg.outer_id();
    paragraph_hash_ = arg.paragraph_hash();
    plsa_topic_feature_list_ = arg.plsa_topic_feature_list();
    plsa_topic_list_ = arg.plsa_topic_list();
    raw_summary_ = arg.raw_summary();
    region_from_title_ = arg.region_from_title();
    region_restrict_ = arg.region_restrict();
    region_ = arg.region();
    semantic_tag_feature_list_ = arg.semantic_tag_feature_list();
    semantic_tag_list_ = arg.semantic_tag_list();
    sim_feature_ = arg.sim_feature();
    sim_hash_ = arg.sim_hash();
    source_media_ = arg.source_media();
    source_ = arg.source();
    tag_feature_list_ = arg.tag_feature_list();
    tag_list_ = arg.tag_list();
    term_feature_bytes_ = arg.term_feature_bytes();
    term_payload_ = arg.term_payload();
    topic_feature_list_ = arg.topic_feature_list();
    topic_list_ = arg.topic_list();
    ucb_editor_name_ = arg.ucb_editor_name();
    wemedia_person_ = arg.wemedia_person();
    wordvec_feature_list_ = arg.wordvec_feature_list();
    wordvec_list_ = arg.wordvec_list();
    youku_video_id_ = arg.youku_video_id();
    priority_ = arg.priority();
    special_contain_item_list_ = arg.special_contain_item_list();
    special_prevew_item_list_ = arg.special_prevew_item_list();
    video_poster_problem_info_ = arg.video_poster_problem_info();
    category_ = arg.category();
    channel_ = arg.channel();
    item_event_tag_ = arg.item_event_tag();
    item_show_tag_ = arg.item_show_tag();
    gaode_poi_ = arg.gaode_poi();
    item_quality_attr_ = arg.item_quality_attr();
    time_axis_results_ = arg.time_axis_results();
    ucbr_deliver_ = arg.ucbr_deliver();
    category_candidates_ = arg.category_candidates();
    title_ = arg.title();
    anchor_ = arg.anchor();
    query_ = arg.query();
    bid_word_ = arg.bid_word();
    content_ = arg.content();
    item_id_ = arg.item_id();
    orig_media_risk_type_ = arg.orig_media_risk_type();
    manual_news_ = arg.manual_news();
    youku_audit_status_ = arg.youku_audit_status();
    ha3_update_timestamp_ = arg.ha3_update_timestamp();
    item_event_tag_info_ = arg.item_event_tag_info();
    video_play_control_ = arg.video_play_control();
    youku_show_id_ = arg.youku_show_id();
    subject_sub_items_ = arg.subject_sub_items();
    title_lda_topic_list_ = arg.title_lda_topic_list();
    title_lda_topic_feature_list_ = arg.title_lda_topic_feature_list();
    title_lda_topic_norm_ = arg.title_lda_topic_norm();
    index_score_ = arg.index_score();
    meta_info_.CopyFrom(arg.meta_info());
    sim_info_.CopyFrom(arg.sim_info());

    for ( int k = 0; k < arg.sim_info().sim_elems_size(); k++) {
      simi_ids_.insert(arg.sim_info().sim_elems(k).sim_id());
    }

    time_axis_info_.CopyFrom(arg.time_axis_info());

    if(!arg.channel().empty()) {
      channel_ids_.clear();
      std::vector<std::string> flds;
      base::SplitString(arg.channel(), "\t", &flds);
      for (int i = 0; i < (int)flds.size(); ++i) {
        int64 id;
        if (!base::StringToInt64(flds[i], &id)) {
          LOG(ERROR) << "err channel id: " << flds[i];
          continue;
        }
        channel_ids_.push_back(id);
      }
    }

    sort_value_ = arg.sort_value();
    local_breaking_ = arg.local_breaking();
    group_info_ = arg.group_info();
    first_nscreen_filter_ = arg.first_nscreen_filter();
    app_token_bits_ = arg.app_token_bits();

    std::string decode_str;
    if (!reco::common::DecodeUrlComponent(arg.app_token_rule_bits().c_str(), &decode_str)) {
      LOG(ERROR) << "decode app_token_rule_bits fail: item_id=" << arg.item_id();
    }

    app_token_rule_bits_ = decode_str;

    video_colors_ = arg.video_colors();
    video_height_ = arg.video_height();
    video_width_ = arg.video_width();
    video_poster_clarity_ = arg.video_poster_clarity();
    wilson_ctr_ = arg.wilson_ctr();
  }

  ItemInfoFull::~ItemInfoFull() {}
}
