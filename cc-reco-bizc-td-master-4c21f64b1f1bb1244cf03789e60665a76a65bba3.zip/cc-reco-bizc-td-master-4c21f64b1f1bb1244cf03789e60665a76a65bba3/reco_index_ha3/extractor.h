#pragma once

#include <unordered_map>
#include <utility>
#include <string>
#include <vector>

#include "reco/bizc/proto/reco_log.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/bizc/reco_index_ha3/dynamic_dict.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/process/process_util.h"
#include "base/container/dense_hash_map.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"
#include "reco/bizc/proto/model_type.pb.h"

// #include "reco/bizc/reco_index_ha3/wd_features/user_feature.h"
// #include "reco/bizc/reco_index_ha3/wd_features/item_feature.h"
// #include "reco/bizc/reco_index_ha3/wd_features/common.h"
#include "reco/ml/wd_feature/text_feature/user_feature.h"
#include "reco/ml/wd_feature/text_feature/item_feature.h"
#include "reco/ml/wd_feature/text_feature/common.h"

namespace reco {
class NewsIndex;
class SortItem;

namespace reco_index {

class WDExtractor {
 public:
  ~WDExtractor() {}
  static WDExtractor& Instance() {
    static WDExtractor instance_;
    return instance_;
  }

  void Init(reco::NewsIndex* news_index = NULL) {
    news_index_ = news_index;
    LOG(INFO) << "extractor start init";
    act_id_ = 0;
    has_ready_ = false;
    LOG(INFO) << "extractor init suc";
    return;
  }

 public:
  bool HasReady() { return has_ready_; }

  // NOTE:
  //   使用顺序如下：
  //   std::vector<reco::model_server::FeatureInfo> wd_feas;
  //   uint64 user_id = 123;
  //   if (NeedExtractUserStaticFea(user_id)) {
  //     reco::user::UserInfo user_info;   // 需要填入相关字段或者从 userserver 获取
  //     ExtractUserStaticFea(user_info);  // 这个接口会把生成的用户特征加入缓存
  //   }
  //   GetUserStaticFea(user_id, &wd_feas);
  bool NeedExtractUserStaticFea(const uint64 user_id);
  void ExtractUserStaticFea(const reco::user::UserInfo& user_info);
  void GetUserStaticFea(const uint64 user_id,
                        std::vector<reco::model_server::FeatureInfo>* wd_feas);

  // 一些和用户相关的动态特征，每次有可能会变，但也只需要抽取一次，比如： channel_id province city
  void ExtractUserDynamicFea(const reco::ml::WDInfo& wd_info,
                             std::vector<reco::model_server::FeatureInfo>* dynamic_feas);
  // 这个抽取 recent_click 或者 session 这种
  void ExtractUserDynamicFea(const reco::user::UserInfo& user_info,
                             std::vector<reco::model_server::FeatureInfo>* dynamic_feas);

  // NOTE:
  //   这个接口目前只保留对 ctr 和 show 的缓存 (随着 news_index 更新), 静态特征以及转移到 model_server 抽取
  void GetItemFeaByIndex(const uint64 item_id, std::vector<reco::model_server::FeatureInfo>* wd_feas);
  void GetItemFeaByIndex(const reco::ml::WDInfo& wd_info,
                         std::vector<reco::model_server::FeatureInfo>* wd_feas);

 public:
  int32 UserStaticFeaNum() {
    return u_fea_cache_.size();
  }

 private:
  void ExtractItemDynamicFeaByIndex(const uint64 item_id);
  void Switch();
  void SetReady();

 private:
  WDExtractor() {}
  WDExtractor(const WDExtractor&);

 private:
  reco::NewsIndex* news_index_;
  mutable thread::RWMutex u_mutex_;
  // 用户特征加缓存
  std::unordered_map<uint64, std::vector<reco::model_server::FeatureInfo>> u_fea_cache_;

  // 双 buf 缓存 item 特征
  std::unordered_map<uint64, std::vector<reco::model_server::FeatureInfo>> item_dynamic_fea_cache_[2];
  int32 act_id_;
  bool has_ready_;

  friend class reco::NewsIndex;
};
}  // namespace reco_index
}  // namespace reco
