#pragma once

#include <boost/dynamic_bitset.hpp>
#include <string>
#include <vector>
#include <boost/dynamic_bitset.hpp>
#include <memory>

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/reco_index_ha3/filter_rule.h"
#include "boost/shared_ptr.hpp"
#include "reco/bizc/proto/index_presort_type.pb.h"
#include "reco/bizc/reco_index_ha3/news_index_type.h"

namespace reco {
//  typedef reco::presort::PbItemInfoIndex ItemInfoFull; 
  typedef std::shared_ptr<ItemInfoFull> ItemInfoFullPtr; 

struct ItemInfo {
  // 全局唯一 ID
  uint64 item_id;
  // 类型
  reco::ItemType item_type;
  // 索引中的 id
  int32 doc_id;
  // 站点等级
  reco::SiteLevel site_level;
  // 媒体等级
  reco::MediaLevel media_level;
  // 时效性等级
  reco::TimeLevel time_level;
  // 热门得分
  int hot_level;
  // 敏感度
  reco::SensitiveType sensitive_type;
  // 推荐得分 [0, 1e6)
  int reco_score;
  // 生成的时间戳
  int64 create_timestamp;
  // query time
  int64 query_time;
  // 一级分类
  std::string category;
  // 二级分类
  std::string sub_category;
  // 质量分
  int itemq;
  // 爬虫抓取的外站得分
  float spider_score;
  // lr model score
  float lr_score;
  // MF model score
  float fm_score;
  // Fac Machine model score
  float fac_machine_score;
  // wide & deep model score
  float wd_score;
  // session model score
  float session_score;
  // 点击率
  float ctr;
  // 展现量
  int show_num;
  // 点击量
  int click_num;
  // 平均时长
  int duration;
  // 时长分, 用于调权
  float duration_score;
  // new pr
  int new_pr;
  // 预估 new_itemq
  int new_itemq;
  // 策略类型
  reco::StrategyType strategy_type;
  // 策略分支
  reco::RecoStrategyBranch strategy_branch;
  // 策略额外信息
  std::string reco_ext_info;

  RuleChain source_rule_chain;

  // source meida controll
  uint64 source_media_sign;
  uint64 orig_source_media_sign;
  bool is_source_wemedia;

  // source (种子源签名)
  uint64 source_sign;
  double media_quantity_score;

  // orig media risk controll
  int32 orig_media_risk_type;

  reco::IrType ir_type;
  std::string ir_word;
  float ir_score;
  int index_score;

  // app token 的位掩码，为 1 表示在这个 app token 不下发
  // 使用 boost::dynamic_bitset 可以运行时动态扩展位数 默认值 512
  boost::dynamic_bitset<uint8> app_rule_mask;
  float wd_text_score;
  ItemInfoFullPtr info_full_ptr;
  float wilson_ctr;
  int predict_ctr;

  int first_n_hide;

  // 主题更新数
  int update_num;
  // 是否订阅
  bool is_followed;
  /*fea_container keyword_info;
  fea_container tag_info;
  fea_container topic_info;
  fea_container category_info;
*/
  ItemInfo() :
    item_id(0), item_type(reco::kNone), doc_id(0), site_level(kMidQualitySite),
    media_level(reco::kLowMedia), time_level(kMidTimeliness),
    hot_level(0), sensitive_type(reco::kNoSensitive), reco_score(0),
    create_timestamp(0), category(""), sub_category(""), itemq(0), spider_score(0), lr_score(0),
    fm_score(0), fac_machine_score(0), wd_score(0), session_score(0), ctr(0), show_num(0), click_num(0),
    duration(70),
    duration_score(1),
    new_pr(0),
    new_itemq(-1),
    strategy_type(reco::kNoStrategy),
    strategy_branch(reco::kUnknownBranch),
    reco_ext_info(""),
    source_media_sign(0), orig_source_media_sign(0),
    is_source_wemedia(false), source_sign(0), media_quantity_score(0.0), orig_media_risk_type(0),
    ir_type(kDefaultIrType), ir_word(""), ir_score(0), index_score(0),
    wd_text_score(0.0), wilson_ctr(-1.0), predict_ctr(-1), first_n_hide(0),
    update_num(0), is_followed(false) {
    /*,
    keyword_info(new std::vector<std::pair<std::string, float> >),
    tag_info(new std::vector<std::pair<std::string, float> >),
    topic_info(new std::vector<std::pair<std::string, float> >),
    category_info(new std::vector<std::pair<std::string, float> >) {}
    */
      app_rule_mask.resize(256, false);
    }

  // NOTE: 不开以下的构造函数,字段顺序填错了就废了
  //   ItemInfo(uint64 id, int32 type, int doc_id) :
  //     item_id(id), item_type(type), doc_local_id(doc_id),
  //     site_level(0), time_level(0), reco_score(0), hot_score(0) {}

  bool operator > (const ItemInfo& rhs) const {
    if (this->reco_score > rhs.reco_score) {
      return true;
    } else if (this->reco_score < rhs.reco_score) {
      return false;
    }

    if (this->ctr > rhs.ctr) {
      return true;
    } else if (this->ctr < rhs.ctr) {
      return false;
    }

    if (this->time_level > rhs.time_level) {
      return true;
    } else if (this->time_level < rhs.time_level) {
      return false;
    }

    if (this->itemq > rhs.itemq) {
      return true;
    } else if (this->itemq < rhs.itemq) {
      return false;
    }

    if (this->hot_level > rhs.hot_level) {
      return true;
    } else if (this->hot_level < rhs.hot_level) {
      return false;
    }

    if (this->media_level > rhs.media_level) {
      return true;
    } else if (this->media_level < rhs.media_level) {
      return false;
    }

    if (this->site_level > rhs.site_level) {
      return true;
    } else if (this->site_level < rhs.site_level) {
      return false;
    }

    return this->item_id > rhs.item_id;
  }

  bool operator < (const ItemInfo& rhs) const {
    return !(*this > rhs);
  }
};
}  // namespace reco

