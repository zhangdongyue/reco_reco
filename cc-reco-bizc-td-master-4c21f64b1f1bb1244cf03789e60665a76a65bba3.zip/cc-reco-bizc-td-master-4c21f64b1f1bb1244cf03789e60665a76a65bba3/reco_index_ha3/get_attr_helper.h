#pragma once

#define GET_SIMPLE_INDEX_ATTR(attr_name) \
  VLOG(2) << "FUNC:" << __func__;\
  ItemInfoFullPtr p;\
  serving_base::Timer timer;\
  timer.Start();\
  bool RET=true;\
  if (item_map_->FindSilently(item_id, &p)) {\
    *attr_name = p->attr_name();\
  } else {\
    VLOG(2) << "attr not find, item_id=" << item_id << " attr=" << #attr_name;\
    RET = false;\
    COUNTERS_news_index__get_attr_err_count.Increase(1);\
  }\
  COUNTERS_news_index__get_attr_time.Increase(timer.Stop());\
  COUNTERS_news_index__get_attr_count.Increase(1);\
  return RET

#define GET_INT_INDEX_ATTR(attr_name) \
  VLOG(2) << "FUNC:" << __func__;\
  serving_base::Timer timer;\
  timer.Start();\
  ItemInfoFullPtr p;\
  int64 INT_VALUE = 0;\
  bool FIND_FLAG = false;\
  if (item_map_->FindSilently(item_id, &p)) {\
    INT_VALUE = static_cast<int64>(p->attr_name());\
    FIND_FLAG = true;\
  } else {\
    VLOG(2) << "attr not find, item_id=" << item_id << " attr=" << #attr_name;\
    COUNTERS_news_index__get_attr_err_count.Increase(1);\
  }\
  COUNTERS_news_index__get_attr_time.Increase(timer.Stop());\
  COUNTERS_news_index__get_attr_count.Increase(1);

#define GET_FLOAT_INDEX_ATTR(attr_name) \
  VLOG(2) << "FUNC:" << __func__;\
  serving_base::Timer timer;\
  timer.Start();\
  ItemInfoFullPtr p;\
  float FLOAT_VALUE = 0.0;\
  bool FIND_FLAG = false;\
  if (item_map_->FindSilently(item_id, &p)) {\
    FLOAT_VALUE = p->attr_name();\
    FIND_FLAG = true;\
  } else {\
    VLOG(2) << "attr not find, item_id=" << item_id << " attr=" << #attr_name;\
    COUNTERS_news_index__get_attr_err_count.Increase(1);\
  }\
  COUNTERS_news_index__get_attr_time.Increase(timer.Stop());\
  COUNTERS_news_index__get_attr_count.Increase(1);

#define GET_STRING_INDEX_ATTR(attr_name) \
  VLOG(2) << "FUNC:" << __func__;\
  serving_base::Timer timer;\
  timer.Start();\
  ItemInfoFullPtr p;\
  std::string STRING_VALUE;\
  bool FIND_FLAG = false;\
  if (item_map_->FindSilently(item_id, &p)) {\
    STRING_VALUE = p->attr_name();\
    FIND_FLAG = true;\
  } else {\
    VLOG(2) << "attr not find, item_id=" << item_id << " attr=" << #attr_name;\
    COUNTERS_news_index__get_attr_err_count.Increase(1);\
  }\
  COUNTERS_news_index__get_attr_time.Increase(timer.Stop());\
  COUNTERS_news_index__get_attr_count.Increase(1);

