#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "reco/bizc/reco_index_ha3/news_index_ha3.h"
#include "reco/bizc/reco_index_ha3/get_attr_helper.h"
#include "reco/bizc/common/index_util_ha3.h"
#include "reco/bizc/common/channel_define.h"
#include "reco/bizc/common/feature_type.h"
#include "reco/base/common/uri_process.h"
#include "serving_base/utility/timer.h"

DEFINE_int64_counter(news_index, get_docs_request_count, 0, "get_docs_request_count");
DEFINE_int64_counter(news_index, get_docs_error_count, 0, "get_docs_error_count");
DEFINE_int64_counter(news_index, get_docs_hit_cache_count, 0, "get_docs_hit_cache_count");
DEFINE_int64_counter(news_index, get_docs_time, 0, "time, unit: ms");
DEFINE_int64_counter(news_index, get_docs_resnum, 0, "resnum");

DEFINE_int64_counter(news_index, get_attr_count, 0, "");
DEFINE_int64_counter(news_index, get_attr_err_count, 0, "");
DEFINE_int64_counter(news_index, get_attr_time, 0, "");

DEFINE_int64_counter(news_index, update_item_count, 0, "update_item_count");
DEFINE_int64_counter(news_index, update_index_count, 0, "update_index_count");
DEFINE_int64_counter(news_index, update_index_time, 0, "time, unit: ms");
DEFINE_int64_counter(news_index, cache_query_count, 0, "cache_query_count");
DEFINE_int64_counter(news_index, update_list_count, 0, "");
DEFINE_int64_counter(news_index, update_list_len, 0, "");
DEFINE_int64_counter(news_index, only_id_count, 0, "");
DEFINE_int64_counter(news_index, only_id_miss_count, 0, "");
DEFINE_int64_counter(news_index, total_id_count, 0, "");

DEFINE_int64_counter(news_index, get_proxy_succ_count, 0, "");
DEFINE_int64_counter(news_index, get_proxy_time, 0, "");
DEFINE_int64_counter(news_index, get_proxy_fail_count, 0, "");

DEFINE_int32(max_feature, 50, "");
namespace reco {
  const int32 DocMaskInvalid = 1;
  const int32 MAX_ID_NUM = 1000*10000;
  const int32 MAX_LIST_LEN= 50000;
  const int32 MAX_LIST_NUM= 100000;
  const std::string INDEX_NAME = "special_index";
  const std::string WE_MEDIA_ITEMS_KEY = "wemedia_items_dict";
  const std::string ITEM_BREAKING_KEY = "item_breaking_dict";

  const int64 NewsIndex::kTimestampInFuture = base::GetTimestamp()
    + base::Time::kMicrosecondsPerDay * 365 * 1000;

  const char* kSourceFile = "source_info.data";
  DECLARE_string(news_index_data_dir);
  DEFINE_int32(item_fea_cache_seconds, 1800, "item fea / title 缓存时常，模型大量请求item fea 和 title");
  DEFINE_int32(item_ucbsetting_cache_seconds, 60, "item ucb setting cache seconds");
  DEFINE_int32(tag_doc_list_cache_seconds, 600, "tag doc list cache seconds");
  DEFINE_int32(tag_doc_candidate_size, 100000, "tag doc candidate size");
  DEFINE_int32(tag_doc_list_cache_size, 5000, "tag doc list cache size");
  DEFINE_int32(tag_doc_async_thread_num, 2, "tag doc async thread num");
  DEFINE_bool(store_index_query, false, "is store index query");
  DEFINE_bool(index_store_item_id, false, "is store index item id");
  DEFINE_int32(item_valid_seconds, 120, "item valid time");
  DEFINE_int32(cutoff_list_len, 2000, "cut off list len");

NewsIndex::NewsIndex(const reco::IndexOptions& opt):
  need_async_update_(opt.need_async_update), async_update_stop_ (false), update_thread_pool_(opt.update_thread_num),
  cache_expire_seconds_(opt.cache_expire_seconds),
  result_num_(opt.result_num), index_cut_off_num_(FLAGS_cutoff_list_len), enable_index_cache_(opt.enable_index_cache),
  update_cache_query_(opt.update_cache_query),
  proxy_long_timeout_ms_(opt.proxy_long_timeout_ms), proxy_short_timeout_ms_(opt.proxy_short_timeout_ms) {
    reco::reco_index::WDExtractor::Instance().Init();
    reco::ml::WDUserFeature::Instance().Init();
    reco::ml::WDItemFeature::Instance().Init(this, NULL);
    stream_filter_ = new reco::filter::StreamFilterSignAsyncCalc(this);

    item_valid_time_ = FLAGS_item_valid_seconds*1000000u;
    int list_cache_block_num = opt.cache_block_num / 100;

    list_access_time_ = new reco::ExpiryMap<std::string, int64>(cache_expire_seconds_, list_cache_block_num, 1);
    CHECK_NOTNULL(list_access_time_);

    item_list_cache_w_ = new reco::ExpiryMap<std::string, ItemInfoFullPtrListPtr>(cache_expire_seconds_, list_cache_block_num, 1);
    CHECK_NOTNULL(item_list_cache_w_);

    item_info_list_cache_w_ = new reco::ExpiryMap<std::string, ItemInfoListPtr>(cache_expire_seconds_, list_cache_block_num, 1);
    CHECK_NOTNULL(item_info_list_cache_w_);

    item_map_w_ = new reco::ExpiryMap<uint64, ItemInfoFullPtr>(3*cache_expire_seconds_, opt.cache_block_num, opt.expire_thread_num);
    CHECK_NOTNULL(item_map_w_);

    item_list_cache_ = new reco::reco_index::WrappedMap<std::string, ItemInfoFullPtrListPtr>();
    CHECK_NOTNULL(item_list_cache_);

    item_info_list_cache_ = new reco::reco_index::WrappedMap<std::string, ItemInfoListPtr>();
    CHECK_NOTNULL(item_info_list_cache_);

    item_map_ = new reco::reco_index::WrappedMap<uint64, ItemInfoFullPtr>();
    CHECK_NOTNULL(item_map_);

    category_cache_ = new reco::ExpiryMap<int32, CategoryListPtr >(cache_expire_seconds_, 1, 1);
    CHECK_NOTNULL(category_cache_);
    channel_cache_ = new reco::ExpiryMap<int32, ChannelListPtr >(cache_expire_seconds_, 1, 1);
    CHECK_NOTNULL(channel_cache_);
    term_cache_ = new reco::ExpiryMap<int32, TermListPtr >(cache_expire_seconds_, 1, 1);
    CHECK_NOTNULL(term_cache_);

    simi_ids_cache_ = new reco::ExpiryMap<uint64, SimiIdsSetPtr >(3*cache_expire_seconds_, opt.cache_block_num, opt.expire_thread_num);
    CHECK_NOTNULL(simi_ids_cache_);

    latest_news_cache_ = new reco::ExpiryMap<std::string, LatestNewsPairPtr>(cache_expire_seconds_, 1, 1);
    CHECK_NOTNULL(latest_news_cache_);

    wemedia_items_cache_ = new reco::ExpiryMap<std::string, WeMediaItemsDictPtr>(cache_expire_seconds_, 1, 1);
    CHECK_NOTNULL(wemedia_items_cache_);

    item_breaking_cache_ = new reco::ExpiryMap<std::string, ItemBreakingDictPtr>(cache_expire_seconds_, 1, 1);
    CHECK_NOTNULL(item_breaking_cache_);

    presort_client_ = new PresortClient(opt.presort_opt);
    CHECK_NOTNULL(presort_client_);

    item_fea_expiry_map_ =
      new reco::ExpiryMap<std::string, reco::FeatureVector>(cache_expire_seconds_, opt.cache_block_num, opt.expire_thread_num);
    item_unigram_expiry_map_ =
      new serving_base::ExpiryMap<std::string, std::vector<std::string> >(FLAGS_item_fea_cache_seconds);
    item_ucbsetting_expiry_map_ =
      new reco::ExpiryMap<uint64, UcBrowserDeliverSettingPtr>(3*cache_expire_seconds_, opt.cache_block_num, opt.expire_thread_num);
    item_quality_expiry_map_ =
      new serving_base::ExpiryMap<uint64, ItemQualityAttr>(FLAGS_item_fea_cache_seconds);
    item_title_core_tags_expiry_map_ =
      new serving_base::ExpiryMap<uint64, std::vector<std::string> >(FLAGS_item_fea_cache_seconds);

    empty_list_ptr_full_ = ItemInfoFullPtrListPtr(new ItemInfoFullPtrList());
    empty_list_ptr_ = ItemInfoListPtr(new ItemInfoList());
    empty_cat_ptr_ = CategoryListPtr(new CategoryList());
    empty_simi_ids_set_ptr_ = SimiIdsSetPtr(new SimiIdsSet());
    empty_wemedia_dict_ptr_ = WeMediaItemsDictPtr(new WeMediaItemsDict());
    empty_item_breaking_dict_ptr_ = ItemBreakingDictPtr(new ItemBreakingDict());

    multi_category_cache_ = new MultiCategoryCache();

    stream_filter_dict_ = DM_GET_DICT(reco::filter::StreamFilterDict,
      reco::filter::DynamicDictContainer::kStreamFilterFile);

    if (need_async_update_) {
      async_update_stop_ = false;
      cache_query_filepath_ = opt.cache_query_filepath;
      cache_item_id_filepath_ = opt.cache_item_id_filepath;
      update_thread_num_ = opt.update_thread_num;
      update_interval_seconds_ = opt.update_interval_seconds;
      finish_part_ = 0;
      update_count_ = 0;
      copy_count_ = 0;

      LoadQuery(cache_query_filepath_, &cache_query_last_);
      std::unordered_set<uint64> cache_item_id_last;
      LoadItemId(cache_item_id_filepath_, &cache_item_id_last);
      LOG(INFO) << "UpdateWork item id of last run...";
      if(!GetItemInfoFullMulti(&cache_item_id_last, 2000)) {
        LOG(ERROR) << "get item info of last run error";
      }
      LOG(INFO) << "UpdateWork item id of last run done, size=" << cache_item_id_last.size();

      // 例行更新
      get_iteminfo_thread_.Start(NewCallback(this, &NewsIndex::GetItemInfoThread));

      update_main_thread_.Start(NewCallback(this, &NewsIndex::UpdateCacheThread));
      while (update_count_==0) {
        VLOG(1) << "UpdateWork first time not finish, wait...";
        base::SleepForSeconds(1);
      }

      LOG(INFO) << "UpdateWork first time done";

      //必须等待 copy 一次， 索引才可以用
      CopyIndex();
      copy_thread_.Start(NewCallback(this, &NewsIndex::CopyIndexThread));
    }
}

void NewsIndex::LoadItemId(const std::string& filepath, std::unordered_set<uint64>* ids) {
  if (filepath == "") {
    LOG(ERROR) << "load item id error, filename empty";
    return;
  }

  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(filepath, &lines)) {
    LOG(ERROR) << "load item id error, filename=" << filepath;
    return;
  }

  for (int i = 0; i < (int)lines.size(); ++i) {
    if (lines[i] == ""){
      continue;
    }

    uint64 item_id = 0u;
    if (base::StringToUint64(lines[i], &item_id)) {
      ids->insert(item_id);
    } else {
      LOG(ERROR) << "parse item_id error, line=" << lines[i];
      continue;
    }
  }

  LOG(INFO) << "succ to load item id file, total record: " << ids->size();
}

void NewsIndex::StoreQuery(const std::string& oldfilepath, const std::vector<reco::index::RecoQuery>& qrs) {
  std::string filepath = oldfilepath + std::string(".new");

  if (filepath == "") {
    LOG(ERROR) << "save query error, filename empty";
    return;
  }

  std::string s;
  for (auto i = qrs.begin(); i != qrs.end(); i++){
    s += i->toString() + std::string("\n");
  }

  if (!base::file_util::WriteFile(filepath, s.c_str(), s.size())) {
    LOG(ERROR) << "save query error, filename=" << filepath;
    return;
  } else {
    LOG(INFO) << "save query succ, filename=" << filepath << " num=" << qrs.size();
  }

  if (!base::file_util::Move(filepath, oldfilepath)) {
    LOG(INFO) << "move item id file fail, from " << filepath << " to " << oldfilepath;
  }
}

void NewsIndex::LoadQuery(const std::string& filepath, std::unordered_map<std::string, reco::index::RecoQuery>* query_map) {
  if (filepath == "") {
    LOG(ERROR) << "load index query error, filename empty";
    return;
  }

  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(filepath, &lines)) {
    LOG(ERROR) << "load index query error, filename=" << filepath;
    return;
  }

  for (int i = 0; i < (int)lines.size(); ++i) {
    if (lines[i] == ""){
      LOG(INFO) << "empty line, i=" << i;
      continue;
    }

    reco::index::RecoQuery q;
    q.result_num_ = result_num_; 
    q.ori_result_num_ = result_num_; 

    if(!q.ParseFromString(lines[i])) {
      LOG(ERROR) << "index query error, line=" << lines[i];
      continue;
    } else {
      VLOG(1) << "load query i=" << i << ":" << q.toString();
    }

    (*query_map)[q.toString()] = q;
  }

  LOG(INFO) << "succ to load query file, total record: " << query_map->size();
}

void NewsIndex::GetUpdateQuery(std::vector<reco::index::RecoQuery>* queries) {
  std::vector<reco::index::RecoQuery>& qrs = *queries;
  std::unordered_map<std::string, reco::index::RecoQuery> query_update;
  CategoryListPtr cats = empty_cat_ptr_;
  if (!category_cache_->FindSilently(0, &cats)) {
    LOG(ERROR) << "get all level0 cat from cache fail";
  } else {
    for ( auto i = cats->begin(); i != cats->end(); i++) {
      reco::index::RecoQuery q;
      q.result_num_ = result_num_; 
      q.ori_result_num_ = result_num_; 
      q.reco_type_ = reco::presort::kCategoryReco;
      q.wc_ = std::shared_ptr<reco::common::WrappedCategory>(new reco::common::WrappedCategory(*i));
      q.timely_ = false;
      q.from_ = std::string(__func__);
      query_update[q.toString()] = q;
      VLOG(1) << "refresh query cat0:" << q.toString();
    }
  }

  if (!category_cache_->FindSilently(1, &cats)) {
    LOG(ERROR) << "get all level1 cat from cache fail";
  } else {
    for ( auto i = cats->begin(); i != cats->end(); i++) {
      reco::index::RecoQuery q;
      q.result_num_ = result_num_; 
      q.ori_result_num_ = result_num_; 
      q.reco_type_ = reco::presort::kCategoryReco;
      q.wc_ = std::shared_ptr<reco::common::WrappedCategory>(new reco::common::WrappedCategory(*i));
      q.timely_ = false;
      q.from_ = std::string(__func__);
      query_update[q.toString()] = q;
      VLOG(1) << "refresh query cat1:" << q.toString();
    }
  }

  ChannelListPtr chan(new ChannelList());
  if (!channel_cache_->FindSilently(0, &chan)) {
    LOG(ERROR) << "get all channel from cache fail";
  } else {
    for ( auto i = chan->begin(); i != chan->end(); i++) {
      reco::index::RecoQuery q;
      q.result_num_ = result_num_; 
      q.ori_result_num_ = result_num_; 
      q.reco_type_ = reco::presort::kChannelReco;
      q.channel_id_ = *i;
      q.region_id_ = -1;
      q.from_ = std::string(__func__);
      query_update[q.toString()] = q;
      VLOG(1) << "refresh query channel:" << q.toString();
    }
  }

  {
    // ucb list 
    reco::index::RecoQuery q;
    q.result_num_ = result_num_; 
    q.ori_result_num_ = result_num_; 
    q.reco_type_ = reco::presort::kUCBReco;
    q.from_ = std::string(__func__);
    query_update[q.toString()] = q;
    VLOG(1) << "refresh query ucb:" << q.toString();
  }

  {
    // Jingpin list 
    reco::index::RecoQuery q;
    q.result_num_ = result_num_; 
    q.ori_result_num_ = result_num_; 
    q.reco_type_ = reco::presort::kChannelReco;
    q.channel_id_ = reco::common::kJingpinChannelId;
    q.from_ = std::string(__func__);
    query_update[q.toString()] = q;
    VLOG(1) << "refresh query jingpin:" << q.toString();
  }

  // region id
  auto region_dict = DM_GET_DICT(reco::dm::RegionDict, reco::IndexDynamicDictContainer::kRegionFile_);
  for ( auto i = region_dict->begin(); i != region_dict->end(); i++) {
    reco::index::RecoQuery q;
    q.result_num_ = result_num_; 
    q.ori_result_num_ = result_num_; 
    q.reco_type_ = reco::presort::kChannelReco;
    q.channel_id_ = reco::common::kLocalChannelId;
    q.region_id_ = i->second;
    q.from_ = std::string(__func__);
    query_update[q.toString()] = q;
    VLOG(1) << "refresh query region id:" << q.toString();
  }

  {
    thread::AutoLock auto_lock(&mutex_of_cache_query_);
    for ( auto it = cache_query_.begin(); it != cache_query_.end();) {
      int64 access_time = 0;
      if (update_cache_query_) {
        if (update_count_ > 5) {
          if (!list_access_time_->FindSilently(it->first, &access_time)) {
            it = cache_query_.erase(it);
            continue;
          }
        }
      }

      query_update[it->first] = it->second;
      it++;
    }
  }

  if (update_count_ == 0) {
    for ( auto it = cache_query_last_.begin(); it != cache_query_last_.end();) {
      query_update[it->first] = it->second;
      it++;
    }
  }

  qrs.clear();
  for ( auto it = query_update.begin(); it != query_update.end(); it++) {
    if (it->second.ori_result_num_ > it->second.result_num_){
      it->second.result_num_ = it->second.ori_result_num_;
    } else {
      it->second.ori_result_num_ = it->second.result_num_;
    }

    qrs.push_back(it->second);
  }
}

void NewsIndex::UpdateCacheThread() {
  bool started = false;
  std::vector<reco::index::RecoQuery> qrs;
  while (!async_update_stop_) {
    if(!started) {
      LOG(INFO) << "UpdateWork start batch...";
      update_timer_.Start();

      if(!GetSourceMetaFromProxy()) {
        LOG(ERROR) << "get Source Meta fail";
      }

      if(!GetItemBreakingFromProxy()) {
        LOG(ERROR) << "get ItemBreaking Dict fail";
      }

      if(!GetWeMediaItemsFromProxy()) {
        LOG(ERROR) << "get WeMedia Items Dict fail";
      }

      if(!GetChannelAndCategoryFromProxy()) {
        LOG(ERROR) << "get all cat and channels fail";
      }

      GetUpdateQuery(&qrs);

      stream_filter_dict_ = DM_GET_DICT(reco::filter::StreamFilterDict,
        reco::filter::DynamicDictContainer::kStreamFilterFile);

      finish_part_ = 0;
      for (int i = 0; i < update_thread_num_; i++) {
        update_thread_pool_.AddTask(NewCallback(this, &NewsIndex::UpdateWork, &qrs, i));
      }

      started = true;
    } else {
      if (finish_part_ < update_thread_num_) {
          VLOG(1) << "UpdateWork running..finish_part_=" << finish_part_
            << " total_part=" << update_thread_num_;
      } else {
        reco::reco_index::WDExtractor::Instance().SetReady();

        if (FLAGS_store_index_query) {
          StoreQuery(cache_query_filepath_, qrs);
        }

        COUNTERS_news_index__update_index_count.Increase(1);
        COUNTERS_news_index__cache_query_count.Reset(static_cast<int64>(item_map_w_->Size()));
        COUNTERS_news_index__update_list_count.Increase(qrs.size());
        COUNTERS_news_index__total_id_count.Reset(item_map_w_->Size());
        const int64 cost_us = update_timer_.Stop();
        COUNTERS_news_index__update_index_time.Increase(cost_us / 1000);
        LOG(INFO) << "UpdateWork batch finish.  full_list_num=" << item_list_cache_w_->Size()
          << " iteminfo_list_num=" <<  item_info_list_cache_w_->Size() 
          << " query_num=" << cache_query_.size()
          << " refresh_list_num=" << qrs.size()
          << " item_num=" << item_map_w_->Size()
          << " time_ms=" << (cost_us/1000)
          << " update_count=" << update_count_; 

        update_count_ ++ ;
        started = false;
        finish_part_ = 0;
        base::SleepForSeconds(update_interval_seconds_);
      }
    }

    base::SleepForSeconds(3);
  }

  LOG(INFO) << "UpdateWork main thread exit.";
  update_thread_pool_.JoinAll();
}

void NewsIndex::UpdateWork(std::vector<reco::index::RecoQuery>* qrs, int hash_id) {
  VLOG(1) << "UpdateWork start, hash_id=" << hash_id  << ", qrs size=" << qrs->size(); 
  SearchOpts opt;
  opt.timeout_ms = proxy_long_timeout_ms_; 
  opt.find_from_cache = false;
  opt.allow_cut_off = false;
  opt.allow_item_loss = false;
  opt.need_build_list = true;
  opt.need_store_list_cache = true;
  opt.need_refresh = false;

  int i=0;
  for (auto it = qrs->begin(); it != qrs->end(); it++) {
    if (async_update_stop_) {
      LOG(INFO) << "updateWork stop, hash_id=" << hash_id;
      return;
    }

    std::string key = it->toString(); 
    if ( i%update_thread_num_ == hash_id) {
      ItemInfoFullPtrListPtr item_list = empty_list_ptr_full_;
      ItemInfoListPtr item_info_list = empty_list_ptr_;
      if (!GetResultFromProxy(*it, opt, &item_list, &item_info_list)) {
        LOG(ERROR) << "update part cache error, hash_id=" << hash_id 
          << " i=" << i
          << " query=" << key;
      } else {
//        VLOG(1) << "update part cache succ, hash_id=" << hash_id 
//          << " i=" << i;
//          << " query=" << key;
      }
      if (item_list){
        COUNTERS_news_index__update_list_len.Increase(item_list->size());
      }
    }

    i++;
  }

  finish_part_++;

  VLOG(1) << "UpdateWork finish, hash_id=" << hash_id << " finish_part=" << finish_part_;
}

void NewsIndex::GetItemInfoThread() {
  LOG(INFO) << "start";
  size_t batch_count = 2000;
  std::unordered_set<uint64> ids_to_get;
  base::PseudoRandom random(base::GetTimestamp());

  while (!async_update_stop_) {
    uint64 item_id = 0;
    int ret = missing_item_queue_.TryTake(&item_id);
    if (-1 == ret) {        // 队列为空，且关闭
      GetItemInfoFull(&ids_to_get, proxy_long_timeout_ms_);
      VLOG(1) << "queue close, async get item num:" << ids_to_get.size();
      ids_to_get.clear();
      break;
    } else if (0 == ret) {  // 队列为空
      if(!ids_to_get.empty()) {
        GetItemInfoFull(&ids_to_get, proxy_long_timeout_ms_);
        VLOG(1) << "queue empty, async get item num:" << ids_to_get.size();
        ids_to_get.clear();
      }

      base::SleepForSeconds(1);
      continue;
    }

    if (item_id != 0) {
      int64 update_time = 0;
      int64 rand_time = random.GetUint64LT(item_valid_time_);
      ItemInfoFullPtr p;
      bool tmpret = item_map_w_->FindSilently(item_id, &p, &update_time);
      if (!tmpret || (base::GetTimestamp() - update_time - rand_time > (int64)item_valid_time_)) {
        ids_to_get.insert(item_id);
      }
    }

    if (ids_to_get.size() < batch_count) {
      continue;
    }

    GetItemInfoFull(&ids_to_get, proxy_long_timeout_ms_);
    VLOG(1) << "batch full, async get item num:" << ids_to_get.size();
    ids_to_get.clear();
  }
  LOG(INFO) << "end";
}

void NewsIndex::StoreItemId(const std::string& oldfilepath, const std::unordered_map<uint64, ItemInfoFullPtr>* item_map) {
  std::string filepath = oldfilepath + std::string(".new");
  std::ofstream   ofresult(filepath);

  if (ofresult.is_open()) {
    LOG(INFO) << "open file succ: " << filepath;
  } else {
    LOG(ERROR) << "open file fail: " << filepath;
    return;
  }

  for (auto i = item_map->begin(); i != item_map->end(); i++){
    ofresult << i->first << std::endl;
  }

  ofresult.flush();
  ofresult.close();

  LOG(INFO) << "save item id succ, filename=" << filepath << " num=" << item_map->size();
  if (!base::file_util::Move(filepath, oldfilepath)) {
    LOG(INFO) << "move item id file fail, from " << filepath << " to " << oldfilepath;
  }
}

void NewsIndex::CopyIndex() {
  LOG(INFO) << "copy start";

  auto list_dict = item_list_dynamic_.GetInactiveDict();
  auto iteminfo_list = item_info_list_dynamic_.GetInactiveDict();
  auto item_dict = item_map_dynamic_.GetInactiveDict();

  list_dict->clear();
  iteminfo_list->clear();
  item_dict->clear();

  item_list_cache_w_->DumpData(list_dict);
  item_info_list_cache_w_->DumpData(iteminfo_list);
  item_map_w_->DumpData(item_dict);

  item_list_dynamic_.SwitchDict();
  item_info_list_dynamic_.SwitchDict();
  item_map_dynamic_.SwitchDict();

  item_list_cache_->SetDataPtr(item_list_dynamic_.GetDict());
  item_info_list_cache_->SetDataPtr(item_info_list_dynamic_.GetDict());
  item_map_->SetDataPtr(item_map_dynamic_.GetDict());
  copy_count_ ++;

  if (FLAGS_index_store_item_id && copy_count_ % 5 == 0) {
    StoreItemId(cache_item_id_filepath_, item_map_dynamic_.GetDict());
  }

  LOG(INFO) << "copy end, copy_count = " << copy_count_ << 
    " list size=" << item_list_cache_->Size() <<
    " iteminfo list size=" << item_info_list_cache_->Size() <<
    " item map size=" << item_map_->Size();
}

void NewsIndex::CopyIndexThread() {
  while (!async_update_stop_) {
    base::SleepForSeconds(60);
    CopyIndex();
  }
  LOG(INFO) << "exit";
}

void NewsIndex::StopUpdateCache() {
  if (need_async_update_ && !async_update_stop_) {
    LOG(INFO) << "Update thread stopping...";

    async_update_stop_ = true;
    update_main_thread_.Join();

    missing_item_queue_.Close();
    get_iteminfo_thread_.Join();
    copy_thread_.Join();
    LOG(INFO) << "Update thread stoped";
  }
}

NewsIndex::~NewsIndex() {
  StopUpdateCache();

  if (stream_filter_ != NULL) {
    delete stream_filter_;
    stream_filter_ = NULL;
  }

  if (item_list_cache_ != NULL) {
    LOG(INFO) << "delete item_list_cache_ ..";
    delete item_list_cache_;
    item_list_cache_ = NULL;
  }

  if (item_list_cache_w_ != NULL) {
    LOG(INFO) << "delete item_list_cache_w_ ..";
    delete item_list_cache_w_;
    item_list_cache_w_ = NULL;
  }

  if (item_info_list_cache_ != NULL) {
    LOG(INFO) << "delete item_info_list_cache_ ..";
    delete item_info_list_cache_;
    item_info_list_cache_ = NULL;
  }

  if (item_info_list_cache_w_ != NULL) {
    LOG(INFO) << "delete item_info_list_cache_w_ ..";
    delete item_info_list_cache_w_;
    item_info_list_cache_w_ = NULL;
  }

  if (list_access_time_ != NULL) {
    LOG(INFO) << "delete list_access_time_..";
    delete list_access_time_;
    list_access_time_ = NULL;
  }

  if (item_map_ != NULL) {
    LOG(INFO) << "delete item_map_ ..";
    delete item_map_;
    item_map_ = NULL;
  }

  if (item_map_w_ != NULL) {
    LOG(INFO) << "delete item_map_w_ ..";
    delete item_map_w_;
    item_map_w_ = NULL;
  }


  if (category_cache_ != NULL) {
    LOG(INFO) << "delete category_cache_ ..";
    delete category_cache_;
    category_cache_ = NULL;
  }
  if (channel_cache_ != NULL) {
    LOG(INFO) << "delete channel_cache..";
    delete channel_cache_;
    channel_cache_ = NULL;
  }
  if (term_cache_ != NULL) {
    LOG(INFO) << "delete term_cache_ ..";
    delete term_cache_;
    term_cache_ = NULL;
  }

  if (simi_ids_cache_ != NULL) {
    LOG(INFO) << "delete simi_ids_cache_ ..";
    delete simi_ids_cache_;
    simi_ids_cache_ = NULL;
  }
  if (latest_news_cache_ != NULL) {
    LOG(INFO) << "delete latest_news_cache_ ..";
    delete latest_news_cache_;
    latest_news_cache_ = NULL;
  }
  if (wemedia_items_cache_ != NULL) {
    LOG(INFO) << "delete wemedia_items_cache_ ..";
    delete wemedia_items_cache_;
    wemedia_items_cache_ = NULL;
  }
  if (item_breaking_cache_ != NULL) {
    LOG(INFO) << "delete item_breaking_cache_ ..";
    delete item_breaking_cache_;
    item_breaking_cache_ = NULL;
  }
  if (presort_client_ != NULL) {
    LOG(INFO) << "delete presort_client_ ..";
    delete presort_client_;
    presort_client_ = NULL;
  }
  if (item_fea_expiry_map_ != NULL) {
    LOG(INFO) << "delete item_fea_expiry_map_ ..";
    delete item_fea_expiry_map_;
    item_fea_expiry_map_ = NULL;
  }
  if (item_unigram_expiry_map_ != NULL) {
    LOG(INFO) << "delete item_unigram_expiry_map_ ..";
    delete item_unigram_expiry_map_;
    item_unigram_expiry_map_ = NULL;
  }
  if (item_ucbsetting_expiry_map_ != NULL) {
    LOG(INFO) << "delete item_ucbsetting_expiry_map_ ..";
    delete item_ucbsetting_expiry_map_;
    item_ucbsetting_expiry_map_ = NULL;
  }
  if (item_quality_expiry_map_ != NULL) {
    LOG(INFO) << "delete item_quality_expiry_map_ ..";
    delete item_quality_expiry_map_;
    item_quality_expiry_map_ = NULL;
  }
  if (item_title_core_tags_expiry_map_ != NULL) {
    LOG(INFO) << "delete item_title_core_tags_expiry_map_ ..";
    delete item_title_core_tags_expiry_map_;
    item_title_core_tags_expiry_map_ = NULL;
  }
  if (multi_category_cache_ != NULL) {
    LOG(INFO) << "delete multi_category_cache_ ..";
    delete multi_category_cache_;
    multi_category_cache_ = NULL;
  }
}

bool NewsIndex::GenerateItemList(const std::string& term, reco::presort::GetDefaultRecoResponse* resp,
  bool need_store, ItemInfoFullPtrListPtr* item_full_list, ItemInfoListPtr* item_simple_list, bool is_async_update) {
  // 先加正排信息，后加倒排信息
  ItemInfoFullPtrListPtr p1(new ItemInfoFullPtrList());
  if(!p1) {
    LOG(ERROR) << "new memory for ItemInfoFullPtrList fail" ;
    return false;
  }

  ItemInfoListPtr p3(new ItemInfoList());
  if(!p3) {
    LOG(ERROR) << "new memory for ItemInfoList fail" ;
    return false;
  }

  int miss_cnt = 0;
  for (int ind = 0; ind < resp->item_info_size(); ind++) {
    const ItemInfoFull& tmp_info = resp->item_info(ind);
    auto item_id = tmp_info.item_id();
    // 正排不需要更新, 只更新两个链上对应的指针或者数据
    p1->push_back(ItemInfoFullPtr());
    bool find_flag = false;
    if (is_async_update) {
      find_flag = item_map_w_->FindSilently(item_id, &(p1->back()));
    }else {
      find_flag = item_map_->FindSilently(item_id, &(p1->back()));
    }

    if (!find_flag){
      miss_cnt ++;
      p1->pop_back();
      continue;
    }

    ItemInfo item_info;
    if(GetItemInfoFromFull(p1->back(), &item_info)) {
      p3.get()->push_back(item_info);
    }
  }

  if(resp->item_info_size() > 0) {
    VLOG(1) << "item miss, total=" << resp->item_info_size() << " miss=" << miss_cnt 
      << " rate=" << (float)miss_cnt/resp->item_info_size()  << " term=" << term ;
  }

  if (need_store) {
    item_list_cache_w_->Add(term, p1);
    item_info_list_cache_w_->Add(term, p3);
  }

  if (item_full_list != NULL) {
    *item_full_list = p1;
  }

  if (item_simple_list != NULL) {
    *item_simple_list = p3;
  }

  return true;
}

bool NewsIndex::SetItemAttr(const ItemInfoFullPtr& p, ItemFea* item_feature) {
  // keyword
  reco::FeatureVector keyword;
  GetFeatureVectorByItemInfoFull(p, reco::common::kKeyword, &keyword);
  for (int i = 0; i < keyword.feature_size() && i < FLAGS_max_feature; ++i) {
    auto& item_fea = keyword.feature(i);
    if (item_fea.literal().empty()) continue;
    item_feature->keyword_info.push_back(std::pair<std::string, float>(item_fea.literal(), item_fea.weight()));
  }
  // tag
  reco::FeatureVector tag;
  GetFeatureVectorByItemInfoFull(p, reco::common::kTag, &tag);
  for (int i = 0; i < tag.feature_size() && i < FLAGS_max_feature; ++i) {
    auto& item_fea = tag.feature(i);
    if (item_fea.literal().empty()) continue;
    item_feature->tag_info.push_back(std::pair<std::string, float>(item_fea.literal(), item_fea.weight()));
  }

  // topic
  reco::FeatureVector topic;
  GetFeatureVectorByItemInfoFull(p, reco::common::kTopic, &topic);
  for (int i = 0; i < topic.feature_size() && i < FLAGS_max_feature; ++i) {
    auto& item_fea = topic.feature(i);
    if (item_fea.literal().empty()) continue;
    item_feature->topic_info.push_back(std::pair<std::string, float>(item_fea.literal(), item_fea.weight()));
  }

  // category
  std::vector<reco::Category> categories;
  GetCategoriesByItemInfoFull(p, &categories);
  int count =  std::min(categories.size(), (size_t)FLAGS_max_feature);
  float weight = 1.0 / count;
  for (size_t i = 0; i < categories.size() && i < (size_t)FLAGS_max_feature; ++i) {
    if (categories[i].category().empty()) continue;
    item_feature->category_info.push_back(std::pair<std::string, float>(categories[i].category(), weight));
  }

  return true;
}

bool NewsIndex::ModifyItemInfoFull(ItemInfoFullPtr* full) {
  if(NULL == full) {
    return false;
  }
  ItemInfoFullPtr& p = *full;


  ParseCategories(p->item_id(), p->category(), p->mutable_categories());
  reco::ml::WDInfo wd_info;
  wd_info.item_id = p->item_id();
  wd_info.show_num = p->meta_info().show_count();
  wd_info.click_num = p->meta_info().click_count();
  reco::ml::WDItemFeature::Instance().ExtractItemDynamicFeaByExternal(wd_info, p->mutable_item_wd_feas());

  stream_filter_->ProcessSingleDoc(p, stream_filter_dict_.get(), p->mutable_filter_strategy());

  if(!SetItemAttr(p, p->mutable_item_fea())) {
    return false;
  }
  return true;
}

bool NewsIndex::FillItemInfoFullCache(reco::presort::GetDefaultRecoResponse* resp) {
  COUNTERS_news_index__update_item_count.Increase(resp->item_info_size());
  for (int ind = 0; ind < resp->item_info_size(); ind++) {
    const reco::presort::PbItemInfoIndex& tmp_info = resp->item_info(ind);
    auto item_id = tmp_info.item_id();
    ItemInfoFullPtr modify_p(new ItemInfoFull(tmp_info));
    // 修改或新增正排字段的操作在这里完成
    if (!ModifyItemInfoFull(&modify_p)) {
      LOG(WARNING) << "modify iteminfofull fail: item_id=" << item_id;
    } else {
      VLOG(1) << "item_id=" << item_id << " keyword=" << modify_p->item_fea().keyword_info.size()
        << " tag=" << modify_p->item_fea().tag_info.size()
        << " topic=" << modify_p->item_fea().topic_info.size()
        << " categories=" << modify_p->item_fea().category_info.size();
    }

    //  加两遍的原因是要对正排做修改，但修改调用的n多个的函数需要访问正排expire map
    item_map_w_->Add(item_id, modify_p);

    if (!tmp_info.ucbr_deliver().empty()) {
      std::string decode_str;
      if (!reco::common::DecodeUrlComponent(tmp_info.ucbr_deliver().c_str(), &decode_str)) {
        LOG(ERROR) << "decode fail: item_id=" << item_id;
      } else {
        UcBrowserDeliverSettingPtr ucb_setting(new UcBrowserDeliverSetting());
        if (!ucb_setting->ParseFromString(decode_str)) {
          LOG(ERROR) << "parse ucbr_deliver fail: item_id=" << item_id;
        } else {
          item_ucbsetting_expiry_map_->Add(item_id, ucb_setting);
        }
      }
    }

    VLOG(1) << "add cache item_id=" << item_id;
  }

  return true;
}

void NewsIndex::GetMetaInfoFromFull(const ItemInfoFullPtr& full, ItemInfo* item) const {
  item->info_full_ptr = full;
  item->item_id = full->item_id();
  item->item_type = static_cast<reco::ItemType>(full->item_type());

  item->site_level = static_cast<reco::SiteLevel>(full->meta_info().site_level());
  item->time_level = static_cast<reco::TimeLevel>(full->meta_info().time_level());
  item->hot_level = full->meta_info().hot_level();
  item->sensitive_type = static_cast<reco::SensitiveType>(full->meta_info().sensitive_type());
  item->itemq = full->meta_info().item_quality();
  item->spider_score = full->meta_info().spider_score();
  item->show_num = full->meta_info().show_count();
  item->click_num = full->meta_info().click_count();
  item->duration = full->meta_info().duration();
  item->new_itemq = full->meta_info().new_itemq();
  item->new_pr = full->meta_info().new_pr();
  item->ctr = full->meta_info().ctr();
  item->duration_score = full->meta_info().duration_score();
  item->predict_ctr = full->meta_info().predict_ctr();
}

bool NewsIndex::GetItemInfoFromFull(const ItemInfoFullPtr& full, ItemInfo* item, bool only_basic) const {
  item->info_full_ptr = full;
  uint64 item_id = full->item_id();

  //basic
  item->item_id = full->item_id();
  item->item_type = static_cast<reco::ItemType>(full->item_type());

  if (only_basic) {
    return true;
  }

  GetMetaInfoFromFull(full, item);

  //other
  std::vector<std::string> categories;
  if (!(full->category().empty())) {
    base::SplitString(full->category(), "\t", &categories);
  }

  if (categories.empty()) {
    auto itemid_category_map = DM_GET_DICT(reco::dm::ItemCategoryDict, reco::IndexDynamicDictContainer::kItemCategoryFile_);
    auto i = itemid_category_map->find(item_id);
    if (i != itemid_category_map->end()) {
      categories = i->second;
    } 
  }

  if (categories.empty()) {
    LOG(ERROR) << "item has no category, " << item_id;
    return false;
  } 

  item->category = categories[0];
  if (categories.size() > 1u) {
    item->sub_category = categories[1];
  }

  item->create_timestamp = full->create_timestamp();

  std::string source_media = full->source_media();
  item->source_media_sign = base::CalcTermSign(source_media.c_str(), source_media.size());
  std::string orig_source_media = full->orig_source_media();
  item->orig_source_media_sign = base::CalcTermSign(orig_source_media.c_str(), orig_source_media.size());

  item->orig_media_risk_type = full->orig_media_risk_type();
  item->wilson_ctr = full->wilson_ctr();

  const std::string source = full->source();
  item->source_sign = base::CalcTermSign(source.c_str(), source.size());

  static const char* wemedia_source = "cp_wemedia_uc_";
  static const size_t wemedia_size = strlen(wemedia_source);
  if (source.size() >= wemedia_size) {
    size_t i = 0;
    for (; i < wemedia_size; ++i) {
      if (source[i] != wemedia_source[i]) {
        break;
      }
    }
    item->is_source_wemedia = (i == wemedia_size);
  }

  // calc media level
  if (item->is_source_wemedia) {
    item->media_level = reco::kNormalMedia;
  } else {
    item->media_level = reco::kLowMedia;
  }
  // 机构媒体：用 类别 + "\t" + 名称 做 key 进行查找
  auto cate_media_level_map = DM_GET_DICT(reco::dm::MediaLevelDict, reco::IndexDynamicDictContainer::kMediaLevelFile_);
  const std::string used_media = (!orig_source_media.empty()) ? orig_source_media : source_media;
  const std::string cate_media = item->category + "\t" + used_media;
  auto level_iter = cate_media_level_map->find(cate_media);
  if (level_iter == cate_media_level_map->end()) {
    level_iter = cate_media_level_map->find("全部\t" + used_media);
  }
  if (level_iter != cate_media_level_map->end()) {
    item->media_level = level_iter->second;
  }

  item->first_n_hide = full->first_nscreen_filter();
  std::string rule_bits = full->app_token_rule_bits();
  int bitnum = full->app_token_bits();
  if (bitnum > 0 && !rule_bits.empty()) {
    size_t size = rule_bits.size() * 8;
    item->app_rule_mask.resize(size, false);
    boost::from_block_range(rule_bits.begin(), rule_bits.end(), item->app_rule_mask);
  } else {
    item->app_rule_mask.resize(0, false);
  }
 
  return true;
}

bool NewsIndex::CollectIds(const reco::presort::GetDefaultRecoResponse* resp,
  std::unordered_set<uint64>* res_ids_set) {
  res_ids_set->clear();
  base::PseudoRandom random(base::GetTimestamp());
  for (int ind = 0; ind < resp->item_info_size(); ind++) {
    auto item_id = resp->item_info(ind).item_id();
    int64 ha3_update_time = resp->item_info(ind).ha3_update_timestamp();
    int64 update_time = 0;
    int64 rand_time = random.GetUint64LT(item_valid_time_);
    ItemInfoFullPtr p;
    bool ret = item_map_w_->FindSilently(item_id, &p, &update_time);
    if (!ret || (base::GetTimestamp() - update_time - rand_time > (int64)item_valid_time_) || 
       (ha3_update_time - update_time > 0)) {
      res_ids_set->insert(item_id);
    }
  }
  return true;
}

bool NewsIndex::CollectSimIds(const std::unordered_set<uint64>* ids_set, std::unordered_set<uint64>* res_ids_set) {
  res_ids_set->clear();
  base::PseudoRandom random(base::GetTimestamp());
  for (auto i = ids_set->begin(); i != ids_set->end(); i++) {
    SimiIdsSetPtr tmpset = GetSimItemIds(*i);
    if (tmpset == NULL) {
      continue;
    }
    for (auto k = tmpset->begin(); k != tmpset->end(); k++) {
      auto item_id = *k;
      int64 update_time = 0;
      int64 rand_time = random.GetUint64LT(item_valid_time_);
      ItemInfoFullPtr p;
      bool ret = item_map_w_->FindSilently(item_id, &p, &update_time);
      if (!ret || (base::GetTimestamp() - update_time - rand_time > (int64)item_valid_time_)) {
        res_ids_set->insert(item_id);
      }
    }
  }

  return true;
}

bool NewsIndex::CollectPreviewIds(const std::unordered_set<uint64>* ids_set, std::unordered_set<uint64>* res_ids_set) {
  res_ids_set->clear();
  base::PseudoRandom random(base::GetTimestamp());
  for (auto i = ids_set->begin(); i != ids_set->end(); i++) {
    std::unordered_set<uint64> tmpset;

    GetPreviewIdsByItemId(*i, &tmpset);
    for (auto k = tmpset.begin(); k != tmpset.end(); k++) {
      auto item_id = *k;
      int64 update_time = 0;
      int64 rand_time = random.GetUint64LT(item_valid_time_);
      ItemInfoFullPtr p;
      bool ret = item_map_w_->FindSilently(item_id, &p, &update_time);
      if (!ret || (base::GetTimestamp() - update_time - rand_time > (int64)item_valid_time_)) {
        res_ids_set->insert(item_id);
      }
    }
  }

  return true;
}

bool NewsIndex::GetItemInfoFull(const std::unordered_set<uint64>* ids_set, int timeout_ms) {
  // make pk query
  reco::index::RecoQuery q;
  q.result_num_ = result_num_; 
  q.ori_result_num_ = result_num_; 
  q.reco_type_ = reco::presort::kTestReco;

  int group_ids_num = 0;
  bool is_first=true;
  int batch_num = 2000;
  for (auto i = ids_set->begin(); i != ids_set->end(); i++) {
    if (!is_first){
      q.clause_ += " OR ";
    }

    q.clause_ += std::string("pk:") + base::Uint64ToString(*i);
    group_ids_num ++;
    is_first = false;

    if (group_ids_num == batch_num) {
      q.result_num_ = group_ids_num;
      q.ori_result_num_ = group_ids_num;
      GetBatchIdsResultFromProxy(&q, timeout_ms);
      q.clause_ = "";
      is_first = true;
      group_ids_num = 0;
      continue;
    }
  }

  if (group_ids_num > 0 ) {
    q.result_num_ = group_ids_num;
    q.ori_result_num_ = group_ids_num;
    GetBatchIdsResultFromProxy(&q, timeout_ms);
  }

  return true;
}

bool NewsIndex::GetItemInfoFullAsync(const std::unordered_set<uint64>* ids_set) {
  for (auto i = ids_set->begin(); i != ids_set->end(); i++) {
    uint64 item_id = *i;
    if(!missing_item_queue_.Put(item_id)) {
      LOG(ERROR) << "add to missing_item_queue_ fail, item_id=" << item_id;
    } else {
      VLOG(1) << "add to missing_item_queue_ succ, item_id=" << item_id << " size=" << missing_item_queue_.Size();
    }
  }

  return true;
}

bool NewsIndex::GetItemInfoFullMulti(const std::unordered_set<uint64>* ids_set, int timeout_ms) {
  if (ids_set == NULL || ids_set->empty()) {
    return true;
  }

  int batch_num = 2000;
  int pool_size = ids_set->size()/batch_num;
  if (pool_size < 1) {
    pool_size=1;
  } else if (pool_size > 20) {
    pool_size = 20;
  }
  thread::ThreadPool thread_pool(pool_size);
  LOG(INFO) << "get GetItemInfoFullMulti start..num=" << ids_set->size() << " pool_size=" << pool_size;
  // make pk query
  std::vector<reco::index::RecoQuery > qrs;
  qrs.reserve(ids_set->size()/batch_num +1);

  reco::index::RecoQuery q;
  q.result_num_ = result_num_; 
  q.ori_result_num_ = result_num_; 
  q.reco_type_ = reco::presort::kTestReco;

  int group_ids_num = 0;
  int group_count = 0;

  bool is_first=true;
  for (auto i = ids_set->begin(); i != ids_set->end(); i++) {
    if (!is_first){
      q.clause_ += " OR ";
    }

    q.clause_ += std::string("pk:") + base::Uint64ToString(*i);
    group_ids_num ++;
    is_first = false;

    if (group_ids_num == batch_num) {
      q.result_num_ = group_ids_num;
      q.ori_result_num_ = group_ids_num;
      qrs.push_back(q);
      thread_pool.AddTask(NewCallback(this, &NewsIndex::GetBatchIdsResultFromProxy, &(qrs[group_count]), timeout_ms));
      group_count ++;

      q.clause_ = "";
      is_first = true;
      group_ids_num = 0;
      continue;
    }
  }

  if (group_ids_num > 0 ) {
    q.result_num_ = group_ids_num;
    q.ori_result_num_ = group_ids_num;
    qrs.push_back(q);
    thread_pool.AddTask(NewCallback(this, &NewsIndex::GetBatchIdsResultFromProxy, &(qrs[group_count]), timeout_ms));
    group_count ++;
  }

  thread_pool.JoinAll();
  LOG(INFO) << "get GetItemInfoFullMulti end, size=" << ids_set->size();
  return true;
}

void NewsIndex::GetBatchIdsResultFromProxy(reco::index::RecoQuery* q, int timeout_ms) {
  reco::presort::GetDefaultRecoRequest request;
  reco::presort::GetDefaultRecoResponse resp;
  q->toRecoRequest(&request);
  request.set_only_id(false);
  int group_ids_num = q->result_num_;

  if(!presort_client_->GetItemList(request,  &resp, timeout_ms, false)) {
    LOG(ERROR) << "presort_client_ pk fail," << " group_ids_num=" << group_ids_num << " query=" << q->clause_;
    return;
  } else {
    LOG(INFO) << "presort_client_ pk succ," << " ids_num=" << group_ids_num
     << " res_num=" << resp.item_info_size() << " total_id_num=" << item_map_w_->Size();
  }

  if (resp.item_info_size() == 0) {
    return;
  }

  if(!FillItemInfoFullCache(&resp)) {
    LOG(ERROR) << "FillItemInfoFullCache fail";
    return;
  } 

  return;
}

bool NewsIndex::GetResultFromProxy(const reco::index::RecoQuery& q, SearchOpts opt,
  ItemInfoFullPtrListPtr* item_full_list, ItemInfoListPtr* item_simple_list) {
  std::string key = q.toString(); 
  reco::presort::GetDefaultRecoRequest request;
  reco::presort::GetDefaultRecoResponse resp;
  q.toRecoRequest(&request);
  // 倒排写死都是只取id
  request.set_only_id(true);

  if(!presort_client_->GetItemList(request,  &resp, opt.timeout_ms, opt.allow_cut_off)) {
    LOG(ERROR) << "presort GetItemList fail, timeout_ms=" << opt.timeout_ms << " query=" << key;
    return false;
  } else {
    LOG(INFO) << "GetItemList succ query=" << key << " res_num=" << resp.item_info_size();
  }

  if (opt.allow_item_loss) {
    if(!GenerateItemList(q.toString(), &resp, opt.need_store_list_cache, item_full_list, item_simple_list, false)) {
      LOG(ERROR) << "GenerateItemList fail, query=" << q.toString();
      return false;
    } 

    COUNTERS_news_index__only_id_count.Increase(resp.item_info_size());
    if(item_full_list != NULL) {
      COUNTERS_news_index__only_id_miss_count.Increase(item_full_list->get()->size());
    } else if(item_simple_list != NULL) {
      COUNTERS_news_index__only_id_miss_count.Increase(item_simple_list->get()->size());
    }

    if (update_cache_query_) {
      if (opt.need_refresh &&  resp.item_info_size() > 0) {
        thread::AutoLock auto_lock(&mutex_of_cache_query_);
        cache_query_[q.toString()] = q;
      }
    }
  } else {
    if (q.result_num_ > 100000) {
      LOG(INFO) << "UpdateWork GetItemList succ, timeout_ms=" << opt.timeout_ms << " query=" << key << " res_num=" << resp.item_info_size();
    }
    std::unordered_set<uint64> ids_set;
    CollectIds(&resp, &ids_set);

    if (ids_set.size() < 5000) {
      if(!GetItemInfoFull(&ids_set, opt.timeout_ms)) {
        LOG(ERROR) << "get GetItemInfoFull error, key=" << key ;
        return false;
      }
    } else {
      if(!GetItemInfoFullMulti(&ids_set, opt.timeout_ms)) {
        LOG(ERROR) << "get GetItemInfoFullMulti error, key=" << key ;
        return false;
      }
    }

    if (update_count_ == 0) {
      std::unordered_set<uint64> sim_ids_set;
      CollectSimIds(&ids_set, &sim_ids_set);

      if(!GetItemInfoFull(&sim_ids_set, opt.timeout_ms)) {
        LOG(ERROR) << "GetItemInfoFull preview error, key=" << key ;
        return false;
      }
    }

    std::unordered_set<uint64> preview_ids_set;
    CollectPreviewIds(&ids_set, &preview_ids_set);

    if(!GetItemInfoFull(&preview_ids_set, opt.timeout_ms)) {
      LOG(ERROR) << "GetItemInfoFull preview error, key=" << key ;
      return false;
    }

    if (opt.need_build_list && resp.item_info_size() <= MAX_LIST_LEN) {
      if(!GenerateItemList(q.toString(), &resp, opt.need_store_list_cache, item_full_list, item_simple_list, true)) {
        LOG(ERROR) << "GenerateItemList fail, query=" << q.toString();
        return false;
      } 
    }

    if (q.reco_type_ == reco::presort::kCategoryReco) {
      LOG(INFO) << "update list, update_count=" << update_count_ << " cat=" << q.wc_->ToString() << " proxy_retnum=" << resp.item_info_size() 
        << " need_update_num=" << ids_set.size() << " previewidnum=" << preview_ids_set.size()
        << " cache res_num_full=" << item_full_list->get()->size()
        << " cache res_num=" << item_simple_list->get()->size()
        << " total_id_num=" << item_map_w_->Size();
    }
  }

  return true;
}

bool NewsIndex::GetChannelAndCategoryFromProxy() {
  reco::presort::GetChnAndCateRequest request;
  reco::presort::GetChnAndCateResponse resp;
  request.set_return_channel(true);
  request.set_return_category(true);
  request.set_return_term(true);

  if(!presort_client_->GetChannelAndCategory(request,  &resp)) {
    LOG(ERROR) << "presort_client_ GetChannelAndCategory fail";
    return false;
  } else {
    LOG(INFO) << "presort_client_ GetChannelAndCategory succ cat_num=" << resp.categories_size()
    << " channel_num=" << resp.channels_size() << " term_num=" << resp.terms_size() ;
  }

  if (resp.categories_size() == 0) {
    LOG(ERROR) << "empty categories result";
    return false;
  }

  if (resp.channels_size() == 0) {
    LOG(ERROR) << "empty channels result";
    return false;
  }

//  if (resp.terms_size() == 0) {
//    LOG(INFO) << "empty terms result";
//    return false;
//  }

  // 目前 index 接口只用到1级分类
  CategoryListPtr cat0(new CategoryList());
  if(!cat0) {
    LOG(ERROR) << "new memory for CategoryListPtr fail" ;
    return false;
  }
  CategoryListPtr cat1(new CategoryList());
  if(!cat1) {
    LOG(ERROR) << "new memory for CategoryListPtr fail" ;
    return false;
  }

  std::set<std::string> dedup_set;

  for (auto i = 0; i < resp.categories_size(); i++) {
    std::vector<std::string > str_categories;
    base::SplitString(resp.categories(i), "\t", &str_categories);

    if (str_categories[0] == "") {
        continue;
    }

    if (dedup_set.find(str_categories[0]) == dedup_set.end()) {
      Category cat;
      ConvertToCategoryProto(str_categories, 0, &cat);
      cat0->push_back(cat);
      dedup_set.insert(str_categories[0]);
      LOG(INFO) << "update_count=" << update_count_  << " level0 catogery:" << str_categories[0];
    }

    if (str_categories.size() >= 2 && str_categories[1] != "") {
      Category cat;
      ConvertToCategoryProto(str_categories, 1, &cat);
      cat1->push_back(cat);
      LOG(INFO) << "update_count=" << update_count_  << " level1 catogery:" << str_categories[0] << "," << str_categories[1];
    }
  }

  category_cache_->Add(0, cat0);
  category_cache_->Add(1, cat1);
  VLOG(1) << "add level0 catogery cache: size=" << cat0->size();
  VLOG(1) << "add level1 catogery cache: size=" << cat1->size();

  ChannelListPtr chan(new ChannelList());
  if(!chan) {
    LOG(ERROR) << "new memory for ChannelListPtr fail" ;
    return false;
  }

  for (auto i = 0; i < resp.channels_size(); i++) {
    chan->push_back(resp.channels(i));
    VLOG(1) << "channel:" << resp.channels(i);
  }

  channel_cache_->Add(0, chan);
  VLOG(1) << "add channel cache: size=" << chan->size();

//  TermListPtr terms(new TermList());
//  if(!terms) {
//    LOG(ERROR) << "new memory for TermsListPtr fail" ;
//    return false;
//  }
//
//  for (auto i = 0; i < resp.terms_size(); i++) {
//    terms->push_back(resp.terms(i));
//    VLOG(2) << "terms:" << resp.terms(i);
//  }
//
//  term_cache_->Add(0, terms);
//  LOG(INFO) << "add terms cache: size=" << terms->size();

  return true;
}

bool NewsIndex::GetLatestNewsFromProxy(const std::string& event_name) {
  reco::presort::GetLatestNewsRequest request;
  reco::presort::GetLatestNewsResponse response;
  request.set_event_name(event_name);

  if(!presort_client_->GetLatestNews(request,  &response)) {
    LOG(ERROR) << "presort_client_ GetLatestNews fail";
    return false;
  } else {
    if ( response.success()) {
      LOG(INFO) << "presort_client_ GetLatestNews succ";
    } else {
      LOG(ERROR) << "presort_client_ success false";
      return false;
    }
  }

  LatestNewsPairPtr ptr(new LatestNewsPair());
  ptr->first = response.latest_item_id();
  ptr->second.CopyFrom(response.timeaxis_info());
  latest_news_cache_->Add(event_name, ptr);
  VLOG(1) << "add event_name cache: " << event_name;

  return true;
}

bool NewsIndex::GetWeMediaItemsFromProxy() {
  reco::presort::GetWemediaDictRequest request;
  reco::presort::GetWemediaDictResponse response;

  if(!presort_client_->GetWemediaDict(request,  &response)) {
    LOG(ERROR) << "presort_client_ GetWemediaDict fail";
    return false;
  } else {
    if ( response.success()) {
      LOG(INFO) << "presort_client_ GetWemediaDict succ, size=" << response.dicts_size();
    } else {
      LOG(ERROR) << "presort_client_ GetWemediaDict success false";
      return false;
    }
  }

  WeMediaItemsDictPtr ptr(new WeMediaItemsDict());
  WeMediaItemsDict& dd = *ptr;
  for (int i = 0; i < response.dicts_size(); i++) {
    for (int k = 0; k < response.dicts(i).item_ids_size(); k++) {
      dd[response.dicts(i).wemedia_name()].insert(response.dicts(i).item_ids(k));
    }
  }
  wemedia_items_cache_->Add(WE_MEDIA_ITEMS_KEY, ptr);
  VLOG(1) << "WemediaItemsDict size=" << ptr->size();

  return true;
}

bool NewsIndex::GetItemBreakingFromProxy() {
  reco::presort::GetDictsRequest request;
  reco::presort::GetDictsResponse response;
  request.set_dict_type(reco::presort::kItemBreakingDict);

  if(!presort_client_->GetDicts(request, &response)) {
    LOG(ERROR) << "presort_client_ GetDicts fail";
    return false;
  } else {
    if (response.breaking_pairs_size() == 0) {
      LOG(ERROR) << "presort_client_ GetDicts size is 0";
      //return false;
    } else {
      LOG(INFO) << "presort_client_ GetDicts size=" << response.breaking_pairs_size();
    }
  }

  ItemBreakingDictPtr ptr(new ItemBreakingDict());
  for (int i = 0; i < response.breaking_pairs_size(); i++) {
    (*ptr)[response.breaking_pairs(i).key()] = LocalBreaking();
    (*ptr)[response.breaking_pairs(i).key()].CopyFrom(response.breaking_pairs(i).val());
  }
  item_breaking_cache_->Add(ITEM_BREAKING_KEY, ptr);
  VLOG(1) << "ItemBreakingDict size=" << ptr->size();

  return true;
}

bool NewsIndex::GetSourceMetaFromProxy() {
  reco::presort::GetDictsRequest request;
  reco::presort::GetDictsResponse response;
  request.set_dict_type(reco::presort::kMediaQuantityMetaDict);

  if(!presort_client_->GetDicts(request, &response)) {
    LOG(ERROR) << "presort_client_ GetDicts fail, type=" << reco::presort::kMediaQuantityMetaDict;
    return false;
  }

  int count = 0;
  for (int i = 0; i < response.media_infos_size(); i++) {
    if (MediaQuantityInfoIns::instance().UpdateQuantityMetaInfo(response.media_infos(i))) {
      count ++;
    }
  }

  LOG(INFO) << "meta info size=" << response.media_infos_size() 
    << " update:" << count;

  return true;
}

void NewsIndex::FindCacheOrSearch(reco::index::RecoQuery& q, ItemInfoFullPtrListPtr* item_list, 
  SearchOpts& opt) {
  COUNTERS_news_index__get_docs_request_count.Increase(1);

  *item_list = empty_list_ptr_full_;
  q.ori_result_num_ = q.result_num_;

  std::string key = q.toString();
  VLOG(1) << "search ItemInfoFull start, from=" << q.from_  << " key=" << key ;

  list_access_time_->Add(key, base::GetTimestamp());

  bool hit_cache = false;

  if (opt.find_from_cache) {
    hit_cache = item_list_cache_->FindSilently(key, item_list);
  }

  if (!hit_cache) {
    VLOG(1) << "not hit item list cache, search...key=" << key ;

    if (opt.allow_cut_off && index_cut_off_num_ < q.result_num_) {
      q.result_num_ = index_cut_off_num_; 
    }

    if (opt.timeout_ms <= 0 ) {
      opt.timeout_ms = proxy_short_timeout_ms_;
    }

    ItemInfoListPtr item_info_list = empty_list_ptr_;
    if(!GetResultFromProxy(q, opt, item_list, &item_info_list)) {
      LOG(ERROR) << "search ItemInfoFull end, error, key=" << key ;
    }
  } else {
    VLOG(1) << "hit item list cache, search key=" << key ;
    COUNTERS_news_index__get_docs_hit_cache_count.Increase(1);
  }
  COUNTERS_news_index__get_docs_resnum.Increase(item_list->get()->size());
}

void NewsIndex::FindCacheOrSearch(reco::index::RecoQuery& q, ItemInfoListPtr* item_list,
  SearchOpts& opt) {
  COUNTERS_news_index__get_docs_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  *item_list = empty_list_ptr_;
  q.ori_result_num_ = q.result_num_;
  std::string key = q.toString();
  VLOG(1) << "search ItemInfo start, from=" << q.from_  << " key=" << key ;

  list_access_time_->Add(key, base::GetTimestamp());

  bool hit_cache = false;
  if (opt.find_from_cache) {
    hit_cache = item_info_list_cache_->FindSilently(key, item_list);
  }

  if (!hit_cache) {
    VLOG(1) << "not hit item list cache, search...key=" << key ;
    if (opt.allow_cut_off && index_cut_off_num_ < q.result_num_) {
      q.result_num_ = index_cut_off_num_; 
    }

    if (opt.timeout_ms <= 0 ) {
      opt.timeout_ms = proxy_short_timeout_ms_;
    }

    ItemInfoFullPtrListPtr item_list_full = empty_list_ptr_full_;
    if(!GetResultFromProxy(q, opt, &item_list_full, item_list)) {
      LOG(ERROR) << "search ItemInfo end, error, key=" << key ;
    }
  } else {
    VLOG(1) << "hit item list cache, search key=" << key ;
    COUNTERS_news_index__get_docs_hit_cache_count.Increase(1);
  }
  COUNTERS_news_index__get_docs_resnum.Increase(item_list->get()->size());
}

ItemInfoListPtr NewsIndex::GetDefaultReco() {
  ItemInfoListPtr item_list;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_; 
  q.reco_type_ = reco::presort::kDefault;
  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  return item_list;
}

ItemInfoListPtr NewsIndex::GetDefaultReco(const reco::Category& category, bool timely) {
  ItemInfoListPtr item_list;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_; 
  q.reco_type_ = reco::presort::kCategoryReco;
  q.wc_ = std::shared_ptr<reco::common::WrappedCategory>(new reco::common::WrappedCategory(category));
  q.timely_ = timely;

  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  return item_list;
}

ItemInfoListPtr NewsIndex::GetGuaranteeQuantityReco(const reco::Category& category) {
  ItemInfoListPtr item_list;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_; 
  q.reco_type_ = reco::presort::kQuantityReco;
  q.wc_ = std::shared_ptr<reco::common::WrappedCategory>(new reco::common::WrappedCategory(category));
  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  return item_list;
}

ItemInfoListPtr NewsIndex::GetDefaultReco(int64 channel_id, int64 region_id, bool only_video) {
  if (only_video) {
    return GetVideoDefaultReco(channel_id);
  }

  ItemInfoListPtr item_list;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_; 
  q.reco_type_ = reco::presort::kChannelReco;
  q.channel_id_ = channel_id;
  q.region_id_ = region_id;

  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  return item_list;
}

ItemInfoListPtr NewsIndex::GetVideoDefaultReco(const reco::Category& category) {
  ItemInfoListPtr item_list;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_; 
  q.reco_type_ = reco::presort::kVideoCategoryReco;
  q.wc_ = std::shared_ptr<reco::common::WrappedCategory>(new reco::common::WrappedCategory(category));

  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  return item_list;
}

ItemInfoListPtr NewsIndex::GetVideoDefaultReco(const int64 channel_id, bool explore) {
  ItemInfoListPtr item_list;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_; 
  q.reco_type_ = reco::presort::kVideoChannelReco;
  q.channel_id_ = channel_id;
  q.explore_= explore;

  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  return item_list;
}

void NewsIndex::GetUCBDefaultReco(ItemInfoListPtr* item_list, uint64 max_return_size) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kUCBReco;

  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, item_list, opt);
}

ItemInfoListPtr NewsIndex::GetHotCardDefaultReco() {
  ItemInfoListPtr item_list;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_; 
  q.reco_type_ = reco::presort::kHotCardReco;

  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  return item_list;
}

ItemInfoListPtr NewsIndex::GetJingpinDefaultReco() {
  ItemInfoListPtr item_list;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_; 
  q.reco_type_ = reco::presort::kChannelReco;
  q.channel_id_ = reco::common::kJingpinChannelId;

  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  return item_list;
}

ItemInfoListPtr NewsIndex::GetLocalDefaultReco(int64 region_id) {
  ItemInfoListPtr item_list;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_;
  q.reco_type_ = reco::presort::kChannelReco;
  q.channel_id_ = reco::common::kLocalChannelId;
  q.region_id_ = region_id;

  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  return item_list;
}

ItemInfoListPtr NewsIndex::GetPOIDefaultReco(int64 area_id) {
  ItemInfoListPtr item_list;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_;
  q.reco_type_ = reco::presort::kPOIReco;
  q.area_id_ = area_id;

  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  return item_list;
}

ItemInfoListPtr NewsIndex::GetLocalBreakingDefaultReco(int64 region_id) {
  ItemInfoListPtr item_list;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_;
  q.reco_type_ = reco::presort::kLocalBreakingReco;
  q.region_id_ = region_id;

  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  VLOG(1) << "len=" << item_list->size();
  return item_list;
}

ItemInfoListPtr NewsIndex::GetMiningStrategyReco(int stragety) {
  ItemInfoListPtr item_list = empty_list_ptr_;
  reco::index::RecoQuery q;
  q.result_num_ = result_num_;
  q.reco_type_ = reco::presort::kMiningSttgReco;
  q.strategy_ = stragety;

  q.from_ = std::string(__func__);
  SearchOpts opt;
  FindCacheOrSearch(q, &item_list, opt);
  VLOG(1) << "len=" << item_list->size();
  return item_list;
}


void NewsIndex::GetDocsByItemId(uint64 item_id, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = std::string("pk:") + base::Uint64ToString(item_id);
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByChannel(int64 channel_id, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetChannelPayloadTerm(channel_id) + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}


void NewsIndex::GetDocsBySource(const std::string& source, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetSourcePayloadTerm(source) + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByCategory(const std::string& category, int level, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTermReco;
  q.term_ = reco::common::GetCategoryPayloadTerm(category, level);
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByEventTag(const std::string& tag, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetEventTagPayloadTerm(tag) + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByMultiCategory(const std::string& category, int level, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetCategoryCandidatesPayloadTerm(category, level) + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByKeywordOrTag(const std::string& word, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetTagPayloadTerm(word)  + std::string("\"")
    + std::string(" OR ")
    + INDEX_NAME + std::string(":\"") + reco::common::GetFeaturePayloadTerm(word, reco::common::kKeyword) + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByShowTag(const std::string& tag, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetShowTagPayloadTerm(tag) + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByTag(const std::string& tag, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTermReco;
  q.term_ = reco::common::GetTagPayloadTerm(tag);
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByTag(const std::string& tag, reco::ItemType item_type, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetTagPayloadTerm(tag) + std::string("\"")
    + "&&filter=ITEM_TYPE=" + base::IntToString(static_cast<int>(item_type));
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByNovelId(const std::string& novel_id, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetNovelIdPayloadTerm(novel_id) + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByTerm(const std::string& term, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + term + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByClause(const std::string& clause, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = clause;
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByItemType(int32 item_type, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetItemTypePayloadTerm(item_type) + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByRegionID(const std::string &region_id, ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetRegionIDPayloadTerm(region_id) + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByWeMedia(ItemInfoFullPtrListPtr* item_list,
  uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetWeMediaPayloadTerm() + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsBySpiderQuery(const std::string& query,
  ItemInfoFullPtrListPtr* item_list, uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetSpiderQueryPayloadTerm(query) + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

void NewsIndex::GetDocsByTitleLdaTopic(const std::string& topic,
  ItemInfoFullPtrListPtr* item_list, uint64 max_return_size, SearchOpts opt) {
  reco::index::RecoQuery q;
  q.result_num_ = (max_return_size == 0)?result_num_:max_return_size; 
  q.reco_type_ = reco::presort::kTestReco;
  q.clause_ = INDEX_NAME + std::string(":\"") + reco::common::GetTitleLdaTopicPayloadTerm(topic) + std::string("\"");
  q.from_ = std::string(__func__);
  FindCacheOrSearch(q, item_list, opt);
}

bool NewsIndex::GetItemTypeByItemId(uint64 item_id, reco::ItemType* item_type) const {
  GET_INT_INDEX_ATTR(item_type);
  *item_type = static_cast<reco::ItemType>(INT_VALUE);
  return FIND_FLAG;
}

uint32 NewsIndex::GetDocMaskByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(docmask);
  if (!FIND_FLAG) {
    return DocMaskInvalid;
  } else {
  return static_cast<uint32>(INT_VALUE);
  }
}

bool NewsIndex::GetItemPtrByItemId(uint64 item_id, ItemInfoFullPtr *p) const {
  bool ret = false;

  COUNTERS_news_index__get_attr_count.Increase(1);
  if (item_map_->FindSilently(item_id, p)) {
    ret = true;
  } else {
    ret = false;
    COUNTERS_news_index__get_attr_err_count.Increase(1);
  }

  return ret;
}


bool NewsIndex::GetMetaInfo(uint64 item_id, ItemInfo *item) const {
  bool ret = false;

  item->item_id = item_id;
  ItemInfoFullPtr p;
  COUNTERS_news_index__get_attr_count.Increase(1);
  if (item_map_->FindSilently(item_id, &p)) {
    GetMetaInfoFromFull(p, item);
    ret = true;
  } else {
    ret = false;
    COUNTERS_news_index__get_attr_err_count.Increase(1);
  }

  return ret;
}

bool NewsIndex::GetItemInfoByItemId(uint64 item_id, ItemInfo* item_info, bool only_basic) {
  ItemInfoFullPtr p;
  serving_base::Timer timer;
  timer.Start();

  COUNTERS_news_index__get_attr_count.Increase(1);
  if (item_map_->FindSilently(item_id, &p)) {
    GetItemInfoFromFull(p, item_info, only_basic);
    COUNTERS_news_index__get_attr_time.Increase(timer.Stop());
  } else {
    VLOG(2) << "FUNC:" << __func__ << " not find, item_id=" << item_id;
    COUNTERS_news_index__get_attr_err_count.Increase(1);
    COUNTERS_news_index__get_attr_time.Increase(timer.Stop());

    if(!missing_item_queue_.Put(item_id)) {
      LOG(ERROR) << "add to missing_item_queue_ fail, item_id=" << item_id;
    } else {
      VLOG(1) << "add to missing_item_queue_ succ, item_id=" << item_id << " size=" << missing_item_queue_.Size();
    }
    return false;
  }

  return true;
}

bool NewsIndex::GetItemTitleByItemId(uint64 item_id, std::string* title) const {
  GET_SIMPLE_INDEX_ATTR(title);
}

bool NewsIndex::GetItemBidwordByItemId(uint64 item_id, std::string* bid_word) const {
  GET_SIMPLE_INDEX_ATTR(bid_word);
}

bool NewsIndex::GetItemContentByItemId(uint64 item_id, std::string* content) const {
  GET_SIMPLE_INDEX_ATTR(content);
}

bool NewsIndex::GetItemRawSummaryByItemId(uint64 item_id, std::string* raw_summary) const {
  GET_SIMPLE_INDEX_ATTR(raw_summary);
}

int64 NewsIndex::GetCreateTimestampByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(create_timestamp);
  return static_cast<int64>(INT_VALUE);
}

int64 NewsIndex::GetExpireTimestampByItemId(uint64 item_id) const {
  if (!(GetDocMaskByItemId(item_id) & reco::common::kDocMaskTimeWhiteList)) {
    return kTimestampInFuture;
  }

  GET_INT_INDEX_ATTR(expire_timestamp);
  return static_cast<int64>(INT_VALUE);
}

int64 NewsIndex::GetPublishSecondByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(publish_time);
  return static_cast<int64>(INT_VALUE);
}

int64 NewsIndex::GetCrawlTimestampByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(crawl_timestamp);
  return static_cast<int64>(INT_VALUE);
}

bool NewsIndex::GetPreviewIdsByItemId(uint64 item_id, std::unordered_set<uint64>* preview_ids) const {
  preview_ids->clear();
  std::vector<std::string> id_list;
  GET_STRING_INDEX_ATTR(special_prevew_item_list);
  base::SplitString(STRING_VALUE, ",", &id_list);
  uint64 id;
  for (int i = 0; i < (int)id_list.size(); ++i) {
    if (base::StringToUint64(id_list[i], &id)) {
      preview_ids->insert(id);
    }
  }
  return true;
}

bool NewsIndex::GetContainIdsByItemId(uint64 item_id, std::unordered_set<uint64>* contain_ids) const {
  contain_ids->clear();
  std::vector<std::string> id_list;
  GET_STRING_INDEX_ATTR(special_contain_item_list);
  base::SplitString(STRING_VALUE, ",", &id_list);
  uint64 id;
  for (int i = 0; i < (int)id_list.size(); ++i) {
    if (base::StringToUint64(id_list[i], &id)) {
      contain_ids->insert(id);
    }
  }
  return true;
}

int32 NewsIndex::GetContentLengthByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(content_length);
  return static_cast<int32>(INT_VALUE);
}

int32 NewsIndex::GetParagraphNumByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(paragraph_num);
  return static_cast<int32>(INT_VALUE);
}

int32 NewsIndex::GetImageCountByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(image_count);
  return static_cast<int32>(INT_VALUE);
}

bool NewsIndex::GetImageByItemId(uint64 item_id, std::vector<uint64>* image) const {
  GET_STRING_INDEX_ATTR(image_hash);
  if (STRING_VALUE.empty()) return false;

  std::vector<std::string> tokens;
  base::SplitString(STRING_VALUE, ",", &tokens);

  image->reserve(tokens.size());
  int64 hash = 0;
  for (int i = 0; i < (int)tokens.size(); ++i) {
    if (!base::StringToInt64(tokens[i], &hash)) continue;
    if (hash == 0) continue;
    image->push_back(hash);
  }
  return true;
}

bool NewsIndex::GetNovelIdByItemId(uint64 item_id, std::string* novel_id) const {
  GET_SIMPLE_INDEX_ATTR(novel_id);
}

int64 NewsIndex::GetNovelUpdateTimestampByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(novel_update_time);
  return static_cast<int64>(INT_VALUE);
}

int32 NewsIndex::GetVideoCountByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(video_count);
  return static_cast<int32>(INT_VALUE);
}

int32 NewsIndex::GetTotalVideoLengthByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(video_length);
  return static_cast<int32>(INT_VALUE);
}

VideoAttr::VideoVulgarLevel NewsIndex::GetVideoVulgarLevelByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(video_vulgar_level);
  return (VideoAttr::VideoVulgarLevel)INT_VALUE;
}

VideoAttr::VideoQualityLevel NewsIndex::GetVideoQualityLevelByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(video_quality_level);
  return (VideoAttr::VideoQualityLevel)INT_VALUE;
}

int32 NewsIndex::GetTitleLengthByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(title_length);
  return static_cast<int32>(INT_VALUE);
}

bool NewsIndex::IsYuanchuangItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(item_is_yuanchuang);
  return INT_VALUE!=0;
}

bool NewsIndex::HasVideoStorageInfoByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(has_video_storage_info);
  return INT_VALUE!=0;
}

int NewsIndex::GetVideoStorageInfoStatusByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(video_storage_info_status);
  if (FIND_FLAG) { 
    return static_cast<int32>(INT_VALUE);
  } else {
    return -1;
  }
}

float NewsIndex::GetVideoBlackEdgeRatioByItemId(uint64 item_id) const {
  GET_FLOAT_INDEX_ATTR(video_black_edge_ratio);
  return FLOAT_VALUE;
}

bool NewsIndex::GetVideoPosterProblemInfoByItemId(uint64 item_id, std::set<std::string> *problems) const {
  GET_STRING_INDEX_ATTR(video_poster_problem_info);
  if (STRING_VALUE.empty()) return false;
  problems->clear();
  std::vector<std::string> tokens;
  base::SplitString(STRING_VALUE, ",", &tokens);
  for (size_t i = 0; i < tokens.size(); ++i) {
    problems->insert(tokens[i]);
  }
  return !problems->empty();
}

bool NewsIndex::GetVideoPlayControlByItemId(uint64 item_id, reco::VideoPlayControl *video_play_control) const {
  GET_STRING_INDEX_ATTR(video_play_control);
  if (STRING_VALUE.empty()) return false;

  std::string decode_str;
  if (!reco::common::DecodeUrlComponent(STRING_VALUE.c_str(), &decode_str)) {
    LOG(ERROR) << "decode fail: item_id=" << item_id;
    return false;
  }

  if (!video_play_control->ParseFromString(decode_str)) return false;
  return true;
}

bool NewsIndex::GetParagraphByItemId(uint64 item_id, std::vector<uint64>* paragraph) const {
  GET_STRING_INDEX_ATTR(paragraph_hash);
  if (STRING_VALUE.empty()) return false;

  std::vector<std::string> tokens;
  base::SplitString(STRING_VALUE, ",", &tokens);

  paragraph->reserve(tokens.size());
  int64 hash = 0;
  for (int i = 0; i < (int)tokens.size(); ++i) {
    if (!base::StringToInt64(tokens[i], &hash)) continue;
    if (hash == 0) continue;
    paragraph->push_back(static_cast<uint64>(hash));
  }
  return true;
}

// not uesed by leaf
uint64 NewsIndex::GetWholeContentHashByItemId(uint64 item_id) const {
 return 0;
}

bool NewsIndex::GetHasReviewedByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(item_has_reviewed);
  return INT_VALUE!=0;
}

CategoryListPtr NewsIndex::GetCategories(int level){
  CategoryListPtr cats = empty_cat_ptr_;
  int key = level;

  LOG(INFO) << "GetChannelAndCategoryFromProxy start..key=" << key ;
  if (!enable_index_cache_){
    if(!GetChannelAndCategoryFromProxy()) {
      LOG(ERROR) << "GetChannelAndCategoryFromProxy, error, key=" << key ;
      return cats;
    }
  }

  if (!category_cache_->FindSilently(level, &cats)) {
    if(!GetChannelAndCategoryFromProxy()) {
      LOG(ERROR) << "GetChannelAndCategoryFromProxy fail, key=" << key;
      return cats;
    } 
    LOG(INFO) << "GetChannelAndCategoryFromProxy end..key=" << key ;

    if (!category_cache_->FindSilently(level, &cats)) {
      LOG(INFO) << "not hit category cache after search, key=" << key ;
    }
  }

  return cats;
}

bool NewsIndex::GetCategoriesByItemId(uint64 item_id, std::vector<reco::Category>* categories) const {
  std::vector<std::string> str_categories;
  if (!GetCategoriesByItemId(item_id, &str_categories))
    return false;

  categories->resize(str_categories.size());
  for (int i = 0; i < (int)str_categories.size(); ++i) {
    ConvertToCategoryProto(str_categories, i, &(categories->at(i)));
  }
  return true;
}

bool NewsIndex::GetCategoriesByItemInfoFull(const ItemInfoFullPtr& p, std::vector<reco::Category>* categories) const {
  std::vector<std::string> str_categories;
  const std::string& category_attr = p->category();
  if(!ParseCategories(p->item_id(), category_attr, &str_categories)) {
    return false;
  }

  categories->resize(str_categories.size());
  for (int i = 0; i < (int)str_categories.size(); ++i) {
    ConvertToCategoryProto(str_categories, i, &(categories->at(i)));
  }
  return true;
}

bool NewsIndex::ParseCategories(uint64 item_id, const std::string& cat_str , std::vector<std::string>* categories) const {
  categories->clear();
  if (! cat_str.empty()) {
    base::SplitString(cat_str, "\t", categories);
    return true;
  } else {
//    LOG(ERROR) << "index empty catogery, item_id=" << item_id;
  }

  auto itemid_category_map = DM_GET_DICT(reco::dm::ItemCategoryDict, reco::IndexDynamicDictContainer::kItemCategoryFile_);
  auto i = itemid_category_map->find(item_id);
  if (i != itemid_category_map->end()) {
    (*categories) = i->second;
    return true;
  } 

//  LOG(ERROR) << "map empty catogery, item_id=" << item_id;
  return false;
}

bool NewsIndex::GetCategoriesByItemId(uint64 item_id, std::vector<std::string>* categories) const {
  GET_STRING_INDEX_ATTR(category);
  return ParseCategories(item_id, STRING_VALUE, categories);
}

bool NewsIndex::GetMultiCategoriesByItemId(uint64 item_id, MultiCategory* multi_category) const {
  GET_STRING_INDEX_ATTR(category_candidates);
  if (STRING_VALUE.empty()) return false;

  std::string decode_str;
  if (!reco::common::DecodeUrlComponent(STRING_VALUE.c_str(), &decode_str)) {
    LOG(ERROR) << "decode fail: item_id=" << item_id;
    return false;
  }

  return multi_category->ParseFromString(decode_str);
}

bool NewsIndex::GetCategoryScore(uint64 item_id, const reco::Category& category, float* score) const {
  return GetCategoryScore(item_id, category.category(), score);
}

bool NewsIndex::GetCategoryScore(uint64 item_id, const std::string& category, float* score) const {
  int status = multi_category_cache_->Find(item_id, category, score);
  if (status == 0) {
    return false;
  } else if (status == 1) {
    return true;
  }

  MultiCategory multi_category;
  GetMultiCategoriesByItemId(item_id, &multi_category);
  multi_category_cache_->Add(item_id, multi_category);

  status = multi_category_cache_->Find(item_id, category, score);
  if (status == -1) {
    LOG(INFO) << "cannot find item: " << item_id;
  }

  return status == 1;
}

bool NewsIndex::GetSourceByItemId(uint64 item_id, std::string* source) const {
  GET_SIMPLE_INDEX_ATTR(source);
}

bool NewsIndex::GetOrigMediaRiskTypeByItemId(uint64 item_id, int32* orig_media_risk_type) const {
  GET_SIMPLE_INDEX_ATTR(orig_media_risk_type);
}

bool NewsIndex::GetProducerByItemId(uint64 item_id, std::string* app_token) const {
  GET_SIMPLE_INDEX_ATTR(app_token);
}

int32 NewsIndex::GetJingpinScoreByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(jingpin_score);
  return static_cast<int32>(INT_VALUE);
}

bool NewsIndex::GetOrigSourceByItemId(uint64 item_id, std::string* orig_source) const {
  GET_SIMPLE_INDEX_ATTR(orig_source);
}

bool NewsIndex::GetShowSourceByItemId(uint64 item_id, std::string* show_source) const {
  show_source->clear();
  std::string source;
  if (!GetSourceByItemId(item_id, &source)) {
    return false;
  }

  auto dict = DM_GET_DICT(reco::dm::SourceInfoDict, reco::IndexDynamicDictContainer::kSourceInfoFile_);
  *show_source = dict->GetShowSource(source);
  return true;
}

bool NewsIndex::GetShowSourceByItemPtr(const ItemInfoFull* ptr, std::string* show_source) const {
  show_source->clear();
  if (ptr->source().empty()) {
    return false;
  }

  auto dict = DM_GET_DICT(reco::dm::SourceInfoDict, reco::IndexDynamicDictContainer::kSourceInfoFile_);
  *show_source = dict->GetShowSource(ptr->source());
  return true;
}

bool NewsIndex::GetFilterChainByItemId(uint64 item_id, RuleChain* filter_chain) const {
  std::string source;
  if (!GetSourceByItemId(item_id, &source)) {
    return false;
  }
  auto dict = DM_GET_DICT(reco::dm::SourceInfoDict, reco::IndexDynamicDictContainer::kSourceInfoFile_);
  if (!dict->GetSourceRuleChain(source, filter_chain)) {
    return false;
  }
  return true;
}

bool NewsIndex::GetSourceMediaByItemId(uint64 item_id, std::string* source_media) const {
  GET_STRING_INDEX_ATTR(source_media);
  if (STRING_VALUE.empty()) return false;
  *source_media = STRING_VALUE;
  return true;
}

bool NewsIndex::GetOrigSourceMediaByItemId(uint64 item_id, std::string* orig_source_media) const {
  GET_STRING_INDEX_ATTR(orig_source_media);
  if (STRING_VALUE.empty()) return false;
  *orig_source_media = STRING_VALUE;
  return true;
}

int NewsIndex::GetPriority(uint64 item_id, const std::string& time, int64 channel_id) const {
  const int kDefaultPriority = 0;
  GET_STRING_INDEX_ATTR(priority);
  if (STRING_VALUE.empty()) return false;

  std::vector<std::string> flds;
  base::SplitString(STRING_VALUE, "\n", &flds);
  int64 id;
  int priority;
  std::vector<std::string> cols;
  for (int i = 0; i < (int)flds.size(); ++i) {
    cols.clear();
    base::SplitString(flds[i], "\t", &cols);
    if (cols.size() != 4
        || !base::StringToInt64(cols[1], &id)
        || !base::StringToInt(cols[0], &priority)) {
      LOG(ERROR) << "priority format error, " << flds[i];
      continue;
    }
    if (channel_id == id) {
      if (cols[2] <= time && time <= cols[3]) {
        return priority;
      } else {
        break;
      }
    }
  }

  return kDefaultPriority;
}

bool NewsIndex::GetUCBSettingByItemId(uint64 item_id, UcBrowserDeliverSettingPtr* ucb_setting) {
  if (item_ucbsetting_expiry_map_->FindSilently(item_id, ucb_setting)) {
    return true;
  }

  GET_STRING_INDEX_ATTR(ucbr_deliver);
  if (STRING_VALUE.empty()) return false;
  std::string decode_str;
  if (!reco::common::DecodeUrlComponent(STRING_VALUE.c_str(), &decode_str)) {
    LOG(ERROR) << "decode fail: item_id=" << item_id;
    return false;
  }

  UcBrowserDeliverSettingPtr ucb_setting_ptr(new UcBrowserDeliverSetting());
  if (!ucb_setting_ptr->ParseFromString(decode_str)) return false;

  item_ucbsetting_expiry_map_->Add(item_id, ucb_setting_ptr);

  if (item_ucbsetting_expiry_map_->FindSilently(item_id, ucb_setting)) {
    return true;
  }

  return false;
}

bool NewsIndex::GetItemQualityAttrByItemId(uint64 item_id, ItemQualityAttr* quality_attr) {
  if (item_quality_expiry_map_->FindSilently(item_id, quality_attr)) {
    return true;
  }

  GET_STRING_INDEX_ATTR(item_quality_attr);
  if (STRING_VALUE.empty()) return false;

  std::string decode_str;
  if (!reco::common::DecodeUrlComponent(STRING_VALUE.c_str(), &decode_str)) {
    LOG(ERROR) << "decode fail: item_id=" << item_id;
    return false;
  }

  if (!quality_attr->ParseFromString(decode_str)) return false;

  item_quality_expiry_map_->Add(item_id, *quality_attr);
  return true;
}

bool NewsIndex::GetTitleCoreTagsByItemId(uint64 item_id, std::vector<std::string>* core_tags) {
  core_tags->clear();
  if (item_title_core_tags_expiry_map_->FindSilently(item_id, core_tags)) {
    return !core_tags->empty();
  }

  // 下面开始不能提前 return
  std::vector<std::string> show_tags;
  if (GetShowTagByItemId(item_id, &show_tags) && !show_tags.empty()) {
    std::string title;
    if (GetItemTitleByItemId(item_id, &title)) {
      for (size_t i = 0; i < show_tags.size(); ++i) {
        if (title.find(show_tags[i]) != std::string::npos) {
          // show tags 已经按照重要性排序了
          core_tags->push_back(show_tags[i]);
        }    
      }    
    }    
  }

  // core_tag 为空也必须缓存
  item_title_core_tags_expiry_map_->Add(item_id, *core_tags);
  return !core_tags->empty();
}

int32 NewsIndex::GetPosteriorItemQByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(posterior_item_q);
  return static_cast<int32>(INT_VALUE);
}

int32 NewsIndex::GetUCBStyleTypeByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(ucbr_style_type);
  return static_cast<int32>(INT_VALUE);
}

std::string NewsIndex::GetUCBEditorNameByItemId(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(ucb_editor_name);
  return STRING_VALUE;
}

std::string NewsIndex::GetKeywordLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(keyword_list);
  return STRING_VALUE;
}

std::string NewsIndex::GetKeywordFeatureLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(keyword_feature_list);
  return STRING_VALUE;
}

float NewsIndex::GetKeywordNorm(uint64 item_id) const {
  GET_FLOAT_INDEX_ATTR(keyword_norm);
  return FLOAT_VALUE;
}

std::string NewsIndex::GetTopicLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(topic_list);
  return STRING_VALUE;
}

std::string NewsIndex::GetTopicFeatureLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(topic_feature_list);
  return STRING_VALUE;
}

float NewsIndex::GetTopicNorm(uint64 item_id) const {
  GET_FLOAT_INDEX_ATTR(topic_norm);
  return FLOAT_VALUE;
}

std::string NewsIndex::GetPlsaTopicLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(plsa_topic_list);
  return STRING_VALUE;
}

std::string NewsIndex::GetPlsaTopicFeatureLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(plsa_topic_feature_list);
  return STRING_VALUE;
}

float NewsIndex::GetPlsaTopicNorm(uint64 item_id) const {
  GET_FLOAT_INDEX_ATTR(plsa_topic_norm);
  return FLOAT_VALUE;
}

std::string NewsIndex::GetTitleLdaTopicLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(title_lda_topic_list);
  return STRING_VALUE;
}

std::string NewsIndex::GetTitleLdaTopicFeatureLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(title_lda_topic_feature_list);
  return STRING_VALUE;
}

float NewsIndex::GetTitleLdaTopicNorm(uint64 item_id) const {
  GET_FLOAT_INDEX_ATTR(title_lda_topic_norm);
  return FLOAT_VALUE;
}

std::string NewsIndex::GetWordVecLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(wordvec_list);
  return STRING_VALUE;
}

std::string NewsIndex::GetWordVecFeatureLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(wordvec_feature_list);
  return STRING_VALUE;
}

float NewsIndex::GetWordVecNorm(uint64 item_id) const {
  GET_FLOAT_INDEX_ATTR(wordvec_norm);
  return FLOAT_VALUE;
}

std::string NewsIndex::GetTagLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(tag_list);
  return STRING_VALUE;
}

std::string NewsIndex::GetTagFeatureLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(tag_feature_list);
  return STRING_VALUE;
}

float NewsIndex::GetTagNorm(uint64 item_id) const {
  GET_FLOAT_INDEX_ATTR(tag_norm);
  return FLOAT_VALUE;
}

std::string NewsIndex::GetSemanticTagLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(semantic_tag_list);
  return STRING_VALUE;
}

std::string NewsIndex::GetSemanticTagFeatureLists(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(semantic_tag_feature_list);
  return STRING_VALUE;
}

float NewsIndex::GetSemanticTagNorm(uint64 item_id) const {
  GET_FLOAT_INDEX_ATTR(semantic_tag_norm);
  return FLOAT_VALUE;
}

bool NewsIndex::GetFeatureMapByItemId(uint64 item_id, reco::common::FeatureType type,
  std::map<std::string, double>* feature,
  double* norm2) const {
  std::string keys;
  std::string vals;
  float norm = 0;

  switch (type) {
  case reco::common::kKeyword:
    keys = GetKeywordLists(item_id);
    vals = GetKeywordFeatureLists(item_id);
    norm = GetKeywordNorm(item_id);
    break;
  case reco::common::kTopic:
    keys = GetTopicLists(item_id);
    vals = GetTopicFeatureLists(item_id);
    norm = GetTopicNorm(item_id);
    break;
  case reco::common::kPlsaTopic:
    keys = GetPlsaTopicLists(item_id);
    vals = GetPlsaTopicFeatureLists(item_id);
    norm = GetPlsaTopicNorm(item_id);
    break;
  case reco::common::kTitleLdaTopic:
    keys = GetTitleLdaTopicLists(item_id);
    vals = GetTitleLdaTopicFeatureLists(item_id);
    norm = GetTitleLdaTopicNorm(item_id);
    break;
  case reco::common::kWordvec:
    keys = GetWordVecLists(item_id);
    vals = GetWordVecFeatureLists(item_id);
    norm = GetWordVecNorm(item_id);
    break;
  case reco::common::kTag:
    keys = GetTagLists(item_id);
    vals = GetTagFeatureLists(item_id);
    norm = GetTagNorm(item_id);
    break;
  case reco::common::kSemanticTag:
    keys = GetSemanticTagLists(item_id);
    vals = GetSemanticTagFeatureLists(item_id);
    norm = GetSemanticTagNorm(item_id);
    break;
  default:
    LOG(ERROR) << "invalid feature type: " << type;
    return false;
  }

  if (keys == "") {
    return false;
  }

  if (vals == "") {
    LOG(ERROR) << "err feature: vals empty, item_id=" << item_id;
    return false;
  }

  if (norm < 1e-7) {
    LOG(ERROR) << "err feature: norm zero, item_id=" << item_id;
    return false;
  }

  std::vector<std::string> key_list;
  std::vector<std::string> val_str_list;
  base::SplitString(keys, "\t", &key_list);
  base::SplitString(vals, "\t", &val_str_list);
  feature->clear();
  for (int i = 0; i < (int)key_list.size(); ++i) {
    const std::string& key = key_list[i];
    double weight = 0.0;
    if (!base::StringToDouble(val_str_list[i], &weight)) {
      LOG(ERROR) << "err feature: " << val_str_list[i];
      return false;
    }

    feature->insert(std::make_pair(key, static_cast<float>(weight)));
  }
  *norm2 = norm;
  return true;
}

bool NewsIndex::GetFeatureVectorByItemId(uint64 item_id, reco::common::FeatureType type,
  reco::FeatureVector* feature) const {
  std::string cache_key = base::StringPrintf("%lu_%d", item_id, type);
  if (item_fea_expiry_map_->FindSilently(cache_key, feature)) {
    return true;
  }

  std::string keys;
  std::string vals;
  float norm = 0;

  switch (type) {
  case reco::common::kKeyword:
    keys = GetKeywordLists(item_id);
    vals = GetKeywordFeatureLists(item_id);
    norm = GetKeywordNorm(item_id);
    break;
  case reco::common::kTopic:
    keys = GetTopicLists(item_id);
    vals = GetTopicFeatureLists(item_id);
    norm = GetTopicNorm(item_id);
    break;
  case reco::common::kPlsaTopic:
    keys = GetPlsaTopicLists(item_id);
    vals = GetPlsaTopicFeatureLists(item_id);
    norm = GetPlsaTopicNorm(item_id);
    break;
  case reco::common::kTitleLdaTopic:
    keys = GetTitleLdaTopicLists(item_id);
    vals = GetTitleLdaTopicFeatureLists(item_id);
    norm = GetTitleLdaTopicNorm(item_id);
    break;
  case reco::common::kWordvec:
    keys = GetWordVecLists(item_id);
    vals = GetWordVecFeatureLists(item_id);
    norm = GetWordVecNorm(item_id);
    break;
  case reco::common::kTag:
    keys = GetTagLists(item_id);
    vals = GetTagFeatureLists(item_id);
    norm = GetTagNorm(item_id);
    break;
  case reco::common::kSemanticTag:
    keys = GetSemanticTagLists(item_id);
    vals = GetSemanticTagFeatureLists(item_id);
    norm = GetSemanticTagNorm(item_id);
    break;
  default:
    LOG(ERROR) << "invalid feature type: " << type;
    return false;
  }

  if (keys == "") {
    return false;
  }

  if (vals == "") {
    LOG(ERROR) << "err feature: vals empty, item_id=" << item_id;
    return false;
  }

  if (norm < 1e-7) {
    LOG(ERROR) << "err feature: norm zero, item_id=" << item_id;
    return false;
  }

  std::vector<std::string> key_list;
  std::vector<std::string> val_str_list;
  base::SplitString(keys, "\t", &key_list);
  base::SplitString(vals, "\t", &val_str_list);
  feature->Clear();

  reco::ItemType item_type;
  if(!GetItemTypeByItemId(item_id, &item_type)) {
    LOG(ERROR) << "GetItemTypeByItemId error";
    return false;
  }

  if (item_type >= reco::kNone) {
    LOG(INFO) << "resert itemtype, old=" << item_type << " item_id=" << item_id;
    item_type = reco::kNews;
  }

  for (int i = 0; i < (int)key_list.size(); ++i) {
    const std::string& key = key_list[i];
    double weight = 0.0;
    if (!base::StringToDouble(val_str_list[i], &weight)) {
      LOG(ERROR) << "err feature: " << val_str_list[i] << " item_id=" << item_id;
      return false;
    }

    auto fea = feature->add_feature();
    fea->set_item_type(item_type);
    fea->set_weight(static_cast<float>(weight));
    fea->set_literal(key);
  }

  feature->set_norm(norm);
  item_fea_expiry_map_->Add(cache_key, *feature);
  return true;
}

bool NewsIndex::GetFeatureVectorByItemInfoFull(const ItemInfoFullPtr& p, reco::common::FeatureType type, reco::FeatureVector* feature) const {
  auto item_id = p->item_id();
  std::string cache_key = base::StringPrintf("%lu_%d", item_id, type);
  if (item_fea_expiry_map_->FindSilently(cache_key, feature)) {
    return true;
  }

  std::string keys;
  std::string vals;
  float norm = 0;

  switch (type) {
  case reco::common::kKeyword:
    keys = p->keyword_list(); 
    vals = p->keyword_feature_list();
    norm = p->keyword_norm();
    break;
  case reco::common::kTopic:
    keys = p->topic_list();
    vals = p->topic_feature_list();
    norm = p->topic_norm();
    break;
  case reco::common::kPlsaTopic:
    keys = p->plsa_topic_list();
    vals = p->plsa_topic_feature_list();
    norm = p->plsa_topic_norm();
    break;
  case reco::common::kTitleLdaTopic:
    keys = p->title_lda_topic_list();
    vals = p->title_lda_topic_feature_list();
    norm = p->title_lda_topic_norm();
    break;
  case reco::common::kWordvec:
    keys = p->wordvec_list();
    vals = p->wordvec_feature_list();
    norm = p->wordvec_norm();
    break;
  case reco::common::kTag:
    keys = p->tag_list();
    vals = p->tag_feature_list();
    norm = p->tag_norm();
    break;
  case reco::common::kSemanticTag:
    keys = p->semantic_tag_list();
    vals = p->semantic_tag_feature_list();
    norm = p->semantic_tag_norm();
    break;
  default:
    LOG(ERROR) << "invalid feature type: " << type;
    return false;
  }

  if (keys == "") {
    return false;
  }

  if (vals == "") {
    LOG(ERROR) << "err feature: vals empty, item_id=" << item_id;
    return false;
  }

  if (norm < 1e-7) {
    LOG(ERROR) << "err feature: norm zero, item_id=" << item_id;
    return false;
  }

  std::vector<std::string> key_list;
  std::vector<std::string> val_str_list;
  base::SplitString(keys, "\t", &key_list);
  base::SplitString(vals, "\t", &val_str_list);
  feature->Clear();

  reco::ItemType item_type = static_cast<reco::ItemType>(p->item_type());

  if (item_type >= reco::kNone) {
    LOG(INFO) << "resert itemtype, old=" << item_type << " item_id=" << item_id;
    item_type = reco::kNews;
  }

  for (int i = 0; i < (int)key_list.size(); ++i) {
    const std::string& key = key_list[i];
    double weight = 0.0;
    if (!base::StringToDouble(val_str_list[i], &weight)) {
      LOG(ERROR) << "err feature: " << val_str_list[i] << " item_id=" << item_id;
      return false;
    }

    auto fea = feature->add_feature();
    fea->set_item_type(item_type);
    fea->set_weight(static_cast<float>(weight));
    fea->set_literal(key);
  }

  feature->set_norm(norm);
  
  item_fea_expiry_map_->Add(cache_key, *feature);
  return true;
}


bool NewsIndex::IsValidByItemId(uint64 item_id) const {
  uint32 docmask = GetDocMaskByItemId(item_id);
  if (docmask & DocMaskInvalid) {
    return false;
  }

  if (docmask & reco::common::kDocFilterServer) {
    return false;
  }

  return true;
}

bool NewsIndex::IsValidByItemPtr(const ItemInfoFull* p) const {
  uint32 docmask = p->docmask(); 
  if (docmask & DocMaskInvalid) {
    return false;
  }

  if (docmask & reco::common::kDocFilterServer) {
    return false;
  }

  return true;
}

bool NewsIndex::IsExpiredByItemId(uint64 item_id, int64 now_timestamp) const {
  return now_timestamp >= GetExpireTimestampByItemId(item_id);
}

bool NewsIndex::IsExpiredByItemPtr(const ItemInfoFull* p, int64 now_timestamp) const {
  int64 tmp_ts = 0;
  if (!(p->docmask() & reco::common::kDocMaskTimeWhiteList)) {
    tmp_ts = kTimestampInFuture;
  } else {
    tmp_ts = p->expire_timestamp();
  }

  return now_timestamp >= tmp_ts;
}

bool IsValidInAppByDocMask(uint32 docmask, reco::common::AppNames app) {
  switch (app) {
    case reco::common::kUcToutiao:
      return !(docmask & reco::common::kDocMaskAppToutiao);
    case reco::common::kHuawei:
      return !(docmask & reco::common::kDocMaskAppHuawei);
    case reco::common::kSamsung:
      return !(docmask & reco::common::kDocMaskAppSamsung);
    case reco::common::kMeizu:
      return !(docmask & reco::common::kDocMaskAppMeizu);
    case reco::common::kTuDouIflow:
    case reco::common::kTuDouPCIflow:
      return !(docmask & reco::common::kDocMaskAppTuDouIflow);
    case reco::common::kYouKuIflow:
      return ((!(docmask & reco::common::kDocMaskAppTuDouIflow)) && (!(docmask & reco::common::kDocMaskAppYoukuIflow)));
    default:
      return true;
  }
}

bool NewsIndex::IsValidInAppByItemId(uint64 item_id, reco::common::AppNames app) const {
  uint32 docmask = GetDocMaskByItemId(item_id);
  return IsValidInAppByDocMask(docmask, app);
}

bool NewsIndex::IsValidInApp(const ItemInfoFullPtr& p, reco::common::AppNames app) const {
  uint32 docmask = p->docmask();
  return IsValidInAppByDocMask(docmask, app);
}

bool NewsIndex::GetChannelsByItemId(uint64 item_id, std::vector<int64>* channel_ids) const {
  channel_ids->clear();
  GET_STRING_INDEX_ATTR(channel);
  if (STRING_VALUE.empty()) return false;

  std::vector<std::string> flds;
  base::SplitString(STRING_VALUE, "\t", &flds);
  int64 id;
  for (int i = 0; i < (int)flds.size(); ++i) {
    if (!base::StringToInt64(flds[i], &id)) {
      LOG(ERROR) << "err channel id: " << flds[i];
      continue;
    }
    channel_ids->push_back(id);
  }
  return !channel_ids->empty();
}

bool NewsIndex::GetRegionIdByItemId(uint64 item_id, std::vector<int64>* region_ids) const {
  region_ids->clear();
  GET_STRING_INDEX_ATTR(region);
  if (STRING_VALUE.empty()) return false;

  std::vector<std::string> fields;
  base::SplitString(STRING_VALUE, ";", &fields);
  int64 region_id;
  for (size_t i = 0; i < fields.size(); ++i) {
    if (base::StringToInt64(fields[i], &region_id)) {
      region_ids->push_back(region_id);
    }
  }
  return true;
}

bool NewsIndex::GetRestrictRegionIdByItemId(uint64 item_id, std::vector<int64> *restrict_region_ids) const {
  restrict_region_ids->clear();
  GET_STRING_INDEX_ATTR(region_restrict);
  if (STRING_VALUE.empty()) return false;

  std::vector<std::string> fields;
  base::SplitString(STRING_VALUE, ";", &fields);
  int64 region_id;
  for (size_t i = 0; i < fields.size(); ++i) {
    if (base::StringToInt64(fields[i], &region_id)) {
      restrict_region_ids->push_back(region_id);
    }
  }
  return true;
}

bool NewsIndex::GetTitleRegionIdByItemId(uint64 item_id, std::vector<int64>* region_ids) const {
  region_ids->clear();
  GET_STRING_INDEX_ATTR(region_from_title);
  if (STRING_VALUE.empty()) return false;

  std::vector<std::string> fields;
  base::SplitString(STRING_VALUE, ";", &fields);
  int64 region_id;
  for (size_t i = 0; i < fields.size(); ++i) {
    if (base::StringToInt64(fields[i], &region_id)) {
      region_ids->push_back(region_id);
    }
  }
  return true;
}

bool NewsIndex::GetSubscriptsByItemId(uint64 item_id, ItemSubscipts *subscripts) const {
  GET_STRING_INDEX_ATTR(item_subscripts);
  if (STRING_VALUE.empty()) return false;
  std::string decode_str;
  if (!reco::common::DecodeUrlComponent(STRING_VALUE.c_str(), &decode_str)) {
    LOG(ERROR) << "decode fail: item_id=" << item_id;
    return false;
  }

  return subscripts->ParseFromString(decode_str);
}

bool NewsIndex::GetShowTagByItemId(uint64 item_id, std::vector<std::string> *show_tags) const {
  show_tags->clear();
  GET_STRING_INDEX_ATTR(item_show_tag);
  if (STRING_VALUE.empty()) return false;
  base::SplitString(STRING_VALUE, "|", show_tags);
  return true;
}

void NewsIndex::ConvertToCategoryProto(const std::vector<std::string>& categories, int level,
  reco::Category* category) const {
  category->Clear();
  if (level >= (int)categories.size() || level < 0) {
    LOG(ERROR) << "error level: " << level;
    return;
  }
  category->set_level(level);
  category->set_category(categories[level]);
  for (int i = 0; i < level; ++i) {
    category->add_parents(categories[i]);
  }
}

bool NewsIndex::GetWeMediaPersonByItemId(uint64 item_id, std::string* wemedia_person) const {
  GET_STRING_INDEX_ATTR(wemedia_person);
  *wemedia_person = STRING_VALUE;
  if (wemedia_person->empty()) return false;
  return true;
}

// not used by leaf 
std::vector<reco::index_data::SourceInfo> NewsIndex::SearchWemediaAuthor(const std::string& query,
  bool filter_unpub) const {
  std::vector<reco::index_data::SourceInfo> res;
  return res;
}

bool NewsIndex::GetContentAttrByItemId(uint64 item_id, ContentAttr* content_attr_res, bool* is_trival) const {
  GET_INT_INDEX_ATTR(content_attr);
  reco::common::UnPackContentAttr(static_cast<uint64>(INT_VALUE), content_attr_res);
  *is_trival = (INT_VALUE == 0);
  return true;
}

bool NewsIndex::GetContentAttr(const ItemInfoFull* p, ContentAttr* content_attr_res, bool* is_trival) const {
  *is_trival = (p->content_attr() == 0);
  reco::common::UnPackContentAttr(static_cast<uint64>(p->content_attr()), content_attr_res);
  return true;
}

bool NewsIndex::GetGaoDePOIByItemId(uint64 item_id, GaoDePOI* gaode_poi) const {
  GET_STRING_INDEX_ATTR(gaode_poi);
  if (STRING_VALUE.empty()) return false;
  std::string decode_str;
  if (!reco::common::DecodeUrlComponent(STRING_VALUE.c_str(), &decode_str)) {
    LOG(ERROR) << "decode fail: item_id=" << item_id;
    return false;
  }

  return gaode_poi->ParseFromString(decode_str);
}

bool NewsIndex::GetTimeAxisResultsByItemId(uint64 item_id, time_axis::TimeAxisResults *time_axis_results) const {
  GET_STRING_INDEX_ATTR(time_axis_results);
  if (STRING_VALUE.empty()) return false;
  std::string decode_str;
  if (!reco::common::DecodeUrlComponent(STRING_VALUE.c_str(), &decode_str)) {
    LOG(ERROR) << "decode fail: item_id=" << item_id;
    return false;
  }

  return time_axis_results->ParseFromString(decode_str);
}

// not used by leaf 
bool NewsIndex::ContainInCategoryQueue(const reco::Category& category, uint64 item_id) const {
  return false;
}

// not used by leaf
bool NewsIndex::GetVideoStatInfoByItemId(uint64 item_id, VideoStatInfo* info) const {
  return false;
}

bool NewsIndex::GetItemTimeAxisInfoByItemId(uint64 item_id, time_axis::TimeAxisInfo *timeaxis_info) const {
  ItemInfoFullPtr p;
  serving_base::Timer timer;
  timer.Start();

  VLOG(2) << "FUNC:" << __func__;
  COUNTERS_news_index__get_attr_count.Increase(1);
  if (item_map_->FindSilently(item_id, &p)) {
    timeaxis_info->CopyFrom(p->time_axis_info());
    COUNTERS_news_index__get_attr_time.Increase(timer.Stop());
    return true;
  } else {
    LOG(ERROR) << "attr not find, item_id=" << item_id << " attr=time_axis_info" ;
    COUNTERS_news_index__get_attr_err_count.Increase(1);
    COUNTERS_news_index__get_attr_time.Increase(timer.Stop());
  }
  return false;
}

bool NewsIndex::GetVideoTagFeatureVectorByItemId(uint64 item_id, reco::FeatureVector* feature) const {
  reco::FeatureVector raw_feature;
  if (!GetFeatureVectorByItemId(item_id, reco::common::kTag, &raw_feature)) {
    return false;
  }
  ParseVideoTagFeatureVector(item_id, raw_feature, feature);
  return true;
}

void NewsIndex::ParseVideoTagFeatureVector(uint64 item_id,
                                           const reco::FeatureVector& raw_feature,
                                           reco::FeatureVector *real_feature) const {
  real_feature->Clear();
  bool manual_checked = false;
  for (int i = 0; i < raw_feature.feature_size(); ++i) {
    const std::string &raw_tag = raw_feature.feature(i).literal();
    std::vector<std::string> tokens;
    base::SplitString(raw_tag, ":", &tokens);
    if (tokens.size() > 1 && tokens[0] == "manual") {
      manual_checked = true;
      break;
    }
  }
  for (int i = 0; i < raw_feature.feature_size(); ++i) {
    const std::string &raw_tag = raw_feature.feature(i).literal();
    std::vector<std::string> tokens;
    base::SplitString(raw_tag, ":", &tokens);
    std::string real_tag = "";
    if (tokens.size() <= 1) {
      // 没有前缀的直接认为是正确的 tag
      real_tag = tokens[0];
    } else if (!manual_checked && (tokens[0] == "label" || tokens[0] == "manual")) {
      real_tag = tokens[1];
    } else if (manual_checked && tokens[0] == "manual") {
      real_tag = tokens[1];
    }
    if (!real_tag.empty()) {
      auto fea = real_feature->add_feature();
      fea->CopyFrom(raw_feature.feature(i));
      fea->set_literal(real_tag);
    }
  }
}

LatestNewsPairPtr NewsIndex::GetLatestNewsByEventName(const std::string& event_name) {
  LatestNewsPairPtr ptr;
  std::string key = event_name;

  LOG(INFO) << "GetLatestNewsFromProxy start..key=" << key ;
  if (!enable_index_cache_){
    if(!GetLatestNewsFromProxy(key)) {
      LOG(ERROR) << "GetLatestNewsFromProxy, error, key=" << key ;
      return ptr;
    }
  }

  if (!latest_news_cache_->FindSilently(key, &ptr)) {
    if(!GetLatestNewsFromProxy(key)) {
      LOG(ERROR) << "GetLatestNewsFromProxy fail, key=" << key;
      return ptr;
    }
    LOG(INFO) << "GetLatestNewsFromProxy end..key=" << key ;

    if (!latest_news_cache_->FindSilently(key, &ptr)) {
      LOG(INFO) << "not hit latest news cache after search, key=" << key ;
    }
  }
  
  return ptr;
}

WeMediaItemsDictPtr NewsIndex::GetWeMediaItemsDict() {
  WeMediaItemsDictPtr ptr = empty_wemedia_dict_ptr_;
  std::string key = WE_MEDIA_ITEMS_KEY;
  LOG(INFO) << "GetWeMediaItemsFromProxy start";

  if (!enable_index_cache_){
    if(!GetWeMediaItemsFromProxy()) {
      LOG(ERROR) << "GetWeMediaItemsFromProxy, error, key=" << key ;
      return ptr;
    }
  }

  if (!wemedia_items_cache_->FindSilently(key, &ptr)) {
    if(!GetWeMediaItemsFromProxy()) {
      LOG(ERROR) << "GetWeMediaItemsFromProxy fail, key=" << key;
      return ptr;
    }
    LOG(INFO) << "GetWeMediaItemsFromProxy end";

    if (!wemedia_items_cache_->FindSilently(key, &ptr)) {
      LOG(INFO) << "not hit wemedia items cache after search, key=" << key ;
    }
  }
  
  return ptr;
}

SimiIdsSetPtr NewsIndex::GetSimItemIds(uint64 item_id) const{
  ItemInfoFullPtr p;
  if (item_map_->FindSilently(item_id, &p)) {
    return p->simi_ids();
  } else {
    return NULL;
  }
}

bool NewsIndex::HasCheckedBySimServer(uint64 item_id) const {
  ItemInfoFullPtr p;
  if (item_map_->FindSilently(item_id, &p)) {
    return p->sim_info().has_checked();
  } else {
    return false;
  }
}

uint64 NewsIndex::GetParentId(uint64 item_id) const {
  ItemInfoFullPtr p;
  if (item_map_->FindSilently(item_id, &p)) {
    return p->sim_info().parent_id();
  } else {
    return 0;
  }
}

bool NewsIndex::GetEventTagByItemId(uint64 item_id, std::vector<std::string> *event_tags) const {
  event_tags->clear();
  GET_STRING_INDEX_ATTR(ucb_editor_name);
  if (STRING_VALUE.empty()) return false;
  base::SplitString(STRING_VALUE, "|", event_tags);
  return (int)event_tags->size() > 0;
}

// todo later
bool NewsIndex::SearchQuery(const std::string& query, int start, int num, std::vector<ItemInfo>* item_list) const {
  return false;
}

// todo later
bool NewsIndex::SearchWords(const std::vector<std::string>& and_words, const std::vector<std::string>& or_words, const std::vector<std::string>& not_words,
    int start, int num, std::vector<ItemInfo>* item_list) const {
  return false;
}

void NewsIndex::FormatItemInfoHa3(const ItemInfoFull* full, std::string* outstr) const {
  std::ostringstream ofresult;
  const ItemInfoFull& item = *full;
  auto item_id = item.item_id();
  ofresult << "item_id=" << item_id << " keyword_norm=" << item.keyword_norm() << std::endl;
  ofresult << "item_id=" << item_id << " plsa_topic_norm=" << item.plsa_topic_norm() << std::endl;
  ofresult << "item_id=" << item_id << " semantic_tag_norm=" << item.semantic_tag_norm() << std::endl;
  ofresult << "item_id=" << item_id << " tag_norm=" << item.tag_norm() << std::endl;
  ofresult << "item_id=" << item_id << " topic_norm=" << item.topic_norm() << std::endl;
  ofresult << "item_id=" << item_id << " video_black_edge_ratio=" << item.video_black_edge_ratio() << std::endl;
  ofresult << "item_id=" << item_id << " wordvec_norm=" << item.wordvec_norm() << std::endl;
  ofresult << "item_id=" << item_id << " content_attr=" << item.content_attr() << std::endl;
  ofresult << "item_id=" << item_id << " content_length=" << item.content_length() << std::endl;
  ofresult << "item_id=" << item_id << " crawl_timestamp=" << item.crawl_timestamp() << std::endl;
  ofresult << "item_id=" << item_id << " create_timestamp=" << item.create_timestamp() << std::endl;
  ofresult << "item_id=" << item_id << " docmask=" << item.docmask() << std::endl;
  ofresult << "item_id=" << item_id << " expire_timestamp=" << item.expire_timestamp() << std::endl;
  ofresult << "item_id=" << item_id << " has_video_storage_info=" << item.has_video_storage_info() << std::endl;
  ofresult << "item_id=" << item_id << " image_count=" << item.image_count() << std::endl;
  ofresult << "item_id=" << item_id << " item_has_reviewed=" << item.item_has_reviewed() << std::endl;
  ofresult << "item_id=" << item_id << " item_is_yuanchuang=" << item.item_is_yuanchuang() << std::endl;
  ofresult << "item_id=" << item_id << " item_type=" << item.item_type() << std::endl;
  ofresult << "item_id=" << item_id << " jingpin_score=" << item.jingpin_score() << std::endl;
  ofresult << "item_id=" << item_id << " novel_update_time=" << item.novel_update_time() << std::endl;
  ofresult << "item_id=" << item_id << " paragraph_num=" << item.paragraph_num() << std::endl;
  ofresult << "item_id=" << item_id << " popularity=" << item.popularity() << std::endl;
  ofresult << "item_id=" << item_id << " posterior_item_q=" << item.posterior_item_q() << std::endl;
  ofresult << "item_id=" << item_id << " publish_time=" << item.publish_time() << std::endl;
  ofresult << "item_id=" << item_id << " title_length=" << item.title_length() << std::endl;
  ofresult << "item_id=" << item_id << " ucbr_style_type=" << item.ucbr_style_type() << std::endl;
  ofresult << "item_id=" << item_id << " video_count=" << item.video_count() << std::endl;
  ofresult << "item_id=" << item_id << " video_length=" << item.video_length() << std::endl;
  ofresult << "item_id=" << item_id << " video_quality_level=" << item.video_quality_level() << std::endl;
  ofresult << "item_id=" << item_id << " video_storage_info_status=" << item.video_storage_info_status() << std::endl;
  ofresult << "item_id=" << item_id << " video_vulgar_level=" << item.video_vulgar_level() << std::endl;
  ofresult << "item_id=" << item_id << " app_token=" << item.app_token() << std::endl;
  ofresult << "item_id=" << item_id << " image_hash=" << item.image_hash() << std::endl;
  ofresult << "item_id=" << item_id << " item_subscripts=" << item.item_subscripts() << std::endl;
  ofresult << "item_id=" << item_id << " keyword_feature_list=" << item.keyword_feature_list() << std::endl;
  ofresult << "item_id=" << item_id << " keyword_list=" << item.keyword_list() << std::endl;
  ofresult << "item_id=" << item_id << " novel_id=" << item.novel_id() << std::endl;
  ofresult << "item_id=" << item_id << " orig_source_media=" << item.orig_source_media() << std::endl;
  ofresult << "item_id=" << item_id << " orig_source=" << item.orig_source() << std::endl;
  ofresult << "item_id=" << item_id << " outer_id=" << item.outer_id() << std::endl;
  ofresult << "item_id=" << item_id << " paragraph_hash=" << item.paragraph_hash() << std::endl;
  ofresult << "item_id=" << item_id << " plsa_topic_feature_list=" << item.plsa_topic_feature_list() << std::endl;
  ofresult << "item_id=" << item_id << " plsa_topic_list=" << item.plsa_topic_list() << std::endl;
  ofresult << "item_id=" << item_id << " raw_summary=" << item.raw_summary() << std::endl;
  ofresult << "item_id=" << item_id << " region_from_title=" << item.region_from_title() << std::endl;
  ofresult << "item_id=" << item_id << " region_restrict=" << item.region_restrict() << std::endl;
  ofresult << "item_id=" << item_id << " region=" << item.region() << std::endl;
  ofresult << "item_id=" << item_id << " semantic_tag_feature_list=" << item.semantic_tag_feature_list() << std::endl;
  ofresult << "item_id=" << item_id << " semantic_tag_list=" << item.semantic_tag_list() << std::endl;
  ofresult << "item_id=" << item_id << " source_media=" << item.source_media() << std::endl;
  ofresult << "item_id=" << item_id << " source=" << item.source() << std::endl;
  ofresult << "item_id=" << item_id << " tag_feature_list=" << item.tag_feature_list() << std::endl;
  ofresult << "item_id=" << item_id << " tag_list=" << item.tag_list() << std::endl;
  ofresult << "item_id=" << item_id << " topic_feature_list=" << item.topic_feature_list() << std::endl;
  ofresult << "item_id=" << item_id << " topic_list=" << item.topic_list() << std::endl;
  ofresult << "item_id=" << item_id << " ucb_editor_name=" << item.ucb_editor_name() << std::endl;
  ofresult << "item_id=" << item_id << " wemedia_person=" << item.wemedia_person() << std::endl;
  ofresult << "item_id=" << item_id << " wordvec_feature_list=" << item.wordvec_feature_list() << std::endl;
  ofresult << "item_id=" << item_id << " wordvec_list=" << item.wordvec_list() << std::endl;
  ofresult << "item_id=" << item_id << " youku_video_id=" << item.youku_video_id() << std::endl;
  ofresult << "item_id=" << item_id << " priority=" << item.priority() << std::endl;
  ofresult << "item_id=" << item_id << " special_contain_item_list=" << item.special_contain_item_list() << std::endl;
  ofresult << "item_id=" << item_id << " special_prevew_item_list=" << item.special_prevew_item_list() << std::endl;
  ofresult << "item_id=" << item_id << " video_poster_problem_info=" << item.video_poster_problem_info() << std::endl;
  ofresult << "item_id=" << item_id << " category=" << item.category() << std::endl;
  ofresult << "item_id=" << item_id << " channel=" << item.channel() << std::endl;
  ofresult << "item_id=" << item_id << " item_event_tag=" << item.item_event_tag() << std::endl;
  ofresult << "item_id=" << item_id << " item_show_tag=" << item.item_show_tag() << std::endl;
  ofresult << "item_id=" << item_id << " gaode_poi=" << item.gaode_poi() << std::endl;
  ofresult << "item_id=" << item_id << " item_quality_attr=" << item.item_quality_attr() << std::endl;
  ofresult << "item_id=" << item_id << " time_axis_results=" << item.time_axis_results() << std::endl;
  ofresult << "item_id=" << item_id << " ucbr_deliver=" << item.ucbr_deliver() << std::endl;
  ofresult << "item_id=" << item_id << " category_candidates=" << item.category_candidates() << std::endl;
  ofresult << "item_id=" << item_id << " title=" << item.title() << std::endl;

  *outstr = ofresult.str();
}

void NewsIndex::FormatItemInfo(const ItemInfo* iteminfo, std::string* outstr) const {
  std::ostringstream ofresult;
  const ItemInfo& item = *iteminfo;
  auto item_id = item.item_id;
  ofresult << "item_id=" << item_id << " item_type=" << item.item_type<< std::endl;
  ofresult << "item_id=" << item_id << " site_level=" << item.site_level << std::endl;
  ofresult << "item_id=" << item_id << " time_level=" << item.time_level << std::endl;
  ofresult << "item_id=" << item_id << " hot_level=" << item.hot_level << std::endl;
  ofresult << "item_id=" << item_id << " sensitive_type=" << item.sensitive_type << std::endl;
  ofresult << "item_id=" << item_id << " itemq=" << item.itemq << std::endl;
  ofresult << "item_id=" << item_id << " spider_score=" << item.spider_score << std::endl;
  ofresult << "item_id=" << item_id << " show_num=" << item.show_num << std::endl;
  ofresult << "item_id=" << item_id << " click_num=" << item.click_num << std::endl;
  ofresult << "item_id=" << item_id << " duration=" << item.duration << std::endl;
  ofresult << "item_id=" << item_id << " new_itemq=" << item.new_itemq << std::endl;
  ofresult << "item_id=" << item_id << " new_pr=" << item.new_pr << std::endl;
  ofresult << "item_id=" << item_id << " ctr=" << item.ctr << std::endl;
  ofresult << "item_id=" << item_id << " duration_score=" << item.duration_score << std::endl;
  ofresult << "item_id=" << item_id << " category=" << item.category<< std::endl;
  ofresult << "item_id=" << item_id << " sub_category=" << item.sub_category<< std::endl;
  ofresult << "item_id=" << item_id << " create_timestamp=" << item.create_timestamp<< std::endl;
  ofresult << "item_id=" << item_id << " source_media_sign=" << item.source_media_sign<< std::endl;
  ofresult << "item_id=" << item_id << " orig_source_media_sign=" << item.orig_source_media_sign<< std::endl;
  ofresult << "item_id=" << item_id << " orig_media_risk_type=" << item.orig_media_risk_type<< std::endl;
  ofresult << "item_id=" << item_id << " is_source_wemedia=" << item.is_source_wemedia<< std::endl;
  ofresult << "item_id=" << item_id << " media_level=" << item.media_level<< std::endl;

  *outstr = ofresult.str();
}

bool NewsIndex::IsManualByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(manual_news);
  if (INT_VALUE > 0) {
     return true;
  }
  return false;
}

bool NewsIndex::GetEventTagInfoByItemId(uint64 item_id,
   std::vector<reco::EventTagInfo> *event_tags) const {
  event_tags->clear();
  GET_STRING_INDEX_ATTR(item_event_tag_info);
  if (STRING_VALUE.empty()) return false;

  std::vector<std::string> event_tag_vec;
  base::SplitString(STRING_VALUE, "|", &event_tag_vec);
  for (int i = 0; i < (int)event_tag_vec.size(); ++i) {
    std::string decode_str;
    if (!reco::common::DecodeUrlComponent(event_tag_vec[i].c_str(), &decode_str)) {
      LOG(ERROR) << "decode fail: item_id=" << item_id;
      continue;
    }
    reco::EventTagInfo eti;
    if (eti.ParseFromString(decode_str)) {
      event_tags->push_back(eti);
    }
  }
  return (int)event_tags->size() > 0;
}

int32 NewsIndex::GetOrgiItemQByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(posterior_item_q);
  return INT_VALUE;
}

bool NewsIndex::GetOrgiItemQByItemId(uint64 item_id, int32* orgi_itemq) const {
  GET_INT_INDEX_ATTR(posterior_item_q);
  if (INT_VALUE >= 0) {
    *orgi_itemq = INT_VALUE;
    return true;
  }
  return false;
}


bool NewsIndex::GetYoukuVideoIdByItemId(uint64 item_id, uint64* youku_video_id) const {
  GET_STRING_INDEX_ATTR(youku_video_id);
  if (STRING_VALUE.empty()) return false;
  return base::StringToUint64(STRING_VALUE, youku_video_id); 
}

bool NewsIndex::GetTitleLdaTopicByItemId(uint64 item_id, reco::FeatureVector* feature) const {
  if (!GetFeatureVectorByItemId(item_id, reco::common::kTitleLdaTopic, feature)) {
    return false;
  }
  return true;
}

bool NewsIndex::GetYoukuAuditStatusByItemId(uint64 item_id) const {
  GET_STRING_INDEX_ATTR(youku_audit_status);
  if (STRING_VALUE == "allowed") {
    return true;
  }
  return false;
}

bool NewsIndex::GetLocalBreakingByItemId(uint64 item_id, reco::LocalBreaking* local_breaking) const {
  GET_STRING_INDEX_ATTR(local_breaking);
  if (STRING_VALUE.empty()) return false;

  std::string decode_str;
  if (!reco::common::DecodeUrlComponent(STRING_VALUE.c_str(), &decode_str)) {
    LOG(ERROR) << "decode fail: item_id=" << item_id;
    return false;
  }

  if (!local_breaking->ParseFromString(decode_str)) return false;
  return true;
}

bool NewsIndex::ContainLocalBreakingByItemId(uint64 item_id) {
  ItemBreakingDictPtr p;
  if(GetItemBreakingDict(&p) && p) {
    return p->find(item_id) != p->end();
  } else {
    return false;
  }
}

bool NewsIndex::GetGroupInfoByItemId(uint64 item_id, ItemGroupInfo* group_info) const {
  GET_STRING_INDEX_ATTR(group_info);
  if (STRING_VALUE.empty()) return false;

  std::string decode_str;
  if (!reco::common::DecodeUrlComponent(STRING_VALUE.c_str(), &decode_str)) {
    LOG(ERROR) << "decode fail: item_id=" << item_id;
    return false;
  }

  if (!group_info->ParseFromString(decode_str)) return false;
  return true;
}

bool NewsIndex::GetItemBreakingDict(ItemBreakingDictPtr* ptr) {
  *ptr = empty_item_breaking_dict_ptr_;
  std::string key = ITEM_BREAKING_KEY;

  if (!enable_index_cache_){
    if(!GetItemBreakingFromProxy()) {
      LOG(ERROR) << "GetItemBreakingFromProxy, error, key=" << key ;
      return false;
    }
  }

  if (!item_breaking_cache_->FindSilently(key, ptr)) {
    if(!GetItemBreakingFromProxy()) {
      LOG(ERROR) << "GetItemBreakingFromProxy fail, key=" << key;
      return false;
    }

    if (!item_breaking_cache_->FindSilently(key, ptr)) {
      VLOG(1) << "not hit cache after search, key=" << key ;
      return false;
    }
  }
  
  return true;
}

int32 NewsIndex::GetAppTokenBitsByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(app_token_bits);
  return static_cast<int32>(INT_VALUE);
}

bool NewsIndex::GetAppTokenRuleBitsByItemId(uint64 item_id, std::string* rule_bits) const {
  GET_STRING_INDEX_ATTR(app_token_rule_bits);
  *rule_bits = STRING_VALUE;
  return !STRING_VALUE.empty();
}

int32 NewsIndex::GetFirstNScreenFilterByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(first_nscreen_filter);
  return static_cast<int32>(INT_VALUE);
}

int32 NewsIndex::GetVideoWidthByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(video_width);
  return static_cast<int32>(INT_VALUE);
}
int32 NewsIndex::GetVideoHeightByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(video_height);
  return static_cast<int32>(INT_VALUE);
}
int32 NewsIndex::GetVideoColorsByItemId(uint64 item_id) const {
  GET_INT_INDEX_ATTR(video_colors);
  return static_cast<int32>(INT_VALUE);
}
float NewsIndex::GetVideoPosterClarityItemId(uint64 item_id) const {
  GET_FLOAT_INDEX_ATTR(video_poster_clarity);
  return FLOAT_VALUE;
}
bool NewsIndex::IsVideoLargeCardItemId(uint64 item_id) const {
  std::set<std::string> problems;
  ItemInfoFullPtr p;
  serving_base::Timer timer;
  timer.Start();

  VLOG(2) << "FUNC:" << __func__;
  COUNTERS_news_index__get_attr_count.Increase(1);
  if (item_map_->FindSilently(item_id, &p)) {
    COUNTERS_news_index__get_attr_time.Increase(timer.Stop());
  } else {
    LOG(ERROR) << "attr not find, item_id=" << item_id << " attr=parent_id" ;
    COUNTERS_news_index__get_attr_err_count.Increase(1);
    COUNTERS_news_index__get_attr_time.Increase(timer.Stop());
    return false;
  }

  return (p->video_width() >= 448
          && p->video_height() >= 252
          && p->video_colors() >= 8
          && p->video_black_edge_ratio() < 0.18
          && p->video_width() > p->video_height()
          && (!GetVideoPosterProblemInfoByItemId(item_id, &problems)));
}
}
