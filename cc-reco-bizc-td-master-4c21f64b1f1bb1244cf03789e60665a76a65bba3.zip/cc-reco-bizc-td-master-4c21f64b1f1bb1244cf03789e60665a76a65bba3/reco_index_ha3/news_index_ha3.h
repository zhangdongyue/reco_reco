#pragma once

#include <string>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <set>
#include <map>
#include <memory>
#include "base/common/basic_types.h"
#include "base/thread/sync.h"
#include "base/thread/blocking_queue.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "reco/base/expiry_map/multi_expiry_map.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/index_presort_type.pb.h"
#include "reco/bizc/common/feature_type.h"
#include "reco/bizc/common/appname_define.h"
#include "reco/bizc/common/channel_define.h"
#include "reco/bizc/common/wrapped_category.h"
#include "reco/bizc/proto/index_aux_data.pb.h"
#include "reco/bizc/reco_index_ha3/filter_rule.h"
#include "reco/bizc/reco_index_ha3/presort_client.h"
#include "reco/bizc/reco_index_ha3/item_info.h"
#include "reco/bizc/reco_index_ha3/reco_query.h"
#include "reco/bizc/reco_index_ha3/dynamic_dict_container.h"
#include "reco/bizc/reco_index_ha3/dynamic_dict.h"
#include "reco/base/common/atomic.h"
#include "base/common/sleep.h"
#include "base/thread/thread_pool.h"
#include "reco/bizc/reco_index_ha3/multi_category_cache.h"
#include "serving_base/utility/timer.h"
#include "base/random/pseudo_random.h"
#include "reco/bizc/reco_index_ha3/media_quantity_assurance.h"
#include "reco/bizc/reco_index_ha3/extractor.h"
#include "reco/bizc/reco_index_ha3/stream_filter_sign_async_calc.h"
#include "reco/bizc/reco_index_ha3/wrapped_unordered_map.h"

namespace reco {
  class Category;
  class MultiCategory;
  struct ItemInfo;
  class UcBrowserDeliverSetting;
  class FeatureVector;
  class ItemSubscipts;
  class ContentAttr;
  class GaoDePOI;
  class VideoStatInfo;
  class VideoAttr;

  namespace time_axis{
    class TimeAxisResults;
    class TimeAxisInfo;
  }

  namespace dm {
    struct MediaQuantityInfo;
  }

  namespace filter {
    class StreamFilterSignAsyncCalc;
  }
  
  typedef std::shared_ptr<UcBrowserDeliverSetting> UcBrowserDeliverSettingPtr; 

  typedef std::vector<ItemInfoFullPtr> ItemInfoFullPtrList; 
  typedef std::shared_ptr<ItemInfoFullPtrList> ItemInfoFullPtrListPtr; 
  typedef std::vector<ItemInfo> ItemInfoList; 
  typedef std::shared_ptr<ItemInfoList> ItemInfoListPtr; 

  typedef std::vector<reco::Category> CategoryList; 
  typedef std::shared_ptr<CategoryList> CategoryListPtr; 

  typedef std::vector<int64> ChannelList; 
  typedef std::shared_ptr<ChannelList> ChannelListPtr; 

  typedef std::unordered_set<uint64> SimiIdsSet;
  //typedef std::shared_ptr<SimiIdsSet> SimiIdsSetPtr;
  typedef const std::set<uint64>* SimiIdsSetPtr;

  typedef std::vector<std::string> TermList; 
  typedef std::shared_ptr<TermList> TermListPtr; 

  typedef std::pair<uint64, time_axis::TimeAxisInfo> LatestNewsPair;
  typedef std::shared_ptr<LatestNewsPair> LatestNewsPairPtr;

  typedef std::unordered_map<std::string, std::unordered_set<uint64> >  WeMediaItemsDict;
  typedef std::shared_ptr<WeMediaItemsDict> WeMediaItemsDictPtr;

  typedef std::unordered_map<uint64, reco::LocalBreaking> ItemBreakingDict;
  typedef std::shared_ptr<ItemBreakingDict> ItemBreakingDictPtr;

  class NewsIndex;

  class IndexOptions {
  public:
    IndexOptions():result_num(50000), need_async_update(true), cache_expire_seconds(300),
    update_thread_num(2), update_interval_seconds(3), enable_index_cache(false),
    update_cache_query(true),
    cache_block_num(100), expire_thread_num(10),proxy_long_timeout_ms(100000), proxy_short_timeout_ms(20)
    {
    }

    int result_num;
    bool need_async_update;
    int cache_expire_seconds;
    int update_thread_num;
    int update_interval_seconds;
    bool enable_index_cache;
    bool update_cache_query;
    int cache_block_num;
    int expire_thread_num;
    int proxy_long_timeout_ms;
    int proxy_short_timeout_ms;
    std::string cache_query_filepath;
    std::string cache_item_id_filepath;
    PresortClientOptions presort_opt;
  };

  class SearchOpts {
    public:
      SearchOpts():timeout_ms(0), find_from_cache(true),
      allow_cut_off(true), allow_item_loss(true), need_build_list(true),
      need_store_list_cache(true), need_refresh(true) {}

      int timeout_ms;  // 查询超时, 如果分多次拉取数据，计算总的超时. 如果不设置，按全局设置
      bool find_from_cache;  // 是否先从 list cache 里面取， 设置为 false 表示强制从proxy查询
      bool allow_cut_off; // 是否允许查询截断。 通常为了性能在不命中 cache 时会截断为查询短链500个
      bool allow_item_loss; // 是否允许正排有损。 设置为 true，只从本机内存取没有失效的正排
      bool need_build_list; // 是否生产倒排拉链。 有的查询只是为了拉取正排，可设置为 false
      bool need_store_list_cache; // 是否存cache
      bool need_refresh;  // 是否需要例行刷新。 设置为 false 就不刷新，过期就没了
  };

/**
 * 新闻的索引，主要功能有
 * 1. 封装了 adsindex，提供 api 查询跟推荐相关的信息
 * 2. 内部独立线程更新新闻的 meta 信息 （可以关闭此线程）
 * 3. 内部独立线程热门新闻的索引（可以关闭此线程）
 */
  class NewsIndex {
  public:
    NewsIndex(const reco::IndexOptions& opt);
    ~NewsIndex();

    ///////////// 基本信息 ///////////////////////////
    // 从 ItemId 得到 Item Type
    bool GetItemTypeByItemId(uint64 item_id, reco::ItemType* item_type) const;
    // 得到 doc mask
    uint32 GetDocMaskByItemId(uint64 item_id) const;

    bool GetItemPtrByItemId(uint64 item_id, ItemInfoFullPtr *p) const;
    bool GetItemInfoByItemId(uint64 item_id, ItemInfo* item_info, bool only_basic);
    bool GetMetaInfo(uint64 item_id, ItemInfo *item) const;
    // 从 ItemId 获得 title 原文
    bool GetItemTitleByItemId(uint64 item_id, std::string* title) const;
    bool GetItemBidwordByItemId(uint64 item_id, std::string* bidword) const;
    bool GetItemContentByItemId(uint64 item_id, std::string* content) const;
    bool GetItemRawSummaryByItemId(uint64 item_id, std::string* summary) const;
    // 时间单位都是微秒，除以 base::time::kMicrosecondsPerSecond 等常量可以换算成其他时间单位
    // 可以认为是发布时间。有发布时间用发布时间，否则用爬虫抓取时间， 单位微秒
    int64 GetCreateTimestampByItemId(uint64 item_id) const;
    // 失效时间
    int64 GetExpireTimestampByItemId(uint64 item_id) const;
    // 待废弃
    int64 GetPublishSecondByItemId(uint64 item_id) const;
    // 抓取时间
    int64 GetCrawlTimestampByItemId(uint64 item_id) const;
    // Special Article 相关
    bool GetPreviewIdsByItemId(uint64 item_id, std::unordered_set<uint64>* preview_ids) const;
    bool GetContainIdsByItemId(uint64 item_id, std::unordered_set<uint64>* contain_ids) const;

    // 正文长度和段落数
    int32 GetContentLengthByItemId(uint64 item_id) const;
    int32 GetParagraphNumByItemId(uint64 item_id) const;
    // 图片个数
    int32 GetImageCountByItemId(uint64 item_id) const;
    bool GetImageByItemId(uint64 item_id, std::vector<uint64>* image) const;

    // 小说 ID
    bool GetNovelIdByItemId(uint64 item_id, std::string* novel_id) const;
    // 小说更新时间
    int64 GetNovelUpdateTimestampByItemId(uint64 item_id) const;

    // 视频个数
    int32 GetVideoCountByItemId(uint64 item_id) const;
    // 视频总播放时长
    int32 GetTotalVideoLengthByItemId(uint64 item_id) const;
    // 视频低俗级别
    VideoAttr::VideoVulgarLevel GetVideoVulgarLevelByItemId(uint64 item_id) const;
    // 视频质量级别
    VideoAttr::VideoQualityLevel GetVideoQualityLevelByItemId(uint64 item_id) const;
    // title 长度
    int32 GetTitleLengthByItemId(uint64 item_id) const;

    // 是否原创
    bool IsYuanchuangItemId(uint64 item_id) const;

    // 视频是否包含自存储地址
    bool HasVideoStorageInfoByItemId(uint64 item_id) const;

    // 视频自存储状态
    // -1 表示获取失败
    // 0 表示未去水印
    // 1 表示已经去水印
    int GetVideoStorageInfoStatusByItemId(uint64 item_id) const;

    // 获取优酷视频的 ID
    bool GetYoukuVideoIdByItemId(uint64 item_id, uint64* youku_video_id) const;
    bool GetItemIdByYoukuVideoId(uint64 youku_video_id, uint64 *item_id) const;

    // 视频封面图黑边比例 0.0 表示无黑边
    float GetVideoBlackEdgeRatioByItemId(uint64 item_id) const;

    bool GetVideoPosterProblemInfoByItemId(uint64 item_id, std::set<std::string> *problems) const;

    bool GetVideoPlayControlByItemId(uint64 item_id, reco::VideoPlayControl *video_play_control) const;

    bool GetParagraphByItemId(uint64 item_id, std::vector<uint64>* paragraph) const;

    uint64 GetWholeContentHashByItemId(uint64 item_id) const;

    // 是否经过人工审查
    bool GetHasReviewedByItemId(uint64 item_id) const;

    ///////////// 类别信息 ///////////////////////////
    // 获得指定 app 指定层级的所有类别信息
    // 返回的类别信息是 Category 形式的，带父级类别
    CategoryListPtr GetCategories(int level);
    // 返回本 item id 的类别信息
    bool GetCategoriesByItemId(uint64 item_id, std::vector<reco::Category>* categories) const;
    bool GetCategoriesByItemInfoFull(const ItemInfoFullPtr& p, std::vector<reco::Category>* categories) const;
    // 直接 append 调用方负责 categories 的 clear
    bool GetCategoriesByItemId(uint64 item_id, std::vector<std::string>* categories) const;

    bool GetMultiCategoriesByItemId(uint64 item_id, MultiCategory* multi_category) const;

    bool GetCategoryScore(uint64 item_id, const reco::Category& category, float* score) const;
    bool GetCategoryScore(uint64 item_id, const std::string& category, float* score) const;

    // 获取本 item id 的 source
    bool GetSourceByItemId(uint64 item_id, std::string* source) const;

    bool GetOrigMediaRiskTypeByItemId(uint64 item_id, int32* orig_media_risk_type) const;

    // 获取 app token / producer
    bool GetProducerByItemId(uint64 item_id, std::string* app_token) const;
    // item mining quality attr 相关, 返回 -1 表示不存在
    int32 GetJingpinScoreByItemId(uint64 item_id) const;

    bool GetOrigSourceByItemId(uint64 item_id, std::string* orig_source) const;

    bool GetShowSourceByItemId(uint64 item_id, std::string* show_source) const;
    bool GetShowSourceByItemPtr(const ItemInfoFull* ptr, std::string* show_source) const;
    bool GetFilterChainByItemId(uint64 item_id,
      RuleChain* filter_chain) const;

    bool GetSourceMediaByItemId(uint64 item_id, std::string* source_media) const;

    bool GetOrigSourceMediaByItemId(uint64 item_id, std::string* orig_source_media) const;
    // 获取类别下对应媒体等级的媒体数量
    int32 GetCateMediaLevelNum(const std::string& cate_level) const;

    bool GetYoukuAuditStatusByItemId(uint64 item_id) const;

    ///////////// 获取推荐信息 ///////////////////////////
    // 获取默认推荐
    ItemInfoListPtr GetDefaultReco();
    // 获取分类下的默认推荐
    ItemInfoListPtr GetDefaultReco(const reco::Category& category, bool timely = false);
    ItemInfoListPtr GetGuaranteeQuantityReco(const reco::Category& category);
    ItemInfoListPtr GetVideoGuaranteeQuantityReco(const reco::Category& category);

    // 获取 channel 下的默认推荐, region_id 只对 channel_id 为本地频道时生效, 不是本地频道时，请取值-1
    // only_video 对非视频频道生效, only_video == true 时返回的 ItemInfo 只有纯视频
    ItemInfoListPtr GetDefaultReco(int64 channel_id, int64 region_id, bool only_video);
    // 获取分类下的视频默认推荐
    ItemInfoListPtr GetVideoDefaultReco(const reco::Category& category);
    // 获取频道下的视频默认推荐
    ItemInfoListPtr GetVideoDefaultReco(const int64 channel_id, bool explore = false);
    // 获取 ucb 默认推荐
    void GetUCBDefaultReco(ItemInfoListPtr* item_list, uint64 max_return_size=0);
    // 获取热门卡片
    ItemInfoListPtr GetHotCardDefaultReco();
    // 获取精品文章的默认推荐
    ItemInfoListPtr GetJingpinDefaultReco();
    // 获取本地频道的默认推荐
    ItemInfoListPtr GetLocalDefaultReco(int64 region_id);
    // 获取基于 POI 的默认推荐
    ItemInfoListPtr GetPOIDefaultReco(int64 area_id);
    ItemInfoListPtr GetLocalBreakingDefaultReco(int64 region_id);
    ItemInfoListPtr GetSubjectDefaultReco();
    ItemInfoListPtr GetMiningStrategyReco(int32 strategy);

    WeMediaItemsDictPtr GetWeMediaItemsDict();

    // 获取对应 index_type 和 tag 的当日新闻数量
    int GetTodayNewsNum() const;
    int GetTodayNewsNum(const reco::Category& category) const;

    // 获取给定新闻在 某个时间/某个 channel 下的优先级，非置顶新闻直接返回 0
    // time 的格式应该满足 yyyy-MM-dd HH:mm:ss  格式，否则不保证结果的准确性
    int GetPriority(uint64 item_id, const std::string& time, int64 channel_id) const;

    bool GetUCBSettingByItemId(uint64 item_id, UcBrowserDeliverSettingPtr* ucb_setting);
    bool GetItemQualityAttrByItemId(uint64 item_id, ItemQualityAttr* quality_attr);
    int32 GetPosteriorItemQByItemId(uint64 item_id) const;
    // 标题里的核心标签. 返回的 core tags 已经按照标签的权重排序了
    // return false 表示没有核心标签.
    bool GetTitleCoreTagsByItemId(uint64 item_id, std::vector<std::string>* core_tags);

    int32 GetUCBStyleTypeByItemId(uint64 item_id) const;
    std::string GetUCBEditorNameByItemId(uint64 item_id) const;

    ///////////// 特征信息 ///////////////////////////
    // 从索引 ID 得到特征 (会填充特征的 type, literal, weight)
    bool GetFeatureMapByItemId(uint64 item_id, reco::common::FeatureType type,
      std::map<std::string, double>* feature,
      double* norm2) const;
    // 从 item id 得到特征 (会填充特征的 type, literal, weight)
    bool GetFeatureVectorByItemId(uint64 item_id, reco::common::FeatureType type,
      reco::FeatureVector* feature) const;
    bool GetFeatureVectorByItemInfoFull(const ItemInfoFullPtr& p, reco::common::FeatureType type, reco::FeatureVector* feature) const;
    // 从 item id 得到视频 tag 特征
    bool GetVideoTagFeatureVectorByItemId(uint64 item_id, reco::FeatureVector* feature) const;

    // 获取 item_id 对应的 sim_item ids
    SimiIdsSetPtr GetSimItemIds(uint64 item_id) const;
    bool HasCheckedBySimServer(uint64 item_id) const;
    uint64 GetParentId(uint64 item_id) const;
    ///////////// 正确性校验 ///////////////////////////
    // 到索引中重新检查 ItemInfo 的信息是否正确
    bool IsValidByItemId(uint64 item_id) const;
    bool IsValidByItemPtr(const ItemInfoFull* p) const;

    // 是否过期
    bool IsExpiredByItemId(uint64 item_id, int64 now_timestamp) const;
    bool IsExpiredByItemPtr(const ItemInfoFull* p, int64 now_timestamp) const;

    // 对特定渠道是否有效
    bool IsValidInAppByItemId(uint64 item_id, reco::common::AppNames app) const;
    bool IsValidInApp(const ItemInfoFullPtr& p, reco::common::AppNames app) const;

    // 直接 append, 调用方负责 channels 的 clear
    bool GetChannelsByItemId(uint64 item_id, std::vector<int64>* channels) const;

    bool GetRegionIdByItemId(uint64 item_id, std::vector<int64>* region_ids) const;
    bool GetRestrictRegionIdByItemId(uint64 item_id, std::vector<int64> *restrict_region_ids) const;
    bool GetTitleRegionIdByItemId(uint64 item_id, std::vector<int64>* region_ids) const;

    bool GetSubscriptsByItemId(uint64 item_id, ItemSubscipts *subscripts) const;
    bool GetShowTagByItemId(uint64 item_id, std::vector<std::string> *show_tags) const;

    void SetTagCache(const std::string& tag, ItemInfoFullPtrListPtr item_list);
    bool GetTagCache(const std::string& tag, ItemInfoFullPtrListPtr* item_list) const;
    void AsyncProcessTag();

    void GetDocsByChannel(int64 channel_id, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsBySource(const std::string& source, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByCategory(const std::string& category, int level, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByMultiCategory(const std::string& category, int level, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByKeywordOrTag(const std::string& word, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByTag(const std::string& tag, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByTag(const std::string& tag, reco::ItemType item_type, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByTerm(const std::string& term, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByClause(const std::string& clause, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByItemType(int32 item_type, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByRegionID(const std::string &region_id, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByWeMedia(ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    // 有些 item 里记录了这条新闻是从哪条 query 抓取回来的， 这个接口可以把他们检索出来
    void GetDocsBySpiderQuery(const std::string& query,
      ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByEventTag(const std::string& tag, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByShowTag(const std::string& tag, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByItemId(uint64 item_id, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByNovelId(const std::string& novel_id, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());
    void GetDocsByTitleLdaTopic(const std::string& topic, ItemInfoFullPtrListPtr* item_list,
      uint64 max_return_size = 0, SearchOpts opt = SearchOpts());

    // category 数组到 Category 的转换
    void ConvertToCategoryProto(const std::vector<std::string>& categories, int level,
      reco::Category* category) const;

    bool GetWeMediaPersonByItemId(uint64 item_id, std::string* wemedia_person) const;

    std::vector<reco::index_data::SourceInfo> SearchWemediaAuthor(const std::string& query,
      bool filter_unpub) const;

    // is_trival 为 true 表示 ContentAttr 里所有属性都为 0， 不需要做处理
    bool GetContentAttrByItemId(uint64 item_id, ContentAttr* content_attr, bool* is_trival) const;
    bool GetContentAttr(const ItemInfoFull* p, ContentAttr* content_attr_res, bool* is_trival) const;

    bool GetGaoDePOIByItemId(uint64 item_id, GaoDePOI* gaode_poi) const;

    // 对于 ItemType 为 kTimeAxisPage 的内容，通过 doc_id 获取整个时间轴的信息
    bool GetTimeAxisResultsByItemId(uint64 item_id, time_axis::TimeAxisResults *time_axis_results) const;

    bool ContainInCategoryQueue(const reco::Category& category, uint64 item_id) const;

    // 通过 item_id 查找其所在的时间轴
    bool GetItemTimeAxisInfoByItemId(uint64 item_id, time_axis::TimeAxisInfo *timeaxis_info) const;
    LatestNewsPairPtr GetLatestNewsByEventName(const std::string& event_name);

    bool GetVideoStatInfoByItemId(uint64 item_id, VideoStatInfo* info) const;
    int64 GetPublishSecond(uint64 item_id) const;

    bool GetEventTagByItemId(uint64 item_id, std::vector<std::string> *event_tags) const;

    bool SearchQuery(const std::string& query, int start, int num, std::vector<ItemInfo>* item_list) const;
    bool SearchWords(const std::vector<std::string>& and_words, const std::vector<std::string>& or_words, const std::vector<std::string>& not_words,
      int start, int num, std::vector<ItemInfo>* item_list) const;

    void StopUpdateCache();

    std::string GetKeywordLists(uint64 item_id) const;
    std::string GetKeywordFeatureLists(uint64 item_id) const;
    std::string GetTopicLists(uint64 item_id) const;
    std::string GetTopicFeatureLists(uint64 item_id) const;
    std::string GetPlsaTopicLists(uint64 item_id) const;
    std::string GetPlsaTopicFeatureLists(uint64 item_id) const;
    std::string GetWordVecLists(uint64 item_id) const;
    std::string GetWordVecFeatureLists(uint64 item_id) const;
    std::string GetTitleLdaTopicLists(uint64 item_id) const;
    std::string GetTitleLdaTopicFeatureLists(uint64 item_id) const;
    std::string GetTagLists(uint64 item_id) const;
    std::string GetTagFeatureLists(uint64 item_id) const;
    std::string GetSemanticTagLists(uint64 item_id) const;
    std::string GetSemanticTagFeatureLists(uint64 item_id) const;
    float GetKeywordNorm(uint64 item_id) const;
    float GetTopicNorm(uint64 item_id) const;
    float GetPlsaTopicNorm(uint64 item_id) const;
    float GetWordVecNorm(uint64 item_id) const;
    float GetTitleLdaTopicNorm(uint64 item_id) const;
    float GetTagNorm(uint64 item_id) const;
    float GetSemanticTagNorm(uint64 item_id) const;
    void FormatItemInfoHa3(const ItemInfoFull* full, std::string* outstr) const;
    void FormatItemInfo(const ItemInfo* iteminfo, std::string* outstr) const;
    bool IsManualByItemId(uint64 item_id) const;
    bool GetEventTagInfoByItemId(uint64 item_id,
      std::vector<reco::EventTagInfo> *event_tags) const;
    int32 GetOrgiItemQByItemId(uint64 item_id) const;
    bool GetOrgiItemQByItemId(uint64 item_id, int32* poster_itemq) const;
    bool GetItemInfoFromFull(const ItemInfoFullPtr& full, ItemInfo* item, bool only_basic=false) const;

    void LoadQuery(const std::string& filepath, std::unordered_map<std::string, reco::index::RecoQuery>* query_map);
    void LoadItemId(const std::string& filepath, std::unordered_set<uint64>* ids);
    void StoreQuery(const std::string& filepath, const std::vector<reco::index::RecoQuery>& qrs);
    void StoreItemId(const std::string& filepath, const std::unordered_map<uint64, ItemInfoFullPtr>* item_map);
    void FindCacheOrSearch(reco::index::RecoQuery& q, ItemInfoFullPtrListPtr* item_list, SearchOpts& opt);
    void FindCacheOrSearch(reco::index::RecoQuery& q, ItemInfoListPtr* item_list, SearchOpts& opt);

    // 获取保量相关信息, in: type, item; out: media_quantity_info, item_limit 返回值 true: 表示有保量信息
    bool GetItemQuantityInfo(const QueueType & type,
      const ItemInfo & item,
      MediaQuantityInfo* media_quantity_info,
      int64* item_limit) const {
      return MediaQuantityInfoIns::instance().GetItemQuantityInfo(
        type, item, media_quantity_info, item_limit);
    }

    void GetMetaInfoFromFull(const ItemInfoFullPtr& full, ItemInfo* item) const;
    bool GetTitleLdaTopicByItemId(uint64 item_id, reco::FeatureVector* feature) const;

    bool GetResultFromProxy(const reco::index::RecoQuery& q, SearchOpts opt,
      ItemInfoFullPtrListPtr* item_full_list, ItemInfoListPtr* item_simple_list);

    bool GetItemBreakingDict(ItemBreakingDictPtr* p);
    bool GetGroupInfoByItemId(uint64 item_id, ItemGroupInfo* group_info) const;
    bool GetLocalBreakingByItemId(uint64 item_id, reco::LocalBreaking* local_breaking) const;
    bool ContainLocalBreakingByItemId(uint64 item_id);
    bool GetItemInfoFull(const std::unordered_set<uint64>* ids_set, int timeout_ms);
    bool GetItemInfoFullAsync(const std::unordered_set<uint64>* ids_set);
    bool GetItemInfoFullMulti(const std::unordered_set<uint64>* ids_set, int timeout_ms);

    bool GetSubjectSubItemIds(uint64 item_id, std::vector<uint64>* subject_sub_itemids) const;
    int32 GetAppTokenBitsByItemId(uint64 item_id) const;
    bool GetAppTokenRuleBitsByItemId(uint64 item_id, std::string *rule_bits) const;
    int32 GetFirstNScreenFilterByItemId(uint64 item_id) const;
    int32 GetVideoWidthByItemId(uint64 item_id) const;
    int32 GetVideoHeightByItemId(uint64 item_id) const;
    int32 GetVideoColorsByItemId(uint64 item_id) const;
    bool IsVideoLargeCardItemId(uint64 item_id) const;
    float GetVideoPosterClarityItemId(uint64 item_id) const;

  private:
    // 解析出来的视频 tag 是不带前缀的，并且如果审核过，只取前缀是 manual 的 tag
    void ParseVideoTagFeatureVector(uint64 item_id,
      const reco::FeatureVector& raw_feature,
      reco::FeatureVector *real_feature) const;

    bool GenerateItemList(const std::string& term, reco::presort::GetDefaultRecoResponse* resp, bool need_store,
      ItemInfoFullPtrListPtr* item_full_list, ItemInfoListPtr* item_simple_list, bool is_async_update);
    bool FillItemInfoFullCache(reco::presort::GetDefaultRecoResponse* resp); 
    void GetBatchIdsResultFromProxy(reco::index::RecoQuery* q, int timeout_ms);
    bool CollectIds(const reco::presort::GetDefaultRecoResponse* resp, std::unordered_set<uint64>* ids_set);
    bool CollectSimIds(const std::unordered_set<uint64>* ids_set, std::unordered_set<uint64>* res_ids_set);
    bool CollectPreviewIds(const std::unordered_set<uint64>* ids_set, std::unordered_set<uint64>* preview_ids_set);
    bool GetChannelAndCategoryFromProxy();
    bool GetLatestNewsFromProxy(const std::string& event_name);
    bool GetWeMediaItemsFromProxy();
    bool GetItemBreakingFromProxy();
    bool GetSourceMetaFromProxy();
    void UpdateCacheThread();
    void UpdateWork(std::vector<reco::index::RecoQuery>* qrs, int hash_id);
    void GetItemInfoThread();
    void CopyIndexThread();
    void CopyIndex();
    bool SetItemAttr(const ItemInfoFullPtr& p, ItemFea* item_feature);
    bool ModifyItemInfoFull(ItemInfoFullPtr* full);
    void GetUpdateQuery(std::vector<reco::index::RecoQuery>* queries);
    bool ParseCategories(uint64 item_id, const std::string& cat_str , std::vector<std::string>* categories) const;

    reco::ExpiryMap<std::string, int64>*  list_access_time_;

    // for read
    DynamicDict< std::unordered_map<std::string, ItemInfoFullPtrListPtr> > item_list_dynamic_;
    DynamicDict< std::unordered_map<std::string, ItemInfoListPtr> > item_info_list_dynamic_;
    DynamicDict< std::unordered_map<uint64, ItemInfoFullPtr> > item_map_dynamic_;

    reco::reco_index::WrappedMap<std::string, ItemInfoFullPtrListPtr>* item_list_cache_; 
    reco::reco_index::WrappedMap<std::string, ItemInfoListPtr>* item_info_list_cache_; 
    reco::reco_index::WrappedMap<uint64, ItemInfoFullPtr>* item_map_; 

    // for write
    reco::ExpiryMap<std::string, ItemInfoFullPtrListPtr>*  item_list_cache_w_;
    reco::ExpiryMap<std::string, ItemInfoListPtr>*  item_info_list_cache_w_;
    reco::ExpiryMap<uint64, ItemInfoFullPtr>* item_map_w_;

    reco::ExpiryMap<int32, CategoryListPtr >* category_cache_;
    reco::ExpiryMap<int32, ChannelListPtr >* channel_cache_;
    reco::ExpiryMap<int32, TermListPtr >* term_cache_;
    reco::ExpiryMap<uint64, SimiIdsSetPtr>* simi_ids_cache_;
    reco::ExpiryMap<std::string, LatestNewsPairPtr>* latest_news_cache_;
    reco::ExpiryMap<std::string, WeMediaItemsDictPtr>* wemedia_items_cache_;
    reco::ExpiryMap<std::string, ItemBreakingDictPtr>* item_breaking_cache_;
    PresortClient* presort_client_;

    bool need_async_update_;
    std::atomic_bool async_update_stop_;
    thread::ThreadPool update_thread_pool_;
    int update_thread_num_;
    int update_interval_seconds_;
    int cache_expire_seconds_;
    std::atomic_int finish_part_;
    thread::Thread update_main_thread_;
    serving_base::Timer update_timer_;
    std::atomic_int update_count_;
    std::atomic_int copy_count_;
    std::unordered_map<uint64, uint64> item_update_time_;
    thread::Mutex mutex_update_time_;

    std::string cache_query_filepath_;
    std::string cache_item_id_filepath_;
    // 上一次运行过程中的query
    std::unordered_map<std::string, reco::index::RecoQuery> cache_query_last_;
    std::unordered_map<std::string, reco::index::RecoQuery> cache_query_;
    thread::Mutex mutex_of_cache_query_;
    int result_num_;
    int index_cut_off_num_;

    reco::ExpiryMap<std::string, reco::FeatureVector>* item_fea_expiry_map_;
    serving_base::ExpiryMap<std::string, std::vector<std::string> >* item_unigram_expiry_map_;
    reco::ExpiryMap<uint64, UcBrowserDeliverSettingPtr>* item_ucbsetting_expiry_map_;
    serving_base::ExpiryMap<uint64, ItemQualityAttr>* item_quality_expiry_map_;
    serving_base::ExpiryMap<uint64, std::vector<std::string> >* item_title_core_tags_expiry_map_;
    MultiCategoryCache* multi_category_cache_;
    static const int64 kTimestampInFuture;

    ItemInfoFullPtrListPtr empty_list_ptr_full_;
    ItemInfoListPtr empty_list_ptr_;
    CategoryListPtr empty_cat_ptr_;
    SimiIdsSetPtr empty_simi_ids_set_ptr_;
    WeMediaItemsDictPtr empty_wemedia_dict_ptr_;
    ItemBreakingDictPtr empty_item_breaking_dict_ptr_;

    bool enable_index_cache_;
    bool update_cache_query_;
    int proxy_long_timeout_ms_;
    int proxy_short_timeout_ms_;
    uint64 item_valid_time_;
    thread::BlockingQueue<uint64> missing_item_queue_;
    thread::Thread get_iteminfo_thread_;

    boost::shared_ptr<const reco::filter::StreamFilterDict> stream_filter_dict_;
    reco::filter::StreamFilterSignAsyncCalc* stream_filter_;

    thread::Thread copy_thread_;
    boost::shared_ptr<const reco::dm::ItemCategoryDict> itemid_category_map_;
  };
}  // namespace reco
