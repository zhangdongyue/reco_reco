#include "reco/bizc/reco_index_ha3/media_quantity_assurance.h"

#include <sstream>
#include "base/testing/gtest.h"
#include "base/common/logging.h"

namespace reco {
class GlobalEnvironment : public testing::Environment {
 public:
  virtual void SetUp() {
    DynamicDictContainer::RegisterAndLoadAllDict();
    reco::dm::DictManagerSingleton::instance().LoadAllDicts();
  }

  virtual void TearDown() {}
};

class MediaQuantityInfoDictTest : public testing::Test {
 public:
  virtual void SetUp() {}
  virtual void TearDown() {}
};

TEST_F(MediaQuantityInfoDictTest, Expand) {
  std::string source = "cp_we_media_种子1";
  reco::MediaSourceInfo meta_source_info;
  meta_source_info.set_source(source);
  meta_source_info.set_today_total_pv(100);
  meta_source_info.set_today_guarantee_pv(50);
  meta_source_info.set_news_total_pv(200);
  meta_source_info.set_news_guarantee_pv(150);
  meta_source_info.set_video_total_pv(300);
  meta_source_info.set_video_guarantee_pv(250);
  MediaQuantityInfoIns::instance().UpdateQuantityMetaInfo(meta_source_info);

  ItemInfo item;
  item.source_sign = base::CalcTermSign(source.c_str(), source.size());
  int64 item_limit;
  MediaQuantityInfo media_quantity_info;
  ASSERT_TRUE(MediaQuantityInfoIns::instance().GetItemQuantityInfo(
                kQueueDoc, item, &media_quantity_info, &item_limit));
  ASSERT_EQ(media_quantity_info.protect_type, 0);
  ASSERT_EQ(media_quantity_info.protect_capacity, 1200000);
  ASSERT_EQ(media_quantity_info.expect_daily_deliever_num, 12);
  ASSERT_EQ(media_quantity_info.source_level, reco::dm::kSourceLevelS);
  ASSERT_EQ(media_quantity_info.deliever_num, 200);
  ASSERT_EQ(media_quantity_info.assurance_deliever_num, 150);

  ASSERT_TRUE(MediaQuantityInfoIns::instance().GetItemQuantityInfo(
                kQueueVideo, item, &media_quantity_info, &item_limit));
  ASSERT_EQ(media_quantity_info.protect_type, 1);
  ASSERT_EQ(media_quantity_info.protect_capacity, 1100000);
  ASSERT_EQ(media_quantity_info.expect_daily_deliever_num, 11);
  ASSERT_EQ(media_quantity_info.source_level, reco::dm::kSourceLevelA);
  ASSERT_EQ(media_quantity_info.deliever_num, 300);
  ASSERT_EQ(media_quantity_info.assurance_deliever_num, 250);
}

TEST_F(MediaQuantityInfoDictTest, CategoryLimit) {
  std::string source = "cp_we_media_种子11";
  reco::MediaSourceInfo meta_source_info;
  meta_source_info.set_source(source);
  meta_source_info.set_today_total_pv(100);
  meta_source_info.set_today_guarantee_pv(50);
  meta_source_info.set_news_total_pv(200);
  meta_source_info.set_news_guarantee_pv(150);
  meta_source_info.set_video_total_pv(300);
  meta_source_info.set_video_guarantee_pv(250);
  MediaQuantityInfoIns::instance().UpdateQuantityMetaInfo(meta_source_info);

  ItemInfo item;
  item.source_sign = base::CalcTermSign(source.c_str(), source.size());

  double score = 0.0;
  ASSERT_TRUE(MediaQuantityInfoIns::instance().GetItemQuantityScore(
                "娱乐", reco::kQueueDoc, item, &score));
  ASSERT_TRUE(MediaQuantityInfoIns::instance().GetItemQuantityScore(
                "科技", reco::kQueueDoc, item, &score));
  ASSERT_FALSE(MediaQuantityInfoIns::instance().GetItemQuantityScore(
                "体育", reco::kQueueDoc, item, &score));
  ASSERT_FALSE(MediaQuantityInfoIns::instance().GetItemQuantityScore(
                "国际", reco::kQueueDoc, item, &score));
}
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "media_quantity_info test");
  testing::InitGoogleTest(&argc, argv);
  testing::AddGlobalTestEnvironment(new reco::GlobalEnvironment);
  return RUN_ALL_TESTS();
}
