#include "reco/bizc/reco_index_ha3/presort_client.h"
#include "arpc/ANetRPCController.h"
#include "base/common/sleep.h"
#include "serving_base/utility/timer.h"

DEFINE_int64_counter(news_index, rpc_proxy_short_list_total_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_short_list_succ_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_short_list_time, 0, "");

DEFINE_int64_counter(news_index, rpc_proxy_long_list_total_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_long_list_succ_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_long_list_time, 0, "");

DEFINE_int64_counter(news_index, rpc_proxy_pk_total_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_pk_succ_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_pk_time, 0, "");

DEFINE_int64_counter(news_index, rpc_proxy_cat_total_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_cat_succ_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_cat_time, 0, "");

DEFINE_int64_counter(news_index, rpc_proxy_latest_total_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_latest_succ_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_latest_time, 0, "");

DEFINE_int64_counter(news_index, rpc_proxy_wemedia_total_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_wemedia_succ_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_wemedia_time, 0, "");

DEFINE_int64_counter(news_index, rpc_proxy_dicts_total_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_dicts_succ_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_dicts_time, 0, "");

DEFINE_int64_counter(news_index, rpc_proxy_connect_count, 0, "");
DEFINE_int64_counter(news_index, rpc_proxy_connect_fail_count, 0, "");

namespace reco{
  DEFINE_int32(presort_max_retry, 2, "presort max retry");

  PresortClient::PresortClient(const PresortClientOptions& opt):options_(opt), connected_(false), retry_interval_ms_(1){
    max_retry_ = FLAGS_presort_max_retry;
    std::vector<std::string> ips;
    base::SplitString(opt.ips, ",", &ips);
    if (ips.size() == 0) {
      LOG(ERROR) << "invalid presort ips.";
      return;
    }
    LOG(INFO) << "presort ip num:" << ips.size();

    arpc_client_pool::client_pool::PoolParams params;
    params.clientCount = opt.connection_num * (int)ips.size();
    //params.lbStrategy = LBStrategy::CONSISTENT_HASH;

    set<arpc_client_pool::client_pool::StubInfo> stub_info;
    for (const auto& ip : ips) {
      stub_info.insert(arpc_client_pool::client_pool::StubInfo(ip, opt.port));
    }

    if (!conn_pool_.init(params, stub_info)) {
      LOG(FATAL) << "presort proxy server down, ip:" << opt.ips;
      return;
    }
    connected_ = true;
  }

  PresortClient::~PresortClient() {
    connected_ = false;
  }

  bool PresortClient::GetItemList(const reco::presort::GetDefaultRecoRequest& request,
   reco::presort::GetDefaultRecoResponse* resp, int timeout_ms, bool is_cutoff) {
    if (!connected_) {
      LOG(ERROR) << "presort server not connected" ;
      return false;
    }

    if (request.only_id()) {
      if (is_cutoff) {
        COUNTERS_news_index__rpc_proxy_short_list_total_count.Increase(1);
      } else {
        COUNTERS_news_index__rpc_proxy_long_list_total_count.Increase(1);
      }
    } else {
      COUNTERS_news_index__rpc_proxy_pk_total_count.Increase(1);
    }
    serving_base::Timer timer;
    timer.Start();

    bool ret = false;
    int retry = max_retry_;
    while (retry-- >= 0 && !ret) {
      arpc::ANetRPCController cntler;
      cntler.SetExpireTime(timeout_ms);
      cntler.SetErrorCode(arpc::ARPC_ERROR_NONE);
      auto stub_ptr = conn_pool_.get();
      COUNTERS_news_index__rpc_proxy_connect_count.Increase(1);
      if (!stub_ptr) {
        COUNTERS_news_index__rpc_proxy_connect_fail_count.Increase(1);
        base::SleepForMilliseconds(retry_interval_ms_);
        continue;
      }

      stub_ptr->stub()->GetDefaultReco(&cntler, &request, resp, NULL);

      int err_code = cntler.GetErrorCode();
      if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
        stub_ptr->setErrorCode(err_code);
        VLOG(1) << "presort arpc failed. msg:" << cntler.ErrorText() << " retry=" << retry 
        << " ip=" << stub_ptr->info().ip()
        << " tout=" << timeout_ms << " only_id=" <<  request.only_id() << " is_short=" << is_cutoff 
        << " recotype=" << request.reco_type() << " request_num=" << request.result_num() << " clause=" << request.clause().substr(0,255);
        continue;
      } 

      ret = true;
      break;
    }

    const int64 cost_ms = timer.Stop() / 1000;
    if (ret) {
      if (request.only_id()) {
        if (is_cutoff) {
          COUNTERS_news_index__rpc_proxy_short_list_succ_count.Increase(1);
        } else {
          COUNTERS_news_index__rpc_proxy_long_list_succ_count.Increase(1);
        }
      } else {
        COUNTERS_news_index__rpc_proxy_pk_succ_count.Increase(1);
      }
    }

    if (request.only_id()) {
      if (is_cutoff) {
        COUNTERS_news_index__rpc_proxy_short_list_time.Increase(cost_ms);
      } else {
        COUNTERS_news_index__rpc_proxy_long_list_time.Increase(cost_ms);
      }
    } else {
      COUNTERS_news_index__rpc_proxy_pk_time.Increase(cost_ms);
    }

    VLOG(1) << "rpc_time=" << cost_ms << " retry=" << retry << " tout=" << timeout_ms << " only_id=" <<  request.only_id() << " is_short=" << is_cutoff
      << " recotype=" << request.reco_type() << " result_num=" << resp->item_info_size();
    return ret;
  }

  bool PresortClient::GetChannelAndCategory(const reco::presort::GetChnAndCateRequest& request, reco::presort::GetChnAndCateResponse* resp) {
    if (!connected_) {
      LOG(ERROR) << "presort server not connected" ;
      return false;
    }

    COUNTERS_news_index__rpc_proxy_cat_total_count.Increase(1);
    serving_base::Timer timer;
    timer.Start();

    bool ret = false;
    int retry = max_retry_;
    while (retry-- >= 0 && !ret) {
      arpc::ANetRPCController cntler;
      cntler.SetExpireTime(options_.request_timeout);
      cntler.SetErrorCode(arpc::ARPC_ERROR_NONE);
      auto stub_ptr = conn_pool_.get();
      COUNTERS_news_index__rpc_proxy_connect_count.Increase(1);
      if (!stub_ptr) {
        COUNTERS_news_index__rpc_proxy_connect_fail_count.Increase(1);
        base::SleepForMilliseconds(retry_interval_ms_);
        continue;
      }

      stub_ptr->stub()->GetChannelAndCategory(&cntler, &request, resp, NULL);
      int err_code = cntler.GetErrorCode();
      if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
        stub_ptr->setErrorCode(err_code);
        LOG(ERROR) << "presort arpc failed. msg:" << cntler.ErrorText() << " retry=" << retry
          << " ip=" << stub_ptr->info().ip();
        continue;
      } 

      ret = true;
      break;
    }

    const int64 cost_ms = timer.Stop() / 1000;
    COUNTERS_news_index__rpc_proxy_cat_time.Increase(cost_ms);
    VLOG(1) << "rpc_time=" << cost_ms;
    return ret;
  }

  bool PresortClient::GetLatestNews(const reco::presort::GetLatestNewsRequest& request, 
  reco::presort::GetLatestNewsResponse* resp) {
    if (!connected_) {
      LOG(ERROR) << "presort server not connected" ;
      return false;
    }

    COUNTERS_news_index__rpc_proxy_latest_total_count.Increase(1);
    serving_base::Timer timer;
    timer.Start();

    bool ret = false;
    int retry = max_retry_;
    while (retry-- >= 0 && !ret) {
      arpc::ANetRPCController cntler;
      cntler.SetExpireTime(options_.request_timeout);
      cntler.SetErrorCode(arpc::ARPC_ERROR_NONE);
      auto stub_ptr = conn_pool_.get();
      COUNTERS_news_index__rpc_proxy_connect_count.Increase(1);
      if (!stub_ptr) {
        COUNTERS_news_index__rpc_proxy_connect_fail_count.Increase(1);
        base::SleepForMilliseconds(retry_interval_ms_);
        continue;
      }

      stub_ptr->stub()->GetLatestNews(&cntler, &request, resp, NULL);

      int err_code = cntler.GetErrorCode();
      if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
        stub_ptr->setErrorCode(err_code);
        LOG(ERROR) << "presort arpc failed. msg:" << cntler.ErrorText() << " retry=" << retry
          << " ip=" << stub_ptr->info().ip();
        continue;
      } 

      ret = true;
      break;
    }

    const int64 cost_ms = timer.Stop() / 1000;
    COUNTERS_news_index__rpc_proxy_latest_time.Increase(cost_ms);
    VLOG(1) << "rpc_time=" << cost_ms;
       
    if (ret) {
      COUNTERS_news_index__rpc_proxy_latest_succ_count.Increase(1);
    }

    return ret;
  }

  bool PresortClient::GetWemediaDict(const reco::presort::GetWemediaDictRequest& request, 
  reco::presort::GetWemediaDictResponse* resp) {
    if (!connected_) {
      LOG(ERROR) << "presort server not connected" ;
      return false;
    }

    COUNTERS_news_index__rpc_proxy_wemedia_total_count.Increase(1);
    serving_base::Timer timer;
    timer.Start();

    bool ret = false;
    int retry = max_retry_;
    while (retry-- >= 0 && !ret) {
      arpc::ANetRPCController cntler;
      cntler.SetExpireTime(options_.request_timeout);
      cntler.SetErrorCode(arpc::ARPC_ERROR_NONE);
      auto stub_ptr = conn_pool_.get();
      COUNTERS_news_index__rpc_proxy_connect_count.Increase(1);
      if (!stub_ptr) {
        COUNTERS_news_index__rpc_proxy_connect_fail_count.Increase(1);
        base::SleepForMilliseconds(retry_interval_ms_);
        continue;
      }

      stub_ptr->stub()->GetWeMediaItemsDict(&cntler, &request, resp, NULL);

      int err_code = cntler.GetErrorCode();
      if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
        stub_ptr->setErrorCode(err_code);
        LOG(ERROR) << "presort arpc failed. msg:" << cntler.ErrorText() << " retry=" << retry
          << " ip=" << stub_ptr->info().ip();
        continue;
      } 

      ret = true;
      break;
    }

    const int64 cost_ms = timer.Stop() / 1000;
    COUNTERS_news_index__rpc_proxy_wemedia_time.Increase(cost_ms);
    VLOG(1) << "rpc_time=" << cost_ms;
       
    if (ret) {
      COUNTERS_news_index__rpc_proxy_wemedia_succ_count.Increase(1);
    }

    return ret;
  }

  bool PresortClient::GetDicts(const reco::presort::GetDictsRequest& request, 
    reco::presort::GetDictsResponse* resp) {
    if (!connected_) {
      LOG(ERROR) << "presort server not connected" ;
      return false;
    }

    COUNTERS_news_index__rpc_proxy_dicts_total_count.Increase(1);
    serving_base::Timer timer;
    timer.Start();

    bool ret = false;
    int retry = max_retry_;
    while (retry-- >= 0 && !ret) {
      arpc::ANetRPCController cntler;
      cntler.SetExpireTime(options_.request_timeout);
      cntler.SetErrorCode(arpc::ARPC_ERROR_NONE);
      auto stub_ptr = conn_pool_.get();
      COUNTERS_news_index__rpc_proxy_connect_count.Increase(1);
      if (!stub_ptr) {
        COUNTERS_news_index__rpc_proxy_connect_fail_count.Increase(1);
        base::SleepForMilliseconds(retry_interval_ms_);
        continue;
      }

      stub_ptr->stub()->GetDicts(&cntler, &request, resp, NULL);

      int err_code = cntler.GetErrorCode();
      if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
        stub_ptr->setErrorCode(err_code);
        LOG(ERROR) << "presort arpc failed. msg:" << cntler.ErrorText() << " retry=" << retry
          << " ip=" << stub_ptr->info().ip();
        continue;
      } 

      ret = true;
      break;
    }

    const int64 cost_ms = timer.Stop() / 1000;
    COUNTERS_news_index__rpc_proxy_dicts_time.Increase(cost_ms);
    VLOG(1) << "rpc_time=" << cost_ms;
       
    if (ret) {
      COUNTERS_news_index__rpc_proxy_dicts_succ_count.Increase(1);
    }
      
    return ret;
  }
}
