#pragma once

#include "reco/base/common/atomic.h"
#include <string>
#include <vector>
#include <map>
#include <cmath>
#include <unordered_map>
#include <unordered_set>
#include <set>

#include "base/time/time.h"
#include "base/thread/thread.h"
#include "base/file/file_path.h"
#include "base/common/logging.h"
#include "base/strings/string_split.h"
#include "reco/base/common/singleton.h"
#include "reco/base/dict_manager/dynamic_dict.h"
#include "reco/bizc/reco_index_ha3/item_info.h"
#include "reco/bizc/reco_index_ha3/dynamic_dict_container.h"
#include "reco/bizc/proto/meta_update.pb.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "third_party/yaml-cpp/include/yaml-cpp/yaml.h"

using reco::dm::MediaQuantityInfo;

namespace reco {

DECLARE_double(text_guarantee_deliver_ratio);
DECLARE_int32(media_quantity_deliver_machine_num);
DECLARE_int32(video_guarantee_machine_num);

enum QueueType {
  kQueueDoc = 0,
  kQueueVideo = 1,
};

struct MediaSourceMetaInfo {
  MediaSourceMetaInfo() {}

  explicit MediaSourceMetaInfo(const reco::MediaSourceInfo & info) {
    source = std::string();
    deliever_num = 0;
    assurance_deliever_num = 0;
    news_deliever_num = 0;
    news_assurance_deliever_num = 0;
    video_deliever_num = 0;
    video_assurance_deliever_num = 0;

    if (!info.has_source()) return;
    std::string source_date = info.source();
    std::vector<std::string> source_split;
    base::SplitString(source_date, "`", &source_split);
    if (source_split.size() > 0) {
      source = source_split[0];
    } else {
      source = source_date;
    }
    if (info.has_today_total_pv()) {
      deliever_num = info.today_total_pv();
    }
    if (info.has_today_guarantee_pv()) {
      assurance_deliever_num = info.today_guarantee_pv();
    }
    if (info.has_news_total_pv()) {
      news_deliever_num = info.news_total_pv();
    }
    if (info.has_news_guarantee_pv()) {
      news_assurance_deliever_num = info.news_guarantee_pv();
    }
    if (info.has_video_total_pv()) {
      video_deliever_num = info.video_total_pv();
    }
    if (info.has_video_guarantee_pv()) {
      video_assurance_deliever_num = info.video_guarantee_pv();
    }
  }

  // 种子源名称
  std::string source;
  // 当日已下发量 (from meta updator)
  int64 deliever_num;
  // 当日保量策略下发量 (from meta updator)
  int64 assurance_deliever_num;
  // 图文当日已下发量 (from meta updator)
  int64 news_deliever_num;
  // 图文当日保量策略下发量 (from meta updator)
  int64 news_assurance_deliever_num;
  // 视频当日已下发量 (from meta updator)
  int64 video_deliever_num;
  // 视频当日保量策略下发量 (from meta updator)
  int64 video_assurance_deliever_num;
};

class MediaQuantityInfoDict {
 public:
  MediaQuantityInfoDict();
  ~MediaQuantityInfoDict();

  bool GetItemQuantityScore(const std::string & category,
                           const QueueType & type,
                           const ItemInfo & item,
                           double* score);

  // 获取保量相关信息， 返回值 true: 表示有保量信息
  bool GetItemQuantityInfo(const QueueType & type,
                           const ItemInfo & item,
                           MediaQuantityInfo* media_quantity_info,
                           int64* item_limit);

  // 实时更新当日下发量的接口
  bool UpdateQuantityMetaInfo(const reco::MediaSourceInfo & meta_source_info);

//  // 获取当天一共有多少要保的量
//  int64 GetGuaranteeQuantityByQueueType();

  void IncGuaranteeDeliver(const ItemInfo& item);
  void LocalGuaranteeDeliver(const ItemInfo& item,
                             int64* source_deliver_num,
                             int64* item_deliver_num);

 public:
  // YAML 的读取过程
  static bool ParseFromYAML(const YAML::Node & node, MediaQuantityInfo* media_quantity_info);
 private:
  inline void GetLimitOfItem(const reco::dm::MediaQuantityType & type,
                             int64 source_level,
                             int64* limit);

  inline bool CalcItemQuantityScore(const MediaQuantityInfo & media_info,
                                    const ItemInfo & item,
                                    int64 item_limit,
                                    double* score);

  inline bool GetQuantityMetaInfo(const QueueType & type,
                                  uint64 source_sign,
                                  MediaQuantityInfo* media_quantity_info);

  static bool GetYamlNodeString(const YAML::Node & node, std::string* data);

  std::unordered_map<uint64, MediaSourceMetaInfo> media_source_meta_dict_;

  serving_base::ExpiryMap<uint64, int64>* media_guarantee_deliver_counter_;
  serving_base::ExpiryMap<uint64, int64>* item_guarantee_deliver_counter_;

  FRIEND_TEST(MediaQuantityInfoDictTest, Expanded);
};

typedef reco::common::singleton_default<MediaQuantityInfoDict> MediaQuantityInfoIns;
}
