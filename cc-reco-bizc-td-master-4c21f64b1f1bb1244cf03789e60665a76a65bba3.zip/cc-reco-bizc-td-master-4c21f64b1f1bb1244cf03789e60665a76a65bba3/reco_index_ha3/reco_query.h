#pragma once
#include <string>
#include <sstream>
#include "base/common/basic_types.h"
#include "reco/base/common/uri_process.h"
#include "reco/bizc/proto/index_presort_type.pb.h"
#include "reco/bizc/common/wrapped_category.h"

namespace reco {
  namespace index {
  class RecoQuery {
  public:
    RecoQuery():reco_type_(reco::presort::kDefault),
    channel_id_(-1), region_id_(-1), area_id_(-1), timely_(false)
    , explore_(false), result_num_(555), ori_result_num_(555), strategy_(-1) {
    }

    ~RecoQuery(){
    }

    void toRecoRequest(reco::presort::GetDefaultRecoRequest* request) const {
      request->set_reco_type(reco_type_); 
      request->set_result_num(result_num_); 

      Category* cate;

      switch (reco_type_) {
      case reco::presort::kCategoryReco:
        cate = request->mutable_category();
        *cate = wc_.get()->ToCategory();
        request->set_timely(timely_); 
        break;
      case reco::presort::kChannelReco:
        request->set_channel_id(channel_id_); 
        request->set_region_id(region_id_); 
        break;
      case reco::presort::kVideoCategoryReco:
        cate = request->mutable_category();
        *cate = wc_.get()->ToCategory();
        break;
      case reco::presort::kVideoChannelReco:
        request->set_channel_id(channel_id_); 
        request->set_explore(explore_); 
        break;
      case reco::presort::kTudouJingpinReco:
        break;
      case reco::presort::kPOIReco:
        request->set_area_id(area_id_); 
        break;
      case reco::presort::kUCBReco:
        break;
      case reco::presort::kHotCardReco:
        break;
      case reco::presort::kWemediaItem:
        break;
      case reco::presort::kTermReco:
        request->set_term(term_); 
        break;
      case reco::presort::kQuantityReco:
        cate = request->mutable_category();
        *cate = wc_.get()->ToCategory();
        break;
      case reco::presort::kLocalBreakingReco:
        request->set_region_id(region_id_);
        break;
      case reco::presort::kMiningSttgReco:
        request->set_mining_strategy(strategy_);
        break;
      case reco::presort::kTestReco:
        request->set_clause(clause_); 
        break;
      default:
        break;
      }
    }

    std::string toString() const {
      std::ostringstream oss;
      oss << "reco_type=" << reco_type_ << "&result_num=" << ori_result_num_;

      std::string  encode_str;
      switch (reco_type_) {
      case reco::presort::kCategoryReco:
        reco::common::FastEncodeUrlComponent(wc_.get()->ToString(), &encode_str);
        oss << "&cate=" << encode_str << "&timely=" << timely_;
        break;
      case reco::presort::kChannelReco:
        oss << "&channel_id=" << channel_id_ << "&region_id=" << region_id_;
        break;
      case reco::presort::kVideoCategoryReco:
        reco::common::FastEncodeUrlComponent(wc_.get()->ToString(), &encode_str);
        oss << "&video_cate=" << encode_str;
        break;
      case reco::presort::kVideoChannelReco:
        oss << "&video_channel_id=" << channel_id_ << "&explore=" << explore_;
        break;
      case reco::presort::kTudouJingpinReco:
        break;
      case reco::presort::kPOIReco:
        oss << "&area_id=" << area_id_;
        break;
      case reco::presort::kUCBReco:
        break;
      case reco::presort::kHotCardReco:
        break;
      case reco::presort::kWemediaItem:
        break;
      case reco::presort::kTermReco:
        reco::common::FastEncodeUrlComponent(term_, &encode_str);
        oss << "&term=" << encode_str;
        break;
      case reco::presort::kQuantityReco:
        reco::common::FastEncodeUrlComponent(wc_.get()->ToString(), &encode_str);
        oss << "&cate=" << encode_str;
        break;
      case reco::presort::kLocalBreakingReco:
        oss << "&region_id=" << region_id_;
        break;
      case reco::presort::kMiningSttgReco:
        oss << "&strategy=" << strategy_;
        break;
      case reco::presort::kTestReco:
        reco::common::FastEncodeUrlComponent(clause_, &encode_str);
        oss << "&clause=" << encode_str;
        break;
      default:
        break;
      }

      return oss.str();
    }

    // url query format: x=y&a=b
    bool ParseFromString(const std::string & s) {
      VLOG(1) << "s:" << s;
      RecoQuery& q = *this;
      std::vector<std::string> flds;
      std::map<std::string, std::string> kv;
      base::SplitString(s, "&", &flds);

      for (auto i = flds.begin(); i != flds.end(); i++) {
        VLOG(1) << "kv:"<< *i;
        std::vector<std::string> tmp;
        base::SplitString(*i, "=", &tmp);
        if (tmp.size() > 2) {
          LOG(ERROR) << "num of = is not 2" << *i;
          return false;
        }

        if (tmp[0] == "") {
          LOG(ERROR) << "invalid kv:" << *i;
          return false;
        }

        kv[tmp[0]] = tmp[1];  
      }

      std::string key = "reco_type";
      if (kv.find(key) == kv.end()) {
        LOG(ERROR) << key << " not exist:" << s;
        return false;
      } else {
        int reco_type=0;
        if (!base::StringToInt(kv[key], &reco_type)) {
          LOG(ERROR) << "parse " << key << " error:" << s;
          return false;
        }
        q.reco_type_ = static_cast<reco::presort::RecoType>(reco_type);
      }

      key = "result_num";
      if (kv.find(key) != kv.end()) {
        int result_num=0;

        if (!base::StringToInt(kv[key], &result_num)) {
          LOG(ERROR) << "parse " << key << " error:" << s;
          return false;
        }

        if (result_num > 0) {
          q.result_num_ = result_num;
          q.ori_result_num_ = result_num;
        }
      }

      key = "is_timely";
      if (kv.find(key) != kv.end()) {
        int is_timely=0;

        if (!base::StringToInt(kv[key], &is_timely)) {
          LOG(ERROR) << "parse " << key << " error:" << s;
          return false;
        }

        q.timely_ = (is_timely != 0 ); 
      }

      key = "is_explore";
      if (kv.find(key) != kv.end()) {
        int is_explore=0;

        if (!base::StringToInt(kv[key], &is_explore)) {
          LOG(ERROR) << "parse " << key << " error:" << s;
          return false;
        }

        q.explore_ = (is_explore != 0 ); 
      }

      key = "cate"; 
      if (kv.find(key) != kv.end()) {
        if (kv[key] == "") {
          LOG(ERROR) << key << " empty error:" << s;
          return false;
        }

        std::string decode_str;
        if (!reco::common::DecodeUrlComponent(kv[key].c_str(), &decode_str)) {
          LOG(ERROR) << "decode fail:" << kv[key];
        } else {
          q.wc_ = std::shared_ptr<reco::common::WrappedCategory>(new reco::common::WrappedCategory(decode_str));
        }
      }

      key = "channel_id"; 
      if (kv.find(key) != kv.end()) {
        if (kv[key] == "") {
          LOG(ERROR) << key << " empty error:" << s;
          return false;
        }
        if (!base::StringToInt64(kv[key], &(q.channel_id_))) {
          LOG(ERROR) << "parse channel id error, line=" << s;
          return false;
        }
      }

      key = "region_id"; 
      if (kv.find(key) != kv.end()) {
        if (kv[key] == "") {
          LOG(ERROR) << key << " empty error:" << s;
          return false;
        }
        if (!base::StringToInt64(kv[key], &(q.region_id_))) {
          LOG(ERROR) << "parse region_id error, line=" << s;
          return false;
        }
      }

      key = "area_id"; 
      if (kv.find(key) != kv.end()) {
        if (kv[key] == "") {
          LOG(ERROR) << key << " empty error:" << s;
          return false;
        }
        if (!base::StringToInt64(kv[key], &(q.area_id_))) {
          LOG(ERROR) << "parse area_id error, line=" << s;
          return false;
        }
      }

      key = "clause"; 
      if (kv.find(key) != kv.end()) {
        if (kv[key] == "") {
          LOG(ERROR) << key << " empty error:" << s;
          return false;
        }

        std::string decode_str;
        if (!reco::common::DecodeUrlComponent(kv[key].c_str(), &decode_str)) {
          LOG(ERROR) << "decode fail:" << kv[key];
        } else {
          q.clause_ = decode_str;
        }
      }

      key = "term"; 
      if (kv.find(key) != kv.end()) {
        if (kv[key] == "") {
          LOG(ERROR) << key << " empty error:" << s;
          return false;
        }

        std::string decode_str;
        if (!reco::common::DecodeUrlComponent(kv[key].c_str(), &decode_str)) {
          LOG(ERROR) << "decode fail:" << kv[key];
        } else {
          q.term_ = decode_str;
        }
      }

      key = "strategy"; 
      if (kv.find(key) != kv.end()) {
        if (kv[key] == "") {
          LOG(ERROR) << key << " empty error:" << s;
          return false;
        }
        if (!base::StringToInt(kv[key], &(q.strategy_))) {
          LOG(ERROR) << "parse strategy error, line=" << s;
          return false;
        }
      }

      VLOG(1) << "parse query succ:" << s << " res:" << q.toString();
      return true;
    }

    reco::presort::RecoType reco_type_;
    std::shared_ptr<reco::common::WrappedCategory> wc_;
    int64 channel_id_;
    int64 region_id_;
    int64 area_id_;
    bool timely_;
    bool explore_;
    int32 result_num_;
    int32 ori_result_num_;
    string clause_;
    string from_;
    string term_;
    int32 strategy_;
  };
  }
}
