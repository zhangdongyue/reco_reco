#pragma once
#include <string>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <set>
#include <map>
#include <memory>
#include "base/common/basic_types.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/index_presort_type.pb.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "reco/ml/wd_feature/text_feature/item_feature.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "reco/bizc/common/index_util_ha3.h"

namespace reco{
 typedef struct _ItemFea_t {
    std::vector<std::pair<std::string, float> > keyword_info;
    std::vector<std::pair<std::string, float> > tag_info;
    std::vector<std::pair<std::string, float> > topic_info;
    std::vector<std::pair<std::string, float> > category_info;
  } ItemFea;

class ItemInfoFull {
public:
  ItemInfoFull(const reco::presort::PbItemInfoIndex& arg);
  ~ItemInfoFull();

  const std::vector<int64>& channel_ids() {
    return channel_ids_;
  }

  float keyword_norm() const { 
    return keyword_norm_;
  }
  float plsa_topic_norm() const { 
    return plsa_topic_norm_;
  }
  float semantic_tag_norm() const { 
    return semantic_tag_norm_;
  }
  float tag_norm() const { 
    return tag_norm_;
  }
  float topic_norm() const { 
    return topic_norm_;
  }
  float video_black_edge_ratio() const { 
    return video_black_edge_ratio_;
  }
  float wordvec_norm() const { 
    return wordvec_norm_;
  }
  int32 content_attr() const { 
    return content_attr_;
  }
  bool content_attr_pb(reco::ContentAttr* ca, bool* is_trival) const {
    *is_trival = (content_attr_ == 0);
    reco::common::UnPackContentAttr(static_cast<uint64>(content_attr_), ca);
    return true;
  }
  int32 content_length() const { 
    return content_length_;
  }
  uint64 crawl_timestamp() const { 
    return crawl_timestamp_;
  }
  uint64 create_timestamp() const { 
    return create_timestamp_;
  }
  int32 docmask() const { 
    return docmask_;
  }
  uint64 expire_timestamp() const { 
    return expire_timestamp_;
  }
  int32 has_video_storage_info() const { 
    return has_video_storage_info_;
  }
  int32 image_count() const { 
    return image_count_;
  }
  int32 item_has_reviewed() const { 
    return item_has_reviewed_;
  }
  int32 item_is_yuanchuang() const { 
    return item_is_yuanchuang_;
  }
  int32 item_type() const { 
    return item_type_;
  }
  int32 jingpin_score() const { 
    return jingpin_score_;
  }
  int32 novel_update_time() const { 
    return novel_update_time_;
  }
  int32 paragraph_num() const { 
    return paragraph_num_;
  }
  int32 popularity() const { 
    return popularity_;
  }
  int32 posterior_item_q() const { 
    return posterior_item_q_;
  }
  int32 publish_time() const { 
    return publish_time_;
  }
  int32 term_feature_version() const { 
    return term_feature_version_;
  }
  int32 title_length() const { 
    return title_length_;
  }
  int32 ucbr_style_type() const { 
    return ucbr_style_type_;
  }
  int32 video_count() const { 
    return video_count_;
  }
  int32 video_length() const { 
    return video_length_;
  }
  int32 video_quality_level() const { 
    return video_quality_level_;
  }
  int32 video_storage_info_status() const { 
    return video_storage_info_status_;
  }
  int32 video_vulgar_level() const { 
    return video_vulgar_level_;
  }
  const std::string& app_token() const { 
    return app_token_;
  }
  const std::string& image_hash() const { 
    return image_hash_;
  }
  const std::string& item_subscripts() const { 
    return item_subscripts_;
  }
  const std::string& keyword_feature_list() const { 
    return keyword_feature_list_;
  }
  const std::string& keyword_list() const { 
    return keyword_list_;
  }
  const std::string& novel_id() const { 
    return novel_id_;
  }
  const std::string& orig_source_media() const { 
    return orig_source_media_;
  }
  const std::string& orig_source() const { 
    return orig_source_;
  }
  const std::string& outer_id() const { 
    return outer_id_;
  }
  const std::string& paragraph_hash() const { 
    return paragraph_hash_;
  }
  const std::string& plsa_topic_feature_list() const { 
    return plsa_topic_feature_list_;
  }
  const std::string& plsa_topic_list() const { 
    return plsa_topic_list_;
  }
  const std::string& raw_summary() const { 
    return raw_summary_;
  }
  const std::string& region_from_title() const { 
    return region_from_title_;
  }
  const std::string& region_restrict() const { 
    return region_restrict_;
  }
  const std::string& region() const { 
    return region_;
  }
  const std::string& semantic_tag_feature_list() const { 
    return semantic_tag_feature_list_;
  }
  const std::string& semantic_tag_list() const { 
    return semantic_tag_list_;
  }
  const std::string& sim_feature() const { 
    return sim_feature_;
  }
  const std::string& sim_hash() const { 
    return sim_hash_;
  }
  const std::string& source_media() const { 
    return source_media_;
  }
  const std::string& source() const { 
    return source_;
  }
  const std::string& tag_feature_list() const { 
    return tag_feature_list_;
  }
  const std::string& tag_list() const { 
    return tag_list_;
  }
  int32 term_feature_bytes() const { 
    return term_feature_bytes_;
  }
  const std::string& term_payload() const { 
    return term_payload_;
  }
  const std::string& topic_feature_list() const { 
    return topic_feature_list_;
  }
  const std::string& topic_list() const { 
    return topic_list_;
  }
  const std::string& ucb_editor_name() const { 
    return ucb_editor_name_;
  }
  const std::string& wemedia_person() const { 
    return wemedia_person_;
  }
  const std::string& wordvec_feature_list() const { 
    return wordvec_feature_list_;
  }
  const std::string& wordvec_list() const { 
    return wordvec_list_;
  }
  const std::string& youku_video_id() const { 
    return youku_video_id_;
  }
  const std::string& priority() const { 
    return priority_;
  }
  const std::string& special_contain_item_list() const { 
    return special_contain_item_list_;
  }
  const std::string& special_prevew_item_list() const { 
    return special_prevew_item_list_;
  }
  const std::string& video_poster_problem_info() const { 
    return video_poster_problem_info_;
  }
  const std::string& category() const { 
    return category_;
  }
  const std::string& channel() const { 
    return channel_;
  }
  const std::string& item_event_tag() const { 
    return item_event_tag_;
  }
  const std::string& item_show_tag() const { 
    return item_show_tag_;
  }
  const std::string& gaode_poi() const { 
    return gaode_poi_;
  }
  const std::string& item_quality_attr() const { 
    return item_quality_attr_;
  }
  const std::string& time_axis_results() const { 
    return time_axis_results_;
  }
  const std::string& ucbr_deliver() const { 
    return ucbr_deliver_;
  }
  const std::string& category_candidates() const { 
    return category_candidates_;
  }
  const std::string& title() const { 
    return title_;
  }
  const std::string& anchor() const { 
    return anchor_;
  }
  const std::string& query() const { 
    return query_;
  }
  const std::string& bid_word() const { 
    return bid_word_;
  }
  const std::string& content() const { 
    return content_;
  }
  uint64 item_id() const { 
    return item_id_;
  }
  int32 orig_media_risk_type() const { 
    return orig_media_risk_type_;
  }
  int32 manual_news() const { 
    return manual_news_;
  }
  const std::string& youku_audit_status() const { 
    return youku_audit_status_;
  }
  uint64 ha3_update_timestamp() const { 
    return ha3_update_timestamp_;
  }
  const std::string& item_event_tag_info() const { 
    return item_event_tag_info_;
  }
  const std::string& video_play_control() const { 
    return video_play_control_;
  }
  const std::string& youku_show_id() const { 
    return youku_show_id_;
  }
  const std::string& subject_sub_items() const { 
    return subject_sub_items_;
  }
  const std::string& title_lda_topic_list() const { 
    return title_lda_topic_list_;
  }
  const std::string& title_lda_topic_feature_list() const { 
    return title_lda_topic_feature_list_;
  }
  float title_lda_topic_norm() const { 
    return title_lda_topic_norm_;
  }

  int32 index_score() const { 
    return index_score_;
  }
  const reco::presort::PbMetaInfo& meta_info() const { 
    return meta_info_;
  }
  const reco::presort::PbSimInfo& sim_info() const { 
    return sim_info_;
  }
  const reco::time_axis::TimeAxisInfo& time_axis_info() const { 
    return time_axis_info_;
  }
  float sort_value() const { 
    return sort_value_;
  }
  const std::string& local_breaking() const { 
    return local_breaking_;
  }
  const std::string& group_info() const { 
    return group_info_;
  }
  const ItemFea& item_fea() const {
    return item_fea_;
  }
  ItemFea* mutable_item_fea() {
    return &item_fea_;
  }
  const std::vector<reco::model_server::FeatureInfo>& item_wd_feas() const {
    return item_wd_feas_;
  }
  std::vector<reco::model_server::FeatureInfo>* mutable_item_wd_feas() {
    return &item_wd_feas_;
  }
  const std::vector<reco::filter::FilterStrategy>& filter_strategy() const {
    return filter_strategy_;
  }
  std::vector<reco::filter::FilterStrategy>* mutable_filter_strategy() {
    return &filter_strategy_;
  }

  int32 first_nscreen_filter() const { 
    return first_nscreen_filter_;
  }
  int32 app_token_bits() const { 
    return app_token_bits_;
  }
  const std::string& app_token_rule_bits() const { 
    return app_token_rule_bits_;
  }
  int32 video_colors() const { 
    return video_colors_;
  }
  int32 video_width() const { 
    return video_width_;
  }
  int32 video_height() const { 
    return video_height_;
  }
  float video_poster_clarity() const { 
    return video_poster_clarity_;
  }
  float wilson_ctr() const { 
    return wilson_ctr_;
  }
  const std::vector<std::string>& categories() const {
    return categories_;
  }
  std::vector<std::string>* mutable_categories() {
    return &categories_;
  }

  const std::set<uint64>* simi_ids() const {
    return &simi_ids_;
  }

private:
  float keyword_norm_;
  float plsa_topic_norm_;
  float semantic_tag_norm_;
  float tag_norm_;
  float topic_norm_;
  float video_black_edge_ratio_;
  float wordvec_norm_;
  int32 content_attr_;
  int32 content_length_;
  uint64 crawl_timestamp_;
  uint64 create_timestamp_;
  int32 docmask_;
  uint64 expire_timestamp_;
  int32 has_video_storage_info_;
  int32 image_count_;
  int32 item_has_reviewed_;
  int32 item_is_yuanchuang_;
  int32 item_type_;
  int32 jingpin_score_;
  int32 novel_update_time_;
  int32 paragraph_num_;
  int32 popularity_;
  int32 posterior_item_q_;
  int32 publish_time_;
  int32 term_feature_version_;
  int32 title_length_;
  int32 ucbr_style_type_;
  int32 video_count_;
  int32 video_length_;
  int32 video_quality_level_;
  int32 video_storage_info_status_;
  int32 video_vulgar_level_;
  std::string app_token_;
  std::string image_hash_;
  std::string item_subscripts_;
  std::string keyword_feature_list_;
  std::string keyword_list_;
  std::string novel_id_;
  std::string orig_source_media_;
  std::string orig_source_;
  std::string outer_id_;
  std::string paragraph_hash_;
  std::string plsa_topic_feature_list_;
  std::string plsa_topic_list_;
  std::string raw_summary_;
  std::string region_from_title_;
  std::string region_restrict_;
  std::string region_;
  std::string semantic_tag_feature_list_;
  std::string semantic_tag_list_;
  std::string sim_feature_;
  std::string sim_hash_;
  std::string source_media_;
  std::string source_;
  std::string tag_feature_list_;
  std::string tag_list_;
  int32 term_feature_bytes_;
  std::string term_payload_;
  std::string topic_feature_list_;
  std::string topic_list_;
  std::string ucb_editor_name_;
  std::string wemedia_person_;
  std::string wordvec_feature_list_;
  std::string wordvec_list_;
  std::string youku_video_id_;
  std::string priority_;
  std::string special_contain_item_list_;
  std::string special_prevew_item_list_;
  std::string video_poster_problem_info_;
  std::string category_;
  std::string channel_;
  std::string item_event_tag_;
  std::string item_show_tag_;
  std::string gaode_poi_;
  std::string item_quality_attr_;
  std::string time_axis_results_;
  std::string ucbr_deliver_;
  std::string category_candidates_;
  std::string title_;
  std::string anchor_;
  std::string query_;
  std::string bid_word_;
  std::string content_;
  uint64 item_id_;
  int32 orig_media_risk_type_;
  int32 manual_news_;
  std::string youku_audit_status_;
  uint64 ha3_update_timestamp_;
  std::string item_event_tag_info_;
  std::string video_play_control_;
  std::string youku_show_id_;
  std::string subject_sub_items_;
  std::string title_lda_topic_list_;
  std::string title_lda_topic_feature_list_;
  float title_lda_topic_norm_;

  int32 index_score_;
  reco::presort::PbMetaInfo meta_info_;
  reco::presort::PbSimInfo sim_info_;
  reco::time_axis::TimeAxisInfo time_axis_info_;
  std::vector<int64> channel_ids_;
  float sort_value_;
  std::string local_breaking_;
  std::string group_info_;
  ItemFea item_fea_;
  std::vector<reco::model_server::FeatureInfo> item_wd_feas_;
  int32 first_nscreen_filter_;
  int32 app_token_bits_;
  std::string app_token_rule_bits_;
  std::vector<reco::filter::FilterStrategy> filter_strategy_;
  int32 video_colors_;
  int32 video_height_;
  int32 video_width_;
  float video_poster_clarity_;
  float wilson_ctr_;
  std::vector<std::string> categories_;
  std::set<uint64> simi_ids_;
};
}
