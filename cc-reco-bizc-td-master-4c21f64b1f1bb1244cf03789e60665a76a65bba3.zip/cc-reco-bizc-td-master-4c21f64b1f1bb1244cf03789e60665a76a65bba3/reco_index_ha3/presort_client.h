#pragma once
#include <string>
#include <vector>
#include "reco/bizc/proto_arpc/index_presort_server.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "client_pool/ArpcClientPool.h"

namespace reco{
  class PresortClientOptions {
  public:
    PresortClientOptions():connection_num(10), request_timeout(10) {}
    std::string ips;
    int port;
    int connection_num;
    int request_timeout;
  };

  class PresortClient {
  public:
    PresortClient(const PresortClientOptions& opt);
    ~PresortClient();

    bool GetItemList(const reco::presort::GetDefaultRecoRequest& request, reco::presort::GetDefaultRecoResponse* resp,
     int timeout_ms, bool is_cutoff);
    bool GetChannelAndCategory(const reco::presort::GetChnAndCateRequest& request, reco::presort::GetChnAndCateResponse* resp);
    bool GetLatestNews(const reco::presort::GetLatestNewsRequest& request, 
      reco::presort::GetLatestNewsResponse* resp);
    bool GetWemediaDict(const reco::presort::GetWemediaDictRequest& request, 
      reco::presort::GetWemediaDictResponse* resp);
    bool GetDicts(const reco::presort::GetDictsRequest& request, 
      reco::presort::GetDictsResponse* resp);

  private:
    PresortClientOptions options_;
    bool connected_;
    int max_retry_;
    int retry_interval_ms_;
    arpc_client_pool::client_pool::ArpcClientPool<reco::presort::PresortService_Stub> conn_pool_;
  };
}
