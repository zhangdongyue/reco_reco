#include <fstream>

#include "reco/bizc/reco_index_ha3/media_quantity_assurance.h"
#include "reco/bizc/reco_index_ha3/news_index_ha3.h"

#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "base/file/platform_file.h"
#include "base/strings/string_number_conversions.h"

namespace reco {

DEFINE_double(media_quantity_deliever_weight, 1.0, "");
DEFINE_double(media_quantity_ctr_weight, 1.0, "");
DEFINE_double(media_quantity_expect_deliever_weight, 1.0, "");
DEFINE_double(media_quantity_item_deliever_weight, 1.0, "");
DEFINE_int32(media_quantity_deliver_machine_num, 250, "");
DEFINE_int32(video_guarantee_machine_num, 1, "");


MediaQuantityInfoDict::MediaQuantityInfoDict() {
  media_guarantee_deliver_counter_ = new serving_base::ExpiryMap<uint64, int64>(24 * 60 * 60);
  item_guarantee_deliver_counter_ = new serving_base::ExpiryMap<uint64, int64>(24 * 60 * 60);
}


MediaQuantityInfoDict::~MediaQuantityInfoDict() {
  delete media_guarantee_deliver_counter_;
  delete item_guarantee_deliver_counter_;
}

bool MediaQuantityInfoDict::ParseFromYAML(const YAML::Node & node, MediaQuantityInfo* media_quantity_info) {
  if (node.Type() != YAML::NodeType::Map) {
    LOG(WARNING) << "Yaml node format error: not Map";
    return false;
  }

  if (!node.FindValue("source")) {
    VLOG(1) << "source not found";
    return false;
  }

  std::string source_level_str;
  static std::unordered_map<std::string, int64> source_level_dict = {
    {"未评级",   static_cast<int64>(reco::dm::kSourceLevelUnknown)},
    {"D",       static_cast<int64>(reco::dm::kSourceLevelD)},
    {"C",       static_cast<int64>(reco::dm::kSourceLevelC)},
    {"B",       static_cast<int64>(reco::dm::kSourceLevelB)},
    {"A",       static_cast<int64>(reco::dm::kSourceLevelA)},
    {"S",       static_cast<int64>(reco::dm::kSourceLevelS)},
  };

  // String 列表类型 map
  std::unordered_map<std::string, std::string*> map_string = {
    std::make_pair<std::string, std::string*>("source", &media_quantity_info->source),
    std::make_pair<std::string, std::string*>("level", &source_level_str),
  };
  // Int64 列表类型 map
  std::unordered_map<std::string, int64*> map_int64 = {
    std::make_pair<std::string, int64*>("protect_type", &media_quantity_info->protect_type),
    std::make_pair<std::string, int64*>("protect_capacity", &media_quantity_info->protect_capacity),
    std::make_pair<std::string, int64*>("deliever_num_avg_7d",
                                        &media_quantity_info->expect_daily_deliever_num),
  };

  // String 列表类型解析
  for (auto iter = map_string.begin(); iter != map_string.end(); ++iter) {
    if (!node.FindValue(iter->first)) {
      continue;
    }

    std::string pattern;
    if (!MediaQuantityInfoDict::GetYamlNodeString(node[iter->first], &pattern)) {
      continue;
    }
    *iter->second = pattern;
    VLOG(1) << iter->first << ":" << *iter->second;
  }

  // Int64 列表类型解析
  for (auto iter = map_int64.begin(); iter != map_int64.end(); ++iter) {
    if (!node.FindValue(iter->first)) {
      continue;
    }

    std::string pattern;
    if (!MediaQuantityInfoDict::GetYamlNodeString(node[iter->first], &pattern)) {
      continue;
    }
    if (!base::StringToInt64(pattern, iter->second)) {
      *iter->second = 0;
    }
    VLOG(1) << iter->first << ":" << *iter->second;
  }

  // 对种子源做签名
  media_quantity_info->UpdateSign();

  // 将种子源评级转换为枚举类型，方便后续逻辑
  if (source_level_dict.find(source_level_str) == source_level_dict.end()) {
    VLOG(1) << "source_level not found:" << source_level_str;
    return false;
  }
  media_quantity_info->source_level = source_level_dict[source_level_str];

  std::string debug_string_categories;
  if (node.FindValue("category")) {
    const YAML::Node& category_nodes = node["category"];
    if (category_nodes.Type() != YAML::NodeType::Sequence) {
      LOG(WARNING) << "Yaml node format error: not Sequence, category";
      return false;
    }
    for (auto i = 0u; i < category_nodes.size(); ++i) {
      std::string pattern;
      if (!MediaQuantityInfoDict::GetYamlNodeString(category_nodes[i], &pattern)) {
        continue;
      }
      VLOG(1) << "category " << i << ": " << pattern;
      media_quantity_info->category.insert(pattern);
      debug_string_categories += pattern;
      debug_string_categories += ",";
    }
  }

  VLOG(2) << "media_quantity_info load:"
          << " source:" << media_quantity_info->source
          << ", source_sign:" << media_quantity_info->source_sign
          << ", protect_type:" << media_quantity_info->protect_type
          << ", protect_capacity:" << media_quantity_info->protect_capacity
          << ", expect_daily_deliever_num:" << media_quantity_info->expect_daily_deliever_num
          << ", source_level:" << media_quantity_info->source_level
          << ", deliever_num:" << media_quantity_info->deliever_num
          << ", assurance_deliever_num:" << media_quantity_info->assurance_deliever_num
          << ", categories:" << debug_string_categories;
  return true;
}


void MediaQuantityInfoDict::GetLimitOfItem(const reco::dm::MediaQuantityType & type,
                                           int64 source_level,
                                           int64* limit) {
  *limit = 0;
  static std::unordered_map<int64, int64> manual_video_limit = {
    {static_cast<int64>(reco::dm::kSourceLevelS),       580000},
    {static_cast<int64>(reco::dm::kSourceLevelA),       460000},
    {static_cast<int64>(reco::dm::kSourceLevelB),       240000},
    {static_cast<int64>(reco::dm::kSourceLevelC),       120000},
    {static_cast<int64>(reco::dm::kSourceLevelUnknown), 120000},
    {static_cast<int64>(reco::dm::kSourceLevelD),       6000},
  };
  static std::unordered_map<int64, int64> manual_doc_limit = {
    {static_cast<int64>(reco::dm::kSourceLevelS),       580000},
    {static_cast<int64>(reco::dm::kSourceLevelA),       460000},
    {static_cast<int64>(reco::dm::kSourceLevelB),       240000},
    {static_cast<int64>(reco::dm::kSourceLevelC),       120000},
    {static_cast<int64>(reco::dm::kSourceLevelUnknown), 120000},
    {static_cast<int64>(reco::dm::kSourceLevelD),       6000},
  };
  static std::unordered_map<int64, int64> beginner_video_limit = {
    {static_cast<int64>(reco::dm::kSourceLevelS),       30000},
    {static_cast<int64>(reco::dm::kSourceLevelA),       25000},
    {static_cast<int64>(reco::dm::kSourceLevelB),       15000},
    {static_cast<int64>(reco::dm::kSourceLevelC),       5000},
    {static_cast<int64>(reco::dm::kSourceLevelUnknown), 5000},
    {static_cast<int64>(reco::dm::kSourceLevelD),       3000},
  };
  static std::unordered_map<int64, int64> beginner_doc_limit = {
    {static_cast<int64>(reco::dm::kSourceLevelS),       23000},
    {static_cast<int64>(reco::dm::kSourceLevelA),       18000},
    {static_cast<int64>(reco::dm::kSourceLevelB),       10000},
    {static_cast<int64>(reco::dm::kSourceLevelC),       3000},
    {static_cast<int64>(reco::dm::kSourceLevelUnknown), 3000},
    {static_cast<int64>(reco::dm::kSourceLevelD),       2000},
  };
  switch (type) {
    case reco::dm::kMediaVideoManual:
      if (manual_video_limit.find(source_level) != manual_video_limit.end()) {
        *limit = manual_video_limit[source_level];
      }
      break;
    case reco::dm::kMediaVideoBeginner:
      if (beginner_video_limit.find(source_level) != beginner_video_limit.end()) {
        *limit = beginner_video_limit[source_level];
      }
      break;
    case reco::dm::kMediaDocManual:
      if (manual_doc_limit.find(source_level) != manual_doc_limit.end()) {
        *limit = manual_doc_limit[source_level];
      }
      break;
    case reco::dm::kMediaDocBeginner:
      if (beginner_doc_limit.find(source_level) != beginner_doc_limit.end()) {
        *limit = beginner_doc_limit[source_level];
      }
      break;
    default:
      break;
  };
}


bool MediaQuantityInfoDict::CalcItemQuantityScore(const MediaQuantityInfo & media_info,
                                                  const ItemInfo & item,
                                                  int64 item_limit,
                                                  double* score) {
  if (media_info.deliever_num < media_info.protect_capacity && item.show_num < item_limit) {
    *score = std::pow(media_info.protect_capacity - media_info.deliever_num,
                      FLAGS_media_quantity_deliever_weight)
             * std::pow(item.ctr, FLAGS_media_quantity_ctr_weight)
             * std::pow(media_info.expect_daily_deliever_num > 0?
                        (1 / media_info.expect_daily_deliever_num) : 1,
                        FLAGS_media_quantity_expect_deliever_weight)
             * std::pow(item_limit - item.show_num, FLAGS_media_quantity_item_deliever_weight);
    // 符合保量条件，允许入保量队列
    return true;
  }
  return false;
}


bool MediaQuantityInfoDict::GetItemQuantityScore(const std::string & category,
                                                 const QueueType & type,
                                                 const ItemInfo & item,
                                                 double* score) {
  MediaQuantityInfo media_quantity_info;
  int64 item_limit = 0;

  if (!GetItemQuantityInfo(type, item, &media_quantity_info, &item_limit)) {
    return false;
  }
  if (!media_quantity_info.category.empty() && media_quantity_info.category.count(category) == 0) {
    return false;
  }

  int64 source_deliver_num = 0L;
  int64 item_deliver_num = 0L;
  LocalGuaranteeDeliver(item, &source_deliver_num, &item_deliver_num);
  if (type == reco::kQueueDoc) {
    if (source_deliver_num * FLAGS_media_quantity_deliver_machine_num >= media_quantity_info.protect_capacity
        || item_deliver_num * FLAGS_media_quantity_deliver_machine_num >= item_limit) {
      return false;
    }
  } else if (type == reco::kQueueVideo) {
    if (source_deliver_num * FLAGS_video_guarantee_machine_num >= media_quantity_info.protect_capacity
        || item_deliver_num * FLAGS_video_guarantee_machine_num >= item_limit) {
      return false;
    }
  }

  return CalcItemQuantityScore(media_quantity_info, item, item_limit, score);
}


bool MediaQuantityInfoDict::GetItemQuantityInfo(const QueueType & type,
                                                const ItemInfo & item,
                                                MediaQuantityInfo* media_quantity_info,
                                                int64* item_limit) {
  bool ret = false;
  auto dict = DM_GET_DICT(reco::dm::MediaQuantityInfoDict,
                          reco::IndexDynamicDictContainer::kMediaQuantityInfoFile_);
  auto it_map = dict->find(item.source_sign);
  if (it_map == dict->end()) {
    VLOG(1) << "item source not found:" << item.item_id
            << ", source_sign:" << item.source_sign;
    return false;
  }

  media_quantity_info->Clear();
  if (type == kQueueVideo) {
    auto it_quant_info = it_map->second.find(reco::dm::kMediaVideoManual);
    if (it_quant_info != it_map->second.end()) {
      // 视频运营保量信息
      *media_quantity_info = it_quant_info->second;
      GetLimitOfItem(reco::dm::kMediaVideoManual, media_quantity_info->source_level, item_limit);
      ret = true;
    } else {
      it_quant_info =  it_map->second.find(reco::dm::kMediaVideoBeginner);
      if (it_quant_info != it_map->second.end()) {
        // 视频新手保量信息
        *media_quantity_info = it_quant_info->second;
        GetLimitOfItem(reco::dm::kMediaVideoBeginner, media_quantity_info->source_level, item_limit);
        ret = true;
      }
    }
  } else if (type == kQueueDoc) {
    auto it_quant_info = it_map->second.find(reco::dm::kMediaDocManual);
    if (it_quant_info != it_map->second.end()) {
      // 图文运营保量信息
      *media_quantity_info = it_quant_info->second;
      GetLimitOfItem(reco::dm::kMediaDocManual, media_quantity_info->source_level, item_limit);
      ret = true;
    } else {
      it_quant_info =  it_map->second.find(reco::dm::kMediaDocBeginner);
      if (it_quant_info != it_map->second.end()) {
        // 图文新手保量信息
        *media_quantity_info = it_quant_info->second;
        GetLimitOfItem(reco::dm::kMediaDocBeginner, media_quantity_info->source_level, item_limit);
        ret = true;
      }
    }
  }

  // 获取媒体保量的 Meta 流信息
  if (!GetQuantityMetaInfo(type, item.source_sign, media_quantity_info)) {
    VLOG(1) << "item quantity meta not found:" << item.item_id
            << ", source_sign:" << item.source_sign;
    ret = false;
  }

  VLOG(2) << "item quantity info found:" << item.item_id
          << ", source:" << media_quantity_info->source
          << ", source_sign:" << media_quantity_info->source_sign
          << ", protect_type:" << media_quantity_info->protect_type
          << ", protect_capacity:" << media_quantity_info->protect_capacity
          << ", expect_daily_deliever_num:" << media_quantity_info->expect_daily_deliever_num
          << ", source_level:" << media_quantity_info->source_level
          << ", deliever_num:" << media_quantity_info->deliever_num
          << ", assurance_deliever_num:" << media_quantity_info->assurance_deliever_num;
  return ret;
}


bool MediaQuantityInfoDict::GetQuantityMetaInfo(const QueueType & type,
                                                uint64 source_sign,
                                                MediaQuantityInfo* media_quantity_info) {
  auto it = media_source_meta_dict_.find(source_sign);
  if (it == media_source_meta_dict_.end()) {
    return false;
  }

  // 区分图文、视频的保量下发统计
  if (type == kQueueVideo) {
    media_quantity_info->deliever_num = it->second.video_deliever_num;
    media_quantity_info->assurance_deliever_num = it->second.video_assurance_deliever_num;
  } else if (type == kQueueDoc) {
    media_quantity_info->deliever_num = it->second.news_deliever_num;
    media_quantity_info->assurance_deliever_num = it->second.news_assurance_deliever_num;
  }
  return true;
}

bool MediaQuantityInfoDict::GetYamlNodeString(const YAML::Node & node, std::string* data) {
  if (data == NULL) return false;
  if (node.Type() != YAML::NodeType::Scalar) {
    LOG(WARNING) << "Yaml node format error: not Scalar";
    return false;
  }
  try {
    node >> *data;
  } catch(YAML::ParserException & e) {
    *data = "";
    LOG(WARNING) << "Yaml load failed: " << e.what();
    return false;
  }
  return true;
}


bool MediaQuantityInfoDict::UpdateQuantityMetaInfo(const reco::MediaSourceInfo & meta_source_info) {
  VLOG(1) << "media quantity meta update:" << meta_source_info.Utf8DebugString();
  MediaSourceMetaInfo meta_info(meta_source_info);
  if (meta_info.source == "") {
    return false;
  }
  uint64 source_sign = base::CalcTermSign(meta_info.source.c_str(), meta_info.source.size());
  media_source_meta_dict_[source_sign] = meta_info;
  return true;
}

// int64 MediaQuantityInfoDict::GetGuaranteeQuantityByQueueType() {
//   auto dict = DM_GET_DICT(reco::dm::MediaQuantityInfoDict,
//                           reco::IndexDynamicDictContainer::kMediaQuantityInfoFile_);
//   int64 quantity = 0L;
//   for (auto iter = dict->begin(); iter != dict->end(); ++iter) {
//     auto it_quant_info = iter->second.find(reco::dm::kMediaDocManual);
//     if (it_quant_info != iter->second.end()) {
//       // 图文运营保量信息
//       quantity += it_quant_info->second.protect_capacity;
//     }
//     it_quant_info = iter->second.find(reco::dm::kMediaDocBeginner);
//     if (it_quant_info != iter->second.end()) {
//       // 图文新手保量信息
//       quantity += it_quant_info->second.protect_capacity;
//     }
//   }
//   LOG(INFO) << "guarantee quantity: " << quantity;
//   return quantity;
// }

void MediaQuantityInfoDict::IncGuaranteeDeliver(const ItemInfo& item) {
  int64 count = 0L;
  if (item_guarantee_deliver_counter_->FindSilently(item.item_id, &count)) {
    item_guarantee_deliver_counter_->Add(item.item_id, count + 1);
  } else {
    item_guarantee_deliver_counter_->Add(item.item_id, 1L);
  }
  count = 0L;
  if (media_guarantee_deliver_counter_->FindSilently(item.source_sign, &count)) {
    media_guarantee_deliver_counter_->Add(item.source_sign, count + 1);
  } else {
    media_guarantee_deliver_counter_->Add(item.source_sign, 1L);
  }
}

void MediaQuantityInfoDict::LocalGuaranteeDeliver(const ItemInfo& item,
                                                  int64* source_deliver_num,
                                                  int64* item_deliver_num) {
  if (!item_guarantee_deliver_counter_->FindSilently(item.item_id, item_deliver_num)) {
    (*item_deliver_num) = 0L;
  }
  if (!media_guarantee_deliver_counter_->FindSilently(item.source_sign, source_deliver_num)) {
    (*source_deliver_num) = 0L;
  }
}
}
