#pragma once
#include "reco/base/common/atomic.h"
#include <string>
#include <bitset>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <vector>
#include <utility>
#include <algorithm>
#include "base/common/basic_types.h"
#include "reco/bizc/proto/index_aux_data.pb.h"
// TODO(xx): 这个 dynamic dict 是双 buffer 版本，后续要切换到 dict_manager 下那个
#include "reco/bizc/reco_index_ha3/dynamic_dict.h"
#include "base/thread/thread.h"
#include "base/strings/string_util.h"
#include "base/testing/gtest.h"

namespace base {
class FilePath;
}

namespace reco {

enum {
  // 平台相关的 bit
  kIosBit = 0,
  kAndroidBit = 1,

  // 地域相关的 bit
  kMainCityBit = 2,

  // 渠道相关的 bit
  // 目前就支持以下渠道，其他渠道的需求先看是否可以映射
  kUcwebBit = 3,  // 浏览器相关
  kToutiaoBit = 4,  // uc 头条相关
  kHuaweiBit = 5,  // 华为渠道相关
};

// NOTE： 规则一律以这个 typedef 来表示，不要直接用底层的 bitset
// 因为随着规则的扩展， bitset 的位数会增加，应该对外部使用方透明
typedef std::bitset<128> RuleChain;

/**
 * 使用方法：
 *
 * 1. 规则侧
 *
 * 通过一个或多个 *FilterRule 方法制定规则，放到 FilterRule 的 vector 里
 * 调用 SetFilterRuleChain 生成规则池的 bitset
 *
 * 2. 用户侧
 * 通过 GetAppNameBitPos 获得用户 app name 在内部的 bit 位
 * 通过 SetUserChain 生成用户属性的 bitset
 *
 * 3. 过滤
 *
 * 调用 IsFiltered 判断是否需要过滤
 *
 * NOTE: 这个类十分重要，如果有新增规则等，一定需要补充单测
 */
class FilterRule {
 public:
  explicit FilterRule(const std::string& bitset) : bitset_(bitset) {}
  explicit FilterRule(uint64 val) : bitset_(val) {}
  ~FilterRule() {}

  uint64 val() { return bitset_.to_ulong(); }

  static int GetAppNameBitPos(const std::string& app_name) {
    if (base::LowerCaseEquals(app_name, "uc-iflow")
        || base::LowerCaseEquals(app_name, "webapp")
        || base::LowerCaseEquals(app_name, "uc-ipad-web")
        || base::LowerCaseEquals(app_name, "uc-pc-nav-web")
        || base::LowerCaseEquals(app_name, "uc-pc-tab-web")) {
      return kUcwebBit;
    } else if (base::LowerCaseEquals(app_name, "ucnews-iflow")) {
      return kToutiaoBit;
    } else {
      return -1;
    }
  }

  static void SetFilterRuleChain(const std::vector<FilterRule>& rules,
                                 RuleChain* rule_chain) {
    rule_chain->reset();
    for (size_t i = 0; i < rules.size(); ++i) {
      rule_chain->set(rules[i].bitset_.to_ulong(), 1);
    }
  }

  static void SetUserChain(bool is_ios, bool is_android, bool is_main_city,
                           const std::string& app_name,
                           RuleChain* user_chain) {
    std::vector<uint32> bit_pos;
    if (is_ios) {
      bit_pos.push_back(kIosBit);
    }
    if (is_android) {
      bit_pos.push_back(kAndroidBit);
    }
    if (is_main_city) {
      bit_pos.push_back(kMainCityBit);
    }
    int pos = GetAppNameBitPos(app_name);
    if (pos > 0) {
      bit_pos.push_back(pos);
    }

    std::sort(bit_pos.begin(), bit_pos.end());

    // 总共有 2 ^ bit_pos.size() - 1 种组合， 减去 1 是因为不可能全 0
    int len = bit_pos.size();
    uint64 n = 1 << len;
    user_chain->reset();
    for (uint64 i = 1; i < n; ++i) {
      std::bitset<8> bits;
      for (int j = 0; j < len; ++j) {
        uint64 temp = i;
        if (temp & (1 << j)) {  // 对应位为 1
          bits.set(bit_pos[j], 1);
        }
      }
      user_chain->set(bits.to_ulong(), 1);
    }
  }

  static bool IsFiltered(const RuleChain& user_chain,
                         const RuleChain& rule_chain) {
    RuleChain result = user_chain & rule_chain;
    return result.any();
  }

  static FilterRule GenerateRule(const reco::index_data::SourceBlockRule& rule) {
    bool is_ios = rule.has_os()
        && (base::LowerCaseEquals(rule.os(), "ios")
            || base::LowerCaseEquals(rule.os(), "iphone")
            || base::LowerCaseEquals(rule.os(), "ipad"));
    bool is_android = rule.has_os()
        && base::LowerCaseEquals(rule.os(), "android");
    bool is_main_city = rule.has_block_main_city()
        && rule.block_main_city();
    int app_bit = rule.has_app_name() ?  GetAppNameBitPos(rule.app_name()) : -1;

    uint64 val = 0;
    if (is_ios) {
      val = val | 1 << kIosBit;
    } else if (is_android) {
      val = val | 1 << kAndroidBit;
    }
    if (is_main_city) {
      val = val | 1 << kMainCityBit;
    }
    if (app_bit > 0) {
      val = val | 1 << app_bit;
    }

    return FilterRule(val);
  }

  // 生成过滤规则
  // 一元规则
  // 过滤所有 ios
  static FilterRule IosFilterRule() {
    return FilterRule(1 << kIosBit);
  }

  // 过滤所有 android
  static FilterRule AndroidFilterRule() {
    return FilterRule(1 << kAndroidBit);
  }

  // 过滤所有一线城市
  static FilterRule MainCityFilterRule() {
    return FilterRule(1 << kMainCityBit);
  }

  // 过滤指定 app name
  static FilterRule AppNameFilterRule(int app_bitpos) {
    return FilterRule(1 << app_bitpos);
  }

  // 二元规则
  // 过滤 ios 的一线城市
  static FilterRule IosMainCityFilterRule() {
    return FilterRule((1 << kMainCityBit) | (1 << kIosBit));
  }
  // 过滤 android 的一线城市
  static FilterRule AndroidMainCityFilterRule() {
    return FilterRule((1 << kMainCityBit) | (1 << kAndroidBit));
  }
  // 过滤指定 appname 的一线城市
  static FilterRule AppNameIosFilterRule(int app_bitpos) {
    FilterRule rule = IosFilterRule();
    rule.set(app_bitpos, 1);
    return rule;
  }
  // 过滤指定 appname 的一线城市
  static FilterRule AppNameAndroidFilterRule(int app_bitpos) {
    FilterRule rule = AndroidFilterRule();
    rule.set(app_bitpos, 1);
    return rule;
  }
  // 过滤 ios 的一线城市
  static FilterRule AppNameMainCityFilterRule(int app_bitpos) {
    FilterRule rule = MainCityFilterRule();
    rule.set(app_bitpos, 1);
    return rule;
  }

  // 三元规则
  // 过滤指定 appname ios 的一线城市
  static FilterRule AppNameIosMainCityFilterRule(int app_bitpos) {
    FilterRule rule = IosMainCityFilterRule();
    rule.set(app_bitpos, 1);
    return rule;
  }
  // 过滤指定 appname android 的一线城市
  static FilterRule AppNameAndroidMainCityFilterRule(int app_bitpos) {
    FilterRule rule = AndroidMainCityFilterRule();
    rule.set(app_bitpos, 1);
    return rule;
  }

 private:
  void set(int pos, int val) { bitset_.set(pos, val); }

  // 目前规则下， 8 bit 够用了
  std::bitset<8> bitset_;
};
}
