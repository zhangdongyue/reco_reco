#include "reco/bizc/reco_index_ha3/subscribe_channel.h"

#include <string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <utility>
#include "base/common/basic_types.h"
#include "base/file/memory_mapped_file.h"
#include "base/encoding/line_escape.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/thread.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/proto/index_aux_data.pb.h"
#include "reco/bizc/reco_index_ha3/news_index_ha3.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

namespace reco {

const int64 SubscribeChannel::kSubscribeChannelIds[] = {27254244, 23154031, 1404457531636};

SubscribeChannel::SubscribeChannel(const NewsIndex* news_index) {
  news_index_ = news_index;
  InitChannelWords();
}

void SubscribeChannel::UpdateSubscribeResult() {
  Clear();
  for (auto it_ch = channel_words_.begin(); it_ch != channel_words_.end(); ++it_ch) {
    const std::vector<std::string>& words = it_ch->second;
    std::vector<int32> total_docs;
    for (int i = 0; i < (int)words.size(); ++i) {
      std::vector<int32> doc_ids;
      news_index_->GetDocsByKeywordOrTag(words[i], &doc_ids);
      // 类别控制通过 leaf 的现有机制来做
      int index = 0;
      std::vector<std::string> cates;
      std::vector<int64> regions;
      for (int j = 0; j < (int)doc_ids.size(); ++j) {
        int id = doc_ids[j];
        cates.clear();
        regions.clear();

        if (news_index_->GetRestrictRegionIdByDocId(id, &regions)
            && !regions.empty()) {
          // 存在地域限制
          continue;
        }

        if (!news_index_->GetCategoriesByDocId(id, &cates) ||
            cates.empty()) {
          continue;
        }
        bool pass_cate_check = false;
        if (it_ch->first == 27254244) {
          if ((cates.size() == 1u && cates[0] == "体育")
              || (cates.size() == 2u && cates[0] == "体育" && cates[1] == "国际足球")) {
            pass_cate_check = true;
          }
        } else if (it_ch->first == 23154031) {
          if (cates[0] == "体育" || cates[0] == "社会" || cates[0] == "国际") {
            pass_cate_check = true;
          }
        } else {
          pass_cate_check = true;
        }
        if (pass_cate_check) {
          if (index != j) {
            std::swap(doc_ids[index], doc_ids[j]);
          }
          ++index;
        } else {
          // check with title
          uint64 item_id;
          std::string title;
          if (news_index_->GetItemIdByDocId(id, &item_id)
              && news_index_->GetItemTitleByItemId(item_id, &title)) {
            if (title.find(words[i]) != std::string::npos) {
              if (index != j) {
                std::swap(doc_ids[index], doc_ids[j]);
              }
              ++index;
            }
          }
        }
      }
      doc_ids.resize(index);
      if (total_docs.empty()) {
        std::swap(total_docs, doc_ids);
      } else {
        std::vector<int32> tmp_ids;
        tmp_ids.resize(doc_ids.size() + total_docs.size());
        std::merge(doc_ids.begin(), doc_ids.end(),
                   total_docs.begin(), total_docs.end(),
                   tmp_ids.begin());
        auto it = std::unique(tmp_ids.begin(), tmp_ids.end());
        tmp_ids.resize(it - tmp_ids.begin());
        std::swap(tmp_ids, total_docs);
      }
    }
    std::unordered_set<int32> set(total_docs.begin(), total_docs.end());
    std::swap(channel_docs_[it_ch->first], set);
  }

  for (auto it = channel_docs_.begin(); it != channel_docs_.end(); ++it) {
    LOG(INFO) << "channel: " << it->first << ", " << it->second.size();
  }
}

bool SubscribeChannel::GetSubsChannelIds(int32 doc_id, std::unordered_set<int64> *channel_ids) {
  if (channel_ids == NULL) return false;
  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(kSubscribeChannelIds); ++i) {
    int64 chid = kSubscribeChannelIds[i];
    if (IsSubscribed(chid, doc_id)) {
      channel_ids->insert(chid);
    }
  }
  return true;
}
}
