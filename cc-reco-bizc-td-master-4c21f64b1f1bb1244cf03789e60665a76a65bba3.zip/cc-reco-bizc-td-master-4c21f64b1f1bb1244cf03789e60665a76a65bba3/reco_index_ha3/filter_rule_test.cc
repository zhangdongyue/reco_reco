#include <vector>
#include <string>
#include <fstream>
#include <set>

#include "reco/bizc/reco_index_ha3/filter_rule.h"
#include "base/file/file_util.h"
#include "base/encoding/line_escape.h"
#include "base/time/scoped_timer.h"

namespace reco {

TEST(FilterRuleTest, rule) {
  FilterRule r1(std::string("1001011"));
  ASSERT_EQ(r1.val(), 75ul);
  FilterRule r2(1 << 7);
  ASSERT_EQ(r2.val(), 128ul);
  FilterRule r3(1 << 0);
  ASSERT_EQ(r3.val(), 1ul);
}

TEST(FilterRuleTest, GetAppNameBit) {
  ASSERT_EQ(FilterRule::GetAppNameBitPos("uc-iflow"), kUcwebBit);
  ASSERT_EQ(FilterRule::GetAppNameBitPos("webapp"), kUcwebBit);
  ASSERT_EQ(FilterRule::GetAppNameBitPos("uc-ipad-web"), kUcwebBit);
  ASSERT_EQ(FilterRule::GetAppNameBitPos("uc-pc-nav-web"), kUcwebBit);
  ASSERT_EQ(FilterRule::GetAppNameBitPos("uc-pc-tab-web"), kUcwebBit);

  ASSERT_EQ(FilterRule::GetAppNameBitPos("ucnews-iflow"), kToutiaoBit);

  ASSERT_EQ(FilterRule::GetAppNameBitPos("huawei-iflow"), kHuaweiBit);
}

TEST(FilterRuleTest, UserChain) {
  RuleChain chain;
  // ios, main city, webapp
  // 全部条件命中为1101， 部分条件命中会转换成  -->  // NOLINT
  // 1101(13), 0101(5), 1001(9), 1100(12),
  // 0001(1), 1000(8), 0100(4)
  FilterRule::SetUserChain(true, false, true, "webapp", &chain);
  ASSERT_EQ(RuleChain(std::string("11001100110010")), chain);

  // android, main city, webapp
  // 全部条件命中为1110， 部分条件命中会转换成  -->  // NOLINT
  // 1110(14), 0110(6), 1010(10), 1100(12),
  // 1000(8), 0010(2), 0100(4)
  FilterRule::SetUserChain(false, true, true, "webapp", &chain);
  ASSERT_EQ(RuleChain(std::string("101010101010100")), chain);
}

static void AddToRuleChains(const FilterRule& rule, std::vector<RuleChain>* chains) {
  std::vector<FilterRule> rules;
  rules.push_back(rule);
  chains->push_back(RuleChain());
  FilterRule::SetFilterRuleChain(rules, &(chains->back()));
}

TEST(FilterRuleTest, SingleRules) {
  std::vector<RuleChain> chains;

  AddToRuleChains(FilterRule::IosFilterRule(), &chains);
  AddToRuleChains(FilterRule::AndroidFilterRule(), &chains);
  AddToRuleChains(FilterRule::MainCityFilterRule(), &chains);
  AddToRuleChains(FilterRule::AppNameFilterRule(kUcwebBit), &chains);
  AddToRuleChains(FilterRule::AppNameFilterRule(kToutiaoBit), &chains);
  AddToRuleChains(FilterRule::AppNameFilterRule(kHuaweiBit), &chains);

  struct {
    bool is_ios;
    bool is_android;
    bool is_main_city;
    std::string app_name;
  } cases[] = {
    {true,  false, true,  "uc-iflow"},
    {false, true,  true,  "uc-iflow"},
    {false, true,  false, "uc-iflow"},
    {true,  false, true,  "ucnews-iflow"},
    {false, false, true,  "ucnews-iflow"},
    {false, true,  false, "ucnews-iflow"},
    {true,  false, false,  "huawei-iflow"},
    {false, false, true,  "huawei-iflow"},
    {false, true,  false, "huawei-iflow"},
  };

  // ios, android, main_city, iflow, news, huawei
  bool results[][6] = {
    {true, false, true, true, false, false},
    {false, true, true, true, false, false},
    {false, true, false, true, false, false},
    {true, false, true, false, true, false},
    {false, false, true, false, true, false},
    {false, true, false, false, true, false},
    {true, false, false, false, false, true},
    {false, false, true, false, false, true},
    {false, true, false, false, false, true},
  };

  int n = ARRAYSIZE_UNSAFE(cases);
  ASSERT_EQ(ARRAYSIZE_UNSAFE(cases), ARRAYSIZE_UNSAFE(results));

  // clear value in redis
  for (int i = 0; i < n; ++i) {
    RuleChain user_chain;
    FilterRule::SetUserChain(cases[i].is_ios,
                             cases[i].is_android,
                             cases[i].is_main_city,
                             cases[i].app_name,
                             &user_chain);
    for (int j = 0; j < (int)chains.size(); ++j) {
      ASSERT_EQ(FilterRule::IsFiltered(user_chain, chains[j]),
                results[i][j]) << i << ":" << j;
    }
  }
}

TEST(FilterRuleTest, DoubleRules) {
  std::vector<RuleChain> chains;
  AddToRuleChains(FilterRule::IosMainCityFilterRule(), &chains);
  AddToRuleChains(FilterRule::AndroidMainCityFilterRule(), &chains);
  AddToRuleChains(FilterRule::AppNameIosFilterRule(kUcwebBit), &chains);
  AddToRuleChains(FilterRule::AppNameIosFilterRule(kToutiaoBit), &chains);
  AddToRuleChains(FilterRule::AppNameIosFilterRule(kHuaweiBit), &chains);
  AddToRuleChains(FilterRule::AppNameAndroidFilterRule(kUcwebBit), &chains);
  AddToRuleChains(FilterRule::AppNameAndroidFilterRule(kToutiaoBit), &chains);
  AddToRuleChains(FilterRule::AppNameAndroidFilterRule(kHuaweiBit), &chains);
  AddToRuleChains(FilterRule::AppNameMainCityFilterRule(kUcwebBit), &chains);
  AddToRuleChains(FilterRule::AppNameMainCityFilterRule(kToutiaoBit), &chains);
  AddToRuleChains(FilterRule::AppNameMainCityFilterRule(kHuaweiBit), &chains);

  struct {
    bool is_ios;
    bool is_android;
    bool is_main_city;
    std::string app_name;
  } cases[] = {
    {true,  false, true,  "uc-iflow"},
    {false, true,  true,  "uc-iflow"},
    {false, true,  false, "uc-iflow"},

    {true,  false, false,  "ucnews-iflow"},
    {false, false, true,  "ucnews-iflow"},
    {false, true,  false, "ucnews-iflow"},

    {true,  false, true,  "huawei-iflow"},
    {true, false, false,  "huawei-iflow"},
    {false, true,  true, "huawei-iflow"},
  };

  // ios_city, android_city,
  // iflow_ios, news_ios, huawei_ios,
  // iflow_android, news_android, huawei_android
  // iflow_city, news_city, huawei_city
  bool results[][11] = {
    {true, false, true, false, false, false, false, false, true, false, false},
    {false, true, false, false, false, true, false, false, true, false, false},
    {false, false, false, false, false, true, false, false, false, false, false},

    {false, false, false, true, false, false, false, false, false, false, false},
    {false, false, false, false, false, false, false, false, false, true, false},
    {false, false, false, false, false, false, true, false, false, false, false},

    {true, false, false, false, true, false, false, false, false, false, true},
    {false, false, false, false, true, false, false, false, false, false, false},
    {false, true, false, false, false, false, false, true, false, false, true},
  };

  int n = ARRAYSIZE_UNSAFE(cases);
  ASSERT_EQ(ARRAYSIZE_UNSAFE(cases), ARRAYSIZE_UNSAFE(results));

  // clear value in redis
  for (int i = 0; i < n; ++i) {
    RuleChain user_chain;
    FilterRule::SetUserChain(cases[i].is_ios,
                             cases[i].is_android,
                             cases[i].is_main_city,
                             cases[i].app_name,
                             &user_chain);
    for (int j = 0; j < (int)chains.size(); ++j) {
    ASSERT_EQ(FilterRule::IsFiltered(user_chain, chains[j]),
              results[i][j]) << i << ":" << j;
    }
  }
}

TEST(FilterRuleTest, TripleRules) {
  std::vector<RuleChain> chains;
  AddToRuleChains(FilterRule::AppNameIosMainCityFilterRule(kUcwebBit), &chains);
  AddToRuleChains(FilterRule::AppNameIosMainCityFilterRule(kToutiaoBit), &chains);
  AddToRuleChains(FilterRule::AppNameIosMainCityFilterRule(kHuaweiBit), &chains);
  AddToRuleChains(FilterRule::AppNameAndroidMainCityFilterRule(kUcwebBit), &chains);
  AddToRuleChains(FilterRule::AppNameAndroidMainCityFilterRule(kToutiaoBit), &chains);
  AddToRuleChains(FilterRule::AppNameAndroidMainCityFilterRule(kHuaweiBit), &chains);

  struct {
    bool is_ios;
    bool is_android;
    bool is_main_city;
    std::string app_name;
  } cases[] = {
    {true,  false, true,  "uc-iflow"},
    {false, true,  true,  "uc-iflow"},
    {false, true,  false, "uc-iflow"},

    {true,  false, false, "ucnews-iflow"},
    {false, false, true,  "ucnews-iflow"},
    {false, true,  false, "ucnews-iflow"},

    {true,  false, true, "huawei-iflow"},
    {false, false, false,  "huawei-iflow"},
    {false, true,  true, "huawei-iflow"},
  };

  // ios_city_iflow
  // ios_city_news
  // ios_city_huawei
  // android_city_iflow
  // android_city_news
  // android_city_huawei
  bool results[][6] = {
    {true, false, false, false, false, false},
    {false, false, false, true, false, false},
    {false, false, false, false, false, false},

    {false, false, false, false, false, false},
    {false, false, false, false, false, false},
    {false, false, false, false, false, false},

    {false, false, true, false, false, false},
    {false, false, false, false, false, false},
    {false, false, false, false, false, true},
  };

  int n = ARRAYSIZE_UNSAFE(cases);
  ASSERT_EQ(ARRAYSIZE_UNSAFE(cases), ARRAYSIZE_UNSAFE(results));

  for (int i = 0; i < n; ++i) {
    RuleChain user_chain;
    FilterRule::SetUserChain(cases[i].is_ios,
                             cases[i].is_android,
                             cases[i].is_main_city,
                             cases[i].app_name,
                             &user_chain);
    for (int j = 0; j < (int)chains.size(); ++j) {
    ASSERT_EQ(FilterRule::IsFiltered(user_chain, chains[j]),
              results[i][j]) << i << ":" << j;
    }
  }
}

TEST(FilterRuleTest, ComplexRule) {
  // block ios
  FilterRule r1 = FilterRule::IosFilterRule();
  // block android main city
  FilterRule r2 = FilterRule::AndroidMainCityFilterRule();

  int app = FilterRule::GetAppNameBitPos("uc-iflow");
  ASSERT_EQ(app, kUcwebBit);
  // block uc-iflow
  FilterRule r3 = FilterRule::AppNameFilterRule(app);

  std::vector<FilterRule> rules;
  rules.push_back(r1);
  rules.push_back(r2);
  rules.push_back(r3);

  RuleChain rule_chain;
  FilterRule::SetFilterRuleChain(rules, &rule_chain);

  struct {
    bool is_ios;
    bool is_android;
    bool is_main_city;
    std::string app_name;
    bool filtered;
  } cases[] = {
    {true, false, true, "uc-iflow", true},
    {false, true, true, "uc-iflow", true},
    {false, true, false, "uc-iflow", true},
    {true, false, true, "ucnews-iflow", true},
    {false, true, true, "ucnews-iflow", true},
    {false, true, false, "ucnews-iflow", false},
  };
  int n = ARRAYSIZE_UNSAFE(cases);
  // clear value in redis
  for (int i = 0; i < n; ++i) {
    RuleChain user_chain;
    FilterRule::SetUserChain(cases[i].is_ios,
                             cases[i].is_android,
                             cases[i].is_main_city,
                             cases[i].app_name,
                             &user_chain);
    // LOG(ERROR) << "user chain: " << user_chain.to_string() << " "
    //     << "rule chain: " << rule_chain.to_string();
    ASSERT_EQ(FilterRule::IsFiltered(user_chain, rule_chain),
              cases[i].filtered) << i;
  }
}

TEST(FilterRuleTest, SourceBlockRule) {
  // 测试 SourceBlockRule 翻译成 FilterRule 是否正确
  {
    reco::index_data::SourceBlockRule rule;
    FilterRule r = FilterRule::GenerateRule(rule);
    ASSERT_EQ(r.val(), 0u);
  }
  {
    reco::index_data::SourceBlockRule rule;
    rule.set_os("Ios");
    FilterRule r1 = FilterRule::GenerateRule(rule);
    FilterRule r2 = FilterRule::IosFilterRule();
    ASSERT_EQ(r1.val(), r2.val());
  }
  {
    reco::index_data::SourceBlockRule rule;
    rule.set_os("webapp");
    rule.set_app_name("webapp");
    FilterRule r1 = FilterRule::GenerateRule(rule);
    FilterRule r2 = FilterRule::AppNameFilterRule(kUcwebBit);
    ASSERT_EQ(r1.val(), r2.val());
  }
  {
    reco::index_data::SourceBlockRule rule;
    rule.set_block_main_city(true);
    rule.set_app_name("webapp");
    FilterRule r1 = FilterRule::GenerateRule(rule);
    FilterRule r2 = FilterRule::AppNameMainCityFilterRule(kUcwebBit);
    ASSERT_EQ(r1.val(), r2.val());
  }
  {
    reco::index_data::SourceBlockRule rule;
    rule.set_os("android");
    rule.set_block_main_city(true);
    rule.set_app_name("huawei-iflow");
    FilterRule r1 = FilterRule::GenerateRule(rule);
    FilterRule r2 = FilterRule::AppNameAndroidMainCityFilterRule(kHuaweiBit);
    ASSERT_EQ(r1.val(), r2.val());
  }
}

TEST(FilterRuleTest, Perf) {
  // 模拟一个队列中的 item 每个都挂了若干规则
  // block ios
  FilterRule r1 = FilterRule::IosFilterRule();
  // block android main city
  FilterRule r2 = FilterRule::AndroidMainCityFilterRule();
  // block uc-iflow
  FilterRule r3 = FilterRule::AppNameFilterRule(kUcwebBit);

  std::vector<FilterRule> rules;
  rules.push_back(r1);
  rules.push_back(r2);
  rules.push_back(r3);

  RuleChain rule_chain;
  FilterRule::SetFilterRuleChain(rules, &rule_chain);

  RuleChain user_chain;
  FilterRule::SetUserChain(true, false, true, "uc-iflow", &user_chain);
  {
    base::ScopedTimer timer("the running time is: ");
    for (int i = 0; i < 10000; ++i) {
      FilterRule::IsFiltered(user_chain, rule_chain);
    }
  }
}
}  // namespace reco
