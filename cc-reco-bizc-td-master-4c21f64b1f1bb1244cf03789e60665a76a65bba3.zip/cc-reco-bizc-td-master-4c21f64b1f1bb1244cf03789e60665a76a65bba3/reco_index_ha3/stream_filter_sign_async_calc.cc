#include "reco/bizc/reco_index_ha3/stream_filter_sign_async_calc.h"
#include "base/strings/string_number_conversions.h"
#include "base/time/timestamp.h"
#include "base/time/time.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace filter {

StreamFilterSignAsyncCalc::StreamFilterSignAsyncCalc(reco::NewsIndex* index) {
  news_index_ = index;
}

StreamFilterSignAsyncCalc::~StreamFilterSignAsyncCalc() {
}

bool StreamFilterSignAsyncCalc::IsItemFiltered(const BitList req_bit, const ItemInfo& item, bool is_debug,
                                               BitList* rule_mask,
                                               BitList* filtered_bit,
                                               std::string* key) {
  const std::vector<FilterStrategy>* strategy = &(item.info_full_ptr->filter_strategy());
  if (strategy == NULL || strategy->size() == 0) {
    return false;
  }

  for (auto i = 0u; i < strategy->size(); ++i) {
    auto& rule = strategy->at(i);
    BitList maskbit = req_bit & rule.mask;
    for (auto j = 0u; j < rule.filter_values.size(); ++j) {
      if (maskbit == rule.filter_values.at(j)) {
        if (is_debug) {
          if (filtered_bit != NULL) {
            *filtered_bit = rule.filter_values.at(j);
          }
          if (rule_mask != NULL) {
            *rule_mask = rule.mask;
          }
          if (key != NULL) {
            *key = rule.key;
          }
        }
        return true;
      }
    }
  }
  return false;
}

void StreamFilterSignAsyncCalc::ProcessSingleDoc(const ItemInfoFullPtr& p
  , const StreamFilterDict* dict
  , std::vector<FilterStrategy>* strategy) {
  uint64 item_id = p->item_id();

  for (auto i = 0u; i < dict->filter_configs.size(); ++i) {
    auto& config = dict->filter_configs.at(i);
    // 如果 item 的属性命中筛选条件, 那么将预处理好的 strategy 加入
    // 通过 key 来识别是否有重复的 strategy, 若重复则不需要加入
    if (MatchConditionHit(p, &config.conditions)) {
      VLOG(1) << "item_id : " << item_id
              << " hit by condition idx : " << i;
      bool bfind = false;
      for (auto j = 0u; j < strategy->size(); ++j) {
        if (strategy->at(j).key == config.strategy.key) {
          bfind = true;
          break;
        }
      }
      if (!bfind) {
        strategy->push_back(config.strategy);
        VLOG(1) << "item_id : " << item_id
                << " added filter strategy, key : " << config.strategy.key;
      }
    }
  }
}

bool StreamFilterSignAsyncCalc::MatchConditionHit(const ItemInfoFullPtr& p,
                                                  const std::vector<MatchCondition>* conditions) {
  if (conditions == NULL || conditions->size() == 0) {
    return false;
  }
  for (auto i = 0u; i < conditions->size(); ++i) {
    auto& condition = conditions->at(i);
    switch (condition.item_attr) {
      case kItemAttrNeg:
        {
          reco::ContentAttr content_attr;
          bool is_trival = false;
          if (!p->content_attr_pb(&content_attr, &is_trival) ||
              is_trival) {
            return false;
          }
          if (!content_attr.has_negative()) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ContentAttr::ContentAttrLevel)value == content_attr.negative()) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrDirty:
        {
          reco::ContentAttr content_attr;
          bool is_trival = false;
          if (!p->content_attr_pb(&content_attr, &is_trival) ||
              is_trival) {
            return false;
          }
          if (!content_attr.has_dirty()) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ContentAttr::ContentAttrLevel)value == content_attr.dirty()) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrTitleParty:
        {
          reco::ContentAttr content_attr;
          bool is_trival = false;
          if (!p->content_attr_pb(&content_attr, &is_trival) ||
              is_trival) {
            return false;
          }
          if (!content_attr.has_bluffing_title()) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ContentAttr::ContentAttrLevel)value == content_attr.bluffing_title()) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrPolitics:
        {
          reco::ContentAttr content_attr;
          bool is_trival = false;
          if (!p->content_attr_pb(&content_attr, &is_trival) ||
              is_trival) {
            return false;
          }
          if (!content_attr.has_politics()) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ContentAttr::ContentAttrLevel)value == content_attr.politics()) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrLowQuality:
        {
          reco::ContentAttr content_attr;
          bool is_trival = false;
          if (!p->content_attr_pb(&content_attr, &is_trival) ||
              is_trival) {
            return false;
          }
          if (!content_attr.has_erro_title() &&
              !content_attr.has_advertorial() &&
              !content_attr.has_short_content() &&
              !content_attr.has_dedup_paragraph()) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((content_attr.has_erro_title() &&
                   (reco::ContentAttr::ContentAttrLevel)value == content_attr.erro_title())
                  || (content_attr.has_advertorial() &&
                      (reco::ContentAttr::ContentAttrLevel)value == content_attr.advertorial())
                  || (content_attr.has_short_content() &&
                      (reco::ContentAttr::ContentAttrLevel)value == content_attr.short_content())
                  || (content_attr.has_dedup_paragraph()
                      && (reco::ContentAttr::ContentAttrLevel)value == content_attr.dedup_paragraph())) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrFirstCate:
        {
          auto categories = p->categories();
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            std::string value = condition.match_values.at(j);
            if (categories.size() > 0u) {
              if (categories.at(0) == value) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrFirstCateNot:
        {
          auto categories = p->categories();
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            std::string value = condition.match_values.at(j);
            if (categories.size() > 0u) {
              if (categories.at(0) == value) {
                return false;
              }
            }
          }
        }
        break;
      case kItemAttrSecondCate:
        {
          auto categories = p->categories();
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            std::string value = condition.match_values.at(j);
            if (categories.size() > 1u) {
              if (categories.at(1) == value) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrSecondCateNot:
        {
          auto categories = p->categories();
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            std::string value = condition.match_values.at(j);
            if (categories.size() > 1u) {
              if (categories.at(1) == value) {
                return false;
              }
            }
          }
        }
        break;
      case kItemAttrTag:
        {
          reco::FeatureVector fevtag;
          if (!news_index_->GetFeatureVectorByItemInfoFull(p, reco::common::kTag, &fevtag)) {
            return false;
          }
          std::string kTagPrefix = "label:";
          bool bfind = false;
          for (int j = 0; j < fevtag.feature_size(); ++j) {
            std::string tag = fevtag.feature(j).literal();
            if (tag.substr(0, kTagPrefix.length()) == kTagPrefix) {
              tag = tag.substr(kTagPrefix.length(), tag.length() - kTagPrefix.length());
            }
            for (auto k = 0u; k < condition.match_values.size(); ++k) {
              if (tag == condition.match_values.at(k)) {
                bfind = true;
                break;
              }
            }
            if (bfind) {
              break;
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrTagNot:
        {
          reco::FeatureVector fevtag;
          if (!news_index_->GetFeatureVectorByItemInfoFull(p, reco::common::kTag, &fevtag)) {
            return false;
          }
          std::string kTagPrefix = "label:";
          for (int j = 0; j < fevtag.feature_size(); ++j) {
            std::string tag = fevtag.feature(j).literal();
            if (tag.substr(0, kTagPrefix.length()) == kTagPrefix) {
              tag = tag.substr(kTagPrefix.length(), tag.length() - kTagPrefix.length());
            }
            for (auto k = 0u; k < condition.match_values.size(); ++k) {
              if (tag == condition.match_values.at(k)) {
                return false;
              }
            }
          }
        }
        break;
      case kItemAttrSemanticTag:
        {
          reco::FeatureVector fevtag;
          if (!news_index_->GetFeatureVectorByItemInfoFull(p, reco::common::kSemanticTag, &fevtag)) {
            return false;
          }
          std::string kTagPrefix = "label2:";
          bool bfind = false;
          for (int j = 0; j < fevtag.feature_size(); ++j) {
            std::string tag = fevtag.feature(j).literal();
            if (tag.substr(0, kTagPrefix.length()) == kTagPrefix) {
              tag = tag.substr(kTagPrefix.length(), tag.length() - kTagPrefix.length());
            }
            for (auto k = 0u; k < condition.match_values.size(); ++k) {
              if (tag == condition.match_values.at(k)) {
                bfind = true;
                break;
              }
            }
            if (bfind) {
              break;
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrSemanticTagNot:
        {
          reco::FeatureVector fevtag;
          if (!news_index_->GetFeatureVectorByItemInfoFull(p, reco::common::kSemanticTag, &fevtag)) {
            return false;
          }
          std::string kTagPrefix = "label2:";
          for (int j = 0; j < fevtag.feature_size(); ++j) {
            std::string tag = fevtag.feature(j).literal();
            if (tag.substr(0, kTagPrefix.length()) == kTagPrefix) {
              tag = tag.substr(kTagPrefix.length(), tag.length() - kTagPrefix.length());
            }
            for (auto k = 0u; k < condition.match_values.size(); ++k) {
              if (tag == condition.match_values.at(k)) {
                return false;
              }
            }
          }
        }
        break;
      case kItemAttrItemType:
        {
          reco::ItemType item_type = static_cast<reco::ItemType>(p->item_type());
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ItemType)value == item_type) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrItemTypeNot:
        {
          reco::ItemType item_type = static_cast<reco::ItemType>(p->item_type());
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ItemType)value == item_type) {
                return false;
              }
            }
          }
        }
        break;
      case kItemAttrWeMedia:
        {
          if (p->manual_news() > 0) {
            return false;
          }
          int value = -1;
          if (condition.match_values.size() > 0) {
            if (base::StringToInt(condition.match_values.at(0), &value) && value >= 0) {
              std::string producer;
              producer = p->app_token();
              bool is_wemedia = producer == "cp_wemedia_uc" ? true : false;
              if (is_wemedia != value) {
                return false;
              }
            } else {
              return false;
            }
          } else {
            return false;
          }
        }
        break;
      case kItemAttrMediaLevel:
        {
          auto cate_media_level_map = DM_GET_DICT(reco::dm::MediaLevelDict, reco::IndexDynamicDictContainer::kMediaLevelFile_);
          if (cate_media_level_map == NULL) {
            return false;
          }
          reco::MediaLevel media_level;
          std::string cate_media;
          std::string all_media;
          std::string used_media = p->orig_source_media();
          if(used_media.empty()) {
            used_media = p->source_media();
            if(used_media.empty()) {
              return false;
            }
          }
          
          std::string category;
          auto categories = p->categories();
          if (categories.size() > 0) {
            category = categories[0];
          }
          cate_media = category + "\t" + used_media;
          all_media = "全部\t" + used_media;
          auto level_iter = cate_media_level_map->find(cate_media);
          if (level_iter == cate_media_level_map->end()) {
            level_iter = cate_media_level_map->find(all_media);
          }
          if (level_iter != cate_media_level_map->end()) {
            media_level = level_iter->second;
          } else {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::MediaLevel)value == media_level) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrReviewed:
        {
          int value = -1;
          if (condition.match_values.size() > 0) {
            if (base::StringToInt(condition.match_values.at(0), &value) && value >= 0) {
              bool reviewed = (static_cast<int64>(p->item_has_reviewed()) != 0); 
              if (reviewed != value) {
                return false;
              }
            } else {
              return false;
            }
          } else {
            return false;
          }
        }
        break;
      case kItemAttrUcVideoStorage:
        {
          int value = -1;
          if (condition.match_values.size() > 0) {
            if (base::StringToInt(condition.match_values.at(0), &value) && value >= 0) {
              bool has_video_storage = (static_cast<int64>(p->has_video_storage_info()) != 0);
              if (has_video_storage != value) {
                return false;
              }
            } else {
              return false;
            }
          } else {
            return false;
          }
        }
        break;
      default:
        return false;
        break;
    }
  }
  return true;
}

}
}
