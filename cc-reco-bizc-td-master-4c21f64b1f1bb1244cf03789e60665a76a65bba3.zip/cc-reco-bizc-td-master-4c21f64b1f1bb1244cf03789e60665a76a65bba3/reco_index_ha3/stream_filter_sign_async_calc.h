#pragma once
#include <string>
#include <vector>
#include <unordered_map>

#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "reco/bizc/reco_index_ha3/news_index_ha3.h"
#include "base/thread/thread.h"

namespace reco {
namespace filter {

class StreamFilterSignAsyncCalc {
 public:
  explicit StreamFilterSignAsyncCalc(reco::NewsIndex* index);
  ~StreamFilterSignAsyncCalc();
  bool IsItemFiltered(const BitList req_bit, const ItemInfo& item, bool is_debug = false,
                      BitList* rule_mask = NULL,
                      BitList* filtered_bit = NULL,
                      std::string* key = NULL);
  void ProcessSingleDoc(const ItemInfoFullPtr& p,
                        const StreamFilterDict* dict,
                         std::vector<FilterStrategy>* strategy
                        );
 private:
  bool MatchConditionHit(const ItemInfoFullPtr& p,
                         const std::vector<MatchCondition>* conditions);
  reco::NewsIndex* news_index_;
};

}
}
