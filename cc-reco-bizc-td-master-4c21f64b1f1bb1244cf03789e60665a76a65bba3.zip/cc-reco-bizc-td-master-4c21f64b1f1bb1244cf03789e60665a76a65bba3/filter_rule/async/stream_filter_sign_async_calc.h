#pragma once
#include <string>
#include <vector>
#include <unordered_map>

#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "reco/bizc/reco_index/news_index.h"
#include "base/thread/thread.h"

namespace adsindexing {
class Index;
}

namespace reco {
namespace filter {

class StreamFilterSignAsyncCalc {
 public:
  explicit StreamFilterSignAsyncCalc(const reco::NewsIndex* index);
  ~StreamFilterSignAsyncCalc();
  // 打开端口前必须先调用 start
  // 启动时会先处理一遍所有的 item
  // 否则会导致大量下发错误
  void Start();

  void Stop();

  bool IsItemFiltered(const BitList req_bit, uint64 item_id, bool is_debug = false,
                      BitList* rule_mask = NULL,
                      BitList* filtered_bit = NULL,
                      std::string* key = NULL);
  std::unordered_map<uint64, std::vector<FilterStrategy>* > * get_filter_info_map() {
    return &filter_info_map_;
  }
 private:
  void ThreadFunc();
  void ProcessSingleDoc(const int32 docid,
                        const StreamFilterDict* dict);
  bool MatchConditionHit(const int32 docid,
                         const std::vector<MatchCondition>* conditions);
  thread::Thread calc_thread_;
  bool running_;
  bool started_;
  int32 last_min_doc_id_;
  const reco::NewsIndex* news_index_;
  const adsindexing::Index* index_;
  // 单写多读, 无锁
  // item 只增不减, 如果之前加入的 item 不需要过滤了, 只需把 vector 清空
  std::unordered_map<uint64, std::vector<FilterStrategy>* > filter_info_map_;
  // 保留上次的词典原始指针, 用来比较词典是否发生变化
  StreamFilterDict* last_dict_ptr_;
};

}
}
