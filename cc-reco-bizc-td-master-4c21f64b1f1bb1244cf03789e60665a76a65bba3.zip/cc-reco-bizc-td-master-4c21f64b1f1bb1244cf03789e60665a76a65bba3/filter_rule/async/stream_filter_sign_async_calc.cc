#include "reco/bizc/filter_rule/async/stream_filter_sign_async_calc.h"
#include "base/strings/string_number_conversions.h"
#include "base/time/timestamp.h"
#include "base/time/time.h"
#include "reco/bizc/proto/item.pb.h"

DEFINE_int32(stream_filter_sign_asnc_calc_interval, 60, "");

namespace reco {
namespace filter {

StreamFilterSignAsyncCalc::StreamFilterSignAsyncCalc(const reco::NewsIndex* index) {
  news_index_ = index;
  index_ = news_index_->GetAdsIndex();
  started_ = false;
  running_ = false;
}

StreamFilterSignAsyncCalc::~StreamFilterSignAsyncCalc() {
  Stop();
  for (auto iter = filter_info_map_.begin(); iter != filter_info_map_.end(); ++iter) {
    if (iter->second != NULL) {
      delete iter->second;
    }
  }
  filter_info_map_.clear();
}

bool StreamFilterSignAsyncCalc::IsItemFiltered(const BitList req_bit, uint64 item_id, bool is_debug,
                                               BitList* rule_mask,
                                               BitList* filtered_bit,
                                               std::string* key) {
  auto iter = filter_info_map_.find(item_id);
  if (iter == filter_info_map_.end()) {
    return false;
  }

  auto strategy = iter->second;
  if (strategy == NULL || strategy->size() == 0) {
    return false;
  }

  for (auto i = 0u; i < strategy->size(); ++i) {
    auto& rule = strategy->at(i);
    BitList maskbit = req_bit & rule.mask;
    for (auto j = 0u; j < rule.filter_values.size(); ++j) {
      if (maskbit == rule.filter_values.at(j)) {
        if (is_debug) {
          if (filtered_bit != NULL) {
            *filtered_bit = rule.filter_values.at(j);
          }
          if (rule_mask != NULL) {
            *rule_mask = rule.mask;
          }
          if (key != NULL) {
            *key = rule.key;
          }
        }
        return true;
      }
    }
  }
  return false;
}

void StreamFilterSignAsyncCalc::Start() {
  if (started_) {
    return;
  }
  LOG(INFO) << "StreamFilterSignAsyncCalc started";
  int64 processed_doc = 0;
  auto stream_filter_dict =
      DM_GET_DICT(StreamFilterDict, reco::filter::DynamicDictContainer::kStreamFilterFile);
  last_dict_ptr_ = const_cast<StreamFilterDict*>(stream_filter_dict.get());
  if (last_dict_ptr_ != NULL && last_dict_ptr_->filter_configs.size() != 0u) {
    int32 min_doc_id = index_->MinDocLocalId();
    int32 max_doc_id = index_->MaxDocLocalId();
    int64 now_timestamp = base::GetTimestamp();
    last_min_doc_id_ = min_doc_id;
    // 从最新文档向最旧文档遍历
    for (auto docid = min_doc_id; docid < max_doc_id; ++docid) {
      // 跳过无效和过期的文章
      if (!news_index_->IsValidByDocId(docid)) {
        continue;
      }
      if (news_index_->IsExpiredByDocId(docid, now_timestamp)) {
        continue;
      }
      ProcessSingleDoc(docid, last_dict_ptr_);
      ++processed_doc;
    }
    LOG(INFO) << "StreamFilterSignAsyncCalc succ, processed_doc : " << processed_doc
              << " min_doc_id : " << min_doc_id
              << " max_doc_id : " << max_doc_id
              << " marked item size : " << filter_info_map_.size();
  } else {
    LOG(ERROR) << "invalid stream filter dict, no doc processed";
  }
  calc_thread_.Start(NewCallback(this, &StreamFilterSignAsyncCalc::ThreadFunc));
  started_ = true;
}

void StreamFilterSignAsyncCalc::Stop() {
  if (!started_) {
    return;
  }

  running_ = false;
  calc_thread_.Join();
  started_ = false;
}

void StreamFilterSignAsyncCalc::ProcessSingleDoc(const int32 docid, const StreamFilterDict* dict) {
  if (dict == NULL) {
    return;
  }
  std::vector<FilterStrategy>* strategy = NULL;
  uint64 item_id;
  // 根据 docid 找不到 itemid 不处理
  if (!news_index_->GetItemIdByDocId(docid, &item_id)) {
    return;
  }
  // 查找这个 item 是否已经被处理过
  // 如果处理过 进行补全
  // 如果没有, new 一个新的, 标记需要插入
  bool need_insert = false;
  auto iter = filter_info_map_.find(item_id);
  if (iter != filter_info_map_.end()) {
    strategy = iter->second;
  }
  if (strategy == NULL) {
    strategy = new std::vector<FilterStrategy>();
    need_insert = true;
  }
  for (auto i = 0u; i < dict->filter_configs.size(); ++i) {
    auto& config = dict->filter_configs.at(i);
    // 如果 item 的属性命中筛选条件, 那么将预处理好的 strategy 加入
    // 通过 key 来识别是否有重复的 strategy, 若重复则不需要加入
    if (MatchConditionHit(docid, &config.conditions)) {
      VLOG(1) << "item_id : " << item_id
              << " hit by condition idx : " << i;
      bool bfind = false;
      for (auto j = 0u; j < strategy->size(); ++j) {
        if (strategy->at(j).key == config.strategy.key) {
          bfind = true;
          break;
        }
      }
      if (!bfind) {
        strategy->push_back(config.strategy);
        VLOG(1) << "item_id : " << item_id
                << " added filter strategy, key : " << config.strategy.key;
      }
    }
  }
  if (need_insert) {
    if (strategy->size() > 0) {
      filter_info_map_.insert(std::make_pair(item_id, strategy));
    } else {
      delete strategy;
    }
  }
}

bool StreamFilterSignAsyncCalc::MatchConditionHit(const int32 docid,
                                                  const std::vector<MatchCondition>* conditions) {
  if (conditions == NULL || conditions->size() == 0) {
    return false;
  }
  for (auto i = 0u; i < conditions->size(); ++i) {
    auto& condition = conditions->at(i);
    switch (condition.item_attr) {
      case kItemAttrNeg:
        {
          reco::ContentAttr content_attr;
          bool is_trival = false;
          if (!news_index_->GetContentAttrByDocId(docid, &content_attr, &is_trival) ||
              is_trival) {
            return false;
          }
          if (!content_attr.has_negative()) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ContentAttr::ContentAttrLevel)value == content_attr.negative()) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrDirty:
        {
          reco::ContentAttr content_attr;
          bool is_trival = false;
          if (!news_index_->GetContentAttrByDocId(docid, &content_attr, &is_trival) ||
              is_trival) {
            return false;
          }
          if (!content_attr.has_dirty()) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ContentAttr::ContentAttrLevel)value == content_attr.dirty()) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrTitleParty:
        {
          reco::ContentAttr content_attr;
          bool is_trival = false;
          if (!news_index_->GetContentAttrByDocId(docid, &content_attr, &is_trival) ||
              is_trival) {
            return false;
          }
          if (!content_attr.has_bluffing_title()) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ContentAttr::ContentAttrLevel)value == content_attr.bluffing_title()) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrPolitics:
        {
          reco::ContentAttr content_attr;
          bool is_trival = false;
          if (!news_index_->GetContentAttrByDocId(docid, &content_attr, &is_trival) ||
              is_trival) {
            return false;
          }
          if (!content_attr.has_politics()) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ContentAttr::ContentAttrLevel)value == content_attr.politics()) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrLowQuality:
        {
          reco::ContentAttr content_attr;
          bool is_trival = false;
          if (!news_index_->GetContentAttrByDocId(docid, &content_attr, &is_trival) ||
              is_trival) {
            return false;
          }
          if (!content_attr.has_erro_title() &&
              !content_attr.has_advertorial() &&
              !content_attr.has_short_content() &&
              !content_attr.has_dedup_paragraph()) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((content_attr.has_erro_title() &&
                   (reco::ContentAttr::ContentAttrLevel)value == content_attr.erro_title())
                  || (content_attr.has_advertorial() &&
                      (reco::ContentAttr::ContentAttrLevel)value == content_attr.advertorial())
                  || (content_attr.has_short_content() &&
                      (reco::ContentAttr::ContentAttrLevel)value == content_attr.short_content())
                  || (content_attr.has_dedup_paragraph()
                      && (reco::ContentAttr::ContentAttrLevel)value == content_attr.dedup_paragraph())) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrFirstCate:
        {
          std::vector<std::string> categories;
          if (!news_index_->GetCategoriesByDocId(docid, &categories)) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            std::string value = condition.match_values.at(j);
            if (categories.size() > 0u) {
              if (categories.at(0) == value) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrFirstCateNot:
        {
          std::vector<std::string> categories;
          if (!news_index_->GetCategoriesByDocId(docid, &categories)) {
            return false;
          }
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            std::string value = condition.match_values.at(j);
            if (categories.size() > 0u) {
              if (categories.at(0) == value) {
                return false;
              }
            }
          }
        }
        break;
      case kItemAttrSecondCate:
        {
          std::vector<std::string> categories;
          if (!news_index_->GetCategoriesByDocId(docid, &categories)) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            std::string value = condition.match_values.at(j);
            if (categories.size() > 1u) {
              if (categories.at(1) == value) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrSecondCateNot:
        {
          std::vector<std::string> categories;
          if (!news_index_->GetCategoriesByDocId(docid, &categories)) {
            return false;
          }
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            std::string value = condition.match_values.at(j);
            if (categories.size() > 1u) {
              if (categories.at(1) == value) {
                return false;
              }
            }
          }
        }
        break;
      case kItemAttrTag:
        {
          // 根据 docid 找不到 itemid 不处理
          uint64 item_id;
          if (!news_index_->GetItemIdByDocId(docid, &item_id)) {
            return false;
          }
          reco::FeatureVector fevtag;
          if (!news_index_->GetFeatureVectorByItemId(item_id, reco::common::kTag, &fevtag)) {
            return false;
          }
          std::string kTagPrefix = "label:";
          bool bfind = false;
          for (int j = 0; j < fevtag.feature_size(); ++j) {
            std::string tag = fevtag.feature(j).literal();
            if (tag.substr(0, kTagPrefix.length()) == kTagPrefix) {
              tag = tag.substr(kTagPrefix.length(), tag.length() - kTagPrefix.length());
            }
            for (auto k = 0u; k < condition.match_values.size(); ++k) {
              if (tag == condition.match_values.at(k)) {
                bfind = true;
                break;
              }
            }
            if (bfind) {
              break;
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrTagNot:
        {
          // 根据 docid 找不到 itemid 不处理
          uint64 item_id;
          if (!news_index_->GetItemIdByDocId(docid, &item_id)) {
            return false;
          }
          reco::FeatureVector fevtag;
          if (!news_index_->GetFeatureVectorByItemId(item_id, reco::common::kTag, &fevtag)) {
            return false;
          }
          std::string kTagPrefix = "label:";
          for (int j = 0; j < fevtag.feature_size(); ++j) {
            std::string tag = fevtag.feature(j).literal();
            if (tag.substr(0, kTagPrefix.length()) == kTagPrefix) {
              tag = tag.substr(kTagPrefix.length(), tag.length() - kTagPrefix.length());
            }
            for (auto k = 0u; k < condition.match_values.size(); ++k) {
              if (tag == condition.match_values.at(k)) {
                return false;
              }
            }
          }
        }
        break;
      case kItemAttrSemanticTag:
        {
          // 根据 docid 找不到 itemid 不处理
          uint64 item_id;
          if (!news_index_->GetItemIdByDocId(docid, &item_id)) {
            return false;
          }
          reco::FeatureVector fevtag;
          if (!news_index_->GetFeatureVectorByItemId(item_id, reco::common::kSemanticTag, &fevtag)) {
            return false;
          }
          std::string kTagPrefix = "label2:";
          bool bfind = false;
          for (int j = 0; j < fevtag.feature_size(); ++j) {
            std::string tag = fevtag.feature(j).literal();
            if (tag.substr(0, kTagPrefix.length()) == kTagPrefix) {
              tag = tag.substr(kTagPrefix.length(), tag.length() - kTagPrefix.length());
            }
            for (auto k = 0u; k < condition.match_values.size(); ++k) {
              if (tag == condition.match_values.at(k)) {
                bfind = true;
                break;
              }
            }
            if (bfind) {
              break;
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrSemanticTagNot:
        {
          // 根据 docid 找不到 itemid 不处理
          uint64 item_id;
          if (!news_index_->GetItemIdByDocId(docid, &item_id)) {
            return false;
          }
          reco::FeatureVector fevtag;
          if (!news_index_->GetFeatureVectorByItemId(item_id, reco::common::kSemanticTag, &fevtag)) {
            return false;
          }
          std::string kTagPrefix = "label2:";
          for (int j = 0; j < fevtag.feature_size(); ++j) {
            std::string tag = fevtag.feature(j).literal();
            if (tag.substr(0, kTagPrefix.length()) == kTagPrefix) {
              tag = tag.substr(kTagPrefix.length(), tag.length() - kTagPrefix.length());
            }
            for (auto k = 0u; k < condition.match_values.size(); ++k) {
              if (tag == condition.match_values.at(k)) {
                return false;
              }
            }
          }
        }
        break;
      case kItemAttrItemType:
        {
          reco::ItemType item_type;
          if (!news_index_->GetItemTypeByDocId(docid, &item_type)) {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ItemType)value == item_type) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrItemTypeNot:
        {
          reco::ItemType item_type;
          if (!news_index_->GetItemTypeByDocId(docid, &item_type)) {
            return false;
          }
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::ItemType)value == item_type) {
                return false;
              }
            }
          }
        }
        break;
      case kItemAttrWeMedia:
        {
          if (news_index_->IsManualByDocId(docid)) {
            return false;
          }
          int value = -1;
          if (condition.match_values.size() > 0) {
            if (base::StringToInt(condition.match_values.at(0), &value) && value >= 0) {
              std::string producer;
              if (!news_index_->GetProducerByDocId(docid, &producer)) {
                return false;
              }
              bool is_wemedia = producer == "cp_wemedia_uc" ? true : false;
              if (is_wemedia != value) {
                return false;
              }
            } else {
              return false;
            }
          } else {
            return false;
          }
        }
        break;
      case kItemAttrMediaLevel:
        {
          auto dict_manager = IndexDictManager::GetInstance();
          auto const cate_media_level_map = dict_manager->GetCategoryMediaLevelMap();
          if (cate_media_level_map == NULL) {
            return false;
          }
          reco::MediaLevel media_level;
          std::string used_media;
          std::string cate_media;
          std::string all_media;
          std::string orig_source_media;
          if (!news_index_->GetOrigSourceMediaByDocId(docid, &orig_source_media)) {
            std::string source_media;
            if (!news_index_->GetSourceMediaByDocId(docid, &source_media)) {
              return false;
            } else {
              used_media = source_media;
            }
          } else {
            used_media = orig_source_media;
          }
          std::vector<std::string> categories;
          std::string category;
          if (news_index_->GetCategoriesByDocId(docid, &categories)) {
            if (categories.size() > 0) {
              category = categories[0];
            }
          }
          cate_media = category + "\t" + used_media;
          all_media = "全部\t" + used_media;
          auto level_iter = cate_media_level_map->find(cate_media);
          if (level_iter == cate_media_level_map->end()) {
            level_iter = cate_media_level_map->find(all_media);
          }
          if (level_iter != cate_media_level_map->end()) {
            media_level = level_iter->second;
          } else {
            return false;
          }
          bool bfind = false;
          for (auto j = 0u; j < condition.match_values.size(); ++j) {
            int value = -1;
            if (base::StringToInt(condition.match_values.at(j), &value) && value >= 0) {
              if ((reco::MediaLevel)value == media_level) {
                bfind = true;
                break;
              }
            }
          }
          if (!bfind) {
            return false;
          }
        }
        break;
      case kItemAttrReviewed:
        {
          int value = -1;
          if (condition.match_values.size() > 0) {
            if (base::StringToInt(condition.match_values.at(0), &value) && value >= 0) {
              bool reviewed = (news_index_->GetHasReviewedByDocId(docid));
              if (reviewed != value) {
                return false;
              }
            } else {
              return false;
            }
          } else {
            return false;
          }
        }
        break;
      case kItemAttrUcVideoStorage:
        {
          int value = -1;
          if (condition.match_values.size() > 0) {
            if (base::StringToInt(condition.match_values.at(0), &value) && value >= 0) {
              bool has_video_storage = (news_index_->HasVideoStorageInfoByDocId(docid));
              if (has_video_storage != value) {
                return false;
              }
            } else {
              return false;
            }
          } else {
            return false;
          }
        }
        break;
      default:
        return false;
        break;
    }
  }
  return true;
}

void StreamFilterSignAsyncCalc::ThreadFunc() {
  running_ = true;
  while (running_) {
    base::SleepForSeconds(FLAGS_stream_filter_sign_asnc_calc_interval);
    bool dict_changed = false;
    int64 processed_doc = 0;
    auto stream_filter_dict =
        DM_GET_DICT(StreamFilterDict, reco::filter::DynamicDictContainer::kStreamFilterFile);
    if (stream_filter_dict.get() != NULL && last_dict_ptr_ != stream_filter_dict.get()) {
      dict_changed = true;
      last_dict_ptr_ = const_cast<StreamFilterDict*>(stream_filter_dict.get());
    }
    if (last_dict_ptr_ == NULL) {
      continue;
    }
    int32 max_doc_id;
    int32 min_doc_id;
    // 如果词典有变动, 全量计算
    // 如果词典没有变动, 只计算增量
    if (!dict_changed) {
      max_doc_id = last_min_doc_id_;
    } else {
      max_doc_id = index_->MaxDocLocalId();
    }
    min_doc_id = index_->MinDocLocalId();
    last_min_doc_id_ = min_doc_id;
    int64 now_timestamp = base::GetTimestamp();
    for (int32 docid = min_doc_id; docid < max_doc_id; ++docid) {
      // 跳过无效和过期的文章
      if (!news_index_->IsValidByDocId(docid)) {
        continue;
      }
      if (news_index_->IsExpiredByDocId(docid, now_timestamp)) {
        continue;
      }
      ProcessSingleDoc(docid, last_dict_ptr_);
      ++processed_doc;
    }
    LOG(INFO) << "StreamFilterSignAsyncCalc succ, processed_doc : " << processed_doc
        << " min_doc_id : " << min_doc_id
        << " max_doc_id : " << max_doc_id
        << " marked item size : " << filter_info_map_.size();
  }
}
}
}
