//
// Created by allen.fw on 2017/8/30.
//

#include <math.h>
#include <boost/dynamic_bitset.hpp>
#include <unordered_map>
#include <vector>
#include "reco/bizc/common/appname_define.h"
#include "reco/bizc/filter_rule/offline/app_token_filter.h"
#include "base/strings/utf_char_iterator.h"
#include "base/hash_function/term.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "extend/json/jansson/jansson.h"
#include "base/strings/string_util.h"

namespace reco {
namespace filter {

const std::string SOURCE_WEMEDIA_PREFIX = "cp_wemedia_uc_";
const int kAppTokenBit = 2;
void AppTokenFilter::FilterRule(RecoItem* reco_item) {
  auto app_token_dict = DM_GET_DICT(AppTokenFilterDict,
                                    reco::filter::DynamicDictContainer::kAppTokenFilterFile);
  if (app_token_dict == NULL) {
    LOG(INFO) << "app_token_dict is null, item_id: " << reco_item->identity().item_id();
    return;
  }
  auto& app_token_index_map = app_token_dict->app_token_index_map;

  auto app_token_bit_index_dict = DM_GET_DICT(AppTokenBitIndex,
                                    reco::filter::DynamicDictContainer::kAppTokenBitIndexFile);
  if (app_token_bit_index_dict == NULL) {
    LOG(INFO) << "app_token_bit_index_dict is null, item_id: " << reco_item->identity().item_id();
    return;
  }
  auto& app_token_bit_index = app_token_bit_index_dict->app_token_bit_index;

  int max_app_idx = 0;
  for (std::unordered_map<std::string, int>::const_iterator it = app_token_bit_index.begin();
          it != app_token_bit_index.end(); ++it) {
    if (it->second > max_app_idx) {
      max_app_idx = it->second;
    }
  }

  bool is_has_app_filter = false;
  boost::dynamic_bitset<uint8> app_rule_mask;
  app_rule_mask.resize(kAppTokenBit * (max_app_idx + 1), false);
  for (std::unordered_map<std::string, int>::const_iterator it = app_token_index_map.begin();
        it != app_token_index_map.end(); ++it) {
    std::unordered_map<std::string, int>::const_iterator index_it
            = app_token_bit_index.find(it->first);
    if (index_it == app_token_bit_index.end()) {
      LOG(INFO) << "app token [" << it->first << "] is not in app_token_bit_index";
      continue;
    }
    int bit_index = index_it->second;
    if (bit_index < 0 || bit_index >= static_cast<int>(app_rule_mask.size())) {
      LOG(INFO) << "app token [" << it->first << "] bit_index [" << bit_index << "] is beyond";
      continue;
    }

    int index = it->second;
    if (index < 0 || index >= static_cast<int>(app_token_index_map.size())) {
      LOG(INFO) << "app token [" << it->first << "] index [" << index << "] is beyond";
      continue;
    }

    bool is_filtered = false;
    if (reco_item->identity().has_manual() && reco_item->identity().manual()) {
      is_filtered = AppTokenRuleFilterUCB(index, *reco_item);
    } else {
      is_filtered = AppTokenRuleFilter(index, *reco_item);
    }

    if (is_filtered) {
      app_rule_mask.set(kAppTokenBit * bit_index, 1);
      is_has_app_filter = true;
    } else if (MainCityBadItemFIlter(index, app_token_dict.get(), *reco_item)) {
      app_rule_mask.set(kAppTokenBit * bit_index + 1, 1);
      is_has_app_filter = true;
    }
  }

  if (is_has_app_filter) {
    reco_item->mutable_offline_filter_rule()->mutable_app_token_rule_bits()->set_app_token_bits(kAppTokenBit);
    std::string value;
    BitsetToString(app_rule_mask, &value);
    reco_item->mutable_offline_filter_rule()->mutable_app_token_rule_bits()->set_rule_bits(value);

    std::string view_rule_bits;
    boost::to_string(app_rule_mask, view_rule_bits);
    LOG(INFO) << "item_id: " << reco_item->identity().item_id() << ", rule bits: "
              << view_rule_bits;
  }

  return;
}

const int APP_TOKEN_CHAR_BIT = 8;
void AppTokenFilter::BitsetToString(const boost::dynamic_bitset<uint8>& app_rule_mask,
                                           std::string* value) {
  if (app_rule_mask.size() <= 0) {
    return;
  }
  uint32 num = ceil(app_rule_mask.size() / 8.0);
  boost::dynamic_bitset<uint8>::block_type* blocks = new boost::dynamic_bitset<uint8>::block_type[num];
  boost::to_block_range(app_rule_mask, blocks);
  for (size_t i = 0; i < num; ++i) {
    value->push_back(blocks[i]);
  }
  delete[] blocks;

  return;
}

bool AppTokenFilter::AppTokenRuleFilter(int app_token_idx, const RecoItem& item) {
  if (app_token_idx < 0) {
    return false;
  }

  auto app_token_dict = DM_GET_DICT(AppTokenFilterDict,
                                    reco::filter::DynamicDictContainer::kAppTokenFilterFile);
  if (app_token_dict == NULL) {
    return false;
  }

  if (IsFilteredByCategory(app_token_idx, app_token_dict.get(), item)) {
    return true;
  }

  if (IsFilteredByItemDirty(app_token_idx, app_token_dict.get(), item)) {
    return true;
  }

  if (IsFilteredByItemBluffing(app_token_idx, app_token_dict.get(), item)) {
    return true;
  }

  if (IsFilteredBySourceWeMedia(app_token_idx, app_token_dict.get(), item)) {
    return true;
  }

  if (IsFilteredByBlackPattern(app_token_idx, app_token_dict.get(), item)) {
    return true;
  }

  if (IsFilteredBySource(app_token_idx, app_token_dict.get(), item)) {
    return true;
  }

  // 自媒体 level 过滤，注意这里会跟 "wemedia" 这个规则 (IsFilteredBySourceWeMedia) 有交集
  // 我们取最严格的：被哪个命中都会被过滤掉

  auto cate_media_level_dict = DM_GET_DICT(CateMediaLevelMap,
                                          reco::filter::DynamicDictContainer::kCategoryMediaLevelFile);
  if (IsFilteredByWeMediaLevel(app_token_idx, app_token_dict.get(), cate_media_level_dict.get(), item)) {
    return true;
  }

  // 自媒体黑名单，注意前面有个白名单(IsFilteredBySource)，我们挨个规则过滤
  if (IsFilteredByBlackWeMediaSource(app_token_idx, app_token_dict.get(), item)) {
    return true;
  }

  if (VideoLengthFilter(app_token_idx, app_token_dict.get(), item)) {
    return true;
  }

  if (ProducerWemediaYoutuFilter(app_token_idx, app_token_dict.get(), item)) {
    return true;
  }

  return false;
}

bool AppTokenFilter::IsFilteredByCategory(int app_token_idx,
                                                 const AppTokenFilterDict* app_token_dict,
                                                 const RecoItem& item) {
  auto category_dict = app_token_dict->app_token_black_category[app_token_idx];
  if (category_dict == NULL) {
    return false;
  }

  if (item.category_size() == 0 || item.category(0).empty()) {
    LOG(INFO) << "app [" << app_token_idx << "] filter by get category fail, item_id: "
                                << item.identity().item_id();
    return true;
  }

  std::string category = item.category(0);
  std::string sub_category;

  if (item.category_size() > 1) {
    sub_category = item.category(1);
  }

  if (category_dict->Find(category, sub_category)) {
    LOG(INFO) << "app [" << app_token_idx << "] filter by category in black category, item_id: "
                            << item.identity().item_id();
    return true;
  }

  return false;
}

bool AppTokenFilter::IsFilteredByItemDirty(int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                                  const RecoItem& item) {
  if (!app_token_dict->app_token_filter_dirty[app_token_idx]) {
    return false;
  }

  if (item.has_content_attr() && item.content_attr().has_dirty()
      && item.content_attr().dirty() >= reco::ContentAttr::kSuspect) {
    LOG(INFO) << "app [" << app_token_idx << "] filter by dirty, item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}

bool AppTokenFilter::IsFilteredByItemBluffing(int app_token_idx,
                                                     const AppTokenFilterDict* app_token_dict,
                                                     const RecoItem& item) {
  if (!app_token_dict->app_token_filter_bluffing_title[app_token_idx]) {
    return false;
  }

  if (item.has_content_attr() && item.content_attr().has_bluffing_title()
      && item.content_attr().bluffing_title() >= reco::ContentAttr::kSuspect) {
    LOG(INFO) << "app [" << app_token_idx << "] filter by bluffing_title, item_id: "
                                      << item.identity().item_id();
    return true;
  }

  return false;
}

bool AppTokenFilter::IsFilteredBySourceWeMedia(int app_token_idx,
                                                      const AppTokenFilterDict* app_token_dict,
                                                      const RecoItem& item) {
  if (!app_token_dict->app_token_filter_wemedia[app_token_idx]) {
    return false;
  }

  if (base::StartsWith(item.source(), SOURCE_WEMEDIA_PREFIX, false)) {
    LOG(INFO) << "app [" << app_token_idx << "] filter by wemedia, item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}

bool AppTokenFilter::IsFilteredByBlackPattern(const int app_token_idx,
                                                     const AppTokenFilterDict* app_token_dict,
                                                     const RecoItem& reco_item) {
  auto pattern = app_token_dict->app_token_title_match[app_token_idx];
  if (NULL == pattern) {
    VLOG(1) << "pattern is null";
    return false;
  }

  std::string title = reco_item.normalized_title();

  extend::MatchResult result;
  if (pattern->Match(title.c_str(), title.size(), &result)) {
    LOG(INFO) << "app [" << app_token_idx << "] filter by black pattern, item_id: "
                          << reco_item.identity().item_id();
    return true;
  }

  return false;
}


bool AppTokenFilter::IsFilteredBySource(int app_token_idx,
                                               const AppTokenFilterDict* app_token_dict,
                                               const RecoItem& item) {
  auto white_source = app_token_dict->app_token_white_source[app_token_idx];
  if (white_source == NULL) {
    VLOG(1) << "pass:" << item.identity().item_id();
    return false;
  }

  if (white_source->Find(item.source())) {
    VLOG(1) << "pass:" << item.identity().item_id() << "-" << item.source();
    return false;
  }

  if (item.has_orig_source() && white_source->Find(item.orig_source())) {
    VLOG(1) << "pass:" << item.identity().item_id() << "-" << item.source();
    return false;
  }

  LOG(INFO) << "app [" << app_token_idx << "] filter by source not in white dict, item_id: "
                          << item.identity().item_id();
  return true;
}

bool AppTokenFilter::IsFilteredByBlackWeMediaSource(int app_token_idx,
                                                           const AppTokenFilterDict* app_token_dict,
                                                           const RecoItem& item) {
  auto black_source = app_token_dict->app_token_black_source[app_token_idx];
  if (black_source == NULL) {
    return false;
  }

  if (black_source->Find(item.source())) {
    LOG(INFO) << "app [" << app_token_idx << "] filter by source in black dict, item_id: "
                      << item.identity().item_id();
    return true;
  }

  if (item.has_orig_source() && black_source->Find(item.orig_source())) {
    LOG(INFO) << "app [" << app_token_idx << "] filter by orig source in black dict, item_id: "
                              << item.identity().item_id();
    return true;
  }

  return false;
}

bool AppTokenFilter::IsFilteredByWeMediaLevel(int app_token_idx,
                                                     const AppTokenFilterDict* app_token_dict,
                                                     const CateMediaLevelMap* cate_media_level_dict,
                                                     const RecoItem& item) {
  if (!base::StartsWith(item.source(), SOURCE_WEMEDIA_PREFIX, false)) {
    return false;
  }

  reco::MediaLevel media_level = reco::kNormalMedia;
  if (item.category_size() > 0) {
    auto& cate_media_level_map = cate_media_level_dict->cate_media_level_map;
    const std::string used_media = (item.has_orig_source_media() && !item.orig_source_media().empty())
                ? item.orig_source_media() : item.has_source_media() ? item.source_media() : "";
    const std::string cate_media = item.category(0) + "\t" + used_media;
    auto level_iter = cate_media_level_map.find(cate_media);
    if (level_iter == cate_media_level_map.end()) {
      level_iter = cate_media_level_map.find("全部\t" + used_media);
    }
    if (level_iter != cate_media_level_map.end()) {
      media_level = level_iter->second;
    }
  }

  auto min_media_level = app_token_dict->app_token_min_media_level[app_token_idx];
  if (media_level < min_media_level) {
    LOG(INFO) << "app [" << app_token_idx << "] filter by wemedia level, item_id: "
              << item.identity().item_id();
    return true;
  }

  return false;
}

bool AppTokenFilter::VideoLengthFilter(int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                              const RecoItem& item) {
  if (item.identity().type() != reco::kPureVideo) {
    return false;
  }

  if (!app_token_dict->app_token_video_length[app_token_idx].is_lenght_filter) {
    return false;
  }

  const int32 length_thr = base::StartsWith(item.source(), SOURCE_WEMEDIA_PREFIX, false)
                           ? app_token_dict->app_token_video_length[app_token_idx].wemedia_max_len * 60
                           : app_token_dict->app_token_video_length[app_token_idx].common_max_len * 60;
  if (length_thr <= 0) {
    return false;
  }

  int32 video_length = 0;
  for (int k = 0; k < item.video_meta_settings_size(); ++k) {
    video_length += item.video_meta_settings(k).play_length();
  }
  VLOG(1) << "video length: " << video_length;

  if (video_length <= 0 || video_length > length_thr) {
    LOG(INFO) << "app [" << app_token_idx << "] filter by video len [" << video_length
                << "] max len [" << length_thr << "], item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}

bool AppTokenFilter::ProducerWemediaYoutuFilter(int app_token_idx,
                                                       const AppTokenFilterDict* app_token_dict,
                                                       const RecoItem& item) {
  if (item.identity().type() != reco::kPureVideo) {
    return false;
  }

  if (!app_token_dict->app_token_filter_wemedia_youtu[app_token_idx]) {
    return false;
  }

  std::string producer = item.identity().has_producer() ?
                         item.identity().producer() : item.identity().app_token();
  if (base::LowerCaseEquals(producer, reco::common::kTuDouProducer)
        || base::LowerCaseEquals(producer, "cp_wemedia_youtu")
        || base::LowerCaseEquals(producer, "tudou-iflow")) {
    LOG(INFO) << "app [" << app_token_idx << "] filter by wemedia youtu, item_id: "
              << item.identity().item_id();
    return true;
  }

  return false;
}

bool AppTokenFilter::AppTokenRuleFilterUCB(int app_token_idx, const RecoItem& item) {
  if (app_token_idx < 0) {
    return false;
  }

  auto app_token_dict = DM_GET_DICT(AppTokenFilterDict,
                                    reco::filter::DynamicDictContainer::kAppTokenFilterFile);
  if (app_token_dict == NULL) {
    return false;
  }

  if (IsFilteredByBlackPattern(app_token_idx, app_token_dict.get(), item)) {
    return true;
  }

  if (IsFilteredBySource(app_token_idx, app_token_dict.get(), item)) {
    return true;
  }

  return false;
}

bool AppTokenFilter::MainCityBadItemFIlter(int app_token_idx,
                                              const AppTokenFilterDict* app_token_dict,
                                              const reco::RecoItem& item) {
  if (app_token_dict == NULL || app_token_idx == -1) {
    return false;
  }
  if (!app_token_dict->app_token_filter_main_city[app_token_idx]) {
    return false;
  }

  if (item.has_content_attr() && item.content_attr().has_dirty()
      && item.content_attr().dirty() >= reco::ContentAttr::kSuspect) {
    LOG(INFO) << "main city filter by dirty, item_id: " << item.identity().item_id();
    return true;
  }

  if (item.has_content_attr() && item.content_attr().has_bluffing_title()
      && item.content_attr().bluffing_title() >= reco::ContentAttr::kSuspect) {
    LOG(INFO) << "main city filter by bluffing title, item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}
}
}
