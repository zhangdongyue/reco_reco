//
// Created by allen.fw on 2017/8/30.
//

#pragma once

#include <boost/dynamic_bitset.hpp>
#include <string>
#include <unordered_set>
#include <vector>

#include "reco/base/dict_manager/dict_manager.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
class NewsIndex;

namespace filter {
class AppTokenFilterDict;
class CateMediaLevelMap;

class AppTokenFilter {
 public:
  AppTokenFilter() {}
  ~AppTokenFilter() {}

  void FilterRule(RecoItem* reco_item);
  void BitsetToString(const boost::dynamic_bitset<uint8>& app_rule_mask, std::string* value);

  bool AppTokenRuleFilter(int app_token_idx, const RecoItem& item);

  bool AppTokenRuleFilterUCB(int app_token_idx, const RecoItem& item);

  bool IsFilteredByCategory(int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                   const RecoItem& item);

  bool IsFilteredByItemDirty(int app_token_idx, const AppTokenFilterDict* app_token_dict,
                             const RecoItem& item);

  bool IsFilteredByItemBluffing(int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                const RecoItem& item);

  bool IsFilteredBySourceWeMedia(int app_token_idx,
                                 const AppTokenFilterDict* app_token_dict,
                                 const RecoItem& item);

  bool IsFilteredByBlackPattern(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                       const RecoItem& item);

  bool IsFilteredBySource(int app_token_idx,
                          const AppTokenFilterDict* app_token_dict,
                          const RecoItem& item);

  bool IsFilteredByWeMediaLevel(int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                const CateMediaLevelMap* cate_media_level_dict, const RecoItem& item);

  bool IsFilteredByBlackWeMediaSource(int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                          const RecoItem& item);

  bool VideoLengthFilter(int app_token_idx, const AppTokenFilterDict* app_token_dict,
                         const RecoItem& item);

  bool ProducerWemediaYoutuFilter(int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                  const RecoItem& item);

  bool MainCityBadItemFIlter(int app_token_idx,
                                   const AppTokenFilterDict* app_token_dict,
                                   const reco::RecoItem& item);
};
}
}
