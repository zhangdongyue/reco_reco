//
// Created by allen.fw on 2017/9/5.
//

#include <memory>
#include "base/testing/gtest.h"
#include "reco/bizc/filter_rule/offline/global_filter.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "base/common/logging.h"

namespace reco {
namespace filter {

using reco::RecoItem;

class GlobalFilterTest : public testing::Test {
 protected:
  GlobalFilterTest() {
    strategy_ = std::shared_ptr<GlobalFilter>();
  }
  virtual ~GlobalFilterTest() {}

  virtual void SetUp() {
    FLAGS_v = 1;
    FLAGS_do_video_risk_check = true;
    FLAGS_do_video_special_filter = true;
  }

  virtual void TearDown() {
  }

 private:
  std::shared_ptr<GlobalFilter> strategy_;
};

// PicNumFilter
TEST_F(GlobalFilterTest, test_item_is_not_picture_should_pic_num_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(reco::kNews);

  ASSERT_FALSE(strategy_->PicNumFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_pic_item_size_gt_three_should_pic_num_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(reco::kPicture);
  reco_item.add_image();
  reco_item.add_image();
  reco_item.add_image();

  ASSERT_FALSE(strategy_->PicNumFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_item_size_less_three_should_pic_num_filter_return_true) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(reco::kPicture);

  ASSERT_TRUE(strategy_->PicNumFilter(reco_item));
}
// end PicNumFilter

// TitleFilter
TEST_F(GlobalFilterTest, test_manual_item_should_title_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_manual(true);

  ASSERT_FALSE(strategy_->TitleFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_item_no_normalized_title_should_title_filter_return_true) {
  RecoItem reco_item;

  ASSERT_TRUE(strategy_->TitleFilter(reco_item));
}
// end TitleFilter

// VideoHasRisk
TEST_F(GlobalFilterTest, test_video_has_risk) {
  RecoItem reco_item;

  // test no video_storage_info
  ASSERT_TRUE(strategy_->VideoHasRisk(reco_item));

  // test no normal
  reco_item.mutable_video_storage_info();
  ASSERT_TRUE(strategy_->VideoHasRisk(reco_item));

  // test no normal
  reco_item.mutable_video_storage_info()->set_normal("");
  ASSERT_TRUE(strategy_->VideoHasRisk(reco_item));

  // test no status
  reco_item.mutable_video_storage_info()->set_normal("no_care");
  ASSERT_TRUE(strategy_->VideoHasRisk(reco_item));

  // test status is not 1
  reco_item.mutable_video_storage_info()->set_status(0);
  ASSERT_TRUE(strategy_->VideoHasRisk(reco_item));

  // test return true
  reco_item.mutable_video_storage_info()->set_status(1);
  ASSERT_FALSE(strategy_->VideoHasRisk(reco_item));
}
// end VideoHasRisk

// InnerImageTxtRiskMediaFilter
const uint64 NO_CARE_MEDIA_SIGN = 0;
TEST_F(GlobalFilterTest, test_not_find_media_should_inner_image_txt_risk_return_false) {
  RecoItem reco_item;
  RiskMediaDict risk_media_dict;

  ASSERT_FALSE(strategy_->InnerImageTxtRiskMediaFilter(NO_CARE_MEDIA_SIGN, &risk_media_dict));
}

TEST_F(GlobalFilterTest, test_level_is_forbiden_should_inner_image_txt_risk_return_true) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_item_id(NO_CARE_MEDIA_SIGN);
  RiskMediaDict risk_media_dict;
  risk_media_dict.risk_media_map[NO_CARE_MEDIA_SIGN].level = RiskMediaInfo::kLevelForbiden;

  ASSERT_TRUE(strategy_->InnerImageTxtRiskMediaFilter(NO_CARE_MEDIA_SIGN, &risk_media_dict));
}

TEST_F(GlobalFilterTest, test_level_not_forbiden_should_inner_image_txt_risk_return_false) {
  RiskMediaDict risk_media_dict;
  risk_media_dict.risk_media_map[NO_CARE_MEDIA_SIGN].level = RiskMediaInfo::kLevelNoRisk;

  ASSERT_FALSE(strategy_->InnerImageTxtRiskMediaFilter(
          NO_CARE_MEDIA_SIGN, &risk_media_dict));
}
// end InnerImageTxtRiskMediaFilter

// YoutobeRiskMediaFilter
TEST_F(GlobalFilterTest, test_not_source_media_should_youtobe_risk_return_false) {
  RecoItem reco_item;
  RiskMediaDict risk_media_dict;

  ASSERT_FALSE(strategy_->YoutobeRiskMediaFilter(reco_item, &risk_media_dict));
}
// end YoutobeRiskMediaFilter

// NegativeFilter
TEST_F(GlobalFilterTest, test_manual_is_true_should_source_common_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_manual(true);

  ASSERT_FALSE(strategy_->NegativeFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_type_is_pure_video_should_source_common_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(reco::kPureVideo);

  ASSERT_FALSE(strategy_->NegativeFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_no_content_attr_should_source_common_filter_return_false) {
  RecoItem reco_item;

  ASSERT_FALSE(strategy_->NegativeFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_no_negative_should_source_common_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_content_attr();

  ASSERT_FALSE(strategy_->NegativeFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_negative_is_kSureNo_should_source_common_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_content_attr()->set_negative(reco::ContentAttr::kSureNo);

  ASSERT_FALSE(strategy_->NegativeFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_negative_is_not_kSureNo_should_source_common_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_content_attr()->set_negative(reco::ContentAttr::kSureYes);

  ASSERT_TRUE(strategy_->NegativeFilter(reco_item));
}
// end NegativeFilter

// SourceBlackFilter
TEST_F(GlobalFilterTest, test_dict_is_null_should_source_black_filter_return_false) {
  RecoItem reco_item;

  ASSERT_FALSE(strategy_->SourceBlackFilter(reco_item, NULL));
}

TEST_F(GlobalFilterTest, test_dict_is_empty_should_source_black_filter_return_false) {
  RecoItem reco_item;

  BlackSourceDict black_source_dict;

  ASSERT_FALSE(strategy_->SourceBlackFilter(reco_item, &black_source_dict));
}

const std::string NO_CARE_SOURCE = "no_care_source";
TEST_F(GlobalFilterTest, test_dict_find_should_source_black_filter_return_true) {
  RecoItem reco_item;
  reco_item.set_source(NO_CARE_SOURCE);

  BlackSourceDict black_source_dict;
  black_source_dict.dict.insert(NO_CARE_SOURCE);

  ASSERT_TRUE(strategy_->SourceBlackFilter(reco_item, &black_source_dict));
}

const std::string NO_CARE_OHTER_SOURCE = "no_care_other_source";
TEST_F(GlobalFilterTest, test_dict_not_find_should_source_black_filter_return_false) {
  RecoItem reco_item;
  reco_item.set_source(NO_CARE_SOURCE);

  BlackSourceDict black_source_dict;
  black_source_dict.dict.insert(NO_CARE_OHTER_SOURCE);

  ASSERT_FALSE(strategy_->SourceBlackFilter(reco_item, &black_source_dict));
}
// end SourceBlackFilter

// SourceWhiteFilter
TEST_F(GlobalFilterTest, test_dict_is_null_should_source_white_filter_return_false) {
  RecoItem reco_item;

  ASSERT_FALSE(strategy_->SourceWhiteFilter(reco_item, NULL));
}

TEST_F(GlobalFilterTest, test_dict_find_should_source_white_filter_return_false) {
  RecoItem reco_item;
  reco_item.set_source(NO_CARE_SOURCE);

  WhiteSourceDict white_source_dict;
  white_source_dict.dict.insert(NO_CARE_SOURCE);

  ASSERT_FALSE(strategy_->SourceWhiteFilter(reco_item, &white_source_dict));
}

TEST_F(GlobalFilterTest, test_dict_empty_should_source_white_filter_return_false) {
  RecoItem reco_item;

  WhiteSourceDict white_source_dict;

  ASSERT_FALSE(strategy_->SourceWhiteFilter(reco_item, &white_source_dict));
}

TEST_F(GlobalFilterTest, test_dict_not_find_should_source_white_filter_return_true) {
  RecoItem reco_item;

  WhiteSourceDict white_source_dict;
  white_source_dict.dict.insert(NO_CARE_OHTER_SOURCE);

  ASSERT_TRUE(strategy_->SourceWhiteFilter(reco_item, &white_source_dict));
}
// end SourceWhiteFilter

// SourcePoliticsFilter
TEST_F(GlobalFilterTest, test_dict_is_null_should_source_politics_filter_return_false) {
  RecoItem reco_item;

  ASSERT_FALSE(strategy_->SourcePoliticsFilter(reco_item, NULL));
}

TEST_F(GlobalFilterTest, test_dict_empty_should_source_politics_filter_return_false) {
  RecoItem reco_item;

  PoliticsSourceDict politics_source_dict;

  ASSERT_FALSE(strategy_->SourcePoliticsFilter(reco_item, &politics_source_dict));
}

TEST_F(GlobalFilterTest, test_item_no_content_attr_should_source_politics_filter_return_false) {
  RecoItem reco_item;

  PoliticsSourceDict politics_source_dict;
  politics_source_dict.dict.insert(NO_CARE_SOURCE);

  ASSERT_FALSE(strategy_->SourcePoliticsFilter(reco_item, &politics_source_dict));
}

TEST_F(GlobalFilterTest, test_item_no_politics_should_source_politics_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_content_attr();

  PoliticsSourceDict politics_source_dict;
  politics_source_dict.dict.insert(NO_CARE_SOURCE);

  ASSERT_FALSE(strategy_->SourcePoliticsFilter(reco_item, &politics_source_dict));
}

TEST_F(GlobalFilterTest, test_item_politics_is_kSureNo_should_source_politics_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_content_attr()->set_politics(reco::ContentAttr::kSureNo);

  PoliticsSourceDict politics_source_dict;
  politics_source_dict.dict.insert(NO_CARE_SOURCE);

  ASSERT_FALSE(strategy_->SourcePoliticsFilter(reco_item, &politics_source_dict));
}

TEST_F(GlobalFilterTest, test_dict_find_source_should_source_politics_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_content_attr()->set_politics(reco::ContentAttr::kSureYes);
  reco_item.set_source(NO_CARE_SOURCE);

  PoliticsSourceDict politics_source_dict;
  politics_source_dict.dict.insert(NO_CARE_SOURCE);

  ASSERT_FALSE(strategy_->SourcePoliticsFilter(reco_item, &politics_source_dict));
}

TEST_F(GlobalFilterTest, test_dict_not_find_source_should_source_politics_filter_return_true) {
  RecoItem reco_item;
  reco_item.mutable_content_attr()->set_politics(reco::ContentAttr::kSureYes);
  reco_item.set_source(NO_CARE_SOURCE);

  PoliticsSourceDict politics_source_dict;
  politics_source_dict.dict.insert(NO_CARE_OHTER_SOURCE);

  ASSERT_TRUE(strategy_->SourcePoliticsFilter(reco_item, &politics_source_dict));
}
// end SourcePoliticsFilter

// VideoStorageFilter
TEST_F(GlobalFilterTest, test_type_is_not_kPureVideo_should_video_storage_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(reco::kNews);

  ASSERT_FALSE(strategy_->VideoStorageFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_no_video_storage_info_should_video_storage_filter_return_true) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(reco::kPureVideo);

  ASSERT_TRUE(strategy_->VideoStorageFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_no_vid_should_video_storage_filter_return_true) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(reco::kPureVideo);
  reco_item.mutable_video_storage_info();

  ASSERT_TRUE(strategy_->VideoStorageFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_is_wemedia_should_video_storage_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(reco::kPureVideo);
  reco_item.mutable_video_storage_info()->set_youku_video_id("1");
  reco_item.set_source("cp_wemedia_uc_");

  ASSERT_FALSE(strategy_->VideoStorageFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_no_normal_should_video_storage_filter_return_true) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(reco::kPureVideo);
  reco_item.mutable_video_storage_info()->set_youku_video_id("1");

  ASSERT_TRUE(strategy_->VideoStorageFilter(reco_item));
}

TEST_F(GlobalFilterTest, test_has_normal_vid_should_video_storage_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(reco::kPureVideo);
  reco_item.mutable_video_storage_info()->set_youku_video_id("1");
  reco_item.mutable_video_storage_info()->set_normal("no_care_normal");

  ASSERT_FALSE(strategy_->VideoStorageFilter(reco_item));
}
// end VideoStorageFilter
}
}
