//
// Created by allen.fw on 2017/9/6.
//

#include <memory>
#include "base/testing/gtest.h"
#include "reco/bizc/filter_rule/offline/app_token_filter.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "base/common/logging.h"

namespace reco {
namespace filter {

class AppTokenFilterTest : public testing::Test {
 protected:
  AppTokenFilterTest() {
    strategy_ = std::shared_ptr<AppTokenFilter>();
  }

  virtual ~AppTokenFilterTest() { }

  virtual void SetUp() {
    FLAGS_v = 1;
  }

  virtual void TearDown() {
  }

 private:
  std::shared_ptr<AppTokenFilter> strategy_;
};

using reco::RecoItem;

const int NO_CARE_IDX = 0;

// IsFilteredByBlackPattern
TEST_F(AppTokenFilterTest, test_dict_is_null_should_filter_black_pattern_return_false) {
  RecoItem reco_item;
  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_title_match.push_back(NULL);

  ASSERT_FALSE(strategy_->IsFilteredByBlackPattern(0, &app_token_dict, reco_item));
}

const std::string MATCH_TITLE = "match_title";
TEST_F(AppTokenFilterTest, test_no_match_title_should_filter_black_pattern_return_false) {
  RecoItem reco_item;
  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_title_match[NO_CARE_IDX] = new extend::MultiPatternMatcher();
  ASSERT_FALSE(app_token_dict.app_token_title_match[NO_CARE_IDX] == NULL);
  ASSERT_TRUE(app_token_dict.app_token_title_match[NO_CARE_IDX]->Build());

  ASSERT_FALSE(strategy_->IsFilteredByBlackPattern(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, test_match_title_should_filter_black_pattern_return_true) {
  RecoItem reco_item;
  reco_item.set_title(MATCH_TITLE);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_title_match[NO_CARE_IDX] = new extend::MultiPatternMatcher();
  ASSERT_FALSE(app_token_dict.app_token_title_match[NO_CARE_IDX] == NULL);
  ASSERT_TRUE(app_token_dict.app_token_title_match[NO_CARE_IDX]->AddPattern(MATCH_TITLE.c_str()));
  ASSERT_TRUE(app_token_dict.app_token_title_match[NO_CARE_IDX]->Build());

  ASSERT_TRUE(strategy_->IsFilteredByBlackPattern(NO_CARE_IDX, &app_token_dict, reco_item));
}
// end IsFilteredByBlackPattern

// IsFilteredBySource
TEST_F(AppTokenFilterTest, test_dict_is_null_should_source_filter_return_false) {
  RecoItem reco_item;
  AppTokenFilterDict app_token_dict;

  ASSERT_FALSE(strategy_->IsFilteredBySource(NO_CARE_IDX, &app_token_dict, reco_item));
}

const std::string FIND_TITLE = "find_title";
TEST_F(AppTokenFilterTest, test_dict_find_source_should_source_filter_return_false) {
  RecoItem reco_item;
  reco_item.set_source(FIND_TITLE);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_white_source[NO_CARE_IDX] = new reco::common::Trie();
  app_token_dict.app_token_white_source[NO_CARE_IDX]->Insert(FIND_TITLE);

  ASSERT_FALSE(strategy_->IsFilteredBySource(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, test_dict_find_orig_source_should_source_filter_return_false) {
  RecoItem reco_item;
  reco_item.set_orig_source(FIND_TITLE);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_white_source[NO_CARE_IDX] = new reco::common::Trie();
  app_token_dict.app_token_white_source[NO_CARE_IDX]->Insert(FIND_TITLE);

  ASSERT_FALSE(strategy_->IsFilteredBySource(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, test_dict_no_find_should_source_filter_return_true) {
  RecoItem reco_item;

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_white_source[NO_CARE_IDX] = new reco::common::Trie();

  ASSERT_TRUE(strategy_->IsFilteredBySource(NO_CARE_IDX, &app_token_dict, reco_item));
}
// end IsFilteredBySource

// IsFilteredByCategory
TEST_F(AppTokenFilterTest, test_category_is_empty_should_category_filter_return_true) {
  RecoItem reco_item;

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_black_category[NO_CARE_IDX] = new reco::common::Trie();
  ASSERT_TRUE(strategy_->IsFilteredByCategory(NO_CARE_IDX, &app_token_dict, reco_item));

  reco_item.add_category();
  ASSERT_TRUE(strategy_->IsFilteredByCategory(NO_CARE_IDX, &app_token_dict, reco_item));
}

const std::string NO_CARE_CATEGORY = "no_care_category";
const std::string NO_CARE_SUB_CATEGORY = "no_care_sub_category";
TEST_F(AppTokenFilterTest, test_dict_find_category_should_category_filter_return_true) {
  RecoItem reco_item;
  reco_item.add_category(NO_CARE_CATEGORY);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_black_category[NO_CARE_IDX] = new reco::common::Trie();
  app_token_dict.app_token_black_category[NO_CARE_IDX]->Insert(NO_CARE_CATEGORY);

  ASSERT_TRUE(strategy_->IsFilteredByCategory(NO_CARE_IDX, &app_token_dict, reco_item));

  reco_item.add_category(NO_CARE_SUB_CATEGORY);
  app_token_dict.app_token_black_category[NO_CARE_IDX]->Insert(NO_CARE_CATEGORY);
  ASSERT_TRUE(strategy_->IsFilteredByCategory(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, test_dict_not_find_category_should_category_filter_return_true) {
  RecoItem reco_item;
  reco_item.add_category(NO_CARE_CATEGORY);

  AppTokenFilterDict app_token_dict;

  ASSERT_FALSE(strategy_->IsFilteredByCategory(NO_CARE_IDX, &app_token_dict, reco_item));
}
// end IsFilteredByCategory

// IsFilteredByItemDirty
TEST_F(AppTokenFilterTest, test_app_not_dirty_filter_should_dirty_filter_return_false) {
  RecoItem reco_item;

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_dirty[NO_CARE_IDX] = false;

  ASSERT_FALSE(strategy_->IsFilteredByItemDirty(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, test_app_dirty_filter_should_dirty_filter_return_correct) {
  RecoItem reco_item;

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_dirty[NO_CARE_IDX] = true;

  ASSERT_FALSE(strategy_->IsFilteredByItemDirty(NO_CARE_IDX, &app_token_dict, reco_item));

  reco_item.mutable_content_attr();
  ASSERT_FALSE(strategy_->IsFilteredByItemDirty(NO_CARE_IDX, &app_token_dict, reco_item));

  reco_item.mutable_content_attr()->set_dirty(reco::ContentAttr::kSureNo);
  ASSERT_FALSE(strategy_->IsFilteredByItemDirty(NO_CARE_IDX, &app_token_dict, reco_item));

  reco_item.mutable_content_attr()->set_dirty(reco::ContentAttr::kSuspect);
  ASSERT_TRUE(strategy_->IsFilteredByItemDirty(NO_CARE_IDX, &app_token_dict, reco_item));
}
// end IsFilteredByItemDirty

// IsFilteredByItemBluffing
TEST_F(AppTokenFilterTest, test_app_not_bluffing_title_filter_should_Bluffing_filter_return_false) {
  RecoItem reco_item;

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_bluffing_title[NO_CARE_IDX] = false;

  ASSERT_FALSE(strategy_->IsFilteredByItemBluffing(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, test_app_bluffing_title_filter_should_Bluffing_filter_return_correct) {
  RecoItem reco_item;

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_bluffing_title[NO_CARE_IDX] = true;

  ASSERT_FALSE(strategy_->IsFilteredByItemBluffing(NO_CARE_IDX, &app_token_dict, reco_item));

  reco_item.mutable_content_attr();
  ASSERT_FALSE(strategy_->IsFilteredByItemBluffing(NO_CARE_IDX, &app_token_dict, reco_item));

  reco_item.mutable_content_attr()->set_bluffing_title(reco::ContentAttr::kSureNo);
  ASSERT_FALSE(strategy_->IsFilteredByItemBluffing(NO_CARE_IDX, &app_token_dict, reco_item));

  reco_item.mutable_content_attr()->set_bluffing_title(reco::ContentAttr::kSuspect);
  ASSERT_TRUE(strategy_->IsFilteredByItemBluffing(NO_CARE_IDX, &app_token_dict, reco_item));
}
// end IsFilteredByItemBluffing

// IsFilteredBySourceWeMedia
TEST_F(AppTokenFilterTest, test_app_not_wemedia_filter_should_wemedia_filter_return_false) {
  RecoItem reco_item;

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_wemedia[NO_CARE_IDX] = false;

  ASSERT_FALSE(strategy_->IsFilteredBySourceWeMedia(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, test_item_is_wemedia_should_wemedia_filter_return_true) {
  RecoItem reco_item;
  reco_item.set_source("cp_wemedia_uc_");

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_wemedia[NO_CARE_IDX] = true;

  ASSERT_TRUE(strategy_->IsFilteredBySourceWeMedia(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, test_item_is_not_wemedia_should_wemedia_filter_return_false) {
  RecoItem reco_item;

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_wemedia[NO_CARE_IDX] = true;

  ASSERT_FALSE(strategy_->IsFilteredBySourceWeMedia(NO_CARE_IDX, &app_token_dict, reco_item));
}
// end IsFilteredBySourceWeMedia

// IsFilteredByWeMediaLevel
TEST_F(AppTokenFilterTest, test_item_not_wemedia_should_wemedia_filter_return_false) {
  RecoItem reco_item;
  AppTokenFilterDict app_token_dict;
  CateMediaLevelMap cate_media_level_dict;

  ASSERT_FALSE(strategy_->IsFilteredByWeMediaLevel(NO_CARE_IDX, &app_token_dict,
                                                    &cate_media_level_dict, reco_item));
}

TEST_F(AppTokenFilterTest,
       test_media_level_is_less_dict_level_should_wemedia_level_filter_return_correct) {
  RecoItem reco_item;
  reco_item.set_source("cp_wemedia_uc_");
  *(reco_item.add_category()) = NO_CARE_CATEGORY;

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_min_media_level[NO_CARE_IDX] = reco::kNormalMedia;

  CateMediaLevelMap cate_media_level_dict;
  cate_media_level_dict.cate_media_level_map[NO_CARE_CATEGORY + "\t"] = reco::kLowMedia;

  ASSERT_TRUE(strategy_->IsFilteredByWeMediaLevel(NO_CARE_IDX, &app_token_dict,
                                                    &cate_media_level_dict, reco_item));

  cate_media_level_dict.cate_media_level_map[NO_CARE_CATEGORY + "\t"] = reco::kGoodMedia;

  ASSERT_FALSE(strategy_->IsFilteredByWeMediaLevel(NO_CARE_IDX, &app_token_dict,
                                                   &cate_media_level_dict, reco_item));
}
// end IsFilteredByWeMediaLevel

// IsFilteredByBlackWeMediaSource
TEST_F(AppTokenFilterTest, test_dict_is_null_should_wemedia_source_filter_return_false) {
  RecoItem reco_item;
  AppTokenFilterDict app_token_dict;

  ASSERT_FALSE(strategy_->IsFilteredByBlackWeMediaSource(NO_CARE_IDX, &app_token_dict, reco_item));
}

const std::string NO_CARE_SOURCE = "no_care_source";
TEST_F(AppTokenFilterTest, test_source_in_black_dict_should_wemedia_source_filter_return_true) {
  RecoItem reco_item;
  reco_item.set_source(NO_CARE_SOURCE);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_black_source[NO_CARE_IDX] = new reco::common::Trie();
  app_token_dict.app_token_black_source[NO_CARE_IDX]->Insert(NO_CARE_SOURCE);

  ASSERT_TRUE(strategy_->IsFilteredByBlackWeMediaSource(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, test_orig_source_in_black_dict_should_wemedia_source_filter_return_true) {
  RecoItem reco_item;
  reco_item.set_orig_source(NO_CARE_SOURCE);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_black_source[NO_CARE_IDX] = new reco::common::Trie();
  app_token_dict.app_token_black_source[NO_CARE_IDX]->Insert(NO_CARE_SOURCE);

  ASSERT_TRUE(strategy_->IsFilteredByBlackWeMediaSource(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, test_source_not_in_black_dict_should_wemedia_source_filter_return_false) {
  RecoItem reco_item;
  reco_item.set_source(NO_CARE_SOURCE);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_black_source[NO_CARE_IDX] = new reco::common::Trie();

  ASSERT_FALSE(strategy_->IsFilteredByBlackWeMediaSource(NO_CARE_IDX, &app_token_dict, reco_item));
}
// end IsFilteredByBlackWeMediaSource

// MainCityBadItemFIlter
TEST_F(AppTokenFilterTest, test_no_need_city_filter_should_city_filter_return_false) {
  RecoItem reco_item;
  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_main_city[NO_CARE_IDX] = false;

  ASSERT_FALSE(strategy_->MainCityBadItemFIlter(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, test_item_dirty_filter_should_city_filter_return_correct) {
  RecoItem reco_item;
  reco_item.mutable_content_attr()->set_dirty(reco::ContentAttr::kSuspect);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_main_city[NO_CARE_IDX] = true;

  ASSERT_TRUE(strategy_->MainCityBadItemFIlter(NO_CARE_IDX, &app_token_dict, reco_item));
}
// end MainCityBadItemFIlter

// BitsetToString
TEST_F(AppTokenFilterTest, test_bitset_to_string_should_return_correct) {
  // init
  boost::dynamic_bitset<uint8> app_rule_mask;
  app_rule_mask.resize(13, false);
  for (size_t i = 0; i < app_rule_mask.size(); ++i) {
    if (i < 4) {
      app_rule_mask.set(i, true);
    }
  }
  app_rule_mask.set(12, true);

  // to_string
  std::string view_rule_bits;
  boost::to_string(app_rule_mask, view_rule_bits);
  LOG(INFO) << "view_rule_bits: " << view_rule_bits;

  // bitset to string
  std::string value;
  strategy_->BitsetToString(app_rule_mask, &value);

  // set pb
  RecoItem reco_item;
  reco_item.mutable_offline_filter_rule()->mutable_app_token_rule_bits()->set_rule_bits(value);

  // pb to string
  std::string value_pb = reco_item.offline_filter_rule().app_token_rule_bits().rule_bits();
  boost::dynamic_bitset<uint8> result(16);
  boost::from_block_range(value_pb.begin(), value_pb.end(), result);
  std::string result_value;
  boost::to_string(result, result_value);
  LOG(INFO) << "result: " << result_value;

  // check
  ASSERT_TRUE(result_value.substr(result_value.size() - view_rule_bits.size()) == view_rule_bits);
}
// end BitsetToString

// VideoLengthFilter
TEST_F(AppTokenFilterTest, type_is_not_kPureVideo_should_video_len_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(kNews);

  ASSERT_FALSE(strategy_->VideoLengthFilter(NO_CARE_IDX, NULL, reco_item));
}

TEST_F(AppTokenFilterTest, dict_is_false_should_video_len_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(kPureVideo);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_video_length[NO_CARE_IDX].is_lenght_filter = false;

  ASSERT_FALSE(strategy_->VideoLengthFilter(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, time_request_is_le_zero_should_video_len_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(kPureVideo);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_video_length[NO_CARE_IDX].is_lenght_filter = true;
  app_token_dict.app_token_video_length[NO_CARE_IDX].common_max_len = 0;

  ASSERT_FALSE(strategy_->VideoLengthFilter(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, time_request_should_video_len_filter_return_correct) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(kPureVideo);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_video_length[NO_CARE_IDX].is_lenght_filter = true;
  // 这个是分钟
  app_token_dict.app_token_video_length[NO_CARE_IDX].common_max_len = 1;

  // 这个是秒
  reco_item.add_video_meta_settings()->set_play_length(1);
  ASSERT_FALSE(strategy_->VideoLengthFilter(NO_CARE_IDX, &app_token_dict, reco_item));

  reco_item.mutable_video_meta_settings(0)->set_play_length(61);
  ASSERT_TRUE(strategy_->VideoLengthFilter(NO_CARE_IDX, &app_token_dict, reco_item));
}
// end VideoLengthFilter

// ProducerWemediaYoutuFilter
TEST_F(AppTokenFilterTest, type_is_not_kPureVideo_should_wemedia_youtu_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(kNews);

  ASSERT_FALSE(strategy_->ProducerWemediaYoutuFilter(NO_CARE_IDX, NULL, reco_item));
}

TEST_F(AppTokenFilterTest, dict_is_false_should_wemedia_youtu_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(kPureVideo);

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_wemedia_youtu[NO_CARE_IDX] = false;

  ASSERT_FALSE(strategy_->ProducerWemediaYoutuFilter(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, producer_is_wemedia_tudou_should_wemedia_youtu_filter_return_true) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(kPureVideo);
  reco_item.mutable_identity()->set_producer("cp_wemedia_youtu");

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_wemedia_youtu[NO_CARE_IDX] = true;

  ASSERT_TRUE(strategy_->ProducerWemediaYoutuFilter(NO_CARE_IDX, &app_token_dict, reco_item));
}

TEST_F(AppTokenFilterTest, producer_is_not_wemedia_tudou_should_wemedia_youtu_filter_return_false) {
  RecoItem reco_item;
  reco_item.mutable_identity()->set_type(kPureVideo);
  reco_item.mutable_identity()->set_producer("no_care");

  AppTokenFilterDict app_token_dict;
  app_token_dict.app_token_filter_wemedia_youtu[NO_CARE_IDX] = true;

  ASSERT_FALSE(strategy_->ProducerWemediaYoutuFilter(NO_CARE_IDX, &app_token_dict, reco_item));
}
// end ProducerWemediaYoutuFilter
}
}
