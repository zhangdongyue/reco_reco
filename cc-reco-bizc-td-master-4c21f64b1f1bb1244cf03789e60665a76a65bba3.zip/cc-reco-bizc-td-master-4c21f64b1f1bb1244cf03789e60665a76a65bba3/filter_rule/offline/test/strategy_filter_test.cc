//
// Created by allen.fw on 2017/9/4.
//

#include <memory>
#include "base/testing/gtest.h"
#include "reco/bizc/filter_rule/offline/strategy_filter.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "base/common/logging.h"

namespace reco {
namespace filter {

class StrategyFilterTest : public testing::Test {
 protected:
  StrategyFilterTest() {
    strategy_ = std::shared_ptr<StrategyFilter>();
  }
  virtual ~StrategyFilterTest() {}

  virtual void SetUp() {
    FLAGS_v = 1;
  }

  virtual void TearDown() {
  }

 private:
  std::shared_ptr<StrategyFilter> strategy_;
};

// FirstNScreenFilter
TEST_F(StrategyFilterTest, dict_is_null_should_first_nscreen_filter_return_false) {
  ASSERT_FALSE(strategy_->FirstNScreenFilter(NULL, NULL));
}

TEST_F(StrategyFilterTest, title_is_null_should_first_nscreen_filter_return_false) {
  FirstNScreenFilterDict filter_nscreen_filter_dict;
  reco::RecoItem reco_item;

  ASSERT_FALSE(strategy_->FirstNScreenFilter(&filter_nscreen_filter_dict, &reco_item));
}

const std::string NO_CARE_TITLE = "no_care_title";
TEST_F(StrategyFilterTest, dict_is_empty_should_first_nscreen_filter_return_false) {
  FirstNScreenFilterDict filter_nscreen_filter_dict;

  reco::RecoItem reco_item;
  reco_item.set_normalized_title(NO_CARE_TITLE);

  ASSERT_FALSE(strategy_->FirstNScreenFilter(&filter_nscreen_filter_dict, &reco_item));
}

const int NO_CARE_FORBID_SCREEN = 3;
TEST_F(StrategyFilterTest, test_dict_found_title_should_first_nscreen_filter_return_true) {
  FirstNScreenInfo dict_info;
  dict_info.forbid_screen = NO_CARE_FORBID_SCREEN;
  dict_info.forbid_pattern->AddPattern(NO_CARE_TITLE.c_str());
  dict_info.forbid_pattern->Build();

  FirstNScreenFilterDict filter_nscreen_filter_dict;
  filter_nscreen_filter_dict.forbid_dict.emplace_back(dict_info);

  reco::RecoItem reco_item;
  reco_item.set_normalized_title(NO_CARE_TITLE);

  ASSERT_TRUE(strategy_->FirstNScreenFilter(&filter_nscreen_filter_dict, &reco_item));
}

const std::string NO_CARE_OTHER_TILE = "no_care_other_title";
TEST_F(StrategyFilterTest, test_dict_not_found_title_should_first_nscreen_filter_return_false) {
  FirstNScreenInfo dict_info;
  dict_info.forbid_screen = NO_CARE_FORBID_SCREEN;
  dict_info.forbid_pattern->AddPattern(NO_CARE_OTHER_TILE.c_str());
  dict_info.forbid_pattern->Build();

  FirstNScreenFilterDict filter_nscreen_filter_dict;
  filter_nscreen_filter_dict.forbid_dict.emplace_back(dict_info);

  reco::RecoItem reco_item;
  reco_item.set_normalized_title(NO_CARE_TITLE);

  ASSERT_FALSE(strategy_->FirstNScreenFilter(&filter_nscreen_filter_dict, &reco_item));
}
// end FirstNScreenFilter

// PublishPlatformBySource
TEST_F(StrategyFilterTest, test_item_has_pulish_platform_should_publish_platform_return_true) {
  reco::RecoItem reco_item;
  reco_item.add_publish_platform(reco::kUCToutiaoPlatform);

  ASSERT_TRUE(strategy_->PublishPlatform(&reco_item));
  ASSERT_EQ(reco_item.offline_filter_rule().real_publish_platform_size(), 1);
  ASSERT_EQ(reco_item.offline_filter_rule().real_publish_platform(0), reco::kUCToutiaoPlatform);
}

TEST_F(StrategyFilterTest, test_dict_is_null_should_publish_platform_by_source_return_false) {
  reco::RecoItem reco_item;

  ASSERT_FALSE(strategy_->PublishPlatformBySource(NULL, &reco_item));
}

const std::string NO_CARE_SOURCE = "no_care_source";
const std::string NO_CARE_ORIG_SOURCE = "no_care_orig_source";
TEST_F(StrategyFilterTest,
       test_item_source_not_found_platform_should_publish_platform_by_source_return_false) {
  reco::RecoItem reco_item;
  reco_item.set_source(NO_CARE_SOURCE);

  SourcePlatformDict source_platform_dict;

  ASSERT_FALSE(strategy_->PublishPlatformBySource(&source_platform_dict, &reco_item));

  reco_item.set_orig_source(NO_CARE_ORIG_SOURCE);
  ASSERT_FALSE(strategy_->PublishPlatformBySource(&source_platform_dict, &reco_item));
}

TEST_F(StrategyFilterTest, test_item_source_found_platform_should_publish_platform_by_source_return_true) {
  reco::RecoItem reco_item;
  reco_item.set_source(NO_CARE_SOURCE);

  SourcePlatformDict source_platform_dict;
  source_platform_dict.source_platforms[NO_CARE_SOURCE] = {reco::kUCToutiaoPlatform};

  ASSERT_TRUE(strategy_->PublishPlatformBySource(&source_platform_dict, &reco_item));
  ASSERT_EQ(reco_item.offline_filter_rule().real_publish_platform_size(), 1);
  ASSERT_EQ(reco_item.offline_filter_rule().real_publish_platform(0), reco::kUCToutiaoPlatform);
}

TEST_F(StrategyFilterTest,
       test_item_orig_source_found_platform_should_publish_platform_by_source_return_true) {
  reco::RecoItem reco_item;
  reco_item.set_source(NO_CARE_SOURCE);
  reco_item.set_orig_source(NO_CARE_ORIG_SOURCE);

  SourcePlatformDict source_platform_dict;
  source_platform_dict.source_platforms[NO_CARE_ORIG_SOURCE] = {reco::kUCToutiaoPlatform};

  ASSERT_TRUE(strategy_->PublishPlatformBySource(&source_platform_dict, &reco_item));
  ASSERT_EQ(reco_item.offline_filter_rule().real_publish_platform_size(), 1);
  ASSERT_EQ(reco_item.offline_filter_rule().real_publish_platform(0), reco::kUCToutiaoPlatform);
}
// end PublishPlatformBySource
}
}
