//
// Created by allen.fw on 2017/8/30.
//

#include <string>
#include "reco/bizc/filter_rule/offline/global_filter.h"
#include "base/strings/utf_char_iterator.h"
#include "base/hash_function/term.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "base/strings/string_util.h"

namespace reco {
namespace filter {

DEFINE_bool(do_video_risk_check, false, "");
DEFINE_bool(do_video_special_filter, false, "");
DEFINE_int32(title_min_len, 0, "tile最小长度");
DEFINE_int32(title_max_len, 255, "title最大长度");
DEFINE_bool(do_video_storage_filter, true, "");

DEFINE_int64_counter(filter_server, common_filter_count, 0, "");
DEFINE_int64_counter(filter_server, video_filter_count, 0, "");

const std::string SOURCE_WEMEDIA_PREFIX = "cp_wemedia_uc_";
bool GlobalFilter::FilterRule(RecoItem* reco_item) {
  if (FilterInterface(*reco_item)) {
    reco_item->mutable_offline_filter_rule()->set_is_filter(true);
    return true;
  }

  reco_item->mutable_offline_filter_rule()->set_is_filter(false);
  return false;
}

bool GlobalFilter::FilterInterface(const RecoItem& item) {
  bool ret = false;
  do {
    ret = PicNumFilter(item);
    if (ret) {
      break;
    }

    ret = SourceFilter(item);
    if (ret) {
      break;
    }
  } while (false);
  if (ret) {
    COUNTERS_filter_server__common_filter_count.Increase(1);
    return true;
  }

  do {
    ret = VideoStorageFilter(item);
    if (ret) {
      break;
    }

    ret = ResolutionFilter(item);
    if (ret) {
      break;
    }
  } while (false);
  if (ret) {
    COUNTERS_filter_server__video_filter_count.Increase(1);
    return true;
  }

  return false;
}

bool GlobalFilter::PicNumFilter(const RecoItem& item) {
  if ((item.identity().type() == ::reco::kPicture || item.identity().type() == ::reco::kPictureNews)
          && item.image_size() < 3) {
    LOG(INFO) << "item filter by pic num is less 3, item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}

bool GlobalFilter::TitleFilter(const RecoItem& item) {
  // 只对机器下发的新闻进行过滤
  if (item.identity().has_manual() && item.identity().manual()) {
    VLOG(1) << "manual item, item_id: " << item.identity().item_id();
    return false;
  }

  int title_len = -1;
  if (!item.has_normalized_title() || !base::GetUTF8CharNum(item.normalized_title(), &title_len)) {
    LOG(INFO) << "item filter by no title, item_id: " << item.identity().item_id();
    return true;
  }

  if (title_len < FLAGS_title_min_len) {
    LOG(INFO) << "item filter by title len [" << title_len << "] is less min len ["
            << FLAGS_title_min_len << "], item_id: " << item.identity().item_id();
    return true;
  }

  if (title_len > FLAGS_title_max_len) {
    LOG(INFO) << "item filter by title len [" << title_len << "] is beyond max len ["
          << FLAGS_title_max_len << "], item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}

bool GlobalFilter::RiskMediaFilter(const RecoItem& item) {
  auto risk_media_dict = DM_GET_DICT(reco::filter::RiskMediaDict,
                                     reco::filter::DynamicDictContainer::kRiskMediaFile);
  if (risk_media_dict == NULL) {
    return false;
  }

  if (item.identity().type() == reco::kPureVideo) {
    // 视频的逻辑
    if (VideoRiskMediaFilter(item, risk_media_dict.get())) {
      return true;
    }
  } else {
    // 文本的逻辑
    if (ImageTxtRiskMediaFilter(item, risk_media_dict.get())) {
      return true;
    }
  }

  return false;
}

bool GlobalFilter::VideoRiskMediaFilter(const RecoItem& item, const RiskMediaDict* risk_media_dict) {
  if (item.identity().type() != reco::kPureVideo) {
    return false;
  }

  // 判断视频风险
  bool video_risk = VideoHasRisk(item);

  // 有风险则进一步进行文本逻辑过滤
  if (video_risk && ImageTxtRiskMediaFilter(item, risk_media_dict)) {
    return true;
  }

  // special
  return YoutobeRiskMediaFilter(item, risk_media_dict);
}

bool GlobalFilter::VideoHasRisk(const RecoItem& item) {
  if (!FLAGS_do_video_risk_check) {
    return false;
  }
  if (!item.has_video_storage_info()) {
    LOG(INFO) << "item filter by no video_storage_info, item_id: " << item.identity().item_id();
    return true;
  }

  if (!item.video_storage_info().has_normal()) {
    LOG(INFO) << "item filter by video_storage_info no normal, item_id: " << item.identity().item_id();
    return true;
  }

  if (item.video_storage_info().normal().empty()) {
    LOG(INFO) << "item filter by video_storage_info normal is empty, item_id: " << item.identity().item_id();
    return true;
  }

  if (!item.video_storage_info().has_status()) {
    LOG(INFO) << "item filter by video_storage_info no status, item_id: " << item.identity().item_id();
    return true;
  }

  if (item.video_storage_info().status() != 1) {
    LOG(INFO) << "item filter by video_storage_info status is not 1, item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}

bool GlobalFilter::ImageTxtRiskMediaFilter(const RecoItem& item,
                                                  const RiskMediaDict* risk_media_dict) {
  // 不过滤来自 UC 的自媒体
  if (base::StartsWith(item.source(), SOURCE_WEMEDIA_PREFIX, false)) {
    return false;
  }

  std::string source_media;
  if (item.has_source_media()) {
    source_media = item.source_media();
  }
  uint64 source_media_sign = base::CalcTermSign(source_media.c_str(), source_media.size());
  if (InnerImageTxtRiskMediaFilter(source_media_sign, risk_media_dict)) {
    LOG(INFO) << "item filter by source_media_sign, item_id: " << item.identity().item_id();
    return true;
  }

  std::string orig_source_media;
  if (item.has_orig_source_media()) {
    source_media = item.orig_source_media();
  }
  uint64 orig_source_media_sign = base::CalcTermSign(orig_source_media.c_str(),
                                                     orig_source_media.size());
  if (InnerImageTxtRiskMediaFilter(orig_source_media_sign, risk_media_dict)) {
    LOG(INFO) << "item filter by orig_source_media_sign, item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}

bool GlobalFilter::InnerImageTxtRiskMediaFilter(const uint64 media_sign,
                                                       const RiskMediaDict* risk_media_dict) {
  auto it = risk_media_dict->risk_media_map.find(media_sign);
  if (it == risk_media_dict->risk_media_map.end()) {
    return false;
  }

  if (it->second.level == RiskMediaInfo::kLevelForbiden) {
    return true;
  }

  return false;
}

bool GlobalFilter::YoutobeRiskMediaFilter(const RecoItem& item,
                                                 const RiskMediaDict* risk_media_dict) {
  if (!FLAGS_do_video_special_filter) {
    return false;
  }

  if (!item.has_source_media()) {
    VLOG(1) << "item no source media, item_id: " << item.identity().item_id();
    return false;
  }

  static const uint64 special_source = base::CalcTermSign("youtube", 7);
  uint64 source_media_sign = base::CalcTermSign(item.source_media().c_str(), item.source_media().size());
  if (source_media_sign == special_source) {
    auto it = risk_media_dict->risk_media_map.find(source_media_sign);
    if (it == risk_media_dict->risk_media_map.end()) {
      VLOG(1) << "youtobe item no risk, item_id: " << item.identity().item_id();
      return false;
    }
    if (!item.has_has_reviewed() || !item.has_reviewed()) {
      VLOG(1) << "youtobe item filter cause no reviewd, item_id: " << item.identity().item_id();
      return true;
    }
  }

  return false;
}

bool GlobalFilter::SourceFilter(const RecoItem& item) {
  // 只对机器下发的新闻进行过滤
//  if (NegativeFilter(item)) {
//    VLOG(1) << "NegativeFilter item, item_id: " << item.identity().item_id();
//    return true;
//  }
  if (item.identity().has_manual() && item.identity().manual()) {
    return false;
  }

  auto black_source_dict = DM_GET_DICT(BlackSourceDict,
                                       reco::filter::DynamicDictContainer::kBlackSourceFile);
  if (SourceBlackFilter(item, black_source_dict.get())) {
    VLOG(1) << "SourceBlackFilter item, item_id: " << item.identity().item_id();
    return true;
  }

  auto white_source_dict = DM_GET_DICT(WhiteSourceDict,
                                       reco::filter::DynamicDictContainer::kWhiteSourceFile);
  if (SourceWhiteFilter(item, white_source_dict.get())) {
    VLOG(1) << "SourceWhiteFilter item, item_id: " << item.identity().item_id();
    return true;
  }

  auto politics_source_dict = DM_GET_DICT(PoliticsSourceDict,
                                       reco::filter::DynamicDictContainer::kPoliticsSourceFile);
  if (SourcePoliticsFilter(item, politics_source_dict.get())) {
    VLOG(1) << "SourcePoliticsFilter item, item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}

bool GlobalFilter::NegativeFilter(const RecoItem& item) {
  if (item.identity().has_manual() && item.identity().manual()) {
    VLOG(1) << "item manual is true, item_id: " << item.identity().item_id();
    return false;
  }

  if (item.identity().type() == reco::kPureVideo) {
    VLOG(1) << "item type is kPureVideo, item_id: " << item.identity().item_id();
    return false;
  }

  if (!item.has_content_attr()) {
    VLOG(1) << "item no content_attr, item_id: " << item.identity().item_id();
    return false;
  }

  if (!item.content_attr().has_negative()) {
    VLOG(1) << "item no negative, item_id: " << item.identity().item_id();
    return false;
  }

  if (item.content_attr().negative() == reco::ContentAttr::kSureNo) {
    VLOG(1) << "item negative is not kSureNo, item_id: " << item.identity().item_id();
    return false;
  }

  LOG(INFO) << "item filter by NegativeFilter, item_id: " << item.identity().item_id();
  return true;
}

bool GlobalFilter::SourceBlackFilter(const RecoItem& item,
                                            const BlackSourceDict* black_source_dict) {
  if (black_source_dict == NULL) {
    return false;
  }

  if (black_source_dict->dict.empty()) {
    return false;
  }

  if (black_source_dict->dict.find(item.source()) != black_source_dict->dict.end()) {
    LOG(INFO) << "item filter by SourceBlackFilter, item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}

bool GlobalFilter::SourceWhiteFilter(const RecoItem& item,
                                            const WhiteSourceDict* white_source_dict) {
  if (white_source_dict == NULL) {
    return false;
  }

  if (white_source_dict->dict.empty()) {
    return false;
  }

  if (white_source_dict->dict.find(item.source()) == white_source_dict->dict.end()) {
    LOG(INFO) << "item filter by SourceWhiteFilter, item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}

bool GlobalFilter::SourcePoliticsFilter(const RecoItem& item,
                                               const PoliticsSourceDict* politics_source_dict) {
  if (politics_source_dict == NULL) {
    return false;
  }

  if (politics_source_dict->dict.empty()) {
    return false;
  }

  if (!item.has_content_attr()) {
    VLOG(1) << "item no content_attr, item_id: " << item.identity().item_id();
    return false;
  }

  if (!item.content_attr().has_politics()) {
    VLOG(1) << "item no politics, item_id: " << item.identity().item_id();
    return false;
  }

  if (item.content_attr().politics() == ::reco::ContentAttr::kSureNo) {
    VLOG(1) << "item politics is kSureNo, item_id: " << item.identity().item_id();
    return false;
  }

  if (politics_source_dict->dict.find(item.source()) != politics_source_dict->dict.end()) {
    VLOG(1) << "politics_source_dict find source fail, item_id: " << item.identity().item_id();
    return false;
  }

  LOG(INFO) << "item filter by SourcePoliticsFilter, item_id: " << item.identity().item_id();
  return true;
}

bool GlobalFilter::VideoStorageFilter(const RecoItem& item) {
//  if (item.identity().has_manual() && item.identity().manual()) {
//    return false;
//  }
  if (!FLAGS_do_video_storage_filter) {
    return false;
  }

  if (item.identity().type() != reco::kPureVideo) {
    return false;
  }

  if (!item.has_video_storage_info()) {
    LOG(INFO) << "item filter by VideoStorageFilter, item_id: " << item.identity().item_id();
    return true;
  }

  if (!item.video_storage_info().has_youku_video_id()
      || item.video_storage_info().youku_video_id().empty()) {
    LOG(INFO) << "item filter by VideoStorageFilter, item_id: " << item.identity().item_id();
    return true;
  }

  if (base::StartsWith(item.source(), SOURCE_WEMEDIA_PREFIX, false)) {
    return false;
  }

  if (!item.video_storage_info().has_normal()
      || item.video_storage_info().normal().empty()) {
    LOG(INFO) << "item filter by VideoStorageFilter, item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}

bool GlobalFilter::ResolutionFilter(const RecoItem& item) {
  if (item.identity().type() != reco::kPureVideo) {
    return false;
  }

  // 只对机器下发的新闻进行过滤
  if (item.identity().has_manual() && item.identity().manual()) {
    VLOG(1) << "manual item not filter, item_id: " << item.identity().item_id();
    return false;
  }

  if (!item.has_video_storage_info()) {
    return false;
  }

  if (!item.video_storage_info().has_resolution()) {
    return false;
  }

  if (item.video_storage_info().resolution() == "low") {
    LOG(INFO) << "item filter by resolution, item_id: " << item.identity().item_id();
    return true;
  }

  return false;
}
}
}
