//
// Created by allen.fw on 2017/8/30.
//

#include <string>
#include <vector>
#include <unordered_map>
#include "reco/bizc/filter_rule/offline/strategy_filter.h"
#include "base/strings/utf_char_iterator.h"
#include "base/hash_function/term.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "base/time/timestamp.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace filter {

void StrategyFilter::FilterRule(RecoItem* reco_item) {
  auto filter_nscreen_filter_dict = DM_GET_DICT(FirstNScreenFilterDict,
            reco::filter::DynamicDictContainer::kFirstNScreenFilterFile);
  FirstNScreenFilter(filter_nscreen_filter_dict.get(), reco_item);

  PublishPlatform(reco_item);

  return;
}

bool StrategyFilter::FirstNScreenFilter(const FirstNScreenFilterDict* filter_nscreen_filter_dict,
                                               RecoItem* item) {
  if (filter_nscreen_filter_dict == NULL) {
    VLOG(1) << "filter_nscreen_filter_dict is NULL";
    return false;
  }

  if (!item->has_normalized_title()) {
    VLOG(1) << "item no normalized_title, item_id: " << item->identity().item_id();
    return false;
  }

  extend::MatchResult result;
  auto const& forbid_dict = filter_nscreen_filter_dict->forbid_dict;
  for (size_t i = 0; i < forbid_dict.size(); ++i) {
    if (forbid_dict[i].forbid_pattern->Match(item->normalized_title().c_str(),
                                             item->normalized_title().size(), &result)) {
      item->mutable_offline_filter_rule()->set_first_nscreen_filter(forbid_dict[i].forbid_screen);
      LOG(INFO) << "item filter by FirstNScreenFilter, item_id: " << item->identity().item_id()
                << ", first n screen: " << forbid_dict[i].forbid_screen;
      return true;
    }
  }

  VLOG(1) << "not in any forbid, item_id: " << item->identity().item_id();
  return false;
}

bool StrategyFilter::PublishPlatform(RecoItem* item) {
  item->mutable_offline_filter_rule()->clear_real_publish_platform();
  if (item->publish_platform_size() > 0) {
    reco::OfflineFilterRule* offline_filter_rule = item->mutable_offline_filter_rule();
    for (int i = 0; i < item->publish_platform_size(); ++i) {
      offline_filter_rule->add_real_publish_platform(item->publish_platform(i));
    }
    return true;
  }
  return PublishPlatformBySource(item);
}

bool StrategyFilter::PublishPlatformBySource(RecoItem* item) {
  auto source_platform_dict = DM_GET_DICT(SourcePlatformDict,
                                          reco::filter::DynamicDictContainer::kSourcePlatformFile);
  return PublishPlatformBySource(source_platform_dict.get(), item);
}

bool StrategyFilter::PublishPlatformBySource(const SourcePlatformDict* source_platform_dict,
                                             RecoItem* item) {
  if (source_platform_dict == NULL) {
    return false;
  }
  std::unordered_map<std::string, std::vector<reco::RestrictPulishPlatform> >::const_iterator it
          = source_platform_dict->source_platforms.find(item->source());
  if (it == source_platform_dict->source_platforms.end()) {
    if (!item->has_orig_source()) {
      VLOG(1) << "item has no source platform, item id: " << item->identity().item_id();
      return false;
    }
    it = source_platform_dict->source_platforms.find(item->orig_source());
    if (it == source_platform_dict->source_platforms.end()) {
      VLOG(1) << "item has no source platform, item id: " << item->identity().item_id();
      return false;
    }
  }
  reco::OfflineFilterRule* offline_filter_rule = item->mutable_offline_filter_rule();
  const std::vector<reco::RestrictPulishPlatform>& platforms = it->second;
  for (size_t i = 0; i < platforms.size(); ++i) {
    offline_filter_rule->add_real_publish_platform(platforms[i]);
  }

  return true;
}
}
}
