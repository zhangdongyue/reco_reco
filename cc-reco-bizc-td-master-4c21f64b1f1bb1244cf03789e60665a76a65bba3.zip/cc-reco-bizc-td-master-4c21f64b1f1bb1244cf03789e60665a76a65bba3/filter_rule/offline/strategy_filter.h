//
// Created by allen.fw on 2017/8/30.
//
#pragma once

#include "reco/bizc/proto/filter_rule.pb.h"

namespace reco {
class RecoItem;

namespace filter {
class FirstNScreenFilterDict;
class SourcePlatformDict;
class StrategyFilter {
 public:
  StrategyFilter() {}
  ~StrategyFilter() {}

  void FilterRule(RecoItem* reco_item);

 private:
  bool FirstNScreenFilter(const FirstNScreenFilterDict* filter_nscreen_filter_dict, RecoItem* item);
  bool PublishPlatform(RecoItem* item);

  bool PublishPlatformBySource(RecoItem* item);
  bool PublishPlatformBySource(const SourcePlatformDict* source_platform_dict, RecoItem* item);
};
}
}
