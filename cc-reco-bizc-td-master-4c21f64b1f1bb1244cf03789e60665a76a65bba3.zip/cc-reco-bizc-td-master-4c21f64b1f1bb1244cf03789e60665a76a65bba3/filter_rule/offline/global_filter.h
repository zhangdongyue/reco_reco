//
// Created by allen.fw on 2017/8/30.
//

#pragma once

#include "reco/bizc/proto/item.pb.h"
#include "base/common/gflags.h"
#include "base/common/basic_types.h"

namespace reco {
class RecoItem;

namespace filter {
class RiskMediaDict;
class BlackSourceDict;
class WhiteSourceDict;
class PoliticsSourceDict;
DECLARE_bool(do_video_risk_check);
DECLARE_bool(do_video_special_filter);

class GlobalFilter {
 public:
  GlobalFilter() {}
  virtual ~GlobalFilter() {}

  bool FilterRule(RecoItem* reco_item);

 private:
  bool FilterInterface(const RecoItem& item);

  bool PicNumFilter(const RecoItem& item);
  bool TitleFilter(const RecoItem& item);
  bool RiskMediaFilter(const RecoItem& item);
  bool VideoRiskMediaFilter(const RecoItem& item, const RiskMediaDict* risk_media_dict);
  bool ImageTxtRiskMediaFilter(const RecoItem& item, const RiskMediaDict* risk_media_dict);
  bool SourceFilter(const RecoItem& item);

  bool VideoHasRisk(const RecoItem& item);
  bool InnerImageTxtRiskMediaFilter(const uint64 media_sign, const RiskMediaDict* risk_media_dict);

  bool YoutobeRiskMediaFilter(const RecoItem& item, const RiskMediaDict* risk_media_dict);

  bool NegativeFilter(const RecoItem& item);
  bool SourceBlackFilter(const RecoItem& item, const BlackSourceDict* black_source_dict);
  bool SourceWhiteFilter(const RecoItem& item, const WhiteSourceDict* white_source_dict);
  bool SourcePoliticsFilter(const RecoItem& item, const PoliticsSourceDict* politics_source_dict);

  bool VideoStorageFilter(const RecoItem& item);
  bool ResolutionFilter(const RecoItem& item);
};
}
}
