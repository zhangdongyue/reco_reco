//
// Created by dongyue.zdy on 2017/10/24.
//

#include <memory>
#include <fstream>
#include "base/testing/gtest.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "reco/bizc/filter_rule/online/component/video_playback_attr_rule.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "reco/bizc/common/appname_define.h"

namespace reco {

namespace dm {
DECLARE_string(dict_manager_root_dir);
}  // namespace dm

namespace filter {
#define DM_LOAD_DICT(var) reco::dm::DictManagerSingleton::instance().ReloadByDictName(#var)

class FilterRuleTest : public testing::Test {
 protected:
  FilterRuleTest() {
  }

  virtual ~FilterRuleTest() { }

  virtual void SetUp() {
    FLAGS_v = 1;
  }

  virtual void TearDown() {
  }

 private:
};

TEST_F(FilterRuleTest, VideoPlaybackAttrRule) {
  // --dict_manager_root_dir=
  // "/data3/dongyue.zdy/sm-xss/cc-reco-bizc/filter_rule/common/test/test_data"

  std::string vpaf_yaml = "video_playback_attr_filter.yaml";

  DM_REGISTER_CUSTOMER_DICT(VideoPlaybackAttrFilterDict,
                            vpaf_yaml,
                            LoadVideoPlaybackAttrFilterDict);
  // DM_LOAD_DICT(vpaf_yaml);
  reco::dm::DictManagerSingleton::instance().ReloadByDictName("vpaf_yaml");

  ::base::Version ver1("5.6.0");
  ::base::Version ver2("5.5.1");
  ::base::Version ver3("");
  ASSERT_TRUE(ver1.CompareTo(ver2) >= 0);
  ASSERT_TRUE(!ver3.IsValid());
  ASSERT_TRUE(ver1.CompareTo(ver3) >= 0);

  boost::shared_ptr<VideoPlaybackAttrRule> vpar(new VideoPlaybackAttrRule());
  ASSERT_TRUE(vpar->JugdeVersion("5.6.0",  ::base::Version(""),      ::base::Version("")));
  ASSERT_TRUE(vpar->JugdeVersion("5.6.0",  ::base::Version(""),      ::base::Version("5.6.1")));
  ASSERT_FALSE(vpar->JugdeVersion("5.6.0", ::base::Version(""),      ::base::Version("5.5.1")));
  ASSERT_TRUE(vpar->JugdeVersion("5.6.0",  ::base::Version("5.5.1"), ::base::Version("")));
  ASSERT_FALSE(vpar->JugdeVersion("5.6.0", ::base::Version("5.6.2"), ::base::Version("")));
  ASSERT_TRUE(vpar->JugdeVersion("5.6.0",  ::base::Version("5.6.0"), ::base::Version("5.6.2")));
  ASSERT_FALSE(vpar->JugdeVersion("5.6.0", ::base::Version("5.7.0"), ::base::Version("5.6.2")));

  // build Options
  Options options;
  options.video_playback_attr_filter_dict
    = DM_GET_DICT(reco::filter::VideoPlaybackAttrFilterDict, vpaf_yaml);
  options.is_ios = true;
  options.news_index = NULL;  // new NewsIndex(NULL);
  options.app_name = ::reco::common::kUcIflow;
  options.channel_id = 10016;
  options.ve = "5.4.6";
  ASSERT_TRUE(options.video_playback_attr_filter_dict);

  // build AspectRatioInfo
  AspectRatioInfo asp_ratio_info;
  ItemInfo item;
  asp_ratio_info.mode = kLandscape;
  ASSERT_TRUE(vpar->JugdeAspectRatio(options, asp_ratio_info, item));

  asp_ratio_info.mode = kPortrait;
  ASSERT_FALSE(vpar->JugdeAspectRatio(options, asp_ratio_info, item));

  asp_ratio_info.mode = kFix;
  asp_ratio_info.w = 5;
  asp_ratio_info.h = 3;
  ASSERT_TRUE(vpar->JugdeAspectRatio(options, asp_ratio_info, item));

  asp_ratio_info.mode = kFix;
  asp_ratio_info.w = 5;
  asp_ratio_info.h = 4;
  ASSERT_FALSE(vpar->JugdeAspectRatio(options, asp_ratio_info, item));

  asp_ratio_info.mode = kFix;
  asp_ratio_info.platform = "andriod";
  asp_ratio_info.app_name = ::reco::common::kUcIflow;  // "uc_iflow";
  asp_ratio_info.ve_s = ::base::Version("5.3.0");
  asp_ratio_info.ve_e = ::base::Version("5.4.7");
  asp_ratio_info.w = 5;
  asp_ratio_info.h = 3;
  ASSERT_FALSE(vpar->HitAspectRatioFilterRule(options, asp_ratio_info, item));
  asp_ratio_info.platform = "ios";
  ASSERT_FALSE(vpar->HitAspectRatioFilterRule(options, asp_ratio_info, item));

  asp_ratio_info.w = 5;
  asp_ratio_info.h = 4;
  ASSERT_TRUE(vpar->HitAspectRatioFilterRule(options, asp_ratio_info, item));

  options.channel_id = 10290;
  FilterReason filterno;
  ASSERT_TRUE(vpar->AspectRatioFilter(options, item, &filterno));
  EXPECT_EQ(filterno, kFilterByVideoAspectRatio);

  options.channel_id = 10017;
  ASSERT_FALSE(vpar->AspectRatioFilter(options, item, &filterno));
  EXPECT_EQ(filterno, kNoFiltered);
}

}  // namespace filter
}  // namespace reco

/*
int main(int argc, char* argv[]) { ::testing::InitGoogleTest(&argc, argv);
  base::InitApp(&argc, &argv, "FilterRuleTest");
  return RUN_ALL_TESTS();
} */
