#pragma once

#include "reco/bizc/filter_rule/online/base_rule.h"

namespace reco {
namespace filter {

class RiskMediaRule : public BaseRule {
 public:
  RiskMediaRule() {}

  virtual ~RiskMediaRule() {}

  virtual FilterType GetFilterType() {
    return RiskMediaFilter;
  }

  virtual bool Filter(const Options& options, const ItemInfo& item, reco::filter::FilterReason* filterno);

 protected:
  virtual bool VideoRiskMediaFilter(const Options& options, const ItemInfo& item,
                                    reco::filter::FilterReason* filterno);

  virtual bool ImageTxtRiskMediaFilter(const Options& options, const ItemInfo& item,
                                       reco::filter::FilterReason* filterno);

  virtual bool InnerImageTxtRiskMediaFilter(const uint64 media_sign, const Options& options,
                                    const ItemInfo& item,
                                    reco::filter::FilterReason* filterno);
  virtual bool VideoHasRisk(const Options& options, const ItemInfo& item);
};


//--------------------------------- inline --------------------------------------
inline bool RiskMediaRule::Filter(const Options& options, const ItemInfo& item,
                                  reco::filter::FilterReason* filterno) {
  if (options.risk_media_dict == NULL) {
    *filterno = kNoFiltered;
    return false;
  }

  if (item.item_type == ::reco::kPureVideo) {
    // 视频的逻辑
    if (options.do_video_filter && VideoRiskMediaFilter(options, item, filterno)) {
      return true;
    }
  } else {
    // 文本的逻辑
    if (options.do_news_filter && ImageTxtRiskMediaFilter(options, item, filterno)) {
      return true;
    }
  }

  *filterno = kNoFiltered;
  return false;
}

inline bool RiskMediaRule::VideoHasRisk(const Options& options, const ItemInfo& item) {
  if (!options.do_video_risk_check) {
    return false;
  }
  // 自存储 && 水印
  if (options.news_index->HasVideoStorageInfoByItemId(item.item_id)
      && options.news_index->GetVideoStorageInfoStatusByItemId(item.item_id) == 1) {
    return false;
  }
  return true;
}

inline bool RiskMediaRule::VideoRiskMediaFilter(const Options& options,
                                                const ItemInfo& item,
                                                reco::filter::FilterReason* filterno) {
  // 判断视频风险
  bool video_risk = VideoHasRisk(options, item);

  // 有风险则进一步进行文本逻辑过滤
  if (video_risk && options.do_news_filter && ImageTxtRiskMediaFilter(options, item, filterno)) {
    return true;
  }

  return false;
}

inline bool RiskMediaRule::ImageTxtRiskMediaFilter(const Options& options,
                                                   const ItemInfo& item,
                                                   reco::filter::FilterReason* filterno) {
  // 不过滤来自 UC 的自媒体
  if (item.is_source_wemedia) {
    return false;
  }

  if (InnerImageTxtRiskMediaFilter(item.source_media_sign, options, item, filterno)) {
    return true;
  }

  if (InnerImageTxtRiskMediaFilter(item.orig_source_media_sign, options, item, filterno)) {
    return true;
  }

  return false;
}


inline bool RiskMediaRule::InnerImageTxtRiskMediaFilter(const uint64 media_sign,
                                                        const Options& options,
                                                        const ItemInfo& item,
                                                        reco::filter::FilterReason* filterno) {
  bool orig_media_risk = false;

  auto it = options.risk_media_dict->risk_media_map.find(media_sign);
  if (it == options.risk_media_dict->risk_media_map.end()) {
    return false;
  }

  if (it->second.level == RiskMediaInfo::kLevelNoRisk) {
    if (item.orig_media_risk_type > 0) {
      orig_media_risk = true;
    } else {
      return false;
    }
  }

  if (it->second.level == RiskMediaInfo::kLevelForbiden) {
    *filterno = kFilterByMediaForbiden;
    return true;
  }

  if (it->second.level == RiskMediaInfo::kLevelUnAuth) {
    if (!options.is_inner_app) {
      *filterno = kFilterByMediaNoInnerAPP;
      return true;
    }

    if (item.orig_media_risk_type > 0) {
      orig_media_risk = true;
    }
  }

  if (it->second.level == RiskMediaInfo::kLevelHostile || orig_media_risk) {
    // 过滤没有无线保镖的
    if (!options.is_wsg_enc) {
      *filterno = kFilterByMediaNoWSG;
      return true;
    }

    // 过滤未知城市
    if (options.city.empty()) {
      *filterno = kFilterByMediaUnknowCity;
      return true;
    }

    // 禁止城市
    if (it->second.cities.Find(options.city)) {
      *filterno = kFilterByMediaForbidCity;
      return true;
    }

    // 过滤大城市的非忠诚用户
    if (options.is_main_city && !options.is_loyal) {
      *filterno = kFilterByMediaCityNoLoyal;
      return true;
    }

    // 过滤非忠诚的 ios 用户
    if (options.is_ios && !options.is_loyal) {
      *filterno = kFilterByMediaIOSNoLoyal;
      return true;
    }

    // 只在 uc iflow
    if (!options.is_uc_iflow_app) {
      *filterno = kFilterByMediaUCiflow;
      return true;
    }
  }

  return false;
}
}
}
