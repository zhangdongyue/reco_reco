#pragma once

#include "extend/multi_strings/multi_pattern_matcher.h"

#include "reco/bizc/filter_rule/online/base_rule.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace filter {
class AppTokenRule : public BaseRule {
 public:
  AppTokenRule() {}

  virtual ~AppTokenRule() {}

  virtual FilterType GetFilterType() {
    return AppTokenFilter;
  }

  virtual bool Filter(const Options& options, const ItemInfo& item, reco::filter::FilterReason* filterno);

 protected:
  virtual bool AppRuleFilter(const Options& options, const ItemInfo& item,
                             reco::filter::FilterReason* filterno);
};

//--------------------------------- inline --------------------------------------
inline bool AppTokenRule::Filter(const Options& options, const ItemInfo& item,
                                 reco::filter::FilterReason* filterno) {
  if (options.app_token_idx == -1) {
    *filterno = kNoFiltered;
    return false;
  }

  if (options.do_apprule_filter && AppRuleFilter(options, item, filterno)) {
    return true;
  }

  *filterno = kNoFiltered;
  return false;
}

inline bool AppTokenRule::AppRuleFilter(const Options& options, const ItemInfo& item,
                                        reco::filter::FilterReason* filterno) {
  int bits = options.news_index->GetAppTokenBitsByDocId(item.doc_id);
  if (bits == -1) {
    return false;
  }
  if (options.app_token_idx * bits + 1 < (int)item.app_rule_mask.size()) {
    // 2 bits, 01 直接被过滤
    // 10 要判断是大城市才过滤
    if (item.app_rule_mask.test(options.app_token_idx * bits)) {
      *filterno = kFilterByAppRule;
      if (options.is_debug) {
        LOG(INFO) << "item filtered by AppRuleFilter, bits :" << bits
            << " app_token_idx : " << options.app_token_idx
            << " app_rule_mask : " << item.app_rule_mask
            << " item_id : " << item.item_id
            << " doc_id : " << item.doc_id;
      }
      return true;
    } else if (options.is_main_city && item.app_rule_mask.test(options.app_token_idx * bits + 1)) {
      *filterno = kFilterByAppRuleMainCity;
      if (options.is_debug) {
        LOG(INFO) << "item filtered by AppRuleFilterMainCity, bits :" << bits
            << " app_token_idx : " << options.app_token_idx
            << " app_rule_mask : " << item.app_rule_mask
            << " item_id : " << item.item_id
            << " doc_id : " << item.doc_id;
      }
      return true;
    }
  }

  return false;
}
}
}
