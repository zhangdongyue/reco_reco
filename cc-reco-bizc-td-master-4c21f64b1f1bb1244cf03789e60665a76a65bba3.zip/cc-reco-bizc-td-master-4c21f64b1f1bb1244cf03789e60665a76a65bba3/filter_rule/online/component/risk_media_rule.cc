#include "reco/bizc/filter_rule/online/component/risk_media_rule.h"

namespace reco {
namespace filter {
DEFINE_bool(open_video_risk_media, true, "");
}
}
