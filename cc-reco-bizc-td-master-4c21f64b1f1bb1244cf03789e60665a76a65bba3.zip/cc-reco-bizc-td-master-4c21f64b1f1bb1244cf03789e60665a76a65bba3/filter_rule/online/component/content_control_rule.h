#pragma once

#include <unordered_map>
#include <string>

#include "reco/bizc/filter_rule/online/base_rule.h"
#include "reco/bizc/common/appname_define.h"

namespace reco {
namespace filter {

using reco::filter::FilterReason;

class ContentControlRule : public BaseRule {
  public:
    ContentControlRule() = default;
    virtual ~ContentControlRule() = default;

    virtual FilterType GetFilterType() {
      return ContentControlFilter;
    }

    virtual bool Filter(const Options& options,
                   const ItemInfo& item,
                   FilterReason* filterno);
  private:
    bool IsWhiteItem(const Options& options,
                     const ItemInfo& item,
                     FilterReason* filterno);

    bool IsWhiteSource(const Options& options,
                     const ItemInfo& item,
                     FilterReason* filterno);

    bool IsBlackItem(const Options& options,
                     const ItemInfo& item,
                     FilterReason* filterno);

    bool IsBlackSource(const Options& options,
                     const ItemInfo& item,
                     FilterReason* filterno);
};

inline bool
ContentControlRule::Filter(const Options& options,
                              const ItemInfo& item,
                              FilterReason* filterno) {
  bool ret = false;
  *filterno = kNoFiltered;

  if (!ret && options.do_ugc_white_item_filter) {
    ret = IsWhiteItem(options, item, filterno);
  }

  if (!ret && options.do_ugc_black_item_filter) {
    ret = IsBlackItem(options, item, filterno);
  }

  if (!ret && options.do_ugc_white_source_filter) {
    ret = IsWhiteSource(options, item, filterno);
  }

  if (!ret && options.do_ugc_black_source_filter) {
    ret = IsBlackSource(options, item, filterno);
  }

  return ret;
}

inline bool
ContentControlRule::IsWhiteItem(const Options& options,
            const ItemInfo& item,
            FilterReason* filterno) {
  if (!options.ugc_white_item_dict.get()) {
    return false;
  }

  auto& dict = options.ugc_black_item_dict->dict;
  if (dict.empty()) {
    return false;
  }

  std::string key = base::StringPrintf("%d_%lu", options.app_name, options.channel_id);
  auto iter = dict.find(key);
  if (iter == dict.end()) {
    return false;
  }

  if (iter->second.empty()) { return false; }

  if (iter->second.find(item.item_id) == iter->second.end()) {
    *filterno = kFilterByUgcWhiteItem;
    return true;
  }

  return false;
}

inline bool
ContentControlRule::IsBlackItem(const Options& options,
            const ItemInfo& item,
            FilterReason* filterno) {
  if (!options.ugc_black_item_dict.get()) {
    return false;
  }

  auto& dict = options.ugc_black_item_dict->dict;
  if (dict.empty()) {
    return false;
  }

  std::string key = base::StringPrintf("%d_%lu", options.app_name, options.channel_id);
  auto iter = dict.find(key);
  if (iter == dict.end()) {
    return false;
  }

  if (iter->second.empty()) { return false; }

  if (iter->second.find(item.item_id) != iter->second.end()) {
    *filterno = kFilterByUgcBlackItem;
    return true;
  }

  return false;
}

inline bool
ContentControlRule::IsWhiteSource(const Options& options,
              const ItemInfo& item,
              FilterReason* filterno) {
  if (!options.ugc_white_source_dict.get()) {
    return false;
  }

  auto& dict = options.ugc_white_source_dict->dict;
  if (dict.empty()) {
    return false;
  }

  std::string key = base::StringPrintf("%d_%lu", options.app_name, options.channel_id);
  auto iter = dict.find(key);
  if (iter == dict.end()) {
    return false;
  }

  if (iter->second.empty()) {
    return false;
  }

  std::string source;
  if (options.news_index->GetSourceByItemId(item.item_id, &source)) {
    if (iter->second.find(source) == iter->second.end()) {
      *filterno = kFilterByUgcWhiteSource;
      VLOG(2) << "source:" << source << ", is filtered.";
      return true;
    }
  }

  VLOG(2) << "source:" << source << ", is not be filtered.";

  return false;
}

inline bool
ContentControlRule::IsBlackSource(const Options& options,
              const ItemInfo& item,
              FilterReason* filterno) {
  if (!options.ugc_black_source_dict.get()) {
    return false;
  }

  auto& dict = options.ugc_black_source_dict->dict;
  if (dict.empty()) {
    return false;
  }

  std::string key = base::StringPrintf("%d_%lu", options.app_name, options.channel_id);
  auto iter = dict.find(key);
  if (iter == dict.end()) {
    return false;
  }

  if (iter->second.empty()) { return false; }

  std::string source;
  if (options.news_index->GetSourceByItemId(item.item_id, &source)) {
    if (iter->second.find(source) != iter->second.end()) {
      *filterno = kFilterByUgcBlackSource;
      return true;
    }
  }

  return false;
}

}  // namespace filter
}  // namespace reco

// vim :set ts=2 sts=2 sw=2 tw=110 et
