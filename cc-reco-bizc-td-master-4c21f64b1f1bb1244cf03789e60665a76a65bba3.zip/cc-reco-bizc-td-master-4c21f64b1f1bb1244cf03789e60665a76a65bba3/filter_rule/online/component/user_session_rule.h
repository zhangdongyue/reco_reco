#pragma once
#include <vector>
#include <string>
#include <set>
#include <unordered_set>

#include "reco/bizc/filter_rule/online/base_rule.h"
#include "reco/bizc/common/channel_define.h"

namespace reco {
namespace filter {
class UserSessionRule : public BaseRule {
 public:
  UserSessionRule() {}

  virtual ~UserSessionRule() {}

  virtual FilterType GetFilterType() {
    return SessionFilter;
  }

  virtual bool Filter(const Options& options, const ItemInfo& item, reco::filter::FilterReason* filterno);

 protected:
  virtual bool ShownHistoryFilter(const Options& options, const ItemInfo& item,
                                  reco::filter::FilterReason* filterno);

  virtual bool TitleFilter(const Options& options, const ItemInfo& item,
                           reco::filter::FilterReason* filterno);

  virtual bool QualityDirtyFilter(const Options& options, const ItemInfo& item,
                             reco::filter::FilterReason* filterno);

  virtual bool DisLikeFilter(const Options& options, const ItemInfo& item,
                             reco::filter::FilterReason* filterno);

  virtual bool LocalChannelFilter(const Options& options, const ItemInfo& item,
                                  reco::filter::FilterReason* filterno);

  virtual bool FirstNScreenFilter(const Options& options, const ItemInfo& item,
                                  reco::filter::FilterReason* filterno);

  virtual bool StreamFilter(const Options& options, const ItemInfo& item,
                            reco::filter::FilterReason* filterno);

  virtual bool SourceEnhanceFilter(const Options& options, const ItemInfo& item,
                                   reco::filter::FilterReason* filterno);

  virtual bool VideoPosterFilter(const Options& options, const ItemInfo& item,
                                   reco::filter::FilterReason* filterno);

  virtual bool VideoPlayControlFilter(const Options& options, const ItemInfo& item,
                                   reco::filter::FilterReason* filterno);

  virtual bool YoutuSpecialFilter(const Options& options, const ItemInfo& item,
                                   reco::filter::FilterReason* filterno);

  virtual bool VideoChannelFilter(const Options& options, const ItemInfo& item,
                                   reco::filter::FilterReason* filterno);

  virtual bool ValidAppFilter(const Options& options, const ItemInfo& item,
                                   reco::filter::FilterReason* filterno);
};


//--------------------------------- inline --------------------------------------
inline bool UserSessionRule::Filter(const Options& options, const ItemInfo& item,
                                    reco::filter::FilterReason* filterno) {
  *filterno = kUnknownFiltered;
  const int64 channel_id = options.channel_id;

  if (options.do_valid_in_app_filter && ValidAppFilter(options, item, filterno)) {
    return true;
  }

  // RuleChain filter
  if (options.do_rule_chain_filter && FilterRule::IsFiltered(options.rule_chain, item.source_rule_chain)) {
    *filterno = kFilterByRuleChain;
    return true;
  }

  // 流量过滤
  if (options.do_stream_filter && StreamFilter(options, item, filterno)) {
    return true;
  }

  if (options.do_quality_dirty_filter && QualityDirtyFilter(options, item, filterno)) {
    return true;
  }

  if (options.do_source_enhance_filter && SourceEnhanceFilter(options, item, filterno)) {
    return true;
  }

  if (options.do_video_poster_filter && VideoPosterFilter(options, item, filterno)) {
    return true;
  }

  if (options.do_video_play_control_filter && VideoPlayControlFilter(options, item, filterno)) {
    return true;
  }

  if (options.do_youtu_special_filter && YoutuSpecialFilter(options, item, filterno)) {
    return true;
  }

  // 频道相关过滤
  if (options.do_video_channel_filter && VideoChannelFilter(options, item, filterno)) {
    return true;
  }

  // 非简版频道要做下面的检查
  if (channel_id != ::reco::common::kLeftChannelId) {
    if (options.do_user_show_history_filter && ShownHistoryFilter(options, item, filterno)) {
      return true;
    }

    if (options.do_title_filter && TitleFilter(options, item, filterno)) {
      return true;
    }

    if (options.do_user_dislike_filter && DisLikeFilter(options, item, filterno)) {
      return true;
    }
  }

  if (options.do_local_channel_filter && LocalChannelFilter(options, item, filterno)) {
    return true;
  }

  // 前 n 屏 关键词过滤
  if (options.do_first_n_screen_filter && FirstNScreenFilter(options, item, filterno)) {
    return true;
  }

  *filterno = kNoFiltered;
  return false;
}

inline bool UserSessionRule::TitleFilter(const Options& options, const ItemInfo& item,
                                         reco::filter::FilterReason* filterno) {
  if (options.title_min_len < 0 && options.title_max_len < 0) {
    return false;
  }

  // 只对机器下发的新闻进行过滤
  if (item.strategy_type == ::reco::kManual ||
      item.strategy_type == ::reco::kBanner ||
      options.is_manual_reco) {
    return false;
  }

  const int title_len = options.news_index->GetTitleLengthByDocId(item.doc_id);

  if (options.title_min_len > 0 && title_len < options.title_min_len) {
    *filterno = kFilterByTitleMin;
    return true;
  }

  if (options.title_max_len > 0 && title_len > options.title_max_len) {
    *filterno = kFilterByTitleMax;
    return true;
  }

  return false;
}


inline bool UserSessionRule::ShownHistoryFilter(const Options& options,
                                                const ItemInfo& item,
                                                reco::filter::FilterReason* filterno) {
  // 推荐过的不出
  if (options.shown_set && options.shown_set->find(item.item_id) != options.shown_set->end()) {
    *filterno = kFilterByShownHistory;
    return true;
  }

  // 专题子文已经太多被看过，即不再出
  if (item.item_type != ::reco::kWeMediaCard && item.item_type != ::reco::kSpecial) {
    return false;
  }

  std::unordered_set<uint64> preview_ids;
  if (options.news_index->GetPreviewIdsByItemId(item.item_id, &preview_ids) && !preview_ids.empty()) {
    int mix_num = 0;
    for (auto it = preview_ids.begin(); it != preview_ids.end(); ++it) {
      if (options.shown_set->find(*it) != options.shown_set->end()) {
        ++mix_num;
        if (mix_num >= 4 || (mix_num * 1.0 / preview_ids.size()) >= 0.9) {
          *filterno = kFilterByShownSpecial;
          return true;
        }
      }
    }
  }

  return false;
}

inline bool UserSessionRule::DisLikeFilter(const Options& options, const ItemInfo& item,
                                           reco::filter::FilterReason* filterno) {
  if (options.is_manual_reco) {
    return false;
  }

  if (options.user_feas == NULL) {
    return false;
  }
  // dislike subcategory
  static const std::unordered_set<int64> kFilterDislikeSubCateChannels
      = {::reco::common::kRecoChannelId, ::reco::common::kSportChannelId,
        ::reco::common::kScienceChannelId, ::reco::common::kFinanceChannelId};
  auto const& ref_dislike_subcates = options.user_feas->behavior_fea.dislike_sub_cates;
  int64 cid = options.channel_id;
  if (!ref_dislike_subcates.empty()
      && !item.sub_category.empty()
      && kFilterDislikeSubCateChannels.find(cid) != kFilterDislikeSubCateChannels.end()) {
    auto const iter = ref_dislike_subcates.find(item.sub_category);
    if (iter != ref_dislike_subcates.end() && iter->second >= 0.8) {
      *filterno = kFilterByDislike;
      return true;
    }
  }

  // dislike tag
  auto const& ref_dislike_tags = options.user_feas->behavior_fea.dislike_tags;
  if (!ref_dislike_tags.empty()) {
    ::reco::FeatureVector tag_feas;
    if (options.news_index->GetFeatureVectorByItemId(item.item_id, ::reco::common::kTag, &tag_feas)) {
      std::vector<std::string> tag_flds;
      for (int i = 0; i < tag_feas.feature_size(); ++i) {
        const ::reco::Feature& fea = tag_feas.feature(i);
        tag_flds.clear();
        base::SplitString(fea.literal(), ":", &tag_flds);
        if (tag_flds.size() == 2u
            && ref_dislike_tags.find(tag_flds[1]) != ref_dislike_tags.end()) {
          *filterno = kFilterByDislike;
          return true;
        }
      }
    }
  }

  // dislike semantic tag
  auto const& ref_dislike_semantic_tags = options.user_feas->behavior_fea.dislike_semantic_tags;
  if (!ref_dislike_semantic_tags.empty()) {
    ::reco::FeatureVector tag_feas;
    if (options.news_index->GetFeatureVectorByItemId(item.item_id, ::reco::common::kSemanticTag, &tag_feas)) {
      std::vector<std::string> tag_flds;
      for (int i = 0; i < tag_feas.feature_size(); ++i) {
        const ::reco::Feature& fea = tag_feas.feature(i);
        tag_flds.clear();
        base::SplitString(fea.literal(), ":", &tag_flds);
        if (tag_flds.size() == 2u
            && ref_dislike_semantic_tags.find(tag_flds[1]) != ref_dislike_semantic_tags.end()) {
          *filterno = kFilterByDislike;
          return true;
        }
      }
    }
  }

  // dislike item_type
  auto const& ref_dislike_item_types = options.user_feas->behavior_fea.dislike_item_types;
  if (!ref_dislike_item_types.empty()) {
    if (ref_dislike_item_types.find(item.item_type) != ref_dislike_item_types.end()) {
      return true;
    }
  }

  // dislike source
  auto const& ref_dislike_sources = options.user_feas->behavior_fea.dislike_sources;
  if (cid != ::reco::common::kHumorPicChannelId
      && cid != ::reco::common::kHumorWordTouTiaoChannelId
      && !ref_dislike_sources.empty()) {
    std::string source;
    if (options.news_index->GetShowSourceByDocId(item.doc_id, &source)
        && !source.empty()) {
      if (ref_dislike_sources.find(source) != ref_dislike_sources.end()) {
        *filterno = kFilterByDislike;
        return true;
      }
    } else if (options.news_index->GetOrigSourceByDocId(item.doc_id, &source)
               && !source.empty()) {
      if (ref_dislike_sources.find(source) != ref_dislike_sources.end()) {
        *filterno = kFilterByDislike;
        return true;
      }
    } else if (options.news_index->GetSourceByDocId(item.doc_id, &source)
               && !source.empty()) {
      if (ref_dislike_sources.find(source) != ref_dislike_sources.end()) {
        *filterno = kFilterByDislike;
        return true;
      }
    }
  }

  return false;
}

inline bool UserSessionRule::QualityDirtyFilter(const Options& options, const ItemInfo& item,
                                           reco::filter::FilterReason* filterno) {
  if (options.news_index->IsManualByDocId(item.doc_id)) return false;

  bool is_trival = true;
  ContentAttr content_attr;

  static const std::unordered_set<int64> kAllowDirtyChannelSet
      = {::reco::common::kPictureChannelId, ::reco::common::kGirlChannelId,
        ::reco::common::kAnecdoteChannelId, ::reco::common::kBoudoirChannelId,
        ::reco::common::kSexyBeautyChannelId};
  static const std::unordered_set<std::string> kAllowDirtyCategorySet
      = {::reco::common::kBoudoirCategory, ::reco::common::kGirlCategory};

  if (options.news_index->GetContentAttrByDocId(item.doc_id, &content_attr, &is_trival) && !is_trival) {
    if (content_attr.has_dirty()
        && content_attr.dirty() >= ::reco::ContentAttr::kSuspect) {
      if (item.item_type == ::reco::kPureVideo) {
        if (options.app_name == reco::common::kYouKuIflow ||
            options.app_name == reco::common::kTuDouIflow ||
            options.app_name == reco::common::kTuDouPCIflow) {
          if (options.is_main_city ||
              options.youtu_dirty_channel_dict.get() == NULL ||
              options.youtu_dirty_channel_dict->find(options.channel_id) ==
              options.youtu_dirty_channel_dict->end()) {
            *filterno = kFilterByDirty;
            return true;
          }
        }
      } else if ((kAllowDirtyChannelSet.find(options.channel_id) == kAllowDirtyChannelSet.end()
           && kAllowDirtyCategorySet.find(item.category) == kAllowDirtyCategorySet.end())) {
        *filterno = kFilterByDirty;
        return true;
      }
    }
  }

  return false;
}

inline bool UserSessionRule::LocalChannelFilter(const Options& options, const ItemInfo& item,
                                                reco::filter::FilterReason* filterno) {
  if (options.is_main_city) {
    // 未分类的数据较杂，先扔掉
    if (item.category == "未分类") {
      VLOG(1) << "local channel filter, category reject in main city: " << item.item_id;
      *filterno = kFilterByLocalChannel;
      return true;
    }

    // 天气类的时效性不超过 24 小时
    bool has_weather_tag = false;
    ::reco::FeatureVector fea_vec;
    if (options.news_index->GetFeatureVectorByItemId(item.item_id, ::reco::common::kSemanticTag, &fea_vec)) {
      for (int i = 0; i < fea_vec.feature_size(); ++i) {
        const ::reco::Feature& fea = fea_vec.feature(i);
        auto &tag_with_label = fea.literal();
        std::string tag = tag_with_label;
        if (base::StartsWith(tag_with_label, "label2:", true)) {
          tag = tag_with_label.substr(7);
        }
        if (tag == "天气") {
          has_weather_tag = true;
          break;
        }
      }
    }
    if (has_weather_tag) {
      if (item.time_level < ::reco::kGoodTimeliness) {
        VLOG(1) << "local channel filter, weather timeout: " << item.item_id;
        *filterno = kFilterByLocalChannel;
        return true;
      }
    }
  }
  return false;
}

inline bool UserSessionRule::FirstNScreenFilter(const Options& options, const ItemInfo& item,
                                                reco::filter::FilterReason* filterno) {
  if (item.first_n_hide > 0 &&
      options.today_access_cnt > -1 &&
      item.first_n_hide > options.today_access_cnt) {
    if (options.is_debug) {
      LOG(INFO) << "item filtered by FirstNScreenFilter, first_n_hide : " << item.first_n_hide
          << " today_access_cnt : " << options.today_access_cnt
          << " item_id : " << item.item_id;
    }
    *filterno = kFilterByFirstNScreen;
    return true;
  }

  return false;
}

inline bool UserSessionRule::StreamFilter(const Options& options, const ItemInfo& item,
                                          reco::filter::FilterReason* filterno) {
  if (options.stream_filter == NULL || options.req_bit.none()) {
    return false;
  }

  BitList rule_mask;
  BitList filtered_bit;
  std::string key;
  if (options.stream_filter->IsItemFiltered(options.req_bit, item.item_id,
                                            options.is_debug, &rule_mask, &filtered_bit, &key)) {
    *filterno = kFilterByStreamFilter;
    if (options.is_debug) {
      LOG(INFO) << "item filtered by stream, req_bit : " << options.req_bit
          << " rule_mask : " << rule_mask
          << " filtered_bit : " << filtered_bit
          << " key : " << key
          << " item_id : " << item.item_id;
    }
    return true;
  }
  return false;
}

inline bool UserSessionRule::SourceEnhanceFilter(const Options& options, const ItemInfo& item,
                              reco::filter::FilterReason* filterno) {
  if (options.news_index == NULL ||
      options.black_source == NULL) {
    return false;
  }
  if (options.is_unknown_city ||
      options.is_main_city) {
    if (options.is_ios) {
      std::string source;
      if (options.news_index->GetSourceByItemId(item.item_id, &source)) {
        if (options.black_source->Find(source)) {
          *filterno = kFilterByVideoSourceEnhanced;
          return true;
        }
      }
    }
  }
  return false;
}

inline bool UserSessionRule::VideoPosterFilter(const Options& options, const ItemInfo& item,
                              reco::filter::FilterReason* filterno) {
  if (options.news_index == NULL) {
    return false;
  }
  if (options.news_index->GetVideoBlackEdgeRatioByItemId(item.item_id) > 0.0) {
    *filterno = kFilterByVideoPoster;
    return true;
  }
  std::set<std::string> problems;
  if (options.news_index->GetVideoPosterProblemInfoByItemId(item.item_id, &problems)) {
    *filterno = kFilterByVideoPoster;
    return true;
  }
  return false;
}

inline bool UserSessionRule::VideoPlayControlFilter(const Options& options, const ItemInfo& item,
                              reco::filter::FilterReason* filterno) {
  if (options.news_index == NULL) {
    return false;
  }
  reco::VideoPlayControl video_play_control;
  if (options.news_index->GetVideoPlayControlByItemId(item.item_id, &video_play_control)) {
    for (int i = 0; i < video_play_control.policy_code_size(); ++i) {
      if ((options.pcode & video_play_control.policy_code(i)) == video_play_control.policy_code(i)) {
        *filterno = kFilterByVideoPlayControl;
        return true;
      }
    }
  }
  return false;
}

inline bool UserSessionRule::YoutuSpecialFilter(const Options& options, const ItemInfo& item,
                              reco::filter::FilterReason* filterno) {
  if (options.news_index == NULL) {
    return false;
  }
  if (options.is_youku_open_token) {
    std::string producer;
    if (!options.news_index->GetProducerByDocId(item.doc_id, &producer)
        || (!base::LowerCaseEquals(producer, reco::common::kTuDouProducer) &&
            !base::LowerCaseEquals(producer, "cp_wemedia_youtu") &&
            !base::LowerCaseEquals(producer, "tudou-iflow"))) {
      *filterno = kFilterByYoutuSpecial;
      return true;
    }
  }

  if (options.app_name == reco::common::kTuDouIflow || options.app_name == reco::common::kTuDouPCIflow) {
    if (item.category == "美女" && options.channel_id != reco::common::kHotGirlChannelId) {
      *filterno = kFilterByYoutuSpecial;
      return true;
    }
  }
  return false;
}

inline bool UserSessionRule::VideoChannelFilter(const Options& options, const ItemInfo& item,
                              reco::filter::FilterReason* filterno) {
  if (options.news_index == NULL) {
    return false;
  }

  if (options.news_index->IsManualByDocId(item.doc_id)) {
    return false;
  }

  // uc-iflow 主 feeds 流不下发 ugc 视频 ( 包括 10016 和 推荐频道 ）
  if (options.app_name != reco::common::kUcIflow ||
      (options.channel_id != reco::common::kVideoChannelId
       && options.channel_id != reco::common::kRecoChannelId)) {
    return false;
  }

  std::string category = item.category;
  if (!category.empty() && base::LowerCaseEquals(category, "ugc")) {
    VLOG(1) << base::StringPrintf("in uc-iflow video&reco channel filter ugc item:%lu", item.item_id);
    *filterno = kVideoChannelUgcFiltered;
    return true;
  }
  return false;
}

inline bool UserSessionRule::ValidAppFilter(const Options& options, const ItemInfo& item,
                                            reco::filter::FilterReason* filterno) {
  if (options.news_index == NULL) {
    return false;
  }
  if (!options.news_index->IsValidInAppByItemId(item.item_id, options.app_name)) {
    *filterno = kFilterByValidInApp;
    return true;
  }

  // 运营文章的 app 判断, 原则上运营文章不会走到这个过滤, 但是按 tag 拉取的时候有可能会拉取到运营文章
  if (options.news_index->IsManualByDocId(item.doc_id)) {
    reco::UcBrowserDeliverSetting ucb_setting;
    if (options.news_index->GetUCBSettingByItemId(item.item_id, &ucb_setting)) {
      // appname 的过滤
      if (ucb_setting.appnames_size() > 0) {
        bool hit_apptoken = false;
        for (int i = 0; i < ucb_setting.appnames_size(); ++i) {
          if (ucb_setting.appnames(i) == options.app_token) {
            hit_apptoken = true;
            break;
          }
        }
        if (!hit_apptoken) {
          *filterno = kFilterByValidInApp;
          return true;
        }
      } else if (options.app_name == reco::common::kTuDouPCIflow
                 || options.app_name == reco::common::kTuDouIflow
                 || options.app_name == reco::common::kYouKuIflow) {
        *filterno = kFilterByValidInApp;
        return true;
      }
    }
  }
  return false;
}
}
}
