#pragma once

#include <string>
#include "reco/bizc/common/channel_define.h"
#include "reco/bizc/filter_rule/online/base_rule.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace filter {

// 全局通用型过滤
// item 属性的过滤，只和 channel id 相关
// 所有依赖其它条件的检查，比如 user_info app 地域，都放到 Session 过滤中
class ItemAttrRule : public BaseRule {
 public:
  ItemAttrRule() {}

  virtual ~ItemAttrRule() {}

  virtual FilterType GetFilterType() {
    return ItemFilter;
  }

  virtual bool Filter(const Options& options, const ItemInfo& item,
                      reco::filter::FilterReason* filterno);

 protected:
  virtual bool ItemValidFilter(const Options& options, const ItemInfo& item,
                               reco::filter::FilterReason* filterno);

  virtual bool SensitiveFilter(const Options& options, const ItemInfo& item,
                               reco::filter::FilterReason* filterno);

  virtual bool SimCheckFilter(const Options& options, const ItemInfo& item,
                              reco::filter::FilterReason* filterno);
};


//--------------------------------- inline --------------------------------------
inline bool ItemAttrRule::Filter(const Options& options, const ItemInfo& item,
                                 reco::filter::FilterReason* filterno) {
  // sensitive filter
  if (options.do_sensitive_filter && SensitiveFilter(options, item, filterno)) {
    return true;
  }

  // 非简版频道要做下面的检查
  if (options.channel_id != ::reco::common::kLeftChannelId) {
    // sim check
    if (options.do_sim_check_filter && SimCheckFilter(options, item, filterno)) {
      return true;
    }
  }

  if (options.do_item_valid_filter && ItemValidFilter(options, item, filterno)) {
    return true;
  }

  *filterno = kNoFiltered;
  return false;
}

inline bool ItemAttrRule::ItemValidFilter(const Options& options, const ItemInfo& item,
                                          reco::filter::FilterReason* filterno) {
  // expire time
  if (options.news_index->IsExpiredByDocId(item.doc_id, options.cur_timestamp)) {
    *filterno = kFilterByExpired;
    return true;
  }

  // is valid
  if (!options.news_index->IsValidByDocId(item.doc_id)) {
    *filterno = kFilterByNotValid;
    return true;
  }

  return false;
}

inline bool ItemAttrRule::SimCheckFilter(const Options& options, const ItemInfo& item,
                                         reco::filter::FilterReason* filterno) {
  if (!options.news_index->HasCheckedBySimServer(item.item_id)) {
    *filterno = kFilterBySimCheck;
    return true;
  }

  return false;
}

inline bool ItemAttrRule::SensitiveFilter(const Options& options, const ItemInfo& item,
                                          reco::filter::FilterReason* filterno) {
  if (item.sensitive_type == ::reco::kNoSensitive) return false;
  if (item.sensitive_type == ::reco::kCopyrightSensitive
      || item.sensitive_type == ::reco::kHighPoliticsSensitive
      || item.sensitive_type == ::reco::kPoliticsSensitive) {
    *filterno = kFilterBySensitive;
    return true;
  }

  return false;
}
}
}
