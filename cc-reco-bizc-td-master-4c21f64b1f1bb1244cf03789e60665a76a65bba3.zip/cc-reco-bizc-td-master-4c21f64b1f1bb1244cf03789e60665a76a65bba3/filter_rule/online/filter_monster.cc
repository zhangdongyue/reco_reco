#include "reco/bizc/filter_rule/online/filter_monster.h"

#include <iostream>

#include "reco/bizc/filter_rule/online/define.h"
#include "reco/bizc/filter_rule/online/base_rule.h"
#include "reco/bizc/filter_rule/online/component/app_token_rule.h"
#include "reco/bizc/filter_rule/online/component/item_attr_rule.h"
#include "reco/bizc/filter_rule/online/component/risk_media_rule.h"
#include "reco/bizc/filter_rule/online/component/user_session_rule.h"
#include "reco/bizc/filter_rule/online/component/video_playback_attr_rule.h"
#include "reco/bizc/filter_rule/online/component/content_control_rule.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "serving_base/utility/timer.h"

namespace reco {
namespace filter {
DEFINE_int64_counter(filter, filter_req_cnt, 0, "");
DEFINE_int64_counter(filter, filter_req_cost, 0, "");

FilterMonster::FilterMonster(const uint64 filter_types, const ::reco::NewsIndex* index) {
  LOG(INFO) << "filter rule is:" << std::hex << filter_types;

  news_index_ = index;

  FillRule(filter_types);

  DynamicDictContainer::RegisterAndLoadOnlineDict();
}


FilterMonster::~FilterMonster() {
  for (auto i = 0u; i < rules_.size(); ++i) {
    if (rules_[i]) {
      delete rules_[i];
      rules_[i] = NULL;
    }
  }

  news_index_ = NULL;
}

void FilterMonster::FillRule(const uint64 filter_types) {
  if (filter_types & SessionFilter) {
    rules_.push_back(new UserSessionRule());
  }

  if (filter_types & ItemFilter) {
    rules_.push_back(new ItemAttrRule());
  }

  if (filter_types & RiskMediaFilter) {
    rules_.push_back(new RiskMediaRule());
  }

  if (filter_types & AppTokenFilter) {
    rules_.push_back(new AppTokenRule());
  }

  if (filter_types & VideoPlaybackAttrFilter) {
    rules_.push_back(new VideoPlaybackAttrRule());
  }

  if (filter_types & ContentControlFilter) {
    rules_.push_back(new ContentControlRule());
  }
}

bool FilterMonster::Filter(const ::reco::ItemInfo& item, Options* options,
                           reco::filter::FilterReason* filterno) {
  COUNTERS_filter__filter_req_cnt.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  options->news_index = news_index_;
  *filterno = kUnknownFiltered;

  bool ret = false;
  for (auto i = 0u; i < rules_.size() && !ret; ++i) {
    if (options->filter_subset & rules_[i]->GetFilterType()) {
      VLOG(2) << "run filter:" << rules_[i]->GetFilterType();
      ret = rules_[i]->Filter(*options, item, filterno);
    }
    if (ret == true) {
      VLOG(2) << "filtered by :" << rules_[i]->GetFilterType()
        << "no:" << filterno;
      break;
    }
  }

  COUNTERS_filter__filter_req_cost.Increase(timer.Stop());
  return ret;
}
}
}
