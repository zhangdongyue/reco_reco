#include <vector>
#include <string>
#include <bitset>
#include <fstream>
#include <functional>
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"

#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/hash_function/term.h"
#include "nlp/common/nlp_util.h"

namespace reco {

DECLARE_string(target_server);
DEFINE_bool(use_app_token_item_filter, false, "");

namespace filter {

#define DM_LOAD_DICT(var) reco::dm::DictManagerSingleton::instance().ReloadByDictName(#var)

bool GetAppToken(const YAML::Node& node, int* app_token_idx,
                 std::unordered_map<std::string, int>* app_token_index_map) {
  if (node.Type() != YAML::NodeType::Map || !node.FindValue("app_token")) {
    return false;
  }
  *app_token_idx = static_cast<int>(app_token_index_map->size());
  std::string app_token;
  node["app_token"] >> app_token;
  (*app_token_index_map)[app_token] = *app_token_idx;
  LOG(INFO) << "app token: " << app_token << ", index: " << *app_token_idx;

  return true;
}

bool GetFilterTrie(const YAML::Node& node, const std::string& node_name,
                   reco::common::Trie** trie_dict) {
  if (node.Type() != YAML::NodeType::Map || !node.FindValue(node_name)) {
    return false;
  }

  const YAML::Node& sub_nodes = node[node_name];
  if (sub_nodes.Type() != YAML::NodeType::Sequence) {
    return false;
  }

  *trie_dict = new reco::common::Trie();
  std::vector<std::string> values;
  for (size_t i = 0; i < sub_nodes.size(); ++i) {
    std::string node_str;
    sub_nodes[i] >> node_str;
    (*trie_dict)->Insert(node_str);
    values.emplace_back(node_str);
  }
  LOG(INFO) << "trie node: " << node_name << ", get values: " << base::JoinStrings(values, "|");

  return true;
}

bool GetFilterBool(const YAML::Node& node, const int app_token_idx,
                   const std::string& node_name,
                   std::bitset<AppTokenFilterDict::kMaxAppTokenNum>* dict) {
  if (node.Type() != YAML::NodeType::Map || !node.FindValue(node_name)) {
    return false;
  }
  std::string value;
  node[node_name] >> value;
  if (base::LowerCaseEquals(value, "true")) {
    (*dict)[app_token_idx] = true;
  } else {
    (*dict)[app_token_idx] = false;
  }

  LOG(INFO) << "bool name: " << node_name << ", get bool: " << (*dict)[app_token_idx];
  return true;
}

bool GetFilterMultiPatternMatcher(const YAML::Node& node, const std::string& node_name,
                                  extend::MultiPatternMatcher** pattern_dict) {
  if (node.Type() != YAML::NodeType::Map || !node.FindValue(node_name)) {
    return false;
  }

  const YAML::Node& sub_nodes = node[node_name];
  if (sub_nodes.Type() != YAML::NodeType::Sequence) {
    return false;
  }

  std::vector<std::string> values;
  *pattern_dict = new extend::MultiPatternMatcher();
  for (size_t i = 0; i < sub_nodes.size(); ++i) {
    std::string node_str;
    sub_nodes[i] >> node_str;
    (*pattern_dict)->AddPattern(node_str.c_str());
    values.emplace_back(node_str);
  }

  if (!(*pattern_dict)->Build()) {
    LOG(ERROR) << "pattern build fail, node_name: " << node_name;
    delete (*pattern_dict);
    (*pattern_dict) = NULL;
    return false;
  }

  LOG(INFO) << "multi node: " << node_name << ", get values: " << base::JoinStrings(values, "|");
  return true;
}

bool GetFilterInt(const YAML::Node& node, const std::string& node_name, int* filter_int) {
  if (node.Type() != YAML::NodeType::Map || !node.FindValue(node_name)) {
    return false;
  }
  // 避免 core ,还是先转成 string 保险点....
  std::string value;
  node[node_name] >> value;
  int id = 0;
  if (!base::StringToInt(value, &id)) {
    LOG(ERROR) << "get int error, name: " << node_name << ", value: " << value;
    return false;
  }
  *filter_int = id;

  LOG(INFO) << "int node: " << node_name << ", get int: " << *filter_int;
  return true;
}

bool GetFilterVideoLength(const YAML::Node& node, VideoContentLengthLegal* legal_length) {
  if (node.Type() != YAML::NodeType::Map || !node.FindValue("video_length")) {
    return false;
  }

  const YAML::Node& len_node = node["video_length"];
  if (GetFilterInt(len_node, "common", &legal_length->common_max_len)) {
    legal_length->is_lenght_filter = true;
  }

  if (GetFilterInt(len_node, "wemedia", &legal_length->wemedia_max_len)) {
    legal_length->is_lenght_filter = true;
  }

  LOG(INFO) << "video get bool: " << legal_length->is_lenght_filter << ", common max len: "
            << legal_length->common_max_len << ", wemedia max len: " << legal_length->wemedia_max_len;
  return true;
}

bool GetFilterBitsets(const YAML::Node& node, const std::string& node_name,
                      std::bitset<AppTokenFilterDict::kMaxItemType>** bits) {
  if (node.Type() != YAML::NodeType::Map || !node.FindValue(node_name)) {
    return false;
  }

  const YAML::Node& sub_nodes = node[node_name];
  if (sub_nodes.Type() != YAML::NodeType::Sequence) {
    return false;
  }

  unsigned item_type = 0;
  std::string node_str;
  *bits = new std::bitset<AppTokenFilterDict::kMaxItemType>();
  (*bits)->reset();
  for (size_t i = 0; i < sub_nodes.size(); ++i) {
    sub_nodes[i] >> node_str;
    if (!base::StringToUint(node_str, &item_type)) {
      LOG(ERROR) << "get itemtype field error: " << node_str;
      continue;
    }
    if (item_type >= AppTokenFilterDict::kMaxItemType) {
      LOG(ERROR) << "item_type field [" << item_type << "] beyond max item type ["
                 << AppTokenFilterDict::kMaxItemType << "]";
      continue;
    }
    (*bits)->set(item_type);
  }
  LOG(INFO) << "bit node: " << node_name << ", get bits: " << (*bits)->to_string();

  return true;
}

void LoadAppTokenFilterDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::ifstream fin(path.value().c_str());
  YAML::Parser parser(fin);
  YAML::Node doc;
  try {
    parser.GetNextDocument(doc);
    if (doc.Type() != YAML::NodeType::Sequence) {
      LOG(ERROR) << "Yaml file " << path.value() << " node type is not YAML::NodeType::Sequence";
      *suc = false;
      return;
    }
  } catch(const YAML::ParserException & e) {
    LOG(ERROR) << "Yaml file " << path.value() << " load failed: " << e.what();
    *suc = false;
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  reco::dm::DynamicDict<AppTokenFilterDict>* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<AppTokenFilterDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<AppTokenFilterDict> new_dict(new AppTokenFilterDict());

  // 处理逻辑
  auto& app_token_index_map = new_dict->app_token_index_map;
  auto& category_dict = new_dict->app_token_black_category;

  auto& dirty_dict = new_dict->app_token_filter_dirty;
  auto& title_party = new_dict->app_token_filter_bluffing_title;
  auto& wemedia_dict = new_dict->app_token_filter_wemedia;
  auto& pattern_dict = new_dict->app_token_title_match;
  auto& white_source_dict = new_dict->app_token_white_source;
  auto& min_media_level_dict = new_dict->app_token_min_media_level;
  auto& video_length_dict = new_dict->app_token_video_length;
  auto& need_storage_dict = new_dict->app_token_filter_need_storage;
  auto& main_city_dict = new_dict->app_token_filter_main_city;
  auto& wemedia_youtu_dict = new_dict->app_token_filter_wemedia_youtu;
  auto& black_source_dict = new_dict->app_token_black_source;
  auto& white_item_type_dict = new_dict->app_token_white_item_type;

  int64 count = 0;
  for (int i = 0; i < static_cast<int>(doc.size()); ++i) {
    const YAML::Node& node = doc[i];
    int app_token_idx = -1;
    if (!GetAppToken(node, &app_token_idx, &app_token_index_map)) {
      LOG(ERROR) << "get app token fail, node idx: " << i;
      continue;
    }

    if (app_token_idx >= static_cast<int>(AppTokenFilterDict::kMaxAppTokenNum)) {
      LOG(ERROR) << "too much black app_token in file: " << path.value();
      *suc = false;
      return;
    }

    GetFilterTrie(node, "category", &category_dict[app_token_idx]);
    GetFilterTrie(node, "white_source", &white_source_dict[app_token_idx]);
    GetFilterTrie(node, "black_source", &black_source_dict[app_token_idx]);
    GetFilterBool(node, app_token_idx, "dirty", &dirty_dict);
    GetFilterBool(node, app_token_idx, "title_party", &title_party);
    GetFilterBool(node, app_token_idx, "wemedia", &wemedia_dict);
    GetFilterBool(node, app_token_idx, "need_storage", &need_storage_dict);
    GetFilterBool(node, app_token_idx, "main_city_filter", &main_city_dict);
    GetFilterBool(node, app_token_idx, "wemedia_youtu", &wemedia_youtu_dict);
    GetFilterMultiPatternMatcher(node, "pattern", &pattern_dict[app_token_idx]);
    GetFilterInt(node, "min_media_level", &min_media_level_dict[app_token_idx]);
    GetFilterVideoLength(node, &video_length_dict[app_token_idx]);
    GetFilterBitsets(node, "white_item_type", &white_item_type_dict[app_token_idx]);
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

void LoadRiskMediaDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 从 dict 地址拿到 dict 类型指针
  reco::dm::DynamicDict<RiskMediaDict>* dynamic_dict =
      reinterpret_cast<reco::dm::DynamicDict<RiskMediaDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<RiskMediaDict> new_dict(new RiskMediaDict());

  // 处理逻辑
  int64 count = 0;
  auto& risk_media = new_dict->risk_media_map;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }

    std::vector<std::string> tokens;
    base::SplitString(lines[i], ":", &tokens);
    if (tokens.size() < 2) continue;

    std::vector<std::string> sub_tokens;
    base::SplitString(tokens[1], ",", &sub_tokens);

    uint64 source_media_sign = base::CalcTermSign(tokens[0].c_str(), tokens[0].size());
    unsigned level = 0;
    if (!base::StringToUint(sub_tokens[0], &level)) {
      LOG(ERROR) << path.value() << " level field error: " << lines[i];
      continue;
    }
    risk_media[source_media_sign].level = (RiskMediaInfo::Level)level;
    for (size_t j = 1; j < sub_tokens.size(); ++j) {
      risk_media[source_media_sign].cities.Insert(sub_tokens[j]);
    }
    ++count;
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

bool CompareForbidKeywordGreater(const ForbidKeyword* lhs, const ForbidKeyword* rhs) {
  if (lhs != NULL && rhs != NULL) {
    return lhs->forbid_screen > rhs->forbid_screen;
  } else if (rhs == NULL) {
    return true;
  } else {
    return false;
  }
}

void LoadRestrictStrategyDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  std::ifstream fin(path.value().c_str());
  YAML::Parser parser(fin);
  YAML::Node doc;
  try {
    parser.GetNextDocument(doc);
  } catch(YAML::ParserException & e) {
    LOG(ERROR) << "Yaml file " << path.value() << " load failed: " << e.what();
    *suc = false;
    return;
  }

  reco::dm::DynamicDict<RestrictStrategyDict>* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<RestrictStrategyDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<RestrictStrategyDict> new_dict(new RestrictStrategyDict());

  try {
    if (LoadRestrictStrategyYAMLFile(doc, *(new_dict.get()))) {
      LOG(INFO) << "load yaml file " << path.value() << " success";
    } else {
      LOG(ERROR) << "load yaml file " << path.value() << " fail";
      *suc = false;
      return;
    }
  } catch(YAML::ParserException & e) {
    LOG(ERROR) << "Yaml file " << path.value() << " load failed: " << e.what();
    *suc = false;
    return;
  }
  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = 1;
}

void LoadStreamFilterDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  std::ifstream fin(path.value().c_str());
  YAML::Parser parser(fin);
  YAML::Node doc;
  try {
    parser.GetNextDocument(doc);
  } catch(YAML::ParserException & e) {
    LOG(ERROR) << "Yaml file " << path.value() << " load failed: " << e.what();
    *suc = false;
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  reco::dm::DynamicDict<StreamFilterDict>* dynamic_dict =
      reinterpret_cast<reco::dm::DynamicDict<StreamFilterDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<StreamFilterDict> new_dict(new StreamFilterDict());

  try {
    if (ParseStreamFilterDictYAMLFile(doc, *(new_dict.get()))) {
      LOG(INFO) << "parse yaml file " << path.value() << " success";
    } else {
      LOG(ERROR) << "parse yaml file " << path.value() << " fail";
      *suc = false;
      return;
    }
  } catch(YAML::ParserException & e) {
    LOG(ERROR) << "Yaml file " << path.value() << " load failed: " << e.what();
    *suc = false;
    return;
  }
  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = 1;
}

bool LoadRestrictStrategyYAMLFile(YAML::Node& doc, RestrictStrategyDict& strategy) {
  if (doc.Type() != YAML::NodeType::Map) {
    return false;
  }

  if (!doc.FindValue("strategy_name")) {
    return false;
  }
  doc["strategy_name"] >> strategy.strategy_name;
  LOG(INFO) << "strategy_name : " << strategy.strategy_name;

  if (doc.FindValue("time_type")) {
    int time_type = -1;
    doc["time_type"] >> time_type;
    if (time_type < 0 || time_type >= (int)kTimeUnknown) {
      return false;
    }
    strategy.time_type = (TimeType)time_type;
    LOG(INFO) << "time_type : " << strategy.time_type;
    // strategy.time_type == 1 表示区间限制
    if (strategy.time_type == kTimeSpan) {
      if (doc.FindValue("time_start") && doc.FindValue("time_end")) {
        doc["time_start"] >> strategy.time_start;
        LOG(INFO) << "time_start : " << strategy.time_start;
        doc["time_end"] >> strategy.time_end;
        LOG(INFO) << "time_end : " << strategy.time_end;
        if (strategy.time_start > strategy.time_end) {
          return false;
        }
      } else {
        return false;
      }
    }
  } else {
    return false;
  }

  if (doc.FindValue("forbid_qudao")) {
    const YAML::Node& node = doc["forbid_qudao"];
    for (auto i = 0u; i < node.size(); ++i) {
      std::string value;
      node[i] >> value;
      if (i == 0 && value == "全部") {
        strategy.is_all_qudao = true;
        LOG(INFO) << "forbid_qudao added " << value;
        break;
      }
      if (!value.empty()) {
        strategy.forbid_qudao.insert(value);
        LOG(INFO) << "forbid_qudao added " << value;
      }
    }
  }

  if (doc.FindValue("forbid_platform")) {
    const YAML::Node& node = doc["forbid_platform"];
    for (auto i = 0u; i < node.size(); ++i) {
      std::string value;
      node[i] >> value;
      if (i == 0 && value == "全部") {
        strategy.is_all_platform = true;
        LOG(INFO) << "forbid_platform added " << value;
        break;
      }
      if (!value.empty()) {
        strategy.forbid_platform.insert(value);
        LOG(INFO) << "forbid_platform added " << value;
      }
    }
  }

  if (doc.FindValue("forbid_city")) {
    const YAML::Node& node = doc["forbid_city"];
    for (auto i = 0u; i < node.size(); ++i) {
      std::string value;
      node[i] >> value;
      if (i == 0 && value == "全部") {
        strategy.is_all_city = true;
        LOG(INFO) << "forbid_city added " << value;
        break;
      }
      if (!value.empty()) {
        strategy.forbid_city.insert(value);
        LOG(INFO) << "forbid_city added " << value;
      }
    }
  }

  if (doc.FindValue("rule_name")) {
    doc["rule_name"] >> strategy.rule.rule_name;
    LOG(INFO) << "strategy.rule.rule_name : " << strategy.rule.rule_name;
  } else {
    return false;
  }

  if (doc.FindValue("source_black_list")) {
    const YAML::Node& node = doc["source_black_list"];
    for (auto i = 0u; i < node.size(); ++i) {
      std::string value;
      node[i] >> value;
      if (!value.empty()) {
        strategy.rule.source_blacklist.insert(value);
        LOG(INFO) << "source_black_list added " << value;
      }
    }
  }

  if (doc.FindValue("source_white_list")) {
    const YAML::Node& node = doc["source_white_list"];
    for (auto i = 0u; i < node.size(); ++i) {
      std::string value;
      node[i] >> value;
      if (!value.empty()) {
        strategy.rule.source_whitelist.insert(value);
        LOG(INFO) << "source_white_list added " << value;
      }
    }
  }

  if (doc.FindValue("filter_low_dirty")) {
    int filter_low_dirty = -1;
    doc["filter_low_dirty"] >> filter_low_dirty;
    if (filter_low_dirty == 1) {
      strategy.rule.filter_low_dirty = true;
    } else if (filter_low_dirty == 0) {
      strategy.rule.filter_low_dirty = false;
    } else {
      return false;
    }
    LOG(INFO) << "strategy.rule.filter_low_dirty : " << strategy.rule.filter_low_dirty;
  } else {
    return false;
  }

  if (doc.FindValue("forbid_keywords")) {
    const YAML::Node& node = doc["forbid_keywords"];
    LOG(INFO) << "forbid_keywords size : " << node.size();
    for (auto i = 0u; i < node.size(); ++i) {
      ForbidKeyword* record = new ForbidKeyword();
      bool success = false;
      do {
        if (node[i].FindValue("record_no")) {
          node[i]["record_no"] >> record->record_num;
          LOG(INFO) << "record_no : " << record->record_num;
        } else {
          break;
        }

        if (node[i].FindValue("forbid_screen")) {
          node[i]["forbid_screen"] >> record->forbid_screen;
          LOG(INFO) << "forbid_screen : " << record->forbid_screen;
        } else {
          break;
        }

        if (node[i].FindValue("time_type")) {
          int time_type = -1;
          node[i]["time_type"] >> time_type;
          if (time_type < 0 || time_type >= (int)kTimeUnknown) {
            break;
          }
          record->time_type = (TimeType)time_type;
          LOG(INFO) << "time_type : " << record->time_type;
          // record->time_type == 1 表示区间限制
          if (record->time_type == kTimeSpan) {
            if (node[i].FindValue("time_start") && node[i].FindValue("time_end")) {
              node[i]["time_start"] >> record->time_start;
              LOG(INFO) << "time_start : " << record->time_start;
              node[i]["time_end"] >> record->time_end;
              LOG(INFO) << "time_end : " << record->time_end;
              if (record->time_start > record->time_end) {
                break;
              }
            } else {
              break;
            }
          }
        } else {
          break;
        }

        if (node[i].FindValue("keyword_list")) {
          const YAML::Node& elem = node[i]["keyword_list"];
          if (elem.size() == 0u) {
            break;
          }
          for (auto k = 0u; k < elem.size(); ++k) {
            std::string value;
            elem[k] >> value;
            if (!value.empty()) {
              if (record->pattern == NULL) {
                record->pattern = new extend::MultiPatternMatcher;
              }
              record->pattern->AddPattern(value.c_str());
              LOG(INFO) << "keyword list added " << value;
            }
          }
          if (record->pattern != NULL) {
            record->pattern->Build();
          } else {
            break;
          }
        } else {
          break;
        }

        success = true;
      } while (false);

      if (!success) {
        delete record;
        record = NULL;
      } else {
        strategy.forbid_keywords.push_back(record);
        LOG(INFO) << "record added";
      }
    }
    std::sort(strategy.forbid_keywords.begin(), strategy.forbid_keywords.end(), CompareForbidKeywordGreater);
    LOG(INFO) << "total added record num : " << strategy.forbid_keywords.size();
  }

  strategy.is_valid = true;
  return true;
}

template <typename dict_type>
void LoadMapStrStrSet(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  reco::dm::DynamicDict<dict_type>* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<dict_type>* >(dict_address);

  // 新 dict
  boost::shared_ptr<dict_type> new_dict(new dict_type());

  auto& dict = new_dict->dict;

  int64 count = 0;
  std::string key;
  std::vector<std::string> flds;
  for (size_t i = 0; i < lines.size(); ++i) {
    base::TrimWhitespaces(&lines[i]);
    if (lines[i].empty()) {
      continue;
    }

    if (lines[i][0] == '#') {
      continue;
    }

    if (lines[i].size() > 4) {
      if (lines[i][0] == '-' &&
          lines[i][1] == '-') {
        base::SplitString(lines[i].substr(2), ",", &flds);
        if (flds.size() < 2) { continue; }
        base::TrimWhitespaces(&flds[0]);
        base::TrimWhitespaces(&flds[1]);
        reco::common::AppNames app_name = reco::common::GetAppName(flds[0]);
        key = base::StringPrintf("%d_%s", app_name, flds[1].c_str());
        LOG(INFO) << "load appname_channel key:" << key;
        continue;
      }
    }

    if (key.empty()) { continue; }

    dict[key].insert(lines[i]);
    ++count;
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;

  LOG(INFO) << "load uint64 set dict succ: " << path.ToString()
            << ", num=" << *cnt;
}

template <typename dict_type>
void LoadMapStringUint64Set(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  reco::dm::DynamicDict<dict_type>* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<dict_type>* >(dict_address);

  // 新 dict
  boost::shared_ptr<dict_type> new_dict(new dict_type());

  auto& dict = new_dict->dict;

  int64 count = 0;
  uint64 item = 0;
  std::string key;
  std::vector<std::string> flds;
  for (size_t i = 0; i < lines.size(); ++i) {
    base::TrimWhitespaces(&lines[i]);
    if (lines[i].empty()) {
      continue;
    }

    if (lines[i][0] == '#') {
      continue;
    }

    if (lines[i].size() > 4) {
      if (lines[i][0] == '-' &&
          lines[i][1] == '-') {
        base::SplitString(lines[i].substr(2), ",", &flds);
        if (flds.size() < 2) { continue; }
        base::TrimWhitespaces(&flds[0]);
        base::TrimWhitespaces(&flds[1]);
        reco::common::AppNames app_name = reco::common::GetAppName(flds[0]);
        key = base::StringPrintf("%d_%s", app_name, flds[1].c_str());
        continue;
      }
    }

    if (key.empty()) { continue; }

    if (base::StringToUint64(lines[i], &item)) {
      dict[key].insert(item);
      ++count;
    }
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;

  LOG(INFO) << "load uint64 set dict succ: " << path.ToString()
            << ", num=" << *cnt;
}


template <typename dict_type>
void LoadStringSet(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  reco::dm::DynamicDict<dict_type>* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<dict_type>* >(dict_address);

  // 新 dict
  boost::shared_ptr<dict_type> new_dict(new dict_type());

  auto& dict = new_dict->dict;

  int64 count = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    base::TrimWhitespaces(&lines[i]);
    if (lines[i].empty()) {
      continue;
    }
    dict.insert(lines[i]);
    ++count;
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

void LoadBlackSourceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  LoadStringSet<BlackSourceDict>(path, dict_address, suc, cnt);
}

void LoadWhiteSourceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  LoadStringSet<WhiteSourceDict>(path, dict_address, suc, cnt);
}

// ugc 内容管控
void LoadUgcBlackSourceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  LoadMapStrStrSet<UgcBlackSourceDict>(path, dict_address, suc, cnt);
}

void LoadUgcWhiteSourceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  LoadMapStrStrSet<UgcWhiteSourceDict>(path, dict_address, suc, cnt);
}

void LoadUgcBlackItemDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  LoadMapStringUint64Set<UgcBlackItemDict>(path, dict_address, suc, cnt);
}

void LoadUgcWhiteItemDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  LoadMapStringUint64Set<UgcWhiteItemDict>(path, dict_address, suc, cnt);
}
// ~~

void LoadPoliticsSourceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  LoadStringSet<PoliticsSourceDict>(path, dict_address, suc, cnt);
}

bool ParseStreamFilterDictYAMLFile(YAML::Node& doc, StreamFilterDict& dict) {
  if (doc.Type() != YAML::NodeType::Map && doc.Type() != YAML::NodeType::Sequence) {
    return false;
  }

  if (doc.FindValue("config")) {
    auto& filter_configs = dict.filter_configs;
    const YAML::Node& config_node = doc["config"];
    LOG(INFO) << "config size : " << config_node.size();
    for (auto i = 0u; i < config_node.size(); ++i) {
      if (config_node[i].FindValue("stream_filter_rule")) {
        StreamFilterConfig rule;
        int valid_match_condition_count = 0;
        bool valid_filter_strategy = false;
        const YAML::Node& node = config_node[i]["stream_filter_rule"];
        if (node.FindValue("match_condition")) {
          const YAML::Node& condition_node = node["match_condition"];
          for (auto j = 0u; j < condition_node.size(); ++j) {
            MatchCondition condition;
            if (condition_node[j].FindValue("item_attr")) {
              int item_attr = -1;
              condition_node[j]["item_attr"] >> item_attr;
              if (item_attr >= 0) {
                condition.item_attr = (StreamFilterItemAttr)item_attr;
                LOG(INFO) << "match condition item_attr added : " << item_attr;
              } else {
                LOG(ERROR) << "item_attr invalid";
                continue;
              }
            } else {
              LOG(ERROR) << "no item_attr for match_condition";
              continue;
            }

            if (condition_node[j].FindValue("values")) {
              const YAML::Node& values_node = condition_node[j]["values"];
              if (values_node.size() == 0u) {
                LOG(ERROR) << "values empty";
                continue;
              }
              for (auto k = 0u; k < values_node.size(); ++k) {
                std::string value;
                values_node[k] >> value;
                if (!value.empty()) {
                  condition.match_values.push_back(value);
                  LOG(INFO) << "match condition value added : value : " << value;
                } else {
                  LOG(ERROR) << "value string empty";
                  continue;
                }
              }
              if (condition.match_values.empty()) {
                LOG(ERROR) << "no valid value";
                continue;
              }
            } else {
              LOG(ERROR) << "no values for match_condition";
              continue;
            }
            ++valid_match_condition_count;
            rule.conditions.push_back(condition);
            LOG(INFO) << "condition added";
          }
        } else {
          LOG(ERROR) << "no match_condition for stream_filter_rule";
          continue;
        }

        if (node.FindValue("filter_rule")) {
          const YAML::Node& strategy_node = node["filter_rule"];
          std::vector<OriFilterStrategy> ori_strategy_list;
          for (auto j = 0u; j < strategy_node.size(); ++j) {
            OriFilterStrategy ori_strategy;
            if (strategy_node[j].FindValue("domain")) {
              int domain = -1;
              strategy_node[j]["domain"] >> domain;
              if (domain >= 0) {
                ori_strategy.domain = (StreamFilterDomainAttr)domain;
                LOG(INFO) << "filter rule domain added : " << domain;
              } else {
                LOG(ERROR) << "domain invalid";
                continue;
              }
            } else {
              LOG(ERROR) << "no domain for filter_strategy";
              continue;
            }

            if (strategy_node[j].FindValue("values")) {
              const YAML::Node& values_node = strategy_node[j]["values"];
              if (values_node.size() == 0u) {
                LOG(ERROR) << "values empty";
                continue;
              }
              for (auto k = 0u; k < values_node.size(); ++k) {
                std::string value;
                values_node[k] >> value;
                if (!value.empty()) {
                  ori_strategy.filter_values.push_back(value);
                  LOG(INFO) << "filter rule value added : " << value;
                } else {
                  LOG(ERROR) << "value string empty";
                  continue;
                }
              }
              if (ori_strategy.filter_values.empty()) {
                LOG(ERROR) << "no valid value";
                continue;
              }
            } else {
              LOG(ERROR) << "no values for filter_strategy";
              continue;
            }

            ori_strategy_list.push_back(ori_strategy);
          }

          valid_filter_strategy = ParseOriFilterStrategy(&ori_strategy_list,
                                                         &rule.strategy);
          if (valid_filter_strategy) {
            LOG(INFO) << "valid rule added.";
            filter_configs.push_back(rule);
          }
        } else {
          LOG(ERROR) << "no filter_strategy for stream_filter_rule";
          continue;
        }
      } else {
        LOG(ERROR) << "no stream_filter_rule field";
        continue;
      }
    }
  } else {
    LOG(ERROR) << "no config field";
    return false;
  }
  if (dict.filter_configs.size() > 0) {
    return true;
  }
  return false;
}

bool CompareOriFilterStrategyLess(const OriFilterStrategy& lhs, const OriFilterStrategy& rhs) {
  return lhs.domain < rhs.domain;
}

bool ParseOriFilterStrategy(std::vector<OriFilterStrategy>* ori_strategy_list,
                            FilterStrategy* strategy) {
  if (ori_strategy_list == NULL || ori_strategy_list->size() == 0 || strategy == NULL) {
    return false;
  }
  // 按照 domain 排序,
  // domian 内的 value 按照 string 排序,
  // 保证同样的策略生成的 identify_key 相同
  // format : domain:value,value,value|domain:value,value,value
  std::sort(ori_strategy_list->begin(), ori_strategy_list->end(), CompareOriFilterStrategyLess);
  // construct identify key
  std::string identify_key;
  for (auto i = 0u; i < ori_strategy_list->size(); ++i) {
    std::string tmpstr = ori_strategy_list->at(i).to_string();
    if (!tmpstr.empty()) {
      identify_key += tmpstr;
      if (i < ori_strategy_list->size() - 1) {
        identify_key += "|";
      }
    }
  }
  if (!identify_key.empty()) {
    strategy->key = identify_key;
  }
  BitList bitlist;
  if (FillMaskAndBitLists(ori_strategy_list, strategy, 0, bitlist)) {
    LOG(INFO) << "valid filter_strategy, mask : " << strategy->mask
        << " filter_values num : " << strategy->filter_values.size()
        << " key : " << strategy->key;
    return true;
  }
  return false;
}

bool FillMaskAndBitLists(std::vector<OriFilterStrategy>* ori_strategy_list,
                         FilterStrategy* strategy,
                         size_t idx,
                         BitList bitlist) {
  bool process_mask = false;
  if (strategy->filter_values.size() == 0) {
    process_mask = true;
  }
  auto& ori_strategy = ori_strategy_list->at(idx);
  switch (ori_strategy.domain) {
    case kDomainAttrApp:
      if (process_mask) {
        BitList tmp_mask;
        for (auto i = 0u; i < OriFilterStrategy::AppBitSize; ++i) {
          tmp_mask.set(i);
        }
        tmp_mask <<= OriFilterStrategy::AppOffset;
        strategy->mask = strategy->mask | tmp_mask;
      }
      for (auto i = 0u; i < ori_strategy.filter_values.size(); ++i) {
        auto cur_bitlist = bitlist;
        std::string& value = ori_strategy.filter_values.at(i);
        if (value == "uc浏览器") {
          BitList tmp_value((uint32)kAttrAppValueUC);
          tmp_value <<= OriFilterStrategy::AppOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "uc头条") {
          BitList tmp_value((uint32)KAttrAppValueUCNews);
          tmp_value <<= OriFilterStrategy::AppOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "土豆") {
          BitList tmp_value((uint32)kAttrAppValueTudou);
          tmp_value <<= OriFilterStrategy::AppOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "优酷") {
          BitList tmp_value((uint32)kAttrAppValueYouku);
          tmp_value <<= OriFilterStrategy::AppOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "有才") {
          BitList tmp_value((uint32)kAttrAppValueYoucai);
          tmp_value <<= OriFilterStrategy::AppOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "其他") {
          BitList tmp_value((uint32)kAttrAppValueOther);
          tmp_value <<= OriFilterStrategy::AppOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else {
          LOG(ERROR) << "not valid value for app : " << value;
          return false;
        }
        if (idx == ori_strategy_list->size() - 1) {
          strategy->filter_values.push_back(cur_bitlist);
          LOG(INFO) <<"bitlist added : " << cur_bitlist;
        } else if (idx < ori_strategy_list->size() - 1) {
          if (!FillMaskAndBitLists(ori_strategy_list, strategy, idx + 1, cur_bitlist)) {
            return false;
          }
        }
      }
      break;
    case kDomainAttrSubApp:
      if (process_mask) {
        BitList tmp_mask;
        for (auto i = 0u; i < OriFilterStrategy::SubAppBitSize; ++i) {
          tmp_mask.set(i);
        }
        tmp_mask <<= OriFilterStrategy::SubAppOffset;
        strategy->mask = strategy->mask | tmp_mask;
      }
      for (auto i = 0u; i < ori_strategy.filter_values.size(); ++i) {
        auto cur_bitlist = bitlist;
        std::string& value = ori_strategy.filter_values.at(i);
        if (value == "主要子渠道") {
          BitList tmp_value((uint32)kAttrSubAppValueMain);
          tmp_value <<= OriFilterStrategy::SubAppOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "次要子渠道") {
          BitList tmp_value((uint32)kAttrSubAppValueMinor);
          tmp_value <<= OriFilterStrategy::SubAppOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else {
          LOG(ERROR) << "not valid value for subapp : " << value;
          return false;
        }

        if (idx == ori_strategy_list->size() - 1) {
          strategy->filter_values.push_back(cur_bitlist);
          LOG(INFO) <<"bitlist added : " << cur_bitlist;
        } else if (idx < ori_strategy_list->size() - 1) {
          if (!FillMaskAndBitLists(ori_strategy_list, strategy, idx + 1, cur_bitlist)) {
            return false;
          }
        }
      }
      break;
    case kDomainAttrPlatform:
      if (process_mask) {
        BitList tmp_mask;
        for (auto i = 0u; i < OriFilterStrategy::PlatformBitSize; ++i) {
          tmp_mask.set(i);
        }
        tmp_mask <<= OriFilterStrategy::PlatformOffset;
        strategy->mask = strategy->mask | tmp_mask;
      }
      for (auto i = 0u; i < ori_strategy.filter_values.size(); ++i) {
        auto cur_bitlist = bitlist;
        std::string& value = ori_strategy.filter_values.at(i);

        if (value == "ios") {
          BitList tmp_value((uint32)kAttrPlatformValueIOS);
          tmp_value <<= OriFilterStrategy::PlatformOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "android") {
          BitList tmp_value((uint32)kAttrPlatformValueAndroid);
          tmp_value <<= OriFilterStrategy::PlatformOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "web") {
          BitList tmp_value((uint32)kAttrPlatformValueWeb);
          tmp_value <<= OriFilterStrategy::PlatformOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else {
          LOG(ERROR) << "not valid value for platform : " << value;
          return false;
        }

        if (idx == ori_strategy_list->size() - 1) {
          strategy->filter_values.push_back(cur_bitlist);
          LOG(INFO) <<"bitlist added : " << cur_bitlist;
        } else if (idx < ori_strategy_list->size() - 1) {
          if (!FillMaskAndBitLists(ori_strategy_list, strategy, idx + 1, cur_bitlist)) {
            return false;
          }
        }
      }
      break;
    case kDomainAttrRegion:
      if (process_mask) {
        BitList tmp_mask;
        for (auto i = 0u; i < OriFilterStrategy::RegionBitSize; ++i) {
          tmp_mask.set(i);
        }
        tmp_mask <<= OriFilterStrategy::RegionOffset;
        strategy->mask = strategy->mask | tmp_mask;
      }
      for (auto i = 0u; i < ori_strategy.filter_values.size(); ++i) {
        auto cur_bitlist = bitlist;
        std::string& value = ori_strategy.filter_values.at(i);

        if (value == "北京") {
          BitList tmp_value((uint32)kAttrRegionValueBJ);
          tmp_value <<= OriFilterStrategy::RegionOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "上海") {
          BitList tmp_value((uint32)kAttrRegionValueSH);
          tmp_value <<= OriFilterStrategy::RegionOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "广州") {
          BitList tmp_value((uint32)kAttrRegionValueGZ);
          tmp_value <<= OriFilterStrategy::RegionOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "其他主要城市") {
          BitList tmp_value((uint32)kAttrRegionValueOtherMain);
          tmp_value <<= OriFilterStrategy::RegionOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "其他城市") {
          BitList tmp_value((uint32)kAttrRegionValueOther);
          tmp_value <<= OriFilterStrategy::RegionOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else {
          LOG(ERROR) << "not valid value for region : " << value;
          return false;
        }

        if (idx == ori_strategy_list->size() - 1) {
          strategy->filter_values.push_back(cur_bitlist);
          LOG(INFO) <<"bitlist added : " << cur_bitlist;
        } else if (idx < ori_strategy_list->size() - 1) {
          if (!FillMaskAndBitLists(ori_strategy_list, strategy, idx + 1, cur_bitlist)) {
            return false;
          }
        }
      }
      break;
    case kDomainAttrTimeRange:
      if (process_mask) {
        BitList tmp_mask;
        for (auto i = 0u; i < OriFilterStrategy::TimeRangeBitSize; ++i) {
          tmp_mask.set(i);
        }
        tmp_mask <<= OriFilterStrategy::TimeRangeOffset;
        strategy->mask = strategy->mask | tmp_mask;
      }
      for (auto i = 0u; i < ori_strategy.filter_values.size(); ++i) {
        auto cur_bitlist = bitlist;
        std::string& value = ori_strategy.filter_values.at(i);

        if (value == "监管时段") {
          BitList tmp_value((uint32)kAttrTimeRangeValueControl);
          tmp_value <<= OriFilterStrategy::TimeRangeOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "非监管时段") {
          BitList tmp_value((uint32)kAttrTimeRangeValueNotControl);
          tmp_value <<= OriFilterStrategy::TimeRangeOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else {
          LOG(ERROR) << "not valid value for time range : " << value;
          return false;
        }

        if (idx == ori_strategy_list->size() - 1) {
          strategy->filter_values.push_back(cur_bitlist);
          LOG(INFO) <<"bitlist added : " << cur_bitlist;
        } else if (idx < ori_strategy_list->size() - 1) {
          if (!FillMaskAndBitLists(ori_strategy_list, strategy, idx + 1, cur_bitlist)) {
            return false;
          }
        }
      }
      break;
    case kDomainAttrChannel:
      if (process_mask) {
        BitList tmp_mask;
        for (auto i = 0u; i < OriFilterStrategy::ChannelBitSize; ++i) {
          tmp_mask.set(i);
        }
        tmp_mask <<= OriFilterStrategy::ChannelOffset;
        strategy->mask = strategy->mask | tmp_mask;
      }
      for (auto i = 0u; i < ori_strategy.filter_values.size(); ++i) {
        auto cur_bitlist = bitlist;
        std::string& value = ori_strategy.filter_values.at(i);

        if (value == "推荐频道") {
          BitList tmp_value((uint32)kAttrChannelValueNews);
          tmp_value <<= OriFilterStrategy::ChannelOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "视频频道") {
          BitList tmp_value((uint32)kAttrChannelValueVideo);
          tmp_value <<= OriFilterStrategy::ChannelOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "其他频道") {
          BitList tmp_value((uint32)kAttrChannelValueOther);
          tmp_value <<= OriFilterStrategy::ChannelOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else {
          LOG(ERROR) << "not valid value for channel : " << value;
          return false;
        }

        if (idx == ori_strategy_list->size() - 1) {
          strategy->filter_values.push_back(cur_bitlist);
          LOG(INFO) <<"bitlist added : " << cur_bitlist;
        } else if (idx < ori_strategy_list->size() - 1) {
          if (!FillMaskAndBitLists(ori_strategy_list, strategy, idx + 1, cur_bitlist)) {
            return false;
          }
        }
      }
      break;
    case kDomainAttrUserNew:
      if (process_mask) {
        BitList tmp_mask;
        for (auto i = 0u; i < OriFilterStrategy::UserNewBitSize; ++i) {
          tmp_mask.set(i);
        }
        tmp_mask <<= OriFilterStrategy::UserNewOffset;
        strategy->mask = strategy->mask | tmp_mask;
      }
      for (auto i = 0u; i < ori_strategy.filter_values.size(); ++i) {
        auto cur_bitlist = bitlist;
        std::string& value = ori_strategy.filter_values.at(i);

        if (value == "新用户") {
          BitList tmp_value((uint32)kAttrUserNewValueY);
          tmp_value <<= OriFilterStrategy::UserNewOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "老用户") {
          BitList tmp_value((uint32)kAttrUserNewValueN);
          tmp_value <<= OriFilterStrategy::UserNewOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else {
          LOG(ERROR) << "not valid value for usernew : " << value;
          return false;
        }

        if (idx == ori_strategy_list->size() - 1) {
          strategy->filter_values.push_back(cur_bitlist);
          LOG(INFO) <<"bitlist added : " << cur_bitlist;
        } else if (idx < ori_strategy_list->size() - 1) {
          if (!FillMaskAndBitLists(ori_strategy_list, strategy, idx + 1, cur_bitlist)) {
            return false;
          }
        }
      }
      break;
    case kDomainAttrUserDirty:
      if (process_mask) {
        BitList tmp_mask;
        for (auto i = 0u; i < OriFilterStrategy::UserDirtyBitSize; ++i) {
          tmp_mask.set(i);
        }
        tmp_mask <<= OriFilterStrategy::UserDirtyOffset;
        strategy->mask = strategy->mask | tmp_mask;
      }
      for (auto i = 0u; i < ori_strategy.filter_values.size(); ++i) {
        auto cur_bitlist = bitlist;
        std::string& value = ori_strategy.filter_values.at(i);

        if (value == "非色情用户") {
          BitList tmp_value((uint32)kAttrUserDirtyValueN);
          tmp_value <<= OriFilterStrategy::UserDirtyOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "色情用户") {
          BitList tmp_value((uint32)kAttrUserDirtyValueY);
          tmp_value <<= OriFilterStrategy::UserDirtyOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else {
          LOG(ERROR) << "not valid value for userdirty : " << value;
          return false;
        }

        if (idx == ori_strategy_list->size() - 1) {
          strategy->filter_values.push_back(cur_bitlist);
          LOG(INFO) <<"bitlist added : " << cur_bitlist;
        } else if (idx < ori_strategy_list->size() - 1) {
          if (!FillMaskAndBitLists(ori_strategy_list, strategy, idx + 1, cur_bitlist)) {
            return false;
          }
        }
      }
      break;
    case kDomainAttrUserTitleParty:
      if (process_mask) {
        BitList tmp_mask;
        for (auto i = 0u; i < OriFilterStrategy::UserTitlePartyBitSize; ++i) {
          tmp_mask.set(i);
        }
        tmp_mask <<= OriFilterStrategy::UserTitlePartyOffset;
        strategy->mask = strategy->mask | tmp_mask;
      }
      for (auto i = 0u; i < ori_strategy.filter_values.size(); ++i) {
        auto cur_bitlist = bitlist;
        std::string& value = ori_strategy.filter_values.at(i);

        if (value == "非标题党用户") {
          BitList tmp_value((uint32)kAttrUserTitlePartyN);
          tmp_value <<= OriFilterStrategy::UserTitlePartyOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else if (value == "标题党用户") {
          BitList tmp_value((uint32)kAttrUserTitlePartyY);
          tmp_value <<= OriFilterStrategy::UserTitlePartyOffset;
          cur_bitlist = cur_bitlist | tmp_value;
        } else {
          LOG(ERROR) << "not valid value for usertitleparty : " << value;
          return false;
        }

        if (idx == ori_strategy_list->size() - 1) {
          strategy->filter_values.push_back(cur_bitlist);
          LOG(INFO) <<"bitlist added : " << cur_bitlist;
        } else if (idx < ori_strategy_list->size() - 1) {
          if (!FillMaskAndBitLists(ori_strategy_list, strategy, idx + 1, cur_bitlist)) {
            return false;
          }
        }
      }
      break;
    default:
      LOG(ERROR) << "not valid domain enum";
      break;
  }
  return true;
}

void LoadCategoryMediaLevelMap(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(WARNING) << "Read cate media level dict fail, "
            << path.ToString();
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  reco::dm::DynamicDict<CateMediaLevelMap>* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<CateMediaLevelMap>* >(dict_address);

  // 新 dict
  boost::shared_ptr<CateMediaLevelMap> new_dict(new CateMediaLevelMap());

  auto& cate_media_level_map = new_dict->cate_media_level_map;
  // 处理逻辑
  int64 count = 0;

  int val = 0;
  reco::MediaLevel level;
  std::vector<std::string> flds;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    flds.clear();
    base::SplitString(lines[idx], "\t", &flds);
    if (flds.size() < 3u || !base::StringToInt(flds[2], &val)) {
      LOG(ERROR) << "parse field fail, " << lines[idx];
      continue;
    }

    // key = cate "\t" media
    const std::string& key = flds[0] + "\t" + flds[1];
    // val
    level = reco::MediaLevel(val);
    // insert
    auto iter = cate_media_level_map.find(key);
    if (iter != cate_media_level_map.end()) {
      if (level > iter->second) {
        iter->second = level;
      }
    } else {
      cate_media_level_map.insert(std::make_pair(key, level));
    }
    ++count;
  }
  LOG(INFO) << "succ to load cate_media level, total record: "
            << cate_media_level_map.size();

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

void LoadAppTokenBitIndex(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(WARNING) << "Read app token bit index dict fail, " << path.ToString();
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  reco::dm::DynamicDict<AppTokenBitIndex>* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<AppTokenBitIndex>* >(dict_address);

  // 新 dict
  boost::shared_ptr<AppTokenBitIndex> new_dict(new AppTokenBitIndex());

  auto& app_token_bit_index = new_dict->app_token_bit_index;
  // 处理逻辑
  int64 count = 0;

  int val = 0;
  std::vector<std::string> flds;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    flds.clear();
    base::SplitString(lines[idx], ":", &flds);
    if (flds.size() != 2 || !base::StringToInt(flds[1], &val)) {
      LOG(ERROR) << "parse field fail: " << lines[idx];
      continue;
    }

    base::TrimWhitespaces(&flds[0]);
    app_token_bit_index.insert(std::make_pair(flds[0], val));

    ++count;
  }
  LOG(INFO) << "succ to load app token bit index, total record: "
                << app_token_bit_index.size();

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

bool GetFirstNScreenInfo(const YAML::Node& node, int* forbid_screen, std::vector<std::string>* keywords) {
  std::string forbid;
  if (!node.FindValue("forbid_screen")) {
    LOG(ERROR) << "get forbid_screen fail";
    return false;
  }
  node["forbid_screen"] >> forbid;
  if (!base::StringToInt(forbid, forbid_screen)) {
    LOG(ERROR) << "get forbid_screen error, yaml screen: " << forbid;
    return false;
  }
  if (!node.FindValue("forbid_keywords")) {
    LOG(ERROR) << "get forbid_keywords fail";
    return false;
  }
  const YAML::Node& keyword_nodes = node["forbid_keywords"];
  for (size_t i = 0; i < keyword_nodes.size(); ++i) {
    std::string keyword;
    keyword_nodes[i] >> keyword;
    base::TrimWhitespaces(&keyword);
    keywords->emplace_back(keyword);
  }

  return true;
}

void SetFirstNScreenInfo(const int forbid_screen, const std::vector<std::string>& keywords,
                         FirstNScreenInfo* forbid_info) {
  forbid_info->forbid_screen = forbid_screen;
  for (size_t i = 0; i < keywords.size(); ++i) {
    forbid_info->forbid_pattern->AddPattern(keywords[i].c_str());
  }

  LOG(INFO) << "get screen: " << forbid_screen << ", keywords: "
            << base::JoinStrings(keywords, "|");
  return;
}

void SortForbidInfo(std::unordered_map<int, FirstNScreenInfo>* forbid_map,
                    std::vector<FirstNScreenInfo>* forbid_dict) {
  for (std::unordered_map<int, FirstNScreenInfo>::iterator it = forbid_map->begin();
       it != forbid_map->end(); ++it) {
    it->second.forbid_pattern->Build();
    forbid_dict->emplace_back(it->second);
  }
  std::sort(forbid_dict->begin(), forbid_dict->end(), std::greater<FirstNScreenInfo>());

  return;
}

void LoadFirstNScreenFilterDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  reco::dm::DynamicDict<FirstNScreenFilterDict>* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<FirstNScreenFilterDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<FirstNScreenFilterDict> new_dict(new FirstNScreenFilterDict());

  std::ifstream fin(path.value().c_str());
  YAML::Parser parser(fin);
  YAML::Node doc;
  try {
    parser.GetNextDocument(doc);
  } catch(YAML::ParserException & e) {
    LOG(ERROR) << "Yaml file " << path.value() << " load failed: " << e.what();
    *suc = false;
    return;
  }

  if (doc.Type() != YAML::NodeType::Sequence) {
    LOG(ERROR) << "doc type is not Sequence, type: " << doc.Type();
    *suc = false;
    return;
  }

  std::unordered_map<int, FirstNScreenInfo> forbid_map;
  for (size_t i = 0; i < doc.size(); ++i) {
    int forbid_screen = 0;
    std::vector<std::string> keywords;
    if (!GetFirstNScreenInfo(doc[i], &forbid_screen, &keywords)) {
      continue;
    }

    SetFirstNScreenInfo(forbid_screen, keywords, &forbid_map[forbid_screen]);
  }

  SortForbidInfo(&forbid_map, &(new_dict->forbid_dict));

  // swap dict
  *cnt = static_cast<int>(new_dict->forbid_dict.size());
  dynamic_dict->Swap(new_dict);
  *suc = true;
}

static void operator >> (const YAML::Node& node, AspectRatioInfo& aspect_ratio_info) {
#define ARI_ASSGIN_VALUE(key) \
  if (node.FindValue(#key)) { \
    node[#key] >> aspect_ratio_info.key;\
  }

  ARI_ASSGIN_VALUE(platform);
  ARI_ASSGIN_VALUE(mode);
  ARI_ASSGIN_VALUE(w);
  ARI_ASSGIN_VALUE(h);

  // version
  if (node.FindValue("ve_s")) {
    std::string version;
    node["ve_s"] >> version;
    ::base::Version ve(version);
    if (ve.IsValid()) aspect_ratio_info.ve_s = ve;
  }

  if (node.FindValue("ve_e")) {
    std::string version;
    node["ve_e"] >> version;
    ::base::Version ve(version);
    if (ve.IsValid()) aspect_ratio_info.ve_e = ve;
  }

#undef ARI_ASSGIN_VALUE
}

static bool SetAspectRatioInfoMap(const YAML::Node& node,
    std::unordered_map<int64, VecAspectRatioInfo>* const aspect_ratio_info_map) {
  CHECK(aspect_ratio_info_map != NULL);

  if (!node.FindValue("channel_ids")) {
    LOG(ERROR) << "get channel_ids failed.";
    return false;
  }

  if (!node.FindValue("aspect_ratio")) {
    LOG(ERROR) << "get aspect_ratio failed.";
    return false;
  }

  ::reco::common::AppNames app_name = ::reco::common::kGeneralApp;
  if (node.FindValue("app_name")) {
    std::string app_name_str;
    node["app_name"] >> app_name_str;
    app_name = ::reco::common::GetAppName(app_name_str);
  }

  const YAML::Node& aspect_ratio_nodes = node["aspect_ratio"];
  std::vector<AspectRatioInfo> aspect_ratio_infos;
  for (size_t i = 0; i < aspect_ratio_nodes.size(); ++i) {
    AspectRatioInfo aspect_ratio_info;
    aspect_ratio_nodes[i] >> aspect_ratio_info;
    aspect_ratio_info.app_name = app_name;
    aspect_ratio_infos.emplace_back(aspect_ratio_info);
  }

  const YAML::Node& channel_id_nodes = node["channel_ids"];
  for (size_t i = 0; i < channel_id_nodes.size(); ++i) {
    uint64 channel_id = 0;
    channel_id_nodes[i] >> channel_id;
    (*aspect_ratio_info_map)[channel_id] = aspect_ratio_infos;
  }

  return true;
}

void LoadVideoPlaybackAttrFilterDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  reco::dm::DynamicDict<VideoPlaybackAttrFilterDict>* dynamic_dict =
    reinterpret_cast<reco::dm::DynamicDict<VideoPlaybackAttrFilterDict>* >(dict_address);

  boost::shared_ptr<VideoPlaybackAttrFilterDict> new_dict(new VideoPlaybackAttrFilterDict());

  std::ifstream fin(path.value().c_str());
  YAML::Parser parser(fin);
  YAML::Node doc;
  try {
    parser.GetNextDocument(doc);
  } catch(const YAML::ParserException& e) {
    LOG(ERROR) << "Yaml file " << path.value() << " load failed: " << e.what();
    *suc = false;
    return;
  }

  if (!doc.FindValue("aspect_ratio_filter")) {
    LOG(ERROR) << "get aspect_ratio_filter failed : " << path.value();
    *suc = false;
    return;
  }

  const YAML::Node& aspect_ratio_filter_nodes = doc["aspect_ratio_filter"];
  for (size_t i = 0; i < aspect_ratio_filter_nodes.size(); ++i) {
    if (!SetAspectRatioInfoMap(aspect_ratio_filter_nodes[i], &(new_dict->aspect_ratio_info_map))) {
      *suc = false;
      return;
    }
  }

  dynamic_dict->Swap(new_dict);
  *suc = true;
  return;
}

void LoadSourcePlatformDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }

  reco::dm::DynamicDict<SourcePlatformDict>* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<SourcePlatformDict>* >(dict_address);
  // 新 dict
  boost::shared_ptr<SourcePlatformDict> new_dict(new SourcePlatformDict());
  auto& source_platforms = new_dict->source_platforms;

  int count = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    std::vector<std::string> tokens;
    base::SplitString(lines[i], ":", &tokens);
    if (tokens.empty()) {
      continue;
    }

    base::TrimWhitespaces(&tokens[0]);
    if (tokens[0].empty() || tokens[0][0] == '#') {
      continue;
    }

    if (tokens.size() != 2) {
      LOG(INFO) << "line is err, line: " << lines[i];
      continue;
    }

    std::vector<std::string> values;
    base::SplitString(tokens[1], ",", &values);
    std::vector<reco::RestrictPulishPlatform>& platform_list = source_platforms[tokens[0]];
    for (size_t j = 0; j < values.size(); ++j) {
      int platform = -1;
      base::TrimWhitespaces(&values[j]);
      if (!base::StringToInt(values[j], &platform) || platform < 0
          || platform > reco::kUnvalidPlatform) {
        LOG(ERROR) << "source [" << tokens[0] << "] get Platform [" << values[j] << "] error";
        continue;
      }
      platform_list.emplace_back(static_cast<reco::RestrictPulishPlatform>(platform));
    }
    LOG(INFO) << "source [" << tokens[0] << "], platform [" << base::JoinStrings(values, "|") << "]";
    ++count;
  }

  // swap dict
  *cnt = count;
  dynamic_dict->Swap(new_dict);
  *suc = true;
}

uint32 OriFilterStrategy::UserTitlePartyOffset = 0u;
uint32 OriFilterStrategy::UserTitlePartyBitSize = 2u;
uint32 OriFilterStrategy::UserDirtyOffset = OriFilterStrategy::UserTitlePartyOffset +
    OriFilterStrategy::UserTitlePartyBitSize;
uint32 OriFilterStrategy::UserDirtyBitSize = 2u;
uint32 OriFilterStrategy::UserNewOffset = OriFilterStrategy::UserDirtyOffset +
    OriFilterStrategy::UserDirtyBitSize;
uint32 OriFilterStrategy::UserNewBitSize = 2u;
uint32 OriFilterStrategy::ChannelOffset = OriFilterStrategy::UserNewOffset +
    OriFilterStrategy::UserNewBitSize;
uint32 OriFilterStrategy::ChannelBitSize = 2u;
uint32 OriFilterStrategy::TimeRangeOffset = OriFilterStrategy::ChannelOffset +
    OriFilterStrategy::ChannelBitSize;
uint32 OriFilterStrategy::TimeRangeBitSize = 2u;
uint32 OriFilterStrategy::RegionOffset = OriFilterStrategy::TimeRangeOffset +
    OriFilterStrategy::TimeRangeBitSize;
uint32 OriFilterStrategy::RegionBitSize = 3u;
uint32 OriFilterStrategy::PlatformOffset = OriFilterStrategy::RegionOffset +
    OriFilterStrategy::RegionBitSize;
uint32 OriFilterStrategy::PlatformBitSize = 2u;
uint32 OriFilterStrategy::SubAppOffset = OriFilterStrategy::PlatformOffset +
    OriFilterStrategy::PlatformBitSize;
uint32 OriFilterStrategy::SubAppBitSize = 2u;
uint32 OriFilterStrategy::AppOffset = OriFilterStrategy::SubAppOffset +
    OriFilterStrategy::SubAppBitSize;
uint32 OriFilterStrategy::AppBitSize = 3u;

const char* DynamicDictContainer::kAppTokenFilterFile = "app_token_blacklist.yaml";
const char* DynamicDictContainer::kAppTokenBitIndexFile = "app_token_bit_index.txt";
const char* DynamicDictContainer::kRiskMediaFile = "source_media.txt";
const char* DynamicDictContainer::kRestrictStrategyFile = "restrict_strategy.yaml";
const char* DynamicDictContainer::kBlackSourceFile = "black_source_file.txt";
const char* DynamicDictContainer::kWhiteSourceFile = "white_source_file.txt";
const char* DynamicDictContainer::kUgcBlackSourceFile = "ugc_black_source_file.txt";
const char* DynamicDictContainer::kUgcWhiteSourceFile = "ugc_white_source_file.txt";
const char* DynamicDictContainer::kUgcBlackItemFile = "ugc_black_item_file.txt";
const char* DynamicDictContainer::kUgcWhiteItemFile = "ugc_white_item_file.txt";
const char* DynamicDictContainer::kPoliticsSourceFile = "politics_source_file.txt";
const char* DynamicDictContainer::kStreamFilterFile = "stream_filter.yaml";
const char* DynamicDictContainer::kCategoryMediaLevelFile  = "media_level.txt";
const char* DynamicDictContainer::kFirstNScreenFilterFile = "first_nscreen_filter.yaml";
const char* DynamicDictContainer::kVideoPlaybackAttrFilterFile = "video_playback_attr_filter.yaml";
const char* DynamicDictContainer::kSourcePlatformFile = "source_platform.txt";

void DynamicDictContainer::RegisterAndLoadOfflineDict() {
  DM_REGISTER_CUSTOMER_DICT(AppTokenFilterDict,
                            reco::filter::DynamicDictContainer::kAppTokenFilterFile,
                            LoadAppTokenFilterDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kAppTokenFilterFile);

  DM_REGISTER_CUSTOMER_DICT(AppTokenBitIndex,
                            reco::filter::DynamicDictContainer::kAppTokenBitIndexFile,
                            LoadAppTokenBitIndex);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kAppTokenBitIndexFile);

//  DM_REGISTER_CUSTOMER_DICT(RestrictStrategyDict,
//                            reco::filter::DynamicDictContainer::kRestrictStrategyFile,
//                            LoadRestrictStrategyDict);
//  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kRestrictStrategyFile);

  DM_REGISTER_CUSTOMER_DICT(BlackSourceDict,
                            reco::filter::DynamicDictContainer::kBlackSourceFile,
                            LoadBlackSourceDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kBlackSourceFile);

  DM_REGISTER_CUSTOMER_DICT(WhiteSourceDict,
                            reco::filter::DynamicDictContainer::kWhiteSourceFile,
                            LoadWhiteSourceDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kWhiteSourceFile);

  DM_REGISTER_CUSTOMER_DICT(PoliticsSourceDict,
                            reco::filter::DynamicDictContainer::kPoliticsSourceFile,
                            LoadPoliticsSourceDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kPoliticsSourceFile);

  DM_REGISTER_CUSTOMER_DICT(CateMediaLevelMap,
                            reco::filter::DynamicDictContainer::kCategoryMediaLevelFile,
                            LoadCategoryMediaLevelMap);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kCategoryMediaLevelFile);

  DM_REGISTER_CUSTOMER_DICT(FirstNScreenFilterDict,
                            reco::filter::DynamicDictContainer::kFirstNScreenFilterFile,
                            LoadFirstNScreenFilterDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kFirstNScreenFilterFile);

  DM_REGISTER_CUSTOMER_DICT(SourcePlatformDict,
                            reco::filter::DynamicDictContainer::kSourcePlatformFile,
                            LoadSourcePlatformDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kSourcePlatformFile);
}

void DynamicDictContainer::RegisterAndLoadOnlineDict() {
  DM_REGISTER_CUSTOMER_DICT(StreamFilterDict,
                            reco::filter::DynamicDictContainer::kStreamFilterFile,
                            LoadStreamFilterDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kStreamFilterFile);

  DM_REGISTER_CUSTOMER_DICT(RiskMediaDict,
                            reco::filter::DynamicDictContainer::kRiskMediaFile,
                            LoadRiskMediaDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kRiskMediaFile);

  DM_REGISTER_CUSTOMER_DICT(AppTokenBitIndex,
                            reco::filter::DynamicDictContainer::kAppTokenBitIndexFile,
                            LoadAppTokenBitIndex);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kAppTokenBitIndexFile);

  if (FLAGS_target_server == "video_server") {
    DM_REGISTER_CUSTOMER_DICT(VideoPlaybackAttrFilterDict,
                              reco::filter::DynamicDictContainer::kVideoPlaybackAttrFilterFile,
                              LoadVideoPlaybackAttrFilterDict);
    DM_LOAD_DICT(reco::filter::DynamicDictContainer::kVideoPlaybackAttrFilterFile);
  }

  // ugc 内容管控
  DM_REGISTER_CUSTOMER_DICT(UgcBlackSourceDict,
                            reco::filter::DynamicDictContainer::kUgcBlackSourceFile,
                            LoadUgcBlackSourceDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kUgcBlackSourceFile);

  /*
  DM_REGISTER_CUSTOMER_DICT(UgcWhiteSourceDict,
                            reco::filter::DynamicDictContainer::kUgcWhiteSourceFile,
                            LoadUgcWhiteSourceDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kUgcWhiteSourceFile);
  */

  DM_REGISTER_CUSTOMER_DICT(UgcBlackItemDict,
                            reco::filter::DynamicDictContainer::kUgcBlackItemFile,
                            LoadUgcBlackItemDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::UgcBlackItemFile_);

  DM_REGISTER_CUSTOMER_DICT(UgcWhiteItemDict,
                            reco::filter::DynamicDictContainer::kUgcWhiteItemFile,
                            LoadUgcWhiteItemDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kUgcWhiteItemFile_);
}

void DynamicDictContainer::RegisterAndLoadAppTokenFilterDict() {
  DM_REGISTER_CUSTOMER_DICT(AppTokenBitIndex,
                            reco::filter::DynamicDictContainer::kAppTokenBitIndexFile,
                            LoadAppTokenBitIndex);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kAppTokenBitIndexFile);

  DM_REGISTER_CUSTOMER_DICT(AppTokenFilterDict,
                            reco::filter::DynamicDictContainer::kAppTokenFilterFile,
                            LoadAppTokenFilterDict);
  DM_LOAD_DICT(reco::filter::DynamicDictContainer::kAppTokenFilterFile);
}
}  // namespace filter
}  // namespace reco
