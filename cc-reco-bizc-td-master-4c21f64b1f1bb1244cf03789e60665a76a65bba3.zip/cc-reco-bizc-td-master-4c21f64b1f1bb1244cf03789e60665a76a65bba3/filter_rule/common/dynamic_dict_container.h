#pragma once
#include <bitset>
#include <unordered_map>
#include <string>
#include <vector>
#include <algorithm>

#include "extend/multi_strings/multi_pattern_matcher.h"

#include "reco/base/dict_manager/dict_manager.h"
#include "reco/bizc/common/trie.h"
#include "reco/bizc/common/appname_define.h"
#include "base/strings/string_printf.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/container/dense_hash_set.h"
#include "base/container/dense_hash_map.h"
#include "base/utility/version.h"
#include "third_party/yaml-cpp/include/yaml-cpp/yaml.h"

namespace reco {
namespace filter {
/*********************************************************************************************************/
struct RiskMediaInfo {
  enum Level {
    kLevelNoRisk = 0,
    kLevelUnAuth,
    kLevelHostile,
    kLevelForbiden
  };

  Level level;
  reco::common::Trie cities;
};

struct RiskMediaDict {
  std::unordered_map<uint64_t, RiskMediaInfo> risk_media_map;
};

void LoadRiskMediaDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

/*********************************************************************************************************/

struct VideoContentLengthLegal {
  bool is_lenght_filter;
  int32 common_max_len;
  int32 wemedia_max_len;

  VideoContentLengthLegal() : is_lenght_filter(false), common_max_len(-1), wemedia_max_len(-1) {}
};

struct AppTokenFilterDict {
  static const unsigned kMaxItemType = reco::kNone + 1;
  static const size_t kMaxAppTokenNum = 2048;

  std::unordered_map<std::string, int> app_token_index_map;
  std::vector<reco::common::Trie*> app_token_black_category;
  std::bitset<kMaxAppTokenNum> app_token_filter_dirty;
  std::bitset<kMaxAppTokenNum> app_token_filter_bluffing_title;
  std::bitset<kMaxAppTokenNum> app_token_filter_wemedia;
  std::vector<extend::MultiPatternMatcher*> app_token_title_match;
  std::vector<reco::common::Trie*> app_token_white_source;
  // 自媒体权威度阈值(MediaLevel), ">="有效
  // 默认是 0，最低级别，表示不过滤
  std::vector<int> app_token_min_media_level;
  // 自媒体黑名单
  std::vector<reco::common::Trie*> app_token_black_source;
  // 视频时长限制
  std::vector<VideoContentLengthLegal> app_token_video_length;
  // UC 渠道过滤没有自存储的视频
  std::bitset<kMaxAppTokenNum> app_token_filter_need_storage;
  // 一线城市过滤策略
  std::bitset<kMaxAppTokenNum> app_token_filter_main_city;
  // 优土自媒体只在 uc 和优土下发
  std::bitset<kMaxAppTokenNum> app_token_filter_wemedia_youtu;
  std::vector<std::bitset<kMaxItemType>* > app_token_white_item_type;

  AppTokenFilterDict() {
    app_token_black_category.resize(kMaxAppTokenNum, NULL);
    app_token_title_match.resize(kMaxAppTokenNum, NULL);
    app_token_white_source.resize(kMaxAppTokenNum, NULL);
    app_token_min_media_level.resize(kMaxAppTokenNum, 0);
    app_token_black_source.resize(kMaxAppTokenNum, NULL);
    app_token_video_length.resize(kMaxAppTokenNum);
    app_token_white_item_type.resize(kMaxAppTokenNum, NULL);
  }

  ~AppTokenFilterDict() {
    for (size_t i = 0; i < app_token_title_match.size(); ++i) {
      delete app_token_title_match.at(i);
    }
    for (size_t i = 0; i < app_token_black_category.size(); ++i) {
      delete app_token_black_category[i];
    }
    for (size_t i = 0; i < app_token_white_source.size(); ++i) {
      delete app_token_white_source[i];
    }
    for (size_t i = 0; i < app_token_black_source.size(); ++i) {
      delete app_token_black_source[i];
    }
    for (size_t i = 0; i < app_token_white_item_type.size(); ++i) {
      if (app_token_white_item_type[i] != NULL) {
        delete app_token_white_item_type[i];
      }
    }
  }

  int GetAppTokenIdx(const std::string& app_token) const {
    auto iter = app_token_index_map.find(app_token);
    if (iter == app_token_index_map.end()) {
      return -1;
    } else {
      return iter->second;
    }
  }
};

bool GetAppToken(const YAML::Node& node, int* app_token_idx,
                 std::unordered_map<std::string, int>* app_token_index_map);
bool GetFilterTrie(const YAML::Node& node, const std::string& node_name,
                   reco::common::Trie** trie_dict);
bool GetFilterBool(const YAML::Node& node, const int app_token_idx,
                   const std::string& node_name,
                   std::bitset<AppTokenFilterDict::kMaxAppTokenNum>* dict);
bool GetFilterMultiPatternMatcher(const YAML::Node& node, const std::string& node_name,
                                  extend::MultiPatternMatcher** pattern_dict);
bool GetFilterInt(const YAML::Node& node, const std::string& node_name, int* filter_int);
bool GetFilterVideoLength(const YAML::Node& node, VideoContentLengthLegal* legal_length);
void LoadAppTokenFilterDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

/*********************************************************************************************************/

// restrict strategy dict
enum TimeType {
  kTimeForever = 0,
  kTimeSpan,
  kTimeUnknown
};

struct RestrictRule {
 public:
  RestrictRule() :
          rule_name(""),
          filter_low_dirty(true) {
    source_blacklist.set_empty_key("");
    source_whitelist.set_empty_key("");
    source_politics_whitelist.set_empty_key("");
  }
 public:
  std::string rule_name;
  base::dense_hash_set<std::string> source_blacklist;
  base::dense_hash_set<std::string> source_whitelist;
  base::dense_hash_set<std::string> source_politics_whitelist;
  bool filter_low_dirty;
};

struct ForbidKeyword {
 public:
  ForbidKeyword() :
          record_num(-1),
          forbid_screen(0),
          pattern(NULL),
          time_type(kTimeUnknown),
          time_start(-1),
          time_end(-1) {}
  ~ForbidKeyword() {
    if (pattern != NULL) {
      delete pattern;
      pattern = NULL;
    }
  }
 public:
  int record_num;
  int forbid_screen;
  extend::MultiPatternMatcher* pattern;
  TimeType time_type;
  int64 time_start;
  int64 time_end;
};

bool CompareForbidKeywordGreater(const ForbidKeyword* lhs, const ForbidKeyword* rhs);

struct RestrictStrategyDict {
 public:
  RestrictStrategyDict() :
          is_valid(false),
          is_all_qudao(false),
          is_all_platform(false),
          is_all_city(false),
          strategy_name(""),
          time_type(kTimeUnknown),
          time_start(-1),
          time_end(-1) {
    forbid_qudao.set_empty_key("");
    forbid_platform.set_empty_key("");
    forbid_city.set_empty_key("");
  }
  ~RestrictStrategyDict() {
    for (auto i = 0u; i < forbid_keywords.size(); ++i) {
      delete forbid_keywords.at(i);
    }
  }
 public:
  bool CheckNeedApplyRestrictStrategy(std::string qudao, std::string city,
                                      bool is_ios, bool is_android) const {
    if (!is_valid) {
      LOG(ERROR) << "not valid restrict strategy, please check and revise dict";
      return false;
    }

    // 判断是否是限制时间范围内
    if (time_type == kTimeSpan) {
      base::Time current_time = base::Time::Now();
      int64 timestamp = (int64)(current_time.ToDoubleT());
      if (timestamp < time_start || timestamp > time_end) {
        LOG(ERROR) << "restrict strategy out of time range, please check and revise dict";
        return false;
      }
    }

    // 未知渠道或者城市, 按照严格的管控进行
    if (qudao.empty() || city.empty()) {
      return true;
    }
    // 只要有一个全部, 那么就过滤
    if (is_all_qudao || is_all_platform || is_all_city) {
      return true;
    } else {
      // 判断渠道是否命中
      if (forbid_qudao.size() > 0 &&
          forbid_qudao.find(qudao) != forbid_qudao.end()) {
        return true;
      }

      // 判断 platform 是否命中
      if (is_ios &&
          forbid_platform.size() > 0 &&
          forbid_platform.find("ios") != forbid_platform.end()) {
        return true;
      }

      if (is_android &&
          forbid_platform.size() > 0 &&
          forbid_platform.find("android") != forbid_platform.end()) {
        return true;
      }

      // 判断城市是否命中
      if (forbid_city.size() > 0 &&
          forbid_city.find(city) != forbid_city.end()) {
        return true;
      }
    }

    return false;
  }
 public:
  bool is_valid;
  bool is_all_qudao;
  bool is_all_platform;
  bool is_all_city;
  std::string strategy_name;
  base::dense_hash_set<std::string> forbid_qudao;
  base::dense_hash_set<std::string> forbid_platform;
  base::dense_hash_set<std::string> forbid_city;
  TimeType time_type;
  int64 time_start;
  int64 time_end;
  RestrictRule rule;
  std::vector<ForbidKeyword*> forbid_keywords;
};

void LoadRestrictStrategyDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
bool LoadRestrictStrategyYAMLFile(YAML::Node& doc, RestrictStrategyDict& strategy);

struct BlackSourceDict {
  base::dense_hash_set<std::string> dict;
  BlackSourceDict() {
    dict.set_empty_key("");
  }
};
void LoadBlackSourceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct WhiteSourceDict {
  base::dense_hash_set<std::string> dict;
  WhiteSourceDict() {
    dict.set_empty_key("");
  }
};
void LoadWhiteSourceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

// ugc 内容管控
struct UgcWhiteSourceDict {
  std::map<std::string, std::unordered_set<std::string> > dict;
};
void LoadUgcWhiteSourceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct UgcBlackSourceDict {
  std::map<std::string, std::unordered_set<std::string> > dict;
};
void LoadUgcBlackSourceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct UgcWhiteItemDict {
  std::map<std::string, std::unordered_set<uint64> > dict;
};
void LoadUgcWhiteItemDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct UgcBlackItemDict {
  std::map<std::string, std::unordered_set<uint64> > dict;
};
void LoadUgcBlackItemDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
//

struct PoliticsSourceDict {
  base::dense_hash_set<std::string> dict;
  PoliticsSourceDict() {
    dict.set_empty_key("");
  }
};
void LoadPoliticsSourceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

/*********************************************************************************************************/

typedef std::bitset<20> BitList;

enum StreamFilterDomainAttr {
  kDomainAttrApp = 0,
  kDomainAttrSubApp = 1,
  kDomainAttrPlatform = 2,
  kDomainAttrRegion = 3,
  kDomainAttrTimeRange = 4,
  kDomainAttrChannel =5,
  kDomainAttrUserNew = 6,
  kDomainAttrUserDirty = 7,
  kDomainAttrUserTitleParty = 8
};

enum AttrAppValue {
  kAttrAppValueUC = 1,
  KAttrAppValueUCNews = 2,
  kAttrAppValueTudou = 3,
  kAttrAppValueYouku = 4,
  kAttrAppValueYoucai = 5,
  kAttrAppValueOther = 7
};

enum AttrSubAppValue {
  kAttrSubAppValueMain = 1,
  kAttrSubAppValueMinor = 2
};

enum AttrPlatformValue {
  kAttrPlatformValueIOS = 1,
  kAttrPlatformValueAndroid = 2,
  kAttrPlatformValueWeb = 3
};

enum AttrRegionValue {
  kAttrRegionValueBJ = 1,
  kAttrRegionValueSH = 2,
  kAttrRegionValueGZ = 3,
  kAttrRegionValueOtherMain = 4,
  kAttrRegionValueOther = 7
};

enum AttrTimeRangeValue {
  kAttrTimeRangeValueControl = 1,
  kAttrTimeRangeValueNotControl = 2
};

enum AttrChannelValue {
  kAttrChannelValueNews = 1,
  kAttrChannelValueVideo = 2,
  kAttrChannelValueOther = 3
};

enum AttrUserNewValue {
  kAttrUserNewValueY = 1,
  kAttrUserNewValueN = 2
};

enum AttrUserDirtyValue {
  kAttrUserDirtyValueN = 1,
  kAttrUserDirtyValueY = 2
};

enum AttrUserTitleParty {
  kAttrUserTitlePartyN = 1,
  kAttrUserTitlePartyY = 2
};

enum StreamFilterItemAttr {
  kItemAttrNeg = 0,
  kItemAttrDirty = 1,
  kItemAttrTitleParty = 2,
  kItemAttrPolitics = 3,
  kItemAttrLowQuality = 4,
  kItemAttrFirstCate = 5,
  kItemAttrFirstCateNot = 6,
  kItemAttrSecondCate = 7,
  kItemAttrSecondCateNot = 8,
  kItemAttrTag = 9,
  kItemAttrTagNot = 10,
  kItemAttrSemanticTag = 11,
  kItemAttrSemanticTagNot = 12,
  kItemAttrItemType = 13,
  kItemAttrItemTypeNot = 14,
  kItemAttrWeMedia = 15,
  kItemAttrMediaLevel = 16,
  kItemAttrReviewed = 17,
  kItemAttrUcVideoStorage = 18
};

// 通过 MatchCondition 筛选出 item
struct MatchCondition {
  StreamFilterItemAttr item_attr;
  std::vector<std::string> match_values;
};

struct OriFilterStrategy {
  StreamFilterDomainAttr domain;
  std::vector<std::string> filter_values;
  static uint32 UserTitlePartyOffset;
  static uint32 UserTitlePartyBitSize;
  static uint32 UserDirtyOffset;
  static uint32 UserDirtyBitSize;
  static uint32 UserNewOffset;
  static uint32 UserNewBitSize;
  static uint32 ChannelOffset;
  static uint32 ChannelBitSize;
  static uint32 TimeRangeOffset;
  static uint32 TimeRangeBitSize;
  static uint32 RegionOffset;
  static uint32 RegionBitSize;
  static uint32 PlatformOffset;
  static uint32 PlatformBitSize;
  static uint32 SubAppOffset;
  static uint32 SubAppBitSize;
  static uint32 AppOffset;
  static uint32 AppBitSize;
  std::string to_string() {
    std::sort(filter_values.begin(), filter_values.end());
    std::string strategy_str;
    strategy_str += base::StringPrintf("%u:", (uint32)domain);
    for (auto i = 0u; i < filter_values.size(); ++i) {
      strategy_str += filter_values.at(i);
      if (i < filter_values.size() - 1) {
        strategy_str += ",";
      }
    }
    return strategy_str;
  }
};

bool CompareOriFilterStrategyLess(const OriFilterStrategy& lhs, const OriFilterStrategy& rhs);

// 过滤策略, bitset list, 对 req bitset 的掩码, 和策略的描述
struct FilterStrategy {
  std::vector<BitList> filter_values;
  BitList mask;
  std::string key;
};

struct StreamFilterConfig {
  std::vector<MatchCondition> conditions;
  FilterStrategy strategy;
};

struct StreamFilterDict {
  std::vector<StreamFilterConfig> filter_configs;
};

void LoadStreamFilterDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
bool ParseStreamFilterDictYAMLFile(YAML::Node& doc, StreamFilterDict& dict);
bool ParseOriFilterStrategy(std::vector<OriFilterStrategy>* ori_strategy_list,
                            FilterStrategy* strategy);
bool FillMaskAndBitLists(std::vector<OriFilterStrategy>* ori_strategy_list,
                         FilterStrategy* strategy,
                         size_t idx,
                         BitList bitlist);

struct CateMediaLevelMap {
  base::dense_hash_map<std::string, reco::MediaLevel> cate_media_level_map;
  CateMediaLevelMap() {
    cate_media_level_map.set_empty_key("");
  }
};
void LoadCategoryMediaLevelMap(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct AppTokenBitIndex {
  std::unordered_map<std::string, int> app_token_bit_index;
};
void LoadAppTokenBitIndex(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct FirstNScreenInfo {
  int forbid_screen;
  std::shared_ptr<extend::MultiPatternMatcher> forbid_pattern;

  FirstNScreenInfo() : forbid_screen(-1) {
    forbid_pattern = std::make_shared<extend::MultiPatternMatcher>();
  }
  bool operator>(const FirstNScreenInfo& rhs) const {
    return forbid_screen > rhs.forbid_screen;
  }
};

struct FirstNScreenFilterDict {
  std::vector<FirstNScreenInfo> forbid_dict;
};
void LoadFirstNScreenFilterDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct AspectRatioInfo {
  AspectRatioInfo() : app_name(reco::common::kGeneralApp), w(0), h(0) {}

  ::reco::common::AppNames app_name;  // see bizc/common/appname_define.h
  std::string platform;  // ios or andriod
  ::base::Version ve_s;  // os version range : start version
  ::base::Version ve_e;  // os version range : end version
  int mode;  // video show mode :0 "landscape" 1 "portrait" 2 "fix"(such as 16x9)
  int w;  // aspect ratio of width
  int h;  // aspect ratio of height
};
typedef std::vector<AspectRatioInfo> VecAspectRatioInfo;
struct VideoPlaybackAttrFilterDict {
  std::unordered_map<int64, VecAspectRatioInfo> aspect_ratio_info_map;
};
void LoadVideoPlaybackAttrFilterDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

/*********************************************************************************************************/

struct SourcePlatformDict {
  std::unordered_map<std::string, std::vector<reco::RestrictPulishPlatform> > source_platforms;
};
void LoadSourcePlatformDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

/*********************************************************************************************************/

class DynamicDictContainer {
 public:
  DynamicDictContainer() {}
  ~DynamicDictContainer() {}
  static void RegisterAndLoadOfflineDict();
  static void RegisterAndLoadOnlineDict();
  static void RegisterAndLoadAppTokenFilterDict();
  static const char* kAppTokenFilterFile;
  static const char* kAppTokenBitIndexFile;
  static const char* kRiskMediaFile;
  static const char* kRestrictStrategyFile;
  static const char* kBlackSourceFile;
  static const char* kWhiteSourceFile;

  static const char* kUgcBlackSourceFile;
  static const char* kUgcWhiteSourceFile;
  static const char* kUgcBlackItemFile;
  static const char* kUgcWhiteItemFile;

  static const char* kPoliticsSourceFile;
  static const char* kStreamFilterFile;
  static const char* kCategoryMediaLevelFile;
  static const char* kFirstNScreenFilterFile;
  static const char* kVideoPlaybackAttrFilterFile;
  static const char* kSourcePlatformFile;
};
}  // namespace filter
}  // namespace reco
