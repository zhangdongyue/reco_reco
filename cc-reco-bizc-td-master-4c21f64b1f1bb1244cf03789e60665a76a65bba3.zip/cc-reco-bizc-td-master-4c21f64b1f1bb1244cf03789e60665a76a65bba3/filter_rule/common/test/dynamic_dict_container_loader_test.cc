//
// Created by dongyue.zdy on 2017/10/24.
//

#include <memory>
#include <fstream>
#include <iostream>
#include "base/testing/gtest.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"

namespace reco {

namespace dm {
DECLARE_string(dict_manager_root_dir);
}  // namespace dm

namespace filter {

class DynamicDictContainerTest : public testing::Test {
 protected:
  DynamicDictContainerTest() {
  }

  virtual ~DynamicDictContainerTest() { }

  virtual void SetUp() {
    FLAGS_v = 1;
  }

  virtual void TearDown() {
  }

 private:
};

struct FrVersion : public ::base::Version {
  public:
    FrVersion() : ::base::Version() {}
    FrVersion(const std::string version) : ::base::Version(version) {}

};

// std::ostream& operator << (std::ostream& ost, const FrVersion& fv) {
std::ostream& operator<<(std::ostream& ost, const ::base::Version& fv) {
  std::vector<uint16>::const_iterator iter;
  if (fv.IsValid()) {
    for (iter = fv.components_.begin(); iter != fv.components_.end(); ++iter) {
      ost << *iter << ".";
    }
  }
  return ost;
}

bool operator<=(const ::base::Version& lhs, const ::base::Version& rhs) {
  return lhs.CompareTo(rhs) <= 0;
}

bool operator>=(const ::base::Version& lhs, const ::base::Version& rhs) {
  return lhs.CompareTo(rhs) >= 0;
}

using reco::filter::VideoPlaybackAttrFilterDict;
TEST_F(DynamicDictContainerTest, LoadVideoPlaybackAttrFilterDict) {
  // --dict_manager_root_dir=
  // "/data3/dongyue.zdy/sm-xss/cc-reco-bizc/filter_rule/common/test/test_data"
  std::string vpaf_yaml = "video_playback_attr_filter.yaml";

  DM_REGISTER_CUSTOMER_DICT(VideoPlaybackAttrFilterDict,
                            vpaf_yaml,
                            LoadVideoPlaybackAttrFilterDict);

  // DM_LOAD_DICT(vpaf_yaml);
  reco::dm::DictManagerSingleton::instance().ReloadByDictName("vpaf_yaml");

  boost::shared_ptr<const VideoPlaybackAttrFilterDict> vpaf_ptr
    = DM_GET_DICT(VideoPlaybackAttrFilterDict, vpaf_yaml);

  ASSERT_TRUE(vpaf_ptr);

  ::base::Version lver("1.2.3");
  ::base::Version hver("1.2.3");
  ASSERT_TRUE(lver >= hver);

  ::base::Version lver1("2.2.0");
  ::base::Version hver1("1.2.3");
  ASSERT_TRUE(lver1 >= hver1);
  ASSERT_FALSE(lver1 <= hver1);

  ::base::Version lver2("2");
  ::base::Version hver2("1.2.3");
  ASSERT_TRUE(lver2 >= hver2);

  std::unordered_map<int64, VecAspectRatioInfo>::const_iterator uvari_map_iter;
  const std::unordered_map<int64, VecAspectRatioInfo>& uvari_map = vpaf_ptr->aspect_ratio_info_map;
#define PRINT_ELEM(elem) \
  std::cout << " - " << std::setw(10) << #elem << " : " << ari_vec_iter->elem << std::endl;
  for (uvari_map_iter = uvari_map.begin(); uvari_map_iter != uvari_map.end(); ++uvari_map_iter) {
    std::cout << "--------------------------------------------" << std::endl;
    std::cout << "channel_id :" << uvari_map_iter->first << std::endl;
    const VecAspectRatioInfo& ari_vec = uvari_map_iter->second;
    VecAspectRatioInfo::const_iterator ari_vec_iter;
    for (ari_vec_iter = ari_vec.begin(); ari_vec_iter != ari_vec.end(); ++ari_vec_iter) {
      PRINT_ELEM(platform);
      PRINT_ELEM(app_name);
      PRINT_ELEM(ve_s);
      PRINT_ELEM(ve_e);
      PRINT_ELEM(mode);
      PRINT_ELEM(w);
      PRINT_ELEM(h);
    }
  }
#undef PRINT_ELEM
}

}  // namespace filter
}  // namespace reco

/*
int main(int argc, char* argv[]) {
  ::testing::InitGoogleTest(&argc, argv);
  base::InitApp(&argc, &argv, "DynamicDictContainerTest");
  return RUN_ALL_TESTS();  
} */ 

