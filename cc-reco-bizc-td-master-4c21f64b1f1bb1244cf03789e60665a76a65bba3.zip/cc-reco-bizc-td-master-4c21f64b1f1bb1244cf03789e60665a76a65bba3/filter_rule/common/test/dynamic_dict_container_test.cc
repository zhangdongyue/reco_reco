//
// Created by allen.fw on 2017/9/21.
//

#include <memory>
#include <fstream>
#include "base/testing/gtest.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "base/common/logging.h"

namespace reco {
namespace filter {

class DynamicDictTest : public testing::Test {
 protected:
  DynamicDictTest() {
  }

  virtual ~DynamicDictTest() { }

  virtual void SetUp() {
    FLAGS_v = 1;
  }

  virtual void TearDown() {
  }

 private:
};

const std::string YAME_PATH_PREFIX = "reco/bizc/filter_rule/common/test/test_data/";
bool GetMockYamlNode(const std::string& path, YAML::Node& doc) {
  std::ifstream fin(YAME_PATH_PREFIX + path);
  YAML::Parser parser(fin);
  try {
    parser.GetNextDocument(doc);
  } catch(YAML::ParserException& e) {
    LOG(ERROR) << "ParserException file " << path << " load failed: " << e.what();
    return false;
  }

  return true;
}

const int NO_CARE_IDX = 0;
// GetAppToken
TEST_F(DynamicDictTest, no_app_token_should_get_app_token_return_false) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("empty.yaml", doc));

  int app_token_idx = -1;
  ASSERT_FALSE(GetAppToken(doc, &app_token_idx, NULL));
}

TEST_F(DynamicDictTest, get_app_token_should_get_app_token_return_true) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  int app_token_idx = -1;
  std::unordered_map<std::string, int> app_token_index_map;
  ASSERT_TRUE(GetAppToken(doc, &app_token_idx, &app_token_index_map));

  ASSERT_EQ(app_token_idx, 0);
  ASSERT_EQ(app_token_index_map["no_care"], 0);
}
// end GetAppToken

// GetFilterInt
TEST_F(DynamicDictTest, not_exist_int_should_get_int_return_false) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  ASSERT_FALSE(GetFilterInt(doc, "not_exist_int", NULL));
}

TEST_F(DynamicDictTest, value_is_not_int_should_get_int_return_false) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  ASSERT_FALSE(GetFilterInt(doc, "value_is_not_int", NULL));
}

TEST_F(DynamicDictTest, test_get_int_return_true) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  int int_value = 0;
  ASSERT_TRUE(GetFilterInt(doc, "int_value", &int_value));
  ASSERT_EQ(int_value, 1);
}
// end GetFilterInt

// GetFilterTrie
TEST_F(DynamicDictTest, not_exist_trie_should_get_trie_return_false) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  ASSERT_FALSE(GetFilterTrie(doc, "not_exist_trie", NULL));
}

TEST_F(DynamicDictTest, not_sequence_trie_should_get_trie_return_false) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  reco::common::Trie* trie = NULL;
  ASSERT_FALSE(GetFilterTrie(doc, "not_sequence_trie", &trie));
}

const std::string NO_CARE_VALUE = "no_care_value";
const std::string NO_CARE_OTHER_VALUE = "no_care_other_value";
TEST_F(DynamicDictTest, test_get_trie_find_correct) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  reco::common::Trie* trie = NULL;
  ASSERT_TRUE(GetFilterTrie(doc, "trie", &trie));

  ASSERT_TRUE(trie->Find(NO_CARE_VALUE));
  ASSERT_TRUE(trie->Find(NO_CARE_VALUE, "no_care_two"));
  ASSERT_FALSE(trie->Find(NO_CARE_OTHER_VALUE));
}
// end GetFilterTrie

// GetFilterBool
TEST_F(DynamicDictTest, not_exist_bool_should_get_bool_return_false) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  ASSERT_FALSE(GetFilterBool(doc, NO_CARE_IDX, "not_exist_bool", NULL));
}

TEST_F(DynamicDictTest, set_false_should_get_bool_return_true) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  std::bitset<AppTokenFilterDict::kMaxAppTokenNum> dict;
  ASSERT_TRUE(GetFilterBool(doc, NO_CARE_IDX, "false_bool", &dict));
  ASSERT_FALSE(dict.test(NO_CARE_IDX));
}

TEST_F(DynamicDictTest, set_true_should_get_bool_return_false) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  std::bitset<AppTokenFilterDict::kMaxAppTokenNum> dict;
  ASSERT_TRUE(GetFilterBool(doc, NO_CARE_IDX, "true_bool", &dict));
  ASSERT_TRUE(dict.test(NO_CARE_IDX));
}
// end GetFilterBool

// GetFilterMultiPatternMatcher
TEST_F(DynamicDictTest, not_exist_multi_match_should_get_multi_match_return_false) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  ASSERT_FALSE(GetFilterMultiPatternMatcher(doc, "not_exist_multi_match", NULL));
}

TEST_F(DynamicDictTest, not_sequence_multi_match_should_get_multi_match_return_false) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  ASSERT_FALSE(GetFilterMultiPatternMatcher(doc, "not_sequence_multi_match", NULL));
}

TEST_F(DynamicDictTest, test_get_multi_match_return_false) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  extend::MultiPatternMatcher* pattern_dict = NULL;
  ASSERT_TRUE(GetFilterMultiPatternMatcher(doc, "multi_match", &pattern_dict));
  extend::MatchResult result;
  ASSERT_TRUE(pattern_dict->Match(NO_CARE_VALUE.c_str(), NO_CARE_VALUE.size(), &result));
  ASSERT_FALSE(pattern_dict->Match(NO_CARE_OTHER_VALUE.c_str(), NO_CARE_OTHER_VALUE.size(), &result));
}
// end GetFilterMultiPatternMatcher

// GetFilterVideoLength
TEST_F(DynamicDictTest, not_exist_video_length_should_get_video_length_return_false) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("test.yaml", doc));

  ASSERT_FALSE(GetFilterVideoLength(doc, NULL));
}

TEST_F(DynamicDictTest, video_length_no_value_should_get_video_length_return_true) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("only_video_length.yaml", doc));

  VideoContentLengthLegal legal_length;
  ASSERT_TRUE(GetFilterVideoLength(doc, &legal_length));
  ASSERT_FALSE(legal_length.is_lenght_filter);
  ASSERT_EQ(legal_length.common_max_len, -1);
  ASSERT_EQ(legal_length.wemedia_max_len, -1);
}

TEST_F(DynamicDictTest, video_length_only_common_should_get_video_length_return_true) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("video_length_only_common.yaml", doc));

  VideoContentLengthLegal legal_length;
  ASSERT_TRUE(GetFilterVideoLength(doc, &legal_length));
  ASSERT_TRUE(legal_length.is_lenght_filter);
  ASSERT_EQ(legal_length.common_max_len, 1);
  ASSERT_EQ(legal_length.wemedia_max_len, -1);
}

TEST_F(DynamicDictTest, video_length_only_wemedia_should_get_video_length_return_true) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("video_length_only_wemedia.yaml", doc));

  VideoContentLengthLegal legal_length;
  ASSERT_TRUE(GetFilterVideoLength(doc, &legal_length));
  ASSERT_TRUE(legal_length.is_lenght_filter);
  ASSERT_EQ(legal_length.common_max_len, -1);
  ASSERT_EQ(legal_length.wemedia_max_len, 1);
}

TEST_F(DynamicDictTest, video_length_should_get_video_length_return_true) {
  YAML::Node doc;
  ASSERT_TRUE(GetMockYamlNode("video_length.yaml", doc));

  VideoContentLengthLegal legal_length;
  ASSERT_TRUE(GetFilterVideoLength(doc, &legal_length));
  ASSERT_TRUE(legal_length.is_lenght_filter);
  ASSERT_EQ(legal_length.common_max_len, 1);
  ASSERT_EQ(legal_length.wemedia_max_len, 2);
}
// end GetFilterVideoLength
}
}