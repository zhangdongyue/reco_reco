// Copyright (c) Alibaba-Inc. All Rights Reserved.
#pragma once

#include <unordered_map>
#include <string>

#include "reco/bizc/filter_rule/online_ha3/base_rule.h"
#include "reco/bizc/common/appname_define.h"

// @brief  filter videos by playback attribute or show mode
//         such as aspect ratio,resolution ratio and so on.
//
// @author Zippy(dongyue.zdy@alibaba-inc.com)
// @date   2017-10-20 11:35:00

namespace reco {
namespace filter {

enum VideoShowModeType {
  kLandscape = 0,
  kPortrait,
  kFix,
};

using reco::filter::FilterReason;

class VideoPlaybackAttrRule : public BaseRule {
  public:
    VideoPlaybackAttrRule() = default;

    virtual ~VideoPlaybackAttrRule() = default;

    virtual FilterType GetFilterType() {
      return VideoPlaybackAttrFilter;
    }

    virtual bool Filter(const Options& options,
                   const ItemInfo& item,
                   FilterReason* filterno);

  protected:
    virtual bool AspectRatioFilter(const Options& options,
                                   const ItemInfo& item,
                                   FilterReason* filterno);

  private:
    bool HitAspectRatioFilterRule(const Options& options,
                              const AspectRatioInfo& asp_ratio_info,
                              const ItemInfo& item);

    bool JugdeVersion(const std::string& val,
                      const ::base::Version& s,
                      const ::base::Version& e);

    bool JugdeAspectRatio(const Options& options,
                          const AspectRatioInfo& asp_ratio_info,
                          const ItemInfo& item);
};

inline bool
VideoPlaybackAttrRule::Filter(const Options& options,
                              const ItemInfo& item,
                              FilterReason* filterno) {
  if (item.item_type == ::reco::kPureVideo) {
     return AspectRatioFilter(options, item, filterno);
  }

  *filterno = kNoFiltered;
  return false;
}

inline bool
VideoPlaybackAttrRule::AspectRatioFilter(const Options& options,
                                         const ItemInfo& item,
                                         FilterReason* filterno) {
  if (!options.video_playback_attr_filter_dict) {
    *filterno = kNoFiltered;
    return false;
  }

  const std::unordered_map<int64, VecAspectRatioInfo>& asp_ratio_map
        = options.video_playback_attr_filter_dict->aspect_ratio_info_map;

  std::unordered_map<int64, VecAspectRatioInfo>::const_iterator ar_map_iter
    = asp_ratio_map.find(options.channel_id);
  if (ar_map_iter == asp_ratio_map.end()) {
    *filterno = kNoFiltered;
    return false;
  }

  const VecAspectRatioInfo& asp_ratio_info_vec = ar_map_iter->second;

  VecAspectRatioInfo::const_iterator ari_vec_iter;
  for (ari_vec_iter = asp_ratio_info_vec.begin(); ari_vec_iter != asp_ratio_info_vec.end(); ++ari_vec_iter) {
    if (HitAspectRatioFilterRule(options, *ari_vec_iter, item)) {
      *filterno = kFilterByVideoAspectRatio;
      VLOG(1) << "filtered by kFilterByVideoAspectRatio item_id:" << item.item_id;
      return true;
    }
  }

  *filterno = kNoFiltered;
  return false;
}

// @brief : 只对规则配置里面的系统版本以及 channelid 做过滤
//          并且不满足视频的长宽比(或横竖屏)才会被过滤.
//
// @return false-不需要过滤 true-需要过滤
inline bool
VideoPlaybackAttrRule::HitAspectRatioFilterRule(const Options& options,
                                            const AspectRatioInfo& asp_ratio_info,
                                            const ItemInfo& item) {
  if (asp_ratio_info.app_name != reco::common::kGeneralApp &&
      asp_ratio_info.app_name != options.app_name) return false;

  if (!asp_ratio_info.platform.empty()) {
    bool is_ios = ((asp_ratio_info.platform.compare("ios") == 0));
    if (is_ios != options.is_ios) { return false; }
  }


  if (!JugdeVersion(options.ve, asp_ratio_info.ve_s, asp_ratio_info.ve_e)) {
    return false;
  }

  return !JugdeAspectRatio(options, asp_ratio_info, item);
}

inline bool
VideoPlaybackAttrRule::JugdeVersion(const std::string& val, const ::base::Version& s, const ::base::Version& e) {
  ::base::Version v(val);
  if (!v.IsValid() ||
      (!s.IsValid() && !e.IsValid()) ||
      (!s.IsValid() && v.CompareTo(e) <= 0) ||
      (!e.IsValid() && v.CompareTo(s) >= 0) ||
      (v.CompareTo(s) >= 0 && v.CompareTo(e) <= 0)) {
    return true;
  }
  return false;
};

inline bool
VideoPlaybackAttrRule::JugdeAspectRatio(const Options& options,
                 const AspectRatioInfo& asp_ratio_info,
                 const ItemInfo& item) {
  CHECK(options.news_index);

  int32 width = options.news_index->GetVideoWidthByItemId(item.item_id);
  int32 height = options.news_index->GetVideoHeightByItemId(item.item_id);

  VLOG(2) << " item_id:" << item.item_id << ",width:" << width << ",height:" << height;

  if (asp_ratio_info.mode == kLandscape) {
    return (width >= height);
  }

  if (asp_ratio_info.mode == kPortrait) {
    return (width < height);
  }

  if (asp_ratio_info.mode == kFix) {
    float asp_ratio = (float)asp_ratio_info.w/asp_ratio_info.h;
    float req_ratio = (float)width/height;

    return (req_ratio >= asp_ratio - 0.01 &&
            req_ratio <= asp_ratio + 0.01);
  }

  return false;
}

}  // namespace filter
}  // namespace reco

// vim :set ts=2 sts=2 sw=2 tw=88 et
