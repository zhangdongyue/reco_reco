#include "reco/bizc/filter_rule/online_ha3/component/risk_media_rule.h"

namespace reco {
namespace filter {
DEFINE_bool(open_video_risk_media, true, "");
}
}
