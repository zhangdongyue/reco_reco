#pragma once

#include <boost/shared_ptr.hpp>
#include <string>

#include "base/container/dense_hash_set.h"
#include "extend/multi_strings/multi_pattern_matcher.h"
#include "serving_base/expiry_map/expiry_map.h"

#include "reco/bizc/common/trie.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "reco/bizc/reco_index_ha3/stream_filter_sign_async_calc.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/filter_rule.pb.h"
#include "reco/bizc/reco_index_ha3/filter_rule.h"
#include "reco/bizc/reco_index_ha3/news_index_ha3.h"
#include "reco/serv/reco_leaf_plugin/strategy/user_feature/user_feature.h"

namespace reco {
namespace filter {
// placeholder
enum FilterType {
  ItemFilter = 1 << 0,
  SessionFilter = 1 << 1,
  RiskMediaFilter = 1 << 2,
  AppTokenFilter = 1 << 3,
  VideoPlaybackAttrFilter = 1 << 4,
};


struct Options {
  // 规则
  uint64 filter_subset;  // 本次调用使用的过滤规则

  // 变量
  ::reco::NewsIndex *news_index;
  const base::dense_hash_set<uint64>* shown_set;
  const ::reco::leafserver::UserFeature* user_feas;
  RuleChain rule_chain;
  BitList req_bit;
  int64 channel_id;
  std::string province;
  std::string city;
  std::string app_token;
  std::string ve;  // client os version(major.minor.point)
  int app_token_idx;
  reco::common::AppNames app_name;
  int64 cur_timestamp;
  int title_min_len;
  int title_max_len;
  int today_access_cnt;
  int32 pcode;

  // 词典
  boost::shared_ptr<const RiskMediaDict> risk_media_dict;
  boost::shared_ptr<const VideoPlaybackAttrFilterDict> video_playback_attr_filter_dict;
  StreamFilterSignAsyncCalc* stream_filter;
  reco::common::Trie* black_source;
  boost::shared_ptr<const reco::dm::DictManager::UnorderedSetUint64> youtu_dirty_channel_dict;

  // flags
  bool is_debug;
  bool is_manual_reco;  // 是否是运营新闻推荐逻辑, 只是在运营推荐逻辑中设置值
  bool is_main_city;
  bool is_unknown_city;
  bool is_new_user;
  bool is_wsg_enc;  // 无线保镖
  bool is_loyal;  // 忠实用户
  bool is_ios;
  bool is_inner_app;
  bool is_uc_iflow_app;
  bool is_youku_open_token;

  // filter switch
  // app_token
  bool do_apprule_filter;

  // item_attr
  bool do_item_valid_filter;
  bool do_sensitive_filter;
  bool do_sim_check_filter;

  // risk_media
  bool do_video_filter;
  bool do_video_risk_check;
  bool do_news_filter;

  // user_session
  bool do_stream_filter;
  bool do_user_show_history_filter;
  bool do_title_filter;
  bool do_user_dislike_filter;
  bool do_quality_dirty_filter;
  bool do_valid_in_app_filter;
  bool do_rule_chain_filter;
  bool do_local_channel_filter;
  bool do_first_n_screen_filter;
  bool do_source_enhance_filter;
  bool do_video_poster_filter;
  bool do_video_play_control_filter;
  bool do_youtu_special_filter;
  bool do_video_channel_filter;

  Options() {
    Clear();
  }

  void Clear() {
    // 规则
    filter_subset = ~0;
    // 变量
    news_index = NULL;
    shown_set = NULL;
    user_feas = NULL;
    rule_chain.reset();
    req_bit.reset();
    channel_id = -1;
    province.clear();
    city.clear();
    app_token_idx = -1;
    app_token.clear();
    ve.clear();
    app_name = reco::common::kGeneralApp;
    cur_timestamp = base::GetTimestamp();
    title_min_len = -1;
    title_max_len = -1;
    today_access_cnt = -1;
    pcode = -1;
    // 词典
    risk_media_dict.reset();
    stream_filter = NULL;
    black_source = NULL;
    youtu_dirty_channel_dict.reset();
    // flags
    is_debug = false;
    is_manual_reco = false;
    is_main_city = false;
    is_unknown_city = false;
    is_new_user = false;
    is_wsg_enc = false;
    is_loyal = false;
    is_ios = false;
    is_inner_app = false;
    is_uc_iflow_app = false;
    is_youku_open_token = false;
    // filter switch
    // app_token
    do_apprule_filter = false;

    // item_attr
    do_item_valid_filter = false;
    do_sensitive_filter = false;
    do_sim_check_filter = false;

    // risk_media
    do_video_filter = false;
    do_video_risk_check = false;
    do_news_filter = false;

    // user_session
    do_user_show_history_filter = false;
    do_title_filter = false;
    do_user_dislike_filter = false;
    do_quality_dirty_filter = false;
    do_valid_in_app_filter = false;
    do_rule_chain_filter = false;
    do_local_channel_filter = false;
    do_stream_filter = false;
    do_first_n_screen_filter = false;
    do_source_enhance_filter = false;
    do_video_poster_filter = false;
    do_video_play_control_filter = false;
    do_youtu_special_filter = false;
    do_video_channel_filter = false;
  }
};
}
}
