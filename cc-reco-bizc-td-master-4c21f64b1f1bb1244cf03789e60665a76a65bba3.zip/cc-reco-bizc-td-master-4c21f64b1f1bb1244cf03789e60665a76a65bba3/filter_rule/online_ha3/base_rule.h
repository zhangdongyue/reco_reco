#pragma once

#include "base/common/gflags.h"
#include "reco/bizc/filter_rule/online_ha3/define.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace filter {
class BaseRule {
 public:
  BaseRule() {}

  virtual ~BaseRule() {}

  virtual FilterType GetFilterType() = 0;

  virtual bool Filter(const Options& options, const ItemInfo& item, reco::filter::FilterReason* filterno) = 0;
};
}
}
