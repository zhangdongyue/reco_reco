#pragma once

#include <vector>

#include "reco/bizc/filter_rule/online_ha3/define.h"

namespace reco {
namespace filter {
class BaseRule;

class FilterMonster {
 public:
  // 这里的 filter_types 是服务启动时候，需要注册的所有过滤规则
  // 在实际调用时候，可以在 options 中配置它的子集进行调用: options.filter_subset, 默认值是走全部注册的规则
  explicit FilterMonster(const uint64 filter_rules, ::reco::NewsIndex* index);

  virtual ~FilterMonster();

  bool Filter(const ::reco::ItemInfo& item, Options* options, reco::filter::FilterReason* filterno);
 protected:
  // 可由子类重写的填充 rule 接口
  // 方便在实际使用的时候由使用方重新组织 rule 而不影响其他使用方
  virtual void FillRule(const uint64 filter_types);

 private:
  ::reco::NewsIndex *news_index_;
  std::vector<BaseRule*> rules_;
};
}
}
