#pragma once

#include <string>
#include <vector>
#include <utility>

#include "base/testing/gtest.h"
#include "reco/bizc/proto/index_service.pb.h"

namespace adsindexing {
class Index;
}

namespace reco {
namespace index_monitor {

class IndexServiceImpl : public reco::index_monitor::IndexService {
 public:
  explicit IndexServiceImpl(adsindexing::Index *index) : index_(index) {}
  ~IndexServiceImpl() {}
  virtual void modifyIndex(::stumy::RpcController* controller,
                           const reco::index_monitor::ModifyIndexRequest* request,
                           reco::index_monitor::ModifyIndexResponse* response,
                           ::Closure* done);
  virtual void getAttr(::stumy::RpcController* controller,
                       const reco::index_monitor::GetAttrRequest* request,
                       reco::index_monitor::GetAttrResponse* response,
                       ::Closure* done);

  virtual void getInvertedIndex(::stumy::RpcController* controller,
                                const reco::index_monitor::GetInvertedIndexRequest* request,
                                reco::index_monitor::GetInvertedIndexResponse* response,
                                ::Closure* done);

 private:
  adsindexing::Index *index_;
  DISALLOW_COPY_AND_ASSIGN(IndexServiceImpl);
};

}  // namespace index_monitor
}  // namespace reco
