#include "reco/bizc/index_monitor/rpc/index_service_impl.h"

#include <algorithm>
#include <utility>

#include "ads_index/api/public.h"
#include "ads_index/dynamic_index/dynamic_index.h"

#include "base/strings/string_number_conversions.h"
#include "base/common/scoped_ptr.h"

#include "serving_base/utility/timer.h"

namespace reco {
namespace index_monitor {

void IndexServiceImpl::modifyIndex(::stumy::RpcController* controller,
                                   const reco::index_monitor::ModifyIndexRequest* request,
                                   reco::index_monitor::ModifyIndexResponse* response,
                                   ::Closure* done) {
  ScopedClosure scoped_closure(done);

  // 不要往非动态索引里面加文档
  if (index_->IndexType() != "dynamic") {
    LOG(ERROR) << "add cdoc to non-dynamic index";
    response->set_success(false);
    response->set_reason("not dynamic index");
    return;
  }
  adsindexing::DynamicIndex* dynamic_index = static_cast<adsindexing::DynamicIndex *>(index_);

  std::vector<std::string> compression_cdocs;
  for (int i = 0; i < request->compression_cdoc_size(); ++i) {
    compression_cdocs.push_back(request->compression_cdoc(i));
  }

  if (dynamic_index->IsBusy()) {
    response->set_success(false);
    response->set_reason("index too busy");
    return;
  }

  if (!dynamic_index->AddCDocs(0, compression_cdocs)) {
    response->set_success(false);
    response->set_reason("add cdocs to index failed");
    return;
  }

  // 添加成功
  response->set_success(true);
  LOG(INFO) << "add " << compression_cdocs.size() << "to index success";
  return;
}

void IndexServiceImpl::getAttr(::stumy::RpcController* controller,
                               const reco::index_monitor::GetAttrRequest* request,
                               reco::index_monitor::GetAttrResponse* response,
                               ::Closure* done) {
  ScopedClosure scoped_closure(done);
  for (int i = 0; i < request->attr_size(); ++i) {
    int doc_local_id = index_->DocLocalIDFromKeySign(request->attr(i).key_sign());
    adsindexing::CustomerAttrValue value;
    if (index_->GetDocCustomerAttr(request->attr(i).attr_key(), doc_local_id, &value)) {
      response->add_attr(std::string(value.data, value.size));
    } else {
      response->add_attr(request->attr(i).default_attr());
    }
  }
}

void IndexServiceImpl::getInvertedIndex(::stumy::RpcController* controller,
                                        const reco::index_monitor::GetInvertedIndexRequest* request,
                                        reco::index_monitor::GetInvertedIndexResponse* response,
                                        ::Closure* done) {
  ScopedClosure scoped_closure(done);
  auto doc_it = index_->NewDocIterator(request->term(), adsindexing::kUnigramTerm);
  if (doc_it) {
    for (; !doc_it->Done(); doc_it->Next()) {
      int doc_local_id = doc_it->GetDocLocalId();
      auto doc_info = index_->GetDocInfo(doc_local_id);
      if (doc_info && (doc_info->doc_mask & adsindexing::kDocMaskInvalid) == 0) {
        response->add_key_sign(doc_info->key_sign);
      }
    }
    delete doc_it;
  }
}
}  // namespace index_monitor
}  // namespace reco
