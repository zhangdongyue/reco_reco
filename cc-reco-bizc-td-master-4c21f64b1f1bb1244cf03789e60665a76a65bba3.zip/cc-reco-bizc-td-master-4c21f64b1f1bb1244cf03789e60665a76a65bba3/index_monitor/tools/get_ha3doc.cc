#include <fstream>

#include "ads_index/api/public.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "base/time/time.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/base/common/local_db/local_db.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/bizc/proto/reco_convertor_server.pb.h"

#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"

#include "ads_index/proto/index.pb.h"

DEFINE_string(item_ids_file, "index_item_id", "");
DEFINE_string(ha3doc_output_file, "ha3doc", "output ha3doc file.");
DEFINE_string(item_keeper_server_ip, "", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 8899, "item keeper ports");
DEFINE_int32(get_item_thread_num, 10, "");
DEFINE_int32(get_item_sleep_millseconds, 1000, "");

DEFINE_string(convertor_server_ip, "1.2.3.4", "convert ip");
DEFINE_int32(convertor_server_port, 8899, "convert ports");
DEFINE_int32(convert_thread_num, 10, "");
DEFINE_int32(convert_sleep_millseconds, 1000, "");

typedef std::pair<uint64, time_t> IDTimeT;


enum WORK_MODE {
  WORK_RPC_CONVERT = 0,
  WORK_RPC_CONVERT_PUSH_DOC
};

DEFINE_int32(work_mode, WORK_RPC_CONVERT,
  "0-rpc convert to get ha3doc string, 1-push ha3doc kafka");


class IndexBuilder {
  public:
  IndexBuilder();
  ~IndexBuilder();
  thread::BlockingQueue<IDTimeT>& IDTimeQueue() { return id_time_queue_; }
  thread::BlockingQueue<std::string>& CDocQueue() { return reco_item_queue_; }
  void GetItemThread();
  void ConvertThread();

  private:
  void GetFromItemKeep(const std::vector<uint64>& item_ids);
  void Convert(const reco::RecoItem& item);
  void SendKafka(const reco::RecoItem& item);

  private:
  thread::BlockingQueue<IDTimeT> id_time_queue_;
  thread::BlockingQueue<std::string> reco_item_queue_;

  net::rpc::RpcGroup* item_keeper_rpc_group_;
  reco::itemkeeper::ItemKeeper::Stub* item_keeper_stub_;

  net::rpc::RpcGroup* convertor_rpc_group_;
  reco::convertor::ConvertorService::Stub* convertor_stub_;


  mutable thread::Mutex mutex_;
  std::vector<std::string> cdoc_strings_;
  std::vector<uint64> item_ids_;

  std::ofstream   ofresult_;

  public:
  // atomic_int from_hbase_;
  atomic_int from_item_keeper_;

  atomic_int get_item_num_;
  atomic_int convert_num_;
};

bool loadItemIds(const std::string & filepath, thread::BlockingQueue<IDTimeT>* idq) {
  std::ifstream infile(filepath.c_str());
  std::string temp;
  int id_num = 0;
  while (getline(infile, temp)) {
    if (temp != "") {
      uint64 id = 0u;
      if (!base::StringToUint64(temp, &id)) {
        LOG(WARNING) << "parse id error: " << temp;
        continue;
      }

      idq->Put(std::make_pair(id, 0));
      // LOG(INFO) << "load_id:\t" << id;
      id_num++;
    }
  }

  LOG(INFO) << "load id num:" << id_num;
  return true;
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "get ha3doc from reco item data");

  IndexBuilder builder;
  thread::ThreadPool get_item_pool(FLAGS_get_item_thread_num);
  for (int i = 0; i < FLAGS_get_item_thread_num; ++i) {
    get_item_pool.AddTask(::NewCallback(&builder, &IndexBuilder::GetItemThread));
  }

  thread::ThreadPool convert_pool(FLAGS_convert_thread_num);
  for (int i = 0; i < FLAGS_convert_thread_num; ++i) {
    convert_pool.AddTask(::NewCallback(&builder, &IndexBuilder::ConvertThread));
  }

  if (!loadItemIds(FLAGS_item_ids_file, &(builder.IDTimeQueue()))) {
    LOG(ERROR) << "load item id error.file: " << FLAGS_item_ids_file;
  }

  builder.IDTimeQueue().Close();

  get_item_pool.JoinAll();
  builder.CDocQueue().Close();
  LOG(ERROR) << "get item : " << builder.from_item_keeper_;

  convert_pool.JoinAll();
  LOG(ERROR) << "final, convert_num=" << builder.convert_num_;

  LOG(ERROR) << "get ha3doc end.";
  return 0;
}

static net::rpc::RpcGroup* SetupConnection(const std::string& ips, int port,
  int timeout, int retry) {
  std::vector<std::string> flds;
  base::SplitString(ips, ",", &flds);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = retry;
  options.timeout = timeout;
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], port, timeout);
    options.servers.push_back(si);
  }

  auto group = new net::rpc::RpcGroup(options);
  CHECK(group->Connect());
  return group;
}

IndexBuilder::IndexBuilder()
  : from_item_keeper_(0),
  get_item_num_(0),
  convert_num_(0) {
  item_keeper_rpc_group_
    = SetupConnection(FLAGS_item_keeper_server_ip, FLAGS_item_keeper_server_port, 10000, 3);
  item_keeper_stub_ = new reco::itemkeeper::ItemKeeper::Stub(item_keeper_rpc_group_);

  convertor_rpc_group_ = SetupConnection(FLAGS_convertor_server_ip, FLAGS_convertor_server_port, 3000, 3);
  convertor_stub_ = new reco::convertor::ConvertorService::Stub(convertor_rpc_group_);

  std::string ofname = FLAGS_ha3doc_output_file;
  ofresult_.open(ofname, std::ios::app);

  if (ofresult_.is_open()) {
    LOG(ERROR) << "open file succ: "<< ofname;
  } else {
    LOG(ERROR) << "open file fail: "<< ofname;
  }
}

IndexBuilder::~IndexBuilder() {
  delete item_keeper_rpc_group_;
  delete item_keeper_stub_;

  delete convertor_rpc_group_;
  delete convertor_stub_;

  ofresult_.flush();
  ofresult_.close();
}

void IndexBuilder::GetItemThread() {
  static const size_t batch_count = 200;
  std::vector<uint64> ids_to_get;

  while (true) {
    IDTimeT id_time;
    int ret = id_time_queue_.TryTake(&id_time);
    if (-1 == ret) {        // 队列为空，且关闭
      GetFromItemKeep(ids_to_get);
      break;
    } else if (0 == ret) {  // 队列为空
      base::SleepForSeconds(1);
      continue;
    }

    std::string cdoc_string;
    ids_to_get.push_back(id_time.first);
    if (ids_to_get.size() < batch_count) {
      continue;
    }

    GetFromItemKeep(ids_to_get);
    ids_to_get.clear();

    if (from_item_keeper_> get_item_num_) {
      get_item_num_ += 10000;
      LOG(ERROR) << "from item_keeper : " << from_item_keeper_;
    }
  }
}

void IndexBuilder::GetFromItemKeep(const std::vector<uint64>& item_ids) {
  if (item_ids.empty())  return;

  reco::RecoItem reco_item;
  for (size_t idx = 0; idx < item_ids.size(); ++idx) {
    uint64 item_id = item_ids.at(idx);
    reco::itemkeeper::RefreshRecoItemRequest request;
    reco::itemkeeper::RefreshRecoItemResponse response;
    request.mutable_service_identity()->set_service_name("ha3_index_builder");
    request.add_item_id(item_id);
    request.add_exclude_storages(reco::itemkeeper::kCdocQueue);

    net::rpc::RpcClientController rpc;
    item_keeper_stub_->refreshRecoItem(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()
      || response.reco_item_size() != 1) {
      LOG(ERROR) <<
        base::StringPrintf("refresh reco item failed. response error_message[%s], "
          "rpc status[%d], item_d[%lu]",
          response.err_message().c_str(),
          rpc.status(),
          item_id);
      continue;
    } else {
      LOG(INFO) << "get itemkeeper done: " << item_id;
      reco_item.CopyFrom(response.reco_item(0));
    }
    std::string str_reco_item;
    reco_item.SerializeToString(&str_reco_item);
    reco_item_queue_.Put(str_reco_item);

    ++from_item_keeper_;

    if (FLAGS_get_item_sleep_millseconds != 0) {
      // LOG(INFO) << "get sleep: " << FLAGS_get_item_sleep_millseconds;
      base::SleepForMilliseconds(FLAGS_get_item_sleep_millseconds);
    }
  }
}

void IndexBuilder::ConvertThread() {
  while (true) {
    std::string cdoc_string;
    int ret = reco_item_queue_.TryTake(&cdoc_string);
    if (-1 == ret) {        // 队列为空，且关闭
      break;
    } else if (0 == ret) {  // 队列为空
      base::SleepForSeconds(1);
      continue;
    }

    reco::RecoItem item;
    if (!item.ParseFromString(cdoc_string)) {
      LOG(ERROR) << "parse from string err";
      continue;
    }

    if (FLAGS_work_mode == WORK_RPC_CONVERT) {
      Convert(item);
      LOG(INFO) << "convert item done: " << item.identity().item_id();
    } else if (FLAGS_work_mode == WORK_RPC_CONVERT_PUSH_DOC) {
      SendKafka(item);
      LOG(INFO) << "send item done: " << item.identity().item_id();
    } else {
      LOG(ERROR) << "unsupported work_mode=" << FLAGS_work_mode;
      break;
    }

    if (convert_num_%1000 == 0) {
      LOG(ERROR) << "convert_num=" << convert_num_;
    }

    if (FLAGS_convert_sleep_millseconds != 0) {
      base::SleepForMilliseconds(FLAGS_convert_sleep_millseconds);
      // LOG(INFO) << "convert sleep: " << FLAGS_convert_sleep_millseconds;
    }
  }
}

void IndexBuilder::Convert(const reco::RecoItem& item) {
  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  std::string cdoc_string;
  reco::convertor::ConvertRecoItemRequest request;
  reco::convertor::ConvertRecoItem2Ha3DocResponse response;
  request.mutable_reco_item()->CopyFrom(item);
  convertor_stub_->convertRecoItem2Ha3Doc(&rpc, &request, &response, NULL);
  rpc.Wait();

  if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
    LOG(ERROR) << "rpc convert ha3doc failed" << response.err_msg();
    return;
  } else {
    ofresult_ << response.res();
    convert_num_ += 1;
  }
}

void IndexBuilder::SendKafka(const reco::RecoItem& item) {
  uint64 item_id = item.identity().item_id();
  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  std::string cdoc_string;
  reco::convertor::PushRecoItemToCDocQueueRequest request;
  reco::convertor::PushRecoItemToCDocQueueResponse response;
  request.mutable_reco_item()->CopyFrom(item);
  convertor_stub_->pushRecoItemToCDocQueue(&rpc, &request, &response, NULL);
  rpc.Wait();

  if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
    LOG(ERROR) << "Send ha3doc failed:" << response.err_message();
    return;
  } else {
    convert_num_ +=1;

    LOG(INFO) << "send ha3doc succ:" << item_id << " is_pushed=" << response.is_pushed();
  }
}
