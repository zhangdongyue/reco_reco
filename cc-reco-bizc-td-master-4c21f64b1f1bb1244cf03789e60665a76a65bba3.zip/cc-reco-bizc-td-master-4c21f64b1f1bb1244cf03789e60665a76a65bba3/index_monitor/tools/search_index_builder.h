//
// Created by allen.fw on 2017/11/14.
//

#pragma once

#include "reco/bizc/index_monitor/index_builder/dao/ProducerEntityDao.h"
#include "base/thread/blocking_queue.h"
#include "reco/bizc/proto/item.pb.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/base/common/local_db/local_db.h"
#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "base/container/dense_hash_set.h"

typedef std::pair<uint64, time_t> IDTimeT;

DECLARE_string(output_index_dir);
DECLARE_int32(get_item_thread_num);
DECLARE_int32(run_type);

class SearchIndexBuilder {
 public:
  SearchIndexBuilder(ProducerEntityDao *producer_dao = NULL);
  ~SearchIndexBuilder();
  thread::BlockingQueue<IDTimeT>& IDTimeQueue() { return id_time_queue_; }
  thread::BlockingQueue<std::string>& CDocQueue() { return reco_item_queue_; }
  void GetItemThread();
  void ConvertThread();
  void BuildIndex();
  void GetSimData(thread::BlockingQueue<uint64>* valid_id_queue);

 private:
  //void GetFromHBase(std::vector<uint64>& item_ids);
  void GetFromItemKeep(const std::vector<uint64>& item_ids);
  bool GetFromLocal(IDTimeT id_time, std::string* cdoc_string);
  void PutLocal(const std::string& item_id, const std::string& cdoc_string);
  void Convert(reco::RecoItem& item);

 private:
  reco::common::LocalDB* localdb_;
  thread::BlockingQueue<IDTimeT> id_time_queue_;
  thread::BlockingQueue<std::string> reco_item_queue_;

  net::rpc::RpcGroup* convertor_rpc_group_;
  reco::convertor::ConvertorService::Stub* convertor_stub_;

  net::rpc::RpcGroup* item_keeper_rpc_group_;
  reco::itemkeeper::ItemKeeper::Stub* item_keeper_stub_;

  mutable thread::Mutex mutex_;
  std::vector<std::string> cdoc_strings_;

  std::vector<uint64> item_ids_;

  // 生产者白名单
  base::dense_hash_set<std::string> producer_whitelist_set_;

 public:
  //atomic_int from_hbase_;
  std::atomic_int from_item_keeper_;
  std::atomic_int from_local_;

  std::atomic_int get_item_num_;
  std::atomic_int convert_num_;
};

bool IsBuildIndex();
bool IsDumpFiles();
