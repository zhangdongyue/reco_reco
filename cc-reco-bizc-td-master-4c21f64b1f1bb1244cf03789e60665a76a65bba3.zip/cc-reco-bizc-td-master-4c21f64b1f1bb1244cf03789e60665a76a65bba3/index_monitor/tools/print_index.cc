#include <iostream>
#include <vector>

#include "reco/bizc/index_monitor/api/index_monitor.h"
#include "reco/bizc/reco_index/news_index.h"
#include "serving_base/utility/signal.h"

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "");

  reco::index_monitor::IndexMonitor monitor;
  monitor.Start();

  LOG(INFO) << "index monitor started";
  adsindexing::Index* index = monitor.GetIndex();

  int32 doc_num = index->GetDocNum();
  LOG(INFO) << "doc_num: " << doc_num;

  reco::NewsIndex* news_index = reco::InitializeNewsIndex(index);
  base::Time now = base::Time::Now();

  uint64 item_id;
  std::vector<int64> channels;
  std::vector<reco::Category> categories;
  std::string source;
  std::string str_channel;
  int last_update_min_doc_id = 0;
  while (true) {
    int min_doc_id = news_index->MinDocLocalId();
    int max_doc_id = (last_update_min_doc_id == 0) ? news_index->MaxDocLocalId() : last_update_min_doc_id;
    LOG(INFO) << "LOOP " << last_update_min_doc_id;
    last_update_min_doc_id = min_doc_id;
    for (int doc_id = min_doc_id; doc_id < max_doc_id; ++doc_id) {
      if (!news_index->GetItemIdByDocId(doc_id, &item_id)) {
        LOG(ERROR) << "get itemid by docid fail, docid: " << doc_id;
        continue;
      }
      bool is_valid = news_index->IsValidByDocId(doc_id);
      // if (!news_index->IsValidByDocId(doc_id)) {
      //   LOG(WARNING) << "invalid item, " << item_id;
      //   continue;
      // }
      CHECK(news_index->GetChannelsByDocId(doc_id, &channels));
      int64 expire_timestamp = news_index->GetExpireTimestampByItemId(item_id);
      base::Time expire_time = base::Time::FromDoubleT(expire_timestamp / base::Time::kMicrosecondsPerSecond);
      bool is_expire = news_index->IsExpiredByDocId(doc_id, now.ToDoubleT() * base::Time::kMicrosecondsPerSecond);
      // item time
      int64 timestamp = news_index->GetCreateTimestampByItemId(item_id);
      base::Time item_time = base::Time::FromDoubleT(timestamp / base::Time::kMicrosecondsPerSecond);
      // category
      categories.clear();
      news_index->GetCategoriesByItemId(item_id, &categories);
      std::string category = categories.empty() ? "" : categories[0].category();
      // source
      news_index->GetSourceByItemId(item_id, &source);
      reco::ItemType type = reco::kNone;
      news_index->GetItemTypeByDocId(doc_id, &type);
      std::string timeStr;
      str_channel.clear();
      for (int k = 0; k < (int)channels.size(); ++k) {
        if (k != 0) str_channel.append("|");
        str_channel.append(base::Int64ToString(channels[k]));
      }
      reco::FeatureVector feature;
      std::string tags = "";
      if (news_index->GetFeatureVectorByItemId(item_id, reco::common::kTag, &feature)) {
        for (int i = 0; i < feature.feature_size(); ++i) {
          tags += feature.feature(i).literal() + " ";
        }
      }
      item_time.ToStringInSeconds(&timeStr);
      std::string expire_time_str;
      expire_time.ToStringInSeconds(&expire_time_str);
      LOG(INFO) << item_id << "\t" << type << "\t" << category << "\t" << str_channel
                << "\t" << source << "\t" << timeStr << "\t" << expire_time_str
                << "\t" << is_expire << "\t" << tags << "\t" << doc_id << "\t" << is_valid;
    }
    sleep(10);
  }

  return 0;
}
