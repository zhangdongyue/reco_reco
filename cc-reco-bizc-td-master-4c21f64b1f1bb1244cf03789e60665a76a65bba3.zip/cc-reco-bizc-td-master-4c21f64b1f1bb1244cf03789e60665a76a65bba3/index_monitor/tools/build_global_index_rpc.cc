#include <iostream>
#include <fstream>
#include <algorithm>

#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

#include "ads_index/proto/index.pb.h"
#include "ads_index/api/public.h"

#include "base/file/memory_mapped_file.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/encoding/line_escape.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"
#include "serving_base/utility/signal.h"
#include "net/rpc_util/rpc_group.h"

DEFINE_string(convertor_server_ip, "100.85.69.71", "server ip");
DEFINE_int32(convertor_server_port, 20021, "server port");
DEFINE_string(item_keeper_ips, "11.251.203.75,11.251.204.31,11.251.203.226,11.251.204.93,11.251.203.47", "ip");  // NOLINT
DEFINE_int32(item_keeper_port, 20021, "server port");
DEFINE_string(item_id_file, "item_id.txt", "item id list to build index.");
DEFINE_string(output_index_dir, "reco_index", "output index dir.");
DEFINE_string(build_index_type, "static", "index type: dynamic or static.");
DEFINE_bool(convert_reco_item, false, "if true, use convertor to renew reco item.");
DEFINE_int32(convert_thread_num, 16, "num of convert thread");
DEFINE_int32(estimated_doc_num, 1000000, "estimated num of doc");


void ConvertWorker(int thread_id,
                   thread::BlockingQueue<uint64>* item_queue,
                   thread::BlockingQueue<std::string>* cdoc_queue,
                   thread::BlockingVar<int>* finish_worker_num,
                   reco::convertor::ConvertorService::Stub* rpc_stub) {
  reco::BaseGetItem* get_item = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips, FLAGS_item_keeper_port);

  LOG(INFO) << "convert worker start, thread id: " << thread_id;
  adsindexing::IndexDocInfo cdoc;
  std::string cdoc_string;
  int finish_num = 0;

  base::Time now = base::Time::Now();
  // base::Time week_ago = now - base::TimeDelta::FromDays(7);
  std::string now_string;
  now.ToStringInSeconds(&now_string);
  base::Time no_write_hbase_time = now - base::TimeDelta::FromDays(30);
  std::string no_write_hbase_time_str;
  no_write_hbase_time.ToStringInSeconds(&no_write_hbase_time_str);
  base::PseudoRandom random;
  while (!item_queue->Closed() || !item_queue->Empty()) {
    if (item_queue->Empty()) {
      base::SleepForSeconds(1);
      continue;
    }
    uint64 item_id;
    int status = item_queue->TimedTake(10, &item_id);

    if (status == -1) break;
    if (status == 0) continue;
    if (status != 1) {
      LOG(ERROR) << "unknown erro occured: " << status;
      continue;
    }

    reco::RecoItem item;
    if (!get_item->GetRecoItem(item_id, &item)) continue;

    reco::RecoItem *reco_item = &item;
    if (FLAGS_convert_reco_item) {
		/*
      reco::convertor::ConvertRawItemRequest request;
      reco::convertor::ConvertRawItemResponse response;
      request.mutable_raw_item()->CopyFrom(reco_item->raw_item());
      request.set_convert_to_reco(true);
      request.set_convert_to_cdoc(true);
      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(120);
      rpc_stub->convertRawItem(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()) {
        LOG(ERROR) << "convert raw item failed. " << response.err_msg();
        continue;
      } else {
        std::string cdoc_string;
        response.cdoc().SerializeToString(&cdoc_string);
        cdoc_queue->Put(cdoc_string);
      }
	  */
    } else {
      reco::convertor::ConvertRecoItemRequest request;
      reco::convertor::ConvertRecoItemResponse response;
      request.mutable_reco_item()->CopyFrom(*reco_item);
      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(120);
      rpc_stub->convertRecoItem(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()) {
        LOG(ERROR) << "convert reco item failed. " << response.err_msg();
        continue;
      } else {
        std::string cdoc_string;
        response.cdoc().SerializeToString(&cdoc_string);
        cdoc_queue->Put(cdoc_string);
      }
    }
    LOG(INFO) << "done convert: " << reco_item->identity().item_id();

    if (++finish_num % 10000 == 0) {
      LOG(INFO) << finish_num << " convert finished. ";
    }
  }

  int n = finish_worker_num->Take() + 1;
  if (n == FLAGS_convert_thread_num) {
    cdoc_queue->Close();
  }
  CHECK(finish_worker_num->TryPut(n));

  delete get_item;
  LOG(INFO) << "convert worker finish, thread id: " << thread_id;
}

void IndexBuildWorker(thread::BlockingQueue<std::string>* cdoc_queue) {
  std::vector<std::string> cdoc_strings;
  cdoc_strings.reserve(FLAGS_estimated_doc_num);
  std::string cdoc_string;
  while (!cdoc_queue->Closed() || !cdoc_queue->Empty()) {
    if (cdoc_queue->Empty()) {
      base::SleepForSeconds(1);
      continue;
    }
    
    cdoc_strings.push_back("");
    int status = cdoc_queue->TimedTake(10, &cdoc_strings.back());
  
    if (status != 1) {
      cdoc_strings.erase(cdoc_strings.end() - 1);

      if (status == -1) break;
      
      if (status == 0) continue;

      LOG(ERROR) << "unknown erro occured: " << status;
    }
  }

  if (FLAGS_build_index_type == "static") {
    LOG(INFO) << "build static index...";
    adsindexing::BuildStaticIndex(cdoc_strings, FLAGS_output_index_dir);
    LOG(INFO) << "build static index finish.";
    return;
  }

  LOG(INFO) << "build dynamic index..., total cdoc: " << cdoc_queue->Size();

  int file_max_doc_count = 1 << 13;
  std::string doc_prefix = FLAGS_output_index_dir + "/dynamic_index_doc.";
  std::string doc_count_prefix = FLAGS_output_index_dir + "/dynamic_index_doc_count.";
  for (int part = 0; part * file_max_doc_count < (int)cdoc_strings.size(); ++part) {
    std::ofstream doc_output(doc_prefix + base::IntToString(part));
    std::ofstream doc_count_output(doc_count_prefix + base::IntToString(part));
    int part_num = std::min(file_max_doc_count, (int)cdoc_strings.size() - part * file_max_doc_count);
    for (int i = part * file_max_doc_count; i < part * file_max_doc_count + part_num; ++i) {
      std::string compression_cdoc;
      CHECK(adsindexing::GetCompressionCDoc(cdoc_strings[i], &compression_cdoc));
      int size = compression_cdoc.size();
      doc_output.write(reinterpret_cast<const char *>(&size), sizeof(int));
      doc_output.write(compression_cdoc.data(), compression_cdoc.size());
    }
    doc_count_output.write(reinterpret_cast<const char *>(&part_num), sizeof(int));
  }

  LOG(INFO) << "build dynamic index finish.";
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "build static index for reco item data");
  
  // init hbase client pool
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());

  if (FLAGS_build_index_type != "static" && FLAGS_build_index_type != "dynamic") {
    LOG(ERROR) << "build index type should be static or dynamic .";
    return 0;
  }

  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = 3000;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_convertor_server_ip, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_convertor_server_port, 3000);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup* rpc_group = new net::rpc::RpcGroup(options);
  CHECK(rpc_group->Connect());
  reco::convertor::ConvertorService::Stub* rpc_stub =
      new reco::convertor::ConvertorService::Stub(rpc_group);

  thread::BlockingQueue<uint64> item_queue;
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines));
  uint64 item_id;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 1u) {
      continue;
    }
    if (!base::StringToUint64(flds[0], &item_id)) {
      LOG(WARNING) << "item id format error, line is: " << lines[i];
      continue;
    }

    item_queue.Put(item_id);
  }
  item_queue.Close();
  LOG(INFO) << "total item id num, " << item_queue.Size();
   
  thread::BlockingQueue<std::string> cdoc_queue;
  thread::BlockingVar<int> finish_worker_num;
  CHECK(finish_worker_num.TryPut(0));

  LOG(INFO) << "convert thread num: " << FLAGS_convert_thread_num;
  thread::ThreadPool pool(FLAGS_convert_thread_num + 1);
  for (int i = 0; i < FLAGS_convert_thread_num; ++i) {
    pool.AddTask(::NewCallback(ConvertWorker, i, &item_queue, &cdoc_queue, &finish_worker_num, rpc_stub));
  }
  pool.AddTask(::NewCallback(IndexBuildWorker, &cdoc_queue));
  pool.JoinAll();

  delete rpc_stub;
  delete rpc_group;

  LOG(INFO) << "index building stop";
  return 0;
}

