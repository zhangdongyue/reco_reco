#include <iostream>
#include <fstream>
#include <algorithm>

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"

#include "ads_index/api/public.h"

#include "base/file/memory_mapped_file.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/encoding/line_escape.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"
#include "serving_base/utility/signal.h"
#include "net/rpc_util/rpc_group.h"

DEFINE_string(convertor_server_ip, "100.85.69.71", "server ip");
DEFINE_int32(convertor_server_port, 20021, "server port");
DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_string(item_id_file, "item_id", "input item id file");
DEFINE_string(output_index_dir, "reco_index", "output index dir");
DEFINE_string(build_index_type, "static", "index type: dynamic or static");
DEFINE_bool(convert_reco_item, true, "if true, use convertor to renew reco item");
DEFINE_int32(convert_thread_num, 16, "num of convert thread");
DEFINE_int32(estimated_doc_num, 2000000, "estimated num of doc");

void ConvertWorker(int thread_id,
                   thread::BlockingQueue<uint64>* item_id_queue,
                   thread::BlockingQueue<std::string>* cdoc_queue,
                   thread::BlockingVar<int>* finish_worker_num,
                   reco::convertor::ConvertorService::Stub* convertor_stub,
                   reco::itemkeeper::ItemKeeper::Stub* item_keeper_stub) {
  LOG(INFO) << "convert worker start, thread id: " << thread_id;
  reco::RecoItem reco_item;
  int finish_num = 0;

  while (!item_id_queue->Closed() || !item_id_queue->Empty()) {
    if (item_id_queue->Empty()) {
      base::SleepForSeconds(1);
      continue;
    }
    uint64 item_id;
    int status = item_id_queue->TimedTake(10, &item_id);

    if (status == -1) break;
    if (status == 0) continue;

    if (status != 1) {
      LOG(ERROR) << "unknown erro occured: " << status;
      continue;
    }

    reco_item.Clear();
    if (FLAGS_convert_reco_item) {
      reco::itemkeeper::RefreshRecoItemRequest request;
      reco::itemkeeper::RefreshRecoItemResponse response;
      request.mutable_service_identity()->set_service_name("index_builder");
      request.add_item_id(item_id);
      request.add_exclude_storages(reco::itemkeeper::kCdocQueue);

      net::rpc::RpcClientController rpc;
      item_keeper_stub->refreshRecoItem(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()
          || response.reco_item_size() != 1) {
        LOG(ERROR) <<
            base::StringPrintf("refresh reco item failed. response error_message[%s], "
                               "rpc status[%d], item_d[%lu]",
                               response.err_message().c_str(),
                               rpc.status(),
                               item_id);
        continue;
      } else {
        LOG(INFO) << "done refresh reco item: " << item_id;
        reco_item.CopyFrom(response.reco_item(0));
      }
    } else {
      reco::itemkeeper::GetRecoItemRequest request;
      reco::itemkeeper::GetRecoItemResponse response;
      request.add_item_id(item_id);

      net::rpc::RpcClientController rpc;
      item_keeper_stub->getRecoItem(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()
          || response.reco_item_size() != 1) {
        LOG(ERROR) <<
            base::StringPrintf("refresh reco item failed. response error_message[%s], "
                               "rpc status[%d], item_d[%lu]",
                               response.err_message().c_str(),
                               rpc.status(),
                               item_id);
        continue;
      } else {
        LOG(INFO) << "done get reco item: " << item_id;
        reco_item.CopyFrom(response.reco_item(0));
      }
    }

    reco::convertor::ConvertRecoItemRequest request;
    reco::convertor::ConvertRecoItemResponse response;
    request.mutable_reco_item()->CopyFrom(reco_item);
    // LOG(INFO) << request.Utf8DebugString();
    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(120);
    convertor_stub->convertRecoItem(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
      LOG(ERROR) << "convert reco item failed. "
                 << response.err_msg() << rpc.status()
                 << " item id : "
                 << item_id;
      continue;
    } else {
      std::string cdoc_string;
      response.cdoc().SerializeToString(&cdoc_string);
      cdoc_queue->Put(cdoc_string);
    }
    LOG(INFO) << "done convert: " << item_id;

    if (++finish_num % 10000 == 0) {
      LOG(INFO) << finish_num << " convert finished. ";
    }
  }
  int n = finish_worker_num->Take() + 1;
  if (n == FLAGS_convert_thread_num) {
    cdoc_queue->Close();
  }
  CHECK(finish_worker_num->TryPut(n));
  LOG(INFO) << "convert worker done, thread id: " << thread_id;
}

void IndexBuildWorker(thread::BlockingQueue<std::string>* cdoc_queue) {
  std::vector<std::string> cdoc_strings;
  cdoc_strings.reserve(FLAGS_estimated_doc_num);
  std::string cdoc_string;
  while (!cdoc_queue->Closed() || !cdoc_queue->Empty()) {
    if (cdoc_queue->Empty()) {
      base::SleepForSeconds(1);
      continue;
    }

    cdoc_strings.push_back("");
    int status = cdoc_queue->TimedTake(10, &cdoc_strings.back());

    if (status != 1) {
      cdoc_strings.erase(cdoc_strings.end() - 1);

      if (status == -1) break;

      if (status == 0) continue;

      LOG(ERROR) << "unknown erro occured: " << status;
    }
  }

  if (FLAGS_build_index_type == "static") {
    LOG(INFO) << "build static index...";
    adsindexing::BuildStaticIndex(cdoc_strings, FLAGS_output_index_dir);
    LOG(INFO) << "build static index finish.";
    return;
  }

  LOG(INFO) << "build dynamic index...";

  // TODO(jianhuang) 检索端新索引上线后:
  // 1. 去掉/dynamic_index_doc_count.
  // 2. 使用 storage/base/disk_queue.h 中 的DiskQueueWriter
  int file_max_doc_count = 1 << 13;
  std::string doc_prefix = FLAGS_output_index_dir + "/dynamic_index_doc.";
  std::string doc_count_prefix = FLAGS_output_index_dir + "/dynamic_index_doc_count.";
  // std::string doc_count_prefix = FLAGS_output_index_dir + "/dynamic_index_doc_count.";
  for (int part = 0; part * file_max_doc_count < (int)cdoc_strings.size(); ++part) {
    std::ofstream doc_output(doc_prefix + base::IntToString(part));
    std::ofstream doc_count_output(doc_count_prefix + base::IntToString(part));
    // std::ofstream doc_count_output(doc_count_prefix + base::IntToString(part));
    int part_num = std::min(file_max_doc_count, (int)cdoc_strings.size() - part * file_max_doc_count);
    for (int i = part * file_max_doc_count; i < part * file_max_doc_count + part_num; ++i) {
      std::string compression_cdoc;
      CHECK(adsindexing::GetCompressionCDoc(cdoc_strings[i], &compression_cdoc));
      int size = compression_cdoc.size();
      doc_output.write(reinterpret_cast<const char *>(&size), sizeof(int));
      doc_output.write(compression_cdoc.data(), compression_cdoc.size());
    }
    doc_count_output.write(reinterpret_cast<const char *>(&part_num), sizeof(int));
    // doc_count_output.write(reinterpret_cast<const char *>(&part_num), sizeof(int));
  }

  LOG(INFO) << "build dynamic index finish.";
}

static net::rpc::RpcGroup* SetupConnection(const std::string& ips, int port,
                                           int timeout, int retry) {
  std::vector<std::string> flds;
  base::SplitString(ips, ",", &flds);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = retry;
  options.timeout = timeout;
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], port, timeout);
    options.servers.push_back(si);
  }

  auto group = new net::rpc::RpcGroup(options);
  CHECK(group->Connect());
  return group;
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "build static index for reco item data");

  if (FLAGS_build_index_type != "static" && FLAGS_build_index_type != "dynamic") {
    LOG(ERROR) << "build index type should be static or dynamic .";
    return 0;
  }

  LOG(INFO) << "start init convert_rpc";
  net::rpc::RpcGroup* convertor_rpc_group =
      SetupConnection(FLAGS_convertor_server_ip, FLAGS_convertor_server_port, 10000, -1);
  reco::convertor::ConvertorService::Stub* convertor_stub =
      new reco::convertor::ConvertorService::Stub(convertor_rpc_group);
  LOG(INFO) << "finish init convert_rpc";

  LOG(INFO) << "start init item_keeper_rpc";
  net::rpc::RpcGroup* item_keeper_rpc_group =
      SetupConnection(FLAGS_item_keeper_server_ip, FLAGS_item_keeper_server_port, 10000, -1);
  reco::itemkeeper::ItemKeeper::Stub* item_keeper_stub =
      new reco::itemkeeper::ItemKeeper::Stub(item_keeper_rpc_group);
  LOG(INFO) << "finish init item_keeper_rpc";


  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines);
  thread::BlockingQueue<uint64> item_id_queue;
  std::vector<std::string> flds;
  for (size_t i = 0; i < lines.size(); ++i) {
    uint64 item_id;
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (base::StringToUint64(flds[0], &item_id)) {
      item_id_queue.Put(item_id);
    } else {
      LOG(ERROR) << "error item id: " << lines[i];
    }
  }
  item_id_queue.Close();

  thread::BlockingQueue<std::string> cdoc_queue;
  thread::BlockingVar<int> finish_worker_num;
  CHECK(finish_worker_num.TryPut(0));

  thread::ThreadPool pool(FLAGS_convert_thread_num + 1);
  for (int i = 0; i < FLAGS_convert_thread_num; ++i) {
    pool.AddTask(::NewCallback(ConvertWorker,
                               i, &item_id_queue, &cdoc_queue, &finish_worker_num,
                               convertor_stub, item_keeper_stub));
  }
  pool.AddTask(::NewCallback(IndexBuildWorker, &cdoc_queue));
  pool.JoinAll();

  delete convertor_stub;
  delete item_keeper_stub;
  delete convertor_rpc_group;
  delete item_keeper_rpc_group;
  LOG(INFO) << "index building stop";

}

