//
// Created by allen.fw on 2017/11/14.
//

#include "reco/bizc/index_monitor/tools/search_index_builder.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/common/sleep.h"
#include "base/common/logging.h"
#include "reco/bizc/sim_lib/sim_lib.h"
#include "ads_index/api/public.h"

DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_string(output_index_dir, "reco_index", "output index dir");
DEFINE_string(index_cache_dir, "index_cache", "index cache save dir");
DEFINE_int32(get_item_thread_num, 10, "");
DEFINE_string(convertor_server_ip, "11.251.203.75,11.251.203.226,11.251.204.31", "server ip");
DEFINE_int32(convertor_server_port, 20021, "server port");
DEFINE_bool(convert_reco_item, false, "if true, use convertor to renew reco item");
DEFINE_bool(process_sim, true, "if true, process sim");
DEFINE_bool(sim_time_offset_startofday, false, "");
DEFINE_int64(sim_time_offset, 3600, "");

static net::rpc::RpcGroup* SetupConnection(const std::string& ips, int port,
                                           int timeout, int retry) {
  std::vector<std::string> flds;
  base::SplitString(ips, ",", &flds);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = retry;
  options.timeout = timeout;
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], port, timeout);
    options.servers.push_back(si);
  }

  auto group = new net::rpc::RpcGroup(options);
  CHECK(group->Connect());
  return group;
}

SearchIndexBuilder::SearchIndexBuilder(ProducerEntityDao *producer_dao)
        : localdb_(new reco::common::LocalDB(FLAGS_index_cache_dir, FLAGS_get_item_thread_num)),
          convertor_rpc_group_(NULL),
          convertor_stub_(NULL),
          from_item_keeper_(0),
          from_local_(0),
          get_item_num_(0),
          convert_num_(0) {
  convertor_rpc_group_ = SetupConnection(FLAGS_convertor_server_ip, FLAGS_convertor_server_port, 3000, 3);
  convertor_stub_ = new reco::convertor::ConvertorService::Stub(convertor_rpc_group_);

  item_keeper_rpc_group_
          = SetupConnection(FLAGS_item_keeper_server_ip, FLAGS_item_keeper_server_port, 10000, 3);
  item_keeper_stub_ = new reco::itemkeeper::ItemKeeper::Stub(item_keeper_rpc_group_);

  // Producer white list loading
  producer_whitelist_set_.set_empty_key("");
  if (producer_dao != NULL) {
    std::vector<ProducerEntity> producer_white_list;
    producer_dao->getAllProducerWhiteList(&producer_white_list);
    for (size_t i = 0; i < producer_white_list.size(); ++i) {
      ProducerEntity& producer = producer_white_list.at(i);
      producer_whitelist_set_.insert(producer.get_name());
      LOG(INFO) << "producer white list elem : " << producer.get_name();
    }
  }
}

SearchIndexBuilder::~SearchIndexBuilder() {
  delete convertor_rpc_group_;
  delete convertor_stub_;
  delete item_keeper_rpc_group_;
  delete item_keeper_stub_;
}

void SearchIndexBuilder::GetItemThread() {
  static const size_t batch_count = 200;
  std::vector<uint64> ids_to_get;

  while (true) {
    IDTimeT id_time;
    int ret = id_time_queue_.TryTake(&id_time);
    if (-1 == ret) {        // 队列为空，且关闭
      GetFromItemKeep(ids_to_get);
      // GetFromHBase(ids_to_get);
      break;
    } else if (0 == ret) {  // 队列为空
      base::SleepForSeconds(1);
      continue;
    }

    std::string cdoc_string;
    if (GetFromLocal(id_time, &cdoc_string)) {
      if (IsBuildIndex()) {
        reco_item_queue_.Put(cdoc_string);
      }
      ++from_local_;
    } else {
      ids_to_get.push_back(id_time.first);
      if (ids_to_get.size() < batch_count) {
        continue;
      }
      GetFromItemKeep(ids_to_get);
      // GetFromHBase(ids_to_get);
      ids_to_get.clear();
    }

    if (from_item_keeper_+from_local_ > get_item_num_) {
      get_item_num_ += 10000;
      LOG(ERROR) << "from item_keeper : " << from_item_keeper_ << ", from local : " << from_local_;
    }
  }
}

void SearchIndexBuilder::GetFromItemKeep(const std::vector<uint64>& item_ids) {
  if (item_ids.empty())  return;

  reco::RecoItem reco_item;
  for (size_t idx = 0; idx < item_ids.size(); ++idx) {
    uint64 item_id = item_ids.at(idx);
    if (FLAGS_convert_reco_item) {
      reco::itemkeeper::RefreshRecoItemRequest request;
      reco::itemkeeper::RefreshRecoItemResponse response;
      request.mutable_service_identity()->set_service_name("index_builder");
      request.add_item_id(item_id);
      request.add_exclude_storages(reco::itemkeeper::kCdocQueue);

      net::rpc::RpcClientController rpc;
      item_keeper_stub_->refreshRecoItem(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()
          || response.reco_item_size() != 1) {
        LOG(ERROR) <<
        base::StringPrintf("refresh reco item failed. response error_message[%s], "
                                   "rpc status[%d], item_d[%lu]",
                           response.err_message().c_str(),
                           rpc.status(),
                           item_id);
        continue;
      } else {
        // LOG(INFO) << "done refresh reco item: " << item_id;
        reco_item.CopyFrom(response.reco_item(0));
      }
    } else {
      reco::itemkeeper::GetRecoItemRequest request;
      reco::itemkeeper::GetRecoItemResponse response;
      request.add_item_id(item_id);

      net::rpc::RpcClientController rpc;
      item_keeper_stub_->getRecoItem(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()
          || response.reco_item_size() != 1) {
        LOG(ERROR) <<
        base::StringPrintf("get reco item failed. response error_message[%s], "
                                   "rpc status[%d], item_d[%lu]",
                           response.err_message().c_str(),
                           rpc.status(),
                           item_id);
        continue;
      } else {
        // LOG(INFO) << "done get reco item: " << item_id;
        reco_item.CopyFrom(response.reco_item(0));
      }
    }
    std::string str_reco_item;
    reco_item.SerializeToString(&str_reco_item);
    if (IsBuildIndex()) {
      reco_item_queue_.Put(str_reco_item);
    }
    std::string str_item_id = base::Uint64ToString(item_id);
    PutLocal(str_item_id, str_reco_item);
    ++from_item_keeper_;
  }
}

bool SearchIndexBuilder::GetFromLocal(IDTimeT id_time, std::string* cdoc_string) {
  std::string key = base::Uint64ToString(id_time.first);
  std::string value;
  if (!localdb_->Get(key, &value)) {
    return false;
  }
  time_t time = *((time_t*)value.data());
  if (time  < id_time.second) {
    return false;
  }

  cdoc_string->assign(value.data()+sizeof(time_t), value.size()-sizeof(time_t));
  return true;
}

void SearchIndexBuilder::PutLocal(const std::string& item_id, const std::string& cdoc_string) {
  std::string value(sizeof(time_t) + cdoc_string.size(), 0);
  *((time_t*)value.data()) = base::Time::Now().ToTimeT();
  memcpy((char*)value.data()+sizeof(time_t), cdoc_string.data(), cdoc_string.size());
  if (!localdb_->Put(item_id, value)) {
    LOG(ERROR) << "leveldb put err";
  }
}

void SearchIndexBuilder::ConvertThread() {
  while (true) {
    std::string cdoc_string;
    int ret = reco_item_queue_.TryTake(&cdoc_string);
    if (-1 == ret) {        // 队列为空，且关闭
      break;
    } else if (0 == ret) {  // 队列为空
      base::SleepForSeconds(1);
      continue;
    }

    reco::RecoItem item;
    if (!item.ParseFromString(cdoc_string)) {
      LOG(ERROR) << "parse from string err";
      continue;
    }

    bool is_manual = false;
    if (item.identity().has_manual() && item.identity().manual()) {
      is_manual = true;
    }
    // producer 非空并且不在白名单里, 直接过滤
    if (!is_manual && item.identity().has_producer() && !item.identity().producer().empty() &&
        producer_whitelist_set_.find(item.identity().producer()) == producer_whitelist_set_.end()) {
      LOG(INFO) << "filtered by producer whitelist, item_id : " << item.identity().item_id()
                << " producer : " << item.identity().producer();
      continue;
    }

    Convert(item);
  }
}

void SearchIndexBuilder::Convert(reco::RecoItem& item) {
  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  std::string cdoc_string;
  
  reco::convertor::ConvertRecoItemRequest request;
  reco::convertor::ConvertRecoItemResponse response;
  request.mutable_reco_item()->CopyFrom(item);
  convertor_stub_->convertRecoItem(&rpc, &request, &response, NULL);
  rpc.Wait();

  if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
    LOG(ERROR) << "convert raw item failed" << response.err_msg();
    return;
  } else {
    if (response.cdoc().SerializeToString(&cdoc_string)) {
      thread::AutoLock lock(&mutex_);
      cdoc_strings_.push_back(cdoc_string);
    } else {
      LOG(ERROR) << "SerializeToString err";
    }
  }

  if (((int)cdoc_strings_.size()) > convert_num_) {
    convert_num_ += 10000;
    LOG(ERROR) << "convert : " << cdoc_strings_.size();
  }
}

void SearchIndexBuilder::BuildIndex() {
  uint64 total_size = 0;
  for (auto iter = cdoc_strings_.begin(); iter != cdoc_strings_.end(); ++iter) {
    total_size += iter->size();
  }
  LOG(ERROR) << "build static index ... index num : "
             << cdoc_strings_.size() << ", total_size : " << total_size;
  adsindexing::BuildStaticIndex(cdoc_strings_, FLAGS_output_index_dir);
  LOG(ERROR) << "build static index end.";
}

base::Time GetStartOfDay(const base::Time& t) {
  base::Time::Exploded exploded;
  t.LocalExplode(&exploded);
  exploded.hour = 0;
  exploded.minute = 0;
  exploded.second = 0;
  exploded.millisecond = 0;
  return base::Time::FromLocalExploded(exploded);
}


void SearchIndexBuilder::GetSimData(thread::BlockingQueue<uint64>* valid_id_queue) {
  if (!FLAGS_process_sim) {
    return;
  }

  reco::sim_lib::SimLib sim_lib(true);

  base::Time sim_start_time;
  base::Time current_time = base::Time::Now();
  if (FLAGS_sim_time_offset_startofday) {
    sim_start_time = GetStartOfDay(current_time);
  } else {
    sim_start_time = current_time - base::TimeDelta::FromSeconds(FLAGS_sim_time_offset);
  }
  int64 timestamp = (int64)(sim_start_time.ToDoubleT());
  LOG(INFO) << "sim timestamp : " << timestamp;
  sim_lib.SetSimTimestamp(timestamp);
  sim_lib.SetSimParentTimestamp(timestamp);
  sim_lib.PrepareSimDataByIds(valid_id_queue);
  sim_lib.DoDump(true);

  LOG(INFO) << "end to get sim data";
}

bool IsBuildIndex() {
  return FLAGS_run_type & 1;
}

bool IsDumpFiles() {
  return FLAGS_run_type & 2;
}
