#include <iostream>
#include <set>
#include <string>
#include <vector>

#include "reco/bizc/proto/item.pb.h"

#include "serving_base/utility/time_helper.h"
#include "base/common/scoped_ptr.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/strings/string_split.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_number_conversions.h"

#include "storage/message_queue/api/message_client_generator.h"

DEFINE_string(message_queue_servers, "10.182.2.99:2181", "message queue servers");
DEFINE_string(message_reader, "get_item_from_mq", "message reader name");
DEFINE_string(queue_read_timestamp, "", "time format  yyyy-MM-dd HH:mm:ss, if empty, not set");

DEFINE_string(raw_item_queue, "", "message queue name of raw item");
DEFINE_string(reco_item_queue, "", "message queue name of reco item");
DEFINE_string(item_id, "", "item for debug");

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "cdoc convertor server");

  CHECK(!(FLAGS_raw_item_queue.empty() && FLAGS_reco_item_queue.empty()));

  // read thead in main
  message_queue::MessageQueueOptions options(FLAGS_message_queue_servers);
  options.create_if_missing_ = false;
  scoped_ptr<message_queue::MessageClientInterface> message_queue_client(message_queue::NewClient(options));


  uint64 time = 0;
  if (!FLAGS_queue_read_timestamp.empty()) {
    CHECK(serving_base::TimeHelper::StringToTimestamp(FLAGS_queue_read_timestamp,
                                                      serving_base::TimeHelper::kSecond,
                                                      &time))
        << "invalid timestamp: " << FLAGS_queue_read_timestamp;

  }

  uint64 item_id;
  CHECK(base::StringToUint64(FLAGS_item_id, &item_id));

  std::string message;
  if (!FLAGS_raw_item_queue.empty()) {
    if (time != 0) {
      message_queue_client->SetStartTimet(FLAGS_raw_item_queue, FLAGS_message_reader, time / 1000000);
    }
    reco::RawItem item;
    while (true) {
      if (message_queue_client->Pop(FLAGS_raw_item_queue, FLAGS_message_reader, &message, 50)) {
        if (!item.ParseFromString(message)) {
          LOG(ERROR) << "failed to parse RawItem from message.";
          continue;
        }
        LOG(INFO) << "receive one item, " << item.identity().item_id();
        if (item.identity().item_id() == item_id) {
          LOG(INFO) << item.Utf8DebugString();
        }
      } else {
        base::SleepForSeconds(1);
      }
    }
  }

  if (!FLAGS_reco_item_queue.empty()) {
    if (time != 0) {
      message_queue_client->SetStartTimet(FLAGS_reco_item_queue, FLAGS_message_reader, time / 1000000);
    }
    reco::RecoItem item;
    while (true) {
      if (message_queue_client->Pop(FLAGS_reco_item_queue, FLAGS_message_reader, &message, 50)) {
        if (!item.ParseFromString(message)) {
          LOG(ERROR) << "failed to parse RawItem from message.";
          continue;
        }
        LOG(INFO) << "receive one item, " << item.identity().item_id();
        if (item.identity().item_id() == item_id) {
          LOG(INFO) << item.Utf8DebugString();
        }
      } else {
        base::SleepForSeconds(1);
      }
    }
  }

  return 0;
}
