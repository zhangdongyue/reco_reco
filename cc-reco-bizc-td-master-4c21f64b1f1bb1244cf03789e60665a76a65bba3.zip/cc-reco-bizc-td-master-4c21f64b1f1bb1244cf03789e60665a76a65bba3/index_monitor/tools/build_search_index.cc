#include <fstream>
#include <memory>
#include "ads_index/api/public.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/container/dense_hash_set.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "base/time/time.h"
#include "net/rpc_util/rpc_group.h"
#include "serving_base/mysql_util/db_conn_manager.h"

#include "reco/base/common/local_db/local_db.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/bizc/proto/reco_convertor_server.pb.h"

#include "reco/bizc/index_monitor/index_builder/dao/ProducerEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/handler/app_channel_handler.h"
#include "reco/bizc/index_monitor/index_builder/handler/source_handler.h"
#include "reco/bizc/index_monitor/tools/search_index_builder.h"

DEFINE_string(db_schema, "reco", "dbname");
DEFINE_string(db_host, "tcp://11.251.204.223:3307", "dbhost");
DEFINE_string(db_user, "recodev", "db user");
DEFINE_string(db_passwd, "tkDn19DHeVZkNA", "db pswd");
DEFINE_string(db_name, "reco", "dbname");

// SearchIndexBuilder
DEFINE_string(index_dir, "data", "output file dir");
DEFINE_string(item_ids_file, "index_item_id", "");
DEFINE_string(tb_item_info, "tb_item_info_tddl", "");

DEFINE_int32(days_from, 0, "");
DEFINE_int32(days_total, 1, "");
DEFINE_int32(max_item_num, 10000, "");
DEFINE_int32(convert_thread_num, 10, "");
DEFINE_int32(total_index_parts, 3, "total index part");
DEFINE_int32(index_part, 0, "index part index, from 0 ~ total_index_parts-1");
DEFINE_int32(run_type, 1, "0: 只获取item数据, 1: 获取item数据,convert,build static index, 2: dump other files, 3: 1 and 2");

using reco::hbase::HBasePoolIns;
using reco::hbase::HBaseAutoCli;
using namespace reco::index_builder;

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "build static index for reco item data");
  base::file_util::Delete(FLAGS_output_index_dir, true);
  base::file_util::CreateDirectory(FLAGS_output_index_dir);

  // MySQL initialize
  serving_base::mysql_util::DbConnManager::Option option;
  option.host = FLAGS_db_host;
  option.schema = FLAGS_db_schema;
  option.user = FLAGS_db_user;
  option.passwd = FLAGS_db_passwd;
  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(option);

  db_manager->ConnectUntilSuccess();
  CHECK_NOTNULL(db_manager->conn());

  // Producer white list initialization
  ProducerEntityDao producer_dao;
  producer_dao.Init(option);

  HBasePoolIns::instance().Init();

  SearchIndexBuilder builder(&producer_dao);
  thread::ThreadPool get_item_pool(FLAGS_get_item_thread_num);
  for (int i = 0; i < FLAGS_get_item_thread_num; ++i) {
    get_item_pool.AddTask(::NewCallback(&builder, &SearchIndexBuilder::GetItemThread));
  }

  thread::ThreadPool convert_pool(FLAGS_convert_thread_num);
  if (IsBuildIndex()) {
    for (int i = 0; i < FLAGS_convert_thread_num; ++i) {
      convert_pool.AddTask(::NewCallback(&builder, &SearchIndexBuilder::ConvertThread));
    }
  }

  reco::hbase::HBasePoolIns::instance().Init();

  base::Time beg_time = base::Time::Now() + base::TimeDelta::FromDays(1-FLAGS_days_from);
  base::Time::Exploded beg_exp;
  beg_time.LocalExplode(&beg_exp);

  int id_count = 0;
  base::dense_hash_set<std::string> valid_id_set;
  valid_id_set.set_empty_key("");
  thread::BlockingQueue<uint64> valid_id_queue;

  thread::Thread sim_thread;
  sim_thread.Start(::NewCallback<SearchIndexBuilder, thread::BlockingQueue<uint64>*>
                      (&builder, &SearchIndexBuilder::GetSimData, &valid_id_queue));

  for (int i = FLAGS_days_from; i < FLAGS_days_from+FLAGS_days_total
         && valid_id_set.size() <= static_cast<uint64>(FLAGS_max_item_num); ++i) {
    base::Time::Exploded end_exp = beg_exp;
    beg_time = base::Time::Now() - base::TimeDelta::FromDays(i);
    beg_time.LocalExplode(&beg_exp);
    std::string sql_str = base::StringPrintf("select item_id, last_modify_time from %s "
                                             "where is_valid=1 and create_time>='%d-%02d-%02d' "
                                             "and create_time<'%d-%02d-%02d'",
                                             FLAGS_tb_item_info.c_str(),
                                             beg_exp.year, beg_exp.month, beg_exp.day_of_month,
                                             end_exp.year, end_exp.month, end_exp.day_of_month);

    base::Time check_start = base::Time::Now();
    sql::ResultSet* dataset = db_manager->ExecuteQuery(sql_str);
    dataset->beforeFirst();

    int id_count_day = 0;
    while (dataset->next()) {
      std::string item_id_str = dataset->getString("item_id");
      std::string last_modify_time = dataset->getString("last_modify_time");

      uint64 item_id = 0;
      base::StringToUint64(item_id_str, &item_id);
      base::Time modify_time;
      if (!last_modify_time.empty()) {
        if (!base::Time::FromStringInSeconds(last_modify_time.c_str(), &modify_time)) {
          LOG(ERROR) << "Time::FromstringInSeconds err:" << last_modify_time.c_str();
        }
      }
      if (((uint32)FLAGS_index_part) == item_id % FLAGS_total_index_parts) {
        if (valid_id_set.size() > static_cast<uint64>(FLAGS_max_item_num)) {
          break;
        }
        if (valid_id_set.insert(item_id_str).second) {
          builder.IDTimeQueue().Put(std::make_pair(item_id, modify_time.ToTimeT()));
          valid_id_queue.Put(item_id);
          ++id_count_day;
        }
      }
    }

    id_count += id_count_day;
    LOG(ERROR) << "day : " << -i << " : " << id_count_day << " / " << id_count;
  }
  builder.IDTimeQueue().Close();
  valid_id_queue.Close();
  LOG(ERROR) << "get from sql total : " << id_count;

  std::shared_ptr<AppChannelHandler> app_channle_handler = std::make_shared<AppChannelHandler>(option);
  std::shared_ptr<SourceHandler> source_handler = std::make_shared<SourceHandler>(option);

  thread::ThreadPool dump_files_pool(2);
  if (IsDumpFiles()) {
      dump_files_pool.AddTask(::NewCallback(app_channle_handler.get(), &AppChannelHandler::Handle));
      dump_files_pool.AddTask(::NewCallback(source_handler.get(), &SourceHandler::Handle));
      std::ofstream ofs(FLAGS_index_dir+"/" + FLAGS_item_ids_file);
      for (auto iter = valid_id_set.begin(); iter != valid_id_set.end(); ++iter) {
        ofs << *iter << "\t1\n";
      }
      ofs.close();
  }

  sim_thread.Join();
  get_item_pool.JoinAll();
  builder.CDocQueue().Close();
  LOG(ERROR) << "get item : " << builder.from_item_keeper_ << " / " << builder.from_local_;

  convert_pool.JoinAll();
  if (IsBuildIndex()) {
    builder.BuildIndex();
  }

  dump_files_pool.JoinAll();

  LOG(ERROR) << "build index end.";
  return 0;
}
