#!/bin/bash
set -u

# 一天 dump 一份
dump_date=`date +"%Y-%m-%d"`
dump_time=`date +"%Y-%m-%d %H:%M:%S"`

root_dir=`pwd`
index_root=$root_dir/index_root
bin_dir=$root_dir/bin
data_dir=$root_dir/data
tmp_dir=$root_dir/tmp
config_dir=$root_dir/config
log_dir=$root_dir/log

# dump reco item
dump_file=$data_dir/dump_reco_item_$dump_date.data
java -jar $bin_dir/RecoInspector.jar --dumpfile $dump_file
if [ $? -ne 0 ]; then
  echo "dump reco item fail"
  exit 1
fi

# 删除老数据
index_dir=$index_root/$dump_date
if [ ! -e $index_dir ]; then
  mkdir -p $index_dir
else
  rm -rf $index_dir/*
fi

# build static index
$bin_dir/build_index --flagfile=$config_dir/index_builder.flags --input_reco_item_file=$dump_file --output_index_dir=$index_dir
if [ $? -ne 0 ]; then
  echo "build index fail"
  exit 1
fi

# write time stamp file
timestamp_file=$index_dir/dump_timestamp.dat
touch $timestamp_file
echo $dump_time > $timestamp_file

exit 0
