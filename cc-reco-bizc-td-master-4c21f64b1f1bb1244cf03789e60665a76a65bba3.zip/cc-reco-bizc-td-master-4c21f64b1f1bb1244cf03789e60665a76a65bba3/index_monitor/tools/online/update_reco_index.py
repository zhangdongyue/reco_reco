#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, commands, datetime, time
# sys.path.append("../..")
from include import gflags
from include.common import *
from include.check_md5 import *
from include.nagios import *

gflags.DEFINE_string("config_filename", "config/index_updater.flags", "config file of env");
gflags.DEFINE_string("server_list_filename", "config/machine.reco", "server list filename in env_path");
FLAGS = gflags.FLAGS

def main(argv):
  try:
    argv = FLAGS(argv)
  except gflags.FlagsError, e:
    print "%s\nUsage: %s [flags]\n%s" %(e, sys.argv[0], FLAGS);
    sys.exit(1);

  if not os.path.exists(FLAGS.config_filename):
    print "path not exist:", FLAGS.config_filename;
    print "Usage: %s [flags]\n%s" %(sys.argv[0], FLAGS);
    sys.exit(1);
  if not os.path.exists(FLAGS.server_list_filename):
    print "path not exist:", FLAGS.server_list_filename;
    print "Usage: %s [flags]\n%s" %(sys.argv[0], FLAGS);
    sys.exit(1);
  
  today_date = datetime.datetime.now().strftime("%Y-%m-%d");

  # 读取配置信息
  config = ReadConfig(FLAGS.config_filename);
  if 'index_root' not in config:
    print "index root not found in config";
    sys.exit(1);

  # 查看新 index 是否生成
  index_dir = config['index_root'] + "/" + today_date;
  index_timestamp_file = index_dir + "/dump_timestamp.dat";
  if not os.path.exists(index_dir) or not os.path.isfile(index_timestamp_file):
    print "index not found in index_root.";
    sys.exit(1);

  # 获取 index 里面每个文件的 md5
  org_index_md5_dict = GetRemoteDirMd5OrDie("127.0.0.1", index_dir);
  
  server_list = GetWolongServerList(FLAGS.server_list_filename);
  for server in server_list:
    server_ip = server[0]
    server_path = server[1]
    server_name = server[2]
    print server_ip, server_path, server_name

    # 将新的 index 更新到指定 server 指定 path 的地方
    ExecuteCommand('ssh %s "rm -rf %s/%s/new_dynamic_index/*"'
                   %(server_ip, server_path, server_name));

    ExecuteCommand('scp %s/* serving@%s:%s/%s/new_dynamic_index/'
                   %(index_dir, server_ip, server_path, server_name));

    # 检查 md5
    index_md5_dict = GetRemoteDirMd5OrDie(server_ip, server_path + "/" + server_name + "/new_dynamic_index")
    CheckMd5DictOrDie(index_md5_dict, org_index_md5_dict)

    # 替换 server 的 index，并重启 server
    ExecuteCommand('ssh %s "bash -x %s/%s/bin/update_index.sh"'
                    %(server_ip, server_path, server_name));
    time.sleep(300);

    # 关闭报警并重启
    # DisableNagios(GetHostNameByIp(server_ip), server_name);
    # print "Sleeping 180s for Nagios shutdown"
    # time.sleep(180);
    # ExecuteCommand('ssh %s "bash -x %s/%s/bin/update_dynamic_index.sh"'
    #                 %(server_ip, server_path, server_name));
    # time.sleep(300);
    # EnableNagios(GetHostNameByIp(server_ip), server_name);
  sys.exit(0);

if __name__ == "__main__":
  main(sys.argv)
