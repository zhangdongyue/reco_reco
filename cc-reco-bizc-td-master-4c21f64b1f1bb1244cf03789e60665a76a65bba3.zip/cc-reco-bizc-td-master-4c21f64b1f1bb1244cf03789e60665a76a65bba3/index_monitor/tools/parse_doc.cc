#include <iostream>
#include <fstream>
#include <algorithm>

#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"
#include "reco/bizc/proto/item.pb.h"
#include "nlp/common/nlp_util.h"
#include "base/file/memory_mapped_file.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/encoding/line_escape.h"
#include "base/file/file_util.h"

DEFINE_string(input_reco_item_file, "reco_item.data", "input reoc item dump file");
DEFINE_string(output_file, "out.txt", "output index dir");

struct DocInfo {
  std::string category;
  std::string title;
  std::string content;
};

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "build static index for reco item data");
    
  base::file_util::MemoryMappedFile file;
  CHECK(file.Initialize(FLAGS_input_reco_item_file));

  std::vector<DocInfo> docs;

  auto data = file.data();
  auto data_end = data + file.size();

  LOG(INFO) << "extract doc info start.";
  std::string category, title, content;
  reco::RecoItem reco_item;
  std::string reco_item_string;
  while (data < data_end) {
    int size = *reinterpret_cast<const int *>(data);
    data += sizeof(int);
    if (!reco_item.ParseFromArray(data, size)) {
      data += size;
      LOG(WARNING) << "parse from array fail.";
      continue;
    }
    if (!reco_item.has_raw_item()) {
      LOG(WARNING) << "reco item has no raw item.";
      continue;
    }
    const reco::RawItem& raw_item = reco_item.raw_item();
    if (raw_item.category_size() <= 0) {
      LOG(WARNING) << "raw item has no category.";
      continue;
    }
    docs.push_back(DocInfo());
    DocInfo& doc = docs.back();
    doc.category = raw_item.category(0);
    doc.title = nlp::util::NormalizeLine(raw_item.title());
    doc.content = nlp::util::NormalizeLine(raw_item.content());
    data += size;
    if (docs.size() % 10000 == 0) {
      LOG(INFO) << docs.size() << " doc finished. ";
    }
  }
  LOG(INFO) << "extract doc info finish. total doc: " << docs.size();

  LOG(INFO) << "write result start.";
  std::ofstream os(FLAGS_output_file);
  for (int i = 0; i < (int)docs.size(); ++i) {
    os << docs[i].category << "\t" << docs[i].title << "\t" << docs[i].content << std::endl;
  }
  LOG(INFO) << "write result finish.";

}

