#include <iostream>
#include <fstream>
#include <algorithm>

#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"
#include "reco/module/cdoc_convertor/convertor/raw_item_convertor.h"
#include "reco/bizc/proto/item.pb.h"

#include "ads_index/proto/index.pb.h"
#include "ads_index/api/public.h"

#include "base/file/memory_mapped_file.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/encoding/line_escape.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"
#include "serving_base/utility/signal.h"

DEFINE_string(input_reco_item_file, "reco_item.data", "input reoc item dump file");
DEFINE_string(output_index_dir, "reco_index", "output index dir");
DEFINE_string(build_index_type, "static", "index type: dynamic or static");
DEFINE_bool(convert_reco_item, false, "if true, use convertor to renew reco item");
DEFINE_int32(convert_thread_num, 16, "num of convert thread");
DEFINE_int32(estimated_doc_num, 1000000, "estimated num of doc");

DEFINE_string(hbase_ip, "100.85.69.80", "hbase ip");
DEFINE_string(hbase_item_attr_table, "tb_item_field", "hbase item attr table name");
DEFINE_int32(hbase_port, 9090, "hbase port");

void ReadWorker(thread::BlockingQueue<reco::RecoItem*>* reco_item_queue) {
  base::file_util::MemoryMappedFile file;
  CHECK(file.Initialize(FLAGS_input_reco_item_file));

  auto data = file.data();
  auto data_end = data + file.size();

  int record_num = 0;
  while (data < data_end) {
    ++record_num;
    int size = *reinterpret_cast<const int *>(data);
    data += sizeof(int);
    reco::RecoItem* reco_item = new reco::RecoItem();
    if (!reco_item->ParseFromArray(data, size)) {
      data += size;
      LOG(WARNING) << "parse from array fail.";
      delete reco_item;
      continue;
    }


    // NOTE(jianhuang) 兼容 app token 及 producer
    // is a trick
    std::string app_token;
    reco::RawItem* raw_item = reco_item->mutable_raw_item();
    const reco::ItemIdentity& item_identity = raw_item->identity();
    // if (item_identity.type() == reco::kPureVideo) {
    //   if (reco_item->create_time().compare("2016-06-03 00:00:00") < 0){
    //     data += size;
    //     LOG(INFO) << "old video item: " << item_identity.item_id() << "," << reco_item->create_time();
    //     delete reco_item;
    //     continue;
    //   }
    // }

    if (item_identity.has_producer() && !item_identity.producer().empty()) {
      app_token = item_identity.producer();
    } else if (!item_identity.app_token().empty()) {
      app_token = item_identity.app_token();
    }
    if (!app_token.empty()) {
      reco::ItemIdentity new_identity;
      new_identity.CopyFrom(item_identity);
      new_identity.set_producer(app_token);
      new_identity.set_app_token(app_token);
      raw_item->mutable_identity()->CopyFrom(new_identity);
      reco_item->mutable_identity()->CopyFrom(new_identity);
    }
    // trick end

    reco_item_queue->Put(reco_item);

    data += size;
  }
  LOG(INFO) << "read reco item finish, total record " << record_num;
  reco_item_queue->Close();
}

void ConvertWorker(int thread_id,
                   thread::BlockingQueue<reco::RecoItem*>* reco_item_queue,
                   thread::BlockingQueue<std::string>* cdoc_queue,
                   thread::BlockingVar<int>* finish_worker_num) {
  LOG(INFO) << "convert worker start, thread id: " << thread_id;
  reco::RecoItem* reco_item = NULL;
  reco::ItemCDocConvertor convertor;
  adsindexing::IndexDocInfo cdoc;
  std::string cdoc_string;
  int finish_num = 0;

  reco::RawItemConvertor* raw_item_convertor = NULL;
  if (FLAGS_convert_reco_item) {
    raw_item_convertor = new reco::RawItemConvertor(FLAGS_hbase_ip, FLAGS_hbase_port,
                                                    FLAGS_hbase_item_attr_table);
  }

  std::string org_expire_time = "";
  std::string new_expire_time = "";
  while (!reco_item_queue->Closed() || !reco_item_queue->Empty()) {
    if (reco_item_queue->Empty()) {
      base::SleepForSeconds(1);
      continue;
    }
    int status = reco_item_queue->TimedTake(10, &reco_item);

    if (status == -1) break;
    if (status == 0) continue;

    if (status != 1) {
      LOG(ERROR) << "unknown erro occured: " << status;
      continue;
    }

    org_expire_time = reco_item->has_expire_time() ? reco_item->expire_time() : "";
    scoped_ptr<reco::RecoItem> scoped_reco_item(reco_item);
    if (FLAGS_convert_reco_item) {
      reco::RecoItem new_reco_item;
      if (reco_item->has_raw_item()
          && raw_item_convertor->ConvertToRecoItem(reco_item->raw_item(), &new_reco_item)) {
        reco_item->Swap(&new_reco_item);
      } else {
        // 转化不成功，则不参与建索引
        continue;
      }
    }
    new_expire_time = reco_item->has_expire_time() ? reco_item->expire_time() : "";
    if (!org_expire_time.empty()) {
      if (new_expire_time.empty() || new_expire_time < org_expire_time) {
        LOG(INFO) << "new_expire_time < org_expire_time, " << reco_item->identity().item_id()
                  << ", " << new_expire_time << ", " << org_expire_time;
        reco_item->set_expire_time(org_expire_time);
      }
    }

    CHECK(convertor.ConvertToCDoc(*scoped_reco_item, &cdoc));

    cdoc.SerializeToString(&cdoc_string);
    cdoc_queue->Put(cdoc_string);
    if (++finish_num % 10000 == 0) {
      LOG(INFO) << finish_num << " convert finished. ";
      // LOG(INFO) << "cdoc:\n" << cdoc.Utf8DebugString();
    }
  }
  if (raw_item_convertor != NULL) delete raw_item_convertor;
  int n = finish_worker_num->Take() + 1;
  if (n == FLAGS_convert_thread_num) {
    cdoc_queue->Close();
  }
  CHECK(finish_worker_num->TryPut(n));
}

void IndexBuildWorker(thread::BlockingQueue<std::string>* cdoc_queue) {
  std::vector<std::string> cdoc_strings;
  cdoc_strings.reserve(FLAGS_estimated_doc_num);
  std::string cdoc_string;
  while (!cdoc_queue->Closed() || !cdoc_queue->Empty()) {
    if (cdoc_queue->Empty()) {
      base::SleepForSeconds(1);
      continue;
    }

    cdoc_strings.push_back("");
    int status = cdoc_queue->TimedTake(10, &cdoc_strings.back());

    if (status != 1) {
      cdoc_strings.erase(cdoc_strings.end() - 1);

      if (status == -1) break;
      
      if (status == 0) continue;

      LOG(ERROR) << "unknown erro occured: " << status;
    }
  }

  if (FLAGS_build_index_type == "static") {
    LOG(INFO) << "build static index...";
    adsindexing::BuildStaticIndex(cdoc_strings, FLAGS_output_index_dir);
    LOG(INFO) << "build static index finish.";
    return;
  }

  LOG(INFO) << "build dynamic index...";

  // TODO(jianhuang) 检索端新索引上线后:
  // 1. 去掉/dynamic_index_doc_count.
  // 2. 使用 storage/base/disk_queue.h 中 的DiskQueueWriter
  int file_max_doc_count = 1 << 13;
  std::string doc_prefix = FLAGS_output_index_dir + "/dynamic_index_doc.";
  std::string doc_count_prefix = FLAGS_output_index_dir + "/dynamic_index_doc_count.";
  // std::string doc_count_prefix = FLAGS_output_index_dir + "/dynamic_index_doc_count.";
  for (int part = 0; part * file_max_doc_count < (int)cdoc_strings.size(); ++part) {
    std::ofstream doc_output(doc_prefix + base::IntToString(part));
    std::ofstream doc_count_output(doc_count_prefix + base::IntToString(part));
    // std::ofstream doc_count_output(doc_count_prefix + base::IntToString(part));
    int part_num = std::min(file_max_doc_count, (int)cdoc_strings.size() - part * file_max_doc_count);
    for (int i = part * file_max_doc_count; i < part * file_max_doc_count + part_num; ++i) {
      std::string compression_cdoc;
      CHECK(adsindexing::GetCompressionCDoc(cdoc_strings[i], &compression_cdoc));
      int size = compression_cdoc.size();
      doc_output.write(reinterpret_cast<const char *>(&size), sizeof(int));
      doc_output.write(compression_cdoc.data(), compression_cdoc.size());
    }
    doc_count_output.write(reinterpret_cast<const char *>(&part_num), sizeof(int));
    // doc_count_output.write(reinterpret_cast<const char *>(&part_num), sizeof(int));
  }

  LOG(INFO) << "build dynamic index finish.";
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "build static index for reco item data");
  
  if (FLAGS_build_index_type != "static" && FLAGS_build_index_type != "dynamic") {
    LOG(ERROR) << "build index type should be static or dynamic .";
    return 0;
  }
   
  thread::BlockingQueue<reco::RecoItem*> reco_item_queue;
  thread::BlockingQueue<std::string> cdoc_queue;
  thread::BlockingVar<int> finish_worker_num;
  CHECK(finish_worker_num.TryPut(0));

  thread::ThreadPool pool(FLAGS_convert_thread_num + 2);
  pool.AddTask(::NewCallback(ReadWorker, &reco_item_queue));
  for (int i = 0; i < FLAGS_convert_thread_num; ++i) {
    pool.AddTask(::NewCallback(ConvertWorker, i, &reco_item_queue, &cdoc_queue, &finish_worker_num));
  }
  pool.AddTask(::NewCallback(IndexBuildWorker, &cdoc_queue));
  pool.JoinAll();
  
  LOG(INFO) << "index building stop";
  
}

