#include <iostream>
#include <fstream>
#include <algorithm>

#include "reco/module/cdoc_convertor/convertor/raw_item_convertor.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/hbase_set_item.h"
#include "reco/bizc/item_service/doc_server_set_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/bizc/proto/item.pb.h"

#include "base/file/memory_mapped_file.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/encoding/line_escape.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"
#include "serving_base/utility/signal.h"

DEFINE_string(hbase_ip, "10.99.8.40", "hbase ip");
DEFINE_int32(hbase_port, 2181, "hbase ip");
DEFINE_string(hbase_reco_item_table, "tb_test_reco_item", "doc info.");
DEFINE_string(hbase_item_attr_table, "tb_item_field", "hbase item attr table name");

DEFINE_bool(debug_mode, false, "debug mode.");

DEFINE_string(item_id_file, "item_id.txt", "item id list to build index.");

DEFINE_int32(thread_num, 8, "syn hbase data to doc server thread num.");

void UpdateWorker(int thread_id,
                  thread::BlockingQueue<std::pair<uint64, bool>>* item_queue,
                  thread::BlockingVar<int>* finish_worker_num) {

  reco::HBaseGetItem* hbase_get_item =
      new reco::HBaseGetItem(FLAGS_hbase_ip, FLAGS_hbase_port, FLAGS_hbase_reco_item_table, 0);

  reco::HBaseSetItem* hbase_set_item =
      new reco::HBaseSetItem(FLAGS_hbase_ip, FLAGS_hbase_port, FLAGS_hbase_reco_item_table);

  reco::RawItemConvertor raw_item_convertor(FLAGS_hbase_ip, FLAGS_hbase_port,
                                            FLAGS_hbase_item_attr_table);

  LOG(INFO) << "update worker start, thread id: " << thread_id;

  std::string cdoc_string;
  int finish_num = 0;
  int get_item_err_num = 0;
  int init_item_err_num = 0;
  int set_item_err_num = 0;

  std::pair<uint64, bool> item_info;
  while (!item_queue->Closed() || !item_queue->Empty()) {
    if (finish_num % 10000 == 0) {
      LOG(INFO) << "thread " << thread_id << ", " << finish_num << " syn finished. ";
    }
    ++finish_num;
    if (item_queue->Empty()) {
      base::SleepForSeconds(1);
      continue;
    }
    int status = item_queue->TimedTake(10, &item_info);
    uint64 item_id = item_info.first;
    if (status == -1) break;
    if (status == 0) continue;
    if (status != 1) {
      LOG(ERROR) << "unknown erro occured: " << status;
      continue;
    }
    reco::RecoItem reco_item;
    if (!hbase_get_item->GetRecoItem(item_id, &reco_item)) {
      LOG(WARNING) << "can't get reco item from hbase, " << item_id;
      ++get_item_err_num;
      continue;
    }
    if (!reco_item.IsInitialized()) {
      ++init_item_err_num;
      LOG(ERROR) << "reco item initialized error, " << item_id;
      continue;
    }

    reco::RecoItem new_reco_item;
    if (reco_item.has_raw_item()
        && raw_item_convertor.ConvertToRecoItem(reco_item.raw_item(), &new_reco_item)) {
      if (!hbase_set_item->SetRecoItem(new_reco_item)) {
        ++set_item_err_num;
        LOG(ERROR) << "set item to hbase, " << item_id;
        continue;
      }
    }
  }

  delete hbase_set_item;
  delete hbase_get_item;

  int n = finish_worker_num->Take() + 1;
  CHECK(finish_worker_num->TryPut(n));

  LOG(INFO) << "syn worker finish, thread id: " << thread_id
            << ", total finish: " << finish_num
            << ", doc_get_item_err_num: " << get_item_err_num
            << ", init_item_err_num: " << init_item_err_num
            << ", hbase_set_item_err_num: " << set_item_err_num;
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "build static index for reco item data");

  thread::BlockingQueue<std::pair<uint64, bool>> item_queue;
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines));
  uint64 item_id;
  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u) {
      LOG(WARNING) << "item id format error, line is: " << lines[i];
      continue;
    }
    if (!base::StringToUint64(flds[0], &item_id)) {
      LOG(WARNING) << "item id format error, line is: " << lines[i];
      continue;
    }
    bool is_valid = flds[1] == "1" ? true : false;
    item_queue.Put(std::make_pair(item_id, is_valid));
  }
  item_queue.Close();
  LOG(INFO) << "total item id num, " << item_queue.Size();

  thread::BlockingVar<int> finish_worker_num;
  CHECK(finish_worker_num.TryPut(0));

  LOG(INFO) << "syn thread num: " << FLAGS_thread_num;
  thread::ThreadPool pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(UpdateWorker, i, &item_queue, &finish_worker_num));
  }
  pool.JoinAll();

  LOG(INFO) << "syn reco item finish.";
}

