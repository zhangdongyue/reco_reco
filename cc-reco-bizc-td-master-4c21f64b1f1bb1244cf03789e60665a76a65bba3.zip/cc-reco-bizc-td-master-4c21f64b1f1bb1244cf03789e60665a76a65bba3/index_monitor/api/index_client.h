#pragma once

#include <string>
#include <map>
#include <vector>

#include "base/common/base.h"
#include "net/rpc/rpc.h"
#include "net/rpc/rpc_client_channel.h"

namespace reco {
namespace index_monitor {

class GetAttrRequest;
class GetAttrResponse;
class GetInvertedIndexRequest;
class GetInvertedIndexResponse;

struct AttrRequest {
  uint64 doc_key_sign;
  int64 int_default_value;
  std::string string_default_value;
  std::vector<std::string> int_attr_keys;
  std::vector<std::string> string_attr_keys;
  AttrRequest() : int_default_value(-1) {}
};

struct AttrResponse {
  std::map<std::string, int64> int_values;
  std::map<std::string, std::string> string_values;
  int64 GetIntValue(const std::string &key, int64 default_value) const {
    auto it = int_values.find(key);
    if (it == int_values.end()) return default_value;
    return it->second;
  }
  std::string GetStringValue(const std::string &key, const std::string &default_value) const {
    auto it = string_values.find(key);
    if (it == string_values.end()) return default_value;
    return it->second;
  }
};

// 非线程安全, 请单线程使用
class IndexClient {
 public:
  IndexClient();
  explicit IndexClient(const std::string &server_list);
  ~IndexClient();

  bool GetAttr(const AttrRequest &request, AttrResponse *response);
  bool GetAttr(const std::vector<AttrRequest> &request, std::vector<AttrResponse> *response);
  bool GetInvertedIndex(const std::string &term, std::vector<uint64> *doc_key_sign);

  bool GetAttr(const GetAttrRequest &request, GetAttrResponse *response);
  bool GetInvertedIndex(const GetInvertedIndexRequest &request, GetInvertedIndexResponse *response);
 private:
  void Initialize(const std::string &server_list);
  std::vector<net::rpc::RpcClientChannel *> channels_;
  DISALLOW_COPY_AND_ASSIGN(IndexClient);
};

}  // namespace index_monitor
}  // namespace reco
