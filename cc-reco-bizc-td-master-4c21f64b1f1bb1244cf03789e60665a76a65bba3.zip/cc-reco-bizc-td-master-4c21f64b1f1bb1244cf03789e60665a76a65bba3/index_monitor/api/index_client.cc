#include "reco/bizc/index_monitor/api/index_client.h"

#include <algorithm>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"

#include "reco/bizc/proto/index_service.pb.h"

DEFINE_string(index_monitor_server_list, "10.3.5.74:4333,10.3.5.73:7333", "index monitor server list");
DEFINE_int32(index_monitor_server_timeout, 200, "index monitor server list timeout(ms)");

namespace reco {
namespace index_monitor {

void IndexClient::Initialize(const std::string &server_list) {
  std::vector<std::string> server_strings;
  base::SplitStringWithOptions(server_list, ",", true, true, &server_strings);
  for (int i = 0; i < (int)server_strings.size(); ++i) {
    std::vector<std::string> ip_and_port;
    base::SplitStringWithOptions(server_strings[i], ":", true, true, &ip_and_port);
    CHECK_EQ(ip_and_port.size(), 2u);
    std::string ip = ip_and_port[0];
    int port = base::ParseIntOrDie(ip_and_port[1]);
    net::rpc::RpcClientChannel::Options options;
    // options.connect_timeout = FLAGS_index_monitor_server_timeout;
    // options.request_timeout = FLAGS_index_monitor_server_timeout;
    channels_.push_back(new net::rpc::RpcClientChannel(ip, port, options));
  }
}

IndexClient::IndexClient() {
  Initialize(FLAGS_index_monitor_server_list);
}

IndexClient::IndexClient(const std::string &server_list) {
  Initialize(server_list);
}

IndexClient::~IndexClient() {
  for (auto it = channels_.begin(); it != channels_.end(); ++it) {
    delete *it;
  }
}

#define SEND_REQUEST(METHOD) \
{ \
  bool success = false; \
  for (int i = 0; i < (int)channels_.size(); ++i) { \
    auto channel = channels_[i]; \
    if (!channel->IsConnected()) { \
      if (!channel->Connect())  continue; \
    } \
    IndexService::Stub index_service(channel); \
    net::rpc::RpcClientController rpc_controller; \
    rpc_controller.SetTimeout(FLAGS_index_monitor_server_timeout); \
    index_service.METHOD(&rpc_controller, &request, response, NULL); \
    rpc_controller.Wait(); \
    if (rpc_controller.GetRpcErrno() != net::rpc::kOk) continue; \
    if (i != 0) std::swap(channels_[i], channels_[0]); \
    success = true; \
    break; \
  } \
  return success; \
}

bool IndexClient::GetAttr(const GetAttrRequest &request, GetAttrResponse *response) {
  SEND_REQUEST(getAttr);
}

bool IndexClient::GetInvertedIndex(const GetInvertedIndexRequest &request,
                                   GetInvertedIndexResponse *response) {
  SEND_REQUEST(getInvertedIndex);
}

bool IndexClient::GetAttr(const AttrRequest &request, AttrResponse *response) {
  std::vector<AttrRequest> requests;
  requests.push_back(request);
  std::vector<AttrResponse> responses;
  if (!GetAttr(requests, &responses) || responses.size() != 1u) return false;
  *response = responses[0];
  return true;
}

static int64 GetIntAttr(const std::map<std::string, std::string> results, const std::string &attr,
                        int64 default_value) {
  auto it = results.find(attr);
  if (it == results.end() || it->second.size() != 8u) return default_value;
  return *(reinterpret_cast<const int64 *>(it->second.data()));
}

static std::string GetStringAttr(const std::map<std::string, std::string> results, const std::string &attr,
                                 const std::string &default_value) {
  auto it = results.find(attr);
  if (it == results.end()) return default_value;
  return it->second;
}

bool IndexClient::GetAttr(const std::vector<AttrRequest> &request, std::vector<AttrResponse> *response) {
  GetAttrRequest rpc_request;
  GetAttrResponse rpc_response;
  for (auto rit = request.begin(); rit != request.end(); ++rit) {
    for (auto kit = rit->int_attr_keys.begin(); kit != rit->int_attr_keys.end(); ++kit) {
      auto attr = rpc_request.add_attr();
      attr->set_key_sign(rit->doc_key_sign);
      attr->set_attr_key(*kit);
      attr->set_default_attr(std::string(reinterpret_cast<const char *>(&(rit->int_default_value)), 8));
    }
    for (auto kit = rit->string_attr_keys.begin(); kit != rit->string_attr_keys.end(); ++kit) {
      auto attr = rpc_request.add_attr();
      attr->set_key_sign(rit->doc_key_sign);
      attr->set_attr_key(*kit);
      attr->set_default_attr(rit->string_default_value);
    }
  }
  if (!GetAttr(rpc_request, &rpc_response) || rpc_request.attr_size() != rpc_response.attr_size()) {
    return false;
  }

  std::map<uint64, std::map<std::string, std::string> > results;
  for (int i = 0; i < rpc_request.attr_size(); ++i) {
    results[rpc_request.attr(i).key_sign()][rpc_request.attr(i).attr_key()] = rpc_response.attr(i);
  }

  response->clear();
  for (auto rit = request.begin(); rit != request.end(); ++rit) {
    response->push_back(AttrResponse());
    auto &res = response->back();
    for (auto kit = rit->int_attr_keys.begin(); kit != rit->int_attr_keys.end(); ++kit) {
      res.int_values[*kit] = GetIntAttr(results[rit->doc_key_sign], *kit, rit->int_default_value);
    }
    for (auto kit = rit->string_attr_keys.begin(); kit != rit->string_attr_keys.end(); ++kit) {
      res.string_values[*kit] = GetStringAttr(results[rit->doc_key_sign], *kit, rit->string_default_value);
    }
  }
  return true;
}

bool IndexClient::GetInvertedIndex(const std::string &term, std::vector<uint64> *doc_key_sign) {
  GetInvertedIndexRequest rpc_request;
  GetInvertedIndexResponse rpc_response;
  rpc_request.set_term(term);
  if (!GetInvertedIndex(rpc_request, &rpc_response)) return false;
  doc_key_sign->clear();
  for (int i = 0; i < rpc_response.key_sign_size(); ++i) {
    doc_key_sign->push_back(rpc_response.key_sign(i));
  }
  return true;
}

}  // namespace index_monitor
}  // namespace wolong
