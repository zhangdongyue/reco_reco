#pragma once

#include <cstdatomic>
#include <string>
#include <unordered_set>

#include "base/common/sleep.h"
#include "base/thread/thread_pool.h"
#include "net/rpc/rpc.h"
#include "net/web_server/web_server.h"

#include "reco/base/kafka_c/api_cc/consumer.h"

namespace adsindexing {
class Index;
}  // namespace adsindexing

namespace reco {

namespace index_monitor {

class IndexWebService;
class IndexServiceImpl;

class IndexMonitor {
 public:
  IndexMonitor();
  ~IndexMonitor();
  // 启动服务
  void Start();
  // 停止服务
  void Stop();
  // 等待服务停止
  void WaitForStop() { while (!stop_) base::SleepForMilliseconds(1000); }
  // 返回 index, 给 bidword server 和 ad server 使用
  adsindexing::Index *GetIndex() { return index_; }

 private:
  // 更新 counter
  void UpdateCounter();
  // cdoc 增量线程, 负责从消息队列获取 cdoc 添加到索引
  void AddCDocThread();
  // 初始化 kafka
  bool InitItemKafka(const int64 timestamp_s);

 private:
  thread::ThreadPool loop_thread_pool_;
  std::atomic_bool stop_;
  std::atomic_bool add_cdoc_thread_stop_;
  std::unordered_set<std::string> app_set_;

  adsindexing::Index *index_;
  std::atomic_int min_index_local_id_;

  int64 index_dump_timestamp_;

  reco::kafka::Consumer* cdoc_consumer_;

  std::string cdoc_queue_name_;
  std::string cdoc_reader_name_;
};

}  // namespace index_monitor
}  // namespace reco
