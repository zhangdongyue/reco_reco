#include "reco/bizc/index_monitor/api/index_monitor.h"

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

#include "base/common/gflags.h"
#include "base/common/basic_types.h"
#include "base/time/timestamp.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/hash_function/city.h"

#include "reco/bizc/proto/item.pb.h"

#include "ads_index/proto/index.pb.h"
#include "ads_index/api/public.h"
#include "ads_index/dynamic_index/dynamic_index.h"
#include "ads_index/forward_index/cdoc_compression.h"
#include "ads_index/mix_index/mix_index.h"

#include "serving_base/utility/system_util.h"
#include "serving_base/utility/time_helper.h"

DEFINE_string(index_dir, "reco/bizc/index_monitor/test_data", "index dir");
DEFINE_int32(index_type, 1, "0 means static index, 1 means dynamic index");
DEFINE_int32(dynamic_unigram_num_bits, 24, "max bits of unigram number");
DEFINE_int32(dynamic_bigram_num_bits, 24, "max bits of unigram number");
DEFINE_int32(dynamic_doc_num_bits, 24, "max bits of unigram number");
DEFINE_string(static_dict_filename, "ads_index/api/data/static_dict.dat", "static dict path");
// XXX(lintao):
// 在线服务时, 动态索引有可能占用很大的内存, 析构的时候会耗费大量时间, 这个操作没有必要
// 这里设置一个标志位, 如果为 false, 我们在退出时不对 index 进行析构, 节省退出时间
DEFINE_bool(delete_index_monitor_dynamic_index, true, "if delete dynamic index, when quit");

DEFINE_int32(cluster_mode, 0, "0:single server, 1:cluster server(distributed search)");
DEFINE_int32(cluster_index_size, -1, "auto generate");
DEFINE_int32(cluster_index_id, -1, "auto generate");

DEFINE_string(cdoc_queue_name, "reco::test::cdoc", "");

// kafka
DEFINE_string(item_kafka_brokers, "127.0.0.1:9092,127.0.0.1:9092", "item kafka server");
DEFINE_string(item_kafka_group_id, "online_leaf_cdoc_reader", "");
DEFINE_string(cdoc_item_kafka_topic, "test_cdoc_item", "");
DEFINE_int32(cdoc_item_kafka_partition, 32, "");

DEFINE_int64_counter(reco_index, build_cdoc_num, 0, "cdoc number of index");
DEFINE_int64_counter(reco_index, kafka_cdoc_consume, 0, "");

namespace reco {
namespace index_monitor {

IndexMonitor::IndexMonitor() : loop_thread_pool_(2), stop_(false),
                               add_cdoc_thread_stop_(true), cdoc_consumer_(NULL) {
  // loading index
  index_dump_timestamp_ = 0;
  LOG(INFO) << "index loading.....";
  ::google::FlushLogFiles(::google::INFO);

  if (FLAGS_index_type == 0) {
    index_ = adsindexing::Index::LoadFrom(FLAGS_index_dir);
  } else {
    adsindexing::DynamicIndexOptions options;
    options.unigram_num_bits = FLAGS_dynamic_unigram_num_bits;
    options.bigram_num_bits = FLAGS_dynamic_bigram_num_bits;
    options.doc_num_bits = FLAGS_dynamic_doc_num_bits;
    options.history_dir = FLAGS_index_dir;
    options.static_dict_filename = FLAGS_static_dict_filename;

    // NOTE(lintao):
    // 我们需要把消息队列的读取位置重置到某个 timestamp 之后来追增量
    std::string timestamp_file = options.history_dir + "/dump_timestamp.dat";
    if (base::file_util::PathExists(timestamp_file)) {
      base::file_util::MemoryMappedFile mapped_file;
      CHECK(mapped_file.Initialize(timestamp_file)) << "mapped timestamp file failed: " << timestamp_file;
      // NOTE(lintao): 支持两种格式
      // 1. 2 进制格式
      // 2. 可读格式
      uint64 index_timestamp = 0;
      if (mapped_file.size() == 8) {
        index_timestamp = *reinterpret_cast<const int64 *>(mapped_file.data());
      } else {
        std::vector<std::string> lines;
        base::file_util::ReadFileToLines(timestamp_file, &lines);
        CHECK(lines.size()) << "invalid dump file: " << timestamp_file;
        CHECK(serving_base::TimeHelper::StringToTimestamp(lines[0],
                                                          serving_base::TimeHelper::kSecond,
                                                          &index_timestamp))
            << "invalid dump timestamp: " << lines[0];
      }

      CHECK(InitItemKafka(index_timestamp / 1000000));
    }

    // NOTE(lintao):
    // 1. 如果有静态索引文件, 我们 load 混合索引
    // 2. 如果没有静态索引文件, 我们 load 纯动态索引
    std::string key_sign_dict_file = FLAGS_index_dir + "/key_sign_dict.dat";
    if (base::file_util::PathExists(key_sign_dict_file)) {
      index_ = new adsindexing::MixIndex(FLAGS_index_dir, options);
    } else {
      index_ = new adsindexing::DynamicIndex(options);
    }
  }
  CHECK(index_);

  // counter
  min_index_local_id_ = index_->MaxDocLocalId();
  UpdateCounter();

  LOG(INFO) << "index loaded.";
  ::google::FlushLogFiles(::google::INFO);
}

bool IndexMonitor::InitItemKafka(const int64 timestamp_s) {
  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_cdoc_item_kafka_topic;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = FLAGS_item_kafka_group_id;
  options.partition_num = FLAGS_cdoc_item_kafka_partition;
  options.start_timestamp = timestamp_s;
  cdoc_consumer_ = new reco::kafka::Consumer(FLAGS_item_kafka_brokers, options);
  CHECK_NOTNULL(cdoc_consumer_);

  // CHECK(cdoc_consumer_->ResetTopicStartTime(timestamp_s));
  LOG(INFO) << "cdoc consumer start time:" << timestamp_s;
  ::google::FlushLogFiles(::google::INFO);

  return true;
}

void IndexMonitor::Start() {
  stop_ = false;

  // add cdoc thread
  if (index_->IndexType() == "dynamic" || index_->IndexType() == "mix") {
    loop_thread_pool_.AddTask(NewCallback(this, &IndexMonitor::AddCDocThread));
  }
}

IndexMonitor::~IndexMonitor() {
  Stop();

  loop_thread_pool_.JoinAll();
  LOG(INFO) << "index monitor server stop";
  ::google::FlushLogFiles(::google::INFO);

  if (cdoc_consumer_) {
    delete cdoc_consumer_;
    cdoc_consumer_ = NULL;
  }

  if (index_->IndexType() != "dynamic" || FLAGS_delete_index_monitor_dynamic_index) {
    delete index_;
    LOG(INFO) << "index monitor index delete";
    ::google::FlushLogFiles(::google::INFO);
  } else {
    LOG(INFO) << "index monitor quit without deleting index";
    ::google::FlushLogFiles(::google::INFO);
  }
}

void IndexMonitor::UpdateCounter() {
  while (min_index_local_id_ > index_->MinDocLocalId()) {
    --min_index_local_id_;
    auto doc_info = index_->GetDocInfo(min_index_local_id_);
    CHECK(doc_info);
    COUNTERS_reco_index__build_cdoc_num.Increase(1);
  }
}

void IndexMonitor::AddCDocThread() {
  add_cdoc_thread_stop_ = false;
  std::string serialized_reco_cdoc;
  std::vector<std::string> compressed_cdocs;
  reco::kafka::Message msg;
  reco::RecoCDoc reco_cdoc;

  while (!stop_) {
    // NOTE(lintao):
    // 每 1 分钟打一个时间戳: 时间为读取到的消息到时间戳
    if (base::GetTimestamp() - index_dump_timestamp_ > 1000000L * 60) {
      int retry = 3;
      bool write_success = false;
      while (!write_success && retry-- > 0) {
        index_dump_timestamp_ = base::GetTimestamp();
        const std::string timestamp_file = FLAGS_index_dir + "/" + "dump_timestamp.dat";
        std::string data;
        if (serving_base::TimeHelper::TimestampToString(
                index_dump_timestamp_, serving_base::TimeHelper::kSecond, &data)) {
          const std::string new_file = timestamp_file + ".new";
          if (base::file_util::WriteFile(new_file, const_cast<char*>(data.data()),
                                         data.size()) == (int)data.size()) {
            if (base::file_util::Move(new_file, timestamp_file)) {
              write_success = true;
            }
          }
        }
      }
      if (!write_success) {
        LOG(WARNING) << "dump_timestamp.dat write failed.";
      }
    }  // if (base::GetTimestamp() - index_dump_timestamp_ > 1000000L * 60)

    // init
    serialized_reco_cdoc.clear();
    compressed_cdocs.clear();
    msg.Clear();
    reco_cdoc.Clear();

    if (!cdoc_consumer_->Consume(&msg)) {
      base::SleepForSeconds(2);
      continue;
    } else {
      serialized_reco_cdoc = msg.content;
      COUNTERS_reco_index__kafka_cdoc_consume.Increase(1);
      VLOG(2) << "prt:" << msg.partition << ", off:" << msg.offset
              << ", key:" << msg.key << ", time:" << msg.timestamp_ms;
    }

    if (reco_cdoc.ParseFromString(serialized_reco_cdoc)) {
      adsindexing::IndexDocInfo ads_cdoc;
      adsindexing::CDocCompressor cdoc_cmp(reco_cdoc.cdoc().c_str(), reco_cdoc.cdoc().size());
      if (!cdoc_cmp.Succeed() || !cdoc_cmp.ToCDoc(&ads_cdoc)) {
        LOG(ERROR) << "failed to parse IndexDocInfo.";
        continue;
      }

      const uint64* item_id = reinterpret_cast<const uint64*>(ads_cdoc.key().c_str());
      if (FLAGS_cluster_mode == 1
          && (*item_id % FLAGS_cluster_index_size) != (uint64)FLAGS_cluster_index_id) {
        continue;
      }

      VLOG(2) << "cdoc add item id:" << *item_id;
      compressed_cdocs.push_back(reco_cdoc.cdoc());
      if (!index_->AddCDocs(0, compressed_cdocs)) {
        LOG(ERROR) << "add cdocs to index failed: " << serialized_reco_cdoc;
      }
      UpdateCounter();
    } else {
      LOG(ERROR) << "failed to parse RecoCDoc: " << serialized_reco_cdoc;
    }
  }

  add_cdoc_thread_stop_ = true;
}

void IndexMonitor::Stop() {
  stop_ = true;
  while (!add_cdoc_thread_stop_) base::SleepForMilliseconds(100);
}

}  // namespace index_monitor
}  // namespace reco
