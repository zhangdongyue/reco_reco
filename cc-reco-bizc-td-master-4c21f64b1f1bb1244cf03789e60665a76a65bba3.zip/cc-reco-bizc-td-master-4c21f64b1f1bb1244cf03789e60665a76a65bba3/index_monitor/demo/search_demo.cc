#include <unistd.h>

#include <algorithm>
#include <fstream>
#include <string>
#include <queue>
#include <vector>
#include <math.h>
#include <unordered_set>
#include <unordered_map>


#include "reco/bizc/index_monitor/api/index_monitor.h"

#include "ads_index/api/public.h"
#include "ads_index/proto/index.pb.h"

#include "base/common/scoped_ptr.h"
#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/testing/gtest.h"

#include "nlp/common/nlp_util.h"
#include "serving_base/utility/signal.h"

// DEFINE_string(index_dir, "reco/bizc/index_monitor/test_data", "");

template<class T>
class TopN {
 public:
  TopN(int heap_size) : kHeapSize(heap_size) {}
  ~TopN() {} 

  void add(const T elem, double score) {
    topn_.push(std::make_pair(score, elem));
    if ((int)topn_.size() > kHeapSize) {
      topn_.pop();
    }
  }

  void get_top_n(std::vector<T>* list, bool descend) {
    list->clear();
    list->reserve(kHeapSize);
    while (!topn_.empty()) {
      const T elem = topn_.top().second;
      list->push_back(elem);
      topn_.pop();
    }
    if (descend) {
      std::reverse(list->begin(), list->end());
    }
  }

 private:
  std::priority_queue<std::pair<double, T>,
      std::vector<std::pair<double, T> >,
      std::greater<std::pair<double, T> > > topn_;
  const int kHeapSize;
};

void DoSearch(const std::string& term, adsindexing::Index* index);

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "cdoc convertor server");

  // scoped_ptr<adsindexing::Index> index;
  // index.reset(adsindexing::Index::LoadFrom(FLAGS_index_dir));
  reco::index_monitor::IndexMonitor monitor;
  monitor.Start();

  LOG(INFO) << "index loaded";
  //adsindexing::Index* index = monitor.GetIndex();

  serving_base::SignalCatcher::Initialize();
  std::string line;
  while (serving_base::SignalCatcher::GetSignal() < 0) {
    LOG(INFO) << "wait for input";
    line.clear();
    std::getline(std::cin, line);
    LOG(INFO) << "search for: " + line;
    DoSearch(line, monitor.GetIndex());
  }
}

void DoSearch(const std::string& term, adsindexing::Index* index) {
  scoped_ptr<adsindexing::DocIterator> doc_iter(index->NewDocIterator(term, adsindexing::kUnigramTerm));
  if (doc_iter.get() == NULL) {
    LOG(INFO) << "no doc hit term " + term;
    return;
  }

  LOG(INFO) << "doc size: " << doc_iter->GetSize();
  TopN<int32> topn(3);
  while (!doc_iter->Done()) {
    topn.add(doc_iter->GetDocLocalId(), doc_iter->GetPayload());
    doc_iter->Next();
  }

  std::vector<int32> docs;
  topn.get_top_n(&docs, true);
  for (size_t i = 0; i < docs.size(); ++i) {
    scoped_ptr<adsindexing::HitIterator> hit(index->NewHitIterator(docs[i]));
    std::vector<adsindexing::HitIterator::DocArea> areas = hit->GetAllDocArea();
    for (size_t i = 0; i < areas.size(); ++i) {
      const adsindexing::HitIterator::DocArea& area = areas[i];
      if (area.type != adsindexing::kTitleArea) {
        continue;
      }
      std::vector<std::string> unigrams;
      hit->GetRawUnigrams(area.begin, area.end, index, &unigrams);
      LOG(INFO) << base::JoinStrings(unigrams, "");
    }
  }
}


//  typedef std::priority_queue<std::pair<double, const recommending::ItemInfo*>,
//      std::vector<std::pair<double, const recommending::ItemInfo*> >
//          , std::greater<std::pair<double, const recommending::ItemInfo*> > > TopN;
//  TopN topn;
//  for (int i = 0; i < (int)candidates->size(); ++i) {
//    const recommending::ItemInfo* item = index->GetItemById((*candidates)[i].item_id);
//    
//    if (item == NULL || !item->is_valid()) {
//      continue;
//    }
//    // if (shown_dict_.find(item->item_id()) != shown_dict_.end()) {
//    //   continue;
//    // }
//
//    if (item->item_type() == recommending::kCoolpadAd &&
//        IsAdFilter(item)) {
//      continue;
//    }
//
//    // compute item 
//    std::vector<std::string> flds;
//    double weight = 0;
//    if (item->has_ad() && item->ad().has_keyword()) {
//      base::SplitString(item->ad().keyword(), " ,", &flds);
//      if (flds.size() == 0) {
//        weight = 0;
//      } else {
//        for (int kindex = 0; kindex < (int)flds.size(); kindex++) {
//          if (interests_map.count(flds[kindex]) > 0) {
//            // assume he keyword related to doc is 0.2
//            // because the keyword here is editd by human
//            weight += interests_map[flds[kindex]] * 0.2;
//          }
//        }
//      }
//    }
//
//    for (int kindex = 0; kindex < (int)item->keywords_size(); kindex++) {
//      if (interests_map.count(item->keywords(kindex).literal()) > 0) {
//        weight += interests_map[item->keywords(kindex).literal()] * item->keywords(kindex).weight();
//      }
//    }
//    // end
//    VLOG(5) << "item_id:" << item->item_id()
//              << " weight:" << weight;
//
//    topn.push(std::make_pair(weight, item));
//    if ((int)topn.size() > kTopNSize) {
//      topn.pop();
//    }
//  }
//  reco_list->clear();
//  while (!topn.empty()) {
//    const recommending::ItemInfo* p_item = topn.top().second;
//    reco_list->push_back(DiversityInfo(p_item));
//    topn.pop();
//  }
//




