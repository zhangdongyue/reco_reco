#include <unistd.h>

#include <algorithm>
#include <fstream>

#include "reco/bizc/index_monitor/rpc/index_service_impl.h"
#include "reco/bizc/index_monitor/api/index_monitor.h"
#include "reco/bizc/proto/index_service.pb.h"

#include "ads_index/api/public.h"
#include "ads_index/proto/index.pb.h"
#include "base/common/scoped_ptr.h"
#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/testing/gtest.h"

#include "nlp/common/nlp_util.h"

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "cdoc convertor server");

  reco::index_monitor::IndexMonitor monitor;
  monitor.Start();

  LOG(INFO) << "index monitor started";
  adsindexing::Index* index = monitor.GetIndex();
  index->LogStatus();
  int32 doc_num = index->GetDocNum();
  // wait for add cdoc from queue done
  do {
    doc_num = index->GetDocNum();
    base::SleepForSeconds(10);
  } while (doc_num != index->GetDocNum());

  LOG(INFO) << "done add cdoc";
  for (int doc_id = index->MinDocLocalId(); doc_id < index->MaxDocLocalId(); ++doc_id) {
    scoped_ptr<adsindexing::HitIterator> hit(index->NewHitIterator(doc_id));
    const adsindexing::DocInfo* doc_info = index->GetDocInfo(doc_id);
    if (doc_info == NULL) {
      LOG(ERROR) << "null docinfo for doc: " << doc_id;
      continue;
    }
    
    std::vector<adsindexing::HitIterator::DocArea> areas = hit->GetAllDocArea();
    for (size_t i = 0; i < areas.size(); ++i) {
      const adsindexing::HitIterator::DocArea& area = areas[i];
      if (area.type != adsindexing::kTitleArea) {
        continue;
      }
      std::vector<std::string> unigrams;
      hit->GetRawUnigrams(area.begin, area.end, index, &unigrams);
      std::cout << doc_info->key_sign << "\t" << base::JoinStrings(unigrams, "") << std::endl;
      
      // adsindexing::HitIterator::TermDocFeature term_doc_feature;
      // for (int pos = area.begin; pos < area.end; ++pos) {
      //   hit->MoveToPosition(pos);
      //   if (!hit->GetTermDocFeature(&term_doc_feature)) {
      //   } else {
      //     LOG(ERROR) << "get term doc featrue for: " << hit->UnigramId();
      //   }
      // }
    }
    delete doc_info;
  }
}

