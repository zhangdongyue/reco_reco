//
// Created by allen.fw on 2017/10/12.
//

#include <fstream>
#include "reco/bizc/index_monitor/index_builder/handler/app_channel_handler.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "reco/bizc/proto/index_aux_data.pb.h"

namespace reco {
namespace index_builder {

DEFINE_string(app_channel_file, "appchannel_info.data", "app channel file name");

AppChannelHandler::AppChannelHandler(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  app_channel_dao_.Init(db_option);
  handler_name_ = "app_channel_handler";
}

AppChannelHandler::~AppChannelHandler() {
}

void AppChannelHandler::Handle() {
  LOG(INFO) << "start handleAppChannel";
  std::vector<AppChannelEntity> channel_list;
  app_channel_dao_.getChannels(&channel_list);
  std::vector<reco::index_data::AppChannelData> data_list;
  for (size_t i = 0; i < channel_list.size(); ++i) {
    AppChannelEntity &entity = channel_list.at(i);
    reco::index_data::AppChannelData data;
    data.set_channel_id(entity.get_channel_id());
    data.set_id(entity.get_id());
    if (!entity.get_appname().empty()) {
      data.set_appname(entity.get_appname());
    }
    if (!entity.get_name().empty()) {
      data.set_name(entity.get_name());
    }
    data.set_is_default(entity.get_is_default());
    data.set_is_fixed(entity.get_is_fixed());
    data.set_seq(entity.get_seq());
    data.set_status(entity.get_status());
    data.set_op_mark(entity.get_op_mark());
    if (!entity.get_op_mark_name().empty()) {
      data.set_op_mark_name(entity.get_op_mark_name());
    }
    if (!entity.get_opmark_online_time().is_null()) {
      std::string time_str;
      entity.get_opmark_online_time().ToStringInMilliseconds(&time_str);
      data.set_opmark_online_time(time_str);
    }
    if (!entity.get_opmark_expired_time().is_null()) {
      std::string time_str;
      entity.get_opmark_expired_time().ToStringInMilliseconds(&time_str);
      data.set_opmark_expired_time(time_str);
    }
    if (!entity.get_android_ve().empty()) {
      data.set_android_ve(entity.get_android_ve());
    }
    if (!entity.get_ios_ve().empty()) {
      data.set_ios_ve(entity.get_ios_ve());
    }
    data.set_is_not_publish(entity.get_is_not_publish());
    if (!entity.get_modify_time().is_null()) {
      std::string time_str;
      entity.get_modify_time().ToStringInMilliseconds(&time_str);
      data.set_modify_time(time_str);
    }
    if (!entity.get_create_time().is_null()) {
      std::string time_str;
      entity.get_create_time().ToStringInMilliseconds(&time_str);
      data.set_create_time(time_str);
    }
    data.set_publish_strategy(entity.get_publish_strategy());
    data_list.push_back(data);
  }

  // dump data_list to file
  std::string file_path = FLAGS_index_dir + "/" + FLAGS_app_channel_file;
  std::ofstream output(file_path);
  int size = 0;
  char buffer[4096];
  std::string app_str;
  for (size_t i = 0; i < data_list.size(); ++i) {
    size = data_list.at(i).ByteSize();
    CHECK(data_list.at(i).SerializeToArray(&buffer, size));
    output.write(reinterpret_cast<const char *>(&size), sizeof(size));
    output.write(buffer, size);
  }
  output.close();
  LOG(INFO) << "end handleAppChannel";
}
}
}
