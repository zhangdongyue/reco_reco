//
// Created by allen.fw on 2017/10/12.
//

#include <fstream>
#include "reco/bizc/index_monitor/index_builder/handler/source_handler.h"
#include "reco/bizc/proto/index_aux_data.pb.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

DEFINE_string(source_file, "source_info.data", "source file name");
DEFINE_string(wemedia_key_prefix, "wemedia:", "wemeida key prefix");
DEFINE_string(wemedia_field, "follow", "wemedia field");
DEFINE_string(discounter_server_ip, "11.251.203.132,11.251.203.173,11.251.203.212,11.251.203.223,"
        "11.251.204.16,11.251.204.51,11.251.204.109,11.251.204.140", "server ip");
DEFINE_int32(discounter_server_port, 20051, "server port");

SourceHandler::SourceHandler(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  seed_source_dao_.Init(db_option);
  seed_block_rule_dao_.Init(db_option);

  LOG(INFO) << "start init discounter_rpc";
  discounter_rpc_group_ = SetupConnection(FLAGS_discounter_server_ip, FLAGS_discounter_server_port,
                                          10000, -1);
  discounter_rpc_stub_ = new reco::discounterserver::DisCounterService::Stub(discounter_rpc_group_);
  LOG(INFO) << "finish init discounter_rpc";

  handler_name_ = "source_handler";
}

SourceHandler::~SourceHandler() {
  if (discounter_rpc_group_ != NULL) {
    delete discounter_rpc_group_;
  }
  if (discounter_rpc_stub_ != NULL) {
    delete discounter_rpc_stub_;
  }
}

void SourceHandler::Handle() {
  LOG(INFO) << "start handleSource";
  int wemediaCnt = 0;
  std::vector <SeedEntity> seed_list;
  seed_source_dao_.getAllSeedList(&seed_list);
  std::vector <reco::index_data::SourceInfo> source_list;
  LOG(INFO) << "seed list size: " << seed_list.size();
  for (size_t i = 0; i < seed_list.size(); ++i) {
    SeedEntity &entity = seed_list.at(i);
    reco::index_data::SourceInfo data;
    SeedDevConfig *dev = entity.getSeedDevConfig();
    if (dev != NULL) {
      std::string show_name = dev->get_seed_show_name();
      entity.set_show_name(show_name);
    }
    data.set_source(entity.get_name());
    data.set_publish_state(entity.get_publish_status());
    data.set_site_level(entity.get_authority_score());
    data.set_politics_sensitivity(entity.get_politics_sensitivity());
    data.set_sex_sensitivity(entity.get_sex_sensitivity());
    if (!entity.get_show_name().empty()) {
      data.set_show_source(entity.get_show_name());
    } else {
      data.set_show_source(entity.get_name());
    }
    std::string prefix = "cp_wemedia_uc";
    if (entity.get_name().substr(0, prefix.size()) == prefix && !entity.get_seed_icon_remark().empty()) {
      std::string wemediakey = FLAGS_wemedia_key_prefix + entity.get_seed_icon_remark();
      std::string wemediafield = FLAGS_wemedia_field;
      int follow_count = getDiscounterValueByKeyAndField(wemediakey, wemediafield);
      data.set_follow_cnt(follow_count);
      data.set_show_source(entity.get_seed_icon_remark());
      ++wemediaCnt;
      data.set_is_wemedia(true);
      LOG(INFO) << entity.get_seed_icon_remark() << " : " << follow_count;
    } else {
      data.set_is_wemedia(false);
    }

    // get seed block rules
    std::vector <SeedBlockRuleEntity> rule_list;
    seed_block_rule_dao_.getBySeedId(entity.get_id(), &rule_list);
    for (size_t j = 0; j < rule_list.size(); ++j) {
      reco::index_data::SourceBlockRule *block = data.add_rules();
      CHECK_NOTNULL(block);
      SeedBlockRuleEntity &rule = rule_list.at(j);
      if (rule.get_block_main_city() == 1) {
        block->set_block_main_city(true);
      }
      if (!rule.get_app_name().empty()) {
        block->set_app_name(rule.get_app_name());
      }
      if (!rule.get_os().empty()) {
        block->set_os(rule.get_os());
      }
    }
    source_list.push_back(data);
    if (i % 1000 == 0) {
      LOG(INFO) << i << " seed id finish.";
    }
  }
  LOG(INFO) << "total " << source_list.size() << " sources, wemedia sources " << wemediaCnt;

  // dump source_list to file
  std::string file_path = FLAGS_index_dir + "/" + FLAGS_source_file;
  std::ofstream output(file_path);
  int size = 0;
  char buffer[4096];
  for (size_t i = 0; i < source_list.size(); ++i) {
    size = source_list.at(i).ByteSize();
    CHECK(source_list.at(i).SerializeToArray(&buffer, size));
    output.write(reinterpret_cast<const char *>(&size), sizeof(size));
    output.write(buffer, size);
  }
  output.close();
  LOG(INFO) << "end handleSource";
}

int SourceHandler::getDiscounterValueByKeyAndField(std::string key, std::string field) {
  int ret = 0;
  net::rpc::RpcClientController controller;
  reco::discounterserver::EntityCounterRequest request;
  reco::discounterserver::EntityCounterResponse response;

  controller.SetTimeout(30000);

  request.add_keys(key);
  request.add_bins(field);

  discounter_rpc_stub_->getEntity(&controller, &request, &response, NULL);
  controller.TimedWait(30000);
  if (controller.status() != stumy::RpcController::kOk) {
    LOG(WARNING) << "get response from discounter server fail";
    return ret;
  }
  if (response.entity_size() > 0 &&
      response.entity(0).bin_size() > 0) {
    ret = response.entity(0).bin(0).value();
  }
  return ret;
}
}
}
