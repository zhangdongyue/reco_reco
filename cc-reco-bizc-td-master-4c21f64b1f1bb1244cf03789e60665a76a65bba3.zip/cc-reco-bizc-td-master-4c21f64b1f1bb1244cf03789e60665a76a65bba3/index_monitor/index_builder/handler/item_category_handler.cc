//
// Created by allen.fw on 2017/10/12.
//

#include <fstream>
#include "reco/bizc/index_monitor/index_builder/handler/item_category_handler.h"
#include "reco/bizc/proto/index_aux_data.pb.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

DEFINE_string(item_category_file, "", "item category file");
DEFINE_int32(item_category_dump_days, 60, "item category dump days");

ItemCategoryHandler::ItemCategoryHandler(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  item_info_category_dao_.Init(db_option);
  handler_name_ = "item_category_handler";
}

ItemCategoryHandler::~ItemCategoryHandler() {
}

void ItemCategoryHandler::Handle() {
  if (FLAGS_item_category_file.empty()) return;

  LOG(INFO) << "begin to get item category from db.";
  std::vector<ItemInfoEntity> items;
  base::Time start_date = base::Time::Now() - base::TimeDelta::FromDays(FLAGS_item_category_dump_days);
  std::string str_start_date;
  start_date.ToStringInSeconds(&str_start_date);
  item_info_category_dao_.getValidItemsInRange(str_start_date, "", &items);
  LOG(INFO) << "succ to get item category from db, total num: " << items.size();

  std::string file_path = FLAGS_index_dir + "/" + FLAGS_item_category_file;
  std::ofstream os(file_path);
  std::vector<std::string> flds;
  for (size_t idx = 0; idx < items.size(); ++idx) {
    const ItemInfoEntity& item = items.at(idx);
    if (item.get_category().empty()) continue;
    flds.clear();
    base::SplitString(item.get_category(), ",", &flds);
    if (flds.size() == 2) {
      os << base::StringPrintf("%s\t%s\t%s\n", item.get_item_id().c_str(), flds[0].c_str(), flds[1].c_str());
    } else if (flds.size() == 1) {
      os << base::StringPrintf("%s\t%s\n", item.get_item_id().c_str(), flds[0].c_str());
    } else {
      continue;
    }
  }
  os.close();
  LOG(INFO) << "succ to write item category to disk, total num: " << items.size();
}
}
}
