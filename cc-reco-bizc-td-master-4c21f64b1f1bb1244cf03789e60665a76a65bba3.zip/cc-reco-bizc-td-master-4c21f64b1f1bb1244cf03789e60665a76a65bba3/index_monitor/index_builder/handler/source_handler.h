//
// Created by allen.fw on 2017/10/12.
//

#pragma once

#include <string>
#include <vector>
#include "reco/bizc/proto/dis_counter.pb.h"
#include "reco/bizc/index_monitor/index_builder/dao/SeedEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/dao/SeedBlockRuleEntityDao.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/index_monitor/index_builder/handler/base_handler.h"

namespace reco {
namespace index_builder {

class SourceHandler : public BaseHandler {
 public:
  explicit SourceHandler(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~SourceHandler();

  virtual void Handle();

 private:
  int getDiscounterValueByKeyAndField(std::string key, std::string field);

 private:
  SeedEntityDao seed_source_dao_;
  SeedBlockRuleEntityDao seed_block_rule_dao_;
  net::rpc::RpcGroup* discounter_rpc_group_;
  reco::discounterserver::DisCounterService::Stub* discounter_rpc_stub_;
};
}
}
