//
// Created by allen.fw on 2017/10/12.
//

#pragma once

#include <string>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/dao/ItemInfoEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/handler/base_handler.h"

namespace reco {
namespace index_builder {

class ItemCategoryHandler : public BaseHandler {
 public:
  explicit ItemCategoryHandler(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~ItemCategoryHandler();

  virtual void Handle();

 private:
  ItemInfoEntityDao item_info_category_dao_;
};
}
}
