//
// Created by allen.fw on 2017/10/31.
//

#pragma once

#include <string>
#include "serving_base/mysql_util/db_conn_manager.h"

namespace reco {
namespace index_builder {

class BaseHandler {
 public:
  virtual ~BaseHandler() {}

  virtual void Handle() = 0;

  const std::string& GetHandlerName() {
    return handler_name_;
  }

 protected:
  std::string handler_name_;
};
}
}
