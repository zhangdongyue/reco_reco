#ifndef PRODUCERENTITY_H
#define PRODUCERENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct ProducerEntity {
 public:
  ProducerEntity() 
  : name_("") {}

  ~ProducerEntity() {}

  bool check_valid() {
    if (name_.empty()) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "name : ";
    out += name_;
    out += "\n";
    return out;
  }

 private:
  // producer 名称
  // 非空
  DEF_FIELD(std::string, name);
};

#endif
