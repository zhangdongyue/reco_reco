#ifndef CHANNELENTITY_H
#define CHANNELENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct ChannelEntity {
 public:
  ChannelEntity()
  : id_(0),
  name_(""),
  iflow_name_(""),
  is_default_(true),
  is_fixed_(false),
  status_(0),
  iflow_status_(0),
  pub_type_(0),
  auto_machine_(0),
  min_len_(0),
  max_len_(0),
  keywords_(""),
  iflow_op_mark_(""),
  seq_(0),
  iflow_seq_(0),
  start_version_("1.0.0.0"),
  type_(0),
  info_(""),
  show_type_(0),
  is_private_(false),
  image_(""),
  description_() {
    modify_time_ = base::Time::Now();
    create_time_ = base::Time::Now();
  }

  bool check_valid() {
    if (id_ == 0) {
      return false;
    }
    if (name_.empty()) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "id : ";
    out += base::Uint64ToString(id_);
    out += "\t";
    out += "name : ";
    out += name_;
    out += "\n";
    return out;
  }

 private:
  // 
  DEF_FIELD(uint64, id);
  // 频道名
  DEF_FIELD(std::string, name);
  // 喜刷刷频道名
  DEF_FIELD(std::string, iflow_name);
  // 默认添加
  DEF_FIELD(bool, is_default);
  // 固定
  DEF_FIELD(bool, is_fixed);
  // 上线下线 0正常，1已下线
  DEF_FIELD(int, status);
  // iflow上线下线
  DEF_FIELD(int, iflow_status);
  // 发布状态， 0不下发机器新闻，不返回给客户端
  DEF_FIELD(int, pub_type);
  // 机器新闻
  DEF_FIELD(int, auto_machine);
  // 标题最小长度
  DEF_FIELD(int, min_len);
  // 标题最大长度
  DEF_FIELD(int, max_len);
  // 过滤
  DEF_FIELD(std::string, keywords);
  // iflow频道角标
  DEF_FIELD(std::string, iflow_op_mark);
  // 顺序号
  DEF_FIELD(int, seq);
  // iflow顺序号
  DEF_FIELD(int, iflow_seq);
  // 修改时间
  DEF_FIELD(base::Time, modify_time);
  // 创建时间
  DEF_FIELD(base::Time, create_time);
  // 
  DEF_FIELD(std::string, start_version);
  // 频道类型，0-普通，1-推荐，2-热点 ，3-普通不下发推荐新闻
  DEF_FIELD(int, type);
  // 组成(二级分类集合)
  DEF_FIELD(std::string, info);
  // 展示类型
  DEF_FIELD(int, show_type);
  // 是否我们内部的私有频道，0:不是私有（客户端可见），1:是私有（客户端不可见）
  DEF_FIELD(bool, is_private);
  // 
  DEF_FIELD(std::string, image);
  // 
  DEF_FIELD(std::string, description);
};

#endif
