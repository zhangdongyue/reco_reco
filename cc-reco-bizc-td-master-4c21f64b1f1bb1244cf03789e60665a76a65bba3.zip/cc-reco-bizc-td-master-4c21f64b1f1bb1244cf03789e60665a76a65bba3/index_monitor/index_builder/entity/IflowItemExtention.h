#ifndef IFLOWITEMEXTENTION_H
#define IFLOWITEMEXTENTION_H

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"

struct IflowItemExtention {
 public:
  IflowItemExtention() 
  : upCnt_(0),
  treadCnt_(0),
  shareCnt_(0) {}
 private:
  DEF_FIELD(int, upCnt);
  DEF_FIELD(int, treadCnt);
  DEF_FIELD(int, shareCnt);
};

#endif
