#ifndef SUPERBITEMENTITY_H
#define SUPERBITEMENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct SuperbItemEntity {
 public:
  SuperbItemEntity() 
  :id_(0),
  item_id_("") {}

  bool check_valid() {
    if (id_ == 0) {
      return false;
    }
    if (item_id_.empty()) {
      return false;
    }
  }

  std::string to_string() {
    std::string out;
    out += "id : ";
    out += base::Uint64ToString(id_);
    out += "\t";
    out += "item_id : ";
    out += item_id_;
    out += "\n";
    return out;
  }

 private:
  // 
  DEF_FIELD(uint64, id);
  // 
  DEF_FIELD(std::string, item_id);
};

#endif
