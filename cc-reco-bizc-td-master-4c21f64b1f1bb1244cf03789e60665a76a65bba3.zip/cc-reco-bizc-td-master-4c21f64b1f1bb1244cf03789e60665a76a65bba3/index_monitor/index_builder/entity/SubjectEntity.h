#ifndef SUBJECTENTITY_H
#define SUBJECTENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct SubjectEntity {
 public:
  SubjectEntity()
  : item_id_("") {}

  ~SubjectEntity() {}

  bool check_valid() {
    if (item_id_.empty()) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "item_id : ";
    out += item_id_;
    out += "\n";
    return out;
  }

 private:
  // item_id
  // 非空
  DEF_FIELD(std::string, item_id);
};

#endif
