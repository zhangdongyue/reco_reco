#ifndef SEEDBLOCKRULEENTITY_H
#define SEEDBLOCKRULEENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct SeedBlockRuleEntity {
 public:
  SeedBlockRuleEntity() 
  : id_(0),
  seed_id_(0),
  os_(""),
  block_main_city_(0),
  app_name_(""),
  remark_(""),
  oper_("") {}

  bool check_valid() {
    if (id_ == 0) {
      return false;
    }
    if (seed_id_ == 0) {
      return false;
    }
    if (oper_.empty()) {
      return false;
    }
    if (operate_time_.is_null()) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "id : ";
    out += base::Uint64ToString(id_);
    out += "\t";
    out += "seed_id : ";
    out += base::Uint64ToString(seed_id_);;
    out += "\t";
    out += "os : ";
    out += os_;
    out += "\t";
    out += "app_name : ";
    out += app_name_;
    out += "\t";
    out += "operator : ";
    out += oper_;
    out += "\t";
    out += "block_main_city : ";
    out += base::IntToString(block_main_city_);
    out += "\t";
    std::string time;
    operate_time_.ToStringInMilliseconds(&time);
    out += "operate_time : ";
    out += time;
    out += "\n";
    return out;
  }

 private:
  // rule id
  // 非空
  DEF_FIELD(uint64, id);
  // 种子 id
  // 非空
  DEF_FIELD(uint64, seed_id);
  // 操作系统平台，值：android,ios
  DEF_FIELD(std::string, os);
  // 是否在一线城市禁止, 0：不禁止, 1：禁止
  DEF_FIELD(int, block_main_city);
  // 渠道名, 值:uc-iflow,ucnews-iflow,huawei-iflow, 
  // 策略端可能会将其它小渠道映射到这几个大渠道上
  DEF_FIELD(std::string, app_name);
  // 运营备注
  DEF_FIELD(std::string, remark);
  // 最后操作人
  DEF_FIELD(std::string, oper);
  // 最后操作时间
  DEF_FIELD(base::Time, operate_time);
};


#endif
