#ifndef IFLOWITEMENTITY_H
#define IFLOWITEMENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "reco/bizc/index_monitor/index_builder/entity/ItemInfoEntity.h"
#include "reco/bizc/index_monitor/index_builder/entity/IflowItemExtention.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct IflowItemEntity {
 public:
  IflowItemEntity() 
  :id_(0),
  item_id_(""),
  copy_id_(""),
  iflow_order_(0),
  operation_type_(0),
  daoliu_type_(0),
  style_type_(0),
  is_published_(0),
  publish_type_(0),
  is_banner_(0),
  is_deleted_(0),
  publisher_(""),
  is_full_deliver_(0),
  channel_id_(0),
  title_(""),
  channel_name_(""),
  oper_src_area_(0),
  extention_data_(""),
  operator_(""),
  is_special_sub_item_(0),
  banner_status_(0),
  appnames_(""),
  producer_("") {
    last_modify_time_ = base::Time::Now();
  }

  bool check_valid() {
    if (id_ == 0) {
      return false;
    }
    if (item_id_.empty()) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "id : ";
    out += base::Uint64ToString(id_);
    out += "\t";
    out += "item_id : ";
    out += item_id_;
    out += "\n";

    return out;
  }

 private:
  // 自增ID
  DEF_FIELD(uint64, id);
  // 
  DEF_FIELD(std::string, item_id);
  // 
  DEF_FIELD(std::string, copy_id);
  // 位置次序
  DEF_FIELD(int, iflow_order);
  // 运营类型
  DEF_FIELD(int, operation_type);
  // 导流模式
  DEF_FIELD(int, daoliu_type);
  // 列表样式类型
  DEF_FIELD(int, style_type);
  // 是否发布：0:未发布,1:已发布
  // 组合生效时间，有附加状态：未生效，已失效
  DEF_FIELD(int, is_published);
  // 发布状态前端显示字段
  // 1=未发布 2=定时发布 3=已发布 4=已过期
  DEF_FIELD(int, publish_type);
  // 是否置顶,0:不置顶，1:置顶
  DEF_FIELD(int, is_banner);
  // 生效的开始时间
  DEF_FIELD(base::Time, start_time);
  // 生效的结束时间
  DEF_FIELD(base::Time, end_time);
  // 是否删除：0:未删除,1:已删除
  DEF_FIELD(int, is_deleted);
  // 删除时间
  DEF_FIELD(base::Time, delete_time);
  // 发布时间
  DEF_FIELD(base::Time, publish_time);
  // 
  DEF_FIELD(std::string, publisher);
  // 是否是全量维度
  DEF_FIELD(int, is_full_deliver);
  // 所属频道 和tb_item_channel 表的数据做冗余，为了查询方便
  DEF_FIELD(uint64, channel_id);
  // 标题
  DEF_FIELD(std::string, title);
  // 
  DEF_FIELD(std::string, channel_name);
  // 运营区标识
  DEF_FIELD(int, oper_src_area);
  // 扩展数据，不用于检索
  DEF_FIELD(std::string, extention_data);
  // 最后操作人
  DEF_FIELD(std::string, operator);
  // 专题子文章标志位
  DEF_FIELD(int, is_special_sub_item);
  // 保存置顶状态 1=等待置顶 2=正在置顶 3=过期
  DEF_FIELD(int, banner_status);
  // 
  DEF_FIELD(base::Time, last_modify_time);
  // 渠道
  DEF_FIELD(std::string, appnames);
  // 
  DEF_FIELD(std::string, producer);
  // 
  DEF_FIELD(ItemInfoEntity, item_info);
  // 
  DEF_FIELD(IflowItemExtention, item_extention);
};

#endif
