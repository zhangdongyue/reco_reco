#ifndef CHANNELSEEDENTITY_H
#define CHANNELSEEDENTITY_H

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct ChannelSeedEntity {
 public:
  ChannelSeedEntity() 
  :id_(0),
  channel_id_(0),
  seed_id_(0),
  is_valid_(-1){
    create_time_ = base::Time::Now();
  }

  bool check_valid() {
    if (id_ == 0) {
      return false;
    }
    if (channel_id_ == 0) {
      return false;
    }
    if (seed_id_ == 0) {
      return false;
    }
    if (is_valid_ == -1) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "id : ";
    out += base::Uint64ToString(id_);
    out += "\t";
    out += "channel_id : ";
    out += base::Uint64ToString(channel_id_);
    out += "\t";
    out += "seed_id : ";
    out += base::Uint64ToString(seed_id_);
    out += "\t";
    out += "is_valid : ";
    out += base::IntToString(is_valid_);
    out += "\n";
    
    return out;
  }

 private:
  // 自增 id
  DEF_FIELD(uint64, id);
  // 频道id，外键依赖到频道表
  DEF_FIELD(uint64, channel_id);
  // 种子 id，外键依赖到种子表
  DEF_FIELD(uint64, seed_id);
  // 该种子在此频道下是否有效
  // 0：不下发
  // 1：下发
  DEF_FIELD(int, is_valid);
  // 绑定时间
  DEF_FIELD(base::Time, create_time);
};

#endif
