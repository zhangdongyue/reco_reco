#ifndef SEEDDEVCONFIG_H
#define SEEDDEVCONFIG_H

#include <string>
#include <vector>
#include <map>
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"

struct SeedDevConfig {
 public:
  explicit SeedDevConfig(std::string devconfig) {
    std::vector<std::string> lines;
    base::SplitString(devconfig, "`", &lines);
    auto iter = lines.begin();
    for (; iter != lines.end(); ++iter) {
      std::string line = *iter;
      base::TrimWhitespaces(&line);
      // # 开头为注释
      if (line.size() == 0 || line.at(0) == '#') {
        continue;
      }
      // 第一个=号分割 key/value
      size_t pos = line.find_first_of('=');
      if (pos == std::string::npos) {
        continue;
      }
      std::string key = line.substr(0, pos);
      std::string value = line.substr(pos + 1, line.length());
      base::TrimWhitespaces(&key);
      base::TrimWhitespaces(&value);
      if (base::LowerCaseEquals(key, "user_agent")) {
        user_agent_ = value;
      }
      if (base::LowerCaseEquals(key, "match_pattern")) {
        match_pattern_ = value;
      }
      if (base::LowerCaseEquals(key, "replacement")) {
        replacement_ = value;
      }
      if (base::LowerCaseEquals(key, "cookie")) {
        cookie_ = value;
      }
      if (base::LowerCaseEquals(key, "star_name")) {
        star_name_ = value;
      }
      if (base::LowerCaseEquals(key, "star_logo")) {
        star_logo_ = value;
      }
      if (base::LowerCaseEquals(key, "js_engine")) {
        js_engine_ = value;
      }
      if (base::LowerCaseEquals(key, "t_show_source")) {
        seed_show_name_ = value;
      }
      if (key.find_first_of("t_") == 0) {
        content_feature_map.insert(std::make_pair(key, value));
      }
    }
  }
  DEF_FIELD(std::string, user_agent);
  DEF_FIELD(std::string, match_pattern);
  DEF_FIELD(std::string, replacement);
  DEF_FIELD(std::string, cookie);
  DEF_FIELD(std::string, star_name);
  DEF_FIELD(std::string, star_logo);
  DEF_FIELD(std::string, js_engine);
  DEF_FIELD(std::string, seed_show_name);
 public:
  std::map<std::string, std::string> content_feature_map;

};

#endif
