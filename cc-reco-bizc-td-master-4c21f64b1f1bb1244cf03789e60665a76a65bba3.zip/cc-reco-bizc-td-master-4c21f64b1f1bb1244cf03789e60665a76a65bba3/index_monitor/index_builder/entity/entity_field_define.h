#ifndef ENTITY_FIELD_DEFINE_H
#define ENTITY_FIELD_DEFINE_H

#define DEF_FIELD(field_type, field_name) \
  private:\
  field_type field_name##_; \
  public:\
  inline field_type get_##field_name() const { \
    return field_name##_;\
  } \
  inline void set_##field_name(field_type& name) { \
    field_name##_ = name; \
  } \


#include "base/common/basic_types.h"

#endif
