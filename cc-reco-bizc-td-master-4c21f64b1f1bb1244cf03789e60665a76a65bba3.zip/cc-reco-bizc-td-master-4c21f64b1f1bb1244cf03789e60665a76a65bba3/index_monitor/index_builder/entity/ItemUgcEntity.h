#ifndef ITEMUGCENTITY_H
#define ITEMUGCENTITY_H

#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct ItemUgcEntity {
 public:
  ItemUgcEntity()
      :id_(0),
      item_id_(""),
      score_(0.0),
      version_(0){}

  bool check_valid() {
    if (item_id_.empty()) {
      return false;
    }
    return true;
  }


  std::string to_string() {
    std::string out;
    out += "id : ";
    out += base::Uint64ToString(id_);
    out += "\t";
    out += "item_id : ";
    out += item_id_;
    out += "\t";
    out += "score : ";
    out += "\t";
    out += "create_time : ";
    std::string create_time;
    create_time_.ToStringInFormat("yyyy-mm-dd",&create_time);
    out += create_time;
    out += "\t";
    out += "version : ";
    out += base::IntToString(version_);
    out += "\n";
    return out;
  }

 private:
  // auto crement id
  DEF_FIELD(uint64, id);
  // item id
  DEF_FIELD(std::string, item_id);
  // Score of sorting.
  DEF_FIELD(double, score);
  // Time of creating.
  DEF_FIELD(base::Time, create_time);
  // Time of modifying.
  DEF_FIELD(base::Time, modify_time);
  // Algorithm version
  DEF_FIELD(int32, version);
};

#endif
