#ifndef ITEMCHANNELENTITY_H
#define ITEMCHANNELENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct ItemChannelEntity {
 public:
  ItemChannelEntity()
  :id_(0),
  item_id_(""),
  channel_id_(0),
  priority_(0),
  publish_time_(""),
  item_type_(0),
  item_type_setter_(0),
  is_web_view_(false),
  outer_id_("") {}

  bool check_valid() {
    if (id_ == 0) {
      return false;
    }
    if (item_id_.empty()) {
      return false;
    }
    if (channel_id_ == 0) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "id : ";
    out += base::Uint64ToString(id_);
    out += "\t";
    out += "item_id : ";
    out += item_id_;
    out += "\t";
    out += "channel_id : ";
    out += base::Uint64ToString(channel_id_);;
    out += "\t";
    out += "priority : ";
    out += base::IntToString(priority_);
    out += "\t";
    out += "item_type : ";
    out += base::IntToString(item_type_);
    out += "\t";
    out += "item_type_setter : ";
    out += base::IntToString(item_type_setter_);
    out += "\n";
    return out;
  }

 private:
  // 自增 id
  // 非空
  DEF_FIELD(uint64, id);
  // 新闻id, 外键依赖到新闻纪录表
  // 非空
  DEF_FIELD(std::string, item_id);
  // 频道id
  // 非空
  DEF_FIELD(uint64, channel_id);
  // 优先级, 0普通新闻, 值越大优先级越高
  // 非空
  DEF_FIELD(int, priority);
  // 优先下发开始时间
  DEF_FIELD(base::Time, start_time);
  // 优先下发结束时间
  DEF_FIELD(base::Time, end_time);
  // 文章发布时间
  DEF_FIELD(std::string, publish_time);
  // item_info : item_type
  DEF_FIELD(int, item_type);
  // item_info : item_type_setter
  DEF_FIELD(int, item_type_setter);
  //todo:迁移到item_info的is_key_item
  DEF_FIELD(bool, is_web_view);
  //todo:迁移到item_info的group_id
  DEF_FIELD(std::string, outer_id);
};

#endif
