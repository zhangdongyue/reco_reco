#ifndef SEEDENTITY_H
#define SEEDENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/SeedDevConfig.h"
#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct SeedEntity {
 public:
  SeedEntity() 
  : id_(0),
  name_(""),
  url_(""),
  seed_type_(0),
  host_(""),
  associated_site_(""),
  render_type_(0),
  link_render_type_(0),
  period_(300),
  scope_(0),
  days_(10000),
  white_list_(""),
  black_list_(""),
  authority_score_(1),
  politics_sensitivity_(1),
  sex_sensitivity_(1),
  display_type_(0),
  data_type_(0),
  item_type_(0),
  crawl_status_(0),
  publish_status_(0),
  remark_(""),
  filter_list_(""),
  path_(""),
  source_type_(10),
  city_code_(""),
  dev_config_(""),
  creator_(""),
  seed_icon_type_(0),
  seed_icon_img_url_(""),
  seed_icon_img_width_(0),
  seed_icon_img_height_(0),
  seed_icon_remark_(""),
  seed_icon_desc_(""),
  is_seed_icon_url_valid_(0),
  seed_icon_url_(""),
  seed_stage_(0),
  logic_delete_(0),
  qualify_status_(0),
  show_name_(""),
  config(NULL) {
    create_time_ = base::Time::Now();
    last_modify_time_ = base::Time::Now();
  }

  ~SeedEntity() {
    if (config != NULL) {
      delete config;
    }
  }

  bool check_valid() {
    if (id_ == 0) {
      return false;
    }
    if (name_.empty()) {
      return false;
    }
    if (url_.empty()) {
      return false;
    }
    if (create_time_.is_null()) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "id : ";
    out += base::Uint64ToString(id_);
    out += "\t";
    out += "name : ";
    out += name_;
    out += "\t";
    std::string time;
    create_time_.ToStringInMilliseconds(&time);
    out += "create_time : ";
    out += time;
    out += "\t";
    out += "url : ";
    out += url_;
    out += "\t";
    out += "dev_config : ";
    out += dev_config_;
    out += "\t";
    out += "crawl_status : ";
    out += base::IntToString(crawl_status_);
    out += "\t";
    out += "publish_status : ";
    out += base::IntToString(publish_status_);
    out += "\t";
    out += "authority_score : ";
    out += base::IntToString(authority_score_);
    out += "\t";
    out += "politics_sensitivity : ";
    out += base::IntToString(politics_sensitivity_);
    out += "\t";
    out += "sex_sensitivity : ";
    out += base::IntToString(sex_sensitivity_);
    out += "\t";
    out += "seed_icon_remark : ";
    out += seed_icon_remark_;
    out += "\n";
    return out;
  }

 private:
  // 种子 id
  // 非空
  DEF_FIELD(uint64, id);
  // 种子名
  // 非空
  DEF_FIELD(std::string, name);
  // 种子页 url
  // 非空
  // 唯一
  DEF_FIELD(std::string, url);
  // 种子类型
  // 非空
  DEF_FIELD(int, seed_type);
  // 种子页域名
  DEF_FIELD(std::string, host);
  // 关联站点
  DEF_FIELD(std::string, associated_site);
  // 页面解析方式 0:普通网页解析, 1:js解析
  // 非空
  DEF_FIELD(int, render_type);
  // 链接页面解析方式 0:普通网页解析, 1:js解析
  DEF_FIELD(int, link_render_type);
  // 抓取频度, 单位:分钟
  DEF_FIELD(int, period);
  // 抓取范围,0:所有,1:站内,2:域内
  // 非空
  DEF_FIELD(int, scope);
  // 有效天数
  DEF_FIELD(int, days);
  // 白名单, 支持正则, 多个的形式是:(正则1)|(正则2)
  DEF_FIELD(std::string, white_list);
  // 黑名单, 支持正则, 多个的形式是:(正则1)|(正则2) 
  DEF_FIELD(std::string, black_list);
  // 权威性得分
  // 0,1,2,3 ===> 低,中,高,极高
  // 默认为1
  DEF_FIELD(int, authority_score);
  // 敏感度
  // 0,1,2 ===> 低,中,高
  // 默认为1
  DEF_FIELD(int, politics_sensitivity);
  // 两性敏感度
  DEF_FIELD(int, sex_sensitivity);
  // 展示方式, 0:全文展示，1：web_view，2：导流方式
  // 非空
  DEF_FIELD(int, display_type);
  // 展现数据类型, 0:普通图文，1：图集， 2:Js图集
  // 非空
  DEF_FIELD(int, data_type);
  // 内容类型 会影响推荐策略
  // 非空
  DEF_FIELD(int, item_type);
  // 状态 ，0：启动抓取，1：停止抓取
  // 非空
  DEF_FIELD(int, crawl_status);
  // 下发状态 ，0：下发，1：不下发
  // 非空
  DEF_FIELD(int, publish_status);
  // 备注
  DEF_FIELD(std::string, remark);
  // 过滤规则，多个的形式是：正则1`正则2
  DEF_FIELD(std::string, filter_list);
  // 链接的位置路径，如：xpath
  DEF_FIELD(std::string, path);
  // 来源类型 (第1位代表数据格式，第2位代表其它标识), 
  // 10：html不带内容 ，11：html带内容，20:Json不带内容，21:Json带内容, 30:Xml不带内容,
  // 31:Xml带内容
  DEF_FIELD(int, source_type);
  // 城市代码，对应高德数据
  DEF_FIELD(std::string, city_code);
  // 创建时间
  // 非空
  DEF_FIELD(base::Time, create_time);
  // 最后修改时间
  DEF_FIELD(base::Time, last_modify_time);

  DEF_FIELD(std::string, dev_config);
  // 创建者
  DEF_FIELD(std::string, creator);
  // 种子图标类型
  DEF_FIELD(int, seed_icon_type);
  // 种子图标图片
  DEF_FIELD(std::string, seed_icon_img_url);
  // 种子图标图片宽
  DEF_FIELD(int, seed_icon_img_width);
  // 种子图标图片高
  DEF_FIELD(int, seed_icon_img_height);
  // 种子图标文案
  DEF_FIELD(std::string, seed_icon_remark);
  // 种子图标简介
  DEF_FIELD(std::string, seed_icon_desc);
  // 种子图标url是否下发
  DEF_FIELD(int, is_seed_icon_url_valid);
  // 种子图标跳转url
  DEF_FIELD(std::string, seed_icon_url);
  // 种子运营阶段
  // 非空
  DEF_FIELD(int, seed_stage);
  // 灰度完成时间
  DEF_FIELD(base::Time, alpha_finish_time);
  // 删除标记
  // 非空
  DEF_FIELD(int, logic_delete);
  // 合格状态
  // 非空
  // 0:不合格,1:合格 
  DEF_FIELD(int, qualify_status);
  // 显示名
  DEF_FIELD(std::string, show_name);
 public:
  // 
  SeedDevConfig* config;
  // 频道id
  std::vector<uint64> channel_ids;
  SeedDevConfig* getSeedDevConfig() {
    if (dev_config_.empty()) {
      return NULL;
    }
    if (config == NULL) {
      config = new SeedDevConfig(dev_config_);
    }
    return config;
  }

};

#endif
