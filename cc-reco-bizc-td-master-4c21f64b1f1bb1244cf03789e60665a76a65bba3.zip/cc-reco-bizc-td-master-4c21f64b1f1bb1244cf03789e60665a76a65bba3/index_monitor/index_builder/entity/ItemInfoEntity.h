#ifndef ITEMINFOENTITY_H
#define ITEMINFOENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"


struct ItemInfoEntity {
 public:
  ItemInfoEntity() 
  :id_(0),
  parent_id_(""),
  app_token_("uc"),
  producer_(""),
  item_id_(""),
  item_type_(0),
  is_manual_news_(false),
  is_web_view_(false),
  is_dao_liu_(false),
  channel_id_(0),
  source_(""),
  orig_source_(""),
  category_(""),
  title_(""),
  url_(""),
  create_operator_(""),
  last_modify_operator_(""),
  original_id_(""),
  priority_(0),
  is_valid_(1),
  attribute_(""),
  only_crawl_(0),
  item_type_setter_(0) {}

  bool check_valid() {
    if (id_ == 0) {
      return false;
    }
    if (item_id_.empty()) {
      return false;
    }
    if (source_.empty()) {
      return false;
    }
    if (orig_source_.empty()) {
      return false;
    }
    if (category_.empty()) {
      return false;
    }
    if (title_.empty()) {
      return false;
    }
    if (url_.empty()) {
      return false;
    }
    if (publish_time_.is_null()) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "id : ";
    out += base::Uint64ToString(id_);
    out += "\t";
    out += "item_id : ";
    out += item_id_;
    out += "\t";
    out += "item_type : ";
    out += base::IntToString(item_type_);
    out += "\n";
    return out;
  }

 private:
  // 自增 id
  DEF_FIELD(uint64, id);
  // parentId 用来表示相似文章之间的关系。
  // 一个相似文章的集合由sim server指定一个主文章，集合内其他文章的parent_id
  // 指向主文章的item_id，主文章的parent_id指向自己的item_id.
  DEF_FIELD(std::string, parent_id);
  // app识别码
  DEF_FIELD(std::string, app_token);
  // 内容生产者
  DEF_FIELD(std::string, producer);
  // 此id不对外暴露
  DEF_FIELD(std::string, item_id);
  // 内容类型
  DEF_FIELD(int, item_type);
  // 是否是运营产生的新闻, false 是爬虫抓取的新闻
  DEF_FIELD(bool, is_manual_news);
  // 是否以 webView 方式展示
  DEF_FIELD(bool, is_web_view);
  // 否以 daoliu 方式展示
  DEF_FIELD(bool, is_dao_liu);
  // 频道Id
  DEF_FIELD(uint64, channel_id);
  // 来源 (种子页) 
  DEF_FIELD(std::string, source);
  // 来源 (正文页)
  DEF_FIELD(std::string, orig_source);
  // 类别 以后 类别 ！= 频道
  DEF_FIELD(std::string, category);
  // 标题
  DEF_FIELD(std::string, title);
  // url
  DEF_FIELD(std::string, url);
  // 创建时间: 对运营新闻是新闻提交的时间； 对爬虫新闻，是新闻被抓取的时间
  DEF_FIELD(base::Time, create_time);
  // 最后修改时间
  DEF_FIELD(base::Time, last_modify_time);
  // 创建者
  DEF_FIELD(std::string, create_operator);
  // 最后修改者
  DEF_FIELD(std::string, last_modify_operator);
  // (运营新闻)对应原始机器新闻的 outer ID
  DEF_FIELD(std::string, original_id);
  // 优先级, 0 普通新闻， 值越大表面优先级越高，可以通过不同的值pk不同新闻的展现顺序
  DEF_FIELD(int, priority);
  // 原始新闻的发布时间
  DEF_FIELD(base::Time, publish_time);
  // 是否下发新闻
  DEF_FIELD(int, is_valid);
  // 新闻属性
  DEF_FIELD(std::string, attribute);
  // 是否是只抓取，不下发的新闻
  // 0: 抓取且下发, 1: 只抓取建库， 不下发
  DEF_FIELD(int, only_crawl);
  // item type 的设置方： 0: 继承种子设置 1: 爬虫自动判断 2：其他（后续运营可以修改）
  DEF_FIELD(int, item_type_setter);
};

#endif
