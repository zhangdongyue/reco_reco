#ifndef JINGPINITEMENTITY_H
#define JINGPINITEMENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct JingpinItemEntity {
 public:
  JingpinItemEntity() 
  :id_(0),
  item_id_(""),
  item_type_(0),
  produced_by_(0),
  source_(""),
  category_(""),
  title_(""),
  score_(0),
  status_(0),
  score_reviewed_(-1),
  review_comment_(""),
  item_fea_info_("{}"),
  oper_(""),
  channel_id_(""),
  orig_source_("") {}

  bool check_valid() {
    if (id_ == 0) {
      return false;
    }
    if (item_id_.empty()) {
      return false;
    }
    if (create_time_.is_null()) {
      return false;
    }
    if (source_.empty()) {
      return false;
    }
    if (category_.empty()) {
      return false;
    }
    if (title_.empty()) {
      return false;
    }
    if (import_time_.is_null()) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "id : ";
    out += base::Uint64ToString(id_);
    out += "\t";
    out += "item_id : ";
    out += item_id_;
    out += "\n";
    return out;
  }

 private:
  // 
  DEF_FIELD(uint64, id);
  // 
  DEF_FIELD(std::string, item_id);
  // 创建时间: 对运营新闻是新闻提交的时间； 对爬虫新闻，是新闻被抓取的时间
  DEF_FIELD(base::Time, create_time);
  // 内容类型
  DEF_FIELD(int, item_type);
  // 标记是机器入库还是运营入库 0:机器 1:运营
  DEF_FIELD(int, produced_by);
  // 来源 (种子页)
  DEF_FIELD(std::string, source);
  // 类别
  DEF_FIELD(std::string, category);
  // 标题
  DEF_FIELD(std::string, title);
  // 载入时间
  DEF_FIELD(base::Time, import_time);
  // 精品分值, 4：精品 , 3：优质, 2：一般, 1：低质, 0:垃圾, -1：无法判别
  DEF_FIELD(int, score);
  // 状态 0：入库待审核 1：已人工审核通过 2：已人工审核不通过
  DEF_FIELD(int, status);
  // 审核的时间
  DEF_FIELD(base::Time, review_time);
  // 审核给定的精品分值, 4：精品 , 3：优质, 2：一般, 1：低质, 0:垃圾, -1：无法判别
  DEF_FIELD(int, score_reviewed);
  // 审核给的评审意见
  DEF_FIELD(std::string, review_comment);
  // 新闻特征feature（json格式存储）
  DEF_FIELD(std::string, item_fea_info);
  // 运营操作人员
  DEF_FIELD(std::string, oper);
  // 频道Id，如果有多个频道用,分割
  DEF_FIELD(std::string, channel_id);
  // 原始来源
  DEF_FIELD(std::string, orig_source);
};

#endif
