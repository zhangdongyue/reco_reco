#ifndef APPCHANNELENTITY_H
#define APPCHANNELENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct AppChannelEntity {
 public:
  AppChannelEntity() 
  : id_(0),
  appname_(""),
  channel_id_(0),
  name_(""),
  is_default_(false),
  is_fixed_(false),
  seq_(0),
  status_(1),
  op_mark_(0),
  op_mark_name_(""),
  android_ve_(""),
  ios_ve_(""),
  is_not_publish_(0),
  publish_strategy_(0),
  force_insert_(false),
  identity_title_(""),
  identity_option_codes_("") {
    modify_time_ = base::Time::Now();
    create_time_ = base::Time::Now();
  }

  bool check_valid() {
    if (id_ == 0) {
      return false;
    }
    if (appname_.empty()) {
      return false;
    }
    if (channel_id_ == 0) {
      return false;
    }
    if (name_.empty()) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string time;

    std::string out;
    out += "id : ";
    out += base::Uint64ToString(id_);
    out += "\t";
    out += "appname : ";
    out += appname_;
    out += "\t";
    out += "channel_id : ";
    out += base::Uint64ToString(channel_id_);;
    out += "\t";
    out += "name : ";
    out += name_;
    out += "\t";
    out += "is_default : ";
    if (is_default_) {
      out += "true";
    } else {
      out += "false";
    }
    out += "\t";
    out += "is_fixed : ";
    if (is_fixed_) {
      out += "true";
    } else {
      out += "false";
    }
    out += "\t";
    out += "seq : ";
    out += base::IntToString(seq_);
    out += "\t";
    out += "status : ";
    out += base::IntToString(status_);
    out += "\t";
    out += "op_mark : ";
    out += base::IntToString(op_mark_);
    out += "\t";
    time.clear();
    opmark_online_time_.ToStringInMilliseconds(&time);
    out += "opmark_online_time : ";
    out += time;
    out += "\t";
    time.clear();
    opmark_expired_time_.ToStringInMilliseconds(&time);
    out += "opmark_expired_time : ";
    out += time;
    out += "\t";
    out += "op_mark_name : ";
    out += op_mark_name_;
    out += "\t";
    out += "android_ve : ";
    out += android_ve_;
    out += "\t";
    out += "ios_ve : ";
    out += ios_ve_;
    out += "\t";
    out += "is_not_publish : ";
    out += base::IntToString(is_not_publish_);
    out += "\t";
    time.clear();
    modify_time_.ToStringInMilliseconds(&time);
    out += "modify_time : ";
    out += time;
    out += "\t";
    time.clear();
    create_time_.ToStringInMilliseconds(&time);
    out += "create_time : ";
    out += time;
    out += "\t";
    out += "publish_strategy : ";
    out += base::IntToString(publish_strategy_);
    out += "\n";
    
    return out;
  }

 private:
  // id
  // 非空
  DEF_FIELD(uint64, id);
  // appname
  // 非空
  DEF_FIELD(std::string, appname);
  // channel表中的频道id
  // 非空
  DEF_FIELD(uint64, channel_id);
  // 渠道自定义频道名
  // 非空
  DEF_FIELD(std::string, name);
  // 是否默认添加
  // 非空
  DEF_FIELD(bool, is_default);
  // 位置是否固定
  // 非空
  DEF_FIELD(bool, is_fixed);
  // 顺序号
  // 非空
  DEF_FIELD(int, seq);
  // 上线下线 0正常，1已下线
  // 非空
  DEF_FIELD(int, status);
  // 频道角标 0-无 1-热 2-新
  // 非空
  DEF_FIELD(int, op_mark);
  // 频道角标自定义名称
  DEF_FIELD(std::string, op_mark_name);
  // 角标上线时间
  DEF_FIELD(base::Time, opmark_online_time);
  // 角标下线时间
  DEF_FIELD(base::Time, opmark_expired_time);
  // android 版本号
  DEF_FIELD(std::string, android_ve);
  // ios 版本号
  DEF_FIELD(std::string, ios_ve);
  // 频道是否下发 0/null=下发; 1=不下发
  DEF_FIELD(int, is_not_publish);
  // 修改时间
  DEF_FIELD(base::Time, modify_time);
  // 创建时间
  // 非空
  DEF_FIELD(base::Time, create_time);
  // 下发特殊策略(可叠加) 0=无特殊策略; 1=分页下发; 2=无上限置顶
  DEF_FIELD(int, publish_strategy);
  // 是否强制插入此位置
  DEF_FIELD(bool, force_insert);
  // 强制插入时间
  DEF_FIELD(base::Time, force_insert_time);
  // 
  DEF_FIELD(std::string, identity_title);
  // 
  DEF_FIELD(std::string, identity_option_codes);
};



#endif
