#ifndef TAGENTITY_H
#define TAGENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct TagEntity {
 public:
  TagEntity()
  : name_("") {}

  bool check_valid() {
    if (name_.empty()) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "name : ";
    out += name_;
    out += "\n";
    return out;
  }

 private:
  // tag 名
  DEF_FIELD(std::string, name);
};

#endif
