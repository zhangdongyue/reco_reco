#ifndef SOURCEENTITY_H
#define SOURCEENTITY_H
#include <string>

#include "reco/bizc/index_monitor/index_builder/entity/entity_field_define.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

struct SourceEntity {
 public:
  SourceEntity()
  : source_(""),
  num_limit_(0),
  day_limit_(0) {}

  bool check_valid() {
    if (source_.empty()) {
      return false;
    }
    return true;
  }

  std::string to_string() {
    std::string out;
    out += "source : ";
    out += source_;
    out += ", ";
    out += "num_limit : ";
    out += num_limit_;
    out += ", ";
    out += "day_limit : ";
    out += day_limit_;
    out += "\n";
    return out;
  }

 private:
  DEF_FIELD(std::string, source);
  DEF_FIELD(int32, num_limit);
  DEF_FIELD(int32, day_limit);
};

#endif
