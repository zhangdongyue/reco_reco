//
// Created by allen.fw on 2017/11/4.
//

#pragma once

#include <string>
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace index_builder {

enum ItemBaptismType {
  kNoNeedItemBaptism = 0,
  kChannelItemBaptism,
  kDirectItemBaptism,
  kTagItemBaptism
};

struct ItemQueueEntity {
  std::string item_id;
  ItemBaptismType item_baptism_type;
  bool item_type_setter;
  reco::ItemType item_type;

  ItemQueueEntity() : item_baptism_type(kNoNeedItemBaptism), item_type_setter(false),
                      item_type(reco::kNone) { }
  ItemQueueEntity(const std::string& id) : item_id(id), item_baptism_type(kNoNeedItemBaptism),
                                           item_type_setter(false), item_type(reco::kNone) { }
  ItemQueueEntity(const std::string& id, const ItemBaptismType baptism_type)
          : item_id(id), item_baptism_type(baptism_type), item_type_setter(false),
            item_type(reco::kNone) { }
  ItemQueueEntity(const std::string& id, const ItemBaptismType baptism_type, bool setter, reco::ItemType type)
          : item_id(id), item_baptism_type(baptism_type), item_type_setter(setter),
            item_type(type) { }
};
}
}
