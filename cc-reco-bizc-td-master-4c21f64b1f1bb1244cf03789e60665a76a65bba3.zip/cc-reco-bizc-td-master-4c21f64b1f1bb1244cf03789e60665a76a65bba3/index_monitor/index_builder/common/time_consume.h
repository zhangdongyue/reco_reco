//
// Created by allen.fw on 2017/8/17.
//

#pragma once

#include <string>
#include "serving_base/utility/timer.h"
#include "base/common/logging.h"

class TimeConsume {
 public:
  TimeConsume(const std::string& name, int sample = 0) : name_(name), sample_(sample) {
    timer_.Start();
  }

  ~TimeConsume() {
    if (sample_ <= 0) {
      LOG(INFO) << name_ << "_cost:" << timer_.Stop();
    } else {
      LOG_EVERY_N(INFO, sample_) << name_ << "_cost:" << timer_.Stop();
    }
  }

 private:
  std::string name_;
  serving_base::Timer timer_;
  int sample_;
};
