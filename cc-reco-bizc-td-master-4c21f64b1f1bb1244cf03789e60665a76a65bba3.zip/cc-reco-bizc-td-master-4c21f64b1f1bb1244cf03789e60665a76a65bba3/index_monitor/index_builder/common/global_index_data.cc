//
// Created by allen.fw on 2017/10/13.
//

#include <string>
#include <unordered_set>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "base/strings/string_split.h"

#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/index_monitor/index_builder/dao/ProducerEntityDao.h"

namespace reco {
namespace index_builder {

DEFINE_int32(start_hour, 1, "hour span from start of day");
DEFINE_bool(for_sim_server, false, "if true, build for sim server");
DEFINE_int32(news_expire_days, 7, "news expire days");
DEFINE_bool(process_ha3doc, true, "if true, process ha3doc");
DEFINE_int32(work_thread_num, 16, "num of convert thread");
DEFINE_string(index_dir, "data", "output file dir");
DEFINE_int32(max_item_per_category, 50000, "max item per category");
DEFINE_int32(max_dbnum_per_category, 200000, "max db num per category");
DEFINE_string(category_expire_days_list, "", "");
DEFINE_string(category_max_limit_list, "", "");
DEFINE_string(channel_max_limit_list, "10016:300000,0:200000,1404457531629:200000", "");
DEFINE_string(channel_expire_days_list, "472933935:15,701104723:15,1911322354:15,1213442674:15,"
        "169476544:15,408250330:15,1670553277:15,1099189934:15,1972619079:15,674534:15,"
        "1404457531633:30,10003:30,10004:30,10012:30,1211676:180,10283:180", "");
DEFINE_bool(open_item_info_debug, false, "");
DEFINE_int32(max_item_per_channel, 50000, "max item per channel");
DEFINE_bool(process_source_seed, true, "if true, process source seed info");

GlobalIndexData::GlobalIndexData() {
  valid_item_strategy_.set_empty_key("");
  producer_whitelist_set_.set_empty_key("");
}

GlobalIndexData::~GlobalIndexData() {
}

bool GlobalIndexData::InitData(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  InitChannelMaxLimitMap();
  InitChannelExpireDaysMap();
  InitCategoryExpireDaysMap();
  InitCategoryMaxLimitMap();
  GetSourceSeedMap(db_option);
  GetProducerWhitelist(db_option);

  return true;
}

void GlobalIndexData::InitChannelMaxLimitMap() {
  std::string max_limits = FLAGS_channel_max_limit_list;
  LOG(INFO) << "channel max_limit_list : " << max_limits;
  std::vector<std::string> limit_pairs;
  std::vector<std::string> rets;
  base::SplitString(max_limits, ",", &limit_pairs);
  for (size_t i = 0; i < limit_pairs.size(); ++i) {
    rets.clear();
    base::SplitString(limit_pairs.at(i), ":", &rets);
    if (rets.size() == 2) {
      uint64 channel_id;
      int limit;
      if (base::StringToUint64(rets[0], &channel_id) &&
          base::StringToInt(rets[1], &limit)) {
        channel_max_limits_.insert(std::make_pair(channel_id, limit));
        LOG(INFO) << "channel id : " << rets[0] << " limit : " << rets[1];
      }
    }
  }
}

void GlobalIndexData::InitChannelExpireDaysMap() {
  std::string expire_days = FLAGS_channel_expire_days_list;
  LOG(INFO) << "channel expire_days_list : " << expire_days;
  std::vector<std::string> expire_pairs;
  std::vector<std::string> rets;
  base::SplitString(expire_days, ",", &expire_pairs);
  for (size_t i = 0; i < expire_pairs.size(); ++i) {
    rets.clear();
    base::SplitString(expire_pairs.at(i), ":", &rets);
    if (rets.size() == 2) {
      uint64 channel_id;
      int expire_days;
      if (base::StringToUint64(rets[0], &channel_id) &&
          base::StringToInt(rets[1], &expire_days)) {
        channel_expire_days_.insert(std::make_pair(channel_id, expire_days));
        LOG(INFO) << "channel id : " << rets[0] << " expire_day : " << rets[1];
      }
    }
  }
}

void GlobalIndexData::InitCategoryExpireDaysMap() {
  std::string expire_days = FLAGS_category_expire_days_list;
  LOG(INFO) << "category expire_days_list : " << expire_days;
  std::vector<std::string> expire_pairs;
  std::vector<std::string> rets;
  base::SplitString(expire_days, ",", &expire_pairs);
  for (size_t i = 0; i < expire_pairs.size(); ++i) {
    rets.clear();
    base::SplitString(expire_pairs.at(i), ":", &rets);
    if (rets.size() == 2) {
      int expire_days;
      if (base::StringToInt(rets[1], &expire_days)) {
        category_expire_days_.insert(std::make_pair(rets[0], expire_days));
        LOG(INFO) << "category: " << rets[0] << " expire_day : " << rets[1];
      }
    }
  }
}

void GlobalIndexData::InitCategoryMaxLimitMap() {
  std::string max_limits = FLAGS_category_max_limit_list;
  LOG(INFO) << "category max_limit_list : " << max_limits;
  std::vector<std::string> limit_pairs;
  std::vector<std::string> rets;
  base::SplitString(max_limits, ",", &limit_pairs);
  for (size_t i = 0; i < limit_pairs.size(); ++i) {
    rets.clear();
    base::SplitString(limit_pairs.at(i), ":", &rets);
    if (rets.size() == 2) {
      int limit;
      if (base::StringToInt(rets[1], &limit)) {
        category_max_limits_.insert(std::make_pair(rets[0], limit));
        LOG(INFO) << "category: " << rets[0] << " limit : " << rets[1];
      }
    }
  }
}

void GlobalIndexData::GetSourceSeedMap(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  if (!FLAGS_process_source_seed) {
    LOG(INFO) << "no nees source seed";
    return;
  }

  std::vector<SeedEntity> seed_list;
  SeedEntityDao seed_dao;
  seed_dao.Init(db_option);
  seed_dao.getAllSeedList(&seed_list);
  for (size_t i = 0; i < seed_list.size(); ++i) {
    SeedEntity& seed = seed_list.at(i);
    source_seed_map_.insert(std::make_pair(seed.get_name(), seed));
  }
  LOG(INFO) << "source seed size: " << source_seed_map_.size();
}

void GlobalIndexData::GetProducerWhitelist(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  std::vector<ProducerEntity> producer_white_list;
  ProducerEntityDao producer_dao;
  producer_dao.Init(db_option);
  producer_dao.getAllProducerWhiteList(&producer_white_list);
  for (size_t i = 0; i < producer_white_list.size(); ++i) {
    ProducerEntity& producer = producer_white_list.at(i);
    producer_whitelist_set_.insert(producer.get_name());
    LOG(INFO) << "producer white list elem : " << producer.get_name();
  }
}

net::rpc::RpcGroup* SetupConnection(const std::string& ips, int port,
                                           int timeout, int retry) {
  std::vector<std::string> flds;
  base::SplitString(ips, ",", &flds);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = retry;
  options.timeout = timeout;
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], port, timeout);
    options.servers.push_back(si);
  }

  auto group = new net::rpc::RpcGroup(options);
  CHECK(group->Connect());
  return group;
}

base::Time GetStartOfDay(const base::Time& t) {
  base::Time::Exploded exploded;
  t.LocalExplode(&exploded);
  exploded.hour = 0;
  exploded.minute = 0;
  exploded.second = 0;
  exploded.millisecond = 0;
  return base::Time::FromLocalExploded(exploded);
}

void PrintItemDebug(const std::string& key, const ItemChannelEntity* item,
                           int show, int click, int day_delta, float score) {
  if (!FLAGS_open_item_info_debug) {
    return;
  }
  LOG(INFO) << "rank_debug:\t" << key << "\t"
            << item->get_item_id() << "\t"
            << item->get_is_web_view() << "\t"
            << item->get_outer_id() << "\t"
            << show << "\t"
            << click << "\t"
            << day_delta << "\t"
            << score << "\t";
}

bool IsNewItemStrategy(const std::string& item_id, const reco::common::IndexStrategyBranch strategy) {
  static const std::unordered_set<reco::common::IndexStrategyBranch,
                                  reco::common::StrategyHash> kLevelMaxStrategy = {
            reco::common::kLeafGoodMine,
            reco::common::kLeafBeautyMine,
            reco::common::kLeafDuration,
            reco::common::kLeafFav,
            reco::common::kLeafShare,
            reco::common::kLeafLike,
            reco::common::kLeafLikeRatio,
            reco::common::kLeafComment,
            reco::common::kLeafBeautyPic
  };
  auto& valid_item_strategy = GlobalIndexDataIns::instance().valid_item_strategy_;
  auto& valid_item_strategy_mutex = GlobalIndexDataIns::instance().valid_item_strategy_mutex_;
  thread::AutoLock lock(&valid_item_strategy_mutex);
  auto iter = valid_item_strategy.find(item_id);
  if (iter != valid_item_strategy.end()) {
    if (kLevelMaxStrategy.find(strategy) != kLevelMaxStrategy.end()) {
      iter->second = strategy;
    }
    return false;
  }
  valid_item_strategy.insert(std::make_pair(item_id, strategy));
  return true;
}

void InvalidItemStrategy(const std::string& item_id, const reco::common::IndexStrategyBranch strategy) {
  auto& invalid_item_strategy = GlobalIndexDataIns::instance().invalid_item_strategy_;
  auto& invalid_item_strategy_mutex = GlobalIndexDataIns::instance().invalid_item_strategy_mutex_;

  thread::AutoLock lock(&invalid_item_strategy_mutex);
  invalid_item_strategy.insert({item_id, strategy});
}

void GetInvalidItemStrategy(const std::vector<ItemChannelEntity>& all_items,
                            const std::vector<ItemChannelEntity>& valid_items,
                            const reco::common::IndexStrategyBranch strategy) {
  std::unordered_set<std::string> valid_item_set;
  for (size_t i = 0; i < valid_items.size(); ++i) {
    valid_item_set.insert(valid_items[i].get_item_id());
  }

  for (size_t i = 0; i < all_items.size(); ++i) {
    const std::string& item_id = all_items[i].get_item_id();
    if (valid_item_set.find(item_id) == valid_item_set.end()) {
      InvalidItemStrategy(item_id, strategy);
    }
  }
}
}
}
