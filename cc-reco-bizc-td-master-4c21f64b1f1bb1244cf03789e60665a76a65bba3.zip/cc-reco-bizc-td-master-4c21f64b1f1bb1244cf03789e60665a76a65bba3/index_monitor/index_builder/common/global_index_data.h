//
// Created by allen.fw on 2017/10/13.
//

#pragma once

#include <map>
#include <string>
#include <unordered_map>
#include "reco/bizc/proto/item.pb.h"
#include "base/thread/blocking_queue.h"
#include "base/container/dense_hash_map.h"
#include "base/container/dense_hash_set.h"
#include "reco/base/common/singleton.h"
#include "reco/bizc/index_monitor/index_builder/dao/ItemChannelEntityDao.h"
#include "base/time/time.h"
#include "reco/bizc/index_monitor/index_builder/dao/SeedEntityDao.h"
#include "reco/bizc/common/index_strategy_define.h"
#include "reco/bizc/index_monitor/index_builder/common/item_queue_entity.h"

namespace net {
namespace rpc {
class RpcGroup;
}
}

namespace reco {
namespace index_builder {

DECLARE_string(build_index_type);
DECLARE_int32(start_hour);
DECLARE_bool(for_sim_server);
DECLARE_int32(news_expire_days);
DECLARE_bool(process_ha3doc);
DECLARE_int32(work_thread_num);
DECLARE_string(index_dir);
DECLARE_int32(max_item_per_category);
DECLARE_int32(max_dbnum_per_category);
DECLARE_int32(max_item_per_channel);

class GlobalIndexData {
 public:
  GlobalIndexData();
  ~GlobalIndexData();

  bool InitData(const serving_base::mysql_util::DbConnManager::Option &db_option);

 private:
  void InitChannelMaxLimitMap();
  void InitChannelExpireDaysMap();
  void InitCategoryExpireDaysMap();
  void InitCategoryMaxLimitMap();
  void GetSourceSeedMap(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void GetProducerWhitelist(const serving_base::mysql_util::DbConnManager::Option &db_option);

 public:
  thread::BlockingQueue<ItemQueueEntity> item_queue_;

  base::dense_hash_map<std::string, reco::common::IndexStrategyBranch> valid_item_strategy_;
  std::unordered_map<std::string, reco::common::IndexStrategyBranch> invalid_item_strategy_;
  std::unordered_map<std::string, int> source_item_num_;
  std::map<std::string, SeedEntity> source_seed_map_;
  base::dense_hash_set<std::string> producer_whitelist_set_;

  thread::Mutex valid_item_strategy_mutex_;
  thread::Mutex invalid_item_strategy_mutex_;

  std::map<uint64, int> channel_expire_days_;
  std::map<uint64, int> channel_max_limits_;
  std::map<std::string, int> category_expire_days_;
  std::map<std::string, int> category_max_limits_;
};

net::rpc::RpcGroup* SetupConnection(const std::string& ips, int port,
                                           int timeout, int retry);
base::Time GetStartOfDay(const base::Time& t);
void PrintItemDebug(const std::string& key, const ItemChannelEntity* item,
                           int show, int click, int day_delta, float score);
bool IsNewItemStrategy(const std::string& item_id, const reco::common::IndexStrategyBranch strategy);

void InvalidItemStrategy(const std::string& item_id, const reco::common::IndexStrategyBranch strategy);

void GetInvalidItemStrategy(const std::vector<ItemChannelEntity>& all_items,
                            const std::vector<ItemChannelEntity>& valid_items,
                            const reco::common::IndexStrategyBranch strategy);

typedef reco::common::singleton_default<GlobalIndexData> GlobalIndexDataIns;
}
}
