#include "reco/bizc/index_monitor/index_builder/hbase/ItemMetaHBaseService.h"
#include "reco/bizc/index_monitor/index_builder/hbase/ItemSimHBaseService.h"

DEFINE_string(tb_meta_table, "tb_item_statistics", "");
DEFINE_string(tb_sim_table, "tb_sim_item", "");
DEFINE_string(item_id, "", "");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "sim item client");

  reco::hbase::HBasePoolIns::instance().Init();

  ItemMetaHBaseService* meta_serv = new ItemMetaHBaseService();
  ItemSimHBaseService* sim_serv = new ItemSimHBaseService();

  reco::index_data::MetaData meta_data;
  if (meta_serv->getMetaData(FLAGS_tb_meta_table, FLAGS_item_id, &meta_data)) {
    LOG(INFO) << meta_data.Utf8DebugString();
  } else {
    LOG(WARNING) << "can't get meta data, " << FLAGS_item_id;
  }

  reco::index_data::SimData sim_data;
  if (sim_serv->getSimData(FLAGS_tb_sim_table, FLAGS_item_id, &sim_data)) {
    LOG(INFO) << sim_data.Utf8DebugString();
  } else {
    LOG(WARNING) << "can't get sim data, " << FLAGS_item_id;
  }

  delete meta_serv;
  delete sim_serv;
  return 0;
}

