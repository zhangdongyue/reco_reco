#ifndef ITEMHBASESERVICE_H
#define ITEMHBASESERVICE_H

#include <string>
#include "base/common/logging.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/proto/item.pb.h"

class ItemHBaseService {
 public:
  ItemHBaseService() {}
  ~ItemHBaseService() {}
  bool getRecoItem(std::string table_name, std::string item_id, reco::RecoItem* reco_item);
 private:
  std::string table_name_;
  
};

#endif
