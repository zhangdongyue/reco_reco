#include "reco/bizc/index_monitor/index_builder/hbase/ItemHBaseService.h"

#include <string>
#include <map>
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"

DEFINE_int32(reco_hbase_retry_time, 10, "reco hbase retry time");
DEFINE_int32(reco_hbase_reconnect_time, 10, "reco hbase reconnect time");
DEFINE_int32(reco_hbase_cli_timeout_ms, 200, "reco hbase cli timeout ms");
DEFINE_string(proto_str, "data:proto", "family name: data, column name: proto");

bool ItemHBaseService::getRecoItem(std::string table_name, std::string item_id, reco::RecoItem* reco_item) {
  CHECK_NOTNULL(reco_item);
  if (table_name.empty()) {
    return false;
  }
  if (item_id.empty()) {
    return false;
  }

  std::map<std::string, std::string> ret_map;

  int retry = 0;
  while (retry++ < FLAGS_reco_hbase_retry_time) {
    reco::hbase::HBaseAutoCli cli(FLAGS_reco_hbase_cli_timeout_ms);
    reco::hbase::HBaseCli* hbase = cli.Get();
    if (hbase == NULL) {
      continue;
    }
    try {
      if (hbase->GetByKey(table_name, item_id, &ret_map)) {
        break;
      } else {
        LOG(ERROR) << "get item from hbase failed! item_id : " << item_id;
        if (!hbase->Isconnect()) {
          int reconnect = 0;
          while (reconnect++ < FLAGS_reco_hbase_reconnect_time && !hbase->Connect()) {
            base::SleepForSeconds(1);
          }
        }
        continue;
      }
    } catch (...) {
      LOG(ERROR) << "exception occur in hbase get key";
      continue;
    }
  }

  if (retry >= FLAGS_reco_hbase_retry_time) {
    return false;
  }

  auto it = ret_map.find(FLAGS_proto_str);
  try {
    if (it != ret_map.end()) {
      VLOG(1) << "item_id: " << item_id << " " << FLAGS_proto_str << ": " << it->second;
      if (!reco_item->ParseFromString(it->second)) {
        LOG(ERROR) << "canot parse proto for key: " << item_id;
        return false;
      }
      return true;
    } else {
      LOG(ERROR) << "canot find proto for key: " << item_id;
      return false;
    }
  } catch (...) {
    LOG(ERROR) <<"exception occur in parse proto string";
    return false;
  }
}
