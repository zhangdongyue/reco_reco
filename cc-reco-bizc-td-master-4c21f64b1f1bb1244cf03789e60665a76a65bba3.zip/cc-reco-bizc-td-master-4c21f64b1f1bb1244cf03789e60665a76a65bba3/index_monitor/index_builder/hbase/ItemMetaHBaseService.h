#ifndef ITEMMETAHBASESERVICE_H
#define ITEMMETAHBASESERVICE_H

#include <string>
#include "base/common/logging.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/proto/index_aux_data.pb.h"

class ItemMetaHBaseService {
 public:
  ItemMetaHBaseService() {}
  ~ItemMetaHBaseService() {}
  bool getMetaData(std::string table_name, std::string item_id, reco::index_data::MetaData* meta_data);
 private:
  std::string table_name_;
  
};

#endif

