#include <stdio.h>
#include <vector>
#include <unordered_map>      
#include <utility>
#include <set>                
#include <string>             

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/common/base.h" 
#include "base/time/time.h"

#include "reco/bizc/index_monitor/index_builder/hbase/ItemHBaseService.h"
#include "reco/bizc/index_monitor/index_builder/dao/IflowItemEntityDao.h"


class ItemHBaseServiceTest : public testing::Test {
 protected:
  virtual void SetUp() {
  }

  virtual void TearDown() {
  }
};

TEST_F(ItemHBaseServiceTest, Test_getRecoItem) {
  ItemHBaseService item_service("11.251.181.33", 9090);

  IflowItemEntityDao iflow_item_dao;
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = "tcp://11.251.203.145:3306";
  db_option.schema = "reco";
  db_option.user = "recodev";
  db_option.passwd = "tkDn19DHeVZkNA";
  iflow_item_dao.Init(db_option);

  std::vector<IflowItemEntity> item_list;
  base::Time current_time = base::Time::Now();
  std::string timestamp;
  current_time.ToStringInSeconds(&timestamp);
  iflow_item_dao.getItemsByDate(timestamp, 10, &item_list);

  for (size_t i = 0; i < item_list.size(); ++i) {
    reco::RecoItem reco_item;
    EXPECT_TRUE(item_service.getRecoItem("tb_reco_item", item_list.at(i).get_item_id(), &reco_item));
    EXPECT_GT(reco_item.ByteSize(), 0);
    printf("reco item size is : %d\n",reco_item.ByteSize());
  }
}


