#include <stdio.h>
#include <vector>
#include <unordered_map>      
#include <utility>
#include <set>                
#include <string>             

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/common/base.h" 
#include "base/time/time.h"

#include "reco/bizc/index_monitor/index_builder/hbase/ItemMetaHBaseService.h"
#include "reco/bizc/index_monitor/index_builder/dao/IflowItemEntityDao.h"
#include "third_party/jsoncpp/include/json/json.h"


class ItemMetaHBaseServiceTest : public testing::Test {
 protected:
  virtual void SetUp() {
  }

  virtual void TearDown() {
  }
};

TEST_F(ItemMetaHBaseServiceTest, Test_getMetaData) {
  ItemMetaHBaseService meta_service("11.251.181.33", 9090);
  IflowItemEntityDao iflow_item_dao;
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = "tcp://11.251.203.145:3306";
  db_option.schema = "reco";
  db_option.user = "recodev";
  db_option.passwd = "tkDn19DHeVZkNA";
  iflow_item_dao.Init(db_option);

  std::vector<IflowItemEntity> item_list;
  base::Time current_time = base::Time::Now();
  std::string timestamp;
  current_time.ToStringInSeconds(&timestamp);
  iflow_item_dao.getItemsByDate(timestamp, 10, &item_list);

  for (size_t i = 0; i < item_list.size(); ++i) {
    reco::index_data::MetaData meta_data;
    if (meta_service.getMetaData("tb_item_statistics", item_list.at(i).get_item_id(), &meta_data)) {
      EXPECT_GT(meta_data.ByteSize(), 0);
      printf("meta data is : %s\n",meta_data.DebugString().c_str());
      break;
    }
  }
}


TEST_F(ItemMetaHBaseServiceTest, Test_jsonParse) {
  ItemMetaHBaseService meta_service("11.251.181.33", 9090);

  std::string show_str = "[31767830,873905]";
  std::string action_str = "[27132221,{\"share\":124,\"duration\":15476443,\"fav\":116,\"disLike\":93,"
      "\"event_time\":1469424498588000,\"click\":158117,\"earliest_time\":1467950761464000}]";

  {
    Json::Reader reader;
    Json::Value value;
    uint64 show_count = 0;
    if (!reader.parse(show_str, value, false) ) {
      LOG(WARNING) << "parse error";
    } else {
      if (!value.isArray()) {
        LOG(WARNING) << "not arrary";
      } else {
        if (value.size() < 2) {
          LOG(WARNING) << "size error";
        } else {
          if (!value[1].isInt()) {
            LOG(WARNING) << "not int";
          } else {
            show_count = (uint64)value[1].asInt64();
            printf("show_count : %lu\n", show_count);
          }
        }
      }
    }
  }

  {
    Json::Reader reader;
    Json::Value value;
    Json::Value object;
    uint64 click_count = 0;
    uint64 share_count = 0;
    uint64 fav_count = 0;
    if (!reader.parse(action_str, value, false)) {
      LOG(WARNING) << "parse error";
    } else {
      if (!value.isArray()) {
        LOG(WARNING) << "not arrary";
      } else {
        if (value.size() < 2) {
          LOG(WARNING) << "size error";
        } else {
          object = value[1];
          if (object.isMember("click")) {
            if (object["click"].isInt()) {
              click_count = (uint64)object["click"].asInt64();
              printf("click_count : %lu\n", click_count);
            } else {
              LOG(WARNING) << "not int";
            }
          } else {
            LOG(WARNING) << "click not member";
          }
          if (object.isMember("share")) {
            if (object["share"].isInt()) {
              share_count = (uint64)object["share"].asInt64();
              printf("share_count : %lu\n", share_count);
            } else {
              LOG(WARNING) << "not int";
            }
          } else {
            LOG(WARNING) << "share not member";
          }
          if (object.isMember("fav")) {
            if (object["fav"].isInt()) {
              fav_count = (uint64)object["fav"].asInt64();
              printf("fav_count : %lu\n", fav_count);
            } else {
              LOG(WARNING) << "not int";
            }
          } else {
            LOG(WARNING) << "fav not member";
          }
        }
      }
    }
  }
}
