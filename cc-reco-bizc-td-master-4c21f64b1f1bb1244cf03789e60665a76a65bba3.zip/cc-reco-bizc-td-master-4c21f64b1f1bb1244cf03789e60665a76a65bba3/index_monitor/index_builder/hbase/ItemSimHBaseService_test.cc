#include <stdio.h>
#include <vector>
#include <unordered_map>      
#include <utility>
#include <set>                
#include <string>             

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/common/base.h" 
#include "base/time/time.h"

#include "reco/bizc/index_monitor/index_builder/hbase/ItemSimHBaseService.h"
#include "reco/bizc/index_monitor/index_builder/dao/IflowItemEntityDao.h"


class ItemSimHBaseServiceTest : public testing::Test {
 protected:
  virtual void SetUp() {
  }

  virtual void TearDown() {
  }
};

TEST_F(ItemSimHBaseServiceTest, Test_getSimData) {
  ItemSimHBaseService sim_service("11.251.181.33", 9090);

  IflowItemEntityDao iflow_item_dao;
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = "tcp://11.251.203.145:3306";
  db_option.schema = "reco";
  db_option.user = "recodev";
  db_option.passwd = "tkDn19DHeVZkNA";
  iflow_item_dao.Init(db_option);

  std::vector<IflowItemEntity> item_list;
  base::Time current_time = base::Time::Now();
  std::string timestamp;
  current_time.ToStringInSeconds(&timestamp);
  iflow_item_dao.getItemsByDate(timestamp, 10, &item_list);

  for (size_t i = 0; i < item_list.size(); ++i) {
    reco::index_data::SimData sim_data;
    EXPECT_TRUE(sim_service.getSimData("tb_sim_item", item_list.at(i).get_item_id(), &sim_data));
    EXPECT_GT(sim_data.ByteSize(), 0);
    printf("sim data is : %s\n",sim_data.DebugString().c_str());
  }
}




