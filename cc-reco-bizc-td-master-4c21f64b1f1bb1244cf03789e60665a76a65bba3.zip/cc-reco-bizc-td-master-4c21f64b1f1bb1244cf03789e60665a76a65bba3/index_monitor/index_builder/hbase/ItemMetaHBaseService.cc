#include "reco/bizc/index_monitor/index_builder/hbase/ItemMetaHBaseService.h"

#include <string>
#include <map>
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"
#include "third_party/jsoncpp/include/json/json.h"

DEFINE_string(show_count_str, "data:show_count_hz", "family name: data, column name: show_count");
DEFINE_string(user_action_str, "data:user_action_hz", "family name: data, column name: user_action");
DEFINE_int32(meta_hbase_retry_time, 10, "meta hbase retry time");
DEFINE_int32(meta_hbase_reconnect_time, 10, "meta hbase reconnect time");
DEFINE_int32(meta_hbase_cli_timeout_ms, 200, "meta hbase cli timeout ms");
DEFINE_string(click_key, "click", "click key in json");
DEFINE_string(share_key, "share", "share key in json");
DEFINE_string(fav_key, "fav", "fav key in json");

bool ItemMetaHBaseService::getMetaData(std::string table_name, std::string item_id,
                                         reco::index_data::MetaData* meta_data) {
  CHECK_NOTNULL(meta_data);
  if (table_name.empty()) {
    return false;
  }
  if (item_id.empty()) {
    return false;
  }

  std::map<std::string, std::string> ret_map;

  int retry = 0;
  while (retry++ < FLAGS_meta_hbase_retry_time) {
    reco::hbase::HBaseAutoCli cli(FLAGS_meta_hbase_cli_timeout_ms);
    reco::hbase::HBaseCli* hbase = cli.Get();
    if (hbase == NULL) {
      continue;
    }
    try {
      if (hbase->GetByKey(table_name, item_id, &ret_map)) {
        break;
      } else {
        LOG(ERROR) << "get item from hbase failed! item_id : " << item_id;
        if (!hbase->Isconnect()) {
          int reconnect = 0;
          while (reconnect++ < FLAGS_meta_hbase_reconnect_time && !hbase->Connect()) {
            base::SleepForSeconds(1);
          }
        }
        continue;
      }
    } catch (...) {
      LOG(ERROR) << "expection occur in hbase get meta item.";
      continue;
    }
  }

  if (retry >= FLAGS_meta_hbase_retry_time) {
    return false;
  }

  if (ret_map.size() == 0) {
    return false;
  }

  uint64 show_count = 0;
  uint64 click_count = 0;
  uint64 share_count = 0;
  uint64 fav_count = 0;
  double score = 0.0;

  bool bfind = false;

  try{
    auto it = ret_map.find(FLAGS_show_count_str);
    if (it != ret_map.end()) {
      bfind = true;
      VLOG(1) << "item_id: " << item_id << " " << FLAGS_show_count_str << ": "<< it->second;
      Json::Reader reader;
      Json::Value value;
      if (!it->second.empty()) {
        if (!reader.parse(it->second, value, false) ||
            !value.isArray() || value.size() < 2 ||
            !value[1].isInt()) {
          LOG(WARNING) << "json value is error: " << it->second;
        } else {
          show_count = (uint64)value[1].asInt64();
          meta_data->set_show_cnt(show_count);
        }
      }
    }

    it = ret_map.find(FLAGS_user_action_str);
    if (it != ret_map.end()) {
      bfind = true;
      VLOG(1) << "item_id: " << item_id << " " << FLAGS_user_action_str << ": " << it->second;
      Json::Reader reader;
      Json::Value value;
      Json::Value object;
      if (!it->second.empty()) {
        if (!reader.parse(it->second, value, false) ||
            !value.isArray() || value.size() < 2) {
          LOG(WARNING) << "json value is error: " << it->second;
        } else {
          object = value[1];
          if (object.isMember(FLAGS_click_key)) {
            if (object[FLAGS_click_key].isInt()) {
              click_count = (uint64)object[FLAGS_click_key].asInt64();
              meta_data->set_click_cnt(click_count);
            }
          }
          if (object.isMember(FLAGS_share_key)) {
            if (object[FLAGS_share_key].isInt()) {
              share_count = (uint64)object[FLAGS_share_key].asInt64();
              meta_data->set_share_cnt(share_count);
            }
          }
          if (object.isMember(FLAGS_fav_key)) {
            if (object[FLAGS_fav_key].isInt()) {
              fav_count = (uint64)object[FLAGS_fav_key].asInt64();
              meta_data->set_fav_cnt(fav_count);
            }
          }
        }
      }
    }

    if (!bfind) {
      return false;
    }

    score = (double)(click_count + (share_count + fav_count) * 30) / (double)(show_count + 200);
    if (score > 1) {
      score = 1;
    }
    meta_data->set_score((int)(score * 100));

    uint64 id;

    base::StringToUint64(item_id, &id);

    meta_data->set_item_id(id);

  } catch (...) {
    LOG(ERROR) << "exception occur in parse meta info.";
    return false;
  }

  return true;
}
