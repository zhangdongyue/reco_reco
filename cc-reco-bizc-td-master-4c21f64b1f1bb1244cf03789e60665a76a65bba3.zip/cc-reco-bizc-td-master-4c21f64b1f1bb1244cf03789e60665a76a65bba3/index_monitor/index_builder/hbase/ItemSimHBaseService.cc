#include "reco/bizc/index_monitor/index_builder/hbase/ItemSimHBaseService.h"

#include <string>
#include <map>
#include <set>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"

DEFINE_string(sim_list_str, "sim:list", "family name: sim, column name: list");
DEFINE_string(sim_list_global, "sim:list_global", "family name: sim, column name: list");
DEFINE_string(parent_str, "sim:parentid", "family name: sim, column name: parentid");
DEFINE_int32(sim_hbase_retry_time, 10, "sim hbase retry time");
DEFINE_int32(sim_hbase_reconnect_time, 10, "sim hbase reconnect time");
DEFINE_int32(sim_hbase_cli_timeout_ms, 200, "sim hbase cli timeout ms");

bool ItemSimHBaseService::getSimData(std::string table_name, std::string item_id,
                                     reco::index_data::SimData* sim_data,
                                     bool get_whole_sim) {
  CHECK_NOTNULL(sim_data);
  if (table_name.empty()) {
    return false;
  }
  if (item_id.empty()) {
    return false;
  }

  std::map<std::string, std::string> ret_map;

  int retry = 0;
  while (retry++ < FLAGS_sim_hbase_retry_time) {
    reco::hbase::HBaseAutoCli cli(FLAGS_sim_hbase_cli_timeout_ms);
    reco::hbase::HBaseCli* hbase = cli.Get();
    if (hbase == NULL) {
      continue;
    }
    try {
    if (hbase->GetByKey(table_name, item_id, &ret_map)) {
      break;
    } else {
      LOG(ERROR) << "get item from hbase failed! item_id : " << item_id;
      if (!hbase->Isconnect()) {
        int reconnect = 0;
        while (reconnect++ < FLAGS_sim_hbase_reconnect_time && !hbase->Connect()) {
          base::SleepForSeconds(1);
        }
      }
      continue;
    }
    } catch (...) {
      LOG(ERROR) << "exception occur in hbase get sim item.";
      continue;
    }
  }

  if (retry >= FLAGS_sim_hbase_retry_time) {
    return false;
  }

  try{

    bool bfind = false;

    auto it = ret_map.find(FLAGS_sim_list_str);
    if (it != ret_map.end()) {
      VLOG(1) << "item_id: " << item_id << " " << FLAGS_sim_list_str << ": " << it->second;
      bfind = true;
      if (!it->second.empty()) {
        std::vector<std::string> rets;
        std::set<std::string> sim_id_set;
        base::SplitString(it->second, ",", &rets);
        for (size_t i = 0; i < rets.size(); ++i) {
          std::string sim_id_str = rets.at(i);
          if (!sim_id_str.empty()) {
            sim_id_set.insert(sim_id_str);
          }
        }
        int sim_id_count = 0;
        for (auto it = sim_id_set.begin(); it != sim_id_set.end(); ++it) {
          uint64 sim_id;
          if (base::StringToUint64(*it, &sim_id)) {
            sim_data->add_sim_ids(sim_id);
            ++sim_id_count;
          }
        }
      }
    }

    if (get_whole_sim) {
      it = ret_map.find(FLAGS_sim_list_global);
      if (it != ret_map.end()) {
        VLOG(1) << "item_id: " << item_id << " " << FLAGS_sim_list_global << ": " << it->second;
        bfind = true;
        if (!it->second.empty()) {
          std::vector<std::string> rets;
          base::SplitString(it->second, ",", &rets);
          uint64 itemid;
          double score;
          int level;
          std::vector<std::string> flds;
          for (size_t i = 0; i < rets.size(); ++i) {
            const std::string str = rets.at(i);
            flds.clear();
            base::SplitString(str, ":", &flds);
            if (flds.size() != 3u
                || !base::StringToUint64(flds[0], &itemid)
                || !base::StringToInt(flds[1], &level)
                || level != 1
                || !base::StringToDouble(flds[2], &score)
                || score < 0.7) {
              continue;
            }
            sim_data->add_whole_sim_ids(itemid);
          }
        }
      }
    }

    it = ret_map.find(FLAGS_parent_str);
    if (it != ret_map.end()) {
      bfind = true;
      VLOG(1) << "item_id: " << item_id << " " << FLAGS_parent_str << ": " << it->second;
      if (!it->second.empty()) {
        uint64 parent_id;
        if (base::StringToUint64(it->second, &parent_id)) {
          sim_data->set_parent_id(parent_id);
        } else {
          LOG(ERROR) << "sim parent convert to uint fail, itemId: " << item_id;
        }
      }
    }
    if (!bfind) {
      return false;
    }
    uint64 id;
    base::StringToUint64(item_id, &id);
    sim_data->set_item_id(id);
  } catch (...) {
    LOG(ERROR) << "exception occur in parse sim info.";
    return false;
  }
  return true;
}

