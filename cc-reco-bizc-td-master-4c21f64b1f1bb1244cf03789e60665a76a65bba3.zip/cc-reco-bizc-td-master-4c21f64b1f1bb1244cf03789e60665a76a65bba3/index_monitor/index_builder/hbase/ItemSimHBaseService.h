#ifndef ITEMSIMHBASESERVICE_H
#define ITEMSIMHBASESERVICE_H

#include <string>
#include "base/common/logging.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/proto/index_aux_data.pb.h"

class ItemSimHBaseService {
 public:
  ItemSimHBaseService() {}
  ~ItemSimHBaseService() {}
  bool getSimData(std::string table_name, std::string item_id,
                  reco::index_data::SimData* sim_data, bool get_whole_sim = true);
 private:
  std::string table_name_;
  
};

#endif

