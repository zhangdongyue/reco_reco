//
// Created by allen.fw on 2017/10/18.
//

#pragma once

#include <string>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/dao/ItemInfoEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/dao/LeafRecallDao.h"

#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class RecallSelector : public BaseSelector {
 public:
  explicit RecallSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~RecallSelector();

  virtual void Process();

 private:
  void GetBeautyPicItems(std::vector<std::string>* info_list);

 private:
  LeafRecallDao leaf_recall_dao_;
};
}
}
