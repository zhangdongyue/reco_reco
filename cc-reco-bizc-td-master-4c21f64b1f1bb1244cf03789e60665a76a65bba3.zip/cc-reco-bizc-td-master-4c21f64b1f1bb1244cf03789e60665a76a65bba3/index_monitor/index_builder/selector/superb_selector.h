//
// Created by allen.fw on 2017/10/18.
//

#pragma once

#include <vector>
#include "reco/bizc/index_monitor/index_builder/dao/SuperbItemEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class SuperbSelector : public BaseSelector {
 public:
  explicit SuperbSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~SuperbSelector();

  virtual void Process();

 private:
  void GetSuperbItems(std::vector<SuperbItemEntity>* item_list);

 private:
  SuperbItemEntityDao superb_item_dao_;
};
}
}
