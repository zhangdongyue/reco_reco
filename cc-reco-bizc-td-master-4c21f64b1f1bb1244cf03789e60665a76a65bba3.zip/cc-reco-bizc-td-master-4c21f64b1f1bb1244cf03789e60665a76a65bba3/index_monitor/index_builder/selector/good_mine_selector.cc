//
// Created by allen.fw on 2017/10/18.
//

#include <map>
#include <unordered_map>
#include <utility>
#include "reco/bizc/index_monitor/index_builder/selector/good_mine_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "base/strings/string_split.h"

namespace reco {
namespace index_builder {

DEFINE_string(goodmine_index_file, "./data/conf_data/goodmine_index_item.txt", "goodmine result index file");
DEFINE_string(good_mine_type, "goodmine:20,beauty:21,"
              "duration:22,fav:23,share:24,"
              "like:25,likeratio:26", "leaf good mine type config");

std::unordered_map<std::string, reco::common::IndexStrategyBranch> kStrToStrategy = {
        {"goodmine", reco::common::kLeafGoodMine}, {"beauty", reco::common::kLeafBeautyMine},
        {"duration", reco::common::kLeafDuration}, {"fav", reco::common::kLeafFav},
        {"share", reco::common::kLeafShare}, {"like", reco::common::kLeafLike},
        {"likeratio", reco::common::kLeafLikeRatio}
};

GoodMineSelector::GoodMineSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  selector_name_ = "good_mine_selector";
}

GoodMineSelector::~GoodMineSelector() {
}

void GoodMineSelector::Process() {
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;
  // 人工挖掘优质内容建库
  std::vector<std::pair<std::string, reco::common::IndexStrategyBranch> > itemid_list;
  GetLeafGoodMineItems(&itemid_list);
  int total_goodmine_items = itemid_list.size();
  for (size_t i = 0; i < itemid_list.size(); ++i) {
    ItemQueueEntity entity(itemid_list[i].first, kDirectItemBaptism);
    item_queue.Put(entity);
    IsNewItemStrategy(entity.item_id, itemid_list[i].second);
  }
  LOG(INFO) << "total get " << total_goodmine_items << " goodmine items";
}

void GoodMineSelector::GetLeafGoodMineItems(std::vector<std::pair<std::string,
                                                reco::common::IndexStrategyBranch> >* itemid_list) {
  base::FilePath index_file(FLAGS_goodmine_index_file);
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(index_file, &lines);
  if (lines.empty()) {
    LOG(WARNING) << "index file empty. " << index_file.ToString();
    return;
  }
  LOG(INFO) << "succ to load goodmine data from disk. " << lines.size();
  itemid_list->resize(lines.size());
  std::map<std::string, reco::common::IndexStrategyBranch> mine_type_map;
  GetMineTypeMap(&mine_type_map);

  for (size_t i = 0; i < lines.size(); ++i) {
    const std::string& line = lines.at(i);
    std::vector<std::string> flds;
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 2u) {
      LOG(WARNING) << "parse fail, flds size < 2, line is: " << line;
      continue;
    }
    base::TrimWhitespaces(&flds[1]);
    auto iter = mine_type_map.find(flds[1]);
    if (iter == mine_type_map.end()) {
      LOG(WARNING) << "find mine type fail [" << flds[1] << "]";
      continue;
    }
    itemid_list->push_back(std::make_pair(flds[0], iter->second));
  }
}

void GoodMineSelector::GetMineTypeMap(std::map<std::string,
                                        reco::common::IndexStrategyBranch>* mine_type_map) {
  std::string mine_type_str = FLAGS_good_mine_type;
  LOG(INFO) << "good mine type map : " << mine_type_str;
  std::vector<std::string> type_pairs;
  std::vector<std::string> rets;
  base::SplitString(mine_type_str, ",", &type_pairs);
  for (size_t i = 0; i < type_pairs.size(); ++i) {
    rets.clear();
    std::string pairstr = type_pairs.at(i);
    base::TrimWhitespaces(&pairstr);
    base::SplitString(pairstr, ":", &rets);
    if (rets.size() != 2) continue;

    base::TrimWhitespaces(&rets[0]);
    auto iter = kStrToStrategy.find(rets[0]);
    if (iter == kStrToStrategy.end()) {
      LOG(WARNING) << "invalid strategy key : " << rets[0];
      continue;
    }
    mine_type_map->insert(std::make_pair(rets[0], iter->second));
    LOG(INFO) << "mine_type " << rets[0] << " strategy : " << iter->second.enum_value;
  }
}
}
}
