//
// Created by allen.fw on 2017/10/18.
//

#pragma once

#include <vector>
#include "reco/bizc/index_monitor/index_builder/dao/JingpinItemEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class JingpinSelector : public BaseSelector {
 public:
  explicit JingpinSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~JingpinSelector();

  virtual void Process();

 private:
  void GetJingpinItems(std::vector<ItemInfoEntity>* info_list);

 private:
  JingpinItemEntityDao jingpin_item_dao_;
};
}
}
