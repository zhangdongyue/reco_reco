#include <string>
#include <vector>

#include "reco/bizc/index_monitor/tools/search_index_builder.h"
#include "reco/bizc/index_monitor/index_builder/selector/ugc_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

DEFINE_string(ugc_item_date, "", "ugc item data datetime.");

UgcSelector::UgcSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  item_ugc_entity_dao_.Init(db_option);
  selector_name_ = "ugc_selector";
}

UgcSelector::~UgcSelector() {
}

void UgcSelector::Process() {
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;

  // Get date interval of ugc items.
  base::Time start_of_day_time = GetStartOfDay(base::Time::Now());
  base::Time start_date = start_of_day_time - base::TimeDelta::FromDays(1);
  if (!FLAGS_ugc_item_date.empty()) {
    LOG(INFO) << "ugc item date is assigned to be:" << FLAGS_ugc_item_date;
    base::Time::FromStringInSeconds(FLAGS_ugc_item_date.c_str(), &start_date);
  }
  base::Time end_date = start_date + base::TimeDelta::FromDays(1);

  // convert date into string.
  std::string str_start_date;
  std::string str_end_date;
  start_date.ToStringInSeconds(&str_start_date);
  end_date.ToStringInSeconds(&str_end_date);
  LOG(INFO) << "start date is:" << str_start_date << " end date is " << str_end_date;

  // Get ugc items from mysql with specific create time
  std::vector<ItemUgcEntity> ugc_items;
  item_ugc_entity_dao_.GetUgcItemsByCreateTime(str_start_date, str_end_date, &ugc_items);

  // Convert ugc items into ItemQueueEntity and enqueue.
  int total_video_num = 0;
  for (auto it = ugc_items.begin();it != ugc_items.end(); ++it) {
    ItemUgcEntity& item = *it;
    if (item.check_valid()) {
      const std::string& item_id = item.get_item_id();
      if (!IsNewItemStrategy(item_id, reco::common::kIndexVideoUgcHandpick)) {
        continue;
      }
      ItemQueueEntity entity(item_id, kNoNeedItemBaptism);
      item_queue.Put(entity);
      ++total_video_num;
    }
  }
  LOG(INFO) << "total video item num : " << total_video_num;
}
}
}
