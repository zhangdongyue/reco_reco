//
// Created by allen.fw on 2017/10/18.
//

#pragma once

#include <string>
#include <unordered_map>
#include "reco/bizc/index_monitor/index_builder/dao/ItemChannelEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class SourceItemsSelector : public BaseSelector {
 public:
  explicit SourceItemsSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  ~SourceItemsSelector();

  virtual void Process();

 private:
  void Process(std::string source, int max_size);
  void GetWhiteSource(std::unordered_map<std::string, int>* white_sources);

 private:
  const serving_base::mysql_util::DbConnManager::Option &db_option_;
};
}
}
