//
// Created by allen.fw on 2017/10/18.
//

#pragma once

#include <string>
#include <vector>
#include <utility>
#include "reco/bizc/index_monitor/index_builder/dao/ItemInfoEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/dao/CommentEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class CommentSelector : public BaseSelector {
 public:
  explicit CommentSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~CommentSelector();

  virtual void Process();

 private:
  void GetTopCommentItems(std::vector<std::string>* itemid_list);
  void LoadCommentFromFile(std::vector<std::pair<int, std::string> >* comment_vec);
  void GetCategoryItemsForComment(const std::vector<ItemInfoEntity>& items,
                                                std::vector<size_t>* index_list);

 private:
  ItemInfoEntityDao item_comment_dao_;
  CommentEntityDao comment_dao_;
};
}
}
