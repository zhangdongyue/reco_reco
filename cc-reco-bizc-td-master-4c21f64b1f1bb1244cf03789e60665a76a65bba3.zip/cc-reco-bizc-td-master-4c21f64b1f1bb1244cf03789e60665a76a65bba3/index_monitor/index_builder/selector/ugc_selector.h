
#pragma once

#include "reco/bizc/index_monitor/index_builder/dao/ItemUgcEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class UgcSelector : public BaseSelector {
 public:
  explicit UgcSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~UgcSelector();

  virtual void Process();

 private:
  ItemUgcEntityDao item_ugc_entity_dao_;
};
}
}
