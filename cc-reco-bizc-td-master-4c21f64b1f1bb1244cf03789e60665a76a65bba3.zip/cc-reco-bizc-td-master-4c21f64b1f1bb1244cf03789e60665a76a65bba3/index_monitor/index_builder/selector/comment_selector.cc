//
// Created by allen.fw on 2017/10/18.
//

#include <algorithm>
#include <functional>
#include <unordered_set>
#include <utility>
#include "reco/bizc/index_monitor/index_builder/selector/comment_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "base/strings/string_split.h"

DEFINE_string(comment_file, "./data/conf_data/comment.txt", "comment file");
DEFINE_int32(item_comment_dump_days, 1, "item comment dump days");

namespace reco {
namespace index_builder {

CommentSelector::CommentSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  item_comment_dao_.Init(db_option);
  comment_dao_.Init(db_option);
  selector_name_ = "comment_selector";
}


CommentSelector::~CommentSelector() {
}

void CommentSelector::Process() {
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;
  // 获取评论排行前 1w 的数据
  std::vector<std::string> itemid_list;
  GetTopCommentItems(&itemid_list);
  int total_items = itemid_list.size();
  for (size_t i = 0; i < itemid_list.size(); ++i) {
    ItemQueueEntity entity(itemid_list[i], kDirectItemBaptism);
    item_queue.Put(entity);
    IsNewItemStrategy(entity.item_id, reco::common::kLeafComment);
  }
  LOG(INFO) << "total get " << total_items << " top comment items";
}

void CommentSelector::GetTopCommentItems(std::vector<std::string>* itemid_list) {
  itemid_list->clear();
  // get parent
  std::vector<std::pair<int, std::string>> comment_vec;
  LoadCommentFromFile(&comment_vec);
  LOG(INFO) << "begin to get items from db.";
  base::Time start_of_day_time = GetStartOfDay(base::Time::Now());
  base::Time start_date = start_of_day_time - base::TimeDelta::FromDays(FLAGS_item_comment_dump_days);
  std::string str_start_date;
  start_date.ToStringInSeconds(&str_start_date);
  std::vector<ItemInfoEntity> items;
  item_comment_dao_.getValidLeafItemsInRange(str_start_date, "", &items);
  LOG(INFO) << "succ to get items from db, total num: " << items.size();

  std::vector<size_t> item_idx_list;
  GetCategoryItemsForComment(items, &item_idx_list);

  std::unordered_set<std::string> comment_id_set;
  for (size_t idx = 0; idx < item_idx_list.size(); ++idx) {
    const ItemInfoEntity& item = items.at(item_idx_list[idx]);
    std::string item_id;
    if (item.get_parent_id().empty()) {
      item_id = item.get_item_id();
    } else {
      item_id = item.get_parent_id();
    }
    if (comment_id_set.find(item_id) != comment_id_set.end()) {
      continue;
    }
    int comment_num = 0;
    comment_dao_.getCommentCountByItemid(item_id, &comment_num);
    comment_vec.push_back(std::make_pair(comment_num, item_id));
    comment_id_set.insert(item_id);
  }

  std::sort(comment_vec.begin(), comment_vec.end(), std::greater<std::pair<int, std::string> >());

  const size_t TOP_NUM = 10000;
  for (size_t i = 0; i < comment_vec.size(); ++i) {
    if (i > TOP_NUM) {
      break;
    }
    itemid_list->push_back(comment_vec[i].second);
    LOG(INFO) << "item : " << comment_vec[i].first << "comment_num : " << comment_vec[i].second;
  }
}

void CommentSelector::LoadCommentFromFile(std::vector<std::pair<int, std::string> >* comment_vec) {
  if (FLAGS_comment_file.empty()) return;
  base::FilePath comment_file(FLAGS_comment_file);
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(comment_file, &lines);
  if (lines.empty()) {
    LOG(WARNING) << "comment file empty. " << comment_file.ToString();
    return;
  }
  comment_vec->resize(comment_vec->size() + lines.size());
  LOG(INFO) << "succ to load comment data from disk. " << lines.size();
  for (size_t i = 0; i < lines.size(); ++i) {
    const std::string& line = lines.at(i);
    std::vector<std::string> flds;
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 2u) {
      LOG(WARNING) << "parse fail, flds size < 2, line is: " << line;
      continue;
    }
    int comment_num = 0;
    if (!base::StringToInt(flds[1], &comment_num)) {
      LOG(WARNING) << "trans to comment_num fail, ine is: " << line;
      continue;
    }
    comment_vec->push_back(std::make_pair(comment_num, flds[0]));
  }
}

void CommentSelector::GetCategoryItemsForComment(const std::vector<ItemInfoEntity>& items,
                                              std::vector<size_t>* index_list) {
  auto& category_expire_days = GlobalIndexDataIns::instance().category_expire_days_;
  LOG(INFO) << "begin to get items from db list.";
  for (size_t idx = 0; idx < items.size(); ++idx) {
    const ItemInfoEntity& item = items.at(idx);
    if (item.get_category().empty()) continue;
    base::Time publish_time = item.get_publish_time();
    if (publish_time.is_null()) continue;
    std::vector<std::string> flds;
    flds.clear();
    base::SplitString(item.get_category(), ",", &flds);
    const std::string& category = flds[0];
    auto it = category_expire_days.find(category);
    int expire_day = it != category_expire_days.end() ? it->second : FLAGS_news_expire_days;
    base::Time now_time = base::Time::Now();
    int day_delta = (now_time - publish_time).InDays();
    if (day_delta <= expire_day) {
      index_list->push_back(idx);
    }
  }
  LOG(INFO) << "succ to get cate items from db list, total num: " << index_list->size();
}
}
}
