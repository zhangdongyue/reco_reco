//
// Created by allen.fw on 2017/10/18.
//

#include <algorithm>
#include <cmath>
#include <set>
#include <string>
#include "reco/bizc/index_monitor/index_builder/selector/leaf_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "base/strings/string_split.h"
#include "base/thread/thread_pool.h"
#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

namespace reco {
namespace index_builder {

DEFINE_bool(process_leaf_channel, true, "if true, process leaf channel item");
DEFINE_bool(process_leaf_cate, true, "if true, process leaf cate item");
DEFINE_string(leaf_channel_special, "1211676,1964289243,200,91888,1670553277,10013,696724,10283", "");

LeafSelector::LeafSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  channel_dao_.Init(db_option);
  leaf_item_channel_dao_.Init(db_option);
  leaf_item_category_dao_.Init(db_option);
  item_info_dao_.Init(db_option);

  selector_name_ = "leaf_selector";
}

LeafSelector::~LeafSelector() {
}

std::set<uint64> get_channel_special() {
  std::set<uint64> ret_set;
  std::vector<std::string> channels;
  base::SplitString(FLAGS_leaf_channel_special, "," , &channels);
  for (auto i = 0u; i < channels.size(); ++i) {
    uint64 channel_id = 0u;
    base::StringToUint64(channels[i], &channel_id);
    if (channel_id != 0u) {
      ret_set.insert(channel_id);
      LOG(INFO) << "special channel : " << channel_id;
    }
  }
  return ret_set;
}

void LeafSelector::Process() {
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;
  auto& channel_expire_days = GlobalIndexDataIns::instance().channel_expire_days_;
  auto& channel_max_limits = GlobalIndexDataIns::instance().channel_max_limits_;
  auto& category_expire_days = GlobalIndexDataIns::instance().category_expire_days_;
  auto& category_max_limits = GlobalIndexDataIns::instance().category_max_limits_;

  base::Time start_of_day_time = GetStartOfDay(base::Time::Now());
  base::Time target_time = start_of_day_time + base::TimeDelta::FromHours(FLAGS_start_hour);
  std::string end_timestamp;
  target_time.ToStringInSeconds(&end_timestamp);
  int total_num = 0;
  std::string timestamp;

  if (FLAGS_process_leaf_channel) {
    // 1. 根据 channel 获取的 item 列表
    std::vector<ChannelEntity> channel_list;
    // TODO(jianhuang) 增加其他需要特殊处理的频道
    // 视频 / 问啊 / 图片 / 本地 / 购物 / 逗逼 / 趣图 / 商业
    // static const std::unordered_set<int64> kAloneIndexChannels
    //    = {1211676, 1964289243, 200, 91888, 1670553277, 10013, 696724};
    ChannelEntity entity;
    std::set<uint64> special_channels = get_channel_special();
    for (auto iter = special_channels.begin(); iter != special_channels.end(); ++iter) {
      if (channel_dao_.getChannelByCid(*iter, &entity)) {
        channel_list.push_back(entity);
      }
    }
    std::vector<ItemChannelEntity> db_items;
    for (size_t i = 0; i < channel_list.size(); ++i) {
      int channel_num = 0;
      ChannelEntity& channel = channel_list.at(i);
      auto it = channel_expire_days.find(channel.get_id());
      int expire_day = it != channel_expire_days.end() ? it->second : FLAGS_news_expire_days;

      auto iter = channel_max_limits.find(channel.get_id());
      int max_limit = iter != channel_max_limits.end() ? iter->second : FLAGS_max_item_per_category;

      // get item from db
      base::Time min_publish_time = start_of_day_time - base::TimeDelta::FromDays(expire_day);
      min_publish_time.ToStringInSeconds(&timestamp);
      db_items.clear();
      if (FLAGS_for_sim_server) {
        max_limit = 0;
      }
      leaf_item_channel_dao_.getValidNewsItemsByChannel(channel.get_id(), timestamp, end_timestamp,
                                                        max_limit, &db_items);

      // 去除已经在 id_set 的 item
      for (size_t k = 0; k < db_items.size(); ++k) {
        ItemChannelEntity& item = db_items.at(k);
        const std::string& itemid = item.get_item_id();
        if (!IsNewItemStrategy(itemid, reco::common::kLeafChannel)) {
          continue;
        }
        ++channel_num;
        ItemQueueEntity entity(item.get_item_id(), kChannelItemBaptism,
                               static_cast<bool>(item.get_item_type_setter()),
                               static_cast<reco::ItemType>(item.get_item_type()));
        item_queue.Put(entity);
      }

      std::string key = "news:" + channel.get_name() + ":" + base::Uint64ToString(channel.get_id());
      LOG(INFO) << "channel: " << key << " get " << channel_num
                << " news items, db item num:" << db_items.size();

      total_num += channel_num;
    }
  }
  LOG(INFO) << "process_leaf_channel end";

  if (FLAGS_process_leaf_cate) {
    // 2. 根据类别获取的 item 列表
    std::unordered_set<std::string> category_list;
    GetCategoryList(&category_list);
    std::vector<ItemChannelEntity> item_list;
    for (auto iter = category_list.begin(); iter != category_list.end(); ++iter) {
      const std::string& category = *iter;

      auto it = category_expire_days.find(category);
      int expire_day = it != category_expire_days.end() ? it->second : FLAGS_news_expire_days;

      auto iter = category_max_limits.find(category);
      int max_limit = iter != category_max_limits.end() ? iter->second : FLAGS_max_item_per_category;
      int kMaxItemFromDB = std::max(max_limit * 3, FLAGS_max_dbnum_per_category);

      // get item from db
      base::Time min_publish_time = start_of_day_time - base::TimeDelta::FromDays(expire_day);
      min_publish_time.ToStringInSeconds(&timestamp);
      item_list.clear();
      if (FLAGS_for_sim_server) {
        kMaxItemFromDB = 0;
      }
      leaf_item_category_dao_.getValidItemsByCategory(category, timestamp, end_timestamp,
                                                      kMaxItemFromDB, &item_list);
      int db_item_num = item_list.size();
      LOG(INFO) << "channel: " << category << " get " << item_list.size() << " db items";
      // 重排序并获取最终进入索引的 item
      if (FLAGS_for_sim_server) {
        max_limit = db_item_num * 10;
      }
      GetCategoryKeyItems(category, &item_list, &total_num);
      rank_items_.RankCategoryItems(category, &item_list, max_limit);

      LOG(INFO) << "category: " << category << " get " << item_list.size()
              << " news items, db item num:" << db_item_num;

      for (size_t i = 0; i < item_list.size(); ++i) {
        const ItemChannelEntity& item = item_list[i];
        ItemQueueEntity entity(item.get_item_id(), kChannelItemBaptism,
                               static_cast<bool>(item.get_item_type_setter()),
                               static_cast<reco::ItemType>(item.get_item_type()));
        item_queue.Put(entity);
      }
      total_num += (int)item_list.size();
    }
  }
  LOG(INFO) << "process_leaf_cate end";

  LOG(INFO) << "total item num : " << total_num;
}

void LeafSelector::GetCategoryKeyItems(const std::string& key,
                    std::vector<ItemChannelEntity>* items,
                    int *total_num) {
  if (items->empty()) return;
  TimeConsume time_consume("category_" + key + "_get_items");

  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;

  std::vector<ItemChannelEntity> ret_items;
  int key_item_num = 0;
  base::dense_hash_map<std::string, std::vector<int>> group_items;
  group_items.set_empty_key("");
  // 获取 group 关联的 item
  for (size_t idx = 0; idx < items->size(); ++idx) {
    const ItemChannelEntity& item = items->at(idx);
    if (item.get_outer_id().empty()) {
      ret_items.push_back(item);
      continue;
    }
    std::string groupid = item.get_outer_id();
    auto iter = group_items.find(groupid);
    if (iter == group_items.end()) {
      iter = group_items.insert(std::make_pair(groupid,
                                               std::vector<int>())).first;
    }
    iter->second.push_back(idx);
  }  // end for

  // 如果 group 有 keyitem 则 keyitem 召回，其他 item 返回继续算分，group 选择一个最佳的 item
  bool has_key = false;
  for (auto iter = group_items.begin(); iter != group_items.end(); ++iter) {
    const std::vector<int>& idx_vec = iter->second;
    if (idx_vec.empty()) continue;
    has_key = false;
    for (size_t i = 0; i < idx_vec.size(); ++i) {
      const ItemChannelEntity& item = items->at(idx_vec[i]);
      // in debup or insert, all recall
      if (!IsNewItemStrategy(item.get_item_id(), reco::common::kLeafCategory)) {
        continue;
      }
      if (!item.get_is_web_view()) {
        continue;
      }
      has_key = true;
      const std::string& itemid = item.get_item_id();
      LOG(INFO) << "key_item_recall:" << itemid;
      // in debup or insert, all recall
      ++key_item_num;
      ItemQueueEntity entity(item.get_item_id(), kChannelItemBaptism,
                             static_cast<bool>(item.get_item_type_setter()),
                             static_cast<reco::ItemType>(item.get_item_type()));
      item_queue.Put(entity);
      break;
    }  // end for
    if (has_key) {
      continue;
    }
    for (size_t i = 0; i < idx_vec.size(); ++i) {
      const ItemChannelEntity& item = items->at(idx_vec[i]);
      ret_items.push_back(item);
    }
  }
  LOG(INFO) << "key item recall num: " << key_item_num;
  *total_num += key_item_num;
  // swap 到返回集
  items->swap(ret_items);

  GetInvalidItemStrategy(ret_items, *items, reco::common::kLeafCategoryGroupFilter);
}

void LeafSelector::GetCategoryList(std::unordered_set<std::string>* category_list) {
  category_list->clear();
  std::vector<std::string> db_category_vec;
  item_info_dao_.getCategories(&db_category_vec);
  std::vector<std::string> flds;
  for (size_t idx = 0; idx < db_category_vec.size(); ++idx) {
    flds.clear();
    base::SplitString(db_category_vec[idx], ",", &flds);
    if (flds.size() > 0 && !flds[0].empty()) {
      category_list->insert(flds[0]);
    }
  }
  category_list->insert("体育,NBA");
  category_list->insert("体育,CBA");
  category_list->insert("体育,国际足球");
  category_list->insert("体育,国内足球");
  category_list->insert("科技,互联网");
  category_list->insert("科技,手机");
  LOG(INFO) << "get category list, db num: " << db_category_vec.size()
  << ", used num: " <<category_list->size();
}
}
}
