//
// Created by allen.fw on 2017/10/18.
//

#include <string>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/selector/recall_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

RecallSelector::RecallSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  leaf_recall_dao_.Init(db_option);

  selector_name_ = "recall_selector";
}

RecallSelector::~RecallSelector() {
}

void RecallSelector::Process() {
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;
  // 强制召回美女图片内容
  std::vector<std::string> itemid_list;
  GetBeautyPicItems(&itemid_list);
  int total_items = itemid_list.size();
  for (size_t i = 0; i < itemid_list.size(); ++i) {
    ItemQueueEntity entity(itemid_list[i], kDirectItemBaptism);
    item_queue.Put(entity);
    IsNewItemStrategy(entity.item_id, reco::common::kLeafBeautyPic);
  }
  LOG(INFO) << "total get " << total_items << " beauty pic items";
}

void RecallSelector::GetBeautyPicItems(std::vector<std::string>* itemid_list) {
  auto& category_expire_days = GlobalIndexDataIns::instance().category_expire_days_;

  itemid_list->clear();
  std::string category = "美女写真";
  base::Time start_of_day_time = GetStartOfDay(base::Time::Now());
  base::Time target_time = start_of_day_time + base::TimeDelta::FromHours(FLAGS_start_hour);
  std::string end_timestamp;
  target_time.ToStringInSeconds(&end_timestamp);

  auto it = category_expire_days.find(category);
  int expire_day = it != category_expire_days.end() ? it->second : FLAGS_news_expire_days;
  base::Time min_publish_time = start_of_day_time - base::TimeDelta::FromDays(expire_day);
  std::string timestamp;
  min_publish_time.ToStringInSeconds(&timestamp);

  int max_limit = FLAGS_max_dbnum_per_category;

  leaf_recall_dao_.getBeautyPicItemList(timestamp, end_timestamp, max_limit, itemid_list);
}
}
}
