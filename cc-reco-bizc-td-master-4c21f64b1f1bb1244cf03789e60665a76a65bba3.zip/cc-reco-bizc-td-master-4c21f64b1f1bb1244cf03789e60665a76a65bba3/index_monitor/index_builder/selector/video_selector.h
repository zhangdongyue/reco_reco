//
// Created by allen.fw on 2017/10/18.
//

#pragma once

#include "reco/bizc/index_monitor/index_builder/dao/ChannelEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/dao/ItemChannelEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class VideoSelector : public BaseSelector {
 public:
  explicit VideoSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~VideoSelector();

  virtual void Process();

 private:
  ChannelEntityDao channel_dao_;
  ItemChannelEntityDao video_item_channel_dao_;
};
}
}
