//
// Created by allen.fw on 2017/10/18.
//

#pragma once

#include <map>
#include <string>
#include <utility>
#include <vector>
#include "reco/bizc/common/index_strategy_define.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class GoodMineSelector : public BaseSelector {
 public:
  explicit GoodMineSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~GoodMineSelector();

  virtual void Process();

 private:
  void GetLeafGoodMineItems(std::vector<std::pair<std::string,
                              reco::common::IndexStrategyBranch> >* itemid_list);
  void GetMineTypeMap(std::map<std::string, reco::common::IndexStrategyBranch>* mine_type_map);
};
}
}
