//
// Created by allen.fw on 2017/10/18.
//

#include <string>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/selector/jingpin_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

DEFINE_int32(max_jingpin_item_num, 100000, "max jingpin item num");
DEFINE_int32(jingpin_expire_days, 30, "max jingpin item expire days");

JingpinSelector::JingpinSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  jingpin_item_dao_.Init(db_option);
  selector_name_ = "jingpin_selector";
}

JingpinSelector::~JingpinSelector() {
}

void JingpinSelector::Process() {
  auto &item_queue = GlobalIndexDataIns::instance().item_queue_;
  // 加入精品运营文章
  std::vector <ItemInfoEntity> info_list;
  GetJingpinItems(&info_list);
  for (size_t i = 0; i < info_list.size(); ++i) {
    ItemQueueEntity entity(info_list[i].get_item_id(), kDirectItemBaptism);
    item_queue.Put(entity);
    IsNewItemStrategy(info_list.at(i).get_item_id(), reco::common::kVideoJingpin);
  }
  LOG(INFO) << "total jingpin items: " << info_list.size();
}

void JingpinSelector::GetJingpinItems(std::vector<ItemInfoEntity>* info_list) {
  base::Time start_of_day_time = GetStartOfDay(base::Time::Now());
  base::Time target_time = start_of_day_time + base::TimeDelta::FromHours(FLAGS_start_hour);
  std::string end_timestamp;
  target_time.ToStringInSeconds(&end_timestamp);

  // 视频精品文章 60 天
  base::Time min_video_publish_time = start_of_day_time
                                      - base::TimeDelta::FromDays(FLAGS_jingpin_expire_days * 2);
  std::string video_start_time;
  min_video_publish_time.ToStringInSeconds(&video_start_time);
  int max_limit = FLAGS_max_jingpin_item_num;
  if (FLAGS_for_sim_server) {
    max_limit = max_limit * 1000;
  }
  jingpin_item_dao_.getJingpinItemInfoByCreatetime(video_start_time, end_timestamp,
                                                   max_limit, info_list);
  if (info_list->size() != 0) {
    LOG(INFO) << "getJingpinItems: jingpin item num: " << info_list->size();
  }
}
}
}
