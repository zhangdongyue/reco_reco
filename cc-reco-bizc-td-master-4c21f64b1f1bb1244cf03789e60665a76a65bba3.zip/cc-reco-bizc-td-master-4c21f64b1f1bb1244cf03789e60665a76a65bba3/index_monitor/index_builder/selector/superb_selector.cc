//
// Created by allen.fw on 2017/10/18.
//

#include <string>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/selector/superb_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

DEFINE_int32(max_superb_item_num, 100000, "max superb item num");
DEFINE_int32(superb_expire_days, 90, "max superb item expire days");

SuperbSelector::SuperbSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  superb_item_dao_.Init(db_option);

  selector_name_ = "superb_selector";
}

SuperbSelector::~SuperbSelector() {
}

void SuperbSelector::Process() {
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;
  // 加入精品运营文章
  std::vector<SuperbItemEntity> item_list;
  GetSuperbItems(&item_list);
  for (size_t i = 0; i < item_list.size(); ++i) {
    ItemQueueEntity entity(item_list.at(i).get_item_id(), kDirectItemBaptism);
    item_queue.Put(entity);
    IsNewItemStrategy(entity.item_id, reco::common::kLeafSuperb);
  }
  LOG(INFO) << "total superb items: " << item_list.size();
}

void SuperbSelector::GetSuperbItems(std::vector<SuperbItemEntity>* item_list) {
  base::Time start_of_day_time = GetStartOfDay(base::Time::Now());
  base::Time target_time = start_of_day_time + base::TimeDelta::FromHours(FLAGS_start_hour);
  std::string end_timestamp;
  target_time.ToStringInSeconds(&end_timestamp);

  // superb 90 天
  base::Time min_publish_time = start_of_day_time - base::TimeDelta::FromDays(FLAGS_superb_expire_days);
  std::string start_time;
  min_publish_time.ToStringInSeconds(&start_time);
  int max_limit = FLAGS_max_superb_item_num;
  if (FLAGS_for_sim_server) {
    max_limit = max_limit * 1000;
  }
  superb_item_dao_.getSuperbItemByCreatetime(start_time, end_timestamp,
                                             max_limit, item_list);
  if (item_list->size() != 0) {
    LOG(INFO) << "getSuperbItems: superb item num: " << item_list->size();
  }
}
}
}
