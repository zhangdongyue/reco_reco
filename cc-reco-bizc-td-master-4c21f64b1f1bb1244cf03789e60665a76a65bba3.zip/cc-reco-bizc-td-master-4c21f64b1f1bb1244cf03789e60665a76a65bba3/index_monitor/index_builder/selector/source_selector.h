//
// Created by allen.fw on 2017/10/18.
//

#pragma once

#include "reco/bizc/index_monitor/index_builder/dao/SourceEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class SourceSelector : public BaseSelector {
 public:
  explicit SourceSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~SourceSelector();

  virtual void Process();

 private:
  SourceEntityDao source_dao_;
};
}
}
