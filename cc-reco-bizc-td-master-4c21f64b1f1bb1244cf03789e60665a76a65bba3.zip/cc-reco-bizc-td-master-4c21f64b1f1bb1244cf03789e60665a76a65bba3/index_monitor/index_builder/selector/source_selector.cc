//
// Created by allen.fw on 2017/10/18.
//

#include <string>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/selector/source_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

SourceSelector::SourceSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  source_dao_.Init(db_option);

  selector_name_ = "source_selector";
}

SourceSelector::~SourceSelector() {
}

void SourceSelector::Process() {
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;
  auto& source_seed_map = GlobalIndexDataIns::instance().source_seed_map_;

  // 加入按源拉取文章
  std::vector<SourceEntity> source_candidate;
  std::vector<SourceEntity> source_list;
  source_dao_.getAllSourceList(&source_candidate);
  for (size_t i = 0; i < source_candidate.size(); ++i) {
    auto it = source_seed_map.find(source_candidate.at(i).get_source());
    if (it != source_seed_map.end()) {
      SeedEntity& seed = it->second;
      // 种子设置成抓取不下发
      if (seed.get_publish_status() == 1) {
        LOG(INFO) << "source : " << source_candidate.at(i).get_source() << " filtered";
        continue;
      }
      source_list.push_back(source_candidate.at(i));
    } else {
      LOG(INFO) << "source : " << source_candidate.at(i).get_source() << " filtered";
    }
  }
  LOG(INFO) << "total source records: " << source_list.size();
  int filtered_size = 0;
  int total_source_items = 0;
  for (size_t i = 0; i < source_list.size(); ++i) {
    std::vector<ItemInfoEntity> item_list;
    std::string source = source_list.at(i).get_source();
    int32 max_limit = source_list.at(i).get_num_limit();
    int32 day_limit = source_list.at(i).get_day_limit();

    std::string start_timestamp;
    std::string end_timestamp;
    base::Time start_of_day_time = GetStartOfDay(base::Time::Now());
    base::Time min_publish_time = start_of_day_time - base::TimeDelta::FromDays(day_limit);
    min_publish_time.ToStringInSeconds(&start_timestamp);
    base::Time target_time = start_of_day_time + base::TimeDelta::FromHours(FLAGS_start_hour);
    target_time.ToStringInSeconds(&end_timestamp);
    source_dao_.getItemsBySource(source, start_timestamp, end_timestamp, max_limit, &item_list);
    total_source_items += item_list.size();
    LOG(INFO) << "source : " << source << " get " << item_list.size() << " items";
    for (size_t j = 0; j < item_list.size(); ++j) {
      ItemQueueEntity entity(item_list[j].get_item_id(), kDirectItemBaptism);
      item_queue.Put(entity);
      IsNewItemStrategy(entity.item_id, reco::common::kVideoSource);
    }
  }
  LOG(INFO) << "total get " << total_source_items << " source items";
  LOG(INFO) << filtered_size << " Source duplicated item filtered";
}
}
}
