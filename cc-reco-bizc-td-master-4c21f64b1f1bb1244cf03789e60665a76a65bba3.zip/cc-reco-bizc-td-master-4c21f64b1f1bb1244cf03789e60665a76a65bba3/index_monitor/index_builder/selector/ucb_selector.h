//
// Created by allen.fw on 2017/10/20.
//

#pragma once

#include "reco/bizc/index_monitor/index_builder/dao/IflowItemEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class UCBSelector : public BaseSelector {
 public:
  explicit UCBSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~UCBSelector();

  virtual void Process();

 private:
  IflowItemEntityDao iflow_item_dao_;
};
}
}
