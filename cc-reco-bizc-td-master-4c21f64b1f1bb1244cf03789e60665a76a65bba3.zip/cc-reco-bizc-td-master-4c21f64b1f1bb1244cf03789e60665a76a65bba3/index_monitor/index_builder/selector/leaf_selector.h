//
// Created by allen.fw on 2017/10/18.
//

#pragma once

#include <set>
#include <string>
#include <unordered_set>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/dao/ChannelEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/dao/ItemChannelEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/dao/ItemInfoEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/dao/LeafItemCategoryDao.h"

#include "reco/bizc/index_monitor/index_builder/strategy/rank_items.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class LeafSelector : public BaseSelector {
 public:
  explicit LeafSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~LeafSelector();

  virtual void Process();

 private:
  void GetCategoryKeyItems(const std::string& key, std::vector<ItemChannelEntity>* items, int *total_num);
  void GetCategoryList(std::unordered_set<std::string>* category_list);

 private:
  ChannelEntityDao channel_dao_;
  ItemChannelEntityDao leaf_item_channel_dao_;
  LeafItemCategoryDao leaf_item_category_dao_;
  ItemInfoEntityDao item_info_dao_;

  RankItems rank_items_;
};
}
}
