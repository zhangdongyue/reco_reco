//
// Created by allen.fw on 2017/10/20.
//

#include <string>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/selector/ucb_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

DEFINE_int32(max_ucb_item_num, 5000, "max ucb item num");

UCBSelector::UCBSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  iflow_item_dao_.Init(db_option);

  selector_name_ = "ucb_selector";
}

UCBSelector::~UCBSelector() {
}

void UCBSelector::Process() {
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;

  // 有些运营新闻需要永久保持
  std::vector<IflowItemEntity> item_list;
  base::Time start_of_day_time = GetStartOfDay(base::Time::Now());
  base::Time target_time = start_of_day_time + base::TimeDelta::FromHours(FLAGS_start_hour);
  std::string start_timestamp;
  target_time.ToStringInSeconds(&start_timestamp);
  int max_limit = FLAGS_max_ucb_item_num;
  if (FLAGS_for_sim_server) {
    max_limit = max_limit * 1000;
  }
  iflow_item_dao_.getItemsByDate(start_timestamp, max_limit, &item_list);

  for (size_t i = 0; i < item_list.size(); ++i) {
    std::string item_id = item_list.at(i).get_item_id();
    ItemQueueEntity entity(item_id, kDirectItemBaptism);
    item_queue.Put(entity);
    IsNewItemStrategy(item_id, reco::common::kIndexManual);
  }
  LOG(INFO) << "total ucb forever items: " << item_list.size();
}
}
}
