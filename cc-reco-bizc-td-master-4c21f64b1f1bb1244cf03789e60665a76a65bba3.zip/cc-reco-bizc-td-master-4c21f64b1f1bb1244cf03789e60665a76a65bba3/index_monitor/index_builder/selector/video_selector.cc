//
// Created by allen.fw on 2017/10/18.
//

#include <string>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/selector/video_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

VideoSelector::VideoSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  channel_dao_.Init(db_option);
  video_item_channel_dao_.Init(db_option);

  selector_name_ = "video_selector";
}

VideoSelector::~VideoSelector() {
}

void VideoSelector::Process() {
  auto& channel_expire_days = GlobalIndexDataIns::instance().channel_expire_days_;
  auto& channel_max_limits = GlobalIndexDataIns::instance().channel_max_limits_;

  std::vector<ChannelEntity> channel_list;
  channel_dao_.getChannels(&channel_list);

  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;

  base::Time start_of_day_time = GetStartOfDay(base::Time::Now());
  base::Time target_time = start_of_day_time + base::TimeDelta::FromHours(FLAGS_start_hour);
  std::string end_timestamp;
  target_time.ToStringInSeconds(&end_timestamp);

  int total_video_num = 0;
  int total_op_num = 0;
  std::vector<ItemChannelEntity> db_items;
  for (size_t i = 0; i < channel_list.size(); ++i) {
    int channel_video_num = 0;
    int channel_op_num = 0;
    ChannelEntity& channel = channel_list.at(i);
    int expire_day = FLAGS_news_expire_days;
    int max_limit = FLAGS_max_item_per_channel;
    auto it = channel_expire_days.find(channel.get_id());
    if (it != channel_expire_days.end()) {
      expire_day = it->second;
    }
    auto iter = channel_max_limits.find(channel.get_id());
    if (iter != channel_max_limits.end()) {
      max_limit = iter->second;
    }
    base::Time min_publish_time = start_of_day_time - base::TimeDelta::FromDays(expire_day);
    std::string timestamp;
    min_publish_time.ToStringInSeconds(&timestamp);
    db_items.clear();
    if (FLAGS_for_sim_server) {
      max_limit = 0;
    }
    video_item_channel_dao_.getValidVideoItemsByChannel(channel.get_id(), timestamp,
                                                        end_timestamp, max_limit, &db_items);
    // 去除已经在 id_set 的 item
    for (size_t k = 0; k < db_items.size(); ++k) {
      ItemChannelEntity& item = db_items.at(k);
      const std::string& itemid = item.get_item_id();
      if (!IsNewItemStrategy(itemid, reco::common::kIndexVideo)) {
        continue;
      }
      if (item.get_item_type() == reco::kPureVideo) {
        ++channel_video_num;
      } else {
        ++channel_op_num;
      }
      ItemQueueEntity entity(item.get_item_id(), kChannelItemBaptism,
                             static_cast<bool>(item.get_item_type_setter()),
                             static_cast<reco::ItemType>(item.get_item_type()));
      item_queue.Put(entity);
    }

    std::string key = "video:" + channel.get_name() + ":" + base::Uint64ToString(channel.get_id());
    LOG(INFO) << "channel: " << key << " get " << channel_video_num
              << " video items, "
              << " get " << channel_op_num
              << " op items, "
              << "db item num:" << db_items.size();
    total_video_num += channel_video_num;
    total_op_num += channel_op_num;
  }
  LOG(INFO) << "total video item num : " << total_video_num;
  LOG(INFO) << "total op item num : " << total_op_num;
}
}
}
