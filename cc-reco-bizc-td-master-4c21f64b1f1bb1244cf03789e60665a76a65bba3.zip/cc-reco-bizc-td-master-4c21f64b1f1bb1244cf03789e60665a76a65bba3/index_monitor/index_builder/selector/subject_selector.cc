//
// Created by allen.fw on 2017/10/18.
//

#include <string>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/selector/subject_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

SubjectSelector::SubjectSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  subject_dao_.Init(db_option);

  selector_name_ = "subject_selector";
}

SubjectSelector::~SubjectSelector() {
}

void SubjectSelector::Process() {
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;
  // 加入拉取主题文章
  std::vector<SubjectEntity> source_list;
  subject_dao_.getAllSubjectList(&source_list);
  int total_subject_items = source_list.size();
  for (size_t i = 0; i < source_list.size(); ++i) {
    ItemQueueEntity entity(source_list.at(i).get_item_id(), kDirectItemBaptism);
    item_queue.Put(entity);
    IsNewItemStrategy(entity.item_id, reco::common::kVideoSubject);
  }
  LOG(INFO) << "total get " << total_subject_items << " subject items";
}
}
}
