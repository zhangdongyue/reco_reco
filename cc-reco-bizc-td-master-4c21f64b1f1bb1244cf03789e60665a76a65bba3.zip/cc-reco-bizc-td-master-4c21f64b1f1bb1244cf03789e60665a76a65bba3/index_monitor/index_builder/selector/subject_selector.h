//
// Created by allen.fw on 2017/10/18.
//

#pragma once

#include "reco/bizc/index_monitor/index_builder/dao/SubjectEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace reco {
namespace index_builder {

class SubjectSelector : public BaseSelector {
 public:
  explicit SubjectSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~SubjectSelector();

  virtual void Process();

 private:
  SubjectEntityDao subject_dao_;
};
}
}
