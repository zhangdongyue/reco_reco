//
// Created by allen.fw on 2017/10/18.
//

#include <string>
#include <vector>
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"
#include "reco/bizc/index_monitor/index_builder/selector/source_items_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "base/common/closure.h"

namespace reco {
namespace index_builder {

DEFINE_string(white_source_limit_file, "data/conf_data/white_source_limit_file", "white source limit file");
DEFINE_int32(default_source_max_items, 2000000, "white source default max item num");

SourceItemsSelector::SourceItemsSelector(const serving_base::mysql_util::DbConnManager::Option &db_option)
                                       : db_option_(db_option) {
  selector_name_ = "source_items_selector";
}

SourceItemsSelector::~SourceItemsSelector() {
}

void SourceItemsSelector::Process() {
  std::unordered_map<std::string, int> white_sources;
  GetWhiteSource(&white_sources);
  thread::ThreadPool work_pool(FLAGS_work_thread_num);
  for (std::unordered_map<std::string, int>::iterator it = white_sources.begin();
       it != white_sources.end(); ++it) {
    work_pool.AddTask(::NewCallback<SourceItemsSelector, std::string, int>
                              (this, &SourceItemsSelector::Process,
                               it->first, it->second));
  }
  work_pool.JoinAll();
}

void SourceItemsSelector::Process(std::string source, int max_size) {
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;
  auto& source_item_num = GlobalIndexDataIns::instance().source_item_num_;

  // 加入拉取主题文章
  ItemChannelEntityDao source_item_dao;
  source_item_dao.Init(db_option_);

  std::vector<ItemInfoEntity> item_list;
  source_item_dao.GetValidItemsBySource(source, max_size, &item_list);
  for (size_t i = 0; i < item_list.size(); ++i) {
    std::string item_id = item_list[i].get_item_id();
    int item_type = item_list[i].get_item_type();
    ItemQueueEntity entity(item_id);
    item_queue.Put(entity);
    if (item_type == reco::kPureVideo || item_type == reco::kThemeVideo) {
      IsNewItemStrategy(item_id, reco::common::kIndexVideo);
    } else {
      IsNewItemStrategy(item_id, reco::common::kLeafChannel);
    }
  }
  source_item_num[source] = item_list.size();
  LOG(INFO) << "source [" << source << "] total get [" << item_list.size() << "] items";
}

void SourceItemsSelector::GetWhiteSource(std::unordered_map<std::string, int>* white_sources) {
  white_sources->clear();
  base::FilePath index_file(FLAGS_white_source_limit_file);
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(index_file, &lines);
  if (lines.empty()) {
    LOG(WARNING) << "white source file empty. " << index_file.ToString();
    return;
  }
  LOG(INFO) << "succ to white source data from disk. " << lines.size();
  for (size_t i = 0; i < lines.size(); ++i) {
    const std::string &line = lines.at(i);
    std::vector<std::string> flds;
    base::SplitString(line, "\t", &flds);
    if (flds.size() == 0) {
      continue;
    }
    base::TrimWhitespaces(&flds[0]);
    int max_limit_num = FLAGS_default_source_max_items;
    if (flds.size() <= 1 || !base::StringToInt(flds[1], &max_limit_num)) {
      max_limit_num = FLAGS_default_source_max_items;
    }
    (*white_sources)[flds[0]] = max_limit_num;
  }
}
}
}
