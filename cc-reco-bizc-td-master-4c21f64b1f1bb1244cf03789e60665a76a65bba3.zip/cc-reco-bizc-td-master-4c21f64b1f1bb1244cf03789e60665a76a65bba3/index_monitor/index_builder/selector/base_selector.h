//
// Created by allen.fw on 2017/10/31.
//

#pragma once

#include <string>

namespace reco {
namespace index_builder {

class BaseSelector {
 public:
  virtual ~BaseSelector() { }

  virtual void Process() = 0;

  const std::string& GetSelectorName() {
    return selector_name_;
  }

 protected:
  std::string selector_name_;
};
}
}
