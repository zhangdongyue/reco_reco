//
// Created by allen.fw on 2017/10/18.
//

#include <string>
#include <vector>
#include "reco/bizc/index_monitor/index_builder/selector/tag_items_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "base/thread/thread_pool.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"
#include "base/strings/string_util.h"

namespace reco {
namespace index_builder {

DEFINE_int32(tag_search_thread_num, 2, "num of tag search thread");
DEFINE_int32(tag_expire_days, 30, "max hot tag item expire days");
DEFINE_int32(search_retry_num, 1, "rpc retry num");
DEFINE_int32(search_timeout, 30000, "rpc timeout");
DEFINE_int32(max_item_per_tag, 500, "max item per tag");
DEFINE_string(search_server_ip, "11.251.177.91", "server ip");
DEFINE_int32(search_server_port, 20011, "server port");

TagItemsSelector::TagItemsSelector(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  tag_dao_.Init(db_option);

  LOG(INFO) << "start init search_rpc";
  search_rpc_group_ = SetupConnection(FLAGS_search_server_ip, FLAGS_search_server_port, 10000, -1);
  search_rpc_stub_ = new reco::searchserver::SearchService::Stub(search_rpc_group_);
  LOG(INFO) << "finish init search_rpc";

  selector_name_ = "tag_items_selector";
}

TagItemsSelector::~TagItemsSelector() {
}

void TagItemsSelector::Process() {
  std::vector<TagEntity> tag_list;
  tag_dao_.getTags(&tag_list);
  thread::ThreadPool tag_search_pool(FLAGS_tag_search_thread_num);
  for (int i = 0; i < FLAGS_tag_search_thread_num; ++i) {
    tag_search_pool.AddTask(::NewCallback<TagItemsSelector, int, std::vector<TagEntity>*>
                                    (this, &TagItemsSelector::TagSearchWorker, i, &tag_list));
  }

  tag_search_pool.JoinAll();
  LOG(INFO) << "get " << tag_list.size() << " tags";
}

void TagItemsSelector::TagSearchWorker(int thread_id, std::vector<TagEntity>* tag_list) {
  CHECK_NOTNULL(tag_list);
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;

  for (int i = thread_id; i < (int)tag_list->size(); i += FLAGS_tag_search_thread_num) {
    reco::searchserver::GeneralSearchRequest req;
    reco::searchserver::GeneralSearchResponse res;
    std::string tag = tag_list->at(i).get_name();
    base::TrimWhitespaces(&tag);
    std::string query = "#" + tag + "#";
    req.add_query(query);
    req.add_item_type(reco::kPureVideo);
    int max_limit = FLAGS_max_item_per_tag;
    if (FLAGS_for_sim_server) {
      max_limit = max_limit * 1000;
    }
    req.set_result_num(max_limit);
    // get start of day
    base::Time current_time = base::Time::Now();
    base::Time::Exploded exploded;
    current_time.LocalExplode(&exploded);
    exploded.hour = 0;
    exploded.minute = 0;
    exploded.second = 0;
    exploded.millisecond = 0;
    base::Time start_of_day_time = base::Time::FromLocalExploded(exploded);
    // get start_time
    base::Time start_time = start_of_day_time - base::TimeDelta::FromDays(FLAGS_tag_expire_days);
    base::Time target_time = start_of_day_time + base::TimeDelta::FromHours(FLAGS_start_hour);
    std::string start_timestamp;
    start_time.ToStringInSeconds(&start_timestamp);
    req.set_start_time(start_timestamp);
    std::string end_timestamp;
    target_time.ToStringInSeconds(&end_timestamp);
    req.set_end_time(end_timestamp);
    LOG(INFO) << "tag items request utf8: " << req.Utf8DebugString();

    for (int request_num = 0; request_num <= FLAGS_search_retry_num; ++request_num) {
      res.Clear();
      net::rpc::RpcClientController rpc;
      {
        TimeConsume time_consume("search_rpc_stub_GeneralSearch", 1000);
        search_rpc_stub_->GeneralSearch(&rpc, &req, &res, NULL);
        rpc.TimedWait(FLAGS_search_timeout);
      }
      if (rpc.status() != net::rpc::RpcClientController::kOk) {
        LOG(ERROR) << "search tag items failed. " << res.err_message() << " tag : "
                   << tag << ", rpc.status(): " << rpc.status();
        continue;
      }

      if (!res.success()) {
        std::string err_message = res.has_err_message() ? res.err_message() : "";
        LOG(ERROR) << "search tag items response not success. tag : " << tag
                   << ", response err_message: " << err_message;
        break;
      }

      int id_count = 0;
      for (int j = 0; j < res.result_size(); ++j) {
        for (int k = 0; k < res.result(j).doc_info_size(); ++k) {
          std::string id_str = base::Uint64ToString(res.result(j).doc_info(k).item_id());
          ItemQueueEntity entity(id_str, kTagItemBaptism);
          item_queue.Put(entity);
          IsNewItemStrategy(id_str, reco::common::kVideoTagItems);
          ++id_count;
        }
      }
      LOG(INFO) << "tag: " << tag << " get " << id_count << " items";
      break;
    }
  }
}
}
}
