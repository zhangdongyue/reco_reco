//
// Created by allen.fw on 2017/10/18.
//

#pragma once

#include <vector>
#include "reco/bizc/index_monitor/index_builder/dao/TagEntityDao.h"
#include "reco/bizc/proto/reco_search_server.pb.h"
#include "reco/bizc/index_monitor/index_builder/selector/base_selector.h"

namespace net {
namespace rpc {
class RpcGroup;
}
}

namespace reco {
namespace index_builder {

class TagItemsSelector : public BaseSelector {
 public:
  explicit TagItemsSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~TagItemsSelector();

  virtual void Process();

 private:
  void TagSearchWorker(int thread_id, std::vector<TagEntity>* tag_list);

 private:
  TagEntityDao tag_dao_;
  reco::searchserver::SearchService::Stub* search_rpc_stub_;
  net::rpc::RpcGroup* search_rpc_group_;
};
}
}
