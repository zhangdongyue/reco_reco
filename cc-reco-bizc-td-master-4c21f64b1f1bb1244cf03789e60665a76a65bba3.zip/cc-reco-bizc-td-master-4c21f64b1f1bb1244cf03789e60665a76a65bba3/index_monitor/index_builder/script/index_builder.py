#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys
from include import gflags
from include.common import *
from include.logging import *
from include.gflags_define import FLAGS
from bin.build_reco_index import BuildRecoIndex
from bin.upload_hdf_index import UploadHdfIndex
from bin.deploy_reco_index import DeployRecoIndex

def CheckCommands(command_set):
  all_command_set = set(['good_mine', 'media_info', 'media_level', 'build_index',
                         'deploy_ha3','upload_cdoc','deploy_cdoc'])
  for command in command_set:
    if command not in all_command_set:
      FATAL_FOR_MAIL('your command [' + command + '] is unkown, please check')
      TouchAlarmCore()
      sys.exit(1)

def IsCommandExecute(command, command_set):
  if command in command_set:
    return True
  return False


if __name__ == "__main__":
  try:
    FLAGS(sys.argv)
  except gflags.FlagsError, e:
    print "%s\nUsage: %s [flags]\n%s" % (e, sys.argv[0], FLAGS)
    sys.exit(1)

  print 'index builder start'

  command_set = set(FLAGS.commands.split(","))
  CheckCommands(command_set)
  is_good_mine = IsCommandExecute('good_mine', command_set)
  is_media_info = IsCommandExecute('media_info', command_set)
  is_media_level = IsCommandExecute('media_level', command_set)
  is_build_index = IsCommandExecute('build_index', command_set)
  is_update_hdf = IsCommandExecute('upload_cdoc', command_set)
  is_deploy_cdoc = IsCommandExecute('deploy_cdoc', command_set)
  is_deploy_ha3doc = IsCommandExecute('deploy_ha3', command_set)

  print "get commands: is_good_mine[%s], is_media_info[%s], is_media_level[%s], is_build_index[%s], " \
            "is_update_hdf[%s], is_deploy_cdoc[%s], is_deploy_ha3doc[%s]" % (is_good_mine,\
            is_media_info, is_media_level, is_build_index, is_update_hdf, is_deploy_cdoc, is_deploy_ha3doc)

  ConfigCheck('builder_flags', FLAGS.builder_flags)
  ConfigCheck('update_conf', FLAGS.update_conf)
  ConfigCheck('module', FLAGS.module)
  if is_deploy_cdoc:
    ConfigCheck('machine_conf', FLAGS.machine_conf)

  ExecuteCommand('rm -rf %s' % FLAGS.module + '/data/' + FLAGS.dump_date)
  os.makedirs(FLAGS.module + '/data/' + FLAGS.dump_date)
  if not os.path.exists(FLAGS.module + '/index_root/' + FLAGS.dump_date):
    os.makedirs(FLAGS.module + '/index_root/' + FLAGS.dump_date)

  if is_good_mine:
    NOTICE_FOR_MAIL('load_goodmine_file.sh start')
    script_cmd = 'bash -x ./bin/load_goodmine_file.sh ' + FLAGS.dump_date + ' ' + FLAGS.module
    if not ExecuteScript(script_cmd):
      WARNING_FOR_MAIL('load_goodmine_file.sh fail')
      TouchAlarmCore()
    NOTICE_FOR_MAIL('load_goodmine_file.sh end')

  if is_media_info:
    NOTICE_FOR_MAIL('gen_media_info.sh start')
    script_cmd = 'bash -x ./bin/gen_media_info.sh ' + FLAGS.dump_date + ' ' + FLAGS.module
    if not ExecuteScript(script_cmd):
      WARNING_FOR_MAIL('gen_media_info.sh fail')
      TouchAlarmCore()
    NOTICE_FOR_MAIL('gen_media_info.sh end')

  if is_media_level:
    NOTICE_FOR_MAIL('gen_media_level.sh start')
    script_cmd = 'bash -x ./bin/gen_media_level.sh ' + FLAGS.dump_date + ' ' + FLAGS.module
    if not ExecuteScript(script_cmd):
      WARNING_FOR_MAIL('gen_media_level.sh fail')
      TouchAlarmCore()
    NOTICE_FOR_MAIL('gen_media_level.sh end')

  if is_build_index:
    NOTICE_FOR_MAIL("build Reco index start")
    build_index = BuildRecoIndex()
    if not build_index.Process():
      FATAL_FOR_MAIL("build Reco index fail")
      TouchAlarmCore()
      sys.exit(1)
    NOTICE_FOR_MAIL("build Reco index end")

  if is_deploy_ha3doc:
    NOTICE_FOR_MAIL("ha3_build_index.sh start")
    script_cmd = 'bash -x ./bin/ha3_build_index.sh ' + FLAGS.dump_date + ' ' + FLAGS.module
    if not ExecuteScript(script_cmd):
      WARNING_FOR_MAIL('ha3_build_index.sh fail')
      TouchAlarmCore()
    NOTICE_FOR_MAIL("ha3_build_index.sh end")

  if is_update_hdf:
    NOTICE_FOR_MAIL("upload cdoc hdf start")
    upload_index = UploadHdfIndex()
    if not upload_index.Process():
      FATAL_FOR_MAIL("upload cdoc hdf fail")
      TouchAlarmCore()
      sys.exit(1)
    NOTICE_FOR_MAIL("upload cdoc hdf end")

  if is_deploy_cdoc:
    NOTICE_FOR_MAIL("deploy cdoc start")
    deploy_index = DeployRecoIndex()
    if not deploy_index.Process():
      FATAL_FOR_MAIL("deploy cdoc fail")
      TouchAlarmCore()
      sys.exit(1)
    NOTICE_FOR_MAIL("deploy cdoc end")
