#!/bin/bash
#wangtingting
#把小流量的itemid列表上传到指定位置，使leaf在线部分能获取相应的meta数据

source include/logging.sh

dump_date=`date +"%Y-%m-%d"`
root_dir=`pwd`
index_dir=$root_dir/index_root/$dump_date

if [ !-f $index_data/index_item_id.$dump_date ]; then
  WARNING "fetch index_item_id not exist!"
  exit 1
fi
#for 小流量meta
/serving/hadoop/hadoop-2.6.0/bin/hadoop fs -rm ./index_data/ext_leaf_item/item.txt
/serving/hadoop/hadoop-2.6.0/bin/hadoop fs -put $index_dir/index_item_id.$dump_date ./index_data/ext_leaf_item/item.txt

exit $ret
