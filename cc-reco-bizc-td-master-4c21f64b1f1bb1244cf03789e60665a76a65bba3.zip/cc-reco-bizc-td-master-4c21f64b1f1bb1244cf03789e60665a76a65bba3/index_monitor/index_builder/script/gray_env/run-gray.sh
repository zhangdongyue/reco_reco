#!/bin/bash
set -u

function sendmail()
{
  #echo -e "index builder error. \nplease login `hostname` at path `pwd` to see what happen" | python send_mail.py ${alert_mail} "[alarm] reco index build FAILED" /dev/stdin
  touch ./bin/core.$$
}

#load goodmine file
bash -x bin/load_goodmine_file.sh
if [ $? -ne 0 ]; then
  echo "load good mine fail"
  sendmail
fi

# 1.1 media info generate
bash -x ./bin/gen_media_info.sh
if [ $? -ne 0 ]; then
  echo "gen media info fail."
  # NOTE(jianhuang) 这里 core 掉，但不 exit
  sendmail
fi

# 1. 构建 index
bash -x ./bin/build_reco_index.sh
if [ $? -ne 0 ]; then
  echo "build reco index fail."
  sendmail
  exit 1
fi

# 1.2 media level generate
bash -x ./bin/gen_media_level.sh
if [ $? -ne 0 ]; then
  echo "gen media level fail."
  sendmail
fi

# 1.3 更新小流量 item 的 meta 数据,仅供小流量使用
bash -x ./bin/update_item_meta.sh
if [ $? -ne 0 ]; then
  echo "update item meta fail."
  sendmail
fi

# 2. 上传 index 到 hadoop
python ./bin/upload_hdf_index.py
if [ $? -ne 0 ]; then
  echo "upload reco index to hadoop fail."
  sendmail
  exit 1
fi

# 3. 部署 index 到 小流量 环境
python ./bin/deploy_reco_index.py --config_filename=config/index_updater.flags --server_list_filename=config/machine.reco.gray
if [ $? -ne 0 ]; then
  echo "update reco index fail."
  sendmail
  exit 1
fi

exit 0
