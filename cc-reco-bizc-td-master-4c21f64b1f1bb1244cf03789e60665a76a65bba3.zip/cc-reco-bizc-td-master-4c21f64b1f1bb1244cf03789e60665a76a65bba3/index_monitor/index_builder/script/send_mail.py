#!/usr/bin/env python
#coding:utf8

import smtplib
import os
import sys
from optparse import OptionParser 
from include.common import *
from email.mime.text import MIMEText
from include import gflags

gflags.DEFINE_string("subject", "建库监控", "建库监控");
gflags.DEFINE_string("log_file_name", "建库日志文件", "建库日志文件");
FLAGS = gflags.FLAGS

def sendmail(log_file_name, subject):
  sender = '喜刷刷建库sm_xss_index_builder监控<sm_xss_index_builder@alibaba-inc.com>'
  receivers = ['allen.fw@alibaba-inc.com', 'kouyan.ky@alibaba-inc.com']
  #receivers = ['allen.fw@alibaba-inc.com']
  time_str = log_file_name.split(".")
  subject = subject + ' ' + time_str[-1]
  username = "sm_xss_index_builder@alibaba-inc.com"
  password = "Qwr*xk2c"
  status, content = GetCommandCodeAndOutput('grep -v "^+" %s | grep "record for mail"' % (log_file_name))
  content = content.replace('[record for mail]', '')
  msg = MIMEText(content, 'plain', 'utf-8')
  msg['Subject'] = subject
  msg['to'] = ";".join(receivers)
  msg['from'] = sender

  smtp = smtplib.SMTP_SSL('smtp.alibaba-inc.com:465')
  smtp.login(username, password)
  smtp.sendmail(sender, receivers, msg.as_string())
  smtp.quit()


if __name__ == '__main__' :
  try:
    argv = FLAGS(sys.argv)
  except gflags.FlagsError, e:
    print "%s\nUsage: %s [flags]\n%s" %(e, sys.argv[0], FLAGS);
    sys.exit(1);

  if os.path.exists(FLAGS.log_file_name) == False:
    print 'log file is not exists'
    sys.exit(-1)

  sendmail(FLAGS.log_file_name, FLAGS.subject)
