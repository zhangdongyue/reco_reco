#!/bin/bash

echo $@
