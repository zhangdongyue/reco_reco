#!/bin/bash

ip=$1
path=$2
server=$3

declare -A tmp
count=0
while read line; do
  tmp[$count]="$line"
  ((count++))
done

fail=0;
for ((i=0;i<count;++i)); do
  line=${tmp[$i]}
  md5str=`echo $line|cut -f1 -d" "`
  file=`echo $line|cut -f2 -d" "`
  remote_line=`ssh $ip "md5sum $path/$server/$file"`
  if [ -z "$remote_line" ]; then
    ((fail++))
    echo -e "\e[1;31m[FAIL] \e[0m${file}" 
    continue
  fi
  remote_md5str=`echo $remote_line|cut -f1 -d" "`
  if [ "$md5str" = "$remote_md5str" ]; then
    echo -e "\e[1;32m[ OK ] \e[0m${file}"
  else
    echo -e "\e[1;31m[FAIL] \e[0m${file}"
    ((fail++))
  fi
done

if [ $fail -eq 0 ];then
  exit 0
else
  exit 1
fi
