#!/bin/bash

function IndexLog {
  log_str=$1
  log_time=`date +"%Y-%m-%d %H:%M:%S"`
  echo "$log_time $log_str"
}

function NOTICE {
  log_str="NOTICE $1"
  IndexLog "$log_str"
}

function NOTICE_FOR_MAIL {
  log_str="[record for mail]$1"
  NOTICE "$log_str"
}

function FATAL {
  log_str="FATAL $1"
  IndexLog "$log_str"
}

function FATAL_FOR_MAIL {
  log_str="[record for mail]$1"
  FATAL "$log_str"
}

function WARNING {
  log_str="WARNING $1"
  IndexLog "$log_str"
}

function WARNING_FOR_MAIL {
  log_str="[record for mail]$1"
  WARNING "$log_str"
}

function TouchAlarmCore {
  touch core.$$
}
