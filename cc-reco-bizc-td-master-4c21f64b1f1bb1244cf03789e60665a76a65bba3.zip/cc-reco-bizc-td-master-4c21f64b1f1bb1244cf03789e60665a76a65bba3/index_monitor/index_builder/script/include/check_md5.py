#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from common import *

# 返回 其他server 的 md5 数组
def GetRemoteDirMd5OrDie(ip, path):
  status, output = GetCommandCodeAndOutput('ssh %s "ls %s"' %(ip, path));
  md5_dict = {}
  for line in output.split("\n"):
    file = line.strip()
    remote_status, remote_md5_output = GetCommandCodeAndOutput('ssh %s "md5sum %s"' %(ip, path + "/" + file))
    ########## trick, optimize it #######
    if remote_status != 0:
      continue
    #######################################
    list = remote_md5_output.split(" ")
    if remote_status != 0 or len(list) < 2:
      print "md5sum failed: %s:%s/%s" %(ip, path, file)
      sys.exit(1)
    md5_dict[file] = list[0]
  return md5_dict

# 检查 md5
def CheckMd5Dict(dict1, dict2):
  if len(dict1.items()) != len(dict2.items()):
    print "md5dict check failed: %d vs %d" %(len(dict1.items()), len(dict2.items()))
    return False

  for key, value in dict1.items():
    if not dict2.has_key(key):
      print "md5 dict check failed: %s not found" %(key)
      return False
    if (dict2[key] != value):
      print "md5 dict check failed: %s, %s vs %s" %(key, value, dict2[key])
      return False
  return True

if __name__ == "__main__":
  dict1 = GetRemoteDirMd5OrDie("10.99.56.16", "/serving/cdoc_convertor_server/wolong_bidword_server_index/");
  CheckMd5DictOrDie(dict1, dict1)
  dict2 = GetRemoteDirMd5OrDie("10.99.56.16", "/serving/cdoc_convertor_server/wolong_ad_server_index/");
  CheckMd5DictOrDie(dict1, dict2)

