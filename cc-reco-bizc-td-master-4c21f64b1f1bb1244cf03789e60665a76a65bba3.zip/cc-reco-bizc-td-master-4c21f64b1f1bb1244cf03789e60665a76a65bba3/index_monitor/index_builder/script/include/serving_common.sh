#!/bin/bash

# 在这里注册你的登录名和 serving 目录的 svn 路径, 样例见下
#declare -A known_hosts
#
#known_hosts["tianjia"]="124.205.102.34 56 ~/svnroot/wolong/serving"
#known_hosts["lintao"]="124.205.102.34 53 ~/svn/wly/wolong/serving"


# 重新启动 server
#
# reload_server IP 路径 server名
function reload_server() {
  ssh $1 "$2/$3/bin/lock_memory.sh reload; $2/$3/bin/load.sh reload"
}

# 对一行 server 配置进行处理，由 |iterate_over_machine_list| 调用
#
# iterate_over_line 脚本/函数名 整行
function iterate_over_line() {
  ip=`echo $2 | awk '{print $1}'`
  path=`echo $2 | awk '{print $2}'`
  
  for server in `echo $2|cut -f3- -d" "`; do
     $1 $ip $path $server
  done
}

# 对机器列表中的每个 server 三元组 （ip，路径，server 名）执行特定函数
# 三元组作为参数 $1 $2 $3 传给该函数
# NOTE(tianjia): 若是脚本则需要加 ./
#
# iterate_over_machine_list 机器列表文件 脚本/函数名
# e.g.
# iterate_over_machine_list machine_list.txt ./test.sh
# iterate_over_machine_list machine_list.txt test_iterate
function iterate_over_machine_list() {
  declare -A tmp
  count=0
  while read line; do
    echo $line | grep "^$" >/dev/null && continue
    echo $line | grep "^#" >/dev/null && continue
    tmp[$count]="$line"
    ((count++))
  done < $1

  for ((i=0;i<count;++i)); do
    iterate_over_line $2 "${tmp[$i]}"
  done
}

#. ./shflags.sh
#DEFINE_string name "world" "description" n
#FLAGS "$@" || exit $?
#eval set -- "${FLAGS_ARGV}"
#echo hello, ${FLAGS_name}!
