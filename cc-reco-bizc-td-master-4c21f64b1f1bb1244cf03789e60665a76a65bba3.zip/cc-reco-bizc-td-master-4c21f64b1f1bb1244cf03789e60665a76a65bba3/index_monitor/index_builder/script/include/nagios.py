#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, string, commands

# Current nagios configuration
nagios_server = "http://10.99.48.70/nagios/"
# nagios_server = "http://42.120.172.24/nagios/"
nagios_user = "nagiosadmin:nagiosadmin"
nagios_api_disable = "cgi-bin/cmd.cgi?cmd_typ=23&cmd_mod=2&btnSubmit=%E7%A1%AE%E5%AE%9A&service={service}&host={host}"
nagios_api_enable = "cgi-bin/cmd.cgi?cmd_typ=22&cmd_mod=2&btnSubmit=%E7%A1%AE%E5%AE%9A&service={service}&host={host}"

nagios_servers = {
'leaf_server':['leaf_server','leaf_server_core'],
'user_server':['user_server','user_server_core'],
'click_server':['click_server','click_server_core'],
'sim_server':['sim_server','sim_server_core'],
}

# nagios_servers = {'ui_server':['ui_server_6090','ui_server_core'],
# 'root_server':['root_server_3090','root_server_core'],
# 'bidword_server':['bidword_server_7090','bidword_server_core'],
# 'ad_server':['ad_server_4090','ad_server_core'],
# 'intent_server':['intent_server_2090','intent_server_core'],
# 'db_monitor':['db_monitor_14090','db_monitor_core'],
# 'cdoc_convertor_server':['cdoc_convertor_16090','cdoc_convertor_core'],
# 'redirect_server':['redirect_server_10090','redirect_server_core'],
# 'antispam_server':['antispam_server_8090','antispam_server_core'],
# 'charge_server':['charge_server_15090','charge_server_core'],
# 'kr_server':['kr_server_counter_12090','kr_server_core'],
# 'config_server':['message_queue_meta_server_1999','message_queue_meta_server_core'],
# 'message_queue_server':['message_queue_node_server_1315','message_queue_node_server_core'],
# 'yellow_page_web_server':['yellow_page_web_server_counter_12090','yellow_page_web_server_core'],
# }

def CallNagiosApi(api, host, service):
  s = string.replace(api, "{host}", host);
  url = nagios_server + string.replace(s, "{service}", service);
  command = "curl --user \"" + nagios_user + "\" '" + url + "' &>/dev/null";
  # print command
  return os.system(command);

def Colorize(s, color_code):
  return '\x1b[1;' + str(color_code) + 'm' + s + '\x1b[0m';

def Red(s):
  return Colorize(s, 31);

def Green(s):
  return Colorize(s, 32);

def Yellow(s):
  return Colorize(s, 33);

def Purple(s):
  return Colorize(s, 35);

def DisableNagiosService(host, service):
  '''Disables |service| notification on |server| '''
  result = CallNagiosApi(nagios_api_disable, host, service)
  print Red('Disable') + ' Nagios service ' + Yellow(service) + ' on ' + Purple(host) + " result:%d"%result;
  return result;

def EnableNagiosService(host, service):
  '''Enables |service| notification on |server|'''
  result = CallNagiosApi(nagios_api_enable, host, service);
  print Green('Enable') + ' Nagios service ' + Yellow(service) + ' on ' + Purple(host) + " result:%d"%result;
  return result;

def DisableNagios(host, server):
  '''Disables all services enlisted under |server| on |host|'''
  if server in nagios_servers:
    for service in nagios_servers[server]:
      DisableNagiosService(host, service);

def DisableNagiosByIp(ip, server):
  DisableNagios(GetHostNameByIp(ip), server);

def EnableNagios(host, server):
  '''Enables all services enlisted under |server| on |host|'''
  if server in nagios_servers:
    for service in nagios_servers[server]:
      EnableNagiosService(host, service);

def EnableNagiosByIp(ip, server):
  EnableNagios(GetHostNameByIp(ip), server);

def ScheduleNagiosDownTime(host, server):
  '''Schedules a period for the server to shutdown'''
  #TODO(tianjia): implement it

def GetHostName():
  '''Return short host name. example: r63f19036.cm10'''
  [ret, host_name] = commands.getstatusoutput('hostname');
  return host_name;

def GetHostNameByIp(ip):
  '''Return short host name in taobao. NOT a general solution'''
  try:
    [ret, host_name] = commands.getstatusoutput('host ' + ip);
    full_name = host_name.split(' ')[-1];
    domains = full_name.split('.');
    short_name = domains[0] + '.' + domains[1];
  except:
    return "rb3d17020.cm8"
  return short_name

if __name__ == "__main__":
  DisableNagios(GetHostName(), 'ad_server');
  EnableNagios(GetHostName(), 'ad_server');
  print GetHostNameByIp('8.8.8.8');
