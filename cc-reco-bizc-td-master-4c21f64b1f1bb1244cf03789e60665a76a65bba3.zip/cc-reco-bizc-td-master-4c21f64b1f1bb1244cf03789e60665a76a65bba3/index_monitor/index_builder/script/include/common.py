#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, commands, copy, datetime, sys
from include.logging import *

# 如果 DEBUG 为 True, 只打印命令, 不执行
DEBUG = False

# 返回 server name 的数组
def GetWolongServerNameList(filename):
  result = [];
  server_name_list_file = open(filename);
  for line in server_name_list_file:
    # 去掉空行和注释行
    line = line.strip()
    if (len(line) == 0 or line[0] == '#'): continue
    result.append(line)
  return result

# 根据配置文件, 返回需要部署的 server 数组, 数组每个元素是个 3 元组 (ip, path, server name) e.g.
# [[('10.147.128.39', '/serving/', 'ui_server'), ('10.147.128.39', '/serving/', 'intent_server')]
def GetWolongServerList(filename):
  result = [];
  server_list_file = open(filename);
  for line in server_list_file:
    # 去掉空行和注释行
    line = line.strip()
    if (len(line) == 0 or line[0] == '#'): continue

    fields = line.split(' ')
    if (len(fields) < 3):
      print "error line: " + line
      continue
    ip = fields[0];
    path = fields[1];
    for server_name in fields[2:]:
      result.append((ip, path, server_name));
  return result

# 根据 |server_name| 筛选出符合条件的 server 数组, 以逗号分隔
def FilterServerListByName(server_list, server_name):
  if server_name == "" or server_name == None:
    return copy.deepcopy(server_list);
  result = [];
  name_filter = server_name.split(',');
  for server in server_list:
    if server[2] in name_filter:
      result.append(server);
  return result;

# 根据 |server_name| 筛选出符合条件的 server 数组, 以逗号分隔
def FilterServerNameListByName(server_list, server_name):
  if server_name == "" or server_name == None:
    return copy.deepcopy(server_list);
  result = [];
  name_filter = server_name.split(',');
  for server in server_list:
    if server in name_filter:
      result.append(server);
  return result;

# 获取一个目录底下的所有文件, 返回 dirname 的路径
def GetFiles(dirname):
  result = []
  if (os.path.isdir(dirname)):
    for item in os.listdir(dirname):
      sub_dir = os.path.join(dirname, item)
      if (os.path.isdir(sub_dir)):
        sub_result = GetFiles(sub_dir)
        for sub_item in sub_result:
          result.append(item + "/" + sub_item);
      else:
        result.append(item)
  return result

def ReadConfig(filename):
  result = {}
  config_file = open(filename);
  for line in config_file:
    # 去掉空行和注释行
    line = line.strip()
    if len(line) == 0 or line[0] == '#': continue

    fields = line.split('=', 1)
    if len(fields) == 2: result[fields[0]] = fields[1];

  return result

def PrintLog(log):
  print "[%s] %s" %(datetime.datetime.now().strftime("%Y%m%d %H:%M:%S"), log)

def GetCommandCode(command):
  PrintLog(command)
  if DEBUG:
    return 0
  return os.system(command)

def ExecuteCommand(command):
  PrintLog(command)
  if DEBUG:
    return
  os.system(command)
  # return commands.getstatusoutput(command)

def GetCommandCodeAndOutput(command):
  PrintLog(command)
  if DEBUG:
    return 0, "asdf"
  return commands.getstatusoutput(command)

def ConfigCheck(conf_name, conf_value):
  if not conf_value.strip():
    FATAL_FOR_MAIL(conf_name + ' is null')
    TouchAlarmCore()
    sys.exit(1)

def ExecuteScript(cmd):
  NOTICE(cmd + ' start')
  status, ret = GetCommandCodeAndOutput(cmd)
  print ret
  if status != 0:
    FATAL(cmd + ' fail')
    return False
  NOTICE(cmd + ' end')
  return True

def FileExists(file):
  if not os.path.exists(file):
    FATAL("%s is not exists" % file)
    return False
  return True


if __name__ == "__main__":
  print GetWolongServerList("server_list.txt")
  print GetFiles("../env")
  list = GetWolongServerList("server_list.txt")
  print FilterServerListByName(list, "ui_server,ad_server");
