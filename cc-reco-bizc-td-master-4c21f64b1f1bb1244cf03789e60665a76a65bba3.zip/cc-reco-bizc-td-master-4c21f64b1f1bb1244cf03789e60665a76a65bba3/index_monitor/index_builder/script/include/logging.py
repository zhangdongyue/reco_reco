#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, commands, datetime

def IndexLog(log_str):
  dt = datetime.datetime.now()
  log_time = dt.strftime('%Y-%m-%d %H:%M:%S')
  print log_time + ' ' + log_str

def NOTICE(log_str):
  log_str = 'NOTICE ' + log_str
  IndexLog(log_str)

def NOTICE_FOR_MAIL(log_str):
  log_str = '[record for mail]' + log_str
  NOTICE(log_str)

def WARNING(log_str):
  log_str = 'WARNING ' + log_str
  IndexLog(log_str)

def WARNING_FOR_MAIL(log_str):
  log_str = '[record for mail]' + log_str
  WARNING(log_str)

def FATAL(log_str):
  log_str = 'FATAL ' + log_str
  IndexLog(log_str)

def FATAL_FOR_MAIL(log_str):
  log_str = '[record for mail]' + log_str
  FATAL(log_str)

def TouchAlarmCore():
  core_name = os.getcwd() + '/core.' + str(os.getpid())
  open(core_name, "w+").close()


if __name__ == "__main__":
  log_str = 'no care'
  IndexLog(log_str)
  NOTICE(log_str)
  NOTICE_FOR_MAIL(log_str)
  WARNING(log_str)
  WARNING_FOR_MAIL(log_str)
  FATAL(log_str)
  FATAL_FOR_MAIL(log_str)
  TouchAlarmCore()
