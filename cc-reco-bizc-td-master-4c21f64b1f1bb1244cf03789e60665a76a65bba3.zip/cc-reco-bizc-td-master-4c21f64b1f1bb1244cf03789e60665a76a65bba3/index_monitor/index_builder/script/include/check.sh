#!/bin/bash

rm -rf fail_list

cat $1 | while read line
do
  echo "processing $line"
  cat index_md5sum | sh check_md5sum.sh $line /serving leaf_server
  res=$?
  if [ $res -ne 0 ]; then
    echo $line >> fail_list
  fi
done
