from include import gflags

gflags.DEFINE_string("builder_template", "index_builder.flags.template",
                     "config index builder flags template")
gflags.DEFINE_string("builder_flags", "index_builder.flags", "config index builder flags")
gflags.DEFINE_string("update_template", "index_update.conf.template",
                     "config index update conf template")
gflags.DEFINE_string("update_conf", "index_update.conf", "config index update conf")
gflags.DEFINE_bool("convert_reco_item", False, "true: item keeper renew, false: only read")
gflags.DEFINE_string("em21_hadoop_dir", "", "em21 hadoop dir")
gflags.DEFINE_string("su18_hadoop_dir", "", "su18 hadoop dir")

gflags.DEFINE_string("dump_date", "", "dump date")
gflags.DEFINE_string("module", "", "module dir")

gflags.DEFINE_string("commands", "", "commands")
gflags.DEFINE_string("machine_conf", "", "deploy for machine conf")
FLAGS = gflags.FLAGS
