#!/bin/bash

rm -rf index_md5sum

for file in `ls $1`;
do
  if [ -f $1"/"$file ] && [ $file != "dump_timestamp.dat" ]; then
    echo $1"/"$file;
    res=$(md5sum $1"/"$file);
    out=${res/$1\//dynamic_index\/};
    echo $out >> index_md5sum;
  fi
done
