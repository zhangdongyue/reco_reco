#!/usr/bin/python
# -*- coding:utf-8 -*-
import os
import urllib
import time
sendsms(title, receiver):
    url = 'http://10.147.128.136:20080/sms/?phone=%s&sms=%s' %(receiver, title)
    fd = urllib.urlopen(url)
