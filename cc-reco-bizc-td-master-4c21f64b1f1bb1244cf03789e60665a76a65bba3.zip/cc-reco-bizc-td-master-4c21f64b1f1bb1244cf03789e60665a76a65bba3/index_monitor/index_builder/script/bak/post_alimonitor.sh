#!/bin/bash

basedir="$0"
oper="$1"
server_ip="$2"

time_date=`date '+%Y%m%d'`
pe_key="0f3b224e86e5111a64109bf0ae18aa8f"
pe_name="luping.yulp"
date_buff=`printf ''$pe_name''$time_date''$pe_key''|md5sum`
api_key=`echo "$date_buff"|awk '{print $1}'`

#if ( [[ -s $oper ]] && [[ -s $server_ip ]] );then
#  if ( [[  $oper = enable ]] || [[ $oper = disable ]] );then
#    echo "format is right"
#  else
#    echo "----Format error"
#    echo "----For example1,sh $basedir enable|disable server_ip "
#    echo "---------------------------"
#    exit 1
#  fi
#else
#  echo "----Format error"
#  echo "----For example2, sh $basedir enable|disable server_ip "
#  echo "---------------------------"
#  exit 1
#fi

monitor_server="http://api.m.alibaba-inc.com"
api_url="/monitor/api/monitorNoticeSwitch.rdo?"

fixed_url="${monitor_server}${api_url}_username=${pe_name}&_key=${api_key}&scopeType=1"

if [ "$oper" = "enable" ] ;then
   mobile_url="&scope=${server_ip}&act=1"
   all_url="${fixed_url}${mobile_url}" 
   curl  $all_url
elif [ "$oper" = "disable" ] ;then
   mobile_url="&scope=${server_ip}&act=0&afterTime=60&message=stop_monitor"
   all_url="${fixed_url}${mobile_url}"
   curl $all_url
else
  echo 'Input error'
  echo 'please enter  "enable"  or "disable"'
fi

