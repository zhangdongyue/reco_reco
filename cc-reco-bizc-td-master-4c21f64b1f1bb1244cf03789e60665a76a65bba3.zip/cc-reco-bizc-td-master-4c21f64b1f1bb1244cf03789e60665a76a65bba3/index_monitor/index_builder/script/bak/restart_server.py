#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
定时任务: 批量索引拷贝到线上server，使其重新加载新索引
具体步骤参考代码中的注释
配置文件见环境下的 config/index_updater.flags
NOTE(jianhuang) 这里面不关报警，报警在外边统一关闭
'''

import os, sys, commands, datetime, time
import threading
import socket
from include import gflags
from include.common import *
from include.check_md5 import *
from include.nagios import *

gflags.DEFINE_string("config_filename", "config/index_updater.flags", "config file of env");
gflags.DEFINE_string("server_list_filename", "config/machine.reco", "server list filename in env_path");
FLAGS = gflags.FLAGS

today_date = datetime.datetime.now().strftime("%Y-%m-%d")

class UpdateIndexThread(threading.Thread):
  def __init__(self, server_list, em21_hadoop_dir, source_index_md5_dict):
    threading.Thread.__init__(self)
    self.server_list = server_list
    self.em21_hadoop_dir = em21_hadoop_dir
    self.source_index_md5_dict = source_index_md5_dict

  def run(self):
    flag = True
    for server in self.server_list:
      self.server_ip = server[0]
      self.server_path = server[1]
      flds = server[2].split(":")
      if len(flds) != 2:
        print "error server line", server
        continue
      self.server_name = flds[0]
      self.port = ""
      if self.server_name == "leaf_server":
        self.port = "20001"
      flag = self.single_run()
      if flag is True: 
        print "succ to update index, ", self.server_ip, self.server_path, self.server_name
      else:
        print "fail to update index, ", self.server_ip, self.server_path, self.server_name
        break

    return flag 

  def check_service(self):
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    max_retry = 20
    retry = 0
    while retry < max_retry:
      retry += 1
      try:
   	s.connect((self.server_ip,int(self.port))) 
        s.shutdown(2)
	print 'server:%s succ to open port:%s' % (self.server_ip, self.port)
        return True
      except:
        print 'wait server to reload, %s:%s, retry:%d' % (self.server_ip, self.port, retry)
        time.sleep(30)
        continue
    print 'server:%s fail to open port:%s' % (self.server_ip, self.port)
    return False

  def single_run(self):
    print "start ", self.server_ip, self.port, self.server_path, self.server_name
    # 下载索引 
    ExecuteCommand('ssh %s "mkdir -p %s/%s/new_dynamic_index"'
                   %(self.server_ip, self.server_path, self.server_name));
    ExecuteCommand('ssh %s "rm -rf %s/%s/new_dynamic_index/*"'
                   %(self.server_ip, self.server_path, self.server_name));
    ExecuteCommand('ssh %s "/serving/hadoop/hadoop-2.6.0/bin/hadoop fs -get %s/%s/* %s/%s/new_dynamic_index/"'
                   %(self.server_ip, self.em21_hadoop_dir, today_date, self.server_path, self.server_name));
    # 检查 md5
    index_md5_dict = GetRemoteDirMd5OrDie(self.server_ip, self.server_path + "/" + self.server_name + "/new_dynamic_index")
    CheckMd5DictOrDie(index_md5_dict, self.source_index_md5_dict)
    # 更新索引并重启服务
    ExecuteCommand('ssh %s "bash -x %s/%s/bin/load.sh stop && sleep 2"'
                    %(self.server_ip, self.server_path, self.server_name));
    ExecuteCommand('ssh %s "mkdir -p %s/%s/old_dynamic_index"'
		   %(self.server_ip, self.server_path, self.server_name));
    ExecuteCommand('ssh %s "rm -rf %s/%s/old_dynamic_index/*"'
                   %(self.server_ip, self.server_path, self.server_name));
    ExecuteCommand('ssh %s "mv %s/%s/dynamic_index/* %s/%s/old_dynamic_index/"'
                   %(self.server_ip, self.server_path, self.server_name, self.server_path, self.server_name));
    ExecuteCommand('ssh %s "mv %s/%s/new_dynamic_index/* %s/%s/dynamic_index/"'
                   %(self.server_ip, self.server_path, self.server_name, self.server_path, self.server_name));
    ExecuteCommand('ssh %s "bash -x %s/%s/bin/load.sh start && sleep 2"'
                    %(self.server_ip, self.server_path, self.server_name));
    # time.sleep(60);
    flag = True
    if self.port == "": 
      time.sleep(300);
    else:
      flag = self.check_service()
    return flag

def main(argv):
  try:
    argv = FLAGS(argv)
  except gflags.FlagsError, e:
    print "%s\nUsage: %s [flags]\n%s" %(e, sys.argv[0], FLAGS);
    sys.exit(1);

  if not os.path.exists(FLAGS.config_filename):
    print "path not exist:", FLAGS.config_filename;
    print "Usage: %s [flags]\n%s" %(sys.argv[0], FLAGS);
    sys.exit(1);
  if not os.path.exists(FLAGS.server_list_filename):
    print "path not exist:", FLAGS.server_list_filename;
    print "Usage: %s [flags]\n%s" %(sys.argv[0], FLAGS);
    sys.exit(1);

  # 读取配置信息
  config = ReadConfig(FLAGS.config_filename);

  if 'index_builder_host' not in config:
    print "index builder host not found in config"
    sys.exit(1)
  index_builder_host = config['index_builder_host']

  if 'index_root' not in config:
    print "index root not found in config"
    sys.exit(1)
  index_dir = config['index_root'] + "/" + today_date;

  if 'em21_hadoop_dir' not in config:
    print "index hadoop dir not found in config";
    sys.exit(1);
  em21_hadoop_dir = config['em21_hadoop_dir']

  # source inde md5
  source_index_md5_dict = GetRemoteDirMd5OrDie(index_builder_host, index_dir)

  # 更新每个server的 index
  server_list = GetWolongServerList(FLAGS.server_list_filename);
  server_groups = {}
  for server in server_list:
    print server
    server_ip = server[0]
    server_path = server[1]
    flds = server[2].split(":")
    if len(flds) != 2:
      print "error server line", server
      continue
    server_name = flds[0]
    server_group = flds[1]
    if not server_groups.has_key(server_group):
      server_groups[server_group] = []
    server_groups[server_group].append(server)

  # group 间的 server 并发更新
  thread_list = []
  for group_id, group in server_groups.items():
    print "update index for group: ", group_id
    thread_list.append(UpdateIndexThread(server_list = group, em21_hadoop_dir = em21_hadoop_dir, source_index_md5_dict = source_index_md5_dict))
  for thread in thread_list:
    thread.start()
    time.sleep(1)
  for thread in thread_list:
    thread.join()

  time.sleep(60)
  print "Update all reco index finish."

  sys.exit(0);

if __name__ == "__main__":
  main(sys.argv)
