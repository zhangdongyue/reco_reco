#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, commands, datetime, time
# sys.path.append("../..")
from include import gflags
from include.common import *
from include.check_md5 import *
from include.nagios import *

gflags.DEFINE_string("server_list_filename", "config/machine.reco", "server list filename in env_path");
FLAGS = gflags.FLAGS

def main(argv):
  try:
    argv = FLAGS(argv)
  except gflags.FlagsError, e:
    print "%s\nUsage: %s [flags]\n%s" %(e, sys.argv[0], FLAGS);
    sys.exit(1);

  if not os.path.exists(FLAGS.server_list_filename):
    print "path not exist:", FLAGS.server_list_filename;
    print "Usage: %s [flags]\n%s" %(sys.argv[0], FLAGS);
    sys.exit(1);
  
  today_date = datetime.datetime.now().strftime("%Y-%m-%d");

  # 所有 server 进行回滚
  server_list = GetWolongServerList(FLAGS.server_list_filename);
  for server in server_list:
    server_ip = server[0]
    server_path = server[1]
    server_name = server[2]
    print server_ip, server_path, server_name

    #  回滚索引
    ExecuteCommand('ssh %s "rm -rf %s/%s/new_dynamic_index/*"'
                   %(server_ip, server_path, server_name));
    ExecuteCommand('ssh %s "mv %s/%s/old_dynamic_index/* %s/%s/new_dynamic_index/"'
                   %(server_ip, server_path, server_name, server_path, server_name));

    # 替换 server 的 index，并重启 server
    ExecuteCommand('ssh %s "bash -x %s/%s/bin/update_index.sh"'
                    %(server_ip, server_path, server_name));
    time.sleep(300);

    # 关闭报警并重启
    # DisableNagios(GetHostNameByIp(server_ip), server_name);
    # print "Sleeping 180s for Nagios shutdown"
    # time.sleep(180);
    # ExecuteCommand('ssh %s "bash -x %s/%s/bin/update_dynamic_index.sh"'
    #                 %(server_ip, server_path, server_name));
    # time.sleep(300);
    # EnableNagios(GetHostNameByIp(server_ip), server_name);
  sys.exit(0);

if __name__ == "__main__":
  main(sys.argv)
