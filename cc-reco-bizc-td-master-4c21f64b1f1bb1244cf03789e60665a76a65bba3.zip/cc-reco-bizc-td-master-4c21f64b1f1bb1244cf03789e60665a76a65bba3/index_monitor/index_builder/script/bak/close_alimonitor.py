#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, commands, datetime, time
# sys.path.append("../..")
from include import gflags
from include.common import *
from include.check_md5 import *
from include.nagios import *

gflags.DEFINE_string("server_list_filename", "config/machine.alarm", "server list filename in env_path");
FLAGS = gflags.FLAGS

def main(argv):
  try:
    argv = FLAGS(argv)
  except gflags.FlagsError, e:
    print "%s\nUsage: %s [flags]\n%s" %(e, sys.argv[0], FLAGS);
    sys.exit(1);

  if not os.path.exists(FLAGS.server_list_filename):
    print "path not exist:", FLAGS.server_list_filename;
    print "Usage: %s [flags]\n%s" %(sys.argv[0], FLAGS);
    sys.exit(1);

  # 统一关闭待操作机器的报警
  print "Begin to shutdow Alarm."
  server_list = GetWolongServerList(FLAGS.server_list_filename);
  for server in server_list:
    server_ip = server[0]
    ExecuteCommand('bash -x ./bin/post_alimonitor.sh disable %s' %(server_ip));
    time.sleep(1)
  time.sleep(30);
  print "Succ to shutdow Alarm."

  sys.exit(0);

if __name__ == "__main__":
  main(sys.argv)
