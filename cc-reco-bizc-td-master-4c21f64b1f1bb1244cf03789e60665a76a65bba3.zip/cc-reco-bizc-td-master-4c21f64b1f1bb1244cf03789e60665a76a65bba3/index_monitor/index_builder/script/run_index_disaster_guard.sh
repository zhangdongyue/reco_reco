
# 如果不需要分发ha3, 一定将 deploy_ha3 从 commands 里删掉
# 如果不需要分发cdoc, 一定将 deploy_cdoc 从 commands 里删掉
# 做实验时一定记得修改 hadoop 的上传目录为自己的目录, 避免影响线上数据
# 做实验时一定记得将convert_reco_item设置为 False ,只读 item-keeper
# 分发的机器由 machine_conf 配置
# 中间数据和结果数据都放在 module 设置的目录下,这是为了常规建库和容灾建库能共用一套环境,保证一致性

#!/bin/bash

source include/logging.sh

cur_time=`date +"%Y%m%d%H"`
dump_date=`date +"%Y-%m-%d-%H"`
commands=good_mine,media_info,media_level,build_index,upload_cdoc

while getopts "d:c:" opt; do
  case $opt in
    c )
      commands="$OPTARG"
      ;;
    d )
      dump_date="$OPTARG"
      ;;
    ? )
      echo "error opts, help:"
      echo "c: commands"
      echo "d: dump_date, default today"
      exit 1
      ;;
  esac
done

python -u index_builder.py --dump_date=$dump_date \
                        --module=disater \
                        --convert_reco_item=False \
                        --em21_hadoop_dir=/user/serving/disaster_gz/leaf_index \
                        --su18_hadoop_dir=/su18/serving/disaster_sz/leaf_index \
                        --commands=$commands > log/cron.log.$cur_time 2>&1
if [ $? -ne 0 ]; then
  FATAL_FOR_MAIL "python index_builder.py fail."
  TouchAlarmCore
fi

seven_day_ago=`date -d '-7 days '${cur_time:0:8}'' +"%Y%m%d"`
rm -f log/cron.log.${seven_day_ago}*

python send_mail.py --log_file_name="log/cron.log.$cur_time" --subject="[容灾索引]例行建库"

