#include <stdio.h>
#include <vector>
#include <unordered_map>      
#include <utility>
#include <set>                
#include <string>             
#include <map>             

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/common/base.h" 
#include "base/time/time.h"

#include "reco/bizc/index_monitor/index_builder/dao/ChannelEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/dao/ItemChannelEntityDao.h"


class ItemChannelEntityDaoTest : public testing::Test {
 protected:
  virtual void SetUp() {
  }

  virtual void TearDown() {
  }
};

TEST_F(ItemChannelEntityDaoTest, Test_getValidItemsByChannel) {
  std::map<uint64, int> channel_map;
  //健康
  channel_map.insert(std::make_pair(472933935, 15));
  //历史
  channel_map.insert(std::make_pair(701104723, 15));
  //干货
  channel_map.insert(std::make_pair(1911322354, 15));
  //时尚
  channel_map.insert(std::make_pair(1213442674, 15));
  //游戏
  channel_map.insert(std::make_pair(169476544, 15));
  //育儿
  channel_map.insert(std::make_pair(408250330, 15));
  //逗比
  channel_map.insert(std::make_pair(1670553277, 15));
  //闺房
  channel_map.insert(std::make_pair(1099189934, 15));
  //旅游
  channel_map.insert(std::make_pair(1972619079, 15));
  //健身
  channel_map.insert(std::make_pair(674534, 15));
  //美女
  channel_map.insert(std::make_pair(1404457531633l, 30));
  //萌宠
  channel_map.insert(std::make_pair(10003, 30));
  //摄影
  channel_map.insert(std::make_pair(10004, 30));
  //动漫
  channel_map.insert(std::make_pair(10012, 30));
  //问啊
  channel_map.insert(std::make_pair(1211676, 180));

  ChannelEntityDao channel_dao;
  ItemChannelEntityDao item_channel_dao;
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = "tcp://11.251.203.145:3306";
  db_option.schema = "reco";
  db_option.user = "recodev";
  db_option.passwd = "tkDn19DHeVZkNA";
  channel_dao.Init(db_option);
  item_channel_dao.Init(db_option);

  std::vector<ChannelEntity> channel_list;
  channel_dao.getChannels(&channel_list);
  EXPECT_GT(channel_list.size(), (size_t)0);

  printf("size of channel_list is : %d\n", (int)channel_list.size());

  base::Time current_time = base::Time::Now();
  base::Time::Exploded exploded;
  current_time.LocalExplode(&exploded);
  exploded.hour = 0;
  exploded.minute = 0;
  exploded.second = 0;
  exploded.millisecond = 0;
  base::Time start_of_day_time = base::Time::FromLocalExploded(exploded);

  for (size_t i = 0; i < channel_list.size() && i < 10; ++i) {
    ChannelEntity& channel = channel_list.at(i);
    printf("NO.%d: %s\n",(int)i, channel.to_string().c_str());

    int expire_day = 7;
    auto it = channel_map.find(channel.get_id());
    if (it != channel_map.end()) {
      expire_day = it->second;
    }
    base::Time min_publish_time = start_of_day_time - base::TimeDelta::FromDays(expire_day);
    std::vector<ItemChannelEntity> item_list;
    std::string time_stamp;
    min_publish_time.ToStringInSeconds(&time_stamp);
    item_channel_dao.getValidOPItemsByChannel(channel.get_id(), time_stamp, 40000, &item_list);

    printf("size of item_list is : %d\n", (int)item_list.size());

    for (size_t j = 0; j < item_list.size() && j < 10; ++j) {
      printf("NO.%d: %s\n",(int)j, item_list.at(j).to_string().c_str());
    }
  }
}



