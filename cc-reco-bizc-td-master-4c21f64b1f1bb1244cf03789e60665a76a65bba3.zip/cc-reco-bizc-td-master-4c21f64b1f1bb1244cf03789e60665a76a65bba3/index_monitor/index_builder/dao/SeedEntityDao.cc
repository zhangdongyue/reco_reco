#include "reco/bizc/index_monitor/index_builder/dao/SeedEntityDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

DEFINE_string(seed_table, "tb_seed", "seed table name");


void SeedEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void SeedEntityDao::getAllSeedList(std::vector<SeedEntity>* seed_list) {
  CHECK_NOTNULL(seed_list);
  TimeConsume timeConsume("SeedEntityDao_getAllSeedList");
  std::string sql = base::StringPrintf("select id,name,url,create_time,dev_config,crawl_status,"
    "publish_status,authority_score,politics_sensitivity,sex_sensitivity,seed_icon_remark from %s",
    FLAGS_seed_table.c_str());

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      serving_base::Timer timer;
      timer.Start();
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      LOG(INFO) << "SeedEntityDao_getAllSeedList_sql_cost:" << timer.Stop();
      
      seed_list->clear();

      timer.Start();
      while (res->next()) {
        SeedEntity entity;
        seed_list->push_back(entity);
        if (!BuildSeedEntityFromResult(res.get(), seed_list->back())) {
          seed_list->pop_back();
        }
      }
      LOG(INFO) << "SeedEntityDao_getAllSeedList_handle_cost:" << timer.Stop() << ", num:" << res->getRow();
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

bool SeedEntityDao::BuildSeedEntityFromResult(sql::ResultSet* res, SeedEntity& ent) {
  CHECK_NOTNULL(res);
  try {
    uint64 id = res->getUInt64("id");
    ent.set_id(id);

    std::string name = res->getString("name");
    ent.set_name(name);

    double create_time_val = (double)res->getInt("create_time");
    base::Time create_time = base::Time::FromDoubleT(create_time_val);
    ent.set_create_time(create_time);

    std::string url = res->getString("url");
    ent.set_url(url);

    std::string dev_config = res->getString("dev_config");
    ent.set_dev_config(dev_config);

    int crawl_status = res->getInt("crawl_status");
    ent.set_crawl_status(crawl_status);

    int publish_status = res->getInt("publish_status");
    ent.set_publish_status(publish_status);

    int authority_score = res->getInt("authority_score");
    ent.set_authority_score(authority_score);

    int politics_sensitivity = res->getInt("politics_sensitivity");
    ent.set_politics_sensitivity(politics_sensitivity);

    int sex_sensitivity = res->getInt("sex_sensitivity");
  ent.set_sex_sensitivity(sex_sensitivity);

  std::string seed_icon_remark = res->getString("seed_icon_remark");
  ent.set_seed_icon_remark(seed_icon_remark);
  } catch (...) {
    LOG(ERROR) << "build seed entity fail.";
    return false;
  }
  return true;
}
