#include <stdio.h>
#include <vector>
#include <unordered_map>      
#include <utility>
#include <set>                
#include <string>             
#include <map>             

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/common/base.h" 
#include "base/time/time.h"

#include "reco/bizc/index_monitor/index_builder/dao/JingpinItemEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/entity/ItemInfoEntity.h"


class JingpinItemEntityDaoTest : public testing::Test {
 protected:
  virtual void SetUp() {
  }

  virtual void TearDown() {
  }
};

TEST_F(JingpinItemEntityDaoTest, Test_getJingpinVideoInfoByCreatetime) {

  JingpinItemEntityDao jingpin_dao;
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = "tcp://11.251.203.145:3306";
  db_option.schema = "reco";
  db_option.user = "recodev";
  db_option.passwd = "tkDn19DHeVZkNA";
  jingpin_dao.Init(db_option);

  base::Time current_time = base::Time::Now();
  base::Time min_publish_time = current_time - base::TimeDelta::FromDays(60);
  std::string now;
  current_time.ToStringInSeconds(&now);
  std::string start_time;
  min_publish_time.ToStringInSeconds(&start_time);
  std::vector<ItemInfoEntity> info_list;
  jingpin_dao.getJingpinItemInfoByCreatetime(start_time, now, 100000, &info_list);
  EXPECT_GT(info_list.size(), (size_t)0);

  printf("size of jingpin video info_list is : %d\n", (int)info_list.size());

  for (size_t j = 0; j < info_list.size() && j < 10; ++j) {
    printf("NO.%d: %s\n",(int)j, info_list.at(j).to_string().c_str());
  }
}

