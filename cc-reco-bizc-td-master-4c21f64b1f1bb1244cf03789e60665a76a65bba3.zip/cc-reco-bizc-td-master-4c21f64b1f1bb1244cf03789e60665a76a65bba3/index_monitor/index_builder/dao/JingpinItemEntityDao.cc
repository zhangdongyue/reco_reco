#include "reco/bizc/index_monitor/index_builder/dao/JingpinItemEntityDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

DEFINE_string(jingpin_table, "tb_jingpin_video", "jingpin table name");
DECLARE_string(item_info_table);


void JingpinItemEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void JingpinItemEntityDao::getJingpinItemByCreatetime(std::string start_time, std::string end_time,
                                        int max_size, std::vector<JingpinItemEntity>* item_list) {
  CHECK_NOTNULL(item_list);
  TimeConsume timeConsume("JingpinItemEntityDao_getJingpinItemByCreatetime");
  std::string sql = base::StringPrintf("select id,item_id from %s "
                    "where create_time >= \"%s\" and create_time <= \"%s\" "
                    "and status != 2 order by create_time desc limit %d", FLAGS_jingpin_table.c_str(),
                    start_time.c_str(), end_time.c_str(), max_size);

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      
      item_list->clear();
      
      while (res->next()) {
        JingpinItemEntity entity;
        item_list->push_back(entity);
        if (!BuildJingpinItemEntityFromResult(res.get(), item_list->back())) {
          item_list->pop_back();
        }
      }
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

void JingpinItemEntityDao::getJingpinItemInfoByCreatetime(std::string start_time, std::string end_time,
                                                      int max_size, std::vector<ItemInfoEntity>* info_list) {
  CHECK_NOTNULL(info_list);
  TimeConsume timeConsume("JingpinItemEntityDao_getJingpinItemInfoByCreatetime");
  std::string sql = base::StringPrintf("select %s.id as id, %s.item_id as item_id,"
                    "%s.item_type as item_type "
                    "from %s inner join %s "
                    "on %s.item_id = %s.item_id "
                    "where %s.create_time >= \"%s\" and %s.create_time <= \"%s\" "
                    "and %s.status != 2 "
                    "order by %s.create_time desc limit %d",
                    FLAGS_item_info_table.c_str(),
                    FLAGS_item_info_table.c_str(),
                    FLAGS_item_info_table.c_str(),
                    FLAGS_jingpin_table.c_str(),
                    FLAGS_item_info_table.c_str(),
                    FLAGS_jingpin_table.c_str(),
                    FLAGS_item_info_table.c_str(),
                    FLAGS_item_info_table.c_str(),
                    start_time.c_str(),
                    FLAGS_item_info_table.c_str(),
                    end_time.c_str(),
                    FLAGS_jingpin_table.c_str(),
                    FLAGS_item_info_table.c_str(),
                    max_size);

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      serving_base::Timer timer;
      timer.Start();
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      LOG(INFO) << "JingpinItemEntityDao_getJingpinItemInfoByCreatetime_sql_cost:" << timer.Stop();
      info_list->clear();

      timer.Start();
      while (res->next()) {
        ItemInfoEntity entity;
        info_list->push_back(entity);
        if (!BuildItemInfoEntityFromResult(res.get(), info_list->back())) {
          info_list->pop_back();
        }
      }
      LOG(INFO) << "JingpinItemEntityDao_getJingpinItemInfoByCreatetime_handle_cost:"
                << timer.Stop() << ", num:" << res->getRow();
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

bool JingpinItemEntityDao::BuildJingpinItemEntityFromResult(sql::ResultSet* res, JingpinItemEntity& ent) {
  CHECK_NOTNULL(res);
  
  uint64 id = res->getUInt64("id");
  ent.set_id(id);

  std::string item_id = res->getString("item_id");
  ent.set_item_id(item_id);

  return true;
}

bool JingpinItemEntityDao::BuildItemInfoEntityFromResult(sql::ResultSet* res, ItemInfoEntity& ent) {
  CHECK_NOTNULL(res);
  try {
    uint64 id = res->getUInt64("id");
    ent.set_id(id);

    std::string item_id = res->getString("item_id");
    ent.set_item_id(item_id);

    int item_type = res->getInt("item_type");
    ent.set_item_type(item_type);
  } catch (...) {
    LOG(ERROR) << "build jingpin item entity fail.";
    return false;
  }
  return true;
}

