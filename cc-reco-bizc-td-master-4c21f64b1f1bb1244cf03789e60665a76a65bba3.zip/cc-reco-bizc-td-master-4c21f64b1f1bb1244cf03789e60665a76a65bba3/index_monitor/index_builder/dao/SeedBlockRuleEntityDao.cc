#include "reco/bizc/index_monitor/index_builder/dao/SeedBlockRuleEntityDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

DEFINE_string(block_rule_table, "tb_seed_block_rule", "block rule table name");

void SeedBlockRuleEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void SeedBlockRuleEntityDao::getBySeedId(uint64 seed_id, std::vector<SeedBlockRuleEntity>* rule_list) {
  CHECK_NOTNULL(rule_list);
  std::string sql = base::StringPrintf("select id,seed_id,os,block_main_city,app_name,"
    "operator,operate_time from %s where seed_id = %lu",FLAGS_block_rule_table.c_str(), seed_id);

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      
      rule_list->clear();
      
      while (res->next()) {
        SeedBlockRuleEntity entity;
        rule_list->push_back(entity);
        if (!BuildSeedBlockRuleEntityFromResult(res.get(), rule_list->back())) {
          rule_list->pop_back();
        }
      }
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

bool SeedBlockRuleEntityDao::BuildSeedBlockRuleEntityFromResult(sql::ResultSet* res,
                                                                SeedBlockRuleEntity& ent) {
  CHECK_NOTNULL(res);
  try {
    uint64 id = res->getUInt64("id");
    ent.set_id(id);

    uint64 seed_id = res->getUInt64("seed_id");
    ent.set_seed_id(seed_id);

    std::string os = res->getString("os");
    ent.set_os(os);

    int block_main_city = res->getInt("block_main_city");
    ent.set_block_main_city(block_main_city);

    std::string app_name = res->getString("app_name");
    ent.set_app_name(app_name);

    std::string oper = res->getString("operator");
    ent.set_oper(oper);

    double operate_time_val = (double)res->getInt("operate_time");
    base::Time operate_time = base::Time::FromDoubleT(operate_time_val);
    ent.set_operate_time(operate_time);
  } catch (...) {
    LOG(ERROR) << "build seed block rule entity fail.";
    return false;
  }

  return true;
}
