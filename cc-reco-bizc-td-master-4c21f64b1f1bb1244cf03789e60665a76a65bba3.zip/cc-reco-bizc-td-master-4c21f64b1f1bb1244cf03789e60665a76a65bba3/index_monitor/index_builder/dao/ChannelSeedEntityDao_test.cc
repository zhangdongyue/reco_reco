#include <stdio.h>
#include <vector>
#include <unordered_map>      
#include <utility>
#include <set>                
#include <string>             

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/common/base.h" 
#include "base/time/time.h"

#include "reco/bizc/index_monitor/index_builder/dao/ChannelSeedEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/dao/SeedEntityDao.h"


class ChannelSeedEntityDaoTest : public testing::Test {
 protected:
  virtual void SetUp() {
  }

  virtual void TearDown() {
  }
};

TEST_F(ChannelSeedEntityDaoTest, Test_getBySeedId) {
  ChannelSeedEntityDao channel_seed_dao;
  SeedEntityDao seed_dao;
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = "tcp://11.251.203.145:3306";
  db_option.schema = "reco";
  db_option.user = "recodev";
  db_option.passwd = "tkDn19DHeVZkNA";
  channel_seed_dao.Init(db_option);
  seed_dao.Init(db_option);

  std::vector<SeedEntity> seeds;
  seed_dao.getAllSeedList(&seeds);
  EXPECT_GT(seeds.size(), (size_t)0);

  printf("size of seeds is : %d\n", (int)seeds.size());

  for (size_t i = 0; i < seeds.size() && i < 10; ++i) {
    printf("NO.%d: %s\n",(int)i, seeds.at(i).to_string().c_str());

    std::vector<ChannelSeedEntity> seed_list;
    channel_seed_dao.getBySeedId(seeds.at(i).get_id(), &seed_list);
    EXPECT_GT(seed_list.size(), (size_t)0);

    printf("size of seed_list is : %d\n", (int)seed_list.size());

    for (size_t j = 0; j < seed_list.size() && j < 10; ++j) {
      printf("NO.%d: %s\n",(int)j, seed_list.at(j).to_string().c_str());
    }
  }
}



