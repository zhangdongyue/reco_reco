#include "reco/bizc/index_monitor/index_builder/dao/ItemInfoEntityDao.h"

#include <vector>
#include <map>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

DECLARE_string(item_info_table);

void ItemInfoEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void ItemInfoEntityDao::getCategories(std::vector<std::string>* category_list) {
  TimeConsume timeConsume("ItemInfoEntityDao_getCategories");
  category_list->clear();
  base::Time current_time = base::Time::Now();
  std::string str_current_time;
  current_time.ToStringInSeconds(&str_current_time);
  base::Time start_time = current_time - base::TimeDelta::FromDays(2);
  std::string str_start_time;
  start_time.ToStringInSeconds(&str_start_time);
  std::string sql = base::StringPrintf("select DISTINCT category from %s where create_time>'%s'"
                                       " and create_time <= '%s'",
                                       FLAGS_item_info_table.c_str(),
                                       str_start_time.c_str(),
                                       str_current_time.c_str());

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

      while (res->next()) {
        try {
          std::string category = res.get()->getString("category");
          category_list->push_back(category);
        }  catch (...) {
          LOG(ERROR) << "parse category from db fail.";
        }
      }
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }

}

void ItemInfoEntityDao::getValidItemsInRange(const std::string& start_date, const std::string& end_date,
                                             std::vector<ItemInfoEntity>* items) {
  CHECK_NOTNULL(items);
  std::string sql = base::StringPrintf("select id,item_id,item_type,category,producer,source,parent_id,publish_time from %s where ",
                                       FLAGS_item_info_table.c_str());
  if (!start_date.empty()) {
    std::string where = base::StringPrintf("create_time >= \"%s\" and ", start_date.c_str());
    sql += where;
  }
  if (!end_date.empty()) {
    std::string where = base::StringPrintf("create_time <= \"%s\" and ", end_date.c_str());
    sql += where;
  } else {
    base::Time current_time = base::Time::Now();
    std::string str_current_time;
    current_time.ToStringInSeconds(&str_current_time);
    std::string where = base::StringPrintf("create_time <= \"%s\" and ", str_current_time.c_str());
    sql += where;
  }
  {
    std::string where = base::StringPrintf("is_valid = 1 and ");
    sql += where;
  }
  {
    std::string where = base::StringPrintf("only_crawl = 0");
    sql += where;
  }

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      serving_base::Timer timer;
      timer.Start();
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      LOG(INFO) << "ItemInfoEntityDao_getValidItemsInRange_sql_cost:" << timer.Stop();

      items->clear();

      timer.Start();
      while (res->next()) {
        ItemInfoEntity entity;
        if (BuildItemInfoEntityFromResult(res.get(), entity)) {
          items->push_back(entity);
        }
      }
      LOG(INFO) << "ItemInfoEntityDao_getValidItemsInRange_handle_cost:" << timer.Stop() << ", num:" << res->getRow();
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

void ItemInfoEntityDao::getValidLeafItemsInRange(const std::string& start_date, const std::string& end_date,
                                             std::vector<ItemInfoEntity>* items) {
  CHECK_NOTNULL(items);
  std::string sql = base::StringPrintf("select id,item_id,item_type,category,producer,source,parent_id,publish_time from %s where ",
                                       FLAGS_item_info_table.c_str());
  if (!start_date.empty()) {
    std::string where = base::StringPrintf("create_time >= \"%s\" and ", start_date.c_str());
    sql += where;
  }
  if (!end_date.empty()) {
    std::string where = base::StringPrintf("create_time <= \"%s\" and ", end_date.c_str());
    sql += where;
  } else {
    base::Time current_time = base::Time::Now();
    std::string str_current_time;
    current_time.ToStringInSeconds(&str_current_time);
    std::string where = base::StringPrintf("create_time <= \"%s\" and ", str_current_time.c_str());
    sql += where;
  }
  {
    std::string where = base::StringPrintf("is_valid = 1 and ");
    sql += where;
  }
  {
    std::string where = base::StringPrintf("only_crawl = 0 and ");
    sql += where;
  }
  {
    std::string where = base::StringPrintf("item_type != 30 ");
    sql += where;
  }

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      serving_base::Timer timer;
      timer.Start();
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      LOG(INFO) << "ItemInfoEntityDao_getValidLeafItemsInRange_sql_cost:" << timer.Stop();

      items->clear();

      timer.Start();
      while (res->next()) {
        ItemInfoEntity entity;
        if (BuildItemInfoEntityFromResult(res.get(), entity)) {
          items->push_back(entity);
        }
      }
      LOG(INFO) << "ItemInfoEntityDao_getValidLeafItemsInRange_handle_cost:" << timer.Stop() << ", num:" << res->getRow();
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

void ItemInfoEntityDao::batchGetItemInfo(std::vector<std::string>* id_list,
                                         std::vector<ItemInfoEntity>* item_list) {
  CHECK_NOTNULL(id_list);
  CHECK_NOTNULL(item_list);
  TimeConsume timeConsume("ItemInfoEntityDao_getValidItemsInRange");
  if (id_list->size() == 0) {
    return;
  }
  std::string sql = base::StringPrintf("select id,item_id,item_type,category,producer,source ,parent_id, publish_time from %s where item_id in ( ",
                                       FLAGS_item_info_table.c_str());

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (size_t i = 0; i < id_list->size(); ++i) {
    std::string id = id_list->at(i);
    if (i == 0) {
      sql += id;
    } else {
      std::string val = base::StringPrintf(" , %s", id.c_str());
    }
  }

  std::string endstr = std::string(" )");

  sql += endstr;

  std::map<std::string, ItemInfoEntity> item_map;

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      
      item_map.clear();
      
      while (res->next()) {
        ItemInfoEntity entity;
        if (BuildItemInfoEntityFromResult(res.get(), entity)) {
          item_map.insert(std::make_pair(entity.get_item_id(), entity));
        }
      }
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }

  // 返回的 item 按照给的 id_list 的顺序
  for (size_t i = 0; i < id_list->size(); ++i) {
    std::string item_id = id_list->at(i);
    auto it = item_map.find(item_id);
    if (it != item_map.end()) {
      item_list->push_back(it->second);
    }
  }

}

bool ItemInfoEntityDao::BuildItemInfoEntityFromResult(sql::ResultSet* res, ItemInfoEntity& ent) {
  CHECK_NOTNULL(res);
  try {
    uint64 id = res->getUInt64("id");
    ent.set_id(id);

    std::string item_id = res->getString("item_id");
    ent.set_item_id(item_id);

    int item_type = res->getInt("item_type");
    ent.set_item_type(item_type);

    std::string category = res->getString("category");
    ent.set_category(category);

    std::string producer = res->getString("producer");
    ent.set_producer(producer);

    std::string source = res->getString("source");
    ent.set_source(source);

    std::string parent_id = res->getString("parent_id");
    ent.set_parent_id(parent_id);

    std::string publish_time_str = res->getString("publish_time");
    base::Time publish_time;
    if (base::Time::FromStringInSeconds(publish_time_str.c_str(), &publish_time)) {
      ent.set_publish_time(publish_time);
    }
  } catch (...) {
    LOG(ERROR) << "build item info entity fail.";
    return false;
  }
  return true;
}

