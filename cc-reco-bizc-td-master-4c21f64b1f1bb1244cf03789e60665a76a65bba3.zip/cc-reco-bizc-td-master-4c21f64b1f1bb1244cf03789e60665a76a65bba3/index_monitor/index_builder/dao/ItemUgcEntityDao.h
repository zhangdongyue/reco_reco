#pragma once

#include <vector>
#include <string>
#include <set>

#include "serving_base/mysql_util/db_conn_manager.h"

#include "third_party/mysql-connector/cppconn/resultset.h"
#include "reco/bizc/index_monitor/index_builder/entity/ItemUgcEntity.h"

class ItemUgcEntityDao {
 public:
  ItemUgcEntityDao()
      : db_manager_(NULL),
      db_connection_(NULL) {}
  ~ItemUgcEntityDao() {
    if (db_manager_ != NULL) {
      delete db_manager_;
    }
  }

  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void GetUgcItemsByCreateTime(const std::string& beg_time,
                               const std::string& end_time,
                               std::vector<ItemUgcEntity> *items);

 private:
  bool BuildItemUgcEntityFromResult(sql::ResultSet *res, ItemUgcEntity &ent);

  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  static const int kRetryTimes = 3;
};
