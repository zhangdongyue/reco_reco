#ifndef SEEDENTITYDAO_H
#define SEEDENTITYDAO_H

#include <vector>
#include <string>

#include "serving_base/mysql_util/db_conn_manager.h"

#include "third_party/mysql-connector/cppconn/resultset.h"
#include "reco/bizc/index_monitor/index_builder/entity/SeedEntity.h"

class SeedEntityDao {
 public:
  SeedEntityDao()
  : db_manager_(NULL),
  db_connection_(NULL) {}
  ~SeedEntityDao() {
    if (db_manager_ != NULL) {
      delete db_manager_;
    }
  }
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void getAllSeedList(std::vector<SeedEntity>* seed_list);
 private:
  bool BuildSeedEntityFromResult(sql::ResultSet* res, SeedEntity& ent);
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  static const int kRetryTimes = 3;
};

#endif
