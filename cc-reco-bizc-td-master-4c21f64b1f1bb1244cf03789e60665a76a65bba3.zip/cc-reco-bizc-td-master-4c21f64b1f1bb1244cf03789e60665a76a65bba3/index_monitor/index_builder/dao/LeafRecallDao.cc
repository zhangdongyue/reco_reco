#include "reco/bizc/index_monitor/index_builder/dao/LeafRecallDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

DECLARE_string(item_info_table);

void LeafRecallDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void LeafRecallDao::getBeautyPicItemList(const std::string& start_time_stamp,
                                                   const std::string& end_time_stamp, int max_size,
                                                   std::vector<std::string>* itemid_list) {
  CHECK_NOTNULL(itemid_list);
  TimeConsume timeConsume("LeafRecallDao_getBeautyPicItemList");

  const std::string category = "美女";
  std::string sql_category = "%" + category + "%";
  std::string sql_limit = base::StringPrintf(" limit %d", max_size);
  std::string sql = base::StringPrintf("select item_id "
                                       "from %s "
                                       "where create_time >= \"%s\" "
                                       "and create_time <= \"%s\" "
                                       "and category like '%s' "
                                       "and is_valid = 1 "
                                       "and only_crawl = 0 "
                                       "and is_manual_news != 1 "
                                       "and item_type = 2 "
                                       "order by create_time desc",
                                       FLAGS_item_info_table.c_str(),
                                       start_time_stamp.c_str(),
                                       end_time_stamp.c_str(),
                                       sql_category.c_str());
  if (max_size > 0) {
    sql += sql_limit;
  }

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      serving_base::Timer timer;
      timer.Start();
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      LOG(INFO) << "LeafRecallDao_getBeautyPicItemList_sql_cost:" << timer.Stop();

      itemid_list->clear();

      timer.Start();
      while (res->next()) {
        std::string item_id = res->getString("item_id");
        itemid_list->push_back(item_id);
      }
      LOG(INFO) << "LeafRecallDao_getBeautyPicItemList_handle_cost:" << timer.Stop() << ", num:" << res->getRow();
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

