#include "reco/bizc/index_monitor/index_builder/dao/AppChannelEntityDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

DEFINE_string(app_channel_table, "tb_app_channel", "app channel table name");

void AppChannelEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void AppChannelEntityDao::getChannels(std::vector<AppChannelEntity>* channel_list) {
  CHECK_NOTNULL(channel_list);
  TimeConsume time_consume("AppChannelEntityDao_getChannels");
  std::string sql = base::StringPrintf("select id,appname,channel_id,name,is_default,is_fixed,"
    "seq,status,op_mark,op_mark_name,opmark_online_time,opmark_expired_time,android_ve,ios_ve,"
    "is_not_publish,modify_time,create_time,publish_strategy from %s", FLAGS_app_channel_table.c_str());

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      
      channel_list->clear();
      
      while (res->next()) {
        AppChannelEntity entity;
        channel_list->push_back(entity);
        if (!BuildAppChannelEntityFromResult(res.get(), channel_list->back())) {
          channel_list->pop_back();
        }
      }
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

bool AppChannelEntityDao::BuildAppChannelEntityFromResult(sql::ResultSet* res, AppChannelEntity& ent) {
  CHECK_NOTNULL(res);
  
  try {

    uint64 id = res->getUInt64("id");
    ent.set_id(id);

    std::string appname = res->getString("appname");
    ent.set_appname(appname);

    uint64 channel_id = res->getUInt64("channel_id");
    ent.set_channel_id(channel_id);

    std::string name = res->getString("name");
    ent.set_name(name);

    bool is_default = res->getBoolean("is_default");
    ent.set_is_default(is_default);

    bool is_fixed = res->getBoolean("is_fixed");
    ent.set_is_fixed(is_fixed);

    int seq = res->getInt("seq");
    ent.set_seq(seq);

    int status = res->getInt("status");
    ent.set_status(status);

    int op_mark = res->getInt("op_mark");
    ent.set_op_mark(op_mark);

    double opmark_online_time_val = (double)res->getInt("opmark_online_time");
    base::Time opmark_online_time = base::Time::FromDoubleT(opmark_online_time_val);
    ent.set_opmark_online_time(opmark_online_time);

    double opmark_expired_time_val = (double)res->getInt("opmark_expired_time");
    base::Time opmark_expired_time = base::Time::FromDoubleT(opmark_expired_time_val);
    ent.set_opmark_expired_time(opmark_expired_time);

    std::string op_mark_name = res->getString("op_mark_name");
    ent.set_op_mark_name(op_mark_name);

    std::string android_ve = res->getString("android_ve");
    ent.set_android_ve(android_ve);

    std::string ios_ve = res->getString("ios_ve");
    ent.set_ios_ve(ios_ve);

    int is_not_publish = res->getInt("is_not_publish");
    ent.set_is_not_publish(is_not_publish);

    double modify_time_val = (double)res->getInt("modify_time");
    base::Time modify_time = base::Time::FromDoubleT(modify_time_val);
    ent.set_modify_time(modify_time);

    double create_time_val = (double)res->getInt("create_time");
    base::Time create_time = base::Time::FromDoubleT(create_time_val);
    ent.set_create_time(create_time);

    int publish_strategy = res->getInt("publish_strategy");
    ent.set_publish_strategy(publish_strategy);

  } catch(...) {
    LOG(ERROR) << "build app channel entity fail.";
    return false;
  }

  if (!ent.check_valid()) {
    return false;
  }
  return true;
}
