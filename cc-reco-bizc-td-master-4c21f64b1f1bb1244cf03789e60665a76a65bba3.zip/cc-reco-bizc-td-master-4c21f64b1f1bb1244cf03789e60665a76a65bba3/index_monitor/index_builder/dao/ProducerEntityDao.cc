#include "reco/bizc/index_monitor/index_builder/dao/ProducerEntityDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

DEFINE_string(cp_config_table, "tb_cp_config", "cp config table name");


void ProducerEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void ProducerEntityDao::getAllProducerWhiteList(std::vector<ProducerEntity>* producer_white_list) {
  CHECK_NOTNULL(producer_white_list);
  TimeConsume timeConsume("ProducerEntityDao_getAllProducerWhiteList");
  std::string sql = base::StringPrintf("select cp from %s where can_publish = 1",
    FLAGS_cp_config_table.c_str());

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      
      producer_white_list->clear();
      
      while (res->next()) {
        ProducerEntity entity;
        producer_white_list->push_back(entity);
        if (!BuildProducerEntityFromResult(res.get(), producer_white_list->back())) {
          producer_white_list->pop_back();
        }
      }
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

bool ProducerEntityDao::BuildProducerEntityFromResult(sql::ResultSet* res, ProducerEntity& ent) {
  CHECK_NOTNULL(res);
  try {
    std::string name = res->getString("cp");
    ent.set_name(name);
  } catch (...) {
    LOG(ERROR) << "build producer entity fail.";
    return false;
  }
  return true;
}
