#ifndef LEAFRECALLDAO_H
#define LEAFRECALLDAO_H

#include <vector>
#include <string>

#include "serving_base/mysql_util/db_conn_manager.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

class LeafRecallDao {
 public:
  LeafRecallDao()
  : db_manager_(NULL),
  db_connection_(NULL) {}
  ~LeafRecallDao() {
    if (db_manager_ != NULL) {
      delete db_manager_;
    }
  }
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void getBeautyPicItemList(const std::string& start_timestamp,
                            const std::string& end_time_stamp,
                            int max_size,
                            std::vector<std::string>* itemid_list);
 private:
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  static const int kRetryTimes = 3;
};

#endif

