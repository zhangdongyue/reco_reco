#ifndef IFLOWITEMENTITYDAO_H
#define IFLOWITEMENTITYDAO_H

#include <vector>
#include <string>

#include "serving_base/mysql_util/db_conn_manager.h"

#include "third_party/mysql-connector/cppconn/resultset.h"
#include "reco/bizc/index_monitor/index_builder/entity/IflowItemEntity.h"

class IflowItemEntityDao {
 public:
  IflowItemEntityDao()
  : db_manager_(NULL),
  db_connection_(NULL) {}
  ~IflowItemEntityDao() {
    if (db_manager_ != NULL) {
      delete db_manager_;
    }
  }
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void getItemsByDate(std::string date, int max_size, std::vector<IflowItemEntity>* item_list);
 private:
  bool BuildIfowItemEntityFromResult(sql::ResultSet* res, IflowItemEntity& ent);
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  static const int kRetryTimes = 3;
};

#endif

