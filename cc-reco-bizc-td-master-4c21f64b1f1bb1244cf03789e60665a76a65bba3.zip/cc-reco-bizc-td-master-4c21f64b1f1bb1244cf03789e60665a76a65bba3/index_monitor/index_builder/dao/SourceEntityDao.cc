#include "reco/bizc/index_monitor/index_builder/dao/SourceEntityDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

DEFINE_string(source_table, "tb_quantity_assurance_source", "source table name");
DECLARE_string(item_info_table);

void SourceEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void SourceEntityDao::getAllSourceList(std::vector<SourceEntity>* source_list) {
  CHECK_NOTNULL(source_list);
  std::string sql = base::StringPrintf("select source,num_limit,day_limit from %s where status = 0",
    FLAGS_source_table.c_str());

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

      source_list->clear();

      while (res->next()) {
        SourceEntity entity;
        source_list->push_back(entity);
        if (!BuildSourceEntityFromResult(res.get(), source_list->back())) {
          source_list->pop_back();
        }
      }
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

void SourceEntityDao::getItemsBySource(std::string source, std::string start_time_stamp,
                                       std::string end_time_stamp, int max_size,
                                            std::vector<ItemInfoEntity>* item_list) {
  CHECK_NOTNULL(item_list);

  std::string sql;

  sql = base::StringPrintf("select id,item_id,item_type from %s "
                           "where source = \"%s\" "
                           "and create_time >= \"%s\" "
                           "and create_time <= \"%s\" "
                           "and is_valid = 1 "
                           "and item_type = 30 "
                           "order by create_time desc "
                           "limit %d", FLAGS_item_info_table.c_str(),
                           source.c_str(),
                           start_time_stamp.c_str(),
                           end_time_stamp.c_str(),
                           max_size);

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

      item_list->clear();

      while (res->next()) {
        ItemInfoEntity entity;
        item_list->push_back(entity);
        if (!BuildItemInfoEntityFromResult(res.get(), item_list->back())) {
          item_list->pop_back();
        }
      }
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

bool SourceEntityDao::BuildSourceEntityFromResult(sql::ResultSet* res, SourceEntity& ent) {
  CHECK_NOTNULL(res);
  try {
    std::string source = res->getString("source");
    ent.set_source(source);

    int32 num_limit = res->getInt("num_limit");
    ent.set_num_limit(num_limit);

    int32 day_limit = res->getInt("day_limit");
    ent.set_day_limit(day_limit);
  } catch (...) {
    LOG(ERROR) << "build seed entity fail.";
    return false;
  }
  return true;
}

bool SourceEntityDao::BuildItemInfoEntityFromResult(sql::ResultSet* res, ItemInfoEntity& ent) {
  CHECK_NOTNULL(res);
  try {
    uint64 id = res->getUInt64("id");
    ent.set_id(id);

    std::string item_id = res->getString("item_id");
    ent.set_item_id(item_id);

    int item_type = res->getInt("item_type");
    ent.set_item_type(item_type);
  } catch (...) {
    LOG(ERROR) << "build source item entity fail.";
    return false;
  }
  return true;
}
