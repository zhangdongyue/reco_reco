#include "reco/bizc/index_monitor/index_builder/dao/SuperbItemEntityDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

DEFINE_string(superb_table, "tb_superb_item", "superb table name");

void SuperbItemEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void SuperbItemEntityDao::getSuperbItemByCreatetime(std::string start_time, std::string end_time,
                                        int max_size, std::vector<SuperbItemEntity>* item_list) {
  CHECK_NOTNULL(item_list);
  base::Time now_time = base::Time::Now();
  std::string sql = base::StringPrintf("select id,item_id, retention_level, create_time from %s "
                    "where create_time >= \"%s\" and create_time <= \"%s\" "
                    "and is_deleted = 0 order by create_time desc limit %d", FLAGS_superb_table.c_str(),
                    start_time.c_str(), end_time.c_str(), max_size);

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      serving_base::Timer timer;
      timer.Start();
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      LOG(INFO) << "SuperbItemEntityDao_getSuperbItemByCreatetime_sql_cost:" << timer.Stop();

      item_list->clear();

      timer.Start();
      while (res->next()) {
        SuperbItemEntity entity;
        item_list->push_back(entity);
        if (!BuildSuperbItemEntityFromResult(res.get(), item_list->back(), now_time)) {
          item_list->pop_back();
        }
      }
      LOG(INFO) << "SuperbItemEntityDao_getSuperbItemByCreatetime_handle_cost:" << timer.Stop()
                << ", num:" << res->getRow();
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}


bool SuperbItemEntityDao::BuildSuperbItemEntityFromResult(sql::ResultSet* res, SuperbItemEntity& ent,
                                                          base::Time& now) {
  CHECK_NOTNULL(res);

  int retention_level = res->getInt("retention_level");

  std::string create_time = res->getString("create_time");
  int day_delta = 7;
  base::Time item_time;
  if (base::Time::FromStringInSeconds(create_time.c_str(), &item_time)) {
    day_delta = (now - item_time).InDays();
  }

  switch (retention_level) {
    case 0:
      if (day_delta > 7) {
        return false;
      }
      break;
    case 1:
      if (day_delta > 30) {
        return false;
      }
      break;
    case 2:
      if (day_delta > 90) {
        return false;
      }
      break;
    case 3:
      if (day_delta > 180) {
        return false;
      }
      break;
    case 4:
      if (day_delta > 3) {
        return false;
      }
      break;
    default:
      break;
  }

  uint64 id = res->getUInt64("id");
  ent.set_id(id);

  std::string item_id = res->getString("item_id");
  ent.set_item_id(item_id);

  return true;
}
