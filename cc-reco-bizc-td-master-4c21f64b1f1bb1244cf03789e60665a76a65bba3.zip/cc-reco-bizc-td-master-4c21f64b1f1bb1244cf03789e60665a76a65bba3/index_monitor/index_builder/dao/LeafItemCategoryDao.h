#ifndef LEAFITEMCATEGORYDAO_H
#define LEAFITEMCATEGORYDAO_H

#include <vector>
#include <string>
#include <set>

#include "serving_base/mysql_util/db_conn_manager.h"

#include "third_party/mysql-connector/cppconn/resultset.h"
#include "reco/bizc/index_monitor/index_builder/entity/ItemChannelEntity.h"
#include "reco/bizc/index_monitor/index_builder/entity/ItemInfoEntity.h"

class LeafItemCategoryDao {
 public:
  LeafItemCategoryDao()
  : db_manager_(NULL),
  db_connection_(NULL) {}
  ~LeafItemCategoryDao() {
    if (db_manager_ != NULL) {
      delete db_manager_;
    }
  }
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void getValidItemsByCategory(const std::string& category, std::string start_time_stamp,
                               std::string end_time_stamp, int max_size,
                               std::vector<ItemChannelEntity>* item_list);
 private:
  bool BuildItemChannelEntityFromResult(sql::ResultSet* res, ItemChannelEntity& ent);
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  static const int kRetryTimes = 3;
};

#endif
