#include "reco/bizc/index_monitor/index_builder/dao/ChannelSeedEntityDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

DEFINE_string(channel_seed_table, "tb_channel_seed", "channel seed table name");

void ChannelSeedEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void ChannelSeedEntityDao::getBySeedId(uint64 seed_id, std::vector<ChannelSeedEntity>* channel_list) {
  CHECK_NOTNULL(channel_list);
  std::string sql = base::StringPrintf("select id,channel_id,seed_id,is_valid from %s "
                                       "where seed_id = %lu", FLAGS_channel_seed_table.c_str(), seed_id);

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      
      channel_list->clear();
      
      while (res->next()) {
        ChannelSeedEntity entity;
        channel_list->push_back(entity);
        if (!BuildChannelSeedEntityFromResult(res.get(), channel_list->back())) {
          channel_list->pop_back();
        }
      }
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

bool ChannelSeedEntityDao::BuildChannelSeedEntityFromResult(sql::ResultSet* res, ChannelSeedEntity& ent) {
  CHECK_NOTNULL(res);
  try {
    uint64 id = res->getUInt64("id");
    ent.set_id(id);

    uint64 channel_id = res->getUInt64("channel_id");
    ent.set_channel_id(channel_id);

    uint64 seed_id = res->getUInt64("seed_id");
    ent.set_seed_id(seed_id);

  int is_valid = res->getInt("is_valid");
  ent.set_is_valid(is_valid);
  } catch(...) {
    LOG(ERROR) << "build channel seed entity fail.";
    return false;
  }
  if (!ent.check_valid()) {
    return false;
  }
  return true;
}

