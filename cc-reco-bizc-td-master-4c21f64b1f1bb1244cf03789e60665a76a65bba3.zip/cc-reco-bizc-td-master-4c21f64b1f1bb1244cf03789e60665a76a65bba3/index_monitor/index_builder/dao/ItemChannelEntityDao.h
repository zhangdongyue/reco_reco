#ifndef ITEMCHANNELENTITYDAO_H
#define ITEMCHANNELENTITYDAO_H

#include <vector>
#include <string>
#include <set>

#include "serving_base/mysql_util/db_conn_manager.h"

#include "third_party/mysql-connector/cppconn/resultset.h"
#include "reco/bizc/index_monitor/index_builder/entity/ItemChannelEntity.h"
#include "reco/bizc/index_monitor/index_builder/entity/ItemInfoEntity.h"

class ItemChannelEntityDao {
 public:
  ItemChannelEntityDao()
  : db_manager_(NULL),
  db_connection_(NULL) {}
  ~ItemChannelEntityDao() {
    if (db_manager_ != NULL) {
      delete db_manager_;
    }
  }
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option);

  void GetValidItemsBySource(const std::string& source, const int max_size,
                             std::vector<ItemInfoEntity>* item_list);

  void getValidNewsItemsByChannel(uint64 channel_id, std::string start_time_stamp,
                                  std::string end_time_stamp, int max_size,
                              std::vector<ItemChannelEntity>* item_list);
  void getValidOPItemsByChannel(uint64 channel_id, std::string time_stamp, int max_size,
                              std::vector<ItemChannelEntity>* item_list);
  void getValidVideoItemsByChannel(uint64 channel_id, std::string start_time_stamp,
                                   std::string end_time_stamp, int max_size,
                              std::vector<ItemChannelEntity>* item_list);
  void getValidItemsByCategory(const std::string& category, std::string start_time_stamp,
                               std::string end_time_stamp, int max_size,
                               std::vector<ItemChannelEntity>* item_list);
  void exploreMoreVideoItemsByChannel(uint64 channel_id,
                                      std::string start_time_stamp, std::string end_time_stamp,
                                      int max_size, std::vector<ItemChannelEntity>* item_list,
                                      std::set<std::string>* id_set);
 private:
  bool BuildItemChannelEntityFromResult(sql::ResultSet* res, ItemChannelEntity& ent);
  bool BuildItemInfoEntityFromResult(sql::ResultSet* res, ItemInfoEntity& ent);
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  static const int kRetryTimes = 3;
};

#endif
