#include "reco/bizc/index_monitor/index_builder/dao/LeafItemCategoryDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

DECLARE_string(item_info_table);

void LeafItemCategoryDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void LeafItemCategoryDao::getValidItemsByCategory(const std::string& category,
                                                   std::string start_time_stamp,
                                                   std::string end_time_stamp, int max_size,
                                                   std::vector<ItemChannelEntity>* item_list) {
  CHECK_NOTNULL(item_list);
  TimeConsume timeConsume("LeafItemCategoryDao_getValidItemsByCategory");

  std::string sql_category = "%" + category + "%";
  std::string sql_limit = base::StringPrintf(" limit %d", max_size);
  std::string sql = base::StringPrintf("select id,item_id,channel_id,priority,publish_time,"
                                       "item_type,item_type_setter,is_web_view,outer_id "
                                       "from %s "
                                       "where create_time >= \"%s\" "
                                       "and create_time <= \"%s\" "
                                       "and category like '%s' "
                                       "and is_valid = 1 "
                                       "and only_crawl = 0 "
                                       "and item_type != 30 "
                                       "and is_manual_news != 1 "
                                       "order by create_time desc",
                                       FLAGS_item_info_table.c_str(),
                                       start_time_stamp.c_str(),
                                       end_time_stamp.c_str(),
                                       sql_category.c_str());
  if (max_size > 0) {
    sql += sql_limit;
  }

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      serving_base::Timer timer;
      timer.Start();
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      LOG(INFO) << "LeafItemCategoryDao_getValidItemsByCategory_sql_cost:" << timer.Stop();

      item_list->clear();

      timer.Start();
      while (res->next()) {
        ItemChannelEntity entity;
        item_list->push_back(entity);
        if (!BuildItemChannelEntityFromResult(res.get(), item_list->back())) {
          item_list->pop_back();
        }
      }
      LOG(INFO) << "LeafItemCategoryDao_getValidItemsByCategory_handle_cost:" << timer.Stop() << ", num:" << res->getRow();
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

bool LeafItemCategoryDao::BuildItemChannelEntityFromResult(sql::ResultSet* res, ItemChannelEntity& ent) {
  CHECK_NOTNULL(res);
  try {
    uint64 id = res->getUInt64("id");
    ent.set_id(id);

    std::string item_id = res->getString("item_id");
    ent.set_item_id(item_id);

    uint64 channel_id = res->getUInt64("channel_id");
    ent.set_channel_id(channel_id);

    int priority = res->getInt("priority");
    ent.set_priority(priority);

    int item_type = res->getInt("item_type");
    ent.set_item_type(item_type);

    int item_type_setter = res->getInt("item_type_setter");
    ent.set_item_type_setter(item_type_setter);

    std::string publish_time = res->getString("publish_time");
    ent.set_publish_time(publish_time);

    std::string outer_id = res->getString("outer_id");
    ent.set_outer_id(outer_id);

    bool is_web_view = res->getBoolean("is_web_view");
    ent.set_is_web_view(is_web_view);
  } catch (...) {
    LOG(ERROR) << "build item channel entity fail.";
  }
  if (!ent.check_valid()) {
    return false;
  }
  return true;
}

