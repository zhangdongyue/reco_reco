#ifndef JINGPINITEMENTITYDAO_H
#define JINGPINITEMENTITYDAO_H

#include <vector>
#include <string>

#include "serving_base/mysql_util/db_conn_manager.h"

#include "third_party/mysql-connector/cppconn/resultset.h"
#include "reco/bizc/index_monitor/index_builder/entity/JingpinItemEntity.h"
#include "reco/bizc/index_monitor/index_builder/entity/ItemInfoEntity.h"

class JingpinItemEntityDao {
 public:
  JingpinItemEntityDao()
  : db_manager_(NULL),
  db_connection_(NULL) {}
  ~JingpinItemEntityDao() {
    if (db_manager_ != NULL) {
      delete db_manager_;
    }
  }
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void getJingpinItemByCreatetime(std::string start_time, std::string end_time, int max_size,
                                  std::vector<JingpinItemEntity>* item_list);
  void getJingpinItemInfoByCreatetime(std::string start_time, std::string end_time, int max_size,
                                  std::vector<ItemInfoEntity>* info_list);
 private:
  bool BuildItemInfoEntityFromResult(sql::ResultSet* res, ItemInfoEntity& ent);
  bool BuildJingpinItemEntityFromResult(sql::ResultSet* res, JingpinItemEntity& ent);
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  static const int kRetryTimes = 3;
};

#endif

