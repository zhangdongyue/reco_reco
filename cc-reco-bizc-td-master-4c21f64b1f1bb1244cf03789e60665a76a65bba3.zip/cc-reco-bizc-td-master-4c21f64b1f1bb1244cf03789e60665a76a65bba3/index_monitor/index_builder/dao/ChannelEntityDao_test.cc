#include <stdio.h>
#include <vector>
#include <unordered_map>      
#include <utility>
#include <set>                
#include <string>             

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/common/base.h" 
#include "base/time/time.h"

#include "reco/bizc/index_monitor/index_builder/dao/ChannelEntityDao.h"


class ChannelEntityDaoTest : public testing::Test {
 protected:
  virtual void SetUp() {
  }

  virtual void TearDown() {
  }
};

TEST_F(ChannelEntityDaoTest, Test_getChannels) {
  ChannelEntityDao channel_dao;
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = "tcp://11.251.203.145:3306";
  db_option.schema = "reco";
  db_option.user = "recodev";
  db_option.passwd = "tkDn19DHeVZkNA";
  channel_dao.Init(db_option);

  std::vector<ChannelEntity> channel_list;
  channel_dao.getChannels(&channel_list);
  EXPECT_GT(channel_list.size(), (size_t)0);

  printf("size of channel_list is : %d\n", (int)channel_list.size());

  for (size_t i = 0; i < channel_list.size() && i < 10; ++i) {
    printf("NO.%d: %s\n",(int)i, channel_list.at(i).to_string().c_str());
  }
}


