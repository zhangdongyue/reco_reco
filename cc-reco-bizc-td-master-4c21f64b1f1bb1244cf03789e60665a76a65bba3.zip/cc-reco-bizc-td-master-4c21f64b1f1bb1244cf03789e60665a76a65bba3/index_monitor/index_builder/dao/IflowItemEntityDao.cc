#include "reco/bizc/index_monitor/index_builder/dao/IflowItemEntityDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

DEFINE_string(iflow_table, "tb_iflow_item", "iflow table name");

void IflowItemEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void IflowItemEntityDao::getItemsByDate(std::string date, int max_size,
                                        std::vector<IflowItemEntity>* item_list) {
  CHECK_NOTNULL(item_list);
  TimeConsume time_consume("IflowItemEntityDao_getItemsByDate");
  std::string sql = base::StringPrintf("select id,item_id from %s "
        "where (is_published = 1 and end_time >= \"%s\" ) or "
        " (is_special_sub_item = 1 and channel_id = 310) "
        "order by publish_time desc limit %d",FLAGS_iflow_table.c_str(), date.c_str(), max_size);

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      serving_base::Timer timer;
      timer.Start();
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      LOG(INFO) << "IflowItemEntityDao_getItemsByDate_sql_cost:" << timer.Stop();
      
      item_list->clear();

      timer.Start();
      while (res->next()) {
        IflowItemEntity entity;
        item_list->push_back(entity);
        if (!BuildIfowItemEntityFromResult(res.get(), item_list->back())) {
          item_list->pop_back();
        }
      }
      LOG(INFO) << "IflowItemEntityDao_getItemsByDate_handle_cost:" << timer.Stop() << ", num:" << res->getRow();
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

bool IflowItemEntityDao::BuildIfowItemEntityFromResult(sql::ResultSet* res, IflowItemEntity& ent) {
  CHECK_NOTNULL(res);
  try {
    uint64 id = res->getUInt64("id");
    ent.set_id(id);

    std::string item_id = res->getString("item_id");
    ent.set_item_id(item_id);

  } catch (...) {
    LOG(ERROR) << "build iflow item entity fail.";
    return false;
  }
  if (!ent.check_valid()) {
    return false;
  }
  return true;
}

