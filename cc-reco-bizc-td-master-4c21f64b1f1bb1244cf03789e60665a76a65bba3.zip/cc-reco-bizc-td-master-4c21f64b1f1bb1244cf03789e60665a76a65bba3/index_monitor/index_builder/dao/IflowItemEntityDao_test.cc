#include <stdio.h>
#include <vector>
#include <unordered_map>      
#include <utility>
#include <set>                
#include <string>             

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/common/base.h" 
#include "base/time/time.h"

#include "reco/bizc/index_monitor/index_builder/dao/IflowItemEntityDao.h"


class IflowItemEntityDaoTest : public testing::Test {
 protected:
  virtual void SetUp() {
  }

  virtual void TearDown() {
  }
};

TEST_F(IflowItemEntityDaoTest, Test_getItemsByDate) {
  IflowItemEntityDao iflow_item_dao;
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = "tcp://11.251.203.145:3306";
  db_option.schema = "reco";
  db_option.user = "recodev";
  db_option.passwd = "tkDn19DHeVZkNA";
  iflow_item_dao.Init(db_option);

  std::vector<IflowItemEntity> item_list;
  base::Time current_time = base::Time::Now();
  std::string timestamp;
  current_time.ToStringInSeconds(&timestamp);
  iflow_item_dao.getItemsByDate(timestamp, 5000, &item_list);
  EXPECT_GT(item_list.size(), (size_t)0);

  printf("iflow item list size : %d\n", (int)item_list.size());

  for (size_t i = 0; i < item_list.size() && i < 10; ++i) {
    printf("NO.%d: %s\n",(int)i, item_list.at(i).to_string().c_str());
  }
}
