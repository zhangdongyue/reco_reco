#ifndef CHANNELENTITYDAO_H
#define CHANNELENTITYDAO_H

#include <vector>
#include <string>

#include "serving_base/mysql_util/db_conn_manager.h"

#include "third_party/mysql-connector/cppconn/resultset.h"
#include "reco/bizc/index_monitor/index_builder/entity/ChannelEntity.h"

class ChannelEntityDao {
 public:
  ChannelEntityDao()
  : db_manager_(NULL),
  db_connection_(NULL) {}
  ~ChannelEntityDao() {
    if (db_manager_ != NULL) {
      delete db_manager_;
    }
  }
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void getChannels(std::vector<ChannelEntity>* channel_list);
  bool getChannelByCid(int64 cid, ChannelEntity* channel);
 private:
  bool BuildChannelEntityFromResult(sql::ResultSet* res, ChannelEntity& ent);
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  static const int kRetryTimes = 3;
};

#endif

