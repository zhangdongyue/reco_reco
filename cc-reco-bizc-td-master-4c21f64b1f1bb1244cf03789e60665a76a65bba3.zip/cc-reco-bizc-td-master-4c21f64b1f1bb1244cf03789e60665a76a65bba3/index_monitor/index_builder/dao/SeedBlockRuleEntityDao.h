#ifndef SEEDBLOCKRULEENTITYDAO_H
#define SEEDBLOCKRULEENTITYDAO_H

#include <vector>
#include <string>

#include "serving_base/mysql_util/db_conn_manager.h"

#include "reco/bizc/index_monitor/index_builder/entity/SeedBlockRuleEntity.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

class SeedBlockRuleEntityDao {
 public:
  SeedBlockRuleEntityDao()
  : db_manager_(NULL),
  db_connection_(NULL) {}
  ~SeedBlockRuleEntityDao() {
    if (db_manager_ != NULL) {
      delete db_manager_;
    }
  }
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void getBySeedId(uint64 seed_id, std::vector<SeedBlockRuleEntity>* rule_list);
 private:
  bool BuildSeedBlockRuleEntityFromResult(sql::ResultSet* ret, SeedBlockRuleEntity& ent);
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  static const int kRetryTimes = 3;
};

#endif
