#include "reco/bizc/index_monitor/index_builder/dao/CommentEntityDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

DEFINE_string(comment_table, "tb_comment", "comment table name");

void CommentEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

//自有评论
bool CommentEntityDao::getCommentCountByItemid(const std::string& itemid, int* cnt) {
  std::string sql = base::StringPrintf("select count(1) from %s where article_id = %s and author_type = 0",
                                       FLAGS_comment_table.c_str(), itemid.c_str());

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  bool succ = false;
  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      while (res->next()) {
        *cnt = res.get()->getInt(1);
        succ = true;
      }
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
  return succ;
}
