#ifndef SOURCEENTITYDAO_H
#define SOURCEENTITYDAO_H

#include <vector>
#include <string>

#include "serving_base/mysql_util/db_conn_manager.h"

#include "third_party/mysql-connector/cppconn/resultset.h"
#include "reco/bizc/index_monitor/index_builder/entity/SourceEntity.h"
#include "reco/bizc/index_monitor/index_builder/entity/ItemInfoEntity.h"

class SourceEntityDao {
 public:
  SourceEntityDao()
  : db_manager_(NULL),
  db_connection_(NULL) {}
  ~SourceEntityDao() {
    if (db_manager_ != NULL) {
      delete db_manager_;
    }
  }
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void getAllSourceList(std::vector<SourceEntity>* source_list);
  void getItemsBySource(std::string source, std::string start_time_stamp,
                        std::string end_time_stamp, int max_size,
                        std::vector<ItemInfoEntity>* item_list);
 private:
  bool BuildSourceEntityFromResult(sql::ResultSet* res, SourceEntity& ent);
  bool BuildItemInfoEntityFromResult(sql::ResultSet* res, ItemInfoEntity& ent);
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  static const int kRetryTimes = 3;
};

#endif
