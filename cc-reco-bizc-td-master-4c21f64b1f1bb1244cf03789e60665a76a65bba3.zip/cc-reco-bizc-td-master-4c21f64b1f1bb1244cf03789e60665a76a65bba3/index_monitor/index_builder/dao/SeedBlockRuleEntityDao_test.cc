#include <stdio.h>
#include <vector>
#include <unordered_map>      
#include <utility>
#include <set>                
#include <string>             

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/common/base.h" 
#include "base/time/time.h"

#include "reco/bizc/index_monitor/index_builder/dao/SeedBlockRuleEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/dao/SeedEntityDao.h"


class SeedBlockRuleEntityDaoTest : public testing::Test {
 protected:
  virtual void SetUp() {
  }

  virtual void TearDown() {
  }
};

TEST_F(SeedBlockRuleEntityDaoTest, Test_getBySeedId) {
  SeedBlockRuleEntityDao seed_block_rule_dao;
  SeedEntityDao seed_dao;
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = "tcp://11.251.203.145:3306";
  db_option.schema = "reco";
  db_option.user = "recodev";
  db_option.passwd = "tkDn19DHeVZkNA";
  seed_block_rule_dao.Init(db_option);
  seed_dao.Init(db_option);

  std::vector<SeedEntity> seeds;
  seed_dao.getAllSeedList(&seeds);
  EXPECT_GT(seeds.size(), (size_t)0);

  printf("size of seeds is : %d\n", (int)seeds.size());

  for (size_t i = 0; i < seeds.size() && i < 10; ++i) {
    printf("NO.%d: %s\n",(int)i, seeds.at(i).to_string().c_str());

    std::vector<SeedBlockRuleEntity> rule_list;
    seed_block_rule_dao.getBySeedId(seeds.at(i).get_id(), &rule_list);

    if (rule_list.size() != 0) {
      printf("size of rule_list is : %d\n", (int)rule_list.size());

      for (size_t j = 0; j < rule_list.size() && j < 10; ++j) {
        printf("NO.%d: %s\n",(int)j, rule_list.at(j).to_string().c_str());
      }
    }
  }
}




