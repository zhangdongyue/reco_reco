#include "reco/bizc/index_monitor/index_builder/dao/ItemUgcEntityDao.h"

#include <vector>

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

DEFINE_string(item_ugc_table, "tb_item_ugc", "item ugc table name");

void ItemUgcEntityDao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

void ItemUgcEntityDao::GetUgcItemsByCreateTime(const std::string& start_time,
                                               const std::string& end_time,
                                               std::vector<ItemUgcEntity> *item_list) {
  CHECK_NOTNULL(item_list);
  TimeConsume time_consume("ItemUgcEntityDao_GetUgcItemsByCreateTime");
  std::string sql = base::StringPrintf("select id, item_id, score, create_time,modify_time "
                                       "from %s where create_time >= '%s' and create_time < '%s'",
                                       FLAGS_item_ugc_table.c_str(), start_time.c_str(), end_time.c_str());

  LOG(INFO) << "SQL : [ "<< sql << " ]";

  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      serving_base::Timer timer;
      timer.Start();
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));
      LOG(INFO) << "ItemUgcEntityDao_GetUgcItemsByCreateTime_sql_cost:" << timer.Stop();

      item_list->clear();

      timer.Start();
      while (res->next()) {
        ItemUgcEntity entity;
        item_list->push_back(entity);
        if (!BuildItemUgcEntityFromResult(res.get(), item_list->back())) {
          item_list->pop_back();
        }
      }
      LOG(INFO) << "ItemUgcEntityDao_GetUgcItemsByCreateTime_sql_cost:" << timer.Stop()
                << ", num:" << res->getRow();
      break;
    } catch (sql::SQLException& e) {
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

bool ItemUgcEntityDao::BuildItemUgcEntityFromResult(sql::ResultSet* res, ItemUgcEntity &ent) {
  CHECK_NOTNULL(res);
  try {
    uint64 id = res->getUInt64("id");
    ent.set_id(id);

    std::string item_id = res->getString("item_id");
    ent.set_item_id(item_id);

    double score = res->getDouble("score");
    ent.set_score(score);

    std::string create_time_literal = res->getString("create_time");
    base::Time create_time;
    if (base::Time::FromStringInSeconds(create_time_literal.c_str(), &create_time)) {
      ent.set_create_time(create_time);
    }

    std::string modify_time_literal = res->getString("modify_time");
    base::Time modify_time;
    if (base::Time::FromStringInSeconds(modify_time_literal.c_str(), &modify_time)) {
      ent.set_create_time(modify_time);
    }
  } catch (...) {
    LOG(ERROR) << "build item channel entity fail.";
  }
  if (!ent.check_valid()) {
    return false;
  }
  return true;
}

