//
// Created by allen.fw on 2017/10/31.
//

#pragma once

#include <memory>
#include <vector>
#include "serving_base/mysql_util/db_conn_manager.h"

namespace thread {
class ThreadPool;
}

namespace reco {
namespace index_builder {

class BaseHandler;
class BaseSelector;

class RegisterFactory {
 public:
  explicit RegisterFactory(const serving_base::mysql_util::DbConnManager::Option &db_option);
  ~RegisterFactory();

  void AsyncProcess();
  void JoinAll();

 private:
  void RegisterHandler(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void RegisterManualSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void RegisterNewsSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void RegisterVideoSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);
  void RegisterSourceItemsSelector(const serving_base::mysql_util::DbConnManager::Option &db_option);

 private:
  std::shared_ptr<thread::ThreadPool> process_pool_;
  std::vector<std::shared_ptr<BaseHandler> > handlers_;
  std::vector<std::shared_ptr<BaseSelector> > selectors_;
};
}
}
