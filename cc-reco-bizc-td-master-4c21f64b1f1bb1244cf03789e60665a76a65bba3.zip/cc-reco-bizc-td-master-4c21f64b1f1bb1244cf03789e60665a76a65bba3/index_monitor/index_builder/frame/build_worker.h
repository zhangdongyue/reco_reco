//
// Created by allen.fw on 2017/10/13.
//

#pragma once

#include <memory>
#include <string>
#include "base/container/dense_hash_set.h"
#include "base/container/dense_hash_map.h"
#include "base/thread/blocking_queue.h"
#include "reco/bizc/index_monitor/index_builder/dao/SeedEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/strategy/item_filter.h"
#include "reco/bizc/index_monitor/index_builder/dao/ProducerEntityDao.h"

#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace net {
namespace rpc {
class RpcGroup;
}
}

namespace reco {

namespace sim_lib {
class SimLib;
}

namespace index_builder {

class ItemBaptismBase;

class BuildWorker {
 public:
  explicit BuildWorker(const serving_base::mysql_util::DbConnManager::Option &db_option);
  ~BuildWorker();

  void Worker();

 private:
  void IndexProcessWorker();

  void IndexBuildWorker();
  void DumpHa3docWorker();

  void RecordValidItemId();

  void GetSimData();

  bool ConvertRecoItemToCDoc(const reco::RecoItem& reco_item, std::string* cdoc_str);
  bool ConvertRecoItemToHa3Doc(const reco::RecoItem& reco_item, std::string* ha3doc_str);

  bool GetRecoItemFromItemKeeper(const uint64 item_id, reco::RecoItem* item);

  bool SetValidIdIntoSet(const uint64 item_id);
  bool PutRecoItemIntoQueue(const reco::RecoItem& reco_item);
  bool GetRecoItemFromCache(const uint64 item_id, reco::RecoItem* item);
  void GetProcessNum(const ItemQueueEntity& entity);

  std::shared_ptr<ItemBaptismBase> GetItemBaptism(ItemBaptismType type);

  inline base::Time GetStartOfDay(const base::Time& t) {
    base::Time::Exploded exploded;
    t.LocalExplode(&exploded);
    exploded.hour = 0;
    exploded.minute = 0;
    exploded.second = 0;
    exploded.millisecond = 0;
    return base::Time::FromLocalExploded(exploded);
  }

 private:
  base::dense_hash_set<std::string> valid_id_set_;
  thread::BlockingQueue<uint64> valid_id_queue_;
  thread::Mutex valid_mutex_;

  thread::BlockingQueue<std::string> cdoc_queue_;
  thread::BlockingQueue<std::string> ha3doc_queue_;

  net::rpc::RpcGroup* convert_rpc_group_;
  thread::BlockingQueue<reco::convertor::ConvertorService::Stub*> convert_stub_queue_;

  net::rpc::RpcGroup* item_keeper_rpc_group_;
  reco::itemkeeper::ItemKeeper::Stub* item_keeper_stub_;

  int dudep_filter_num_;
  std::atomic<int> total_process_num_;
  std::atomic<int> channel_item_num_;
  std::atomic<int> total_video_num_;
  std::atomic<int> publish_item_num_;
  std::atomic<int> publish_video_num_;
  std::atomic<int> finish_item_num_;
  std::atomic<int> direct_process_item_num_;
  std::atomic<int> tag_video_item_num_;
  std::atomic<int> no_baptism_process_item_num_;
  std::atomic<int> recom_item_cache_num_;
  std::atomic<int> dedup_valid_id_num_;

  reco::sim_lib::SimLib* sim_lib_;
  base::Time sim_start_time_;

  std::shared_ptr<serving_base::ExpiryMap<uint64, RecoItem> > reco_item_cache_;

  std::shared_ptr<ItemBaptismBase> channel_item_baptism_;
  std::shared_ptr<ItemBaptismBase> direct_item_baptism_;
  std::shared_ptr<ItemBaptismBase> tag_item_baptism_;
  std::shared_ptr<ItemBaptismBase> base_item_baptism_;
};
}
}
