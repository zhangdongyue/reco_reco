//
// Created by allen.fw on 2017/11/10.
//

#pragma once

#include <memory>
#include <string>
#include <vector>
#include <unordered_map>
#include <reco/bizc/common/index_strategy_define.h>
#include "base/container/dense_hash_set.h"
#include "base/container/dense_hash_map.h"
#include "reco/bizc/index_monitor/index_builder/common/item_queue_entity.h"

namespace reco {
namespace index_builder {

class IndexIterator {
 public:
  explicit IndexIterator(const std::string& file_name) : out_file_name_(file_name) {}
  virtual ~IndexIterator() {}
  virtual bool HasNext() = 0;
  virtual std::string Next() = 0;
  const std::string& GetOutFileName() {
    return out_file_name_;
  }
 protected:
  const std::string out_file_name_;
};

class ValidItemIterator : public IndexIterator {
 public:
  explicit ValidItemIterator(const std::string& file_name,
                             const base::dense_hash_set<std::string>& valid_id_set);
  virtual ~ValidItemIterator();
  virtual bool HasNext();
  virtual std::string Next();

 private:
  const base::dense_hash_set<std::string>& valid_id_set_;
  base::dense_hash_set<std::string>::const_iterator iter_;
};

class ValidStrategyIterator : public IndexIterator {
 public:
  explicit ValidStrategyIterator(const std::string& file_name,
                                 const base::dense_hash_set<std::string>& valid_id_set);
  virtual ~ValidStrategyIterator();
  virtual bool HasNext();
  virtual std::string Next();

 private:
  const base::dense_hash_set<std::string>& valid_id_set_;
  base::dense_hash_set<std::string>::const_iterator iter_;
};

class SourceNumIterator : public IndexIterator {
 public:
  explicit SourceNumIterator(const std::string& file_name);
  virtual ~SourceNumIterator();
  virtual bool HasNext();
  virtual std::string Next();

 private:
  const std::unordered_map<std::string, int>& source_item_num_;
  std::unordered_map<std::string, int>::const_iterator iter_;
};

class AllItemStrategyIterator : public IndexIterator {
 public:
  explicit AllItemStrategyIterator(const std::string& file_name,
                                   const base::dense_hash_set<std::string>& valid_id_set);
  virtual ~AllItemStrategyIterator();

  virtual bool HasNext();
  virtual std::string Next();

 private:
  const base::dense_hash_set<std::string>& valid_id_set_;
  base::dense_hash_map<std::string, reco::common::IndexStrategyBranch>::const_iterator item_iter_;
};

class DumpIndexItem {
 public:
  explicit DumpIndexItem(const base::dense_hash_set<std::string>& valid_id_set);
  ~DumpIndexItem();

  void CreateIterators(std::vector<std::shared_ptr<IndexIterator> >* index_iterators);
  void DumpItem();

 private:
  const base::dense_hash_set<std::string>& valid_id_set_;
};
}
}
