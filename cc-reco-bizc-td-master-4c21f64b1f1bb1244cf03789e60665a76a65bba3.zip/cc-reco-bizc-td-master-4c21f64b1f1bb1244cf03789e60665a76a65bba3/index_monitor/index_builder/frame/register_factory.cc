//
// Created by allen.fw on 2017/10/31.
//

#include <string>
#include "reco/bizc/index_monitor/index_builder/frame/register_factory.h"
#include "base/strings/string_split.h"
#include "base/thread/thread_pool.h"

#include "reco/bizc/index_monitor/index_builder/handler/app_channel_handler.h"
#include "reco/bizc/index_monitor/index_builder/handler/item_category_handler.h"
#include "reco/bizc/index_monitor/index_builder/handler/source_handler.h"

#include "reco/bizc/index_monitor/index_builder/selector/ucb_selector.h"
#include "reco/bizc/index_monitor/index_builder/selector/leaf_selector.h"
#include "reco/bizc/index_monitor/index_builder/selector/superb_selector.h"
#include "reco/bizc/index_monitor/index_builder/selector/good_mine_selector.h"
#include "reco/bizc/index_monitor/index_builder/selector/recall_selector.h"
#include "reco/bizc/index_monitor/index_builder/selector/comment_selector.h"

#include "reco/bizc/index_monitor/index_builder/selector/video_selector.h"
#include "reco/bizc/index_monitor/index_builder/selector/subject_selector.h"
#include "reco/bizc/index_monitor/index_builder/selector/tag_items_selector.h"
#include "reco/bizc/index_monitor/index_builder/selector/source_selector.h"
#include "reco/bizc/index_monitor/index_builder/selector/jingpin_selector.h"
#include "reco/bizc/index_monitor/index_builder/selector/ugc_selector.h"

#include "reco/bizc/index_monitor/index_builder/selector/source_items_selector.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

DEFINE_string(commands, "manual,news,video", "commands");
DEFINE_bool(app_channel_handler, true, "if true, handle app channel");
DEFINE_bool(item_category_handler, true, "if true, handle item category");
DEFINE_bool(source_handler, true, "if true, handle source");

DEFINE_bool(process_superb_item, true, "if true, process superb item");
DEFINE_bool(process_goodmine_item, true, "if true, process leaf goodmine item");
DEFINE_bool(process_recall_item, true, "if true, process leaf recall item");
DEFINE_bool(process_comment_item, true, "if true, process leaf comment item");

DEFINE_bool(process_subject_item, true, "if true, process subject item");
DEFINE_bool(process_tag, true, "if true, process tag item");
DEFINE_bool(process_source_item, true, "if true, process source item");
DEFINE_bool(process_jingpin_item, true, "if true, process jingpin item");
DEFINE_bool(process_ugc_item, true, "if true, process ugc item");

RegisterFactory::RegisterFactory(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  std::string commands_str = FLAGS_commands;
  std::vector<std::string> command_vec;
  base::SplitString(commands_str, ",", &command_vec);
  CHECK(!command_vec.empty());

  RegisterHandler(db_option);
  std::vector<std::string> process_commands;
  for (size_t i = 0; i < command_vec.size(); ++i) {
    if (command_vec.at(i) == "manual") {
      RegisterManualSelector(db_option);
      process_commands.emplace_back("manual");
    } else if (command_vec.at(i) == "news") {
      RegisterNewsSelector(db_option);
      process_commands.emplace_back("news");
    } else if (command_vec.at(i) == "video") {
      RegisterVideoSelector(db_option);
      process_commands.emplace_back("video");
    } else if (command_vec.at(i) == "source_items") {
      RegisterSourceItemsSelector(db_option);
      process_commands.emplace_back("source_items");
    }
  }
  LOG(INFO) << "process_commands: " << base::JoinStrings(process_commands, ",");
}

RegisterFactory::~RegisterFactory() {
}

void RegisterFactory::AsyncProcess() {
  std::vector<std::string> handlers;
  process_pool_ = std::make_shared<thread::ThreadPool>(static_cast<int>(
                                                               handlers_.size() + selectors_.size()));
  for (size_t i = 0; i < handlers_.size(); ++i) {
    process_pool_->AddTask(NewCallback(handlers_[i].get(), &BaseHandler::Handle));
    handlers.emplace_back(handlers_[i]->GetHandlerName());
  }
  LOG(INFO) << "async handlers: " << base::JoinStrings(handlers, ",");

  std::vector<std::string> selectors;
  for (size_t i = 0; i < selectors_.size(); ++i) {
    process_pool_->AddTask(NewCallback(selectors_[i].get(), &BaseSelector::Process));
    selectors.emplace_back(selectors_[i]->GetSelectorName());
  }
  LOG(INFO) << "async selectors: " << base::JoinStrings(selectors, ",");
}

void RegisterFactory::JoinAll() {
  process_pool_->JoinAll();
  reco::index_builder::GlobalIndexDataIns::instance().item_queue_.Close();
  LOG(INFO) << "handle and selector end";
}

void RegisterFactory::RegisterHandler(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  if (FLAGS_app_channel_handler) {
    handlers_.emplace_back(std::make_shared<AppChannelHandler>(db_option));
  }
  if (FLAGS_item_category_handler) {
    handlers_.emplace_back(std::make_shared<ItemCategoryHandler>(db_option));
  }
  if (FLAGS_source_handler) {
    handlers_.emplace_back(std::make_shared<SourceHandler>(db_option));
  }
}

void RegisterFactory::RegisterManualSelector(
        const serving_base::mysql_util::DbConnManager::Option &db_option) {
  selectors_.emplace_back(std::make_shared<UCBSelector>(db_option));
}

void RegisterFactory::RegisterNewsSelector(
        const serving_base::mysql_util::DbConnManager::Option &db_option) {
  selectors_.emplace_back(std::make_shared<LeafSelector>(db_option));

  if (FLAGS_process_superb_item) {
    selectors_.emplace_back(std::make_shared<SuperbSelector>(db_option));
  }

  if (FLAGS_process_goodmine_item) {
    selectors_.emplace_back(std::make_shared<GoodMineSelector>(db_option));
  }

  if (FLAGS_process_recall_item) {
    selectors_.emplace_back(std::make_shared<RecallSelector>(db_option));
  }

  if (FLAGS_process_comment_item) {
    selectors_.emplace_back(std::make_shared<CommentSelector>(db_option));
  }
}

void RegisterFactory::RegisterVideoSelector(
        const serving_base::mysql_util::DbConnManager::Option &db_option) {
  selectors_.emplace_back(std::make_shared<VideoSelector>(db_option));

  if (FLAGS_process_subject_item) {
    selectors_.emplace_back(std::make_shared<SubjectSelector>(db_option));
  }

  if (FLAGS_process_tag) {
    selectors_.emplace_back(std::make_shared<TagItemsSelector>(db_option));
  }

  if (FLAGS_process_source_item) {
    selectors_.emplace_back(std::make_shared<SourceSelector>(db_option));
  }

  if (FLAGS_process_jingpin_item) {
    selectors_.emplace_back(std::make_shared<JingpinSelector>(db_option));
  }
  if (FLAGS_process_ugc_item) {
    selectors_.emplace_back(std::make_shared<UgcSelector>(db_option));
  }
}

void RegisterFactory::RegisterSourceItemsSelector(
        const serving_base::mysql_util::DbConnManager::Option &db_option) {
  selectors_.emplace_back(std::make_shared<SourceItemsSelector>(db_option));
}
}
}
