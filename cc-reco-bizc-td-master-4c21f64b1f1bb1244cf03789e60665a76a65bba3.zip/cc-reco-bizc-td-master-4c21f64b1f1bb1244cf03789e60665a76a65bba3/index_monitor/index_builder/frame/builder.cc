//
// Created by allen.fw on 2017/10/26.
//

#include <string>
#include <vector>

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/strings/string_split.h"
#include "reco/bizc/index_monitor/index_builder/handler/app_channel_handler.h"
#include "reco/bizc/index_monitor/index_builder/handler/source_handler.h"
#include "reco/bizc/index_monitor/index_builder/handler/item_category_handler.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "reco/bizc/index_monitor/index_builder/frame/build_worker.h"
#include "reco/bizc/index_monitor/index_builder/frame/register_factory.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

DEFINE_string(db_host, "tcp://11.251.204.223:3307", "dbhost");
DEFINE_string(db_user, "recodev", "db user");
DEFINE_string(db_passwd, "tkDn19DHeVZkNA", "db pswd");
DEFINE_string(db_name, "reco", "dbname");

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "build index for reco item data");
  if (reco::index_builder::FLAGS_build_index_type != "static"
      && reco::index_builder::FLAGS_build_index_type != "dynamic") {
    LOG(ERROR) << "build index type should be static or dynamic .";
    return 1;
  }

  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.schema = FLAGS_db_name;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  reco::index_builder::GlobalIndexDataIns::instance().InitData(db_option);
  // 这一句必须要,不然获取 hbase 句柄会超时还不打日志
  reco::hbase::HBasePoolIns::instance().Init();

  reco::index_builder::RegisterFactory register_factory(db_option);
  register_factory.AsyncProcess();

  reco::index_builder::BuildWorker* worker = new reco::index_builder::BuildWorker(db_option);
  thread::Thread work_thread;
  work_thread.Start(NewCallback(worker, &reco::index_builder::BuildWorker::Worker));

  register_factory.JoinAll();

  work_thread.Join();

  return 0;
}
