//
// Created by allen.fw on 2017/11/10.
//

#include <fstream>
#include "reco/bizc/index_monitor/index_builder/frame/dump_index_item.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "base/common/logging.h"
#include "base/strings/string_printf.h"

namespace reco {
namespace index_builder {

DEFINE_string(id_file, "index_item_id", "id file name");
DEFINE_string(strategy_branch_file, "index_item_strategy", "item id and strategy branch file name");
DEFINE_string(source_item_num_file, "source_item_num", "source item_num file");
DEFINE_string(id_publish_file, "index_item_publish_strategy", "index item publish strategy file");

/******************************************ValidItemIterator******************************/
ValidItemIterator::ValidItemIterator(const std::string& file_name,
                                     const base::dense_hash_set<std::string>& valid_id_set)
        : IndexIterator(file_name), valid_id_set_(valid_id_set), iter_(valid_id_set_.begin()) {
}

ValidItemIterator::~ValidItemIterator() {
}

bool ValidItemIterator::HasNext() {
  if (iter_ == valid_id_set_.end()) {
    return false;
  }
  return true;
}

std::string ValidItemIterator::Next() {
  std::string valid_id = *iter_ + "\n";
  ++iter_;
  return valid_id;
}

/******************************************ValidStrategyIterator******************************/
ValidStrategyIterator::ValidStrategyIterator(const std::string& file_name,
                                             const base::dense_hash_set<std::string>& valid_id_set)
        : IndexIterator(file_name), valid_id_set_(valid_id_set), iter_(valid_id_set_.begin()) {
}

ValidStrategyIterator::~ValidStrategyIterator() {
}

bool ValidStrategyIterator::HasNext() {
  if (iter_ == valid_id_set_.end()) {
    return false;
  }
  return true;
}

std::string ValidStrategyIterator::Next() {
  auto& valid_item_strategy = GlobalIndexDataIns::instance().valid_item_strategy_;
  const std::string& item_id = *iter_;
  ++iter_;
  auto iter = valid_item_strategy.find(item_id);
  if (iter == valid_item_strategy.end()) {
    LOG(WARNING) << "item has no strategy branch : " << item_id;
    return base::StringPrintf("%s\t%d\n", item_id.c_str(), reco::common::kUnknownStrategy.enum_value);
  }
  return base::StringPrintf("%s\t%d\n", iter->first.c_str(), iter->second.enum_value);
}

/******************************************SourceNumIterator******************************/
SourceNumIterator::SourceNumIterator(const std::string& file_name)
        : IndexIterator(file_name), source_item_num_(GlobalIndexDataIns::instance().source_item_num_),
          iter_(source_item_num_.begin()) {
}

SourceNumIterator::~SourceNumIterator() {
}

bool SourceNumIterator::HasNext() {
  if (iter_ == source_item_num_.end()) {
    return false;
  }
  return true;
}

std::string SourceNumIterator::Next() {
  std::string source_num = iter_->first + ":" + base::IntToString(iter_->second) + "\n";
  ++iter_;
  return source_num;
}

/******************************************AllItemStrategyIterator******************************/
AllItemStrategyIterator::AllItemStrategyIterator(const std::string& file_name,
                                                 const base::dense_hash_set<std::string>& valid_id_set)
    : IndexIterator(file_name), valid_id_set_(valid_id_set),
      item_iter_(GlobalIndexDataIns::instance().valid_item_strategy_.begin()) {
}

AllItemStrategyIterator::~AllItemStrategyIterator() {
}

bool AllItemStrategyIterator::HasNext() {
  auto& valid_item_strategy = GlobalIndexDataIns::instance().valid_item_strategy_;
  return (item_iter_ != valid_item_strategy.end());
}

std::string AllItemStrategyIterator::Next() {
  auto& invalid_item_strategy = GlobalIndexDataIns::instance().invalid_item_strategy_;

  std::string out_string = item_iter_->first;
  out_string.append("\t");
  out_string.append(item_iter_->second.comment);

  auto valid_item = valid_id_set_.find(item_iter_->first);
  if (valid_item != valid_id_set_.end()) {
    out_string.append("\t0");
  } else {
    out_string.append("\t1");
    auto iter = invalid_item_strategy.find(item_iter_->first);
    if (iter == invalid_item_strategy.end()) {
      out_string.append("\t");
      out_string.append(reco::common::kUnknownItemFilter.comment);
    } else {
      out_string.append("\t");
      out_string.append(iter->second.comment);
    }
  }
  out_string.append("\n");
  ++item_iter_;

  return out_string;
}

/******************************************DumpIndexItem******************************/
DumpIndexItem::DumpIndexItem(const base::dense_hash_set<std::string>& valid_id_set)
        : valid_id_set_(valid_id_set) {
}

void DumpIndexItem::CreateIterators(std::vector<std::shared_ptr<IndexIterator> >* index_iterators) {
  index_iterators->emplace_back(std::make_shared<ValidItemIterator>(
          FLAGS_index_dir + "/" + FLAGS_id_file, valid_id_set_));
  index_iterators->emplace_back(std::make_shared<ValidStrategyIterator>(
          FLAGS_index_dir + "/" + FLAGS_strategy_branch_file, valid_id_set_));
  index_iterators->emplace_back(std::make_shared<SourceNumIterator>(
          FLAGS_index_dir + "/" + FLAGS_source_item_num_file));
  index_iterators->emplace_back(std::make_shared<AllItemStrategyIterator>(
          FLAGS_index_dir + "/" + FLAGS_id_publish_file, valid_id_set_));
}

DumpIndexItem::~DumpIndexItem() {
}

void DumpIndexItem::DumpItem() {
  std::vector<std::shared_ptr<IndexIterator> > index_iterators;
  CreateIterators(&index_iterators);

  for (size_t i = 0; i < index_iterators.size(); ++i) {
    const std::string& file_name = index_iterators[i]->GetOutFileName();
    std::ofstream output(file_name);
    int count = 0;
    while (index_iterators[i]->HasNext()) {
      std::string out_str = index_iterators[i]->Next();
      int size = out_str.length();
      output.write(out_str.c_str(), size);
      ++count;
    }
    output.close();
    LOG(INFO) << "dump [" << file_name << "] finish, num: " << count;
  }
}
}
}
