//
// Created by allen.fw on 2017/10/13.
//

#include "reco/bizc/index_monitor/index_builder/frame/build_worker.h"

#include <algorithm>
#include <fstream>
#include <string>
#include <vector>
#include "base/common/sleep.h"
#include "net/rpc_util/rpc_group.h"
#include "base/strings/string_printf.h"
#include "ads_index/api/public.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/sim_lib/sim_lib.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"
#include "reco/bizc/index_monitor/index_builder/strategy/channel_item_baptism.h"
#include "reco/bizc/index_monitor/index_builder/strategy/direct_item_baptism.h"
#include "reco/bizc/index_monitor/index_builder/strategy/tag_item_baptism.h"
#include "reco/bizc/index_monitor/index_builder/frame/dump_index_item.h"

namespace reco {
namespace index_builder {

DEFINE_bool(convert_reco_item, false, "if true, use convertor to renew reco item");
DEFINE_string(convertor_server_ip, "11.251.203.75,11.251.203.226,11.251.204.31", "server ip");
DEFINE_int32(convertor_server_port, 20021, "server port");
DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_int32(estimated_doc_num, 2000000, "estimated num of doc");
DEFINE_string(build_index_type, "static", "index type: dynamic or static");
DEFINE_string(reco_index_dir, "index_root", "reco output file dir");
DEFINE_bool(process_sim, true, "if true, process sim");
DEFINE_bool(sim_time_offset_startofday, false, "");
DEFINE_int64(sim_time_offset, 3600, "");
DEFINE_int32(tag_process_thread_num, 12, "num of tag process thread");
DEFINE_int32(reco_item_cache_seconds, 600, "reco item cache seconds");

BuildWorker::BuildWorker(const serving_base::mysql_util::DbConnManager::Option &db_option)
        : channel_item_num_(0), total_video_num_(0), publish_item_num_(0),
          publish_video_num_(0), finish_item_num_(0), direct_process_item_num_(0),
          tag_video_item_num_(0), no_baptism_process_item_num_(0), recom_item_cache_num_(0),
          dedup_valid_id_num_(0), sim_lib_(new reco::sim_lib::SimLib(true)) {
  LOG(INFO) << "start init convert_rpc";
  valid_id_set_.set_empty_key("");
  if (FLAGS_reco_item_cache_seconds > 0) {
    reco_item_cache_ = std::make_shared<serving_base::ExpiryMap<uint64, RecoItem> >(
            FLAGS_reco_item_cache_seconds);
  }

  convert_rpc_group_ = SetupConnection(FLAGS_convertor_server_ip, FLAGS_convertor_server_port, 10000, -1);
  for (int i = 0; i < FLAGS_work_thread_num; ++i) {
    convert_stub_queue_.Put(new reco::convertor::ConvertorService::Stub(convert_rpc_group_));
  }
  LOG(INFO) << "finish init convert_rpc";

  LOG(INFO) << "start init item_keeper_rpc";
  item_keeper_rpc_group_ = SetupConnection(FLAGS_item_keeper_server_ip,
                                           FLAGS_item_keeper_server_port,
                                           10000, 3);
  item_keeper_stub_ = new reco::itemkeeper::ItemKeeper::Stub(item_keeper_rpc_group_);
  LOG(INFO) << "finish init item_keeper_rpc";

  channel_item_baptism_ = std::make_shared<ChannelItemBaptism>(db_option);
  direct_item_baptism_ = std::make_shared<DirectItemBaptism>();
  tag_item_baptism_ = std::make_shared<TagItemBaptism>();
  base_item_baptism_ = std::make_shared<ItemBaptismBase>();
}

BuildWorker::~BuildWorker() {
  if (convert_rpc_group_ != NULL) {
    delete convert_rpc_group_;
  }
  if (item_keeper_rpc_group_ != NULL) {
    delete item_keeper_rpc_group_;
  }
  if (item_keeper_stub_ != NULL) {
    delete item_keeper_stub_;
  }
  if (sim_lib_ != NULL) {
    delete sim_lib_;
  }
}

void BuildWorker::Worker() {
  thread::Thread get_sim_data_thread;
  get_sim_data_thread.Start(NewCallback(this, &BuildWorker::GetSimData));

  thread::Thread build_index_thread;
  build_index_thread.Start(NewCallback(this, &BuildWorker::IndexBuildWorker));

  thread::Thread dump_ha3doc_thread;
  if (FLAGS_process_ha3doc) {
    dump_ha3doc_thread.Start(NewCallback(this, &BuildWorker::DumpHa3docWorker));
  }

  thread::ThreadPool work_pool(FLAGS_work_thread_num);
  for (int i = 0; i < FLAGS_work_thread_num; ++i) {
    work_pool.AddTask(::NewCallback<BuildWorker>(this, &BuildWorker::IndexProcessWorker));
  }

  work_pool.JoinAll();

  LOG(INFO) << "total process items: " << total_process_num_;
  LOG(INFO) << "total publish channel items: " << publish_item_num_;
  LOG(INFO) << "total channel video item num : " << total_video_num_;
  LOG(INFO) << "publish channel video item num : " << publish_video_num_;
  LOG(INFO) << "filtered channel video item num : " << total_video_num_ - publish_video_num_;
  LOG(INFO) << "get reco item num from cache: " << recom_item_cache_num_
            << ", dedup valid id num: " << dedup_valid_id_num_;

  valid_id_queue_.Close();

  cdoc_queue_.Close();
  ha3doc_queue_.Close();

  build_index_thread.Join();
  LOG(INFO) << "collect cdoc finished. num : " << finish_item_num_;
  LOG(INFO) << "total tag video items: " << tag_video_item_num_;
  LOG(INFO) << "total no filter strategy items: " << no_baptism_process_item_num_;
  LOG(INFO) << "total direct process items: " << direct_process_item_num_;
  LOG(INFO) << "total channel items: " << channel_item_num_;

  if (FLAGS_process_ha3doc) {
    dump_ha3doc_thread.Join();
  }

  get_sim_data_thread.Join();

  LOG(INFO) << "get sim data end";

  RecordValidItemId();
}

void BuildWorker::RecordValidItemId() {
  DumpIndexItem dump_valid_item(valid_id_set_);
  dump_valid_item.DumpItem();
}

void BuildWorker::IndexBuildWorker() {
  std::vector<std::string> cdoc_strings;
  cdoc_strings.reserve(FLAGS_estimated_doc_num);
  while (!cdoc_queue_.Closed() || !cdoc_queue_.Empty()) {
    if (cdoc_queue_.Empty()) {
      base::SleepForSeconds(1);
      continue;
    }
    cdoc_strings.push_back("");
    int status = cdoc_queue_.TimedTake(10, &cdoc_strings.back());

    if (status != 1) {
      cdoc_strings.erase(cdoc_strings.end() - 1);

      if (status == -1) break;

      if (status == 0) continue;

      LOG(ERROR) << "unknown erro occured: " << status;
      continue;
    }
    ++finish_item_num_;
    if (finish_item_num_ % 10000 == 0) {
      LOG(INFO) << finish_item_num_ << " item finished. ";
    }
  }

  // build static index
  if (FLAGS_build_index_type == "static") {
    LOG(INFO) << "build static index...";
    adsindexing::BuildStaticIndex(cdoc_strings, FLAGS_reco_index_dir);
    LOG(INFO) << "build static index finish.";
    return;
  }
  // build dynamic index
  if (FLAGS_build_index_type == "dynamic") {
    int file_max_doc_count = 1 << 13;
    std::string doc_prefix = FLAGS_reco_index_dir + "/dynamic_index_doc.";
    std::string doc_count_prefix = FLAGS_reco_index_dir + "/dynamic_index_doc_count.";
    for (int part = 0; part * file_max_doc_count < (int)cdoc_strings.size(); ++part) {
      std::ofstream doc_output(doc_prefix + base::IntToString(part));
      std::ofstream doc_count_output(doc_count_prefix + base::IntToString(part));
      int part_num = std::min(file_max_doc_count, (int)cdoc_strings.size() - part * file_max_doc_count);
      for (int i = part * file_max_doc_count; i < part * file_max_doc_count + part_num; ++i) {
        std::string compression_cdoc;
        CHECK(adsindexing::GetCompressionCDoc(cdoc_strings[i], &compression_cdoc));
        int size = compression_cdoc.size();
        doc_output.write(reinterpret_cast<const char *>(&size), sizeof(int));
        doc_output.write(compression_cdoc.data(), size);
      }
      doc_count_output.write(reinterpret_cast<const char *>(&part_num), sizeof(int));
      doc_output.close();
      doc_count_output.close();
    }
    LOG(INFO) << "build dynamic index finish.";
  }
}

void BuildWorker::DumpHa3docWorker() {
  std::string ofname = FLAGS_index_dir + "/ha3doc";
  std::ofstream ha3_ofresult(ofname);

  if (ha3_ofresult.is_open()) {
    LOG(INFO) << "open ha3outfile succ: " << ofname;
  } else {
    LOG(ERROR) << "open ha3outfile fail: " << ofname;
    return;
  }

  int doc_num = 0;
  while (!ha3doc_queue_.Closed() || !ha3doc_queue_.Empty()) {
    if (ha3doc_queue_.Empty()) {
      base::SleepForSeconds(1);
      continue;
    }
    std::string doc_str;
    int status = ha3doc_queue_.TimedTake(10, &doc_str);

    if (status != 1) {
      if (status == -1) break;

      if (status == 0) continue;

      LOG(ERROR) << "unknown erro occured: " << status;
      continue;
    }

    ha3_ofresult << doc_str;

    ++doc_num;
    if (doc_num % 10000 == 0) {
      LOG(INFO) << doc_num << " ha3doc dumped. ";
    }
  }

  ha3_ofresult.flush();
  ha3_ofresult.close();
  LOG(INFO) << "dump ha3doc finish. doc_num=" << doc_num;
}

void BuildWorker::IndexProcessWorker() {
  auto& item_queue = GlobalIndexDataIns::instance().item_queue_;

  while (!item_queue.Closed() || !item_queue.Empty()) {
    ItemQueueEntity entity;
    if (item_queue.Empty()) {
      base::SleepForSeconds(1);
      continue;
    }
    int status = item_queue.TimedTake(10, &entity);

    if (status == -1) break;
    if (status == 0) continue;

    if (status != 1) {
      LOG(ERROR) << "unknown erro occured: " << status;
      continue;
    }

    uint64 item_id = 0;
    if (!base::StringToUint64(entity.item_id, &item_id)) {
      LOG(ERROR) << "item id erro: " << entity.item_id;
      continue;
    }

    GetProcessNum(entity);

    reco::RecoItem item;
    if (!GetRecoItemFromItemKeeper(item_id, &item)) {
      continue;
    }

    std::shared_ptr<ItemBaptismBase> baptism = GetItemBaptism(entity.item_baptism_type);
    if (!baptism->ItemBaptism(entity, &item)) {
      continue;
    }

    if (!PutRecoItemIntoQueue(item)) {
      continue;
    }
  }
  LOG(INFO) << "IndexProcessWorker end";
}

void BuildWorker::GetProcessNum(const ItemQueueEntity& entity) {
  int processed_num = ++total_process_num_;
  if (processed_num % 10000 == 0) {
    LOG(INFO) << "total item processed : " << processed_num;
  }
  if (entity.item_type == 30) {
    ++total_video_num_;
  }

  switch (entity.item_baptism_type) {
    case kChannelItemBaptism:
      processed_num = ++channel_item_num_;
      if (processed_num % 1000 == 0) {
        LOG(INFO) << "channel item processed: " << processed_num;
      }
      break;
    case kDirectItemBaptism:
      processed_num = ++direct_process_item_num_;
      if (processed_num % 1000 == 0) {
        LOG(INFO) << "direct item processed: " << processed_num;
      }
      break;
    case kTagItemBaptism:
      processed_num = ++tag_video_item_num_;
      if (processed_num % 1000 == 0) {
        LOG(INFO) << "tag item processed: " << processed_num;
      }
      break;
    default:
      processed_num = ++no_baptism_process_item_num_;
      if (processed_num % 1000 == 0) {
        LOG(INFO) << "no baptism item processed: " << processed_num;
      }
      break;
  }
  return;
}

bool BuildWorker::PutRecoItemIntoQueue(const reco::RecoItem& reco_item) {
  uint64 item_id = reco_item.identity().item_id();
  std::string cdoc_str;
  if (!ConvertRecoItemToCDoc(reco_item, &cdoc_str)) {
    return false;
  }

  std::string ha3doc_str;
  if (FLAGS_process_ha3doc) {
    if (!ConvertRecoItemToHa3Doc(reco_item, &ha3doc_str)) {
      LOG(ERROR) << "convertRecoItemToHa3Doc fail, item_id=" << item_id;
      return false;
    }
  }

  if (!SetValidIdIntoSet(item_id)) {
    return false;
  }

  if (!cdoc_queue_.Put(cdoc_str)) {
    LOG(WARNING) << "put item to cdoc_queue fail, item_id: " << item_id;
  }

  if (FLAGS_process_ha3doc) {
    if (!ha3doc_queue_.Put(ha3doc_str)) {
      LOG(ERROR) << "put to ha3doc_queue_ fail. item_id=" << item_id;
    }
  }

  ++publish_item_num_;
  if (reco_item.identity().type() == reco::kThemeVideo
      || reco_item.identity().type() == reco::kPureVideo) {
    ++publish_video_num_;
  }

  return true;
}

void BuildWorker::GetSimData() {
  if (!FLAGS_process_sim || sim_lib_ == NULL) {
    return;
  }

  base::Time current_time = base::Time::Now();
  if (FLAGS_sim_time_offset_startofday) {
    sim_start_time_ = GetStartOfDay(current_time);
  } else {
    sim_start_time_ = current_time - base::TimeDelta::FromSeconds(FLAGS_sim_time_offset);
  }
  int64 timestamp = (int64)(sim_start_time_.ToDoubleT());
  LOG(INFO) << "sim timestamp : " << timestamp;
  sim_lib_->SetSimTimestamp(timestamp);
  sim_lib_->SetSimParentTimestamp(timestamp);
  sim_lib_->PrepareSimDataByIds(&valid_id_queue_);
  sim_lib_->DoDump(true);

  LOG(INFO) << "end to get sim data";
}

bool BuildWorker::ConvertRecoItemToCDoc(const reco::RecoItem& reco_item, std::string* cdoc_str) {
  reco::convertor::ConvertorService::Stub* convert_stub = NULL;

  reco::convertor::ConvertRecoItemRequest request;
  reco::convertor::ConvertRecoItemResponse response;
  request.mutable_reco_item()->CopyFrom(reco_item);
  net::rpc::RpcClientController rpc;
  convert_stub = convert_stub_queue_.Take();
  {
    TimeConsume timeConsume("convert_stub_convertRecoItem", 1000);
    convert_stub->convertRecoItem(&rpc, &request, &response, NULL);
    rpc.Wait();
  }
  convert_stub_queue_.Put(convert_stub);
  convert_stub = NULL;
  if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
    LOG(ERROR) << "convert reco item failed. "
               << response.err_msg() << rpc.status()
               << " item id : "
               << reco_item.identity().item_id();
    return false;
  } else {
    response.cdoc().SerializeToString(cdoc_str);
    LOG(INFO) << "done cdoc convert: " << reco_item.identity().item_id();
    return true;
  }
}

bool BuildWorker::ConvertRecoItemToHa3Doc(const reco::RecoItem& reco_item, std::string* ha3doc_str) {
  *ha3doc_str = "";
  reco::convertor::ConvertorService::Stub* convert_stub = NULL;

  reco::convertor::ConvertRecoItemRequest request;
  reco::convertor::ConvertRecoItem2Ha3DocResponse response;
  request.mutable_reco_item()->CopyFrom(reco_item);
  net::rpc::RpcClientController rpc;
  convert_stub = convert_stub_queue_.Take();
  {
    TimeConsume timeConsume("convert_stub_convertRecoItemHa3", 1000);
    convert_stub->convertRecoItem2Ha3Doc(&rpc, &request, &response, NULL);
    rpc.Wait();
  }
  convert_stub_queue_.Put(convert_stub);
  convert_stub = NULL;
  if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
    LOG(ERROR) << "convert reco item ha3 failed. "
               << response.err_msg() << rpc.status()
               << " item id : "
               << reco_item.identity().item_id();
    return false;
  } else {
    *ha3doc_str = response.res();
    LOG(INFO) << "done ha3doc convert: " << reco_item.identity().item_id();
    return true;
  }
}

bool BuildWorker::GetRecoItemFromItemKeeper(const uint64 item_id, reco::RecoItem* item) {
  if (GetRecoItemFromCache(item_id, item)) {
    return true;
  }

  if (FLAGS_convert_reco_item) {
    // 测试关掉这个开关
    reco::itemkeeper::RefreshRecoItemRequest request;
    reco::itemkeeper::RefreshRecoItemResponse response;
    request.mutable_service_identity()->set_service_name("index_builder");
    request.add_item_id(item_id);
    request.add_exclude_storages(reco::itemkeeper::kCdocQueue);

    net::rpc::RpcClientController rpc;
    {
      TimeConsume timeConsume("item_keeper_stub_refreshRecoItem", 1000);
      item_keeper_stub_->refreshRecoItem(&rpc, &request, &response, NULL);
      rpc.Wait();
    }
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()
        || response.reco_item_size() != 1) {
      LOG(ERROR) <<
      base::StringPrintf("refresh reco item failed. response error_message[%s], "
                                 "rpc status[%d], item_id[%lu], response_size[%d]",
                         response.err_message().c_str(), rpc.status(),
                         item_id, response.reco_item_size());
      return false;
    } else {
      LOG(INFO) << "done refresh reco item: " << item_id;
      item->CopyFrom(response.reco_item(0));
    }
  } else {
    reco::itemkeeper::GetRecoItemRequest request;
    reco::itemkeeper::GetRecoItemResponse response;
    request.add_item_id(item_id);

    net::rpc::RpcClientController rpc;
    {
      TimeConsume timeConsume("item_keeper_stub_getRecoItem", 1000);
      item_keeper_stub_->getRecoItem(&rpc, &request, &response, NULL);
      rpc.Wait();
    }
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()
        || response.reco_item_size() != 1) {
      LOG(ERROR) <<
      base::StringPrintf("get reco item failed. response error_message[%s], "
                                 "rpc status[%d], item_id[%lu], response_size[%d]",
                         response.err_message().c_str(), rpc.status(),
                         item_id, response.reco_item_size());
      return false;
    } else {
      item->CopyFrom(response.reco_item(0));
      LOG(INFO) << "done get reco item: " << item_id;
    }
  }
  if (FLAGS_reco_item_cache_seconds > 0) {
    reco_item_cache_->Add(item_id, *item);
  }

  return true;
}

bool BuildWorker::GetRecoItemFromCache(const uint64 item_id, reco::RecoItem* item) {
  if (FLAGS_reco_item_cache_seconds <= 0) {
    // no use cache
    return false;
  }

  if (reco_item_cache_->FindSilently(item_id, item)) {
    ++recom_item_cache_num_;
    if (recom_item_cache_num_ % 2000 == 0) {
      LOG(INFO) << recom_item_cache_num_ << " reco item geted from cache.";
    }
    return true;
  }
  return false;
}

bool BuildWorker::SetValidIdIntoSet(const uint64 item_id) {
  std::string item_id_str = base::Uint64ToString(item_id);
  {
    thread::AutoLock lock(&valid_mutex_);
    if (valid_id_set_.find(item_id_str) != valid_id_set_.end()) {
      ++dedup_valid_id_num_;
      return false;
    }
    valid_id_set_.insert(item_id_str);
  }
  valid_id_queue_.Put(item_id);
  return true;
}

std::shared_ptr<ItemBaptismBase> BuildWorker::GetItemBaptism(ItemBaptismType type) {
  switch (type) {
    case kChannelItemBaptism:
      return channel_item_baptism_;
    case kDirectItemBaptism:
      return direct_item_baptism_;
    case kTagItemBaptism:
      return tag_item_baptism_;
    default:
      return base_item_baptism_;
  }

  return base_item_baptism_;
}
}
}
