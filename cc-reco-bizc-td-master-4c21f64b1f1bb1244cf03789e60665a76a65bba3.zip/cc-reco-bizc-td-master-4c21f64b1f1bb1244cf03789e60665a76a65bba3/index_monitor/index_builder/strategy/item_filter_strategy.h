#pragma once

#include <string>
#include <unordered_set>
#include <unordered_map>
#include <vector>

#include "base/common/base.h"
#include "base/file/file_util.h"
#include "base/container/dense_hash_map.h"
namespace reco {
struct ItemFilterInfo {
  uint64 item_id;
  ItemType item_type;
  bool is_manual;
  int orgi_itemq;
  bool is_source_wemedia;
  int media_level;
  int site_level;
  bool is_trival;
  int erro_title;
  int advertorial;
  int short_content;
  int dedup_paragraph;
  int dirty;
  int politics;
  int bluffing_title;
  std::string title;
  std::string source;
  std::string source_media;
  std::string category;
  std::string sub_category;
  std::vector<std::string> tags;
  ItemFilterInfo() : item_id(0), item_type(kNone), is_manual(false), orgi_itemq(-1),
  is_source_wemedia(false), media_level(reco::kNormalMedia), site_level(reco::kMidQualitySite),
  is_trival(false), erro_title(-1), advertorial(-1),
  short_content(-1), dedup_paragraph(-1), dirty(-1),
  politics(-1), bluffing_title(-1), title(""),
  source(""), source_media(""), category(""), sub_category("") {
    tags.clear();
  }
};

class ItemFilterStrategy {
 public:
  ItemFilterStrategy();
  ~ItemFilterStrategy();
  bool FilterBadItem(const ItemFilterInfo* item);
 private:
  void LoadDizhiTag(const base::FilePath& base_dir);
  void PrintFilterDebug(const ItemFilterInfo* item, const std::string& reason);
  static const std::unordered_set<std::string> kCompeteSourceMediaSet;
  // 低质源词表
  std::unordered_map<std::string, int> dizhi_tag_map_;
  std::unordered_map<std::string, int> dizhi_category_map_;
  static const char* kDizhiTagFile;
};
}
