//
// Created by allen.fw on 2017/10/20.
//

#pragma once

#include <string>
#include <vector>
#include <unordered_set>
#include "reco/bizc/index_monitor/index_builder/entity/ItemChannelEntity.h"
#include "reco/bizc/index_monitor/index_builder/hbase/ItemMetaHBaseService.h"
#include "reco/bizc/index_monitor/index_builder/hbase/ItemSimHBaseService.h"

namespace reco {
namespace index_builder {

class RankItems {
 public:
  RankItems();
  ~RankItems();

  void RankCategoryItems(const std::string& key, std::vector<ItemChannelEntity>* items, int max_limit);

 private:
  void GetMetaThread(const std::vector<std::string>& items,
                     std::vector<reco::index_data::MetaData>* meta_vec,
                     int thread_id);
  void GetSimThread(const std::vector<std::string>& items,
                    std::vector<reco::index_data::SimData>* sim_vec,
                    bool get_whole_sim,
                    int thread_id);

 private:
  ItemMetaHBaseService* item_meta_hbase_service_;
  ItemSimHBaseService* item_sim_hbase_service_;
};
}
}
