//
// Created by allen.fw on 2017/11/1.
//

#include "reco/bizc/index_monitor/index_builder/strategy/tag_item_baptism.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

TagItemBaptism::TagItemBaptism() {
}

TagItemBaptism::~TagItemBaptism() {
}

bool TagItemBaptism::FilterItem(const reco::RecoItem* item) {
  if (item->identity().has_manual() && item->identity().manual()) {
    return false;
  }

  return ProduceWhiteDictFilter(item);
}
}
}
