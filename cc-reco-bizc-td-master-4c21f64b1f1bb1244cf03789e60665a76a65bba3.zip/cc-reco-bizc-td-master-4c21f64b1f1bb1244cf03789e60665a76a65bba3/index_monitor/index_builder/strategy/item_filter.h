#pragma once

#include <string>
#include <unordered_set>
#include <unordered_map>
#include <vector>

#include "base/common/base.h"
#include "base/file/file_util.h"
#include "base/container/dense_hash_map.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/index_monitor/index_builder/strategy/item_filter_strategy.h"
namespace reco {

class ItemFilter {
 public:
  ItemFilter(const base::dense_hash_map<std::string, int>* sourcesite_level_map);
  ~ItemFilter();
  bool FilterBadItem(const reco::RecoItem* item);
  void FillItemFilterInfo(const reco::RecoItem* item, ItemFilterInfo* item_info);
 private:
  void LoadAllmediaLevelMap(const base::FilePath& map_file);
  bool IsSourceWemedia(const reco::RecoItem* item);
  reco::MediaLevel GetItemMediaLevel(const reco::RecoItem* item);
  reco::SiteLevel GetItemSiteLevel(const reco::RecoItem* item);
  // int GetItemq(const reco::RecoItem* item);
  bool IsItemTrival(const reco::ContentAttr& content_attr);
  void PrintFilterDebug(const reco::RecoItem* item, const std::string& reason);
  // wemedia&media 质量等级
  base::dense_hash_map<std::string, reco::MediaLevel> allmedia_level_map_;
  // site 质量等级,外部传入
  const base::dense_hash_map<std::string, int>* sourcesite_level_map_;
  static const char* kAllmediaLevelFile;
  ItemFilterStrategy strategy_;
};
}
