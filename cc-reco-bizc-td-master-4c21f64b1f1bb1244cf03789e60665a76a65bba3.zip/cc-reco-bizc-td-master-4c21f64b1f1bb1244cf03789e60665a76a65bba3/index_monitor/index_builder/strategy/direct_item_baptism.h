//
// Created by allen.fw on 2017/11/1.
//

#pragma once

#include <memory>
#include <string>
#include "base/container/dense_hash_map.h"
#include "reco/bizc/index_monitor/index_builder/strategy/item_baptism_base.h"

namespace reco {
class RecoItem;
namespace index_builder {

class DirectItemBaptism : public ItemBaptismBase {
 public:
  DirectItemBaptism();
  virtual ~DirectItemBaptism();

 private:
  virtual bool FilterItem(const reco::RecoItem* item);
};
}
}
