//
// Created by allen.fw on 2017/11/1.
//

#include "reco/bizc/index_monitor/index_builder/strategy/direct_item_baptism.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"

namespace reco {
namespace index_builder {

DirectItemBaptism::DirectItemBaptism() {
}

DirectItemBaptism::~DirectItemBaptism() {
}

bool DirectItemBaptism::FilterItem(const reco::RecoItem* item) {
  if (item->identity().has_manual() && item->identity().manual()) {
    return false;
  }

  if (ProduceWhiteDictFilter(item)) {
    return true;
  }

  return FinanceStockFilter(item);
}
}
}
