#include "reco/bizc/index_monitor/index_builder/strategy/item_filter.h"
#include "base/file/file_path.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
DEFINE_string(data_dict_dir, "data/conf_data", "");

const char* ItemFilter::kAllmediaLevelFile  = "all_media_quality.txt";

ItemFilter::ItemFilter(const base::dense_hash_map<std::string, int>* sourcesite_level_map)
        : sourcesite_level_map_(sourcesite_level_map) {
  allmedia_level_map_.set_empty_key("");
  if (FLAGS_data_dict_dir.empty()) return;
  base::FilePath base_dir(FLAGS_data_dict_dir);
  LoadAllmediaLevelMap(base_dir);
}

ItemFilter::~ItemFilter() {
  sourcesite_level_map_ = NULL;
}

// 过滤最差的一批低质 item
bool ItemFilter::FilterBadItem(const reco::RecoItem* item) {
  ItemFilterInfo item_info;
  FillItemFilterInfo(item, &item_info);
  return strategy_.FilterBadItem(&item_info);
}

// 填充过滤需要的数据结构
void ItemFilter::FillItemFilterInfo(const reco::RecoItem* item, ItemFilterInfo* item_info) {
  // 视频不做过滤
  item_info->item_id = item->identity().item_id();
  item_info->item_type = item->identity().type();
  item_info->is_manual = item->identity().has_manual() && item->identity().manual();
  if (item->quality_attr().has_posterior_itemq()) {
    item_info->orgi_itemq = item->quality_attr().posterior_itemq();
  }
  item_info->is_source_wemedia = IsSourceWemedia(item);
  item_info->media_level = GetItemMediaLevel(item);
  item_info->site_level = GetItemSiteLevel(item);

  reco::ContentAttr content_attr = item->content_attr();
  item_info->is_trival = IsItemTrival(content_attr);
  item_info->erro_title = content_attr.erro_title();
  item_info->advertorial = content_attr.advertorial();
  item_info->short_content = content_attr.short_content();
  item_info->dedup_paragraph = content_attr.dedup_paragraph();
  item_info->dirty = content_attr.dirty();
  item_info->politics = content_attr.politics();
  item_info->bluffing_title = content_attr.bluffing_title();

  item_info->title = item->title();
  item_info->source = item->source();
  item_info->source_media = item->source_media();

  if (item->category_size() > 0) {
    item_info->category = item->category(0);
    if (item->category_size() > 1) {
      item_info->sub_category = item->category(1);
    }
  }

  reco::FeatureVector tag_fea_vec = item->tag();
  for (int i = 0; i < tag_fea_vec.feature_size(); ++i) {
    std::string tag = tag_fea_vec.feature(i).literal();
    item_info->tags.push_back(tag);
  }
};

void ItemFilter::LoadAllmediaLevelMap(const base::FilePath& base_dir) {
  allmedia_level_map_.clear();
  base::FilePath media_file = base_dir.Append(kAllmediaLevelFile);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(media_file, &lines)) {
    LOG(WARNING) << "Read all cate media level dict fail, "
                 << media_file.ToString();
    return;
  }

  int val;
  std::vector<std::string> flds;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    flds.clear();
    base::SplitString(lines[idx], "\t", &flds);
    if (flds.size() < 3u || !base::StringToInt(flds[2], &val)) {
      LOG(ERROR) << "parse field fail, " << lines[idx];
      continue;
    }
    // key = cate "\t" media
    const std::string& key = flds[0] + "\t" + flds[1];
    // val
    reco::MediaLevel level = reco::MediaLevel(val);
    // insert
    allmedia_level_map_.insert(std::make_pair(key, level));
  }

  LOG(INFO) << "succ to load all media_key level, total record: "
            << allmedia_level_map_.size();
}

bool ItemFilter::IsSourceWemedia(const reco::RecoItem* item) {
  bool is_source_wemedia = false;
  const std::string source = item->source();
  static const char* wemedia_source = "cp_wemedia_uc_";
  static const size_t wemedia_size = strlen(wemedia_source);
  if (source.size() >= wemedia_size) {
    size_t i = 0;
    for (; i < wemedia_size; ++i) {
      if (source[i] != wemedia_source[i]) {
        break;
      }
    }
    is_source_wemedia = (i == wemedia_size);
  }
  return is_source_wemedia;
}

bool ItemFilter::IsItemTrival(const reco::ContentAttr& content_attr) {
  bool is_trival = (content_attr.erro_title() == reco::ContentAttr::kSureNo
                 && content_attr.advertorial() == reco::ContentAttr::kSureNo
                 && content_attr.short_content() == reco::ContentAttr::kSureNo
                 && content_attr.dedup_paragraph() == reco::ContentAttr::kSureNo
                 && content_attr.dirty() == reco::ContentAttr::kSureNo
                 && content_attr.politics() == reco::ContentAttr::kSureNo
                 && content_attr.bluffing_title() == reco::ContentAttr::kSureNo);
  return is_trival;
}

reco::MediaLevel ItemFilter::GetItemMediaLevel(const reco::RecoItem* item) {
  const std::string used_media = (!item->orig_source_media().empty())
                                 ? item->orig_source_media() : item->source_media();
  std::string media_key;
  if (item->category_size() > 0) {
    media_key = item->category(0) + "\t" + used_media;
    auto result = allmedia_level_map_.find(media_key);
    if (result != allmedia_level_map_.end()) {
      return result->second;
    }  // find key
  }
  // not find key or no cate
  media_key = "\t" + used_media;
  auto result = allmedia_level_map_.find(media_key);
  if (result != allmedia_level_map_.end()) {
    return result->second;
  }  // find key
  return reco::kNormalMedia;
}

reco::SiteLevel ItemFilter::GetItemSiteLevel(const reco::RecoItem* item) {
  auto result = sourcesite_level_map_->find(item->source());
  if (result != sourcesite_level_map_->end()) {
    return reco::SiteLevel(result->second);
  }
  return reco::kMidQualitySite;
}

}  // namespace reco
