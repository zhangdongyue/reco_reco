//
// Created by allen.fw on 2017/11/1.
//

#include <vector>
#include "reco/bizc/index_monitor/index_builder/strategy/channel_item_baptism.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "reco/bizc/index_monitor/index_builder/dao/SeedEntityDao.h"
#include "reco/bizc/index_monitor/index_builder/strategy/item_filter.h"

namespace reco {
namespace index_builder {

ChannelItemBaptism::ChannelItemBaptism(const serving_base::mysql_util::DbConnManager::Option &db_option) {
  sourcesite_level_map_.set_empty_key("");
  GetSourceSiteLevelMap(db_option);
  item_filter_ = std::make_shared<reco::ItemFilter>(&sourcesite_level_map_);
}

ChannelItemBaptism::~ChannelItemBaptism() {
}

bool ChannelItemBaptism::FilterItem(const reco::RecoItem* item) {
  uint64 item_id = item->identity().item_id();
  if (item->identity().has_manual() && item->identity().manual()) {
    return false;
  }

  if (ProduceWhiteDictFilter(item)) {
    return true;
  }

  // 财经荐股类过滤
  if (FinanceStockFilter(item)) {
    LOG(INFO) << "filtered by finance stock recommend, item_id : " << item_id;
    return true;
  }

  const std::string item_id_str = base::Uint64ToString(item_id);
  if (item_filter_->FilterBadItem(item)) {
    LOG(INFO) << "filtered by bad item, item_id : " << item_id;
    InvalidItemStrategy(item_id_str, reco::common::kBadItemFilter);
    return true;
  }

  // 爬虫文章，要进行各种检查：种子 / item_type / 内嵌图集 等等
  if (item->has_parent_url() && !item->parent_url().empty()) {
    LOG(INFO) << "filtered by inner atlas, not to build into index. item_id : " << item_id;
    InvalidItemStrategy(item_id_str, reco::common::kInnerAtlasItemFilter);
    return true;
  }

  return false;
}

bool ChannelItemBaptism::UpdateItem(const ItemQueueEntity& entity, reco::RecoItem *item) {
  if (!UpdateExpireTimeBySeed(item)) {
    return false;
  }

  UpdateItemTypeByDB(entity, item);

  return true;
}

bool ChannelItemBaptism::UpdateExpireTimeBySeed(reco::RecoItem *item) {
  const std::string item_id_str = base::Uint64ToString(item->identity().item_id());
  auto& source_seed_map = GlobalIndexDataIns::instance().source_seed_map_;
  auto it = source_seed_map.find(item->source());
  if (it == source_seed_map.end()) {
    // 种子不存在，更新失败，不建入索引
    LOG(INFO) << "filtered by source not find in seed map, source : " << item->source()
              << " item_id : " << item->identity().item_id();
    InvalidItemStrategy(item_id_str, reco::common::kWhiteSourceSeedFilter);
    return false;
  }

  SeedEntity& seed = it->second;
  if (seed.get_publish_status() == 1) {
    item->set_expire_time("1970-01-01 00:00:00");
  }

  return true;
}

void ChannelItemBaptism::UpdateItemTypeByDB(const ItemQueueEntity& entity, reco::RecoItem* item) {
  if (entity.item_type_setter && entity.item_type != item->identity().type()) {
    LOG(INFO) << "reset item type, item : " << item->identity().item_id() << " , orig type: "
              << item->identity().type() << " , new type : " << entity.item_type;
    item->mutable_identity()->set_type(entity.item_type);
  }
}

void ChannelItemBaptism::GetSourceSiteLevelMap(
        const serving_base::mysql_util::DbConnManager::Option &db_option) {
  std::vector<SeedEntity> seed_list;
  SeedEntityDao seed_dao;
  seed_dao.Init(db_option);
  seed_dao.getAllSeedList(&seed_list);
  for (size_t i = 0; i < seed_list.size(); ++i) {
    SeedEntity& seed = seed_list.at(i);
    sourcesite_level_map_.insert(std::make_pair(seed.get_name(), seed.get_authority_score()));
  }
  LOG(INFO) << "source site_level size: " << sourcesite_level_map_.size();
}
}
}
