//
// Created by allen.fw on 2017/11/1.
//

#pragma once

#include <memory>
#include <string>
#include "base/container/dense_hash_map.h"
#include "reco/bizc/index_monitor/index_builder/strategy/item_baptism_base.h"
#include "reco/bizc/index_monitor/index_builder/handler/base_handler.h"

namespace reco {
class RecoItem;
class ItemFilter;
namespace index_builder {

class ChannelItemBaptism : public ItemBaptismBase {
 public:
  ChannelItemBaptism() {}
  explicit ChannelItemBaptism(const serving_base::mysql_util::DbConnManager::Option &db_option);
  virtual ~ChannelItemBaptism();

 private:
  virtual bool FilterItem(const reco::RecoItem* item);
  virtual bool UpdateItem(const ItemQueueEntity& entity, reco::RecoItem* item);

  bool UpdateExpireTimeBySeed(reco::RecoItem* item);
  void UpdateItemTypeByDB(const ItemQueueEntity& entity, reco::RecoItem* item);

  void GetSourceSiteLevelMap(const serving_base::mysql_util::DbConnManager::Option &db_option);

 private:
  base::dense_hash_map<std::string, int> sourcesite_level_map_;
  std::shared_ptr<reco::ItemFilter> item_filter_;
};
}
}
