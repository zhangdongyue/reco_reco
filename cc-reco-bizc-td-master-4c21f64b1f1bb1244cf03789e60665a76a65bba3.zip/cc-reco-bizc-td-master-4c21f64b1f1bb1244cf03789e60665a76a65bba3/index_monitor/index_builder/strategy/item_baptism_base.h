//
// Created by allen.fw on 2017/11/1.
//

#pragma once
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/proto/reco_doc_server.pb.h"

namespace reco {
class RecoItem;
namespace index_builder {

struct ItemQueueEntity;

class ItemBaptismBase {
 public:
  ItemBaptismBase();
  virtual ~ItemBaptismBase();

  bool ItemBaptism(const ItemQueueEntity& entity, reco::RecoItem* item) {
    std::string item_id_str = base::Uint64ToString(item->identity().item_id());
    if (!item->is_valid() || item->offline_filter_rule().is_filter()) {
      LOG(INFO) << "item filtered by is_valid or is_filter, item_id: " << item_id_str;
      InvalidItemStrategy(item_id_str, reco::common::kInvalidItemFilter);
      return false;
    }

    if (FilterItem(item)) {
      return false;
    }

    if (!UpdateItem(entity, item)) {
      return false;
    }

    if (!GetItemDocInfo(item->identity().item_id())) {
      LOG(INFO) << "item filtered by get item doc info fail, item_id: " << item_id_str;
      InvalidItemStrategy(item_id_str, reco::common::kGetDocFailFilter);
      return false;
    }

    return true;
  }

 private:
  bool GetItemDocInfo(uint64 item_id);
  // 弄成 const 和 * 主要是为了兼容 ItemFilter 和 FinanceStockFilter 的旧接口
  virtual bool FilterItem(const reco::RecoItem* item) { return false; }
  virtual bool UpdateItem(const ItemQueueEntity& entity, reco::RecoItem* item) { return true; }

 protected:
  bool ProduceWhiteDictFilter(const reco::RecoItem* item);
  bool FinanceStockFilter(const reco::RecoItem* item);
  net::rpc::RpcGroup* rpc_group_;
  reco::docserver::RecoDocService::Stub* doc_server_stub_;
};
}
}
