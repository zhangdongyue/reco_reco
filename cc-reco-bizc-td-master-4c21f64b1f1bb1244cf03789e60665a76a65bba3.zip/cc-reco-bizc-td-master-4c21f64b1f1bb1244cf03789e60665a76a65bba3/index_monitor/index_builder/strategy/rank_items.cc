//
// Created by allen.fw on 2017/10/20.
//

#include <algorithm>
#include <cmath>
#include <functional>
#include <utility>
#include "reco/bizc/index_monitor/index_builder/strategy/rank_items.h"
#include "reco/bizc/index_monitor/index_builder/common/global_index_data.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"
#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"
#include "base/common/closure.h"

namespace reco {
namespace index_builder {

DEFINE_int32(get_sim_thread_num, 16, "max jingpin item num");
DEFINE_int32(get_meta_thread_num, 8, "max jingpin item num");
DEFINE_string(hbase_sim_table, "tb_sim_item", "hbase.item_sim.table");
DEFINE_string(hbase_meta_table, "tb_item_statistics", "hbase.item_action.table");

RankItems::RankItems() : item_meta_hbase_service_(new ItemMetaHBaseService()),
                             item_sim_hbase_service_(new ItemSimHBaseService()) {
}

RankItems::~RankItems() {
  if (item_meta_hbase_service_) {
    delete item_meta_hbase_service_;
  }

  if (item_sim_hbase_service_ != NULL) {
    delete item_sim_hbase_service_;
  }
}

void RankItems::RankCategoryItems(const std::string& key,
                            std::vector<ItemChannelEntity>* items,
                            int max_limit) {
  if (items->empty()) return;
  TimeConsume time_consume("category_" + key + "_rank_items");

  // 获取 meta 信息
  std::vector<std::string> item_id_list;
  item_id_list.resize(items->size());
  for (size_t idx = 0; idx < items->size(); ++idx) {
    item_id_list[idx] = items->at(idx).get_item_id();
  }
  std::vector<reco::index_data::MetaData> meta_vec;
  meta_vec.resize(item_id_list.size());
  thread::ThreadPool meta_pool(FLAGS_get_meta_thread_num);
  for (int i = 0; i < FLAGS_get_meta_thread_num; ++i) {
    meta_pool.AddTask(NewCallback<RankItems, const std::vector<std::string>&,
            std::vector<reco::index_data::MetaData>*, int >
                              (this, &RankItems::GetMetaThread, item_id_list, &meta_vec, i));
  }
  meta_pool.JoinAll();

  // 排序
  base::Time item_time;
  base::Time now_time = base::Time::Now();
  std::vector<std::pair<float, size_t> > rank_vec;
  reco::index_data::MetaData data;
  for (size_t idx = 0; idx < items->size(); ++idx) {
    const ItemChannelEntity& item = items->at(idx);
    const reco::index_data::MetaData& data = meta_vec[idx];
    int64 show = data.has_show_cnt() ? data.show_cnt() : 0;
    int64 clk = data.has_click_cnt() ? data.click_cnt() : 0;
    int day_delta = 7;
    if (base::Time::FromStringInSeconds(item.get_publish_time().c_str(), &item_time)) {
      day_delta = (now_time - item_time).InDays();
    }
    float score = show > 0 ? (clk + 1.0) / (show + 1000) : 0;
    if (day_delta == 0) {
      score += 1;
    } else {
      if (day_delta < 0) {
        day_delta = 2;
      } else if (day_delta >= 15) {
        day_delta = 3;
      } else if (day_delta >= 7) {
        day_delta = 2;
      } else if (day_delta >= 3) {
        day_delta = 1;
      }
      score = score * std::pow(0.7, day_delta);
    }
    PrintItemDebug(key, &item, show, clk, day_delta, score);
    // no keyitem group
    rank_vec.push_back(std::make_pair(score, idx));
  }
  std::sort(rank_vec.begin(), rank_vec.end(), std::greater<std::pair<float, size_t> >());



  // 获取 sim info
  item_id_list.clear();
  for (size_t i = 0; i < rank_vec.size(); ++i) {
    if ((int)item_id_list.size() >= 3 * max_limit) break;
    size_t pos = rank_vec[i].second;
    const ItemChannelEntity& item = items->at(pos);
    const std::string& itemid = item.get_item_id();
    item_id_list.push_back(itemid);
  }
  std::vector<reco::index_data::SimData> sim_vec;
  if (!FLAGS_for_sim_server) {
    sim_vec.resize(item_id_list.size());
    thread::ThreadPool sim_pool(FLAGS_get_sim_thread_num);
    for (int i = 0; i < FLAGS_get_sim_thread_num; ++i) {
      sim_pool.AddTask(::NewCallback<RankItems, const std::vector<std::string>&,
              std::vector<reco::index_data::SimData>*, bool, int >
                               (this, &RankItems::GetSimThread, item_id_list, &sim_vec, true, i));
    }
    sim_pool.JoinAll();
  }

  LOG(INFO) << "sim pool end";

  // 填充待返回的 item
  // 1. 按 rank_vec 依次填充
  // 2. 去重
  base::dense_hash_set<std::string> dedup_items;
  dedup_items.set_empty_key("");
  std::vector<ItemChannelEntity> ret_items;
  std::unordered_set<std::string> group_id_set;
  for (size_t idx = 0; idx < rank_vec.size(); ++idx) {
    if ((int)ret_items.size() >= max_limit) break;
    float score = rank_vec[idx].first;
    if (score < 1e-4 && (int)ret_items.size() > max_limit / 2) break;
    size_t pos = rank_vec[idx].second;
    const ItemChannelEntity& item = items->at(pos);
    std::string groupid = item.get_outer_id();
    if (!groupid.empty() &&
        group_id_set.find(groupid) != group_id_set.end()) {
      continue;
    }
    const std::string& itemid = item.get_item_id();
    if (dedup_items.find(itemid) != dedup_items.end()) {
      LOG(INFO) << itemid << " filtered.";
      continue;
    }
    if (!IsNewItemStrategy(itemid, reco::common::kLeafCategory)) {
      LOG(INFO) << itemid << " filtered.";
      continue;
    }
    dedup_items.insert(itemid);
    if (!FLAGS_for_sim_server && idx < sim_vec.size()) {
      const reco::index_data::SimData& sim_data = sim_vec[idx];
      for (int j = 0; j < sim_data.whole_sim_ids_size(); ++j) {
        dedup_items.insert(base::Uint64ToString(sim_data.whole_sim_ids(j)));
      }
    }
    ret_items.push_back(item);
    if (!groupid.empty()) {
      group_id_set.insert(groupid);
    }
//      int show = meta_vec[pos].has_show_cnt() ?  meta_vec[pos].show_cnt() : 0;
//      int clk = meta_vec[pos].has_click_cnt() ?  meta_vec[pos].click_cnt() : 0;
    VLOG(1) << "key:" << key
            << ", item:"<< itemid << ", create_time:" << item.get_publish_time()
            << ", show:" << (meta_vec[pos].has_show_cnt() ?  meta_vec[pos].show_cnt() : 0)
            << ", clk:" << (meta_vec[pos].has_click_cnt() ?  meta_vec[pos].click_cnt() : 0)
            << ", rankscore:" << score;
  }

  // swap 到返回集
  items->swap(ret_items);
  GetInvalidItemStrategy(ret_items, *items, reco::common::kLeafRankItemFilter);
  LOG(INFO) << "RankCategoryItems end";
}

void RankItems::GetMetaThread(const std::vector<std::string>& items,
                                 std::vector<reco::index_data::MetaData>* meta_vec,
                                 int thread_id) {
  CHECK_EQ(items.size(), meta_vec->size());

  int process_num = 0;
  reco::index_data::MetaData base_data;
  base_data.set_item_id(0);
  for (int idx = thread_id; idx < (int)items.size(); idx+=FLAGS_get_meta_thread_num) {
    ++process_num;
    const std::string& itemid = items.at(idx);
    reco::index_data::MetaData& meta_data = meta_vec->at(idx);
    if (!item_meta_hbase_service_->getMetaData(FLAGS_hbase_meta_table, itemid, &meta_data)) {
      meta_data.CopyFrom(base_data);
    }
  }

  LOG(INFO) << "meta thread " << thread_id << " process " << process_num << " item.";
}

void RankItems::GetSimThread(const std::vector<std::string>& items,
                                std::vector<reco::index_data::SimData>* sim_vec,
                                bool get_whole_sim,
                                int thread_id) {
  CHECK_EQ(items.size(), sim_vec->size());

  int process_num = 0;
  reco::index_data::SimData base_data;
  base_data.set_item_id(0);
  for (int idx = thread_id; idx < (int)items.size(); idx+=FLAGS_get_sim_thread_num) {
    LOG_IF(INFO, process_num % 5000 == 0) << "thread " << thread_id << " process " << process_num << " sim.";
    ++process_num;
    const std::string& itemid = items.at(idx);
    reco::index_data::SimData& sim_data = sim_vec->at(idx);
    if (!item_sim_hbase_service_->getSimData(FLAGS_hbase_sim_table, itemid, &sim_data, get_whole_sim)) {
      sim_data.CopyFrom(base_data);
    }
  }

  LOG(INFO) << "sim thread " << thread_id << " process " << process_num << " item.";
}
}
}
