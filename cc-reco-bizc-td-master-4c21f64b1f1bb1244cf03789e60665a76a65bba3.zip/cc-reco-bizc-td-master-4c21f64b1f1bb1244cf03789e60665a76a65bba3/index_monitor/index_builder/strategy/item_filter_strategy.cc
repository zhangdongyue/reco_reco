#include "reco/bizc/index_monitor/index_builder/strategy/item_filter.h"
#include "base/file/file_path.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
DEFINE_bool(dizhi_filter_wemedia, true, "是否开启自媒体过滤");
DEFINE_int32(dizhi_low_new_itemq_thresh, 20, "dizhi low_new_itemq_thresh");
DEFINE_bool(dizhi_filter_compete_source, true, "是否开启竞品过滤");
DEFINE_bool(dizhi_filter_compete_media, true, "是否开启竞品媒体过滤");
DEFINE_bool(dizhi_tag_and_category_filter, true, "是否开启 dizhi tag and category filter");
DEFINE_bool(open_debug_filter_bad_item, false, "是否开启 debug filter bad item");

DEFINE_string(dizhi_dict_dir, "data/conf_data", "");
const char* ItemFilterStrategy::kDizhiTagFile = "dizhi_tag.txt";

const std::unordered_set<std::string> ItemFilterStrategy::kCompeteSourceMediaSet
        = {"一点资讯", "腾讯网", "微信自媒体"};

ItemFilterStrategy::ItemFilterStrategy() {
  if (FLAGS_dizhi_dict_dir.empty()) return;
  base::FilePath base_dir(FLAGS_dizhi_dict_dir);
  LoadDizhiTag(base_dir);
}

ItemFilterStrategy::~ItemFilterStrategy() {
}

// 过滤最差的一批低质 item
bool ItemFilterStrategy::FilterBadItem(const ItemFilterInfo* item) {
  // 视频不做过滤
  if (item->item_type == reco::kPureVideo) return false;

  // 运营豁免
  if (item->is_manual) {
    return false;
  }
  int32 orgi_itemq = item->orgi_itemq;
  bool is_source_wemedia = item->is_source_wemedia;
  int media_level = item->media_level;
  int site_level = item->site_level;

  if (FLAGS_dizhi_filter_wemedia && is_source_wemedia) {
    if (media_level == reco::MediaLevel::kBadMedia
        && site_level == reco::SiteLevel::kBadQualitySite) {
      PrintFilterDebug(item, "shuangzuidi && zimeiti");
      return true;
    } else if (media_level <= reco::MediaLevel::kLowMedia
               && site_level <= reco::SiteLevel::kMidQualitySite
               && orgi_itemq > -1
               && orgi_itemq <= FLAGS_dizhi_low_new_itemq_thresh) {
      PrintFilterDebug(item, "shuangzhongdi && zimeiti && low itemq");
      return true;
    }
  }

  if (item->is_trival) return false;

  int low_quality_score = 0;
  if (item->short_content == reco::ContentAttr::kSureYes
      || item->dedup_paragraph == reco::ContentAttr::kSureYes
      || item->advertorial == reco::ContentAttr::kSureYes) {
    low_quality_score = 3;
  } else if (item->erro_title == reco::ContentAttr::kSureYes
             || item->politics == reco::ContentAttr::kSureYes
             || item->dirty == reco::ContentAttr::kSureYes
             || item->bluffing_title == reco::ContentAttr::kSureYes
             || item->short_content == reco::ContentAttr::kSuspect
             || item->dedup_paragraph == reco::ContentAttr::kSuspect
             || item->advertorial == reco::ContentAttr::kSuspect) {
    low_quality_score = 2;
  } else if (item->erro_title == reco::ContentAttr::kSuspect
             || item->politics == reco::ContentAttr::kSuspect
             || item->dirty == reco::ContentAttr::kSuspect
             || item->bluffing_title == reco::ContentAttr::kSuspect) {
    low_quality_score = 1;
  }

  if (low_quality_score == 0) return false;

  // low quality 最高的文章直接过滤
  if (low_quality_score >= 3) {
    PrintFilterDebug(item, "low quality >= 3.");
    return true;
  }

  // 根据低质分数及媒体权威性的过滤
  if (low_quality_score >= 2
      && media_level <= reco::MediaLevel::kNormalMedia
      && (site_level <= reco::SiteLevel::kMidQualitySite)) {
    PrintFilterDebug(item, "shuangzhongdi && queding");
    return true;
  }
  if (low_quality_score >= 1
      && media_level == reco::MediaLevel::kBadMedia
      && (site_level == reco::SiteLevel::kBadQualitySite)) {
    PrintFilterDebug(item, "shuangzuidi && suspect");
    return true;
  }

  // 竞品低质做严格打压
  std::string source = item->source;
  if (FLAGS_dizhi_filter_compete_source
      && low_quality_score >= 1
      && (source.find("天天快报-文本-竞品") != std::string::npos
          || source.find("今日头条-文本-竞品") != std::string::npos)) {
    PrintFilterDebug(item, "compete_source low item filter.");
    return true;
  }
  if (FLAGS_dizhi_filter_compete_media
      && kCompeteSourceMediaSet.find(source) != kCompeteSourceMediaSet.end()
      && low_quality_score >= 1) {
    PrintFilterDebug(item, "compete_media low item filter.");
    return true;
  }

  bool hit_dizhi = false;
  std::string category = item->category;
  std::string sub_category = item->sub_category;

  if (FLAGS_dizhi_tag_and_category_filter
      && dizhi_category_map_.size() > 0) {
    if (dizhi_category_map_.find(category) != dizhi_category_map_.end()) {
      hit_dizhi = true;
    } else if (dizhi_category_map_.find(sub_category) != dizhi_category_map_.end()) {
      hit_dizhi = true;
    }
  }

  if (FLAGS_dizhi_tag_and_category_filter
      && !hit_dizhi) {
    const std::vector<std::string>& tag_vec = item->tags;
    if (dizhi_tag_map_.size() > 0
        && tag_vec.size() > 0) {
      for (int i = 0; i < (int)tag_vec.size(); ++i) {
        std::string tag = tag_vec[i];
        if (dizhi_tag_map_.find(tag) == dizhi_tag_map_.end()) {
          continue;
        } else {
          hit_dizhi = true;
          break;
        }
      }
    }
  }
  // int itemq = GetItemq(item);
  if (hit_dizhi) {
    if (low_quality_score >= 1
      //  || itemq <= 1
        || (orgi_itemq <= FLAGS_dizhi_low_new_itemq_thresh
            && orgi_itemq > -1
            && is_source_wemedia)
        || (media_level < reco::MediaLevel::kNormalMedia
            && site_level < reco::SiteLevel::kMidQualitySite)) {
      PrintFilterDebug(item, "dizhi_tag#");
      return true;
    }
  }
  return false;
};

void ItemFilterStrategy::LoadDizhiTag(const base::FilePath& base_dir) {
  dizhi_tag_map_.clear();
  dizhi_category_map_.clear();

  base::FilePath map_file = base_dir.Append(kDizhiTagFile);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(map_file, &lines)) {
    LOG(WARNING) << "Read dizhi tag dict fail, "
                 << map_file.ToString();
    return;
  }

  std::vector<std::string> flds;
  std::vector<std::string> key_value_vec;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    flds.clear();
    base::SplitString(lines[idx], "\t", &flds);
    if (flds.size() < 1u) {
      LOG(ERROR) << "parse field fail: " << lines[idx];
      continue;
    }
    key_value_vec.clear();
    base::SplitString(flds[0], "#", &key_value_vec);
    if (key_value_vec.size() < 2u) continue;
    if (key_value_vec[0] == "TAG") {
      dizhi_tag_map_.insert(std::make_pair(key_value_vec[1], 1));
    } else if (key_value_vec[0] == "CATE") {
      dizhi_category_map_.insert(std::make_pair(key_value_vec[1], 1));
    }
  }

  LOG(INFO) << "succ to load dizhi tag dict, total record: "
            << dizhi_tag_map_.size();
}

void ItemFilterStrategy::PrintFilterDebug(const ItemFilterInfo* item, const std::string& reason) {
  if (!FLAGS_open_debug_filter_bad_item) return;
  LOG(INFO) << "dizhidebug:\t" << item->item_id << "\t"
            << "reason\t" << reason << "\t"
            << item->title << "\t"
            << item->source << "\t"
            << item->source_media << "\t"
            << "\torgi_itemq\t" << item->orgi_itemq
            << "\tcategory\t" << item->category
            << "\tmedia_level\t" << item->media_level
            << "\tsite_level\t" << item->site_level
            << "\tis_trival\t" << item->is_trival
            << "\terro_title\t" << item->erro_title
            << "\tadvertorial\t" << item->advertorial
            << "\tshort_content\t" << item->short_content
            << "\tdedup_paragraph\t" << item->dedup_paragraph
            << "\tdirty\t" << item->dirty
            << "\tpolitics\t" << item->politics
            << "\tbluffing_title\t" << item->bluffing_title;
}

}  // namespace reco
