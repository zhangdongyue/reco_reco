//
// Created by allen.fw on 2017/11/1.
//

#include <string>
#include "reco/bizc/index_monitor/index_builder/strategy/item_baptism_base.h"
#include "reco/bizc/proto/item.pb.h"
#include "base/time/time.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/index_monitor/index_builder/common/time_consume.h"

namespace reco {
namespace index_builder {

DEFINE_int32(filter_protect_days, 1, "filter protect days");
DEFINE_string(doc_server_ips, "100.85.69.71", "doc server ips, splitted by ,");
DEFINE_int32(doc_server_port, 20013, "doc server port");
DEFINE_int32(doc_server_time_out, 10000, "doc time out");
DEFINE_bool(filter_no_doc_info_item, false, "filter no doc info item switch");

ItemBaptismBase::ItemBaptismBase() : rpc_group_(NULL), doc_server_stub_(NULL) {
  if (FLAGS_filter_no_doc_info_item) {
    rpc_group_ = SetupConnection(FLAGS_doc_server_ips, FLAGS_doc_server_port, FLAGS_doc_server_time_out, -1);
    doc_server_stub_ = new reco::docserver::RecoDocService::Stub(rpc_group_);
  }
}

ItemBaptismBase::~ItemBaptismBase() {
  if (FLAGS_filter_no_doc_info_item) {
    if (doc_server_stub_ != NULL) {
      delete doc_server_stub_;
    }
    if (rpc_group_ != NULL) {
      delete rpc_group_;
    }
  }
}

bool ItemBaptismBase::GetItemDocInfo(uint64 item_id) {
  if (!FLAGS_filter_no_doc_info_item) {
    return true;
  }

  TimeConsume timeConsume("GetItemDocInfo", 1000);
  reco::doc::ItemDocRequest request;
  request.add_item_id(item_id);
  net::rpc::RpcClientController controller;
  controller.SetTimeout(FLAGS_doc_server_time_out);
  reco::doc::ItemDocResponse response;

  doc_server_stub_->GetItemDocInfo(&controller, &request, &response, NULL);
  controller.Wait();
  if (controller.status() != net::rpc::RpcController::kOk) {
    LOG(ERROR) << "get item doc info failed: " << controller.error_text() << ", item id: " << item_id;
    return false;
  }

  return response.success();
}

bool ItemBaptismBase::ProduceWhiteDictFilter(const reco::RecoItem* item) {
  auto& producer_whitelist_set = GlobalIndexDataIns::instance().producer_whitelist_set_;
  // 非运营文章, producer 非空并且不在白名单里, 直接过滤
  if (item->identity().has_producer() && !item->identity().producer().empty() &&
      producer_whitelist_set.find(item->identity().producer()) == producer_whitelist_set.end()) {
    LOG(INFO) << "filtered by producer whitelist, item_id : " << item->identity().item_id()
              << " producer : " << item->identity().producer();
    InvalidItemStrategy(base::Uint64ToString(item->identity().item_id()), reco::common::kProduceWhiteDictFilter);
    return true;
  }

  return false;
}

bool ItemBaptismBase::FinanceStockFilter(const reco::RecoItem* item) {
  if (item->category_size() == 0) {
    return false;
  }
  if (item->category(0) != "财经") {
    return false;
  }
  // 24 小时之内的不过滤
  base::Time protect_time = base::Time::Now() - base::TimeDelta::FromDays(FLAGS_filter_protect_days);
  base::Time item_time;
  base::Time::FromStringInSeconds(item->publish_time().c_str(), &item_time);
  if (item_time >= protect_time) {
    return false;
  }
  // 精品保护
  if (item->has_quality_attr()
      && item->quality_attr().has_manual_jingpin_level()
      && item->quality_attr().manual_jingpin_level() > 0) {
    return false;
  }

  // item->category 财经
  reco::FeatureVector feature_vector = item->semantic_tag();
  for (int feature_index = 0; feature_index < feature_vector.feature_size(); ++feature_index) {
    const reco::Feature& feature = feature_vector.feature(feature_index);
    if (feature.literal().find("炒股指南") != std::string::npos) {
      LOG(INFO) << "filtered by finance stock recommend, item_id : " << item->identity().item_id();
      InvalidItemStrategy(base::Uint64ToString(item->identity().item_id()), reco::common::kFinanceStockFilter);
      return true;
    }
  }
  return false;
}
}
}
