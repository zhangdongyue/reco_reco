#pragma once

#include <string>
#include <vector>

#include "reco/bizc/proto/common.pb.h"
#include "base/strings/string_split.h"
#include "base/hash_function/term.h"

namespace reco {
namespace common {
/**
 * reco::Category 的包装类，使得 Category 对象能放到容器中
 */
class WrappedCategory {
 public:
  explicit WrappedCategory(const reco::Category& cate) : category_(cate) {
    for (int i = 0; i < cate.parents_size(); ++i) {
      vector_.push_back(cate.parents(i));
    }
    vector_.push_back(cate.category());
    string_ = base::JoinStrings(vector_, "\t");
  }

  WrappedCategory(const std::vector<std::string>& vec, int level) : vector_(vec) {
    category_.Clear();
    if (level >= (int)vec.size() || level < 0) {
      return;
    }

    category_.set_level(level);
    category_.set_category(vec[level]);
    for (int i = 0; i < level; ++i) {
      category_.add_parents(vec[i]);
    }
    string_ = base::JoinStrings(vec, "\t");
  }

  explicit WrappedCategory(const std::string& str) : string_(str) {
    base::SplitString(str, "\t", &vector_);
    category_.Clear();
    int level = vector_.size() - 1;
    category_.set_level(level);
    category_.set_category(vector_[level]);
    for (int i = 0; i < level; ++i) {
      category_.add_parents(vector_[i]);
    }
  }

  ~WrappedCategory() {}

  const reco::Category& ToCategory() const {
    return category_;
  }

  const std::string& ToString() const {
    return string_;
  }

  // 默认是用 TAB 分割多个类别层级。这个接口可以指定 splitter
  std::string ToString(const std::string& splitter) const {
    return base::JoinStrings(vector_, splitter);
  }

  const std::vector<std::string>& ToVector() const {
    return vector_;
  }

  size_t Hash() const {
    return base::CalcTermSign(string_.c_str(), string_.size());
  }

  bool operator == (const WrappedCategory& wrap_rhs) const {
    const reco::Category& lhs = category_;
    const reco::Category& rhs = wrap_rhs.ToCategory();
    if (lhs.level() != rhs.level()) {
      return false;
    }
    if (lhs.category() != rhs.category()) {
      return false;
    }
    if (lhs.parents_size() != rhs.parents_size()) {
      return false;
    }
    for (int i = 0; i < lhs.parents_size(); ++i) {
      if (lhs.parents(i) != rhs.parents(i)) {
        return false;
      }
    }
    return true;
  }

  bool operator < (const WrappedCategory& rhs) const {
    return this->Hash() < rhs.Hash();
  }

  int level() {
    return category_.level();
  }

 private:
  reco::Category category_;
  std::vector<std::string> vector_;
  std::string string_;
};

struct CategoryHash {
  size_t operator()(const WrappedCategory &category) const {
    return category.Hash();
  }
};
}  // namespace common
}  // namespace reco
