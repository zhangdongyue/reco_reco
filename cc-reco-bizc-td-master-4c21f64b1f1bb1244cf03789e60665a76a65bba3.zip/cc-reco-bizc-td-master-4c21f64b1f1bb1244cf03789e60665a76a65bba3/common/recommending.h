#pragma once

namespace reco {

//enum RecommendType {
//  kNewsType = 0,
//  kNumbers,
//  kAllType = 255,
//};

enum OperateType {
  kAdd = 0,
  kUpdate = 1,
};

enum ResultType {
  kSuccess = 0,
  kFailed = -1
};

enum Province {
  kTaiwan = 0,
  kBeijing = 1,
  kHebei = 2,
  kShanxiShanxi = 3,
  kNeimeng = 4,
  kLiaoning = 5,
  kJilin = 6,
  kHeilongjiang = 7,
  kShanghai = 8,
  kJiangsu = 9,
  kZhejiang = 10,
  kAnhui = 11,
  kFujian = 12,
  kJiangxi = 13,
  kShandong = 14,
  kHenan = 15,
  kHubei = 16,
  kHunan = 17,
  kGuangdong = 18,
  kGuangxi = 19,
  kHainan = 20,
  kChongqing = 21,
  kSichuan = 22,
  kGuizhou = 23,
  kYunnan = 24,
  kXizang = 25,
  kShanxi = 26,
  kGansu = 27,
  kNingxia = 28,
  kXinjiang = 29,
  kXianggang = 30,
  kAomen = 31,
  kQinghai = 32,
  kTianjin = 33
};

} // namespace recommending
