#include "reco/bizc/common/index_util_ha3.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "nlp/common/nlp_util.h"

namespace reco {
namespace common {

std::string GetFeaturePayloadTerm(const std::string& literal, FeatureType type) {
  switch (type) {
    case kKeyword:
      return "K_" + literal;
    case kTopic:
      return "P_" + literal;
    case kWordvec:
      return "W_" + literal;
    case kTag:
      return "T_" + literal;
    case kPlsaTopic:
      return "PT_" + literal;
    case kTitleLdaTopic:
      return "LT_" + literal;
    case kSemanticTag:
      return "ST_" + literal;
  }
  CHECK(false);
}

std::string GetTagPayloadTerm(const std::string& tag) {
  std::string tterm;
  if (base::StartsWith(tag, "label:", true)) {
    tterm = reco::common::GetFeaturePayloadTerm(tag, reco::common::kTag);
  } else {
    tterm = reco::common::GetFeaturePayloadTerm("label:" + tag, reco::common::kTag);
  }

  return tterm;
}

std::string GetPayloadString(const std::string& prefix, const std::string& val) {
  return prefix + "_" + val;
}

std::string GetPayloadInt(const std::string& prefix, int val) {
  return prefix + "_" + base::IntToString(val);
}

std::string GetPayloadUint64(const std::string& prefix, uint64 val) {
  return prefix + "_" + base::Uint64ToString(val);
}

std::string GetItemTypePayloadTerm(int32 type) {
  return "I_" + base::IntToString(type);
}

std::string GetCategoryPayloadTerm(const std::string& literal, int level) {
  return "C_" + base::IntToString(level) + "_" + literal;
}

std::string GetSourcePayloadTerm(const std::string& literal) {
  return "S_" + literal;
}

std::string GetAppTokenPayloadTerm(const std::string& literal) {
  return "A_" + literal;
}

std::string GetChannelPayloadTerm(int64 channel_id) {
  return "CN_" + base::Int64ToString(channel_id);
}

std::string GetPicturePayloadTerm(int64 image_hash) {
  return "IMG_" + base::Int64ToString(image_hash);
}

std::string GetParagraphPayloadTerm(int64 paragraph_hash) {
  return "PARAGRAPH_" + base::Int64ToString(paragraph_hash);
}

std::string GetRegionIDPayloadTerm(const std::string &region_id) {
  return "REGIONID_" + region_id;
}

std::string GetWeMediaPayloadTerm() {
  return "WEMEDIA";
}

std::string GetYouzhiItemPayloadTerm() {
  return "YOUZHI";
}

std::string GetJingpinItemPayloadTerm() {
  return "JINGPIN";
}

std::string GetShowTagPayloadTerm(const std::string& tag) {
  return "SHOWTAG_" + tag;
}

std::string GetEventTagPayloadTerm(const std::string& tag) {
    return "EVENTTAG_" + tag;
}

std::string GetContentAttrPayloadTerm(uint64 packed_content_bits) {
  return "CONTATTR_" + base::Int64ToString(packed_content_bits);
}

std::string GetResourcePayloadTerm(const std::string& literal) {
  return "RES_" + literal;
}

std::string GetCategoryCandidatesPayloadTerm(const std::string& literal, int level) {
  return base::StringPrintf("MC_%d_%s", level, literal.c_str());
}

std::string GetSpiderQueryPayloadTerm(const std::string &query) {
  return "QRY_" + nlp::util::NormalizeLine(query);
}

std::string GetNovelIdPayloadTerm(const std::string& novel_id) {
    return "NOVELID_" + novel_id;
}

std::string GetTitleLdaTopicPayloadTerm(const std::string& topic) {
    return "TITLELDA_" + topic;
}

}  // namespace common
}  // namespace reco
