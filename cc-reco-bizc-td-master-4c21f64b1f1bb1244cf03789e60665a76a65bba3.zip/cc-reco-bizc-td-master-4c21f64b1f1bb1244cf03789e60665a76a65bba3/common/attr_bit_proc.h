#pragma once

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/common/feature_type.h"

namespace reco {
namespace common {

// 每种属性的位移
enum {
  // kErrorTitleAttrMask = 0x3,
  // kAdAttrMask = 0xC,
  // kShortContentAttrMask = 0x30,
  // kDedupParagraphAttrMask = 0xC0,
  // kDirtyAttrMask = 0x300,
  // kPoliticsAttrMask = 0xC00,
  // kBluffingTitleAttrMask = 0x3000,
  kErrorTitleAttrShift = 0,
  kAdAttrShift = 2,
  kShortContentAttrShift = 4,
  kDedupParagraphAttrShift = 6,
  kDirtyAttrShift = 8,
  kPoliticsAttrShift = 10,
  kBluffingTitleAttrShift = 12,
  kNegativeAttrShift = 14,
  kVideoDirtyAttrShift = 16,
  kVideoDirtyStatusAttrShift = 18,
  kMaxAttrShift = 13,
};

// 把 ContentAttr protobuf 打包压缩到一个 uint64 中去
inline void PackContentAttr(const reco::ContentAttr& content_attr, uint64 *attr_bits) {
  *attr_bits = 0;
  uint64 bits = 0;
  bits |= (content_attr.erro_title() << kErrorTitleAttrShift);
  bits |= (content_attr.advertorial() << kAdAttrShift);
  bits |= (content_attr.short_content() << kShortContentAttrShift);
  bits |= (content_attr.dedup_paragraph() << kDedupParagraphAttrShift);
  bits |= (content_attr.dirty() << kDirtyAttrShift);
  bits |= (content_attr.politics() << kPoliticsAttrShift);
  bits |= (content_attr.bluffing_title() << kBluffingTitleAttrShift);
  bits |= (content_attr.negative() << kNegativeAttrShift);
  if (content_attr.has_video_dirty()) {
    bits |= (content_attr.video_dirty() << kVideoDirtyAttrShift);
  } else {
    bits |= (0 << kVideoDirtyAttrShift);
  }
  if (content_attr.has_video_dirty_status()) {
    bits |= (content_attr.video_dirty_status() << kVideoDirtyStatusAttrShift);
  } else {
    bits |= (0 << kVideoDirtyStatusAttrShift);
  }
  *attr_bits = bits;
}

// 从 uint64 反解析出 ContentAttr， 并返回 all_clear
// NOTE 调用之前先判断 attr_bits 是否为 0， 如果为 0 不需要调用此函数，因为返回的是平凡结果
inline void UnPackContentAttr(uint64 attr_bits, reco::ContentAttr* content_attr) {
  content_attr->Clear();
  if (attr_bits == 0) return;
  uint64 val = 0x3;
  content_attr->set_erro_title(
      static_cast<reco::ContentAttr::ContentAttrLevel>((attr_bits >> kErrorTitleAttrShift) & val));
  content_attr->set_advertorial(
      static_cast<reco::ContentAttr::ContentAttrLevel>((attr_bits >> kAdAttrShift) & val));
  content_attr->set_short_content(
      static_cast<reco::ContentAttr::ContentAttrLevel>((attr_bits >> kShortContentAttrShift) & val));
  content_attr->set_dedup_paragraph(
      static_cast<reco::ContentAttr::ContentAttrLevel>((attr_bits >> kDedupParagraphAttrShift) & val));
  content_attr->set_dirty(
      static_cast<reco::ContentAttr::ContentAttrLevel>((attr_bits >> kDirtyAttrShift) & val));
  content_attr->set_politics(
      static_cast<reco::ContentAttr::ContentAttrLevel>((attr_bits >> kPoliticsAttrShift) & val));
  content_attr->set_bluffing_title(
      static_cast<reco::ContentAttr::ContentAttrLevel>((attr_bits >> kBluffingTitleAttrShift) & val));
  content_attr->set_negative(
      static_cast<reco::ContentAttr::ContentAttrLevel>((attr_bits >> kNegativeAttrShift) & val));
  content_attr->set_video_dirty(
      static_cast<reco::ContentAttr::ContentAttrLevel>((attr_bits >> kVideoDirtyAttrShift) & val));
  content_attr->set_video_dirty_status(
      static_cast<int32>((attr_bits >> kVideoDirtyStatusAttrShift) & val));
}

// 只针对 content_attr 中 non trival 的属性， 生成一个 mask
inline uint64 ContentAttrMask(const reco::ContentAttr& attr) {
  uint64 bits = 0;
  uint64 val = 0x3;
  if (attr.has_erro_title() && attr.erro_title() > reco::ContentAttr::kSureNo) {
    bits |= (val << kErrorTitleAttrShift);
  }
  if (attr.has_advertorial() && attr.advertorial() > reco::ContentAttr::kSureNo) {
    bits |= (val << kAdAttrShift);
  }
  if (attr.has_short_content() && attr.short_content() > reco::ContentAttr::kSureNo) {
    bits |= (val << kShortContentAttrShift);
  }
  if (attr.has_dedup_paragraph() && attr.dedup_paragraph() > reco::ContentAttr::kSureNo) {
    bits |= (val << kDedupParagraphAttrShift);
  }
  if (attr.has_dirty() && attr.dirty() > reco::ContentAttr::kSureNo) {
    bits |= (val << kDirtyAttrShift);
  }
  if (attr.has_politics() && attr.politics() > reco::ContentAttr::kSureNo) {
    bits |= (val << kPoliticsAttrShift);
  }
  if (attr.has_bluffing_title() && attr.bluffing_title() > reco::ContentAttr::kSureNo) {
    bits |= (val << kBluffingTitleAttrShift);
  }
  if (attr.has_negative() && attr.negative() > reco::ContentAttr::kSureNo) {
    bits |= (val << kNegativeAttrShift);
  }
  if (attr.has_video_dirty() && attr.video_dirty() > reco::ContentAttr::kSureNo) {
    bits |= (val << kVideoDirtyAttrShift);
  }
  if (attr.has_video_dirty_status() && attr.video_dirty_status() > reco::ContentAttr::kSureNo) {
    bits |= (val << kVideoDirtyStatusAttrShift);
  }
  return bits;
}

}
}
