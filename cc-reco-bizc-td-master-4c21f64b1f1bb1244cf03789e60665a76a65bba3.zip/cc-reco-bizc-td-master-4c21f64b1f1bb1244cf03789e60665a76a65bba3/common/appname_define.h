#pragma once

#include <string>
#include <vector>

#include "base/common/base.h"
#include "base/strings/string_util.h"

namespace reco {
namespace common {
// NOTE(everyone) 0x01 是索引保留标志位, 请不要占用
enum DocMaskFlags {
  // 该文档设置地域白名单过滤, 不继承上级设置, 如果属性为空表示不过滤
  kDocMaskRegionWhiteList = 0x02,
  // 该文档有时间段过滤白名单
  kDocMaskTimeWhiteList = 0x04,
  // 该文档过滤 uc 头条 渠道
  kDocMaskAppToutiao = 0x08,
  // 该文档过滤 华为 渠道
  kDocMaskAppHuawei = 0x10,
  // 该文档过滤 三星 渠道
  kDocMaskAppSamsung = 0x20,
  // 该文档过滤 魅族 渠道
  kDocMaskAppMeizu = 0x40,
  // 该文档过滤 土豆 渠道
  kDocMaskAppTuDouIflow = 0x80,
  // 该文档过滤 优酷 渠道
  kDocMaskAppYoukuIflow = 0x100,
  // 该文档被 filter_server 过滤
  kDocFilterServer = 0x200,
};

// NOTE: 这块代码目前没有整理比较零散，针对渠道的一些过滤规则
// 因此在修改了 DocMaskFlags 和 AppNames 以后，
// find -name *.cc |xargs grep AppNames 看哪里使用到了，进行相应修改
enum AppNames {
  kUcIflow = 0,
  kUcToutiao = 1,
  kHuawei = 2,
  kSamsung = 3,
  kMeizu = 4,
  kTuDouIflow = 5,
  kTuDouPCIflow = 6,
  kYouKuIflow = 7,
  kYouKuPCIflow = 8,
  kYoukuOpenIflow = 9,
  kYoukuIkuIflow = 10,
  kTuDouPreviewIflow = 11,
  kYouCaiIflow = 12,
  kGeneralApp= 100,
};

const char kWeMediaSourcePrefix[] = "cp_wemedia_uc_";

const char kZZDProducer[] = "uc";
const char kZZDOpProducer[] = "zzd_op";
const char kUCBProducer[] = "uc_br_op";
const char kTuDouProducer[] = "tudou";

const char kDftAppUser[] = "uc";
const char kZZDAppUser[] = "uc";
const char kNewZZDAppUser[] = "sm-zzd-app";
const char kUCBIflowUser[] = "uc-iflow";
const char kUCAppUser[] = "ucnews-iflow";
const char kWebAppUser[] = "webapp";
const char kUCVideoAppUser[] = "ucnewsvideo-iflow";
const char kTuDouAppUser[] = "newtudou-iflow";
const char kYouCaiAppUser[] = "youcai-iflow";
const char kTuDouPCAppUser[] = "newtudoupc-iflow";
const char kYouKuAppUser[] = "youkunews-iflow";
const char kYunOSAppUser[] = "yunos-iflow";
const char kUCLiteAppUser[] = "uclite-iflow";
const char kSsrdAnAppUser[] = "ssrd_an-iflow";
const char kUCMiniAppUser[] = "ucminibro-iflow";
const char kYunOsBrwAppUser[] = "yunosbrw-iflow";
const char kOppoIflowAppUser[] = "oppo-iflow";
const char kYunOsLiuLanQiAppUser[] = "yunosliulanqi-iflow";

inline reco::common::AppNames GetAppName(const std::string& app) {
  if (base::LowerCaseEquals(app, "uc-iflow")) {
    return reco::common::kUcIflow;
  } else if (base::LowerCaseEquals(app, "ucnews-iflow")) {
    return reco::common::kUcToutiao;
  } else if (base::LowerCaseEquals(app, "huawei-iflow")) {
    return reco::common::kHuawei;
  } else if (base::LowerCaseEquals(app, "samsung-iflow")) {
    return reco::common::kSamsung;
  } else if (base::LowerCaseEquals(app, "meizunews-iflow")) {
    return reco::common::kMeizu;
  } else if (base::LowerCaseEquals(app, "newtudou-iflow")) {
    return reco::common::kTuDouIflow;
  } else if (base::LowerCaseEquals(app, "newtudoupc-iflow")) {
    return reco::common::kTuDouPCIflow;
  } else if (base::LowerCaseEquals(app, "youcai-iflow")) {
    return reco::common::kYouCaiIflow;
  } else if (base::LowerCaseEquals(app, "youkunews-iflow")) {
    return reco::common::kYouKuIflow;
  } else if (base::LowerCaseEquals(app, "youkunewspc-iflow")) {
    return reco::common::kYouKuPCIflow;
  } else if (base::LowerCaseEquals(app, "youku-open-aliyun-iflow") ||
             base::LowerCaseEquals(app, "youku-open-huawei-iflow") ||
             base::LowerCaseEquals(app, "youku-open-meizu-iflow ")) {
    return reco::common::kYoukuOpenIflow;
  } else if (base::LowerCaseEquals(app, "youkuiku-iflow")) {
    return reco::common::kYoukuIkuIflow;
  }
  return reco::common::kGeneralApp;
}
}  // namespace common
}  // namespace reco
