#pragma once
namespace reco {
namespace common {

enum FeatureType {
  kKeyword = 0,
  kTopic,
  kWordvec,
  kTag,
  kPlsaTopic,
  kSemanticTag,
  kTitleLdaTopic,
};

}
}
