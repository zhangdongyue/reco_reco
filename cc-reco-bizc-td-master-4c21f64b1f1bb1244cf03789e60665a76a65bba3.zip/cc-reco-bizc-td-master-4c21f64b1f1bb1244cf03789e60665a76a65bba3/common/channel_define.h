#pragma once

#include <string>
#include <vector>
#include <unordered_set>
#include "base/common/basic_types.h"
namespace reco {
namespace common {
const int64 kHotChannelId = 51830095;
const int64 kPictureChannelId = 1964289243;
const int64 kGirlChannelId = 1404457531633;
const int64 kAnecdoteChannelId = 715945925;
const int64 kRecoChannelId = 100;
const int64 kSpecialChannelId = 1;
const int64 kHumorWordChannelId = 1670553277;
const int64 kHumorPicChannelId = 10013;
const int64 kHumorWordTouTiaoChannelId = 10070;
const int64 kBoudoirChannelId = 1099189934;
const int64 kLocalChannelId = 200;
const int64 kSubscriptionChannelId = 300;
const int64 kTagMainpageChannelId = 310;
const int64 kSportChannelId = 923258246;   // 体育
const int64 kFinanceChannelId = 26325229;   // 财经
const int64 kScienceChannelId = 1525483516; // 科技
const int64 kEstateChannelId = 586710362;  // 房产
const int64 kInternetChannelId = 242677432;
const int64 kSocialChannelId = 1192652582;
const int64 kOlympicChannelId = 23154031;
const int64 kVideoChannelId = 10016;
const int64 kLeftChannelId = 100000;
const int64 kAutoChannelId = 323644874;
const int64 kOperChannelId = 1211676;
const int64 kJingpinChannelId = 500;
const int64 kEntertainmentChannelId = 179223212;
const int64 kGanhuoChannelId = 1911322354;
const int64 kMilitaryChannelId = 1105405272;
const int64 kInternationalChannelId = 1001932710;
const int64 kEuropeanCupChannelId = 27254244;
const int64 kBusinessChannelId = 696724;
const int64 kThirdVideoChannelId = 20016; // 外渠视频推荐频道

const int64 kWangBaoQiangChannelId = 1404457531636;
const int64 kIos10PluginCustomerContentChannelId = 1404457531637;
const int64 kFitnessChannelId = 674534;  // 健身
const int64 kHistoryChannelId = 701104723;  // 历史
const int64 kNBAChannelId = 90002;  // NBA
const int64 kStockChannelId = 90001;  // 股票
const int64 kCBAChannelId = 66498;  // CBA
const int64 kDigitalChannelId = 835729;  // 数码
const int64 kHealthChannelId = 472933935;  // 健康
const int64 kHouseHoldChannelId = 90003;  // 家居
const int64 kMovieChannelId = 1404457531635;  // 电影
const int64 kAnimationChannelId = 10012;  // 动漫
const int64 kConstellationChannelId = 10008;  // 星座
const int64 kTravelChannelId = 1972619079;  // 旅游
const int64 kFoodChannelId = 10000;  // 美食
const int64 kBeautyChannelId = 90005;  // 美容瘦身
const int64 kFationChannelId = 1213442674;  // 时尚
const int64 kGameChannelId = 169476544;  // 游戏
const int64 kWenWanChannelId = 10005;  // 文玩
const int64 kEducationChannelId = 681723207;  // 教育
const int64 kStudyAbroadChannelId = 90004;  // 留学
const int64 kParentingChannelId = 408250330;  // 育儿
const int64 kChineseFootballChannelId = 684625112;  // 中国足球
const int64 kI18nFootballChannelId = 701538712;  // 国际足球
const int64 kDiaryChannelId = 27882911;  // 日记频道
const int64 kShoppingId = 91888;  // 购物频道
const int64 kTagWemediaChannelId = 315;  // 订阅标签和自媒体频道
const int64 kJingpinTopVideoChannelId = 11111;  // 竞品首页视频
const int64 kHotGirlChannelId = 1024; // 视频的美女频道
const int64 kWanghongChannelId = 10240;   // 网红
const int64 kYouCaiUgcChannelId = 10311;   // 有才小视频
const int64 kTudouSubjectChannelId = 20170718;  // 土豆主题订阅
const int64 kUgcVideoChannelId = 10290;  //  ugc 小视频频道
const int64 kUgcJingxuanVideoChannelId = 10300;  //  ugc 精选视频频道
const int64 kSexyBeautyChannelId = 666999L;  // 美女频道

const char kGirlCategory[] = "美女写真";
const char kBoudoirCategory[] = "两性情感";
const char kHotNewsCategory[] = "热点";
const char kSportCategory[] = "体育";
const char kFinanceCategory[] = "财经";
const char kScienceCategory[] = "科技";
const char kLocalCategory[]   = "地方";
const char kHumorCategory[]   = "幽默";
const char kVideoCategory[] = "视频";
const char kSocietyCategory[] = "社会";

const char kPhoneSndCategory[] = "手机";
const char kInternetSndCategory[] = "互联网";

// 是否为视频频道
inline bool IsVideoChannel(int64 channel_id) {
  return (channel_id == kVideoChannelId || channel_id == kThirdVideoChannelId);
}

// 是否为音频频道
inline bool IsAudioChannel(int64 channel_id) {
  static const std::unordered_set<int64> kAudioChannels
      = {10170, 10171, 10147, 10172, 10169, 10145, 10146, 10143, 10144};
  return (kAudioChannels.find(channel_id) != kAudioChannels.end());
}

}  // namespace common
}  // namespace reco

