#pragma once

#include <string>
#include <vector>
#include <sstream>
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/sim_info/sim_info.h"

namespace reco {
namespace common {
void GetUCBSpecialContentIds(const reco::RecoItem& reco_item, std::vector<std::string>* id_list);
// 去掉 tag 前缀，对审核过的视频 tag 特殊处理
bool ExtractRealTag(const RecoItem& item, const std::string& raw_tag, std::string* real_tag);
void GetItemMedia(const RecoItem& item, std::string* media);
bool CompareTimeStr(const std::string &lvalue, const std::string &rvalue);

// 同步两个 message （可以定义不同）里同名同类型的字段
bool CopyProtoFields(const google::protobuf::Message& src, google::protobuf::Message* dest);

// 比较两个 message （定义要相同） 的 diff，
// 如果无 diff 返回 true, 否则返回 false, 并将具体的 diff 信息填充在 diff_report 里
// fields_to_compare 如果不为 null，则只比较这些字段
bool CompareMessage(const google::protobuf::Message& msg1, const google::protobuf::Message& msg2,
                    std::string* diff_report, std::vector<const char*>* fields_to_compare);

// 类似于 DiffMessage， 但是由于 RecoItem 存在 raw item 这个历史遗留问题，
// 所以在比较字段的时候还会考察 raw item 里的字段
bool CompareRecoItem(const reco::RecoItem& item1, const reco::RecoItem& item2,
                     std::string* diff_report);

template<typename T>
void generate_string_diff(const std::string& parent, const std::string& field_name,
                          const T& t1, const T& t2, std::vector<std::string>* diffs) {
  if (t1 != t2) {
    std::stringstream ss;
    std::string name = field_name;
    if (!parent.empty()) {
      name = parent + "." + field_name;
    }

    ss << "field [" << name << "] -> (" << t1 << ") .vs. (" << t2 << ")";
    diffs->push_back(ss.str());
  }
}

void generate_string_diff1(const std::string& parent, const std::string& field_name,
                          const std::string& t1, const std::string& t2, std::vector<std::string>* diffs);

// protobuf repeated fields 与 std::vector 的互相转化
template<typename Elem>
void RepeatedToVector(const google::protobuf::RepeatedPtrField<Elem>& src,
                      std::vector<Elem>* dest) {
  if (src.size() == 0) return;
  dest->resize(src.size());
  for (int i = 0; i < src.size(); ++i) {
    dest->at(i) = src.Get(i);
  }
}

template<typename Elem>
void VectorToRepeated(const std::vector<Elem>& src, google::protobuf::RepeatedPtrField<Elem>* dest) {
  if (src.size() == 0) return;
  dest->Reserve(src.size());
  for (size_t i = 0; i < src.size(); ++i) {
    *(dest->Add()) = src[i];
  }
}
}  // namespace common
}  // namespace reco
