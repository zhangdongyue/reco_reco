#pragma once

#include <string>
#include <vector>

#include "reco/bizc/common/feature_type.h"
#include "ads_index/api/cdoc_convertor.pb.h"
#include "ads_index/api/public.h"
#include "reco/bizc/proto/convert_info.pb.h"
#include "base/common/base.h"
#include "base/common/logging.h"
#include "reco/bizc/common/attr_bit_proc.h"

namespace reco {
namespace common {

std::string GetPayloadString(const std::string& prefix, const std::string& val);
std::string GetPayloadInt(const std::string& prefix, int val);
std::string GetPayloadUint64(const std::string& prefix, uint64 val);

// 以下 api 将 RecoItem 中的特征和重要字段，转换成特殊 term
std::string GetFeaturePayloadTerm(const std::string& literal, FeatureType type);
std::string GetItemTypePayloadTerm(int32 type);
std::string GetCategoryPayloadTerm(const std::string& literal, int level);
std::string GetSourcePayloadTerm(const std::string& literal);
std::string GetAppTokenPayloadTerm(const std::string& literal);
std::string GetChannelPayloadTerm(int64 channel_id);
std::string GetPublishTimePayloadTerm(const std::string& publish_time);
std::string GetPicturePayloadTerm(int64 image_hash);
std::string GetParagraphPayloadTerm(int64 image_hash);
std::string GetRegionIDPayloadTerm(const std::string &region_id);
// 是否是自媒体文章，用单独的 term 来标记
std::string GetWeMediaPayloadTerm();
// 是否是自媒体文章，用单独的 term 来标记
std::string GetYouzhiItemPayloadTerm();
std::string GetJingpinItemPayloadTerm();
// show tag
std::string GetShowTagPayloadTerm(const std::string& tag);
// event tag
std::string GetEventTagPayloadTerm(const std::string& tag);

// packed_content_bits 是调用 PackContentAttr 得到的对 ContentAttr 的 bits 表示
std::string GetContentAttrPayloadTerm(uint64 packed_content_bits);

std::string GetResourcePayloadTerm(const std::string &resource);

// category candidates speicial term
std::string GetCategoryCandidatesPayloadTerm(const std::string& literal, int level);

// query 直接触发
std::string GetSpiderQueryPayloadTerm(const std::string &query);

// 小说 id
std::string GetNovelIdPayloadTerm(const std::string& novel_id);

// title lda topic 
std::string GetTitleLdaTopicPayloadTerm(const std::string& topic);

void PackFeatureVector(const FeatureVector& feavec, FeatureType type,
                       adsindexing::ConvertInfo* convert_info);


std::string doubleConverToString(double d);
void PackFeatureVectorHa3(const FeatureVector& feavec, FeatureType type,
                       reco::convertor::ConvertInfo* convert_info);

bool UnPackFeatureVector(const adsindexing::Index* index, int64 doc_local_id, FeatureType type,
                         reco::FeatureVector* feavec);

}  // namespace common
}  // namespace reco

