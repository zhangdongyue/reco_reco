#include "reco/bizc/common/index_util.h"

#include <sstream>
#include <set>
#include <unordered_map>

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/common/attr_key_define.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "nlp/common/term_container.h"
#include "nlp/common/nlp_util.h"

namespace reco {
namespace common {

std::string GetFeaturePayloadTerm(const std::string& literal, FeatureType type) {
  switch (type) {
    case kKeyword:
      return "K_" + literal;
    case kTopic:
      return "P_" + literal;
    case kWordvec:
      return "W_" + literal;
    case kTag:
      return "T_" + literal;
    case kPlsaTopic:
      return "PT_" + literal;
    case kTitleLdaTopic:
      return "LT_" + literal;
    case kSemanticTag:
      return "ST_" + literal;
  }
  CHECK(false);
}


std::string GetPayloadString(const std::string& prefix, const std::string& val) {
  return prefix + "_" + val;
}

std::string GetPayloadInt(const std::string& prefix, int val) {
  return prefix + "_" + base::IntToString(val);
}

std::string GetPayloadUint64(const std::string& prefix, uint64 val) {
  return prefix + "_" + base::Uint64ToString(val);
}

std::string GetItemTypePayloadTerm(int32 type) {
  return "I_" + base::IntToString(type);
}

std::string GetCategoryPayloadTerm(const std::string& literal, int level) {
  return "C_" + base::IntToString(level) + "_" + literal;
}

std::string GetSourcePayloadTerm(const std::string& literal) {
  return "S_" + literal;
}

std::string GetAppTokenPayloadTerm(const std::string& literal) {
  return "A_" + literal;
}

std::string GetChannelPayloadTerm(int64 channel_id) {
  return "CN_" + base::Int64ToString(channel_id);
}

std::string GetPicturePayloadTerm(int64 image_hash) {
  return "IMG_" + base::Int64ToString(image_hash);
}

std::string GetParagraphPayloadTerm(int64 paragraph_hash) {
  return "PARAGRAPH_" + base::Int64ToString(paragraph_hash);
}

std::string GetRegionIDPayloadTerm(const std::string &region_id) {
  return "REGIONID_" + region_id;
}

std::string GetWeMediaPayloadTerm() {
  return "WEMEDIA";
}

std::string GetYouzhiItemPayloadTerm() {
  return "YOUZHI";
}

std::string GetJingpinItemPayloadTerm() {
  return "JINGPIN";
}

std::string GetShowTagPayloadTerm(const std::string& tag) {
  return "SHOWTAG_" + tag;
}

std::string GetEventTagPayloadTerm(const std::string& tag) {
    return "EVENTTAG_" + tag;
}

std::string GetContentAttrPayloadTerm(uint64 packed_content_bits) {
  return "CONTATTR_" + base::Int64ToString(packed_content_bits);
}

std::string GetResourcePayloadTerm(const std::string& literal) {
  return "RES_" + literal;
}

std::string GetCategoryCandidatesPayloadTerm(const std::string& literal, int level) {
  return base::StringPrintf("MC_%d_%s", level, literal.c_str());
}

std::string GetSpiderQueryPayloadTerm(const std::string &query) {
  return "QRY_" + nlp::util::NormalizeLine(query);
}

std::string GetNovelIdPayloadTerm(const std::string& novel_id) {
    return "NOVELID_" + novel_id;
}

std::string GetTitleLdaTopicPayloadTerm(const std::string& topic) {
    return "TITLELDA_" + topic;
}

void PackFeatureVector(const FeatureVector& feavec, FeatureType type,
                       adsindexing::ConvertInfo* convert_info) {
  std::vector<std::string> keys;
  keys.reserve(feavec.feature_size());
  for (int i = 0; i < feavec.feature_size(); ++i) {
    // 特征的每一个元素作为一个 attr
    auto attr = convert_info->add_float_attr();
    attr->set_key(feavec.feature(i).literal());
    attr->set_value(feavec.feature(i).weight());
    // 特征签名 Join 后单独存储成一个 attr
    keys.push_back(feavec.feature(i).literal());
  }


  auto list_attr = convert_info->add_string_attr();
  auto norm_attr = convert_info->add_float_attr();
  switch (type) {
    case kKeyword:
      list_attr->set_key(reco::common::attr_key::kKeywordList);
      norm_attr->set_key(reco::common::attr_key::kKeywordNorm);
      break;
    case kTopic:
      list_attr->set_key(reco::common::attr_key::kTopicList);
      norm_attr->set_key(reco::common::attr_key::kTopicNorm);
      break;
    case kWordvec:
      list_attr->set_key(reco::common::attr_key::kWordvecList);
      norm_attr->set_key(reco::common::attr_key::kWordvecNorm);
      break;
    case kTag:
      list_attr->set_key(reco::common::attr_key::kTagList);
      norm_attr->set_key(reco::common::attr_key::kTagNorm);
      break;
    case kPlsaTopic:
      list_attr->set_key(reco::common::attr_key::kPlsaTopicList);
      norm_attr->set_key(reco::common::attr_key::kPlsaTopicNorm);
      break;
    case kTitleLdaTopic:
      list_attr->set_key(reco::common::attr_key::kTitleLdaTopicList);
      norm_attr->set_key(reco::common::attr_key::kTitleLdaTopicNorm);
      break;
    case kSemanticTag:
      list_attr->set_key(reco::common::attr_key::kSemanticTagList);
      norm_attr->set_key(reco::common::attr_key::kSemanticTagNorm);
      break;
    default:
      CHECK(false);
  }
  list_attr->set_value(base::JoinStrings(keys, "\t"));
  norm_attr->set_value(feavec.norm());
}

void PackFeatureVectorHa3(const FeatureVector& feavec, FeatureType type,
                       reco::convertor::ConvertInfo* convert_info) {
  std::vector<std::string> keys;
  std::vector<std::string> vals;
  keys.reserve(feavec.feature_size());
  vals.reserve(feavec.feature_size());
  for (int i = 0; i < feavec.feature_size(); ++i) {
    // 特征签名 Join 后单独存储成一个 attr
    keys.push_back(feavec.feature(i).literal());
    vals.push_back(base::DoubleToString(feavec.feature(i).weight()));
  }

  auto key_list_attr = convert_info->add_string_attr();
  auto val_list_attr = convert_info->add_string_attr();
  auto norm_attr = convert_info->add_float_attr();
  switch (type) {
    case kKeyword:
      key_list_attr->set_key(reco::common::attr_key::kKeywordList);
      val_list_attr->set_key(reco::common::attr_key::kKeywordFeatureList);
      norm_attr->set_key(reco::common::attr_key::kKeywordNorm);
      break;
    case kTopic:
      key_list_attr->set_key(reco::common::attr_key::kTopicList);
      val_list_attr->set_key(reco::common::attr_key::kTopicFeatureList);
      norm_attr->set_key(reco::common::attr_key::kTopicNorm);
      break;
    case kWordvec:
      key_list_attr->set_key(reco::common::attr_key::kWordvecList);
      val_list_attr->set_key(reco::common::attr_key::kWordvecFeatureList);
      norm_attr->set_key(reco::common::attr_key::kWordvecNorm);
      break;
    case kTag:
      key_list_attr->set_key(reco::common::attr_key::kTagList);
      val_list_attr->set_key(reco::common::attr_key::kTagFeatureList);
      norm_attr->set_key(reco::common::attr_key::kTagNorm);
      break;
    case kPlsaTopic:
      key_list_attr->set_key(reco::common::attr_key::kPlsaTopicList);
      val_list_attr->set_key(reco::common::attr_key::kPlsaTopicFeatureList);
      norm_attr->set_key(reco::common::attr_key::kPlsaTopicNorm);
      break;
    case kTitleLdaTopic:
      key_list_attr->set_key(reco::common::attr_key::kTitleLdaTopicList);
      val_list_attr->set_key(reco::common::attr_key::kTitleLdaTopicFeatureList);
      norm_attr->set_key(reco::common::attr_key::kTitleLdaTopicNorm);
      break;
    case kSemanticTag:
      key_list_attr->set_key(reco::common::attr_key::kSemanticTagList);
      val_list_attr->set_key(reco::common::attr_key::kSemanticTagFeatureList);
      norm_attr->set_key(reco::common::attr_key::kSemanticTagNorm);
      break;
    default:
      LOG(ERROR) << "feature type: " << type << " 's key not exists";
  }
  key_list_attr->set_value(base::JoinStrings(keys, "\t"));
  val_list_attr->set_value(base::JoinStrings(vals, "\t"));
  norm_attr->set_value(feavec.norm());
}

bool UnPackFeatureVector(const adsindexing::Index* index, int64 doc_local_id, FeatureType type,
                         reco::FeatureVector* feavec) {
  adsindexing::CustomerAttrValue norm_value;
  adsindexing::CustomerAttrValue list_value;
  std::string norm_key;
  std::string list_key;
  switch (type) {
    case kKeyword:
      list_key = reco::common::attr_key::kKeywordList;
      norm_key = reco::common::attr_key::kKeywordNorm;
      break;
    case kTopic:
      list_key = reco::common::attr_key::kTopicList;
      norm_key = reco::common::attr_key::kTopicNorm;
      break;
    case kWordvec:
      list_key = reco::common::attr_key::kWordvecList;
      norm_key = reco::common::attr_key::kWordvecNorm;
      break;
    case kTag:
      list_key = reco::common::attr_key::kTagList;
      norm_key = reco::common::attr_key::kTagNorm;
      break;
    case kPlsaTopic:
      list_key = reco::common::attr_key::kPlsaTopicList;
      norm_key = reco::common::attr_key::kPlsaTopicNorm;
      break;
    case kTitleLdaTopic:
      list_key = reco::common::attr_key::kTitleLdaTopicList;
      norm_key = reco::common::attr_key::kTitleLdaTopicNorm;
      break;
    default:
      CHECK(false);
  }

  if (!index->GetDocCustomerAttr(norm_key, doc_local_id, &norm_value) ||
      !index->GetDocCustomerAttr(list_key, doc_local_id, &list_value)) {
    LOG(ERROR) << "feature type: " << type << " 's key not exists";
    return false;
  }

  float norm;
  CHECK(norm_value.GetFloatValue(&norm));
  feavec->set_norm(norm);

  std::string keys;
  CHECK(list_value.GetStringValue(&keys));
  feavec->clear_feature();
  std::vector<std::string> signs;
  base::SplitString(keys, "\t", &signs);
  for (int i = 0; i < (int)signs.size(); ++i) {
    reco::Feature* fea = feavec->add_feature();
    fea->set_literal(signs[i]);
    adsindexing::CustomerAttrValue weight_value;
    CHECK(index->GetDocCustomerAttr(fea->literal(), doc_local_id, &weight_value));
    float weight;
    CHECK(weight_value.GetFloatValue(&weight));
    fea->set_weight(weight);
  }
  return true;
}

}  // namespace common
}  // namespace reco
