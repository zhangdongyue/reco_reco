#include <string.h>
#include <string>

#include "base/common/logging.h"
#include "base/testing/gtest.h"

#include "reco/bizc/common/wrapped_category.h"
#include "base/common/basic_types.h"
#include "base/common/scoped_ptr.h"
#include "base/hash_function/term.h"
#include "base/strings/string_number_conversions.h"

TEST(WrappedCategory, TestL1) {
  reco::common::WrappedCategory c1("l1");
  reco::common::WrappedCategory c2(c1.ToCategory());
  reco::common::WrappedCategory c3(c1.ToVector(), 0);
  reco::common::WrappedCategory c4(c1.ToString());

  ASSERT_EQ(c1.Hash(), c2.Hash());
  ASSERT_EQ(c1.Hash(), c3.Hash());
  ASSERT_EQ(c1.Hash(), c4.Hash());
}

TEST(WrappedCategory, TestL2) {
  reco::common::WrappedCategory c1("l1\tl2");
  reco::common::WrappedCategory c2(c1.ToCategory());
  reco::common::WrappedCategory c3(c1.ToVector(), 1);
  reco::common::WrappedCategory c4(c1.ToString());

  ASSERT_EQ(c1.Hash(), c2.Hash());
  ASSERT_EQ(c1.Hash(), c3.Hash());
  ASSERT_EQ(c1.Hash(), c4.Hash());
}

TEST(WrappedCategory, TestL3) {
  reco::common::WrappedCategory c1("l1\tl2\tl3");
  reco::common::WrappedCategory c2(c1.ToCategory());
  reco::common::WrappedCategory c3(c1.ToVector(), 2);
  reco::common::WrappedCategory c4(c1.ToString());

  ASSERT_EQ(c1.Hash(), c2.Hash());
  ASSERT_EQ(c1.Hash(), c3.Hash());
  ASSERT_EQ(c1.Hash(), c4.Hash());
}

TEST(WrappedCategory, TestVectorLevel) {
  reco::common::WrappedCategory c("l1\tl2\tl3");
  reco::common::WrappedCategory c1(c.ToVector(), 0);
  reco::common::WrappedCategory c2(c.ToVector(), 1);
  reco::common::WrappedCategory c3(c.ToVector(), 2);

  ASSERT_STREQ(c1.ToCategory().category().c_str(), "l1");
  ASSERT_EQ(c1.ToCategory().level(), 0);

  ASSERT_STREQ(c2.ToCategory().category().c_str(), "l2");
  ASSERT_EQ(c2.ToCategory().level(), 1);
  ASSERT_STREQ(c2.ToCategory().parents(0).c_str(), "l1");

  ASSERT_STREQ(c3.ToCategory().category().c_str(), "l3");
  ASSERT_EQ(c3.ToCategory().level(), 2);
  ASSERT_STREQ(c3.ToCategory().parents(0).c_str(), "l1");
  ASSERT_STREQ(c3.ToCategory().parents(1).c_str(), "l2");
}
