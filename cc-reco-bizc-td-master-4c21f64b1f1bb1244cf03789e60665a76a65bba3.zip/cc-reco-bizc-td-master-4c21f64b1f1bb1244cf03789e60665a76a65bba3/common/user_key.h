#pragma once

#include <vector>
#include <set>
#include "reco/bizc/proto/reco_user_server.pb.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/logging.h"

DECLARE_bool(use_inner_account_user_profile);

DECLARE_bool(use_new_ali_profile_id);
DECLARE_bool(use_new_query_profile_id);
DECLARE_bool(use_new_ucb_profile_id);

namespace reco{
namespace common {
using std::vector;
using std::string;

typedef std::pair<std::string, ::google::protobuf::RepeatedField< int > > UserKeyFields;

class UserKey {
public:
  static int GetInnerUserKeys(const reco::UserIdentity& user,
                              const ::google::protobuf::RepeatedField< int > & field_types,
                              vector<UserKeyFields>* user_keys) {
    int field_num = 0;
    // < ID 类型`ID, 数据类型>, 内部画像 key
    if (user_keys == NULL) {
      LOG(WARNING) << "user_keys null";
      return 0;
    }
    user_keys->clear();

    // 账户标识
    if (FLAGS_use_inner_account_user_profile) {
      // iCloud 账户标识
      if (user.has_tuicid() && !user.tuicid().empty()) {
        std::set<reco::user::UserFieldType> field_type_filter = {reco::user::kIcloudAccountProfile};
        field_num += AddKeyFields(GenUserKey(user.app_token(), "uic", user.tuicid()),
                                  field_types, field_type_filter, user_keys);
      }
      // 第三方账户标识
      if (user.has_acpf_type() && !user.acpf_type().empty()
          && user.has_tacid() && !user.tacid().empty()) {
        std::set<reco::user::UserFieldType> field_type_filter = {reco::user::kThirdAccountProfile};
        field_num += AddKeyFields(GenUserKey(user.app_token(), user.acpf_type(), user.tacid()),
                                  field_types, field_type_filter, user_keys);
      }
    }

    // 设备标识
    std::set<reco::user::UserFieldType> device_field_type_filter = {reco::user::kProfile,
                                                                   reco::user::kUserGroup,
                                                                   reco::user::kVideoProfile,
                                                                   reco::user::kLongTermProfile};
    field_num += AddKeyFields(GenUserKey(user.app_token(), "uid",  base::Uint64ToString(user.user_id())),
                              field_types, device_field_type_filter, user_keys);
    return field_num;
  }

  static int GetOuterUserKeys(const reco::UserIdentity & user,
                              const ::google::protobuf::RepeatedField< int > & field_types,
                              vector<UserKeyFields>* user_keys) {
    int field_num = 0;
    if (user_keys == NULL) {
      LOG(WARNING) << "user_keys null";
      return 0;
    }
    user_keys->clear();

    // < ID 类型`ID, 数据类型>, 外部画像 key ，全为设备标识
    // utdid
    if (user.has_utdid() && !user.utdid().empty()) {
      std::set<reco::user::UserFieldType> field_type_filter = {reco::user::kAliProfile};
      if (!FLAGS_use_new_ali_profile_id) {
        field_num += AddKeyFields(GenUserKey("ali", "utd", user.utdid()),
                                  field_types, field_type_filter, user_keys);
      }

      if (!FLAGS_use_new_ucb_profile_id) {
        field_type_filter.clear();
        field_type_filter.insert(reco::user::kSmProfile);
        field_num += AddKeyFields(GenUserKey("ucb", "utd", user.utdid()),
                                  field_types, field_type_filter, user_keys);
      }

      // uc-iflow 与 ucnews-iflow 通过 utdid 互查
      field_type_filter.clear();
      field_type_filter.insert(reco::user::kXssProfile);
      if (user.app_token() == "uc-iflow") {
        field_num += AddKeyFields(GenUserKey("ucnews-iflow", "utd", user.utdid()),
                                  field_types, field_type_filter, user_keys);
      } else if (user.app_token() == "ucnews-iflow") {
        field_num += AddKeyFields(GenUserKey("uc-iflow", "utd", user.utdid()),
                                  field_types, field_type_filter, user_keys);
      }
    }

    // sn
    if (user.has_sn() && !user.sn().empty()) {
      std::set<reco::user::UserFieldType> field_type_filter = {reco::user::kQueryProfile};
      if (!FLAGS_use_new_query_profile_id) {
        field_num += AddKeyFields(GenUserKey("query", "sn", user.sn()),
                                  field_types, field_type_filter, user_keys);
      }
    }

    // imei
    if (user.has_imei() && !user.imei().empty()) {
      std::set<reco::user::UserFieldType> field_type_filter = {reco::user::kRegionProfile};
      field_num += AddKeyFields(GenUserKey("amap", "imfa", user.imei()),
                                field_types, field_type_filter, user_keys);

      if (FLAGS_use_new_ali_profile_id) {
        field_type_filter.clear();
        field_type_filter.insert(reco::user::kAliProfile);
        field_num += AddKeyFields(GenUserKey("ali", "imfa", user.imei()),
                                  field_types, field_type_filter, user_keys);
      }

      if (FLAGS_use_new_query_profile_id) {
        field_type_filter.clear();
        field_type_filter.insert(reco::user::kQueryProfile);
        field_num += AddKeyFields(GenUserKey("query", "imfa", user.imei()),
                                  field_types, field_type_filter, user_keys);
      }

      if (FLAGS_use_new_ucb_profile_id) {
        field_type_filter.clear();
        field_type_filter.insert(reco::user::kSmProfile);
        field_num += AddKeyFields(GenUserKey("ucb", "imfa", user.imei()),
                                  field_types, field_type_filter, user_keys);
      }

      field_type_filter.clear();
      field_type_filter.insert(reco::user::kTudouProfile);
      field_num += AddKeyFields(GenUserKey("td", "imfa", user.imei()),
                                field_types, field_type_filter, user_keys);

      field_type_filter.clear();
      field_type_filter.insert(reco::user::kYtLongVideoProfile);
      field_num += AddKeyFields(GenUserKey("ytlv", "imfa", user.imei()),
                                field_types, field_type_filter, user_keys);

      field_type_filter.clear();
      field_type_filter.insert(reco::user::kImfaProfile);
      field_num += AddKeyFields(GenUserKey(user.app_token(), "imfa", user.imei()),
                                field_types, field_type_filter, user_keys);
    }

    // uid
    std::set<reco::user::UserFieldType> field_type_filter = {reco::user::kAppProfile};
    field_num += AddKeyFields(GenUserKey("pp", "uid", base::Uint64ToString(user.user_id())),
                              field_types, field_type_filter, user_keys);

    /*
    field_type_filter.clear();
    field_type_filter.insert(reco::user::kDmpProfile);
    field_num += AddKeyFields(GenUserKey("dmp", "uid", base::Uint64ToString(user.user_id())),
                              field_types, field_type_filter, user_keys);
    */

    field_type_filter.clear();
    field_type_filter.insert(reco::user::kYtRtLongVideoProfile);
    field_num += AddKeyFields(GenUserKey("ytlvh", "uid", base::Uint64ToString(user.user_id())),
                              field_types, field_type_filter, user_keys);

    field_type_filter.clear();
    field_type_filter.insert(reco::user::kYtRtShortVideoProfile);
    field_num += AddKeyFields(GenUserKey("ytsvh", "uid", base::Uint64ToString(user.user_id())),
                              field_types, field_type_filter, user_keys);

    field_type_filter.clear();
    field_type_filter.insert(reco::user::kYtShortVideoProfile);
    field_num += AddKeyFields(GenUserKey("ytsv", "uid", base::Uint64ToString(user.user_id())),
                              field_types, field_type_filter, user_keys);

    field_type_filter.clear();
    field_type_filter.insert(reco::user::kUgcProfile);
    field_num += AddKeyFields(GenUserKey("tdugc", "uid", base::Uint64ToString(user.user_id())),
                              field_types, field_type_filter, user_keys);
    return field_num;
  }

  static bool IsInnerField(int64 field_type) {
    static std::unordered_set<int64> inner_field_set = {
      reco::user::kProfile,
      reco::user::kUserGroup,
      reco::user::kIcloudAccountProfile,
      reco::user::kThirdAccountProfile,
      reco::user::kVideoProfile,
      reco::user::kLongTermProfile,
    };
    if (inner_field_set.count(field_type) > 0) {
      return true;
    }
    return false;
  }

private:
  explicit UserKey() {}
  ~UserKey() {}

  static int AddKeyFields(const std::string & user_key,
                          const ::google::protobuf::RepeatedField< int > & field_types,
                          const std::set<reco::user::UserFieldType> & field_type_filter,
                          std::vector<UserKeyFields>* user_keys) {
    int field_num = 0;
    if (user_keys == NULL) {
      LOG(WARNING) << "user_keys null";
      return 0;
    }
    ::google::protobuf::RepeatedField< int > field_types_needed;
    for (auto i = 0; i < field_types.size(); ++i) {
      if (field_type_filter.count(static_cast<reco::user::UserFieldType>(field_types.Get(i))) > 0) {
        field_types_needed.Add(field_types.Get(i));
        ++field_num;
      }
    }
    if (field_num > 0) {
      user_keys->push_back(std::make_pair(user_key, field_types_needed));
    }
    return field_num;
  }

  static std::string GenUserKey(const std::string & data_type,
                                const std::string & id_type,
                                const std::string & id) {
    std::string key = data_type;
    key += "`";
    key += id_type;
    key += "`";
    key += id;
    return key;
  }
};
} // common
} // reco
