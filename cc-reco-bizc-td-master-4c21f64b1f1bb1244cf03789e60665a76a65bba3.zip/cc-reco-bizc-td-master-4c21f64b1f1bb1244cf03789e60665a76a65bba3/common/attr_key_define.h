#pragma once

#include <string>
#include <vector>

#include "base/common/base.h"

namespace reco {
namespace common {

// 建库文档 key-value 属性对应的 key 值
// 公共的基本属性
namespace attr_key {
const char kExpireTimestamp[] = "EXPIRE_TIMESTAMP";
const char kPublishTimestamp[] = "CREATE_TIMESTAMP";
const char kCrawlTimestamp[] = "CRAWL_TIMESTAMP";
const char kRegion[] = "REGION";
const char kRegionFromTitle[] = "REGION_FROM_TITLE";
const char kRegionRestrict[] = "REGION_RESTRICT";

const char kKeywordList[] = "KEYWORD_LIST";
const char kKeywordFeatureList[] = "KEYWORD_FEATURE_LIST";
const char kKeywordNorm[] = "KEYWORD_NORM";

const char kTopicList[] = "TOPIC_LIST";
const char kTopicFeatureList[] = "TOPIC_FEATURE_LIST";
const char kTopicNorm[] = "TOPIC_NORM";

const char kWordvecList[] = "WORDVEC_LIST";
const char kWordvecFeatureList[] = "WORDVEC_FEATURE_LIST";
const char kWordvecNorm[] = "WORDVEC_NORM";


const char kTagList[] = "TAG_LIST";
const char kTagFeatureList[] = "TAG_FEATURE_LIST";
const char kTagNorm[] = "TAG_NORM";

const char kPlsaTopicList[] = "PLSA_TOPIC_LIST";
const char kPlsaTopicFeatureList[] = "PLSA_TOPIC_FEATURE_LIST";
const char kPlsaTopicNorm[] = "PLSA_TOPIC_NORM";

const char kTitleLdaTopicList[] = "TITLE_LDA_TOPIC_LIST";
const char kTitleLdaTopicFeatureList[] = "TITLE_LDA_TOPIC_FEATURE_LIST";
const char kTitleLdaTopicNorm[] = "TITLE_LDA_TOPIC_NORM";

const char kSemanticTagList[] = "SEMANTIC_TAG_LIST";
const char kSemanticTagFeatureList[] = "SEMANTIC_TAG_FEATURE_LIST";
const char kSemanticTagNorm[] = "SEMANTIC_TAG_NORM";

const char kRawSummary[] = "RAW_SUMMARY";

const char kSpecialPreviewIdList[] = "SPECIAL_PREVEW_ITEM_LIST";
const char kSpecialContainIdList[] = "SPECIAL_CONTAIN_ITEM_LIST";

const char kAppToken[] = "APP_TOKEN";
const char kCategory[] = "CATEGORY";
const char kCategoryCandidates[] = "CATEGORY_CANDIDATES";
const char kChannel[] = "CHANNEL";
const char kPriority[] = "PRIORITY";
const char kSource[] = "SOURCE";
const char kOrigSource[] = "ORIG_SOURCE";
const char kSourceMedia[] = "SOURCE_MEDIA";
const char kOrigSourceMedia[] = "ORIG_SOURCE_MEDIA";
const char kItemType[] = "ITEM_TYPE";
const char kOuterId[] = "OUTER_ID";

const char kNovelId[] = "NOVEL_ID";
const char kNovelUpdateTime[] = "NOVEL_UPDATE_TIME";

const char kImageCount[] = "IMAGE_COUNT";
const char kVideoCount[] = "VIDEO_COUNT";
const char kVideoLength[] = "VIDEO_LENGTH";
const char kContentLength[] = "CONTENT_LENGTH";
const char kParagraphNum[] = "PARAGRAPH_NUM";
const char kVideoVulgarLevel[] = "VIDEO_VULGAR_LEVEL";
const char kVideoQualityLevel[] = "VIDEO_QUALITY_LEVEL";
const char kTitleLength[] = "TITLE_LENGTH";
const char kSimHash[] = "SIM_HASH";
const char kParagraphHash[] = "PARAGRAPH_HASH";
const char kImageHash[] = "IMAGE_HASH";
const char kPublishTimeInSeconds[] = "PUBLISH_TIME";

const char kUcBrowserDeliverSetting[] = "UCBR_DELIVER";
const char kUcBrowserStyleType[] = "UCBR_STYLE_TYPE";
const char kUCBEditorName[] = "UCB_EDITOR_NAME";
const char kWeMediaPerson[] = "WEMEDIA_PERSON";

const char kJingpinScore[] = "JINGPIN_SCORE";

const char kItemHasReviewed[] = "ITEM_HAS_REVIEWED";
const char kItemIsYuanchuang[] = "ITEM_IS_YUANCHUANG";

const char kItemSubscripts[] = "ITEM_SUBSCRIPTS";

const char kContentAttr[] = "CONTENT_ATTR";
const char kVideoAttr[] = "VIDEO_ATTR";
const char kGaoDePOI[] = "GAODE_POI";
const char kTimeAxisResults[] = "TIME_AXIS_RESULTS";

const char kChannelIds[] = "CHANNEL_IDS";

const char kItemShowTag[] = "ITEM_SHOW_TAG";
const char kHasVideoStorageInfo[] = "HAS_VIDEO_STORAGE_INFO";
const char kVideoStorageInfoStatus[] = "VIDEO_STORAGE_INFO_STATUS";
const char kYoukuVideoId[] = "YOUKU_VIDEO_ID";
const char kItemQualityAttr[] = "ITEM_QUALITY_ATTR";
const char kPosteriorItemQ[] = "POSTERIOR_ITEM_Q";
const char kVideoBlackEdgeRatio[] = "VIDEO_BLACK_EDGE_RATIO";
const char kVideoPosterProblemInfo[] = "VIDEO_POSTER_PROBLEM_INFO";
const char kVideoPosterClarity[] = "VIDEO_POSTER_CLARITY";
const char kVideoWidth[] = "VIDEO_WIDTH";
const char kVideoHeight[] = "VIDEO_HEIGHT";
const char kVideoColors[] = "VIDEO_COLORS";
const char kItemEventTag[] = "ITEM_EVENT_TAG";
const char kItemEventTagInfo[] = "ITEM_EVENT_TAG_INFO";

const char kVideoPlayControl[] = "VIDEO_PLAY_CONTROL";
const char kOrigMediaRiskType[] = "ORIG_MEDIA_RISK_TYPE";
const char kManualNews[] = "MANUAL_NEWS";
const char kYoukuAuditStatus[] = "YOUKU_AUDIT_STATUS";
const char kHa3UpdateTime[] = "HA3_UPDATE_TIMESTAMP";
const char kYoukuShowID[] = "YOUKU_SHOW_ID";
const char kRawTitle[] = "RAW_TITLE";

const char kSubjectSubItems[] = "SUBJECT_SUB_ITEMS";
const char kGroupInfo[] = "GROUP_INFO";

const char kLocalBreaking[] = "LOCAL_BREAKING";
const char kAppTokenBits[] = "APP_TOKEN_BITS";
const char kAppTokenRuleBits[] = "APP_TOKEN_RULE_BITS";
const char kFirstNScreenFilter[] = "FIRST_NSCREEN_FILTER";
const char kSourcePublishPlatform[] = "SOURCE_PUBLISH_PLATFORM";
const char kVideoResolution[] = "VIDEO_RESOLUTION";

const char kItemAttachDataExt[] = "ITEM_ATTACH_DATA_EXT";
}  // namespace attr_key

}  // namespace common
}  // namespace reco

