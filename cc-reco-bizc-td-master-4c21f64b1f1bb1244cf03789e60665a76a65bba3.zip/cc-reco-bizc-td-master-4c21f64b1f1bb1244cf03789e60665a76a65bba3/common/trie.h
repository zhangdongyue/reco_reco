#pragma once

#include <vector>
#include <string>

namespace reco {
namespace common {

class Trie;

struct TrieNode {
  TrieNode() : sub_tire(NULL), is_odd_end(false), is_even_end(false) { children.resize(0x10000, NULL); }
  ~TrieNode();

  std::vector<TrieNode*> children;
  Trie* sub_tire;
  bool is_odd_end;
  bool is_even_end;
};

class Trie {
 public:
  Trie() :  root_(NULL) {}

  ~Trie() {
    if (root_ != NULL) {
      delete root_;
      root_ = NULL;
    }
  }

  void Insert(const std::string& word) {
    size_t pos = word.find('-');
    if (std::string::npos == pos) {
      InsertWord(word);
    } else {
      TrieNode* p = InsertWord(word.substr(0, pos), false);
      if (NULL == p->sub_tire) {
        p->sub_tire = new Trie();
      }
      p->sub_tire->InsertWord(word.substr(pos+1));
    }
  }

  inline bool Find(const std::string& word) const {
    bool is_odd = false;
    TrieNode* p = FindWord(word, is_odd);
    if (NULL == p) {
      return false;
    }

    return is_odd?p->is_odd_end:p->is_even_end;
  }

  inline bool Find(const std::string& word, const std::string& sub_word) const {
    bool is_odd = false;
    TrieNode* p = FindWord(word, is_odd);
    if (NULL == p)
      return false;

    if (is_odd?p->is_odd_end:p->is_even_end) {
      return true;
    }

    if (NULL == p->sub_tire || sub_word.empty())
      return false;

    return p->sub_tire->Find(sub_word);
  }

 private:
  TrieNode* InsertWord(const std::string& word, bool is_end = true) {
    if (NULL == root_) {
      root_ = new TrieNode();
    }

    TrieNode* p = root_;
    size_t sz = word.size() >> 1;
    const uint16* data = reinterpret_cast<const uint16*>(word.c_str());

    for (size_t i = 0; i < sz; ++i) {
      uint16 k = data[i];
      if (NULL == p->children[k]) {
        p->children[k] = new TrieNode();
      }
      p = p->children[k];
    }

    sz <<= 1;
    if (sz != word.size()) {
      uint16 k = word[sz];
      if (NULL == p->children[k]) {
        p->children[k] = new TrieNode();
      }
      p = p->children[k];
      if (is_end) {
        p->is_odd_end = true;
      }
    } else if (is_end) {
      p->is_even_end = true;
    }
    return p;
  }

  inline TrieNode* FindWord(const std::string& word, bool& is_odd) const {
    if (NULL == root_) {
      return NULL;
    }

    TrieNode* p = root_;
    size_t sz = word.size() >> 1;
    const uint16* data = reinterpret_cast<const uint16*>(word.c_str());

    for (size_t i = 0; i < sz; ++i) {
      uint16 k = data[i];
      p = p->children[k];
      if (NULL == p) {
        return NULL;
      }
    }
    sz <<= 1;
    is_odd = sz != word.size();
    if (is_odd) {
      p = p->children[(uint16)(word[sz])];
    }
    return p;
  }


 private:
  TrieNode* root_;
};

inline TrieNode::~TrieNode() {
  for (size_t i = 0; i < children.size(); ++i) {
    if (children[i] != NULL) {
      delete children[i];
    }
  }
  if (sub_tire != NULL) {
    delete sub_tire;
  }
}
}
}
