//
// Created by allen.fw on 2017/10/26.
//

#pragma once

#include <memory>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include "base/strings/string_printf.h"

namespace reco {
namespace common {

struct IndexStrategyBranch {
  IndexStrategyBranch() : enum_value(-1), comment("empty comment") {
  }
  IndexStrategyBranch(const int v, const std::string &c)
          : enum_value(v), comment(c) {
  }

  ~IndexStrategyBranch() {
  }

  std::string ToString() {
    return base::StringPrintf("%d\t%s\n", enum_value, comment.c_str());
  }

  bool operator<(const IndexStrategyBranch& rhs) {
    return enum_value < rhs.enum_value;
  }

  bool operator>(const IndexStrategyBranch& rhs) {
    return enum_value > rhs.enum_value;
  }

  bool operator<=(const IndexStrategyBranch& rhs) {
    return !(*this > rhs);
  }

  bool operator>=(const IndexStrategyBranch& rhs) {
    return !(*this < rhs);
  }

  bool operator==(const IndexStrategyBranch& rhs) {
    return enum_value == rhs.enum_value;
  }

  friend bool operator==(const IndexStrategyBranch& lhs, const IndexStrategyBranch& rhs) {
    return lhs.enum_value == rhs.enum_value;
  }

  IndexStrategyBranch& operator=(const IndexStrategyBranch &rhs) {
    enum_value = rhs.enum_value;
    comment = rhs.comment;
    return *this;
  }

  int enum_value;
  std::string comment;
};

struct StrategyHash{
  size_t operator()(const reco::common::IndexStrategyBranch& strategy) const {
    return static_cast<size_t>(strategy.enum_value);
  }
};

class IndexStrategyFactory {
 public:
  static IndexStrategyBranch GetIndexStrategy(const int enum_value, const std::string& comment) {
    return IndexStrategyBranch(enum_value, comment);
  }
};

// leaf publish
#define kIndexManual IndexStrategyFactory::GetIndexStrategy(0, "运营")
#define kIndexLeaf IndexStrategyFactory::GetIndexStrategy(10, "leaf 索引内容")
#define kLeafChannel IndexStrategyFactory::GetIndexStrategy(11, "leaf 根据频道召回")
#define kLeafCategory IndexStrategyFactory::GetIndexStrategy(12, "leaf 根据类目召回")
#define kLeafGoodMine IndexStrategyFactory::GetIndexStrategy(20, "leaf 历史挖掘的优质内容")
#define kLeafBeautyMine IndexStrategyFactory::GetIndexStrategy(21, "leaf 历史外挖掘的美女内容")
#define kLeafDuration IndexStrategyFactory::GetIndexStrategy(22, "leaf 历史挖掘的阅读时长排序内容")
#define kLeafFav IndexStrategyFactory::GetIndexStrategy(23, "leaf 历史挖掘的收藏排序内容")
#define kLeafShare IndexStrategyFactory::GetIndexStrategy(24, "leaf 历史挖掘的分享排序内容")
#define kLeafLike IndexStrategyFactory::GetIndexStrategy(25, "leaf 历史挖掘的 like 排序内容")
#define kLeafLikeRatio IndexStrategyFactory::GetIndexStrategy(26, "leaf 历史挖掘的 like / dislike 比例排序内容")
#define kLeafComment IndexStrategyFactory::GetIndexStrategy(27, "leaf 历史挖掘的评论排序内容")
#define kLeafSuperb IndexStrategyFactory::GetIndexStrategy(28, "leaf 运营标注的精品内容")
#define kLeafBeautyPic IndexStrategyFactory::GetIndexStrategy(29, "leaf 产品指定召回美女图片")

// video publish
#define kIndexVideo IndexStrategyFactory::GetIndexStrategy(100, "video 索引")
#define kVideoSource IndexStrategyFactory::GetIndexStrategy(101, "video 根据 source 召回")
#define kVideoSubject IndexStrategyFactory::GetIndexStrategy(102, "video 主题 item")
#define kVideoTagItems IndexStrategyFactory::GetIndexStrategy(103, "video 按 tag 去 search server 拉取的内容")
#define kVideoJingpin IndexStrategyFactory::GetIndexStrategy(104, "video 运营标注的精品内容")
#define kIndexVideoUgcHandpick IndexStrategyFactory::GetIndexStrategy(105, "video UGC 手工选取视频")
#define kUnknownStrategy IndexStrategyFactory::GetIndexStrategy(255, "未知的下发的 item")

// filter
#define kLeafCategoryGroupFilter IndexStrategyFactory::GetIndexStrategy(301, "在 category item 分组中被过滤掉")
#define kLeafRankItemFilter IndexStrategyFactory::GetIndexStrategy(302, "在 rank item 排序中被过滤掉")
#define kProduceWhiteDictFilter IndexStrategyFactory::GetIndexStrategy(401, "被 producer 白名单过滤掉")
#define kFinanceStockFilter IndexStrategyFactory::GetIndexStrategy(402, "被财经类规则过滤掉")
#define kBadItemFilter IndexStrategyFactory::GetIndexStrategy(403, "被风险媒体、标题党等规则过滤掉")
#define kInnerAtlasItemFilter IndexStrategyFactory::GetIndexStrategy(404, "由于内嵌图集被过滤")
#define kWhiteSourceSeedFilter IndexStrategyFactory::GetIndexStrategy(405, "被种子白名单过滤")
#define kInvalidItemFilter IndexStrategyFactory::GetIndexStrategy(410, "无效 item 过滤")
#define kGetDocFailFilter IndexStrategyFactory::GetIndexStrategy(411, "由于查不到 doc info 而被过滤")
#define kUnknownItemFilter IndexStrategyFactory::GetIndexStrategy(555, "未知被过滤的 item")
}
}
