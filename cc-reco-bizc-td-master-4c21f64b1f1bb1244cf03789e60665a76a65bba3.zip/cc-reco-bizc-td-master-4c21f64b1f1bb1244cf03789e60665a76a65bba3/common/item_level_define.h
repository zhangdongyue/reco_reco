#pragma once

#include <string>
#include <vector>

namespace reco {
namespace item_level {

const char kItemRedisKeyPrefix[] = "ItemLevel-";
// const char kItemRedisKeyPrefix[]    = "MetaExp-";
const char kSpiderScoreKeyPrefix[] = "ItemLevel-";

const char kTimeLevelField[]     = "TimeLevel";
const char kSiteLevelField[]     = "SiteLevel";
const char kHotLevelField[]      = "HotScore";
const char kSensitiveTypeField[] = "SensitiveType";
const char kItemQualityField[]   = "ItemQuality";
const char kStatItemqField[]     = "StatItemq";
const char kPrioriItemqField[]   = "PrioriItemq";
const char kPRScoreField[]       = "PR";

// log data related
const char kShowField[]             = "Show";
const char kClickField[]            = "Click";
const char kDurationField[]         = "AvgDuration";
const char kCtrqField[]             = "Ctrq";

const char kFavField[]              = "Fav";
const char kShareField[]            = "Share";
const char kLikeField[]             = "Like";
const char kDisLikeField[]          = "DisLike";

// spider ranking
const char kSpiderCommentCountField[] = "SCommentCnt";
const char kSpiderUpCountField[]      = "SUpCnt";
const char kSpiderDownCountField[]    = "SDownCnt";
const char kSpiderReadCountField[]    = "SReadCnt";
const char kSpiderPlayCountField[]    = "SPlayCnt";
const char kSpiderShareCountField[]   = "SShareCnt";
const char kSpiderFavCountField[]     = "SFavCnt";
const char kSpiderScoreField[]        = "SpiderScore";

// predict ctr
const char kPredictCtr[]            = "PredictCtr";

// hot thres
const int kManualHotScoreThres = 100;
const int kTopHotScoreThres    = 50;
const int kVeryHotScoreThres   = 40;
const int kHotScoreThres       = 30;
const int kMidHotScoreThres    = 20;
const int kLowHotScoreThres    = 0;
const int kFloorHotScoreThres  = 5;

}
}
