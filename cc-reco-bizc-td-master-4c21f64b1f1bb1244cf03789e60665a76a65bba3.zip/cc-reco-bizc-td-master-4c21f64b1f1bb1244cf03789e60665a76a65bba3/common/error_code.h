#pragma once

namespace reco {
enum {
  ENUM_INTENT_NET_ERROR = 1 ,
  ENUM_INTENT_PARSE_ERROR   ,
  ENUM_QP_ERROR             ,
  ENUM_BIDWORD_NET_ERROR    ,
  ENUM_BIDWORD_RET_ERROR    ,
  ENUM_AD_NET_ERROR         ,
  ENUM_AD_RET_ERROR         ,
  ENUM_ROOT_ERROR           ,
  ENUM_OVER_LOAD            ,
};
}  // namespace reco
