# -*- coding: UTF-8-*-
#encoding= UTF-8
from sklearn.utils import shuffle
import gensim
import logging
import datetime
import pandas as pd
import numpy as np
import tensorflow as tf
import pickle
import os
import re
import random 
import math
import ml_metrics as metrics

window_size =15
pre_size =5
lg_rate = 0.0025# 定义学习速度 最后的loss 
training_epochs =10# 训练次数
batch_size =256 # 数据批次训练 minibatch 这个后期考虑
num_samp =1000#num_samp =500## 负采样的数量
emb_dim = 256#  relu的网络层最后一层输出节点
save_path= u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/pkl_model" # dic 相关中间参量存储
save_pd_path = u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/data/skip-1/avg_1" # 向量AVG之后的数据
vec_path =u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/data"
emb_size=256 #视频ID embedding 之后的维度

def save_data(dic_list,name):
    ''' save dic data '''
    output = open(save_path+u"/"+name+'.pkl', 'wb')
    pickle.dump(dic_list, output)
    output.close()
def reload_data(name):
    ''' reload dic data '''
    pkl_file = open(save_path+u"/"+name+'.pkl', 'rb')
    data = pickle.load(pkl_file)
    pkl_file.close()
    return data
#******************************subsampling 亚采样 start********************************
def Sample_drophot(train_data):
    '''丢掉热门label 按照热门反热度采样'''
    #print(Video_count.values())
    train_data["pro"] =train_data["itemid"]
    train_data["pro"] =train_data["pro"].apply(apply_drophot)
    train_data =train_data[train_data["pro"]<0]
    return train_data

def apply_drophot(x):
    t =0.00001
    ss =random.uniform(0,1)
    fre_rate =Video_count[str(x)]
    pro_kk =math.sqrt(t/fre_rate)+(t/fre_rate)
    if pro_kk <ss:
        pro_kk =1 ##丢掉
    else:
        pro_kk =-1 ##不丢掉
    return pro_kk
#******************************subsampling 亚采样 end********************************


#**************************************神经网络层******************************************
def Batch_Norm(Wx_plus_b,out_size):
    #******************batch normalization*********************
    scale = tf.Variable(tf.ones([out_size])) #需要训练出来的放缩尺度伽马  
    shift = tf.Variable(tf.zeros([out_size]))#需要寻来拿出来的平移变换贝塔 
    epsilon = 0.001  
    fc_mean, fc_var = tf.nn.moments(Wx_plus_b,axes=[0])
    ema = tf.train.ExponentialMovingAverage(decay=0.5)  
    def mean_var_with_update():  
        ema_apply_op = ema.apply([fc_mean, fc_var])  
        with tf.control_dependencies([ema_apply_op]):  
            return tf.identity(fc_mean,name="BN_mean"), tf.identity(fc_var,name ="BN_var")  
    mean, var = mean_var_with_update()
    Wx_plus_b = tf.nn.batch_normalization(Wx_plus_b, mean, var, shift, scale, epsilon)
    return Wx_plus_b

def AddNetLayer(input_x,Weight,bias):
    '''搭建神经网络层 Relu 可以是激活函数'''
    Wx_plus_b = tf.matmul(input_x,Weight)+bias
    #Wx_plus_b =Batch_Norm(Wx_plus_b,bias.shape[0])
    output = tf.nn.tanh(Wx_plus_b)
    return output 

def softmax_layer_nce(example_emb,y_batch,sm_w_t,sm_b):
    #loss =tf.reduce_mean(tf.nn.nce_loss(weights=sm_w_t,biases=sm_b,labels=y_batch,inputs =example_emb,num_sampled =num_samp,num_classes=len(Video_title),remove_accidental_hits=True))
    loss =tf.reduce_mean(tf.nn.sampled_softmax_loss(weights=sm_w_t,biases=sm_b,labels=y_batch,inputs =example_emb,num_sampled =num_samp,num_classes=len(Video_title)))
    Wx_plus_b =tf.matmul(example_emb,tf.transpose(sm_w_t))+sm_b
    #Wx_plus_b =Batch_Norm(Wx_plus_b,sm_b.shape[0])
    softmax_layer = tf.nn.softmax(Wx_plus_b)
    return softmax_layer,loss

#**************************************神经网络层****************************************** 
#****************************************feed 数据读取**************************************
def read_data_batch(data_batch_input):
    '''mini batch 训练 小批量数据训练,每个batch收敛会比较快'''
    data_batch_input =data_batch_input.reset_index(drop=True)
    word_num =data_batch_input["item_count"]
    predict_list =data_batch_input[predict_col] # 预测序列
    batch_x =data_batch_input[vec_item]
    batch_y =data_batch_input["itemid"]
    #print("batch_y",batch_y)
    other_fea_in =(data_batch_input["age"]-age_mess[0])/(age_mess[1]-age_mess[0])
    return batch_x,batch_y,word_num,predict_list,other_fea_in
 
def model(f_name,k_cols,istrain =True):
    #********************变量定义start **************************************
    tf.reset_default_graph() ## 解决 saver.restore的错误
    checkpoint_dir =u"./03_age_with_subsampling_tanh_var/"
    item_count =len(Video_title)
    in_1_size =emb_size+1
    out_1_size =emb_dim*2 #out_1_size =emb_dim*2 
    in_2_size =out_1_size
    out_2_size =emb_dim
    x_batch = tf.placeholder(tf.int64, shape=[None,window_size],name ="x_batch")
    other_fea_batch =tf.placeholder(tf.float32, shape=[None,1],name ="fea_batch")
    y_batch = tf.placeholder(tf.int64, [None,1],name ="y_batch")
    word_num_batch = tf.placeholder(tf.float32, shape=[None, 1],name ="word_num_batch")
    labels_predict =tf.placeholder(tf.int64, [None,pre_size],name ="labels_predict")
    vector_item =tf.cast(tf.Variable(vec_df[:vec_df.shape[0]-1],name="vec_df"),dtype=tf.float32)
    vector_item =tf.concat([vector_item,np.zeros((1,emb_size))],0)
    weights = {
    'h1_w':tf.Variable(tf.random_normal([in_1_size,out_1_size] ,mean=0,stddev=1.0/out_1_size),name ="h1_w"),
    'h2_w':tf.Variable(tf.random_normal([in_2_size,out_2_size] ,mean=0,stddev=1.0/out_1_size),name ="h2_w"),
    'sm_t':tf.cast(tf.Variable(vec_df[:vec_df.shape[0]-1],name="sm_t"),dtype=tf.float32)
    #'sm_t':tf.Variable(tf.truncated_normal([item_count,out_2_size],mean=0,stddev=1.0/item_count),name="sm_t")
    }
    biases = {
    'h1_b': tf.Variable(tf.zeros([out_1_size]),name ="h1_b"),
    'h2_b': tf.Variable(tf.zeros([out_2_size]),name ="h2_b"),
    'sm_b':  tf.Variable(tf.zeros([item_count]), name="sm_b")
        }
    #****************************神经网络层 start***************************************************
    input_avg =tf.div(tf.reduce_sum(tf.nn.embedding_lookup(vector_item,x_batch),1),word_num_batch)
    input_all =tf.concat([input_avg,other_fea_batch],1)
    hidden_1_out = AddNetLayer(input_all,weights['h1_w'],biases['h1_b'])
    hidden_2_out = AddNetLayer(hidden_1_out,weights['h2_w'],biases['h2_b'])
    pred,loss =softmax_layer_nce(hidden_2_out,y_batch,weights['sm_t'],biases['sm_b'])
    #***************************评估数据 mAP**********************************
    values,indices = tf.nn.top_k(pred,100)
    #mAP_batch,map_op = tf.contrib.metrics.streaming_sparse_average_precision_at_top_k(indices,labels_predict)
    #****************************神经网络层 end ***************************************************
    optimizer = tf.train.AdamOptimizer(learning_rate=lg_rate).minimize(loss) # optimize
    saver = tf.train.Saver()
    #**************************train************************************************
    if istrain:
        init = tf.global_variables_initializer() # init all
    with tf.Session() as sess:
        if istrain:
            sess.run(init)
            for epoch in range(training_epochs):
                print("循环"+str(epoch))
                avg_loss =0.0
                pre_loss =0.0
                count =0
                pd_df_reader =pd.read_csv(f_name,sep='\t',chunksize =1000*batch_size,names=key_col)
                for chunk in pd_df_reader:
                    print("data size ",chunk.shape)
                    chunk =Sample_drophot(chunk)
                    print("data size without hot",chunk.shape)
                    total_len =chunk.shape[0]/batch_size
                    for batch_i in range(total_len-1):
                        #print("vector",sess.run(vector_item))
                        count =count+1 
                        batch_x,batch_y,word_num,predict_list,other_fea_in\
                        =read_data_batch(chunk[batch_i*batch_size:(batch_i+1)*batch_size])
                        _,loss_iter=sess.run([optimizer,loss], feed_dict={x_batch:batch_x,other_fea_batch:other_fea_in.reshape(-1,1),y_batch:batch_y.reshape(-1,1),word_num_batch:word_num.reshape(-1,1),labels_predict:predict_list})
                        avg_loss +=loss_iter
                        print("iteral",count,"loss",avg_loss/count)
                        pre_loss =avg_loss/count
                        if count%500==0:
                            list_video =sess.run(indices,feed_dict={x_batch:batch_x,other_fea_batch:other_fea_in.reshape(-1,1),y_batch:batch_y.reshape(-1,1),word_num_batch:word_num.reshape(-1,1),labels_predict:predict_list})
                            #list_video =outlist.argsort()
                            saver.save(sess, checkpoint_dir+"my-model_01.ckpt",global_step=count)
                            size_iter =len(batch_y.values)
                            for i in range(10): #打印前20个的 len(list_video) 
                                print("******************label***************************")
                                j_row =i#j_row =random.randint(0,size_iter-1) #j_row =i  #
                                print(Video_title[str(batch_y.values[j_row])])
                                print(batch_y.values[j_row])
                                print(j_row,"******************hist***************************")
                                n_row_x =batch_x.loc[j_row].tolist()
                                for item in n_row_x:
                                    if int(item)==item_count:
                                        print("nan")
                                    else:
                                        print(Video_title[str(int(item))])
                                    #print(item)
                                print("******************reco***************************")
                                head_n_video =list_video[j_row ,-6:]
                                for itemid in head_n_video:
                                    print(Video_title[str(itemid)]) ## 打印出前n个最大值 n=10
                                    print(itemid)
                saver.save(sess, checkpoint_dir+"my-model_01.ckpt",global_step=count)      
        else:
            ckpt = tf.train.get_checkpoint_state(checkpoint_dir)
            if ckpt and ckpt.model_checkpoint_path:
                print("model_restore",ckpt.model_checkpoint_path)
                saver.restore(sess, ckpt.model_checkpoint_path)
                mAP =0.0
                avg_loss =0.0
                count =0
                pd_df_reader =pd.read_csv(f_name,sep='\t',chunksize =1000*batch_size,names=key_col)
                for chunk in pd_df_reader:
                    print("data size ",chunk.shape)
                    #chunk =Sample_drophot(chunk)
                    print("data size without hot",chunk.shape)
                    total_len =chunk.shape[0]/batch_size
                    for batch_i in range(total_len-1):
                        count =count+1
                        batch_x,batch_y,word_num,predict_list,other_fea_in=\
                        read_data_batch(chunk[batch_i*batch_size:(batch_i+1)*batch_size])
                        loss_iter,top_k =sess.run([loss,indices],feed_dict={x_batch:batch_x,other_fea_batch:other_fea_in.reshape(-1,1),y_batch:batch_y.reshape(-1,1),word_num_batch:word_num.reshape(-1,1),labels_predict:predict_list})
                        #print("top_k",top_k,"shape",top_k.shape)
                        #print("indices",predict_list,"shape",predict_list.shape)
                        mAP +=metrics.mapk(actual=np.array(predict_list).tolist(),predicted=top_k.tolist(), k=100)
                        avg_loss +=loss_iter
                        if count%50 ==0:
                            print("iteral",count,"loss",avg_loss/count)
                            print("iteral",count,"mAP",mAP/count)
                        
#************************************************************************************************************************

ids_col =["T1_age","Tn_age","countid","item_count","itemid","age","userid"]
predict_col =[str(n)+"pre" for n in range(pre_size)]
vec_item =[i for i in range(window_size)]
key_col =vec_item+ids_col+predict_col ## 定义字段名
print("col_name",key_col)
print("reload")
Video_count =reload_data("Video_count") ## 视频 count
sum_count =float(sum(Video_count.values()))
for k,v in Video_count.items():
    Video_count[k] =v/sum_count  
Video_title = reload_data("Video_title") ## 视频 title
model_vec =gensim.models.KeyedVectors.load_word2vec_format(save_path+u"/vector256.bin", binary=True)
vec_df =pd.read_csv(vec_path+u"/1vec_item.txt",sep=' ',header=None) ## 第一行就是数据 header=None
print("the total count of Video",len(Video_count))
print("the total count of embedding Video",vec_df.shape[0])
age_mess =reload_data("age_mess") #[min_age,max_age,mean_age,var_age]
print("age min",age_mess[0],"age max",age_mess[1],"age mean",age_mess[2],"age var",age_mess[3])

train_fname =save_pd_path+u"/"+"train_2.txt" 
test_fname =save_pd_path+u"/"+"test.txt"

print("开始")
model(test_fname,key_col,istrain =True)