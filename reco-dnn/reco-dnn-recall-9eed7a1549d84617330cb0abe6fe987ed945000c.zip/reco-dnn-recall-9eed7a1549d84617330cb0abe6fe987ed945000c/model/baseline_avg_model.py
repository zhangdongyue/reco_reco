# -*- coding: UTF-8-*-
#encoding= UTF-8
from sklearn.utils import shuffle
import gensim
import logging
import datetime
import pandas as pd
import numpy as np
import tensorflow as tf
import pickle
import os
import re
import random 
import math
import ml_metrics as metrics

window_size =15
predict_list =5
lg_rate = 0.04# 定义学习速度 最后的loss 优化 SGD
training_epochs =4# 训练次数
batch_size =128 # 数据批次训练 minibatch 这个后期考虑
num_samp =32#num_samp =500## 负采样的数量
emb_dim = 128#  relu的网络层最后一层输出节点
save_path= u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/pkl_model" # dic 相关中间参量存储
save_pd_path = u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/data_128" # 向量AVG之后的数据
emb_size=128 #视频ID embedding 之后的维度
ids_col =["countid","item_count","itemid","userid"]
predict_col =[str(n)+"pre" for n in range(predict_list)]
def save_data(dic_list,name):
    ''' save dic data '''
    output = open(save_path+u"/"+name+'.pkl', 'wb')
    pickle.dump(dic_list, output)
    output.close()
def reload_data(name):
    ''' reload dic data '''
    pkl_file = open(save_path+u"/"+name+'.pkl', 'rb')
    data = pickle.load(pkl_file)
    pkl_file.close()
    return data
#******************************subsampling 亚采样 start********************************
def Sample_drophot(train_data):
    '''丢掉热门label 按照热门反热度采样'''
    #print(Video_count.values())
    train_data["pro"] =train_data["itemid"]
    train_data["pro"] =train_data["pro"].apply(apply_drophot)
    train_data =train_data[train_data["pro"]<0]
    return train_data

def apply_drophot(x):
    t =0.00001
    ss =random.uniform(0,1)
    fre_rate =Video_count[str(x)]
    pro_kk =math.sqrt(t/fre_rate)+(t/fre_rate)
    if pro_kk <ss:
        pro_kk =1 ##丢掉
    else:
        pro_kk =-1 ##不丢掉
    return pro_kk
#******************************subsampling 亚采样 end********************************


#**************************************神经网络层******************************************
def AddNetLayer(input_x,Weight,bias):
    '''搭建神经网络层 Relu 可以是激活函数'''
    Wx_plus_b = tf.matmul(input_x,Weight)+bias
    output = tf.nn.relu(Wx_plus_b)
    return output 

def softmax_layer_nce(example_emb,y_batch,sm_w_t,sm_b):
    loss =tf.reduce_mean(tf.nn.nce_loss(weights=sm_w_t,biases=sm_b,labels=y_batch,inputs =example_emb,num_sampled =num_samp,num_classes=len(Video_title)))
    softmax_layer = tf.nn.softmax(tf.matmul(example_emb,tf.transpose(sm_w_t))+sm_b)
    return softmax_layer,loss

#**************************************神经网络层****************************************** 
#****************************************feed 数据读取**************************************
def read_data_batch(data_batch_input):
    '''mini batch 训练 小批量数据训练,每个batch收敛会比较快'''
    #print("data size with na",data_batch_input.shape)
    #data_batch_input =data_batch_input.dropna(axis=0)
    print("data size ",data_batch_input.shape)
    #data_batch_input  =Sample_drophot(data_batch_input) ##打压掉热门观看点label
    print("data size without hot",data_batch_input.shape)
    data_batch_input =data_batch_input.reset_index(drop=True)
    word_num =data_batch_input["item_count"]
    predict_list =data_batch_input[predict_col] # 预测序列
    batch_x =data_batch_input[vec_item]
    batch_y =data_batch_input["itemid"]
    return batch_x,batch_y,word_num,predict_list
 
def model(f_name,k_cols,istrain =True):
    #********************变量定义start **************************************
    tf.reset_default_graph() ## 解决 saver.restore的错误
    checkpoint_dir =u"./model_01_cons_bin/"
    item_count =len(Video_title)
    in_1_size =emb_size## embedding vector 的长度 后续可以添加其他特征
    out_1_size =emb_dim ## 最后一层relu
    x_batch = tf.placeholder(tf.int64, shape=[None,window_size],name ="x_batch")
    y_batch = tf.placeholder(tf.int64, [None,1],name ="y_batch")
    word_num_batch = tf.placeholder(tf.float32, shape=[None, 1],name ="word_num_batch")
    #vector_item =tf.Variable(tf.random_uniform([item_count + 1, emb_size], -1.0, 1.0),name="vec_pd")
    vector_item =tf.cast(tf.constant(vec_df,name="vec_df"),dtype=tf.float32) 
    weights = {
    'h1_w':tf.Variable(tf.random_normal([in_1_size,out_1_size] ,mean=0,stddev=1.0/out_1_size),name ="h1_w"),
    'sm_t':tf.cast(tf.Variable(vec_df[:vec_df.shape[0]-1],name="sm_t"),dtype=tf.float32)
    #'sm_t':tf.Variable(tf.truncated_normal([item_count,emb_dim],mean=0,stddev=1.0/item_count),name="sm_t")
    }
    biases = {
    'h1_b': tf.Variable(tf.zeros([out_1_size]),name ="h1_b"),
    'sm_b':  tf.Variable(tf.zeros([item_count]), name="sm_b")
        }
    #****************************神经网络层 start***************************************************
    # 从embedding向量中获取 然后平均
    # 除个数平均<想一下>
    input_avg =tf.div(tf.reduce_sum(tf.nn.embedding_lookup(vector_item,x_batch),1),word_num_batch)
    #hidden_1_out = AddNetLayer(input_avg,weights['h1_w'],biases['h1_b'])
    #pred,loss =softmax_layer_nce(input_avg,y_batch,weights['sm_t'],biases['sm_b'])
    #****************************神经网络层 end ***************************************************
    #optimizer = tf.train.AdamOptimizer(learning_rate=lg_rate).minimize(loss) # optimize
    saver = tf.train.Saver()
    #**************************train************************************************
    if istrain:
        init = tf.global_variables_initializer() # init all
    with tf.Session() as sess:
        pd_df_reader =pd.read_csv(f_name,sep=' ',chunksize =batch_size,names=key_col)
        mAP =0.0
        mAP_nums_cnt =0
        for chunk in pd_df_reader:
            batch_x,batch_y,word_num,predict_list=read_data_batch(chunk)
            input_avg_out=sess.run(input_avg, feed_dict={x_batch:batch_x,y_batch:batch_y.reshape(-1,1),word_num_batch:word_num.reshape(-1,1)})
            # 计算input_avg_out 和 vec_df 的余弦相似度
            size_iter =len(batch_y.values)
            mAP_nums_cnt +=size_iter
            for i in range(input_avg_out.shape[0]):
                #print("*********************label*******************")
                #print(Video_title[str(batch_y.values[i])])
                #print("****************hist*************************")
                n_row_x =batch_x.loc[i].tolist()
                '''for item in n_row_x:
                    if int(item)==item_count:
                        print("nan")
                    else:
                        print(Video_title[str(int(item))]) '''              
                vec_avg =input_avg_out[i]
                most_10 =model_vec.similar_by_vector(vec_avg,topn=100)
                #print("****************similar******************")
                cnt =0
                pre_list =[]
                for itemid in most_10:
                    if cnt ==100:
                        break
                    pre_list.append(int(itemid[0]))
                    #print(Video_title[str(itemid[0])])
                    cnt =cnt+1
                AP =metrics.apk(actual=predict_list.loc[i].tolist(), predicted=pre_list, k=100)
                #print("AP",AP)
                mAP +=AP
            print("mAP",mAP/mAP_nums_cnt)
vec_item =[]
for i in range(window_size):
    vec_item.append(i)      
print("reload")
Video_count =reload_data("Video_count") ## 视频 count
sum_count =0.0
for i in Video_count.values():
    sum_count+=i
for k,v in Video_count.items():
    Video_count[k] =v/sum_count
Video_title = reload_data("Video_title") ## 视频 title
model_vec = gensim.models.KeyedVectors.load_word2vec_format(save_path+u'/vectors.bin', binary=True)
vec_df =pd.read_csv(save_pd_path+u"/1vec_item_bin.txt",sep=' ',header=None) ## 第一行就是数据 header=None
print("the total count of Video",len(Video_count))
print("the total count of embedding Video",vec_df.shape[0])

key_col =vec_item+ids_col+predict_col ## 定义字段名
train_fname =save_pd_path+u"/"+"train.txt" 
test_fname =save_pd_path+u"/"+"test.txt"
print("训练开始")
model(train_fname,key_col,istrain =True)
#print("测试开始")
#model(test_fname,key_col,istrain =False)