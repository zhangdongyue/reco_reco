# -*- coding: UTF-8-*-
#encoding= UTF-8
import pandas as pd 
import numpy as np
import pickle
from sklearn import preprocessing
save_path= u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/pkl_model" # dic 相关中间参量存储
save_pd_path = u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/data_128_age" # 添加 embedding向量AVG之后的数据 分文件存储
#************************获取年龄的均值和方差*******************************************
def save_data(dic_list,name):
    ''' save dic data '''
    output = open(save_path+u"/"+name+'.pkl', 'wb')
    pickle.dump(dic_list, output)
    output.close()
def reload_data(name):
    ''' reload dic data '''
    pkl_file = open(save_path+u"/"+name+'.pkl', 'rb')
    data = pickle.load(pkl_file)
    pkl_file.close()
    return data

pd_age =pd.read_csv(save_pd_path+u"/Tn_age.txt",sep=' ')
age_ctm =np.array(pd_age)
min_age =np.min(age_ctm)
max_age =np.max(age_ctm)
mean_age =np.mean(age_ctm)
var_age =np.std(age_ctm)
list_age =[min_age,max_age,mean_age,var_age]
save_data(list_age,"Tn_age")