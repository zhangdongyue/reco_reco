# -*- coding: UTF-8-*-
#encoding= UTF-8
### 切分数据 按userid切分
import os 
save_pd_path = u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/raw-data" 
user_path = u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/userdata"
def read_file_split(fm,size =150000):
    lst_user =""
    count =0
    lines =[]
    for line in open(fm,'r'):
        items =line.split('\t')# 第三个是userid
        if len(items)<3 or len(items)>6:   
            #print("items ",items)
            continue
        if cmp(items[3],lst_user)!=0:
            count =count+1
            lst_user =items[3]
            print("user",items[3])
            if count%size==0:
                print("items ",items)
                name =count/size
                #print("data_name",user_path+u"/"+str(name)+"user.txt")
                file_new =open(user_path+u"/"+str(name)+"user.txt",'w')
                file_new.writelines(lines)
                file_new.close()
                lines=[]
        lines.append(line)
    if len(lines)!=0:
        file_new =open(user_path+u"/last_user.txt",'w')
        file_new.writelines(lines)
        file_new.close()   
        
read_file_split(save_pd_path+u"/sort_userid_data.txt")
    
    