# -*- coding: UTF-8-*-
#encoding= UTF-8
import gensim
import logging
import datetime
import pandas as pd
import numpy as np
import pickle
import os
import re
import operator
from multiprocessing import Pool

save_path= u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/pkl_model" # dic 相关中间参量存储
filepath =u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/userdata" # 简单筛选之后的源文件
key_col =["tm","ctm","itemid","userid","click","title"]
#************************ 数据处理的部分 ***********************
def save_data(dic_list,name):
    ''' save dic data '''
    output = open(save_path+u"/"+name+'.pkl', 'wb')
    pickle.dump(dic_list, output)
    output.close()
def reload_data(name):
    ''' reload dic data '''
    pkl_file = open(save_path+u"/"+name, 'rb')
    data = pickle.load(pkl_file)
    pkl_file.close()
    return data
#****************************单文件生成对应字典代码 start*********************************
def raw_file_check():
    print("read_file")
    filename_list =[]
    names_list =[]
    cnt =0
    for f in os.listdir(filepath):
        if re.search( 'user_2.txt$',f):
            #Index_count(filepath+u"/"+f,cnt)
            print(f)
            filename_list.append(filepath+u"/"+f)
            names_list.append(cnt)
            cnt =cnt+1
    map(Index_count,filename_list,names_list)
    #Video_Index =Dic_Merge()
def Watch_List():
    print("read_file")
    filename_list =[]
    names_list =[]
    cnt =0
    for f in os.listdir(filepath):
        if re.search( 'user_2.txt$',f):
            #Index_count(filepath+u"/"+f,cnt)
            print(f)
            filename_list.append(filepath+u"/"+f)
            names_list.append(cnt)
            cnt =cnt+1
    map(Watch_count,filename_list,names_list)
def Watch_count(fname,cnt_fi):
    # 分文件统计
    # 得到每个item 的 count 和index 用dic 存储
    print("Watch_count")
    pd_df = pd.read_csv(fname,names=key_col,sep='\t')
    pd_item_Index =pd.DataFrame({"itemid":Video_Index.keys(),"itemIndex":Video_Index.values()})
    print("itemid_Index",pd_item_Index.shape)
    pd_result =pd.merge(pd_item_Index,pd_df,on="itemid",how ="inner")
    print(pd_result.columns,pd_result.shape)
    pd_result2 =pd_result[["ctm","userid","itemIndex"]].sort_values("ctm").groupby("userid").aggregate(lambda x: list(x))
    ctm_dic =pd_result2["ctm"].to_dict()
    print("ctm_dic")
    WatchedList_dic = pd_result2["itemIndex"].to_dict()
    print("WatchedList_dic")
    print("save")
    save_data(ctm_dic,str(cnt_fi)+"ctm_Dic")
    save_data(WatchedList_dic,str(cnt_fi)+"WatchedList_Dic2")
    
def Index_count(fname,cnt_fi):
    # 分文件统计
    # 得到每个item 的 count 和index 用dic 存储
    print("Index_count")
    pd_df = pd.read_csv(fname,names=key_col,sep='\t')
    print(pd_df.columns,pd_df.shape)
    Video_count_tmp = pd_df["itemid"].value_counts().to_dict()
    print("Video_count_tmp")
    Video_title_pd =pd_df[["itemid","title"]].drop_duplicates()
    Video_title_pd  =Video_title_pd.set_index('itemid')
    Video_title_tmp =Video_title_pd["title"].to_dict()
    print("Video_title_tmp")
    print("save")
    save_data(Video_count_tmp,str(cnt_fi)+"Video_Count")
    save_data(Video_title_tmp,str(cnt_fi)+"Video_Title")
    print("end")
 #****************************单文件生成对应字典代码 over******************************** 
def Dic_Merge():
    ## merge Video_count and Video_Index
    Video_title2 ={}
    Video_count2 ={}
    Video_Index={}
    Video_count_list=[]
    Video_title_list =[]
    for i in os.listdir(save_path):
        print(i)
        if re.search('Video_Count.pkl$',i):
            Video_count_list.append(reload_data(i))
        if re.search('Video_Title.pkl$',i):
            Video_title_list.append(reload_data(i))
    Video_count =union_dict(Video_count_list,isint =True)
    sorted_Video = sorted(Video_count.iteritems(), key=operator.itemgetter(1),reverse=True)# 按键值排序 降序
    Video_title =reduce(Dic_2_Merge,Video_title_list) 
    for i in range(0,len(sorted_Video)):
        if sorted_Video[i][1]<5: #过滤低频词
            continue 
        Video_Index[sorted_Video[i][0]] =str(i) #编号从1开始
        
    print("替换 Video_title键值")
    for k,v in Video_title.items():
        try:
            Video_title2[Video_Index[k]] =v
        except:
            continue
    print("替换 Video_count的键值")
    for k,v in Video_count.items(): 
        try:
            Video_count2[Video_Index[k]] =v
        except:
            continue
    save_data(Video_title2,"Video_title")
    save_data(Video_Index,"Video_Index")
    save_data(Video_count2,"Video_count")
    return Video_Index
def Dic_2_Merge(dic_1,dic_2):
    '''Video_title 合并'''
    print("合并相加 Dic_2_Merge")
    dic_1 =dict(dic_1, **dic_2)
    return dic_1 
def union_dict(objs,isint=False):
    print("union_dict")
    _keys = set(sum([obj.keys() for obj in objs],[]))
    _total = {}  
    if isint: ##键值是int类型
        for _key in _keys:
            list_key =0
            for obj in objs:
                list_key +=obj.get(_key,0)
            _total[_key]=list_key  
        return _total 
    else:
        for _key in _keys: ##键值是list类型
            list_key =[]
            for obj in objs:
                list_key +=obj.get(_key,[])
            _total[_key]=list_key  
        return _total
    

raw_file_check()
Video_Index =Dic_Merge()
#Video_Index =reload_data("Video_Index.pkl")
Watch_List()