#encoding= UTF-8
import gensim
import logging
import datetime 
import pandas as pd
import numpy as np
import pickle
import os
import re
from sklearn.utils import shuffle
from sklearn import preprocessing
emb_size=256
pre_num =4
window_size =15+pre_num### 截取的视频的长度（avg）  +5取后面的5个视频作为预测相关序列
windows_long =10
windows_short =5
save_path= u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/pkl_model" # dic 相关中间参量存储
save_pd_path = u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/data/skip-1/clean_hot" # 添加 embedding向量AVG之后的数据 分文件存储
save_pd_path_2 = u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/data_not_shuffle/skip-1/avg_2" # 添加 embedding向量AVG之后的数据 分文件存储
##############################pkl 持久存储模块##############################
def save_data(dic_list,name):
    ''' save dic data '''
    output = open(save_path+u"/"+name+'.pkl', 'wb')
    pickle.dump(dic_list, output)
    output.close()
def reload_data(name):
    ''' reload dic data '''
    pkl_file = open(save_path+u"/"+name, 'rb')
    data = pickle.load(pkl_file)
    pkl_file.close()
    return data
##############################切分数据 窗口滑动##############################

def list_watch_embedding(WL,name):
    print("map",name)
    list_watch =[]
    list_predict =[]
    userid =[]
    itemid =[]
    count_list =[]
    item_count_long =[]
    item_count_short =[]
    ctm_label =[]
    bug_num =len(Video_Index) #人为增加了一个虚数 ，对应的embedding向量为len(Video_Index)数量不计入计算范围
    WatchedList_dic_all =reload_data(WL)
    print(WL)
    ctm_Dic =reload_data(WL.replace("WatchedList_Dic2nohot.pkl","")+"ctm_Dic.pkl")
    print(WL[0]+"ctm_Dic.pkl")
    print("count",len(WatchedList_dic_all))
    for k,v in WatchedList_dic_all.items():
        #print("len",len(v))
        if len(v)<=1+pre_num:
            continue
        count =len(v)
        i =0
        j=window_size
        
        while j<=len(v)-1:
            list_watch.append(v[i:j-pre_num])
            item_count_long.append(windows_long)
            item_count_short.append(windows_short)
            itemid.append(v[j-pre_num])
            userid.append(k)
            count_list.append(count)
            list_predict.append(v[j-pre_num:j+1])
            label_t =datetime.datetime.strptime(ctm_Dic[k][j-pre_num], "%Y-%m-%d %H:%M:%S")
            ctm_label.append((Tmax-label_t).seconds) 
            i =i+1
            j =j+1
            count =count-1
        if len(v[i:])<window_size :
            last_line =v[0:len(v)-1-pre_num]
            if len(v[i:])>windows_short+pre_num+1:
                item_count_short.append(windows_short)
                item_count_long.append(len(last_line)-windows_short)
            else:
                item_count_short.append(len(last_line))
                item_count_long.append(10) # 除了之后都是0
            list_bug_num=[]
            for mm in range(len(v),window_size+1): ## 最后一段补齐
                list_bug_num.append(str(bug_num))
            last_line =list_bug_num + last_line
            list_watch.append(last_line)
            itemid.append(v[len(v)-1-pre_num])
            userid.append(k)
            count_list.append(count)
            list_predict.append(v[len(v)-1-pre_num:])
            print(str(ctm_Dic[k][len(v)-1-pre_num]))
            label_t =datetime.datetime.strptime(ctm_Dic[k][len(v)-1-pre_num], "%Y-%m-%d %H:%M:%S")
            ctm_label.append((Tmax-label_t).seconds)
    pd_df =pd.DataFrame(list_watch)
    pd_list_predict =pd.DataFrame(list_predict)
    tmp_item_user =pd.DataFrame({"userid":userid,"itemid":itemid,"countid":count_list,"item_count_long":item_count_long,"item_count_short":item_count_short,"label_age":np.array(ctm_label)})
    pd_df =pd.concat([pd_df,tmp_item_user,pd_list_predict],axis=1)
    #pd_df.to_csv(save_pd_path_2+u"/"+name+"pd_df_not_shuffle.txt",index=False,header=True,sep='\t')
    pd_df =shuffle(pd_df) ## 打乱下顺序
    print("save")
    pd_df.to_csv(save_pd_path+u"/"+name+"pd_df.txt",index=False,header=False,sep='\t')
    ## 最后再去用cat命令合并数据

def read_Dic():
    ### 生成最后的数据
    cnt =0
    list_Wl=[]
    list_name=[]
    for i in os.listdir(save_path):
        if re.search('WatchedList_Dic2nohot.pkl$',i):
                list_Wl.append(i)
                list_name.append(str(cnt))
                cnt =cnt+1
    map(list_watch_embedding,list_Wl,list_name)
#**********************************word2vec训练***************************************
def word2vec():
    sentences =[]
    for i in os.listdir(save_path):
        if re.search('WatchedList_Dic2.pkl$',i):
            Watchlist =reload_data(i)
            print("i.values()",len(Watchlist.values()))
            sentences =sentences+Watchlist.values()
    print("word2vec")
    ## 把语句存储起来
    print("sentences",len(sentences))
    model =gensim.models.Word2Vec(sentences,min_count=5,size=emb_size)
    vector_item =model.wv
    save_data(vector_item,"vector_item")
    
def word2vec_1():
    sentences =[]
    f=open("watch_list.txt","w")
    for i in os.listdir(save_path):
        if re.search('WatchedList_Dic2.pkl$',i):
            Watchlist =reload_data(i)
            print("i.values()",len(Watchlist.values()))
            sentences =sentences+Watchlist.values()
            for item in Watchlist.values():
                f.write(" ".join(item))
                f.write(u"\n")
    f.close()
    print("is over")    
#***************生成对应 vector 向量**************
def vec_item_pd():
    print("vector_item")
    vec_item = gensim.models.KeyedVectors.load_word2vec_format(save_path+u'/vector256.bin', binary=True)
    print("Video_Index")
    Video_Index =reload_data("Video_Index.pkl")
    count =len(Video_Index)
    result =[]
    for i in range(count+1):
        try:
            result.append(vec_item[str(i)])
        except:
            result.append([0 for i in range(emb_size)])
    pd_df =pd.DataFrame(np.array(result))
    
    pd_df.to_csv(save_pd_path+u"/1vec_item.txt",index=False,header=False,sep=' ')


Tmax =datetime.datetime.strptime("2017-08-01 00:00:00", "%Y-%m-%d %H:%M:%S")  
Video_Index =reload_data("Video_Index.pkl")
#word2vec_1()
read_Dic()
#word2vec()
#vec_item_pd()