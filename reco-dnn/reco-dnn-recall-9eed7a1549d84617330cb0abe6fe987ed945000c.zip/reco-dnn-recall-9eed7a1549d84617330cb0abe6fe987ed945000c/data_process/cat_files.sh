#!/bin/sh
cd /data/raw
#awk 输出文件
cd ~/myproject/reco-dnn/gitcode/caorong/raw-data
# cat merge
cat *data.txt >merge_data.txt
#sort  按userid 排序
sort -f -k 4 -t $'\t' merge_data.txt  >sort_userid_data.txt

#**********************对所有用户数据清洗
awk -F '\t' '$2>"2017-07-25 00:00:00", $2<"2017-08-01 00:00:00"' 1user.txt  >1user_2.txt

#******************执行完data_produce 再合并成大文件****************
cd ~/myproject/reco-dnn/gitcode/caorong/data
cat *pd_df.txt >train_all.txt

##*****************筛选数据******************************
awk '$16<200' train_all.txt >train_2.txt
#**************求age 的mean 和var 值*********************
awk '{print $16}' data.txt >age.txt
#*************处理数据 筛掉小于 2017-07-24 00:00:00 和 大于 2017-08-01 00:00:00的数据
#*************对比看 筛掉相关数据之后的大小
awk -F '\t' '$21>"2017-07-24 00:00:00"' data.txt >data_1.txt
awk -F '\t' '$21<"2017-08-01 00:00:00"' data_1.txt >data_2.txt

#********************************处理rank的数据************************
awk -F '\t' '$36>"2017-07-25 00:00:00",$36<"2017-08-01 00:00:00"' merge_log.txt* > /home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/raw-data_rank/test.txt
