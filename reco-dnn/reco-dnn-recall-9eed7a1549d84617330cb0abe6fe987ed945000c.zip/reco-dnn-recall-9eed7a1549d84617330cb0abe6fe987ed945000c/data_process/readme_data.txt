clean_raw_data.py: 清理原始数据
