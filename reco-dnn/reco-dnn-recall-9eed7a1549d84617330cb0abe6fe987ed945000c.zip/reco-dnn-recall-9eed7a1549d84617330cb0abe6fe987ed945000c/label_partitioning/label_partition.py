import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.cluster import MiniBatchKMeans

save_pd_path = u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/data/skip-1/avg_2" # 向量AVG之后的数据
def label_partition(X,K=2000):
    '''用k-means聚类
    X:输入的数据
    K:分割的聚类类别个数 partition个数
    returns: 返回Kmeans model'''
    kmeans_model = KMeans(n_clusters=K, random_state=0).fit(X)
    return kmeans_model # 返回kmeans_model

def partition_assignment(X_partiton,C =250,k=15):
    '''训练partition assignment 得到每个partition中的前C个最关联的labels 再给出在C个里面计算的top k的值
    X_patition：分到partition 的X
    C:每一个partition中的labels中应该有的个数
    k:最后结果的top k,影响优化函数'''
    rank_part =Rank(X_partition)
    
def Rank(X_partiton):
    '''利用DNN 计算模型，可以算X_partition中每一个example的Rank值
    X_partition:分到partition中的X
    returns:每个example比自己实际的label排名高的所有labels的排名'''
    # 计算Re = X_partition*sm_w.T+sm_b