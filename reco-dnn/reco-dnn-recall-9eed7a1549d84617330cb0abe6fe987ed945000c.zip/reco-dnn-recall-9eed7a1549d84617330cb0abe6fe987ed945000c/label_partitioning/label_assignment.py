# -*- coding: utf-8 -*-
import numpy as np
from numpy.linalg import cholesky
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import tensorflow as tf
from random import choice, shuffle
from numpy import array
save_pd_path = u"/home/freelyblue.cr/myproject/reco-dnn/gitcode/caorong/data/skip-2/parttion" # 添加 embedding向量AVG之后的
def assign_label_loss(labels,rank,alpha,k=15):
    '''使用tensorflow
    labels:partition中的实际label[labels_num]
    rank:每条记录在所有video上的排名，形如[234,231,...,231] 里面对应的Video_ID,然后所在的数组位置即为排名[labels_nums,Video_ID]
    alpha:每个Video是否属于该partition的概率,取值控制在(0,1)之间[0.1,0.2,...,] 数组位置为第i个视频，值为概率 [Video_ID]
    k：目标是取到top k'''
    
def pre_rank(labels,rank_all,partname):
    ## 事先存储好每一个label的rank 值和在这个label之前的rank值
    # labels 一维数组
    # rank_all 二维数组
    bug_num =len(Video_title) ## 填充num 
    label_rank =[]
    rank_front_label =[]
    for i in range(len(labels)):
        # 找到对应的label的rank的位置
        pos =rank_all[i].where(labels[i])
        label_rank.append(pos)
        # 找到排在前面的labels
        rank_front_label=rank_all[i][:pos[0]]
    pd_rank_part =pd.DataFrame(rank_front_label)
    pd_rank_part.fillna(bug_num)
    pd_label_rank_part =pd.DataFrame(label_rank)
    pd_label_rank_part.to_csv(save_pd_path+u"/"+partname+"label_rank.txt",index=False,header=False,sep='\t')
    pd_rank_part.to_csv(save_pd_path+u"/"+partname+"rank.txt",index=False,header=False,sep='\t')
    
def train(Num_partition):
    # Num_partition 一个partition里面聚类之后的examples 数目
    item_count =len(Video_title)
    alpha =tf.Variable(tf.random_normal([item_count])) ## 随机初始化
    labels =tf.placeholder(tf.int64, shape=[Num_partition],name ="labels")
    rank =tf.placeholder(tf.int64, shape=[Num_partition,item_count],name ="Rank_num")
    
    
    