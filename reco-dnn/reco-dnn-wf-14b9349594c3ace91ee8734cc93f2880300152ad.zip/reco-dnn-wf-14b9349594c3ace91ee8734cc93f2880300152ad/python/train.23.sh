FEATURE_DATE='20170906'
VERSION='23'
odpscmd -e "pai -name tensorflow
-Dscript='file:///home/wangfei01/git/reco-dnn/python/train.${VERSION}.py' 
-Dtables='odps://tdalg/tables/ads_up_dnn_device_model_emb_d/ds=${FEATURE_DATE},odps://tdalg/tables/ads_up_dnn_recall_feature_d/ds=${FEATURE_DATE}/type=train,odps://tdalg/tables/ads_up_dnn_recall_feature_d/ds=${FEATURE_DATE}/type=validate,odps://tdalg/tables/ads_up_dnn_item_emb_d/ds=${FEATURE_DATE}' 
-Doutputs='odps://tdalg/tables/ads_up_dnn_recall_predict_d/ds=${FEATURE_DATE}/type=validate' 
-Dbuckets='oss://up-tf/?host=oss-cn-hangzhou-zmf.aliyuncs.com&role_arn=acs:ram::1101095605178671:role/up-tf-role' 
-DcheckpointDir='oss://up-tf/?host=oss-cn-hangzhou-zmf.aliyuncs.com&role_arn=acs:ram::1101095605178671:role/up-tf-role';" > train.${VERSION}.log 2>&1
