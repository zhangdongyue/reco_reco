#!/bin/python
# Generate video embedding data.
import tensorflow as tf
from collections import Counter
import re
import numpy as np
import math
import os
import time

flags = tf.app.flags

flags.DEFINE_string("tables",'',"odps train table")

flags.DEFINE_string(
    "eval_data", None, "File consisting of analogies of four tokens."
    "embedding 2 - embedding 1 + embedding 3 should be close "
    "to embedding 4."
    "See README.md for how to get 'questions-words.txt'.")
flags.DEFINE_integer(
    "epochs_to_train", 15,
    "Number of epochs to train. Each epoch processes the training data once "
    "completely.")
flags.DEFINE_float("learning_rate", 0.0002, "Initial learning rate.")
flags.DEFINE_integer("num_neg_samples", 1000,
                    "Negative samples per training example.")
flags.DEFINE_integer("batch_size", 256,
                     "Number of training examples processed per step "
                     "(size of a minibatch).")
flags.DEFINE_integer("max_train_steps", 2000,
                     "The max train steps.")
flags.DEFINE_integer("window_size", 3,
                     "The number of words to predict to the left and right "
                     "of the target word.")
flags.DEFINE_integer("min_count", 0,
                     "The minimum number of word occurrences for it to be "
                     "included in the vocabulary.")
flags.DEFINE_float("subsample", 1e-3,
                   "Subsample threshold for word occurrence. Words that appear "
                   "with higher frequency will be randomly down-sampled. Set "
                   "to 0 to disable.")
flags.DEFINE_integer("statistics_interval", 5,
                     "Print statistics every n seconds.")
flags.DEFINE_integer("summary_interval", 5,
                     "Save training summary to file every n seconds (rounded "
                     "up to statistics interval).")
flags.DEFINE_integer("checkpoint_interval", 600,
                     "Checkpoint the model (i.e. save the parameters) every n "
                     "seconds (rounded up to statistics interval).")

flags.DEFINE_integer("embedding_size",256,"size of embedding vector dimension")
flags.DEFINE_string('date','20170901','')
flags.DEFINE_string('train_feature_table',\
'odps://tdalg/tables/ads_up_dnn_recall_feature_d/ds=${date}/type=train',"training feature odps table.")
flags.DEFINE_string('validate_feature_table',\
'odps://tdalg/tables/ads_up_dnn_recall_feature_d/ds=${date}/type=validate',"training feature odps table.")
flags.DEFINE_string('validate_predict_table',\
'odps://tdalg/tables/ads_up_dnn_recall_predict_d/ds=${date}/type=validate',"training feature odps table.")
flags.DEFINE_string('test_feature_table',\
'odps://tdalg/tables/ads_up_dnn_recall_feature_d/ds=${date}/type=test',"training feature odps table.")
flags.DEFINE_string('test_predict_table',\
'odps://tdalg/tables/ads_up_dnn_recall_predict_d/ds=${date}/type=test',"training feature odps table.")
flags.DEFINE_string('feature_path','../data/feature.csv',"training feature file.")
flags.DEFINE_string("device_emb_table",\
"odps://tdalg/tables/ads_up_device_vector_model","device embedding table.")
flags.DEFINE_string("device_emb_path","../data/device.csv","device embedding file.")
flags.DEFINE_integer("device_emb_dim",128,"dimession of deivce embedding")
flags.DEFINE_string("item_emb_table",\
"odps://tdalg/tables/ads_up_dnn_item_emb_d/ds=${date}","odps table of items.")
flags.DEFINE_string("item_emb_path","../data/item.csv","items embedding file")
flags.DEFINE_integer("item_emb_dim",256,"dimession of items embedding.")
flags.DEFINE_integer("watch_seq_window_size",50,"dimession of items embedding.")
flags.DEFINE_integer("num_threads",3,"dimession of items embedding.")
flags.DEFINE_integer("queue_capacity",1000,"batch queue capacity.")
flags.DEFINE_string("seq_splitter","`","splitter of seq")
flags.DEFINE_string("model_path","/home/wangfei01/tensorflow/model/dnn_reco.ckpt",\
                "model saving path.")
flags.DEFINE_string("model_name", "", "model name")
flags.DEFINE_string("buckets", "", "read oss info")
flags.DEFINE_string("checkpointDir", "", "write oss info")
FLAGS = flags.FLAGS

class Options(object):
  """Options used by our word2vec model."""
  def __init__(self):
    # Model options.
    self.tables = FLAGS.tables
    self.seq_splitter = FLAGS.seq_splitter
    # Embedding dimension.
    self.emb_dim = FLAGS.embedding_size
    # Training options.
    # Number of negative samples per example.
    self.num_neg_samples = FLAGS.num_neg_samples
    # The initial learning rate.
    self.learning_rate = FLAGS.learning_rate
    # Number of epochs to train. After these many epochs, the learning
    # rate decays linearly to zero and the training stops.
    self.epochs_to_train = FLAGS.epochs_to_train
    # Max training steps.
    self.max_train_steps = FLAGS.max_train_steps
    # Number of examples for one training step.
    self.batch_size = FLAGS.batch_size
    # The number of words to predict to the left and right of the target word.
    self.window_size = FLAGS.window_size
    # The minimum number of word occurrences for it to be included in the
    # vocabulary.
    self.min_count = FLAGS.min_count
    # Subsampling threshold for word occurrence.
    self.subsample = FLAGS.subsample
    # How often to print statistics.
    self.statistics_interval = FLAGS.statistics_interval
    # How often to write to the summary file (rounds up to the nearest
    # statistics_interval).
    self.summary_interval = FLAGS.summary_interval
    # How often to write checkpoints (rounds up to the nearest statistics
    # interval).
    self.checkpoint_interval = FLAGS.checkpoint_interval
    # Where to save the model.
    self.model_path = FLAGS.model_path
    # Eval options.
    # The text file for eval.
    self.eval_data = FLAGS.eval_data
    # Device embedding odps table
    self.device_emb_table = FLAGS.device_emb_table
    self.device_emb_path = FLAGS.device_emb_path
    # dimession of the user device embedding
    self.device_emb_dim = FLAGS.device_emb_dim
    # Train data feature table
    self.train_feature_table = FLAGS.train_feature_table
    self.validate_feature_table = FLAGS.validate_feature_table
    self.validate_predict_table = FLAGS.validate_predict_table
    self.test_feature_table = FLAGS.test_feature_table
    self.test_predict_table = FLAGS.test_predict_table 
    self.feature_path = FLAGS.feature_path
    # Video item embedding odps table.
    self.item_emb_table = FLAGS.item_emb_table
    self.item_emb_path = FLAGS.item_emb_path
    # Video item embedding dimession
    self.item_emb_dim = FLAGS.item_emb_dim
    # Watch sequence window size
    self.watch_seq_window_size = FLAGS.watch_seq_window_size 
    # Number of threads of creating batch input.
    self.num_threads = FLAGS.num_threads
    # Capacity of queue
    self.queue_capacity = FLAGS.queue_capacity
    # OSS bucket
    self.buckets = FLAGS.buckets
    self.checkpoint_dir = FLAGS.checkpointDir
    # Date of the feature data
    self.date = FLAGS.date
    # Model name
    self.model_name = FLAGS.model_name

def odps_pipeline(table_name,num_epochs=None):
  if num_epochs is None:
    data_queue = tf.train.string_input_producer([table_name])
  else:
    data_queue = tf.train.string_input_producer([table_name],num_epochs)
  reader = tf.TableRecordReader()
  key,value = reader.read(data_queue)
  return value

def file_pipeline(table_name,num_epochs=None):
  if num_epochs is None:
    data_queue = tf.train.string_input_producer([table_name])
  else:
    data_queue = tf.train.string_input_producer([table_name],num_epochs=1)
  reader = tf.TextLineReader()
  key,value = reader.read(data_queue)
  return value

class Embedding(object):
  def __init__(self,tensor_name,table_name,dim,is_item=False):
    self._dim = dim
    self._tensor_name = tensor_name
    if not is_item:
      self._table_name = table_name
      self._id2word,self._embedding = self.load_odps_embedding()
    else:
      self._table_name = table_name 
      self._id2word,self._id2title,self._embedding = self.load_item_embedding()
    self._size = len(self._id2word)
      
  def decode_item_seq(self,sequence):
    title_list = [str(seq) + ' ' +self._id2title[int(seq)] for seq in sequence]
    return '\n'.join(title_list)
    
  def load_file_embedding(self,path):
    embedding = []
    id2word = []
    word2id= {}
    id2word.append('None')
    embedding.append([0] * self._dim)
    line = file_pipeline(path,1)
    with tf.Session() as sess:
      sess.run(tf.local_variables_initializer())
      coord = tf.train.Coordinator()
      threads = tf.train.start_queue_runners(sess=sess,coord=coord)
      try:
        while not coord.should_stop():
          embedding_raw = sess.run(line)  
          embedding_tokens = embedding_raw.split(',')
          id2word.append(embedding_tokens[0])
          embedding.append([float(token) for token in embedding_tokens[1:self._dim+1]])
      except tf.errors.OutOfRangeError:
        print('finish reading the embedding data:%s' % (self._path))
      coord.request_stop()
      coord.join(threads)
      sess.close() 
    word2id = dict([(word,i) for i,word in enumerate(id2word)])
    return word2id,id2word,embedding

  def load_item_embedding(self):
    embedding = []
    id2word = []
    id2title = []
    id2word.append('None')
    id2title.append('None')
    embedding.append([0] * self._dim)
    line = odps_pipeline(self._table_name,1)
    with tf.Session() as sess:
      sess.run(tf.local_variables_initializer())
      coord = tf.train.Coordinator()
      threads = tf.train.start_queue_runners(sess=sess,coord=coord)
      try:
        while not coord.should_stop():
          embedding_raw = sess.run(line)  
          embedding_tokens = embedding_raw.split(',')
          indice = int(embedding_tokens[0])
          prob = embedding_tokens[1]
          word = embedding_tokens[2]
          title = embedding_tokens[3]
          id2word.insert(indice,word)
          id2title.insert(indice,title)
          embedding.insert(indice,[float(token) for token in embedding_tokens[4:self._dim + 4]])
      except tf.errors.OutOfRangeError:
        print('finish reading the embedding data:%s' % (self._table_name))
      coord.request_stop()
      coord.join(threads)
      sess.close() 
    return id2word,id2title,embedding
    
  def load_odps_embedding(self):
    embedding = []
    id2word = []
    id2word.append('None')
    embedding.append([0] * self._dim)
    line = odps_pipeline(self._table_name,1)
    with tf.Session() as sess:
      sess.run(tf.local_variables_initializer())
      coord = tf.train.Coordinator()
      threads = tf.train.start_queue_runners(sess=sess,coord=coord)
      try:
        while not coord.should_stop():
          embedding_raw = sess.run(line)  
          embedding_tokens = embedding_raw.split(',')
          indice = int(embedding_tokens[0])
          word = embedding_tokens[1]
          id2word.insert(indice,word)
          embedding.insert(indice,[float(token) for token in embedding_tokens[2:self._dim + 2]])
      except tf.errors.OutOfRangeError:
        print('finish reading the embedding data:%s' % (self._table_name))
      coord.request_stop()
      coord.join(threads)
      sess.close() 
    return id2word,embedding
    
  def embedding_tensor(self):
    init_emb = tf.constant(self._embedding)
    #with tf.variable_scope('embedding'):
      #self._tensor = tf.get_variable(self._tensor_name,initializer=init_emb) 
      #self._tensor = tf.Variable(self._embedding,[self._size,self._dim],name=self._tensor_name)
    self._tensor = tf.constant(self._embedding,shape=[self._size,self._dim])
    return self._tensor 

class Feature(object):
  def __init__(self,options):
    self._options = options 
    #self._device_emb = Embedding('device',options.device_emb_table,options.device_emb_dim)
    item_emb_table = options.item_emb_table.replace('${date}',options.date)
    self._item_emb = Embedding('item',item_emb_table,options.item_emb_dim,True)

  def embedding_avg_tensor(self,emb_dict,indices):
    embeddings = tf.nn.embedding_lookup(emb_dict,indices) 
    #nonzero_count = tf.count_nonzero(indices,1)
    #nonzero_emb_count = tf.cast(tf.reshape(nonzero_count,[-1,1]),tf.float32)
    #sum_emb = tf.reduce_sum(embeddings,axis=1)
    #avg_emb = tf.divide(sum_emb,nonzero_emb_count) 
    avg_emb = tf.reduce_mean(embeddings,axis=0)
    return avg_emb 
    
  def parse_seq(self,seq_feature,width,splitter):
    seq_split = tf.string_split([seq_feature],splitter)
    seq_dense = tf.sparse_tensor_to_dense(seq_split,default_value='0')
    seq_flat = tf.reshape(seq_dense,[width])
    return seq_flat
    
    
  def build_inputs(self,path,batch_size,label_size=1,epochs=None,local=False):
    opts = self._options
    emb_item = self._item_emb.embedding_tensor()
    features = odps_pipeline(path,epochs)
    # Todo:Add more feature column
    record_defaults = [['0'],['0'],['0'],['0'],['0']]
    user_id,label,device,watch_seq,example_age = tf.decode_csv(features,record_defaults=record_defaults)
    # User next watch label.
    label_seq_split = self.parse_seq(label,label_size,'`')
    label_ids = tf.string_to_number(label_seq_split,tf.int32)
    #label_ids = tf.reshape(tf.string_to_number(label,tf.int32),[label_size])
    # Watch Seq feature
    watch_seq_split = self.parse_seq(watch_seq,opts.watch_seq_window_size,'`')
    watch_ids = tf.string_to_number(watch_seq_split,tf.int32)
    watch_emb = self.embedding_avg_tensor(emb_item,watch_ids)
    
    example_age_value = tf.reshape(tf.string_to_number(example_age,tf.float32),[1])
    
    batch_user,batch_label,batch_watch_ids,batch_watch_emb,batch_example_age =\
                        tf.train.batch([user_id,label_ids,watch_ids,\
                        watch_emb,example_age_value],\
                        batch_size=batch_size,num_threads=opts.num_threads,\
                        capacity=opts.queue_capacity)

    #emb_device = self._device_emb.embedding_tensor()
    #devices = tf.reshape(tf.string_to_number(batch_device,tf.int32),[-1,1])
    #device_input = self.embedding_avg_tensor(emb_device,devices)
    
    batch_input = batch_watch_emb 
    probe = batch_watch_ids
    inputs_width = self._item_emb._dim
    return probe,batch_user,inputs_width,batch_input,batch_label

class RecoEstimator(object):
  
  def __init__(self,options):
    self._options = options
    self._features = Feature(options)

  def inference(self,model_path):
    opts = self._options
    # The local mark means loading data from local disk.
    train_path = opts.train_feature_table.replace('${date}',opts.date)
    print('training path is :%s' % (train_path))
    probe,users,width,features,labels = \
            self._features.build_inputs(train_path,batch_size=opts.batch_size)
    # Create relu netword.
    #softmax_inputs = self.add_relu_layer(features,width)
    layer1_width = 512
    layer2_width = 256
    #layer1 = self.add_norm_layer(features,width,layer1_width,'layer1')
    layer2 = self.add_norm_layer(features,width,layer2_width,'layer2')
    # Add softmax output.
    softmax_weight,softmax_bias = self.add_softmax_output()
    # Create the NCE loss
    num_labels = self._features._item_emb._size 
    print('num of labels is :%d' % (num_labels))
    num_neg_samples = opts.num_neg_samples
    print('negative sample size is : %d' % (num_neg_samples))
    loss = tf.nn.sampled_softmax_loss(softmax_weight,softmax_bias,\
                          labels,layer2,num_sampled=num_neg_samples,\
                          num_classes=num_labels)
    # Use AdamOptimizer.
    optimizer = tf.train.AdamOptimizer(learning_rate=opts.learning_rate).minimize(loss)
    avg_loss = tf.reduce_mean(loss,axis=0)
    # Create softmax predict result
    predictions = tf.nn.softmax(
          tf.add(tf.matmul(layer2,softmax_weight,transpose_b=True),softmax_bias))
    top_labels = tf.nn.top_k(predictions,15)
    check_op = tf.add_check_numerics_ops()
    # Add ops to save and restore all the variables.
    saver = tf.train.Saver()
    with tf.Session() as sess:
      sess.run(tf.local_variables_initializer())
      sess.run(tf.global_variables_initializer()) 
      coord = tf.train.Coordinator() 
      threads = tf.train.start_queue_runners(sess=sess,coord=coord)
      step = 0
      prev_loss = 0
      total_loss = 0
      improv = 100.0
      while not coord.should_stop() and step < opts.max_train_steps:
        try:
          result = sess.run([avg_loss,labels,layer2,loss,optimizer])
          #check = sess.run(check_op)
          total_loss += result[0] 
          step += 1
          if (step % 1000) == 0:
            improv = abs(prev_loss-total_loss) / 1000
            prev_loss = total_loss
            predict = sess.run([features,layer2,probe,top_labels])
            for i in range(0,10):
              print('\nwatch seq is:********************************')
              print(self._features._item_emb.decode_item_seq(predict[2][i]))
              print('predict is :>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
              print(self._features._item_emb.decode_item_seq(predict[3][1][i]))
            print('step:%d,total loss:%f,loss:%f' % (step,total_loss,total_loss / 1000 ))
            total_loss = 0
        except tf.errors.OutOfRangeError as e:
          print('Exhausted the training data.')
          coord.request_stop()
          coord.join(threads)
        except Exception as e:
          print('-------------------------------------------------')
          print(e)
          print(str(result[2][0]))
      saver.save(sess,model_path)
      print('The model is inferenced and saved')
      sess.close()
  
  def metric(self,model_path):
    tf.reset_default_graph()
    opts = self._options
    # The local mark means loading data from local disk.
    train_path = opts.validate_feature_table.replace('${date}',opts.date)
    probe,users,width,features,labels = \
            self._features.build_inputs(train_path,batch_size=opts.batch_size,label_size=5)
    # Create relu netword.
    #softmax_inputs = self.add_relu_layer(features,width)
    layer1_width = 512
    layer2_width = 256
    #layer1 = self.add_norm_layer(features,width,layer1_width,'layer1')
    layer2 = self.add_norm_layer(features,width,layer2_width,'layer2')
    # Add softmax output.
    softmax_weight,softmax_bias = self.add_softmax_output()
    num_labels = self._features._item_emb._size 
    print('num of labels is :%d' % (num_labels))
    # Create softmax predict result
    predictions = tf.nn.softmax(
          tf.add(tf.matmul(layer2,softmax_weight,transpose_b=True),softmax_bias))
    values,indices = tf.nn.top_k(predictions,100)
    mean_average_precision,map_op = tf.contrib.metrics.\
        streaming_sparse_average_precision_at_top_k(indices,tf.cast(labels,dtype=tf.int64))
    # Add ops to save and restore all the variables.
    saver = tf.train.Saver()
    with tf.Session() as sess:
      saver.restore(sess,model_path)
      print('restore model from:%s' % (model_path))
      sess.run(tf.local_variables_initializer())
      coord = tf.train.Coordinator() 
      threads = tf.train.start_queue_runners(sess=sess,coord=coord)
      step = 0
      while not coord.should_stop() and step < opts.max_train_steps:
        try:
          result = sess.run(map_op)
          if step % 1000 == 0:
            print('batch average precision is : %f' % (result))
          step += 1
        except tf.errors.OutOfRangeError as e:
          print('Exhausted the training data.')
          coord.request_stop()
          coord.join(threads)
      mean_ap = sess.run(mean_average_precision)
      print('mean average precision is: %f' % (mean_ap))
      sess.close()
    
  def predict(self):
    opts = self._options
    tf.reset_default_graph()
    # The local mark means loading data from local disk.
    validate_path = opts.validate_feature_table.replace('${date}',opts.date)
    user,width,features,labels = self._features.build_inputs(validate_path,batch_size=1,epochs=1)
    # Create relu netword.
    #softmax_inputs = self.add_relu_layer(features,width)
    layer1_width = 1024
    layer2_width = 256
    layer1 = self.add_norm_layer(features,width,layer1_width,'layer1',False)
    layer2 = self.add_norm_layer(layer1,layer1_width,layer2_width,'layer2',False)
    # Add softmax output.
    softmax_weight,softmax_bias = self.add_softmax_output()
    # Create softmax predict result
    predictions = tf.nn.softmax(
          tf.add(tf.matmul(layer2,softmax_weight,transpose_b=True),softmax_bias))
    top_labels = tf.nn.top_k(predictions,100).indices
    
    predict_path = opts.validate_predict_table.replace('${date}',opts.date)
    writer = tf.TableRecordWriter(predict_path)
    feature_string = tf.string_join(tf.unstack(tf.as_string(tf.reshape(layer2,[-1]))),' ')
    label_string = tf.as_string(labels)
    top_label_string = tf.string_join(tf.unstack(tf.as_string(tf.reshape(top_labels,[-1]))),' ')
    write_predict = writer.write([0,1,2,3],[user,feature_string,label_string,top_label_string])
    close_writer = writer.close()
    saver = tf.train.Saver()
    ckp_path = os.path.join(opts.buckets, "model.ckpt")
    with tf.Session() as sess:
      saver.restore(sess,ckp_path)
      print('restore model from:%s' % (ckp_path))
      sess.run(tf.local_variables_initializer())
      sess.run(tf.global_variables_initializer()) 
      coord = tf.train.Coordinator()
      threads = tf.train.start_queue_runners(sess=sess,coord=coord)
      try:
       step = 0
       while not coord.should_stop() and step < 1000:
        sess.run(write_predict)
        step += 1
        if step % 100 == 0:
          print('validate step:%d' % (step))
      except tf.errors.OutOfRangeError as e:
        print('Exhausted the validate data.')
      finally:
       sess.run(close_writer)
       coord.request_stop()
       coord.join(threads)
       sess.close()

  def add_softmax_output(self):
    opts = self._options
    num_labels = self._features._item_emb._size 
    with tf.variable_scope('softmax'):
      # Create the softmax embedding matrix. 
      # The embedding matrix is weights of the sofmax output layer.
      softmax_weight = tf.get_variable('weight',\
                       shape=[num_labels,opts.emb_dim],\
                       initializer=tf.truncated_normal_initializer)
      softmax_bias = tf.get_variable('bias',shape=[num_labels],initializer=tf.zeros_initializer)
      print('The softmax weight shape is [%d,%d]' % (num_labels,opts.emb_dim))
      print('The softmax bias shape is [%d]' % (num_labels))
    return softmax_weight,softmax_bias
  
  def add_norm_layer(self,inputs,width_input,width_output,scope_name,is_training=True):
    with tf.variable_scope(scope_name):
      layer = tf.contrib.layers.fully_connected(inputs,width_output,\
                         activation_fn=None,scope='layer')
      bn = tf.contrib.layers.batch_norm(layer,center=True,scale=True,\
                          is_training=is_training,scope='bn')
      relu = tf.nn.elu(bn)
      return relu

  def add_relu_layer(self,input,width_input):
    '''
    The inputs shape is [batch_size,width_input]
    '''
    print('The input layer width is: %d' % (width_input))
    with tf.variable_scope('relu'):
      with tf.variable_scope('layer1'):
        width_layer1 = 1024 

        weight_layer1 = tf.get_variable('weight',\
                          shape=[width_input,width_layer1],\
                          initializer=tf.truncated_normal_initializer())
        bias_layer1 =  tf.get_variable('bias',\
                          shape=[width_layer1],\
                          initializer=tf.zeros_initializer)
        with tf.variable_scope('batch_norm'):
          scale_layer1 = tf.get_variable('scale',shape=[width_layer1],\
                          initializer=tf.ones_initializer)
          offset_layer1= tf.get_variable('offset',shape=[width_layer1],\
                          initializer=tf.zeros_initializer)
        print('Add layer1 weight shape is [%d,%d]' % (width_input,width_layer1))
      with tf.variable_scope('layer2'):
        width_layer2 = 256 
        weight_layer2 = tf.get_variable('weight',\
                          shape=[width_layer1,width_layer2],\
                          initializer=tf.truncated_normal_initializer())
        bias_layer2 =  tf.get_variable('bias',\
                          shape=[width_layer2],\
                          initializer=tf.zeros_initializer)
        with tf.variable_scope('batch_norm'):
          scale_layer2 = tf.get_variable('scale',shape=[width_layer2],\
                          initializer=tf.ones_initializer)
          offset_layer2= tf.get_variable('offset',shape=[width_layer2],\
                          initializer=tf.zeros_initializer)
        print('Add layer2 weight shape is [%d,%d]' % (width_layer1,width_layer2))

    epsilon = 0.001
    # layer1:shape is [batch_size,width_layer1]
    input_layer1 = tf.add(tf.matmul(input,weight_layer1),bias_layer1)
    activ_layer1 = tf.nn.relu(input_layer1,name='relu_layer1') 
    mean_layer1,var_layer1 = tf.nn.moments(activ_layer1,[0])
    norm_layer1 = tf.nn.batch_normalization(activ_layer1, mean_layer1, var_layer1,\
                               offset_layer1, scale_layer1,epsilon)
    input_layer2 = tf.add(tf.matmul(norm_layer1,weight_layer2),bias_layer2)
    activ_layer2 = tf.nn.relu(input_layer2,name='relu_layer2')
    mean_layer2,var_layer2 = tf.nn.moments(activ_layer2,[0])
    norm_layer2 = tf.nn.batch_normalization(activ_layer2, mean_layer2, var_layer2,\
                               offset_layer2, scale_layer2,epsilon)
    return norm_layer2
    
if __name__ == '__main__':
  opts = Options()
  model_name = '1504524733.ckpt'
  print('Passed in path:%s/%s' % (opts.buckets,model_name))
  ckp_path = os.path.join(opts.checkpoint_dir,model_name)
  print('Model save path:%s' % (ckp_path))
  estimator = RecoEstimator(opts)
  #estimator.inference(ckp_path)
  estimator.metric(ckp_path)
