#!/bin/sh
#****************************************************************#
# ScriptName: process_data.sh
# Author: $SHTERM_REAL_USER@alibaba-inc.com
# Create Date: 2017-08-08 16:05
# Modify Author: $SHTERM_REAL_USER@alibaba-inc.com
# Modify Date: 2017-08-08 16:05
# Function: 
#***************************************************************#
for file in $(ls /data/raw/)
do
	    cat $file|awk -F '\t' '$11>5 && $36>$1 && $36>"2017-01-01 00:00:00" {print $36,$10,$4,$11}'|sort>>/home/paisen.gw/sorted_data.txt
	done
