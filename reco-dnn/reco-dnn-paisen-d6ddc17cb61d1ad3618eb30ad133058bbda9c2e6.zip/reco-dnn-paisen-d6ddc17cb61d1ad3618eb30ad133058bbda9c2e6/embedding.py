import word2vec
word2vec.word2vec('/home/paisen.gw/process_data/final.txt','/home/paisen.gw/process_data/vector.bin',size=128, verbose=True)
