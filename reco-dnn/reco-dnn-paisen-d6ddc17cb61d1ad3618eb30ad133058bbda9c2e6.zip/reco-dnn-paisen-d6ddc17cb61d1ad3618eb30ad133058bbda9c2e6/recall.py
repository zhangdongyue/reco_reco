# -*- coding:utf-8 -*- 
from __future__ import absolute_import
from __future__ import print_function

import collections
import math
import os
import random
import re
import json
from itertools import compress
import pickle
import word2vec

import numpy as np
import tensorflow as tf
tf.GraphKeys.VARIABLES = tf.GraphKeys.GLOBAL_VARIABLES
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.metrics.pairwise import pairwise_distances


# Set random seeds
SEED = 2017
random.seed(SEED)
np.random.seed(SEED)
index_file = '/home/paisen.gw/process_data/index_dict.pkl'
reversed_file = '/home/paisen.gw/process_data/reversed_dictionary.pkl'
watch_file = '/home/paisen.gw/process_data/final.txt'
vector_file = '/home/paisen.gw/process_data/vector.bin'
title_pairfile= '/home/paisen.gw/process_data/titlepair.pkl'
count_file='/home/paisen.gw/process_data/count.pkl'

def build_dataset(index_file,reversed_file,watch_file, vector_file,title_pairfile,count_file,sample):
    s = open(index_file,'r')
    dictionary = pickle.load(s)
    s.close()
    print('dictionart finish')
    s1 = open(reversed_file, 'r')
    rev = pickle.load(s1)
    s1.close()
    print('reversed finish')
    model = word2vec.load(vector_file)
    embeding = []
    for i in model.vocab:
        embeding.append(model[i])
    embeding[0]=[0]*128
    s2 = open(count_file,'r')
    count= pickle.load(s2)
    s2.close()
    count_prob={}
    sum=0.0
    for i in count:
        sum+=i[1]
    for i in count:
        tmp=i[1]/sum
        #print(tmp)
        if tmp >0.0:
            prob=sample/tmp+math.sqrt(sample/tmp)
        else:
            prob=1.2
        count_prob[i[0]]=prob
    print('prob finish')
    f = open(watch_file, 'r')
    word=[]
    unk=0
    known=0
    discard=0
    for line in f:
        a = np.zeros(128)
        count = 0
        line = line.strip().split(' ')
        usr = []
        for video_id in line:
            if video_id not in model:
                unk+=1
                continue
            known+=1
            if np.random.rand() <= count_prob[video_id]:
                usr.append(dictionary[video_id])
            else:
                discard+=1
        word.append(usr)
    print('unknown %d',unk)
    print('known %d',known)
    print('discard %d',discard)
    print('subsampling finish')
    f.close()
    s = open(title_pairfile,'r')
    title_pair = pickle.load(s)
    s.close()
    print(word[0])
    print("loading data has finished")
    return dictionary,rev,word,embeding,title_pair#word is the index of watching history
# data_index = 0
# usr_index = 0
# def generate_batch_cbow(data, batch_size, skip_window):
#     '''
#     Batch generator for CBOW (Continuous Bag of Words).
#     batch should be a shape of (batch_size, num_skips)
#     Parameters
#     ----------
#     data: list of index of videos
#     batch_size: number of words in each mini-batch
#     skip_window: number of videos before the target video
#     '''
#     global data_index
#     global usr_index
#     batch = np.ndarray(shape=(batch_size, skip_window), dtype=np.int32)
#     labels = np.ndarray(shape=(batch_size, 1), dtype=np.int32)
#     span = skip_window + 1 # [ skip_window target skip_window ]
#     buffer = collections.deque(maxlen=span) # used for collecting data[data_index] in the sliding window
#     # collect the first window of words
#     for i in range(batch_size):
#         l2=len(data[usr_index])
#         if data_index >= l2:
#             usr_index=(usr_index+1)%len(data)
#             data_index=0
#         l = len(data[usr_index])
#         if l < span:
#             low = span - l
#             for _ in range(low):
#                 batch[i][_]=0
#                 data_index+=1
#             for _ in range(low,skip_window):
#                 batch[i][_]=data[usr_index][_-low]
#                 data_index+=1
#             labels[i][0]=data[usr_index][skip_window]
#        # usr_index+=1
#         else:
#             if data_index < span:
#                 for _ in range(span):
#                     buffer.append(data[usr_index][_])
#                     data_index+=1
#             else:
#                 buffer.append(data[usr_index][data_index])
#                 data_index+=1
#             mask=[1]*span
#             mask[skip_window] = 0
#             batch[i, :] = list(compress(buffer, mask))
#             labels[i, 0] = buffer[skip_window]
# #         for _ in 
# #     if data_index >= l:
# #         usr_index=(usr_index+1)%len(data)
# #         data_index=0
# #         #l1=len()
# #     for _ in range(span):
# #         buffer.append(data[data_index])
# #         data_index = (data_index + 1) % len(data)
# #     # move the sliding window  
# #     for i in range(batch_size):
# #         mask = [1] * span
# #         mask[skip_window] = 0 
# #         batch[i, :] = list(compress(buffer, mask)) # history
# #         labels[i, 0] = buffer[skip_window] # target
# #         buffer.append(data[data_index])
# #         data_index = (data_index + 1) % len(data)
#     return batch, labels

batch_size = 256 
#skip_windows=8

learning_rate=0.1
n_steps=1000001
sample=0.000001
dictionary, reverse_dictionary,data,embeding,title_pair = build_dataset(index_file,reversed_file,watch_file, vector_file,title_pairfile,count_file,sample)
n_classes=len(dictionary)
print(data[0])
print(n_classes)
def dnn(x,w,b):
    output = tf.add(tf.matmul(x, w['w1']), b['b1'])
    output = tf.nn.relu(output)
    return output

n_hidden_1 = 128
embeding_size = 128
skip_window = 15
true_lable=1
n_sampled=32
train_inputs = tf.placeholder(tf.int32, shape=[batch_size, skip_window])
train_labels = tf.placeholder(tf.int32, shape=[batch_size, true_lable])
weights = {'nce_w': tf.Variable(tf.truncated_normal([n_classes, n_hidden_1],stddev=1.0 / math.sqrt(n_hidden_1))),
           'w1':tf.Variable(tf.random_normal([embeding_size, n_hidden_1]))
            }
bias = {'nce_b': tf.Variable(tf.zeros([n_classes])),
        'b1' : tf.Variable(tf.random_normal([n_hidden_1]))
       }

#v=tf.Variable(tf.random_normal([embeding_size, n_hidden_1]))
print("before....")
learning_rate1=0.025
#embeding = tf.Variable(tf.random_uniform([n_classes,embeding_size], -1.0, 1.0))
embeding = tf.Variable(initial_value=np.array(embeding),dtype=tf.float32)
#embeding = tf.constant(np.array(embeding))
print("after0000000")
#for j in range(skip_window):
embed = tf.zeros([batch_size,embeding_size])
print("here.......")
#for i in range(skip_window):
for j in range(skip_window):
    embed += tf.nn.embedding_lookup(embeding, train_inputs[:,j])/skip_window
print('average finish')
output = dnn(embed,weights,bias)
#c=tf.matmul(output,tf.transpose(weights['nce_w']))
#loss = tf.nn.nce_loss(weights=weights['nce_w'], biases=bias['nce_b'], inputs=output,labels= train_labels,num_sampled= n_sampled,  num_classes=n_classes)
loss = tf.nn.sampled_softmax_loss(weights=weights['nce_w'], biases=bias['nce_b'], inputs=output,labels= train_labels,num_sampled= n_sampled,  num_classes=n_classes)
loss = tf.reduce_mean(loss)
optimizer = tf.train.AdamOptimizer(learning_rate= learning_rate1).minimize(loss)
out_layer = tf.matmul(output, tf.transpose(weights['nce_w'])) + bias['nce_b']
saver = tf.train.Saver()
if not os.path.exists('/home/freelyblue.cr/myproject/reco-dnn/'):
    os.mkdir('/home/freelyblue.cr/myproject/reco-dnn/')
    
    
data_index = 0
usr_index = 0
buffer = collections.deque(maxlen=skip_window+1)
def generate_batch_cbow(data, batch_size, skip_window,true_lable):
    '''
    Batch generator for CBOW (Continuous Bag of Words).
    batch should be a shape of (batch_size, num_skips)
    Parameters
    ----------
    data: list of index of videos
    batch_size: number of words in each mini-batch
    skip_window: number of videos before the target video
    '''
    global data_index
    global usr_index
    global buffer
    batch = np.ndarray(shape=(batch_size, skip_window), dtype=np.int32)
    labels = np.ndarray(shape=(batch_size, true_lable), dtype=np.int32)
    span = skip_window + true_lable # [ skip_window target skip_window ]
#    buffer = collections.deque(maxlen=span) # used for collecting data[data_index] in the sliding window
#     if data_index >= span:
#         if data_index<len(data[usr_index]):
#             buffer.extend(data[usr_index][data_index-span:data_index])
    # collect the first window of words
    for i in range(batch_size):
        l2=len(data[usr_index])
        
        if data_index >= l2:
            usr_index=(usr_index+1)%len(data)
            data_index=0
        l = len(data[usr_index])
        if l < span:
            for j in range(span-l):
                data[usr_index].insert(0,0)
            for j in range(skip_window):
                batch[i][j]=data[usr_index][j]
            for j in range(true_lable):
                labels[i][j]=data[usr_index][j+skip_window]
#             low = span - l
#             if l<true_lable:
#                 #data[usr_index].append(0)
#                 low=low-1
#                 l=1
#             for _ in range(low):
#                 batch[i][_]=0
#                 data_index+=1
#             for _ in range(low,skip_window):
#                 batch[i][_]=data[usr_index][_-low]
#                 data_index+=1
#             for k in range
#             labels[i][0]=data[usr_index][l-1]
       # usr_index+=1
        else:
            if data_index < span:
                for _ in range(span):
                    buffer.append(data[usr_index][_])
                    #batch[i][_]=
                    data_index+=1
            else:
                buffer.append(data[usr_index][data_index])
                data_index+=1
            mask=[1]*span
            #mask1=[0]*span
            for j in range(true_lable):
                mask[skip_window+j] = 0
                labels[i][j]=buffer[span-true_lable+j]
                #mask1[skip_window+j] = 1
            batch[i, :] = list(compress(buffer, mask))
            #print(i,buffer)
#             for
#             labels[i, 0] = buffer[skip_window]
    return batch,labels


import time
title_pair['</s>']='unk'
print(tf.__version__)
#tf.GraphKeys.VARIABLES = tf.GraphKeys.GLOBAL_VARIABLES
#init = tf.global_variables_initializer()
#loss = tf.reduce_mean(loss)/batch_size
with tf.Session() as sess:
    if 1==0:
        print('error')
#     if os.path.exists('/home/freelyblue.cr/myproject/reco-dnn/checkpoint'): #
#         saver.restore(sess, '/home/freelyblue.cr/myproject/reco-dnn/gaoweimodel.ckpt') #
    else:
        init = tf.global_variables_initializer() #
        sess.run(init)
        print("initial")
    start_time = time.time()
    print("begin to trainning")
    avarage_loss = 0
    for i in range(n_steps):
        batch_data,batch_lable = generate_batch_cbow(data[:len(data)*3/4], batch_size, skip_window,true_lable)
        feed_dict = {train_inputs: batch_data, train_labels: batch_lable}
        _, loss_val,out = sess.run([optimizer, loss,out_layer], feed_dict=feed_dict)
        avarage_loss += loss_val
#         if loss_val < 3:
#             #out = out_layer.eval()
#             for j in range(batch_size):
#                 valid_word = title_pair[reverse_dictionary[batch_lable[j,0]]]
#                 nearest = (-out[j, :]).argsort()[0:10]
#                 print('Nearest to %s:' % valid_word)
#                 for k in range(10):
#                     close_word = title_pair[reverse_dictionary[nearest[k]]]
#                     print(close_word)
        if i%1000==0 : #每50次保存一次模型
            save_path = saver.save(sess, '/home/freelyblue.cr/myproject/reco-dnn/gaoweimodel.ckpt') #保存模型到tmp/model.ckpt，注意一定要有一层文件夹，否则保存不成功！！！
            print("save in：%s loss：%s"%(save_path, loss_val))
        if i % 100 == 0:
            if i > 0:
                avarage_loss /= 100
                print("batch",i,"avg_cost", "{:.9f}".format(avarage_loss))
                if i%1000==0:
                    #if avarage_loss < 4:
                        #out = out_layer.eval()
                    for u in range(8):
                        for j in range(2):
                            valid_word = title_pair[reverse_dictionary[batch_lable[32*u+j,0]]]
                                #valid_word1 = title_pair[reverse_dictionary[batch_lable[32*u+j,1]]]
                            nearest = (-out[32*u+j, :]).argsort()[0:10]
                            print('********************')
                            print("watching history")
                            for k in range(skip_window):
                                print(title_pair[reverse_dictionary[batch_data[32*u+j,k]]])
                            print('will watch %s:' % valid_word)
                                #print(valid_word1)
                            print('.......................')
                            for k in range(10):
                                close_word = title_pair[reverse_dictionary[nearest[k]]]
                                print(close_word)
                avarage_loss = 0
    
    
