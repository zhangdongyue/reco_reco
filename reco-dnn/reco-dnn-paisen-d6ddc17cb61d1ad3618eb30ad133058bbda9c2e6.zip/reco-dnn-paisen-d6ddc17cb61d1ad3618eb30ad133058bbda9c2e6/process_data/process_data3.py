import pickle
s=open('/disk5/gaowei/count_dict.pkl','r')
c=pickle.load(s)
s.close()
s=open('/disk5/gaowei/reversed_dictionary.pkl','r')
re=pickle.load(s)
s.close()
count=[]
for i in range(1,len(re)):
    tmp=[]
    tmp.append(re[i])
    tmp.append(c[re[i]])
    count.append(tmp)
s=open('/disk5/gaowei/count_list.pkl','wb')
print(len(count))
pickle.dump(count,s)
s.close()

