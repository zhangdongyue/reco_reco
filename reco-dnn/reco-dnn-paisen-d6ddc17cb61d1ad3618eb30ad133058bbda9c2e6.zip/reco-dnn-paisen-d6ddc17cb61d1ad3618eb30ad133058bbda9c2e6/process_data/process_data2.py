import word2vec
import pickle
f=open('/disk5/gaowei/watch_video.txt','rb')
model=word2vec.load('/disk5/gaowei/vector128.bin')
f1=open('/disk5/gaowei/watch_index.txt','wb')
video_index={}
count_dict={}
l=len(model.vocab)
for i in range(l):
	video_index[model.vocab[i]]=i
for line in f:
	line=line.strip().split(' ')
	str1=""
	for word in line:
		if word in video_index:
			str1=str1+str(video_index[word])+" "
		if word not in count_dict:
			count_dict[word]=1
		else:
			count_dict[word]+=1
	f1.write(str1[:-1]+'\n')
reversed_dictionary = dict(zip(video_index.values(), video_index.keys()))
print('reversed_dictionar[1]',reversed_dictionary[1])
file = open('/disk5/gaowei/index_dict.pkl', 'wb')
pickle.dump(video_index, file)
file.close()
file = open('/disk5/gaowei/reversed_dictionary.pkl', 'wb')
pickle.dump(reversed_dictionary,file)
file.close()
file = open('/disk5/gaowei/count_dict.pkl', 'wb')
pickle.dump(count_dict, file)
file.close()
f.close()
f1.close()

