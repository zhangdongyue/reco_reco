import time
f=open('/disk5/gaowei/processed_data1.txt','r')
i="10000005859374285885"
flag=0
f1=open('/disk5/gaowei/usr.txt','wb')
f2=open('/disk5/gaowei/watch_video.txt','wb')
f3=open('/disk5/gaowei/video_time.txt','wb')
f1.write(i+'\n')
str1=""
str2=""
for line in f:
	line=line.strip().split('\t')
	if line[0]=='0':
		continue
	if line[0]!=i:
		i=line[0]
		flag=1	
		f1.write(i+'\n')
		f2.write(str1[:-1]+'\n')
		f3.write(str2[:-1]+'\n')
		str1=""
		str2=""
	str1=str1+line[1]+" "
	timeArray = time.strptime(line[2], "%Y-%m-%d %H:%M:%S")
	timeStamp = str(time.mktime(timeArray))
	str2=str2+line[1]+" "+timeStamp+" "
f1.close()
f2.close()
f3.close()
f.close()
