# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import tensorflow as tf
window_size = 100 # 定义历史记录的embedding的长度
lg_rate = 0.01 # 定义学习速度 最后的loss 优化 SGD
training_epochs = 1000 # 训练次数
batch_size = 100 # 数据批次训练 minibatch 这个后期考虑
num_samp =1000 ## 负采样的数量
emb_dim = 128 # 视频ID embedding 之后的维度 与relu的网络层最后一层输出节点同步

raw_path = "" # 原始数据路径
save_path= "" # 数据处理完成之后的结果
Video_Index ={} ## 视频ID 的类别
Video_count ={} ## 统计视频ID 对应的出现次数

#************************ 数据处理的部分 ***********************
##这部分得到 train_data test_data DataFrame 
pre_raw_data(rawpath):
    
#************************数据处理的结果 ************************
def read_data_batch(pos,batch_size,input_data):
    '''mini batch 训练 小批量数据训练,每个batch收敛会比较快'''
    data_batch_input = input_data[pos,pos+batch_size]
    batch_y =data_batch_input["itemid"]
    batch_x =data_batch_input.drop(data_batch_input["itemid"]) 
    return batch_x,batch_y

def split_data(save_path,splitTm):
    '''区分train 数据 还是eval数据'''
    ## 可以用ctm 区分
    pd_df_hist = pd.read_csv(save_path,sep=' ')
    train_data =pd_df_hist[pd_df_hist["ctm"]<splitTm]
    eval_data=pd_df_hist[pd_df_hist["ctm"]>=splitTm]
    return train_data,eval_data


def AddNetLayer(input_x,in_size,out_size,activation_func =None,w_name,b_name):
    '''搭建神经网络层 Relu 可以是激活函数'''
    Weight = tf.Variables(tf.random_normal([in_size,out_size]),name =w_name)
    bias = tf.Variable(tf.zeros(1,out_size)+0.1,name =w_name)
    Wx_plus_b = tf.matmul(inputs,Weight)+bias
    if active_function is None:
        output = Wx_plus_b
    else:
        output = activation_func(Wx_plus_b)
    return output 

def nce_loss(true_logits,sampled_logits,batch_size):
    '''模型估计用nce_loss的方式去预估 
      1.为了打压热点数据 带偏 
      2.为了使计算复杂度降低  只在采样类别上去做预估 而不是在全局类别'''
    true_xent = tf.nn.sigmoid_cross_entropy_with_logits(labels=tf.ones_like(true_logits), logits=true_logits)
    sampled_xent = tf.nn.sigmoid_cross_entropy_with_logits(labels=tf.zeros_like(sampled_logits), logits=sampled_logits)
    nce_loss_tensor = (tf.reduce_sum(true_xent) + tf.reduce_sum(sampled_xent)) /batch_size
    return nce_loss_tensor

def negative_Sample(examples_emb,labels):
    '''negative sample 的部分 
      examples_emb 是输入的前一层的向量'''
    labels_matrix = tf.reshape(tf.cast(labels,dtype=tf.int64),[batch_size ,1])
    ## 通过 distor
    sampled_ids, _, _ =(tf.nn.fixed_unigram_candidate_sampler(
            true_classes=labels_matrix,
            num_true=1, 
            num_sampled=num_samp,
            unique=True,
            range_max=len(Video_Index),
            distortion=0.75,
            unigrams=Video_count.values())
    return sampled_ids

def softmax_layer_nce(input_x,labels,t_w_name="sm_t",t_b_name="sm_b"):
    item_count =len(Video_Index)
    sampled_ids =negative_Sample(input_x,labels)
    sm_w_t = tf.Variable(tf.zeros([item_count,input_x.shape[1]]),name=t_w_name)
    sm_b = tf.Variable(tf.zeros([item_count]), name=t_b_name)
                        
    true_w = tf.nn.embedding_lookup(sm_w_t, labels)
    true_b = tf.nn.embedding_lookup(sm_b, labels)
    sampled_w = tf.nn.embedding_lookup(sm_w_t, sampled_ids)
    sampled_b = tf.nn.embedding_lookup(sm_b, sampled_ids)
                        
    true_logits = tf.reduce_sum(tf.multiply(example_emb, true_w), 1) + true_b
    sampled_b_vec = tf.reshape(sampled_b, [num_samp])
    sampled_logits = tf.matmul(example_emb,sampled_w,transpose_b=True) + sampled_b_vec
    softmax_layer = tf.nn.softmax(true_logits)
    return true_logits, sampled_logits,softmax_layer
                        
def model(train_data,test_data):
    ## 第一层神经网络层 Relu
    in_1_size =train_data.shape[1]-1 ## embedding vector 的长度 后续可以添加其他特征
    out_1_size =emb_dim ## 视频ID的embedding的长度 保证跟最后一层Relu输出节点相同
    x_batch = tf.placeholder(tf.int32, shape=[None,in_1_size])
    y_batch = tf.placeholder(tf.int64, [None,out_dim])
    ## 可以之后再添加其他层节点
    hidden_1_out = AddNetLayer(x_batch,in_1_size,out_1_size,activation_func =tf.nn.Relu,w_name="h1_w",b_name="h1_b")
    true_logits,sampled_logits,pred =softmax_layer_nce(hidden_1_out,y_batch,t_w_name="sm_t",t_b_name="sm_b")
    loss =nce_loss(true_logits,sampled_logits,batch_size) ## loss func 
    optimizer = tf.train.AdamOptimizer(learning_rate=lg_rate).minimize(loss) # optimize
    total_batch = int(train_data.shape[0] / batch_size)
    final_accuracy=0.0
    init = tf.global_variables_initializer() # init all
    with tf.Session() as sess:
        sess.run(init)
        for epoch in range(training_epochs):
            avg_cost =0.0
            for i in range(total_batch):
                batch_x,batch_y =read_data_batch(i*batch_size,batch_size,train_data)
                sess.run([optimizer, loss], feed_dict={x_batch:batch_x,y_batch:batch_y})
                     # Display logs per epoch step
        if epoch % 50 == 0:
            print("Epoch:", '%04d' % (epoch + 1), "loss=","{:.9f}".format(loss))
            correct_prediction = tf.equal(tf.argmax(pred, 1), tf.reshape(y_batch, [batch_size]))
            accuracy = tf.reduce_mean(tf.cast(correct_prediction, "float"))
            print("每个Epoch的最后一次的batch:", '%04d' % (epoch + 1), "accuracy=","{:.9f}".format(accuracy))

        # 测试数据
        total_batch = int(test_data.shape[0] / batch_size)
        for i in range(total_batch):
            batch_x,batch_y =read_data_batch(i*batch_size,batch_size,test_data)
            accuracy.eval({x_batch: x, y_batch: y})
            final_accuracy += batch_accuracy
        final_accuracy = final_accuracy /total_batch
        print("测试得到的准确率accuracy:{:.9f}".format(final_accuracy))
         
# 预处理数据，得到word2vec corpus
pd_df_hist = pre_raw_data(rawpath)
train_data,test_data =split_data(save_path,splitTm="2017-07-28 00:00:00")
model(train_data,test_data)