
# coding: utf-8

# In[1]:

import tensorflow as tf
#import word2vec
import pickle
import math
import time
import linecache


# In[5]:

readfile1 = '/home/paisen.gw/process_data/index_dict.pkl'
#readfile2 = "/home/paisen.gw/process_data/project/video_list.txt"
label_file = "/home/paisen.gw/process_data/label.csv"
feature_file = "/home/paisen.gw/process_data/feature.csv"
n_hidden_1 = 256 #the dimension of the feature
emb_size = 128 #vedio embeding size
learn_rate = 0.1
video_dict = dict()
num_sample = 64
batch_size = 128


# In[6]:

def form_batch_sampe(pos, batch_size, x, y):
    # batch_x = x[pos:pos+batch_size]
    # batch_y = y[pos:pos+batch_size]
    y_batch = []
    x_batch = []
    for i in range(pos,pos+batch_size):
        y_batch.append([y[i].strip()])
        x_batch.append(x[i].strip().split(','))
    return x_batch, y_batch

def read_date(filename1):
    s = open(filename1,'r')
    dictionary = pickle.load(s)
    s.close()
#     s1 = open(filename2, 'r')
#     rev = pickle.load(s1)
#     s1.close()
    return dictionary


# In[ ]:

vedio_index = read_date(readfile1)
n_classes = len(vedio_index)
print(n_classes)
train_feature = linecache.getlines(feature_file)
train_label = linecache.getlines(label_file)
print(len(train_feature))


# In[ ]:

x_batch = tf.placeholder(tf.int32, [batch_size,emb_size])
y_batch = tf.placeholder(tf.int64, [None, 1])
video_size = len(video_dict)
#y = tf.placeholder("float", [None, video_size])
weights = {
    'w1': tf.Variable(tf.random_normal([emb_size, n_hidden_1])),
    'nce_w': tf.truncated_normal([n_classes, n_hidden_1],
                        stddev=1.0 / math.sqrt(n_hidden_1))
}
biases = {
    'b1': tf.Variable(tf.ranom_normal([n_hidden_1])),
    'nce_b': tf.Variable(tf.ranom_normal([video_size]))
}


# In[ ]:

def dnn_model(x, weights, biases):
     output = tf.add(tf.matmul(x, weights['w1']), biases['b1'])
     return output


# In[ ]:

x = dnn_model(x_batch, weights, biases)
loss = tf.reduce_mean(tf.nn.nce_loss(weights=weights["nce_w"], biases=biases["nce_b"],
                                     labels=y_batch, inputs=x, num_sampled=num_sample, num_classes=n_classes))
cost = tf.reduce_sum(loss) / batch_size
optimizer = tf.train.AdamOptimizer(learning_rate=learn_rate).minimize(cost)
out_layer = tf.matmul(x, tf.transpose(weights['nce_w'])) + biases['nce_b']


# In[ ]:

#training
#train_step = tf.train.GradientDescentOptimizer(learning_rate=learn_rate).minimize(cross_entropy)
init = tf.initialize_all_variables()
sess = tf.Session()
sess.run(init)
#training cycle
start_time = time.time()
total_batch = int(len(train_label) / batch_size)
print("total_batch of training data: ", total_batch)
avg_cost = 0.
for i in range(total_batch):
    x, y = form_batch_sampe(i*batch_size, batch_size,train_feature,train_label)
    _, c = sess.run([optimizer, cost], feed_dict={x_batch: x,y_batch:y})
    avg_cost += c / total_batch

print("Epoch:", '%04d' % (1), "cost=",               "{:.9f}".format(avg_cost))


# In[ ]:



