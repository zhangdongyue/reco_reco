def process_data2txt(read_file):
    #0 is used for padding embedding
    label_cnt = 0
    sku_cnt = 1
    data_dict = dict()
    f = open(read_file, 'r')
    for line in f:
        line = line.strip().split(' ')
        if line[2] not in data_dict:
            data_dict[line[2]] = [[line[3], line[4]]]
        else:
            data_dict[line[2]].append([line[3], line[4]])
    f.close()
    file = open("/home/paisen.gw/process_data/final.txt", 'w')
    for i in data_dict:
        str=""
        for list in data_dict[i]:
            str = str+list[0]+" "
        file.write(str[:-1]+'\n')
    file.close()

read_file = '/home/paisen.gw/process_data/sorted_data.txt'
process_data2txt(read_file)
