# -*- coding:utf-8 -*- 
from __future__ import absolute_import
from __future__ import print_function

import collections
import math
import os
import random
import re
import json
from itertools import compress
import pickle
import word2vec
import pandas as pd
import numpy as np
import tensorflow as tf
tf.GraphKeys.VARIABLES = tf.GraphKeys.GLOBAL_VARIABLES
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.metrics.pairwise import pairwise_distances


# Set random seeds
SEED = 2017
random.seed(SEED)
np.random.seed(SEED)
index_file = '/home/paisen.gw/process_data/index_dict.pkl'
reversed_file = '/home/paisen.gw/process_data/reversed_dictionary.pkl'
watch_file = '/home/paisen.gw/process_data/final.txt'
vector_file = '/home/paisen.gw/process_data/vector.bin'
title_pairfile= '/home/paisen.gw/process_data/titlepair.pkl'
count_file='/home/paisen.gw/process_data/count.pkl'
def get_data(vector_file,reversed_file,title_pairfile):
    model=word2vec.load(vector_file)
    embeding=[]
    for i in model.vocab:
        embeding.append(model[i])
    s=open(reversed_file,'r')
    rev=pickle.load(s)
    s.close()
    s1=open(title_pairfile)
    title_pair=pickle.load(s1)
    s1.close()
    return embeding,rev,title_pair
def build_dataset(index_file,reversed_file,watch_file, vector_file,title_pairfile,count_file,sample):
    s = open(index_file,'r')
    dictionary = pickle.load(s)
    s.close()
    print('dictionart finish')
    s1 = open(reversed_file, 'r')
    rev = pickle.load(s1)
    s1.close()
    print('reversed finish')
    model = word2vec.load(vector_file)
    embeding = []
    for i in model.vocab:
        embeding.append(model[i])
    embeding[0]=[0]*128
    s2 = open(count_file,'r')
    count= pickle.load(s2)
    s2.close()
    count_prob={}
    sum=0.0
    for i in count:
        sum+=i[1]
    for i in count:
        tmp=i[1]/sum
        #print(tmp)
        if tmp >0.0:
            prob=sample/tmp+math.sqrt(sample/tmp)
        else:
            prob=1.2
        count_prob[i[0]]=prob
    print('prob finish')
    f = open(watch_file, 'r')
    word=[]
    unk=0
    known=0
    discard=0
    for line in f:
        a = np.zeros(128)
        count = 0
        line = line.strip().split(' ')
        usr = []
        for video_id in line:
            if video_id not in model:
                unk+=1
                continue
            known+=1
            if np.random.rand() <= count_prob[video_id]:
                usr.append(dictionary[video_id])
            else:
                discard+=1
        if len(usr)==0:
            continue
        word.append(usr)
    print('unknown %d',unk)
    print('known %d',known)
    print('discard %d',discard)
    print('subsampling finish')
    f.close()
    s = open(title_pairfile,'r')
    title_pair = pickle.load(s)
    s.close()
    print(word[0])
    print("loading data has finished")
    return dictionary,rev,word,embeding,title_pair#word is the index of watching history
# data_index = 0
# usr_index = 0
# def generate_batch_cbow(data, batch_size, skip_window):
#     '''
#     Batch generator for CBOW (Continuous Bag of Words).
#     batch should be a shape of (batch_size, num_skips)
#     Parameters
#     ----------
#     data: list of index of videos
#     batch_size: number of words in each mini-batch
#     skip_window: number of videos before the target video
#     '''
#     global data_index
#     global usr_index
#     batch = np.ndarray(shape=(batch_size, skip_window), dtype=np.int32)
#     labels = np.ndarray(shape=(batch_size, 1), dtype=np.int32)
#     span = skip_window + 1 # [ skip_window target skip_window ]
#     buffer = collections.deque(maxlen=span) # used for collecting data[data_index] in the sliding window
#     # collect the first window of words
#     for i in range(batch_size):
#         l2=len(data[usr_index])
#         if data_index >= l2:
#             usr_index=(usr_index+1)%len(data)
#             data_index=0
#         l = len(data[usr_index])
#         if l < span:
#             low = span - l
#             for _ in range(low):
#                 batch[i][_]=0
#                 data_index+=1
#             for _ in range(low,skip_window):
#                 batch[i][_]=data[usr_index][_-low]
#                 data_index+=1
#             labels[i][0]=data[usr_index][skip_window]
#        # usr_index+=1
#         else:
#             if data_index < span:
#                 for _ in range(span):
#                     buffer.append(data[usr_index][_])
#                     data_index+=1
#             else:
#                 buffer.append(data[usr_index][data_index])
#                 data_index+=1
#             mask=[1]*span
#             mask[skip_window] = 0
#             batch[i, :] = list(compress(buffer, mask))
#             labels[i, 0] = buffer[skip_window]
# #         for _ in 
# #     if data_index >= l:
# #         usr_index=(usr_index+1)%len(data)
# #         data_index=0
# #         #l1=len()
# #     for _ in range(span):
# #         buffer.append(data[data_index])
# #         data_index = (data_index + 1) % len(data)
# #     # move the sliding window  
# #     for i in range(batch_size):
# #         mask = [1] * span
# #         mask[skip_window] = 0 
# #         batch[i, :] = list(compress(buffer, mask)) # history
# #         labels[i, 0] = buffer[skip_window] # target
# #         buffer.append(data[data_index])
# #         data_index = (data_index + 1) % len(data)
#     return batch, labels

batch_size = 256 

#skip_windows=8

learning_rate=0.1
n_steps=150000
sample=0.01
#dictionary, reverse_dictionary,data,embeding1,title_pair = build_dataset(index_file,reversed_file,watch_file, vector_file,title_pairfile,count_file,sample)
embeding1,reverse_dictionary,title_pair=get_data(vector_file,reversed_file,title_pairfile)
n_classes=len(reverse_dictionary)
#print(data[0])
print(n_classes)
def dnn(x,w,b):
    output = tf.add(tf.matmul(x, w['w1']), b['b1'])
    output = tf.nn.tanh(output)
    return output

n_hidden_1 = 128
embeding_size = 128
skip_window = 15
true_lable=1
n_sampled=2048
trainning=False
train_inputs = tf.placeholder(tf.int32, shape=[None, skip_window])
train_labels = tf.placeholder(tf.int32, shape=[None, true_lable])
weights = {'nce_w': tf.Variable(tf.truncated_normal([n_classes, n_hidden_1],stddev=1.0 / math.sqrt(n_hidden_1))),
           'w1':tf.Variable(tf.random_normal([embeding_size, n_hidden_1]))
            }
bias = {'nce_b': tf.Variable(tf.zeros([n_classes])),
        'b1' : tf.Variable(tf.random_normal([n_hidden_1]))
       }

#v=tf.Variable(tf.random_normal([embeding_size, n_hidden_1]))
print("before....")
learning_rate1=0.001
#embeding = tf.Variable(tf.random_uniform([n_classes,embeding_size], -1.0, 1.0))
embeding = tf.Variable(initial_value=np.array(embeding1),dtype=tf.float32)
#embeding = tf.constant(np.array(embeding))
print("after0000000")
#for j in range(skip_window):
embed = tf.zeros([batch_size,embeding_size])
print("here.......")
#for i in range(skip_window):
for j in range(skip_window):
    embed += tf.nn.embedding_lookup(embeding, train_inputs[:,j])/skip_window
print('average finish')
output = dnn(embed,weights,bias)
#c=tf.matmul(output,tf.transpose(weights['nce_w']))
#loss = tf.nn.nce_loss(weights=weights['nce_w'], biases=bias['nce_b'], inputs=output,labels= train_labels,num_sampled= n_sampled,  num_classes=n_classes)
#loss = tf.nn.sampled_softmax_loss(weights=weights['nce_w'], biases=bias['nce_b'], inputs=output,labels= train_labels,num_sampled= n_sampled,  num_classes=n_classes)
#loss = tf.reduce_mean(loss)
#optimizer = tf.train.AdamOptimizer(learning_rate= learning_rate1).minimize(loss)
out_layer = tf.matmul(output, tf.transpose(weights['nce_w'])) + bias['nce_b']
if 1:
    loss = tf.nn.sampled_softmax_loss(weights=weights['nce_w'], biases=bias['nce_b'], inputs=output,labels= train_labels,num_sampled= n_sampled,  num_classes=n_classes)
else:
    labels_one_hot = tf.one_hot(train_labels, n_classes)
    loss = tf.nn.softmax_cross_entropy_with_logits(
            labels=labels_one_hot,
                  logits=out_layer)
loss = tf.reduce_mean(loss)
optimizer = tf.train.AdamOptimizer(learning_rate= learning_rate1).minimize(loss)

saver = tf.train.Saver()
if not os.path.exists('/home/paisen.gw/git/model/model_save_tanh/'):
    os.mkdir('/home/paisen.gw/git/model/model_save_tanh/')
    
valid_size=5
data_index = 0
usr_index = 0
buffer = collections.deque(maxlen=skip_window+true_lable+valid_size)
def generate_batch_cbow(data, batch_size, skip_window,true_lable,valid_size):
    '''
    Batch generator for CBOW (Continuous Bag of Words).
    batch should be a shape of (batch_size, num_skips)
    Parameters
    ----------
    data: list of index of videos
    batch_size: number of words in each mini-batch
    skip_window: number of videos before the target video
    '''
    global data_index
    global usr_index
    global buffer
    batch = np.ndarray(shape=(batch_size, skip_window), dtype=np.int32)
    labels = np.ndarray(shape=(batch_size, true_lable), dtype=np.int32)
    span = skip_window + true_lable+valid_size# [ skip_windo skip_window ]
    valid_data=np.ndarray(shape=(batch_size,valid_size+true_lable), dtype=np.int32)
#    buffer = collections.deque(maxlen=span) # used for collecting data[data_index] in the sliding window
#     if data_index >= span:
#         if data_index<len(data[usr_index]):
#             buffer.extend(data[usr_index][data_index-span:data_index])
    # collect the first window of words
    while(len(data[usr_index])<span):
         usr_index=(usr_index+1)%len(data)
    for i in range(batch_size):
        l2=len(data[usr_index])
        
        if data_index >= l2:
            usr_index=(usr_index+1)%len(data)
            while(len(data[usr_index])<span):
                     usr_index=(usr_index+1)%len(data)
            data_index=0
        l = len(data[usr_index])
        if l < span:
            for j in range(span-l):
                data[usr_index].insert(0,0)
            for j in range(skip_window):
                batch[i][j]=data[usr_index][j]
            for j in range(true_lable):
                labels[i][j]=data[usr_index][j+skip_window]
            for j in range(valid_size):
                valid_data[i][j]=0
#             low = span - l
#             if l<true_lable:
#                 #data[usr_index].append(0)
#                 low=low-1
#                 l=1
#             for _ in range(low):
#                 batch[i][_]=0
#                 data_index+=1
#             for _ in range(low,skip_window):
#                 batch[i][_]=data[usr_index][_-low]
#                 data_index+=1
#             for k in range
#             labels[i][0]=data[usr_index][l-1]
       # usr_index+=1`
        else:
            if data_index < span:
                for _ in range(span):
                    buffer.append(data[usr_index][_])
                    #batch[i][_]=
                    data_index+=1
                
            else:
                buffer.append(data[usr_index][data_index])
                data_index+=1
            #mask=[1]*span
            #mask1=[0]*span
            for j in range(true_lable):
                labels[i][j]=buffer[span-true_lable-valid_size+j]
                #mask1[skip_window+j] = 1
            #batch[i, :] = list(compress(buffer, mask))
            for j in range(valid_size+true_lable):
                valid_data[i][j]=buffer[span-true_lable-valid_size+j]
            for j in range(skip_window):
                batch[i][j]=buffer[j]
            #print(i,buffer)
#             for
#             labels[i, 0] = buffer[skip_window]
    return batch,labels,valid_data


import time
import ml_metrics as metrics
#valid_size=5
title_pair['</s>']='unk'
print(tf.__version__)
file_path="/home/paisen.gw/git/model/data/"
#trainning=True
#tf.GraphKeys.VARIABLES = tf.GraphKeys.GLOBAL_VARIABLES
#init = tf.global_variables_initializer()
#loss = tf.reduce_mean(loss)/batch_size
with tf.Session() as sess:
    if 1==0:
        print('error')
#     if os.path.exists('/home/freelyblue.cr/myproject/reco-dnn/checkpoint'): #
#         saver.restore(sess, '/home/freelyblue.cr/myproject/reco-dnn/gaoweimodel.ckpt') #
    if trainning:
        init = tf.global_variables_initializer() #
        sess.run(init)
        print("initial")
   # if trainning:
        start_time = time.time()
        print("begin to trainning")
        avarage_loss = 0
        map=0
        file_index=-1
        globle_step=0
        chunk_index=0
        for i in range(6):
            file_index=(file_index+1)%3
            print("we are in file "+str(file_index))
            pd_reader=pd.read_csv(file_path+"sample"+str(file_index)+".csv",sep=',',chunksize =2048*batch_size)
            for chunk in pd_reader:
                chunk_index+=1
                print("we are in chunk "+str(chunk_index))
                shuffle_data=chunk.as_matrix()
                np.random.shuffle(shuffle_data)
                for j in range(2047):
                    #print("we are in file"+str(file_index))
                    batch=shuffle_data[j*batch_size:(j+1)*batch_size,:]
                    batch_data=batch[:,0:skip_window]
                    batch_lable=batch[:,skip_window:skip_window+true_lable]
                    valid_data=batch[:,-valid_size:]
                    
            #batch_data,batch_lable,valid_data = generate_batch_cbow(data, batch_size, skip_window,true_lable,valid_size)
                    feed_dict = {train_inputs: batch_data, train_labels: batch_lable}
                    _, loss_val,out,relu_out = sess.run([optimizer, loss,out_layer,output], feed_dict=feed_dict)
                    avarage_loss += loss_val
                    globle_step+=1
                    if globle_step % 100 == 0:
                        if globle_step > 0:
                            avarage_loss /= 100
 #               map/=100   
                            map+=metrics.mapk(valid_data.tolist(),(-out).argsort()[:,0:100],100)
                    #print("batch",i,"MAP", "{:.9f}".format(map))
 #               map=0
                            print("batch",globle_step,"avg_cost", "{:.9f}".format(avarage_loss))
                    #print("usr_index:",usr_index)
                            avarage_loss=0
                            if globle_step%1000==0:
                                print("batch",globle_step,"MAP", "{:.9f}".format(map/10))
                                map=0
                                print(relu_out[0])
                                save_path = saver.save(sess, '/home/paisen.gw/git/model/model_save_tanh/model.ckpt', global_step=globle_step) #保存模型到tmp/model.ckpt，注>意一定要有一层文件夹，否则保存不成功！！！
                                print("save in：%s loss：%s"%(save_path, loss_val))
                                for u in range(8):
                                    for j in range(2):
                                        valid_word = title_pair[reverse_dictionary[batch_lable[32*u+j,0]]]
                                #valid_word1 = title_pair[reverse_dictionary[batch_lable[32*u+j,1]]]
                                        nearest = (-out[32*u+j, :]).argsort()[0:10]
                                        print('********************')
                                        print("watching history")
                                        for k in range(skip_window):
                                            print(title_pair[reverse_dictionary[batch_data[32*u+j,k]]])
                                        print('will watch %s:' % valid_word)
                                #print(valid_word1)
                                        print('.......................')
                                        for k in range(10):
                                            close_word = title_pair[reverse_dictionary[nearest[k]]]
                                            print(close_word)
                    
    
    else:
       # tf.reset_default_graph()

        ckpt = tf.train.get_checkpoint_state('/home/paisen.gw/git/model/model_save_tanh/')  
        if ckpt and ckpt.model_checkpoint_path:  
        #    tf.reset_default_graph()
            saver.restore(sess, ckpt.model_checkpoint_path) 
            print('model restore')
        else:  
            pass
        avarage_loss = 0
        map=0
        file_index=-1
        globle_step=0
        chunk_index=0
        for i in range(1):
            file_index=(file_index+1)%3+3
            print("we are in file "+str(file_index))
            pd_reader=pd.read_csv(file_path+"sample"+str(file_index)+".csv",sep=',',chunksize =2048*batch_size)
            for chunk in pd_reader:
                chunk_index+=1
                print("we are in chunk "+str(chunk_index))
                shuffle_data=chunk.as_matrix()
                #np.random.shuffle(shuffle_data)
                for j in range(2047):
                #print("we are in file"+str(file_index))
                    batch=shuffle_data[j*batch_size:(j+1)*batch_size,:]
                    batch_data=batch[:,0:skip_window]
                    batch_lable=batch[:,skip_window:skip_window+true_lable]
                    valid_data=batch[:,-valid_size:]
            #batch_data,batch_lable,valid_data = generate_batch_cbow(data, batch_size, skip_window,true_lable,valid_size)
                    feed_dict = {train_inputs: batch_data, train_labels: batch_lable}
                    loss_val,out,relu_out = sess.run([loss,out_layer,output], feed_dict=feed_dict)
                    avarage_loss += loss_val
                    map+=metrics.mapk(valid_data.tolist(),(-out).argsort()[:,0:100],100)
                    globle_step+=1
                    if globle_step % 100 == 0:
                        if globle_step > 0:
                            avarage_loss /= 100
                            map/=100
                   # map=metrics.mapk(valid_data.tolist(),(-out).argsort()[:,0:100],100)
                            print("batch",globle_step,"MAP", "{:.9f}".format(map))
                            map=0
                            print("batch",globle_step,"avg_cost", "{:.9f}".format(avarage_loss))
                            avarage_loss=0
                            if globle_step%1000==0:
                                print(relu_out[0])
                                for u in range(8):
                                    for j in range(2):
                                        valid_word = title_pair[reverse_dictionary[batch_lable[32*u+j,0]]]
                                        nearest = (-out[32*u+j, :]).argsort()[0:10]
                                        print('********************')
                                        print("watching history")
                                        for k in range(skip_window):
                                            print(title_pair[reverse_dictionary[batch_data[32*u+j,k]]])
                                        print('will watch %s:' % valid_word)
                                        print('.......................')
                                        for k in range(10):
                                            close_word = title_pair[reverse_dictionary[nearest[k]]]
                                            print(close_word)
                   # avarage_loss = 0

