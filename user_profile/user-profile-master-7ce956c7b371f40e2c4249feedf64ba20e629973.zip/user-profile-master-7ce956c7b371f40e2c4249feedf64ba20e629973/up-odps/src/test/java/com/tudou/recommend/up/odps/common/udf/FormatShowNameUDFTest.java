package com.tudou.recommend.up.odps.common.udf;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Wangfei on 2017/6/23.
 */
public class FormatShowNameUDFTest {
    FormatShowNameUDF showNamePreTagUDF = new FormatShowNameUDF();

    @Test
    public void evaluate() throws Exception {
        assertThat(showNamePreTagUDF.evaluate("优酷全娱乐 2014 4月3日"))
                .isEqualTo("《优酷全娱乐》 2014 4月3日");
        assertThat(showNamePreTagUDF.evaluate("哆啦A梦 第二季 上"))
                .isEqualTo("《哆啦A梦》 第二季 上");
        assertThat(showNamePreTagUDF.evaluate("家庭健身 2015"))
                .isEqualTo("《家庭健身》 2015");
        assertThat(showNamePreTagUDF.evaluate("【牛人】胥渡吧"))
                .isEqualTo("牛人 《胥渡吧》");
        assertThat(showNamePreTagUDF.evaluate("爱情公寓3"))
                .isEqualTo("《爱情公寓》 3");
        assertThat(showNamePreTagUDF.evaluate("爱情公寓III"))
                .isEqualTo("《爱情公寓》 III");
        assertThat(showNamePreTagUDF.evaluate("大冒险家 DVD版"))
                .isEqualTo("《大冒险家》 DVD版");
        assertThat(showNamePreTagUDF.evaluate("Running Man 2013"))
                .isEqualTo("《Running Man》 2013");
        assertThat(showNamePreTagUDF.evaluate("Running Man第一 IV"))
                .isEqualTo("《Running Man第一》 IV");
        assertThat(showNamePreTagUDF.evaluate("爱情公寓IV"))
                .isEqualTo("《爱情公寓》 IV");
    }

}