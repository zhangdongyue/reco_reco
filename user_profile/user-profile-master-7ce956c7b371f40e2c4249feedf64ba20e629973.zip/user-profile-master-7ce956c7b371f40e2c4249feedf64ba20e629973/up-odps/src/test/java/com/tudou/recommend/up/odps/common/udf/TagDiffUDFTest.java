package com.tudou.recommend.up.odps.common.udf;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by pharosa on 2017/7/20.
 */
public class TagDiffUDFTest {
    private TagDiffUDTF diffUDF = new TagDiffUDTF();

    @Test
    public void testEvaluate() {
        String tag1 = "火影忍者::6.00::4.5 | 海泽王::5.0::6.0 | 择天记::4.5::10.1 | 国际足球::10.1::12.323";
        String tag2 = "火影忍者::4.00::4.5 | 海泽王::16.0::6.0 | 择天记::5.5::10.1 | dota::1.0::1.0";
        Object[] result = diffUDF.evaluate(tag1, tag2, "\\|", "::");
        assertThat(result[0]).isEqualTo("1");
        assertThat(result[1]).isEqualTo("国际足球:10.100000:12.323000");
        assertThat(result[2]).isEqualTo("1");
        assertThat(result[3]).isEqualTo("dota:1.000000:1.000000");
        assertThat(result[4]).isEqualTo("3");
        assertThat(result[5]).isEqualTo("3");
        assertThat(result[6]).isEqualTo("<1>:火影忍者:6.000000:4.500000->海泽王:16.000000:6.000000,\n" +
                "<2>:海泽王:5.000000:6.000000->择天记:5.500000:10.100000,\n" +
                "<3>:择天记:4.500000:10.100000->火影忍者:4.000000:4.500000,\n");
        assertThat(result[7]).isEqualTo("0");

    }

}