package com.tudou.recommend.up.odps.iflow.dnn;

import com.google.common.base.Joiner;
import org.junit.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.*;

/**
 * @author wangfei01
 * @date 2017/8/28
 */
public class SeqReducerTest {
    private WatchHistoryMR.SeqReducer reducer = new WatchHistoryMR.SeqReducer();

    @Test
    public void windowExample() throws Exception {
        String[] array = new String[]{
                "0", "1", "2", "3", "4", "5",
                "6", "7", "8", "9", "10",
                "11", "12", "13", "14", "15",
                "16", "17", "18", "19", "20",
                "21", "22", "23", "24", "25", "26",};
        List<Object[]> result = reducer.windowExample(array, "0", 1, 5, 20, 3);
        for(Object[] obj:result) {
            System.out.println(Joiner.on("\t").join(obj));
        }
        array = new String[]{
                "0", "1", "2", "3", "4", "5",
                "21", "22", "23", "24", "25", "26",};
        result = reducer.windowExample(array, "0", 1, 5, 20, 3);
        for(Object[] obj:result) {
            System.out.println(Joiner.on("\t").join(obj));
        }
    }

}