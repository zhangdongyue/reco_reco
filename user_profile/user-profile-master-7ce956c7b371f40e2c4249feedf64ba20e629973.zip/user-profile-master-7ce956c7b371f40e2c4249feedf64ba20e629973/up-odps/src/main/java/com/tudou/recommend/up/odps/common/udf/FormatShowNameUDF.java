package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.google.common.base.Joiner;
import com.tudou.recommend.up.utils.CharacterUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Wangfei on 2017/6/23.
 */
public class FormatShowNameUDF extends UDF {
    private static Pattern SUFFIX_PATTERN = Pattern.compile(".*[0-9IV]+$");
    private static Pattern EPISODE_PATTERN = Pattern.compile("([第上下].*)|([0-9IV]+)");
    private static Pattern NUMBER_PATTERN = Pattern.compile("\\d+");
    private static Pattern VERSION_PATTERN = Pattern.compile(".*版$");
    private static Pattern MONTH_PATTERN = Pattern.compile("([0-1]*[0-9][月日]*)+");

    public String evaluate(String title) {
        String[] decorates = decorate(title);
        return Joiner.on(" ")
                .join(decorates)
                .trim()
                .replace("  ", " ");
    }

    public String[] decorate(String showName) {
        boolean hasRight = false;
        String[] terms = removeChinesePunctuation(showName).split(" ");
        for (int i = terms.length - 1; i >= 0; i--) {
            if (!isEpisodeMark(terms[i])
                    && !isVersionMark(terms[i])
                    && !isDateMark(terms[i])) {
                if (CharacterUtils.sentenceType(terms[i]) != 1) {
                    int index = suffixDetect(terms[i]);
                    if (index > 0) {
                        if (!terms[i].endsWith("`")) {
                            if (i == 0) {
                                terms[i] = "《" + terms[i];
                            }
                            String tmp = terms[i].substring(0, Math.min(index + 2, terms[i].length()));
                            if (index + 2 >= terms[i].length()) {
                                terms[i] = tmp + "》";
                            } else {
                                terms[i] = tmp + "》 " + terms[i].substring(index + 2);
                            }
                            hasRight = true;
                        } else {
                            if ((i + 1) < terms.length) {
                                terms[i + 1] = "《" + terms[i + 1];
                            }
                            terms[i] = terms[i].replace("`", "");
                        }
                    }
                } else {
                    terms[0] = "《" + terms[0];
                    if (!hasRight) {
                        terms[i] = terms[i] + "》";
                    }
                    break;
                }
            }
        }
        return terms;
    }

    public String removeChinesePunctuation(String text) {
        char[] characters = text.replace("`", " ").toCharArray();
        boolean hasBefore = false;
        boolean hasChinesePunctuation = false;
        StringBuilder builder = new StringBuilder();
        int index = 0;
        for (int i = 0; i < characters.length; i++) {
            if (CharacterUtils.isChinesePunctuation(characters[i])) {
                hasChinesePunctuation = true;
                if (hasBefore) {
                    builder.append(new String(characters, index, i - index))
                            .append("` ");
                    index = i + 1;
                    hasBefore = false;
                } else {
                    builder.append("`");
                    hasBefore = true;
                    index = i + 1;
                }
            }
            if (hasChinesePunctuation && i == (characters.length - 1)) {
                builder.append(new String(characters, index, i - index + 1));
            }
        }
        if (!hasChinesePunctuation) {
            builder.append(text);
        }
        return builder.toString();
    }

    /**
     * Detect show name format like '爱情公寓3' or '爱情公寓IV'.
     *
     * @param term
     * @return
     */
    public int suffixDetect(String term) {
        Matcher matcher = SUFFIX_PATTERN.matcher(term);
        boolean isSuffix = matcher.matches();
        char[] characters = term.toCharArray();
        if (!isSuffix) {
            return characters.length - 1;
        }
        for (int i = characters.length - 1; i > 0; i--) {
            if (CharacterUtils.isChinese(characters[i])) {
                return i;
            }
        }
        return -1;
    }


    public boolean isEpisodeMark(String text) {
        if (EPISODE_PATTERN.matcher(text).matches() ||
                NUMBER_PATTERN.matcher(text).matches()) {
            return true;
        }
        return false;
    }

    public boolean isVersionMark(String text) {
        if (VERSION_PATTERN.matcher(text).matches()) {
            return true;
        }
        return false;
    }

    public boolean isDateMark(String text) {
        if (MONTH_PATTERN.matcher(text).matches()) {
            return true;
        }
        return false;
    }
}
