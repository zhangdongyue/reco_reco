package com.tudou.recommend.up.odps.newtd;

import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

import org.apache.commons.lang3.StringUtils;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.proto.ProtoCommon.ItemType;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.newtd.entity.TudouLog;

/**
 * 拼接视频特征和日志，并转换成统一的日志格式
 * 
 * @author zengtao
 *
 */
public class TudouLogConvertor {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class TudouLogConvertorMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private String logDataTableName;
		private String itemInfoDataTableName;
		private int joinShuffleFactor;
		private HashSet<String> appNameSet = new HashSet<String>();
		private int count = 0;
		private String tableName;

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			JobConf jobConf = context.getJobConf();

			logDataTableName = jobConf.get("logDataTableName");
			itemInfoDataTableName = jobConf.get("itemInfoDataTableName");
			joinShuffleFactor = jobConf.getInt("joinShuffleFactor", 0);
			String[] appNames = jobConf.get("appNameList", "").split(",", -1);
			for (String appName : appNames) {
				if (!appName.isEmpty())
					appNameSet.add(appName);
			}
			tableName = context.getInputTableInfo().getTableName();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			if (tableName.equalsIgnoreCase(logDataTableName)) {
				TudouLog log = new TudouLog();
				if (!log.parseFromStr(record.getString(0))) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_tudou_log").increment(1L);
					return;
				}
				if (!appNameSet.isEmpty() && !appNameSet.contains(log.appName)) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"filtered_by_app_name").increment(1L);
					return;
				}
				if (log.vdoId.isEmpty() || log.vdoTitle.isEmpty()) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"empty_vdo_id_or_title").increment(1L);
					return;
				}

				// merge log 打散后分发，避免把reduce内存打爆
				v2.setString(0, "2:" + log.convertToMergeLog().toString());
				if (joinShuffleFactor <= 1) {
					k2.setString(0, log.vdoId);
					context.write(k2, v2);
				} else {
					k2.setString(0, log.vdoId + "_" + count);
					context.write(k2, v2);
					;
					count = (count + 1) % joinShuffleFactor;
				}
			} else if (tableName.equalsIgnoreCase(itemInfoDataTableName)) {
				String vdoId = record.getString(0).split("\t", -1)[0];
				String vdoLen = record.getString(0).split("\t", -1)[1];
				StringBuilder sb = new StringBuilder();
				String sep = "::";

				// item type ~ isGlobalManual
				sb.append(vdoId).append("\t");
				sb.append(ItemType.kPureVideo.toString()).append("\t");
				sb.append("0");

				String parentCategory = "";
				String categorys = record.getString(2);
				if (categorys != null) {
					for (String category : categorys.split("\t", -1)) {
						if (category.equals("未分类"))
							break;

						String fullCategory;
						if (parentCategory.length() == 0) { // 一级类别
							fullCategory = category;
						} else { // 子类别
							fullCategory = parentCategory
									+ Contents.CATEGORY_SEP + category;
						}
						parentCategory = fullCategory;
						double weight = 1; // category 权重设为1
						if (sb.length() > 0) {
							sb.append("\t");
						}
						sb.append(ProfileFeatureType.VIDEO_CATEGORY.getValue())
								.append(sep).append(fullCategory).append(sep)
								.append(weight);
					}

				}
				String level1Category = "";
				if (StringUtils.isNotBlank(categorys)) {
					level1Category = categorys.split("\t", -1)[0];
				} else {
					level1Category = "未分类";
				}

				// tag
				String tags = record.getString(1);
				if (tags != null) {
					for (String tag : tags.split("\t", -1)) {
						String tagStr = level1Category + Contents.CATEGORY_SEP
								+ tag;
						if (sb.length() > 0) {
							sb.append("\t");
						}
						sb.append(ProfileFeatureType.VIDEO_TAG.getValue())
								.append(sep).append(tagStr).append(sep)
								.append(1.0);
					}
				}
				// video length
				if (sb.length() > 0) {
					sb.append("\t");
				}
				sb.append(ProfileFeatureType.VIDEO_LENGTH.getValue()).append(sep)
						.append(vdoLen).append(sep).append(1);

				// item info 重复分发，避免把reduce内存打爆
				v2.setString(0, "1:" + sb.toString());
				if (joinShuffleFactor <= 1) {
					k2.setString(0, vdoId);
					context.write(k2, v2);
				} else {
					for (int prefix = 0; prefix < joinShuffleFactor; ++prefix) {
						k2.setString(0, vdoId + "_" + prefix);
						context.write(k2, v2);
					}
				}
			} else {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_input_source").increment(1L);
				return;
			}
		}
	}

	public static class TudouLogConvertorReducer extends ReducerBase {
		private Record result;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			String itemInfoStr = "";
			LinkedList<String> logs = new LinkedList<String>();
			String itemStr;
			String valueStr;
			String tag;
			while (values.hasNext()) {
				itemStr = values.next().getString(0);
				tag = itemStr.substring(0, 2);
				valueStr = itemStr.substring(2);
				if (tag.equals("1:")) {
					if (valueStr.length() > itemInfoStr.length()) {
						itemInfoStr = valueStr;
					}
				} else if (tag.equals("2:")) {
					logs.add(valueStr);
				} else {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_input_source").increment(1L);
					continue;
				}
			}
			for (String log : logs) {
				result.setString(0, log);
				result.setString(1, itemInfoStr);
				context.write(result);
				if (itemInfoStr.isEmpty()) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"merge_log_without_item_info").increment(1L);
				} else {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"merge_log_with_item_info").increment(1L);
				}
			}
		}

	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("v2:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput());
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(TudouLogConvertorMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(TudouLogConvertorReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		MrJobParamSetter.setSplitSize(job, 128L);

		job.set("logDataTableName", argContainer.getLogDataDir());
		job.set("itemInfoDataTableName", argContainer.getItemInfoDataDir());
		job.setInt("joinShuffleFactor", argContainer.getJoinShuffleFactor());
		job.set("appNameList", argContainer.getAppNameList());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-logDataTableName", description = "")
		private String logDataTableName = "logDataTableName";

		@Parameter(names = "-itemInfoDataTableName", description = "")
		private String itemInfoDataTableName = "itemInfoDataTableName";

		@Parameter(names = "-joinShuffleFactor", description = "")
		private int joinShuffleFactor = 0;

		@Parameter(names = "-appNameList", description = "")
		private String appNameList = "";

		public String getLogDataDir() {
			return logDataTableName;
		}

		public void setLogDataDir(String logDataDir) {
			this.logDataTableName = logDataDir;
		}

		public String getItemInfoDataDir() {
			return itemInfoDataTableName;
		}

		public void setItemInfoDataDir(String itemInfoDataDir) {
			this.itemInfoDataTableName = itemInfoDataDir;
		}

		public String getAppNameList() {
			return appNameList;
		}

		public void setAppNameList(String appNameList) {
			this.appNameList = appNameList;
		}

		public int getJoinShuffleFactor() {
			return joinShuffleFactor;
		}

		public void setJoinShuffleFactor(int joinShuffleFactor) {
			this.joinShuffleFactor = joinShuffleFactor;
		}
	}
}
