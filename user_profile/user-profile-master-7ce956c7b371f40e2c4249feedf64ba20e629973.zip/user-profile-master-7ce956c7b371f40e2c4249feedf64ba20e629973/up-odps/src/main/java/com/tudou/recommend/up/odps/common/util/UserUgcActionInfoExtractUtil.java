package com.tudou.recommend.up.odps.common.util;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

import com.tudou.recommend.up.odps.common.entity.ActionTypes;
import com.tudou.recommend.up.odps.common.entity.log.MergeLog;

/**
 * UGC画像特征抽取
 * @author jinchanghu
 * @date 2018年1月4日 下午3:41:16
 */
public class UserUgcActionInfoExtractUtil {

  /**
   * 将用户的多种行为折合成点击次数
   * 
   * @param log
   *          merge log
   * @param actionWeights
   *          merge log中各种行为的权重
   * @return
   */
  public static float calcActionWeight(MergeLog log, HashMap<String, Float> actionWeights, double itemWeight) {
    float actionWeight = 0;
    int click = log.getClickSeconds() > 3 ? 1 : 0;
    int fav = log.getFavorite() > 0 ? 1 : 0;
    int share = log.getShareNum() > 0 ? 1 : 0;
    int agree = log.getAgree() > 0 ? 1 : 0;
    int disagree = log.getDisagree() > 0 ? 1 : 0;
    int cmt = log.getCommentNum() > 0 ? 1 : 0;
    int dislike = log.getDislike() > 0 ? 1 : 0;
    actionWeight += click * actionWeights.get(ActionTypes.RecoClick.getValue().toLowerCase()) + fav
        * actionWeights.get(ActionTypes.Favority.getValue().toLowerCase()) + share
        * actionWeights.get(ActionTypes.Share.getValue().toLowerCase()) + agree
        * actionWeights.get(ActionTypes.Agree.getValue().toLowerCase()) + disagree
        * actionWeights.get(ActionTypes.Disagree.getValue().toLowerCase()) + cmt
        * actionWeights.get(ActionTypes.Comment.getValue().toLowerCase()) + dislike
        * actionWeights.get(ActionTypes.Dislike.getValue().toLowerCase());
    actionWeight *= itemWeight;
    return actionWeight;
  }
  
  public static float calcActionWeight(MergeLog log, HashMap<String, Float> actionWeights) {
    return calcActionWeight(log, actionWeights, 1);
  } 
  
  /**
   * 统计不同阅读时间段的个数（碎片/连贯阅读）
   * 
   * @param recoTimestamps
   * @return
   */
  public static HashMap<String, Integer> statReadContinuous(HashMap<String, Long> recoTimestamps) {
    HashMap<String, Integer> statResults = new HashMap<String, Integer>();
    if (recoTimestamps == null || recoTimestamps.size() == 0) {
      return statResults;
    }

    // 推荐时间戳升序排列
    long[] arr = new long[recoTimestamps.size()];
    int idx = 0;
    for (String key : recoTimestamps.keySet()) {
      arr[idx++] = recoTimestamps.get(key);
    }
    Arrays.sort(arr);

    // 统计各阅读区段时长
    long readTime = 0;
    String readTimeRange;
    for (int i = 1; i < arr.length; ++i) {
      long diff = arr[i] - arr[i - 1];
      // 间隔大于10分钟被认为是另一次阅读
      if (diff > 10 * 60 * 1000) {
        readTimeRange = convertReadTimeLen(readTime);
        if (!statResults.containsKey(readTimeRange)) {
          statResults.put(readTimeRange, 0);
        }
        statResults.put(readTimeRange, statResults.get(readTimeRange) + 1);
        readTime = 0;
      } else {
        readTime += diff;
      }
    }
    readTimeRange = convertReadTimeLen(readTime);
    if (!statResults.containsKey(readTimeRange)) {
      statResults.put(readTimeRange, 0);
    }
    statResults.put(readTimeRange, statResults.get(readTimeRange) + 1);

    return statResults;
  }

  public static String convertReadTimeLen(long readSeconds) {
    String readTimeRange;
    if (readSeconds <= 10 * 60 * 1000) {
      readTimeRange = "VL";
    } else if (readSeconds > 10 * 60 * 1000 && readSeconds <= 30 * 60 * 1000) {
      readTimeRange = "L";
    } else if (readSeconds > 30 * 60 * 1000 && readSeconds <= 60 * 60 * 1000) {
      readTimeRange = "M";
    } else if (readSeconds > 60 * 60 * 1000 && readSeconds <= 120 * 60 * 1000) {
      readTimeRange = "H";
    } else {
      readTimeRange = "VH";
    }
    return readTimeRange;
  }
  
  public static String convertTextLength(int len){
    String lenRange;
    if (len < 1000) {
      lenRange = "短";
    } else if (len < 2000) {
      lenRange = "中";
    } else {
      lenRange = "长";
    }
    return lenRange;
  }
  
  public static String convertVideoLength(double len){
    String lenRange;
    if (len < 30) {
      lenRange = "短";
    } else if (len < 300) {
      lenRange = "中";
    } else {
      lenRange = "长";
    }
    return lenRange;
  }
  
  public static String convertTimeDuration(Long timestamp){
    Date date = new Date(timestamp);
    Calendar calendar = new GregorianCalendar();
    calendar.setTime(date);
    int hour = calendar.get(Calendar.HOUR_OF_DAY);
    String duration;
    if (hour >= 0 && hour < 6) {
      duration = "凌晨";
    } else if (hour >= 6 && hour < 9) {
      duration = "早晨";
    } else if (hour >= 9 && hour < 12) {
      duration = "上午";
    } else if (hour >= 12 && hour < 14) {
      duration = "中午";
    } else if (hour >= 14 && hour < 17) {
      duration = "下午";
    } else if (hour >= 17 && hour < 20) {
      duration = "傍晚";
    }else {
      duration = "晚上";
    }
    return duration;
  }
  
  public static int convertToWeekDay(Long timestamp){
    Date date = new Date(timestamp);
    Calendar cal = Calendar.getInstance();
    cal.setTime(date);
    int weekDay = cal.get(Calendar.DAY_OF_WEEK) -1;
    return weekDay;
  }
  
  public static int convertToHour(Long timestamp){
    Date date = new Date(timestamp);
    Calendar cal = Calendar.getInstance();
    cal.setTime(date);
    int hour = cal.get(Calendar.HOUR_OF_DAY);
    return hour;
  }
}
