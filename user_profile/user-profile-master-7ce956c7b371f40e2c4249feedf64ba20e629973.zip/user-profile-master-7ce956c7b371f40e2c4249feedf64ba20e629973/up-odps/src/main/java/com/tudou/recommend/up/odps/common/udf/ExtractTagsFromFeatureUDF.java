package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;

public class ExtractTagsFromFeatureUDF extends UDF {
	public String evaluate(String feature, String delimitor, String seperator, String weights) {
		if (feature == null || weights == null || delimitor == null || seperator == null) {
			return null;
		}
		
		if (feature.isEmpty() || delimitor.isEmpty() || seperator.isEmpty()) {
			return null;
		}
		
		StringBuilder sb = new StringBuilder();
		String[] tokens = feature.split(delimitor);
		for (int i = 0; i < tokens.length; i++) {
			String featureInfo = tokens[i].trim();
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String[] tokens1 = featureInfo.split(seperator);
			if (tokens1.length > 1) {
				if (i > 0) {
					sb.append(delimitor);
				}
				sb.append(tokens1[1]);
				sb.append(weights);
			}
		}
		
		if (sb.length() > 0) {
			return sb.toString();
		}
		
		return null;
	}
}
