package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;

public class ImfaMappingUDF extends UDF {
	public String evaluate(String imei, String idfa, String osName) {
		if(osName == null) {
			return "";
		}
		
		if("iOS".equals(osName) || "iPhone OS".equals(osName)) {
			if (DataFormatUtil.isValidIdfa(idfa)) {
				return idfa;
			} else {
				return "";
			}
		} else {
			if (DataFormatUtil.isValidImei(imei)) {
				return imei;
			} else {
				return "";
			}
		}
	}	
}
