package com.tudou.recommend.up.odps.iflow;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import com.tudou.recommend.up.odps.iflow.video.VideoMergeLogFilter;
import org.apache.log4j.Logger;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;

/**
 * 将不同时间桶上的用户行为聚合
 * 
 * @author zengtao
 *
 */
public class UserActionInfoMerger {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class UserActionInfoMergerMapper extends MapperBase {
		private Record k2;
		private Record v2;
		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			k2.setString(0, record.getString(0));
			v2.setString(0, record.getString(0));
			v2.setString(1, record.getString(1));
			v2.setString(2, record.getString(2));
			v2.setString(3, record.getString(3));
			context.write(k2, v2);
		}
	}

	public static class UserActionInfoMergerReducer extends ReducerBase {
		private static final Logger logger = Logger
				.getLogger(VideoMergeLogFilter.class);
		private Record result;
		private static final DecimalFormat DF = DataFormatUtil
				.getDefaultDecimalFormater();
		// 是否过滤非频繁兴趣
		private boolean doFilter = false;

		private Long startTime;
		private Long endTime;
		private int intervalInSeconds;
		private int bucketNum = 0;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
			JobConf conf = context.getJobConf();
			startTime = DataFormatUtil.getTimestamp(conf.get("startTime"));
			endTime = DataFormatUtil.getTimestamp(conf.get("endTime"));
			intervalInSeconds = Integer.parseInt(conf.get("intervalInSeconds"));
			bucketNum = DataFormatUtil.computeTimeBucketNum(startTime, endTime,
					intervalInSeconds);

			doFilter = conf.getBoolean("doFilter", false);
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			HashMap<String, float[]> weightSumMap = new HashMap<String, float[]>(); // 用户在fea上的权重和
			HashMap<String, float[]> clickSumMap = new HashMap<String, float[]>(); // 用户在fea上的总点击次数

			context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "user_id_num")
					.increment(1L);

			while (values.hasNext()) {
				Record record = values.next();
				// 判断时间戳格式是否合法
				Long timestamp = DataFormatUtil.getTimestamp(record
						.getString(1));
				if (timestamp == null) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"invalid_timestamp").increment(1L);
					continue;
				}
				if (timestamp >= endTime || timestamp < startTime) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"timestamp_out_of_range").increment(1L);
					continue; // 异常记录
				}
				int bucket = new Long((timestamp - startTime)
						/ (intervalInSeconds * 1000)).intValue();
				if (bucket >= bucketNum) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_bucket").increment(1L);
					continue;
				}
				String feaType = record.getString(2);
				String[] flds = record.getString(3).split("\t", -1);
				for (int i = 0; i < flds.length; ++i) {
					String[] feaFlds = flds[i].split("::", -1);
					String feaWithType = feaType + "\t" + feaFlds[0];
					float weight = 0;
					float click = 0;
					try {
						weight = Float.parseFloat(feaFlds[1]);
						click = Float.parseFloat(feaFlds[2]);
					} catch (Exception e) {
						logger.info(e.getMessage());
						context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
								"invalid_fld_num").increment(1L);
						continue;
					}

					if (!weightSumMap.containsKey(feaWithType)) {
						float[] arr = new float[bucketNum];
						Arrays.fill(arr, 0);
						weightSumMap.put(feaWithType, arr);
					}
					if (!clickSumMap.containsKey(feaWithType)) {
						float[] arr = new float[bucketNum];
						Arrays.fill(arr, 0);
						clickSumMap.put(feaWithType, arr);
					}
					weightSumMap.get(feaWithType)[bucket] += weight;
					clickSumMap.get(feaWithType)[bucket] += click;
				}
			}
			result.setString(0, key.getString(0));
			// output
			// key: profileKey
			// value: feaType ~ fea ~ [bucket : weightSum : clickSum]

			if (doFilter) {
				// 过滤掉非频繁的term
				// 获取活跃桶数，按一级category统计
				float[] cateNums = new float[bucketNum];
				float allClick = 0;
				for (String feaWithType : weightSumMap.keySet()) {
					String[] feaFlds = feaWithType.split("\t", -1);
					int feaType = Integer.parseInt(feaFlds[0]);
					String fea = feaFlds[1];
					if (feaType == ProfileFeatureType.CATEGORY.getValue()
							&& fea.indexOf(Contents.CATEGORY_SEP) < 0) {
						float[] clicks = clickSumMap.get(feaWithType);
						for (int n = 0; n < clicks.length; ++n) {
							cateNums[n] = cateNums[n] + clicks[n];
							allClick += clicks[n];
						}
					}
				}
				if (allClick < 30) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"inactive_user").increment(1L);
				}

				int numActiveBucketNum = getActiveBucketNum(cateNums, 3); // 活跃桶数
				int activeBucketThreshold = numActiveBucketNum / 3; // 最低活跃桶数

				for (String feaWithType : weightSumMap.keySet()) {
					int feaType = Integer.parseInt(feaWithType.substring(0,
							feaWithType.indexOf("\t")));
					float[] weights = weightSumMap.get(feaWithType);
					float[] clicks = clickSumMap.get(feaWithType);

					// 根据用户的活跃度调节阈值
					// TODO: 过滤参数需要实验调节
					int activeBucketNum = 0;
					if (feaType == ProfileFeatureType.CATEGORY.getValue()) {
						float thre = allClick / 30 > 2 ? 2 : allClick / 30;
						activeBucketNum = getActiveBucketNum(clicks, thre);
					}
					if (feaType == ProfileFeatureType.KEYWORD.getValue()
							|| feaType == ProfileFeatureType.TAG.getValue()) {
						float thre = allClick / 30 > 2 ? 2 : allClick / 30;
						activeBucketNum = getActiveBucketNum(clicks, thre);
					}
					if (feaType == ProfileFeatureType.TOPIC.getValue()
							|| feaType == ProfileFeatureType.PLSA_TOPIC
									.getValue()) {
						float thre = allClick / 30 > 2 ? 2 : allClick / 30;
						activeBucketNum = getActiveBucketNum(clicks, thre);
					} else {
						// 其它类型暂不参与过滤
						activeBucketNum = bucketNum;
					}

					// 过滤掉非频繁term
					if (activeBucketNum < activeBucketThreshold) {
						context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
								"filter_by_active_threshold").increment(1L);
						continue;
					}

					StringBuilder buf = new StringBuilder();
					for (int i = 0; i < weights.length; ++i) {
						// click为0的桶不输出，节省存储空间
						if (clicks[i] > 0) {
							if (buf.length() > 0) {
								buf.append(" ");
							}
							// 防止聚合后的weight出现负数
							buf.append(i)
									.append(":")
									.append(DF.format(weights[i] < 0 ? 0
											: weights[i]))
									.append(":")
									.append(DF.format(clicks[i] < 0 ? 0
											: clicks[i]));
						}
					}
					if (buf.length() > 0) {
						String[] splits = feaWithType.split("\t", -1);
						result.setString(1, splits[0]);
						result.setString(2, splits[1]);
						result.setString(3, buf.toString());
						context.write(result);
					}
				}
			} else {
				StringBuilder buf = new StringBuilder();
				for (String feaWithType : weightSumMap.keySet()) {
					float[] weights = weightSumMap.get(feaWithType);
					float[] clicks = clickSumMap.get(feaWithType);

					buf.delete(0, buf.length());
					for (int i = 0; i < weights.length; ++i) {
						// click为0的桶不输出，节省存储空间
						if (clicks[i] > 0) {
							if (buf.length() > 0) {
								buf.append(" ");
							}
							// 防止聚合后的weight出现负数
							buf.append(i)
									.append(":")
									.append(DF.format(weights[i] < 0 ? 0
											: weights[i]))
									.append(":")
									.append(DF.format(clicks[i] < 0 ? 0
											: clicks[i]));
						}
					}
					if (buf.length() > 0) {
						String[] splits = feaWithType.split("\t", -1);
						result.setString(1, splits[0]);
						result.setString(2, splits[1]);
						result.setString(3, buf.toString());
						context.write(result);
					}
				}
			}
		}

		private int getActiveBucketNum(float[] clicks, float clickThreshold) {
			int num = 0;
			for (double click : clicks) {
				if (click >= clickThreshold) {
					num++;
				}
			}
			return num;
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils
				.fromString("user_id:string,action_date:string,feature_type:string,feature:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {
				"user_id", "action_date", "feature_type", "feature" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(UserActionInfoMergerMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(UserActionInfoMergerReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		MrJobParamSetter.setSplitSize(job, 128L);

		job.set("startTime", argContainer.getStartTime());
		job.set("endTime", argContainer.getEndTime());
		job.set("intervalInSeconds", "" + argContainer.getIntervalInSeconds());
		job.setBoolean("doFilter", argContainer.isDoFilter());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {

		@Parameter(names = "-startTime", description = "start time")
		private String startTime = "20151001000000";

		@Parameter(names = "-endTime", description = "end time")
		private String endTime = "20151001000000";

		@Parameter(names = "-intervalInSeconds", description = "Interval In Seconds")
		private int intervalInSeconds = 3600 * 24 * 1;

		@Parameter(names = "-doFilter", description = "whether filter infrequent actions")
		private boolean doFilter = false;

		public String getStartTime() {
			return startTime;
		}

		public void setStartTime(String startTime) {
			this.startTime = startTime;
		}

		public String getEndTime() {
			return endTime;
		}

		public void setEndTime(String endTime) {
			this.endTime = endTime;
		}

		public int getIntervalInSeconds() {
			return intervalInSeconds;
		}

		public void setIntervalInSeconds(int intervalInSeconds) {
			this.intervalInSeconds = intervalInSeconds;
		}

		public boolean isDoFilter() {
			return doFilter;
		}

		public void setDoFilter(boolean doFilter) {
			this.doFilter = doFilter;
		}

	}
}
