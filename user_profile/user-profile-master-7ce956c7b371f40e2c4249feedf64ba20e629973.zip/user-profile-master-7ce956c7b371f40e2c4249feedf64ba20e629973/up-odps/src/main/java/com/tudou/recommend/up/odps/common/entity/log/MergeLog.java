package com.tudou.recommend.up.odps.common.entity.log;

import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.aliyun.odps.data.Record;

/**
 * merge log工具类
 * 
 * @author hezhimin
 *
 */
public class MergeLog {
	private static final Logger logger = Logger.getLogger(MergeLog.class);
	public static final String TOP_SEPERATOR = "\t``\t";

	public String[] flds = new String[] {}; // merge log字段

	public String userId = "";
	public String appName = "";
	public String time = "";
	public String recoId = "";
	public long channelId = -1;
	public String itemId = "";
	public int itemType = -1;
	public String source = "";
	public String title = "";
	public int clickSeconds = 0;
	public int shareNum = 0;
	public int commentNum = 0;
	public int favorite = 0;
	public int disagree = 0;
	public int agree = 0;
	public int dislike = 0;
	public float readProgress = 0;
	public String strategy = "";
	public int auto = 0;
	public String server = "";
	public String os = "";
	public String imei = "";
	public String utdid = "";
	public String mac = "";
	public String dn = "";
	public String sn = ""; // sn已基本废弃，用公参ni替代
	public String ni = "";
	public String city = "";
	public String province = "";
	public String gi = "";
	public String network = "";
	public String accountInfo = "";
	public int readSeconds = 0; // 阅读时长/视频播放时长

	public MergeLog() {
	}

	public String toString() {
		return toString("\t");
	}

	public String toString(String sep) {
		StringBuilder bld = new StringBuilder();
		bld.append(userId).append(sep).append(appName).append(sep).append(time)
				.append(sep).append(recoId).append(sep).append(channelId)
				.append(sep).append(itemId).append(sep).append(itemType)
				.append(sep).append(source).append(sep).append(title)
				.append(sep).append(clickSeconds).append(sep).append(shareNum)
				.append(sep).append(commentNum).append(sep).append(favorite)
				.append(sep).append(disagree).append(sep).append(agree)
				.append(sep).append(dislike).append(sep).append(readProgress)
				.append(sep).append(strategy).append(sep).append(auto)
				.append(sep).append(server).append(sep).append(os).append(sep)
				.append(imei).append(sep).append(utdid).append(sep).append(mac)
				.append(sep).append(dn).append(sep).append(sn).append(sep)
				.append(ni).append(sep).append(city).append(sep)
				.append(province).append(sep).append(gi).append(sep)
				.append(network).append(sep).append(accountInfo).append(sep)
				.append(readSeconds);

		return bld.toString();
	}

	public boolean parseFromStr(String logStr) {
		return parseFromStr(logStr, "\t");
	}

	public boolean parseFromStr(String logStr, String sep) {
		if (logStr == null || sep == null) {
			return false;
		}

		// merge log flds
		flds = logStr.split(sep, -1);
		int len = flds.length;
		if (flds.length < 1) {
			logger.error("error merge log: len = " + flds.length + " : "
					+ Arrays.toString(flds));
			return false;
		} else {
			try {
				int idx = 0;
				userId = flds[idx++];
				if (len > idx) {
					appName = flds[idx++];
				}
				if (len > idx) {
					time = flds[idx++];
				}
				if (len > idx) {
					recoId = flds[idx++];
				}
				if (len > idx) {
					channelId = parseLong(flds[idx++]);
				}
				if (len > idx) {
					itemId = flds[idx++];
				}
				if (len > idx) {
					itemType = parseInt(flds[idx++], -1);
				}
				if (len > idx) {
					source = flds[idx++];
				}
				if (len > idx) {
					title = flds[idx++];
				}
				if (len > idx) {
					clickSeconds = parseInt(flds[idx++]);
				}
				if (len > idx) {
					shareNum = parseInt(flds[idx++]);
				}
				if (len > idx) {
					commentNum = parseInt(flds[idx++]);
				}
				if (len > idx) {
					favorite = parseInt(flds[idx++]);
				}
				if (len > idx) {
					disagree = parseInt(flds[idx++]);
				}
				if (len > idx) {
					agree = parseInt(flds[idx++]);
				}
				if (len > idx) {
					dislike = parseInt(flds[idx++]);
				}
				if (len > idx) {
					readProgress = Float.parseFloat(flds[idx++]);
				}
				if (len > idx) {
					strategy = flds[idx++];
				}
				if (len > idx) {
					auto = parseInt(flds[idx++], 0);
				}
				if (len > idx) {
					server = flds[idx++];
				}
				if (len > idx) {
					os = flds[idx++];
				}
				if (len > idx) {
					imei = flds[idx++];
				}
				if (len > idx) {
					utdid = flds[idx++];
				}
				if (len > idx) {
					mac = flds[idx++];
				}
				if (len > idx) {
					dn = flds[idx++];
				}
				if (len > idx) {
					sn = flds[idx++];
				}
				if (len > idx) {
					ni = flds[idx++];
				}
				if (len > idx) {
					city = flds[idx++];
				}
				if (len > idx) {
					province = flds[idx++];
				}
				if (len > idx) {
					gi = flds[idx++];
				}
				if (len > idx) {
					network = flds[idx++];
				}
				if (len > idx) {
					accountInfo = flds[idx++];
				}
				if (len > idx) {
					readSeconds = parseInt(flds[idx++]);
				}
			} catch (Exception e) {
				logger.error(e.getMessage());
				return false;
			}
			return true;
		}
	}

	public boolean parseFromOrigMergeLog(String logStr) {
		if (logStr == null) {
			return false;
		} else {
			String[] logFlds = logStr.split("\t", -1);
			if (logFlds.length < 75) {
				return false;
			} else {
				try {
					flds = logFlds;
					time = flds[0];
					appName = flds[1];
					recoId = flds[2];
					itemId = flds[3];
					itemType = parseInt(flds[4], -1);
					channelId = parseLong(flds[5]);
					userId = flds[9];
					clickSeconds = parseInt(flds[10]);
					shareNum = parseInt(flds[11]);
					commentNum = parseInt(flds[12]);
					favorite = parseInt(flds[13]);
					strategy = flds[14];
					source = flds[15];
					title = flds[16];
					os = flds[26];
					city = flds[28];
					province = flds[29];
					imei = flds[30];
					mac = flds[31];
					utdid = flds[32];
					dn = flds[34];
					ni = flds[35];
					network = flds[39];
					server = flds[40];
					auto = parseInt(flds[45], 0);
					sn = flds[46];
					disagree = parseInt(flds[47]);
					agree = parseInt(flds[48]);
					dislike = parseInt(flds[49]);
					gi = flds[53];

					if (!flds[71].isEmpty() && StringUtils.isNumeric(flds[71])) {
						float progress = Integer.parseInt(flds[71]) / 10.0f;
						progress = progress < 0 ? 0 : progress;
						progress = progress > 1 ? 1 : progress;
						readProgress = progress;
					} else {
						readProgress = 0;
					}

					accountInfo = flds.length > 83 ? flds[83] : "";
					readSeconds = clickSeconds; // TODO
					return true;
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				}
			}
		}
	}

	public boolean parseFromOrigMergeLogRecord(Record r) {
		if (r == null) {
			return false;
		} else {
			try {
				time = r.getString("tm");
				appName = r.getString("appname");
				recoId = r.getString("recoid");
				itemId = r.getString("itemid");
				itemType = parseInt(r.getString("itemtype"), -1);
				channelId = parseLong(r.getString("cid"));
				userId = r.getString("userid");
				clickSeconds = parseInt(r.getString("click"));
				shareNum = parseInt(r.getString("share_count"));
				commentNum = parseInt(r.getString("cmt"));
				favorite = parseInt(r.getString("fav"));
				strategy = r.getString("strategy");
				source = r.getString("source");
				title = r.getString("title");
				os = r.getString("fr");
				city = r.getString("city");
				province = r.getString("prov");
				imei = r.getString("imei");
				mac = r.getString("mac");
				utdid = r.getString("utdid");
				dn = r.getString("dn");
				ni = r.getString("ni");
				network = r.getString("nt");
				server = r.getString("server");
				auto = parseInt(r.getString("auto"), 0);
				sn = r.getString("sn");
				disagree = parseInt(r.getString("disagree"));
				agree = parseInt(r.getString("agree"));
				dislike = parseInt(r.getString("dislike"));
				gi = r.getString("gi");

				if (!r.getString("progress").isEmpty()
						&& StringUtils.isNumeric(r.getString("progress"))) {
					float progress = Integer.parseInt(r.getString("progress")) / 10.0f;
					progress = progress < 0 ? 0 : progress;
					progress = progress > 1 ? 1 : progress;
					readProgress = progress;
				} else {
					readProgress = 0;
				}

				accountInfo = r.getString("client_user_info");
				readSeconds = clickSeconds; // TODO
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}
	}
	
	/**
	 * parse record from ads_up_log_join_feature_d
	 * add by jinchanghu. 20170704
	 * @param r
	 * @return
	 */
	public boolean parseFromAdsUpLogJoinFeature(Record r) {
		if (r == null) {
			return false;
		} else {
			try {
				time = r.getString("server_time");
				appName = r.getString("app_name");
				recoId = r.getString("se_id");
				itemId = r.getString("item_id");
				userId = r.getString("user_id");
				clickSeconds = parseInt(r.getString("ts"));
				title = r.getString("title");
				os = r.getString("os_name");
				imei = r.getString("imei");
				utdid = r.getString("utdid");
				network = r.getString("network");
				readSeconds = clickSeconds; 
				
				itemType = 30; 		//set video type 30
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}
	}
	
	/**
	 * parse record from ads_ugc_log_join_feature_d
	 * add by jinchanghu. 20180104
	 * @param r
	 * @return
	 */
	public boolean parseFromAdsUgcLogJoinFeature(Record r) {
		if (r == null) {
			return false;
		} else {
			try {
				time = r.getString("server_time");
				appName = r.getString("app_name");
				recoId = r.getString("reco_id");
				itemId = r.getString("item_id");
				userId = r.getString("user_id");
				clickSeconds = parseInt(r.getString("ts"));
				title = r.getString("title");
				os = r.getString("os_name");
				imei = r.getString("imei");
				utdid = r.getString("utdid");
				source = r.getString("source");
				readSeconds = clickSeconds; 
				
				itemType = 30; 		//set video type 30
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}
	}
	private int parseInt(String str, int defaultValue) {
		if (!str.isEmpty() && StringUtils.isNumeric(str)) {
			return Integer.parseInt(str);
		} else {
			return defaultValue;
		}
	}

	private int parseInt(String str) {
		return parseInt(str, 0);
	}

	private long parseLong(String str, long defaultValue) {
		if (!str.isEmpty() && StringUtils.isNumeric(str)) {
			return Long.parseLong(str);
		} else {
			return defaultValue;
		}
	}

	public boolean parseFromRelateLog(RelateLog log) {
		if (log == null) {
			return false;
		} else {
			this.flds = new String[75];
			Arrays.fill(this.flds, "");

			this.time = log.getTime();
			this.flds[0] = log.getTime();
			this.userId = log.getUserId();
			this.flds[9] = log.getUserId();
			this.appName = log.getAppName();
			this.flds[1] = log.getAppName();
			this.itemId = log.getRelatedItemId();
			this.flds[3] = log.getRelatedItemId();
			this.itemType = log.getRelatedItemType();
			this.flds[4] = String.valueOf(log.getRelatedItemType());
			this.clickSeconds = log.getClickSeconds();
			this.flds[10] = String.valueOf(log.getClickSeconds());
			this.utdid = log.getUtdid();
			this.flds[32] = log.getUtdid();
			return true;
		}
	}

	private long parseLong(String str) {
		return parseLong(str, 0L);
	}

	public String getTime() {
		return time;
	}

	public String getAppName() {
		return appName;
	}

	public String getRecoId() {
		return recoId;
	}

	public String getItemId() {
		return itemId;
	}

	public int getItemType() {
		return itemType;
	}

	public long getChannelId() {
		return channelId;
	}

	public String getUserId() {
		return userId;
	}

	/**
	 * 获取用户点击文章后阅读的时长，单位秒
	 * 
	 * @return
	 */
	public int getClickSeconds() {
		return clickSeconds;
	}

	public int getShareNum() {
		return shareNum;
	}

	public int getCommentNum() {
		return commentNum;
	}

	public int getFavorite() {
		return favorite;
	}

	public String getStrategy() {
		return strategy;
	}

	public String getSource() {
		return source;
	}

	public String getTitle() {
		return title;
	}

	public String getOs() {
		return os;
	}

	public String getImei() {
		return imei;
	}

	public String getUtdid() {
		return utdid;
	}

	public String getNetwork() {
		return network;
	}

	public String getServer() {
		return server;
	}

	/**
	 * 0: 主动刷新, 1:自动刷新
	 * 
	 * @return
	 */
	public int getAuto() {
		return auto;
	}

	public int getDisagree() {
		return disagree;
	}

	public int getAgree() {
		return agree;
	}

	public int getDislike() {
		return dislike;
	}

	/**
	 * 阅读比例
	 * 
	 * @return
	 */
	public float getReadProgress() {
		return readProgress;
	}

	public String[] getFlds() {
		return flds;
	}

	public String getMac() {
		return mac;
	}

	public String getDn() {
		return dn;
	}

	public String getSn() {
		return sn;
	}

	public String getNi() {
		return ni;
	}

	public String getCity() {
		return city;
	}

	public String getProvince() {
		return province;
	}

	public String getGi() {
		return gi;
	}

	public String getAccountInfo() {
		return accountInfo;
	}

}
