package com.tudou.recommend.up.odps.iflow.util;

import java.util.Date;

import com.aliyun.odps.data.Record;
import com.tudou.recommend.proto.ProtoCommon.CategoryFeatureVector;
import com.tudou.recommend.proto.ProtoCommon.FeatureVector;
import com.tudou.recommend.proto.ProtoUser.Profile;

/**
 * 工具类，将 video profile转化成 结构化ODPS表
 * 
 * @author hezhimin
 *
 */
public class VideoProfileConvertUtil {
	public static String getCategoryFeatureVectorStr(CategoryFeatureVector vec) {
		StringBuilder sb = new StringBuilder();
		if (vec == null)
			return sb.toString();

		for (int k = 0; k < vec.getFeatureCount(); ++k) {

			if (vec.getFeature(k).getLiteral().getLevel() == 1) {
				if (vec.getFeature(k).getLiteral().getParentsCount() > 0) {
					sb.append(vec.getFeature(k).getLiteral().getParents(0));
				}
				sb.append("`");
			}
			sb.append(vec.getFeature(k).getLiteral().getCategory())
					.append("::");
			sb.append(vec.getFeature(k).getWeight()).append("::");
			sb.append(vec.getFeature(k).getConfidence()).append(" | ");
		}
		if (sb.length() > 0) {
			sb.delete(sb.length() - 3, sb.length());
		}
		return sb.toString();

	}

	public static String getFeatureVectorStr(FeatureVector vec,
			boolean withCategory) {
		StringBuilder sb = new StringBuilder();
		if (vec == null)
			return sb.toString();
		for (int k = 0; k < vec.getFeatureCount(); ++k) {
			if (withCategory) {
				sb.append(vec.getFeature(k).getCategory()).append("`");
			}
			sb.append(vec.getFeature(k).getLiteral()).append("::");
			sb.append(vec.getFeature(k).getWeight()).append("::");
			sb.append(vec.getFeature(k).getConfidence()).append(" | ");
		}
		if (sb.length() > 0) {
			sb.delete(sb.length() - 3, sb.length());
		}
		return sb.toString();
	}

	public static String getFeatureVectorStr(FeatureVector vec) {
		return getFeatureVectorStr(vec, false);
	}

	public static void convertProfileToOdpsTable(Profile profile, Record record) {
		if (profile.hasLastUpdateTime()) {
			record.setDatetime("last_update_time",
					new Date(profile.getLastUpdateTime()));
		}
		if (profile.hasCategoryFeavec()) {
			record.setString("categories",
					getCategoryFeatureVectorStr(profile.getCategoryFeavec()));
		}
		if (profile.hasTagFeavec()) {
			record.setString("cate_tags",
					getFeatureVectorStr(profile.getTagFeavec(), true));
		}
		if (profile.hasKeywordFeavec()) {
			record.setString("cate_keywords",
					getFeatureVectorStr(profile.getKeywordFeavec(), true));
		}
		if (profile.hasTopicFeavec()) {
			record.setString("topics",
					getFeatureVectorStr(profile.getTopicFeavec()));
		}
		if (profile.hasPlsaTopicFeavec()) {
			record.setString("topics_with_cate",
					getFeatureVectorStr(profile.getPlsaTopicFeavec(), true));
		}
		if (profile.hasChannelFeavec()) {
			record.setString("channels",
					getFeatureVectorStr(profile.getChannelFeavec()));
		}
		if (profile.hasNegCategoryFeavec()) {
			record.setString("dislike_categories",
					getCategoryFeatureVectorStr(profile.getNegCategoryFeavec()));
		}
		if (profile.hasNegTagFeavec()) {
			record.setString("dislike_tags",
					getFeatureVectorStr(profile.getNegTagFeavec(), true));
		}
		if (profile.hasRegionFeavec()) {
			record.setString("item_regions",
					getFeatureVectorStr(profile.getRegionFeavec()));
		}
		if (profile.hasItemSourceFeavec()) {
			record.setString("item_sources",
					getFeatureVectorStr(profile.getItemSourceFeavec()));
		}
		if (profile.hasItemTypeFeavec()) {
			record.setString("item_types",
					getFeatureVectorStr(profile.getItemTypeFeavec()));
		}
		if (profile.hasResourceTypeFeavec()) {
			record.setString("resource_types",
					getFeatureVectorStr(profile.getResourceTypeFeavec()));
		}
		if (profile.hasItemDepthFeavec()) {
			record.setString("item_depthes",
					getFeatureVectorStr(profile.getItemDepthFeavec()));
		}
		if (profile.hasRecoStrategyFeavec()) {
			record.setString("reco_strategies",
					getFeatureVectorStr(profile.getRecoStrategyFeavec()));
		}
		if (profile.hasReadingDurationFeavec()) {
			record.setString("read_durations",
					getFeatureVectorStr(profile.getReadingDurationFeavec()));
		}
		if (profile.hasReadingLengthFeavec()) {
			record.setString("item_length",
					getFeatureVectorStr(profile.getReadingLengthFeavec()));
		}
		if (profile.hasReadingContinuousFeavec()) {
			record.setString("read_continuous",
					getFeatureVectorStr(profile.getReadingContinuousFeavec()));
		}
		if (profile.hasReadingTimeFea()) {
			record.setString("avg_read_time", profile.getReadingTimeFea()
					.getLiteral());
		}
		if (profile.hasVisitFrequency()) {
			record.setString("visit_frequency", profile.getVisitFrequency()
					.getLiteral());
		}
		if (profile.hasDirtyFea()) {
			record.setString("sex_preference", profile.getDirtyFea()
					.getLiteral());
		}
		if (profile.hasBluffingTitleFea()) {
			record.setString("bluffing_title_pref", profile
					.getBluffingTitleFea().getLiteral());
		}
		if (profile.hasPoliticsFea()) {
			record.setString("politics_perf", profile.getPoliticsFea()
					.getLiteral());
		}
		if (profile.hasVideoCategoryFeavec()) {
			record.setString("video_categories",
					getCategoryFeatureVectorStr(profile
							.getVideoCategoryFeavec()));
		} else {
			record.set("video_categories", null);
		}
		
		if (profile.hasVideoTagFeavec()) {
			record.setString("video_cate_tags",
					getFeatureVectorStr(profile.getVideoTagFeavec(), true));
		}
		if (profile.hasVideoTagWithoutCatFeavec()) {
			record.setString("video_tags",
					getFeatureVectorStr(profile.getVideoTagWithoutCatFeavec()));
		}
		if (profile.hasVideoClickNumFea()) {
			record.setDouble("video_click_num", Double.parseDouble(profile
					.getVideoClickNumFea().getLiteral()));
		}
		if (profile.hasVideoReadTimeFea()) {
			record.setDouble("video_read_time", Double.parseDouble(profile
					.getVideoReadTimeFea().getLiteral()));
		}
		if (profile.hasVideoReadHourFeavec()) {
			record.setString("video_read_hours",
					getFeatureVectorStr(profile.getVideoReadHourFeavec()));
		}
		if (profile.hasVideoReadWeekDayFeavec()) {
			record.setString("video_read_week_days",
					getFeatureVectorStr(profile.getVideoReadWeekDayFeavec()));
		}
		if (profile.hasVideoLengthFeavec()) {
			record.setString("video_length",
					getFeatureVectorStr(profile.getVideoLengthFeavec()));
		}
		if (profile.hasVideoNetworkFeavec()) {
			record.setString("video_networks",
					getFeatureVectorStr(profile.getVideoNetworkFeavec()));
		}
		if (profile.hasIsLoyalUser()) {
			record.setBoolean("is_loyal_user", profile.getIsLoyalUser());
		} else {
			record.set("is_loyal_user",null);
			
		}

	}

}
