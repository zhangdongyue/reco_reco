package com.tudou.recommend.up.odps.newtd.entity;

import com.tudou.recommend.up.odps.common.entity.log.MergeLog;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;

/**
 * 优土日志
 * 
 *
 */
public class TudouLog {
  public String utdid = ""; // utdid
  public String seId = ""; // session id
  public String serverTime = ""; // 时间戳

  public String vdoId = ""; // item ID
  public double vdoLen = 0; // 视频长度
  public String vdoTitle = ""; // 标题
  public String vdoType = ""; // 视频类型
  public String vdoDesc = ""; // 视频描述
  public String vdoEditorTitle = ""; // 编辑推荐标题
  public String vdoTags = ""; // 视频标签

  public String ip = "";
  public String mac = "";
  public String imei = "";
  public String idfa = "";

  public String netStatus = ""; // 网络状态
  public String network = ""; // 网络类型
  public double ts = 0; // 播放时长

  public String appName = ""; // 客户端名称

  public TudouLog() {
  }

  public String toString() {
    return toString("\t");
  }

  public String toString(String sep) {
    StringBuilder bld = new StringBuilder();
    bld.append(utdid).append(sep).append(seId).append(sep).append(serverTime).append(sep).append(vdoId).append(sep)
        .append(vdoLen).append(sep).append(vdoTitle).append(sep).append(vdoType).append(sep).append(vdoDesc)
        .append(sep).append(vdoEditorTitle).append(sep).append(vdoTags).append(sep).append(ip).append(sep).append(mac)
        .append(sep).append(imei).append(sep).append(idfa).append(sep).append(netStatus).append(sep).append(network)
        .append(sep).append(ts).append(sep).append(appName);

    return bld.toString();
  }

  public boolean parseFromStr(String logStr) {
    return parseFromStr(logStr, "\t");
  }

  public boolean parseFromStr(String logStr, String sep) {
    if (logStr == null || sep == null) {
      return false;
    }

    String[] flds = logStr.split(sep, -1);
    if (flds.length < 18) {
      return false;
    }
    utdid = flds[0];
    seId = flds[1];
    serverTime = flds[2];
    vdoId = flds[3];
    vdoLen = Double.parseDouble(flds[4]);
    vdoTitle = flds[5];
    vdoType = flds[6];
    vdoDesc = flds[7];
    vdoEditorTitle = flds[8];
    vdoTags = flds[9];
    ip = flds[10];
    mac = flds[11];
    imei = flds[12];
    idfa = flds[13];
    netStatus = flds[14];
    network = flds[15];
    ts = Double.parseDouble(flds[16]);
    appName = flds[17];

    return true;
  }

  /**
   * 转换成统一的merge log格式，方便后续走现有的视频画像生产流程
   * 
   * @return
   */
  public MergeLog convertToMergeLog() {
    MergeLog log = new MergeLog();

    log.utdid = utdid;
    // 新土豆专用appToken
    log.appName = appNameMapping(appName);
    // 生成 iflow user id
    log.userId = DataFormatUtil.GenUserKey(log.appName, log.utdid);
    log.time = serverTime;
    log.recoId = seId;
    log.itemId = vdoId;
    log.title = vdoTitle;
    log.clickSeconds = (int) ts;
    
    log.network = netWorkTypeMapping(network);
    
    // andriod 的 imei 和 ios的idfa都存放在 merge log的imei字段里，后续使用需要注意
    if (DataFormatUtil.isValidIdfa(idfa)) {
      log.imei = idfa;
    } else if (DataFormatUtil.isValidImei(imei)) {
      log.imei = imei;
    }

    // 播放比例
    if (ts <= 0) {
      log.readProgress = 0;
    } else {
      if (vdoLen > 0) {
        log.readProgress = Math.min((float) (ts / vdoLen), 1);
      }
    }

    return log;
  }

  public TudouItemInfo getItemInfo() {
    TudouItemInfo info = new TudouItemInfo();
    info.vdoId = vdoId;
    info.vdoLen = vdoLen;
    info.vdoTitle = vdoTitle;
    info.vdoType = vdoType;
    info.vdoDesc = vdoDesc;
    info.vdoEditorTitle = vdoEditorTitle;
    info.vdoTags = vdoTags;
	info.vdoSource = "优酷视频";

    return info;
  }
  
  //网络类型映射
  // 喜刷刷：0：wap，1：net，2：wifi，99：其它
  // 土豆：wifi;2G;3G;2G/3G;4G;WiFi; Wi-Fi; UNKNOWN; unknown
  private String netWorkTypeMapping(String network) {
    if (network == null || network.isEmpty()) {
      return "99";
    } else if ("2G".equals(network) || "2G/3G".equals(network)) {
      return "0";
    } else if ("3G".equals(network) || "4G".equals(network)) {
      return "1";
    } else if (network.equalsIgnoreCase("wifi") || network.equalsIgnoreCase("wi-fi")) {
      return "2";
    } else {
      return "99";
    }
  }
  
  // 设置app token
  private String appNameMapping(String appName) {
    if (appName == null || appName.isEmpty()) {
      return "";
    } else if (appName.equalsIgnoreCase("tudou_client")) {
      return "td";
    } else {
      return "yk";
    }
  }

}
