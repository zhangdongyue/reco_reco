package com.tudou.recommend.up.odps.common.entity.log;

import org.apache.commons.lang3.StringUtils;

/**
 * click log解析工具类
 * 
 * @author hezhimin
 *
 */
public class ClickLog {
  private String[] flds;
  
  private String actionType;
  private String recoId;
  private String itemId;
  private String userId;
  private String readId;
  private String childId;
  private String actionTime;
  private String content;
  private String appName;
  private String scene;
  private String acpfType;
  private String tacid;
  private String tuicid;
  private String utdid;

  public ClickLog() {
    flds = null;
  }

  public boolean parse(String logStr) {
    if (logStr == null) {
      return false;
    } else {
      String[] logFlds = logStr.split("\t", -1);
      if (logFlds.length < 17) {
        return false;
      } else {
        try{
          flds = logFlds;
          actionType = flds[0];
          recoId = flds[1];
          itemId = flds[2];
          userId = flds[3];
          readId = flds[4];
          actionTime = flds[6];
          content = flds[10];
          appName = flds[14];
          scene = flds[16];
          acpfType = flds.length > 17 ? flds[17] : "";
          tacid = flds.length > 18 ? flds[18] : "";
          tuicid = flds.length > 19 ? flds[19] : "";
          utdid = flds.length > 25 ? flds[25] : "";
          
          return true;
        } catch (Exception e) {
          e.printStackTrace();
          return false;
        }
      }
    }
  }
  
  private int parseInt(String str, int defaultValue){
    if(!str.isEmpty() && StringUtils.isNumeric(str)){
      return Integer.parseInt(str);
    }else{
      return defaultValue;
    }
  }
  
  private int parseInt(String str){
    return parseInt(str, 0);
  }
  
  private long parseLong(String str, long defaultValue){
    if(!str.isEmpty() && StringUtils.isNumeric(str)){
      return Long.parseLong(str);
    }else{
      return defaultValue;
    }
  }
  
  private long parseLong(String str){
    return parseLong(str, 0L);
  }

  public String[] getFlds() {
    return flds;
  }

  public String getActionType() {
    return actionType;
  }

  public String getRecoId() {
    return recoId;
  }

  public String getItemId() {
    return itemId;
  }

  public String getUserId() {
    return userId;
  }

  public String getReadId() {
    return readId;
  }

  public String getChildId() {
    return childId;
  }

  public String getActionTime() {
    return actionTime;
  }

  public String getContent() {
    return content;
  }

  public String getAppName() {
    return appName;
  }

  public String getScene() {
    return scene;
  }

  public String getAcpfType() {
    return acpfType;
  }

  public String getTacid() {
    return tacid;
  }

  public String getTuicid() {
    return tuicid;
  }

  public String getUtdid() {
    return utdid;
  }
  
}
