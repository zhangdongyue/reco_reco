package com.tudou.recommend.up.odps.newtd.entity;

/**
 * 优土视频item信息
 * 
 *
 */
public class TudouItemInfo {
  public String vdoId = ""; // item ID
  public double vdoLen = 0; // 视频长度
  public String vdoTitle = ""; // 标题
  public String vdoType = ""; // 视频类型
  public String vdoDesc = ""; // 视频描述
  public String vdoEditorTitle = ""; // 编辑推荐标题
  public String vdoTags = ""; // 视频标签
  public String vdoSource = ""; // 视频来源, 一般统一设成"优酷视频"

  public TudouItemInfo() {
  }
  
  public String toString() {
    return toString("\t");
  }
  
  public String toString(String sep) {
    StringBuilder bld = new StringBuilder();
    bld.append(vdoId).append(sep).append(vdoLen).append(sep).append(vdoTitle).append(sep)
    .append(vdoType).append(sep).append(vdoDesc).append(sep).append(vdoEditorTitle).append(sep)
    .append(vdoTags).append(sep).append(vdoSource);
    
    return bld.toString();
  }
  
  public boolean parseFromStr(String logStr) {
    return parseFromStr(logStr, "\t");
  }
  
  public boolean parseFromStr(String logStr, String sep) {
    if (logStr == null || sep == null) {
      return false;
    }
    
    String[] flds = logStr.split(sep, -1);
    if (flds.length < 8) return false;
    vdoId = flds[0];
    vdoLen = Double.parseDouble(flds[1]);
    vdoTitle = flds[2];
    vdoType = flds[3];
    vdoDesc = flds[4];
    vdoEditorTitle = flds[5];
    vdoTags = flds[6];
    vdoSource = flds[7];
    return true;
  }
}
