package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.googlecode.protobuf.format.JsonFormat;
import com.tudou.recommend.proto.ProtoItem;
import sun.misc.BASE64Decoder;

import java.io.IOException;

/**
 * @author wangfei01
 * @date 2017/12/6
 */
public class ItemParseUDF extends UDF{
    private BASE64Decoder decoder =new BASE64Decoder();
    public String evaluate(String rawItem) throws IOException {
        if(rawItem==null || rawItem.isEmpty()){
            return null;
        }
        byte[] decodeBuffer = decoder.decodeBuffer(rawItem);
        ProtoItem.RecoItem decodeItem = ProtoItem.RecoItem.parseFrom(decodeBuffer);
        ProtoItem.RecoItem itemProto = decodeItem.toBuilder()
                .clearSimFeature()
                .build();
        return JsonFormat.printToString(itemProto);
    }
}
