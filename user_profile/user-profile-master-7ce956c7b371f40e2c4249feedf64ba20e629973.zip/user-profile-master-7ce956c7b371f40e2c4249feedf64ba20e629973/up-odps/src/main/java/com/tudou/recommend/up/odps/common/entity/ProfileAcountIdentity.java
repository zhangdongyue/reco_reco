package com.tudou.recommend.up.odps.common.entity;

/**
 * 画像账号类型标识
 * @author hezhimin
 *
 */
public class ProfileAcountIdentity {
  /**
   * UC浏览器账号(目前所有第三方账户(微信、微博、淘宝、QQ)都会映射到一个uc账号)
   */
  public static final String UC = "UC";
  
}
