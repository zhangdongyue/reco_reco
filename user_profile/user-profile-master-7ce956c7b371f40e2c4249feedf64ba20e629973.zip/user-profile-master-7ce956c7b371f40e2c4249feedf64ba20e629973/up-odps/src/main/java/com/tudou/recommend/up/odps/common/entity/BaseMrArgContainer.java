package com.tudou.recommend.up.odps.common.entity;

import com.beust.jcommander.Parameter;


/**
 * MR job 配置参数基类
 * 
 * @author hezhimin
 * 
 */
public class BaseMrArgContainer extends BaseArgContainer {
  @Parameter(names = "-numReducer", description = "number of reducer")
  private int numReducer = -1;

  @Parameter(names = "-numMapper", description = "number of mapper")
  private int numMapper = -1;
  
  @Parameter(names = "-mapperInputSplitNumLimit", description = "limit of mapper input split number")
  private int mapperInputSplitNumLimit = 100000000;

  @Parameter(names = "-mapperMemoryLimit", description = "limit of mapper memory size (GB)")
  private int mapperMemoryLimit = 1;

  @Parameter(names = "-reducerMemoryLimit", description = "limit of reducer memory size (GB)")
  private int reducerMemoryLimit = 4;
  
  @Parameter(names = "-mapperVcoreNum", description = "mapper vcore num")
  private int mapperVcoreNum = 1;

  @Parameter(names = "-reducerVcoreNum", description = "reducer vcore num")
  private int reducerVcoreNum = 1;

  @Parameter(names = "-mapperTaskLimit", description = "limit of mapper task number")
  private int mapperTaskLimit = 4000;

  @Parameter(names = "-reducerTaskLimit", description = "limit of reducer task number")
  private int reducerTaskLimit = 2000;
  
  @Parameter(names = "-jobMemoryLimt", description = "limit of job memory (GB)")
  private int jobMemoryLimt = 1024 * 16;
  
  @Parameter(names = "-taskTimeoutSeconds", description = "limit of task timeout seconds")
  private int taskTimeoutSeconds = 20 * 60;

  public BaseMrArgContainer() {
  }

  public int getNumReducer() {
    return numReducer;
  }

  public void setNumReducer(int numReducer) {
    this.numReducer = numReducer;
  }

  public int getNumMapper() {
    return numMapper;
  }

  public void setNumMapper(int numMapper) {
    this.numMapper = numMapper;
  }

  public int getMapperMemoryLimit() {
    return mapperMemoryLimit;
  }

  public void setMapperMemoryLimit(int mapperMemoryLimit) {
    this.mapperMemoryLimit = mapperMemoryLimit;
  }

  public int getMapperInputSplitNumLimit() {
    return mapperInputSplitNumLimit;
  }

  public void setMapperInputSplitNumLimit(int mapperInputSplitNumLimit) {
    this.mapperInputSplitNumLimit = mapperInputSplitNumLimit;
  }

  public int getReducerMemoryLimit() {
    return reducerMemoryLimit;
  }

  public void setReducerMemoryLimit(int reducerMemoryLimit) {
    this.reducerMemoryLimit = reducerMemoryLimit;
  }

  public int getMapperTaskLimit() {
    return mapperTaskLimit;
  }

  public void setMapperTaskLimit(int mapperTaskLimit) {
    this.mapperTaskLimit = mapperTaskLimit;
  }

  public int getReducerTaskLimit() {
    return reducerTaskLimit;
  }

  public void setReducerTaskLimit(int reducerTaskLimit) {
    this.reducerTaskLimit = reducerTaskLimit;
  }

  public int getMapperVcoreNum() {
    return mapperVcoreNum;
  }

  public void setMapperVcoreNum(int mapperVcoreNum) {
    this.mapperVcoreNum = mapperVcoreNum;
  }

  public int getReducerVcoreNum() {
    return reducerVcoreNum;
  }

  public void setReducerVcoreNum(int reducerVcoreNum) {
    this.reducerVcoreNum = reducerVcoreNum;
  }

  public int getJobMemoryLimt() {
    return jobMemoryLimt;
  }

  public void setJobMemoryLimt(int jobMemoryLimt) {
    this.jobMemoryLimt = jobMemoryLimt;
  }

  public int getTaskTimeoutSeconds() {
    return taskTimeoutSeconds;
  }

  public void setTaskTimeoutSeconds(int taskTimeoutSeconds) {
    this.taskTimeoutSeconds = taskTimeoutSeconds;
  }

}
