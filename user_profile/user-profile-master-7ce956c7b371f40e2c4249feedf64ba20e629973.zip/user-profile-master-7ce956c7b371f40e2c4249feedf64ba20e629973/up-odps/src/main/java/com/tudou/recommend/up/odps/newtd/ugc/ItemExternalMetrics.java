package com.tudou.recommend.up.odps.newtd.ugc;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.util.BaseArgContainer;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Pipeline;
import redis.clients.jedis.Response;

import java.io.IOException;
import java.util.*;

/**
 * @author wangfei01
 * @date 2017/11/10
 */
public class ItemExternalMetrics {
    private static Argument argument = new Argument();

    public static void main(String[] args) throws OdpsException {
        JCommander commander = new JCommander(argument);
        commander.parse(args);
        Job job = new Job();
        job.set("redis.ip", argument.getRedisIp());
        job.setInt("redis.port", argument.getRedisPort());
        job.setInt("batch.size", argument.getBatchSize());
        MrJobParamSetter.addInput(job, argument.getInput(), new String[]{"itemid"});
        MrJobParamSetter.addOutput(job, argument.getOutput());
        job.setMapperClass(MetricsMapper.class);
        job.setReducerClass(MetricsReducer.class);
        job.setMapOutputKeySchema(SchemaUtils.fromString("itemid:string"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("count:bigint"));
        boolean flag = job.waitForCompletion();
        if (!flag) {
            System.exit(1);
        }
    }

    public static class Argument extends BaseArgContainer {
        @Parameter(names = "-redisIp")
        private String redisIp;

        @Parameter(names = "-redisPort")
        private Integer redisPort;

        @Parameter(names = "-batchSize")
        private Integer batchSize;

        public Integer getBatchSize() {
            return batchSize;
        }

        public void setBatchSize(Integer batchSize) {
            this.batchSize = batchSize;
        }

        public String getRedisIp() {
            return redisIp;
        }

        public void setRedisIp(String redisIp) {
            this.redisIp = redisIp;
        }

        public Integer getRedisPort() {
            return redisPort;
        }

        public void setRedisPort(Integer redisPort) {
            this.redisPort = redisPort;
        }
    }

    static class MetricsMapper extends MapperBase {
        private Record outputKey;
        private Record outputValue;

        @Override
        public void setup(TaskContext context) throws IOException {
            outputKey = context.createMapOutputKeyRecord();
            outputValue = context.createMapOutputValueRecord();
        }

        @Override
        public void map(long key, Record record, TaskContext context) throws IOException {
            String itemId = record.getString("itemid");
            outputKey.setString("itemid", itemId);
            outputValue.setBigint("count", 1L);
            context.write(outputKey, outputValue);
        }
    }

    static class MetricsReducer extends ReducerBase {
        private Logger logger = LoggerFactory.getLogger(this.getClass());
        private String redisIp;
        private Integer redisPort;
        private Jedis jedis;
        private Record output;
        private Integer batchSize;
        private Map<String, Response<List<String>>> requestMap;
        private Pipeline pipeline;
        private StopWatch stopWatch = new StopWatch();

        @Override
        public void setup(TaskContext context) throws IOException {
            JobConf conf = context.getJobConf();
            output = context.createOutputRecord();
            redisIp = conf.get("redis.ip");
            redisPort = conf.getInt("redis.port", 0);
            batchSize = conf.getInt("batch.size", 0);
            jedis = new Jedis(redisIp, redisPort);
            pipeline = jedis.pipelined();
            jedis.connect();
            requestMap = new HashMap<>();
        }

        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
            String itemid = key.getString("itemid");
            if (requestMap.size() < batchSize) {
                Response<List<String>> hmGet = pipeline.hmget("ItemLevel-" + itemid,
                        "SCommentCnt", "SUpCnt", "SDownCnt", "SReadCnt", "SShareCnt", "SFavCnt", "SPlayCnt");
                requestMap.put(itemid, hmGet);
            } else {
                stopWatch.reset();
                stopWatch.start();
                pipeline.sync();
                stopWatch.stop();
                logger.info("spend {} ms to request {} item info", stopWatch.getTime(), batchSize);
                Set<Map.Entry<String, Response<List<String>>>> set = requestMap.entrySet();
                for (Map.Entry<String, Response<List<String>>> entry : set) {
                    String requestKey = entry.getKey();
                    List<String> list = entry.getValue().get();
                    output.setString("itemid", requestKey);
                    output.setBigint("comm", getCount(list, 0));
                    output.setBigint("up", getCount(list, 1));
                    output.setBigint("down", getCount(list, 2));
                    output.setBigint("watch", getCount(list, 3));
                    output.setBigint("share", getCount(list, 4));
                    output.setBigint("fav", getCount(list, 5));
                    output.setBigint("play", getCount(list, 6));
                    context.write(output);
                }
                requestMap.clear();
            }
        }

        public Long getCount(List<String> list, int index) {
            if (list != null) {
                String value = list.get(index);
                if (value != null) {
                    return Long.parseLong(value);
                }
            }
            return null;
        }


        @Override
        public void cleanup(TaskContext context) throws IOException {
            pipeline.sync();
            Set<Map.Entry<String, Response<List<String>>>> set = requestMap.entrySet();
            for (Map.Entry<String, Response<List<String>>> entry : set) {
                String requestKey = entry.getKey();
                List<String> list = entry.getValue().get();
                output.setString("itemid", requestKey);
                output.setBigint("comm", getCount(list, 0));
                output.setBigint("up", getCount(list, 1));
                output.setBigint("down", getCount(list, 2));
                output.setBigint("watch", getCount(list, 3));
                output.setBigint("share", getCount(list, 4));
                output.setBigint("fav", getCount(list, 5));
                output.setBigint("play", getCount(list, 6));
                context.write(output);
            }
            requestMap.clear();
            jedis.close();
        }
    }
}

