package com.tudou.recommend.up.odps.iflow.video;

import java.io.IOException;
import java.util.*;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;

import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
/**
 * 
 * @author wj148482
 *
 */
public class ExtractItemSeq {
	private static MrArgContainer argContainer = new MrArgContainer();
	public static class Mapper extends MapperBase {
		private Record k2;
		private Record v2;
		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
		}
		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			k2.setString(0, record.getString(0)); // userid
			v2.setString(0, record.getString(1)); // tm
			v2.setString(1, record.getString(2)); // itemid
			v2.setString(2, record.getString(3));  // ince3_vec , 128  float , sep=":"
			context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "ItemSeq input").increment(1L);
			context.write(k2, v2);
		}
	}
	public static class Reducer extends ReducerBase {
		private Record result;
		private int step = 6;
		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();	
			JobConf conf = context.getJobConf();
			step = conf.getInt("step", 6);
		}
		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			HashMap<String,Long> itemTm = new HashMap<String, Long >();
			HashMap<String, String> itemInce = new HashMap<String, String>();
			long tm = 0l;
			int flag = 0;
			String tmStr="";
			String itemId = "";
			String ince = "";
			while (values.hasNext()) {
				Record r = values.next();
				tmStr = r.getString(0);
				itemId = r.getString(1);
				ince = r.getString(2);
				try{
					tm = Long.valueOf(tmStr.toString());
				}catch(NumberFormatException e){
					flag = -1;
				}
				if (0 != flag)
				{
					continue;
				}
				
				if (itemTm.containsKey(itemId))
				{
					if (itemTm.get(itemId) < tm)
					{
						itemTm.put(itemId, tm);
						itemInce.put(itemId, ince);
					}
				}
				else
				{
					itemTm.put(itemId, tm);
					itemInce.put(itemId, ince);
				}
							
				if (itemTm.size() > 200000)
				{
					break;
				}
			}
			// hashmap 排序			
			ArrayList<Map.Entry<String, Long>> list = new ArrayList<>(itemTm.entrySet());
            Collections.sort(list, new Comparator<Map.Entry<String, Long>>() {
	            public int compare(Map.Entry<String, Long> o1, Map.Entry<String, Long> o2) {
	                return o1.getValue().compareTo(o2.getValue());
	            }
	        });
            String tmList = "";
            String itemList = "";
            String inceList = "";
            
	        
	        if (list.size() > step)
	        {
	        	int len = list.size() / step * step;
	        	for (int i = 0; i < len; i=i+step)
	        	{
	        		tmList ="";
	        		itemList = "";
	        		inceList="";
	        		tmStr = "";
	        		itemId="";
	        		ince = "";
	        		for(int j = i; j < i+step; j++)
	        		{
	        			tmStr=list.get(j).getValue().toString();
	        			itemId=list.get(j).getKey();
	        			if (itemInce.containsKey(itemId))
	        			{
	        				ince=itemInce.get(itemId);
	        			}
	        			else
	        			{
	        				break;
	        			}
	        			// construct tm_list string
	        			if (0 == tmList.length())
	        			{
	        				tmList = tmStr;
	        			}
	        			else
	        			{
	        				tmList = tmList + ":" + tmStr;
	        			}
	        			// construct item_list string
	        			if (0 == itemList.length())
	        			{
	        				itemList = itemId;
	        			}
	        			else
	        			{
	        				itemList = itemList + ":" + itemId;
	        			}
	        			// construct ince list string
	        			if (0 == inceList.length())
	        			{
	        				inceList = ince;
	        			}
	        			else	
	        			{
	        				inceList = inceList + ":" + ince;
	        			}
	        			
	        		}
	        		result.setString(0, key.getString(0));
	        		result.setString(1, tmList);	// tm        		
	        		result.setString(2, itemList); // item list
	        		result.setString(3, inceList); // ince list
	        		context.write(result);
	        	}
	        }
        
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("tm :string ,itemId:string, ince:string"));
		MrJobParamSetter.addInput(job, argContainer.getInput());
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(Mapper.class);
		// TODO: specify a reducer
		job.setReducerClass(Reducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		job.setInt("step", argContainer.getStep());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}
	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-step", description = "set sequence size")
		private int step = 6;
		public MrArgContainer() {
		}
		public int getStep() {
			return step;
		}
		public void setStep(int step) {
			this.step = step;
		}
	}
}