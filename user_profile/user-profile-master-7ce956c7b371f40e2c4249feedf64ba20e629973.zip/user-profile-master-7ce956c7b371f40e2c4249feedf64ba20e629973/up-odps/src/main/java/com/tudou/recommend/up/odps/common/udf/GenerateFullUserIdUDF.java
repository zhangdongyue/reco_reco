package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;

public class GenerateFullUserIdUDF extends UDF {
	public String evaluate(String appName, String userId) {
		return	DataFormatUtil.GenUserKey(userId, appName);
	}
}
