package com.tudou.recommend.up.odps.common.util;

import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.tudou.recommend.up.odps.common.entity.RegexPatterns;


/**
 * 数据格式处理工具类
 */
public class DataFormatUtil {
  private static final Logger logger = Logger.getLogger(DataFormatUtil.class);
  private static DecimalFormat defaultDecimalFormater = new DecimalFormat("0.####");

  /**
   * 将java long字符串转化为unint 64字符串 
   * 一般用于从redis或hbase中读取unint64类型数据后做转换，以保持string结果和c++一致
   * @param longStr
   * @return
   */
  public static String longStrToULongStr(String longStr) {
    BigInteger TWO_64 = BigInteger.ONE.shiftLeft(64);
    BigInteger b = BigInteger.valueOf(Long.parseLong(longStr));
    if (b.signum() < 0) {
      b = b.add(TWO_64);
    }
    return b.toString();
  }
  
  /**
   * 将java long转化成unint 64 字符串
   * @param longValue
   * @return
   */
  public static String longStrToULongStr(long longValue){
    return longStrToULongStr(String.valueOf(longValue));
  }
  
  /**
   * 组合appName和userId,约定用"-"做连接符, 若appName为空或含有非法字符，则默认置为"uc"
   * note: appName中可能包含"-"字符,解析时应以最后一个"-"做分隔符
   * @param userId
   * @param appToken
   * @return
   */
  public static String GenUserKey(String userId, String appToken) {
    String prefix = appToken;
    if (appToken == null || appToken.isEmpty()) {
      prefix = "uc";
    } 
    return prefix + "-" + userId;
  }
  
  /**
   * 生成画像key
   * @param dataIdentity 数据标识
   * @param accountDeviceIdentity 账号/设备标识类型
   * @param value 账号/设备标识取值
   * @return
   */
  public static String GenProfileKey(String dataIdentity, String accountDeviceIdentity, String value) {
    if (dataIdentity == null) dataIdentity = "";
    if (accountDeviceIdentity == null) accountDeviceIdentity = "";
    if (value == null) value = "";
    return dataIdentity + "`" + accountDeviceIdentity + "`" + value;
  }
  
  /**
   * 根据app token和utdid生成喜刷刷user id (uint64)
   * @param appName
   * @param utdid
   * @return
   */
  /*
  public static String GenIflowUserId(String appName, String utdid) {
    UnsignedLong userId = UnsignedLong.ZERO;
    if (!StringUtils.isBlank(utdid)) {
      userId = UnsignedLong.valueOf(IflowUser.getUserId(appName, utdid));
    }
    return userId.toString();
  }*/
  
  public static String GenIflowUserId(String appName, String utdid) {
    return appName + '-' + utdid;
  }
  
  /**
   * 将字符串表示的时间转化成java时间戳(单位ms，转化成unix时间戳需要除以1000)
   * 支持的时间格式有：
   * 1）yyyy-MM-dd HH:mm:ss
   * 2) yyyy-MM-dd
   * 3) yyyyMMddHHmmss
   * 4) yyyyMMdd
   * @param timeStr
   * @return null表示转化失败
   */
  public static Long getTimestamp(String timeStr) {
    if(timeStr == null || timeStr.isEmpty()){
      return null;
    }
    
    Long timestamp = 0L;
    try {
      if (timeStr.contains("-")) {
        if(timeStr.length() <= 10 && timeStr.length() >= 8){
          SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
          timestamp = format.parse(timeStr).getTime();
        }else if(timeStr.length() <= 19 && timeStr.length() >= 14){
          SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
          timestamp = format.parse(timeStr).getTime();
        }else{
          logger.error("invalid time str: " + timeStr);
          return null;
        }
      } else {
        if(timeStr.length() == 14){
          SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
          timestamp = format.parse(timeStr).getTime();
        }else if(timeStr.length() == 8){
          SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
          timestamp = format.parse(timeStr).getTime();
        }else{
          logger.error("invalid time str: " + timeStr);
          return null;
        }
      }
      return timestamp;
    } catch (Exception e) {
      logger.error(e.getMessage());
      return null;
    }
  }
  
  /**
   * 将时间戳转化成可读字符串
   * @param timestamp
   * @return
   */
  public static String convertTimestampToStr(long timestamp){
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    return format.format(new Date(timestamp));
  }
  
  /**
   * 计算时间桶的个数
   * @param startTime 开始时间戳（毫秒）
   * @param endTime 结束时间戳（毫秒）
   * @param intervalInSeconds 时间桶长度（单位：秒）
   * @return -1表示参数非法
   */
  public static int computeTimeBucketNum(long startTime, long endTime, int intervalInSeconds){
    if(intervalInSeconds <= 0){
      return -1;
    }
    int bucketNum;
    long interval = endTime - startTime;
    if(interval < 0){
      return -1;
    }
    
    if(interval % (intervalInSeconds * 1000) == 0){
      bucketNum = new Long(interval/(intervalInSeconds * 1000)).intValue();
    }else{
      bucketNum = new Long(interval/(intervalInSeconds * 1000)).intValue() + 1;
    }
    return bucketNum;
  }
  
  /**
   * 计算时间桶的个数
   * @param startTime 开始时间
   * @param endTime 结束时间
   * @param intervalInSeconds 时间桶长度（单位：秒）
   * @return -1表示参数非法
   */
  public static int computeTimeBucketNum(Date startTime, Date endTime, int intervalInSeconds){
    if(startTime == null || endTime == null){
      return -1;
    }
    return computeTimeBucketNum(startTime.getTime(), endTime.getTime(), intervalInSeconds);
  }
  
  /**
   * 判断appName是否合法
   * 由于leaf在读profile时，直接使用客户端传回的app name拼user id
   * 所以此处也不对app name进行严格的合法性判断，仅判断是否包含非法字符和限制最大长度
   * @param appName
   * @return
   */
  public static boolean isValidAppName(String appName){
    if(appName == null || appName.length() > 64 || appName.contains("\t")){
      return false;
    }
    return true;
  }
  
  /**
   * 判断IDFA是否合法
   * @param idfa
   * @return
   */
  public static boolean isValidIdfa(String idfa) {
    if (idfa == null) {
      return false;
    } else {
      return RegexPatterns.IDFA_PATTERN.matcher(idfa).matches();
    }
  }
  
  /**
   * 判断IMEI是否合法
   * @param imei
   * @return
   */
  public static boolean isValidImei(String imei) {
    if (imei == null) {
      return false;
    } else {
      return RegexPatterns.IMEI_PATTERN.matcher(imei).matches();
    }
  }
  
  /**
   * 对字节数组进行切分
   * @param bytes
   * @param sep
   * @return
   */
  public static ArrayList<byte[]> splitByteArray(byte[] bytes, byte sep){
    ArrayList<byte[]> results = new ArrayList<byte[]>();
    if(bytes == null){
      return results;
    }
    
    int beginIndex = 0;
    for(int i=0; i<bytes.length; i++){
      if(bytes[i] == sep){
        results.add(Arrays.copyOfRange(bytes, beginIndex, i));
        beginIndex = i+1;
      }
    }
    results.add(Arrays.copyOfRange(bytes, beginIndex, bytes.length));
    return results;
  }
  
  /**
   * 对字节数组进行切分
   * @param bytes
   * @return
   */
  public static ArrayList<byte[]> splitByteArray(byte[] bytes){
    return splitByteArray(bytes, (byte)'\t');
  }

  public static DecimalFormat getDefaultDecimalFormater() {
    return defaultDecimalFormater;
  }
  
  /**
   * 拼接字符串集合
   * @param strs
   * @param sep
   * @return
   */
  public static String joinStrings(List<String> strs, String sep){
    StringBuilder builder = new StringBuilder();
    int num = 0;
    for (String str : strs) {
      if (num > 0) {
        builder.append(sep);
      }
      builder.append(str);
      num++;
    }
    return builder.toString();
  }
  
  /**
   * 拼接字符串数组
   * @param strs
   * @param sep
   * @return
   */
  public static String joinStrings(String[] strs, String sep){
    StringBuilder builder = new StringBuilder();
    int num = 0;
    for (String str : strs) {
      if (num > 0) {
        builder.append(sep);
      }
      builder.append(str);
      num++;
    }
    return builder.toString();
  }
  
}
