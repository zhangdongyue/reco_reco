package com.tudou.recommend.up.odps.iflow.mergelog;

import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.log.MergeLog;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;

/**
 * 从merge log中统计活跃item id
 * 
 */
public class ActiveItemIdFilter {
	public static MrArgContainer argContainer = new MrArgContainer();

	public static class ActiveItemIdFilterMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private HashSet<String> itemIds = new HashSet<String>();
		private boolean isOrigMergeLog;

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			v2.setString(0, "1");
			isOrigMergeLog = context.getJobConf().getInt("isOrigMergeLog", 1) == 1;
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			MergeLog log = new MergeLog();
			boolean ret;
			if (isOrigMergeLog) {
				ret = log.parseFromOrigMergeLog(record.getString(0));
			} else {
				ret = log.parseFromStr(record.getString(0));
			}
			if (!ret) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"failed_to_parse_merge_log").increment(1L);
				return;
			}
			String itemId = log.getItemId();

			// 剔除itemid = 0的情况
			if (!itemId.isEmpty() && !"0".equals(itemId)) {
				itemIds.add(itemId);
			} else {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"invalid_item_id").increment(1L);
			}
		}

		@Override
		public void cleanup(TaskContext context) throws IOException {
			if (itemIds != null) {
				for (String itemId : itemIds) {
					k2.setString(0, itemId);
					context.write(k2, v2);
				}
			}
		}
	}

	public static class ActiveItemIdFilterReducer extends ReducerBase {
		Record result;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			result.setString(0, key.getString(0));
			context.write(result);
		}

	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("v2:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(),
				new String[] { "log" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(ActiveItemIdFilterMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(ActiveItemIdFilterReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		//MrJobParamSetter.setSplitSize(job, 128L);

		job.setInt("isOrigMergeLog", argContainer.getIsOrigMergeLog());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-isOrigMergeLog", description = "")
		private int isOrigMergeLog = 1;

		public int getIsOrigMergeLog() {
			return isOrigMergeLog;
		}

		public void setIsOrigMergeLog(int isOrigMergeLog) {
			this.isOrigMergeLog = isOrigMergeLog;
		}

	}
}
