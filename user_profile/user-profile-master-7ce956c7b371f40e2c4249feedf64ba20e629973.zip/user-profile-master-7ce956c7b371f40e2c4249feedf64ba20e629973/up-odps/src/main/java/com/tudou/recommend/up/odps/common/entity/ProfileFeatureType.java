package com.tudou.recommend.up.odps.common.entity;

/**
 * 用户画像维度类型枚举(中间结果)
 * 注意: 千万不要随意修改各type对应的value值，否则会引起MR计算结果紊乱
 */
public enum ProfileFeatureType {
  /**
   * 类目
   */
  CATEGORY("category", 0),
  
  /**
   * 关键词
   */
  KEYWORD("keyword", 1),
  
  /**
   * 标签
   */
  TAG("tag", 2),
  
  /**
   * 主题
   */
  TOPIC("topic", 3),
  
  /**
   * PLSA 主题（分类目）
   */
  PLSA_TOPIC("plsa_topic", 4),
  
  /**
   * 频道点击
   */
  CHANNEL("channel", 5),
  
  /**
   * 事件标签
   */
  EVENT_TAG("event_tag", 6),

  /**
   * 标题 LDA 主题
   */
  TITLE_LDA_TOPIC("title_lda_topic", 7),

  /**
   * 正文 LDA 主题
   */
  CONTENT_LDA_TOPIC("content_lda_topic", 8),

  /**
   * 正文 SLDA 主题
   */
  CONTENT_SLDA_TOPIC("content_slda_topic", 9),

  /**
   * 不喜欢类目
   */
  NEG_CATEGORY("neg_category", 10),
  
  /**
   * 不喜欢关键词
   */
  NEG_KEYWORD("neg_keyword", 11),
  
  /**
   * 不喜欢标签
   */
  NEG_TAG("neg_tag", 12), 
  
  /**
   * 不喜欢主题
   */
  NEG_TOPIC("neg_topic", 13), 
  
  /**
   * 不喜欢源
   */
  NEG_ITEM_SOURCE("neg_item_source",14),
  
  /**
   * 文章地域
   */
  REGION("region", 31), 
  
  /**
   * 文章来源
   */
  ITEM_SOURCE("item_source", 41), 
  
  /**
   * item类型
   */
  ITEM_TYPE("item_type", 50), 
  
  /**
   * 资源类型
   */
  RESOURCE_TYPE("resource_type", 51), 
  
  /**
   * 类别
   */
  ITEM_DEPTH("item_depth", 52), 
  
  /**
   * 阅读类型
   */
  READING_TYPE("reading_type", 53), 
  
  /**
   * 推荐策略
   */
  RECO_STRATEGY("strategy", 60), 
  
  /**
   * 阅读时段
   */
  READING_DURATION("duration", 61), 
  
  /**
   * 阅读时长
   */
  READING_TIME("read_time", 62), 
  
  /**
   * 访问频次
   */
  VISIT_FREQ("visit_freq", 63), 
  
  /**
   * 文章长度
   */
  ITEM_LEN("item_len", 64), 
  
  /**
   * 阅读持续性
   */
  READ_CONTINUOUS("read_continuous", 65), 
  
  //低俗相关
  
  /**
   * 政治相关
   */
  IS_POLITICS("is_politics", 70),
  
  /**
   * 色情
   */
  IS_DIRTY("is_dirty", 71),
  
  /**
   * 标题党
   */
  IS_BLUFFING_TITLE("is_bluffing_title", 72),
  
  /**
   * 偏好政治
   */
  LIKE_POLITICS("like_politics", 80),
  
  /**
   * 偏好色情
   */
  LIKE_DIRTY("like_dirty", 81),
  
  /**
   * 偏好标题党
   */
  LIKE_BLUFFING_TITLE("like_bluffing_title", 82),
  
  /**
   * 容忍政治
   */
  TOLERATE_POLITICS("tolerate_politics", 90),
  
  /**
   * 容忍色情
   */
  TOLERATE_DIRTY("tolerate_dirty", 91),
  
  /**
   * 容忍标题党
   */
  TOLERATE_BLUFFING_TITLE("tolerate_bluffing_title", 92),
  
  /**
   * 反感政治
   */
  DISLIKE_POLITICS("dislike_politics", 100),
  
  /**
   * 反感色情
   */
  DISLIKE_DIRTY("dislike_dirty", 101),
  
  /**
   * 反感标题党
   */
  DISLIKE_BLUFFING_TITLE("dislike_bluffing_title", 102),
  
  /**
   * 政治反感度
   */
  POLITICS_TOLERANCE("politics_tolerance", 110),
  
  /**
   * 色情反感度
   */
  DIRTY_TOLERANCE("dirty_tolerance", 111),
  
  /**
   * 标题党反感度
   */
  BLUFFING_TITLE_TOLERANCE("bluffing_title_tolerance", 112),
  
  // 两性情感擦边球
  
  /**
   * 不喜欢两性情感
   */
  DISLIKE_EMOTION("dislike_emotion", 120),
  
  /**
   * 容忍两性情感
   */
  TOLERATE_EMOTION("tolerate_emotion", 121),
  
  /**
   * 喜欢两性情感
   */
  LIKE_EMOTION("like_emotion", 122),
  
  /**
   * 订阅的奥运标签
   */
  SUB_OLYM_TAG("sub_olym_tag", 130),
  
  /**
   * 搜索类目
   */
  SEARCH_CATEGORY("search_category", 140),
  
  /**
   * 搜索标签
   */
  SEARCH_TAG("search_tag", 141),
  
  /**
   * 搜索关键词
   */
  SEARCH_KEYWORD("search_keyword", 142),
  
  /**
   * 类目主动刷新次数（不含推荐和热点频道）
   */
  REFRESH_CATEGORY("refresh_category", 150),
  
  /**
   * 标签主动刷新次数（不含推荐和热点频道）
   */
  REFRESH_TAG("refresh_tag", 151),
  
  /**
   * 关键词主动刷新次数（不含推荐和热点频道）
   */
  REFRESH_KEYWORD("refresh_keyword", 152),
  
  /**
   * topic主动刷新次数（不含推荐和热点频道）
   */
  REFRESH_TOPIC("refresh_topic", 153),
  
  /**
   * plsa topic主动刷新次数（不含推荐和热点频道）
   */
  REFRESH_PLSA_TOPIC("refresh_plsa_topic", 154),
  
  /**
   * 频道主动刷新次数（含所有频道）
   */
  REFRESH_CHANNEL("refresh_channel", 155),
  
  /**
   * 类目阅读时长
   */
  READTIME_CATEGORY("read_time_category", 160),
  
  /**
   * 标签阅读时长
   */
  READTIME_TAG("read_time_tag", 161),
  
  /**
   * 关键词阅读时长
   */
  READTIME_KEYWORD("read_time_keyword", 162),
  
  /**
   * topic阅读时长
   */
  READTIME_TOPIC("read_time_topic", 163),
  
  /**
   * plsa topic 阅读时长
   */
  READTIME_PLSA_TOPIC("read_time_plsa_topic", 164),
  
  /**
   * 频道阅读时长
   */
  READTIME_CHANNEL("read_time_channel", 165),
  
  /**
   * 视频类目
   */
  VIDEO_CATEGORY("video_category", 170), 
  
  /**
   * 视频标签
   */
  VIDEO_TAG("video_tag", 171), 
  
  /**
   * 视频标签-不考虑item所属类别
   */
  VIDEO_TAG_WITHOUT_CATEGORY("video_tag_without_cat", 172), 
  
  /**
   * 视频点击总数
   */
  VIDEO_CLICK_SUM("video_click_sum", 175),
  
  /**
   * 视频点击占比
   */
  VIDEO_CLICK_RATIO("video_click_ratio", 176),
  
  /**
   * 视频观看时段（小时）偏好
   */
  VIDEO_DURATION("video_duration", 177),
  
  /**
   * 视频观看时段（week day）偏好
   */
  VIDEO_WEEK_DAY("video_week_day", 178),
  
  /**
   * 视频清晰度偏好
   */
  VIDEO_RESOLUTION("video_resolution", 179),
  
  /**
   * 视频长度偏好
   */
  VIDEO_LENGTH("video_length", 180),
  
  /**
   * 视频观看网络状态偏好
   */
  VIDEO_NETWORK("video_network", 181),
  
  /**
   * 视频观看总时长
   */
  VIDEO_READ_TIME("video_read_time", 182),

  /**
   * 视频来源
   */
  VIDEO_SOURCE("video_source", 183),
 
  /**
   * 实体标签
   */
  VIDEO_ENTITY_TAG("video_entity_tag", 184),

  /**
   * 语义标签
   */
  VIDEO_SEMANTIC_TAG("video_semantic_tag", 185),

  /**
   * 种子源上传者的职业
   */
  SEED_CAREER("seed_career", 186),
  /**
   * 种子源上传者的年龄
   */
  SEED_AGE("seed_age", 187),
  /**
   * 种子源上传者的性别
   */
  SEED_GENDER("seed_gender", 188),
  /**
   * 种子源上传者的地区
   */
  SEED_ADDRESS("seed_address", 189),
  /**
   * 是否是忠实用户
   */
  IS_LOYAL_USER("is_loyal_user", 190),
  
  /**
   * 种子源一级类目
   */
  SEED_CATEGORY("seed_category", 200),
  /**
   * 种子源二级类目
   */
  SEED_CATEGORY2("seed_category2", 201),
  /**
   * 种子源标签
   */
  SEED_TAG("seed_tag", 202),
  
  /**
   * 未知
   */
  UNKNOWN("unknown", -1);

  private String msg;
  private int value;

  private ProfileFeatureType(String msg, int value) {
    this.msg = msg;
    this.value = value;
  }

  public String getMsg() {
    return msg;
  }

  public void setMsg(String msg) {
    this.msg = msg;
  }

  public int getValue() {
    return value;
  }

  public void setValue(int value) {
    this.value = value;
  }
}
