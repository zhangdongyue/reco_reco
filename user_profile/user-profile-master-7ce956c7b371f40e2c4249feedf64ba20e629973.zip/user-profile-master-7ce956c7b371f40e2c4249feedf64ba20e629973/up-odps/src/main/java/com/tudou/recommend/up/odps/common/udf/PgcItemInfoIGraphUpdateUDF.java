package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.google.common.base.Splitter;
import com.taobao.igraph.client.core.IGraphClient;
import com.taobao.igraph.client.core.IGraphClientBuilder;
import com.taobao.igraph.client.core.RequestContext;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.util.Map;

/**
 * @author wangfei01
 * @date 2018/3/21
 */
public class PgcItemInfoIGraphUpdateUDF extends UDF {
    private IGraphClient client;


    public IGraphClient init(String searchDomain, String updateDomain) {
        IGraphClientBuilder builder = IGraphClientBuilder.create();
        builder.setSocketTimeout(500);
        builder.setConnectTimeout(500);
        builder.setConnectionRequestTimeout(500);
        builder.setSearchCluster("DEFAULT");
        builder.setUpdateCluster("DEFAULT");
        builder.setMaxConnTotal(512);
        builder.setMaxConnPerRoute(1);
        return builder.build("reco_pgc_odps_update_reco_item", searchDomain, updateDomain);
    }


    public String evaluate(
            String tableName,
            String pkey,
            String message,
            String searchDomain,
            String updateDomain) {
        if (client == null) {
            this.client = init(searchDomain, updateDomain);
        }
        for (int i = 0; i < 3; i++) {
            try {
                Map<String, String> messageMap = Splitter.on("&&&&").trimResults().withKeyValueSeparator("====").split(message);
                RequestContext requestContext = new RequestContext();
                client.update(requestContext, tableName, pkey, messageMap);
                break;
            } catch (Exception e) {
                System.out.println(ExceptionUtils.getStackTrace(e));
                System.out.println("retry update message:" + message + " for " + i + " times.");
                if (i == 2) {
                    return "Error:" + message;
                }
            }
        }
        return message;
    }
}
