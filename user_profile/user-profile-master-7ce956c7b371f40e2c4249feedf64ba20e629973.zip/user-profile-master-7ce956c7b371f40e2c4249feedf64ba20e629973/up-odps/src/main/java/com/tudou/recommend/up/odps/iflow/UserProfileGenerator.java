package com.tudou.recommend.up.odps.iflow;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.tudou.recommend.proto.ProtoUser.Profile;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.interest.InterestElem;
import com.tudou.recommend.up.odps.iflow.util.UserProfileGenerateUtil;
import com.tudou.recommend.up.odps.iflow.util.VideoProfileConvertUtil;

import org.apache.commons.lang3.StringUtils;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;

public class UserProfileGenerator {
    private static MrArgContainer argContainer = new MrArgContainer();

    public static class UserProfileGeneratorMapper extends MapperBase {
        private Record k2;
        private Record v2;

        @Override
        public void setup(TaskContext context) throws IOException {
            k2 = context.createMapOutputKeyRecord();
            v2 = context.createMapOutputValueRecord();
        }

        @Override
        public void map(long recordNum, Record record, TaskContext context)
                throws IOException {
            k2.setString(0, record.getString(0));
            v2.setString(0, record.getString(0));
            v2.setString(1, record.getString(1));
            v2.setString(2, record.getString(2));
            context.write(k2, v2);
        }
    }

    public static class UserProfileGeneratorReducer extends ReducerBase {
        private Record result;
        private String profileFieldType;
        private String userIdType;

        @Override
        public void setup(TaskContext context) throws IOException {
            result = context.createOutputRecord();
            profileFieldType = context.getJobConf().get("profileFieldType",
                    "kProfile");
            userIdType = context.getJobConf().get("userIdType", "imfa");
        }

        @Override
        public void reduce(Record key, Iterator<Record> values,
                           TaskContext context) throws IOException {
            // interest
            // feaType ~ feaHashCode ~ interestElem
            Map<Integer, Map<Integer, InterestElem>> interestsMap = new HashMap<>();
            Record r;
            while (values.hasNext()) {
                r = values.next();
                int feaType = Integer.parseInt(r.getString(1));
                if (!interestsMap.containsKey(feaType)) {
                    interestsMap.put(feaType, new HashMap<Integer, InterestElem>());
                }
                if (StringUtils.isNotBlank(r.getString(2))) {
                    UserProfileGenerateUtil.parseInterests(r.getString(2)
                            .split("\t", -1), interestsMap.get(feaType));
                }
            }

            // generate user profile
            Profile profile = UserProfileGenerateUtil
                    .generateUserProfile(interestsMap);
            if (profile == null) {
                context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
                        "failed_to_gen_profile").increment(1L);
                return;
            }

            if (!profile.isInitialized()) {
                context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
                        "profile_not_initialized").increment(1L);
                return;
            }

            String fullUserId = key.getString(0);
            String[] uidFlds = fullUserId.split("`", -1);
            VideoProfileConvertUtil.convertProfileToOdpsTable(profile, result);
            if ("uid".equalsIgnoreCase(userIdType)) {
                result.setString("full_user_id", fullUserId);
                result.setString("user_id", uidFlds[2]);
                result.setString("app_name", uidFlds[0]);
            } else {
                result.setString("full_user_id", fullUserId);
                result.setString("user_id", uidFlds[2]);
                result.setString("app_name", uidFlds[1]);
            }
            context.write(result);
        }

    }

    public static void main(String[] args) throws OdpsException {
        JCommander cmder = new JCommander(argContainer, args);
        if (argContainer.isHelp()) {
            cmder.usage();
            System.exit(Contents.SUCCED_CODE);
        }
        Job job = new Job();
        // TODO: specify map output types
        job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
        job.setMapOutputValueSchema(SchemaUtils
                .fromString("user_id:string,feature_type:string,interest:string"));

        MrJobParamSetter.addInput(job, argContainer.getInput(), new String[]{
                "user_id", "feature_type", "interest"});
        MrJobParamSetter.addOutput(job, argContainer.getOutput());
        // TODO: specify a mapper
        job.setMapperClass(UserProfileGeneratorMapper.class);
        // TODO: specify a reducer
        job.setReducerClass(UserProfileGeneratorReducer.class);
        if (argContainer.getNumReducer() > 0) {
            MrJobParamSetter.setNumReduceTasks(job,
                    argContainer.getNumReducer());
        }
        //MrJobParamSetter.setSplitSize(job, 128L);

        job.set("profileFieldType", argContainer.getProfileFieldType());
        job.set("userIdType", argContainer.getUserIdType());

        job.waitForCompletion();
        System.exit(job.isSuccessful() == true ? 0 : 1);
    }

    public static class MrArgContainer extends BaseMrArgContainer {
        @Parameter(names = "-expPrefix", description = "the prefix to note the exp")
        private String expPrefix = "";

        @Parameter(names = "-profileFieldType", description = "type of profile field: kProfile, kXssProfile")
        private String profileFieldType = "kProfile";

        @Parameter(names = "-userIdType", description = "user id/account type: default, uid, uc, uic")
        private String userIdType = "imfa";

        public String getExpPrefix() {
            return expPrefix;
        }

        public void setExpPrefix(String expPrefix) {
            this.expPrefix = expPrefix;
        }

        public String getProfileFieldType() {
            return profileFieldType;
        }

        public void setProfileFieldType(String profileFieldType) {
            this.profileFieldType = profileFieldType;
        }

        public String getUserIdType() {
            return userIdType;
        }

        public void setUserIdType(String userIdType) {
            this.userIdType = userIdType;
        }
    }
}
