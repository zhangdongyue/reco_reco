package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.ExecutionContext;
import com.aliyun.odps.udf.UDFException;
import com.aliyun.odps.udf.UDTF;
import com.aliyun.odps.utils.StringUtils;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.tudou.recommend.proto.ProtoCommon;
import com.tudou.recommend.proto.ProtoConvertorServer;
import com.wolong.protorpc.client.pool.PooledRpcClient;
import com.wolong.protorpc.client.protobuf.DefaultBlockingRpcChannel;
import com.wolong.protorpc.model.DefaultRpcController;
import com.wolong.protorpc.model.RpcClientConf;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import java.util.List;

/**
 * Created by Wangfei on 2017/4/20.
 */
public class UcTagRpcUDTF extends UDTF {
    private Logger logger = Logger.getLogger(this.getClass());
    private ProtoConvertorServer.ConvertorService.BlockingInterface convertService;
    private PooledRpcClient rpcClient;
    private String na62Addresses = "11.173.174.158:20021,11.173.176.165:20021,11.173.187.243:20021";
    private String na61Addresses = "11.139.111.73:20021,11.139.111.75:20021,11.139.111.77:20021";
    private int timeout = 2000;
    private int count = 0;
    private int retry = 5;

    @Override
    public void setup(ExecutionContext ctx) throws UDFException {
        try {
            super.setup(ctx);
            initClient();
        } catch (Exception e) {
            throw new UDFException(e);
        }
    }

    public String inputValue(Object[] args, int index) {
        if (index < args.length) {
            if (args[index] != null) {
                return args[index].toString();
            }
        }
        return null;
    }

    @Override
    public void process(Object[] args) throws UDFException {
        StopWatch watch = new StopWatch();
        count++;
        int length = Integer.parseInt(args[0].toString());
        int begin = length + 2;
        String splitter = inputValue(args, 1);
        Object[] output = new Object[length + 4];
        for (int i = 0; i < length; i++) {
            output[i] = args[i + 2];
        }

        String title = inputValue(args, begin + 0);
        String content = inputValue(args, begin + 1);
        String category = inputValue(args, begin + 2);
        String itemType = inputValue(args, begin + 3);
        String source = inputValue(args, begin + 4);

        ProtoConvertorServer.ExtractFeatureRequest.Builder builder = ProtoConvertorServer.ExtractFeatureRequest
                .newBuilder();
        builder.setReturnCategory(true)
                .setReturnTag(true);
        if (title == null) {
            forward(output);
        } else {
            builder.setTitle(title);
            if (content != null) {
                builder.setContent(content);
            }
            if (source != null) {
                builder.setSource(source);
            }
            if (itemType != null) {
                int type = Integer.parseInt(itemType);
                builder.setItemType(ProtoCommon.ItemType.valueOf(type));
            } else {
                builder.setItemType(ProtoCommon.ItemType.kPureVideo);
            }
            if (category != null) {
                builder.addCategory(category);
            }
            ProtoConvertorServer.ExtractFeatureRequest request = builder.build();
            ProtoConvertorServer.ExtractFeatureResponse response = null;
            DefaultRpcController controller = new DefaultRpcController();
            watch.start();
            try {
                response = convertService.extractFeature(controller, request);
            } catch (Exception e) {
                closeRpcClient();
                initClient();
            }
            watch.stop();
            logger.error("spend " + watch.getTime() + " ms to send request " + count);
            watch.reset();
            if (response == null || !response.getSuccess()) {
                logger.error(response);
                forward(output);
            } else {
                List<String> tagList = response.getTagsList();
                String tagResult = null;
                if (tagList != null) {
                    List<String> tags = Lists.transform(tagList, new Function<String, String>() {
                        @Override
                        public String apply(String s) {
                            return s.substring(s.indexOf(":") + 1, s.length());
                        }
                    });
                    tagResult = Joiner.on(splitter).join(tags).trim();
                }

                List<String> categoryList = response.getCategoryList();
                String categoriesResult = null;
                if (categoryList != null) {
                    List<String> categories = Lists.transform(categoryList, new Function<String, String>() {
                        @Override
                        public String apply(String s) {
                            return s.substring(s.indexOf(":") + 1, s.length());
                        }
                    });
                    categoriesResult = Joiner.on(splitter).join(categories).trim();
                }

                List<String> topicList = response.getPlsaList();
                String topicsResult = null;
                if (topicList != null) {
                    List<String> topics = Lists.transform(topicList, new Function<String, String>() {
                        @Override
                        public String apply(String s) {
                            return s.substring(s.indexOf(":") + 1, s.length());
                        }
                    });
                    topicsResult = Joiner.on(splitter).join(topics).trim();
                }

                List<String> keywordList = response.getKeywordsList();
                String keywordsResult = null;
                if (keywordList != null) {
                    Lists.transform(keywordList, new Function<String, String>() {
                        @Override
                        public String apply(String s) {
                            return s.substring(s.indexOf(":") + 1, s.length());
                        }
                    });
                    keywordsResult = Joiner.on(splitter).join(keywordList).trim();
                }
                output[length] = StringUtils.isEmpty(tagResult) ? null : tagResult;
                output[length + 1] = StringUtils.isEmpty(categoriesResult) ? null : categoriesResult;
                output[length + 2] = StringUtils.isEmpty(topicsResult) ? null : topicsResult;
                output[length + 3] = StringUtils.isEmpty(keywordsResult) ? null : keywordsResult;
                forward(output);
            }

        }
    }

    @Override
    public void close() throws UDFException {
        super.close();
        closeRpcClient();
    }

    public void initClient() {
        for (int i = 0; i < retry; i++) {
            try {
                RpcClientConf conf = new RpcClientConf(na61Addresses + "," + na62Addresses,
                        timeout, -1);
                conf.setvNodeNum(2048);
                conf.setEnableHA(true);
                conf.setMinActives(1);
                rpcClient = new PooledRpcClient(conf);
                rpcClient.bootstrap();
                convertService = ProtoConvertorServer.ConvertorService
                        .newBlockingStub(new DefaultBlockingRpcChannel(rpcClient));
                break;
            } catch (Exception e) {
                if (rpcClient != null) {
                    try {
                        rpcClient.stop();
                    } catch (Exception e1) {
                        logger.error("Get error trying to stop rpc client", e1);
                        if (i == (retry - 1)) {
                            throw e1;
                        }
                    }
                }
            }
        }
    }

    public void closeRpcClient() {
        for (int i = 0; i < retry; i++) {
            if (rpcClient != null && !rpcClient.isStopped()) {
                rpcClient.stop();
                break;
            }
        }
    }
}
