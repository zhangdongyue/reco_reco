package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.wolong.reco.common.entity.IflowUser;

/**
 * Generate user id from app name and UTDID.
 * app name: newtudou-iflow ...
 * UTDID: Alibaba device ID.
 *
 * @author wangfei01
 */
public class UserIdGeneratorUDF extends UDF {
    public String evaluate(String appName, String utdid) {
        if (appName == null || utdid == null) {
            return null;
        }
        return IflowUser.getUserId(appName, utdid);
    }
}
