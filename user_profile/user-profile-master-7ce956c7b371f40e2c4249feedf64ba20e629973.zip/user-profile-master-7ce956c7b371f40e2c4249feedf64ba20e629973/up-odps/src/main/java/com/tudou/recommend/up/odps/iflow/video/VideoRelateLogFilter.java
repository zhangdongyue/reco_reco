package com.tudou.recommend.up.odps.iflow.video;

import java.io.IOException;
import java.util.Iterator;

import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.log.MergeLog;
import com.tudou.recommend.up.odps.common.entity.log.RelateLog;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import org.apache.log4j.Logger;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;

/**
 * 过滤视频relate log
 */
public class VideoRelateLogFilter {
	private static final Logger logger = Logger
			.getLogger(VideoMergeLogFilter.class);
	public static MrArgContainer argContainer = new MrArgContainer();

	public static class VideoRelateLogFilterMapper extends MapperBase {
		private Record k2;
		private Record v2;

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			RelateLog log = new RelateLog();
			if (!log.parseFromRecord(record)) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_map_input").increment(1L);
				return;
			}

			// 过滤无效log
			String itemId = log.getRelatedItemId();
			String userId = log.getUserId();
			String appName = log.getAppName();
			int isShow = log.getIsShow();

			if (itemId.isEmpty() || "0".equals(itemId)) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "error_item_id").increment(1L);
				return;
			}
			if (userId.isEmpty() || "0".equals(userId)) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "error_user_id").increment(1L);
				return;
			}
			if (isShow <= 0) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"not_show_relate_log").increment(1L);
				return;
			}

			// 过滤视频中间页
			if (log.getRelatedItemType() != 30) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"not_video_log").increment(1L);
				return;
			}
			if (log.getOppo() != 15) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"not_video_mid_page").increment(1L);
				return;
			}

			MergeLog mergeLog = new MergeLog();
			if (!mergeLog.parseFromRelateLog(log)) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"fail_convert_to_merge_log").increment(1L);
				return;
			}

			k2.setString(0, DataFormatUtil.GenUserKey(userId, appName));
			v2.setString(0, mergeLog.toString());
			context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "video_log")
					.increment(1L);
			context.write(k2, v2);
		}
	}

	public static class VideoRelateLogFilterReducer extends ReducerBase {
		private Record result;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {

			while (values.hasNext()) {
				result.setString(0, values.next().getString(0));
				context.write(result);
			}
		}

	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("v2:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {
				"tm", "appname", "ref_read_id", "userid", "itemid",
				"item_type", "related_itemid", "related_item_type", "click",
				"oppo", "is_show", "utdid" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(VideoRelateLogFilterMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(VideoRelateLogFilterReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
	
		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);

	}

	public static class MrArgContainer extends BaseMrArgContainer {

	}
}
