package com.tudou.recommend.up.odps.iflow.util;

import com.tudou.recommend.proto.ProtoCommon.*;
import com.tudou.recommend.proto.ProtoUser;
import com.tudou.recommend.proto.ProtoUser.UgcProfile;
import com.tudou.recommend.proto.ProtoUser.VideoProfile;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;
import com.tudou.recommend.up.odps.common.entity.interest.InterestElem;
import org.apache.log4j.Logger;

import java.util.*;

public class VideoProfileGenerateUtil {
    private static final Logger logger = Logger.getLogger(VideoProfileGenerateUtil.class);

    public static boolean parseInterests(String features,
                                         Map<Integer, InterestElem> interestMap) {
        String[] featureArray = features.split("\t");
        for (String feature : featureArray) {
            String[] tokens = feature.split("::", -1);
            if (tokens.length < 3) {
                return false;
            }
            String term = tokens[0];
            float interest = Float.parseFloat(tokens[1]);
            float confidence = Float.parseFloat(tokens[2]);
            float ctr = tokens.length > 3 ? Float.parseFloat(tokens[3]) : 0;
            int sign = term.hashCode();
            InterestElem element = new InterestElem(term, "", interest, confidence, ctr);
            interestMap.put(sign, element);
        }
        return true;
    }

    /**
     * Generate Video Profile from all different feature types.
     *
     * @param interestsMap Collected feature type.
     * @return Pure video profile.
     */
    public static VideoProfile generatePureVideoProfile(Map<Integer,
            Map<Integer, InterestElem>> interestsMap) {
        ProtoUser.VideoProfile.Builder profileBuilder = ProtoUser.VideoProfile.newBuilder();
        boolean allNull = true;
        int featureType;

        // set the created time.
        profileBuilder.setLastUpdateTime(System.currentTimeMillis() / 1000);

        //video source preference
        featureType = ProfileFeatureType.VIDEO_SOURCE.getValue();
        if (interestsMap.containsKey(featureType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
            if (feaVec != null) {
                profileBuilder.setItemSourceFeavec(feaVec);
                allNull = false;
            }
        }
        //video title LDA topic preference.
        featureType = ProfileFeatureType.TITLE_LDA_TOPIC.getValue();
        if (interestsMap.containsKey(featureType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
            if (feaVec != null) {
                profileBuilder.setVideoTitleLda(feaVec);
                allNull = false;
            }
        }

        // video category
        featureType = ProfileFeatureType.VIDEO_CATEGORY.getValue();
        if (interestsMap.containsKey(featureType)) {
            CategoryFeatureVector feaVec = generateCategoryFeatureVec(interestsMap.get(featureType));
            if (feaVec != null) {
                profileBuilder.setVideoCategoryFeavec(feaVec);
                allNull = false;
            }
        }


        // video tag
        featureType = ProfileFeatureType.VIDEO_TAG.getValue();
        if (interestsMap.containsKey(featureType)) {
            FeatureVector feaVec = generateFeatureVecWithCate(interestsMap.get(featureType));
            if (feaVec != null) {
                profileBuilder.setVideoTagFeavec(feaVec);
                allNull = false;
            }
        }
        // video tag (without category)
        featureType = ProfileFeatureType.VIDEO_TAG_WITHOUT_CATEGORY.getValue();
        if (interestsMap.containsKey(featureType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
            if (feaVec != null) {
                profileBuilder.setVideoTagWithoutCatFeavec(feaVec);
                allNull = false;
            }
        }

        // video click sum
        featureType = ProfileFeatureType.VIDEO_CLICK_SUM.getValue();
        if (interestsMap.containsKey(featureType)) {
            Feature fea = generateFeature(interestsMap.get(featureType));
            if (fea != null) {
                profileBuilder.setVideoClickNum(Double.parseDouble(fea.getLiteral()));
                allNull = false;
            }
        }
        // video read time
        featureType = ProfileFeatureType.VIDEO_READ_TIME.getValue();
        if (interestsMap.containsKey(featureType)) {
            Feature fea = generateFeature(interestsMap.get(featureType));
            if (fea != null) {
                profileBuilder.setVideoReadTime(Double.parseDouble(fea.getLiteral()));
                allNull = false;
            }
        }
        // video duration
        featureType = ProfileFeatureType.VIDEO_DURATION.getValue();
        if (interestsMap.containsKey(featureType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
            if (feaVec != null) {
                profileBuilder.setVideoReadHourFeavec(feaVec);
                allNull = false;
            }
        }
        // video week day
        featureType = ProfileFeatureType.VIDEO_WEEK_DAY.getValue();
        if (interestsMap.containsKey(featureType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
            if (feaVec != null) {
                profileBuilder.setVideoReadWeekDayFeavec(feaVec);
                allNull = false;
            }
        }
        // video length
        featureType = ProfileFeatureType.VIDEO_LENGTH.getValue();
        if (interestsMap.containsKey(featureType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
            if (feaVec != null) {
                profileBuilder.setVideoLengthFeavec(feaVec);
                allNull = false;
            }
        }
        // video resolution

        // video network
        featureType = ProfileFeatureType.VIDEO_NETWORK.getValue();
        if (interestsMap.containsKey(featureType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
            if (feaVec != null) {
                profileBuilder.setVideoNetworkFeavec(feaVec);
                allNull = false;
            }
        }

        if (allNull) {
            return null;
        } else {
            return profileBuilder.build();
        }
    }
    
    /**
     * generate ugc profile.
     * @param interestsMap
     * @return
     */
    public static UgcProfile generateUgcVideoProfile(Map<Integer,
    		Map<Integer, InterestElem>> interestsMap) {
    	ProtoUser.UgcProfile.Builder profileBuilder = ProtoUser.UgcProfile.newBuilder();
    	boolean allNull = true;
    	int featureType;
    	
    	// set the created time.
    	profileBuilder.setLastUpdateTime(System.currentTimeMillis() / 1000);
    	
    	//video source preference
    	featureType = ProfileFeatureType.VIDEO_SOURCE.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setItemSourceFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed career preference.
    	featureType = ProfileFeatureType.SEED_CAREER.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setSeedCareerFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed age preference.
    	featureType = ProfileFeatureType.SEED_AGE.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setSeedAgeFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed gender preference.
    	featureType = ProfileFeatureType.SEED_GENDER.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setSeedGenderFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed gender preference.
    	featureType = ProfileFeatureType.SEED_ADDRESS.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setSeedAddressFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed category preference.(input video_category value)
    	featureType = ProfileFeatureType.VIDEO_CATEGORY.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		CategoryFeatureVector feaVec = generateCategoryFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setSeedCategoryFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed tag preference.
    	featureType = ProfileFeatureType.SEED_TAG.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setSeedTagFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	// video category
    	featureType = ProfileFeatureType.VIDEO_CATEGORY.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		CategoryFeatureVector feaVec = generateCategoryFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setVideoCategoryFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	    	
    	// video tag
    	featureType = ProfileFeatureType.VIDEO_TAG.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVecWithCate(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setVideoTagFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	// video tag (without category)
    	featureType = ProfileFeatureType.VIDEO_TAG_WITHOUT_CATEGORY.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setVideoTagWithoutCatFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	// video click sum
    	featureType = ProfileFeatureType.VIDEO_CLICK_SUM.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		Feature fea = generateFeature(interestsMap.get(featureType));
    		if (fea != null) {
    			profileBuilder.setVideoClickNum(Double.parseDouble(fea.getLiteral()));
    			allNull = false;
    		}
    	}
    	// video read time
    	featureType = ProfileFeatureType.VIDEO_READ_TIME.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		Feature fea = generateFeature(interestsMap.get(featureType));
    		if (fea != null) {
    			profileBuilder.setVideoReadTime(Double.parseDouble(fea.getLiteral()));
    			allNull = false;
    		}
    	}
    	// video duration
    	featureType = ProfileFeatureType.VIDEO_DURATION.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setVideoReadHourFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	// video week day
    	featureType = ProfileFeatureType.VIDEO_WEEK_DAY.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setVideoReadWeekDayFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	// video length
    	featureType = ProfileFeatureType.VIDEO_LENGTH.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setVideoLengthFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	// video resolution
    	
    	// video network
    	featureType = ProfileFeatureType.VIDEO_NETWORK.getValue();
    	if (interestsMap.containsKey(featureType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(featureType));
    		if (feaVec != null) {
    			profileBuilder.setVideoNetworkFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	if (allNull) {
    		return null;
    	} else {
    		return profileBuilder.build();
    	}
    }

    /**
     * 生成category feature proto
     *
     * @param categoryInterestMap
     * @param maxFeatureNumber    -1表示不按topN过滤
     * @return
     */
    private static CategoryFeatureVector generateCategoryFeatureVec(Map<Integer, InterestElem> categoryInterestMap,
                                                                    int maxFeatureNumber) {
        if (categoryInterestMap == null) {
            logger.error("failed to generate CategoryFeatureVector");
            return null;
        }

        ArrayList<InterestElem> interestElemArr = new ArrayList<InterestElem>();
        for (int sign : categoryInterestMap.keySet()) {
            InterestElem interestElem = categoryInterestMap.get(sign);
            int sepIndex = interestElem.term.indexOf(Contents.CATEGORY_SEP);
            if (sepIndex > 0) {
                interestElem.parent = interestElem.term.substring(0, sepIndex);
                interestElem.term = interestElem.term.substring(sepIndex + Contents.CATEGORY_SEP.length());
            } else {
                interestElem.parent = "";
            }
            interestElemArr.add(interestElem);
        }
        // sort and get topN interest
        sortFeatureVec(interestElemArr);
        List<InterestElem> topInterestElems = maxFeatureNumber > 0 ? getTopNInterestElem(interestElemArr,
                maxFeatureNumber) : interestElemArr;
        if (topInterestElems == null) {
            return null;
        }

        double norm = 0;
        CategoryFeatureVector.Builder featureVecBuilder = CategoryFeatureVector.newBuilder();
        for (int i = 0; i < topInterestElems.size(); ++i) {
            InterestElem elem = topInterestElems.get(i);
            CategoryFeature.Builder featureBuilder = CategoryFeature.newBuilder();
            if ("".equals(elem.parent)) { // 一级类目
                featureBuilder = featureBuilder.setWeight(elem.interest)
                        .setConfidence(elem.confidence)
                        .setUserCtr(elem.ctr)
                        .setItemType(ItemType.kPureVideo)
                        .setLiteral(Category.newBuilder()
                                .setCategory(elem.term)
                                .setLevel(0)
                                .build());
            } else {// 二级类目
                featureBuilder = featureBuilder.setWeight(elem.interest)
                        .setConfidence(elem.confidence)
                        .setUserCtr(elem.ctr)
                        .setItemType(ItemType.kPureVideo)
                        .setLiteral(Category.newBuilder()
                                .setCategory(elem.term)
                                .addParents(elem.parent)
                                .setLevel(1)
                                .build());
            }
            featureVecBuilder = featureVecBuilder.addFeature(featureBuilder.build());
            norm += elem.confidence;
        }
        featureVecBuilder = featureVecBuilder.setNorm(norm);
        return featureVecBuilder.build();
    }

    private static CategoryFeatureVector generateCategoryFeatureVec(Map<Integer,
            InterestElem> categoryInterestMap) {
        return generateCategoryFeatureVec(categoryInterestMap, -1);
    }

    /**
     * 生成feature vec proto， 设置category
     *
     * @param interestMap
     * @param maxFeatureNumber -1表示不按topN过滤
     * @return
     */
    private static FeatureVector generateFeatureVecWithCate(Map<Integer, InterestElem> interestMap, int maxFeatureNumber) {
        if (interestMap == null) {
            logger.error("failed to generate FeatureVec");
            return null;
        }

        ArrayList<InterestElem> interestElemArr = new ArrayList<InterestElem>();
        for (int sign : interestMap.keySet()) {
            InterestElem interestElem = interestMap.get(sign);
            int sepIndex = interestElem.term.indexOf(Contents.CATEGORY_SEP);
            if (sepIndex > 0) {
                interestElem.parent = interestElem.term.substring(0, sepIndex);
                interestElem.term = interestElem.term.substring(sepIndex + Contents.CATEGORY_SEP.length());
            } else {
                logger.error("invalid feature, no category found:" + interestElem.term);
                return null;
            }
            interestElemArr.add(interestElem);
        }
        // sort and get topN interest
        sortFeatureVec(interestElemArr);
        List<InterestElem> topInterestElems = maxFeatureNumber > 0 ? getTopNInterestElem(interestElemArr,
                maxFeatureNumber) : interestElemArr;
        if (topInterestElems == null) {
            return null;
        }

        double norm = 0;
        FeatureVector.Builder featureVecBuilder = FeatureVector.newBuilder();
        for (int i = 0; i < topInterestElems.size(); ++i) {
            InterestElem elem = topInterestElems.get(i);
            Feature.Builder featureBuilder = Feature.newBuilder()
                    .setCategory(elem.parent)
                    .setWeight(elem.interest)
                    .setConfidence(elem.confidence)
                    .setLiteral(elem.term)
                    .setItemType(ItemType.kPureVideo);
            featureVecBuilder = featureVecBuilder.addFeature(featureBuilder.build());
            norm += elem.confidence;
        }
        featureVecBuilder = featureVecBuilder.setNorm(norm);
        return featureVecBuilder.build();
    }

    private static FeatureVector generateFeatureVecWithCate(Map<Integer, InterestElem> interestMap) {
        return generateFeatureVecWithCate(interestMap, -1);
    }

    /**
     * 生成feature vec proto， 不设置category
     *
     * @param interestMap
     * @param maxFeatureNumber -1表示不按topN过滤
     * @return
     */
    private static FeatureVector generateFeatureVec(Map<Integer, InterestElem> interestMap,
                                                    int maxFeatureNumber) {
        if (interestMap == null) {
            logger.error("failed to generate TopicFeatureVec");
            return null;
        }

        ArrayList<InterestElem> interestElemArr = new ArrayList<InterestElem>();
        for (int sign : interestMap.keySet()) {
            InterestElem interestElem = interestMap.get(sign);
            interestElemArr.add(interestElem);
        }
        // sort and get topN interest
        sortFeatureVec(interestElemArr);
        List<InterestElem> topInterestElems = maxFeatureNumber > 0 ? getTopNInterestElem(interestElemArr,
                maxFeatureNumber) : interestElemArr;

        double norm = 0;
        FeatureVector.Builder featureVecBuilder = FeatureVector.newBuilder();
        for (int i = 0; i < topInterestElems.size(); ++i) {
            InterestElem elem = topInterestElems.get(i);
            Feature.Builder featureBuilder = Feature.newBuilder().setWeight(elem.interest).setConfidence(elem.confidence)
                    .setLiteral(elem.term).setItemType(ItemType.kPureVideo);

            featureVecBuilder = featureVecBuilder.addFeature(featureBuilder.build());
            norm += elem.confidence;
        }
        featureVecBuilder = featureVecBuilder.setNorm(norm);
        return featureVecBuilder.build();
    }

    private static FeatureVector generateFeatureVec(Map<Integer, InterestElem> interestMap) {
        return generateFeatureVec(interestMap, -1);
    }

    /**
     * 生成单个Feature
     *
     * @param interestMap
     * @return
     */
    private static Feature generateFeature(Map<Integer, InterestElem> interestMap) {
        if (interestMap == null || interestMap.size() != 1) {
            logger.error("failed to generate Feature");
            return null;
        }
        InterestElem elem = interestMap.values().iterator().next();

        Feature.Builder featureBuilder = Feature.newBuilder()
                .setWeight(elem.interest)
                .setConfidence(elem.confidence)
                .setLiteral(elem.term)
                .setItemType(ItemType.kPureVideo);
        return featureBuilder.build();
    }

    private static List<InterestElem> getTopNInterestElem(List<InterestElem> interestElemArr, int topN) {
        if (interestElemArr == null || topN < 0) {
            return null;
        }
        topN = topN < interestElemArr.size() ? topN : interestElemArr.size();
        return interestElemArr.subList(0, topN);
    }

    /**
     * 按weight降序排列
     *
     * @param interestElemArr
     */
    private static void sortFeatureVec(List<InterestElem> interestElemArr) {
        if (interestElemArr == null) {
            return;
        }

        // sort by interest desc
        // System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");
        Collections.sort(interestElemArr, new Comparator<InterestElem>() {
            @Override
            public int compare(InterestElem elem1, InterestElem elem2) {
                Double d1 = new Double(elem1.interest);
                Double d2 = new Double(elem2.interest);
                return Double.compare(d2, d1);
            }
        });
    }
}
