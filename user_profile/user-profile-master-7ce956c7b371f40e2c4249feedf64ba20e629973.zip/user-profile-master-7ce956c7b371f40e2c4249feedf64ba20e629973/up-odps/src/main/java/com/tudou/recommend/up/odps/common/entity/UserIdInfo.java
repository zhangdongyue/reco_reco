package com.tudou.recommend.up.odps.common.entity;

import com.aliyun.odps.data.Record;
import com.tudou.recommend.up.odps.common.entity.log.MergeLog;

public class UserIdInfo {
	public String appToken = "";
	public String userId = "";
	public String osType = "";
	public String imei = "";
	public String idfa = "";
	public String mac = "";
	public String utdid = "";
	public String dn = "";
	public String ni = "";
	public String province = "";
	public String city = "";
	public String gi = "";
	public String last_reco_time = "";

	public UserIdInfo() {

	}

	public UserIdInfo(MergeLog mergeLog) {
		appToken = mergeLog.getAppName();
		userId = mergeLog.getUserId();
		osType = mergeLog.getOs();

		// imei杂质清洗
		String imeiStr = mergeLog.getImei();
		int idx = imeiStr.indexOf("imei:");
		if (idx >= 0) {
			imeiStr = imeiStr.substring(idx + "imei:".length());
		}
		if (osType.equalsIgnoreCase("iphone")) {
			idfa = imeiStr;
		} else {
			this.imei = imeiStr;
		}
		mac = mergeLog.getMac();
		utdid = mergeLog.getUtdid();
		dn = mergeLog.getDn();
		ni = mergeLog.getNi();
		province = mergeLog.getProvince();
		city = mergeLog.getCity();
		gi = mergeLog.getGi();
		last_reco_time = mergeLog.getTime();
	}

	public String toString() {
		String sep = "\t";
		StringBuilder builder = new StringBuilder();
		builder.append(last_reco_time).append(sep);
		builder.append(appToken).append(sep);
		builder.append(userId).append(sep);
		builder.append(osType).append(sep);
		builder.append(imei).append(sep);
		builder.append(idfa).append(sep);
		builder.append(mac).append(sep);
		builder.append(utdid).append(sep);
		builder.append(dn).append(sep);
		builder.append(ni).append(sep);
		builder.append(province).append(sep);
		builder.append(city).append(sep);
		builder.append(gi);
		return builder.toString();
	}

	public static UserIdInfo parseFromString(String str, int start) {
		if (str == null) {
			return null;
		}
		if (start < 0) {
			return null;
		}
		String sep = "\t";
		String[] flds = str.split(sep, -1);
		if (flds.length != 13 + start) {
			return null;
		}
		UserIdInfo info = new UserIdInfo();
		info.last_reco_time = flds[0 + start];
		info.appToken = flds[1 + start];
		info.userId = flds[2 + start];
		info.osType = flds[3 + start];
		info.imei = flds[4 + start];
		info.idfa = flds[5 + start];
		info.mac = flds[6 + start];
		info.utdid = flds[7 + start];
		info.dn = flds[8 + start];
		info.ni = flds[9 + start];
		info.province = flds[10 + start];
		info.city = flds[11 + start];
		info.gi = flds[12 + start];
		return info;
	}

	public static UserIdInfo parseFromRecord(Record record) {
		if (record == null) {
			return null;
		}
		UserIdInfo info = new UserIdInfo();
		info.last_reco_time = record.getString("last_reco_time");
		info.appToken = record.getString("app_name");
		info.userId = record.getString("user_id");
		info.osType = record.getString("os_type");
		info.imei = record.getString("imei");
		info.idfa = record.getString("idfa");
		info.mac = record.getString("mac");
		info.utdid = record.getString("utdid");
		info.dn = record.getString("dn");
		info.ni = record.getString("sn");
		info.province = record.getString("province");
		info.city = record.getString("city");
		info.gi = record.getString("gi");
		return info;
	}

	public static UserIdInfo parseFromString(String str) {
		return parseFromString(str, 0);
	}
}
