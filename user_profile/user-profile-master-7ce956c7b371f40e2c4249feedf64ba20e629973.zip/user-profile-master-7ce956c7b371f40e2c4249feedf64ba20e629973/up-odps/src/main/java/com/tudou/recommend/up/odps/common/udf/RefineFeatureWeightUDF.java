package com.tudou.recommend.up.odps.common.udf;

import java.util.*;

import com.aliyun.odps.udf.UDF;

public class RefineFeatureWeightUDF extends UDF {
	public class TagNode {
		String tag;
		String feature;
		double weight;
		
		public TagNode(String tag, String feature, double weight) {
			this.tag = tag;
			this.feature = feature;
			this.weight = weight;
		}
		
		public String getKey() {
			return this.tag;
		}
		
		public double getValue() {
			return this.weight;
		}
	}
	
	public class SortByWeightAndTagDesc implements Comparator<TagNode> {
		public int compare(TagNode s1, TagNode s2) {
			if ( s1.weight > s2.weight) {
				return -1;
			} else if (s1.weight < s2.weight) {
				return 1;
			} else {
				return s1.tag.compareTo(s2.tag);
			}
		}
	}
	
	public String evaluate(String features, String featuresTune, String delimitor, String seperator) {
		if (features == null || delimitor == null || seperator == null) {
			return null;
		}
		
		if (features.isEmpty() || delimitor.isEmpty() || seperator.isEmpty() ) {
			return null;
		}
		
		if (featuresTune == null || featuresTune.isEmpty()) {
			return features;
		} 
		
		HashMap<String, Double> featureTuneMap = new HashMap<String, Double>();
		String[] tokens0 = featuresTune.split(delimitor);
		for (int i = 0; i < tokens0.length; i++) {
			String featureInfo = tokens0[i];
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String[] tokens = featureInfo.split(seperator);
			if (tokens.length > 1) {
				String feature = tokens[0];
				double weight = Double.parseDouble(tokens[1]);
				
				featureTuneMap.put(feature, weight);
			}
		}
		
		ArrayList<TagNode> tagList = new ArrayList<TagNode>();
		String[] tokens1 = features.split(delimitor);
		for (int i = 0; i < tokens1.length; i++) {
			String featureInfo = tokens1[i];
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String[] tokens = featureInfo.split(seperator);
			if (tokens.length >= 3) {
				if (!tokens[0].isEmpty()) {
					double weight = Double.parseDouble(tokens[1]);
					tagList.add(new TagNode(tokens[0], featureInfo, weight));
					
				}
			} 
		}

		// sort tag list 
		Collections.sort(tagList, new SortByWeightAndTagDesc());

		// generate result
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < tagList.size(); i++) {
			if (i > 0) {
				sb.append(delimitor);
			}

			TagNode tagNode = tagList.get(i);
			String tag = tagNode.tag;
			double weight = tagNode.weight;
			String feature = tagNode.feature;
			if (featureTuneMap.containsKey(tag)) {
				weight += featureTuneMap.get(tag);
			}
			
			String[] tokens = feature.split(seperator);
			
			for (int j = 0; j < tokens.length; j++) {
				if (j > 0) {
					sb.append(seperator);
				}
				
				if (j == 1) {
					sb.append(weight);
				} else {
					sb.append(tokens[j]);
				}
			}
			
		}
		if (sb.length() > 0) {
			return sb.toString();
		}
	
		return null;
	}
}
