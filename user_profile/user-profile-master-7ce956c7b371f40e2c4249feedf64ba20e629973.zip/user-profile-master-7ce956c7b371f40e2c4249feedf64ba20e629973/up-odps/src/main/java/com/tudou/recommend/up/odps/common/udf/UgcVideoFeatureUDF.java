package com.tudou.recommend.up.odps.common.udf;

import org.apache.commons.lang3.StringUtils;

import com.aliyun.odps.udf.UDF;
import com.tudou.recommend.proto.ProtoCommon.ItemType;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;

public class UgcVideoFeatureUDF extends UDF {
	public String evaluate(String seperator, String features) {
		if (features==null || features.isEmpty() || seperator==null || seperator.isEmpty()) {
			return null;
		}
		
		String[] tokens = features.split(seperator);
		if (tokens.length < 9) {
			return null;
		}
		
		String vdoId = tokens[0];
		String vdoLen = tokens[1];
		String vdoSource = tokens[2];
		String career = tokens[3];
		String age = tokens[4];
		String gender = tokens[5];
		String address = tokens[6];
		
		if ("NULL".equals(vdoId)) {
			return null;
		}
		
		StringBuilder sb = new StringBuilder();
		String sep = "::";
		
		// item type ~ isGlobalManual
		sb.append(vdoId).append("\t");
		sb.append(ItemType.kPureVideo.toString()).append("\t");
		sb.append("0");
		
		// category
		String parentCategory = "";
		String prefix = "manual:";
		String categorys = tokens[7];
		if (! "NULL".equals(categorys) && !categorys.isEmpty()) {
			if (categorys.startsWith(prefix)) {
				categorys = categorys.substring(prefix.length()); 
			}
			for (String category : categorys.split(",", -1)) {
				if ("未分类".equals(category)) {
					break;
				}
				
				String fullCategory;
				if (parentCategory.length() == 0) { // 一级类别
					fullCategory = category;
				} else { // 子类别
					fullCategory = parentCategory
							+ Contents.CATEGORY_SEP + category;
				}
				parentCategory = fullCategory;
				double weight = 1; // category 权重设为1
				if (sb.length() > 0) {
					sb.append("\t");
				}
				sb.append(ProfileFeatureType.VIDEO_CATEGORY.getValue())
				.append(sep).append(fullCategory).append(sep)
				.append(weight);
			}
			
		}
		String level1Category = "";
		if (StringUtils.isNotBlank(categorys)) {
			level1Category = categorys.split(",", -1)[0];
		} else {
			level1Category = "未分类";
		}
		
		// tag
		String tags = tokens[8];
		if (! "NULL".equals(tags) && !tags.isEmpty()) {
			for (String tag : tags.split("\t", -1)) {
				String tagStr = level1Category + Contents.CATEGORY_SEP
						+ tag;
				if (sb.length() > 0) {
					sb.append("\t");
				}
				sb.append(ProfileFeatureType.VIDEO_TAG.getValue())
				.append(sep).append(tagStr).append(sep)
				.append(1.0);
			}
		}
		
		// video length
		if (! "NULL".equals(vdoLen) && !vdoLen.isEmpty()) {
			if (sb.length() > 0) {
				sb.append("\t");
			}
			
			sb.append(ProfileFeatureType.VIDEO_LENGTH.getValue());
			sb.append(sep);
			sb.append(vdoLen);
			sb.append(sep);
			sb.append(1.0);
		}
		
		// video source
		if (! "NULL".equals(vdoSource) && !vdoSource.isEmpty()) {
			if (sb.length() > 0) {
				sb.append("\t");
			}
			
			sb.append(ProfileFeatureType.VIDEO_SOURCE.getValue());
			sb.append(sep);
			sb.append(vdoSource);
			sb.append(sep);
			sb.append(1.0);
		}
		
		// seed career
		if (! "NULL".equals(career) && !career.isEmpty()) {
			if (sb.length() > 0) {
				sb.append("\t");
			}
			
			sb.append(ProfileFeatureType.SEED_CAREER.getValue());
			sb.append(sep);
			sb.append(career);
			sb.append(sep);
			sb.append(1.0);
		}
				
		// seed age
		if (! "NULL".equals(age) && !age.isEmpty()) {
			if (sb.length() > 0) {
				sb.append("\t");
			}
			
			sb.append(ProfileFeatureType.SEED_AGE.getValue());
			sb.append(sep);
			sb.append(age);
			sb.append(sep);
			sb.append(1.0);
		}
		
		// seed gender
		if (! "NULL".equals(gender) && !gender.isEmpty()) {
			if (sb.length() > 0) {
				sb.append("\t");
			}
			
			sb.append(ProfileFeatureType.SEED_GENDER.getValue());
			sb.append(sep);
			sb.append(gender);
			sb.append(sep);
			sb.append(1.0);
		}
		
		// seed address
		if (! "NULL".equals(address) && !address.isEmpty()) {
			if (sb.length() > 0) {
				sb.append("\t");
			}
			
			sb.append(ProfileFeatureType.SEED_ADDRESS.getValue());
			sb.append(sep);
			sb.append(address);
			sb.append(sep);
			sb.append(1.0);
		}
		
		return sb.toString();
		
	}
}
