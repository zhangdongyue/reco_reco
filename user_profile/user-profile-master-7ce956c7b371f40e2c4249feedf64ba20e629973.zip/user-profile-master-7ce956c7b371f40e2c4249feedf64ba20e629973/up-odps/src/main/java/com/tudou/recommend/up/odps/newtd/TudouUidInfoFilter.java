package com.tudou.recommend.up.odps.newtd;

import java.io.IOException;
import java.util.Iterator;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.UserIdInfo;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;

/**
 * 清洗user ID Mapping数据，滤掉无效imei和idfa
 * 
 * @author zengtao
 *
 */
public class TudouUidInfoFilter {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class TudouUidInfoFilterMapper extends MapperBase {
		private Record k2;

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			UserIdInfo info = UserIdInfo.parseFromRecord(record);
			if (info == null) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_uid_info_input").increment(1L);
				return;
			}
			if (!info.appToken.equals("uc-iflow")) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"filtered_by_app_token").increment(1L);
				return;
			}
			if (!info.idfa.isEmpty()) {
				k2.setString(0, info.idfa);
			} else if (!info.imei.isEmpty()) {
				k2.setString(0, info.imei);
			}
			context.write(k2, record);
		}
	}

	public static class TudouUidInfoFilterReducer extends ReducerBase {
		private Record result;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			int cnt = 0;

			while (values.hasNext()) {
				Record record = values.next();
				cnt++;
				if (cnt == 1) {
					result.setString("last_reco_time", record.getString("last_reco_time"));
					result.setString("app_name", record.getString("app_name"));
					result.setString("user_id", record.getString("user_id"));
					result.setString("os_type", record.getString("os_type"));
					result.setString("imei", record.getString("imei"));
					result.setString("idfa", record.getString("idfa"));
					result.setString("mac", record.getString("mac"));
					result.setString("utdid", record.getString("utdid"));
					result.setString("dn", record.getString("dn"));
					result.setString("sn", record.getString("sn"));
					result.setString("province", record.getString("province"));
					result.setString("city", record.getString("city"));
					result.setString("gi", record.getString("gi"));
				}
			}
			// 仅保留一对一的imei 和 IDFA
			if (cnt == 1 && null != result) {
				context.write(result);
			} else {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"multi_uid_imfa").increment(1L);
			}
		}

	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils
				.fromString("last_reco_time:string,app_name:string,user_id:string,utdid:string,mac:string,dn:string,sn:string,imei:string,idfa:string,os_type:string,province:string,city:string,gi:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {
				"last_reco_time", "app_name", "user_id", "utdid", "mac", "dn",
				"sn", "imei", "idfa", "os_type", "province", "city", "gi" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(TudouUidInfoFilterMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(TudouUidInfoFilterReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		MrJobParamSetter.setSplitSize(job, 128L);

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {

	}
}
