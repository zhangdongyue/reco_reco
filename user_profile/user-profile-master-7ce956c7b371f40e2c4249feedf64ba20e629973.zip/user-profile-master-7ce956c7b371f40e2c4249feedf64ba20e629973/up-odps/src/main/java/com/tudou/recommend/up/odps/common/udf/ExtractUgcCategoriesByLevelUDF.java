package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.tudou.recommend.up.odps.common.entity.Contents;

public class ExtractUgcCategoriesByLevelUDF extends UDF {
	public String evaluate(String tag, String delimitor, String outputLevel) {
		if (tag == null  || delimitor == null || outputLevel == null) {
			return null;
		}
		
		if (tag.isEmpty() || delimitor.isEmpty() || outputLevel.isEmpty()) {
			return null;
		}
		
		StringBuilder sb = new StringBuilder();
		String[] tokens = tag.split(delimitor);
		for (int i = 0; i < tokens.length; i++) {
			String featureInfo = tokens[i];
			if (featureInfo.isEmpty()) {
				continue;
			}

			if("1".equals(outputLevel) && !featureInfo.contains(Contents.CATEGORY_SEP)) {
				if (sb.length() > 0) {
					sb.append(delimitor);
				}
				sb.append(featureInfo);
			}
			
			if ("2".equals(outputLevel) && featureInfo.contains(Contents.CATEGORY_SEP)) {
				if (sb.length() > 0) {
					sb.append(delimitor);
				}
				sb.append(featureInfo);
			}
		}
		
		if (sb.length() > 0) {
			return sb.toString();
		}
		
		return null;
	}
}
