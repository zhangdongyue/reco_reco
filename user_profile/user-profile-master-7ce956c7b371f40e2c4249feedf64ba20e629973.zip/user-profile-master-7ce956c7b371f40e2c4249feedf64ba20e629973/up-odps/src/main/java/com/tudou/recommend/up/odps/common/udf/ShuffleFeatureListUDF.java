package com.tudou.recommend.up.odps.common.udf;

import java.util.*;

import com.aliyun.odps.udf.UDF;

public class ShuffleFeatureListUDF extends UDF {
	public String evaluate( String features, String delimitor) {
		if (features == null ||  delimitor == null) {
			return null;
		}
		
		if (features.isEmpty() || delimitor.isEmpty()) {
			return null;
		}
		
		StringBuilder sb = new StringBuilder();
		String[] tokens = features.split(delimitor);
		List<String> featureList = new ArrayList<String>();
		for (int i = 0; i < tokens.length; i++) {
			if (tokens[i].isEmpty()) {
				continue;
			}
			featureList.add(tokens[i]);
		}
		
		// shuffle features
		Collections.shuffle(featureList);

		// generate new sequence
		for (int i = 0; i < featureList.size(); i++) {
			if (i > 0) {
				sb.append(delimitor);
			}
			
			sb.append(featureList.get(i));
		}
		
		if (sb.length()>0) {
			return sb.toString();
		}
		
		return null;
	}
}
