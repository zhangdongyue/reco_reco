package com.tudou.recommend.up.odps.common.entity.interest;

/**
 * User Interest 计算方法枚举
 */
public enum InterestCalcMethods{
    /**
     * 类目兴趣计算方法（内部有针对二级类目的平滑）
     */
    Category("category"),
    
    /**
     * 类目兴趣计算方法（不进行平滑）
     */
    CategoryWithouSmooting("category_no_smooting"),
    
    /**
     * 默认类目计算方法（贝叶斯方法，考虑时间衰减和热度平滑）
     */
    Default("default"),
    
    /**
     * 无平滑计算方法
     */
    WithouSmooting("no_smooting"),
    
    /**
     * 均值计算方法
     */
    Average("average"),
    
    /**
     * 求和计算方法
     */
    Sum("sum")
    ;
    
    private String value;
    
    private InterestCalcMethods(String value){
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
