package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;

public class ExtractFeatureByFeatureTypeUDF extends UDF {
	public String evaluate(String featureType, String feature, String delimitor, String seperator) {
		if (featureType == null || feature == null || delimitor == null || seperator == null) {
			return null;
		}
		
		if (featureType.isEmpty() || delimitor.isEmpty() || seperator.isEmpty()) {
			return null;
		}
		
		StringBuilder sb = new StringBuilder();
		String[] tokens = feature.split(delimitor);
		for (int i = 0; i < tokens.length; i++) {
			String featureInfo = tokens[i];
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String[] tokens1 = featureInfo.split(seperator);
			if (tokens1.length == 3) {
				if (featureType.compareTo(tokens1[0]) == 0) {
					sb.append(tokens1[1]);
					sb.append(delimitor);
				}
			}
		}
		
		if (sb.length() > 0) {
			sb.deleteCharAt(sb.length() - 1);
			return sb.toString();
		}
		
		return null;
	}

}
