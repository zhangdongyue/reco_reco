package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.googlecode.protobuf.format.JsonFormat;
import com.tudou.recommend.proto.ProtoItem;
import org.apache.commons.lang.StringUtils;
import sun.misc.BASE64Decoder;

import java.io.IOException;
import java.lang.reflect.Method;

/**
 * @author wangfei01
 * @date 2017/12/6
 */
public class ItemInfoUDF extends UDF {
    private BASE64Decoder decoder = new BASE64Decoder();

    public String evaluate(String rawItem, String path) throws IOException {
        if (rawItem == null || rawItem.isEmpty()) {
            return null;
        }
        byte[] decodeBuffer = decoder.decodeBuffer(rawItem);
        ProtoItem.RecoItem decodeItem = ProtoItem.RecoItem.parseFrom(decodeBuffer);
        if (StringUtils.isEmpty(path)) {
            return JsonFormat.printToString(decodeItem);
        }
        String[] tokens = path.split("\\.");
        Object result = decodeItem;
        for (int i = 0; i < tokens.length; i++) {
            try {
                int left = tokens[i].indexOf("[");
                int right = tokens[i].indexOf("]");
                if (left != -1) {
                    String methodName = "get" + StringUtils.capitalize(tokens[i].substring(0, left));
                    Integer index = Integer.parseInt(tokens[i].substring(left + 1, right));
                    Method method = result.getClass().getMethod(methodName, int.class);
                    result = method.invoke(result, index);
                } else {
                    String methodName = "get" + StringUtils.capitalize(tokens[i]);
                    Method method = result.getClass().getMethod(methodName);
                    result = method.invoke(result);
                }
            } catch (Exception e) {
                System.out.println("Error line is:" + rawItem.hashCode() + "\n-->" + path + "->" + tokens[i]);
                e.printStackTrace();
                return null;
            }
        }
        return result.toString();
    }
}
