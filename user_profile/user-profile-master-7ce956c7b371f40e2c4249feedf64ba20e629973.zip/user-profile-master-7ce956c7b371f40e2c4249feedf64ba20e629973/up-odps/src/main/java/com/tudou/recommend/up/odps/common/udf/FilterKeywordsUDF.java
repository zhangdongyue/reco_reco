package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.ExecutionContext;
import com.aliyun.odps.udf.UDF;
import com.aliyun.odps.udf.UDFException;
import com.google.common.base.Splitter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author wangfei01
 * @date 2018/4/20
 */
public class FilterKeywordsUDF extends UDF {
    private List<String> list = new ArrayList<>();

    @Override
    public void setup(ExecutionContext ctx) throws UDFException {
        String resourceName = "sensitive_keywords";
        try {
            Iterator<Object[]> iterator = ctx.readResourceTable(resourceName)
                    .iterator();
            int count = 0;
            while (iterator.hasNext()) {
                Object[] row = iterator.next();
                String keyword = row[0].toString();
                list.add(keyword);
                count++;
            }
            System.out.println("read " + count + " words from " + resourceName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Boolean evaluate(String raw) {
        if (raw == null) {
            return false;
        }
        for (String keyword : list) {
            if (raw.contains(keyword)) {
                return true;
            }
        }
        return false;
    }
}
