package com.tudou.recommend.up.odps.common.udf;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.aliyun.odps.udf.UDF;

public class AdjustFeatureWeightUDF extends UDF {
	public class TagNode {
		String tag;
		String feature;
		double weight;
		
		public TagNode(String tag, String feature, double weight) {
			this.tag = tag;
			this.feature = feature;
			this.weight = weight;
		}
		
		public String getKey() {
			return this.tag;
		}
		
		public double getValue() {
			return this.weight;
		}
	}
	
	public class SortByWeightAndTagDesc implements Comparator<TagNode> {
		public int compare(TagNode s1, TagNode s2) {
			if ( s1.weight > s2.weight) {
				return -1;
			} else if (s1.weight < s2.weight) {
				return 1;
			} else {
				return s1.tag.compareTo(s2.tag);
			}
		}
	}
	
	public class SortByWeightAndTagAsc implements Comparator<TagNode> {
		public int compare(TagNode s1, TagNode s2) {
			if ( s1.weight < s2.weight) {
				return -1;
			} else if (s1.weight > s2.weight) {
				return 1;
			} else {
				return s1.tag.compareTo(s2.tag);
			}
		}
	}
	
	public String evaluate(String features, String delimitor, String seperator, String maxTagCount, String sortType, String weightType) {
		if (features == null || delimitor == null || seperator == null || maxTagCount == null || sortType == null || weightType ==  null) {
			return null;
		}
		
		if (features.isEmpty() || delimitor.isEmpty() || seperator.isEmpty() || maxTagCount.isEmpty() || sortType.isEmpty() || weightType.isEmpty()) {
			return null;
		}
		
		int maxCount = Integer.parseInt(maxTagCount);
		ArrayList<TagNode> tagList = new ArrayList<TagNode>();
		String[] tokens1 = features.split(delimitor);
		for (int i = 0; i < tokens1.length; i++) {
			String featureInfo = tokens1[i];
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String[] tokens = featureInfo.split(seperator);
			if (tokens.length >= 3) {
				if (!tokens[0].isEmpty()) {
					
					double weight = Double.parseDouble(tokens[1]);
					tagList.add(new TagNode(tokens[0], featureInfo, weight));
					
				}
				
			} 
		}

		// sort tag list 
		if ("asc".equals(sortType) || "ASC".equals(sortType)) {
			Collections.sort(tagList, new SortByWeightAndTagAsc());
		} else if ("desc".equals(sortType) || "DESC".equals(sortType)) {
			Collections.sort(tagList, new SortByWeightAndTagDesc());
		} 

		// generate result
		int count = 0;
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < tagList.size(); i++) {
			if (count >= maxCount) {
				break;
			}
			count ++;
			
			String feature = tagList.get(i).feature;
			String[] tokens = feature.split(seperator);
			for (int j = 0; j < tokens.length; j++) {
				if (j > 0) {
					sb.append(seperator);
				}
				
				if (j == 1) {
					if ("1".equals(weightType)) {
						sb.append("1.0");
					} else {
						sb.append(tokens[j]);
					}
				} else {
					sb.append(tokens[j]);
				}
			}
			sb.append(delimitor);
			
		}
		if (sb.length() > 0) {
			sb.deleteCharAt(sb.length() - 1);
			return sb.toString();
		}
	
		return null;
	}
}
