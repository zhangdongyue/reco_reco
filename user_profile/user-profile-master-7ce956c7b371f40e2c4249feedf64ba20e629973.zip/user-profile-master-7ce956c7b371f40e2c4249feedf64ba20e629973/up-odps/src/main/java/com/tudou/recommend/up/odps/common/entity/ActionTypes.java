package com.tudou.recommend.up.odps.common.entity;

/**
 * 用户行为类型枚举
 */
public enum ActionTypes{
    /**
     * 点击
     */
    RecoClick("kRecoClick"),
    
    /**
     * 页内点击
     */
    PageElemClick("kPageElemClick"),
    
    /**
     * 分享
     */
    Share("kShare"),
    
    /**
     * 评论
     */
    Comment("kCmt"),
    
    /**
     * 收藏
     */
    Favority("kFav"),
    
    /**
     * 不喜欢
     */
    Dislike("kDisLike"),
    
    /**
     * 喜欢
     */
    Like("kLike"),
    
    /**
     * 顶
     */
    Agree("kAgree"),
    
    /**
     * 踩
     */
    Disagree("kDisAgree"),
    
    /**
     * 视频点击
     */
    VideoClick("kVideoClick"),
    
    /**
     * 频道主动刷新
     */
    ChannelPush("kChannelPush"),
    
    /**
     * 视频自动连播
     */
    VideoAutoPlay("kVideoAutoPlay"),
    
    /**
     * 视频自动连播
     */
    RelatedClick("kRelateClick"),
    
    /**
     * 其它行为
     */
    Other("kOther");
    
    private String value;
    
    private ActionTypes(String value){
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
