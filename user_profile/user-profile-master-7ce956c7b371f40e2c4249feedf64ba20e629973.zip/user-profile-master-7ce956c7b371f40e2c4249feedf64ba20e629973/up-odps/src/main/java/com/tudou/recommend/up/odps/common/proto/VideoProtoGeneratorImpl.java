package com.tudou.recommend.up.odps.common.proto;

import com.google.protobuf.GeneratedMessage;
import com.google.protobuf.InvalidProtocolBufferException;
import com.tudou.recommend.proto.ProtoUser;
import com.tudou.recommend.up.odps.common.entity.interest.InterestElem;
import com.tudou.recommend.up.odps.iflow.util.VideoProfileGenerateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * Implement of user profile proto generator.
 *
 * @author wangfei01
 */
public class VideoProtoGeneratorImpl implements IProtoGenerate {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public GeneratedMessage generate(Map<Integer, Map<Integer, InterestElem>> featureMap) {
        return VideoProfileGenerateUtil.generatePureVideoProfile(featureMap);
    }
    
    @Override
    public GeneratedMessage generateUgc(Map<Integer, Map<Integer, InterestElem>> featureMap) {
    	return VideoProfileGenerateUtil.generateUgcVideoProfile(featureMap);
    }

    @Override
    public GeneratedMessage parse(byte[] bytes) {
        try {
            return ProtoUser.VideoProfile.parseFrom(bytes);
        } catch (InvalidProtocolBufferException e) {
            logger.error("parse user proto failed.", e);
            return null;
        }
    }

    @Override
    public String printToJson(byte[] bytes) {
        GeneratedMessage message = parse(bytes);
        return message.toString();
    }
}
