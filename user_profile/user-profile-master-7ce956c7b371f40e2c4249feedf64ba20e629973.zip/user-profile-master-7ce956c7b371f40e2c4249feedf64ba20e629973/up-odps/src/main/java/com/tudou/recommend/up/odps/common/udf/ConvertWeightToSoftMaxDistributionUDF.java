package com.tudou.recommend.up.odps.common.udf;

import java.util.ArrayList;

import com.aliyun.odps.udf.UDF;

public class ConvertWeightToSoftMaxDistributionUDF extends UDF {
//	public void softmax(double[] x) {
//		double max = 0.0;
//		double sum = 0.0;
//		
//		for(int i=0; i<n_out; i++) if(max < x[i]) max = x[i];
//		
//		for(int i=0; i<n_out; i++) {
//			x[i] = Math.exp(x[i] - max);
//			sum += x[i];
//		}
//		
//		for(int i=0; i<n_out; i++) x[i] /= sum;
//	}
	
	public class TagNode {
		String tag;
		double weight;
		
		public TagNode(String tag, double weight) {
			this.tag = tag;
			this.weight = weight;
		}
		
		public String getKey() {
			return this.tag;
		}
		
		public double getValue() {
			return this.weight;
		}
		
		public void setWeight(double weight) {
			this.weight = weight;
		}
	}
	
	public ArrayList<TagNode> softMax(ArrayList<TagNode> tagList) {
		ArrayList<TagNode> resultList = new ArrayList<TagNode>();
		
		// convert to softmax distribution.
		double max = 0.0;
		double sum = 0.0;
		for (int i = 0; i < tagList.size(); i++) {
			double weight = tagList.get(i).weight;
			if (max < weight) {
				max = weight;
			}
		}
		for (int i = 0; i < tagList.size(); i++) {
			double weight = Math.exp(tagList.get(i).weight - max);
			tagList.get(i).setWeight(weight);
			sum += weight;
		}
		for (int i = 0; i < tagList.size(); i++) {
			double weight = tagList.get(i).weight / sum;
			String tag = tagList.get(i).tag;
			resultList.add(new TagNode(tag, weight));
		}
		
		return resultList;
	}
	
	public String evaluate(String tag1, String delimitor, String seperator, String factor, String useSoftMax) {
		if (tag1 == null || delimitor == null || seperator == null || factor == null) {
			return null;
		}
		
		if (tag1.isEmpty() || delimitor.isEmpty() || seperator.isEmpty() || factor.isEmpty()) {
			return null;
		}
		
		double weightFactor = Double.parseDouble(factor);
		ArrayList<TagNode> tagList = new ArrayList<TagNode>();
		String[] tokens1 = tag1.split(delimitor);
		for (int i = 0; i < tokens1.length; i++) {
			String featureInfo = tokens1[i];
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String[] tokens = featureInfo.split(seperator);
			if (tokens.length >= 3) {
				if (!tokens[0].isEmpty()) {
					
					double weight = Double.parseDouble(tokens[1]);
					if (i > 0) {
						weight *= weightFactor;
					}
					
					tagList.add(new TagNode(featureInfo, weight));
					
				}
				
			} 
		}

		if ("yes".equals(useSoftMax)) {
			tagList = softMax(tagList);
		}
		
		// replace by new weight
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < tagList.size(); i++) {
			if (i > 0) {
				sb.append(delimitor);
			}
			
			String[] tokens = tagList.get(i).tag.split(seperator);
			for (int j = 0; j < tokens.length; j++) {
				if (j > 0) {
					sb.append(seperator);
				}
				
				if (j == 1) {
					sb.append(tagList.get(i).weight);
				} else {
					sb.append(tokens[j]);
				}
			}
		}
		
		if (sb.length() > 0) {
			return sb.toString();
		}
		
		return null;
	}
}
