package com.tudou.recommend.up.odps.newtd.ugc;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;


import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import com.tudou.recommend.up.odps.iflow.video.VideoMergeLogFilter;
import org.apache.log4j.Logger;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.iflow.util.UserInterestGenerateUtil;

/**
 * 计算用户的长期兴趣，考虑时间衰减因素
 * @author jinchanghu
 * @date 2018年1月8日 下午1:59:28
 */
public class UserUgcInterestGenerator {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class UserInterestGeneratorMapper extends MapperBase {
		private Record k2;
		private Record v2;

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			// input formate
			// appname-userId ~ feaType ~ fea ~ [bucket : weightSum : clickSum]
			// 剔除各桶上weight均为0的record
			String[] weightStrs = record.getString(3).split(" ", -1);
			boolean isAllZero = true;
			for (String str : weightStrs) {
				if (Float.parseFloat(str.split(":", -1)[1]) > 0) {
					isAllZero = false;
					break;
				}
			}

			if (!isAllZero) {
				k2.setString(0, record.getString(0));// uer_id
				v2.setString(0, record.getString(1));// feature_type
				v2.setString(1, record.getString(2));// feature
				v2.setString(2, record.getString(3));// weight_click
				context.write(k2, v2);
			} else {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"all_weight_zero").increment(1L);
			}
		}
	}

	/**
	 * 用户权重数据reducer,根据用户的在fea上的weight和fea本身的weight计算用户的长期兴趣
	 * 
	 * @author zengtao
	 *
	 */
	public static class UserInterestGeneratorReducer extends ReducerBase {
		private static final Logger logger = Logger
				.getLogger(VideoMergeLogFilter.class);
		private Record result;
		private static final DecimalFormat DF = DataFormatUtil
				.getDefaultDecimalFormater();
		private int bucketNum = -1;
		UserInterestGenerateUtil interestGenerator = new UserInterestGenerateUtil();

		private void readFeatureWeightFile(Iterator<Record> values,
				HashMap<String, float[]> feaWeightsMap)
				throws NumberFormatException, IOException {
			while (values.hasNext()) {
				Record next = values.next();
				int feaType = Integer.parseInt(next.getString(0));
				String fea = next.getString(1);
				String[] feaWeightStrs = next.getString(2).trim().split(" ");
				float[] feaWeights = new float[bucketNum];
				for (String str : feaWeightStrs) {
					String[] numbers = str.split(":", -1);
					feaWeights[Integer.parseInt(numbers[0])] = Float
							.parseFloat(numbers[1]);
				}
				String feaWithType = feaType + "_" + fea;
				feaWeightsMap.put(feaWithType, feaWeights);
			}
		}

		private void readFeatureTuneFile(Iterator<Record> values,
				HashMap<Integer, HashMap<String, Double>> feaTuneMap)
				throws NumberFormatException, IOException {
			while (values.hasNext()) {
				Record next = values.next();
				int feaType = Integer.parseInt(next.getString(0));
				String fea = next.getString(1);
				double tuneWeight = Double.parseDouble(next.getString(2));
				if (!feaTuneMap.containsKey(feaType)) {
					feaTuneMap.put(feaType, new HashMap<String, Double>());
				}
				feaTuneMap.get(feaType).put(fea, tuneWeight);
			}
		}

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
			JobConf conf = context.getJobConf();
			// 设置时间桶个数
			bucketNum = conf.getInt("bucketNum", 10);
			interestGenerator.setBucketNum(bucketNum);

			// 加载feature weight资源表
			HashMap<String, float[]> feaWeightsMap = new HashMap<String, float[]>();
			Iterator<Record> termWeightTable = context.readResourceTable(conf
					.get("termWeightDataTable"));
			readFeatureWeightFile(termWeightTable, feaWeightsMap);
			interestGenerator.setFeaWeightsMap(feaWeightsMap);
			interestGenerator.setFeaWeightLoad(true);
			interestGenerator.setUseGlobalTermWeight(conf.getInt("useGlobalTermWeight", 0) == 1);
			
			
			// 生成时间衰减系数
			interestGenerator.setTimeDecayFactor(conf.getFloat(
					"timeDecayFactor", 1.0f));
			interestGenerator.generateTimeDecayFactors();

			// 设置不同的fea type对应的interest 计算方法
			interestGenerator.setFeaInterestCalcMethods();

			// feature weight 强制调权
			boolean doFeatureWeightTuning = conf.getInt("featureWeightTune", 0) == 1;
			interestGenerator.setDoFeatureWeightTuning(doFeatureWeightTuning);
			if (doFeatureWeightTuning) {
				HashMap<Integer, HashMap<String, Double>> feaTuneMap = new HashMap<Integer, HashMap<String, Double>>();
				Iterator<Record> featureTuneTable = context
						.readResourceTable(conf.get("featureTuneDataTable"));
				readFeatureTuneFile(featureTuneTable, feaTuneMap);
				interestGenerator.setFeaTuneWeights(feaTuneMap);
			}
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			if (!interestGenerator.isFeaWeightLoad()) {
				logger.error("feature weight load failed!");
				return;
			}
			interestGenerator.clear();
			while (values.hasNext()) {
				Record r = values.next();
				interestGenerator.process(new String[] { r.getString(0),
						r.getString(1), r.getString(2) });
			}
			interestGenerator.merge();

			if (interestGenerator.isDoFeatureWeightTuning()) {
				interestGenerator.doInterestTuningByFeatureWeights();
			}

			// output
			HashMap<Integer, HashMap<String, float[]>> interestResults = interestGenerator
					.getInterestResults();
			String interestStr;
			for (int feaType : interestResults.keySet()) {
				interestStr = generateOutputStr(key.getString(0), feaType,
						interestResults.get(feaType), result);
				if (interestStr != null) {
					context.write(result);
				}
			}
		}

		/**
		 * 组装输出字符串 组装时剔除interest=0的term
		 * 
		 * @param userId
		 * @param termType
		 * @param interestMap
		 * @return 组装失败返回null
		 */
		private String generateOutputStr(String userId, int termType,
				HashMap<String, float[]> interestMap, Record result) {
			if (interestMap == null || interestMap.size() == 0) {
				return null;
			}

			// sort by interest desc
			ArrayList<Map.Entry<String, float[]>> interestArr = new ArrayList<Map.Entry<String, float[]>>();
			for (Map.Entry<String, float[]> en : interestMap.entrySet()) {
				interestArr.add(en);
			}
			//System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");
			Collections.sort(interestArr,
					new Comparator<Map.Entry<String, float[]>>() {
						public int compare(Entry<String, float[]> en1,
								Entry<String, float[]> en2) {
							return Float.compare(en2.getValue()[0],
									en1.getValue()[0]);
						}
					});

			boolean allTermInterestZero = true; // 是否所有term的interest都为0
			StringBuilder builder = new StringBuilder();
			result.setString(0, userId);
			result.setString(1, String.valueOf(termType));
			for (int k = 0; k < interestArr.size() && k < 1000; ++k) {
				Map.Entry<String, float[]> en = interestArr.get(k);
				if (en.getValue()[0] > 0) {
					if (builder.length() > 0) {
						builder.append("\t");
					}
					builder.append(en.getKey());
					builder.append("::" + DF.format(en.getValue()[0]) + "::"
							+ DF.format(en.getValue()[1]));
					allTermInterestZero = false;
				}
			}

			if (allTermInterestZero) {
				return null;
			} else {
				result.setString(2, builder.toString());
				return builder.toString();
			}
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils
				.fromString("feature_type:string,feature:string,weight_click:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {
				"user_id", "feature_type", "feature", "weight_click" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(UserInterestGeneratorMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(UserInterestGeneratorReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		MrJobParamSetter.setSplitSize(job, 128L);

		job.setFloat("timeDecayFactor", argContainer.getTimeDecayFactor());
		job.setInt("bucketNum", argContainer.getBucketNum());
		job.setInt("featureWeightTune", argContainer.getFeatureWeightTune());
		job.set("termWeightDataTable", argContainer.getTermWeightDataDir());
		job.setInt("useGlobalTermWeight", argContainer.getUseGlobalTermWeight());
		if (argContainer.getFeatureWeightTune() == 1) {
			job.set("featureTuneDataTable", argContainer.getTermWeightDataDir());
		}

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-termWeightDataTable", description = "path of term weight data files")
		private String termWeightDataTable = "/reco/user_profile/ptc/000";

		@Parameter(names = "-timeDecayFactor", description = "time decay factor")
		private float timeDecayFactor = 0.95f;

		@Parameter(names = "-bucketNum", description = "num of time bucket")
		private int bucketNum = 10;

		@Parameter(names = "-featureWeightTune", description = "whether use additional feature weight tuning")
		private int featureWeightTune = 0;

		@Parameter(names = "-featureTuneDataTable", description = "path of feature weight tuning data")
		private String featureTuneDataTable = "/reco/user_profile/ptc/000";
		
		@Parameter(names = "-useGlobalTermWeight", description = "whether use global term weight")
		private int globalTermWeight = 0;

		public String getTermWeightDataDir() {
			return termWeightDataTable;
		}

		public void setTermWeightDataDir(String termWeightDataDir) {
			this.termWeightDataTable = termWeightDataDir;
		}

		public float getTimeDecayFactor() {
			return timeDecayFactor;
		}

		public void setTimeDecayFactor(float timeDecayFactor) {
			this.timeDecayFactor = timeDecayFactor;
		}

		public int getBucketNum() {
			return bucketNum;
		}

		public void setBucketNum(int bucketNum) {
			this.bucketNum = bucketNum;
		}

		public int getFeatureWeightTune() {
			return featureWeightTune;
		}

		public void setFeatureWeightTune(int featureWeightTune) {
			this.featureWeightTune = featureWeightTune;
		}

		public String getFeatureTuneDataDir() {
			return featureTuneDataTable;
		}

		public void setFeatureTuneDataDir(String featureTuneDataDir) {
			this.featureTuneDataTable = featureTuneDataDir;
		}
		
		public int getUseGlobalTermWeight() {
			return this.globalTermWeight;
		}

		public void setUseGlobalTermWeight(int globalTermWeight) {
			this.globalTermWeight = globalTermWeight;
		}
	}
}
