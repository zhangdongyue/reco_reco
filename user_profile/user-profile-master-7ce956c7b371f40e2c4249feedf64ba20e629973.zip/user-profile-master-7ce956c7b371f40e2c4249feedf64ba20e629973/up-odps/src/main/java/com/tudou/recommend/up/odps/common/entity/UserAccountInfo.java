package com.tudou.recommend.up.odps.common.entity;

import com.alibaba.fastjson.JSONObject;

/**
 * 用户登录信息
 * @author hezhimin
 *
 */
public class UserAccountInfo {
  public String accountType;
  public String ucAccount;
  public String icloudAccount;
  
  public UserAccountInfo(){
    this.accountType = "";
    this.ucAccount = "";
    this.icloudAccount = "";
  }
  
  public UserAccountInfo(String accountType, String ucAccount, String icloudAccount){
    this.accountType = accountType;
    this.ucAccount = ucAccount;
    this.icloudAccount = icloudAccount;
  }
  
  public static UserAccountInfo parseFromJson(String str) {
    if (str == null || str.isEmpty()) {
      return null;
    }
    
    JSONObject json = null;
    try {
      json = JSONObject.parseObject(str);
    } catch (Exception e) {
      return null;
    }
    
    if (json == null) {
      return null;
    }
    
    UserAccountInfo account = new UserAccountInfo();
    if (json.containsKey("acpf_type")) {
      String accountType = json.getString("acpf_type");
      if (accountType != null) {
        account.accountType = accountType;
      }
    }
    if (json.containsKey("tacid")) {
      String id = json.getString("tacid");
      if (id != null) {
        account.ucAccount = id;
      }
    }
    if (json.containsKey("tuicid")) {
      String id = json.getString("tuicid");
      if (id != null) {
        account.icloudAccount = id;
      }
    }
    return account;
  }
}
