package com.tudou.recommend.up.odps.common.entity.log;

import org.apache.commons.lang3.StringUtils;

import com.aliyun.odps.data.Record;

/**
 * relate log解析工具类
 * 
 * @author hezhimin
 *
 */
public class RelateLog {
	private String[] flds;

	private String time;
	private String appName;
	private String refReadId;
	private String userId;
	private String origItemId;
	private int origItemType;
	private String relatedItemId;
	private int relatedItemType;
	private int clickSeconds;
	private int oppo;
	private int isShow;
	private String utdid;

	public RelateLog() {
		flds = null;
	}

	public boolean parse(String logStr) {
		if (logStr == null) {
			return false;
		} else {
			String[] logFlds = logStr.split("\t", -1);
			if (logFlds.length < 21) {
				return false;
			} else {
				try {
					flds = logFlds;
					time = flds[0];
					appName = flds[1];
					refReadId = flds[2];
					userId = flds[3];
					origItemId = flds[4];
					origItemType = parseInt(flds[5], -1);
					relatedItemId = flds[7];
					relatedItemType = parseInt(flds[8], -1);
					clickSeconds = parseInt(flds[12], 0);
					oppo = parseInt(flds[18], 0);
					isShow = parseInt(flds[20], 0);
					if (flds.length > 25) {
						utdid = flds[25];
					}
					return true;
				} catch (Exception e) {
					return false;
				}
			}
		}
	}

	public boolean parseFromRecord(Record r) {
		if (r == null) {
			return false;
		} else {
			try {
				time = r.getString("tm");
				appName = r.getString("appname");
				refReadId = r.getString("ref_read_id");
				userId = r.getString("userid");
				origItemId = r.getString("itemid");
				origItemType = parseInt(r.getString("item_type"), -1);
				relatedItemId = r.getString("related_itemid");
				relatedItemType = parseInt(r.getString("related_item_type"), -1);
				clickSeconds = parseInt(r.getString("click"), 0);
				oppo = parseInt(r.getString("oppo"), 0);
				isShow = parseInt(r.getString("is_show"), 0);
				utdid = r.getString("utdid");
				return true;
			} catch (Exception e) {
				return false;
			}
		}
	}

	private int parseInt(String str, int defaultValue) {
		if (!str.isEmpty() && StringUtils.isNumeric(str)) {
			return Integer.parseInt(str);
		} else {
			return defaultValue;
		}
	}

	private int parseInt(String str) {
		return parseInt(str, 0);
	}

	private long parseLong(String str, long defaultValue) {
		if (!str.isEmpty() && StringUtils.isNumeric(str)) {
			return Long.parseLong(str);
		} else {
			return defaultValue;
		}
	}

	private long parseLong(String str) {
		return parseLong(str, 0L);
	}

	public String[] getFlds() {
		return flds;
	}

	public String getTime() {
		return time;
	}

	public String getAppName() {
		return appName;
	}

	public String getRefReadId() {
		return refReadId;
	}

	public String getUserId() {
		return userId;
	}

	public String getOrigItemId() {
		return origItemId;
	}

	public int getOrigItemType() {
		return origItemType;
	}

	public String getRelatedItemId() {
		return relatedItemId;
	}

	public int getRelatedItemType() {
		return relatedItemType;
	}

	public int getClickSeconds() {
		return clickSeconds;
	}

	public int getOppo() {
		return oppo;
	}

	public int getIsShow() {
		return isShow;
	}

	public String getUtdid() {
		return utdid;
	}

}
