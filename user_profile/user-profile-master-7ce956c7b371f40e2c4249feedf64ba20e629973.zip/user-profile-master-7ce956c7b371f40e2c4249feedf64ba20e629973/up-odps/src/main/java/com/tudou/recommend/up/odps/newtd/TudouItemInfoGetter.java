package com.tudou.recommend.up.odps.newtd;

import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.newtd.entity.TudouLog;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.newtd.entity.TudouItemInfo;

/**
 * 过滤出优土视频item的信息
 * 
 * @author zengtao
 *
 */
public class TudouItemInfoGetter {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class TuDouItemInfoGetterMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private HashSet<String> itemInfos;

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			itemInfos = new HashSet<String>();
			v2.setString(0, "1");
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			TudouLog log = new TudouLog();
			if (!log.parseFromStr(record.getString(0))) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_map_input").increment(1L);
				return;
			}
			TudouItemInfo itemInfo = log.getItemInfo();
			if (itemInfo.vdoId.isEmpty() || itemInfo.vdoTitle.isEmpty()) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"empty_item_id_or_title").increment(1L);
				return;
			}
			itemInfos.add(itemInfo.toString());
		}

		@Override
		public void cleanup(TaskContext context) throws IOException {
			for (String itemInfo : itemInfos) {
				if (itemInfo != null && !itemInfo.isEmpty()) {
					k2.setString(0, itemInfo);
					context.write(k2, v2);
				}
			}
		}
	}

	public static class TuDouItemInfoGetterReducer extends ReducerBase {
		Record result;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
				result.set(0, key.getString(0));
				context.write(result);
		}

	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("v2:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput());
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(TuDouItemInfoGetterMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(TuDouItemInfoGetterReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		//MrJobParamSetter.setSplitSize(job, 128L);

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {

	}
}
