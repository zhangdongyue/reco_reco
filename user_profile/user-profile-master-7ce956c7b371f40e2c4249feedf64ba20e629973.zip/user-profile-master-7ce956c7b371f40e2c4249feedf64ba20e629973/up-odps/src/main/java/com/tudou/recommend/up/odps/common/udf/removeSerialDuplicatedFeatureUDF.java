package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;

public class removeSerialDuplicatedFeatureUDF extends UDF {
	public String evaluate( String features, String delimitor) {
		if (features == null ||  delimitor == null) {
			return null;
		}
		
		if (features.isEmpty() || delimitor.isEmpty()) {
			return null;
		}
		
		StringBuilder sb = new StringBuilder();
		String[] tokens = features.split(delimitor);
		String prevFeature = "";
		for (int i = 0; i < tokens.length; i++) {
			if (tokens[i].isEmpty()) {
				continue;
			}
			
			String feature = tokens[i];
			
			if (prevFeature.isEmpty()) {
				prevFeature = feature;
				sb.append(feature);
				continue;
			}
			
			if (prevFeature.equals(feature)) {
				continue;
			} else {
				sb.append(delimitor);
				sb.append(feature);
				
				prevFeature = feature;
			}
		}
		
		if (sb.length()>0) {
			return sb.toString();
		}
		
		return null;
	}
}
