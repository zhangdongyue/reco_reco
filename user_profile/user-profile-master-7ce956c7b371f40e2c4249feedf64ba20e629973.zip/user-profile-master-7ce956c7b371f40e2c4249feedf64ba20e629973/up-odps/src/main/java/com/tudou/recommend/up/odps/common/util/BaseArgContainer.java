package com.tudou.recommend.up.odps.common.util;

import com.beust.jcommander.Parameter;

/**
 * 配置参数基类
 * @author hezhimin
 *
 */
public class BaseArgContainer {
  @Parameter(names = "-help", help = true)
  private boolean help;
  
  @Parameter(names = "-debug", description = "debug")
  private boolean debug = false;
  
  @Parameter(names = "-input", description = "input data")
  private String input = "/job_input";
  
  @Parameter(names = "-output", description = "output")
  private String output = "/job_output";

  public BaseArgContainer() {
  }

  public boolean isHelp() {
    return help;
  }

  public void setHelp(boolean help) {
    this.help = help;
  }

  public boolean isDebug() {
    return debug;
  }

  public void setDebug(boolean debug) {
    this.debug = debug;
  }

  public String getInput() {
    return input;
  }

  public void setInput(String input) {
    this.input = input;
  }

  public String getOutput() {
    return output;
  }

  public void setOutput(String output) {
    this.output = output;
  }
  
}
