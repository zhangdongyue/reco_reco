package com.tudou.recommend.up.odps.iflow;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;

/**
 * generate user feature weight using 60days user action info.
 * @author jinchanghu
 * @date 2017年10月23日 上午10:28:37
 */
public class GenerateUserFeautreWeight {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class UserActionInfoMergerMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private HashSet<String> feaTypeSet = new HashSet<String>();
		
		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			
			JobConf conf = context.getJobConf();
			String feaType = conf.get("featureType");
			if (!feaType.isEmpty()) {
				String[] tokens = feaType.split(",");
				for (int i = 0; i < tokens.length; i++) {
					if (!tokens[i].isEmpty()) {
						feaTypeSet.add(tokens[i]);
					}
				}
			}
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			String userId = record.getString(0);
			String actionDate =  record.getString(1);
			String feaType = record.getString(2);
			String weights = record.getString(3);
			
			if (!feaTypeSet.contains(feaType)) {
				return;
			}
			
			StringBuilder sb = new StringBuilder();
			sb.append(userId);
			sb.append("\t");
			sb.append(feaType);
			
			k2.setString(0, sb.toString());		//userId + feaType
			v2.setString(0, userId);
			v2.setString(1, actionDate);
			v2.setString(2, feaType);
			v2.setString(3, weights);
			context.write(k2, v2);
		}
	}

	public static class UserActionInfoMergerReducer extends ReducerBase {
		private Record result;
		private static final DecimalFormat DF = DataFormatUtil.getDefaultDecimalFormater();

		private Long startTime;
		private Long endTime;
		private int intervalInSeconds;
		private int bucketNum = 0;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
			JobConf conf = context.getJobConf();
			startTime = DataFormatUtil.getTimestamp(conf.get("startTime"));
			endTime = DataFormatUtil.getTimestamp(conf.get("endTime"));
			intervalInSeconds = Integer.parseInt(conf.get("intervalInSeconds"));
			bucketNum = DataFormatUtil.computeTimeBucketNum(startTime, endTime, intervalInSeconds);
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			HashMap<String, Double> weightSumMap = new HashMap<String, Double>();
			HashMap<String, Double> clickSumMap = new HashMap<String, Double>();

			context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "user_id_num").increment(1L);

			String userIdWithType = key.getString(0);
			
			while (values.hasNext()) {
				Record record = values.next();
				
				// 判断时间戳格式是否合法
				Long timestamp = DataFormatUtil.getTimestamp(record.getString(1));
				if (timestamp == null) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"invalid_timestamp").increment(1L);
					continue;
				}
				if (timestamp >= endTime || timestamp < startTime) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"timestamp_out_of_range").increment(1L);
					continue; // 异常记录
				}
				int bucket = new Long((timestamp - startTime)
						/ (intervalInSeconds * 1000)).intValue();
				if (bucket >= bucketNum) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_bucket").increment(1L);
					continue;
				}
				
				String[] flds = record.getString(3).split("\t", -1);
				for (int i = 0; i < flds.length; ++i) {
					String[] feaFlds = flds[i].split("::", -1);
					String feature = feaFlds[0];
					
					if (!clickSumMap.containsKey(feature)) {
						clickSumMap.put(feature, 1.0);
					} else {
						double click = clickSumMap.get(feature) + 1.0;
						clickSumMap.put(feature, click);
					}
					
					if (!weightSumMap.containsKey(feature)) {
						double weight0 = (1 - (double)bucket/(double)bucketNum);
						weightSumMap.put(feature, weight0);
					} 
					
					double weight = weightSumMap.get(feature);
					weight += (1 - (double)bucket/(double)bucketNum);
					weightSumMap.put(feature, weight);
					
				}
			}
			
			// output: userId featureType [feature:weight]
			StringBuilder sb = new StringBuilder();
			for (String feature : weightSumMap.keySet()) {
				double weights = weightSumMap.get(feature);
				double clicks = clickSumMap.get(feature);
				
				if (sb.length() > 0) {
					sb.append("\t");
				}
				
				sb.append(feature);
				sb.append("::");
				sb.append(DF.format(weights));
				sb.append("::");
				sb.append(DF.format(clicks));
			}
			
			String[] tokens = userIdWithType.split("\t");
			if (tokens.length > 1 && sb.length() > 0) {
				String userId = tokens[0];
				String feaWithType = tokens[1];
				
				result.setString(0, userId);
				result.setString(1, feaWithType);
				result.setString(2, sb.toString());
				context.write(result);
			}
			
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils
				.fromString("user_id:string,action_date:string,feature_type:string,feature:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {
				"user_id", "action_date", "feature_type", "feature" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(UserActionInfoMergerMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(UserActionInfoMergerReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		MrJobParamSetter.setSplitSize(job, 128L);

		job.set("startTime", argContainer.getStartTime());
		job.set("endTime", argContainer.getEndTime());
		job.set("intervalInSeconds", "" + argContainer.getIntervalInSeconds());
		job.set("featureType", argContainer.getFeatureType());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {

		@Parameter(names = "-startTime", description = "start time")
		private String startTime = "20151001000000";

		@Parameter(names = "-endTime", description = "end time")
		private String endTime = "20151001000000";

		@Parameter(names = "-intervalInSeconds", description = "Interval In Seconds")
		private int intervalInSeconds = 3600 * 24 * 1;

		@Parameter(names = "-featureType", description = "allowed feature type")
		private String featureType = "";

		public String getStartTime() {
			return startTime;
		}

		public void setStartTime(String startTime) {
			this.startTime = startTime;
		}

		public String getEndTime() {
			return endTime;
		}

		public void setEndTime(String endTime) {
			this.endTime = endTime;
		}

		public int getIntervalInSeconds() {
			return intervalInSeconds;
		}

		public void setIntervalInSeconds(int intervalInSeconds) {
			this.intervalInSeconds = intervalInSeconds;
		}

		public void setFeatureType(String feaType) {
			this.featureType = feaType;
		}
		
		public String getFeatureType() {
			return this.featureType;
		}

	}
}
