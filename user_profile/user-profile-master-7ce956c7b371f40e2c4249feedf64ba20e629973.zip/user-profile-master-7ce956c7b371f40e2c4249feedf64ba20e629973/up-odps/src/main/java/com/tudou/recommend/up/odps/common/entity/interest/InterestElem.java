package com.tudou.recommend.up.odps.common.entity.interest;

/**
 * 用户兴趣（画像维度）
 * 
 * @author hezhimin
 *
 */
public class InterestElem {
  /**
   * feature字面值
   */
  public String term = null;
  
  /**
   * feature的父级feature(一般是对应的一级类目)
   */
  public String parent = null;
  
  /**
   * 用户在feature上的兴趣度（权重）
   */
  public float interest = 0;
  
  /**
   * 用户兴趣度的置信度
   */
  public float confidence = 0;
  
  /**
   *  用户在feature上的ctr
   */
  public float ctr = 0;
  
  /**
   * 构造器, ctr默认置为0
   * @param term
   * @param parent
   * @param interest
   * @param confidence
   */
  public InterestElem(String term, String parent, float interest, float confidence) {
    this.term = term;
    this.parent = parent;
    this.interest = interest;
    this.confidence = confidence;
  }
  
  /**
   * 构造器
   * @param term
   * @param parent
   * @param interest
   * @param confidence
   * @param ctr
   */
  public InterestElem(String term, String parent, float interest, float confidence, float ctr) {
    this.term = term;
    this.parent = parent;
    this.interest = interest;
    this.confidence = confidence;
    this.ctr = ctr;
  }
}
