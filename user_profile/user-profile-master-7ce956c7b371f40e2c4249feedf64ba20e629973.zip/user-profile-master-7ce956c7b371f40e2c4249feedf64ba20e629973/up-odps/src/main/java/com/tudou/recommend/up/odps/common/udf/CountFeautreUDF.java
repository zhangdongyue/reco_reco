package com.tudou.recommend.up.odps.common.udf;


import com.aliyun.odps.udf.UDF;

public class CountFeautreUDF extends UDF {
	public String evaluate( String features, String delimitor) {
		if (features == null ||  delimitor == null) {
			return null;
		}
		
		if (features.isEmpty() || delimitor.isEmpty()) {
			return null;
		}
		
		String[] tokens = features.split(delimitor);
		return String.valueOf(tokens.length);
	}
}
