package com.tudou.recommend.up.odps.iflow.dnn;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.google.common.base.Joiner;
import com.google.common.collect.EvictingQueue;
import com.tudou.recommend.up.odps.common.util.BaseArgContainer;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.math3.stat.interval.ConfidenceInterval;
import org.apache.commons.math3.stat.interval.IntervalUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * The MR will create user watch sequences according to click time.
 *
 * @author wangfei01
 * @date 2017/8/24
 */
public class WatchHistoryMR {
    private static ArgumentContainer argument = new ArgumentContainer();

    public static class WatchMapper extends MapperBase {
        private Logger logger = LoggerFactory.getLogger(this.getClass());
        private Record outputKey;
        private Record outputValue;
        private String dateFormat;

        @Override
        public void setup(TaskContext context) throws IOException {
            outputKey = context.createMapOutputKeyRecord();
            outputValue = context.createMapOutputValueRecord();
            JobConf jobConf = context.getJobConf();
            dateFormat = jobConf.get("seq.date.format");
        }

        @Override
        public void map(long key, Record record, TaskContext context) throws IOException {
            String userId = record.getString("userid");
            String utdid = record.getString("utdid");
            String itemId = record.getString("itemid");
            String title = record.getString("title");
            String ctm = record.getString("ctm");
            Long click = record.getBigint("click");
            Long videoLen = record.getBigint("video_len");
            double rate = 0.0;
            if (click != null && videoLen != null && click < videoLen) {
                ConfidenceInterval interval = IntervalUtils.getWilsonScoreInterval(videoLen.intValue(), click.intValue(), 0.90);
                rate = interval.getLowerBound();
            }
            try {
                if (ctm != null && userId != null && itemId != null) {
                    long clickDate = DateUtils.parseDate(ctm, dateFormat).getTime();
                    long clickSecond = TimeUnit.MILLISECONDS.toSeconds(clickDate);
                    outputKey.setString("userid", userId);
                    outputKey.setBigint("ctm", clickSecond);
                    outputKey.setString("utdid", utdid);
                    outputValue.setString("itemid", itemId);
                    outputValue.setString("title", title);
                    outputValue.setBigint("ctm", clickSecond);
                    outputValue.setBigint("click", click);
                    outputValue.setDouble("play_rate", rate);
                    context.write(outputKey, outputValue);
                }
            } catch (ParseException e) {
                logger.error("Parse date:{} error", ctm, e);
            }
        }
    }

    public static class SeqReducer extends ReducerBase {
        private Record output;
        private Integer maxSeqLength;
        private String seqSplitter;
        private Integer minWindowSize;
        private Integer maxWindowSize;
        private Integer labelSize;
        private Integer skip;
        private Integer leastClickSecond;
        private Float sampleRate;

        @Override
        public void setup(TaskContext context) throws IOException {
            output = context.createOutputRecord();
            JobConf conf = context.getJobConf();
            maxSeqLength = conf.getInt("seq.max.length", 500);
            seqSplitter = conf.get("seq.splitter", " ");
            skip = conf.getInt("seq.skip.steps", 5);
            minWindowSize = conf.getInt("seq.min.window", 5);
            maxWindowSize = conf.getInt("seq.max.window", 20);
            labelSize = conf.getInt("seq.label.size", 1);
            leastClickSecond = conf.getInt("least.click.second", 5);
            sampleRate = conf.getFloat("sample.rate", 1.0f);
        }

        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
            String userId = key.getString("userid");
            String utdid = key.getString("utdid");
            output.setString("userid", userId);
            output.setString("utdid", utdid);
            EvictingQueue<String> titleSeq = EvictingQueue.create(maxSeqLength);
            EvictingQueue<String> itemSeq = EvictingQueue.create(maxSeqLength);
            EvictingQueue<Long> dateSeq = EvictingQueue.create(maxSeqLength);
            EvictingQueue<Double> rateSeq = EvictingQueue.create(maxSeqLength);
            while (values.hasNext()) {
                Record value = values.next();
                String title = value.getString("title");
                String itemId = value.getString("itemid");
                Long clickDate = value.getBigint("ctm");
                Long click = value.getBigint("click");
                Double rate = value.getDouble("play_rate");
                if (click >= leastClickSecond) {
                    itemSeq.add(itemId);
                    titleSeq.add(title);
                    dateSeq.add(clickDate);
                    rateSeq.add(rate);
                }
            }
            String[] itemArray = itemSeq.toArray(new String[0]);
            String[] titleArray = titleSeq.toArray(new String[0]);
            Long[] dateArray = dateSeq.toArray(new Long[0]);
            Double[] rateArray = rateSeq.toArray(new Double[0]);
            List<Object[]> itemExamples = windowExample(itemArray, "0", skip, minWindowSize, maxWindowSize, labelSize);
            List<Object[]> titleExamples = windowExample(titleArray, "0", skip, minWindowSize, maxWindowSize, labelSize);
            List<Object[]> dateExamples = windowExample(dateArray, "0", skip, minWindowSize, maxWindowSize, labelSize);
            List<Object[]> rateExamples = windowExample(rateArray, "0", skip, minWindowSize, maxWindowSize, labelSize);
            for (int i = 0; i < itemExamples.size(); i++) {
                try {
                    Object[] example = itemExamples.get(i);
                    Object[] titles = titleExamples.get(i);
                    Object[] dates = dateExamples.get(i);
                    Object[] rates = rateExamples.get(i);

                    output.setString("item_seq",
                            Joiner.on(seqSplitter)
                                    .join(Arrays.copyOf(example, maxWindowSize))
                    );
                    output.setString("title_seq",
                            Joiner.on(seqSplitter)
                                    .join(Arrays.copyOf(titles, maxWindowSize))
                    );
                    if (labelSize > 0) {
                        output.setString("item_labels",
                                Joiner.on(seqSplitter)
                                        .join(Arrays.copyOfRange(example, maxWindowSize, maxWindowSize + labelSize))
                        );
                        output.setString("title_labels",
                                Joiner.on(seqSplitter)
                                        .join(Arrays.copyOfRange(titles, maxWindowSize, maxWindowSize + labelSize))
                        );
                        output.setBigint("label_date", (Long) dates[maxWindowSize]);
                        output.setDouble("label_rate", (Double) rates[maxWindowSize]);
                    }

                    output.setString("userid", userId);
                    if (Math.random() < sampleRate) {
                        context.write(output);
                    }
                } catch (Exception e) {
                    StringBuilder builder = new StringBuilder();
                    for (Object[] obj : dateExamples) {
                        builder.append(Joiner.on(" ").join(obj)).append("\t");
                    }
                    builder.append(e.getMessage()).append("\t");
                    StackTraceElement[] traces = e.getStackTrace();
                    for (StackTraceElement element : traces) {
                        builder.append(element.getClassName())
                                .append(" ")
                                .append(element.getLineNumber())
                                .append("\t");
                    }
                    throw new IOException(builder.toString());
                }
            }
        }

        public List<Object[]> windowExample(Object[] seq,
                                            Object padding,
                                            int skip,
                                            int minWindowSize,
                                            int maxWindowSize,
                                            int labelSize) {
            List<Object[]> resultList = new ArrayList<>();
            if (labelSize > seq.length) {
                return resultList;
            }
            for (int i = 0; i < seq.length; i += skip) {
                Object[] example = new Object[maxWindowSize + labelSize];
                // Set default value.
                for (int j = 0; j < example.length; j++) {
                    example[j] = padding;
                }
                // Control the minimum size of the sequence.
                int minSize = minWindowSize + labelSize;
                int remainSize = seq.length - i;
                if (minSize <= remainSize) {
                    int expectLength = maxWindowSize + labelSize;
                    //Get the length of valid items.
                    int copyLength = Math.min(remainSize, expectLength);
                    int beg = expectLength - copyLength;
                    System.arraycopy(seq, i, example, beg, copyLength);
                    resultList.add(example);
                    //If the watch seq is exhausted.
                    if (copyLength < expectLength) {
                        break;
                    }
                } else {
                    break;
                }
            }
            return resultList;
        }
    }

    public static void main(String[] args) throws OdpsException {
        JCommander commander = new JCommander(argument);
        commander.parse(args);
        Job job = new Job();
        job.setInt("seq.max.length", argument.getSeqMaxLength());
        job.set("seq.splitter", argument.getSeqSplitter());
        job.set("seq.date.format", argument.getSeqDateFormat());
        job.setInt("seq.skip.steps", argument.getSkipSteps());
        job.setInt("seq.min.window", argument.getMinWindowSize());
        job.setInt("seq.max.window", argument.getMaxWindowSize());
        job.setInt("seq.label.size", argument.getLabelSize());
        job.setFloat("sample.rate", argument.getSampleRate());
        if (argument.getLeastClickSecond() != null) {
            job.setInt("least.click.second", argument.getLeastClickSecond());
        }

        MrJobParamSetter.addInput(job, argument.getInput(),
                new String[]{"userid", "utdid", "itemid", "title", "ctm", "click", "video_len"});
        MrJobParamSetter.addOutput(job, argument.getOutput());
        job.setOutputKeySortColumns(new String[]{"userid", "ctm"});
        job.setPartitionColumns(new String[]{"userid", "utdid"});
        job.setOutputGroupingColumns(new String[]{"userid", "utdid"});
        job.setMapperClass(WatchMapper.class);
        job.setReducerClass(SeqReducer.class);
        job.setMapOutputKeySchema(SchemaUtils.fromString("userid:string,ctm:bigint,utdid:string"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("itemid:string,title:string,ctm:bigint,click:bigint,play_rate:double"));
        boolean flag = job.waitForCompletion();
        if (!flag) {
            System.exit(1);
        }
    }

    public static class ArgumentContainer extends BaseArgContainer {
        @Parameter(names = "-seqMaxLength")
        private Integer seqMaxLength = 100;

        @Parameter(names = "-minWindowSize")
        private Integer minWindowSize = 5;

        @Parameter(names = "-maxWindowSize")
        private Integer maxWindowSize = 20;

        @Parameter(names = "-skipSteps")
        private Integer skipSteps = 5;

        @Parameter(names = "-labelSize")
        private Integer labelSize = 1;

        @Parameter(names = "-seqSplitter")
        private String seqSplitter = " ";

        @Parameter(names = "-seqDateFormat")
        private String seqDateFormat = "yyyy-MM-dd HH:mm:ss";

        @Parameter(names = "-leastClickSecond")
        private Integer leastClickSecond = 5;

        @Parameter(names = "-sampleRate")
        private Float sampleRate = 1.0f;

        public Float getSampleRate() {
            return sampleRate;
        }

        public void setSampleRate(Float sampleRate) {
            this.sampleRate = sampleRate;
        }

        public Integer getLeastClickSecond() {
            return leastClickSecond;
        }

        public void setLeastClickSecond(Integer leastClickSecond) {
            this.leastClickSecond = leastClickSecond;
        }

        public Integer getMinWindowSize() {
            return minWindowSize;
        }

        public void setMinWindowSize(Integer minWindowSize) {
            this.minWindowSize = minWindowSize;
        }

        public Integer getMaxWindowSize() {
            return maxWindowSize;
        }

        public void setMaxWindowSize(Integer maxWindowSize) {
            this.maxWindowSize = maxWindowSize;
        }

        public Integer getSkipSteps() {
            return skipSteps;
        }

        public void setSkipSteps(Integer skipSteps) {
            this.skipSteps = skipSteps;
        }

        public Integer getLabelSize() {
            return labelSize;
        }

        public void setLabelSize(Integer labelSize) {
            this.labelSize = labelSize;
        }

        public Integer getSeqMaxLength() {
            return seqMaxLength;
        }

        public void setSeqMaxLength(Integer seqMaxLength) {
            this.seqMaxLength = seqMaxLength;
        }

        public String getSeqSplitter() {
            return seqSplitter;
        }

        public void setSeqSplitter(String seqSplitter) {
            this.seqSplitter = seqSplitter;
        }

        public String getSeqDateFormat() {
            return seqDateFormat;
        }

        public void setSeqDateFormat(String seqDateFormat) {
            this.seqDateFormat = seqDateFormat;
        }
    }
}
