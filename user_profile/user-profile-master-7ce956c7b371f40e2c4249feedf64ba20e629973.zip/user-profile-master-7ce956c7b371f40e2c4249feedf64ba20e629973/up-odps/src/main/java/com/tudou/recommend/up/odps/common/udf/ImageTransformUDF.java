package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.google.common.primitives.UnsignedLong;
import com.wolong.common.util.CityHash;

/**
 * @author wangfei01
 * @date 2018/3/30
 */
public class ImageTransformUDF extends UDF {
    public String evaluate(String imageUrl) {
        if (imageUrl == null) {
            return null;
        }
        return convertToZZDImageUrl(imageUrl);
    }

    public static String convertToZZDImageUrl(String url) {
        String urlSign = UnsignedLong.fromLongBits(CityHash.cityHash64(url.getBytes(), 0, url.length())).toString();
        String zzdUrl = "http://image.uczzd.cn/" + urlSign + ".jpg?id=0";
        return zzdUrl;
    }


}
