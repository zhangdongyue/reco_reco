package com.tudou.recommend.up.odps.common.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;

public class EncryptUtil {
  private static final Logger logger = Logger.getLogger(EncryptUtil.class);

  public static String md5(String str) {
    MessageDigest md = null;
    try {
      md = MessageDigest.getInstance("md5");
      md.update(str.getBytes());
      byte[] md5Bytes = md.digest();
      return bytes2Hex(md5Bytes);
    } catch (NoSuchAlgorithmException e) {
      logger.error("exception caught in md5 method, reason: " + e.getMessage());
    }

    return null;
  }

  private static String bytes2Hex(byte[] byteArray) {
    StringBuffer strBuf = new StringBuffer();
    for (int i = 0; i < byteArray.length; i++) {
      if (byteArray[i] >= 0 && byteArray[i] < 16) {
        strBuf.append("0");
      }
      strBuf.append(Integer.toHexString(byteArray[i] & 0xFF));
    }
    return strBuf.toString();
  }

  /**
   * mask phone number. Keep the three prefix and four suffix digits and hide others. For instance,
   * 13811011011 -> 138****1011. Make sure the input number has 11 characters
   * 
   * @param number
   * @return
   */
  public static String maskPhone(String number) {
    if (number == null || (number = number.trim()).length() != 11) {
      return number;
    }

    return number.substring(0, 3) + "****" + number.substring(7);
  }

  /**
   * mask email address. Keep three prefix and on suffix character and hide others. For instance,
   * message@gmail.com -> mes***e@gmail.com. If the length of user name is less than four, no mask
   * will happen.
   * 
   * @param email
   * @return
   */
  public static String maskEmail(String email) {
    if (email == null || (email = email.trim()).length() == 0 || (email.indexOf('@') == -1)) {
      return email;
    }

    String[] ary = email.split("@");
    if (ary[0].length() <= 4) {
      return email;
    } else {
      StringBuilder builder = new StringBuilder();
      for (int i = 0; i < ary[0].length() - 4; i++) {
        builder.append('*');
      }
      return ary[0].substring(0, 3) + builder.toString() + ary[0].substring(ary[0].length() - 1)
          + "@" + ary[1];
    }

  }

  // a wrapper of city hash, just to be consistent with c++ api
  public static long calcUrlSign(String url) {
    return CityHash.cityHash64(url.getBytes(), 0, url.length());
  }
}
