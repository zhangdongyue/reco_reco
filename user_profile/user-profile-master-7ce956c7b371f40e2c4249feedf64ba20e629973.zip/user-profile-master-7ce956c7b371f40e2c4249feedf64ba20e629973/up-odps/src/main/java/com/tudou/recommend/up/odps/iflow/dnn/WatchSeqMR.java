package com.tudou.recommend.up.odps.iflow.dnn;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.google.common.base.Joiner;
import com.tudou.recommend.up.odps.common.util.BaseArgContainer;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * The MR will create user watch sequences according to click time.
 *
 * @author wangfei01
 * @date 2017/8/24
 */
public class WatchSeqMR {
    private static ArgumentContainer argument = new ArgumentContainer();

    public static class WatchMapper extends MapperBase {
        private Logger logger = LoggerFactory.getLogger(this.getClass());
        private Record outputKey;
        private Record outputValue;
        private String dateFormat;

        @Override
        public void setup(TaskContext context) throws IOException {
            outputKey = context.createMapOutputKeyRecord();
            outputValue = context.createMapOutputValueRecord();
            JobConf jobConf = context.getJobConf();
            dateFormat = jobConf.get("seq.date.format");
        }

        @Override
        public void map(long key, Record record, TaskContext context) throws IOException {
            String userId = record.getString("userid");
            String itemId = record.getString("itemid");
            String title = record.getString("title");
            String ctm = record.getString("ctm");
            Long click = record.getBigint("click");

            try {
                if (ctm != null && userId != null && itemId != null) {
                    long clickDate = DateUtils.parseDate(ctm, dateFormat).getTime();
                    long clickSecond = TimeUnit.MILLISECONDS.toSeconds(clickDate);
                    outputKey.setString("userid", userId);
                    outputKey.setBigint("ctm", clickSecond);
                    outputValue.setString("itemid", itemId);
                    outputValue.setString("title", title);
                    outputValue.setBigint("ctm", clickSecond);
                    outputValue.setBigint("click", click);
                    context.write(outputKey, outputValue);
                }
            } catch (ParseException e) {
                logger.error("Parse date:{} error", ctm, e);
            }
        }
    }

    public static class SeqReducer extends ReducerBase {
        private Record output;
        private Long maxInterval;
        private Integer maxLength;
        private Integer userMaxSeqNum;
        private Integer minSeqLength;
        private String seqSplitter;

        @Override
        public void setup(TaskContext context) throws IOException {
            output = context.createOutputRecord();
            JobConf conf = context.getJobConf();
            maxInterval = TimeUnit.HOURS.toSeconds(conf.getLong("seq.max.interval", 2L));
            maxLength = conf.getInt("seq.max.length", 100);
            userMaxSeqNum = conf.getInt("user.max.seq.num", 10);
            seqSplitter = conf.get("seq.splitter", " ");
            minSeqLength = conf.getInt("seq.min.length", 3);
        }

        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
            String userId = key.getString("userid");
            output.setString("userid", userId);
            long previousClickDate = 0;
            List<String> titleSeq = new ArrayList<>();
            List<String> itemSeq = new ArrayList<>();
            List<Long> clickDateSeq = new ArrayList<>();
            int seqLength = 0;
            int seqNum = 0;
            while (values.hasNext()) {
                if (seqNum >= userMaxSeqNum) {
                    break;
                }
                Record value = values.next();
                String title = value.getString("title");
                String itemId = value.getString("itemid");
                long currentClickDate = value.getBigint("ctm");
                long currentClick = value.getBigint("click");
                //If the sequence reach a break condition
                long timeGap = previousClickDate == 0 ? 0 : currentClickDate - previousClickDate;
                if (breakCondition(timeGap, seqLength)) {
                    writeSeq(itemSeq, titleSeq, clickDateSeq, seqLength, context);
                    seqLength = 0;
                    seqNum += 1;
                }
                itemSeq.add(itemId);
                titleSeq.add(title);
                clickDateSeq.add(currentClickDate);
                previousClickDate = currentClickDate + currentClick;
                seqLength += 1;
            }
            if (seqNum < userMaxSeqNum) {
                writeSeq(itemSeq, titleSeq, clickDateSeq, seqLength, context);
            }
        }

        public void writeSeq(List<String> itemSeq,
                             List<String> titleSeq,
                             List<Long> dateSeq,
                             int seqLength,
                             TaskContext context) throws IOException {
            if (seqLength >= minSeqLength) {
                output.setString("title_seq", Joiner.on(seqSplitter).join(titleSeq));
                output.setString("item_seq", Joiner.on(seqSplitter).join(itemSeq));
                output.setString("click_date_seq", Joiner.on(seqSplitter).join(dateSeq));
                output.setBigint("seq_length", (long) seqLength);
                context.write(output);
            }
            itemSeq.clear();
            titleSeq.clear();
            dateSeq.clear();
        }

        boolean breakCondition(long timeGap, int seqLength) {
            if (timeGap > maxInterval) {
                return true;
            }
            if (seqLength >= maxLength) {
                return true;
            }
            return false;
        }
    }

    public static void main(String[] args) throws OdpsException {
        JCommander commander = new JCommander(argument);
        commander.parse(args);
        Job job = new Job();
        job.setInt("seq.max.length", argument.getSeqMaxLength());
        job.setInt("seq.max.interval", argument.getSeqMaxInterval());
        job.set("seq.splitter", argument.getSeqSplitter());
        job.set("seq.date.format", argument.getSeqDateFormat());
        job.setInt("user.max.seq.num", argument.getUserMaxSeqNum());
        job.setInt("seq.min.length", argument.getSeqMinLength());

        MrJobParamSetter.addInput(job, argument.getInput(),
                new String[]{"userid", "itemid", "title", "ctm", "click"});
        MrJobParamSetter.addOutput(job, argument.getOutput());
        job.setOutputKeySortColumns(new String[]{"userid", "ctm"});
        job.setPartitionColumns(new String[]{"userid"});
        job.setOutputGroupingColumns(new String[]{"userid"});
        job.setMapperClass(WatchMapper.class);
        job.setReducerClass(SeqReducer.class);
        job.setMapOutputKeySchema(SchemaUtils.fromString("userid:string,ctm:bigint"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("itemid:string,title:string,ctm:bigint,click:bigint"));
        boolean flag = job.waitForCompletion();
        if (!flag) {
            System.exit(1);
        }
    }

    public static class ArgumentContainer extends BaseArgContainer {
        @Parameter(names = "-seqMaxLength")
        private Integer seqMaxLength = 100;

        @Parameter(names = "-seqMaxInterval")
        private Integer seqMaxInterval = 1;

        @Parameter(names = "-seqSplitter")
        private String seqSplitter = " ";

        @Parameter(names = "-seqDateFormat")
        private String seqDateFormat = "yyyy-MM-dd HH:mm:ss";

        @Parameter(names = "-userMaxSeqNum")
        private Integer userMaxSeqNum = 10;

        @Parameter(names = "-seqMinLength")
        private Integer seqMinLength = 3;

        public Integer getSeqMinLength() {
            return seqMinLength;
        }

        public void setSeqMinLength(Integer seqMinLength) {
            this.seqMinLength = seqMinLength;
        }

        public Integer getUserMaxSeqNum() {
            return userMaxSeqNum;
        }

        public void setUserMaxSeqNum(Integer userMaxSeqNum) {
            this.userMaxSeqNum = userMaxSeqNum;
        }

        public Integer getSeqMaxLength() {
            return seqMaxLength;
        }

        public Integer getSeqMaxInterval() {
            return seqMaxInterval;
        }

        public void setSeqMaxInterval(Integer seqMaxInterval) {
            this.seqMaxInterval = seqMaxInterval;
        }

        public void setSeqMaxLength(Integer seqMaxLength) {
            this.seqMaxLength = seqMaxLength;
        }

        public String getSeqSplitter() {
            return seqSplitter;
        }

        public void setSeqSplitter(String seqSplitter) {
            this.seqSplitter = seqSplitter;
        }

        public String getSeqDateFormat() {
            return seqDateFormat;
        }

        public void setSeqDateFormat(String seqDateFormat) {
            this.seqDateFormat = seqDateFormat;
        }
    }
}
