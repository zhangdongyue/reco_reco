package com.tudou.recommend.up.odps.common.util;

import com.tudou.recommend.up.odps.common.entity.ProfileDeviceIdentity;
import com.tudou.recommend.up.odps.common.entity.log.MergeLog;
import com.tudou.recommend.up.odps.common.entity.ProfileAcountIdentity;
import com.tudou.recommend.up.odps.common.entity.ProfileDataIdentity;
import com.tudou.recommend.up.odps.common.entity.UserAccountInfo;
import com.tudou.recommend.up.odps.common.entity.log.ClickLog;

public class UserAccountUtil {
  
  public static String generateProfileKey(MergeLog mergeLog, String userIdType) {
    if (mergeLog == null || userIdType == null) {
      return null;
    }
    String appName = convertAppName(mergeLog.getAppName());
    return generateProfileKey(mergeLog, userIdType, appName);
  }
  
  /**
   * 生成profile key
   * @param mergeLog
   * @param userIdType
   * @return null表示生成失败
   */
  public static String generateProfileKey(MergeLog mergeLog, String userIdType, String dataIdentity) {
    if (mergeLog == null || userIdType == null) {
      return null;
    }
    if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.XSS_USER_ID)) {
      // xss user id
      String userId = mergeLog.getUserId();
      String appname = mergeLog.getAppName();
      if (userId == null || userId.isEmpty()) {
        return null;
      }
      if (appname == null || appname.isEmpty()) {
    	  return null;
      }
      return DataFormatUtil.GenProfileKey(appname, ProfileDeviceIdentity.XSS_USER_ID, userId);
    } else if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.UTDID)) {
      // utdid
      String utdid = mergeLog.getUtdid();
      if (utdid == null || utdid.isEmpty()) {
        return null;
      }
      return DataFormatUtil.GenProfileKey(dataIdentity, ProfileDeviceIdentity.UTDID, utdid);
    } else if (userIdType.equalsIgnoreCase(ProfileAcountIdentity.UC)) {
      // uc account
      UserAccountInfo account = UserAccountInfo.parseFromJson(mergeLog.getAccountInfo());
      if (account == null || account.ucAccount == null || account.ucAccount.isEmpty()) {
        return null;
      } else {
        return DataFormatUtil.GenProfileKey(dataIdentity, ProfileAcountIdentity.UC, account.ucAccount);
      }
    } else if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.ICLOUD_ID)) {
      // icloud id
      UserAccountInfo account = UserAccountInfo.parseFromJson(mergeLog.getAccountInfo());
      if (account == null || account.icloudAccount == null || account.icloudAccount.isEmpty()) {
        return null;
      } else {
        return DataFormatUtil.GenProfileKey(dataIdentity, ProfileDeviceIdentity.ICLOUD_ID, account.icloudAccount);
      }
    } else if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.IMEI_OR_IDFA)) {
      // imei / idfa
      String imei = mergeLog.getImei();
      String appname = mergeLog.getAppName();
      if (imei == null || imei.isEmpty()) {
        return null;
      }
      if (appname == null || appname.isEmpty()) {
    	  appname = ProfileDeviceIdentity.IMEI_OR_IDFA;
      }
      
      // add by jinchanghu. 20170625
      if (dataIdentity.equals(ProfileDataIdentity.TD_LONG)) {
    	  dataIdentity = ProfileDataIdentity.TD;		//临时设定
    	  appname = ProfileDeviceIdentity.IMEI_OR_IDFA;
      }
      
      return DataFormatUtil.GenProfileKey(dataIdentity, appname, imei);
    } else {
      return null;
    }
  }
  
  public static String generateProfileKey(MergeLog mergeLog){
    return generateProfileKey(mergeLog, ProfileDeviceIdentity.XSS_USER_ID);
  }
  
  public static String generateProfileKey(ClickLog clickLog, String userIdType) {
    if (clickLog == null || userIdType == null) {
      return null;
    }
    if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.XSS_USER_ID)) {
      // xss user id
      String userId = clickLog.getUserId();
      if (userId == null || userId.isEmpty()) {
        return null;
      }
      String appName = convertAppName(clickLog.getAppName());
      return DataFormatUtil.GenProfileKey(appName, ProfileDeviceIdentity.XSS_USER_ID, userId);
    } else if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.UTDID)) {
      // utdid
      String utdid = clickLog.getUtdid();
      if (utdid == null || utdid.isEmpty()) {
        return null;
      }
      String appName = convertAppName(clickLog.getAppName());
      return DataFormatUtil.GenProfileKey(appName, ProfileDeviceIdentity.UTDID, utdid);
    } else if (userIdType.equalsIgnoreCase(ProfileAcountIdentity.UC)) {
      // uc account
      String ucAccount = clickLog.getTacid();
      if (ucAccount == null || ucAccount.isEmpty()) {
        return null;
      } else {
        String appName = convertAppName(clickLog.getAppName());
        return DataFormatUtil.GenProfileKey(appName, ProfileAcountIdentity.UC, ucAccount);
      }
    } else if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.ICLOUD_ID)) {
      // icloud id
      String icloudAccount = clickLog.getTuicid();
      if (icloudAccount == null || icloudAccount.isEmpty()) {
        return null;
      } else {
        String appName = convertAppName(clickLog.getAppName());
        return DataFormatUtil.GenProfileKey(appName, ProfileDeviceIdentity.ICLOUD_ID, icloudAccount);
      }
    } else {
      // 默认 appName-userId
      String userId = clickLog.getUserId();
      String appName = convertAppName(clickLog.getAppName());
      if (userId.isEmpty() || "0".equals(userId)) {
        return null;
      } else {
        return DataFormatUtil.GenUserKey(userId, appName);
      }
    }
  }
  
  public static String generateProfileKey(ClickLog clickLog){
    return generateProfileKey(clickLog, ProfileDeviceIdentity.XSS_USER_ID);
  }
  
  public static String convertAppName(String appName) {
    if (appName == null || appName.isEmpty()) {
      return "uc";
    } else {
      return appName;
    }
  }
}
