package com.tudou.recommend.up.odps.common.udf;

import java.util.HashSet;

import com.aliyun.odps.udf.UDF;

public class GetIncludeTagCountUDF extends UDF {
	public String evaluate(String profileTags, String actionTags, String delimitor, String seperator) {
		if (profileTags == null || actionTags == null || delimitor == null || seperator == null) {
			return null;
		}
		
		if (profileTags.isEmpty() || actionTags.isEmpty() || delimitor.isEmpty() || seperator.isEmpty()) {
			return null;
		}
		
		HashSet<String> tagSet = new HashSet<String>();
		String[] tokens1 = profileTags.split(delimitor);
		for (int i = 0; i < tokens1.length; i++) {
			String featureInfo = tokens1[i];
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String[] tokens = featureInfo.split(seperator);
			if (tokens.length >= 3) {
				if (!tokens[0].isEmpty()) {
					tagSet.add(tokens[0]);
				}
			} 
		}
		
		if (tagSet.size() == 0) {
			return null;
		}
		
		int totalTag1 = 0;
		int totalTag2 = 0;
		String[] tokens2 = actionTags.split(delimitor);
		for (int i = 0; i < tokens2.length; i++) {
			String featureInfo = tokens2[i];
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String[] tokens = featureInfo.split(seperator);
			if (tokens.length >= 3) {
				if (!tokens[0].isEmpty()) {
					if (tagSet.contains(tokens[0])) {
						totalTag1 ++;
					}
					totalTag2 ++;
				}
			}
		}
		
		StringBuilder sb = new StringBuilder();
		sb.append(totalTag1);
		sb.append("\t");
		sb.append(totalTag2);
		
		return sb.toString();
		
	}
}
