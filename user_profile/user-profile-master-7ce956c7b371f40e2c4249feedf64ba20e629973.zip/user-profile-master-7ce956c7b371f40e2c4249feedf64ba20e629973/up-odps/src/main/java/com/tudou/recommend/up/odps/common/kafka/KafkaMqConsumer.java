package com.tudou.recommend.up.odps.common.kafka;

import gnu.trove.impl.Constants;
import gnu.trove.map.hash.TLongLongHashMap;
import kafka.consumer.Consumer;
import kafka.consumer.ConsumerConfig;
import kafka.consumer.ConsumerIterator;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;
import kafka.message.MessageAndMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Kafka队列的消费者
 * <p/>
 * Created by yumeng on 15/3/9.
 */
public class KafkaMqConsumer {
  private static final Logger logger = LoggerFactory.getLogger(KafkaMqConsumer.class);

  private ConsumerConfig consumerConfig;
  private ConsumerConnector consumer;
  private String topic;
  private KafkaStream<byte[], byte[]> stream;
  private TLongLongHashMap offsetMap;

  public KafkaMqConsumer(Properties properties, String topic) {
    // 配置样例
    // properties.setProperty("zookeeper.connect", "10.3.5.55:2181/kafka");
    // properties.setProperty("group.id", "consumer.group");
    // 从队列头开始读
    // properties.setProperty("auto.offset.reset", "smallest");
    // Add by pengdan: 否则 大消息传送失败, 抛异常：kafka.common.MessageSizeTooLargeException
    if (!properties.contains("fetch.message.max.bytes")) {
      properties.setProperty("fetch.message.max.bytes", String.valueOf(1024 * 1024 * 64));
    }
    this.consumerConfig = new ConsumerConfig(properties);
    this.topic = topic;
    this.offsetMap =
        new TLongLongHashMap(Constants.DEFAULT_CAPACITY, Constants.DEFAULT_LOAD_FACTOR, -1L, -1L);
  }

  protected void initConnection() {
    if (consumer == null) {
      synchronized (this) {
        if (consumer == null) {
          consumer = Consumer.createJavaConsumerConnector(consumerConfig);
          Map<String, Integer> topicCountMap = new HashMap<>();
          topicCountMap.put(topic, 1);
          Map<String, List<KafkaStream<byte[], byte[]>>> consumerMap =
              consumer.createMessageStreams(topicCountMap);
          List<KafkaStream<byte[], byte[]>> streams = consumerMap.get(topic);
          if (streams.size() != 1) {
            throw new RuntimeException("Consumer stream number is not 1");
          }
          stream = streams.get(0);
        }
      }
    }
  }

  public synchronized MessageAndMetadata<byte[], byte[]> fetch() {
    initConnection();
    ConsumerIterator<byte[], byte[]> iter = stream.iterator();
    while (iter.hasNext()) {
      MessageAndMetadata<byte[], byte[]> item = iter.next();
      long consumedOffset = offsetMap.get(item.partition());
      if (item.offset() > consumedOffset) {
        offsetMap.put(item.partition(), item.offset());
        logger.info("Consume: partition=" + item.partition() + ", offset=" + item.offset()
            + ", message_size=" + item.message().length);
        return item;
      } else {
        logger.info("Skip: partition=" + item.partition() + ", offset=" + item.offset()
            + ", message_size=" + item.message().length);
        continue;
      }
    }
    return null;
  }

  public void commitOffsets() {
    consumer.commitOffsets();
  }

  /**
   * 重置consumer
   */
  public synchronized void reset() {
    this.consumer = null;
  }
}
