package com.tudou.recommend.up.odps.newtd.ugc;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;

import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;
import com.tudou.recommend.up.odps.common.entity.interest.InterestElem;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import org.apache.commons.lang3.StringUtils;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;

/**
 * 1)对User Interest进行截断和排序; 2)剔除已下线tag
 * @author jinchanghu
 * @date 2018年1月8日 下午3:54:33
 */
public class UserUgcInterestFilter {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class UserInterestFilterMapper extends MapperBase {
		private Record k2;
		private Record v2;
		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			k2.setString(0, record.getString(0));	// user_id
			v2.setString(0, record.getString(0));	// user_id
			v2.setString(1, record.getString(1));	// feature_type
			v2.setString(2, record.getString(2));	// interest
			context.write(k2, v2);
		}
	}

	public static class UserInterestFilterReducer extends ReducerBase {
		private Record result;
		private static final DecimalFormat DF = DataFormatUtil
				.getDefaultDecimalFormater();
		// feature top N thresholds
		int maxFeatureNumber;
		int maxCategoryNumber;
		int minTagNumber;
		int maxTagNumber;
		double tagWeightThreshold;
		int minKeywordNumber;
		int maxKeywordNumber;
		double keywordWeightThreshold;
		int minPlsaTopicNumber;
		int maxPlsaTopicNumber;
		double plsaTopicWeightThreshold;
		int maxRegionNumber;
		int maxSourceNumber;
		int maxTopicNumber;
		int maxVideoCategoryNumber;
		int minVideoTagNumber;
		int maxVideoTagNumber;
		int maxVideoNoCateTagNumber;

		// tag white list
//		private HashSet<String> tagList = new HashSet<String>();

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
			// get configs
			JobConf conf = context.getJobConf();
			maxFeatureNumber = conf.getInt("maxFeatureNumber", 100);
			maxCategoryNumber = conf.getInt("maxCategoryNumber", 100);
			minTagNumber = conf.getInt("minTagNumber", 5);
			maxTagNumber = conf.getInt("maxTagNumber", 30);
			tagWeightThreshold = Double.parseDouble(conf.get(
					"tagWeightThreshold", "3.0"));
			minKeywordNumber = conf.getInt("minKeywordNumber", 5);
			maxKeywordNumber = conf.getInt("maxKeywordNumber", 30);
			keywordWeightThreshold = Double.parseDouble(conf.get(
					"keywordWeightThreshold", "3.0"));
			minPlsaTopicNumber = conf.getInt("minPlsaTopicNumber", 5);
			maxPlsaTopicNumber = conf.getInt("maxPlsaTopicNumber", 20);
			plsaTopicWeightThreshold = Double.parseDouble(conf.get(
					"plsaTopicWeightThreshold", "1.0"));
			maxRegionNumber = conf.getInt("maxRegionNumber", 20);
			maxSourceNumber = conf.getInt("maxSourceNumber", 50);
			maxTopicNumber = conf.getInt("maxTopicNumber", 100);
			maxVideoCategoryNumber = conf.getInt("maxVideoCategoryNumber", 100);
			minVideoTagNumber = conf.getInt("minVideoTagNumber", 5);
			maxVideoTagNumber = conf.getInt("maxVideoTagNumber", 30);
			maxVideoNoCateTagNumber = conf.getInt("maxVideoNoCateTagNumber",
					100);
			
			// read tag list from resource file
//			Iterator<Record> values = context.readResourceTable(conf.get("tagListTable"));
//			while (values.hasNext()) {
//				tagList.add(values.next().getString(0));
//			}
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			// interest
			// feaType ~ feaHashCode ~ interestElem
			HashMap<Integer, ArrayList<InterestElem>> interestsMap = new HashMap<Integer, ArrayList<InterestElem>>();
			Record r;
			while (values.hasNext()) {
				r = values.next();
				int feaType = Integer.parseInt(r.getString(1));

				if (!interestsMap.containsKey(feaType)) {
					interestsMap.put(feaType, new ArrayList<InterestElem>());
				}
				if (StringUtils.isNotBlank(r.getString(2))) {
					parseInterests(r.getString(2).split("\t", -1),
							interestsMap.get(feaType));
				}
			}

			int feaType;
			

			// video category
			ArrayList<InterestElem> l1VideoCategories = new ArrayList<InterestElem>();
			feaType = ProfileFeatureType.VIDEO_CATEGORY.getValue();
			if (interestsMap.containsKey(feaType)) {
				ArrayList<InterestElem> results = filterInterest(
						interestsMap.get(feaType), maxVideoCategoryNumber);
				interestsMap.put(feaType, results);
				for (InterestElem category : results) {
					if (!category.term.contains(Contents.CATEGORY_SEP)) {
						l1VideoCategories.add(category);
					}
				}
			}

			// video tag
			feaType = ProfileFeatureType.VIDEO_TAG.getValue();
			if (interestsMap.containsKey(feaType)) {
				// TODO: 过滤已下线标签的逻辑
				ArrayList<InterestElem> results = filterInterestWithCategory(
						interestsMap.get(feaType), l1VideoCategories,
						minVideoTagNumber, maxVideoTagNumber, 0);
				interestsMap.put(feaType, results);
			}

			// video tag without category
			feaType = ProfileFeatureType.VIDEO_TAG_WITHOUT_CATEGORY.getValue();
			if (interestsMap.containsKey(feaType)) {
				ArrayList<InterestElem> results = filterInterest(
						interestsMap.get(feaType), maxVideoNoCateTagNumber);
				interestsMap.put(feaType, results);
			}

			// video source
			feaType = ProfileFeatureType.VIDEO_SOURCE.getValue();
			if (interestsMap.containsKey(feaType)) {
				ArrayList<InterestElem> results = filterInterest(
						interestsMap.get(feaType), maxFeatureNumber);
				interestsMap.put(feaType, results);
			}
			
			// seed career
			feaType = ProfileFeatureType.SEED_CAREER.getValue();
			if (interestsMap.containsKey(feaType)) {
				ArrayList<InterestElem> results = filterInterest(
						interestsMap.get(feaType), maxFeatureNumber);
				interestsMap.put(feaType, results);
			}
			
			// seed address
			feaType = ProfileFeatureType.SEED_ADDRESS.getValue();
			if (interestsMap.containsKey(feaType)) {
				ArrayList<InterestElem> results = filterInterest(
						interestsMap.get(feaType), maxFeatureNumber);
				interestsMap.put(feaType, results);
			}
			
			// output
			ArrayList<Integer> feaTypes = new ArrayList<Integer>(
					interestsMap.keySet());
			Collections.sort(feaTypes);
			StringBuilder builder = new StringBuilder();
			for (int feaTypeKey : feaTypes) {
				ArrayList<InterestElem> interests = interestsMap
						.get(feaTypeKey);
				for (InterestElem interest : interests) {
					if (builder.length() > 0) {
						builder.append("\t");
					}
					builder.append(interest.term).append("::")
							.append(DF.format(interest.interest)).append("::")
							.append(DF.format(interest.confidence))
							.append("::").append(DF.format(interest.ctr));
				}
				result.setString(0, key.getString(0));// user_id
				result.setString(1, String.valueOf(feaTypeKey));// feature_type
				result.setString(2, builder.toString());// interest
				context.write(result);
				builder.delete(0, builder.length());
			}
		}

		private ArrayList<InterestElem> filterInterest(
				ArrayList<InterestElem> interests, int topN) {
			sortInterests(interests);
			return new ArrayList<InterestElem>(getTopNInterestElem(interests,
					topN));
		}

		/**
		 * 对各类别下的feature排序取topN
		 * 
		 * @param interests
		 * @param categories
		 * @param topN
		 * @return
		 */
		private ArrayList<InterestElem> filterInterestWithCategory(
				ArrayList<InterestElem> interests,
				ArrayList<InterestElem> categories, int topNMin, int topNMax,
				double weightThre) {
			ArrayList<InterestElem> results = new ArrayList<InterestElem>();
			HashMap<String, ArrayList<InterestElem>> interestMap = new HashMap<String, ArrayList<InterestElem>>();
			for (InterestElem elem : interests) {
				String[] flds = elem.term.split(Contents.CATEGORY_SEP, -1);
				if (!interestMap.containsKey(flds[0])) {
					interestMap.put(flds[0], new ArrayList<InterestElem>());
				}
				interestMap.get(flds[0]).add(elem);
			}
			// 各类别内部排序
			for (InterestElem elem : categories) {
				String cate = elem.term;
				if (!interestMap.containsKey(cate)) {
					continue;
				}
				ArrayList<InterestElem> cateInterests = interestMap.get(cate);
				sortInterests(cateInterests);
				List<InterestElem> topNInterests = getTopNInterestElem(
						cateInterests, topNMin, topNMax, weightThre);
				results.addAll(topNInterests);
			}
			return results;
		}

		/**
		 * 按weight降序排列
		 * 
		 * @param interestElemArr
		 */
		private void sortInterests(List<InterestElem> interestElemArr) {
			if (interestElemArr == null) {
				return;
			}

			// sort by interest desc
			Collections.sort(interestElemArr, new Comparator<InterestElem>() {
				public int compare(InterestElem elem1, InterestElem elem2) {
					Double d1 = new Double(elem1.interest);
					Double d2 = new Double(elem2.interest);
					return Double.compare(d2, d1);
				}
			});
		}

		/**
		 * interest取topN
		 * 
		 * @param interestElemArr
		 * @param topN
		 * @return
		 */
		private List<InterestElem> getTopNInterestElem(
				List<InterestElem> interestElemArr, int topNMin, int topNMax,
				double weightThre) {
			if (interestElemArr == null) {
				return null;
			}
			List<InterestElem> results = new ArrayList<InterestElem>();
			for (int i = 0; i < interestElemArr.size(); ++i) {
				if (i < topNMin) {
					results.add(interestElemArr.get(i));
				} else if (i >= topNMax) {
					break;
				} else {
					if (interestElemArr.get(i).interest >= weightThre) {
						results.add(interestElemArr.get(i));
					}
				}
			}
			return results;
		}

		private List<InterestElem> getTopNInterestElem(
				List<InterestElem> interestElemArr, int topN) {
			return getTopNInterestElem(interestElemArr, 0, topN, -1);
		}

		/**
		 * 解析user interest
		 * 
		 * @param fields
		 * @param interestArr
		 * @return
		 */
		private boolean parseInterests(String[] fields,
				ArrayList<InterestElem> interestArr) {
			if (fields == null || interestArr == null) {
				return false;
			}

			for (int i = 0; i < fields.length; ++i) {
				String[] ss = fields[i].split("::", -1);
				if (ss.length < 3) {
					return false;
				}
				String term = ss[0];
				float interest = Float.parseFloat(ss[1]);
				float confidence = Float.parseFloat(ss[2]);
				float ctr = ss.length > 3 ? Float.parseFloat(ss[3]) : 0;
				interestArr.add(new InterestElem(term, "", interest,
						confidence, ctr));
			}
			return true;
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils
				.fromString("user_id:string,feature_type:string,interest:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {
				"user_id", "feature_type", "interest" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		job.setMapperClass(UserInterestFilterMapper.class);
		job.setReducerClass(UserInterestFilterReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		//MrJobParamSetter.setSplitSize(job, 128L);

		job.setInt("maxFeatureNumber", argContainer.getMaxFeatureNumber());
		job.setInt("maxCategoryNumber", argContainer.getMaxCategoryNumber());
		job.setInt("minTagNumber", argContainer.getMinTagNumber());
		job.setInt("maxTagNumber", argContainer.getMaxTagNumber());
		job.set("tagWeightThreshold", argContainer.getTagWeightThreshold());
		job.setInt("minKeywordNumber", argContainer.getMinKeywordNumber());
		job.setInt("maxKeywordNumber", argContainer.getMaxKeywordNumber());
		job.set("keywordWeightThreshold",
				argContainer.getKeywordWeightThreshold());
		job.setInt("minPlsaTopicNumber", argContainer.getMinPlsaTopicNumber());
		job.setInt("maxPlsaTopicNumber", argContainer.getMaxPlsaTopicNumber());
		job.set("plsaTopicWeightThreshold",
				argContainer.getPlsaTopicWeightThreshold());
		job.setInt("maxRegionNumber", argContainer.getMaxRegionNumber());
		job.setInt("maxSourceNumber", argContainer.getMaxSourceNumber());
		job.setInt("maxTopicNumber", argContainer.getMaxTopicNumber());
		job.setInt("maxVideoCategoryNumber",
				argContainer.getMaxVideoCategoryNumber());
		job.setInt("minVideoTagNumber", argContainer.getMinVideoTagNumber());
		job.setInt("maxVideoTagNumber", argContainer.getMaxVideoTagNumber());
		job.setInt("maxVideoNoCateTagNumber",
				argContainer.getMaxVideoNoCateTagNumber());
		job.set("tagListTable", argContainer.getTagListFile());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-maxFeatureNumber", description = "maximun number of user profile features")
		private int maxFeatureNumber = 100;

		@Parameter(names = "-maxCategoryNumber", description = "")
		private int maxCategoryNumber = 100;

		@Parameter(names = "-minTagNumber", description = "")
		private int minTagNumber = 5;

		@Parameter(names = "-maxTagNumber", description = "")
		private int maxTagNumber = 30;

		@Parameter(names = "-tagWeightThreshold", description = "")
		private String tagWeightThreshold = "3.0";

		@Parameter(names = "-minKeywordNumber", description = "")
		private int minKeywordNumber = 5;

		@Parameter(names = "-maxKeywordNumber", description = "")
		private int maxKeywordNumber = 30;

		@Parameter(names = "-keywordWeightThreshold", description = "")
		private String keywordWeightThreshold = "3.0";

		@Parameter(names = "-minPlsaTopicNumber", description = "")
		private int minPlsaTopicNumber = 5;

		@Parameter(names = "-maxPlsaTopicNumber", description = "")
		private int maxPlsaTopicNumber = 20;

		@Parameter(names = "-plsaTopicWeightThreshold", description = "")
		private String plsaTopicWeightThreshold = "1.0";

		@Parameter(names = "-maxRegionNumber", description = "")
		private int maxRegionNumber = 20;

		@Parameter(names = "-maxSourceNumber", description = "")
		private int maxSourceNumber = 50;

		@Parameter(names = "-maxTopicNumber", description = "")
		private int maxTopicNumber = 100;

		@Parameter(names = "-maxVideoCategoryNumber", description = "")
		private int maxVideoCategoryNumber = 100;

		@Parameter(names = "-minVideoTagNumber", description = "")
		private int minVideoTagNumber = 5;

		@Parameter(names = "-maxVideoTagNumber", description = "")
		private int maxVideoTagNumber = 30;

		@Parameter(names = "-maxVideoNoCateTagNumber", description = "")
		private int maxVideoNoCateTagNumber = 100;

		@Parameter(names = "-tagListTable", description = "")
		private String tagListTable = "";

		public int getMaxFeatureNumber() {
			return maxFeatureNumber;
		}

		public void setMaxFeatureNumber(int maxFeatureNumber) {
			this.maxFeatureNumber = maxFeatureNumber;
		}

		public int getMaxCategoryNumber() {
			return maxCategoryNumber;
		}

		public void setMaxCategoryNumber(int maxCategoryNumber) {
			this.maxCategoryNumber = maxCategoryNumber;
		}

		public int getMinTagNumber() {
			return minTagNumber;
		}

		public void setMinTagNumber(int minTagNumber) {
			this.minTagNumber = minTagNumber;
		}

		public int getMaxTagNumber() {
			return maxTagNumber;
		}

		public void setMaxTagNumber(int maxTagNumber) {
			this.maxTagNumber = maxTagNumber;
		}

		public String getTagWeightThreshold() {
			return tagWeightThreshold;
		}

		public void setTagWeightThreshold(String tagWeightThreshold) {
			this.tagWeightThreshold = tagWeightThreshold;
		}

		public int getMinKeywordNumber() {
			return minKeywordNumber;
		}

		public void setMinKeywordNumber(int minKeywordNumber) {
			this.minKeywordNumber = minKeywordNumber;
		}

		public int getMaxKeywordNumber() {
			return maxKeywordNumber;
		}

		public void setMaxKeywordNumber(int maxKeywordNumber) {
			this.maxKeywordNumber = maxKeywordNumber;
		}

		public String getKeywordWeightThreshold() {
			return keywordWeightThreshold;
		}

		public void setKeywordWeightThreshold(String keywordWeightThreshold) {
			this.keywordWeightThreshold = keywordWeightThreshold;
		}

		public int getMinPlsaTopicNumber() {
			return minPlsaTopicNumber;
		}

		public void setMinPlsaTopicNumber(int minPlsaTopicNumber) {
			this.minPlsaTopicNumber = minPlsaTopicNumber;
		}

		public int getMaxPlsaTopicNumber() {
			return maxPlsaTopicNumber;
		}

		public void setMaxPlsaTopicNumber(int maxPlsaTopicNumber) {
			this.maxPlsaTopicNumber = maxPlsaTopicNumber;
		}

		public String getPlsaTopicWeightThreshold() {
			return plsaTopicWeightThreshold;
		}

		public void setPlsaTopicWeightThreshold(String plsaTopicWeightThreshold) {
			this.plsaTopicWeightThreshold = plsaTopicWeightThreshold;
		}

		public int getMaxRegionNumber() {
			return maxRegionNumber;
		}

		public void setMaxRegionNumber(int maxRegionNumber) {
			this.maxRegionNumber = maxRegionNumber;
		}

		public int getMaxSourceNumber() {
			return maxSourceNumber;
		}

		public void setMaxSourceNumber(int maxSourceNumber) {
			this.maxSourceNumber = maxSourceNumber;
		}

		public int getMaxTopicNumber() {
			return maxTopicNumber;
		}

		public void setMaxTopicNumber(int maxTopicNumber) {
			this.maxTopicNumber = maxTopicNumber;
		}

		public int getMaxVideoCategoryNumber() {
			return maxVideoCategoryNumber;
		}

		public void setMaxVideoCategoryNumber(int maxVideoCategoryNumber) {
			this.maxVideoCategoryNumber = maxVideoCategoryNumber;
		}

		public int getMaxVideoTagNumber() {
			return maxVideoTagNumber;
		}

		public void setMaxVideoTagNumber(int maxVideoTagNumber) {
			this.maxVideoTagNumber = maxVideoTagNumber;
		}

		public int getMaxVideoNoCateTagNumber() {
			return maxVideoNoCateTagNumber;
		}

		public void setMaxVideoNoCateTagNumber(int maxVideoNoCateTagNumber) {
			this.maxVideoNoCateTagNumber = maxVideoNoCateTagNumber;
		}

		public int getMinVideoTagNumber() {
			return minVideoTagNumber;
		}

		public void setMinVideoTagNumber(int minVideoTagNumber) {
			this.minVideoTagNumber = minVideoTagNumber;
		}

		public String getTagListFile() {
			return tagListTable;
		}

		public void setTagListFile(String tagListFile) {
			this.tagListTable = tagListFile;
		}

	}
}
