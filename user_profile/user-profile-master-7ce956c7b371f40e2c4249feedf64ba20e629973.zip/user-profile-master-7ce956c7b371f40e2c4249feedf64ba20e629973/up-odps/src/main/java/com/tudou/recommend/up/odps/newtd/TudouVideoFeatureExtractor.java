package com.tudou.recommend.up.odps.newtd;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.proto.ProtoCommon.ItemType;
import com.tudou.recommend.proto.ProtoConvertorServer;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.newtd.entity.TudouItemInfo;
import com.wolong.protorpc.client.pool.PooledRpcClient;
import com.wolong.protorpc.client.protobuf.DefaultBlockingRpcChannel;
import com.wolong.protorpc.model.DefaultRpcController;
import com.wolong.protorpc.model.RpcClientConf;

public class TudouVideoFeatureExtractor {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class TudouVideoFeatureExtractorMapper extends MapperBase {
		private Record result;
		private String addresses = "";
		private int timeout = 2000;
		private boolean useDescription;
		private boolean useSource;
		private ProtoConvertorServer.ConvertorService.BlockingInterface convertService;
		private PooledRpcClient rpcClient;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
			JobConf conf = context.getJobConf();
			addresses = conf.get("rpcServerIps");
			timeout = conf.getInt("rpcTimeout", 1000);
			useDescription = (conf.getInt("useDescription", 0) == 1);
			// useTag = (conf.getInt("useTag", 0) == 1);
			useSource = (conf.getInt("useSource", 0) == 1);
			// sleepMillSec = conf.getInt("sleepMillSec", 0);

			try {
				initClient();
			} catch (Exception e) {
				try {
					throw new Exception(e);
				} catch (Exception e1) {
				}
			}

		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			TudouItemInfo info = new TudouItemInfo();
			if (!info.parseFromStr(record.getString(0))) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_map_input").increment(1L);
				return;
			}

			ProtoConvertorServer.ExtractFeatureRequest.Builder builder = ProtoConvertorServer.ExtractFeatureRequest
					.newBuilder();
			builder.setReturnCategory(true).setReturnTag(true);
			builder.setTitle(info.vdoTitle);

			if (useDescription) {
				builder.setContent(info.vdoDesc);
			}
			if (useSource) {
				builder.setSource(info.vdoSource);
			}
			ProtoConvertorServer.ExtractFeatureRequest request = builder
					.build();
			DefaultRpcController controller = new DefaultRpcController();
			ProtoConvertorServer.ExtractFeatureResponse response = null;

			int retry = 3;

			try {
				while (retry > 0) {
					try {
						response = convertService.extractFeature(controller,
								request);
					} catch (Exception e) {
						retry--;
						closeRpcClient();
						initClient();
						continue;
					}
					break;
				}
			} catch (Exception e) {
				try {
					throw new Exception(e);
				} catch (Exception e1) {
				}
			}

			if (response == null || !response.getSuccess()) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"failed_to_extract_fea").increment(1L);
				return;
			}
			ArrayList<String> categories = new ArrayList<String>();
			ArrayList<String> tags = new ArrayList<String>();
			categories.addAll(response.getCategoryList());
			tags.addAll(response.getTagsList());

			StringBuilder sb = new StringBuilder();
			String sep = "::";
			// item type ~ isGlobalManual
			result.setString(1, ItemType.kPureVideo.toString());
			result.setString(2, "0");

			String parentCategory = "";
			for (int i = 0; i < categories.size(); ++i) {
				String category = categories.get(i);
				if ("未分类".equals(category)) {
					break;
				}

				String fullCategory;
				if (parentCategory.length() == 0) { // 一级类别
					fullCategory = category;
				} else { // 子类别
					fullCategory = parentCategory + Contents.CATEGORY_SEP
							+ category;
				}
				parentCategory = fullCategory;
				double weight = 1; // category 权重设为1
				if (sb.length() > 0) {
					sb.append("\t");
				}
				sb.append(ProfileFeatureType.VIDEO_CATEGORY.getValue())
						.append(sep).append(fullCategory).append(sep)
						.append(weight);
			}
			String level1Category = categories.size() > 0 ? categories.get(0)
					: "未分类";

			// tag
			for (String tag : tags) {
				String tagStr = level1Category + Contents.CATEGORY_SEP + tag;
				if (sb.length() > 0) {
					sb.append("\t");
				}
				sb.append(ProfileFeatureType.VIDEO_TAG.getValue()).append(sep)
						.append(tagStr).append(sep).append(1.0);
			}

			// video length
			if (sb.length() > 0) {
				sb.append("\t");
			}
			sb.append(ProfileFeatureType.VIDEO_LENGTH.getValue()).append(sep)
					.append(info.vdoLen).append(sep).append(1);
			result.setString(3, sb.toString());
			context.write(result);
		}

		@Override
		public void cleanup(TaskContext context) throws IOException {
			try {
				closeRpcClient();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void initClient() throws Exception {
			RpcClientConf conf = new RpcClientConf(addresses, timeout, -1);
			conf.setvNodeNum(2048);
			conf.setEnableHA(true);
			rpcClient = new PooledRpcClient(conf);
			rpcClient.bootstrap();
			convertService = ProtoConvertorServer.ConvertorService
					.newBlockingStub(new DefaultBlockingRpcChannel(rpcClient));
		}

		public void closeRpcClient() throws Exception {
			if (rpcClient != null && !rpcClient.isStopped()) {
				rpcClient.stop();
			}
		}
	}

	public static class TudouVideoFeatureExtractorReducer extends ReducerBase {
		private Record result;
		private long sleepMillSec = 0;
		private long totalTime = 0;
		private long itemNum = 0;
		private Long startTime;
		private static final Logger logger = Logger
				.getLogger(TudouVideoFeatureExtractor.class);
		// convertor server
		VideoFeatureExtractor feaExtractor = new VideoFeatureExtractor();

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
			JobConf conf = context.getJobConf();
			feaExtractor.setRpcServerAddress(conf.get("rpcServerIps"));
			feaExtractor.setRpcTimeout(conf.getInt("rpcTimeout", 1000));
			feaExtractor.setRpcRetry(conf.getInt("rpcRetry", 10000));
			feaExtractor
					.setUseDescription(conf.getInt("useDescription", 0) == 1);
			feaExtractor.setUseTag(conf.getInt("useTag", 0) == 1);
			feaExtractor.setUseSource(conf.getInt("useSource", 0) == 1);
			feaExtractor.initRpcConnection();

			sleepMillSec = conf.getInt("sleepMillSec", 0);
			startTime = System.currentTimeMillis();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			StringBuilder bld = new StringBuilder();
			result.setString(0, key.getString(0));
			while (values.hasNext()) {
				TudouItemInfo item = new TudouItemInfo();
				if (!item.parseFromStr(values.next().getString(0))) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_reduce_input").increment(1L);
					continue;
				}
				ArrayList<String> categories = new ArrayList<String>();
				ArrayList<String> tags = new ArrayList<String>();
				if (!feaExtractor.extractFeature(item, categories, tags)) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"failed_to_extract_fea").increment(1L);
					continue;
				}

				bld.delete(0, bld.length());
				String sep = "::";
				// item type ~ isGlobalManual
				result.setString(1, ItemType.kPureVideo.toString());
				result.setString(2, "0");

				String parentCategory = "";
				for (int i = 0; i < categories.size(); ++i) {
					String category = categories.get(i);
					if ("未分类".equals(category)) {
						break;
					}

					String fullCategory;
					if (parentCategory.length() == 0) { // 一级类别
						fullCategory = category;
					} else { // 子类别
						fullCategory = parentCategory + Contents.CATEGORY_SEP
								+ category;
					}
					parentCategory = fullCategory;
					double weight = 1; // category 权重设为1
					if (bld.length() > 0) {
						bld.append("\t");
					}
					bld.append(ProfileFeatureType.VIDEO_CATEGORY.getValue())
							.append(sep).append(fullCategory).append(sep)
							.append(weight);
				}
				String level1Category = categories.size() > 0 ? categories
						.get(0) : "未分类";

				// tag
				for (String tag : tags) {
					String tagStr = level1Category + Contents.CATEGORY_SEP
							+ tag;
					if (bld.length() > 0) {
						bld.append("\t");
					}
					bld.append(ProfileFeatureType.VIDEO_TAG.getValue())
							.append(sep).append(tagStr).append(sep).append(1.0);
				}

				// video length
				if (bld.length() > 0) {
					bld.append("\t");
				}
				bld.append(ProfileFeatureType.VIDEO_LENGTH.getValue())
						.append(sep).append(item.vdoLen).append(sep).append(1);
				result.setString(3, bld.toString());
				context.write(result);
			}
			if (sleepMillSec > 0) {
				try {
					Thread.sleep(sleepMillSec);
				} catch (InterruptedException e) {
				}
			}
			totalTime = System.currentTimeMillis() - startTime;
			itemNum += 1;

			if (itemNum % 100 == 0) {
				logger.info("userNum=" + itemNum + ", totalSeconds="
						+ totalTime / 1000 + ", qps=" + itemNum
						/ (double) (totalTime / 1000));
			}
		}

		@Override
		public void cleanup(TaskContext context) throws IOException {
			feaExtractor.closeRpcConnection();
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("v2:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(),
				new String[] { "item" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(TudouVideoFeatureExtractorMapper.class);
		// TODO: specify a reducer
		// job.setReducerClass(TudouVideoFeatureExtractorReducer.class);
		job.setNumReduceTasks(0);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		// MrJobParamSetter.setSplitSize(job, 128L);

		job.set("rpcServerIps", argContainer.getRpcServerIps());
		job.setInt("rpcTimeout", argContainer.getRpcTimeout());
		job.setInt("rpcRetry", argContainer.getRpcRetry());
		job.setInt("sleepMillSec", argContainer.getSleepMillSec());
		job.setInt("useDescription", argContainer.getUseDescription());
		job.setInt("useTag", argContainer.getUseTag());
		job.setInt("useSource", argContainer.getUseSource());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);

	}

	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-rpcServerIps", description = "user server ips")
		private String rpcServerIps = "";

		@Parameter(names = "-rpcTimeout", description = "rpc time out")
		private int rpcTimeout = 500;

		@Parameter(names = "-rpcRetry", description = "rpc time out")
		private int rpcRetry = 0;

		@Parameter(names = "-sleepMillSec", description = "sleep time (ms) after each rpc call")
		private int sleepMillSec = 0;

		@Parameter(names = "-useDescription", description = "")
		private int useDescription = 0;

		@Parameter(names = "-useTag", description = "")
		private int useTag = 0;

		@Parameter(names = "-useSource", description = "")
		private int useSource = 0;

		public String getRpcServerIps() {
			return rpcServerIps;
		}

		public void setRpcServerIps(String rpcServerIps) {
			this.rpcServerIps = rpcServerIps;
		}

		public int getRpcTimeout() {
			return rpcTimeout;
		}

		public void setRpcTimeout(int rpcTimeout) {
			this.rpcTimeout = rpcTimeout;
		}

		public int getRpcRetry() {
			return rpcRetry;
		}

		public void setRpcRetry(int rpcRetry) {
			this.rpcRetry = rpcRetry;
		}

		public int getSleepMillSec() {
			return sleepMillSec;
		}

		public void setSleepMillSec(int sleepMillSec) {
			this.sleepMillSec = sleepMillSec;
		}

		public int getUseDescription() {
			return useDescription;
		}

		public void setUseDescription(int useDescription) {
			this.useDescription = useDescription;
		}

		public int getUseTag() {
			return useTag;
		}

		public void setUseTag(int useTag) {
			this.useTag = useTag;
		}

		public int getUseSource() {
			return useSource;
		}

		public void setUseSource(int useSource) {
			this.useSource = useSource;
		}

	}
}
