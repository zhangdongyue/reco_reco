package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;

public class ExtractInterestByTypeUDF extends UDF {
	public String evaluate(String interestType, String interestInfo, String delimitor, String seperator) {
		if (interestInfo == null || interestType == null || delimitor == null || seperator == null) {
			return null;
		}
		
		if (interestType.isEmpty() || delimitor.isEmpty() || seperator.isEmpty()) {
			return null;
		}
		
		String[] tokens = interestInfo.split(delimitor);
		for (int i = 0; i < tokens.length; i++) {
			String featureInfo = tokens[i].trim();
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String prefix = interestType + seperator;
			if (featureInfo.startsWith(prefix)) {
				String result = featureInfo.substring(prefix.length());
				result = result.replaceAll("\t", " | ");
				return result;
			}
		}
		
		return null;
	}
}
