package com.tudou.recommend.up.odps.common.udf;

import java.util.*;

import com.aliyun.odps.udf.UDF;

public class CompareTwoTagsUDF extends UDF {
	public String evaluate(String tag1, String tag2, String delimitor, String seperator) {
		if (tag1 == null || tag2 == null || delimitor == null || seperator == null) {
			return null;
		}
		
		if (tag1.isEmpty() || tag2.isEmpty() || delimitor.isEmpty() || seperator.isEmpty()) {
			return null;
		}
		
		HashSet<String> tagSet = new HashSet<String>();
		String[] tokens1 = tag1.split(delimitor);
		for (int i = 0; i < tokens1.length; i++) {
			String featureInfo = tokens1[i];
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String[] tokens = featureInfo.split(seperator);
			if (tokens.length >= 3) {
				if (!tokens[0].isEmpty()) {
					tagSet.add(tokens[0]);
				}
			} 
		}
		
		if (tagSet.size() == 0) {
			return null;
		}
		
		int totalTag1 = 0;
		int totalTag2 = 0;
		String[] tokens2 = tag2.split(delimitor);
		for (int i = 0; i < tokens2.length; i++) {
			String featureInfo = tokens2[i];
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String[] tokens = featureInfo.split(seperator);
			if (tokens.length >= 3) {
				if (!tokens[0].isEmpty()) {
					if (tagSet.contains(tokens[0])) {
						totalTag1 ++;
					}
					totalTag2 ++;
				}
			}
		}
		
		if (totalTag2 == 0) {
			return null;
		}
		
		if (totalTag1 == totalTag2) {
			if (tagSet.size() == totalTag1) {
				return "0";		// tag1 == tag2
			} else {
				return "1";		// tag1 > tag2
			}
		} else {
			if (tagSet.size() == totalTag1) {
				return "-1";	// tag1 < tag2
			} else {
				return "2";		//  tag1 <> tag2
			}
		}
		
	}
}
