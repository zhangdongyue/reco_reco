package com.tudou.recommend.up.odps.common.kafka;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;


/**
 * Kafka消息列表的生产者
 * <p>
 * Created by yumeng on 15/3/9. New Version of Kafka Client
 */
public class KafkaProducer<T> {
    protected Properties producerConfig;
    protected Producer<String, T> producer;

    private Callback defaultAsyncCallback = new Callback() {
        @Override
        public void onCompletion(RecordMetadata metadata, Exception exception) {


        }
    };

    KafkaProducer(Properties config, long logIntervalMs) {
        producerConfig = new Properties();
        for (Map.Entry<Object, Object> entry : config.entrySet()) {
            producerConfig.put(entry.getKey(), entry.getValue());
        }
        String keySerCls = producerConfig.getProperty("key.serializer", null);
        if (keySerCls == null) {
            producerConfig.setProperty("key.serializer",
                    "org.apache.kafka.common.serialization.StringSerializer");
        }
        String valueSerCls = producerConfig.getProperty("value.serializer", null);
        if (valueSerCls == null) {
            producerConfig.setProperty("value.serializer",
                    "org.apache.kafka.common.serialization.ByteArraySerializer");
        }
    }

    // 懒惰连接
    protected void initConnection() {
        if (producer == null) {
            synchronized (this) {
                if (producer == null) {
                    producer = new org.apache.kafka.clients.producer.KafkaProducer<>(producerConfig);
                }
            }
        }
    }

    /**
     * 同步发送一个消息到topic中，按key哈希分片，value是消息内容
     *
     * @param topic
     * @param key
     * @param value
     * @return 返回发送成功的消息个数
     */
    public void send(String topic, Integer partition, String key, T value)
            throws ExecutionException, InterruptedException {
        initConnection();
        ProducerRecord<String, T> record = new ProducerRecord<>(topic, partition, key, value);
        Future<RecordMetadata> future = this.producer.send(record);
        RecordMetadata recordMetadata = future.get();
    }

    public void send(String topic, String key, T value)
            throws ExecutionException, InterruptedException {
        send(topic, null, key, value);
    }

    /**
     * 异步发送一个消息到topic中，按key哈希分片，value是消息内容
     *
     * @param topic
     * @param key
     * @param value
     * @return 返回发送成功的消息个数
     */
    public Future<RecordMetadata> asyncSend(String topic, String key, T value) {
        initConnection();
        ProducerRecord<String, T> record = new ProducerRecord<>(topic, null, key, value);
        return this.producer.send(record, defaultAsyncCallback);
    }

    /**
     * 异步发送一个消息到topic中，按key哈希分片，value是消息内容
     *
     * @param topic
     * @param partition 指定发送到哪个partition
     * @param key
     * @param value
     * @return 返回发送成功的消息个数
     */
    public Future<RecordMetadata> asyncSend(String topic, Integer partition, String key, T value) {
        initConnection();
        ProducerRecord<String, T> record = new ProducerRecord<>(topic, partition, key, value);
        return this.producer.send(record, defaultAsyncCallback);
    }

    public void close() {
        if (this.producer != null) {
            synchronized (this) {
                if (this.producer != null) {
                    this.producer.close();
                    this.producer = null;
                }
            }
        }
    }

}
