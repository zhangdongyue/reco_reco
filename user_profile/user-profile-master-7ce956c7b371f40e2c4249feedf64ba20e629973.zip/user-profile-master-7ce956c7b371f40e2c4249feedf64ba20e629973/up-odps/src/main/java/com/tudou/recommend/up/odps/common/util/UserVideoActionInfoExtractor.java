package com.tudou.recommend.up.odps.common.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import com.tudou.recommend.proto.ProtoCommon.ItemType;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;
import com.tudou.recommend.up.odps.common.entity.log.MergeLog;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.tudou.recommend.up.odps.common.entity.ActionTypes;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.item.ItemFeature;
import com.tudou.recommend.up.odps.common.entity.item.RecoItemInfo;

/**
 * 用户在视频上的行为特征抽取
 * 
 * @author hezhimin
 *
 */
public class UserVideoActionInfoExtractor {
	/**
	 * FEA_WEIGHT: 特征的实际权重
	 * ONE： 权重设置 1.0f
	 * @author jinchanghu
	 * @date 2017年6月22日 上午10:04:41
	 */
	enum WeightType {
		/**
		 * 1.0f
		 */
		ONE,
		/**
		 * 特征的实际权重
		 */
		FEA_WEIGHT
	}

	private static final Logger logger = Logger
			.getLogger(UserVideoActionInfoExtractor.class);

	// 全局设置信息（对所有用户生效）
	// 各行为权重
	private HashMap<String, Float> actionWeights = new HashMap<String, Float>();

	// 是否排除全量运营新闻
	private boolean excludeGlobalDeliveredManualNews = false;

	// 是否使用阅读比例调权
	private boolean readProgressTuning = false;
	private boolean readLengthTuning = false;
	private float minReadProgressThre = 0;
	private float maxReadProgressThre = 1.0f;
	// 视频长度和平均播放时长的映射
	private HashMap<Integer, Float> videoLenAvgPlayTimeMap = new HashMap<Integer, Float>();

	// 缓存的item info
	private HashMap<String, RecoItemInfo> itemInfoMap = new HashMap<String, RecoItemInfo>();

	// debug 模式
	private boolean debug = false;

	// 缺乏item info的item数
	private long noInfoItemNum = 0;

	// 单个用户统计结果
	// 用户在term上的行为权重和: termType ~ term ~ value
	private HashMap<Integer, HashMap<String, Float>> weightSumMap = new HashMap<Integer, HashMap<String, Float>>();
	// 用户在term上的总行为次数: termType ~ term ~ value
	private HashMap<Integer, HashMap<String, Float>> clickSumMap = new HashMap<Integer, HashMap<String, Float>>();

	// 记录推荐id
	private HashSet<String> recoIds = new HashSet<String>();

	// 主动刷新recoId和对应的channel
	private HashMap<String, Long> recoIdChMap = new HashMap<String, Long>();

	// 记录点击次数和刷新次数
	private int clickNum = 0;
	private int pushNum = 0;

	// 记录总阅读时长
	private float readSeconds = 0;

	// 记录推荐时间，判断碎片/连贯阅读
	private HashMap<String, Long> recoTimestamps = new HashMap<String, Long>();

	/**
	 * 注意：clear方法默认只清除（单个用户）局部统计结果, 如需清除所有信息，请调用clear(true)
	 */
	public void clear() {
		clear(false);
	}

	public void clear(boolean clearAll) {
		// 清除全局设置和词典信息
		if (clearAll) {
			actionWeights.clear();
			excludeGlobalDeliveredManualNews = false;
			readProgressTuning = false;
			minReadProgressThre = 0;
			maxReadProgressThre = 1.0f;
			itemInfoMap.clear();
			debug = false;
			noInfoItemNum = 0;
		}
		// 清除局部统计结果
		weightSumMap.clear();
		clickSumMap.clear();
		recoIds.clear();
		recoIdChMap.clear();
		clickNum = 0;
		pushNum = 0;
		readSeconds = 0;
		recoTimestamps.clear();
	}

	public void process(MergeLog mergeLog) {
		process(mergeLog, null);
	}

	/**
	 *
	 * 判断一篇文章是否是世界杯相关的文章
	 *
	 * @author lfk
	 * @date 2018/7/11 下午5:29
	 */
	public boolean isWorldCupItem(RecoItemInfo recoItemInfo) {
		if(recoItemInfo.tags.size() > 0) {
			for(ItemFeature i : recoItemInfo.tags) {
				if(i.feature.contains("世界杯")) {
					return true;
				}
			}
		}
		if(recoItemInfo.eventTags.size() > 0) {
			for(ItemFeature i : recoItemInfo.eventTags) {
				if(i.feature.contains("世界杯")) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * 从merge log中统计用户行为信息
	 * 
	 * @param mergeLog
	 */
	public void process(MergeLog mergeLog, RecoItemInfo item) {
		if (mergeLog == null) {
			return;
		}

		// 记录每次推荐的时间戳（仅主动刷新计入有效推荐）
		Long recoTimestamp = DataFormatUtil.getTimestamp(mergeLog.getTime());
		if (recoTimestamp != null && mergeLog.getAuto() == 0) {
			recoTimestamps.put(mergeLog.getRecoId(), recoTimestamp);
		}

		// get item info from cache
		// String itemId = mergeLog.getItemId();
		// RecoItemInfo item = itemInfoMap.get(itemId);
		if (item == null) {
			noInfoItemNum++;
			return;
		}

		// 过滤全量运营新闻, 纯视频新闻不过滤
		if (item.isGlobalManualNews == 1 && excludeGlobalDeliveredManualNews) {
			return;
		}

		boolean isClicked = mergeLog.getClickSeconds() > 3;

		// 行为加权
		float actionWeight = UserActionInfoExtractUtil.calcActionWeight(
				mergeLog, actionWeights);
		if(isWorldCupItem(item)) {
			actionWeight = actionWeight * 0.3f;
		}
		if (debug) {
			logger.info("actionWeight=" + actionWeight);
		}

		HashMap<String, Integer> videoPlayInfo = parseVideoPlayInfo(mergeLog);
		if (videoPlayInfo != null) {
			// 自动连播调权
			if (videoPlayInfo.containsKey("auto")
					&& videoPlayInfo.get("auto") == 1
					&& actionWeights.containsKey(ActionTypes.VideoAutoPlay
							.getValue().toLowerCase())) {
				actionWeight *= actionWeights.get(ActionTypes.VideoAutoPlay
						.getValue().toLowerCase());
				if (debug) {
					logger.info("#auto play: actionWeight=" + actionWeight
							+ ", log=" + mergeLog.toString());
				}
			}
		}
		
		// 阅读时长调权 (add by jinchanghu. 20170610)
		// 使用在长视频场景
		/** 观看时长小于10秒的惩罚系数高. 
		 * played=3,factor=0.00091; played=4,factor=0.00247; played=5,factor=0.006; 
		 * played=6,factor=0.0179; played=7,factor=0.0474; played=8,factor=0.11; 
		 * played=9,factor=0.2689; played=10,factor=0.5;  played=11,factor=0.73;
		 * played=12,factor=0.88; played=13,factor=0.952; played=14,factor=0.982;
		 *  played=15,factor=0.993; played=16,factor=0.997;
		**/
		if (readLengthTuning && item.videoLength != null) { 
			float played = mergeLog.getClickSeconds(); 						// 实际播放时长，单位秒
			int len = (int) Double.parseDouble(item.videoLength.feature); 	// 视频长度
			
			float factor = (float) MathUtil.sigmoid(played-10);		
			if (factor > 0) {											
				actionWeight *= factor;									
			}															
		}

		// 阅读比例调权
		// 图文阅读比例直接用客户端回传结果（readProgress）
		// 视频播放比率需要根据readSeconds 和 video length自行计算
		if (readProgressTuning && item.videoLength != null) {
			float readProgress = 1;
			float played = mergeLog.getClickSeconds(); 						// 实际播放时长，单位秒
			int len = (int) Double.parseDouble(item.videoLength.feature); 	// 视频长度
			if (len > 0 && videoLenAvgPlayTimeMap.containsKey(len)) {	 	// 平均播放时长表只保存长度小于605秒的视频的信息
				float avgPlayLen = videoLenAvgPlayTimeMap.get(len);
				if (avgPlayLen > 0 && played >= 0 && played < avgPlayLen) {
					readProgress = played / avgPlayLen;
					if (debug) {
						logger.info("#read progress: progress=" + readProgress
								+ ", log=" + mergeLog.toString());
					}
				}
			}
			float factor = 0.0f; // 阅读比例折扣系数
			if (readProgress < minReadProgressThre) {
				factor = 0.0f;
			} else if (readProgress >= maxReadProgressThre) {
				factor = 1.0f;
			} else {
				factor = (readProgress - minReadProgressThre)
						/ (maxReadProgressThre - minReadProgressThre);
			}
			actionWeight *= factor;
		}
		if (debug) {
			logger.info("actionWeight after tunning=" + actionWeight);
		}

		if (actionWeight > 0) {
			if (item.itemType.equalsIgnoreCase(ItemType.kPureVideo.toString())) {
				// video category
				addItemFeatures(item.videoCategories, actionWeight, weightSumMap, clickSumMap, WeightType.ONE);
				if (debug) {
					logger.info("add video category, size="
							+ item.videoCategories.size());
				}
				// video source
				addItemFeatures(item.videoSource, actionWeight, weightSumMap, clickSumMap, WeightType.ONE);
				
				// title lda topic
				addItemFeatures(item.titleLdaTopics, actionWeight, weightSumMap, clickSumMap, WeightType.ONE);
				
				if (debug) {
					logger.info("add video source, size="
							+ item.videoSource.size());
				}
				// video tag
				// tag做合并处理
				HashMap<String, ItemFeature> tags = new HashMap<String, ItemFeature>();
				for (ItemFeature tag : item.videoTags) {
					if (debug) {
						logger.info("add tag, tag_fea=" + tag.toString());
					}
					String[] flds = tag.feature
							.split(Contents.CATEGORY_SEP, -1);
					if (flds.length != 2) {
						continue;
					}

					// 不同类型的tag的设置不同的权重：人工1.0，机器0.7
					boolean isManual = flds[1].startsWith("manual");
					float weight = isManual ? 1.0f : 0.7f;

					String category = flds[0];
					String[] tagFlds = flds[1].split(":", -1);
					String tagStr = tagFlds[tagFlds.length - 1]; // 不带类目
					
					if (tagStr.isEmpty()) {
						continue;
					}
					
					String tagStrWithCate = category + Contents.CATEGORY_SEP
							+ tagStr; // 带类目

					// 带类目tag
					if (!tags.containsKey(tagStrWithCate)) {
						ItemFeature tagFea = new ItemFeature(tag.featureType,
								tagStrWithCate, weight);
						tags.put(tagStrWithCate, tagFea);
					} else {
						if (tags.get(tagStrWithCate).weight < weight) {
							tags.get(tagStrWithCate).weight = weight;
						}
					}

					// 不带类目tag
					if (!tags.containsKey(tagStr)) {
						ItemFeature tagFea = new ItemFeature(
								ProfileFeatureType.VIDEO_TAG_WITHOUT_CATEGORY
										.getValue(),
								tagStr, weight);
						tags.put(tagStr, tagFea);
					} else {
						if (tags.get(tagStr).weight < weight) {
							tags.get(tagStr).weight = weight;
						}
					}
				}
				addItemFeatures(new ArrayList<ItemFeature>(tags.values()),
						actionWeight, weightSumMap, clickSumMap,
						WeightType.FEA_WEIGHT);
			} else {
				logger.info("not video item");
			}

			if (isClicked) {
				clickNum += 1;
			}

			// 阅读时段
			if (isClicked) {
				String timeStr = mergeLog.getTime();
				Long timestamp = DataFormatUtil.getTimestamp(timeStr);
				if (timestamp != null) {
					int hour = UserActionInfoExtractUtil
							.convertToHour(timestamp);
					ItemFeature itemFea = new ItemFeature(
							ProfileFeatureType.VIDEO_DURATION.getValue(),
							String.valueOf(hour), 1.0f);
					addItemFeature(itemFea, actionWeight, weightSumMap,
							clickSumMap, WeightType.ONE);

					int weekDay = UserActionInfoExtractUtil
							.convertToWeekDay(timestamp);
					itemFea = new ItemFeature(
							ProfileFeatureType.VIDEO_WEEK_DAY.getValue(),
							String.valueOf(weekDay), 1.0f);
					addItemFeature(itemFea, actionWeight, weightSumMap,
							clickSumMap, WeightType.ONE);
				}
			}

			// 阅读时长,时长大于10小时的记录被剔除
			int clickSeconds = mergeLog.getClickSeconds();
			if (clickSeconds > 3 && clickSeconds < 3600 * 10) {
				readSeconds += clickSeconds;
			}

			// 长度喜好
			if (item.videoLength != null) {
				double len = Double.parseDouble(item.videoLength.feature);
				String lenRange = UserActionInfoExtractUtil
						.convertVideoLength(len);
				ItemFeature itemFea = new ItemFeature(
						ProfileFeatureType.VIDEO_LENGTH.getValue(), lenRange,
						1.0f);
				addItemFeature(itemFea, actionWeight, weightSumMap,
						clickSumMap, WeightType.ONE);
			}

			// 网络状态
			if (mergeLog.getNetwork() != null) {
				String network = mergeLog.getNetwork();
				if(!network.isEmpty()) {
					ItemFeature itemFea = new ItemFeature(ProfileFeatureType.VIDEO_NETWORK.getValue(), network, 1.0f);
					addItemFeature(itemFea, actionWeight, weightSumMap,	clickSumMap, WeightType.ONE);
				}
			}
		}
	}

	/**
	 * 计算汇总类指标
	 */
	public void merge() {

		// 阅读时长
		if (readSeconds > 0) {
			ItemFeature itemFea = new ItemFeature(
					ProfileFeatureType.VIDEO_READ_TIME.getValue(), "total",
					readSeconds);
			addItemFeature(itemFea, 1, weightSumMap, clickSumMap,
					WeightType.FEA_WEIGHT);
		}

		// 点击次数
		if (clickNum > 0) {
			ItemFeature itemFea = new ItemFeature(
					ProfileFeatureType.VIDEO_CLICK_SUM.getValue(), "total",
					clickNum);
			addItemFeature(itemFea, 1, weightSumMap, clickSumMap,
					WeightType.FEA_WEIGHT);
		}
	}

	private void addItemFeatures(ArrayList<ItemFeature> itemTerms,
			float actionWeight,
			HashMap<Integer, HashMap<String, Float>> weightSumMap,
			HashMap<Integer, HashMap<String, Float>> clickSumMap,
			WeightType weightType) {
		for (int i = 0; i < itemTerms.size(); ++i) {
			addItemFeature(itemTerms.get(i), actionWeight, weightSumMap,
					clickSumMap, weightType);
		}
	}

	private void addItemFeature(ItemFeature itemTerm, float actionWeight,
			HashMap<Integer, HashMap<String, Float>> weightSumMap,
			HashMap<Integer, HashMap<String, Float>> clickSumMap,
			WeightType weightType) {
		int feaType = itemTerm.featureType;
		String fea = itemTerm.feature;

		if (!weightSumMap.containsKey(feaType)) {
			weightSumMap.put(feaType, new HashMap<String, Float>());
		}
		if (!weightSumMap.get(feaType).containsKey(fea)) {
			weightSumMap.get(feaType).put(fea, 0.0f);
		}
		if (!clickSumMap.containsKey(feaType)) {
			clickSumMap.put(feaType, new HashMap<String, Float>());
		}
		if (!clickSumMap.get(feaType).containsKey(fea)) {
			clickSumMap.get(feaType).put(fea, 0.0f);
		}
		float weight = 0;
		if (weightType == WeightType.ONE) {
			weight = 1.0f;
		} else if (weightType == WeightType.FEA_WEIGHT) {
			weight = itemTerm.weight;
		}
		weightSumMap.get(feaType).put(fea,
				weightSumMap.get(feaType).get(fea) + actionWeight * weight);
		clickSumMap.get(feaType).put(fea,
				clickSumMap.get(feaType).get(fea) + actionWeight);
	}

	/**
	 * 解析merge log中视频播放信息
	 * 
	 * @param log
	 * @return
	 */
	private HashMap<String, Integer> parseVideoPlayInfo(MergeLog log) {
		if (log == null || log.getFlds().length < 85) {
			return null;
		}

		HashMap<String, Integer> infoMap = new HashMap<String, Integer>();
		String jsonStr = log.getFlds()[84];
		if (jsonStr.isEmpty()) {
			return null;
		}
		
		try {
			JSONObject json = JSONObject.parseObject(jsonStr);
			String key = "auto";
			if (json.keySet().contains(key)) {
				infoMap.put(key, json.getInteger(key));
			}
			key = "played";
			if (json.keySet().contains(key)) {
				infoMap.put(key, json.getInteger(key));
			}
			key = "video_len";
			if (json.keySet().contains(key)) {
				infoMap.put(key, json.getInteger(key));
			}
		} catch (Exception e) {
			return null;
		}

		return infoMap;
	}

	public HashMap<String, Float> getActionWeights() {
		return actionWeights;
	}

	public void setActionWeights(HashMap<String, Float> actionWeights) {
		this.actionWeights = actionWeights;
	}

	public HashMap<String, RecoItemInfo> getItemInfoMap() {
		return itemInfoMap;
	}

	public void setItemInfoMap(HashMap<String, RecoItemInfo> itemInfoMap) {
		this.itemInfoMap = itemInfoMap;
	}

	public boolean isDebug() {
		return debug;
	}

	public void setDebug(boolean debug) {
		this.debug = debug;
	}

	public boolean isExcludeGlobalDeliveredManualNews() {
		return excludeGlobalDeliveredManualNews;
	}

	public void setExcludeGlobalDeliveredManualNews(
			boolean excludeGlobalDeliveredManualNews) {
		this.excludeGlobalDeliveredManualNews = excludeGlobalDeliveredManualNews;
	}

	public boolean isReadProgressTuning() {
		return readProgressTuning;
	}

	public void setReadProgressTuning(boolean readProgressTuning) {
		this.readProgressTuning = readProgressTuning;
	}
	
	public boolean isReadLengthTuning() {
		return readLengthTuning;
	}
	
	public void setReadLengthTuning(boolean readLengthTuning) {
		this.readLengthTuning = readLengthTuning;
	}

	public float getMinReadProgressThre() {
		return minReadProgressThre;
	}

	public void setMinReadProgressThre(float minReadProgressThre) {
		this.minReadProgressThre = minReadProgressThre;
	}

	public float getMaxReadProgressThre() {
		return maxReadProgressThre;
	}

	public void setMaxReadProgressThre(float maxReadProgressThre) {
		this.maxReadProgressThre = maxReadProgressThre;
	}

	public long getNoInfoItemNum() {
		return noInfoItemNum;
	}

	public void setNoInfoItemNum(long noInfoItemNum) {
		this.noInfoItemNum = noInfoItemNum;
	}

	public HashMap<Integer, HashMap<String, Float>> getWeightSumMap() {
		return weightSumMap;
	}

	public void setWeightSumMap(
			HashMap<Integer, HashMap<String, Float>> weightSumMap) {
		this.weightSumMap = weightSumMap;
	}

	public HashMap<Integer, HashMap<String, Float>> getClickSumMap() {
		return clickSumMap;
	}

	public void setClickSumMap(
			HashMap<Integer, HashMap<String, Float>> clickSumMap) {
		this.clickSumMap = clickSumMap;
	}

	public HashSet<String> getRecoIds() {
		return recoIds;
	}

	public void setRecoIds(HashSet<String> recoIds) {
		this.recoIds = recoIds;
	}

	public int getClickNum() {
		return clickNum;
	}

	public void setClickNum(int clickNum) {
		this.clickNum = clickNum;
	}

	public int getPushNum() {
		return pushNum;
	}

	public void setPushNum(int pushNum) {
		this.pushNum = pushNum;
	}

	public float getReadSeconds() {
		return readSeconds;
	}

	public void setReadSeconds(float readSeconds) {
		this.readSeconds = readSeconds;
	}

	public HashMap<String, Long> getRecoTimestamps() {
		return recoTimestamps;
	}

	public void setRecoTimestamps(HashMap<String, Long> recoTimestamps) {
		this.recoTimestamps = recoTimestamps;
	}

	public HashMap<Integer, Float> getVideoLenAvgPlayTimeMap() {
		return videoLenAvgPlayTimeMap;
	}

	public void setVideoLenAvgPlayTimeMap(
			HashMap<Integer, Float> videoLenAvgPlayTimeMap) {
		this.videoLenAvgPlayTimeMap = videoLenAvgPlayTimeMap;
	}


}
