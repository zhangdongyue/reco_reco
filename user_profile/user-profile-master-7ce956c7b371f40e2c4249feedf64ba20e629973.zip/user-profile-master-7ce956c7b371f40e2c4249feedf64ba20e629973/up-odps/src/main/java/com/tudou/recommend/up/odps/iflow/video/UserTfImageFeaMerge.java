package com.tudou.recommend.up.odps.iflow.video;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.lang.*;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;

import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
/**
 * 
 * @author wj148482
 *
 */
public class UserTfImageFeaMerge {
	private static MrArgContainer argContainer = new MrArgContainer();
	private static final Logger logger = LoggerFactory.getLogger(UserTfImageFeaMerge.class);
	
	
	public static class MyMapper extends MapperBase {
		private Record k2;
		private Record v2;
		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
		}
		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
						
			k2.setString(0, record.getString(0));
			v2.setDouble(0, record.getDouble(2)); // p_wei
			v2.setDouble(1, record.getDouble(3)); // v_wei
			v2.setString(2,  record.getString(4)); // ince3Vec
			context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "ads_up_user_item_tf_image_fea_tmp_d input").increment(1L);
			context.write(k2, v2);
		}
	}
	public static class MyReducer extends ReducerBase {
		private Record result;
		private Float alpha = (float)0.5;
		private Float beta = (float)0.5;
		private int dim = 2048;
		
		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();	
			JobConf conf = context.getJobConf();
			alpha = conf.getFloat("alpha", (float)0.5);
			beta = conf.getFloat("beta", (float)0.5);
			dim = conf.getInt("dim", 2048);
			
		}
		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			
			List<Double> logPWeiList = new ArrayList<Double> ();
			List<Double> logVWeiList = new ArrayList<Double> ();
			List<String> ince3VecList = new ArrayList<String> ();
			
			double [] sumFeaVec = new double[dim];
			for (int i = 0; i < dim; i ++)
			{
				sumFeaVec[i] = 0.0;
			}
			
			double logPWeiSum = 1.0 * 10E-8;
			double logVWeiSum = 1.0 * 10E-8;
			double logPWei = 0.0;
			double logVWei = 0.0;
			String ince3Vec = "";
	
			while (values.hasNext()) {
				Record r = values.next();
				try{
							
					Double tmpP = r.getDouble(0);
					Double tmpV = r.getDouble(1);
					logPWei = (tmpP >= 1.0 ? Math.log10(tmpP) : (double)0.0);
					logVWei = (tmpV >= 1.0 ? Math.log10(tmpV) : (double)0.0);
					
					ince3Vec = r.getString(2);
					logPWeiList.add(logPWei);
					logPWeiSum += logPWei;
					logVWeiList.add(logVWei);
					logVWeiSum += logVWei;
					ince3VecList.add(ince3Vec);
				} catch (Exception e)
				{
					logger.info("key=" + key.getString(0) );
					continue;
				}
			}
			
			for (int i = 0; i < ince3VecList.size(); i ++)
			{
				
				double wei = alpha * logPWeiList.get(i) / logPWeiSum  + beta * logVWeiList.get(i) / logVWeiSum ;
				ince3Vec = ince3VecList.get(i);
				String [] ince3FeaStrVec = ince3Vec.split(":");
				if (ince3FeaStrVec.length != dim)
				{
					continue;
				}
				for (int j = 0; j < ince3FeaStrVec.length; j ++)
				{
					Double oriFeaWei = Double.parseDouble(ince3FeaStrVec[j]);
					Double newWei = oriFeaWei * wei;
					sumFeaVec[j] += newWei;
					
				}
			}
			String resStr = "";
			resStr = resStr + sumFeaVec[0];
			for (int i = 1; i < dim; i ++)
			{
				resStr = resStr + "," + sumFeaVec[i];
			}
			result.setString(0,  key.getString(0));
			result.setString(1, resStr);
			context.write(result);
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("p_wei :double ,v_wei:double, inc3_vec:string"));
		MrJobParamSetter.addInput(job, argContainer.getInput());
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(MyMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(MyReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		job.setFloat("alpha",  (float)argContainer.getAlpha());
		job.setFloat("beta", (float)argContainer.getBeta());
		job.setInt("dim", (int)argContainer.getDim());
		
		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}
	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-alpha", description = "factor for pubtime wei")
		private Float alpha = (float)0.5;		
		@Parameter(names="-beta", description = "factor for view time wei")
		private Float beta = (float)0.5;
		
		@Parameter(names="-dim", description = "dimenstion for tf image inception v3 feature")
		private int dim = 2048;
		
		public MrArgContainer() {
		}
		public double getAlpha() {
			return alpha;
		}
		public void setalpha(Float alpha) {
			this.alpha = alpha;
		}
		public Float getBeta()
		{
			return beta;
		}
		public void setBeta(Float beta)
		{
			this.beta = beta;
		}
		public int getDim()
		{
			return dim;
		}
		public void setDim(int dim)
		{
			this.dim = dim;
		}
	}
}
