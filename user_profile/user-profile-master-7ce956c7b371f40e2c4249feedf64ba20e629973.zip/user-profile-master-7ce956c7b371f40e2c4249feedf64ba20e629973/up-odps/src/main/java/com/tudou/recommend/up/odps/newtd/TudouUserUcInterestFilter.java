package com.tudou.recommend.up.odps.newtd;

import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.ProfileDeviceIdentity;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.UserIdInfo;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;

/**
 * 过滤出土豆用户在UC头条的图文兴趣
 * @author zengtao
 *
 */
public class TudouUserUcInterestFilter {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class TudouUserUcInterestFilterMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private String tudouUidInfoDataTable;
		private String ucInterestDataTable;
		private String tableName;

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			JobConf conf = context.getJobConf();
			tudouUidInfoDataTable = conf.get("tudouUidInfoDataTable");
			ucInterestDataTable = conf.get("ucInterestDataTable");
			tableName = context.getInputTableInfo().getTableName();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			StringBuilder sb = new StringBuilder();
			if (tableName.contains(tudouUidInfoDataTable)) {
				UserIdInfo info = UserIdInfo.parseFromRecord(record);
				if (info == null) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_uid_info_input").increment(1L);
					return;
				}
				// 仅召回浏览器信息流图文兴趣，避免多渠道数据冲突
				if (!info.appToken.equals("uc-iflow")) {
					return;
				}
				String fullUserId = DataFormatUtil.GenIflowUserId(
						info.appToken, info.userId);
				if (!fullUserId.isEmpty()) {
					k2.setString(0, fullUserId);
					v2.setString(0, "1:" + info.toString());
					context.write(k2, v2);
				}
			} else if (tableName.contains(ucInterestDataTable)) {
				String uidStr = record.getString(0);
				String[] uidFlds = uidStr.split("`", -1);
				if (uidFlds.length != 3) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_interest_input").increment(1L);
					return;
				}
				// 仅召回浏览器信息流图文兴趣，避免多渠道数据冲突
				if (!uidFlds[0].equals("uc-iflow")) {
					return;
				}
				String fullUserId = DataFormatUtil.GenIflowUserId(uidFlds[0],
						uidFlds[2]);
				if (!fullUserId.isEmpty()) {
					k2.setString(0, fullUserId);
					sb.append(record.getString(0)).append("\t");
					sb.append(record.getString(1)).append("\t");
					sb.append(record.getString(2));
					v2.setString(0, "2:" + sb.toString());
					context.write(k2, v2);
				}
			} else {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_input_source").increment(1L);
				return;
			}
		}
	}

	public static class TudouUserUcInterestFilterReducer extends ReducerBase {
		private Record result;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			HashSet<String> imeiSet = new HashSet<String>();
			HashSet<String> interestSet = new HashSet<String>();
			int indexOf;
			String value;
			String tag;
			String valueStr;
			while (values.hasNext()) {
				value = values.next().getString(0);
				tag = value.substring(0, 2);
				valueStr = value.substring(2);
				if (tag.equals("1:")) {
					UserIdInfo info = UserIdInfo.parseFromString(valueStr, 0);
					if (info == null) {
						continue;
					}
					if (!info.idfa.isEmpty()) {
						imeiSet.add(info.idfa);
					} else if (!info.imei.isEmpty()) {
						imeiSet.add(info.imei);
					}
				} else if (tag.equals("2:")) {
					interestSet.add(valueStr);
				} else {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_input_source").increment(1L);
					continue;
				}
			}

			for (String imei : imeiSet) {
				String newUid = DataFormatUtil.GenProfileKey("td",
						ProfileDeviceIdentity.IMEI_OR_IDFA, imei);
				for (String interestStr : interestSet) {
					String[] interestFlds = interestStr.split("\t", -1);
					result.setString(0, newUid);
					result.setString(1, interestFlds[1]);
					indexOf = interestStr.indexOf(interestFlds[2]);
					result.setString(2, interestStr.substring(indexOf));
					context.write(result);
				}
			}
		}

	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("v2:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput());
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(TudouUserUcInterestFilterMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(TudouUserUcInterestFilterReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		MrJobParamSetter.setSplitSize(job, 128L);

		job.set("tudouUidInfoDataTable", argContainer.getTudouUidInfoDataDir());
		job.set("ucInterestDataTable", argContainer.getUcInterestDataDir());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-tudouUidInfoDataTable", description = "")
		private String tudouUidInfoDataTable = "tudouUidInfoDataDir";

		@Parameter(names = "-ucInterestDataTable", description = "")
		private String ucInterestDataTable = "ucInterestDataDir";

		public String getTudouUidInfoDataDir() {
			return tudouUidInfoDataTable;
		}

		public void setTudouUidInfoDataDir(String tudouUidInfoDataDir) {
			this.tudouUidInfoDataTable = tudouUidInfoDataDir;
		}

		public String getUcInterestDataDir() {
			return ucInterestDataTable;
		}

		public void setUcInterestDataDir(String ucInterestDataDir) {
			this.ucInterestDataTable = ucInterestDataDir;
		}

	}
}
