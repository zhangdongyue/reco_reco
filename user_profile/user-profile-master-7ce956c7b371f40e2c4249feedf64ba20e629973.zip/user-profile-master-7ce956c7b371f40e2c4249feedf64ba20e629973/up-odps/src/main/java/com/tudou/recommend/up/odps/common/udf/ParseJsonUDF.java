package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.jayway.jsonpath.JsonPath;

/**
 * @author wangfei01
 * @date 2017/12/12
 */
public class ParseJsonUDF extends UDF {
    public String evaluate(String json,String path){
        String value = JsonPath.read(json,path);
        return value;
    }
}
