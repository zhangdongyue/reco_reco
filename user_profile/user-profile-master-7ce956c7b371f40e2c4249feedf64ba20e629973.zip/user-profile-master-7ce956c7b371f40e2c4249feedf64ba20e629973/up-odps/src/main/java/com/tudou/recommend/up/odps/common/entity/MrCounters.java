package com.tudou.recommend.up.odps.common.entity;

import java.io.IOException;
import java.util.Iterator;

import com.aliyun.odps.counter.Counter;
import com.aliyun.odps.mapred.Job;

/**
 * mr job中常用的counter常量
 * @author hezhimin
 *
 */
public class MrCounters {
  
  /**
   * 默认自定义 counter group
   */
  public static final String DEFAULT_COUNTER_GROUP = "udc";
  
  public static final String INVALID_USER_ID_COUNTER = "num_invalid_user_id";
  public static final String INVALID_ITEM_ID_COUNTER = "num_invalid_item_id";
  public static final String INVALID_APP_NAME_COUNTER = "num_invalid_app_name";
  public static final String INVALID_ACTION_TYPE_COUNTER = "num_invalid_action_type";
  public static final String INVALID_CLICK_TIME_COUNTER = "num_invalid_click_time";
  public static final String INVALID_TIME_STAMP_COUNTER = "num_invalide_time_stamp";
  
  public static final String NO_ITEM_INFO_COUNTER = "num_no_item_info";
  
  public static final String ERROR_BUCKET_NUM_COUNTER = "error_bucket_num";
  
  public static final String GLOBAL_MANUAL_NEWS_NUM_COUNTER = "num_global_manual_news";
  
  public static final String INVALID_USER_CTR_STR_COUNTER = "num_invalid_user_ctr_str";
  public static final String INVALID_DISLIKE_INTEREST_STR_COUNTER = "num_invalid_dislike_interest_str";
  public static final String INVALID_INTEREST_STR_COUNTER = "num_invalid_interest_str";
  
  /**
   * 获取所有自定义counter结果信息
   * @param job mr job
   * @return counter结果，每一行表示一个自定义counter
   * @throws IOException
   */
  public static String getAllDefaultCounters(Job job) throws IOException{
    StringBuilder builder = new StringBuilder();
    Iterator<Counter> ite = job.getCounters().getGroup(MrCounters.DEFAULT_COUNTER_GROUP).iterator();
    while (ite.hasNext()){
      Counter counter = ite.next();
      builder.append(counter.getName()).append(" = ").append(counter.getValue()).append("\n");
    }
    return builder.toString();
  }
  
  /**
   * 获取指定counter的值
   * @param job
   * @param groupName
   * @param counterName
   * @return
   * @throws IOException
   */
  public static long getCounters(Job job, String groupName, String counterName) throws IOException{
    Iterator<Counter> ite = job.getCounters().getGroup(groupName).iterator();
    while (ite.hasNext()){
      Counter counter = ite.next();
      if (counter.getName().equals(counterName)) {
        return counter.getValue();
      }
    }
    return 0L;
  }
}
