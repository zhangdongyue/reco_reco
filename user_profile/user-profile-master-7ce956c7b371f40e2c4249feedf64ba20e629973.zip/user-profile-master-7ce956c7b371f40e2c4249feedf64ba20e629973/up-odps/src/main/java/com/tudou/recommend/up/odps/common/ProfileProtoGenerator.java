package com.tudou.recommend.up.odps.common;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.google.protobuf.ByteString;
import com.google.protobuf.GeneratedMessage;
import com.tudou.recommend.proto.ProtoUserServer.UserFieldType;
import com.tudou.recommend.proto.ProtoUserServer.UserProfileKafkaMessage;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.interest.InterestElem;
import com.tudou.recommend.up.odps.common.proto.IProtoGenerate;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.iflow.util.VideoProfileGenerateUtil;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

/**
 * Generate pure video profile proto data using collected user feature.
 *
 * @author: wangfei01
 */
public class ProfileProtoGenerator {
    public static ArgumentContainer argContainer = new ArgumentContainer();

    /**
     * Read feature file and distribute with user id.
     */
    public static class DataMapper extends MapperBase {
        private Set<String> allowedAppNames = new HashSet<String>();
        private Record key;
        private Record value;

        @Override
        public void setup(TaskContext context) throws IOException {
            JobConf jobConf = context.getJobConf();
            String allowedAppNames = jobConf.get("allowedAppName", "");
            String[] apps = allowedAppNames.split(",", -1);
            for (String appName : apps) {
                if (!appName.trim().isEmpty()) {
                    this.allowedAppNames.add(appName.trim());
                }
            }
            key = context.createMapOutputKeyRecord();
            value = context.createMapOutputValueRecord();
        }

        @Override
        public void map(long recordNum, Record record, TaskContext context) throws IOException {
            String userId = record.getString("user_id");
            String featureType = record.getString("feature_type");
            String interest = record.getString("interest");
            String appName = userId.split("`", -1)[0];
            if (!allowedAppNames.isEmpty() && !allowedAppNames.contains(appName)) {
                context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
                        "filtered_by_app_name").increment(1L);
                return;
            }
            key.setString("user_id", userId);
            value.setString("feature_type", featureType);
            value.setString("interest", interest);
            context.write(key, value);
        }
    }

    public static class DataReducer extends ReducerBase {
        private Logger logger = LoggerFactory.getLogger(this.getClass());
        private String profileFieldType;
        private Boolean forceUpdate = false;
        private String abTestTableName;
        private Boolean cleanTestData = false;
        private Boolean cleanOnlineData = false;
        private Record output;
        private Base64 encoder = new Base64();
        private IProtoGenerate generator;


        @Override
        public void setup(TaskContext context) throws IOException {
            JobConf jobConfig = context.getJobConf();
            profileFieldType = jobConfig.get("profileFieldType");
            String generatorClass = jobConfig.get("generatorClass");
            forceUpdate = jobConfig.getBoolean("forceUpdate", false);
            cleanTestData = jobConfig.getBoolean("abtest.data.clean", false);
            cleanOnlineData = jobConfig.getBoolean("online.data.clean", false);
            abTestTableName = jobConfig.get("abtest.table.name");
            logger.info("ab test table name is:{}",abTestTableName);
            try {
                generator = (IProtoGenerate) Class.forName(generatorClass).newInstance();
            } catch (Exception e) {
                throw new IOException(e);
            }
            output = context.createOutputRecord();

        }

        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
            // feaType ~ feaHashCode ~ interestElem
            Map<Integer, Map<Integer, InterestElem>> interestsMap = new HashMap<>();

            while (values.hasNext()) {
                Record record = values.next();
                //value format should be: user_id \t feature_type \t feature_weight
                int featureType = Integer.parseInt(record.getString("feature_type"));
                String interest = record.getString("interest");
                if (!interestsMap.containsKey(featureType)) {
                    interestsMap.put(featureType, new HashMap<Integer, InterestElem>());
                }
                VideoProfileGenerateUtil.parseInterests(interest, interestsMap.get(featureType));
            }

            // generate user profile with all interest collected.
            GeneratedMessage profile = null;
            if ("kTdUgcVideoProfile".equals(profileFieldType)) {
            	profile = generator.generateUgc(interestsMap);
            } else {
            	profile = generator.generate(interestsMap);
            }
            
            if (profile == null) {
                context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "failed_to_gen_profile")
                        .increment(1L);
                return;
            }

            if (!profile.isInitialized()) {
                context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "profile_not_initialized")
                        .increment(1L);
                return;
            }

            String profileKey = key.getString("user_id");
            // construct kafka message proto
            UserProfileKafkaMessage.Builder msgBuilder = UserProfileKafkaMessage.newBuilder();
            switch (profileFieldType) {
                case "kVideoProfile":
                    msgBuilder.setFieldType(UserFieldType.kVideoProfile);
                    break;
                case "kYtLongVideoProfile":
                    msgBuilder.setFieldType(UserFieldType.kYtLongVideoProfile);
                    break;
                case "kYtRtLongVideoProfile":
                    msgBuilder.setFieldType(UserFieldType.kYtRtLongVideoProfile);
                    break;
                case "kTudouProfile":
                    msgBuilder.setFieldType(UserFieldType.kTudouProfile);
                    break;
                case "kYtRtShortVideoProfile":
                    msgBuilder.setFieldType(UserFieldType.kYtRtShortVideoProfile);
                    break;
                case "kYtShortVideoProfile":
                    msgBuilder.setFieldType(UserFieldType.kYtShortVideoProfile);
                    break;
                case "kTdUgcVideoProfile":
                	msgBuilder.setFieldType(UserFieldType.kTdUgcVideoProfile);
                	break;
                default:
                    msgBuilder.setFieldType(UserFieldType.kProfile);
                    break;
            }
            msgBuilder.setForceWrite(forceUpdate);
            msgBuilder.setKey(profileKey);
            msgBuilder.setValue(ByteString.copyFrom(profile.toByteArray()));
            if (abTestTableName != null && !abTestTableName.isEmpty()) {
                msgBuilder.setTableName(abTestTableName);
            }
            msgBuilder.setClearExperimentData(cleanTestData);
            msgBuilder.setClearMasterData(cleanOnlineData);
            UserProfileKafkaMessage kafkaMessage = msgBuilder.build();
            if (!kafkaMessage.isInitialized()) {
                context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "PROTO_GENERATE_ERROR").increment(1L);
                return;
            }
            byte[] msgBytes = kafkaMessage.toByteArray();
            output.setString("profile_key", profileKey);
            String byteString = encoder.encodeToString(msgBytes);
            output.setString("profile", byteString);
            context.write(output);
        }
    }

    public static void main(String[] args) throws OdpsException {
        JCommander commander = new JCommander(argContainer);
        commander.parse(args);

        Job job = new Job();
        job.set("profileFieldType", argContainer.getProfileFieldType());
        job.set("generatorClass", argContainer.getGeneratorClass());
        job.set("allowedAppName", argContainer.getAllowedAppName());
        job.set("abtest.table.name", argContainer.getAbTestTableName());
        job.setBoolean("forceUpdate", argContainer.getForceUpdate());
        job.setBoolean("abtest.data.clean", argContainer.getDeleteTestData());
        job.setBoolean("online.data.clean", argContainer.getDeleteOnlineData());

        job.setMapOutputKeySchema(SchemaUtils.fromString("user_id:string"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("feature_type:string,interest:string"));
        job.setMapperClass(DataMapper.class);
        job.setReducerClass(DataReducer.class);
        MrJobParamSetter.addInput(job,
                argContainer.getInput(),
                new String[]{"user_id", "feature_type", "interest"});
        MrJobParamSetter.addOutput(job, argContainer.getOutput());

        job.waitForCompletion();
        System.exit(job.isSuccessful() == true ? 0 : 1);
    }

    public static class ArgumentContainer {
        @Parameter(names = "-profileFieldType",
                required = true,
                description = "type of profile field: kProfile, kXssProfile")
        private String profileFieldType = "kVideoProfile";

        @Parameter(names = "-input")
        private String input;

        @Parameter(names = "-output")
        private String output;

        @Parameter(names = "-generatorClass", required = true)
        private String generatorClass;

        @Parameter(names = "-allowedAppName", description = "allowed app names")
        private String allowedAppName = "";

        @Parameter(names = "-abTestTableName")
        private String abTestTableName = "";

        @Parameter(names = "-forceUpdate")
        private Boolean forceUpdate = false;

        @Parameter(names = "-deleteTestData")
        private Boolean deleteTestData = false;

        @Parameter(names = "-deleteOnlineData")
        private Boolean deleteOnlineData = false;

        public Boolean getDeleteTestData() {
            return deleteTestData;
        }

        public void setDeleteTestData(Boolean deleteTestData) {
            this.deleteTestData = deleteTestData;
        }

        public Boolean getDeleteOnlineData() {
            return deleteOnlineData;
        }

        public void setDeleteOnlineData(Boolean deleteOnlineData) {
            this.deleteOnlineData = deleteOnlineData;
        }

        public String getAbTestTableName() {
            return abTestTableName;
        }

        public void setAbTestTableName(String abTestTableName) {
            this.abTestTableName = abTestTableName;
        }

        public Boolean getForceUpdate() {
            return forceUpdate;
        }

        public void setForceUpdate(Boolean forceUpdate) {
            this.forceUpdate = forceUpdate;
        }

        public String getAllowedAppName() {
            return allowedAppName;
        }

        public void setAllowedAppName(String allowedAppName) {
            this.allowedAppName = allowedAppName;
        }

        public String getGeneratorClass() {
            return generatorClass;
        }

        public void setGeneratorClass(String generatorClass) {
            this.generatorClass = generatorClass;
        }

        public String getInput() {
            return input;
        }

        public void setInput(String input) {
            this.input = input;
        }

        public String getOutput() {
            return output;
        }

        public void setOutput(String output) {
            this.output = output;
        }

        public String getProfileFieldType() {
            return profileFieldType;
        }

        public void setProfileFieldType(String profileFieldType) {
            this.profileFieldType = profileFieldType;
        }

    }
}
