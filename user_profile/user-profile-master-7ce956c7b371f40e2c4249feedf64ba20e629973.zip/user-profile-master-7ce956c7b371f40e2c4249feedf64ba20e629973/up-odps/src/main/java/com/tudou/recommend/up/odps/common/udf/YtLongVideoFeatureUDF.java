package com.tudou.recommend.up.odps.common.udf;

import org.apache.commons.lang3.StringUtils;

import com.aliyun.odps.udf.UDF;
import com.tudou.recommend.proto.ProtoCommon.ItemType;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;

public class YtLongVideoFeatureUDF extends UDF {
	
	public String evaluate(String seperator, String features) {
		if (features==null || features.isEmpty() || seperator==null || seperator.isEmpty()) {
			return null;
		}
		
		String[] tokens = features.split(seperator);
		if (tokens.length < 4) {
			return null;
		}
		
		String vdoId = tokens[0];
		String vdoLen = tokens[1];
		
		if ("NULL".equals(vdoId)) {
			return null;
		}
		
		StringBuilder sb = new StringBuilder();
		String sep = "::";
		
		// item type ~ isGlobalManual
		sb.append(vdoId).append("\t");
		sb.append(ItemType.kPureVideo.toString()).append("\t");
		sb.append("0");
		
		// category
		String parentCategory = "";
		String categorys = tokens[2];
		if (! "NULL".equals(categorys)) {
			for (String category : categorys.split("\t", -1)) {
				if ("未分类".equals(category)) {
					break;
				}
				
				String fullCategory;
				if (parentCategory.length() == 0) { // 一级类别
					fullCategory = category;
				} else { // 子类别
					fullCategory = parentCategory
							+ Contents.CATEGORY_SEP + category;
				}
				parentCategory = fullCategory;
				double weight = 1; // category 权重设为1
				if (sb.length() > 0) {
					sb.append("\t");
				}
				sb.append(ProfileFeatureType.VIDEO_CATEGORY.getValue())
				.append(sep).append(fullCategory).append(sep)
				.append(weight);
			}
			
		}
		String level1Category = "";
		if (StringUtils.isNotBlank(categorys)) {
			level1Category = categorys.split("\t", -1)[0];
		} else {
			level1Category = "未分类";
		}
		
		// tag
		String tags = tokens[3];
		if (! "NULL".equals(tags)) {
			for (String tag : tags.split("\t", -1)) {
				String tagStr = level1Category + Contents.CATEGORY_SEP
						+ tag;
				if (sb.length() > 0) {
					sb.append("\t");
				}
				sb.append(ProfileFeatureType.VIDEO_TAG.getValue())
				.append(sep).append(tagStr).append(sep)
				.append(1.0);
			}
		}
		
		// video length
		if (! "NULL".equals(vdoLen)) {
			if (sb.length() > 0) {
				sb.append("\t");
			}
			
			sb.append(ProfileFeatureType.VIDEO_LENGTH.getValue());
			sb.append(sep);
			sb.append(vdoLen);
			sb.append(sep);
			sb.append(1.0);
		}
		
		return sb.toString();
		
	}

}
