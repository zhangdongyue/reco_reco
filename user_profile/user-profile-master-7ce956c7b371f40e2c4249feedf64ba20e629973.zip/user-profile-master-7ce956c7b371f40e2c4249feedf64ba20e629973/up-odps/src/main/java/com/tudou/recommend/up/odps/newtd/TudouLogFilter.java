package com.tudou.recommend.up.odps.newtd;

import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.newtd.entity.TudouItemInfo;
import com.tudou.recommend.up.odps.newtd.entity.TudouLog;

/**
 * 过滤优酷土豆log
 * 
 * @author zengtao
 *
 */
public class TudouLogFilter {
	public static MrArgContainer argContainer = new MrArgContainer();

	public static class TuDouLogFilterMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private HashSet<String> appNameSet = new HashSet<String>();
		private TodouLogOdpsRecordConvertor todouLogOdpsRecordConvertor;

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			String[] appNames = context.getJobConf().get("appNameList", "")
					.split(",", -1);
			for (String appName : appNames) {
				if (!appName.isEmpty()) {
					appNameSet.add(appName);
				}
			}
			todouLogOdpsRecordConvertor = new TodouLogOdpsRecordConvertor();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			TudouLog log = new TudouLog();
			String value = todouLogOdpsRecordConvertor
					.convertRecordToStr(record);
			if (!log.parseFromStr(value)) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_map_input").increment(1L);
				return;
			}
			TudouItemInfo itemInfo = log.getItemInfo();
			if (itemInfo.vdoId.isEmpty() || itemInfo.vdoTitle.isEmpty()) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"empty_item_id_or_title").increment(1L);
				return;
			}
			if (!appNameSet.isEmpty() && !appNameSet.contains(log.appName)) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"filtered_by_app_name").increment(1L);
				return;
			}
			k2.setString(0, log.utdid);
			v2.setString(0, value);
			context.write(k2, v2);
		}
	}

	public static class TuDouLogFilterReducer extends ReducerBase {
		private Record result;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {

			while (values.hasNext()) {
				result.setString(0, values.next().getString(0));
				context.write(result);
			}
		}

	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("v2:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {
				"utdid", "se_id", "server_time", "vdo_id", "vdo_len",
				"vdo_title", "vdo_type", "vdo_desc", "editor_title", "tags",
				"ip", "mac", "imei", "idfa", "net_status", "network", "ts",
				"app_name" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(TuDouLogFilterMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(TuDouLogFilterReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		//MrJobParamSetter.setSplitSize(job, 128L);

		job.set("appNameList", argContainer.getAppNameList());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-appNameList", description = "")
		private String appNameList = "";

		public String getAppNameList() {
			return appNameList;
		}

		public void setAppNameList(String appNameList) {
			this.appNameList = appNameList;
		}

	}
}
