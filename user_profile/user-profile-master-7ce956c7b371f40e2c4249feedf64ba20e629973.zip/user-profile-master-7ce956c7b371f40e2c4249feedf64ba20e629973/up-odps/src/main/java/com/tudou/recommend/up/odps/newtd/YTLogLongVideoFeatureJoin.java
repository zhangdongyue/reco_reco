package com.tudou.recommend.up.odps.newtd;

import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

import org.apache.commons.lang3.StringUtils;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.data.TableInfo;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.proto.ProtoCommon.ItemType;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;
import com.tudou.recommend.up.odps.common.entity.log.MergeLog;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;

public class YTLogLongVideoFeatureJoin {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class YTLogLongVideoFeatureJoinMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private String logDataTableName;
		private String itemInfoDataTableName;
		private int joinShuffleFactor;
		private HashSet<String> appNameSet = new HashSet<String>();
		private int count = 0;
		private String tableName;

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			JobConf jobConf = context.getJobConf();

			logDataTableName = jobConf.get("logDataTableName");
			itemInfoDataTableName = jobConf.get("itemInfoDataTableName");
			joinShuffleFactor = jobConf.getInt("joinShuffleFactor", 0);
			String[] appNames = jobConf.get("appNameList", "").split(",", -1);
			for (String appName : appNames) {
				if (!appName.isEmpty()) {
					appNameSet.add(appName);
				}
			}
			tableName = context.getInputTableInfo().getTableName();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			if (tableName.equalsIgnoreCase(logDataTableName)) {
				MergeLog log = convertToMergeLog(record);
				if (StringUtils.isBlank(String.valueOf(getLong(record,
						"show_id"))) || getLong(record, "show_id") == 0) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"empty_show_id").increment(1L);
					return;
				}
				if (log.itemId.isEmpty() || log.title.isEmpty()) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"empty_video_id_or_title").increment(1L);
					return;
				}
				// merge log 打散后分发，避免把reduce内存打爆
				v2.setString(0, "2:" + log.toString());
				if (joinShuffleFactor <= 1) {
					k2.setString(0, log.itemId);
					context.write(k2, v2);
				} else {
					k2.setString(0, log.itemId + "_" + count);
					context.write(k2, v2);
					count = (count + 1) % joinShuffleFactor;
				}
			} else if (tableName.equalsIgnoreCase(itemInfoDataTableName)) {
				String vdoId = record.getString(0);
//				double vdoLen = getDouble(record, "vdo_len");
				double vdoLen = 1000;	//set default value for long video. add by jch.  

				StringBuilder sb = new StringBuilder();
				String sep = "::";

				// item type ~ isGlobalManual
				sb.append(vdoId).append("\t");
				sb.append(ItemType.kPureVideo.toString()).append("\t");
				sb.append("0");

				String parentCategory = "";
				String categorys = record.getString(2);
				if (categorys != null) {
					for (String category : categorys.split("\t", -1)) {
						if ("未分类".equals(category)) {
							break;
						}

						String fullCategory;
						if (parentCategory.length() == 0) { // 一级类别
							fullCategory = category;
						} else { // 子类别
							fullCategory = parentCategory
									+ Contents.CATEGORY_SEP + category;
						}
						parentCategory = fullCategory;
						double weight = 1; // category 权重设为1
						if (sb.length() > 0) {
							sb.append("\t");
						}
						sb.append(ProfileFeatureType.VIDEO_CATEGORY.getValue())
								.append(sep).append(fullCategory).append(sep)
								.append(weight);
					}

				}
				String level1Category = "";
				if (StringUtils.isNotBlank(categorys)) {
					level1Category = categorys.split("\t", -1)[0];
				} else {
					level1Category = "未分类";
				}

				// tag
				String tags = record.getString(1);
				if (tags != null) {
					for (String tag : tags.split("\t", -1)) {
						String tagStr = level1Category + Contents.CATEGORY_SEP
								+ tag;
						if (sb.length() > 0) {
							sb.append("\t");
						}
						sb.append(ProfileFeatureType.VIDEO_TAG.getValue())
								.append(sep).append(tagStr).append(sep)
								.append(1.0);
					}
				}
				// video length
				if (sb.length() > 0) {
					sb.append("\t");
				}
				sb.append(ProfileFeatureType.VIDEO_LENGTH.getValue())
						.append(sep).append(vdoLen).append(sep).append(1);

				// item info 重复分发，避免把reduce内存打爆
				v2.setString(0, "1:" + sb.toString());
				if (joinShuffleFactor <= 1) {
					k2.setString(0, vdoId);
					context.write(k2, v2);
				} else {
					for (int prefix = 0; prefix < joinShuffleFactor; ++prefix) {
						k2.setString(0, vdoId + "_" + prefix);
						context.write(k2, v2);
					}
				}
			} else {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_input_source").increment(1L);
				return;
			}
		}

		public MergeLog convertToMergeLog(Record record) {
			MergeLog log = new MergeLog();

			log.utdid = getString(record, "utdid").replaceAll("\t|\n|\r", " ");
			// 新土豆专用appToken
			log.appName = appNameMapping(getString(record, "app_name"));
			// 生成 iflow user id
			log.userId = DataFormatUtil.GenUserKey(log.appName, log.utdid);
			log.time = getString(record, "server_time").replaceAll("\t|\n|\r",
					" ");
			log.recoId = getString(record, "se_id").replaceAll("\t|\n|\r", " ");

			log.itemId = getString(record, "vdo_id")
					.replaceAll("\t|\n|\r", " ");

			log.title = getString(record, "vdo_title").replaceAll("\t|\n|\r",
					" ");
			log.clickSeconds = (int) getDouble(record, "ts");

			log.network = netWorkTypeMapping(record.getString("network"));

			// andriod 的 imei 和 ios的idfa都存放在 merge log的imei字段里，后续使用需要注意
			String imei = getString(record, "imei").replaceAll("\t|\n|\r", " ");
			String idfa = getString(record, "idfa").replaceAll("\t|\n|\r", " ");
			if (DataFormatUtil.isValidIdfa(idfa)) {
				log.imei = idfa;
			} else if (DataFormatUtil.isValidImei(imei)) {
				log.imei = imei;
			}
			double vdoLen = getDouble(record, "vdo_len");
			if (log.clickSeconds <= 0) {
				log.readProgress = 0;
			} else {
				if (vdoLen > 0) {
					log.readProgress = Math.min(
							(float) (log.clickSeconds / vdoLen), 1);
				}
			}

			return log;
		}

		private long getLong(Record record, String colName, long defaultValue) {
			Long ln = record.getBigint(colName);
			return ln == null ? defaultValue : ln.longValue();
		}

		private long getLong(Record record, String colName) {
			return getLong(record, colName, 0L);
		}

		private double getDouble(Record record, String colName,
				double defaultValue) {
			Double d = record.getDouble(colName);
			return d == null ? defaultValue : d.doubleValue();
		}

		private double getDouble(Record record, String colName) {
			return getDouble(record, colName, 0);
		}

		private String getString(Record record, String colName,
				String defaultValue) {
			String str = record.getString(colName);
			return str == null ? defaultValue : str;
		}

		private String getString(Record record, String colName) {
			return getString(record, colName, "");
		}

		private String netWorkTypeMapping(String network) {
			if (network == null || network.isEmpty()) {
				return "99";
			} else if ("2G".equals(network) || "2G/3G".equals(network)) {
				return "0";
			} else if ("3G".equals(network) || "4G".equals(network)) {
				return "1";
			} else if (network.equalsIgnoreCase("wifi")
					|| network.equalsIgnoreCase("wi-fi")) {
				return "2";
			} else {
				return "99";
			}
		}

		// 设置app token
		private String appNameMapping(String appName) {
			if (appName == null || appName.isEmpty()) {
				return "";
			} else if (appName.equalsIgnoreCase("tudou_client")) {
				return "td";
			} else {
				return "yk";
			}
		}
	}

	public static class YTLogLongVideoFeatureJoinReducer extends ReducerBase {
		private Record result;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			String itemInfoStr = "";
			LinkedList<String> logs = new LinkedList<String>();
			String itemStr;
			String valueStr;
			String tag;
			while (values.hasNext()) {
				itemStr = values.next().getString(0);
				tag = itemStr.substring(0, 2);
				valueStr = itemStr.substring(2);
				if ("1:".equals(tag)) {
					if (valueStr.length() > itemInfoStr.length()) {
						itemInfoStr = valueStr;
					}
				} else if ("2:".equals(tag)) {
					logs.add(valueStr);
				} else {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_input_source").increment(1L);
					continue;
				}
			}
			for (String log : logs) {
				result.setString(0, log);
				result.setString(1, itemInfoStr);
				context.write(result);
				if (itemInfoStr.isEmpty()) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"merge_log_without_item_info").increment(1L);
				} else {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"merge_log_with_item_info").increment(1L);
				}
			}
		}

	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("v2:string"));

		String[] inputPaths = argContainer.getInput().split(",", -1);
		for (String in : inputPaths) {
			String[] ss = in.split("\\|", -1);
			if (argContainer.getItemInfoDataDir().equals(ss[0])) {
				if (ss.length == 1) {
					job.addInput(TableInfo
							.builder()
							.tableName(ss[0])
							.cols(new String[] { "vdo_id", "tags", "category" })
							.build());
				} else if (ss.length == 2) {
					job.addInput(TableInfo
							.builder()
							.tableName(ss[0])
							.partSpec(ss[1])
							.cols(new String[] { "vdo_id", "tags", "category" })
							.build());
				} else {
					System.exit(1);
				}
			} else {
				if (ss.length == 1) {
					job.addInput(TableInfo
							.builder()
							.tableName(ss[0])
							.cols(new String[] { "utdid", "app_name",
									"server_time", "se_id", "vdo_id",
									"vdo_title", "ts", "network", "imei",
									"idfa", "vdo_len", "show_id" }).build());
				} else if (ss.length == 2) {
					job.addInput(TableInfo
							.builder()
							.tableName(ss[0])
							.partSpec(ss[1])
							.cols(new String[] { "utdid", "app_name",
									"server_time", "se_id", "vdo_id",
									"vdo_title", "ts", "network", "imei",
									"idfa", "vdo_len", "show_id" }).build());
				} else {
					System.exit(1);
				}
			}
		}
		// MrJobParamSetter.addInput(job, argContainer.getInput());
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(YTLogLongVideoFeatureJoinMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(YTLogLongVideoFeatureJoinReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		MrJobParamSetter.setSplitSize(job, 128L);

		job.set("logDataTableName", argContainer.getLogDataDir());
		job.set("itemInfoDataTableName", argContainer.getItemInfoDataDir());
		job.setInt("joinShuffleFactor", argContainer.getJoinShuffleFactor());
		job.set("appNameList", argContainer.getAppNameList());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-logDataTableName", description = "")
		private String logDataTableName = "logDataTableName";

		@Parameter(names = "-itemInfoDataTableName", description = "")
		private String itemInfoDataTableName = "itemInfoDataTableName";

		@Parameter(names = "-joinShuffleFactor", description = "")
		private int joinShuffleFactor = 0;

		@Parameter(names = "-appNameList", description = "")
		private String appNameList = "";

		@Parameter(names = "-userIdType", description = "")
		private String userIdType = "";

		public String getLogDataDir() {
			return logDataTableName;
		}

		public void setLogDataDir(String logDataDir) {
			this.logDataTableName = logDataDir;
		}

		public String getItemInfoDataDir() {
			return itemInfoDataTableName;
		}

		public void setItemInfoDataDir(String itemInfoDataDir) {
			this.itemInfoDataTableName = itemInfoDataDir;
		}

		public String getAppNameList() {
			return appNameList;
		}

		public void setAppNameList(String appNameList) {
			this.appNameList = appNameList;
		}

		public int getJoinShuffleFactor() {
			return joinShuffleFactor;
		}

		public void setJoinShuffleFactor(int joinShuffleFactor) {
			this.joinShuffleFactor = joinShuffleFactor;
		}

		public String getUserIdType() {
			return userIdType;
		}

		public void setUserIdType(String userIdType) {
			this.userIdType = userIdType;
		}
	}
}
