package com.tudou.recommend.up.odps.iflow.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;
import com.tudou.recommend.up.odps.common.entity.ProfileHotFactorOrderType;

import org.apache.log4j.Logger;

/**
 * 计算feature的权重，用作interest平滑
 * 
 * @author hezhimin
 *
 */
public class FeatureWeightCalculator {
  private static final Logger logger = Logger.getLogger(FeatureWeightCalculator.class);
  
  // 需要进行平滑的feature type
  private HashSet<Integer> allowedFeaTypes;
  
  private boolean useCtrSmooth; // 是否使用类目ctr进行平滑
  private String orderType; 		// hot factor order .
  private HashMap<String, double[]> ctrMap = new HashMap<String, double[]>();

  // 归一化参数
  private double minWeight = 0.05;		// input value is 0.5
  private double maxWeight = 1.0;		// input value is 1.0

  // 统计匹配失败率
  private long totalFeaNum = 0;
  private long noMatchNum = 0;
  
  public FeatureWeightCalculator(){
    allowedFeaTypes = new HashSet<Integer>();
    setupAllowedFeatureTypes();
  }

  // 设置需要进行平滑的feature type
  private void setupAllowedFeatureTypes() {
    if (allowedFeaTypes == null)
    {return;}
    allowedFeaTypes.clear();
    
    allowedFeaTypes.add(ProfileFeatureType.CATEGORY.getValue());
    allowedFeaTypes.add(ProfileFeatureType.CHANNEL.getValue());
    allowedFeaTypes.add(ProfileFeatureType.KEYWORD.getValue());
    allowedFeaTypes.add(ProfileFeatureType.TAG.getValue());
    allowedFeaTypes.add(ProfileFeatureType.TOPIC.getValue());
    allowedFeaTypes.add(ProfileFeatureType.PLSA_TOPIC.getValue());
    allowedFeaTypes.add(ProfileFeatureType.TITLE_LDA_TOPIC.getValue());
    allowedFeaTypes.add(ProfileFeatureType.VIDEO_CATEGORY.getValue());
    allowedFeaTypes.add(ProfileFeatureType.VIDEO_TAG.getValue());
    allowedFeaTypes.add(ProfileFeatureType.VIDEO_TAG_WITHOUT_CATEGORY.getValue());
    allowedFeaTypes.add(ProfileFeatureType.REGION.getValue());
    allowedFeaTypes.add(ProfileFeatureType.ITEM_SOURCE.getValue());
    allowedFeaTypes.add(ProfileFeatureType.SEARCH_CATEGORY.getValue());
    allowedFeaTypes.add(ProfileFeatureType.SEARCH_TAG.getValue());
    allowedFeaTypes.add(ProfileFeatureType.SEARCH_KEYWORD.getValue());
    allowedFeaTypes.add(ProfileFeatureType.VIDEO_SOURCE.getValue());
  }
  
  public boolean isFeatureAllowed(int feaType) {
    return allowedFeaTypes.contains(feaType);
  }
  
  public static void readCtrReaourceFile(String filePath, HashMap<String, double[]> ctrMap) throws NumberFormatException, IOException {
    if (filePath == null || filePath.isEmpty()) {
      return;
    }
    if (ctrMap == null) {
      return;
    } else {
      ctrMap.clear();
    }
    
    int bucketNum = -1;
    File termCtrtFile = new File(filePath);
    BufferedReader reader = new BufferedReader(new FileReader(termCtrtFile));
    String line;
    while ((line = reader.readLine()) != null) {
    	if (line.length() == 0) { 
    		continue;
    	}
    	String[] fields = line.split("\t");
    	if (fields.length != 3) {
    		logger.error("invalide input: " + line);
    		return;
    	}
    	int feaType = Integer.parseInt(fields[1]);
    	String fea = fields[0];
    	String[] feaCtrStrs = fields[2].split(" ", -1);
    	
    	if (bucketNum == -1) {
    		bucketNum = feaCtrStrs.length;
    	} else {
    		if (bucketNum != feaCtrStrs.length) {
    			logger.error("invalide input, wrong bucket number: " + line);
    			break;
    		}
    	}
    	long[] pvs = new long[bucketNum];
    	long[] clicks = new long[bucketNum];
    	double[] ctrs = new double[bucketNum];
    	for (int i = 0; i < bucketNum; ++i) {
    		String[] pvClickCtrStr = feaCtrStrs[i].split(":");
    		ctrs[i] = Double.parseDouble(pvClickCtrStr[0]);
    		pvs[i] = Long.parseLong(pvClickCtrStr[1]);
    		clicks[i] = Long.parseLong(pvClickCtrStr[2]);
    	}
    	
    	String feaWithType = feaType + "\t" + fea;
    	ctrMap.put(feaWithType, ctrs);
    }
    if (reader != null) {
      reader.close();
    }
  }

  /**
   * 计算各feature的权重
   * @param feaInfos 输入为属于同一feaType的所有fea的weight和click sum
   * @return
   */
  public HashMap<String, HashMap<Integer, Double>> calculateFeaWeight(List<String> feaInfos) {
    HashMap<String, HashMap<Integer, Double>> finalTermWeightMap = new HashMap<String, HashMap<Integer, Double>>();
    if (feaInfos == null) {
      return finalTermWeightMap;
    }
    
    // 不同时间桶内的click总数
    HashMap<Integer, Double> allClickSum = new HashMap<Integer, Double>();
    // 各term在不同时间桶内的weight和
    HashMap<String, HashMap<Integer, Double>> weightSumMap = new HashMap<String, HashMap<Integer, Double>>();

    for (String valueStr : feaInfos) {
      String[] fields = valueStr.split("\t", -1);
      if (fields.length != 3) {
        continue;
      }

      int termType = Integer.parseInt(fields[0]);
      String term = fields[1];
      String termWithType = termType + "\t" + term;
      String[] buckets = fields[2].split(" ", -1);

      if (!weightSumMap.containsKey(termWithType)) {
        weightSumMap.put(termWithType, new HashMap<Integer, Double>());
      }

      for (String str : buckets) {
        String[] numbers = str.split(":", -1);
        int bucket = Integer.parseInt(numbers[0]);
        double weight = Double.parseDouble(numbers[1]);
        double click = Double.parseDouble(numbers[2]);

        // 累加weight
        if (!weightSumMap.get(termWithType).containsKey(bucket)) {
          weightSumMap.get(termWithType).put(bucket, 0.0);
        }
        weightSumMap.get(termWithType).put(bucket, weightSumMap.get(termWithType).get(bucket) + weight);

        // 统计总click
        if (!allClickSum.containsKey(bucket)) {
          allClickSum.put(bucket, 0.0);
        }
        if ((termType == ProfileFeatureType.CATEGORY.getValue() || termType == ProfileFeatureType.VIDEO_CATEGORY
            .getValue()) && term.indexOf(Contents.CATEGORY_SEP) > 0) {
          // 跳过二级类目
        } else {
          allClickSum.put(bucket, allClickSum.get(bucket) + click);
        }
      }
    }

    // 规范化ctr
    if (useCtrSmooth) {
      ctrMap = normalizeCtrs(ctrMap);
    }

    // 计算权重
    finalTermWeightMap = calculateFeaWeight(weightSumMap, ctrMap, allClickSum);

    return finalTermWeightMap;
  }

  /**
   * 规范化ctr到[0,1]区间
   * 
   * @param ctrMap
   * @return
   */
  private HashMap<String, double[]> normalizeCtrs(HashMap<String, double[]> ctrMap) {

    HashMap<String, double[]> normalizedCtrMap = new HashMap<String, double[]>();
    HashMap<Integer, double[]> minCtrMap = new HashMap<Integer, double[]>();
    HashMap<Integer, double[]> maxCtrMap = new HashMap<Integer, double[]>();
    for (String termWithType : ctrMap.keySet()) {
      int sepIndex = termWithType.indexOf("_");
      int termType = Integer.parseInt(termWithType.substring(0, sepIndex));
      double[] ctrArr = ctrMap.get(termWithType);
      if (!minCtrMap.containsKey(termType)) {
        double[] arr = new double[ctrArr.length];
        for (int i = 0; i < arr.length; ++i) {
          arr[i] = Double.MAX_VALUE;
        }
        minCtrMap.put(termType, arr);
      }
      if (!maxCtrMap.containsKey(termType)) {
        double[] arr = new double[ctrArr.length];
        for (int i = 0; i < arr.length; ++i) {
          arr[i] = Double.MIN_VALUE;
        }
        maxCtrMap.put(termType, arr);
      }

      for (int i = 0; i < ctrArr.length; ++i) {
        if (minCtrMap.get(termType)[i] > ctrArr[i]) {
          minCtrMap.get(termType)[i] = ctrArr[i];
        }
        if (maxCtrMap.get(termType)[i] < ctrArr[i]) {
          maxCtrMap.get(termType)[i] = ctrArr[i];
        }
      }
    }

    for (String termWithType : ctrMap.keySet()) {
      int sepIndex = termWithType.indexOf("_");
      int termType = Integer.parseInt(termWithType.substring(0, sepIndex));
      double[] ctrArr = ctrMap.get(termWithType);
      double[] minCtrs = minCtrMap.get(termType);
      double[] maxCtrs = maxCtrMap.get(termType);
      double[] normalizedCtrs = new double[ctrArr.length];
      for (int i = 0; i < ctrArr.length; ++i) {
        if (maxCtrs[i] - minCtrs[i] > 10e-6) {
          normalizedCtrs[i] = 0.0001 + (1 - 0.0001) * (ctrArr[i] - minCtrs[i]) / (maxCtrs[i] - minCtrs[i]);
        } else {
          normalizedCtrs[i] = 1.0;
        }
      }
      normalizedCtrMap.put(termWithType, normalizedCtrs);
    }
    return normalizedCtrMap;
  }

  /**
   * 计算feature的权重考虑ctr，点击总数等因素,并规范化到[0.5, 1.0]区间
   * 
   * @return
   */
  private HashMap<String, HashMap<Integer, Double>> calculateFeaWeight(
      HashMap<String, HashMap<Integer, Double>> weightSumMap, HashMap<String, double[]> ctrMap,
      HashMap<Integer, Double> allClickSum) {

    HashMap<String, HashMap<Integer, Double>> termWeightMap = new HashMap<String, HashMap<Integer, Double>>();

    // final_term_weight = ctr * weightSum/all_click_sum
    for (String termWithType : weightSumMap.keySet()) {
      totalFeaNum++;

      int sepIndex = termWithType.indexOf("\t");
      int termType = Integer.parseInt(termWithType.substring(0, sepIndex));
      boolean isCategory = (termType == ProfileFeatureType.CATEGORY.getValue());

      if (!termWeightMap.containsKey(termWithType)) {
        termWeightMap.put(termWithType, new HashMap<Integer, Double>());
      }
      if (!ctrMap.containsKey(termWithType)) {
        noMatchNum++;
      }
      for (int bucket : weightSumMap.get(termWithType).keySet()) {
        double termWeightSum = weightSumMap.get(termWithType).get(bucket);
        double termCtr; // term的整体CTR

        // note: 仅category使用ctr进行平滑
        if (isCategory && useCtrSmooth && ctrMap.containsKey(termWithType)) {
          termCtr = ctrMap.get(termWithType)[bucket];
        } else {
          termCtr = 1.0;
        }
        termWeightMap.get(termWithType).put(bucket, (termWeightSum * termCtr) / allClickSum.get(bucket));
      }
    }

    // 对final_term_weight进行归一化
    // termType ~ bucket ~ min/max
    HashMap<Integer, HashMap<Integer, Double>> minTermWeights = new HashMap<Integer, HashMap<Integer, Double>>(); // 每个桶权重的最小值
    HashMap<Integer, HashMap<Integer, Double>> maxTermWeights = new HashMap<Integer, HashMap<Integer, Double>>(); // 每个桶权重的最大值
    for (String termWithType : termWeightMap.keySet()) {
      int sepIndex = termWithType.indexOf("\t");
      int termType = Integer.parseInt(termWithType.substring(0, sepIndex));
      if (!minTermWeights.containsKey(termType)) {
        minTermWeights.put(termType, new HashMap<Integer, Double>());
      }
      if (!maxTermWeights.containsKey(termType)) {
        maxTermWeights.put(termType, new HashMap<Integer, Double>());
      }
      for (int bucket : termWeightMap.get(termWithType).keySet()) {
        double weight = termWeightMap.get(termWithType).get(bucket);
        if (!minTermWeights.get(termType).containsKey(bucket)
            || minTermWeights.get(termType).get(bucket) > weight) {
          minTermWeights.get(termType).put(bucket, weight);
        }
        if (!maxTermWeights.get(termType).containsKey(bucket)
            || maxTermWeights.get(termType).get(bucket) < weight) {
          maxTermWeights.get(termType).put(bucket, weight);
        }
      }
    }

    HashMap<String, HashMap<Integer, Double>> finalTermWeightMap = new HashMap<String, HashMap<Integer, Double>>();
    for (String termWithType : termWeightMap.keySet()) {
      int sepIndex = termWithType.indexOf("\t");
      int termType = Integer.parseInt(termWithType.substring(0, sepIndex));
      if (!finalTermWeightMap.containsKey(termWithType)) {
        finalTermWeightMap.put(termWithType, new HashMap<Integer, Double>());
      }

      for (int bucket : termWeightMap.get(termWithType).keySet()) {
        double min = minTermWeights.get(termType).get(bucket);
        double max = maxTermWeights.get(termType).get(bucket);
        double finalWeight;
        if (max - min < 1e-9) {
          finalWeight = 1.0;
        } else {
          finalWeight = (termWeightMap.get(termWithType).get(bucket) - min) / (max - min);
        }
        finalWeight = minWeight + (maxWeight - minWeight) * finalWeight; // 值域映射到[0.5, 1.0]
        finalTermWeightMap.get(termWithType).put(bucket, finalWeight);
      }
    }

    return finalTermWeightMap;
  }
  
  /**
   * initialize max weight map
   * @return
   */
  public HashMap<Integer, HashMap<Integer, Double>> initTermWeightMap() {
	  HashMap<Integer, HashMap<Integer, Double>> termWeights = new HashMap<Integer, HashMap<Integer, Double>>(); 
	  Iterator<Integer> iter = allowedFeaTypes.iterator();
	  while(iter.hasNext()) {
		  int termType = iter.next();
		  termWeights.put(termType, new HashMap<Integer, Double>());
	  }
	  return termWeights;
  }
  
  /**
   * get max weight from each bucket.
   * @param termWeightMap
   * @return
   */
  private HashMap<Integer, HashMap<Integer, Double>> getMaxWeightFromEachBucket(HashMap<String, HashMap<Integer, Double>> termWeightMap) {
	  HashMap<Integer, HashMap<Integer, Double>> maxTermWeights = new HashMap<Integer, HashMap<Integer, Double>>(); // 每个桶权重的最大值
	  Iterator<Integer> iter = allowedFeaTypes.iterator();
	  while(iter.hasNext()) {
		  int termType = iter.next();
		  maxTermWeights.put(termType, new HashMap<Integer, Double>());
	  }
	  
	  for (String termWithType : termWeightMap.keySet()) {
		  int sepIndex = termWithType.indexOf("\t");
		  int termType = Integer.parseInt(termWithType.substring(0, sepIndex));
		  for (int bucket : termWeightMap.get(termWithType).keySet()) {
			  double weight = termWeightMap.get(termWithType).get(bucket);
			  if (!maxTermWeights.get(termType).containsKey(bucket)) {
				  maxTermWeights.get(termType).put(bucket, weight);
			  } else if(maxTermWeights.get(termType).get(bucket) < weight) {
				  maxTermWeights.get(termType).put(bucket, weight);
			  }
		  }
	  }
	  return maxTermWeights;
  }
  
  /**
   * get min weight from each bucket.
   * @param termWeightMap
   * @return
   */
  private HashMap<Integer, HashMap<Integer, Double>> getMinWeightFromEachBucket(HashMap<String, HashMap<Integer, Double>> termWeightMap) {
	  HashMap<Integer, HashMap<Integer, Double>> minTermWeights = new HashMap<Integer, HashMap<Integer, Double>>(); // 每个桶权重的最小值
	  Iterator<Integer> iter = allowedFeaTypes.iterator();
	  while(iter.hasNext()) {
		  int termType = iter.next();
		  minTermWeights.put(termType, new HashMap<Integer, Double>());
	  }
	  
	  for (String termWithType : termWeightMap.keySet()) {
		  int sepIndex = termWithType.indexOf("\t");
		  int termType = Integer.parseInt(termWithType.substring(0, sepIndex));
		  for (int bucket : termWeightMap.get(termWithType).keySet()) {
			  double weight = termWeightMap.get(termWithType).get(bucket);
			  if (!minTermWeights.get(termType).containsKey(bucket)) {
				  minTermWeights.get(termType).put(bucket, weight);
			  } else if(minTermWeights.get(termType).get(bucket) > weight) {
				  minTermWeights.get(termType).put(bucket, weight);
			  }
		  }
	  }
	  return minTermWeights;
  }
  
  /**
   * calculate feature weight by order type
   * @param weightSumMap
   * @param ctrMap
   * @param allClickSum
   * @return
   */
  public HashMap<String, HashMap<Integer, Double>> calculateFeatureWeight (HashMap<Integer, HashMap<Integer, Double>> originalMaxTermWeights, HashMap<String, HashMap<Integer, Double>> weightSumMap) {
	  // TF*IDF思想，计算IDF的方式来计算termWeight
	  HashMap<String, HashMap<Integer, Double>> termWeightMap = new HashMap<String, HashMap<Integer, Double>>();
	  for (String termWithType : weightSumMap.keySet()) {
		  int sepIndex = termWithType.indexOf("\t");
		  int termType = Integer.parseInt(termWithType.substring(0, sepIndex));
		  if (!termWeightMap.containsKey(termWithType)) {
			  termWeightMap.put(termWithType, new HashMap<Integer, Double>());
		  }
		  
		  for (int bucket : weightSumMap.get(termWithType).keySet()) {
			  double max = originalMaxTermWeights.get(termType).get(bucket);
			  double termWeight = weightSumMap.get(termWithType).get(bucket);
			  double finalWeight = 1.0;
			  if (max <= 0 || termWeight <= 0) {
				  finalWeight = 1.0;
				  System.out.println("error: " + max + "," + termWeight);
			  } else {
				  finalWeight = Math.log10((max * 10)/termWeight);
				  if (finalWeight==1.0) {
					  System.out.println("max,termWeight,termWithType: " + max + "," + termWeight + "," + termWithType);
				  }
			  }
			  
			  if (finalWeight < 0) {
				  finalWeight = 1.0;
				  System.out.println("finalWeight: " + finalWeight + "," + max + "," + termWeight);
			  }
			  
			  if (finalWeight==1.0) {
				  System.out.println("Max,termWeight,bucket: " + max + "," + termWeight + "," + bucket);
			  }
			  termWeightMap.get(termWithType).put(bucket, finalWeight);
		  }
	  }
	  
	  // 对final_term_weight进行归一化
	  // termType ~ bucket ~ min/max
	  HashMap<Integer, HashMap<Integer, Double>> maxTermWeights = getMaxWeightFromEachBucket(termWeightMap); // 每个桶权重的最大值
	  HashMap<Integer, HashMap<Integer, Double>> minTermWeights = getMinWeightFromEachBucket(termWeightMap); // 每个桶权重的最小值
	  
	  
	  HashMap<String, HashMap<Integer, Double>> finalTermWeightMap = new HashMap<String, HashMap<Integer, Double>>();
	  for (String termWithType : termWeightMap.keySet()) {
		  int sepIndex = termWithType.indexOf("\t");
		  int termType = Integer.parseInt(termWithType.substring(0, sepIndex));
		  if (!finalTermWeightMap.containsKey(termWithType)) {
			  finalTermWeightMap.put(termWithType, new HashMap<Integer, Double>());
		  }
		  
		  for (int bucket : termWeightMap.get(termWithType).keySet()) {
			  double min = minTermWeights.get(termType).get(bucket);
			  double max = maxTermWeights.get(termType).get(bucket);
			  double finalWeight;
			  if (max - min < 1e-9) {
				  finalWeight = 1.0;
			  } else {
				  finalWeight = (termWeightMap.get(termWithType).get(bucket) - min) / (max - min);
			  }
			  
			  finalWeight = minWeight + (maxWeight - minWeight) * finalWeight;	// 值域映射到[1.0, 2.0]
			  
			  if (ProfileHotFactorOrderType.LONG.equals(orderType)) {
				finalWeight = minWeight + (maxWeight - finalWeight);			// 对长视频，反转分布  
			  } else if (ProfileHotFactorOrderType.DEFAULT.equals(orderType)) {
				  finalWeight = termWeightMap.get(termWithType).get(bucket);
			  }
			  
			  finalTermWeightMap.get(termWithType).put(bucket, finalWeight);
		  }
	  }
	  
	  return finalTermWeightMap;
  }
  
  public boolean getUseCtrSmooth() {
    return useCtrSmooth;
  }

  public void setUseCtrSmooth(boolean useCtrSmooth) {
    this.useCtrSmooth = useCtrSmooth;
  }
  
  public String getOrderType() {
	  return this.orderType;
  }
  
  public void setOrderType(String orderType) {
	  this.orderType = orderType;
  }

  public HashMap<String, double[]> getCtrMap() {
    return ctrMap;
  }

  public void setCtrMap(HashMap<String, double[]> ctrMap) {
    this.ctrMap = ctrMap;
  }

  public long getTotalFeaNum() {
    return totalFeaNum;
  }

  public void setTotalFeaNum(long totalFeaNum) {
    this.totalFeaNum = totalFeaNum;
  }

  public long getNoMatchNum() {
    return noMatchNum;
  }

  public void setNoMatchNum(long noMatchNum) {
    this.noMatchNum = noMatchNum;
  }

  public double getMinWeight() {
    return minWeight;
  }

  public void setMinWeight(double minWeight) {
    this.minWeight = minWeight;
  }

  public double getMaxWeight() {
    return maxWeight;
  }

  public void setMaxWeight(double maxWeight) {
    this.maxWeight = maxWeight;
  }

  public HashSet<Integer> getAllowedFeaTypes() {
    return allowedFeaTypes;
  }

  public void setAllowedFeaTypes(HashSet<Integer> allowedFeaTypes) {
    this.allowedFeaTypes = allowedFeaTypes;
  }

}