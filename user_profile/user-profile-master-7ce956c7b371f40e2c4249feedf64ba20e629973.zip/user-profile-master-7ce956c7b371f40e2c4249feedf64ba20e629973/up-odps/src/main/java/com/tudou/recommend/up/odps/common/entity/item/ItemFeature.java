package com.tudou.recommend.up.odps.common.entity.item;

/**
 * item的feature
 * @author hezhimin
 *
 */
public class ItemFeature{
  /**
   * feature 类别
   */
  public int featureType;
  
  /**
   * feature
   */
  public String feature;
  
  /**
   * feature在item中的weight
   */
  public float weight;
  
  /**
   * 默认构造器
   */
  public ItemFeature(){
    this.featureType = -1;
    this.feature = null;
    this.weight = 0;
  }
  
  /**
   * 构造器
   * @param termType
   * @param term
   * @param weight
   */
  public ItemFeature(int featureType, String feature, float weight){
    this.featureType = featureType;
    this.feature = feature;
    this.weight = weight;
  }
  
  public ItemFeature(ItemFeature fea){
    if(fea != null){
      this.featureType = fea.featureType;
      this.feature = fea.feature;
      this.weight = fea.weight;
    }
  }
  
  public String toString(){
    StringBuilder bld = new StringBuilder();
    String sep = "::";
    bld.append(this.featureType).append(sep).append(this.feature).append(sep).append(this.weight);
    return bld.toString();
  }
  
  public boolean parse(String str) {
    String[] flds = str.split("::");
    if (flds.length == 3) {
      this.featureType = Integer.parseInt(flds[0]);
      this.feature = flds[1];
      this.weight = Float.parseFloat(flds[2]);
      return true;
    } else {
      return false;
    }
  }
}
