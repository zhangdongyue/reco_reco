package com.tudou.recommend.up.odps.common;

import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.Reducer;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.proto.ProtoUserImageEmb.EmbType;
import com.tudou.recommend.proto.ProtoUserImageEmb.MetaInfo;
import com.tudou.recommend.proto.ProtoUserImageEmb.Emb;
import com.tudou.recommend.proto.ProtoUserImageEmb.KeyElements;
import com.tudou.recommend.proto.ProtoUserImageEmb.SetDataRequest;

import com.google.common.base.Charsets;
import com.google.common.collect.Collections2;
import com.google.protobuf.ByteString;

import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.kafka.KafkaProducer;
import com.tudou.recommend.up.odps.common.kafka.KafkaProducerBuilder;

import com.tudou.recommend.up.odps.common.util.BaseArgContainer;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.math.BigDecimal;


public class UserImageEmbKafkaWriter {
    public static MrArgContainer argContainer = new MrArgContainer();

    public static class DataMapper extends MapperBase {

        private Record outputKey;
        private Record outputValue;

        @Override
        public void setup(TaskContext context) throws IOException {
            outputKey = context.createMapOutputKeyRecord();
            outputValue = context.createMapOutputValueRecord();
        }

        @Override
        public void map(long key, Record record, TaskContext context) throws IOException {        
                outputKey.setString(0, record.getString(0));
                outputValue.setString(0,record.getString(1));
                context.write(outputKey, outputValue);
        }
    }

    public static class DataReducer extends ReducerBase {
        private static final Logger logger = LoggerFactory.getLogger(DataReducer.class);
        private boolean debug;
        private Integer batchSize;
        // kafka
        private String kafkaBroker;
        private String kafkaTopic;
        
        private int partitionBegin;
        private int partitionEnd;
        private KafkaProducer<byte[]> kafkaProducer;

        // qps控制history
        private int sleepMs = 0;
        private int qpsOutputFreq = 10000;
        private long startTime;
        private long currentTime;
        private int dataNum;
        // emb dim
        private int dim;
        private String keyPrefix;
        private String version;

        private Record output;
        private Base64 base64 = new Base64();
        private Base64 encoder = new Base64();
        
        private List<Future<RecordMetadata>> buffer = new ArrayList<>();

        private boolean initKafkaProducer() {
            KafkaProducerBuilder kafkaBuilder = KafkaProducerBuilder.custom();
            kafkaBuilder.setBrokerList(kafkaBroker);
            kafkaProducer = kafkaBuilder.build();
            logger.info("The kafka producer is initialized.");
            return true;
        }


        @Override
        public void setup(TaskContext context) throws IOException {
            JobConf jobConf = context.getJobConf();
            dim = jobConf.getInt("dim", 128);
            keyPrefix = jobConf.get("keyPrefix","userImageFea");   
            version = jobConf.get("ver", "1.0");
            debug = jobConf.getBoolean("debug", false);            
            kafkaBroker = jobConf.get("kafkaBroker");
            kafkaTopic = jobConf.get("kafkaTopic");       
                        
            partitionBegin = jobConf.getInt("kafkaPartitionBegin", 0);
            partitionEnd = jobConf.getInt("kafkaPartitionEnd", 50);
            batchSize = jobConf.getInt("batchSize", 1);
            if (!initKafkaProducer()) {
                throw new IOException("Cannot init kafka producer.");
            }
            if (partitionBegin < 0 || partitionEnd < 0 || partitionEnd - partitionBegin <= 0) {
                throw new IOException("Partition begin or end assigned error.");
            }
       

            startTime = System.currentTimeMillis();
            dataNum = 0;
            sleepMs = jobConf.getInt("sleepMs", 0);
            qpsOutputFreq = jobConf.getInt("qpsOutputFreq", 10000);
            if (debug) {
                output = context.createOutputRecord();
            }
        }

        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
        	KeyElements.Builder keyBuilder = KeyElements.newBuilder();
        	KeyElements keyProto;      	
        	SetDataRequest.Builder setDataReqBuilder = SetDataRequest.newBuilder();
        	SetDataRequest setDataReqProto;
        	
            String ikey = key.getString(0);
            keyBuilder.setKey(ikey);
            keyBuilder.setProduct(keyPrefix);
            keyBuilder.setVersion(version);
            keyProto = keyBuilder.build();
            if (!keyProto.isInitialized())
            {
            	logger.error("keyProto is not initialized!");
            	return;
            }
            setDataReqBuilder.setKeyElements(keyProto);
            
            byte[] keyBytes = keyProto.toByteArray();
            String keyBytesString = encoder.encodeToString(keyBytes);
            
            String [] kTopics = kafkaTopic.split(",",-1);
            
            while (values.hasNext()) {
                Record value = values.next();
                String profile = value.getString(0); 
                byte[] valueBytes = base64.decode(profile);
                Emb proto = Emb.parseFrom(valueBytes);              
                setDataReqBuilder.setValue(proto.toByteString());
                               
                setDataReqProto = setDataReqBuilder.build();
                if (!setDataReqProto.isInitialized())
                {
                	logger.error("setDataReqProto is not initialized!");
                	return;
                }
                byte[] setDataBytes = setDataReqProto.toByteArray();
                
                // write to kafka
                int partition = Math.abs(keyBytesString.hashCode()) % (partitionEnd - partitionBegin) + partitionBegin;
                try {
                    if (batchSize <= 1) {
                    	for (String kTopic:kTopics )
                    	{	if (!kTopic.trim().isEmpty()) {
                    			kafkaProducer.send(kTopic.trim(), partition, ikey, setDataBytes);
                    		}
                    	}
                        context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "kafka_write_success").increment(1L);
                    } else {
                    	for (String kTopic:kTopics) {
                    		if (!kTopic.trim().isEmpty())
                    		{
                    			buffer.add(kafkaProducer.asyncSend(kTopic.trim(), partition, ikey, setDataBytes));
                    		}
                    	}
                        if (buffer.size() >= batchSize) {
                            for (Future<RecordMetadata> future : buffer) {
                                try {
                                    future.get();
                                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "kafka_write_success").increment(1L);
                                } catch (Exception e) {
                                    logger.info("get future result error.", e);
                                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "kafka_write_failed").increment(1L);
                                }
                            }
                            logger.info("batch send kafka message with size:{}", buffer.size());
                            buffer.clear();
                        }
                    }
                    if (debug) {
                        output.setString(0, ikey);
                        //Emb proto = Emb.parseFrom(valueBytes);
                        List<Float>  userEmbVec =  proto.getVecList();
                        double tmp = 0.0;
                        for (int i = 0; i < dim; i ++)
                        {                        	
                        	BigDecimal b = new BigDecimal(String.valueOf(userEmbVec.get(i)));                          	
                        	double d = b.doubleValue();
                        	output.setDouble(i+1, d);                        	
                        }
                                                                     
                        context.write(output);
                    }
                } catch (Exception e) {
                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "kafka_write_failed").increment(1L);
                    logger.error("failed to write kafka: topic={}, partition={}, key={}, value={}",
                            kafkaBroker, partition, ikey, new String(valueBytes, Charsets.ISO_8859_1));
                    logger.error("send kafka message error.", e);
                }
                // qps control
                dataNum++;
                if (dataNum % qpsOutputFreq == 0) {
                    currentTime = System.currentTimeMillis();
                    double time = (currentTime - startTime) / 1000.0;
                    double qps = dataNum / time;
                    logger.info("## dataNum={}, seconds={}, qps={}", dataNum, time, qps);
                }
                if (sleepMs > 0) {
                    try {
                        Thread.sleep(sleepMs);
                    } catch (InterruptedException e) {
                        logger.error("interrupted exception.", e);
                    }
                }
            }

        }
        @Override
        public void cleanup(TaskContext context) throws IOException {
            if (batchSize > 1 && buffer.size() > 0) {
                try {
                    for (Future<RecordMetadata> future : buffer) {
                        future.get();
                        context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "kafka_write_success").increment(1L);
                    }
                    logger.info("batch send kafka message with size:{}", buffer.size());
                } catch (Exception e) {
                    logger.error("Get future result error.", e);
                } finally {
                    buffer.clear();
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        JCommander commander = new JCommander(argContainer);
        commander.parse(args);
        Job job = new Job();
        job.set("kafkaBroker", argContainer.getKafkaBroker());
        job.set("kafkaTopic", argContainer.getKafkaTopic());
        job.setInt("kafkaPartitionBegin", argContainer.getKafkaPartitionBegin());
        job.setInt("kafkaPartitionEnd", argContainer.getKafkaPartitionEnd());
        job.setInt("rowKeyIndex", argContainer.getRowKeyIndex());
        job.setInt("dataIndex", argContainer.getDataIndex());
        job.set("writeModel", argContainer.getWriteModel());
        job.setInt("batchSize", argContainer.getBatchSize());
        job.setInt("sleepMs", argContainer.getSleepMs());
        job.setInt("qpsOutputFreq", argContainer.getQpsOutputFreq());        
        job.setBoolean("debug", argContainer.isDebug());
        job.set("keyPrefix", argContainer.getKeyPrefix());
        job.set("ver", argContainer.getVer());
        job.setInt("dim",argContainer.getDim());
        job.setBoolean("debug", argContainer.isDebug());
        

        job.setMapperClass(DataMapper.class);
        job.setReducerClass(DataReducer.class);
        job.setMapOutputKeySchema(SchemaUtils.fromString("ikey:string"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("ivalue:string"));
        
        
        MrJobParamSetter.addInput(job, argContainer.getInput());
        if (argContainer.isDebug()) {
            MrJobParamSetter.addOutput(job, argContainer.getOutput());
        }
        job.waitForCompletion();
        System.exit(job.isSuccessful() == true ? 0 : 1);
    }

    public static class MrArgContainer extends BaseArgContainer {
        @Parameter(names = "-kafkaBroker", description = "kafka brokers")
        private String kafkaBroker = "";

        @Parameter(names = "-kafkaTopic", description = "kafka topic")
        private String kafkaTopic = "_test";

        @Parameter(names = "-kafkaPartitionBegin", description = "start kafka partition index")
        private int kafkaPartitionBegin = 0;

        @Parameter(names = "-kafkaPartitionEnd", description = "end kafka partition index")
        private int kafkaPartitionEnd = 50;

        @Parameter(names = "-rowKeyIndex", description = "")
        private int rowKeyIndex = 0;

        @Parameter(names = "-dataIndex", description = "")
        private int dataIndex = 1;

        @Parameter(names = "-writeModel", description = "hbase write model: single, batch")
        private String writeModel = "single";

        @Parameter(names = "-batchSize", description = "")
        private int batchSize = 1;

        @Parameter(names = "-sleepMs", description = "")
        private int sleepMs = 0;

        @Parameter(names = "-qpsOutputFreq", description = "")
        private int qpsOutputFreq = 10000;

        @Parameter(names = "-dataConvert",
                description = "convert data before writing to hbase: escape, unescape, none")
        private String dataConvert;      
        
        @Parameter(names = "-dim", description = "emb size")
        private int dim;
        @Parameter(names = "-keyPrefix", description = "key prefix")
        private String keyPrefix;
        
        @Parameter(names = "-ver", description = "version")
        private String ver;
        public String getVer() {
        	return ver;
        }
        public void setVer(String ver) {
        	this.ver = ver;
        }
        public int getDim() {
        	return dim;
        }
        public void setDim(int dim) {
        	this.dim = dim;
        }
        public String getKeyPrefix() {
        	return keyPrefix;
        }
        public void setKeyPrefix(String keyPrefix) {
        	this.keyPrefix = keyPrefix;
        }
        public String getKafkaBroker() {
            return kafkaBroker;
        }

        public void setKafkaBroker(String kafkaBroker) {
            this.kafkaBroker = kafkaBroker;
        }

        public String getKafkaTopic() {
            return kafkaTopic;
        }

        public void setKafkaTopic(String kafkaTopic) {
            this.kafkaTopic = kafkaTopic;
        }

        public int getKafkaPartitionBegin() {
            return kafkaPartitionBegin;
        }

        public void setKafkaPartitionBegin(int kafkaPartitionBegin) {
            this.kafkaPartitionBegin = kafkaPartitionBegin;
        }

        public int getKafkaPartitionEnd() {
            return kafkaPartitionEnd;
        }

        public void setKafkaPartitionEnd(int kafkaPartitionEnd) {
            this.kafkaPartitionEnd = kafkaPartitionEnd;
        }

        public int getRowKeyIndex() {
            return rowKeyIndex;
        }

        public void setRowKeyIndex(int rowKeyIndex) {
            this.rowKeyIndex = rowKeyIndex;
        }

        public int getDataIndex() {
            return dataIndex;
        }

        public void setDataIndex(int dataIndex) {
            this.dataIndex = dataIndex;
        }

        public String getWriteModel() {
            return writeModel;
        }

        public void setWriteModel(String writeModel) {
            this.writeModel = writeModel;
        }

        public int getBatchSize() {
            return batchSize;
        }

        public void setBatchSize(int batchSize) {
            this.batchSize = batchSize;
        }

        public int getSleepMs() {
            return sleepMs;
        }

        public void setSleepMs(int sleepMs) {
            this.sleepMs = sleepMs;
        }

        public int getQpsOutputFreq() {
            return qpsOutputFreq;
        }

        public void setQpsOutputFreq(int qpsOutputFreq) {
            this.qpsOutputFreq = qpsOutputFreq;
        }

        public String getDataConvert() {
            return dataConvert;
        }

        public void setDataConvert(String dataConvert) {
            this.dataConvert = dataConvert;
        }

        

    }
}
