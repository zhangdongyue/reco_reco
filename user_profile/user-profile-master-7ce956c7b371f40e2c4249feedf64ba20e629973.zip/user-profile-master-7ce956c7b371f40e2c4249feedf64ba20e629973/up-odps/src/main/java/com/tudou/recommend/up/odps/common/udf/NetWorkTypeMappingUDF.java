package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;

public class NetWorkTypeMappingUDF extends UDF {

	public String evaluate(String network) {
		if (network == null || network.isEmpty()) {
			return "99";
		} else if ("2G".equals(network) || "2G/3G".equals(network)) {
			return "0";
		} else if ("3G".equals(network) || "4G".equals(network) || "5G".equals(network)) {
			return "1";
		} else if (network.equalsIgnoreCase("wifi")
				|| network.equalsIgnoreCase("wi-fi")) {
			return "2";
		} else {
			return "99";
		}
	}
}
