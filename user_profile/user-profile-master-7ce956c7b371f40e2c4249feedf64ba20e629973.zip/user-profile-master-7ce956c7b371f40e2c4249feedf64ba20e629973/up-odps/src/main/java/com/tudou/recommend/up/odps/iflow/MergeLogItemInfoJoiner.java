package com.tudou.recommend.up.odps.iflow;

import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.log.MergeLog;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.item.RecoItemInfo;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;

/**
 * 将item fea拼接到merge log中 trick: 部分热门新闻下发次数可能很大，直接按item ID
 * 为key分发到reduce可能把内存撑爆，可以按itemid + 后缀打散后分发
 * 
 * @author zengtao
 *
 */
public class MergeLogItemInfoJoiner {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class MergeLogItemInfoJoinerMapper extends MapperBase {
		private Record joinKey;
		private Record outputLog;
		private String logDataTableName;
		private String itemInfoDataTableName;
		private int joinShuffleFactor;
		private int count = 0;
		private String tableName;
		private HashSet<String> appNameSet = new HashSet<String>();
		
		@Override
		public void setup(TaskContext context) throws IOException {
			joinKey = context.createMapOutputKeyRecord();
			outputLog = context.createMapOutputValueRecord();
			JobConf jobConf = context.getJobConf();

			logDataTableName = jobConf.get("logDataTableName");
			itemInfoDataTableName = jobConf.get("itemInfoDataTableName");
			joinShuffleFactor = jobConf.getInt("joinShuffleFactor", 0);
			tableName = context.getInputTableInfo().getTableName();
			String[] appNames = jobConf.get("appNameList", "").split(",", -1);
			for (String appName : appNames) {
				if (!appName.isEmpty()) {
					appNameSet.add(appName);
				}
			}
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			if (tableName.equalsIgnoreCase(logDataTableName)) {
				MergeLog log = new MergeLog();
				if (!log.parseFromStr(record.getString(0))) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_merge_log").increment(1L);
					return;
				}
				if (log.itemId.isEmpty() || log.itemId.isEmpty()) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"empty_item_id").increment(1L);
					return;
				}
				if (!appNameSet.isEmpty() && appNameSet.contains(log.appName)) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"filtered_by_app_name").increment(1L);
					return;
				}
				// merge log 打散后分发，避免把reduce内存打爆
				outputLog.setString(0, "2:" + record.getString(0));
				if (joinShuffleFactor <= 1) {
					joinKey.setString(0, log.itemId);
					context.write(joinKey, outputLog);
				} else {
					joinKey.setString(0, log.itemId + "_" + count);
					context.write(joinKey, outputLog);
					count = (count + 1) % joinShuffleFactor;
				}
			} else if (tableName.equalsIgnoreCase(itemInfoDataTableName)) {
				RecoItemInfo itemInfo = RecoItemInfo.parseFromRecord(record);
				if (itemInfo == null) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_item_info").increment(1L);
					return;
				}
				// item info 重复分发，避免把reduce内存打爆
				outputLog.setString(0, "1:" + recordToString(record));
				if (joinShuffleFactor <= 1) {
					joinKey.setString(0, itemInfo.itemId);
					context.write(joinKey, outputLog);
				} else {
					for (int prefix = 0; prefix < joinShuffleFactor; ++prefix) {
						joinKey.setString(0, itemInfo.itemId + "_" + prefix);
						context.write(joinKey, outputLog);
					}
				}
			} else {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_input_source").increment(1L);
				return;
			}
		}

		private String recordToString(Record record) {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < record.getColumnCount(); i++) {
				if (sb.length() > 0) {
					sb.append("\t");
				}
				sb.append(record.getString(i));
			}
			return sb.toString();
		}
	}

	public static class MergeLogItemInfoJoinerReducer extends ReducerBase {
		private Record result;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			String itemInfoStr = "";
			LinkedList<String> logs = new LinkedList<String>();
			String itemStr;
			String valueStr;
			String tag;
			while (values.hasNext()) {
				itemStr = values.next().getString(0);
				tag = itemStr.substring(0, 2);
				valueStr = itemStr.substring(2);
				if ("1:".equals(tag)) {
					if (valueStr.length() > itemInfoStr.length()) {
						itemInfoStr = valueStr;
					}
				} else if ("2:".equals(tag)) {
					logs.add(valueStr);
				} else {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_input_source").increment(1L);
					continue;
				}
			}
			for (String log : logs) {
				result.setString(0, log);
				result.setString(1, itemInfoStr);
				context.write(result);
				if (itemInfoStr.isEmpty()) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"merge_log_without_item_info").increment(1L);
				} else {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"merge_log_with_item_info").increment(1L);
				}
			}
		}

	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("joinKey:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("outputLog:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput());
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(MergeLogItemInfoJoinerMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(MergeLogItemInfoJoinerReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		MrJobParamSetter.setSplitSize(job, 128L);

		job.set("logDataTableName", argContainer.getLogDataDir());
		job.set("itemInfoDataTableName", argContainer.getItemInfoDataDir());
		job.setInt("joinShuffleFactor", argContainer.getJoinShuffleFactor());
		job.set("appNameList", argContainer.getAppNameList());
		
		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-logDataTableName", description = "")
		private String logDataTableName = "logDataTableName";

		@Parameter(names = "-itemInfoDataTableName", description = "")
		private String itemInfoDataTableName = "itemInfoDataTableName";

		@Parameter(names = "-joinShuffleFactor", description = "")
		private int joinShuffleFactor = 0;

		@Parameter(names = "-appNameList", description = "")
		private String appNameList = "";
		
		public String getLogDataDir() {
			return logDataTableName;
		}

		public void setLogDataDir(String logDataDir) {
			this.logDataTableName = logDataDir;
		}

		public String getItemInfoDataDir() {
			return itemInfoDataTableName;
		}

		public void setItemInfoDataDir(String itemInfoDataDir) {
			this.itemInfoDataTableName = itemInfoDataDir;
		}

		public int getJoinShuffleFactor() {
			return joinShuffleFactor;
		}

		public void setJoinShuffleFactor(int joinShuffleFactor) {
			this.joinShuffleFactor = joinShuffleFactor;
		}

		public String getAppNameList() {
			return appNameList;
		}

		public void setAppNameList(String appNameList) {
			this.appNameList = appNameList;
		}
	}
}
