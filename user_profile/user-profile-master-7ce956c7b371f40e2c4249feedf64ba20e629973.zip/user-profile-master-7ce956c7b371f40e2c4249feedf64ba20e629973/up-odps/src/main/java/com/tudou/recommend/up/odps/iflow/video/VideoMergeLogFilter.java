package com.tudou.recommend.up.odps.iflow.video;

import java.io.IOException;
import java.util.Iterator;

import com.tudou.recommend.up.odps.common.entity.log.MergeLog;
import org.apache.log4j.Logger;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
/**
 * 过滤出uc头条视频日志
 * @author zengtao
 *
 */
public class VideoMergeLogFilter {
	private static final Logger logger = Logger
			.getLogger(VideoMergeLogFilter.class);
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class VideoMergeLogFilterMapper extends MapperBase {
		private Record k2;
		private Record v2;

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			MergeLog mergeLog = new MergeLog();
			if (!mergeLog.parseFromOrigMergeLogRecord(record)) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_map_input").increment(1);
				return;
			}

			// 过滤无效merge log
			String itemId = mergeLog.getItemId();
			String userId = mergeLog.getUserId();
			String appName = mergeLog.getAppName();

			if (itemId.isEmpty() || "0".equals(itemId)) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_item_id").increment(1L);
				return;
			}
			if (userId.isEmpty() || "0".equals(userId)) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_user_id").increment(1L);
				return;
			}

			// 过滤视频
			if (mergeLog.getItemType() != 30) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"no_video_log").increment(1L);
				return;
			}
			k2.setString(0, DataFormatUtil.GenUserKey(userId, appName));
			v2.setString(0, mergeLog.toString());
			context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "video_log")
					.increment(1L);
			context.write(k2, v2);
		}
	}

	public static class VideoMergeLogFilterReducer extends ReducerBase {
		private Record result;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {

			while (values.hasNext()) {
				result.setString(0, values.next().getString(0));
				context.write(result);
			}
		}

	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("v2:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {
				"tm", "appname", "recoid", "itemid", "itemtype", "cid",
				"userid", "click", "share_count", "cmt", "fav", "strategy",
				"source", "title", "fr", "city", "prov", "imei", "mac",
				"utdid", "dn", "ni", "nt", "server", "auto", "sn", "disagree",
				"agree", "dislike", "gi", "progress", "client_user_info" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(VideoMergeLogFilterMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(VideoMergeLogFilterReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {

	}
}
