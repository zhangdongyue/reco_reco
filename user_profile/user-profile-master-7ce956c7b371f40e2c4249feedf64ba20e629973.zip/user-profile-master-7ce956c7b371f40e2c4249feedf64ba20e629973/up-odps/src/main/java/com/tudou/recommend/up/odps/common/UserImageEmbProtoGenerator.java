package com.tudou.recommend.up.odps.common;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.proto.ProtoUserImageEmb.EmbType;
import com.tudou.recommend.proto.ProtoUserImageEmb.MetaInfo;
import com.tudou.recommend.proto.ProtoUserImageEmb.Emb;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import org.apache.commons.codec.binary.Base64;

import java.io.IOException;
import java.util.*;

/**
 * Generate user image emb proto data 
 *
 * @author: wj148482
 */
public class UserImageEmbProtoGenerator {
    public static ArgumentContainer argContainer = new ArgumentContainer();

    /**
     * Read feature file and distribute with user id.
     */
    public static class DataMapper extends MapperBase {
        
        private Record key;
        private Record value;

        @Override
        public void setup(TaskContext context) throws IOException {
            key = context.createMapOutputKeyRecord();
            value = context.createMapOutputValueRecord();
        }

        @Override
        public void map(long recordNum, Record record, TaskContext context) throws IOException {
                 
            key.setString(0, record.getString(0));
            value.setString(0, record.getString(1));            
            context.write(key, value);
        }
    }

    public static class DataReducer extends ReducerBase {
       
        private int embLen = 128;
	private int idType = 1;
        private Record output;
        private Base64 encoder = new Base64();
        private MetaInfo.Builder  metaInfoBuilder = MetaInfo.newBuilder();
        private MetaInfo metaInfo;
        
        @Override
        public void setup(TaskContext context) throws IOException {
            JobConf jobConfig = context.getJobConf();
            embLen = jobConfig.getInt("dim", 128);       
	        idType = jobConfig.getInt("type", 1);
            output = context.createOutputRecord();
                 
            metaInfoBuilder.setEmbType(EmbType.Poster);
            metaInfoBuilder.setDim(embLen);
	        metaInfoBuilder.setType(idType);
            metaInfo = metaInfoBuilder.build();
            if (!metaInfo.isInitialized())
            {
            	context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "metaInfo_Initial_ERROR").increment(1L);
                return;
            }
        }

        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
        	String sid = key.getString(0);
        	Emb.Builder embBuilder = Emb.newBuilder();
        	
        	embBuilder.setId(0);        	
        	embBuilder.setMetaInfo(metaInfo);
        	embBuilder.setSid(sid);
            while (values.hasNext()) {
                Record record = values.next();
                String fea = record.getString(0);
                String [] feaVec = fea.split(":");
                if (feaVec.length != embLen)
                {
                	continue;
                }
                else
                {
                	for (int j = 0; j < embLen; j++)
                	{
                		float oriFeaWei = Float.parseFloat(feaVec[j]);
                		embBuilder.addVec(oriFeaWei);
                	}
                	Emb emb = embBuilder.build();
                	if (!emb.isInitialized())
                	{
                		context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "Emb_Initial_ERROR").increment(1L);
                        return;
                	}
                	
                	byte [] embBytes = emb.toByteArray();                	
                	String bytesString = encoder.encodeToString(embBytes);
                	output.setString(0, sid);
                	output.setString(1, bytesString);
                	
                	context.write(output);
                }
                
            }

        }
    }

    public static void main(String[] args) throws OdpsException {
        JCommander commander = new JCommander(argContainer);
        commander.parse(args);

        Job job = new Job();        
        job.setInt("dim", argContainer.getDim());
	job.setInt("type", argContainer.getType());

        job.setMapOutputKeySchema(SchemaUtils.fromString("user_id:string"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("feature_type:string"));
        
        job.setMapperClass(DataMapper.class);
        job.setReducerClass(DataReducer.class);
        MrJobParamSetter.addInput(job, argContainer.getInput());
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		       

        job.waitForCompletion();
        System.exit(job.isSuccessful() == true ? 0 : 1);
    }

    public static class ArgumentContainer extends BaseMrArgContainer {
        @Parameter(names = "-dim",
                required = true,
                description = "fea emb dim")
        private int dim = 128; 
        @Parameter(names = "-type",
                required = true,
                description = "id type 1:userid 2:itemid")
        private int type = 1; 
        
        public int getDim() {
        	return dim;
        }
        public void setDim(int dim) {
        	this.dim = dim;
        }
        public int getType() {
        	return type;
        }
        public void settype(int type) {
        	this.type = type;
        }

    }
}
