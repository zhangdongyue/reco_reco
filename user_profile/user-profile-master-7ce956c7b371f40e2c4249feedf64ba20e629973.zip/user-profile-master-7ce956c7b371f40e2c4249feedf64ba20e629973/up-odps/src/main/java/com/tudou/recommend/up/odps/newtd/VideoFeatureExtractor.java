package com.tudou.recommend.up.odps.newtd;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.tudou.recommend.proto.ProtoConvertorServer;
import com.tudou.recommend.up.odps.newtd.entity.TudouItemInfo;
import com.wolong.protorpc.client.pool.PooledRpcClient;
import com.wolong.protorpc.client.protobuf.DefaultBlockingRpcChannel;
import com.wolong.protorpc.model.DefaultRpcController;

/**
 * 提取土豆视频的特征
 * 
 * @author hezhimin
 */
public class VideoFeatureExtractor {
	private static final Logger logger = Logger
			.getLogger(VideoFeatureExtractor.class);
	private boolean useDescription = false;
	private boolean useTag = false;
	private boolean useSource = false;

	// convertor server
	private String rpcServerAddress;
	private int rpcTimeout;
	private int rpcRetry;

	private PooledRpcClient rpcClient = null;
	private ProtoConvertorServer.ConvertorService.BlockingInterface convertorService = null;
	private boolean isRpcInit = false;

	private boolean debug = false;

	public void initRpcConnection() {
		rpcClient = new PooledRpcClient(rpcServerAddress, rpcTimeout);
		try {
			rpcClient.bootstrap();
		} catch (Exception e) {
			logger.error(e.getMessage());
			return;
		}
		convertorService = ProtoConvertorServer.ConvertorService
				.newBlockingStub(new DefaultBlockingRpcChannel(rpcClient));
		isRpcInit = true;
		//logger.info("convertor server connection init successed");
	}

	public void closeRpcConnection() {
		if (rpcClient != null && !rpcClient.isStopped()) {
			try {
				rpcClient.stop();
			} catch (Exception e) {
				//logger.error("Convertor service destroy() exception->", e);
			}
		}
	}

	public boolean extractFeature(TudouItemInfo itemInfo,
			ArrayList<String> categories, ArrayList<String> tags) {
		if (itemInfo == null || itemInfo.vdoTitle == null
				|| itemInfo.vdoTitle.isEmpty()) {
			return false;
		}

		// 构建rpc request
		ProtoConvertorServer.ExtractFeatureRequest.Builder builder = ProtoConvertorServer.ExtractFeatureRequest
				.newBuilder();
		builder.setReturnCategory(true).setReturnTag(true);
		builder.setTitle(itemInfo.vdoTitle);
		if (useDescription) {
			builder.setContent(itemInfo.vdoDesc);
		}
		if (useSource) {
			builder.setSource(itemInfo.vdoSource);
		}
		ProtoConvertorServer.ExtractFeatureRequest request = builder.build();
		DefaultRpcController controller = new DefaultRpcController();
		ProtoConvertorServer.ExtractFeatureResponse response = null;

		int retry = 3;
		while (retry > 0) {
			try {
				if (!isRpcInit || rpcClient == null || rpcClient.isStopped()) {
					initRpcConnection();
				}
				response = convertorService.extractFeature(controller, request);
			} catch (Exception e) {
				logger.error("rpc call failed as " + e.getMessage(), e);
				retry--;
				closeRpcConnection();
				initRpcConnection();
				continue;
			}
			break;
		}

		if (response == null || !response.getSuccess()) {
			return false;
		}

		categories.clear();
		tags.clear();
		categories.addAll(response.getCategoryList());
		tags.addAll(response.getTagsList());
		return true;
	}

	public void setUseDescription(boolean useDescription) {
		this.useDescription = useDescription;
	}

	public void setUseTag(boolean useTag) {
		this.useTag = useTag;
	}

	public void setUseSource(boolean useSource) {
		this.useSource = useSource;
	}

	public void setRpcServerAddress(String rpcServerAddress) {
		this.rpcServerAddress = rpcServerAddress;
	}

	public void setRpcTimeout(int rpcTimeout) {
		this.rpcTimeout = rpcTimeout;
	}

	public void setRpcRetry(int rpcRetry) {
		this.rpcRetry = rpcRetry;
	}

	public void setDebug(boolean debug) {
		this.debug = debug;
	}

}
