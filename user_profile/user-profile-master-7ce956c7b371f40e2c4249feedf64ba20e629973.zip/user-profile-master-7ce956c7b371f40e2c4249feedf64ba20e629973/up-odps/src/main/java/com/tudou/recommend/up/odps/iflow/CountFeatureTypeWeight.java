package com.tudou.recommend.up.odps.iflow;

import java.io.IOException;
import java.util.*;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.iflow.util.FeatureWeightCalculator;

/**
 * 
 * @author jinchanghu
 * @date 2017年7月1日 下午6:10:36
 */
public class CountFeatureTypeWeight {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class UserFeatureWeightMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private FeatureWeightCalculator calculator;
		
		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			calculator = new FeatureWeightCalculator();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			// input format
			// feaType ~ fea ~ [bucket : weightSum ]

			int feaType = Integer.parseInt(record.getString(0));
			if (!calculator.isFeatureAllowed(feaType)) {
				return;
			}
			
			String feature = record.getString(1);
			String weightSum = record.getString(2);
			
			if (feature == null || weightSum == null) {
				return;
			}
			
			String[] tokens = weightSum.split(" ");
			for (int i = 0; i < tokens.length; i++) {
				String[] bucketWeight = tokens[i].split(":");
				if (bucketWeight.length == 2) {
					String bucket = bucketWeight[0];
					String weight = bucketWeight[1];
					
					String typeWithBucket = feaType + "\t" + bucket;
					
					k2.setString(0, typeWithBucket);
					v2.setString(0, weight);
					context.write(k2, v2);
				}
			}
	
		}
	}

	/**
	 * calculate max type weight in each bucket
	 * use different method to calculate long and short video hot factor. 
	 * @author jinchanghu
	 * @date 2017年7月11日 下午6:10:07
	 */
	public static class FeaWeightReducer extends ReducerBase {
		private Record result;
		private FeatureWeightCalculator calculator;
		private HashMap<Integer, HashMap<Integer, Double>> maxWeightMap = new HashMap<Integer, HashMap<Integer, Double>>();
		private HashMap<Integer, HashMap<Integer, Double>> minWeightMap = new HashMap<Integer, HashMap<Integer, Double>>();
		
		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
			calculator = new FeatureWeightCalculator();
			maxWeightMap = calculator.initTermWeightMap();
			minWeightMap = calculator.initTermWeightMap();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
			String typeWithBucket = key.getString(0);
			String[] tokens = typeWithBucket.split("\t");
			if (tokens.length!=2) {
				return;
			}
			
			int termType = Integer.parseInt(tokens[0]);
			int bucket = Integer.parseInt(tokens[1]);
			
			// 计算每个type的不同时间桶内的最大值
			while (values.hasNext()) {
				Record r = values.next();
				String weightStr = r.getString(0);
				if (weightStr == null) {
					continue;
				}
				double weight = Double.parseDouble(weightStr);
				
				// count max value for each bucket.
				if (!maxWeightMap.get(termType).containsKey(bucket)) {
					maxWeightMap.get(termType).put(bucket, weight);
				} else if(maxWeightMap.get(termType).get(bucket) < weight) {
					maxWeightMap.get(termType).put(bucket, weight);
				}
				
				// count min value for each bucket.
				if (!minWeightMap.get(termType).containsKey(bucket)) {
					minWeightMap.get(termType).put(bucket, weight);
				} else if(minWeightMap.get(termType).get(bucket) > weight) {
					minWeightMap.get(termType).put(bucket, weight);
				}
				
			}
		}
		
		@Override
		public void cleanup(TaskContext context) throws IOException {
			// output
			StringBuilder builder = new StringBuilder();
			for (int featureType : maxWeightMap.keySet()) {
				if (maxWeightMap.get(featureType).size() == 0) {
					continue;
				}
				for (int bucketId : maxWeightMap.get(featureType).keySet()) {
					builder.delete(0, builder.length());
					builder.append(maxWeightMap.get(featureType).get(bucketId));
					builder.append(":");
					builder.append(minWeightMap.get(featureType).get(bucketId));
					
					result.setString(0, String.valueOf(featureType));	
					result.setString(1, String.valueOf(bucketId));		
					result.setString(2, builder.toString());
					
					context.write(result);
				}
			}
			
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils
				.fromString("v2:string"));
		
		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {"feature_type", "feature", "weight" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		
		// TODO: specify a mapper
		job.setMapperClass(UserFeatureWeightMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(FeaWeightReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {

		@Parameter(names = "-ctrSmooth", description = "whether use category ctr to smooth term weight")
		private int ctrSmooth = 0;

		@Parameter(names = "-inactiveThreshold", description = "")
		private String inactiveThreshold = "0";

		@Parameter(names = "-minWeight", description = "")
		private String minWeight = "0.5";

		@Parameter(names = "-maxWeight", description = "")
		private String maxWeight = "1.0";
		
		@Parameter(names = "-orderType", description = "global feature weight order type: (long/short)")
		private String orderType = "short_video";

		public int getCtrSmooth() {
			return ctrSmooth;
		}

		public void setCtrSmooth(int ctrSmooth) {
			this.ctrSmooth = ctrSmooth;
		}

		public String getInactiveThreshold() {
			return inactiveThreshold;
		}

		public void setInactiveThreshold(String inactiveThreshold) {
			this.inactiveThreshold = inactiveThreshold;
		}

		public String getMinWeight() {
			return minWeight;
		}

		public void setMinWeight(String minWeight) {
			this.minWeight = minWeight;
		}

		public String getMaxWeight() {
			return maxWeight;
		}

		public void setMaxWeight(String maxWeight) {
			this.maxWeight = maxWeight;
		}
		
		public String getOrderType() {
			return this.orderType;
		}
		
		public void setOrderType(String orderType) {
			this.orderType = orderType;
		}
	}
}
