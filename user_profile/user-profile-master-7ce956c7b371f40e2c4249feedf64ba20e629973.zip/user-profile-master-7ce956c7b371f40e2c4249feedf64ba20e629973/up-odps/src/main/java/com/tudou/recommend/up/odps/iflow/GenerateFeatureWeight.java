package com.tudou.recommend.up.odps.iflow;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.ProfileHotFactorOrderType;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.iflow.util.FeatureWeightCalculator;

public class GenerateFeatureWeight {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class UserFeatureWeightMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private FeatureWeightCalculator calculator;
		
		
		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			calculator = new FeatureWeightCalculator();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			// input format
			// feaType ~ fea ~ [bucket : weightSum ]
			
			int feaType = Integer.parseInt(record.getString(0));
			if (!calculator.isFeatureAllowed(feaType)) {
				return;
			}
			
			String feature = record.getString(1);
			String featureWeight = record.getString(2);
			String feaWithType = record.getString(0) + "\t" + feature;
			
			if (feature == null || featureWeight == null) {
				return;
			}
			
			StringBuilder builder = new StringBuilder();
			String[] tokens = featureWeight.split(" ");
			for (int i = 0; i < tokens.length; i++) {
				builder.delete(0, builder.length());
				String[] bucketWeight = tokens[i].split(":");
				if (bucketWeight.length == 2) {
					int bucket = Integer.parseInt(bucketWeight[0]);
					double weight = Double.parseDouble(bucketWeight[1]);
					builder.append(bucket);
					builder.append(":");
					builder.append(weight);
					
					k2.setString(0, feaWithType);
					v2.setString(0, builder.toString());	// bucket:weight
					context.write(k2, v2);
				}
			}
		}
	}
	
	public static class FeaWeightReducer extends ReducerBase {
		private Record result;
		private static final DecimalFormat DF = DataFormatUtil.getDefaultDecimalFormater();
		private FeatureWeightCalculator calculator;
		private HashMap<Integer, HashMap<Integer, Double>> maxTermCountMap = new HashMap<Integer, HashMap<Integer, Double>>();
		private HashMap<Integer, HashMap<Integer, Double>> maxTermWeights = new HashMap<Integer, HashMap<Integer, Double>>();; // 每个桶权重的最大值
		
		
		/**
		 * read max type weight in each bucket
		 * @param values
		 * @param feaWeightsMap
		 * @throws NumberFormatException
		 * @throws IOException
		 */
		private void readFeatureWeightFile(Iterator<Record> values) throws NumberFormatException, IOException {
			while (values.hasNext()) {
				Record next = values.next();
				int feaType = Integer.parseInt(next.getString(0));
				int bucket = Integer.parseInt(next.getString(1));
				String maxAndMin = next.getString(2);
				String[] tokens = maxAndMin.split(":");
				if (tokens.length!=2) {
					continue;
				}
				
				double maxCount = Double.parseDouble(tokens[0]);
				double minCount = Double.parseDouble(tokens[1]);
				
				if (!maxTermCountMap.get(feaType).containsKey(bucket)) {
					maxTermCountMap.get(feaType).put(bucket, maxCount);
				} 
				
				if (!maxTermWeights.get(feaType).containsKey(bucket)) {
					double maxWeight = 1.0;
					if (minCount <= 0 || maxCount <= 0 || maxCount < minCount) {
						maxWeight = 1.0;
					} else {
						maxWeight = Math.log10((maxCount * 10)/minCount);
					}
					maxTermWeights.get(feaType).put(bucket, maxWeight);
				} 
			}
		}
		
		/**
		 * calculate final weight with max/min normalization.
		 * @param termType
		 * @param bucket
		 * @param weight
		 * @return
		 */
		private double calculateWeight(int termType, int bucket, double weight) {
			double termWeight = 1.0;
			double minWeight = calculator.getMinWeight();
			double maxWeight = calculator.getMaxWeight();
			String orderType = calculator.getOrderType();
			
			if (maxTermCountMap.get(termType).containsKey(bucket)) {
				double maxCount = maxTermCountMap.get(termType).get(bucket);
				if (weight <= 0 || maxCount <= 0 || maxCount < weight) {
					termWeight = 1.0;
				} else {
					termWeight = Math.log10((maxCount * 10)/weight);
				}
			} 
			
			// min/max normalization
			double finalWeight = 1.0;
			double max = maxTermWeights.get(termType).get(bucket);
			double min = 1.0;
			
			if (max - min < 1e-9) {
				finalWeight = 1.0;
			} else {
				finalWeight = (termWeight - min) / (max - min);
			}
			
			finalWeight = minWeight + (maxWeight - minWeight) * finalWeight;	// 值域映射到[1.0, 2.0]
			
			if (ProfileHotFactorOrderType.LONG.equals(orderType)) {
				finalWeight = minWeight + (maxWeight - finalWeight);			// 对长视频，反转分布  
			} else if (ProfileHotFactorOrderType.DEFAULT.equals(orderType)) {
				finalWeight = termWeight;
			}
			 
			return finalWeight;
		}
		
		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
			calculator = new FeatureWeightCalculator();
			
			JobConf conf = context.getJobConf();
			calculator.setMinWeight(Double.parseDouble(conf.get("minWeight","1.0")));
			calculator.setMaxWeight(Double.parseDouble(conf.get("maxWeight","2.0")));
			calculator.setOrderType(conf.get("orderType", "short_video"));
			this.maxTermCountMap = calculator.initTermWeightMap();
			this.maxTermWeights = calculator.initTermWeightMap();
			Iterator<Record> termWeightTable = context.readResourceTable(conf.get("typeWeightDataTable"));
			readFeatureWeightFile(termWeightTable);
			
			System.out.println(conf.get("orderType"));
		}

		@Override
		public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
			String termWithType = key.getString(0);
			String[] tokens = termWithType.split("\t");
			if (tokens.length!=2) {
				return;
			}
			
			String featureType = tokens[0];
			String feature = tokens[1];
			
			int termType = Integer.parseInt(featureType);
			
			StringBuilder builder = new StringBuilder();
			// 计算每个term的不同时间桶内的权重
			while (values.hasNext()) {
				Record r = values.next();
				String valueStr = r.getString(0);
				if (valueStr == null) {
					continue;
				}
				String[] tokens1 = valueStr.split(":");
				if (tokens1.length!=2) {
					continue;
				}
				
				int bucket = Integer.parseInt(tokens1[0]);
				double weight = Double.parseDouble(tokens1[1]);
				double finalWeight = calculateWeight(termType, bucket, weight);
				
				if (builder.length() > 0) {
					builder.append(" ");
				}
				
				builder.append(bucket);
				builder.append(":");
				builder.append(DF.format(finalWeight));
			}
			
			result.setString(0, featureType);			// feature_type
			result.setString(1, feature);				// feature
			result.setString(2, builder.toString());	// weight
			
			context.write(result);
		}
	}
	
	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		
		Job job = new Job();
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("v2:string"));
		
		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {"feature_type", "feature", "weight" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		
		job.setMapperClass(UserFeatureWeightMapper.class);
		job.setReducerClass(FeaWeightReducer.class);
		 
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job, argContainer.getNumReducer());
		}
		
		job.set("inactiveThreshold", argContainer.getInactiveThreshold());
		job.set("typeWeightDataTable", argContainer.getWeightTable());
		job.set("minWeight", argContainer.getMinWeight());
		job.set("maxWeight", argContainer.getMaxWeight());
		job.set("orderType", argContainer.getOrderType());
		
		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {

		@Parameter(names = "-typeWeightDataTable", description = "type weight resource table name")
		private String typeWeightDataTable = "typeWeightDataTable";

		@Parameter(names = "-inactiveThreshold", description = "")
		private String inactiveThreshold = "0";

		@Parameter(names = "-minWeight", description = "")
		private String minWeight = "0.5";

		@Parameter(names = "-maxWeight", description = "")
		private String maxWeight = "1.0";
		
		@Parameter(names = "-orderType", description = "global feature weight order type: (long/short)")
		private String orderType = "short_video";

		public String getWeightTable() {
			return this.typeWeightDataTable;
		}
		
		public void setWeightTable(String typeWeightDataTable) {
			this.typeWeightDataTable = typeWeightDataTable;
		}

		public String getInactiveThreshold() {
			return inactiveThreshold;
		}

		public void setInactiveThreshold(String inactiveThreshold) {
			this.inactiveThreshold = inactiveThreshold;
		}

		public String getMinWeight() {
			return minWeight;
		}

		public void setMinWeight(String minWeight) {
			this.minWeight = minWeight;
		}

		public String getMaxWeight() {
			return maxWeight;
		}

		public void setMaxWeight(String maxWeight) {
			this.maxWeight = maxWeight;
		}
		
		public String getOrderType() {
			return this.orderType;
		}
		
		public void setOrderType(String orderType) {
			this.orderType = orderType;
		}
	}
}
