package com.tudou.recommend.up.odps.iflow;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import com.aliyun.odps.Column;
import com.aliyun.odps.OdpsException;
import com.aliyun.odps.OdpsType;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.pipeline.Pipeline;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.iflow.util.FeatureWeightCalculator;

/**
 *
 * 计算 feature的权重, 计算时考虑click数、总体ctr等因素
 * 总体逻辑：feature被点击次数越多（热度越高），则计算interest时降权系数越大，对画像的影响越小
 * 
 * @author zengtao
 *
 */
public class FeatureWeightGenerator {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class UserWeightSumMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private FeatureWeightCalculator calculator;
		// fea ~ bucket ~ [weightSum, clickSum]
		private HashMap<String, HashMap<Integer, double[]>> statResults = new HashMap<String, HashMap<Integer, double[]>>();

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			calculator = new FeatureWeightCalculator();
			statResults.clear();

		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			// input format
			// appname-userId ~ feaType ~ fea ~ [bucket : weightSum : clickSum]

			int feaType = Integer.parseInt(record.getString(0));
			if (!calculator.isFeatureAllowed(feaType)) {
				return;
			}

			String feaWithType = feaType + "\t" + record.getString(1);
			if (!statResults.containsKey(feaWithType)) {
				statResults.put(feaWithType, new HashMap<Integer, double[]>());
			}
			HashMap<Integer, double[]> feaStatResults = statResults
					.get(feaWithType);

			String[] buckets = record.getString(2).split(" ", -1);
			for (String str : buckets) {
				String[] numbers = str.split(":", -1);
				int bucket = Integer.parseInt(numbers[0]);
				double weight = Double.parseDouble(numbers[1]);
				double click = Double.parseDouble(numbers[2]);

				// 累加weight, click
				if (!feaStatResults.containsKey(bucket)) {
					feaStatResults.put(bucket, new double[] { 0, 0 });
				}
				feaStatResults.get(bucket)[0] += weight;
				feaStatResults.get(bucket)[1] += click;
			}
		}

		@Override
		public void cleanup(TaskContext context) throws IOException {
			StringBuilder builder = new StringBuilder();
			for (String feaWithType : statResults.keySet()) {
				HashMap<Integer, double[]> feaStatResults = statResults
						.get(feaWithType);
				if (feaStatResults.size() > 0) {
					builder.delete(0, builder.length());
					for (int bucket : feaStatResults.keySet()) {
						if (builder.length() > 0) {
							builder.append(" ");
						}
						double[] weights = feaStatResults.get(bucket);
						builder.append(bucket);
						for (int k = 0; k < weights.length; ++k) {
							builder.append(":").append(weights[k]);
						}
					}
					k2.setString(0, feaWithType);
					v2.setString(0, builder.toString());
					context.write(k2, v2);
				}
			}
		}
	}

	public static class UserWeightSumReducer extends ReducerBase {
		private Record k3;
		private Record v3;
		private double inactiveThreshold = 0;

		@Override
		public void setup(TaskContext context) throws IOException {
			k3 = context.createOutputKeyRecord();
			v3 = context.createOutputValueRecord();
			inactiveThreshold = Double.parseDouble(context.getJobConf().get(
					"inactiveThreshold", "0"));
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			HashMap<Integer, double[]> statResults = new HashMap<Integer, double[]>();

			while (values.hasNext()) {
				String[] buckets = values.next().getString(0).split(" ", -1);
				for (String str : buckets) {
					String[] numbers = str.split(":", -1);
					int bucket = Integer.parseInt(numbers[0]);
					if (!statResults.containsKey(bucket)) {
						statResults.put(bucket, new double[numbers.length - 1]);
					}
					for (int k = 1; k < numbers.length; ++k) {
						statResults.get(bucket)[k - 1] += Double
								.parseDouble(numbers[k]);
					}
				}
			}
			// 统计 feature 被点击总数， 滤掉非活跃 feature
			double allClickSum = 0;
			for (double[] weights : statResults.values()) {
				allClickSum += weights[1];
			}
			if (allClickSum < inactiveThreshold) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"inactive_fea").increment(1L);
				return;
			}
			String feaWithType = key.getString(0);
			k3.setString(0, feaWithType.split("\t", -1)[0]);
			if (statResults.size() > 0) {
				StringBuilder builder = new StringBuilder();
				for (int bucket : statResults.keySet()) {
					if (builder.length() > 0) {
						builder.append(" ");
					}
					double[] weights = statResults.get(bucket);
					builder.append(bucket);
					for (int k = 0; k < weights.length; ++k) {
						builder.append(":").append(weights[k]);
					}
				}

				v3.setString(0, feaWithType + "\t" + builder.toString());
				context.write(k3, v3);
			}
		}
	}

	public static class FeaWeightReducer extends ReducerBase {
		private Record result;
		private static final DecimalFormat DF = DataFormatUtil
				.getDefaultDecimalFormater();
		private FeatureWeightCalculator calculator;

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
			calculator = new FeatureWeightCalculator();
			JobConf conf = context.getJobConf();
			calculator.setMinWeight(Double.parseDouble(conf.get("minWeight",
					"0.05")));
			calculator.setMaxWeight(Double.parseDouble(conf.get("maxWeight",
					"1.0")));
			calculator.setUseCtrSmooth(conf.getInt("useCtrSmooth", 0) == 1);
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			ArrayList<String> valueStrs = new ArrayList<String>();

			while (values.hasNext()) {
				Record r = values.next();
				valueStrs.add(r.getString(0));
			}
			// 计算每个term的权重
			HashMap<String, HashMap<Integer, Double>> finalTermWeightMap = calculator
					.calculateFeaWeight(valueStrs);

			// output
			StringBuilder builder = new StringBuilder();
			for (String termWithType : finalTermWeightMap.keySet()) {
				if (finalTermWeightMap.get(termWithType).size() == 0) {
					continue;
				}
				builder.delete(0, builder.length());
				for (int bucket : finalTermWeightMap.get(termWithType).keySet()) {
					if (builder.length() > 0) {
						builder.append(" ");
					}
					builder.append(bucket
							+ ":"
							+ DF.format(finalTermWeightMap.get(termWithType)
									.get(bucket)));
				}
				String[] splits = termWithType.split("\t", -1);
				result.setString(0, splits[0]);// feature_type
				result.setString(1, splits[1]);// feature
				result.setString(2, builder.toString());
				context.write(result);
			}
		}

	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		int reduceTaskNum = 100;
		if (argContainer.getNumReducer() > 0) {
			reduceTaskNum = argContainer.getNumReducer();
		}
		Job job = new Job();
		Pipeline pipeline = Pipeline
				.builder()
				.addMapper(UserWeightSumMapper.class)
				.setOutputKeySchema(
						new Column[] { new Column("k2", OdpsType.STRING) })
				.setOutputValueSchema(
						new Column[] { new Column("v2", OdpsType.STRING) })
				.setOutputKeySortColumns(new String[] { "k2" })
				.setPartitionColumns(new String[] { "k2" })
				.setOutputGroupingColumns(new String[] { "k2" })
				.addReducer(UserWeightSumReducer.class)
				.setNumTasks(reduceTaskNum)
				.setOutputKeySchema(
						new Column[] { new Column("k3", OdpsType.STRING) })
				.setOutputValueSchema(
						new Column[] { new Column("v3", OdpsType.STRING) })
				.addReducer(FeaWeightReducer.class).setNumTasks(reduceTaskNum)
				.setMemoryForJVM(12288).createPipeline();

		job.setPipeline(pipeline);

		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {
				"feature_type", "feature", "weight_click" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());

		MrJobParamSetter.setSplitSize(job, 128L);

		job.set("inactiveThreshold", argContainer.getInactiveThreshold());
		job.setInt("useCtrSmooth", argContainer.getCtrSmooth());
		job.set("minWeight", argContainer.getMinWeight());
		job.set("maxWeight", argContainer.getMaxWeight());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {

		@Parameter(names = "-ctrSmooth", description = "whether use category ctr to smooth term weight")
		private int ctrSmooth = 0;

		@Parameter(names = "-inactiveThreshold", description = "")
		private String inactiveThreshold = "0";

		@Parameter(names = "-minWeight", description = "")
		private String minWeight = "0.05";

		@Parameter(names = "-maxWeight", description = "")
		private String maxWeight = "1.0";

		public int getCtrSmooth() {
			return ctrSmooth;
		}

		public void setCtrSmooth(int ctrSmooth) {
			this.ctrSmooth = ctrSmooth;
		}

		public String getInactiveThreshold() {
			return inactiveThreshold;
		}

		public void setInactiveThreshold(String inactiveThreshold) {
			this.inactiveThreshold = inactiveThreshold;
		}

		public String getMinWeight() {
			return minWeight;
		}

		public void setMinWeight(String minWeight) {
			this.minWeight = minWeight;
		}

		public String getMaxWeight() {
			return maxWeight;
		}

		public void setMaxWeight(String maxWeight) {
			this.maxWeight = maxWeight;
		}

	}
}
