package com.tudou.recommend.up.odps.iflow.video;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.entity.log.MergeLog;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import com.tudou.recommend.up.odps.common.util.UserAccountUtil;
import com.tudou.recommend.up.odps.common.entity.ActionTypes;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.item.RecoItemInfo;
import com.tudou.recommend.up.odps.common.util.LogFilterUtil;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.common.util.UserVideoActionInfoExtractor;

/**
 * 统计用户行为信息
 * 
 * @author zengtao
 *
 */
public class UserVideoActionInfoGenerator {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class UserVideoActionInfoGeneratorMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private String userIdType = "default";
		private String dataIdentity = "";
		private String dateTimeStr = "";

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			JobConf jobConf = context.getJobConf();
			userIdType = jobConf.get("userIdType", "default");
			dataIdentity = jobConf.get("dataIdentity", "");
			dateTimeStr = jobConf.get("dateTimeStr", "");
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			MergeLog mergeLog = new MergeLog();
			if (!mergeLog.parseFromStr(record.getString("log"))) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_map_input").increment(1L);
				return;
			}

			// 过滤无效merge log (item id 非法)
			String itemId = mergeLog.getItemId();
			if (itemId.isEmpty() || "0".equals(itemId)) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"error_item_id").increment(1L);
				return;
			}

			// 根据user id type判断log是否纳入画像统计范围
			if (!LogFilterUtil.isValidMergeLog(mergeLog, userIdType)) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"filtered_by_uid_type").increment(1L);
				return;
			}

			// 生成 profile key
			String profileKey;
			if (userIdType.equalsIgnoreCase("default")) {
				profileKey = DataFormatUtil.GenUserKey(mergeLog.getUserId(),
						mergeLog.getAppName());
			} else {
				if (dataIdentity.isEmpty()) {
					profileKey = UserAccountUtil.generateProfileKey(mergeLog,
							userIdType);
				} else {
					profileKey = UserAccountUtil.generateProfileKey(mergeLog,
							userIdType, dataIdentity);
				}
			}
			if (profileKey == null) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"failed_to_gen_profile_key").increment(1L);
				return;
			}

			k2.setString(0, profileKey + "\t" + dateTimeStr);
			v2.setString(0, record.getString("log"));
			v2.setString(1, record.getString("feature"));
			context.write(k2, v2);
		}
	}

	/**
	 * 统计用户在各个term上的权重
	 * 
	 * @author zengtao
	 *
	 */
	public static class UserVideoActionInfoGeneratorReducer extends ReducerBase {
		private Record result;
		private static final DecimalFormat DF = DataFormatUtil
				.getDefaultDecimalFormater();
		UserVideoActionInfoExtractor extractor = new UserVideoActionInfoExtractor();

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
			JobConf conf = context.getJobConf();

			// read action weight
			HashMap<String, Float> actionWeights = new HashMap<String, Float>();
			actionWeights.put(ActionTypes.RecoClick.getValue().toLowerCase(),
					conf.getFloat("clickWeight", 1.0f));
			actionWeights.put(ActionTypes.Favority.getValue().toLowerCase(),
					conf.getFloat("favoriteWeight", 0));
			actionWeights.put(ActionTypes.Share.getValue().toLowerCase(),
					conf.getFloat("shareWeight", 0));
			actionWeights.put(ActionTypes.Comment.getValue().toLowerCase(),
					conf.getFloat("commentWeight", 0));
			actionWeights.put(ActionTypes.Like.getValue().toLowerCase(),
					conf.getFloat("likeWeight", 0));
			actionWeights.put(ActionTypes.Dislike.getValue().toLowerCase(),
					conf.getFloat("dislikeWeight", 0));
			actionWeights.put(ActionTypes.Agree.getValue().toLowerCase(),
					conf.getFloat("agreeWeight", 0));
			actionWeights.put(ActionTypes.Disagree.getValue().toLowerCase(),
					conf.getFloat("disagreeWeight", 0));
			actionWeights.put(ActionTypes.ChannelPush.getValue().toLowerCase(),
					conf.getFloat("channelPushWeight", 0));
			actionWeights.put(ActionTypes.VideoAutoPlay.getValue()
					.toLowerCase(), conf.getFloat("autoPlayWeight", 1.0f));

			// read video lenght avg read length mapping data
			HashMap<Integer, Float> videoLenAvgPlayMap = new HashMap<Integer, Float>();
			Iterator<Record> readResourceTable = context.readResourceTable(conf
					.get("videoLenAvgPlayLenMappingData"));
			while (readResourceTable.hasNext()) {
				Record r = readResourceTable.next();
				videoLenAvgPlayMap.put(Integer.parseInt(r.getString(0)),
						Float.parseFloat(r.getString(1)));
			}

			// setup action info extractor
			extractor.setActionWeights(actionWeights);
			extractor.setExcludeGlobalDeliveredManualNews(conf.getInt(
					"excludeGlobalDeliveredManualNews", 0) == 1);
			extractor.setReadProgressTuning(conf
					.getInt("readProgressTuning", 0) == 1);
			extractor.setReadLengthTuning(conf
					.getInt("readLengthTuning", 0) == 1);
			extractor.setMinReadProgressThre(conf
					.getFloat("minReadProgress", 0));
			extractor.setMaxReadProgressThre(conf.getFloat("maxReadProgress",
					1.0f));
			extractor.setVideoLenAvgPlayTimeMap(videoLenAvgPlayMap);
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {

			context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "user_id_num")
					.increment(1L);
			// 清除 action info extractor
			extractor.clear();

			String[] keyFlds = key.getString(0).split("\t", -1);
			String userId = keyFlds[0];
			String dateStr = keyFlds[1];

			// 处理用户的merge log
			while (values.hasNext()) {
				Record r = values.next();
				MergeLog mergeLog = new MergeLog();
				if (!mergeLog.parseFromStr(r.getString("log"))) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"error_reduce_input").increment(1L);
					continue;
				}

				RecoItemInfo itemInfo = RecoItemInfo.parse(r
						.getString("feature"));

				if (itemInfo == null) {
					context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
							"failed_to_parse_item_info").increment(1L);
				}

				extractor.process(mergeLog, itemInfo);

			}

			// 统计汇总类指标
			extractor.merge();

			// 滤掉点击次数明显超标的用户
			if (extractor.getClickNum() > 20000
					|| extractor.getPushNum() > 20000) {
				context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
						"too_many_click_push").increment(1L);
				return;
			}

			// output
			// key: appname-userId
			// value: date ~ termType ~ [term::weightSum::clickSum]
			HashMap<Integer, HashMap<String, Float>> weightSumMap = extractor
					.getWeightSumMap();
			HashMap<Integer, HashMap<String, Float>> clickSumMap = extractor
					.getClickSumMap();
			result.setString(0, userId);
			result.setString(1, dateStr);
			StringBuilder sb = new StringBuilder();
			for (int termType : weightSumMap.keySet()) {
				sb.delete(0, sb.length());
				result.setString(2, String.valueOf(termType));
				for (String term : weightSumMap.get(termType).keySet()) {
					float weight = weightSumMap.get(termType).get(term);
					float click = clickSumMap.get(termType).get(term);
					weight = weight < 0 ? 0 : weight;
					click = click < 0 ? 0 : click;
					if (sb.length() > 0) {
						sb.append("\t");
					}
					sb.append(term).append("::").append(DF.format(weight))
							.append("::").append(click);
				}
				result.setString(3, sb.toString());
				context.write(result);
			}
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils
				.fromString("log:string,feature:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {
				"log", "feature" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(UserVideoActionInfoGeneratorMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(UserVideoActionInfoGeneratorReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		//MrJobParamSetter.setSplitSize(job, 128L);

		job.setInt("excludeGlobalDeliveredManualNews",
				argContainer.getExcludeGlobalDeliveredManualNews());
		job.setInt("readProgressTuning", argContainer.getReadProgressTuning());
		job.setInt("readLengthTuning", argContainer.getReadLengthTuning());
		job.setFloat("minReadProgress", argContainer.getMinReadProgress());
		job.setFloat("maxReadProgress", argContainer.getMaxReadProgress());
		job.setFloat("clickWeight", argContainer.getClickWeight());
		job.setFloat("favoriteWeight", argContainer.getFavoriteWeight());
		job.setFloat("shareWeight", argContainer.getShareWeight());
		job.setFloat("commentWeight", argContainer.getCommentWeight());
		job.setFloat("likeWeight", argContainer.getLikeWeight());
		job.setFloat("dislikeWeight", argContainer.getDislikeWeight());
		job.setFloat("agreeWeight", argContainer.getAgreeWeight());
		job.setFloat("disagreeWeight", argContainer.getDisagreeWeight());
		job.setFloat("channelPushWeight", argContainer.getChannelPushWeight());
		job.setFloat("autoPlayWeight", argContainer.getAutoPlayWeight());
		job.set("dateTimeStr", argContainer.getDateTimeStr());
		job.set("userIdType", argContainer.getUserIdType());
		job.set("dataIdentity", argContainer.getDataIdentity());
		job.set("videoLenAvgPlayLenMappingData",
				argContainer.getVideoLenAvgPlayLenMappingData());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-excludeGlobalDeliveredManualNews", description = "whether exclude global delivered manual news from user profile, 1:exclude 0:include")
		private int excludeGlobalDeliveredManualNews = 0;

		@Parameter(names = "-clickWeight", description = "weight of click action")
		private float clickWeight = 1.0f;

		@Parameter(names = "-favoriteWeight", description = "weight of favorite action")
		private float favoriteWeight = 0;

		@Parameter(names = "-shareWeight", description = "weight of share action")
		private float shareWeight = 0;

		@Parameter(names = "-commentWeight", description = "weight of comment action")
		private float commentWeight = 0;

		@Parameter(names = "-likeWeight", description = "weight of like action")
		private float likeWeight = 0;

		@Parameter(names = "-dislikeWeight", description = "weight of dislike action")
		private float dislikeWeight = 0;

		@Parameter(names = "-agreeWeight", description = "weight of agree action")
		private float agreeWeight = 0;

		@Parameter(names = "-disagreeWeight", description = "weight of disagree action")
		private float disagreeWeight = 0;

		@Parameter(names = "-channelPushWeight", description = "weight of channel push")
		private float channelPushWeight = 0;

		@Parameter(names = "-autoPlayWeight", description = "weight of video auto play")
		private float autoPlayWeight = 1.0f;

		@Parameter(names = "-dateTimeStr", description = "")
		private String dateTimeStr = "20160101";

		@Parameter(names = "-readProgressTuning", description = "whether adopt read progress tuning, 1: tuning 0: not tuning")
		private int readProgressTuning = 0;
		
		@Parameter(names = "-readLengthTuning", description = "whether adopt read length tuning, 1: tuning 0: not tuning")
		private int readLengthTuning = 0;

		@Parameter(names = "-minReadProgress", description = "min read progress needed to account an item click")
		private float minReadProgress = 0;

		@Parameter(names = "-maxReadProgress", description = "max read progress needed to account an item click")
		private float maxReadProgress = 1.0f;

		@Parameter(names = "-videoLenAvgPlayLenMappingData", description = "")
		private String videoLenAvgPlayLenMappingData = "videoLenAvgPlayLenMappingData";

		@Parameter(names = "-dataIdentity", description = "data identity, if empty, user app token in merge log")
		private String dataIdentity = "";

		@Parameter(names = "-userIdType", description = "user id/account type: default, uid, uc, uic")
		private String userIdType = "default";

		public MrArgContainer() {
		}

		public int getExcludeGlobalDeliveredManualNews() {
			return excludeGlobalDeliveredManualNews;
		}

		public void setExcludeGlobalDeliveredManualNews(
				int excludeGlobalDeliveredManualNews) {
			this.excludeGlobalDeliveredManualNews = excludeGlobalDeliveredManualNews;
		}

		public float getClickWeight() {
			return clickWeight;
		}

		public void setClickWeight(float clickWeight) {
			this.clickWeight = clickWeight;
		}

		public float getFavoriteWeight() {
			return favoriteWeight;
		}

		public void setFavoriteWeight(float favoriteWeight) {
			this.favoriteWeight = favoriteWeight;
		}

		public float getShareWeight() {
			return shareWeight;
		}

		public void setShareWeight(float shareWeight) {
			this.shareWeight = shareWeight;
		}

		public float getCommentWeight() {
			return commentWeight;
		}

		public void setCommentWeight(float commentWeight) {
			this.commentWeight = commentWeight;
		}

		public float getLikeWeight() {
			return likeWeight;
		}

		public void setLikeWeight(float likeWeight) {
			this.likeWeight = likeWeight;
		}

		public float getDislikeWeight() {
			return dislikeWeight;
		}

		public void setDislikeWeight(float dislikeWeight) {
			this.dislikeWeight = dislikeWeight;
		}

		public float getAgreeWeight() {
			return agreeWeight;
		}

		public void setAgreeWeight(float agreeWeight) {
			this.agreeWeight = agreeWeight;
		}

		public float getDisagreeWeight() {
			return disagreeWeight;
		}

		public void setDisagreeWeight(float disagreeWeight) {
			this.disagreeWeight = disagreeWeight;
		}

		public float getChannelPushWeight() {
			return channelPushWeight;
		}

		public void setChannelPushWeight(float channelPushWeight) {
			this.channelPushWeight = channelPushWeight;
		}

		public String getDateTimeStr() {
			return dateTimeStr;
		}

		public void setDateTimeStr(String dateTimeStr) {
			this.dateTimeStr = dateTimeStr;
		}

		public int getReadLengthTuning() {
			return readLengthTuning;
		}
		public void setReadLengthTuning(int readLengthTuning) {
			this.readLengthTuning = readLengthTuning;
		}
		
		public int getReadProgressTuning() {
			return readProgressTuning;
		}

		public void setReadProgressTuning(int readProgressTuning) {
			this.readProgressTuning = readProgressTuning;
		}

		public String getUserIdType() {
			return userIdType;
		}

		public void setUserIdType(String userIdType) {
			this.userIdType = userIdType;
		}

		public float getAutoPlayWeight() {
			return autoPlayWeight;
		}

		public void setAutoPlayWeight(float autoPlayWeight) {
			this.autoPlayWeight = autoPlayWeight;
		}

		public float getMinReadProgress() {
			return minReadProgress;
		}

		public void setMinReadProgress(float minReadProgress) {
			this.minReadProgress = minReadProgress;
		}

		public float getMaxReadProgress() {
			return maxReadProgress;
		}

		public void setMaxReadProgress(float maxReadProgress) {
			this.maxReadProgress = maxReadProgress;
		}

		public String getVideoLenAvgPlayLenMappingData() {
			return videoLenAvgPlayLenMappingData;
		}

		public void setVideoLenAvgPlayLenMappingData(
				String videoLenAvgPlayLenMappingData) {
			this.videoLenAvgPlayLenMappingData = videoLenAvgPlayLenMappingData;
		}

		public String getDataIdentity() {
			return dataIdentity;
		}

		public void setDataIdentity(String dataIdentity) {
			this.dataIdentity = dataIdentity;
		}

	}
}
