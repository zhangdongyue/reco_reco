package com.tudou.recommend.up.odps.common.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

/**
 * 字符串转义工具类
 * 
 */
public class LineEscape {
  private static boolean isprint(int c) {
    return c >= 32 && c <= 126;
  }

  private static boolean isxdigit(int c) {
    return (47 < c && c < 58) || (64 < c && c < 91) || (96 < c && c < 123);
  }

  private static boolean isoctaldigit(int c) {
    return 47 < c && c < 56;
  }

  private static int hexDigitToInt(int c) {
    if (c > 57) {
      return (c + 9) & 15;
    } else {
      return c & 15;
    }
  }

  private static int digitToHex(int c) {
    if (c > 9) {
      return (int) (c + 87);
    } else {
      return (int) (c + 48);
    }
  }

  private static int ord(char c) {
    return 0x000000FF & (int) c;
  }

  private static char chr(int c) {
    return (char) (0x000000FF & c);
  }

  // private static int unsignize(int i) {
  // return 0x000000FF & i;
  // }

  private static int unsignize(byte i) {
    return 0x000000FF & i;
  }

  private static byte[] listToArray(List<Byte> list) {
    byte[] ret = new byte[list.size()];
    int i = 0;
    for (Byte e : list)
      ret[i++] = e.byteValue();
    return ret;
  }

  /**
   * 转义
   * 
   * @param src
   * @return
   * @throws UnsupportedEncodingException
   */
  public static String escape(String input) throws UnsupportedEncodingException {
    byte[] inputBytes = input.getBytes();
    return new String(escape(inputBytes, inputBytes.length, true, true));
  }

  /**
   * 转义
   * 
   * @param src
   * @return
   * @throws UnsupportedEncodingException
   */
  public static byte[] escape(byte[] inputBytes, int length) throws UnsupportedEncodingException {
    return escape(inputBytes, length, true, true);
  }

  /**
   * 对字符串进行行转义, 将转义结果覆盖到 |result|     
   * 针对存储 key-value 的文本文件设计，     
   * 每行是一对 key-value, 且 key-value 之间用制表符 \t 分割，     
   * 需要保证 key 和 value 本身不能包含一些特殊字符，如 \t, \r, \n 等     
   * 这时候可用该函数对字符串做转义后再写入文件     
   * 该函数的目标是，任意字符串行转义后，都可以作为 key-value 文本文件的字段，     
   * 同时尽量少做转义，使得转义跟原字符串比较接近，便于人工查阅     
   * 
   * 目前只转义这些字节     
   * 1. 换行符号: \n,                                                     
   * 2. 回车符号: \r,
   * 3. 制表符:   \t,
   * 4. 反斜杠:   \\,
   * 5. 不可打印字符: 属于区间 [0, 0x20) 或者等于 0x7F (字符 DEL),
   *                  转义成由 \x 开头的两位 16 进制数
   * NOTE:
   * 如上述，所有大于等于 0x80 (128) 的字节，均不会被转义.这样可以保证 utf-8 编码的字符串不会被转义，便于人工查阅 
   * 
   * @param src
   * @param useHex 使用16进制
   * @param utf8Safe 设为false时把字符串字节数组中>=128的字节转义成\数字，设为true不转换
   * @return
   * @throws UnsupportedEncodingException
   */
  public static byte[] escape(byte[] inputBytes, int length, boolean useHex, boolean utf8Safe)
      throws UnsupportedEncodingException {
    // byte[] inputBytes = src.getBytes("UTF-8");
    ArrayList<Byte> dest = new ArrayList<Byte>();
    for (int i = 0; i < length; i++) {
      int c = unsignize(inputBytes[i]);
      if (c < 0) {
        return null;
      }
      if (c == ord('\n')) {
        dest.add((byte) '\\');
        dest.add((byte) 'n');
      } else if (c == ord('\r')) {
        dest.add((byte) '\\');
        dest.add((byte) 'r');
      } else if (c == ord('\t')) {
        dest.add((byte) '\\');
        dest.add((byte) 't');
      } else if (c == ord('\\')) {
        dest.add((byte) '\\');
        dest.add((byte) '\\');
      } else if ((!utf8Safe || c < 128) && !isprint(c)) {
        dest.add((byte) '\\');
        if (useHex) {
          dest.add((byte) 'x');
          dest.add((byte) digitToHex(c >> 4));
          dest.add((byte) digitToHex(c & 15));
        } else {
          dest.add((byte) ((c >> 6) + 48));
          dest.add((byte) ((c >> 3 & 7) + 48));
          dest.add((byte) ((c & 7) + 48));
        }
      } else {
        dest.add((byte) chr(c));
      }
    }
    return listToArray(dest);
    // return new String(listToArray(dest), "UTF-8");
  }

  private static int flag = 0, tox = 0, too = 0;
  
  public static byte[] unescape(byte[] inputBytes) throws IOException {
    ArrayList<Byte> dest = new ArrayList<Byte>();
    for (int i = 0; i < inputBytes.length; i++) {
      int c = unsignize(inputBytes[i]);
      if (flag == 0) {
        if (c != ord('\\')) {
          dest.add((byte) c);
        } else {
          flag = 1;
        }
      } else if (flag == 1) {
        flag = 0;
        // NOTE: 为了兼容 cescape, 这里多支持了一些转义序列,这样之前用 cescape 转义结果，也可以用 line unescape 来解析
        if (c == ord('a')) {
          dest.add((byte) 0x7);
        } else if (c == ord('b')) {
          dest.add((byte) '\b');
        } else if (c == ord('f')) {
          dest.add((byte) '\f');
        } else if (c == ord('n')) {
          dest.add((byte) '\n');
        } else if (c == ord('r')) {
          dest.add((byte) '\r');
        } else if (c == ord('t')) {
          dest.add((byte) '\t');
        } else if (c == ord('v')) {
          dest.add((byte) 0xB);
        } else if (c == ord('?')) {
          dest.add((byte) 0x3F);
        } else if (c == ord('\'')) {
          dest.add((byte) '\'');
        } else if (c == ord('\"')) {
          dest.add((byte) '"');
        } else if (c == ord('\\')) {
          dest.add((byte) '\\');
        } else if (c == ord('x') || c == ord('X')) {
          flag = 2;
        } else {
          if (isoctaldigit(c)) {
            too = c & 15;
            flag = 4;
          } else {
            flag = -1;
          }
        }
      } else if (flag == 2) {
        if (isxdigit(c)) {
          tox = hexDigitToInt(c);
          flag = 3;
        } else {
          flag = -1;
        }
      } else if (flag == 3) {
        if (isxdigit(c)) {
          tox = (tox << 4) | hexDigitToInt(c);
          dest.add((byte) chr(tox));
          flag = 0;
        } else {
          flag = -1;
        }
      } else if (flag == 4) {
        if (isoctaldigit(c)) {
          flag = 5;
          too = (too << 3) | (c & 15);
        } else {
          flag = -1;
        }
      } else if (flag == 5) {
        if (isoctaldigit(c)) {
          flag = 0;
          too = (too << 3) | (c & 15);
          dest.add((byte) chr(too));
        } else {
          flag = -1;
        }
      } else {
        throw new IOException("bad format" + flag + " " + i);
      }
    }
    return listToArray(dest);
  }
  /**
   * 反转义
   * 
   * @param src
   * @return
   * @throws IOException
   */
  public static String unescape(String input) throws IOException {
    return new String(unescape(input.getBytes()));
  }
  public static void main(String[] args) {
    System.out.println((int)'\7');
  }
}
