package com.tudou.recommend.up.odps.common;

import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.google.common.base.Charsets;
import com.google.protobuf.ByteString;
import com.tudou.recommend.proto.ProtoDictServer;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.kafka.KafkaProducer;
import com.tudou.recommend.up.odps.common.kafka.KafkaProducerBuilder;
import com.tudou.recommend.up.odps.common.util.BaseArgContainer;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.Future;

/**
 * Created by lvhl on 2017/8/12.
 */
public class DictServerKafkaMrWriter {
    public static MrArgContainer argContainer = new MrArgContainer();

    public static class DataMapper extends MapperBase {
        private Set<String> allowedAppNames = new HashSet<String>();
        private Record outputKey;
        private Record outputValue;
        private double sampleRate;
        private String keyColumn;
        private String valueColumn;

        @Override
        public void setup(TaskContext context) throws IOException {
            JobConf jobConf = context.getJobConf();
            String allowedAppNames = jobConf.get("allowedAppName", "");
            keyColumn = jobConf.get("key.column");
            valueColumn = jobConf.get("value.column");
            String[] apps = allowedAppNames.split(",", -1);
            for (String appName : apps) {
                if (!appName.trim().isEmpty()) {
                    this.allowedAppNames.add(appName.trim());
                }
            }
            outputKey = context.createMapOutputKeyRecord();
            outputValue = context.createMapOutputValueRecord();
            sampleRate = jobConf.getFloat("sampleRate", 1.0f);
        }

        @Override
        public void map(long key, Record record, TaskContext context) throws IOException {
            if (Math.random() <= sampleRate) {
                String profileKey = record.getString(keyColumn);
                String profile = record.getString(valueColumn);

                if (profileKey.isEmpty() || profile.isEmpty()) {
                    return;
                }
                outputKey.setString("profile_key", profileKey);
                outputValue.setString("profile", profile);
                context.write(outputKey, outputValue);
            }
        }
    }

    public static class DataReducer extends ReducerBase {
        private static final Logger logger = LoggerFactory.getLogger(DataReducer.class);
        private boolean debug;
        private Integer batchSize;
        // kafka
        private String kafkaBroker;
        private String kafkaTopic;
        private int partitionBegin;
        private int partitionEnd;
        private String productName;
        private String version;
        private KafkaProducer<byte[]> kafkaProducer;

        // qps控制
        private int sleepMs = 0;
        private int qpsOutputFreq = 10000;
        private long startTime;
        private long currentTime;
        private int dataNum;

        private Record output;
        private List<Future<RecordMetadata>> buffer = new ArrayList<>();

        private boolean initKafkaProducer() {
            KafkaProducerBuilder kafkaBuilder = KafkaProducerBuilder.custom();
            kafkaBuilder.setBrokerList(kafkaBroker);
            kafkaProducer = kafkaBuilder.build();
            return true;
        }


        @Override
        public void setup(TaskContext context) throws IOException {
            JobConf jobConf = context.getJobConf();
            debug = jobConf.getBoolean("debug", false);
            kafkaBroker = jobConf.get("kafkaBroker");
            kafkaTopic = jobConf.get("kafkaTopic");
            productName = jobConf.get("productName");
            version = jobConf.get("version");
            partitionBegin = jobConf.getInt("kafkaPartitionBegin", 0);
            partitionEnd = jobConf.getInt("kafkaPartitionEnd", 60);
            batchSize = jobConf.getInt("batchSize", 1);
            if (!initKafkaProducer()) {
                throw new IOException("Cannot init kafka producer.");
            }
            if (partitionBegin < 0 || partitionEnd < 0 || partitionEnd - partitionBegin <= 0) {
                throw new IOException("Partition begin or end assigned error.");
            }

            startTime = System.currentTimeMillis();
            dataNum = 0;
            sleepMs = jobConf.getInt("sleepMs", 0);
            qpsOutputFreq = jobConf.getInt("qpsOutputFreq", 10000);
            output = context.createOutputRecord();
        }

        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
            String profileKey = key.getString("profile_key");
            while (values.hasNext()) {
                Record value = values.next();
                String itemList = value.getString("profile");
                ProtoDictServer.KeyElements.Builder keyElementBuilder = ProtoDictServer.KeyElements.newBuilder();
                keyElementBuilder.setKey(ByteString.copyFromUtf8(profileKey));
                keyElementBuilder.setProduct(ByteString.copyFromUtf8(productName));
                keyElementBuilder.setVersion(ByteString.copyFromUtf8(version));
                ProtoDictServer.SetDataRequest.Builder msgBuilder = ProtoDictServer.SetDataRequest.newBuilder();
                msgBuilder.setKeyElements(keyElementBuilder.build());
                msgBuilder.setValue(ByteString.copyFromUtf8(itemList));
                byte[] valueBytes = msgBuilder.build().toByteArray();
                // write to kafka
                int partition = Math.abs(profileKey.hashCode()) % (partitionEnd - partitionBegin) + partitionBegin;
                try {
                    if (batchSize <= 1) {
                        kafkaProducer.send(kafkaTopic, profileKey, valueBytes);
                        context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "kafka_write_success").increment(1L);
                    } else {
                        buffer.add(kafkaProducer.asyncSend(kafkaTopic, profileKey, valueBytes));
                        if (buffer.size() >= batchSize) {
                            for (Future<RecordMetadata> future : buffer) {
                                try {
                                    future.get();
                                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "kafka_write_success").increment(1L);
                                } catch (Exception e) {
                                    logger.info("get future result error.", e);
                                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "kafka_write_failed").increment(1L);
                                }
                            }
                            logger.info("batch send kafka message with size:{}", buffer.size());
                            buffer.clear();
                        }
                    }
                    if (debug) {
                        output.setString("profile_key", profileKey);
                        output.setString("profile", itemList);
                        context.write(output);
                    }
                } catch (Exception e) {
                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "kafka_write_failed").increment(1L);
                    logger.error("failed to write kafka: topic={}, partition={}, key={}, value={}",
                            kafkaBroker, partition, profileKey, new String(valueBytes, Charsets.ISO_8859_1));
                    logger.error("send kafka message error.", e);
                }
                // qps control
                dataNum++;
                if (dataNum % qpsOutputFreq == 0) {
                    currentTime = System.currentTimeMillis();
                    double time = (currentTime - startTime) / 1000.0;
                    double qps = dataNum / time;
                    logger.info("## dataNum={}, seconds={}, qps={}", dataNum, time, qps);
                }
                if (sleepMs > 0) {
                    try {
                        Thread.sleep(sleepMs);
                    } catch (InterruptedException e) {
                        logger.error("interrupted exception.", e);
                    }
                }
            }

        }

        @Override
        public void cleanup(TaskContext context) throws IOException {
            if (batchSize > 1 && buffer.size() > 0) {
                try {
                    for (Future<RecordMetadata> future : buffer) {
                        future.get();
                        context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "kafka_write_success").increment(1L);
                    }
                    logger.info("batch send kafka message with size:{}", buffer.size());
                } catch (Exception e) {
                    logger.error("Get future result error.", e);
                } finally {
                    buffer.clear();
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        JCommander commander = new JCommander(argContainer);
        commander.parse(args);
        Job job = new Job();
        job.set("kafkaBroker", argContainer.getKafkaBroker());
        job.set("kafkaTopic", argContainer.getKafkaTopic());
        job.setInt("kafkaPartitionBegin", argContainer.getKafkaPartitionBegin());
        job.setInt("kafkaPartitionEnd", argContainer.getKafkaPartitionEnd());
        job.setInt("rowKeyIndex", argContainer.getRowKeyIndex());
        job.setInt("dataIndex", argContainer.getDataIndex());
        job.set("writeModel", argContainer.getWriteModel());
        job.setInt("batchSize", argContainer.getBatchSize());
        job.set("productName", argContainer.getProductName());
        job.set("version", argContainer.getVersion());
        job.setInt("sleepMs", argContainer.getSleepMs());
        job.setInt("qpsOutputFreq", argContainer.getQpsOutputFreq());
        job.set("key.column", argContainer.getKeyColumn());
        job.set("value.column", argContainer.getValueColumn());
        if (argContainer.getAllowedAppName() != null) {
            job.set("allowedAppName", argContainer.getAllowedAppName());
        }
        job.setFloat("sampleRate", argContainer.getSampleRate());
        job.setBoolean("debug", argContainer.isDebug());

        job.setMapperClass(DataMapper.class);
        job.setReducerClass(DataReducer.class);
        job.setMapOutputKeySchema(SchemaUtils.fromString("profile_key:string"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("profile:string"));

        MrJobParamSetter.addInput(job, argContainer.getInput(),
                new String[]{argContainer.getKeyColumn(),argContainer.getValueColumn()});
        MrJobParamSetter.addOutput(job, argContainer.getOutput());

        job.waitForCompletion();
        System.exit(job.isSuccessful() == true ? 0 : 1);
    }

    public static class MrArgContainer extends BaseArgContainer {
        @Parameter(names = "-kafkaBroker", description = "kafka brokers")
        private String kafkaBroker = "";

        @Parameter(names = "-kafkaTopic", description = "kafka topic")
        private String kafkaTopic = "_test";

        @Parameter(names = "-kafkaPartitionBegin", description = "start kafka partition index")
        private int kafkaPartitionBegin = 0;

        @Parameter(names = "-kafkaPartitionEnd", description = "end kafka partition index")
        private int kafkaPartitionEnd = 50;

        @Parameter(names = "-rowKeyIndex", description = "")
        private int rowKeyIndex = 0;

        @Parameter(names = "-dataIndex", description = "")
        private int dataIndex = 1;

        @Parameter(names = "-writeModel", description = "hbase write model: single, batch")
        private String writeModel = "single";

        @Parameter(names = "-batchSize", description = "")
        private int batchSize = 1;

        @Parameter(names = "-productName", description = "dict product name")
        private String productName = "YTU2ISwing";

        @Parameter(names = "-productVersion", description = "dict data version")
        private String version = "1";

        @Parameter(names = "-sleepMs", description = "")
        private int sleepMs = 0;

        @Parameter(names = "-qpsOutputFreq", description = "")
        private int qpsOutputFreq = 10000;

        @Parameter(names = "-dataConvert",
                description = "convert data before writing to hbase: escape, unescape, none")
        private String dataConvert;

        @Parameter(names = "-allowedAppName", description = "allowed app names")
        private String allowedAppName;

        @Parameter(names = "-sampleRate", description = "test sample rate.")
        private Float sampleRate;

        @Parameter(names = "-generatorClass", description = "generatorClass")
        private String generatorClass;

        @Parameter(names = "-keyColumn")
        private String keyColumn = "userid";

        @Parameter(names = "-valueColumn")
        private String valueColumn = "item_list";

        public String getKeyColumn() {
            return keyColumn;
        }

        public void setKeyColumn(String keyColumn) {
            this.keyColumn = keyColumn;
        }

        public String getValueColumn() {
            return valueColumn;
        }

        public void setValueColumn(String valueColumn) {
            this.valueColumn = valueColumn;
        }

        public String getGeneratorClass() {
            return generatorClass;
        }

        public void setGeneratorClass(String generatorClass) {
            this.generatorClass = generatorClass;
        }

        public Float getSampleRate() {
            return sampleRate;
        }

        public void setSampleRate(Float sampleRate) {
            this.sampleRate = sampleRate;
        }

        public String getKafkaBroker() {
            return kafkaBroker;
        }

        public void setKafkaBroker(String kafkaBroker) {
            this.kafkaBroker = kafkaBroker;
        }

        public String getKafkaTopic() {
            return kafkaTopic;
        }

        public void setKafkaTopic(String kafkaTopic) {
            this.kafkaTopic = kafkaTopic;
        }

        public int getKafkaPartitionBegin() {
            return kafkaPartitionBegin;
        }

        public void setKafkaPartitionBegin(int kafkaPartitionBegin) {
            this.kafkaPartitionBegin = kafkaPartitionBegin;
        }

        public int getKafkaPartitionEnd() {
            return kafkaPartitionEnd;
        }

        public void setKafkaPartitionEnd(int kafkaPartitionEnd) {
            this.kafkaPartitionEnd = kafkaPartitionEnd;
        }

        public String getWriteModel() {
            return writeModel;
        }

        public void setWriteModel(String writeModel) {
            this.writeModel = writeModel;
        }

        public int getBatchSize() {
            return batchSize;
        }

        public void setBatchSize(int batchSize) {
            this.batchSize = batchSize;
        }

        public String getProductName() {
            return productName;
        }

        public void setProductName(String productName) {
            this.productName = productName;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public int getRowKeyIndex() {
            return rowKeyIndex;
        }

        public void setRowKeyIndex(int rowKeyIndex) {
            this.rowKeyIndex = rowKeyIndex;
        }

        public int getDataIndex() {
            return dataIndex;
        }

        public void setDataIndex(int dataIndex) {
            this.dataIndex = dataIndex;
        }


        public int getSleepMs() {
            return sleepMs;
        }

        public void setSleepMs(int sleepMs) {
            this.sleepMs = sleepMs;
        }

        public int getQpsOutputFreq() {
            return qpsOutputFreq;
        }

        public void setQpsOutputFreq(int qpsOutputFreq) {
            this.qpsOutputFreq = qpsOutputFreq;
        }

        public String getDataConvert() {
            return dataConvert;
        }

        public void setDataConvert(String dataConvert) {
            this.dataConvert = dataConvert;
        }

        public String getAllowedAppName() {
            return allowedAppName;
        }

        public void setAllowedAppName(String allowedAppName) {
            this.allowedAppName = allowedAppName;
        }

    }
}
