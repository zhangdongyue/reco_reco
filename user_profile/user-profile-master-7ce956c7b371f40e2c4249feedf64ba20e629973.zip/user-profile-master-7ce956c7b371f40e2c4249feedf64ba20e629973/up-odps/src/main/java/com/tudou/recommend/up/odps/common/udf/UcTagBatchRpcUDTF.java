package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.ExecutionContext;
import com.aliyun.odps.udf.UDFException;
import com.aliyun.odps.udf.UDTF;
import com.aliyun.odps.utils.StringUtils;
import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.tudou.recommend.proto.ProtoCommon;
import com.tudou.recommend.proto.ProtoConvertorServer;
import com.wolong.protorpc.client.pool.PooledRpcClient;
import com.wolong.protorpc.client.protobuf.DefaultBlockingRpcChannel;
import com.wolong.protorpc.model.DefaultRpcController;
import com.wolong.protorpc.model.RpcClientConf;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.log4j.Logger;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Wangfei on 2017/4/20.
 */
public class UcTagBatchRpcUDTF extends UDTF {
    private Logger logger = Logger.getLogger(this.getClass());
    private ProtoConvertorServer.ConvertorService.BlockingInterface convertService;
    private PooledRpcClient rpcClient;
    private String na62Addresses = "11.173.174.158:20021,11.173.176.165:20021,11.173.187.243:20021";
    private String na61Addresses = "11.139.111.73:20021,11.139.111.75:20021,11.139.111.77:20021";
    private int timeout = 2000;
    private int count = 0;
    private int retry = 5;
    private Map<String, Object[]> requestBuffer = new LinkedHashMap<>();

    @Override
    public void setup(ExecutionContext ctx) throws UDFException {
        try {
            super.setup(ctx);
            initClient();
        } catch (Exception e) {
            throw new UDFException(e);
        }
    }

    public String inputValue(Object[] args, int index) {
        if (index < args.length) {
            if (args[index] != null) {
                return args[index].toString();
            }
        }
        return null;
    }

    @Override
    public void process(Object[] args) throws UDFException {
        count++;
        int batchSize = Integer.parseInt(args[1].toString());
        int length = Integer.parseInt(args[0].toString());
        int begin = length + 3;
        String title = inputValue(args, begin + 0);
        if (title == null) {
            forward(formatOutput(args, null));
        } else {
            requestBuffer.put(title, args);
            if (requestBuffer.size() >= batchSize) {
                batchRequest();
                requestBuffer.clear();
            }
        }

    }

    public ProtoConvertorServer.ExtractFeatureRequest parseRequest(Object[] args) {
        int length = Integer.parseInt(args[0].toString());
        int begin = length + 3;
        String title = inputValue(args, begin + 0);
        String content = inputValue(args, begin + 1);
        String category = inputValue(args, begin + 2);
        String itemType = inputValue(args, begin + 3);
        String source = inputValue(args, begin + 4);

        ProtoConvertorServer.ExtractFeatureRequest.Builder builder = ProtoConvertorServer
                .ExtractFeatureRequest
                .newBuilder();
        builder.setReturnCategory(true)
                .setReturnTag(true);
        builder.setTitle(title);
        if (content != null) {
            builder.setContent(content);
        }
        if (source != null) {
            builder.setSource(source);
        }
        if (itemType != null) {
            int type = Integer.parseInt(itemType);
            builder.setItemType(ProtoCommon.ItemType.valueOf(type));
        } else {
            builder.setItemType(ProtoCommon.ItemType.kPureVideo);
        }
        if (category != null) {
            builder.addCategory(category);
        }
        ProtoConvertorServer.ExtractFeatureRequest request = builder.build();
        return request;
    }

    public Object[] formatOutput(Object[] args, ProtoConvertorServer.ExtractFeatureResponse response) throws UDFException {
        int length = Integer.parseInt(args[0].toString());
        Object[] output = new Object[length + 2];
        for (int i = 0; i < length; i++) {
            output[i] = args[i + 3];
        }
        String splitter = inputValue(args, 2);
        if (response == null || !response.getSuccess()) {
            logger.error("the null response result's key is :" + output[0]);
        } else {
            List<String> tagList = response.getTagsList();
            String tagResult = null;
            if (tagList != null) {
                List<String> tags = Lists.transform(tagList, new Function<String, String>() {
                    @Override
                    public String apply(String s) {
                        return s.substring(s.indexOf(":") + 1, s.length());
                    }
                });
                tagResult = Joiner.on(splitter).join(tags).trim();
            }

            List<String> categoryList = response.getCategoryList();
            String categoriesResult = null;
            if (categoryList != null) {
                List<String> categories = Lists.transform(categoryList, new Function<String, String>() {
                    @Override
                    public String apply(String s) {
                        return s.substring(s.indexOf(":") + 1, s.length());
                    }
                });
                categoriesResult = Joiner.on(splitter).join(categories).trim();
            }
            output[length] = StringUtils.isEmpty(tagResult) ? null : tagResult;
            output[length + 1] = StringUtils.isEmpty(categoriesResult) ? null : categoriesResult;
        }
        return output;
    }

    public void batchRequest() throws UDFException {
        StopWatch watch = new StopWatch();
        watch.start();
        ProtoConvertorServer.BatchExtractFeatureRequest.Builder builder = ProtoConvertorServer
                .BatchExtractFeatureRequest
                .newBuilder();
        List<ProtoConvertorServer.ExtractFeatureRequest> requestList = Lists.transform(
                Lists.newArrayList(requestBuffer.values()),
                new Function<Object[], ProtoConvertorServer.ExtractFeatureRequest>() {
                    @Override
                    public ProtoConvertorServer.ExtractFeatureRequest apply(Object[] objects) {
                        return parseRequest(objects);
                    }
                });
        builder.addAllExtractFeatureRequests(requestList);
        ProtoConvertorServer.BatchExtractFeatureRequest batchRequest = builder.build();
        ProtoConvertorServer.BatchExtractFeatureResponse batchResponse = null;
        DefaultRpcController controller = new DefaultRpcController();
        for (int i = 0; i < 3; i++) {
            try {
                logger.error("request size is " + requestList.size());
                batchResponse = convertService.batchExtractFeature(controller, batchRequest);
                watch.stop();
                logger.error("spend " + watch.getTime() + " ms to send request " + count);
                break;
            } catch (Exception e) {
                closeRpcClient();
                initClient();
                continue;
            }
        }
        if (batchResponse != null) {
            List<String> titleList = batchResponse.getTitlesList();
            List<ProtoConvertorServer.ExtractFeatureResponse> responseList = batchResponse.getExtractFeatureResponsesList();
            logger.error("response size is:" + titleList.size());
            for (int i = 0; i < titleList.size(); i++) {
                Object[] passInArgs = requestBuffer.get(titleList.get(i));
                ProtoConvertorServer.ExtractFeatureResponse responseValue = responseList.get(i);
                forward(formatOutput(passInArgs, responseValue));
            }
        }
    }

    @Override
    public void close() throws UDFException {
        if (requestBuffer.size() > 0) {
            batchRequest();
            requestBuffer.clear();
        }
        super.close();
        closeRpcClient();
    }

    public void initClient() {
        for (int i = 0; i < retry; i++) {
            try {
                RpcClientConf conf = new RpcClientConf(na61Addresses + "," + na62Addresses,
                        timeout, -1);
                conf.setvNodeNum(2048);
                conf.setMinActives(1);
                conf.setEnableHA(true);
                rpcClient = new PooledRpcClient(conf);
                rpcClient.bootstrap();
                convertService = ProtoConvertorServer.ConvertorService
                        .newBlockingStub(new DefaultBlockingRpcChannel(rpcClient));
                break;
            } catch (Exception e) {
                if (rpcClient != null) {
                    try {
                        rpcClient.stop();
                    } catch (Exception e1) {
                        logger.error("Get error trying to stop rpc client", e1);
                        if (i == (retry - 1)) {
                            throw e1;
                        }
                    }
                }
            }
        }
    }

    public void closeRpcClient() {
        for (int i = 0; i < retry; i++) {
            if (rpcClient != null && !rpcClient.isStopped()) {
                rpcClient.stop();
                break;
            }
        }
    }
}
