package com.tudou.recommend.up.odps.common.util;

import org.apache.log4j.Logger;

import com.aliyun.odps.data.TableInfo;
import com.aliyun.odps.mapred.Job;

/**
 * MR任务参数设置器
 */
public class MrJobParamSetter {
	private static Logger logger = Logger.getLogger(MrJobParamSetter.class);

	/**
	 * 设置map task并行度
	 * 
	 * @param job
	 */
	public static void setNumMapTasks(Job job, int num) {
		job.setNumMapTasks(num);
	}

	/**
	 * 设置reduce task并行度
	 * 
	 * @param job
	 */
	public static void setNumReduceTasks(Job job, int num) {
		job.setNumReduceTasks(num);
	}

	/**
	 * 设置输入分片大小，控制map task并行度
	 * 
	 * @param job
	 * @param sizeM
	 */
	public static void setSplitSize(Job job, long sizeM) {
		job.setSplitSize(sizeM);
	}

	/**
	 * 添加输入路径，多路径间以逗号分隔
	 * 
	 * @param job
	 * @param pathStr
	 * @param columns
	 */
	public static void addInput(Job job, String pathStr, String[] columns) {
		if (job == null || pathStr == null) {
			return;
		}
		String[] inputPaths = pathStr.split(",", -1);
		for (String in : inputPaths) {
			String[] ss = in.split("\\|", -1);
			if (ss.length == 1) {
				job.addInput(TableInfo.builder().tableName(ss[0]).cols(columns)
						.build());
			} else if (ss.length == 2) {
				job.addInput(TableInfo.builder().tableName(ss[0])
						.partSpec(ss[1]).cols(columns).build());
			} else {
				logger.error("Style of input: " + in + " is not right");
				System.exit(1);
			}
		}
	}

	/**
	 * 添加输入路径，多路径间以逗号分隔
	 * 
	 * @param job
	 * @param pathStr
	 */
	public static void addInput(Job job, String pathStr) {
		if (job == null || pathStr == null) {
			return;
		}
		String[] inputPaths = pathStr.split(",", -1);
		for (String in : inputPaths) {
			String[] ss = in.split("\\|", -1);
			if (ss.length == 1) {
				job.addInput(TableInfo.builder().tableName(ss[0]).build());
			} else if (ss.length == 2) {
				job.addInput(TableInfo.builder().tableName(ss[0])
						.partSpec(ss[1]).build());
			} else {
				logger.error("Style of input: " + in + " is not right");
				System.exit(1);
			}
		}
	}

	/**
	 * 添加输出路径
	 * 
	 * @param job
	 * @param pathStr
	 */
	public static void addOutput(Job job, String pathStr) {
		if (job == null || pathStr == null) {
			return;
		}
		String[] outputs = pathStr.split(",", -1);
		for (String out : outputs) {
			String[] ss = out.split("\\|", -1);
			if (ss.length == 1) {
				job.addOutput(TableInfo.builder().tableName(ss[0]).build());
			} else if (ss.length == 2) {
				job.addOutput(TableInfo.builder().tableName(ss[0])
						.partSpec(ss[1]).build());
			} else if (ss.length == 3) {
				job.addOutput(TableInfo.builder().tableName(ss[0])
						.partSpec(ss[1]).label(ss[2]).build());
			} else {
				logger.error("Style of output: " + out + " is not right");
				System.exit(1);
			}
		}
	}

	/**
	 * 添加资源文件
	 * 
	 * @param job
	 * @param resourceFileName
	 */
	public static void addResource(Job job, String resourceFileName) {
		if (job == null || resourceFileName == null
				|| resourceFileName.isEmpty()) {
			return;
		}
		job.set("import.resources", resourceFileName);
	}

}
