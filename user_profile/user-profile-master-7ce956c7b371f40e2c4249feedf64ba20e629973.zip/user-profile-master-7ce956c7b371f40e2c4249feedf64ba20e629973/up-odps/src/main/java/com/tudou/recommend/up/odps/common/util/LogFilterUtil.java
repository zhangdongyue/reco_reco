package com.tudou.recommend.up.odps.common.util;

import com.tudou.recommend.up.odps.common.entity.ProfileDeviceIdentity;
import com.tudou.recommend.up.odps.common.entity.log.ClickLog;
import com.tudou.recommend.up.odps.common.entity.log.MergeLog;
import com.tudou.recommend.up.odps.common.entity.ProfileAcountIdentity;
import com.tudou.recommend.up.odps.common.entity.UserAccountInfo;

/**
 * log 过滤，判断log是否纳入画像统计范围
 * 
 * @author hezhimin
 *
 */
public class LogFilterUtil {

  /**
   * 是否有效merger log
   * @param mergeLog merge log
   * @param userIdType 用户ID类别
   * @return
   */
  public static boolean isValidMergeLog(MergeLog mergeLog, String userIdType) {
    if (mergeLog == null || userIdType == null)
      return false;
    if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.XSS_USER_ID)) {
      // xss user id
      String userId = mergeLog.getUserId();
      if (userId.isEmpty() || userId.equals("0")) {
        return false;
      } else {
        return true;
      }
    } else if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.UTDID)) {
      // utdid
      String utdid = mergeLog.getUtdid();
      if (utdid.isEmpty() || utdid.equals("0")) {
        return false;
      } else {
        return true;
      }
    } else if (userIdType.equalsIgnoreCase(ProfileAcountIdentity.UC)) {
      // uc account
      UserAccountInfo account = UserAccountInfo.parseFromJson(mergeLog.getAccountInfo());
      if (account == null || account.ucAccount == null || account.ucAccount.isEmpty() || account.accountType == null
          || !account.accountType.equalsIgnoreCase("uc")) {
        return false;
      } else {
        return true;
      }
    } else if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.ICLOUD_ID)) {
      // icloud id
      UserAccountInfo account = UserAccountInfo.parseFromJson(mergeLog.getAccountInfo());
      if (account == null || account.icloudAccount == null || account.icloudAccount.isEmpty()) {
        return false;
      } else {
        return true;
      }
    } else if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.IMEI_OR_IDFA)) {
      // imei / idfa
      String imei = mergeLog.getImei();
      if (imei.isEmpty()) {
        return false;
      } else {
        return true;
      }
    } else {
      // 默认 appName-userId
      String userId = mergeLog.getUserId();
      String appName = UserAccountUtil.convertAppName(mergeLog.getAppName());
      if (userId.isEmpty() || userId.equals("0") || !DataFormatUtil.isValidAppName(appName)) {
        return false;
      } else {
        return true;
      }
    }
  }

  public static boolean isValidMergeLog(MergeLog mergeLog) {
    return isValidMergeLog(mergeLog, ProfileDeviceIdentity.XSS_USER_ID);
  }

  /**
   * 是否有效click log
   * @param clickLog
   * @param userIdType
   * @return
   */
  public static boolean isValidClickLog(ClickLog clickLog, String userIdType) {
    if (clickLog == null || userIdType == null)
      return false;
    if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.XSS_USER_ID)) {
      // xss user id
      String userId = clickLog.getUserId();
      if (userId.isEmpty() || userId.equals("0")) {
        return false;
      } else {
        return true;
      }
    } else if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.UTDID)) {
      // utdid
      String utdid = clickLog.getUtdid();
      if (utdid.isEmpty() || utdid.equals("0")) {
        return false;
      } else {
        return true;
      }
    } else if (userIdType.equalsIgnoreCase(ProfileAcountIdentity.UC)) {
      // uc account
      String accountType = clickLog.getAcpfType();
      String ucAccount = clickLog.getTacid();
      if (ucAccount == null || ucAccount.isEmpty() || accountType == null || !accountType.equalsIgnoreCase("uc")) {
        return false;
      } else {
        return true;
      }
    } else if (userIdType.equalsIgnoreCase(ProfileDeviceIdentity.ICLOUD_ID)) {
      // icloud id
      String icloudAccount = clickLog.getTuicid();
      if (icloudAccount == null || icloudAccount.isEmpty()) {
        return false;
      } else {
        return true;
      }
    } else {
      // 默认 appName-userId
      String userId = clickLog.getUserId();
      String appName = UserAccountUtil.convertAppName(clickLog.getAppName());
      if (userId.isEmpty() || userId.equals("0") || !DataFormatUtil.isValidAppName(appName)) {
        return false;
      } else {
        return true;
      }
    }
  }

  public static boolean isValidClickLog(ClickLog clickLog) {
    return isValidClickLog(clickLog, ProfileDeviceIdentity.XSS_USER_ID);
  }

}
