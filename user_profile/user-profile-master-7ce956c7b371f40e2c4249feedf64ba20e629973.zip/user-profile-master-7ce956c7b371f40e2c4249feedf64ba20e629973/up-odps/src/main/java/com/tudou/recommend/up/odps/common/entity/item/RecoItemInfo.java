package com.tudou.recommend.up.odps.common.entity.item;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.aliyun.odps.data.Record;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;

/**
 * 从hbase中dump出的reco item信息进行二次封装，方便后续使用
 * item的特征信息均以ItemFeature 对象封装
 *
 */
public class RecoItemInfo {
  
  /**
   * item id
   */
  public String itemId = null;
  
  /**
   * item type
   */
  public String itemType = null;
  
  /**
   * 是否是全量运营新闻，0：不是， 1：是
   */
  public int isGlobalManualNews = 0;
  
  /**
   * 资源类型：文本、视频、自媒体、问啊、段子
   */
  public ItemFeature resourceType = null;
  
  /**
   * item深度：深度、通识、大众
   */
  public ItemFeature itemDepth = null;
  
  /**
   * 阅读类型：精品、热门、资讯、专题、直播
   */
  public ItemFeature readingType = null;
  
  /**
   * 文本长度
   */
  public ItemFeature textLength = null;
  
  /**
   * 视频长度
   */
  public ItemFeature videoLength = null;
  
  /**
   * 是否标题党
   */
  public ItemFeature isBluffingTitle = null;
  
  /**
   * 是否政治敏感
   */
  public ItemFeature isPolitics = null;
  
  /**
   * 是否色情
   */
  public ItemFeature isDirty = null;
  
  /**
   * 种子源
   */
  public ArrayList<ItemFeature> itemSource = new ArrayList<ItemFeature>();
  
  /**
   * category列表
   */
  public ArrayList<ItemFeature> categories = new ArrayList<ItemFeature>();
  
  /**
   * tag列表
   */
  public ArrayList<ItemFeature> tags = new ArrayList<ItemFeature>();
  
  /**
   * event tag列表
   */
  public ArrayList<ItemFeature> eventTags = new ArrayList<ItemFeature>();
  
  /**
   * keyword列表
   */
  public ArrayList<ItemFeature> keywords = new ArrayList<ItemFeature>();
  
  /**
   * topic列表
   */
  public ArrayList<ItemFeature> topics = new ArrayList<ItemFeature>();
  
  /**
   * plsa topic列表
   */
  public ArrayList<ItemFeature> plsaTopics = new ArrayList<ItemFeature>();
  
  /**
   * title lda topic列表
   */
  public ArrayList<ItemFeature> titleLdaTopics = new ArrayList<ItemFeature>();
  
  /**
   * 视频category列表
   */
  public ArrayList<ItemFeature> videoCategories = new ArrayList<ItemFeature>();
  
  /**
   * 视频tag列表 
   */
  public ArrayList<ItemFeature> videoTags = new ArrayList<ItemFeature>();
  
  /**
   * 地域列表
   */
  public ArrayList<ItemFeature> regions = new ArrayList<ItemFeature>();
  /**
   * 种子源
   */
  public ArrayList<ItemFeature> videoSource = new ArrayList<ItemFeature>();
  
  /**
   * 种子源上传者职业
   */
  public ArrayList<ItemFeature> seedCareer = new ArrayList<ItemFeature>();
  
  /**
   * 种子源上传者年龄
   */
  public ArrayList<ItemFeature> seedAge = new ArrayList<ItemFeature>();
  
  /**
   * 种子源上传者性别
   */
  public ArrayList<ItemFeature> seedGender = new ArrayList<ItemFeature>();
  
  /**
   * 种子源上传者地区
   */
  public ArrayList<ItemFeature> seedAddress = new ArrayList<ItemFeature>();
  
  /**
   * 默认构造器
   */
  public RecoItemInfo(){
    
  }
  
  /**
   * 解析RecoItemInfo
   * @param str
   * @return null 表示解析失败
   */
  public static RecoItemInfo parse(String str){
    if(str == null){
      return null;
    }
    
    String[] flds = str.split("\t", -1);
    if (flds.length < 3) {
      return null;
    }
    RecoItemInfo info = new RecoItemInfo();
    info.itemId = flds[0];
    info.itemType = flds[1];
    info.isGlobalManualNews = Integer.parseInt(flds[2]);
    for (int i = 3; i < flds.length; ++i) {
      try {
        ItemFeature itemTerm = new ItemFeature();
        String[] termFlds = flds[i].split("::", -1);
        itemTerm.featureType = Integer.parseInt(termFlds[0]);
        itemTerm.feature = termFlds[1];
        itemTerm.weight = Float.parseFloat(termFlds[2]);
        if (itemTerm.featureType == ProfileFeatureType.CATEGORY.getValue()) {
          info.categories.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.TAG.getValue()) {
          info.tags.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.EVENT_TAG.getValue()) {
          info.eventTags.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.KEYWORD.getValue()) {
          info.keywords.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.TOPIC.getValue()) {
          info.topics.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.PLSA_TOPIC.getValue()) {
          info.plsaTopics.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.REGION.getValue()) {
          info.regions.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.TITLE_LDA_TOPIC.getValue()) {
        	info.titleLdaTopics.add(itemTerm);	// add by jinchanghu. 20170828
        } else if (itemTerm.featureType == ProfileFeatureType.VIDEO_CATEGORY.getValue()) {
          info.videoCategories.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.VIDEO_TAG.getValue()) {
          info.videoTags.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.SEED_CAREER.getValue()) {
        	info.seedCareer.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.SEED_AGE.getValue()) {
        	info.seedAge.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.SEED_GENDER.getValue()) {
        	info.seedGender.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.SEED_ADDRESS.getValue()) {
        	info.seedAddress.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.ITEM_SOURCE.getValue()) {
          //info.itemSource.add(itemTerm);
          itemTerm.featureType = ProfileFeatureType.VIDEO_SOURCE.getValue();
          info.videoSource.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.VIDEO_SOURCE.getValue()) {
          info.videoSource.add(itemTerm);
        } else if (itemTerm.featureType == ProfileFeatureType.RESOURCE_TYPE.getValue()) {
          info.resourceType = itemTerm;
        } else if (itemTerm.featureType == ProfileFeatureType.READING_TYPE.getValue()) {
          info.readingType = itemTerm;
        } else if (itemTerm.featureType == ProfileFeatureType.ITEM_LEN.getValue()) {
          info.textLength = itemTerm;
        } else if (itemTerm.featureType == ProfileFeatureType.VIDEO_LENGTH.getValue()) {
          info.videoLength = itemTerm;
        } else if (itemTerm.featureType == ProfileFeatureType.IS_BLUFFING_TITLE.getValue()) {
          info.isBluffingTitle = itemTerm;
        } else if (itemTerm.featureType == ProfileFeatureType.IS_POLITICS.getValue()) {
          info.isPolitics = itemTerm;
        } else if (itemTerm.featureType == ProfileFeatureType.IS_DIRTY.getValue()) {
          info.isDirty = itemTerm;
        } 
      } catch (Exception e) {
        return null;
      }
    }
    
    return info;
  }

  public static RecoItemInfo parseFromRecord(Record record){
	    if(record == null){
	      return null;
	    }

	    RecoItemInfo info = new RecoItemInfo();
	    info.itemId = record.getString(0);
	    info.itemType = record.getString(1);
	    info.isGlobalManualNews = Integer.parseInt(record.getString(2));
	    String[] flds = record.getString(3).split("\t", -1);
	    for (int i = 0; i < flds.length; ++i) {
	      try {
	        ItemFeature itemTerm = new ItemFeature();
	        String[] termFlds = flds[i].split("::", -1);
	        itemTerm.featureType = Integer.parseInt(termFlds[0]);
	        itemTerm.feature = termFlds[1];
	        itemTerm.weight = Float.parseFloat(termFlds[2]);
	        if (itemTerm.featureType == ProfileFeatureType.CATEGORY.getValue()) {
	          info.categories.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.TAG.getValue()) {
	          info.tags.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.EVENT_TAG.getValue()) {
	          info.eventTags.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.KEYWORD.getValue()) {
	          info.keywords.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.TOPIC.getValue()) {
	          info.topics.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.PLSA_TOPIC.getValue()) {
	          info.plsaTopics.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.REGION.getValue()) {
	          info.regions.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.TITLE_LDA_TOPIC.getValue()) {
	        	info.titleLdaTopics.add(itemTerm);	//add by jinchanghu. 20170828
	        } else if (itemTerm.featureType == ProfileFeatureType.VIDEO_CATEGORY.getValue()) {
	          info.videoCategories.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.VIDEO_TAG.getValue()) {
	          info.videoTags.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.SEED_CAREER.getValue()) {
	        	info.seedCareer.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.SEED_AGE.getValue()) {
	        	info.seedAge.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.SEED_GENDER.getValue()) {
	        	info.seedGender.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.SEED_ADDRESS.getValue()) {
	        	info.seedAddress.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.ITEM_SOURCE.getValue()) {
	          //info.itemSource.add(itemTerm);
	          itemTerm.featureType = ProfileFeatureType.VIDEO_SOURCE.getValue();
	          info.videoSource.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.VIDEO_SOURCE.getValue()) {
		      info.videoSource.add(itemTerm);
	        } else if (itemTerm.featureType == ProfileFeatureType.RESOURCE_TYPE.getValue()) {
	          info.resourceType = itemTerm;
	        } else if (itemTerm.featureType == ProfileFeatureType.READING_TYPE.getValue()) {
	          info.readingType = itemTerm;
	        } else if (itemTerm.featureType == ProfileFeatureType.ITEM_LEN.getValue()) {
	          info.textLength = itemTerm;
	        } else if (itemTerm.featureType == ProfileFeatureType.VIDEO_LENGTH.getValue()) {
	          info.videoLength = itemTerm;
	        } else if (itemTerm.featureType == ProfileFeatureType.IS_BLUFFING_TITLE.getValue()) {
	          info.isBluffingTitle = itemTerm;
	        } else if (itemTerm.featureType == ProfileFeatureType.IS_POLITICS.getValue()) {
	          info.isPolitics = itemTerm;
	        } else if (itemTerm.featureType == ProfileFeatureType.IS_DIRTY.getValue()) {
	          info.isDirty = itemTerm;
	        } 
	      } catch (Exception e) {
	        return null;
	      }
	    }
	    
	    return info;
	  }
  
  /**
   * 判断item是否属于某一类目
   * @param cate
   * @return
   */
  public boolean containsCategory(String cate){
    boolean result = false;
    for(ItemFeature fea : categories){
      if (fea.feature != null && fea.feature.equals(cate)){
        result = true;
        break;
      }
    }
    return result;
  }
  
  /**
   * 从文件中读取item info到map中
   * @param filePath
   * @param itemInfoMap
   * @throws IOException 
   */
  public static boolean readRecoItemInfoFromFile(String filePath, HashMap<String, RecoItemInfo> itemInfoMap) throws IOException {
    if(filePath == null || filePath.isEmpty() || itemInfoMap==null) {
      return false;
    }
    
    BufferedReader reader = new BufferedReader(new FileReader(filePath));
    String line;
    while ((line = reader.readLine()) != null) {
      RecoItemInfo info = RecoItemInfo.parse(line);
      if (info != null) {
        itemInfoMap.put(info.itemId, info);
      }
    }
    if (reader != null) {
      reader.close();
    }
    return true;
  }
}


