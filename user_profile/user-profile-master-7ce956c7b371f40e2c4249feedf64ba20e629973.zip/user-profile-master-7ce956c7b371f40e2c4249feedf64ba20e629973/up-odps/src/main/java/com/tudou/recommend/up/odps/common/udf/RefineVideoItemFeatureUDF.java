package com.tudou.recommend.up.odps.common.udf;

import java.util.ArrayList;
import java.util.List;

import com.aliyun.odps.udf.UDF;

public class RefineVideoItemFeatureUDF extends UDF {
	public String evaluate( String features, String delimitor, String topN, String vdoLen) {
		if (features == null ||  delimitor == null || topN == null) {
			return null;
		}
		
		if (features.isEmpty() || delimitor.isEmpty() || topN.isEmpty()) {
			return null;
		}
		
		int maxCount = Integer.parseInt(topN);
		int topicCount = 0;
		
		StringBuilder sb = new StringBuilder();
		String[] tokens = features.split(delimitor);
		
		// remain top n title_lda_topic
		List<String> featureList = new ArrayList<String>();
		for (int i = 0; i < tokens.length; i++) {
			String feature = tokens[i];
			if (feature.isEmpty()) {
				continue;
			}
			
			if (feature.startsWith("7::topic")) {
				if (topicCount < maxCount) {
					featureList.add(feature);
					topicCount++; 
				}
				continue;
			} 
			
			// if exist vdoLen value, then skip original video length value.
			if (feature.startsWith("180::") && vdoLen != null && !vdoLen.isEmpty()) {
				continue;
			}
			
			featureList.add(feature);
		}
		
		// add video length
		if (vdoLen != null && !vdoLen.isEmpty()) {
			featureList.add(vdoLen);
		}
	
		for (int i = 0; i < featureList.size(); i++) {
			if (i > 0) {
				sb.append(delimitor);
			}
			
			sb.append(featureList.get(i));
		}
		
		if (sb.length()>0) {
			return sb.toString();
		}
		
		return null;
	}
}
