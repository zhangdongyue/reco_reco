package com.tudou.recommend.up.odps.common.udf;


import java.util.*;

import com.aliyun.odps.udf.UDF;

public class GetTopNTagsUDF extends UDF {
	public class TagNode {
		String tag;
		double weight;
		
		public TagNode(String tag, double weight) {
			this.tag = tag;
			this.weight = weight;
		}
		
		public String getKey() {
			return this.tag;
		}
		
		public double getValue() {
			return this.weight;
		}
	}
	
	public class SortByWeightAndTagDesc implements Comparator<TagNode> {
		public int compare(TagNode s1, TagNode s2) {
			if ( s1.weight > s2.weight) {
				return -1;
			} else if (s1.weight < s2.weight) {
				return 1;
			} else {
				return s1.tag.compareTo(s2.tag);
			}
		}
	}
	
	public class SortByWeightAndTagAsc implements Comparator<TagNode> {
		public int compare(TagNode s1, TagNode s2) {
			if ( s1.weight < s2.weight) {
				return -1;
			} else if (s1.weight > s2.weight) {
				return 1;
			} else {
				return s1.tag.compareTo(s2.tag);
			}
		}
	}
	
	public String evaluate(String tag1, String delimitor, String seperator, String maxTagCount, String sortType) {
		if (tag1 == null || delimitor == null || seperator == null || maxTagCount == null || sortType == null) {
			return null;
		}
		
		if (tag1.isEmpty() || delimitor.isEmpty() || seperator.isEmpty() || maxTagCount.isEmpty() || sortType.isEmpty()) {
			return null;
		}
		
		ArrayList<TagNode> tagList = new ArrayList<TagNode>();
		String[] tokens1 = tag1.split(delimitor);
		for (int i = 0; i < tokens1.length; i++) {
			String featureInfo = tokens1[i];
			if (featureInfo.isEmpty()) {
				continue;
			}
			
			String[] tokens = featureInfo.split(seperator);
			if (tokens.length >= 3) {
				if (!tokens[0].isEmpty()) {
					
					double weight = Double.parseDouble(tokens[1]);
					tagList.add(new TagNode(tokens[0], weight));
					
				}
				
			} 
		}

		// sort tag list 
		if ("asc".equals(sortType) || "ASC".equals(sortType)) {
			Collections.sort(tagList, new SortByWeightAndTagAsc());
		} else if ("desc".equals(sortType) || "DESC".equals(sortType)) {
			Collections.sort(tagList, new SortByWeightAndTagDesc());
		} else if ("random".equals(sortType) || "RANDOM".equals(sortType)){
			Collections.shuffle(tagList);
		}

		// generate result
		int count = 0;
		int maxCount = Integer.parseInt(maxTagCount);
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < tagList.size(); i++) {
			String tag = tagList.get(i).tag;
			
			if (count >= maxCount) {
				break;
			}
			
			if (i > 0) {
				sb.append(delimitor);
			}
			sb.append(tag);
			
			count ++;
			
		}
		
		if (sb.length() > 0) {
			return sb.toString();
		}
		
		return null;
	}
}
