package com.tudou.recommend.up.odps.common.entity;

public class ProfileHotFactorOrderType {
	/**
	 * short (default)
	 */
	 public static final String SHORT = "short_video";
	 
	 /**
	  * long (inverse with short)
	  */
	 public static final String LONG = "long_video";
	 
	 /**
	  * default: 1.0
	  */
	 public static final String DEFAULT = "default_video";
}
