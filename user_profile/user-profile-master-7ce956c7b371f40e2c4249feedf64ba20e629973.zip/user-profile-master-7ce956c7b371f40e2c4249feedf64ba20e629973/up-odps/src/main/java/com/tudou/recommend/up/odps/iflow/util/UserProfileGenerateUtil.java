package com.tudou.recommend.up.odps.iflow.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import java.util.List;

import com.tudou.recommend.proto.ProtoCommon.Category;
import com.tudou.recommend.proto.ProtoCommon.CategoryFeature;
import com.tudou.recommend.proto.ProtoCommon.CategoryFeatureVector;
import com.tudou.recommend.proto.ProtoCommon.Feature;
import com.tudou.recommend.proto.ProtoCommon.FeatureVector;
import com.tudou.recommend.proto.ProtoCommon.ItemType;
import com.tudou.recommend.proto.ProtoUser.Profile;
import com.tudou.recommend.proto.ProtoUser.UgcProfile;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;
import com.tudou.recommend.up.odps.common.entity.interest.InterestElem;

import org.apache.log4j.Logger;

public class UserProfileGenerateUtil {
    private static final Logger logger = Logger
            .getLogger(UserProfileGenerateUtil.class);

    /**
     * 解析user interest
     *
     * @param fields
     * @param interestMap
     * @return
     */
    public static boolean parseInterests(String[] fields,
                                         Map<Integer, InterestElem> interestMap) {
        if (fields == null || interestMap == null) {
            return false;
        }

        for (int i = 0; i < fields.length; ++i) {
            String[] ss = fields[i].split("::", -1);
            if (ss.length < 3) {
                return false;
            }
            String term = ss[0];
            float interest = Float.parseFloat(ss[1]);
            float confidence = Float.parseFloat(ss[2]);
            float ctr = ss.length > 3 ? Float.parseFloat(ss[3]) : 0;
            int sign = term.hashCode();
            interestMap.put(sign, new InterestElem(term, "", interest,
                    confidence, ctr));
        }
        return true;
    }

    /**
     * generate ugc profile.
     * @param interestsMap
     * @return
     */
    public static UgcProfile generateUgcUserProfile(
    		Map<Integer, Map<Integer, InterestElem>> interestsMap) {
    	UgcProfile.Builder profileBuilder = UgcProfile.newBuilder();
    	boolean allNull = true;
    	int feaType;
    	
    	// set the created time.
    	profileBuilder.setLastUpdateTime(System.currentTimeMillis() / 1000);
    	
    	//video source preference
    	feaType = ProfileFeatureType.VIDEO_SOURCE.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setItemSourceFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed career preference.
    	feaType = ProfileFeatureType.SEED_CAREER.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setSeedCareerFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed age preference.
    	feaType = ProfileFeatureType.SEED_AGE.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setSeedAgeFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed gender preference.
    	feaType = ProfileFeatureType.SEED_GENDER.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setSeedGenderFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed gender preference.
    	feaType = ProfileFeatureType.SEED_ADDRESS.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setSeedAddressFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed category preference.(input video_category value)
    	feaType = ProfileFeatureType.VIDEO_CATEGORY.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		CategoryFeatureVector feaVec = generateCategoryFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setSeedCategoryFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	//seed tag preference.
    	feaType = ProfileFeatureType.SEED_TAG.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setSeedTagFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	// video category
    	feaType = ProfileFeatureType.VIDEO_CATEGORY.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		CategoryFeatureVector feaVec = generateCategoryFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setVideoCategoryFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	    	
    	// video tag
    	feaType = ProfileFeatureType.VIDEO_TAG.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVecWithCate(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setVideoTagFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	// video tag (without category)
    	feaType = ProfileFeatureType.VIDEO_TAG_WITHOUT_CATEGORY.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setVideoTagWithoutCatFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	// video click sum
    	feaType = ProfileFeatureType.VIDEO_CLICK_SUM.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		Feature fea = generateFeature(interestsMap.get(feaType));
    		if (fea != null) {
    			profileBuilder.setVideoClickNum(Double.parseDouble(fea.getLiteral()));
    			allNull = false;
    		}
    	}
    	// video read time
    	feaType = ProfileFeatureType.VIDEO_READ_TIME.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		Feature fea = generateFeature(interestsMap.get(feaType));
    		if (fea != null) {
    			profileBuilder.setVideoReadTime(Double.parseDouble(fea.getLiteral()));
    			allNull = false;
    		}
    	}
    	// video duration
    	feaType = ProfileFeatureType.VIDEO_DURATION.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setVideoReadHourFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	// video week day
    	feaType = ProfileFeatureType.VIDEO_WEEK_DAY.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setVideoReadWeekDayFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	// video length
    	feaType = ProfileFeatureType.VIDEO_LENGTH.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setVideoLengthFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	// video resolution
    	
    	// video network
    	feaType = ProfileFeatureType.VIDEO_NETWORK.getValue();
    	if (interestsMap.containsKey(feaType)) {
    		FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
    		if (feaVec != null) {
    			profileBuilder.setVideoNetworkFeavec(feaVec);
    			allNull = false;
    		}
    	}
    	
    	if (allNull) {
    		return null;
    	} else {
    		return profileBuilder.build();
    	}
    }
    
    public static Profile generateUserProfile(
            Map<Integer, Map<Integer, InterestElem>> interestsMap) {
        Profile.Builder profileBuilder = Profile.newBuilder();
        boolean allNull = true;
        int feaType;

        // 设置生成时间
        profileBuilder.setLastUpdateTime(System.currentTimeMillis() / 1000);

        // category
        feaType = ProfileFeatureType.CATEGORY.getValue();
        if (interestsMap.containsKey(feaType)) {
            CategoryFeatureVector feaVec = generateCategoryFeatureVec(interestsMap
                    .get(feaType));
            if (feaVec != null) {
                profileBuilder.setCategoryFeavec(feaVec);
                allNull = false;
            }
        }
        // video category
        feaType = ProfileFeatureType.VIDEO_CATEGORY.getValue();
        if (interestsMap.containsKey(feaType)) {
            CategoryFeatureVector feaVec = generateCategoryFeatureVec(interestsMap
                    .get(feaType));
            if (feaVec != null) {
                profileBuilder.setVideoCategoryFeavec(feaVec);
                allNull = false;
            }
        }
        // dislike category
        feaType = ProfileFeatureType.NEG_CATEGORY.getValue();
        if (interestsMap.containsKey(feaType)) {
            CategoryFeatureVector feaVec = generateCategoryFeatureVec(interestsMap
                    .get(feaType));
            if (feaVec != null) {
                profileBuilder.setNegCategoryFeavec(feaVec);
                allNull = false;
            }
        }
        // channel
        feaType = ProfileFeatureType.CHANNEL.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setChannelFeavec(feaVec);
                allNull = false;
            }
        }
        // keyword
        feaType = ProfileFeatureType.KEYWORD.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVecWithCate(interestsMap
                    .get(feaType));
            if (feaVec != null) {
                profileBuilder.setKeywordFeavec(feaVec);
                allNull = false;
            }
        }
        // tag
        feaType = ProfileFeatureType.TAG.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVecWithCate(interestsMap
                    .get(feaType));
            if (feaVec != null) {
                profileBuilder.setTagFeavec(feaVec);
                allNull = false;
            }
        }
        // event tag
        feaType = ProfileFeatureType.EVENT_TAG.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setEventTagFeavec(feaVec);
                allNull = false;
            }
        }
        // video tag
        feaType = ProfileFeatureType.VIDEO_TAG.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVecWithCate(interestsMap
                    .get(feaType));
            if (feaVec != null) {
                profileBuilder.setVideoTagFeavec(feaVec);
                allNull = false;
            }
        }
        // video tag (without category)
        feaType = ProfileFeatureType.VIDEO_TAG_WITHOUT_CATEGORY.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setVideoTagWithoutCatFeavec(feaVec);
                allNull = false;
            }
        }
        // dislike tag
        feaType = ProfileFeatureType.NEG_TAG.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVecWithCate(interestsMap
                    .get(feaType));
            if (feaVec != null) {
                profileBuilder.setNegTagFeavec(feaVec);
                allNull = false;
            }
        }

        // olympic tag
        feaType = ProfileFeatureType.SUB_OLYM_TAG.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setOlympicsTagFeavec(feaVec);
                allNull = false;
            }
        }

        // plsa-topic
        feaType = ProfileFeatureType.PLSA_TOPIC.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVecWithCate(interestsMap
                    .get(feaType));
            if (feaVec != null) {
                profileBuilder.setPlsaTopicFeavec(feaVec);
                allNull = false;
            }
        }
        // topic
        feaType = ProfileFeatureType.TOPIC.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setTopicFeavec(feaVec);
                allNull = false;
            }
        }
        // region
        feaType = ProfileFeatureType.REGION.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setRegionFeavec(feaVec);
                allNull = false;
            }
        }
        // item source
        feaType = ProfileFeatureType.ITEM_SOURCE.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setItemSourceFeavec(feaVec);
                allNull = false;
            }
        }

        // dirty item
        feaType = ProfileFeatureType.DIRTY_TOLERANCE.getValue();
        if (interestsMap.containsKey(feaType)) {
            Feature fea = generateFeature(interestsMap.get(feaType));
            if (fea != null) {
                profileBuilder.setDirtyFea(fea);
                allNull = false;
            }
        }

        // politics item
        feaType = ProfileFeatureType.POLITICS_TOLERANCE.getValue();
        if (interestsMap.containsKey(feaType)) {
            Feature fea = generateFeature(interestsMap.get(feaType));
            if (fea != null) {
                profileBuilder.setPoliticsFea(fea);
                allNull = false;
            }
        }

        // bluffing title item
        feaType = ProfileFeatureType.BLUFFING_TITLE_TOLERANCE.getValue();
        if (interestsMap.containsKey(feaType)) {
            Feature fea = generateFeature(interestsMap.get(feaType));
            if (fea != null) {
                profileBuilder.setBluffingTitleFea(fea);
                allNull = false;
            }
        }

        // item type
        feaType = ProfileFeatureType.ITEM_TYPE.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setItemTypeFeavec(feaVec);
                allNull = false;
            }
        }

        // resource type
        feaType = ProfileFeatureType.RESOURCE_TYPE.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setResourceTypeFeavec(feaVec);
                allNull = false;
            }
        }
        // item depth
        feaType = ProfileFeatureType.ITEM_DEPTH.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setItemDepthFeavec(feaVec);
                allNull = false;
            }
        }
        // reading type
        feaType = ProfileFeatureType.READING_TYPE.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setReadingTypeFeavec(feaVec);
                allNull = false;
            }
        }
        // reco strategy
        feaType = ProfileFeatureType.RECO_STRATEGY.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setRecoStrategyFeavec(feaVec);
                allNull = false;
            }
        }
        // reading duration
        feaType = ProfileFeatureType.READING_DURATION.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setReadingDurationFeavec(feaVec);
                allNull = false;
            }
        }
        // reading length
        feaType = ProfileFeatureType.ITEM_LEN.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setReadingLengthFeavec(feaVec);
                allNull = false;
            }
        }
        // reading continuous
        feaType = ProfileFeatureType.READ_CONTINUOUS.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setReadingContinuousFeavec(feaVec);
                allNull = false;
            }
        }
        // avg read time
        feaType = ProfileFeatureType.READING_TIME.getValue();
        if (interestsMap.containsKey(feaType)) {
            Feature fea = generateFeature(interestsMap.get(feaType));
            if (fea != null) {
                profileBuilder.setReadingTimeFea(fea);
                allNull = false;
            }
        }
        // avg visit frequency
        feaType = ProfileFeatureType.VISIT_FREQ.getValue();
        if (interestsMap.containsKey(feaType)) {
            Feature fea = generateFeature(interestsMap.get(feaType));
            if (fea != null) {
                profileBuilder.setVisitFrequency(fea);
                allNull = false;
            }
        }
        // channel refresh
        feaType = ProfileFeatureType.REFRESH_CHANNEL.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setRefreshChannelFeavec(feaVec);
                allNull = false;
            }
        }
        // video click sum
        feaType = ProfileFeatureType.VIDEO_CLICK_SUM.getValue();
        if (interestsMap.containsKey(feaType)) {
            Feature fea = generateFeature(interestsMap.get(feaType));
            if (fea != null) {
                profileBuilder.setVideoClickNumFea(fea);
                allNull = false;
            }
        }
        // video read time
        feaType = ProfileFeatureType.VIDEO_READ_TIME.getValue();
        if (interestsMap.containsKey(feaType)) {
            Feature fea = generateFeature(interestsMap.get(feaType));
            if (fea != null) {
                profileBuilder.setVideoReadTimeFea(fea);
                allNull = false;
            }
        }
        // video duration
        feaType = ProfileFeatureType.VIDEO_DURATION.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setVideoReadHourFeavec(feaVec);
                allNull = false;
            }
        }
        // video week day
        feaType = ProfileFeatureType.VIDEO_WEEK_DAY.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setVideoReadWeekDayFeavec(feaVec);
                allNull = false;
            }
        }
        // video length
        feaType = ProfileFeatureType.VIDEO_LENGTH.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setVideoLengthFeavec(feaVec);
                allNull = false;
            }
        }
        // video resolution

        // video network
        feaType = ProfileFeatureType.VIDEO_NETWORK.getValue();
        if (interestsMap.containsKey(feaType)) {
            FeatureVector feaVec = generateFeatureVec(interestsMap.get(feaType));
            if (feaVec != null) {
                profileBuilder.setVideoNetworkFeavec(feaVec);
                allNull = false;
            }
        }

        // loyal user
        feaType = ProfileFeatureType.IS_LOYAL_USER.getValue();
        if (interestsMap.containsKey(feaType)) {
            InterestElem elem = interestsMap.get(feaType).values().iterator()
                    .next();
            if (elem != null) {
                profileBuilder.setIsLoyalUser("1".equals(elem.term));
            } else {
                profileBuilder.setIsLoyalUser(false);
            }
        } else {
            profileBuilder.setIsLoyalUser(false);
        }

        if (allNull) {
            return null;
        } else {
            return profileBuilder.build();
        }
    }

    /**
     * 生成category feature proto
     *
     * @param categoryInterestMap
     * @param maxFeatureNumber    -1表示不按topN过滤
     * @return
     */
    private static CategoryFeatureVector generateCategoryFeatureVec(
            Map<Integer, InterestElem> categoryInterestMap,
            int maxFeatureNumber) {
        if (categoryInterestMap == null) {
            logger.error("failed to generate CategoryFeatureVector");
            return null;
        }

        ArrayList<InterestElem> interestElemArr = new ArrayList<InterestElem>();
        for (int sign : categoryInterestMap.keySet()) {
            InterestElem interestElem = categoryInterestMap.get(sign);
            int sepIndex = interestElem.term.indexOf(Contents.CATEGORY_SEP);
            if (sepIndex > 0) {
                interestElem.parent = interestElem.term.substring(0, sepIndex);
                interestElem.term = interestElem.term.substring(sepIndex
                        + Contents.CATEGORY_SEP.length());
            } else {
                interestElem.parent = "";
            }
            interestElemArr.add(interestElem);
        }
        // sort and get topN interest
        sortFeatureVec(interestElemArr);
        List<InterestElem> topInterestElems = maxFeatureNumber > 0 ? getTopNInterestElem(
                interestElemArr, maxFeatureNumber) : interestElemArr;
        if (topInterestElems == null) {
            return null;
        }

        double norm = 0;
        CategoryFeatureVector.Builder featureVecBuilder = CategoryFeatureVector
                .newBuilder();
        for (int i = 0; i < topInterestElems.size(); ++i) {
            InterestElem elem = topInterestElems.get(i);
            CategoryFeature.Builder featureBuilder = CategoryFeature
                    .newBuilder();
            if ("".equals(elem.parent)) { // 一级类目
                featureBuilder = featureBuilder
                        .setWeight(elem.interest)
                        .setConfidence(elem.confidence)
                        .setUserCtr(elem.ctr)
                        .setItemType(ItemType.kNews)
                        .setLiteral(
                                Category.newBuilder().setCategory(elem.term)
                                        .setLevel(0).build());
            } else {// 二级类目
                featureBuilder = featureBuilder
                        .setWeight(elem.interest)
                        .setConfidence(elem.confidence)
                        .setUserCtr(elem.ctr)
                        .setItemType(ItemType.kNews)
                        .setLiteral(
                                Category.newBuilder().setCategory(elem.term)
                                        .addParents(elem.parent).setLevel(1)
                                        .build());
            }
            featureVecBuilder = featureVecBuilder.addFeature(featureBuilder
                    .build());
            norm += elem.confidence;
        }
        featureVecBuilder = featureVecBuilder.setNorm(norm);
        return featureVecBuilder.build();
    }

    private static CategoryFeatureVector generateCategoryFeatureVec(
            Map<Integer, InterestElem> categoryInterestMap) {
        return generateCategoryFeatureVec(categoryInterestMap, -1);
    }

    /**
     * 生成feature vec proto， 设置category
     *
     * @param interestMap
     * @param maxFeatureNumber -1表示不按topN过滤
     * @return
     */
    private static FeatureVector generateFeatureVecWithCate(
            Map<Integer, InterestElem> interestMap, int maxFeatureNumber) {
        if (interestMap == null) {
            logger.error("failed to generate FeatureVec");
            return null;
        }

        ArrayList<InterestElem> interestElemArr = new ArrayList<InterestElem>();
        for (int sign : interestMap.keySet()) {
            InterestElem interestElem = interestMap.get(sign);
            int sepIndex = interestElem.term.indexOf(Contents.CATEGORY_SEP);
            if (sepIndex > 0) {
                interestElem.parent = interestElem.term.substring(0, sepIndex);
                interestElem.term = interestElem.term.substring(sepIndex
                        + Contents.CATEGORY_SEP.length());
            } else {
                logger.error("invalid feature, no category found:"
                        + interestElem.term);
                return null;
            }
            interestElemArr.add(interestElem);
        }
        // sort and get topN interest
        sortFeatureVec(interestElemArr);
        List<InterestElem> topInterestElems = maxFeatureNumber > 0 ? getTopNInterestElem(
                interestElemArr, maxFeatureNumber) : interestElemArr;
        if (topInterestElems == null) {
            return null;
        }

        double norm = 0;
        FeatureVector.Builder featureVecBuilder = FeatureVector.newBuilder();
        for (int i = 0; i < topInterestElems.size(); ++i) {
            InterestElem elem = topInterestElems.get(i);
            Feature.Builder featureBuilder = Feature.newBuilder()
                    .setCategory(elem.parent).setWeight(elem.interest)
                    .setConfidence(elem.confidence).setLiteral(elem.term)
                    .setItemType(ItemType.kNews);
            featureVecBuilder = featureVecBuilder.addFeature(featureBuilder
                    .build());
            norm += elem.confidence;
        }
        featureVecBuilder = featureVecBuilder.setNorm(norm);
        return featureVecBuilder.build();
    }

    private static FeatureVector generateFeatureVecWithCate(
            Map<Integer, InterestElem> interestMap) {
        return generateFeatureVecWithCate(interestMap, -1);
    }

    /**
     * 生成feature vec proto， 不设置category
     *
     * @param interestMap
     * @param maxFeatureNumber -1表示不按topN过滤
     * @return
     */
    private static FeatureVector generateFeatureVec(
            Map<Integer, InterestElem> interestMap, int maxFeatureNumber) {
        if (interestMap == null) {
            logger.error("failed to generate TopicFeatureVec");
            return null;
        }

        ArrayList<InterestElem> interestElemArr = new ArrayList<InterestElem>();
        for (int sign : interestMap.keySet()) {
            InterestElem interestElem = interestMap.get(sign);
            interestElemArr.add(interestElem);
        }
        // sort and get topN interest
        sortFeatureVec(interestElemArr);
        List<InterestElem> topInterestElems = maxFeatureNumber > 0 ? getTopNInterestElem(
                interestElemArr, maxFeatureNumber) : interestElemArr;

        double norm = 0;
        FeatureVector.Builder featureVecBuilder = FeatureVector.newBuilder();
        for (int i = 0; i < topInterestElems.size(); ++i) {
            InterestElem elem = topInterestElems.get(i);
            Feature.Builder featureBuilder = Feature.newBuilder()
                    .setWeight(elem.interest).setConfidence(elem.confidence)
                    .setLiteral(elem.term).setItemType(ItemType.kNews);

            featureVecBuilder = featureVecBuilder.addFeature(featureBuilder
                    .build());
            norm += elem.confidence;
        }
        featureVecBuilder = featureVecBuilder.setNorm(norm);
        return featureVecBuilder.build();
    }

    private static FeatureVector generateFeatureVec(
            Map<Integer, InterestElem> interestMap) {
        return generateFeatureVec(interestMap, -1);
    }

    /**
     * 生成单个Feature
     *
     * @param interestMap
     * @return
     */
    private static Feature generateFeature(
            Map<Integer, InterestElem> interestMap) {
        if (interestMap == null || interestMap.size() != 1) {
            logger.error("failed to generate Feature");
            return null;
        }
        InterestElem elem = interestMap.values().iterator().next();

        Feature.Builder featureBuilder = Feature.newBuilder()
                .setWeight(elem.interest).setConfidence(elem.confidence)
                .setLiteral(elem.term).setItemType(ItemType.kNews);
        return featureBuilder.build();
    }

    private static List<InterestElem> getTopNInterestElem(
            List<InterestElem> interestElemArr, int topN) {
        if (interestElemArr == null || topN < 0) {
            return null;
        }
        topN = topN < interestElemArr.size() ? topN : interestElemArr.size();
        return interestElemArr.subList(0, topN);
    }

    /**
     * 按weight降序排列
     *
     * @param interestElemArr
     */
    private static void sortFeatureVec(List<InterestElem> interestElemArr) {
        if (interestElemArr == null) {
            return;
        }

        // sort by interest desc
        // System.setProperty("java.util.Arrays.useLegacyMergeSort", "true");
        Collections.sort(interestElemArr, new Comparator<InterestElem>() {
            public int compare(InterestElem elem1, InterestElem elem2) {
                Double d1 = new Double(elem1.interest);
                Double d2 = new Double(elem2.interest);
                return Double.compare(d2, d1);
            }
        });
    }
}
