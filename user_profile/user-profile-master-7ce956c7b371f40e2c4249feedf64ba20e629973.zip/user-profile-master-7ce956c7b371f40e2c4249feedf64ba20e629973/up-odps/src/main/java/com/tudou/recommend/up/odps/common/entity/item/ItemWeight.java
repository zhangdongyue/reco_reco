package com.tudou.recommend.up.odps.common.entity.item;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import com.tudou.recommend.up.odps.common.util.DataFormatUtil;

/**
 * item 权重信息，统计用户行为时对item的权重进行调节
 * @author hezhimin
 *
 */
public class ItemWeight {
  /**
   * item id
   */
  public String itemId;
  
  /**
   * item 权重
   */
  public double weight;
  
  /**
   * 生效开始时间
   */
  public Long startTime;
  
  /**
   * 生效结束时间
   */
  public Long endTime;
  
  public ItemWeight(){
    itemId = "";
    weight = 1.0;
    startTime = 0L;
    endTime = 0L;
  }
  
  public static ItemWeight parse(String str) {
    if (str == null) return null;
    String[] flds = str.split("\t", -1);
    if (flds.length != 4) return null;
    ItemWeight iw = new ItemWeight();
    iw.itemId = flds[0];
    iw.weight = Double.parseDouble(flds[1]);
    iw.startTime = DataFormatUtil.getTimestamp(flds[2]);
    iw.endTime = DataFormatUtil.getTimestamp(flds[3]);
    return iw;
  }
  
  /**
   * 从文件中读取item weight到map中
   * @param filePath
   * @param itemWeightMap
   * @throws IOException 
   */
  public static boolean ReadItemWeightFromFile(String filePath, HashMap<String, ItemWeight> itemWeights) throws IOException {
    if(filePath == null || filePath.isEmpty() || itemWeights==null) {
      return false;
    }
    
    BufferedReader reader = new BufferedReader(new FileReader(filePath));
    String line;
    while ((line = reader.readLine()) != null) {
      ItemWeight iw = ItemWeight.parse(line);
      if (iw != null) {
        itemWeights.put(iw.itemId, iw);
      }
    }
    if (reader != null) {
      reader.close();
    }
    return true;
  }
}
