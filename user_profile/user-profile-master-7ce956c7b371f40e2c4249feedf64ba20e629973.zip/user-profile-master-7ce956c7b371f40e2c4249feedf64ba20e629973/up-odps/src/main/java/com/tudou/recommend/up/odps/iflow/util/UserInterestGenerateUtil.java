package com.tudou.recommend.up.odps.iflow.util;

import java.text.DecimalFormat;
import java.util.HashMap;

import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;
import com.tudou.recommend.up.odps.common.entity.interest.InterestCalcMethods;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import org.apache.log4j.Logger;

public class UserInterestGenerateUtil {
  private static final Logger logger = Logger.getLogger(UserInterestGenerateUtil.class);
  private static final DecimalFormat DF = DataFormatUtil.getDefaultDecimalFormater();

  // 全局设置
  // fea的权重
  private HashMap<String, float[]> feaWeightsMap = new HashMap<String, float[]>();

  // 时间衰减因子
  private float timeDecayFactor = 1.0f;

  // 各时间桶的具体具体衰减系数
  private float[] timeDecayFactors;

  // 时间桶个数
  private int bucketNum = 0;

  // feature 权重是否已加载
  private boolean isFeaWeightLoad = false;
  
  // 是否用特征的全局热度打压权重
  private boolean useGlobalTermWeight = false;

  // 不同的fea type走不同的interest计算逻辑
  private HashMap<Integer, InterestCalcMethods> feaInterestCalcMethodMap = new HashMap<Integer, InterestCalcMethods>();

  // feature weight强制调权
  private boolean doFeatureWeightTuning = false;
  private HashMap<Integer, HashMap<String, Double>> feaTuneWeights = new HashMap<Integer, HashMap<String, Double>>();

  // debug模式
  private boolean debug = false;

  // 计数器： 桶编号错误个数
  private long errorBucketNum = 0;

  // 局部设置
  // 用户在不同fea上的weight: feaType ~ fea ~ [weight]
  private HashMap<Integer, HashMap<String, float[]>> userWeightsMap = new HashMap<Integer, HashMap<String, float[]>>();

  // 用户兴趣: feaType ~ fea ~ [interest]
  private HashMap<Integer, HashMap<String, float[]>> interestResults = new HashMap<Integer, HashMap<String, float[]>>();

  /**
   * 注意：clear方法默认只清除（单个用户）局部统计结果, 如需清除所有信息，请调用clear(true)
   */
  public void clear() {
    clear(false);
  }

  public void clear(boolean clearAll) {
    // 清除全局设置和词典信息
    if (clearAll) {
      feaWeightsMap.clear();
      timeDecayFactor = 1.0f;
      timeDecayFactors = null;
      bucketNum = 0;
      isFeaWeightLoad = false;
      feaInterestCalcMethodMap.clear();
      doFeatureWeightTuning = false;
      feaTuneWeights.clear();
      debug = false;
      errorBucketNum = 0;
    }
    // 清除局部统计结果
    userWeightsMap.clear();
    interestResults.clear();
  }

  public void process(String[] flds) {
    int feaType = Integer.parseInt(flds[0]);
    String fea = flds[1];
    String[] weightStrs = flds[2].split(" ", -1);
    float[] weights = new float[bucketNum];
    for (String str : weightStrs) {
      String[] number = str.split(":", -1);
      int bucket = Integer.parseInt(number[0]);
      float weight = Float.parseFloat(number[1]);
      if (bucket >= bucketNum) {
        errorBucketNum++;
        continue;
      }
      // 取weight sum
      weights[bucket] = weight;
    }

    if (!userWeightsMap.containsKey(feaType)) {
      userWeightsMap.put(feaType, new HashMap<String, float[]>());
    }
    userWeightsMap.get(feaType).put(fea, weights);
  }

  public void merge() {
    // 计算用户interest
    for (int feaType : userWeightsMap.keySet()) {
      HashMap<String, float[]> interestMap = calculateInterest(userWeightsMap.get(feaType), feaWeightsMap,
          timeDecayFactors, feaType);
      if (interestMap != null) {
        interestResults.put(feaType, interestMap);
      }
    }

    // 离散化平均阅读时长
    if (interestResults.containsKey(ProfileFeatureType.READING_TIME.getValue())) {
      HashMap<String, float[]> interestMap = interestResults.get(ProfileFeatureType.READING_TIME.getValue());
      String key = "total";
      if (interestMap.containsKey(key)) {
        float avgReadSeconds = interestMap.get(key)[0];
        float clickSum = interestMap.get(key)[1];
        String readTimeRange = convertReadTime(avgReadSeconds);
        interestMap.clear();
        interestMap.put(readTimeRange, new float[] { avgReadSeconds, clickSum });
      }
    }

    // 离散化用户访问频次
    if (interestResults.containsKey(ProfileFeatureType.VISIT_FREQ.getValue())) {
      HashMap<String, float[]> interestMap = interestResults.get(ProfileFeatureType.VISIT_FREQ.getValue());
      String key = "total";
      if (interestMap.containsKey(key)) {
        float avgVisitNum = interestMap.get(key)[0];
        float clickSum = interestMap.get(key)[1];
        String visitFreq = convertVisitFrequency(avgVisitNum);
        interestMap.clear();
        interestMap.put(visitFreq, new float[] { avgVisitNum, clickSum });
      }
    }

    // 汇总统计用户对低质文章的耐受度
    {
      HashMap<String, float[]> interestMap;
      if ((interestMap = calcPoliticsTolerance(interestResults)) != null) {
        interestResults.put(ProfileFeatureType.POLITICS_TOLERANCE.getValue(), interestMap);
      }
      if ((interestMap = calcDirtyTolerance(interestResults)) != null) {
        interestResults.put(ProfileFeatureType.DIRTY_TOLERANCE.getValue(), interestMap);
      }
      if ((interestMap = calcBluffingTitleTolerance(interestResults)) != null) {
        interestResults.put(ProfileFeatureType.BLUFFING_TITLE_TOLERANCE.getValue(), interestMap);
      }
    }

    // 视频点击总数
    if (interestResults.containsKey(ProfileFeatureType.VIDEO_CLICK_SUM.getValue())) {
      HashMap<String, float[]> interestMap = interestResults.get(ProfileFeatureType.VIDEO_CLICK_SUM.getValue());
      String key = "total";
      if (interestMap.containsKey(key)) {
        float clickSum = interestMap.get(key)[0];
        interestMap.clear();
        // 权重和置信度均置为1
        interestMap.put(String.valueOf(clickSum), new float[] { 1, 1 });
      }
    }

    // 视频观看总时长
    if (interestResults.containsKey(ProfileFeatureType.VIDEO_READ_TIME.getValue())) {
      HashMap<String, float[]> interestMap = interestResults.get(ProfileFeatureType.VIDEO_READ_TIME.getValue());
      String key = "total";
      if (interestMap.containsKey(key)) {
        float readTimeSum = interestMap.get(key)[0];
        interestMap.clear();
        // 权重和置信度均置为1
        interestMap.put(String.valueOf(readTimeSum), new float[] { 1, 1 });
      }
    }
  }

  public void generateTimeDecayFactors() {
    timeDecayFactors = generateTimeDecayFactors(timeDecayFactor, bucketNum);
  }

  /**
   * 生成时间衰减系数
   * 
   * @param alpha
   *          衰减权重，越小表示随时间衰减越严重
   * @param len
   *          时间窗长度
   * @return
   */
  public static float[] generateTimeDecayFactors(float alpha, int len) {
    if (len < 0) {
      return null;
    }
    float[] factors = new float[len];
    for (int i = 0; i < len; ++i) {
      factors[i] = 1;
    }
    for (int i = len - 1; i > 0; --i) {
      factors[i - 1] = alpha * factors[i];
    }
    return factors;
  }

  /**
   * 对weight过低的时间桶进行处罚 对category，weight等于click数
   * 
   * @param userWeight
   * @param minWeight
   * @return
   */
  public static float calcDisDecay(float[] userWeight, float minWeight) {
    int hit = 0;
    for (int i = 0; i < userWeight.length; ++i) {
      if (userWeight[i] > minWeight) {
        hit += 1;
      } else {
        hit += userWeight[i] / minWeight;
      }
    }
    float decay = hit / userWeight.length;
    if (decay < 0.1) {
      return 0.6f;
    }
    return 0.6f + (decay - 0.1f) * 4 / 9;
  }

  /**
   * 设置不同的fea type对应的interest计算方法
   */
  public void setFeaInterestCalcMethods() {
    // category interest
    feaInterestCalcMethodMap.put(ProfileFeatureType.CATEGORY.getValue(), InterestCalcMethods.Category);
    feaInterestCalcMethodMap.put(ProfileFeatureType.VIDEO_CATEGORY.getValue(), InterestCalcMethods.Category);
    feaInterestCalcMethodMap.put(ProfileFeatureType.SEARCH_CATEGORY.getValue(), InterestCalcMethods.CategoryWithouSmooting);

    // default interest
    feaInterestCalcMethodMap.put(ProfileFeatureType.KEYWORD.getValue(), InterestCalcMethods.Default);
    feaInterestCalcMethodMap.put(ProfileFeatureType.TAG.getValue(), InterestCalcMethods.Default);
    feaInterestCalcMethodMap.put(ProfileFeatureType.TOPIC.getValue(), InterestCalcMethods.Default);
    feaInterestCalcMethodMap.put(ProfileFeatureType.PLSA_TOPIC.getValue(), InterestCalcMethods.Default);
    feaInterestCalcMethodMap.put(ProfileFeatureType.TITLE_LDA_TOPIC.getValue(), InterestCalcMethods.Default);
    feaInterestCalcMethodMap.put(ProfileFeatureType.VIDEO_TAG.getValue(), InterestCalcMethods.Default);
    feaInterestCalcMethodMap.put(ProfileFeatureType.VIDEO_TAG_WITHOUT_CATEGORY.getValue(), InterestCalcMethods.Default);
    feaInterestCalcMethodMap.put(ProfileFeatureType.ITEM_SOURCE.getValue(), InterestCalcMethods.Default);
    feaInterestCalcMethodMap.put(ProfileFeatureType.VIDEO_SOURCE.getValue(), InterestCalcMethods.Default);
    feaInterestCalcMethodMap.put(ProfileFeatureType.CHANNEL.getValue(), InterestCalcMethods.Default);

    // no-smooting interest
    feaInterestCalcMethodMap.put(ProfileFeatureType.NEG_CATEGORY.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.NEG_TAG.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.NEG_KEYWORD.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.NEG_TOPIC.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.EVENT_TAG.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.RESOURCE_TYPE.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.READING_TYPE.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.ITEM_LEN.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.RECO_STRATEGY.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.ITEM_TYPE.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.READING_DURATION.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.READ_CONTINUOUS.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.LIKE_BLUFFING_TITLE.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.LIKE_DIRTY.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.LIKE_POLITICS.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.TOLERATE_BLUFFING_TITLE.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.TOLERATE_DIRTY.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.TOLERATE_POLITICS.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.DISLIKE_BLUFFING_TITLE.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.DISLIKE_DIRTY.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.DISLIKE_POLITICS.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.REFRESH_CATEGORY.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.REFRESH_CHANNEL.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.REFRESH_TAG.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.REFRESH_KEYWORD.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.REFRESH_TOPIC.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.REFRESH_PLSA_TOPIC.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.SEARCH_TAG.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.SEARCH_KEYWORD.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.VIDEO_DURATION.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.VIDEO_WEEK_DAY.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.VIDEO_LENGTH.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.VIDEO_RESOLUTION.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.VIDEO_NETWORK.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.SEED_CAREER.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.SEED_AGE.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.SEED_GENDER.getValue(), InterestCalcMethods.WithouSmooting);
    feaInterestCalcMethodMap.put(ProfileFeatureType.SEED_ADDRESS.getValue(), InterestCalcMethods.WithouSmooting);

    // sum interest
    feaInterestCalcMethodMap.put(ProfileFeatureType.VIDEO_CLICK_SUM.getValue(), InterestCalcMethods.Sum);
    feaInterestCalcMethodMap.put(ProfileFeatureType.VIDEO_READ_TIME.getValue(), InterestCalcMethods.Sum);

    // avg interest
    feaInterestCalcMethodMap.put(ProfileFeatureType.READING_TIME.getValue(), InterestCalcMethods.Average);
    feaInterestCalcMethodMap.put(ProfileFeatureType.VISIT_FREQ.getValue(), InterestCalcMethods.Average);
  }

  /**
   * 计算用户在feature上的interest，根据feature type的不同调用不同的计算逻辑
   * 
   * @param userWeightsMap
   * @param feaWeightsMap
   * @param timeDecayFactors
   * @param feaType
   * @return
   */
  private HashMap<String, float[]> calculateInterest(HashMap<String, float[]> userWeightsMap,
      HashMap<String, float[]> feaWeightsMap, float[] timeDecayFactors, int feaType) {
    InterestCalcMethods calcMethod = feaInterestCalcMethodMap.get(feaType);
    if (calcMethod == null) {
      return null;
    } else if (calcMethod == InterestCalcMethods.Category) {
      return calculateCategoryInterest(userWeightsMap, feaWeightsMap, timeDecayFactors, feaType);
    } else if (calcMethod == InterestCalcMethods.CategoryWithouSmooting) {
      return calculateCategoryInterest(userWeightsMap, timeDecayFactors, feaType);
    } else if (calcMethod == InterestCalcMethods.Default) {
      return calculateDefaultInterest(userWeightsMap, feaWeightsMap, timeDecayFactors, feaType);
    } else if (calcMethod == InterestCalcMethods.WithouSmooting) {
      return calculateDefaultInterest(userWeightsMap, timeDecayFactors, feaType);
    } else if (calcMethod == InterestCalcMethods.Sum) {
      return calculateInterestBySum(userWeightsMap);
    } else if (calcMethod == InterestCalcMethods.Average) {
      return calculateInterestByAvg(userWeightsMap);
    } else {
      return null;
    }
  }

  /**
   * 计算用户在category上的interest
   * 
   * @param userWeightsMap
   *          用户在各term上的行为权重
   * @param feaWeightsMap
   *          各term的权重
   * @param timeDecayFactors
   *          各桶的时间衰减系数
   * @return
   */
  private HashMap<String, float[]> calculateCategoryInterest(HashMap<String, float[]> userWeightsMap,
      HashMap<String, float[]> feaWeightsMap, float[] timeDecayFactors, int feaType) {

    HashMap<String, float[]> interestMap = new HashMap<String, float[]>();

    // 用户在所有时间桶所有类目下的权重总和
    float globalUserWeightSum = 0;
    // 用户对所有一级类目的兴趣得分总和
    float globalUserInterestSum = 0;
    float minInterest = Float.MAX_VALUE;

    for (String fea : userWeightsMap.keySet()) {
      String feaWithType = feaType + "_" + fea;
      if (!feaWeightsMap.containsKey(feaWithType)) {
        // skip inactive features
        continue;
      }

      String[] categories = fea.split(Contents.CATEGORY_SEP);
      // 是否是一级类目
      boolean isLevel1Category = categories.length == 1;
      String level1Cate = categories[0];
      String level1CateWithType = feaType + "_" + level1Cate;

      float userWeightSum = 0;
      // float interestNoDecay = 0;
      float interestWithDecay = 0;
      // 一二级类目统一使用一级类目的fea weight做平滑
      float[] feaWeights = feaWeightsMap.get(level1CateWithType);
      float[] userWeights = userWeightsMap.get(fea);
      float disDecay = calcDisDecay(userWeights, 3);

      // 热度降权
      for (int i = 0; i < userWeights.length; ++i) {
        if (userWeights[i] <= 0 || feaWeights[i] < 0.01) {
          continue;
        }
        interestWithDecay += timeDecayFactors[i] * userWeights[i] / feaWeights[i];
        userWeightSum += userWeights[i];
      }

      // 非稳定兴趣降权
      interestWithDecay *= disDecay;

      interestMap.put(fea, new float[] { interestWithDecay, userWeightSum });
      if (isLevel1Category) {
        globalUserInterestSum += interestWithDecay;
        globalUserWeightSum += userWeightSum;
      }
      if (minInterest > interestWithDecay) {
        minInterest = interestWithDecay;
      }
    }

    // 平滑
    globalUserInterestSum += 0.5 * minInterest;
    // HashMap<String, Float> level2CategoryInterestSumMap = new HashMap<String,
    // Float>();
    for (String fea : interestMap.keySet()) {
      if (globalUserInterestSum > 0) {
        interestMap.get(fea)[0] = interestMap.get(fea)[0] * globalUserWeightSum / globalUserInterestSum;
      } else {
        interestMap.get(fea)[0] = 0;
      }
    }

    // 继续平滑,防止interest过度大于weight
    for (String fea : interestMap.keySet()) {
      if (interestMap.get(fea)[0] > 1.5f * interestMap.get(fea)[1]) {
        interestMap.get(fea)[0] = 1.5f * interestMap.get(fea)[1];
      }
    }

    return interestMap;
  }

  /**
   * 计算用户在category上的interest (仅考虑时间衰减，不进行平滑)
   * 
   * @param userWeightsMap
   *          用户在各term上的行为权重
   * @param timeDecayFactors
   *          各桶的时间衰减系数
   * @return
   */
  private HashMap<String, float[]> calculateCategoryInterest(HashMap<String, float[]> userWeightsMap,
      float[] timeDecayFactors, int feaType) {

    HashMap<String, float[]> interestMap = new HashMap<String, float[]>();

    // 用户在所有时间桶所有类目下的权重总和
    float globalUserWeightSum = 0;
    // 用户对所有一级类目的兴趣得分总和
    float globalUserInterestSum = 0;
    float minInterest = Float.MAX_VALUE;

    for (String fea : userWeightsMap.keySet()) {
      String[] categories = fea.split(Contents.CATEGORY_SEP);
      // 是否是一级类目
      boolean isLevel1Category = categories.length == 1;

      float userWeightSum = 0;
      // float interestNoDecay = 0;
      float interestWithDecay = 0;
      // 一二级类目统一使用一级类目的term weight做平滑
      float[] userWeights = userWeightsMap.get(fea);

      for (int i = 0; i < userWeights.length; ++i) {
        interestWithDecay += timeDecayFactors[i] * userWeights[i];
        userWeightSum += userWeights[i];
      }

      interestMap.put(fea, new float[] { interestWithDecay, userWeightSum });

      if (isLevel1Category) {
        globalUserInterestSum += interestWithDecay;
        globalUserWeightSum += userWeightSum;
      }
      if (minInterest > interestWithDecay) {
        minInterest = interestWithDecay;
      }
    }

    // 平滑
    globalUserInterestSum += 0.5 * minInterest;
    for (String fea : interestMap.keySet()) {
      if (globalUserInterestSum > 0) {
        interestMap.get(fea)[0] = interestMap.get(fea)[0] * globalUserWeightSum / globalUserInterestSum;
      } else {
        interestMap.get(fea)[0] = 0;
      }
    }

    return interestMap;
  }

  /**
   * 计算用户在feature上的interest
   * 
   * @param userWeightsMap
   * @param feaWeightsMap
   * @param timeDecayFactors
   * @return
   */
  private HashMap<String, float[]> calculateDefaultInterest(HashMap<String, float[]> userWeightsMap,
      HashMap<String, float[]> feaWeightsMap, float[] timeDecayFactors, int feaType) {

    // term ~ {用户在fea上的interest, 用户在fea上的weight和}
    HashMap<String, float[]> interestMap = new HashMap<String, float[]>();
    // 用户在所有时间桶所有fea上的weight总和
    float globalUserWeightSum = 0;
    // 用户在所有fea上的interest的总和
    float globalUserInterestSum = 0;
    float minInterest = Float.MAX_VALUE;
    for (String fea : userWeightsMap.keySet()) {
      String feaWithType = feaType + "_" + fea;
      if (!feaWeightsMap.containsKey(feaWithType)) {
        // skip inactive features
        continue;
      }

      float userWeightSum = 0;
      float interestWithDecay = 0;
      float[] feaWeights = feaWeightsMap.get(feaWithType);
      float[] userWeights = userWeightsMap.get(fea);
      for (int i = 0; i < userWeights.length; ++i) {
        if (userWeights[i] <= 0 || feaWeights[i] < 0.01) {
          continue;
        }
        
        if (this.useGlobalTermWeight) {
        	interestWithDecay += timeDecayFactors[i] * userWeights[i] * feaWeights[i];
        } else {
        	interestWithDecay += timeDecayFactors[i] * userWeights[i] / feaWeights[i];
        }
        userWeightSum += userWeights[i];
      }
      interestMap.put(fea, new float[] { interestWithDecay, userWeightSum });
      globalUserWeightSum += userWeightSum;
      globalUserInterestSum += interestWithDecay;
      if (minInterest > interestWithDecay) {
        minInterest = interestWithDecay;
      }
    }

    // 平滑
    globalUserInterestSum += 0.5f * minInterest;
    for (String fea : interestMap.keySet()) {
      if (globalUserInterestSum > 0) {
        interestMap.get(fea)[0] = interestMap.get(fea)[0] * globalUserWeightSum / globalUserInterestSum;
      } else {
        interestMap.get(fea)[0] = 0;
      }
    }

    return interestMap;
  }

  /**
   * 计算用户在feature上的interest (不使用feature的weight进行平滑)
   * 
   * @param userWeightsMap
   * @param timeDecayFactors
   * @return
   */
  private HashMap<String, float[]> calculateDefaultInterest(HashMap<String, float[]> userWeightsMap,
      float[] timeDecayFactors, int feaType) {

    // term ~ {用户在fea上的interest, 用户在fea上的weight和}
    HashMap<String, float[]> interestMap = new HashMap<String, float[]>();
    // 用户在所有时间桶所有fea上的weight总和
    float globalUserWeightSum = 0;
    // 用户在所有fea上的interest的总和
    float globalUserInterestSum = 0;
    float minInterest = Float.MAX_VALUE;
    for (String fea : userWeightsMap.keySet()) {
      float userWeightSum = 0;
      float interestWithDecay = 0;
      float[] userWeights = userWeightsMap.get(fea);
      for (int i = 0; i < userWeights.length; ++i) {
        interestWithDecay += timeDecayFactors[i] * userWeights[i];
        userWeightSum += userWeights[i];
      }
      interestMap.put(fea, new float[] { interestWithDecay, userWeightSum });
      globalUserWeightSum += userWeightSum;
      globalUserInterestSum += interestWithDecay;
      if (minInterest > interestWithDecay) {
        minInterest = interestWithDecay;
      }
    }

    // 平滑
    globalUserInterestSum += 0.5f * minInterest;
    for (String fea : interestMap.keySet()) {
      if (globalUserInterestSum > 0) {
        interestMap.get(fea)[0] = interestMap.get(fea)[0] * globalUserWeightSum / globalUserInterestSum;
      } else {
        interestMap.get(fea)[0] = 0;
      }
    }

    return interestMap;
  }

  /**
   * 通过均值计算interest
   * 
   * @param userWeightsMap
   * @param timeDecayFactors
   * @return
   */
  private HashMap<String, float[]> calculateInterestByAvg(HashMap<String, float[]> userWeightsMap) {
    // term ~ {用户在fea上的interest, 用户在fea上的click和}
    HashMap<String, float[]> interestMap = new HashMap<String, float[]>();
    for (String fea : userWeightsMap.keySet()) {
      float userWeightSum = 0;
      float[] userWeights = userWeightsMap.get(fea);
      for (int i = 0; i < userWeights.length; ++i) {
        userWeightSum += userWeights[i];
      }
      interestMap.put(fea, new float[] { userWeightSum / userWeights.length, userWeights.length });
    }
    return interestMap;
  }

  /**
   * 通过求和计算interest
   * 
   * @param userWeightsMap
   * @return
   */
  private HashMap<String, float[]> calculateInterestBySum(HashMap<String, float[]> userWeightsMap) {
    // term ~ {用户在fea上的interest, 用户在fea上的click和}
    HashMap<String, float[]> interestMap = new HashMap<String, float[]>();
    for (String fea : userWeightsMap.keySet()) {
      float userWeightSum = 0;
      float[] userWeights = userWeightsMap.get(fea);
      for (int i = 0; i < userWeights.length; ++i) {
        userWeightSum += userWeights[i];
      }
      interestMap.put(fea, new float[] { userWeightSum, userWeights.length });
    }
    return interestMap;
  }

  public void doInterestTuningByFeatureWeights() {
    for (int feaType : interestResults.keySet()) {
      if (!feaTuneWeights.containsKey(feaType)) {continue;}
      for (String fea : interestResults.get(feaType).keySet()) {
        // 带类目和前缀的feature要额外解析
        String feaStr = fea;
        if (feaType == ProfileFeatureType.TAG.getValue() || feaType == ProfileFeatureType.VIDEO_TAG.getValue() || feaType == ProfileFeatureType.NEG_TAG.getValue()) {
          String[] flds = fea.split(Contents.CATEGORY_SEP);
          if(flds.length == 2) {
            String[] tagFlds = flds[1].split(":");
            if (tagFlds.length == 2) {
              feaStr = tagFlds[1];
            }
          }
        } else if (feaType == ProfileFeatureType.KEYWORD.getValue() || feaType == ProfileFeatureType.NEG_KEYWORD.getValue()) {
          String[] flds = fea.split(Contents.CATEGORY_SEP);
          if(flds.length == 2) {
            feaStr = flds[1];
          }
        }
        
        if (!feaTuneWeights.get(feaType).containsKey(feaStr)) {continue;}
        double feaTuneWeight = feaTuneWeights.get(feaType).get(feaStr);
        for (int i = 0; i < interestResults.get(feaType).get(fea).length; ++i) {
          interestResults.get(feaType).get(fea)[i] *= feaTuneWeight;
        }
      }
    }
  }

  public static String convertReadTime(float readSeconds) {
    String readTimeRange;
    if (readSeconds <= 10 * 60) {
      readTimeRange = "VL";
    } else if (readSeconds > 10 * 60 && readSeconds <= 30 * 60) {
      readTimeRange = "L";
    } else if (readSeconds > 30 * 60 && readSeconds <= 60 * 60) {
      readTimeRange = "M";
    } else if (readSeconds > 60 * 60 && readSeconds <= 120 * 60) {
      readTimeRange = "H";
    } else {
      readTimeRange = "VH";
    }
    return readTimeRange;
  }

  public static String convertVisitFrequency(float visitNum) {
    String visitFreq;
    if (visitNum >= 3) {
      visitFreq = "H";
    } else if (visitNum >= 1 && visitNum < 3) {
      visitFreq = "M";
    } else {
      visitFreq = "L";
    }
    return visitFreq;
  }

  private float getInterest(int feaType, String fea, HashMap<Integer, HashMap<String, float[]>> interestResults) {
    float interest = 0;
    if (interestResults.containsKey(feaType) && interestResults.get(feaType).containsKey(fea)) {
      interest = interestResults.get(feaType).get(fea)[0];
    }
    return interest;
  }

  private HashMap<String, float[]> calcPoliticsTolerance(HashMap<Integer, HashMap<String, float[]>> interestResults) {
    HashMap<String, float[]> interestMap = new HashMap<String, float[]>();
    float dislike = getInterest(ProfileFeatureType.DISLIKE_POLITICS.getValue(), "2", interestResults);
    float tolerate = getInterest(ProfileFeatureType.TOLERATE_POLITICS.getValue(), "2", interestResults);
    float like = getInterest(ProfileFeatureType.LIKE_POLITICS.getValue(), "2", interestResults);
    float sum = dislike + tolerate + like;
    String tolerance = calcLowQualityItemTolerance(dislike, tolerate, like);
    if (tolerance == null) {
      return null;
    } else {
      interestMap.put(tolerance, new float[] { sum, sum });
      return interestMap;
    }
  }

  private HashMap<String, float[]> calcDirtyTolerance(HashMap<Integer, HashMap<String, float[]>> interestResults) {
    HashMap<String, float[]> interestMap = new HashMap<String, float[]>();
    float dislike = getInterest(ProfileFeatureType.DISLIKE_DIRTY.getValue(), "2", interestResults);
    float tolerate = getInterest(ProfileFeatureType.TOLERATE_DIRTY.getValue(), "2", interestResults);
    float like = getInterest(ProfileFeatureType.LIKE_DIRTY.getValue(), "2", interestResults);
    // 两性擦边球item
    float lxqgDislike = getInterest(ProfileFeatureType.DISLIKE_EMOTION.getValue(), "1", interestResults);
    float lxqgTolerate = getInterest(ProfileFeatureType.TOLERATE_EMOTION.getValue(), "1", interestResults);
    float lxqgLike = getInterest(ProfileFeatureType.LIKE_EMOTION.getValue(), "1", interestResults);
    float lxqgInfluence = 0.2f;
    lxqgDislike *= lxqgInfluence;
    lxqgTolerate *= lxqgInfluence;
    lxqgLike *= lxqgInfluence;

    float sum = dislike + tolerate + like + lxqgDislike + lxqgTolerate + lxqgLike;
    String tolerance = calcLowQualityItemTolerance(dislike + lxqgDislike, tolerate + lxqgTolerate, like + lxqgLike);
    if (tolerance == null) {
      return null;
    } else {
      interestMap.put(tolerance, new float[] { sum, sum });
      return interestMap;
    }
  }

  private HashMap<String, float[]> calcBluffingTitleTolerance(HashMap<Integer, HashMap<String, float[]>> interestResults) {
    HashMap<String, float[]> interestMap = new HashMap<String, float[]>();
    float dislike = getInterest(ProfileFeatureType.DISLIKE_BLUFFING_TITLE.getValue(), "2", interestResults);
    float tolerate = getInterest(ProfileFeatureType.TOLERATE_BLUFFING_TITLE.getValue(), "2", interestResults);
    float like = getInterest(ProfileFeatureType.LIKE_BLUFFING_TITLE.getValue(), "2", interestResults);
    float sum = dislike + tolerate + like;
    String tolerance = calcLowQualityItemTolerance(dislike, tolerate, like);
    if (tolerance == null) {
      return null;
    } else {
      interestMap.put(tolerance, new float[] { sum, sum });
      return interestMap;
    }
  }

  private String calcLowQualityItemTolerance(float dislikeNum, float tolerateNum, float likeNum) {
    float sum = dislikeNum + tolerateNum + likeNum;
    if (sum <= 3) {
      return "UNKNOWN";
    } else {
      if (dislikeNum / sum >= 0.1 || dislikeNum > likeNum || dislikeNum >= 3) {
        return "VL";
      } else if (dislikeNum / sum >= 0.05 || dislikeNum > 0.5 * likeNum || dislikeNum >= 1) {
        return "L";
      } else if (likeNum / sum >= 0.1 && likeNum >= 20 && likeNum > 2.0 * dislikeNum) {
        return "VH";
      } else if (likeNum / sum >= 0.1 && likeNum >= 5 && likeNum > dislikeNum) {
        return "H";
      } else {
        return "M";
      }
    }
  }

  public HashMap<String, float[]> getFeaWeightsMap() {
    return feaWeightsMap;
  }

  public void setFeaWeightsMap(HashMap<String, float[]> feaWeightsMap) {
    this.feaWeightsMap = feaWeightsMap;
  }

  public float getTimeDecayFactor() {
    return timeDecayFactor;
  }

  public void setTimeDecayFactor(float timeDecayFactor) {
    this.timeDecayFactor = timeDecayFactor;
  }

  public float[] getTimeDecayFactors() {
    return timeDecayFactors;
  }

  public void setTimeDecayFactors(float[] timeDecayFactors) {
    this.timeDecayFactors = timeDecayFactors;
  }

  public int getBucketNum() {
    return bucketNum;
  }

  public void setBucketNum(int bucketNum) {
    this.bucketNum = bucketNum;
  }

  public boolean isFeaWeightLoad() {
    return isFeaWeightLoad;
  }

  public void setFeaWeightLoad(boolean isFeaWeightLoad) {
    this.isFeaWeightLoad = isFeaWeightLoad;
  }

  public boolean useGlobalTermWeight() {
	  return this.useGlobalTermWeight;
  }
  
  public void setUseGlobalTermWeight(boolean useGlobalTermWeight) {
	  this.useGlobalTermWeight = useGlobalTermWeight;
  }
  
  public HashMap<Integer, InterestCalcMethods> getFeaInterestCalcMethodMap() {
    return feaInterestCalcMethodMap;
  }

  public void setFeaInterestCalcMethodMap(HashMap<Integer, InterestCalcMethods> feaInterestCalcMethodMap) {
    this.feaInterestCalcMethodMap = feaInterestCalcMethodMap;
  }

  public boolean isDebug() {
    return debug;
  }

  public void setDebug(boolean debug) {
    this.debug = debug;
  }

  public long getErrorBucketNum() {
    return errorBucketNum;
  }

  public void setErrorBucketNum(long errorBucketNum) {
    this.errorBucketNum = errorBucketNum;
  }

  public HashMap<Integer, HashMap<String, float[]>> getUserWeightsMap() {
    return userWeightsMap;
  }

  public void setUserWeightsMap(HashMap<Integer, HashMap<String, float[]>> userWeightsMap) {
    this.userWeightsMap = userWeightsMap;
  }

  public HashMap<Integer, HashMap<String, float[]>> getInterestResults() {
    return interestResults;
  }

  public void setInterestResults(HashMap<Integer, HashMap<String, float[]>> interestResults) {
    this.interestResults = interestResults;
  }

  public static Logger getLogger() {
    return logger;
  }

  public static DecimalFormat getDf() {
    return DF;
  }

  public boolean isDoFeatureWeightTuning() {
    return doFeatureWeightTuning;
  }

  public void setDoFeatureWeightTuning(boolean doFeatureWeightTuning) {
    this.doFeatureWeightTuning = doFeatureWeightTuning;
  }

  public HashMap<Integer, HashMap<String, Double>> getFeaTuneWeights() {
    return feaTuneWeights;
  }

  public void setFeaTuneWeights(HashMap<Integer, HashMap<String, Double>> feaTuneWeights) {
    this.feaTuneWeights = feaTuneWeights;
  }

}
