package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.google.common.base.Joiner;

/**
 * @author wangfei01
 * @date 2017/9/26
 */
public class PaddingUDF extends UDF {
    public String evaluate(String seperator, String defaultValue, Long maxLength, String text) {
        if (text != null) {
            String[] tokens = text.split(seperator);
            String[] paddings = new String[maxLength.intValue()];

            int beg = paddings.length - tokens.length;
            for (int i = 0; i < paddings.length; i++) {
                if (i >= beg && !"".equals(tokens[i - beg])) {
                    paddings[i] = tokens[i - beg];
                } else {
                    paddings[i] = defaultValue;
                }
            }
            return Joiner.on(seperator).join(paddings);
        }
        return null;
    }
}
