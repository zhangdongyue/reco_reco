package com.tudou.recommend.up.odps.newtd;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.newtd.entity.SwingItemPairOneUserInfo;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.math.BigInteger;
import java.util.*;

/**
 *  利用swing算法计算item-item的相似度
 *  Created by lvhl on 2017/7/7.
 *  @author lvhl
 */
public class SwingI2IA2BAcc {

    private static SwingI2IA2BAcc.MrArgContainer argContainer = new SwingI2IA2BAcc.MrArgContainer();
    private static int SIM_ALPHA = 1; // 弦木给的推荐取值1~3 即可
    private static boolean isDebug = false;

    public static class SwingI2IMapper extends MapperBase {
        private Record k2;
        private Record v2;
        private int maxUserKeep;
        private int maxUserBehavior = 1000;
        private int count = 0;
        private Map<String, Integer> itemKeepUserNum;
        private int isItem2Item = 1;

        @Override
        public void setup(TaskContext context) throws IOException {
            k2 = context.createMapOutputKeyRecord();
            v2 = context.createMapOutputValueRecord();
            JobConf jobConf = context.getJobConf();

            maxUserKeep = jobConf.getInt("maxUserKeep", 600);
            System.err.println("v0.5_maxUserKeep:" + maxUserKeep);
            int isPrintDebug = jobConf.getInt("isPrintDebug", 0);
            this.isItem2Item = jobConf.getInt("isItem2Item", 1);
            if (isPrintDebug == 1) {
                SwingI2IA2BAcc.isDebug = true;
            }
            System.err.println("isPrintDebug:" + SwingI2IA2BAcc.isDebug);
            maxUserBehavior =jobConf.getInt("maxUserBehavior", 1000);
            System.err.println("maxUserBehavior:" + maxUserBehavior);
            itemKeepUserNum = new HashMap<String, Integer>(700000);

        }

        @Override
        public void map(long recordNum, Record record, TaskContext context)
                throws IOException {
            //user
            if (StringUtils.isBlank(record.getString("imei")) ||
                    StringUtils.isBlank(record.getString("item_list"))) {
                context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
                        "empty_record").increment(1L);
                return;
            }
            String imei = record.getString("imei");
            String itemListStr = record.getString("item_list");
            String[] items = itemListStr.split(";", -1);
            if (items.length <= 1) return;
            if (items.length > maxUserBehavior) {
                context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
                        "big_user_counter").increment(1L);
                //System.err.println("imei:" + imei + ", itemList:" + itemListStr);
                //return;
            }
            if (items.length > 10) {
                items = SwingI2IA2BAcc.shuffleArray(items);
            }
            ArrayList<String[]> itemList = new ArrayList<String[]>(items.length);
            ArrayList<BigInteger> itemIdList = new ArrayList<BigInteger>(items.length);
            for (int i = 0; i < items.length && i < maxUserBehavior; ++i) {
                if (StringUtils.isBlank(items[i])) {
                    continue;
                }
                String[] flds = items[i].split(",");
                if (flds.length < 2) continue;
                String[] idFlds = flds[0].split("_", -1);
                if(idFlds.length < 1) continue;
                String itemid = idFlds[0];
                if ((idFlds[0].isEmpty() || idFlds[0].equals("0")) && idFlds.length == 2) {
                    itemid = idFlds[1];
                }
                if (!StringUtils.isNumeric(itemid)) {
                    System.err.println("imei:" + imei + ", itemid:" + itemid);
                    continue;
                }
                if (itemid.isEmpty() || itemid.equals("0")) {
                    continue;
                }
                if (itemKeepUserNum.containsKey(itemid)) {
                    Integer oriKeepUserNum = itemKeepUserNum.get(itemid);
                    if (oriKeepUserNum > maxUserKeep) {
                        continue;
                    }
                    itemKeepUserNum.put(itemid, oriKeepUserNum + 1);
                } else {
                    itemKeepUserNum.put(itemid, 1);
                }
                itemList.add(Arrays.copyOf(flds, flds.length));
                itemIdList.add(new BigInteger(itemid));
            }
            Collections.sort(itemIdList);
            String itemIdListStr = StringUtils.join(itemIdList, ";");
            if (SwingI2IA2BAcc.isDebug) {
                System.err.println(itemIdListStr);
            }

            if (itemList.size() == 0) return;
            for (int i = 0; i < itemList.size(); ++i) {
                String[] iFields = itemList.get(i);
                if (iFields.length < 2) continue;
                String itemId_i = iFields[0];
                if (iFields[0].indexOf('_') != -1) { // 是A2B的运算
                    String[] iItemidFlds = iFields[0].split("_", -1);
                    if (iItemidFlds.length < 2 || iItemidFlds[0].isEmpty() || iItemidFlds[0].equals("0")) continue; //不在A集合的item，不计算相似列表
                    itemId_i = iItemidFlds[0];
                }
                for (int j = 0; j < itemList.size(); ++j) {
                    if (i == j) {
                        continue;
                    }
                    String[] jFields = itemList.get(j);
                    if (jFields.length < 2) continue;
                    if (jFields.length == 3 && jFields[2].equals("0")) continue; // 不在最终的下发列表中，不出现在pair对的右边
                    String itemId_j = jFields[0];
                    if (jFields[0].indexOf('_') != -1) { // 是A2B的运算
                        String[] jItemidFlds = jFields[0].split("_", -1);
                        if (jItemidFlds.length < 2 || jItemidFlds[1].isEmpty() ||jItemidFlds[1].equals("0")) {
                            continue; //不在B集合的item，不计算相似列表
                        }
                        itemId_j = jItemidFlds[1];
                    }
                    if (1 == isItem2Item) { // 只输出升序的pair
                        if (!StringUtils.isNumeric(itemId_i) || !StringUtils.isNumeric(itemId_j)) {
                            System.err.println("imei:" + imei + ", itemId_i:" + itemId_i + ", itemId_j:" + itemId_j);
                            continue;
                        }
                        BigInteger big_i = new BigInteger(itemId_i);
                        BigInteger big_j = new BigInteger(itemId_j);
                        if (big_i.compareTo(big_j) >= 0)
                            continue;
                    }
                    k2.setString(0, itemId_i + "#" + itemId_j);
                    v2.setString("imei", imei); //用户标识
                    v2.setString("item_list", itemIdListStr); //I(u)的集合
                    v2.setString("itemJWeight", jFields[1]); // Item_J的
                    v2.setString("itemIWeight", iFields[1]);
                    context.write(k2, v2);
                    if (SwingI2IA2BAcc.isDebug) {
                        System.out.println(itemId_i + "#" + itemId_j + "\t" +
                                imei + "\t" +itemIdListStr + "\t" + jFields[1]);
                    }
                }
            }
        }

        private long getLong(Record record, String colName, long defaultValue) {
            Long ln = record.getBigint(colName);
            return ln == null ? defaultValue : ln.longValue();
        }

        private long getLong(Record record, String colName) {
            return getLong(record, colName, 0L);
        }

        private double getDouble(Record record, String colName,
                                 double defaultValue) {
            Double d = record.getDouble(colName);
            return d == null ? defaultValue : d.doubleValue();
        }

        private double getDouble(Record record, String colName) {
            return getDouble(record, colName, 0);
        }

        private String getString(Record record, String colName,
                                 String defaultValue) {
            String str = record.getString(colName);
            return str == null ? defaultValue : str;
        }

        private String getString(Record record, String colName) {
            return getString(record, colName, "");
        }
    }

    public static class SwringI2IReducer extends ReducerBase {
        private Record result;
        private int maxUserKeep;
        private int isNorm = 0; //weight存储的是item的Norm还是权重
        private int isItem2Item = 1;
        @Override
        public void setup(TaskContext context) throws IOException {
            result = context.createOutputRecord();
            JobConf jobConf = context.getJobConf();
            int isPrintDebug = jobConf.getInt("isPrintDebug", 0);
            if (isPrintDebug == 1) {
                SwingI2IA2BAcc.isDebug = true;
            }
            maxUserKeep = jobConf.getInt("maxUserKeep", 600);
            isNorm = jobConf.getInt("isNorm", 0);
            this.isItem2Item = jobConf.getInt("isItem2Item", 1);
            System.out.println("isPrintDebug:" + SwingI2IA2BAcc.isDebug);
            System.out.println("maxUserKeep:" + maxUserKeep);
            System.out.println("isNorm:" + isNorm);
        }

        @Override
        public void reduce(Record key, Iterator<Record> values,
                           TaskContext context) throws IOException {
            String itemInfoStr = "";
            ArrayList<SwingItemPairOneUserInfo> users = new ArrayList<SwingItemPairOneUserInfo>();
            String imei;
            String itemListStr;
            String itemJWeightStr;
            String itemIWeightStr;
            String keyStr = key.getString(0);
            String[] keyFlds = keyStr.split("#");
            if (keyFlds.length != 2) {
                if (SwingI2IA2BAcc.isDebug) {
                    System.err.println("key error:" + keyStr);
                }
                context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
                        "key_len_erro").increment(1L);
                return;
            }
            String itemI = keyFlds[0];
            String itemJ = keyFlds[1];
            if (SwingI2IA2BAcc.isDebug) {
                System.err.println("itemI:" + itemI + ", itemJ" + itemJ);
            }
            while (values.hasNext()) {
                Record record = values.next();
                imei = record.getString("imei");
                itemListStr = record.getString("item_list");
                itemJWeightStr = record.getString("itemJWeight");
                itemIWeightStr = record.getString("itemIWeight");
                SwingItemPairOneUserInfo userInfo = new SwingItemPairOneUserInfo();
                if (SwingI2IA2BAcc.isDebug) {
                    System.err.println("imei:" + imei + ", itemList:" + itemListStr + ", itemJWeight:" + itemJWeightStr);
                }
                if (!userInfo.parseFromStr(imei, itemListStr, itemJWeightStr, itemIWeightStr)) {
                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
                            "reduce_parse_pair_erro").increment(1L);
                    continue;
                }
                if (isNorm == 1) {
                    double tmpItemJWeight = userInfo.getItemJWeight();
                    //if (tmpItemJWeight > maxUserKeep) tmpItemJWeight = maxUserKeep;
                    double itemJWeight = 1.0 / Math.pow(1 + tmpItemJWeight, 0.5);
                    userInfo.setItemJWeight(itemJWeight);
                    double tmpItemIWeight = userInfo.getItemIWeight();
                    double itemIWeight = 1.0 / Math.pow(1 + tmpItemIWeight, 0.5);
                    userInfo.setItemIWeight(itemIWeight);
                }
                if (users.size() <= maxUserKeep) {
                    users.add(userInfo);
                } else {
                    break;
                }
            }
            double similarity = 0.0;
            double similarity_i = 0.0;
            if(SwingI2IA2BAcc.isDebug) {
                System.err.println("user size:" + users.size());
            }
            int commonUserSize = users.size();
            if (commonUserSize <= 1) return;
            for (int u = 0; u < commonUserSize; ++u) {
                SwingItemPairOneUserInfo userU = users.get(u);
                double weightU = userU.getUserWeight();
                for (int v = u + 1; v < commonUserSize; ++v) {
                    if (SwingI2IA2BAcc.isDebug) {
                        System.out.println("u:" + u + ", v:" + v);
                    }
                    SwingItemPairOneUserInfo userV = users.get(v);
                    double weightV = userV.getUserWeight();
                    double itemJWeight = userV.getItemJWeight();
                    double itemIWeight = userV.getItemIWeight();
                    int commonSetSize = SwingItemPairOneUserInfo
                            .getCommonSetSizeByOrderedList(userU.getUserItemSet(), userV.getUserItemSet());
                    similarity += weightU * weightV * itemJWeight / ((SwingI2IA2BAcc.SIM_ALPHA + commonSetSize) * 1.0);
                    if (1 == isItem2Item) {
                        similarity_i += weightU * weightV * itemIWeight / ((SwingI2IA2BAcc.SIM_ALPHA + commonSetSize) * 1.0);
                    }
                    if (SwingI2IA2BAcc.isDebug) {
                        System.err.println("item_i:" + itemI + ", item_j:" + itemJ + ", U:" + userU.getImei() + ", V:" + userV.getImei());
                        System.err.println("weightU:" + weightU + ", weightV:" + weightV + ", itemJWeight:" + itemJWeight);
                        System.err.println("commonSetSize:" + commonSetSize + ", similarity:" + similarity);
                    }
                }
            }
            result.setString("item_i", itemI);
            result.setString("item_j", itemJ);
            result.setDouble("similarity", similarity);
            if (SwingI2IA2BAcc.isDebug) {
                System.err.println("item_i:" + itemI + "item_j:" + itemJ + ", similarity:" + similarity);
            }
            context.write(result);
            if (1 == isItem2Item) {
                result.setString("item_i", itemJ);
                result.setString("item_j", itemI);
                result.setDouble("similarity", similarity_i);
                context.write(result);
            }
        }

    }

    public static void main(String[] args) throws OdpsException {
        JCommander cmder = new JCommander(argContainer, args);
        if (argContainer.isHelp()) {
            cmder.usage();
            System.exit(Contents.SUCCED_CODE);
        }
        Job job = new Job();
        // TODO: specify map output types
        job.setMapOutputKeySchema(SchemaUtils.fromString("item_i:string"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("imei:string,item_list:string,itemJWeight:string,itemIWeight:string"));

        // MrJobParamSetter.addInput(job, argContainer.getInput());
        MrJobParamSetter.addInput(job,
                argContainer.getInput(),
                new String[] { "imei", "item_list"});
        MrJobParamSetter.addOutput(job, argContainer.getOutput());
        // TODO: specify a mapper
        job.setMapperClass(SwingI2IA2BAcc.SwingI2IMapper.class);
        // TODO: specify a reducer
        job.setReducerClass(SwingI2IA2BAcc.SwringI2IReducer.class);
        job.setInt("maxUserKeep", argContainer.getMaxUserKeep());
        job.setInt("isPrintDebug", argContainer.getIsPrintDebug());
        job.setInt("isNorm", argContainer.getIsNorm());
        job.setInt("isItem2Item", argContainer.getIsItem2Item());
        job.setInt("maxUserBehavior", argContainer.getMaxUserBehavior());
        System.out.println("maxUserKeep:" + argContainer.getMaxUserKeep());
        System.out.println("isPrintDebug:" + argContainer.getIsPrintDebug());
        System.out.println("isNorm:" + argContainer.getIsNorm());
        System.out.println("maxUserBehavior:" + argContainer.getMaxUserBehavior());
        if (argContainer.getNumReducer() > 0) {
            MrJobParamSetter.setNumReduceTasks(job,
                    argContainer.getNumReducer());
        }
        MrJobParamSetter.setSplitSize(job, Long.parseLong(argContainer.getMapperSplitSize()));

        job.waitForCompletion();
        System.exit(job.isSuccessful() == true ? 0 : 1);
    }

    public static class MrArgContainer extends BaseMrArgContainer {
        /**
         * 一件商品从被关注的客户中选取参与计算推荐的人数最大值
         */
        @Parameter(names = "-isItem2Item", description = "是否是item2item推荐")
        private int isItem2Item = 1;

        @Parameter(names = "-maxUserKeep", description = "一件item从被关注的用户中选取参与计算推荐的人数最大值")
        private int maxUserKeep = 600;

        @Parameter(names = "-maxUserBehavior", description = "一个用户能关注的最多item数量")
        private int maxUserBehavior = 1000;

        @Parameter(names = "-isPrintDebug", description = "")
        private int isPrintDebug = 0;

        @Parameter(names = "-mapperSplitSize", description = "")
        private String mapperSplitSize = "256";

        @Parameter(names = "-isNorm", description = "item权重存储的是否是Norm")
        private int isNorm = 0;

        public int getMaxUserKeep() {
            return maxUserKeep;
        }

        public void setMaxUserKeep(int maxUserKeep) {
            this.maxUserKeep = maxUserKeep;
        }

        public int getIsPrintDebug() {
            return isPrintDebug;
        }

        public void setIsPrintDebug(int isPrintDebug) {
            this.isPrintDebug = isPrintDebug;
        }

        public String getMapperSplitSize() {
            return mapperSplitSize;
        }

        public void setMapperSplitSize(String mapperSplitSize) {
            this.mapperSplitSize = mapperSplitSize;
        }

        public int getIsNorm() {
            return isNorm;
        }

        public void setIsNorm(int isNorm) {
            this.isNorm = isNorm;
        }

        public int getIsItem2Item() {
            return isItem2Item;
        }

        public void setIsItem2Item(int isItem2Item) {
            this.isItem2Item = isItem2Item;
        }

        public int getMaxUserBehavior() {
            return maxUserBehavior;
        }

        public void setMaxUserBehavior(int maxUserBehavior) {
            this.maxUserBehavior = maxUserBehavior;
        }
    }

    public static String[] shuffleArray(String[] array) {
        int length = array.length;
        java.util.Random random = new java.util.Random();
        for (int i=0;i<length-1; i++) {
            int j = Math.abs(random.nextInt()%(length-i));
            String temp = array[i];
            array[i] = array[i+j];
            array[i+j] = temp;
        }

        return array;
    }
}
