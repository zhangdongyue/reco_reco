package com.tudou.recommend.up.odps.common.entity;

/**
 * 一些通用常量
 */
public class Contents {
  
  /**
   * 一二级类目分隔符
   */
  public static final String CATEGORY_SEP = "----";
  
  /**
   * 成功标识符
   */
  public static final int SUCCED_CODE = 0;
  
  /**
   * 失败标识符
   */
  public static final int FAILED_CODE = 1;

}
