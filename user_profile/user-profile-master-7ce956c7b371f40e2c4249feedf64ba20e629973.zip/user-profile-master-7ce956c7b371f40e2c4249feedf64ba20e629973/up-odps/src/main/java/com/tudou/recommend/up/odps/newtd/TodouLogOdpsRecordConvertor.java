package com.tudou.recommend.up.odps.newtd;

import com.aliyun.odps.data.Record;
import com.tudou.recommend.up.odps.newtd.entity.TudouLog;

public class TodouLogOdpsRecordConvertor {

	public boolean convertStrToRecord(Record record, String valueStr) {
		return false;
	}

	public String convertRecordToStr(Record record) {
		TudouLog log = new TudouLog();
		log.utdid = getString(record, "utdid").replaceAll("\t|\n|\r", " ");
		log.seId = getString(record, "se_id").replaceAll("\t|\n|\r", " ");
		log.serverTime = getString(record, "server_time").replaceAll(
				"\t|\n|\r", " ");
		log.vdoId = getString(record, "vdo_id").replaceAll("\t|\n|\r", " ");
		log.vdoLen = getDouble(record, "vdo_len");
		log.vdoTitle = getString(record, "vdo_title").replaceAll("\t|\n|\r",
				" ");
		log.vdoType = getString(record, "vdo_type").replaceAll("\t|\n|\r", " ");
		log.vdoDesc = getString(record, "vdo_desc").replaceAll("\t|\n|\r", " ");
		log.vdoEditorTitle = getString(record, "editor_title").replaceAll(
				"\t|\n|\r", " ");
		log.vdoTags = getString(record, "tags").replaceAll("\t|\n|\r", " ");
		log.ip = getString(record, "ip").replaceAll("\t|\n|\r", " ");
		log.mac = getString(record, "mac").replaceAll("\t|\n|\r", " ");
		log.imei = getString(record, "imei").replaceAll("\t|\n|\r", " ");
		log.idfa = getString(record, "idfa").replaceAll("\t|\n|\r", " ");
		log.netStatus = getString(record, "net_status").replaceAll("\t|\n|\r",
				" ");
		log.network = getString(record, "network").replaceAll("\t|\n|\r", " ");
		log.ts = getDouble(record, "ts");
		log.appName = getString(record, "app_name").replaceAll("\t|\n|\r", " ");
		return log.toString();
	}

	private String getString(Record record, String colName, String defaultValue) {
		String str = record.getString(colName);
		return str == null ? defaultValue : str;
	}

	private String getString(Record record, String colName) {
		return getString(record, colName, "");
	}

	private double getDouble(Record record, String colName, double defaultValue) {
		Double d = record.getDouble(colName);
		return d == null ? defaultValue : d.doubleValue();
	}

	private double getDouble(Record record, String colName) {
		return getDouble(record, colName, 0);
	}

	private long getLong(Record record, String colName, long defaultValue) {
		Long ln = record.getBigint(colName);
		return ln == null ? defaultValue : ln.longValue();
	}

	private long getLong(Record record, String colName) {
		return getLong(record, colName, 0L);
	}
}
