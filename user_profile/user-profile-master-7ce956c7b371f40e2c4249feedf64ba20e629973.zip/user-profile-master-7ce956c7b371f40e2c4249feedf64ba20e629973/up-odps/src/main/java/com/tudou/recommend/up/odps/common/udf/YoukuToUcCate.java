package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Wangfei on 2017/5/16.
 */
public class YoukuToUcCate extends UDF {
    private Map<String, String> cateMap = new HashMap<>();

    public YoukuToUcCate() {
        manualMap();
    }

    private void manualMap() {
        cateMap.put("生活", "社会");
        cateMap.put("纪实", "记录短片");
        cateMap.put("纪录片", "记录短片");
        cateMap.put("时尚", "时尚");
        cateMap.put("搞笑", "搞笑");
        cateMap.put("旅游", "旅游");
        cateMap.put("母婴", "育儿");
        cateMap.put("汽车", "汽车");
        cateMap.put("网剧", "影视剧");
        cateMap.put("电影", "影视剧");
        cateMap.put("电视剧", "影视剧");
        cateMap.put("娱乐", "娱乐");
        cateMap.put("亲子", "育儿");
        cateMap.put("网络剧", "影视剧");
        cateMap.put("拍货", "记录短片");
        cateMap.put("音乐", "音乐");
        cateMap.put("动漫", "动漫");
        cateMap.put("综艺", "综艺");
        cateMap.put("财富", "财经");
        cateMap.put("教育", "教育");
        cateMap.put("微电影", "影视剧");
        cateMap.put("科技", "科技");
        cateMap.put("游戏", "游戏");
        cateMap.put("体育", "体育");
    }

    public String evaluate(String youkuCate) {
        if (youkuCate == null) {
            return null;
        }
        return cateMap.get(youkuCate);
    }
}
