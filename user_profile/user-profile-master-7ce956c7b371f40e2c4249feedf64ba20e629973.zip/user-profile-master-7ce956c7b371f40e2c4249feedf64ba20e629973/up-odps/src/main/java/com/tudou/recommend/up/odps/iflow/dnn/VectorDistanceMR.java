package com.tudou.recommend.up.odps.iflow.dnn;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.google.common.base.Joiner;
import com.google.common.collect.MinMaxPriorityQueue;
import com.tudou.recommend.up.odps.common.util.BaseArgContainer;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

/**
 * The MR will create user watch sequences according to click time.
 *
 * @author wangfei01
 * @date 2017/8/24
 */
public class VectorDistanceMR {
    private static ArgumentContainer argument = new ArgumentContainer();

    public static class Sim {
        public int index;
        public float sim;

        @Override
        public String toString() {
            return index + ":" + sim;
        }

        public Sim(int index, float sim) {
            this.index = index;
            this.sim = sim;
        }
    }

    public static class ItemVector {
        private List<float[]> vectors = new ArrayList<>();
        private List<Integer> indices = new ArrayList<>();
        private int maxTopSize = 500;

        public ItemVector(int maxTopSize) {
            this.maxTopSize = maxTopSize;
        }

        public static float[] fromString(String value) {
            if (value != null) {
                String[] dims = value.split(",");
                float[] vectorValues = new float[dims.length];
                for (int i = 0; i < dims.length; i++) {
                    vectorValues[i] = Float.parseFloat(dims[i]);
                }
                return vectorValues;
            }
            return null;
        }

        public static float dotProduct(float[] left, float[] right,int length) {
            float norm = 0;
            for (int i = 0; i < length ; i += 8) {
                float norm1 = left[i] * right[i];
                float norm2 = left[i + 1] * right[i + 1];
                float norm3 = left[i + 2] * right[i + 2];
                float norm4 = left[i + 3] * right[i + 3];
                float norm5 = left[i + 4] * right[i + 4];
                float norm6 = left[i + 5] * right[i + 5];
                float norm7 = left[i + 6] * right[i + 6];
                float norm8 = left[i + 7] * right[i + 7];
                norm += (norm1 + norm2 + norm3 + norm4 + norm5 + norm6 + norm7 + norm8);
            }
            return norm;
        }

        public void add(int index, String value) {
            float[] vector = fromString(value);
            if (vector != null) {
                vectors.add(vector);
                indices.add(index);
            }
        }

        public MinMaxPriorityQueue<Sim> sim(String vector) {
            MinMaxPriorityQueue<Sim> topSim = MinMaxPriorityQueue.orderedBy(new Comparator<Sim>() {
                @Override
                public int compare(Sim o1, Sim o2) {
                    if (o1.sim == o2.sim) {
                        return 0;
                    } else if (o1.sim > o2.sim) {
                        return -1;
                    } else {
                        return 1;
                    }
                }
            }).maximumSize(maxTopSize).create();
            float[] left = fromString(vector);
            int length = left.length;
            int vectorSize = vectors.size();
            for (int i = 0; i < vectorSize; i++) {
                float[] right = vectors.get(i);
                int index = indices.get(i);
                float dot = dotProduct(left, right,length);
                topSim.add(new Sim(index, dot));
            }
            return topSim;
        }
    }

    public static class ReadMapper extends MapperBase {
        private Logger logger = LoggerFactory.getLogger(this.getClass());
        private Record output;
        private ItemVector vector;
        private int count = 0;
        private StopWatch watch = new StopWatch();

        @Override
        public void setup(TaskContext context) throws IOException {
            output = context.createOutputRecord();
            JobConf jobConf = context.getJobConf();
            String itemEmbTable = jobConf.get("item.emb.table");
            int maxTopSize = jobConf.getInt("max.top.size", 500);
            vector = new ItemVector(maxTopSize);
            loadVector(context, itemEmbTable);
            watch.start();
        }

        public void loadVector(TaskContext context, String resourceName) throws IOException {
            Iterator<Record> table = context.readResourceTable(resourceName);
            while (table.hasNext()) {
                Record record = table.next();
                String index = record.getString("userid");
                String vec = record.getString("predict");
                vector.add(Integer.parseInt(index), vec);
            }
            logger.info("Finish load item vector.");
            logger.info("item vector size is {}", vector.indices.size());
        }

        public void map(long key, Record record, TaskContext context) throws IOException {
            String userId = record.getString("userid");
            String vec = record.getString("predict");
            MinMaxPriorityQueue<Sim> topSim = vector.sim(vec);
            for (Sim sim : topSim) {
                output.setString("userid", userId);
                output.setString("itemid", "" + sim.index);
                output.setDouble("sim", (double) sim.sim);
                context.write(output);
            }
            count++;
            if (count % 100 == 0) {
                watch.stop();
                long span = watch.getTime();
                logger.info("total size {}, avg spend {} ms", count, span / 100);
                watch.reset();
                watch.start();
            }
        }
    }


    public static void main(String[] args) throws OdpsException {
        JCommander commander = new JCommander(argument);
        commander.parse(args);
        Job job = new Job();
        job.set("item.emb.table", argument.getItemEmbTable());
        job.setInt("max.top.size", argument.getMaxTopSize());

        MrJobParamSetter.addInput(job, argument.getInput(), new String[]{"userid", "predict"});
        MrJobParamSetter.addOutput(job, argument.getOutput());
        job.setMapperClass(ReadMapper.class);
        job.setNumReduceTasks(0);
        boolean flag = job.waitForCompletion();
        if (!flag) {
            System.exit(1);
        }
    }

    public static class ArgumentContainer extends BaseArgContainer {
        @Parameter(names = "-itemEmbTable")
        private String itemEmbTable;

        @Parameter(names = "-maxTopSize")
        private Integer maxTopSize = 500;

        public String getItemEmbTable() {
            return itemEmbTable;
        }

        public void setItemEmbTable(String itemEmbTable) {
            this.itemEmbTable = itemEmbTable;
        }

        public Integer getMaxTopSize() {
            return maxTopSize;
        }

        public void setMaxTopSize(Integer maxTopSize) {
            this.maxTopSize = maxTopSize;
        }
    }
}
