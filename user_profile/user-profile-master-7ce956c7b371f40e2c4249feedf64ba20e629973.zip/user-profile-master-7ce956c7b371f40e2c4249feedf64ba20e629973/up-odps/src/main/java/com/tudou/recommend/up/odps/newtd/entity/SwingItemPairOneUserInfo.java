package com.tudou.recommend.up.odps.newtd.entity;

import org.apache.commons.lang3.StringUtils;

import java.math.BigInteger;
import java.util.ArrayList;

/**
 * itemI, itemJ, userU, I(u),
 * Created by lvhl on 2017/7/9.
 */
public class SwingItemPairOneUserInfo {
    private String imei = ""; // 用户标识
    private ArrayList<BigInteger> userItemSet; // 用户访问过的item集合
    private double userWeight = 1.0; // 用户权重
    private double itemJWeight = 1.0; // 用户权重
    private double itemIWeight = 1.0;
    private static int ALPHA = 3;


    public SwingItemPairOneUserInfo() {
    }

    public String toString() {
        return toString("\t");
    }

    public String toString(String sep) {
        StringBuilder bld = new StringBuilder();
        bld.append(imei).append(sep).append(userItemSet.size())
                .append(userWeight).append(userItemSet.toString());

        return bld.toString();
    }

    public boolean parseFromStr(String imei, String itemList, String itemJWeight, String itemIWeight) {
        if (imei == null || itemList == null || itemJWeight == null) {
            //System.err.println("imei:" + imei + ", itemList:" + itemList + ", itemJWeight:" + itemJWeight);
            return false;
        }

        this.imei = imei;
        String[] items = itemList.split(";");
        if (items.length < 1) {
            //System.err.println("items length:" + items.length + ", itemList:" + itemList);
            return false;
        }
        userItemSet = new ArrayList<BigInteger>(items.length);
        for (int i = 0; i < items.length; ++i) {
            if (StringUtils.isBlank(items[i])) continue;
            if (items[i].length() > 0) {
                userItemSet.add(new BigInteger(items[i]));
            }
        }
        this.userWeight = 1.0 / Math.sqrt(SwingItemPairOneUserInfo.ALPHA + userItemSet.size());
        this.itemJWeight = Double.parseDouble(itemJWeight);
        this.itemIWeight = Double.parseDouble(itemIWeight);
        return true;
    }

    public static int getCommonSetSizeByOrderedList(ArrayList<BigInteger> A, ArrayList<BigInteger> B) {
        int idxFirst = 0;
        int idxSecond = 0;
        int commonElementNum = 0;
        while (idxFirst < A.size() && idxSecond < B.size()) {
            while (idxFirst < A.size() && idxSecond < B.size()  && A.get(idxFirst).compareTo(B.get(idxSecond)) == -1) {
                ++idxFirst;
            }
            while (idxFirst < A.size() && idxSecond < B.size()  && B.get(idxSecond).compareTo(A.get(idxFirst)) == -1) {
                ++idxSecond;
            }
            if (idxFirst < A.size() && idxSecond < B.size() && A.get(idxFirst).equals(B.get(idxSecond))) {
                ++commonElementNum;
                ++idxFirst;
                ++idxSecond;
            }
        }
        return commonElementNum;
    }

    public String getImei() {
        return imei;
    }

    public ArrayList<BigInteger> getUserItemSet() {
        return userItemSet;
    }

    public double getUserWeight() {
        return userWeight;
    }

    public double getItemJWeight() {
        return itemJWeight;
    }

    public void setItemJWeight(double itemJWeight) {
        this.itemJWeight = itemJWeight;
    }

	public double getItemIWeight() {
        return itemIWeight;
    }

    public void setItemIWeight(double itemIWeight) {
        this.itemIWeight = itemIWeight;
    }
}
