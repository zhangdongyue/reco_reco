package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDFException;
import com.aliyun.odps.udf.UDTF;
import com.aliyun.odps.udf.annotation.Resolve;
import com.google.common.base.Joiner;
import com.google.common.base.Predicate;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Created by pharosa on 2017/7/20.
 */
public class TagDiffUDTF extends UDTF {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public void process(Object[] args) throws UDFException {
        int retain = Integer.parseInt(args[0].toString());
        String splitter = args[1].toString();
        String separator = args[2].toString();
        Object[] output = new Object[retain + 8];
        Object[] result = evaluate(args[retain + 3], args[retain + 4], splitter, separator);
        System.arraycopy(args, 3, output, 0, retain);
        System.arraycopy(result, 0, output, retain, 8);
        forward(output);
    }

    class TagNode {
        public String tagName;
        public Double tagWeight;
        public Double tagConfident;

        public TagNode(String tagName, Double tagWeight, Double tagConfident) {
            this.tagName = tagName;
            this.tagWeight = tagWeight;
            this.tagConfident = tagConfident;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            TagNode tagNode = (TagNode) o;

            return tagName != null ? tagName.equals(tagNode.tagName) : tagNode.tagName == null;
        }

        @Override
        public int hashCode() {
            return tagName != null ? tagName.hashCode() : 0;
        }

        @Override
        public String toString() {
            return String.format("%s:%f:%f", tagName, tagWeight, tagConfident);
        }
    }


    class TagNodeWeightComparator implements Comparator<TagNode> {

        @Override
        public int compare(TagNode o1, TagNode o2) {
            if (o1 == null && o2 == null) {
                return 0;
            } else if (o1 == null && o2 != null) {
                return 1;
            } else if (o1 != null && o2 == null) {
                return -1;
            }
            Double leftWeight = o1.tagWeight;
            Double rightWeight = o2.tagWeight;
            if (leftWeight == null && rightWeight == null) {
                return 0;
            } else if (leftWeight == null && rightWeight != null) {
                return 1;
            } else if (leftWeight != null && rightWeight == null) {
                return -1;
            }
            return -leftWeight.compareTo(rightWeight);
        }

    }

    public Object[] evaluate(Object left, Object right, Object splitter, Object separator) {
        Object[] result = new Object[8];
        TagNodeWeightComparator weightComparator = new TagNodeWeightComparator();
        Set<TagNode> leftSet = new HashSet<>();
        Set<TagNode> rightSet = new HashSet<>();
        if (left == null && right == null) {
            return result;
        }
        if (left != null) {
            String[] leftTags = left.toString().trim().split(splitter.toString());
            for (String tag : leftTags) {
                String[] info = tag.trim().split(separator.toString());
                if (info.length >= 3) {
                    TagNode node = new TagNode(info[0], Double.parseDouble(info[1]), Double.parseDouble(info[2]));
                    leftSet.add(node);
                }
            }
        }
        if (right != null) {
            String[] rightTags = right.toString().trim().split(splitter.toString());
            for (String tag : rightTags) {
                String[] info = tag.trim().split(separator.toString());
                if (info.length >= 3) {
                    TagNode node = new TagNode(info[0], Double.parseDouble(info[1]), Double.parseDouble(info[2]));
                    rightSet.add(node);
                }
            }
        }

        Sets.SetView<TagNode> leftOnly = Sets.difference(leftSet, rightSet);
        Sets.SetView<TagNode> rightOnly = Sets.difference(rightSet, leftSet);
        result[0] = String.valueOf(leftOnly.size());
        result[1] = leftOnly.size() == 0 ? null : Joiner.on(",\n").join(leftOnly);
        result[2] = String.valueOf(rightOnly.size());
        result[3] = rightOnly.size() == 0 ? null : Joiner.on(",\n").join(rightOnly);

        final Sets.SetView<TagNode> intersection = Sets.intersection(leftSet, rightSet);
        List<TagNode> leftIntersection = Lists.newArrayList(Sets.filter(leftSet, new Predicate<TagNode>() {
            @Override
            public boolean apply(TagNode input) {
                return intersection.contains(input);
            }
        }));

        ArrayList<TagNode> rightIntersection = Lists.newArrayList(Sets.filter(rightSet, new Predicate<TagNode>() {
            @Override
            public boolean apply(TagNode input) {
                return intersection.contains(input);
            }
        }));

        Collections.sort(leftIntersection, weightComparator);
        Collections.sort(rightIntersection, weightComparator);
        int wrongOrder = 0;
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < leftIntersection.size(); i++) {
            TagNode leftTag = leftIntersection.get(i);
            TagNode rightTag = rightIntersection.get(i);
            if (!leftTag.equals(rightTag)) {
                wrongOrder++;
                builder.append("<")
                        .append(i + 1)
                        .append(">:")
                        .append(leftTag)
                        .append("->")
                        .append(rightTag)
                        .append(",\n");
            }
        }

        result[4] = String.valueOf(intersection.size());
        result[5] = String.valueOf(wrongOrder);
        result[6] = builder.toString();
        result[7] = wrongOrder == 0 ? (left == right ? "1" : "0") : "0";
        return result;
    }
}
