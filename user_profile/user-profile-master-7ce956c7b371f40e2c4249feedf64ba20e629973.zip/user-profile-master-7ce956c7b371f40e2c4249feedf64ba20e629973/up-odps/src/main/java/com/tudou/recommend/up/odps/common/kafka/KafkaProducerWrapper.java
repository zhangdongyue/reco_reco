package com.tudou.recommend.up.odps.common.kafka;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

// https://cwiki.apache.org/confluence/display/KAFKA/0.8.0+Producer+Example
// 本机一定要 配置 host 映射 zookeeper， broker， 否则可能获取meta topic 信息失败
// New Producer in 0.8.2:
// http://kafka.apache.org/082/javadoc/index.html?org/apache/kafka/clients/producer/KafkaProducer.html

public class KafkaProducerWrapper<VALUE_TYPE> {
  public static final Logger logger = LoggerFactory.getLogger(KafkaProducerWrapper.class);
  private Properties props = null;
  private ProducerConfig config = null;
  private Producer<String, VALUE_TYPE> producer = null;

  /**
   * @param kafkaServerAddress: Defines where the Producer can find a one or more Brokers to
   *        determine the Leader for each topic. This does not need to be the full set of Brokers in
   *        your cluster but should include at least two in case the first Broker is not available.
   *        examples: "broker1:9092,broker2:9092"
   */
  public KafkaProducerWrapper(String kafkaServerAddress) {
    props = new Properties();
    props.put("metadata.broker.list", kafkaServerAddress);
    // 没有做任何处理
    props.put("serializer.class", "kafka.serializer.DefaultEncoder");
    props.put("partitioner.class", "com.shenma.wolong.kafka.SimplePartitioner");
    props.put("request.required.acks", "1");
    props.put("message.max.bytes", String.valueOf(1024 * 1024 * 64));

    init();
  }

  public KafkaProducerWrapper(Properties props) {
    this.props = props;
    init();
  }

  private void init() {
    config = new ProducerConfig(props);
    this.producer = new Producer<String, VALUE_TYPE>(config);
  }

  public void closeProducer() {
    try {
      producer.close();
    } catch (Exception e) {
      // ignore any exception info
    }
    return;
  }

  /**
   * 
   * @param topic
   * @param partitionKey: 分区用的key, 可以为 null or empty string
   * @param msg： 实际发送的数据
   * @return
   */
  public boolean sendMsg(String topic, String partitionKey, VALUE_TYPE msg) {
    boolean status = true;
    KeyedMessage<String, VALUE_TYPE> data =
        new KeyedMessage<String, VALUE_TYPE>(topic, null, partitionKey, msg);
    try {
      producer.send(data);
    } catch (Exception e) {
      status = false;
      logger.warn("msg: " + e.getMessage(), e);
    }
    return status;
  }

  /**
   * 
   * @param topic
   * @param msgs: 每一个 pair 的 left 为 分区用的 key, right 为 实际发送的数据
   * @return
   */
  public boolean sendMsg(String topic, List<Pair<String, VALUE_TYPE>> msgs) {
    boolean status = true;
    List<KeyedMessage<String, VALUE_TYPE>> datas =
        new ArrayList<KeyedMessage<String, VALUE_TYPE>>();
    for (Pair<String, VALUE_TYPE> pair : msgs) {
      KeyedMessage<String, VALUE_TYPE> data =
          new KeyedMessage<String, VALUE_TYPE>(topic, null, pair.getLeft(), pair.getRight());
      datas.add(data);
    }
    try {
      producer.send(datas);
    } catch (Exception e) {
      status = false;
    }
    return status;
  }

  // bin/kafka-topics.sh --create --zookeeper 10.3.5.55:2181,10.3.5.48:2181,10.3.5.70:2181/kafka --replication-factor 1 --partitions 9 --topic test.topic
  public static void main(String[] args) {
    String topic = "test.topic";
    String kafkaServerAddress = "10.3.5.55:9092,10.3.5.70:9092";

    KafkaProducerWrapper<byte[]> producer = new KafkaProducerWrapper<>(kafkaServerAddress);

    logger.info("finished");
  }
}
