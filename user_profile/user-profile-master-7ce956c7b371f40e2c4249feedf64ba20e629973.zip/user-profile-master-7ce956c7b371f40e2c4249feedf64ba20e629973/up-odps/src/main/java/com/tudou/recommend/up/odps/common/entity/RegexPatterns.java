package com.tudou.recommend.up.odps.common.entity;

import java.util.regex.Pattern;

/**
 * 常用正则表达式pattern
 * @author hezhimin
 *
 */
public class RegexPatterns {
  /**
   * IDFA正则表达式
   */
  public static final String IDFA_REGEX = "^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$";
  /**
   *  IDFV正则表达式
   */
  public static final String IDFV_REGEX = "^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$";
  /**
   *  IMEI正则表达式
   */
  public static final String IMEI_REGEX = "^[0-9]{15}(,[0-9]{15})*$";
  /**
   *  mac正则表达式
   */
  public static final String MAC_REGEX = "^([0-9A-Fa-f]{2}[:]){5}([0-9A-Fa-f]{2})$";

  /**
   * IDFA pattern
   */
  public static final Pattern IDFA_PATTERN = Pattern.compile(IDFA_REGEX);
  /**
   * IDFV pattern
   */
  public static final Pattern IDFV_PATTERN = Pattern.compile(IDFV_REGEX);
  /**
   * IMEI pattern
   */
  public static final Pattern IMEI_PATTERN = Pattern.compile(IMEI_REGEX);
  /**
   * MAC pattern
   */
  public static final Pattern MAC_PATTERN = Pattern.compile(MAC_REGEX);
}
