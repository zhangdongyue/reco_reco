package com.tudou.recommend.up.odps.iflow;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.tudou.recommend.up.odps.iflow.util.FeatureWeightCalculator;

/**
 * calculate global feature weight.(count sum of users for each feature)
 * @author jinchanghu
 * @date 2017年7月11日 下午6:10:36
 */
public class CountFeatureWeight {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class UserFeatureWeightMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private FeatureWeightCalculator calculator;
		
		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			calculator = new FeatureWeightCalculator();
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			// input format
			// appname-userId ~ feaType ~ fea ~ [bucket : weightSum : clickSum]

			int feaType = Integer.parseInt(record.getString(1));
			if (!calculator.isFeatureAllowed(feaType)) {
				return;
			}
			
			String feaWithType = feaType + "\t" + record.getString(2);
			String userId = record.getString(0);
			String weightClick = record.getString(3);
			
			if (userId == null || weightClick == null) {
				return;
			}
			
			StringBuilder builder = new StringBuilder();
			if(!weightClick.isEmpty() && !userId.isEmpty()) {
				builder.append(feaWithType);	
				builder.append("\t");
				
				builder.append(userId);	
				builder.append("\t");
				
				String[] buckets = weightClick.split(" ", -1);
				for (String str : buckets) {
					String[] numbers = str.split(":", -1);
					String bucket = numbers[0];
					builder.append(bucket);
					builder.append(" ");
				}
			}
			
			k2.setString(0, feaWithType);
			v2.setString(0, builder.toString().trim());	// featureWithType\tUserID\tBuckets
			context.write(k2, v2);
		}
	}

	/**
	 * calculate global feature weight(hot factor)
	 * use different method to calculate long and short video hot factor. 
	 * @author jinchanghu
	 * @date 2017年7月11日 下午6:10:07
	 */
	public static class FeaWeightReducer extends ReducerBase {
		private Record result;
		private static final DecimalFormat DF = DataFormatUtil.getDefaultDecimalFormater();
		
		// 各term在不同时间桶内的weight和
		private HashMap<String, HashMap<Integer, Double>> weightSumMap = new HashMap<String, HashMap<Integer, Double>>();
		
		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
		}

		@Override
		public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
			
			// 计算每个term的不同时间桶内的用户数
			while (values.hasNext()) {
				Record r = values.next();
				String valueStr = r.getString(0);
				if (valueStr == null) {
					continue;
				}
				
				String[] fields = valueStr.split("\t", -1);
				if (fields.length != 4) {
					continue;
				}
				
				String termWithType = fields[0] + "\t" + fields[1];
				String[] buckets = fields[3].split(" ", -1);
				
				if (!weightSumMap.containsKey(termWithType)) {
					weightSumMap.put(termWithType, new HashMap<Integer, Double>());
				}
				
				for (String str : buckets) {
					int bucket = Integer.parseInt(str);
					
					// 累加weight
					if (!weightSumMap.get(termWithType).containsKey(bucket)) {
						weightSumMap.get(termWithType).put(bucket, 0.0);
					}
					weightSumMap.get(termWithType).put(bucket, weightSumMap.get(termWithType).get(bucket) + 1.0);
				}
			}
		}
		
		@Override
		public void cleanup(TaskContext context) throws IOException {
			// output
			StringBuilder builder = new StringBuilder();
			for (String termWithType : weightSumMap.keySet()) {
				if (weightSumMap.get(termWithType).size() == 0) {
					continue;
				}
				builder.delete(0, builder.length());
				for (int bucket : weightSumMap.get(termWithType).keySet()) {
					if (builder.length() > 0) {
						builder.append(" ");
					}
					builder.append(bucket);
					builder.append(":");
					builder.append(DF.format(weightSumMap.get(termWithType).get(bucket)));
				}
				String[] splits = termWithType.split("\t", -1);
				result.setString(0, splits[0]);// feature_type
				result.setString(1, splits[1]);// feature
				result.setString(2, builder.toString());
				context.write(result);
			}
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils
				.fromString("user_id:string,feature_type:string,feature:string"));
		
		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {"user_id", "feature_type", "feature", "weight_click" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		
		// TODO: specify a mapper
		job.setMapperClass(UserFeatureWeightMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(FeaWeightReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {

		@Parameter(names = "-ctrSmooth", description = "whether use category ctr to smooth term weight")
		private int ctrSmooth = 0;

		@Parameter(names = "-inactiveThreshold", description = "")
		private String inactiveThreshold = "0";

		@Parameter(names = "-minWeight", description = "")
		private String minWeight = "0.5";

		@Parameter(names = "-maxWeight", description = "")
		private String maxWeight = "1.0";
		
		@Parameter(names = "-orderType", description = "global feature weight order type: (long/short)")
		private String orderType = "short_video";

		public int getCtrSmooth() {
			return ctrSmooth;
		}

		public void setCtrSmooth(int ctrSmooth) {
			this.ctrSmooth = ctrSmooth;
		}

		public String getInactiveThreshold() {
			return inactiveThreshold;
		}

		public void setInactiveThreshold(String inactiveThreshold) {
			this.inactiveThreshold = inactiveThreshold;
		}

		public String getMinWeight() {
			return minWeight;
		}

		public void setMinWeight(String minWeight) {
			this.minWeight = minWeight;
		}

		public String getMaxWeight() {
			return maxWeight;
		}

		public void setMaxWeight(String maxWeight) {
			this.maxWeight = maxWeight;
		}
		
		public String getOrderType() {
			return this.orderType;
		}
		
		public void setOrderType(String orderType) {
			this.orderType = orderType;
		}
	}
}
