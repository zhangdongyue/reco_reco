package com.tudou.recommend.up.odps.common.kafka;

import com.tudou.recommend.up.odps.common.util.CityHash;
import kafka.producer.Partitioner;
import kafka.utils.VerifiableProperties;

import java.nio.charset.StandardCharsets;

public class SimplePartitioner implements Partitioner {
    public SimplePartitioner(VerifiableProperties props) {

    }

    public int partition(Object key, int numPartitions) {
        int partition;
        long hash;
        byte[] keyBytes;
        if (key instanceof String) {
            keyBytes = ((String) key).getBytes(StandardCharsets.UTF_8);
        } else if (key instanceof byte[]) {
            keyBytes = (byte[]) key;
        } else {
            // 不知道是什么类型的key，直接用0分区
            return 0;
        }
        hash = Math.abs(CityHash.cityHash64(keyBytes, 0, keyBytes.length));
        partition = (int) (hash % numPartitions);
        return partition;
    }
}
