package com.tudou.recommend.up.odps.common.entity;

/**
 * 画像设备类型标识
 * @author hezhimin
 *
 */
public class ProfileDeviceIdentity {
  /**
   * 喜刷刷内部用户ID，基于UTDID计算得出
   */
  public static final String XSS_USER_ID = "uid";
  /**
   * ios设备icloud id
   */
  public static final String ICLOUD_ID = "uic";
  /**
   * utdid
   */
  public static final String UTDID = "utd";
  /**
   * imei
   */
  public static final String IMEI = "im";
  /**
   * ios设备idfa
   */
  public static final String IDFA = "idfa";
  /**
   * Android存imei，ios存idfa
   */
  public static final String IMEI_OR_IDFA = "imfa";
  /**
   * SN, UC公参中sn号由|分隔的3部分构成，取中间部分和神马大搜user id匹配
   */
  public static final String SN = "sn";
  /**
   * 集团AID
   */
  public static final String AID = "aid";
  
}
