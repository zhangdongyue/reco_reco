package com.tudou.recommend.up.odps.common.proto;

import com.google.protobuf.GeneratedMessage;
import com.tudou.recommend.up.odps.common.entity.interest.InterestElem;

import java.util.Map;

/**
 * Interface for generating user profile into protobuf format.
 *
 * @author wangfei01
 */
public interface IProtoGenerate {
    /**
     * The feature map contains all feature extract from logs.
     *
     * @param featureMap collected features.
     * @return generated protobuf message.
     */
    GeneratedMessage generate(Map<Integer, Map<Integer, InterestElem>> featureMap);
    
    /**
     * The feature map contains all feature extract from logs.
     *
     * @param featureMap collected features.
     * @return generated protobuf message.
     */
    GeneratedMessage generateUgc(Map<Integer, Map<Integer, InterestElem>> featureMap);

    /**
     * Parse proto from pure bytes array.
     *
     * @param bytes passed-in bytes array.
     * @return Proto object.
     */
    GeneratedMessage parse(byte[] bytes);


    /**
     * Parse proto into json string.
     *
     * @param bytes passed-in bytes array.
     * @return json string.
     */
    String printToJson(byte[] bytes);
}
