package com.tudou.recommend.up.odps.common.udf;

import com.aliyun.odps.udf.UDF;
import com.google.common.primitives.UnsignedLong;
import com.tudou.recommend.proto.ProtoCommon;
import com.tudou.recommend.proto.ProtoUser;
import com.tudou.recommend.proto.ProtoUserServer;
import com.wolong.protorpc.client.pool.PooledRpcClient;
import com.wolong.protorpc.client.protobuf.DefaultBlockingRpcChannel;
import com.wolong.protorpc.model.DefaultRpcController;

import java.math.BigInteger;
import java.util.List;

/**
 * @author wangfei01
 * @date 2018/4/16
 */
public class SubjectGetUDF extends UDF {
    public static String na61UserServerAddress = "11.138.250.204:20002,11.138.252.102:20002,11.138.252.213:20002,11.138.253.18:20002,11.142.9.48:20002,11.142.9.90:20002,11.142.9.92:20002,11.142.9.93:20002";
    public static String na62UserServerAddress = "11.142.11.216:20002,11.142.11.228:20002,11.142.11.238:20002,11.142.44.28:20002,11.173.144.73:20002,11.173.145.41:20002,11.173.145.103:20002,11.173.179.45:20002";
    public static int rpcTimeout = 1000;
    private PooledRpcClient na61RpcClient;
    private PooledRpcClient na62RpcClient;
    private ProtoUserServer.UserService.BlockingInterface na61UserService;
    private ProtoUserServer.UserService.BlockingInterface na62UserService;

    public SubjectGetUDF() throws Exception {
        init();
    }

    public void init() throws Exception {
        this.na61RpcClient = new PooledRpcClient(na61UserServerAddress, rpcTimeout);
        this.na61RpcClient.bootstrap();
        this.na61UserService = ProtoUserServer.UserService.newBlockingStub(new DefaultBlockingRpcChannel(this.na61RpcClient));
        this.na62RpcClient = new PooledRpcClient(na62UserServerAddress, rpcTimeout);
        this.na62RpcClient.bootstrap();
        this.na62UserService = ProtoUserServer.UserService.newBlockingStub(new DefaultBlockingRpcChannel(this.na62RpcClient));

    }

    public String evaluate(String userId, String appName, String fieldSep) {
        ProtoUserServer.GetUserFieldRequest request = ProtoUserServer.GetUserFieldRequest
                .newBuilder()
                .addFieldTypes(ProtoUserServer.UserFieldType.kFollowSubject)
                .addFieldTypes(ProtoUserServer.UserFieldType.kRecentClick)
                .addFieldTypes(ProtoUserServer.UserFieldType.kSubscription)
                .setUser(ProtoCommon.UserIdentity
                        .newBuilder()
                        .setAppToken(appName)
                        .setUserId(new BigInteger(userId).longValue())
                        .setOuterId(userId)
                        .build())
                .build();
        DefaultRpcController controller = new DefaultRpcController();
        ProtoUserServer.GetUserFieldResponse response;

        for (int i = 0; i < 3; i++) {
            try {
                response = this.na61UserService.getUserField(controller, request);
                ProtoUser.FollowSubjectInfo subjectInfo = response.getSubjectInfo();
                List<ProtoUser.SubjectInfo> list = subjectInfo.getSubjectsList();

                ProtoUserServer.GetUserFieldResponse na62Response = this.na62UserService.getUserField(controller, request);
                ProtoUser.FollowSubjectInfo na62SubjectInfo = na62Response.getSubjectInfo();
                List<ProtoUser.SubjectInfo> na62List = na62SubjectInfo.getSubjectsList();

                if(list!=null&&na62List!=null&&list.size()<list.size()){
                    list=na62List;
                }

                StringBuilder builder = new StringBuilder();
                for (ProtoUser.SubjectInfo info : list) {
                    builder.append(UnsignedLong.fromLongBits(info.getSubjectId()).toString())
                            .append(fieldSep)
                            .append(info.getSubTime())
                            .append(fieldSep)
                            .append(info.getLastViewTime())
                            .append(";");
                }
                return builder.toString();
            } catch (Exception e) {
                if (i == 2) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }
}
