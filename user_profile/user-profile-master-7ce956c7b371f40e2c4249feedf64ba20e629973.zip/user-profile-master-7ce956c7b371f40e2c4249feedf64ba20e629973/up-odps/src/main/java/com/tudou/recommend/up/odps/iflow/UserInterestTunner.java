package com.tudou.recommend.up.odps.iflow;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.ProfileFeatureType;
import com.tudou.recommend.up.odps.common.entity.interest.InterestElem;
import com.tudou.recommend.up.odps.common.util.DataFormatUtil;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import org.apache.commons.lang3.StringUtils;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;

/**
 * 对User Interest进行强制调权
 * 
 * @author zengtao
 *
 */
public class UserInterestTunner {
	private static MrArgContainer argContainer = new MrArgContainer();

	public static class UserInterestTunnerMapper extends MapperBase {
		private Record k2;
		private Record v2;
		private String userIdPostfix = "";

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			userIdPostfix = context.getJobConf().get("userIdPostfix");
		}

		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			String userId = record.getString("user_id");
			if (userIdPostfix != null && !userIdPostfix.isEmpty()
					&& !userId.endsWith(userIdPostfix)) {
				return;
			}
			k2.setString(0, userId);
			v2.setString(0, record.getString(0));
			v2.setString(1, record.getString(1));
			v2.setString(2, record.getString(2));
			context.write(k2, v2);
		}
	}

	public static class UserInterestTunnerReducer extends ReducerBase {
		private Record result;
		private static final DecimalFormat DF = DataFormatUtil
				.getDefaultDecimalFormater();
		private boolean doFeatureWeightTuning = false;
		private HashMap<Integer, HashMap<String, Double>> feaTuneMap = new HashMap<Integer, HashMap<String, Double>>();

		private void readFeatureTuneFile(Iterator<Record> values,
				HashMap<Integer, HashMap<String, Double>> feaTuneMap)
				throws NumberFormatException, IOException {
			while (values.hasNext()) {
				Record next = values.next();
				int feaType = Integer.parseInt(next.getString(0));
				String fea = next.getString(1);
				double tuneWeight = Double.parseDouble(next.getString(2));
				if (!feaTuneMap.containsKey(feaType)) {
					feaTuneMap.put(feaType, new HashMap<String, Double>());
				}
				feaTuneMap.get(feaType).put(fea, tuneWeight);
			}
		}

		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();
			// get configs
			JobConf conf = context.getJobConf();
			doFeatureWeightTuning = conf.getInt("featureWeightTune", 0) == 1;
			if (doFeatureWeightTuning) {
				Iterator<Record> featureTuneTable = context
						.readResourceTable(conf.get("featureTuneDataTable"));
				readFeatureTuneFile(featureTuneTable, feaTuneMap);
			}
		}

		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			// interest
			// feaType ~ feaHashCode ~ interestElem
			HashMap<Integer, ArrayList<InterestElem>> interestsMap = new HashMap<Integer, ArrayList<InterestElem>>();

			while (values.hasNext()) {
				Record r = values.next();
				int feaType = Integer.parseInt(r.getString(1));

				if (!interestsMap.containsKey(feaType)) {
					interestsMap.put(feaType, new ArrayList<InterestElem>());
				}
				if (StringUtils.isNotBlank(r.getString(2))) {
					parseInterests(r.getString(2).split("\t", -1),
							interestsMap.get(feaType));
				}
			}

			// tuning
			if (doFeatureWeightTuning) {
				doInterestTuningByFeatureWeights(interestsMap);
			}

			// output
			ArrayList<Integer> feaTypes = new ArrayList<Integer>(
					interestsMap.keySet());
			Collections.sort(feaTypes);
			StringBuilder builder = new StringBuilder();
			for (int feaTypeKey : feaTypes) {
				ArrayList<InterestElem> interests = interestsMap
						.get(feaTypeKey);

				for (InterestElem interest : interests) {
					if (builder.length() > 0) {
						builder.append("\t");
					}
					builder.append(interest.term).append("::")
							.append(DF.format(interest.interest)).append("::")
							.append(DF.format(interest.confidence))
							.append("::").append(DF.format(interest.ctr));
				}
				result.setString(0, key.getString(0));
				result.setString(1, String.valueOf(feaTypeKey));
				result.setString(2, builder.toString());
				context.write(result);
				builder.delete(0, builder.length());
			}
		}

		/**
		 * 解析user interest
		 * 
		 * @param fields
		 * @param interestArr
		 * @return
		 */
		private boolean parseInterests(String[] fields,
				ArrayList<InterestElem> interestArr) {
			if (fields == null || interestArr == null) {
				return false;
			}

			for (int i = 0; i < fields.length; ++i) {
				String[] ss = fields[i].split("::", -1);
				if (ss.length < 3) {
					return false;
				}
				String term = ss[0];
				float interest = Float.parseFloat(ss[1]);
				float confidence = Float.parseFloat(ss[2]);
				float ctr = ss.length > 3 ? Float.parseFloat(ss[3]) : 0;
				interestArr.add(new InterestElem(term, "", interest,
						confidence, ctr));
			}
			return true;
		}

		public void doInterestTuningByFeatureWeights(
				HashMap<Integer, ArrayList<InterestElem>> interestsMap) {
			for (int feaType : interestsMap.keySet()) {
				if (!feaTuneMap.containsKey(feaType)) {
					continue;
				}

				for (InterestElem interest : interestsMap.get(feaType)) {
					// 带类目和前缀的feature要额外解析
					String feaStr = interest.term;
					if (feaType == ProfileFeatureType.TAG.getValue()
							|| feaType == ProfileFeatureType.NEG_TAG.getValue()) {
						String[] flds = interest.term
								.split(Contents.CATEGORY_SEP);
						if (flds.length == 2) {
							String[] tagFlds = flds[1].split(":");
							if (tagFlds.length == 2) {
								feaStr = tagFlds[1];
							}
						}
					} else if (feaType == ProfileFeatureType.KEYWORD.getValue()
							|| feaType == ProfileFeatureType.NEG_KEYWORD
									.getValue()
							|| feaType == ProfileFeatureType.VIDEO_TAG
									.getValue()) {
						String[] flds = interest.term
								.split(Contents.CATEGORY_SEP);
						if (flds.length == 2) {
							feaStr = flds[1];
						}
					}

					if (!feaTuneMap.get(feaType).containsKey(feaStr)) {
						continue;
					}
					double feaTuneWeight = feaTuneMap.get(feaType).get(feaStr);
					interest.interest *= feaTuneWeight;
				}
			}
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils
				.fromString("user_id:string,feature_type:string,interest:string"));

		MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {
			"user_id", "feature_type", "interest" });
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(UserInterestTunnerMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(UserInterestTunnerReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		//MrJobParamSetter.setSplitSize(job, 128L);

		job.set("userIdPostfix", argContainer.getUserIdPostfix());
		job.setInt("featureWeightTune", argContainer.getFeatureWeightTune());
		if (argContainer.getFeatureWeightTune() == 1) {
			job.set("featureTuneDataTable",
					argContainer.getFeatureTuneDataDir());
		}

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}

	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-featureWeightTune", description = "whether use additional feature weight tuning")
		private int featureWeightTune = 0;

		@Parameter(names = "-featureTuneDataTable", description = "path of feature weight tuning data")
		private String featureTuneDataTable = "/reco/user_profile/ptc/000";

		@Parameter(names = "-userIdPostfix", description = "user sampling by user id posfix")
		private String userIdPostfix = "";

		public int getFeatureWeightTune() {
			return featureWeightTune;
		}

		public void setFeatureWeightTune(int featureWeightTune) {
			this.featureWeightTune = featureWeightTune;
		}

		public String getFeatureTuneDataDir() {
			return featureTuneDataTable;
		}

		public void setFeatureTuneDataDir(String featureTuneDataDir) {
			this.featureTuneDataTable = featureTuneDataDir;
		}

		public String getUserIdPostfix() {
			return userIdPostfix;
		}

		public void setUserIdPostfix(String userIdPostfix) {
			this.userIdPostfix = userIdPostfix;
		}

	}
}
