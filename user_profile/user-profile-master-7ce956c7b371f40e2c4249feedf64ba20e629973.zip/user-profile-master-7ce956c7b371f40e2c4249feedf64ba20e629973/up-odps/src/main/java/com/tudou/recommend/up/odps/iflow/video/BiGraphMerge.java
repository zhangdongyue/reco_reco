package com.tudou.recommend.up.odps.iflow.video;

import java.io.IOException;
import java.util.*;

import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.Contents;
import com.tudou.recommend.up.odps.common.entity.MrCounters;

import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
/**
 * 
 * @author wj148482
 *
 */
public class BiGraphMerge {
	private static MrArgContainer argContainer = new MrArgContainer();
	public static class BiGraphMapper extends MapperBase {
		private Record k2;
		private Record v2;
		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
		}
		@Override
		public void map(long recordNum, Record record, TaskContext context)
				throws IOException {
			k2.setString(0, record.getString(0));
			v2.setString(0, record.getString(1));
			v2.setString(1, record.getString(2));
			context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "bigraph input").increment(1L);
			context.write(k2, v2);
		}
	}
	public static class BiGraphReducer extends ReducerBase {
		private Record result;
		private int topN = 500;
		@Override
		public void setup(TaskContext context) throws IOException {
			result = context.createOutputRecord();	
			JobConf conf = context.getJobConf();
			topN = conf.getInt("topN", 500);
		}
		@Override
		public void reduce(Record key, Iterator<Record> values,
				TaskContext context) throws IOException {
			HashMap<String,Double> recWeights = new HashMap<String, Double >();
			Double newWei = 0.0;
			Double wei = 0.0;
			int flag = 0;
			while (values.hasNext()) {
				Record r = values.next();
				String recSource = r.getString(0);
				String weiStr = r.getString(1);
				try{
					wei = Double.valueOf(weiStr.toString());
				}catch(NumberFormatException e){
					flag = -1;
				}
				if (0 != flag)
				{
					continue;
				}
				
				if (recWeights.containsKey(recSource))
				{
					newWei = recWeights.get(recSource) + wei;
					recWeights.put(recSource, newWei);
				}
				else
				{
					recWeights.put(recSource,  wei);
				}
				
				if (recWeights.size() > 200000)
				{
					break;
				}
			}
			// hashmap 排序			
	        List<Map.Entry<String,Double>> list = new ArrayList<Map.Entry<String,Double>>(recWeights.entrySet());
            Collections.sort(list, new Comparator<Map.Entry<String, Double>>() {
	            public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
	                return o2.getValue().compareTo(o1.getValue());
	            }
	        }); 
	        int recLen =  topN;
	                
	        if (recLen > list.size())
	        {
	        	recLen = list.size();
	        }
	        
	        for (int i = 0; i < recLen; i ++)
	        {
	        	result.setString(0, key.getString(0));
	        	result.setString(1, list.get(i).getKey());
	        	result.setString(2,  list.get(i).getValue()+"");
	        	context.write(result);
	        }
		}
	}

	public static void main(String[] args) throws OdpsException {
		JCommander cmder = new JCommander(argContainer, args);
		if (argContainer.isHelp()) {
			cmder.usage();
			System.exit(Contents.SUCCED_CODE);
		}
		Job job = new Job();
		// TODO: specify map output types
		job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
		job.setMapOutputValueSchema(SchemaUtils.fromString("recSource :string ,rec_wei:string"));
		MrJobParamSetter.addInput(job, argContainer.getInput());
		MrJobParamSetter.addOutput(job, argContainer.getOutput());
		// TODO: specify a mapper
		job.setMapperClass(BiGraphMapper.class);
		// TODO: specify a reducer
		job.setReducerClass(BiGraphReducer.class);
		if (argContainer.getNumReducer() > 0) {
			MrJobParamSetter.setNumReduceTasks(job,
					argContainer.getNumReducer());
		}
		job.setInt("topN", argContainer.getTopN());

		job.waitForCompletion();
		System.exit(job.isSuccessful() == true ? 0 : 1);
	}
	public static class MrArgContainer extends BaseMrArgContainer {
		@Parameter(names = "-topN", description = "select top N sources for recommendation")
		private int topN = 500;
		public MrArgContainer() {
		}
		public int getTopN() {
			return topN;
		}
		public void setTopN(int topN) {
			this.topN = topN;
		}
	}
}