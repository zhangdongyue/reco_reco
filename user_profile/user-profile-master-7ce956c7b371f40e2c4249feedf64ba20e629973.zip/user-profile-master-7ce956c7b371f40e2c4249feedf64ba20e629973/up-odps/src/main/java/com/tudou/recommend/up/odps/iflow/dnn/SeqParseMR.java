package com.tudou.recommend.up.odps.iflow.dnn;

import com.aliyun.odps.Column;
import com.aliyun.odps.OdpsException;
import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.google.common.base.Joiner;
import com.google.common.collect.Sets;
import com.tudou.recommend.up.odps.common.util.BaseArgContainer;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * The MR will create user watch sequences according to click time.
 *
 * @author wangfei01
 * @date 2017/8/24
 */
public class SeqParseMR {
    private static ArgumentContainer argument = new ArgumentContainer();

    public static class ReadMapper extends MapperBase {
        private Logger logger = LoggerFactory.getLogger(this.getClass());
        private Map<String, Long> encodeMap = new HashMap<>();
        private Map<String, Double> subsampleMap = new HashMap<>();
        private Map<Long, String> decodeMap = new HashMap<>();
        private Map<String, Integer> leastValidCountMap = new HashMap<>();
        private Map<String, Integer> mostValidCountMap = new HashMap<>();
        private Record output;
        private Set<String> columnSet;
        private String[] remainColumns;
        private String encodeOrDecode;
        private String splitter;
        private String subsampleProb;
        private long defaultIndex;
        private Boolean sequenceSubsample;

        @Override
        public void setup(TaskContext context) throws IOException {
            output = context.createOutputRecord();
            JobConf jobConf = context.getJobConf();
            String encodeTableName = jobConf.get("encode.table.name");
            String[] columnNames = jobConf.get("column.name").split(",");
            String[] leastValidCount = jobConf.get("column.least.item").split(",");
            String[] mostValidCount = jobConf.get("column.most.item").split(",");
            for (int i = 0; i < columnNames.length; i++) {
                leastValidCountMap.put(columnNames[i], Integer.parseInt(leastValidCount[i]));
                mostValidCountMap.put(columnNames[i], Integer.parseInt(mostValidCount[i]));
            }
            columnSet = Sets.newHashSet(columnNames);
            encodeOrDecode = jobConf.get("encode.or.decode.column", "encode");
            splitter = jobConf.get("column.splitter");
            String remainList = jobConf.get("column.remain");
            if (remainList != null) {
                remainColumns = remainList.split(",");
            }
            logger.info("The remain columns is:{}", remainList);
            subsampleProb = jobConf.get("example.subsample.prob");
            sequenceSubsample = jobConf.getBoolean("sequence.subsample.prob", false);
            logger.info("subsampling column is:{}, seq subsampling is:{}", subsampleProb, sequenceSubsample);
            loadEncode(context, encodeTableName);
        }

        public void loadEncode(TaskContext context, String resourceName) throws IOException {
            Iterator<Record> table = context.readResourceTable(resourceName);
            long size = 0;
            boolean startFromZero = false;
            while (table.hasNext()) {
                Record record = table.next();
                Long id = record.getBigint("id");
                if (id == 0L) {
                    startFromZero = true;
                }
                String word = record.getString("word");
                if ("encode".equals(encodeOrDecode)) {
                    this.encodeMap.put(word, id);
                }
                if ("decode".equals(encodeOrDecode)) {
                    this.decodeMap.put(id, word);
                }
                if (subsampleProb != null || sequenceSubsample) {
                    Double prob = record.getDouble("prob");
                    this.subsampleMap.put(word, prob);
                }
                size += 1;
            }
            if (startFromZero) {
                this.defaultIndex = size;
            } else {
                this.defaultIndex = 0L;
            }
            logger.info("encode dict size is : {}, default index is: {}",
                    encodeMap.size(), this.defaultIndex);
        }


        @Override
        public void map(long key, Record record, TaskContext context) throws IOException {
            if (subsampleProb != null) {
                String label = record.getString(subsampleProb);
                Double prob = subsampleMap.get(label);
                if (prob != null && prob > Math.random()) {
                    context.getCounter("SUBSAMPLE", "LABEL").increment(1L);
                    return;
                }
            }
            if ("encode".equals(encodeOrDecode)) {
                for (String columnName : columnSet) {
                    String columnValue = record.getString(columnName);
                    if (columnValue != null) {
                        Integer mostCount = mostValidCountMap.get(columnName);
                        Long[] encodes = new Long[mostCount];
                        int valid = 0;
                        String[] raws = columnValue.split(splitter);
                        for (int i = 0; i < mostCount; i++) {
                            // Make sure the item count less than most count.
                            if (mostCount > valid) {
                                Long encodeId = encodeMap.get(raws[i]);
                                Double prob = subsampleMap.get(raws[i]);
                                if (encodeId != null) {
                                    if (sequenceSubsample) {
                                        if (prob != null && Math.random() < prob) {
                                            encodes[i] = this.defaultIndex;
                                            context.getCounter("SUBSAMPLE", "SEQ").increment(1L);
                                        } else {
                                            encodes[i] = encodeId;
                                            valid += 1;
                                        }
                                    } else {
                                        encodes[i] = encodeId;
                                        valid += 1;
                                    }
                                } else {
                                    encodes[i] = this.defaultIndex;
                                }
                            }
                        }
                        // The valid item count should be greater than or equal to least count.
                        Integer leastCount = leastValidCountMap.get(columnName);
                        if (valid < leastCount) {
                            return;
                        }
                        output.setString(columnName, Joiner.on(splitter).join(encodes));
                    } else {
                        output.setString(columnName, columnValue);
                    }
                }
            } else {
                // Decode the columns.
                for (String columnName : columnSet) {
                    String encodedString = record.getString(columnName);
                    if (encodedString != null) {
                        String[] encodes = encodedString.split(splitter);
                        String[] decodes = new String[encodes.length];
                        for (int i = 0; i < encodes.length; i++) {
                            String itemId = decodeMap.get(Long.parseLong(encodes[i]));
                            decodes[i] = (itemId == null) ? "0" : itemId;
                        }
                        output.setString(columnName, Joiner.on(splitter).join(decodes));
                    }
                }
            }
            Column[] columns = record.getColumns();
            // Add remain columns
            if (remainColumns != null && remainColumns.length > 0) {
                for (String columnName : remainColumns) {
                    Object columnValue = record.get(columnName);
                    output.set(columnName, columnValue);
                }
            } else {
                for (Column column : columns) {
                    String columnName = column.getName();
                    if (!columnSet.contains(columnName)) {
                        Object columnValue = record.get(columnName);
                        output.set(columnName, columnValue);
                    }
                }
            }
            context.write(output);
        }
    }


    public static void main(String[] args) throws OdpsException {
        JCommander commander = new JCommander(argument);
        commander.parse(args);
        Job job = new Job();
        job.set("encode.table.name", argument.getEncodeTableName());
        job.set("column.name", argument.getColumnName());
        job.set("encode.or.decode.column", argument.getEncodeOrDecode());
        job.set("column.splitter", argument.getColumnSplitter());
        job.set("column.least.item", argument.getColumnLeastItem());
        job.set("column.most.item", argument.getColumnMostItem());
        if (argument.getColumnRemain() != null) {
            job.set("column.remain", argument.getColumnRemain());
        }
        if (argument.getSubsampleProbColumn() != null) {
            job.set("example.subsample.prob", argument.getSubsampleProbColumn());
        }
        if (argument.getSequenceSubsample() != null) {
            job.setBoolean("sequence.subsample.prob", argument.getSequenceSubsample());
        }

        if (argument.getColumnRemain() != null) {
            String columns = argument.getColumnName() + "," + argument.getColumnRemain();
            MrJobParamSetter.addInput(job, argument.getInput(),columns.split(","));
        } else {
            MrJobParamSetter.addInput(job, argument.getInput());
        }
        MrJobParamSetter.addOutput(job, argument.getOutput());
        job.setMapperClass(ReadMapper.class);
        job.setNumReduceTasks(0);
        boolean flag = job.waitForCompletion();
        if (!flag) {
            System.exit(1);
        }
    }

    public static class ArgumentContainer extends BaseArgContainer {
        @Parameter(names = "-encodeTableName")
        private String encodeTableName;

        @Parameter(names = "-columnName")
        private String columnName;

        @Parameter(names = "-encodeOrDecode")
        private String encodeOrDecode;

        @Parameter(names = "-columnSplitter")
        private String columnSplitter;

        @Parameter(names = "-columnRemain")
        private String columnRemain;

        @Parameter(names = "-subsampleProbColumn")
        private String subsampleProbColumn;

        @Parameter(names = "-sequenceSubsample")
        private Boolean sequenceSubsample = false;

        @Parameter(names = "-columnLeastItem")
        private String columnLeastItem;

        @Parameter(names = "-columnMostItem")
        private String columnMostItem;

        public Boolean getSequenceSubsample() {
            return sequenceSubsample;
        }

        public void setSequenceSubsample(Boolean sequenceSubsample) {
            this.sequenceSubsample = sequenceSubsample;
        }

        public String getColumnMostItem() {
            return columnMostItem;
        }

        public void setColumnMostItem(String columnMostItem) {
            this.columnMostItem = columnMostItem;
        }

        public String getColumnLeastItem() {
            return columnLeastItem;
        }

        public void setColumnLeastItem(String columnLeastItem) {
            this.columnLeastItem = columnLeastItem;
        }

        public String getSubsampleProbColumn() {
            return subsampleProbColumn;
        }

        public void setSubsampleProbColumn(String subsampleProbColumn) {
            this.subsampleProbColumn = subsampleProbColumn;
        }

        public String getEncodeTableName() {
            return encodeTableName;
        }

        public void setEncodeTableName(String encodeTableName) {
            this.encodeTableName = encodeTableName;
        }

        public String getColumnName() {
            return columnName;
        }

        public void setColumnName(String columnName) {
            this.columnName = columnName;
        }

        public String getEncodeOrDecode() {
            return encodeOrDecode;
        }

        public void setEncodeOrDecode(String encodeOrDecode) {
            this.encodeOrDecode = encodeOrDecode;
        }

        public String getColumnSplitter() {
            return columnSplitter;
        }

        public void setColumnSplitter(String columnSplitter) {
            this.columnSplitter = columnSplitter;
        }

        public String getColumnRemain() {
            return columnRemain;
        }

        public void setColumnRemain(String columnRemain) {
            this.columnRemain = columnRemain;
        }
    }
}
