package com.tudou.recommend.up.odps.common.entity;

public class ProfileDataIdentity {

	/**
	 * 土豆 (default)
	 */
	 public static final String TD = "td";
	 
	 /**
	  * 土豆短视频
	  */
	 public static final String TD_SHORT = "td_short";
	 
	 /**
	  * 土豆长视频
	  */
	 public static final String TD_LONG = "td_long";
}
