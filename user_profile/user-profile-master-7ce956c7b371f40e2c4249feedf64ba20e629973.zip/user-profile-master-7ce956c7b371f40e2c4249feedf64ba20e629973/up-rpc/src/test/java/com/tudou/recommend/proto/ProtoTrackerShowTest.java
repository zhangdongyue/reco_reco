package com.tudou.recommend.proto;

import org.assertj.core.util.Lists;
import org.junit.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.*;

/**
 * Created by Wangfei on 2017/5/26.
 */
public class ProtoTrackerShowTest {

    @Test
    public void testUserTracker() {
        ProtoYoukuTrackerShow.YoukuShowTrace trace = ProtoYoukuTrackerShow.YoukuShowTrace
                .newBuilder()
                .setYoukuShowId(12212)
                .setWeight(1.0)
                .setTotalPlayedEpisodes(10)
                .setLastPlayedRate(0.5)
                .setLastPlayedTimestamp(121213321)
                .setLastPlayedVideo(123123)
                .build();
        List<ProtoYoukuTrackerShow.YoukuShowTrace> list = Lists.newArrayList(trace);
        ProtoYoukuTrackerShow.YoukuUserTracker userTracker = ProtoYoukuTrackerShow.YoukuUserTracker
                .newBuilder()
                .addAllTraces(list)
                .build();
        System.out.println(userTracker.toString());
        assertThat(userTracker.toByteArray().length).isEqualTo(34);
    }

}