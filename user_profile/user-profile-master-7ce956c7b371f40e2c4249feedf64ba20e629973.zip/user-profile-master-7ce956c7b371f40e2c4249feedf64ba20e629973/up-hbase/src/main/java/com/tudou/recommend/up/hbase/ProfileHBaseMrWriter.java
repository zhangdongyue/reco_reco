package com.tudou.recommend.up.hbase;

import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.google.protobuf.InvalidProtocolBufferException;
import com.tudou.recommend.up.odps.common.entity.BaseArgContainer;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.proto.IProtoGenerate;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.wolong.reco.proto.ProtoUserServer;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.Charsets;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Write user profile data into HBase.
 * Author:wangfei01
 * Date:20170710
 */
public class ProfileHBaseMrWriter {
    public static MrArgContainer argContainer = new MrArgContainer();

    public static class DataMapper extends MapperBase {
        private Set<String> allowedAppNames = new HashSet<String>();
        private Record outputKey;
        private Record outputValue;
        private double sampleRate;

        @Override
        public void setup(TaskContext context) throws IOException {
            JobConf jobConf = context.getJobConf();
            String allowedAppNames = jobConf.get("allowedAppName", "");
            String[] apps = allowedAppNames.split(",", -1);
            for (String appName : apps) {
                if (!appName.trim().isEmpty()) {
                    this.allowedAppNames.add(appName.trim());
                }
            }
            outputKey = context.createMapOutputKeyRecord();
            outputValue = context.createMapOutputValueRecord();
            sampleRate = jobConf.getFloat("sampleRate", 1.0f);
        }

        @Override
        public void map(long key, Record record, TaskContext context) throws IOException {
            if (Math.random() <= sampleRate) {
                String profileKey = record.getString("profile_key");
                String profile = record.getString("profile");

                String appName = profileKey.split("`", -1)[0];
                if (!allowedAppNames.isEmpty() && !allowedAppNames.contains(appName)) {
                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP,
                            "filtered_by_app_name").increment(1L);
                    return;
                }
                outputKey.setString("profile_key", profileKey);
                outputValue.setString("profile", profile);
                context.write(outputKey, outputValue);
            }
        }
    }

    public static class DataReducer extends ReducerBase {
        private static final Logger logger = LoggerFactory.getLogger(DataReducer.class);
        private boolean debug;
        private Record output;
        // HBase client interface.
        private Connection hbaseCon;
        private String hbaseIp;
        private int hbasePort;
        private String tableName;
        private byte[] columnFamily;
        private byte[] column;
        private Table table;

        // batch put
        private boolean batchModel = false;
        private int batchSize;
        private ArrayList<Put> puts = new ArrayList<Put>();

        // qps controller.
        private int sleepMs = 0;
        private int qpsOutputFreq = 10000;
        private long startTime;
        private long currentTime;
        private int dataNum;

        // data format
        private String dataType = "raw";
        private Base64 base64 = new Base64();

        private boolean initHbaseConnection() {
            if (!closeHbaseConnection()) {
                return false;
            }

            logger.info("set hbase config: ip=" + hbaseIp + ", port=" + hbasePort);
            Configuration config = HBaseConfiguration.create();
            config.set("hbase.zookeeper.quorum", hbaseIp);
            config.set("hbase.zookeeper.property.clientPort", String.valueOf(hbasePort));

            try {
                hbaseCon = ConnectionFactory.createConnection(config);
                table = hbaseCon.getTable(TableName.valueOf(tableName));
            } catch (IOException e) {
                logger.error("can't connect to hbase, exception", e);
                hbaseCon = null;
                return false;
            }
            logger.info("succ to conenct to hbase");
            return true;
        }

        private boolean closeHbaseConnection() {
            if (hbaseCon != null) {
                try {
                    hbaseCon.close();
                } catch (IOException e) {
                    logger.error("close HBase connection failed.", e);
                    return false;
                }
            }
            return true;
        }

        @Override
        public void setup(TaskContext context) throws IOException {
            JobConf jobConf = context.getJobConf();
            // init HBase connection
            hbaseIp = jobConf.get("hbaseIp");
            hbasePort = jobConf.getInt("hbasePort", 0);
            tableName = jobConf.get("hbaseTableName");
            columnFamily = Bytes.toBytes(jobConf.get("colFamilyName"));
            column = Bytes.toBytes(jobConf.get("colName"));
            batchModel = jobConf.get("writeModel").equalsIgnoreCase("batch");
            batchSize = jobConf.getInt("batchSize", 1);
            debug = jobConf.getBoolean("debug", false);
            if (debug) {
                output = context.createOutputRecord();
            }
            dataType = jobConf.get("dataType");
            startTime = System.currentTimeMillis();
            dataNum = 0;
            sleepMs = jobConf.getInt("sleepMs", 0);
            qpsOutputFreq = jobConf.getInt("qpsOutputFreq", 10000);
            initHbaseConnection();
            logger.info("the batch mode is {} and batch size is {}", batchModel, batchSize);
        }

        /**
         * Parse message bytes according to different data type.
         *
         * @param origBytes passed in origin bytes.
         * @param dataType  assigned data type.
         * @return extracted message bytes.
         * @throws InvalidProtocolBufferException
         */
        private byte[] parse(byte[] origBytes, String dataType) throws InvalidProtocolBufferException {
            if (origBytes == null) {
                return null;
            }
            if (dataType == null || dataType.isEmpty() || dataType.equalsIgnoreCase("raw")) {
                return origBytes;
            }
            if (dataType.equalsIgnoreCase("kafkamsg")) {
                ProtoUserServer.UserProfileKafkaMessage msg = ProtoUserServer.UserProfileKafkaMessage.parseFrom(origBytes);
                if (msg == null) {
                    return null;
                }
                return msg.getValue().toByteArray();
            }
            return null;
        }

        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
            String profileKey = key.getString("profile_key");
            byte[] rowKey = profileKey.getBytes();
            while (values.hasNext()) {
                Record value = values.next();
                String profile = value.getString("profile");

                // extract profile content
                byte[] convertBytes = base64.decode(profile);
                if (convertBytes == null) {
                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "null_after_convert").increment(1L);
                    continue;
                }
                byte[] valueBytes = parse(convertBytes, dataType);
                if (valueBytes == null) {
                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "null_after_parse").increment(1L);
                    continue;
                }

                //write data into HBase
                Put put = new Put(rowKey);
                put.addColumn(columnFamily, column, valueBytes);

                if (batchSize > 1) {
                    if (puts.size() >= batchSize) {
                        try {
                            table.put(puts);
                            context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "hbase_write_success").increment(puts.size());
                        } catch (IOException e) {
                            context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "hbase_write_failed").increment(puts.size());
                        } finally {
                            puts.clear();
                        }
                    }
                    puts.add(put);
                    if (debug) {
                        output.setString("profile_key", profileKey);
                        output.setString("profile", new String(valueBytes, Charsets.UTF_8));
                        context.write(output);
                    }
                } else {
                    try {
                        table.put(put);
                        if (debug) {
                            output.setString("profile_key", profileKey);
                            output.setString("profile", new String(valueBytes, Charsets.UTF_8));
                            context.write(output);
                        }
                        context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "hbase_write_success").increment(1L);
                    } catch (IOException e) {
                        context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "hbase_write_failed").increment(1L);
                    }

                }
                // QPS control
                dataNum++;
                if (dataNum % qpsOutputFreq == 0) {
                    currentTime = System.currentTimeMillis();
                    double time = (currentTime - startTime) / 1000.0;
                    double qps = dataNum / time;
                    logger.info("dataNum={}, seconds={}, qps={}", dataNum, time, qps);
                }

                if (sleepMs > 0) {
                    try {
                        Thread.sleep(sleepMs);
                    } catch (InterruptedException e) {
                        logger.error("interrupted during sleep.", e);
                    }
                }
            }

        }

        @Override
        public void cleanup(TaskContext context) throws IOException {
            if (puts.size() > 0) {
                try {
                    table.put(puts);
                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "hbase_write_success").increment(puts.size());
                } catch (IOException e) {
                    context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "hbase_write_failed").increment(1L);
                } finally {
                    puts.clear();
                }
            }
            closeHbaseConnection();
        }
    }


    public static void main(String[] args) throws Exception {
        JCommander commander = new JCommander(argContainer);
        commander.parse(args);

        Job job = new Job();
        job.setBoolean("debug", argContainer.isDebug());
        job.set("hbaseIp", argContainer.getHbaseIp());
        job.setInt("hbasePort", argContainer.getHbasePort());
        job.set("hbaseTableName", argContainer.getHbaseTableName());
        job.setInt("rowKeyIndex", argContainer.getRowKeyIndex());
        job.setInt("dataIndex", argContainer.getDataIndex());
        job.set("colFamilyName", argContainer.getColFamilyName());
        job.set("colName", argContainer.getColName());
        job.set("writeModel", argContainer.getWriteModel());
        job.setInt("batchSize", argContainer.getBatchSize());
        job.setInt("sleepMs", argContainer.getSleepMs());
        job.setInt("qpsOutputFreq", argContainer.getQpsOutputFreq());
        job.set("dataType", argContainer.getDataType());
        job.set("allowedAppName", argContainer.getAllowedAppName());
        job.setFloat("sampleRate", argContainer.getSampleRate());
        job.setBoolean("debug", argContainer.isDebug());
        job.set("generatorClass", argContainer.getGeneratorClass());

        MrJobParamSetter.addInput(job, argContainer.getInput(), new String[]{"profile_key", "profile"});
        if (argContainer.isDebug()) {
            MrJobParamSetter.addOutput(job, argContainer.getOutput());
        }
        job.setMapperClass(DataMapper.class);
        job.setReducerClass(DataReducer.class);

        job.setMapOutputKeySchema(SchemaUtils.fromString("profile_key:string"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("profile:string"));

        boolean runResult = job.waitForCompletion();
        if (!runResult) {
            System.exit(1);
        }
    }

    public static class MrArgContainer extends BaseArgContainer {
        @Parameter(names = "-hbaseIp", description = "hbase ip")
        private String hbaseIp = "10.99.4.4";

        @Parameter(names = "-hbasePort", description = "hbase port")
        private int hbasePort = 2181;

        @Parameter(names = "-hbaseTableName", description = "table in hbase")
        private String hbaseTableName = "";

        @Parameter(names = "-rowKeyIndex", description = "")
        private int rowKeyIndex = 0;

        @Parameter(names = "-dataIndex", description = "")
        private int dataIndex = 1;

        @Parameter(names = "-dataType", description = "input data type: raw:raw profile proto bytes; kafkamsg: profile kafka msg")
        private String dataType = "raw";

        @Parameter(names = "-colFamilyName", description = "")
        private String colFamilyName = "data";

        @Parameter(names = "-colName", description = "")
        private String colName = "proto";

        @Parameter(names = "-writeModel", description = "hbase write model: single, batch")
        private String writeModel = "single";

        @Parameter(names = "-batchSize", description = "")
        private int batchSize = 1;

        @Parameter(names = "-sleepMs", description = "")
        private int sleepMs = 0;

        @Parameter(names = "-qpsOutputFreq", description = "")
        private int qpsOutputFreq = 10000;

        @Parameter(names = "-allowedAppName", description = "allowed app names")
        private String allowedAppName = "";

        @Parameter(names = "-sampleRate", description = "test sample rate.")
        private Float sampleRate;

        @Parameter(names = "-generatorClass", required = true)
        private String generatorClass;

        public String getGeneratorClass() {
            return generatorClass;
        }

        public void setGeneratorClass(String generatorClass) {
            this.generatorClass = generatorClass;
        }

        public String getAllowedAppName() {
            return allowedAppName;
        }

        public void setAllowedAppName(String allowedAppName) {
            this.allowedAppName = allowedAppName;
        }

        public Float getSampleRate() {
            return sampleRate;
        }

        public void setSampleRate(Float sampleRate) {
            this.sampleRate = sampleRate;
        }

        public String getHbaseIp() {
            return hbaseIp;
        }

        public void setHbaseIp(String hbaseIp) {
            this.hbaseIp = hbaseIp;
        }

        public int getHbasePort() {
            return hbasePort;
        }

        public void setHbasePort(int hbasePort) {
            this.hbasePort = hbasePort;
        }

        public String getHbaseTableName() {
            return hbaseTableName;
        }

        public void setHbaseTableName(String hbaseTableName) {
            this.hbaseTableName = hbaseTableName;
        }

        public int getRowKeyIndex() {
            return rowKeyIndex;
        }

        public void setRowKeyIndex(int rowKeyIndex) {
            this.rowKeyIndex = rowKeyIndex;
        }

        public int getDataIndex() {
            return dataIndex;
        }

        public void setDataIndex(int dataIndex) {
            this.dataIndex = dataIndex;
        }

        public int getSleepMs() {
            return sleepMs;
        }

        public void setSleepMs(int sleepMs) {
            this.sleepMs = sleepMs;
        }

        public int getQpsOutputFreq() {
            return qpsOutputFreq;
        }

        public void setQpsOutputFreq(int qpsOutputFreq) {
            this.qpsOutputFreq = qpsOutputFreq;
        }


        public String getColFamilyName() {
            return colFamilyName;
        }

        public void setColFamilyName(String colFamilyName) {
            this.colFamilyName = colFamilyName;
        }

        public String getColName() {
            return colName;
        }

        public void setColName(String colName) {
            this.colName = colName;
        }

        public String getWriteModel() {
            return writeModel;
        }

        public void setWriteModel(String writeModel) {
            this.writeModel = writeModel;
        }

        public int getBatchSize() {
            return batchSize;
        }

        public void setBatchSize(int batchSize) {
            this.batchSize = batchSize;
        }

        public String getDataType() {
            return dataType;
        }

        public void setDataType(String dataType) {
            this.dataType = dataType;
        }

    }
}
