package com.tudou.recommend.up.hbase;

import com.aliyun.odps.data.Record;
import com.aliyun.odps.mapred.Job;
import com.aliyun.odps.mapred.MapperBase;
import com.aliyun.odps.mapred.ReducerBase;
import com.aliyun.odps.mapred.conf.JobConf;
import com.aliyun.odps.mapred.utils.SchemaUtils;
import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.tudou.recommend.up.odps.common.entity.BaseMrArgContainer;
import com.tudou.recommend.up.odps.common.entity.MrCounters;
import com.tudou.recommend.up.odps.common.util.MrJobParamSetter;
import com.wolong.reco.profile.common.entity.Contents;
import com.wolong.reco.profile.common.util.item.ItemInfoFetcher;
import com.wolong.reco.profile.iflow.util.ItemFeaExtractUtil;
import com.wolong.reco.proto.ProtoItem.RecoItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Iterator;

/**
 * 从hbase中批量dump出item的信息
 *
 * @author wangfei01
 */
public class ItemInfoGetter {
    public static class LogDataMapper extends MapperBase {
    	private Record k2;
    	private Record v2;

		@Override
		public void setup(TaskContext context) throws IOException {
			k2 = context.createMapOutputKeyRecord();
			v2 = context.createMapOutputValueRecord();
			v2.setString(0, "1");
		}
		
        @Override
        public void map(long key, Record record, TaskContext context) throws IOException {
        	k2.setString(0, record.getString(0));
        	context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "video_log").increment(1L);
        	context.write(k2, v2);
        }

    }

    public static class LogDataReducer extends ReducerBase {
        private static final Logger logger = LoggerFactory.getLogger(LogDataReducer.class);

        private ItemInfoFetcher itemInfoFetcher;
        private ItemFeaExtractUtil itemFeaExtractor;
        private Record output;

        @Override
        public void setup(TaskContext context) throws IOException {
            logger.info("setting up hbase configs");
            JobConf conf = context.getJobConf();
            String hbaseIp = conf.get("hbaseIp");
            int hbasePort = conf.getInt("hbasePort", 0);
            String recoItemTable = conf.get("recoItemTable");
            itemInfoFetcher = ItemInfoFetcher.getInstance(hbaseIp, hbasePort, recoItemTable);
            logger.info("job conf: hbase:" + hbaseIp + ":" + hbasePort + " recoItemTable:" + recoItemTable);
            // init item fea extractor
            itemFeaExtractor = new ItemFeaExtractUtil();
            itemFeaExtractor.init();
            output = context.createOutputRecord();
        }

        @Override
        public void reduce(Record key, Iterator<Record> values, TaskContext context) throws IOException {
            String itemId = key.getString(0);

            // get item info from hbase
            RecoItem item = null;
            if (itemInfoFetcher != null) {
                item = itemInfoFetcher.fetchItem(itemId);
            }
            if (item == null) {
                logger.info("failed to get item info from hbase: " + itemId);
                context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, MrCounters.NO_ITEM_INFO_COUNTER).increment(1L);
                return;
            }
            String itemFeaStr = itemFeaExtractor.getItemFeaStr(item);
            if (itemFeaStr == null) {
                context.getCounter(MrCounters.DEFAULT_COUNTER_GROUP, "failed_to_extract_item_fea").increment(1L);
                return;
            }
            output.setString("item_id", itemId);
            output.setString("feature", itemFeaStr);
            context.write(output);
        }

        @Override
        public void cleanup(TaskContext context) throws IOException {
            if (itemInfoFetcher != null) {
                itemInfoFetcher.close();
            }
        }
    }

    public static void main(String[] args) throws Exception {
        MrArgContainer argContainer = new MrArgContainer();
        JCommander cmder = new JCommander(argContainer, args);
        if (argContainer.isHelp()) {
            cmder.usage();
            System.exit(Contents.SUCCED_CODE);
        }
        
        Job job = new Job();
        
        job.setMapOutputKeySchema(SchemaUtils.fromString("k2:string"));
        job.setMapOutputValueSchema(SchemaUtils.fromString("v2:string"));
        
        MrJobParamSetter.addInput(job, argContainer.getInput(), new String[] {"item" });
        
        job.set("hbaseIp", argContainer.getHbaseIp());
        job.setInt("hbasePort", argContainer.getHbasePort());
        job.set("recoItemTable", argContainer.getItemTableName());
        
        job.setMapperClass(LogDataMapper.class);
        job.setReducerClass(LogDataReducer.class);
        MrJobParamSetter.addInput(job, argContainer.getInput());
        MrJobParamSetter.addOutput(job, argContainer.getOutput());

        
        job.waitForCompletion();
        System.exit(job.isSuccessful() == true ? 0 : 1);

    }

    public static class MrArgContainer extends BaseMrArgContainer {
        @Parameter(names = "-hbaseIp", description = "hbase ip")
        private String hbaseIp = "";

        @Parameter(names = "-hbasePort", description = "hbase port")
        private Integer hbasePort = 2181;

        @Parameter(names = "-itemTableName", description = "reco item table in hbase")
        private String itemTableName = "tb_reco_item";


        public String getHbaseIp() {
            return hbaseIp;
        }

        public void setHbaseIp(String hbaseIp) {
            this.hbaseIp = hbaseIp;
        }

        public Integer getHbasePort() {
            return hbasePort;
        }

        public void setHbasePort(Integer hbasePort) {
            this.hbasePort = hbasePort;
        }

        public String getItemTableName() {
            return itemTableName;
        }

        public void setItemTableName(String itemTableName) {
            this.itemTableName = itemTableName;
        }
    }
}
