package com.tudou.recommend.up.utils;

import org.junit.Test;

import static org.assertj.core.api.Assertions.*;

/**
 * Created by pharosa on 2017/8/2.
 */
public class YTLogUtilsTest {
    @Test
    public void testIsFeedClick() throws Exception {
        assertThat(YTLogUtils.isFeedClick("newtd", "a2h04.8165617.home.home")).isEqualTo(false);
        assertThat(YTLogUtils.isFeedClick("newtd", "a2h2f.8294701.home.home")).isEqualTo(true);
        assertThat(YTLogUtils.isFeedClick("youku", "a2h04.8165617.home.home")).isEqualTo(true);
        assertThat(YTLogUtils.isFeedClick("youku", "a2h2f.8294701.home.home")).isEqualTo(false);
    }
}