package com.tudou.recommend.up.utils;

/**
 * Chinese character utility.
 *
 * @author chjin
 *         2014-9-10 上午11:24:54
 */
public class CharacterUtils {

    /**
     * Convert String to Float
     *
     * @param str: input string.
     * @param def: default value of float
     * @return
     */
    public static float stringToFloat(String str, float def) {
        float floatRet = def;
        try {
            if (str == null || str.trim().equals("")) {
                str = def + "";
            }
            floatRet = Float.parseFloat(str);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return floatRet;
    }

    /**
     * Convert String to Double
     *
     * @param str: input string.
     * @param def: default value of double
     * @return
     */
    public static double stringToDouble(String str, double def) {
        double doubleRet = def;
        try {
            if (str == null || str.trim().equals("")) {
                str = def + "";
            }
            doubleRet = Double.parseDouble(str);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return doubleRet;
    }

    /**
     * Convert String to Integer
     *
     * @param str: input string.
     * @param def: default value of integer
     * @return
     */
    public static int stringToInt(String str, int def) {
        int intRet = def;
        try {
            if (str == null || str.trim().equals("")) {
                str = def + "";
            }
            intRet = Integer.parseInt(str);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return intRet;
    }

    /**
     * check input character is Chinese
     *
     * @param c
     * @return
     */
    public static boolean isChinese(char c) {

        Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);

        if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
                || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B
                || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS
                || ub == Character.UnicodeBlock.GENERAL_PUNCTUATION) {
            return true;
        }

        return false;
    }

    /**
     * 识别字符类型
     *
     * @param input
     * @return int 0.Useless word 1.Arabic number 2.English 3.Chinese 4.Wide Characters and Korean, Japanise Characters.
     */
    public static int characterType(char input) {
        if (isPunctuation(input)) {
            return 5;
        }
        if (input >= '0' && input <= '9') {
            return 1;

        } else if ((input >= 'a' && input <= 'z')
                || (input >= 'A' && input <= 'Z')) {
            return 2;

        } else {
            Character.UnicodeBlock ub = Character.UnicodeBlock.of(input);

            if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
                    || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
                    || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
                    || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B
                    ) {
                //目前已知的中文字符UTF-8集合
                return 3;

            } else if (
                //韩文字符集
                    ub == Character.UnicodeBlock.HANGUL_SYLLABLES
                            || ub == Character.UnicodeBlock.HANGUL_JAMO
                            || ub == Character.UnicodeBlock.HANGUL_COMPATIBILITY_JAMO
                            //日文字符集
                            || ub == Character.UnicodeBlock.HIRAGANA //平假名
                            || ub == Character.UnicodeBlock.KATAKANA //片假名
                            || ub == Character.UnicodeBlock.KATAKANA_PHONETIC_EXTENSIONS
                    ) {
                return 4;

            }
        }
        //其他的不做处理的字符
        return 0;
    }

    /**
     * 进行字符规格化（全角转半角处理）
     *
     * @param input
     * @return char
     */
    public static char dbcToSbc(char input) {
        if (input == 12288) {
            input = (char) 32;

        } else if (input > 65280 && input < 65375) {
            input = (char) (input - 65248);

        }

        return input;
    }

    // 根据UnicodeBlock方法判断中文标点符号
    public static boolean isChinesePunctuation(char c) {
        Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
        if (ub == Character.UnicodeBlock.GENERAL_PUNCTUATION
                || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
                || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS
                || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_FORMS
                || ub == Character.UnicodeBlock.VERTICAL_FORMS) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean isLatinPunctuation(char c) {
        return c <= '~' && !isLatinNumber(c) && !isLatinAlphabet(c);
    }

    public static boolean isLatinNumber(char c) {
        return (c >= '0') && (c <= '9');
    }

    public static boolean isLatinAlphabet(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }

    public static boolean isPunctuation(char c) {
        return isLatinPunctuation(c) || isChinesePunctuation(c);
    }

    /**
     * Calculate the words num of sentence.
     *
     * @param sentence
     * @return Count of the sentence word.
     */
    public static long sentenceWordCount(String sentence) {
        int length = 0;
        int previous = -1;
        int type = 0;
        for (int i = 0; i < sentence.length(); i++) {
            char character = sentence.charAt(i);
            type = CharacterUtils.characterType(character);
            //If the previous is number or alphabet and current is punctuation.
            if ((previous == 2 || previous == 1) && (type == 5 || type == 0)) {
                length += 1;
            }
            //If the previous is CJK.
            if (type == 3 || type == 4) {
                if (previous == 1 || previous == 2) {
                    length += 1;
                }
                length += 1;
            }
            if (previous == -1 && type == 5) {
                previous = -1;
            } else {
                previous = type;
            }
        }
        if (type == 1 || type == 2) {
            length++;
        }
        return length;
    }

    public static int sentenceType(String sentence) {
        int enCount = 0;
        int chCount = 0;

        for (int i = 0; i < sentence.length(); i++) {
            char character = sentence.charAt(i);
            int type = CharacterUtils.characterType(character);

            if (type == 2 || type == 1) {
                enCount += 1;
            }
            //If the previous is CJK.
            if (type == 3 || type == 4) {
                chCount++;
            }

        }

        if (enCount > 0 && chCount == 0) {
            return 1;
        } else if (enCount > 0 && chCount > 0) {
            return 2;
        } else if (enCount == 0 && chCount > 0) {
            return 3;
        } else {
            return 0;
        }
    }

}
