package com.tudou.recommend.up.utils;

import com.tudou.recommend.up.constant.AppName;

import java.util.regex.Pattern;

/**
 * Created by pharosa on 2017/7/31.
 */
public class YTLogUtils {
    private static Pattern patternYoukuFeed = Pattern.compile("a2h04\\.8165617");
    private static Pattern patternNewtdFeed = Pattern.compile("a2h2f\\.8294701");

    public static boolean isFeedClick(String site, String spmUrl) {
        if (AppName.YOUKU_SITE.equals(site)) {
            return patternYoukuFeed.matcher(spmUrl).find();
        } else if (AppName.NEWTD_SITE.equals(site)) {
            return patternNewtdFeed.matcher(spmUrl).find();
        }
        return false;
    }
}
