package com.tudou.recommend.up.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Wangfei on 2017/4/24.
 */
public class DeviceUtils {
    private static Pattern UTDID_PATTERN = Pattern.compile(".{24}");
    private static Pattern IDFA_PATTERN = Pattern.compile("^[0-9a-zA-Z]{8}(-[0-9a-zA-Z]{4}){4}[0-9a-zA-Z]{8}$");
    private static Pattern IMEI_PATTERN = Pattern.compile("^\\d{15}$");
    private static Pattern SHOW_ID_PATTERN = Pattern.compile("\\d\\d+");
    private static Pattern VIDEO_ID_PATTERN = Pattern.compile("\\d\\d+");

    public static boolean isUTDID(String utdid) {
        return regex(UTDID_PATTERN, utdid);
    }

    public static boolean isIDFA(String idfa) {
        return regex(IDFA_PATTERN, idfa);
    }

    public static boolean isIMEI(String imei) {
        return regex(IMEI_PATTERN, imei);
    }

    public static boolean isShow(String showId) {
        return regex(SHOW_ID_PATTERN, showId);
    }

    public static boolean isVideo(String videoId) {
        return regex(VIDEO_ID_PATTERN, videoId);
    }

    public static boolean regex(Pattern pattern, String text) {
        if (text == null) {
            return false;
        }
        Matcher matcher = pattern.matcher(text);
        if (matcher.matches()) {
            return true;
        }
        return false;
    }
}
