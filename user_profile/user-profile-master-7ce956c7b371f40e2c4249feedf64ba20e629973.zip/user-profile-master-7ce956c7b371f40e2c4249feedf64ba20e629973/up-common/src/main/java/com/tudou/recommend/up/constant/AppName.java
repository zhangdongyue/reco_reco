package com.tudou.recommend.up.constant;

/**
 * Created by pharosa on 2017/7/31.
 */
public class AppName {
    public static String UC_IFLOW = "uc-iflow";
    public static String NEWTD_IFLOW = "newtudou-iflow";
    public static String YOUKU_IFLOW = "youkunews-iflow";
    public static String YOUKU_SITE = "youku";
    public static String NEWTD_SITE = "newtd";

    public static String getAppName(String site) {
        if (NEWTD_SITE.equals(site)) {
            return NEWTD_IFLOW;
        }
        if (YOUKU_SITE.equals(site)) {
            return YOUKU_IFLOW;
        }
        return null;
    }
}
