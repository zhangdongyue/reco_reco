package com.tudou.recommend.up.utils;

/**
 * Utils for parse Key Value style String.
 *
 * @author wangfei01
 * @date 20170731
 */
public class KeyValueParseUtils {
    /**
     * Get value from parameter string like : "k1=v1&k2=v2&k3=v3". When this method is called with key k2,
     * then v2 is returned.
     *
     * @param args    the parameter string.
     * @param key     Assigned key.
     * @param paraSep Separator between parameters.
     * @param kvSep   Separator between key and value.
     * @return The value of the key.
     */
    public static String getValue(String args, String key, String paraSep, String kvSep) {
        String[] tokens = args.split(paraSep);
        if (tokens.length <= 0 || key == null) {
            return null;
        }
        for (String token : tokens) {
            String[] keyValue = token.split(kvSep);
            if (keyValue.length == 2 && key.equals(keyValue[0])) {
                return keyValue[1].trim();
            }
        }
        return null;
    }
}
