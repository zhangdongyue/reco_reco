package com.tudou.recommend.up.storm.track;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.shenma.wolong.kafka.KafkaProducer;
import com.shenma.wolong.kafka.KafkaProducerBuilder;
import com.wolong.reco.proto.ProtoDictServer;
import com.wolong.reco.proto.ProtoYoukuShowTrace.*;
import com.tudou.recommend.up.storm.common.DictServerClient;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by Wangfei on 2017/5/22.
 */
public class TrackShowProtoBolt extends BaseRichBolt {
    private static final Logger logger = LoggerFactory.getLogger(TrackShowProtoBolt.class);
    private static String PRODUCTION = "newtd-track";
    private static Integer VERSION = 1;
    private DictServerClient dictServerClient;
    private OutputCollector collector;
    private KafkaProducer<byte[]> kafkaProducer;
    private double alpha = 0.5;
    private double beta = 1.0;
    private int expireDays = 7;
    private Boolean isDebug = false;
    private String kafkaBroker;
    private int partitionBegin;
    private int partitionEnd;
    private int batchSize;
    private String kafkaTopic;
    private List<Future<RecordMetadata>> buffer = new ArrayList<>();
    private AtomicInteger failedCount =new AtomicInteger(0);

    private boolean initKafkaProducer() {
        KafkaProducerBuilder kafkaBuilder = KafkaProducerBuilder.custom();
        kafkaBuilder.setBrokerList(kafkaBroker);
        kafkaProducer = kafkaBuilder.build();
        return true;
    }

    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        try {
            String dictServerAddresses = stormConf.get("dict.server.address").toString();
            this.dictServerClient = new DictServerClient(dictServerAddresses);

            kafkaBroker = stormConf.get("kafka.broker").toString();
            kafkaTopic = stormConf.get("kafka.topic").toString();
            partitionBegin = Integer.parseInt(stormConf.get("kafka.partition.begin").toString());
            partitionEnd = Integer.parseInt(stormConf.get("kafka.partition.end").toString());
            batchSize = Integer.parseInt(stormConf.get("batch.size").toString());
            alpha = Double.parseDouble(stormConf.get("weight.alpha").toString());
            beta = Double.parseDouble(stormConf.get("weight.beta").toString());
            expireDays = Integer.parseInt(stormConf.get("expire.days").toString());
            isDebug = Boolean.parseBoolean(stormConf.get("log.debug").toString());
            if (!initKafkaProducer()) {
                throw new IOException("Cannot init kafka producer.");
            }
            if (partitionBegin < 0 || partitionEnd < 0 || partitionEnd - partitionBegin <= 0) {
                throw new IOException("Partition begin or end assigned error.");
            }
            this.collector = collector;
        } catch (Exception e) {
            logger.error("connect to dict server failed.", e);
        }
    }

    @Override
    public void execute(Tuple input) {
        try {
            String userId = input.getStringByField("user_id");
            Integer showId = input.getIntegerByField("show_id");
            Integer videoId = input.getIntegerByField("vdo_id");
            Double playRate = input.getDoubleByField("play_rate");
            Long serverTime = input.getLongByField("server_time");
            Double endPlayPoint = input.getDoubleByField("end_point");
            byte[] bytes = dictServerClient.getData(PRODUCTION,
                    userId.getBytes("UTF-8"), VERSION);
            YoukuUserTracker userTracker = null;
            try {
                userTracker = YoukuUserTracker.parseFrom(bytes);
                if (isDebug) {
                    logger.info("fetch show tracker: {}->{}", userId, userTracker.toString());
                }
            } catch (InvalidProtocolBufferException e) {
                if (isDebug) {
                    logger.error("Get protobuf decode error.", e);
                }
                userTracker = YoukuUserTracker.newBuilder().build();
            }
            userTracker = updateUserTracker(userTracker, showId, videoId, playRate,
                    serverTime, endPlayPoint, alpha, beta);

            ProtoDictServer.KeyElements.Builder keyElementBuilder = ProtoDictServer.KeyElements.newBuilder();
            keyElementBuilder.setKey(ByteString.copyFromUtf8(userId));
            keyElementBuilder.setProduct(ByteString.copyFromUtf8(PRODUCTION));
            keyElementBuilder.setVersion(ByteString.copyFromUtf8(VERSION.toString()));
            ProtoDictServer.SetDataRequest.Builder msgBuilder = ProtoDictServer.SetDataRequest.newBuilder();
            msgBuilder.setKeyElements(keyElementBuilder.build());
            msgBuilder.setValue(userTracker.toByteString());

            buffer.add(kafkaProducer.asyncSend(kafkaTopic, userId, msgBuilder.build().toByteArray()));
            if (buffer.size() >= batchSize) {
                for (Future<RecordMetadata> future : buffer) {
                    try {
                        future.get();
                    } catch (Exception e) {
                        logger.info("get future result error.", e);
                    }
                }
                logger.info("batch send kafka message with size:{}", buffer.size());
                buffer.clear();
            }

            if (isDebug) {
                logger.info("save show tracker: {}->{}", userId, userTracker.toString());
            }
            collector.ack(input);
        } catch (UnsupportedEncodingException e) {
            logger.error("Get protobuf encode error.", e);
        } catch (Exception e){
            if(failedCount.get()>=10) {
                kafkaProducer.close();
                initKafkaProducer();
                logger.error("restart kafka producer to recover job.");
                failedCount.set(0);
            }else{
                failedCount.incrementAndGet();
            }
        }
    }

    public YoukuUserTracker updateUserTracker(YoukuUserTracker userTracker,
                                              int showId,
                                              int videoId,
                                              double playRate,
                                              long serverTime,
                                              double endPlayPoint,
                                              double alpha,
                                              double beta) {
        Map<Integer, YoukuShowTrace> map = new HashMap<>();
        for (YoukuShowTrace trace : userTracker.getTracesList()) {
            int show = trace.getYoukuShowId();
            int vdo = trace.getLastPlayedVideo();
            if (!isExpired(trace.getLastPlayedTimestamp())) {
                map.put(show, trace);
                if (showId == show) {
                    YoukuShowTrace.Builder builder = trace.toBuilder();
                    int episodes = vdo == videoId ? trace.getTotalPlayedEpisodes() : (trace.getTotalPlayedEpisodes() + 1);
                    double preWeight = trace.getWeight();
                    double currentWeight = weight(preWeight, playRate, episodes, alpha, beta);
                    builder.setLastPlayedVideo(videoId);
                    builder.setLastPlayedRate(playRate);
                    builder.setLastPlayedTimestamp(serverTime);
                    builder.setTotalPlayedEpisodes(episodes);
                    builder.setWeight(currentWeight);
                    builder.setLastEndPoint(endPlayPoint);
                    map.put(showId, builder.build());
                }
            }
        }
        if (!map.containsKey(showId)) {
            YoukuShowTrace trace = YoukuShowTrace.newBuilder()
                    .setYoukuShowId(showId)
                    .setLastPlayedVideo(videoId)
                    .setLastPlayedTimestamp(serverTime)
                    .setLastPlayedRate(playRate)
                    .setTotalPlayedEpisodes(1)
                    .setWeight(weight(0, playRate, 1, alpha, beta))
                    .build();
            map.put(showId, trace);
        }
        return YoukuUserTracker.newBuilder()
                .addAllTraces(map.values())
                .build();
    }

    /**
     * Make sure the track show data is not expired.
     *
     * @param serverTime
     * @return
     */
    public boolean isExpired(long serverTime) {
        long current = System.currentTimeMillis();
        if ((current - serverTime) > TimeUnit.DAYS.toMillis(expireDays)) {
            return true;
        }
        return false;
    }

    /**
     * The weight value is approximate to the probability of watching next episode of the show.
     * $$
     * p_t = \frac{1}{1+\frac{e^{-\alpha*ep_t}}{\beta*r_{t}}}
     * $$
     * Top function is sigmod of watch records count($\alpha*ep_t$)
     * with leverage of play rate(\beta * r_t).
     * $$
     * w_{t} = \frac{p_t+e^{-\alpha*ep_t}*w_{t-1}}{1+e^{-\alpha*ep_t}}
     * $$
     * The second function combine previous weight($w_{t-1}$) with current weight($p_t$)
     * with consideration of the more show videos watched the less importance of current
     * weight.
     * $t$ donates the records that receive by storm.
     *
     * @param preWeight   $w_{t-1}$
     * @param currentRate $r_t$
     * @param episodes    $ep_t$
     * @param alpha       $\alpha$
     * @param beta        $\beta$
     * @return
     */
    public double weight(double preWeight,
                         double currentRate,
                         int episodes,
                         double alpha,
                         double beta) {
        double expo = Math.exp(-alpha * episodes);
        double prob = 1 / (1 + expo / (beta * currentRate));
        return (prob + expo * preWeight) / (expo + 1);
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {

    }
}
