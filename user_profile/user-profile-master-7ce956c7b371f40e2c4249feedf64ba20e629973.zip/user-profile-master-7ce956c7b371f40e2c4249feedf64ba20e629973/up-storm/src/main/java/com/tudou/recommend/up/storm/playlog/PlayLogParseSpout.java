package com.tudou.recommend.up.storm.playlog;

import com.alibaba.tt.exception.TTQueueException;
import com.google.common.base.Joiner;
import com.google.common.base.Strings;
import com.tudou.recommend.up.constant.AppName;
import com.tudou.recommend.up.storm.common.ClickLog;
import com.tudou.recommend.up.storm.common.TTReader;
import com.tudou.recommend.up.storm.util.LogUtils;
import com.tudou.recommend.up.utils.DeviceUtils;
import com.tudou.recommend.up.utils.YTLogUtils;
import com.wolong.reco.common.entity.IflowUser;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * This Spout digests tt log and send the pre-filtered click log to filter bolt.
 * This Spout with fetch block of logs for each request to TT and splits into log for parsing.
 * Finally only the desired log will be sent to next bolt.
 *
 * @author wangfei01
 * @date 20170802
 */
public class PlayLogParseSpout extends BaseRichSpout {
    private static final Logger logger = LoggerFactory.getLogger(PlayLogParseSpout.class);
    private static String CLICK_EVENT = "12003";
    private Integer playSecondsThreshold;
    private boolean isDebug = false;
    private SpoutOutputCollector collector;
    private TTReader ttReader;
    private List<Integer> queueIndexes;
    private Set<String> sites = new HashSet<>();

    public PlayLogParseSpout(List<Integer> queueIndexes) {
        this.queueIndexes = queueIndexes;
    }

    @Override
    public void open(Map conf, TopologyContext context, SpoutOutputCollector collector) {
        this.collector = collector;
        logger.info("create spout:{} with queues:{}",
                context.getThisComponentId(),
                Joiner.on(", ").join(queueIndexes));
        String topic = conf.get("tt.topic").toString();
        String subscribeId = conf.get("tt.subscribe.id").toString();
        String accessKey = conf.get("tt.access.key").toString();
        Object allowSites = conf.get("allow.sites");
        playSecondsThreshold = Integer.parseInt(conf.get("play.seconds.threshold").toString());
        if (allowSites != null) {
            String[] tokens = allowSites.toString().split(",");
            for (String token : tokens) {
                String site = token.trim();
                if (!site.isEmpty()) {
                    sites.add(site);
                }
            }
        }
        isDebug = Boolean.parseBoolean(conf.get("log.debug").toString());

        int bufferSize = Integer.parseInt(conf.get("tt.buffer.size").toString());
        try {
            Object ttSecondsAche = conf.get("tt.seconds.ahead");
            if (ttSecondsAche != null) {
                Long secondsAche = Long.parseLong(ttSecondsAche.toString());
                this.ttReader = new TTReader(topic,
                        subscribeId,
                        accessKey,
                        secondsAche,
                        queueIndexes,
                        bufferSize);
            } else {
                this.ttReader = new TTReader(topic,
                        subscribeId,
                        accessKey,
                        queueIndexes,
                        bufferSize);
            }
        } catch (TTQueueException e) {
            logger.error("Can not create TT reader.", e);
            throw new RuntimeException(e);
        }
    }

    public int versionCompare(String v1, String v2) {
        String[] version1 = v1.split("\\.");
        String[] version2 = v2.split("\\.");
        for (int i = 0; i < Math.min(version1.length, version2.length); i++) {
            int gap = Integer.parseInt(version1[i]) - Integer.parseInt(version2[i]);
            if (gap != 0) {
                return gap;
            }
        }
        if (version1.length > version2.length) {
            return 1;
        } else if (version1.length < version2.length) {
            return -1;
        }
        return 0;
    }

    public String generateUserId(String appName, String appVersion, String guid, String utdid) {
        //(utdid 为空 || 版本为空 || 版本是6 .2 .1 以下（不含6 .2 .1） )  && guid 不为空
        try {
            if (versionCompare("6.2.1", appVersion) > 0 && !Strings.isNullOrEmpty(guid)) {
                logger.info("The app version:{},guid:{}", appVersion, guid);
                return IflowUser.getUserId(appName, guid);
            }
        } catch (Exception e) {
            logger.info("catch error during version compare.", e.getMessage());
            appVersion = null;
        }
        if (Strings.isNullOrEmpty(appVersion) && !Strings.isNullOrEmpty(guid)) {
            logger.info("The app version:{},guid:{}", appVersion, guid);
            return IflowUser.getUserId(appName, guid);
        }
        if (Strings.isNullOrEmpty(utdid)) {
            if (!Strings.isNullOrEmpty(guid)) {
                logger.info("The app version:{},guid:{}", appVersion, guid);
                return IflowUser.getUserId(appName, guid);
            }
            return null;
        }
        return IflowUser.getUserId(appName, utdid);
    }

    @Override
    public void nextTuple() {
        try {
            byte[] data = ttReader.next();
            List<ClickLog> logBatch = ClickLog.fromBytes(data);
            for (ClickLog log : logBatch) {
                String utdid = log.getUtdid();
                String showId = log.getShowId();
                String vdoId = log.getVdoId();
                String vdoLen = log.getVdoLen();
                String ts = log.getTs();
                String serverTime = log.getServerTime();
                String site = log.getSite();
                String eventId = log.getEventId();
                String spmUrl = log.getSpmUrl();
                String appName = AppName.getAppName(site);
                String args = log.getArgs();
                String appVersion = log.getAppVersion();
                String guid = log.getGuid();
                String userId = generateUserId(appName, appVersion, guid, utdid);
                int autoPlay = LogUtils.argsInt(args, "autoPlay");
                if ((sites.size() == 0 || sites.contains(site))
                        && autoPlay != 1
                        && !YTLogUtils.isFeedClick(site, spmUrl)
                        && userId != null
                        && DeviceUtils.isVideo(vdoId)
                        && CLICK_EVENT.equals(eventId)
                        && vdoLen != null
                        && ts != null
                        && serverTime != null) {
                    long show = 0L;
                    if (NumberUtils.isParsable(showId)) {
                        show = Long.parseLong(showId);
                    }
                    long video = Long.parseLong(vdoId);
                    int len = 0;
                    if (NumberUtils.isParsable(vdoLen)) {
                        len = (int) Double.parseDouble(vdoLen);
                    }
                    int play = 0;
                    if (NumberUtils.isParsable(ts)) {
                        play = (int) Double.parseDouble(ts);
                    }
                    long timestamp = 0L;
                    if (NumberUtils.isParsable(serverTime)) {
                        timestamp = TimeUnit.MILLISECONDS.toSeconds(Long.parseLong(serverTime));
                    }
                    // If the play seconds is over the threshold, then this record is valid.
                    if (play >= playSecondsThreshold) {
                        collector.emit(new Values(userId, appName, video, len, play, timestamp, show), userId.hashCode());
                    }
                }
            }
        } catch (InterruptedException e) {
            logger.error("catch interrupted exception.", e);
        } catch (UnsupportedEncodingException e) {
            logger.error("encoding log error.", e);
        }
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("user_id", "app_name", "vdo_id", "vdo_len", "ts", "server_time", "yt_show_id"));
    }
}
