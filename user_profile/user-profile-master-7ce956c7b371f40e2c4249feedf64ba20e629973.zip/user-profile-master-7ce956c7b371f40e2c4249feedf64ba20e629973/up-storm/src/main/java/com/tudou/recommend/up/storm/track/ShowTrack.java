package com.tudou.recommend.up.storm.track;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Created by Wangfei on 2017/5/23.
 */
public class ShowTrack {
    private Map<Integer, Track> showTrackMap;

    public Map<Integer, Track> getShowTrackMap() {
        return showTrackMap;
    }

    public void setShowTrackMap(Map<Integer, Track> showTrackMap) {
        this.showTrackMap = showTrackMap;
    }

    public void update(Integer showId, Integer videoId, Double playRate) {
        Track track = new Track(videoId, playRate);
        if (showTrackMap == null) {
            showTrackMap = new HashMap<>();
        }
        showTrackMap.put(showId, track);
    }

    public byte[] toBytes() throws UnsupportedEncodingException {
        return toString().getBytes("UTF-8");
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        if (showTrackMap != null) {
            Set<Map.Entry<Integer, Track>> set = showTrackMap.entrySet();
            for (Map.Entry<Integer, Track> entry : set) {
                Integer videoId = entry.getKey();
                Track playRate = entry.getValue();
                builder.append(videoId)
                        .append(":")
                        .append(playRate)
                        .append("\t");
            }
        }
        return builder.toString();
    }

    public static ShowTrack fromBytes(byte[] bytes) throws UnsupportedEncodingException {
        ShowTrack showTrack = new ShowTrack();
        if (bytes == null) {
            return showTrack;
        }
        String tracks = new String(bytes, "UTF-8");
        String[] shows = tracks.split("\t");
        Map<Integer, Track> map = new HashMap<>();
        for (String show : shows) {
            String[] tokens = show.split(":");
            if (tokens.length == 3) {
                map.put(Integer.parseInt(tokens[0]),
                        new Track(Integer.parseInt(tokens[1]), Double.parseDouble(tokens[2])));
            }
        }
        showTrack.setShowTrackMap(map);
        return showTrack;
    }

    static class Track {
        private Integer videoId;
        private Double rate;

        public Track(Integer videoId, Double rate) {
            this.videoId = videoId;
            this.rate = rate;
        }

        public void update(Integer videoId, Double rate) {
            this.videoId = videoId;
            this.rate = rate;
        }

        @Override
        public String toString() {
            return String.format("%d:%.2f", videoId, rate);
        }
    }
}

