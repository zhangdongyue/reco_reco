package com.tudou.recommend.up.storm.playlog;

import com.tudou.recommend.up.storm.common.UserServerClient;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

import java.util.Map;

/**
 * Filter user id which has show history in user server.
 * The query result from user server is storm with LRU cache to release frequent rpc request.
 *
 * @author wangfei01
 * @date 20170802
 */
public class PlayLogFilterBolt extends BaseRichBolt {
    private UserServerClient client;
    private OutputCollector collector;


    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        this.collector = collector;
        String addresses = stormConf.get("user.server.addresses").toString();
        String timeout = stormConf.get("user.server.timeout").toString();
        String retry = stormConf.get("user.server.retry").toString();
        client = UserServerClient.newInstance(addresses, Integer.parseInt(timeout), Integer.parseInt(retry));
    }

    @Override
    public void execute(Tuple input) {
        String userId = input.getStringByField("user_id");
        String appName = input.getStringByField("app_name");
        Long vdoId = input.getLongByField("vdo_id");
        Integer vdoLen = input.getIntegerByField("vdo_len");
        Integer ts = input.getIntegerByField("ts");
        Long serverTime = input.getLongByField("server_time");
        Long showId = input.getLongByField("yt_show_id");
        if (userId != null) {
            boolean hasShowHistory = client.hasShowHistory(userId, appName);
            if (hasShowHistory) {
                collector.emit(new Values(userId, appName, vdoId, vdoLen, ts, serverTime, showId));
            }
        }
        collector.ack(input);
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("user_id", "app_name", "vdo_id", "vdo_len", "ts", "server_time", "yt_show_id"));
    }
}
