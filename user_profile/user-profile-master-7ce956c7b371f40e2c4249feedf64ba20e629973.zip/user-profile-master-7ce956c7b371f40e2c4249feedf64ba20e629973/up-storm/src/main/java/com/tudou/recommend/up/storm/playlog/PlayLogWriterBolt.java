package com.tudou.recommend.up.storm.playlog;

import com.tudou.recommend.up.storm.common.UserServerClient;
import com.wolong.reco.proto.ProtoUser.*;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.BasicOutputCollector;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseBasicBolt;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Tuple;
import org.apache.storm.tuple.Values;

import java.util.Map;

/**
 * Created by pharosa on 2017/7/31.
 */
public class PlayLogWriterBolt extends BaseRichBolt {
    private UserServerClient client;
    private OutputCollector collector;

    @Override
    public void prepare(Map stormConf, TopologyContext context, OutputCollector collector) {
        this.collector = collector;
        String addresses = stormConf.get("user.server.addresses").toString();
        String timeout = stormConf.get("user.server.timeout").toString();
        String retry = stormConf.get("user.server.retry").toString();
        client = UserServerClient.newInstance(addresses, Integer.parseInt(timeout), Integer.parseInt(retry));
    }

    @Override
    public void execute(Tuple input) {
        String userId = input.getStringByField("user_id");
        String appName = input.getStringByField("app_name");
        Long vdoId = input.getLongByField("vdo_id");
        Integer vdoLen = input.getIntegerByField("vdo_len");
        Integer ts = input.getIntegerByField("ts");
        Long serverTime = input.getLongByField("server_time");
        Long showId = input.getLongByField("yt_show_id");
        if (userId != null) {
            YtViewClickItem item = YtViewClickItem.newBuilder()
                    .setVideoId(vdoId)
                    .setVideoLength(vdoLen)
                    .setTs(ts)
                    .setServerTime(serverTime)
                    .setYtShowId(showId)
                    .build();
            boolean hasShowHistory = client.updateYtRecentClick(userId, appName, item);
            if (hasShowHistory) {
                collector.emit(new Values(userId, appName, vdoId, vdoLen, ts, serverTime, showId));
            }
        }
        collector.ack(input);
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {

    }
}
