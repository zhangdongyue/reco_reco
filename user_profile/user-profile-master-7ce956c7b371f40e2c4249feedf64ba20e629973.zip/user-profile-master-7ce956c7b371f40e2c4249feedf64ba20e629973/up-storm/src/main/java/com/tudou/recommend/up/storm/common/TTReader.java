package com.tudou.recommend.up.storm.common;

import com.alibaba.tt.exception.TTQueueException;
import com.alibaba.tt.exception.TTQueueSafemodeException;
import com.alibaba.tt.exception.TTSubChangedException;
import com.alibaba.tt.log.TTLog;
import com.alibaba.tt.log.TTLogInput;
import com.alibaba.tt.log.impl.TTLogBlock;
import com.alibaba.tt.log.impl.TTLogImpl;
import com.alibaba.tt.log.impl.TTLogSimpleInput;
import com.google.common.base.Joiner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.*;


public class TTReader {
    private final Logger logger = LoggerFactory.getLogger(TTReader.class);
    private final ExecutorService threadPool;
    private final BlockingQueue<TTLogBlock> buffer;

    public TTReader(String topic,
                    String subscribeId,
                    String accessKey,
                    Long secondsAhead,
                    List<Integer> queueIndexes,
                    int bufferSize) throws TTQueueException {
        threadPool = Executors.newFixedThreadPool(queueIndexes.size());
        buffer = new LinkedBlockingDeque<>(bufferSize);
        Long beginDate = TimeUnit.MILLISECONDS
                .toSeconds(System.currentTimeMillis()) - secondsAhead;
        for (Integer index : queueIndexes) {
            TTLog ttLog = new TTLogImpl(topic, subscribeId, accessKey);
            threadPool.submit(new Reader(ttLog, beginDate, index, buffer));
        }
    }

    public TTReader(String topic,
                    String subscribeId,
                    String accessKey,
                    List<Integer> queueIndexes,
                    int bufferSize) throws TTQueueException {
        logger.info("create TT reader with queues:{}", Joiner.on(",").join(queueIndexes));
        threadPool = Executors.newFixedThreadPool(queueIndexes.size());
        buffer = new ArrayBlockingQueue<>(bufferSize);
        for (Integer index : queueIndexes) {
            TTLog ttLog = new TTLogImpl(topic, subscribeId, accessKey);
            threadPool.submit(new Reader(ttLog, index, buffer));
        }
    }


    /**
     * @throws InterruptedException
     * @returndata could be states below:
     * 1. null：empty data.
     * 2. heartbeat that moves the offset.
     * 3. correct data.
     */
    public byte[] next() throws InterruptedException {
        TTLogBlock block = null;
        try {
            block = buffer.take();
            byte[] data = block.getBuffer();
            return data;
        } finally {
            // every block should call ack if processed.
            if (block != null) {
                block.getKey().ack();
            }
        }
    }

    class Reader implements Runnable {
        private final TTLog ttLog;
        private final BlockingQueue<TTLogBlock> buffer;
        private final int queueIndex;
        private TTLogInput input;
        private Long startDate;

        public Reader(TTLog ttLog,
                      Long startDate,
                      int queueIndex,
                      BlockingQueue<TTLogBlock> buffer) {
            assert (ttLog != null && queueIndex >= 0 && buffer != null);
            this.ttLog = ttLog;
            this.queueIndex = queueIndex;
            this.buffer = buffer;
            this.startDate = startDate;
        }

        public Reader(TTLog ttLog,
                      int queueIndex,
                      BlockingQueue<TTLogBlock> buffer) {
            this(ttLog, null, queueIndex, buffer);
        }

        /**
         * Create the TT input
         */
        private void createInput(Long startDate) {
            try {
                // First destroy the input.
                if (this.input != null) {
                    this.input.close();
                }

                /**
                 * long ts = System.currentTimeMillis() / 1000;
                 * this.input = new TTLogSimpleInput(this.ttLog, ts, new int[]{this.queueIndex});
                 */
                if (startDate != null) {
                    this.input = new TTLogSimpleInput(this.ttLog, startDate, new int[]{this.queueIndex});
                } else {
                    this.input = new TTLogSimpleInput(this.ttLog, new int[]{this.queueIndex});
                }
                logger.info("create TT log input {}", queueIndex);
            } catch (TTQueueException e) {
                logger.error("Cannot initialize TT Queue.", e);
                // Retry for three times.
                for (int i = 0; i < 3; i++) {
                    try {
                        sleep(1000);
                        // First destroy the input.
                        if (this.input != null) {
                            this.input.close();
                        }
                        this.input = new TTLogSimpleInput(this.ttLog, new int[]{this.queueIndex});
                    } catch (TTQueueException e1) {
                        logger.error("Cannot initialize TT Queue.", e1);
                    }
                }
            }
        }

        private void sleep(long milliSeconds) {
            try {
                TimeUnit.MILLISECONDS.sleep(milliSeconds);
            } catch (InterruptedException e) {
                logger.error("Get interrupted exception.", e);
            }
        }

        @Override
        public void run() {
            createInput(startDate);
            TTLogBlock block = null;
            while (true) {
                try {
                    block = this.input.read();
                    if (block != null) {
                        startDate = block.getOffset();
                        byte[] ttData = block.getBuffer();
                        if (ttData.length == 0) {
                            block.getKey().ack();
                        }
                    }
                } catch (TTQueueException e) {
                    logger.error("input read failed", e);
                    //Triggered by network exception and TT degrade.
                    sleep(1000);
                    createInput(startDate);
                } catch (TTQueueSafemodeException e) {
                    logger.warn("input enter safe mode", e);
                    /**
                     * Triggered when offset is updated, typically when server
                     * open the safe mode. When queue is read by multiple clients,
                     * this exception is threw to make sure only one client could subscribe
                     * one specific queue.
                     */
                    sleep(1000);
                } catch (TTSubChangedException e) {
                    // Triggered when subscribe point is set on the web page.
                    logger.warn("input subscribe changed", e);
                    createInput(startDate);
                }
                if (block == null) {
                    // No more data when the block is null.
                    sleep(1000);
                    continue;
                }
                try {
                    this.buffer.put(block);
                } catch (InterruptedException e) {
                    logger.error("Catch interrupted exception.", e);
                }
            }
        }
    }

}

