package com.tudou.recommend.up.storm.track;

import com.alibaba.tt.exception.TTQueueException;
import com.google.common.base.Joiner;
import com.tudou.recommend.up.storm.common.ClickLog;
import com.tudou.recommend.up.storm.common.TTReader;
import com.tudou.recommend.up.storm.util.LogUtils;
import com.tudou.recommend.up.utils.DeviceUtils;
import com.wolong.reco.common.entity.IflowUser;
import org.apache.storm.spout.SpoutOutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichSpout;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

/**
 * Created by Wangfei on 2017/5/22.
 */
public class TrackClickLogProtoSpout extends BaseRichSpout {
    private static final Logger logger = LoggerFactory.getLogger(TrackClickLogProtoSpout.class);
    private static double PLAY_SECOND_THRESHOLD = 5;
    private boolean isDebug = false;
    private SpoutOutputCollector collector;
    private TTReader ttReader;
    private List<Integer> queueIndexes;

    public TrackClickLogProtoSpout(List<Integer> queueIndexes) {
        this.queueIndexes = queueIndexes;
    }

    @Override
    public void open(Map conf, TopologyContext context, SpoutOutputCollector collector) {
        this.collector = collector;
        logger.info("create spout:{} with queues:{}",
                context.getThisComponentId(),
                Joiner.on(", ").join(queueIndexes));
        String topic = conf.get("tt.topic").toString();
        String subscribeId = conf.get("tt.subscribe.id").toString();
        String accessKey = conf.get("tt.access.key").toString();
        isDebug = Boolean.parseBoolean(conf.get("log.debug").toString());

        int bufferSize = Integer.parseInt(conf.get("tt.buffer.size").toString());
        try {
            Object ttSecondsAche = conf.get("tt.seconds.ahead");
            if (ttSecondsAche != null) {
                Long secondsAche = Long.parseLong(ttSecondsAche.toString());
                this.ttReader = new TTReader(topic,
                        subscribeId,
                        accessKey,
                        secondsAche,
                        queueIndexes,
                        bufferSize);
            } else {
                this.ttReader = new TTReader(topic,
                        subscribeId,
                        accessKey,
                        queueIndexes,
                        bufferSize);
            }
        } catch (TTQueueException e) {
            logger.error("Can not create TT reader.", e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public void nextTuple() {
        try {
            byte[] data = ttReader.next();
            List<ClickLog> logBatch = ClickLog.fromBytes(data);
            if (isDebug) {
                logger.info("fetch batch log size is: {}", logBatch.size());
            }
            for (ClickLog log : logBatch) {

                String utdid = log.getUtdid();
                String showId = log.getShowId();
                String vdoId = log.getVdoId();
                String vdoLen = log.getVdoLen();
                String ts = log.getTs();
                String serverTime = log.getServerTime();
                String vdoType = log.getVdoType();
                String site = log.getSite();
                String eventId = log.getEventId();
                String args = log.getArgs();
                if ("newtd".equals(site)
                        && DeviceUtils.isUTDID(utdid)
                        && DeviceUtils.isShow(showId)
                        && DeviceUtils.isVideo(vdoId)
                        && "正片".equals(vdoType)
                        && "12003".equals(eventId)
                        && vdoLen != null
                        && ts != null
                        && serverTime != null) {

                    String userId = utdid;
                    double endPlayPoint = LogUtils.argsDouble(args, "end_play_time") / 1000;
                    if (isDebug) {
                        logger.info("video info is :user_id:{}, utdid:{}, vdo_id:{}, " +
                                        "show_id:{}, vdo_type:{}, ts:{}, vdo_len:{}, event:{}," +
                                        " site:{}, end_time:{}",
                                userId, utdid, vdoId, showId, vdoType, ts, vdoLen, eventId, site, endPlayPoint);
                    }
                    Integer show = Integer.parseInt(showId);
                    Integer video = Integer.parseInt(vdoId);
                    double len = Double.parseDouble(vdoLen);
                    double play = Double.parseDouble(ts);
                    Long timestamp = Long.parseLong(serverTime);
                    Double playRate = Math.min(len == 0 ? -1 : play / len, 1);
                    endPlayPoint = Math.min(Math.max(play, endPlayPoint), len);
                    // If the play seconds is over the threshold, then this record is valid.
                    if (play >= PLAY_SECOND_THRESHOLD && playRate > 0) {
                        collector.emit(new Values(userId, show, video, playRate, timestamp, endPlayPoint),
                                log.hashCode());
                    }
                }
            }
        } catch (InterruptedException e) {
            logger.error("catch interrupted exception.", e);
        } catch (UnsupportedEncodingException e) {
            logger.error("encoding log error.", e);
        }
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer declarer) {
        declarer.declare(new Fields("user_id", "show_id", "vdo_id",
                "play_rate", "server_time", "end_point"));
    }
}
