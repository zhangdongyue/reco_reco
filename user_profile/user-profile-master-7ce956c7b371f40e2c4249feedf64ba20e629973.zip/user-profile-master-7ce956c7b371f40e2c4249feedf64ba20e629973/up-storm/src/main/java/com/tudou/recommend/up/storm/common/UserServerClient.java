package com.tudou.recommend.up.storm.common;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.protobuf.RpcController;
import com.wolong.protorpc.client.pool.PooledRpcClient;
import com.wolong.protorpc.client.protobuf.DefaultBlockingRpcChannel;
import com.wolong.protorpc.model.DefaultRpcController;
import com.wolong.reco.proto.ProtoCommon.UserIdentity;
import com.wolong.reco.proto.ProtoUser.*;
import com.wolong.reco.proto.ProtoUserServer.*;
import com.wolong.reco.proto.ProtoUserServer.GetUserFieldRequest;
import com.wolong.reco.proto.ProtoUserServer.GetUserFieldResponse;
import com.wolong.reco.proto.ProtoUserServer.UserFieldType;
import com.wolong.reco.proto.ProtoUserServer.UserService;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigInteger;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * User Server client that encapsulate update/get methods.
 * This client is not singleton and should be used carefully. The rpc connect/close/retry mechanism
 * is provide for convenient.
 *
 * @author wangfei01
 * @date 20170802
 */
public final class UserServerClient {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private PooledRpcClient client;
    private UserService.BlockingInterface userService;
    private String addresses;
    private int retry = 3;
    private int timeout = 500;
    private Cache<String, Boolean> hasShowHistoryLRUCache;
    private AtomicBoolean rpcInitialized = new AtomicBoolean(false);
    private StopWatch stopWatch = new StopWatch();
    private AtomicLong historyRequest = new AtomicLong(0L);
    private AtomicLong historyNotHit = new AtomicLong(0L);
    private AtomicLong updateRequest = new AtomicLong(0L);
    private AtomicLong hasShowHistory = new AtomicLong(0L);

    private UserServerClient(String addresses, int timeout, int retry) {
        this.addresses = addresses;
        this.timeout = timeout;
        this.retry = retry;
        init();
    }


    public static UserServerClient newInstance(String addresses, int timeout, int retry) {
        return new UserServerClient(addresses, timeout, retry);
    }

    /**
     * init process when this client is created.
     */
    public void init() {
        initRpc();
        initCache();
        stopWatch.start();
    }

    /**
     * Initialize a LRU cache to prevent frequent user server call.
     */
    public void initCache() {
        hasShowHistoryLRUCache = CacheBuilder.newBuilder()
                .expireAfterWrite(3, TimeUnit.HOURS)
                .concurrencyLevel(100)
                .initialCapacity(100000)
                .maximumSize(500000)
                .softValues()
                .build();
    }

    public void initRpc() {
        try {
            client = new PooledRpcClient(addresses, timeout);
            client.bootstrap();
            userService = UserService.newBlockingStub(new DefaultBlockingRpcChannel(client));
        } catch (Exception e) {
            logger.error("Initial RPC failed.", e);
        }
        rpcInitialized.set(true);
    }

    public void closeRpc() {
        rpcInitialized.set(false);
        if (client != null && !client.isStopped()) {
            client.stop();
        }
    }


    public void restartRpc() {
        closeRpc();
        initRpc();
    }

    public boolean updateYtRecentClick(String userId, String appToken, YtViewClickItem item) {
        if (userId == null) {
            return false;
        }
        metrics();
        for (int i = 0; i < retry; i++) {
            if (!rpcInitialized.get()) {
                initRpc();
            }
            UserIdentity userIdentity = UserIdentity.newBuilder()
                    .setUserId(new BigInteger(userId).longValue())
                    .setAppToken(appToken)
                    .setOuterId(userId)
                    .build();
            UpdateUserFieldRequest request = UpdateUserFieldRequest.newBuilder()
                    .setUser(userIdentity)
                    .setFieldType(UserFieldType.kYtRecentClick)
                    .addYtRecentClick(item)
                    .build();
            RpcController controller = new DefaultRpcController();
            try {
                UserServerCommonResponse response = userService.updateUserField(controller, request);
                updateRequest.incrementAndGet();
                if (response != null && response.getSuccess()) {
                    logger.info("send click log (user {}, appName:{}) succeed.", userId, appToken);
                    return true;
                }
            } catch (Exception e) {
                logger.error("update yt video click:{} error", item.toString(), e);
                if (i == retry / 2) {
                    restartRpc();
                }
            }
        }
        return false;
    }

    public boolean hasShowHistory(final String userId, final String appToken) {
        if (userId == null) {
            return false;
        }
        metrics();
        historyRequest.incrementAndGet();
        try {
            Boolean result = hasShowHistoryLRUCache.get(userId, new Callable<Boolean>() {
                @Override
                public Boolean call() throws Exception {
                    historyNotHit.incrementAndGet();
                    for (int i = 0; i < retry; i++) {
                        if (!rpcInitialized.get()) {
                            initRpc();
                        }
                        UserIdentity userIdentity = UserIdentity.newBuilder()
                                .setUserId(new BigInteger(userId).longValue())
                                .setAppToken(appToken)
                                .setOuterId(userId)
                                .build();
                        GetUserFieldRequest request = GetUserFieldRequest.newBuilder()
                                .setUser(userIdentity)
                                .addFieldTypes(UserFieldType.kShownHistory)
                                .build();
                        RpcController controller = new DefaultRpcController();
                        try {
                            GetUserFieldResponse response = userService.getUserField(controller, request);
                            if (response != null && response.getShownHistoryCount() > 0) {
                                return true;
                            } else {
                                return false;
                            }
                        } catch (Exception e) {
                            logger.error("get user {} from user server failed.", userId, e);
                            if (i == retry / 2) {
                                restartRpc();
                            }
                        }
                    }
                    throw new Exception("user:" + userId + " not found for " + retry + " times.");
                }
            });
            if (result != null && result) {
                hasShowHistory.incrementAndGet();
            }
            return result != null && result;
        } catch (ExecutionException e) {
            logger.error("error message: {}", e.getMessage());
        }
        return false;
    }

    private void metrics() {
        long milliseconds = stopWatch.getTime();
        if (milliseconds >= TimeUnit.SECONDS.toMillis(30)) {
            try {
                stopWatch.reset();
                long historyRequest = this.historyRequest.get();
                long historyNotHit = this.historyNotHit.get();
                long updateRequest = this.updateRequest.get();
                long hasShowHistory = this.hasShowHistory.get();
                double hitRate = 100.0 * (historyRequest - historyNotHit) / historyRequest;
                double historyQps = 1000.0 * historyRequest / milliseconds;
                double updateQps = 1000.0 * updateRequest / milliseconds;
                double feedRate = 100.0 * hasShowHistory / historyRequest;
                logger.info("******************************************************************************");
                if (historyRequest > 0) {
                    logger.info("##Thread:{}, iflow history cache hit rate:{}%, average qps:{}",
                            Thread.currentThread().getName(), hitRate, historyQps);
                    logger.info("##Thread:{}, iflow history request:{}, history hit:{}",
                            Thread.currentThread().getName(), historyRequest, (historyRequest - historyNotHit));
                }
                if (updateRequest > 0) {
                    logger.info("##Thread:{}, add yt_recent_click qps:{}",
                            Thread.currentThread().getName(), updateQps);
                    logger.info("##Thread:{}, add yt_recent_click:{}",
                            Thread.currentThread().getName(), updateRequest);
                }
                if (hasShowHistory > 0) {
                    logger.info("##Thread:{}, is feed user rate:{}",
                            Thread.currentThread().getName(), feedRate);
                    logger.info("##Thread:{}, is feed user num:{}",
                            Thread.currentThread().getName(), hasShowHistory);
                }
                logger.info("******************************************************************************");
            } catch (Exception e) {
                logger.error("calculate performance metrics error", e);
            } finally {
                this.historyRequest.set(0L);
                this.historyNotHit.set(0L);
                this.updateRequest.set(0L);
                this.hasShowHistory.set(0L);
                stopWatch.start();
            }
        }
    }
}
