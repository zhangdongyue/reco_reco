package com.tudou.recommend.up.storm.common;

import com.google.protobuf.ByteString;
import com.wolong.exception.WolongException;
import com.wolong.protorpc.client.pool.PooledRpcClient;
import com.wolong.protorpc.client.protobuf.DefaultBlockingRpcChannel;
import com.wolong.protorpc.model.DefaultRpcController;
import com.wolong.reco.proto.ProtoDictServer;
import org.apache.log4j.Logger;

public class DictServerClient {
    private static Logger logger = Logger.getLogger(DictServerClient.class);

    private PooledRpcClient rpcClient = null;
    private ProtoDictServer.DictService.BlockingInterface dictService = null;
    private String address;
    private int timeout = 500;
    private int maxRetry = 600;
    private float bootRatio = 0.8f;

    public DictServerClient(String address) throws Exception {
        this.address = address;
        init();
    }

    public void init() throws Exception {
        rpcClient = new PooledRpcClient(address, timeout, maxRetry, 2048, bootRatio);
        rpcClient.bootstrap();
        dictService = ProtoDictServer.DictService
                .newBlockingStub(new DefaultBlockingRpcChannel(rpcClient));
    }

    public void destroy() {
        if (rpcClient != null && !rpcClient.isStopped()) {
            try {
                rpcClient.stop();
            } catch (Exception e) {
                logger.error("DictService destroy() exception->", e);
            }
        }
    }

    public ProtoDictServer.GetDataResponse getData(ProtoDictServer.GetDataRequest request) {
        if (request == null) {
            logger.warn("request is null or empty.");
            return null;
        }

        DefaultRpcController controller = new DefaultRpcController();
        ProtoDictServer.GetDataResponse response = null;
        try {
            response = dictService.getData(controller, request);
        } catch (Exception ex) {
            logger.error("rpc call failed as " + ex.getMessage(), ex);
            throw WolongException.INTERNAL(ex, "rpc call failed");
        }

        return response;
    }

    public byte[] getData(String product, byte[] keyBytes, int version) {
        if (product == null || keyBytes == null) {
            return null;
        }
        ProtoDictServer.KeyElements.Builder keyBuilder = ProtoDictServer.KeyElements.newBuilder();
        keyBuilder.setKey(ByteString.copyFrom(keyBytes));
        keyBuilder.setProduct(ByteString.copyFrom(product.getBytes()));
        keyBuilder.setVersion(ByteString.copyFromUtf8(String.valueOf(version)));
        ProtoDictServer.GetDataRequest.Builder builder = ProtoDictServer.GetDataRequest.newBuilder();
        builder.setKeyElements(keyBuilder.build());
        ProtoDictServer.GetDataResponse response = getData(builder.build());
        if (response == null || !response.getSuccess()) {
            return null;
        } else {
            return response.getValue().toByteArray();
        }
    }

    public ProtoDictServer.SetDataResponse setData(ProtoDictServer.SetDataRequest request) {
        if (request == null) {
            logger.warn("request is null or empty.");
            return null;
        }

        DefaultRpcController controller = new DefaultRpcController();
        ProtoDictServer.SetDataResponse response = null;
        try {
            response = dictService.setData(controller, request);
        } catch (Exception ex) {
            logger.error("rpc call failed as " + ex.getMessage(), ex);
            throw WolongException.INTERNAL(ex, "rpc call failed");
        }
        return response;
    }

    public boolean setData(String product, byte[] keyBytes, byte[] valueBytes, int version) {
        ProtoDictServer.SetDataRequest.Builder builder = ProtoDictServer.SetDataRequest.newBuilder();
        builder.setValue(ByteString.copyFrom(valueBytes));
        ProtoDictServer.KeyElements.Builder keyBuilder = ProtoDictServer.KeyElements.newBuilder();
        keyBuilder.setKey(ByteString.copyFrom(keyBytes));
        keyBuilder.setProduct(ByteString.copyFrom(product.getBytes()));
        keyBuilder.setVersion(ByteString.copyFromUtf8(String.valueOf(version)));
        builder.setKeyElements(keyBuilder.build());

        ProtoDictServer.SetDataResponse response = setData(builder.build());
        if (response == null) {
            return false;
        } else {
            return response.getSuccess();
        }
    }

    public boolean setData(String product, byte[] keyBytes, byte[] valueBytes) {
        return setData(product, keyBytes, valueBytes, 0);
    }

    public ProtoDictServer.DelKeyResponse delKey(ProtoDictServer.DelKeyRequest request) {
        if (request == null) {
            logger.warn("request is null or empty.");
            return null;
        }

        DefaultRpcController controller = new DefaultRpcController();
        ProtoDictServer.DelKeyResponse response = null;
        try {
            response = dictService.delKey(controller, request);
        } catch (Exception ex) {
            logger.error("rpc call failed as " + ex.getMessage(), ex);
            throw WolongException.INTERNAL(ex, "rpc call failed");
        }
        return response;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public int getMaxRetry() {
        return maxRetry;
    }

    public void setMaxRetry(int maxRetry) {
        this.maxRetry = maxRetry;
    }

    public float getBootRatio() {
        return bootRatio;
    }

    public void setBootRatio(float bootRatio) {
        this.bootRatio = bootRatio;
    }

}
