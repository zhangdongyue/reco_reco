package com.tudou.recommend.up.storm.playlog;

import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import org.apache.storm.Config;
import org.apache.storm.StormSubmitter;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.BoltDeclarer;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.tuple.Fields;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * Main class that collect Youku and Newtd play log whose user id should have
 * iFlow show history.
 *
 * @author wangfei01
 * @date 20170802
 */
public class PLayLogMain {
    private static Logger logger = LoggerFactory.getLogger(PLayLogMain.class);

    public static void main(String[] args) {
        PlayLogArgument arguments = new PlayLogArgument();
        // parse args
        JCommander commander = new JCommander(arguments);
        commander.parse(args);

        // create the topology
        TopologyBuilder builder = new TopologyBuilder();
        int queueNum = arguments.getTtQueueNum();
        int spoutNum = arguments.getClickLogSpoutNum();
        // shuffle all queue to each spout
        Map<String, List<Integer>> map = new HashMap<>();
        for (int i = 0; i < queueNum; i++) {
            Integer mode = i % spoutNum;
            String key = String.format("yt_click_log_spout_%d", mode);
            List<Integer> list = map.get(key);
            if (list == null) {
                list = new ArrayList<>();
                map.put(key, list);
            }
            list.add(i);
        }

        // define the log filter bolt
        int filterBoltNum = arguments.getLogFilterBoltNum();
        BoltDeclarer filterBoltDeclarer = builder.setBolt("yt_play_log_filter_bolt", new PlayLogFilterBolt(), filterBoltNum)
                .setNumTasks(filterBoltNum);

        // create spout with predefined queues
        Set<Map.Entry<String, List<Integer>>> set = map.entrySet();
        for (Map.Entry<String, List<Integer>> entry : set) {
            String spoutName = entry.getKey();
            List<Integer> spoutQueues = entry.getValue();
            builder.setSpout(spoutName, new PlayLogParseSpout(spoutQueues), 1)
                    .setMaxTaskParallelism(1)
                    .setNumTasks(1);
            filterBoltDeclarer.fieldsGrouping(spoutName, new Fields("user_id"));
        }

        //create play log write bolt.
        int writerBoltNum = arguments.getLogWriterBoltNum();
        BoltDeclarer writerBoltDeclarer = builder.setBolt("yt_play_log_writer_bolt", new PlayLogWriterBolt(), writerBoltNum)
                .setNumTasks(writerBoltNum);
        writerBoltDeclarer.fieldsGrouping("yt_play_log_filter_bolt", new Fields("user_id"));

        //create the topology.
        StormTopology topology = builder.createTopology();

        Config conf = new Config();
        conf.setMaxSpoutPending(arguments.getSpoutMaxPending());
        conf.setNumWorkers(arguments.getWorkerNum());
        conf.put("tt.seconds.ahead", arguments.getTtSecondsAhead());
        conf.put("tt.topic", arguments.getTtTopic());
        conf.put("tt.subscribe.id", arguments.getTtSubscribeId());
        conf.put("tt.access.key", arguments.getTtAccessKey());
        conf.put("tt.queue.num", arguments.getTtQueueNum());
        conf.put("tt.buffer.size", arguments.getTtBufferSize());
        conf.put("user.server.addresses", arguments.getUserServerAddresses());
        conf.put("user.server.timeout", arguments.getUserServerTimeout());
        conf.put("user.server.retry", arguments.getUserServerRetry());
        conf.put("play.seconds.threshold", arguments.getPlaySecondsThreshold());
        if (arguments.getAllowedSites() != null) {
            conf.put("allow.sites", arguments.getAllowedSites());
        }
        conf.put("log.debug", arguments.getDebug());

        try {
            StormSubmitter.submitTopology(arguments.getJobName(), conf, topology);
        } catch (Exception e) {
            logger.error("submit topology failed.", e);
            System.exit(1);
        }
    }

    public static class PlayLogArgument {
        @Parameter(names = "--debug", description = "print the debug log")
        private String debug = "false";

        @Parameter(names = "--jobName", description = "storm job name")
        private String jobName;

        @Parameter(names = "--ttTopic", description = "Topic of the TT")
        private String ttTopic;

        @Parameter(names = "--ttAccessKey", description = "Access key of the TT")
        private String ttAccessKey;

        @Parameter(names = "--ttSubscribeId", description = "Subscribe ID of the TT")
        private String ttSubscribeId;

        @Parameter(names = "--ttSecondsAhead", description = "Receive log from seconds ahead.")
        private Long ttSecondsAhead;

        @Parameter(names = "--ttQueueNum", description = "TT queue number")
        private Integer ttQueueNum;

        @Parameter(names = "--ttBufferSize", description = "TT reader buffer size")
        private Integer ttBufferSize;

        @Parameter(names = "--clickLogSpoutNum", description = "Storm click log spout number")
        private Integer clickLogSpoutNum;

        @Parameter(names = "--logFilterBoltNum", description = "number of log filter bolt")
        private Integer logFilterBoltNum;

        @Parameter(names = "--logWriterBoltNum", description = "number of log write bolt")
        private Integer logWriterBoltNum;

        @Parameter(names = "--workerNum", description = "worker number")
        private Integer workerNum;

        @Parameter(names = "--userServerAddresses", description = "address of user server")
        private String userServerAddresses;

        @Parameter(names = "--userServerTimeout", description = "user server time out(milliseconds)")
        private Integer userServerTimeout = 200;

        @Parameter(names = "--userServerRetry", description = "user server retry times")
        private Integer userServerRetry = 3;

        @Parameter(names = "--spoutMaxPending", description = "spout max pending tuple")
        private Integer spoutMaxPending = 500;

        @Parameter(names = "--allowedSites", description = "site allow to save")
        private String allowedSites;

        @Parameter(names = "--playSecondsThreshold")
        private Integer playSecondsThreshold = 10;

        public Integer getPlaySecondsThreshold() {
            return playSecondsThreshold;
        }

        public void setPlaySecondsThreshold(Integer playSecondsThreshold) {
            this.playSecondsThreshold = playSecondsThreshold;
        }

        public String getAllowedSites() {
            return allowedSites;
        }

        public void setAllowedSites(String allowedSites) {
            this.allowedSites = allowedSites;
        }

        public Integer getUserServerTimeout() {
            return userServerTimeout;
        }

        public void setUserServerTimeout(Integer userServerTimeout) {
            this.userServerTimeout = userServerTimeout;
        }

        public Integer getUserServerRetry() {
            return userServerRetry;
        }

        public void setUserServerRetry(Integer userServerRetry) {
            this.userServerRetry = userServerRetry;
        }

        public String getDebug() {
            return debug;
        }

        public void setDebug(String debug) {
            this.debug = debug;
        }

        public String getJobName() {
            return jobName;
        }

        public void setJobName(String jobName) {
            this.jobName = jobName;
        }

        public String getTtTopic() {
            return ttTopic;
        }

        public void setTtTopic(String ttTopic) {
            this.ttTopic = ttTopic;
        }

        public String getTtAccessKey() {
            return ttAccessKey;
        }

        public void setTtAccessKey(String ttAccessKey) {
            this.ttAccessKey = ttAccessKey;
        }

        public String getTtSubscribeId() {
            return ttSubscribeId;
        }

        public void setTtSubscribeId(String ttSubscribeId) {
            this.ttSubscribeId = ttSubscribeId;
        }

        public Long getTtSecondsAhead() {
            return ttSecondsAhead;
        }

        public void setTtSecondsAhead(Long ttSecondsAhead) {
            this.ttSecondsAhead = ttSecondsAhead;
        }

        public Integer getTtQueueNum() {
            return ttQueueNum;
        }

        public void setTtQueueNum(Integer ttQueueNum) {
            this.ttQueueNum = ttQueueNum;
        }

        public Integer getTtBufferSize() {
            return ttBufferSize;
        }

        public void setTtBufferSize(Integer ttBufferSize) {
            this.ttBufferSize = ttBufferSize;
        }

        public Integer getClickLogSpoutNum() {
            return clickLogSpoutNum;
        }

        public void setClickLogSpoutNum(Integer clickLogSpoutNum) {
            this.clickLogSpoutNum = clickLogSpoutNum;
        }

        public Integer getLogFilterBoltNum() {
            return logFilterBoltNum;
        }

        public void setLogFilterBoltNum(Integer logFilterBoltNum) {
            this.logFilterBoltNum = logFilterBoltNum;
        }

        public Integer getLogWriterBoltNum() {
            return logWriterBoltNum;
        }

        public void setLogWriterBoltNum(Integer logWriterBoltNum) {
            this.logWriterBoltNum = logWriterBoltNum;
        }

        public Integer getWorkerNum() {
            return workerNum;
        }

        public void setWorkerNum(Integer workerNum) {
            this.workerNum = workerNum;
        }

        public String getUserServerAddresses() {
            return userServerAddresses;
        }

        public void setUserServerAddresses(String userServerAddresses) {
            this.userServerAddresses = userServerAddresses;
        }

        public Integer getSpoutMaxPending() {
            return spoutMaxPending;
        }

        public void setSpoutMaxPending(Integer spoutMaxPending) {
            this.spoutMaxPending = spoutMaxPending;
        }
    }
}


