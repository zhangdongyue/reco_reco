package com.tudou.recommend.up.storm.common;

import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.wolong.reco.proto.ProtoYoukuShowTrace.*;

/**
 * Show Tracker client that fetch data from dict server.
 * Created by Wangfei on 2017/6/12.
 */
public class ShowTrackClient {
    private static String PRODUCTION = "newtd-track";
    private static int VERSION = 1;

    public static void main(String[] args) throws Exception {
        ShowTrackArguments arguments = new ShowTrackArguments();
        JCommander commander = new JCommander(arguments);
        commander.parse(args);
        DictServerClient dictServerClient = new DictServerClient(arguments.getAddress());
        byte[] bytes = dictServerClient.getData(PRODUCTION,
                arguments.getUserId().getBytes("UTF-8"), VERSION);
        System.out.println(String.format("bytes array length is:%d", bytes.length));
        YoukuUserTracker userTracker = YoukuUserTracker.parseFrom(bytes);
        System.out.println(String.format("%s-->%s", arguments.getUserId(), userTracker.toString()));
    }

    public static class ShowTrackArguments {
        @Parameter(names = "--addresses", required = true, description = "dict server addresses.")
        private String address = "";

        @Parameter(names = "--userId", required = true, description = "User id should be UTDID.")
        private String userId;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }
    }
}
