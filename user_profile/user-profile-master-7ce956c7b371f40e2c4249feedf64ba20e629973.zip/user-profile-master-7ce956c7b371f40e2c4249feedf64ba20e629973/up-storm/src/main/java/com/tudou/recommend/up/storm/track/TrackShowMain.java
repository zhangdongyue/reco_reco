package com.tudou.recommend.up.storm.track;

import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import org.apache.storm.Config;
import org.apache.storm.StormSubmitter;
import org.apache.storm.generated.StormTopology;
import org.apache.storm.topology.BoltDeclarer;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.tuple.Fields;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URISyntaxException;
import java.util.*;

/**
 * Created by Wangfei on 2017/5/23.
 */
public class TrackShowMain {
    private static final Logger logger = LoggerFactory.getLogger(TrackShowMain.class);

    public static void main(String[] args) throws InterruptedException, URISyntaxException {
        TrackArgument arguments = new TrackArgument();
        // parse args
        JCommander commander = new JCommander(arguments);
        commander.parse(args);

        // create the topology
        TopologyBuilder builder = new TopologyBuilder();
        int queueNum = arguments.getQueueNum();
        int spoutNum = arguments.getClickLogSpoutNum();
        // shuffle all queue to each spout
        Map<String, List<Integer>> map = new HashMap<>();
        for (int i = 0; i < queueNum; i++) {
            Integer mode = i % spoutNum;
            String key = String.format("track_click_log_spout_%d", mode);
            List<Integer> list = map.get(key);
            if (list == null) {
                list = new ArrayList<>();
                map.put(key, list);
            }
            list.add(i);
        }

        // define the dict server write bolt
        int boltNum = arguments.getTrackShowBoltNum();
        BoltDeclarer boltDeclarer = builder.setBolt("track_dict_server", new TrackShowProtoBolt(), boltNum)
                .setNumTasks(boltNum);

        // create spout with predefined queues
        Set<Map.Entry<String, List<Integer>>> set = map.entrySet();
        for (Map.Entry<String, List<Integer>> entry : set) {
            String spoutName = entry.getKey();
            List<Integer> spoutQueues = entry.getValue();
            builder.setSpout(spoutName, new TrackClickLogProtoSpout(spoutQueues), 1)
                    .setMaxTaskParallelism(1)
                    .setNumTasks(1);
            boltDeclarer.fieldsGrouping(entry.getKey(), new Fields("user_id"));
        }
        StormTopology topology = builder.createTopology();

        Config conf = new Config();
        conf.setMaxSpoutPending(arguments.getSpoutMaxPending());
        conf.setNumWorkers(arguments.getWorkerNum());

        conf.put("tt.seconds.ahead", arguments.getSecondsAhead());
        conf.put("tt.topic", arguments.getTopic());
        conf.put("tt.subscribe.id", arguments.getSubscribeId());
        conf.put("tt.access.key", arguments.getAccessKey());
        conf.put("tt.queue.num", arguments.getQueueNum());
        conf.put("tt.buffer.size", arguments.getBufferSize());
        conf.put("dict.server.address", arguments.getDictServerAddress());
        conf.put("weight.alpha", arguments.getWeightAlpha());
        conf.put("weight.beta", arguments.getWeightBeta());
        conf.put("expire.days", arguments.getExpireDays());
        conf.put("log.debug", arguments.getDebug());
        conf.put("kafka.broker", arguments.getKafkaBroker());
        conf.put("kafka.topic", arguments.getKafkaTopic());
        conf.put("kafka.partition.begin", arguments.getKafkaPartitionBegin());
        conf.put("kafka.partition.end", arguments.getKafkaPartitionEnd());
        conf.put("batch.size", arguments.getBatchSize());

        try {
            StormSubmitter.submitTopology(arguments.getJobName(), conf, topology);
        } catch (Exception e) {
            logger.error("submit topology failed.", e);
            System.exit(1);
        }
    }


    public static class TrackArgument {
        @Parameter(names = "--debug", description = "print the debug log")
        private String debug = "false";

        @Parameter(names = "--jobName", description = "storm job name")
        private String jobName;

        @Parameter(names = "--ttTopic", description = "Topic of the TT")
        private String topic;

        @Parameter(names = "--ttAccessKey", description = "Access key of the TT")
        private String accessKey;

        @Parameter(names = "--ttSubscribeId", description = "Subscribe ID of the TT")
        private String subscribeId;

        @Parameter(names = "--secondsAhead", description = "Receive log from seconds ahead.")
        private Long secondsAhead;

        @Parameter(names = "--queueNum", description = "TT queue number")
        private Integer queueNum;

        @Parameter(names = "--bufferSize", description = "TT reader buffer size")
        private Integer bufferSize;

        @Parameter(names = "--clickLogSpoutNum", description = "Storm click log spout number")
        private Integer clickLogSpoutNum;

        @Parameter(names = "--trackShowBoltNum", description = "Storm dict server write bolt number")
        private Integer trackShowBoltNum;

        @Parameter(names = "--workerNum", description = "worker number")
        private Integer workerNum;

        @Parameter(names = "--dictServerAddress", description = "address of dict server")
        private String dictServerAddress;

        @Parameter(names = "--spoutMaxPending", description = "spout max pending tuples")
        private Integer spoutMaxPending = 50;

        @Parameter(names = "--weightAlpha", description = "tunning parameter for played times")
        private Double weightAlpha = 0.5;

        @Parameter(names = "--weightBeta", description = "tunning parameter for play rate")
        private Double weightBeta = 1.0;

        @Parameter(names = "--expireDays", description = "expire days of show track records")
        private Integer expireDays = 7;

        @Parameter(names = "--kafkaBroker")
        private String kafkaBroker;

        @Parameter(names = "--kafkaTopic")
        private String kafkaTopic;

        @Parameter(names = "--kafkaPartitionBegin")
        private Integer kafkaPartitionBegin=0;

        @Parameter(names = "--kafkaPartitionEnd")
        private Integer kafkaPartitionEnd;

        @Parameter(names = "--batchSize")
        private Integer batchSize;

        public String getKafkaBroker() {
            return kafkaBroker;
        }

        public void setKafkaBroker(String kafkaBroker) {
            this.kafkaBroker = kafkaBroker;
        }

        public String getKafkaTopic() {
            return kafkaTopic;
        }

        public void setKafkaTopic(String kafkaTopic) {
            this.kafkaTopic = kafkaTopic;
        }

        public Integer getKafkaPartitionBegin() {
            return kafkaPartitionBegin;
        }

        public void setKafkaPartitionBegin(Integer kafkaPartitionBegin) {
            this.kafkaPartitionBegin = kafkaPartitionBegin;
        }

        public Integer getKafkaPartitionEnd() {
            return kafkaPartitionEnd;
        }

        public void setKafkaPartitionEnd(Integer kafkaPartitionEnd) {
            this.kafkaPartitionEnd = kafkaPartitionEnd;
        }

        public Integer getBatchSize() {
            return batchSize;
        }

        public void setBatchSize(Integer batchSize) {
            this.batchSize = batchSize;
        }

        public String getDebug() {
            return debug;
        }

        public void setDebug(String debug) {
            this.debug = debug;
        }

        public Integer getExpireDays() {
            return expireDays;
        }

        public void setExpireDays(Integer expireDays) {
            this.expireDays = expireDays;
        }

        public Double getWeightAlpha() {
            return weightAlpha;
        }

        public void setWeightAlpha(Double weightAlpha) {
            this.weightAlpha = weightAlpha;
        }

        public Double getWeightBeta() {
            return weightBeta;
        }

        public void setWeightBeta(Double weightBeta) {
            this.weightBeta = weightBeta;
        }

        public Integer getSpoutMaxPending() {
            return spoutMaxPending;
        }

        public void setSpoutMaxPending(Integer spoutMaxPending) {
            this.spoutMaxPending = spoutMaxPending;
        }

        public String getDictServerAddress() {
            return dictServerAddress;
        }

        public void setDictServerAddress(String dictServerAddress) {
            this.dictServerAddress = dictServerAddress;
        }

        public String getTopic() {
            return topic;
        }

        public void setTopic(String topic) {
            this.topic = topic;
        }

        public String getAccessKey() {
            return accessKey;
        }

        public void setAccessKey(String accessKey) {
            this.accessKey = accessKey;
        }

        public String getSubscribeId() {
            return subscribeId;
        }

        public void setSubscribeId(String subscribeId) {
            this.subscribeId = subscribeId;
        }

        public Long getSecondsAhead() {
            return secondsAhead;
        }

        public void setSecondsAhead(Long secondsAhead) {
            this.secondsAhead = secondsAhead;
        }

        public Integer getQueueNum() {
            return queueNum;
        }

        public void setQueueNum(Integer queueNum) {
            this.queueNum = queueNum;
        }

        public Integer getBufferSize() {
            return bufferSize;
        }

        public void setBufferSize(Integer bufferSize) {
            this.bufferSize = bufferSize;
        }

        public Integer getClickLogSpoutNum() {
            return clickLogSpoutNum;
        }

        public void setClickLogSpoutNum(Integer clickLogSpoutNum) {
            this.clickLogSpoutNum = clickLogSpoutNum;
        }

        public Integer getTrackShowBoltNum() {
            return trackShowBoltNum;
        }

        public void setTrackShowBoltNum(Integer trackShowBoltNum) {
            this.trackShowBoltNum = trackShowBoltNum;
        }

        public Integer getWorkerNum() {
            return workerNum;
        }

        public void setWorkerNum(Integer workerNum) {
            this.workerNum = workerNum;
        }

        public String getJobName() {
            return jobName;
        }

        public void setJobName(String jobName) {
            this.jobName = jobName;
        }
    }
}

