package com.tudou.recommend.up.storm.common;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Wangfei on 2017/5/23.
 */
public class ClickLog implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(ClickLog.class);
    // 1	client_ip	客户端ip
    private String clientIp;
    // 2	protocol_version	sdk协议版本
    private String protocolVersion;
    // 3	imei	移动设备国际身份码的缩写
    private String imei;
    // 4	imsi	国际移动用户识别码是区别移动用户的标志，储存在SIM卡中
    private String imsi;
    // 5	brand	手机或终端的品牌
    private String brand;
    // 6	cpu	终端cpu
    private String cpu;
    // 7	device_id	device_id
    private String deviceId;
    // 8	device_model	手机或终端的机型
    private String deviceModel;
    // 9	resolution	手机或终端的屏幕分辨率
    private String resolution;
    // 10	carrier	移动运营商，如：中国移动、中国联通、中国电信
    private String carrier;
    // 11	access	连接的网络，如：2G、3G、Wi-Fi
    private String access;
    // 12	access_subtype	网络类型，如：HSPA、EVDO、EDGE、GPRS等
    private String accessSubtype;
    // 13	channel	app对应的渠道号，映射表为wireless_wdm.wdm_dim_channel
    private String channel;
    // 14	app_key	app_key
    private String appKey;
    // 15	app_version	app版本
    private String appVersion;
    // 16	long_login_nick	长登录nick
    private String longLoginNick;
    // 17	user_nick	短登陆nick
    private String userNick;
    // 18	phone_number	手机号码
    private String phoneNumber;
    // 19	country	国家
    private String country;
    // 20	language	语言
    private String language;
    // 21	os	操作系统
    private String os;
    // 22	os_version	操作系统版本
    private String osVersion;
    // 23	sdk_type	sdk类型
    private String sdkType;
    // 24	sdk_version	sdk版本
    private String sdkVersion;
    // 25	session_id	session_id
    private String sessionId;
    // 26	utdid	utdid
    private String utdid;
    // 27	reserve3	预留字段
    private String reserve3;
    // 28	reserve4	预留字段
    private String reserve4;
    // 29	reserve5	预留字段
    private String reserve5;
    // 30	reserves	预留字段
    private String reserves;
    // 31	local_time	APP终端时间(格式为yyyy-MM-dd HHss)
    private String localTime;
    // 32	server_time	APP终端时间(时间戳,精确到毫秒)
    private String serverTime;
    // 33	page	页面
    private String page;
    // 34	event_id	埋点的事件ID
    private String eventId;
    // 35	arg1	事件参数
    private String arg1;
    // 36	arg2	事件参数 播放器生命周期内唯一标示（playsid）
    private String arg2;
    // 37	arg3	事件参数
    private String arg3;
    // 38	args	事件参数
    private String args;
    // 39	day
    private String day;
    // 40	hour_id
    private String hourId;
    // 41	server_timestamp	日志到达服务器时间，时间戳格式，精确到秒
    private String serverTimestamp;
    // 42	seq	不用
    private String seq;
    // 43	app_bu app_id关联该表wireless_dw.appid_config得到
    private String appBu;
    // 44	mbr_id	归一化的用户id
    private String mbrId;
    // 45	mbr_name	昵称
    private String mbrName;
    // 46	is_vip	是否VIP会员：Y：是 N:否
    private String isVip;
    // 47	vip_level	会员级别：黄金、白银、其他
    private String vipLevel;
    // 48	vdo_id	视频id
    private String vdoId;
    // 49	ts	播放时长 单位秒
    private String ts;
    // 50	vdo_title	视频标题
    private String vdoTitle;
    // 51	vdo_len	视频长度
    private String vdoLen;
    // 52	vdo_type	视频类型：花絮、资讯、MV、预告片、首映式、正片
    private String vdoType;
    // 53	show_id	节目id
    private String showId;
    // 54	show_name	节目名称
    private String showName;
    // 55	ouid	ouid
    private String ouid;
    // 56	guid	guid
    private String guid;
    // 57	spm_url	来源页面的spm信息（站点.页面.区块.位置）
    private String spmUrl;
    // 58	site	youku, newtd , laifeng , other
    private String site;

    public static List<ClickLog> fromBytes(byte[] bytes) throws UnsupportedEncodingException {
        List<ClickLog> clickLogs = new ArrayList<>();
        if (bytes == null || bytes.length == 0) {
            return clickLogs;
        }
        String batch = new String(bytes, "UTF-8");
        String[] logs = batch.split("\u0001\n");
        for (String stream : logs) {
            try {
                ClickLog log = new ClickLog();
                String[] tokens = stream.split("\u0001");
                // 1	client_ip	客户端ip
                log.clientIp = tokens[0];
                // 2	protocol_version	sdk协议版本
                log.protocolVersion = tokens[1];
                // 3	imei	移动设备国际身份码的缩写
                log.imei = tokens[2];
                // 4	imsi	国际移动用户识别码是区别移动用户的标志，储存在SIM卡中
                log.imsi = tokens[3];
                // 5	brand	手机或终端的品牌
                log.brand = tokens[4];
                // 6	cpu	终端cpu
                log.cpu = tokens[5];
                // 7	device_id	device_id
                log.deviceId = tokens[6];
                // 8	device_model	手机或终端的机型
                log.deviceModel = tokens[7];
                // 9	resolution	手机或终端的屏幕分辨率
                log.resolution = tokens[8];
                // 10	carrier	移动运营商，如：中国移动、中国联通、中国电信
                log.carrier = tokens[9];
                // 11	access	连接的网络，如：2G、3G、Wi-Fi
                log.access = tokens[10];
                // 12	access_subtype	网络类型，如：HSPA、EVDO、EDGE、GPRS等
                log.accessSubtype = tokens[11];
                // 13	channel	app对应的渠道号，映射表为wireless_wdm.wdm_dim_channel
                log.channel = tokens[12];
                // 14	app_key	app_key
                log.appKey = tokens[13];
                // 15	app_version	app版本
                log.appVersion = tokens[14];
                // 16	long_login_nick	长登录nick
                log.longLoginNick = tokens[15];
                // 17	user_nick	短登陆nick
                log.userNick = tokens[16];
                // 18	phone_number	手机号码
                log.phoneNumber = tokens[17];
                // 19	country	国家
                log.country = tokens[18];
                // 20	language	语言
                log.language = tokens[19];
                // 21	os	操作系统
                log.os = tokens[20];
                // 22	os_version	操作系统版本
                log.osVersion = tokens[21];
                // 23	sdk_type	sdk类型
                log.sdkType = tokens[22];
                // 24	sdk_version	sdk版本
                log.sdkVersion = tokens[23];
                // 25	session_id	session_id
                log.sessionId = tokens[24];
                // 26	utdid	utdid
                log.utdid = tokens[25];
                // 27	reserve3	预留字段
                log.reserve3 = tokens[26];
                // 28	reserve4	预留字段
                log.reserve4 = tokens[27];
                // 29	reserve5	预留字段
                log.reserve5 = tokens[28];
                // 30	reserves	预留字段
                log.reserves = tokens[29];
                // 31	local_time	APP终端时间(格式为yyyy-MM-dd HHss)
                log.localTime = tokens[30];
                // 32	server_time	APP终端时间(时间戳,精确到毫秒)
                log.serverTime = tokens[31];
                // 33	page	页面
                log.page = tokens[32];
                // 34	event_id	埋点的事件ID
                log.eventId = tokens[33];
                // 35	arg1	事件参数
                log.arg1 = tokens[34];
                // 36	arg2	事件参数 播放器生命周期内唯一标示（playsid）
                log.arg2 = tokens[35];
                // 37	arg3	事件参数
                log.arg3 = tokens[36];
                // 38	args	事件参数
                log.args = tokens[37];
                // 39	day
                log.day = tokens[38];
                // 40	hour_id
                log.hourId = tokens[39];
                // 41	server_timestamp	日志到达服务器时间，时间戳格式，精确到秒
                log.serverTimestamp = tokens[40];
                // 42	seq	不用
                log.seq = tokens[41];
                // 43	app_bu app_id关联该表wireless_dw.appid_config得到
                log.appBu = tokens[42];
                // 44	mbr_id	归一化的用户id
                log.mbrId = tokens[43];
                // 45	mbr_name	昵称
                log.mbrName = tokens[44];
                // 46	is_vip	是否VIP会员：Y：是 N:否
                log.isVip = tokens[45];
                // 47	vip_level	会员级别：黄金、白银、其他
                log.vipLevel = tokens[46];
                // 48	vdo_id	视频id
                log.vdoId = tokens[47];
                // 49	ts	播放时长 单位秒
                log.ts = tokens[48];
                // 50	vdo_title	视频标题
                log.vdoTitle = tokens[49];
                // 51	vdo_len	视频长度
                log.vdoLen = tokens[50];
                // 52	vdo_type	视频类型：花絮、资讯、MV、预告片、首映式、正片
                log.vdoType = tokens[51];
                // 53	show_id	节目id
                log.showId = tokens[52];
                // 54	show_name	节目名称
                log.showName = tokens[53];
                // 55	ouid	ouid
                log.ouid = tokens[54];
                // 56	guid	guid
                if (StringUtils.isNotEmpty(tokens[55])) {
                    String[] guidArray = tokens[55].split("&");
                    log.guid = guidArray[0];
                }
                // 57	spm_url	来源页面的spm信息（站点.页面.区块.位置）
                log.spmUrl = tokens[56];
                // 58	site	youku, newtd , laifeng , other
                log.site = tokens[57];
                clickLogs.add(log);
            } catch (Exception e) {
                logger.error("parse log error: {}.", stream);
            }
        }
        return clickLogs;
    }

    public String getClientIp() {
        return clientIp;
    }

    public void setClientIp(String clientIp) {
        this.clientIp = clientIp;
    }

    public String getProtocolVersion() {
        return protocolVersion;
    }

    public void setProtocolVersion(String protocolVersion) {
        this.protocolVersion = protocolVersion;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getAccess() {
        return access;
    }

    public void setAccess(String access) {
        this.access = access;
    }

    public String getAccessSubtype() {
        return accessSubtype;
    }

    public void setAccessSubtype(String accessSubtype) {
        this.accessSubtype = accessSubtype;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getLongLoginNick() {
        return longLoginNick;
    }

    public void setLongLoginNick(String longLoginNick) {
        this.longLoginNick = longLoginNick;
    }

    public String getUserNick() {
        return userNick;
    }

    public void setUserNick(String userNick) {
        this.userNick = userNick;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public String getSdkType() {
        return sdkType;
    }

    public void setSdkType(String sdkType) {
        this.sdkType = sdkType;
    }

    public String getSdkVersion() {
        return sdkVersion;
    }

    public void setSdkVersion(String sdkVersion) {
        this.sdkVersion = sdkVersion;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getUtdid() {
        return utdid;
    }

    public void setUtdid(String utdid) {
        this.utdid = utdid;
    }

    public String getReserve3() {
        return reserve3;
    }

    public void setReserve3(String reserve3) {
        this.reserve3 = reserve3;
    }

    public String getReserve4() {
        return reserve4;
    }

    public void setReserve4(String reserve4) {
        this.reserve4 = reserve4;
    }

    public String getReserve5() {
        return reserve5;
    }

    public void setReserve5(String reserve5) {
        this.reserve5 = reserve5;
    }

    public String getReserves() {
        return reserves;
    }

    public void setReserves(String reserves) {
        this.reserves = reserves;
    }

    public String getLocalTime() {
        return localTime;
    }

    public void setLocalTime(String localTime) {
        this.localTime = localTime;
    }

    public String getServerTime() {
        return serverTime;
    }

    public void setServerTime(String serverTime) {
        this.serverTime = serverTime;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getArg1() {
        return arg1;
    }

    public void setArg1(String arg1) {
        this.arg1 = arg1;
    }

    public String getArg2() {
        return arg2;
    }

    public void setArg2(String arg2) {
        this.arg2 = arg2;
    }

    public String getArg3() {
        return arg3;
    }

    public void setArg3(String arg3) {
        this.arg3 = arg3;
    }

    public String getArgs() {
        return args;
    }

    public void setArgs(String args) {
        this.args = args;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getHourId() {
        return hourId;
    }

    public void setHourId(String hourId) {
        this.hourId = hourId;
    }

    public String getServerTimestamp() {
        return serverTimestamp;
    }

    public void setServerTimestamp(String serverTimestamp) {
        this.serverTimestamp = serverTimestamp;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public String getAppBu() {
        return appBu;
    }

    public void setAppBu(String appBu) {
        this.appBu = appBu;
    }

    public String getMbrId() {
        return mbrId;
    }

    public void setMbrId(String mbrId) {
        this.mbrId = mbrId;
    }

    public String getMbrName() {
        return mbrName;
    }

    public void setMbrName(String mbrName) {
        this.mbrName = mbrName;
    }

    public String getIsVip() {
        return isVip;
    }

    public void setIsVip(String isVip) {
        this.isVip = isVip;
    }

    public String getVipLevel() {
        return vipLevel;
    }

    public void setVipLevel(String vipLevel) {
        this.vipLevel = vipLevel;
    }

    public String getVdoId() {
        return vdoId;
    }

    public void setVdoId(String vdoId) {
        this.vdoId = vdoId;
    }

    public String getTs() {
        return ts;
    }

    public void setTs(String ts) {
        this.ts = ts;
    }

    public String getVdoTitle() {
        return vdoTitle;
    }

    public void setVdoTitle(String vdoTitle) {
        this.vdoTitle = vdoTitle;
    }

    public String getVdoLen() {
        return vdoLen;
    }

    public void setVdoLen(String vdoLen) {
        this.vdoLen = vdoLen;
    }

    public String getVdoType() {
        return vdoType;
    }

    public void setVdoType(String vdoType) {
        this.vdoType = vdoType;
    }

    public String getShowId() {
        return showId;
    }

    public void setShowId(String showId) {
        this.showId = showId;
    }

    public String getShowName() {
        return showName;
    }

    public void setShowName(String showName) {
        this.showName = showName;
    }

    public String getOuid() {
        return ouid;
    }

    public void setOuid(String ouid) {
        this.ouid = ouid;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getSpmUrl() {
        return spmUrl;
    }

    public void setSpmUrl(String spmUrl) {
        this.spmUrl = spmUrl;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    @Override
    public int hashCode() {
        return utdid.hashCode();
    }
}
