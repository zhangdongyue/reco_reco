package com.tudou.recommend.up.storm.util;

import org.apache.commons.lang3.math.NumberUtils;

/**
 * Log utils that help to parse log columns.
 * Created by Wangfei01 on 2017/6/23.
 */
public class LogUtils {

    /**
     * Parse arg parameters with specific key.
     *
     * @param args log args column.
     * @param key  passed in key.
     * @return
     */
    public static String parseArgs(String args, String key) {
        String[] argTokens = args.split(",");
        if (argTokens == null || argTokens.length == 0 || key == null) {
            return null;
        }
        for (String arg : argTokens) {
            String[] keyValue = arg.trim().split("=");
            if (keyValue.length == 2) {
                if (key.equals(keyValue[0])) {
                    return keyValue[1];
                }
            }
        }
        return null;
    }


    /**
     * Parse args parameter with double type.
     *
     * @param args
     * @param key
     * @return
     */
    public static double argsDouble(String args, String key) {
        String value = parseArgs(args, key);
        if (value == null) {
            return 0.0;
        }
        return Double.parseDouble(value);
    }

    /**
     * Parse args parameter with int type.
     *
     * @param args
     * @param key
     * @return
     */
    public static int argsInt(String args, String key) {
        String value = parseArgs(args, key);
        if (value == null || !NumberUtils.isParsable(value)) {
            return 0;
        }
        return Integer.parseInt(value);
    }
}
