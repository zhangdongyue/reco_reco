package com.tudou.recommend.up.storm.playlog;

import org.junit.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.*;

/**
 * @author wangfei01
 * @date 2017/9/5
 */
public class PlayLogParseSpoutTest {
    private PlayLogParseSpout spout = new PlayLogParseSpout(new ArrayList<Integer>());

    @Test
    public void versionCompare() throws Exception {
        int result = spout.versionCompare("6.2.1", "6.1.1");
        assertThat(result).isGreaterThan(0);
        result = spout.versionCompare("6.10.1", "6.2.1");
        assertThat(result).isGreaterThan(0);
        result = spout.versionCompare("6.0.1", "6.0.1");
        assertThat(result).isEqualTo(0);
    }

}