package com.tudou.recommend.up.storm.util;

import org.junit.Test;

import static org.assertj.core.api.Assertions.*;

/**
 * Created by Wangfei on 2017/6/23.
 */
public class LogUtilsTest {
    @Test
    public void parseArgs() throws Exception {
        String args = "netSpeedMax=38630,netSpeedMin=28771,startplaytime=22384,video_coding_format=H264,package=com.tudou.android,type=end,playerCore=0,domainName_ip=ntd.cp31.ott.cibntv.net,27.221.84.218,isAuto=0,netSpeedAvg=35842,replay=false,video_format_suggest=高清,video_format=高清,video_time=1389621.00,spm_url=,ytid=,end_play_time=22384,full=1,complete=0,play_types=net,sid=3cf707a75089ae970482d1110915d270,play_codes=200,dns=202.102.128.68|202.102.134.68,pid=72dbe84e6eec9a3d,play_decoding=1,guid=5bb63cbf6dcaaea5089a0035071edaed,login_status=0,autoPlay=0,channel=10014151";
        String playTime = LogUtils.parseArgs(args, "startplaytime");
        assertThat(playTime).isEqualTo("22384");
    }

}