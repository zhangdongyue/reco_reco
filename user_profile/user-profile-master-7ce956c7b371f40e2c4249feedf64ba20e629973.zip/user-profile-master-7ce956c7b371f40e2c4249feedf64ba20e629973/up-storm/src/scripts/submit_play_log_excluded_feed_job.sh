#!/usr/bin/env bash
# This script try to submit storm job of digest play log from tt log.
# The play log will be reserved in user server for online calling.
JAR_PATH=`pwd`/../lib/up-storm.jar
USER_SERVER_HOSTS='11.138.250.204:20002,11.138.252.102:20002,11.138.252.213:20002,11.138.253.18:20002,11.142.9.48:20002,11.142.9.90:20002,11.142.9.92:20002,11.142.9.93:20002'
JOB_NAME='yt_play_log_excluded_feed_topology'
ALLOW_SITES='youku,newtd'
TT_TOPIC='dwd_yt_log_app_ts_ri'
TT_ACCESS_KEY='b35b8238-f844-4f44-b157-3378bb00feb1'
TT_SUBSCRIBE_ID='0803114645GXJW3SWD'
# Kill pre-existed job.
storm kill ${JOB_NAME}
# Sleep 30s to ensure the job is terminated.
sleep 30s
# Submit a new job.
storm jar ${JAR_PATH} com.tudou.recommend.up.storm.playlog.PLayLogMain \
--jobName ${JOB_NAME} \
--ttTopic ${TT_TOPIC} \
--ttAccessKey  ${TT_ACCESS_KEY} \
--ttSubscribeId  ${TT_SUBSCRIBE_ID} \
--ttSecondsAhead 0 \
--ttQueueNum 32 \
--ttBufferSize 1000 \
--workerNum 8 \
--clickLogSpoutNum 64 \
--logFilterBoltNum 64 \
--logWriterBoltNum 64 \
--userServerAddresses ${USER_SERVER_HOSTS} \
--userServerTimeout 500 \
--userServerRetry 3 \
--spoutMaxPending 500 \
--allowedSites ${ALLOW_SITES} \
--playSecondsThreshold 20 \
--debug true
