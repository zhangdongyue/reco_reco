#!/bin/bash
# Submit the show track storm job which fetches online click log and persisted in Dict Server.
# Author: Wangfei01
DICT_SERVER_NA61='11.138.250.206:20006,11.138.251.242:20006,11.138.252.144:20006,11.138.252.204:20006,11.142.9.77:20006,11.142.9.83:20006,11.142.9.86:20006,11.180.120.87:20006,11.142.11.219:20006,11.142.11.221:20006,11.142.11.236:20006,11.142.44.34:20006,11.173.144.75:20006,11.173.197.147:20006,11.173.197.162:20006,11.173.197.180:20006'

if [ $1 = 'na61' ]
then
    DICT_SERVER=${DICT_SERVER_NA61}
    TT_TOPIC='dwd_yt_log_app_ts_ri'
    SUBSCRIBE_ID='0523165915TNXQ5ZWR'
    ACCESS_KEY='ab3d9508-6e87-4a01-a99f-9cdecf475c15'
elif [ $1 = 'na62' ]
then
    DICT_SERVER=${DICT_SERVER_NA62}
    TT_TOPIC='dwd_yt_log_app_ts_ri'
    SUBSCRIBE_ID='08081815156ZG50GWT'
    ACCESS_KEY='b92bf98c-c7d5-4694-a9fd-76c541b0f0b1'
fi

JOB_NAME="user_show_track_topology_$1"
KAFKA_BROKER="11.251.176.1:9092,11.251.176.2:9092,11.251.176.21:9092,11.251.176.3:9092,11.251.176.49:9092,11.251.176.5:9092,11.251.176.51:9092,11.251.176.54:9092,11.251.176.8:9092,11.251.176.9:9092"
KAFKA_TOPIC="dict_server_local_na61"

storm kill ${JOB_NAME}
sleep 30s
JAR=`pwd`/../lib/up-storm.jar
storm jar ${JAR} com.tudou.recommend.up.storm.track.TrackShowMain \
--jobName ${JOB_NAME} \
--ttTopic ${TT_TOPIC} \
--ttSubscribeId ${SUBSCRIBE_ID} \
--ttAccessKey ${ACCESS_KEY} \
--queueNum 32 \
--debug true \
--secondsAhead 0 \
--bufferSize 100 \
--clickLogSpoutNum 8 \
--workerNum 8 \
--trackShowBoltNum 8 \
--weightAlpha 0.5 \
--weightBeta 1.0 \
--expireDays 7 \
--dictServerAddress ${DICT_SERVER} \
--kafkaBroker ${KAFKA_BROKER} \
--kafkaTopic ${KAFKA_TOPIC} \
--kafkaPartitionBegin 0 \
--kafkaPartitionEnd 60 \
--batchSize 10
