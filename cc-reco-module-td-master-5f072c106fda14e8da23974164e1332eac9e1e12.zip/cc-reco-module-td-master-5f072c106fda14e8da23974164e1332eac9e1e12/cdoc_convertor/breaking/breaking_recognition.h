#pragma once
#include <unordered_set>
#include <unordered_map>
#include <string>

#include "base/time/time.h"
#include "reco/bizc/proto/item.pb.h"
#include "base/strings/string_split.h"
#include "base/hash_function/term.h"

namespace reco {
namespace common {

struct BreakingReqItem {
  uint64 item_id;
  reco::ItemType item_type;
  std::string  publish_time;
  std::string category;
  std::string snd_category;
  std::string source;
  std::string producer;
  std::string title;
  std::string content;
  std::string region;
  std::vector<std::string> title_unigrams;
  //const std::set<uint64>* item_sim_vec;
  void reset() {
    title_unigrams.clear();
  }
};

// 突发事件类型
enum BreakingType {
  WEATHER,  // 天气
  TRAFFIC,  // 交通
  DISASTER, // 灾害
  UNKNOWN
};

enum BreakingReliability {
  HIGH_CREDIBLE,
  MIDDLE_CREDIBLE,
  LOW_CREDIBLE,
  NOT_CREDIBLE
};

// item的事件属性
struct BreakingProperty {
  // 事件id，唯一标识，规则：日期#城市code#事件类型
  uint64 event_id;
  // 事件名称字面
  std::string event_literal;
  // 事件可信度，一般是基于item的源判断
  BreakingReliability reliability;
  // 事件开始时间，item的创建时间
  std::string start_time;
  // 事件停止下发时间，=开始时间+可持续时间
  std::string stop_time;
  // 事件类型
  int32 event_type;
  // 事件所属地域
  std::string region;

  BreakingProperty() {
    event_id = 0;
    event_literal = "";
    reliability = BreakingReliability::NOT_CREDIBLE;
  }
};

// 事件类
struct BreakingEvent {
  uint64 event_id;
  int32 event_type;
  std::string event_literal;
  std::string event_start_time;
  std::string event_expire_time;
  std::vector<uint64> items;
  // item_id: Properties
  std::unordered_map<uint64, reco::LocalBreaking> item_properties;
};

class BreakingRecognition {
 public:
  explicit BreakingRecognition(const std::string& reco_breaking_data_dir);
  ~BreakingRecognition();

  bool ExtractBreakingProperty(const RecoItem& req_item, std::vector<BreakingProperty>* properties);
  bool ExtractBreakingProperty(const RecoItem& req_item, reco::LocalBreaking* local_breaking);

  // 将突发属性转换为protocolbuf格式
  static bool ConvertProperty(const std::vector<BreakingProperty>& properties, reco::LocalBreaking* local_breaking);

 private:
  bool ExtractWeather(const std::string& title);
  bool ExtractTraffic(const std::string& title);
  bool ExtractDisaster(const std::string& title);

  static const std::unordered_set<int32> white_itemtypes;
};
}
} //namespace reco
