#include "reco/module/cdoc_convertor/breaking/breaking_recognition.h"

namespace reco {
namespace common {

const std::unordered_set<int32> BreakingRecognition::white_itemtypes = {0, 1, 2, 4};

BreakingRecognition::BreakingRecognition(const std::string& reco_breaking_data_dir) {
}

BreakingRecognition::~BreakingRecognition() {
}

bool BreakingRecognition::ExtractWeather(const std::string& title) {
  std::unordered_set<std::string> weather_unigram = {"蓝色预警", "橙色预警",
    "红色预警", "黄色预警", "白色预警", "雷雨大风", "冰雹", "雾霾", "沙尘暴"};
  std::vector<std::pair<std::string, std::string> > weather_bigram = {
    std::make_pair("暴雨", "预警"),
    std::make_pair("高温", "预警"),
    std::make_pair("雷电", "预警"),
    std::make_pair("寒潮", "预警"),
  };

  bool hit = false;

  for (auto iter = weather_unigram.begin(); iter != weather_unigram.end(); ++iter) {
    if (title.find(*iter) != std::string::npos) {
      hit = true;
      break;
    }
  }
  if (!hit) {
    for (auto iter = weather_bigram.begin(); iter != weather_bigram.end(); ++iter) {
      if (title.find(iter->first) != std::string::npos && title.find(iter->second) != std::string::npos) {
        hit = true;
        break;
      }
    }
  }
  return hit;
}

bool BreakingRecognition::ExtractTraffic(const std::string& title) {
  std::unordered_set<std::string> unigram = {"信号故障", "限速运行"};//, "发生滑坡", "发生泥石流", "山洪爆发", "引发泥石流"};
  std::vector<std::pair<std::string, std::string> > bigram = {
    std::make_pair("地铁", "故障"),
  };

  bool hit = false;

  for (auto iter = unigram.begin(); iter != unigram.end(); ++iter) {
    if (title.find(*iter) != std::string::npos) {
      hit = true;
      break;
    }
  }
  if (!hit) {
    for (auto iter = bigram.begin(); iter != bigram.end(); ++iter) {
      if (title.find(iter->first) != std::string::npos && title.find(iter->second) != std::string::npos) {
        hit = true;
        break;
      }
    }
  }
  return hit;
}

bool BreakingRecognition::ExtractDisaster(const std::string& title) {
  std::unordered_set<std::string> unigram = {"震感", "山体滑坡", "发生滑坡", "发生泥石流", "山洪爆发", "引发泥石流"};
  std::vector<std::pair<std::string, std::string> > bigram = {
    std::make_pair("发生", "地震"),
  };

  bool hit = false;

  for (auto iter = unigram.begin(); iter != unigram.end(); ++iter) {
    if (title.find(*iter) != std::string::npos) {
      hit = true;
      break;
    }
  }
  if (!hit) {
    for (auto iter = bigram.begin(); iter != bigram.end(); ++iter) {
      if (title.find(iter->first) != std::string::npos && title.find(iter->second) != std::string::npos) {
        hit = true;
        break;
      }
    }
  }
  return hit;
}

bool BreakingRecognition::ExtractBreakingProperty(const RecoItem& req_item, std::vector<BreakingProperty>* properties) {
  CHECK(properties);
  properties->clear();

  if (req_item.region().empty()) {
    return false;
  }

  if (white_itemtypes.find(req_item.identity().type()) == white_itemtypes.end()) {
    return false;
  }

  if (req_item.source().find("cp_wemedia_uc_") != std::string::npos) {
    return false;
  }

  if (req_item.publish_time().size() == 19 && req_item.publish_time().substr(11, 8) == "00:00:00") {
    return false;
  }

  std::unordered_set<std::string> white_categories = {"社会", "国内", "生活服务"};
  if (req_item.category_size() <= 0 ||
      white_categories.find(req_item.category(0)) == white_categories.end()) {
    return false;
  }

  bool hit_weather = false, hit_traffic = false, hit_disaster = false;
  hit_weather = ExtractWeather(req_item.title());
  hit_traffic = ExtractTraffic(req_item.title());
  hit_disaster = ExtractDisaster(req_item.title());

  if (!hit_weather && !hit_traffic && !hit_disaster)
    return false;

  int last_hour = 3;

  std::string event_type = "unknown";
  int event_type_int = BreakingType::UNKNOWN;
  if (hit_weather) {
    event_type = "天气";
    event_type_int = BreakingType::WEATHER;
    last_hour = 4;
  } else if (hit_traffic) {
    event_type = "交通";
    event_type_int = BreakingType::TRAFFIC;
    last_hour = 3;
  } else if (hit_disaster) {
    event_type = "重大灾害";
    event_type_int = BreakingType::DISASTER;
    last_hour = 8;
  }

  std::vector<std::string> date_buf;
  base::SplitString(req_item.publish_time(), " ", &date_buf);

  std::vector<std::string> region_buf;
  base::SplitString(req_item.region(), ";", &region_buf);

  BreakingReliability rel = BreakingReliability::NOT_CREDIBLE;
  if (hit_weather) {
    if (req_item.source() == "中国天气网" || req_item.orig_source() == "中国天气网" ||
        req_item.source_media() == "中国天气网" || req_item.orig_source_media() == "中国天气网") {
      rel = BreakingReliability::HIGH_CREDIBLE;
    }
  } else if (hit_disaster) {
    if (req_item.source() == "中国地震台网" || req_item.orig_source() == "中国地震台网" ||
        req_item.source_media() == "中国地震台网" || req_item.orig_source_media() == "中国地震台网") {
      rel = BreakingReliability::HIGH_CREDIBLE;
    }
  } else if (hit_traffic) {
    if (req_item.orig_source() == "人民网" || req_item.source_media() == "人民网" ||
        req_item.source_media() == "新浪网") {
      rel = BreakingReliability::HIGH_CREDIBLE;
    }
  }

  base::Time pub_time, end_time;
  std::string end_time_str;
  if (base::Time::FromStringInFormat(req_item.publish_time().c_str(), "%Y-%m-%d %H:%M:%S", &pub_time)) {
    double end_t = pub_time.ToDoubleT() + 3600 * last_hour;
    end_time = base::Time::FromDoubleT(end_t);
    if (!end_time.ToStringInFormat("%Y-%m-%d %H:%M:%S", &end_time_str)) {
      end_time_str = "";
    }
  }

  std::vector<std::string> buf;
  for (size_t i = 0; i < region_buf.size(); ++i) {
    buf.clear();
    buf.push_back(date_buf[0]);
    buf.push_back(region_buf[i]);
    buf.push_back(event_type);

    BreakingProperty property;
    property.event_literal = base::JoinStrings(buf, "#");
    property.event_id = base::CalcTermSign(property.event_literal.c_str(), property.event_literal.size());
    property.start_time = req_item.publish_time();
    property.stop_time = end_time_str;
    property.reliability = rel;
    property.event_type = event_type_int;
    property.region = region_buf[i];

    properties->push_back(property);
  }
  return properties->size() > 0;
}

bool BreakingRecognition::ConvertProperty(const std::vector<BreakingProperty>& properties, reco::LocalBreaking* local_breaking) {
  CHECK(local_breaking);
  reco::LocalBreakingInfo breaking_info;
  for (size_t i = 0; i < properties.size(); ++i) {
    const BreakingProperty& prop = properties[i];

    breaking_info.set_event_id(prop.event_id);
    breaking_info.set_event_literal(prop.event_literal);
    breaking_info.set_reliability(prop.reliability);
    breaking_info.set_start_time(prop.start_time);
    breaking_info.set_stop_time(prop.stop_time);
    breaking_info.set_event_type(prop.event_type);
    breaking_info.set_region(prop.region);

    local_breaking->add_breaking_infos()->CopyFrom(breaking_info);
  }
  return properties.size() > 0;
}

bool BreakingRecognition::ExtractBreakingProperty(const RecoItem& req_item, reco::LocalBreaking* local_breaking) {
  CHECK(local_breaking);

  std::vector<BreakingProperty> properties;
  if (!ExtractBreakingProperty(req_item, &properties)) {
    return false;
  }

  return ConvertProperty(properties, local_breaking);
}

} //namespace common
} //namespace reco
