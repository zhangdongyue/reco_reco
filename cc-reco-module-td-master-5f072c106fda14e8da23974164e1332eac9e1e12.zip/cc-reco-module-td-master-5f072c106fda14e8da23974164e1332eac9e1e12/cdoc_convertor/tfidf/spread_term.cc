#include <string>
#include <vector>
#include <iostream>
#include <map>
#include <unordered_map>

#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/base.h"
#include "base/file/file_util.h"

int cmp(const std::pair<std::string, uint32> &x, const std::pair<std::string, uint32> &y)  {  
  return x.second > y.second;
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "spread term");

  std::string content;
  std::vector<std::string> flds;
  std::vector<std::string> words;
  std::vector<std::string> word_weight;
  std::vector<std::string> word_type;
  std::unordered_map<std::string, uint32> word_count_map;
  while(std::getline(std::cin, content)) {
    CHECK_GT(content.size(), 0u);
    
    flds.clear();
    base::SplitString(content, "\t", &flds);
    if(flds.size() != 3u) {
      LOG(ERROR) << "error line:" << content;
    }

    words.clear();
    base::SplitString(flds[2], ",", &words);
    for(int i = 0; i < (int)words.size(); i++) {
      std::string wordweight = words[i];
      if(wordweight.find("(bi)", 0) == wordweight.npos && wordweight.find("(tri)", 0) == wordweight.npos) {
        continue;
      }
      word_weight.clear();
      base::SplitString(wordweight, ":", &word_weight);
      if(word_weight.size() != 2u) {
        continue;
      } 
      word_count_map[word_weight[0]] += 1;
    }
  }
  std::vector<std::pair<std::string, uint32> > word_count_vec;
  for(auto it = word_count_map.begin(); it != word_count_map.end(); it++) {
    word_count_vec.push_back(std::make_pair(it->first, it->second));
  }
  std::sort(word_count_vec.begin(), word_count_vec.end(), cmp);

  for(int i = 0; i < (int)word_count_vec.size(); i++) {
    std::cout << word_count_vec[i].first << "\t" << word_count_vec[i].second << std::endl;
  }
  return 0;
}
