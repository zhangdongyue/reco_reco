#include <unordered_map>
#include <unordered_set>
#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include <regex>

#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"

#include "nlp/common/nlp_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "reco/bizc/reco_splice/reco_splice.h"
#include "extend/regexp/re3/re3.h"

DEFINE_string(df_file, "df.dict", "input df file");
DEFINE_string(doc_count_file, "doc_count.txt", "number of documents");

reco::splice::RecoSplicer splicer_;

void RemoveHtmlTag(const std::string& old_string, std::string* new_string) {
  // 处理掉各种 http tag
  //  比如<!--IMG#0-->   <p> <!--VIDEO#0--> <!--IMG#0--> 等内容
  CHECK_NOTNULL(new_string);
  *new_string = old_string;
  // extend::re3::Re3::GlobalReplace(new_string, "<[!#+\\/=0-9A-Za-z_\\-[:graph:]]+>", "");
  extend::re3::Re3::GlobalReplace(new_string, "<[[:ascii:]]+>", " ");
}

void ReadFile(std::unordered_map<std::string, float>* idf_dict) {
  // doc count
  std::vector<std::string> lines;
  std::vector<std::string> flds;
  base::FilePath doc_count_file(FLAGS_doc_count_file);
  CHECK(base::file_util::ReadFileToLines(doc_count_file, &lines));
  int doc_count = 0;
  for(int i = 0; i < (int)lines.size(); i++) {
    CHECK_GT(lines[i].size(), 0u);
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    CHECK_EQ(flds.size(), 2u);
    if(flds[0] == "MapSplitDocCount") {
      CHECK(base::StringToInt(flds[1], &doc_count));
    } 
  }
  if(doc_count == 0) {
    LOG(ERROR) << "number of documents is zero";
    return;
  }
  LOG(INFO) << "MapSplitDocCount:" << doc_count;

  // df
  lines.clear();
  base::FilePath idf_file(FLAGS_df_file);
  CHECK(base::file_util::ReadFileToLines(idf_file, &lines));
  double idf = 0;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() != 2u) {
      LOG(ERROR) << "error idf line, " << lines[i];
      continue;
    }
    CHECK(base::StringToDouble(flds[1], &idf));
    (*idf_dict)[flds[0]] = std::log((float)doc_count / (float)idf);
  }
}

bool IsFilteredByPostag(const nlp::term::TermInfo& info) {
  if (info.is_postag(nlp::term::kWhiteSpace)
      || info.is_postag(nlp::term::kPunctuation)
      || info.is_postag(nlp::term::kPreposition)
      || info.is_postag(nlp::term::kAuxiliary)
      || info.is_postag(nlp::term::kExclamation)) {
    return true;
  }
  return false;
}

void CalcDocTf(const nlp::term::TermContainer& container, const std::string& content, bool is_title,
               std::unordered_map<std::string, float> * kw_tf_vec) {
  //const float kTitleEntityWt  = 2;
  const float kTitleBigramWt  = 1.5;
  const float kTitleTrigramWt = 1.5;
  //const float kTitleUnigramWt = 1.25;

  //const float kContentEntityWt  = 1.5;
  const float kContentBigramWt  = 1.25;
  const float kContentTrigramWt = 1.25;
  //const float kContentUnigramWt = 1;

  std::string term;
  // bigram
  for (int j = 0; j < container.basic_term_num() - 1; ++j) {
    const nlp::term::TermInfo& info1 = container.basic_term_info(j);
    const nlp::term::TermInfo& info2 = container.basic_term_info(j + 1);
    if (IsFilteredByPostag(info1)
        || (IsFilteredByPostag(info2) && !info2.is_postag(nlp::term::kWhiteSpace))) {
      continue;
    }
    if (!info2.is_postag(nlp::term::kWhiteSpace)) {
      term = info1.term(content).as_string() + info2.term(content).as_string();
    } else if (j < container.basic_term_num() - 2) {
      const nlp::term::TermInfo& info3 = container.basic_term_info(j + 2);
      term = info1.term(content).as_string() + info3.term(content).as_string();
      if (IsFilteredByPostag(info3)) {
        continue;
      }
      term = info1.term(content).as_string() + info3.term(content).as_string();
    } else {
      continue;
    }
    (*kw_tf_vec)[term + "(bi)"] += is_title ? kTitleBigramWt : kContentBigramWt;
  }
  // trigram
  for (int j = 0; j < container.basic_term_num() - 2; ++j) {
    const nlp::term::TermInfo& info1 = container.basic_term_info(j);
    const nlp::term::TermInfo& info2 = container.basic_term_info(j + 1);
    const nlp::term::TermInfo& info3 = container.basic_term_info(j + 2);
    // if (info1.entity_index != -1 || info2.entity_index != -1 || info3.entity_index != -1) {
    //   continue;
    // }
    if (IsFilteredByPostag(info1)
        || info2.is_postag(nlp::term::kPunctuation)
        || IsFilteredByPostag(info3)) {
      continue;
    }
    term = info1.term(content).as_string() + info2.term(content).as_string() +
        info3.term(content).as_string();
    (*kw_tf_vec)[term + "(tri)"] += is_title ? kTitleTrigramWt : kContentTrigramWt;
  }
  
  std::unordered_map<std::string, float>::iterator iter;
  for(iter = kw_tf_vec->begin(); iter != kw_tf_vec->end(); ) {
    if(iter->second < 2.5) {
      iter = kw_tf_vec->erase(iter);
    } else {
      iter++;
    }
  }
}

void GetRealTerm(const std::string &term_ttype, std::string *term) {
  std::vector<std::string> flds;
  int idx = 0;
  if((idx = term_ttype.find("(en)", 0)) != -1) {
    CHECK_GT(idx, 0);
    *term = term_ttype.substr(0, idx);
  } else if((idx = term_ttype.find("(uni)", 0)) != -1) {
    CHECK_GT(idx, 0);
    *term = term_ttype.substr(0, idx);
  } else if((idx = term_ttype.find("(bi)", 0)) != -1) {
    CHECK_GT(idx, 0);
    *term = term_ttype.substr(0, idx);
  } else if((idx = term_ttype.find("(tri)", 0)) != -1) {
    CHECK_GT(idx, 0);
    *term = term_ttype.substr(0, idx);
  } else {
    *term = term_ttype;
  }
}

void CalcDocTfIdf(const std::string &content, const nlp::term::TermContainer& container, int title_len,
                  const std::unordered_map<std::string, float>& kw_idf_map,
                  std::vector<std::pair<float, std::string> >* kw_tfidf_vec) {

  std::unordered_map<std::string, float> kw_tf_map;
  // do splice
  std::unordered_map<std::string, int> bigram_phrases;
  std::unordered_map<std::string, int> trigram_phrases;
  if (!splicer_.SpliceT(content, title_len, container, &bigram_phrases, &trigram_phrases)) {
    LOG(WARNING) << "failed to extract splice";
    bigram_phrases.clear();
    trigram_phrases.clear();
  }
  int phrase_count = (int)container.basic_term_num();
  for(auto it = bigram_phrases.begin(); it != bigram_phrases.end(); it++) {
    kw_tf_map[it->first + "(bi)"] = (it->second * 1.0) / (phrase_count * 1.0);
  }
  for(auto it = trigram_phrases.begin(); it != trigram_phrases.end(); it++) {
    kw_tf_map[it->first + "(tri)"] = (it->second * 1.0) / (phrase_count * 1.0);
  }

  if(kw_tf_map.empty()) {
    LOG(ERROR) << "the number of phrases is zero";
    return;
  }
  // calc tf-idf
  for (auto iter = kw_tf_map.begin(); iter != kw_tf_map.end(); ++iter) {
    //if (iter->second <= 1) continue;
    std::string term;
    GetRealTerm(iter->first, &term);
    if(term.size() == 0u) {
      continue;
    }
    auto idf_iter = kw_idf_map.find(term);
    if (idf_iter == kw_idf_map.end()) {
      continue;
    }
    kw_tfidf_vec->push_back(std::make_pair(iter->second * idf_iter->second, iter->first));
  }
  std::sort(kw_tfidf_vec->begin(), kw_tfidf_vec->end(), std::greater<std::pair<float, std::string> >());

  // top
  int term_num = container.basic_term_num() + container.entity_term_num();
  int limit_num = std::min(term_num / 10, 10);
  limit_num = std::min(limit_num, (int)kw_tfidf_vec->size());

  kw_tfidf_vec->resize(limit_num);
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "calc tfidf mapper");
  
  LOG(INFO) << "load dict...";
  std::unordered_map<std::string, float> dict_idf;
  ReadFile(&dict_idf);
  CHECK_GT(dict_idf.size(), 0u);
  LOG(INFO) << "succ to load idf dict.";

  nlp::segment::Segmenter segmenter;
  nlp::postag::PosTagger postagger;
  nlp::ner::Ner ner;

  std::string article;
  std::vector<std::string> flds;
  std::vector<std::pair<float, std::string> > kw_tfidf_vec;
  while(std::getline(std::cin, article)) {
    CHECK_GT((int)article.size(), 0);

    flds.clear();
    base::SplitString(article, "\t", &flds);
    if (flds.size() != 5) {
      LOG(ERROR) << "error line, " << article;
      continue;
    }
    
    std::string title;
    std::string content;
    RemoveHtmlTag(nlp::util::NormalizeLine(flds[2]), &title);
    RemoveHtmlTag(nlp::util::NormalizeLine(flds[3]), &content);
    if (title.empty() || content.empty()) {
      LOG(ERROR) << "title or content is empty: " << article;
      continue;
    }
    std::string title_content = title + " " + content;
    if (title_content.size() < 100) {
      LOG(ERROR) << "length is less then 100: " << article;
      continue;
    }

    nlp::term::TermContainer container;
    if (!segmenter.SegmentT(title_content, &container)
        || !postagger.PosTagT(title_content, &container)
        || !ner.DetectEntityT(title_content, &container)) {
      LOG(ERROR) << "segment fail, " << content;
      continue;
    }

    if(container.basic_term_num() < 20) {
      LOG(INFO) << "basic term num less than twenty";
      continue;
    }
    kw_tfidf_vec.clear();
    CalcDocTfIdf(title_content, container, (int)title.size(), dict_idf, &kw_tfidf_vec);
    std::string keyword_list = base::StringPrintf("%s\t", flds[1].c_str());
    for (int j = 0; j < (int)kw_tfidf_vec.size(); ++j) {
      if (j != 0) { 
        keyword_list.append(",");
      }
      keyword_list.append(base::StringPrintf("%s:%.3f", kw_tfidf_vec[j].second.c_str(),
                                             kw_tfidf_vec[j].first));
    }
    std::string id = flds[0];
    base::TrimWhitespaces(&id);
    std::string new_id = id;
    if(new_id == "0") {
      new_id = base::Int64ToString(base::CalcTermSign(title.c_str(), (int)title.size()));
    }
    std::cout << new_id << "\t" <<  keyword_list << std::endl;
  } 
  return 0;
}
