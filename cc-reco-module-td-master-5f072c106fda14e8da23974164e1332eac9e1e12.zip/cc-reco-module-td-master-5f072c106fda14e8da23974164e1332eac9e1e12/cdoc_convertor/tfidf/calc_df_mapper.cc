#include <unordered_map>
#include <unordered_set>
#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include <algorithm>

#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"

#include "nlp/common/nlp_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/logging.h"
#include "extend/regexp/re3/re3.h"

void RemoveHtmlTag(const std::string& old_string, std::string* new_string) {
  // 处理掉各种 http tag
  //  比如<!--IMG#0-->   <p> <!--VIDEO#0--> <!--IMG#0--> 等内容
  CHECK_NOTNULL(new_string);
  *new_string = old_string;
  // extend::re3::Re3::GlobalReplace(new_string, "<[!#+\\/=0-9A-Za-z_\\-[:graph:]]+>", "");
  extend::re3::Re3::GlobalReplace(new_string, "<[[:ascii:]]+>", " ");
}

void parseTerms(const nlp::term::TermContainer& container,
                const std::string& content,
                std::unordered_map<std::string, uint64>* term_counters) {
  std::unordered_set<std::string> uniq_set;
  // entity
  std::string term;
  for (int j = 0; j < container.entity_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.entity_term_info(j);
    if (info.is_postag(nlp::term::kWhiteSpace) || info.is_postag(nlp::term::kPunctuation)) {
      continue;
    }
    uniq_set.insert(info.term(content).as_string());
  }

  // unigram
  for (int j = 0; j < container.basic_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.basic_term_info(j);
    if (info.is_postag(nlp::term::kWhiteSpace) || info.is_postag(nlp::term::kPunctuation)) {
      continue;
    }
    uniq_set.insert(info.term(content).as_string());
  }

  // bigram
  for (int j = 0; j < container.basic_term_num() - 1; ++j) {
    const nlp::term::TermInfo& info1 = container.basic_term_info(j);
    const nlp::term::TermInfo& info2 = container.basic_term_info(j + 1);
    if (info1.is_postag(nlp::term::kWhiteSpace) || info1.is_postag(nlp::term::kPunctuation)
        || info2.is_postag(nlp::term::kPunctuation)) {
      continue;
    }
    if (!info2.is_postag(nlp::term::kWhiteSpace)) {
      term = info1.term(content).as_string() + info2.term(content).as_string();
    } else if (j < container.basic_term_num() - 2) {
      const nlp::term::TermInfo& info3 = container.basic_term_info(j + 2);
      if (info3.is_postag(nlp::term::kPunctuation)) {
        continue;
      }
      term = info1.term(content).as_string() + info3.term(content).as_string();
    } else {
      continue;
    }
    uniq_set.insert(term);
  }

  // trigram
  for (int j = 0; j < container.basic_term_num() - 2; ++j) {
    const nlp::term::TermInfo& info1 = container.basic_term_info(j);
    const nlp::term::TermInfo& info2 = container.basic_term_info(j + 1);
    const nlp::term::TermInfo& info3 = container.basic_term_info(j + 2);
    if (info1.is_postag(nlp::term::kWhiteSpace) || info1.is_postag(nlp::term::kPunctuation)
        || info2.is_postag(nlp::term::kPunctuation)
        || info3.is_postag(nlp::term::kPunctuation) || info3.is_postag(nlp::term::kWhiteSpace)) {
      continue;
    }
    term = info1.term(content).as_string() + info2.term(content).as_string() +
        info3.term(content).as_string();
    uniq_set.insert(term);
  }

  LOG(INFO) << base::StringPrintf("uniq_set' size %lu", uniq_set.size());
  
  for (auto iter = uniq_set.begin(); iter != uniq_set.end(); ++iter) {
    //std::cout << *iter << " ";
    (*term_counters)[*iter] += 1;
  }
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "mapper for idf");
 
  uint32 docs_count = 0;

  nlp::segment::Segmenter segmenter;
  nlp::postag::PosTagger postagger;
  nlp::ner::Ner ner;

  std::string article;
  std::vector<std::string> flds;
  std::unordered_map<std::string, uint64> term_counters;
  std::map<std::string, int> output_history;
  while (getline(std::cin, article)) {
    CHECK_GT((int)article.size(), 0);

    flds.clear();
    base::SplitString(article, "\t", &flds);
    if(flds.size() != 5u) {
      LOG(ERROR) << "error line:" << article;
    }

    std::string title;
    std::string content;
    RemoveHtmlTag(nlp::util::NormalizeLine(flds[2]), &title);
    RemoveHtmlTag(nlp::util::NormalizeLine(flds[3]), &content);
    if (title.empty() || content.empty()) {
      LOG(ERROR) << "title or content is empty: " << article;
      continue;
    }
    std::string title_content = title + " " + content;
    if (title_content.size() < 100) {
      LOG(ERROR) << "length is less then 100: " << article;
      continue;
    }

    nlp::term::TermContainer container;
    if (!segmenter.SegmentT(title_content, &container)
        || !postagger.PosTagT(title_content, &container)
        || !ner.DetectEntityT(title_content, &container)) {
      LOG(ERROR) << "segment fail, " << content;
      continue;
    }

    term_counters.clear();
    parseTerms(container, title_content, &term_counters);

    output_history.clear();
    for (auto it = term_counters.begin(); it != term_counters.end(); ++it) {
      if(output_history.count(it->first) > 0) {
        continue;
      } 
      output_history[it->first] = 1;
      std::cout << it->first << "\t" << "1" << std::endl;
    }
    ++docs_count;
  }

  std::cout << "MapSplitDocCount" << "\t" << docs_count << std::endl;

  return 0;
}
