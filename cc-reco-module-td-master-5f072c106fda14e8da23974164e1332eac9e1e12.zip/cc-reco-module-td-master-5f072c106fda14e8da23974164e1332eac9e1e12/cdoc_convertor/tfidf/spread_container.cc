#include <string>
#include <unordered_map>
#include <unordered_set>
#include <iostream>
#include <fstream>
#include <cmath>
#include <regex>
#include <map>
#include <algorithm>

#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "nlp/common/nlp_util.h"
#include "base/common/base.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "extend/regexp/re3/re3.h"
#include "base/strings/string_number_conversions.h"

DEFINE_string(df_file, "df.dict", "input df file");
DEFINE_string(doc_count_file, "doc_count_file.txt", "number of docments");
DEFINE_string(whitelist_file, "whitelist.txt", "number of documents");

bool IsFilteredByPostag(const nlp::term::TermInfo& info) {
  if (info.is_postag(nlp::term::kWhiteSpace)
      || info.is_postag(nlp::term::kPunctuation)
      || info.is_postag(nlp::term::kPreposition)
      || info.is_postag(nlp::term::kAuxiliary)
      || info.is_postag(nlp::term::kExclamation)) {
    return true;
  }
  return false;
}

void RemoveHtmlTag(const std::string& old_string, std::string* new_string) {
  // 处理掉各种 http tag
  //  比如<!--IMG#0-->   <p> <!--VIDEO#0--> <!--IMG#0--> 等内容
  CHECK_NOTNULL(new_string);
  *new_string = old_string;
  // extend::re3::Re3::GlobalReplace(new_string, "<[!#+\\/=0-9A-Za-z_\\-[:graph:]]+>", "");
  extend::re3::Re3::GlobalReplace(new_string, "<[[:ascii:]]+>", " ");
}

std::string getPartOfSpeech(uint8 postag) {
  switch(postag) {
    case 0:
      return "Adjective";
    case 1:
      return "Conjunction";
    case 2:
      return "Adverb";
    case 3:
      return "Exclamation";
    case 4:
      return "Position";
    case 5:
      return "Prefix";
    case 6:
      return "Postfix";
    case 7:
      return "Number";
    case 8:
      return "NumberQuantity";
    case 9:
      return "Noun";
    case 10:
      return "HumanName";
    case 11:
      return "FamilyName";
    case 12:
      return "GivenName";
    case 13:
      return "Preposition";
    case 14:
      return "Quantity";
    case 15:
      return "Pronoun";
    case 16:
      return "Place";
    case 17:
      return "Time";
    case 18:
      return "Auxiliary";
    case 19:
      return "Verb";
    case 20:
      return "Punctation";
    case 21:
      return "WhiteSpace";
    case 22:
      return "UnknownPostTag";
    default:
      return "UnKnown";
  }
}

std::string getRuneType(uint8 type) {
  uint8 i = 1;
  if(i == type) {
    return "Number";
  } else if(i << 1 == type) {
    return "Alpha";
  } else if(i << 2 == type) {
    return "WhiteSpace";
  } else if(i << 3 == type) {
    return "Punctuation";
  } else if(i << 4 == type) {
    return "Stopword";
  } else if(i << 5 == type) {
    return "Other";
  } else {
    return "Time";
  }
}

std::string getEntityType(uint8 type) {
  switch(type) {
    case 0:
      return "Idiom";
    case 1:
      return "EntityHuman";
    case 2:
      return "EntityPlace";
    case 3:
      return "Organization";
    case 4:
      return "Book";
    case 5:
      return "Brand";
    case 6:
      return "Product";
    case 7:
      return "ProductSN";
    case 8:
      return "Movie";
    case 9:
      return "Video";
    case 10:
      return "Game";
    case 11:
      return "Software";
    case 12:
      return "Music";
    case 13:
      return "Disease";
    case 14:
      return "Album";
    case 15:
      return "Phrase";
    case 16:
      return "EntityOther";
    case 17:
      return "BookSN";
    case 18:
      return "VideoSN";
    case 19:
      return "SoftwareVN";
    case 20:
      return "WebSite";
    case 21:
      return "Proposition";
    case 22:
      return "Stock";
    case 23:
      return "UnkownEntity";
    default:
      return "Unknown";
  }
}

void ReadFile(std::unordered_map<std::string, float>* idf_dict, std::map<std::string, int> *dict_whitelist) {
  // doc count
  std::vector<std::string> lines;
  std::vector<std::string> flds;
  base::FilePath doc_count_file(FLAGS_doc_count_file);
  CHECK(base::file_util::ReadFileToLines(doc_count_file, &lines));
  int doc_count = 0;
  for(int i = 0; i < (int)lines.size(); i++) {
    CHECK_GT(lines[i].size(), 0u);
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    CHECK_EQ(flds.size(), 2u);
    if(flds[0] == "MapSplitDocCount") {
      CHECK(base::StringToInt(flds[1], &doc_count));
    } 
  }
  if(doc_count == 0) {
    LOG(ERROR) << "number of documents is zero";
    return;
  }

  // df
  LOG(INFO) << "MapSplitDocCount:" << doc_count;
  lines.clear();
  base::FilePath idf_file(FLAGS_df_file);
  CHECK(base::file_util::ReadFileToLines(idf_file, &lines));
  double idf = 0;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() != 2u) {
      LOG(ERROR) << "error idf line, " << lines[i];
      continue;
    }
    CHECK(base::StringToDouble(flds[1], &idf));
    (*idf_dict)[flds[0]] = std::log((float)doc_count / (float)idf);
  }

  // white list
  lines.clear();
  base::FilePath whitelist_file(FLAGS_whitelist_file);
  CHECK(base::file_util::ReadFileToLines(whitelist_file, &lines));
  for(int i = 0; i < (int)lines.size(); i++) {
    if(lines[i].empty() || lines[i].size() == 0) {
      continue;
    }
    (*dict_whitelist)[lines[i]] = 1;
  }
}

void GetRealTerm(const std::string &term_ttype, std::string *term) {
  std::vector<std::string> flds;
  int idx = 0;
  if((idx = term_ttype.find("(en)", 0)) != -1) {
    CHECK_GT(idx, 0);
    *term = term_ttype.substr(0, idx);
  } else if((idx = term_ttype.find("(uni)", 0)) != -1) {
    CHECK_GT(idx, 0);
    *term = term_ttype.substr(0, idx);
  } else if((idx = term_ttype.find("(bi)", 0)) != -1) {
    CHECK_GT(idx, 0);
    *term = term_ttype.substr(0, idx);
  } else if((idx = term_ttype.find("(tri)", 0)) != -1) {
    CHECK_GT(idx, 0);
    *term = term_ttype.substr(0, idx);
  }
}

void CalcDocTf(const nlp::term::TermContainer& container, const std::string& content, bool is_title,
               const std::map<std::string, int> dict_whitelist, std::unordered_map<std::string, float> * kw_tf_vec) {
  //const float kTitleEntityWt  = 2;
  const float kTitleBigramWt  = 1.5;
  const float kTitleTrigramWt = 1.5;
  //const float kTitleUnigramWt = 1.25;

  //const float kContentEntityWt  = 1.5;
  const float kContentBigramWt  = 1.25;
  const float kContentTrigramWt = 1.25;
  //const float kContentUnigramWt = 1;

  std::string term;
  // bigram
  for (int j = 0; j < container.basic_term_num() - 1; ++j) {
    const nlp::term::TermInfo& info1 = container.basic_term_info(j);
    const nlp::term::TermInfo& info2 = container.basic_term_info(j + 1);
    if (IsFilteredByPostag(info1)
        || (IsFilteredByPostag(info2) && !info2.is_postag(nlp::term::kWhiteSpace))) {
      continue;
    }
    if (!info2.is_postag(nlp::term::kWhiteSpace)) {
      term = info1.term(content).as_string() + info2.term(content).as_string();
    } else if (j < container.basic_term_num() - 2) {
      const nlp::term::TermInfo& info3 = container.basic_term_info(j + 2);
      term = info1.term(content).as_string() + info3.term(content).as_string();
      if (IsFilteredByPostag(info3)) {
        continue;
      }
      term = info1.term(content).as_string() + info3.term(content).as_string();
    } else {
      continue;
    }
    if(dict_whitelist.count(term) == 0) {
      continue;
    }
    (*kw_tf_vec)[term + "(bi)"] += is_title ? kTitleBigramWt : kContentBigramWt;
  }
  // trigram
  for (int j = 0; j < container.basic_term_num() - 2; ++j) {
    const nlp::term::TermInfo& info1 = container.basic_term_info(j);
    const nlp::term::TermInfo& info2 = container.basic_term_info(j + 1);
    const nlp::term::TermInfo& info3 = container.basic_term_info(j + 2);
    // if (info1.entity_index != -1 || info2.entity_index != -1 || info3.entity_index != -1) {
    //   continue;
    // }
    if (IsFilteredByPostag(info1)
        || info2.is_postag(nlp::term::kPunctuation)
        || IsFilteredByPostag(info3)) {
      continue;
    }
    term = info1.term(content).as_string() + info2.term(content).as_string() +
        info3.term(content).as_string();
    if(dict_whitelist.count(term) == 0) {
      continue;
    }
    (*kw_tf_vec)[term + "(tri)"] += is_title ? kTitleTrigramWt : kContentTrigramWt;
  }
  
  std::unordered_map<std::string, float>::iterator iter;
  for(iter = kw_tf_vec->begin(); iter != kw_tf_vec->end(); ) {
    if(iter->second < 2.5) {
      iter = kw_tf_vec->erase(iter);
    } else {
      iter++;
    }
  }
}

void CalcDocTfIdf(const std::string &content, const nlp::term::TermContainer& container, int title_len,
                  const std::unordered_map<std::string, float>& kw_idf_map,
                  std::vector<std::pair<float, std::string> >* kw_tfidf_vec) {

  std::unordered_map<std::string, float> kw_tf_map;
  // do splice
  std::unordered_map<std::string, int> bigram_phrases;
  std::unordered_map<std::string, int> trigram_phrases;
  if (!splicer_.SpliceT(content, title_len, container, &bigram_phrases, &trigram_phrases)) {
    LOG(WARNING) << "failed to extract splice";
    bigram_phrases.clear();
    trigram_phrases.clear();
  }
  int phrase_count = (int)container.basic_term_num();
  for(auto it = bigram_phrases.begin(); it != bigram_phrases.end(); it++) {
    kw_tf_map[it->first + "(bi)"] = (it->second * 1.0) / (phrase_count * 1.0);
  }
  for(auto it = trigram_phrases.begin(); it != trigram_phrases.end(); it++) {
    kw_tf_map[it->first + "(tri)"] = (it->second * 1.0) / (phrase_count * 1.0);
  }

  if(kw_tf_map.empty()) {
    LOG(ERROR) << "the number of phrases is zero";
    return;
  }
  // calc tf-idf
  for (auto iter = kw_tf_map.begin(); iter != kw_tf_map.end(); ++iter) {
    //if (iter->second <= 1) continue;
    std::string term;
    GetRealTerm(iter->first, &term);
    if(term.size() == 0u) {
      continue;
    }
    auto idf_iter = kw_idf_map.find(term);
    if (idf_iter == kw_idf_map.end()) {
      continue;
    }
    kw_tfidf_vec->push_back(std::make_pair(iter->second * idf_iter->second, iter->first));
  }
  std::sort(kw_tfidf_vec->begin(), kw_tfidf_vec->end(), std::greater<std::pair<float, std::string> >());

  // top
  int term_num = container.basic_term_num() + container.entity_term_num();
  int limit_num = std::min(term_num / 10, 10);
  limit_num = std::min(limit_num, (int)kw_tfidf_vec->size());

  kw_tfidf_vec->resize(limit_num);
}

void CalcDocTfIdf(const nlp::term::TermContainer& title_container, const std::string& title,
                  const nlp::term::TermContainer& content_container, const std::string& content,
                  const std::unordered_map<std::string, float>& kw_idf_map,
                  std::vector<std::pair<float, std::string>>* kw_tfidf_vec) {

  std::unordered_map<std::string, float> kw_tf_map;

  // title tf
  CalcDocTf(title_container, title, true, &kw_tf_map);

  // content tf
  CalcDocTf(content_container, content, false, &kw_tf_map);

  // calc tf-idf
  for (auto iter = kw_tf_map.begin(); iter != kw_tf_map.end(); ++iter) {
    if (iter->second <= 1) continue;
    std::string term;
    GetRealTerm(iter->first, &term);
    CHECK_GT(term.size(), 0u);
    auto idf_iter = kw_idf_map.find(term);
    if (idf_iter == kw_idf_map.end()) {
      continue;
    }
    kw_tfidf_vec->push_back(std::make_pair(iter->second * idf_iter->second, iter->first));
  }
  std::sort(kw_tfidf_vec->begin(), kw_tfidf_vec->end(), std::greater<std::pair<float, std::string> >());

  // top
  int term_num = title_container.basic_term_num() + title_container.entity_term_num() +
      content_container.basic_term_num() + content_container.entity_term_num();
  int limit_num = std::min(term_num / 10, 10);
  limit_num = std::min(limit_num, (int)kw_tfidf_vec->size());

  kw_tfidf_vec->resize(limit_num);
}

void getPostagHtml(nlp::term::TermContainer &container, std::string title_content, std::string *doc, std::string &full_text, std::string title_only, int idx) {
  std::vector<std::string> flds;
  std::string article;
  std::map<uint32, uint8> entity_idx_map;
  //std::map<uint32, uint32> phrase_idx_map;

  (*doc).append("<div>");
  (*doc).append("<div class=\"content\" style=\"width:95%;margin:0 auto 10px auto;\">&nbsp;&nbsp;&nbsp;&nbsp;");

  //phrase_idx_map.clear();
  //for(int i = 0; i < container.phrase_term_num(); i++) {
  //  const nlp::term::TermInfo& info = container.phrase_term_info(i);
  //  phrase_idx_map[info.begin] = info.end;
  //}

  entity_idx_map.clear();
  for(int i = 0; i < container.entity_term_num(); i++) {
    const nlp::term::TermInfo& info = container.entity_term_info(i);
    entity_idx_map[info.begin] = (uint8)info.enum_entity;
  }
  for(int i = 0; i < container.basic_term_num(); i++) {
    const nlp::term::TermInfo& info = container.basic_term_info(i);
    (*doc).append("&nbsp;");
    (*doc).append("<span style=\"");
    if (info.entity_index != -1) {
      (*doc).append("color:Red;");
    }
    if(i % 2 == 0) {
      (*doc).append("background:#e9e9e9;");
    }
    if(info.phrase_index != -1) {
      (*doc).append("font-weight:bold;");
    }
    (*doc).append("\" ");
    // postag
    (*doc).append("title=\"" + getPartOfSpeech(info.enum_postag));
    if(info.entity_index != -1 && entity_idx_map.count(info.begin) > 0) {
      (*doc).append("  " + getEntityType(entity_idx_map[info.begin]));
    }
    (*doc).append("  " + getRuneType(info.rune_type));
    (*doc).append("\">");
    (*doc).append(info.term(title_content).as_string());
    (*doc).append("</span>");
  }
  (*doc).append("</div>");
  // full text
  (*doc).append("<div style=\"width:95%;margin:0 auto 10px auto;\">");
  (*doc).append(full_text);
  (*doc).append("</div>");

  // title only
  (*doc).append("<div style=\"width:95%;margin:0 auto 10px auto;\">");
  (*doc).append(title_only);
  (*doc).append("</div>");
  (*doc).append("</div>");
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "calc tfidf mapper");
  
  LOG(INFO) << "load idf dict...";
  std::unordered_map<std::string, float> dict_idf;
  std::map<std::string, int> dict_whitelist;
  ReadFile(&dict_idf, &dict_whitelist);
  CHECK_GT(dict_idf.size(), 0u);
  LOG(INFO) << "succ to load idf dict.";

  nlp::segment::Segmenter segmenter;
  nlp::postag::PosTagger postagger;
  nlp::ner::Ner ner;

  std::string article;
  std::vector<std::string> flds;
  std::vector<std::pair<float, std::string> > kw_tfidf_vec;

  int idx = 0;
  std::string doc;
  doc.append("<html><head><title>doc</title><style>span.keyword{margin-right:5px;}</style>");
  doc.append("<script type=\"text/javascript\" src=\"jquery-1.10.2.js\"></script><script>$(document).ready(function(){$(\"span.keyword\").mouseover(function(){var firstChar = $(this).html().substr(0, 1);var content = $(this).parent().parent().find(\"div.content\");var childs = content.children();childs.each(function(){if($(this).html().indexOf(firstChar) != -1) {$(this).css(\"background\", \"Blue\");}});});$(\"span.keyword\").mouseout(function(){var firstChar = $(this).html().substr(0, 1);var content = $(this).parent().parent().find(\"div.content\");var childs = content.children();childs.each(function(){if($(this).html().indexOf(firstChar) != -1) {$(this).css(\"background\", \"White\");}});});});</script>");
  doc.append("</head><body>");
  while(std::getline(std::cin, article)) {
    CHECK_GT((int)article.size(), 0);

    flds.clear();
    base::SplitString(article, "\t", &flds);
    if (flds.size() != 5) {
      LOG(ERROR) << "error line, " << article;
      continue;
    }
    std::string title;
    std::string content;
    RemoveHtmlTag(nlp::util::NormalizeLine(flds[2]), &title);
    RemoveHtmlTag(nlp::util::NormalizeLine(flds[3]), &content);
    if (title.empty() || content.empty()) {
      LOG(ERROR) << "title or content is empty: " << article;
      continue;
    }
    std::string title_content = title + " " + content;
    if(title_content.size() < 100u) {
      continue;
    }
    nlp::term::TermContainer container;
    if(!segmenter.SegmentT(title_content, &container)
       || !postagger.PosTagT(title_content, &container)
       || !ner.DetectEntityT(title_content, &container)) {
      continue;
    }
    nlp::term::TermContainer title_container;
    nlp::term::TermContainer content_container;
    if (!segmenter.SegmentT(title, &title_container)
        || !postagger.PosTagT(title, &title_container)
        || !ner.DetectEntityT(title, &title_container)
        || !segmenter.SegmentT(content, &content_container)
        || !postagger.PosTagT(content, &content_container)
        || !ner.DetectEntityT(content, &content_container)) {
      LOG(ERROR) << "segment fail, " << article;
      continue;
    }
    if(title_container.basic_term_num() + content_container.basic_term_num() < 20) {
      LOG(INFO) << "basic term num less than twenty";
      continue;
    }

    // full_text
    kw_tfidf_vec.clear();
    CalcDocTfIdf(title_container, title, content_container, content, dict_idf, &kw_tfidf_vec);
    
    std::string full_text;
    for (int j = 0; j < (int)kw_tfidf_vec.size(); ++j) {
       full_text.append("<span class=\"keyword\">");
       full_text.append(base::StringPrintf("%s:%.3f", kw_tfidf_vec[j].second.c_str(),
                                             kw_tfidf_vec[j].first));
       full_text.append("</span>");
    }

    // title only
    kw_tfidf_vec.clear();
    CalcDocTfIdf(title_content, container, (int)title.size(), dict_idf, &kw_tfidf_vec);
    std::string title_only;
    for (int j = 0; j < (int)kw_tfidf_vec.size(); ++j) {
       title_only.append("<span class=\"keyword\">");
       title_only.append(base::StringPrintf("%s:%.3f", kw_tfidf_vec[j].second.c_str(),
                                             kw_tfidf_vec[j].first));
       title_only.append("</span>");
    }
    
    getPostagHtml(container, title_content, &doc, full_text, title_only, idx);
    idx++;
  }
  doc.append("</body></html>");
  std::cout << doc << std::endl;
  return 0;
}

