#include <string>
#include <iostream>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/strings/string_split.h"

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "reducer for tfidf");

  std::string content;
  std::vector<std::string> fields;
  while(getline(std::cin, content)) {
    CHECK_GT((int)content.size(), 0);
    
    fields.clear();
    base::SplitString(content, "\t", &fields);
    CHECK_EQ((int)fields.size(), 3);

    std::cout << fields[0] << "\t" << fields[1] << "\t" << fields[2] << std::endl;
  }

  return 0;
}

