#include <string>
#include <iostream>
#include <unordered_map>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/mapreduce/mapreduce.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "reducer for idf");

  std::unordered_map<std::string, uint64> term_counters;
  std::string content;
  while(getline(std::cin, content)) {
    CHECK_GT((int)content.size(), 0);

    std::vector<std::string> fields;
    base::SplitString(content, "\t", &fields);
    CHECK_EQ((int)fields.size(), 2);

    uint64 count;
    base::StringToUint64(fields[1], &count);
    term_counters[fields[0]] += count;
  }
  for(auto it = term_counters.begin(); it != term_counters.end(); it++) {
    if(it->first != "MapSplitDocCount" && it->second < 5) {
      continue;
    }
    std::cout << it->first << "\t" << it->second << std::endl;
  }

  return 0;
}

