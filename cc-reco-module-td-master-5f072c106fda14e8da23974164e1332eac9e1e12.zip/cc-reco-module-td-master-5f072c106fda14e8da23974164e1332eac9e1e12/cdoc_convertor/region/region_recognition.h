#pragma once
#include <cstdatomic>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>

#include "base/file/file_path.h"
#include "base/thread/sync.h"
#include "nlp/common/term_info.h"
#include "nlp/common/term_container.h"
#include "reco/bizc/region/region_dict.h"
#include "reco/bizc/region/region_restrict.h"
#include "reco/bizc/region/gaode_region_client.h"
#include "reco/module/cdoc_convertor/tag/multi_pattern_match.h"

namespace nlp {
namespace term {
class TermContainer;
}
}  // namespace nlp

namespace reco {
class RecoItem;
namespace common {
struct RegionNode;
struct RegionRestrictInfo;
struct GaodeRegionInfo;
class GaoDeRegionClient;

enum CategoryLimitType {
  ONLY_FROM_TITLE,
  SEED_MISS_ONLY_FROM_TITLE,
  ONLY_BASED_SEED,
  RELAX_RECALL_FROM_TITLE,
  RELAX_RECALL_FROM_FINAL_TITLE,
  NONE
};

// 地域黑名单 term 信息
struct BlackTermInfo {
  // 黑名单词条
  std::string term;
  // [begin, end)
  // 词条在匹配串中的起始位置
  int begin;
  // 词条在匹配串中的结束位置中的下一个位置
  int end;

  BlackTermInfo(std::string t, int b, int e) {
    term = t;
    begin = b;
    end = e;
  }

  bool operator==(const BlackTermInfo& bt) {
    return this->term == bt.term && this->begin == bt.begin && this->end == bt.end;
  }
};

// 地域可信度
enum RegionRel {
  HIGH_CREDIBLE,
  MIDDLE_CREDIBLE,
  LOW_CREDIBLE,
  NOT_CREDIBLE
};

// 地域信息
struct RegionInfo {
  reco::common::RegionNode reg;
  std::string place;
  std::string place_tag;
  RegionRel reliability;
  bool is_from_title;
  bool exist_multi;
  bool selected;
  RegionInfo() {
    place = "";
    place_tag = "";
    reliability = RegionRel::NOT_CREDIBLE;
    is_from_title = false;
    exist_multi = false;
    selected = false;
  }
};

// 地名信息
struct PlaceInfo {
  std::string place;
  std::string place_tag;
  bool is_from_title;
  int entity_index;
  PlaceInfo() {
    place = "";
    place_tag = "";
    is_from_title = false;
    entity_index = -1;
  }
};

class RegionRecognition {
 public:
  explicit RegionRecognition(const std::string &reco_region_data_dir);
  ~RegionRecognition();

  // 提取地域字段, 提取成功，则将这些地名对应的 code 更新到 RecoItem 的 region 字段
  bool ExtractRegionFromRawitem(const reco::ItemIdentity& item_identity,
                                const std::string& source,
                                const std::string& orig_source,
                                const std::string& spider_region,
                                const std::string& content, int title_len,
                                const nlp::term::TermContainer &container,
                                RecoItem* reco_item);
  bool ExtractRegionFromRawitem(const reco::ItemIdentity& item_identity,
                                const std::string& source,
                                const std::string& orig_source,
                                const std::string& spider_region,
                                const std::string& content, int title_len,
                                const nlp::term::TermContainer &container,
                                RecoItem* reco_item,
                                std::vector<RegionInfo> *region_list,
                                GaodeRegionInfo *reg_info);
  bool ExtractRegionFromString(const std::string& source,
                               const std::string& orig_source,
                               const std::string& spider_region,
                               const std::string& content, int title_len,
                               const nlp::term::TermContainer& container,
                               std::vector<RegionInfo> *region_list);

  // 查找字符串 str 中出现的所有黑名单词条，并返回匹配位置
  bool SearchAllBlackTerms(const std::string &str, int str_len,
                           std::vector<BlackTermInfo>* black_terms);
 private:
  bool LoadSourceCntnBlackList();

  // 加载类别限制词典
  bool LoadCategoryLimitList();

  // 加载本地词列表
  bool LoadLocalWordList();

  // 加载歧义后缀词词表
  bool LoadAmbiguousSuffixWordList();

  // 查找类别限制对应的 tag , 1-只从 title 中抽取地域；2-种子源为空时只从 title 中抽取地域;
  // 3-只基于种子源抽取地域; 4-放开抽取地域的条件，可以选择来自 title 的低可信
  CategoryLimitType SearchCategoryLimit(const std::string &category);

  // 给定地名, 判断该地名是否有对应类别的黑名单
  bool SearchCategoryBlack(const std::string &region, const std::string &category);

  // 查找字符串 str 中是否出现来源黑名单词，有返回 true ,否则返回 false
  bool SearchSourceContentBlackTerms(const std::string &str);

  // 查找 title 是否包含限制黑名单词，有返回 true , 否则返回 false
  bool SearchTitleBlackLimitTerms(const std::string& content,
                                  int title_len,
                                  const nlp::term::TermContainer& container);

  // 根据 from_title 选择从正文或 title 中提取所有地域字段, 计算地域对应的 code , 存储到 region_id_list
  // region_id_list 不为空，则返回 true ，否则返回 false
  bool ExtractRegion(const std::string& source, const std::string& orig_source,
                     const std::string& spider_region, const std::string& content, int title_len,
                     const nlp::term::TermContainer& container,
                     bool from_title, RecoItem *reco_item,
                     std::vector<BlackTermInfo>* region_black_terms,
                     std::vector<RegionInfo> *region_list);
  // 计算 region 间的匹配情况,0-raw_region 为空，1-不匹配，2-与 raw_region 为省市关系匹配且 raw_region 为省，
  // 3-与 raw_region 为省市关系匹配且 raw_region 为市，4-与 raw_region 省匹配，5-与 raw_region 市匹配
  int RegionMatch(const std::string &raw_region, const std::string &extract_region);
  // 从 region 候选中选择最终 region
  bool FilterRegion(const bool &is_from_title,
                    const std::vector<reco::common::RegionInfo> &region_list,
                    std::string *region);
  bool FilterRegion(const std::vector<size_t> &region_index_list,
                    const std::vector<reco::common::RegionInfo> &region_list,
                    std::string *region);
  void FilterRegion(RecoItem *reco_item,
                    std::vector<reco::common::RegionInfo> *region_list);
  // 根据候选 region 查找 region code
  bool SearchRegion(const std::string& source, const std::string& orig_source,
                    const std::string& spider_region, const std::vector<PlaceInfo> &place_info_list,
                    const std::vector<PlaceInfo> &entity_place_info_list,
                    const std::vector<PlaceInfo> &travel_poi_place_info_list,
                    std::vector<RegionInfo> *region_list,
                    reco::common::CategoryLimitType &category_limit_tag);
  // 从文本中抽取地名实体
  bool ExtractValidEntity(RecoItem *reco_item, const std::string& title, int title_len,
                          const nlp::term::TermContainer& container,
                          const std::vector<BlackTermInfo>*region_black_terms,
                          bool from_title,
                          std::unordered_set<int32>& not_valid_entity_index_list,
                          std::vector<PlaceInfo>* place_info_list);
  // 计算 region 可信度
  bool CompleteRegionReliability(
      const std::string& source, const std::string& orig_source, const std::string& spider_region,
      const std::unordered_map<std::string, std::vector<RegionInfo> > &m_code_correspond_region_info,
      std::vector<RegionInfo> *region_list, reco::common::CategoryLimitType &category_limit_tag);
  // 加载词表, 用于抽取 manual_lable
  bool LoadDict(const std::string &reco_region_data_dir);

  // 判断是否为本地源, source 可以是种子源 或者 初始源
  bool IsLocalSource(const std::string& source);

  // 判断是否为非本地
  bool IsNotLocal(const std::string& title);

  // 判断新闻是否包含本地关键词
  bool HaveLocalWord(const std::string &content);

  // 种子源 region 修正
  void RefineRawRegion(const std::string &region, std::string *refine_region);

  // 判断地名是否是有歧义地名,如:北京路,上海路,不从这种地名中识别地域
  bool IsAmbiguousPlace(const std::string &place, const std::string &next_place);

  // 加载旅游poi词表
  bool LoadTravelPOIDict(const std::string &file_path);

  // 检查字符串里匹配的所有travel poi名称
  void FindTravelPOI(const std::string &buf, std::vector<std::string> *poi_names);

  // 解析标题里的旅游景点
  void ExtractTravelPOIFromTitle(const std::string &title, std::vector<PlaceInfo>* place_info_list);

 private:
  static const char* kRegionFile;
  static const char* kTravelPOIFile;

  static std::unordered_set<std::string> source_content_black_dict_;
  static std::unordered_map<std::string, CategoryLimitType> category_limit_dict_;
  static std::unordered_set<std::string> local_word_dict_;
  static std::unordered_set<std::string> ambiguous_suffix_word_dict_;

  static std::unordered_map<std::string, std::string> travel_poi_reg_dict_;
  static std::vector<std::string> travel_poi_vector_;
  static reco::Automation travel_poi_atm_;

  static std::atomic<bool> is_dict_init_;
  static thread::Mutex mutex_;
};
}
}  // namespace reco
