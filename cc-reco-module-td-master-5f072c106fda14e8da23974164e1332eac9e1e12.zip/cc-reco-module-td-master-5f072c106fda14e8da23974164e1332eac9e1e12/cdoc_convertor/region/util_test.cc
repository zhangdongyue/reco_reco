#include <string>
#include "reco/module/cdoc_convertor/region/region_recognition.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/strings/string_split.h"
#include "base/testing/gtest.h"
#include "nlp/common/nlp_util.h"
#include "nlp/ner/ner.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/segment/segmenter.h"
#include "reco/bizc/region/region_dict.h"
#include "reco/bizc/common/index_util.h"

DEFINE_string(region_file, "serving/reco/data/cdoc_convertor/city_code.txt", "region file");
DEFINE_string(region_black_file, "serving/reco/data/cdoc_convertor/city_black.txt", "region black file");

namespace nlp {
namespace term {
class TermContainer;
}
namespace segment {
class Segmenter;
}
namespace postag {
class PosTagger;
}
namespace ner {
class Ner;
}
}

namespace reco {
class RegionRecognition;
namespace common {
struct RegionNode;
struct RegionInfo;

TEST(RegionRecognition, ExtractRegionFromString) {
  // 加载地名词典
  // CHECK(reco::common::RegionSearcher::instance().Load(FLAGS_region_file));
  // CHECK(reco::common::RegionSearcher::instance().LoadBlackList(FLAGS_region_black_file));

  nlp::segment::Segmenter* segmenter = new nlp::segment::Segmenter;
  nlp::postag::PosTagger* postagger = new nlp::postag::PosTagger;
  nlp::ner::Ner* ner = new nlp::ner::Ner;
  nlp::term::TermContainer container;
  reco::common::RegionRecognition* region_recognition =
      new RegionRecognition("serving/reco/data/cdoc_convertor/");

  struct Cases {
    const char* title;
    bool succ;
    const char* region;
  } cases[] = {
    {"北京市天气预报", true, "010"},
    {"你好啊", false, ""},
    {"北京现代第九代索纳塔混动版年底上市", false, ""},
    {"北京时间公布", false, ""},
    {"确定北京时间公布", false, ""},
    {"报时北京时间", false, ""},
    {"北京房山区", true, "010"},
  };

  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(cases); ++i) {
    container.renew();  // reset

    std::string str(cases[i].title);
    std::cout << cases[i].title << std::endl;
    nlp::util::NormalizeLineInPlaceS(&str);
    CHECK(segmenter->SegmentT(str, &container));
    CHECK(postagger->PosTagT(str, &container));
    CHECK(ner->DetectEntityT(str, &container));

    std::vector<std::string> vec;
    std::vector<BlackTermInfo> region_black_terms;
    // 添加测试用例时注意调整这个下标
    if (i == 3) {
      std::string target_str("北京时间");
      int target_len = target_str.size();
      region_black_terms.push_back(BlackTermInfo(target_str, 0, target_len));
    } else if (i == 4) {
      std::string target_str("北京时间");
      int target_len = target_str.size();
      region_black_terms.push_back(BlackTermInfo(target_str, 6, 6 + target_len));
    } else if (i == 5) {
      std::string target_str("北京时间");
      int target_len = target_str.size();
      region_black_terms.push_back(BlackTermInfo(target_str, 6, 6 + target_len));
    }
    std::vector<reco::common::RegionInfo> region_list;
    std::vector<std::string> region_id_list;
    std::string regions;
    region_recognition->ExtractRegionFromString("", "", "", str, str.length(), container,
                                                &region_list);
    for (auto it = region_list.begin(); it != region_list.end(); it++) {
      region_id_list.push_back(it->reg.code);
    }
    regions = base::JoinStrings(region_id_list, ";");

    base::SplitString(regions, ";", &vec);
    // EXPECT_EQ(1, ret == cases[i].succ);
    // EXPECT_EQ(1, ret);
    if (!cases[i].succ && regions == "") {
      continue;
    }
    std::cout << regions << "\t" << cases[i].region << std::endl;
    std::vector<std::string> dst_vec;
    base::SplitString(cases[i].region, ";", &dst_vec);

    EXPECT_EQ(dst_vec.size(), vec.size());

    for (int i = 0; i < (int)vec.size(); ++i) {
      bool is_exist = false;
      for (int j = 0; j < (int)dst_vec.size(); ++j) {
        if (vec[i] == dst_vec[j]) {
          is_exist = true;
          break;
        }
      }
      EXPECT_EQ(true, is_exist);
    }
  }

  // 释放句柄
  delete segmenter;
  delete postagger;
  delete ner;
  delete region_recognition;
}

static void test_pack(const reco::ContentAttr& attr) {
  reco::ContentAttr attr1;
  uint64 bits, bits1;
  reco::common::PackContentAttr(attr, &bits);
  reco::common::UnPackContentAttr(bits, &attr1);
  reco::common::PackContentAttr(attr1, &bits1);
  ASSERT_EQ(bits, bits1);
}

TEST(Util, PackContentAttr) {
  reco::ContentAttr attr;
  uint64 bits;
  reco::common::PackContentAttr(attr, &bits);
  ASSERT_EQ(bits, 0u);

  attr.set_erro_title(reco::ContentAttr::kSuspect);
  test_pack(attr);

  attr.set_advertorial(reco::ContentAttr::kSureYes);
  test_pack(attr);

  attr.set_short_content(reco::ContentAttr::kSureYes);
  test_pack(attr);

  attr.set_dedup_paragraph(reco::ContentAttr::kSuspect);
  test_pack(attr);

  attr.set_dirty(reco::ContentAttr::kSureYes);
  test_pack(attr);

  attr.set_politics(reco::ContentAttr::kSuspect);
  test_pack(attr);

  attr.set_bluffing_title(reco::ContentAttr::kSureYes);
  test_pack(attr);
}

TEST(Util, ContentAttrMask) {
  reco::ContentAttr attr;
  uint64 mask = 0;

  attr.set_erro_title(reco::ContentAttr::kSuspect);
  mask = ContentAttrMask(attr);
  ASSERT_EQ(mask, 0x3u);

  attr.set_advertorial(reco::ContentAttr::kSureYes);
  mask = ContentAttrMask(attr);
  ASSERT_EQ(mask, (0xFu));

  attr.set_short_content(reco::ContentAttr::kSureYes);
  mask = ContentAttrMask(attr);
  ASSERT_EQ(mask, (0x3Fu));

  attr.set_dedup_paragraph(reco::ContentAttr::kSuspect);
  mask = ContentAttrMask(attr);
  ASSERT_EQ(mask, (0xFFu));

  attr.set_dirty(reco::ContentAttr::kSureYes);
  mask = ContentAttrMask(attr);
  ASSERT_EQ(mask, (0x3FFu));

  attr.set_politics(reco::ContentAttr::kSuspect);
  mask = ContentAttrMask(attr);
  ASSERT_EQ(mask, (0xFFFu));

  attr.set_bluffing_title(reco::ContentAttr::kSureYes);
  mask = ContentAttrMask(attr);
  ASSERT_EQ(mask, (0x3FFFu));
}
}  // namespace common
}  // namespace reco

