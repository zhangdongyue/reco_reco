#include "reco/module/cdoc_convertor/region/region_recognition.h"

#include <cmath>
#include <algorithm>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <functional>

#include "reco/bizc/common/appname_define.h"
#include "reco/bizc/common/channel_define.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "base/hash_function/term.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/utf_string_conversions.h"
#include "base/time/time.h"


DEFINE_bool(open_gaode_region, false, "open gaode region");
DEFINE_bool(open_video_region, false, "open video region");
DEFINE_bool(wemedia_only_from_title, false, "wemedia source only from title");

namespace reco {
namespace common {

const char* RegionRecognition::kRegionFile = "city_code.txt";
const char* RegionRecognition::kTravelPOIFile = "travel_poi.txt";

std::atomic<bool> RegionRecognition::is_dict_init_(false);
thread::Mutex RegionRecognition::mutex_;

std::unordered_set<std::string> RegionRecognition::source_content_black_dict_;
std::unordered_map<std::string, CategoryLimitType> RegionRecognition::category_limit_dict_;
std::unordered_set<std::string> RegionRecognition::local_word_dict_;
std::unordered_set<std::string> RegionRecognition::ambiguous_suffix_word_dict_;
std::unordered_map<std::string, std::string> RegionRecognition::travel_poi_reg_dict_;
std::vector<std::string> RegionRecognition::travel_poi_vector_;
reco::Automation RegionRecognition::travel_poi_atm_;

RegionRecognition::RegionRecognition(const std::string &reco_region_data_dir) {
  CHECK(LoadDict(reco_region_data_dir));
}

RegionRecognition::~RegionRecognition() {
}

bool RegionRecognition::LoadCategoryLimitList() {
  category_limit_dict_.insert(std::make_pair("体育", CategoryLimitType::ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("历史", CategoryLimitType::ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("游戏", CategoryLimitType::ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("娱乐", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));

  // 根据地域识别 badcase 增加类别限制(一级分类:两性情感 健康 军事 戏曲)
  category_limit_dict_.insert(std::make_pair("两性情感", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("健康", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("军事", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("戏曲", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("美术", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("国际", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("型男", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("宗教", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("小说", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("成人色情", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("旅游", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("星座", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("求职", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("美女写真", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("移民", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));

  // 根据地域识别 badcase 增加类别限制(一级分类:房产 财经 汽车 科技)
  category_limit_dict_.insert(std::make_pair("房产", CategoryLimitType::RELAX_RECALL_FROM_FINAL_TITLE));
  category_limit_dict_.insert(std::make_pair("财经", CategoryLimitType::RELAX_RECALL_FROM_FINAL_TITLE));
  category_limit_dict_.insert(std::make_pair("汽车", CategoryLimitType::RELAX_RECALL_FROM_FINAL_TITLE));
  category_limit_dict_.insert(std::make_pair("科技", CategoryLimitType::RELAX_RECALL_FROM_FINAL_TITLE));

  // 由于未分类会引入地域 badcase  (国际、军事、股票等类), 地域识别对于未分类依赖种子源和 title
  category_limit_dict_.insert(std::make_pair("未分类", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));

  // 根据类别限制评测结果增加(一级分类:奇闻 时尚 宠物 摄影 书画 育儿 彩票 科学探索 收藏 幽默 干货)
  category_limit_dict_.insert(std::make_pair("奇闻", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("时尚", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("宠物", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("摄影", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("书画", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("育儿", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("彩票", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("科学探索", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("收藏", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("幽默", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("干货", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));

  // 根据类别限制评测结果增加(二级分类:电脑 家电 手机 智能硬件)
  category_limit_dict_.insert(std::make_pair("电脑", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("家电", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("手机", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("智能硬件", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("留学", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("研究生考试", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));

  // 根据类别限制评测结果增加(二级分类:港股 美股 外汇 贵金属 保险)
  category_limit_dict_.insert(std::make_pair("港股", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("美股", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("外汇", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("贵金属", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("保险", CategoryLimitType::ONLY_BASED_SEED));

  // 根据体育类评测结果增加类别限制(二级分类:nba 国际足球)
  category_limit_dict_.insert(std::make_pair("nba", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("国际足球", CategoryLimitType::ONLY_BASED_SEED));

  // 根据类别限制评测结果增加(一级分类:职场)
  category_limit_dict_.insert(std::make_pair("职场", CategoryLimitType::ONLY_BASED_SEED));

  category_limit_dict_.insert(std::make_pair("股票", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("理财", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("期货", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("动漫", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("中国军情", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("互联网", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("债券", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("基金", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("音乐", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("健康", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("美食", CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("育儿", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("美文", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("搞笑", CategoryLimitType::ONLY_BASED_SEED));
  category_limit_dict_.insert(std::make_pair("社会", CategoryLimitType::RELAX_RECALL_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("国内", CategoryLimitType::RELAX_RECALL_FROM_TITLE));
  category_limit_dict_.insert(std::make_pair("教育", CategoryLimitType::RELAX_RECALL_FROM_TITLE));

  VLOG(1) << "category_limit_dict size:" << category_limit_dict_.size();
  return (category_limit_dict_.size() > 0 ) ? true : false;
}

CategoryLimitType RegionRecognition::SearchCategoryLimit(const std::string &category) {
  auto it = category_limit_dict_.find(category);
  if (it != category_limit_dict_.end()) {
    VLOG(1) << "category_limit_dict size:" << category_limit_dict_.size()
            << ",category:" << category
            << ",category_limit:" << it->second;
    return it->second;
  } else {
    VLOG(1) << "category_limit_dict size:" << category_limit_dict_.size()
            << ",category:" << category
            << ",category_limit:" << CategoryLimitType::NONE;
    return CategoryLimitType::NONE;
  }
}

bool RegionRecognition::SearchCategoryBlack(const std::string &region, const std::string &category) {
  auto category_black_dict = reco::GlobalDataIns::instance().GetRegionCateBlackDict();
  auto it = category_black_dict->find(region);
  if (it != category_black_dict->end()) {
    auto it_tmp = it->second.begin();
    for (;it_tmp != it->second.end();it_tmp++) {
      if (*it_tmp == category)
        return true;
    }
  }
  return false;
}

bool RegionRecognition::LoadLocalWordList() {
  local_word_dict_.insert("我省");
  local_word_dict_.insert("我市");
  local_word_dict_.insert("我县");
  local_word_dict_.insert("我州");
  local_word_dict_.insert("本省");
  local_word_dict_.insert("本市");
  local_word_dict_.insert("本县");
  local_word_dict_.insert("本州");
  local_word_dict_.insert("全省");
  local_word_dict_.insert("全市");
  local_word_dict_.insert("全县");
  local_word_dict_.insert("全州");
  local_word_dict_.insert("该省");
  local_word_dict_.insert("该市");
  local_word_dict_.insert("该县");
  local_word_dict_.insert("该州");
  local_word_dict_.insert("我区");
  local_word_dict_.insert("本区");
  local_word_dict_.insert("全区");
  local_word_dict_.insert("该区");
  return local_word_dict_.size() > 0;
}

bool RegionRecognition::LoadAmbiguousSuffixWordList() {
  ambiguous_suffix_word_dict_.insert("街");   // added by xumaoxing
  ambiguous_suffix_word_dict_.insert("路");
  ambiguous_suffix_word_dict_.insert("南路");
  ambiguous_suffix_word_dict_.insert("北路");
  ambiguous_suffix_word_dict_.insert("西路");
  ambiguous_suffix_word_dict_.insert("东路");
  ambiguous_suffix_word_dict_.insert("中路");
  ambiguous_suffix_word_dict_.insert("路段");
  ambiguous_suffix_word_dict_.insert("路南");
  ambiguous_suffix_word_dict_.insert("路北");
  ambiguous_suffix_word_dict_.insert("路西");
  ambiguous_suffix_word_dict_.insert("路东");
  ambiguous_suffix_word_dict_.insert("路中");
  return ambiguous_suffix_word_dict_.size() > 0;
}

bool RegionRecognition::SearchAllBlackTerms(const std::string &str, int str_len,
                                     std::vector<BlackTermInfo>* black_terms) {
  CHECK(black_terms);
  auto black_dict = reco::GlobalDataIns::instance().GetRegionBlackDict();
  for (auto it = black_dict->begin(); it != black_dict->end(); ++it) {
    int index = 0;
    int src_len = (int)(*it).size();
    while (index + src_len <= str_len) {
      int pos = str.find(*it, index);
      if (pos == -1) {
        break;
      } else {
        black_terms->push_back(BlackTermInfo(*it, pos, pos + src_len));
        index = pos + 1;
      }
    }
  }
  return black_terms->size() >= 1;
}

bool RegionRecognition::SearchSourceContentBlackTerms(const std::string &str) {
  for (auto it = source_content_black_dict_.begin(); it != source_content_black_dict_.end(); ++it) {
    if (str.find(*it) != std::string::npos)
      return true;
  }
  return false;
}

bool RegionRecognition::SearchTitleBlackLimitTerms(const std::string& content,
                                                   int title_len,
                                                   const nlp::term::TermContainer& container) {
  auto black_limit_dict = reco::GlobalDataIns::instance().GetRegionBlackLimitDict();
  // 收集符合要求词性及实体的词
  for (int i = 0; i < container.basic_term_num(); ++i) {
    const nlp::term::TermInfo& info = container.basic_term_info(i);
    if ((int)info.end > title_len) {
      break;
    }
    std::string place = info.term(content).as_string();

    if (black_limit_dict->find(place) != black_limit_dict->end()) {
      return true;
    }
  }
  return false;
}

bool RegionRecognition::LoadDict(const std::string &reco_region_data_dir) {
  // 加载地域词典
  mutex_.Lock();
  if (!is_dict_init_) {
    std::string region_file_new = reco_region_data_dir + "/" + kRegionFile;
    CHECK(reco::common::RegionSearcher::instance().Load(region_file_new))
        << "load RegionSearcher failed !!! dict_name:" << region_file_new;
    LOG(INFO) << "load RegionSearcher successfully !!! dict_name:" << region_file_new;

    CHECK(LoadSourceCntnBlackList()) << "load SouceCntn Black List failed !!!";
    LOG(INFO) << "load Region Black List successfully !!!";

    CHECK(LoadCategoryLimitList())
        << "load Region Category Limit List failed !!!";
    LOG(INFO) << "load Region Category Limit List successfully";

    CHECK(LoadLocalWordList()) << "load Local Word List failed !!!";
    LOG(INFO) << "load Local Word List successfully";

    CHECK(LoadAmbiguousSuffixWordList()) << "load Ambiguous Suffix Word List failed !!!";
    LOG(INFO) << "load Ambiguous Suffix Word List successfully";

    std::string travel_poi_file = reco_region_data_dir + "/" + kTravelPOIFile;
    CHECK(LoadTravelPOIDict(travel_poi_file)) << "load travel poi file failed !!!";
    LOG(INFO) << "load travel poi file successfully";
  }


  is_dict_init_ = true;
  mutex_.Unlock();
  return true;
}

bool RegionRecognition::LoadTravelPOIDict(const std::string &file_path) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    return false;
  }

  std::vector<std::string> fields;
  for (size_t i = 0; i < lines.size(); ++i) {
    fields.clear();
    base::SplitString(lines[i], "\t", &fields);
    if (fields.size() < 2) {
      continue;
    }

    travel_poi_vector_.push_back(fields[0]);
    travel_poi_atm_.TrieInsert(fields[0], travel_poi_vector_.size()-1);

    travel_poi_reg_dict_.insert(std::make_pair(fields[0], fields[1]));
  }

  travel_poi_atm_.AutomationBuild();

  return true;
}

void RegionRecognition::FindTravelPOI(const std::string &buf, std::vector<std::string> *poi_names) {
  CHECK(poi_names);
  poi_names->clear();

  VLOG(1) << "to find travel poi in: " << buf;

  std::vector<int> ans;
  travel_poi_atm_.TrieFind(buf, &ans);

  for (size_t i = 0; i < ans.size(); ++i) {
    if (ans[i] < 0 || ans[i] >= int(travel_poi_vector_.size())) {
      continue;
    }
    poi_names->push_back(travel_poi_vector_[ans[i]]);
    VLOG(1) << "found travel poi: " << travel_poi_vector_[ans[i]];
  }

  return;
}

void RegionRecognition::ExtractTravelPOIFromTitle(const std::string &title, std::vector<PlaceInfo>* place_info_list) {
  CHECK(place_info_list);
  place_info_list->clear();

  std::vector<std::string> poi_names;
  FindTravelPOI(title, &poi_names);

  for (size_t i = 0; i < poi_names.size(); ++i) {
    PlaceInfo p_info;
    p_info.place = poi_names[i];
    p_info.place_tag = "travel_poi";
    p_info.is_from_title = true;
    p_info.entity_index = -1;
    place_info_list->push_back(p_info);
    VLOG(1) << "extract_travel_poi:" << p_info.place
            << ",is_from_title:" << p_info.is_from_title;
  }

  return;
}

bool RegionRecognition::LoadSourceCntnBlackList() {
  source_content_black_dict_.insert("股票");
  source_content_black_dict_.insert("证券");
  source_content_black_dict_.insert("篮球");
  source_content_black_dict_.insert("足球");
  source_content_black_dict_.insert("军事");
  source_content_black_dict_.insert("基金");
  source_content_black_dict_.insert("债券");
  source_content_black_dict_.insert("理财");
  source_content_black_dict_.insert("期货");
  source_content_black_dict_.insert("黄金");
  source_content_black_dict_.insert("全球财富");
  source_content_black_dict_.insert("股市");
  // source_content_black_dict_.insert("环球网国际");

  return source_content_black_dict_.size() > 0;
}

bool RegionRecognition::ExtractRegionFromRawitem(const reco::ItemIdentity& item_identity,
                                                 const std::string& source,
                                                 const std::string& orig_source,
                                                 const std::string& spider_region,
                                                 const std::string& content,
                                                 int title_len,
                                                 const nlp::term::TermContainer& container,
                                                 RecoItem* reco_item) {
  CHECK(reco_item);
  std::vector<reco::common::RegionInfo> region_list;
  reco::common::GaodeRegionInfo reg_info;
  bool ret = ExtractRegionFromRawitem(item_identity, source, orig_source, spider_region,
                                      content, title_len, container, reco_item, &region_list, &reg_info);
  VLOG(1) << reco_item->identity().item_id() << ":reco_item region:" << reco_item->region();
  // 地域识别为空,且 title 中包含本地关键词,设置 expire_time 来限制下发( 9380217679696506111 )
  VLOG(1) << reco_item->identity().item_id() << ":reco_item expire_time1:" << reco_item->expire_time();
  if (!reco_item->has_region() || reco_item->region().empty()) {
    std::string title = content.substr(0, title_len);
    if (HaveLocalWord(title)) {
      reco_item->set_expire_time("1970-01-01 06:19:00");
    }
  }
  VLOG(1) << reco_item->identity().item_id() << ":reco_item expire_time2:" << reco_item->expire_time();
  return ret;
}

int RegionRecognition::RegionMatch(const std::string &raw_region, const std::string &extract_region) {
  int match = 0;
  if (raw_region == "")
    return match;
  bool is_raw_as_a_province =
        reco::common::RegionSearcher::instance().IsShengFenCode(raw_region);
  bool is_raw_as_a_special_province =
        reco::common::RegionSearcher::instance().IsSpecialShengFenCode(raw_region);
  if (!extract_region.empty()) {
    bool is_as_a_province =
        reco::common::RegionSearcher::instance().IsShengFenCode(extract_region);
    bool is_as_a_special_province =
        reco::common::RegionSearcher::instance().IsSpecialShengFenCode(extract_region);
    if (is_raw_as_a_province && !is_raw_as_a_special_province) {
      if (is_as_a_province && !is_as_a_special_province) {
        if (raw_region == extract_region) {
          match = 4;
        } else {
          match = 1;
        }
      } else {
        const std::string& province_code =
            reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(extract_region);
        if (raw_region == province_code) {
          match = 2;
        } else {
          match = 1;
        }
      }
    } else {
      if (is_as_a_province && !is_as_a_special_province) {
        const std::string& province_code =
            reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(raw_region);
        if (extract_region == province_code) {
          match = 3;
        } else {
          match = 1;
        }
      } else {
        if (extract_region == raw_region) {
          match = 5;
        } else {
          match = 1;
        }
      }
    }
  }
  return match;
}

bool RegionRecognition::FilterRegion(const bool &is_from_title,
                                     const std::vector<reco::common::RegionInfo> &region_list,
                                     std::string *region) {
  CHECK(region);
  // 地名多余一个时，检查地名和省份词是否同时出现，如果同时出现，把省份词去掉
  std::vector<std::string> region_id_list, region_id_from_title_list;
  bool title_has_middle_or_high = false;
  if (region_list.size() == 1) {
    if (is_from_title && !region_list[0].is_from_title) {
      region->assign("");
    } else {
      region->assign(region_list[0].reg.code);
    }
  } else {
    for (size_t i = 0; i < region_list.size(); ++i) {
      if (is_from_title) {
        if (!region_list[i].is_from_title) continue;
      }
      bool duplicate = false;
      bool duplicate_in_title = false;
      std::string region_id_i = region_list[i].reg.code;
      if (reco::common::RegionSearcher::instance().IsShengFenCode(region_id_i)) {
        for (size_t j = 0; j < region_list.size(); ++j) {
          if (i == j) continue;
          if (is_from_title) {
            if (!region_list[j].is_from_title) continue;
          }
          std::string region_id_j = region_list[j].reg.code;
          std::string province_code =
             reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(region_id_j);
          if (region_id_i == province_code) {
            duplicate = true;
            if (region_list[i].is_from_title &&
                region_list[j].is_from_title)
              duplicate_in_title = true;
          }
        }
      }
      if (!duplicate_in_title) {
        if (region_list[i].is_from_title) {
          if (region_list[i].reliability == reco::common::RegionRel::MIDDLE_CREDIBLE ||
              region_list[i].reliability == reco::common::RegionRel::HIGH_CREDIBLE)
            title_has_middle_or_high = true;
          region_id_from_title_list.push_back(region_id_i);
        }
      }
      if (!duplicate) {
        region_id_list.push_back(region_id_i);
      }
    }
    if (region_id_list.size() > 3) {
      region->assign(base::JoinStrings(region_id_from_title_list, ";"));
    } else if (title_has_middle_or_high) {
      region->assign(base::JoinStrings(region_id_from_title_list, ";"));
    } else {
      region->assign(base::JoinStrings(region_id_list, ";"));
    }
  }
  return true;
}

bool RegionRecognition::FilterRegion(const std::vector<size_t> &region_index_list,
                                     const std::vector<reco::common::RegionInfo> &region_list,
                                     std::string *region) {
  CHECK(region);
  // 地名多余一个时，检查地名和省份词是否同时出现，如果同时出现，把省份词去掉
  std::vector<std::string> region_id_list, region_id_from_title_list;
  bool title_has_middle_or_high = false;
  if (region_index_list.size() == 1) {
    region->assign(region_list[region_index_list[0]].reg.code);
    // filter_region_list->push_back(region_list[region_index_list[0]]);
  } else {
    for (size_t i = 0; i < region_index_list.size(); ++i) {
      bool duplicate = false;
      bool duplicate_in_title = false;
      std::string region_id_i = region_list[region_index_list[i]].reg.code;
      if (reco::common::RegionSearcher::instance().IsShengFenCode(region_id_i)) {
        for (size_t j = 0; j < region_index_list.size(); ++j) {
          if (i == j) continue;
          std::string region_id_j = region_list[region_index_list[j]].reg.code;
          std::string province_code =
             reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(region_id_j);
          if (region_id_i == province_code) {
            duplicate = true;
            if (region_list[region_index_list[i]].is_from_title &&
                region_list[region_index_list[j]].is_from_title)
              duplicate_in_title = true;
          }
        }
      }
      if (!duplicate_in_title) {
        if (region_list[region_index_list[i]].is_from_title) {
          if (region_list[region_index_list[i]].reliability == reco::common::RegionRel::MIDDLE_CREDIBLE ||
              region_list[region_index_list[i]].reliability == reco::common::RegionRel::HIGH_CREDIBLE)
            title_has_middle_or_high = true;
          region_id_from_title_list.push_back(region_id_i);
        }
      }
      if (!duplicate) {
        region_id_list.push_back(region_id_i);
      }
      VLOG(1) << "region_debug: region_id_i:" << region_id_i
              << ",duplicate:" << duplicate
              << ",duplicate_in_title:" << duplicate_in_title
              << ",region_id_list.size:" << region_id_list.size()
              << ",region_id_from_title_list.size:" << region_id_from_title_list.size()
              << ",title_has_middle_or_high:" << title_has_middle_or_high;
    }
    if (region_id_list.size() > 3) {
      region->assign(base::JoinStrings(region_id_from_title_list, ";"));
    } else if (title_has_middle_or_high) {
      region->assign(base::JoinStrings(region_id_from_title_list, ";"));
    } else {
      region->assign(base::JoinStrings(region_id_list, ";"));
    }
  }
  return true;
}

bool RegionRecognition::IsNotLocal(const std::string& title) {
  if (title.find("全国") != std::string::npos
      || title.find("我国") != std::string::npos) {
    return true;
  }
  return false;
}

bool RegionRecognition::IsLocalSource(const std::string& source) {
  auto local_source_dict = reco::GlobalDataIns::instance().GetRegionLocalSourceDict();
  if (local_source_dict->find(source) != local_source_dict->end()) {
    return true;
  }
  if (source.find("地方新闻") != std::string::npos
      || source.find("_本地") != std::string::npos) {
    return true;
  }
  return false;
}

bool RegionRecognition::HaveLocalWord(const std::string &content) {
  for (auto it = local_word_dict_.begin(); it != local_word_dict_.end(); it++) {
    if (*it == "本市" && content.find("资本市场") != std::string::npos) continue;
    if (content.find(*it) != std::string::npos) return true;
  }
  return false;
}

// 由于种子源映射的地域 code 有些会去 0 ,如: 010 变为 10 ,处理时需考虑
void RegionRecognition::RefineRawRegion(const std::string &spider_region, std::string *refine_region) {
  CHECK(refine_region);
  if (!spider_region.empty()) {
    if (spider_region.length() < 4 && spider_region[0] != '0') {
      refine_region->assign("0" + spider_region);
    } else {
      refine_region->assign(spider_region);
    }
  }
}

bool RegionRecognition::ExtractRegionFromRawitem(const reco::ItemIdentity& item_identity,
                                                 const std::string& source,
                                                 const std::string& orig_source,
                                                 const std::string& spider_region,
                                                 const std::string& content,
                                                 int title_len,
                                                 const nlp::term::TermContainer& container,
                                                 RecoItem* reco_item,
                                                 std::vector<reco::common::RegionInfo> *region_list,
                                                 reco::common::GaodeRegionInfo * reg_info) {
  CHECK(reco_item && region_list && reg_info);

  std::vector<BlackTermInfo> content_region_black_terms;
  SearchAllBlackTerms(content, content.length(), &content_region_black_terms);

  bool category_match = false;
  bool have_seed = false;
  bool have_local_word = false;
  VLOG(1) << "region_debug:" << "category_size:" << reco_item->category_size();

  if (!spider_region.empty()) {
    have_seed = true;
  }

  if (IsLocalSource(source) || IsLocalSource(orig_source)) {
    have_seed = true;
  }

  if (HaveLocalWord(content)) have_local_word = true;

  std::string title = content.substr(0, title_len);
  if (!have_seed && !have_local_word && IsNotLocal(title)) return false;

  // 类别限制，以二级分类为准
  auto category_limit_tag = reco::common::CategoryLimitType::NONE;
  for (int i = 0; i < reco_item->category_size(); ++i) {
    auto category_limit_tag_tmp = SearchCategoryLimit(reco_item->category(i));
    VLOG(1) << "region_debug:" << "category:" << reco_item->category(i)
            << "category_limit_tag_tmp:" << category_limit_tag_tmp;
    if (category_limit_tag_tmp != reco::common::CategoryLimitType::NONE) {
      category_limit_tag = category_limit_tag_tmp;
    }
  }
  if (category_limit_tag == reco::common::CategoryLimitType::ONLY_FROM_TITLE
      || (!have_seed
          && !have_local_word
          && category_limit_tag == reco::common::CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE)) {
    category_match = true;
  }

  // 如果 title 中包含限制黑名单词，不做地域识别
  if (spider_region.empty()) {
    if (category_limit_tag != reco::common::CategoryLimitType::RELAX_RECALL_FROM_TITLE
        && SearchTitleBlackLimitTerms(content, title_len, container)) {
      return false;
    }
  }

  // 匹配指定类别或某些类别无种子源映射，地域只从 title 中抽取
  ExtractRegion(source, orig_source, spider_region, content, title_len, container, category_match, reco_item,
                &content_region_black_terms, region_list);
  VLOG(1) << "region_debug:" << " item_id: " << item_identity.item_id()
          << " region_list size:" << region_list->size();

  // raw_item 有 region 字段，根据 raw_region 与高德地域、自身地域（从 title 或 title + 正文中抽取的）
  // 匹配情况，做市替换为省或不变或置空或置换为高德或置换为自身可信的。
  if (!spider_region.empty()) {
    // 与高德匹配情况：0-高德缺失地域，1-不匹配，2-与高德为省市关系匹配且 raw_region 为省，
    // 3-与高德为省市关系匹配且 raw_region 为市，4-与高德省匹配，5-与高德市匹配
    int match_with_gaode = 0;
    // 与自身匹配情况：0-自身缺失地域，1-不匹配，2-与自身为省市关系匹配且 raw_region 为省，
    // 3-与自身为省市关系匹配且 raw_region 为市，4-与自身省匹配，5-与自身市匹配
    std::vector<int> v_match_with_self;
    std::vector<size_t> v_match_with_self_index;
    std::vector<size_t> v_conflict_with_self_index;
    bool match_has_high_credible = false;
    bool conflict_has_high_credible = false;
    int match_2_high_credible_index = -1;
    int match_2_num = 0;
    bool can_match = false;
    bool can_match_is_from_title = false;
    bool conflict_is_from_title = false;
    std::string raw_region = "";
    RefineRawRegion(spider_region, &raw_region);
    reco_item->set_region(raw_region);
    if (reg_info->confidence < 0.4) {
      match_with_gaode = 0;
    } else {
      match_with_gaode = RegionMatch(raw_region, reg_info->city_adcode);
    }

    bool category_match = false;
    if (category_limit_tag == reco::common::CategoryLimitType::RELAX_RECALL_FROM_TITLE) {
      category_match = true;
    }
    for (size_t i = 0; i < (*region_list).size(); ++i) {
      std::string region_id = (*region_list)[i].reg.code;
      int match_with_self = RegionMatch(raw_region, region_id);
      if (match_with_self > 1) {
        can_match = true;
        if ((*region_list)[i].is_from_title) {
          can_match_is_from_title = true;
        }
      }
      if (!(*region_list)[i].is_from_title) {
        VLOG(1) << "region_debug:" << "region_list size:" << region_list->size()
                << ",category_match:" << category_match << ",place:" << (*region_list)[0].place;
        if (!((*region_list)[i].reliability == reco::common::RegionRel::HIGH_CREDIBLE
            || (*region_list)[i].reliability == reco::common::RegionRel::MIDDLE_CREDIBLE
            || (region_list->size() == 1 && category_match))) {
          continue;
        }
      }
      if (match_with_self > 1) {
        v_match_with_self.push_back(match_with_self);
        v_match_with_self_index.push_back(i);
        if ((*region_list)[i].reliability == reco::common::RegionRel::HIGH_CREDIBLE) {
          match_has_high_credible = true;
          if (match_with_self == 2) {
            match_2_high_credible_index = i;
          }
        }
        if (match_with_self == 2) {
          match_2_num += 1;
        }
      } else if (match_with_self == 1) {
        if ((*region_list)[i].reliability == reco::common::RegionRel::HIGH_CREDIBLE) {
          conflict_has_high_credible = true;
          v_conflict_with_self_index.push_back(i);
          if ((*region_list)[i].is_from_title)
            conflict_is_from_title = true;
        } else if ((*region_list)[i].reliability == reco::common::RegionRel::MIDDLE_CREDIBLE) {
          v_conflict_with_self_index.push_back(i);
          if ((*region_list)[i].is_from_title)
            conflict_is_from_title = true;
        }
      }
    }
    VLOG(1) << "region_debug:" << " raw region not null: "
            << " item_id: " << item_identity.item_id() << "match_with_gaode:"
            << match_with_gaode << " v_match_with_self size:" << v_match_with_self.size()
            << " v_conflict_with_self_index size:" << v_conflict_with_self_index.size()
            << " match_has_high_credible:" << match_has_high_credible
            << " conflict_has_high_credible:" << conflict_has_high_credible
            << " match_2_num:" << match_2_num;

    // 结合 raw_region 与高德和自身匹配情况，生成最终 region
    if (match_with_gaode > 1 && v_match_with_self.size() > 0) {
      // raw_region 为省，高德识别为市且自身识别为市的个数为 1 且为高可信
      // 或自身与高德识别相同且 raw_region 与自身 match 个数为 1，把 raw_region 置为市
      if (match_with_gaode == 2 && match_2_num == 1) {
        if (match_2_high_credible_index >= 0) {
          reco_item->set_region((*region_list)[match_2_high_credible_index].reg.code);
        } else if (v_match_with_self.size() == 1
                   && reg_info->city_adcode == (*region_list)[v_match_with_self_index[0]].reg.code) {
          reco_item->set_region((*region_list)[v_match_with_self_index[0]].reg.code);
        }
      }
    } else if (match_with_gaode > 1 && v_match_with_self.size() == 0) {
      if (conflict_has_high_credible) {
        reco_item->set_region("");
      }
    } else if (match_with_gaode <= 1 && v_match_with_self.size() == 0) {
      // 包含本地关键词或为本地源新闻降低地域识别条件（如：9993749049742647217 9954747297168281462）
      // 只包含种子源但无地名且无本地关键词，地域置为空(如:9554057835032290383)
      VLOG(1) << "have_seed:" << have_seed
              << ", have_local_word:" << have_local_word
              << ", can_match:" << can_match
              << ", can_match_is_from_title:" << can_match_is_from_title
              << ", category_match:" << category_match
              << ", region_list size:" << region_list->size();
      if (!have_seed && !have_local_word) {
        reco_item->set_region("");
      } else if (!can_match && region_list->size() > 0) {
        reco_item->set_region("");
      } else if (region_list->size() == 0 && !have_local_word) {
        reco_item->set_region("");
      } else if (!can_match && !have_local_word && !category_match) {
        reco_item->set_region("");
      } else if (!category_match && !can_match_is_from_title) {
        reco_item->set_region("");
      } else if (conflict_is_from_title && !can_match_is_from_title) {
        // 种子源映射地域和来自标题的地域(中高可信)冲突,把地域置空,
        // 当成无种子源映射地域处理(如: 906600997296678177 )
        reco_item->set_region("");
      }
    } else {
      // 种子源映射地域和来自标题的地域(中高可信)冲突,把地域置空,
      // 当成无种子源映射地域处理(如: 10806774099381471436 )
      if (conflict_is_from_title && !can_match_is_from_title) {
        reco_item->set_region("");
      } else if (match_2_num == 1) {
        if ((match_2_high_credible_index >= 0 && v_match_with_self.size() == 1)
            || (match_2_high_credible_index >= 0
                && (*region_list)[match_2_high_credible_index].is_from_title)) {
          reco_item->set_region((*region_list)[match_2_high_credible_index].reg.code);
        } else if (v_match_with_self_index.size() == 1
                   && (*region_list)[v_match_with_self_index[0]].is_from_title) {
          reco_item->set_region((*region_list)[v_match_with_self_index[0]].reg.code);
        }
      }
    }

    // 过滤基于种子源识别地域太多的问题
    if (reco_item->has_region() && !reco_item->region().empty() && !have_local_word) {
      VLOG(1) << "region_debug: filter region multi, reco_region:" << reco_item->region()
              << ", have_local_word:" << have_local_word
              << ", region_list_size:" << region_list->size();
      if (category_limit_tag !=
          reco::common::CategoryLimitType::RELAX_RECALL_FROM_TITLE) {
        if (region_list->size() >= 5) {
          reco_item->set_region("");
        }
      } else {
        if (region_list->size() >= 6) {
          reco_item->set_region("");
        }
      }
    }

    VLOG(1) << "region_debug: after filter region multi, reco_region:" << reco_item->region();
    FilterRegion(reco_item, region_list);

    VLOG(1) << "region_debug: after filter region mill, reco_region:" << reco_item->region();

    // 根据 reco_item 中的 region 字段更新 region_list
    if (reco_item->has_region() && !reco_item->region().empty()) {
      std::vector<std::string> strings, regions_from_title;
      base::SplitString(reco_item->region(), ";", &strings);
      for (auto it = region_list->begin(); it != region_list->end(); it++) {
        for (auto it_temp = strings.begin(); it_temp != strings.end(); it_temp++) {
          if (*it_temp == it->reg.code) {
            it->selected = true;
            it->place_tag = "news_source";
            if (it->is_from_title) {
              regions_from_title.push_back(*it_temp);
            }
          }
        }
      }
      reco_item->set_region_from_title(base::JoinStrings(regions_from_title, ";"));
    }
  }

  // reco_item 中的 region 字段为空时，结合高德和自身匹配情况，生成最终 region
  if (!reco_item->has_region() || reco_item->region().empty()) {
    if ((*region_list).empty()) {
      VLOG(1) << "no region candidate from self, item_id:" << item_identity.item_id();
      return false;
    }
    // 股票,理财,期货,动漫等类别不做地域识别
    if (category_limit_tag == reco::common::CategoryLimitType::ONLY_BASED_SEED) {
      return false;
    }
    if (SearchSourceContentBlackTerms(reco_item->source())) {
      return false;
    }

    std::vector<int> v_match_with_self;
    std::vector<size_t> v_match_with_self_index;
    std::vector<size_t> v_conflict_with_self_index;
    std::vector<size_t> v_conflict_from_title_with_self_index;
    bool match_has_high_credible = false;
    bool conflict_has_high_credible = false;
    int match_2_high_credible_index = -1;
    int match_2_index = -1;
    int match_2_num = 0;
    std::string same_province = "";
    bool have_imp_city = false;
    bool have_from_title = false;

    for (size_t i = 0; i < (*region_list).size(); ++i) {
      std::string region_id = (*region_list)[i].reg.code;
      if (reco::common::RegionSearcher::instance().IsMainCityByCode(region_id)) {
        have_imp_city = true;
      }
      if ((*region_list)[i].is_from_title) {
        have_from_title = true;
      }

      if (i == 0) {
        same_province = reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(region_id);
      } else {
        if (same_province.empty() ||
            same_province != reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(region_id))
          same_province = "";
      }
      if (!(*region_list)[i].is_from_title) {
        if (!((*region_list)[i].reliability == reco::common::RegionRel::HIGH_CREDIBLE
            || (*region_list)[i].reliability == reco::common::RegionRel::MIDDLE_CREDIBLE))
          continue;
      }

      int match_with_self;
      if (reg_info->confidence < 0.4) {
        match_with_self = 0;
      } else {
        match_with_self = RegionMatch(reg_info->city_adcode, region_id);
      }
      if (match_with_self > 1) {
        v_match_with_self.push_back(match_with_self);
        v_match_with_self_index.push_back(i);
        if ((*region_list)[i].reliability == reco::common::RegionRel::HIGH_CREDIBLE) {
          match_has_high_credible = true;
          if (match_with_self == 2)
            match_2_high_credible_index = i;
        }
        if (match_with_self == 2) {
          match_2_index = i;
          match_2_num += 1;
        }
      } else {
        if ((*region_list)[i].reliability == reco::common::RegionRel::HIGH_CREDIBLE) {
          conflict_has_high_credible = true;
          v_conflict_with_self_index.push_back(i);
          if ((*region_list)[i].is_from_title)
            v_conflict_from_title_with_self_index.push_back(i);
        } else if ((*region_list)[i].reliability == reco::common::RegionRel::MIDDLE_CREDIBLE) {
          if ((*region_list)[i].is_from_title)
            v_conflict_from_title_with_self_index.push_back(i);
          v_conflict_with_self_index.push_back(i);
        }
      }
    }
    VLOG(1) << "region_debug:" << " raw region null: "
            << " item_id: " << item_identity.item_id()
            << " v_match_with_self size:" << v_match_with_self.size()
            << " v_conflict_with_self_index size:" << v_conflict_with_self_index.size()
            << " match_has_high_credible:" << match_has_high_credible
            << " conflict_has_high_credible:" << conflict_has_high_credible
            << " match_2_num:" << match_2_num;
    if (v_match_with_self.size() > 0) {
      if (match_2_num > 1) {
        reco_item->set_region(reg_info->city_adcode);
      } else if (match_2_num == 1 && match_2_high_credible_index >= 0) {
        reco_item->set_region((*region_list)[match_2_high_credible_index].reg.code);
      } else if (match_2_num == 1 && !(*region_list)[match_2_index].is_from_title) {
        reco_item->set_region(reg_info->city_adcode);
      } else {
        std::string region;
        std::vector<size_t> v_tmp;
        v_tmp.insert(v_tmp.end(), v_match_with_self_index.begin(), v_match_with_self_index.end());
        v_tmp.insert(v_tmp.end(), v_conflict_from_title_with_self_index.begin(),
                     v_conflict_from_title_with_self_index.end());
        FilterRegion(v_tmp, *region_list, &region);
        reco_item->set_region(region);
      }
    } else {
      if (v_conflict_with_self_index.size() > 0) {
        std::string region;
        // 识别地域太多，只要 title 中的高可信
        VLOG(1) << "region_debug:" << "raw region null && all conflict:"
                << " v_conflict_from_title_with_self_index.size:"
                << v_conflict_from_title_with_self_index.size()
                << " v_conflict_with_self_index.size:"
                << v_conflict_with_self_index.size()
                << " region list size:" << region_list->size()
                << " same_province:" << same_province;
        if (region_list->size() > 3) {
          FilterRegion(v_conflict_from_title_with_self_index, *region_list, &region);
          /*
          if (v_conflict_from_title_with_self_index.size() > 0) {
            FilterRegion(v_conflict_from_title_with_self_index, *region_list, &region);
          } else {
            FilterRegion(v_conflict_with_self_index, *region_list, &region);
          }
          */
          if (region.empty() && !same_province.empty()) {
            region = same_province;
          }
        } else {
          FilterRegion(v_conflict_with_self_index, *region_list, &region);
        }
        reco_item->set_region(region);
      } else if (reg_info->confidence >= 0.6 && !reg_info->city_adcode.empty()) {
        VLOG(1) << "region_debug: assign gaode region " << reg_info->confidence << ","
                << reg_info->city_adcode;
        reco_item->set_region(reg_info->city_adcode);
      } else {
        // 1.限定类别选择来自 title 的低可信
        // 2.包含本地关键词或为本地源新闻降低地域识别条件（如：9993749049742647217 9954747297168281462）
        bool category_match1 = false;
        bool category_match2 = false;
        bool category_match3 = false;
        if (category_limit_tag == reco::common::CategoryLimitType::RELAX_RECALL_FROM_TITLE) {
          category_match1 = true;
        }
        if (category_limit_tag == reco::common::CategoryLimitType::RELAX_RECALL_FROM_FINAL_TITLE) {
          category_match2 = true;
        }
        if (category_limit_tag == reco::common::CategoryLimitType::ONLY_FROM_TITLE
            || category_limit_tag == reco::common::CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE
            || category_limit_tag == reco::common::CategoryLimitType::ONLY_BASED_SEED) {
          category_match3 = true;
        }
        VLOG(1) << "have_imp_city:" << have_imp_city
                << ", have_from_title:" << have_from_title
                << ", category_match1:" << category_match1
                << ", category_match2:" << category_match2
                << ", have_seed:" << have_seed
                << ", have_local_word:" << have_local_word
                << ", same_province:" << same_province
                << ", region_list size:" << region_list->size();
        if ((!have_imp_city || have_from_title)
            && (category_match1 || category_match2)
            && !category_match3
            && (have_seed || have_local_word)
            && (region_list->size() == 1 || (region_list->size() == 2 && !same_province.empty()))) {
          std::string region;
          FilterRegion(false, *region_list, &region);
          reco_item->set_region(region);
        } else if (category_match1) {
          std::string region;
          FilterRegion(true, *region_list, &region);
          reco_item->set_region(region);
        } else if (region_list->size() == 1
                   || (region_list->size() == 2 && !same_province.empty())
                   || (have_seed || have_local_word)) {
          std::string region;
          FilterRegion(true, *region_list, &region);
          reco_item->set_region(region);
        }
      }
    }

    VLOG(1) << "region_debug:" << "start update region";

    VLOG(1) << "region_debug: before filter region mill, reco_region:" << reco_item->region();
    FilterRegion(reco_item, region_list);

    VLOG(1) << "region_debug: after filter region mill, reco_region:" << reco_item->region();
    // 根据 reco_item 中的 region 字段更新 region_list
    if (reco_item->has_region() && !reco_item->region().empty()) {
      std::vector<std::string> strings, regions_from_title, regions;
      bool category_match1 = false;
      bool category_match2 = false;
      bool category_match3 = false;
      std::string imp_city_code = "";
      base::SplitString(reco_item->region(), ";", &strings);

      // 重要城市识别到的地域和种子源冲突,选择来自 title 的
      bool imp_city_has_conflict = false;
      for (auto it = strings.begin(); it != strings.end(); it++) {
        if (reco::common::RegionSearcher::instance().IsMainCityByCode(*it)) {
          imp_city_code = *it;
          break;
        }
      }
      if (!imp_city_code.empty() && !spider_region.empty()) {
        // 由于种子源映射的地域 code 有些会去 0 ,如: 010 变为 10 ,处理时需考虑
        std::string raw_region;
        RefineRawRegion(spider_region, &raw_region);
        if (imp_city_code != raw_region) {
          imp_city_has_conflict = true;
        }
      }

      if (category_limit_tag == reco::common::CategoryLimitType::RELAX_RECALL_FROM_FINAL_TITLE) {
        category_match1 = true;
      } else if (category_limit_tag == reco::common::CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE) {
        category_match2 = true;
      } else if (category_limit_tag == reco::common::CategoryLimitType::ONLY_FROM_TITLE
                 || category_limit_tag == reco::common::CategoryLimitType::SEED_MISS_ONLY_FROM_TITLE
                 || category_limit_tag == reco::common::CategoryLimitType::ONLY_BASED_SEED) {
        category_match3 = true;
      }

      std::unordered_set<std::string> s_temp;
      for (auto it = region_list->begin(); it != region_list->end(); it++) {
        for (auto it_temp = strings.begin(); it_temp != strings.end(); it_temp++) {
          if (*it_temp == it->reg.code
              || reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(*it_temp)
              == it->reg.code
              || reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(it->reg.code)
              == *it_temp) {
            it->selected = true;
            if (it->is_from_title) {
              if (s_temp.find(*it_temp) == s_temp.end()) {
                regions_from_title.push_back(*it_temp);
                s_temp.insert(*it_temp);
              }
            }
          }
        }
      }

      // 特殊类别只要从 title 中抽取的地域
      // 自媒体源只从 title 中抽取地域(含有种子源映射的不做特殊处理)
      // 12215795597636012979 (设置 size 条件为了解决类似 badcase )
      VLOG(1) << "region_debug:" << "category_match1:" << category_match1
              << ",category_match2:" << category_match2
              << ",category_match3:" << category_match3
              << ",have_seed:" << have_seed
              << ",have_local_word:" << have_local_word
              << ",region size:" << strings.size()
              << ",region from title size:" << regions_from_title.size();
      if (category_match2 || category_match3) {
        reco_item->set_region(base::JoinStrings(regions_from_title, ";"));
      } else if (category_match1 && strings.size() > 1) {
        reco_item->set_region(base::JoinStrings(regions_from_title, ";"));
      } else if (category_match1 && !have_seed && !have_local_word && region_list->size() > 1) {
        reco_item->set_region(base::JoinStrings(regions_from_title, ";"));
      } else if (FLAGS_wemedia_only_from_title && reco_item->source().find("cp_wemedia_uc_") != std::string::npos) {
        reco_item->set_region(base::JoinStrings(regions_from_title, ";"));
      } else if (imp_city_has_conflict) {
        reco_item->set_region(base::JoinStrings(regions_from_title, ";"));
      }
      reco_item->set_region_from_title(base::JoinStrings(regions_from_title, ";"));
    }
  }

  bool is_manual = item_identity.has_manual() ? item_identity.manual() : false;
  // NOTE: 由于 leaf server 中，对运营文章的地域过滤策略不走 region 的判断，运营文章不设置 channel
  // set channel
  if (reco_item->has_region() && !reco_item->region().empty() && !is_manual &&
      (item_identity.type() == reco::kNews || item_identity.type() == reco::kReading)) {
    bool need_fill_channel = true;
    for (int i = 0; i < (int)reco_item->channel_id_size(); ++i) {
      if (reco_item->channel_id(i) == reco::common::kLocalChannelId) {
        need_fill_channel = false;
        break;
      }
    }
    if (need_fill_channel) {
      reco_item->add_channel_id(reco::common::kLocalChannelId);
    }
  }

  return true;
}

void RegionRecognition::FilterRegion(RecoItem *reco_item,
                                     std::vector<reco::common::RegionInfo> *region_list) {
  CHECK(reco_item && region_list);
  if (reco_item->has_region() && !reco_item->region().empty()) {
    // 对于军事或国际新闻，如果提取出来的地域是北京的话，则干掉
    bool is_mil = false;
    bool is_inland = false;
    for (int i = 0; i < reco_item->category_size(); ++i) {
      if (reco_item->category(i) == "军事" || reco_item->category(i) == "国际") {
        is_mil = true;
        break;
      } else if (reco_item->category(i) == "国内") {
        is_inland = true;
        break;
      }
    }
    std::vector<std::string> strings;
    base::SplitString(reco_item->region(), ";", &strings);
    if (is_mil) {
      for (auto it = strings.begin(); it != strings.end(); it++) {
        if (*it == "010") {
          VLOG(1) << "region filter by mil and beijing !!! item_id:" << reco_item->identity().item_id();
          reco_item->set_region("");
          return;
        }
      }
    }
    // “国内”类下面如果同时出现“北京”和“台湾”、“香港”、“澳门”，把“北京”地域丢弃
    if (is_inland) {
      for (auto it = strings.begin(); it != strings.end(); it++) {
        if (*it == "010") {
          for (auto it_temp = region_list->begin(); it_temp != region_list->end(); it_temp++) {
            if (it_temp->reg.code == "1886" || it_temp->reg.code == "1852" || it_temp->reg.code == "1853") {
              VLOG(1) << "region filter by inland and beijing !!! item_id:"
                      << reco_item->identity().item_id();
              reco_item->set_region("");
              return;
            }
          }
        }
      }
    }
  }
}

bool RegionRecognition::ExtractRegionFromString(const std::string& source,
                                                const std::string& orig_source,
                                                const std::string& spider_region,
                                                const std::string& content,
                                                int title_len,
                                                const nlp::term::TermContainer& container,
                                                std::vector<reco::common::RegionInfo> *region_list) {
  CHECK(region_list);
  region_list->clear();
  std::vector<reco::common::RegionInfo> region_list_tmp;
  // 找出 title 中的地域黑名单词条
  std::vector<BlackTermInfo> title_region_black_terms;
  SearchAllBlackTerms(content, title_len, &title_region_black_terms);

  RecoItem *reco_item;
  reco_item = NULL;
  ExtractRegion(source, orig_source, spider_region, content, title_len, container, false, reco_item,
                &title_region_black_terms, &region_list_tmp);

  // 地名多余一个时，检查地名和省份词是否同时出现，如果同时出现，把省份词去掉
  if (region_list_tmp.size() == 1) {
    region_list->push_back(region_list_tmp[0]);
  } else {
    for (size_t i = 0; i < region_list_tmp.size(); ++i) {
      bool duplicate = false;
      std::string region_id_i = region_list_tmp[i].reg.code;
      if (reco::common::RegionSearcher::instance().IsShengFenCode(region_id_i)) {
        for (size_t j = 0; j < region_list_tmp.size(); ++j) {
          if (j == i)
            continue;
          std::string region_id_j = region_list_tmp[j].reg.code;
          std::string province_code =
                reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(region_id_j);
          if (region_id_i == province_code) {
            duplicate = true;
          }
        }
      }
      if (!duplicate) {
        region_list->push_back(region_list_tmp[i]);
      }
    }
  }
  return true;
}

bool RegionRecognition::IsAmbiguousPlace(const std::string& place,
                                         const std::string& next_place) {
  // 城市 + 路上/路口 等，枚举有限
  // if (ambiguous_suffix_word_dict_.find(next_place) != ambiguous_suffix_word_dict_.end()) {
  if (base::StartsWith(next_place, "路", false) || base::StartsWith(next_place, "街", false)) {
    std::vector<reco::common::RegionNode> reg;
    reco::common::RegionSearcher::instance().SearchRegion(place, &reg);
    for (size_t i = 0; i < reg.size(); i++) {
      if (reg[i].region_type == "city" ||
          reg[i].region_type == "province" ||
          reg[i].region_type == "district") {
        VLOG(1) << "ambiguous place:" << place << "," << next_place;
        return true;
      }
    }
  }
  return false;
}

bool RegionRecognition::ExtractRegion(const std::string& source, const std::string& orig_source,
                                      const std::string& spider_region,
                                      const std::string& content, int title_len,
                                      const nlp::term::TermContainer& container,
                                      bool from_title, RecoItem *reco_item,
                                      std::vector<BlackTermInfo>* region_black_terms,
                                      std::vector<RegionInfo> *region_list) {
  CHECK(region_list);
  region_list->clear();

  std::vector<PlaceInfo> place_info_list;
  std::vector<PlaceInfo> entity_place_info_list;
  std::vector<PlaceInfo> travel_poi_place_info_list;
  std::unordered_set<int32> not_valid_entity_index_list;

  VLOG(1) << "start extract region!!!";

  // 收集符合要求词性及实体的词
  for (int i = 0; i < container.basic_term_num(); ++i) {
    const nlp::term::TermInfo& info = container.basic_term_info(i);
    if (from_title && (int)info.end > title_len) {
      break;
    }
    if ((int)info.end > (int)content.length()) {
      break;
    }
    bool is_from_title = true;
    if ((int)info.end > title_len) {
      is_from_title = false;
    }
    std::string place = info.term(content).as_string();
    VLOG(1) << "place: " << place << ", i: " << i;

    if (place.length() < 6) continue;

    if (i < (container.basic_term_num() - 1)) {
      const nlp::term::TermInfo& next_info = container.basic_term_info(i + 1);
      std::string next_place = next_info.term(content).as_string();
      if (IsAmbiguousPlace(place, next_place)) {
        if (info.entity_index != -1) {
          not_valid_entity_index_list.insert(info.entity_index);
        }
        continue;
      }
    }
    // 0-null, 1-entity_place, 2-entity_org, 3-entity_web, 4-entity_other;
    int entity_tag = 0;
    // 0-other, 1-place
    int pos_tag = 0;
    VLOG(1) << "region_debug: term:" << info.term(content).as_string()
            << ", postag:" << (int)info.enum_postag;
    if (info.entity_index != -1) {
      const nlp::term::TermInfo& info_entity = container.entity_term_info(info.entity_index);
      VLOG(1) << "region_debug: term:" << info.term(content).as_string() << ", entity:"
              << (int)info_entity.enum_entity;
      if ((int)info_entity.end <= (int)content.length()) {
        if (info_entity.has_entity_type(nlp::term::kEntityPlace)) {
          entity_tag = 1;
        } else if (info_entity.has_entity_type(nlp::term::kOrganization)) {
          entity_tag = 2;
        } else if (info_entity.has_entity_type(nlp::term::kWebSite)
                   || info_entity.has_entity_type(nlp::term::kBook)
                   || info_entity.has_entity_type(nlp::term::kEntityOther)
                   || info_entity.has_entity_type(nlp::term::kUnkownEntity)) {
          entity_tag = 3;
        } else {
          entity_tag = 4;
        }
      }
      VLOG(1) << "region_debug:" << " entity_tag:" << entity_tag;
    }
    if (!(info.is_postag(nlp::term::kPlace)
        || info.is_postag(nlp::term::kNoun))) {
      if (entity_tag == 0 || entity_tag == 4) continue;
    }
    VLOG(1) << "region_debug1:" << place;
    if (info.is_postag(nlp::term::kPlace)) {
      pos_tag = 1;
    }
    // 判断地名是否转义：如果地名包含在一个品牌实体中
    // 例如: 北京现代第九代索纳塔混动版 年底上市
    //       上海大众 2015 款帕萨特对比 增加 5 项配置
    bool zhuanyi = false;
    if (entity_tag == 4)
      zhuanyi = true;
    // 检查是否命中黑名单词条
    if (!zhuanyi) {
      for (int j = 0; j < (int)region_black_terms->size(); ++j) {
        if ((int)info.begin >= (*region_black_terms)[j].begin
            && (int)info.end <= (*region_black_terms)[j].end) {
          zhuanyi = true;
          break;
        }
      }
    }
    // 检查是否命中类别黑名单
    if (!zhuanyi) {
      if (reco_item != NULL) {
        for (int j = 0; j < reco_item->category_size(); ++j) {
          std::string category = reco_item->category(j);
          if (SearchCategoryBlack(place, category)) {
            zhuanyi = true;
            break;
          }
        }
      }
    }
    VLOG(1) << "region_debug2:" << place;
    if (!zhuanyi) {
      std::string place_tag = "";
      if (pos_tag == 1) {
        if (entity_tag == 0) {
          place_tag = "place;not_entity";
        } else if (entity_tag == 1) {
          place_tag = "place;entity_place";
        } else if (entity_tag == 2) {
          place_tag = "place;entity_org";
        } else {
          place_tag = "place;entity_web";
        }
      } else {
        if (entity_tag == 0) {
          place_tag = "not_place;not_entity";
        } else if (entity_tag == 1) {
          place_tag = "not_place;entity_place";
        } else if (entity_tag == 2) {
          place_tag = "not_place;entity_org";
        } else {
          place_tag = "not_place;entity_web";
        }
      }
      VLOG(1) << "region_debug3:" << place;
      PlaceInfo p_info;
      p_info.place = place;
      p_info.place_tag = place_tag;
      p_info.is_from_title = is_from_title;
      p_info.entity_index = (int)info.entity_index;
      place_info_list.push_back(p_info);
    }
  }

  ExtractValidEntity(reco_item, content, title_len, container, region_black_terms,
                     from_title, not_valid_entity_index_list, &entity_place_info_list);

  // 只针对 旅游 类别做poi识别
  bool poi_category_ok = false;
  for (int i = 0; i < reco_item->category_size(); ++i) {
    std::string cate = reco_item->category(i);
    if (cate == "旅游") {
      poi_category_ok = true;
      break;
    }
  }
  if (poi_category_ok) {
    ExtractTravelPOIFromTitle(content.substr(0, title_len), &travel_poi_place_info_list);
  }

  VLOG(1) << "place_info_list size:" << place_info_list.size()
          << ", entity_place_info_list size():" << entity_place_info_list.size()
          << ", travel_poi_place_info_list size():" << travel_poi_place_info_list.size();

  // 类别限制，以二级分类为准
  auto category_limit_tag = reco::common::CategoryLimitType::NONE;
  for (int i = 0; i < reco_item->category_size(); ++i) {
    auto category_limit_tag_tmp = SearchCategoryLimit(reco_item->category(i));
    VLOG(1) << "region_debug:" << "category:" << reco_item->category(i)
            << "category_limit_tag_tmp:" << category_limit_tag_tmp;
    if (category_limit_tag_tmp != reco::common::CategoryLimitType::NONE) {
      category_limit_tag = category_limit_tag_tmp;
    }
  }

  // 获取这些地名词对应的编码，并拼接在一起
  SearchRegion(source, orig_source, spider_region,
               place_info_list, entity_place_info_list, travel_poi_place_info_list,
               region_list, category_limit_tag);
  return region_list->size() > 0 ? true : false;
}

bool RegionRecognition::ExtractValidEntity(RecoItem *reco_item, const std::string& content, int title_len,
                                           const nlp::term::TermContainer& container,
                                           const std::vector<BlackTermInfo>* region_black_terms,  // NOLINT
                                           bool from_title,
                                           std::unordered_set<int32>& not_valid_entity_index_list,
                                           std::vector<PlaceInfo>* place_info_list) {
  CHECK(region_black_terms && place_info_list);
  place_info_list->clear();
  // 收集 kEntityPlace
  for (int i = 0; i < container.entity_term_num(); ++i) {
    const nlp::term::TermInfo& info = container.entity_term_info(i);
    VLOG(1) << "entity_term: " << info.term(content).as_string() << ", i: " << i;
    // 过滤从分词中判断出来的不可用实体，如淄博路，实体为淄博，不从其中识别地域
    if (not_valid_entity_index_list.find(i) != not_valid_entity_index_list.end()) {
      continue;
    }

    VLOG(1) << "extract_entity_place:" << info.term(content).as_string()
            << ", entity:" << (int)info.enum_entity
            << ", i:" << i;
    if (from_title && (int)info.end > title_len) {
      break;
    }
    if ((int)info.end > (int)content.length()) {
      break;
    }
    bool is_from_title = true;
    if ((int)info.end > title_len) {
      is_from_title = false;
    }
    std::string place = info.term(content).as_string();
    if (place.length() < 6)
      continue;
    if (!info.has_entity_type(nlp::term::kEntityPlace)) {
      continue;
    }
    bool zhuanyi = false;
    // 检查是否命中黑名单词条
    if (!zhuanyi) {
      for (int j = 0; j < (int)region_black_terms->size(); ++j) {
        if ((int)info.begin >= (*region_black_terms)[j].begin
            && (int)info.end <= (*region_black_terms)[j].end) {
          zhuanyi = true;
          break;
        }
      }
    }
    // 检查是否命中类别黑名单
    if (!zhuanyi) {
      if (reco_item != NULL) {
        for (int j = 0; j < reco_item->category_size(); ++j) {
          std::string category = reco_item->category(j);
          if (SearchCategoryBlack(place, category)) {
            zhuanyi = true;
            break;
          }
        }
      }
    }
    if (!zhuanyi) {
      PlaceInfo p_info;
      p_info.place = place;
      p_info.place_tag = "entity_place";
      p_info.is_from_title = is_from_title;
      p_info.entity_index = i;
      place_info_list->push_back(p_info);
      VLOG(1) << "extract_entity_place:" << p_info.place
              << ",is_from_title:" << p_info.is_from_title;
    }
  }

  return true;
}

bool RegionRecognition::SearchRegion(const std::string& source, const std::string& orig_source,
                                     const std::string& spider_region,
                                     const std::vector<PlaceInfo> &place_info_list,
                                     const std::vector<PlaceInfo> &entity_place_info_list,
                                     const std::vector<PlaceInfo> &travel_poi_place_info_list,
                                     std::vector<RegionInfo> *region_list,
                                     reco::common::CategoryLimitType &category_limit_tag) {
  CHECK(region_list);
  region_list->clear();

  std::unordered_map<std::string, std::vector<RegionInfo> > m_code_correspond_region_info;
  std::unordered_set<int> entity_indexs;
  for (size_t i = 0;i < entity_place_info_list.size(); i++) {
    std::vector<reco::common::RegionNode> reg;
    reco::common::RegionSearcher::instance().SearchRegion(entity_place_info_list[i].place, &reg);
    VLOG(1) << entity_place_info_list[i].place << ",reg_size:" << reg.size()
            << ",is_from_title:" << entity_place_info_list[i].is_from_title;
    if (reg.size() > 0) {
      entity_indexs.insert(entity_place_info_list[i].entity_index);
    }
    for (size_t j = 0;j < reg.size(); j++) {
      RegionInfo reg_info;
      reg_info.place = entity_place_info_list[i].place;
      reg_info.place_tag = entity_place_info_list[i].place_tag;
      reg_info.reg = reg[j];
      reg_info.is_from_title = entity_place_info_list[i].is_from_title;
      if (reg.size() > 1) {
        reg_info.exist_multi = true;
      } else {
        reg_info.exist_multi = false;
      }
      auto it = m_code_correspond_region_info.find(reg[j].code);
      if (it != m_code_correspond_region_info.end()) {
        it->second.push_back(reg_info);
      } else {
        std::vector<RegionInfo> v;
        v.push_back(reg_info);
        m_code_correspond_region_info.insert(make_pair(reg[j].code, v));
      }
    }
  }
  for (size_t i = 0;i < place_info_list.size(); i++) {
    if (place_info_list[i].entity_index != -1
        && entity_indexs.find(place_info_list[i].entity_index) != entity_indexs.end()) continue;
    std::vector<reco::common::RegionNode> reg;
    reco::common::RegionSearcher::instance().SearchRegion(place_info_list[i].place, &reg);
    VLOG(1) << place_info_list[i].place << ",reg_size:" << reg.size()
            << ",is_from_title:" << place_info_list[i].is_from_title;
    for (size_t j = 0; j < reg.size(); j++) {
      RegionInfo reg_info;
      reg_info.place = place_info_list[i].place;
      reg_info.place_tag = place_info_list[i].place_tag;
      reg_info.reg = reg[j];
      reg_info.is_from_title = place_info_list[i].is_from_title;
      if (reg.size() > 1) {
        reg_info.exist_multi = true;
      } else {
        reg_info.exist_multi = false;
      }
      auto it = m_code_correspond_region_info.find(reg[j].code);
      if (it != m_code_correspond_region_info.end()) {
        it->second.push_back(reg_info);
      } else {
        std::vector<RegionInfo> v;
        v.push_back(reg_info);
        m_code_correspond_region_info.insert(make_pair(reg[j].code, v));
      }
    }
  }

  for (size_t i = 0; i < travel_poi_place_info_list.size(); ++i) {
    VLOG(1) << travel_poi_place_info_list[i].place << ",is_from_title:" << travel_poi_place_info_list[i].is_from_title;
    auto it = travel_poi_reg_dict_.find(travel_poi_place_info_list[i].place);
    if (it == travel_poi_reg_dict_.end()) {
      continue;
    }
    VLOG(1) << travel_poi_place_info_list[i].place << ",city code:" << it->second;
    reco::common::RegionNode node;
    if (!reco::common::RegionSearcher::instance().SearchRegionInfo(it->second, &node)) {
      continue;
    }
    VLOG(1) << travel_poi_place_info_list[i].place << ",city name:" << node.city;

    RegionInfo reg_info;
    reg_info.place = travel_poi_place_info_list[i].place;
    reg_info.place_tag = travel_poi_place_info_list[i].place_tag;
    reg_info.reg = node;
    reg_info.is_from_title = travel_poi_place_info_list[i].is_from_title;
    reg_info.exist_multi = false;

    auto it2 = m_code_correspond_region_info.find(node.code);
    if (it2 != m_code_correspond_region_info.end()) {
      it2->second.push_back(reg_info);
    } else {
      std::vector<RegionInfo> v;
      v.push_back(reg_info);
      m_code_correspond_region_info.insert(std::make_pair(node.code, v));
    }
  }

  CompleteRegionReliability(source, orig_source, spider_region,
                            m_code_correspond_region_info, region_list, category_limit_tag);
  return true;
}

bool RegionRecognition::CompleteRegionReliability(
    const std::string& source, const std::string& orig_source, const std::string& spider_region,
    const std::unordered_map<std::string, std::vector<RegionInfo> >& m_code_correspond_region_info,
    std::vector<RegionInfo> *region_list, reco::common::CategoryLimitType &category_limit_tag) {
  CHECK(region_list);

  for (auto it = m_code_correspond_region_info.begin(); it != m_code_correspond_region_info.end(); it++) {
    VLOG(1) << it->first << ",place_size:" << it->second.size();
    RegionInfo reg_info;
    bool is_a_province = reco::common::RegionSearcher::instance().IsShengFenCode(it->first);
    bool is_a_special_province =
          reco::common::RegionSearcher::instance().IsSpecialShengFenCode(it->first);
    std::vector<std::string> v_tmp_place, v_tmp_place_tag;
    std::unordered_set<std::string> s_tmp_place;
    int province_reliability = 0;
    bool is_from_title = false;
    bool exist_multi = true;
    bool city_exist = false;
    bool is_main_city = reco::common::RegionSearcher::instance().IsMainCityByCode(it->first);
    if (is_a_province && !is_a_special_province) {
      for (auto it_tmp = m_code_correspond_region_info.begin();
           it_tmp != m_code_correspond_region_info.end(); it_tmp++) {
        bool is_a_province_tmp = reco::common::RegionSearcher::instance().IsShengFenCode(it_tmp->first);
        bool is_a_special_province_tmp =
          reco::common::RegionSearcher::instance().IsSpecialShengFenCode(it_tmp->first);
        if (is_a_province_tmp && !is_a_special_province_tmp)
          continue;
        std::string province_code_tmp =
            reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(it_tmp->first);
        if (it->first == province_code_tmp) {
          city_exist = true;
          break;
        }
      }
      for (auto it_tmp = it->second.begin(); it_tmp != it->second.end(); it_tmp++) {
        if (it_tmp->is_from_title)
          is_from_title = true;
        if (!it_tmp->exist_multi)
          exist_multi = false;
        if (s_tmp_place.find(it_tmp->place) == s_tmp_place.end()) {
          v_tmp_place.push_back(it_tmp->place);
          v_tmp_place_tag.push_back(it_tmp->place_tag + ";" + it_tmp->reg.region_type);
          s_tmp_place.insert(it_tmp->place);
        }
        if (province_reliability == 2)
          continue;
        if (!it_tmp->reg.region_is_short || it_tmp->place.length() >= 9) {
          if (!it_tmp->is_from_title && it->second.size() < 2) {
            province_reliability = 1;
          } else {
            province_reliability = 2;
          }
        } else if ((is_from_title && it->second.size() >= 2) || it->second.size() >= 4) {
          province_reliability = 2;
        }
      }
      reg_info = it->second[0];
      if (province_reliability == 2) {
        reg_info.reliability = RegionRel::HIGH_CREDIBLE;
      } else if (city_exist) {
        reg_info.reliability = RegionRel::MIDDLE_CREDIBLE;
      } else if (is_from_title) {
        reg_info.reliability = RegionRel::MIDDLE_CREDIBLE;
      } else {
        reg_info.reliability = RegionRel::LOW_CREDIBLE;
      }
      reg_info.place = base::JoinStrings(v_tmp_place, "#");
      reg_info.place_tag = base::JoinStrings(v_tmp_place_tag, "#");
      reg_info.is_from_title = is_from_title;
      reg_info.exist_multi = exist_multi;
      region_list->push_back(reg_info);
    } else {
      bool province_exist = false;
      // 0--null, 1--short, 2--long
      int city_reliability = 0;
      int poi_reliability = 0;
      bool is_from_title = false;
      bool exist_multi = true;
      // 像北京的东城、西城,其他城市也会有这种叫法,如果东城、西城没有北京其他无歧义词
      // 出现辅助,该地名不能被识别为北京(歧义词可信度为 30 40 50)
      bool is_ambiguous = true;
      std::string province_code = "";
      if (!is_a_special_province) {
        province_code =
            reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(it->first);
        auto it_tmp = m_code_correspond_region_info.find(province_code);
        if (it_tmp != m_code_correspond_region_info.end())
          province_exist = true;
      }
      for (auto it_tmp = it->second.begin(); it_tmp != it->second.end(); it_tmp++) {
        // 判断地名词是否有歧义,可信度 50 (对于社会、国内、教育类可放开),
        // 如果源中含有地名支持,当做无歧义处理.
        VLOG(1) << it_tmp->place << " " << it_tmp->reg.reliability;
        if (it_tmp->reg.reliability != 30
            && !(it_tmp->reg.reliability == 50
                 && (category_limit_tag != reco::common::CategoryLimitType::RELAX_RECALL_FROM_TITLE
                     || m_code_correspond_region_info.size() >= 3))) {
          is_ambiguous = false;
        } else if (it_tmp->reg.reliability == 50) {
          if (orig_source.find(it_tmp->place) != std::string::npos
                  || orig_source.find(it_tmp->reg.region) != std::string::npos) {
            is_ambiguous = false;
          } else if (source.find(it_tmp->place) != std::string::npos
                         || source.find(it_tmp->reg.region) != std::string::npos) {
            is_ambiguous = false;
          }
        }

        if (it_tmp->is_from_title)
          is_from_title = true;
        if (!it_tmp->exist_multi)
          exist_multi = false;
        if (s_tmp_place.find(it_tmp->place) == s_tmp_place.end()) {
          v_tmp_place.push_back(it_tmp->place);
          v_tmp_place_tag.push_back(it_tmp->place_tag + ";" + it_tmp->reg.region_type);
          s_tmp_place.insert(it_tmp->place);
        }
        if (city_reliability == 2 && poi_reliability == 2)
          continue;
        if (it_tmp->reg.region_type == "city") {
          if (city_reliability == 2)
            continue;
          if (it_tmp->exist_multi) {
            city_reliability = 1;
          } else if (it_tmp->reg.region_is_short && it_tmp->place.length() < 9) {
            if (it_tmp->place.length() >= 6 && it->second.size() >= 4) {
              city_reliability = 2;
            } else if (it_tmp->is_from_title && it->second.size() >=2) {
              city_reliability = 2;
            } else {
              city_reliability = 1;
            }
          } else {
            // 地域非来自标题且重要城市地名频次小于 4 或 非重要城市地名频次小于 2
            // (地名是全称且只识别到一个地名除外)置低可信
            if (!it_tmp->is_from_title &&
                ((is_main_city && it->second.size() < 4) ||
                 (!is_main_city && (it->second.size() < 2 &&
                  !(!it_tmp->reg.region_is_short && m_code_correspond_region_info.size() == 1))))) {
              city_reliability = 1;
            } else {
              city_reliability = 2;
            }
          }
          // 西安 如果出现在标题中，city reliability -> 2
          if (it->first == "029" && it_tmp->is_from_title) {
            city_reliability = 2;
          }
        } else {
          if (poi_reliability == 2)
            continue;
          if (it_tmp->exist_multi) {
            poi_reliability = 1;
          } else if (it_tmp->reg.region_is_short && it_tmp->place.length() < 9) {
            if (it_tmp->place.length() >= 6 && it->second.size() >= 4) {
              poi_reliability = 2;
            } else if (it_tmp->is_from_title && it->second.size() >= 2) {
              poi_reliability = 2;
            } else {
              poi_reliability = 1;
            }
          } else {
            if (!it_tmp->is_from_title &&
                ((is_main_city && it->second.size() < 4) || (!is_main_city && it->second.size() < 2))) {
              poi_reliability = 1;
            } else {
              poi_reliability = 2;
            }
          }
        }
      }
      reg_info = it->second[0];
      reg_info.place = base::JoinStrings(v_tmp_place, "#");
      reg_info.place_tag = base::JoinStrings(v_tmp_place_tag, "#");
      if (poi_reliability == 2 || city_reliability == 2) {
        reg_info.reliability = RegionRel::HIGH_CREDIBLE;
      } else if (poi_reliability == 1 && province_exist) {
        reg_info.reliability = RegionRel::MIDDLE_CREDIBLE;
      } else if (city_reliability == 1 && province_exist) {
        reg_info.reliability = RegionRel::MIDDLE_CREDIBLE;
      } else if (poi_reliability == 1 || city_reliability == 1) {
        reg_info.reliability = RegionRel::LOW_CREDIBLE;
      } else {
        reg_info.reliability = RegionRel::NOT_CREDIBLE;
      }
      reg_info.is_from_title = is_from_title;
      reg_info.exist_multi = exist_multi;
      VLOG(1) << exist_multi << " " << is_from_title << " " << reg_info.reliability << " " << is_ambiguous;
      // 可信度为 30 40 50 的歧义词无其他辅助,滤掉,(如: 8542435915760688184 中的东城)
      // city/district/poi 低可信且有歧义 place 过滤掉（如：西安区中的西安）
      if (!is_ambiguous) {
        if (!((city_reliability < 2 || poi_reliability < 2) && exist_multi
              && (reg_info.reliability == RegionRel::LOW_CREDIBLE
                  || reg_info.reliability == RegionRel::NOT_CREDIBLE))) {
          region_list->push_back(reg_info);
        } else {
          // 有歧义但是有种子源支撑,不需过滤(15638750092971045662)
          if (!spider_region.empty()) {
            std::string raw_region = "";
            RefineRawRegion(spider_region, &raw_region);
            if (raw_region == reg_info.reg.code
                || raw_region == province_code) {
              region_list->push_back(reg_info);
            }
          }
        }
      } else {
        if (!spider_region.empty()) {
          std::string raw_region = "";
          RefineRawRegion(spider_region, &raw_region);
          if (raw_region == reg_info.reg.code
              || raw_region == province_code) {
            region_list->push_back(reg_info);
          }
        }
      }
      VLOG(1) << "city_reliability:" << city_reliability << ",poi_reliability:"
              << poi_reliability << ",province_exist:" << province_exist
              << ",place_size:" << v_tmp_place.size()
              << ",place:" << reg_info.place
              << ",is_from_title:" << reg_info.is_from_title;
    }
  }
  return true;
}
}  // namespace common
}  // namespace reco
