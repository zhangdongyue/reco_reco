#pragma once

#include <string>
#include <vector>

#include "base/common/basic_types.h"
#include "base/thread/blocking_queue.h"
#include "net/rpc/rpc.h"

#include "reco/bizc/proto/item_handler.pb.h"

namespace reco {
class RawItemConvertor;
namespace itemhandler {

class ItemHandlerImpl : public ItemHandler {
 public:
  explicit ItemHandlerImpl(thread::BlockingQueue<RawItemConvertor*>* item_workers);
  virtual ~ItemHandlerImpl() {}

  virtual void registerFields(stumy::RpcController* controller,
                        const GetHandlerContextRequest* request,
                        ItemHandlerContext* response,
                        Closure* done);

  virtual void updateItem(stumy::RpcController* controller,
                          const ItemHandlerRequest* request,
                          ItemHandlerResponse* response,
                          Closure* done);
 private:
  google::protobuf::RepeatedPtrField<std::string> listening_fields_;
  google::protobuf::RepeatedPtrField<std::string> update_fields_;
  thread::BlockingQueue<RawItemConvertor*>* item_workers_;
  DISALLOW_COPY_AND_ASSIGN(ItemHandlerImpl);
};
}  // namespace convertor
}  // namespace reco
