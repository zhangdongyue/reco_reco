#include "reco/module/cdoc_convertor/server/cdoc_writer.h"

#include "ads_index/proto/index.pb.h"
#include "ads_index/api/public.h"
#include "reco/bizc/proto/item.pb.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/logging.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "reco/base/kafka_c/api_cc/producer.h"

DEFINE_int64_counter(convertor, cdoc_length_filter_count, 0, "");
DEFINE_int32(cdoc_max_length, 4 * 1024 * 1024, "cdoc max length");

namespace reco {
CDocWriter::CDocWriter(const std::string& kafka_brokers, const std::string& kafka_topic) {
  cdoc_producer_ = new reco::kafka::Producer(kafka_brokers, kafka_topic);
}

CDocWriter::~CDocWriter() {
  delete cdoc_producer_;
}

int CDocWriter::GenPartitionNum(const reco::ItemIdentity& identity) {
  if (!identity.producer().empty() && identity.producer() != "uc") {
    return kManualItemPartitionUpperBound - (identity.item_id() % kManualItemPartitionNum);
  } else if (identity.type() == reco::kPureVideo) {
    return kVideoItemPartitionUpperBound - (identity.item_id() % kVideoItemPartitionNum);
  } else {
    return kCommonItemPartitionUpperBound - (identity.item_id() % kCommonItemPartitionNum);
  }
}

bool CDocWriter::AddCDoc(const adsindexing::IndexDocInfo& cdoc, const ItemIdentity& identity,
                         std::string* err_msg) {
  reco::RecoCDoc reco_cdoc;
  std::string producer = identity.has_producer() ?
      identity.producer() : identity.app_token();
  uint64 item_id = identity.item_id();
  std::string item_id_str = base::Uint64ToString(item_id);
  std::string compressed_cdoc;
  if (!adsindexing::GetCompressionCDoc(cdoc, &compressed_cdoc)) {
    err_msg->append("failed to get compress cdoc, id=");
    err_msg->append(item_id_str);
    return false;
  }

  reco_cdoc.set_app_token(producer);
  reco_cdoc.set_cdoc(compressed_cdoc);
  std::string serialized_reco_cdoc;
  if (!reco_cdoc.SerializeToString(&serialized_reco_cdoc)) {
    err_msg->append("Failed to convert to RecoCDoc, id=");
    err_msg->append(item_id_str);
    return false;
  }

  if (static_cast<int>(serialized_reco_cdoc.size()) >= FLAGS_cdoc_max_length) {
    COUNTERS_convertor__cdoc_length_filter_count.Increase(1);
    err_msg->append("cdoc filter by length, id=");
    err_msg->append(item_id_str);
    return false;
  }

  int retry_num = 0;
  while (!cdoc_producer_->Produce(serialized_reco_cdoc, item_id_str, GenPartitionNum(identity))) {
    LOG(WARNING) << "failed to push to cdoc kafka, retry, item id:" << item_id_str;
    base::SleepForMilliseconds(10);
    if (retry_num++ > 3) {
      LOG(ERROR) << "failed to push to cdoc kafka, return, item id :" << item_id_str;
      return false;
    }
  }
  return true;
}
}

