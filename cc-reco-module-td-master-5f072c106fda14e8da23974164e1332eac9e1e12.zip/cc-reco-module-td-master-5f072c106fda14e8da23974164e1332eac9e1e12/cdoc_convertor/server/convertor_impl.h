#pragma once

#include <string>
#include <vector>
#include <set>

#include "base/thread/blocking_queue.h"
#include "base/common/basic_types.h"
#include "net/rpc/rpc.h"

#include "reco/bizc/proto/reco_convertor_server.pb.h"

namespace reco {
class RawItemConvertor;
class ItemCDocConvertor;
class CDocWriter;
class Ha3DocWriter;

namespace convertor {

class ConvertorImpl : public ConvertorService {
 public:
  ConvertorImpl(thread::BlockingQueue<RawItemConvertor*>* item_workers,
                thread::BlockingQueue<ItemCDocConvertor*>* cdoc_workers,
                thread::BlockingQueue<RawItemConvertor*>* extract_workers,
                CDocWriter* cdoc_producer, Ha3DocWriter* ha3doc_producer);

  virtual ~ConvertorImpl() {}

  virtual void validateItem(stumy::RpcController* controller,
                            const ValidateItemRequest* request,
                            ValidateItemResponse* response,
                            Closure* done);

  virtual void convertRecoItem(stumy::RpcController* controller,
                               const ConvertRecoItemRequest* request,
                               ConvertRecoItemResponse* response,
                               Closure* done);

  virtual void convertRecoItem2Ha3Doc(stumy::RpcController* controller,
                               const ConvertRecoItemRequest* request,
                               ConvertRecoItem2Ha3DocResponse* response,
                               Closure* done);

  virtual void extractFeature(stumy::RpcController* controller,
                              const ExtractFeatureRequest* request,
                              ExtractFeatureResponse* response,
                              Closure* done);

  virtual void pushRecoItemToCDocQueue(stumy::RpcController* controller,
                                       const PushRecoItemToCDocQueueRequest* request,
                                       PushRecoItemToCDocQueueResponse* response,
                                       Closure* done);
 private:
  void AddToDocQueue(std::string cdoc_str, uint64 item_id);

  std::set<std::string> cdoc_listening_field_set_;
  thread::BlockingQueue<RawItemConvertor*>* item_workers_;
  thread::BlockingQueue<ItemCDocConvertor*>* cdoc_workers_;
  thread::BlockingQueue<RawItemConvertor*>* extract_workers_;

  // NOTE(*): convertor server 保留了 push cdoc 到 kafka 队列
  CDocWriter* cdoc_writer_;

  // push ha3doc to swift
  Ha3DocWriter* ha3doc_writer_;

  DISALLOW_COPY_AND_ASSIGN(ConvertorImpl);
};
}  // namespace convertor
}  // namespace reco
