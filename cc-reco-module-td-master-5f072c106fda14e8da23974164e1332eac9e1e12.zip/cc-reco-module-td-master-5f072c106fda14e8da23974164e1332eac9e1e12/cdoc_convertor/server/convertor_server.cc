#include <string>
#include <vector>

#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "reco/module/cdoc_convertor/server/convertor_impl.h"
#include "reco/module/cdoc_convertor/server/item_handler_impl.h"
#include "reco/module/cdoc_convertor/server/cdoc_writer.h"
#include "reco/module/cdoc_convertor/server/ha3doc_writer.h"
#include "reco/module/cdoc_convertor/convertor/raw_item_convertor.h"
#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/base/dict_manager/reload_service_impl.h"
#include "reco/ml/feature/global_data/global_data.h"

#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "net/rpc/rpc.h"

#include "serving_base/utility/signal.h"
#include "net/counter/export.h"
#include "serving_base/utility/timer.h"

// 这个可执行程序完成 2 个功能：
// 1. 对外提供 raw item 转换 reco item 服务
// 2. 对外提供 reco item 转换 cdoc 服务
DEFINE_int32(port, 20021, "the listening port on which the serving application listens");
DEFINE_int32(thread_num, 8, "rpc thread num");
DEFINE_int32(reload_port, 30021, "port for reload service");
DEFINE_int32(reload_thread_num, 8, "reload service thread num");

DEFINE_int32(cdoc_convertor_thread_num, 4, "number of thread for converting reco item to cdoc");
DEFINE_int32(reco_item_convertor_thread_num, 4, "number of thread for converting raw item to reco item");

DEFINE_string(hbase_table, "tb_reco_item", "hbase table");

DEFINE_string(item_kafka_brokers, "127.0.0.1:9092", "item_kafka_broker");
DEFINE_string(cdoc_item_kafka_topic, "test_cdoc_item", "");
DEFINE_string(ha3doc_item_kafka_topic, "test_ha3doc_item", "ha3doc_item topic");

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "cdoc convertor server");
  serving_base::SignalCatcher::Initialize();

  net::counter::HttpCounterExport();

  serving_base::Timer timer;
  timer.Start();

  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited()) << "init hbase pool first";
  LOG(INFO) << "init habase time:" << timer.Interval();

  reco::GlobalDataIns::instance().Init();
  LOG(INFO) << "init convertor global data time:" << timer.Interval();

  reco::ml::GlobalDataIns::instance().Init();
  LOG(INFO) << "init ml global data time:" << timer.Interval();

  reco::redis::RedisCli* redis_cli_ = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);

  thread::BlockingQueue<reco::RawItemConvertor*>* item_workers =
      new thread::BlockingQueue<reco::RawItemConvertor*>();
  for (int i = 0; i < FLAGS_thread_num + FLAGS_reco_item_convertor_thread_num; ++i) {
    item_workers->Put(new reco::RawItemConvertor(FLAGS_hbase_table, redis_cli_));
  }
  LOG(INFO) << "init raw item convertor time:" << timer.Interval();

  thread::BlockingQueue<reco::ItemCDocConvertor*>* cdoc_workers =
      new thread::BlockingQueue<reco::ItemCDocConvertor*>();
  for (int i = 0; i < FLAGS_thread_num + FLAGS_cdoc_convertor_thread_num; ++i) {
    cdoc_workers->Put(new reco::ItemCDocConvertor());
  }
  LOG(INFO) << "init reco item convertor time:" << timer.Interval();

  thread::BlockingQueue<reco::RawItemConvertor*>* extract_workers =
      new thread::BlockingQueue<reco::RawItemConvertor*>();
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    extract_workers->Put(new reco::RawItemConvertor(FLAGS_hbase_table, redis_cli_));
  }
  LOG(INFO) << "init extractor time:" << timer.Interval();

  reco::CDocWriter* cdoc_writer = new reco::CDocWriter(FLAGS_item_kafka_brokers, FLAGS_cdoc_item_kafka_topic);
  reco::Ha3DocWriter* ha3doc_writer = new reco::Ha3DocWriter(FLAGS_item_kafka_brokers,
          FLAGS_ha3doc_item_kafka_topic);
  reco::convertor::ConvertorImpl convertor_service(item_workers, cdoc_workers,
          extract_workers, cdoc_writer, ha3doc_writer);
  reco::itemhandler::ItemHandlerImpl item_handler_service(item_workers);
  reco::dm::ReloadServiceImpl reload_service;

  net::rpc::RpcServer::Options opt;
  opt.port = FLAGS_port;
  opt.server_thread_num = FLAGS_thread_num;
  opt.pump_thread_num = 4;
  net::rpc::RpcServer *server = new net::rpc::RpcServer(opt);

  CHECK(server->ExportService(&convertor_service));
  CHECK(server->ExportService(&item_handler_service));
  CHECK(server->ExportService(&reload_service));

  server->Start();
  LOG(INFO) << "convertor server start, total start time:" << timer.Stop();
  ::google::FlushLogFiles(::google::INFO);

  // 初始化, 捕捉 kill 信号
  serving_base::SignalCatcher::WaitForSignal();

  server->Stop();
  delete server;

  while (!item_workers->Empty()) {
    auto c = item_workers->Take();
    delete c;
  }
  delete item_workers;

  while (!cdoc_workers->Empty()) {
    auto c = cdoc_workers->Take();
    delete c;
  }
  delete cdoc_workers;

  delete cdoc_writer;
  delete ha3doc_writer;

  delete redis_cli_;

  LOG(INFO) << "convertor server safe stop.";
  ::google::FlushLogFiles(::google::INFO);

  return 0;
}
