#include "reco/module/cdoc_convertor/server/item_handler_impl.h"

#include <google/protobuf/message.h>
#include <google/protobuf/descriptor.h>
#include <string>
#include <set>

#include "base/strings/string_printf.h"
#include "ads_index/proto/index.pb.h"
#include "ads_index/api/public.h"
#include "serving_base/utility/timer.h"
#include "base/thread/blocking_queue.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/module/cdoc_convertor/convertor/raw_item_convertor.h"
#include "reco/module/cdoc_convertor/convertor/util/convertor_util.h"

DEFINE_int64_counter(convertor, update_item_request_count, 0, "");
DEFINE_int64_counter(convertor, update_item_response_time, 0, "");

DEFINE_int64_counter(convertor, conv_reco_item_num, 0, "update reco item succ num");
DEFINE_int64_counter(convertor, conv_reco_failed_num, 0, "update reco item fail num");
namespace reco {
namespace itemhandler {
ItemHandlerImpl::ItemHandlerImpl(thread::BlockingQueue<RawItemConvertor*>* item_workers) {
  // TODO(*): 看是否需要区分 raw-》reco，  reco-》cdoc 的 listening fields
  // 这里写的其实是并集
  const std::vector<std::string>& kListeningFields = RawItemConvertor::kListeningFields;

  const std::vector<std::string>& kUpdateFields = RawItemConvertor::kUpdateFields;

  reco::RecoItem reco_item;  // for field valid only
  const google::protobuf::Descriptor* descriptor = reco_item.GetDescriptor();
  CHECK_NOTNULL(descriptor);

  std::set<std::string> dedup;
  for (size_t i = 0; i < kListeningFields.size(); ++i) {
    const std::string& field = kListeningFields[i];
    if (dedup.find(field) != dedup.end()) {
      continue;
    }
    CHECK_NOTNULL(descriptor->FindFieldByLowercaseName(field));
    *(listening_fields_.Add()) = field;
    dedup.insert(field);
    LOG(INFO) << "I will listen change of field [" << field << "]";
  }

  dedup.clear();
  for (size_t i = 0; i < kUpdateFields.size(); ++i) {
    const std::string& field = kUpdateFields[i];
    if (dedup.find(field) != dedup.end()) {
      continue;
    }
    CHECK_NOTNULL(descriptor->FindFieldByLowercaseName(field));
    *(update_fields_.Add()) = field;
    dedup.insert(field);
    LOG(INFO) << "I will update field [" << field << "]";
  }

  item_workers_ = item_workers;
}

void ItemHandlerImpl::registerFields(stumy::RpcController* controller,
                                     const GetHandlerContextRequest* request,
                                     ItemHandlerContext* response,
                                     Closure* done) {
  ScopedClosure scoped_done(done);
  response->mutable_listening_fields()->CopyFrom(listening_fields_);
  response->mutable_update_fields()->CopyFrom(update_fields_);
}

void ItemHandlerImpl::updateItem(stumy::RpcController* controller,
                                 const ItemHandlerRequest* request,
                                 ItemHandlerResponse* response,
                                 Closure* done) {
  COUNTERS_convertor__update_item_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_done(done);
  response->set_success(false);
  response->mutable_reco_item()->CopyFrom(request->reco_item());

  RawItemConvertor* item_convertor = item_workers_->Take();
  if (item_convertor == NULL) {
    LOG(WARNING) << "failed to get item worker";
    return;
  }

  std::vector<std::string> manual_fields;
  std::vector<RecoItem> child_items;
  RepeatedToVector(request->manual_set_fields(), &manual_fields);
  RepeatedToVector(request->child_items(), &child_items);
  bool suc = item_convertor->UpdateRecoItem(response->mutable_reco_item(), &manual_fields, &child_items);
  item_workers_->Put(item_convertor);
  if (!suc) {
    COUNTERS_convertor__conv_reco_failed_num.Increase(1);
    LOG(WARNING) << "failed to update reco item";
  } else {
    COUNTERS_convertor__conv_reco_item_num.Increase(1);
    response->set_success(true);

    LOG(INFO) << "DEBUG id:" << response->reco_item().identity().item_id()
              << " valid:" << response->reco_item().is_valid()
              << " expire time:" << response->reco_item().expire_time()
              << " offline setting:" << response->reco_item().offline_settings().Utf8DebugString()
              << " invalid setting:" << response->reco_item().invalid_settings().Utf8DebugString();
  }

  int64 cost_ms = timer.Stop() / 1000;
  LOG(INFO) << "done update item, reqest: " << request->reco_item().identity().item_id()
            << ", cost ms: " << cost_ms;
  COUNTERS_convertor__update_item_response_time.Increase(cost_ms);
  return;
}
}  // namespace itemhandler
}  // namespace reco
