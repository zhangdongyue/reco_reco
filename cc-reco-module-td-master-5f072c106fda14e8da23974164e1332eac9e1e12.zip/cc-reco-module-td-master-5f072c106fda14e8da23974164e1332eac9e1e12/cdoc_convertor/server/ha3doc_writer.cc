#include <map>
#include <string>
#include "reco/module/cdoc_convertor/server/ha3doc_writer.h"

#include "reco/bizc/proto/item.pb.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/logging.h"
#include "reco/base/kafka_c/api_cc/producer.h"
#include "base/common/sleep.h"

DEFINE_int32(push_ha3doc_kafka_retry_num, 3, "retry of  push ha3doc to kafka server");
DEFINE_int64_counter(convertor, ha3doc_length_filter_count, 0, "");
DEFINE_int32(ha3doc_max_length, 4 * 1024 * 1024, "ha3doc max length");

namespace reco {

    Ha3DocWriter::Ha3DocWriter(const std::string& kafka_brokers, const std::string& kafka_topic) {
        doc_producer_ = new reco::kafka::Producer(kafka_brokers, kafka_topic);
    }

    Ha3DocWriter::~Ha3DocWriter() {
        delete doc_producer_;
    }

    /*TODO:
      因为http方式走swift gateway太慢，100~200ms响应时间
      改为写kafka， 7u环境下用一个程序同步kafka到ha3 swift .
     */
    bool Ha3DocWriter::AddHa3doc(const std::string & doc,
            const ItemIdentity& identity, std::string* err_msg) {
        int retry_num = 0;

        uint64 item_id = identity.item_id();
        std::string item_id_str = base::Uint64ToString(item_id);
        if (static_cast<int>(doc.size()) >= FLAGS_ha3doc_max_length) {
            COUNTERS_convertor__ha3doc_length_filter_count.Increase(1);
            err_msg->append("ha3doc filter by length, id=");
            err_msg->append(item_id_str);
            return false;
        }

        while (!doc_producer_->Produce(doc, item_id_str)) {
            LOG(WARNING) << "failed to push to ha3doc kafka, item id:"
                << item_id_str << " retry_num=" << retry_num;
            base::SleepForSeconds(10);
            if (retry_num++ > FLAGS_push_ha3doc_kafka_retry_num) {
                LOG(ERROR) << "failed to push to ha3doc kafka, item id :" << item_id_str;
                return false;
            }
        }

        return true;
    }
}

