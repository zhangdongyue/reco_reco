#include "reco/module/cdoc_convertor/server/convertor_impl.h"

#include <google/protobuf/descriptor.h>
#include <string>

#include "base/strings/string_printf.h"
#include "base/thread/blocking_queue.h"
#include "ads_index/api/public.h"
#include "ads_index/proto/index.pb.h"
#include "serving_base/utility/timer.h"
#include "reco/module/cdoc_convertor/convertor/raw_item_convertor.h"
#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"
#include "reco/module/cdoc_convertor/convertor/util/convertor_util.h"
#include "reco/module/cdoc_convertor/server/cdoc_writer.h"
#include "reco/module/cdoc_convertor/server/ha3doc_writer.h"

DEFINE_int64_counter(convertor, conv_raw_request_count, 0, "");
DEFINE_int64_counter(convertor, conv_raw_response_time, 0, "");
DEFINE_int64_counter(convertor, conv_reco_request_count, 0, "");
DEFINE_int64_counter(convertor, conv_reco_response_time, 0, "");
DEFINE_int64_counter(convertor, ext_fea_request_count, 0, "");
DEFINE_int64_counter(convertor, ext_fea_response_time, 0, "");
DEFINE_int64_counter(convertor, push_cdoc_request_count, 0, "");
DEFINE_int64_counter(convertor, push_cdoc_response_time, 0, "");

DEFINE_int64_counter(convertor, conv_cdoc_failed_num, 0, "failed num, reco_item-->cdoc");
DEFINE_int64_counter(convertor, kafka_cdoc_produce_num, 0, "");

DEFINE_int64_counter(convertor, ha3doc_failed_num, 0, "failed num, reco_item-->ha3doc");
DEFINE_int64_counter(convertor, ha3doc_produce_num, 0, "");


namespace reco {
namespace convertor {
ConvertorImpl::ConvertorImpl(thread::BlockingQueue<RawItemConvertor*>* item_workers,
                             thread::BlockingQueue<ItemCDocConvertor*>* cdoc_workers,
                             thread::BlockingQueue<RawItemConvertor*>* extract_workers,
                             CDocWriter* cdoc_writer, Ha3DocWriter* ha3_writer) {
  item_workers_ = item_workers;
  cdoc_workers_ = cdoc_workers;
  extract_workers_ = extract_workers;
  cdoc_writer_ = cdoc_writer;
  ha3doc_writer_ = ha3_writer;

  const std::vector<std::string>& kListeningFields = ItemCDocConvertor::GetListeningFields();
  reco::RecoItem reco_item;  // for field valid only
  const google::protobuf::Descriptor* descriptor = reco_item.GetDescriptor();
  CHECK_NOTNULL(descriptor);
  for (size_t i = 0; i < kListeningFields.size(); ++i) {
    const std::string& field = kListeningFields[i];
    CHECK_NOTNULL(descriptor->FindFieldByLowercaseName(field));
    cdoc_listening_field_set_.insert(field);
    LOG(INFO) << "I will listen change of field [" << field << "]";
  }
}

void ConvertorImpl::validateItem(stumy::RpcController* controller,
                                 const ValidateItemRequest *request,
                                 ValidateItemResponse *response,
                                 Closure *done) {
  ScopedClosure scoped_done(done);

  bool success = true;
  std::string msg;
  for (int i = 0; i < request->item_size(); ++i) {
    ValidateItemResult* result = response->add_result();
    result->set_is_valid(true);
  }
  response->set_success(success);
  CHECK_EQ(request->item_size(), response->result_size());
}

void ConvertorImpl::convertRecoItem2Ha3Doc(stumy::RpcController* controller,
                                    const ConvertRecoItemRequest *request,
                                    ConvertRecoItem2Ha3DocResponse *response,
                                    Closure *done) {
  COUNTERS_convertor__conv_reco_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_done(done);
  LOG(INFO) << "recv reqest: " << request->reco_item().identity().item_id();
  response->set_success(false);

  bool suc = true;
  std::string err_msg;
  const reco::RecoItem& reco_item = request->reco_item();

  ItemCDocConvertor* cdoc_convertor = cdoc_workers_->Take();
  std::string doc="";
  if (!cdoc_convertor->ConvertToHa3Doc(reco_item, &doc)) {
    LOG(ERROR) << base::StringPrintf("convert ha3doc failed! item_id=%lu",
                                     reco_item.identity().item_id());
    err_msg += "convert to ha3 doc string failed;";
    suc = false;
  } else {
    response->set_res(doc);
  }
  cdoc_workers_->Put(cdoc_convertor);

  response->set_success(suc);
  response->set_err_msg(err_msg);

  int64 cost_ms = timer.Stop() / 1000;
  LOG(INFO) << "done conver reco item 2 ha3doc, reqest: " << request->reco_item().identity().item_id()
            << ", cost ms: " << cost_ms;
  COUNTERS_convertor__conv_reco_response_time.Increase(cost_ms);
  return;
}

void ConvertorImpl::convertRecoItem(stumy::RpcController* controller,
                                    const ConvertRecoItemRequest *request,
                                    ConvertRecoItemResponse *response,
                                    Closure *done) {
  COUNTERS_convertor__conv_reco_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_done(done);
  LOG(INFO) << "recv reqest: " << request->reco_item().identity().item_id();
  response->set_success(false);

  bool suc = true;
  std::string err_msg;
  const reco::RecoItem& reco_item = request->reco_item();

  ItemCDocConvertor* cdoc_convertor = cdoc_workers_->Take();
  adsindexing::IndexDocInfo cdoc;
  if (!cdoc_convertor->ConvertToCDoc(reco_item, &cdoc)) {
    LOG(ERROR) << base::StringPrintf("convert cdoc failed! item_id=%lu",
                                     reco_item.identity().item_id());
    err_msg += "convert to cdoc item failed;";
    suc = false;
  } else {
    response->mutable_cdoc()->CopyFrom(cdoc);
  }
  cdoc_workers_->Put(cdoc_convertor);

  response->set_success(suc);
  response->set_err_msg(err_msg);

  int64 cost_ms = timer.Stop() / 1000;
  LOG(INFO) << "done conver reco item, reqest: " << request->reco_item().identity().item_id()
            << ", cost ms: " << cost_ms;
  COUNTERS_convertor__conv_reco_response_time.Increase(cost_ms);
  return;
}

void ConvertorImpl::extractFeature(stumy::RpcController* controller,
                                   const ExtractFeatureRequest* request,
                                   ExtractFeatureResponse* response,
                                   Closure* done) {
  COUNTERS_convertor__ext_fea_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_done(done);
  response->set_success(false);

  VLOG(1) << "extractFeature req:" << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  std::vector<std::string> orig_categories;
  if (request->category_size() == 0) {
    orig_categories.push_back("未分类");
  } else {
    RepeatedToVector<std::string>(request->category(), &orig_categories);
  }

  // extract feature
  RawItemConvertor* item_convertor = extract_workers_->Take();
  ExtractCfg cfg(request);
  std::vector<std::string> tags;
  std::vector<std::string> keywords;
  std::vector<std::string> bows;
  std::vector<std::string> plsa;
  std::vector<std::string> categories;
  reco::ItemType item_type = reco::kNews;
  if (request->has_type()) item_type = request->type();
  if (!item_convertor->ExtractItemFeatures(cfg,
                                           item_type,
                                           request->title(),
                                           request->content(),
                                           request->source(),
                                           orig_categories,
                                           &tags,
                                           &keywords,
                                           &bows,
                                           &plsa,
                                           &categories)) {
    LOG(WARNING) << "extract feature faield";
    return;
  }

  VectorToRepeated(tags, response->mutable_tags());
  VectorToRepeated(keywords, response->mutable_keywords());
  VectorToRepeated(bows, response->mutable_bows());
  VectorToRepeated(plsa, response->mutable_plsa());
  VectorToRepeated(categories, response->mutable_category());

  extract_workers_->Put(item_convertor);

  response->set_success(true);
  response->set_err_msg("");

  int64 cost_ms = timer.Stop() / 1000;
  LOG(INFO) << "extractFeature succ, title:" << request->title()
            << ", cost ms: " << cost_ms;
  COUNTERS_convertor__ext_fea_response_time.Increase(cost_ms);
  return;
}

void ConvertorImpl::pushRecoItemToCDocQueue(stumy::RpcController* controller,
                                            const PushRecoItemToCDocQueueRequest* request,
                                            PushRecoItemToCDocQueueResponse* response,
                                            Closure* done) {
  COUNTERS_convertor__push_cdoc_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_done(done);
  const reco::RecoItem& reco_item = request->reco_item();
  uint64 item_id = reco_item.identity().item_id();

  std::vector<std::string> updated_fields;
  RepeatedToVector(request->updated_fields(), &updated_fields);
  LOG(INFO) << "recv reqest: " << item_id << ", claimed updated fields: "
            << base::JoinStrings(updated_fields, ",");

  response->set_success(false);

  bool suc = true;
  std::string err_msg;

  bool listening = false;

  if (request->flush_storage()) {
    listening = true;
  } else {
    if (request->updated_fields_size() > 0) {
      for (int i = 0; i < request->updated_fields_size(); ++i) {
        if (cdoc_listening_field_set_.find(request->updated_fields(i)) != cdoc_listening_field_set_.end()) {
          listening = true;
          break;
        }
      }
    } else {
      listening = true;
    }
  }

  if (!listening) {
    LOG(INFO) << item_id << " do not need to push to cdoc";
    response->set_success(true);
    response->set_is_pushed(false);
    return;
  }

  ItemCDocConvertor* cdoc_convertor = cdoc_workers_->Take();
  adsindexing::IndexDocInfo cdoc;
  suc = cdoc_convertor->ConvertToCDoc(reco_item, &cdoc);
  if (!suc) {
    LOG(WARNING) << "convert cdoc failed! item_id:" << item_id;
    err_msg = "convert to cdoc item failed;";
  } else {
    suc = cdoc_writer_->AddCDoc(cdoc, reco_item.identity(), &err_msg);
    if (!suc) {
      LOG(WARNING) << "push cdoc failed! item_id:" << item_id;
      err_msg = "push cdoc failed;";
    } else {
      LOG(INFO) << "done push to cdoc, item_id: " << item_id;
    }
  }

  if (suc) {
    COUNTERS_convertor__kafka_cdoc_produce_num.Increase(1);
  } else {
    COUNTERS_convertor__conv_cdoc_failed_num.Increase(1);
  }

  // add to swift for ha3 realtime builder.
  std::string ha3doc;
  if (!cdoc_convertor->ConvertToHa3Doc(reco_item, &ha3doc)) {
    LOG(WARNING) << "convert ha3doc failed! item_id:" << item_id;
    err_msg = "convert to cdoc item failed;";
  } else {
    suc = ha3doc_writer_->AddHa3doc(ha3doc, reco_item.identity(), &err_msg);
    if (!suc) {
      LOG(WARNING) << "push ha3doc failed! item_id:" << item_id;
      err_msg = "push ha3doc failed;";
    } else {
      LOG(INFO) << "done push to ha3doc, item_id: " << item_id;
    }
  }

  cdoc_workers_->Put(cdoc_convertor);

  if (suc) {
    COUNTERS_convertor__ha3doc_produce_num.Increase(1);
  } else {
    COUNTERS_convertor__ha3doc_failed_num.Increase(1);
  }

  response->set_success(suc);
  response->set_is_pushed(suc);
  response->set_err_message(err_msg);

  int64 cost_ms = timer.Stop() / 1000;
  COUNTERS_convertor__push_cdoc_response_time.Increase(cost_ms);
  return;
}
}  // namespace convertor
}  // namespace reco
