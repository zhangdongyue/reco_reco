#include "reco/module/cdoc_convertor/server/cdoc_writer.h"

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

#include "ads_index/api/cdoc_convertor.pb.h"
#include "ads_index/forward_index/cdoc_compression.h"
#include "base/testing/gtest.h"
#include "base/common/gflags.h"
#include "base/common/sleep.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "reco/base/kafka_c/api_cc/consumer.h"

namespace reco {

DEFINE_string(item_kafka_brokers, "11.251.176.1,11.251.176.2,11.251.176.3", "kafka queue servers");
DEFINE_string(cdoc_item_kafka_topic, "unit_test_cdoc", "cdoc topic name");
DEFINE_int32(kafka_partition_common_ub, 2, "");
DEFINE_int32(kafka_partition_video_ub, 4, "");
DEFINE_int32(kafka_partition_manual_ub, 6, "");
DEFINE_string(db_host, "tcp://11.251.203.145:3306", "dbhost");
DEFINE_string(db_user, "recodev", "db user");
DEFINE_string(db_passwd, "tkDn19DHeVZkNA", "db passwd");
DEFINE_string(schema, "reco", "shcema");
DEFINE_string(item_keeper_ips, "11.251.202.129", "item keeper");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");

namespace hbase {
DECLARE_string(hbase_thrift_ips);
}
void ConstructCDocs(std::vector<adsindexing::IndexDocInfo>* cdocs, std::vector<ItemIdentity>* identities) {
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  // get id from db
  serving_base::mysql_util::DbConnManager db_manager(db_option);
  // use data one hour ago
  uint64 timestamp = 0;
  std::string time_str;
  CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kDay, &timestamp));
  CHECK(serving_base::TimeHelper::TimestampToString(timestamp, serving_base::TimeHelper::kDay, &time_str));

  std::string sql = base::StringPrintf("select item_id from tb_item_info where create_time>\"%s\"limit 64",
                                       time_str.c_str());
  sql::ResultSet* res = db_manager.ExecuteQueryWithRetry(sql, 3);
  CHECK_NOTNULL(res);

  std::vector<uint64> item_ids;
  std::unordered_set<uint64> dedup;
  while (res->next()) {
    uint64 id = res->getUInt64("item_id");
    if (dedup.insert(id).second) {
      item_ids.push_back(id);
    }
  }

  // get reco item from item-keeper
  reco::BaseGetItem* get_item = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips, FLAGS_item_keeper_port); // NOLINT
  std::vector<RecoItem> reco_items;
  get_item->GetRecoItems(item_ids, &reco_items);

  // transfer to cdoc
  reco::ItemCDocConvertor cdoc_convertor;
  cdocs->clear();
  identities->clear();
  for (size_t i = 0; i < reco_items.size(); ++i) {
    cdocs->push_back(adsindexing::IndexDocInfo());
    ASSERT_TRUE(cdoc_convertor.ConvertToCDoc(reco_items[i], &(cdocs->back())));
    identities->push_back(reco_items[i].identity());
  }
}

class CDocWriterTest : public testing::Test {
 public:
  static void SetUpTestCase() {
    reco::hbase::FLAGS_hbase_thrift_ips="11.251.181.33:9090,11.251.181.38:9090,11.251.181.42:9090,11.251.181.48:9090";  // NOLINT
    reco::hbase::HBasePoolIns::instance().Init();
    CHECK(reco::hbase::HBasePoolIns::instance().is_inited());

    ConstructCDocs(&cdocs_, &identities_);
    // construct writer
    cdoc_writer_ = new CDocWriter(FLAGS_item_kafka_brokers, FLAGS_cdoc_item_kafka_topic);
  }

  static void TearDownTestCase() {
    LOG(INFO) << "tear dwon!";
  }

  static const std::vector<adsindexing::IndexDocInfo> cdocs() {
    return cdocs_;
  }
  static const std::vector<ItemIdentity>& identities() {
    return identities_;
  }
  CDocWriter* cdoc_writer() {
    return cdoc_writer_;
  }
 public:
  static std::vector<adsindexing::IndexDocInfo> cdocs_;
  static std::vector<ItemIdentity> identities_;
  static CDocWriter* cdoc_writer_;
};

std::vector<adsindexing::IndexDocInfo> CDocWriterTest::cdocs_;
std::vector<ItemIdentity> CDocWriterTest::identities_;
CDocWriter* CDocWriterTest::cdoc_writer_ = NULL;

TEST_F(CDocWriterTest, TestWriteCDoc) {
  CDocWriter* cdoc_writer = CDocWriterTest::cdoc_writer();
  const std::vector<adsindexing::IndexDocInfo>& cdocs = CDocWriterTest::cdocs();
  const std::vector<ItemIdentity>& identities = CDocWriterTest::identities();
  std::string err_msg;
  for (size_t i = 0; i < cdocs.size(); ++i) {
    ASSERT_TRUE(cdoc_writer->AddCDoc(cdocs[i], identities[i], &err_msg)) << err_msg;
  }
  // read to test cdocs
  reco::kafka::ConsumerOptions option;
  option.topic = FLAGS_cdoc_item_kafka_topic;
  option.group_id = "0";
  option.partition_num = FLAGS_kafka_partition_manual_ub;
  option.start_timestamp = base::GetTimestamp() / 1000000 - 10;
  option.type = reco::kafka::kConsumerMirror;
  reco::kafka::Consumer consumer(FLAGS_item_kafka_brokers, option);
  reco::kafka::Message msg;
  reco::RecoCDoc reco_cdoc;
  std::unordered_set<uint64> item_id_dict;
  adsindexing::IndexDocInfo cdoc;
  // sleep enough for item write to kafka queue
  base::SleepForMilliseconds(3000);
  int fail = 0;
  std::string serialized_reco_cdoc;
  while (consumer.Consume(&msg, 100) || ++fail < option.partition_num) {
    serialized_reco_cdoc.clear();
    reco_cdoc.ParseFromString(msg.content);
    adsindexing::CDocCompressor cdoc_cmp(reco_cdoc.cdoc().c_str(), reco_cdoc.cdoc().size());
    ASSERT_TRUE(cdoc_cmp.Succeed() && cdoc_cmp.ToCDoc(&cdoc));
    const uint64* item_id = reinterpret_cast<const uint64*>(cdoc.key().c_str());
    item_id_dict.insert(*item_id);
  }
  ASSERT_EQ(cdocs.size(), item_id_dict.size());
  for (size_t i = 0; i < cdocs.size(); ++i) {
    const uint64* item_id = reinterpret_cast<const uint64*>(cdoc.key().c_str());
    auto it = item_id_dict.find(*item_id);
    ASSERT_TRUE(it != item_id_dict.end());
  }
}
}

