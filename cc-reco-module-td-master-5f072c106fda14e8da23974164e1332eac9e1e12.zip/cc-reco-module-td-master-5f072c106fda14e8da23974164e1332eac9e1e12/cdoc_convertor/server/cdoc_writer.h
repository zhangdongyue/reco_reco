#pragma once
#include <string>
namespace adsindexing {
class IndexDocInfo;
}
namespace reco {
namespace kafka {
class Producer;
}
}
namespace thread {
class ThreadPool;
}

namespace reco {
class ItemIdentity;
// thraed safe, singletone usage
class CDocWriter {
 public:
  CDocWriter(const std::string& kafka_brokers, const std::string& kafka_topic);
  ~CDocWriter();

  bool AddCDoc(const adsindexing::IndexDocInfo& cdoc, const ItemIdentity& identity, std::string* err_msg);
 private:
  // NOTE 以下常量切勿更改
  static const int kCommonItemPartitionUpperBound = 19;
  static const int kVideoItemPartitionUpperBound = 27;
  static const int kManualItemPartitionUpperBound = 31;
  static const int kCommonItemPartitionNum = kCommonItemPartitionUpperBound + 1;
  static const int kVideoItemPartitionNum = kVideoItemPartitionUpperBound - kCommonItemPartitionUpperBound;
  static const int kManualItemPartitionNum = kManualItemPartitionUpperBound - kVideoItemPartitionUpperBound;

  int GenPartitionNum(const reco::ItemIdentity& identity);

  reco::kafka::Producer* cdoc_producer_;
};
}
