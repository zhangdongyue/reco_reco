#pragma once
#include <string>

namespace reco {
    namespace kafka {
        class Producer;
    }
}

namespace reco {
    class ItemIdentity;
    // thraed safe, singletone usage
    class Ha3DocWriter {
        public:
            Ha3DocWriter(const std::string& kafka_brokers, const std::string& kafka_topic);
            ~Ha3DocWriter();

            bool AddHa3doc(const std::string & doc,
                    const ItemIdentity& identity, std::string* err_msg);

        private:
            reco::kafka::Producer* doc_producer_;
    };
}
