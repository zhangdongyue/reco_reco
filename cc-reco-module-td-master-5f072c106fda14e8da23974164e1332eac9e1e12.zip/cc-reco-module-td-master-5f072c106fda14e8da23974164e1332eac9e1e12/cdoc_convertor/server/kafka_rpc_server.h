#pragma once

#include "base/thread/internal/synchronization/lock.h"
#include "net/rpc/rpc.h"

#include "reco/module/cdoc_convertor/server/convertor_daemon.h"

namespace thread {
class Thread;
}

namespace reco {
namespace convertor {
class KafkaRpcServiceImpl;

class KafkaRpcServer {
 public:
  explicit KafkaRpcServer(int port);
  ~KafkaRpcServer();

  void Start();
  void Stop();

 private:
  base::Lock lock_;
  int port_;
  KafkaRpcServiceImpl *service_;
  net::rpc::RpcServer *server_;
};
}
}  // end of base
