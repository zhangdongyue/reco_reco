#include "reco/module/cdoc_convertor/server/kafka_rpc_server.h"

#include "base/common/base.h"
#include "net/rpc/rpc.h"
#include "base/thread/thread.h"

#include "reco/module/cdoc_convertor/server/convertor_impl.h"

namespace reco {
namespace convertor {
KafkaRpcServer::KafkaRpcServer(int port) {
  port_=  port;
  server_ = NULL;

  service_ = new KafkaRpcServiceImpl();
  CHECK(service_ != NULL);
}

KafkaRpcServer::~KafkaRpcServer() {
  Stop();
  delete service_;
}

void KafkaRpcServer::Start() {
  base::AutoLock auto_lock(lock_);
  if (server_ != NULL) return;

  net::rpc::RpcServer::Options opt;
  opt.port = port_;
  opt.server_thread_num = 1;
  opt.pump_thread_num = 1;
  server_ = new net::rpc::RpcServer(opt);
  CHECK(server_ != NULL);
  CHECK(server_->ExportService(service_));
  CHECK(server_->Start());
}

void KafkaRpcServer::Stop() {
  base::AutoLock auto_lock(lock_);
  if (server_ == NULL) return;

  server_->Stop();
  delete server_;
  server_ = NULL;
}
}
}  // namespace serving_base
