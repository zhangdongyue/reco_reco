#include <boost/shared_ptr.hpp>
#include <cstdatomic>
#include <unordered_map>
#include <vector>

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_split.h"
#include "base/random/pseudo_random.h"

#include "reco/base/dict_manager/common_dict_loader.h"
#include "reco/base/dict_manager/internal/template_dict_loader.h"
#include "reco/base/dict_manager/dynamic_dict.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/base/common/common_load_file.h"

TEST(GlobalDataTest, compare) {
  using namespace reco::dm;
  DynamicDict<DictManager::UnorderedMapStrDouble> dict;
  bool suc;
  int64 cnt;
  UnorderedMapStrDoubleLoader("news_idf.txt", &dict, &suc, &cnt);
  std::unordered_map<std::string, double> news_idf_dict;
  CHECK(reco::common::LoadFileToUnorderedMapKstringVdouble("news_idf.txt", &news_idf_dict));
  auto p = dict.GetDict();
  EXPECT_EQ(p->size(), news_idf_dict.size());
  // for (auto it = news_idf_dict.begin(); it != news_idf_dict.end(); ++it) {
  //   if (p->find(it->first) == p->end()) {
  //     LOG(ERROR) << it->first << ":" << it->second;
  //   }
  // }
  // for (auto it = p->begin(); it != p->end(); ++it) {
  //   if (news_idf_dict.find(it->first) == news_idf_dict.end()) {
  //     LOG(ERROR) << it->first << ":" << it->second;
  //   }
  // }
}

