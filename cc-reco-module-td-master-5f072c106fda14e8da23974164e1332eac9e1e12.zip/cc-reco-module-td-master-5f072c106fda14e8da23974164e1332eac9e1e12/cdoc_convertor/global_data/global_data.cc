#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/utf_string_conversions.h"
#include "base/hash_function/term.h"
#include "reco/module/cdoc_convertor/tag/tag_normalize.h"
#include "reco/module/cdoc_convertor/tag/tag_rule_match.h"
#include "reco/module/bad_item/strategy/rubbish_detector.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"

DEFINE_bool(default_init, true, "默认初始化为true时,加载所有词典,为false时,由调用方自行加载词典,用于测试");
DEFINE_string(reco_data_dir, "../data", "data dir");
// real time rule tree files
DEFINE_string(realtime_detect_rule_tree_xml, "", "rules tree realtime detect dict file.");

namespace reco {
namespace dm {
void LoadTermBlackFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) return;

  std::unordered_set<uint64>* dict = new std::unordered_set<uint64>();
  for (int i = 0; i < (int)lines.size(); ++i) {
    std::string str = nlp::util::NormalizeLine(lines[i]);
    dict->insert(base::CalcTermSign(str.c_str(), str.size()));
  }

  boost::shared_ptr<std::unordered_set<uint64>> ptr(dict);
  DynamicDict<std::unordered_set<uint64>>* dynamic_dict =
      reinterpret_cast<DynamicDict<std::unordered_set<uint64>>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

void LoadDynCorewordDetailFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "read file error:" << file_path.value();
    return;
  }

  std::unordered_map<std::string, CoreWordDetailInfo>* dyn_dict =
      new std::unordered_map<std::string, CoreWordDetailInfo>();

  std::vector<std::string> tokens;
  for (size_t i = 0; i < lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);

    // word \t tag_level \t is_semantic_tag \t c1`c2`c3 \t c1~tag11;c1~tag12;c2~tag21 [\t a1`a2`a3]
    if ((int)tokens.size() < 5 || tokens[0].empty()) continue;

    CoreWordDetailInfo word_info;

    std::string word = nlp::util::NormalizeLine(tokens[0]);
    int tag_level = 0;
    if (!base::StringToInt(tokens[1], &tag_level)) {
      VLOG(1) << "tag level field is invald ! tag_level:" << tokens[1];
      continue;
    }
    word_info.tag_level = tag_level;
    word_info.is_semantic_tag = (tokens[2] == "1");

    // 基础标签的限制类别
    word_info.categories.clear();
    if (!tokens[3].empty()) {
      std::vector<std::string> categories;
      base::SplitString(tokens[3], "`", &categories);

      for (int k = 0; k < (int)categories.size(); ++k) {
        word_info.categories.insert(categories[k]);
      }
    }

    // 扩展信息
    if (!tokens[4].empty()) {
      std::vector<std::string> ext_tokens;
      base::SplitString(tokens[4], ";", &ext_tokens);
      for (int j = 0; j < (int)ext_tokens.size(); ++j) {
        if (ext_tokens[j].empty()) continue;

        std::vector<std::string> kv;
        base::SplitString(ext_tokens[j], "~", &kv);
        if ((int)kv.size() < 2 || kv[0].empty() || kv[1].empty()) continue;

        std::string c = kv[0];
        std::string t = kv[1];

        auto it_c = word_info.extend_dict.find(c);
        if (it_c == word_info.extend_dict.end()) {
          std::vector<std::string> ext_tag_list;
          ext_tag_list.push_back(t);
          word_info.extend_dict.insert(std::make_pair(c, ext_tag_list));
        } else {
          it_c->second.push_back(t);
        }
      }
    }

    // 标签属性
    if ((int)tokens.size() >= 6 && !tokens[5].empty()) {
      std::vector<std::string> attr_vec;
      base::SplitString(tokens[5], "`", &attr_vec);
      for (int idx_attr = 0; idx_attr < (int)attr_vec.size(); ++idx_attr) {
        if (!attr_vec[idx_attr].empty()) {
          word_info.attributes.insert(attr_vec[idx_attr]);
          if (attr_vec[idx_attr] == "歧义词") {
            word_info.is_amb_word = true;
          }
        }
      }
    }

    if (dyn_dict->find(word) == dyn_dict->end()) {
      dyn_dict->insert(std::make_pair(word, word_info));
    }
  }

  boost::shared_ptr<std::unordered_map<std::string, CoreWordDetailInfo>> ptr(dyn_dict);
  DynamicDict<std::unordered_map<std::string, CoreWordDetailInfo> >* dynamic_dict =
      reinterpret_cast<DynamicDict<std::unordered_map<std::string, CoreWordDetailInfo> >* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dyn_dict->size();
  return;
}

void LoadSynonymTagDict(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "open synonym tag dict fail:" << file_path.value();
    return;
  }

  std::unordered_map<std::string, ContextSynonymData>* synonym_tag_dict =
      new std::unordered_map<std::string, ContextSynonymData>();

  for (size_t i = 0; i < lines.size(); ++i) {
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    // word \t context_type \t context(|) \t answer_word
    // context_type : 0 - context free, 1 - category context, 2 - keyword context
    if (tokens.size() < 4) {
      continue;
    }
    std::string word = nlp::util::NormalizeLine(tokens[0]);
    std::string type = nlp::util::NormalizeLine(tokens[1]);
    std::string context = nlp::util::NormalizeLine(tokens[2]);
    std::string answer_word = nlp::util::NormalizeLine(tokens[3]);

    if (word.empty() || answer_word.empty()) continue;
    if (type != "0" && type != "1" && type != "2") continue;

    ContextSynonymData& context_syn_data = (*synonym_tag_dict)[word];

    std::vector<std::string> context_vec;
    base::SplitString(context, "`", &context_vec);

    if (type == "0") {
      context_syn_data.context_free_result = answer_word;
    } else if (type == "1") {
      if (!context.empty()) {
        for (int j = 0; j < (int)context_vec.size(); ++j) {
          context_syn_data.category_context_dict[context_vec[j]] = answer_word;
        }
      }
    } else if (type == "2") {
      if (!context.empty()) {
        for (int j = 0; j < (int)context_vec.size(); ++j) {
          context_syn_data.keyword_context_dict[context_vec[j]] = answer_word;
        }
      }
    }
  }

  boost::shared_ptr<std::unordered_map<std::string, ContextSynonymData>> ptr(synonym_tag_dict);
  DynamicDict<std::unordered_map<std::string, ContextSynonymData> >* dynamic_dict =
      reinterpret_cast<DynamicDict<std::unordered_map<std::string, ContextSynonymData> >* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = synonym_tag_dict->size();
  return;
}

void LoadTagNormalizeFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "open tag normalize file fail:" << file_path.ToString();
    return;
  }

  std::unordered_map<std::string, std::string>* dict = new std::unordered_map<std::string, std::string>();
  std::vector<std::string> fields;
  for (auto it = lines.begin(); it != lines.end(); ++it) {
    if (!it->empty() && (*it)[0] == '#') continue;
    fields.clear();
    base::SplitString(*it, "\t", &fields);
    if (fields.size() < 2) continue;

    // 原始标签做特殊处理，主要是针对外国人名和含有空格的标签
    std::string tag = fields[0];
    GlobalData::CommonNormalize(fields[0], &tag);
    std::string nor_tag = fields[1];
    nlp::util::QuanJiaoToBanJiao(fields[1], &nor_tag);
    dict->insert(std::make_pair(tag, nor_tag));
  }

  boost::shared_ptr<std::unordered_map<std::string, std::string> > ptr(dict);
  DynamicDict<std::unordered_map<std::string, std::string> >* dynamic_dict =
      reinterpret_cast<DynamicDict<std::unordered_map<std::string, std::string> >* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}
// LDA 专用的简单分词器
void LoadLDASimpleTokenizer(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  SimpleTokenizer* tokenizer = new SimpleTokenizer(file_path.value());
  boost::shared_ptr<SimpleTokenizer> ptr(tokenizer);
  DynamicDict<SimpleTokenizer>* dynamic_dict =
          reinterpret_cast<DynamicDict<SimpleTokenizer>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  return;
}
// LDA 引擎
void LoadLDAInferenceEngine(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  InferenceEngine* lda_engine = new InferenceEngine( file_path.DirName().value(),
                                                    file_path.value(), SamplerType::MetropolisHastings);
  boost::shared_ptr<InferenceEngine> ptr(lda_engine);
  DynamicDict<InferenceEngine>* dynamic_dict =
          reinterpret_cast<DynamicDict<InferenceEngine>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  return;
}
void LoadAdverRuleFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  dawgdic::Dictionary* dict = new dawgdic::Dictionary();
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "read file error:" << file_path.value();
    return;
  }
  std::vector<std::string> fields;
  std::map<std::string, int> load_cache;
  for (auto it = lines.begin(); it != lines.end(); ++it) {
    fields.clear();
    base::SplitString(*it, "\t", &fields);
    CHECK_EQ((int)fields.size(), 2);
    nlp::util::NormalizeLineInPlaceS(&fields[0]);
    load_cache.insert(std::make_pair(fields[0], base::ParseIntOrDie(fields[1])));
  }
  dawgdic::DawgBuilder builder;
  for (auto it = load_cache.begin(); it != load_cache.end(); ++it) {
    CHECK(builder.Insert(it->first.c_str(), it->second));
  }
  dawgdic::Dawg dawg;
  builder.Finish(&dawg);
  CHECK(dawgdic::DictionaryBuilder::Build(dawg, dict));

  boost::shared_ptr<dawgdic::Dictionary> ptr(dict);
  DynamicDict<dawgdic::Dictionary>* dynamic_dict =
      reinterpret_cast<DynamicDict<dawgdic::Dictionary>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

void LoadLowQualitySubRuleFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "failed to open file: " << file_path.ToString();
    return;
  }
  std::unordered_map<std::string, int>* dict = new std::unordered_map<std::string, int>();
  std::vector<std::string> tokens;
  std::string key;
  int type = 0;
  for (int i = 0; i < (int)lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    if ((int)tokens.size() > 3 || (int)tokens.size() < 2) {
      LOG(ERROR) << "error line:\t" << lines[i];
      continue;
    }
    base::StringToInt(tokens.back(), &type);
    if (tokens.size() == 2) {
      dict->insert(std::make_pair(tokens[0], type));
    } else {
      if (tokens[0] < tokens[1]) {
        key = base::StringPrintf("%s#%s", tokens[0].c_str(), tokens[1].c_str());
      } else {
        key = base::StringPrintf("%s#%s", tokens[1].c_str(), tokens[0].c_str());
      }
      dict->insert(std::make_pair(key, type));
    }
  }
  boost::shared_ptr<std::unordered_map<std::string, int> > ptr(dict);
  DynamicDict<std::unordered_map<std::string, int> >* dynamic_dict =
      reinterpret_cast<DynamicDict<std::unordered_map<std::string, int >>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

void LoadLowQualityDawgDict(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "failed to open file: " << file_path.ToString();
    return;
  }

  dawgdic::Dictionary* dict = new dawgdic::Dictionary();

  std::vector<std::string> tokens;
  std::map<std::string, int> cache;
  std::string ngram;
  for (int i = 0; i < (int)lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    CHECK_GT((int)tokens.size(), 0);
    CHECK_LT((int)tokens.size(), 3);
    if ((int)tokens.size() == 1) {
      nlp::util::NormalizeLineInPlaceS(&tokens[0]);
      if (cache.find(tokens[0]) != cache.end()) {
        cache.find(tokens[0])->second = 2;
      } else {
        cache.insert(std::make_pair<std::string, int>(tokens[0].c_str(), 2));
      }
    } else {
      nlp::util::NormalizeLineInPlaceS(&tokens[0]);
      if (cache.find(tokens[0]) != cache.end()) {
        if (cache.find(tokens[0])->second == 1) cache.find(tokens[0])->second = 3;
        if (cache.find(tokens[0])->second == 2) cache.find(tokens[0])->second = 5;
        if (cache.find(tokens[0])->second == 4) cache.find(tokens[0])->second = 6;
      } else {
        cache.insert(std::make_pair(tokens[0], 0));
      }
      nlp::util::NormalizeLineInPlaceS(&tokens[1]);
      if (cache.find(tokens[1]) != cache.end()) {
        if (cache.find(tokens[1])->second == 0) cache.find(tokens[1])->second = 3;
        if (cache.find(tokens[1])->second == 2) cache.find(tokens[1])->second = 4;
        if (cache.find(tokens[1])->second == 5) cache.find(tokens[1])->second = 6;
      } else {
        cache.insert(std::make_pair(tokens[1], 1));
      }
      ngram = tokens[0] + tokens[1];
      nlp::util::NormalizeLineInPlaceS(&ngram);
      if (cache.find(ngram) != cache.end()) {
        cache.find(ngram)->second = 2;
      } else {
        cache.insert(std::make_pair<std::string, int>(ngram.c_str(), 2));
      }
    }
  }
  dawgdic::DawgBuilder builder;
  for (auto it = cache.begin(); it != cache.end(); ++it) {
    CHECK(builder.Insert(it->first.c_str(), it->second));
  }
  dawgdic::Dawg dawg;
  CHECK(builder.Finish(&dawg));
  dawgdic::DictionaryBuilder::Build(dawg, dict);

  boost::shared_ptr<dawgdic::Dictionary> ptr(dict);
  DynamicDict<dawgdic::Dictionary>* dynamic_dict = reinterpret_cast<DynamicDict<dawgdic::Dictionary>* >(dict_address); // NOLINT
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

void LoadTextLenStatFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::unordered_map<std::string, double>* dict = new std::unordered_map<std::string, double>();
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "read file error:" << file_path.value();
    return;
  }
  std::vector<std::string> tokens;
  for (int i = 0; i < (int)lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() < 10 || tokens[1] == "num") continue;
    double cur_threshold = 0;
    size_t i = 3;
    for (; i < tokens.size(); ++i) {
      double threshold = base::ParseDoubleOrDie(tokens[i]);
      if (threshold < 1) break;
      cur_threshold = threshold;
    }
    if (i == tokens.size()) continue;
    auto it_pair = dict->insert(std::make_pair(tokens[0], cur_threshold + 0.5));
    CHECK(it_pair.second);
  }

  boost::shared_ptr<std::unordered_map<std::string, double> > ptr(dict);
  DynamicDict<std::unordered_map<std::string, double> >* dynamic_dict =
      reinterpret_cast<DynamicDict<std::unordered_map<std::string, double> >* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

void LoadVideoInvalidTagFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::unordered_map<std::string, std::unordered_set<std::string> >* dict =
      new std::unordered_map<std::string, std::unordered_set<std::string> >();
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "read file error:" << file_path.value();
    return;
  }

  std::vector<std::string> tokens;
  std::vector<std::string> categories;
  for (size_t i = 0; i < lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    // 全局黑名单
    if (tokens.size() == 1) {
      (*dict)["all"].insert(tokens[0]);
      continue;
    }
    // 某些分类下的黑名单
    if (tokens.size() > 1) {
      categories.clear();
      base::SplitString(tokens[1], "|", &categories);
      for (size_t j = 0; j < categories.size(); ++j) {
        (*dict)[categories[j]].insert(tokens[0]);
      }
    }
  }

  boost::shared_ptr<std::unordered_map<std::string, std::unordered_set<std::string> > > ptr(dict);
  DynamicDict<std::unordered_map<std::string, std::unordered_set<std::string>> >* dynamic_dict =
      reinterpret_cast<DynamicDict<std::unordered_map<std::string, std::unordered_set<std::string>> >* >(dict_address); // NOLINT
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

void LoadLowQualityThresholdFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "failed to open file: " << file_path.ToString();
    return;
  }
  std::unordered_map<std::string, double>* dict = new std::unordered_map<std::string, double>();
  std::vector<std::string> tokens;
  std::string key;
  double value = 0;
  for (int i = 0; i < (int)lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    if ((int)tokens.size() < 2) continue;
    if (3 == (int)tokens.size()) {
      if (!base::StringToDouble(tokens[2], &value)) continue;
      key = base::StringPrintf("%s\t%s", tokens[0].c_str(), tokens[1].c_str());
      dict->insert(std::make_pair(key, value));
    } else if (2 == (int)tokens.size()) {
      if (!base::StringToDouble(tokens[1], &value)) continue;
      dict->insert(std::make_pair(tokens[0], value));
    }
  }
  boost::shared_ptr<std::unordered_map<std::string, double> > ptr(dict);
  DynamicDict<std::unordered_map<std::string, double> >* dynamic_dict =
      reinterpret_cast<DynamicDict<std::unordered_map<std::string, double >>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

void LoadNbaBlackTermFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "failed to open file: " << file_path.ToString();
    return;
  }

  std::set<std::string> key_set;
  for (auto it = lines.begin(); it != lines.end(); ++it) {
    key_set.insert(nlp::util::NormalizeLine(*it));
  }

  std::vector<const char*> keys;
  for (auto it = key_set.begin(); it != key_set.end(); ++it) {
    keys.push_back(it->c_str());
  }

  boost::shared_ptr<darts_clone::DoubleArray> new_dict(new darts_clone::DoubleArray());
  if (new_dict->build(keys.size(), &(keys[0]), NULL, NULL, NULL) != 0) return;

  auto dict = static_cast<DynamicDict<darts_clone::DoubleArray>*>(dict_address);
  dict->Swap(new_dict);
  *suc = true;
  *cnt = keys.size();
}

void LoadVideoTagVectorFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "failed to open file: " << file_path.ToString();
    return;
  }
  std::unordered_map<std::string, TagVec>* dict = new std::unordered_map<std::string, TagVec>();
  std::vector<std::string> tokens;
  for (int i = 0; i < (int)lines.size(); ++i) {
    base::TrimWhitespaces(&lines[i]);
    if (lines[i].empty()) {
      continue;
    }
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    if ((int)tokens.size() < 129) continue;
    std::string tag = tokens.at(0);
    double weight = 0.0;
    double l2_norm = 0.0;
    TagVec tag_vec;
    for (size_t j = 1; j < tokens.size(); ++j) {
      if (!base::StringToDouble(tokens.at(j), &weight)) {
        LOG(ERROR) << "value error : " << tokens.at(j) << ",can't convetor to double";
        continue;
      }
      l2_norm += weight * weight;
      tag_vec.vec.push_back(weight);
    }
    tag_vec.l2_norm = sqrt(l2_norm);
    dict->insert(std::make_pair(tag, tag_vec));
  }
  LOG(INFO) << "load video tag : " << file_path.ToString() << ", success";
  boost::shared_ptr<std::unordered_map<std::string, TagVec> > ptr(dict);
  DynamicDict<std::unordered_map<std::string, TagVec> >* dynamic_dict =
      reinterpret_cast<DynamicDict<std::unordered_map<std::string, TagVec> >* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

}  // namespace dict_manager

const char* GlobalData::kNbaBlackTermFile = "nba_black_term.txt";
const char* GlobalData::kNewsIdfFile = "news_idf.txt";
const char* GlobalData::kTermBlackFile = "term_black.txt";
const char* GlobalData::kWhiteVideoSourceFile = "white_video_source.txt";
const char* GlobalData::kVideoShowTagFile = "video_show_tag.txt";
const char* GlobalData::kDynCorewordDetailFile = "dyn_coreword_detail.txt";
const char* GlobalData::kTitleSynonymFile = "title_synonym.txt";
const char* GlobalData::kVideoInvalidTagFile = "video_invalid_tag.txt";
const char* GlobalData::kShowTagCategoryFile = "show_tag_category.txt";
const char* GlobalData::kSourceTagFile = "source_tag.txt";
const char* GlobalData::kTagNormalizeFile = "tag_normalize.txt";
const char* GlobalData::kSynonymTagFile = "synonym_tag.txt";
const char* GlobalData::kWemediaSourceFile = "wemedia_source_info.txt";

// region
const char* GlobalData::kRegionBlackFile = "city_black.txt";
const char* GlobalData::kRegionBlackLimitFile = "region_black_limit.txt";
const char* GlobalData::kRegionCategoryBlackFile = "city_category_black.txt";
const char* GlobalData::kLocalSourceFile = "local_source.txt";

// 低质相关
const char* GlobalData::kAdverRuleFile = "advertorial_rule.txt";
const char* GlobalData::kAdverKeywordFile = "advertorial_keywords.txt";
const char* GlobalData::kAdverImpurityKeywordFile = "advertorial_impurity_keywords.txt";
const char* GlobalData::kAdverModelFile = "advertorial_model.txt";
const char* GlobalData::kRubbishSourceFile = "rubbish_sources.txt";
const char* GlobalData::kBluffingRuleFile = "bluffing_rule.txt";
const char* GlobalData::kBluffingKeywordFile = "bluffing_keywords.txt";
const char* GlobalData::kDirtyRuleFile = "dirty_rule.txt";
const char* GlobalData::kDirtyKeywordFile = "dirty_keywords.txt";
const char* GlobalData::kDirtyModelFile = "dirty_model.txt";
const char* GlobalData::kDirtySubRuleFile = "dirty_sub_rule.txt";
const char* GlobalData::kRubbishTitleFile = "rubbish_title.txt";
const char* GlobalData::kNegativeRuleFile = "negative_rule.txt";
const char* GlobalData::kNegativeKeywordFile = "negative_keywords.txt";
const char* GlobalData::kPoliticsRuleFile = "politics_rule.txt";
const char* GlobalData::kPoliticsKeywordFile = "politics_keywords.txt";
const char* GlobalData::kTextLenStatFile = "text_len.txt";
const char* GlobalData::kStopwordFile = "stopword.txt";
const char* GlobalData::kMediaQualityFile = "media_quality.txt";
const char* GlobalData::kLowQualityRemitSourceFile = "low_quality_remit_source.txt";
const char* GlobalData::kLowQualityThresholdFile = "low_quality_thresholds.txt";
const char* GlobalData::kLowQualityImageHashFile = "bad_image_hash.txt";

// 视频质量相关
const char* GlobalData::kVideoDirtyRuleFile = "video_quality_dirty_rule.txt";
const char* GlobalData::kVideoDirtyKeywordFile = "video_quality_dirty_keywords.txt";

// 视频 show tag 点击率表
const char* GlobalData::kVideoShowTagCtrFile = "video_show_tag_ctr.txt";
// LDA 词表
const char* GlobalData::kLDAWordFile = "vocab_info.txt";
const char* GlobalData::kLDAConfigFile = "lda.conf";
const char* GlobalData::kSLDAConfigFile = "slda.conf";
// video tag
const char* GlobalData::kVideoTagVecFile = "video_tag_vec.txt";

GlobalData::GlobalData() {
}

GlobalData::~GlobalData() {
  for (auto it = realtime_rule_forest_map_.begin(); it != realtime_rule_forest_map_.end(); ++it) {
    delete it->second;
  }
}

void GlobalData::Init() {
  // 默认初始化会加载所有词典,但在单元测试之类的场景则没有必要,
  // 所以单测时可以设置默认初始化为 false,然后手工调用指定词典的加载函数;
  base::FilePath root_dir(FLAGS_reco_data_dir);

  DM_REGISTER_COMMON_DICT(UnorderedMapStrDouble, kNewsIdfFile);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedSetUint64,
                            kTermBlackFile, reco::dm::LoadTermBlackFile);
  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kWhiteVideoSourceFile);

  // 加载简称同义词词典
  DM_REGISTER_COMMON_DICT(UnorderedMapStrStr, kTitleSynonymFile);

  // region
  DM_REGISTER_COMMON_DICT(UnorderedSetStr, kRegionBlackFile);
  DM_REGISTER_COMMON_DICT(UnorderedSetStr, kRegionBlackLimitFile);

  DM_REGISTER_COMMON_DICT(UnorderedMapStrUnorderedSetStr, kRegionCategoryBlackFile);

  DM_REGISTER_COMMON_DICT(UnorderedSetStr, kLocalSourceFile);

  // realtime rule
  CHECK(RuleTreeRealtimeDetectorLoadXml(FLAGS_realtime_detect_rule_tree_xml));

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrUnorderedSetStr, kShowTagCategoryFile);

  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedMapStrUnorderedSetStr,
                            kVideoInvalidTagFile, reco::dm::LoadVideoInvalidTagFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrDouble, kVideoShowTagFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrVectorStr, kSourceTagFile);

  DM_REGISTER_CUSTOMER_DICT(UnorderedMapStrCoreWordDetailInfo,
                            kDynCorewordDetailFile, reco::dm::LoadDynCorewordDetailFile);

  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedMapStrStr,
                            kTagNormalizeFile, reco::dm::LoadTagNormalizeFile);

  DM_REGISTER_CUSTOMER_DICT(UnorderedMapStrContextSynonymData,
                            kSynonymTagFile, reco::dm::LoadSynonymTagDict);

  DM_REGISTER_CUSTOMER_DICT(UnorderedMapStrTagVec,
                            kVideoTagVecFile, reco::dm::LoadVideoTagVectorFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrUnorderedSetStr, kWemediaSourceFile);

  // 加载低质词表
  /*
  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverRuleFile,
                            reco::dm::LoadAdverRuleFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverImpurityKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_DICT(UnorderedMapUint64Double, kAdverModelFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kDirtyRuleFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kDirtyKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kBluffingRuleFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kBluffingKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_DICT(UnorderedMapUint64Double, kDirtyModelFile);
  */
  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedMapStrInt,
                            kDirtySubRuleFile, reco::dm::LoadLowQualitySubRuleFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kRubbishTitleFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kPoliticsRuleFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kPoliticsKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kNegativeRuleFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kNegativeKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrInt, kRubbishSourceFile);

  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedMapStrDouble,
                            kTextLenStatFile, reco::dm::LoadTextLenStatFile);

  // DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kStopwordFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrInt, kMediaQualityFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kLowQualityRemitSourceFile);

  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedMapStrDouble,
                            kLowQualityThresholdFile, reco::dm::LoadLowQualityThresholdFile);
  // DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrInt, kLowQualityImageHashFile);

  // 加载视频质量词表
  /**
  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kVideoDirtyRuleFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kVideoDirtyKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);
  */

  // NBA屏蔽词词表
  DM_REGISTER_CUSTOMER_DICT(darts_clone::DoubleArray, kNbaBlackTermFile,
                            reco::dm::LoadNbaBlackTermFile);

  // LDA
  reco::dm::DictManagerSingleton::instance().RegisterDict<SimpleTokenizer>("kLDAWordFile",
                                                                     root_dir.Append(kLDAWordFile),
                                                                       reco::dm::LoadLDASimpleTokenizer);
  reco::dm::DictManagerSingleton::instance().RegisterDict<InferenceEngine>("kLDAConfigFile",
                                                                     root_dir.Append(kLDAConfigFile),
                                                                     reco::dm::LoadLDAInferenceEngine);
  reco::dm::DictManagerSingleton::instance().RegisterDict<InferenceEngine>("kSLDAConfigFile",
                                                                     root_dir.Append(kSLDAConfigFile),
                                                                     reco::dm::LoadLDAInferenceEngine);

  // 加载视频 show tag 点击率表
  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrDouble, kVideoShowTagCtrFile);

  if (FLAGS_default_init) {
    reco::dm::DictManagerSingleton::instance().LoadAllDicts();
  }
}

void GlobalData::CommonNormalize(const std::string &org, std::string *nor) {
  if (!nor) return;
  *nor = base::StringReplace(org, "-", "", true);
  *nor = base::StringReplace(*nor, "·", "", true);
  *nor = base::StringReplace(*nor, " ", "", true);
  *nor = nlp::util::NormalizeLine(*nor);
}

bool GlobalData::RuleTreeRealtimeDetectorLoadXml(const std::string& filename) {
  xml::TiXmlDocument doc;
  CHECK(doc.LoadFile(filename.c_str())) << filename;

  const xml::TiXmlElement* forest_element = doc.FirstChildElement("forest");
  CHECK_NOTNULL(forest_element);

  int tree_num = -1;
  CHECK_EQ(forest_element->QueryIntAttribute("tree_num", &tree_num), xml::TIXML_SUCCESS);
  CHECK_GT(tree_num, 0);

  for (const xml::TiXmlElement* element = forest_element->FirstChildElement("tree");
       element; element = element->NextSiblingElement("tree")) {
    reco::cdoc_convertor::Tree* tree = new reco::cdoc_convertor::Tree();
    std::string tree_name;
    CHECK_EQ(element->QueryStringAttribute("name", &tree_name), xml::TIXML_SUCCESS);

    if (!reco::cdoc_convertor::Tree::ParseTree(element, tree)) return false;
    tree->SetTreeName(tree_name);
    realtime_rule_forest_map_.insert(std::make_pair(tree_name, tree));
  }

  return true;
}
}  // namespace reco
