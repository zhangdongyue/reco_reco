#pragma once
#include <string>
#include <vector>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>

#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "nlp/common/term_info.h"
#include "nlp/common/nlp_util.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/module/cdoc_convertor/tag/video_tag_annotator.h"
#include "reco/module/cdoc_convertor/tag/tag_annotator.h"
#include "reco/base/common/singleton.h"
#include "reco/module/cdoc_convertor/rules_tree/tree.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "extend/static_dict/darts_clone/darts_clone.h"
#include "reco/module/cdoc_convertor/plda/inference_engine.h"
#include "reco/module/cdoc_convertor/plda/tokenizer.h"

namespace reco {
namespace dm {
void LoadTermBlackFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadDynCorewordDetailFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadSynonymTagDict(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadTagNormalizeFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadVideoInvalidTagFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadAdverRuleFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadTextLenStatFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadLowQualityDawgDict(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadLowQualitySubRuleFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadLowQualityThresholdFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadLDASimpleTokenizer(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadLDAInferenceEngine(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadNbaBlackTermFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadVideoTagVectorFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
}
}

namespace reco {
class TagMatch;
struct CoreWordDetailInfo {
  // 0: 核心词, 1: 基础标签, 2: 展示标签, 3: 订阅标签
  int tag_level;
  // 是否语义标签
  bool is_semantic_tag;
  // 不为空，则表示只有在这些类别下才作为标签生效。为空，表示所有类别下都可以作为标签
  std::unordered_set<std::string> categories;
  // 扩展信息：类别 --> 扩展 tag 集合
  std::unordered_map<std::string, std::vector<std::string> > extend_dict;
  // 是否歧义词, 从属性信息中解析得到
  bool is_amb_word;
  // 属性信息: 歧义词，歌曲，图书，游戏，电影，电视剧，综艺，动漫，机构名-国家机构，机构名-公司，
  // 地名，国家，人名，人名-明星，人名-政治家，品牌，品牌-汽车
  std::set<std::string> attributes;

  CoreWordDetailInfo() {
    Reset();
  }
  void Reset() {
    tag_level = 0;
    is_semantic_tag = false;
    categories.clear();
    extend_dict.clear();
    is_amb_word = false;
    attributes.clear();
  }
};

// 上下文数据
// 1. context_free_result 不为空，则表示这是一个上下文无关同义词
// 2. 支持类别和关键词两种上下文
struct ContextSynonymData {
  std::string context_free_result;
  std::unordered_map<std::string, std::string> category_context_dict;
  std::unordered_map<std::string, std::string> keyword_context_dict;
};

struct TagVec {
  std::vector<double> vec;
  double l1_norm;
  double l2_norm;
  TagVec() {
    l1_norm = 0.0;
    l2_norm = 0.0;
    vec.clear();
  }
};

class GlobalData {
 public:
  GlobalData();
  ~GlobalData();
  void Init();

  static void CommonNormalize(const std::string &org, std::string *nor);

 public:

 public:
  boost::shared_ptr<const std::unordered_map<std::string, double>> GetNewIdfDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrDouble, kNewsIdfFile);
  }

  boost::shared_ptr<const std::unordered_set<uint64>> GetBlackTermDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetUint64, kTermBlackFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string>> GetWhiteVideoSourceDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kWhiteVideoSourceFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::string>> GetTitleSynDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrStr, kTitleSynonymFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::unordered_set<std::string>>> GetVideoInvalidTagDict() { // NOLINT
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrUnorderedSetStr, kVideoInvalidTagFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, double>> GetVideoShowTagDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrDouble, kVideoShowTagFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::unordered_set<std::string> > >GetShowTagCategroyDict() { // NOLINT
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrUnorderedSetStr, kShowTagCategoryFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, CoreWordDetailInfo>> GetDynCorewordDetailDict() {
    return DM_GET_DICT(reco::GlobalData::UnorderedMapStrCoreWordDetailInfo, kDynCorewordDetailFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::vector<std::string> > > GetSourceTagDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrVectorStr, kSourceTagFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::unordered_set<std::string> > > GetWemediaSourceDict() { // NOLINT
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrUnorderedSetStr, kWemediaSourceFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string> > GetRegionBlackDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kRegionBlackFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string> > GetRegionBlackLimitDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kRegionBlackLimitFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::unordered_set<std::string> > > GetRegionCateBlackDict() { // NOLINT
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrUnorderedSetStr, kRegionCategoryBlackFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string>> GetRegionLocalSourceDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kLocalSourceFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, ContextSynonymData>> GetSynTagDict() {
    return DM_GET_DICT(UnorderedMapStrContextSynonymData, kSynonymTagFile);
  }

  const std::unordered_map<std::string, reco::cdoc_convertor::Tree*>* GetRealTimeRuleForest() {
    return &realtime_rule_forest_map_;
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::string>> GetTagNormalizeDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrStr, kTagNormalizeFile);
  }

  // 低质识别词表的 getter 方法
  boost::shared_ptr<const dawgdic::Dictionary> GetAdverRules() {
    return DM_GET_DICT(dawgdic::Dictionary, kAdverRuleFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetAdverKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kAdverKeywordFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetAdverImpurityKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kAdverImpurityKeywordFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, int> > GetRubbishSource() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrInt, kRubbishSourceFile);
  }

  boost::shared_ptr<const std::unordered_map<uint64, double> > GetAdverModel() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapUint64Double, kAdverModelFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetBluffingRules() {
    return DM_GET_DICT(dawgdic::Dictionary, kBluffingRuleFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetBluffingKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kBluffingKeywordFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetDirtyRules() {
    return DM_GET_DICT(dawgdic::Dictionary, kDirtyRuleFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetDirtyKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kDirtyKeywordFile);
  }

  boost::shared_ptr<const std::unordered_map<uint64, double> > GetDirtyModel() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapUint64Double, kDirtyModelFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, int> > GetDirtySubRule() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrInt, kDirtySubRuleFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetNegativeRules() {
    return DM_GET_DICT(dawgdic::Dictionary, kNegativeRuleFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetNegativeKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kNegativeKeywordFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetPoliticsRules() {
    return DM_GET_DICT(dawgdic::Dictionary, kPoliticsRuleFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetPoliticsKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kPoliticsKeywordFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string> > GetRubbishTitles() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kRubbishTitleFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string> > GetStopwords() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kStopwordFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, int> > GetMediaQuality() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrInt, kMediaQualityFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, double> > GetCategoryLengthThreshold() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrDouble, kTextLenStatFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string> > GetLowQualityRemitSources() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kLowQualityRemitSourceFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, double> > GetLowQualityThresholds() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrDouble, kLowQualityThresholdFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, int> > GetLowQualityImageHashs() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrInt, kLowQualityImageHashFile);
  }

  // 视频质量词表的 get 方法
  boost::shared_ptr<const dawgdic::Dictionary> GetVideoDirtyRules() {
    return DM_GET_DICT(dawgdic::Dictionary, kVideoDirtyRuleFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetVideoDirtyKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kVideoDirtyKeywordFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, double>> GetVideoShowTagCtrDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrDouble, kVideoShowTagCtrFile);
  }

  boost::shared_ptr<const SimpleTokenizer> GetLDATokenizer() {
    return DM_GET_DICT(SimpleTokenizer, kLDAWordFile);
  }
  boost::shared_ptr<const InferenceEngine> GetLDAInferenceEngine() {
    return DM_GET_DICT(InferenceEngine, kLDAConfigFile);
  }
  boost::shared_ptr<const InferenceEngine> GetSLDAInferenceEngine() {
    return DM_GET_DICT(InferenceEngine, kSLDAConfigFile);
  }

  boost::shared_ptr<const darts_clone::DoubleArray> GetNbaBlackTermDict() {
    return DM_GET_DICT(darts_clone::DoubleArray, kNbaBlackTermFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, TagVec>> GetVideoTagVecDict() {
    return DM_GET_DICT(reco::GlobalData::UnorderedMapStrTagVec, kVideoTagVecFile);
  }

 public:
  typedef std::unordered_map<std::string, CoreWordDetailInfo> UnorderedMapStrCoreWordDetailInfo;
  typedef std::unordered_map<std::string, ContextSynonymData> UnorderedMapStrContextSynonymData;
  typedef std::unordered_map<std::string, TagVec> UnorderedMapStrTagVec;

  // realtime rule
  bool RuleTreeRealtimeDetectorLoadXml(const std::string& filename);

 private:
  // NBA屏蔽关键词
  static const char* kNbaBlackTermFile;

  static const char* kNewsIdfFile;  // news_idf_dict_;

  // 黑名单, 出现在此名单里的词不作为 keyword 等特征
  static const char* kTermBlackFile;

  // 白名单，出现在此名单里的视频源使用 summary 扩召回视频标签
  // std::unordered_set<uint64> white_video_source_dict_;
  static const char* kWhiteVideoSourceFile;
  static const char* kVideoShowTagFile;

  static const char* kDynCorewordDetailFile;
  static const char* kTermNormalizeFile;
  static const char* kTitleSynonymFile;
  static const char* kVideoInvalidTagFile;
  static const char* kShowTagCategoryFile;
  static const char* kSourceTagFile;
  static const char* kTagNormalizeFile;
  static const char* kSynonymTagFile;
  static const char* kWemediaSourceFile;

  // region
  static const char* kRegionBlackFile;
  static const char* kRegionBlackLimitFile;
  static const char* kRegionCategoryBlackFile;
  static const char* kLocalSourceFile;

  // 低质相关文件
  static const char* kAdverRuleFile;
  static const char* kAdverKeywordFile;
  static const char* kAdverImpurityKeywordFile;
  static const char* kAdverModelFile;
  static const char* kBluffingRuleFile;
  static const char* kBluffingKeywordFile;
  static const char* kDirtyRuleFile;
  static const char* kDirtyKeywordFile;
  static const char* kDirtyModelFile;
  static const char* kDirtySubRuleFile;
  static const char* kRubbishTitleFile;
  static const char* kNegativeRuleFile;
  static const char* kNegativeKeywordFile;
  static const char* kPoliticsRuleFile;
  static const char* kPoliticsKeywordFile;
  static const char* kRubbishSourceFile;
  static const char* kTextLenStatFile;
  static const char* kStopwordFile;
  static const char* kMediaQualityFile;
  static const char* kLowQualityRemitSourceFile;
  static const char* kLowQualityThresholdFile;
  static const char* kLowQualityImageHashFile;

  // 视频质量相关文件
  static const char* kVideoDirtyRuleFile;
  static const char* kVideoDirtyKeywordFile;

  static const char* kVideoShowTagCtrFile;
  // realtime rule
  std::unordered_map<std::string, reco::cdoc_convertor::Tree*> realtime_rule_forest_map_;
  // LDA
  static const char* kLDAWordFile;
  static const char* kLDAConfigFile;
  static const char* kSLDAConfigFile;
  // video tag vec
  static const char* kVideoTagVecFile;
};

typedef reco::common::singleton_default<GlobalData> GlobalDataIns;
}  // name space reco
