#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <google/protobuf/descriptor.h>

//#include "reco/base/hbase_c/api/hbase_client_pool.h"
//#include "reco/bizc/item_service/hbase_get_item.h"
//#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/proto/item.pb.h"
//#include "reco/bizc/proto/
#include "base/common/base.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_number_conversions.h"
#include "reco/module/cdoc_convertor/breaking/breaking_recognition.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "serving_base/utility/time_helper.h"

DEFINE_string(item_keeper_server_ips, "11.251.202.129,11.251.202.194,11.251.202.213", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_int32(item_keeper_server_timeout, 3000, "");
DEFINE_string(item_kafka_brokers, "", "kafka queue servers");
DEFINE_string(item_topic, "", "iten topic name");
DEFINE_int32(item_partition, 32, "partition num for item topic");
DEFINE_string(start_time, "", "db start time");
DEFINE_int32(max_num, 100, "");
DEFINE_string(output, "../data/kafka_break.output", "");

static std::atomic_bool reader_finished(false);

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "breaking news recognition demo");

  const std::vector<std::string> kListeningFields = {
    "title", "region"
  };
  std::unordered_set<std::string> listening_fld_dict;
  reco::RecoItem reco_item;
  const google::protobuf::Descriptor* descriptor = reco_item.GetDescriptor();
  for (size_t i = 0; i < kListeningFields.size(); ++i) {
    const std::string& field = kListeningFields[i];
    CHECK_NOTNULL(descriptor->FindFieldByLowercaseName(field));
    listening_fld_dict.insert(field);
    LOG(INFO) << "I will listen change of field [" << field << "]";
  }

  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_item_topic;
  options.partition_num = FLAGS_item_partition;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = "0";
  uint64 timestamp = 0;
  if (!serving_base::TimeHelper::StringToTimestamp(FLAGS_start_time, serving_base::TimeHelper::kSecond,
                                                   &timestamp)) {
    CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond,
                                                        &timestamp));
  }
  options.start_timestamp = timestamp / 1000000;

  reco::kafka::Message msg;
  reco::kafka::Consumer consumer(FLAGS_item_kafka_brokers, options);

  reco::common::BreakingRecognition br("");
  reco::RecoItem item;
  std::ofstream ofout(FLAGS_output);
  int n = 0;
  while (!reader_finished && (FLAGS_max_num <= 0 || n < FLAGS_max_num)) {
    if (!consumer.Consume(&msg, 100)) {
      LOG_EVERY_N(INFO, 1000) << "get message from kafka failed!";
      base::SleepForMilliseconds(500);
      continue;
    }
    ++n;
    //reco::RecoItem* item = new reco::RecoItem;
    if (!item.ParseFromString(msg.content)) {
      LOG(ERROR) << "failed to parse RecoItem from message, " << msg.content;
      continue;
    }
    uint64 item_id = item.identity().item_id();
    // fitler out item that we don't care about
    bool is_listen = (item.updated_fields_size() == 0);
    std::string listen_field;
    for (int i = 0; i < item.updated_fields_size(); ++i) {
      const std::string& name = item.updated_fields(i);
      if (listening_fld_dict.find(name) != listening_fld_dict.end()) {
        listen_field = name;
        is_listen = true;
        break;
      }
    }

    if (!is_listen) {
      LOG_EVERY_N(INFO, 1000) << "skip unlistening changing " << item_id;
      continue;
    } else {
      LOG(INFO) << "listening changing " << item_id << " of field " << listen_field;
    }

    std::vector<reco::common::BreakingProperty> v;
    //std::cout << it->title() << "\n";
    //ofout << item.identity().item_id() << "\t" << item.title() << "\n";
    if (br.ExtractBreakingProperty(item, &v)) {
      //std::cout << "--------------------- item id: " << it->identity().item_id();
      std::vector<std::string> cate_buf;
      for (auto i = 0; i < item.category_size(); ++i) {
        cate_buf.push_back(item.category(i));
      }
      for (auto iter = v.begin(); iter != v.end(); ++iter) {
        ofout << item.identity().item_id()
             << "\t" << item.title()
             << "\t" << iter->event_id
             << "\t" << iter->event_literal
             << "\t" << iter->reliability
             << "\t" << iter->start_time
             << "\t" << iter->stop_time
             << "\t" << base::JoinStrings(cate_buf, "|")
             << "\n";

        /*
        std::cout << "\ntitle: " << it->title()
             << "\nevent_id: " << iter->event_id
             << "\nevent_literal: " << iter->event_literal
             << "\nreliability: " << iter->reliability
             << "\nstart_time: " << iter->start_time
             << "\nstop_time: " << iter->stop_time
             << "\ncategory: " << base::JoinStrings(cate_buf, "|")
             << "\n";
             */
      }
    }
  }

  return 0;
}
