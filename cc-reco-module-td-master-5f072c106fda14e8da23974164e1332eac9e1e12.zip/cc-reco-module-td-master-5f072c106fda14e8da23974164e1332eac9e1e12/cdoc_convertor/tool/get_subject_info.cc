#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/encoding/line_escape.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc_util/rpc_group.h"

#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_handler.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"

#include "extend/json/jansson/jansson.h"
#include "reco/module/cdoc_convertor/tool/subject_utils.h"

DEFINE_int32(time_out, 1000, "rpc time out");
DEFINE_string(item_id, "", "");
DEFINE_string(item_id_file, "", "");
DEFINE_string(output_file, "out_subject_info.txt", "输出文件名");
DEFINE_string(manual_fields, "", "逗号分隔开不同的字段");

DEFINE_string(doc_server_ips, "100.85.69.71", "doc server ips, splitted by ,");
DEFINE_int32(doc_server_port, 20013, "doc server port");

DEFINE_int32(api, 0,
             "API: 0-convertRawItem, 1-convertRecoItem, 2-extractFeature, 3-updateItem");

DEFINE_string(hbase_reco_item_table, "tb_reco_item", "hbase table, tb_reco_item");

std::string FeatureVectorToString(const reco::FeatureVector& feature_vec) {
  std::string result = "";
  for (int i = 0; i < feature_vec.feature_size(); ++i) {
    auto current_fea = feature_vec.feature(i);
    std::string raw_tag = current_fea.literal();
    if (result == "") {
      result = raw_tag;
    } else {
      result += ","+raw_tag;
    }
  }
  return result;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "convertor client");

  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());

  reco::HBaseGetItem* hbase_get_item =
      new reco::HBaseGetItem(FLAGS_hbase_reco_item_table, 0);

  reco::DocServerGetItem* doc_get_item =
      new reco::DocServerGetItem(FLAGS_doc_server_ips, FLAGS_doc_server_port, 0);

  std::vector<std::string> manual_fields_vec;
  if (!FLAGS_manual_fields.empty()) {
    base::SplitString(FLAGS_manual_fields, ",", &manual_fields_vec);
  }

  std::string line;
  std::string key;
  std::string value;

  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }
  std::ofstream fout(FLAGS_output_file);

  for (int i = 0; i < (int)item_id_list.size(); ++i) {
    reco::RecoItem reco_item;
    std::vector<reco::RecoItem> subitems_vec;
    uint64 item_id = base::ParseUint64OrDie(item_id_list[i]);
    LOG(INFO) << "get item " << item_id;
    if (!doc_get_item->GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "failed to get reco item: " << item_id;
      continue;
    }
    LOG(INFO) << "done get item " << item_id;
    std::string subject_title = base::StringReplace(reco_item.title(), "\t", "", true);
    subject_title = base::StringReplace(subject_title, "\n", "", true);
    // LOG(INFO) << reco_item.raw_item().Utf8DebugString();
    if (reco_item.identity().type() == reco::kThemeVideo) {
      get_subject_subitems(reco_item, &subitems_vec, doc_get_item, 10);
    }
    if (FLAGS_api == 2) {
      // get subject tag
      std::string subject_tag = FeatureVectorToString(reco_item.tag());
      // get subject subitem ifno
      for (size_t idx = 0; idx < subitems_vec.size(); idx++) {
        auto& subitem = subitems_vec.at(idx);
        std::string subitem_title = base::StringReplace(subitem.title(), "\t", "", true);
        subitem_title = base::StringReplace(subitem_title, "\n", "", true);

        auto feature_vector = subitem.tag();
        std::string subitem_tag = FeatureVectorToString(feature_vector);
        if (subitem_tag == "") {
          subitem_tag = "NULL";
        }

        fout << item_id << "\t"
             << subject_title <<"\t"
             << subject_tag << "\t"
             << subitem.identity().item_id() << "\t"
             << subitem_title << "\t"
             << subitem_tag << std::endl;
      }
    }
  }

  fout.close();

  delete doc_get_item;
  delete hbase_get_item;

  return 0;
}
