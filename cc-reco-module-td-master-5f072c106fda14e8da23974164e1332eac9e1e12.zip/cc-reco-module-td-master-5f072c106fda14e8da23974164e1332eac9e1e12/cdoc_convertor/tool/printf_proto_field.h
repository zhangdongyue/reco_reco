#pragma once
#include <vector>
#include <string>

#include "build_tools/third_party/include/google/protobuf/descriptor.h"
#include "build_tools/third_party/include/google/protobuf/message.h"
#include "base/testing/gtest.h"

// 对传人的 |field_name| 数组中的每个字段名, 到 |message| 中找到相应的字段,
// 根据字段本身的类型,选择合适的格式输出. 用 TAB 连接各个字段的输出结果
// 如果字段是 POD 类型, 以相应格式输出
// 如果字段是 repeated 的 POD 类型, 以 TAB 连接数组元素
// 如果字段是 Message, 调用 Utf8DebugString 输出各个子字段
// (TODO(zhengying) 支持 Message 类型字段的子字段输出
std::string PrintfProtoFields(const ::google::protobuf::Message* message,
                              const std::vector<std::string>& field_name);

namespace internal {
std::string PrintfSingleProtoField(const ::google::protobuf::Message* message,
                                   const ::google::protobuf::FieldDescriptor* field,
                                   const ::google::protobuf::Reflection* reflection);

std::string PrintfRepeatedProtoField(const ::google::protobuf::Message* message,
                                     const ::google::protobuf::FieldDescriptor* field,
                                     const ::google::protobuf::Reflection* reflection, int index);
}  // namespace internal
