#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <string>

#include "base/common/base.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/hdfs/hdfs_file_util.h"
#include "net/rpc_util/rpc_group.h"
#include "nlp/common/nlp_util.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/ml/feature/global_data/global_data.h"
#include "reco/module/cdoc_convertor/convertor/raw_item_convertor.h"

DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_string(hbase_reco_item_table, "tb_reco_item", "hbase table, tb_reco_item");
DEFINE_string(item_id_file, "", "");
DEFINE_string(item_id_auto_file, "", "");
DEFINE_bool(output_keyword, false, "");
DEFINE_bool(output_showtag, false, "");
DEFINE_bool(output_synonymtag, false, "");
DEFINE_bool(output_region, false, "");
DEFINE_bool(output_source, false, "");
DEFINE_bool(output_weight, false, "");
DEFINE_bool(recompute_reco, true, "");

bool GetRecoItemFromItemKeeper(uint64 item_id, reco::itemkeeper::ItemKeeper::Stub* rpc_stub,
                               reco::RecoItem* reco_item) {
  reco::itemkeeper::GetRecoItemRequest request;
  reco::itemkeeper::GetRecoItemResponse response;
  request.add_item_id(item_id);
  net::rpc::RpcClientController rpc;
  rpc_stub->getRecoItem(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()
      || response.reco_item_size() != 1) {
    LOG(ERROR) << "Get reco item failed. "
               << " item id: "
               << item_id << ", "
               << response.Utf8DebugString();
    return false;
  } else {
    reco_item->CopyFrom(response.reco_item(0));
  }
  return true;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "auto tag demo");
  reco::GlobalDataIns::instance().Init();

  reco::ml::GlobalDataIns::instance().Init();
  LOG(INFO) << "init ml global data time:";

  reco::redis::RedisCli* redis_cli_ = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);
  CHECK(redis_cli_->GetPool()->IsRun());

  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 2;
  options.timeout = 3000;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_item_keeper_server_ip, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_item_keeper_server_port, 3000);
    options.servers.push_back(si);
  }
  net::rpc::RpcGroup* rpc_group = new net::rpc::RpcGroup(options);
  CHECK(rpc_group->Connect());
  reco::itemkeeper::ItemKeeper::Stub* rpc_stub =
      new reco::itemkeeper::ItemKeeper::Stub(rpc_group);

  reco::RawItemConvertor raw_convertor(FLAGS_hbase_reco_item_table, redis_cli_);

  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines);

  std::ofstream ofm(FLAGS_item_id_auto_file);
  ofm << "itemid\ttype\tcategory\ttitle\turl\trecoitem_tags\tcandidate_tags\trawitem_tags";  // NOLINT
  if (FLAGS_output_keyword) {
    ofm << "\tkeyword";
  }
  if (FLAGS_output_showtag) {
    ofm << "\tshow_tag";
  }
  if (FLAGS_output_synonymtag) {
    ofm << "\tsynonymtag";
  }
  if (FLAGS_output_region) {
    ofm << "\tregion";
  }
  if (FLAGS_output_source) {
    ofm << "\torig_source_media\tsource_media\torig_source\tsource";
  }
  ofm << std::endl;

  std::vector<std::string> fields;
  for (auto it = lines.begin(); it != lines.end(); ++it) {
    if (*it == "") {
      continue;
    }
    uint64 item_id;
    if (!base::StringToUint64(*it, &item_id)) continue;

    reco::RecoItem hbase_reco_item;
    if (!GetRecoItemFromItemKeeper(item_id, rpc_stub, &hbase_reco_item)) {
      LOG(WARNING) << "can't find item in hbase, " << item_id;
      continue;
    }
    if (hbase_reco_item.identity().type() == reco::kThemeVideo) continue;

    if (FLAGS_recompute_reco) {
      if (!raw_convertor.UpdateRecoItem(&hbase_reco_item, NULL)) continue;
    }
    if (hbase_reco_item.category_size() == 0) {
      VLOG(1) << "no category ! item_id:" << item_id;
      continue;
    }

    std::string out_category = "";
    if (hbase_reco_item.category_size() > 0) {
      out_category += hbase_reco_item.category(0);
    }
    if (hbase_reco_item.category_size() > 1) {
      out_category += ",";
      out_category += hbase_reco_item.category(1);
    }

    std::string out_tags = "";
    for (int i = 0; i < hbase_reco_item.tag().feature_size(); ++i) {
      std::ostringstream oss;
      oss << hbase_reco_item.tag().feature(i).weight();
      out_tags += hbase_reco_item.tag().feature(i).literal();
      if (FLAGS_output_weight) {
        out_tags += ":";
        out_tags += oss.str();
      }
      if (i != hbase_reco_item.tag().feature_size() - 1) {
        out_tags += ",";
      }
    }

    std::string out_semantic_tags = "";
    for (int i = 0; i < hbase_reco_item.semantic_tag().feature_size(); ++i) {
      out_semantic_tags += hbase_reco_item.semantic_tag().feature(i).literal();
      if (i != hbase_reco_item.semantic_tag().feature_size() - 1) {
        out_semantic_tags += ",";
      }
    }

    std::string out_candidate_tags = "";
    for (int i = 0; i < hbase_reco_item.candidate_tag().feature_size(); ++i) {
      out_candidate_tags += hbase_reco_item.candidate_tag().feature(i).literal();
      if (i != hbase_reco_item.candidate_tag().feature_size() - 1) {
        out_candidate_tags += ",";
      }
    }

    std::string out_rawitem_tags = "";
    for (int i = 0; i < hbase_reco_item.spider_tags_size(); ++i) {
      out_rawitem_tags += hbase_reco_item.spider_tags(i);
      if (i != hbase_reco_item.spider_tags_size() - 1) {
        out_rawitem_tags += ",";
      }
    }

    std::string out_keywords = "";
    for (int i = 0; i < hbase_reco_item.keyword().feature_size() && i < 10; ++i) {
      out_keywords += hbase_reco_item.keyword().feature(i).literal();
      if (i != hbase_reco_item.keyword().feature_size() - 1) {
          out_keywords += ",";
      }
    }

    std::string out_show_tag = "";
    for (int i = 0; i < hbase_reco_item.show_tag_size(); ++i) {
      out_show_tag += hbase_reco_item.show_tag(i);
      if (i != hbase_reco_item.show_tag_size() - 1) {
        out_show_tag += ",";
      }
    }

    std::string out_synonymtag = "";
    for (int i = 0; i < hbase_reco_item.synonymous_tags_size(); ++i) {
      out_synonymtag +=  hbase_reco_item.synonymous_tags(i);
      if (i != hbase_reco_item.synonymous_tags_size() - 1) {
        out_synonymtag += ",";
      }
    }

    std::vector<std::string> regions;
    regions.push_back(hbase_reco_item.region());
    regions.push_back(hbase_reco_item.region_from_title());
    regions.push_back(hbase_reco_item.region_restrict());

    std::string out_source = "";
    if (hbase_reco_item.has_orig_source_media()) {
      out_source.append(hbase_reco_item.orig_source_media());
    }
    out_source.append("\t");
    if (hbase_reco_item.has_source_media()) {
      out_source.append(hbase_reco_item.source_media());
    }
    out_source.append("\t");
    if (hbase_reco_item.has_orig_source()) {
      out_source.append(hbase_reco_item.orig_source());
    }
    out_source.append("\t");
    out_source.append(hbase_reco_item.source());

    // 输出

    ofm << item_id << "\t" << (int)hbase_reco_item.identity().type() << "\t"
        << out_category << "\t" << hbase_reco_item.title() << "\t"
        << hbase_reco_item.original_url()  << "\t";
    ofm << out_tags;
    if (out_semantic_tags != "") {
      if (out_tags != "") {
        ofm << ",";
      }
      ofm << out_semantic_tags;
    }
    ofm << "\t" << out_candidate_tags << "\t" << out_rawitem_tags;
    if (FLAGS_output_keyword) {
      ofm << "\t" << out_keywords;
    }
    if (FLAGS_output_showtag) {
      ofm << "\t" << out_show_tag;
    }
    if (FLAGS_output_synonymtag) {
      ofm << "\t" << out_synonymtag;
    }
    if (FLAGS_output_region) {
      ofm  << "\t" << base::JoinStrings(regions, ",");
    }
    if (FLAGS_output_source) {
      ofm << "\t" << out_source;
    }
    ofm << std::endl;
  }

  ofm.close();

  delete redis_cli_;
  return 0;
}
