#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <string>

#include "base/common/base.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "net/rpc_util/rpc_group.h"
#include "nlp/common/nlp_util.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/ml/feature/global_data/global_data.h"

DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_string(item_id_file, "", "");
DEFINE_string(item_id_auto_file, "", "");

bool GetRecoItemFromItemKeeper(uint64 item_id, reco::itemkeeper::ItemKeeper::Stub* rpc_stub,
                               reco::RecoItem* reco_item) {
  reco::itemkeeper::GetRecoItemRequest request;
  reco::itemkeeper::GetRecoItemResponse response;
  request.add_item_id(item_id);
  net::rpc::RpcClientController rpc;
  rpc_stub->getRecoItem(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()
      || response.reco_item_size() != 1) {
    LOG(ERROR) << "Get reco item failed. "
               << " item id: "
               << item_id << ", "
               << response.Utf8DebugString();
    return false;
  } else {
    reco_item->CopyFrom(response.reco_item(0));
  }
  return true;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "auto tag demo");

  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 2;
  options.timeout = 3000;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_item_keeper_server_ip, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_item_keeper_server_port, 3000);
    options.servers.push_back(si);
  }
  net::rpc::RpcGroup* rpc_group = new net::rpc::RpcGroup(options);
  CHECK(rpc_group->Connect());
  reco::itemkeeper::ItemKeeper::Stub* rpc_stub =
      new reco::itemkeeper::ItemKeeper::Stub(rpc_group);

  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines);

  std::ofstream ofm(FLAGS_item_id_auto_file);
  ofm << "itemid\ttype\tcategory\ttitle\turl\tcrawler_copyright\tposter_clarity\tvideo_clarity" << std::endl;

  int total_reco_item = 0;
  int has_pc = 0;
  int has_vc = 0;
  std::vector<std::string> fields;
  for (auto it = lines.begin(); it != lines.end(); ++it) {
    if (*it == "") {
      continue;
    }
    uint64 item_id;
    if (!base::StringToUint64(*it, &item_id)) continue;

    reco::RecoItem keeper_reco_item;
    if (!GetRecoItemFromItemKeeper(item_id, rpc_stub, &keeper_reco_item)) {
      LOG(WARNING) << "can't find item in hbase, " << item_id;
      continue;
    }
    if (keeper_reco_item.identity().type() == reco::kThemeVideo) continue;
    total_reco_item += 1;

    std::string out_category = "";
    if (keeper_reco_item.category_size() > 0) {
      out_category += keeper_reco_item.category(0);
    }
    if (keeper_reco_item.category_size() > 1) {
      out_category += ",";
      out_category += keeper_reco_item.category(1);
    }

    int copyright = -1;
    if (keeper_reco_item.has_crawler_info() && keeper_reco_item.crawler_info().has_copyright_type()) {
      copyright = keeper_reco_item.crawler_info().copyright_type();
    }
    if (copyright != -1) {
      has_pc += 1;
    }
    double poster_clarity = -1.0;
    double video_clarity = -1.0;
    if (keeper_reco_item.video_meta_settings_size() > 0) {
      const reco::VideoMetaSetting& vms = keeper_reco_item.video_meta_settings(0);
      if (vms.has_poster_clarity()) {
        poster_clarity = vms.poster_clarity();
      }
      if (vms.has_video_clarity()) {
        video_clarity = vms.video_clarity();
      }
    }
    if (poster_clarity != -1.0) {
      has_pc += 1;
    }
    if (video_clarity != -1.0) {
      has_vc += 1;
    }

    // 输出
    ofm << item_id << "\t" << (int)keeper_reco_item.identity().type() << "\t"
        << out_category << "\t" << keeper_reco_item.title() << "\t"
        << keeper_reco_item.original_url()  << "\t"
        << copyright << "\t"
        << poster_clarity << "\t"
        << video_clarity << "\t";
    ofm << std::endl;
  }

  ofm.close();

  if (total_reco_item > 0) {
    std::cout << "total_recoitem:" << total_reco_item
              << ", has_poster_clarity:" << has_pc << "(" << 1.0 * has_pc / total_reco_item << ")"
              << ", has_video_clarity:" << has_vc << "(" << 1.0 * has_vc / total_reco_item << ")"
              << std::endl;
  }
  return 0;
}
