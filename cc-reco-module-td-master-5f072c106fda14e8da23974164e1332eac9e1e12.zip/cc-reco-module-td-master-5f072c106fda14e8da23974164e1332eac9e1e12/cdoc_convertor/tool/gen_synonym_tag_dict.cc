#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <map>

#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/strings/utf_char_iterator.h"

// 并查集生成同义词词典

DEFINE_string(synonym_tag_dict, "synonym_tag.txt", "生成的synonym_tag字典路径");
DEFINE_string(synonym_candidates, "synonym_candidates.txt", "同义词两两配对的数据");

std::map<std::string, std::string> pre;
std::map<std::string, int> count;

std::string Find(const std::string &x) {
  std::string r = x;
  while (pre[r] != r) {
    r = pre[r];
  }

  // 压缩路径
  std::string i = x;
  while (i != r) {
    std::string j = pre[i];
    pre[i] = r;
    i = j;
  }

  return pre[r];
}

void Join(const std::string &x, const std::string &y) {
  auto fx = Find(x);
  auto fy = Find(y);
  if (fx != fy) {
    LOG(INFO) << fx << ":" << count[fx] << "\t" << fy << ":" << count[fy];
    if (count[fx] < count[fy]) {
      pre[fx] = fy;
    } else {
      pre[fy] = fx;
    }
  }
}

bool NeedFilter(const std::string& tag) {
  int utf8_len;
  if (!base::GetUTF8CharNum(tag, &utf8_len)) {
    return true;
  }
  return utf8_len < 2;
}

void GenSameTagDict() {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(FLAGS_synonym_candidates, &lines)) {
    LOG(ERROR) << "open synonym candidates fail:" << FLAGS_synonym_candidates;
    return;
  }

  for (size_t i = 0; i < lines.size(); ++i) {
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() < 4) {
      continue;
    }
    if (NeedFilter(tokens[0]) || NeedFilter(tokens[2])) {
      continue;
    }
    int show_num;
    if (base::StringToInt(tokens[1], &show_num)) {
      count[tokens[0]] = show_num;
    }
    if (base::StringToInt(tokens[3], &show_num)) {
      count[tokens[2]] = show_num;
    }
    if (tokens[0] == tokens[2]) {
      continue;
    }
    pre[tokens[0]] = tokens[0];
    pre[tokens[2]] = tokens[2];
  }

  for (size_t i = 0; i < lines.size(); ++i) {
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() < 4) {
      continue;
    }
    if (NeedFilter(tokens[0]) || NeedFilter(tokens[2])) {
      continue;
    }
    if (tokens[0] == tokens[2]) {
      continue;
    }
    Join(tokens[0], tokens[2]);
  }

  std::map<std::string, std::vector<std::string> > ans;
  for (auto it = pre.begin(); it != pre.end(); ++it) {
    std::string root = Find(it->first);
    if (ans.find(root) == ans.end()) {
      std::vector<std::string> synonym_tags;
      ans[root] = synonym_tags;
    }
    if (root == it->first) {
      continue;
    }
    ans[root].push_back(it->first);
  }
  std::ofstream fout(FLAGS_synonym_tag_dict);
  for (auto it = ans.begin(); it != ans.end(); ++it) {
    if (it->second.size() > 2 || it->second.size() <= 0) {
      continue;
    }

    fout << it->first << "\t" << base::JoinStrings(it->second, "\t") << std::endl;
  }
  fout.close();
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "gen synonym_tag_dict");
  GenSameTagDict();
  return 0;
}
