#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>

#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/proto/item.pb.h"
//#include "reco/bizc/proto/
#include "base/common/base.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_number_conversions.h"
#include "reco/module/cdoc_convertor/breaking/breaking_recognition.h"

DEFINE_string(hbase_reco_item_table, "tb_reco_item", "hbase table, tb_reco_item");
DEFINE_string(item_id_file, "", "");
DEFINE_string(item_keeper_server_ips, "11.251.202.129,11.251.202.194,11.251.202.213", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_int32(item_keeper_server_timeout, 3000, "");
DEFINE_int32(keeper_thread_num, 10, "");
DEFINE_string(item_file, "", "");

// Deprecated
void GetRecoItemThread(reco::HBaseGetItem* item_getter,
                     std::vector<std::string>* items,
                     std::vector<reco::RecoItem>* reco_item_vec,
                     int thread_id) {
  CHECK_EQ(items->size(), reco_item_vec->size());

  int process_num = 0;
  reco::RecoItem base_reco;
  base_reco.mutable_identity()->set_item_id(0);

  for (int idx = thread_id; idx < (int)items->size(); idx += 10) {
    ++process_num;
    if (process_num % 500 == 0) {
      LOG(INFO) << "item thread " << thread_id << " process " << process_num << " item.";
    }
    const std::string& itemid = items->at(idx);
    uint64 intid;
    if (!base::StringToUint64(itemid, &intid)) {
      LOG(ERROR) << "itemid erro " << itemid;
      continue;
    }   
    reco::RecoItem& reco_item = reco_item_vec->at(idx);

    if (!item_getter->GetRecoItem(intid, &reco_item)) {
      LOG(ERROR) << "get reco item error " << itemid;
      reco_item.CopyFrom(base_reco);
    }
  }

  LOG(INFO) << "item thread " << thread_id << " process " << process_num << " item.";
}

void GetKeeperThread(reco::ItemKeeperGetItem* item_getter,
                     std::vector<std::string>* items,
                     std::vector<reco::RecoItem>* reco_item_vec,
                     int thread_id) {
  CHECK_EQ(items->size(), reco_item_vec->size());

  int process_num = 0;
  reco::RecoItem base_reco;
  base_reco.mutable_identity()->set_item_id(0);

  for (int idx = thread_id; idx < (int)items->size(); idx += FLAGS_keeper_thread_num) {
    ++process_num;
    if (process_num % 500 == 0) {
      LOG(INFO) << "keeper thread " << thread_id << " process " << process_num << " item.";
    }
    const std::string& itemid = items->at(idx);
    uint64 intid;
    if (!base::StringToUint64(itemid, &intid)) {
      LOG(ERROR) << "itemid erro " << itemid;
      continue;
    }
    reco::RecoItem& reco_item = reco_item_vec->at(idx);

    if (!item_getter->GetRecoItem(intid, &reco_item)) {
      LOG(ERROR) << "get reco item error " << itemid;
      reco_item.CopyFrom(base_reco);
    }
  }

  LOG(INFO) << "keeper thread " << thread_id << " process " << process_num << " item.";
}

void GetKeeperData(std::vector<reco::RecoItem>* reco_item_vec) {
  std::vector<std::string> items;
  base::file_util::ReadFileToLines(FLAGS_item_id_file, &items);

  //LoadItemList(&items);
  LOG(INFO) << "begin to get keeper data, req num:" << items.size();

  reco::ItemKeeperGetItem item_getter = reco::ItemKeeperGetItem(FLAGS_item_keeper_server_ips, FLAGS_item_keeper_server_port);

  //std::vector<reco::RecoItem> reco_item_vec;
  reco_item_vec->resize(items.size());

  thread::ThreadPool keeper_pool(FLAGS_keeper_thread_num);
  for (int i = 0; i < FLAGS_keeper_thread_num; ++i) {
    keeper_pool.AddTask(::NewCallback(GetKeeperThread, &item_getter, &items, reco_item_vec, i));
  }
  keeper_pool.JoinAll();

  /*
  std::ofstream ofs(FLAGS_region_file);
  for (size_t idx = 0; idx < reco_item_vec->size(); ++idx) {
    const reco::RecoItem& data = reco_item_vec->at(idx);
    ofs << items[idx] << "\t"
        << data.region() << std::endl;
  }
  ofs.close();
  */
  LOG(INFO) << "finish to get keeper data, ret num:" << reco_item_vec->size();
}

void ExtractRecoItemFromFile(std::vector<reco::RecoItem>* reco_items) {
  CHECK(reco_items);
  reco_items->clear();

  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_item_file, &lines);
  LOG(INFO) << "process item size, " << lines.size();

  std::vector<std::string> flds;
  for (size_t i = 0; i < lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() != 8) {
      LOG(WARNING) << "line format error, " << lines[i];
      continue;
    }
    uint64 item_id;
    if (!base::StringToUint64(flds[0], &item_id)) {
      LOG(WARNING) << "item error, " << lines[i];
      continue;
    }

    reco::RecoItem item;

    std::vector<std::string> cate_vec;
    base::SplitString(flds[1], ",", &cate_vec);
    //  LOG(WARNING) << "cate error, " << lines[i];
    //  continue;
    //}
    //::google::protobuf::RepeatedPtrField<std::string> cates;
    //cates.Reserve(cate_vec.size());
    for (size_t j = 0; j < cate_vec.size(); ++j) {
      //*(cates.Add()) = cate_vec[j];
      std::string* cate = item.add_category();
      *cate = cate_vec[j];
    }
    item.mutable_identity()->set_item_id(item_id);
    //item.set_category(cates);
    item.set_source(flds[2]);
    item.set_orig_source(flds[3]);
    item.set_publish_time(flds[4]);
    item.set_title(flds[5]);
    item.set_create_time(flds[6]);
    item.set_region(flds[7]);

    reco_items->push_back(item);
  }
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "breaking news recognition demo");

  //reco::hbase::HBasePoolIns::instance().Init();
  //CHECK(reco::hbase::HBasePoolIns::instance().is_inited());

  //reco::HBaseGetItem* hbase_get_item = new reco::HBaseGetItem(FLAGS_hbase_reco_item_table, 0);

  reco::common::BreakingRecognition br("");

  std::vector<reco::RecoItem> reco_items;

  if (!FLAGS_item_id_file.empty()) {
    GetKeeperData(&reco_items);
  } else if (!FLAGS_item_file.empty()) {
    ExtractRecoItemFromFile(&reco_items);
  }

  //hbase_get_item->GetRecoItems(lines, &hbase_reco_items);

  //for (auto it = lines.begin(); it != lines.end(); ++it) {
  for (auto it = reco_items.begin(); it != reco_items.end(); ++it) {
    /*
    if (*it == "") {
      continue;
    }
    */

    //uint64 item_id;
    //if (!base::StringToUint64(*it, &item_id)) continue;

    /*
    reco::RecoItem hbase_reco_item;
    if (!hbase_get_item->GetRecoItem(item_id, &hbase_reco_item)) {
      LOG(WARNING) << "can not find item in hbase, " << item_id;
      continue;
    }
    */

    std::vector<reco::common::BreakingProperty> v;
    //std::cout << it->title() << "\n";
    if (br.ExtractBreakingProperty(*it, &v)) {
      //std::cout << "--------------------- item id: " << it->identity().item_id();
      std::vector<std::string> cate_buf;
      for (auto i = 0; i < it->category_size(); ++i) {
        cate_buf.push_back(it->category(i));
      }
      for (auto iter = v.begin(); iter != v.end(); ++iter) {
        std::cout << it->identity().item_id()
             << "\t" << it->title()
             << "\t" << iter->event_id
             << "\t" << iter->event_literal
             << "\t" << iter->reliability
             << "\t" << iter->start_time
             << "\t" << iter->stop_time
             << "\t" << base::JoinStrings(cate_buf, "|")
             << "\n";

        /*
        std::cout << "\ntitle: " << it->title()
             << "\nevent_id: " << iter->event_id
             << "\nevent_literal: " << iter->event_literal
             << "\nreliability: " << iter->reliability
             << "\nstart_time: " << iter->start_time
             << "\nstop_time: " << iter->stop_time
             << "\ncategory: " << base::JoinStrings(cate_buf, "|")
             << "\n";
             */
      }
    }
  }
  
  return 0;
}
