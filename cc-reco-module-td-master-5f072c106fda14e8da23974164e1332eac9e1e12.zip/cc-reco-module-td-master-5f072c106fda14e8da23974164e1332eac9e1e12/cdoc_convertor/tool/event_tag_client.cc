#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/encoding/line_escape.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc_util/rpc_group.h"

#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"

DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_string(item_id_file, "", "item_id \t event_tag_item_id \t event_name");
DEFINE_string(hbase_table, "reco", "shcema");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "convertor client");
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited()) << "init hbase pool first";

  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = 3000;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_item_keeper_server_ip, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_item_keeper_server_port, 3000);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup* rpc_group = new net::rpc::RpcGroup(options);
  CHECK(rpc_group->Connect());
  reco::itemkeeper::ItemKeeper::Stub* rpc_stub =
      new reco::itemkeeper::ItemKeeper::Stub(rpc_group);

  reco::HBaseGetItem* get_item_service_ = new reco::HBaseGetItem(FLAGS_hbase_table, 0);

  std::string line;
  std::string key;
  std::string value;

  std::vector<std::string> item_id_list;
  base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);

  std::vector<std::string> fields;
  for (int i = 0; i < (int)item_id_list.size(); ++i) {
    if (item_id_list[i].empty() || item_id_list[i][0] == '#') continue;

    fields.clear();
    base::SplitString(item_id_list[i], "\t", &fields);
    if (fields.size() < 3 || fields[0].empty() || fields[1].empty() || fields[2].empty()) continue;

    uint64 item_id;
    if (!base::StringToUint64(fields[0], &item_id)) {
      LOG(ERROR) << "StringToUint64 fail ! item_id_str:" << fields[0];
      continue;
    }
    LOG(INFO) << "get item " << item_id;

    uint64 event_tag_item_id;
    if (!base::StringToUint64(fields[1], &event_tag_item_id)) {
      LOG(ERROR) << "StringToUint64 fail ! item_id_str:" << fields[1];
      continue;
    }

    std::string event_tag = fields[2];

    reco::RecoItem old_reco_item;
    if (!get_item_service_->GetRecoItem(item_id, &old_reco_item)) {
      LOG(INFO) << "faile to get item from hbase: " << item_id;
      continue;
    }

    reco::RecoItem new_reco_item;
    bool found = false;
    for (int i = 0; i < (int)old_reco_item.event_tag_info_size(); ++i) {
      if (old_reco_item.event_tag_info(i).event_tag_name() == event_tag) {
        found = true;
      }
      reco::EventTagInfo* eti = new_reco_item.add_event_tag_info();
      eti->set_event_tag_name(old_reco_item.event_tag_info(i).event_tag_name());
      eti->set_event_item_id(old_reco_item.event_tag_info(i).event_item_id());
    }
    if (!found) {
      reco::EventTagInfo* eti = new_reco_item.add_event_tag_info();
      eti->set_event_tag_name(event_tag);
      eti->set_event_item_id(event_tag_item_id);
    }

    reco::itemkeeper::UpdateItemRequest request;
    reco::itemkeeper::UpdateItemFieldResponse response;
    request.mutable_service_identity()->set_service_name("event_tag");
    request.set_item_id(item_id);
    new_reco_item.SerializePartialToString(request.mutable_reco_item_bytes());

    net::rpc::RpcClientController rpc;
    rpc_stub->updateItemFields(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "set item event tag failed ! item id: " << item_id << ", response: "
                 << response.Utf8DebugString();
      continue;
    } else {
      LOG(INFO) << "done set item event tag: " << item_id;
      continue;
    }
  }

  delete rpc_stub;
  delete rpc_group;
  delete get_item_service_;

  return 0;
}
