#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/encoding/line_escape.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc_util/rpc_group.h"

#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_handler.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"

#include "extend/json/jansson/jansson.h"
#include "reco/module/cdoc_convertor/tool/subject_utils.h"

DEFINE_string(convertor_server_ip, "100.85.69.71", "server ip");
DEFINE_int32(convertor_server_port, 20021, "server port");
DEFINE_int32(time_out, 1000, "rpc time out");
DEFINE_string(item_id, "", "");
DEFINE_string(item_id_file, "", "");
DEFINE_string(manual_fields, "", "逗号分隔开不同的字段");

DEFINE_string(doc_server_ips, "100.85.69.71", "doc server ips, splitted by ,");
DEFINE_int32(doc_server_port, 20013, "doc server port");

DEFINE_int32(api, 0,
             "API: 0-convertRawItem, 1-convertRecoItem, 2-extractFeature, 3-updateItem");

DEFINE_bool(is_return_tag, true, "");
DEFINE_bool(is_return_keyword, true, "");
DEFINE_bool(is_return_bow, true, "");
DEFINE_bool(is_return_plsa, true, "");
DEFINE_bool(is_return_category_plsa, true, "");
DEFINE_bool(is_return_category, true, "");
DEFINE_bool(is_return_rubbish, true, "");
DEFINE_string(hbase_reco_item_table, "tb_reco_item", "hbase table, tb_reco_item");


int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "convertor client");

  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());

  reco::HBaseGetItem* hbase_get_item =
      new reco::HBaseGetItem(FLAGS_hbase_reco_item_table, 0);

  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = FLAGS_time_out;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_convertor_server_ip, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_convertor_server_port, FLAGS_time_out);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup* rpc_group = new net::rpc::RpcGroup(options);
  CHECK(rpc_group->Connect());
  reco::convertor::ConvertorService::Stub* convertor_stub =
      new reco::convertor::ConvertorService::Stub(rpc_group);

  reco::itemhandler::ItemHandler::Stub* handler_stub =
      new reco::itemhandler::ItemHandler::Stub(rpc_group);

  reco::DocServerGetItem* doc_get_item =
      new reco::DocServerGetItem(FLAGS_doc_server_ips, FLAGS_doc_server_port, 0);

  std::vector<std::string> manual_fields_vec;
  if (!FLAGS_manual_fields.empty()) {
    base::SplitString(FLAGS_manual_fields, ",", &manual_fields_vec);
  }

  std::string line;
  std::string key;
  std::string value;

  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }

  for (int i = 0; i < (int)item_id_list.size(); ++i) {
    reco::RecoItem reco_item;
    std::vector<reco::RecoItem> subitems_vec;
    uint64 item_id = base::ParseUint64OrDie(item_id_list[i]);
    LOG(INFO) << "get item " << item_id;
    if (!doc_get_item->GetRecoItem(item_id, &reco_item)
        && !hbase_get_item->GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "failed to get reco item: " << item_id;
      continue;
    }
    LOG(INFO) << "done get item " << item_id;
    // LOG(INFO) << reco_item.raw_item().Utf8DebugString();
    if (reco_item.identity().type() == reco::kThemeVideo) {
      get_subject_subitems(reco_item, &subitems_vec, doc_get_item, 10);
    }

    if (FLAGS_api == 1) {
      // convert reco item
      reco::convertor::ConvertRecoItemRequest request;
      reco::convertor::ConvertRecoItemResponse response;
      request.mutable_reco_item()->CopyFrom(reco_item);
      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(FLAGS_time_out);
      convertor_stub->convertRecoItem(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()) {
        LOG(ERROR) << "convert reco item failed. " << response.err_msg();
      } else {
        std::cout <<"Response: " << response.Utf8DebugString() << std::endl;
      }
    } else if (FLAGS_api == 2) {
      reco::convertor::ExtractFeatureRequest request;
      reco::convertor::ExtractFeatureResponse response;
      request.set_title(reco_item.title());
      request.set_content(reco_item.content());
      for (int i = 0; i < reco_item.category_size(); i++) {
        request.add_category(reco_item.category(i));
      }
      request.set_return_tag(FLAGS_is_return_tag);
      request.set_return_keyword(FLAGS_is_return_keyword);
      request.set_return_bow(FLAGS_is_return_bow);
      request.set_return_plsa(FLAGS_is_return_plsa);
      request.set_return_category_plsa(FLAGS_is_return_category_plsa);
      request.set_return_category(FLAGS_is_return_category);
      request.set_return_rubbish(FLAGS_is_return_rubbish);
      std::cout <<"Request:  " << request.Utf8DebugString() << std::endl;

      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(FLAGS_time_out);
      convertor_stub->extractFeature(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()) {
        LOG(ERROR) << "extract feature failed. " << response.err_msg();
      } else {
        std::cout <<"Response: " << response.Utf8DebugString() << std::endl;
      }
    } else if (FLAGS_api == 3) {
      reco::itemhandler::ItemHandlerRequest request;
      reco::itemhandler::ItemHandlerResponse response;
      request.mutable_reco_item()->CopyFrom(reco_item);
      for (int idx = 0; idx < (int)manual_fields_vec.size(); ++idx) {
        request.add_updated_fields(manual_fields_vec[idx]);
        request.add_manual_set_fields(manual_fields_vec[idx]);
      }
      // add subitem
      if (reco_item.identity().type() == reco::kThemeVideo) {
        for (size_t j = 0; j < subitems_vec.size(); ++j) {
          request.add_child_items()->CopyFrom(subitems_vec.at(j));
        }
      }

      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(FLAGS_time_out);
      handler_stub->updateItem(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()) {
        LOG(ERROR) << "extract feature failed. " << response.err_message();
      } else {
        std::cout <<"Response: " << response.Utf8DebugString() << std::endl;
      }
    }
  }

  delete convertor_stub;
  delete handler_stub;
  delete rpc_group;
  delete doc_get_item;
  delete hbase_get_item;

  return 0;
}
