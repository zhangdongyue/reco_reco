#include <iostream>

#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/base/kafka_c/api_cc/producer.h"
#include "reco/bizc/proto/item.pb.h"

#include "base/common/base.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

DEFINE_string(brokers, "11.251.176.1:9092", "broker list");
DEFINE_string(topic, "test_reco_item_new", "topic name");
DEFINE_int32(partition_num, 32, "partition");
DEFINE_int32(consume_num, 10, "");
DEFINE_bool(set_ts, false, "");

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "convertor kafka client");

  const int64 cur_timestamp = base::GetTimestamp() / 1e6;

  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_topic;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = "convertor_test_group";
  options.partition_num = FLAGS_partition_num;
  if (FLAGS_set_ts) {
    options.start_timestamp = cur_timestamp;
  }

  reco::kafka::Message msg;
  reco::kafka::Consumer consumer(FLAGS_brokers, options);
  for (auto i = 0; i < FLAGS_consume_num; ++i) {
    if (!consumer.Consume(&msg)) {
      std::cout << "consume failed:" << msg.errcode << std::endl;
      continue;
    }

    reco::RecoItem reco_item;
    if (!reco_item.ParseFromString(msg.content)) {
      std::cout << "parse failed." << std::endl;
      continue;
    }

    std::cout << reco_item.Utf8DebugString() << std::endl;
  }
}

