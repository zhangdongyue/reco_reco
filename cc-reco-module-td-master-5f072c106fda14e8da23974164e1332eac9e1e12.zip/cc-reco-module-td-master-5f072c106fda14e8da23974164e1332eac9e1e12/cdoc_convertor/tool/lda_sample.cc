#include <set>
#include <string>
#include <sstream>
#include <fstream>
#include <iostream>
#include "base/strings/string_printf.h"
#include "reco/bizc/item_service/hbase_get_item.h"

#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"

#include "nlp/common/nlp_util.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "serving_base/mysql_util/db_conn_manager.h"

#include "reco/module/cdoc_convertor/plda/tokenizer.h"
#include "reco/module/cdoc_convertor/plda/inference_engine.h"
#include "reco/bizc/proto/item_keeper.pb.h"
// #include "reco/module/cdoc_convertor/plda/tokenizer.h"

#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"
#include "extend/json/jansson/jansson.h"
#include "reco/module/cdoc_convertor/tool/subject_utils.h"

DEFINE_string(item_keeper_ips, "", "item keeper ips");
DEFINE_int32(item_keeper_port, 0, "");

DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table, tb_reco_item");

DEFINE_string(input_file, "input.id", "");
DEFINE_string(output_path, "result", "");

DEFINE_int32(extract_thread_num, 8, "extract thread num");
DEFINE_string(data_path, "data", "");
DEFINE_double(cutting_threshold, 0.1, "cutting_threshold");
DEFINE_int32(subject_use_subitem_title, 0, "0-只用主题标题 1-使用主题子文的标题");
DEFINE_int32(subject_max_subitem_num, 10, "如果使用主题子文，选用子文的最大数目");
class TopicResult {
 public:
  int topic_id;
  double value;

  uint64 item_id;
  std::string title;
  std::string cate;
  int item_type;
  bool operator>(const TopicResult& another) const {
    return value > another.value;
  }
};

void SaveResult(thread::BlockingQueue<TopicResult>* results) {
  std::vector<std::vector<TopicResult>> output_results;
  for (size_t i = 0; i < 5000; ++i) {
    output_results.push_back(std::vector<TopicResult>());
  }
  TopicResult topic_result;
  while (!(results->Closed() && results->Empty())) {
    int status = results->TryTake(&topic_result);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    output_results[topic_result.topic_id].push_back(topic_result);
  }

  for (size_t j = 0; j < output_results.size(); ++j) {
    std::vector<TopicResult>& one_topic_result = output_results[j];
    if (one_topic_result.size() == 0) continue;
    std::ofstream fout(FLAGS_output_path + "/topic_" +base::IntToString(j)+".txt");
    std::sort(one_topic_result.begin(), one_topic_result.end(), std::greater<TopicResult>());
    fout << "topic: " << j << std::endl;
    for (size_t i = 0; i < one_topic_result.size(); ++i) {
      const TopicResult& result = one_topic_result[i];
      fout << result.value << "\t" << result.item_id << "\t" << result.item_type << "\t" << result.title << std::endl;
    }
    fout.close();
  }
}

void ExtractLDATopic(std::vector<uint64>* input_queue,
                     thread::BlockingQueue<TopicResult>* results,
                     thread::BlockingVar<int>* finish_num) {
  reco::HBaseGetItem hbase_pool_get_item(FLAGS_hbase_item_table, 0);
  std::vector<reco::RecoItem> items;
  LOG(WARNING) << "准备读取数据";
  hbase_pool_get_item.GetRecoItems(*input_queue, &items);
  // 初始化 lda
  reco::Tokenizer* tokenizer = new reco::SimpleTokenizer(FLAGS_data_path + "/" + "vocab_info.txt");
  reco::InferenceEngine* lda_engine =
                    new reco::InferenceEngine(FLAGS_data_path, FLAGS_data_path + "/" + "lda.conf");
  std::vector<std::string> words;
  std::vector<reco::Topic> topics;
  for (size_t i = 0; i < items.size(); ++i) {
    std::string nor_content = "";
    std::string title = items[i].normalized_title();
    std::vector<reco::RecoItem> subitem_vec;
    if (items[i].identity().type() == reco::kThemeVideo && FLAGS_subject_use_subitem_title == 1) {
      get_subject_subitems(items[i], &subitem_vec, &hbase_pool_get_item, FLAGS_subject_max_subitem_num);
      for (size_t j = 0; j < subitem_vec.size(); ++j) {
        const reco::RecoItem& subitem = subitem_vec.at(j);
        nor_content += subitem.normalized_title() + " ";
      }
      title += nor_content;
    }

    words.clear();
    topics.clear();
    tokenizer->tokenize(title, words);
    reco::LDADoc doc;
    lda_engine->infer(words, doc);
    doc.sparse_topic_dist(topics);

    reco::itemkeeper::UpdateItemRequest update_request;

    const reco::RecoItem& reco_item = items[i];
    for (size_t j = 0; j < topics.size(); ++j) {
      if (topics[j].prob < FLAGS_cutting_threshold) continue;
      TopicResult topic_result;
      topic_result.item_id = reco_item.identity().item_id();
      topic_result.title = reco_item.normalized_title();
      topic_result.cate = "None";
      if (reco_item.category_size() >= 1) {
        topic_result.cate = reco_item.category(0);
      }
      if (reco_item.category_size() == 2) {
        topic_result.cate.append("|");
        topic_result.cate.append(reco_item.category(1));
      }
      topic_result.topic_id = topics[j].tid;
      topic_result.value = topics[j].prob;
      topic_result.item_type = items[i].identity().type();
      results->Put(topic_result);
    }
  }

  int n = finish_num->Take() + 1;
  if (n == FLAGS_extract_thread_num) {
    results->Close();
  }
  CHECK(finish_num->TryPut(n));
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "generate trainning samples");
  std::vector<std::vector<uint64>*> input_queue;
  thread::BlockingQueue<TopicResult> results;
  thread::BlockingVar<int> finish_num;

  thread::ThreadPool pool(FLAGS_extract_thread_num + 1);
  CHECK(finish_num.TryPut(0));

  std::string line;
  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    input_queue.push_back(new std::vector<uint64>());
  }

  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_input_file, &lines);
  std::vector<uint64> item_ids;
  for (size_t i = 0; i < lines.size(); ++i) {
    uint64 item_id;
    if (!base::StringToUint64(lines[i], &item_id)) continue;
    input_queue[item_id % FLAGS_extract_thread_num]->push_back(item_id);
  }
  LOG(INFO) << "线程开始启动";
  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    pool.AddTask(::NewCallback(ExtractLDATopic, input_queue[i], &results, &finish_num)); // NOLINT
  }
  pool.AddTask(::NewCallback(SaveResult, &results)); // NOLINT

  pool.JoinAll();
}
