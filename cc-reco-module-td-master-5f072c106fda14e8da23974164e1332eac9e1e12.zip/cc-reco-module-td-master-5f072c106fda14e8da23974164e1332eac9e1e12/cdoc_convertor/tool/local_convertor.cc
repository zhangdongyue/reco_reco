#include <iostream>
#include <fstream>
#include <set>
#include <string>
#include <vector>

#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/module/cdoc_convertor/convertor/raw_item_convertor.h"
#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"
#include "reco/module/cdoc_convertor/tool/printf_proto_field.h"
#include "reco/bizc/proto/item.pb.h"

#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/strings/string_split.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_number_conversions.h"
#include "base/encoding/line_escape.h"

#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/counter/export.h"

#include "ads_index/proto/index.pb.h"
#include "ads_index/api/public.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

DEFINE_string(item_id, "", "");
DEFINE_string(item_id_file, "", "");
DEFINE_string(doc_server_ips, "100.85.69.71", "doc server ips, splitted by ,");
DEFINE_int32(doc_server_port, 20013, "doc server port");

DEFINE_string(hbase_table, "tb_reco_item", "hbase table");

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "local convertor");

  reco::GlobalDataIns::instance().Init();

  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited()) << "init hbase pool first";

  reco::DocServerGetItem* doc_get_item =
      new reco::DocServerGetItem(FLAGS_doc_server_ips, FLAGS_doc_server_port, 0);

  serving_base::mysql_util::DbConnManager::Option option;
  option.host = FLAGS_db_host;
  option.user = FLAGS_db_user;
  option.passwd = FLAGS_db_passwd;
  option.schema = FLAGS_schema;
  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(option); // NOLINT

  std::string line;
  std::string key;
  std::string value;

  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }

  reco::RawItemConvertor raw_item_convertor(FLAGS_hbase_table, db_manager);
  for (int i = 0; i < (int)item_id_list.size(); ++i) {
    reco::RecoItem reco_item;
    uint64 item_id = base::ParseUint64OrDie(item_id_list[i]);
    if (!doc_get_item->GetRecoItem(item_id, &reco_item, false)) {
      LOG(ERROR) << "failed to get reco item: " << item_id;
      continue;
    }
    const reco::RawItem& raw_item = reco_item.raw_item();

    reco::RecoItem reco_item1;
    if (!raw_item_convertor.ConvertToRecoItem(raw_item, &reco_item1)) {
      LOG(ERROR) << "Failed to convert to RecoItem, id=" << raw_item.identity().Utf8DebugString();
      continue;
    } else {
      LOG(INFO) << "done convert " << raw_item.identity().item_id();
    }

    // std::cout << PrintfProtoFields(&reco_item, field_names) << std::endl;
  }

  delete db_manager;
  delete doc_get_item;
  return 0;
}
