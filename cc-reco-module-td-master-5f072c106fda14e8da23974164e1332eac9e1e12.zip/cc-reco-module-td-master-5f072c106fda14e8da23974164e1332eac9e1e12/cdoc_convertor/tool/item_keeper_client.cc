#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/encoding/line_escape.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc_util/rpc_group.h"

#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"

DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_string(item_id, "", "");
DEFINE_string(item_id_file, "", "");
DEFINE_int32(api, 0, "0/1/2");

DEFINE_string(doc_server_ips, "11.251.203.139", "doc server ips, splitted by ,");
DEFINE_int32(doc_server_port, 20013, "doc server port");

DEFINE_bool(output_item, false, "if true, output item to stdout");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "convertor client");

  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = 3000;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_item_keeper_server_ip, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_item_keeper_server_port, 3000);
    options.servers.push_back(si);
  }

  reco::DocServerGetItem* doc_get_item =
      new reco::DocServerGetItem(FLAGS_doc_server_ips, FLAGS_doc_server_port, 0);

  net::rpc::RpcGroup* rpc_group = new net::rpc::RpcGroup(options);
  CHECK(rpc_group->Connect());
  reco::itemkeeper::ItemKeeper::Stub* rpc_stub =
      new reco::itemkeeper::ItemKeeper::Stub(rpc_group);

  std::string line;
  std::string key;
  std::string value;

  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }

  for (int i = 0; i < (int)item_id_list.size(); ++i) {
    reco::RecoItem reco_item;
    uint64 item_id = base::ParseUint64OrDie(item_id_list[i]);
    LOG(INFO) << "get item " << item_id;

    if (FLAGS_api == 0) {
      // convert raw item
      reco::itemkeeper::RefreshRecoItemRequest request;
      reco::itemkeeper::RefreshRecoItemResponse response;
      request.mutable_service_identity()->set_service_name("index_builder");
      request.add_item_id(item_id);
      // request.add_exclude_storages(reco::itemkeeper::kCdocQueue);
      // request.add_exclude_storages(reco::itemkeeper::kRecoItemQueue);
      request.add_exclude_storages(reco::itemkeeper::kItemInfoTable);
      net::rpc::RpcClientController rpc;
      rpc_stub->refreshRecoItem(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()
          || response.reco_item_size() != 1) {
        LOG(ERROR) << "refresh reco item failed. "
                   << " item id: "
                   << item_id << ", "
                   << response.Utf8DebugString();
        return false;
      } else {
        LOG(INFO) << "done refresh reco item: " << item_id;
        if (FLAGS_output_item) {
          reco_item.CopyFrom(response.reco_item(0));
          std::cout << reco_item.Utf8DebugString() << std::endl;
        }
      }
    } else if (FLAGS_api == 1) {
      // convert reco item
      reco::itemkeeper::GetRecoItemRequest request;
      reco::itemkeeper::GetRecoItemResponse response;
      request.add_item_id(item_id);

      net::rpc::RpcClientController rpc;
      rpc_stub->getRecoItem(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()
          || response.reco_item_size() != 1) {
        LOG(ERROR) << "refresh reco item failed. "
                   << " item id: "
                   << item_id << ", "
                   << response.Utf8DebugString();
        return false;
      } else {
        LOG(INFO) << "done get reco item: " << item_id;
        if (FLAGS_output_item) {
          reco_item.CopyFrom(response.reco_item(0));
          std::cout << reco_item.Utf8DebugString() << std::endl;
        }
      }
    } else if (FLAGS_api == 2) {
      if (!doc_get_item->GetRecoItem(item_id, &reco_item, false)) {
        LOG(ERROR) << "failed to get reco item: " << item_id;
        continue;
      }
      // reco::itemkeeper::CreateRecoItemRequest request;
      // reco::itemkeeper::CreateRecoItemResponse response;
      reco::itemkeeper::UpdateItemRequest request;
      reco::itemkeeper::UpdateItemFieldResponse response;
      request.mutable_service_identity()->set_service_name("index_builder");
      // request.mutable_reco_item()->CopyFrom(reco_item);
      request.set_item_id(item_id);
      reco_item.SerializeToString(request.mutable_reco_item_bytes());
      request.add_exclude_storages(reco::itemkeeper::kCdocQueue);
      request.add_exclude_storages(reco::itemkeeper::kRecoItemQueue);
      request.add_exclude_storages(reco::itemkeeper::kItemInfoTable);
      request.set_partial_update(false);

      net::rpc::RpcClientController rpc;
      // rpc_stub->createRecoItem(&rpc, &request, &response, NULL);
      rpc_stub->updateItemFields(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()) {
        LOG(ERROR) << "refresh reco item failed. "
                   << " item id: "
                   << item_id << ", "
                   << response.Utf8DebugString();
        continue;
      } else {
        LOG(INFO) << "done update reco item: " << item_id;
      }
    }
  }

  delete rpc_stub;
  delete rpc_group;
  delete doc_get_item;

  return 0;
}
