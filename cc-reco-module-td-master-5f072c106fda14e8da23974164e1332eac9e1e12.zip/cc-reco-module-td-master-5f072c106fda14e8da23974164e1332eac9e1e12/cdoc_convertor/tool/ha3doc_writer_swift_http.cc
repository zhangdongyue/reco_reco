#include <map>
#include "reco/module/cdoc_convertor/server/ha3doc_writer.h"

#include "reco/bizc/proto/item.pb.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/logging.h"
#include "reco/base/common/uri_process.h"

DEFINE_string(swift_gw_server_ip, "11.180.61.8", "ip address of  swift_gw server");
DEFINE_int32(swift_gw_server_port, 10073, "port of  swift_gw server");
DEFINE_string(swift_gw_server_path, "/sendmsg", "path of  swift_gw server");
DEFINE_string(swift_topic, "news_ha3_test", "topic of  swift");
DEFINE_int32(swift_gw_server_connect_timeout, 300, "connect timeout of  swift_gw server");
DEFINE_int32(swift_gw_server_transfer_timeout, 400, "transfer timeout of  swift_gw server");
DEFINE_int32(swift_retry_num, 3, "retry of  swift_gw server");

namespace reco {

Ha3DocWriter::Ha3DocWriter()
{
  web_client_ = new net::WebClient;
  web_client_->Init();
}

Ha3DocWriter::~Ha3DocWriter() {
  delete web_client_;
}


/*TODO:
  正式上线需要改swift c++ client调用。因为http方式走gateway太慢，100~200ms响应时间
  并增加重试
 */
bool Ha3DocWriter::AddHa3doc(const std::string & doc, const ItemIdentity& identity, std::string* err_msg) {
	std::string topic_encoded = reco::common::EncodeUrlComponent(std::string(FLAGS_swift_topic));
	std::string doc_encoded = reco::common::EncodeUrlComponent(doc);

	net::WebClient::Request request;
	net::WebClient::Response response;
	request.url = base::StringPrintf("http://%s:%d%s?t=%s&p=0&msg=%s",
			FLAGS_swift_gw_server_ip.c_str(),
			FLAGS_swift_gw_server_port,
			FLAGS_swift_gw_server_path.c_str(), topic_encoded.c_str(), doc_encoded.c_str());
	request.method = ::net::HTTPConstants::kGET;

    //LOG(INFO) << "push ha3doc url=[" << request.url <<"]";
	request.connect_timeout_in_ms = FLAGS_swift_gw_server_connect_timeout;
	request.transfer_timeout_in_ms = FLAGS_swift_gw_server_transfer_timeout;

	int n_retry=0;
	while(n_retry<FLAGS_swift_retry_num){
		web_client_->AddTask(&request, &response, NULL);
		web_client_->JoinAll();

		LOG(INFO) << "push ha3doc res" 
			<< ", retry="<<n_retry
			<< ", success="<<response.success
			<< ", curl_code="<<response.curl_code
			<< ", error_desc="<<response.error_desc
			<< ", http_code="<<response.http_response_code
			//<< ", http_header="<<response.http_header
			//<< ", http_body="<<response.http_body
			<< ", t="<<response.crawl_duration;

		if(response.success){
			break;
		}

		n_retry ++;
	}

	return true;
}

}

