#include <set>
#include <string>
#include <sstream>
#include <fstream>
#include <iostream>
#include "base/strings/string_printf.h"
#include "reco/bizc/item_service/hbase_get_item.h"

#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"

#include "nlp/common/nlp_util.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "serving_base/mysql_util/db_conn_manager.h"

#include "reco/module/cdoc_convertor/plda/tokenizer.h"
#include "reco/module/cdoc_convertor/plda/inference_engine.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/module/cdoc_convertor/plda/tokenizer.h"

#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"

DEFINE_string(item_keeper_ips, "", "item keeper ips");
DEFINE_int32(item_keeper_port, 0, "");

DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table, tb_reco_item");

DEFINE_string(input_file, "input.id", "");
DEFINE_string(output_file, "result.txt", "");

DEFINE_int32(extract_thread_num, 200, "extract thread num");
DEFINE_int32(push_thread_num, 50, "extract thread num");

DEFINE_string(data_path, "data", "");
DEFINE_int32(type, 1, "1=刷数据 2=验证数据");

void inline TransTopci2FeatureVector(const std::vector<reco::Topic>& topics, reco::FeatureVector* fv) {
  fv->set_norm(1.0);
  fv->clear_feature();
  for (size_t i = 0; i < topics.size(); ++i) {
    const reco::Topic& topic = topics[i];
    auto it = fv->add_feature();
    it->set_literal(base::StringPrintf("topic-%d", topic.tid));
    it->set_weight(topic.prob);
  }
}

void PushWorker(thread::BlockingQueue<reco::itemkeeper::UpdateItemRequest>* requests) {
  std::vector<std::string> ips;
  base::SplitString(FLAGS_item_keeper_ips, ",", &ips);
  base::SplitString(FLAGS_item_keeper_ips, ",", &ips);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 2;
  options.timeout = 5000;
  for (int i = 0; i < (int) ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], FLAGS_item_keeper_port, options.timeout);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup channel(options);
  CHECK(channel.Connect());
  reco::itemkeeper::ItemKeeper::Stub stub(&channel);

  reco::itemkeeper::UpdateItemRequest result;
  std::vector<std::string> cates;
  while (!(requests->Closed() && requests->Empty())) {
    int status = requests->TryTake(&result);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    net::rpc::RpcClientController rpc;
    rpc.SetTimeout(5000);
    reco::itemkeeper::UpdateItemFieldResponse update_response;
    stub.updateItemFields(&rpc, &result, &update_response, NULL);
    rpc.Wait();
    if (rpc.status() == net::rpc::RpcClientController::kDeadlineExceeded) {
      LOG(ERROR) << "update parent timeout for: " << result.item_id();
      continue;
    }

    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !update_response.success()) {
      LOG(ERROR) << "update parent failed: " << result.item_id();
      continue;
    }
    LOG(INFO) << "finish update: " << result.item_id();
    CHECK_EQ(status, 1) << "fucking status " << status;
  }
}

void ExtractLDATopic(std::vector<uint64>* input_queue,
                     thread::BlockingQueue<reco::itemkeeper::UpdateItemRequest>* requests,
                     thread::BlockingVar<int>* finish_num) {
  reco::HBaseGetItem hbase_pool_get_item(FLAGS_hbase_item_table, 0);
  std::vector<reco::RecoItem> items;
  LOG(WARNING) << "准备读取数据";
  hbase_pool_get_item.GetRecoItems(*input_queue, &items);
  // 初始化 lda
  reco::Tokenizer* tokenizer = new reco::SimpleTokenizer(FLAGS_data_path + "/" + "vocab_info.txt");
  reco::InferenceEngine* lda_engine = new reco::InferenceEngine(FLAGS_data_path, FLAGS_data_path + "/" + "lda.conf");
  std::vector<std::string> words;
  std::vector<reco::Topic> topics;
  for (size_t i = 0; i < items.size(); ++i) {
    const std::string& title = items[i].normalized_title();
    uint64 item_id = items[i].raw_item().identity().item_id();

    words.clear();
    topics.clear();
    tokenizer->tokenize(title, words);
    reco::LDADoc doc;
    lda_engine->infer(words, doc);
    doc.sparse_topic_dist(topics);

    reco::itemkeeper::UpdateItemRequest update_request;

    reco::RecoItem reco_item;
    auto title_lda = reco_item.mutable_title_lda();
    TransTopci2FeatureVector(topics, title_lda);
    update_request.mutable_service_identity()->set_service_name("lda_topic_offline");
    update_request.set_item_id(item_id);
    update_request.add_exclude_storages(reco::itemkeeper::kCdocQueue);
    update_request.add_exclude_storages(reco::itemkeeper::kRecoItemQueue);
    if (!reco_item.SerializePartialToString(update_request.mutable_reco_item_bytes())) {
      LOG(ERROR) << "fail to transfer reco item for : " << item_id;
    }
    if (FLAGS_type == 1) {
      requests->Put(update_request);
    } else if (FLAGS_type == 2) {
      if (items[i].title_lda().feature_size() != reco_item.title_lda().feature_size()) {
        std::cout << item_id << " topic 个数不一致" << items[i].title_lda().feature_size() << "vs"
                  << reco_item.title_lda().feature_size() << std::endl;
      }
      bool has_diff = false;
      for (int j = 0; j < reco_item.title_lda().feature_size(); ++j) {
        if (items[i].title_lda().feature(j).literal().compare(reco_item.title_lda().feature(j).literal()) != 0) {
          std::cout << item_id << " 第" << j << " literal不一致" << items[i].title_lda().feature(j).literal() << " vs  "
                    << reco_item.title_lda().feature(j).literal() << std::endl;
          has_diff = true;
          break;
        }
        if (items[i].title_lda().feature(j).weight() != reco_item.title_lda().feature(j).weight()) {
          std::cout << item_id << " 第" << j << " weight不一致" << items[i].title_lda().feature(j).weight() << " vs  "
                    << reco_item.title_lda().feature(j).weight() << std::endl;
          has_diff = true;
          break;
        }
      }
      if (!has_diff) {
        std::cout << item_id << "结果一致" << std::endl;
      }
    }
  }

  int n = finish_num->Take() + 1;
  if (n == FLAGS_extract_thread_num) {
    requests->Close();
  }
  CHECK(finish_num->TryPut(n));
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "generate trainning samples");
  std::vector<std::vector<uint64>*> input_queue;
  thread::BlockingQueue<reco::itemkeeper::UpdateItemRequest> requests;
  thread::BlockingVar<int> finish_num;

  thread::ThreadPool pool(FLAGS_extract_thread_num + 1);
  CHECK(finish_num.TryPut(0));

  std::string line;
  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    input_queue.push_back(new std::vector<uint64>());
  }

  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_input_file, &lines);
  std::vector<uint64> item_ids;
  for (size_t i = 0; i < lines.size(); ++i) {
    uint64 item_id;
    if (!base::StringToUint64(lines[i], &item_id)) continue;
    input_queue[item_id % FLAGS_extract_thread_num]->push_back(item_id);
  }
  LOG(INFO) << "线程开始启动";
  for (int i = 0; i < FLAGS_push_thread_num; ++i) {
    pool.AddTask(::NewCallback(PushWorker, &requests)); // NOLINT
  }
  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    pool.AddTask(::NewCallback(ExtractLDATopic, input_queue[i], &requests, &finish_num)); // NOLINT
  }
  pool.JoinAll();
}
