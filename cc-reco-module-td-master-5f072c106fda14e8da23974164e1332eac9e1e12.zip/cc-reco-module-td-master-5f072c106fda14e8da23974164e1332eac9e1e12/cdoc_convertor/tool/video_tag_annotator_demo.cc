#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <map>

#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/strings/utf_char_iterator.h"

#include "reco/module/cdoc_convertor/tag/video_tag_annotator.h"

DEFINE_string(reco_item_feature_data_dir, "", "");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "");
  reco::VideoTagAnnotator video_tag_annotator;
  std::string line;
  while (std::getline(std::cin, line)) {
    std::vector<std::string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 3) {
      continue;
    }
    const std::string &source = tokens[0];
    const std::string &category = tokens[1];
    const std::string &title = tokens[2];
    std::vector<reco::VideoTagAnnotator::VideoTag> tags;
    video_tag_annotator.GetTags(source, category, title, &tags);
    std::vector<std::string> video_tags;
    for (size_t i = 0; i < tags.size(); ++i) {
      video_tags.push_back(tags[i].tag);
    }
    std::cout << source << "\t" << category << "\t"
       << title << "\t" << base::JoinStrings(video_tags, ",") << std::endl;
  }
  return 0;
}
