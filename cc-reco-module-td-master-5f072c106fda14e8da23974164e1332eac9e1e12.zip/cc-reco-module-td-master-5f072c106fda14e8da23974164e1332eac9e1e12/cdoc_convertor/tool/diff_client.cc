#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/encoding/line_escape.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc_util/rpc_group.h"

#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/module/cdoc_convertor/convertor/util/convertor_util.h"

DEFINE_string(convertor_server_ip1, "100.85.69.71", "server ip");
DEFINE_string(convertor_server_ip2, "100.85.69.71", "server ip");
DEFINE_int32(convertor_server_port1, 20021, "server port");
DEFINE_int32(convertor_server_port2, 20021, "server port");
DEFINE_int32(time_out, 1000, "rpc time out");
DEFINE_string(item_id, "", "");
DEFINE_string(item_id_file, "", "");

DEFINE_string(doc_server_ips, "100.85.69.71", "doc server ips, splitted by ,");
DEFINE_int32(doc_server_port, 20013, "doc server port");

DEFINE_string(cdoc_diff_file, "cdoc.diff", "");
DEFINE_string(reco_item_diff_file, "reco_item.diff", "");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "convertor client");

  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = FLAGS_time_out;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_convertor_server_ip1, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_convertor_server_port1, FLAGS_time_out);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup* rpc_group1 = new net::rpc::RpcGroup(options);
  CHECK(rpc_group1->Connect());

  flds.clear();
  options.servers.clear();
  base::SplitString(FLAGS_convertor_server_ip2, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_convertor_server_port2, FLAGS_time_out);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup* rpc_group2 = new net::rpc::RpcGroup(options);
  CHECK(rpc_group2->Connect());

  reco::convertor::ConvertorService::Stub* rpc_stub1 =
      new reco::convertor::ConvertorService::Stub(rpc_group1);
  reco::convertor::ConvertorService::Stub* rpc_stub2 =
      new reco::convertor::ConvertorService::Stub(rpc_group2);

  reco::DocServerGetItem* doc_get_item =
      new reco::DocServerGetItem(FLAGS_doc_server_ips, FLAGS_doc_server_port, 0);

  std::string line;
  std::string key;
  std::string value;

  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }

  std::ofstream out_reco_item;
  out_reco_item.open(FLAGS_reco_item_diff_file);
  std::ofstream out_cdoc;
  out_cdoc.open(FLAGS_cdoc_diff_file);
  int64 cdoc_diff_num = 0;
  int64 reco_item_diff_num = 0;
  for (int i = 0; i < (int)item_id_list.size(); ++i) {
    reco::RecoItem reco_item;
    uint64 item_id = base::ParseUint64OrDie(item_id_list[i]);
    // LOG(INFO) << "get item " << item_id;
    if (!doc_get_item->GetRecoItem(item_id, &reco_item, false)) {
      LOG(ERROR) << "failed to get reco item: " << item_id;
      continue;
    }
    // LOG(INFO) << "done get item " << item_id;
    // LOG(INFO) << reco_item.raw_item().Utf8DebugString();

    // convert raw item
    reco::convertor::ConvertRawItemRequest request;
    request.mutable_raw_item()->CopyFrom(reco_item.raw_item());
    request.set_convert_to_reco(true);
    request.set_convert_to_cdoc(true);

    reco::RecoItem reco_item1, reco_item2;
    adsindexing::IndexDocInfo cdoc1, cdoc2;

    {
      reco::convertor::ConvertRawItemResponse response1;
      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(FLAGS_time_out);
      rpc_stub1->convertRawItem(&rpc, &request, &response1, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response1.success()) {
        LOG(ERROR) << "convert raw item failed. resp err:" << response1.err_msg()
                   << ", rpc err:" << rpc.error_text();
        continue;
      } else {
        reco_item1.CopyFrom(response1.reco_item());
        cdoc1.CopyFrom(response1.cdoc());
      }
    }
    {
      reco::convertor::ConvertRawItemResponse response2;
      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(FLAGS_time_out);
      rpc_stub2->convertRawItem(&rpc, &request, &response2, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response2.success()) {
        LOG(ERROR) << "convert raw item failed. resp err:" << response2.err_msg()
                   << ", rpc err:" << rpc.error_text();
        continue;
      } else {
        reco_item2.CopyFrom(response2.reco_item());
        cdoc2.CopyFrom(response2.cdoc());
      }
    }

    std::string diffs;
    if (!reco::CompareMessage(cdoc1, cdoc2, &diffs, NULL)) {
      ++cdoc_diff_num;
      out_cdoc << item_id << "\t" << diffs << std::endl;
    }

    diffs.clear();
    if (!reco::CompareRecoItem(reco_item1, reco_item2, &diffs)) {
      ++reco_item_diff_num;
      out_reco_item << item_id << "\t" << diffs << std::endl;
    }
  }

  std::cout << base::StringPrintf("total item [%lu], cdoc diff [%ld], reco item diff [%ld]",
                                  item_id_list.size(), cdoc_diff_num, reco_item_diff_num)
      << std::endl;

  delete rpc_stub1;
  delete rpc_group1;
  delete rpc_stub2;
  delete rpc_group2;
  delete doc_get_item;

  out_reco_item.close();
  out_cdoc.close();
  return 0;
}
