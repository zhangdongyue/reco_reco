#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/encoding/line_escape.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc_util/rpc_group.h"

#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_handler.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/module/cdoc_convertor/convertor/util/convertor_util.h"

DEFINE_string(convertor_server_ip1, "100.85.69.71", "server ip");
DEFINE_string(convertor_server_ip2, "100.85.69.71", "server ip");
DEFINE_int32(convertor_server_port1, 20021, "server port");
DEFINE_int32(convertor_server_port2, 20021, "server port");
DEFINE_int32(time_out, 1000, "rpc time out");
DEFINE_string(item_id, "", "");
DEFINE_string(item_id_file, "", "");

DEFINE_string(doc_server_ips, "100.85.69.71", "doc server ips, splitted by ,");
DEFINE_int32(doc_server_port, 20013, "doc server port");

DEFINE_string(hbase_reco_item_table, "tb_reco_item", "hbase table, tb_reco_item");

DEFINE_string(reco_item_diff_file, "reco_item.diff", "");

DEFINE_string(manual_fields, "", "逗号分隔开不同的字段");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "diff convertor client");

  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = FLAGS_time_out;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_convertor_server_ip1, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_convertor_server_port1, FLAGS_time_out);
    options.servers.push_back(si);
  }

  reco::HBaseGetItem* hbase_get_item =
          new reco::HBaseGetItem(FLAGS_hbase_reco_item_table, 0);

  net::rpc::RpcGroup* rpc_group1 = new net::rpc::RpcGroup(options);
  CHECK(rpc_group1->Connect());

  flds.clear();
  options.servers.clear();
  base::SplitString(FLAGS_convertor_server_ip2, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_convertor_server_port2, FLAGS_time_out);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup* rpc_group2 = new net::rpc::RpcGroup(options);
  CHECK(rpc_group2->Connect());

  reco::itemhandler::ItemHandler::Stub* handler_stub1 =
          new reco::itemhandler::ItemHandler::Stub(rpc_group1);

  reco::itemhandler::ItemHandler::Stub* handler_stub2 =
          new reco::itemhandler::ItemHandler::Stub(rpc_group2);

  reco::DocServerGetItem* doc_get_item =
      new reco::DocServerGetItem(FLAGS_doc_server_ips, FLAGS_doc_server_port, 0);

  std::vector<std::string> manual_fields_vec;
  if (!FLAGS_manual_fields.empty()) {
    base::SplitString(FLAGS_manual_fields, ",", &manual_fields_vec);
  }

  std::string line;
  std::string key;
  std::string value;

  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }

  std::ofstream out_reco_item;
  out_reco_item.open(FLAGS_reco_item_diff_file);
  int64 reco_item_diff_num = 0;
  for (int i = 0; i < (int)item_id_list.size(); ++i) {
    reco::RecoItem reco_item;
    uint64 item_id = base::ParseUint64OrDie(item_id_list[i]);
    if (!doc_get_item->GetRecoItem(item_id, &reco_item)
        && !hbase_get_item->GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "failed to get reco item: " << item_id;
      continue;
    }

    // convert raw item
    reco::itemhandler::ItemHandlerRequest request;
    request.mutable_reco_item()->CopyFrom(reco_item);
    for (int idx = 0; idx < (int)manual_fields_vec.size(); ++idx) {
      request.add_updated_fields(manual_fields_vec[idx]);
      request.add_manual_set_fields(manual_fields_vec[idx]);
    }

    reco::RecoItem reco_item1, reco_item2;

    {
      reco::itemhandler::ItemHandlerResponse response1;
      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(FLAGS_time_out);
      handler_stub1->updateItem(&rpc, &request, &response1, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response1.success()) {
        LOG(ERROR) << "update reco item failed. resp err:" << response1.err_message()
                   << ", rpc err:" << rpc.error_text();
        continue;
      } else {
        reco_item1.CopyFrom(response1.reco_item());
      }
    }
    {
      reco::itemhandler::ItemHandlerResponse response2;
      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(FLAGS_time_out);
      handler_stub2->updateItem(&rpc, &request, &response2, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response2.success()) {
        LOG(ERROR) << "update reco item failed. resp err:" << response2.err_message()
                   << ", rpc err:" << rpc.error_text();
        continue;
      } else {
        reco_item2.CopyFrom(response2.reco_item());
      }
    }

    std::string diffs;
    if (!reco::CompareRecoItem(reco_item1, reco_item2, &diffs)) {
      ++reco_item_diff_num;
      out_reco_item << item_id << "\t" << diffs << std::endl;
    }
  }

  std::cout << base::StringPrintf("total item [%lu], reco item diff [%ld]",
                                  item_id_list.size(), reco_item_diff_num)
      << std::endl;

  delete handler_stub1;
  delete rpc_group1;
  delete handler_stub2;
  delete rpc_group2;
  delete doc_get_item;

  out_reco_item.close();
  return 0;
}
