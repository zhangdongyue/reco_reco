#include "reco/module/cdoc_convertor/tool/printf_proto_field.h"
#include <vector>
#include <string>

#include "base/file/file_util.h"
#include "base/file/dir_reader_posix.h"
#include "base/encoding/line_escape.h"
#include "base/common/logging.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

std::string PrintfProtoFields(const ::google::protobuf::Message* message,
                              const std::vector<std::string>& field_name) {
  const ::google::protobuf::Descriptor* descriptor = message->GetDescriptor();
  const ::google::protobuf::Reflection* reflection = message->GetReflection();
  std::vector<std::string> strs;
  strs.resize(field_name.size());
  for (int i = 0; i < (int)field_name.size(); ++i) {
    const ::google::protobuf::FieldDescriptor* field = descriptor->FindFieldByName(field_name[i]);
    if (NULL == field) continue;
    if (field->is_repeated()) {
      std::vector<std::string> repeated_field;
      for (int j = 0; j < reflection->FieldSize(*message, field); ++j) {
        repeated_field.push_back(internal::PrintfRepeatedProtoField(message, field, reflection, j));
      }
      strs[i] = base::JoinStrings(repeated_field, "\t");
    } else {
      strs[i] = internal::PrintfSingleProtoField(message, field, reflection);
    }
  }

  return base::JoinStrings(strs, "\t");
}

namespace internal {
std::string PrintfSingleProtoField(const ::google::protobuf::Message* message,
                                   const ::google::protobuf::FieldDescriptor* field,
                                   const ::google::protobuf::Reflection* reflection) {
  switch (field->type()) {
    case ::google::protobuf::FieldDescriptor::TYPE_FIXED64 :
    case ::google::protobuf::FieldDescriptor::TYPE_INT64 :
      return base::Int64ToString(reflection->GetInt64(*message, field));
    case ::google::protobuf::FieldDescriptor::TYPE_UINT64 :
      return base::Uint64ToString(reflection->GetUInt64(*message, field));
    case ::google::protobuf::FieldDescriptor::TYPE_FIXED32:
    case ::google::protobuf::FieldDescriptor::TYPE_INT32 :
      return base::IntToString(reflection->GetInt32(*message, field));
    case ::google::protobuf::FieldDescriptor::TYPE_UINT32 :
      return base::UintToString(reflection->GetUInt32(*message, field));
    case ::google::protobuf::FieldDescriptor::TYPE_STRING :
      return reflection->GetString(*message, field);
    case ::google::protobuf::FieldDescriptor::TYPE_DOUBLE :
      return base::DoubleToString(reflection->GetDouble(*message, field));
    case ::google::protobuf::FieldDescriptor::TYPE_FLOAT :
      return base::DoubleToString(reflection->GetFloat(*message, field));
    case ::google::protobuf::FieldDescriptor::TYPE_BOOL :
      return base::IntToString(reflection->GetBool(*message, field));
    default:
      std::string str = reflection->GetMessage(*message, field, NULL).Utf8DebugString();
      return base::StringReplace(str, "\n", "|", true);
  }
}

std::string PrintfRepeatedProtoField(const ::google::protobuf::Message* message,
                                     const ::google::protobuf::FieldDescriptor* field,
                                     const ::google::protobuf::Reflection* reflection, int index) {
  switch (field->type()) {
    case ::google::protobuf::FieldDescriptor::TYPE_FIXED64 :
    case ::google::protobuf::FieldDescriptor::TYPE_INT64 :
      return base::Int64ToString(reflection->GetRepeatedInt64(*message, field, index));
    case ::google::protobuf::FieldDescriptor::TYPE_UINT64 :
      return base::Uint64ToString(reflection->GetRepeatedUInt64(*message, field, index));
    case ::google::protobuf::FieldDescriptor::TYPE_FIXED32:
    case ::google::protobuf::FieldDescriptor::TYPE_INT32 :
      return base::IntToString(reflection->GetRepeatedInt32(*message, field, index));
    case ::google::protobuf::FieldDescriptor::TYPE_UINT32 :
      return base::UintToString(reflection->GetRepeatedUInt32(*message, field, index));
    case ::google::protobuf::FieldDescriptor::TYPE_STRING :
      return reflection->GetRepeatedString(*message, field, index);
    case ::google::protobuf::FieldDescriptor::TYPE_DOUBLE :
      return base::DoubleToString(reflection->GetRepeatedDouble(*message, field, index));
    case ::google::protobuf::FieldDescriptor::TYPE_FLOAT :
      return base::DoubleToString(reflection->GetRepeatedFloat(*message, field, index));
    case ::google::protobuf::FieldDescriptor::TYPE_BOOL :
      return base::IntToString(reflection->GetRepeatedBool(*message, field, index));
    default:
      std::string str = reflection->GetRepeatedMessage(*message, field, index).Utf8DebugString();
      return base::StringReplace(str, "\n", "|", true);
  }
}
}  // namespace internal

