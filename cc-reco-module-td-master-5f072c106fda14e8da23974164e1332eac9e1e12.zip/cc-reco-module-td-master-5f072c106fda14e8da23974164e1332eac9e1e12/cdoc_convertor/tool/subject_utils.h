#pragma once

#include <unordered_map>
#include <string>
#include <vector>
#include "base/strings/string_split.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "base/common/base.h"
#include "extend/json/jansson/jansson.h"

void get_subject_subitems(const reco::RecoItem& reco_item,
                          std::vector<reco::RecoItem>* subitem_vec,
                          reco::DocServerGetItem* doc_get_item,
                          const size_t max_num = 10) {
  if (reco_item.identity().type() != reco::kThemeVideo || reco_item.content().empty()) {
    return;
  }
  const std::string& content = reco_item.content();

  json_error_t json_error;
  json_t *json = json_loads(content.c_str(), &json_error);
  if (json == NULL || json->type != JSON_ARRAY) {
    LOG(WARNING) << "Failed to load line: " << json_error.line;
    return;
  }

  uint64 sub_id = 0;

  unsigned int size = json_array_size(json);
  for (unsigned int i = 0u; i < size; ++i) {
    if (subitem_vec->size() > max_num) {
      break;
    }
    json_t* obj = json_array_get(json, i);
    if (obj == NULL) {
      LOG(WARNING) << "content json error, json: " << content;
      continue;
    }

    json_t* item_id_json = json_object_get(obj, "item_id");
    if (!json_is_string(item_id_json)
        || !base::StringToUint64(json_string_value(item_id_json), &sub_id)) {
      json_type type = item_id_json == NULL ? JSON_NULL : json_typeof(item_id_json);
      LOG(WARNING) << "content get subject item_id error, json_type: " << type;
      continue;
    }

    reco::RecoItem sub_item;
    if (!doc_get_item->GetRecoItem(sub_id, &sub_item)) {
      //  && !hbase_get_item->GetRecoItem(sub_id, &sub_item)) {
      LOG(ERROR) << "failed to get reco item: " << sub_id;
      continue;
    }
    VLOG(1) << "subject id:" << reco_item.identity().item_id() << ","
            << " get sub id:" << sub_item.identity().item_id();
    subitem_vec->push_back(sub_item);
  }
}
void get_subject_subitems(const reco::RecoItem& reco_item,
                          std::vector<reco::RecoItem>* subitem_vec,
                          reco::HBaseGetItem* hbase_get_item,
                          size_t max_subitem_num) {
  if (reco_item.identity().type() != reco::kThemeVideo || reco_item.content().empty()) {
    return;
  }
  const std::string& content = reco_item.content();
  json_error_t json_error;
  json_t *json = json_loads(content.c_str(), &json_error);
  if (json == NULL || json->type != JSON_ARRAY) {
    LOG(WARNING) << "Failed to load line: " << json_error.line;
    return;
  }

  uint64 sub_id = 0;
  std::vector<uint64> input_queue;
  unsigned int size = json_array_size(json);
  for (unsigned int i = 0u; i < size; ++i) {
    if (input_queue.size() > max_subitem_num) {
      break;
    }
    json_t* obj = json_array_get(json, i);
    if (obj == NULL) {
      LOG(WARNING) << "content json error, json: " << content;
      continue;
    }

    json_t* item_id_json = json_object_get(obj, "item_id");
    if (!json_is_string(item_id_json)
        || !base::StringToUint64(json_string_value(item_id_json), &sub_id)) {
      json_type type = item_id_json == NULL ? JSON_NULL : json_typeof(item_id_json);
      LOG(WARNING) << "content get subject item_id error, json_type: " << type;
      continue;
    }
    input_queue.push_back(sub_id);
  }
  hbase_get_item->GetRecoItems(input_queue, subitem_vec);
}
