#pragma once
#include <string>
#include "net/web_client/web_client.h"

namespace reco {
class ItemIdentity;
// thraed safe, singletone usage
class Ha3DocWriter {
 public:
	 Ha3DocWriter();
	 ~Ha3DocWriter();

	 bool AddHa3doc(const std::string & doc, const ItemIdentity& identity, std::string* err_msg);

 private:
	 net::WebClient *web_client_;
};
}
