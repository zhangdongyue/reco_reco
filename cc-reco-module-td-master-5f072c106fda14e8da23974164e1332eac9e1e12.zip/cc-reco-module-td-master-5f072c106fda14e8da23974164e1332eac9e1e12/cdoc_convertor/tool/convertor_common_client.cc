#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/encoding/line_escape.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc_util/rpc_group.h"

#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_handler.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"

DEFINE_string(convertor_server_ip, "100.85.69.71", "server ip");
DEFINE_string(input, "input.txt", "server ip");
DEFINE_int32(convertor_server_port, 20021, "server port");
DEFINE_int32(time_out, 1000, "rpc time out");
DEFINE_bool(is_return_tag, true, "");
DEFINE_bool(is_return_category, true, "");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "convertor client");

  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = FLAGS_time_out;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_convertor_server_ip, ",", &flds);
  for (int i = 0; i < (int) flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_convertor_server_port, FLAGS_time_out);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup* rpc_group = new net::rpc::RpcGroup(options);
  CHECK(rpc_group->Connect());
  reco::convertor::ConvertorService::Stub* convertor_stub =
          new reco::convertor::ConvertorService::Stub(rpc_group);

  reco::itemhandler::ItemHandler::Stub* handler_stub =
          new reco::itemhandler::ItemHandler::Stub(rpc_group);

  std::string line;
  std::string key;
  std::string value;

  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_input, &lines);
  std::vector<std::string> tokens;
  for (int i = 0; i < (int) lines.size(); ++i) {
    reco::convertor::ExtractFeatureRequest request;
    reco::convertor::ExtractFeatureResponse response;
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens[0].empty()) {
      request.set_title(tokens[1]);
    } else {
      request.set_title(tokens[0]);
    }

    if (tokens[1].empty()) {
      request.set_content(tokens[0]);
    } else {
      request.set_content(tokens[1]);
    }
    request.set_return_tag(false);
    request.set_return_keyword(false);
    request.set_return_bow(false);
    request.set_return_plsa(false);
    request.set_return_category_plsa(false);
    request.set_return_category(true);
    request.set_return_rubbish(false);

    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(FLAGS_time_out);
    convertor_stub->extractFeature(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "extract feature failed. " << response.err_msg();
    } else {
      if (response.category_size() == 1) {
        std::cout << " 分类结果:" << response.category(0) << " " << lines[i] << std::endl;
      } else {
        std::cout << " 分类结果:" << response.category(0) << "," << response.category(1) << " " << lines[i] << std::endl;
      }
    }
  }
  delete convertor_stub;
  delete handler_stub;
  delete rpc_group;

  return 0;
}
