// Copyright (c) 2017, Baidu.com, Inc. All Rights Reserved
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
//
// Author: chenzeyu01@baidu.com

#include "inference_engine.h"

#include <algorithm>
#include <fstream>
#include <stdlib.h>
#include <memory>

namespace reco {
inline void load_config(const std::string& config_file, ModelConfig* config) {
  std::ifstream fin(config_file);

  std::string line;
  std::vector<std::string> tokens;

  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, " ", &tokens);
    const std::string& key = tokens[0];
    const std::string& value = tokens[2];
    if (key == "type") {
      if (value == "LDA") {
        config->type = ModelType::LDA;
      } else if (value == "SLDA") {
        config->type = ModelType::SLDA;
      }
    } else if (key == "num_topics") {
      base::StringToInt(value, &config->num_topics);
    } else if (key == "alpha") {
      double v;
      base::StringToDouble(value, &v);
      config->alpha = static_cast<float>(v);
    } else if (key == "beta") {
      double v;
      base::StringToDouble(value, &v);
      config->beta = static_cast<float>(v);
    } else if (key == "word_topic_file") {
      config->word_topic_file = base::StringReplace(value, "\"", "", true);
    } else if (key == "vocab_file") {
      config->vocab_file = base::StringReplace(value, "\"", "", true);
    }
  }
}

InferenceEngine::InferenceEngine(const std::string& model_dir,
                                 const std::string& conf_file,
                                 SamplerType type) {
  LOG(INFO) << "Inference Engine initializing...";
  // 读取模型配置和模型
  ModelConfig config;
  load_config(conf_file, &config);
  //load_prototxt(model_dir + "/" + conf_file, config);
  _model = std::make_shared<TopicModel>(model_dir, config);

  // 根据配置初始化采样器
  if (type == SamplerType::GibbsSampling) {
    _sampler = std::unique_ptr<Sampler>(new GibbsSampler(_model));
  } else if (type == SamplerType::MetropolisHastings) {
    _sampler = std::unique_ptr<Sampler>(new MHSampler(_model));
  }

  LOG(INFO) << "InferenceEngine initialize successfully!";
}

int InferenceEngine::infer(const std::vector<std::string>& input, LDADoc& doc) const {
  base::PseudoRandom* pseudo_random = new base::PseudoRandom();
  doc.init(_model->num_topics());
  doc.set_alpha(_model->alpha());
  for (size_t i = 0; i < input.size(); ++i) {
    int id = _model->term_id(input[i]);
    if (id != OOV) {
      int init_topic = pseudo_random->GetInt(0, _model->num_topics() - 1);
      doc.add_token({init_topic, id});
    }
  }

  lda_infer(doc, 20, 50, pseudo_random);
  delete pseudo_random;
  return 0;
}

int InferenceEngine::infer(const std::vector<std::vector<std::string>>& input, SLDADoc& doc) const {
  base::PseudoRandom* pseudo_random = new base::PseudoRandom();
  doc.init(_model->num_topics());
  doc.set_alpha(_model->alpha());
  std::vector<int> words;

  for (size_t i = 0; i < input.size(); ++i) {
    const std::vector<std::string>& sent = input[i];
    for (size_t j = 0; j < sent.size(); ++j) {
      const std::string& token = sent[j];
      int id = _model->term_id(token);
      if (id != OOV) {
        words.push_back(id);
      }
    }
    // 随机初始化
    int init_topic = pseudo_random->GetInt(0, _model->num_topics() - 1);
    doc.add_sentence({init_topic, words});
    words.clear();
  }

  slda_infer(doc, 20, 50, pseudo_random);
  delete pseudo_random;
  return 0;
}

void InferenceEngine::lda_infer(LDADoc& doc, int burn_in_iter, int total_iter, base::PseudoRandom* random) const {
  CHECK_GE(burn_in_iter, 0);
  CHECK_GT(total_iter, 0);
  CHECK_GT(total_iter, burn_in_iter);

  for (int iter = 0; iter < total_iter; ++iter) {
    _sampler->sample_doc(doc, random);
    if (iter >= burn_in_iter) {
      // 经过burn-in阶段后, 对每轮采样的结果进行累积，以得到更平滑的分布
      doc.accumulate_topic_sum();
    }
  }
}

void InferenceEngine::slda_infer(SLDADoc& doc, int burn_in_iter, int total_iter, base::PseudoRandom* random) const {
  CHECK_GE(burn_in_iter, 0);
  CHECK_GT(total_iter, 0);
  CHECK_GT(total_iter, burn_in_iter);

  for (int iter = 0; iter < total_iter; ++iter) {
    _sampler->sample_doc(doc, random);
    if (iter >= burn_in_iter) {
      // 经过burn-in阶段后，对每轮采样的结果进行累积，以得到更平滑的分布
      doc.accumulate_topic_sum();
    }
  }
}
} // namespace familia
