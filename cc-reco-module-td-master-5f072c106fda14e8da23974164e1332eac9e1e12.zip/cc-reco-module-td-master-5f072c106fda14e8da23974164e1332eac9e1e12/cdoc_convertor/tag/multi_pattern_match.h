#pragma once
#include <vector>
#include <string>
#include <queue>
#include <unordered_map>

#include "base/common/basic_types.h"
#include "base/common/slice.h"
#include "base/file/file_path.h"

namespace reco {
class Automation {
 public:
  Automation();
  ~Automation();

  void TrieInsert(const std::string& word, const int& word_index);

  void AutomationBuild();

  void TrieFind(const std::string& title, std::vector<int>* ans);

 private:
  struct Trie {
    std::vector<Trie*> child;
    std::unordered_map<int, int> local_map;
    int map_num;
    int word_index;
    int char_index;
    Trie* fail;
    Trie() {
      map_num = 0;
      word_index = -1;
      char_index = -1;
    }
  };

  void GetUTFChars(const std::string& str, std::vector<std::string>* utf_chars);
  void AutomationInit();
  void TrieDelete(Trie* node);

  Trie* root_;
  int char_num_;
  std::unordered_map<std::string, int> char_map_;
  std::queue<Trie*> bfs_queue;
};
}
