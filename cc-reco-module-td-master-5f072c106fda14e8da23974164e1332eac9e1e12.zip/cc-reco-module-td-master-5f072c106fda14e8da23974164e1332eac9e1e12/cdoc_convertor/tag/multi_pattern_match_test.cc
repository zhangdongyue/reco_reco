#include "reco/module/cdoc_convertor/tag/multi_pattern_match.h"

#include <vector>
#include <queue>
#include <unordered_map>
#include <utility>
#include <fstream>
#include <algorithm>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/slice.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/testing/gtest.h"
#include "nlp/common/nlp_util.h"

namespace reco {
class AutomationTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    automation_ = new Automation();
  }

  virtual void TearDown() {
    delete automation_;
  }

  Automation *automation_;
};

TEST_F(AutomationTest, TESTMATCH) {
  automation_->TrieInsert("你好", 1);
  automation_->TrieInsert("再见", 2);
  automation_->TrieInsert("谢谢", 3);
  automation_->TrieInsert("hhhh", 4);
  automation_->TrieInsert("谢谢你", 5);
  automation_->AutomationBuild();
  std::vector<int> ans;
  automation_->TrieFind("谢谢你好再见", &ans);
  // sort(ans.begin(), ans.end());
  EXPECT_EQ((int)ans.size(), 4);
  EXPECT_EQ(ans[0], 3);
  EXPECT_EQ(ans[1], 5);
  EXPECT_EQ(ans[2], 1);
  EXPECT_EQ(ans[3], 2);
}
}
