#include "reco/module/cdoc_convertor/tag/video_tag_annotator.h"

#include <set>
#include <utility>
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "nlp/common/nlp_util.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"

// DEFINE_string(mysql_host, "10.99.20.42", "数据库 ip");
// DEFINE_string(mysql_user, "test", "数据库 user");
// DEFINE_string(mysql_password, "chuheridangwu", "数据库密码");
// DEFINE_string(mysql_schema, "test_reco", "数据库名");
namespace reco {

VideoTagAnnotator::VideoTagAnnotator(const std::string& base_dir) {
  tag_matcher_ = new TagMatch(base_dir + "/video_tag");
  video_attr_level_annotator_ = new reco::TagAnnotator(base_dir);
}

VideoTagAnnotator::~VideoTagAnnotator() {
  delete tag_matcher_;
  delete video_attr_level_annotator_;
}

bool VideoTagAnnotator::GetTags(const std::string& source,
                                const std::string& orig_source,
                                const std::string& category,
                                const std::string& title,
                                std::vector<VideoTag>* video_tags) {
  std::string nor_title = nlp::util::NormalizeLine(title);
  std::vector<VideoTag> rule_tags;
  // 根据规则打标签
  if (ExtractTagFromRule(category, nor_title, &rule_tags)) {
    video_tags->insert(video_tags->end(), rule_tags.begin(), rule_tags.end());
  }

  // 根据源打标签
  std::vector<VideoTag> source_tags;
  if (ExtractTagFromSource(source, orig_source, &source_tags)) {
    video_tags->insert(video_tags->end(), source_tags.begin(), source_tags.end());
  }

  // 根据书名号等符号提取标签
  // std::vector<VideoTag> special_tags;
  // if (ExtractTagBetweenPunctuation(nor_title, "《", "》", &special_tags)) {
  //   video_tags->insert(video_tags->end(), special_tags.begin(), special_tags.end());
  // }

  return !video_tags->empty();
}

bool VideoTagAnnotator::ExtractTagFromRule(const std::string& category,
                                           const std::string& nor_title,
                                           std::vector<VideoTag>* rule_tags) {
  std::vector<std::string> tags;
  // 规则打标签
  tag_matcher_->GetTags(category, nor_title, &tags);
  DeleteSubTags(&tags);
  ConvertStringToVideoTag(tags, "rule", rule_tags);
  return !rule_tags->empty();
}

bool VideoTagAnnotator::ExtractTagFromSource(const std::string& source,
                                             const std::string& orig_source,
                                             std::vector<VideoTag>* source_tags) {
  auto source_tags_dict = GlobalDataIns::instance().GetSourceTagDict();
  source_tags->clear();

  auto it = source_tags_dict->find(orig_source);
  if (it != source_tags_dict->end()) {
    ConvertStringToVideoTag(it->second, "source", source_tags);
    return true;
  } else {
    auto it_s = source_tags_dict->find(source);
    if (it_s != source_tags_dict->end()) {
      ConvertStringToVideoTag(it_s->second, "source", source_tags);
      return true;
    }
    return false;
  }
}

bool VideoTagAnnotator::ExtractTagBetweenPunctuation(const std::string& title,
                                                     const std::string& left_punctuation,
                                                     const std::string& right_punctuation,
                                                     std::vector<VideoTag>* special_tags) {
  std::vector<std::string> tags;
  if (title.find(left_punctuation) == std::string::npos ||
      title.find(right_punctuation) == std::string::npos) {
    return false;
  }
  tags.clear();
  std::vector<size_t> left_index;
  std::vector<size_t> right_index;
  size_t left = title.find(left_punctuation);
  while (left != std::string::npos) {
    left_index.push_back(left);
    left = title.find(left_punctuation, left + 1);
  }
  size_t right = title.find(right_punctuation);
  while (right != std::string::npos) {
    right_index.push_back(right);
    right = title.find(right_punctuation, right + 1);
  }

  std::vector<std::pair<size_t, size_t> > range;
  std::set<size_t> used_right_index;
  for (int i = left_index.size() - 1; i >= 0; --i) {
    for (size_t j = 0; j < right_index.size(); ++j) {
      if (left_index[i] < right_index[j] && used_right_index.find(right_index[j]) == used_right_index.end()) {
        range.push_back(std::make_pair(left_index[i], right_index[j]));
        used_right_index.insert(right_index[j]);
        break;
      }
    }
  }
  for (size_t i = 0; i < range.size(); ++i) {
    tags.push_back(title.substr(range[i].first + left_punctuation.size(),
                                range[i].second - range[i].first - right_punctuation.size()));
    VLOG(1) << "extract between punctuation " << tags.back();
  }
  DeleteSubTags(&tags);
  ConvertStringToVideoTag(tags, "bookmarks", special_tags);

  return !special_tags->empty();
}

void VideoTagAnnotator::DeleteSubTags(std::vector<std::string> *tags) {
  std::set<std::string> merge_tags;
  for (size_t i = 0; i < tags->size(); ++i) {
    merge_tags.insert(tags->at(i));
  }
  tags->clear();
  for (auto it = merge_tags.begin(); it != merge_tags.end(); ++it) {
    tags->push_back(*it);
  }
  std::vector<std::string> swap_tags;
  for (size_t i = 0; i < tags->size(); ++i) {
    bool is_sub_tag = false;
    for (size_t j = 0; j < tags->size(); ++j) {
      if (i == j) {
        continue;
      }
      if (tags->at(j).find(tags->at(i)) != std::string::npos) {
        is_sub_tag = true;
        break;
      }
    }
    if (!is_sub_tag) {
      swap_tags.push_back(tags->at(i));
    }
  }
  tags->swap(swap_tags);
}

void VideoTagAnnotator::ConvertStringToVideoTag(const std::vector<std::string>& tags,
                                                const std::string& type,
                                                std::vector<VideoTag>* video_tags) {
  video_tags->clear();
  static const int kDefaultTf = 10;
  for (size_t i = 0; i < tags.size(); ++i) {
    video_tags->push_back(VideoTag(tags[i], kDefaultTf, type));
  }
}

VideoAttr::VideoVulgarLevel VideoTagAnnotator::GetVideoVulgarLevel(const std::string& title) {
  VideoAttr::VideoVulgarLevel vulgar_level = VideoAttr::kNotVulgar;
  std::set<reco::TagAnnotator::Tag> video_tags;
  int vulgar_count = 0;
  std::string vulgar_matched_str;
  if (video_attr_level_annotator_->GetTags(title, &video_tags)) {
    for (auto iter = video_tags.begin(); iter != video_tags.end(); ++iter) {
      if (iter->type == "低俗") {
        ++vulgar_count;
        vulgar_matched_str += " " + iter->literal;
      }
    }
  }
  if (vulgar_count > 0) {
    vulgar_level = VideoAttr::kHighVulgar;
    VLOG(1) << "vulgar video detected: " << title << '\t' << vulgar_matched_str;
  }
  return vulgar_level;
}

VideoAttr::VideoQualityLevel VideoTagAnnotator::GetVideoQualityLevel(const std::string& title) {
  VideoAttr::VideoQualityLevel quality_level = VideoAttr::kNormal;
  std::set<reco::TagAnnotator::Tag> video_tags;
  int low_quality_count = 0;
  std::string low_quality_matched_str;
  if (video_attr_level_annotator_->GetTags(title, &video_tags)) {
    for (auto iter = video_tags.begin(); iter != video_tags.end(); ++iter) {
      if (iter->type == "低质") {
        ++low_quality_count;
        low_quality_matched_str += " " + iter->literal;
      }
    }
  }
  if (low_quality_count > 0) {
    quality_level = VideoAttr::kSuspectRubbish;
    VLOG(1) << "suspect rubbish video detected: " << title << '\t' << low_quality_matched_str;
  }
  return quality_level;
}

/*
   void VideoTagAnnotator::LoadSourceTagFromMysql() {
   static const int kRetryTimes = 3;

// 种子 id 对应的 name
std::unordered_map<std::string, std::string> seed_id_name;
for (int i = 0; i < kRetryTimes; ++i) {
std::string sql = "select id,name from tb_seed;";
try {
scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

while (res->next()) {
std::string seed_id_str = res->getString("id");
std::string seed_name = res->getString("name");
seed_id_name[seed_id_str] = seed_name;
VLOG(1) << "seed_id: " << seed_id_str << ", name: " << seed_name;
}   
break;
} catch (sql::SQLException& e) {  // NOLINT
LOG(ERROR) << "Exception: " << e.what();
LOG(ERROR) << "sql: " << sql;
db_manager_->ConnectUntilSuccess();
db_connection_ = db_manager_->conn();
CHECK_NOTNULL(db_connection_);
LOG(ERROR) << "Reconnectd to MySQL.";
}
}

// 标签 id 对应的明文
std::unordered_map<std::string, std::string> tag_id_literal;
for (int i = 0; i < kRetryTimes; ++i) {
std::string sql = "select id,tag from tb_video_category_tag;";
try {
scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

while (res->next()) {
std::string tag_id_str = res->getString("id");
std::string literal = res->getString("tag");
tag_id_literal[tag_id_str] = literal;
VLOG(1) << "tag_id: " << tag_id_str << ", tag: " << literal;
}   
break;
} catch (sql::SQLException& e) {  // NOLINT
LOG(ERROR) << "Exception: " << e.what();
LOG(ERROR) << "sql: " << sql;
db_manager_->ConnectUntilSuccess();
db_connection_ = db_manager_->conn();
CHECK_NOTNULL(db_connection_);
LOG(ERROR) << "Reconnectd to MySQL.";
}
}

// 视频种子对应的标签
auto source_tags = source_tags_.GetInactiveDict();
for (int i = 0; i < kRetryTimes; ++i) {
std::string sql = "select seed_id,tag_id from tb_seed_video_tag;";
try {
scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

while (res->next()) {
std::string seed_id_str = res->getString("seed_id");
std::string tag_id_str = res->getString("tag_id");
auto tag_it = tag_id_literal.find(tag_id_str);
if (tag_it == tag_id_literal.end()) {
continue;
}
auto seed_it = seed_id_name.find(seed_id_str);
if (seed_it == seed_id_name.end()) {
continue;
}
(*source_tags)[seed_it->second].push_back(tag_it->second);
VLOG(1) << "seed: " << seed_it->second << ", tag: " << tag_it->second;
}   
break;
} catch (sql::SQLException& e) {  // NOLINT
  LOG(ERROR) << "Exception: " << e.what();
  LOG(ERROR) << "sql: " << sql;
  db_manager_->ConnectUntilSuccess();
  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
  LOG(ERROR) << "Reconnectd to MySQL.";
}
}
}
*/
}
