#include "reco/module/cdoc_convertor/tag/video_tag_annotator.h"

#include <vector>
#include <queue>
#include <unordered_map>
#include <utility>
#include <fstream>
#include <algorithm>
#include <iostream>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/slice.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/testing/gtest.h"
#include "nlp/common/nlp_util.h"

namespace reco {

class VideoTagAnnnotatorTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    // source_tags_dict_ = new std::unordered_map<std::string, std::vector<std::string> >();
    // std::vector<std::string> tags;
    // tags.push_back("陈翔六点半");
    // tags.push_back("爆笑原创");
    // source_tags_dict_->insert(std::make_pair("微博-陈翔六点半", tags));
    video_tag_annotator_ = new VideoTagAnnotator("serving/reco/data/cdoc_convertor");
  }

  virtual void TearDown() {
    delete video_tag_annotator_;
  }

  VideoTagAnnotator *video_tag_annotator_;
  // std::unordered_map<std::string, std::vector<std::string> >* source_tags_dict_;
};

TEST_F(VideoTagAnnnotatorTest, GetTags) {
  struct Case {
    std::string title;
    std::string category;
    std::string source;
  };
  Case test_case[3] = {
    {"《夜空中最亮的星》", "音乐", "优酷-24小时-音乐"},
    {"papi酱的个人小剧场之——你有酱婶儿的盆友吗？第N弹", "搞笑", "papi酱"},
    {"猪一样的队友", "搞笑", "微博-陈翔六点半"},
  };
  for (size_t i = 0; i < 3; ++i) {
    std::vector<VideoTagAnnotator::VideoTag> tags;
    video_tag_annotator_->GetTags(test_case[i].source, test_case[i].category, test_case[i].title, &tags);
    for (size_t j = 0; j < tags.size(); ++j) {
      std::cout << tags[j].tag << "\t";
    }
    std::cout << std::endl;
  }
}
}
