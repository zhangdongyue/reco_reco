#include "reco/module/cdoc_convertor/tag/tag_rule_match.h"

#include <vector>
#include <queue>
#include <unordered_map>
#include <utility>
#include <fstream>
#include <algorithm>

#include "base/common/slice.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "nlp/common/nlp_util.h"

namespace reco {

const char* TagMatch::kCategoryTagRulesFile = "tag_match_rule.txt";
const char* TagMatch::kStdCategoriesFile = "match_category.txt";
const char* TagMatch::kCategoryAll= "all";

void TagMatch::MapInsert(const std::vector<std::string>& word_vec,
               std::unordered_map<std::string, int>* word_map,
               int* word_num) {
  for (int i = 0; i < (int)word_vec.size(); i++) {
    if (word_map->find(word_vec[i]) == word_map->end()) {
      (*word_map)[word_vec[i]] = (*word_num)++;
    }
  }
}

bool TagMatch::LoadTagRule(const std::string &rules_file) {
  int rule_num = 0;
  int category_num = 0;
  int word_num = 0;
  std::vector<std::string> lines;

  if (!base::file_util::ReadFileToLines(rules_file, &lines)) {
    LOG(ERROR) << "open tag rule file fail:" << rules_file;
    return false;
  }

  std::vector<std::string> tokens;

  for (int i = 0; i < (int)lines.size(); i++) {
    if (lines[i].empty() || lines[i].at(0) == '#') {
      continue;
    }

    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    if ((int)tokens.size() < 5) continue;
    for (auto it = tokens.begin(); it != tokens.end(); ++it) {
      *it = nlp::util::NormalizeLine(*it);
    }
    if (tokens[4] == "1") {
      std::vector<std::string> categories;
      std::vector<std::string> positive;
      std::vector<std::string> negative;
      std::vector<std::string> tags;

      base::SplitString(tokens[0], "|", &categories);
      if ((int)categories.size() == 1 && categories[0] == kCategoryAll) {
        categories.clear();
        for (int j = 0; j < (int)std_all_categories_.size(); j++) {
          categories.push_back(std_all_categories_[j]);
        }
      }

      base::SplitString(tokens[1], "|", &positive);
      if (tokens[2].size() > 0u) {
        base::SplitString(tokens[2], "|", &negative);
      }
      base::SplitString(tokens[3], "|", &tags);

      sort(categories.begin(), categories.end());
      sort(positive.begin(), positive.end());
      sort(negative.begin(), negative.end());
      sort(tags.begin(), tags.end());

      categories.erase(unique(categories.begin(), categories.end()), categories.end());
      positive.erase(unique(positive.begin(), positive.end()), positive.end());
      negative.erase(unique(negative.begin(), negative.end()), negative.end());
      tags.erase(unique(tags.begin(), tags.end()), tags.end());

      all_categories_.push_back(categories);
      MapInsert(categories, &category_map_, &category_num);
      all_positive_.push_back(positive);
      MapInsert(positive, &word_map_, &word_num);
      all_negative_.push_back(negative);
      MapInsert(negative, &word_map_, &word_num);
      all_tags_.push_back(tags);

      rule_num++;
    }
  }
  LOG(INFO) << base::StringPrintf("tag rule file [%s] load [%d] rules, [%lu] categories, [%lu] words",
                                  rules_file.c_str(), rule_num, category_map_.size(), word_map_.size());

  // for (int i = 0; i < word_num; i++) {
  //   std::vector<std::vector<int> > tmp1;
  //   std::vector<std::vector<int> > tmp2;
  //   for (int j = 0; j < category_num; j++) {
  //     std::vector<int> tmp3;
  //     std::vector<int> tmp4;
  //     tmp1.push_back(tmp3);
  //     tmp2.push_back(tmp4);
  //   }
  //   positive_rule_lists_.push_back(tmp1);
  //   negative_rule_lists_.push_back(tmp2);
  // }
  positive_rule_lists_.resize(word_num);
  negative_rule_lists_.resize(word_num);
  for (int i = 0; i < word_num; i++) {
    positive_rule_lists_[i].resize(category_num);
    negative_rule_lists_[i].resize(category_num);
  }

  for (int i = 0; i < category_num; i++) {
    positive_trie_.push_back(new Automation());
    negative_trie_.push_back(new Automation());
  }

  for (int i = 0; i < rule_num; i++) {
    for (int j = 0; j < (int)all_positive_[i].size(); j++) {
      int word_index = word_map_[all_positive_[i][j]];
      for (int k = 0; k < (int)all_categories_[i].size(); k++) {
        int trie_index = category_map_[all_categories_[i][k]];
        positive_trie_[trie_index]->TrieInsert(all_positive_[i][j], word_index);
        positive_rule_lists_[word_index][trie_index].push_back(i);
      }
    }

    for (int j = 0; j < (int)all_negative_[i].size(); j++) {
      int word_index = word_map_[all_negative_[i][j]];
      for (int k = 0; k < (int)all_categories_[i].size(); k++) {
        int trie_index = category_map_[all_categories_[i][k]];
        negative_trie_[trie_index]->TrieInsert(all_negative_[i][j], word_index);
        negative_rule_lists_[word_index][trie_index].push_back(i);
      }
    }
  }
  for (int i = 0; i < category_num; i++) {
    positive_trie_[i]->AutomationBuild();
    negative_trie_[i]->AutomationBuild();
  }
  LOG(INFO) << "load tag file rule success: " << rules_file;
  return true;
}

bool TagMatch::LoadStdCategories(const std::string &std_categories_file) {
  std::vector<std::string> lines;

  if (!base::file_util::ReadFileToLines(std_categories_file, &lines)) {
    LOG(ERROR) << "open std categories file fail:" << std_categories_file;
    return false;
  }
  for (int i = 0; i < (int)lines.size(); i++) {
    if (lines[i].empty() || lines[i].at(0) == '#') {
      continue;
    }
    std_all_categories_.push_back(lines[i]);
  }

  LOG(INFO) << "load std categories file success";
  return true;
}

TagMatch::TagMatch(const std::string &rules_dir) {
  CHECK(LoadStdCategories(rules_dir + "/" + kStdCategoriesFile));
  CHECK(LoadTagRule(rules_dir + "/" + kCategoryTagRulesFile));
}

TagMatch::~TagMatch() {
  for (int i = 0; i < (int)positive_trie_.size(); i++) {
    delete positive_trie_[i];
    positive_trie_[i] = NULL;
    delete negative_trie_[i];
    negative_trie_[i] = NULL;
  }
}

bool TagMatch::GetTags(const std::string &category,
                         const std::string &title,
                         std::vector<std::string>* tags) {
  if (category_map_.find(category) == category_map_.end()) {
    return false;
  }

  int category_index = category_map_[category];
  std::vector<int> positive_ans;
  std::vector<int> negative_ans;
  positive_trie_[category_index]->TrieFind(title, &positive_ans);
  negative_trie_[category_index]->TrieFind(title, &negative_ans);

  sort(positive_ans.begin(), positive_ans.end());
  sort(negative_ans.begin(), negative_ans.end());
  positive_ans.erase(unique(positive_ans.begin(), positive_ans.end()), positive_ans.end());
  negative_ans.erase(unique(negative_ans.begin(), negative_ans.end()), negative_ans.end());

  std::unordered_map<int, int> positive_map;
  std::unordered_map<int, int> negative_map;

  for (int i = 0; i < (int)negative_ans.size(); i++) {
    int word_index = negative_ans[i];
    for (int j = 0; j < (int)negative_rule_lists_[word_index][category_index].size(); j++) {
      negative_map[negative_rule_lists_[word_index][category_index][j]] = 1;
    }
  }

  for (int i = 0; i < (int)positive_ans.size(); i++) {
    int word_index = positive_ans[i];
    for (int j = 0; j < (int)positive_rule_lists_[word_index][category_index].size(); j++) {
      int k = positive_rule_lists_[word_index][category_index][j];
      if (negative_map.find(k) != negative_map.end()) continue;
      if (positive_map.find(k) == positive_map.end()) {
        positive_map[k] = 1;
      } else {
        positive_map[k]++;
      }
      if (positive_map[k] == (int)all_positive_[k].size()) {
        for (int p = 0; p < (int)all_tags_[k].size(); p++) {
          tags->push_back(all_tags_[k][p]);
        }
      }
    }
  }
  return tags->size() > 0u;
}

bool TagMatch::GetTagsSlow(const std::string &category,
                         const std::string &title,
                         std::vector<std::string>* tags) {
  if (category_map_.find(category) == category_map_.end()) {
    return false;
  }
  for (int i = 0; i < (int)all_categories_.size(); i++) {
    int flag = 0;
    for (int j = 0; j < (int)all_categories_[i].size(); j++) {
      if (category_map_[all_categories_[i][j]] == category_map_[category]) {
        flag = 1;
        break;
      }
    }

    if (!flag) continue;
    for (int j = 0; j < (int)all_positive_[i].size(); j++) {
      if (title.find(all_positive_[i][j]) == std::string::npos) {
        flag = 0;
        break;
      }
    }

    if (!flag) continue;
    for (int j = 0; j < (int)all_negative_[i].size(); j++) {
      if (title.find(all_negative_[i][j]) != std::string::npos) {
        flag = 0;
        break;
      }
    }

    if (flag) {
      for (int j = 0; j < (int)all_tags_[i].size(); j++) {
        tags->push_back(all_tags_[i][j]);
      }
    }
  }

  return tags->size() > 0u;
}
}
