#pragma once
#include <string>
#include <vector>
#include <set>
#include <unordered_map>

#include "base/common/base.h"
#include "extend/multi_strings/multi_pattern_matcher.h"

namespace reco {
class TagAnnotator {
 public:
  explicit TagAnnotator(const std::string &base_dir);
  ~TagAnnotator();
  struct Tag {
    // 显示的 tag
    std::string literal;
    // tag 的类型
    std::string type;
    Tag(std::string l, std::string t) {
      literal = l;
      type = t;
    }
    bool operator<(const Tag &a) const {
      return a.literal < literal;
    }

    bool operator==(const Tag &a) const {
      return (a.literal == literal && a.type == type);
    }
  };

  struct TagPattern {
    // 正则表达式
    std::string reg;
    // 对应的 tag
    std::string literal;
    // tag 的类型
    std::string type;
    TagPattern(std::string r, std::string l, std::string t) {
      reg = r;
      literal = l;
      type = t;
    }
  };

 public:
  bool GetTags(const std::string &title, std::set<Tag> *tags);

 private:
  // 装载正则词典
  bool LoadTagPattern(const std::string &pattern_dict);
  // 装载多模匹配词典
  bool LoadMultiMatcher(const std::string &matcher_dict);
  // 从正则匹配打标签
  void GetTagsFromPattern(const std::string &title, std::set<Tag> *tags);
  // 从 keyword 强规则打标签
  void GetTagsFromMultiMatcher(const std::string &title, std::set<Tag> *tags);

 private:
  // 多模匹配器
  extend::MultiPatternMatcher multi_matcher_;
  // 正则匹配器
  std::vector<TagPattern> tag_patterns_;
  // keyword 对应 的 tag
  std::unordered_map<std::string, Tag*> keyword_tag_map_;
};
}
