#pragma once
#include <vector>
#include <string>
#include <queue>
#include <unordered_map>

#include "base/common/basic_types.h"
#include "base/common/slice.h"
#include "base/file/file_path.h"
#include "reco/module/cdoc_convertor/tag/multi_pattern_match.h"
#include "base/testing/gtest_prod.h"

namespace reco {
class TagMatch {
 public:
  explicit TagMatch(const std::string &rules_dir);
  ~TagMatch();

  bool GetTags(const std::string& category, const std::string& title, std::vector<std::string>* tags);
 private:
  FRIEND_TEST(TagMatchTest, TESTRULE);
  bool GetTagsSlow(const std::string& category, const std::string& title, std::vector<std::string>* tags);
  bool LoadTagRule(const std::string &rules_file);
  bool LoadStdCategories(const std::string &std_categories_file);
  void MapInsert(const std::vector<std::string>& word_vec,
                 std::unordered_map<std::string, int>* word_mp,
                 int* word_num);

  std::unordered_map<std::string, int> category_map_;
  std::unordered_map<std::string, int> word_map_;
  std::vector<std::string> std_all_categories_;
  std::vector<std::vector<std::string> > all_tags_;
  std::vector<std::vector<std::string> > all_categories_;
  std::vector<std::vector<std::string> > all_positive_;
  std::vector<std::vector<std::string> > all_negative_;
  std::vector<std::vector<std::vector<int> > > positive_rule_lists_;
  std::vector<std::vector<std::vector<int> > > negative_rule_lists_;
  std::vector<Automation*> positive_trie_;
  std::vector<Automation*> negative_trie_;

  static const char* kCategoryTagRulesFile;
  static const char* kStdCategoriesFile;
  static const char* kCategoryAll;
};
}
