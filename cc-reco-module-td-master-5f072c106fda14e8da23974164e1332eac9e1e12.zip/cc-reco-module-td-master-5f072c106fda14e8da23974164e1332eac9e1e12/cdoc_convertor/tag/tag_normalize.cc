#include "reco/module/cdoc_convertor/tag/tag_normalize.h"

#include <fstream>
#include <iostream>

#include <unordered_set>
#include "base/common/logging.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "nlp/common/nlp_util.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"

namespace reco {

TagNormalize::TagNormalize() {
}

TagNormalize::~TagNormalize() {
}

TagNormalize& TagNormalize::Instance() {
  static TagNormalize ins;
  return ins;
}

std::string TagNormalize::SearchNormalizeTag(const std::string &org_tag) {
  auto dict = GlobalDataIns::instance().GetTagNormalizeDict();
  std::string nor_tag;
  GlobalData::CommonNormalize(org_tag, &nor_tag);
  auto it = dict->find(nor_tag);
  if (it != dict->end()) {
    if (it->second != org_tag) {
      VLOG(1) << "search normalize tag:" << org_tag << ", " << it->second;
    }
    return it->second;
  } else {
    return org_tag;
  }
}

void TagNormalize::NormalizeTag(const std::vector<std::string> tags, std::vector<std::string> *nor_tags) {
  CHECK(nor_tags);
  nor_tags->clear();
  std::unordered_set<std::string> s;
  for (size_t i = 0; i < tags.size(); i++) {
    std::string nor_tag = SearchNormalizeTag(tags[i]);

    // 去重
    if (s.find(nor_tag) != s.end()) continue;
    s.insert(nor_tag);

    nor_tags->push_back(nor_tag);
  }
}

void TagNormalize::NormalizeTag(const reco::FeatureVector &tag_fea, reco::FeatureVector *nor_tag_fea) {
  CHECK(nor_tag_fea);
  std::unordered_set<std::string> s;
  for (int i = 0; i < tag_fea.feature_size(); i++) {
    std::vector<std::string> v;
    base::SplitString(tag_fea.feature(i).literal(), ":", &v);
    if (v.size() < 2) continue;
    Feature fea;
    std::string nor_tag = v[1];
    nor_tag = SearchNormalizeTag(nor_tag);

    std::string literal = base::StringPrintf("%s:%s", v[0].c_str(), nor_tag.c_str());
    // 去重
    if (s.find(literal) != s.end()) continue;
    s.insert(literal);

    fea.set_literal(literal);
    fea.set_weight(tag_fea.feature(i).weight());
    nor_tag_fea->add_feature()->CopyFrom(fea);
  }
  nor_tag_fea->set_norm(tag_fea.norm());
}

}  // namespace reco
