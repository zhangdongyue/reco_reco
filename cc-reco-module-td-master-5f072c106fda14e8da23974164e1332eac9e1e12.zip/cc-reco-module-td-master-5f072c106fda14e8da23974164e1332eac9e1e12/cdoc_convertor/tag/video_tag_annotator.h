#pragma once
#include <vector>
#include <set>
#include <string>
#include <queue>
#include <unordered_map>

#include "reco/module/cdoc_convertor/tag/tag_rule_match.h"
#include "reco/module/cdoc_convertor/tag/tag_annotator.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
class VideoTagAnnotator {
 public:
  explicit VideoTagAnnotator(const std::string& base_dir);
  ~VideoTagAnnotator();

  struct VideoTag {
    std::string tag;
    int tf;
    std::string type;
    VideoTag(const std::string& tag_, int tf_, const std::string& type_) {
      tag = tag_;
      tf = tf_;
      type = type_;
    }

    VideoTag() {
      tag = "";
      tf = 0;
      type = "";
    }

    bool operator<(const VideoTag &a) const {
      return a.tag < tag;
    }

    bool operator==(const VideoTag &a) const {
      return (a.tag == tag && a.tf == tf);
    }
  };

  bool GetTags(const std::string& source,
               const std::string& orig_source,
               const std::string& category,
               const std::string& title,
               std::vector<VideoTag>* video_tags);

  VideoAttr::VideoVulgarLevel GetVideoVulgarLevel(const std::string& title);

  VideoAttr::VideoQualityLevel GetVideoQualityLevel(const std::string& title);

 private:
  // 根据规则打标签
  bool ExtractTagFromRule(const std::string& category,
                          const std::string& title,
                          std::vector<VideoTag>* rule_tags);

  // 根据一些种子源可以打上标签，例如"papi酱"，她在优酷的自频道下的视频都可以打上"papi酱"的 tag NOLINT
  bool ExtractTagFromSource(const std::string& source, const std::string& orig_source,
                            std::vector<VideoTag>* source_tags);

  // 在两个标点符号之间提取 tag ，例如书名号、引号
  bool ExtractTagBetweenPunctuation(const std::string& title,
                                    const std::string& left_punctuation,
                                    const std::string& right_punctuation,
                                    std::vector<VideoTag>* special_tags);

  void DeleteSubTags(std::vector<std::string> *tags);

  void ConvertStringToVideoTag(const std::vector<std::string>& tags,
                               const std::string& type,
                               std::vector<VideoTag>* video_tags);

 private:
  // 视频标签规则匹配器
  TagMatch* tag_matcher_;
  // 视频属性标签器
  reco::TagAnnotator *video_attr_level_annotator_;
  // serving_base::mysql_util::DbConnManager* db_manager_;
  // sql::Connection* db_connection_;
};
}
