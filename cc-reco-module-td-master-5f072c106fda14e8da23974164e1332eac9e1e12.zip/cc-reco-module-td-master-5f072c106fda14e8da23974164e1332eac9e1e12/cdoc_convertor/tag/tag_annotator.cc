#include "reco/module/cdoc_convertor/tag/tag_annotator.h"

#include <algorithm>
#include "base/common/slice.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"

#include "extend/regexp/re3/re3.h"
#include "extend/multi_strings/kwset.h"
#include "nlp/common/nlp_util.h"

namespace reco {
TagAnnotator::TagAnnotator(const std::string &base_dir) {
  static const char* kVideoVulgarPatternFile = "video_vulgar_pattern.txt";
  static const char* kVideoVulgarMultimatcherFile = "video_vulgar_multi_matcher.txt";
  base::FilePath root_dir(base_dir.c_str());
  base::FilePath video_vulgar_pattern_file = root_dir.Append(kVideoVulgarPatternFile);
  base::FilePath video_vulgar_multi_matcher_file = root_dir.Append(kVideoVulgarMultimatcherFile);
  CHECK(LoadTagPattern(video_vulgar_pattern_file.ToString()));
  CHECK(LoadMultiMatcher(video_vulgar_multi_matcher_file.ToString()));
}

TagAnnotator::~TagAnnotator() {
  for (auto it = keyword_tag_map_.begin(); it != keyword_tag_map_.end(); ++it) {
    delete it->second;
    it->second = NULL;
  }
}

bool TagAnnotator::LoadTagPattern(const std::string &pattern_dict) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(pattern_dict, &lines)) {
    LOG(ERROR) << "load tag pattern fail! " << pattern_dict;
    return false;
  }
  for (auto i = 0u; i < lines.size(); ++i) {
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() < 3) {
      continue;
    }
    const std::string &reg = nlp::util::NormalizeLine(tokens[0]);
    const std::string &tag = nlp::util::NormalizeLine(tokens[1]);
    const std::string &type = nlp::util::NormalizeLine(tokens[2]);
    tag_patterns_.push_back(TagPattern(reg, tag, type));
  }
  return true;
}

bool TagAnnotator::LoadMultiMatcher(const std::string &matcher_dict) {
  keyword_tag_map_.clear();
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(matcher_dict, &lines)) {
    LOG(ERROR) << "load multi matcher fail! " << matcher_dict;
    return false;
  }
  for (auto i = 0u; i < lines.size(); ++i) {
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() < 3) {
      continue;
    }
    const std::string &keyword = nlp::util::NormalizeLine(tokens[0]);
    const std::string &tag = nlp::util::NormalizeLine(tokens[1]);
    const std::string &type = nlp::util::NormalizeLine(tokens[2]);
    keyword_tag_map_[keyword] = new Tag(tag, type);
    multi_matcher_.AddPattern(keyword.c_str());
  }
  multi_matcher_.Build();
  return true;
}

bool TagAnnotator::GetTags(const std::string &title, std::set<Tag> *tags) {
  tags->clear();
  std::string nor_title = nlp::util::NormalizeLine(title);
  GetTagsFromPattern(nor_title, tags);
  GetTagsFromMultiMatcher(nor_title, tags);
  return !tags->empty();
}

void TagAnnotator::GetTagsFromPattern(const std::string &title, std::set<Tag> *tags) {
  for (auto it = tag_patterns_.begin(); it != tag_patterns_.end(); ++it) {
    std::string &pattern = it->reg;
    std::string value;
    base::Slice input(title);
    if (extend::re3::Re3::FindAndConsume(&input, pattern, &value)) {
      tags->insert(Tag(it->literal, it->type));
    }
  }
}

void TagAnnotator::GetTagsFromMultiMatcher(const std::string &title, std::set<Tag> *tags) {
  static const size_t kMaxMatchResultNum = 20;
  extend::multi_internal::kwsmatch* result = new extend::multi_internal::kwsmatch[kMaxMatchResultNum];
  size_t match_num = multi_matcher_.MatchAll(title.c_str(), title.size(), result, kMaxMatchResultNum);
  match_num = std::min(match_num, kMaxMatchResultNum);
  for (size_t i = 0; i < match_num; ++i) {
    std::string keyword = title.substr(result[i].offset[0], result[i].size[0]);
    DLOG(INFO) << "hit keyword: " << keyword;
    auto it = keyword_tag_map_.find(keyword);
    if (it != keyword_tag_map_.end()) {
      tags->insert(Tag(it->second->literal, it->second->type));
    }
  }
  delete[] result;
}
}
