#include "reco/module/cdoc_convertor/tag/tag_annotator.h"

#include <vector>
#include "base/common/base.h"
#include "base/testing/gtest.h"
#include "base/common/gflags.h"

namespace reco {
namespace cdoc_convertor {
class TagAnnotatorTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    tag_annotator_ = new TagAnnotator("serving/reco/data/cdoc_convertor/video_tag");
  }
  virtual void TearDown() {
    delete tag_annotator_;
  }
  TagAnnotator* tag_annotator_;
};

TEST_F(TagAnnotatorTest, GetTags) {
  std::vector<std::string> test_case;
  std::vector<std::set<TagAnnotator::Tag>> test_ans;
  std::string title;
  std::set<TagAnnotator::Tag> tags;

  title = "爆乳, 这个逼装的我给打99分";
  test_case.push_back(title);
  tags.insert(TagAnnotator::Tag("装逼", "装逼"));
  tags.insert(TagAnnotator::Tag("爆乳", "低俗"));
  test_ans.push_back(tags);

  title = "这个逼装的我给打0分";
  test_case.push_back(title);
  tags.clear();
  tags.insert(TagAnnotator::Tag("装逼", "装逼"));
  test_ans.push_back(tags);

  title = "广场舞小丽";
  test_case.push_back(title);
  tags.clear();
  tags.insert(TagAnnotator::Tag("广场舞", "低质"));
  test_ans.push_back(tags);

  for (auto i = 0u; i < test_case.size(); ++i) {
    std::cout << test_case[i] << std::endl;
    std::set<TagAnnotator::Tag> tags;
    ASSERT_TRUE(tag_annotator_->GetTags(test_case[i], &tags));
    for (auto it = tags.begin(); it != tags.end(); ++it) {
      std::cout << it->literal << "\t" << it->type << std::endl;
    }
    ASSERT_EQ(tags, test_ans[i]);
  }
}
}
}
