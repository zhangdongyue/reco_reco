#include "reco/module/cdoc_convertor/tag/multi_pattern_match.h"

#include <vector>
#include <queue>
#include <unordered_map>
#include <utility>
#include <fstream>
#include <algorithm>

#include "base/common/slice.h"
#include "base/strings/string_split.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "nlp/common/nlp_util.h"

namespace reco {

void Automation::GetUTFChars(const std::string& str, std::vector<std::string>* utf_chars) {
  base::UTF8CharIterator iter(&str);
  int last_pos = 0;
  int cur_pos;
  while (!iter.end()) {
    iter.Advance();
    cur_pos = iter.array_pos();
    std::string char_tmp = str.substr(last_pos, cur_pos - last_pos);
    utf_chars->push_back(char_tmp);
    last_pos = cur_pos;
  }
}

void Automation::AutomationInit() {
  root_ = new Trie();
  char_num_ = 0;
  char_map_.clear();
}

void Automation::TrieDelete(Trie* node) {
  for (int i = 0; i < (int)node->child.size(); i++) {
    TrieDelete(node->child[i]);
  }
  delete node;
  node = NULL;
}

Automation::Automation() {
  AutomationInit();
}

Automation::~Automation() {
  TrieDelete(root_);
}

void Automation::TrieInsert(const std::string& word, const int& word_index) {
  std::vector<std::string>utf_chars;
  GetUTFChars(word, &utf_chars);
  Trie* now = root_;
  for (int i = 0; i < (int)utf_chars.size(); i++) {
    if (char_map_.find(utf_chars[i]) == char_map_.end()) {
      char_map_[utf_chars[i]] = char_num_++;
    }

    int char_index = char_map_[utf_chars[i]];
    if (now->local_map.find(char_index) == now->local_map.end()) {
      now->local_map[char_index] = now->map_num++;
      now->child.push_back(new Trie());
    }

    now = now->child[now->local_map[char_index]];
    now->char_index = char_index;
  }
  now->word_index = word_index;
}

void Automation::AutomationBuild() {
  root_->fail = NULL;
  for (int i = 0; i < (int)root_->child.size(); i++) {
    root_->child[i]->fail = root_;
    bfs_queue.push(root_->child[i]);
  }

  while (!bfs_queue.empty()) {
    Trie* tmp_node = bfs_queue.front();
    bfs_queue.pop();
    for (int i = 0; i < (int)tmp_node->child.size(); i++) {
      int char_index = tmp_node->child[i]->char_index;
      Trie* tmp_fail = tmp_node->fail;
      while (tmp_fail != NULL && tmp_fail->local_map.find(char_index) == tmp_fail->local_map.end()) {
        tmp_fail = tmp_fail->fail;
      }

      if (tmp_fail != NULL) {
        int local_char_index = tmp_fail->local_map[char_index];
        tmp_node->child[i]->fail = tmp_fail->child[local_char_index];
      } else {
        tmp_node->child[i]->fail = root_;
      }

      bfs_queue.push(tmp_node->child[i]);
    }
  }
}

void Automation::TrieFind(const std::string& title, std::vector<int>* ans) {
  std::vector<std::string>utf_chars;
  GetUTFChars(title, &utf_chars);
  Trie* now = root_;
  for (int i = 0; i < (int)utf_chars.size(); i++) {
    int char_index;
    if (char_map_.find(utf_chars[i]) == char_map_.end()) {
      char_index = -1;
    } else {
      char_index = char_map_[utf_chars[i]];
    }

    while (now != NULL && now->local_map.find(char_index) == now->local_map.end()) {
      now = now->fail;
    }

    if (now != NULL) {
      int local_char_index = now->local_map[char_index];
      now = now->child[local_char_index];
    } else {
      now = root_;
    }

    for (Trie* tmp_node = now; tmp_node; tmp_node = tmp_node->fail) {
      if (tmp_node->word_index != -1) {
        ans->push_back(tmp_node->word_index);
      }
    }
  }
}
}
