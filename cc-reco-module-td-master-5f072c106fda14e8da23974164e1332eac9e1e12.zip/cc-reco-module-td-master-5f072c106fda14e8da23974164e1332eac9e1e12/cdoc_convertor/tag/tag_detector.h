#pragma once

#include <vector>
#include <string>
#include <utility>
#include <unordered_map>
#include <unordered_set>

#include "base/common/base.h"
#include "extend/multi_strings/multi_strings_vldc.h"

namespace reco {

class TagDetector {
 public:
  explicit TagDetector(const std::string &rules_dir);
  ~TagDetector();

  // 通过匹配正则打 tag
  struct TagRule {
    // 规则序号，唯一
    int id;
    // 该规则不适用于哪些一级类别
    std::unordered_set<std::string> negative_categorys;
    // 正则表达式
    std::string reg;
    // 展示出来的 tag 名称
    std::string tag;
    // 负例关键词，命中一个，则正向规则无效
    VLDC::MultiStringVLDC *vldc_negative_words;
    // 效果权重
    float weight;

    TagRule() {
      id = -1;
      negative_categorys.clear();
      reg = "";
      tag = "";
      vldc_negative_words = NULL;
      weight = 0;
    }
  };
  typedef std::vector<TagRule> RuleVec;

  struct ExtendRule {
    // 规则序号，唯一
    int id;
    // 一级 tag
    std::string tag1;
    // 二级 tag
    std::string tag2;
    // 核心词是否可以展示
    bool can_show;
    // 核心词抽象概念,需要单独识别,比如汽车评测,用车
    bool is_concept;

    ExtendRule() {
      id = -1;
      tag1 = "";
      tag2 = "";
      can_show = false;
      is_concept = false;
    }
  };
  // coreword --> ExtendRule
  // 目前没有支持，核心词对应多个一级标签
  typedef std::unordered_map<std::string, ExtendRule> ExtendMap;

  // 给定一级类别和 title ，进行正则匹配
  bool GetTags(const std::string &category, const std::string &title,
               std::vector<std::string> *tags);
  // 查找是否在扩展词典中
  // 返回值: 2 表示，在词典中，并且可以展示
  //         1 表示，在词典中，但是不可以展示
  //         0 表示，不在词典中
  int SearchCoreWord(const std::string &category, const std::string &word);
  // 给定一级类别和词，进行扩展
  bool GetExtendTags(const std::string &category, const std::string &word,
                     int *can_show, std::string *tag1, std::string *tag2);
 private:
  // 逐条加载规则，加载规则时，如果权重低于参数 weight_thres 制定的阈值，则不加载该规则
  bool LoadRules(const std::string &rules_file, float weight_thres);
  // 加载核心词文件
  bool LoadCoreWordFile(const std::string &coreword_file);
  // 加载扩展文件
  bool LoadExtendFile(const std::string &extend_file);

  void SplitSubStrToSet(const std::string &str,
                        const std::string &delim,
                        std::unordered_set<std::string> *tokens);
  void SplitSubStrToMultiStringVLDC(const std::string &str,
                                    const std::string &delim,
                                    VLDC::MultiStringVLDC *vldc);

  std::unordered_map<std::string, RuleVec> category_rule_dict_;
  std::unordered_map<std::string, ExtendMap> category_entend_dict_;
  std::unordered_map<std::string, std::pair<bool, bool> > coreword_dict_;

  static const char* kCategoryTagRulesFile;
  static const char* kCategoryExtendFile;
  static const char* kCoreWordFile;
  static const char* kDefaultCategory;

  DISALLOW_COPY_AND_ASSIGN(TagDetector);
};
}  // namespace reco

