#include "reco/module/cdoc_convertor/tag/tag_detector.h"

#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "extend/regexp/re3/re3.h"
#include "nlp/common/nlp_util.h"

DEFINE_double(rule_weight_thres, 0.85, "");

namespace reco {

const char* TagDetector::kCategoryTagRulesFile = "category_tag_rules.txt";
const char* TagDetector::kCategoryExtendFile = "category_extend.txt";
const char* TagDetector::kCoreWordFile = "coreword_for_extend.txt";
const char* TagDetector::kDefaultCategory = "all";

TagDetector::TagDetector(const std::string &rules_dir) {
  CHECK(LoadRules(rules_dir + "/" + kCategoryTagRulesFile, FLAGS_rule_weight_thres));
  CHECK(LoadCoreWordFile(rules_dir + "/" + kCoreWordFile));
  CHECK(LoadExtendFile(rules_dir + "/" + kCategoryExtendFile));
}

TagDetector::~TagDetector() {
  for (auto rules_iter = category_rule_dict_.begin();
       rules_iter != category_rule_dict_.end();
       ++rules_iter) {
    RuleVec rule_vec = rules_iter->second;
    for (auto iter = rule_vec.begin(); iter != rule_vec.end(); ++iter) {
      iter->negative_categorys.clear();
      if (iter->vldc_negative_words) {
        delete iter->vldc_negative_words;
        iter->vldc_negative_words = NULL;
      }
    }
  }
  category_rule_dict_.clear();
  category_entend_dict_.clear();
  coreword_dict_.clear();
}

bool TagDetector::LoadRules(const std::string &rules_file, float weight_thres) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(rules_file, &lines)) {
    LOG(ERROR) << "load tag rule dict file error: " << rules_file;
    return false;
  }

  const uint16 kRuleDictColNum = 8;
  const std::string kRuleFieldDelim = "##";

  std::vector<std::string> tokens;
  for (int i = 0; i < (int)lines.size(); ++i) {
    if (lines[i].empty() || lines[i].at(0) == '#') {
      continue;
    }

    // id \t 类别(## 分割) \t 否定类别(## 分割) \t 正则表达式 \t 映射后标签 \t 负例关键词(##分割) \t positive \t total NOLINT
    // 类别：如果支持不同类别，则类别之间以 ## 分割; 如果支持所有类别，则该字段为 all
    // positive: 该 pattern 匹配的正例样本数目
    // total: 该 pattern 匹配的总样本数目
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() < kRuleDictColNum) {
      LOG(ERROR) << "rule dict column num is error, num is: " << tokens.size()
                 << ", content is: " << lines[i];
      continue;
    }
    for (auto it = tokens.begin(); it != tokens.end(); ++it) {
      *it = nlp::util::NormalizeLine(*it);
    }

    TagRule new_rule;

    base::StringToInt(tokens[0], &new_rule.id);

    std::string category = tokens[1];
    if (category.empty()) continue;
    std::unordered_set<std::string> match_categorys;
    SplitSubStrToSet(category, kRuleFieldDelim, &match_categorys);

    std::string negative_category = tokens[2];
    SplitSubStrToSet(negative_category, kRuleFieldDelim, &new_rule.negative_categorys);

    new_rule.reg = tokens[3];
    if (new_rule.reg.empty()) continue;
    base::LowerString(&(new_rule.reg));

    new_rule.tag = tokens[4];
    if (new_rule.tag.empty()) continue;

    std::string negative_words = tokens[5];
    if (!negative_words.empty()) {
      new_rule.vldc_negative_words = new VLDC::MultiStringVLDC;
      SplitSubStrToMultiStringVLDC(negative_words, kRuleFieldDelim, new_rule.vldc_negative_words);
    }

    // 计算规则的效果权重
    int positive = 0;
    base::StringToInt(tokens[6], &positive);
    int total = 0;
    base::StringToInt(tokens[7], &total);
    float weight = 0.0;
    if (total != 0) {
        weight = 1.0 * positive / total;
    }
    if (weight < weight_thres) {
        continue;
    }
    new_rule.weight = weight;

    // add rule
    for (auto c = match_categorys.begin();
         c != match_categorys.end();
         ++c) {
      if (c->empty()) continue;
      category_rule_dict_[*c].push_back(new_rule);
    }
  }

  return true;
}

bool TagDetector::GetTags(const std::string &category, const std::string &title,
                          std::vector<std::string> *tags) {
  CHECK_NOTNULL(tags);

  tags->clear();

  // add all category for default
  std::unordered_set<std::string> category_set;
  category_set.insert(kDefaultCategory);
  if (!category.empty()) {
    category_set.insert(category);
  }

  for (auto it = category_set.begin();
       it != category_set.end();
       ++it) {
    auto rule_search = category_rule_dict_.find(*it);
    if (rule_search == category_rule_dict_.end()) {
      return false;
    }

    std::vector<VLDC::MatchResult> match_result;
    const RuleVec &rule_vec = rule_search->second;
    for (auto rule = rule_vec.begin(); rule != rule_vec.end(); ++rule) {
      // 只要命中一个负例类别, 则该规则无效
      if (!rule->negative_categorys.empty() &&
          rule->negative_categorys.find(*it) != rule->negative_categorys.end()) {
        continue;
      }

      // 只要命中一个负例关键词，则该规则无效
      match_result.clear();
      if (rule->vldc_negative_words &&
          rule->vldc_negative_words->MatchAll(title.c_str(), title.size(), &match_result)) {
        continue;
      }

      std::string reg = rule->reg;
      base::Slice input(title);
      if (extend::re3::Re3::PartialMatch(input, reg)) {
        // 去掉与一级类别重复的语义标签
        if (rule->tag != category) {
          tags->push_back(rule->tag);

          LOG(INFO) << "title:" << title << ", category:" << category << ", rule_id:" << rule->id
                    << ", rule_reg:" << rule->reg << ", rule_tag:" << rule->tag;
        }
      }
    }
  }
  return tags->size() > 0;
}

void TagDetector::SplitSubStrToSet(const std::string &str,
                                   const std::string &delim,
                                   std::unordered_set<std::string> *tokens) {
  CHECK(tokens);

  tokens->clear();
  std::vector<std::string> flds;
  base::SplitStringUsingSubstr(str, delim, &flds);
  tokens->insert(flds.begin(), flds.end());

  return;
}

void TagDetector::SplitSubStrToMultiStringVLDC(const std::string &str,
                                               const std::string &delim,
                                               VLDC::MultiStringVLDC *vldc) {
  CHECK_NOTNULL(vldc);

  std::vector<std::string> flds;
  std::string reason;

  base::SplitStringUsingSubstr(str, delim, &flds);
  for (size_t i = 0; i < flds.size(); ++i) {
    if (!vldc->AddRule(flds[i], &reason)) {
      LOG(ERROR) << "add rule error, match key is: " << flds[i]
                 << ", reason is: " << reason;
    }
  }

  if (!vldc->Build()) {
    LOG(ERROR) << "vldc build error, str is: " << str
               << ", delim is: " << delim;
  }

  return;
}

bool TagDetector::LoadCoreWordFile(const std::string &extend_file) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(extend_file, &lines)) {
    LOG(ERROR) << "load tag extend file error: " << extend_file;
    return false;
  }

  const uint16 kRuleDictColNum = 3;

  std::vector<std::string> tokens;
  for (int i = 0; i < (int)lines.size(); ++i) {
    if (lines[i].empty() || lines[i].at(0) == '#') {
      continue;
    }

    // 核心词 \t 核心词是否可以作为标签词 \t 核心词是否需要识别
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() < kRuleDictColNum) {
      LOG(ERROR) << "rule dict column num is error, num is: " << tokens.size()
                 << ", content is: " << lines[i];
      continue;
    }
    for (auto it = tokens.begin(); it != tokens.end(); ++it) {
      *it = nlp::util::NormalizeLine(*it);
    }

    std::string coreword = tokens[0];
    if (coreword.empty()) continue;
    bool can_show = (tokens[1] == "1");
    bool is_concept = (tokens[2] == "1");

    auto it = coreword_dict_.find(coreword);
    if (it == coreword_dict_.end()) {
      coreword_dict_.insert(std::make_pair(coreword, std::make_pair(can_show, is_concept)));
    } else {
      std::string sametag = "diff";
      if (can_show == it->second.first && is_concept == it->second.second) {
        sametag = "same";
      }
      LOG(INFO) << "duplicate coreword and value is " << sametag << "! coreword:" << coreword
                << ", oldshow_newshow_oldconcept_newconcept:"
                << it->second.first << "_" << can_show << "_"
                << it->second.second << "_" << is_concept;
    }
  }
  return coreword_dict_.size() >= 1;
}

bool TagDetector::LoadExtendFile(const std::string &extend_file) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(extend_file, &lines)) {
    LOG(ERROR) << "load tag extend file error: " << extend_file;
    return false;
  }

  const uint16 kRuleDictColNum = 6;
  const std::string kRuleFieldDelim = "##";

  std::vector<std::string> tokens;
  for (int i = 0; i < (int)lines.size(); ++i) {
    if (lines[i].empty() || lines[i].at(0) == '#') {
      continue;
    }

    // valid \t id \t 核心词 \t 二级标签 \t 一级标签 \t 类别
    // valid: 1:表示启用该规则, 否则，该数据无效
    // 类别：如果支持不同类别，则类别之间以 ## 分割;
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() < kRuleDictColNum) {
      LOG(ERROR) << "rule dict column num is error, num is: " << tokens.size()
                 << ", content is: " << lines[i];
      continue;
    }
    for (auto it = tokens.begin(); it != tokens.end(); ++it) {
      *it = nlp::util::NormalizeLine(*it);
    }
    if (tokens[0] != "1") continue;

    ExtendRule new_rule;

    base::StringToInt(tokens[1], &new_rule.id);
    std::string coreword = tokens[2];
    auto it = coreword_dict_.find(coreword);
    if (it == coreword_dict_.end()) {
      LOG(INFO) << "extend coreword not found , invalid extend data ! line:" << lines[i];
      continue;
    }
    new_rule.can_show = it->second.first;
    new_rule.is_concept = it->second.second;
    if (new_rule.is_concept) continue;

    new_rule.tag2 = tokens[3];
    new_rule.tag1 = tokens[4];

    std::string category = tokens[5];
    if (category.empty()) continue;
    std::unordered_set<std::string> match_categorys;
    SplitSubStrToSet(category, kRuleFieldDelim, &match_categorys);

    // add rule
    for (auto c = match_categorys.begin();
         c != match_categorys.end();
         ++c) {
      if (c->empty()) continue;

      auto it_outer = category_entend_dict_.find(*c);
      if (it_outer == category_entend_dict_.end()) {
        ExtendMap extmap;
        extmap.insert(std::make_pair(coreword, new_rule));
        category_entend_dict_.insert(std::make_pair(*c, extmap));
      } else {
        auto it_inner = it_outer->second.find(coreword);
        if (it_inner == it_outer->second.end()) {
          it_outer->second.insert(std::make_pair(coreword, new_rule));
        } else {
          LOG(INFO) << "duplicate extend rule ! line:" << lines[i];
        }
      }
    }
  }

  return true;
}

int TagDetector::SearchCoreWord(const std::string &category, const std::string &word) {
  auto it_outer = category_entend_dict_.find(category);
  if (it_outer == category_entend_dict_.end()) {
    return 0;
  } else {
    auto it_inner = it_outer->second.find(word);
    if (it_inner == it_outer->second.end()) {
      return 0;
    } else {
      return (it_inner->second.can_show) ? 2 : 1;
    }
  }
}

bool TagDetector::GetExtendTags(const std::string &category, const std::string &word,
                                int *can_show, std::string *tag1, std::string *tag2) {
  *can_show = 0;
  auto it_outer = category_entend_dict_.find(category);
  if (it_outer == category_entend_dict_.end()) {
    return false;
  } else {
    auto it_inner = it_outer->second.find(word);
    if (it_inner == it_outer->second.end()) {
      return false;
    } else {
      *can_show = (it_inner->second.can_show) ? 2 : 1;
      *tag1 = it_inner->second.tag1;
      *tag2 = it_inner->second.tag2;
      return true;
    }
  }
}

}  // namespace reco

