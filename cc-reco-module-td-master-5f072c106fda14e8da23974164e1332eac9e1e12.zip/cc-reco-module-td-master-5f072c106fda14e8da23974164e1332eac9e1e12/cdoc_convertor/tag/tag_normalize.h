#pragma once
#include <cstdatomic>
#include <unordered_map>
#include <unordered_set>
#include <string>
#include <vector>
#include "base/thread/sync.h"
#include "base/common/basic_types.h"
#include "reco/base/common/singleton.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {

// 标签规范化模块，提供标签规范化相关接口
class TagNormalize {
 public:
  ~TagNormalize();

  static TagNormalize& Instance();

  void NormalizeTag(const reco::FeatureVector &tag_fea, reco::FeatureVector *nor_tag_fea);

  void NormalizeTag(const std::vector<std::string> tags, std::vector<std::string> *nor_tags);

  std::string SearchNormalizeTag(const std::string &org_tag);

 private:
  TagNormalize();
};
}  // namespace reco
