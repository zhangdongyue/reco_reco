#include "reco/module/cdoc_convertor/tag/tag_rule_match.h"

#include <vector>
#include <queue>
#include <unordered_map>
#include <utility>
#include <fstream>
#include <set>
#include <algorithm>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/slice.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/testing/gtest.h"
#include "nlp/common/nlp_util.h"

DEFINE_string(title_tag_rules_dir, "serving/reco/data/cdoc_convertor/ut", "");
DEFINE_string(tag_match_ut_title_file, "serving/reco/data/cdoc_convertor/ut/tag_match_ut_title.txt", "");
DEFINE_string(tag_match_ut_title2_file, "serving/reco/data/cdoc_convertor/ut/tag_match_ut_title2.txt", "");

namespace reco {

class TagMatchTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    tag_match_ = new TagMatch(FLAGS_title_tag_rules_dir);
  }

  virtual void TearDown() {
    delete tag_match_;
  }

  TagMatch *tag_match_;
};

TEST_F(TagMatchTest, TESTRULE) {
  std::vector<std::string> lines;
  EXPECT_TRUE(base::file_util::ReadFileToLines(FLAGS_tag_match_ut_title_file, &lines));
  for (int i = 0; i < (int)lines.size(); ++i) {
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    EXPECT_EQ((int)tokens.size(), 2);
    std::vector<std::string> ans1;
    std::vector<std::string> ans2;
    tag_match_->GetTags(tokens[1], tokens[0], &ans1);
    tag_match_->GetTagsSlow(tokens[1], tokens[0], &ans2);
    sort(ans1.begin(), ans1.end());
    sort(ans2.begin(), ans2.end());
    EXPECT_EQ(ans1.size(), ans2.size());
    for (int j = 0; j < (int)ans1.size(); j++) {
      EXPECT_EQ(ans1[j], ans2[j]);
    }
  }
}

TEST_F(TagMatchTest, GetTags) {
  std::vector<std::string> lines;
  EXPECT_TRUE(base::file_util::ReadFileToLines(FLAGS_tag_match_ut_title2_file, &lines));

  for (int i = 0; i < (int)lines.size(); ++i) {
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    for (auto it = tokens.begin(); it != tokens.end(); ++it) {
      *it = nlp::util::NormalizeLine(*it);
    }
    // tag \t category \t title
    if (tokens.size() < 3) {
      continue;
    }
    std::cout << lines[i] << std::endl;
    std::string tag = tokens[0];
    std::string category = tokens[1];
    std::string title = tokens[2];

    std::vector<std::string> tags;
    base::SplitString(tag, ",", &tags);
    std::set<std::string> tag_answer;
    for (std::vector<std::string>::iterator it = tags.begin();
         it != tags.end(); ++it) {
      if (*it == "" || *it == " ") continue;
      tag_answer.insert(*it);
    }

    std::vector<std::string> tag_result;
    std::set<std::string> tag_result_new;
    tag_match_->GetTags(category, title, &tag_result);
    for (auto it = tag_result.begin(); it != tag_result.end(); ++it) {
      tag_result_new.insert(*it);
    }
    EXPECT_EQ(tag_answer, tag_result_new);
  }
}
}
