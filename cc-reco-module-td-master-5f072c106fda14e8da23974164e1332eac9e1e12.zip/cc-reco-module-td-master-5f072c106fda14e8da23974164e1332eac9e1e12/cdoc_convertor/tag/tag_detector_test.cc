#include "reco/module/cdoc_convertor/tag/tag_detector.h"

#include <set>
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/testing/gtest.h"
#include "nlp/common/nlp_util.h"

DEFINE_string(category_tag_rules_dir, "serving/reco/data/cdoc_convertor/ut", "");
DEFINE_string(tag_detector_ut_file, "serving/reco/data/cdoc_convertor/ut/tag_detector_ut.txt", "");
DEFINE_string(tag_detector_extend_ut_file, "serving/reco/data/cdoc_convertor/ut/tag_detector_extend_ut.txt", "");  // NOLINT

namespace reco {

class TagDetectorTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    tag_detector_ = new TagDetector(FLAGS_category_tag_rules_dir);
  }

  virtual void TearDown() {
    delete tag_detector_;
  }

  TagDetector *tag_detector_;
};

TEST_F(TagDetectorTest, GetTags) {
  std::vector<std::string> lines;
  EXPECT_TRUE(base::file_util::ReadFileToLines(FLAGS_tag_detector_ut_file, &lines));

  for (int i = 0; i < (int)lines.size(); ++i) {
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    for (auto it = tokens.begin(); it != tokens.end(); ++it) {
      *it = nlp::util::NormalizeLine(*it);
    }
    // tag \t category \t title
    if (tokens.size() < 3) {
      continue;
    }
    std::cout << lines[i] << std::endl;
    std::string tag = tokens[0];
    std::string category = tokens[1];
    std::string title = tokens[2];

    std::vector<std::string> tags;
    base::SplitString(tag, ",", &tags);
    std::set<std::string> tag_answer;
    for (std::vector<std::string>::iterator it = tags.begin();
         it != tags.end(); ++it) {
      if (*it == "" || *it == " ") continue;
      tag_answer.insert(*it);
    }

    std::vector<std::string> tag_result;
    std::set<std::string> tag_result_new;
    tag_detector_->GetTags(category, title, &tag_result);
    for (auto it = tag_result.begin(); it != tag_result.end(); ++it) {
      tag_result_new.insert(*it);
    }
    EXPECT_EQ(tag_answer, tag_result_new);
  }
}

TEST_F(TagDetectorTest, GetExtendTags) {
  std::vector<std::string> lines;
  EXPECT_TRUE(base::file_util::ReadFileToLines(FLAGS_tag_detector_extend_ut_file, &lines));

  for (int i = 0; i < (int)lines.size(); ++i) {
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    for (auto it = tokens.begin(); it != tokens.end(); ++it) {
      *it = nlp::util::NormalizeLine(*it);
    }
    // tag \t canshow_flag(0,1,2) \t category \t word
    if (tokens.size() < 4) {
      continue;
    }
    std::cout << lines[i] << std::endl;
    std::string tag = tokens[0];
    int coreword_flag = 0;
    base::StringToInt(tokens[1], &coreword_flag);
    std::string category = tokens[2];
    std::string word = tokens[3];

    int can_show1 = tag_detector_->SearchCoreWord(category, word);
    EXPECT_EQ(coreword_flag, can_show1);

    int can_show2 = 0;
    std::string tag1 = "";
    std::string tag2 = "";
    tag_detector_->GetExtendTags(category, word, &can_show2, &tag1, &tag2);
    std::string sum_tag = tag1 + "," + tag2;

    EXPECT_EQ(coreword_flag, can_show2);
    EXPECT_EQ(tag, sum_tag);
  }
}
}
