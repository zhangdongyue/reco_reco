#include "reco/module/cdoc_convertor/rules_tree/forest.h"

namespace reco {
namespace cdoc_convertor {

const std::string kDefaultCategory = "所有类别";

Forest::Forest(const std::unordered_map<std::string, Tree*>* forest_map) {
  forest_map_ = forest_map;
}

bool Forest::Match(const reco::ItemIdentity& item_identity,
                 const std::string& title,
                 const std::string& content,
                 const std::string& source,
                 const std::string& category,
                 const std::string& snd_category,
                 const std::string& publish_time_str,
                 int64* value) {
  bool match_success = false;
  int64 value_min = 0, value_t = 0;
  auto iter = forest_map_->find(category);
  if (iter != forest_map_->end()) {
    bool match_res = iter->second->Match(item_identity,
                                         title,
                                         content,
                                         source,
                                         category,
                                         snd_category,
                                         publish_time_str,
                                         &value_t);
    if (match_res && (match_success == false || value_t < value_min)) {
      value_min = value_t;
      match_success = true;
    }
  }
  iter = forest_map_->find(kDefaultCategory);
  if (iter != forest_map_->end()) {
    bool match_res = iter->second->Match(item_identity,
                                         title,
                                         content,
                                         source,
                                         category,
                                         snd_category,
                                         publish_time_str,
                                         &value_t);
    if (match_res && (match_success == false || value_t < value_min)) {
      value_min = value_t;
      match_success = true;
    }
  }
  if (match_success) *value = value_min;
  return match_success;
}

void Forest::PrintForest() {
  for (auto iter = forest_map_->begin(); iter != forest_map_->end(); ++iter) {
    std::cout << "Tree Name: " << iter->first << std::endl;
    iter->second->PrintTree();
  }
}

}  // namespace cdoc_convertor
}  // namespace reco


