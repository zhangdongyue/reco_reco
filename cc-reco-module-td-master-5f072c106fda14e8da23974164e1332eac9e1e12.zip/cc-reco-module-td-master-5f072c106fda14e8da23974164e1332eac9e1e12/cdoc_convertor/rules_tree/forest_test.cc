#include <iostream>
#include <vector>
#include "base/common/logging.h"
#include "base/common/base.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/module/cdoc_convertor/rules_tree/forest.h"

#include "serving_base/utility/signal.h"
#include "serving_base/utility/timer.h"
#include "reco/bizc/item_service/hbase_get_item.h"


DEFINE_string(regex_file_path, "", "");
DEFINE_string(item_file_list, "", "");
DEFINE_string(rule_forest_xml_path, "", "");

// hbase config
DEFINE_string(hbase_ip, "10.181.169.19", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table, "tb_reco_item", "hbase table");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "");
  // Init Hbase
  reco::HBaseGetItem* hbase_get_item =
      new reco::HBaseGetItem(FLAGS_hbase_ip, FLAGS_hbase_port, FLAGS_hbase_table, 0);
  CHECK_NOTNULL(hbase_get_item);


  // Init RealtimeDetector
  reco::cdoc_convertor::Forest* forest = new reco::cdoc_convertor::Forest();
  reco::cdoc_convertor::Forest::Load(FLAGS_rule_forest_xml_path, forest);

  std::vector<std::string> lines;
  base::FilePath item_file_list(FLAGS_item_file_list);
  if (!FLAGS_item_file_list.empty() && base::file_util::ReadFileToLines(item_file_list, &lines)) {
    // std::cout << "line size: " << lines.size() << std::endl;
    serving_base::Timer timer;
    timer.Start();
    uint64 item_id;
    for (size_t i = 0; i < lines.size(); ++i) {
      if (!base::StringToUint64(lines[i], &item_id)) {
        LOG(WARNING) << "Fail Convert item id, the item_id str is: " << lines[i];
        continue;
      }
      // 获取 reco item
      reco::RecoItem reco_item;
      if (!hbase_get_item->GetRecoItem(item_id, &reco_item)) {
        LOG(WARNING) << "Fail Get HBase Data, item id: " << item_id;
        continue;
      }
      int32 lift_time_forest = -1;
      forest->Match(&reco_item, &lift_time_forest);
      std::string expire_time_str;
      if (lift_time_forest != -1) {
        base::Time publish_time;
        if (!base::Time::FromStringInSeconds(reco_item.raw_item().publish_time().c_str(), &publish_time)) {
          LOG(ERROR) << "Convert Publish: " << reco_item.raw_item().publish_time() << " To Time Fail";
           return false;
         }
        base::Time expire_time = base::Time::FromDoubleT(publish_time.ToDoubleT() + lift_time_forest * 60);
        expire_time.ToStringInSeconds(&expire_time_str);
      } else {
        expire_time_str = "No Limit";
      }
      std::string publish_str = reco_item.raw_item().publish_time();
      std::string category = reco_item.category(0);
      std::string snd_category = "";
      if (reco_item.category_size() > 1) {
        snd_category = reco_item.category(1);
      }
      LOG(INFO) << "item id: " << reco_item.identity().item_id() << "\t"
                << "category: " << category << "\t"
                << "snd_category: " << snd_category << "\t"
                << "item_type: " << reco_item.identity().type() << "\t"
                << "publish_time: " << publish_str;
      std::cout << item_id << "\t"
                << category << "\t"
                << reco_item.title() << "\t"
                << publish_str << "\t"
                << lift_time_forest << "\t"
                << expire_time_str
                << std::endl;
    }
    LOG(INFO) << "Use Time: " << timer.Stop();
  } else {
    LOG(INFO) << "Load Item File Fail, the file is: " << FLAGS_item_file_list;
  }
  return 0;
}
