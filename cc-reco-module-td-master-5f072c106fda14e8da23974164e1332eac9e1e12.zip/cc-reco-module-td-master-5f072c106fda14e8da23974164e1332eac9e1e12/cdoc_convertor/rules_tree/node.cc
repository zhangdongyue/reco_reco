#include "reco/module/cdoc_convertor/rules_tree/node.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace cdoc_convertor {

bool Node::Match(const reco::ItemIdentity& item_identity,
                 const std::string& title,
                 const std::string& content,
                 const std::string& source,
                 const std::string& category,
                 const std::string& snd_category,
                 const std::string& publish_time_str,
                 int64* value) {
  bool node_match_success = false;
  bool child_match_success = false;
  int64 node_match_value = 0, children_match_value = 0;
  if (IsRoot() != true) {
    if (match_type_ == kRegexRule
        && RegexMatch(title, content, source, category, snd_category)) {
      node_match_value = value_;
      node_match_success = true;
      LOG(INFO) << "[MATCH_DEBUG] item id: " << item_identity.item_id() << "\t"
                << "match regex: " << regex_rule_->pattern() << "\t"
                << "field type: " << field_type_ << "\t"
                << "value is: " << value_;
    } else if (match_type_ == kItemTypeRule && ItemTypeMatch(item_identity)) {
      node_match_value = value_;
      node_match_success = true;
      LOG(INFO) << "[MATCH_DEBUG] item id: " << item_identity.item_id() << "\t"
                << "match item type: " << item_type_rule_ << "\t"
                << "field type: " << field_type_ << "\t"
                << "value is: " << value_;
    } else if (match_type_ == kPublishTimeRule && PublishTimeMatch(publish_time_str)) {
      node_match_value = value_;
      node_match_success = true;
      // for log
      LOG(INFO) << "[MATCH_DEBUG] item id: " << item_identity.item_id() << "\t"
                << "match item type: " << item_type_rule_ << "\t"
                << "start_time: " << trigger_time_interval_.start_hour << ":"
                << trigger_time_interval_.start_min << "\t"
                << "end_time: " << trigger_time_interval_.end_hour << ":"
                << trigger_time_interval_.end_min << "\t"
                << "item_time: " << publish_time_str << "\t"
                << "value is: " << value_;
    }
    if (node_match_success && only_very_day_) {
      OnlyVeryDay(publish_time_str, &node_match_value);
    }
    if (node_match_success && only_very_week_) {
      OnlyVeryWeek(publish_time_str, &node_match_value);
    }
    if (node_match_success == false) return false;
  }

  Node* node = first_child();
  int64 value_t;
  for (; node != NULL; node = node->next_sibling()) {
    if (node->Match(item_identity, title, content, source,
                    category, snd_category, publish_time_str,
                    &value_t) == true) {
      if (child_match_success == false || value_t < children_match_value) {
        child_match_success = true;
        children_match_value = value_t;
      }
    }
  }
  if (child_match_success == false && node_match_success == false) return false;
  if (child_match_success == true) {
    *value = children_match_value;
  } else {
    *value = node_match_value;
  }
  return true;
}

bool Node::ItemTypeMatch(const reco::ItemIdentity& item_identity) {
  if (field_type_ == kItemType) {
    return item_identity.type() == item_type_rule_;
  } else {
    return false;
  }
}

bool Node::PublishTimeMatch(const std::string& publish_time_str) {
  base::Time publish_time;
  if (!base::Time::FromStringInSeconds(publish_time_str.c_str(), &publish_time)) {
    LOG(ERROR) << "Convert Publish: " << publish_time_str << " To Time Fail";
    return false;
  }
  int32 start_time = trigger_time_interval_.start_hour * 60 + trigger_time_interval_.start_min;
  int32 end_time = trigger_time_interval_.end_hour * 60 + trigger_time_interval_.end_min;
  // 是否跨天
  bool cross_zero_point = false;
  if (end_time < start_time) {
    cross_zero_point = true;
  }

  // 因为时区 +8 小时
  time_t tm_t = publish_time.ToTimeT() + 28800;
  struct tm tm_val;
  struct tm *tm_p = gmtime_r(&tm_t, &tm_val);
  int32 publish_hour = tm_p->tm_hour;
  int32 publish_min = tm_p->tm_min;
  int32 p_time = publish_hour * 60 + publish_min;
  if (cross_zero_point == false) {
    return (p_time >= start_time && p_time <= end_time);
  } else {
    return (p_time >= start_time || p_time <= end_time);
  }
}

bool Node::RegexMatch(const std::string& title, const std::string& content, const std::string& source,
                      const std::string& category, const std::string& snd_category) {
  if (field_type_ == kTitle) {
    if (regex_rule_ != NULL &&
        extend::re3::Re3::PartialMatch(title.c_str(), *regex_rule_)) {
      return true;
    }
  } else if (field_type_ == kContent) {
    if (regex_rule_ != NULL &&
        extend::re3::Re3::PartialMatch(content.c_str(), *regex_rule_)) {
      return true;
    }
  } else if (field_type_ == kSource) {
    if (regex_rule_ != NULL &&
        extend::re3::Re3::PartialMatch(source.c_str(), *regex_rule_)) {
      return true;
    }
  } else if (field_type_ == kCategory) {
    if (regex_rule_ != NULL &&
        extend::re3::Re3::PartialMatch(category.c_str(), *regex_rule_)) {
      return true;
    }
  } else if (field_type_ == kSndCategory) {
    if (snd_category.empty()) return false;
    if (regex_rule_ != NULL &&
        extend::re3::Re3::PartialMatch(snd_category.c_str(), *regex_rule_)) {
      return true;
    }
  }
  return false;
}

bool Node::OnlyVeryDay(const std::string& publish_time_str, int64* alive_time) {
  base::Time publish_time;
  if (!base::Time::FromStringInSeconds(publish_time_str.c_str(), &publish_time)) {
    LOG(ERROR) << "Convert Publish: " << publish_time_str << " To Time Fail";
    return false;
  }

  int64 zero_point_timestamp = (((publish_time.ToDoubleT() + 8 * 3600)
                                      / (24 * 3600)) + 1) * (24 * 3600);
  *alive_time = (zero_point_timestamp - (publish_time.ToDoubleT() + 8 * 3600)) / 60;
  return true;
}

bool Node::OnlyVeryWeek(const std::string& publish_time_str, int64* alive_time) {
  base::Time publish_time;
  if (!base::Time::FromStringInSeconds(publish_time_str.c_str(), &publish_time)) {
    LOG(ERROR) << "Convert Publish: " << publish_time_str << " To Time Fail";
    return false;
  }
  // 因为时区 +8 小时
  time_t tm_t = publish_time.ToTimeT() + 28800;
  struct tm tm_val;
  struct tm *tm_p = gmtime_r(&tm_t, &tm_val);
  int32 remain_day = (7 - tm_p->tm_wday) % 7;
  int64 zero_point_timestamp = (((publish_time.ToDoubleT() + 8 * 3600) / (24 * 3600))
                                + remain_day + 1) * (24 * 3600);
  *alive_time = (zero_point_timestamp - (publish_time.ToDoubleT() + 8 * 3600)) / 60;
  return true;
}
}  // namepaace cdoc_convertor
}  // namespace reco

