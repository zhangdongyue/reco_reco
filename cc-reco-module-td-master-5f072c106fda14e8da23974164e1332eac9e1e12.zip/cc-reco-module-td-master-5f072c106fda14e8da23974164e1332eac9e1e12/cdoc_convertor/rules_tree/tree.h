#pragma once

#include <map>
#include <string>
#include <vector>
#include "base/common/base.h"
#include "base/common/basic_types.h"

#include "reco/module/item_level/base/base.h"
#include "reco/bizc/proto/common.pb.h"

#include "util/xml/tree_node.h"
#include "util/xml/tinyxml.h"
#include "base/strings/string_split.h"

#include "reco/module/cdoc_convertor/rules_tree/enum_define.h"
#include "reco/module/cdoc_convertor/rules_tree/node.h"

namespace reco {
namespace cdoc_convertor {

class Tree {
  friend class Forest;

 public:
  explicit Tree();
  ~Tree();

  bool Match(const reco::ItemIdentity& item_identity,
             const std::string& title,
             const std::string& content,
             const std::string& source,
             const std::string& category,
             const std::string& snd_category,
             const std::string& publish_time_str,
             int64* value);

  static bool ParseTree(const xml::TiXmlNode* tree_node, Tree* tree);

  void PrintTree();
  void PrintTree(Node* node, int32 depth);
  void SetTreeName(const std::string& tree_name);
 private:
  // input format xx:xx example start 09:30 end 21:30. 支持跨天
  static bool ParsePublishTimeInterval(const std::string& start, const std::string& end,
                                       TimeInterval* time_interval);
 private:
  Node* root_;
  std::string tree_name_;
};

}  // namespace cdoc_convertor
}  // namespace reco

