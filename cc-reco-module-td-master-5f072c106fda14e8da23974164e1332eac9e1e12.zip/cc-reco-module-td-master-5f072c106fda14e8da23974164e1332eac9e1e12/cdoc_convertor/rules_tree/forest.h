#pragma once

#include <string>
#include <unordered_map>
#include "reco/module/cdoc_convertor/rules_tree/tree.h"

namespace reco {
namespace cdoc_convertor {

class Forest {
 public:
  explicit Forest(const std::unordered_map<std::string, Tree*>* forest_map);
  ~Forest() {}

  // 给定 item，返回其在规则上命中的值
  bool Match(const reco::ItemIdentity& item_identity,
             const std::string& title,
             const std::string& content,
             const std::string& source,
             const std::string& category,
             const std::string& snd_category,
             const std::string& publish_time_str,
             int64* value);
  // 打印整颗森林
  void PrintForest();

 private:
  const std::unordered_map<std::string, Tree*>* forest_map_;
};
}  // namespace cdoc_convertor
}  // namespace reco
