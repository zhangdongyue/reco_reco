#include "reco/module/cdoc_convertor/rules_tree/tree.h"

namespace reco {
namespace cdoc_convertor {

Tree::Tree() {
}

Tree::~Tree() {
  delete root_;
};

bool Tree::Match(const reco::ItemIdentity& item_identity,
                 const std::string& title,
                 const std::string& content,
                 const std::string& source,
                 const std::string& category,
                 const std::string& snd_category,
                 const std::string& publish_time_str,
                 int64* value) {
  return root_->Match(item_identity, title, content, source,
                      category, snd_category, publish_time_str, value);
}

bool Tree::ParseTree(const xml::TiXmlNode* tree_node, Tree* tree) {
  CHECK_NOTNULL(tree_node);
  const xml::TiXmlElement* node_num_element = tree_node->FirstChildElement("node_num");
  CHECK_NOTNULL(node_num_element);
  int32 node_num = -1;
  CHECK_EQ(node_num_element->QueryIntAttribute("value", &node_num), xml::TIXML_SUCCESS);
  // 用来记录 id-> 指针的映射
  std::vector<Node*> nodes(node_num, NULL);
  // 用来记录父亲节点 id
  std::vector<int32> parent(node_num, -1);
  int node_id = -1;
  std::string match_type_str;
  std::string field_type_str;
  // var for log
  int32 load_node_num = 0;
  std::vector<std::string> parents_vec;
  for (const xml::TiXmlElement* element = tree_node->FirstChildElement("node"); element;
       element = element->NextSiblingElement("node")) {
    element->QueryIntAttribute("node_id", &node_id);
    CHECK_LT(node_id, node_num);
    CHECK_LT(-1, node_id);
    // 父亲节点 id
    CHECK_EQ(element->QueryIntAttribute("parent_id", &(parent[node_id])), xml::TIXML_SUCCESS);
    if (parent[node_id] == -1) {
      nodes[node_id] = new Node();
      ++load_node_num;
      continue;
    }
    // 使用到的变量
    extend::re3::Re3* regex_rule = NULL;
    reco::ItemType item_type = kNews;
    TimeInterval time_interval;
    CHECK_EQ(element->QueryStringAttribute("match_type", &match_type_str), xml::TIXML_SUCCESS);
    CHECK_EQ(element->QueryStringAttribute("field_type", &field_type_str), xml::TIXML_SUCCESS);
    auto match_type_iter = match_type_map.find(match_type_str);
    auto field_type_iter = field_type_map.find(field_type_str);
    CHECK(match_type_iter != match_type_map.end());
    CHECK(field_type_iter != field_type_map.end());
    // 节点的 value
    int32 value;
    CHECK_EQ(element->QueryIntAttribute("alive_time", &value), xml::TIXML_SUCCESS);
    // 如果是正则匹配 则记录正则匹配串
    if (match_type_iter->second == kRegexRule) {
      std::string regex_rule_str;
      CHECK_EQ(element->QueryStringAttribute("regex_rule", &regex_rule_str), xml::TIXML_SUCCESS);
      regex_rule = new extend::re3::Re3(regex_rule_str);
      CHECK(regex_rule->ok());
    } else if (match_type_iter->second == kItemTypeRule) {
      std::string item_type_rule_str;
      CHECK_EQ(element->QueryStringAttribute("item_type_rule", &item_type_rule_str), xml::TIXML_SUCCESS);
      auto item_type_iter = item_type_map.find(item_type_rule_str);
      CHECK(item_type_iter != item_type_map.end());
      item_type = item_type_iter->second;
    } else if (match_type_iter->second == kPublishTimeRule) {
      std::string start_time, end_time;
      CHECK_EQ(element->QueryStringAttribute("publish_start_time", &start_time), xml::TIXML_SUCCESS);
      CHECK_EQ(element->QueryStringAttribute("publish_end_time", &end_time), xml::TIXML_SUCCESS);
      CHECK(ParsePublishTimeInterval(start_time, end_time, &time_interval));
    }
    CHECK(nodes[node_id] == NULL);
    nodes[node_id] = new Node(node_id, match_type_iter->second, field_type_iter->second,
                              regex_rule, item_type, value);
    if (match_type_iter->second == kPublishTimeRule) {
      nodes[node_id]->trigger_time_interval_ = time_interval;
    }
    if (element->QueryBoolAttribute("OnlyVeryDay", &(nodes[node_id]->only_very_day_))
        != xml::TIXML_SUCCESS) {
      nodes[node_id]->only_very_day_ = false;
    }
    if (element->QueryBoolAttribute("OnlyVeryWeek", &(nodes[node_id]->only_very_week_))
        != xml::TIXML_SUCCESS) {
      nodes[node_id]->only_very_week_ = false;
    }

    ++load_node_num;
  }
  for (size_t i = 0; i < nodes.size(); ++i) {
    if (nodes[i] != NULL) {
      if (parent[i] != -1) {
        CHECK_LT(parent[i], node_num);
        LOG(INFO) << "Node: " << parent[i] << " add child: " << i;
        nodes[parent[i]]->AddChild(nodes[i]);
      }
    }
  }
  int32 root_num = 0;
  for (size_t i = 0; i < nodes.size(); ++i) {
    if (nodes[i] != NULL && nodes[i]->IsRoot()) {
      tree->root_ = nodes[i];
      ++root_num;
    }
  }
  CHECK_EQ(1, root_num);
  LOG(INFO) << "Load Tree Success, Tree Name: "  << tree->tree_name_ << "\t"
            << "Total Node Num is:" << node_num << "\t"
            << "Load Node Num:" << load_node_num << "\t"
            << "root num: " << root_num;
  return true;
}

void Tree::PrintTree() {
  PrintTree(root_, 0);
}

void Tree::PrintTree(Node* node, int32 depth) {
  for (int32 i = 0; i < depth; ++i) std::cout << "  ";
  std::cout << "node id: " << node->node_id_ << "  ";
  for (auto iter = field_type_map.begin(); iter != field_type_map.end(); ++iter) {
    if (iter->second == node->field_type_) {
      std::cout << "FieldType: " << iter->first << "  ";
      break;
    }
  }
  for (auto iter = match_type_map.begin(); iter != match_type_map.end(); ++iter) {
    if (iter->second == node->match_type_) {
      std::cout << "MatchType: " << iter->first << "  ";
      break;
    }
  }
  if (node->match_type_ == kRegexRule) {
    std::cout << "RegexRule: " << node->regex_rule_->pattern() << "  ";
  } else {
    std::cout << "RegexRule: NULL" << "  ";
  }
  if (node->match_type_ == kItemTypeRule) {
    for (auto iter = item_type_map.begin(); iter != item_type_map.end(); ++iter) {
      if (iter->second == node->item_type_rule_) {
        std::cout << "ItemTypeRule: " << iter->first << "  ";
        break;
      }
    }
  } else {
    std::cout << "ItemTypeRule: NULL" << "  ";
  }
  std::cout << node->value_ << std::endl;
  if (node->HasChildren()) {
    Node* child = node->first_child();
    while (child != NULL) {
      PrintTree(child, depth + 1);
      child = child->next_sibling();
    }
  }
}

void Tree::SetTreeName(const std::string& tree_name) {
  tree_name_ = tree_name;
}

bool Tree::ParsePublishTimeInterval(const std::string& start, const std::string& end,
                                    TimeInterval* time_interval) {
  std::vector<std::string> hour_min;
  hour_min.clear();
  base::SplitString(start, ":", &hour_min);
  CHECK_EQ(hour_min.size(), 2u);
  CHECK(base::StringToInt(hour_min[0], &(time_interval->start_hour)));
  CHECK(base::StringToInt(hour_min[1], &(time_interval->start_min)));
  hour_min.clear();
  base::SplitString(end, ":", &hour_min);
  CHECK_EQ(hour_min.size(), 2u);
  CHECK(base::StringToInt(hour_min[0], &(time_interval->end_hour)));
  CHECK(base::StringToInt(hour_min[1], &(time_interval->end_min)));
  if ((time_interval->end_hour >= 0 && time_interval->end_hour <= 23)
      && (time_interval->start_hour >= 0 && time_interval->start_hour <= 23)
      && (time_interval->start_min >= 0 && time_interval->start_min <= 59)
      && (time_interval->end_min >= 0 && time_interval->end_min <= 59)) return true;
  return false;
}
}  // namespace cdoc_convertor
}  // namespace reco

