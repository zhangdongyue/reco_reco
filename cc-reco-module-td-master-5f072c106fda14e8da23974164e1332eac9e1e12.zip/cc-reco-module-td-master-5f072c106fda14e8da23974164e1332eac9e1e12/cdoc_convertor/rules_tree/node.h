#pragma once

#include <unordered_map>
#include <string>
#include <vector>
#include "base/common/base.h"
#include "base/common/basic_types.h"

#include "extend/regexp/re3/re3.h"

#include "reco/module/item_level/base/base.h"
#include "reco/bizc/proto/common.pb.h"

#include "util/xml/tree_node.h"

#include "reco/module/cdoc_convertor/rules_tree/enum_define.h"

namespace reco {
namespace cdoc_convertor {

// 表示一段时间区间
struct TimeInterval {
  int32 start_hour;
  int32 start_min;
  int32 end_hour;
  int32 end_min;
};

class Node: public util::xml::TreeNode<Node> {
  friend class Tree;
 public:
  Node() {
    regex_rule_ = NULL;
    field_type_ = kTitle;
    match_type_ = kNullRule;
  }
  Node(int32 node_id, MatchType match_type, FieldType field_type,
                extend::re3::Re3* regex_rule, reco::ItemType item_type_rule, int64 value):
      node_id_(node_id), match_type_(match_type), field_type_(field_type),
      regex_rule_(regex_rule), item_type_rule_(item_type_rule), value_(value) {}

  bool Match(const reco::ItemIdentity& item_identity,
             const std::string& title,
             const std::string& content,
             const std::string& source,
             const std::string& category,
             const std::string& snd_category,
             const std::string& publish_time_str,
             int64* value);
 private:
  int32 node_id_;
  // 匹配类型 和 匹配用的字段
  MatchType match_type_;
  FieldType field_type_;
  // 规则库
  extend::re3::Re3* regex_rule_;
  reco::ItemType item_type_rule_;
  // 是否当天有效和当周有效
  bool only_very_day_;
  bool only_very_week_;
  // Publish Start and End
  TimeInterval trigger_time_interval_;
  // 匹配成功的匹配值
  int64 value_;
 private:
  bool RegexMatch(const std::string& title, const std::string& content, const std::string& source,
                  const std::string& category, const std::string& snd_category);
  bool ItemTypeMatch(const reco::ItemIdentity& item_identity);
  bool PublishTimeMatch(const std::string& publish_time_str);
  bool OnlyVeryDay(const std::string& publish_time_str, int64* alive_time);
  bool OnlyVeryWeek(const std::string& publish_time_str, int64* alive_time);
};
}  // namespace cdoc_convertor
}  // namespace reco

