#pragma once

#include <unordered_map>
#include <string>
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace cdoc_convertor {

// 匹配类型
enum MatchType {
  kNullRule,
  kRegexRule,
  kItemTypeRule,
  kPublishTimeRule,
};

// 匹配使用的字段
enum FieldType {
  kTitle,
  kContent,
  kSource,
  kItemType,
  kCategory,
  kSndCategory,
  kPublishTime
};

static const std::unordered_map<std::string, MatchType> match_type_map = {
  {"kNullRule", kNullRule}, {"kRegexRule", kRegexRule},
  {"kItemTypeRule", kItemTypeRule}, {"kPublishTimeRule", kPublishTimeRule}
};

static const std::unordered_map<std::string, FieldType> field_type_map = {
  {"kTitle", kTitle}, {"kContent", kContent}, {"kSource", kSource}, {"kItemType", kItemType},
  {"kCategory", kCategory}, {"kSndCategory", kSndCategory}, {"kPublishTime", kPublishTime},
};

static const std::unordered_map<std::string, reco::ItemType> item_type_map = {
  {"kNews", reco::kNews}, {"kReading", reco::kReading}, {"kPicture", reco::kPicture},
  {"kHumor", reco::kHumor}, {"kPictureNews", reco::kPictureNews},
};
}  // namespace cdoc_convertor
}  // namespace reco

