#include <iostream>
#include <string>

#include "base/common/base.h"
#include "base/common/logging.h"

#include "segment_dll.h"
#include "postag_dll.h"
#include "parser_dll.h"

DEFINE_string(input, "", "1");
DEFINE_int32(threads, 1, "");
DEFINE_string(segmentor_model, "ltp_data/cws.model", "1");
DEFINE_string(segmentor_lexicon, "", "1");
DEFINE_string(postagger_model, "ltp_data/pos.model", "1");
DEFINE_string(parser_model, "ltp_data/parser.model", "1");


int main(int argc, char * argv[]) {
    base::InitApp(&argc, &argv, "xss dep parser");
    std::cout << "hello world";

    void * seg_engine = segmentor_create_segmentor(FLAGS_segmentor_model.c_str(), FLAGS_segmentor_lexicon.c_str());
    if (!seg_engine) {
        return -1;
    }
    void * pos_engine = postagger_create_postagger(FLAGS_postagger_model.c_str());
    if (!pos_engine) {
        return -1;
    }
    void * dep_engine = parser_create_parser(FLAGS_parser_model.c_str());
    if (!dep_engine) {
        return -1;
    }

    std::vector<std::string> words;
    int len = segmentor_segment(seg_engine,
            "爱上一匹野马，可我的家里没有草原。", words);
    for (int i = 0; i < len; ++ i) {
        std::cout << words[i] << "|";
    }
    std::cout << std::endl;

    std::vector<std::string> tags;
    postagger_postag(pos_engine, words, tags);
    for (int i = 0; i < (int)tags.size(); ++ i) {
        std::cout << words[i] << "/" << tags[i];
        if (i == (int)tags.size() - 1) std::cout << std::endl;
        else std::cout << " ";

    }

    std::vector<int>            heads;
    std::vector<std::string>    deprels;
    parser_parse(dep_engine, words, tags, heads, deprels);
    for (int i = 0; i < (int)heads.size(); ++ i) {
        std::cout << words[i] << "\t" << tags[i] << "\t"
            << heads[i] << "\t" << deprels[i] << std::endl;
    }

    segmentor_release_segmentor(seg_engine);
    postagger_release_postagger(pos_engine);
    parser_release_parser(dep_engine);
    return 0;
}

