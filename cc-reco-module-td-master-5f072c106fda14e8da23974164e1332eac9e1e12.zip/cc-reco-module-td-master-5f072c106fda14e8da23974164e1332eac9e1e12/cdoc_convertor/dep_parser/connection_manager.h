#pragma once

namespace net {
namespace rpc {
class RpcGroup;
}
}

namespace reco {

class ConnectionManager {
 public:
  static bool InitConnection();
  static void CleanConnection();

  static net::rpc::RpcGroup* GetItemKeeperGroup() {
    return item_keeper_rpc_group_;
  }

 private:
  static net::rpc::RpcGroup* item_keeper_rpc_group_;
};
}
