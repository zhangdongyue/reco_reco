#pragma once

#include <string>
#include <utility>
#include <unordered_map>
#include <vector>

#include "base/thread/blocking_queue.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "serving_base/mysql_util/db_conn_manager.h"

namespace extend {
class MultiPatternMatcher;
};

namespace reco {
class RawItemConvertor;

class CorewordWorker {
 public:
  CorewordWorker(thread::BlockingQueue<RecoItem>* item_queue, bool is_online,
      void* seg_engine = NULL, void* pos_engine = NULL, void* dep_engine = NULL);
  ~CorewordWorker();

  // 对 item_queue 中的 item ，计算主语频次，并写入相应字段
  void Run();

 private:
  bool IsDepValid(const reco::RecoItem& reco_item);
  // 计算主语频次
  void CalcCoreword(const std::string str);
  static bool cmp_by_value(const std::pair<std::string, int>& lhs, const std::pair<std::string, int>& rhs) {
    return lhs.second > rhs.second;
  }
  // 将主语频次写入相应字段
  bool UpdateRecoItem(reco::RecoItem* reco_item);
  // 设置 dep_info
  void SetDepInfo(reco::RecoItem* reco_item);
  // 输出该 item 的相关信息
  void OuputItem(const reco::RecoItem& reco_item);
  // 获取 RecoItem.tag
  std::string GetTagsStr(const reco::RecoItem& reco_item);

  thread::BlockingQueue<RecoItem>* item_queue_;
  bool is_online_;
  void* seg_engine_;
  void* pos_engine_;
  void* dep_engine_;

  static const int kMinFreq = 3;

  serving_base::mysql_util::DbConnManager* db_manager_;
  reco::RawItemConvertor* raw_convertor_;
  reco::itemkeeper::ItemKeeper::Stub* item_keeper_stub_;

  extend::MultiPatternMatcher *match_;
  std::unordered_map<std::string, int> coreword_freq_dict_;
};
}
