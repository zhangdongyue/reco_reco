#include "reco/module/cdoc_convertor/dep_parser/connection_manager.h"

#include <string>
#include <vector>

#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"
#include "base/strings/string_split.h"

DEFINE_string(item_keeper_server_ips, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_int32(item_keeper_timeout, 3000, "search server rpc timeout in ms");
DEFINE_int32(item_keeper_retry_times, 2, "search server rpc retry times");

namespace reco {

net::rpc::RpcGroup* ConnectionManager::item_keeper_rpc_group_ = NULL;

static net::rpc::RpcGroup* SetupConnection(const std::vector<std::string>& ips, int port,
                                           int timeout, int retry) {
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = retry;
  options.timeout = timeout;
  for (int i = 0; i < (int)ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], port, timeout);
    options.servers.push_back(si);
  }

  auto group = new net::rpc::RpcGroup(options);
  CHECK(group->Connect()) << "connect fail";
  return group;
}

bool ConnectionManager::InitConnection() {
  std::vector<std::string> flds;

    flds.clear();
  base::SplitString(FLAGS_item_keeper_server_ips, ",", &flds);
  item_keeper_rpc_group_ = SetupConnection(flds,
                                      FLAGS_item_keeper_server_port,
                                      FLAGS_item_keeper_timeout,
                                      FLAGS_item_keeper_retry_times);
  return true;
}

void ConnectionManager::CleanConnection() {
  delete item_keeper_rpc_group_;
}
}
