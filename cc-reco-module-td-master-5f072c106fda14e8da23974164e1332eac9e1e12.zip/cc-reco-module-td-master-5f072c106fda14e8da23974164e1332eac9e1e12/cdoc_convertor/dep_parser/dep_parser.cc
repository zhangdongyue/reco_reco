#include <iostream>
#include <string>
#include <vector>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/thread/thread_pool.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/module/cdoc_convertor/dep_parser/coreword_worker.h"
#include "reco/module/cdoc_convertor/dep_parser/connection_manager.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"

#include "segment_dll.h"
#include "postag_dll.h"
#include "parser_dll.h"

DECLARE_string(hbase_reco_item_table);
DEFINE_int32(thread_num, 8, "thread num for send request");
DEFINE_string(item_id_file, "", "");
DEFINE_bool(is_online, false, "true: update the field by item_keeper; false: write the field directly");

// 分词词典
DEFINE_string(segmentor_model, "ltp_data/cws.model", "1");
DEFINE_string(segmentor_lexicon, "", "1");
DEFINE_string(postagger_model, "ltp_data/pos.model", "1");
DEFINE_string(parser_model, "ltp_data/parser.model", "1");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "xss dep parser");
  if (!FLAGS_is_online) {
    reco::GlobalDataIns::instance().Init();
  }
  CHECK(reco::ConnectionManager::InitConnection()) << "Initialize connection error";

  // hbase 初始化
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());
  reco::HBaseGetItem* hbase_get_item =
      new reco::HBaseGetItem(FLAGS_hbase_reco_item_table, 0);

  // 依存工具初始化
  void* seg_engine = segmentor_create_segmentor(FLAGS_segmentor_model.c_str(),
      FLAGS_segmentor_lexicon.c_str());
  if (!seg_engine) {
    return -1;
  }
  void* pos_engine = postagger_create_postagger(FLAGS_postagger_model.c_str());
  if (!pos_engine) {
    return -1;
  }
  void* dep_engine = parser_create_parser(FLAGS_parser_model.c_str());
  if (!dep_engine) {
    return -1;
  }

  // 读取要处理的数据
  thread::BlockingQueue<reco::RecoItem> item_queue;
  LOG(INFO) << "preparing request data, please wait...";
  if (!FLAGS_item_id_file.empty()) {
    std::vector<std::string> lines;
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines);
    for (int i = 0; i < (int)lines.size(); ++i) {
      base::TrimTrailingWhitespaces(&(lines[i]));

      uint64 item_id;
      if (!base::StringToUint64(lines[i], &item_id)) continue;

      reco::RecoItem reco_item;
      if (!hbase_get_item->GetRecoItem(item_id, &reco_item)) {
        LOG(WARNING) << "can't find item in hbase, " << item_id;
        continue;
      }
      item_queue.Put(reco_item);
    }
  }

  std::vector<reco::CorewordWorker*> workers;
  int total_workers = FLAGS_thread_num;

  thread::ThreadPool pool(total_workers);
  for (int i = 0; i < total_workers; ++i) {
    workers.push_back(new reco::CorewordWorker(&item_queue, FLAGS_is_online,
        seg_engine, pos_engine, dep_engine));
    pool.AddTask(::NewCallback(workers.back(), &reco::CorewordWorker::Run));
  }
  pool.JoinAll();

  segmentor_release_segmentor(seg_engine);
  postagger_release_postagger(pos_engine);
  parser_release_parser(dep_engine);
  return 0;
}

