#include "reco/module/cdoc_convertor/dep_parser/coreword_worker.h"

#include <algorithm>

#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "extend/multi_strings/multi_pattern_matcher.h"
#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"
#include "nlp/common/nlp_util.h"
#include "reco/module/cdoc_convertor/convertor/raw_item_convertor.h"
#include "reco/module/cdoc_convertor/dep_parser/connection_manager.h"

#include "segment_dll.h"
#include "postag_dll.h"
#include "parser_dll.h"

DEFINE_string(hbase_reco_item_table, "tb_reco_item", "hbase table, tb_reco_item");
DEFINE_bool(recalc_tag, false, "");
// mysql
DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

namespace reco {

CorewordWorker::CorewordWorker(thread::BlockingQueue<RecoItem>* item_queue, bool is_online,
                               void* seg_engine, void* pos_engine, void* dep_engine) {
  item_queue_ = item_queue;
  is_online_ = is_online;
  seg_engine_ = seg_engine;
  pos_engine_ = pos_engine;
  dep_engine_ = dep_engine;

  // 句子分隔符
  match_ = new extend::MultiPatternMatcher();
  CHECK(match_->AddPattern("!"));
  CHECK(match_->AddPattern("?"));
  CHECK(match_->AddPattern(";"));
  CHECK(match_->AddPattern("。"));
  CHECK(match_->AddPattern("\n"));
  CHECK(match_->Build());

  // convertor 初始化
  serving_base::mysql_util::DbConnManager::Option option;
  option.host = FLAGS_db_host;
  option.user = FLAGS_db_user;
  option.passwd = FLAGS_db_passwd;
  option.schema = FLAGS_schema;
  db_manager_ = new serving_base::mysql_util::DbConnManager(option);
  raw_convertor_ = NULL;
  if (!is_online_) {
    raw_convertor_ = new reco::RawItemConvertor(FLAGS_hbase_reco_item_table, db_manager_);
  }

  item_keeper_stub_ = new reco::itemkeeper::ItemKeeper::Stub(ConnectionManager::GetItemKeeperGroup());
}

CorewordWorker::~CorewordWorker() {
  delete match_;
  delete db_manager_;
  if (raw_convertor_ != NULL) {
    delete raw_convertor_;
    raw_convertor_ = NULL;
  }
  delete item_keeper_stub_;
}

void CorewordWorker::Run() {
  int dep_item_num = 0;
  while (!item_queue_->Empty()) {
    reco::RecoItem reco_item;
    if (item_queue_->TryTake(&reco_item) != 1) continue;
    if (!IsDepValid(reco_item)) continue;
    uint64 item_id = reco_item.identity().item_id();
    if (!FLAGS_recalc_tag && reco_item.dep_info_size() > 0) {
      VLOG(1) << "dep_info_size > 0, so skip ! item_id:" << item_id;
      continue;
    }

    coreword_freq_dict_.clear();

    // 调用依存工具
    VLOG(2) << "calc title coreword ! title:" << reco_item.title();
    CalcCoreword(nlp::util::NormalizeLine(reco_item.title()));

    std::string content = nlp::util::NormalizeMultiLines(reco_item.content());
    VLOG(2) << "calc content coreword ! content:" << content;
    std::vector<base::Slice> sentences;
    nlp::util::TextSplitSentence(content, match_, -1, &sentences);
    for (int j = 0; j < (int)sentences.size(); ++j) {
      VLOG(2) << "sentence j:" << j << ", info:" << sentences[j].as_string();
      CalcCoreword(sentences[j].as_string());
    }

    // 依存结果按频次降序排序
    std::vector<std::pair<std::string, int> > vec(coreword_freq_dict_.begin(), coreword_freq_dict_.end());
    std::sort(vec.begin(), vec.end(), cmp_by_value);
    VLOG(1) << "sub freq info size:" << vec.size();
    for (auto it = vec.begin(); it != vec.end(); ++it) {
      VLOG(1) << it->first << ":" << it->second << "\t";
    }
    if ((int)vec.size() == 0 || vec[0].second < kMinFreq) {
      VLOG(1) << "no subject freq >= 3 ! item_id:" << item_id;
      continue;
    }

    // 将依存结果写到 RecoItem
    std::string old_tags = GetTagsStr(reco_item);
    if (!UpdateRecoItem(&reco_item)) continue;
    std::string new_tags = GetTagsStr(reco_item);
    std::string label = (new_tags == old_tags) ? "SAME" : "DIFF";
    VLOG(1) << "TAGS " << label << ", item_id:" << item_id
            << ", old_tags: [" << old_tags << "], new_tags: [" << new_tags << "]";

    if (!is_online_) {
      OuputItem(reco_item);
    }
    ++dep_item_num;
  }
  LOG(INFO) << "dep_item_num:" << dep_item_num;
}

bool CorewordWorker::IsDepValid(const reco::RecoItem& reco_item) {
  if (reco_item.identity().type() == reco::kPureVideo) {
    VLOG(1) << "video dep invalid !" << reco_item.identity().item_id();
    return false;
  }
  if (reco_item.category_size() == 0
      || (reco_item.category(0) != "娱乐"
          && reco_item.category(0) != "体育"
          && reco_item.category(0) != "历史"
          && reco_item.category(0) != "国际")) {
    VLOG(1) << "category dep invalid !" << reco_item.identity().item_id();
    return false;
  }
  return true;
}

void CorewordWorker::CalcCoreword(const std::string str) {
  std::string str_new = nlp::util::NormalizeLine(str);

  std::vector<std::string> words;
  std::vector<std::string> tags;
  std::vector<int> heads;
  std::vector<std::string> deprels;

  segmentor_segment(seg_engine_, str_new, words);
  postagger_postag(pos_engine_, words, tags);
  parser_parse(dep_engine_, words, tags, heads, deprels);

  VLOG(2) << str_new << "\t" << heads.size() << "\t";
  for (int i = 0; i < (int)heads.size(); ++i) {
    VLOG(2) << "/" << words[i] << "," << tags[i] << ","
            << heads[i] << "," << deprels[i];
    if (deprels[i] == "SBV" && !words[i].empty()) {
      auto it = coreword_freq_dict_.find(words[i]);
      if (it == coreword_freq_dict_.end()) {
        coreword_freq_dict_.insert(std::make_pair(words[i], 1));
      } else {
        ++(it->second);
      }
    }
  }
}

bool CorewordWorker::UpdateRecoItem(reco::RecoItem* reco_item) {
  uint64 item_id = reco_item->identity().item_id();

  if (is_online_) {
    reco::RecoItem new_reco_item;
    SetDepInfo(&new_reco_item);

    reco::itemkeeper::UpdateItemRequest request;
    reco::itemkeeper::UpdateItemFieldResponse response;
    request.mutable_service_identity()->set_service_name("dep_parser");
    request.set_item_id(item_id);
    new_reco_item.SerializePartialToString(request.mutable_reco_item_bytes());
    VLOG(1) << "add dep_info rpc request ! item_id:" << item_id;

    net::rpc::RpcClientController rpc;
    item_keeper_stub_->updateItemFields(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "set dep_info failed ! item id: " << item_id << ", response: "
                 << response.Utf8DebugString();
      return false;
    } else {
      LOG(INFO) << "done set dep_info: " << item_id;
      return true;
    }
  } else {
    SetDepInfo(reco_item);
    return raw_convertor_->UpdateRecoItem(reco_item, NULL);
  }
}

void CorewordWorker::SetDepInfo(reco::RecoItem* reco_item) {
  reco_item->clear_dep_info();
  for (auto it_core = coreword_freq_dict_.begin(); it_core != coreword_freq_dict_.end(); ++it_core) {
    if (it_core->second >= kMinFreq) {
      reco::DepInfo* di = reco_item->add_dep_info();
      di->set_word(it_core->first);
      di->set_freq(it_core->second);
      di->set_mark("SBV");
    }
  }
}

std::string CorewordWorker::GetTagsStr(const reco::RecoItem& reco_item) {
  std::string out_tags = "";
  if (reco_item.has_tag()) {
    for (int i = 0; i < reco_item.tag().feature_size(); ++i) {
      out_tags += reco_item.tag().feature(i).literal();
      if (i != reco_item.tag().feature_size() - 1) {
        out_tags += ",";
      }
    }
  }
  return out_tags;
}

void CorewordWorker::OuputItem(const reco::RecoItem& reco_item) {
  std::string out_category = "";
  if (reco_item.category_size() > 0) {
    out_category += reco_item.category(0);
  }
  if (reco_item.category_size() > 1) {
    out_category += ",";
    out_category += reco_item.category(1);
  }

  std::string out_tags = GetTagsStr(reco_item);

  VLOG(1) << "item_tag_info:" << reco_item.identity().item_id() << "\t"
    << (int)reco_item.identity().type() << "\t"
    << out_category << "\t" << reco_item.title() << "\t"
    << reco_item.original_url()  << "\t"
    << out_tags << std::endl;
}
}  // namespace reco
