#pragma once
#include <cstdatomic>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/module/cdoc_convertor/region/region_recognition.h"
#include "reco/bizc/proto/item.pb.h"

#include "base/file/file_path.h"
#include "base/thread/sync.h"
#include "base/thread/thread_pool.h"
#include "nlp/common/term_info.h"

#include "reco/module/cdoc_convertor/convertor/item_bow.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

namespace nlp {
namespace term {
class TermContainer;
}
namespace segment {
class Segmenter;
}
namespace postag {
class PosTagger;
}
namespace ner {
class Ner;
}
namespace plsa {
class PzdPredictor;
}
}  // namespace nlp
namespace queries {
class TermImp;
}

namespace thread {
class ThreadPool;
}

namespace reco {

namespace splice {
class RecoSplicer;
}

namespace common {
class RegionRecognition;
}
namespace bad_item {
class RubbishDetector;
}
class VideoRubbishDetector;
class RecoItem;
class RealtimeDetector;
class ItemClassifier;
class RecoPlsa;
class RuleTreeRealtimeDetector;
class HBaseGetItem;
class StockClassify;
class AutoClassify;
class TagMatch;
class SynonymTag;
class MediaUpdator;
class LDAUtil;
struct ExtractCfg {
  explicit ExtractCfg(bool df_val = true) {
    extract_tag = df_val;
    extract_keyword = df_val;
    extract_bow = df_val;
    extract_plsa = df_val;
    extract_category_plsa = df_val;
    extract_category = df_val;
    extract_rubbish = df_val;
    extract_lda = df_val;
  }

  explicit ExtractCfg(const reco::convertor::ExtractFeatureRequest* request) {
    extract_tag = request->return_tag();
    extract_keyword = request->return_keyword();
    extract_bow = request->return_bow();
    extract_plsa = request->return_plsa();
    extract_category_plsa = request->return_category_plsa();
    extract_category = request->return_category();
    extract_rubbish = request->return_rubbish();
    extract_lda = request->return_lda();
  }

  bool extract_tag;
  bool extract_keyword;
  bool extract_bow;
  bool extract_plsa;
  bool extract_category_plsa;
  bool extract_category;
  bool extract_rubbish;
  bool extract_lda;
};

class RawItemConvertor {
 public:
  explicit RawItemConvertor(const std::string& item_hbase_table, const reco::redis::RedisCli* redis_cli_);
  ~RawItemConvertor();

  // RecoItem 特征提取，供 item handler 使用
  // if manual_fields != NULL 表示这些字段是人工已经设置过了，机器需要沿用人工的结果
  // 这主要是用在一些字段之间互相依赖的场景，比如标签依赖于分类的结果，而人工已经干预了分类的结果，
  // 此时如果不遵照人工的结果来走，标签抽取就会得到错误分类下的标签
  // NOTE 现在只有在有互相依赖的情况下要强制用人工结果。
  // 其他独立的特征，即使机器抽取了，回传到上游也不会生效，所以可以继续让机器抽着
  bool UpdateRecoItem(RecoItem* reco_item,
                      const std::vector<std::string>* manual_fields = NULL,
                      const std::vector<RecoItem>* child_items = NULL);

  // 特征抽取的独立入口。
  // NOTE 需要
  bool ExtractItemFeatures(const ExtractCfg& Cfg,
                           const reco::ItemType& type,
                           const std::string& title,
                           const std::string& content,
                           const std::string& source,
                           const std::vector<std::string>& orig_categories,
                           std::vector<std::string>* tags,
                           std::vector<std::string>* keywords,
                           std::vector<std::string>* bows,
                           std::vector<std::string>* plsa,
                           std::vector<std::string>* categories);

 public:
  static const std::vector<std::string> kListeningFields;
  static const std::vector<std::string> kUpdateFields;

 private:
  std::string ExtractVideoSummary(RecoItem* reco_item);
  void ExtractItemFeatures(const ExtractCfg& Cfg, RecoItem* reco_item);
  std::string MergeImageDesc(const google::protobuf::RepeatedPtrField<reco::NewsImage>& image);

  void ExtractVideoTagFeature(const std::string& source,
                              const std::string& orig_source,
                              const std::string& category,
                              const std::string& title);

  void SetExpireTime(reco::RecoItem* reco_item);

  // 专门对股票类的设置超时时间
  // 1、尝试识别盘段，例如如果是早市（默认中国股市），这个reco_item顶多活到12:30(11:30结束，只能多活1小时)   // NOLINT
  // 2、如果是指数类或数值类，并且在交易时间内（默认中国股市），顶多活 1 小时
  // 3、如果是指数类或数值类，顶多活 2 小时
  void SetStockExpireTime(RecoItem* reco_item);

  void ExtractTopicFeature(const std::string& content,
                           const nlp::term::TermContainer& container,
                           RecoItem* item);

  void ExtractPlsaTopicFeature(const std::string& category,
                               const std::string& title,
                               const std::string& content,
                               RecoItem* item);
  void ExtractTagFeature(const std::string& content,
                         const std::string& title,
                         const nlp::term::TermContainer& container,
                         RecoItem *item);
  // LDA 主题特征, 会产生三个特征
  // 1、 title + LDA
  // 2、 content + LDA
  // 3、 content + SLDA
  void ExtractLDATopicFeature(const std::string& title,
                              const std::string& content,
                              RecoItem* item);
  void ExtractThemeLDATopicFeature(const std::string& title,
                                   const std::string& content,
                                   RecoItem* item);
  void ExtractSpiderTags(RecoItem* reco_item);
  void ExtractSummaryWords(RecoItem* reco_item,
      std::map<std::string, float>* summary_unseg_tag_weight_dict);

  void ExtractSemanticTag(const std::string& title_content, const std::string& title,
                          const std::string& content,
                          const nlp::term::TermContainer& container,
                          RecoItem* item);
  void ExtractSpecialTagFeature(RecoItem *item);
  //  主题标签抽取
  void ExtractThemeTagFeature(RecoItem *item);

  bool RemoveTagLabel(const std::string raw_tag_literal, std::string* tag_literal);

  double cosine_similarity(const TagVec& tag_vec_1, const TagVec& tag_vec_2);

  void ExtractThemeChildTagFeature(RecoItem *item,
                                   std::unordered_map<std::string, double>* child_tags_weight);

  void CalculateThemeTagWeight(RecoItem *item,
                               const std::unordered_map<std::string, double>& child_tags_weight,
                               const std::vector<std::string>& video_spider_tags,
                               std::unordered_map<std::string, double>* all_tags_similarity);

  void ExtractTitleTermDocFeature(const std::string& content,
                                  int title_len,
                                  const nlp::term::TermContainer& container,
                                  RecoItem* item);

  void ExtractBidwordTermDocFeature(RecoItem* item);

  void ExtractOtherTermDocFeature(RecoItem* item);

  // 提取地域字段, 提取成功，则将这些地名对应的 code 更新到 RecoItem 的 region 字段
  bool ExtractRegion(const std::string& content,
                     int title_len,
                     const nlp::term::TermContainer& container,
                     RecoItem* reco_item);

  // 设置地域限制，基于类别、标签、关键词，更新到 RecoItem 中 region_restrict_level 字段中
  bool SetRegionRestrict(const std::string& content,
                         int title_len,
                         RecoItem* reco_item);

  // 加载词表, 用于抽取 manual_lable
  bool GetDict();

  struct SortTagInfo {
    int index;  // 对应 tag_candidates_ 元素的下标，如果该值为负值，则表示元素无效需要删除
    int length;  // tag 的长度
    SortTagInfo(int i, int l) {
      index = i;
      length = l;
    }
  };

  // tag 相关信息
  struct ShowTagInfo {
    std::string tag;
    int index;
    double ctr;
  };

  // 用于调权
  struct MergeSortInfo {
    bool in_title;
    int raw_tf;  // 标题加权之前的 tf
    int pf;  // 段落频次, 一个段落出现多次算作一次
  };

  bool ExtractTags(RecoItem* reco_item,
                   std::string& str, std::string& nor_title,
                   std::string& nor_content, const nlp::term::TermContainer& container);

  void ClearTags();

  // 角标词典的加载与查找函数
  void FillingSubscript(const std::string &tag, RecoItem *item);

  // 去掉不在 tag 词表中的 tag
  void DeleteInvalidTags(RecoItem *item);
  // tag 归一化：济南 --> 济南市
  void NormalizeTags(RecoItem *item);
  // 删除标签候选中的子串，比如标签候选中同事有融资租赁和融资，则去掉融资
  void DeleteSubTags(std::vector<std::pair<std::string, float> > *key_terms);
  void DeleteSubSemanticTags(std::vector<std::string> *key_terms);
  // 同义词: 如果有同义词，则返回同义词；没有同义词，则返回空串
  // category: 如果有二级分类，则格式为"一级分类,二级分类"
  std::string GetSynonymWords(const std::string& word, const std::string &category,
                              const std::unordered_set<std::string>& context_data);
  int SearchCoreWord(const std::string &category1, const std::string &category2, const std::string &word);
  bool GetExtendTags(const std::string &category1, const std::string &category2, const std::string &word,
                     int *can_show, std::vector<std::string> *extend_tags);
  // 导出未经筛选的词表候选 tag ，满足对准确不高召回要求比较高的业务使用
  void ExportCandidateTags(RecoItem *item);

  // 选择最终在客户端展现的 tag
  void SelectFinalShowTagsNew(reco::RecoItem *reco_item);
  // 视频的 show_tag 由 reco_item->tag 字段生成，每次 reco_item->tag 字段更改，都要重新调用一下这个函数
  void GenVideoShowTag(reco::RecoItem* reco_item);

  // 将可展示的语义标签添加到展示标签中,需要和已选择的展示标签去重及去包含
  void SelectShowTagFromSemanticTag(reco::RecoItem *reco_item,
                                    std::vector<std::string> *show_tag_list);

  // 过滤无效 show tag
  void FilterInvalidShowTag(const std::vector<std::string> &show_tag_list,
                            reco::RecoItem *reco_item);

  bool MeetTagExtractCondition(const std::string &producer, const reco::ItemType &item_type,
                               const int &raw_item_tags_size);

  // category: "一级类别"，"一级类别,类别"
  // 返回值： 1 表示 命中词典，0 表示不命中词典，-1 表示歧义词
  int IsManualTag(const std::string &first_category,
                   const std::string &second_category,
                   const std::string &tag,
                   const std::unordered_set<std::string> &video_spider_tags);

  bool InVideoInvalidTag(const std::string& first_category, const std::string& tag);

  // 设置自媒体标签为最终标签
  void SetTagsUsingWemediaTags(const std::vector<std::string>& wemedia_tags, RecoItem* reco_item);

  // 计算专题 tag 时，需要 merge 多个子文章的 tag
  void MergeSubTags(const reco::FeatureVector &fv,
                    std::vector<std::pair<std::string, float> > *tags);
  void FillSpecialTag(std::vector<std::pair<std::string, float> > *tags, FeatureVector* fv);

  // 判断一个字段是否是人工设置过的字段
  bool IsManualField(const std::string &f);

  // 视频分类映射到文本分类，用于限制类别的标签检查
  bool CategoryMapping(const std::string &video_category1, const std::string &video_category2,
                       std::string *text_category1, std::string *text_category2);
  // 判断歧义词是否适合作为标签
  bool JudgeAmbTag(const std::set<std::string> &attributes, const std::string &tag);
  // 查找视频源的默认类别
  bool MatchVideoSourceCategory(RecoItem* reco_item);
  // 计算段落边界
  void CalcParagraphBoundary(RecoItem* reco_item);
  // 计算所有 term 的段落频次 pf , 即在一个段落中出现多次算作一次
  void CalcParagraphFreq(RecoItem* reco_item, const std::string& title);
  void CalcParagraphFreq(const std::string& tag,
                         const std::vector<std::pair<uint32, uint32> >& pos_dict,
                         std::set<int>* para_set);
  // 计算单个 term 的段落频次 pf
  int CalcParagraphFreq(const std::string& term);
  // 蹭热点意图分析
  bool IntentionAnalysis(const RecoItem& reco_item,
    const std::string& content,
    const std::string& title,
    const nlp::term::TermContainer& container);
  // 根据标签词频次调整意图分析结果, 标题中的标签重新加权
  void TitleReweight(const std::string& norm_title, bool* hot_spam);
  // 更新同义词的段落频次
  void UpdateSynonymPF(const std::string& tag, const std::string& norm_tag);
  // 蹭热点调权
  float AdjustWeight(std::vector<std::pair<std::string, float> > *key_terms);
  // 判断是否使用依存结果
  bool IsUseDepResult(const RecoItem& reco_item, const std::string& title);
  // 根据依存句法分析结果调整词频
  void AdjustDepTF(const RecoItem& reco_item);

  void GetNormPos(const int& doc_length);
  void GetNormPos(const std::string& word, const int& doc_length,
                  double* first_norm_pos, double* last_norm_pos);
  // 是否启用位置特征
  bool IsUsePosFilter(const std::string& category1);

  static bool TagWeightSorter(const InnerTagInfo& left, const InnerTagInfo& right);
  static bool TagCtrCmp(const ShowTagInfo& left, const ShowTagInfo& right);
  static bool TagIndexCmp(const ShowTagInfo& left, const ShowTagInfo& right);
  static bool TagLengthCmp(const SortTagInfo& left, const SortTagInfo& right);
  static bool PairValueCmp(const std::pair<std::string, float>& left,
                           const std::pair<std::string, float>& right);

 private:
  static const int64 kHumorChannelId = 1670553277;
  // show tag limit
  static const int kShowTagNumLimit = 4;
  static const int kMinTagFreq = 3;

  nlp::segment::Segmenter *segmenter_;
  nlp::postag::PosTagger* postagger_;
  nlp::ner::Ner* ner_;
  reco::common::RegionRecognition* region_recognition_;
  nlp::plsa::PzdPredictor* pzd_predictor_;
  queries::TermImp* imp_;
  reco::RecoPlsa* reco_plsa_predictor_;

  // realtime detector
  reco::RuleTreeRealtimeDetector *rules_tree_detector_;
  reco::HBaseGetItem* get_item_service_;

  // 核心词完整信息词典
  const std::unordered_map<std::string, CoreWordDetailInfo> *dyn_coreword_detail_dict_;

  // temporary container for tags
  std::vector<InnerTagInfo> tag_candidates_;

  // 视频的 tag 的特殊处理
  std::unordered_map<std::string, VideoTagAnnotator::VideoTag> video_tags_;

  // 标题匹配 tag
  TagMatch* tag_matcher_title_;
  // 特殊 tag : 有些类型 tag 不受预估个数限制，比如书名号实体，扩展 tag
  std::set<std::string> special_tags_;
  // 不展现的扩展核心词
  std::unordered_set<std::string> not_show_corewords_;
  // 语义扩展 tag 结果
  std::unordered_set<std::string> category_extend_results_;
  // 最终选择的 tag ，只填充 tag 字段的那一部分，不包括新增的语义 tag
  std::unordered_set<std::string> final_tags_;
  // 同义词
  reco::SynonymTag* synonym_searcher_;
  // 存储同义词的原始词，用于更新同义 tag. 比如，原来为: 阿里巴巴 --> 阿里，这里存储的是 阿里 --> 阿里巴巴
  std::unordered_map<std::string, std::string> synonym_source_words_;

  const std::unordered_map<std::string, std::vector<std::string> >* source_tag_dict_;

  // 卡片样式的 item type
  static const std::unordered_set<int> card_item_type_dict_;

  // 视频打标签器
  reco::VideoTagAnnotator *video_tag_annotator_;
  // lda topic
  LDAUtil* lda_util_;

  ItemBow* item_bow_;  // extract keywords

  MediaUpdator* media_updator_;

  ItemClassifier* item_classifier_;

  reco::bad_item::RubbishDetector* rubbish_detector_;
  reco::VideoRubbishDetector *video_rubbish_detector_;
  uint64 item_id_;
  // 视频 summary 字段
  std::string video_summary_;
  reco::ItemType item_type_;
  std::string producer_;
  const std::vector<std::string>* manual_fields_;
  // subject(主题）子文信息
  const std::vector<RecoItem>* child_items_;

  // 分类器提供的候选标签
  std::vector<std::string> classified_tags_;
  std::string classified_hot_spam_;
  // 本次的展示标签黑名单
  std::unordered_set<std::string> current_show_tag_black_;
  // 书名号词表
  std::set<std::string> book_names_;
  // 纯净视频源默认类别匹配标志
  bool video_source_category_match_;
  // 段落频次词典
  std::unordered_map<std::string, MergeSortInfo> term_pf_dict_;
  // 段落的开始和结束位置
  std::vector<std::pair<int, int> > paragraph_boundary_;
  // 主语频次词典
  std::pair<std::string, int> subject_freq_;
  // FRIEND_TEST(ConvertorTest, KWTest);
};
}  // namespace reco
