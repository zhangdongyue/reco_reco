#include "reco/module/cdoc_convertor/convertor/item_bow.h"

#include <string>
#include <vector>
#include <queue>
#include <unordered_map>
#include <cmath>
#include <algorithm>
#include <utility>

#include "base/hash_function/term.h"
#include "reco/bizc/reco_splice/reco_splice.h"
#include "reco/bizc/reco_ner/reco_ner.h"
#include "reco/module/cdoc_convertor/convertor/util/convertor_util.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "reco/bizc/proto/item.pb.h"

#include "nlp/common/term_container.h"
#include "nlp/common/rune_type.h"

DEFINE_int32(bow_term_num, 10, "");
DEFINE_double(default_news_idf, 11, "");

namespace reco {
ItemBow::ItemBow() {
  splicer_ = new reco::splice::RecoSplicer;
  reco_ner_ = new reco::ner::RecoNer;
}

ItemBow::~ItemBow() {
  delete splicer_;
  delete reco_ner_;
}

// term_type: 0 basic, 1: entity, 2: reco_ner, 3: phrase
double ItemBow::CalcTermImp(base::Slice term, uint64 term_sign, int tf,
                            int postag, int term_type) {
  auto news_idf_dict = GlobalDataIns::instance().GetNewIdfDict();
  float idf = FLAGS_default_news_idf;
  // TODO(xielang): change key as uint64
  auto idf_it = news_idf_dict->find(term.as_string());
  if (idf_it != news_idf_dict->end()) {
    idf = idf_it->second;
  }
  CHECK_GT(idf, 0);
  double imp = (tf + 1.0) * idf / (mix_term_num_ + 2);
  // LOG(ERROR) << "orig:" << imp << " " << idf << " " << tf << " " << term.as_string() << " " << term.size();

  if (term_type == 3) return imp;

  // boost
  if (term_type == 0 && postag_rule(postag)) {
    // 不知接过滤，防止 postag 不准的情况
    imp *= 0.6;
  } else if (term_type == 1 && entity_rule(postag)) {
    // 不直接过滤，entity type 识别可能错误
    imp *= 0.8;
  }

  auto it = boost_level_.find(term_sign);
  if (it == boost_level_.end()) {
    // do nothing
  } else if (it->second >= 2) {
    imp *= 2;
  } else if (it->second >= 1) {
    imp *= 1.5;
  }
  return imp;
}

bool ItemBow::ExtractKeywords(const std::string& content,
                              const std::string& title,
                              const nlp::term::TermContainer& container,
                              reco::RecoItem* item,
                              std::vector<InnerTagInfo>* tag_candidates) {
  term_position_dict_.clear();

  reco::ItemType item_type = item->identity().type();

  // step 1: stat tf for each term (mix)
  PreProcess(content, title, container);

  // step 2: generate keyword and tag candidates
  GenerateCandidates(title, content, container, item_type, tag_candidates);
  // extract keywords out
  std::vector<std::pair<std::string, double>> key_terms(heap_.size());
  auto it = key_terms.rbegin();
  double org_sum_weight = 0;
  while (!heap_.empty()) {
    auto& pr = heap_.top();
    *it++ = std::make_pair(pr.second, pr.first);
    org_sum_weight += pr.first;
    heap_.pop();
  }
  if (org_sum_weight < 1e-6 || key_terms.empty()) return false;

  // 过滤低权重的词
  double filter_wt_thres = 0.6 / key_terms.size();
  int st_filter_idx = (int)key_terms.size();

  double sum_weight = 0;
  for (int i = 0; i < (int)key_terms.size(); ++i) {
    auto& pr = key_terms[i];
    if (pr.second / org_sum_weight < filter_wt_thres) {
      st_filter_idx = i;
      break;
    }
    sum_weight += pr.second;
  }
  auto feature_vector = item->mutable_keyword();
  feature_vector->clear_feature();
  double norm2 = 0.0;
  // query: 猫眼电影,一周票房,淘票票,猫眼,猴姆
  if (item_type == reco::kThemeVideo) {
    if (item->has_query() && !item->query().empty()) {
      std::string spider_query = nlp::util::NormalizeLine(item->query());
      std::vector<std::string> query_vec;
      base::SplitString(spider_query, ",", &query_vec);
      for (int j = 0; j < (int)query_vec.size(); ++j) {
        base::TrimWhitespaces(&query_vec[j]);
        if (query_vec[j].empty()) continue;

        Feature current_fea;
        double weight = 1.0 / query_vec.size();
        current_fea.set_weight(weight);
        norm2 += weight * weight;
        current_fea.set_literal(query_vec[j]);
        feature_vector->add_feature()->CopyFrom(current_fea);
        VLOG(1) << "theme keyword: " << query_vec[j];
      }
    }
  } else {
    for (int j = 0; j < st_filter_idx; ++j) {
      auto& pr = key_terms[j];
      pr.second /= sum_weight;
      const std::string& term = pr.first;
      Feature current_fea;
      current_fea.set_weight(pr.second);
      norm2 += pr.second * pr.second;
      current_fea.set_literal(term);
      feature_vector->add_feature()->CopyFrom(current_fea);
      VLOG(1) << "keyword: " << term << ", weight:" << pr.second;
    }
  }
  feature_vector->set_norm(sqrt(norm2));
  return true;
}

void ItemBow::PreProcess(const std::string& content, const std::string& title,
                         const nlp::term::TermContainer& container) {
  clear();
  size_t title_len = title.length();
  // do splice
  std::unordered_map<std::string, int> bigram_phrases;
  std::unordered_map<std::string, int> trigram_phrases;

  if (!splicer_->SpliceT(content, title_len, container, &bigram_phrases, &trigram_phrases)) {
    LOG(WARNING) << "failed to extract splice";
    bigram_phrases.clear();
    trigram_phrases.clear();
  }
  // 获取 phrase 的出现位置，并更新到位置词典
  std::unordered_map<std::string, std::vector<std::pair<uint32, uint32> > >* phrase_position_dict =
      splicer_->GetTermPositionDict();
  for (auto it_phrase = phrase_position_dict->begin();
       it_phrase != phrase_position_dict->end(); ++it_phrase) {
    VLOG(2) << "phrase position ! phrase:" << it_phrase->first << ", count:" << it_phrase->second.size();
    for (auto it_phrase_pos = it_phrase->second.begin();
         it_phrase_pos != it_phrase->second.end(); ++it_phrase_pos) {
      UpdateTermPosition(it_phrase->first, it_phrase_pos->first, it_phrase_pos->second);
    }
  }

  auto black_term_dict = GlobalDataIns::instance().GetBlackTermDict();
  for (auto iter = bigram_phrases.begin(); iter != bigram_phrases.end(); ++iter) {
    uint64 sign = base::CalcTermSign(iter->first.c_str(), (int)iter->first.size());
    if (black_term_dict->find(sign) == black_term_dict->end()) {
      phrases_[iter->first] += iter->second;
    }
  }

  for (auto iter = trigram_phrases.begin(); iter != trigram_phrases.end(); ++iter) {
    uint64 sign = base::CalcTermSign(iter->first.c_str(), (int)iter->first.size());
    if (black_term_dict->find(sign) == black_term_dict->end()) {
      phrases_[iter->first] += iter->second;
    }
  }

  basic_term_sign_.resize(container.basic_term_num(), 0);

  for (int j = 0; j < container.basic_term_num(); ++j) {
    mix_term_num_++;
    const nlp::term::TermInfo& info = container.basic_term_info(j);
    VLOG(2) << "before_tf_basic: term:" << info.term(content).as_string();
    // TODO(xielang): nlp common 里面有构造 mix 的路基，这里这么玩浪费
    if (info.entity_index != -1) {
      mix_term_num_--;
      continue;  // 走专名粒度的统计
    }

    basic_term_sign_[j] = base::CalcTermSign(info.term(content).data(), info.term(content).size());
    if (info.end <= title_len) {
      // title term 提权
      if (nlp::rune::is_rune_type(info.rune_type, nlp::rune::kAlpha) && info.rune_len > 2) {
        // 标题中的英文词视为 专名
        boost_level_[basic_term_sign_[j]] = 2;
      } else {
        boost_level_[basic_term_sign_[j]] = 1;
      }
    }
    tf_[basic_term_sign_[j]] += 1;
    VLOG(1) << "stat_tf_basic: term:" << info.term(content).as_string() << ", current_tf:"
            << tf_[basic_term_sign_[j]];
  }

  entity_term_sign_.resize(container.entity_term_num(), 0);
  for (int j = 0; j < container.entity_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.entity_term_info(j);
    entity_term_sign_[j] = base::CalcTermSign(info.term(content).data(), info.term(content).size());
    VLOG(2) << "before_tf_ner: term:" << info.term(content).as_string();
    if (info.end <= title_len) {
      // title term 提权
      boost_level_[entity_term_sign_[j]] = 2;
    }
    tf_[entity_term_sign_[j]] += 1;
    mix_term_num_++;
    VLOG(1) << "stat_tf_ner: term:" << info.term(content).as_string() << ", current_tf:"
            << tf_[entity_term_sign_[j]];
  }

  // 提取 reco ner
  std::vector<base::Slice> reco_entities;
  std::vector<base::Slice> results;
  if (!reco_ner_->DetectEntity(content, container, "", &results, &reco_entities)) {
    LOG(WARNING) << "detect reco entity fail";
  }

  for (int j = 0; j < (int)reco_entities.size(); ++j) {
    uint64 term_sign = base::CalcTermSign(reco_entities[j].data(), reco_entities[j].size());
    // 与现有的专名 和 basic_term 去重
    if (reco_entity_dict_.find(term_sign) == reco_entity_dict_.end() &&
        tf_.find(term_sign) != tf_.end()) {
      continue;
    }
    reco_entity_dict_.insert(std::make_pair(term_sign, reco_entities[j]));
    if (title.find(reco_entities[j].data(), reco_entities[j].size()) != std::string::npos) {
      // reco entity in title
      boost_level_[term_sign] = 2;
    }
    tf_[term_sign] += 1;
    mix_term_num_++;
    VLOG(1) << "stat tf reco_ner: " << reco_entities[j].as_string() << ", current_tf:"
            << tf_[term_sign];
  }
}

// TODO(xielang): tag_candidates 的逻辑也可以剥离 ，这里把所 kw 的候选全部存下来即可
void ItemBow::GenerateCandidates(const std::string& title,
                                 const std::string& content,
                                 const nlp::term::TermContainer& container,
                                 const reco::ItemType &item_type,
                                 std::vector<InnerTagInfo>* tag_candidates) {
  auto black_term_dict = GlobalDataIns::instance().GetBlackTermDict();
  int kBowFeaLimitNum = std::min(FLAGS_bow_term_num, mix_term_num_ / 15 + 1);

  std::unordered_set<uint64> dedup_set;
  size_t title_len = title.size();
  for (int j = 0; j < container.basic_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.basic_term_info(j);
    // some filter rules
    if (info.entity_index != -1) continue;  // 走专名粒度的统计
    base::Slice base_slice = info.term(content);
    std::string cur_term = base_slice.as_string();
    std::string whole_term = "";
    if (info.rune_len == 1)  continue;

    // 记录出现的位置
    if (info.end > title_len) {
      UpdateTermPosition(cur_term, info.begin, info.end);
    }

    if (dedup_set.find(basic_term_sign_[j]) != dedup_set.end()) continue;
    // 这种逻辑为何不前移，擦
    if (black_term_dict->find(basic_term_sign_[j]) != black_term_dict->end()) continue;
    if (cur_term != "12306" && info.is_postag(nlp::term::kNumber) && cur_term.size() >= 5) continue;
    if (item_type != reco::kPureVideo && info.end > title_len && tf_[basic_term_sign_[j]] == 1
        && !info.is_postag(nlp::term::kPlace)) {
      continue;
    }
    // TODO(*) 如果是某个 entity 的一部份，是否过滤, 这里暂时不过滤
    // if (phrase_substrings.count(base_slice.as_string()) > 0) continue;
    // tf-idf
    double imp = CalcTermImp(base_slice, basic_term_sign_[j], tf_[basic_term_sign_[j]], info.enum_postag, 0);
    // add to heap
    heap_.push(std::make_pair(imp, cur_term));
    dedup_set.insert(basic_term_sign_[j]);
    if ((int)heap_.size() > kBowFeaLimitNum) heap_.pop();

    VLOG(1) << "basic: term:" << cur_term << ", j:" << j << ", pos_end:" << info.end << " " << imp;
    int is_pn = info.is_postag(nlp::term::kHumanName)?1:0;

    tag_candidates->push_back(InnerTagInfo(
            cur_term, tf_[basic_term_sign_[j]], imp, false, is_pn));
  }

  for (int j = 0; j < container.entity_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.entity_term_info(j);
    base::Slice entity_slice = info.term(content);
    std::string current_term = entity_slice.as_string();

    // 记录出现的位置
    if (info.end > title_len) {
      UpdateTermPosition(current_term, info.begin, info.end);
    }
    if (dedup_set.find(entity_term_sign_[j]) != dedup_set.end()) continue;
    if (info.rune_len == 1) continue;
    if (black_term_dict->find(entity_term_sign_[j]) != black_term_dict->end()) continue;
    if (info.is_postag(nlp::term::kNumber) && info.term(content).size() >= 5) continue;
    // if (entity_slice.as_string().find(".") != entity_slice.as_string().npos) continue;
    // if (entity_slice.as_string().find("!") != entity_slice.as_string().npos) continue;
    if (entity_slice.find("#") != base::Slice::npos || entity_slice.find("*") != base::Slice::npos) continue;
    // if (entity_slice.as_string().find("-") != entity_slice.as_string().npos) continue;
    if (item_type != reco::kPureVideo && info.end > title_len && tf_[entity_term_sign_[j]] == 1
        && !info.has_entity_type(nlp::term::kEntityPlace)) continue;
    // if (phrase_substrings.count(entity_slice.as_string()) > 0) continue;
    // tf-idf
    double imp = CalcTermImp(entity_slice, entity_term_sign_[j], tf_[entity_term_sign_[j]],
                             info.enum_entity, 1);

    // put to heap
    heap_.push(std::make_pair(imp, entity_slice.as_string()));
    dedup_set.insert(entity_term_sign_[j]);
    if ((int)heap_.size() > kBowFeaLimitNum) heap_.pop();

    int is_pn = 0;
    if (info.has_entity_type(nlp::term::kEntityHuman)) {
      is_pn = 1;
    }
    VLOG(1) << "ner: term:" << entity_slice.as_string() << ", j:" << j << ", pos_end:" << info.end
        << ", is_pn:" << is_pn << " " << imp;

    tag_candidates->push_back(InnerTagInfo(
            current_term, tf_[entity_term_sign_[j]], imp, false, is_pn));
  }

  for (auto iter = reco_entity_dict_.begin(); iter != reco_entity_dict_.end(); ++iter) {
    uint64 term_sign = iter->first;
    base::Slice &reco_entity = iter->second;
    if (dedup_set.find(term_sign) != dedup_set.end()) continue;
    int char_len;
    if (!base::GetUTF8CharNum(reco_entity, &char_len)) continue;
    if (char_len <= 1) continue;

    double imp = CalcTermImp(reco_entity, term_sign, tf_[term_sign], -1, 2);

    // put to heap
    heap_.push(std::make_pair(imp, reco_entity.as_string()));
    dedup_set.insert(term_sign);
    if ((int)heap_.size() > kBowFeaLimitNum) heap_.pop();

    VLOG(1) << "reco_ent: term:" << reco_entity.as_string();
    tag_candidates->push_back(InnerTagInfo(reco_entity.as_string(), tf_[term_sign], imp, false, 0));
  }

  for (auto it = phrases_.begin(); it != phrases_.end(); ++it) {
    const std::string& term = it->first;
    uint64 sign = base::CalcTermSign(term.c_str(), term.size());
    if (dedup_set.find(sign) != dedup_set.end()) continue;
    double imp = CalcTermImp(term, sign, it->second, -1, 3);

    heap_.push(std::make_pair(imp, term));
    if ((int)heap_.size() > kBowFeaLimitNum) heap_.pop();

    VLOG(1) << "phrases: term:" << term;
    tag_candidates->push_back(InnerTagInfo(term, it->second, imp, false, 0));
  }
}

void ItemBow::UpdateTermPosition(const std::string& term, uint32 begin, uint32 end) {
  auto it_term_pos = term_position_dict_.find(term);
  if (it_term_pos == term_position_dict_.end()) {
    std::vector<std::pair<uint32, uint32> > tmp_position;
    tmp_position.push_back(std::make_pair(begin, end));
    term_position_dict_.insert(std::make_pair(term, tmp_position));
  } else {
    it_term_pos->second.push_back(std::make_pair(begin, end));
  }
}

void ItemBow::AddSpecialTagCandidates(const std::string& content,
                                      const std::string& title,
                                      const nlp::term::TermContainer& container,
                                      const std::string& category,
                                      std::vector<InnerTagInfo>* tag_candidates) {
  auto title_synonym_dict = GlobalDataIns::instance().GetTitleSynDict();
  std::string level1 = category;
  size_t pos = category.find(",");
  if (pos != std::string::npos) level1 = category.substr(0, pos);

  // 字符个数为 1 时，对国家名字做简称映射，但要验证映射后的词是否合适
  for (int j = 0; j < container.basic_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.basic_term_info(j);
    if (info.end > title.length()) break;
    // some filter rules
    if (info.entity_index != -1) continue;  // 走专名粒度的统计
    base::Slice base_slice = info.term(content);
    std::string cur_term = base_slice.as_string();
    if (info.rune_len != 1 || (level1 != "国际" && level1 != "军事")) continue;
    // 字符个数为 1 时，对国家名字做简称映射，但要验证映射后的词是否合适
    auto it = title_synonym_dict->find(cur_term);
    if (it == title_synonym_dict->end()) continue;

    const std::string& whole_term = it->second;
    uint64 term_sign = base::CalcTermSign(whole_term.c_str(), whole_term.size());
    auto it_sign = tf_.find(term_sign);
    if (it_sign == tf_.end() || it_sign->second == 0) {
      continue;
    } else {
      VLOG(1) << "国际|军事标题同义词, category:" << level1 << ", simple_term:" << base_slice.as_string()
              << ", whole_term:" << whole_term;
    }
    int is_pn = 0;
    if (info.is_postag(nlp::term::kHumanName)) {
      is_pn = 1;
    }
    double imp = CalcTermImp(cur_term, basic_term_sign_[j], tf_[basic_term_sign_[j]], info.enum_postag, 0);
    tag_candidates->push_back(InnerTagInfo(
            cur_term, tf_[basic_term_sign_[j]], imp, false, is_pn));
  }
}
}
