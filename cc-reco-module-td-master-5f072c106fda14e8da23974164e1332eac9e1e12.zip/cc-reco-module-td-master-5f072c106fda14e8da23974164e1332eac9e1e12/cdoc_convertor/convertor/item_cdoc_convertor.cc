#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"

#include <cmath>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <iostream>
#include <sstream>
#include <set>

#include "reco/bizc/proto/item.pb.h"

#include "base/common/scoped_ptr.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/utf_char_iterator.h"
#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "extend/json/jansson/jansson.h"
#include "nlp/common/nlp_util.h"

#include "ads_index/api/cdoc_convertor.h"
#include "ads_index/api/cdoc_convertor.pb.h"
#include "ads_index/api/public.h"
#include "nlp/segment/segmenter.h"
#include "reco/bizc/proto/convert_info.pb.h"
#include "serving_base/utility/time_helper.h"
#include "reco/module/cdoc_convertor/convertor/util/convertor_util.h"
#include "reco/bizc/common/attr_key_define.h"
#include "reco/bizc/common/appname_define.h"
#include "reco/bizc/common/index_util.h"
#include "reco/base/common/uri_process.h"

DEFINE_bool(clear_content, true, "clear content");
DEFINE_bool(search_index, false, "if true, adjust some fields for search");

DEFINE_int32(youzhi_posterior_itemq_threshold, 30, "优质 itemq 阈值");

namespace reco {

  const char cmd_sep[] = "\x1E\n";
  const char kv_sep[] = "\x1F\n";
  const char multi_val_sep[] = "\x1D";
  const char term_attr_sep[] = "\x1C";
  const char section_sep[] = "\x1D";
  const char payload_kv_sep[] = "\x10";
  const char subdoc_sep[] = "\x03";

  const std::unordered_map<std::string, reco::ResolutionType> resolution_type_map = {
          {"low", reco::kLowResolution}, {"normal", reco::kNormalResolution},
          {"high", reco::kHighResolution}, {"super", reco::kSuperResolution},
          {"original", reco::kOriginalResolution}
  };

reco::ResolutionType StringToResolutionType(const std::string& resolution) {
  std::unordered_map<std::string, reco::ResolutionType>::const_iterator it
          = resolution_type_map.find(resolution);
  if (it != resolution_type_map.end()) {
    return it->second;
  }
  return reco::kUnknownResolution;
}

  ItemCDocConvertor::ItemCDocConvertor() {
    index_cdoc_convertor_ = new adsindexing::CDocConvertor();
    segmenter_ = new nlp::segment::Segmenter;
  }

  ItemCDocConvertor::~ItemCDocConvertor() {
    delete segmenter_;
    delete index_cdoc_convertor_;
  }

  bool ItemCDocConvertor::ConvertToHa3Doc(const RecoItem &item, std::string* ha3) {
    *ha3 = "";
    scoped_ptr<reco::convertor::ConvertInfo> convert_info(new reco::convertor::ConvertInfo());

    std::ostringstream oss;

    uint64 item_id = item.identity().item_id();
    if ( item_id == 0u ) {
      LOG(ERROR) << "zero item_id";
      return false;
    }

    std::string producer = item.identity().has_producer() ?
      item.identity().producer() : item.identity().app_token();

    oss << "CMD=add" << kv_sep;
    oss << "ITEM_ID=" << item_id << kv_sep;
    oss << "TITLE=" << item.normalized_title() << kv_sep;

    std::vector<std::string> segres;
    std::string norm4seg = nlp::util::NormalizeLine(item.normalized_title());
    if (norm4seg.length()>0 && segmenter_->SegmentS(norm4seg, &segres)) {
      std::string title_gram_str = base::JoinStrings(segres, "|");
      oss << "TITLE_TEXT=" << title_gram_str << kv_sep;
      oss << "TITLE_UNIGRAMS=" << title_gram_str << kv_sep;
    } else {
      oss << "TITLE_TEXT=" << kv_sep;
    }

    std::string bidword;
    std::string bidword_for_seg;
    bool munual_checked = IsTagManualChecked(item);
    for (int i = 0; item.has_tag() && i < item.tag().feature_size(); ++i) {
      std::string raw_tag = item.tag().feature(i).literal();
      std::string tag;
      if (!ExtractRealTag(munual_checked, raw_tag, &tag)) {
        continue;
      }
      if (!tag.empty()) {
        bidword.append(tag);
        // 空格会被索引过滤，改成分割符
        bidword.append("|");

        bidword_for_seg.append(tag);
        bidword_for_seg.append("");
      }
    }

    oss << "BID_WORD=" << bidword << kv_sep;

    norm4seg = nlp::util::NormalizeLine(bidword_for_seg);
    if (norm4seg.length()>0 && segmenter_->SegmentS(norm4seg, &segres)) {
      oss << "BID_WORD_TEXT=" << base::JoinStrings(segres, "|") << kv_sep;
    } else {
      oss << "BID_WORD_TEXT=" << kv_sep;
    }

    // source 放入 anchor 域
    std::string anchor;
    if (!item.source().empty()) {
      anchor.append(item.source());
    }
    if (!item.orig_source().empty()) {
      anchor.append(" ");
      anchor.append(item.orig_source());
    }

    oss << "ANCHOR=" << anchor << kv_sep;
    norm4seg = nlp::util::NormalizeLine(anchor);
    if (norm4seg.length()>0 && segmenter_->SegmentS(norm4seg, &segres)) {
      oss << "ANCHOR_TEXT=" << base::JoinStrings(segres, "|") << kv_sep;
    } else {
      oss << "ANCHOR_TEXT=" << kv_sep;
    }

    // category 放入 query 域
    std::string query;
    for (int i = 0; i < item.category_size(); ++i) {
      if (item.category(0) == "未分类") break;
      query.append(item.category(i));
      query.append(" ");
    }
    int char_num = 0;
    if (!base::GetUTF8CharNum(query, &char_num)) {
      LOG(ERROR) << "FATAL: none-utf8 char in category:" << query << " item: " << item.identity().item_id();
      return false;
    }

    oss << "QUERY=" << query << kv_sep;
    norm4seg = nlp::util::NormalizeLine(query);
    if (norm4seg.length()>0 && segmenter_->SegmentS(norm4seg, &segres)) {
      oss << "QUERY_TEXT=" << base::JoinStrings(segres, "|") << kv_sep;
    } else {
      oss << "QUERY_TEXT=" << kv_sep;
    }

    std::string tmpcontent;
    if (FLAGS_clear_content) { } else {
      tmpcontent = item.normalized_content();
    }
    oss << "CONTENT=" << tmpcontent << kv_sep;
    norm4seg = nlp::util::NormalizeLine(tmpcontent);
    if (norm4seg.length()>0 && segmenter_->SegmentS(norm4seg, &segres)) {
      oss << "CONTENT_TEXT=" << base::JoinStrings(segres, "|") << kv_sep;
    } else {
      oss << "CONTENT_TEXT=" << kv_sep;
    }


    uint32 doc_mask = 0;

    // importance
    if (item.has_popularity()) {
      oss << "POPULARITY=" << item.popularity() << kv_sep;
    }

    // 是否失效
    if (!item.is_valid()) {
      int kDocMaskInvalid = 0x01;
      doc_mask |= kDocMaskInvalid;
    }

    auto attr2 = convert_info->add_int_attr();
    uint64 ha3_time = base::GetTimestamp();

    // ha3 保留字段， 写死不能改
    attr2->set_key("ha_reserved_timestamp");
    attr2->set_value(ha3_time);

    attr2 = convert_info->add_int_attr();
    attr2->set_key(reco::common::attr_key::kHa3UpdateTime);
    attr2->set_value(ha3_time);

    std::string publish_time_str = item.publish_time().empty() ? item.create_time() : item.publish_time();
    double publish_time_d = 0.0;
    if (!publish_time_str.empty()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kPublishTimestamp);
      base::Time time;
      base::Time::FromStringInSeconds(item.publish_time().c_str(), &time);
      publish_time_d = time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
      attr->set_value(publish_time_d);
    }

    if (!item.create_time().empty()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kCrawlTimestamp);
      base::Time time;
      base::Time::FromStringInSeconds(item.create_time().c_str(), &time);
      attr->set_value(time.ToDoubleT() * base::Time::kMicrosecondsPerSecond);
    }

    if (!item.expire_time().empty()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kExpireTimestamp);
      base::Time time;
      base::Time::FromStringInSeconds(item.expire_time().c_str(), &time);
      attr->set_value(time.ToDoubleT() * base::Time::kMicrosecondsPerSecond);
      doc_mask |= reco::common::kDocMaskTimeWhiteList;
    }

    if (!item.region().empty()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kRegion);
      attr->set_value(item.region());
      doc_mask |= reco::common::kDocMaskRegionWhiteList;
    }

    if (!item.region_from_title().empty()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kRegionFromTitle);
      attr->set_value(item.region_from_title());
    }

    if (!item.region_restrict().empty()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kRegionRestrict);
      attr->set_value(item.region_restrict());
    }
    std::set<std::string> filtered_apps;
    if (!item.filtered_app_names().empty()) {
      std::vector<std::string> flds;
      base::SplitString(item.filtered_app_names(), "`", &flds);
      for (size_t i = 0; i < flds.size(); ++i) {
        filtered_apps.insert(flds[i]);
      }
    }
    if (item.appname_filters_size() > 0) {
      for (int i = 0; i < item.appname_filters_size(); ++i) {
        filtered_apps.insert(item.appname_filters(i));
      }
    }
    for (auto it = filtered_apps.begin(); it != filtered_apps.end(); ++it) {
      if (base::LowerCaseEquals(*it, "ucnews-iflow")) {
        doc_mask |= reco::common::kDocMaskAppToutiao;
      } else if (base::LowerCaseEquals(*it, "huawei-iflow")) {
        doc_mask |= reco::common::kDocMaskAppHuawei;
      } else if (base::LowerCaseEquals(*it, "samsung-iflow")) {
        doc_mask |= reco::common::kDocMaskAppSamsung;
      } else if (base::LowerCaseEquals(*it, "meizunews-iflow")) {
        doc_mask |= reco::common::kDocMaskAppMeizu;
      }
    }
    // 土豆渠道需要过滤 youku_video_id 为空的视频
    if (item.identity().type() == kPureVideo && (!item.has_video_storage_info() ||
      !item.video_storage_info().has_youku_video_id() ||
      item.video_storage_info().youku_video_id().empty())) {
      doc_mask |= reco::common::kDocMaskAppTuDouIflow;
      doc_mask |= reco::common::kDocMaskAppYoukuIflow;
    }

    if (item.has_video_storage_info() &&
        item.video_storage_info().has_youku_audit_status()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kYoukuAuditStatus);
      attr->set_value(item.video_storage_info().youku_audit_status());
    }

    // 优酷渠道过滤 二次审核状态不是 allowed 的视频
    // if (!item.has_video_storage_info() ||
    //     !item.video_storage_info().has_youku_audit_status() ||
    //     item.video_storage_info().youku_audit_status() != "allowed") {
    //   doc_mask |= reco::common::kDocMaskAppYoukuIflow;
    // }

    if (item.has_risk_info() && item.risk_info().has_orig_media_risk_type()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kOrigMediaRiskType);
      attr->set_value(item.risk_info().orig_media_risk_type());
    } else {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kOrigMediaRiskType);
      attr->set_value(-1);
    }

    {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kItemType);
      attr->set_value(item.identity().type());
    }

    if (item.identity().has_manual()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kManualNews);
      attr->set_value(item.identity().manual());
    }

    {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kOuterId);
      attr->set_value(item.identity().outer_id());
    }

    {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kAppToken);
      attr->set_value(producer);
    }

    {
      auto attr = convert_info->add_string_attr();
      std::string category;
      for (int i = 0; i < item.category_size(); ++i) {
        if (!category.empty()) {
          category += "\t";
        }
        category += item.category(i);
      }
      attr->set_key(reco::common::attr_key::kCategory);
      attr->set_value(category);
    }

    if (item.has_multi_category()) {
      auto attr = convert_info->add_string_attr();
      std::string buf;
      if (item.multi_category().SerializeToString(&buf)) {
        attr->set_key(reco::common::attr_key::kCategoryCandidates);
        attr->set_value(reco::common::EncodeUrlComponent(buf));
      } else {
        LOG(WARNING) << "serialize multi category failed, item id: " << item_id;
      }
    }

    {
      auto attr = convert_info->add_string_attr();
      std::string channel;
      std::unordered_set<int64> uniq_channels;
      for (int i = 0; i < item.channel_id_size(); ++i) {
        if (uniq_channels.find(item.channel_id(i)) != uniq_channels.end()) continue;
        if (!channel.empty()) {
          channel += "\t";
        }
        channel += base::Int64ToString(item.channel_id(i));
        uniq_channels.insert(item.channel_id(i));
      }
      attr->set_key(reco::common::attr_key::kChannel);
      attr->set_value(channel);
    }


    // 置顶相关
    if (item.priority_info_size() > 0) {
      auto attr = convert_info->add_string_attr();
      std::string priority;
      for (int i = 0; i < item.priority_info_size(); ++i) {
        if (i != 0) {
          priority += "\n";
        }
        const PriorityInfo& info = item.priority_info(i);
        priority += base::StringPrintf("%d\t%ld\t%s\t%s", info.priority(), info.channel_id(),
          info.start_time().c_str(), info.end_time().c_str());
      }
      attr->set_key(reco::common::attr_key::kPriority);
      attr->set_value(priority);
    }

    {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kSource);
      attr->set_value(item.source());
    }

    if (!item.orig_source().empty()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kOrigSource);
      attr->set_value(item.orig_source());
    }

    if (!item.source_media().empty()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kSourceMedia);
      attr->set_value(item.source_media());
    }

    if (!item.orig_source_media().empty()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kOrigSourceMedia);
      attr->set_value(item.orig_source_media());
    }

    // quality attr
    if (item.has_quality_attr()) {
      const reco::ItemQualityAttr& quality_attr = item.quality_attr();
      std::string dumped;
      if (quality_attr.SerializeToString(&dumped)) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kItemQualityAttr);
        attr->set_value(reco::common::EncodeUrlComponent(dumped));
      } else {
        LOG(WARNING) << "serialize quality attr failed, item id: " << item_id;
      }
      if (quality_attr.has_jingpin_score()) {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kJingpinScore);
        attr->set_value(quality_attr.jingpin_score());
      } else {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kJingpinScore);
        attr->set_value(-1);
      }
      if (quality_attr.has_is_yuanchuang() && quality_attr.is_yuanchuang()) {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kItemIsYuanchuang);
        attr->set_value(quality_attr.is_yuanchuang());
      }
      if (quality_attr.has_posterior_itemq()) {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kPosteriorItemQ);
        attr->set_value(quality_attr.posterior_itemq());
      } else {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kPosteriorItemQ);
        attr->set_value(-1);
      }

      // 优质倒排
      if (quality_attr.has_posterior_itemq()
        && quality_attr.posterior_itemq() >= FLAGS_youzhi_posterior_itemq_threshold) {
        auto term = convert_info->add_term_payload();
        term->set_literal(reco::common::GetYouzhiItemPayloadTerm());
        term->set_payload(0);
      }

      // 精品倒排
      if (quality_attr.has_manual_jingpin_level()
        && quality_attr.manual_jingpin_level() > 0) {
        auto term = convert_info->add_term_payload();
        term->set_literal(reco::common::GetJingpinItemPayloadTerm());
        term->set_payload(0);
        LOG(INFO) << "jingpin item id: " << item_id;
      }
    }

    // content attr
    if (item.has_content_attr()) {
      uint64 bits;
      reco::common::PackContentAttr(item.content_attr(), &bits);
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kContentAttr);
      attr->set_value(bits);

      if (bits > 0) {
        auto term = convert_info->add_term_payload();
        term->set_literal(reco::common::GetContentAttrPayloadTerm(bits));
        term->set_payload(0);
      }
    }


    // gaode poi
    if (item.has_gaode_poi()) {
      std::string dumped;
      if (item.gaode_poi().SerializeToString(&dumped)) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kGaoDePOI);
        attr->set_value(reco::common::EncodeUrlComponent(dumped));
      } else {
        LOG(WARNING) << "serialize gaode poi failed, item id: " << item_id;
      }
    }

    // time axis results
    if (item.has_time_axis_results()) {
      std::string serialized_str;
      if (item.time_axis_results().SerializeToString(&serialized_str)) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kTimeAxisResults);
        attr->set_value(reco::common::EncodeUrlComponent(serialized_str));
      } else {
        LOG(WARNING) << "serialize time axis failed, item id: " << item_id;
      }
    }

    // ucb 运营文章 投放设置直接整体序列化
    if (item.has_uc_browser_deliver_setting()) {
      std::string dumped;
      if (item.uc_browser_deliver_setting().SerializeToString(&dumped)) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kUcBrowserDeliverSetting);
        attr->set_value(reco::common::EncodeUrlComponent(dumped));
        LOG(INFO) << "build deliver setting for " << item_id << " with size " << dumped.size();
      } else {
        LOG(WARNING) << "serialize uc_browser_deliver_setting failed, item_id: " << item_id;
      }
    } else {
      // LOG(INFO) << item_id << " has no deliver setting";
    }

    // ucb 运营文章 投放样式
    if (item.has_uc_browser_display_setting()
        && item.uc_browser_display_setting().has_style_type()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kUcBrowserStyleType);
      attr->set_value(item.uc_browser_display_setting().style_type());

      if (item.uc_browser_display_setting().has_editor_name() &&
        !item.uc_browser_display_setting().editor_name().empty()) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kUCBEditorName);
        attr->set_value(item.uc_browser_display_setting().editor_name());
      }
    } else {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kUcBrowserStyleType);
      attr->set_value(-1);
    }

    // 图片数量写入索引
    if (item.image_size() > 0) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kImageCount);
      attr->set_value(item.image_size());
    }

    // 小说更新信息
    // 小说各字段信息封装成 JSON 存储在 RecoItem 的 content 字段， 需要解析出来建到 index 中
    if (item.identity().type() == reco::kNovel
      && (item.source() == "神马小说更新" || item.source() == "神马小说")) {
      // 解析 json
      VLOG(1) << "convert novel notice item: item_id=" << item_id;
      json_error_t json_error;
      json_t *json = json_loads(item.content().c_str(), &json_error);
      if (json != NULL) {
        {
          std::string novel_id;
          json_t *j_novel_id = json_object_get(json, "novelId");
          if (j_novel_id != NULL && j_novel_id->type == JSON_STRING) {
            novel_id = json_string_value(j_novel_id);
          }
          // 小说 id 正排
          auto attr = convert_info->add_string_attr();
          attr->set_key(reco::common::attr_key::kNovelId);
          attr->set_value(novel_id);
          // 小说 id 倒排
          auto term = convert_info->add_term_payload();
          term->set_literal(reco::common::GetNovelIdPayloadTerm(novel_id));
          term->set_payload(0);
          VLOG(1) << "novel_id=" << novel_id;
        }
        {
          int64 novel_update_time = 0;
          json_t *j_novel_update_time = json_object_get(json, "updateTime");
          if (j_novel_update_time != NULL && j_novel_update_time->type == JSON_STRING) {
            base::Time time;
            std::string time_str = json_string_value(j_novel_update_time);
            base::Time::FromStringInSeconds(time_str.c_str(), &time);
            novel_update_time = time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
          }
          // 小说更新时间正排
          auto attr = convert_info->add_int_attr();
          attr->set_key(reco::common::attr_key::kNovelUpdateTime);
          attr->set_value(novel_update_time);
          VLOG(1) << "novel_update_time=" << novel_update_time;
        }
        json_decref(json);
      } else {
        LOG(WARNING) << "Failed to parse novel notice json line: " << json_error.line;
      }
    }


    // 视频数量
    if (item.video_meta_settings_size() > 0) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kVideoCount);
      attr->set_value(item.video_meta_settings_size());
    }

    // 视频封面图清晰度
    if (item.video_meta_settings_size() > 0) {
      auto &first_video = item.video_meta_settings(0);
      if (first_video.has_poster_clarity()) {
        auto attr = convert_info->add_float_attr();
        attr->set_key(reco::common::attr_key::kVideoPosterClarity);
        attr->set_value(first_video.poster_clarity());
      }
    }

    // 视频封面图黑边比例
    if (item.video_meta_settings_size() > 0) {
      auto &first_video = item.video_meta_settings(0);
      if (first_video.has_image_meta() && first_video.image_meta().has_black_edge_ratio()) {
        auto attr = convert_info->add_float_attr();
        attr->set_key(reco::common::attr_key::kVideoBlackEdgeRatio);
        attr->set_value(first_video.image_meta().black_edge_ratio());
      }
    }

    // 视频长宽色
    if (item.video_meta_settings_size() > 0) {
      auto &first_video = item.video_meta_settings(0);
      if (first_video.has_image_meta()) {
        if (first_video.image_meta().has_width()) {
          auto attr = convert_info->add_int_attr();
          attr->set_key(reco::common::attr_key::kVideoWidth);
          attr->set_value(first_video.image_meta().width());
          VLOG(1) << "set video width ha3:" << first_video.image_meta().width();
        }
        if (first_video.image_meta().has_height()) {
          auto attr = convert_info->add_int_attr();
          attr->set_key(reco::common::attr_key::kVideoHeight);
          attr->set_value(first_video.image_meta().height());
          VLOG(1) << "set video height ha3:" << first_video.image_meta().height();
        }
        if (first_video.image_meta().has_colors()) {
          auto attr = convert_info->add_int_attr();
          attr->set_key(reco::common::attr_key::kVideoColors);
          attr->set_value(first_video.image_meta().colors());
          VLOG(1) << "set video colors ha3:" << first_video.image_meta().colors();
        }
      }
    }

    // 视频封面图问题
    if (item.video_meta_settings_size() > 0) {
      auto &first_video = item.video_meta_settings(0);
      if (first_video.has_poster_problem_info() && first_video.has_poster_problem_info()) {
        auto &problem_info = first_video.poster_problem_info();
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kVideoPosterProblemInfo);
        std::vector<std::string> problems;
        if (problem_info.has_is_black_edge() && problem_info.is_black_edge()) {
          problems.push_back("is_black_edge");
        }
        if (problem_info.has_is_twisty() && problem_info.is_twisty()) {
          problems.push_back("is_twisty");
        }
        if (problem_info.has_is_dim() && problem_info.is_dim()) {
          problems.push_back("is_dim");
        }
        if (problem_info.has_contain_watermark() && problem_info.contain_watermark()) {
          problems.push_back("contain_watermark");
        }
        attr->set_value(base::JoinStrings(problems, ","));
        VLOG(1) << item.identity().item_id() << " " << base::JoinStrings(problems, ",");
      }
    }

    // 视频总播放时长
    if (item.video_meta_settings_size() > 0) {
      int32 play_len = 0;
      for (int k = 0; k < item.video_meta_settings_size(); ++k) {
        play_len += item.video_meta_settings(k).play_length();
      }
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kVideoLength);
      attr->set_value(play_len);
    }

    // 视频低俗级别
    if (item.identity().type() == kPureVideo &&
      item.has_video_attr() &&
      item.video_attr().has_vulgarlevel()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kVideoVulgarLevel);
      attr->set_value((int)item.video_attr().vulgarlevel());
    }

    // 视频低质级别
    if (item.identity().type() == kPureVideo &&
      item.has_video_attr() &&
      item.video_attr().has_quality_level()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kVideoQualityLevel);
      attr->set_value((int)item.video_attr().quality_level());
    }

    // title 长度
    if (item.has_normalized_title()) {
      int title_char_num;
      if (base::GetUTF8CharNum(item.normalized_title(), &title_char_num)) {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kTitleLength);
        attr->set_value(title_char_num);
      }
    }

    // 是否经过审核处理
    if (item.has_has_reviewed() && item.has_reviewed() == true) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kItemHasReviewed);
      attr->set_value(item.has_reviewed());
    }

    // 是否有自有视频存储地址
    if (item.has_video_storage_info() &&
      item.video_storage_info().has_normal() &&
      !item.video_storage_info().normal().empty()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kHasVideoStorageInfo);
      attr->set_value(true);
    }

    // 是否有视频自存储状态
    if (item.has_video_storage_info() &&
      item.video_storage_info().has_status()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kVideoStorageInfoStatus);
      attr->set_value(item.video_storage_info().status());
    }

    // 视频的播放控制设置
    if (item.has_video_play_control()) {
      std::string dumped;
      if (item.video_play_control().SerializeToString(&dumped)) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kVideoPlayControl);
        attr->set_value(reco::common::EncodeUrlComponent(dumped));
        VLOG(1) << "video_play_control dump:" << dumped;
      } else {
        LOG(WARNING) << "serialize video play control failed, item id: " << item_id;
      }
    }


    // 优酷的视频 ID
    if (item.has_video_storage_info() &&
      item.video_storage_info().has_youku_video_id() &&
      !item.video_storage_info().youku_video_id().empty()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kYoukuVideoId);
      attr->set_value(item.video_storage_info().youku_video_id());
    }

    if (item.has_video_meta_ext() && item.video_meta_ext().has_show_id()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kYoukuShowID);
      attr->set_value(item.video_meta_ext().show_id());
      VLOG(1) << "youku show id success" << item_id << " " << item.video_meta_ext().show_id();
    }

    // 角标
    if (item.has_subscripts()) {
      std::string serialized;
      if (item.subscripts().SerializeToString(&serialized)) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kItemSubscripts);
        attr->set_value(reco::common::EncodeUrlComponent(serialized));
      } else {
        LOG(WARNING) << "serialize subscript, item_id: " << item.identity().item_id();
      }
    }

    // add attr format
    reco::common::PackFeatureVectorHa3(item.keyword(), reco::common::kKeyword, convert_info.get());
    reco::common::PackFeatureVectorHa3(item.topic(), reco::common::kTopic, convert_info.get());
    if (item.has_plsa_topic()) {
      reco::common::PackFeatureVectorHa3(item.plsa_topic(), reco::common::kPlsaTopic, convert_info.get());
    }
    reco::common::PackFeatureVectorHa3(item.wordvec(), reco::common::kWordvec, convert_info.get());
    reco::common::PackFeatureVectorHa3(item.tag(), reco::common::kTag, convert_info.get());
    if (item.has_title_lda()) {
      // lda topic 打太多需要截断
      reco::FeatureVector title_lda_feavec;
      for (int idx = 0; idx < 10 && idx < item.title_lda().feature_size(); ++idx) {
        if (item.title_lda().feature(idx).weight() < 0.05) break;
        title_lda_feavec.add_feature()->CopyFrom(item.title_lda().feature(idx));
      }
      VLOG(1) << "lda topic size: " << item.title_lda().feature_size()
              << "," << title_lda_feavec.feature_size();
      reco::common::PackFeatureVectorHa3(title_lda_feavec, reco::common::kTitleLdaTopic, convert_info.get());
    }
    // semantic_tag: 正排索引
    if (item.has_semantic_tag()) {
      reco::common::PackFeatureVectorHa3(item.semantic_tag(), reco::common::kSemanticTag, convert_info.get());
    }




    // show_tag: 正排
    if (item.show_tag_size() > 0) {
      std::string total_show_tag = "";
      for (int i = 0; i < item.show_tag_size(); ++i) {
        if (i != 0) {
          total_show_tag.append("|");
        }
        std::string show_tag_norm = nlp::util::NormalizeLine(item.show_tag(i));
        total_show_tag.append(show_tag_norm);
      }
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kItemShowTag);
      attr->set_value(total_show_tag);
    }

    // event_tag: 正排
    if (item.event_tag_info_size() > 0) {
      std::string total_event_tag = "";
      std::string total_info = "";
      for (int i = 0; i < item.event_tag_info_size(); ++i) {
        if (i != 0) {
          total_event_tag.append("|");
        }
        std::string event_tag_norm = nlp::util::NormalizeLine(item.event_tag_info(i).event_tag_name());
        total_event_tag.append(event_tag_norm);

        std::string serialized_str;
        if (item.event_tag_info(i).SerializeToString(&serialized_str)) {
          if (i != 0) {
            total_info.append("|");
          }
          total_info.append(reco::common::EncodeUrlComponent(serialized_str));
        } else {
          LOG(WARNING) << "serialize event tag failed, item id: " << item_id;
        }
      }
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kItemEventTag);
      attr->set_value(total_event_tag);
      VLOG(1) << "event_tag forward index ! item_id:" << item.identity().item_id();

      auto attr_info = convert_info->add_string_attr();
      attr_info->set_key(reco::common::attr_key::kItemEventTagInfo);
      attr_info->set_value(total_info);
    }

    // 建立特殊 term
    // APP TOKEN
    auto term = convert_info->add_term_payload();
    term->set_literal(reco::common::GetAppTokenPayloadTerm(producer));
    term->set_payload(0);
    // item type
    term = convert_info->add_term_payload();
    term->set_literal(reco::common::GetItemTypePayloadTerm(item.identity().type()));
    term->set_payload(0);
    // category
    for (int i = 0; i < item.category_size(); ++i) {
      term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetCategoryPayloadTerm(item.category(i), i));
      term->set_payload(0);
    }

    // multi category
    for (int i = 0; i < item.multi_category().category_candidates_size(); ++i) {
      const reco::ItemCategory category = item.multi_category().category_candidates(i);
      term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetCategoryCandidatesPayloadTerm(category.level1(), 0));
      term->set_payload(0);
      for (int j = 0; j < category.level2_size(); ++j) {
        term = convert_info->add_term_payload();
        term->set_literal(reco::common::GetCategoryCandidatesPayloadTerm(category.level2(j), 1));
        term->set_payload(0);
      }
    }

    if (!item.query().empty()) {
      term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetSpiderQueryPayloadTerm(nlp::util::NormalizeLine(item.query())));
      term->set_payload(0);
    }

    // group info attr
    if (item.has_item_group_info()) {
      std::string dumped;
      if (item.item_group_info().SerializeToString(&dumped)) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kGroupInfo);
        attr->set_value(reco::common::EncodeUrlComponent(dumped));
      }

      if (item.item_group_info().has_group_id()) {
        auto term = convert_info->add_term_payload();
        const std::string& payload_key
            = reco::common::GetPayloadUint64("GROUP", item.item_group_info().group_id());
        term->set_literal(payload_key);
        term->set_payload(0);
      }
    }

    // wemida attr
    if (!item.show_source().empty()
        && base::StartsWithCaseSensitive(item.source(), reco::common::kWeMediaSourcePrefix)) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kWeMediaPerson);
      attr->set_value(item.show_source());

      auto term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetWeMediaPayloadTerm());
      term->set_payload(0);
    }

    // preview / summary
    if (!item.summary().empty()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kRawSummary);
      attr->set_value(item.summary());
    }

    if (item.identity().type() == reco::kSpecial
        || item.identity().type() == reco::kWeMediaCard) {
      if (producer == reco::common::kUCBProducer) {
        std::vector<std::string> contain_ids;
        GetUCBSpecialContentIds(item, &contain_ids);
        if (!contain_ids.empty()) {
          std::string str_id_list = base::JoinStrings(contain_ids, ",");
          auto attr = convert_info->add_string_attr();
          attr->set_key(reco::common::attr_key::kSpecialContainIdList);
          attr->set_value(str_id_list);
          auto attr2 = convert_info->add_string_attr();
          attr2->set_key(reco::common::attr_key::kSpecialPreviewIdList);
          attr2->set_value(str_id_list);
        }
      } else if (producer == reco::common::kZZDProducer || producer == reco::common::kZZDOpProducer) {
        // 专题内容包含的文章
        std::vector<std::string> contain_ids;
        GetZZDSpecialContentIds(item, &contain_ids);
        if (!contain_ids.empty()) {
          auto attr = convert_info->add_string_attr();
          attr->set_key(reco::common::attr_key::kSpecialContainIdList);
          attr->set_value(base::JoinStrings(contain_ids, ","));
        }
        // 专题 preview 的文章
        std::vector<std::string> preview_ids;
        GetZZDSpecialPreviewIds(item, &preview_ids);
        if (preview_ids.empty() && !contain_ids.empty()) {
          preview_ids.push_back(contain_ids[0]);
        }
        if (!preview_ids.empty()) {
          auto attr = convert_info->add_string_attr();
          attr->set_key(reco::common::attr_key::kSpecialPreviewIdList);
          attr->set_value(base::JoinStrings(preview_ids, ","));
        }
      }
    } else if (item.identity().type() == reco::kThemeVideo) {
      reco::SubjectSubItems subject_sub_items;
      GetZZDSubjectSubItems(item, &subject_sub_items);
      std::string dumped;
      if (subject_sub_items.SerializeToString(&dumped)) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kSubjectSubItems);
        attr->set_value(dumped);
      } else {
        LOG(WARNING) << "serialize subject_sub_items failed, item_id: " << item_id;
      }
    }

    // channel
    for (int i = 0; i < item.channel_id_size(); ++i) {
      term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetChannelPayloadTerm(item.channel_id(i)));
      term->set_payload(0);
    }
    // source
    term = convert_info->add_term_payload();
    term->set_literal(reco::common::GetSourcePayloadTerm(item.source()));
    term->set_payload(0);

    if (!item.orig_source().empty()) {
      term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetSourcePayloadTerm(item.orig_source()));
      term->set_payload(0);
    }

    // keyword
    for (int i = 0; i < item.keyword().feature_size(); ++i) {
      auto term = convert_info->add_term_payload();
      auto& fea = item.keyword().feature(i);
      term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kKeyword));
      term->set_payload(fea.weight() * 100);
    }

    // topic
    for (int i = 0; i < item.topic().feature_size(); ++i) {
      auto term = convert_info->add_term_payload();
      auto& fea = item.topic().feature(i);
      term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kTopic));
      term->set_payload(fea.weight() * 100);
    }

    // new plsa topic
    if (item.has_plsa_topic()) {
      for (int i = 0; i < item.plsa_topic().feature_size(); ++i) {
        auto term = convert_info->add_term_payload();
        auto& fea = item.plsa_topic().feature(i);
        term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kPlsaTopic));
        term->set_payload(fea.weight() * 100);
      }
    }

    // title lda topic
    if (item.has_title_lda()) {
      for (int i = 0; i < 5 && i < item.title_lda().feature_size(); ++i) {
        if (item.title_lda().feature(i).weight() < 0.1) break;
        auto term = convert_info->add_term_payload();
        auto& fea = item.title_lda().feature(i);
        term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kTitleLdaTopic));
        term->set_payload(fea.weight() * 100);
      }
    }

    // wordvec
    for (int i = 0; i < item.wordvec().feature_size(); ++i) {
      auto term = convert_info->add_term_payload();
      auto& fea = item.wordvec().feature(i);
      term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kWordvec));
      term->set_payload(fea.weight() * 100);
    }

    bool has_youku_show_id = false;
    if (item.has_video_meta_ext() && item.video_meta_ext().has_show_id()) {
      has_youku_show_id = true;
    }

    // show tag
    if (!has_youku_show_id) {  // 优酷追剧不建 tag 倒排
      for (int i = 0; i < item.show_tag_size(); ++i) {
        auto term = convert_info->add_term_payload();
        // tag show_tag 做了规范化，在倒排索引处需要 normalize
        std::string show_tag_norm = nlp::util::NormalizeLine(item.show_tag(i));
        term->set_literal(reco::common::GetShowTagPayloadTerm(show_tag_norm));
        term->set_payload(0);
      }

      // tag
      // bool munual_checked = IsTagManualChecked(item);
      for (int i = 0; i < item.tag().feature_size(); ++i) {
        auto& fea = item.tag().feature(i);
        std::string raw_tag = fea.literal();
        std::string real_tag;
        if (!ExtractRealTag(munual_checked, raw_tag, &real_tag)) {
          continue;
        }
        auto term = convert_info->add_term_payload();
        // tag show_tag 做了规范化，在倒排索引处需要 normalize
        std::string real_tag_norm = nlp::util::NormalizeLine(real_tag);
        term->set_literal(reco::common::GetFeaturePayloadTerm("label:" + real_tag_norm, reco::common::kTag));
        term->set_payload(fea.weight() * 100);
      }

      for (int i = 0; i < item.synonymous_tags_size(); ++i) {
        if (item.synonymous_tags(i).empty()) {
          continue;
        }
        const std::string& raw_tag = item.synonymous_tags(i);
        std::string real_tag;
        if (!ExtractRealTag(false, raw_tag, &real_tag)) {
          continue;
        }
        auto term = convert_info->add_term_payload();
        term->set_literal(reco::common::GetFeaturePayloadTerm("label:" + real_tag, reco::common::kTag));
        term->set_payload(10);
      }

      // semantic_tag: 倒排索引
      if (item.has_semantic_tag()) {
        for (int i = 0; i < item.semantic_tag().feature_size(); ++i) {
          auto& fea = item.semantic_tag().feature(i);

          auto term = convert_info->add_term_payload();
          term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kSemanticTag));
          term->set_payload(fea.weight() * 100);

          // 语义标签索引也建到实体标签的倒排
          // 第一，有些标签既可以作为语义标签，又可以作为实体标签，比如 反腐倡廉
          // 第二，方便检索, 使用 GetDocsByTag 就能检索到某个标签的所有文档
          const std::string& raw_tag = fea.literal();
          std::string real_tag;
          if (!ExtractRealTag(false, raw_tag, &real_tag)) {
            continue;
          }
          auto term_tag = convert_info->add_term_payload();
          term_tag->set_literal(reco::common::GetFeaturePayloadTerm("label:" + real_tag, reco::common::kTag));
          term_tag->set_payload(10);
          VLOG(1) << "semantic_tag inverted index ! item_id:" << item.identity().item_id();
        }
      }

      // event_tag: 倒排
      for (int i = 0; i < item.event_tag_info_size(); ++i) {
        auto term = convert_info->add_term_payload();
        std::string event_tag_norm = nlp::util::NormalizeLine(item.event_tag_info(i).event_tag_name());
        term->set_literal(reco::common::GetEventTagPayloadTerm(event_tag_norm));
        term->set_payload(0);
        VLOG(1) << "event_tag inverted index ! item_id:" << item.identity().item_id();
      }
    }

    // item type

    // add sim feature as term doc feature
    for (int i = 0; i < item.sim_feature_size(); ++i) {
      reco::convertor::TermDocFeature* term_doc_feature = convert_info->add_term_feature();
      term_doc_feature->set_literal(item.sim_feature(i).literal());
      term_doc_feature->set_feature(item.sim_feature(i).feature());
    }
    convert_info->set_term_feature_version(0);
    convert_info->set_term_feature_bytes(reco::sim_item::SimTermInfo::kTermInfoBytes);

    // parse simhash
    if (item.has_simhash()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kSimHash);
      attr->set_value(base::Int64ToString(item.simhash()));
    }

    // 正文长度
    char_num = 0;
    if (base::GetUTF8CharNum(item.normalized_content(), &char_num)) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kContentLength);
      attr->set_value(char_num);
    }

    // paragraph hash
    if (item.paragraph_simhash_size() > 0) {
      // 段落数量
      auto attr_int = convert_info->add_int_attr();
      attr_int->set_key(reco::common::attr_key::kParagraphNum);
      attr_int->set_value(item.paragraph_simhash_size());

      // 段落 hash
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kParagraphHash);
      std::ostringstream oss;
      for (int i = 0; i < item.paragraph_simhash_size(); ++i) {
        oss << item.paragraph_simhash(i);
        if (i != item.paragraph_simhash_size() - 1) {
          oss << ",";
        }
      }
      attr->set_value(oss.str());
    }

    // image hash
    if (item.image_size() > 0) {
      std::string value;
      value.reserve(64* item.image_size());
      for (int i = 0; i < item.image_size(); ++i) {
        const NewsImage& img = item.image(i);
        if (img.is_qrcode()) {
          continue;
        }
        if (!value.empty()) value.push_back(',');
        value +=  base::Int64ToString(img.simhash());

        auto term = convert_info->add_term_payload();
        term->set_literal(reco::common::GetPicturePayloadTerm(img.simhash()));
        term->set_payload(0);
      }

      if (!value.empty()) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kImageHash);
        attr->set_value(value);
      }
      // (NOTE): add image has as payload term for image search
    }

    if (item.has_region()) {
      std::vector<std::string> region_ids;
      base::SplitString(item.region(), ";", &region_ids);
      for (int i = 0; i < (int)region_ids.size(); ++i) {
        if (region_ids[i].empty()) continue;
        auto term = convert_info->add_term_payload();
        term->set_literal(reco::common::GetRegionIDPayloadTerm(region_ids[i]));
        term->set_payload(0);
      }
    }

    // set publish time
    if (!item.publish_time().empty()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kPublishTimeInSeconds);
      base::Time time;
      base::Time::FromStringInSeconds(item.publish_time().c_str(), &time);
      attr->set_value(time.ToDoubleT());
    }

    // set local breaking
    if (item.has_local_breaking()) {
      std::string breaking_str;
      if (item.local_breaking().SerializeToString(&breaking_str)) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kLocalBreaking);
        attr->set_value(reco::common::EncodeUrlComponent(breaking_str));
      } else {
        LOG(WARNING) << "serialize local breaking failed, item id: " << item_id;
      }
    }

    if (item.has_offline_filter_rule()) {
      if (item.offline_filter_rule().has_first_nscreen_filter()) {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kFirstNScreenFilter);
        attr->set_value(item.offline_filter_rule().first_nscreen_filter());
      }

      if (!item.offline_filter_rule().has_is_filter()) {
        LOG(ERROR) << "item miss offline_filter_rule.is_filter, item_id: " << item.identity().item_id();
      } else if (item.offline_filter_rule().is_filter()) {
        doc_mask |= reco::common::kDocFilterServer;
      } else {
        doc_mask &= ~reco::common::kDocFilterServer;
      }

      if (item.offline_filter_rule().has_app_token_rule_bits()) {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kAppTokenBits);
        attr->set_value(item.offline_filter_rule().app_token_rule_bits().app_token_bits());

        if (item.offline_filter_rule().app_token_rule_bits().has_rule_bits()) {
          auto attr = convert_info->add_string_attr();
          attr->set_key(reco::common::attr_key::kAppTokenRuleBits);
          attr->set_value(reco::common::EncodeUrlComponent(
                            item.offline_filter_rule().app_token_rule_bits().rule_bits()));
        }
      }

      int64 platforms = 0;
      for (int i = 0; i < item.offline_filter_rule().real_publish_platform_size(); ++i) {
        platforms |= 0x01 << item.offline_filter_rule().real_publish_platform(i);
      }
      if (platforms > 0) {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kSourcePublishPlatform);
        attr->set_value(platforms);
      }
      LOG(INFO) << "offline filter item_id: " << item_id;
    }

    if (item.has_video_storage_info() && item.video_storage_info().has_resolution()
        && !item.video_storage_info().resolution().empty()) {
      reco::ResolutionType type = StringToResolutionType(item.video_storage_info().resolution());
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kVideoResolution);
      attr->set_value(type);
    }

    // doc mask
    auto doc_mask_attr = convert_info->add_int_attr();
    doc_mask_attr->set_key("DocMask");
    doc_mask_attr->set_value(doc_mask);

    int item_num = 0;

    item_num = convert_info->string_attr_size();
    for (int i = 0;i < item_num;i++) {
      oss<< convert_info->string_attr(i).key() << "=" << convert_info->string_attr(i).value() << kv_sep;
    }

    item_num = convert_info->int_attr_size();
    for (int i = 0;i < item_num;i++) {
      oss<< convert_info->int_attr(i).key() << "=" << convert_info->int_attr(i).value() << kv_sep;
    }

    item_num = convert_info->float_attr_size();
    for (int i = 0;i < item_num;i++) {
      oss<< convert_info->float_attr(i).key() << "=" << convert_info->float_attr(i).value() << kv_sep;
    }


    // sim feature
    oss << "TERM_FEATURE_VERSION=" << convert_info->term_feature_version() << kv_sep;

    oss << "TERM_FEATURE_BYTES=" << convert_info->term_feature_bytes() << kv_sep;

    oss << "SIM_FEATURE=";
    for (int i = 0;i < convert_info->term_feature_size();i++) {
      reco::convertor::TermDocFeature& tt =
        const_cast<reco::convertor::TermDocFeature&>(convert_info->term_feature(i));
      oss << tt.literal() << "^";
      const uint8* pc = reinterpret_cast<const uint8*>((tt.mutable_feature())->c_str());
      const int sim_info_len = 9;
      for (int j = 0; j < sim_info_len; j++) {
        unsigned int val = *(pc+j);
        oss<< val;
        if (j!= (sim_info_len-1)) {
          oss << ",";
        }
      }

      if (i!= (convert_info->term_feature_size()-1)) {
        oss << multi_val_sep;
      }
    }
    oss << kv_sep;

    auto tterm = convert_info->add_term_payload();
    tterm->set_literal("ALL_ITEM");
    tterm->set_payload(0);
    // LOG(INFO) << "ALL_ITEM\t"<< item_id;

    oss << "TERM_SPECIAL=";
    for (int i = 0;i < convert_info->term_payload_size();i++) {
      reco::convertor::CustomerTermPayload& tt =
        const_cast<reco::convertor::CustomerTermPayload&>(convert_info->term_payload(i));
      oss << tt.literal();

      if (i!= (convert_info->term_payload_size()-1)) {
        oss << '|';
      }
    }
    oss << kv_sep;

    oss << "TERM_PAYLOAD=";

    for (int i = 0;i < convert_info->term_payload_size();i++) {
      reco::convertor::CustomerTermPayload& tt =
        const_cast<reco::convertor::CustomerTermPayload&>(convert_info->term_payload(i));
      oss << tt.literal() << term_attr_sep << "weight=" << tt.payload();

      if (i != (convert_info->term_payload_size()-1)) {
        oss << multi_val_sep;
      }
    }
    oss << kv_sep;

    oss << cmd_sep;
    *ha3 = oss.str();

    return true;
  }

bool ItemCDocConvertor::ConvertToCDoc(const RecoItem &item, adsindexing::IndexDocInfo *cdoc) {
  scoped_ptr<adsindexing::ConvertInfo> convert_info(new adsindexing::ConvertInfo());
  uint64 item_id = item.identity().item_id();
  CHECK_NE(item_id, 0u);

  std::string producer = item.identity().has_producer() ?
      item.identity().producer() : item.identity().app_token();

  // 标题和描述切词建索引
  convert_info->add_title_area(item.normalized_title());
  std::string bidword;
  // keyword 字段不放入 bid word, 会引起较多 badcase
  // if (!FLAGS_search_index) {
  //   // search 不建立 keyword 的正排
  //   for (int i = 0; item.has_keyword() && i < item.keyword().feature_size(); ++i) {
  //     bidword.append(item.keyword().feature(i).literal());
  //     // 空格会被索引过滤，改成分割符
  //     bidword.append(" | ");
  //   }
  // }
  // tag 字段放入 bid word
  bool munual_checked = IsTagManualChecked(item);
  for (int i = 0; item.has_tag() && i < item.tag().feature_size(); ++i) {
    std::string raw_tag = item.tag().feature(i).literal();
    std::string tag;
    if (!ExtractRealTag(munual_checked, raw_tag, &tag)) {
      continue;
    }
    if (!tag.empty()) {
      bidword.append(tag);
      // 空格会被索引过滤，改成分割符
      bidword.append(" | ");
    }
  }

  convert_info->add_bid_word_area(bidword);

  // source 放入 anchor 域
  std::string anchor;
  if (!item.source().empty()) {
    anchor.append(item.source());
  }
  if (!item.orig_source().empty()) {
    anchor.append(" ");
    anchor.append(item.orig_source());
  }
  convert_info->add_anchor_area(anchor);

  // category 放入 query 域
  std::string query;
  for (int i = 0; i < item.category_size(); ++i) {
    if (item.category(0) == "未分类") break;
    query.append(item.category(i));
    query.append(" ");
  }
  int char_num = 0;
  if (!base::GetUTF8CharNum(query, &char_num)) {
    LOG(ERROR) << "FATAL: none-utf8 char in category:" << query << " item: " << item.identity().item_id();
    return false;
  }
  convert_info->add_query_area(query);

  if (FLAGS_clear_content) {
    convert_info->add_content_area("");
  } else {
    convert_info->add_content_area(item.normalized_content());
  }

  uint32 doc_mask = 0;

  // importance
  // TODO(zhengying) 热度信息可能不能这样放
  if (item.has_popularity()) {
    convert_info->set_importance(item.popularity());
  }

  // 是否失效
  if (!item.is_valid()) {
    doc_mask |= adsindexing::kDocMaskInvalid;
  }

  std::string publish_time_str = item.publish_time().empty() ? item.create_time() : item.publish_time();
  if (!publish_time_str.empty()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kPublishTimestamp);
    base::Time time;
    base::Time::FromStringInSeconds(item.publish_time().c_str(), &time);
    attr->set_value(time.ToDoubleT() * base::Time::kMicrosecondsPerSecond);
  }
  if (!item.create_time().empty()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kCrawlTimestamp);
    base::Time time;
    base::Time::FromStringInSeconds(item.create_time().c_str(), &time);
    attr->set_value(time.ToDoubleT() * base::Time::kMicrosecondsPerSecond);
  }

  if (!item.expire_time().empty()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kExpireTimestamp);
    base::Time time;
    base::Time::FromStringInSeconds(item.expire_time().c_str(), &time);
    attr->set_value(time.ToDoubleT() * base::Time::kMicrosecondsPerSecond);
    doc_mask |= reco::common::kDocMaskTimeWhiteList;
  }

  if (!item.region().empty()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kRegion);
    attr->set_value(item.region());
    doc_mask |= reco::common::kDocMaskRegionWhiteList;
  }

  if (!item.region_from_title().empty()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kRegionFromTitle);
    attr->set_value(item.region_from_title());
  }

  if (!item.region_restrict().empty()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kRegionRestrict);
    attr->set_value(item.region_restrict());
  }

  if (item.has_video_storage_info() &&
      item.video_storage_info().has_youku_audit_status()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kYoukuAuditStatus);
    attr->set_value(item.video_storage_info().youku_audit_status());
  }

  std::set<std::string> filtered_apps;
  if (!item.filtered_app_names().empty()) {
    std::vector<std::string> flds;
    base::SplitString(item.filtered_app_names(), "`", &flds);
    for (size_t i = 0; i < flds.size(); ++i) {
      filtered_apps.insert(flds[i]);
    }
  }
  if (item.appname_filters_size() > 0) {
    for (int i = 0; i < item.appname_filters_size(); ++i) {
      filtered_apps.insert(item.appname_filters(i));
    }
  }
  for (auto it = filtered_apps.begin(); it != filtered_apps.end(); ++it) {
    if (base::LowerCaseEquals(*it, "ucnews-iflow")) {
      doc_mask |= reco::common::kDocMaskAppToutiao;
    } else if (base::LowerCaseEquals(*it, "huawei-iflow")) {
      doc_mask |= reco::common::kDocMaskAppHuawei;
    } else if (base::LowerCaseEquals(*it, "samsung-iflow")) {
      doc_mask |= reco::common::kDocMaskAppSamsung;
    } else if (base::LowerCaseEquals(*it, "meizunews-iflow")) {
      doc_mask |= reco::common::kDocMaskAppMeizu;
    }
  }
  // 土豆渠道需要过滤 youku_video_id 为空的视频
  if (item.identity().type() == kPureVideo && (!item.has_video_storage_info() ||
      !item.video_storage_info().has_youku_video_id() ||
      item.video_storage_info().youku_video_id().empty())) {
    doc_mask |= reco::common::kDocMaskAppTuDouIflow;
    doc_mask |= reco::common::kDocMaskAppYoukuIflow;
  }

  // if (!item.has_video_storage_info() ||
  //     !item.video_storage_info().has_youku_audit_status() ||
  //     item.video_storage_info().youku_audit_status() != "allowed") {
  //   doc_mask |= reco::common::kDocMaskAppYoukuIflow;
  // }

  // 初始源风险信息
  if (item.has_risk_info()) {
    if (item.risk_info().has_orig_media_risk_type()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kOrigMediaRiskType);
      attr->set_value(item.risk_info().orig_media_risk_type());
    }
  }

  {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kItemType);
    attr->set_value(item.identity().type());
  }

  if (item.identity().has_manual()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kManualNews);
    attr->set_value(item.identity().manual());
  }

  {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kOuterId);
    attr->set_value(item.identity().outer_id());
  }

  {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kAppToken);
    attr->set_value(producer);
  }

  {
    auto attr = convert_info->add_string_attr();
    std::string category;
    for (int i = 0; i < item.category_size(); ++i) {
      if (!category.empty()) {
        category += "\t";
      }
      category += item.category(i);
    }
    attr->set_key(reco::common::attr_key::kCategory);
    attr->set_value(category);
  }

  if (item.has_multi_category()) {
    auto attr = convert_info->add_string_attr();
    std::string buf;
    if (item.multi_category().SerializeToString(&buf)) {
      attr->set_key(reco::common::attr_key::kCategoryCandidates);
      attr->set_value(buf);
    } else {
      LOG(WARNING) << "serialize multi category failed, item id: " << item_id;
    }
  }

  {
    auto attr = convert_info->add_string_attr();
    std::string channel;
    std::unordered_set<int64> uniq_channels;
    for (int i = 0; i < item.channel_id_size(); ++i) {
      if (uniq_channels.find(item.channel_id(i)) != uniq_channels.end()) continue;
      if (!channel.empty()) {
        channel += "\t";
      }
      channel += base::Int64ToString(item.channel_id(i));
      uniq_channels.insert(item.channel_id(i));
    }
    attr->set_key(reco::common::attr_key::kChannel);
    attr->set_value(channel);
  }

  // 置顶相关
  if (item.priority_info_size() > 0) {
    auto attr = convert_info->add_string_attr();
    std::string priority;
    for (int i = 0; i < item.priority_info_size(); ++i) {
      if (i != 0) {
        priority += "\n";
      }
      const PriorityInfo& info = item.priority_info(i);
      priority += base::StringPrintf("%d\t%ld\t%s\t%s", info.priority(), info.channel_id(),
                                     info.start_time().c_str(), info.end_time().c_str());
    }
    attr->set_key(reco::common::attr_key::kPriority);
    attr->set_value(priority);
  }

  {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kSource);
    attr->set_value(item.source());
  }

  if (!item.orig_source().empty()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kOrigSource);
    attr->set_value(item.orig_source());
  }

  if (!item.source_media().empty()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kSourceMedia);
    attr->set_value(item.source_media());
  }

  if (!item.orig_source_media().empty()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kOrigSourceMedia);
    attr->set_value(item.orig_source_media());
  }

  // quality attr
  if (item.has_quality_attr()) {
    const reco::ItemQualityAttr& quality_attr = item.quality_attr();
    std::string dumped;
    if (quality_attr.SerializeToString(&dumped)) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kItemQualityAttr);
      attr->set_value(dumped);
    } else {
      LOG(WARNING) << "serialize quality attr failed, item id: " << item_id;
    }
    if (quality_attr.has_jingpin_score()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kJingpinScore);
      attr->set_value(quality_attr.jingpin_score());
    }
    if (quality_attr.has_is_yuanchuang() && quality_attr.is_yuanchuang()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kItemIsYuanchuang);
      attr->set_value(quality_attr.is_yuanchuang());
    }
    if (quality_attr.has_posterior_itemq()) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kPosteriorItemQ);
      attr->set_value(quality_attr.posterior_itemq());
    }
    // 优质倒排
    if (quality_attr.has_posterior_itemq()
        && quality_attr.posterior_itemq() >= FLAGS_youzhi_posterior_itemq_threshold) {
      auto term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetYouzhiItemPayloadTerm());
      term->set_payload(0);
    }
  }
  // content attr
  if (item.has_content_attr()) {
    uint64 bits;
    reco::common::PackContentAttr(item.content_attr(), &bits);
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kContentAttr);
    attr->set_value(bits);

    if (bits > 0) {
      auto term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetContentAttrPayloadTerm(bits));
      term->set_payload(0);
    }
  }

  // gaode poi
  if (item.has_gaode_poi()) {
    std::string dumped;
    if (item.gaode_poi().SerializeToString(&dumped)) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kGaoDePOI);
      attr->set_value(dumped);
    } else {
      LOG(WARNING) << "serialize gaode poi failed, item id: " << item_id;
    }
  }

  // time axis results
  if (item.has_time_axis_results()) {
    std::string serialized_str;
    if (item.time_axis_results().SerializeToString(&serialized_str)) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kTimeAxisResults);
      attr->set_value(serialized_str);
    } else {
      LOG(WARNING) << "serialize time axis failed, item id: " << item_id;
    }
  }

  // ucb 运营文章 投放设置直接整体序列化
  if (item.has_uc_browser_deliver_setting()) {
    std::string dumped;
    if (item.uc_browser_deliver_setting().SerializeToString(&dumped)) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kUcBrowserDeliverSetting);
      attr->set_value(dumped);
      LOG(INFO) << "build deliver setting for " << item_id << " with size " << dumped.size();
    } else {
      LOG(WARNING) << "serialize uc_browser_deliver_setting failed, item_id: " << item_id;
    }
  } else {
    // LOG(INFO) << item_id << " has no deliver setting";
  }

  // ucb 运营文章 投放样式
  if (item.has_uc_browser_display_setting()
      && item.uc_browser_display_setting().has_style_type()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kUcBrowserStyleType);
    attr->set_value(item.uc_browser_display_setting().style_type());

    if (item.uc_browser_display_setting().has_editor_name() &&
        !item.uc_browser_display_setting().editor_name().empty()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kUCBEditorName);
      attr->set_value(item.uc_browser_display_setting().editor_name());
    }
  }

  // 图片数量写入索引
  if (item.image_size() > 0) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kImageCount);
    attr->set_value(item.image_size());
  }

  // 小说更新信息
  // 小说各字段信息封装成 JSON 存储在 RecoItem 的 content 字段， 需要解析出来建到 index 中
  if (item.identity().type() == reco::kNovel
      && (item.source() == "神马小说更新" || item.source() == "神马小说")) {
    // 解析 json
    VLOG(1) << "convert novel notice item: item_id=" << item_id;
    json_error_t json_error;
    json_t *json = json_loads(item.content().c_str(), &json_error);
    if (json != NULL) {
      {
        std::string novel_id;
        json_t *j_novel_id = json_object_get(json, "novelId");
        if (j_novel_id != NULL && j_novel_id->type == JSON_STRING) {
          novel_id = json_string_value(j_novel_id);
        }
        // 小说 id 正排
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kNovelId);
        attr->set_value(novel_id);
        // 小说 id 倒排
        auto term = convert_info->add_term_payload();
        term->set_literal(reco::common::GetNovelIdPayloadTerm(novel_id));
        term->set_payload(0);
        VLOG(1) << "novel_id=" << novel_id;
      }
      {
        int64 novel_update_time = 0;
        json_t *j_novel_update_time = json_object_get(json, "updateTime");
        if (j_novel_update_time != NULL && j_novel_update_time->type == JSON_STRING) {
          base::Time time;
          std::string time_str = json_string_value(j_novel_update_time);
          base::Time::FromStringInSeconds(time_str.c_str(), &time);
          novel_update_time = time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
        }
        // 小说更新时间正排
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kNovelUpdateTime);
        attr->set_value(novel_update_time);
        VLOG(1) << "novel_update_time=" << novel_update_time;
      }
      json_decref(json);
    } else {
      LOG(WARNING) << "Failed to parse novel notice json line: " << json_error.line;
    }
  }

  // 视频数量
  if (item.video_meta_settings_size() > 0) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kVideoCount);
    attr->set_value(item.video_meta_settings_size());
  }

  // 视频封面图清晰度
  if (item.video_meta_settings_size() > 0) {
    auto &first_video = item.video_meta_settings(0);
    if (first_video.has_poster_clarity()) {
      auto attr = convert_info->add_float_attr();
      attr->set_key(reco::common::attr_key::kVideoPosterClarity);
      attr->set_value(first_video.poster_clarity());
    }
  }

  // 视频封面图黑边比例
  if (item.video_meta_settings_size() > 0) {
    auto &first_video = item.video_meta_settings(0);
    if (first_video.has_image_meta() && first_video.image_meta().has_black_edge_ratio()) {
      auto attr = convert_info->add_float_attr();
      attr->set_key(reco::common::attr_key::kVideoBlackEdgeRatio);
      attr->set_value(first_video.image_meta().black_edge_ratio());
    }
  }

  // 视频长宽色
  if (item.video_meta_settings_size() > 0) {
    auto &first_video = item.video_meta_settings(0);
    if (first_video.has_image_meta()) {
      if (first_video.image_meta().has_width()) {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kVideoWidth);
        attr->set_value(first_video.image_meta().width());
        VLOG(1) << "set video width:" << first_video.image_meta().width();
      }

      if (first_video.image_meta().has_height()) {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kVideoHeight);
        attr->set_value(first_video.image_meta().height());
        VLOG(1) << "set video height:" << first_video.image_meta().height();
      }

      if (first_video.image_meta().has_colors()) {
        auto attr = convert_info->add_int_attr();
        attr->set_key(reco::common::attr_key::kVideoColors);
        attr->set_value(first_video.image_meta().colors());
        VLOG(1) << "set video colors:" << first_video.image_meta().colors();
      }
    }
  }

  // 视频封面图问题
  if (item.video_meta_settings_size() > 0) {
    auto &first_video = item.video_meta_settings(0);
    if (first_video.has_poster_problem_info() && first_video.has_poster_problem_info()) {
      auto &problem_info = first_video.poster_problem_info();
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kVideoPosterProblemInfo);
      std::vector<std::string> problems;
      if (problem_info.has_is_black_edge() && problem_info.is_black_edge()) {
        problems.push_back("is_black_edge");
      }
      if (problem_info.has_is_twisty() && problem_info.is_twisty()) {
        problems.push_back("is_twisty");
      }
      if (problem_info.has_is_dim() && problem_info.is_dim()) {
        problems.push_back("is_dim");
      }
      if (problem_info.has_contain_watermark() && problem_info.contain_watermark()) {
        problems.push_back("contain_watermark");
      }
      attr->set_value(base::JoinStrings(problems, ","));
      VLOG(1) << item.identity().item_id() << " " << base::JoinStrings(problems, ",");
    }
  }


  // 视频总播放时长
  if (item.video_meta_settings_size() > 0) {
    int32 play_len = 0;
    for (int k = 0; k < item.video_meta_settings_size(); ++k) {
      play_len += item.video_meta_settings(k).play_length();
    }
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kVideoLength);
    attr->set_value(play_len);
  }

  // 视频低俗级别
  if (item.identity().type() == kPureVideo &&
      item.has_video_attr() &&
      item.video_attr().has_vulgarlevel()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kVideoVulgarLevel);
    attr->set_value((int)item.video_attr().vulgarlevel());
  }

  // 视频低质级别
  if (item.identity().type() == kPureVideo &&
      item.has_video_attr() &&
      item.video_attr().has_quality_level()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kVideoQualityLevel);
    attr->set_value((int)item.video_attr().quality_level());
  }

  // title 长度
  if (item.has_normalized_title()) {
    int title_char_num;
    if (base::GetUTF8CharNum(item.normalized_title(), &title_char_num)) {
      auto attr = convert_info->add_int_attr();
      attr->set_key(reco::common::attr_key::kTitleLength);
      attr->set_value(title_char_num);
    }
  }

  // 是否经过审核处理
  if (item.has_has_reviewed() && item.has_reviewed() == true) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kItemHasReviewed);
    attr->set_value(item.has_reviewed());
  }

  // 是否有自有视频存储地址
  if (item.has_video_storage_info() &&
      item.video_storage_info().has_normal() &&
      !item.video_storage_info().normal().empty()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kHasVideoStorageInfo);
    attr->set_value(true);
  }

  // 是否有视频自存储状态
  if (item.has_video_storage_info() &&
      item.video_storage_info().has_status()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kVideoStorageInfoStatus);
    attr->set_value(item.video_storage_info().status());
  }

  // 视频的播放控制设置
  if (item.has_video_play_control()) {
    std::string dumped;
    if (item.video_play_control().SerializeToString(&dumped)) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kVideoPlayControl);
      attr->set_value(dumped);
      VLOG(1) << "video_play_control dump:" << dumped;
    } else {
      LOG(WARNING) << "serialize video play control failed, item id: " << item_id;
    }
  }

  // 优酷的视频 ID
  if (item.has_video_storage_info() &&
      item.video_storage_info().has_youku_video_id() &&
      !item.video_storage_info().youku_video_id().empty()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kYoukuVideoId);
    attr->set_value(item.video_storage_info().youku_video_id());
  }

  if (item.has_video_meta_ext() && item.video_meta_ext().has_show_id()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kYoukuShowID);
    attr->set_value(item.video_meta_ext().show_id());
    VLOG(1) << "youku show id success" << item_id << " " << item.video_meta_ext().show_id();
  }

  if (item.has_raw_title()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kRawTitle);
    attr->set_value(item.raw_title());
    VLOG(1) << "raw title:" << item_id << " "  << item.raw_title();
  }

  // 角标
  if (item.has_subscripts()) {
    std::string serialized;
    if (item.subscripts().SerializeToString(&serialized)) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kItemSubscripts);
      attr->set_value(serialized);
    } else {
      LOG(WARNING) << "serialize subscript, item_id: " << item.identity().item_id();
    }
  }

  // add attr
  reco::common::PackFeatureVector(item.keyword(), reco::common::kKeyword, convert_info.get());
  reco::common::PackFeatureVector(item.topic(), reco::common::kTopic, convert_info.get());
  if (item.has_plsa_topic()) {
    reco::common::PackFeatureVector(item.plsa_topic(), reco::common::kPlsaTopic, convert_info.get());
  }
  if (item.has_title_lda()) {
    // lda topic 打太多需要截断
    reco::FeatureVector title_lda_feavec;
    for (int idx = 0; idx < 10 && idx < item.title_lda().feature_size(); ++idx) {
      if (item.title_lda().feature(idx).weight() < 0.05) break;
      title_lda_feavec.add_feature()->CopyFrom(item.title_lda().feature(idx));
    }
    VLOG(1) << "lda topic size: " << item.title_lda().feature_size()
            << "," << title_lda_feavec.feature_size();
    reco::common::PackFeatureVector(title_lda_feavec, reco::common::kTitleLdaTopic, convert_info.get());
  }
  reco::common::PackFeatureVector(item.wordvec(), reco::common::kWordvec, convert_info.get());
  reco::common::PackFeatureVector(item.tag(), reco::common::kTag, convert_info.get());
  // semantic_tag: 正排索引
  if (item.has_semantic_tag()) {
    reco::common::PackFeatureVector(item.semantic_tag(), reco::common::kSemanticTag, convert_info.get());
  }
  // show_tag: 正排
  if (item.show_tag_size() > 0) {
    std::string total_show_tag = "";
    for (int i = 0; i < item.show_tag_size(); ++i) {
      if (i != 0) {
        total_show_tag.append("|");
      }
      std::string show_tag_norm = nlp::util::NormalizeLine(item.show_tag(i));
      total_show_tag.append(show_tag_norm);
    }
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kItemShowTag);
    attr->set_value(total_show_tag);
  }
  // event_tag: 正排
  if (item.event_tag_info_size() > 0) {
    std::string total_event_tag = "";
    std::string total_info = "";
    for (int i = 0; i < item.event_tag_info_size(); ++i) {
      if (i != 0) {
        total_event_tag.append("|");
      }
      std::string event_tag_norm = nlp::util::NormalizeLine(item.event_tag_info(i).event_tag_name());
      total_event_tag.append(event_tag_norm);

      std::string serialized_str;
      if (item.event_tag_info(i).SerializeToString(&serialized_str)) {
        if (i != 0) {
          total_info.append("|");
        }
        total_info.append(serialized_str);
      } else {
        LOG(WARNING) << "serialize event tag failed, item id: " << item_id;
      }
    }
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kItemEventTag);
    attr->set_value(total_event_tag);
    VLOG(1) << "event_tag forward index ! item_id:" << item.identity().item_id();

    auto attr_info = convert_info->add_string_attr();
    attr_info->set_key(reco::common::attr_key::kItemEventTagInfo);
    attr_info->set_value(total_info);
  }

  // 以内部 id 作为文档的签名
  uint64 key_sign = item.identity().item_id();

  // 建立特殊 term
  // APP TOKEN
  auto term = convert_info->add_term_payload();
  term->set_literal(reco::common::GetAppTokenPayloadTerm(producer));
  term->set_payload(0);
  // item type
  term = convert_info->add_term_payload();
  term->set_literal(reco::common::GetItemTypePayloadTerm(item.identity().type()));
  term->set_payload(0);
  // category
  for (int i = 0; i < item.category_size(); ++i) {
    term = convert_info->add_term_payload();
    term->set_literal(reco::common::GetCategoryPayloadTerm(item.category(i), i));
    term->set_payload(0);
  }

  // multi category
  for (int i = 0; i < item.multi_category().category_candidates_size(); ++i) {
    const reco::ItemCategory category = item.multi_category().category_candidates(i);
    term = convert_info->add_term_payload();
    term->set_literal(reco::common::GetCategoryCandidatesPayloadTerm(category.level1(), 0));
    term->set_payload(0);
    for (int j = 0; j < category.level2_size(); ++j) {
      term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetCategoryCandidatesPayloadTerm(category.level2(j), 1));
      term->set_payload(0);
    }
  }

  if (!item.query().empty()) {
    term = convert_info->add_term_payload();
    term->set_literal(reco::common::GetSpiderQueryPayloadTerm(nlp::util::NormalizeLine(item.query())));
    term->set_payload(0);
  }

  // group info attr
  if (item.has_item_group_info()) {
    std::string dumped;
    if (item.item_group_info().SerializeToString(&dumped)) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kGroupInfo);
      // attr->set_value(reco::common::EncodeUrlComponent(dumped));
      attr->set_value(dumped);
    }

    if (item.item_group_info().has_group_id()) {
      auto term = convert_info->add_term_payload();
      const std::string& payload_key
          = reco::common::GetPayloadUint64("GROUP", item.item_group_info().group_id());
      term->set_literal(payload_key);
      term->set_payload(0);
    }
  }

  // wemida attr
  if (!item.show_source().empty()
      && base::StartsWithCaseSensitive(item.source(), reco::common::kWeMediaSourcePrefix)) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kWeMediaPerson);
    attr->set_value(item.show_source());

    auto term = convert_info->add_term_payload();
    term->set_literal(reco::common::GetWeMediaPayloadTerm());
    term->set_payload(0);
  }
  // preview / summary
  if (!item.summary().empty()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kRawSummary);
    attr->set_value(item.summary());
  }
  if (item.identity().type() == reco::kSpecial
      || item.identity().type() == reco::kWeMediaCard) {
    if (producer == reco::common::kUCBProducer) {
      std::vector<std::string> contain_ids;
      GetUCBSpecialContentIds(item, &contain_ids);
      if (!contain_ids.empty()) {
        std::string str_id_list = base::JoinStrings(contain_ids, ",");
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kSpecialContainIdList);
        attr->set_value(str_id_list);
        auto attr2 = convert_info->add_string_attr();
        attr2->set_key(reco::common::attr_key::kSpecialPreviewIdList);
        attr2->set_value(str_id_list);
      }
    } else if (producer == reco::common::kZZDProducer || producer == reco::common::kZZDOpProducer) {
      // 专题内容包含的文章
      std::vector<std::string> contain_ids;
      GetZZDSpecialContentIds(item, &contain_ids);
      if (!contain_ids.empty()) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kSpecialContainIdList);
        attr->set_value(base::JoinStrings(contain_ids, ","));
      }
      // 专题 preview 的文章
      std::vector<std::string> preview_ids;
      GetZZDSpecialPreviewIds(item, &preview_ids);
      if (preview_ids.empty() && !contain_ids.empty()) {
        preview_ids.push_back(contain_ids[0]);
      }
      if (!preview_ids.empty()) {
        auto attr = convert_info->add_string_attr();
        attr->set_key(reco::common::attr_key::kSpecialPreviewIdList);
        attr->set_value(base::JoinStrings(preview_ids, ","));
      }
    }
  } else if (item.identity().type() == reco::kThemeVideo) {
    reco::SubjectSubItems subject_sub_items;
    GetZZDSubjectSubItems(item, &subject_sub_items);
    std::string dumped;
    if (subject_sub_items.SerializeToString(&dumped)) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kSubjectSubItems);
      attr->set_value(dumped);
    } else {
      LOG(WARNING) << "serialize subject_sub_items failed, item_id: " << item_id;
    }
  }

  // channel
  for (int i = 0; i < item.channel_id_size(); ++i) {
    term = convert_info->add_term_payload();
    term->set_literal(reco::common::GetChannelPayloadTerm(item.channel_id(i)));
    term->set_payload(0);
  }
  // source
  term = convert_info->add_term_payload();
  term->set_literal(reco::common::GetSourcePayloadTerm(item.source()));
  term->set_payload(0);

  if (!item.orig_source().empty()) {
    term = convert_info->add_term_payload();
    term->set_literal(reco::common::GetSourcePayloadTerm(item.orig_source()));
    term->set_payload(0);
  }

  // keyword
  for (int i = 0; i < item.keyword().feature_size(); ++i) {
    auto term = convert_info->add_term_payload();
    auto& fea = item.keyword().feature(i);
    term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kKeyword));
    term->set_payload(fea.weight() * 100);
  }

  // topic
  for (int i = 0; i < item.topic().feature_size(); ++i) {
    auto term = convert_info->add_term_payload();
    auto& fea = item.topic().feature(i);
    term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kTopic));
    term->set_payload(fea.weight() * 100);
  }

  // new plsa topic
  if (item.has_plsa_topic()) {
    for (int i = 0; i < item.plsa_topic().feature_size(); ++i) {
      auto term = convert_info->add_term_payload();
      auto& fea = item.plsa_topic().feature(i);
      term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kPlsaTopic));
      term->set_payload(fea.weight() * 100);
    }
  }

  // title lda topic
  if (item.has_title_lda()) {
    for (int i = 0; i < 5 && i < item.title_lda().feature_size(); ++i) {
      if (item.title_lda().feature(i).weight() < 0.1) break;
      auto term = convert_info->add_term_payload();
      auto& fea = item.title_lda().feature(i);
      term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kTitleLdaTopic));
      term->set_payload(fea.weight() * 100);
    }
  }

  // wordvec
  for (int i = 0; i < item.wordvec().feature_size(); ++i) {
    auto term = convert_info->add_term_payload();
    auto& fea = item.wordvec().feature(i);
    term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kWordvec));
    term->set_payload(fea.weight() * 100);
  }

  // show tag
  for (int i = 0; i < item.show_tag_size(); ++i) {
    auto term = convert_info->add_term_payload();
    // tag show_tag 做了规范化，在倒排索引处需要 normalize
    std::string show_tag_norm = nlp::util::NormalizeLine(item.show_tag(i));
    term->set_literal(reco::common::GetShowTagPayloadTerm(show_tag_norm));
    term->set_payload(0);
  }

  // tag
  // bool munual_checked = IsTagManualChecked(item);
  for (int i = 0; i < item.tag().feature_size(); ++i) {
    auto& fea = item.tag().feature(i);
    std::string raw_tag = fea.literal();
    std::string real_tag;
    if (!ExtractRealTag(munual_checked, raw_tag, &real_tag)) {
      continue;
    }
    auto term = convert_info->add_term_payload();
    // tag show_tag 做了规范化，在倒排索引处需要 normalize
    std::string real_tag_norm = nlp::util::NormalizeLine(real_tag);
    term->set_literal(reco::common::GetFeaturePayloadTerm("label:" + real_tag_norm, reco::common::kTag));
    term->set_payload(fea.weight() * 100);
  }

  for (int i = 0; i < item.synonymous_tags_size(); ++i) {
    if (item.synonymous_tags(i).empty()) {
      continue;
    }
    const std::string& raw_tag = item.synonymous_tags(i);
    std::string real_tag;
    if (!ExtractRealTag(false, raw_tag, &real_tag)) {
      continue;
    }
    auto term = convert_info->add_term_payload();
    term->set_literal(reco::common::GetFeaturePayloadTerm("label:" + real_tag, reco::common::kTag));
    term->set_payload(10);
  }

  // semantic_tag: 倒排索引
  if (item.has_semantic_tag()) {
    for (int i = 0; i < item.semantic_tag().feature_size(); ++i) {
      auto& fea = item.semantic_tag().feature(i);

      auto term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetFeaturePayloadTerm(fea.literal(), reco::common::kSemanticTag));
      term->set_payload(fea.weight() * 100);

      // 语义标签索引也建到实体标签的倒排
      // 第一，有些标签既可以作为语义标签，又可以作为实体标签，比如 反腐倡廉
      // 第二，方便检索, 使用 GetDocsByTag 就能检索到某个标签的所有文档
      const std::string& raw_tag = fea.literal();
      std::string real_tag;
      if (!ExtractRealTag(false, raw_tag, &real_tag)) {
        continue;
      }
      auto term_tag = convert_info->add_term_payload();
      term_tag->set_literal(reco::common::GetFeaturePayloadTerm("label:" + real_tag, reco::common::kTag));
      term_tag->set_payload(10);
      VLOG(1) << "semantic_tag inverted index ! item_id:" << item.identity().item_id();
    }
  }

  // event_tag: 倒排
  for (int i = 0; i < item.event_tag_info_size(); ++i) {
    auto term = convert_info->add_term_payload();
    std::string event_tag_norm = nlp::util::NormalizeLine(item.event_tag_info(i).event_tag_name());
    term->set_literal(reco::common::GetEventTagPayloadTerm(event_tag_norm));
    term->set_payload(0);
    VLOG(1) << "event_tag inverted index ! item_id:" << item.identity().item_id();
  }

  // key
  convert_info->set_key(std::string(reinterpret_cast<const char *>(&key_sign), 8));
  // item type

  // add sim feature as term doc feature
  for (int i = 0; i < item.sim_feature_size(); ++i) {
    adsindexing::TermDocFeature* term_doc_feature = convert_info->add_term_feature();
    term_doc_feature->set_literal(item.sim_feature(i).literal());
    term_doc_feature->set_feature(item.sim_feature(i).feature());
  }
  convert_info->set_term_feature_version(0);
  convert_info->set_term_feature_bytes(reco::sim_item::SimTermInfo::kTermInfoBytes);

  // parse simhash
  if (item.has_simhash()) {
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kSimHash);
    attr->set_value(base::Int64ToString(item.simhash()));
  }

  // 正文长度
  char_num = 0;
  if (base::GetUTF8CharNum(item.normalized_content(), &char_num)) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kContentLength);
    attr->set_value(char_num);
  }

  // paragraph hash
  if (item.paragraph_simhash_size() > 0) {
    // 段落数量
    auto attr_int = convert_info->add_int_attr();
    attr_int->set_key(reco::common::attr_key::kParagraphNum);
    attr_int->set_value(item.paragraph_simhash_size());

    // 段落 hash
    auto attr = convert_info->add_string_attr();
    attr->set_key(reco::common::attr_key::kParagraphHash);
    std::ostringstream oss;
    for (int i = 0; i < item.paragraph_simhash_size(); ++i) {
      oss << item.paragraph_simhash(i);
      if (i != item.paragraph_simhash_size() - 1) {
        oss << ",";
      }
    }
    attr->set_value(oss.str());
  }

  // image hash
  if (item.image_size() > 0) {
    std::string value;
    value.reserve(64* item.image_size());
    for (int i = 0; i < item.image_size(); ++i) {
      const NewsImage& img = item.image(i);
      if (img.is_qrcode()) {
        continue;
      }
      if (!value.empty()) value.push_back(',');
      value +=  base::Int64ToString(img.simhash());

      auto term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetPicturePayloadTerm(img.simhash()));
      term->set_payload(0);
    }

    if (!value.empty()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kImageHash);
      attr->set_value(value);
    }
    // (NOTE): add image has as payload term for image search
  }

  if (item.has_region()) {
    std::vector<std::string> region_ids;
    base::SplitString(item.region(), ";", &region_ids);
    for (int i = 0; i < (int)region_ids.size(); ++i) {
      if (region_ids[i].empty()) continue;
      auto term = convert_info->add_term_payload();
      term->set_literal(reco::common::GetRegionIDPayloadTerm(region_ids[i]));
      term->set_payload(0);
    }
  }

  // set publish time
  if (!item.publish_time().empty()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kPublishTimeInSeconds);
    base::Time time;
    base::Time::FromStringInSeconds(item.publish_time().c_str(), &time);
    attr->set_value(time.ToDoubleT());
  }

  // set local breaking
  if (item.has_local_breaking()) {
    std::string breaking_str;
    if (item.local_breaking().SerializeToString(&breaking_str)) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kLocalBreaking);
      attr->set_value(breaking_str);
    } else {
      LOG(WARNING) << "serialize local breaking failed, item id: " << item_id;
    }
  }

  GetOfflineFilterRule(item, &doc_mask, convert_info.get());

  if (item.has_video_storage_info() && item.video_storage_info().has_resolution()
          && !item.video_storage_info().resolution().empty()) {
    reco::ResolutionType type = StringToResolutionType(item.video_storage_info().resolution());
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kVideoResolution);
    attr->set_value(type);
  }

  // doc mask
  auto doc_mask_attr = convert_info->add_int_attr();
  doc_mask_attr->set_key("DocMask");
  doc_mask_attr->set_value(doc_mask);

  // 将最终得到的 proto Serialize 再 Parse 一下，这样没有设置的 require 字段会导致 check
  std::string serialized;
  CHECK(convert_info->IsInitialized()) << "proto has required field not set";
  CHECK(convert_info->SerializeToString(&serialized)) << "proto can not serialize";
  adsindexing::ConvertInfo another;
  CHECK(another.ParseFromString(serialized));

  if (!index_cdoc_convertor_->ConvertToCDoc(*convert_info, cdoc)) return false;
  return (cdoc->has_key() && cdoc->key().size() != 0);
}  // NOLINT

void ItemCDocConvertor::GetOfflineFilterRule(const reco::RecoItem& reco_item,
                                             uint32* doc_mask, adsindexing::ConvertInfo* convert_info) {
  if (!reco_item.has_offline_filter_rule()) {
    LOG(ERROR) << "item miss offline_filter_rule, item_id: " << reco_item.identity().item_id();
    return;
  }

  if (!reco_item.offline_filter_rule().has_is_filter()) {
    LOG(ERROR) << "item miss offline_filter_rule.is_filter, item_id: " << reco_item.identity().item_id();
  } else if (reco_item.offline_filter_rule().is_filter()) {
    *doc_mask |= reco::common::kDocFilterServer;
  } else {
    *doc_mask &= ~reco::common::kDocFilterServer;
  }

  if (reco_item.offline_filter_rule().has_first_nscreen_filter()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kFirstNScreenFilter);
    attr->set_value(reco_item.offline_filter_rule().first_nscreen_filter());
  }

  if (reco_item.offline_filter_rule().has_app_token_rule_bits()) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kAppTokenBits);
    attr->set_value(reco_item.offline_filter_rule().app_token_rule_bits().app_token_bits());

    if (reco_item.offline_filter_rule().app_token_rule_bits().has_rule_bits()) {
      auto attr = convert_info->add_string_attr();
      attr->set_key(reco::common::attr_key::kAppTokenRuleBits);
      attr->set_value(reco_item.offline_filter_rule().app_token_rule_bits().rule_bits());
    }
  }

  int64 platforms = 0;
  for (int i = 0; i < reco_item.offline_filter_rule().real_publish_platform_size(); ++i) {
    platforms |= 0x01 << reco_item.offline_filter_rule().real_publish_platform(i);
  }
  if (platforms > 0) {
    auto attr = convert_info->add_int_attr();
    attr->set_key(reco::common::attr_key::kSourcePublishPlatform);
    attr->set_value(platforms);
  }

  return;
}

void ItemCDocConvertor::GetZZDSpecialPreviewIds(const reco::RecoItem& reco_item,
                                             std::vector<std::string>* id_list) {
  id_list->clear();
  if (reco_item.identity().type() != reco::kSpecial
      || reco_item.summary().empty()) return;

  const std::string& summary = reco_item.summary();

  json_error_t json_error;
  json_t *json = json_loads(summary.c_str(), &json_error);
  if (json == NULL || json->type != JSON_ARRAY) {
    LOG(WARNING) << "Failed to load line: " << json_error.line;
    return;
  }
  unsigned int doc_size = json_array_size(json);
  for (unsigned int i = 0u; i < doc_size; ++i) {
    json_t *obj = json_array_get(json, i);
    if (obj == NULL) {
      LOG(WARNING) << "summary json error, json: " << summary;
      continue;
    }
    json_t *para = json_object_get(obj, "article_id");
    if (para == NULL || para->type != JSON_STRING) {
      if (i != 0u) {
        LOG(WARNING) << "summary json error, json: " << summary;
      }
      continue;
    }
    const char* id_str = json_string_value(para);
    uint64 id = 0u;
    if (!base::StringToUint64(id_str, &id)) {
      LOG(WARNING) << "summary json error, json: " << summary;
      continue;
    }
    id_list->push_back(id_str);
  }
}

void ItemCDocConvertor::GetZZDSpecialContentIds(const reco::RecoItem& reco_item,
                                             std::vector<std::string>* id_list) {
  id_list->clear();
  if (reco_item.identity().type() != reco::kSpecial || reco_item.content().empty()) return;

  const std::string& content = reco_item.content();

  json_error_t json_error;
  json_t *json = json_loads(content.c_str(), &json_error);
  if (json == NULL || json->type != JSON_ARRAY) {
    LOG(WARNING) << "Failed to load line: " << json_error.line;
    return;
  }
  uint64 id = 0;
  unsigned int size = json_array_size(json);
  for (unsigned int i = 0u; i < size; ++i) {
    json_t* obj = json_array_get(json, i);
    if (obj == NULL) {
      LOG(WARNING) << "content json error, json: " << content;
      continue;
    }
    json_t* para = json_object_get(obj, "special");
    if (para == NULL) {
      continue;
    }
    json_t* article_json = json_object_get(para, "article_id");
    if (article_json != NULL) {
      if (article_json->type == JSON_STRING
          && base::StringToUint64(json_string_value(article_json), &id)) {
        id_list->push_back(json_string_value(article_json));
      }
      continue;
    }
    json_t* special_list_json = json_object_get(para, "list");
    if (special_list_json == NULL || special_list_json->type != JSON_ARRAY) {
      continue;
    }
    for (unsigned int j = 0u; j < json_array_size(special_list_json); ++j) {
      json_t* special_json = json_array_get(special_list_json, j);
      if (special_json == NULL) {
        continue;
      }
      article_json = json_object_get(special_json, "article_id");
      if (article_json == NULL) {
        continue;
      }
      if (article_json->type == JSON_STRING
          && base::StringToUint64(json_string_value(article_json), &id)) {
        id_list->push_back(json_string_value(article_json));
      }
    }
  }
}

void ItemCDocConvertor::GetZZDSubjectSubItems(const reco::RecoItem& reco_item,
                                                   reco::SubjectSubItems* subject_sub_items) {
  if (reco_item.identity().type() != reco::kThemeVideo || reco_item.content().empty()) {
    return;
  }
  subject_sub_items->Clear();

  const std::string& content = reco_item.content();

  json_error_t json_error;
  json_t *json = json_loads(content.c_str(), &json_error);
  if (json == NULL || json->type != JSON_ARRAY) {
    LOG(WARNING) << "content get subject Failed to load line: " << json_error.line
        << ", error: " << json_error.text << ", content: " << content;
    return;
  }

  uint64 u_buf = 0;
  int64 buf = 0;

  unsigned int size = json_array_size(json);
  reco::SubjectSubItem sub_item;
  for (unsigned int i = 0u; i < size; ++i) {
    sub_item.Clear();
    json_t* obj = json_array_get(json, i);
    if (obj == NULL) {
      LOG(WARNING) << "content json error, json: " << content;
      continue;
    }

    json_t* item_id_json = json_object_get(obj, "item_id");
    if (!json_is_string(item_id_json)
        || !base::StringToUint64(json_string_value(item_id_json), &u_buf)) {
      json_type type = item_id_json == NULL ? JSON_NULL : json_typeof(item_id_json);
      LOG(WARNING) << "content get subject item_id error, json_type: " << type;
      continue;
    }
    sub_item.set_item_id(u_buf);

    json_t* time_json = json_object_get(obj, "create_time");
    if (!json_is_integer(time_json)) {
      json_type type = time_json == NULL ? JSON_NULL : json_typeof(time_json);
      LOG(WARNING) << "content get subject create_time error, item_id: " << buf << ", json_type: " << type;
      continue;
    }
    sub_item.set_create_time(json_integer_value(time_json));

    time_json = json_object_get(obj, "modify_time");
    if (json_is_integer(time_json)) {
      sub_item.set_modify_time(json_integer_value(time_json));
    } else {
      json_type type = time_json == NULL ? JSON_NULL : json_typeof(time_json);
      LOG(WARNING) << "content get subject create_time error, item_id: " << buf << ", json_type: " << type;
    }

    // 解析子文播控码
    json_t* policy_code_str = json_object_get(obj, "policy_code");
    if (policy_code_str != NULL) {
      if (json_is_string(policy_code_str)) {
        json_t *policy_code_json = json_loads(json_string_value(policy_code_str), &json_error);
        if (policy_code_json != NULL && policy_code_json->type == JSON_ARRAY) {
          for (unsigned int j = 0u; j < json_array_size(policy_code_json); ++j) {
            json_t* pcode_json = json_array_get(policy_code_json, j);
            if (json_is_integer(pcode_json)) {
              sub_item.add_policy_code(json_integer_value(pcode_json));
            } else {
              json_type type = pcode_json == NULL ? JSON_NULL : json_typeof(pcode_json);
              LOG(WARNING) << "content get subject policy_code error, item_id: " << buf
                           << ", pcode json_type: " << type;
            }
          }
        } else {
          json_type type = policy_code_json == NULL ? JSON_NULL : json_typeof(policy_code_json);
          LOG(WARNING) << "content get subject policy_code error, item_id: " << buf
                       << ", policy_code json_type: " << type;
        }
      } else {
          LOG(WARNING) << "content get subject policy_code error, item_id:" << u_buf
                    << ", policy_code_str is not string, type:" << policy_code_str->type;
      }
    }

    subject_sub_items->add_sub_items()->CopyFrom(sub_item);
  }
}
}  // namespace reco
