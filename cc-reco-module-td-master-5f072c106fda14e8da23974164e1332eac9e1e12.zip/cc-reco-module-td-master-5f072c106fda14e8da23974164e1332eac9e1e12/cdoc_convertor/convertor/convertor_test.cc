#include <iostream>
#include "reco/module/cdoc_convertor/convertor/raw_item_convertor.h"
#include "reco/module/cdoc_convertor/convertor/item_cdoc_convertor.h"
#include "reco/module/cdoc_convertor/convertor/item_bow.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/hbase_set_item_attr.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "ads_index/api/cdoc_convertor.pb.h"
#include "nlp/segment/segmenter.h"
#include "nlp/common/nlp_util.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"

#include "base/testing/gtest.h"
#include "base/common/gflags.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"

DEFINE_string(hbase_table, "tb_reco_item", "hbase table");
DECLARE_string(reco_item_feature_data_dir);
DECLARE_string(reco_region_data_dir);

DEFINE_string(db_host, "tcp://11.251.203.145:3306", "dbhost");
DEFINE_string(db_user, "recodev", "db user");
DEFINE_string(db_passwd, "tkDn19DHeVZkNA", "db passwd");
DEFINE_string(schema, "reco", "shcema");
DECLARE_string(realtime_detect_rule_tree_xml);
DECLARE_string(item_classify_server_ip);
namespace reco {
namespace hbase {
DECLARE_string(hbase_thrift_ips);
}
class ConvertorTest : public testing::Test {
 public:
  void SetUp() {
    reco::hbase::FLAGS_hbase_thrift_ips="11.251.181.33:9090,11.251.181.38:9090,11.251.181.42:9090,11.251.181.48:9090";  // NOLINT
    reco::hbase::HBasePoolIns::instance().Init();
    CHECK(reco::hbase::HBasePoolIns::instance().is_inited());
    GlobalDataIns::instance().Init();
    // FLAGS_reco_item_feature_data_dir="serving/reco/data/cdoc_convertor/";
    // FLAGS_reco_region_data_dir="serving/reco/data/cdoc_convertor/";

    FLAGS_realtime_detect_rule_tree_xml="serving/reco/data/cdoc_convertor/rule_forest.xml";
    FLAGS_item_classify_server_ip = "11.251.177.94";
    raw_convertor_ = new RawItemConvertor(FLAGS_hbase_table);
    cdoc_convertor_ = new ItemCDocConvertor();
    ConstructTestCase();
  }

  void TearDown() {
    delete raw_convertor_;
    delete cdoc_convertor_;
  }
  void ConstructTestCase() {
    reco::UcBrowserDeliverSetting deliver;
    deliver.add_province("prov");
    deliver.add_city("city");
    deliver.add_ve("ve");
    deliver.add_fr("fr");
    deliver.add_isp("isp");
    deliver.add_nt("nt");
    deliver.add_sv("sv");

    reco::UcBrowserDisplaySetting display;

    test_cases_.reserve(32);
    {
      test_cases_.push_back(reco::RawItem());
      reco::RawItem& raw_item = test_cases_.back();
      raw_item.set_content("content1");
      raw_item.set_title("title1");
      raw_item.mutable_identity()->set_app_token("ucnews");
      raw_item.mutable_identity()->set_item_id(1);
      raw_item.mutable_identity()->set_outer_id("test1");
      raw_item.mutable_identity()->set_type(reco::kNews);
      raw_item.mutable_identity()->set_producer("uc");

      raw_item.set_is_valid(true);
      raw_item.set_source("zzd");
      raw_item.set_is_webview(true);
      raw_item.add_category("财经");
      raw_item.add_category("基金");

      raw_item.set_create_time("2016-03-23 00:00:30");
      raw_item.set_publish_time("2016-03-23 00:00:00");
      raw_item.set_expire_time("");

      content_attrs_.push_back(reco::ContentAttr());
      content_attrs_.back().set_advertorial(reco::ContentAttr::kSureYes);
      is_valid_.push_back(true);
      is_ok_.push_back(true);
      title_.push_back("title_chagne1");
      expire_time_.push_back("2017-03-23 00:00:00");
      deliver.clear_tag();
      deliver.add_tag("tag1");
      deliver_.push_back(deliver);
      display.set_daoliu_type(0);
      display_.push_back(display);
      url_.push_back("http://url1");
    }
    {
      test_cases_.push_back(reco::RawItem());
      reco::RawItem& raw_item = test_cases_.back();
      raw_item.set_content("content2");
      raw_item.set_title("title2");
      raw_item.mutable_identity()->set_app_token("ucnews");
      raw_item.mutable_identity()->set_item_id(2);
      raw_item.mutable_identity()->set_outer_id("test2");
      raw_item.mutable_identity()->set_type(reco::kNews);
      raw_item.mutable_identity()->set_producer("uc");

      raw_item.set_is_valid(true);
      raw_item.set_source("zzd");
      raw_item.set_is_webview(true);
      raw_item.add_category("国内");

      raw_item.set_create_time("2016-03-23 00:00:30");
      raw_item.set_publish_time("2016-03-23 00:00:00");
      raw_item.set_expire_time("");

      content_attrs_.push_back(reco::ContentAttr());
      content_attrs_.back().set_bluffing_title(reco::ContentAttr::kSuspect);
      content_attrs_.back().set_dirty(reco::ContentAttr::ContentAttr::kSureYes);

      is_valid_.push_back(false);
      is_ok_.push_back(false);
      title_.push_back("title_chagne2");
      expire_time_.push_back("2018-03-23 00:00:00");
      deliver.clear_tag();
      deliver.add_tag("tag2");
      deliver_.push_back(deliver);

      display.set_daoliu_type(0);
      display_.push_back(display);
      url_.push_back("http://url2");
    }
  }

 public:
  RawItemConvertor* raw_convertor_;
  ItemCDocConvertor* cdoc_convertor_;

  std::vector<reco::RawItem> test_cases_;
  std::vector<reco::ContentAttr> content_attrs_;
  std::vector<bool> is_valid_;
  std::vector<bool> is_ok_;
  std::vector<std::string> title_;
  std::vector<std::string> url_;
  std::vector<std::string> expire_time_;
  std::vector<reco::UcBrowserDeliverSetting> deliver_;
  std::vector<reco::UcBrowserDisplaySetting> display_;
};

struct TestCase {
  std::string title;
  std::string publish_time;
  std::string expire_time;
  std::string ans;
  std::string content;
  TestCase(std::string t, std::string p, std::string e, std::string a) {
    title = t;
    publish_time = p;
    expire_time = e;
    ans = a;
  }
};

TEST_F(ConvertorTest, KWTest) {
  std::vector<TestCase> test_case;
  RawItem raw_item;
  raw_item.Clear();
  raw_item.mutable_identity()->set_app_token("test");
  raw_item.mutable_identity()->set_item_id(1);
  raw_item.mutable_identity()->set_outer_id("test");
  raw_item.mutable_identity()->set_type(reco::kNews);
  raw_item.mutable_identity()->set_producer("uc");

  raw_item.set_is_valid(true);
  raw_item.set_source("zzd");
  raw_item.set_is_webview(true);
  raw_item.add_category("财经");
  raw_item.add_category("基金");

  test_case.push_back(TestCase("固本开新再走长征路 一图看懂习近平强军梦路径", "2016-08-08 11:00:00", "", ""));
  test_case.push_back(TestCase("家属参与管理打造和谐社区校园", "2016-08-08 11:00:00", "",
                               ": 今年60岁的廖生林是湖南常德人,退休来中山市已经8年。作为一名员工家属,"
                               "两年前,他又在中山市纪中三鑫双语学校上岗了,成为学校的教学管理督察员。"
                               "如今,他每天的工作就是拿着手机在学校巡查、拍照,将一些不文明的现象反募学校教职"
                               "员工的家属成立了校园居委会,共同参与学校管理。在1万多名师生和400多名家属的努力"
                               "下，“打造和谐社区校园”已由口号变为行动。 说起社区化管理,很多人都会想起小区和"
                               "居民区,但早在几年前,三鑫双语学校就提出了“打造和谐社区校园”的目标,开展社区化"
                               "管理的探索。学校招聘员工家属组成校园居委会分片参与学校管理。 该校校办主任"
                               "李珊介绍说,为了留住人才,学校打出“感情牌”,鼓励员工携家带口并为他们提供职工"
                               "宿舍。 2001年,刚从大学毕业的廖梦枝就来到这里工作。5年后,她的女儿出生。廖生林"
                               "便和老伴前来帮忙带孩子。慢慢地孩子长大了,老两口的生活重心不得不改 变。他们将"
                               "更多的时间用来参与学校的活动,如帮忙调解邻里之间的矛盾,组织退休老人开展文体活"
                               "动等。后来,学校成立社区居委会,老两口踊跃参与。“廖老师 的母亲还弄了个老人舞蹈"
                               "队,每年六一、元旦还会登台表演助兴。”李珊说。 2014年,廖生林和另外几名员工家属"
                               "被聘请为学校教学管理督导员。每天他会来到学校生活部查看学生的早锻炼情况,会跟"
                               "随学生前往饭堂,检查当天的伙食和用餐情况,还前往教学楼查看师生的上课情况。遇到"
                               "不文明的现象,比如上课睡觉、教师不在岗等还用手机拍下来。 李诗嘉是三鑫双语学校"
                               "一名学生。每周她都会身穿红色的志愿者马甲,和同学们一起清理校园垃圾。教学楼内"
                               "、学生宿舍里、校内小道上……他们的身影构成了一道亮丽的风景。“我们希望通过这样"
                               "的行动来影响周围的人,让大家都保护环境,参与学校或社区建设。”李诗嘉说。 据了"
                               "解,三鑫双语学校开办时就注重抓党建,将党员干部当成学校发展的“主力军”。近期,学"
                               "校以“两学一做”为切入口,发起“党团少工委,共建和谐家园” 主题系列学习实践活动。"
                               "学校党支部发起了“文明校园,从我做起”系列活动,评选了“最美员工宿舍”“最美教工楼”“"
                               "最美办公桌”“最美教室”等,党支部纪 检委员带领的纪检团队还通过每周的常规检查和"
                               "每月的专项检查,评选出了“最美的校园一角”。三鑫双语学校充分发挥和调动全校师生"
                               "和教职员工的力量建设和谐 社区。廖生林说:“当职工的父母和小孩都在身边,而且过得"
                               "开心、快乐,那他还有什么理由不开心工作呢?”"));

  test_case.push_back(TestCase("宠物藏獒萌萌哒大獒子, 我咋这么喜欢你呢? 成熟稳重, 懂",
                               "2016-08-08 11:00:00", "", ""));

  nlp::segment::Segmenter segmenter;
  nlp::postag::PosTagger postagger;
  nlp::ner::Ner ner;

  ItemBow item_bow;
  std::string str;
  nlp::term::TermContainer container;
  std::vector<InnerTagInfo> tag_candidates;
  reco::RecoItem reco_item;
  for (int i = 0; i < (int)test_case.size(); ++i) {
    raw_item.set_create_time(test_case[i].publish_time);
    raw_item.set_publish_time(test_case[i].publish_time);
    raw_item.set_expire_time("");
    raw_item.set_title(test_case[i].title);
    raw_item.set_content(test_case[i].ans);

    std::string str = test_case[i].title + raw_item.content();
    container.renew();
    nlp::util::NormalizeLineInPlaceS(&str);
    CHECK(segmenter.SegmentT(str, &container));
    CHECK(postagger.PosTagT(str, &container));
    CHECK(ner.DetectEntityT(str, &container));
    tag_candidates.clear();
    nlp::util::ConstructMixTerms(str, false, &container);
    reco::RecoItem reco_item;
    ASSERT_TRUE(item_bow.ExtractKeywords(str, raw_item.title(), container, &reco_item, &tag_candidates));
    for (int i = 0; i < reco_item.keyword().feature_size(); ++i) {
      std::cout << reco_item.keyword().feature(i).literal() << " ";
    }
    std::cout << std::endl;
  }
}

TEST_F(ConvertorTest, StockTest) {
  std::vector<TestCase> test_case;
  RawItem raw_item;
  raw_item.Clear();
  raw_item.set_content("　　周四市场呈现惊心动魄的过山车行情，早盘平稳窄幅震荡，却在午盘时因石油石化、银行板块跳水而下砸，最低冲破4650点。随后主力资金底部抢筹，直到收盘时，沪指站上4950点附近。从量能上看，昨日沪指小幅放量。分析认为，昨日行情应属庄家有意为之，原因在于庄家希望通过凶狠的洗盘动作，以极低成本获得不坚定的筹码以及赶走前期利润丰厚的融资盘，并趁机抬高散户持仓成本。今日，本周第一批打新资金解冻回归市场，庄家或将借此消息拉高出货。另外，冲破5000点后单边上涨或过度消耗主力做多意愿及实力，使牛市过快结束；也不符合管理层“牛市支持实体经济”构想。因此，今日市场或以高开后宽幅震荡为主。 ");  // NOLINT
  raw_item.set_title("早盘点评：沪指破5000点");
  raw_item.mutable_identity()->set_app_token("test");
  raw_item.mutable_identity()->set_item_id(1);
  raw_item.mutable_identity()->set_outer_id("test");
  raw_item.mutable_identity()->set_type(reco::kNews);
  raw_item.mutable_identity()->set_producer("uc");

  raw_item.set_is_valid(true);
  raw_item.set_source("zzd");
  raw_item.set_is_webview(true);
  raw_item.add_category("财经");
  raw_item.add_category("基金");

  test_case.push_back(TestCase("早盘点评：沪指破5000点", "2015-08-27 11:00:00", "", "2015-08-27 12:00:00"));
  test_case.push_back(TestCase("广发证券：寻求确定性是下半年最强主线", "2015-08-27 11:00:00", "", ""));
  test_case.push_back(TestCase("美股早盘点评：纳指破5000点", "2015-08-28 23:00:00", "", "2015-08-29 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("美股收盘点评：纳指破5000点", "2015-08-29 05:00:00", "", "2015-08-29 07:00:00"));  // NOLINT
  test_case.push_back(TestCase("纳指破5000点", "2015-08-31 03:00:00", "", "2015-08-31 05:00:00"));
  test_case.push_back(TestCase("石油板块行情很好", "2015-08-31 10:00:00", "", ""));
  test_case.push_back(TestCase("美股石油板块行情很好", "2015-08-31 10:00:00", "", ""));
  test_case.push_back(TestCase("2015年8月31日期市交易提示", "2015-08-31 10:00:00", "", "2015-09-01 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("今日312公司公布中报 52家业绩增幅翻倍", "2015-08-30 10:20:00", "", "2015-08-31 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("周末最新重磅公司传闻集锦（8月30日）", "2015-08-30 12:31:00", "", "2015-08-31 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("周末最新重磅公司传闻集锦（8.30日）", "2015-08-30 12:31:00", "", "2015-08-31 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("周末最新重磅公司传闻集锦（8/30日）", "2015-08-30 12:31:00", "", "2015-08-31 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("周末最新重磅公司传闻集锦(8/30)", "2015-08-30 12:31:00", "", "2015-08-31 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("周末最新重磅公司传闻集锦(8、30)", "2015-08-30 12:31:00", "", "2015-08-31 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("周末最新重磅公司传闻集锦(8.30)", "2015-08-30 12:31:00", "", "2015-08-31 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("周末最新重磅公司传闻集锦(8-30)", "2015-08-30 12:31:00", "", "2015-08-31 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("(2015-08-20)周累积换手率前二十只个股市场表现(截止8.25)", "2015-08-30 12:31:00", "", "2015-08-26 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("8.20投融资日周累积换手率前二十只个股市场表现", "2015-08-30 12:31:00", "", "2015-08-21 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("周末最新重磅公司传闻集锦（8.30）", "2015-08-30 12:31:00", "", "2015-08-31 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("我的持股跟踪和买股逻辑(2015、8、29)", "2015-08-29 12:31:00", "", "2015-08-30 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("周末最新重磅公司传闻集锦8-30", "2015-08-30 12:31:00", "", "2015-08-31 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("08月31日龙虎榜:主力资金连续三日抢筹个股名单一览", "2015-09-02 12:31:00", "", "2015-09-01 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("8 月 31日龙虎榜:主力资金连续三日抢筹个股名单一览", "2015-09-02 12:31:00", "", "2015-09-01 00:00:00"));  // NOLINT
  test_case.push_back(TestCase("国务院发文推进国内贸易流通现代化建设", "2015-08-30 12:31:00", "", ""));
  // test_case.push_back(TestCase("广州万隆午评：再度跳水释是重要不祥信号", "2015-08-31 11:55:00", "", "2015-08-31 14:00:00"));  // NOLINT
  test_case.push_back(TestCase("5大券商周二看好6板块28股", "2015-08-31 11:55:00", "", ""));
  // test_case.push_back(TestCase("午评:养老金入市提速 沪指涨近2%站上3100(组图)", "2015-08-28 19:31:11", "2015-08-28 20:01:11", "2015-08-28 14:00:00"));  // NOLINT
  test_case.push_back(TestCase("中国农产品（新）", "2015-08-28 19:31:11", "", ""));
  for (int i = 0; i < (int)test_case.size(); ++i) {
    raw_item.set_create_time(test_case[i].publish_time);
    raw_item.set_publish_time(test_case[i].publish_time);
    raw_item.set_expire_time("");
    raw_item.set_title(test_case[i].title);
    RecoItem reco_item;
    ASSERT_TRUE(raw_convertor_->ConvertToRecoItem(raw_item, &reco_item)) << i;
    ASSERT_EQ(reco_item.expire_time(), test_case[i].ans);
    for (int i = 0; i < reco_item.tag().feature_size(); ++i) {
      std::cout << reco_item.tag().feature(i).literal() << ":" << reco_item.tag().feature(i).weight();
      if (i != reco_item.tag().feature_size() - 1) {
        std::cout << ",";
      }
    }
    std::cout << std::endl;
  }
}

TEST_F(ConvertorTest, TestExtractAllFeature) {
  static struct {
    uint64 item_id;
    std::string attr_result;
  } cases[] = {
    {14604142931253295581ul, "00000020"},
    {3546912192067681831ul, "02000002"},
    {2308283589850069837ul, "000020022"},
    {8867703008036591005ul, "01000000"},
    {15243681283876193461ul, "00000020"},
    {12423145431606200538ul, "00000000"},
  };
  reco::HBaseGetItem get_item(FLAGS_hbase_table, 0);
  std::string result_str;
  for (int i = 0; i < (int)ARRAYSIZE_UNSAFE(cases); ++i) {
    reco::ContentAttr content_attr;
    result_str.clear();
    reco::RecoItem reco_item;
    if (!get_item.GetRecoItem(cases[i].item_id, &reco_item)) {
      LOG(ERROR) << "cannot get reco item\t" << cases[i].item_id;
      continue;
    }
    ASSERT_TRUE(raw_convertor_->ConvertToRecoItem(reco_item.raw_item(), &reco_item));

    // TODO(*): 补充其他字段的测试
    // test content attr
    result_str += base::IntToString(reco_item.content_attr().erro_title());
    result_str += base::IntToString(reco_item.content_attr().advertorial());
    result_str += base::IntToString(reco_item.content_attr().short_content());
    result_str += base::IntToString(reco_item.content_attr().dedup_paragraph());
    result_str += base::IntToString(reco_item.content_attr().dirty());
    result_str += base::IntToString(reco_item.content_attr().politics());
    result_str += base::IntToString(reco_item.content_attr().bluffing_title());
    result_str += base::IntToString(reco_item.content_attr().negative());
    if (reco_item.content_attr().sub_dirty_size() > 0) {
      for (int i = 0; i < (int)reco_item.content_attr().sub_dirty_size(); ++i) {
        result_str += base::IntToString(reco_item.content_attr().sub_dirty(i));
      }
    }
    ASSERT_EQ(cases[i].attr_result, result_str) << cases[i].item_id;
  }
}
}  // namespace reco
