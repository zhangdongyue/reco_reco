#include "reco/module/cdoc_convertor/convertor/util/convertor_util.h"

#include <vector>
#include <utility>

#include "base/common/base.h"
#include "base/testing/gtest.h"
#include "base/common/gflags.h"

namespace reco {
namespace cdoc_convertor {

class ProtobufTools: public ::testing::Test {
 protected:
  virtual void SetUp() {
    // 对 raw1 的各种类型字段都设置一下
    reco::ItemIdentity idt;
    idt.set_item_id(0);
    idt.set_type(reco::kNews);
    idt.set_app_token("uc");
    idt.set_outer_id("0");
    // messgae
    raw1.mutable_identity()->CopyFrom(idt);
    // bool
    raw1.set_is_valid(true);
    raw1.set_is_webview(false);
    // string
    raw1.set_source("source");
    raw1.set_title("title");
    raw1.set_content("content");
    raw1.set_create_time("1970-01-01 00:00:00");
    // message (enum)
    reco::VideoAttr video_attr;
    video_attr.set_vulgarlevel(reco::VideoAttr::kLowVulgar);
    video_attr.set_quality_level(reco::VideoAttr::kSuspectRubbish);
    raw1.mutable_video_attr()->CopyFrom(video_attr);
    // int32
    raw1.set_priority(1);
    // int64
    raw1.set_simhash(2);
    // repeated int64
    raw1.add_channel_id(100l);
    raw1.add_channel_id(200l);
    // repeated mesage
    reco::NewsImage image;
    image.set_url("http://www.baidu.com");
    raw1.add_image()->CopyFrom(image);
    image.set_url("http://www.taobao.com");
    raw1.add_image()->CopyFrom(image);
  }

  virtual void TearDown() {
  }

  reco::RawItem raw1;
};

TEST_F(ProtobufTools, CopyProtoFields) {
  reco::RecoItem reco1;
  reco::RawItem raw2;

  // 同类型 proto 拷贝，最终结果完全一样
  CopyProtoFields(raw1, &raw2);
  ASSERT_EQ(raw1.Utf8DebugString(), raw2.Utf8DebugString());

  // 不同类型 proto 拷贝，同名字段结果一样
  CopyProtoFields(raw1, &reco1);
  ASSERT_EQ(raw1.identity().Utf8DebugString(), reco1.identity().Utf8DebugString());
  std::vector<const char*> field_names;
  // 以下字段一直以 reco item 为准的， 直接比较
  field_names.push_back("identity");
  field_names.push_back("is_valid");
  field_names.push_back("is_webview");
  field_names.push_back("source");
  field_names.push_back("title");
  field_names.push_back("content");
  field_names.push_back("create_time");
  field_names.push_back("video_attr");
  field_names.push_back("priority");
  field_names.push_back("simhash");
  field_names.push_back("channel_id");
  field_names.push_back("image");
  std::string diff;
  ASSERT_TRUE(CompareMessage(raw1, reco1, &diff, &field_names));

  // 尝试修改一些字段以后再拷贝，应该完全覆盖
  // 普通的和 repeated 的字段都修改下
  raw2.CopyFrom(raw1);
  raw2.mutable_identity()->set_item_id(1111);
  reco::NewsImage image;
  image.set_url("http://www.tmall.com");
  raw2.add_image()->CopyFrom(image);
  CopyProtoFields(raw1, &raw2);
  ASSERT_EQ(raw1.Utf8DebugString(), raw2.Utf8DebugString());
}

TEST_F(ProtobufTools, MessageDiff) {
  reco::RawItem raw2;
  raw2.CopyFrom(raw1);
  std::string diff;
  ASSERT_TRUE(CompareMessage(raw1, raw2, &diff, NULL));

  raw2.set_title("title1");
  ASSERT_FALSE(CompareMessage(raw1, raw2, &diff, NULL));
  ASSERT_STREQ(diff.c_str(), "field [reco.RawItem.title] -> (title) .vs. (title1)");

  raw2.CopyFrom(raw1);
  reco::NewsImage image;
  image.set_url("http://www.tmall.com");
  raw2.add_image()->CopyFrom(image);
  ASSERT_FALSE(CompareMessage(raw1, raw2, &diff, NULL));
  ASSERT_STREQ(diff.c_str(), "repeated field [reco.RawItem.image] size not-match (2) .vs. (3)");

  raw2.CopyFrom(raw1);
  raw2.mutable_image(0)->CopyFrom(image);
  ASSERT_FALSE(CompareMessage(raw1, raw2, &diff, NULL));
  ASSERT_STREQ(diff.c_str(),
               "field [reco.NewsImage.url] -> (http://www.baidu.com) .vs. (http://www.tmall.com)");
}

TEST_F(ProtobufTools, RecoItemDiff) {
  reco::RecoItem reco1, reco2;
  reco1.mutable_identity()->CopyFrom(raw1.identity());
  reco1.set_is_valid(true);
  reco1.set_create_time("1970-01-01 00:00:00");
  reco1.set_title("title");
  reco1.set_content("content");
  reco1.set_source("source");
  reco1.add_show_tag("tag1");
  reco1.add_show_tag("tag2");

  reco2.CopyFrom(reco1);
  std::string diff;
  ASSERT_TRUE(CompareRecoItem(reco1, reco2, &diff));

  reco1.set_is_webview(true);
  reco2.clear_show_tag();
  reco2.mutable_raw_item()->CopyFrom(raw1);
  reco2.mutable_raw_item()->add_show_tag("tag1");
  reco2.mutable_raw_item()->add_show_tag("tag2");
  ASSERT_TRUE(CompareRecoItem(reco1, reco2, &diff)) << diff;

  // reco2.set_title("title1");
  // ASSERT_FALSE(CompareMessage(raw1, raw2, &diff, NULL));
  // ASSERT_STREQ(diff.c_str(), "field [title] -> (title) .vs. (title1)");

  // raw2.CopyFrom(raw1);
  // reco::NewsImage image;
  // image.set_url("http://www.tmall.com");
  // raw2.add_image()->CopyFrom(image);
  // ASSERT_FALSE(CompareMessage(raw1, raw2, &diff, NULL));
  // ASSERT_STREQ(diff.c_str(), "repeated field [image] size not-match (2) .vs. (3)");

  // raw2.CopyFrom(raw1);
  // raw2.mutable_image(0)->CopyFrom(image);
  // ASSERT_FALSE(CompareMessage(raw1, raw2, &diff, NULL));
  // ASSERT_STREQ(diff.c_str(), "field [url] -> (http://www.baidu.com) .vs. (http://www.tmall.com)");
  // LOG(ERROR) << diff;
}
}  // namespace convertor
}  // namespace reco
