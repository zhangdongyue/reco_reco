#include <string>
#include "reco/module/cdoc_convertor/convertor/util/rule_tree_realtime_detector.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"

namespace reco {

RuleTreeRealtimeDetector::RuleTreeRealtimeDetector() {
  rule_forest_ = new reco::cdoc_convertor::Forest(GlobalDataIns::instance().GetRealTimeRuleForest());
}

RuleTreeRealtimeDetector::~RuleTreeRealtimeDetector() {
}

bool RuleTreeRealtimeDetector::Detect(const reco::ItemIdentity& item_identity,
                                      const std::string& title,
                                      const std::string& content,
                                      const std::string& source,
                                      const std::string& category,
                                      const std::string& snd_category,
                                      const std::string& publish_time_str,
                                      std::string* expire_time_str) {
  int64 alive_time;
  if (rule_forest_->Match(item_identity,
                          title,
                          content,
                          source,
                          category,
                          snd_category,
                          publish_time_str,
                          &alive_time)) {
    base::Time publish_time;
    if (!base::Time::FromStringInSeconds(publish_time_str.c_str(), &publish_time)) {
      LOG(ERROR) << "Convert Publish: " << publish_time_str << " To Time Fail";
      return false;
    }
    base::Time expire_time = base::Time::FromDoubleT(publish_time.ToDoubleT() + alive_time * 60);
    expire_time.ToStringInSeconds(expire_time_str);
    LOG(INFO) << "[Expire Time DEBUG] item id: " << item_identity.item_id() << "\t"
              << "Title: " << title << "\t"
              << "item_type: " << item_identity.type() << "\t"
              << "publish: " << publish_time_str << "\t"
              << "set expire time: " << *expire_time_str;
    return true;
  } else {
    return false;
  }
}
}  // namespace reco
