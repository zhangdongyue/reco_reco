#pragma once

#include <string>
#include <vector>
#include "base/common/base.h"

#include "reco/module/cdoc_convertor/plda/document.h"
#include "reco/module/cdoc_convertor/plda/model.h"
#include "reco/module/cdoc_convertor/plda/inference_engine.h"
#include "reco/module/cdoc_convertor/plda/tokenizer.h"

namespace reco {
class LDAUtil {
 public:
  bool infer(ModelType model_type, std::string input, std::vector<Topic>& topics);
};
}
