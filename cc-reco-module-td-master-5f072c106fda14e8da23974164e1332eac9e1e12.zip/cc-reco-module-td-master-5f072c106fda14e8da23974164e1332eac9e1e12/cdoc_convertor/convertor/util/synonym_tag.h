#pragma once

#include <string>
#include <unordered_map>
#include <unordered_set>

#include "base/file/file_util.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"

namespace reco {
//
// 同义词模块，支持三种同义词。当前优先级依次降低，后续可能会改变
// 1. 上下文相关同义词：上下文为关键词
// 2. 上下文相关同义词：上下文为类别
// 3. 上下文无关同义词
//
// 同义词模块的词典，包括
// 1. 消岐词典：  着重语义上的一致，该词典中包含类别和关键词等上下文信息
// 2. 规范化词典：着重形式上的一致，所有人工运营添加的规范化标签自动成为上下文无关同义词对
class SynonymTag {
 public:
  SynonymTag();
  ~SynonymTag();

  // 如果有同义词，直接返回对应的同义词，如果没有，返回原字符串。
  // （一个词的同义词可能是其本身，例如湖人->湖人，湖人队->湖人）
  std::string GetSynonymTag(const std::string& tag, const std::string& category,
                            const std::unordered_set<std::string>& context_data);

 private:
};
}
