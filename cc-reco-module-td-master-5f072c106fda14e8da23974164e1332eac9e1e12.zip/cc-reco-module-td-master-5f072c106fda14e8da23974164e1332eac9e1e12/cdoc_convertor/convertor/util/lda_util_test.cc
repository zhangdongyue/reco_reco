#include "reco/module/cdoc_convertor/convertor/util/lda_util.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"

#include "base/testing/gtest.h"

namespace reco {
class LDAUtilTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    reco::GlobalDataIns::instance().Init();
  }

  virtual void TearDown() {
    delete lda_util_;
  }
  LDAUtil* lda_util_;
};
TEST_F(LDAUtilTest, LDAInferTest) {
  std::vector<std::string> test_cases;
  test_cases.push_back("日宣称半小时击沉中国航母? 中国回应了4个字");
  test_cases.push_back("景天科青锁龙属方鳞绿塔, 听着就很霸气的多肉");
  test_cases.push_back("洛阳一座古城, 千年帝都");
  test_cases.push_back("洛阳,位于中国河南省西部,丝绸之路东起点,有十省通衢之称");
  std::vector<Topic> topics;
  for (size_t i = 0; i < test_cases.size(); ++i) {
    topics.clear();
    ASSERT_TRUE(lda_util_->infer(ModelType::LDA, test_cases[i], topics));
    topics.clear();
    ASSERT_TRUE(lda_util_->infer(ModelType::SLDA, test_cases[i], topics));
  }
}
}

