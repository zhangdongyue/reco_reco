#pragma once

#include <string>
#include <utility>
#include <vector>

namespace net {
class WebClient;
}

namespace reco {

class MediaUpdator {
 public:
  explicit MediaUpdator();
  ~MediaUpdator();

  // 获得初始源对应的媒体。 这个接口不能用于获取种子源媒体
  // 目前种子源媒体从种子层面继承，不在这里更新
  bool GetOrigSourceMedia(int item_type, const char* url,
                          const char* source_name, const char* orig_source_name,
                          std::string* media);

  // 因为是 http 接口，测试接口逻辑是否符合预期
  bool test_ok();
 private:
  bool HttpRequest(int item_type, const char* url,
                   const char* source_name, const char* orig_source_name,
                   std::string* response);
  bool ParseResponse(const std::string& response, std::string* media);
  net::WebClient* http_client_;
};
}
