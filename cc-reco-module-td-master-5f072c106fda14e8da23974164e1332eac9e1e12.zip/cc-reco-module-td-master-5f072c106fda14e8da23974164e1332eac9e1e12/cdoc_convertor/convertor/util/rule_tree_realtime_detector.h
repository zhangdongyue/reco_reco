#pragma once
#include <string>
#include "reco/module/cdoc_convertor/rules_tree/forest.h"

namespace reco {
class RecoItem;

class RuleTreeRealtimeDetector {
 public:
  RuleTreeRealtimeDetector();
  ~RuleTreeRealtimeDetector();

  bool Detect(const reco::ItemIdentity& item_identity,
             const std::string& title,
             const std::string& content,
             const std::string& source,
             const std::string& category,
             const std::string& snd_category,
             const std::string& publish_time_str,
             std::string* expire_time_str);

 private:
  reco::cdoc_convertor::Forest* rule_forest_;
  DISALLOW_COPY_AND_ASSIGN(RuleTreeRealtimeDetector);
};

}  // namespace reco
