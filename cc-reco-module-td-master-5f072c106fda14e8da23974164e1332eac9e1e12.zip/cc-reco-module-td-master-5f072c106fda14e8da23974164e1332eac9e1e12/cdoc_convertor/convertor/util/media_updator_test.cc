#include "reco/module/cdoc_convertor/convertor/util/media_updator.h"

#include <iostream>
#include <vector>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/testing/gtest.h"
#include "nlp/common/nlp_util.h"

namespace reco {

class MediaUpdatorTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    media_updator_ = new MediaUpdator();
  }

  virtual void TearDown() {
    delete media_updator_;
  }

  MediaUpdator *media_updator_;
};

TEST_F(MediaUpdatorTest, Cases) {
  struct {
    bool ret;
    const char* url;
    const char* source;
    const char* orig_source;
    const char* media;
  } cases[] = {
    {true, "http://hebei.qq.com", "新浪网美体图片", "搜房网", "搜房网"},
    {true, "http://hebei.qq.com", "新浪网美体图片", "腾讯新闻", "腾讯网"},
    {false, "http://hebei.qq.com", "新浪网美体图片", NULL, ""},
    {false, "http://hebei.qq.com", "新浪网美体图片", "unknown", ""},
  };

  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(cases); ++i) {
    std::string media;
    ASSERT_EQ(cases[i].ret, media_updator_->GetOrigSourceMedia(1,
                                                               cases[i].url,
                                                               cases[i].source,
                                                               cases[i].orig_source,
                                                               &media));
    if (cases[i].ret) {
      ASSERT_STREQ(cases[i].media, media.c_str());
    }
  }
}
}
