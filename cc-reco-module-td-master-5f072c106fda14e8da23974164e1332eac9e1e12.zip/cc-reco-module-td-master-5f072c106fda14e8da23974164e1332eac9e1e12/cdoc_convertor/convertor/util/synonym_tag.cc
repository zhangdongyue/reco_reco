#include "reco/module/cdoc_convertor/convertor/util/synonym_tag.h"

#include <vector>

#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "nlp/common/nlp_util.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "reco/module/cdoc_convertor/tag/tag_normalize.h"

namespace reco {

SynonymTag::SynonymTag() {
}

SynonymTag::~SynonymTag() {
}

std::string SynonymTag::GetSynonymTag(const std::string& tag, const std::string& category,
                                      const std::unordered_set<std::string>& context_data) {
  auto synonym_tag_dict = GlobalDataIns::instance().GetSynTagDict();
  auto it = synonym_tag_dict->find(tag);
  if (it == synonym_tag_dict->end()) {
    // 4. 规范化词典作为上下无关同义词; 注意规范化的标签可能有大小写
    std::string normal_tag = TagNormalize::Instance().SearchNormalizeTag(tag);
    if (normal_tag != tag) {
      VLOG(1) << "synonym using normalize ! tag:" << tag;
      return nlp::util::NormalizeLine(normal_tag);
    }
    return tag;
  }

  // 1. 判断关键词上下文同义词
  if ((int)it->second.keyword_context_dict.size() > 0 && (int)context_data.size() > 0) {
    for (auto it_kw = it->second.keyword_context_dict.begin();
         it_kw != it->second.keyword_context_dict.end(); ++it_kw) {
      if (context_data.find(it_kw->first) != context_data.end()) {
        VLOG(1) << "KEYWORD SYNONYM !" << "[" << it_kw->first << "] "
                << tag << "-->" << it_kw->second;
        return it_kw->second;
      }
    }
  }

  // 2. 判断类别同义词
  if ((int)it->second.category_context_dict.size() > 0 && !category.empty()) {
    // 2.1 在指定的类别里查找
    auto it_cat = it->second.category_context_dict.find(category);
    if (it_cat != it->second.category_context_dict.end()) {
      VLOG(1) << "CATEGORY SYNONYM !" << "[" << category << "] "
              << tag << "-->" << it_cat->second;
      return it_cat->second;
    }

    // 2.2 查找 category 是否含有二级分类, 如果有二级类别，则在相应的一级类别里查找
    std::string first_category = "";
    std::string second_category = "";
    std::vector<std::string> fields;
    base::SplitString(category, ",", &fields);
    if ((int)fields.size() == 2 && !fields[0].empty() && !fields[1].empty()) {
      first_category = fields[0];
      second_category = fields[1];
    }

    if (!second_category.empty()) {
      it_cat = it->second.category_context_dict.find(first_category);
      if (it_cat != it->second.category_context_dict.end()) {
        VLOG(1) << "FIRST CATEGORY SYNONYM !" << "[" << first_category << "] "
                << tag << "-->" << it_cat->second;
        return it_cat->second;
      }
    }
  }

  // 3. 判断上下文无关同义词
  if (!it->second.context_free_result.empty()) {
    VLOG(1) << "CONTEXT FREE SYNONYM !" << "[ ] " << tag << "-->" << it->second.context_free_result;
    return it->second.context_free_result;
  }

  return tag;
}
}
