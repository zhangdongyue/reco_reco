#include "reco/module/cdoc_convertor/convertor/util/lda_util.h"

#include "serving_base/utility/timer.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"

namespace reco {

bool LDAUtil::infer(ModelType model_type, std::string input, std::vector<Topic>& topics) {
  std::vector<std::string> words;
  serving_base::Timer timer;
  timer.Start();
  const Tokenizer* tokenizer = GlobalDataIns::instance().GetLDATokenizer().get();
  tokenizer->tokenize(input, words);
  if (model_type == ModelType::LDA) {
    LDADoc doc;
    const InferenceEngine* lda_engine = GlobalDataIns::instance().GetLDAInferenceEngine().get();
    lda_engine->infer(words, doc);
    doc.sparse_topic_dist(topics);
  } else if (model_type == ModelType::SLDA) {
    std::vector<std::vector<std::string>> sentences;
    std::vector<std::string> sent;
    for (size_t i = 0; i < words.size(); ++i) {
      sent.push_back(words[i]);
      // 为了简化句子边界问题，以 5-gram 作为一个句子
      // 其中 n 不宜太大，否则会导致采样过程中数值计算精度下降
      if (sent.size() % 5 == 0) {
        sentences.push_back(sent);
        sent.clear();
      }
    }

    // 剩余单词作为一个句子
    if (sent.size() > 0) {
      sentences.push_back(sent);
    }

    SLDADoc doc;
    const InferenceEngine* slda_engine = GlobalDataIns::instance().GetSLDAInferenceEngine().get();
    slda_engine->infer(sentences, doc);
    doc.sparse_topic_dist(topics);
    sentences.clear();
  }
  return false;
}
}
