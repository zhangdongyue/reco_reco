#include "reco/module/cdoc_convertor/convertor/util/synonym_tag.h"

#include <utility>
#include <vector>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/testing/gtest.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"

namespace reco {
namespace cdoc_convertor {
class SynonymTagTest: public ::testing::Test {
 protected:
  virtual void SetUp() {
    GlobalDataIns::instance().Init();
    synonym_tag_ = new SynonymTag();
  }

  virtual void TearDown() {
    delete synonym_tag_;
  }

  SynonymTag *synonym_tag_;
};

TEST_F(SynonymTagTest, GetSynonymTag) {
  std::unordered_set<std::string> empty_context;
  // 上下文无关
  ASSERT_EQ(synonym_tag_->GetSynonymTag("周总理", "", empty_context), "周恩来");
  ASSERT_EQ(synonym_tag_->GetSynonymTag("周总理", "体育,nba", empty_context), "周恩来");
  ASSERT_EQ(synonym_tag_->GetSynonymTag("周总理", "xxx", empty_context), "周恩来");
  // 类别上下文: 词典中含有二级类别 : 鲁小胖 1 体育,国际足球 鲁尼
  ASSERT_EQ(synonym_tag_->GetSynonymTag("鲁小胖", "体育,国际足球", empty_context), "鲁尼");
  ASSERT_EQ(synonym_tag_->GetSynonymTag("鲁小胖", "体育", empty_context), "鲁小胖");
  ASSERT_EQ(synonym_tag_->GetSynonymTag("鲁小胖", "财经", empty_context), "鲁小胖");
  // 类别上下文: 词典中只有一级类别 : 星爷 1 娱乐 周星驰
  ASSERT_EQ(synonym_tag_->GetSynonymTag("星爷", "娱乐", empty_context), "周星驰");
  ASSERT_EQ(synonym_tag_->GetSynonymTag("星爷", "娱乐,综艺", empty_context), "周星驰");
  ASSERT_EQ(synonym_tag_->GetSynonymTag("星爷", "体育", empty_context), "星爷");

  // 关键词上下文: 绿城  2 杭州绿城|中超 杭州绿城
  // 绿城  1 体育  杭州绿城
  std::unordered_set<std::string> kw_context;
  kw_context.insert("中国");
  ASSERT_EQ(synonym_tag_->GetSynonymTag("绿城", "体育", kw_context), "杭州绿城");
  ASSERT_EQ(synonym_tag_->GetSynonymTag("绿城", "娱乐", kw_context), "绿城");
  kw_context.insert("中超");
  ASSERT_EQ(synonym_tag_->GetSynonymTag("绿城", "娱乐", kw_context), "杭州绿城");
  kw_context.clear();
  kw_context.insert("杭州绿城");
  ASSERT_EQ(synonym_tag_->GetSynonymTag("绿城", "娱乐", kw_context), "杭州绿城");

  // 来自规范化词典而不是同义词典的测试用例: 奶茶妹妹  章泽天
  ASSERT_EQ(synonym_tag_->GetSynonymTag("奶茶妹妹", "", empty_context), "章泽天");
}
}
}
