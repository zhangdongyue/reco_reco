#pragma once
#include <vector>
#include <string>

namespace net {
namespace rpc {
class RpcGroup;
}
}
namespace reco {
class RecoItem;

namespace item_classify {
class ItemClassifyService;
class ItemClassifyService_Stub;
}

class ItemClassifier {
 public:
  explicit ItemClassifier();
  ~ItemClassifier();

  void Classify(RecoItem* item, std::vector<std::string> *semantic_tags, std::string* hot_spam_str);

 private:
  static const std::string kEmptyCategory;
  // rpc
  net::rpc::RpcGroup* classify_channel_;
  // reco classify
  reco::item_classify::ItemClassifyService* classify_stub_;
};
}
