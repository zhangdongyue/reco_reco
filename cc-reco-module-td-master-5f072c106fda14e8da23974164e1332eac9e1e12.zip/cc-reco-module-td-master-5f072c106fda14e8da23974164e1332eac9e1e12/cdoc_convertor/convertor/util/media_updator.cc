#include "reco/module/cdoc_convertor/convertor/util/media_updator.h"

#include "base/encoding/url_encode.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "net/web_client/web_client.h"
#include "extend/json/jansson/jansson.h"

namespace reco {

// mirror http param
DEFINE_string(get_media_url, "http://11.180.58.198:20005/item/media/orig_source_media_name",
              "get media item server url");
DEFINE_int32(http_connect_timeout_ms, 4000, "");
DEFINE_int32(http_transfer_timeout_ms, 4000, "");

MediaUpdator::MediaUpdator() {
  net::WebClient::Options option;
  http_client_ = new net::WebClient(option);
  http_client_->Init();
}

MediaUpdator::~MediaUpdator() {
  delete http_client_;
}

bool MediaUpdator::test_ok() {
  // 保证一个 case 能够通过
  if (FLAGS_get_media_url.empty()) {
    return false;
  }

  std::string media;
  if (!GetOrigSourceMedia(1, "http://hebei.qq.com", "新浪网美体图片", "搜房网", &media)) {
    return false;
  }

  if (media != "搜房网") {
    return false;
  }

  return true;
}

bool MediaUpdator::GetOrigSourceMedia(int item_type, const char* url,
                                      const char* source_name, const char* orig_source_name,
                                      std::string* media) {
  std::string http_response;
  if (!HttpRequest(item_type, url, source_name, orig_source_name, &http_response)) {
    LOG(WARNING) << "http request for " << FLAGS_get_media_url << " failed";
    return false;
  }

  if (!ParseResponse(http_response, media)) {
    LOG(WARNING) << "parse json failed" << http_response;
    return false;
  }

  return true;
}

//  正常返回格式：{"status":0,"msg":"ok","data":"搜房网"}
//  或：{"status":0,"msg":"ok","data":{"mediaName":"搜房网","mediaType":1}}
//  非正常返回格式：{"status":1,"msg":"Cannot get suitable original source media name","data":null}
bool MediaUpdator::ParseResponse(const std::string& response, std::string* media) {
  json_error_t json_error;
  json_t *json = json_loads(response.c_str(), &json_error);
  if (json == NULL) {
    LOG(WARNING) << "parse json failed" << response;
    return false;
  }
  json_t *para = json_object_get(json, "status");
  if (para == NULL || para->type != JSON_INTEGER) {
    LOG(WARNING) << "json object has no status, json: " << response;
    return false;
  }
  int status = json_integer_value(para);
  if (status != 0) {
    LOG(WARNING) << "json status not 0";
    return false;
  }

  para = json_object_get(json, "data");
  if (para == NULL ||
      (para->type != JSON_STRING && para->type != JSON_OBJECT)) {
    LOG(WARNING) << "json object has no data, json: " << response;
    return false;
  }

  if (para->type == JSON_STRING) {
    *media = json_string_value(para);
  } else {
    json_t *name = json_object_get(para, "mediaName");
    if (name == NULL || name->type != JSON_STRING) {
      LOG(WARNING) << "json object has no mediaName, json: " << response;
      return false;
    }
    *media = json_string_value(name);
  }
  json_decref(json);

  return true;
}
bool MediaUpdator::HttpRequest(int item_type, const char* url,
                               const char* source_name, const char* orig_source_name,
                               std::string* response) {
  //  "http://11.180.58.198:20005/item/media/orig_source_media_name?itemUrl=http://hebei.qq.com&seedName=新浪网美体图片&origSource=搜房网&itemType=1"  // NOLINT
  net::WebClient::Request req;
  req.connect_timeout_in_ms = FLAGS_http_connect_timeout_ms;
  req.transfer_timeout_in_ms = FLAGS_http_transfer_timeout_ms;
  req.method = net::HTTPConstants::kGET;

  std::vector<std::string> kvs;
  kvs.reserve(4);
  kvs.push_back("itemType=" + base::IntToString(item_type));
  if (url != NULL) {
    kvs.push_back("itemUrl=" + base::EncodeUrlComponent(url));
    // kvs.push_back("itemUrl=" + std::string(url));
  }
  if (source_name != NULL) {
    kvs.push_back("seedName=" + base::EncodeUrlComponent(source_name));
    // kvs.push_back("seedName=" + std::string(source_name));
  }
  if (orig_source_name != NULL) {
    kvs.push_back("origSource=" + base::EncodeUrlComponent(orig_source_name));
    // kvs.push_back("origSource=" + std::string(orig_source_name));
  }

  req.url = FLAGS_get_media_url + "?" + base::JoinStrings(kvs, "&");

  net::WebClient::Response resp;
  http_client_->AddTask(&req, &resp, NULL);
  http_client_->JoinAll();

  if (resp.success && resp.http_response_code == net::HTTPStatusCode::kOK) {
    *response = resp.http_body;
    return true;
  } else {
    return false;
  }
}
}  // namespace reco
