#include "reco/module/cdoc_convertor/convertor/util/item_classifier.h"

#include <string>
#include <unordered_map>
#include <vector>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "nlp/common/nlp_util.h"
#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"

DEFINE_string(item_classify_server_ip, "100.85.69.71", "host of classify server");
DEFINE_int32(item_classify_server_port, 20004, "host of classify server");
DEFINE_int32(item_classify_timeout, 3000, "host of classify server");

namespace reco {
const std::string ItemClassifier::kEmptyCategory = "未分类";
ItemClassifier::ItemClassifier() {
  std::vector<std::string> ips;
  base::SplitString(FLAGS_item_classify_server_ip, ",", &ips);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 2;
  options.timeout = FLAGS_item_classify_timeout;
  for (int i = 0; i < (int)ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], FLAGS_item_classify_server_port, FLAGS_item_classify_timeout);
    options.servers.push_back(si);
  }

  classify_channel_ = new net::rpc::RpcGroup(options);
  CHECK(classify_channel_->Connect());
  classify_stub_ = new reco::item_classify::ItemClassifyService_Stub(classify_channel_);
}

ItemClassifier::~ItemClassifier() {
  delete classify_stub_;
  delete classify_channel_;
}

// for new interface : category candidates
static void AddCandidates(const reco::item_classify::ItemClassifyResponse& response, reco::RecoItem* item) {
  // set candidates, new flds
  if (item->identity().type() != reco::kPureVideo &&
      response.category_candidates_size() != response.score_size()) {
    LOG(ERROR) << "[FATAL] candidates and score not equal " << item->identity().item_id()
               << response.category_candidates_size() << " vs " << response.score_size();
    return;
  }

  std::unordered_map<std::string, int> level1_dict;
  item->mutable_multi_category()->Clear();

  auto multi_category = item->mutable_multi_category();
  for (int i = 0; i < response.category_candidates_size(); ++i) {
    std::string level1 = response.category_candidates(i);
    std::string level2 = "";
    size_t pos = level1.find(",");
    if (pos == std::string::npos) {
      pos = level1.find("\t");
    }

    if (pos != std::string::npos) {
      level2 = level1.substr(pos + 1);
      level1 = level1.substr(0, pos);
    }

    auto it_pair = level1_dict.insert(std::make_pair(level1, level1_dict.size()));
    if (it_pair.second) {
      auto category = multi_category->add_category_candidates();
      category->set_level1(level1);
      category->set_level1_score(response.score(i));
    }
    int idx = it_pair.first->second;
    if (!level2.empty()) {
      multi_category->mutable_category_candidates(idx)->add_level2(level2);
      multi_category->mutable_category_candidates(idx)->add_level2_score(response.score(i));
    }
  }
}

void ItemClassifier::Classify(RecoItem* item, std::vector<std::string> *semantic_tags,
    std::string* hot_spam_str) {
  //  运营新闻除未分类以外不走 分类服务
  if (item->identity().has_manual() && item->identity().manual() && item->category_size() >= 1 &&
      item->category(0) != "未分类")
    return;
  reco::item_classify::ItemClassifyResponse response;
  reco::item_classify::ItemClassifyRequest request;
  request.set_title(item->title());
  request.set_source(item->source());
  request.set_level(2);
  request.set_item_type(item->identity().type());

  // keyword
  for (int i = 0; i < item->keyword().feature_size(); ++i) {
    request.add_keywords(item->keyword().feature(i).literal());
  }

  // tag fea
  int tag_num = item->spider_tags().size();
  std::string norm_tag;
  for (int i = 0; i < tag_num; ++i) {
    nlp::util::NormalizeLineCopy(item->spider_tags(i), &norm_tag);
    request.add_tags(norm_tag);
  }

  // cut too long content
  if (item->content().size() < 3000) {
    request.set_content(item->content());
  } else {
    request.set_content(item->content().substr(0, 3000));
  }
  const reco::FeatureVector& title_lda = item->title_lda();
  auto topic_lda = request.mutable_title_lda_topic();

  topic_lda->set_norm(1.0);
  auto topic_lda_feature = topic_lda->mutable_feature();
  for (int j = 0; j < title_lda.feature_size(); ++j) {
    auto it = topic_lda_feature->Add();
    it->set_literal(title_lda.feature(j).literal());
    it->set_weight(title_lda.feature(j).weight());
    // LOG(INFO) << fea_topic.feature(j).literal()<<fea_topic.feature(j).weight();
  }
  for (int j = 0; j < item->paragraph_simhash_size(); ++j) {
    request.add_para_simhash(item->paragraph_simhash(j));
  }
  for (int j = 0; j < item->image_size(); ++j) {
    request.add_picture_simhash(item->image(j).simhash());
  }
  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(500);
  classify_stub_->ClassifyItem(&rpc, &request, &response, NULL);
  rpc.Wait();

  uint64 item_id = item->identity().item_id();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "get item category rpc failed. " << item_id << " "
        << request.title() << " " << request.source();
    return;
  }

  AddCandidates(response, item);

  if (item->category_size() == 0 && response.category_size() == 0) {  // fucking audio item
    LOG(INFO) << "set 未分类 for item: " << item->identity().item_id();
    item->add_category(kEmptyCategory);
  }

  // 如果新分类结果为未分类, 用未分类覆盖原分类结果
  if (response.category_size() == 0 || response.category(0).empty()) {
    std::string org_cate = item->category_size() > 0 ? item->category(0) : "";
    LOG(INFO) << "get empty category, item: " << item_id
              << ", org category: " << org_cate
              << ", request: " << request.title() << " source:" << request.source();
  }

  item->clear_category();
  for (int i = 0; i < response.category_size(); ++i) {
    if (response.category(i).empty()) break;
    item->add_category(response.category(i));
  }
  if (item->category_size() < 1) item->add_category(kEmptyCategory);

  std::string new_category = response.category_size() == 0 ? kEmptyCategory : response.category(0);
  if (response.category_size() > 1) {
    new_category += ",";
    new_category += response.category(1);
  }

  std::string orig_category = item->category_size() == 0 ? kEmptyCategory : item->category(0);
  if (item->category_size() > 1) {
    orig_category += ",";
    orig_category += item->category(1);
  }

  LOG(INFO) << "recalc item category, " << item_id << ", org category:" << orig_category
            << ", new category: " << new_category;

  // 返回可信的语义标签: 韦鹏建议:
  // 每篇文章至多返回 2 个语义标签，而且第二个语义标签不能低于第一个语义标签的 0.8 倍
  if (semantic_tags == NULL) return;
  if (response.tag_candidates_size() != response.tag_score_size()) return;
  static double kMinScore = 0.55;
  static const int kMaxTagCount = 10;
  static double kDiscount = 0.8;
  for (int i = 0; i < response.tag_candidates_size() && i < kMaxTagCount; ++i) {
    if (response.tag_score(i) >= kMinScore) {
      std::vector<std::string> cats;
      base::SplitString(response.tag_candidates(i), ",", &cats);
      if ((int)cats.size() != 2 || cats[1].empty()) continue;

      if (i > 0 && response.tag_score(i) <= response.tag_score(i-1) * kDiscount) {
        VLOG(1) << "tag_score discount filter fail !"
                << "[" << i - 1 << response.tag_candidates(i-1) << ", " << response.tag_score(i-1) << "], "
                << "[" << i     << response.tag_candidates(i)   << ", " << response.tag_score(i)   << "]";
        break;
      }

      VLOG(1) << "item_id:" << item_id << ", semantic_tag from classify server: "
              << response.tag_candidates(i) << ", score:" << response.tag_score(i)
              << ", real_tag:" << cats[1];
      semantic_tags->push_back(cats[1]);
    }
  }

  // 解析蹭热点结果
  if (hot_spam_str == NULL) return;
  if (response.post_tag_candidates_size() > 0) {
    *hot_spam_str = response.post_tag_candidates(0);
    VLOG(1) << "item_id:" << item_id << ", intention:" << *hot_spam_str;
  }
}
}
