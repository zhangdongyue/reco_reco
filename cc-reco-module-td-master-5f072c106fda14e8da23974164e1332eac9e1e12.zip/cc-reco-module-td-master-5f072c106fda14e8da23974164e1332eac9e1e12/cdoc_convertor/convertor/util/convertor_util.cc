#include "reco/module/cdoc_convertor/convertor/util/convertor_util.h"

#include <google/protobuf/message.h>
#include <google/protobuf/descriptor.h>
#include <string>
#include <set>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "nlp/common/nlp_util.h"
#include "nlp/common/term_info.h"
#include "extend/json/jansson/jansson.h"
#include "extend/regexp/re3/re3.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"

namespace reco {
bool postag_rule(int postag) {
  using namespace nlp::term;  // NOLINT
  static const int kPostagNum = 40;
  static int postag_set[kPostagNum];
  static int postag_blist[] = {
    kTime, kConjunction, kAdverb, kExclamation,
    kPosition, kPrefix, kNumber, kNumberQuantity,
    kPreposition, kQuantity, kPronoun, kAuxiliary, kPunctuation,
    kAdjective, kWhiteSpace
  };
  static bool first = true;
  // multi-thread not safe
  if (first) {
    memset(postag_set, 0, kPostagNum * sizeof(int));
    int num_of_blist = sizeof(postag_blist)/sizeof(int);
    for (int i = 0; i < num_of_blist; i++) {
      postag_set[postag_blist[i]] = 1;
    }
    first = false;
  }
  return (postag_set[postag] == 1);
}

bool entity_rule(int entity) {
  using namespace nlp::term;  // NOLINT
  static const int kEntityNum = 255;
  static int entity_set[kEntityNum];
  static int entity_blist[] = {
    kIdiom, kProductSN, kPhrase, kEntityOther, kBookSN,
    kVideoSN, kSoftwareVN,
  };
  static bool first = true;
  // multi-thread not safe
  if (first) {
    memset(entity_set, 0, kEntityNum * sizeof(int));
    int num_of_blist = sizeof(entity_blist)/sizeof(int);
    for (int i = 0; i < num_of_blist; i++) {
      entity_set[entity_blist[i]] = 1;
    }
    first = false;
  }
  return (entity_set[entity] == 1);
}

void RemoveHtmlTag(const std::string& old_string, std::string* new_string) {
  // 处理掉各种 http tag
  //  比如<!--IMG#0-->   <p> <!--VIDEO#0--> <!--IMG#0--> 等内容
  CHECK_NOTNULL(new_string);
  *new_string = old_string;
  extend::re3::Re3::GlobalReplace(new_string, "<[[:ascii:]]+>", " ");
}

void GetUCBSpecialContentIds(const reco::RecoItem& reco_item,
                             std::vector<std::string>* id_list) {
  id_list->clear();
  if (reco_item.identity().type() != reco::kSpecial
      && reco_item.identity().type() != reco::kWeMediaCard) {
    return;
  }

  const std::string& content = reco_item.content();

  json_error_t json_error;
  json_t *json = json_loads(content.c_str(), &json_error);
  if (json == NULL || json->type != JSON_ARRAY) {
    LOG(WARNING) << "Failed to load line: " << json_error.line;
    return;
  }

  uint64 id = 0;
  unsigned int size = json_array_size(json);
  for (unsigned int i = 0u; i < size; ++i) {
    json_t* obj = json_array_get(json, i);
    if (obj == NULL) {
      LOG(WARNING) << "content json error, json: " << content;
      continue;
    }
    json_t* article_json = json_object_get(obj, "id");
    if (article_json == NULL || article_json->type != JSON_STRING
        || !base::StringToUint64(json_string_value(article_json), &id)) {
      LOG(WARNING) << "content json error, json: " << content;
      continue;
    }
    id_list->push_back(json_string_value(article_json));
  }
}

bool IsTagManualChecked(const RecoItem& item) {
  if (item.identity().type() == kPureVideo &&
      item.has_has_reviewed() && item.has_reviewed()) {
    std::vector<std::string> tokens;
    for (int i = 0; item.has_tag() && i < item.tag().feature_size(); ++i) {
      const std::string &raw_tag = item.tag().feature(i).literal();
      base::SplitString(raw_tag, ":", &tokens);
      if (tokens.size() > 1 && tokens[0] == "manual") {
        return true;
      }
    }
  }
  return false;
}

bool ExtractRealTag(bool tag_manual_checked, const std::string& raw_tag, std::string* real_tag) {
  std::vector<std::string> tokens;
  base::SplitString(raw_tag, ":", &tokens);
  if (tokens.size() <= 1) {
    *real_tag = tokens[0];
  } else {
    *real_tag = tokens[1];
  }
  // 已经人工打标的事情，只用人工的结果
  if (tag_manual_checked && tokens[0] != "manual") {
    return false;
  }
  return !real_tag->empty();
}

bool CompareTimeStr(const std::string &lvalue, const std::string &rvalue) {
  if (lvalue.empty()) {
    return false;
  }

  if (rvalue.empty()) {
    return true;
  }

  base::Time ltime;
  if (base::Time::FromStringInSeconds(lvalue.c_str(), &ltime)) {
    base::Time rtime;
    if (base::Time::FromStringInSeconds(rvalue.c_str(), &rtime)) {
      return ltime < rtime;
    }
  }

  return true;
}

bool CopyProtoFields(const google::protobuf::Message& src, google::protobuf::Message* dest) {
  using namespace google::protobuf;  // NOLINT

  const Descriptor* src_descriptor = src.GetDescriptor();
  if (src_descriptor == NULL) {
    return false;
  }

  const Descriptor* dest_descriptor = dest->GetDescriptor();
  if (dest_descriptor == NULL) {
    return false;
  }

  const Reflection* src_reflection = src.GetReflection();
  if (src_reflection == NULL) {
    return false;
  }

  const Reflection* dest_reflection = dest->GetReflection();
  if (dest_reflection == NULL) {
    return false;
  }

  vector<const FieldDescriptor*> src_fields;
  src_reflection->ListFields(src, &src_fields);
  for (size_t i = 0; i < src_fields.size(); ++i) {
    const FieldDescriptor* src_field = src_fields[i];
    const std::string& name = src_field->lowercase_name();
    const FieldDescriptor* dest_field = dest_descriptor->FindFieldByLowercaseName(name);
    if (dest_field == NULL) {
      VLOG(1) << "reco item do not has field name " << name;
      continue;
    }

    bool is_repeated = src_field->is_repeated();
    if (is_repeated != dest_field->is_repeated()) {
      VLOG(1) << "reco and raw item repeated not match, field name " << name;
      continue;
    }

    FieldDescriptor::CppType cpp_type = src_field->cpp_type();
    if (cpp_type != dest_field->cpp_type()) {
      VLOG(1) << "reco and raw item field cpp type not match" << name;
      continue;
    }

    dest_reflection->ClearField(dest, dest_field);
    if (!is_repeated) {
      switch (cpp_type) {
        case FieldDescriptor::CPPTYPE_INT32:
          dest_reflection->SetInt32(dest, dest_field, src_reflection->GetInt32(src, src_field));
          break;
        case FieldDescriptor::CPPTYPE_INT64:
          dest_reflection->SetInt64(dest, dest_field, src_reflection->GetInt64(src, src_field));
          break;
        case FieldDescriptor::CPPTYPE_UINT32:
          dest_reflection->SetUInt32(dest, dest_field, src_reflection->GetUInt32(src, src_field));
          break;
        case FieldDescriptor::CPPTYPE_UINT64:
          dest_reflection->SetUInt64(dest, dest_field, src_reflection->GetUInt64(src, src_field));
          break;
        case FieldDescriptor::CPPTYPE_DOUBLE:
          dest_reflection->SetDouble(dest, dest_field, src_reflection->GetDouble(src, src_field));
          break;
        case FieldDescriptor::CPPTYPE_FLOAT:
          dest_reflection->SetFloat(dest, dest_field, src_reflection->GetFloat(src, src_field));
          break;
        case FieldDescriptor::CPPTYPE_BOOL:
          dest_reflection->SetBool(dest, dest_field, src_reflection->GetBool(src, src_field));
          break;
        case FieldDescriptor::CPPTYPE_ENUM:
          dest_reflection->SetEnum(dest, dest_field, src_reflection->GetEnum(src, src_field));
          break;
        case FieldDescriptor::CPPTYPE_STRING:
          dest_reflection->SetString(dest, dest_field, src_reflection->GetString(src, src_field));
          break;
        case FieldDescriptor::CPPTYPE_MESSAGE:
          dest_reflection->MutableMessage(dest, dest_field)->CopyFrom(
              src_reflection->GetMessage(src, src_field));
          break;
      }
    } else {  // repeated
      int repeated_size = src_reflection->FieldSize(src, src_field);
      for (int j = 0; j < repeated_size; ++j) {
        switch (cpp_type) {
          case FieldDescriptor::CPPTYPE_INT32:
            dest_reflection->AddInt32(dest, dest_field,
                                      src_reflection->GetRepeatedInt32(src, src_field, j));
            break;
          case FieldDescriptor::CPPTYPE_INT64:
            dest_reflection->AddInt64(dest, dest_field,
                                      src_reflection->GetRepeatedInt64(src, src_field, j));
            break;
          case FieldDescriptor::CPPTYPE_UINT32:
            dest_reflection->AddUInt32(dest, dest_field,
                                       src_reflection->GetRepeatedUInt32(src, src_field, j));
            break;
          case FieldDescriptor::CPPTYPE_UINT64:
            dest_reflection->AddUInt64(dest, dest_field,
                                       src_reflection->GetRepeatedUInt64(src, src_field, j));
            break;
          case FieldDescriptor::CPPTYPE_DOUBLE:
            dest_reflection->AddDouble(dest, dest_field,
                                       src_reflection->GetRepeatedDouble(src, src_field, j));
            break;
          case FieldDescriptor::CPPTYPE_FLOAT:
            dest_reflection->AddFloat(dest, dest_field,
                                      src_reflection->GetRepeatedFloat(src, src_field, j));
            break;
          case FieldDescriptor::CPPTYPE_BOOL:
            dest_reflection->AddBool(dest, dest_field,
                                     src_reflection->GetRepeatedBool(src, src_field, j));
            break;
          case FieldDescriptor::CPPTYPE_ENUM:
            dest_reflection->AddEnum(dest, dest_field,
                                     src_reflection->GetRepeatedEnum(src, src_field, j));
            break;
          case FieldDescriptor::CPPTYPE_STRING:
            dest_reflection->AddString(dest, dest_field,
                                       src_reflection->GetRepeatedString(src, src_field, j));
            break;
          case FieldDescriptor::CPPTYPE_MESSAGE:
            dest_reflection->AddMessage(dest, dest_field)->CopyFrom(
                src_reflection->GetRepeatedMessage(src, src_field, j));
            break;
        }
      }
    }
  }
  return true;
}

void generate_string_diff1(const std::string& parent, const std::string& field_name,
                          const std::string& t1, const std::string& t2, std::vector<std::string>* diffs) {
  if (t1 != t2) {
    std::stringstream ss;
    std::string name = field_name;
    if (!parent.empty()) {
      name = parent + "." + field_name;
    }

    if (parent == "reco.RawFeature" && field_name == "feature") {
      reco::sim_item::SimTermInfo info1;
      reco::sim_item::SimTermInfo info2;
      reco::sim_item::SimTermInfo::UnPackSimTermInfo(t1.c_str(), t1.size(), &info1);
      reco::sim_item::SimTermInfo::UnPackSimTermInfo(t2.c_str(), t2.size(), &info2);

      ss << "field [" << name << "] -> (" << info1.debug_str() << ") .vs. (" << info2.debug_str() << ")";
    } else {
      ss << "field [" << name << "] -> (" << t1 << ") .vs. (" << t2 << ")";
    }
    diffs->push_back(ss.str());
  }
}

bool CompareMessage(const google::protobuf::Message& msg1, const google::protobuf::Message& msg2,
                 std::string* diff_report, std::vector<const char*>* fields_to_compare) {
  using namespace google::protobuf;  // NOLINT

  std::vector<std::string> diffs;
  const std::string parent = msg1.GetTypeName();

  const Descriptor* descriptor1 = msg1.GetDescriptor();
  const Descriptor* descriptor2 = msg2.GetDescriptor();
  const Reflection* reflection1 = msg1.GetReflection();
  const Reflection* reflection2 = msg2.GetReflection();
  CHECK(descriptor1 != NULL && descriptor2 != NULL
        && reflection1 != NULL && reflection2 != NULL);

  std::vector<const FieldDescriptor*> fields;
  reflection1->ListFields(msg1, &fields);
  for (size_t i = 0; i < fields.size(); ++i) {
    const FieldDescriptor* field1 = fields[i];
    const std::string& name = field1->lowercase_name();
    if (fields_to_compare != NULL) {
      bool matched = false;
      for (size_t k = 0; k < fields_to_compare->size(); ++k) {
        if (base::LowerCaseEquals(name, fields_to_compare->at(k))) {
          matched = true;
          break;
        }
      }
      if (!matched) {
        continue;
      }
    }
    const FieldDescriptor* field2 = descriptor2->FindFieldByLowercaseName(name);
    if (field2 == NULL) {
      diffs.push_back("miss field [" + parent + "." + name + "]");
      continue;
    }

    bool is_repeated = field1->is_repeated();
    if (is_repeated != field2->is_repeated()) {
      diffs.push_back("miss repeated field [" + parent + "." + name + "]");
      continue;
    }

    FieldDescriptor::CppType cpp_type = field1->cpp_type();
    if (cpp_type != field2->cpp_type()) {
      diffs.push_back(base::StringPrintf("field [%s.%s] type not-match (%d) .vs. (%d)",
                                         parent.c_str(), name.c_str(), cpp_type, field2->cpp_type()));
      continue;
    }

    if (!is_repeated) {
      switch (cpp_type) {
        case FieldDescriptor::CPPTYPE_INT32:
          generate_string_diff(parent, name, reflection1->GetInt32(msg1, field1),
                               reflection2->GetInt32(msg2, field2), &diffs);
          break;
        case FieldDescriptor::CPPTYPE_INT64:
          generate_string_diff(parent, name, reflection1->GetInt64(msg1, field1),
                               reflection2->GetInt64(msg2, field2), &diffs);
          break;
        case FieldDescriptor::CPPTYPE_UINT32:
          generate_string_diff(parent, name, reflection1->GetUInt32(msg1, field1),
                               reflection2->GetUInt32(msg2, field2), &diffs);
          break;
        case FieldDescriptor::CPPTYPE_UINT64:
          generate_string_diff(parent, name, reflection1->GetUInt64(msg1, field1),
                               reflection2->GetUInt64(msg2, field2), &diffs);
          break;
        case FieldDescriptor::CPPTYPE_DOUBLE:
          generate_string_diff(parent, name, reflection1->GetDouble(msg1, field1),
                               reflection2->GetDouble(msg2, field2), &diffs);
          break;
        case FieldDescriptor::CPPTYPE_FLOAT:
          generate_string_diff(parent, name, reflection1->GetFloat(msg1, field1),
                               reflection2->GetFloat(msg2, field2), &diffs);
          break;
        case FieldDescriptor::CPPTYPE_BOOL:
          generate_string_diff(parent, name, reflection1->GetBool(msg1, field1),
                               reflection2->GetBool(msg2, field2), &diffs);
          break;
        case FieldDescriptor::CPPTYPE_ENUM:
          generate_string_diff(parent, name, reflection1->GetEnum(msg1, field1),
                               reflection2->GetEnum(msg2, field2), &diffs);
          break;
        case FieldDescriptor::CPPTYPE_STRING:
          generate_string_diff1(parent, name, reflection1->GetString(msg1, field1),
                               reflection2->GetString(msg2, field2), &diffs);
          break;
        case FieldDescriptor::CPPTYPE_MESSAGE:
          std::string msg_diff;
          if (!CompareMessage(reflection1->GetMessage(msg1, field1), reflection2->GetMessage(msg2, field2),
                              &msg_diff, NULL)) {
            diffs.push_back(msg_diff);
          }
          break;
      }
    } else {  // repeated
      int repeated_size1 = reflection1->FieldSize(msg1, field1);
      int repeated_size2 = reflection2->FieldSize(msg2, field2);
      if (repeated_size1 != repeated_size2) {
        diffs.push_back(base::StringPrintf("repeated field [%s.%s] size not-match (%d) .vs. (%d)",
                                         parent.c_str(), name.c_str(), repeated_size1, repeated_size2));
        continue;
      }

      for (int j = 0; j < repeated_size1; ++j) {
        switch (cpp_type) {
          case FieldDescriptor::CPPTYPE_INT32:
            generate_string_diff(parent, name, reflection1->GetRepeatedInt32(msg1, field1, j),
                                 reflection2->GetRepeatedInt32(msg2, field2, j), &diffs);
            break;
          case FieldDescriptor::CPPTYPE_INT64:
            generate_string_diff(parent, name, reflection1->GetRepeatedInt64(msg1, field1, j),
                                 reflection2->GetRepeatedInt64(msg2, field2, j), &diffs);
            break;
          case FieldDescriptor::CPPTYPE_UINT32:
            generate_string_diff(parent, name, reflection1->GetRepeatedUInt32(msg1, field1, j),
                                 reflection2->GetRepeatedUInt32(msg2, field2, j), &diffs);
            break;
          case FieldDescriptor::CPPTYPE_UINT64:
            generate_string_diff(parent, name, reflection1->GetRepeatedUInt64(msg1, field1, j),
                                 reflection2->GetRepeatedUInt64(msg2, field2, j), &diffs);
            break;
          case FieldDescriptor::CPPTYPE_DOUBLE:
            generate_string_diff(parent, name, reflection1->GetRepeatedDouble(msg1, field1, j),
                                 reflection2->GetRepeatedDouble(msg2, field2, j), &diffs);
            break;
          case FieldDescriptor::CPPTYPE_FLOAT:
            generate_string_diff(parent, name, reflection1->GetRepeatedFloat(msg1, field1, j),
                                 reflection2->GetRepeatedFloat(msg2, field2, j), &diffs);
            break;
          case FieldDescriptor::CPPTYPE_BOOL:
            generate_string_diff(parent, name, reflection1->GetRepeatedBool(msg1, field1, j),
                                 reflection2->GetRepeatedBool(msg2, field2, j), &diffs);
            break;
          case FieldDescriptor::CPPTYPE_ENUM:
            generate_string_diff(parent, name, reflection1->GetRepeatedEnum(msg1, field1, j),
                                 reflection2->GetRepeatedEnum(msg2, field2, j), &diffs);
            break;
          case FieldDescriptor::CPPTYPE_STRING:
            generate_string_diff1(parent, name, reflection1->GetRepeatedString(msg1, field1, j),
                                 reflection2->GetRepeatedString(msg2, field2, j), &diffs);
            break;
          case FieldDescriptor::CPPTYPE_MESSAGE:
            std::string msg_diff;
            if (!CompareMessage(reflection1->GetRepeatedMessage(msg1, field1, j),
                                reflection2->GetRepeatedMessage(msg2, field2, j),
                                &msg_diff, NULL)) {
              diffs.push_back(msg_diff);
            }
            break;
        }
      }
    }
  }

  *diff_report = base::JoinStrings(diffs, "; ");
  base::TrimWhitespaces(diff_report);
  return diffs.empty();
}

bool CompareRecoItem(const reco::RecoItem& item1, const reco::RecoItem& item2,
                     std::string* diff_report) {
  std::vector<std::string> diffs;
  std::string diff;
  std::vector<const char*> field_names;
  // 以下字段一直以 reco item 为准的， 直接比较
  field_names.push_back("identity");
  field_names.push_back("is_valid");
  field_names.push_back("expire_time");
  field_names.push_back("create_time");
  field_names.push_back("region");
  field_names.push_back("region_from_title");
  field_names.push_back("region_restrict");
  field_names.push_back("source");
  field_names.push_back("orig_source");
  field_names.push_back("source_media");
  field_names.push_back("orig_source_media");
  field_names.push_back("popularity");
  field_names.push_back("category");
  field_names.push_back("channel_id");
  field_names.push_back("keyword");
  field_names.push_back("topic");
  field_names.push_back("plsa_topic");
  field_names.push_back("wordvec");
  field_names.push_back("tag");
  field_names.push_back("subscripts");
  field_names.push_back("sim_feature");
  field_names.push_back("plas_topic");
  field_names.push_back("semantic_tag");
  field_names.push_back("synonymous_tags");
  field_names.push_back("multi_category");
  if (!CompareMessage(item1, item2, &diff, &field_names)) {
    diffs.push_back(diff);
  }

  field_names.clear();
  field_names.push_back("summary");
  field_names.push_back("show_tag");
  field_names.push_back("image");
  field_names.push_back("publish_time");
  field_names.push_back("content_attr");
  field_names.push_back("priority_info");
  field_names.push_back("simhash");
  field_names.push_back("paragraph_simhash");
  field_names.push_back("uc_browser_deliver_setting");
  field_names.push_back("uc_browser_display_setting");
  field_names.push_back("video_meta_settings");
  field_names.push_back("show_source");
  field_names.push_back("has_reviewed");
  field_names.push_back("appname_filters");
  field_names.push_back("filtered_app_names");
  field_names.push_back("quality_attr");
  field_names.push_back("content_attr");
  field_names.push_back("video_attr");
  field_names.push_back("gaode_poi");
  field_names.push_back("time_axis_results");
  field_names.push_back("video_storage_info");
  field_names.push_back("appname_filters");
  field_names.push_back("filtered_app_names");
  diff.clear();
  if (!CompareMessage(item1, item2, &diff, &field_names)) {
    diffs.push_back(diff);
  }

  bool item1_normalized = item1.has_normalized_title();
  bool item2_normalized = item2.has_normalized_title();
  if (item1_normalized) {
    if (item2_normalized) {
      generate_string_diff("reco::RecoItem", "title",
                           item1.normalized_title(), item2.normalized_title(), &diffs);
      generate_string_diff("reco::RecoItem", "content",
                           item1.normalized_content(), item2.normalized_content(), &diffs);
    } else {
      generate_string_diff("reco::RecoItem", "title",
                           item1.normalized_title(), item2.title(), &diffs);
      generate_string_diff("reco::RecoItem", "content",
                           item1.normalized_content(), item2.content(), &diffs);
    }
  } else {
    if (item2_normalized) {
      generate_string_diff("reco::RecoItem", "title",
                           item1.title(), item2.normalized_title(), &diffs);
      generate_string_diff("reco::RecoItem", "content",
                           item1.content(), item2.normalized_content(), &diffs);
    } else {
      generate_string_diff("reco::RecoItem", "title",
                           item1.title(), item2.title(), &diffs);
      generate_string_diff("reco::RecoItem", "content",
                           item1.content(), item2.content(), &diffs);
    }
  }

  *diff_report = base::JoinStrings(diffs, "; ");
  base::TrimWhitespaces(diff_report);
  return diffs.empty();
}

}  // namespace reco
