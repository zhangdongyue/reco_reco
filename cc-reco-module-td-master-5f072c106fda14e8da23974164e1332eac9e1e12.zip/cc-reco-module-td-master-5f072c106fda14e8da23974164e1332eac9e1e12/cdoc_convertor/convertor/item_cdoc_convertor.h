#pragma once

#include <vector>
#include <string>

#include "base/common/base.h"
#include "base/common/scoped_ptr.h"
#include "base/testing/gtest.h"

namespace adsindexing {
class CDocConvertor;
// 中间结构，转换过程是 RecoItem -> ConvertInfo -> IndexDocInfo
class ConvertInfo;
// 建库用的 cdoc
class IndexDocInfo;
class CustomerTermPayload;
}  // namespace adsindexing

namespace nlp {
namespace segment {
class Segmenter;
}
}

namespace reco {
class RecoItem;
class SubjectSubItems;

class ItemCDocConvertor {
 public:
  ItemCDocConvertor();
  ~ItemCDocConvertor();
  // 将 RecoItem 转换成建库所需的 cdoc
  bool ConvertToCDoc(const RecoItem &item, adsindexing::IndexDocInfo *cdoc);

  bool ConvertToHa3Doc(const RecoItem &item, std::string* doc);

  static const std::vector<std::string>& GetListeningFields() {
    static const std::vector<std::string> kListeningFields = {
      "identity", "is_valid", "create_time", "expire_time", "publish_time",
      "region", "region_from_title", "region_restrict", "gaode_poi",
      "title", "content", "source", "category", "channel_id",
      "orig_source", "source_media", "orig_source_media",
      "keyword", "topic", "tag", "wordvec", "plsa_topic",
      "semantic_tag", "synonymous_tags", "show_tag",
      "subscripts", "multi_category", "summary", "image", "spider_region",
      "priority_info", "simhash", "paragraph_simhash", "sim_feature", "popularity",
      "uc_browser_deliver_setting", "uc_browser_display_setting", "video_meta_settings",
      "show_source", "has_reviewed", "appname_filters", "filtered_app_names",
      "quality_attr", "content_attr", "video_attr", "time_axis_results",
      "video_storage_info", "event_tag_info", "risk_info", "dep_info", "item_group_info",
      "video_play_control", "offline_filter_rule"
    };
    return kListeningFields;
  }

 private:
  void GetZZDSpecialPreviewIds(const reco::RecoItem& reco_item, std::vector<std::string>* id_list);
  void GetZZDSpecialContentIds(const reco::RecoItem& reco_item, std::vector<std::string>* id_list);
  void GetZZDSubjectSubItems(const reco::RecoItem& reco_item, reco::SubjectSubItems* subject_sub_items);
  void GetOfflineFilterRule(const reco::RecoItem& reco_item, uint32* doc_mask,
                            adsindexing::ConvertInfo* convert_info);

 private:
  adsindexing::CDocConvertor *index_cdoc_convertor_;

  FRIEND_TEST(ConvertorTest, UCBItemTest);
  nlp::segment::Segmenter* segmenter_;

  DISALLOW_COPY_AND_ASSIGN(ItemCDocConvertor);
};
}  // namespace reco
