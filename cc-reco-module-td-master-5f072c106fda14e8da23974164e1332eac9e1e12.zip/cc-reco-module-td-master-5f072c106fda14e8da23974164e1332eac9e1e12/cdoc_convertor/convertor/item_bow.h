#pragma once
#include <set>
#include <string>
#include <vector>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <functional>

#include "base/common/basic_types.h"
#include "base/common/slice.h"
#include "base/common/logging.h"
#include "reco/bizc/proto/common.pb.h"
namespace nlp {
namespace term {
class TermContainer;
}
}

namespace reco {
namespace splice {
class RecoSplicer;
}
namespace ner {
class RecoNer;
}
class RecoItem;

struct InnerTagInfo {
  std::string tag;
  int   tf;  // 标题加权之后的 tf
  float tfidf;
  bool  intitle;
  int type;  // 默认为 0， tag 为人名，则该值为 1
  double first_norm_pos;  //位置信息
  double last_norm_pos;
  double spread;
  InnerTagInfo(const std::string& ptag, int ptf, float ptfidf, bool pintitle, int t) :
      tag(ptag), tf(ptf), tfidf(ptfidf), intitle(pintitle), type(t) {}
  InnerTagInfo() {}
};

class ItemBow {
 public:
  ItemBow();
  ~ItemBow();

  void clear() {
    basic_term_sign_.clear();
    entity_term_sign_.clear();
    tf_.clear();
    boost_level_.clear();
    reco_entity_dict_.clear();
    phrases_.clear();
    mix_term_num_ = 0;

    if (!heap_.empty()) {
      LOG(ERROR) << "keyword heap is not empty " << heap_.size();
      std::priority_queue<std::pair<double, std::string>, std::vector<std::pair<double, std::string> >,
          std::greater<std::pair<double, std::string>> > tmp_heap;
      heap_.swap(tmp_heap);
    }

    tf_.swap(std::unordered_map<uint64, int>());
    boost_level_.swap(std::unordered_map<uint64, int>());
    reco_entity_dict_.swap(std::unordered_map<uint64, base::Slice>());
  }

 public:
  // NOTE(all): call extract keywords before call extract tag
  bool ExtractKeywords(const std::string& content,
                       const std::string& title,
                       const nlp::term::TermContainer& container,
                       RecoItem* reco_item,
                       std::vector<InnerTagInfo>* tag_candidates);

  void AddSpecialTagCandidates(const std::string& content,
                               const std::string& title,
                               const nlp::term::TermContainer& container,
                               const std::string& category,
                               std::vector<InnerTagInfo>* tag_candidates);

  std::unordered_map<std::string, std::vector<std::pair<uint32, uint32> > >* GetTermPositionDict() {
    return &term_position_dict_;
  }
 private:
  void PreProcess(const std::string& content, const std::string& title,
                  const nlp::term::TermContainer& continer);

  void GenerateCandidates(const std::string& title,
                          const std::string& content,
                          const nlp::term::TermContainer& container,
                          const reco::ItemType& item_type,
                          std::vector<InnerTagInfo>* tag_candidates);

  double CalcTermImp(base::Slice term, uint64 term_sign, int tf, int postag, int term_type);

  void UpdateTermPosition(const std::string& term, uint32 begin, uint32 end);
 private:
  std::vector<uint64> basic_term_sign_;
  std::vector<uint64> entity_term_sign_;
  std::unordered_map<uint64, int> tf_;
  std::unordered_map<uint64, int> boost_level_;
  int mix_term_num_;

  std::unordered_map<uint64, base::Slice> reco_entity_dict_;
  std::unordered_map<std::string, double> phrases_;

  reco::splice::RecoSplicer* splicer_;
  reco::ner::RecoNer* reco_ner_;

  std::unordered_map<std::string, std::vector<std::pair<uint32, uint32> > > term_position_dict_;

  std::priority_queue<std::pair<double, std::string>,
      std::vector<std::pair<double, std::string> >, std::greater<std::pair<double, std::string>> > heap_;
};
}
