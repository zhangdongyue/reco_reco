#include "reco/module/cdoc_convertor/convertor/raw_item_convertor.h"

#include <cmath>
#include <algorithm>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <functional>

#include "base/hash_function/term.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/utf_string_conversions.h"
#include "base/time/time.h"
#include "nlp/segment/segmenter.h"
#include "nlp/common/nlp_util.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "nlp/plsa/pwz_dict.h"
#include "nlp/plsa/pzd_predictor.h"
#include "query/imp/imp.h"
#include "extend/regexp/re3/re3.h"
#include "serving_base/utility/timer.h"

#include "reco/bizc/common/appname_define.h"
#include "reco/bizc/reco_plsa/reco_plsa.h"
#include "reco/bizc/region/region_dict.h"
#include "reco/bizc/region/region_restrict.h"
#include "reco/bizc/sim_info/sim_info.h"
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/module/bad_item/strategy/rubbish_detector.h"
#include "reco/module/video_quality/strategy/video_rubbish_detector.h"
#include "reco/module/cdoc_convertor/tag/tag_normalize.h"
#include "reco/module/cdoc_convertor/convertor/util/convertor_util.h"
#include "reco/module/cdoc_convertor/convertor/util/item_classifier.h"
#include "reco/module/cdoc_convertor/convertor/util/rule_tree_realtime_detector.h"
#include "reco/module/cdoc_convertor/convertor/util/synonym_tag.h"
#include "reco/module/cdoc_convertor/convertor/util/media_updator.h"
#include "reco/module/cdoc_convertor/convertor/util/lda_util.h"
#include "reco/module/cdoc_convertor/convertor/item_bow.h"
#include "reco/module/cdoc_convertor/tag/tag_annotator.h"
#include "reco/module/cdoc_convertor/tag/tag_rule_match.h"

DECLARE_string(reco_data_dir);

DEFINE_int32(tag_term_num, 6, "");

DEFINE_int32(subject_lda_subitem_num, 10, "抽取主题LDA所用的子文的个数");

DEFINE_int32(subject_max_tag_num, 30, "主题抽取子文最大的标签数目");

DEFINE_bool(redo_classify, false, "switch for redo classification");

DEFINE_bool(print_debug_raw_item, false, "");

DEFINE_bool(open_new_plsa_predict, false, "是否开启新的 plsa 预估");

DEFINE_bool(title_match_switch, true, "标题匹配扩展");

DEFINE_string(reco_region_data_dir, "../data", "region related data dir");

DEFINE_bool(update_media, false, "更新源相关字段，单机版本不需要打开，线上再开启");
DEFINE_bool(same_show_switch, false, "图文和视频是否使用一套展示标签");

namespace reco {
const std::vector<std::string> RawItemConvertor::kListeningFields = {
    "identity", "is_valid", "create_time", "expire_time", "publish_time",
    "title", "content", "source", "orig_source", "category",
    "image", "spider_region", "spider_tags", "tag", "dep_info", "video_play_control"
};

const std::vector<std::string> RawItemConvertor::kUpdateFields = {
  "is_valid", "expire_time", "region", "region_from_title", "region_restrict",
  "category", "channel_id", "source_media", "orig_source_media", "title_unigram",
  "keyword", "topic", "tag", "wordvec", "plsa_topic", "sim_feature",
  "semantic_tag", "candidate_tag", "synonymous_tags", "show_tag",
  "multi_category", "content_attr", "normalized_title", "normalized_content", "offline_settings",
  "invalid_settings", "title_lda", "content_lda", "content_slda"
};
const std::unordered_set<int> RawItemConvertor::card_item_type_dict_
    = {reco::kSpecial, reco::kWeMediaCard, reco::kStockIndexCard, reco::kTopicCard, reco::kSportLiveCard,
      reco::kConstellation, reco::kStarCard};

RawItemConvertor::RawItemConvertor(const std::string& item_hbase_table,
                                   const reco::redis::RedisCli* redis_cli_) {
  segmenter_ = new nlp::segment::Segmenter;
  postagger_ = new nlp::postag::PosTagger;
  ner_ = new nlp::ner::Ner;
  pzd_predictor_ = new nlp::plsa::PzdPredictor;
  reco_plsa_predictor_ = new reco::RecoPlsa();
  imp_ = new queries::TermImp();
  rules_tree_detector_ = new reco::RuleTreeRealtimeDetector();
  region_recognition_ = new reco::common::RegionRecognition(FLAGS_reco_region_data_dir);

  // 加载地域限制词典
  CHECK(reco::common::RegionRestrictSearcher::instance().LoadDict(FLAGS_reco_region_data_dir));

  item_classifier_ = new ItemClassifier();
  rubbish_detector_ = new reco::bad_item::RubbishDetector(redis_cli_);
  video_rubbish_detector_ = new reco::VideoRubbishDetector(true);
  // TODO(xielang): tag 的逻辑和成员统一封装一个单独的类挪走
  tag_matcher_title_ = new TagMatch(FLAGS_reco_data_dir);
  synonym_searcher_ = new reco::SynonymTag();

  get_item_service_ = new reco::HBaseGetItem(item_hbase_table, 0);
  item_bow_ = new ItemBow();
  media_updator_ = new MediaUpdator();
  if (FLAGS_update_media) {
    CHECK(media_updator_->test_ok());
  }

  video_tag_annotator_ = new VideoTagAnnotator(FLAGS_reco_data_dir);
  manual_fields_ = NULL;
  video_summary_ = "";
}

RawItemConvertor::~RawItemConvertor() {
  delete item_classifier_;
  delete region_recognition_;
  delete segmenter_;
  delete postagger_;
  delete ner_;
  delete pzd_predictor_;
  delete rules_tree_detector_;
  delete reco_plsa_predictor_;
  delete synonym_searcher_;
  if (get_item_service_ != NULL) {
    delete get_item_service_;
    get_item_service_ = NULL;
  }
  delete item_bow_;
  delete media_updator_;
  delete video_tag_annotator_;
  delete rubbish_detector_;
  delete tag_matcher_title_;
  // delete lda_util_;
}

// TODO(*): mv to tag module
static bool ExtractBookNer(const std::string& content, const std::string& title,
                           const nlp::term::TermContainer& container,
                           std::set<std::string> *special_tags) {
  // 标题中是否含有书名号
  std::string book_prefix = "《";
  std::string book_suffix = "》";
  if (title.find(book_prefix) == std::string::npos ||
      title.find(book_suffix) == std::string::npos) {
    return false;
  }

  size_t title_len = title.length();
  std::string book = "";
  bool is_book_prefix = false;
  // 10 个 utf8 字符的最大长度
  const int BOOK_NER_LENGTH = 30;
  for (int j = 0; j < container.basic_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.basic_term_info(j);
    if (info.end > title_len) continue;

    std::string current_term = info.term(content).as_string();
    if (current_term == book_prefix) {
      is_book_prefix = true;
    } else if (current_term == book_suffix) {
      if (book != "" && (int)book.size() < BOOK_NER_LENGTH
          && (int)book.size() >= 2
          && special_tags->find(book) == special_tags->end()) {
        special_tags->insert(book);
        VLOG(1) << "ner-book:" << book;
      }
      book = "";
      is_book_prefix = false;
    } else if (is_book_prefix) {
      book.append(current_term);
    }
  }

  return true;
}

bool RawItemConvertor::UpdateRecoItem(RecoItem* reco_item,
                                      const std::vector<std::string>* manual_fields,
                                      const std::vector<RecoItem>* child_items) {
  item_id_ = reco_item->identity().item_id();
  item_type_ = reco_item->identity().type();
  producer_ = reco_item->identity().has_producer() ?
      reco_item->identity().producer() : reco_item->identity().app_token();
  manual_fields_ = manual_fields;
  child_items_ = child_items;

  reco_item->set_normalized_title(nlp::util::NormalizeLine(reco_item->title()));
  if (item_type_ == reco::kNews || item_type_ == reco::kReading || item_type_ == reco::kPicture) {
    std::string cleared_content;
    RemoveHtmlTag(reco_item->content(), &cleared_content);
    reco_item->set_normalized_content(nlp::util::NormalizeLine(cleared_content));
  } else {
    reco_item->set_normalized_content(reco_item->content());
  }

  // 特征信息抽取
  ExtractCfg cfg;
  ExtractItemFeatures(cfg, reco_item);
  SetExpireTime(reco_item);

  // 将最终得到的 proto Serialize 再 Parse 一下，这样没有设置的 require 字段会导致 check
  std::string serialized;
  CHECK(reco_item->IsInitialized())
      << "proto has required field not set, item id: " << item_id_
      << reco_item->InitializationErrorString();
  CHECK(reco_item->SerializeToString(&serialized)) << "proto can not serialize";
  reco::RecoItem another_item;
  CHECK(another_item.ParseFromString(serialized));
  return true;
}

// 时效性检测，会修改 item 的失效时间
void RawItemConvertor::SetExpireTime(reco::RecoItem* reco_item) {
  // NBA 屏蔽词检测，如果 title 命中屏蔽词，则把 item 失效，仅针对体育分类下的视频
  if (item_type_ == reco::kPureVideo && reco_item->category_size() > 0 && reco_item->category(0) == "体育") {
    // tag filter
    if (reco_item->has_tag()) {
      for (int i = 0; i < reco_item->tag().feature_size(); i++) {
        if (nlp::util::NormalizeLine(reco_item->tag().feature(i).literal()).find("nba") != std::string::npos) {
          reco_item->set_is_valid(false);
          reco_item->mutable_invalid_settings()->set_nba_black_term(true);

          LOG(INFO) << "SetExpireTime has nba tag, item_id:" << reco_item->identity().item_id();
          return;
        }
      }
    }

    // black term filter
    auto nba_black_term_dict = GlobalDataIns::instance().GetNbaBlackTermDict();
    std::vector<base::Slice> matches;
    std::vector<int> values;
    std::string nmlz_title = nlp::util::NormalizeLine(reco_item->title());
    int match = nlp::util::ForwardMaxMatch(*nba_black_term_dict, nmlz_title, &matches, &values);
    if (match > 0) {
      reco_item->set_expire_time("1970-01-01 00:00:00");
      reco_item->mutable_offline_settings()->set_nba_black_term(true);
      // expire time 可能会被运营覆盖，额外设置 is_valid=false
      reco_item->set_is_valid(false);
      reco_item->mutable_invalid_settings()->set_nba_black_term(true);

      LOG(INFO) << "SetExpireTime hit nba black term, item_id:" << reco_item->identity().item_id();
      return;
    }
  }

  if (reco_item->identity().has_manual() && reco_item->identity().manual() == true) {
    VLOG(1) << "not machine item, do not set expire time, item: " << item_id_;
    return;
  }

  if (item_type_ != reco::kNews && item_type_ != reco::kReading
      && item_type_ != reco::kPictureNews && item_type_ != reco::kPicture) {
    VLOG(1) << "not deal with item type, item: " << item_id_;
    return;
  }

  base::Time now = base::Time::Now();
  std::string now_str;
  now.ToStringInSeconds(&now_str);
  if (reco_item->has_expire_time() && reco_item->expire_time() < now_str) {
    VLOG(1) << "already expired, item: " << item_id_;
    return;
  }

  std::string publish_time_str = reco_item->has_publish_time() ?
      reco_item->publish_time() : reco_item->create_time();
  std::string expire_time_str;
  if (rules_tree_detector_->Detect(reco_item->identity(),
                                   reco_item->normalized_title(),
                                   reco_item->normalized_content(),
                                   reco_item->source(),
                                   reco_item->category_size() > 0 ? reco_item->category(0) : "",
                                   reco_item->category_size() > 1 ? reco_item->category(1) : "",
                                   publish_time_str,
                                   &expire_time_str)) {
    bool update_expire_time = true;
    if (reco_item->has_expire_time()) {
      base::Time expire_time;
      if (base::Time::FromStringInSeconds(reco_item->expire_time().c_str(), &expire_time)) {
        base::Time now = base::Time::Now();
        if (expire_time < now) update_expire_time = false;
      }
    }
    if (update_expire_time) {
      reco_item->set_expire_time(std::min(reco_item->expire_time(), expire_time_str, reco::CompareTimeStr));
    }
    reco_item->mutable_offline_settings()->set_timeline_miss(true);
  }
}

bool RawItemConvertor::ExtractItemFeatures(const ExtractCfg& cfg,
                                           const reco::ItemType& item_type,
                                           const std::string& title,
                                           const std::string& content,
                                           const std::string& source,
                                           const std::vector<std::string>& orig_categories,
                                           std::vector<std::string>* tags,
                                           std::vector<std::string>* keywords,
                                           std::vector<std::string>* bows,
                                           std::vector<std::string>* plsa,
                                           std::vector<std::string>* categories) {
  // construct reco item
  reco::RecoItem reco_item;
  reco::ItemIdentity* idt = reco_item.mutable_identity();
  idt->set_item_id(0);
  idt->set_type(item_type);
  idt->set_app_token("uc");
  idt->set_outer_id("0");

  reco_item.set_is_valid(true);
  reco_item.set_source(source);
  reco_item.set_title(title);
  reco_item.set_content(content);
  reco_item.set_is_webview(false);
  reco_item.set_create_time("1970-01-01 00:00:00");
  VectorToRepeated<std::string>(orig_categories, reco_item.mutable_category());

  // process base on reco item
  item_id_ = reco_item.identity().item_id();
  item_type_ = reco_item.identity().type();
  producer_ = reco_item.identity().has_producer() ?
      reco_item.identity().producer() : reco_item.identity().app_token();
  manual_fields_ = NULL;

  reco_item.set_normalized_title(nlp::util::NormalizeLine(reco_item.title()));
  if (item_type_ == reco::kNews || item_type_ == reco::kReading || item_type_ == reco::kPicture) {
    std::string cleared_content;
    RemoveHtmlTag(reco_item.content(), &cleared_content);
    reco_item.set_normalized_content(nlp::util::NormalizeLine(cleared_content));
  } else {
    reco_item.set_normalized_content(reco_item.content());
  }

  ExtractItemFeatures(cfg, &reco_item);
  if (cfg.extract_tag && reco_item.has_tag()) {
    for (int i = 0; i < reco_item.tag().feature_size(); i++) {
      tags->push_back(reco_item.tag().feature(i).literal());
    }
  }
  if (cfg.extract_tag && reco_item.has_semantic_tag()) {
    for (int i = 0; i < reco_item.semantic_tag().feature_size(); i++) {
      tags->push_back(reco_item.semantic_tag().feature(i).literal());
    }
  }

  if (cfg.extract_keyword && reco_item.has_keyword()) {
    for (int i = 0; i < reco_item.keyword().feature_size(); i++) {
      keywords->push_back(reco_item.keyword().feature(i).literal());
    }
  }

  if (cfg.extract_plsa && reco_item.has_plsa_topic()) {
    for (int i = 0; i < reco_item.plsa_topic().feature_size(); i++) {
      plsa->push_back(reco_item.plsa_topic().feature(i).literal());
    }
  }

  if (cfg.extract_category && reco_item.category_size() > 0) {
    RepeatedToVector<std::string>(reco_item.category(), categories);
  }
  return true;
}

bool RawItemConvertor::IsManualField(const std::string &f) {
  if (manual_fields_ != NULL) {
    for (size_t i = 0; i < manual_fields_->size(); ++i) {
      if (base::LowerCaseEquals((*manual_fields_)[i], f.c_str())) {
        return true;
      }
    }
  }
  return false;
}

std::string RawItemConvertor::ExtractVideoSummary(RecoItem* reco_item) {
  auto white_video_source_dict = GlobalDataIns::instance().GetWhiteVideoSourceDict();
  if (reco_item->has_orig_source()) {
    std::string orig_source = reco_item->orig_source();
    if (white_video_source_dict->find(orig_source) != white_video_source_dict->end()) {
      VLOG(1) << "in white video source list: " << orig_source;
      std::string summary = "";
      for (int i = 0; i < reco_item->video_meta_settings_size(); ++i) {
        if (reco_item->video_meta_settings(i).has_summary()) {
          summary += reco_item->video_meta_settings(i).summary();
        }
      }
      if (summary != "") {
        VLOG(1) << "video summary: " << summary;
        std::string nor_summary = nlp::util::NormalizeLine(summary);
        return nor_summary;
      }
    }
  }
  return "";
}

bool RawItemConvertor::MatchVideoSourceCategory(RecoItem* reco_item) {
  if (item_type_ != reco::kPureVideo) return false;

  std::string source = reco_item->source();
  if (reco_item->has_orig_source() && !reco_item->orig_source().empty()) {
    source = reco_item->orig_source();
  }
  if (source.empty()) return false;

  std::string first_category = reco_item->category_size() == 0 ? "" : reco_item->category(0);
  auto wemedia_source_dict = GlobalDataIns::instance().GetWemediaSourceDict();
  auto it_ws = wemedia_source_dict->find(source);
  if (it_ws != wemedia_source_dict->end() && it_ws->second.find(first_category) != it_ws->second.end()) {
    VLOG(1) << "match video source default categoy ! item_id:" << reco_item->identity().item_id()
        << ", category:" << first_category << ", source:" << source;
    return true;
  }
  return false;
}

void RawItemConvertor::ExtractItemFeatures(const ExtractCfg& cfg, RecoItem* reco_item) {
  serving_base::Timer timer;
  timer.Start();

  std::string nor_title = nlp::util::NormalizeLine(reco_item->normalized_title());
  std::string nor_content = nlp::util::NormalizeLine(reco_item->normalized_content());
  nor_content += nlp::util::NormalizeLine(MergeImageDesc(reco_item->image()));

  video_summary_ = "";
  if (item_type_ == reco::kPureVideo) {
    video_summary_ = ExtractVideoSummary(reco_item);
    nor_content = nor_content + " " + video_summary_;
    if (reco_item->has_converted_audio_text() && !reco_item->converted_audio_text().empty()) {
      // 语音转文本长度至少 60 个汉字长度
      const int AudioValidLength = 60 * 3;
      if ((int)reco_item->converted_audio_text().size() > AudioValidLength) {
        nor_content = nor_content + " " + reco_item->converted_audio_text();
      }
      VLOG(1) << "converted_audio_text:" << reco_item->converted_audio_text().size() / 3
              << ", content:" << reco_item->converted_audio_text();
    }
  }
  std::string str = nor_title + " " + nor_content;
  nlp::term::TermContainer container;

  CHECK(segmenter_->SegmentT(str, &container));
  CHECK(postagger_->PosTagT(str, &container));
  CHECK(ner_->DetectEntityT(str, &container));
  // 填充 title unigrams
  reco_item->clear_title_unigram();
  if (!nor_title.empty()) {
    int title_len = nor_title.length();
    for (int j = 0; j < container.basic_term_num(); ++j) {
      const nlp::term::TermInfo& info = container.basic_term_info(j);
      if ((int)info.end > title_len) break;
      reco_item->add_title_unigram(info.term(str).as_string());
    }
  }
  nlp::util::ConstructMixTerms(str, false, &container);
  LOG(INFO) << "item id:" << reco_item->identity().item_id()
      << ", extract feature prepare time:" << timer.Interval();

  ClearTags();
  // tag 抽取需要先抽 keyword
  reco_item->clear_keyword();
  item_bow_->ExtractKeywords(str, nor_title, container, reco_item, &tag_candidates_);
  LOG(INFO) << "item id:" << reco_item->identity().item_id() << ", extract keyword time:" << timer.Interval();

  if (cfg.extract_lda) {
    if (item_type_ == kThemeVideo) {
      ExtractThemeLDATopicFeature(nor_title, nor_content, reco_item);
    } else {
      ExtractLDATopicFeature(nor_title, nor_content, reco_item);
    }
    LOG(INFO) << "item id:" << reco_item->identity().item_id()
              << ", extarct lda topic time:" << timer.Interval();
  }
  // reset category
  bool category_is_manual = IsManualField("category");
  VLOG(1) << "category_is_manual:" << category_is_manual << ", item_id:" << reco_item->identity().item_id();
  if (!category_is_manual || reco_item->category_size() == 0) {
    item_classifier_->Classify(reco_item, &classified_tags_, &classified_hot_spam_);
  }
  LOG(INFO) << "item id:" << reco_item->identity().item_id() << ", classify time:" << timer.Interval();

  // 判断纯净视频源的默认类别与文章类别是否匹配
  video_source_category_match_ = MatchVideoSourceCategory(reco_item);

  // tag 抽取需要先执行 ExtractBowFeature
  if (cfg.extract_tag) {
    bool tag_is_manual = IsManualField("tag");
    VLOG(1) << "tag_is_manual:" << tag_is_manual << ", item_id:" << reco_item->identity().item_id();
    if (!tag_is_manual || !reco_item->has_tag() || reco_item->tag().feature_size() == 0) {
      item_bow_->AddSpecialTagCandidates(str, nor_title, container,
                                         reco_item->category_size() > 0 ? reco_item->category(0) : "未分类",
                                         &tag_candidates_);
      // 只负责提取书名实体，实际并没有加入到 tag 候选集合中
      // 如果一个 item 被识别为书名，但是没有以 basic/ner/reco ner/phrase 的方式加入候选，也不能识别为 tag
      ExtractBookNer(str, nor_title, container, &special_tags_);
      book_names_.insert(special_tags_.begin(), special_tags_.end());

      ExtractTags(reco_item, str, nor_title, nor_content, container);
    } else {
      LOG(INFO) << "using manual audit tag ! item_id:" << reco_item->identity().item_id();
    }
    // 标签统一规范化，如 iphone8 和 iphone 8 保持统一
    if (reco_item->has_tag()) {
      reco::FeatureVector nor_tag_fea;
      TagNormalize::Instance().NormalizeTag(reco_item->tag(), &nor_tag_fea);
      reco_item->mutable_tag()->CopyFrom(nor_tag_fea);
    }
  }
  LOG(INFO) << "item id:" << reco_item->identity().item_id() << ", extarct tag time:" << timer.Interval();

  // 选择最终展现给客户端的 tag
  if (item_type_ == reco::kPureVideo) {
    GenVideoShowTag(reco_item);
  } else {
    SelectFinalShowTagsNew(reco_item);
  }

  // topic 特征
  if (cfg.extract_plsa) {
    ExtractTopicFeature(str, container, reco_item);
    if (reco_item->category_size() > 0) {
      ExtractPlsaTopicFeature(reco_item->category(0), nor_title, nor_content, reco_item);
    }
  }
  LOG(INFO) << "item id:" << reco_item->identity().item_id()
      << ", extarct plsa topic time:" << timer.Interval();

  // NOTE(*): only depend on tag, keyword, category
  if (cfg.extract_rubbish) {
    reco::ContentAttr content_attr;
    rubbish_detector_->Detect(*reco_item, &content_attr);
    if (item_type_ == reco::kPureVideo) {
      reco::ContentAttr video_content_attr;
      video_rubbish_detector_->Detect(*reco_item, &video_content_attr);
      VLOG(1) << "video_detect result: " << video_content_attr.dirty();
      if (content_attr.has_video_dirty()) {
        video_content_attr.set_video_dirty(content_attr.video_dirty());
      }
      if (content_attr.has_video_dirty_status()) {
        video_content_attr.set_video_dirty_status(content_attr.video_dirty_status());
      }
      if (content_attr.has_bluffing_title()) {
        video_content_attr.set_bluffing_title(content_attr.bluffing_title());
      }
      if (content_attr.has_politics()) {
        video_content_attr.set_politics(content_attr.politics());
      }
      if (content_attr.has_negative()) {
        video_content_attr.set_negative(content_attr.negative());
      }
      reco_item->mutable_content_attr()->Swap(&video_content_attr);
    } else {
      reco_item->mutable_content_attr()->Swap(&content_attr);
    }
  }
  // 地域字段抽取: region
  ExtractRegion(str, nor_title.length(), container, reco_item);
  LOG(INFO) << "item id:" << reco_item->identity().item_id() << ", extarct region time:" << timer.Interval();

  // 设置地域限制
  SetRegionRestrict(str, nor_title.length(), reco_item);
  LOG(INFO) << "item id:" << reco_item->identity().item_id() << ", restrict region time:" << timer.Interval();

  // NOTE: 顺序不能反，后加入的 term doc feature 有效
  reco_item->clear_sim_feature();
  ExtractOtherTermDocFeature(reco_item);
  ExtractBidwordTermDocFeature(reco_item);
  ExtractTitleTermDocFeature(str, nor_title.length(), container, reco_item);
  LOG(INFO) << "item id:" << reco_item->identity().item_id()
      << ", extarct other feature time:" << timer.Interval();
}

bool RawItemConvertor::ExtractTags(RecoItem* reco_item,
                                   std::string& str, std::string& nor_title, std::string& nor_content,
                                   const nlp::term::TermContainer& container) {
  reco_item->clear_tag();
  reco_item->clear_candidate_tag();
  reco_item->clear_synonymous_tags();
  reco_item->clear_semantic_tag();

  // 如果是视频，则进入视频标签流程
  if ((item_type_ == kPureVideo || item_type_ == kThemeVideo) && reco_item->category_size() >= 1) {
    std::string orig_source = "";
    if (reco_item->has_orig_source() && !reco_item->orig_source().empty()) {
      orig_source = reco_item->orig_source();
    }
    ExtractVideoTagFeature(reco_item->source(), orig_source, reco_item->category(0), nor_title);
  }

  if (producer_ == reco::common::kUCBProducer && item_type_ == reco::kSpecial) {
    ExtractSpecialTagFeature(reco_item);
  } else if (item_type_ == kThemeVideo) {
    ExtractTagFeature(str, nor_title, container, reco_item);
    // ExtractSemanticTag(str, nor_title, nor_content, container, reco_item);
    ExtractThemeTagFeature(reco_item);
  } else {
    // tag 特征
    ExtractTagFeature(str, nor_title, container, reco_item);
    ExtractSemanticTag(str, nor_title, nor_content, container, reco_item);
  }

  // 设置地域限制
  // SetRegionRestrict(str, nor_title.length(), reco_item);

  return true;
}

bool RawItemConvertor::MeetTagExtractCondition(const std::string &producer,
                                               const reco::ItemType &item_type,
                                               const int &raw_item_tags_size) {
  if (producer == reco::common::kZZDProducer || producer == reco::common::kZZDOpProducer) {
    return true;
  } else if (producer == reco::common::kUCBProducer) {
    if (item_type == reco::kNews ||
        item_type == reco::kReading ||
        item_type == reco::kPictureNews ||
        item_type == kPureVideo) {
      return true;
    } else if (item_type == reco::kPicture) {
      if (raw_item_tags_size > 0) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  }
  return false;
}

std::string RawItemConvertor::MergeImageDesc(const google::protobuf::RepeatedPtrField<reco::NewsImage>& image) {  // NOLINT
  std::string out_tags = "";
  for (int i = 0; i < image.size(); ++i) {
    const reco::NewsImage& img = image.Get(i);
    if (img.has_desc() && !img.desc().empty()) {
      std::string desc = nlp::util::NormalizeLine(img.desc());
      // 从 desc 中去掉设计图片来源及拍摄者等附着在描述信息后面的内容
      // 比如 " 米级钢箱梁悬索桥。新华社记者 刘潺 摄"
      // 这里利用中文标点的使用规范来解这个问题 GB/T 15834-2011
      size_t pos = desc.rfind("。");
      if (pos != std::string::npos) {
        desc = desc.substr(0, pos);
      }
      out_tags += desc;
      VLOG(1) << "image i:" << i << ", desc:" << desc;
    }
  }
  return out_tags;
}

void RawItemConvertor::ExtractPlsaTopicFeature(const std::string& category,
                                               const std::string& title,
                                               const std::string& content,
                                               RecoItem* item) {
  reco::ItemType item_type = item->identity().type();
  if (!FLAGS_open_new_plsa_predict
      || category.empty()
      || title.empty()
      || item_type == reco::kHumor
      || card_item_type_dict_.find(item_type) != card_item_type_dict_.end()) {
    return;
  }

  uint64 item_id = item->identity().item_id();
  std::vector<nlp::plsa::Topic> pzd;
  if (!reco_plsa_predictor_->PredictPzd(category, title, content, &pzd)) {
    LOG(WARNING) << "do reco plsa predict fail, item: " << item_id <<  ", " << item_type;
    return;
  }

  double org_sum_weight = 0;
  for (size_t i = 0; i < pzd.size(); ++i) {
    org_sum_weight += pzd[i].value;
  }
  if (org_sum_weight < 1e-6) return;

  // TODO(jianhuang) 看分布进行调整
  const double kFilterWeightThres = 1.0 / pzd.size();
  double sum_weight = 0;
  std::unordered_set<size_t> filter_idx_set;
  for (size_t i = 0; i < pzd.size(); ++i) {
    if (pzd[i].value / org_sum_weight < kFilterWeightThres) {
      filter_idx_set.insert(i);
      continue;
    }
    sum_weight += pzd[i].value;
  }
  if (sum_weight < 1e-6) return;

  double norm2 = 0.0;
  std::map<uint64, reco::Feature> features;
  for (size_t i = 0; i < pzd.size(); ++i) {
    if (filter_idx_set.find(i) != filter_idx_set.end()) continue;
    const std::string& fea = base::StringPrintf("topic-%d", pzd[i].aspect);
    uint64 fea_sign = base::CalcTermSign(fea.c_str(), fea.size());
    pzd[i].value /= sum_weight;
    reco::Feature current_fea;
    current_fea.set_category(category);
    current_fea.set_weight(pzd[i].value);
    current_fea.set_literal(fea);
    norm2 += pzd[i].value * pzd[i].value;
    features[fea_sign] = current_fea;
  }
  item->clear_plsa_topic();
  auto feature_vector = item->mutable_plsa_topic();
  for (auto it = features.begin(); it != features.end(); ++it) {
    feature_vector->add_feature()->CopyFrom(it->second);
  }
  feature_vector->set_norm(sqrt(norm2));
}

void RawItemConvertor::ExtractTopicFeature(const std::string& str,
                                           const nlp::term::TermContainer& container,
                                           RecoItem* item) {
  std::vector<nlp::plsa::PredictInputT> plsa_input(1);
  std::vector<nlp::plsa::Topic> pzd;
  // std::vector<std::string> debug_str;
  plsa_input.back().text = str;
  plsa_input.back().term_container = &container;
  plsa_input.back().source = 2;
  pzd.clear();
  if (str == "") {
    LOG(WARNING) << "Input contain no term";
    return;
  }
  if (!pzd_predictor_->PredictPzdT(plsa_input, &pzd)) {
    // LOG(WARNING) << "Failed to calculate pzd";
    return;
  }
  double org_sum_weight = 0;
  for (size_t i = 0; i < pzd.size(); ++i) {
    org_sum_weight += pzd[i].value;
  }
  if (org_sum_weight < 1e-6) return;

  const double kFilterWeightThres = 1.0 / pzd.size();
  double sum_weight = 0;
  std::unordered_set<size_t> filter_idx_set;
  for (size_t i = 0; i < pzd.size(); ++i) {
    if (pzd[i].value / org_sum_weight < kFilterWeightThres) {
      filter_idx_set.insert(i);
      continue;
    }
    sum_weight += pzd[i].value;
  }
  if (sum_weight < 1e-6) return;

  double norm2 = 0.0;
  std::map<uint64, reco::Feature> features;
  for (size_t i = 0; i < pzd.size(); ++i) {
    if (filter_idx_set.find(i) != filter_idx_set.end()) continue;
    std::string fea = base::StringPrintf("topic-%d", pzd[i].aspect);
    reco::Feature current_fea;
    uint64 fea_sign = base::CalcTermSign(fea.c_str(), fea.size());
    pzd[i].value /= sum_weight;
    current_fea.set_weight(pzd[i].value);
    current_fea.set_literal(fea);
    norm2 += pzd[i].value * pzd[i].value;
    features[fea_sign] = current_fea;
    // debug_str.push_back(base::StringPrintf("%s:%g", fea.c_str(),  pzd[i].value));
  }
  item->clear_topic();
  auto feature_vector = item->mutable_topic();
  for (auto it = features.begin(); it != features.end(); ++it) {
    feature_vector->add_feature()->CopyFrom(it->second);
  }
  feature_vector->set_norm(sqrt(norm2));
}

std::string RawItemConvertor::GetSynonymWords(const std::string& word, const std::string &category,
                                              const std::unordered_set<std::string>& context_data) {
  auto title_synonym_dict = GlobalDataIns::instance().GetTitleSynDict();
  std::string ret = synonym_searcher_->GetSynonymTag(word, category, context_data);
  if (ret != word) {
    return ret;
  } else {
    auto it = title_synonym_dict->find(word);
    return (it != title_synonym_dict->end()) ? it->second : "";
  }
  return "";
}

void RawItemConvertor::NormalizeTags(RecoItem *item) {
  // 获取分类信息。对于视频文章，某些类别会映射到文本的分类体系上
  std::string first_category = item->category_size() == 0 ? "" : item->category(0);
  std::string second_category = item->category_size() <= 1 ? "" : item->category(1);
  if (item_type_ == kPureVideo) {
    std::string text_category1;
    std::string text_category2;
    if (CategoryMapping(first_category, second_category, &text_category1, &text_category2)) {
      first_category = text_category1;
      second_category = text_category2;
      VLOG(1) << "mapping category:" << "new first category:" << first_category;
    }
  }
  // 组合一级和二级类别，用于查找同义词
  std::string detail_category = "";
  if (item->category_size() > 1) {
    detail_category = first_category + ',' + second_category;
  } else if (item->category_size() == 1) {
    detail_category = first_category;
  }

  // 归一化词条处理
  bool changed = false;
  // 去掉首尾空格
  std::unordered_set<std::string> context_data;
  for (size_t i = 0; i < tag_candidates_.size(); ++i) {
    base::TrimWhitespaces(&tag_candidates_[i].tag);
    context_data.insert(tag_candidates_[i].tag);
  }

  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    if (tag_candidates_[i].tf == -1) continue;

    // 如果当前 tag 在归一化词典中，则查找候选是否同时有原 tag 和归一后 tag
    // 如果同时有原 tag 和归一化 tag，则合并 tf 和 tfidf 等信息
    // 否则修改当前 tag
    std::string nor_tag = GetSynonymWords(tag_candidates_[i].tag, detail_category, context_data);
    if (nor_tag != "") {
      LOG(INFO) << "SYNONYM WORDS: detail_category: [" << detail_category<< "], "
                << tag_candidates_[i].tag << " --> " << nor_tag;

      // 存储同义词的原标签
      auto it_synonym_tag = synonym_source_words_.find(nor_tag);
      if (it_synonym_tag == synonym_source_words_.end()) {
        synonym_source_words_.insert(std::make_pair(nor_tag, tag_candidates_[i].tag));
      }
      // 存储到书名列表
      if (book_names_.find(tag_candidates_[i].tag) != book_names_.end()) {
        book_names_.insert(nor_tag);
      }

      changed = true;
      bool has_nor_tag = false;
      for (int j = 0; j < (int)tag_candidates_.size(); ++j) {
        if (tag_candidates_[j].tf == -1) continue;
        if (j != i && nor_tag == tag_candidates_[j].tag) {  // 同时有原 tag 和归一化 tag
          has_nor_tag = true;
          tag_candidates_[j].tf += tag_candidates_[i].tf;
          tag_candidates_[j].tfidf += tag_candidates_[i].tfidf;
          tag_candidates_[j].intitle = (tag_candidates_[j].intitle || tag_candidates_[i].intitle);
          if (tag_candidates_[i].type == 1) {
            tag_candidates_[j].type = 1;
          }
          tag_candidates_[j].first_norm_pos = std::min(tag_candidates_[i].first_norm_pos,
                                                       tag_candidates_[j].first_norm_pos);
          tag_candidates_[j].last_norm_pos = std::max(tag_candidates_[i].last_norm_pos,
                                                      tag_candidates_[j].last_norm_pos);
          tag_candidates_[j].spread = std::max(0.0, tag_candidates_[j].last_norm_pos
                                               - tag_candidates_[j].first_norm_pos);
          // 设置原标签为无效标签
          tag_candidates_[i].tf = -1;
          break;
        }
      }
      // 更新同义词的段落频次
      UpdateSynonymPF(tag_candidates_[i].tag, nor_tag);
      if (!has_nor_tag) {  // 只有原 tag
        tag_candidates_[i].tag = nor_tag;
      }
    }
  }
  if (changed) {
    std::vector<InnerTagInfo> tag_candidates_tmp;
    for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
      if (tag_candidates_[i].tf != -1) {
        tag_candidates_tmp.push_back(tag_candidates_[i]);
      }
    }

    tag_candidates_.clear();
    for (int i = 0; i < (int)tag_candidates_tmp.size(); ++i) {
      tag_candidates_.push_back(tag_candidates_tmp[i]);
    }
  }
}

void RawItemConvertor::DeleteSubTags(std::vector<std::pair<std::string, float> > *key_terms) {
  if (key_terms == NULL || key_terms->size() <= 1) return;

  std::vector<SortTagInfo> tag_candidates_tmp;
  for (int i = 0; i < (int)key_terms->size(); ++i) {
    tag_candidates_tmp.push_back(SortTagInfo(i, (*key_terms)[i].first.size()));
  }
  // 按照长度降序排序
  std::sort(tag_candidates_tmp.begin(), tag_candidates_tmp.end(), RawItemConvertor::TagLengthCmp);

  // 查找子 tag，并设置对应 index 为 -1
  bool deleted = false;
  for (int i = 0; i < (int)tag_candidates_tmp.size(); ++i) {
    if (tag_candidates_tmp[i].index == -1) continue;
    // 当前 tag 和最后一个 tag 的长度相同，则肯定不是子串，直接 break
    if (tag_candidates_tmp[i].length == tag_candidates_tmp[tag_candidates_tmp.size() - 1].length) break;
    std::string &i_tag = (*key_terms)[tag_candidates_tmp[i].index].first;
    for (int j = i + 1; j < (int)tag_candidates_tmp.size(); ++j) {
      if (tag_candidates_tmp[j].index == -1) continue;
      std::string &j_tag = (*key_terms)[tag_candidates_tmp[j].index].first;
      if (i_tag.find(j_tag) != std::string::npos) {
        VLOG(1) << "deletes sub tags ! tag:" << j_tag;
        tag_candidates_tmp[j].index = -1;
        deleted = true;
      }
    }
  }

  // 删除子 tag
  if (deleted) {
    std::vector<std::pair<std::string, float> > new_candidates;
    for (int i = 0; i < (int)tag_candidates_tmp.size(); ++i) {
      if (tag_candidates_tmp[i].index == -1) {
        continue;
      }
      new_candidates.push_back((*key_terms)[tag_candidates_tmp[i].index]);
    }

    key_terms->clear();
    for (int i = 0; i < (int)new_candidates.size(); ++i) {
      key_terms->push_back(new_candidates[i]);
    }
  }
}

void RawItemConvertor::DeleteSubSemanticTags(std::vector<std::string> *key_terms) {
  if (key_terms == NULL || key_terms->size() <= 1) return;

  std::vector<SortTagInfo> tag_candidates_tmp;
  for (int i = 0; i < (int)key_terms->size(); ++i) {
    tag_candidates_tmp.push_back(SortTagInfo(i, (*key_terms)[i].size()));
  }
  // 按照长度降序排序
  std::sort(tag_candidates_tmp.begin(), tag_candidates_tmp.end(), RawItemConvertor::TagLengthCmp);

  // 查找子 tag，并设置对应 index 为 -1
  bool deleted = false;
  for (int i = 0; i < (int)tag_candidates_tmp.size(); ++i) {
    if (tag_candidates_tmp[i].index == -1) continue;
    std::string &i_tag = (*key_terms)[tag_candidates_tmp[i].index];
    for (int j = i + 1; j < (int)tag_candidates_tmp.size(); ++j) {
      if (tag_candidates_tmp[j].index == -1) continue;
      std::string &j_tag = (*key_terms)[tag_candidates_tmp[j].index];
      if (i_tag.find(j_tag) != std::string::npos) {
        tag_candidates_tmp[j].index = -1;
        deleted = true;
      }
    }
  }

  // 删除子 tag
  if (deleted) {
    std::vector<std::string> new_candidates;
    for (int i = 0; i < (int)tag_candidates_tmp.size(); ++i) {
      if (tag_candidates_tmp[i].index == -1) continue;
      new_candidates.push_back((*key_terms)[tag_candidates_tmp[i].index]);
    }

    key_terms->clear();
    for (int i = 0; i < (int)new_candidates.size(); ++i) {
      key_terms->push_back(new_candidates[i]);
    }
  }
}

void RawItemConvertor::ExportCandidateTags(RecoItem *item) {
  int candidate_sum_wt = 0;
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    candidate_sum_wt += tag_candidates_[i].tf;
  }
  if (candidate_sum_wt == 0) candidate_sum_wt = 1;

  item->clear_candidate_tag();
  auto feature_vector = item->mutable_candidate_tag();
  double norm = 0.0;
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    float tag_wt = (float)tag_candidates_[i].tf / candidate_sum_wt;
    norm += tag_wt * tag_wt;
    Feature fea;
    fea.set_literal(base::StringPrintf("label0:%s", tag_candidates_[i].tag.c_str()));
    fea.set_weight(tag_wt);
    feature_vector->add_feature()->CopyFrom(fea);
  }
  feature_vector->set_norm(norm);
}

void RawItemConvertor::ExtractSummaryWords(RecoItem* reco_item,
    std::map<std::string, float>* summary_unseg_tag_weight_dict) {
  if (video_summary_.empty()) return;

  // summary 中的词条 tf 加权
  std::set<std::string> dedup_dict;
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    InnerTagInfo& tag_info = tag_candidates_[i];
    dedup_dict.insert(tag_info.tag);
    if (!tag_info.intitle && (video_summary_.find(tag_info.tag) != std::string::npos)) {
      if (tag_info.tf < 3) {
        tag_info.tf = 3;
      }
      VLOG(1) << "summary boost ! tag:" << tag_info.tag << ",tf:" << tag_info.tf;
    }
  }

  std::string source = nlp::util::NormalizeLine(reco_item->source());
  if (source.find("cp_wemedia_uc_") == std::string::npos) return;

  // 对 uc 自媒体，有些 summary 是人工剪辑的，质量较高，影响面大。其中有些视频名字分词结果是错误的
  // 这里会按照空格分割后，作为标签候选
  std::vector<std::string> fields;
  base::SplitString(video_summary_, " ", &fields);
  const int kMaxLength = 45;   // 15 个汉字长度
  const float kUnitWeight = 0.001;
  for (int i = 0; i < (int)fields.size(); ++i) {
    if (fields[i].empty()) continue;
    // 权重递减，将来展示的时候，如果频次相同，就按照原来的顺序展示
    summary_unseg_tag_weight_dict->insert(std::make_pair(fields[i], kUnitWeight * (fields.size() - i)));
    if (dedup_dict.find(fields[i]) == dedup_dict.end()) {
      dedup_dict.insert(fields[i]);
      if ((int)fields[i].size() < kMaxLength) {
        tag_candidates_.push_back(InnerTagInfo(fields[i], 3, 0.1, false, 0));
        VLOG(1) << "add unsegment word from summary! word:" << fields[i];
      }
    }
  }
}

void RawItemConvertor::CalcParagraphBoundary(RecoItem* reco_item) {
  const std::string& content = reco_item->content();

  int begin = -1;
  int end = -1;
  for (int i = 0; i < (int)content.size(); ++i) {
    if (content[i] == '\n') {
      begin = end + 1;
      end = i;
      paragraph_boundary_.push_back(std::make_pair(begin, end));
      VLOG(2) << "PARA" << paragraph_boundary_.size() - 1 << ", begin:" << begin << ", end:" << end
              << ", para_content:" << content.substr(begin, end - begin);
    }
  }
  if (end < (int)content.size()) {
    begin = end + 1;
    end = (int)content.size();
    paragraph_boundary_.push_back(std::make_pair(begin, end));
    VLOG(2) << "PARA" << paragraph_boundary_.size() - 1 << ", begin:" << begin << ", end:" << end
            << ", para_content:" << content.substr(begin, end - begin);
  }
}

void RawItemConvertor::CalcParagraphFreq(RecoItem* reco_item, const std::string& title) {
  // 记录每个段落的开始和结束位置, 忽略标题
  paragraph_boundary_.clear();
  CalcParagraphBoundary(reco_item);

  term_pf_dict_.clear();
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    InnerTagInfo& tag_info = tag_candidates_[i];
    MergeSortInfo msi;
    msi.in_title = (title.find(tag_info.tag) != std::string::npos);
    msi.raw_tf = tag_info.tf;
    int cur_pf = CalcParagraphFreq(tag_info.tag);
    msi.pf = cur_pf;
    term_pf_dict_.insert(std::make_pair(tag_info.tag, msi));
    VLOG(1) << "term:" << tag_info.tag << ", raw_tf:" << msi.raw_tf << ", pf:" << msi.pf
            << ", in_title:" << msi.in_title;
  }
}

int RawItemConvertor::CalcParagraphFreq(const std::string& term) {
  // 标签候选出现的位置
  std::unordered_map<std::string, std::vector<std::pair<uint32, uint32> > >* term_position_dict =
      item_bow_->GetTermPositionDict();

  auto it_pos_dict = term_position_dict->find(term);
  if (it_pos_dict == term_position_dict->end()) {
    return 0;
  }

  std::set<int> para_set;
  CalcParagraphFreq(term, it_pos_dict->second, &para_set);
  return (int)para_set.size();
}

void RawItemConvertor::CalcParagraphFreq(const std::string& term,
                                         const std::vector<std::pair<uint32, uint32> >& pos_dict,
                                         std::set<int>* para_set) {
  for (auto it_pos = pos_dict.begin(); it_pos != pos_dict.end(); ++it_pos) {
    int pos = it_pos->second;
    for (int index_bound = 0; index_bound < (int)paragraph_boundary_.size(); ++index_bound) {
      if (pos < paragraph_boundary_[index_bound].second) {
        para_set->insert(index_bound);
        VLOG(1) << "term:" << term << ", begin:" << it_pos->first <<  ", end:" << pos
                << ", para:" << index_bound;
        break;
      }
    }
  }
}

void RawItemConvertor::UpdateSynonymPF(const std::string& tag, const std::string& norm_tag) {
  auto it_raw = term_pf_dict_.find(tag);
  if (it_raw == term_pf_dict_.end()) {
    VLOG(1) << "not in term_pf_dict_, tag:" << tag;
    return;
  }

  auto it_norm = term_pf_dict_.find(norm_tag);
  if (it_norm == term_pf_dict_.end()) {
    MergeSortInfo msi;
    msi.in_title = it_raw->second.in_title;
    msi.raw_tf = it_raw->second.raw_tf;
    msi.pf = it_raw->second.pf;
    term_pf_dict_.insert(std::make_pair(norm_tag, msi));
    VLOG(1) << "reset synonym tag pf, norm_tag:" << norm_tag << ", new pf:" << it_raw->second.pf;
  } else {
    // tag 和 norm_tag 可能出现在同一位置，防止频次重复叠加
    std::unordered_map<std::string, std::vector<std::pair<uint32, uint32> > >* term_position_dict =
      item_bow_->GetTermPositionDict();
    auto it_raw_tp = term_position_dict->find(tag);
    auto it_norm_tp = term_position_dict->find(norm_tag);
    if (it_raw_tp != term_position_dict->end() && it_norm_tp != term_position_dict->end()) {
      std::set<int> para_set;
      CalcParagraphFreq(tag, it_raw_tp->second, &para_set);
      CalcParagraphFreq(norm_tag, it_norm_tp->second, &para_set);
      it_norm->second.in_title = (it_raw->second.in_title || it_norm->second.in_title);
      it_norm->second.pf = (int) para_set.size();
      VLOG(1) << "update synonym tag pf, norm_tag:" << norm_tag << ", new pf:" << it_norm->second.pf;
    } else if (it_raw_tp != term_position_dict->end() && it_norm_tp == term_position_dict->end()) {
      it_norm->second.in_title = it_raw->second.in_title;
      it_norm->second.pf = it_raw->second.pf;
      VLOG(1) << "reset synonym tag pf, norm_tag:" << norm_tag << ", new pf:" << it_raw->second.pf;
    }
  }
}

bool RawItemConvertor::IsUseDepResult(const RecoItem& reco_item, const std::string& title) {
  if (item_type_ == reco::kPureVideo) {
    return false;
  }
  if (reco_item.dep_info_size() == 0) {
    VLOG(1) << "no dep info ! item_id:" << reco_item.identity().item_id();
    return false;
  }
  if (title.find("《") != std::string::npos) {
    VLOG(1) << "book mark occurs in title";
    return false;
  }

  std::string category1 = "";
  std::string category2 = "";
  if (reco_item.category_size() >= 1) {
    category1 = reco_item.category(0);
  }
  if (category1 != "娱乐" && category1 != "体育" && category1 != "历史" && category1 != "国际") {
    VLOG(1) << "invalid category for dep result ! categoyr1:" << category1;
    return false;
  }
  if (reco_item.category_size() > 1) {
    category2 = reco_item.category(1);
  }
  std::unordered_set<std::string> tmp_video_spider_tags;

  // 找出在标签库中的最频繁主语
  const int MinFreq = 3;
  for (int i = 0; i < (int)reco_item.dep_info_size(); ++i) {
    const DepInfo& cur_word_info = reco_item.dep_info(i);
    if (cur_word_info.freq() < MinFreq) continue;
    if (cur_word_info.mark() == "SBV") {
      int found = IsManualTag(category1, category2, cur_word_info.word(), tmp_video_spider_tags);
      if (found == 1) {
        if (cur_word_info.freq() > subject_freq_.second) {
          subject_freq_.second = cur_word_info.freq();
          subject_freq_.first = cur_word_info.word();
        }
      }
    }
  }

  // 要求最频繁主语不能出现在标题中
  std::string norm_title = base::StringReplace(title, " ", "", true);
  if (subject_freq_.second != -1 && title.find(subject_freq_.first) == std::string::npos
      && norm_title.find(subject_freq_.first) == std::string::npos) {
    return true;
  } else {
    return false;
  }
}

void RawItemConvertor::AdjustDepTF(const RecoItem& reco_item) {
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    InnerTagInfo& tag_info = tag_candidates_[i];
    if (tag_info.tag == subject_freq_.first) {
      tag_info.tf += subject_freq_.second;
      VLOG(1) << "add subject freq ! word:" << tag_info.tag << ", new add freq:" << subject_freq_.second
              << ", new tf:" << tag_info.tf;
    }
  }
}

void RawItemConvertor::ExtractTagFeature(const std::string& content,
                                         const std::string& title,
                                         const nlp::term::TermContainer& container,
                                         RecoItem *item) {
  // 计算标签候选的段落频次 pf
  CalcParagraphFreq(item, title);

  // 蹭热点意图分析
  bool hot_spam = IntentionAnalysis(*item, content, title, container);

  // 判断是否可以用依存结果
  bool use_dep_result = IsUseDepResult(*item, title);

  // 计算位置特征
  GetNormPos(content.size());

  // 保存原始 tag 数
  int old_tag_candidates_size = (int)tag_candidates_.size();
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    InnerTagInfo& tag_info = tag_candidates_[i];
    VLOG(1) << "before delete: candidate_tag:" << tag_info.tag << ", tf:" << tag_info.tf;
  }

  // 地名识别 region 字段转换为真实地名。
  // 暂时去掉该策略, 因为地名识别的逻辑在这个逻辑之后，这个策略实际并未生效
  std::vector<std::string> region_names;
  // std::string recoitem_region = "";
  // if (item->has_region() && item->region() != "") {
  //  recoitem_region = item->region();
  //  VLOG(1) << "recoitem_region:" << recoitem_region;
  // }
  // reco::common::RegionSearcher::instance().GetRegionNames(recoitem_region, &region_names);

  bool title_boost = true;
  reco::ItemType item_type = item->identity().type();
  if (title.find("马云") != std::string::npos
      && (item_type == reco::kNews || item_type == reco::kReading)) {
    VLOG(1) << "match mayun rule";
    title_boost = false;
  }
  if (hot_spam) {
    VLOG(1) << "cancel title boost for hot_spam !";
    title_boost = false;
  }
  bool title_boost_light = false;
  if (use_dep_result && title_boost) {
    VLOG(1) << "title boost light for dep_info !";
    title_boost = false;
    title_boost_light = true;
  }

  // 标题中的词条 tf 加权,设置 intitle 字段
  std::string norm_title = base::StringReplace(title, " ", "", true);
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    InnerTagInfo& tag_info = tag_candidates_[i];
    if ((title_boost || title_boost_light)
        && (title.find(tag_info.tag) != std::string::npos
            || norm_title.find(tag_info.tag) != std::string::npos)) {
      tag_info.intitle = true;
      if (title_boost) {
        if (tag_info.tf < 8) {
          tag_info.tf *= kMinTagFreq;
        } else {
          tag_info.tf *= 2;
        }
        VLOG(1) << "title boost ! tag:" << tag_info.tag << ",tf:" << tag_info.tf;
      } else {
        tag_info.tf += 2;
        VLOG(1) << "title boost light! tag:" << tag_info.tag << ",tf:" << tag_info.tf;
      }
    } else if (region_names.size() > 0) {
      for (auto it = region_names.begin(); it != region_names.end(); ++it) {
        if (*it != tag_info.tag) continue;
        if (tag_info.tf < 4) {
          tag_info.tf = 4;
          special_tags_.insert(tag_info.tag);
          VLOG(1) << "place boost ！tag:" << tag_info.tag << ",tf:" << tag_info.tf;
        }
      }
    }
  }

  // 视频 summary 提取标签候选
  std::map<std::string, float> summary_unseg_tag_weight_dict;
  ExtractSummaryWords(item, &summary_unseg_tag_weight_dict);

  // 视频标签使用爬虫标签优化
  ExtractSpiderTags(item);

  // 根据依存句法分析结果调整词频
  if (use_dep_result) {
    VLOG(1) << "use dep info";
    AdjustDepTF(*item);
  }

  // 归一化标签
  NormalizeTags(item);

  // 去掉不在 tag 词表中的 tag, 并去掉与类别重名的 tag
  DeleteInvalidTags(item);

  // 标签最大频次都达不到阈值，则对标题重新加权
  if (hot_spam) {
    TitleReweight(norm_title, &hot_spam);
  }

  if (tag_candidates_.empty()) {
    VLOG(1) << "no tags in tag dict, item_id" << item->identity().item_id();
    return;
  }

  VLOG(1) << "tag_candidates_.size(), old:" << old_tag_candidates_size
          << ", new:" << tag_candidates_.size();

  std::sort(tag_candidates_.begin(), tag_candidates_.end(), RawItemConvertor::TagWeightSorter);

  // 导出未经筛选的词表候选 tag，满足对准确不高召回要求比较高的业务使用
  ExportCandidateTags(item);

  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    InnerTagInfo& tag_info = tag_candidates_[i];
    VLOG(1) << "after_sort: tag:" << tag_info.tag << ", tf:" << tag_info.tf
            << ", spread:" << tag_info.spread;
  }

  // const int kKw4TagTopN = std::min(old_tag_candidates_size,
  //                                  std::max(5, std::min(20, old_tag_candidates_size / 5)));
  int kKw4TagTopN = std::min(old_tag_candidates_size,
                                   std::max(5, std::min(20, old_tag_candidates_size / 5)));
  if (item_type_ == reco::kPureVideo) {
    // 视频候选标签的 TopN 重设
    kKw4TagTopN = 10;
  }

  int candidate_sum_wt = 0;
  for (int i = 0; i < kKw4TagTopN && i < (int)tag_candidates_.size(); ++i) {
    candidate_sum_wt += tag_candidates_[i].tf;
  }
  if (candidate_sum_wt == 0) candidate_sum_wt = 1;

  // 统计标题中的 tag 数
  int title_tag_count = 0;
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    if (tag_candidates_[i].intitle) {
      title_tag_count += 1;
    }
  }

  // 3<=n<=6
  int guess_tag_num = std::min(FLAGS_tag_term_num, std::max(3, old_tag_candidates_size / 10));
  if (guess_tag_num <= title_tag_count) {
    guess_tag_num = std::min(FLAGS_tag_term_num, title_tag_count + 1);
  }
  // const int kTagFeaLimitNum = guess_tag_num;
  int kTagFeaLimitNum = guess_tag_num;
  if (item_type_ == reco::kPureVideo) {
    // 视频标签限制数目重设
    kTagFeaLimitNum = 6;
  }

  const float kLimitTagWt = std::min(0.15, 0.6 / kKw4TagTopN);

  VLOG(1) << "kTagFeaLimitNum:" << kTagFeaLimitNum
          << ", kLimitTagWt: " << kLimitTagWt
          << ", kKw4TagTopN:" << kKw4TagTopN;

  std::unordered_map<std::string, float> map_tag_wt;
  std::vector<std::string> cols;
  int category_extend_count = 0;  // 细分类别的扩展
  std::string category1 = "";
  std::string category2 = "";
  if (item->category_size() >= 1) {
    category1 = item->category(0);
  }
  if (item->category_size() > 1) {
    category2 = item->category(1);
  }
  VLOG(1) << "category1:" << category1 << ", category2:" << category2;

  // 是否启用位置特征规则
  bool pos_filter_enabled = IsUsePosFilter(category1);

  for (int i = 0; i < kKw4TagTopN && i < (int)tag_candidates_.size(); ++i) {
    const InnerTagInfo& tag_info = tag_candidates_[i];
    const std::string& nor_tag = tag_info.tag;
    float tag_wt = (float)tag_info.tf / candidate_sum_wt;
    // 人名和标题中的词加权, 保证 tf 相同时优先把标题中的词和人名排在前面
    if (tag_info.intitle) {
      tag_wt += 0.0005;
    }
    if (tag_info.type == 1) {
      tag_wt += 0.0003;
    }
    auto it_unseg = summary_unseg_tag_weight_dict.find(nor_tag);
    if (it_unseg != summary_unseg_tag_weight_dict.end()) {
      tag_wt += it_unseg->second;
    }

    if (!tag_info.intitle && (tag_wt < kLimitTagWt || tag_info.tf <= kMinTagFreq - 1)
        && special_tags_.find(nor_tag) == special_tags_.end()) {
      VLOG(1) << "not in title !!! tag:" << nor_tag << ", tf:" << tag_info.tf
              << ", tag_wt:" << tag_wt << ", kLimitTagWt:" << kLimitTagWt;
      continue;
    }

    // 针对图文类新闻中，出现靠后并且分布过于集中的词语进行过滤
    if (item_type_ != reco::kPureVideo
        && item_type_ != reco::kThemeVideo
        && pos_filter_enabled
        && tag_info.tf <= kMinTagFreq && tag_info.spread <= 0.1 && tag_info.first_norm_pos > 0.1
        && tag_info.last_norm_pos != 0.0) {
      VLOG(1) << "spread too small !!! tag:" << nor_tag << "spread: " << tag_info.spread;
      continue;
    }

    VLOG(1) << "passed !!! tag:" << nor_tag << ", tf:" << tag_info.tf << ", tag_wt:" << tag_wt;

    // 要去掉不能展现的核心词
    if (not_show_corewords_.find(nor_tag) == not_show_corewords_.end()) {
      if (map_tag_wt.find(nor_tag) == map_tag_wt.end()) {
        map_tag_wt.insert(std::make_pair(nor_tag, tag_wt));
      }
    }

    // 新整理的细分类别的扩展
    if (category_extend_count <= 3) {
      category_extend_count++;
      int can_show = 0;
      std::vector<std::string> extend_tags;
      if (GetExtendTags(category1, category2, nor_tag, &can_show, &extend_tags)) {
        std::unordered_set<std::string> tmp_video_spider_tags;
        for (auto it_ext_tag = extend_tags.begin(); it_ext_tag != extend_tags.end(); ++it_ext_tag) {
          int found = IsManualTag(category1, category2, *it_ext_tag, tmp_video_spider_tags);
          if (found != 1) {
            VLOG(1) << "invalid extend_tag ! extend_tag:" << *it_ext_tag;
            continue;
          }
          if (*it_ext_tag != "" && *it_ext_tag != category1 && *it_ext_tag != category2) {
            category_extend_results_.insert(*it_ext_tag);
            VLOG(1) << "category_word_extend ! category: " << category1 << ", "
                    <<  *it_ext_tag << " extend from " << nor_tag;
          }
        }
      }
    }
  }

  std::priority_queue<std::pair<float, std::string>,
      std::vector<std::pair<float, std::string> >, std::greater<std::pair<float, std::string>> > heap;
  // special_tags_ 不受预估个数限制，其他 tag 的个数不能超过 kTagFeaLimitNum
  for (auto it = map_tag_wt.begin(); it != map_tag_wt.end(); it++) {
    if (it->first == category1 || it->first == category2) continue;
    if ((it->first == "宠物" && category1 == "萌宠")
        || (it->first == "萌宠" && category1 == "宠物")) continue;
    if (special_tags_.find(it->first) != special_tags_.end()) continue;
    VLOG(1) << it->first << ":" << it->second << " into heap";
    heap.push(std::make_pair(it->second, it->first));
    if ((int)heap.size() > kTagFeaLimitNum) {
      LOG(INFO) << heap.top().second << ":" << heap.top().first << " weight is too small";
      heap.pop();
    }
  }
  for (auto it = map_tag_wt.begin(); it != map_tag_wt.end(); it++) {
    if (it->first == category1 || it->first == category2) continue;
    if (special_tags_.find(it->first) == special_tags_.end()) continue;
    VLOG(1) << "special_tags_:" << it->first << ":" << it->second << " into heap";
    heap.push(std::make_pair(it->second, it->first));
  }

  std::vector<std::pair<std::string, float> > key_terms(heap.size());
  auto it = key_terms.rbegin();
  float sum_weight = 0;
  while (!heap.empty()) {
    auto& pr = heap.top();
    *it++ = std::make_pair(pr.second, pr.first);
    sum_weight += pr.first;
    heap.pop();
  }
  if (sum_weight < 1e-6 || key_terms.empty()) return;

  // 去掉子标签
  DeleteSubTags(&key_terms);

  // 按照权重排序
  sort(key_terms.begin(), key_terms.end(), PairValueCmp);
  // 蹭热点意图, 根据 pf 调整权重
  if (hot_spam) {
    sum_weight = AdjustWeight(&key_terms);
    sort(key_terms.begin(), key_terms.end(), PairValueCmp);
  }

  // 填充 tag 字段, 并更新同义词标签
  auto feature_vector = item->mutable_tag();
  double norm = 0.0;
  final_tags_.clear();
  item->clear_synonymous_tags();
  for (int i = 0; i < (int)key_terms.size(); ++i) {
    key_terms[i].second /= sum_weight;
    norm += key_terms[i].second * key_terms[i].second;
    Feature fea;
    fea.set_literal(base::StringPrintf("label:%s", key_terms[i].first.c_str()));
    fea.set_weight(key_terms[i].second);
    feature_vector->add_feature()->CopyFrom(fea);
    VLOG(1) << "tag:" << key_terms[i].first << ", norm_weight:" << key_terms[i].second;
    final_tags_.insert(key_terms[i].first);

    // 如有同义词，则更新同义词 tag
    auto it_synonymous = synonym_source_words_.find(key_terms[i].first);
    if (it_synonymous != synonym_source_words_.end() && it_synonymous->second != "") {
      *(item->add_synonymous_tags()) = it_synonymous->second;
      VLOG(1) << "new add synonymous_tags [" << it_synonymous->second << "] from ["
              << key_terms[i].first << "]";
    }
  }
  feature_vector->set_norm(sqrt(norm));
}

bool RawItemConvertor::IsUsePosFilter(const std::string& category1) {
  // 找出分布最广的值
  double max_spread = 0;
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    InnerTagInfo& tag_info = tag_candidates_[i];
    if (tag_info.tf >= kMinTagFreq && tag_info.spread > max_spread) {
      max_spread = tag_info.spread;
    }
  }
  // 某些类别很多对比盘点类新闻，用位置过滤也不合适
  if (max_spread <= 0.1 || category1 == "汽车" || category1 == "旅游" || category1 == "美食") {
    VLOG(1) << "pos_filter disabled !";
    return false;
  }
  return true;
}

void RawItemConvertor::GetNormPos(const int& doc_length) {
  VLOG(1) << "doc_length: " << doc_length;
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    InnerTagInfo& tag_info = tag_candidates_[i];
    GetNormPos(tag_info.tag, doc_length, &tag_info.first_norm_pos, &tag_info.last_norm_pos);
    tag_info.spread = std::max(0.0, tag_info.last_norm_pos - tag_info.first_norm_pos);
    VLOG(1) << tag_info.tag << " : " << tag_info.tf << " : " << tag_info.first_norm_pos
            << " : " << tag_info.last_norm_pos << " : " << tag_info.spread;
  }
}

void RawItemConvertor::GetNormPos(const std::string& word,
                                  const int& doc_length, double* first_norm_pos, double* last_norm_pos) {
  *first_norm_pos = 1.0;
  *last_norm_pos = 0.0;
  if (doc_length == 0) return;

  // 标签候选出现的位置
  std::unordered_map<std::string, std::vector<std::pair<uint32, uint32> > >* term_position_dict =
  item_bow_->GetTermPositionDict();

  auto it_pos_dict = term_position_dict->find(word);
  if (it_pos_dict == term_position_dict->end()) {
    return;
  }

  int first_pos = doc_length;
  int last_pos = 0;
  for (auto it_pos = it_pos_dict->second.begin(); it_pos != it_pos_dict->second.end(); ++it_pos) {
    int pos = it_pos->first;
    if (pos < first_pos) {
      first_pos = pos;
    }
    if (pos > last_pos) {
      last_pos = pos;
    }
  }
  *first_norm_pos = 1.0 * first_pos / doc_length;
  *last_norm_pos = 1.0 * last_pos / doc_length;
}

float RawItemConvertor::AdjustWeight(std::vector<std::pair<std::string, float> > *key_terms) {
  for (auto it_key_term = key_terms->begin(); it_key_term != key_terms->end(); ++it_key_term) {
    VLOG(1) << "before adjust weight ! tag:" << it_key_term->first << ", weight:" << it_key_term->second;
  }
  float sum_weight = 0;
  for (auto it_key_term = key_terms->begin(); it_key_term != key_terms->end(); ++it_key_term) {
    std::string tag = it_key_term->first;
    float weight = it_key_term->second;

    auto it_pf = term_pf_dict_.find(tag);
    if (it_pf != term_pf_dict_.end()) {
      weight += (float)it_pf->second.pf;
    }
    it_key_term->second = weight;

    sum_weight += weight;
  }
  for (auto it_key_term = key_terms->begin(); it_key_term != key_terms->end(); ++it_key_term) {
    VLOG(1) << "after adjust weight ! tag:" << it_key_term->first << ", weight:" << it_key_term->second;
  }
  return sum_weight;
}

bool RawItemConvertor::IntentionAnalysis(const RecoItem& reco_item,
    const std::string& content,
    const std::string& title,
    const nlp::term::TermContainer& container) {
  if (item_type_ == reco::kPureVideo) {
    return false;
  }
  if (classified_hot_spam_ == "汽车,蹭热点") {
    VLOG(1) << "classified_hot_spam_:" << classified_hot_spam_
            << ", item_id:" << reco_item.identity().item_id();
    return true;
  }

  // 汽车类意图识别
  if ((int)reco_item.category_size() >= 1 && reco_item.category(0) == "汽车") {
    // 1. 基本切分中出现“比”，“连”；或者，标题匹配到“不输”、“完胜”、“完虐”、“直逼”、“吊打”、“比肩”
    size_t title_len = title.length();
    for (int j = 0; j < container.basic_term_num(); ++j) {
      const nlp::term::TermInfo& info = container.basic_term_info(j);
      std::string cur_term = info.term(content).as_string();
      if (info.end > title_len) break;
      if (cur_term == "比" || cur_term == "连") {
        VLOG(1) << "automobile category: segment result match intention word " << cur_term;
        return true;
      }
    }
    if (title.find("不输") != std::string::npos
        || title.find("完胜") != std::string::npos
        || title.find("完虐") != std::string::npos
        || title.find("直逼") != std::string::npos
        || title.find("吊打") != std::string::npos
        || title.find("不输") != std::string::npos
        || title.find("比肩") != std::string::npos
        || title.find("神似") != std::string::npos
        || title.find("剑指") != std::string::npos
        || title.find("比超") != std::string::npos
        || title.find("赶超") != std::string::npos
        ) {
      VLOG(1) << "automobile category: title match intention word ! title:" << title;
      return true;
    }
  }
  return false;
}

void RawItemConvertor::TitleReweight(const std::string& norm_title, bool* hot_spam) {
  // 最大频次达不到标签频次阈值
  int max_tf = 0;
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    InnerTagInfo& tag_info = tag_candidates_[i];
    if (tag_info.tf > max_tf) {
      max_tf = tag_info.tf;
    }
  }
  if (max_tf >= kMinTagFreq) {
    return;
  }

  // 标题重新加权
  *hot_spam = false;
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    InnerTagInfo& tag_info = tag_candidates_[i];
    tag_info.intitle = (norm_title.find(tag_info.tag) != std::string::npos);
    if (!tag_info.intitle) {
      auto it = synonym_source_words_.find(tag_info.tag);
      if (it != synonym_source_words_.end() && norm_title.find(it->second) != std::string::npos) {
        tag_info.intitle = true;
      }
    }
    if (tag_info.intitle) {
      tag_info.tf *= kMinTagFreq;
      VLOG(1) << "title renew boost ! tag:" << tag_info.tag << ",tf:" << tag_info.tf;
    }
  }
}
void RawItemConvertor::ExtractSpiderTags(RecoItem* reco_item) {
  // 视频使用爬虫标签
  if (item_type_ != reco::kPureVideo)
    return;
  std::string source = nlp::util::NormalizeLine(reco_item->source());
  if (reco_item->spider_tags_size() <= 0)
    return;
  if (reco_item->has_original_url()) {
    // 原始 url 为优酷的不使用爬虫标签
    std::string original_url = nlp::util::NormalizeLine(reco_item->original_url());
    if (original_url.find("v.youku.com") != std::string::npos)
      return;
  }
  for (int i = 0; i < reco_item->spider_tags_size(); ++i) {
    std::string spider_tag = nlp::util::NormalizeLine(reco_item->spider_tags(i));
    if (spider_tag.empty()) continue;
    bool found = false;
    for (int j = 0; j < (int)tag_candidates_.size(); ++j) {
      if (tag_candidates_[j].tag == spider_tag) {
        found = true;
        tag_candidates_[j].tf += 3;
        break;
      }
    }
    if (found) continue;
    tag_candidates_.push_back(InnerTagInfo(spider_tag, 3, 0.1, false, 0));
    VLOG(1) << "add from spider tag: " << spider_tag;
  }
}

void RawItemConvertor::ExtractSemanticTag(
    const std::string& title_content, const std::string& title,
    const std::string& content,
    const nlp::term::TermContainer& container,
    RecoItem* item) {
  item->clear_semantic_tag();

  std::string category1 = "";
  std::string category2 = "";
  if (item->category_size() >= 1) {
    category1 = item->category(0);
  }
  if (item->category_size() > 1) {
    category2 = item->category(1);
  }

  std::vector<std::string> semantic_tags;

  // 0. 从分类结果获取语义标签
  for (int i = 0; i < (int)classified_tags_.size(); ++i) {
    semantic_tags.push_back(classified_tags_[i]);
    VLOG(1) << "add classified_tag:" << classified_tags_[i];
  }

  // 1. 获取基础标签中的扩展 tag
  for (auto it = category_extend_results_.begin(); it != category_extend_results_.end(); ++it) {
    if (*it != "" && *it != category1 && *it != category2) {
      semantic_tags.push_back(*it);
    }
  }

  // 2. 从 title 中提取语义 tag
  if (FLAGS_title_match_switch) {
    std::vector<std::string> out_tags;
    if (tag_matcher_title_->GetTags(category1, title, &out_tags)) {
      for (auto it = out_tags.begin(); it != out_tags.end(); ++it) {
        if (*it != "" && *it != category1 && *it != category2) {
          semantic_tags.push_back(*it);
          VLOG(1) << "title_extend ! first_category: " << category1 << ",title: " << title
                  <<", tag:" <<  *it;
        }
      }
    }
  }

  // 跟 final_tags_ 去重, 并检查是否在标签库中
  std::unordered_set<std::string> tmp_video_spider_tags;
  for (auto it = semantic_tags.begin(); it != semantic_tags.end();) {
    if (final_tags_.find(*it) != final_tags_.end()) {
      it = semantic_tags.erase(it);
    } else if (IsManualTag(category1, category2, *it, tmp_video_spider_tags) != 1) {
      VLOG(1) << "invalid semantic_tag ! semantic_tag:" << *it;
      it = semantic_tags.erase(it);
    } else if ((*it == "宠物" && category1 == "萌宠")
               || (*it == "萌宠" && category1 == "宠物")) {
      it = semantic_tags.erase(it);
    } else {
      ++it;
    }
  }

  // 语义标签内部去重
  DeleteSubSemanticTags(&semantic_tags);

  if ((int)semantic_tags.size() == 0) return;

  auto fv = item->mutable_semantic_tag();
  double norm = 0.0;
  for (int i = 0; i < (int)semantic_tags.size(); ++i) {
    float tag_weight = 1.0 / (int)semantic_tags.size();
    norm += tag_weight * tag_weight;
    Feature fea;
    fea.set_literal(base::StringPrintf("label2:%s", semantic_tags[i].c_str()));
    fea.set_weight(tag_weight);
    fv->add_feature()->CopyFrom(fea);
    VLOG(1) << "semantic_tag:" << semantic_tags[i] << ", norm_weight:" << tag_weight;
  }
  fv->set_norm(sqrt(norm));
}

void RawItemConvertor::ExtractSpecialTagFeature(RecoItem *item) {
  std::vector<std::string> contain_ids;
  GetUCBSpecialContentIds(*item, &contain_ids);
  if (contain_ids.size() == 0) return;

  std::vector<std::pair<std::string, float> > tags;
  std::vector<std::pair<std::string, float> > semantic_tags;
  for (int i = 0; i < (int)contain_ids.size(); ++i) {
    uint64 item_id;
    if (!base::StringToUint64(contain_ids[i], &item_id)) {
      LOG(INFO) << "error item_id str ! item_id " << contain_ids[i];
      continue;
    }

    RecoItem sub_reco_item;
    if (!get_item_service_->GetRecoItem(item_id, &sub_reco_item)) {
      LOG(INFO) << "faile to get item from hbase: " << item_id;
      continue;
    }

    // 遍历当前子文章的标签和语义标签
    if (!sub_reco_item.has_tag() || sub_reco_item.tag().feature_size() == 0) continue;
    MergeSubTags(sub_reco_item.tag(), &tags);
    if (!sub_reco_item.has_semantic_tag() || sub_reco_item.semantic_tag().feature_size() == 0) continue;
    MergeSubTags(sub_reco_item.semantic_tag(), &semantic_tags);
  }

  if ((int)tags.size() > 0) {
    FeatureVector* fv = item->mutable_tag();
    FillSpecialTag(&tags, fv);
  }
  if ((int)semantic_tags.size() > 0) {
    FeatureVector* fv = item->mutable_semantic_tag();
    FillSpecialTag(&semantic_tags, fv);
  }
}

bool RawItemConvertor::RemoveTagLabel(const std::string raw_tag_literal, std::string* tag_literal) {
  if (raw_tag_literal.empty()) {
    return false;
  }
  std::vector<std::string> tokens;
  base::SplitString(raw_tag_literal, ":", &tokens);
  if (tokens.size() <= 1) {
    *tag_literal = tokens[0];
  } else if (tokens[0] == "label" || tokens[0] == "manual") {
    *tag_literal = tokens[1];
  } else {
    return false;
  }
  return true;
}

void RawItemConvertor::ExtractThemeTagFeature(RecoItem *item) {
  if (item_type_ != reco::kThemeVideo) return;

  // 获取分类信息。对于视频文章，某些类别会映射到文本的分类体系上
  std::string first_category = item->category_size() == 0 ? "" : item->category(0);
  std::string second_category = item->category_size() <= 1 ? "" : item->category(1);
  std::string text_category1;
  std::string text_category2;
  if (CategoryMapping(first_category, second_category, &text_category1, &text_category2)) {
    first_category = text_category1;
    second_category = text_category2;
    VLOG(1) << "theme video mapping category:" << "new first category:" << first_category;
  }

  //  人工或抓取的标签
  std::unordered_set<std::string> tmp_video_tags;
  std::vector<std::string> video_spider_tags;
  for (int i = 0; i < item->spider_tags_size(); ++i) {
    std::string spider_tag = nlp::util::NormalizeLine(item->spider_tags(i));
    base::TrimWhitespaces(&spider_tag);
    if (spider_tag.empty()) continue;
    if (spider_tag == first_category || spider_tag == second_category) continue;
    int found = IsManualTag(first_category, second_category, spider_tag, tmp_video_tags);
    if (found == 1 && tmp_video_tags.find(spider_tag) == tmp_video_tags.end()) {
      video_spider_tags.push_back(spider_tag);
      tmp_video_tags.insert(spider_tag);
      VLOG(1) << "subject id:" << item->identity().item_id() << ","
              << "manual tag:" << spider_tag;
    }
  }

  // 通过子文聚合标签
  std::unordered_map<std::string, double> child_tags_weight;
  ExtractThemeChildTagFeature(item, &child_tags_weight);

  // 计算主题与标签相似度
  std::unordered_map<std::string, double> all_tags_weight;
  CalculateThemeTagWeight(item, child_tags_weight, video_spider_tags, &all_tags_weight);

  auto feature_vector = item->mutable_tag();
  feature_vector->clear_feature();  // 清除之前主题本身的标签
  double norm = 0.0;
  for (auto it = all_tags_weight.begin(); it != all_tags_weight.end(); ++it) {
    double weight = it->second;
    norm += weight * weight;

    Feature current_fea;
    current_fea.set_weight(weight);
    current_fea.set_literal(base::StringPrintf("label:%s", (it->first).c_str()));
    feature_vector->add_feature()->CopyFrom(current_fea);
    VLOG(1) << "theme tag:" << it->first << ", norm_weight:" << weight;
  }
  feature_vector->set_norm(sqrt(norm));
}

void RawItemConvertor::ExtractThemeChildTagFeature(RecoItem *item,
                                      std::unordered_map<std::string, double>* child_tags_weight) {
  // 通过子文聚合标签
  base::Time current_time = base::Time::Now();
  int64 current_timestamp = current_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  for (size_t i = 0; i < child_items_->size(); ++i) {
    const RecoItem& child_item = child_items_->at(i);
    double subject_child_weight = 0.0;  // 主题与子文视频的相关度
    // TODO(liurong)  目前为视频创建时间，并非加入主题时间，可能是加入主题时间更靠谱
    int64 create_timestamp = child_item.identity().create_timestamp()*base::Time::kMicrosecondsPerMillisecond;
    double delta_days = 1.0*(current_timestamp - create_timestamp) / base::Time::kMicrosecondsPerDay;
    subject_child_weight = pow(0.9999, delta_days);

    auto feature_vector = child_item.tag();
    for (int j = 0; j < feature_vector.feature_size(); ++j) {
      auto current_fea = feature_vector.feature(j);
      // 需要去除标签中的标记
      std::string raw_tag = current_fea.literal();
      std::string tag = "";
      if (!RemoveTagLabel(raw_tag, &tag)) continue;

      auto it_find = child_tags_weight->find(tag);
      if (it_find != child_tags_weight->end()) {
        it_find->second += subject_child_weight;
      } else {
        child_tags_weight->insert(std::make_pair<std::string, double>(tag, subject_child_weight));
      }
      VLOG(1) << "subject id:" << item->identity().item_id() << ","
              << "add tag :" << tag << ","
              << "by child id:" << child_item.identity().item_id() << ","
              << "weight :" << subject_child_weight;
    }
  }
  VLOG(1) << "subject id:" << item->identity().item_id() << ","
          << "subject subitem size : " << child_items_->size();
  // sort by weight
  std::vector<std::pair<std::string, float> > child_tags_vec;
  for (auto iter = child_tags_weight->begin(); iter != child_tags_weight->end(); ++iter) {
    child_tags_vec.push_back(std::make_pair(iter->first, iter->second));
  }
  std::sort(child_tags_vec.begin(), child_tags_vec.end(), PairValueCmp);

  // 截取标签
  child_tags_weight->clear();
  const size_t kMaxTagNum = FLAGS_subject_max_tag_num;
  for (size_t i = 0; i < child_tags_vec.size(); ++i) {
    if (child_tags_weight->size() > kMaxTagNum) {
      break;
    }
    auto tag = child_tags_vec.at(i).first;
    if (child_tags_weight->find(tag) == child_tags_weight->end()) {
      VLOG(1)  << "subject id:" << item->identity().item_id() << ","
               << "selected child tag:" << tag;
      child_tags_weight->insert(child_tags_vec.at(i));
    }
  }
}

double RawItemConvertor::cosine_similarity(const TagVec& tag_vec_1, const TagVec& tag_vec_2) {
  if (tag_vec_1.l2_norm == 0.0 || tag_vec_2.l2_norm == 0.0) {
    return 0.0;
  }
  if (tag_vec_1.vec.size() != tag_vec_2.vec.size()) {
    LOG(ERROR) << "cosine_similarity ERROR, vector size is not equall";
    return 0.0;
  }
  double result = 0.0;
  for (size_t i = 0; i < tag_vec_1.vec.size(); ++i) {
    result +=  tag_vec_1.vec.at(i) * tag_vec_2.vec.at(i);
  }
  return (result / (tag_vec_1.l2_norm * tag_vec_2.l2_norm));
}

void RawItemConvertor::CalculateThemeTagWeight(RecoItem *item,
                                   const std::unordered_map<std::string, double>& child_tags_weight,
                                   const std::vector<std::string>& video_spider_tags,
                                   std::unordered_map<std::string, double>* all_tags_similarity
                                               ) {
  //  计算标签与主题的权重：
  //  step1 : 计算标签的权重,对于子文聚合,则为标签命中视频的个数；
  //         对于抓取标签和主题本身标签,权重为子文标签的均值加1
  //  step2 : 计算主题下标签的中心向量,即标签权重乘以标签向量，然后累加
  //  step3 : 计算标签向量与中心向量的距离，即相似度。
  //  step4 : 计算标签与主题的相似度，即相似度乘以标签权重
  std::unordered_map<std::string, double> all_tags_weight;
  // step1:计算标签权重
  double sum_weight = 0.0;
  for (auto iter = child_tags_weight.begin(); iter != child_tags_weight.end(); ++iter) {
    all_tags_weight.insert(std::make_pair(iter->first, iter->second));
    sum_weight += iter->second;
    VLOG(1) << "child tag : " << iter->first << ", weight : " << iter->second;
  }
  double manual_weight = 1.0;
  if (child_tags_weight.size() > 0 && sum_weight > 0) {
    manual_weight = sum_weight/child_tags_weight.size();
  }
  manual_weight += 1.0;  // 增强

  // 合并个来源标签
  for (auto iter = video_spider_tags.begin(); iter != video_spider_tags.end(); ++iter) {
    auto iter_find = all_tags_weight.find(*iter);
    if (iter_find == all_tags_weight.end()) {
      all_tags_weight.insert(std::make_pair((*iter), manual_weight));
    } else {
      iter_find->second += manual_weight;
    }
    VLOG(1) << "spider tag : " << *iter<< ",weight ; " << manual_weight;
  }

  auto const feature_vector = item->mutable_tag();
  for (int i = 0; i < feature_vector->feature_size(); ++i) {
    auto const & current_fea = feature_vector->feature(i);
    std::string raw_tag = current_fea.literal();
    std::string tag = "";
    if (RemoveTagLabel(raw_tag, &tag)) continue; 
    auto iter_find = all_tags_weight.find(tag);
    if (iter_find == all_tags_weight.end()) {
      all_tags_weight.insert(std::make_pair((tag), manual_weight));
    } else {
      iter_find->second += manual_weight;
    }
    VLOG(1) << "self tag : " << tag << ",weight : " << manual_weight;
  }

  if (all_tags_weight.empty()) return;

  //  step2 计算中心向量
  auto tag_vec_dict = GlobalDataIns::instance().GetVideoTagVecDict();
  if (tag_vec_dict == NULL || tag_vec_dict->empty()) {
    LOG(ERROR) << "load tag vec error";
    return;
  }
  TagVec mean_vec;
  int tag_num = all_tags_weight.size();
  for (auto iter = all_tags_weight.begin(); iter != all_tags_weight.end(); ++iter) {
    double weight = iter->second;
    std::string find_tag = base::StringReplace(iter->first, " ", "_", true);  //  计算向量时，将标签进行了转换
    base::LowerString(&find_tag);
    auto const & iter_find = tag_vec_dict->find(find_tag);
    if (iter_find == tag_vec_dict->end()) {
      LOG(ERROR) << "tag vector not find : " << find_tag;
      continue;
    }
    auto find_vec = iter_find->second.vec;
    if (mean_vec.vec.size() <= 0) {
      for (size_t i = 0; i < find_vec.size(); ++i) {
        mean_vec.vec.push_back(0.0);
      }
    }
    for (size_t i = 0; i < find_vec.size(); ++i) {
      mean_vec.vec[i] += weight * find_vec.at(i);
    }
  }
  double mean_vec_norm = 0.0;
  for (size_t i = 0; i < mean_vec.vec.size(); ++i) {
    mean_vec_norm += (mean_vec.vec.at(i) * mean_vec.vec.at(i));
  }
  if (mean_vec_norm <= 0.0) return;
  mean_vec.l2_norm = sqrt(mean_vec_norm);

  // step3:计算相似度
  double dist_mean_weight = 0.0;
  for (auto iter = all_tags_weight.begin(); iter != all_tags_weight.end(); ++iter) {
    std::string find_tag = base::StringReplace(iter->first, " ", "_", true);  //  计算向量时，将标签进行了转换
    base::LowerString(&find_tag);
    auto iter_find = tag_vec_dict->find(find_tag);
    if (iter_find == tag_vec_dict->end()) continue;
    auto const & find_vec = iter_find->second;
    double dist = cosine_similarity(find_vec, mean_vec);
    all_tags_similarity->insert(std::make_pair(iter->first, dist));
    dist_mean_weight += dist/tag_num;
    VLOG(1) << "tag: " << iter->first << ", dist weight: " << dist << "tag_num:" << tag_num;
  }
  if (dist_mean_weight <= 0.0) return;
  VLOG(1) << "dist_mean_weight : " << dist_mean_weight;

  // step4:计算距离中心位置
  for (auto iter = all_tags_weight.begin(); iter != all_tags_weight.end(); ++iter) {
    auto iter_find = all_tags_similarity->find(iter->first);
    if (iter_find == all_tags_similarity->end()) continue;
    double sim_weight = iter->second * iter_find->second / dist_mean_weight;
    VLOG(1) << "tag : " << iter->first << ", "
            << "weight : " << iter->second << ","
            << "sim : " << iter_find->second << ","
            << "dist_mean_weight : " << dist_mean_weight << ","
            << "sim_w : " << sim_weight;
    iter_find->second = sim_weight;
  }
}

void RawItemConvertor::MergeSubTags(const reco::FeatureVector &fv,
                                    std::vector<std::pair<std::string, float> > *tags) {
  for (int index = 0; index < fv.feature_size(); ++index) {
    std::string word = fv.feature(index).literal();
    float weight = fv.feature(index).weight();
    // 跟已有的标签进行合并
    int candidate_index = 0;
    for (; candidate_index < (int)tags->size(); ++candidate_index) {
      if ((*tags)[candidate_index].first == word) {
        (*tags)[candidate_index].second += weight;
        break;
      }
    }
    // 没找到，则新增
    if (candidate_index == (int)tags->size()) {
      tags->push_back(std::make_pair(word, weight));
    }
  }
}

void RawItemConvertor::FillSpecialTag(std::vector<std::pair<std::string, float> > *tags, FeatureVector* fv) {
  sort(tags->begin(), tags->end(), PairValueCmp);

  float sum_weight = 0.0;
  for (int i = 0; i < (int)tags->size(); ++i) {
    sum_weight += (*tags)[i].second;
  }

  double norm = 0.0;
  for (int i = 0; i < (int)tags->size(); ++i) {
    float tag_weight = (*tags)[i].second / sum_weight;
    norm += tag_weight * tag_weight;
    Feature fea;
    fea.set_literal(base::StringPrintf("%s", (*tags)[i].first.c_str()));
    fea.set_weight(tag_weight);
    fv->add_feature()->CopyFrom(fea);
    VLOG(1) << "tag: " << (*tags)[i].first << ", norm_weight:" << tag_weight;
  }
  if (tags->size() > 0) {
    fv->set_norm(sqrt(norm));
  }
}

void RawItemConvertor::ExtractTitleTermDocFeature(const std::string& content,
                                                  int title_len,
                                                  const nlp::term::TermContainer& container,
                                                  RecoItem* item) {
  std::vector<nlp::term::TermInfo> basic_terms;
  std::vector<nlp::term::TermInfo> mix_terms;
  std::vector<nlp::term::TermInfo> entity_terms;

  if (title_len == 0) {
    title_len = content.size();
  }

  for (int i = 0; i < (int)container.basic_term_num(); ++i) {
    const nlp::term::TermInfo& term_info = container.basic_term_info(i);
    if ((int)term_info.begin >= title_len) break;
    basic_terms.push_back(term_info);
  }
  for (int i = 0; i < (int)container.entity_term_num(); ++i) {
    const nlp::term::TermInfo& term_info = container.entity_term_info(i);
    if ((int)term_info.begin >= title_len) break;
    entity_terms.push_back(term_info);
  }
  const std::vector<nlp::term::TermInfo>& orig_mix_terms = container.mix_terms();
  for (int i = 0; i < (int)orig_mix_terms.size(); ++i) {
    const nlp::term::TermInfo& term_info = orig_mix_terms[i];
    if ((int)term_info.begin >= title_len) break;
    mix_terms.push_back(term_info);
  }
  // NOTE(xielang): 这行挂说明 title 的最后和正文的开始，有被连在一起识别为专名的
  if (basic_terms.back().end != mix_terms.back().end) {
    LOG(ERROR) << base::StringPrintf("title: %s, basic: %s, mix: %s",
                                     content.substr(0, title_len).c_str(),
                                     basic_terms.back().term(content).as_string().c_str(),
                                     mix_terms.back().term(content).as_string().c_str());
    int idx = mix_terms.size() - 1;
    mix_terms[idx].end = basic_terms.back().end;
    mix_terms[idx].rune_len = mix_terms[idx].end - mix_terms[idx].begin;
  }

  std::vector<float> imps;
  imp_->CalcImp(content, basic_terms, mix_terms, &imps);
  CHECK_EQ(imps.size(), basic_terms.size());

  int entity_idx = 0;
  reco::sim_item::SimTermInfo sim_term_info;
  std::string bytes;
  for (int i = 0; i < (int)basic_terms.size(); ++i) {
    if (entity_idx < (int)entity_terms.size() &&
        entity_terms[entity_idx].end <= basic_terms[i].begin) ++entity_idx;

    sim_term_info.pos = i;
    sim_term_info.enum_postag = basic_terms[i].enum_postag;

    if (entity_idx < (int)entity_terms.size()
        && basic_terms[i].begin >= entity_terms[entity_idx].begin
        && basic_terms[i].end <= entity_terms[entity_idx].end) {
      sim_term_info.enum_entity = entity_terms[entity_idx].enum_entity;
    }

    sim_term_info.imp = imps[i];
    reco::RawFeature* raw_feature = item->add_sim_feature();
    const base::Slice& term = basic_terms[i].term(content);
    int show_len;
    if (base::GetUTF8TextWidth(term, &(show_len))) {
      show_len = std::min(show_len, 255);
      sim_term_info.show_len = show_len;
    } else {
      sim_term_info.show_len = 0;
    }
    raw_feature->set_literal(term.as_string());
    // LOG_IF(INFO, item->identity().item_id() == 10000128212882333397ul)
    // << "pk: " << term.as_string() << "-" << sim_term_info.imp;
    reco::sim_item::SimTermInfo::PackSimTermInfo(sim_term_info, &bytes);
    raw_feature->set_feature(bytes);
  }
}

void RawItemConvertor::ExtractOtherTermDocFeature(RecoItem* item) {
  nlp::term::TermContainer container;

  std::vector<std::string> literals;
  if (item->has_source() && !item->source().empty()) {
    literals.push_back(item->source());
  }

  for (int i = 0; i < item->category_size(); ++i) {
    if (item->category(0) == "未分类") break;
    literals.push_back(item->category(i));
  }

  for (size_t i = 0; i < literals.size(); ++i) {
    container.renew();
    nlp::util::NormalizeLineInPlaceS(&literals[i]);
    CHECK(segmenter_->SegmentT(literals[i], &container));
    for (int j = 0; j < container.basic_term_num(); ++j) {
      const nlp::term::TermInfo &info = container.basic_term_info(j);
      std::string term = info.term(literals[i]).as_string();
      reco::sim_item::SimTermInfo sim_term_info;
      sim_term_info.pos = j;
      sim_term_info.imp = 0.01 / container.basic_term_num();
      int show_len;
      if (base::GetUTF8TextWidth(term, &(show_len))) {
        show_len = std::min(show_len, 255);
        sim_term_info.show_len = show_len;
      } else {
        sim_term_info.show_len = 0;
      }

      std::string bytes;
      reco::RawFeature* raw_feature = item->add_sim_feature();
      raw_feature->set_literal(term);
      // LOG_IF(INFO, item->identity().item_id() == 10000128212882333397ul)
      //     << "pk: " << term << "-" << sim_term_info.imp;
      reco::sim_item::SimTermInfo::PackSimTermInfo(sim_term_info, &bytes);
      raw_feature->set_feature(bytes);
    }
  }
}

void RawItemConvertor::ExtractBidwordTermDocFeature(RecoItem* item) {
  nlp::term::TermContainer container;

  std::vector<std::pair<std::string, float>> term_weight;
  term_weight.reserve(item->keyword().feature_size() +
                      item->tag().feature_size());
  for (int i = 0; i < item->keyword().feature_size(); ++i) {
    term_weight.push_back(
        std::make_pair(item->keyword().feature(i).literal(),
                       item->keyword().feature(i).weight()));
  }
  for (int i = 0; i < item->tag().feature_size(); ++i) {
    std::string tag = item->tag().feature(i).literal();
    base::ReplaceFirstSubstringAfterOffset(&tag, 0, "label:", "");
    if (tag.empty()) continue;
    term_weight.push_back(
        std::make_pair(tag, item->tag().feature(i).weight()));
  }
  for (size_t i = 0; i < term_weight.size(); ++i) {
    container.renew();
    std::string str = nlp::util::NormalizeLine(term_weight[i].first);
    CHECK(segmenter_->SegmentT(str, &container));
    for (int j = 0; j < container.basic_term_num(); ++j) {
      const nlp::term::TermInfo &info = container.basic_term_info(j);
      std::string term = info.term(str).as_string();
      reco::sim_item::SimTermInfo sim_term_info;
      sim_term_info.pos = j;
      sim_term_info.imp = term_weight[i].second / container.basic_term_num();
      int show_len;
      if (base::GetUTF8TextWidth(term, &(show_len))) {
        show_len = std::min(show_len, 255);
        sim_term_info.show_len = show_len;
      } else {
        sim_term_info.show_len = 0;
      }

      std::string bytes;
      reco::RawFeature* raw_feature = item->add_sim_feature();
      raw_feature->set_literal(term);
      // LOG_IF(INFO, item->identity().item_id() == 10000128212882333397ul)
      //     << "pk: " << term << "-" << sim_term_info.imp;
      reco::sim_item::SimTermInfo::PackSimTermInfo(sim_term_info, &bytes);
      raw_feature->set_feature(bytes);
    }
  }
}

bool RawItemConvertor::TagWeightSorter(const InnerTagInfo& left, const InnerTagInfo& right) {
  if (left.tf != right.tf) return left.tf > right.tf;
  if (left.tfidf != right.tfidf) return left.tfidf > right.tfidf;
  return left.tag <= right.tag;
}

bool RawItemConvertor::ExtractRegion(const std::string& content,
                                     int title_len,
                                     const nlp::term::TermContainer& container,
                                     RecoItem* reco_item) {
  return region_recognition_->ExtractRegionFromRawitem(reco_item->identity(),
                                                       reco_item->source(),
                                                       reco_item->orig_source(),
                                                       reco_item->spider_region(),
                                                       content,
                                                       title_len,
                                                       container,
                                                       reco_item);
}

bool RawItemConvertor::SetRegionRestrict(const std::string& content,
                                         int title_len,
                                         RecoItem* reco_item) {
  CHECK(reco_item);
  reco::common::RegionRestrictInfo region_restrict_info;
  return reco::common::RegionRestrictSearcher::instance().SetRegionRestrict(content,
                                                                            title_len,
                                                                            &region_restrict_info,
                                                                            reco_item);
}

void RawItemConvertor::ExtractVideoTagFeature(const std::string& source,
                                              const std::string& orig_source,
                                              const std::string& category,
                                              const std::string& title) {
  video_tags_.clear();
  std::vector<VideoTagAnnotator::VideoTag> tags;
  if (video_tag_annotator_->GetTags(source, orig_source, category, title, &tags)) {
    for (size_t i = 0; i < tags.size(); ++i) {
      bool found = false;
      for (int j = 0; j < (int)tag_candidates_.size(); ++j) {
        if (tag_candidates_[j].tag == tags[i].tag) {
          found = true;
        }
      }
      if (found) continue;

      tag_candidates_.push_back(InnerTagInfo(tags[i].tag, tags[i].tf, 100, false, 0));
      video_tags_[tags[i].tag] = tags[i];
      VLOG(1) << "add from video tag annotator: " << tags[i].tag;
    }
  }
}

void RawItemConvertor::ClearTags() {
  tag_candidates_.clear();
  special_tags_.clear();
  not_show_corewords_.clear();
  category_extend_results_.clear();
  final_tags_.clear();
  synonym_source_words_.clear();
  classified_tags_.clear();
  classified_hot_spam_ = "";
  current_show_tag_black_.clear();
  book_names_.clear();
  subject_freq_.first = "";
  subject_freq_.second = -1;
}

bool RawItemConvertor::CategoryMapping(const std::string &video_category1,
                                       const std::string &video_category2,
                                       std::string *text_category1,
                                       std::string *text_category2) {
  *text_category2 = "";
  if (video_category1 == "影视剧"
      || video_category1 == "语言类"
      || video_category1 == "音乐"
      || video_category1 == "综艺"
      || video_category1 == "演讲") {
    *text_category1 = "娱乐";
    return true;
  } else if (video_category1 == "劲爆体育") {
    *text_category1 = "体育";
    return true;
  } else if (video_category1 == "萌宠") {
    *text_category1 = "宠物";
    return true;
  }
  return false;
}

void RawItemConvertor::DeleteInvalidTags(RecoItem *item) {
  // 获取分类信息。对于视频文章，某些类别会映射到文本的分类体系上
  std::string first_category = item->category_size() == 0 ? "" : item->category(0);
  std::string second_category = item->category_size() <= 1 ? "" : item->category(1);
  if (item_type_ == kPureVideo) {
    std::string text_category1;
    std::string text_category2;
    if (CategoryMapping(first_category, second_category, &text_category1, &text_category2)) {
      first_category = text_category1;
      second_category = text_category2;
      VLOG(1) << "mapping category:" << "new first category:" << first_category;
    }
  }

  std::string source = nlp::util::NormalizeLine(item->source());
  std::unordered_set<std::string> video_spider_tags;
  if (item_type_ == kPureVideo) {
    for (int i = 0; i < item->spider_tags_size(); ++i) {
      std::string spider_tag = nlp::util::NormalizeLine(item->spider_tags(i));
      if (spider_tag.empty()) continue;
      video_spider_tags.insert(spider_tag);
    }
  }

  std::vector<InnerTagInfo> tag_candidates_tmp;
  for (int i = 0; i < (int)tag_candidates_.size(); ++i) {
    const std::string& nor_tag = tag_candidates_[i].tag;
    // 删除视频中的 tag 黑名单
    if (item_type_ == kPureVideo && InVideoInvalidTag(first_category, nor_tag)) {
      VLOG(1) << "video invalid tag:" << nor_tag;
      continue;
    }
    // 删除：跟一级类别相同的标签
    if (nor_tag == first_category) continue;

    // NOTE:为了调试方便，把这些 if 条件拆开
    // 标签词典
    int found = IsManualTag(first_category, second_category, nor_tag, video_spider_tags);
    if (found == 1) {
      tag_candidates_tmp.push_back(tag_candidates_[i]);
      VLOG(1) << "manual ! tag:" << nor_tag;
      // 特殊词条
    } else if (special_tags_.find(nor_tag) != special_tags_.end()) {
      tag_candidates_tmp.push_back(tag_candidates_[i]);
      VLOG(1) << "special ! tag:" << nor_tag;
    } else if (found == 0) {
      // 细分类别扩展词典中的核心词
      int canshow_flag =  SearchCoreWord(first_category, second_category, nor_tag);
      if (canshow_flag >= 1) {
        tag_candidates_tmp.push_back(tag_candidates_[i]);
        VLOG(1) << "Do not filter extend coreword when selecting candidate ! coreword:" << nor_tag;
        if (canshow_flag == 1) {
          not_show_corewords_.insert(nor_tag);
        }
      }
    }
  }
  tag_candidates_.clear();
  for (int i = 0; i < (int)tag_candidates_tmp.size(); ++i) {
    tag_candidates_.push_back(tag_candidates_tmp[i]);
  }
}

void RawItemConvertor::FilterInvalidShowTag(const std::vector<std::string> &show_tag_list,
                                            reco::RecoItem *reco_item) {
  CHECK(reco_item);
  // 过滤有地名关系标签，保留第一个
  for (size_t i = 0; i < show_tag_list.size(); i++) {
    std::set<std::string> relation_list;
    if (reco::common::RegionSearcher::instance().GetPcdRelation(show_tag_list[i], &relation_list)) {
      bool have_relation = false;
      VLOG(9) << show_tag_list[i] << " , relation size:" << relation_list.size();
      for (size_t j = 0; j < i; j++) {
        if (relation_list.find(show_tag_list[j]) != relation_list.end()) {
          have_relation = true;
          break;
        }
      }
      if (!have_relation) {
        reco_item->add_show_tag(show_tag_list[i]);
      }
    } else {
      reco_item->add_show_tag(show_tag_list[i]);
    }
  }
}

void RawItemConvertor::SelectShowTagFromSemanticTag(reco::RecoItem *reco_item,
                                                    std::vector<std::string> *show_tag_list) {
  auto show_tag_category_dict = GlobalDataIns::instance().GetShowTagCategroyDict();
  CHECK(reco_item && show_tag_list);
  if (reco_item->has_semantic_tag()) {
    for (int i = 0; i < reco_item->semantic_tag().feature_size(); i++) {
      std::vector<std::string> v;
      base::SplitString(reco_item->semantic_tag().feature(i).literal(), ":", &v);
      if (v.size() < 2) continue;

      std::string semantic_tag = v[1];
      if (semantic_tag.empty()) continue;
      if (current_show_tag_black_.find(semantic_tag) != current_show_tag_black_.end()) {
        VLOG(1) << "match show tag black:" << semantic_tag;
        continue;
      }
      VLOG(1) << "add semantic tag to show tag:" << semantic_tag;

      bool is_classified_tag = false;
      for (auto idx = 0; idx < (int)classified_tags_.size(); ++idx) {
        if (semantic_tag == classified_tags_[idx]) {
          is_classified_tag = true;
          break;
        }
      }
      if (is_classified_tag) {
        show_tag_list->push_back(semantic_tag);
        continue;
      }

      auto it = show_tag_category_dict->find(nlp::util::NormalizeLine(semantic_tag));
      if (it != show_tag_category_dict->end()) {
        bool is_valid = true;
        for (size_t j = 0; j < show_tag_list->size(); j++) {
          if ((*show_tag_list)[j].find(it->first) != std::string::npos
              || it->first.find((*show_tag_list)[j]) != std::string::npos) {
            is_valid = false;
            break;
          }
        }
        if (is_valid) {
          show_tag_list->push_back(it->first);
        }
      }
    }
  }
}

bool CmpByValue(const std::pair<std::string, double>& lhs, const std::pair<std::string, double>& rhs) {
  return lhs.second > rhs.second;
}

void RawItemConvertor::GenVideoShowTag(reco::RecoItem* reco_item) {
  // 只对视频生效
  if (reco_item->identity().type() != reco::kPureVideo) {
    return;
  }
  reco_item->clear_show_tag();
  auto video_show_tag_dict = GlobalDataIns::instance().GetVideoShowTagDict();
  auto video_show_tag_ctr_dict = GlobalDataIns::instance().GetVideoShowTagCtrDict();
  if (reco_item->has_tag()) {
    std::map<std::string, double> showtag_ctr_map;
    bool munual_checked = IsTagManualChecked(*reco_item);
    for (int i = 0; i < reco_item->tag().feature_size(); ++i) {
      std::string real_tag;
      const std::string& raw_tag = reco_item->tag().feature(i).literal();
      VLOG(1) << "video before real_tag ! raw_tag:" << raw_tag;
      if (!ExtractRealTag(munual_checked, raw_tag, &real_tag)) {
        continue;
      }
      VLOG(1) << "video after real_tag ! raw_tag:" << raw_tag << ", real_tag:" << real_tag;
      std::string norm_tag = nlp::util::NormalizeLine(real_tag);
      if (FLAGS_same_show_switch) {
        if (current_show_tag_black_.find(norm_tag) != current_show_tag_black_.end()) {
          VLOG(1) << "match show tag black:" << norm_tag;
          continue;
        }
      } else {
        if (video_show_tag_dict->find(norm_tag) == video_show_tag_dict->end()) {
          continue;
        }
      }
      double ctr = 0.0;
      auto iter = video_show_tag_ctr_dict->find(norm_tag);
      if (iter != video_show_tag_ctr_dict->end()) {
        ctr = iter->second;
      }
      showtag_ctr_map.insert(std::make_pair(real_tag, ctr));
    }
    if (showtag_ctr_map.size() == 0) {
      return;
    }
    std::vector<std::pair<std::string, double>> showtag_ctr_vec(showtag_ctr_map.begin(), showtag_ctr_map.end()); // NOLINT
    // show tag 按照 ctr 排序
    std::sort(showtag_ctr_vec.begin(), showtag_ctr_vec.end(), CmpByValue);
    int vec_len = showtag_ctr_vec.size();
    // showtag_ctr_vec 大于 1 则看第一个 show tag 长度是否大于 3
    if (vec_len > 1) {
      base::Slice first_showtag(showtag_ctr_vec[0].first);
      int char_num = 0;
      if (!GetUTF8CharNum(first_showtag, &char_num)) return;
      VLOG(1) << "first_showtag: " << first_showtag.as_string() << " , len: " << char_num;
      // 第一个 show tag 长度大于 3 个字,则查找后面长度小于等于 3 的 show tag 替换
      if (char_num > 3) {
        for (int i = 1; i < vec_len; ++i) {
          base::Slice other_showtag(showtag_ctr_vec[i].first);
          if (!GetUTF8CharNum(other_showtag, &char_num)) return;
          VLOG(1) << "other_showtag: " << other_showtag.as_string() << " , len: " << char_num;
          if (char_num <= 3) {
            std::swap(showtag_ctr_vec[0], showtag_ctr_vec[i]);
            break;
          }
        }
      }
    }
    auto iter = showtag_ctr_vec.begin();
    for (; iter != showtag_ctr_vec.end(); ++iter) {
      VLOG(1) << "add video show_tag:" << iter->first;
      reco_item->add_show_tag(iter->first);
    }
  }
}

void RawItemConvertor::SelectFinalShowTagsNew(reco::RecoItem *reco_item) {
  reco_item->clear_show_tag();
  auto show_tag_category_dict = GlobalDataIns::instance().GetShowTagCategroyDict();

  // 使用多分类优化展示标签召回
  std::unordered_set<std::string> category_list;
  if (reco_item->category_size() > 0) {
    category_list.insert(reco_item->category(0));
  }
  if (reco_item->has_multi_category()) {
    const reco::MultiCategory& multi_category = reco_item->multi_category();
    for (int i = 0; i < multi_category.category_candidates_size(); i++) {
      std::string category = multi_category.category_candidates(i).level1();
      float score = multi_category.category_candidates(i).level1_score();
      VLOG(1) << "category:" << category << ", score:" << score;
      if (!category.empty()) {
        category_list.insert(category);
      }
    }
  }

  // 展示标签选择对未分类特殊处理
  bool is_null_category = false;
  if (category_list.size() == 1 && category_list.find("未分类") != category_list.end()) {
    is_null_category = true;
  }

  int count = 0;
  // 获取所有 tag
  const reco::FeatureVector& feavec = reco_item->tag();
  std::vector<std::string> tokens;
  std::vector<std::string> show_tag_list;
  for (int i = 0; i < feavec.feature_size(); ++i) {
    // 当前 tag 的格式为 label:tag
    tokens.clear();
    base::SplitString(feavec.feature(i).literal(), ":", &tokens);
    std::string fea_tag = tokens.size() >= 2u ? tokens[1] : feavec.feature(i).literal();
    if (fea_tag.empty()) continue;
    VLOG(1) << "candidate show tag:" << fea_tag;

    if (current_show_tag_black_.find(fea_tag) != current_show_tag_black_.end()) {
      VLOG(1) << "match show tag black:" << fea_tag;
      continue;
    }

    VLOG(1) << "show tag category check:" << fea_tag;
    bool is_valid = true;
    auto it = show_tag_category_dict->find(nlp::util::NormalizeLine(fea_tag));
    if (it != show_tag_category_dict->end()) {
      bool category_match = false;
      if (is_null_category) {
        category_match = true;
      } else {
        for (auto it_set = category_list.begin(); it_set != category_list.end(); it_set++) {
          if (it->second.find(*it_set) != it->second.end()) {
            category_match = true;
            break;
          }
        }
      }
      if (!category_match) {
        is_valid = false;
      }
    }

    if (is_valid) {
      show_tag_list.push_back(fea_tag);
      count += 1;
      VLOG(1) << "show tag category passed: " << fea_tag;
      if (count == kShowTagNumLimit) break;
    } else if (i >= 2 && show_tag_list.size() >= 2) {
      // top3 标签都会判断是否可以作为 show tag,第 4 个标签之后的如果前一个不可作为 show tag
      // 且当前 show tag 多于两个后面不会再判断
      break;
    }
  }
  // 将可展示的语义标签添加到展示标签中,需要和已选择的展示标签去重及去包含
  SelectShowTagFromSemanticTag(reco_item, &show_tag_list);
  FilterInvalidShowTag(show_tag_list, reco_item);
}

bool RawItemConvertor::InVideoInvalidTag(const std::string& first_category, const std::string& tag) {
  // 全局黑名单
  auto video_invalid_tag_dict = GlobalDataIns::instance().GetVideoInvalidTagDict();
  auto invalid_tags_it = video_invalid_tag_dict->find("all");
  if (invalid_tags_it != video_invalid_tag_dict->end()) {
    if (invalid_tags_it->second.find(tag) != invalid_tags_it->second.end()) {
      return true;
    }
  }
  // 某个分类下的黑名单
  invalid_tags_it = video_invalid_tag_dict->find(first_category);
  if (invalid_tags_it != video_invalid_tag_dict->end()) {
    if (invalid_tags_it->second.find(tag) != invalid_tags_it->second.end()) {
      return true;
    }
  }
  return false;
}

bool RawItemConvertor::JudgeAmbTag(const std::set<std::string> &attributes, const std::string &tag) {
  // 一个词具有歧义词属性，且具有"歌曲/图书/电影/电视剧/综艺"  中的一种，
  // 则只有当出现在书名号内部时才展现出来
  if (attributes.find("电影") != attributes.end()
      || attributes.find("电视剧") != attributes.end()
      || attributes.find("综艺") != attributes.end()
      || attributes.find("歌曲") != attributes.end()
      || attributes.find("动漫") != attributes.end()
      || attributes.find("游戏") != attributes.end()
      || attributes.find("图书") != attributes.end()) {
    return (book_names_.find(tag) != book_names_.end());
  }
  return true;
}

int RawItemConvertor::IsManualTag(const std::string &first_category,
                                   const std::string &second_category,
                                   const std::string &tag,
                                   const std::unordered_set<std::string> &video_spider_tags) {
  auto dyn_coreword_detail_dict = GlobalDataIns::instance().GetDynCorewordDetailDict();
  auto it_dyn = dyn_coreword_detail_dict->find(tag);
  if (it_dyn != dyn_coreword_detail_dict->end()) {
    if (it_dyn->second.tag_level == 1) {
      current_show_tag_black_.insert(tag);
      VLOG(1) << "add show black:" << tag << ", current_size:" << current_show_tag_black_.size();
    }
    if (it_dyn->second.tag_level >= 1) {
      if (it_dyn->second.is_amb_word && !JudgeAmbTag(it_dyn->second.attributes, tag)) {
        VLOG(1) << "invalid amb tag ! tag:" << tag;
        return -1;
      }
      if ((int)it_dyn->second.categories.size() == 0) {
        VLOG(1) << "dynamic found ! tag: " << tag;
        return 1;
      } else if (it_dyn->second.categories.find(first_category) != it_dyn->second.categories.end()) {
        VLOG(1) << "dynamic found ! tag: " << tag << ", first_category:" << first_category;
        return 1;
      // 限制到娱乐类的标签对时尚类也生效
      } else if (first_category == "时尚" &&
                 it_dyn->second.categories.find("娱乐") != it_dyn->second.categories.end()) {
        VLOG(1) << " entertainment tag mapping to fasion ! tag:" << tag
                << ", first_category:" << first_category;
        return 1;
      // 视频标签候选命中爬虫标签，则取消该候选的类别限制
      } else if (!video_spider_tags.empty() && video_spider_tags.find(tag) != video_spider_tags.end()) {
        VLOG(1) << "video spider tag found ! tag: " << tag;
        return 1;
      } else if (video_source_category_match_) {
        VLOG(1) << "video source category match ! tag:" << tag;
        return 1;
      } else if (!second_category.empty()) {
        std::string category = first_category + ',' + second_category;
        if (it_dyn->second.categories.find(category) != it_dyn->second.categories.end()) {
          VLOG(1) << "dynamic found ! tag: " << tag << ", category:" << category;
          return 1;
        }
      }
    }
  }

  return 0;
}

bool RawItemConvertor::TagCtrCmp(const RawItemConvertor::ShowTagInfo& left,
                                 const RawItemConvertor::ShowTagInfo& right) {
  if (left.ctr != right.ctr) return left.ctr > right.ctr;
  if (left.index != right.index) return left.index < right.index;
  return left.tag <= right.tag;
}

bool RawItemConvertor::TagIndexCmp(const RawItemConvertor::ShowTagInfo& left,
                                   const RawItemConvertor::ShowTagInfo& right) {
  return left.index < right.index;
}

bool RawItemConvertor::TagLengthCmp(const RawItemConvertor::SortTagInfo& left,
                                    const RawItemConvertor::SortTagInfo& right) {
  if (left.length != right.length) return left.length > right.length;
  return left.index < right.index;
}

bool RawItemConvertor::PairValueCmp(const std::pair<std::string, float>& left,
                                    const std::pair<std::string, float>& right) {
  return left.second > right.second;
}

int RawItemConvertor::SearchCoreWord(const std::string &category1,
    const std::string &category2, const std::string &word) {
  std::string total_category = category1;
  if (!category2.empty()) {
    total_category.append(",");
    total_category.append(category2);
  }

  auto dyn_coreword_detail_dict = GlobalDataIns::instance().GetDynCorewordDetailDict();
  auto it_dyn = dyn_coreword_detail_dict->find(word);
  if (it_dyn != dyn_coreword_detail_dict->end()) {
    if (it_dyn->second.categories.size() == 0
        || it_dyn->second.categories.find(category1) != it_dyn->second.categories.end()) {
      auto it_inner = it_dyn->second.extend_dict.find(total_category);
      if (it_inner == it_dyn->second.extend_dict.end()) {
        if (!category2.empty()) {
          it_inner = it_dyn->second.extend_dict.find(category1);
        }
      }
      if (it_inner != it_dyn->second.extend_dict.end()) {
        return (it_dyn->second.tag_level >= 1) ? 2 : 1;
      }
    }
  }

  return 0;
}

bool RawItemConvertor::GetExtendTags(const std::string &category1,
    const std::string &category2, const std::string &word,
    int *can_show, std::vector<std::string> *extend_tags) {
  std::string total_category = category1;
  if (!category2.empty()) {
    total_category.append(",");
    total_category.append(category2);
  }

  *can_show = 0;
  auto dyn_coreword_detail_dict = GlobalDataIns::instance().GetDynCorewordDetailDict();
  auto it_dyn = dyn_coreword_detail_dict->find(word);
  if (it_dyn != dyn_coreword_detail_dict->end()) {
    if (it_dyn->second.categories.size() == 0
        || it_dyn->second.categories.find(category1) != it_dyn->second.categories.end()) {
      auto it_inner = it_dyn->second.extend_dict.find(total_category);
      if (it_inner == it_dyn->second.extend_dict.end()) {
        if (!category2.empty()) {
          it_inner = it_dyn->second.extend_dict.find(category1);
        }
      }
      if (it_inner != it_dyn->second.extend_dict.end()) {
        *can_show = (it_dyn->second.tag_level >= 1) ? 2 : 1;
        for (int j = 0; j < (int)it_inner->second.size(); ++j) {
          extend_tags->push_back((it_inner->second)[j]);
        }
        return extend_tags->size() > 0;
      }
    }
  }

  return false;
}
void inline TransTopci2FeatureVector(const std::vector<Topic>& topics, FeatureVector* fv) {
  fv->set_norm(1.0);
  fv->clear_feature();
  for (size_t i = 0; i < topics.size(); ++i) {
    const Topic& topic = topics[i];
    auto it = fv->add_feature();
    it->set_literal(base::StringPrintf("topic-%d", topic.tid));
    it->set_weight(topic.prob);
  }
}
void RawItemConvertor::ExtractLDATopicFeature(const std::string& title,
                                              const std::string& content,
                                              RecoItem* item) {
  std::vector<Topic> topics;
  // title lda
  lda_util_->infer(ModelType::LDA, title, topics);
  auto title_lda = item->mutable_title_lda();
  TransTopci2FeatureVector(topics, title_lda);
}
void RawItemConvertor::ExtractThemeLDATopicFeature(const std::string& title,
                                                   const std::string& content,
                                                   RecoItem* item) {
  // TODO(lirong) 按照一定阈值进行截取 topic ,防止出现噪音
  std::vector<Topic> topics;
  // title lda
  /*lda_util_->infer(ModelType::LDA, title, topics);
  auto title_lda = item->mutable_title_lda();
  TransTopci2FeatureVector(topics, title_lda);
  VLOG(1) << "subject id:" << item->identity().item_id() << ","
          << "title : " << title << ","
          << "title lda size : " << topics.size();
  */
  // content lda
  topics.clear();
  std::string nor_content = title;  // 加入主题本身的标题,丰富内容
  int subitems_num = 0;
  for (size_t i = 0; i < child_items_->size(); ++i) {
    if (subitems_num > FLAGS_subject_lda_subitem_num) {
      break;
    }
    subitems_num++;
    const RecoItem& child_item = child_items_->at(i);
    nor_content += nlp::util::NormalizeLine(child_item.normalized_title()) + " ";
  }
  lda_util_->infer(ModelType::LDA, nor_content, topics);
  // auto content_lda = item->mutable_content_lda();
  auto title_lda = item->mutable_title_lda();  // 存储在 title_lda ，为了和文本的正文做区分
  TransTopci2FeatureVector(topics, title_lda);
  VLOG(2) << "subject id:" << item->identity().item_id() << ","
          << "content lda size : " << topics.size() << ","
          << "content : " << nor_content << ","
          << "subitems size : " << child_items_->size();
}
}  // namespace reco
