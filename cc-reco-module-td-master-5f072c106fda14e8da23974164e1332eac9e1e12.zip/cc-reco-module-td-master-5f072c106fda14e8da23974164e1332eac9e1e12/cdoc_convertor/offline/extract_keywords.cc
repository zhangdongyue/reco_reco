#include <unordered_map>
#include <unordered_set>
#include <iostream>
#include <string>
#include <fstream>
#include <cmath>

#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"

#include "nlp/common/nlp_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"

DEFINE_string(src_file, "news file", "input news file");
DEFINE_string(idf_file, "idf.txt", "output idf file");
DEFINE_string(res_file, "result.txt", "res file");
DEFINE_int32(thread_num, 8, "output idf file");

void ReadIdf(std::unordered_map<std::string, float>* idf_dict) {
  std::vector<std::string> lines;
  base::FilePath idf_file(FLAGS_idf_file);
  CHECK(base::file_util::ReadFileToLines(idf_file, &lines));
  std::vector<std::string> flds;
  double idf = 0;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 3u) {
      LOG(ERROR) << "error idf line, " << lines[i];
      continue;
    }
    CHECK(base::StringToDouble(flds[2], &idf));
    (*idf_dict)[flds[0]] = (float)idf;
  }
}

bool IsFilteredByPostag(const nlp::term::TermInfo& info) {
  if (info.is_postag(nlp::term::kWhiteSpace)
      || info.is_postag(nlp::term::kPunctuation)
      || info.is_postag(nlp::term::kPreposition)
      || info.is_postag(nlp::term::kAuxiliary)
      || info.is_postag(nlp::term::kExclamation)) {
    return true;
  }
  return false;
}

void CalcDocTf(const nlp::term::TermContainer& container, const std::string& content, bool is_title,
               std::unordered_map<std::string, float> * kw_tf_vec) {
  const float kTitleEntityWt  = 2;
  const float kTitleBigramWt  = 1.5;
  const float kTitleTrigramWt = 1.5;
  const float kTitleUnigramWt = 1.25;

  const float kContentEntityWt  = 1.5;
  const float kContentBigramWt  = 1.25;
  const float kContentTrigramWt = 1.25;
  const float kContentUnigramWt = 1;

  std::string term;
  // entity
  for (int j = 0; j < container.entity_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.entity_term_info(j);
    if (info.is_postag(nlp::term::kWhiteSpace)
        || info.is_postag(nlp::term::kPunctuation)) {
      continue;
    }
    term = info.term(content).as_string();
    (*kw_tf_vec)[term] += is_title ? kTitleEntityWt : kContentEntityWt;
  }
  // unigram
  for (int j = 0; j < container.basic_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.basic_term_info(j);
    // 处于专名下
    if (info.entity_index != -1) {
      continue;
    }
    if (IsFilteredByPostag(info) || info.rune_len <= 1) {
      continue;
    }
    term = info.term(content).as_string();
    (*kw_tf_vec)[term] += is_title ? kTitleUnigramWt : kContentUnigramWt;
  }
  // bigram
  for (int j = 0; j < container.basic_term_num() - 1; ++j) {
    const nlp::term::TermInfo& info1 = container.basic_term_info(j);
    const nlp::term::TermInfo& info2 = container.basic_term_info(j + 1);
    if (IsFilteredByPostag(info1)
        || (IsFilteredByPostag(info2) && !info2.is_postag(nlp::term::kWhiteSpace))) {
      continue;
    }
    if (!info2.is_postag(nlp::term::kWhiteSpace)) {
      term = info1.term(content).as_string() + info2.term(content).as_string();
    } else if (j < container.basic_term_num() - 2) {
      const nlp::term::TermInfo& info3 = container.basic_term_info(j + 2);
      term = info1.term(content).as_string() + info3.term(content).as_string();
      if (IsFilteredByPostag(info3)) {
        continue;
      }
      term = info1.term(content).as_string() + info3.term(content).as_string();
    } else {
      continue;
    }
    (*kw_tf_vec)[term] += is_title ? kTitleBigramWt : kContentBigramWt;
  }
  // trigram
  for (int j = 0; j < container.basic_term_num() - 2; ++j) {
    const nlp::term::TermInfo& info1 = container.basic_term_info(j);
    const nlp::term::TermInfo& info2 = container.basic_term_info(j + 1);
    const nlp::term::TermInfo& info3 = container.basic_term_info(j + 2);
    // if (info1.entity_index != -1 || info2.entity_index != -1 || info3.entity_index != -1) {
    //   continue;
    // }
    if (IsFilteredByPostag(info1)
        || info2.is_postag(nlp::term::kPunctuation)
        || IsFilteredByPostag(info3)) {
      continue;
    }
    term = info1.term(content).as_string() + info2.term(content).as_string() +
        info3.term(content).as_string();
    (*kw_tf_vec)[term] += is_title ? kTitleTrigramWt : kContentTrigramWt;
  }
}

void CalcDocTfIdf(const nlp::term::TermContainer& title_container, const std::string& title,
                  const nlp::term::TermContainer& content_container, const std::string& content,
                  const std::unordered_map<std::string, float>& kw_idf_map,
                  std::vector<std::pair<float, std::string> >* kw_tfidf_vec) {
  std::unordered_map<std::string, float> kw_tf_map;

  // title tf
  CalcDocTf(title_container, title, true, &kw_tf_map);

  // content tf
  CalcDocTf(content_container, content, false, &kw_tf_map);

  // calc tf-idf
  for (auto iter = kw_tf_map.begin(); iter != kw_tf_map.end(); ++iter) {
    if (iter->second <= 1) continue;
    auto idf_iter = kw_idf_map.find(iter->first);
    if (idf_iter == kw_idf_map.end()) {
      continue;
    }
    kw_tfidf_vec->push_back(std::make_pair(iter->second * idf_iter->second, iter->first));
  }
  std::sort(kw_tfidf_vec->begin(), kw_tfidf_vec->end(), std::greater<std::pair<float, std::string> >());

  // top
  int term_num = title_container.basic_term_num() + title_container.entity_term_num() +
      content_container.basic_term_num() + content_container.entity_term_num();
  int limit_num = std::min(term_num / 10, 10);
  limit_num = std::min(limit_num, (int)kw_tfidf_vec->size());

  kw_tfidf_vec->resize(limit_num);
}

void work(std::vector<std::string>* lines,
          std::unordered_map<std::string, float>* idf_dict,
          std::vector<std::string>* results,
          int thread_id) {
  CHECK_EQ(lines->size(), results->size());

  nlp::segment::Segmenter segmenter;
  nlp::postag::PosTagger postagger;
  nlp::ner::Ner ner;

  std::string title;
  std::string content;
  nlp::term::TermContainer title_container;
  nlp::term::TermContainer content_container;

  std::vector<std::string> flds;
  std::vector<std::pair<float, std::string> > kw_tfidf_vec;
  for (int i = thread_id; i < (int)lines->size(); i += FLAGS_thread_num) {
    LOG_EVERY_N(INFO, 1000) << "thread " << thread_id << " parse " << i << "th line.";
    flds.clear();
    base::SplitString((*lines)[i], "\t", &flds);
    if (flds.size() != 3) {
      LOG(ERROR) << "error line, " << (*lines)[i];
      continue;
    }
    title = nlp::util::NormalizeLine(flds[1]);
    content = nlp::util::NormalizeLine(flds[2]);
    if (title.empty() || content.empty()) {
      LOG(ERROR) << "title or content is empty. index: " << i;
      continue;
    }
    if (!segmenter.SegmentT(title, &title_container)
        || !postagger.PosTagT(title, &title_container)
        || !ner.DetectEntityT(title, &title_container)
        || !segmenter.SegmentT(content, &content_container)
        || !postagger.PosTagT(content, &content_container)
        || !ner.DetectEntityT(content, &content_container)) {
      LOG(ERROR) << "segment fail, " << (*lines)[i];
      continue;
    }
    kw_tfidf_vec.clear();
    CalcDocTfIdf(title_container, title, content_container, content, *idf_dict, &kw_tfidf_vec);
    std::string& keyword_list = (*results)[i];
    keyword_list = base::StringPrintf("%d\t%s\t", i, flds[0].c_str());
    for (int j = 0; j < (int)kw_tfidf_vec.size(); ++j) {
      if (j != 0) keyword_list.append(",");
      keyword_list.append(base::StringPrintf("%s:%.3f", kw_tfidf_vec[j].second.c_str(),
                                             kw_tfidf_vec[j].first));
    }
    (*lines)[i].clear();
  }
}

void ExtractKeywords() {
  // read idf dict
  LOG(INFO) << "load idf dict...";
  std::unordered_map<std::string, float> idf_dict;
  ReadIdf(&idf_dict);
  LOG(INFO) << "succ to load idf dict.";

  LOG(INFO) << "read src file...";
  std::vector<std::string> lines;
  base::FilePath src_file(FLAGS_src_file);
  CHECK(base::file_util::ReadFileToLines(src_file, &lines));
  LOG(INFO) << "succ to read src file. total record num: " << lines.size();

  std::vector<std::string> results;
  results.resize(lines.size());
  thread::ThreadPool pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(NewCallback(work, &lines, &idf_dict, &results, i));
  }
  pool.JoinAll();
  lines.clear();

  std::ofstream os(FLAGS_res_file);
  for (int i = 0; i < (int)results.size(); ++i) {
    os << results[i] << std::endl;
  }
  os.close();
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "extract keywords.");

  ExtractKeywords();

  return 0;
}
