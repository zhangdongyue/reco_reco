#include <unordered_map>
#include <unordered_set>
#include <iostream>
#include <string>
#include <fstream>
#include <cmath>

#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"

#include "nlp/common/nlp_util.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"

DEFINE_string(input_file, "news file", "input news file");
DEFINE_string(output_file, "idf.txt", "output idf file");
DEFINE_int32(thread_num, 8, "output idf file");

void parseTerms(const nlp::term::TermContainer& container,
                const std::string& content,
                std::unordered_map<std::string, uint64>* term_counters) {
  std::unordered_set<std::string> uniq_set;
  // entity
  std::string term;
  for (int j = 0; j < container.entity_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.entity_term_info(j);
    if (info.is_postag(nlp::term::kWhiteSpace) || info.is_postag(nlp::term::kPunctuation)) {
      continue;
    }
    uniq_set.insert(info.term(content).as_string());
  }

  // unigram
  for (int j = 0; j < container.basic_term_num(); ++j) {
    const nlp::term::TermInfo& info = container.basic_term_info(j);
    if (info.is_postag(nlp::term::kWhiteSpace) || info.is_postag(nlp::term::kPunctuation)) {
      continue;
    }
    uniq_set.insert(info.term(content).as_string());
  }

  // bigram
  for (int j = 0; j < container.basic_term_num() - 1; ++j) {
    const nlp::term::TermInfo& info1 = container.basic_term_info(j);
    const nlp::term::TermInfo& info2 = container.basic_term_info(j + 1);
    if (info1.is_postag(nlp::term::kWhiteSpace) || info1.is_postag(nlp::term::kPunctuation)
        || info2.is_postag(nlp::term::kPunctuation)) {
      continue;
    }
    if (!info2.is_postag(nlp::term::kWhiteSpace)) {
      term = info1.term(content).as_string() + info2.term(content).as_string();
    } else if (j < container.basic_term_num() - 2) {
      const nlp::term::TermInfo& info3 = container.basic_term_info(j + 2);
      if (info3.is_postag(nlp::term::kPunctuation)) {
        continue;
      }
      term = info1.term(content).as_string() + info3.term(content).as_string();
    } else {
      continue;
    }
    uniq_set.insert(term);
  }

  // trigram
  for (int j = 0; j < container.basic_term_num() - 2; ++j) {
    const nlp::term::TermInfo& info1 = container.basic_term_info(j);
    const nlp::term::TermInfo& info2 = container.basic_term_info(j + 1);
    const nlp::term::TermInfo& info3 = container.basic_term_info(j + 2);
    if (info1.is_postag(nlp::term::kWhiteSpace) || info1.is_postag(nlp::term::kPunctuation)
        || info2.is_postag(nlp::term::kPunctuation)
        || info3.is_postag(nlp::term::kPunctuation) || info3.is_postag(nlp::term::kWhiteSpace)) {
      continue;
    }
    term = info1.term(content).as_string() + info2.term(content).as_string() +
        info3.term(content).as_string();
    uniq_set.insert(term);
  }

  for (auto iter = uniq_set.begin(); iter != uniq_set.end(); ++iter) {
    (*term_counters)[*iter] += 1;
  }
}

void work(std::vector<std::string>* lines,
          std::unordered_map<std::string, uint64>* term_counters,
          int thread_id) {
  nlp::segment::Segmenter segmenter;
  nlp::postag::PosTagger postagger;
  nlp::ner::Ner ner;

  term_counters->clear();

  std::string content;
  std::vector<std::string> flds;
  nlp::term::TermContainer container;
  for (int i = thread_id; i < (int)lines->size(); i += FLAGS_thread_num) {
    LOG_EVERY_N(INFO, 1000) << "thread" << thread_id << ", parse the " << i << " th line.";
    flds.clear();
    base::SplitString((*lines)[i], "\t", &flds);
    if (flds.size() != 3) {
      LOG(ERROR) << "error line, " << (*lines)[i];
      continue;
    }
    content = nlp::util::NormalizeLine(flds[1]) + " " + nlp::util::NormalizeLine(flds[2]);
    if (content.size() < 100) {
      continue;
    }
    if (!segmenter.SegmentT(content, &container)
        || !postagger.PosTagT(content, &container)
        || !ner.DetectEntityT(content, &container)) {
      LOG(ERROR) << "segment fail, " << content;
      continue;
    }

    parseTerms(container, content, term_counters);
    (*lines)[i] = "";
  }

  LOG(ERROR) << "thread " << thread_id << " done, term num: " << term_counters->size();
}

void CalcIdf() {
  std::vector<std::string> lines;
  base::FilePath input_file(FLAGS_input_file);
  CHECK(base::file_util::ReadFileToLines(input_file, &lines));
  LOG(INFO) << "total input file: " << lines.size();

  uint64 doc_num = lines.size();

  std::vector<std::unordered_map<std::string, uint64> > results;
  results.resize(FLAGS_thread_num);
  thread::ThreadPool pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(NewCallback(work, &lines, &(results[i]), i));
  }
  pool.JoinAll();

  lines.swap(std::vector<std::string>());

  std::unordered_map<std::string, uint64>& term_counters = results[0];
  for (size_t i = 1; i < results.size(); ++i) {
    std::unordered_map<std::string, uint64>& result = results[i];
    for (auto iter = result.begin(); iter != result.end(); ++iter) {
      term_counters[iter->first] += iter->second;
    }
    result.swap(std::unordered_map<std::string, uint64>());
  }

  LOG(INFO) << "write result start.";
  std::ofstream os(FLAGS_output_file);
  for (auto iter = term_counters.begin(); iter != term_counters.end(); ++iter) {
    if (iter->second <= 5) continue;
    double idf = std::log(doc_num * 1.0 / iter->second);
    os << base::StringPrintf("%s\t%lu\t%.3f\n", iter->first.c_str(), iter->second, idf);
  }
  LOG(INFO) << "write result finish.";
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "calc idf");
  CHECK_GT(FLAGS_thread_num, 0);

  CalcIdf();

  return 0;
}
