#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/file/file_util.h"

#include "reco/module/cdoc_convertor/perf/press_worker.h"
#include "reco/module/cdoc_convertor/perf/press_responser.h"

#include "base/common/sleep.h"
#include "reco/module/cdoc_convertor/perf/define.h"
#include "reco/module/cdoc_convertor/tool/subject_utils.h"

DEFINE_int32(thread_num, 8, "thread num for send request");
DEFINE_string(item_id_file, "", "file contains item id");

DEFINE_string(doc_server_ips, "100.85.69.71", "doc server ips, splitted by ,");
DEFINE_int32(doc_server_port, 20013, "doc server port");
DEFINE_int32(doc_num, 100000, "max doc num from doc server.");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "press tool");

  reco::DocServerGetItem* doc_get_item =
        new reco::DocServerGetItem(FLAGS_doc_server_ips, FLAGS_doc_server_port, 0);
  thread::BlockingQueue<reco::RecoItem> item_queue;
  std::unordered_map<int64, std::vector<reco::RecoItem>> subitems_map;
  LOG(ERROR) << "preparing request data, please wait...";

  int subitem_num = 0;
  int item_num = 0;
  if (!FLAGS_item_id_file.empty()) {
    std::vector<std::string> lines;
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines);
    for (int i = 0; i < (int)lines.size() && i < FLAGS_doc_num; ++i) {
      base::TrimTrailingWhitespaces(&(lines[i]));

      reco::RecoItem reco_item;
      if (!doc_get_item->GetRecoItem(base::ParseUint64OrDie(lines[i]), &reco_item)) {
        LOG(ERROR) << "failed to get reco item: " << lines[i];
        continue;
      }
      item_queue.Put(reco_item);
      item_num++;
      if (reco_item.identity().type() == reco::kThemeVideo) {
        std::vector<reco::RecoItem> subitems_vec;
        get_subject_subitems(reco_item, &subitems_vec, doc_get_item, 10);
        subitems_map.insert(std::make_pair(reco_item.identity().item_id(), subitems_vec));
        subitem_num += subitems_vec.size();
      }
    }
  }

  LOG(INFO) << "item size : " << item_num << " childs : " << subitem_num;
  thread::BlockingQueue<ResponseDumpInfo*> response_queue;
  reco::PressResponser responser(&response_queue);

  std::vector<reco::PressWorker*> workers;
  int total_workers = FLAGS_thread_num;

  thread::ThreadPool pool(total_workers + 1);
  for (int i = 0; i < total_workers; ++i) {
    workers.push_back(new reco::PressWorker(&item_queue, &response_queue, &subitems_map));
    pool.AddTask(::NewCallback<reco::PressWorker, int>(workers.back(), &reco::PressWorker::run, i));
  }
  pool.AddTask(::NewCallback<reco::PressResponser>(&responser, &reco::PressResponser::run));

  while (total_workers > 0) {
    base::SleepForMilliseconds(200);
    total_workers = 0;
    for (int i = 0; i < (int)workers.size(); ++i) {
      if (workers[i]->running()) {
        ++total_workers;
      }
    }
  }
  response_queue.Close();
  responser.stop();

  pool.JoinAll();
  return 0;
}
