#pragma once
#include <unordered_map>
#include <vector>

#include "base/common/basic_types.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "reco/module/cdoc_convertor/perf/define.h"
#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "reco/bizc/proto/item_handler.pb.h"
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "serving_base/utility/timer.h"
#include "base/time/timestamp.h"
#include "base/common/sleep.h"
#include "net/rpc/rpc.h"

DEFINE_int32(time_slice, 1000, "time slice in ms");
DEFINE_int32(min_num_in_slice, 1, "min num sample in slice");

DEFINE_string(convertor_server_ip, "100.85.69.71", "server ip");
DEFINE_int32(convertor_server_port, 20021, "server port");

DEFINE_int32(qps, 100, "qps");
DEFINE_int64(total_request, 10000, "total request");
DEFINE_int32(api, 0,
             "API: 0-convertRawItem, 1-convertRecoItem, 2-extractFeature,"
             " 3-pushRecoItemToCDocQueue, 4-updateItem");

DEFINE_bool(is_return_tag, true, "");
DEFINE_bool(is_return_keyword, true, "");
DEFINE_bool(is_return_bow, true, "");
DEFINE_bool(is_return_plsa, true, "");
DEFINE_bool(is_return_category_plsa, true, "");
DEFINE_bool(is_return_category, true, "");
DEFINE_bool(is_return_rubbish, true, "");

namespace reco {
class PressWorker {
 private:
  atomic_bool running_;
  int qps_;
  int64 total_request_;

  thread::BlockingQueue<RecoItem>* item_queue_;
  thread::BlockingQueue<ResponseDumpInfo*>* response_queue_;
  std::unordered_map<int64, std::vector<reco::RecoItem> >* subitems_map_;
  int queue_buff_size_;

 public:
  bool running() {
    return running_;
  }

  PressWorker(thread::BlockingQueue<RecoItem>* item_queue,
              thread::BlockingQueue<ResponseDumpInfo*>* response_queue,
              std::unordered_map<int64, std::vector<reco::RecoItem> >* subitems_map) {
    running_ = true;
    qps_ = FLAGS_qps;
    total_request_ = FLAGS_total_request;
    queue_buff_size_ = qps_ * 1000;

    item_queue_ = item_queue;
    response_queue_ = response_queue;
    subitems_map_ = subitems_map;
  }

  void run(int thread_id) {
    running_ = true;
    float coeff = qps_ / 1000.0;
    float p_gain = coeff * FLAGS_time_slice;
    if (p_gain < FLAGS_min_num_in_slice) {
      p_gain = FLAGS_min_num_in_slice;
    }
    int time_slice = (int) (p_gain / coeff);  // in ms
    int grain_num = (int) p_gain;  // num in slice

    LOG(INFO) << "Thread " << thread_id << " start.";

    int64 send_num = 0;
    int64 start = 0;
    int64 tick = -1;
    bool from_begin = true;
    int total_send = 0;
    int total_err = 0;
    int subitem_num = 0;

    net::rpc::RpcClientChannel channel(FLAGS_convertor_server_ip, FLAGS_convertor_server_port);
    CHECK(channel.Connect());
    reco::convertor::ConvertorService::Stub stub(&channel);
    reco::itemhandler::ItemHandler::Stub handler_stub(&channel);

    int64 very_start = base::GetTimestamp();

    while (running_) {
      if (send_num >= grain_num) {
        tick = base::GetTimestamp() / 1000;
        int64 time_consume = tick - start;
        if (time_consume <= time_slice) {
          base::SleepForMilliseconds(time_slice - time_consume);
        }
        from_begin = true;
        send_num = 0;
      }

      if (from_begin) {
        start = base::GetTimestamp() / 1000;
        from_begin = false;
      }

      reco::RecoItem reco_item = item_queue_->Take();
      item_queue_->Put(reco_item);

      ResponseDumpInfo* dumpInfo = new ResponseDumpInfo();
      dumpInfo->send_timestamp = base::GetTimestamp() / 1000;

      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(120);

      if (FLAGS_api == 0) {
        /*
        reco::convertor::ConvertRawItemRequest request;
        reco::convertor::ConvertRawItemResponse response;

        request.mutable_raw_item()->CopyFrom(reco_item.raw_item());
        request.set_convert_to_reco(true);
        request.set_convert_to_cdoc(true);

        stub.convertRawItem(&rpc, &request, &response, NULL);
        rpc.Wait();
        if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
          LOG(ERROR) << "convert raw item failed. " << response.err_msg();
        } else {
          dumpInfo->response_timestamp = base::GetTimestamp() / 1000;
          dumpInfo->body_size = response.ByteSize();
          dumpInfo->status = 200;
        }
        */
      } else if (FLAGS_api == 1) {
        reco::convertor::ConvertRecoItemRequest request;
        reco::convertor::ConvertRecoItemResponse response;

        request.mutable_reco_item()->CopyFrom(reco_item);

        stub.convertRecoItem(&rpc, &request, &response, NULL);
        rpc.Wait();
        if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
          LOG(ERROR) << "convert raw item failed. " << response.err_msg();
        } else {
          dumpInfo->response_timestamp = base::GetTimestamp() / 1000;
          dumpInfo->body_size = response.ByteSize();
          dumpInfo->status = 200;
        }
      } else if (FLAGS_api == 2) {
        reco::convertor::ExtractFeatureRequest request;
        reco::convertor::ExtractFeatureResponse response;

        request.set_title(reco_item.title());
        request.set_content(reco_item.content());
        for (int i = 0; i < reco_item.category_size(); i++) {
          request.add_category(reco_item.category(i));
        }
        request.set_return_tag(FLAGS_is_return_tag);
        request.set_return_keyword(FLAGS_is_return_keyword);
        request.set_return_bow(FLAGS_is_return_bow);
        request.set_return_plsa(FLAGS_is_return_plsa);
        request.set_return_category_plsa(FLAGS_is_return_category_plsa);
        request.set_return_category(FLAGS_is_return_category);
        request.set_return_rubbish(FLAGS_is_return_rubbish);

        stub.extractFeature(&rpc, &request, &response, NULL);
        rpc.Wait();
        if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
          LOG(ERROR) << "extract feature failed. " << response.err_msg();
        } else {
          dumpInfo->response_timestamp = base::GetTimestamp() / 1000;
          dumpInfo->body_size = response.ByteSize();
          dumpInfo->status = 200;
        }
      } else if (FLAGS_api == 3) {
        reco::convertor::PushRecoItemToCDocQueueRequest request;
        reco::convertor::PushRecoItemToCDocQueueResponse response;

        request.mutable_reco_item()->CopyFrom(reco_item);
        stub.pushRecoItemToCDocQueue(&rpc, &request, &response, NULL);
        rpc.Wait();
        if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
          LOG(ERROR) << "extract feature failed. " << response.err_message();
        } else {
          dumpInfo->response_timestamp = base::GetTimestamp() / 1000;
          dumpInfo->body_size = response.ByteSize();
          dumpInfo->status = 200;
        }
      } else if (FLAGS_api == 4) {
        reco::itemhandler::ItemHandlerRequest request;
        reco::itemhandler::ItemHandlerResponse response;

        request.mutable_reco_item()->CopyFrom(reco_item);
        if (reco_item.identity().type() == reco::kThemeVideo) {
          auto iter = subitems_map_->find(reco_item.identity().item_id());
          if (iter != subitems_map_->end()) {
            std::vector<RecoItem>& subitems_vec = iter->second;
            for (size_t j = 0; j < subitems_vec.size(); ++j) {
               request.add_child_items()->CopyFrom(subitems_vec.at(j));
            }
          } else {
            LOG(ERROR) << "no childs : " << reco_item.identity().item_id() << ","
                       << "item id : " << reco_item.identity().item_id();
          }
        }
        subitem_num += request.child_items_size();
        handler_stub.updateItem(&rpc, &request, &response, NULL);
        rpc.Wait();
        if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
          LOG(ERROR) << "extract feature failed. " << response.err_message();
        } else {
          dumpInfo->response_timestamp = base::GetTimestamp() / 1000;
          dumpInfo->body_size = response.ByteSize();
          dumpInfo->status = 200;
        }
      }

      if (response_queue_->Size() > queue_buff_size_) {
        LOG(INFO) << "response queue is full, sleep for 10 ms";
        base::SleepForMilliseconds(10);
      }

      // should alway be success to add
      response_queue_->Put(dumpInfo);

      ++total_send;
      ++send_num;
      if (total_send > total_request_) {
        running_ = false;
        break;
      }
    }

    int64 total_time = (base::GetTimestamp() - very_start) / 1000;
    int thread_qps = total_send / (total_time / 1000);
    LOG(INFO) << base::StringPrintf(
        "Thread %d end, total send: %d total err: %d, total consume: %ld ms, qps:%d, subitems:%d",
        thread_id, total_send, total_err, total_time, thread_qps, subitem_num);
  }
};
}
