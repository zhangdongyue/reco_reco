#include "reco/module/item_level/updater/item_ctr_updater.h"

#include <utility>  // for pair
#include <vector>
#include <fstream>

#include "reco/module/item_level/base/redis_util.h"
#include "reco/module/item_level/base/connection_manager.h"
#include "reco/bizc/common/appname_define.h"
#include "serving_base/utility/time_helper.h"
#include "extend/json/jansson/jansson.h"
#include "net/counter/export.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/time/timestamp.h"

namespace reco {
namespace item_level {

DEFINE_int32(show_partition_num, 32, "");
DEFINE_int32(click_partition_num, 32, "");
DEFINE_string(kafka_brokers, "", "必须外部指定");
DEFINE_string(kafka_show_topic_name, "", "show log topic name");
DEFINE_string(kafka_click_topic_name, "", "show log topic name");
DEFINE_int32(kafka_consume_offset, -2, "kafka consume offset");
DEFINE_int32(kafka_backtrack_hours, 24 * 7, "kafka backtrack hours");
DEFINE_int32(kafka_consume_timeout_ms, 5000, "kafka timeout ms");
DEFINE_string(kafka_timestamp_store_path, "../kafka_timestamp", "kafka timestamp store path");

DEFINE_int32(redis_record_expire_seconds, 3600*24, "time interval to inc update item info in seconds.");
DEFINE_int32(update_stats_redis_seconds, 600, "time interval to update redis data in seconds.");
DEFINE_int32(update_stats_timestamp_seconds, 60, "time interval to update timestamp in seconds.");

DEFINE_int32(store_stats_disk_seconds, 3600, "time interval to write stats to disk in seconds.");
DEFINE_string(store_stats_disk_dir, "../dump_data", "item stats data path");
DEFINE_int32(store_stats_expire_days, 30, "item stats expire days");
DEFINE_int32(dedup_click_expire_hours, 4, "");

DEFINE_bool(open_batch_update_memory_item_switch, true, "if batch");
DEFINE_bool(skip_write_ctr_to_redis, false, "if write redis");
DEFINE_bool(write_redis_when_startup, false, "if write redis at when startup");

DEFINE_bool(if_only_use_iflow_data, false, "if only use iflow data");

DEFINE_string(data_dir, "../data", "item stats data path");

DEFINE_int64_counter(joiner, parse_click_log_failed, 0, "解析点击日志");
DEFINE_int64_counter(joiner, parse_show_log_failed, 0, "解析点击日志");
DEFINE_int64_counter(joiner, put_total_item_num, 0, "解析点击日志");

const char* ItemCtrUpdater::kGlobalItemDataStoreFile = "item_data.txt";
const char* ItemCtrUpdater::kShowTopicTimeStampStoreFile = "show_topic.stamp";
const char* ItemCtrUpdater::kClickTopicTimeStampStoreFile = "click_topic.stamp";
const uint32 ItemCtrUpdater::kMaxShowLimit = std::numeric_limits<uint32_t>::max() / 2;
const std::unordered_set<std::string> ItemCtrUpdater::kValidAppNames = {
  reco::common::kUCBIflowUser, reco::common::kTuDouAppUser, reco::common::kYouKuAppUser,
};

ItemCtrUpdater::ItemCtrUpdater() {
  redis_util_ = new RedisUtil();

  item_ctr_dict_.set_empty_key(0);
  item_ctr_dict_.rehash(kItemCtrDictRehashSize);

  LoadItemCtrDataFromDisk();

  if (FLAGS_write_redis_when_startup) {
    last_update_redis_time_ = base::Time::Now() - base::TimeDelta::FromDays(7);
    WriteItemDataToRedis(item_ctr_dict_);
    last_update_redis_time_ = base::Time::Now();
  }
  dedup_clicks_ = NULL;
  if (FLAGS_dedup_click_expire_hours > 0) {
    dedup_clicks_ = new serving_base::ExpiryMap<std::string, int>(3600 * FLAGS_dedup_click_expire_hours);
  }
}

ItemCtrUpdater::~ItemCtrUpdater() {
  Stop();
  delete redis_util_;
  delete show_consumer_;
  delete click_consumer_;
  if (dedup_clicks_ != NULL) {
    delete dedup_clicks_;
  }
}

void ItemCtrUpdater::LoadItemCtrDataFromDisk() {
  base::FilePath root_dir(FLAGS_data_dir);
  base::FilePath store_file = root_dir.Append(kGlobalItemDataStoreFile);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(store_file, &lines)) {
    LOG(WARNING) << "item ctr data store file does not exist, " << store_file.ToString();
    return;
  }
  LOG(INFO) << "begin to load item ctr data from disk, total num " << lines.size();

  base::Time curr_time = base::Time::Now();
  std::string str_curr_time;
  curr_time.ToStringInSeconds(&str_curr_time);
  // 只要更新时间不是太久前的数据
  base::Time expire_time = curr_time - base::TimeDelta::FromDays(FLAGS_store_stats_expire_days);

  // LogData env;
  uint64 item_id;
  ItemCtrData env;
  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 5u) {
      LOG(WARNING) << "error flds num, " << lines[i].size();
      continue;
    }
    // parse
    CHECK(base::StringToUint64(flds[0], &item_id));
    // CHECK(base::StringToUint(flds[1], &env.total_show));
    // CHECK(base::StringToUint(flds[2], &env.total_click));
    // CHECK(base::StringToUint64(flds[3], &env.total_duration));
    if (!base::StringToUint(flds[1], &env.total_show)
        || !base::StringToUint(flds[2], &env.total_click)
        || !base::StringToUint64(flds[3], &env.total_duration)) continue;

    if (flds.size() >= 5u
        && base::Time::FromStringInSeconds(flds[4].c_str(), &env.recent_update_time)) {
    } else {
      env.recent_update_time = base::Time::Now();
    }

    // 太久没更新的数据不要了，重新累积
    if (env.recent_update_time < expire_time) continue;

    item_ctr_dict_.insert(std::make_pair(item_id, env));
  }

  LOG(INFO) << "succ to load item ctr data from disk, total num " << item_ctr_dict_.size();
}

void ItemCtrUpdater::Start() {
  LOG(INFO) << "ItemCtrUpdater starting...";

  startup_time_ = base::Time::Now();

  // joiner thread-safe
  running_ = new std::atomic<bool>(true);
  thread_pool_ = new thread::ThreadPool(FLAGS_show_partition_num + FLAGS_click_partition_num + 1);

  // init kafka
  InitKafka();

  // collect show from show log
  for (int idx = 0; idx < FLAGS_show_partition_num; ++idx) {
    thread_pool_->AddTask(NewCallback(this, &ItemCtrUpdater::GetRecoShowLog, idx));
  }

  // collect click from click log
  for (int idx = 0; idx < FLAGS_click_partition_num; ++idx) {
    thread_pool_->AddTask(NewCallback(this, &ItemCtrUpdater::GetRecoClickLog, idx));
  }

  // update show click data to redis
  thread_pool_->AddTask(NewCallback(this, &ItemCtrUpdater::LoopUpdateItemData));
}

void ItemCtrUpdater::Stop() {
  if (running_) {
    running_ = false;
    thread_pool_->JoinAll();
  }
}

void ItemCtrUpdater::GetRecoShowLog(int idx) {

  // 过滤太久远的展现
  base::Time expire_time = startup_time_ - base::TimeDelta::FromHours(FLAGS_kafka_backtrack_hours);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  base::dense_hash_map<uint64, uint32> item_show_dict;
  item_show_dict.set_empty_key(0);

  LOG(INFO) << "start_to_get_show_log, thread, " << idx;

  uint64 fail_num = 0;
  uint64 add_show_num = 0;
  uint64 add_pv_num = 0;
  uint64 add_fetch_num = 0;
  uint64 dict_item_num = 0;
  uint64 item_id;
  int64 offset = 0;
  reco::log::RecoShowLog show_log;
  reco::kafka::Message msg;
  while (running_->load()) {
    if (add_fetch_num % 10000 == 0) {
      LOG(INFO) << "partition: " << idx
                << ", add_fetch_num: " << add_fetch_num
                << ", add_pv_num: " << add_pv_num
                << ", add_show_num: " << add_show_num
                << ", fail_num: " << fail_num
                << ", dict_size: " << item_ctr_dict_.size()
                << ", offset: " << offset;
    }
    msg.Clear();
    if (!show_consumer_->Consume(&msg)) {
      ++fail_num;
      LOG_IF(INFO, fail_num % 100 == 1) << "FAILED partition: " << idx
                                        << ", offset: " << offset
                                        << ", fail num: " << fail_num;
      base::SleepForMilliseconds(10);
      continue;
    }
    ++add_fetch_num;
    offset = msg.offset;
    thread::AutoLock auto_lock(&show_mutex_);
    show_topic_timestamp_ = msg.timestamp_ms / 1000L;
    if (msg.content.empty()) {
      LOG(INFO) << "fetch kafka show log message is empty";
      continue;
    }
    if (!show_log.ParseFromString(msg.content)) {
      LOG(WARNING) << "parse show log failed";
      COUNTERS_joiner__parse_show_log_failed.Increase(1);
      continue;
    }
    if (FLAGS_if_only_use_iflow_data &&
        kValidAppNames.find(show_log.user().app_token()) == kValidAppNames.end()) {
      VLOG(1) << "app name not valid: " << show_log.user().app_token();
      continue;
    }
    // 测试 channel 不要
    if (show_log.has_channel_id()) {
      if (show_log.channel_id() == 0 || show_log.channel_id() == 600) continue;
    }

    // 老 show， 丢弃
    if (show_log.reco_timestamp() < expire_timestamp) continue;
    // userid = 0 是测试用户,过滤掉
    if (show_log.user().user_id() == 0) continue;

    if (add_pv_num % 10000 == 0) {
      LOG(INFO) << "partition: " << idx
                << ", reco_id: " << show_log.reco_id()
                << ", add pv num: " << add_pv_num
                << ", add show num: " << add_show_num
                << ", show read timestamp: " << TimestampToString(show_log.reco_timestamp());
      if (last_update_redis_time_ <= startup_time_) {
        int sleep_ms = FLAGS_show_partition_num * 10;
        base::SleepForMilliseconds(sleep_ms);
      }
    }

    ++add_pv_num;
    for (auto it = show_log.misc_info().begin(); it != show_log.misc_info().end(); ++it) {
      if (!base::StringToUint64(it->item_id(), &item_id) || item_id <= 1000000) continue;
      ++add_show_num;
      if (FLAGS_open_batch_update_memory_item_switch) {
        ++dict_item_num;
        auto iter = item_show_dict.find(item_id);
        if (iter == item_show_dict.end()) {
          item_show_dict.insert(std::make_pair(item_id, 1));
        } else {
          iter->second += 1;
        }
      } else {
        AddShow(item_id, 1);
      }
    }

    if (dict_item_num >= 2000 && FLAGS_open_batch_update_memory_item_switch) {
      BatchAddShow(item_show_dict);
      base::dense_hash_map<uint64, uint32> swap_dict;
      item_show_dict.swap(swap_dict);
      item_show_dict.set_empty_key(0);
      dict_item_num = 0;
    }
  }
  return;
}

void ItemCtrUpdater::GetRecoClickLog(int idx) {
  // 不要太久远的点击
  base::Time expire_time = startup_time_ - base::TimeDelta::FromHours(FLAGS_kafka_backtrack_hours);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  base::dense_hash_map<uint64, uint32> item_click_dict;
  item_click_dict.set_empty_key(0);

  base::dense_hash_map<uint64, uint64> item_duration_dict;
  item_duration_dict.set_empty_key(0);

  LOG(INFO) << "start_to_get_click_log, thread, " << idx;
  uint64 fail_num = 0;
  uint64 add_fetch_num = 0;
  uint64 add_click_num = 0;
  uint64 dict_item_num = 0;
  uint64 item_id;
  int64 offset = 0;
  std::string uniq_key;
  reco::kafka::Message msg;
  reco::log::ActionLog click_log;
  while (running_->load()) {
    if (add_fetch_num % 10000 == 1) {
      LOG(INFO) << "partition: " << idx
                << ", add_fetch_num: " << add_fetch_num
                << ", add_click_num: " << add_click_num
                << ", fail_num: " << fail_num
                << ", dict_size: " << item_ctr_dict_.size()
                << ", offset: " << offset;
    }
    msg.Clear();
    if (!click_consumer_->Consume(&msg)) {
      ++fail_num;
      LOG_IF(INFO, fail_num % 100 == 1) << "FAILED partition: " << idx
                                        << ", offset: " << offset
                                        << ", fail num: " << fail_num;
      base::SleepForMilliseconds(10);
      continue;
    }
    ++add_fetch_num;
    offset = msg.offset;
    thread::AutoLock auto_lock(&click_mutex_);
    click_topic_timestamp_ = msg.timestamp_ms / 1000L;
    if (msg.content.empty()) {
      LOG(INFO) << "fetch message is empty";
      continue;
    }
    // 解析点击日志
    if (!click_log.ParseFromString(msg.content)) {
      LOG(ERROR) << "parse click log body failed";
      COUNTERS_joiner__parse_click_log_failed.Increase(1);
      continue;
    }
    // if (FLAGS_if_only_use_iflow_data
    //     && click_log.has_user()
    //     && kValidAppNames.find(click_log.user().app_token()) == kValidAppNames.end()) {
    //   VLOG(1) << "app name not valid: " << click_log.user().app_token();
    //   continue;
    // }
    if (FLAGS_if_only_use_iflow_data
        && (!click_log.has_app_name()
            || kValidAppNames.find(click_log.app_name()) == kValidAppNames.end())) {
      VLOG(1) << "app name not valid: " << click_log.user().app_token();
      continue;
    }

    if (click_log.timestamp() < expire_timestamp) continue;

    if (click_log.action_type() != reco::log::kRecoClick) continue;

    if (click_log.user_id() <= 0) continue;
    if (click_log.has_item_type() && click_log.item_type() == 255) continue;
    // 测试 channel 不要
    if (click_log.has_channel_id()) {
      if (click_log.channel_id() == 0 || click_log.channel_id() == 600) continue;
    }

    if (!click_log.has_reco_id()
        || click_log.reco_id().size() == 0
        || click_log.reco_id() == "0") {
      continue;
    }

    if (!base::StringToUint64(click_log.item_id(), &item_id) || item_id < 1000000) continue;

    if (!IsListClick(click_log)) continue;

    static const std::unordered_set<int64> kFilteredChannelIds = {20161205};
    if (click_log.has_channel_id() &&
        kFilteredChannelIds.find(click_log.channel_id()) != kFilteredChannelIds.end()) continue;

    // dedup click
    uniq_key = base::StringPrintf("%lu-%lu", click_log.user_id(), item_id);

    int duration = 1;
    if (click_log.has_duration()) {
      duration = std::min(600, click_log.duration());
    }

    int * pointer = NULL;
    if (dedup_clicks_ != NULL) {
      pointer = dedup_clicks_->IfNotFoundThenAdd(uniq_key, duration);
      if (pointer != NULL) {
        // 用长的 duration 替换短的 duration
        if (*pointer < duration) {
          ReplaceDuration(item_id, *pointer, duration);
          dedup_clicks_->Add(uniq_key, duration);
        }
        continue;
      }
    }

    if (add_click_num % 10000 == 0) {
      LOG(INFO) << "partition:" << idx
                << ", reco_id:" << click_log.reco_id()
                << ", add fetch num: " << add_fetch_num
                << ", add click num: " << add_click_num
                << ", click read timestamp: " << TimestampToString(click_log.timestamp());
      if (last_update_redis_time_ <= startup_time_) {
        int sleep_ms = FLAGS_click_partition_num * 10;
        base::SleepForMilliseconds(sleep_ms);
      }
    }

    ++add_click_num;
    if (FLAGS_open_batch_update_memory_item_switch) {
      ++dict_item_num;
      auto iter = item_click_dict.find(item_id);
      if (iter == item_click_dict.end()) {
        item_click_dict.insert(std::make_pair(item_id, 1));
      } else {
        iter->second += 1;
      }
      if (click_log.has_duration()) {
        auto iter = item_duration_dict.find(item_id);
        if (iter == item_duration_dict.end()) {
          item_duration_dict.insert(std::make_pair(item_id, duration));
        } else {
          iter->second += duration;
        }
      }
    } else {
      AddClick(item_id, 1);
      if (click_log.has_duration()) {
        AddDuration(item_id, duration);
      }
    }

    if (dict_item_num >= 1000 && FLAGS_open_batch_update_memory_item_switch) {
      BatchAddClick(item_click_dict);
      base::dense_hash_map<uint64, uint32> swap_dict;
      item_click_dict.swap(swap_dict);
      item_click_dict.set_empty_key(0);

      BatchAddDuration(item_duration_dict);
      base::dense_hash_map<uint64, uint64> duration_swap_dict;
      item_duration_dict.swap(duration_swap_dict);
      item_duration_dict.set_empty_key(0);

      dict_item_num = 0;
    }
  }
}

void ItemCtrUpdater::BatchAddShow(const base::dense_hash_map<uint64, uint32>& item_show_dict) {
  thread::AutoLock auto_lock(&mutex_);
  for (auto iter = item_show_dict.begin(); iter != item_show_dict.end(); ++iter) {
    ItemCtrData& env = item_ctr_dict_[iter->first];
    if (env.total_show < kMaxShowLimit) {
      env.total_show += iter->second;
    }
    env.recent_update_time = base::Time::Now();
  }
}

void ItemCtrUpdater::BatchAddClick(const base::dense_hash_map<uint64, uint32>& item_click_dict) {
  thread::AutoLock auto_lock(&mutex_);
  for (auto iter = item_click_dict.begin(); iter != item_click_dict.end(); ++iter) {
    ItemCtrData& env = item_ctr_dict_[iter->first];
    if (env.total_show < kMaxShowLimit) {
      env.total_click += iter->second;
    }
    env.recent_update_time = base::Time::Now();
  }
}

void ItemCtrUpdater::BatchAddDuration(const base::dense_hash_map<uint64, uint64>& item_duration_dict) {
  thread::AutoLock auto_lock(&mutex_);
  for (auto iter = item_duration_dict.begin(); iter != item_duration_dict.end(); ++iter) {
    ItemCtrData& env = item_ctr_dict_[iter->first];
    if (env.total_show < kMaxShowLimit) {
      env.total_duration += iter->second;
    }
    env.recent_update_time = base::Time::Now();
  }
}


void ItemCtrUpdater::AddShow(uint64 item_id, int show) {
  thread::AutoLock auto_lock(&mutex_);
  ItemCtrData& env = item_ctr_dict_[item_id];
  if (env.total_show < kMaxShowLimit) {
    env.total_show += show;
  }
  env.recent_update_time = base::Time::Now();
}

void ItemCtrUpdater::AddClick(uint64 item_id, int click) {
  thread::AutoLock auto_lock(&mutex_);
  ItemCtrData& env = item_ctr_dict_[item_id];
  if (env.total_show < kMaxShowLimit) {
    env.total_click += click;
  }
}

void ItemCtrUpdater::AddDuration(uint64 item_id, int duration) {
  thread::AutoLock auto_lock(&mutex_);
  ItemCtrData& env = item_ctr_dict_[item_id];
  if (env.total_show < kMaxShowLimit) {
    env.total_duration += std::min(600, duration);
  }
}

void ItemCtrUpdater::ReplaceDuration(uint64 item_id, int org_duration, int new_duration) {
  thread::AutoLock auto_lock(&mutex_);
  ItemCtrData& env = item_ctr_dict_[item_id];
  env.total_duration += (new_duration - org_duration);
}

void ItemCtrUpdater::LoopUpdateItemData() {
  last_update_redis_time_ = startup_time_;
  last_update_disk_time_ = startup_time_;
  last_update_timestamp_time_ = startup_time_;
  last_tune_show_click_time_ = startup_time_;
  while (running_) {
    const base::Time& loop_start_time = base::Time::Now();

    // if update time stamp
    const base::TimeDelta& delta_time_timestamp = loop_start_time - last_update_timestamp_time_;
    if (delta_time_timestamp.InSeconds() >= FLAGS_update_stats_timestamp_seconds) {
      LOG(INFO) << "loop to update timestamp, ...";
      last_update_timestamp_time_ = loop_start_time;
      WriteKafkaTimeStampsToDisk();
    }

    // if update redis
    const base::TimeDelta& delta_time_redis = loop_start_time - last_update_redis_time_;

    if (delta_time_redis.InSeconds() >= FLAGS_update_stats_redis_seconds) {
      LOG(INFO) << "loop to update redis, ...";
      thread::AutoLock auto_lock(&mutex_);
      WriteItemDataToRedis(item_ctr_dict_);
      last_update_redis_time_ = loop_start_time;
      LOG(INFO) << "finish to update redis of this loop.";
    }

    // if write disk
    const base::TimeDelta& delta_time_disk = loop_start_time - last_update_disk_time_;
    if (delta_time_disk.InSeconds() >= FLAGS_store_stats_disk_seconds) {
      LOG(INFO) << "loop to write disk, ...";
      thread::AutoLock auto_lock(&mutex_);
      WriteItemDataToDisk(item_ctr_dict_);
      last_update_disk_time_ = loop_start_time;
      LOG(INFO) << "finish to write disk of this loop.";
    }

    base::SleepForSeconds(30);

    LOG(INFO) << "this loop update stats cost ms: " << (base::Time::Now() - loop_start_time).InMilliseconds();
  }
}

void ItemCtrUpdater::WriteItemDataToDisk(const base::dense_hash_map<uint64, ItemCtrData>& stats_dict) {
  LOG(INFO) << "begin to write stats to disk, " << stats_dict.size();

  base::Time now = base::Time::Now();
  std::string date_suffix;
  CHECK(now.ToStringInFormat("%Y-%m-%d", &date_suffix));

  // 创建存储文件
  base::FilePath root_dir(FLAGS_store_stats_disk_dir);
  if (!base::file_util::DirectoryExists(root_dir)) {
    LOG(WARNING) << "does not exit such dir, create it, " << root_dir.ToString();
    CHECK(base::file_util::CreateDirectory(root_dir));
  }

  // 写入 kafka timestamp
  WriteKafkaTimeStampsToDisk();
  base::FilePath timestamp_backup_dir = root_dir.Append("timestamp." + date_suffix);
  base::FilePath timestamp_orig_dir(FLAGS_kafka_timestamp_store_path);
  if (base::file_util::DirectoryExists(timestamp_orig_dir)) {
    base::file_util::Delete(timestamp_backup_dir, true);
    base::file_util::CopyDirectory(timestamp_orig_dir, timestamp_backup_dir, true);
  }

  // 写入历史统计信息
  std::string store_file_name = base::StringPrintf("%s.%s", kGlobalItemDataStoreFile, date_suffix.c_str());
  base::FilePath store_file = root_dir.Append(store_file_name);
  std::ofstream os(store_file.ToString());
  // 存储加载统计信息
  base::FilePath reload_data_dir(FLAGS_data_dir);
  base::FilePath reload_data_file = reload_data_dir.Append(kGlobalItemDataStoreFile);
  std::ofstream os_reload(reload_data_file.ToString());

  std::string str_update_time;
  for (auto iter = stats_dict.begin(); iter != stats_dict.end(); ++iter) {
    const ItemCtrData& env = iter->second;
    env.recent_update_time.ToStringInSeconds(&str_update_time);
    os << base::StringPrintf("%lu\t%d\t%d\t%lu\t%s\n",
                             iter->first,
                             env.total_show,
                             env.total_click,
                             env.total_duration,
                             str_update_time.c_str());
    os_reload << base::StringPrintf("%lu\t%d\t%d\t%lu\t%s\n",
                                    iter->first,
                                    env.total_show,
                                    env.total_click,
                                    env.total_duration,
                                    str_update_time.c_str());
  }
  os.close();
  os_reload.close();

  LOG(INFO) << "succ to write stats to disk, " << stats_dict.size();
}

void ItemCtrUpdater::WriteItemDataToRedis(const base::dense_hash_map<uint64, ItemCtrData>& stats_dict) {
  if (FLAGS_skip_write_ctr_to_redis) {
    LOG(INFO) << "skip write ctr info to redis.";
    return;
  }

  LOG(INFO) << "begin to write stats to redis, " << stats_dict.size();

  std::vector<std::pair<uint64, ItemCtrData> > item_ctr_vec;
  for (auto iter = stats_dict.begin(); iter != stats_dict.end(); ++iter) {
    if (iter->second.recent_update_time <= last_update_redis_time_) continue;
    item_ctr_vec.push_back(std::make_pair(iter->first, iter->second));
  }

  redis_util_->BatchWriteItemCtr(item_ctr_vec);

  LOG(INFO) << "succ to write stats to redis, total:" << stats_dict.size()
            << ", real write:" << item_ctr_vec.size();
}

inline std::string ItemCtrUpdater::TimestampToString(int64 timestamp) const {
  base::Time t = base::Time::FromDoubleT(timestamp / base::Time::kMicrosecondsPerSecond);
  std::string str;
  t.ToStringInSeconds(&str);
  return str;
}

void ItemCtrUpdater::InitKafka() {
  base::FilePath root_dir(FLAGS_kafka_timestamp_store_path);
  base::FilePath show_topic_store_file = root_dir.Append(kShowTopicTimeStampStoreFile);
  base::FilePath click_topic_store_file = root_dir.Append(kClickTopicTimeStampStoreFile);
  std::vector<std::string> lines;
  show_topic_timestamp_ = -1;
  click_topic_timestamp_ = -1;
  if (!base::file_util::ReadFileToLines(show_topic_store_file, &lines)) {
    LOG(WARNING) << "show topic timestamps file does not exist, " << show_topic_store_file.ToString();
  } else {
    for (int i = 0; i < (int)lines.size(); ++i) {
      CHECK(base::StringToInt64(lines[i], &show_topic_timestamp_));
      break;
    }
  }

  lines.clear();
  if (!base::file_util::ReadFileToLines(click_topic_store_file, &lines)) {
    LOG(WARNING) << "click topic timestamps file does not exist, " << click_topic_store_file.ToString();
  } else {
    for (int i = 0; i < (int)lines.size(); ++i) {
      CHECK(base::StringToInt64(lines[i], &click_topic_timestamp_));
      break;
    }
  }

  reco::kafka::ConsumerOptions show_options;
  show_options.topic = FLAGS_kafka_show_topic_name;
  show_options.partition_num = FLAGS_show_partition_num;
  show_options.type = reco::kafka::kConsumerMirror;
  show_options.group_id = "get_show_log_group";
  show_options.start_timestamp = show_topic_timestamp_;
  show_consumer_ = new reco::kafka::Consumer(FLAGS_kafka_brokers, show_options);
  CHECK_NOTNULL(show_consumer_);

  reco::kafka::ConsumerOptions click_options;
  click_options.topic = FLAGS_kafka_click_topic_name;
  click_options.partition_num = FLAGS_click_partition_num;
  click_options.type = reco::kafka::kConsumerMirror;
  click_options.group_id = "get_click_log_group";
  click_options.start_timestamp = click_topic_timestamp_;
  click_consumer_ = new reco::kafka::Consumer(FLAGS_kafka_brokers, click_options);
  CHECK_NOTNULL(click_consumer_);
  LOG(INFO) << "succ to init kafka";
  return;
}

void ItemCtrUpdater::WriteKafkaTimeStampsToDisk() {
  base::FilePath root_dir(FLAGS_kafka_timestamp_store_path);
  base::FilePath show_topic_store_file = root_dir.Append(kShowTopicTimeStampStoreFile);
  std::ofstream os_show(show_topic_store_file.ToString());
  //  os_show << base::StringPrintf("%ld\n", base::GetTimestamp() / 1000000L);
  os_show << base::StringPrintf("%ld\n", show_topic_timestamp_);
  os_show.close();
  base::FilePath click_topic_store_file = root_dir.Append(kClickTopicTimeStampStoreFile);
  std::ofstream os_click(click_topic_store_file.ToString());
  //  os_click << base::StringPrintf("%ld\n", base::GetTimestamp() / 1000000L);
  os_click << base::StringPrintf("%ld\n", click_topic_timestamp_);
  os_click.close();
  LOG(INFO) << "succ to write kafka timestamps into disk";
}

inline bool ItemCtrUpdater::IsListClick(const reco::log::ActionLog& click_log) const {
  if (!click_log.has_content() || click_log.content().empty()) return true;
  static const std::unordered_set<std::string> kFilteredSourceSet
      = {"push", "relate", "wemedia", "search", "video_page"};

  json_error_t json_error;
  json_t *json = json_loads(click_log.content().c_str(), &json_error);
  if (json == NULL) {
    LOG(WARNING) << "Failed to parse click log content, " << click_log.content()
                 << ", json error, " << json_error.line;
    return true;
  }

  json_t *j_novel_id = json_object_get(json, "source");
  std::string source;
  if (j_novel_id != NULL && j_novel_id->type == JSON_STRING) {
    source = json_string_value(j_novel_id);
  }
  if (!source.empty() && kFilteredSourceSet.find(source) != kFilteredSourceSet.end()) {
    return false;
  }

  json_decref(json);

  return true;
}

}  // namespace joiner
}  // namespace reco
