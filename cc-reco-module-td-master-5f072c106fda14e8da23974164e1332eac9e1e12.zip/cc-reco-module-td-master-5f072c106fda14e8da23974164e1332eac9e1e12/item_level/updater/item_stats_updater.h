#pragma once

#include <unordered_map>
#include <unordered_set>
#include <utility>  // for pair
#include <string>
#include <vector>

#include "boost/unordered_map.hpp"

#include "reco/bizc/proto/reco_log.pb.h"
#include "reco/module/item_level/base/base.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/process/process_util.h"
#include "base/container/dense_hash_map.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"

namespace reco {
namespace item_level {
class RedisUtil;

// 生成 item 统计数据
//
class ItemStatsUpdater {
 public:
  ItemStatsUpdater();
  ~ItemStatsUpdater();

  void Start();
  void Stop();

 private:
  // 从磁盘中 load 已经积累的数据
  // 该积累的数据与 kafka 的 offset 文件必须配套，否则会造成数据不一致
  void LoadItemStatsDataFromDisk();
  // 从 kafka show 队列获取展现数据
  void GetRecoShowLog(int idx);
  // 从 kafka action 队列获取展现数据
  void GetRecoClickLog(int idx);
  // 累加相关统计数据
  void BatchAddShow(const base::dense_hash_map<uint64, uint32>& item_show_dict);
  void BatchAddClick(const base::dense_hash_map<uint64, uint32>& item_click_dict);
  void BatchAddDuration(const base::dense_hash_map<uint64, uint64>& item_duration_dict);
  void BatchAddFav(const base::dense_hash_map<uint64, uint32>& item_fav_dict);
  void BatchAddShare(const base::dense_hash_map<uint64, uint32>& item_share_dict);
  void BatchAddDislike(const base::dense_hash_map<uint64, uint32>& item_dislike_dict);
  void BatchAddLike(const base::dense_hash_map<uint64, uint32>& item_like_dict);

  void AddShow(uint64 item_id, int show_num);
  void AddClick(uint64 item_id, int click_num);
  void AddDuration(uint64 item_id, int duration);
  void AddFav(uint64 item_id, int fav);
  void AddShare(uint64 item_id, int share);
  void AddDislike(uint64 item_id, int dislike);
  void AddLike(uint64 item_id, int like);
  void ReplaceDuration(uint64 item_id, int org_duration, int new_duration);
  bool IsListClick(const reco::log::ActionLog& click_log) const;
  // 定时循环更新积累的数据到 redis 和 disk 中
  void LoopUpdateItemData();
  // 将新增的统计数据更新到 redis
  void WriteItemDataToRedis(const base::dense_hash_map<uint64, ItemStatsData>& stats_dict);
  // 全局统计信息更新到磁盘
  void WriteItemDataToDisk(const base::dense_hash_map<uint64, ItemStatsData>& stats_dict);

  // 加载 kafka 时间戳
  void InitKafka();
  // 写时间戳到磁盘
  void WriteKafkaTimeStampsToDisk();
  std::string TimestampToString(int64 timestamp) const;

 private:
  static const int kConsumerTimeoutMS = 100;
  static const char* kGlobalItemDataStoreFile;
  static const char* kShowTopicTimeStampStoreFile;
  static const char* kClickTopicTimeStampStoreFile;
  static const int kRedisBatchSize = 1000;
  static const int kItemCtrDictRehashSize = 12000000;
  static const int kRedisCnt = 3;
  static const uint32 kMaxShowLimit;
  static const std::unordered_set<std::string> kValidAppNames;

  RedisUtil* redis_util_;

  // item ctr 的统计
  base::dense_hash_map<uint64, ItemStatsData> item_ctr_dict_;

  // 相同 user-item 的点击去重
  serving_base::ExpiryMap<std::string, int>* dedup_clicks_;

  base::Time startup_time_;
  base::Time last_update_redis_time_;
  base::Time last_update_timestamp_time_;
  base::Time last_update_disk_time_;
  base::Time last_tune_show_click_time_;

  int64 show_topic_timestamp_;
  int64 click_topic_timestamp_;

  thread::Mutex mutex_;
  thread::Mutex show_mutex_;
  thread::Mutex click_mutex_;

  std::atomic<bool>* running_;
  thread::ThreadPool* thread_pool_;
  reco::kafka::Consumer* show_consumer_;
  reco::kafka::Consumer* click_consumer_;
};

}  // namespace item_level
}  // namespace reco
