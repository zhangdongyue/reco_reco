#include "reco/module/item_level/updater/item_ctr_updater.h"

#include <vector>
#include <fstream>

#include "reco/module/item_level/base/connection_manager.h"
#include "serving_base/utility/time_helper.h"
#include "net/counter/export.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/time/timestamp.h"

namespace reco {
namespace item_level {

DEFINE_int32(partition_num, 9, "");
DEFINE_string(kafka_brokers, "", "必须外部指定");
DEFINE_string(kafka_show_topic_name, "", "show log topic name");
DEFINE_string(kafka_click_topic_name, "", "show log topic name");
DEFINE_int32(kafka_consume_offset, -2, "kafka consume offset");
DEFINE_int32(kafka_backtrack_hours, 24 * 7, "kafka backtrack hours");
DEFINE_string(kafka_offset_store_path, "../kafka_offset", "kafka offset data path");

DEFINE_int32(redis_record_expire_seconds, 3600*24, "time interval to inc update item info in seconds.");
DEFINE_int32(update_stats_redis_seconds, 600, "time interval to update redis data in seconds.");

DEFINE_int32(tune_show_click_seconds, 3600, "time interval to update redis data in seconds.");
DEFINE_double(show_click_tune_ratio, 0.8, "time interval to update redis data in seconds.");

DEFINE_int32(store_stats_disk_seconds, 3600, "time interval to write stats to disk in seconds.");
DEFINE_string(store_stats_disk_dir, "../dump_data", "item stats data path");
DEFINE_int32(store_stats_expire_days, 30, "item stats expire days");

DEFINE_bool(write_redis_when_startup, false, "if write redis at when startup");
DEFINE_int32(show_num_limit_per_scene, 10000, "every scene_show_num_limit");

DEFINE_string(data_dir, "../data", "item stats data path");

DEFINE_int64_counter(joiner, parse_click_log_failed, 0, "解析点击日志");
DEFINE_int64_counter(joiner, parse_show_log_failed, 0, "解析点击日志");
DEFINE_int64_counter(joiner, put_total_item_num, 0, "解析点击日志");

const char* ItemCtrUpdater::kGlobalItemDataStoreFile = "item_data.txt";

ItemCtrUpdater::ItemCtrUpdater() {
  redis_client_pool_ = ConnectionManager::GetRedisClientPool();
  CHECK_NOTNULL(redis_client_pool_);

  item_ctr_dict_.rehash(kItemCtrDictRehashSize);

  LoadItemCtrDataFromDisk();

  if (FLAGS_write_redis_when_startup) {
    last_update_redis_time_ = base::Time::Now() - base::TimeDelta::FromDays(7);
    WriteItemDataToRedis(item_ctr_dict_);
    last_update_redis_time_ = base::Time::Now();
  }

  dedup_clicks_ = new serving_base::ExpiryMap<std::string, int>(3600 * 4);
}

ItemCtrUpdater::~ItemCtrUpdater() {
  Stop();
  delete dedup_clicks_;
}

void ItemCtrUpdater::LoadItemCtrDataFromDisk() {
  base::FilePath root_dir(FLAGS_data_dir);
  base::FilePath store_file = root_dir.Append(kGlobalItemDataStoreFile);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(store_file, &lines)) {
    LOG(WARNING) << "item ctr data store file does not exist, " << store_file.ToString();
    return;
  }
  LOG(INFO) << "begin to load item ctr data from disk, total num " << lines.size();

  base::Time curr_time = base::Time::Now();
  std::string str_curr_time;
  curr_time.ToStringInSeconds(&str_curr_time);
  // 只要更新时间不是太久前的数据
  base::Time expire_time = curr_time - base::TimeDelta::FromDays(FLAGS_store_stats_expire_days);

  // LogData env;
  uint64 item_id;
  ItemCtrData env;
  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 4u) {
      LOG(WARNING) << "error flds num, " << lines[i].size();
      continue;
    }
    // parse
    CHECK(base::StringToUint64(flds[0], &item_id));
    CHECK(base::StringToUint(flds[1], &env.total_show));
    CHECK(base::StringToUint(flds[2], &env.total_click));
    CHECK(base::StringToUint(flds[3], &env.tune_show));
    CHECK(base::StringToUint(flds[4], &env.tune_click));
    if (flds.size() >= 5u
        && base::Time::FromStringInSeconds(flds[5].c_str(), &env.recent_update_time)) {
    } else {
      env.recent_update_time = base::Time::Now();
    }

    // 太久没更新的数据不要了，重新累积
    if (env.recent_update_time < expire_time) continue;

    item_ctr_dict_.insert(std::make_pair(item_id, env));
  }

  LOG(INFO) << "succ to load item ctr data from disk, total num " << item_ctr_dict_.size();
}

void ItemCtrUpdater::Start() {
  LOG(INFO) << "ItemCtrUpdater starting...";

  startup_time_ = base::Time::Now();

  // joiner thread-safe
  running_ = new std::atomic<bool>(true);
  thread_pool_ = new thread::ThreadPool(FLAGS_partition_num * 2 + 1);

  // collect show from show log
  for (int idx = 0; idx < FLAGS_partition_num; ++idx) {
    thread_pool_->AddTask(NewCallback(this, &ItemCtrUpdater::GetRecoShowLog, idx));
  }

  // collect click from click log
  for (int idx = 0; idx < FLAGS_partition_num; ++idx) {
    thread_pool_->AddTask(NewCallback(this, &ItemCtrUpdater::GetRecoClickLog, idx));
  }

  // update show click data to redis
  thread_pool_->AddTask(NewCallback(this, &ItemCtrUpdater::LoopUpdateItemData));
}

void ItemCtrUpdater::Stop() {
  if (running_) {
    thread_pool_->JoinAll();
    running_ = false;
  }
}

void ItemCtrUpdater::GetRecoShowLog(int partition) {
  reco::kafka::PartitionConsumer consumer;
  CHECK(consumer.Connect(FLAGS_kafka_brokers,
                          FLAGS_kafka_show_topic_name, partition)) << "show consumer connect failed.";
  consumer.ResetOffset(FLAGS_kafka_consume_offset);

  // 过滤太久远的展现
  base::Time expire_time = startup_time_ - base::TimeDelta::FromHours(FLAGS_kafka_backtrack_hours);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  LOG(INFO) << "start_to_get_show_log";

  int fnum = 0;
  uint64 addnum = 0;
  uint64 item_num = 0;
  uint64 item_id;
  int64 offset = 0;
  std::string messages;
  reco::log::RecoShowLog show_log;
  while (running_->load()) {
    if (addnum % 100000 == 0) {
      LOG(INFO) << "partition " << partition << " fetch " << addnum
                << " show, total show item num: " << item_num
                << ", uniq show item: " << item_ctr_dict_.size()
                << ", offset: " << offset;
    }
    if (consumer.Fetch(2000, &messages, &offset)) {
      if (!show_log.ParseFromString(messages)) {
        LOG(WARNING) << "parse show log failed";
        COUNTERS_joiner__parse_show_log_failed.Increase(1);
        continue;
      }

      if (show_log.reco_timestamp() < expire_timestamp) continue;
      // 幽默频道的数据不进入训练
      if (!show_log.has_channel_id()
          || show_log.channel_id() == reco::common::kHumorPicChannelId
          || show_log.channel_id() == reco::common::kHumorWordChannelId) {
        continue;
      }
      // userid = 0 是测试用户,要过滤掉
      if (show_log.user().user_id() == 0) {
        continue;
      }

      ++addnum;
      for (auto it = show_log.misc_info().begin(); it != show_log.misc_info().end(); ++it) {
        if (!base::StringToUint64(it->item_id(), &item_id) || item_id <= 1000000) continue;
        ++item_num;
        AddShow(item_id, 1);
      }

    } else {
      ++fnum;
      LOG_EVERY_N(INFO, 10000) << "FAILED partition : "
                               << partition << " offset : " << offset
                               << " " << fnum;
      base::SleepForSeconds(3);
    }
  }

  return;
}

void ItemCtrUpdater::AddShow(uint64 item_id, int show) {
  thread::AutoLock auto_lock(&mutex_);
  ItemCtrData& env = item_ctr_dict_[item_id];
  env.total_show += show;
  // env.tune_show += show;
  // env.recent_show += show;
  env.recent_update_time = base::Time::Now();
}

void ItemCtrUpdater::AddClick(uint64 item_id, int click) {
  thread::AutoLock auto_lock(&mutex_);
  ItemCtrData& env = item_ctr_dict_[item_id];
  env.total_click += click;
  // env.tune_click += click;
  // env.recent_click += click;
  // env.recent_update_time = base::Time::Now();
}

void ItemCtrUpdater::GetRecoClickLog(int partition) {
  reco::kafka::PartitionConsumer consumer;
  CHECK(consumer.Connect(FLAGS_kafka_brokers,
                         FLAGS_kafka_click_topic_name, partition)) << "click consumer connect failed.";
  consumer.ResetOffset(FLAGS_kafka_consume_offset);

  // 不要太久远的点击
  base::Time expire_time = startup_time_ - base::TimeDelta::FromHours(FLAGS_kafka_backtrack_hours);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  LOG(INFO) << "start_to_get_click_log";
  int fnum = 0;
  uint64 addnum = 0;
  uint64 item_id;
  int64 offset = 0;
  std::string uniq_key;
  std::string messages;
  reco::log::ActionLog click_log;
  while (running_->load()) {
    if (addnum % 100000 == 1) {
      LOG(INFO) << "partition " << partition << " fetch " << addnum
                << " click, uniq item item: " << item_ctr_dict_.size()
                << ", offset: " << offset;
    }
    if (consumer.Fetch(2000, &messages, &offset)) {
      if (messages.empty()) {
        LOG(INFO) << "fetch message is empty";
        continue;
      }
      // 解析点击日志
      if (!click_log.ParseFromString(messages)) {
        LOG(ERROR) << "parse click log body failed";
        COUNTERS_joiner__parse_click_log_failed.Increase(1);
        continue;
      }

      if (click_log.timestamp() < expire_timestamp) continue;

      if (click_log.action_type() != reco::log::kRecoClick) continue;
      // NOTE(jianhuang) 这里只要页端点击
      // if (click_log.has_scene() && click_log.scene() != "page") continue;
      // if (!click_log.has_scene() || click_log.scene() != "page") continue;

      if (click_log.user_id() <= 0) continue;

      if (!click_log.has_reco_id()
          || click_log.reco_id().size() == 0
          || click_log.reco_id() == "0") {
        continue;
      }

      if (!base::StringToUint64(click_log.item_id(), &item_id) || item_id < 1000000) continue;

      // dedup click
      uniq_key = base::StringPrintf("%lu-%lu", click_log.user_id(), item_id);
      if (dedup_clicks_->IfNotFoundThenAdd(uniq_key, 1) != NULL) continue;

      if (addnum % 10000 == 1) {
        LOG(INFO) << "partition:" << partition << ", reco_id:" << click_log.reco_id()
                  << ", click add num: " << addnum
                  << ", click read timestamp: " << click_log.timestamp();
      }
      ++addnum;
      AddClick(item_id, 1);
    } else {
      ++fnum;
      LOG_EVERY_N(INFO, 10000) << "FAILED partition : "
                               << partition << " offset : " << offset
                               << " " << fnum;
      base::SleepForSeconds(3);
    }
  }
}

void ItemCtrUpdater::LoopUpdateItemData() {
  last_update_redis_time_ = startup_time_;
  last_update_disk_time_ = startup_time_;
  last_tune_show_click_time_ = startup_time_;
  while (running_) {
    const base::Time& loop_start_time = base::Time::Now();

    // if tune show click
    // const base::TimeDelta& delta_time_tune = loop_start_time - last_tune_show_click_time_;
    // if (delta_time_tune.InSeconds() >= FLAGS_tune_show_click_seconds) {
    //   LOG(INFO) << "loop to tune show click, ...";
    //   thread::AutoLock auto_lock(&mutex_);
    //   TuneItemShowClick(&item_ctr_dict_);
    //   last_tune_show_click_time_ = loop_start_time;
    //   LOG(INFO) << "finish to tune show click of this loop.";
    // }

    // if update redis
    const base::TimeDelta& delta_time_redis = loop_start_time - last_update_redis_time_;
    if (delta_time_redis.InSeconds() >= FLAGS_update_stats_redis_seconds) {
      LOG(INFO) << "loop to update redis, ...";
      thread::AutoLock auto_lock(&mutex_);
      WriteItemDataToRedis(item_ctr_dict_);
      last_update_redis_time_ = loop_start_time;
      LOG(INFO) << "finish to update redis of this loop.";
    }

    // if write disk
    const base::TimeDelta& delta_time_disk = loop_start_time - last_update_disk_time_;
    if (delta_time_disk.InSeconds() >= FLAGS_store_stats_disk_seconds) {
      LOG(INFO) << "loop to write disk, ...";
      thread::AutoLock auto_lock(&mutex_);
      WriteItemDataToDisk(item_ctr_dict_);
      last_update_disk_time_ = loop_start_time;
      LOG(INFO) << "finish to write disk of this loop.";
    }

    base::SleepForSeconds(30);

    LOG(INFO) << "this loop update stats cost ms: " << (base::Time::Now() - loop_start_time).InMilliseconds();
  }
}

void ItemCtrUpdater::TuneItemShowClick(boost::unordered_map<uint64, ItemCtrData>* stats_dict) {
  static const uint32 kTuneShowNumCutoff
      = static_cast<uint32>(FLAGS_show_num_limit_per_scene / FLAGS_show_click_tune_ratio + 0.5);
  for (auto iter = stats_dict->begin(); iter != stats_dict->end(); ++iter) {
    ItemCtrData& env = iter->second;
    if (env.recent_show < env.recent_click) {
      // bad item data
      env.tune_show -= env.recent_show;
      env.tune_click -= env.recent_click;
    }
    if (env.tune_show >= kTuneShowNumCutoff) {
      env.tune_show *= FLAGS_show_click_tune_ratio;
      env.tune_click *= FLAGS_show_click_tune_ratio;
    }
    env.recent_show = 0;
    env.recent_click = 0;
  }
}

void ItemCtrUpdater::WriteItemDataToDisk(const boost::unordered_map<uint64, ItemCtrData>& stats_dict) {
  LOG(INFO) << "begin to write stats to disk, " << stats_dict.size();

  base::Time now = base::Time::Now();
  std::string date_suffix;
  CHECK(now.ToStringInFormat("%Y-%m-%d", &date_suffix));

  // 创建存储文件
  base::FilePath root_dir(FLAGS_store_stats_disk_dir);
  if (!base::file_util::DirectoryExists(root_dir)) {
    LOG(WARNING) << "does not exit such dir, create it, " << root_dir.ToString();
    CHECK(base::file_util::CreateDirectory(root_dir));
  }

  // 写入 kafka offset
  base::FilePath offset_backup_dir = root_dir.Append("offset." + date_suffix);
  base::FilePath offset_orig_dir(FLAGS_kafka_offset_store_path);
  if (base::file_util::DirectoryExists(offset_orig_dir)) {
    base::file_util::Delete(offset_backup_dir, true);
    base::file_util::CopyDirectory(offset_orig_dir, offset_backup_dir, true);
  }

  // 写入历史统计信息
  std::string store_file_name = base::StringPrintf("%s.%s", kGlobalItemDataStoreFile, date_suffix.c_str());
  base::FilePath store_file = root_dir.Append(store_file_name);
  std::ofstream os(store_file.ToString());
  std::string str_update_time;
  for (auto iter = stats_dict.begin(); iter != stats_dict.end(); ++iter) {
    const ItemCtrData& env = iter->second;
    env.recent_update_time.ToStringInSeconds(&str_update_time);
    os << base::StringPrintf("%lu\t%d\t%d\t%d\t%d\t%s\n",
                             iter->first,
                             env.total_show, env.total_click,
                             env.tune_show, env.tune_click,
                             str_update_time.c_str());
  }
  os.close();

  LOG(INFO) << "succ to write stats to disk, " << stats_dict.size();
}

void ItemCtrUpdater::WriteItemDataToRedis(const boost::unordered_map<uint64, ItemCtrData>& stats_dict) {
  LOG(INFO) << "begin to write stats to redis, " << stats_dict.size();

  redis::TwempAutoPutback redis(redis_client_pool_);
  redis::TwempClient* client = redis.TimedTake(10);
  CHECK(client != NULL) << "redis time take error.";

  std::unordered_map<uint64, ItemCtrData> items;
  int write_redis_num = 0;
  for (auto iter = stats_dict.begin(); iter != stats_dict.end(); ++iter) {
    if (iter->second.recent_update_time <= last_update_redis_time_) continue;
    LOG(INFO) << "write item, " << iter->first
              << ", " << iter->second.total_show
              << ", " << iter->second.total_click
              << ", " << iter->second.tune_show
              << ", " << iter->second.tune_click;
    items.insert(std::make_pair(iter->first, iter->second));
    if ((int)items.size() >= kRedisBatchSize) {
      WriteRedisInf(client, items);
      items.clear();
    }
    ++write_redis_num;
  }

  if (!items.empty()) {
    WriteRedisInf(client, items);
    items.clear();
  }

  LOG(INFO) << "succ to write stats to redis, total:" << stats_dict.size()
            << ", real write:" << write_redis_num;
}

void ItemCtrUpdater::WriteRedisInf(redis::TwempClient* client,
                                    const std::unordered_map<uint64, ItemCtrData>& items) {
  int64 start_t = base::GetTimestamp();
  const int kMaxInstance = items.size() * 4 + 1;
  std::vector<std::string> keys, fields, values;
  keys.reserve(kMaxInstance);
  fields.reserve(kMaxInstance);
  values.reserve(kMaxInstance);
  std::string key;
  std::string val;
  for (auto iter = items.begin(); iter != items.end(); ++iter) {
    const ItemCtrData& env = iter->second;
    uint64 item_id = iter->first;
    key = base::StringPrintf("%s%lu", kItemRedisKeyPrefix, item_id);
    uint32 show_num = env.total_show;
    uint32 click_num = env.total_click;
    // uint32 show_num = env.tune_show;
    // uint32 click_num = env.tune_click;
    // if (show_num < (uint32)FLAGS_show_num_limit_per_scene
    //     || show_num < click_num) {
    //   show_num = env.total_show;
    //   click_num = env.total_click;
    // }
    if (show_num > 0) {
      val = base::IntToString(show_num);
      keys.push_back(key);
      fields.push_back(kShowField);
      // fields.push_back(kExpShowField);
      values.push_back(val);
    }
    if (click_num > 0) {
      val = base::IntToString(click_num);
      keys.push_back(key);
      fields.push_back(kClickField);
      // fields.push_back(kExpClickField);
      values.push_back(val);
    }
  }

  CHECK_EQ(keys.size(), fields.size()) << "key size: " << keys.size() << ", field size: " << fields.size();
  CHECK_EQ(keys.size(), values.size()) << "key size: " << keys.size() << ", value size: " << values.size();

  std::vector<bool> ret_codes;
  if (!client->MultiHashSetEx(keys, fields, values, FLAGS_redis_record_expire_seconds, &ret_codes)) {
  }

  CHECK_EQ(keys.size(), ret_codes.size()) << "key size: " << keys.size() << ", ret size: " << values.size();
  int total_cnt = (int)ret_codes.size();
  int err_cnt = 0;
  for (size_t i = 0; i < ret_codes.size(); ++i) {
    if (ret_codes[i] != 0) ++err_cnt;
  }

  LOG(INFO) << "write redis, total: " << total_cnt << ", err_cnt: " << err_cnt
            << ",  cost " << static_cast<int>((base::GetTimestamp() - start_t) / 1e3) << " ms.";
}

}  // namespace joiner
}  // namespace reco
