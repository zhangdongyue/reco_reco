#pragma once

#include <unordered_map>
#include <string>
#include <vector>

#include "boost/unordered_map.hpp"

#include "reco/bizc/proto/reco_log.pb.h"
#include "reco/module/item_level/base/base.h"
#include "reco/base/kafka_c/api/partition_consumer.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "rpc/redis/twemp_client_pool.h"
#include "base/process/process_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"

namespace reco {
namespace item_level {

struct ItemCtrData {
  // 汇总的 show / click
  uint32 total_show;
  uint32 total_click;
  // 调权的展现和点击
  uint32 tune_show;
  uint32 tune_click;
  // 最近的展现和点击
  uint32 recent_show;
  uint32 recent_click;
  // 最近更新时间
  base::Time recent_update_time;

  ItemCtrData() :
      total_show(0), total_click(0),
      tune_show(0), tune_click(0),
      recent_show(0), recent_click(0) {
        recent_update_time = base::Time::Now();
      }
};

// 生成 item 统计数据
//
class ItemCtrUpdater {
 public:
  ItemCtrUpdater();
  ~ItemCtrUpdater();

  void Start();
  void Stop();

 private:
  // 从磁盘中 load 已经积累的数据
  // 该积累的数据与 kafka 的 offset 文件必须配套，否则会造成数据不一致
  void LoadItemCtrDataFromDisk();
  // 从 kafka show 队列获取展现数据
  void GetRecoShowLog(int partition);
  // 从 kafka action 队列获取展现数据
  void GetRecoClickLog(int partition);
  // 累加相关统计数据
  void AddShow(uint64 item_id, int show_num);
  void AddClick(uint64 item_id, int click_num);
  // 定时循环更新积累的数据到 redis 和 disk 中
  void LoopUpdateItemData();
  // 将新增的统计数据更新到 redis
  void WriteItemDataToRedis(const boost::unordered_map<uint64, ItemCtrData>& stats_dict);
  // 更新 redis 接口
  void WriteRedisInf(redis::TwempClient* client, const std::unordered_map<uint64, ItemCtrData>& items);
  // 全局统计信息更新到磁盘
  void WriteItemDataToDisk(const boost::unordered_map<uint64, ItemCtrData>& stats_dict);
  // bool GetItemPublishTime(uint64 item_id, base::Time* item_time);
  void TuneItemShowClick(boost::unordered_map<uint64, ItemCtrData>* stats_dict);

 private:
  static const char* kGlobalItemDataStoreFile;
  static const int kRedisBatchSize = 1000;
  static const int kItemCtrDictRehashSize = 5000000;

  redis::TwempClientPool* redis_client_pool_;

  // item ctr 的统计
  boost::unordered_map<uint64, ItemCtrData> item_ctr_dict_;

  // 相同 user-item 的点击去重
  serving_base::ExpiryMap<std::string, int>* dedup_clicks_;

  base::Time startup_time_;
  base::Time last_update_redis_time_;
  base::Time last_update_disk_time_;
  base::Time last_tune_show_click_time_;

  thread::Mutex mutex_;

  std::atomic<bool>* running_;
  thread::ThreadPool* thread_pool_;
};

}  // namespace item_level
}  // namespace reco
