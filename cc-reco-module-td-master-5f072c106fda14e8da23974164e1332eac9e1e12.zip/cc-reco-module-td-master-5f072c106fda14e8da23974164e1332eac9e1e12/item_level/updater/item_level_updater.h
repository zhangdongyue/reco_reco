#pragma once

#include <cstdatomic>
#include <string>
#include <unordered_map>
#include <unordered_set>

#include "ads_index/api/public.h"

#include "base/thread/thread.h"
#include "base/common/base.h"

#include "reco/module/item_level/base/base.h"
#include "reco/module/item_level/base/base.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/module/item_level/db_util/hot_db_op.h"
#include "reco/bizc/reco_index/news_index.h"

#include "ads_index/api/public.h"

#include "base/common/base.h"
#include "base/thread/thread.h"

#include "nlp/common/nlp_util.h"
#include "nlp/common/term_container.h"
#include "nlp/common/term_info.h"
#include "nlp/common/rune_type.h"
#include "nlp/segment/segmenter.h"

namespace reco {
class NewsIndex;

namespace item_level {
class RedisUtil;
class HotCalculator;
class TimeLevelCalculator;
class SiteLevelCalculator;
class SensitiveCalculator;
class ItemExpiryCalculator;  // 挖坟文章判断器，属于时效性的一部分
class ItemRelativeCalculator;

// 负责更新大部分 item meta 信息, 当前包括：
// 1. time level
// 2. hot level
// 3. sensitive
// 4. spider score
class ItemLevelUpdater {
 public:
  explicit ItemLevelUpdater(const reco::NewsIndex* index);
  ~ItemLevelUpdater();

  void Start();
  void Stop();

 private:
  void UpdateIndexSpiderDataThread();
  void UpdateIndexSpiderData();

  // 时效性：挖坟文章判断线程
  // 由于挖坟文章判断比较耗时，所以独立单独的线程
  void ItemExpiryCalcThread();
  void ItemExpiryCalcWorker(int thread_id, int thread_num);

  void UpdateIndexItemLevelThread();
  void UpdateIndexPredictCtrThread();
  void UpdateIndexItemLevel();
  void UpdateIndexItemCtr();

  bool GetReqItemInfo(int32 doc_id, ReqItemInfo* item_info);

  bool IfItemHasReviewed(int32 doc_id) const;
  bool NeedUpdateToModel(const ItemLevelInfo& level_info,
                         const ReqItemInfo& item_info,
                         const ClickData& click_data) const;
  void ChooseUpdateToRedis(std::vector<ItemLevelInfo>& level_results,
                           std::vector<ItemLevelInfo>* level_redis);

  void PrintItemInfo(const ReqItemInfo& item_info, const ItemLevelInfo& level_info,
                     const DynamicInfo& dynamic_info) const;

  void ReloadDict();

  // 获取title
  bool GetTitle(const std::vector<std::string>& title_unigrams,
                std::string *title, std::string *bititle);
  // calc wilson ctr
  int CalcWilsonCtr(uint64 item_id, int click, int show);
  // wilson ctr
  float WilsonIntervalRatio(int numerator, int denominator);

 private:
  const reco::NewsIndex* news_index_;

  bool stop_;

  int64 last_loop_update_timestamp_;
  int64 last_loop_ctr_timestamp_;
  int64 last_weekly_update_timestamp_;
  int   last_loop_min_doc_id_;
  bool  is_startup_loop_;

  int64 last_update_spider_data_timestamp_;

  thread::Mutex item_level_update_mutex_;
  thread::Mutex item_ctr_update_mutex_;
  thread::Thread* item_level_update_thread_;
  thread::Thread* item_ctr_update_thread_;

  thread::Mutex spider_data_update_mutex_;
  thread::Thread* spider_data_update_thread_;

  serving_base::ExpiryMap<uint64, SpiderData>* spider_data_dict_;
  serving_base::ExpiryMap<uint64, ClickData>* click_data_dict_;
  serving_base::ExpiryMap<uint64, ReqItemInfo>* item_info_dict_;
  serving_base::ExpiryMap<uint64, ItemLevelInfo>* item_level_dict_;
  serving_base::ExpiryMap<uint64, TimeData>* time_data_dict_;

  HotDbOp* hot_db_op_;
  serving_base::ExpiryMap<uint64, bool>* item_expiry_dict_;

  RedisUtil* redis_util_;
  RedisUtil* redis_r_util_;
  HotCalculator* hot_calc_;
  TimeLevelCalculator* time_level_calc_;
  SensitiveCalculator* sensitive_calc_;
  SiteLevelCalculator* site_level_calc_;
  ItemRelativeCalculator* pctr_calc_;

  thread::Mutex item_expiry_calc_mutex_;
  thread::Thread* item_expiry_calc_thread_;
  ItemExpiryCalculator** item_expiry_calculator_;
  int64 last_item_expiry_calc_loop_timestamp_;
};

}  // namespace item_level
}  // namespace reco
