#include "reco/module/item_level/updater/item_level_updater.h"

#include <limits>
#include <vector>

#include "reco/bizc/common/attr_key_define.h"
#include "reco/module/item_level/base/connection_manager.h"
#include "reco/module/item_level/base/connection_manager_r.h"
#include "reco/module/item_level/base/redis_util.h"
#include "reco/module/item_level/hot_level/hot_calculator.h"
#include "reco/module/item_level/hot_level/spider_score.h"
#include "reco/module/item_level/sensitive/sensitive_calculator.h"
#include "reco/module/item_level/site_level/site_level_calculator.h"
#include "reco/module/item_level/time_level/item_expiry_calculator.h"
#include "reco/module/item_level/time_level/time_level_calculator.h"
#include "reco/module/item_level/item_relative/item_relative_calculator.h"
#include "reco/bizc/reco_index/news_index.h"

#include "ads_index/proto/index.pb.h"

#include "base/common/closure.h"
#include "base/common/counters.h"
#include "base/common/gflags.h"
#include "base/common/scoped_ptr.h"
#include "base/common/sleep.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/time/timestamp.h"

namespace reco {
namespace item_level {

DEFINE_int32(reload_interval_second, 3600, "time interval to reload dict in seconds.");
DEFINE_int32(itemlevel_update_loop_second, 300, "time interval to update item info in seconds.");
DEFINE_int32(itemlevel_ctr_loop_second, 300, "time interval to update item info in seconds.");
//DEFINE_int32(spider_data_update_loop_second, 1800, "time interval to update quality env.");
DEFINE_int32(spider_data_update_loop_second, 300, "time interval to update quality env.");
DEFINE_int32(weekly_update_interval_second, 7200, "global time interval to print log in seconds.");
DEFINE_string(item_level_data_dir, "reco/module/item_level/data", "");
DEFINE_bool(update_item_level_to_redis, true, "whethor update item level info to redis");

DEFINE_int32(item_expiry_calculator_thread_num, 50, "dig grave judger thread number");
DEFINE_int32(item_expiry_calculator_time_interval_second, 30, "time interval to calculate dig grave item");
DEFINE_bool(enable_item_expiry_calculator, true, "enable dig grave judger");
DEFINE_int32(item_expiry_calc_hour_before, 12, "对这个时间阈值之内的新闻进行挖坟检测。小时");

const int kDefaultCTR = 1001;

ItemLevelUpdater::ItemLevelUpdater(const reco::NewsIndex* index) {
  news_index_ = index;

  stop_ = false;
  is_startup_loop_ = true;
  last_loop_min_doc_id_ = std::numeric_limits<int>::max();
  last_loop_update_timestamp_ = 0;
  last_loop_ctr_timestamp_ = 0;
  last_weekly_update_timestamp_ = 0;

  item_level_update_thread_ = new thread::Thread();
  item_ctr_update_thread_ = new thread::Thread();
  spider_data_update_thread_  = new thread::Thread();
  spider_data_dict_ = new serving_base::ExpiryMap<uint64, SpiderData>(3600 * 2);
  click_data_dict_ = new serving_base::ExpiryMap<uint64, ClickData>(3600 * 2);
  item_level_dict_ = new serving_base::ExpiryMap<uint64, ItemLevelInfo>(3600 * 2);
  time_data_dict_ = new serving_base::ExpiryMap<uint64, TimeData>(3600 * 2);
  item_info_dict_ = new serving_base::ExpiryMap<uint64, ReqItemInfo>(3600);
  item_expiry_dict_ = new serving_base::ExpiryMap<uint64, bool>(3600 * 24);

  redis_r_util_ = new RedisUtil(true);
  redis_util_ = new RedisUtil();
  hot_calc_ = new HotCalculator(index);
  sensitive_calc_ = new SensitiveCalculator();
  time_level_calc_ = new TimeLevelCalculator();
  site_level_calc_ = new SiteLevelCalculator();
  pctr_calc_ = new ItemRelativeCalculator();
  hot_db_op_ = new HotDbOp(news_index_);

  item_expiry_calc_thread_ = new thread::Thread();
  item_expiry_calculator_ = new ItemExpiryCalculator*[FLAGS_item_expiry_calculator_thread_num];
  for (int i = 0; i < FLAGS_item_expiry_calculator_thread_num; i ++) {
    item_expiry_calculator_[i] = new ItemExpiryCalculator(news_index_);
  }
}

ItemLevelUpdater::~ItemLevelUpdater() {
  delete redis_util_;
  delete redis_r_util_;
  delete hot_calc_;
  delete sensitive_calc_;
  delete time_level_calc_;
  delete site_level_calc_;
  delete pctr_calc_;
  delete spider_data_dict_;
  delete click_data_dict_;
  delete item_info_dict_;
  delete item_level_dict_;
  delete time_data_dict_;
  delete item_level_update_thread_;
  delete item_ctr_update_thread_;
  delete spider_data_update_thread_;
  delete hot_db_op_;
  for (int i = 0; i < FLAGS_item_expiry_calculator_thread_num; i ++) {
    delete item_expiry_calculator_[i];
  }
  delete[] item_expiry_calculator_;
  delete item_expiry_calc_thread_;
  delete item_expiry_dict_;
}

void ItemLevelUpdater::Start() {
  UpdateIndexSpiderData();
  item_expiry_calc_thread_->Start(NewCallback(this, &ItemLevelUpdater::ItemExpiryCalcThread));
  spider_data_update_thread_->Start(NewCallback(this, &ItemLevelUpdater::UpdateIndexSpiderDataThread));
  item_level_update_thread_->Start(NewCallback(this, &ItemLevelUpdater::UpdateIndexItemLevelThread));
  item_ctr_update_thread_->Start(NewCallback(this, &ItemLevelUpdater::UpdateIndexPredictCtrThread));
}

void ItemLevelUpdater::Stop() {
  if (!stop_) {
    stop_ = true;
    if (spider_data_update_thread_ != NULL) {
      spider_data_update_thread_->Join();
    }
    if (item_level_update_thread_ != NULL) {
      item_level_update_thread_->Join();
    }
    if (item_ctr_update_thread_ != NULL) {
      item_ctr_update_thread_->Join();
    }
  }
}

void ItemLevelUpdater::ItemExpiryCalcThread() {
  while (!stop_) {
    thread::AutoLock auto_lock(&item_expiry_calc_mutex_);

    int64 start_time = base::GetTimestamp();
    if (start_time - last_item_expiry_calc_loop_timestamp_
          < FLAGS_item_expiry_calculator_time_interval_second * 1e6) {
      base::SleepForSeconds(30);
      continue;
    }
    if (!FLAGS_enable_item_expiry_calculator)
      continue;
    last_item_expiry_calc_loop_timestamp_ = base::GetTimestamp();
    thread::ThreadPool pool(FLAGS_item_expiry_calculator_thread_num);
    for (int thread_id = 0; thread_id < FLAGS_item_expiry_calculator_thread_num; thread_id ++) {
      pool.AddTask(NewCallback(this, &ItemLevelUpdater::ItemExpiryCalcWorker,
                               thread_id, FLAGS_item_expiry_calculator_thread_num));
    }
    pool.JoinAll();
    LOG(INFO) << "finish a round of dig grave judge";
    base::LogCountersInGroup("item_level_updater");
  }
}

void ItemLevelUpdater::ItemExpiryCalcWorker(int thread_id, int thread_num) {
  const int min_doc_id = news_index_->MinDocLocalId();
  const int max_doc_id = news_index_->MaxDocLocalId();
  LOG(INFO) << "thread: " << thread_id << " min_doc_id: " << min_doc_id << ", max_doc_id: " << max_doc_id;
  // 定义 counter. total_num = invalid_num + expiry_num + cache_num + item_expiry_num + not_item_expiry_num
  int total_num = 0;
  int invalid_num = 0;
  int expiry_num = 0;
  int cache_num = 0;
  int item_expiry_num = 0;
  int not_item_expiry_num = 0;
  for (int doc_id = min_doc_id + thread_id; doc_id < max_doc_id; doc_id += thread_num) {
    ++total_num;
    uint64 item_id = 0;
    // 判断是否有效
    ReqItemInfo item_info;
    const int64 now_timestamp = base::GetTimestamp();
    if (!news_index_->IsValidByDocId(doc_id)
        || news_index_->IsExpiredByDocId(doc_id, now_timestamp)
        || !news_index_->GetItemIdByDocId(doc_id, &item_id)
        || !GetReqItemInfo(doc_id, &item_info)) {
      ++invalid_num;
      continue;
    }
    // 挖坟文章时间限时判断： crawl_time 没有在当前 22 小时以内
    base::Time expire_time = base::Time::Now()
                             - base::TimeDelta::FromHours(FLAGS_item_expiry_calc_hour_before);
    const int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
    int64 crawl_time = news_index_->GetCrawlTimestampByDocId(doc_id);
    if (crawl_time < expire_timestamp) {
      ++expiry_num;
      continue;
    }
    // 是否命中了上一轮计算的 cache
    bool is_expiry_item = false;
    if (item_expiry_dict_->FindSilently(item_id, &is_expiry_item)) {
      ++cache_num;
      continue;
    }
    // 进行是否挖坟文章的判断
    const int64 start_time = base::GetTimestamp();
    is_expiry_item = item_expiry_calculator_[thread_id]->IsExpiryItem(item_info);
    item_expiry_dict_->Add(item_id, is_expiry_item);
    const int64 time_comsume = base::GetTimestamp() - start_time;
    LOG(INFO) << "itemid: " << item_id << ", time consume: " << time_comsume;
    // 输出日志
    is_expiry_item ? ++item_expiry_num : ++not_item_expiry_num;
    LOG_EVERY_N(INFO, 1000) << "thread: " << thread_id
            << ", calc total : " << total_num << ", invalid : " << invalid_num
            << ", expiry : " << expiry_num << ", cache : " << cache_num
            << ", dig grave : " << item_expiry_num << ", not dig grave : " << not_item_expiry_num;
  }
  LOG(INFO) << "thread: " << thread_id << " finished"
            << ", calc total : " << total_num << ", invalid : " << invalid_num
            << ", expiry : " << expiry_num << ", cache : " << cache_num
            << ", dig grave : " << item_expiry_num << ", not dig grave : " << not_item_expiry_num;
}

void ItemLevelUpdater::UpdateIndexPredictCtrThread() {
  while (!stop_) {
    thread::AutoLock auto_lock(&item_ctr_update_mutex_);

    int64 start_t = base::GetTimestamp();
    if (start_t - last_loop_ctr_timestamp_ < FLAGS_itemlevel_ctr_loop_second * 1e6) {
      base::SleepForSeconds(30);
      continue;
    }

    LOG(INFO) << "run itemctr update: " << start_t;

    UpdateIndexItemCtr();

    LOG(INFO) << "recent itemctr update cost "
              << static_cast<int>((base::GetTimestamp() - start_t) / 1e6) << " seconds";
  }
}

void ItemLevelUpdater::UpdateIndexItemLevelThread() {
  while (!stop_) {
    thread::AutoLock auto_lock(&item_level_update_mutex_);

    int64 start_t = base::GetTimestamp();
    if (start_t - last_loop_update_timestamp_ < FLAGS_itemlevel_update_loop_second * 1e6) {
      base::SleepForSeconds(30);
      continue;
    }

    LOG(INFO) << "run itemlevel update: " << start_t;

    ReloadDict();
    UpdateIndexItemLevel();

    LOG(INFO) << "recent itemlevel update cost "
              << static_cast<int>((base::GetTimestamp() - start_t) / 1e6) << " seconds";
  }
}

void ItemLevelUpdater::ReloadDict() {
  LOG(INFO) << "reload dict start";
  hot_calc_->ReloadDict(FLAGS_item_level_data_dir);
  time_level_calc_->ReloadDict(FLAGS_item_level_data_dir);
  site_level_calc_->ReloadDict(FLAGS_item_level_data_dir);
  sensitive_calc_->ReloadDict(FLAGS_item_level_data_dir);
  LOG(INFO) << "reload dict finish";
}

void ItemLevelUpdater::UpdateIndexSpiderDataThread() {
  while (!stop_) {
    thread::AutoLock auto_lock(&spider_data_update_mutex_);
    int64 start_t = base::GetTimestamp();
    if (start_t - last_update_spider_data_timestamp_ < FLAGS_spider_data_update_loop_second * 1e6) {
      base::SleepForSeconds(60);
      continue;
    }
    LOG(INFO) << "run spider data update: " << start_t;

    UpdateIndexSpiderData();

    LOG(INFO) << "recent spider data update cost "
              << static_cast<int>((base::GetTimestamp() - start_t) / 1e6) << " seconds";
  }
}

void ItemLevelUpdater::UpdateIndexSpiderData() {
  LOG(INFO) << "begin to update spider data ... ";

  last_update_spider_data_timestamp_ = base::GetTimestamp();

  uint64 now_timestamp = base::GetTimestamp();
  int min_doc_id = news_index_->MinDocLocalId();
  int max_doc_id = news_index_->MaxDocLocalId();

  uint64 item_id;
  SpiderData spider_data;
  std::vector<uint64> update_items;
  for (int doc_id = min_doc_id; doc_id < max_doc_id; ++doc_id) {
    if (!news_index_->IsValidByDocId(doc_id)
        || news_index_->IsExpiredByDocId(doc_id, now_timestamp)
        || !news_index_->GetItemIdByDocId(doc_id, &item_id)) {
      continue;
    }
    update_items.push_back(item_id);
  }

  int64 begin_ts = base::GetTimestamp();
  std::vector<std::pair<int64, RedisData> > spider_data_vec;
  if (!update_items.empty()) {
    redis_r_util_->BatchGetItemSpiderData(update_items, &spider_data_vec);
  }
  int64 end_ts = base::GetTimestamp();

  for (auto iter = spider_data_vec.begin(); iter != spider_data_vec.end(); ++iter) {
    if (iter->first == 0) continue;
    spider_data_dict_->Add(iter->first, iter->second.spider_data);
    click_data_dict_->Add(iter->first, iter->second.click_data);
  }

  LOG(INFO) << "finish to update spider data dict"
            << ", update size: " << update_items.size()
            << ", total size: " << spider_data_dict_->Size()
            << ", read redis cost: " << end_ts - begin_ts;
}

float ItemLevelUpdater::WilsonIntervalRatio(int numerator, int denominator) {
  if (numerator == 0 or denominator == 0) {
    return 0.0;
  }
  float n = float(denominator);
  float p = float(numerator) / float(denominator);
  p = std::max(p, 0.0f);
  p = std::min(p, 1.0f);
  float z = 1.96;
  float result_numerator = n * p + z * z / 2 - z * sqrt(n * p * (1 - p) + z * z / 4);
  float result_denominator = n + z * z;
  float result = result_numerator / result_denominator;
  result = std::max(result, 0.0f);
  result = std::min(result, 1.0f);
  return result;
}

int ItemLevelUpdater::CalcWilsonCtr(uint64 item_id, int click, int show) {
  int ctr = kDefaultCTR;
  if (show > 0) {
    float wilson_ctr = WilsonIntervalRatio(click, show);
    ctr = int(wilson_ctr * 1000);
  }
  return ctr;
}

void ItemLevelUpdater::UpdateIndexItemCtr() {
  base::Time now_time = base::Time::Now();
  base::Time daily_expire_item_time = now_time - base::TimeDelta::FromHours(24);
  base::Time weekly_expire_item_time = now_time - base::TimeDelta::FromHours(24 * 7);

  uint64 now_timestamp = base::GetTimestamp();
  static const std::unordered_set<int> kNeedSpiderScoreItemTypeSet = {reco::kHumor, reco::kPureVideo};

  // 周级别的更新
  bool need_weekly_update = false;
  if (now_timestamp - last_weekly_update_timestamp_ >= FLAGS_weekly_update_interval_second * 1e6) {
    need_weekly_update = true;
    last_weekly_update_timestamp_ = now_timestamp;
  }

  int min_doc_id = news_index_->MinDocLocalId();
  int max_doc_id = news_index_->MaxDocLocalId();
  int invalid_num = 0;
  int calc_num = 0;
  int total_num = 0;
  SpiderData  spider_data;
  ClickData click_data;
  TimeData time_data;
  ReqItemInfo item_info;
  ItemLevelInfo level_info;
  DynamicInfo dynamic_info;
  base::TimeDelta delta;
  std::vector<ItemLevelInfo> level_results;
  std::vector<ReqItemInfo> item_request;
  std::vector<DynamicInfo> ctr_info;
  std::vector<std::string> categories;
  LOG(INFO) << "index info, min_doc_id: " << min_doc_id
            << ", max_doc_id: " << max_doc_id;
  for (int doc_id = min_doc_id; doc_id < max_doc_id; ++doc_id) {
    ++total_num;
    if (!news_index_->IsValidByDocId(doc_id)
        || news_index_->IsExpiredByDocId(doc_id, now_timestamp)) {
      ++invalid_num;
      continue;
    }

    // 抽取计算所需的 item 属性
    if (!GetReqItemInfo(doc_id, &item_info)) continue;

    // 计算 item level
    ++calc_num;
    level_info.reset();
    level_info.item_id = item_info.item_id;
    time_data.reset();
    if (time_data_dict_->FindSilently(item_info.item_id, &time_data)) {
      level_info.hot_level = time_data.hot_level;
      level_info.time_level = time_data.time_level;
      level_info.site_level = time_data.site_level;
      level_info.sensitive_type = time_data.sensitive_type;
      level_info.spider_score = time_data.spider_score;
    }
    VLOG(2) << "itemid: " << item_info.item_id
            << " hotlevel: " << level_info.hot_level
            << " time_level: " << level_info.time_level
            << " site_level: " << level_info.site_level
            << " sensitive_type: " << level_info.sensitive_type
            << " spider_score: " << level_info.spider_score;
    click_data.reset();
    if (click_data_dict_->FindSilently(item_info.item_id, &click_data)) {
      dynamic_info.wilson_ctr = CalcWilsonCtr(item_info.item_id, click_data.click_count,
                                            click_data.show_count);
    } else {
      dynamic_info.wilson_ctr = kDefaultCTR;
    }

    // time
    int64 time_elapse = base::GetTimestamp() - item_info.pub_time;
    delta = base::TimeDelta::FromMicroseconds(time_elapse);
    dynamic_info.time = delta.InDays();
    if (dynamic_info.time > 7) {
      dynamic_info.time = 7;
    }

    // 是否更新到 redis
    if (NeedUpdateToModel(level_info, item_info, click_data)) {
      level_info.last_show = click_data.show_count;
      //PrintItemInfo(item_info, level_info, dynamic_info);
      level_results.push_back(level_info);
      item_request.push_back(item_info);
      ctr_info.push_back(dynamic_info);
    }
  }
  int64 begin_ts = base::GetTimestamp();
  pctr_calc_->CalcItemRelative(item_request, ctr_info, level_results);
  int64 end_ts = base::GetTimestamp();

  std::vector<ItemLevelInfo> level_redis;
  ChooseUpdateToRedis(level_results, &level_redis);

  int64 write_begin = base::GetTimestamp();
  if (FLAGS_update_item_level_to_redis) {
    redis_util_->BatchWriteItemLevel(level_redis);
    hot_db_op_->BatchWriteHotItem(level_redis);
  }
  int64 write_end = base::GetTimestamp();
  last_loop_ctr_timestamp_ = write_end;

  LOG(INFO) << "succ to update item ctr"
            << ", global update: " << need_weekly_update
            << ", total num: " << total_num
            << ", invalid num: " << invalid_num
            << ", update num: " << level_redis.size()
            << ", calc num: " << calc_num
            << ", predict time: " << end_ts - begin_ts
            << ", write redis time: " << write_end - write_begin;
}

void ItemLevelUpdater::UpdateIndexItemLevel() {
  base::Time now_time = base::Time::Now();
  base::Time daily_expire_item_time = now_time - base::TimeDelta::FromHours(24);
  base::Time weekly_expire_item_time = now_time - base::TimeDelta::FromHours(24 * 7);

  uint64 now_timestamp = base::GetTimestamp();
  static const std::unordered_set<int> kNeedSpiderScoreItemTypeSet = {reco::kHumor, reco::kPureVideo};

  // 周级别的更新
  bool need_weekly_update = false;
  if (now_timestamp - last_weekly_update_timestamp_ >= FLAGS_weekly_update_interval_second * 1e6) {
    need_weekly_update = true;
    last_weekly_update_timestamp_ = now_timestamp;
  }

  int min_doc_id = news_index_->MinDocLocalId();
  int max_doc_id = news_index_->MaxDocLocalId();
  int invalid_num = 0;
  int calc_num = 0;
  int total_num = 0;
  SpiderData  spider_data;
  ReqItemInfo item_info;
  TimeData time_data;
  reco::ItemType item_type;
  LOG(INFO) << "index info, min_doc_id: " << min_doc_id
            << ", max_doc_id: " << max_doc_id;
  for (int doc_id = min_doc_id; doc_id < max_doc_id; ++doc_id) {
    ++total_num;
    if (!news_index_->IsValidByDocId(doc_id)
        || news_index_->IsExpiredByDocId(doc_id, now_timestamp)) {
      ++invalid_num;
      continue;
    }

    // 抽取计算所需的 item 属性
    if (!GetReqItemInfo(doc_id, &item_info)) continue;

    if (doc_id <= last_loop_min_doc_id_
        || is_startup_loop_
        || item_info.producer != reco::common::kZZDProducer) {
      // 不过滤任意 item
    } else if (need_weekly_update) {
      // 周级别更新
      if (item_info.publish_time < weekly_expire_item_time) continue;
    } else {
      // 例行更新, 天级别更新
      if (item_info.publish_time < daily_expire_item_time) continue;
    }

    // 计算 item level
    ++calc_num;
    time_data.reset();
    bool is_new_doc = doc_id < last_loop_min_doc_id_;
    time_data.hot_level = hot_calc_->CalcHotScore(item_info, is_new_doc);
    time_data.time_level = time_level_calc_->CalcTimeLevel(item_info, *item_expiry_dict_);
    time_data.site_level = site_level_calc_->CalcSiteLevel(item_info);
    time_data.sensitive_type = sensitive_calc_->CalcItemSensitive(item_info);
    spider_data.reset();
    if (spider_data_dict_->FindSilently(item_info.item_id, &spider_data)) {
      if (news_index_->GetItemTypeByDocId(doc_id, &item_type)
        && kNeedSpiderScoreItemTypeSet.find(item_type) == kNeedSpiderScoreItemTypeSet.end()) {
        time_data.spider_score = hot_calc_->CalcSpiderScore(item_info, spider_data);
      }
    }
    time_data_dict_->Add(item_info.item_id, time_data);
  }

  last_loop_min_doc_id_ = min_doc_id;
  is_startup_loop_ = false;

  int64 write_end = base::GetTimestamp();
  last_loop_update_timestamp_ = write_end;

  LOG(INFO) << "succ to update item level"
            << ", total num: " << total_num
            << ", invalid num: " << invalid_num
            << ", calc num: " << calc_num
            << ", first_update: " << is_startup_loop_;
}

bool ItemLevelUpdater::GetTitle(const std::vector<std::string>& title_unigrams,
                                std::string *title, std::string *bititle) {
  nlp::rune::RuneTypeDetector detector;
  std::string last_str = "";
  for (unsigned index = 0; index < title_unigrams.size(); ++index) {
    std::string term_str = title_unigrams[index];
    int type = detector.SingleRuneTypeDetect(term_str);
    if (type == nlp::rune::kNumber ||
        type == nlp::rune::kWhiteSpace ||
        type == nlp::rune::kPunctuation) {
      last_str = "";
      continue;
    }

    int32 length;
    if (!base::GetUTF8CharNum(term_str, &length)) continue;
    if (length > 1) {
      // unigram
      if (title->empty()) *title = term_str;
      else *title += "," + term_str;
    }

    // bigram
    if (last_str != "") {
      std::string bigram = last_str + term_str;
      if (bititle->empty()) *bititle = bigram;
      else *bititle += "," + bigram;
    }
    last_str = term_str;
  }
  return true;
}

bool ItemLevelUpdater::GetReqItemInfo(int32 doc_id, ReqItemInfo* item_info) {
  uint64 item_id;
  if (!news_index_->GetItemIdByDocId(doc_id, &item_id)) {
    LOG(WARNING) << "doc has no item_id, " << doc_id;
    return false;
  }
  item_info->reset();
  // 如果缓存中有直接返回
  if (item_info_dict_->Find(item_id, item_info)) {
    // 缓存中的 review 状态 每次都重新计算
    bool is_oper_item = (item_info->producer != reco::common::kZZDProducer);
    item_info->has_reviewed = (is_oper_item || IfItemHasReviewed(doc_id));
    return true;
  }
  // 抽取所需要的各维度数据
  if (!news_index_->GetItemTypeByDocId(doc_id, &item_info->item_type)) {
    LOG(WARNING) << "doc has no item_type, " << doc_id << ", " << item_id;
    return false;
  }

  item_info->item_id = item_id;

  if (!news_index_->GetProducerByDocId(doc_id, &item_info->producer)) {
    item_info->producer.clear();
  }
  bool is_oper_item = (item_info->producer != reco::common::kZZDProducer);
  item_info->has_reviewed = (is_oper_item || IfItemHasReviewed(doc_id));

  if (!news_index_->GetAreaUnigramsByDocId(doc_id, adsindexing::kTitleArea, &item_info->title_unigrams)) {
    item_info->title_unigrams.clear();
  }
  // 填充 sim itemid
  item_info->item_sim_vec = news_index_->GetSimItemIds(item_id);

  item_info->image_count = news_index_->GetImageCountByDocId(doc_id);

  item_info->channels.clear();
  CHECK(news_index_->GetChannelsByDocId(doc_id, &item_info->channels));

  std::vector<std::string> categories;
  news_index_->GetCategoriesByDocId(doc_id, &categories);
  item_info->category = categories.empty() ? "" : categories[0];
  item_info->snd_category = categories.size() < 2u ? "" : categories[1];

  news_index_->GetSourceByItemId(item_info->item_id, &item_info->source);
  news_index_->GetItemContentByItemId(item_info->item_id, &item_info->content);
  int64 timestamp = news_index_->GetCreateTimestampByItemId(item_info->item_id);
  item_info->publish_time = base::Time::FromDoubleT(timestamp / base::Time::kMicrosecondsPerSecond);

  // title
  if (!GetTitle(item_info->title_unigrams, &(item_info->title), &(item_info->bititle))) {
    item_info->title = "|missing";
    item_info->bititle = "|missing";
  }
  if (item_info->title == "") {
    item_info->title = "|missing";
  }
  if (item_info->bititle == "") {
    item_info->bititle = "|missing";
  }

  // time
  item_info->pub_time = news_index_->GetPublishSecondByItemId(item_id) * base::Time::kMicrosecondsPerSecond;

  // source_media
  if (!news_index_->GetOrigSourceMediaByDocId(doc_id, &item_info->source_media) ||
      item_info->source_media == "") {
    if (!news_index_->GetOrigSourceByDocId(doc_id, &item_info->source_media) ||
        item_info->source_media == "") {
      if (!news_index_->GetSourceMediaByDocId(doc_id, &item_info->source_media) ||
          item_info->source_media == "") {
        if (!news_index_->GetSourceByDocId(doc_id, &item_info->source_media) ||
            item_info->source_media == "") {
          item_info->source_media = "|missing";
        }
      }
    }
  }

  // tags
  item_info->tags = "";
  reco::FeatureVector tag;
  news_index_->GetFeatureVectorByItemId(item_id, reco::common::kTag, &tag);
  for (int i = 0; i < tag.feature_size(); ++i) {
    auto& item_fea = tag.feature(i);
    if (item_fea.literal().empty()) continue;
    if (item_info->tags == "") item_info->tags = tag.feature(i).literal();
    else item_info->tags += "," + tag.feature(i).literal();
  }
  if (item_info->tags == "") item_info->tags = "|missing";

  // categories
  item_info->categories = "";
  for (unsigned i = 0; i < categories.size(); ++i) {
    if (categories[i].empty()) continue;
    if (item_info->categories == "") item_info->categories = categories[i];
    else item_info->categories += "," + categories[i];
  }
  if (item_info->categories == "") {
    item_info->categories = "|missing";
  }

  // 加入缓存
  item_info_dict_->Add(item_id, *item_info);

  return true;
}

#define CALC_SIGN(attr) base::CalcTermSign(attr, strlen(attr))

bool ItemLevelUpdater::IfItemHasReviewed(int32 doc_id) const {
  const adsindexing::Index* index = news_index_->GetAdsIndex();
  static const uint64 kItemHasReviewedSign = CALC_SIGN(reco::common::attr_key::kItemHasReviewed);
  int64 attr = index->GetIntAttr(kItemHasReviewedSign, doc_id, 0);
  return attr > 0;
}

void ItemLevelUpdater::PrintItemInfo(const ReqItemInfo& item_info,
                                     const ItemLevelInfo& level_info,
                                     const DynamicInfo& dynamic_info) const {
  std::string str_channel;
  for (int k = 0; k < (int)item_info.channels.size(); ++k) {
    if (k != 0) str_channel.append("|");
    str_channel.append(base::Int64ToString(item_info.channels[k]));
  }
  std::string str_time;
  CHECK(item_info.publish_time.ToStringInFormat("%Y-%m-%d", &str_time));
  const std::string& title = base::JoinStrings(item_info.title_unigrams, "");
  LOG(INFO) << "[ItemLevelInfo], " << item_info.item_id << "\t" << item_info.item_type
            << "\t" << item_info.category << "\t" << str_channel
            << "\t" << item_info.source << "\t" << str_time
            << "\t" << level_info.time_level << "\t" << level_info.site_level
            << "\t" << level_info.hot_level << "\t" << level_info.sensitive_type
            << "\t" << level_info.spider_score << "\t" << title
            << "\t" << item_info.title << "\t" << item_info.bititle
            << "\t" << item_info.source_media << "\t" << item_info.tags
            << "\t" << item_info.categories << "\t" << item_info.pub_time
            << "\t" << dynamic_info.wilson_ctr << "\t" << dynamic_info.time
            << "\t" << level_info.predict_ctr;
}

void ItemLevelUpdater::ChooseUpdateToRedis(std::vector<ItemLevelInfo>& level_results,
                                           std::vector<ItemLevelInfo>* level_redis) {
  //ItemLevelInfo tmp_info;
  //bool need_update = false;
  for (unsigned i = 0; i < level_results.size(); ++i) {
    const ItemLevelInfo& level_info = level_results[i];
    /*need_update = false;
    if (item_level_dict_->FindSilently(level_info.item_id, &tmp_info)) {
      if (level_info.hot_level != ItemLevelInfo::kDftVal
          && level_info.hot_level != tmp_info.hot_level) {
        need_update = true;
      } else if (level_info.time_level != ItemLevelInfo::kDftVal
                 && level_info.time_level != tmp_info.time_level) {
        need_update = true;
      } else if (level_info.sensitive_type != ItemLevelInfo::kDftVal
                 && level_info.sensitive_type != tmp_info.sensitive_type) {
        need_update = true;
      } else if (level_info.spider_score != ItemLevelInfo::kDftVal
                 && level_info.spider_score != tmp_info.spider_score) {
        need_update = true;
      } else if (level_info.site_level != ItemLevelInfo::kDftVal
                 && level_info.site_level != tmp_info.site_level) {
        need_update = true;
      } else if (level_info.predict_ctr != ItemLevelInfo::kDftVal) {
        if (tmp_info.predict_ctr == ItemLevelInfo::kDftVal) {
          need_update = true;
        } else {
          int delta = tmp_info.predict_ctr - level_info.predict_ctr;
          if (delta < 0) delta = -delta;
          if (delta >= 10) {
            need_update = true;
          }
        }
      }
    } else {
      need_update = true;
    }*/

    //if (need_update) {
      level_redis->push_back(level_info);
      item_level_dict_->Add(level_info.item_id, level_info);
    //}
  }

  return;
}

bool ItemLevelUpdater::NeedUpdateToModel(const ItemLevelInfo& level_info,
                                         const ReqItemInfo& item_info,
                                         const ClickData& click_data) const {
  ItemLevelInfo tmp_info;
  bool need_update = false;
  if (item_level_dict_->FindSilently(level_info.item_id, &tmp_info)) {
    if (level_info.hot_level != ItemLevelInfo::kDftVal
        && level_info.hot_level != tmp_info.hot_level) {
      need_update = true;
    } else if (level_info.time_level != ItemLevelInfo::kDftVal
               && level_info.time_level != tmp_info.time_level) {
      need_update = true;
    } else if (level_info.sensitive_type != ItemLevelInfo::kDftVal
               && level_info.sensitive_type != tmp_info.sensitive_type) {
      need_update = true;
    } else if (level_info.spider_score != ItemLevelInfo::kDftVal
               && level_info.spider_score != tmp_info.spider_score) {
      need_update = true;
    } else if (level_info.site_level != ItemLevelInfo::kDftVal
               && level_info.site_level != tmp_info.site_level) {
      need_update = true;
    } else if (click_data.show_count != 0
               && tmp_info.last_show != click_data.show_count) {
      if (item_info.item_type == reco::kNews ||
          item_info.item_type == reco::kPicture ||
          item_info.item_type == reco::kReading ||
          item_info.item_type == reco::kPictureNews) {
        need_update = true;
      }
    }
  } else {
    need_update = true;
  }

  return need_update;
}

}
}
