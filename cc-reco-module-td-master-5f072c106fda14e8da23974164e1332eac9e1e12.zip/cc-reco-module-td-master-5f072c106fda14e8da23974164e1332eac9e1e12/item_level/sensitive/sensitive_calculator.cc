#include "reco/module/item_level/sensitive/sensitive_calculator.h"
#include <vector>
#include "reco/bizc/common/appname_define.h"
#include "nlp/common/nlp_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace item_level {

DEFINE_bool(do_sensitive_keyword_filter, true, "是否进行敏感词过滤");
DEFINE_bool(do_sensitive_source_filter, false, "是否进行敏感源过滤");
DEFINE_bool(do_ucb_deny_source_filter, false, "是否过滤ucb禁止源");

const char* SensitiveCalculator::kWhiteSourceFile      = "category_white_source.txt";
const char* SensitiveCalculator::kSensitiveKeywordFile = "sensitive_keyword.txt";
const char* SensitiveCalculator::kSourceStatusFile = "source_info.txt";

SensitiveCalculator::SensitiveCalculator() {
  sensitive_keyword_dict_ = new util::SensitiveDict();
}

SensitiveCalculator::~SensitiveCalculator() {
  delete sensitive_keyword_dict_;
}

SensitiveType SensitiveCalculator::CalcItemSensitive(const ReqItemInfo& item_info) const {
  // 运营文章直接设置为不敏感
  if (item_info.producer != reco::common::kZZDProducer) return kNoSensitive;

  // NOTE(jianhuang) 以下敏感级别由高到低进行判断

  // 特定分类下，限定只展现几个白名单下的源的文章
  if (FLAGS_do_sensitive_source_filter
      && !item_info.has_reviewed
      && !item_info.category.empty()) {
    auto category_source_dict = white_source_dict_.GetDict();
    std::vector<std::string> keys;
    keys.push_back(item_info.category);
    if (!item_info.snd_category.empty()) {
      keys.push_back(item_info.category + "-" + item_info.snd_category);
    }
    for (int k = 0; k < (int)keys.size(); ++k) {
      auto iter = category_source_dict->find(keys[k]);
      if (iter == category_source_dict->end()) continue;
      const std::unordered_set<std::string>& source_set = iter->second;
      if (source_set.find(item_info.source) == source_set.end()) {
        return kHighPoliticsSensitive;
      }
    }
  }

  // 命中敏感词
  if (FLAGS_do_sensitive_keyword_filter
      && !item_info.has_reviewed) {
    const std::string& title = base::JoinStrings(item_info.title_unigrams, "");
    util::SensitiveLevel level;
    std::string match_item;
    bool hit = false;
    if (sensitive_keyword_dict_->GetSensitiveInfo(title, &level, &hit, &match_item) && hit) {
      LOG(INFO) << "item " << item_info.item_id << ", title: " << title
        << ", hit sensitive dict, match_term:" << match_item << ", level:" << level;
      if (level == util::kForbidden) {
        return kHighPoliticsSensitive;
      } else if (level == util::kInSafe || level == util::kInSafeNoReport) {
        return kPoliticsSensitive;
      }
    }
  }

  // TODO(jianhuang) 种子的下发及渠道限制移到 leaf server
  // 种子源已经删除或停止下发, 设置没有版权
  if (item_info.item_type != reco::kPureVideo) {
    auto const source_dict = source_status_dict_.GetDict();
    const std::string& key = nlp::util::NormalizeLine(item_info.source);
    auto source_iter = source_dict->find(key);
    if (source_iter == source_dict->end()) {
      return kCopyrightSensitive;
    } else if (source_iter->second.publish_status != 0
               || source_iter->second.crawl_status != 0) {
      return kCopyrightSensitive;
    } else if (source_iter->second.ucb_enable == 0) {
      if (FLAGS_do_ucb_deny_source_filter) {
        // 不能在 uc browser 上下发
        return kUcbCopyrightSensitive;
      } else if (item_info.item_type == reco::kHumor || item_info.item_type == reco::kPureVideo) {
        // 不能在 uc browser 上下发
        return kUcbCopyrightSensitive;
      }
    }
  }

  // TODO(jianhuang) porn sensitive

  return kNoSensitive;
}

bool SensitiveCalculator::ReloadDict(const base::FilePath& root_dir) {
  thread::AutoLock auto_lock(&mutex_);
  return (LoadSourceStatusFile(root_dir)
          && LoadWhiteSourceFile(root_dir)
          && LoadSensitiveKeywordFile(root_dir));
}

bool SensitiveCalculator::LoadSensitiveKeywordFile(const base::FilePath& base_dir) {
  // sensitive 模块去重载数据，全局共享
  // NOTE(jianhuang) 多个对象的时候实际上会重载同一份数据.
  // 但 sensitive 内部重载字典有时间的限制，所以影响不大
  base::FilePath sensitive_file = base_dir.Append(kSensitiveKeywordFile);
  util::SensitiveDict::ReloadDict(sensitive_file.ToString().c_str());
  return true;
}

bool SensitiveCalculator::LoadWhiteSourceFile(const base::FilePath& base_dir) {
  std::vector<std::string> lines;
  base::FilePath white_source_file = base_dir.Append(kWhiteSourceFile);
  CHECK(base::file_util::ReadFileToLines(white_source_file, &lines)) << white_source_file.ToString();

  auto white_source_dict = white_source_dict_.GetInactiveDict();
  white_source_dict->swap(std::unordered_map<std::string, std::unordered_set<std::string> >());

  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u) {
      LOG(ERROR) << "sensitive source field error, " << lines[i];
      continue;
    }
    const std::string& category = flds[0];
    std::unordered_set<std::string>& source_set = (*white_source_dict)[category];
    source_set.clear();
    for (int k = 1; k < (int)flds.size(); ++k) {
      source_set.insert(nlp::util::NormalizeLine(flds[k]));
    }
  }

  LOG(INFO) << "category white source dict load succ"
            << ", file size: " << lines.size()
            << ", dict size: " << white_source_dict->size();

  white_source_dict_.SwitchDict();

  return true;
}

bool SensitiveCalculator::LoadSourceStatusFile(const base::FilePath& base_dir) {
  std::vector<std::string> lines;
  base::FilePath source_info_file = base_dir.Append(kSourceStatusFile);
  CHECK(base::file_util::ReadFileToLines(source_info_file, &lines)) << source_info_file.ToString();

  auto source_status_dict = source_status_dict_.GetInactiveDict();
  source_status_dict->clear();

  std::vector<std::string> flds;
  SourceStatus source_status;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 5u) {
      LOG(ERROR) << "source status file data column num error, line is: " << lines[i];
      continue;
    }
    const std::string& source_name = nlp::util::NormalizeLine(flds[0]);
    if (source_name.empty()
        || !base::StringToInt(flds[2], &source_status.publish_status)
        || !base::StringToInt(flds[3], &source_status.crawl_status)
        || !base::StringToInt(flds[4], &source_status.ucb_enable)) {
      LOG(ERROR) << "source status file record content error, line is: " << lines[i];
      continue;
    }
    // NOTE(jianhuang) 这里强制设置 crawl status 为正常, crawl status 不影响下发的逻辑
    source_status.crawl_status = 0;
    source_status_dict->insert(std::make_pair(source_name, source_status));
  }

  LOG(INFO) << "source status dict load succ, file size: " << lines.size()
            << ", dict size: " << source_status_dict->size();

  source_status_dict_.SwitchDict();

  return true;
}
}
}
