#pragma once

#include <string>
#include <unordered_map>
#include <unordered_set>
#include "reco/module/item_level/base/base.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/proto/common.pb.h"
#include "util/sensitive/sensitive.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/base.h"

namespace reco {
namespace item_level {

// 种子状态
struct SourceStatus {
  // 发布状态, 0:下发, 1:不下发
  int publish_status;
  // 抓取状态, 0:正在抓取, 1:停止抓取
  int crawl_status;
  // 是否 ucb 允许下发
  int ucb_enable;
};

// 敏感度计算模块
//
class SensitiveCalculator {
 public:
  SensitiveCalculator();
  ~SensitiveCalculator();

  // 计算敏感度
  SensitiveType CalcItemSensitive(const ReqItemInfo& item_info) const;

  // 词典重载
  bool ReloadDict(const base::FilePath& root_dir);

 private:
  bool LoadWhiteSourceFile(const base::FilePath& base_dir);
  bool LoadSensitiveKeywordFile(const base::FilePath& base_dir);
  bool LoadSourceStatusFile(const base::FilePath& base_dir);

 private:
  static const char* kWhiteSourceFile;
  static const char* kSensitiveKeywordFile;
  static const char* kSourceStatusFile;

  thread::Mutex mutex_;

  // 敏感词处理
  util::SensitiveDict* sensitive_keyword_dict_;
  // 敏感时期，有些类别只能下发指定源的文章
  reco::DynamicDict<std::unordered_map<std::string,
      std::unordered_set<std::string> > > white_source_dict_;
  // 源状态词表
  reco::DynamicDict<std::unordered_map<std::string, SourceStatus>> source_status_dict_;

  DISALLOW_COPY_AND_ASSIGN(SensitiveCalculator);
};

}  // namespace item_level
}  // namespace reco
