#include "reco/module/item_level/hot_clean/hot_clean.h"

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "");
  LOG(INFO) << "begin hot clean";
  reco::item_level::HotClean * cleaner = new reco::item_level::HotClean();
  cleaner->Run();
  delete cleaner;
  return 0;
}
