#include "reco/module/item_level/hot_clean/hot_clean.h"

#include <vector>
#include <fstream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/utf_string_conversions.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
// #include "reco/bizc/common/channels.h"

namespace reco {
namespace item_level {

DEFINE_string(dict_data_dir, "../dict/nlp", "dict dir");
DEFINE_string(data_dir, "../data", "hot_news_data_dir");
DEFINE_string(conf_dir, "../conf", "hot clean conf");
DEFINE_string(hot_news_file_prefix, "hotnews.", "hot_news_prefix");
DEFINE_string(hot_news_filter_prefix, "hotnews.filter.", "hot_news_filter_prefix");
DEFINE_string(hot_news_clean_prefix, "hotnews.clean.", "hot_news_clean_prefix");

const char* HotClean::kSourceConf = "hot_source.conf";
const char* HotClean::kChannelConf = "hot_channel.conf";


HotClean::HotClean() {
  InitData();
  LoadHotNews();
  LoadRulesConf();
}

HotClean::~HotClean() {
}

void HotClean::InitData() {
  CHECK(lex_.LoadDict(base::FilePath(FLAGS_data_dir)));
}

void HotClean::LoadHotNews() {
  LOG(INFO) << "begin to load hot news.";
  base::FilePath root_dir(FLAGS_data_dir);
  base::Time now = base::Time::Now();
  std::string date_suffix;
  CHECK(now.ToStringInFormat("%Y%m%d_%H", &date_suffix));
  base::FilePath hot_news_file = root_dir.Append(FLAGS_hot_news_file_prefix + date_suffix);

  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(hot_news_file, &lines)) {
    LOG(WARNING) << "load hot news file failed, " << hot_news_file.ToString();
    return;
  }
  hot_news_vec_.clear();
  LOG(INFO) << "hot news total num " << lines.size();
  std::vector<std::string> flds;
  for (size_t i = 0; i < lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 5) {
      LOG(WARNING) << "error flds num, when load hot news " << lines[i].size();
      continue;
    }

    // parse
    NewsStats news_stats;
    news_stats.title = flds[0];
    CHECK(base::StringToDouble(flds[1], &news_stats.score));
    news_stats.source = flds[2];
    news_stats.source_channel = flds[3];
    news_stats.time = flds[4];
    hot_news_vec_.push_back(news_stats);
  }
}

void HotClean::LoadRulesConf() {
  base::FilePath root_dir(FLAGS_conf_dir);

  // load rules conf
  base::FilePath source_conf_file = root_dir.Append(base::StringPrintf("%s", kSourceConf));
  std::vector<std::string> lines;
  std::vector<std::string> flds;
  if (!base::file_util::ReadFileToLines(source_conf_file, &lines)) {
    LOG(WARNING) << "load hot source conf failed, " << source_conf_file.ToString();
  } else {
    for (size_t i = 0; i < lines.size(); ++i) {
      flds.clear();
      base::SplitString(lines[i], "#", &flds);
      if (flds.size() < 2) {
        LOG(WARNING) << "error flds num, when load source conf " << flds.size();
        continue;
      }
      int value = 0;
      base::StringToInt(flds[1], &value);
      source_conf_map_[flds[0]] = value;
    }
  }
  // load channel conf
  base::FilePath channel_conf_file = root_dir.Append(base::StringPrintf("%s", kChannelConf));
  lines.clear();
  if (!base::file_util::ReadFileToLines(channel_conf_file, &lines)) {
    LOG(WARNING) << "load hot channel conf failed, " << channel_conf_file.ToString();
  } else {
    for (size_t i = 0; i < lines.size(); ++i) {
      flds.clear();
      base::SplitString(lines[i], "#", &flds);
      if (flds.size() < 2) {
        LOG(WARNING) << "error flds num, when load channel conf " << flds.size();
        continue;
      }
      int value = 0;
      base::StringToInt(flds[1], &value);
      channel_tuning_map_[flds[0]] = value;
    }
  }
  LOG(INFO) << "succ to load rules conf, source rule num " << source_conf_map_.size()
      << "channel rule num " << channel_tuning_map_.size();
}

void HotClean::WriteCleanHotNews() {
  LOG(INFO) << "begin to write clean hotnews to disk";
  base::FilePath root_dir(FLAGS_data_dir);
  base::Time now = base::Time::Now();
  std::string date_suffix;
  CHECK(now.ToStringInFormat("%Y%m%d_%H", &date_suffix));
  base::FilePath hot_clean_news_file = root_dir.Append(FLAGS_hot_news_clean_prefix + date_suffix);

  // 创建存储文件
  if (!base::file_util::DirectoryExists(root_dir)) {
    LOG(WARNING) << "does not exit such dir, create it, " << root_dir.ToString();
    CHECK(base::file_util::CreateDirectory(root_dir));
  }
  std::ofstream os(hot_clean_news_file.ToString());
  int count = 0;
  for (auto iter = hot_news_vec_.begin(); iter != hot_news_vec_.end(); ++iter) {
    if (!iter->is_valid) continue;
    ++count;
    os << base::StringPrintf(
        "%s\t%.1f\t%s\t%s\t%s\n",
        iter->title.c_str(),
        iter->score,
        iter->source.c_str(),
        iter->source_channel.c_str(),
        iter->time.c_str());
  }
  os.close();
  LOG(INFO) << "write clean hotnews to disk success, " << count;
}

void HotClean::WriteFilterNews() {
  LOG(INFO) << "begin to write filter hotnews to disk.";
  base::FilePath root_dir(FLAGS_data_dir);
  base::Time now = base::Time::Now();
  std::string date_suffix;
  CHECK(now.ToStringInFormat("%Y%m%d_%H", &date_suffix));
  base::FilePath hot_filter_news_file = root_dir.Append(FLAGS_hot_news_filter_prefix + date_suffix);

  // 创建存储文件
  if (!base::file_util::DirectoryExists(root_dir)) {
    LOG(WARNING) << "does not exit such dir, create it, " << root_dir.ToString();
    CHECK(base::file_util::CreateDirectory(root_dir));
  }
  std::ofstream os(hot_filter_news_file.ToString());
  int count = 0;
  for (auto iter = hot_news_vec_.begin(); iter != hot_news_vec_.end(); ++iter) {
    if (iter->is_valid) continue;
    ++count;
    os << base::StringPrintf(
        "%s\t%.1f\t%s\t%s\t%s\t%s\n",
        iter->title.c_str(),
        iter->score,
        iter->source.c_str(),
        iter->source_channel.c_str(),
        iter->time.c_str(),
        iter->filter_reason.c_str());
  }
  os.close();
  LOG(INFO) << "write filter hotnews to disk success, " << count;
}

void HotClean::Clean() {
  for (size_t idx = 0; idx < hot_news_vec_.size(); ++idx) {
    Filter(&hot_news_vec_[idx]);
    RemoveTimeStr(&hot_news_vec_[idx]);
  }
}

void HotClean::RemoveTimeStr(NewsStats *news_stats) {
  std::vector<int> entries;
  std::vector<nlp::time::SymbolTableElement> table;
  std::vector<std::vector<int> > groups;
  std::string &sentence = news_stats->title;
  std::string time_str = "";
  nlp::util::NormalizeLineInPlaceS(&sentence);
  CHECK(segmenter_.SegmentT(sentence, &container_));
  CHECK(pos_tagger_.PosTagT(sentence, &container_));
  CHECK(ner_.DetectEntityT(sentence, &container_));
  entries.clear();
  table.clear();
  groups.clear();
  lex_.GenerateTokens(sentence, container_, &entries, &table);
  if (syntax_.ParseForTimeGroups(sentence, container_, entries, &table, &groups)) {
    for (int j = 0; j < (int)groups.front().size(); ++j) {
      for (int k = table[groups.front()[j]].begin_term_idx; k < table[groups.front()[j]].end_term_idx; ++k) {
        time_str += container_.basic_term_slice(sentence, k).as_string();
      }
    }
  }

  if (time_str.size() > 0) {
    base::ReplaceSubstringsAfterOffset(&sentence, 0, time_str, "");
  }
}

std::string HotClean::DeletePuncAndSpace(const std::string& from) {
  nlp::rune::RuneTypeDetector detector;
  std::string nor_str;
  for (size_t i = 0; i < from.size(); ++i) {
    std::string character = base::StringPrintf("%c", from[i]);
    int result = detector.MultiRunesTypeDetect(character);
    if (nlp::rune::is_rune_type(result, nlp::rune::kPunctuation) == false &&
        nlp::rune::is_rune_type(result, nlp::rune::kWhiteSpace) == false) {
      nor_str += character;
    }
  }
  return nor_str;
}

bool HotClean::Filter(NewsStats *news_stats) {
  std::string nor_line = nlp::util::NormalizeLine(news_stats->title);
  std::string nor_title = DeletePuncAndSpace(nor_line);
  base::Slice slice(nor_title.c_str());
  int title_len;
  CHECK(base::GetUTF8CharNum(slice, &title_len));

  // 标题长度过滤
  if (title_len < 7) {
    news_stats->is_valid = false;
    news_stats->filter_reason = "TITLE LEN FILTER";
    return false;
  }
  // 源过滤
  auto source_iter = source_conf_map_.find(news_stats->source);
  if (source_iter != source_conf_map_.end()) {
    news_stats->is_valid = false;
    news_stats->filter_reason = "SOURCE FILTER";
    return false;
  }

  // 源频道过滤，作用类似于类别过滤
  auto channel_iter = channel_tuning_map_.find(news_stats->source_channel);
  if (channel_iter != channel_tuning_map_.end()) {
    if (title_len < channel_iter->second) {
      news_stats->is_valid = false;
      news_stats->filter_reason = "CHANNEL FILTER";
      return false;
    }
  }

  // 短文本降权
  if (title_len < 8) {
    news_stats->score *= 0.8;
  } else if (title_len < 15) {
    news_stats->score *= 0.9;
  } else if (title_len > 25) {
    news_stats->score *= 1.05;
  }
  return true;
}

void HotClean::Run() {
  Clean();
  WriteCleanHotNews();
  WriteFilterNews();
}

}  // namespace item_level
}  // namespace reco
