#pragma once

#include <utility>
#include <vector>
#include <string>
#include <unordered_map>

#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/base.h"

#include "nlp/common/rune_type.h"
#include "nlp/time/time_lex.h"
#include "nlp/time/time_syntax_analyzier.h"
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"

#include "reco/module/item_level/base/base.h"
namespace reco {
namespace item_level {

struct NewsStats {
  NewsStats() {
    reset();
  }
  std::string title;
  std::string source;
  std::string source_channel;
  std::string time;
  double score;
  bool is_valid;
  std::string filter_reason;
  void reset() {
    title = "";
    source = "";
    source_channel = "";
    score = 1.0;
    time = "";
    is_valid = true;
    filter_reason = "";
  }
};

class HotClean {
 public:
  HotClean();
  ~HotClean();
  void Run();
 private:
  void InitData();
  void Clean();
  void LoadHotNews();
  void LoadRulesConf();
  //  删除标点和空白符
  std::string DeletePuncAndSpace(const std::string& from);
  void WriteCleanHotNews();
  void WriteFilterNews();
  void RemoveTimeStr(NewsStats * news_stats);
  bool Filter(NewsStats * news_stats);
  std::vector<NewsStats> hot_news_vec_;
  nlp::time::TimeLex lex_;
  nlp::time::TimeSyntaxAnalyzier syntax_;
  nlp::segment::Segmenter segmenter_;
  nlp::postag::PosTagger pos_tagger_;
  nlp::ner::Ner ner_;
  nlp::term::TermContainer container_;
  std::unordered_map<std::string, int> source_conf_map_;
  std::unordered_map<std::string, int> channel_tuning_map_;
  static const char* kSourceConf;
  static const char* kChannelConf;
};

}  // namespace item_level
}  // namespace reco
