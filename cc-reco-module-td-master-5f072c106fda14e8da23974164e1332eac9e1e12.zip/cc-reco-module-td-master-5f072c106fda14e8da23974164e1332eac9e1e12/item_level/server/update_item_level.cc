#include <iostream>

#include "reco/module/item_level/updater/item_level_updater.h"
#include "reco/module/item_level/base/connection_manager.h"
#include "reco/module/item_level/base/connection_manager_r.h"
#include "reco/bizc/index_monitor/api/index_monitor.h"
#include "reco/bizc/reco_index/news_index.h"
#include "serving_base/utility/signal.h"
#include "reco/ml/model_server/api/model_server_api.h"

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "");

  CHECK(reco::item_level::ConnectionManager::InitConnection()) << "Initialize connection error.";
  CHECK(reco::item_level::ConnectionManagerR::InitConnection()) << "Initialize connection error.";

  reco::index_monitor::IndexMonitor monitor;
  monitor.Start();

  LOG(INFO) << "index monitor started";
  adsindexing::Index* index = monitor.GetIndex();

  int32 doc_num = index->GetDocNum();
  LOG(INFO) << "doc_num: " << doc_num;

  // model server api
  reco::model_server::ModelServerAPIIns::instance().Init();

  reco::NewsIndex* news_index = reco::InitializeNewsIndex(index);

  reco::item_level::ItemLevelUpdater* updater = new reco::item_level::ItemLevelUpdater(news_index);
  updater->Start();

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();

  LOG(INFO) << "finish signal. ";

  updater->Stop();

  delete updater;

  reco::item_level::ConnectionManager::CleanConnection();
  reco::item_level::ConnectionManagerR::CleanConnection();

  return 0;
}
