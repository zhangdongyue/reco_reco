#include <iostream>

#include "reco/module/item_level/updater/item_stats_updater.h"
#include "reco/module/item_level/base/connection_manager.h"
#include "reco/bizc/index_monitor/api/index_monitor.h"
#include "reco/bizc/reco_index/news_index.h"
#include "serving_base/utility/signal.h"

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "");

  CHECK(reco::item_level::ConnectionManager::InitConnection()) << "Initialize connection error.";

  reco::item_level::ItemStatsUpdater* producer = new reco::item_level::ItemStatsUpdater();
  producer->Start();

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();

  LOG(INFO) << "finish signal. ";

  producer->Stop();

  delete producer;

  reco::item_level::ConnectionManager::CleanConnection();

  return 0;
}
