#include <algorithm>

#include "reco/module/item_level/hot_level/city_hot.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace item_level {

DEFINE_int32(max_hot_score, 20, "max hot score");

const char* CityHotCalculator::kCityHotItemFile = "city_hot_item.txt";

int CityHotCalculator::CalcHotScore(const ReqItemInfo& item_info) const {
  auto const hot_dict = hot_item_dict_.GetDict();
  auto it = hot_dict->find(item_info.item_id);
  if (it == hot_dict->end())
    return 0;

  return std::min(FLAGS_max_hot_score, it->second);
}

bool CityHotCalculator::ReloadDict(const base::FilePath& root_dir) {
  LOG(INFO) << "reload city hot dict start";

  std::vector<std::string> lines;
  base::FilePath hot_file = root_dir.Append(kCityHotItemFile);
  CHECK(base::file_util::ReadFileToLines(hot_file, &lines)) << hot_file.ToString();

  if (lines.empty()) {
    LOG(INFO) << "read city hot file empty [" << hot_file.ToString() << "]";
    return true;
  }

  auto hot_dict = hot_item_dict_.GetInactiveDict();
  hot_dict->swap(std::unordered_map<uint64, int>());

  int error_line = 0;
  int dup_city_line = 0;
  int no_city_line = 0;
  int expire_line = 0;

  base::Time publish_time;
  base::Time now_t = base::Time::Now();

  uint64 item_id = 0;
  int score = 0;
  std::vector<std::string> flds;
  for (size_t i = 0; i < lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);

    if (flds.size() < 17u
        || !base::StringToUint64(flds[2], &item_id)
        || !base::Time::FromStringInSeconds(flds[4].c_str(), &publish_time)
        || !base::StringToInt(flds[3], &score)) {
      LOG(ERROR) << "parse city hot file error, line: " << lines[i];
      ++error_line;
      continue;
    }

    if ((now_t - publish_time).InHours() > 24 * 3) {
      ++expire_line;
      continue;
    }

    if (flds[0].empty()) {
      ++no_city_line;
      continue;
    }

    score = std::max(0, score);

    auto it = hot_dict->find(item_id);
    if (it == hot_dict->end()) {
      hot_dict->insert(std::make_pair(item_id, score));
    } else {
      ++dup_city_line;
      it->second = std::max(score, it->second);
    }
  }

  LOG(INFO) << "reload city hot dict success: "
            << "\thot_item_dict size: " << hot_item_dict_.GetDict()->size()
            << "\terror line: " << error_line
            << "\texpire line: " << expire_line
            << "\tno city line: " << no_city_line
            << "\tdup city line: " << dup_city_line;
  hot_item_dict_.SwitchDict();

  return true;
}

}
}
