#include "reco/module/item_level/hot_level/general_hot.h"

#include <algorithm>
#include <vector>

#include "nlp/common/nlp_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/time/time.h"
#include "base/hash_function/term.h"
#include "base/common/sleep.h"

namespace reco {
namespace item_level {
DEFINE_double(search_score_thres, 0.5, "search 阈值控制");

const char* GeneralHotCalculator::kHotNewsScoreFile = "title_hot_score.txt";
const char* GeneralHotCalculator::kCategoryHotTuneFile = "category_hot_discount.txt";

GeneralHotCalculator::GeneralHotCalculator(const reco::NewsIndex* index) {
  news_index_ = index;
  search_util_ = new SearchUtil();
}

GeneralHotCalculator::~GeneralHotCalculator() {
  delete search_util_;
}


int GeneralHotCalculator::CalcHotScore(const ReqItemInfo& item_info) const {
  auto const hot_dict = hot_item_dict_.GetDict();
  auto hot_iter = hot_dict->find(item_info.item_id);
  if (hot_iter == hot_dict->end()) {
    return 0;
  }

  float hit_hot_score = hot_iter->second.first;
  if (hit_hot_score >= kManualHotScoreThres) {
    return kManualHotScoreThres;
  }

  const base::Time& item_t = item_info.publish_time;
  float time_discount = 1.0;
  base::Time curr_time = base::Time::Now();
  int news_hour_interval = (curr_time - item_t).InHours();
  if (news_hour_interval < kHotNewsExpireHours) {
    // float kTimeDiscountPower = 0.5;
    // if (item_info.category == reco::common::kSportCategory) kTimeDiscountPower = 0.8;
    // time_discount = (kHotNewsExpireHours - news_hour_interval) * 1.0 / kHotNewsExpireHours;
    // time_discount = std::pow(time_discount, kTimeDiscountPower);
  }

  float category_discount = 1;
  const std::unordered_map<std::string, float>* discount_dict = category_hot_tune_dict_.GetDict();
  auto discount_iter = discount_dict->find(item_info.category);
  if (discount_iter == discount_dict->end()) {
    LOG(WARNING) << "category not find, " << item_info.category;
  } else {
    category_discount = discount_iter->second;
  }
  for (int i = 0; i < (int)item_info.channels.size(); ++i) {
    auto iter = discount_dict->find(base::Uint64ToString(item_info.channels[i]));
    if (iter != discount_dict->end()) {
      category_discount = std::max(iter->second, category_discount);
    }
  }

  int hot_score = static_cast<int>(hit_hot_score * category_discount * time_discount);
  hot_score = TunnerBySim(item_info.item_id, hot_score);
  hot_score = NormalizeHotScore(hot_score);
  if (hot_score >= kManualHotScoreThres) {
    hot_score = kManualHotScoreThres - 1;
  }
  return hot_score;
}

int32 GeneralHotCalculator::TunnerBySim(uint64 item_id, int32 orgi_score) const {
  float weight = 1;
  const std::set<uint64>* sim_list = news_index_->GetSimItemIds(item_id);
  if (sim_list == NULL) {
    LOG(INFO) << "Get Sim Null, item id: " << item_id;
    weight = 1;
  } else {
    if (sim_list->size() >= 100) {
      weight = 1;
    } else {
      weight = float(std::sqrt(sim_list->size())) / 10.0;
    }
  }
  return int32(orgi_score * weight + 0.5);
}

int32 GeneralHotCalculator::NormalizeHotScore(int32 orgi_score) const {
  float b = 100, a = 30, c = 20;
  // 使用sigmoid做归一化   y = b / (1 + e^(-(x - a)/c))
  if (float(orgi_score) >= a) {
    return int32(b / (1 + exp(-(orgi_score - a)/ c)) + 0.5);
  } else {
    float xs = 50.0 / a;
    return int32(xs * orgi_score + 0.5);
  }
}

bool GeneralHotCalculator::ReloadDict(const base::FilePath& root_dir) {
  thread::AutoLock auto_lock(&mutex_);
  return (LoadHotNewsFile(root_dir)
          && LoadCategoryHotTuneFile(root_dir)
          && UpdateHotItemDict());
}

bool GeneralHotCalculator::LoadHotNewsFile(const base::FilePath& base_dir) {
  std::vector<std::string> lines;
  base::FilePath hot_info_file = base_dir.Append(kHotNewsScoreFile);
  CHECK(base::file_util::ReadFileToLines(hot_info_file, &lines)) << hot_info_file.ToString();

  auto hot_dict = hot_title_dict_.GetInactiveDict();
  hot_dict->swap(std::unordered_map<uint64, HotNewsInfo>());

  int is_manual = 0;
  int filter_num = 0;
  uint64 title_id = 0;
  base::Time now_t = base::Time::Now();
  std::string title;
  base::Time news_time;
  std::vector<std::string> flds;
  std::vector<std::string> level_flds, level_detail_flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    HotNewsInfo hot_info;
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 5u
        || !base::StringToUint64(flds[0], &title_id)
        || !base::Time::FromStringInSeconds(flds[1].c_str(), &news_time)
        || !base::StringToInt(flds[2], &is_manual)) {
      LOG(ERROR) << "parse title hot score error, line is: " << lines[i];
      ++filter_num;
      continue;
    }
    if ((now_t - news_time).InHours() > 24 * 3) {
      ++filter_num;
      continue;
    }
    if (hot_dict->find(title_id) != hot_dict->end()) {
      continue;
    }
    title = nlp::util::NormalizeLine(flds[4]);
    title_id = base::CalcTermSign(title.c_str(), title.size());
    level_flds.clear();
    base::SplitString(flds[5], ",", &level_flds);
    for (uint32 level_i = 0; level_i < level_flds.size(); ++level_i) {
      level_detail_flds.clear();
      base::SplitString(level_flds[level_i], ":", &level_detail_flds);
      if (level_detail_flds.size() < 2) continue;
      int32 seed_type, level;
      if (!base::StringToInt(level_detail_flds[0], &seed_type)
          || !base::StringToInt(level_detail_flds[1], &level)) continue;
      hot_info.hot_score.insert(std::make_pair(seed_type, level));
    }
    if (hot_info.hot_score.size() == 0) continue;
    hot_info.is_manual = is_manual > 0;
    hot_info.news_time = news_time;
    hot_info.title = title;
    hot_info.source = flds[3];
    hot_dict->insert(std::make_pair(title_id, hot_info));
  }

  LOG(INFO) << "hot title load succ, file size: " << lines.size()
            << ", dict size: " << hot_dict->size()
            << ", fiter hot news size: " << filter_num;

  hot_title_dict_.SwitchDict();

  return true;
}

bool GeneralHotCalculator::LoadCategoryHotTuneFile(const base::FilePath& base_dir) {
  std::vector<std::string> lines;
  base::FilePath discount_file = base_dir.Append(kCategoryHotTuneFile);
  CHECK(base::file_util::ReadFileToLines(discount_file, &lines)) << discount_file.ToString();

  auto discount_dict = category_hot_tune_dict_.GetInactiveDict();
  discount_dict->swap(std::unordered_map<std::string, float>());

  double score = 0;
  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u
        || !base::StringToDouble(flds[1], &score)) {
      LOG(ERROR) << "category_hot_tune_dict_file field error, line is: " << lines[i];
      continue;
    }
    const std::string& category = nlp::util::NormalizeLine(flds[0]);
    discount_dict->insert(std::make_pair(category, (float)score));
  }

  LOG(INFO) << "category hot discount dict load succ, file size: " << lines.size()
            << ", dict size: " << discount_dict->size();

  category_hot_tune_dict_.SwitchDict();

  return true;
}

int32 GeneralHotCalculator::CalHotScoreBaseSeedType(uint64 item_id, const HotNewsInfo& hot_info,
                                                    std::unordered_map<uint64,
                                                                      std::unordered_map<int32, int32>
                                                                     >* item_seed_type_dis) const {
  int32 score = 0;
  auto seed_iter = item_seed_type_dis->find(item_id);
  if (seed_iter == item_seed_type_dis->end()) {
    seed_iter = item_seed_type_dis->insert(std::make_pair(item_id,
                                                          std::unordered_map<int32, int32>())).first;
  }
  for (auto iter = hot_info.hot_score.begin(); iter != hot_info.hot_score.end(); ++iter) {
    if (iter->first == kVillageSite || iter->first == kStarSite) {
      continue;
    } else if (iter->first == kAuthoritativeSite
               || iter->first == kProvinceSite
               || iter->first == kHotNews) {
      score = 4 * iter->second;
    } else if (iter->first == kCitySite) {
      auto city_iter = seed_iter->second.find(kCitySite);
      if (city_iter == seed_iter->second.end()) {
        city_iter = seed_iter->second.insert(std::make_pair(kCitySite, 0)).first;
      }
      if (city_iter->second <= 5) {
        score = 2 * iter->second;
        city_iter->second += iter->second;
      }
    } else if (iter->first == kOther) {
      auto other_iter = seed_iter->second.find(kOther);
      if (other_iter == seed_iter->second.end()) {
        other_iter = seed_iter->second.insert(std::make_pair(kOther, 0)).first;
      }
      if (other_iter->second <= 5) {
        score = 1 * iter->second;
        other_iter->second += iter->second;
      }
    }
  }
  return score;
}


void GeneralHotCalculator::ExtractHotItems(
    const HotNewsInfo& hot_info, const searchserver::SearchResult& search_result,
    std::unordered_map<uint64, std::pair<float, std::string> >* hot_items,
    std::unordered_map<uint64, std::unordered_map<int32, int32> >* item_seed_type_dis) const {
  // 外边控制 clear
  // hot_items->clear();

  static const float kIdxDescRatio = 0.98;
  float pos_weight = 1.0;
  int32 doc_id = 0;
  for (int i = 0; i < search_result.doc_info_size(); ++i) {
    const searchserver::SearchDocInfo& search_info = search_result.doc_info(i);
    const std::string& search_title = search_info.title();
    float search_score = std::min(1.0f, search_info.rel_score());
    if (search_score < FLAGS_search_score_thres) {
      break;
    }
    // item 时间远落后于热门新闻时，需要过滤.
    uint64 item_id = search_info.item_id();
    if (!news_index_->GetDocIdByItemId(item_id, &doc_id)) continue;
    int64 item_timestamp = news_index_->GetCreateTimestampByItemId(item_id);
    const base::Time& item_time
        = base::Time::FromDoubleT(item_timestamp / base::Time::kMicrosecondsPerSecond);
    int hour_gap = std::abs((item_time - hot_info.news_time).InHours());
    if (hour_gap > 24) continue;
    // 计算分数
    float title_weight = 0;
    int32 score = CalHotScoreBaseSeedType(search_info.item_id(), hot_info, item_seed_type_dis);
    if (score <= 0) continue;
    if (hot_info.is_manual
        && search_score >= 0.8) {
      title_weight = 100;
    } else {
      title_weight = pos_weight * score * search_score;
    }
    auto item_iter = hot_items->find(search_info.item_id());
    if (item_iter == hot_items->end()) {
      (*hot_items)[item_id].first  = title_weight;
      (*hot_items)[item_id].second = search_title;
    } else {
      item_iter->second.first += title_weight;
    }
    pos_weight *= kIdxDescRatio;
  }
}

bool GeneralHotCalculator::UpdateHotItemDict() {
  auto const hot_news_dict = hot_title_dict_.GetDict();
  if (hot_news_dict->empty()) return true;

  auto hot_item_dict = hot_item_dict_.GetInactiveDict();
  hot_item_dict->clear();

  // search hot news title from search server to get hot item in index
  std::vector<std::string> query_list;
  query_list.reserve(hot_news_dict->size());
  for (auto iter = hot_news_dict->begin(); iter != hot_news_dict->end(); ++iter) {
    const HotNewsInfo& hot_news = iter->second;
    query_list.push_back(hot_news.title);
  }
  std::vector<searchserver::GeneralSearchResponse> responses;
  search_util_->BatchSearch(query_list, &responses);
  std::unordered_map<uint64, std::unordered_map<int32, int32> > item_seed_type_dis;
  // calc hot score
  // std::unordered_map<uint64, std::pair<float, std::string>> search_hot_items;
  for (int i = 0; i < (int)responses.size(); ++i) {
    const searchserver::GeneralSearchResponse& response = responses[i];
    if (!response.success() || response.result_size() == 0) continue;
    // search_hot_items.clear();
    for (int j = 0; j < response.result_size(); ++j) {
      const searchserver::SearchResult& search_result = response.result(j);
      uint64 query_title_id
          = base::CalcTermSign(search_result.query().c_str(), search_result.query().length());
      auto iter = hot_news_dict->find(query_title_id);
      CHECK(iter != hot_news_dict->end());
      const HotNewsInfo& hot_info = iter->second;
      // search_hot_items.clear();
      ExtractHotItems(hot_info, search_result, hot_item_dict, &item_seed_type_dis);
      // hot_item_dict->insert(search_hot_items.begin(), search_hot_items.end());
    }
  }

  LOG(INFO) << "succ to recalc item hot dict, item_hot_dict size:" << hot_item_dict->size();

  hot_item_dict_.SwitchDict();

  return true;
}
}
}
