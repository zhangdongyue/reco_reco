#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>

#include "base/time/time.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/module/item_level/base/base.h"

namespace reco {
namespace item_level {

class CityHotCalculator {
  public:
    CityHotCalculator() {}
    ~CityHotCalculator() {}

    int CalcHotScore(const ReqItemInfo& item_info) const;

    bool ReloadDict(const base::FilePath& root_dir);

  private:
    static const char* kCityHotItemFile;

    reco::DynamicDict<std::unordered_map<uint64, int>> hot_item_dict_;

    DISALLOW_COPY_AND_ASSIGN(CityHotCalculator);
};
}
}
