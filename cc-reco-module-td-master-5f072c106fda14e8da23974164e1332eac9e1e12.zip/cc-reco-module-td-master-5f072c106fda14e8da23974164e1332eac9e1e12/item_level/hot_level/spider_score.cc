#include "reco/module/item_level/hot_level/spider_score.h"

#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/common/logging.h"

namespace reco {
namespace item_level {

float SpiderScoreCalculator::CalcSpiderScore(const ReqItemInfo& item_info,
                                             const SpiderData& spider_data) const {
  if (item_info.item_type == reco::kPureVideo) {
    return CalcVideoSpiderScore(item_info, spider_data);
  }

  if (item_info.item_type == reco::kHumor) {
    return CalcHumorSpiderScore(item_info, spider_data);
  }

  return -1;
}

float SpiderScoreCalculator::CalcHumorSpiderScore(const ReqItemInfo& item_info,
                                                  const SpiderData& spider_data) const {
  float spider_score =
      spider_data.spider_comment_count * 3
      + spider_data.spider_up_count * 1.5
      + spider_data.spider_down_count * 0.3
      + spider_data.spider_read_count;
  return spider_score;
}

float SpiderScoreCalculator::CalcVideoSpiderScore(const ReqItemInfo& item_info,
                                                  const SpiderData& spider_data) const {
  base::TimeDelta time_delta = base::Time::Now() - item_info.publish_time;

  static const float kMaxVideoSpiderScore = 0.15;
  float spider_score = kMaxVideoSpiderScore;

  // 统计得出某个视频每天增长的播放数的中位数
  static const float kPlayCountPerDayMedian = 12;
  static const int kSecondsPerDay
      = base::Time::kMicrosecondsPerDay / base::Time::kMicrosecondsPerSecond;
  float play_count_per_day
      = 1.0 * spider_data.spider_play_count / (time_delta.InSecondsF() / kSecondsPerDay);
  if (play_count_per_day< kPlayCountPerDayMedian) {
    // 限制最多减权 0.05
    spider_score += 0.05 * (play_count_per_day / kPlayCountPerDayMedian - 1.0);
  }

  // 保留小数点 4 位
  spider_score = (static_cast<int>(spider_score * 10000)) / 10000.0;

  LOG(INFO) << "calc video spider score success [" << item_info.item_id
            << ", " << spider_score << "]"
            << ", time_delta:" << time_delta.InSeconds()
            << ", play_count:" << spider_data.spider_play_count;

  return spider_score;
}
}
}
