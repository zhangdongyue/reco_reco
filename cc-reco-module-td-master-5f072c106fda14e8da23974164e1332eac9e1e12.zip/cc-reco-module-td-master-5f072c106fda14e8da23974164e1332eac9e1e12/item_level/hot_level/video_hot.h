#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include "reco/module/item_level/base/search_util.h"
#include "reco/module/item_level/base/hdfs_util.h"
#include "reco/bizc/reco_index/news_index.h"
#include "base/time/time.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "base/thread/thread.h"

namespace reco {
namespace item_level {

class VideoHotCalculator {
 public:
  explicit VideoHotCalculator(const reco::NewsIndex* index);
  ~VideoHotCalculator();

  // 计算热度
  int CalcHotScore(const ReqItemInfo& item_info) const;

 private:
  // 通过 hot news 去搜索热门 video, 并更新到热门 video 词表
  void UpdateHotVideoDict();

 private:
  // 抽取的热门视频
  reco::DynamicDict<std::unordered_map<uint64, int> > hot_video_dict_;

  const reco::NewsIndex* news_index_;

  reco::kafka::Consumer* global_hot_video_consumer_;

  thread::Thread* update_thread_;

  // 结束更新线程
  bool stop_;
  DISALLOW_COPY_AND_ASSIGN(VideoHotCalculator);
};
}
}
