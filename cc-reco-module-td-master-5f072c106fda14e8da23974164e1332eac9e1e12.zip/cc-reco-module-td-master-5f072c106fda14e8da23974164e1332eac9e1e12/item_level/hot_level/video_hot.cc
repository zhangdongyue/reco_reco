#include "reco/module/item_level/hot_level/video_hot.h"
#include <unordered_set>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"
#include "reco/bizc/proto/hot_video.pb.h"

#include "nlp/common/nlp_util.h"
#include "serving_base/utility/timer.h"

namespace reco {
namespace item_level {
DEFINE_int32(global_hot_video_partition_num, 32, "");
DEFINE_string(global_hot_video_kafka_brokers, "", "必须外部指定");
DEFINE_string(global_hot_video_group, "global_hot_video_group", "group");
DEFINE_string(global_hot_video_topic_name, "global_hot_video", "topic name");

VideoHotCalculator::VideoHotCalculator(const reco::NewsIndex* index) {
  news_index_ = index;
  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_global_hot_video_topic_name;
  options.partition_num = FLAGS_global_hot_video_partition_num;
  options.type = reco::kafka::kConsumerExclusive;
  options.group_id = FLAGS_global_hot_video_group;
  global_hot_video_consumer_ = new reco::kafka::Consumer(FLAGS_global_hot_video_kafka_brokers, options);
  update_thread_ = new thread::Thread();
  update_thread_->Start(NewCallback(this, &VideoHotCalculator::UpdateHotVideoDict));
  stop_ = false;
}

VideoHotCalculator::~VideoHotCalculator() {
  stop_ = true;
  update_thread_->Join();
  delete update_thread_;
  delete global_hot_video_consumer_;
}

int VideoHotCalculator::CalcHotScore(const ReqItemInfo& item_info) const {
  auto const hot_dict = hot_video_dict_.GetDict();
  auto it = hot_dict->find(item_info.item_id);
  return it == hot_dict->end() ? 0 : it->second;
}

void VideoHotCalculator::UpdateHotVideoDict() {
  reco::kafka::Message msg;
  reco::HotVideoVector hot_video_vector;
  while (!stop_) {
    if (!global_hot_video_consumer_->Consume(&msg)) {
      base::SleepForMilliseconds(500);
      continue;
    }
    if (!hot_video_vector.ParseFromString(msg.content)) {
      LOG(WARNING) << "parse HotVideoVector fail" << msg.content;
      continue;
    }
    auto hot_videos = hot_video_dict_.GetInactiveDict();
    hot_videos->clear();
    for (int j = 0; j < hot_video_vector.hot_video_list_size(); ++j) {
      uint64 item_id = hot_video_vector.hot_video_list(j).item_id();
      int64 item_ts = news_index_->GetCreateTimestampByItemId(item_id);
      if (item_ts <= 0) continue;
      (*hot_videos)[item_id] = hot_video_vector.hot_video_list(j).hot_score();
      LOG(INFO) << hot_video_vector.timestamp() << " "
                << item_id << " "
                << hot_video_vector.hot_video_list(j).hot_score() << " " << (*hot_videos)[item_id];
    }
    LOG(INFO) << "calc video hot score success [" << ", " << hot_videos->size()  << "]";
    hot_video_dict_.SwitchDict();
  }
}
}
}
