#pragma once

#include <utility>
#include <string>
#include <unordered_map>

#include "reco/module/item_level/base/base.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/module/item_level/base/search_util.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "reco/module/item_level/base/define.h"

namespace reco {
namespace item_level {

struct HotNewsInfo {
  // 是否人工标注的热门
  bool is_manual;
  // 热门得分, 这里主要考虑命中几个热榜, 及命中的热榜的分数
  std::unordered_map<int32, int32> hot_score;
  // 热榜上新闻的时间
  base::Time news_time;
  // 热榜上新闻的 title
  std::string title;
  // 源
  std::string source;
  HotNewsInfo() {
    is_manual = false;
    hot_score.clear();
    title = "";
    source = "";
  }
};

// 通用的热门计算模块
//
class GeneralHotCalculator {
 public:
  explicit GeneralHotCalculator(const reco::NewsIndex* index);
  ~GeneralHotCalculator();

  // 计算
  int CalcHotScore(const ReqItemInfo& item_info) const;
  // 词典重载
  bool ReloadDict(const base::FilePath& root_dir);

 private:
  /////////////////// 词表相关
  // 热门新闻库
  bool LoadHotNewsFile(const base::FilePath& base_dir);
  // 分类别的打折系数
  bool LoadCategoryHotTuneFile(const base::FilePath& base_dir);
  // 通过 hot news 去搜索热门 item, 并更新到热门 item 词表
  bool UpdateHotItemDict();
  //
  void ExtractHotItems(const HotNewsInfo& hot_info, const searchserver::SearchResult& search_result,
                       std::unordered_map<uint64, std::pair<float, std::string> >* hot_items,
                       std::unordered_map<uint64, std::unordered_map<int32, int32> >* item_seed_type_dis) const;

  int32 CalHotScoreBaseSeedType(uint64 item_id, const HotNewsInfo& hot_info,
                                std::unordered_map<uint64, std::unordered_map<int32, int32> >* item_seed_type_dis) const;
  int32 NormalizeHotScore(int32 orgi_source) const;
  int32 TunnerBySim(uint64 item_id, int32 orgi_score) const;
 private:
  static const int   kHotNewsExpireHours = 24;
  static const char* kHotNewsScoreFile;
  static const char* kCategoryHotTuneFile;

  // 词表重载加锁
  thread::Mutex mutex_;
  // 索引
  const reco::NewsIndex* news_index_;

  // 热门新闻词表
  reco::DynamicDict<std::unordered_map<uint64, HotNewsInfo>> hot_title_dict_;
  // 热门新闻分类别打折系数词表
  reco::DynamicDict<std::unordered_map<std::string, float>> category_hot_tune_dict_;
  // 计算出来的热门 item 词表
  reco::DynamicDict<std::unordered_map<uint64, std::pair<float, std::string> > > hot_item_dict_;
  // 用于搜索热门文章
  SearchUtil* search_util_;

  DISALLOW_COPY_AND_ASSIGN(GeneralHotCalculator);
};

}  // namespace item_level
}  // namespace reco
