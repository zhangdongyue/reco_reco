#pragma once

#include <string>
#include "reco/module/item_level/base/base.h"
#include "base/common/base.h"

namespace reco {
namespace item_level {

class SpiderScoreCalculator {
 public:
  SpiderScoreCalculator() {}
  ~SpiderScoreCalculator() {}

  // 计算 spider score
  float CalcSpiderScore(const ReqItemInfo& item_info, const SpiderData& spider_data) const;

 private:
  float CalcHumorSpiderScore(const ReqItemInfo& item_info, const SpiderData& spider_data) const;
  float CalcVideoSpiderScore(const ReqItemInfo& item_info, const SpiderData& spider_data) const;

 private:
  DISALLOW_COPY_AND_ASSIGN(SpiderScoreCalculator);
};

}  // namespace item_level
}  // namespace reco
