#include "reco/module/item_level/hot_level/hot_calculator.h"

#include <algorithm>

#include "reco/module/item_level/hot_level/spider_score.h"
#include "reco/module/item_level/hot_level/general_hot.h"
#include "reco/module/item_level/hot_level/region_hot.h"
#include "reco/module/item_level/hot_level/video_hot.h"
#include "reco/module/item_level/hot_level/city_hot.h"

namespace reco {
namespace item_level {

DEFINE_bool(open_city_hot_switch, true, "是否开启城市热点文章score计算");

HotCalculator::HotCalculator(const reco::NewsIndex* index) {
  news_index_ = index;
  spider_score_calc_ = new SpiderScoreCalculator();
  video_hot_calc_ = new VideoHotCalculator(news_index_);
  region_hot_calc_ = new RegionHotCalculator(news_index_);
  general_hot_calc_ = new GeneralHotCalculator(news_index_);
  city_hot_calc_ = new CityHotCalculator();
}

HotCalculator::~HotCalculator() {
  delete spider_score_calc_;
  delete video_hot_calc_;
  delete region_hot_calc_;
  delete general_hot_calc_;
  delete city_hot_calc_;
}


int HotCalculator::CalcHotScore(const ReqItemInfo& item_info, bool is_new_item) const {
  int hot_score = 0;
  if (item_info.item_type == reco::kPureVideo) {
    hot_score = video_hot_calc_->CalcHotScore(item_info);
  } else if (item_info.item_type == reco::kHumor) {
    hot_score = 0;
  } else {
    bool local_channel = false;
    for (size_t i = 0; i < item_info.channels.size(); ++i) {
      if (item_info.channels[i] == reco::common::kLocalChannelId) {
        local_channel = true;
        break;
      }
    }
    if (local_channel) {
      if (FLAGS_open_city_hot_switch) {
        hot_score = city_hot_calc_->CalcHotScore(item_info);
      } else {
        hot_score = region_hot_calc_->CalcHotScore(item_info);
        if (hot_score < 1e-6 && is_new_item) {
          hot_score = region_hot_calc_->CalcEmergencyScore(item_info);
        }
      }
    } else {
      hot_score = general_hot_calc_->CalcHotScore(item_info);
    }
  }

  return std::min(hot_score, kManualHotScoreThres);
}

float HotCalculator::CalcSpiderScore(const ReqItemInfo& item_info,
                                     const SpiderData& spider_data) const {
  return spider_score_calc_->CalcSpiderScore(item_info, spider_data);
}

bool HotCalculator::ReloadDict(const base::FilePath& root_dir) {
  return (general_hot_calc_->ReloadDict(root_dir)
          && region_hot_calc_->ReloadDict()
          && city_hot_calc_->ReloadDict(root_dir));
}
}
}

