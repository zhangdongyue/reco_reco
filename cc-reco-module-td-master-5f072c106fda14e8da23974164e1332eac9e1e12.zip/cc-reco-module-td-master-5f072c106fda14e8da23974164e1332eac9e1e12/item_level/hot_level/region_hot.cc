#include "reco/module/item_level/hot_level/region_hot.h"
#include <algorithm>
#include "base/hdfs/hdfs_file_util.h"
#include "base/hdfs/hdfs_file_stream.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"
#include "base/hash_function/term.h"

#include "nlp/common/nlp_util.h"
#include "net/rpc_util/rpc_group.h"
#include "serving_base/utility/timer.h"

namespace hadoop {
DECLARE_string(hadoop_namenode_ip);
DECLARE_int32(hadoop_namenode_port);
}

namespace reco {
namespace item_level {

DEFINE_string(region_hot_title_hdfs_path, "/user/serving/zhuzekun/local_hot_title", "");
DEFINE_double(region_search_score_thres, 0.55, "");
DECLARE_string(item_level_data_dir);

const char *RegionHotCalculator::kEmergencyKeywordDictName = "emergency_keywords.txt";
const std::unordered_set<std::string> RegionHotCalculator::kEmergencyCategories = {"社会", "国内"};
std::unordered_map<std::string, std::string> RegionHotCalculator::BuildCityNameMap() {
  std::unordered_map<std::string, std::string> cmap;
  cmap["北京"] = "010";
  cmap["上海"] = "021";
  cmap["广州"] = "020";
  cmap["深圳"] = "0755";
  cmap["杭州"] = "0571";
  return cmap;
}
const std::unordered_map<std::string, std::string> RegionHotCalculator::kCityNameMap =
  BuildCityNameMap();

RegionHotCalculator::RegionHotCalculator(const reco::NewsIndex* index) : news_index_(index) {
  search_util_ = new SearchUtil();
  matcher_ = new extend::MultiPatternMatcher();
  LoadEmergencyKeywords(FLAGS_item_level_data_dir + "/" + kEmergencyKeywordDictName);
}

RegionHotCalculator::~RegionHotCalculator() {
  delete search_util_;
  delete matcher_;
}

bool RegionHotCalculator::LoadEmergencyKeywords(const std::string &path) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read emergency keyword file fail: " << path;
    return false;
  }
  for (size_t i = 0; i < lines.size(); ++i) {
    base::TrimWhitespaces(&lines[i]);
    if (lines[i].empty() || lines[i][0] == '#') continue;
    if (!matcher_->AddPattern(lines[i].c_str())) {
      LOG(WARNING) << "add pattern fail: " << lines[i];
      continue;
    }
  }
  if (!matcher_->Build()) {
    LOG(ERROR) << "multi-pattern matcher build fail";
    return false;
  }
  LOG(INFO) << "load emergency keyword dict success: " << path;
  return true;
}

int RegionHotCalculator::CalcHotScore(const ReqItemInfo& item_info) const {
  auto const hot_dict = hot_item_dict_.GetDict();
  auto it = hot_dict->find(item_info.item_id);
  return it == hot_dict->end() ? 0 : it->second;
}

int RegionHotCalculator::CalcEmergencyScore(const ReqItemInfo& item_info) const {
  if (kEmergencyCategories.find(item_info.category) == kEmergencyCategories.end()) {
    return 0;
  }
  const std::string& title = base::JoinStrings(item_info.title_unigrams, "");
  extend::MatchResult result;
  if (matcher_->Match(title.c_str(), title.length(), &result)) {
    VLOG(1) << "match emergency keyword: " << item_info.item_id << ", " << title;
    return kMidHotScoreThres;
  }
  return 0;
}

bool RegionHotCalculator::ReloadDict() {
  LOG(INFO) << "reload hot region dict start";
  std::string lastest_path;
  if (!HdfsUtil::GetHdfsLastestPath(FLAGS_region_hot_title_hdfs_path, &lastest_path)) return false;
  if (lastest_path == lastest_hot_title_hdfs_path_) {
    LOG(INFO) << "no hot region file updated.";
    return true;
  }
  LOG(INFO) << "get new region hot file: " << lastest_path;

  // load city hot title from hdfs
  if (!ReadCityHotTitles(lastest_path + "/parsed_local.txt")) {
    return false;
  }

  // calc hot items
  if (!UpdateHotItemDict()) {
    return false;
  }

  lastest_hot_title_hdfs_path_ = lastest_path;
  LOG(INFO) << "reload hot region dict success: " << hot_item_dict_.GetDict()->size();
  return true;
}

bool RegionHotCalculator::UpdateHotItemDict() {
  std::vector<std::string> query_list;
  for (auto iter = hot_title_dict_.begin(); iter != hot_title_dict_.end(); ++iter) {
    query_list.push_back(iter->second.title);
  }

  if (query_list.empty()) return true;

  std::vector<searchserver::GeneralSearchResponse> responses;
  search_util_->BatchSearch(query_list, &responses);

  auto hot_items = hot_item_dict_.GetInactiveDict();
  hot_items->clear();

  int32 doc_id = 0;
  std::vector<std::string> tokens;
  for (int i = 0; i < (int)responses.size(); ++i) {
    const searchserver::GeneralSearchResponse& response = responses[i];
    if (!response.success() || response.result_size() == 0) continue;
    for (int j = 0; j < response.result_size(); ++j) {
      const searchserver::SearchResult& result = response.result(j);
      const std::string& query_title = result.query();
      uint64 query_title_id = base::CalcTermSign(query_title.c_str(), query_title.length());
      auto iter = hot_title_dict_.find(query_title_id);
      CHECK(iter != hot_title_dict_.end());

      const RegionNewsInfo& hot_info = iter->second;
      for (int k = 0; k < result.doc_info_size(); ++k) {
        const searchserver::SearchDocInfo& search_info = result.doc_info(k);
        float search_score = std::min(1.0f, search_info.rel_score());
        if (search_score < FLAGS_region_search_score_thres) {
          break;
        }

        // item 时间远落后于热门新闻时，需要过滤.
        uint64 item_id = search_info.item_id();
        if (!news_index_->GetDocIdByItemId(item_id, &doc_id)) continue;
        int64 item_timestamp = news_index_->GetCreateTimestampByItemId(item_id);
        base::Time item_time = base::Time::FromDoubleT(item_timestamp / base::Time::kMicrosecondsPerSecond);
        int hour_gap = std::abs((item_time - hot_info.news_time).InHours());
        if (hour_gap > kLastNHours) continue;

        // 地域是否匹配
        std::vector<int64> region_ids;
        if (!news_index_->GetRegionIdByDocId(doc_id, &region_ids)
            || region_ids.empty()) {
          continue;
        }
        bool matched = false;
        for (int i = 0; i < (int)region_ids.size(); ++i) {
          const std::string& region_id = base::Int64ToString(region_ids[i]);
          if (region_id == hot_info.city_id) {
            matched = true;
            break;
          }
        }
        if (!matched) continue;

        // 计算分数
        double hot_score = std::log((double)hot_info.comment_num / 1000.0 + 1.05) / std::log(2.0);
        hot_score *= std::log(1 + hot_info.sources.size()) / std::log(2.0);
        hot_score *= kManualHotScoreThres;

        auto it = hot_items->find(item_id);
        if (it != hot_items->end()) {
          it->second = std::max(it->second, hot_score);
        } else {
          hot_items->insert(std::make_pair(item_id, hot_score));
        }

        VLOG(1) << "local hot item: " << item_id << ", "
                << hot_info.city_id << ", " << hot_score << ", " << hot_info.title;
      }
    }
  }

  LOG(INFO) << "calc region hot score success [" << ", " << hot_items->size()  << "]";

  hot_item_dict_.SwitchDict();

  return true;
}

bool RegionHotCalculator::ReadCityHotTitles(const std::string &hdfs_path) {
  hot_title_dict_.clear();
  std::vector<std::string> lines;
  if (!HdfsUtil::ReadHdfsFile(hdfs_path, &lines)) {
    LOG(ERROR) << "read hdfs file fail [" << hdfs_path << "]";
    return false;
  }
  if (lines.empty()) {
    LOG(INFO) << "read hdfs file empty [" << hdfs_path << "]";
    return true;
  }

  base::Time expire_time = base::Time::Now() - base::TimeDelta::FromHours(kLastNHours);
  int comment, share, favorite;
  std::vector<std::string> tokens;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    tokens.clear();
    base::SplitString(lines[idx], "\t", &tokens);
    if (tokens.size() < 7) {
      LOG(WARNING) << "region hot file field error: " << lines[idx];
      continue;
    }
    auto &source = tokens[0];
    auto &city = tokens[1];
    auto &title = tokens[2];
    auto &time = tokens[3];
    if (!base::StringToInt(tokens[4], &comment) ||
        !base::StringToInt(tokens[5], &share) ||
        !base::StringToInt(tokens[6], &favorite)) {
      LOG(WARNING) << "region hot file format error: " << lines[idx];
      continue;
    }
    auto city_iter = kCityNameMap.find(city);
    if (city_iter == kCityNameMap.end()) {
      LOG(WARNING) << "city not found: " << city;
      continue;
    }

    const std::string& nor_title = nlp::util::NormalizeLine(title);
    uint64 title_sign = base::CalcTermSign(nor_title.c_str(), nor_title.length());
    RegionNewsInfo info;
    info.sources.insert(source);
    info.title = nor_title;
    info.comment_num = comment;
    info.share_num = share;
    info.favorite_num = favorite;
    info.city_id = city_iter->second;
    if (!base::Time::FromStringInFormat(time.c_str(), "%Y-%m-%d %H:%M:%S", &info.news_time)) {
      LOG(WARNING) << "time format error: " << time;
      continue;
    }
    if (info.news_time < expire_time) {
      continue;
    }

    auto dict_iter = hot_title_dict_.find(title_sign);
    if (dict_iter == hot_title_dict_.end()) {
      hot_title_dict_.insert(std::make_pair(title_sign, info));
    } else {
      dict_iter->second.Add(info);
    }
  }
  LOG(INFO) << "read city hot data success: " << hot_title_dict_.size();
  return true;
}
}
}
