#pragma once

#include <string>

#include "reco/module/item_level/base/base.h"
#include "reco/bizc/reco_index/news_index.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/base.h"

namespace reco {
namespace item_level {

class SpiderScoreCalculator;
class RegionHotCalculator;
class VideoHotCalculator;
class GeneralHotCalculator;
class CityHotCalculator;

class HotCalculator {
 public:
  explicit HotCalculator(const reco::NewsIndex* index);
  ~HotCalculator();

  // 计算热门分数
  int CalcHotScore(const ReqItemInfo& item_info, bool is_new_item = false) const;

  // 计算 spider score
  float CalcSpiderScore(const ReqItemInfo& item_info, const SpiderData& spider_data) const;

  // 重载词典
  bool ReloadDict(const base::FilePath& root_dir);

 private:
  SpiderScoreCalculator* spider_score_calc_;
  GeneralHotCalculator* general_hot_calc_;
  RegionHotCalculator* region_hot_calc_;
  VideoHotCalculator* video_hot_calc_;
  CityHotCalculator* city_hot_calc_;

  // 索引
  const reco::NewsIndex* news_index_;

  DISALLOW_COPY_AND_ASSIGN(HotCalculator);
};

}  // namespace item_level
}  // namespace reco
