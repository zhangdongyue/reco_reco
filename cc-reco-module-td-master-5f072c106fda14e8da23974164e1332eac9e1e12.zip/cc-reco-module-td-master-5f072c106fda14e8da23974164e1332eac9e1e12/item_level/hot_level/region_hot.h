#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>

#include "base/time/time.h"
#include "extend/multi_strings/multi_pattern_matcher.h"
#include "reco/module/item_level/base/search_util.h"
#include "reco/module/item_level/base/hdfs_util.h"
#include "reco/bizc/reco_index/news_index.h"

namespace reco {
namespace item_level {

class RegionHotCalculator {
 public:
  explicit RegionHotCalculator(const reco::NewsIndex* index);
  ~RegionHotCalculator();

  // 计算热度
  int CalcHotScore(const ReqItemInfo& item_info) const;
  // 词典重载, 直接从 hadoop 上读取，因此不需要传入路径
  bool ReloadDict();
  // 计算突发事件的分数
  int CalcEmergencyScore(const ReqItemInfo& item_info) const;

 private:
  struct RegionNewsInfo {
    void Add(const RegionNewsInfo &info) {
      comment_num += info.comment_num;
      share_num += info.share_num;
      favorite_num += info.favorite_num;
      sources.insert(info.sources.begin(), info.sources.end());
    }
    std::string title;
    base::Time news_time;
    std::string city_id;
    int comment_num;
    int share_num;
    int favorite_num;
    std::unordered_set<std::string> sources;
  };

 private:
  bool ReadCityHotTitles(const std::string& hdfs_path);

  bool UpdateHotItemDict();

  bool LoadEmergencyKeywords(const std::string &path);

 private:
  static const std::unordered_map<std::string, std::string> kCityNameMap;
  static std::unordered_map<std::string, std::string> BuildCityNameMap();

  static const int kLastNHours = 48;
  static const std::unordered_set<std::string> kEmergencyCategories;
  static const char *kEmergencyKeywordDictName;

 private:
  reco::DynamicDict<std::unordered_map<uint64, double> > hot_item_dict_;
  std::unordered_map<uint64, RegionNewsInfo> hot_title_dict_;

  // 用于搜索热门文章
  SearchUtil* search_util_;

  extend::MultiPatternMatcher *matcher_;

  const reco::NewsIndex* news_index_;
  std::string lastest_hot_title_hdfs_path_;

  DISALLOW_COPY_AND_ASSIGN(RegionHotCalculator);
};
}
}
