#include "reco/module/item_level/item_relative/item_relative_calculator.h"
#include <vector>
namespace reco {
namespace item_level {

DEFINE_string(wd_item_model_name, "item_cate_relative", "");
DEFINE_int32(modelserver_thread_num, 10, "modelserver thread");

const int KModelBatchSize = 500;

ItemRelativeCalculator::ItemRelativeCalculator() {
}

ItemRelativeCalculator::~ItemRelativeCalculator() {
}

bool ItemRelativeCalculator::NeedPredict(const ItemLevelInfo& level_info) {
  if (level_info.predict_ctr == ItemLevelInfo::kDftVal) {
    return true;
  } else {
    return false;
  }
}

void ItemRelativeCalculator::SetItemFea(const std::string& key, const std::string& value,
                                        reco::model_server::Features* features) {
  reco::model_server::FeatureInfo* feature = features->add_feature_info();
  feature->set_literal(key);
  feature->set_text(value);

  return;
}

int ItemRelativeCalculator::ExtractItemFea(const ReqItemInfo& item_info, const DynamicInfo& ctr,
                                           reco::model_server::OneRequest* one_request) {
  reco::model_server::WideDeepRequest* wide_deep_request = one_request->add_wide_deep_requests();
  wide_deep_request->mutable_model_info()->set_model_name(FLAGS_wd_item_model_name);
  wide_deep_request->set_sid(1);

  reco::model_server::Features* features = wide_deep_request->add_request_items();
  // title
  SetItemFea("title", item_info.title, features);
  // bititle
  SetItemFea("bititle", item_info.bititle, features);
  // source
  SetItemFea("source", item_info.source_media, features);
  // channelid: 暂时只预测结果在推荐频道时的 ctr
  SetItemFea("channelid", "100", features);
  // tags
  SetItemFea("item_tag", item_info.tags, features);
  // categories
  SetItemFea("item_category", item_info.categories, features);
  // time
  SetItemFea("time", base::IntToString(ctr.time), features);
  // ctr
  SetItemFea("ctr", base::IntToString(ctr.wilson_ctr), features);

  return 1;
}

bool ItemRelativeCalculator::CalcItemRelative(std::vector<ReqItemInfo>& item_request,
                                              std::vector<DynamicInfo>& ctr_info,
                                              std::vector<ItemLevelInfo>& level_results) {
  thread::ThreadPool pool(FLAGS_modelserver_thread_num);
  for (int i = 0; i < FLAGS_modelserver_thread_num; ++i) {
    pool.AddTask(NewCallback<ItemRelativeCalculator, int, int32,
                 std::vector<ReqItemInfo>&, std::vector<DynamicInfo>&,
                 std::vector<ItemLevelInfo>&> (this,
                 &ItemRelativeCalculator::CalcItemRelativeThread,
                 i, FLAGS_modelserver_thread_num,
                 item_request, ctr_info, level_results));
  }
  pool.JoinAll();

  return true;
}

void ItemRelativeCalculator::CalcItemRelativeThread(int thread_id, int32 thread_num,
                                                    std::vector<ReqItemInfo>& item_request,
                                                    std::vector<DynamicInfo>& ctr_info,
                                                    std::vector<ItemLevelInfo>& level_results) {
  int thread_count = level_results.size() / thread_num + 1;
  unsigned thread_begin = thread_id * thread_count;
  unsigned thread_end = (thread_id + 1) * thread_count;
  if (thread_end > level_results.size()) {
    thread_end = level_results.size();
  }
  CalcItemRelativePart(item_request, ctr_info, level_results, thread_begin, thread_end);
  LOG(INFO) << "thread id: " << thread_id << " start index: " << thread_begin
            << " end index: " << thread_end;
  return;
}

bool ItemRelativeCalculator::CalcItemRelativePart(std::vector<ReqItemInfo>& item_request,
                                                  std::vector<DynamicInfo>& ctr_info,
                                                  std::vector<ItemLevelInfo>& level_results,
                                                  unsigned head, unsigned tail) {
  int size = tail - head + 1;
  int loop_num = size / KModelBatchSize + 1;
  for (int i = 0; i < loop_num; ++i) {
    unsigned begin = head + i * KModelBatchSize;
    unsigned end = head + (i + 1) * KModelBatchSize;

    if (begin >= tail) {
      break;
    }
    if (end > tail) {
      end = tail;
    }
    int64 begin_ts = base::GetTimestamp();
    CalcItemRelativeLoop(item_request, ctr_info, level_results, begin, end);
    int64 end_ts = base::GetTimestamp();
    VLOG(2) << "part start: " << begin << " end: "
            << end << " cost time: " << end_ts - begin_ts;
  }
  return true;
}

bool ItemRelativeCalculator::CalcItemRelativeLoop(std::vector<ReqItemInfo>& item_request,
                                              std::vector<DynamicInfo>& ctr_info,
                                              std::vector<ItemLevelInfo>& level_results,
                                              unsigned begin, unsigned end) {
  reco::model_server::PackagedRequest packaged_request;
  packaged_request.set_sid(1);
  reco::model_server::OneRequest* one_request = packaged_request.add_request_items();
  one_request->set_user_id(1);

  reco::model_server::WideDeepRequest* wide_deep_request = NULL;

  int count = 0;
  for (unsigned i = begin; i < end; ++i) {
    const ReqItemInfo& item_info = item_request[i];
    const DynamicInfo& ctr = ctr_info[i];
    const ItemLevelInfo& level_info = level_results[i];
    if (!NeedPredict(level_info)) {
      continue;
    }
    // 抽取特征
    count += ExtractItemFea(item_info, ctr, one_request);
  }

  // 预测
  reco::model_server::PackagedResponse response;
  if (!reco::model_server::ModelServerAPIIns::instance().PackagedSearch(packaged_request, &response) ||
      response.responses_items_size() < 1) {
    LOG(ERROR) << "request_items_size:" << count
               << " responses_items_size:" << response.responses_items_size();
    return false;
  }

  const reco::model_server::OneResponse &one_response = response.responses_items(0);
  if (count != one_response.wide_deep_responses_size()) {
    LOG(ERROR) << "size diff!!" << " request size:"
        << one_request->wide_deep_requests_size() << " responses size:"
        << one_response.wide_deep_responses_size();
    return false;
  }

  // 赋值
  for (unsigned i = begin, j = 0; i < end; ++i) {
    if (!NeedPredict(level_results[i])) {
      continue;
    }
    const reco::model_server::WideDeepResponse &wd_response = one_response.wide_deep_responses(j);
    wide_deep_request = one_request->mutable_wide_deep_requests(j);
    j += 1;
    if (wd_response.response_items_size() < 1) {
      LOG(ERROR) << "wd response has no response_items,code:" << wd_response.code();
      continue;
    }
    int predict_ctr = int(wd_response.response_items(0).q() * 1000);

    level_results[i].predict_ctr = predict_ctr;
  }

  return true;
}

}
}
