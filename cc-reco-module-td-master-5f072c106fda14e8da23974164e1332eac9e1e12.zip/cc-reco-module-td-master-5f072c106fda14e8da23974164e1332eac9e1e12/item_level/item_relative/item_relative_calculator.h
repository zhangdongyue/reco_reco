#pragma once

#include <string>
#include <unordered_map>
#include <unordered_set>
#include "reco/module/item_level/base/base.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/proto/model_service.pb.h"
#include "reco/ml/model_server/api/model_server_api.h"


namespace reco {
namespace item_level {

// 预测 item 到类别的相关性
class ItemRelativeCalculator {
 public:
  ItemRelativeCalculator();
  ~ItemRelativeCalculator();

  bool CalcItemRelative(std::vector<ReqItemInfo>& item_request,
                        std::vector<DynamicInfo>& ctr_info,
                        std::vector<ItemLevelInfo>& level_results);

 private:
  void CalcItemRelativeThread(int thread_id, int32 thread_num,
                              std::vector<ReqItemInfo>& item_request,
                              std::vector<DynamicInfo>& ctr_info,
                              std::vector<ItemLevelInfo>& level_results);

  bool CalcItemRelativePart(std::vector<ReqItemInfo>& item_request,
                            std::vector<DynamicInfo>& ctr_info,
                            std::vector<ItemLevelInfo>& level_results,
                            unsigned head, unsigned tail);

  bool CalcItemRelativeLoop(std::vector<ReqItemInfo>& item_request,
                            std::vector<DynamicInfo>& ctr_info,
                            std::vector<ItemLevelInfo>& level_results,
                            unsigned begin, unsigned end);

  bool NeedPredict(const ItemLevelInfo& level_info);

  int ExtractItemFea(const ReqItemInfo& item_info, const DynamicInfo& ctr,
                     reco::model_server::OneRequest* one_request);

  void SetItemFea(const std::string& key, const std::string& value,
                                        reco::model_server::Features* features);

  DISALLOW_COPY_AND_ASSIGN(ItemRelativeCalculator);
};

}  // namespace item_level
}  // namespace reco
