#pragma once
#include "base/common/base.h"
#include "base/strings/string_util.h"

#include "serving_base/data_manager/data_manager.h"
#include "serving_base/mysql_util/db_conn_manager.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/cppconn/resultset.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/statement.h"

#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/item_service/hbase_pool_get_sim.h"

#include "reco/module/item_level/base/base.h"
namespace reco {
namespace item_level { 
enum DbInsertStatus {
  kItemExpire = -1,
  kInsertItemFail = 0,
  kNoUpdateInfo = 1,
  kInsertItemSuccess = 2,
};

// 应用于热点写入 mysql
class HotDbOp {
 public:
  HotDbOp(const reco::NewsIndex* news_index);
  ~HotDbOp();

  // 批量写入热点数据到 db
  void BatchWriteHotItem(const std::vector<ItemLevelInfo>& item_level_vec);

 private:
  int32 InsertHotItem(const HotItemInDataBase& level_info);
  bool Convert(const ItemLevelInfo& hot_item, HotItemInDataBase* db_item);
  std::string FormatStringForDB(const std::string& string);

 private:
  const reco::NewsIndex* news_index_;
  serving_base::mysql_util::DbConnManager* db_manager_;
  serving_base::ExpiryMap<uint64, HotItemInDataBase>* hot_item_cache_;
  reco::HBasePoolGetSim* get_sim_;
  std::unordered_map<uint64, ItemLevelInfo> hot_item_map_;
};

} // namespace reco
} // namespace item_level
