#include "reco/module/item_level/db_util/hot_db_op.h"
#include "reco/module/item_level/db_util/db_config.h"

namespace reco {
namespace item_level {
DECLARE_string(db_host);
DECLARE_string(db_user);
DECLARE_string(db_passwd);
DECLARE_string(schema);

DEFINE_string(sim_hbase_table, "tb_sim_item", "sim table");

DEFINE_int32(hot_item_cache_seconds, 3600, "热门item的cache");
DEFINE_int32(hot_level_threshold, 20, "热门分数阈值");
DEFINE_int32(hot_item_expire_hour, 24, "计算多少小时以内的item");
DEFINE_int32(cache_expire_time, 0, "缓存大小");

HotDbOp::HotDbOp(const reco::NewsIndex* news_index) {
  news_index_ = news_index;
  hot_item_cache_ = new serving_base::ExpiryMap<uint64, HotItemInDataBase>(FLAGS_hot_item_cache_seconds);
  // 没有设置 db host，表示不写数据库
  db_manager_ = NULL;
  if (!FLAGS_db_host.empty()) {
    serving_base::mysql_util::DbConnManager::Option db_option;
    db_option.host = FLAGS_db_host;
    db_option.user = FLAGS_db_user;
    db_option.passwd = FLAGS_db_passwd;
    db_option.schema = FLAGS_schema;
    db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
    CHECK_NOTNULL(db_manager_);
    db_manager_->ConnectUntilSuccess();
    LOG(INFO) << "succ to connect to db, " << FLAGS_db_host;
    get_sim_ = new reco::HBasePoolGetSim(FLAGS_sim_hbase_table);
  } else {
    LOG(WARNING) << "skip to connect to db.";
  }
}

HotDbOp::~HotDbOp() {
  delete hot_item_cache_;
  if (get_sim_ != NULL) {
    delete get_sim_;
  }
  if (db_manager_ != NULL) {
    delete db_manager_;
  }
}

void HotDbOp::BatchWriteHotItem(const std::vector<ItemLevelInfo>& item_level_vec) {
  if (db_manager_ == NULL) return;

  for (size_t i = 0; i < item_level_vec.size(); ++i) {
    if (item_level_vec[i].hot_level >= FLAGS_hot_level_threshold) {
      hot_item_map_.insert(std::make_pair(item_level_vec[i].item_id, item_level_vec[i]));
    }
  }
  int32 succ_num = 0;
  int32 fail_num = 0;
  int32 no_update = 0;
  int32 item_expire_num = 0;
  int32 convert_fail = 0;
  HotItemInDataBase db_item;
  for (auto iter = hot_item_map_.begin(); iter != hot_item_map_.end(); ++iter) {
    if (!Convert(iter->second, &db_item)) {
      ++convert_fail;
      continue;
    }
    int status = InsertHotItem(db_item);
    if (status == kInsertItemSuccess) {
      ++succ_num;
    } else if(status == kNoUpdateInfo) {
      ++no_update;
    } else if (status == kInsertItemFail) {
      ++fail_num;
    } else if (status == kItemExpire) {
      ++item_expire_num;
    }
  }
  LOG(INFO) << "Hot Item Insert database info: [total num]: " << hot_item_map_.size() << "\t"
            << "[success num]: " << succ_num << "\t" 
            << "[convert fail num]: " << convert_fail << "\t" 
            << "[no update num]: " << no_update << "\t"
            << "[fail num]: " << fail_num << "\t"
            << "[item expire num]: " << item_expire_num;
}

std::string HotDbOp::FormatStringForDB(const std::string& str) {
  std::string res;
  res = base::StringReplace(str, "\\", "\\\\", true);
  res = base::StringReplace(res, "\"", "\\\"", true);
  res = base::StringReplace(res, "'", "\\'", true);
  res = base::StringReplace(res, "%", "\\%", true);
  res = base::StringReplace(res, "_", "\\_", true);
  return res;
}

bool HotDbOp::Convert(const ItemLevelInfo& level_info, HotItemInDataBase* db_item) {
  // item_id
  db_item->item_id = level_info.item_id;
  // 获取doc_id
  int32 doc_id;
  if (!news_index_->GetDocIdByItemId(db_item->item_id, &doc_id)) {
    LOG(ERROR) << "Get Doc Id Fail, item id: " << level_info.item_id;
    return false;
  }
  // 获取最后修改时间 和 统计的hour
  base::Time time_now = base::Time::FromDoubleT(double(base::GetTimestamp()) / 1e6);
  time_now.ToStringInSeconds(&db_item->last_modify_time);
  if (!time_now.ToStringInFormat("%Y-%m-%d %H", &db_item->stat_hour)) {
    LOG(ERROR) << "Format Time To Stat Hour Fail, the timestamp is: " << base::GetTimestamp();
    return false;
  }
  if (!time_now.ToStringInFormat("%Y-%m-%d", &db_item->last_modify_day)) {
    LOG(ERROR) << "Format Time To last_modify Day Fail, the timestamp is: " << base::GetTimestamp();
    return false;
  }
  // 获取发布时间
  int64 publist_time = news_index_->GetCreateTimestampByItemId(level_info.item_id);
  base::Time time_publish = base::Time::FromDoubleT(double(publist_time) / 1e6);
  // 只取24小时以内
  if ((time_now - time_publish).InHours() > FLAGS_hot_item_expire_hour) return kItemExpire;
  time_publish.ToStringInSeconds(&db_item->publish_time);
  // 获取item info
  reco::ItemInfo item_info;
  if (!news_index_->GetItemInfoByItemId(level_info.item_id, &item_info, false)) {
    LOG(ERROR) << "Get Item Info Fail, item id: " << level_info.item_id;
    return false;
  }
  // 获取类别
  db_item->category = item_info.category;
  db_item->snd_category = item_info.sub_category;
  // 获取item type
  db_item->item_type = item_info.item_type;
  // 热度分
  db_item->hot_level = level_info.hot_level;
  // 获取标题
  if (!news_index_->GetItemTitleByItemId(level_info.item_id, &db_item->title)) {
    LOG(ERROR) << "Get Title Fail, item id: " << level_info.item_id;
    return false;
  }
  db_item->title = FormatStringForDB(db_item->title);
  // 获取源
  if (!news_index_->GetSourceByItemId(level_info.item_id, &db_item->source)) {
    db_item->source = "";
    LOG(ERROR) << "Get Source Fail, item id: " << level_info.item_id;
  }
  db_item->source = base::StringReplace(db_item->source, "\"", "\\\"", true);
  // 获取producer
  if (!news_index_->GetProducerByDocId(doc_id, &db_item->producer)) {
    db_item->producer = "";
    LOG(ERROR) << "Get Producer Fail, item id: " << level_info.item_id;
  }
  db_item->producer = FormatStringForDB(db_item->producer);
  // 获取sim
  db_item->represent_item_id = level_info.item_id;
  std::vector<uint64> sim_items;
  db_item->sim_item_count = 0;
  if (get_sim_->GetSimItem(level_info.item_id, &sim_items)) {
    db_item->sim_item_count = sim_items.size();
    int32 max_hot_level = db_item->hot_level;
    uint64 min_item_id = db_item->item_id;
    for (size_t i = 0; i < sim_items.size(); ++i) {
      uint64 sim_id = sim_items.at(i);
      auto iter = hot_item_map_.find(sim_id);
      if (iter == hot_item_map_.end()) continue;
      if (iter->second.hot_level > max_hot_level
          || (iter->second.hot_level == max_hot_level && sim_id < min_item_id)) {
        max_hot_level = iter->second.hot_level;
        min_item_id = sim_id;
        db_item->represent_item_id = sim_id;
      }
    }
  }
  return true;
}

int32 HotDbOp::InsertHotItem(const HotItemInDataBase& hot_item) {
  // 查看缓存数据 看看是否需要插入或者更新
  HotItemInDataBase cache_data;
  uint64 item_id = hot_item.item_id;
  if (hot_item_cache_->FindSilently(item_id, &cache_data) && cache_data == hot_item) {
    return kNoUpdateInfo;
  }
  std::string sql_insert_stat_hour =
      base::StringPrintf("INSERT INTO tb_xss_hot_item \
                         (item_id, stat_hour, item_type, \
                          producer, category, snd_category, \
                          title, source, publish_time, \
                          hot_score, sim_item_count, represent_item_id, last_modify_time) \
                         VALUES \
                         (\"%lu\", \"%s\", \"%d\", \
                          \"%s\", \"%s\", \"%s\", \
                          \"%s\", \"%s\", \"%s\", \
                          \"%d\", \"%d\", \"%lu\", \"%s\")",
                         hot_item.item_id, hot_item.stat_hour.c_str(), hot_item.item_type,
                         hot_item.producer.c_str(), hot_item.category.c_str(), hot_item.snd_category.c_str(),
                         hot_item.title.c_str(), hot_item.source.c_str(), hot_item.publish_time.c_str(),
                         hot_item.hot_level, hot_item.sim_item_count, hot_item.represent_item_id,
                         hot_item.last_modify_time.c_str());
  std::string sql_insert_summarize =
      base::StringPrintf("INSERT INTO tb_xss_hot_item \
                         (item_id, stat_hour, item_type, \
                          producer, category, snd_category, \
                          title, source, publish_time, \
                          hot_score, sim_item_count, represent_item_id, last_modify_time) \
                         VALUES \
                         (\"%lu\", \"%s\", \"%d\", \
                          \"%s\", \"%s\", \"%s\", \
                          \"%s\", \"%s\", \"%s\", \
                          \"%d\", \"%d\", \"%lu\", \"%s\")",
                         hot_item.item_id, hot_item.last_modify_day.c_str(), hot_item.item_type,
                         hot_item.producer.c_str(), hot_item.category.c_str(), hot_item.snd_category.c_str(),
                         hot_item.title.c_str(), hot_item.source.c_str(), hot_item.publish_time.c_str(),
                         hot_item.hot_level, hot_item.sim_item_count, hot_item.represent_item_id,
                         hot_item.last_modify_time.c_str());

  std::string sql_update =
      base::StringPrintf(" ON DUPLICATE KEY UPDATE hot_score=\"%d\", sim_item_count=\"%d\", \
                         represent_item_id=\"%lu\", last_modify_time=\"%s\"",
                         hot_item.hot_level, hot_item.sim_item_count,
                         hot_item.represent_item_id, hot_item.last_modify_time.c_str());
  std::string sql_update_summarize =
      base::StringPrintf(" ON DUPLICATE KEY UPDATE hot_score=\"%d\", sim_item_count=\"%d\", \
                         represent_item_id=\"%lu\", last_modify_time=\"%s\", stat_hour=\"%s\"",
                         hot_item.hot_level, hot_item.sim_item_count, hot_item.represent_item_id,
                         hot_item.last_modify_time.c_str(), hot_item.last_modify_day.c_str());

  std::string sql_stat_hour_str = sql_insert_stat_hour + sql_update;
  std::string sql_summarize_str = sql_insert_summarize + sql_update_summarize;
  int32 kRetryTimes = 5;
  bool insert_stat_hour_ret = false;
  bool insert_summarize_ret = false;
  try {
    insert_stat_hour_ret = db_manager_->ExecuteSQLWithRetry(sql_stat_hour_str, kRetryTimes);
    insert_summarize_ret = db_manager_->ExecuteSQLWithRetry(sql_summarize_str, kRetryTimes);
  } catch(sql::SQLException e) {
    LOG(ERROR) << "Exception: " << e.what();
    db_manager_->ConnectUntilSuccess();
    sql::Connection* db_connection = db_manager_->conn();
    CHECK_NOTNULL(db_connection);
    LOG(ERROR) << "Reconnectd to MySQL.";
    return kInsertItemFail;
  }
  if (!insert_stat_hour_ret) {
    LOG(WARNING) << "insert stat hour Fail, item id: " << hot_item.item_id << " ";
  }
  if (insert_stat_hour_ret && insert_summarize_ret) {
    hot_item_cache_->Add(item_id, hot_item);
    return kInsertItemSuccess;
  } else {
    return kInsertItemFail;
  }
}

} // namespace reco
} // namespace item_level

