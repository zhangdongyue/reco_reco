#pragma once
#include "base/common/gflags.h"

namespace reco {
namespace item_level {
// mysql config
DEFINE_string(db_host, "tcp://10.182.2.62:3306", "dbhost");
DEFINE_string(db_user, "recodev", "db user");
DEFINE_string(db_passwd, "tkDn19DHeVZkNA", "db passwd");
DEFINE_string(schema, "reco", "shcema");

} // item_level
} // namespace reco
