#include <iostream>

#include "reco/module/item_level/pr_calc/pr_calc.h"
#include "reco/module/item_level/base/connection_manager.h"
#include "reco/bizc/index_monitor/api/index_monitor.h"
#include "reco/bizc/reco_index/news_index.h"
#include "serving_base/utility/signal.h"

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "");
  CHECK(reco::item_level::ConnectionManager::InitConnection()) << "Initialize connection error.";
  reco::item_level::PRCalc* calcuter = new reco::item_level::PRCalc();
  calcuter->Start();
  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();
  LOG(INFO) << "finish signal. ";
  delete calcuter;
  reco::item_level::ConnectionManager::CleanConnection();
  return 0;
}
