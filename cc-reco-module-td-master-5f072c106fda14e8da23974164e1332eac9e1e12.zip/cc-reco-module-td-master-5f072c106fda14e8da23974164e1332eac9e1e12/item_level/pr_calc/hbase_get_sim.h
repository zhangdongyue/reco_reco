#pragma once

#include <string>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/sync.h"
#include "base/common/closure.h"
#include "base/time/timestamp.h"
#include "reco/bizc/proto/item.pb.h"

namespace net {
namespace rpc {
class RpcGroup;
}
}

namespace reco {
namespace hbase {
class HBaseCli;
}  // namespace hbase

// NOTE: not thread safe
class HBaseGetSim {
 public:
  HBaseGetSim(const std::string& hbase_ip, int hbase_port,
               const std::string& hbase_table_name);
  ~HBaseGetSim();

  void GetSims(const uint64& item_id, std::string *sim_items);
 private:
  reco::hbase::HBaseCli* hbase_;
  std::string table_name_;
};
}  // namespace reco
