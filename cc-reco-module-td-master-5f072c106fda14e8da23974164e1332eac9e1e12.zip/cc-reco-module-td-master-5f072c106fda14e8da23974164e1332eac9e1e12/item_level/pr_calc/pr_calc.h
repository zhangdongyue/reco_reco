#pragma once

#include <string>
#include <vector>
#include <fstream>
#include <unordered_map>
#include <utility>

#include "boost/unordered_map.hpp"
#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/cppconn/resultset.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/statement.h"

#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/time/timestamp.h"
#include "base/process/process_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "reco/module/item_level/base/base.h"
#include "reco/bizc/proto/reco_log.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/base/kafka_c/api/partition_consumer.h"
#include "reco/bizc/item_service/hbase_pool_get_sim.h"
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

namespace reco {
namespace item_level {

struct ItemStats {
  ItemStats() {
    reset();
  }
  std::string title;
  std::string category;
  std::string publish_time;
  std::string source;
  std::string source_top_category;
  std::unordered_map<uint64, int> sim_map;
  std::vector<std::pair<uint64, std::string> > sim_vec;
  std::vector<std::pair<uint64, std::string> > sim_vec_bak;
  double item_score;
  void reset() {
    title = "";
    category = "";
    source_top_category = "";
    publish_time = "";
    source = "";
    sim_map.clear();
    sim_vec.clear();
    item_score = 0;
  }
};

struct SourceStats {
  SourceStats() {
    reset();
  }
  double source_score;
  int item_count;
  int top_category_count;
  std::string last_publish_time;
  std::unordered_map<std::string, int> category_map;
  std::string  top_category;
  void reset() {
    source_score = 0;
    item_count = 0;
    top_category_count = 0;
    category_map.clear();
    top_category = "";
  }
};


struct SourceCategoryScore {
  SourceCategoryScore() {
    reset();
  };
  std::vector<std::pair<std::string, reco::item_level::SourceStats> > category_source_vec;
  std::vector<double> thresh_vec;
  void reset() {
    category_source_vec.clear();
    thresh_vec.clear();
  }
};

struct ItemCategoryScore {
  ItemCategoryScore() {
    reset();
  };
  std::vector<std::pair<uint64, reco::item_level::ItemStats> > category_item_vec;
  std::vector<double> thresh_vec;
  std::unordered_map<uint64, ItemStats> top_n_dict;
  std::vector<std::pair<uint64, reco::item_level::ItemStats> > top_n_vec;
  void reset() {
    category_item_vec.clear();
    thresh_vec.clear();
  }
};

enum CompareFlag {
  kSourceScore = 1,
  kItemScore = 2,
  kMixScore = 3,
};


class PRCalc {
 public:
  PRCalc();
  ~PRCalc();


  void Start();
  void Stop();

 private:
  // init jobs
  bool InitData();
  bool InitHbase();
  bool InitMysql();
  bool InitRedis();

  static const char* kItemDataStoreFile;
  static const char* kSourceDataStoreFile;
  static const char* kSourceScoreThresh;
  static const char* kSourceScoreStats;
  static const char* kItemScoreThresh;
  static const char* kItemScoreStats;
  static const char* kItemTopN;

  static const int kDictRehashSize = 100000;
  static const int kVecReserveSize = 100000;
  static const int kRedisBatchGetRecordNum = 1000;
  static const int kRetryTimes = 3;
  static const double kExp = 2.71828;

  void LoadGlobalDataFromDisk();
  void GetItemAttributes(std::string);
  void LoopUpdateStats();
  void WriteItemStatsToDisk();
  void WriteSourceStatsToDisk();
  void SortSource();
  void SortItem();
  void GetTopLevelCategory(std::string & category, std::string *top_level_category);
  double TimeDistance(const std::string& time_a, std::string& time_b);

  bool InitCategoryBoostVec();

  void UpdateSourceDict(const boost::unordered_map<uint64, ItemStats>::iterator& iter);

  static bool ComparePublish(const std::pair<uint64, reco::item_level::ItemStats>& a,
                             const std::pair<uint64, reco::item_level::ItemStats>& b);

  static bool CompareSim(const std::pair<uint64, std::string>& a, const std::pair<uint64, std::string>& b);

  bool GetQualityLevel(const uint64 &item_id, int* quality_level) const;
  static bool CompareSource(const std::pair<std::string, reco::item_level::SourceStats>& a,
                            const std::pair<std::string, reco::item_level::SourceStats>& b);

  static bool CompareItem(const std::pair<uint64, reco::item_level::ItemStats>& a,
                          const std::pair<uint64, reco::item_level::ItemStats>& b);

  void GlobalGetItems();
  void MergeGlobalData();
  void ComputeScore();
  void GenerateSourceThreshScore();
  void GenerateItemThreshScore();
  void WriteStatsToRedis(const std::vector<std::pair<uint64, ItemStats> >& stats_vec);
  // 线程写 redis
  void WriteRedisThread(const std::vector<uint64>* items, int thread_id);

 private:
  base::Time startup_time_;
  thread::Mutex mutex_;
  std::atomic<bool>* running_;
  thread::ThreadPool* thread_pool_;
  reco::HBasePoolGetSim* hbase_get_sim_;
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  reco::redis::RedisCli* redis_client_;
  reco::redis::RedisCli* slave_redis_client_;
  reco::redis::RedisCli* third_redis_client_;
  std::string last_update_mysql_time_;

  boost::unordered_map<uint64, reco::item_level::ItemStats> acc_item_dict_;
  std::vector<std::pair<uint64, reco::item_level::ItemStats> > acc_item_vec_;

  boost::unordered_map<uint64, reco::item_level::ItemStats> global_item_dict_;
  std::vector<std::pair<uint64, reco::item_level::ItemStats> > global_item_vec_;


  boost::unordered_map<std::string, reco::item_level::SourceStats> source_dict_;
  std::vector<std::pair<std::string, reco::item_level::SourceStats> > source_vec_;

  // 按照类别分别统计
  boost::unordered_map<std::string, reco::item_level::SourceCategoryScore> category_source_score_map_;

  boost::unordered_map<std::string, reco::item_level::ItemCategoryScore> category_item_score_map_;

  std::vector<std::pair<std::string, double> > category_boost_vec_;
  std::unordered_map<std::string, double> category_boost_map_;
};

}  // namespace item_level
}  // namespace reco
