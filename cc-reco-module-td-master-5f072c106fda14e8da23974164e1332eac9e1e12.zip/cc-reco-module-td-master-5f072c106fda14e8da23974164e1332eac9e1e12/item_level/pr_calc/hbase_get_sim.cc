#include "reco/module/item_level/pr_calc/hbase_get_sim.h"

#include <map>
#include <string>

#include "base/common/sleep.h"
#include "base/container/lru_cache.h"
#include "base/strings/string_number_conversions.h"
#include "reco/base/hbase_c/api/hbase_client.h"

namespace reco {

HBaseGetSim::HBaseGetSim(const std::string& hbase_ip, int hbase_port,
                           const std::string& hbase_table_name) {
  hbase_ = new reco::hbase::HBaseCli(hbase_ip, base::IntToString(hbase_port));
  CHECK(hbase_->Connect());
  table_name_ = hbase_table_name;
}

HBaseGetSim::~HBaseGetSim() {
  delete hbase_;
}

void HBaseGetSim::GetSims(const uint64& item_id, std::string *sim_items) {
  std::map<std::string, std::string> str_map;
  int retry = 0;
  std::string key = base::Uint64ToString(item_id);
  while (retry++ < 3) {
    if (hbase_->GetByKey(table_name_, key, &str_map)) {
      break;
    } else {
      LOG(ERROR) << "get sims from hbase failed!";
      if (!hbase_->Isconnect()) {
        int reconnect = 0;
        while (reconnect++ < 10 && !hbase_->Connect()) {
          base::SleepForSeconds(1);
        }
      }
      continue;
    }
  }
  auto iter = str_map.find("sim:list");
  if (iter == str_map.end()) {
    *sim_items = "";
    return;
  } else {
    *sim_items = (*iter).second;
    return;
  }
}

}  // namespace reco
