#include <utility>
#include <unordered_map>
#include <algorithm>

#include "serving_base/utility/time_helper.h"
#include "net/counter/export.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_util.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/utf_string_conversions.h"
#include "reco/module/item_level/base/connection_manager.h"
#include "reco/module/item_level/pr_calc/pr_calc.h"
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/bizc/proto/item.pb.h"

// #define max(a, b) ((a) > (b) ? (a) : (b))

namespace reco {
namespace item_level {

// redis config
DEFINE_int32(redis_record_expire_seconds, 3600*24, "time interval to inc update item info in seconds.");
DEFINE_int32(update_stats_redis_seconds, 300, "time interval to update redis data in seconds.");
DEFINE_int32(write_pr_redis_thread_num, 8, "write redis thread num");
DEFINE_bool(shut_write_redis, false, "shut down the write redis");

// hbase config
// DEFINE_string(hbase_ip, "10.181.169.19", "hbase ip");
// DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table, "tb_sim_item", "hbase table");
//  DEFINE_string(data_dir, "", "the store path action stats data");

// mysql config
DEFINE_string(db_host, "tcp://10.182.2.62:3306", "dbhost");
DEFINE_string(db_user, "recodev", "db user");
DEFINE_string(db_passwd, "tkDn19DHeVZkNA", "db passwd");
DEFINE_string(schema, "reco", "shcema");

// store config
DEFINE_int32(store_stats_disk_seconds, 300, "time interval to write stats to disk in seconds.");
DEFINE_string(store_stats_disk_dir, "../dump_data", "item stats data path");
DEFINE_int32(store_stats_expire_days, 7, "item stats expire days");
DEFINE_string(data_dir, "../data", "item stats data path");
DEFINE_int32(generate_thresh_interval_second, 300, "time interval to write stats to disk in seconds.");

// para config
DEFINE_double(para_alpha, -0.028, "the alpha para, 12hours=-0.057, 24hours=-0.028");
DEFINE_double(para_beta, 0.5, "the beta para");
DEFINE_string(category_config, "娱乐#未定义", "the toplevel category config string, category split by #");

DEFINE_string(category_boost, "国际:1.1#科技:1.1#财经:1.1#体育:1.0#娱乐:0.6#汽车:0.6#健康:0.5#美食:0.5#"
"历史:0.4#干货:0.4#奇闻:0.4#星座:0.4#两性情感:0.4#美女写真:0.4#旅游:0.4",
"the category boost, split by # ,like 国际:1.1#科技:1.1");
DEFINE_int32(top_n_num, 200, "the top n num to save");
DEFINE_int32(floor_hot_thresh, 5, "floor hot thresh");
DEFINE_double(unknown_source_score, 300, "unknown source score");


DEFINE_double(thresh_high, 0.1, "the thresh high, ratio");
DEFINE_double(thresh_mid_high, 0.3, "the thresh mid high ratio");
DEFINE_double(thresh_mid_low, 0.7, "the thresh mid low ratio");
DEFINE_double(thresh_low, 0.9, "the thresh low ratio");

const char* PRCalc::kItemDataStoreFile = "item_data.txt";
const char* PRCalc::kSourceDataStoreFile = "source_data.txt";
const char* PRCalc::kSourceScoreThresh = "source_score.thresh";
const char* PRCalc::kSourceScoreStats = "source_score.stats";
const char* PRCalc::kItemScoreThresh = "item_score.thresh";
const char* PRCalc::kItemScoreStats = "item_score.stats";
const char* PRCalc::kItemTopN = "item_top_n.stats";


void PRCalc::Start() {
  startup_time_ = base::Time::Now();
  running_ = new std::atomic<bool>(true);
  thread_pool_ = new thread::ThreadPool(1);
  LOG(INFO) << "PRCalc starting...";
  thread_pool_->AddTask(NewCallback(this, &PRCalc::LoopUpdateStats));
}

void PRCalc::Stop() {
  if (running_) {
    thread_pool_->JoinAll();
  }
  running_ = false;
  delete db_manager_;
  delete hbase_get_sim_;
}

PRCalc::PRCalc() {
  InitRedis();
  InitMysql();
  InitHbase();
  InitData();
}

bool PRCalc::InitData() {
  acc_item_vec_.reserve(kVecReserveSize);
  global_item_dict_.rehash(kDictRehashSize);
  global_item_vec_.reserve(kVecReserveSize);
  source_dict_.rehash(kDictRehashSize);
  InitCategoryBoostVec();
  GlobalGetItems();
  return true;
}

bool PRCalc::InitCategoryBoostVec() {
  std::string category_boost_str = FLAGS_category_boost;
  std::vector<std::string> category_boost_vec;
  base::SplitString(category_boost_str, "#" , &category_boost_vec);
  std::vector<std::string> key_value;
  for (int i = 0; i < (int)category_boost_vec.size(); ++i) {
    key_value.clear();
    base::SplitString(category_boost_vec[i], ":", &key_value);
    if ((int)key_value.size() != 2) {
      continue;
    } else {
      double boost = 1;
      CHECK(base::StringToDouble(key_value[1], &boost));
      LOG(INFO)<< "category: boost "<< key_value[0]<< ":" << boost;
      category_boost_map_[key_value[0]] = boost;
    }
  }
  return true;
}

bool PRCalc::InitHbase() {
  hbase_get_sim_ = NULL;
  hbase_get_sim_ = new reco::HBasePoolGetSim(FLAGS_hbase_table);
  CHECK_NOTNULL(hbase_get_sim_);
  return true;
}

bool PRCalc::InitMysql() {
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();
  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
  return true;
}

bool PRCalc::InitRedis() {
  redis_client_ = ConnectionManager::GetRedisClient();
  CHECK_NOTNULL(redis_client_);
  slave_redis_client_ = NULL;
  if (ConnectionManager::GetSlaveRedisClient() != NULL) {
    slave_redis_client_ = ConnectionManager::GetSlaveRedisClient();
    CHECK_NOTNULL(slave_redis_client_);
  }
  third_redis_client_ = NULL;
  if (ConnectionManager::GetThirdRedisClient() != NULL) {
    third_redis_client_ = ConnectionManager::GetThirdRedisClient();
    CHECK_NOTNULL(third_redis_client_);
  }

  return true;
}

void PRCalc::WriteStatsToRedis(const std::vector<std::pair<uint64, ItemStats> >& stats_vec) {
  CHECK_LT(stats_vec.size(),  15000000u) << "the number of items to write into redis is too large to quit";
  LOG(INFO) << "begin to write stats to redis, " << stats_vec.size();
  std::vector<uint64> items;
  for (auto iter = stats_vec.begin(); iter != stats_vec.end(); ++iter) {
    items.push_back(iter->first);
  }

  thread::ThreadPool pool(FLAGS_write_pr_redis_thread_num);
  for (int i = 0; i < FLAGS_write_pr_redis_thread_num; ++i) {
    pool.AddTask(NewCallback<PRCalc, const std::vector<uint64>*, int>
                 (this, &PRCalc::WriteRedisThread, &items, i));
  }
  pool.JoinAll();
  LOG(INFO) << "succ to write stats to redis, " << stats_vec.size();
}

void PRCalc::WriteRedisThread(const std::vector<uint64>* items, int thread_id) {
  if (FLAGS_shut_write_redis) return;
  int64 start_t = base::GetTimestamp();
  int count = 0;
  std::string key;
  std::string val;
  for (int idx = thread_id; idx < (int)items->size(); idx += FLAGS_write_pr_redis_thread_num) {
    uint64 item_id = items->at(idx);
    auto iter = global_item_dict_.find(item_id);
    if (iter == global_item_dict_.end()) continue;
    int quality_level;
    if (!GetQualityLevel(item_id, &quality_level)) continue;
    key = base::StringPrintf("%s%lu", kItemRedisKeyPrefix, item_id);
    val = base::StringPrintf("%d", quality_level);
    redis_client_->HSet(key, kPRScoreField, val);
    if (slave_redis_client_ != NULL) {
      slave_redis_client_->HSet(key, kPRScoreField, val);
    }
    if (third_redis_client_ != NULL) {
      third_redis_client_->HSet(key, kPRScoreField, val);
    }
    ++count;
  }

  LOG(INFO) << "write redis, thread_id: " << thread_id
            << ", total: " << count
            << ",  cost " << static_cast<int>((base::GetTimestamp() - start_t) / 1e3) << " ms.";
}

bool PRCalc::GetQualityLevel(const uint64 &item_id, int* quality_level) const {
  auto item_iter = global_item_dict_.find(item_id);
  if (item_iter == global_item_dict_.end()) return false;

  std::string category = item_iter->second.category;
  std::string undefined_category = "未定义";
  auto category_iter = category_item_score_map_.find(category);
  if (category_iter == category_item_score_map_.end()) {
    category_iter = category_item_score_map_.find(undefined_category);
    if (category_iter == category_item_score_map_.end()) {
      return false;
    }
  }
  double score = item_iter->second.item_score;
  double cate_boost = 1;
  auto cate_boost_iter = category_boost_map_.find(category);
  if (cate_boost_iter != category_boost_map_.end()) {
    cate_boost = cate_boost_iter->second;
  }

  if (score > category_iter->second.thresh_vec[0]) {
    *quality_level = (int)(kTopHotScoreThres * cate_boost);
    return true;
  } else if (score >= category_iter->second.thresh_vec[1]) {
    *quality_level = (int)(kVeryHotScoreThres * cate_boost);
    return true;
  } else if (score >= category_iter->second.thresh_vec[2]) {
    *quality_level = (int)(kHotScoreThres * cate_boost);
    return true;
  } else if (score >= category_iter->second.thresh_vec[3]) {
    *quality_level = (int)(kMidHotScoreThres * cate_boost);
    return true;
  } else if (score >= category_iter->second.thresh_vec[4]) {
    *quality_level = (int)(FLAGS_floor_hot_thresh * cate_boost);
    return true;
  } else {
    *quality_level = (int)(FLAGS_floor_hot_thresh * cate_boost);
    return true;
  }

  return true;
}

PRCalc::~PRCalc() {
  Stop();
}


bool PRCalc::ComparePublish(const std::pair<uint64, ItemStats>& a,
                                  const std::pair<uint64, ItemStats>& b) {
  return a.second.publish_time < b.second.publish_time;
}

bool PRCalc::CompareSim(const std::pair<uint64, std::string>& a,
                              const std::pair<uint64, std::string>& b) {
  return a.second < b.second;
}

bool PRCalc::CompareSource(const std::pair<std::string, SourceStats>& a,
                                 const std::pair<std::string, SourceStats>& b) {
  return a.second.source_score > b.second.source_score;
}

bool PRCalc::CompareItem(const std::pair<uint64, ItemStats>& a, const std::pair<uint64, ItemStats>& b) {
  return a.second.item_score > b.second.item_score;
}

void PRCalc::GlobalGetItems() {
    base::Time curr_time = base::Time::Now();
    base::Time expire_time = curr_time - base::TimeDelta::FromDays(FLAGS_store_stats_expire_days);
    std::string str_expire_time;
    expire_time.ToStringInSeconds(&str_expire_time);
    LOG(INFO) <<" the data expire days is: "
              <<FLAGS_store_stats_expire_days << "; the str expire time :" <<str_expire_time;
    GetItemAttributes(str_expire_time);
    MergeGlobalData();
    GenerateItemThreshScore();
    GenerateSourceThreshScore();
    WriteSourceStatsToDisk();
    WriteItemStatsToDisk();
    WriteStatsToRedis(acc_item_vec_);
}

void PRCalc::LoopUpdateStats() {
    int64 last_update_timestamp = base::GetTimestamp();
    int64 last_store_timestamp  = last_update_timestamp;
    int64 last_generate_thresh_time = last_update_timestamp;
    while (running_) {
      int64 start_t = base::GetTimestamp();
      if (start_t - last_update_timestamp < FLAGS_update_stats_redis_seconds * 1e6) {
        base::SleepForSeconds(30);
        LOG(INFO) << "not ready to write to update source score redis, wait...";
        continue;
      }
      thread::AutoLock auto_lock(&mutex_);
      GetItemAttributes(last_update_mysql_time_);
      // merge 全量数据
      MergeGlobalData();
      // 生成 item 阈值
      GenerateItemThreshScore();
      if (start_t - last_generate_thresh_time >= FLAGS_generate_thresh_interval_second * 1e6) {
        // 生成 item 阈值
//        GenerateItemThreshScore();
        // 生成 source 阈值
        GenerateSourceThreshScore();
        last_generate_thresh_time = base::GetTimestamp();
      }
      if (start_t - last_store_timestamp >= FLAGS_store_stats_disk_seconds *1e6) {
        WriteSourceStatsToDisk();
        WriteItemStatsToDisk();
        last_store_timestamp = base::GetTimestamp();
      }
      // update redis
      WriteStatsToRedis(acc_item_vec_);
      int64 end_t = base::GetTimestamp();
      last_update_timestamp = end_t;
      LOG(INFO) << "update stats cost ms: " << (end_t - start_t) / 1000;
    }
}

void PRCalc::SortSource() {
  base::Time curr_time = base::Time::Now();
  std::string str_curr_time;
  curr_time.ToStringInSeconds(&str_curr_time);
  source_vec_.clear();
  for (auto source_iter = source_dict_.begin(); source_iter != source_dict_.end(); ++source_iter) {
    source_iter->second.source_score *=
        pow(kExp, TimeDistance(str_curr_time, source_iter->second.last_publish_time)*FLAGS_para_alpha);
    source_vec_.push_back(make_pair(source_iter->first, source_iter->second));
  }
  sort(source_vec_.begin(), source_vec_.end(), CompareSource);
}

void PRCalc::SortItem() {
  base::Time curr_time = base::Time::Now();
  std::string str_curr_time;
  curr_time.ToStringInSeconds(&str_curr_time);
  global_item_vec_.clear();
  for (auto item_iter = global_item_dict_.begin(); item_iter != global_item_dict_.end(); ++item_iter) {
    item_iter->second.item_score *=
        pow(kExp, TimeDistance(str_curr_time, item_iter->second.publish_time)*FLAGS_para_alpha);
    item_iter->second.source_top_category = source_dict_[item_iter->second.source].top_category;
    global_item_vec_.push_back(std::make_pair(item_iter->first, item_iter->second));
  }
  sort(global_item_vec_.begin(), global_item_vec_.end(), CompareItem);
}

double PRCalc::TimeDistance(const std::string& time_a, std::string& time_b ) {
  base::Time a_time;
  base::Time b_time;
  base::Time::FromStringInSeconds(time_a.c_str(), &a_time);
  base::Time::FromStringInSeconds(time_b.c_str(), &b_time);
  base::TimeDelta time_distance = a_time - b_time;
  int minutes = time_distance.InMinutes();
  double hours = ((double) minutes)/(double)60;
  return std::max(hours, 0.0);
}

void PRCalc::GetTopLevelCategory(std::string & category, std::string *top_level_category) {
  std::vector<std::string> category_vec;
  base::SplitString(category, ",", &category_vec);
  if (!category_vec.empty()) {
    *top_level_category = category_vec[0];
  } else {
    *top_level_category = "";
  }
  return;
}

void PRCalc::UpdateSourceDict(const boost::unordered_map<uint64, ItemStats>::iterator& iter) {
    std::string source = iter->second.source;
    std::string publish_time = iter->second.publish_time;

    if (source_dict_.find(source) != source_dict_.end()) {
      source_dict_[source].item_count++;
      if (source_dict_[source].last_publish_time > publish_time) {
        source_dict_[source].last_publish_time = publish_time;
      } else {
        if (source == "Unknown") {
          source_dict_[source].source_score = std::min(FLAGS_unknown_source_score,
          pow(kExp, TimeDistance(iter->second.publish_time,
          source_dict_[source].last_publish_time) * FLAGS_para_alpha) * source_dict_[source].source_score);
          source_dict_[source].last_publish_time = publish_time;
        } else {
          source_dict_[source].source_score = pow(kExp, TimeDistance(iter->second.publish_time,
          source_dict_[source].last_publish_time) * FLAGS_para_alpha) * source_dict_[source].source_score;
          source_dict_[source].last_publish_time = publish_time;
        }
      }
    } else {
      source_dict_[source].item_count = 1;
      source_dict_[source].source_score = 1;
      source_dict_[source].last_publish_time = publish_time;
    }

    std::string category = iter->second.category;
    std::string& top_category = source_dict_[source].top_category;
    int &top_category_count = source_dict_[source].top_category_count;
    auto cate_iter = source_dict_[source].category_map.find(category);
    if (cate_iter != source_dict_[source].category_map.end()) {
      source_dict_[source].category_map[category] += 1;
    } else {
      source_dict_[source].category_map[category] = 1;
    }

    if (source_dict_[source].category_map[category] > top_category_count) {
      top_category = category;
      top_category_count = source_dict_[source].category_map[category];
    }
}

void PRCalc::ComputeScore() {
  LOG(INFO) << "into the compute score, acc:" << acc_item_vec_.size();
  for (auto iter_vec = acc_item_vec_.begin(); iter_vec != acc_item_vec_.end(); ++iter_vec) {
    auto global_iter = global_item_dict_.find(iter_vec->first);
    if (global_iter != global_item_dict_.end()) continue;

    auto res = global_item_dict_.insert(std::make_pair(iter_vec->first, iter_vec->second));

    if (!res.second) continue;
    auto iter = res.first;
    std::vector<uint64> sim_items;
    hbase_get_sim_->GetSimItem(iter->first, &sim_items);

    // 更新 source dict
    UpdateSourceDict(iter);

    if (sim_items.size() > 0) {
      for (size_t sim_idx = 0; sim_idx < sim_items.size(); ++sim_idx) {
        const uint64& sim_id = sim_items.at(sim_idx);
        iter->second.sim_vec_bak.push_back(std::make_pair(sim_id, ""));
        auto iter_sim = global_item_dict_.find(sim_id);
        if (iter_sim != global_item_dict_.end()) {
          if (iter->second.sim_map.find(sim_id) != iter->second.sim_map.end()) {
            continue;
          } else {
            iter->second.sim_vec.push_back(std::make_pair(sim_id, iter_sim->second.publish_time));
          }
        } else {
          continue;
        }
      }

      sort(iter->second.sim_vec.begin(), iter->second.sim_vec.end(), CompareSim);
      double item_score = 0;
      bool have_sim  = false;
      int the_earlist_sim_idx = 0;
      for (int idx = 0; idx < (int)iter->second.sim_vec.size(); ++idx) {
        auto sim_iter = global_item_dict_.find(iter->second.sim_vec[idx].first);
        if (sim_iter == global_item_dict_.end()) {
          continue;
        }

        if (!have_sim) {
            have_sim = true;
            the_earlist_sim_idx = idx;
        }

        uint64 sim_id = iter->second.sim_vec[idx].first;
        item_score += pow(kExp, TimeDistance(iter->second.publish_time,
                                             sim_iter->second.publish_time)*FLAGS_para_alpha)*
                                              pow(sim_iter->second.item_score, FLAGS_para_beta);
        iter->second.sim_map[sim_id] = idx;
      }

      // update the own source
      auto source_iter = source_dict_.find(iter->second.source);
      if (source_iter != source_dict_.end()) {
        item_score += pow((pow(kExp, TimeDistance(iter->second.publish_time,
        source_iter->second.last_publish_time)*FLAGS_para_alpha)*
        (source_iter->second.source_score)), FLAGS_para_beta);
        iter->second.item_score = item_score;
        if (source_iter->first == "Unknown") {
          source_iter->second.source_score += pow(kExp, TimeDistance(iter->second.publish_time,
          source_iter->second.last_publish_time)*FLAGS_para_alpha)* iter->second.item_score;
          source_iter->second.source_score =
              std::min(FLAGS_unknown_source_score, source_iter->second.source_score);
        } else {
          source_iter->second.source_score += pow(kExp, TimeDistance(iter->second.publish_time,
          source_iter->second.last_publish_time)*FLAGS_para_alpha)* iter->second.item_score;
        }
      } else {
//        LOG(ERROR) << "error when find the own source in the source_dict_ :"<< iter->second.source;
        continue;
      }

      // update the sim source
      if (!have_sim) continue;
      uint64 first_sim_id = iter->second.sim_vec[the_earlist_sim_idx].first;
      std::string& the_first_source = global_item_dict_[first_sim_id].source;
      auto first_source_iter = source_dict_.find(the_first_source);
      if (first_source_iter  == source_dict_.end()) {
//        LOG(ERROR) << "error when find the sim_id's source in the source_dict_ :"<< the_first_source;
        continue;
      }
      if (first_source_iter->first == "Unknown") {
        first_source_iter->second.source_score = std::min(FLAGS_unknown_source_score,
        pow(kExp, TimeDistance(iter->second.publish_time,
        first_source_iter->second.last_publish_time) * FLAGS_para_alpha) *
        first_source_iter->second.source_score + pow(iter->second.item_score, FLAGS_para_beta));
      } else {
        first_source_iter->second.source_score = pow(kExp, TimeDistance(iter->second.publish_time,
        first_source_iter->second.last_publish_time) * FLAGS_para_alpha) *
        first_source_iter->second.source_score + pow(iter->second.item_score, FLAGS_para_beta);
      }
    }
  }
}


void PRCalc::GenerateItemThreshScore() {
  LOG(INFO) << "begin to generate item thresh score, the size " << global_item_dict_.size();
  SortItem();
  uint64 start_t = base::GetTimestamp();
  std::string category_str = FLAGS_category_config;
  std::string undefined_category = "未定义";
  std::vector<std::string> flds;
  base::SplitString(category_str, "#", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    ItemCategoryScore category_score;
    category_item_score_map_[flds[i]] = category_score;
  }

  if (category_item_score_map_.find(undefined_category) == category_item_score_map_.end()) {
    ItemCategoryScore category_score;
    category_item_score_map_[undefined_category] = category_score;
  }
  auto item_iter = global_item_vec_.begin();
  for (; item_iter != global_item_vec_.end(); ++item_iter) {
    auto category = item_iter->second.category;
    if (category_item_score_map_.find(item_iter->second.category) != category_item_score_map_.end()) {
      category_item_score_map_[item_iter->second.category].category_item_vec.push_back
          (std::pair<uint64, ItemStats>(item_iter->first, item_iter->second));
    } else {
      category_item_score_map_[undefined_category].category_item_vec.push_back
          (std::pair<uint64, ItemStats>(item_iter->first, item_iter->second));
      category = undefined_category;
    }

    bool if_sim_in_top_n = false;
    auto &top_n_dict = category_item_score_map_[category].top_n_dict;
    auto &top_n_vec = category_item_score_map_[category].top_n_vec;
    if ((int)top_n_vec.size() < FLAGS_top_n_num) {
      for (auto sim_iter = item_iter->second.sim_vec_bak.begin();
           sim_iter != item_iter->second.sim_vec_bak.end(); ++sim_iter) {
        if (top_n_dict.find(sim_iter->first) != top_n_dict.end()) {
          if_sim_in_top_n = true;
          break;
        }
      }
      if (!if_sim_in_top_n) {
        top_n_dict.insert(std::make_pair(item_iter->first, item_iter->second));
        top_n_vec.push_back(std::make_pair(item_iter->first, item_iter->second));
      }
    }
  }

  auto category_iter = category_item_score_map_.begin();
  // item top 版本
  for (; category_iter != category_item_score_map_.end();++category_iter) {
    int vec_length = category_iter->second.top_n_vec.size();
    category_iter->second.thresh_vec.push_back
        (category_iter->second.top_n_vec[(int)(FLAGS_thresh_high * vec_length)].second.item_score);
    category_iter->second.thresh_vec.push_back
        (category_iter->second.top_n_vec[(int)(FLAGS_thresh_mid_high * vec_length)].second.item_score);
    category_iter->second.thresh_vec.push_back
        (category_iter->second.top_n_vec[(int)(FLAGS_thresh_mid_low * vec_length)].second.item_score);
    category_iter->second.thresh_vec.push_back
        (category_iter->second.top_n_vec[(int)(FLAGS_thresh_low * vec_length)].second.item_score);
    category_iter->second.thresh_vec.push_back
        (category_iter->second.top_n_vec[(int)(vec_length - 1)].second.item_score);
  }

  LOG(INFO) << "succ to generate item thresh score, "
            << ",  cost " << static_cast<int>((base::GetTimestamp() - start_t) / 1e3) << " ms.";
}

void PRCalc::GenerateSourceThreshScore() {
  uint64 start_t = base::GetTimestamp();
  LOG(INFO) << "begin to generate source thresh score, the size " << source_dict_.size();
  SortSource();
  std::string category_str = FLAGS_category_config;
  std::string undefined_category = "未定义";
  std::vector<std::string> flds;
  base::SplitString(category_str, "#", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    SourceCategoryScore category_score;
    category_source_score_map_[flds[i]] = category_score;
  }

  if (category_source_score_map_.find(undefined_category) == category_source_score_map_.end()) {
    SourceCategoryScore category_score;
    category_source_score_map_[undefined_category] = category_score;
  }
  auto source_iter = source_vec_.begin();
  for (; source_iter != source_vec_.end(); ++source_iter) {
    if (category_source_score_map_.find(source_iter->second.top_category) !=
        category_source_score_map_.end()) {
      category_source_score_map_[source_iter->second.top_category].category_source_vec.push_back
          (std::pair<std::string, SourceStats>(source_iter->first, source_iter->second));
    } else {
      category_source_score_map_[undefined_category].category_source_vec.push_back
          (std::pair<std::string, SourceStats>(source_iter->first, source_iter->second));
    }
  }

  auto category_iter = category_source_score_map_.begin();
  for (; category_iter != category_source_score_map_.end();++category_iter) {
//    sort(category_iter->second.category_source_vec.begin(), category_iter->second.category_source_vec.end(),
//         PRCalc::CompareSource);
    int vec_length = category_iter->second.category_source_vec.size();
    category_iter->second.thresh_vec.push_back
        (category_iter->second.category_source_vec[(int)(FLAGS_thresh_high * vec_length)].
         second.source_score);
    category_iter->second.thresh_vec.push_back
        (category_iter->second.category_source_vec[(int)(FLAGS_thresh_mid_high * vec_length)].
         second.source_score);
    category_iter->second.thresh_vec.push_back
        (category_iter->second.category_source_vec[(int)(FLAGS_thresh_mid_low * vec_length)].
         second.source_score);
    category_iter->second.thresh_vec.push_back
        (category_iter->second.category_source_vec[(int)(FLAGS_thresh_low * vec_length)].
         second.source_score);
  }
  LOG(INFO) << "succ to generate source thresh score, "
            << ",  cost " << static_cast<int>((base::GetTimestamp() - start_t) / 1e3) << " ms.";
}


void PRCalc::MergeGlobalData() {
  LOG(INFO) << "into the merge global data, acc:" << acc_item_vec_.size();
  sort(acc_item_vec_.begin(), acc_item_vec_.end(), ComparePublish);
  ComputeScore();
  LOG(INFO) << "monitor dict size, acc:" << acc_item_vec_.size()
            << "; global:" << global_item_dict_.size() << ", " << global_item_dict_.bucket_count();
}

void PRCalc::GetItemAttributes(std::string sup_bound_time) {
  acc_item_vec_.clear();
//  acc_item_dict_.clear();
  int64 start_t = base::GetTimestamp();
  base::Time curr_time = base::Time::Now();
  std::string str_curr_time;
  curr_time.ToStringInSeconds(&str_curr_time);

  std::string create_time_record = sup_bound_time;
  LOG(INFO) << "start read mysql time: " << create_time_record;
  LOG(INFO) << "current time: " << str_curr_time;
  int return_num;
  int sum_num = 0;
  while (create_time_record <= str_curr_time) {
    std::string sql_str =
    base::StringPrintf("select item_id, item_type, publish_time, create_time, channel_id, "
                       "orig_source, source, title, category from tb_item_info where create_time "
                       " > \"%s\" order by create_time Asc limit 10000", create_time_record.c_str());
    for (int i = 0; i < kRetryTimes; ++i) {
      return_num = 0;
      try {
          scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
          scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql_str));
          while (res->next()) {
            ++return_num;
            std::string create_time = res->getString("create_time");
            // 有一些 create_time 小编乱写
            if (create_time >= str_curr_time) {
              // create_time_record = create_time;
              continue;
            }
            int item_type = res->getInt("item_type");
            // 过滤本地频道 pr_score
            std::string channel_id_str = res->getString("channel_id");
            if (channel_id_str == "200") {
              create_time_record = create_time;
              continue;
            }
            // remove video and humor
            if (item_type == 30 || item_type == 3) {
              create_time_record = create_time;
              continue;
            }
            std::string publish_time = res->getString("publish_time");
            if (publish_time < sup_bound_time
                || publish_time > str_curr_time) {
              create_time_record = create_time;
              continue;
            }
            std::string item_id_str = res->getString("item_id");

            std::string source = res->getString("source");
            if (source == "proxy_gaode") {
              create_time_record = create_time;
              continue;
            }
            std::string orig_source = res->getString("orig_source");
            std::string title = res->getString("title");
            std::string category_str = res->getString("category");
            std::string category;
            GetTopLevelCategory(category_str, &category);
            uint64 item_id;
            base::StringToUint64(item_id_str, &item_id);
            auto iter = global_item_dict_.find(item_id);
            if (iter != global_item_dict_.end()) {
              create_time_record = create_time;
              continue;
            }
            ItemStats item_stats;
            item_stats.title = title;
            item_stats.category = category;
            item_stats.source = orig_source;
            item_stats.publish_time = publish_time;
            acc_item_vec_.push_back(std::make_pair(item_id, item_stats));
            create_time_record = create_time;
          }
          last_update_mysql_time_ = create_time_record;
          LOG(INFO) << "tht last return num " << return_num;
          // LOG(INFO) << "normal" <<last_update_mysql_time_;
          sum_num += return_num;
          break;
      } catch(sql::SQLException e) {
        LOG(ERROR) << "Exception: " << e.what();
        db_manager_->ConnectUntilSuccess();
        db_connection_ = db_manager_->conn();
        CHECK_NOTNULL(db_connection_);
        LOG(ERROR) << "Reconnectd to MySQL.";
      }
    }
    if (return_num < 10000) {
        base::Time update_mysql_time;
        base::Time::FromStringInSeconds(last_update_mysql_time_.c_str(), &update_mysql_time);
        base::Time new_update_mysql_time = update_mysql_time - base::TimeDelta::FromHours(1);
        new_update_mysql_time.ToStringInSeconds(&last_update_mysql_time_);
        LOG(INFO)<< "update from mysql over, last time return_num"<< return_num;
        break;
    }
  }
  int64 end_t = base::GetTimestamp();
  LOG(INFO) << "end load form mysql:  cost " << (end_t - start_t) / 1000;
  return;
}

void PRCalc::WriteItemStatsToDisk() {
  SortItem();
  LOG(INFO) << "begin to write item stats to disk, " << global_item_vec_.size();
  base::Time now = base::Time::Now();
  std::string date_suffix;
  CHECK(now.ToStringInFormat("%Y-%m-%d", &date_suffix));

  // 创建存储文件
  base::FilePath root_dir(FLAGS_store_stats_disk_dir);
  if (!base::file_util::DirectoryExists(root_dir)) {
    LOG(WARNING) << "does not exit such dir, create it, " << root_dir.ToString();
    CHECK(base::file_util::CreateDirectory(root_dir));
  }

  // 写入历史统计信息
  std::string store_file_name = base::StringPrintf("%s.%s",
                                                   kItemDataStoreFile,
                                                   date_suffix.c_str());

  base::FilePath store_file = root_dir.Append(store_file_name);
  std::ofstream os(store_file.ToString());
  for (auto iter = global_item_vec_.begin(); iter != global_item_vec_.end(); ++iter) {
    os << base::StringPrintf(
    "%lu\t%s\t%s\t%s\t%s\t%s\t%d\t%.4f\n",
                             iter->first,
                             iter->second.title.c_str(),
                             iter->second.category.c_str(),
                             iter->second.source.c_str(),
                             iter->second.source_top_category.c_str(),
                             iter->second.publish_time.c_str(),
                             (int)iter->second.sim_vec_bak.size(),
                             iter->second.item_score);
  }
  os.close();

  // generate the category stats and thresh file
  auto category_iter = category_item_score_map_.begin();
  for (; category_iter != category_item_score_map_.end(); ++category_iter) {
    std::string thresh_file_name = base::StringPrintf("%s.%s.%s",
                                                       kItemScoreThresh,
                                                       date_suffix.c_str(),
                                                       category_iter->first.c_str());
    base::FilePath thresh_store_file = root_dir.Append(thresh_file_name);
    std::ofstream os_thresh(thresh_store_file.ToString());
    auto thresh_iter = category_iter -> second.thresh_vec.begin();
    for (; thresh_iter != category_iter -> second.thresh_vec.end(); ++thresh_iter) {
      os_thresh << *thresh_iter <<std::endl;
    }
    os_thresh.close();
    std::string dict_file_name = base::StringPrintf("%s.%s.%s",
                                                   kItemScoreStats,
                                                   date_suffix.c_str(),
                                                   category_iter->first.c_str());
    base::FilePath dict_store_file = root_dir.Append(dict_file_name);
    std::ofstream os_dict(dict_store_file.ToString());
    auto item_iter = category_iter -> second.category_item_vec.begin();
    for (; item_iter != category_iter -> second.category_item_vec.end(); ++item_iter) {
      os_dict << base::StringPrintf("%lu\t%s\t%s\t%s\t%s\t%s\t%.4f\n",
                             item_iter->first,
                             item_iter->second.title.c_str(),
                             item_iter->second.category.c_str(),
                             item_iter->second.source.c_str(),
                             item_iter->second.source_top_category.c_str(),
                             item_iter->second.publish_time.c_str(),
                             item_iter->second.item_score);
    }
    os_dict.close();

    std::string top_file_name = base::StringPrintf("%s.%s.%s",
                                                   kItemTopN,
                                                   date_suffix.c_str(),
                                                   category_iter->first.c_str());
    base::FilePath top_store_file = root_dir.Append(top_file_name);
    std::ofstream os_top(top_store_file.ToString());
    auto top_iter = category_iter -> second.top_n_vec.begin();
    for (; top_iter != category_iter -> second.top_n_vec.end(); ++top_iter) {
      os_top << base::StringPrintf("%lu\t%s\t%s\t%s\t%s\t%s\t%.4f\n",
                             top_iter->first,
                             top_iter->second.title.c_str(),
                             top_iter->second.category.c_str(),
                             top_iter->second.source.c_str(),
                             top_iter->second.source_top_category.c_str(),
                             top_iter->second.publish_time.c_str(),
                             top_iter->second.item_score);
    }
    os_top.close();

    LOG(INFO) << "succ to write category item dict to disk, category: " << category_iter -> first
              << "size: " << category_iter -> second.category_item_vec.size();
  }
  LOG(INFO) << "succ to write item stats to disk";
}

void PRCalc::WriteSourceStatsToDisk() {
  GenerateSourceThreshScore();
  LOG(INFO) << "begin to write source stats to disk, " << source_dict_.size();
  base::Time now = base::Time::Now();
  std::string date_suffix;
  CHECK(now.ToStringInFormat("%Y-%m-%d", &date_suffix));

  // 创建存储文件
  base::FilePath root_dir(FLAGS_store_stats_disk_dir);
  if (!base::file_util::DirectoryExists(root_dir)) {
    LOG(WARNING) << "does not exit such dir, create it, " << root_dir.ToString();
    CHECK(base::file_util::CreateDirectory(root_dir));
  }

  // 写入历史统计信息
  std::string store_file_name = base::StringPrintf("%s.%s",
                                                   kSourceDataStoreFile,
                                                   date_suffix.c_str());

  base::FilePath store_file = root_dir.Append(store_file_name);
  std::ofstream os(store_file.ToString());
  for (auto iter = source_vec_.begin(); iter != source_vec_.end(); ++iter) {
    os << base::StringPrintf("%s\t%.4f\t%s\t%d\t%d\t%s\n",
                             iter->first.c_str(),
                             iter->second.source_score,
                             iter->second.top_category.c_str(),
                             iter->second.top_category_count,
                             iter->second.item_count,
                             iter->second.last_publish_time.c_str());
  }
  os.close();

  // generate the category stats and thresh file
  auto category_iter = category_source_score_map_.begin();
  for (; category_iter != category_source_score_map_.end(); ++category_iter) {
    std::string thresh_file_name = base::StringPrintf("%s.%s.%s",
                                                       kSourceScoreThresh,
                                                       date_suffix.c_str(),
                                                       category_iter->first.c_str());
    base::FilePath thresh_store_file = root_dir.Append(thresh_file_name);
    std::ofstream os_thresh(thresh_store_file.ToString());
    auto thresh_iter = category_iter -> second.thresh_vec.begin();
    for (; thresh_iter != category_iter -> second.thresh_vec.end(); ++thresh_iter) {
      os_thresh << *thresh_iter <<std::endl;
    }
    os_thresh.close();
    std::string dict_file_name = base::StringPrintf("%s.%s.%s",
                                                   kSourceScoreStats,
                                                   date_suffix.c_str(),
                                                   category_iter->first.c_str());
    base::FilePath dict_store_file = root_dir.Append(dict_file_name);
    std::ofstream os_dict(dict_store_file.ToString());
    auto source_iter = category_iter -> second.category_source_vec.begin();
    for (; source_iter != category_iter -> second.category_source_vec.end(); ++source_iter) {
      os_dict << base::StringPrintf("%s\t%.4f\t%s\t%d\t%d\t%s\n",
                             source_iter->first.c_str(),
                             source_iter->second.source_score,
                             source_iter->second.top_category.c_str(),
                             source_iter->second.top_category_count,
                             source_iter->second.item_count,
                             source_iter->second.last_publish_time.c_str());
    }
    os_dict.close();
    LOG(INFO) << "succ to write category source dict to disk, category: " << category_iter -> first
              << "size: " << category_iter -> second.category_source_vec.size();
  }
  LOG(INFO) << "succ to write source stats to disk";
}

}  // namespace item_level
}  // namespace reco
