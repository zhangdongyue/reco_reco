#include "reco/module/item_level/site_level/site_level_calculator.h"
#include <vector>
#include "nlp/common/nlp_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace item_level {

DEFINE_string(no_image_degrade_channels, "",
              "which channels to degrade items without image, splitted by ,");

const char* SiteLevelCalculator::kSiteLevelFile = "source_info.txt";

SiteLevelCalculator::SiteLevelCalculator() {
  std::vector<std::string> flds;
  base::SplitString(FLAGS_no_image_degrade_channels, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    no_image_degrade_channels_.insert(base::ParseInt64OrDie(flds[i]));
  }
}

SiteLevelCalculator::~SiteLevelCalculator() {
}

bool SiteLevelCalculator::ReloadDict(const base::FilePath& root_dir) {
  return (LoadSiteLevelFile(root_dir));
}

reco::SiteLevel SiteLevelCalculator::CalcSiteLevel(const ReqItemInfo& item_info) const {
  const std::string& key = nlp::util::NormalizeLine(item_info.source);

  // 直接根据词表返回
  reco::SiteLevel site_level = kMidQualitySite;
  auto const source_dict = site_level_dict_.GetDict();
  auto it = source_dict->find(key);
  if (it != source_dict->end()) {
    if (it->second > kGoodQualitySite) {
      site_level = kTopQualitySite;
    } else if (it->second >= kGoodQualitySite) {
      site_level = kGoodQualitySite;
    } else if (it->second >= kMidQualitySite) {
      site_level = kMidQualitySite;
    } else {
      site_level =  kBadQualitySite;
    }
  }

  // 无图降权
  if (site_level == kGoodQualitySite) {
    bool no_image_degrade = false;
    for (int i = 0; i < (int)item_info.channels.size(); ++i) {
      if (no_image_degrade_channels_.count(item_info.channels[i]) > 0) {
        no_image_degrade = true;
        break;
      }
    }
    if (no_image_degrade && item_info.image_count <= 0) {
      site_level = kMidQualitySite;
    }
  }

  return site_level;
}

bool SiteLevelCalculator::LoadSiteLevelFile(const base::FilePath& base_dir) {
  std::vector<std::string> lines;
  base::FilePath site_level_file = base_dir.Append(kSiteLevelFile);
  CHECK(base::file_util::ReadFileToLines(site_level_file, &lines)) << site_level_file.ToString();

  auto site_level_dict = site_level_dict_.GetInactiveDict();
  site_level_dict->clear();

  std::vector<std::string> flds;
  int authority_score;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u) {
      LOG(ERROR) << "site level file data column num error, line is: " << lines[i];
      continue;
    }
    const std::string& source_name = nlp::util::NormalizeLine(flds[0]);
    if (source_name.empty()
        || !base::StringToInt(flds[1], &authority_score)) {
      LOG(ERROR) << "site level file record content error, line is: " << lines[i];
      continue;
    }
    site_level_dict->insert(std::make_pair(source_name, authority_score));
  }

  LOG(INFO) << "site level dict load succ, file size: " << lines.size()
            << ", dict size: " << site_level_dict->size();

  site_level_dict_.SwitchDict();

  return true;
}
}
}
