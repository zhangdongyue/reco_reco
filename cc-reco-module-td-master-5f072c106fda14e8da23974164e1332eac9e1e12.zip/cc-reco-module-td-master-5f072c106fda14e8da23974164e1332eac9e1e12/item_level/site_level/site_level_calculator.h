#pragma once

#include <string>
#include <unordered_map>
#include <unordered_set>
#include "reco/module/item_level/base/base.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/base.h"

namespace reco {
namespace item_level {

// site level 计算模块
//
class SiteLevelCalculator {
 public:
  SiteLevelCalculator();
  ~SiteLevelCalculator();

  // 获取站点权威性
  reco::SiteLevel CalcSiteLevel(const ReqItemInfo& request) const;

  bool ReloadDict(const base::FilePath& root_dir);

 private:
  bool LoadSiteLevelFile(const base::FilePath& base_dir);

 private:
  // 词表相关
  static const char* kSiteLevelFile;

  // site 等级词表
  reco::DynamicDict<std::unordered_map<std::string, int>> site_level_dict_;

  // 指定频道的没有图片的文章进行降权
  std::unordered_set<int64> no_image_degrade_channels_;

  DISALLOW_COPY_AND_ASSIGN(SiteLevelCalculator);
};

}  // namespace item_level
}  // namespace reco
