#pragma once
#include <map>
#include <string>

#include "base/common/basic_types.h"
#include "base/testing/gtest_prod.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace item_level {
class TextSimilarity {
 public:
  // 通过 keyword 计算两组文本的相似度
  static double GetKeywordSimilarity(const reco::RecoItem& first,
                                     const reco::RecoItem& second);

  // 通过 topic 计算两组文本的相似度
  static double GetTopicSimilarity(const reco::RecoItem& first,
                                   const reco::RecoItem& second);
 private:
  // 计算文本相似度
  // 采用的方法是 TF-IDF 和基于空间向量的余弦算法
  // 传入为两组文本的 <高频单词-权重> 对
  // 返回值为两组文本的相似度 [0, 1]
  static double CalculateSimilarity(const std::map<std::string, uint64>& first,
                                    const std::map<std::string, uint64>& second);

  // use for test
  FRIEND_TEST(PrivateFunTest, CalculateSimilarity);
};
}  // namespace item_level
}  // namespace reco
