#include "reco/module/item_level/time_level/search_similar_item_util.h"

#include <vector>
#include <string>

#include "base/testing/gtest.h"

using std::string;
using std::vector;

namespace reco {
namespace item_level {
TEST(PrivateFunTest, DeleteSpace) {
  // TEST 1
  vector<string> ori_one = {"this", " ", "is", " ", "a", " ", "test"};
  vector<string> tar_one = {"this", "is", "a", "test"};
  vector<string> normalize_one;
  SearchSimilarItemUtil::Normalize(ori_one, &normalize_one);
  EXPECT_EQ(normalize_one, tar_one);

  // TEST 2
  vector<string> ori_two = {" ", " ", " ", " ", " ", "测试"};
  vector<string> tar_two = {"测试"};
  vector<string> normalize_two;
  SearchSimilarItemUtil::Normalize(ori_two, &normalize_two);
  EXPECT_EQ(normalize_two, tar_two);

  // TEST 3
  vector<string> ori_three = {" ", " ", " ", " ", " "};
  vector<string> tar_three;
  vector<string> normalize_three;
  SearchSimilarItemUtil::Normalize(ori_three, &normalize_three);
  EXPECT_EQ(normalize_three, tar_three);
}

TEST(PrivateFunTest, ToLowercase) {
  // TEST 1
  vector<string> ori_one = {"ThiS", " ", "IS", " ", "a", " ", "tEsT"};
  vector<string> tar_one = {"this", "is", "a", "test"};
  vector<string> normalize_one;
  SearchSimilarItemUtil::Normalize(ori_one, &normalize_one);
  EXPECT_EQ(normalize_one, tar_one);
}

TEST(PrivateFunTest, DeletePunctuation) {
  // TEST 1
  vector<string> ori_one = {"this", " ", "is", "!", "a", "?", "test", ".", "^"};
  vector<string> tar_one = {"this", "is", "a", "test"};
  vector<string> normalize_one;
  SearchSimilarItemUtil::Normalize(ori_one, &normalize_one);
  EXPECT_EQ(normalize_one, tar_one);

  // TEST 2
  vector<string> ori_two = {"这", "！", "是", "!", "。", "一个", "测试", "、", ".", "~", "=", "，"};
  vector<string> tar_two = {"这", "是", "一个", "测试"};
  vector<string> normalize_two;
  SearchSimilarItemUtil::Normalize(ori_two, &normalize_two);
  EXPECT_EQ(normalize_two, tar_two);

  // TEST 3
  vector<string> ori_three = {"。", ".", ",", "?", "!", "+", "-",
                              "*", "/", "、", "\"", "%", "$", "@", "……", ")", "(",
                              "[", "]", "【", "】", "{", "}", "|", "#",
                              "'", "“", "”", ":", ";", ">", "<", "《", "》"};
  vector<string> tar_three;
  vector<string> normalize_three;
  SearchSimilarItemUtil::Normalize(ori_three, &normalize_three);
  EXPECT_EQ(normalize_three, tar_three);

  // TEST 4
  vector<string> ori_four = {"，", "？", "！", "：", "；"};
  vector<string> tar_four;
  vector<string> normalize_four;
  SearchSimilarItemUtil::Normalize(ori_four, &normalize_four);
  EXPECT_EQ(normalize_four, tar_four);
}

TEST(PrivateFunTest, CalculateLevenshteinDistance) {
  // TEST 1
  vector<string> vec_one_first = {"this", "is", "a", "test"};
  vector<string> vec_one_second = {"that", "is", "not", "an", "apple"};
  EXPECT_EQ(SearchSimilarItemUtil::CalculateLevenshteinDistance(vec_one_first, vec_one_second),
            static_cast<uint32>(4));

  // TEST 2
  vector<string> vec_two_first = {"我", "喜欢", "吃", "苹果"};
  vector<string> vec_two_second = {"我", "爱", "吃", "香蕉"};
  EXPECT_EQ(SearchSimilarItemUtil::CalculateLevenshteinDistance(vec_two_first, vec_two_second),
            static_cast<uint32>(2));

  // TEST 3
  vector<string> vec_three_first = {"我", "喜欢", "吃", "苹果"};
  vector<string> vec_three_second = {"我", "喜欢", "吃", "苹果"};
  EXPECT_EQ(SearchSimilarItemUtil::CalculateLevenshteinDistance(vec_three_first, vec_three_second),
            static_cast<uint32>(0));

  // TEST 4
  vector<string> vec_four_first = {"我", "喜欢", "吃", "苹果"};
  vector<string> vec_four_second;
  EXPECT_EQ(SearchSimilarItemUtil::CalculateLevenshteinDistance(vec_four_first, vec_four_second),
            static_cast<uint32>(4));
}

TEST(PrivateFunTest, IsMonth) {
  struct TestCase {
    string str;
    int month;
    bool is_mon;
  }cases[] = {
    { "1", 1, true }, { "2", 2, true }, { "3", 3, true }, { "4", 4, true }, { "5", 5, true },
    { "6", 6, true }, { "7", 7, true }, { "8", 8, true }, { "9", 9, true }, { "10", 10, true },
    { "11", 11, true }, { "12", 12, true }, { "01", 1, true}, { "03", 3, true }, { "004", 4, true },
    { "0", 0, false }, { "13", 0, false }, { "100", 0, false }, { "-5", 0, false } , { "-100", 0, false },
    { "十一", 0, false }, { "十二", 0, false }, { "十五", 0, false }, { "九", 0, false },
    { "一百五十", 0, false }, { "哈哈", 0, false }, { "abcsd", 0, false }, { "..", 0, false },
  };
  int month;
  for (int64 i = 0; i < 28; ++i) {
    EXPECT_EQ(SearchSimilarItemUtil::IsMonth(cases[i].str, &month), cases[i].is_mon);
    EXPECT_EQ(cases[i].month, month);
  }
}

TEST(PrivateFunTest, IsDay) {
  struct TestCase {
    string str;
    int day;
    bool is_day;
  }cases[] = {
    { "1", 1, true }, { "12", 12, true }, { "23", 23, true }, { "4", 4, true }, { "15", 15, true },
    { "26", 26, true }, { "27", 27, true }, { "18", 18, true }, { "9", 9, true }, { "10", 10, true },
    { "111", 0, false }, { "122", 0, false }, { "01", 1, true}, { "03", 3, true }, { "004", 4, true },
    { "0", 0, false }, { "32", 0, false }, { "100", 0, false }, { "-5", 0, false } , { "-100", 0, false },
    { "零", 0, false }, { "一百五十", 0, false }, { "哈哈", 0, false }, { "abcsd", 0, false },
    { "..", 0, false },
  };
  int day;
  for (int64 i = 0; i < 25; ++i) {
    EXPECT_EQ(SearchSimilarItemUtil::IsDay(cases[i].str, &day), cases[i].is_day);
    EXPECT_EQ(cases[i].day, day);
  }
}

TEST(PrivateFunTest, IsNonNegativeInt) {
  struct TestCase {
    string str;
    bool is_num;
  }cases[] = {
    { "123", true }, { "2", true }, { "357", true }, { "十二", true }, { "一百五十三", true },
    { "三千二百五十九", true }, { "四万五千两百二十一", false }, { "一亿三千万", true },
    { "一亿五千万人", false }, { "一二三四五", true }, { "上山打老虎", false }, { "万万万万万", true },
    { ".xx.x", false }, { "这是english", false }, { "123abc", false }, { "0", true }, { "01234", true },
    { "x.", false }, { "..", false },
  };
  for (int64 i = 0; i < 18; ++i) {
    EXPECT_EQ(SearchSimilarItemUtil::IsNonNegativeInt(cases[i].str), cases[i].is_num);
  }
}

TEST(PublicFunTest, LevenshteinDistanceByWords) {
  // TEST 1
  vector<string> vec_one_first = {"this", " ", "is", " ", "test", "!"};
  vector<string> vec_one_second = {"This", "!", " ", "isn't", " ", "for", " ", "test"};
  EXPECT_EQ(SearchSimilarItemUtil::GetSimilarity(vec_one_first, vec_one_second), 0.5);

  // TEST 2
  vector<string> vec_two_first = {"this", " ", "is", " ", "test", "!"};
  vector<string> vec_two_second = {"This", "!", " ", "is", " ", " ", "test", "~", "!", "，", "！"};
  EXPECT_EQ(SearchSimilarItemUtil::GetSimilarity(vec_two_first, vec_two_second), 1);

  // TEST 3
  vector<string> vec_three_first = {"我", "喜欢", "吃", "苹果"};
  vector<string> vec_three_second = {"我", "不", "喜欢", "吃", "苹果"};
  EXPECT_EQ(SearchSimilarItemUtil::GetSimilarity(vec_three_first, vec_three_second), 0.8);

  // TEST 4
  vector<string> vec_four_first = {"我", "喜欢", "吃", "苹果"};
  vector<string> vec_four_second = {"他", "经常", "去", "游泳", "、", "健身"};
  EXPECT_EQ(SearchSimilarItemUtil::GetSimilarity(vec_four_first, vec_four_second), 0);

  // TEST 5
  vector<string> vec_five_first = {"我", "like", "吃", "apple"};
  vector<string> vec_five_second = {"我", "like", "eat", "苹果"};
  EXPECT_EQ(SearchSimilarItemUtil::GetSimilarity(vec_five_first, vec_five_second), 0.5);
}

TEST(PublicFunTest, ContainsDate) {
  int day;
  // 模式 1
  {
    // TEST 1
    vector<string> vec_one = {"今天", "是", "9", "月", "-", "5", "日", "星期一"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_one, &day));
    EXPECT_EQ(day, 247);

    // TEST 2
    vector<string> vec_two = {"今天", "是", "09", "月", "-", "05", "日", "星期一"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_two, &day));
    EXPECT_EQ(day, 247);

    // TEST 3
    vector<string> vec_three = {"今天", "是", "19", "月", "-", "35", "日", "星期一"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_three, &day));
    EXPECT_EQ(day, -1);

    // TEST 4
    vector<string> vec_four = {"今天", "是", "日", "月", "-", "月", "日", "星期x"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_four, &day));
    EXPECT_EQ(day, -1);

    // TEST 5
    vector<string> vec_five = {"今天", "是", "x", "月", "-", "x", "日", "星期x"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_five, &day));
    EXPECT_EQ(day, -1);

    // TEST 6
    vector<string> vec_six = {"今天", "是", "十一", "月", "-", "二十五", "日", "星期x"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_six, &day));
    EXPECT_EQ(day, -1);
  }

  // 模式 2
  {
    // TEST 1
    vector<string> vec_one = {"今天", "是", "9", "月", "5", "日", "星期一"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_one, &day));
    EXPECT_EQ(day, 247);

    // TEST 2
    vector<string> vec_two = {"今天", "是", "09", "月", "05", "日", "星期一"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_two, &day));
    EXPECT_EQ(day, 247);

    // TEST 3
    vector<string> vec_three = {"今天", "是", "19", "月", "35", "日", "星期一"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_three, &day));
    EXPECT_EQ(day, -1);

    // TEST 4
    vector<string> vec_four = {"今天", "是", "日", "月", "月", "日", "星期x"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_four, &day));
    EXPECT_EQ(day, -1);

    // TEST 5
    vector<string> vec_five = {"今天", "是", "x", "月", "x", "日", "星期x"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_five, &day));
    EXPECT_EQ(day, -1);
  }

  // 模式 3
  {
    // TEST 1
    vector<string> vec_one = {"资料", ":", "意甲", "联赛", "2016", "-", "2017", "赛季", "主场", "积分", "榜",
                              "(", "7", ".", "17", "-", "7", ".", "23", ")"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_one, &day));
    EXPECT_EQ(day, 203);

    // TEST 2
    vector<string> vec_two = {"资料", ":", "意甲", "联赛", "2016", "-", "2017", "赛季", "主场", "积分", "榜",
                              "(", "12", "-", "29", ")"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_two, &day));
    EXPECT_EQ(day, 362);

    // TEST 3
    vector<string> vec_three = {"资料", ":", "意甲", "联赛", "2016", "-", "2017", "赛季", "主场", "积分",
                                "榜", "08", ".", "29", ")"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_three, &day));
    EXPECT_EQ(day, 240);

    // TEST 4
    vector<string> vec_four = {"资料", ":", "意甲", "联赛", "2016", "-", "2017", "赛季", "主场", "积分", "榜",
                               "(", "08", "/", "29", ")"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_four, &day));
    EXPECT_EQ(day, -1);
  }

  // 模式 4
  {
    // TEST 1
    vector<string> vec_one = {"2016", "-", "9", "-", "5", "(", "星期一", ")"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_one, &day));
    EXPECT_EQ(day, 247);

    // TEST 2
    vector<string> vec_two = {"2016", ".", "09", ".", "05", "(", "星期一", ")"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_two, &day));
    EXPECT_EQ(day, 247);

    // TEST 3
    vector<string> vec_three = {"4", "/", "1", "十", "大", "谎言"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_three, &day));
    EXPECT_EQ(day, -1);

    // TEST 4
    vector<string> vec_four = {"4", "\\", "15", "变成", "劳动节", "？"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_four, &day));
    EXPECT_EQ(day, -1);

    // TEST 5
    vector<string> vec_five = {"今天", "是", "4", ",", "15", "date", "星期x"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_five, &day));
    EXPECT_EQ(day, -1);

    // TEST 6
    vector<string> vec_six = {"5", "-", "-", "1", "劳动节", "将", "放假", "十", "天"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_six, &day));
    EXPECT_EQ(day, -1);
  }

  // 模式 5
  {
    // TEST 1
    vector<string> vec_one = {"今天", "是", "9", "月", "第", "一", "天"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_one, &day));
    EXPECT_EQ(day, 243);

    // TEST 2
    vector<string> vec_two = {"今天", "是", "09", "月", "35", "日", "星期一"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_two, &day));
    EXPECT_EQ(day, 243);

    // TEST 3
    vector<string> vec_three = {"今天", "是", "19", "月", "5", "日", "星期一"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_three, &day));
    EXPECT_EQ(day, 4);

    // TEST 5
    vector<string> vec_five = {"今天", "是", "x", "月", "5", "日", "星期x"};
    ASSERT_TRUE(SearchSimilarItemUtil::ContainsDate(vec_five, &day));
    EXPECT_EQ(day, 4);
  }

  // 其他
  {
    // TEST 1
    vector<string> vec_one = {"今天"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_one, &day));
    EXPECT_EQ(day, -1);

    // TEST 2
    vector<string> vec_two = {"1", "2", "3", "05", "55", "星期一"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_two, &day));
    EXPECT_EQ(day, -1);

    // TEST 3
    vector<string> vec_three = {"今天", "是", "2016", "年", "最", "热", "的", "一", "天"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_three, &day));
    EXPECT_EQ(day, -1);

    // TEST 4
    vector<string> vec_four = {"九", "月", "愿", "你", "好事", "连连", "事事", "顺"};
    ASSERT_FALSE(SearchSimilarItemUtil::ContainsDate(vec_four, &day));
    EXPECT_EQ(day, -1);
  }
}

TEST(PublicFunTest, ContainsPattern) {
  string result;
  // TEST 1
  vector<string> vec_one = {"福彩", "3d", "第", "16234", "期", "分析", ":", "一", "位", "看", "579"};
  ASSERT_TRUE(SearchSimilarItemUtil::ContainsPattern(vec_one, &result));
  EXPECT_EQ(result, "16234期");

  // TEST 2
  vector<string> vec_two = {"761", "人", "参加", "面试", "“", "闯关", "”"};
  ASSERT_TRUE(SearchSimilarItemUtil::ContainsPattern(vec_two, &result));
  EXPECT_EQ(result, "761人");

  // TEST 3
  vector<string> vec_three = {"环球", "图片", "一", "周", "精选", "[", "295", "期", "]"};
  ASSERT_TRUE(SearchSimilarItemUtil::ContainsPattern(vec_three, &result));
  EXPECT_EQ(result, "295期");

  // TEST 4
  vector<string> vec_four = {"环球"};
  ASSERT_FALSE(SearchSimilarItemUtil::ContainsPattern(vec_four, &result));
  EXPECT_EQ(result, "");

  // TEST 5
  vector<string> vec_five = {"环球", "图片", "一", "周", "精选"};
  ASSERT_FALSE(SearchSimilarItemUtil::ContainsPattern(vec_five, &result));
  EXPECT_EQ(result, "");

  // TEST 6
  vector<string> vec_six;
  ASSERT_FALSE(SearchSimilarItemUtil::ContainsPattern(vec_six, &result));
  EXPECT_EQ(result, "");

  // TEST 7
  vector<string> vec_seven = {"环球", "图片", "一", "周", "精选", "第", "未知", "期"};
  ASSERT_FALSE(SearchSimilarItemUtil::ContainsPattern(vec_seven, &result));
  EXPECT_EQ(result, "");

  // TEST 8
  vector<string> vec_eight = {"今日", "股价", "上调", "87", "个", "点"};
  ASSERT_TRUE(SearchSimilarItemUtil::ContainsPattern(vec_eight, &result));
  EXPECT_EQ(result, "上调87");

  // TEST 9
  vector<string> vec_nine = {"今日", "股价", "上调", "了", "87", "个", "点"};
  ASSERT_TRUE(SearchSimilarItemUtil::ContainsPattern(vec_nine, &result));
  EXPECT_EQ(result, "上调87");
}

TEST(PublicFunTest, ContainsPatternWithRestriction) {
  string result;
  // TEST 1
  vector<string> vec_one = {"新", "上市", "福特", "福克斯", "售价", "10", ".", "6", "万元", "起"};
  ASSERT_TRUE(SearchSimilarItemUtil::ContainsPatternWithRestriction(vec_one, "汽车", &result));
  EXPECT_EQ(result, "10.6万元");

  // TEST 2
  vector<string> vec_two = {"新", "上市", "福特", "福克斯", "售价", "16", "元"};
  ASSERT_TRUE(SearchSimilarItemUtil::ContainsPatternWithRestriction(vec_two, "汽车", &result));
  EXPECT_EQ(result, "16元");

  // TEST 3
  vector<string> vec_three = {"新", "上市", "福特", "福克斯", "售价", "10", ".", "6", "万元", "起"};
  ASSERT_FALSE(SearchSimilarItemUtil::ContainsPatternWithRestriction(vec_three, "社会", &result));
  EXPECT_EQ(result, "");

  // TEST 4
  vector<string> vec_four = {"今年", "房价", "平均", "跌幅", "超", "6000", "元"};
  ASSERT_TRUE(SearchSimilarItemUtil::ContainsPatternWithRestriction(vec_four, "房产", &result));
  EXPECT_EQ(result, "6000元");

  // TEST 5
  vector<string> vec_five = {"股市", "今日", "涨幅", "5", ".", "6", "%"};
  ASSERT_TRUE(SearchSimilarItemUtil::ContainsPatternWithRestriction(vec_five, "财经", &result));
  EXPECT_EQ(result, "5.6%");

  // TEST 6
  vector<string> vec_six = {"股市", "今日", "涨幅", "5", ".", "6", "%"};
  ASSERT_FALSE(SearchSimilarItemUtil::ContainsPatternWithRestriction(vec_five, "汽车", &result));
  EXPECT_EQ(result, "");
}
}  // namespace item_level
}  // namespace reco
