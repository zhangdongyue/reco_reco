#pragma once

#include "reco/module/item_level/base/base.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/module/item_level/time_level/content_detect_item_expiry_calculator.h"
#include "reco/module/item_level/time_level/search_similar_item_expiry_calculator.h"

namespace reco {
class HBaseGetItem;

namespace item_level {

class ItemExpiryCalculator {
 public:
  explicit ItemExpiryCalculator(const reco::NewsIndex* index);
  ~ItemExpiryCalculator();
  bool IsExpiryItem(const ReqItemInfo& item_info) const;

 private:
  reco::HBaseGetItem* hbase_get_item_;
  ContentDetectItemExpiryCalculator* content_detect_calculator;
  SearchSimilarItemExpiryCalculator* search_similar_calculator;
};

}  // namespace item_level
}  // namespace reco
