#include "reco/module/item_level/time_level/time_level_calculator.h"

#include <vector>

#include "reco/bizc/common/appname_define.h"

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "nlp/common/nlp_util.h"

namespace reco {
namespace item_level {

const char* TimeLevelCalculator::kCategoryTimelinessFile = "category_timelevel.txt";

TimeLevelCalculator::TimeLevelCalculator() {
}

TimeLevelCalculator::~TimeLevelCalculator() {
}

reco::TimeLevel TimeLevelCalculator::CalcTimeLevel(const ReqItemInfo& item_info,
    const serving_base::ExpiryMap<uint64, bool>& item_expiry_dict) const {
  auto const timeliness_dict = category_timeliness_.GetDict();

  reco::TimeLevel time_level = kMidTimeliness;

  // 获取时效性阈值
  int good_timelevel_days = kGoodTimeDftDays;
  int mid_timelevel_days  = kMidTimeDftDays;
  if (!item_info.category.empty()) {
    const std::string& key
        = base::StringPrintf("%s\t%d", item_info.category.c_str(), item_info.item_type);
    auto it = timeliness_dict->find(key);
    if (it != timeliness_dict->end()) {
      good_timelevel_days = it->second.good_timelevel_days;
      mid_timelevel_days  = it->second.mid_timelevel_days;
    }
  }

  // 计算 item 与当前时间的间隔小时
  base::Time now_t = base::Time::Now();
  int hour_interval = (now_t - item_info.publish_time).InHours();

  // 计算 item 与当前时间的间隔天数
  std::string str;
  base::Time now_date;
  base::Time item_date;
  CHECK(now_t.ToStringInFormat("%Y-%m-%d", &str));
  CHECK(base::Time::FromStringInFormat(str.c_str(), "%Y-%m-%d", &now_date));
  CHECK(item_info.publish_time.ToStringInFormat("%Y-%m-%d", &str));
  CHECK(base::Time::FromStringInFormat(str.c_str(), "%Y-%m-%d", &item_date));
  base::TimeDelta date_delta = now_date - item_date;
  int day_interval = date_delta.InDays();

  if (day_interval < good_timelevel_days || hour_interval < 12) {
    // 时效性很好
    time_level = kGoodTimeliness;
  } else if (day_interval > mid_timelevel_days) {
    // 时效性很差
    time_level = kBadTimeliness;
  } else {
    time_level = kMidTimeliness;
  }
  // 如果是挖坟文章，设置成时效性差
  bool is_item_expiry_item = false;
  if (item_expiry_dict.FindSilently(item_info.item_id, &is_item_expiry_item)
      && is_item_expiry_item) {
    time_level = kBadTimeliness;
  }
  // 运营文章，至少调成中间时效性
  if (item_info.producer != reco::common::kZZDProducer
      && time_level <= reco::kBadTimeliness) {
    time_level = reco::kMidTimeliness;
  }

  return time_level;
}

bool TimeLevelCalculator::ReloadDict(const base::FilePath& root_dir) {
  return LoadCategoryTimelinessFile(root_dir);
}

bool TimeLevelCalculator::LoadCategoryTimelinessFile(const base::FilePath& root_dir) {
  thread::AutoLock auto_lock(&mutex_);

  std::vector<std::string> lines;
  base::FilePath timeliness_file = root_dir.Append(kCategoryTimelinessFile);
  CHECK(base::file_util::ReadFileToLines(timeliness_file, &lines)) << timeliness_file.ToString();

  auto timeliness_dict = category_timeliness_.GetInactiveDict();
  timeliness_dict->clear();

  TimePartition partition;
  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 3u
        || !base::StringToInt(flds[2], &partition.good_timelevel_days)
        || !base::StringToInt(flds[3], &partition.mid_timelevel_days)) {
      LOG(ERROR) << "category_timeliness file field error, line is: " << lines[i];
      continue;
    }
    const std::string& item_type = flds[1];
    const std::string& category_str = nlp::util::NormalizeLine(flds[0]) + "\t" + item_type;
    timeliness_dict->insert(std::make_pair(category_str, partition));
  }

  LOG(INFO) << "succ to load category timeliness dict"
            << ", file size: " << lines.size()
            << ", dict size: " << timeliness_dict->size();

  category_timeliness_.SwitchDict();

  return true;
}

}  // namespace item_level
}  // namespace reco
