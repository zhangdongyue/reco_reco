#include "reco/module/item_level/time_level/search_similar_item_util.h"

#include <algorithm>
#include <set>
#include <string>
#include <vector>

#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/common/slice.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/time/time.h"
#include "nlp/common/rune_type.h"
#include "nlp/common/nlp_util.h"

namespace reco {
namespace item_level {
namespace {
  const int kDaysBeforeMonth[] = {0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};
  const std::set<std::string> kNumber = {"零", "一", "二", "三", "四", "五", "六", "七",
                                            "八", "九", "十", "百", "千", "万", "亿"};
  const std::set<std::string> kPrice = {"元", "万元", "万", "亿元", "亿", "万亿"};
  const std::set<std::string> kOrdinalCharacter = {"号", "次", "篇", "季", "届", "家", "周", "季度"};
  const std::set<std::string> kTimesCharacter = {"批", "期", "股", "人", "批次", "家", "季度"};
  const std::set<std::string> kPrefixCharacter = {"停运", "上升", "下降", "上调", "下调", "上涨", "下跌",
                                                  "涨", "跌", "q"};
}

// 以单词为单位计算两字符串的相似度
// 输入为两字符串经过分词后的结果
// 输出为相似度
double SearchSimilarItemUtil::GetSimilarity(const std::vector<std::string>& first_words,
                                            const std::vector<std::string>& second_words) {
  // 对两组单词做规格化处理
  std::vector<std::string> first_normalized_words;
  Normalize(first_words, &first_normalized_words);

  std::vector<std::string> second_normalized_words;
  Normalize(second_words, &second_normalized_words);

  // 计算结果
  uint32 levenshtein_distance = CalculateLevenshteinDistance(first_normalized_words, second_normalized_words);

  // 保存 size
  int max_size = std::max(first_normalized_words.size(), second_normalized_words.size());
  double similarity = 1 - levenshtein_distance * 1.0 / (max_size * 1.0);

  return similarity;
}

// 做规格化处理
// 处理包括将单词转换为半角、小写
// 以及删除标点符号及 whitespace
// whitespace 定义见 base/strings/string_util.h
void SearchSimilarItemUtil::Normalize(const std::vector<std::string>& from, std::vector<std::string>* to) {
  nlp::rune::RuneTypeDetector detector;
  for (uint64 index = 0; index < from.size(); ++index) {
    std::string word;
    // 将单词转化为半角、小写
    nlp::util::QuanJiaoToBanJiao(from[index], &word);
    base::LowerString(&word);
    // 删除标点符号和 whitespace
    base::Slice word_slice = word;
    int result = detector.MultiRunesTypeDetect(word_slice);
    if (nlp::rune::is_rune_type(result, nlp::rune::kPunctuation) == false
        && nlp::rune::is_rune_type(result, nlp::rune::kWhiteSpace) == false) {
      to->push_back(word);
    }
  }
}

// 计算编辑距离
uint32 SearchSimilarItemUtil::CalculateLevenshteinDistance(const std::vector<std::string>& first_vec,
                                                           const std::vector<std::string>& second_vec) {
  uint64 length_of_first = first_vec.size();
  uint64 length_of_second = second_vec.size();

  uint32 **dist = new uint32*[length_of_first + 1];
  for (uint64 i = 0; i < length_of_first + 1; ++i) {
    dist[i] = new uint32[length_of_second + 1];
  }

  for (uint64 i = 0; i < length_of_first + 1; ++i) {
    dist[i][0] = i;
  }
  for (uint64 i = 0; i < length_of_second + 1; ++i) {
    dist[0][i] = i;
  }

  for (uint64 i = 1; i < length_of_first + 1; ++i) {
    for (uint64 j = 1; j < length_of_second + 1; ++j) {
      uint32 cost = (first_vec[i-1] == second_vec[j-1]) ? 0 : 1;

      uint32 deletion = dist[i-1][j] + 1;
      uint32 insertion = dist[i][j-1] + 1;
      uint32 substitution = dist[i-1][j-1] + cost;

      dist[i][j] = std::min(std::min(deletion, insertion), substitution);
    }
  }

  uint32 levenshtein_distance = dist[length_of_first][length_of_second];

  for (uint64 i = 0; i < length_of_first + 1; ++i) {
    delete[] dist[i];
  }
  delete[] dist;

  return levenshtein_distance;
}

// 计算汉明距离 (simhash)
int32 SearchSimilarItemUtil::HammingDistance(int64 hash1, int64 hash2) {
  int64 i = hash1 ^ hash2;
  i = i - ((i >> 1) & 0x5555555555555555L);
  i = (i & 0x3333333333333333L) + ((i >> 2) & 0x3333333333333333L);
  i = (i + (i >> 4)) & 0x0f0f0f0f0f0f0f0fL;
  i = i + (i >> 8);
  i = i + (i >> 16);
  i = i + (i >> 32);
  return (int32) i & 0x7f;
}

// 判断文章中是否含有时间
// 最后获得 date_in_days 减 1 的原因是为了与 TimeDelta 类标准一致
bool SearchSimilarItemUtil::ContainsDate(const std::vector<std::string>& words, int* date_in_days) {
  int month, day;
  // 模式 1: x 月 - y 日
  for (int64 i = 0; i < static_cast<int64>(words.size()) - 4; ++i) {
    if (IsMonth(words[i], &month)
        && words[i+1] == "月"
        && words[i+2] == "-"
        && IsDay(words[i+3], &day)
        && (words[i+4] == "日" || words[i+4] == "号")) {
      (*date_in_days) = kDaysBeforeMonth[month] + day - 1;
      return true;
    }
  }
  // 模式 2: x 月 y 日
  for (int64 i = 0; i < static_cast<int64>(words.size()) - 2; ++i) {
    if (IsMonth(words[i], &month)
        && words[i+1] == "月"
        && IsDay(words[i+2], &day)) {
      (*date_in_days) = kDaysBeforeMonth[month] + day - 1;
      return true;
    }
  }
  // 模式 3: (mm.dd), (mm-dd), (mm.dd-mm.dd), mm.dd
  for (int64 i = 0; i < static_cast<int64>(words.size()) - 3; ++i) {
    if (IsMonth(words[i], &month)
        && (words[i+1] == "." || words[i+1] == "-")
        && IsDay(words[i+2], &day)
        && words[i+3] == ")") {
      (*date_in_days) = kDaysBeforeMonth[month] + day - 1;
      return true;
    }
  }
  // 模式 4: yyyy.mm.dd, yyyy/mm/dd, yyyy-mm-dd
  for (int64 i = 0; i < static_cast<int64>(words.size()) - 4; ++i) {
    if (((words[i+1] == "." && words[i+3] == ".")
          || (words[i+1] == "/" && words[i+3] == "/")
          || (words[i+1] == "-" && words[i+3] == "-")
          || (words[i+1] == "\\" && words[i+3] == "\\"))
        && IsYear(words[i])
        && IsMonth(words[i+2], &month)
        && IsDay(words[i+4], &day)) {
      (*date_in_days) = kDaysBeforeMonth[month] + day - 1;
      return true;
    }
  }
  // 模式 5: mm 月, dd 日
  for (int64 i = 0; i < static_cast<int64>(words.size()) - 1; ++i) {
    if (IsMonth(words[i], &month) && words[i+1] == "月") {
      (*date_in_days) = kDaysBeforeMonth[month];
      return true;
    } else if (IsDay(words[i], &day) && words[i+1] == "日") {
      (*date_in_days) = day - 1;
      return true;
    }
  }
  (*date_in_days) = -1;
  return false;
}

// 就目前来看，如果日期中带有年份的话，年份通常为数字
// 并且通过年月日来区分时效性的文章通常是最近发生的时事
// 所以，限定年份时判断其是否在 1900 ~ 2050 这段区间内
bool SearchSimilarItemUtil::IsYear(const std::string& str) {
  int year;
  if (base::StringToInt(str, &year) && year >= 1900 && year <= 2050) {
    return true;
  }
  return false;
}

// 判断字符串是否符合月份的格式
bool SearchSimilarItemUtil::IsMonth(const std::string& str, int* month) {
  // 检查是不是数字的月份
  if (base::StringToInt(str, month) && (*month) > 0 && (*month) < 13) {
    return true;
  }
  (*month) = 0;
  return false;
}

// 判断字符串是否符合日期的格式
bool SearchSimilarItemUtil::IsDay(const std::string& str, int* day) {
  // 检查是不是数字的日期
  if (base::StringToInt(str, day) && (*day) > 0 && (*day) < 32) {
    return true;
  }
  (*day) = 0;
  return false;
}

// 判断字符串中是否包含某一模式
// 如：第 5 天，第 6 批，第 15 期，35 人，180 股等
bool SearchSimilarItemUtil::ContainsPattern(const std::vector<std::string>& words, std::string* result) {
  // 寻找有没有匹配的模式
  int64 words_size = static_cast<int64>(words.size());
  // 模式 1: 第 x Y, 如：第 5 批，第 6 期
  for (int64 i = 0; i < words_size - 2; ++i) {
    if (words[i] == "第"
        && IsNonNegativeInt(words[i+1])
        && kOrdinalCharacter.count(words[i+2]) != 0) {
      (*result) = words[i+1] + words[i+2];
      return true;
    }
  }
  // 模式 2: x Y，如：35 人，180 股
  for (int64 i = 0; i < words_size - 1; ++i) {
    if (IsNonNegativeInt(words[i])
        && kTimesCharacter.count(words[i+1]) != 0) {
      (*result) = words[i] + words[i+1];
      return true;
    }
  }
  // 模式 3: X y，如：上调 24，下跌 56
  for (int64 i = 0; i < words_size - 1; ++i) {
    if (kPrefixCharacter.count(words[i]) != 0
        && IsNonNegativeInt(words[i+1])) {
      (*result) = words[i] + words[i+1];
      return true;
    }
  }
  // 模式 4: X 了 y，如：上调了 24，下跌了 56
  for (int64 i = 0; i < words_size - 2; ++i) {
    if (kPrefixCharacter.count(words[i]) != 0
        && words[i+1] == "了"
        && IsNonNegativeInt(words[i+2])) {
      (*result) = words[i] + words[i+2];
      return true;
    }
  }

  (*result) = "";
  return false;
}

// 对于某些特殊的条件限制可能会有特殊的规则
// 如：对于汽车类或财经类的文章，标题中是否含有价格并且价格是否相同可以作为判断是否是挖坟文章的依据
//     对于财经类文章，标题含有百分数，类似涨幅等相关的信息，可以看做是判断是否是挖坟文章的依据
bool SearchSimilarItemUtil::ContainsPatternWithRestriction(const std::vector<std::string>& words,
                                                           const std::string restriction,
                                                           std::string* result) {
  int64 words_size = static_cast<int64>(words.size());
  if (restriction == "汽车" || restriction == "房产" || restriction == "财经") {
    // 模式 1: x.y 元，x.y 万元, x.y 万, 其中 x.y 为小数
    for (int64 i = 0; i < words_size - 3; ++i) {
      if (!IsNonNegativeInt(words[i])
          || words[i+1] != "."
          || !IsNonNegativeInt(words[i+2])
          || kPrice.count(words[i+3]) == 0) {
        continue;
      }
      (*result) = words[i] + words[i+1] + words[i+2] + words[i+3];
      return true;
    }
    // 模式 2: x 元，x 万元，x 万，其中 x 为整数
    for (int64 i = 0; i < words_size - 1; ++i) {
      if (!IsNonNegativeInt(words[i])
          || kPrice.count(words[i+1]) == 0) {
        continue;
      }
      (*result) = words[i] + words[i+1];
      return true;
    }
  }
  if (restriction == "财经") {
    // 模式 1: 涨幅 x.y %
    for (int64 i = 0; i < words_size - 3; ++i) {
      if (!IsNonNegativeInt(words[i])
          || words[i+1] != "."
          || !IsNonNegativeInt(words[i+2])
          || words[i+3] != "%") {
        continue;
      }
      (*result) = words[i] + words[i+1] + words[i+2] + words[i+3];
      return true;
    }
    // 模式 2: 涨幅 x%
    for (int64 i = 0; i < words_size - 1; ++i) {
      if (!IsNonNegativeInt(words[i])
          || words[i+1] != "%") {
        continue;
      }
      (*result) = words[i] + words[i+1];
      return true;
    }
  }
  (*result) = "";
  return false;
}


// 判断是否是数字，包括中文数字和阿拉伯数字
bool SearchSimilarItemUtil::IsNonNegativeInt(const std::string& str) {
  // 如果是纯中文
  if (str.length()%3 == 0 && str.length() >= 3) {
    bool all_is_chinese_number = true;
    for (int64 i = 0; i < static_cast<int64>(str.length()) - 2; i+=3) {
      if (kNumber.count(str.substr(i, 3)) == 0) {
        all_is_chinese_number = false;
        break;
      }
    }
    if (all_is_chinese_number) {
      return true;
    }
  }
  // 检查阿拉伯数字
  for (uint64 index = 0; index < str.size(); ++index) {
    if (str[index] < '0' || str[index] > '9') {
      return false;
    }
  }
  return true;
}
}  // namespace item_level
}  // namespace reco
