#pragma once

#include <string>
#include <vector>

#include "base/common/base.h"
#include "base/container/dense_hash_set.h"
#include "base/file/file_util.h"
#include "extend/regexp/re2/re2.h"
#include "reco/module/item_level/base/base.h"
#include "reco/bizc/reco_index/news_index.h"

namespace reco {
namespace item_level {

class ContentDetectItemExpiryCalculator {
 public:
  explicit ContentDetectItemExpiryCalculator(const reco::NewsIndex* index);
  ~ContentDetectItemExpiryCalculator();
  bool IsExpiryItem(const ReqItemInfo& item_info) const;

 private:
  bool CheckExpireBaseRegex(const ReqItemInfo& item_info) const;
  bool CheckExpireBaseSim(const ReqItemInfo& item_info) const;
  // 正则匹配式 预先初始化提高性能
  std::vector<extend::re2::RE2*> regex_pattern_;
  // 正则白名单
  std::vector<extend::re2::RE2*> regex_white_list_pattern_;
  base::dense_hash_set<std::string> regex_available_category_;
  const reco::NewsIndex* news_index_;
};

}  // namespace item_level
}  // namespace reco
