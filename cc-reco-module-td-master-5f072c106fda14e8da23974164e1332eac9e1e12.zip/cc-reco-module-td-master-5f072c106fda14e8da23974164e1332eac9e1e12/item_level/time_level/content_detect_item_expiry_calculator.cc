#include "reco/module/item_level/time_level/content_detect_item_expiry_calculator.h"

#include <cmath>
#include <iostream>

#include "base/strings/string_split.h"

namespace reco {
namespace item_level {

DEFINE_int32(content_expiry_day, 7, "天数阈值, 超过阈值判断过期");

ContentDetectItemExpiryCalculator::ContentDetectItemExpiryCalculator(const reco::NewsIndex* index) {
  news_index_ = index;
  regex_pattern_.clear();
  regex_available_category_.set_empty_key("");
  regex_available_category_.clear();
  regex_pattern_.push_back(new extend::re2::RE2("\\D*(\\d+)月(\\d+)日"));
  regex_white_list_pattern_.push_back(new extend::re2::RE2(".*今天|今日|近日|昨天|昨日|今早|今晚.*"));
  regex_available_category_.insert("体育");
  regex_available_category_.insert("娱乐");
  regex_available_category_.insert("社会");
  regex_available_category_.insert("科技");
  regex_available_category_.insert("军事");
  regex_available_category_.insert("财经");
}
ContentDetectItemExpiryCalculator::~ContentDetectItemExpiryCalculator() {
  for (size_t i = 0; i < regex_pattern_.size(); ++i) {
    delete regex_pattern_[i];
  }
}
bool ContentDetectItemExpiryCalculator::IsExpiryItem(const ReqItemInfo& item_info) const {
  return (CheckExpireBaseRegex(item_info) && CheckExpireBaseSim(item_info));
}
bool ContentDetectItemExpiryCalculator::CheckExpireBaseRegex(const ReqItemInfo& item_info) const {
  if (regex_available_category_.find(item_info.category) == regex_available_category_.end()) return false;
  // 先检测白名单
  for (size_t white_pattern_index = 0; white_pattern_index < regex_white_list_pattern_.size();
       ++white_pattern_index) {
    extend::re2::RE2* one_regex = regex_white_list_pattern_[white_pattern_index];
    if (!one_regex->ok()) {
      LOG(ERROR) << "regex white list pattern parse error, the error pattern index is: "
                 << white_pattern_index << "\t"
                 << "the pattern is: " << one_regex->pattern();
      continue;
    }
    if (extend::re2::RE2::FullMatch(item_info.content, *one_regex)) return false;
  }
  for (size_t pattern_index = 0; pattern_index < regex_pattern_.size(); ++pattern_index) {
    if (!regex_pattern_[pattern_index]->ok()) {
      LOG(ERROR) << "regex pattern parse error, the error pattern index is: " << pattern_index << "\t"
                 << "the pattern is: " << regex_pattern_[pattern_index]->pattern();
      continue;
    }
    // 使用全文做判断
    base::Slice input(item_info.content);
    // 内容中匹配出的月和天
    int32 content_month = 0, content_day = 0;
    // 临时变量
    int32 month_t = 0, day_t = 0;
    bool match_flag = false;
    while (!item_info.content.empty()
           && extend::re2::RE2::Consume(&input, *(regex_pattern_[pattern_index]), &month_t, &day_t)) {
      match_flag = true;
      if (month_t > content_month
          || (month_t == content_month && day_t > content_day)) {
        content_month = month_t;
        content_day = day_t;
      }
    }
    if (match_flag) {
      base::Time now_time = base::Time::Now();
      base::Time::Exploded exploded;
      now_time.LocalExplode(&exploded);
      int32 now_month = exploded.month;
      int32 now_day = exploded.day_of_month;
      if ((now_month * 30 + now_day) - (content_month * 30 + content_day) > FLAGS_content_expiry_day) {
        return true;
      }
    }
  }
  return false;
}
// 判断 文章发布时间 与 所有相似文章的平均发布时间 是否超过阈值
bool ContentDetectItemExpiryCalculator::CheckExpireBaseSim(const ReqItemInfo& item_info) const {
  if (item_info.item_sim_vec == NULL || item_info.item_sim_vec->size() == 0) return true;
  double ave_time = 0;
  for (auto it = item_info.item_sim_vec->begin(); it != item_info.item_sim_vec->end(); ++it) {
    int64 sim_item_create_time = news_index_->GetCreateTimestampByItemId(*it);
    if (sim_item_create_time != 0)
    ave_time += (static_cast<double>(sim_item_create_time) / 1e6);
  }
  ave_time = ave_time / item_info.item_sim_vec->size();
  base::Time ave_time_delta = base::Time::FromDoubleT(ave_time);
  double item_time = item_info.publish_time.ToDoubleT();
  if (abs(item_time - ave_time) <= (FLAGS_content_expiry_day * 24 * 3600)) {
    return false;
  }
  return true;
}

}  // namespace item_level
}  // namespace reco
