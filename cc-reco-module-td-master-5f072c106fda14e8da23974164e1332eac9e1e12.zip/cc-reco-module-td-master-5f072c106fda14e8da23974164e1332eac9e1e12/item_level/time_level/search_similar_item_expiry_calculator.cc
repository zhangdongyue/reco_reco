#include "reco/module/item_level/time_level/search_similar_item_expiry_calculator.h"

#include <algorithm>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include "base/common/basic_types.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/time/time.h"
#include "extend/multi_strings/multi_strings_vldc.h"
#include "net/rpc/rpc.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/module/item_level/time_level/search_similar_item_util.h"
#include "reco/module/item_level/time_level/text_similarity.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/reco_search_server.pb.h"

DEFINE_bool(logreason, false, "flag to determine whether log reason or not");

DEFINE_double(similarity_threshold1, 0.70, "the first threshold value that consider an item is expiry");
DEFINE_double(similarity_threshold2, 0.85, "the second threshold value that consider an item is expiry");
DEFINE_double(content_threshold1, 1.96, "the 1st content threshold value that consider an item is expriy");
DEFINE_double(content_threshold2, 1.97, "the 2nd content threshold value that consider an item is expiry");
DEFINE_int32(search_similar_out_of_days, 3, "搜索若干天前是否有相似文章的阈值。天");

namespace reco {
namespace item_level {
namespace {
const std::set<std::string> kSpecificCategory = {"汽车", "房产", "财经"};
const std::set<std::string> kSpecificTitle = {"今日电视", "今晚电视", "每日彩讯", "更正与说明", "移民讲座",
                                              "人民法院公告", "重晚副刊", "开奖公告", "北京新发地菜价晴雨表",
                                              "健康大课堂开讲啦", "今天辽阳天气", "渭南天气早报", "通 告",
                                              "长治交警: 交通违法曝光台", "直播导视", "专家论彩", "书店有约",
                                              "时报体育频道", "秦皇岛港城早市最新菜价", "抚顺市枫红指数",
                                              "荆州地区生活指数"};
const std::set<std::string> kHighQualitySource = {"凤凰网资讯", "环球网国际", "环球网国内", "东方网_国内",
                                                  "东方网_国际", "中国江苏网_国内", "中国江苏网_国际",
                                                  "央广网_新闻接口", "北青网_新闻资讯接口", "手机人民网-国内",
                                                  "手机人民网-国际", "手机人民网-社会", "人民网国际",
                                                  "中新网国际", "南海网-国际", "新华网全球播报",
                                                  "央视新闻APP-要闻", "人民网地方新闻"};
const std::set<std::string> kHighQualityCategory = {"未分类", "社会", "国际", "国内", "房产", "汽车", "游戏",
                                                    "旅游"};
const std::vector<std::string> kSpecificKeyword = {"天气预报", "本周", "今日", "乐透", "福彩", "竞彩", "体彩",
                                                   "福利彩票", "体育彩票", "橙色*警报", "蓝色*警报",
                                                   "红色*警报", "双色球", "每日运势", "公示", "公告", "通告",
                                                   "橙色*预警", "蓝色*预警", "黄色*预警", "下周", "红色*预警",
                                                   "人大常委会", "人民代表大会", "人大代表", "大宗商品",
                                                   "任免", "黄色*警报", "气象预报", "萌宝秀", "节目预告",
                                                   "担任*省长", "担任*书记", "担任*市长", "担任*县长",
                                                   "担任*主任", "担任*委员", "担任*主席", "担任*区长",
                                                   "当选*省长", "当选*书记", "当选*市长", "当选*县长",
                                                   "当选*主任", "当选*委员", "当选*主席", "当选*区长",
                                                   "任*省长", "任*书记", "任*市长", "任*县长", "任*主任",
                                                   "任*委员", "任*主席", "任*区长", "辞去*省长", "辞去*书记",
                                                   "辞去*市长", "辞去*县长", "辞去*主任", "辞去*委员",
                                                   "辞去*主席", "辞去*区长", "大师兄小师妹", "听故事|",
                                                   "变变格漫", "每日一言", "每日好孕", "下周yy课预告",
                                                   "发生*级地震", "启动*应急响应", "一分钟心理", "天气情况",
                                                   "流出前*股", "最新资讯"};
const std::vector<std::string> kSpecificSource = {"^手机新浪网-股票$", "^新浪接口数据_体育$",
                                                  "^新浪体育图片$", "^中国好诗词$", "^网贷之家-网贷政策$",
                                                  "^新浪体育", "^女姿清纯美女$", "^新浪黄金频道$",
                                                  "^中国天气网_rss$"};
const std::vector<std::string> kSpecificTimeliness = {"下周", "下月"};
};

SearchSimilarItemExpiryCalculator::SearchSimilarItemExpiryCalculator(reco::HBaseGetItem* hbase) {
  is_init_ = false;
  hbase_get_item_ = hbase;
  search_util_ = new SearchUtil();
  title_matcher_ = new VLDC::MultiStringVLDC();
  source_matcher_ = new VLDC::MultiStringVLDC();
  timeliness_matcher_ = new VLDC::MultiStringVLDC();
}

SearchSimilarItemExpiryCalculator::~SearchSimilarItemExpiryCalculator() {
  delete search_util_;
  delete title_matcher_;
  delete source_matcher_;
  delete timeliness_matcher_;
}

// 判断一篇文章是否是挖坟文章
// 输入：文章 id，需要保存文章信息的 RecoItem，以及挖坟文章信息的 RecoItem
// 输出：bool，true 表示是挖分文章
// 只有在返回 true 时，similar_item 中才会保存信息，否则访问 similar_item 无意义
// NOTE: 参数不可传入 NULL；
bool SearchSimilarItemExpiryCalculator::IsExpiryItem(uint64 item_id,
                                                     reco::RecoItem* source_item,
                                                     reco::RecoItem* similar_item) {
  if (!is_init_) {
    Init();
  }
  CHECK_NOTNULL(source_item);
  CHECK_NOTNULL(similar_item);
  if (!hbase_get_item_->GetRecoItem(item_id, source_item)) {
    LOG(ERROR) << "query failed when query source item id: " << item_id;
    return false;
  }
  return IsExpiryItem(*source_item, similar_item);
}

bool SearchSimilarItemExpiryCalculator::IsExpiryItem(const reco::RecoItem& source_item,
                                                     reco::RecoItem* similar_item) {
  if (!is_init_) {
    Init();
  }
  CHECK_NOTNULL(similar_item);
  LOG_IF(INFO, FLAGS_logreason) << source_item.identity().item_id() << "\t" << source_item.title() << "\t"
                                << source_item.source() << "\t" << source_item.create_time();
  // 文章 title 不为空时查询
  std::string trim_title = source_item.title();
  base::TrimWhitespaces(&trim_title);
  if (trim_title.empty()) {
    LOG_IF(INFO, FLAGS_logreason) << "source item title is empty";
    return false;
  }

  // 文章标题是特定标题时，一般不是挖坟文章
  if (kSpecificTitle.find(source_item.title()) != kSpecificTitle.end()) {
    LOG_IF(INFO, FLAGS_logreason) << "source item title matches specifc titles";
    return false;
  }

  // 文章标题中含有特殊单词时，一般不是挖坟文章
  std::vector<VLDC::MatchResult> match_result;
  if (title_matcher_->MatchAll(source_item.title().c_str(), source_item.title().length(), &match_result)) {
    LOG_IF(INFO, FLAGS_logreason) << "source item titles contains specific keywords";
    return false;
  }

  // 文章来源是一些特定来源时，一般不是挖坟文章
  std::string source_with_ends = "^" + source_item.source() + "$";
  if (source_matcher_->MatchAll(source_with_ends.c_str(), source_with_ends.length(), &match_result)) {
    LOG_IF(INFO, FLAGS_logreason) << "source item posted by specific sources";
    return false;
  }

  std::vector<reco::RecoItem> alternative_item_list;
  // 通过 search_server 获取潜在的挖坟文章 id
  if (FindAlternativeItem(source_item.title(), &alternative_item_list)) {
    return CheckSingleArticle(source_item, alternative_item_list, similar_item);
  } else {
    LOG(ERROR) << "search similar item failed, source item id: " << source_item.identity().item_id();
    return false;
  }
}

// 初始化类内部变量
void SearchSimilarItemExpiryCalculator::Init() {
  std::string reason;
  for (uint64 index = 0; index < kSpecificKeyword.size(); ++index) {
    if (!title_matcher_->AddRule(kSpecificKeyword[index], &reason)) {
      LOG(ERROR) << "add rule failed when adding rule \"" << kSpecificKeyword[index]
                 << "\" with reason: " << reason;
    }
  }
  CHECK(title_matcher_->Build()) << "Failed when init title_matcher";
  for (uint64 index = 0; index < kSpecificSource.size(); ++index) {
    if (!source_matcher_->AddRule(kSpecificSource[index], &reason)) {
      LOG(ERROR) << "add rule failed when adding rule \"" << kSpecificSource[index]
                 << "\" with reason: " << reason;
    }
  }
  CHECK(source_matcher_->Build()) << "Failed when init source_matcher";
  for (uint64 index = 0; index < kSpecificTimeliness.size(); ++index) {
    if (!timeliness_matcher_->AddRule(kSpecificTimeliness[index], &reason)) {
      LOG(ERROR) << "add rule failed when adding rule \"" << kSpecificTimeliness[index]
                 << "\" with reason: " << reason;
    }
  }
  CHECK(timeliness_matcher_->Build()) << "Failed when init timeliness_matcher";
  is_init_ = true;
}

// 内部调用函数
// 输入是需要判断的文章的信息以及 search_server 返回的查询结果列表
// 通过两两比较 create_time, type, title similarity 和 simhash 来决定一篇文章是否是挖分文章
// 在执行函数的过程中出错则返回 false (不是挖坟文章)
bool SearchSimilarItemExpiryCalculator::CheckSingleArticle(const reco::RecoItem& source_item,
                                                    const std::vector<reco::RecoItem>& alternative_item_list,
                                                    reco::RecoItem* similar_item) {
  std::vector<std::string> source_word_list;
  GetWordListWithoutWhitespace(source_item, &source_word_list);

  bool is_similar_exist = false;
  // 现在保存的是正文最相似的文章，而不是标题最相似的文章
  double min_content_diff = static_cast<double>(INT_MAX);
  double min_suspected_diff = static_cast<double>(INT_MAX);
  bool has_suspected = false;
  // 在疑似文章的前提下，在该文章发布近期有多少个其他源发布同样的文章
  int num_of_source_post_same_article = 0;
  reco::RecoItem suspected_item;
  for (auto it = alternative_item_list.begin(); it != alternative_item_list.end(); ++it) {
    reco::RecoItem alternative_item = (*it);
    // 文章类型不同则不予考虑 (两篇文章为 kNews 或 kReading 时除外)
    if (source_item.identity().type() != alternative_item.identity().type()) {
      if ((source_item.identity().type() != kNews && source_item.identity().type() != kReading)
         || (alternative_item.identity().type() != kNews && alternative_item.identity().type() != kReading)) {
        LOG_IF(INFO, FLAGS_logreason) << alternative_item.identity().item_id() << "\t"
                                      << alternative_item.title() << ": items' type are different";
        continue;
      }
    }

    // 计算两篇文章的时间间隔，如果时间转换失败，则查看下一篇候选文章
    bool is_latest_article = false;
    if (!CheckTimeInterval(source_item, alternative_item, &is_latest_article)) {
      LOG_IF(INFO, FLAGS_logreason) << alternative_item.identity().item_id() << "\t"
                                    << alternative_item.title() << ": time transition failed";
      continue;
    }

    std::vector<std::string> alternative_word_list;
    GetWordListWithoutWhitespace(alternative_item, &alternative_word_list);

    double title_similarity = SearchSimilarItemUtil::GetSimilarity(source_word_list, alternative_word_list);
    // 标题如果相似，则判断正文的标准降低
    // 否则，提高正文判断标准
    is_title_similar_ = (title_similarity >= FLAGS_similarity_threshold1);

    // 检查标题中是否含有日期或者匹配特定的模式、日期或者模式是否相同，如果不同说明不是挖坟文章
    if (CheckDateNotSame(source_word_list, alternative_word_list)
        || CheckPatternNotSame(source_word_list, alternative_word_list)
        || CheckPatternWithRestriction(GetItemCategory(source_item), GetItemCategory(alternative_item),
                                       source_word_list, alternative_word_list)) {
      LOG_IF(INFO, FLAGS_logreason) << alternative_item.identity().item_id() << "\t"
                                    << alternative_item.title() << ": titles contain different pattern";
      continue;
    }

    // 如果源文章不含时效性词汇 (如：下月，下周)，但候选文章含此类词汇，说明不是挖坟文章
    std::vector<VLDC::MatchResult> res;
    if (!timeliness_matcher_->MatchAll(source_item.title().c_str(), source_item.title().length(), &res)
        && timeliness_matcher_->MatchAll(alternative_item.title().c_str(),
                                         alternative_item.title().length(), &res)) {
      LOG_IF(INFO, FLAGS_logreason) << alternative_item.identity().item_id() << "\t"
                                    << alternative_item.title() << ": title contains timeliness words";
      continue;
    }

    double content_diff;
    if (source_item.identity().type() == reco::kPureVideo) {
      // TODO(zhangfan): handle with the purevideo item
    // 纯图片，判断图片的相似度
    // 对于图片，不存在疑似的规则。因为判断图片是否相同标准很严格。
    } else if (!is_latest_article && source_item.identity().type() == reco::kPicture) {
      if (CheckImageSimilar(source_item, alternative_item, &content_diff) != IsSimilar) {
        continue;
      }
      is_similar_exist = true;
      UpdateSimilarItem(content_diff, alternative_item, &min_content_diff, similar_item);
    } else {
      // 处理正文
      // CheckContentIsSimilar 无法判断两篇文章是否相似，此时
      // 通过提高标题相似度的标准来判断是否相似
      SimilarResult res = CheckContentIsSimilar(source_item, alternative_item, &content_diff);
      if (res == IsSimilar) {
        if (is_latest_article && source_item.source() != alternative_item.source()) {
          ++num_of_source_post_same_article;
        } else if (!is_latest_article) {
          is_similar_exist = true;
          UpdateSimilarItem(content_diff, alternative_item, &min_content_diff, similar_item);
        }
      } else if (res == NotSure && !is_latest_article) {
        LOG_IF(INFO, FLAGS_logreason) << alternative_item.identity().item_id() << "\t"
                                      << alternative_item.title() << ": can't decide from content "
                                      << "rejudge from title with similarity " << title_similarity;
        if (title_similarity >= FLAGS_similarity_threshold2) {
          is_similar_exist = true;
          UpdateSimilarItem(content_diff, alternative_item, &min_content_diff, similar_item);
        }
      } else if (res == Suspected && !is_latest_article) {
        has_suspected = true;
        UpdateSimilarItem(content_diff, alternative_item, &min_suspected_diff, &suspected_item);
      }
    }
  }

  // 如果不存在相似文章，但是存在疑似文章，并且该篇文章发布近期内没有其他相似的文章发布，则看做是挖坟文章
  if (!is_similar_exist && has_suspected && num_of_source_post_same_article == 0) {
    is_similar_exist = true;
    (*similar_item) = suspected_item;
  }
  return is_similar_exist;
}

// 获取两篇文章的时间间隔
bool SearchSimilarItemExpiryCalculator::CheckTimeInterval(const reco::RecoItem& first,
                                                          const reco::RecoItem& second,
                                                          bool* is_latest_article) {
  base::Time first_time, second_time;
  if (!base::Time::FromStringInFormat(first.create_time().c_str(), "%Y-%m-%d %H:%M:%S", &first_time)
      || !base::Time::FromStringInFormat(second.create_time().c_str(), "%Y-%m-%d %H:%M:%S", &second_time)) {
    LOG(ERROR) << "Format string to time failed. item_id " << first.identity().item_id() <<
                                                    " or " << second.identity().item_id();
    return false;
  }
  base::TimeDelta delta = first_time - second_time;
  (*is_latest_article) = (delta.InDays() < FLAGS_search_similar_out_of_days);

  return (delta.InDays() >= 0);
}

// 更新保留标题相似度最高的文章
void SearchSimilarItemExpiryCalculator::UpdateSimilarItem(double similarity,
                                                          const reco::RecoItem& candidate,
                                                          double* min_similarity,
                                                          reco::RecoItem* target) {
  if (similarity < (*min_similarity)) {
    (*min_similarity) = similarity;
    (*target) = candidate;
  }
}

// 获取文章标题，并去除其中的 whitespace
void SearchSimilarItemExpiryCalculator::GetWordListWithoutWhitespace(const reco::RecoItem& item,
                                                                     std::vector<std::string>* words) {
  for (int index = 0; index < item.title_unigram_size(); ++index) {
    std::string trim = item.title_unigram(index);
    base::TrimWhitespaces(&trim);
    if (trim.empty()) continue;
    words->push_back(trim);
  }
}

// 从 search server 获取标题类似的文章信息
bool SearchSimilarItemExpiryCalculator::FindAlternativeItem(const std::string& query_title,
                                                            std::vector<reco::RecoItem>* result) {
  reco::searchserver::GeneralSearchResponse response;
  if (!search_util_->QuerySearch(query_title, 20, &response) || response.result_size() <= 0) {
    return false;
  }

  const reco::searchserver::SearchResult& search_result = response.result(0);
  for (int index = 0; index < search_result.doc_info_size(); ++index) {
    reco::RecoItem item;
    if (!hbase_get_item_->GetRecoItem(search_result.doc_info(index).item_id(), &item)) {
      LOG(ERROR) << "query failed when query item id: " << search_result.doc_info(index).item_id();
      continue;
    }
    result->push_back(item);
  }
  return true;
}

// 从正文角度判断两篇文章是否相似
// 判断方法如下：
//  如果两篇文章的 simhash 值均存在，则通过汉明距离判断。
//     汉明距离的阀值通过 GetSimhashThreshold 获得。
//  返回：IsSimilar 表示两篇文章相似
//        NotSure 表示无法判断
//        NotSimilar 表示两篇文章不相似
SearchSimilarItemExpiryCalculator::SimilarResult
SearchSimilarItemExpiryCalculator::CheckContentIsSimilar(const reco::RecoItem& first,
                                                         const reco::RecoItem& second,
                                                         double* similarity) {
  if (first.has_raw_item() && first.raw_item().has_simhash()
      && second.has_raw_item() && second.raw_item().has_simhash()) {
    std::string category_first = GetItemCategory(first);
    std::string category_second = GetItemCategory(second);
    // 考虑到存在为图片配文字的新闻，所以限制如果文章正文分配到每张图片上字数不大于 30 个字，
    // 就可以将其看做是图片占主要部分的新闻，此时判断图片的相似度即可。
    // 除此之外，此规则对于图片数量较少时会产生较大误差（由于文章头尾可能存在的起始段或结尾段），
    // 所以，在上述数值基础上再加 300 作为误差的弥补值
    // (9.28): 财经类文章图片的 simhash 差值误差较大，所以不作为判断是挖坟的标准，但可作判断不是挖坟的标准
    if (static_cast<int>(first.content().length()) <= first.image_size() * 90 + 300
        && static_cast<int>(second.content().length()) <= second.image_size() * 90 + 300) {
      SimilarResult result = CheckImageSimilar(first, second, similarity);
      if (category_first == "财经" || category_second == "财经"
          || category_first == "股票" || category_second == "股票") {
        if (result == NotSimilar) {
          return result;
        }
      } else if (result != NotSure) {
        return result;
      }

      // 在从图片角度判断不出来的情况下，如果有文章没有正文，则无法判断
      if (first.content().length() == 0 || second.content().length() == 0) {
        return NotSure;
      }
    }

    // 获取阀值
    int32 hamming_distance =
              SearchSimilarItemUtil::HammingDistance(first.raw_item().simhash(), second.raw_item().simhash());
    (*similarity) = static_cast<double>(hamming_distance);

    int32 threshold = GetSimhashThreshold(first, second);
    if (hamming_distance < threshold) {
      LOG_IF(INFO, FLAGS_logreason) << second.identity().item_id() << "\t" << second.title()
                                    << ": contents are similar with " << hamming_distance
                                    << " under threshold " << threshold;
      return IsSimilar;
    // 对于地域不同的文章，不对其进行疑似文章的判断
    // 阀值 SureNot 和 RegionThreshold 只有地域不同时才会返回
    } else if (threshold != kSureNot && threshold != kRegionThreshold
               && hamming_distance < kSuspectedThreshold) {
      // 对 财经、游戏、收藏类 文章不进行正文的疑似文章判断
      if (category_first != "财经" && category_second != "财经"
          && category_first != "游戏" && category_second != "游戏"
          && category_first != "收藏" && category_second != "收藏") {
        double sum_similarity = TextSimilarity::GetTopicSimilarity(first, second)
                                + TextSimilarity::GetKeywordSimilarity(first, second);
        // 对于 simhash < 12 的视为一档，使用于标题不相似的文章的疑似文章的判断，
        // 对符合此条件的文章判断其是挖分文章要求 topic 和 keyword 和大于等于 1.96，
        // 除此之外的其他文章，判断其为挖坟文章的标准提高至 1.97
        if ((!is_title_similar_
             && hamming_distance < kSuspectedLowThreshold
             && sum_similarity >= FLAGS_content_threshold1)
            || (is_title_similar_
                && sum_similarity >= FLAGS_content_threshold2)) {
          LOG_IF(INFO, FLAGS_logreason) << second.identity().item_id() << "\t" << second.title()
                                        << ": found suspected article";
          return Suspected;
        }
      }
    }

    LOG_IF(INFO, FLAGS_logreason) << second.identity().item_id() << "\t" << second.title()
                                  << ": contents are different with " << hamming_distance
                                  << " under threshold " << threshold;
    return NotSimilar;
  } else {
    LOG_IF(INFO, FLAGS_logreason) << second.identity().item_id() << "\t" << second.title()
                                  << ": articles have no simhash";
    return CheckImageSimilar(first, second, similarity);
  }
}

// 如果文章标题中均含有日期
// 日期相同则说明很有可能是挖坟文章
// 若日期不同则说明不是挖坟文章
bool SearchSimilarItemExpiryCalculator::CheckDateNotSame(const std::vector<std::string>& first,
                                                         const std::vector<std::string>& second) {
  int days_of_first;
  int days_of_second;
  bool has_date_first = SearchSimilarItemUtil::ContainsDate(first, &days_of_first);
  bool has_date_second = SearchSimilarItemUtil::ContainsDate(second, &days_of_second);
  return ((has_date_first || has_date_second) && days_of_first != days_of_second);
}

// 如果两篇文章标题中含有类似： x 期， x 篇，x 股等等模式的话
// 如果匹配模式不同，则说明很大可能不是挖坟文章
bool SearchSimilarItemExpiryCalculator::CheckPatternNotSame(const std::vector<std::string>& first,
                                                            const std::vector<std::string>& second) {
  std::string result_first;
  std::string result_second;
  bool has_pattern_first = SearchSimilarItemUtil::ContainsPattern(first, &result_first);
  bool has_pattern_second = SearchSimilarItemUtil::ContainsPattern(second, &result_second);
  return ((has_pattern_first || has_pattern_second) && result_first != result_second);
}

// 对于某些符合特殊条件的文章，比如：category 是 汽车 的文章，有些特殊的模式需要进行匹配，如果能够匹配上
// 并且匹配模式不同，则很有可能不是挖坟文章
bool SearchSimilarItemExpiryCalculator::CheckPatternWithRestriction(const std::string& first_restriction,
                                                              const std::string& second_restriction,
                                                              const std::vector<std::string>& first_words,
                                                              const std::vector<std::string>& second_words) {
  std::string restriction;
  if (kSpecificCategory.count(first_restriction) != 0) {
    restriction = first_restriction;
  } else if (kSpecificCategory.count(second_restriction) != 0) {
    restriction = second_restriction;
  } else {
    restriction = "";
  }

  std::string result_first;
  std::string result_second;
  if (SearchSimilarItemUtil::ContainsPatternWithRestriction(first_words, restriction, &result_first)
      && SearchSimilarItemUtil::ContainsPatternWithRestriction(second_words, restriction, &result_second)) {
    return (result_first != result_second);
  }
  return false;
}

// 检测两篇文章是否包含地域，如果包含地域，所属地域是否不同
bool SearchSimilarItemExpiryCalculator::CheckRegionNotSame(const reco::RecoItem& first,
                                                           const reco::RecoItem& second) {
  // 至少有一篇文章不含有地域信息则无法判断
  if (!first.has_region() || !second.has_region()) {
    return false;
  }

  // 获取地域信息
  std::vector<std::string> region_of_first;
  base::SplitStringWithOptions(first.region(), ";", true, true, &region_of_first);
  std::vector<std::string> region_of_second;
  base::SplitStringWithOptions(second.region(), ";", true, true, &region_of_second);

  // 不含有地域信息或者包含的地域信息数量不同，则无法判断
  if (region_of_first.empty() || region_of_second.empty()
      || region_of_first.size() != region_of_second.size()) {
    return false;
  }

  sort(region_of_first.begin(), region_of_first.end());
  sort(region_of_second.begin(), region_of_second.end());
  for (uint64 index = 0; index < region_of_first.size(); ++index) {
    if (region_of_first[index] != region_of_second[index]) {
      return true;
    }
  }
  return false;
}

// 针对不同文章给出不同的阀值
// 规则：
//    先检测两篇文章的地域是否相同，如果不同的话，说明存在可能不是挖坟文章
//        此时需要检测两篇文章的图片相似度，一般带有地域标志的文章有两类
//        一类为软文，另一类为时政新闻。一般情况下，软文都还有大量配图。
//        所以通过检测图片判断是不是软文，如果是软文，两篇文章图片是否相似
//        如果没有图片一般则是时政新闻，此时不是挖坟文章的可能性很大，返回一个低阀值 2
//        如果图片不相似，则说明不是挖坟文章，返回阀值 0
//    财经类文章很多不是挖坟文章，所以加强限制，阀值返回 7
//    对于有些优质的源发布的一些优质类别的文章，提高阀值限制，返回 10
//    其他情况下，如果文章标题相似，则降低正文限制，阀值为 14
//                                                  否则为 8
SearchSimilarItemExpiryCalculator::SimhashThreshold
SearchSimilarItemExpiryCalculator::GetSimhashThreshold(const reco::RecoItem& first,
                                                       const reco::RecoItem& second) {
  // 检查地域信息是否不一致，如果不一致则表示有很大可能不是挖坟文章
  if (CheckRegionNotSame(first, second)) {
    double similarity;
    SimilarResult result = CheckImageSimilar(first, second, &similarity);
    // 如果文章不含有图片，或者图片数量较少，则可看做不是软文，此时说明很可能不是挖坟文章
    if (result == NotSure
        || (first.raw_item().image_size() <= 3 && second.raw_item().image_size() <= 3)) {
      return kRegionThreshold;
    } else if (result == NotSimilar) {
      return kSureNot;
    }
  }

  std::string category_first = GetItemCategory(first);
  std::string category_second = GetItemCategory(second);
  // 对财经类文章和股票类文章加强限制
  if (category_first == "财经" || category_second == "财经"
      || category_first == "股票" || category_second == "股票") {
    return kFinanceThreshold;
  }

  // 对于优质源发布的优质类别的文章给予较严格的评判标准
  if (kHighQualitySource.find(first.source()) != kHighQualitySource.end()
      && kHighQualityCategory.count(category_first) != 0
      && kHighQualityCategory.count(category_second) != 0
      && (category_first != "未分类" || category_second != "未分类")) {
    return kHighQualityThreshold;
  }

  // 其他情况设定阀值为默认值
  if (is_title_similar_)
    return kDefaultThreshold;
  return kStrictThreshold;
}

// 判断纯图的新闻是否是挖坟文章
// 判断方法如下：
//     比较图片较少的文章中的图片是否在另一篇文章中出现过
//     如果出现率超过 60% 则认为是挖坟文章
//     判断图片重复的方法采用使用两篇文章 simhash 的 hamming 距离判断
SearchSimilarItemExpiryCalculator::SimilarResult
SearchSimilarItemExpiryCalculator::CheckImageSimilar(const reco::RecoItem& first,
                                                     const reco::RecoItem& second,
                                                     double* similarity) {
  (*similarity) = static_cast<double>(INT_MAX) - 1.0;
  if (!first.has_raw_item() || !second.has_raw_item()) {
    return NotSure;
  }

  if (first.raw_item().image_size() == 0 || second.raw_item().image_size() == 0) {
    return NotSure;
  }

  // (9.28): 如果源文章就一两张图，且相似文章有一定数量的图片，存在源文章图片是自媒体或广告的宣传图
  //         在此情况下判断的准确率不高，所以不进行判断
  if (first.raw_item().image_size() <= 2 && second.raw_item().image_size() >= 5) {
    return NotSure;
  }

  // (9.21): 如果源文章比相似文章图片数量多很多，则说明不是挖坟文章
  if (first.raw_item().image_size() - second.raw_item().image_size() >= 5) {
    LOG_IF(INFO, FLAGS_logreason) << second.identity().item_id() << "\t" << second.title()
                                  << ": diff of images more than 5";
    return NotSimilar;
  }

  // 如果存在任意一篇文章存在一定比例的图片 simhash 没有计算出来，那么后续的计算就没有必要
  uint64 zero_count_first = 0;
  for (int i = 0; i < first.raw_item().image_size() && first.raw_item().image(i).has_simhash(); ++i) {
    zero_count_first += (first.raw_item().image(i).simhash() == 0 ? 1 : 0);
  }
  uint64 zero_count_second = 0;
  for (int i = 0; i < second.raw_item().image_size() && second.raw_item().image(i).has_simhash(); ++i) {
    zero_count_second += (second.raw_item().image(i).simhash() == 0 ? 1 : 0);
  }
  if (static_cast<double>(zero_count_first) / static_cast<double>(first.raw_item().image_size()) >= 0.50
    || static_cast<double>(zero_count_second) / static_cast<double>(second.raw_item().image_size()) >= 0.50) {
    return NotSure;
  }

  int size_of_less, size_of_more;
  reco::RecoItem less_image_item, more_image_item;
  if (first.raw_item().image_size() >= second.raw_item().image_size()) {
    more_image_item = first;
    size_of_more = first.raw_item().image_size();
    less_image_item = second;
    size_of_less = second.raw_item().image_size();
  } else {
    less_image_item = first;
    size_of_less = first.raw_item().image_size();
    more_image_item = second;
    size_of_more = second.raw_item().image_size();
  }

  // 财经类文章加强限制
  int threshold = kImageThreshold;
  if (GetItemCategory(first) == "财经" || GetItemCategory(second) == "财经"
      || GetItemCategory(first) == "股票" || GetItemCategory(second) == "股票") {
    threshold = kFinanceImageThreshold;
  }

  int same_pic_count = 0;
  for (int i = 0; i < size_of_less && less_image_item.raw_item().image(i).has_simhash(); ++i) {
    int min_simhash = 0x3f3f3f3f;
    for (int j = 0; j < size_of_more && more_image_item.raw_item().image(j).has_simhash(); ++j) {
      int32 hamming = SearchSimilarItemUtil::HammingDistance(less_image_item.raw_item().image(i).simhash(),
                                                             more_image_item.raw_item().image(j).simhash());
      min_simhash = std::min(min_simhash, hamming);
    }
    if (min_simhash <= threshold) {
      ++same_pic_count;
    }
  }

  (*similarity) = 1 - static_cast<double>(same_pic_count) / static_cast<double>(size_of_less);
  // 对于不同数量的图片，判断图片相似有不同的数量限制，若图片数量大于 2，则要求至少有 60% 以上图片相似
  //                                                   其他情况，则需保证至少有 50% 以上图片相似
  if ((size_of_less >= 3 && (*similarity) <= 0.40)
      || (size_of_less <= 2 && (*similarity) <= 0.5)) {
    LOG_IF(INFO, FLAGS_logreason) << second.identity().item_id() << "\t" << second.title()
                                  << ": images are similar with similarity " << 1 - (*similarity)
                                  << " under images count " << size_of_less;
    // 图片很少的情况下，还要从正文的角度判断
    if (size_of_less <= 2) {
      return NotSure;
    }
    return IsSimilar;
  }
  LOG_IF(INFO, FLAGS_logreason) << second.identity().item_id() << "\t" << second.title()
                                << ": images are different with similarity " << 1 - (*similarity)
                                << " under images count " << size_of_less;
  return NotSimilar;
}
}  // namespace item_level
}  // namespace reco
