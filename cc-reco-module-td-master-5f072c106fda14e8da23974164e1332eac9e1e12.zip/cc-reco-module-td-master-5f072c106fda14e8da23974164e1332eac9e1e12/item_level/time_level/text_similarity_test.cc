#include "reco/module/item_level/time_level/text_similarity.h"

#include <cmath>
#include <map>
#include <string>
#include <utility>

#include "base/common/basic_types.h"
#include "base/testing/gtest.h"

using std::map;
using std::pair;
using std::string;

namespace reco {
namespace item_level {
TEST(PrivateFunTest, CalculateSimilarity) {
  // TEST 1
  struct Cases {
    string str;
    uint64 weight;
  } cases1[] = {
    {"A", 10},
    {"B", 20},
    {"C", 15},
    {"D", 35},
    {"E", 20},
  };
  map<string, uint64> m11;
  map<string, uint64> m12;
  for (int i = 0; i < 5; ++i) {
    m11.insert(pair<string, uint64>(cases1[i].str, cases1[i].weight));
    m12.insert(pair<string, uint64>(cases1[i].str, cases1[i].weight));
  }
  EXPECT_EQ(TextSimilarity::CalculateSimilarity(m11, m12), 1);

  // TEST 2
  Cases cases2[] = {
    {"A", 10},
    {"B", 20},
    {"C", 15},
    {"D", 35},
    {"E", 20},
    {"F", 20},
    {"G", 25},
    {"H", 15},
    {"I", 30},
    {"J", 10},
  };
  map<string, uint64> m21;
  map<string, uint64> m22;
  for (int i = 0, j = 5; i < 5 && j < 10; ++i, ++j) {
    m21.insert(pair<string, uint64>(cases2[i].str, cases2[i].weight));
    m22.insert(pair<string, uint64>(cases2[j].str, cases2[j].weight));
  }
  EXPECT_EQ(TextSimilarity::CalculateSimilarity(m21, m22), 0);

  // TEST 3
  Cases cases3[] = {
    {"A", 10},
    {"B", 20},
    {"C", 15},
    {"D", 35},
    {"E", 20},
    {"F", 20},
    {"A", 25},
    {"B", 15},
    {"C", 30},
    {"D", 10},
  };
  map<string, uint64> m31;
  map<string, uint64> m32;
  for (int i = 0, j = 5; i < 5 && j < 10; ++i, ++j) {
    m31.insert(pair<string, uint64>(cases3[i].str, cases3[i].weight));
    m32.insert(pair<string, uint64>(cases3[j].str, cases3[j].weight));
  }
  EXPECT_EQ(TextSimilarity::CalculateSimilarity(m31, m32), static_cast<double>(1350.0 / sqrt(2350.0*2250.0)));

  // TEST 4
  Cases cases4[] = {
    {"A", 10},
    {"B", 20},
    {"C", 15},
    {"A", 10},
    {"D", 20},
    {"E", 15},
  };
  map<string, uint64> m41;
  map<string, uint64> m42;
  for (int i = 0, j = 3; i < 3 && j < 6; ++i, ++j) {
    m41.insert(pair<string, uint64>(cases4[i].str, cases4[i].weight));
    m42.insert(pair<string, uint64>(cases4[j].str, cases4[j].weight));
  }
  EXPECT_EQ(TextSimilarity::CalculateSimilarity(m41, m42), static_cast<double>(100.0 / 725.0));

  // TEST 5
  Cases cases5[] = {
    {"A", 10},
    {"B", 20},
    {"C", 15},
    {"A", 10},
    {"B", 20},
    {"C", 20},
  };
  map<string, uint64> m51;
  map<string, uint64> m52;
  for (int i = 0, j = 3; i < 3 && j < 6; ++i, ++j) {
    m51.insert(pair<string, uint64>(cases5[i].str, cases5[i].weight));
    m52.insert(pair<string, uint64>(cases5[j].str, cases5[j].weight));
  }
  EXPECT_EQ(TextSimilarity::CalculateSimilarity(m51, m52), static_cast<double>(800.0 / sqrt(725.0*900.0)));
}
}  // namespace item_level
}  // namespace reco
