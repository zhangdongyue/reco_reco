#pragma once

#include <string>
#include <unordered_map>

#include "base/common/base.h"
#include "base/file/file_util.h"
#include "reco/module/item_level/base/base.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "serving_base/expiry_map/expiry_map.h"

namespace reco {
namespace item_level {

// 时效性计算模块
//
class TimeLevelCalculator {
 public:
  explicit TimeLevelCalculator();
  ~TimeLevelCalculator();

  // 计算 item level
  reco::TimeLevel CalcTimeLevel(const ReqItemInfo& item_info,
                                const serving_base::ExpiryMap<uint64, bool>& item_expiry_dict) const;

  // 重载词典
  bool ReloadDict(const base::FilePath& root_dir);

 private:
  bool LoadCategoryTimelinessFile(const base::FilePath& base_dir);

 private:
  static const char* kCategoryTimelinessFile;

  static const int   kGoodTimeDftDays = 1;
  static const int   kMidTimeDftDays = 2;
  struct TimePartition {
    int good_timelevel_days;
    int mid_timelevel_days;
    TimePartition() :
        good_timelevel_days(kGoodTimeDftDays),
        mid_timelevel_days(kMidTimeDftDays) {}
  };

 private:
  thread::Mutex mutex_;

  // category + itemtype 联合，作为时效性的判断依据
  reco::DynamicDict<std::unordered_map<std::string, TimePartition> > category_timeliness_;

  DISALLOW_COPY_AND_ASSIGN(TimeLevelCalculator);
};

}  // namespace item_level
}  // namespace reco
