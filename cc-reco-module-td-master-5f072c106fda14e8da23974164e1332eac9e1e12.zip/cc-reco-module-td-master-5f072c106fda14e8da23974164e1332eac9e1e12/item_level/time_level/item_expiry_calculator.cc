#include "reco/module/item_level/time_level/item_expiry_calculator.h"

#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/module/item_level/time_level/search_similar_item_expiry_calculator.h"

DEFINE_string(reco_item_hbase_table, "tb_reco_item", "the hbase table name that query from.");

namespace reco {
namespace item_level {

ItemExpiryCalculator::ItemExpiryCalculator(const reco::NewsIndex* index) {
  hbase_get_item_ = new reco::HBaseGetItem(FLAGS_reco_item_hbase_table, -1);
  content_detect_calculator = new ContentDetectItemExpiryCalculator(index);
  search_similar_calculator = new SearchSimilarItemExpiryCalculator(hbase_get_item_);
  search_similar_calculator->Init();
}

ItemExpiryCalculator::~ItemExpiryCalculator() {
  delete hbase_get_item_;
  delete content_detect_calculator;
  delete search_similar_calculator;
}

bool ItemExpiryCalculator::IsExpiryItem(const ReqItemInfo& item_info) const {
  // 先获取被查询文章的信息
  reco::RecoItem source_item;
  if (!hbase_get_item_->GetRecoItem(item_info.item_id, &source_item)) {
    LOG(ERROR) << "query failed when query source item id: " << item_info.item_id;
    return false;
  }
  // 从 hbase 中获取文章内容
  ReqItemInfo item_full_info = item_info;
  item_full_info.content = source_item.content();
  bool content_expiry = content_detect_calculator->IsExpiryItem(item_full_info);

  reco::RecoItem similar_item;
  bool search_expiry = search_similar_calculator->IsExpiryItem(source_item, &similar_item);
  if (content_expiry && search_expiry) {
    LOG(INFO) << "both_calculator found expiry item " << item_info.item_id;
    LOG(INFO) << "search_similar_detail: " << item_info.item_id << " title: " << source_item.title()
              << " similar to " << similar_item.identity().item_id() << " title " << similar_item.title();
    return true;
  } else if (content_expiry && !search_expiry) {
    LOG(INFO) << "content_detect_calculator found expiry item " << item_info.item_id;
    return true;
  } else if (!content_expiry && search_expiry) {
    LOG(INFO) << "search_similar_calculator found expiry item " << item_info.item_id;
    LOG(INFO) << "search_similar_detail: " << item_info.item_id << " title: " << source_item.title()
              << " similar to " << similar_item.identity().item_id() << " title " << similar_item.title();
    return true;
  } else {
    return false;
  }
}

}  // namespace item_level
}  // namespace reco
