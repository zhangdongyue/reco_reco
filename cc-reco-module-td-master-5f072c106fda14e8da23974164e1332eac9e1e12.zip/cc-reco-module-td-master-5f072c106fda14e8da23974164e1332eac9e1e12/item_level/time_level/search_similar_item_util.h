#pragma once

#include <string>
#include <vector>

#include "base/common/basic_types.h"
#include "base/common/slice.h"
#include "base/testing/gtest_prod.h"

namespace reco {
namespace item_level {
// 封装了通过使用编辑距离计算两字符串相似度的方法
// 提供了接口，采用分词及相关优化的计算两字符串编辑距离的方法
// 说明：
//  方法运行的基础是对一句话进行分词处理，以单词为基本判断单位，如：
//    "我喜欢吃苹果。" 分词结果是”我“”喜欢”“吃”“苹果”“。”
//    “我爱吃苹果。” 分词结果是“我”“爱”“吃”“苹果”“。”
//  此时可以看到两句话编辑距离为 1 （“喜欢”变成“爱”或者“爱”变成“喜欢”，仅需一次操作）
//  优化：
//    标点符号、句子中的 whitespace 对句意的理解没有任何影响，但其存
//    在会影响最后结果的准确性，所以在计算编辑距离前，需要把句子分词之后产生的标点符
//    号以及 whitespace 去掉。
// 除此之外，还提供了其他的一些接口，包括：
//    计算汉明距离（ simhash ）
//    判断一个字符串中是否含有另一个字符串
//    判断一个文章 title 中是否含有日期
//    判断一个文章 title 是否含有特定的模式
//    判断一个符合特定条件的文章 title 是否含有相应条件下的特定模式
class SearchSimilarItemUtil {
 public:
  // 以分词方式得到两个字符串的相似度
  // 输入：两个字符串分词后的 vector
  // 输出：相似度
  // Sample:
  //  我 喜欢 吃 苹果 。
  //  我 不 爱 吃 苹果 。
  // 此两句话的相似度为 60%
  // 计算原理：编辑距离为 2 。
  //           第一句去掉标点符号后的长度为 4
  //           第二句去掉标点符号后的长度为 5
  //           similarity = 1 - 2 / max (4, 5);
  static double GetSimilarity(const std::vector<std::string>& first_words,
                              const std::vector<std::string>& second_words);

  // 计算汉明距离 (simhash)
  static int32 HammingDistance(int64 hash1, int64 hash2);
  // 判断文章的标题中是否含有日期：x 月 x 日
  static bool ContainsDate(const std::vector<std::string>& words, int* date_in_days);
  // 判断文章标题是否含有特殊 pattern 的词组，pattern 类似于 第 x 批，第 x 期等
  // 如果存在返回统一格式 x Y, 其中 x 为数字， Y 为中文字符
  static bool ContainsPattern(const std::vector<std::string>& words, std::string* result);
  // 在某些特殊的限制条件下，判断文章标题是否含在该限制条件下存在的 pattern
  static bool ContainsPatternWithRestriction(const std::vector<std::string>& words,
                                             const std::string restriction,
                                             std::string* result);
 private:
  // 做规格化处理
  // 处理包括将单词转换为半角、小写
  // 以及删除标点符号及 whitespace
  // whitespace 定义见 base/strings/string_util.h
  // Sample:
  //  这 ！ 是 个 测试 。 。 ！ ！
  // 经过处理后结果为
  //  这 是 个 测试
  static void Normalize(const std::vector<std::string>& from, std::vector<std::string>* to);
  static uint32 CalculateLevenshteinDistance(const std::vector<std::string>& first_vec,
                                             const std::vector<std::string>& second_vec);

  static bool IsYear(const std::string& str);
  static bool IsMonth(const std::string& str, int* month);
  static bool IsDay(const std::string& str, int* day);
  static bool IsNonNegativeInt(const std::string& str);

  // use for test
  FRIEND_TEST(PrivateFunTest, DeleteSpace);
  FRIEND_TEST(PrivateFunTest, ToLowercase);
  FRIEND_TEST(PrivateFunTest, DeletePunctuation);
  FRIEND_TEST(PrivateFunTest, CalculateLevenshteinDistance);
  FRIEND_TEST(PrivateFunTest, IsMonth);
  FRIEND_TEST(PrivateFunTest, IsDay);
  FRIEND_TEST(PrivateFunTest, IsNonNegativeInt);
};
}  // namespace item_level
}  // namespace reco
