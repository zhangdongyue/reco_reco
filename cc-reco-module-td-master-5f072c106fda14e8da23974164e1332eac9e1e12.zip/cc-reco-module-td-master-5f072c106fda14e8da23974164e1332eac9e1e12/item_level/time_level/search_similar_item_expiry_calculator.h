#pragma once

#include <string>
#include <vector>

#include "base/common/basic_types.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/module/item_level/base/base.h"
#include "reco/module/item_level/base/search_util.h"

namespace VLDC {
class MultiStringVLDC;
}  // namespace VLDC

namespace reco {
class HBaseGetItem;

namespace item_level {
// 判断是否是挖分文章的类，通过传入文章 id，判断该文章是否是挖分文章，
// 程序将该文章信息以及相似文章信息返回
// sample usage:
//    reco::HBaseGetItem* hbase = new reco::HbaseGetItem(hbase_ip, hbase_port, table_name, -1);
//    SearchSimilarItemExpiryCalculator item_expiry_calculator(hbase);
//    item_expiry_calculator.Init();
//    uint64 item_id = 6849141766104065381;
//    reco::RecoItem source_item;
//    reco::RecoItem similar_item;
//    bool is_expiry = item_expiry_calculator.IsExpiryItem(item_id, &source_item, &similar_item);
//    if (is_expiry) {
//      // 是挖坟文章，文章信息存在 source_item 中，该文章挖坟的文章信息存在 similar_item 中
//    } else {
//      // 不是挖坟文章
//    }
//
class SearchSimilarItemExpiryCalculator {
 public:
  explicit SearchSimilarItemExpiryCalculator(reco::HBaseGetItem* hbase);
  ~SearchSimilarItemExpiryCalculator();

  // 判断是否是挖分文章的函数
  // 提供两个接口：
  //    传入 源文章 的信息，如果是挖坟文章，相似文章信息保存在 similar_item 中
  //    传入 源文章 的 item_id，如果是挖坟文章，源文章、相似文章信息分别保存在 source_item 和 similar_item 中
  // 函数返回 true 表示是挖坟文章，此时文章信息和相似
  bool IsExpiryItem(const reco::RecoItem& source_item, reco::RecoItem* similar_item);
  bool IsExpiryItem(uint64 item_id, reco::RecoItem* source_item, reco::RecoItem* similar_item);

  // 初始化一些类内部必须的变量
  void Init();
 private:
  // 内部调用函数，判断一篇文章是否是挖坟文章
  bool CheckSingleArticle(const reco::RecoItem& source_item,
                          const std::vector<reco::RecoItem>& alternative_item_list,
                          reco::RecoItem* similar_item);
  // 查找可能的挖坟文章，通过 search_server 查询返回结果
  bool FindAlternativeItem(const std::string& query_title,
                           std::vector<reco::RecoItem>* result);
  // 判断两篇文章是否相似
  // 方法是通过 simhash 距离判断
  // 如果文章 simhash 值不存在，则通过两篇文章的 keyword 和 topic 判断
  enum SimilarResult {
    IsSimilar = 0,
    NotSure = 1,
    NotSimilar = 2,
    Suspected = 3,
  };
  SimilarResult CheckContentIsSimilar(const reco::RecoItem& first, const reco::RecoItem& second,
                                      double* similarity);

  // 获得两篇文章创建时间的时间间隔
  bool CheckTimeInterval(const reco::RecoItem& first, const reco::RecoItem& second, bool* is_latest_article);
  // 更新保留相似度最高的文章
  void UpdateSimilarItem(double similarity, const reco::RecoItem& candidate,
                         double* min_similarity, reco::RecoItem* target);
  // 获取一个文章 title 的分词并去掉其中的空白字符
  void GetWordListWithoutWhitespace(const reco::RecoItem& item, std::vector<std::string>* words);
  // 判断两篇文章是否来自同一地域
  bool CheckRegionNotSame(const reco::RecoItem& first, const reco::RecoItem& second);
  // 判断两篇文章标题是否含有日期，如果含有日期的话，日期是否相同
  bool CheckDateNotSame(const std::vector<std::string>& first, const std::vector<std::string>& second);
  // 判断两篇文章标题是否含有特定模式，如果含有，其模式是否相同
  bool CheckPatternNotSame(const std::vector<std::string>& first, const std::vector<std::string>& second);
  // 对一些满足特殊条件的文章会有特殊的限制，如：分类是 汽车 的文章，一般能够通过判断标题中是否含有价格信息，
  // 价格信息是否相等来判断挖坟与否，所以对于这类文章需要进行特殊判断
  bool CheckPatternWithRestriction(const std::string& first, const std::string& second,
                                   const std::vector<std::string>& first_words,
                                   const std::vector<std::string>& second_words);
  // 判断纯图的新闻是否是挖坟文章
  SimilarResult CheckImageSimilar(const reco::RecoItem& first, const reco::RecoItem& second,
                                  double* similarity);
  // 对不同类型的文章会有不同的判断 content 的标准
  // 函数根据输入的源文章的相关信息，确定阀值
  enum SimhashThreshold {
    kSureNot = 0,
    kFinanceImageThreshold = 1,
    kRegionThreshold = 3,
    kImageThreshold = 6,
    kFinanceThreshold = 7,
    kStrictThreshold = 8,
    kHighQualityThreshold = 10,
    kSuspectedLowThreshold = 12,
    kDefaultThreshold = 14,
    kSuspectedThreshold = 18,
  };
  SimhashThreshold GetSimhashThreshold(const reco::RecoItem& first, const reco::RecoItem& second);

  inline std::string GetItemCategory(const reco::RecoItem& item) {
    if (item.has_raw_item() && item.raw_item().category_size() > 0) {
      return item.raw_item().category(0);
    }
    return "";
  }

  reco::HBaseGetItem* hbase_get_item_;
  SearchUtil* search_util_;
  VLDC::MultiStringVLDC* title_matcher_;
  VLDC::MultiStringVLDC* source_matcher_;
  VLDC::MultiStringVLDC* timeliness_matcher_;
  bool is_init_;
  bool is_title_similar_;
};
}  // namespace item_level
}  // namespace reco
