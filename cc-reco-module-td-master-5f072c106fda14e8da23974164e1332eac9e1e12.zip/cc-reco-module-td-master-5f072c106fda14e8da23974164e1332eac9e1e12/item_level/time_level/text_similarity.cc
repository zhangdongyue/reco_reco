#include "reco/module/item_level/time_level/text_similarity.h"

#include <cmath>
#include <map>
#include <string>
#include <utility>
#include <vector>

#include "base/common/basic_types.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace item_level {
double TextSimilarity::CalculateSimilarity(const std::map<std::string, uint64>& first,
                                           const std::map<std::string, uint64>& second) {
  if (first.size() == 0 || second.size() == 0) {
    return -1.0;
  }

  std::vector<uint64> first_vec;
  std::vector<uint64> second_vec;

  uint64 vec_of_first_module = 0;
  for (auto it = first.begin(); it != first.end(); ++it) {
    first_vec.push_back(it->second);
    if (second.count(it->first)) {
      second_vec.push_back(second.find(it->first)->second);
    } else {
      second_vec.push_back(0);
    }
    vec_of_first_module += (it->second * it->second);
  }

  uint64 vec_of_second_module = 0;
  for (auto it = second.begin(); it != second.end(); ++it) {
    if (first.count(it->first) == 0) {
      first_vec.push_back(0);
      second_vec.push_back(it->second);
    }
    vec_of_second_module += (it->second * it->second);
  }

  uint64 vector_product = 0;
  for (uint64 i = 0; i < first_vec.size(); ++i) {
    vector_product += (first_vec[i] * second_vec[i]);
  }

  double result = vector_product * 1.0 / (sqrt(vec_of_first_module * vec_of_second_module * 1.0));
  return result;
}

// 通过 keyword 计算两个文本的相似度
// 需要从文章信息中获取到各自的 keyword 以及对应的 weight 列表
// 然后才能计算其相似度
// NOTE: 如果两个 item 均没有 keyword , 表示无法计算 keyword 相似度，
//       不能计算意味着函数返回的结果应该不能够影响通过其他条件对文章
//       相似度进行判断，所以返回 1.0 。
//       如果两个 item 有一个没有 keyword 则说明两篇文章极有可能不相似，
//       因为两篇文章拥有的属性都不一样，所以返回一个低值 -1.0 ，不反
//       回 0 是因为可能存在需要特判此种情况，与 0 区分。
double TextSimilarity::GetKeywordSimilarity(const reco::RecoItem& first,
                                            const reco::RecoItem& second) {
  if (!first.has_keyword() && !second.has_keyword()) {
    return 1.0;
  }
  if (!first.has_keyword() || !second.has_keyword()) {
    return -1.0;
  }

  std::map<std::string, uint64> keyword_of_first;
  for (int i = 0; i < first.keyword().feature_size(); ++i) {
    uint64 weight = static_cast<uint64>(first.keyword().feature(i).weight() * 10000);
    keyword_of_first.insert(std::pair<std::string, uint64>(first.keyword().feature(i).literal(), weight));
  }

  std::map<std::string, uint64> keyword_of_second;
  for (int i = 0; i < second.keyword().feature_size(); ++i) {
    uint64 weight = static_cast<uint64>(second.keyword().feature(i).weight() * 10000);
    keyword_of_second.insert(std::pair<std::string, uint64>(second.keyword().feature(i).literal(), weight));
  }

  double result = CalculateSimilarity(keyword_of_first, keyword_of_second);
  return result;
}

// 通过 topic 计算两个文本的相似度
// 需要从文章信息中获取到各自的 topic 以及对应的 weight 列表
// 然后才能计算其相似度
// NOTE: 如果两个 item 均没有 topic , 表示无法计算 topic 相似度，
//       不能计算意味着函数返回的结果应该不能够影响通过其他条件对文章
//       相似度进行判断，所以返回 1.0 。
//       如果两个 item 有一个没有 topic 则说明两篇文章极有可能不相似，
//       因为两篇文章拥有的属性都不一样，所以返回一个低值 -1.0 ，不反
//       回 0 是因为可能存在需要特判此种情况，与 0 区分。
double TextSimilarity::GetTopicSimilarity(const reco::RecoItem& first,
                                          const reco::RecoItem& second) {
  if (!first.has_topic() && !second.has_topic()) {
    return 1.0;
  }
  if (!first.has_topic() || !second.has_topic()) {
    return -1.0;
  }

  std::map<std::string, uint64> topic_of_first;
  for (int i = 0; i < first.topic().feature_size(); ++i) {
    uint64 weight = static_cast<uint64>(first.topic().feature(i).weight() * 10000);
    topic_of_first.insert(std::pair<std::string, uint64>(first.topic().feature(i).literal(), weight));
  }

  std::map<std::string, uint64> topic_of_second;
  for (int i = 0; i < second.topic().feature_size(); ++i) {
    uint64 weight = static_cast<uint64>(second.topic().feature(i).weight() * 10000);
    topic_of_second.insert(std::pair<std::string, uint64>(second.topic().feature(i).literal(), weight));
  }

  double result = CalculateSimilarity(topic_of_first, topic_of_second);
  return result;
}
}  // namespace item_level
}  // namespace reco
