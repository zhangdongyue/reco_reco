#pragma once

#include <string>
#include <map>
#include <vector>
#include <unordered_map>

#include "reco/module/item_level/base/connection_manager.h"
#include "reco/module/item_level/base/connection_manager_r.h"
#include "reco/module/item_level/base/base.h"
#include "ads_index/api/public.h"
#include "base/common/base.h"
#include "base/container/dense_hash_map.h"

namespace reco {
namespace item_level {

// 封装的用于 item level 的 redis 操作类
//
class RedisUtil {
 public:
  RedisUtil();
  RedisUtil(bool read);
  ~RedisUtil();

  // 接口：给定 item 集合，返回对应的 spider data 数据
  void BatchGetItemSpiderData(const std::vector<uint64>& item_ids,
                              std::vector<std::pair<int64, RedisData> >* spider_data_dict);
  // 接口：批量写入 item level 数据
  void BatchWriteItemLevel(const std::vector<ItemLevelInfo>& level_infos);
  // 接口：批量写入 item ctr 数据
  void BatchWriteItemCtr(const std::vector<std::pair<uint64, ItemCtrData> >& item_ctr_vec);

  // 接口：批量写入 item 各维度信息 数据
  void BatchWriteItemStats(const std::vector<std::pair<uint64, ItemStatsData> >& item_ctr_vec);

  // 接口：批量写入 item ctrq 数据
  void BatchWriteItemCtrq(const std::vector<std::pair<uint64, float> >& item_ctrq_vec);
  void BatchGetItemCtrqFromRedis(const std::vector<uint64>& item_ids,
                                 std::unordered_map<uint64, std::unordered_map<std::string, std::string>>* dict);

 private:
  // 内部实现：批量从 redis 获取 spider data 数据
  void BatchGetSpiderDataFromRedis(const std::vector<uint64>& item_ids,
                                   std::unordered_map<uint64, RedisData>* dict);
  void GetItemSpiderData(int thread_id, int32 thread_num, const std::vector<uint64>& item_ids,
                         std::vector<std::pair<int64, RedisData> >* spider_data);
  // 线程写 redis
  void WriteItemLevelRedisThread(const std::vector<ItemLevelInfo>* items,
                                 reco::redis::RedisCli* redis_client, int thread_id);
  // 线程写 redis
  void WriteItemCtrRedisThread(const std::vector<std::pair<uint64, ItemCtrData>>* items,
                               reco::redis::RedisCli* redis_client, int thread_id, bool print_log = false);

  // 线程写 redis
  void WriteItemStatsRedisThread(const std::vector<std::pair<uint64, ItemStatsData>>* items,
                                 reco::redis::RedisCli* redis_client, int thread_id, bool print_log = false);

  // 解析 spider data 数据
  bool ParseSpiderData(uint64 item_id,
                       const std::unordered_map<std::string, std::string>& field_values,
                       RedisData *redis_data) const;
  void WriteItemCtrqRedisThread(const std::vector<std::pair<uint64, float>>* items,
                                reco::redis::RedisCli* redis_client, int thread_id, bool print_log);
 private:
  static const int kRedisBatchSize = 1000;
  static const int kRedisCnt = 3;

  reco::redis::RedisCli* redis_client_;
  reco::redis::RedisCli* slave_redis_client_;
  reco::redis::RedisCli* third_redis_client_;

  DISALLOW_COPY_AND_ASSIGN(RedisUtil);
};
}
}
