#pragma once

#include <string>
#include <vector>
#include <unordered_set>

#include "reco/module/item_level/base/base.h"
#include "reco/bizc/proto/reco_search_server.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/common/base.h"

namespace reco {
namespace item_level {
// not thread safe
//
class SearchUtil {
 public:
  SearchUtil();
  ~SearchUtil();

  // 给定 query 集合，返回查询的文章集合
  void BatchSearch(const std::vector<std::string>& queries,
                   std::vector<searchserver::GeneralSearchResponse>* responses,
                   const std::unordered_set<int>* item_type_set = NULL) const;

  // 给定一个 query ，返回查询的文章集合
  bool QuerySearch(const std::string& query,
                   int32 max_return_num,
                   searchserver::GeneralSearchResponse* response) const;
 private:
  // query 转换成 SearchRequest
  void BatchGenSearchRequests(const std::vector<std::string>& queries,
                              std::vector<searchserver::GeneralSearchRequest>* requests,
                              const std::unordered_set<int>* item_type_set = NULL) const;

  void GenSearchRequest(const std::string& query,
                        int32 max_return_num,
                        searchserver::GeneralSearchRequest* request) const;

 private:
  searchserver::SearchService::Stub* search_service_;
};

}  // namespace item_level
}  // namespace reco
