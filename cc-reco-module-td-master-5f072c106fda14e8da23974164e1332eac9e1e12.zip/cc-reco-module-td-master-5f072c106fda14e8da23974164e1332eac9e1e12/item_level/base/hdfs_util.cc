#include "reco/module/item_level/base/hdfs_util.h"

#include <algorithm>
#include <functional>
#include "base/hdfs/hdfs_file_util.h"
#include "base/hdfs/hdfs_file_stream.h"
#include "base/common/sleep.h"
#include "base/common/logging.h"

namespace hadoop {
DECLARE_string(hadoop_namenode_ip);
DECLARE_int32(hadoop_namenode_port);
}

namespace reco {
namespace item_level {

bool HdfsUtil::GetHdfsLastestPath(const std::string& hdfs_dir, std::string *lastest_path,
                                  const char *done_file) {
  lastest_path->clear();
  std::vector<hadoop::HDFSPathInfo> hdfs_paths;
  if (!hadoop::HDFSListDirectory(hdfs_dir.c_str(), &hdfs_paths)) {
    LOG(ERROR) << "hdfs list dir fail [" << hdfs_dir << "]";
    return false;
  }

  if (hdfs_paths.empty()) {
    LOG(ERROR) << "hdfs dir empty [" << hdfs_dir << "]";
    return false;
  }
  std::vector<std::string> paths;
  for (int i = 0; i < (int)hdfs_paths.size(); ++i) {
    paths.push_back(hdfs_paths[i].name);
  }
  std::sort(paths.begin(), paths.end(), std::greater<std::string>());
  for (int i = 0; i < (int)paths.size(); ++i) {
    std::string done_path = paths[i] + "/" + done_file;
    if (hadoop::HDFSExists(done_path.c_str())) {
      *lastest_path = paths[i];
      break;
    }
  }
  if (lastest_path->empty()) {
    LOG(ERROR) << "lastest update path empty, " << hdfs_dir;
    return false;
  }
  LOG(INFO) << "get lastest path [" << *lastest_path << "]";
  return true;
}

bool HdfsUtil::ReadHdfsFile(const std::string &hdfs_path, std::vector<std::string>* lines) {
  lines->clear();
  hadoop::HDFSFileStream hdfs_in(hadoop::FLAGS_hadoop_namenode_ip.c_str(),
                                 hadoop::FLAGS_hadoop_namenode_port);
  if (!hdfs_in.Open(hdfs_path.c_str(), O_RDONLY)) {
    LOG(ERROR) << "read hdfs file fail [" << hdfs_path << "]";
    return false;
  }
  std::string line;
  while (hdfs_in.ReadLine(&line)) {
    lines->push_back(line);
  }

  LOG(INFO) << "read [" << ", " << lines->size()  << "] line from " << hdfs_path;
  return true;
}
}
}
