#include "reco/module/item_level/base/connection_manager_r.h"

#include <string>
#include <utility>
#include <vector>

#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"

#include "net/rpc_util/rpc_group.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

DEFINE_string(itemlevel_redis_onlineread_ip, "10.3.5.70:6379", "redis server ip");
DEFINE_string(itemlevel_slave_redis_onlineread_ip, "", "redis server ip");
DEFINE_string(itemlevel_third_redis_onlineread_ip, "", "redis server ip");

namespace reco {
namespace item_level {

reco::redis::RedisCli* ConnectionManagerR::redis_cli_ = NULL;
reco::redis::RedisCli* ConnectionManagerR::slave_redis_cli_ = NULL;
reco::redis::RedisCli* ConnectionManagerR::third_redis_cli_ = NULL;

bool ConnectionManagerR::InitConnection() {
  // search server client
  std::vector<std::string> flds;

  // redis
  redis_cli_ = new reco::redis::RedisCli(FLAGS_itemlevel_redis_onlineread_ip);
  CHECK_NOTNULL(redis_cli_);
  // slave redis
  if (!FLAGS_itemlevel_slave_redis_onlineread_ip.empty()) {
    slave_redis_cli_ = new reco::redis::RedisCli(FLAGS_itemlevel_slave_redis_onlineread_ip);
    CHECK_NOTNULL(slave_redis_cli_);
  }
  // third redis
  if (!FLAGS_itemlevel_third_redis_onlineread_ip.empty()) {
    third_redis_cli_ = new reco::redis::RedisCli(FLAGS_itemlevel_third_redis_onlineread_ip);
    CHECK_NOTNULL(third_redis_cli_);
  }

  return true;
}

void ConnectionManagerR::CleanConnection() {
  delete redis_cli_;
  delete slave_redis_cli_;
  delete third_redis_cli_;
}
}  // namespace leafserver
}  // namespace reco
