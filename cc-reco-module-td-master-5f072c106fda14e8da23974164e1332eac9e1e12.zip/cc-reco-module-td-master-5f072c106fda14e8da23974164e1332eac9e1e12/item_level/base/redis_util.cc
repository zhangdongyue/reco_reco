#include "reco/module/item_level/base/redis_util.h"

#include "base/strings/string_number_conversions.h"
#include "base/time/timestamp.h"

namespace reco {
namespace item_level {
DEFINE_int32(redis_record_expire_second, 3600*24, "time interval to inc update item info in seconds.");
DEFINE_int32(write_itemlevel_redis_thread_num, 8, "write redis thread num");
DEFINE_int32(read_redis_thread_num, 100, "read redis thread num");
DEFINE_bool(item_ctrq_print_log, false, "");

RedisUtil::RedisUtil() {
  redis_client_ = ConnectionManager::GetRedisClient();
  CHECK_NOTNULL(redis_client_);
  slave_redis_client_ = NULL;
  if (ConnectionManager::GetSlaveRedisClient() != NULL) {
    slave_redis_client_ = ConnectionManager::GetSlaveRedisClient();
    CHECK_NOTNULL(slave_redis_client_);
  }
  third_redis_client_ = NULL;
  if (ConnectionManager::GetThirdRedisClient() != NULL) {
    third_redis_client_ = ConnectionManager::GetThirdRedisClient();
    CHECK_NOTNULL(third_redis_client_);
  }
}

RedisUtil::RedisUtil(bool read) {
  redis_client_ = ConnectionManagerR::GetRedisClient();
  CHECK_NOTNULL(redis_client_);
  slave_redis_client_ = NULL;
  if (ConnectionManagerR::GetSlaveRedisClient() != NULL) {
    slave_redis_client_ = ConnectionManagerR::GetSlaveRedisClient();
    CHECK_NOTNULL(slave_redis_client_);
  }
  third_redis_client_ = NULL;
  if (ConnectionManagerR::GetThirdRedisClient() != NULL) {
    third_redis_client_ = ConnectionManagerR::GetThirdRedisClient();
    CHECK_NOTNULL(third_redis_client_);
  }
}

RedisUtil::~RedisUtil() {
}

void RedisUtil::GetItemSpiderData(int thread_id, int32 thread_num, const std::vector<uint64>& item_ids,
                                  std::vector<std::pair<int64, RedisData> >* spider_data) {
  RedisData redis_data;
  std::unordered_map<std::string, std::string> field_value_map;
  int count = 0;
  for (int i = thread_id; i < int(item_ids.size()); i += thread_num) {
    uint64 item_id = item_ids[i];
    field_value_map.clear();
    redis_data.reset();
    const std::string& key = base::StringPrintf("%s%lu", kSpiderScoreKeyPrefix, item_id);
    if (!redis_client_->HGetAll(key, &field_value_map)) {
      (*spider_data)[i] = std::make_pair(0, redis_data);
      continue;
    }
    if (ParseSpiderData(item_id, field_value_map, &redis_data)) {
      (*spider_data)[i] = std::make_pair(item_id, redis_data);
    } else {
      (*spider_data)[i] = std::make_pair(0, redis_data);
    }
    count += 1;
  }
  LOG(INFO) << "thread id: " << thread_id
            << " read redis count: " << count
            << " total count: " << item_ids.size();
  return;
}

void RedisUtil::BatchGetItemSpiderData(const std::vector<uint64>& item_ids,
                                       std::vector<std::pair<int64, RedisData> >* spider_data_dict) {
  if (item_ids.empty()) return;
  spider_data_dict->clear();
  spider_data_dict->resize(item_ids.size());

  // 分割到特定大小后请求 redis
  thread::ThreadPool pool(FLAGS_read_redis_thread_num);
  for (int i = 0; i < FLAGS_read_redis_thread_num; ++i) {
    pool.AddTask(NewCallback<RedisUtil, int, int32, const std::vector<uint64>&,
             std::vector<std::pair<int64, RedisData> >*> (this, &RedisUtil::GetItemSpiderData,
             i, FLAGS_read_redis_thread_num,
             item_ids, spider_data_dict));
  }

  pool.JoinAll();
  return;
}

void RedisUtil::BatchWriteItemLevel(const std::vector<ItemLevelInfo>& items) {
  if (items.empty()) return;

  thread::ThreadPool pool(FLAGS_write_itemlevel_redis_thread_num * kRedisCnt);
  for (int i = 0; i < FLAGS_write_itemlevel_redis_thread_num; ++i) {
    pool.AddTask(NewCallback<RedisUtil, const std::vector<ItemLevelInfo>*,reco::redis::RedisCli*,  int>
                 (this, &RedisUtil::WriteItemLevelRedisThread, &items, redis_client_, i));
    pool.AddTask(NewCallback<RedisUtil, const std::vector<ItemLevelInfo>*,reco::redis::RedisCli*,  int>
                 (this, &RedisUtil::WriteItemLevelRedisThread, &items, slave_redis_client_, i));
    pool.AddTask(NewCallback<RedisUtil, const std::vector<ItemLevelInfo>*,reco::redis::RedisCli*,  int>
                 (this, &RedisUtil::WriteItemLevelRedisThread, &items, third_redis_client_, i));
  }
  pool.JoinAll();
}

void RedisUtil::WriteItemLevelRedisThread(const std::vector<ItemLevelInfo>* items,
                                          reco::redis::RedisCli* redis_client, int thread_id) {
  if (redis_client == NULL) return;

  int64 start_timestamp = base::GetTimestamp();

  int count = 0;
  for (size_t i = thread_id; i < items->size(); i += FLAGS_write_itemlevel_redis_thread_num) {
    const ItemLevelInfo& item = items->at(i);
    const std::string& key = base::StringPrintf("%s%lu", kItemRedisKeyPrefix, item.item_id);
    if (item.site_level >= 0) {
      const std::string& val = base::IntToString(item.site_level);
      redis_client->HSet(key, kSiteLevelField, val);
    }
    if (item.time_level >= 0) {
      const std::string& val = base::IntToString(item.time_level);
      redis_client->HSet(key, kTimeLevelField, val);
    }
    if (item.hot_level >= 0) {
      const std::string& val = base::IntToString(item.hot_level);
      redis_client->HSet(key, kHotLevelField, val);
    }
    if (item.sensitive_type >= 0) {
      const std::string& val = base::IntToString(item.sensitive_type);
      redis_client->HSet(key, kSensitiveTypeField, val);
    }
    if (item.spider_score > ItemLevelInfo::kDftVal) {
      const std::string& val = base::DoubleToString(item.spider_score);
      redis_client->HSet(key, kSpiderScoreField, val);
    }
    if (item.predict_ctr > ItemLevelInfo::kDftVal) {
      const std::string& val = base::DoubleToString(item.predict_ctr);
      redis_client->HSet(key, kPredictCtr, val);
    }
    VLOG(2) << "item id: " << item.item_id
            << " site level: " << item.site_level
            << " time level: " << item.time_level
            << " hot level: " << item.hot_level
            << " sensitive type: " << item.sensitive_type
            << " spider score: " << item.spider_score
            << " predict ctr: " << item.predict_ctr;
    ++count;
  }

  int cost_ms = (base::GetTimestamp() - start_timestamp) / 1e3;
  LOG(INFO) << "write redis, thread_id: " << thread_id
            << ", total: " << count
            << ", cost " << cost_ms << " ms.";
}

void RedisUtil::BatchWriteItemCtr(const std::vector<std::pair<uint64, ItemCtrData> >& item_ctr_vec) {
  thread::ThreadPool pool(FLAGS_write_itemlevel_redis_thread_num * kRedisCnt);
  for (int i = 0; i < FLAGS_write_itemlevel_redis_thread_num; ++i) {
    pool.AddTask(NewCallback<RedisUtil, const std::vector<std::pair<uint64, ItemCtrData>>*,
                 reco::redis::RedisCli*, int, bool>
                 (this, &RedisUtil::WriteItemCtrRedisThread, &item_ctr_vec, redis_client_, i, true));
    pool.AddTask(NewCallback<RedisUtil, const std::vector<std::pair<uint64, ItemCtrData>>*,
                 reco::redis::RedisCli*, int, bool>
                 (this, &RedisUtil::WriteItemCtrRedisThread, &item_ctr_vec, slave_redis_client_, i, false));
    pool.AddTask(NewCallback<RedisUtil, const std::vector<std::pair<uint64, ItemCtrData>>*,
                 reco::redis::RedisCli*, int, bool>
                 (this, &RedisUtil::WriteItemCtrRedisThread, &item_ctr_vec, third_redis_client_, i, false));
  }
  pool.JoinAll();
}

void RedisUtil::BatchWriteItemStats(const std::vector<std::pair<uint64, ItemStatsData> >& item_stats_vec) {
  thread::ThreadPool pool(FLAGS_write_itemlevel_redis_thread_num * kRedisCnt);
  for (int i = 0; i < FLAGS_write_itemlevel_redis_thread_num; ++i) {
    pool.AddTask(NewCallback<RedisUtil, const std::vector<std::pair<uint64, ItemStatsData>>*,
                 reco::redis::RedisCli*, int, bool>
                 (this, &RedisUtil::WriteItemStatsRedisThread, &item_stats_vec, redis_client_, i, true));
    pool.AddTask(NewCallback<RedisUtil, const std::vector<std::pair<uint64, ItemStatsData>>*,
                 reco::redis::RedisCli*, int, bool>
                 (this, &RedisUtil::WriteItemStatsRedisThread, &item_stats_vec, slave_redis_client_, i, false));
    pool.AddTask(NewCallback<RedisUtil, const std::vector<std::pair<uint64, ItemStatsData>>*,
                 reco::redis::RedisCli*, int, bool>
                 (this, &RedisUtil::WriteItemStatsRedisThread, &item_stats_vec, third_redis_client_, i, false));
  }
  pool.JoinAll();
}

void RedisUtil::WriteItemStatsRedisThread(const std::vector<std::pair<uint64, ItemStatsData>>* items,
                                          reco::redis::RedisCli* redis_client, int thread_id, bool print_log) {
  if (redis_client == NULL) return;

  long start_t = base::GetTimestamp();

  int count = 0;
  for (int idx = thread_id; idx < (int)items->size(); idx += FLAGS_write_itemlevel_redis_thread_num) {
    uint64 item_id = items->at(idx).first;
    const ItemStatsData& env = items->at(idx).second;
    const std::string& key = base::StringPrintf("%s%lu", kItemRedisKeyPrefix, item_id);
    uint32 show_num = env.total_show;
    uint32 click_num = env.total_click;
    uint64 total_duration = env.total_duration;
    uint32 fav_num = env.total_fav;
    uint32 share_num = env.total_share;
    uint32 like_num = env.total_like;
    uint32 dislike_num = env.total_dislike;
    uint32 avg_duration = 0;
    if (show_num > 0) {
      const std::string& val = base::IntToString(show_num);
      redis_client->HSet(key, kShowField, val);
    }
    if (click_num > 0) {
      avg_duration = std::min(600, (int)(total_duration / click_num));
      const std::string& val = base::IntToString(click_num);
      redis_client->HSet(key, kClickField, val);
      const std::string& duration_val = base::IntToString(avg_duration);
      redis_client->HSet(key, kDurationField, duration_val);
    }
    if (fav_num > 0) {
      const std::string& val = base::IntToString(fav_num);
      redis_client->HSet(key, kFavField, val);
    }
    if (share_num > 0) {
      const std::string& val = base::IntToString(share_num);
      redis_client->HSet(key, kShareField, val);
    }
    if (like_num > 0) {
      const std::string& val = base::IntToString(like_num);
      redis_client->HSet(key, kLikeField, val);
    }
    if (dislike_num > 0) {
      const std::string& val = base::IntToString(dislike_num);
      redis_client->HSet(key, kDisLikeField, val);
    }
    ++count;
    LOG_IF(INFO, print_log) << "write item, " << item_id
                            << ", " << env.total_show
                            << ", " << env.total_click
                            << ", " << avg_duration
                            << ", " << env.total_fav
                            << ", " << env.total_share
                            << ", " << env.total_like
                            << ", " << env.total_dislike;
  }

  int cost_ms = (base::GetTimestamp() - start_t) / 1e3;
  LOG(INFO) << "write redis, thread_id: " << thread_id
            << ", total: " << count
            << ", cost " << cost_ms << " ms.";
}

void RedisUtil::WriteItemCtrRedisThread(const std::vector<std::pair<uint64, ItemCtrData>>* items,
                                       reco::redis::RedisCli* redis_client, int thread_id, bool print_log) {
  if (redis_client == NULL) return;

  long start_t = base::GetTimestamp();

  int count = 0;
  for (int idx = thread_id; idx < (int)items->size(); idx += FLAGS_write_itemlevel_redis_thread_num) {
    uint64 item_id = items->at(idx).first;
    const ItemCtrData& env = items->at(idx).second;
    const std::string& key = base::StringPrintf("%s%lu", kItemRedisKeyPrefix, item_id);
    uint32 show_num = env.total_show;
    uint32 click_num = env.total_click;
    uint64 total_duration = env.total_duration;
    uint32 avg_duration = 0;
    if (show_num > 0) {
      const std::string& val = base::IntToString(show_num);
      redis_client->HSet(key, kShowField, val);
    }
    if (click_num > 0) {
      avg_duration = std::min(600, (int)(total_duration / click_num));
      const std::string& val = base::IntToString(click_num);
      redis_client->HSet(key, kClickField, val);
      const std::string& duration_val = base::IntToString(avg_duration);
      redis_client->HSet(key, kDurationField, duration_val);
    }
    ++count;
    LOG_IF(INFO, print_log) << "write item, " << item_id
                            << ", " << env.total_show
                            << ", " << env.total_click
                            << ", " << avg_duration;
  }

  int cost_ms = (base::GetTimestamp() - start_t) / 1e3;
  LOG(INFO) << "write redis, thread_id: " << thread_id
            << ", total: " << count
            << ", cost " << cost_ms << " ms.";
}

void RedisUtil::BatchWriteItemCtrq(const std::vector<std::pair<uint64, float> >& item_ctrq_vec) {
  thread::ThreadPool pool(FLAGS_write_itemlevel_redis_thread_num * kRedisCnt);
  for (int i = 0; i < FLAGS_write_itemlevel_redis_thread_num; ++i) {
    pool.AddTask(NewCallback<RedisUtil, const std::vector<std::pair<uint64, float>>*,
                 reco::redis::RedisCli*, int, bool>
                 (this, &RedisUtil::WriteItemCtrqRedisThread, &item_ctrq_vec, redis_client_,
                  i, FLAGS_item_ctrq_print_log));
    pool.AddTask(NewCallback<RedisUtil, const std::vector<std::pair<uint64, float>>*,
                 reco::redis::RedisCli*, int, bool>
                 (this, &RedisUtil::WriteItemCtrqRedisThread, &item_ctrq_vec, slave_redis_client_,
                  i, FLAGS_item_ctrq_print_log));
  }
  pool.JoinAll();
}

void RedisUtil::WriteItemCtrqRedisThread(const std::vector<std::pair<uint64, float>>* items,
                                       reco::redis::RedisCli* redis_client, int thread_id, bool print_log) {
  if (redis_client == NULL) return;

  long start_t = base::GetTimestamp();

  int count = 0;
  for (int idx = thread_id; idx < (int)items->size(); idx += FLAGS_write_itemlevel_redis_thread_num) {
    uint64 item_id = items->at(idx).first;
    const float& ctrq = items->at(idx).second;
    const std::string& key = base::StringPrintf("%s%lu", kItemRedisKeyPrefix, item_id);
    const std::string& val = base::DoubleToString(ctrq);
    redis_client->HSet(key, kCtrqField, val);
    ++count;
    LOG_IF(INFO, print_log) << "write item, " << item_id
                            << ", " << ctrq;
  }

  int cost_ms = (base::GetTimestamp() - start_t) / 1e3;
  LOG(INFO) << "write redis, thread_id: " << thread_id
            << ", total: " << count
            << ", cost " << cost_ms << " ms.";
}

void RedisUtil::BatchGetItemCtrqFromRedis(const std::vector<uint64>& item_ids,
                                          std::unordered_map<uint64, std::unordered_map<std::string, std::string>>* dict) {
  std::unordered_map<std::string, std::string> field_value_map;
  for (size_t i = 0; i < item_ids.size(); ++i) {
    uint64 item_id = item_ids[i];
    field_value_map.clear();
    const std::string& key = base::StringPrintf("%s%lu", kItemRedisKeyPrefix, item_id);
    if (!redis_client_->HGetAll(key, &field_value_map)) {
      continue;
    }
    auto find = field_value_map.find(kCtrqField);
    if (find != field_value_map.end()) {
      (*dict)[item_id] = field_value_map;
    }
  }
}

void RedisUtil::BatchGetSpiderDataFromRedis(const std::vector<uint64>& item_ids,
                                            std::unordered_map<uint64, RedisData>* dict) {
  RedisData redis_data;
  std::unordered_map<std::string, std::string> field_value_map;
  for (size_t i = 0; i < item_ids.size(); ++i) {
    uint64 item_id = item_ids[i];
    field_value_map.clear();
    const std::string& key = base::StringPrintf("%s%lu", kSpiderScoreKeyPrefix, item_id);
    if (!redis_client_->HGetAll(key, &field_value_map)) {
      continue;
    }
    if (ParseSpiderData(item_id, field_value_map, &redis_data)) {
      dict->insert(std::make_pair(item_id, redis_data));
    }
  }
}

bool RedisUtil::ParseSpiderData(uint64 item_id,
                                const std::unordered_map<std::string, std::string>& field_values,
                                RedisData *redis_data) const {
  redis_data->reset();
  auto iter = field_values.find(reco::item_level::kSpiderCommentCountField);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &redis_data->spider_data.spider_comment_count) ||
        redis_data->spider_data.spider_comment_count < 0) {
      LOG(ERROR) << "spider comment count format error [" << item_id << ", " << iter->second << "]";
      return false;
    }
  }

  iter = field_values.find(reco::item_level::kSpiderUpCountField);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &redis_data->spider_data.spider_up_count) ||
        redis_data->spider_data.spider_up_count < 0) {
      LOG(ERROR) << "spider up count format error [" << item_id << ", " << iter->second << "]";
      return false;
    }
  }

  iter = field_values.find(reco::item_level::kSpiderDownCountField);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &redis_data->spider_data.spider_down_count) ||
        redis_data->spider_data.spider_down_count < 0) {
      LOG(ERROR) << "spider down count format error [" << item_id << ", " << iter->second << "]";
      return false;
    }
  }

  iter = field_values.find(reco::item_level::kSpiderReadCountField);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &redis_data->spider_data.spider_read_count) ||
        redis_data->spider_data.spider_read_count < 0) {
      LOG(ERROR) << "spider read count format error [" << item_id << ", " << iter->second << "]";
      return false;
    }
  }

  iter = field_values.find(reco::item_level::kSpiderPlayCountField);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &redis_data->spider_data.spider_play_count) ||
        redis_data->spider_data.spider_play_count < 0) {
      LOG(ERROR) << "spider play count format error [" << item_id << ", " << iter->second << "]";
      return false;
    }
  }

  iter = field_values.find(reco::item_level::kSpiderShareCountField);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &redis_data->spider_data.spider_share_count) ||
        redis_data->spider_data.spider_share_count < 0) {
      LOG(ERROR) << "spider share count format error [" << item_id << ", " << iter->second << "]";
      return false;
    }
  }

  iter = field_values.find(reco::item_level::kSpiderFavCountField);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &redis_data->spider_data.spider_fav_count) ||
        redis_data->spider_data.spider_fav_count < 0) {
      LOG(ERROR) << "spider fav count format error [" << item_id << ", " << iter->second << "]";
      return false;
    }
  }
  // click
  iter = field_values.find(reco::item_level::kClickField);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &redis_data->click_data.click_count) ||
        redis_data->click_data.click_count < 0) {
      LOG(ERROR) << "spider click count format error [" << item_id << ", " << iter->second << "]";
      return false;
    }
  }
  // show
  iter = field_values.find(reco::item_level::kShowField);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &redis_data->click_data.show_count) ||
        redis_data->click_data.show_count < 0) {
      LOG(ERROR) << "spider show count format error [" << item_id << ", " << iter->second << "]";
      return false;
    }
  }
  return true;
}
}
}
