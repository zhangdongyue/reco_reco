#pragma once

#include <string>
#include <vector>

#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "net/rpc/rpc.h"

namespace net {
namespace rpc {
class RpcGroup;
}
}

namespace reco {
namespace item_level {

class ConnectionManager {
 public:
  static bool InitConnection();
  static void CleanConnection();

  static net::rpc::RpcGroup* GetSearchServerGroup() {
    return search_rpc_group_;
  }

  static reco::redis::RedisCli* GetRedisClient() {
    return redis_cli_;
  }

  static reco::redis::RedisCli* GetSlaveRedisClient() {
    return slave_redis_cli_;
  }

  static reco::redis::RedisCli* GetThirdRedisClient() {
    return third_redis_cli_;
  }

 private:
  static net::rpc::RpcGroup* search_rpc_group_;
  static reco::redis::RedisCli* redis_cli_;
  static reco::redis::RedisCli* slave_redis_cli_;
  static reco::redis::RedisCli* third_redis_cli_;
};
}
}
