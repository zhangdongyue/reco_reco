#pragma once

namespace reco {
namespace item_level {

const int32 kAuthoritativeSite = 0;
const int32 kProvinceSite = 1;
const int32 kCitySite = 2;
const int32 kVillageSite = 3;
const int32 kStarSite = 4;
const int32 kOther = 100;
const int32 kHotNews = 101;
const int32 kManual = 102;

}
}
