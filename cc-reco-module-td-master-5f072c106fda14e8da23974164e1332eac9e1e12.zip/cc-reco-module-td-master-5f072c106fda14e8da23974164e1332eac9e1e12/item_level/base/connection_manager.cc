#include "reco/module/item_level/base/connection_manager.h"

#include <string>
#include <utility>
#include <vector>

#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"

#include "net/rpc_util/rpc_group.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

DEFINE_string(itemlevel_redis_ip, "10.3.5.70:6379", "redis server ip");
DEFINE_string(itemlevel_slave_redis_ip, "", "redis server ip");
DEFINE_string(itemlevel_third_redis_ip, "", "redis server ip");

DEFINE_string(search_server_ips, "10.99.20.47", "server ips, by ','");
DEFINE_int32(search_server_port, 20009, "search server port");
DEFINE_int32(search_server_timeout, 300, "search server rpc timeout in ms");
DEFINE_int32(search_server_retry_times, 2, "search server rpc retry times");

namespace reco {
namespace item_level {

net::rpc::RpcGroup* ConnectionManager::search_rpc_group_  = NULL;
reco::redis::RedisCli* ConnectionManager::redis_cli_ = NULL;
reco::redis::RedisCli* ConnectionManager::slave_redis_cli_ = NULL;
reco::redis::RedisCli* ConnectionManager::third_redis_cli_ = NULL;

static net::rpc::RpcGroup* SetupConnection(const std::vector<std::string>& ips, int port,
                                           int timeout, int retry) {
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = retry;
  options.timeout = timeout;
  for (int i = 0; i < (int)ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], port, timeout);
    options.servers.push_back(si);
  }

  auto group = new net::rpc::RpcGroup(options);
  CHECK(group->Connect());
  return group;
}

bool ConnectionManager::InitConnection() {
  // search server client
  std::vector<std::string> flds;
  if (!FLAGS_search_server_ips.empty()) {
    base::SplitString(FLAGS_search_server_ips, ",", &flds);
    search_rpc_group_ = SetupConnection(flds,
                                        FLAGS_search_server_port,
                                        FLAGS_search_server_timeout,
                                        FLAGS_search_server_retry_times);
  } else {
    LOG(ERROR) << "[FATAL]: search server ip empty";
  }

  // redis
  redis_cli_ = new reco::redis::RedisCli(FLAGS_itemlevel_redis_ip);
  CHECK_NOTNULL(redis_cli_);
  // slave redis
  if (!FLAGS_itemlevel_slave_redis_ip.empty()) {
    slave_redis_cli_ = new reco::redis::RedisCli(FLAGS_itemlevel_slave_redis_ip);
    CHECK_NOTNULL(slave_redis_cli_);
  }
  // third redis
  if (!FLAGS_itemlevel_third_redis_ip.empty()) {
    third_redis_cli_ = new reco::redis::RedisCli(FLAGS_itemlevel_third_redis_ip);
    CHECK_NOTNULL(third_redis_cli_);
  }

  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());

  return true;
}

void ConnectionManager::CleanConnection() {
  delete redis_cli_;
  delete slave_redis_cli_;
  delete third_redis_cli_;
  delete search_rpc_group_;
}
}  // namespace leafserver
}  // namespace reco
