#include "reco/module/item_level/base/search_util.h"

#include <algorithm>

#include "reco/module/item_level/base/connection_manager.h"
#include "serving_base/utility/timer.h"
#include "base/common/sleep.h"
#include "nlp/common/nlp_util.h"
#include "net/rpc_util/rpc_group.h"

namespace reco {
namespace item_level {

DEFINE_int32(max_search_cocurrency, 4, "批量请求 search server 的并发数");

SearchUtil::SearchUtil() {
  search_service_ = new searchserver::SearchService::Stub(ConnectionManager::GetSearchServerGroup());
}

SearchUtil::~SearchUtil() {
  delete search_service_;
}

void SearchUtil::BatchSearch(const std::vector<std::string>& queries,
                             std::vector<searchserver::GeneralSearchResponse>* responses,
                             const std::unordered_set<int>* item_type_set) const {
  responses->clear();

  // query 转换成 SearchRequest
  std::vector<searchserver::GeneralSearchRequest> requests;
  BatchGenSearchRequests(queries, &requests, item_type_set);

  if (requests.empty()) return;

  // 多线程请求 user server，获取结果
  responses->resize(requests.size());
  std::vector<net::rpc::RpcClientController*> controllers(requests.size());
  for (size_t i = 0; i < requests.size(); ++i) {
    controllers[i] = new net::rpc::RpcClientController();
  }

  ::serving_base::Timer timer;
  timer.Start();
  int start_idx = 0;
  int end_idx = std::min(start_idx + FLAGS_max_search_cocurrency, (int)requests.size());
  while (start_idx < (int)requests.size()) {
    for (int i = start_idx; i < end_idx; ++i) {
      CHECK_GT(requests[i].query_size(), 0);
      search_service_->GeneralSearch(controllers[i], &(requests[i]), &(responses->at(i)), NULL);
    }

    // 等一个，其他的轮询
    controllers[start_idx]->Wait();
    while (true) {
      int finish_num = 0;
      for (int i = start_idx; i < end_idx; ++i) {
        if (controllers[i]->IsCompleted()) {
          ++finish_num;
        } else {
          break;
        }
      }
      if (finish_num == end_idx - start_idx) {
        break;
      } else {
        base::SleepForMilliseconds(5);
      }
    }
    for (int i = start_idx; i < end_idx; ++i) {
      if (controllers[i]->status() != stumy::RpcController::kOk) {
        LOG(ERROR) << "general search failed, " << controllers[i]->error_text();
        continue;
      }
      if (!(*responses)[i].success() || (*responses)[i].result_size() == 0) {
        std::string debug_info;
        for (int j = 0; j < requests[i].query_size(); ++j) {
          debug_info += requests[i].query(j);
        }
        LOG(WARNING) << "search with empty result for queries: " << debug_info;
        continue;
      }
    }
    start_idx = end_idx;
    end_idx = std::min(start_idx + FLAGS_max_search_cocurrency, (int)requests.size());
  }

  for (size_t i = 0; i < controllers.size(); ++i) {
    delete controllers[i];
  }

  double total_time = timer.Stop();
  LOG(INFO) << "done hot news search, search num: " << queries.size()
            << ", total time: " << total_time;
}

// 给定一个 query ，返回查询的文章集合
bool SearchUtil::QuerySearch(const std::string& query,
                             int32 max_return_num,
                             searchserver::GeneralSearchResponse* response) const {
  searchserver::GeneralSearchRequest request;
  GenSearchRequest(query, max_return_num, &request);
  net::rpc::RpcClientController rpc;
  search_service_->GeneralSearch(&rpc, &request, response, NULL);
  rpc.Wait();

  if (rpc.status() != net::rpc::RpcClientController::kOk || !response->success()) {
    LOG(ERROR) << "general search failed, rpc msg: " << rpc.error_text();
    return false;
  }

  return true;
}


void SearchUtil::BatchGenSearchRequests(const std::vector<std::string>& queries,
                                        std::vector<searchserver::GeneralSearchRequest>* requests,
                                        const std::unordered_set<int>* item_type_set) const {
  requests->clear();
  if (queries.empty()) return;

  static const int kQryNumPerRequest = 1;
  requests->reserve(queries.size() / kQryNumPerRequest + 1);

  static const int kMaxReturnNum = 2000;
  searchserver::GeneralSearchRequest base_request;
  base_request.set_result_num(kMaxReturnNum);
  base_request.set_dedup_method(reco::kNoDedup);
  base_request.set_sort_method(reco::kRelevantSort);
  base_request.set_only_high_relevant(true);
  base_request.set_only_reco_index(true);
  base_request.set_sort_method(kRelevantSort);
  if (item_type_set != NULL && !item_type_set->empty()) {
    for (auto iter = item_type_set->begin(); iter != item_type_set->end(); ++iter) {
      base_request.add_item_type(reco::ItemType(*iter));
    }
  }

  for (size_t i = 0; i < queries.size(); ++i) {
    if (requests->empty()
        || requests->back().query_size() >= kQryNumPerRequest) {
      requests->push_back(base_request);
    }
    requests->back().add_query(queries[i]);
  }
}

void SearchUtil::GenSearchRequest(const std::string& query,
                                  int32 max_return_num,
                                  searchserver::GeneralSearchRequest* request) const {
  request->add_query(query);
  request->set_result_num(max_return_num);
  request->set_dedup_method(reco::kNoDedup);
  request->set_sort_method(reco::kRelevantSort);
  request->set_only_high_relevant(true);
  request->set_only_reco_index(false);
}
}
}
