#pragma once
#include <string>
#include <vector>
#include "base/time/time.h"

namespace reco {
namespace item_level {

// 封装的 hdfs 操作类
class HdfsUtil {
 public:
  // 指定文件夹，获取里面最新的文件
  static bool GetHdfsLastestPath(const std::string& hdfs_dir, std::string *lastest_path,
                                 const char *done_file = "done");
  // 读取 hdfs 文件
  static bool ReadHdfsFile(const std::string& hdfs_path, std::vector<std::string>* lines);

 private:
  HdfsUtil() {}
  ~HdfsUtil() {}
};
}
}
