#pragma once

#include <string>
#include <vector>
#include <set>

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/common/item_level_define.h"

#include "base/strings/string_printf.h"

#include "base/time/time.h"
#include "base/common/base.h"
#include "base/common/basic_types.h"

namespace reco {
namespace item_level {

static const int kDftVal = -10000;

struct DynamicInfo {
  int wilson_ctr;
  int time;
  DynamicInfo() {
    reset();
  }
  void reset() {
    wilson_ctr = 0;
    time = 0;
  }
};

struct ClickData {
  int click_count;
  int show_count;
  ClickData() {
    reset();
  }
  void reset() {
    click_count = 0;
    show_count = 0;
  }
};

struct TimeData {
  // 热门性
  int hot_level;
  // 时效性
  int time_level;
  // 站点权威性
  int site_level;
  // 文章敏感类型
  int sensitive_type;
  // 爬虫抓取的外站得分
  float spider_score;
  void reset() {
    hot_level = kDftVal;
    time_level = kDftVal;
    site_level = kDftVal;
    sensitive_type = kDftVal;
    spider_score = kDftVal;
  }
};

struct SpiderData {
  int spider_comment_count;
  int spider_up_count;
  int spider_down_count;
  int spider_read_count;
  int spider_play_count;
  int spider_share_count;
  int spider_fav_count;
  SpiderData() {
    reset();
  }
  void reset() {
    spider_comment_count = 0;
    spider_up_count = 0;
    spider_down_count = 0;
    spider_read_count = 0;
    spider_play_count = 0;
    spider_share_count = 0;
    spider_fav_count = 0;
  }
};

struct RedisData {
  ClickData click_data;
  SpiderData spider_data;
  RedisData() {
    click_data.reset();
    spider_data.reset();
  }
  void reset() {
    click_data.reset();
    spider_data.reset();
  }
};

struct ReqItemInfo {
  uint64 item_id;
  int32 image_count;
  bool has_reviewed;
  reco::ItemType item_type;
  base::Time  publish_time;
  std::string category;
  std::string snd_category;
  std::string source;
  std::string producer;
  std::string content;
  std::vector<int64> channels;
  std::vector<std::string> title_unigrams;
  const std::set<uint64>* item_sim_vec;

  // ctr 预测特征
  std::string title;
  std::string bititle;
  std::string source_media;
  std::string tags;
  std::string categories;
  int64 pub_time;

  void reset() {
    has_reviewed = false;
    channels.clear();
    title_unigrams.clear();
    title = "";
    bititle = "";
    source_media = "";
    tags = "";
    categories = "";
    pub_time = -1;
    item_type = reco::kNone;
  }
};

// item level 相关信息
struct ItemLevelInfo {
  uint64 item_id;
  // 热门性
  int hot_level;
  // 时效性
  int time_level;
  // 站点权威性
  int site_level;
  // 文章敏感类型
  int sensitive_type;
  // 爬虫抓取的外站得分
  float spider_score;
  // 预估 ctr
  int predict_ctr;
  // 上一次的 show
  int last_show;
  static const int kDftVal = -10000;

  ItemLevelInfo() :
      item_id(kDftVal), hot_level(kDftVal), time_level(kDftVal),
      site_level(kDftVal), sensitive_type(kDftVal), spider_score(kDftVal), predict_ctr(kDftVal),
      last_show(kDftVal) { }

  void reset() {
    item_id = kDftVal;
    hot_level = kDftVal;
    time_level = kDftVal;
    site_level = kDftVal;
    sensitive_type = kDftVal;
    spider_score = kDftVal;
    predict_ctr = kDftVal;
    last_show = kDftVal;
  }

  std::string toString() const {
    return base::StringPrintf(
        "itemid: %lu, timelevel: %d, hot_level: %d, "
        "site_level:%d, sensitive_type: %d, spider_score: %f, predict_ctr: %d",
        item_id, time_level, hot_level, site_level, sensitive_type, spider_score, predict_ctr);
  }
};

struct ItemCtrData {
  // 汇总的 show / click / duration
  uint32 total_show;
  uint32 total_click;
  uint64 total_duration;
  // 最近更新时间
  base::Time recent_update_time;

  ItemCtrData() : total_show(0), total_click(0), total_duration(0) {
    recent_update_time = base::Time::Now();
  }
};

struct ItemStatsData {
  // 汇总的 show / click / duration
  uint32 total_show;
  uint32 total_click;
  uint64 total_duration;
  // fav share dislike like
  uint32 total_fav;
  uint32 total_share;
  uint32 total_dislike;
  uint32 total_like;
  // 最近更新时间
  base::Time recent_update_time;

  ItemStatsData() : total_show(0), total_click(0), total_duration(0),
                    total_fav(0), total_share(0), total_dislike(0), total_like(0) {
    recent_update_time = base::Time::Now();
  }
};


// 热门数据插入到数据库中
struct HotItemInDataBase {
  uint64 item_id;
  // 文章类型
  ItemType item_type;
  // 文章生产者
  std::string producer;
  // 发布时间 例如2000-01-01 00:00:00
  std::string publish_time;
  // 最近修改时间 例如2000-01-01 00:00:00
  std::string last_modify_time;
  // 统计的hour 例如2016-08-15 08
  std::string stat_hour;
  // 文章在版时间 精确到天
  std::string last_modify_day;
  // 标题
  std::string title;
  // 源
  std::string source;
  // 一级类别
  std::string category;
  // 二级类别
  std::string snd_category;
  // 相似文章条数
  int32 sim_item_count;
  // 热度分
  int32 hot_level;
  // 关联item
  uint64 represent_item_id;
  bool operator == (const HotItemInDataBase& rhs) const {
    return (rhs.item_id == item_id && rhs.stat_hour == stat_hour && rhs.category == category
            && rhs.snd_category == snd_category &&rhs.sim_item_count == sim_item_count
            && rhs.hot_level == hot_level && rhs.represent_item_id == represent_item_id);
  }
};

}
}
