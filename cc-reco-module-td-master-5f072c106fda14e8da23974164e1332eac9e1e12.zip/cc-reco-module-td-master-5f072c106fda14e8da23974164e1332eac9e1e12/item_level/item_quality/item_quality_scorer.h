#pragma once

#include <string>
#include <vector>
#include <fstream>
#include <unordered_map>
#include <utility>

#include "boost/unordered_map.hpp"
#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/cppconn/resultset.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/statement.h"

#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/time/timestamp.h"
#include "base/process/process_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "reco/module/item_level/base/base.h"
#include "reco/bizc/proto/reco_log.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/base/kafka_c/api/partition_consumer.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/bizc/reco_index/dynamic_dict.h"

namespace reco {
namespace item_level {


struct CommonStats {
  CommonStats() {
    reset();
  }
  int click_num;
  int share_num;
  int cmt_num;
  int fav_num;
  int disLike_num;
  int like_num;
  int agree_num;
  int disAgree_num;
  int64 duration_sum;
  int64 content_len_sum;
  std::string title;
  std::string category;
  std::string last_update_time;
  void reset() {
    click_num = 0;
    share_num = 0;
    cmt_num = 0;
    fav_num = 0;
    disLike_num = 0;
    like_num = 0;
    agree_num = 0;
    disAgree_num = 0;
    duration_sum = 0;
    content_len_sum = 0;
    title = "";
    category = "";
    last_update_time = "";
  }
};


struct ActionStats {
  ActionStats() {
    reset();
  }
  CommonStats common_stats;
  uint64 parent_id;
  int item_type_id;
  void reset() {
    parent_id = 0;
    item_type_id = 0;
  }
};

struct ActionClusterStats {
  ActionClusterStats() {
    reset();
  }
  CommonStats common_stats;
  int cluster_size;
  double quality_score;
  std::string item_type;
  void reset() {
    cluster_size = 0;
    quality_score = 0;
    item_type = "";
  }
};

struct ActionClusterScore {
  ActionClusterScore();
  double click_score;
  double share_score;
  double cmt_score;
  double fav_score;
  double disLike_score;
  double like_score;
  double disAgree_score;
  double agree_score;
  double duration_score;
  double average_duration;
  double content_len_score;
  double quality_score;
  double quality_score_test;
  int cluster_size;
  std::string title;
  std::string item_type;
  std::string category;
  std::string last_update_time;
  int compare_flag;
  void reset() {
    click_score = 0;
    share_score = 0;
    cmt_score = 0;
    fav_score = 0;
    disLike_score = 0;
    like_score = 0;
    disAgree_score = 0;
    agree_score = 0;
    duration_score = 0;
    average_duration = 0;
    content_len_score = 0;
    quality_score = 0;
    quality_score_test = 0;
    cluster_size = 0;
    title = "";
    item_type = "";
    category = "";
    last_update_time = "";
    compare_flag = 1;
  }
};

struct ActionCategoryScore {
  ActionCategoryScore();
  std::vector<std::pair<uint64, reco::item_level::ActionClusterScore> > score_vec;
  std::vector<double> thresh_vec;
  void reset() {
    score_vec.clear();
    thresh_vec.clear();
  }
};


enum CompareFlag {
  kClickFlag = 1,
  kShareFlag = 2,
  kCmtFlag = 3,
  kFavFlag = 4,
  kDisLikeFlag = 5,
  kLikeFlag = 6,
  kDisAgreeFlag = 7,
  kAgreeFlag = 8,
  kDurationFlag = 9,
  kContentLenFlag = 10,
  kQualityFlag = 11,
  kQualityFlagTest = 12,
};


class ItemQualityScorer {
 public:
  ItemQualityScorer();
  ~ItemQualityScorer();


  void Start();
  void Stop();

 private:
  // init jobs
  void InitItemType();
  bool InitData();
  bool InitHbase();
  bool InitMysql();
  bool InitRedis();

  // 从磁盘中 load 已经积累的数据
  // 该积累的数据与 kafka 的 offset 文件必须配套，否则会造成数据不一致
  void LoadGlobalDataFromDisk();

  // 从 kafka action 队列获取用户行为数据
  void GetRecoActionLog(int partition);
  // 根据不同的行为类型累加统计数据
  void AddAction(const uint64 &item_id, reco::log::ActionLog &action_log);
  // 新增的统计数据累计到全局
  void MergeGlobalData();
  // 定时循环更新积累的数据到磁盘中
  void LoopUpdateStats();
  // dump 数据到磁盘
  void WriteStatsToDisk();
  // dump quality score
  void WriteGroupStatsToDisk();
  // write item quality to redis
  void WriteStatsToRedis(const boost::unordered_map<uint64, ActionStats>& stats_dict);
  void WriteRedis(reco::redis::RedisCli* client, const std::vector<uint64>& items) const;
  // 线程写 redis
  void WriteRedisThread(const std::vector<uint64>* items, int thread_id);

  bool GetParentIDLocal(const uint64 &item_id, uint64 *parent_id) const;
  bool GetMoreAttributes(const uint64 &item_id, reco::item_level::ActionStats& action_stats);
  void GetParentIdAndItemType(const uint64 &item_id, uint64* parent_id, int* item_type_id);
  bool GetQualityLevel(const uint64 &parent_id, int *quality_level) const;
  // get itemtype_name with id
  std::string GetItemTypeStr(int item_type_id);
  // compare func
  static bool Compare(const std::pair<uint64, reco::item_level::ActionClusterScore>& a,
                      const std::pair<uint64, reco::item_level::ActionClusterScore>& b);
  static bool CompareGreater(const std::pair<uint64, reco::item_level::ActionClusterScore>& a,
                             const std::pair<uint64, reco::item_level::ActionClusterScore>& b);

  // add the quality score to group_dict_
  void AddStatsByGroup(const uint64 &parent_id, reco::item_level::ActionClusterStats &action_stats);
  // cluster the item_id with the same parent_id
  void Cluster(int cluster_mode);
  // generate item quality score at cluster level
  void GenerateScore(boost::unordered_map<uint64, reco::item_level::ActionClusterStats>::iterator group_iter);
  // generate the threshhold
  void GenerateThreshScore();
  // run calculate item quality score
  void RunScore();

  static const char* kGlobalActionDataStoreFile;
  static const char* kActionStatsOutfile;
  static const char* kItemQualityScoreDict;
  static const char* kItemQualityScoreThresh;
  static const int kDictRehashSize = 1000000;
  static const int kVecReserveSize = 1000000;
  static const int kRedisBatchGetRecordNum = 1000;
  static const int kRetryTimes = 2;
  static const int kGlobalMode = 1;
  static const int kAccMode = 2;


  base::Time startup_time_;
  thread::Mutex mutex_;
  std::atomic<bool>* running_;
  thread::ThreadPool* thread_pool_;
  reco::HBaseGetItem* hbase_get_item_;
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  reco::redis::RedisCli* redis_client_;
  reco::redis::RedisCli* slave_redis_client_;
  reco::redis::RedisCli* third_redis_client_;

  // 用于新增数据累计的 dict
  boost::unordered_map<uint64, reco::item_level::ActionStats> acc_dict_;

  // 全量累计数据 global dict
  boost::unordered_map<uint64, reco::item_level::ActionStats> global_dict_;

  // 存放 item_type_id 到 name 映射
  boost::unordered_map<int, std::string> item_type_;

  // 全量累计数据 cluster dict
  boost::unordered_map<uint64, reco::item_level::ActionClusterStats> group_dict_;

  // key:item_id, val:parent_id;
  boost::unordered_map<uint64, uint64> parent_map_;

  // 相同 parent_id-itemtype 去重，缓存
  serving_base::ExpiryMap<uint64, std::string>* cache_parent_;

  // score vector
  boost::unordered_map<uint64, reco::item_level::ActionClusterScore> score_dict_;

  // score vector
  std::vector<std::pair<uint64, reco::item_level::ActionClusterScore> > score_vec_;
  // 按照类别分别统计
  boost::unordered_map<std::string, reco::item_level::ActionCategoryScore> quality_category_score_map_;
};

}  // namespace item_level
}  // namespace reco
