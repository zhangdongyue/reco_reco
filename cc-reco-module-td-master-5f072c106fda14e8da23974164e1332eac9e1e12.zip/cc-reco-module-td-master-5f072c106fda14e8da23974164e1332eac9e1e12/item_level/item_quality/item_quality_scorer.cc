#include <utility>
#include <unordered_map>
#include <algorithm>

#include "serving_base/utility/time_helper.h"
#include "net/counter/export.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_util.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/utf_string_conversions.h"
#include "reco/module/item_level/base/connection_manager.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/doc_server_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/module/item_level/item_quality/item_quality_scorer.h"

#define max(a, b) ((a) > (b) ? (a) : (b))

namespace reco {
namespace item_level {

// kafka config
DEFINE_int32(partition_num, 9, "");
DEFINE_string(kafka_brokers, "", "必须外部指定");
DEFINE_string(kafka_action_topic_name, "", "action log topic name");
DEFINE_int32(kafka_consume_offset, -2, "kafka consume offset");
DEFINE_int32(kafka_backtrack_hours, 24 * 7, "kafka backtrack hours");
DEFINE_string(kafka_offset_store_path, "../kafka_offset", "kafka offset data path");
DEFINE_int32(write_quality_redis_thread_num, 8, "write redis thread num");

// redis config
DEFINE_int32(redis_record_expire_seconds, 3600*24, "time interval to inc update item info in seconds.");
DEFINE_int32(update_stats_redis_seconds, 600, "time interval to update redis data in seconds.");
// DEFINE_bool(sync_stats_from_redis, false, "if sync stats from redis");

// hbase config
DEFINE_string(hbase_ip, "10.181.169.19", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table, "tb_reco_item", "hbase table");
//  DEFINE_string(data_dir, "", "the store path action stats data");

// mysql config
DEFINE_string(db_host, "tcp://10.182.2.62:3306", "dbhost");
DEFINE_string(db_user, "recodev", "db user");
DEFINE_string(db_passwd, "tkDn19DHeVZkNA", "db passwd");
DEFINE_string(schema, "reco", "shcema");


// store config
DEFINE_int32(store_stats_disk_seconds, 3600, "time interval to write stats to disk in seconds.");
DEFINE_string(store_stats_disk_dir, "../dump_data", "item stats data path");
DEFINE_int32(store_stats_expire_days, 30, "item stats expire days");
DEFINE_string(data_dir, "../data", "item stats data path");
DEFINE_int32(generate_thresh_interval_second, 600, "time interval to write stats to disk in seconds.");

// counter
DEFINE_int64_counter(item_level, parse_action_log_failed, 0, "解析行为日志");

// parament config
DEFINE_int32(cmp_flag, 1, "the compare flag of action_stats, default with the click");
DEFINE_int32(act_weight, 10, "the action_score weight");
DEFINE_double(duration_weight_para_a, 2, "the duration_score weight para A");
DEFINE_double(duration_weight_para_b, 0.2, "the duration_score weight para B");
DEFINE_int32(duration_weight_para_c, 10000, "the duration_score weight para C");
DEFINE_int32(duration_ceiling, 5, "the highest value of duration_score");

DEFINE_double(thresh_high, 0.1, "the thresh high, ratio");
DEFINE_double(thresh_mid_high, 0.2, "the thresh mid high ratio");
DEFINE_double(thresh_mid_low, 0.8, "the thresh mid low ratio");
DEFINE_double(thresh_low, 0.9, "the thresh low ratio");


DEFINE_string(category_config, "娱乐#未定义", "the toplevel category config string, category split by #");

const char* ItemQualityScorer::kActionStatsOutfile = "action_stats_cluster.txt";
const char* ItemQualityScorer::kItemQualityScoreDict = "item_quality_score.dic";
const char* ItemQualityScorer::kItemQualityScoreThresh = "item_quality_score.thresh";
const char* ItemQualityScorer::kGlobalActionDataStoreFile = "action_data.txt";

ItemQualityScorer::ItemQualityScorer() {
  InitRedis();
  InitMysql();
  InitHbase();
  InitData();
}

ActionClusterScore::ActionClusterScore() {
  reset();
  compare_flag = FLAGS_cmp_flag;
}

ActionCategoryScore::ActionCategoryScore() {
  reset();
}

bool ItemQualityScorer::InitData() {
  InitItemType();
  acc_dict_.rehash(kDictRehashSize);
  global_dict_.rehash(kDictRehashSize);
  group_dict_.rehash(kDictRehashSize);
  score_vec_.reserve(kVecReserveSize);
  score_dict_.rehash(kDictRehashSize);
  cache_parent_ = new serving_base::ExpiryMap<uint64, std::string>(3600 * 12);
  LoadGlobalDataFromDisk();
  return true;
}

bool ItemQualityScorer::InitRedis() {
  redis_client_ = ConnectionManager::GetRedisClient();
  CHECK_NOTNULL(redis_client_);
  slave_redis_client_ = NULL;
  if (ConnectionManager::GetSlaveRedisClient() != NULL) {
    slave_redis_client_ = ConnectionManager::GetSlaveRedisClient();
    CHECK_NOTNULL(slave_redis_client_);
  }
  third_redis_client_ = NULL;
  if (ConnectionManager::GetThirdRedisClient() != NULL) {
    third_redis_client_ = ConnectionManager::GetThirdRedisClient();
    CHECK_NOTNULL(third_redis_client_);
  }
  return true;
}

bool ItemQualityScorer::InitHbase() {
  hbase_get_item_ = new reco::HBaseGetItem(FLAGS_hbase_table, -1);
  CHECK_NOTNULL(hbase_get_item_);
  return true;
}

bool ItemQualityScorer::InitMysql() {
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();
  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
  return true;
}

void ItemQualityScorer::InitItemType() {
  // consist with the itemType defined in proto.
  item_type_[0] = "kNews";
  item_type_[1] = "kReading";
  item_type_[2] = "kPictrue";
  item_type_[3] = "kHumor";
  item_type_[4] = "kPictureNews";
  item_type_[5] = "kGossip";
  item_type_[6] = "kAudio";
  item_type_[7] = "kSiteNav";
  item_type_[8] = "kAD";
  item_type_[9] = "kNovel";
  item_type_[10] = "kStarCard";
  item_type_[11] = "kStarCardSchedule";
  item_type_[12] = "kSportLiveCard";
  item_type_[13] = "kTopicCard";
  item_type_[14] = "kStockIndexCard";
  item_type_[15] = "kWeMediaCard";
  item_type_[30] = "kPureVideo";
  item_type_[50] = "kMarketing";
  item_type_[100] = "kSpecial";
  item_type_[255] = "kNone";
}

ItemQualityScorer::~ItemQualityScorer() {
  Stop();
}

void ItemQualityScorer::Stop() {
  if (running_) {
    thread_pool_->JoinAll();
  }
  running_ = false;
  delete hbase_get_item_;
  delete db_manager_;
  delete cache_parent_;
}

void ItemQualityScorer::LoadGlobalDataFromDisk() {
  base::FilePath root_dir(FLAGS_data_dir);
  base::FilePath store_file = root_dir.Append(kGlobalActionDataStoreFile);
  std::vector<std::string> lines;

  if (!base::file_util::ReadFileToLines(store_file, &lines)) {
    LOG(WARNING) << "global data store file does not exist, " << store_file.ToString();
    return;
  }

  int64 start_t = base::GetTimestamp();
  LOG(INFO) << "begin to load global data from disk, total num " << lines.size();

  base::Time curr_time = base::Time::Now();
  std::string str_curr_time;
  curr_time.ToStringInSeconds(&str_curr_time);
  base::Time expire_time = curr_time - base::TimeDelta::FromDays(FLAGS_store_stats_expire_days);
  std::string str_expire_time;
  expire_time.ToStringInSeconds(&str_expire_time);
  ActionStats env;
  uint64 item_id;
  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size();++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 16u) {
      LOG(WARNING) << "error flds num, when load global data from disk " << lines[i].size();
      continue;
    }
    // parse
    CHECK(base::StringToUint64(flds[0], &item_id));
    CHECK(base::StringToUint64(flds[1], &env.parent_id));
    CHECK(base::StringToInt(flds[2], &env.common_stats.click_num));
    CHECK(base::StringToInt(flds[3], &env.common_stats.share_num));
    CHECK(base::StringToInt(flds[4], &env.common_stats.cmt_num));
    CHECK(base::StringToInt(flds[5], &env.common_stats.fav_num));
    CHECK(base::StringToInt(flds[6], &env.common_stats.disLike_num));
    CHECK(base::StringToInt(flds[7], &env.common_stats.like_num));
    CHECK(base::StringToInt(flds[8], &env.common_stats.agree_num));
    CHECK(base::StringToInt(flds[9], &env.common_stats.disAgree_num));
    CHECK(base::StringToInt64(flds[10], &env.common_stats.duration_sum));
    CHECK(base::StringToInt64(flds[11], &env.common_stats.content_len_sum));
    CHECK(base::StringToInt(flds[12], &env.item_type_id));
    env.common_stats.title = flds[13];
    env.common_stats.category = flds[14];
    env.common_stats.last_update_time = flds[15];


    // 太久没更新的数据不要了，重新累计
    if (env.common_stats.last_update_time < str_expire_time) continue;
    global_dict_.insert(std::make_pair(item_id, env));
    parent_map_.insert(std::make_pair(item_id, env.parent_id));
  }

  Cluster(kGlobalMode);
  // 生成阈值
  GenerateThreshScore();
  // item_quality_score 分值排序日志写入磁盘
  WriteGroupStatsToDisk();
  // item_quality_score 结果写入 redis
  WriteStatsToRedis(global_dict_);

  LOG(INFO) << "succ to load global data from disk, total num " << global_dict_.size()
            << ",  cost " << static_cast<int>((base::GetTimestamp() - start_t) / 1e3) << " ms.";
}

void ItemQualityScorer::Start() {
  startup_time_ = base::Time::Now();
  // joiner thread-safe
  running_ = new std::atomic<bool>(true);
  thread_pool_ = new thread::ThreadPool(FLAGS_partition_num * 2 + 1);
  LOG(INFO) << "ItemQualityScorer starting...";

  // action log offset
  for (int idx = 0; idx < FLAGS_partition_num; ++idx) {
    thread_pool_->AddTask(NewCallback(this, &ItemQualityScorer::GetRecoActionLog, idx));
  }

  thread_pool_->AddTask(NewCallback(this, &ItemQualityScorer::LoopUpdateStats));
}

void ItemQualityScorer::GetRecoActionLog(int partition) {
  reco::kafka::PartitionConsumer consumer;

  CHECK(consumer.Connect(FLAGS_kafka_brokers,
                          FLAGS_kafka_action_topic_name, partition)) << "action consumer connect failed.";
  consumer.ResetOffset(FLAGS_kafka_consume_offset);

  // 过滤太久的行为统计
  base::Time expire_time = startup_time_ - base::TimeDelta::FromHours(FLAGS_kafka_backtrack_hours);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  LOG(INFO) << "start_to_get_action_log";

  int fnum = 0;
  uint64 addnum = 0;
  uint64 item_id;
  int64 offset = 0;
  std::string messages;
  reco::log::ActionLog action_log;
  while (running_->load()) {
    if (addnum % 100000 == 0) {
      LOG(INFO) << "partition " << partition << " fetch " << addnum
                << " action, uniq item num: " << acc_dict_.size()
                << ", offset: " << offset;
    }
    if (consumer.Fetch(2000, &messages, &offset)) {
      if (!action_log.ParseFromString(messages)) {
        LOG(WARNING) << "parse action log failed";
        COUNTERS_item_level__parse_action_log_failed.Increase(1);
        continue;
      }
      if (action_log.timestamp() < expire_timestamp ) continue;

      // userid = 0 是测试用户，要过滤掉
      if (action_log.user_id() <= 0 ) continue;

      if (!action_log.has_reco_id()
          || action_log.reco_id().size() == 0
          || action_log.reco_id() == "0") {
        continue;
      }
      if (!action_log.has_item_id()
          || action_log.item_id().size() == 0) continue;

      if (!base::StringToUint64(action_log.item_id(), &item_id)) continue;
      if (item_id < 1000000000000) continue;

      ++addnum;
      AddAction(item_id, action_log);
    } else {
      ++fnum;
      LOG_EVERY_N(INFO, 10000) << "FAILED partition : "
                               << partition << " offset : " << offset
                               << " " << fnum;
      base::SleepForSeconds(3);
    }
  }
}

void ItemQualityScorer::AddAction(const uint64 &item_id, reco::log::ActionLog &action_log) {
  thread::AutoLock auto_lock(&mutex_);
  auto acc_iter = acc_dict_.find(item_id);
  if (acc_iter != acc_dict_.end()) {
     switch (action_log.action_type()) {
        case reco::log::kRecoClick:
          if (action_log.has_duration()) {
            if (!action_log.has_scene() || action_log.scene().empty()) {
            acc_iter->second.common_stats.click_num += 1;
            acc_iter->second.common_stats.duration_sum +=
                (((action_log.duration() > 1200) || (action_log.duration() < 0))?90:action_log.duration());
            }
          }
          break;
        case reco::log::kRelateClick:
          if (action_log.has_duration()) {
            acc_iter->second.common_stats.click_num += 1;
            acc_iter->second.common_stats.duration_sum +=
                (((action_log.duration() > 1200) || (action_log.duration() < 0))?90:action_log.duration());
          }
          break;
        case reco::log::kShare:
          acc_iter->second.common_stats.share_num += 1;
          break;
        case reco::log::kCmt:
          acc_iter->second.common_stats.cmt_num += 1;
          break;
        case reco::log::kFav:
          acc_iter->second.common_stats.fav_num += 1;
          break;
        case reco::log::kDisLike:
          acc_iter->second.common_stats.disLike_num += 1;
          break;
        case reco::log::kLike:
          acc_iter->second.common_stats.like_num += 1;
          break;
        case reco::log::kAgree:
          acc_iter->second.common_stats.agree_num += 1;
          break;
        case reco::log::kDisAgree:
          acc_iter->second.common_stats.disAgree_num += 1;
          break;
        default:
          break;
      }
  } else {
    ActionStats action_stats;
    GetMoreAttributes(item_id, action_stats);
    switch (action_log.action_type()) {
        case reco::log::kRecoClick:
          if (action_log.has_duration()) {
            if (!action_log.has_scene() || action_log.scene().empty()) {
              action_stats.common_stats.click_num += 1;
              action_stats.common_stats.duration_sum +=
                  (((action_log.duration() > 1200) || (action_log.duration() < 0))?90:action_log.duration());
              acc_dict_[item_id] = action_stats;
            }
          }
          break;
        case reco::log::kRelateClick:
          if (action_log.has_duration()) {
            action_stats.common_stats.click_num += 1;
            action_stats.common_stats.duration_sum +=
                (((action_log.duration() > 1200) || (action_log.duration() < 0))?90:action_log.duration());
            acc_dict_[item_id] = action_stats;
          }
          break;
        case reco::log::kShare:
          action_stats.common_stats.share_num += 1;
          acc_dict_[item_id] = action_stats;
          break;
        case reco::log::kCmt:
          action_stats.common_stats.cmt_num += 1;
          acc_dict_[item_id] = action_stats;
          break;
        case reco::log::kFav:
          action_stats.common_stats.fav_num += 1;
          acc_dict_[item_id] = action_stats;
          break;
        case reco::log::kDisLike:
          action_stats.common_stats.disLike_num += 1;
          acc_dict_[item_id] = action_stats;
          break;
        case reco::log::kLike:
          action_stats.common_stats.like_num += 1;
          acc_dict_[item_id] = action_stats;
          break;
        case reco::log::kAgree:
          action_stats.common_stats.agree_num += 1;
          acc_dict_[item_id] = action_stats;
          break;
        case reco::log::kDisAgree:
          action_stats.common_stats.disAgree_num += 1;
          acc_dict_[item_id] = action_stats;
          break;
        default:
          break;
     }
  }
}

void ItemQualityScorer::LoopUpdateStats() {
  int64 last_update_timestamp = base::GetTimestamp();
  int64 last_store_timestamp = last_update_timestamp;
  while (running_) {
    int64 start_t = base::GetTimestamp();
    int64 last_generate_thresh_time = start_t - FLAGS_generate_thresh_interval_second * 1e6;
    if (start_t - last_update_timestamp < FLAGS_update_stats_redis_seconds * 1e6) {
      base::SleepForSeconds(30);
      LOG(INFO) << "not ready to write to disk, wait...";
      continue;
    }
    thread::AutoLock auto_lock(&mutex_);
    // merge 全量数据
    MergeGlobalData();

    // 计算 item 后验质量分，根据 parent 聚簇
    RunScore();


    if (start_t - last_generate_thresh_time >= FLAGS_generate_thresh_interval_second * 1e6) {
        // 生成阈值
        GenerateThreshScore();
        last_generate_thresh_time = base::GetTimestamp();
    }

    // item_quality_score 结果写入 redis
    WriteStatsToRedis(acc_dict_);


    // 全量行为数据备份写入磁盘
    if (start_t - last_store_timestamp >= FLAGS_store_stats_disk_seconds * 1e6) {
      WriteStatsToDisk();
      // item_quality_score 分值排序日志写入磁盘
      WriteGroupStatsToDisk();
      last_store_timestamp = base::GetTimestamp();
    }

    LOG(INFO) << "monitor dict size, acc:" << acc_dict_.size() << ", " << acc_dict_.bucket_count()
              << "; global:" << global_dict_.size() << ", " << global_dict_.bucket_count();

    acc_dict_.clear();
    int64 end_t = base::GetTimestamp();
    last_update_timestamp = end_t;
    LOG(INFO) << "update stats cost ms: " << (end_t - start_t) / 1000;
  }
}

void ItemQualityScorer::WriteStatsToDisk() {
  LOG(INFO) << "begin to write action stats to disk, " << global_dict_.size();
  int64 start_t = base::GetTimestamp();
  base::Time now = base::Time::Now();
  std::string date_suffix;
  CHECK(now.ToStringInFormat("%Y-%m-%d", &date_suffix));

  // 创建存储文件
  base::FilePath root_dir(FLAGS_store_stats_disk_dir);
  if (!base::file_util::DirectoryExists(root_dir)) {
    LOG(WARNING) << "does not exit such dir, create it, " << root_dir.ToString();
    CHECK(base::file_util::CreateDirectory(root_dir));
  }

  // 写入 kafka offset
  base::FilePath offset_backup_dir = root_dir.Append("offset." + date_suffix);
  base::FilePath offset_orig_dir(FLAGS_kafka_offset_store_path);
  if (base::file_util::DirectoryExists(offset_orig_dir)) {
    base::file_util::Delete(offset_backup_dir, true);
    base::file_util::CopyDirectory(offset_orig_dir, offset_backup_dir, true);
  }

  // 写入历史统计信息
  std::string store_file_name = base::StringPrintf("%s.%s", kGlobalActionDataStoreFile, date_suffix.c_str());
  base::FilePath store_file = root_dir.Append(store_file_name);
  std::ofstream os(store_file.ToString());
  for (auto iter = global_dict_.begin(); iter != global_dict_.end(); ++iter) {
    const ActionStats& env = iter->second;
    os << base::StringPrintf("%lu\t%lu\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%ld\t%ld\t%d\t%s\t%s\t%s\n",
                             iter->first,
                             env.parent_id,
                             env.common_stats.click_num,
                             env.common_stats.share_num,
                             env.common_stats.cmt_num,
                             env.common_stats.fav_num,
                             env.common_stats.disLike_num,
                             env.common_stats.like_num,
                             env.common_stats.agree_num,
                             env.common_stats.disAgree_num,
                             env.common_stats.duration_sum,
                             env.common_stats.content_len_sum,
                             env.item_type_id,
                             env.common_stats.title.c_str(),
                             env.common_stats.category.c_str(),
                             env.common_stats.last_update_time.c_str());
  }
  os.close();

  LOG(INFO) << "succ to write action stats to disk, " << global_dict_.size()
            << ",  cost " << static_cast<int>((base::GetTimestamp() - start_t) / 1e3) << " ms.";
}

void ItemQualityScorer::MergeGlobalData() {
  LOG(INFO) << "begin to merge global data, acc dict size: " << acc_dict_.size();
  int64 start_t = base::GetTimestamp();

  base::Time curr_time = base::Time::Now();
  std::string str_curr_time;
  curr_time.ToStringInSeconds(&str_curr_time);
  for (auto acc_iter = acc_dict_.begin(); acc_iter != acc_dict_.end(); ++acc_iter) {
    // merge 历史累积的统计数据
    acc_iter->second.common_stats.last_update_time = str_curr_time;
    auto global_iter = global_dict_.find(acc_iter->first);
    if (global_iter != global_dict_.end()) {
      // 更新全局的统计数据
      global_iter->second.common_stats.click_num += acc_iter->second.common_stats.click_num;
      global_iter->second.common_stats.share_num += acc_iter->second.common_stats.share_num;
      global_iter->second.common_stats.cmt_num += acc_iter->second.common_stats.cmt_num;
      global_iter->second.common_stats.fav_num += acc_iter->second.common_stats.fav_num;
      global_iter->second.common_stats.disLike_num += acc_iter->second.common_stats.disLike_num;
      global_iter->second.common_stats.like_num += acc_iter->second.common_stats.like_num;
      global_iter->second.common_stats.disAgree_num += acc_iter->second.common_stats.disAgree_num;
      global_iter->second.common_stats.agree_num += acc_iter->second.common_stats.agree_num;
      global_iter->second.common_stats.duration_sum += acc_iter->second.common_stats.duration_sum;
      global_iter->second.common_stats.last_update_time = acc_iter->second.common_stats.last_update_time;
    } else {
      // 没有获取内容长度,类别属性，选择丢弃
      if (!GetMoreAttributes(acc_iter->first, acc_iter->second)) continue;
      int64 content_len_sum = acc_iter->second.common_stats.content_len_sum;
      uint64 item_id = acc_iter->first;
      uint64 parent_id;
      int item_type_id;
      GetParentIdAndItemType(item_id, &parent_id, &item_type_id);
      // 过滤 humor, purevideo, content_len = 0, parent_id = 0
      if (item_type_id == 30 || item_type_id == 3 || content_len_sum <= 0) continue;
      if (parent_id <= 0) {
        parent_id = item_id;
      }
      acc_iter->second.parent_id = parent_id;
      acc_iter->second.item_type_id = item_type_id;
      std::string value = base::StringPrintf("%lu#%d", parent_id, item_type_id);

      // cache the parent_id and item_type
      cache_parent_->IfNotFoundThenAdd(item_id, value);
      auto iter = parent_map_.find(item_id);
      if (iter == parent_map_.end()) {
        parent_map_[item_id] = parent_id;
      }
      // 更新全局的统计数据
      global_dict_[acc_iter->first] = acc_iter->second;
    }
  }
  LOG(INFO) << "succ to merge acc_dict to global data."
            << ",  cost " << static_cast<int>((base::GetTimestamp() - start_t) / 1e3) << " ms.";
}

bool ItemQualityScorer::GetMoreAttributes(const uint64 &item_id, ActionStats &action_stats) {
  reco::RecoItem reco_item;
  if (!hbase_get_item_->GetRecoItem(item_id, &reco_item)) {
    LOG(ERROR) << "failed to get reco item form hbase item_id: " << item_id;
    return false;
  }
  std::string content = reco_item.content();
  std::string title = reco_item.title();
  base::Slice slice(content.c_str());
  int content_len;
  CHECK(base::GetUTF8CharNum(slice, &content_len));
  content_len += (reco_item.image_size())*10;
  std::string category;
  if (reco_item.category_size() > 0) {
    category = reco_item.category(0);
  }
  action_stats.common_stats.title = title;
  action_stats.common_stats.category = category;
  action_stats.common_stats.content_len_sum = content_len;
  return true;
}


std::string ItemQualityScorer::GetItemTypeStr(int item_type_id) {
  if (item_type_.find(item_type_id) != item_type_.end()) {
    return item_type_[item_type_id];
  } else {
    return "error_item_type_id";
  }
}

bool ItemQualityScorer::Compare(const std::pair<uint64, ActionClusterScore>& a,
                                      const std::pair<uint64, ActionClusterScore>& b) {
  switch (a.second.compare_flag) {
    case kClickFlag:
      return (a.second.click_score > b.second.click_score);
    case kShareFlag:
      return (a.second.share_score > b.second.share_score);
    case kCmtFlag:
      return (a.second.cmt_score > b.second.cmt_score);
    case kFavFlag:
      return (a.second.fav_score > b.second.fav_score);
    case kDisLikeFlag:
      return (a.second.disLike_score > b.second.disLike_score);
    case kLikeFlag:
      return (a.second.like_score > b.second.like_score);
    case kDisAgreeFlag:
      return (a.second.disAgree_score > b.second.disAgree_score);
    case kAgreeFlag:
      return (a.second.agree_score > b.second.agree_score);
    case kDurationFlag:
      return (a.second.duration_score > b.second.duration_score);
    case kContentLenFlag:
      return (a.second.content_len_score > b.second.content_len_score);
    case kQualityFlag:
      return (a.second.quality_score > b.second.quality_score);
    case kQualityFlagTest:
      return (a.second.quality_score_test > b.second.quality_score_test);
    }
    return false;
}

bool ItemQualityScorer::CompareGreater(const std::pair<uint64, ActionClusterScore>& a,
                                       const std::pair<uint64, ActionClusterScore>& b) {
  return a.second.quality_score_test > b.second.quality_score_test;
}

void ItemQualityScorer::GetParentIdAndItemType(const uint64 &item_id, uint64* parent_id, int* item_type_id) {
  uint64 key = item_id;
  std::string value;
  if (cache_parent_->Find(key, &value)) {
    std::vector<std::string> flds;
    base::SplitString(value, "#", &flds);
    CHECK(base::StringToUint64(flds[0], parent_id));
    CHECK(base::StringToInt(flds[1], item_type_id));
    return;
  }

  std::string sql_str =
      base::StringPrintf("select parent_id, item_type from tb_item_info where item_id=\"%lu\"", item_id);
  for (int i =0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql_str));
      while (res->next()) {
        std::string category;
        std::string parent_id_str = res->getString("parent_id");
        int item_type_int = res->getInt("item_type");
        *item_type_id = item_type_int;
        if (!base::StringToUint64(parent_id_str, parent_id)) {
          LOG(ERROR) << "error parent_id: " << parent_id_str << " when item_id: " << item_id;
          break;
        } else {
//          LOG(INFO) << "success parent_id: " << parent_id_str << " when item_id: " << item_id;
          break;
        }
      }
      break;
    } catch(sql::SQLException e) {
      LOG(ERROR) << "Exception: " << e.what();
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
  return;
}

void ItemQualityScorer::AddStatsByGroup(const uint64 &parent_id, ActionClusterStats &action_stats) {
  auto group_iter = group_dict_.find(parent_id);
  if (group_iter == group_dict_.end()) {
    group_dict_[parent_id] = action_stats;
    group_iter = group_dict_.find(parent_id);
    GenerateScore(group_iter);
  } else {
    group_iter -> second.common_stats.click_num += action_stats.common_stats.click_num;
    group_iter -> second.common_stats.share_num += action_stats.common_stats.share_num;
    group_iter -> second.common_stats.cmt_num += action_stats.common_stats.cmt_num;
    group_iter -> second.common_stats.fav_num += action_stats.common_stats.fav_num;
    group_iter -> second.common_stats.disLike_num += action_stats.common_stats.disLike_num;
    group_iter -> second.common_stats.like_num += action_stats.common_stats.like_num;
    group_iter -> second.common_stats.disAgree_num += action_stats.common_stats.disAgree_num;
    group_iter -> second.common_stats.agree_num += action_stats.common_stats.agree_num;
    group_iter -> second.common_stats.duration_sum += action_stats.common_stats.duration_sum;
    group_iter -> second.common_stats.content_len_sum += action_stats.common_stats.content_len_sum;
    group_iter -> second.common_stats.category = action_stats.common_stats.category;
    group_iter -> second.common_stats.title = action_stats.common_stats.title;
    group_iter -> second.common_stats.last_update_time = action_stats.common_stats.last_update_time;
    group_iter -> second.item_type = action_stats.item_type;
    group_iter -> second.cluster_size += action_stats.cluster_size;
    GenerateScore(group_iter);
  }
}

void ItemQualityScorer::Cluster(int cluster_mode) {
  if (cluster_mode == kAccMode) {
    LOG(INFO) << "begin to cluster the item, acc mode, total num " << acc_dict_.size();
    int64 start_t = base::GetTimestamp();
    auto acc_iter = acc_dict_.begin();
    for (; acc_iter != acc_dict_.end(); ++acc_iter) {
      auto global_iter = global_dict_.find(acc_iter->first);
      if (global_iter == global_dict_.end()) continue;
      if (global_iter->second.parent_id == 0) continue;
      ActionClusterStats env;
//    uint64 item_id = global_iter->first;
      env.common_stats.click_num = global_iter->second.common_stats.click_num;
      env.common_stats.share_num = global_iter->second.common_stats.share_num;
      env.common_stats.cmt_num = global_iter->second.common_stats.cmt_num;
      env.common_stats.fav_num = global_iter->second.common_stats.fav_num;
      env.common_stats.disLike_num = global_iter->second.common_stats.disLike_num;
      env.common_stats.like_num = global_iter->second.common_stats.like_num;
      env.common_stats.agree_num = global_iter->second.common_stats.agree_num;
      env.common_stats.disAgree_num = global_iter->second.common_stats.disAgree_num;
      env.common_stats.duration_sum = global_iter->second.common_stats.duration_sum;
      env.common_stats.content_len_sum = global_iter->second.common_stats.content_len_sum;
      env.item_type = GetItemTypeStr(global_iter->second.item_type_id);
      env.cluster_size = 1;
      env.common_stats.title = global_iter->second.common_stats.title;
      env.common_stats.category = global_iter->second.common_stats.category;
      env.common_stats.last_update_time = global_iter->second.common_stats.last_update_time;
      AddStatsByGroup(global_iter->second.parent_id, env);
    }
    int64 end_t = base::GetTimestamp();
    LOG(INFO) << "cluster stats cost ms: " << (end_t - start_t) / 1000;
  } else if (cluster_mode == kGlobalMode) {
    LOG(INFO) << "begin to cluster the item, global mode, total num " << global_dict_.size();
    int64 start_t = base::GetTimestamp();
    auto global_iter = global_dict_.begin();
    for (; global_iter != global_dict_.end(); ++global_iter) {
      ActionClusterStats env;
//    uint64 item_id = global_iter->first;
      env.common_stats.click_num = global_iter->second.common_stats.click_num;
      env.common_stats.share_num = global_iter->second.common_stats.share_num;
      env.common_stats.cmt_num = global_iter->second.common_stats.cmt_num;
      env.common_stats.fav_num = global_iter->second.common_stats.fav_num;
      env.common_stats.disLike_num = global_iter->second.common_stats.disLike_num;
      env.common_stats.like_num = global_iter->second.common_stats.like_num;
      env.common_stats.agree_num = global_iter->second.common_stats.agree_num;
      env.common_stats.disAgree_num = global_iter->second.common_stats.disAgree_num;
      env.common_stats.duration_sum = global_iter->second.common_stats.duration_sum;
      env.common_stats.content_len_sum = global_iter->second.common_stats.content_len_sum;
      env.item_type = GetItemTypeStr(global_iter->second.item_type_id);
      env.cluster_size = 1;
      env.common_stats.title = global_iter->second.common_stats.title;
      env.common_stats.category = global_iter->second.common_stats.category;
      env.common_stats.last_update_time = global_iter->second.common_stats.last_update_time;
      if (global_iter->second.parent_id == 0) continue;
      AddStatsByGroup(global_iter->second.parent_id, env);
    }
    int64 end_t = base::GetTimestamp();
    LOG(INFO) << "cluster stats cost ms: " << (end_t - start_t) / 1000;
  }
}

void ItemQualityScorer::WriteGroupStatsToDisk() {
  LOG(INFO) << "begin to write Group stats to disk, " << group_dict_.size();
  base::Time now = base::Time::Now();
  std::string date_suffix;
  CHECK(now.ToStringInFormat("%Y-%m-%d", &date_suffix));

  // 创建存储文件
  base::FilePath root_dir(FLAGS_store_stats_disk_dir);
  if (!base::file_util::DirectoryExists(root_dir)) {
    LOG(WARNING) << "does not exit such dir, create it, " << root_dir.ToString();
    CHECK(base::file_util::CreateDirectory(root_dir));
  }

  // 写入历史统计信息
  std::string store_file_name = base::StringPrintf("%s.%s_%d",
                                                   kActionStatsOutfile,
                                                   date_suffix.c_str(),
                                                   FLAGS_cmp_flag);
  base::FilePath store_file = root_dir.Append(store_file_name);
  std::ofstream os(store_file.ToString());
  for (auto iter = score_vec_.begin(); iter != score_vec_.end(); ++iter) {
    ActionClusterScore env = iter->second;
    os << base::StringPrintf(
    "%lu\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f\t%d\t%.4f\t%.4f\t%s\t%s\t%s\t%s\n",
                             iter->first,
                             env.click_score,
                             env.share_score,
                             env.cmt_score,
                             env.fav_score,
                             env.disLike_score,
                             env.like_score,
                             env.disAgree_score,
                             env.agree_score,
                             env.duration_score,
                             env.average_duration,
                             env.content_len_score,
                             env.cluster_size,
                             env.quality_score,
                             env.quality_score_test,
                             env.title.c_str(),
                             env.category.c_str(),
                             env.item_type.c_str(),
                             env.last_update_time.c_str());
  }
  os.close();

  // generate the quality score dict file
  auto quality_score_iter = quality_category_score_map_.begin();
  for (; quality_score_iter != quality_category_score_map_.end(); ++quality_score_iter) {
    std::string thresh_file_name = base::StringPrintf("%s.%s.%s",
                                                       kItemQualityScoreThresh,
                                                       date_suffix.c_str(),
                                                       quality_score_iter->first.c_str());
    base::FilePath thresh_store_file = root_dir.Append(thresh_file_name);
    std::ofstream os_thresh(thresh_store_file.ToString());
    auto thresh_iter = quality_score_iter -> second.thresh_vec.begin();
    for (; thresh_iter != quality_score_iter -> second.thresh_vec.end(); ++thresh_iter) {
      os_thresh << *thresh_iter <<std::endl;
    }
    os_thresh.close();
    std::string dict_file_name = base::StringPrintf("%s.%s.%s",
                                                   kItemQualityScoreDict,
                                                   date_suffix.c_str(),
                                                   quality_score_iter->first.c_str());
    base::FilePath dict_store_file = root_dir.Append(dict_file_name);
    std::ofstream os_dict(dict_store_file.ToString());
    auto score_iter = quality_score_iter -> second.score_vec.begin();
    for (; score_iter != quality_score_iter -> second.score_vec.end(); ++score_iter) {
      os_dict << base::StringPrintf(
          "%lu\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f\t%d\t%.4f\t%s\t%s\t%s\n",
                             score_iter->first,
                             score_iter->second.click_score,
                             score_iter->second.share_score,
                             // score_iter->second.cmt_score,
                             score_iter->second.fav_score,
                             score_iter->second.disLike_score,
                             score_iter->second.like_score,
                             // score_iter->second.disAgree_score,
                             score_iter->second.agree_score,
                             score_iter->second.duration_score,
                             // score_iter->second.average_duration,
                             // score_iter->second.content_len_score,
                             score_iter->second.cluster_size,
                             // score_iter->second.quality_score,
                             score_iter->second.quality_score_test,
                             score_iter->second.title.c_str(),
                             score_iter->second.item_type.c_str(),
                             // score_iter->second.category.c_str(),
                             score_iter->second.last_update_time.c_str());
    }
    os_dict.close();
    LOG(INFO) << "succ to write item quality dict to disk, category: " << quality_score_iter -> first
              << "size: " << quality_score_iter -> second.score_vec.size();
  }
}

void ItemQualityScorer::GenerateScore(
    boost::unordered_map<uint64, reco::item_level::ActionClusterStats>::iterator group_iter) {
  ActionClusterScore  action_score;
    // 丢弃 click 低于 50 的
  if ((group_iter->second.common_stats.click_num >= 50) &&
      (group_iter->second.common_stats.content_len_sum > 0)) {
    action_score.click_score = (double)(group_iter->second.common_stats.click_num);
    action_score.share_score =
        ((double)group_iter->second.common_stats.share_num / action_score.click_score);
    action_score.cmt_score =
        ((double)group_iter->second.common_stats.cmt_num / action_score.click_score);
    action_score.fav_score =
        ((double)group_iter->second.common_stats.fav_num / action_score.click_score);
    action_score.disLike_score =
        ((double)group_iter->second.common_stats.disLike_num / action_score.click_score);
    action_score.like_score =
        ((double)group_iter->second.common_stats.like_num / action_score.click_score);
    action_score.disAgree_score =
        ((double)group_iter->second.common_stats.disAgree_num / action_score.click_score);
    action_score.agree_score =
        ((double)group_iter->second.common_stats.agree_num / action_score.click_score);
    action_score.duration_score =
        ((double)group_iter->second.common_stats.duration_sum /
                 (sqrt((double)group_iter->second.common_stats.content_len_sum) * action_score.click_score));
    if (action_score.duration_score > FLAGS_duration_ceiling) {
      action_score.duration_score = FLAGS_duration_ceiling;
    }
    action_score.average_duration =
        ((double)group_iter->second.common_stats.duration_sum / action_score.click_score);
    action_score.title = group_iter->second.common_stats.title;
    action_score.item_type = group_iter->second.item_type;
    action_score.content_len_score =
        ((double)group_iter->second.common_stats.content_len_sum /(double)group_iter->second.cluster_size);

    double time_score_weight = max((1 - (double)(action_score.click_score/FLAGS_duration_weight_para_c)),
                                   FLAGS_duration_weight_para_b);
    double time_score_weight_test =
        max(FLAGS_duration_weight_para_a *
            (1 -(double)(action_score.click_score/FLAGS_duration_weight_para_c)),
            FLAGS_duration_weight_para_b);

    double act_score = 1 + FLAGS_act_weight * (3 * (action_score.share_score + action_score.fav_score)
        + 2 * action_score.like_score + action_score.agree_score - 3 * action_score.disLike_score);
    action_score.quality_score = act_score * pow(action_score.duration_score, time_score_weight);
    action_score.quality_score_test = act_score * pow(action_score.duration_score, time_score_weight_test);
    action_score.cluster_size = group_iter ->second.cluster_size;
    action_score.category = group_iter->second.common_stats.category;
    action_score.last_update_time = group_iter->second.common_stats.last_update_time;
    // record the score; quality_score_test 用于调参和对比，后续稳定后将固定。
    group_iter->second.quality_score = action_score.quality_score_test;
    score_dict_[group_iter->first] = action_score;
  }
}

void ItemQualityScorer::GenerateThreshScore() {
  int64 start_t = base::GetTimestamp();
  LOG(INFO) << "begin to generate thresh score, the size " << score_dict_.size();
  score_vec_.clear();
  for (auto score_iter = score_dict_.begin(); score_iter != score_dict_.end(); ++score_iter) {
    score_vec_.push_back(std::make_pair(score_iter->first, score_iter->second));
  }
  sort(score_vec_.begin(), score_vec_.end(), ItemQualityScorer::Compare);
  std::string category_str = FLAGS_category_config;
  std::string undefined_category = "未定义";
  std::vector<std::string> flds;
  base::SplitString(category_str, "#", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    ActionCategoryScore category_score;
    quality_category_score_map_[flds[i]] = category_score;
  }

  if (quality_category_score_map_.find(undefined_category) == quality_category_score_map_.end()) {
    ActionCategoryScore category_score;
    quality_category_score_map_[undefined_category] = category_score;
  }
  auto score_iter = score_vec_.begin();
  for (; score_iter != score_vec_.end(); ++score_iter) {
    if (quality_category_score_map_.find(score_iter->second.category) != quality_category_score_map_.end()) {
      quality_category_score_map_[score_iter->second.category].score_vec.push_back
          (std::pair<uint64, ActionClusterScore>(score_iter->first, score_iter->second));
    } else {
      quality_category_score_map_[undefined_category].score_vec.push_back
          (std::pair<uint64, ActionClusterScore>(score_iter->first, score_iter->second));
    }
  }
  auto quality_score_iter = quality_category_score_map_.begin();
  for (; quality_score_iter != quality_category_score_map_.end();++quality_score_iter) {
    sort(quality_score_iter->second.score_vec.begin(), quality_score_iter->second.score_vec.end(),
         ItemQualityScorer::CompareGreater);
    int vec_length = quality_score_iter->second.score_vec.size();
    int idx = static_cast<int>(FLAGS_thresh_high * vec_length);
    quality_score_iter->second.thresh_vec.push_back
        (quality_score_iter->second.score_vec[idx].second.quality_score_test);

    idx = static_cast<int>(FLAGS_thresh_mid_high * vec_length);
    quality_score_iter->second.thresh_vec.push_back
        (quality_score_iter->second.score_vec[idx].second.quality_score_test);

    idx = static_cast<int>(FLAGS_thresh_mid_low * vec_length);
    quality_score_iter->second.thresh_vec.push_back
        (quality_score_iter->second.score_vec[idx].second.quality_score_test);

    idx = static_cast<int>(FLAGS_thresh_low * vec_length);
    quality_score_iter->second.thresh_vec.push_back
        (quality_score_iter->second.score_vec[idx].second.quality_score_test);
  }
  LOG(INFO) << "succ to generate thresh score, "
            << ",  cost " << static_cast<int>((base::GetTimestamp() - start_t) / 1e3) << " ms.";
}

void ItemQualityScorer::RunScore() {
  Cluster(kAccMode);
}


void ItemQualityScorer::WriteStatsToRedis(const boost::unordered_map<uint64, ActionStats>& stats_dict) {
  CHECK_LT(stats_dict.size(), 3000000u) << "the number of items to write into redis is too large to quit";
  LOG(INFO) << "begin to write stats to redis, " << stats_dict.size();

  std::vector<uint64> items;
  for (auto iter = stats_dict.begin(); iter != stats_dict.end(); ++iter) {
    items.push_back(iter->first);
  }

  thread::ThreadPool pool(FLAGS_write_quality_redis_thread_num);
  for (int i = 0; i < FLAGS_write_quality_redis_thread_num; ++i) {
    pool.AddTask(NewCallback<ItemQualityScorer, const std::vector<uint64>*, int>
                 (this, &ItemQualityScorer::WriteRedisThread, &items, i));
  }
  pool.JoinAll();


  LOG(INFO) << "succ to write stats to redis, " << stats_dict.size();
}

void ItemQualityScorer::WriteRedisThread(const std::vector<uint64>* items, int thread_id) {
  int64 start_t = base::GetTimestamp();

  int count = 0;
  for (int idx = thread_id; idx < (int)items->size(); idx += FLAGS_write_quality_redis_thread_num) {
    uint64 item_id = items->at(idx);
    uint64 parent_id;
    if (!GetParentIDLocal(item_id, &parent_id)) continue;
    const auto iter = group_dict_.find(parent_id);  // NOLINT
    if (iter == group_dict_.end()) continue;
    int quality_level;
    if (!GetQualityLevel(parent_id, &quality_level)) continue;
    if (quality_level == 2) continue;
    const std::string& key = base::StringPrintf("%s%lu", kItemRedisKeyPrefix, item_id);
    const std::string& val = base::StringPrintf("%d", quality_level);
    redis_client_->HSet(key, kItemQualityField, val);
    if (slave_redis_client_ != NULL) {
      slave_redis_client_->HSet(key, kItemQualityField, val);
    }
    if (third_redis_client_ != NULL) {
      third_redis_client_->HSet(key, kItemQualityField, val);
    }
    ++count;
  }

  int cost_ms = (base::GetTimestamp() - start_t) / 1e3;
  LOG(INFO) << "write redis, thread_id: " << thread_id
            << ", total: " << count
            << ", cost " << cost_ms << " ms.";
}

void ItemQualityScorer::WriteRedis(reco::redis::RedisCli* client,
                                   const std::vector<uint64>& items) const {
  int64 start_t = base::GetTimestamp();
  for (auto iter = items.begin(); iter != items.end(); ++iter) {
    const uint64 item_id = *iter;
    uint64 parent_id;
    if (!GetParentIDLocal(item_id, &parent_id)) continue;
    const auto iter = group_dict_.find(parent_id);  // NOLINT
    if (iter == group_dict_.end()) continue;
    int quality_level;
    if (!GetQualityLevel(parent_id, &quality_level)) continue;
    if (quality_level == 2) continue;
    const std::string& key = base::StringPrintf("%s%lu", kItemRedisKeyPrefix, item_id);
    const std::string& val = base::StringPrintf("%d", quality_level);
    client->HSet(key, kItemQualityField, val);
  }

  LOG(INFO) << "write redis, total: " << items.size()
            << ",  cost " << static_cast<int>((base::GetTimestamp() - start_t) / 1e3) << " ms.";
}

bool ItemQualityScorer::GetParentIDLocal(const uint64 &item_id, uint64* parent_id) const {
  const auto iter = parent_map_.find(item_id);  // NOLINT
  if (iter != parent_map_.end()) {
    *parent_id = iter->second;
    return true;
  }
  return false;
}

bool ItemQualityScorer::GetQualityLevel(const uint64 &parent_id, int* quality_level) const {
  const auto score_iter = score_dict_.find(parent_id);  // NOLINT
  if (score_iter == score_dict_.end()) return false;

  const std::vector<double>* thresh_vec = NULL;
  const std::string& category = score_iter->second.category;
  static const std::string undefined_category = "未定义";
  const auto category_iter = quality_category_score_map_.find(category);  // NOLINT
  if (category_iter != quality_category_score_map_.end()) {
    thresh_vec = &category_iter->second.thresh_vec;
  } else {
    const auto category_iter2 = quality_category_score_map_.find(undefined_category);  // NOLINT
    if (category_iter2 != quality_category_score_map_.end()) {
      thresh_vec = &category_iter2->second.thresh_vec;
    }
  }
  if (thresh_vec == NULL || thresh_vec->size() < 4u) {
    return false;
  }

  double score = score_iter->second.quality_score_test;

  if (score > (*thresh_vec)[0]) {
    // *quality_level = kQualityHigh;
    *quality_level = kSuperItemq;
  } else if (score > (*thresh_vec)[1]) {
    // *quality_level = kQualityMidHigh;
    *quality_level = kGoodItemq;
  } else if (score > (*thresh_vec)[2]) {
    // *quality_level = kQualityNormal;
    *quality_level = kNormalItemq;
  } else if (score > (*thresh_vec)[3]) {
    // *quality_level = kQualityMidLow;
    *quality_level = kLowItemq;
  } else {
    // *quality_level = kQualityLow;
    *quality_level = kBadItemq;
  }
  return true;
}

}  // namespace item_level
}  // namespace reco
