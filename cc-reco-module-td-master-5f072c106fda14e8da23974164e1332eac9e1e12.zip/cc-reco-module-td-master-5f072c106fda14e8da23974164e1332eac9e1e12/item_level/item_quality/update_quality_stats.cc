#include <iostream>

#include "reco/module/item_level/item_quality/item_quality_scorer.h"
#include "reco/module/item_level/base/connection_manager.h"
#include "reco/bizc/index_monitor/api/index_monitor.h"
#include "reco/bizc/reco_index/news_index.h"
#include "serving_base/utility/signal.h"



int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "");

  CHECK(reco::item_level::ConnectionManager::InitConnection()) << "Initialize connection error.";


  reco::item_level::ItemQualityScorer* extractor = new reco::item_level::ItemQualityScorer();
  extractor->Start();

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();

  LOG(INFO) << "finish signal. ";

  delete extractor;

  reco::item_level::ConnectionManager::CleanConnection();

  return 0;
}
