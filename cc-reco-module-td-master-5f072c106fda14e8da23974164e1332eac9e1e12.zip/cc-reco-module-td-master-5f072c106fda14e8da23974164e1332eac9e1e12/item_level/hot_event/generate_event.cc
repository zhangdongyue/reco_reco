#include <iostream>
#include <fstream>

#include "reco/module/item_level/hot_event/hot_event_base.h"
#include "reco/module/item_level/hot_event/hot_event_cluster.h"

#include "serving_base/utility/signal.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/time/time.h"

DEFINE_string(hot_file_path, "", "hot file path");
DEFINE_string(today_hot_event_file_path, "", "today hot event file path");
DEFINE_string(hot_event_file_path, "", "hot event file path");
DEFINE_string(update_hot_event_file_path, "", "update_hot_event_file_path");
DEFINE_double(sim_history_thresh, 0.3, "sim_history_thresh");
DEFINE_double(sim_event_thresh, 0.3, "sim_event_thresh");
using namespace reco::item_level;

bool ReadHotFile(const std::string& hot_file_path, std::vector<std::pair<uint64, int>>* item_score_vec) {
  item_score_vec->clear();

  base::FilePath hot_file(hot_file_path);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(hot_file, &lines)) {
    LOG(WARNING) << "read hot file fail, " << hot_file_path;
    return false;
  }
  
  std::vector<std::string> flds;
  uint64 item_id;
  int score;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    flds.clear();
    base::SplitString(lines[idx], "\t", &flds);
    if (flds.size() < 2u
        || !base::StringToUint64(flds[0], &item_id)
        || !base::StringToInt(flds[1], &score)) {
      LOG(WARNING) << "line parse fail, " << lines[idx];
      continue;
    }
    item_score_vec->push_back(std::make_pair(item_id, score));
  }
  
  LOG(INFO) << "succ to load hot file, " << hot_file_path << ", total record:" << item_score_vec->size();

  return true;
}

bool ReadTodayHotEventFile(const std::string& today_hot_event_file_path,
                           std::vector<std::pair<uint64, std::vector<uint64> > > *today_hot_events) {
  today_hot_events->clear();
  base::FilePath today_hot_event_file(today_hot_event_file_path);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(today_hot_event_file, &lines)) {
    LOG(WARNING) << "read today hot event file fail, " << today_hot_event_file_path;
    return false;
  }
  
  std::vector<std::string> flds;
  std::vector<uint64> item_list;
  std::vector<std::string> item_vec;
  std::string id_str;
  uint64 id;
  std::string item_list_str;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    flds.clear();
    item_list.clear();
    item_vec.clear();
    base::SplitString(lines[idx], "\t", &flds);
    if (flds.size() < 3u) {
      LOG(WARNING) << "line parse fail, " << lines[idx];
      continue;
    }
    id_str = flds[0];
    base::StringToUint64(id_str, &id);
    item_list_str = flds[1];
    base::SplitString(item_list_str, "`", &item_vec);
    for (auto iter = item_vec.begin(); iter != item_vec.end(); ++iter) { 
      uint64 item_id;
      base::StringToUint64(*iter, &item_id);
      item_list.push_back(item_id);
    }
    today_hot_events->push_back(std::make_pair(id, item_list));
  }
  LOG(INFO) << "succ to load today hot event file, " << today_hot_event_file_path << ", total record:" << today_hot_events->size();
  return true;
}

bool IfSimEvent(const std::vector<uint64> & his_item_list,
                const HotEventInfo & event) {
  if(((int)his_item_list.size() == 0) || ((int)event.item_list.size() == 0)) {
    return false;
  }
  int count = 0;
  for (size_t i = 0; i < his_item_list.size(); ++i) {
    uint64 his_item_id = his_item_list[i];
    for (size_t j = 0; j < event.item_list.size(); ++j) {
      if (his_item_id == event.item_list[j].item_id) {
        count++;
        break;
      } else {
        if (event.item_list[j].sim_ids.count(his_item_id) > 0) { 
          count++;
          break;
        }
      }
    }
  }
  double sim_history_score = ((double)count + 0.1)/((double)his_item_list.size() + 0.1);
  double sim_event_score = ((double)count + 0.1)/((double)event.item_list.size() + 0.1);
  if ((sim_history_score > FLAGS_sim_history_thresh)
      && (sim_event_score > FLAGS_sim_event_thresh)) return true;
  return false;
}

bool CompareHotItem(const HotItemInfo & a, const HotItemInfo & b) {
  return a.publish_time > b.publish_time;
}

void WriteUpdateHotEventToDisk(std::vector<HotEventInfo>& events,
                               const std::vector<std::pair<uint64, std::vector<uint64 > > > &history_hot_events) {
  LOG(INFO) << "origin_events num" << events.size();
  size_t filter_num = 0;
  std::ofstream os(FLAGS_update_hot_event_file_path);
  for (size_t event_idx = 0; event_idx < events.size(); ++event_idx) {
    if ((int)(events[event_idx].item_list.size()) < 3)  {
      filter_num++;
      continue;
    }
    uint64 represent_id = events[event_idx].item_list[0].item_id;
    const std::string represent_title = events[event_idx].item_list[0].title;
    int hot_score = events[event_idx].item_list[0].hot_score;
    const std::string &category = events[event_idx].item_list[0].category;
    std::string event_item_list = "";

    sort(events[event_idx].item_list.begin(), events[event_idx].item_list.end(), CompareHotItem);

    for (size_t i = 0; i < events[event_idx].item_list.size(); ++i) {
      std::string item_id_str = base::StringPrintf("%lu", events[event_idx].item_list[i].item_id);
      event_item_list = event_item_list + "`" + item_id_str;
    }
    bool sim_flag = false;
    uint64 history_id;
    for (auto his_iter = history_hot_events.begin(); his_iter != history_hot_events.end(); ++his_iter) {
      const HotEventInfo& event = events.at(event_idx);
      if (IfSimEvent(his_iter->second, event)) {
        sim_flag = true;
        history_id = his_iter->first;
        break;
      }
    }
    if (sim_flag) {
      os << base::StringPrintf("%lu\t%d\t%s\t%s\t%s\t%lu\n",
                               represent_id,
                               hot_score,
                               represent_title.c_str(),
                               event_item_list.c_str(),
                               category.c_str(),
                               history_id);
    } else {
      os << base::StringPrintf("%lu\t%d\t%s\t%s\t%s\n",
                               represent_id,
                               hot_score,
                               represent_title.c_str(),
                               event_item_list.c_str(),
                               category.c_str());
    }
  }

  LOG(INFO) << "filter events num" << filter_num;
  LOG(INFO) << "succ to write update hot event file to disk, " << events.size();
}

void WriteToDisk(const std::vector<HotEventInfo>& events) {
  std::ofstream os(FLAGS_hot_event_file_path);
  int kMaxEventItemNum = 5;
  std::string publish_time;
  for (int i = kMaxEventItemNum; i >= 1; --i) {
    for (size_t j = 0; j < events.size(); ++j) {
      const HotEventInfo& event = events.at(j);
      bool write_this_loop = false;
      if (i == kMaxEventItemNum) {
        if ((int)event.item_list.size() >= i) {
          write_this_loop = true;
        }
      } else if ((int)event.item_list.size() == i) {
        write_this_loop = true;
      }
      if (!write_this_loop) continue;
      for (size_t k = 0; k < event.item_list.size(); ++k) {
        const HotItemInfo& item = event.item_list.at(k);
        item.publish_time.ToStringInSeconds(&publish_time);
        os << base::StringPrintf("%lu\t%d\t%s\t%d\t%s\n",
                                 item.item_id, item.hot_score, item.title.c_str(),
                                 (int)item.sim_ids.size(), publish_time.c_str());
      }   
      os << "--------------------hot_event--------------------------\n";
    }
  }
  os.close();
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "");
  std::vector<std::pair<uint64, int> > item_score_vec;
  if (!ReadHotFile(FLAGS_hot_file_path, &item_score_vec)) {
    return 0;
  }

  std::vector<std::pair<uint64, std::vector<uint64> > > today_hot_events;
  if (!ReadTodayHotEventFile(FLAGS_today_hot_event_file_path, &today_hot_events)) {
    return 0;
  }

  HotEventCluster* cluster = new HotEventCluster();
  std::vector<HotEventInfo> hot_events;
  cluster->DoHotEventCluster(item_score_vec, &hot_events);
  WriteToDisk(hot_events);
  WriteUpdateHotEventToDisk(hot_events, today_hot_events);
  
  delete cluster;

  return 0;
}
