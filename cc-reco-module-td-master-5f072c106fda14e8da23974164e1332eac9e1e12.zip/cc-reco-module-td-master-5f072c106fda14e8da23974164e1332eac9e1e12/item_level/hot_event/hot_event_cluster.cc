#include "reco/module/item_level/hot_event/hot_event_cluster.h"

#include "base/time/time.h"
#include "base/strings/utf_char_iterator.h"

namespace reco {
namespace item_level {
DEFINE_string(sim_hbase_table_name, "tb_sim_item", "the table name of sim.");
DEFINE_int32(sim_cache_size, 10000, "sim cache size.");

DEFINE_string(item_hbase_table_name, "tb_reco_item", "the table name of item.");
DEFINE_int32(item_cache_size, 10000, "sim cache size.");
DEFINE_int32(main_hot_score_thres, 40, "main hot score thres.");
DEFINE_int32(main_hot_item_hour_limit, 6, "main hot item hour thres.");
DEFINE_int32(event_item_hour_interval, 24, "");

DEFINE_bool(hot_event_cluster_debug_mode, false, "");

HotEventCluster::HotEventCluster() {
  hbase_get_sim_ = new reco::HBasePoolGetSim(FLAGS_sim_hbase_table_name);
//  hbase_get_item_ = new reco::HBasePoolGetItem(FLAGS_item_hbase_table_name, FLAGS_item_cache_size);
  hbase_get_item_ = new reco::HBaseGetItem(FLAGS_item_hbase_table_name, FLAGS_item_cache_size);
}

HotEventCluster::~HotEventCluster() {
  delete hbase_get_sim_;
  delete hbase_get_item_;
}

void HotEventCluster::DoHotEventCluster(const std::vector<std::pair<uint64, int> >& item_score_vec,
                                        std::vector<HotEventInfo>* hot_events) {
  hot_events->clear();

  std::vector<std::pair<int, uint64> > score_item_vec;
  score_item_vec.resize(item_score_vec.size());
  for (size_t idx = 0; idx < item_score_vec.size(); ++idx) {
    score_item_vec[idx].first = item_score_vec[idx].second;
    score_item_vec[idx].second = item_score_vec[idx].first;
  }
  std::sort(score_item_vec.begin(), score_item_vec.end(), std::greater<std::pair<int, uint64>>());

  // item 转换
  std::vector<HotItemInfo> hot_items;
  hot_items.reserve(score_item_vec.size());
  RecoItem reco_item;
  HotItemInfo hot_item;
  for (size_t idx = 0; idx < score_item_vec.size(); ++idx) {
    if (!hbase_get_item_->GetRecoItem(score_item_vec[idx].second, &reco_item)) {
      LOG(WARNING) << "item does not exist in hbase, " << score_item_vec[idx].second;
      continue;
    }
    if (!RecoItemToHotItem(reco_item, score_item_vec[idx].first, &hot_item)) {
      LOG(WARNING) << "do reco_item to hot_item fail, " << score_item_vec[idx].second;
      continue;
    }
    hot_items.push_back(hot_item);
  }

  // 聚簇
  DoHotEventClusterAlg(hot_items, hot_events);
}

void HotEventCluster::DoHotEventClusterAlg(const std::vector<HotItemInfo>& hot_items,
                                           std::vector<HotEventInfo>* hot_events) {
  base::dense_hash_set<uint64> dedup_items;
  dedup_items.set_empty_key(0);

  base::dense_hash_set<uint64> cluster_sim_items;
  cluster_sim_items.set_empty_key(0);

  base::Time hot_limit_time = base::Time::Now() - base::TimeDelta::FromHours(FLAGS_main_hot_item_hour_limit);

  // 事件子文只允许以下几种类型
  static const std::unordered_set<int> kRemainItemTypeSet
      = {reco::kReading, reco::kNews, reco::kPictureNews, reco::kPicture, reco::kPureVideo};
  HotEventInfo hot_event;
  std::vector<int> event_cluster_items;
  for (size_t idx = 0; idx < hot_items.size(); ++idx) {
    const HotItemInfo& hot_item = hot_items.at(idx);
    if (hot_item.hot_score < FLAGS_main_hot_score_thres) continue;
    if (hot_item.publish_time < hot_limit_time) continue;

    if (kRemainItemTypeSet.find(hot_item.item_type) == kRemainItemTypeSet.end()) continue;
    if (dedup_items.find(hot_item.item_id) != dedup_items.end()) continue;
    dedup_items.insert(hot_item.item_id);

    event_cluster_items.clear();
    cluster_sim_items.clear();

    event_cluster_items.push_back(idx);
    AddToSimCluster(hot_item, &cluster_sim_items);

    for (size_t jdx = idx + 1; jdx < hot_items.size(); ++jdx) {
      const HotItemInfo& rht_hot_item = hot_items.at(jdx);
      if (kRemainItemTypeSet.find(rht_hot_item.item_type) == kRemainItemTypeSet.end()) continue;
      if (dedup_items.find(rht_hot_item.item_id) != dedup_items.end()) continue;
      if (IsSameCluster(hot_item, rht_hot_item)) {
        dedup_items.insert(rht_hot_item.item_id);
        event_cluster_items.push_back(jdx);
        AddToSimCluster(rht_hot_item, &cluster_sim_items);
      }
    }

    if (GenerateEvent(hot_items, event_cluster_items, &cluster_sim_items, &hot_event)) {
      hot_events->push_back(hot_event);
    }
  }
}


bool HotEventCluster::RecoItemToHotItem(const reco::RecoItem& reco_item, int hot_score,
                                        HotItemInfo* hot_item) const {
  hot_item->Clear();
  std::vector<uint64> sim_ids;
  hot_item->item_id = reco_item.identity().item_id();
  if ((int)reco_item.category_size() > 0) {
    hot_item->category = reco_item.category(0);
  } else { 
    hot_item->category = "no_category";
  }
  hot_item->item_type = reco_item.identity().type();
  hot_item->hot_score = hot_score;
  hot_item->title = reco_item.title();
  hot_item->source = reco_item.source();

  if (hot_item->source.find("地方新闻接口") != std::string::npos) { 
    return false;
  }

  if (!base::Time::FromStringInSeconds(reco_item.raw_item().publish_time().c_str(),
                                       &hot_item->publish_time)) {
    LOG(WARNING) << "parse publish time fail, " << reco_item.raw_item().publish_time();
    return false;
  }
  for (int jdx = 0; jdx < reco_item.title_unigram_size(); ++jdx) {
    hot_item->title_unigrams.push_back(reco_item.title_unigram(jdx));
  }
  if (reco_item.has_keyword()) {
    const reco::FeatureVector& kw_vec = reco_item.keyword();
    for (int i = 0; i < kw_vec.feature_size(); ++i) {
      const reco::Feature& fea = kw_vec.feature(i);
      hot_item->keywords[fea.literal()] += fea.weight();
    }
  }
  if (reco_item.has_tag()) {
    const reco::FeatureVector& tag_vec = reco_item.tag();
    for (int i = 0; i < tag_vec.feature_size(); ++i) {
      const reco::Feature& fea = tag_vec.feature(i);
      hot_item->tags[fea.literal()] += fea.weight();
    }
  }
  if (!hbase_get_sim_->GetSimItem(hot_item->item_id, &sim_ids)) {
    LOG(WARNING) << "get sim item fail, " << hot_item->item_id;
    return false;
  }
  hot_item->sim_ids.insert(sim_ids.begin(), sim_ids.end());
  return true;
}

bool HotEventCluster::IsSameCluster(const HotItemInfo& main_item, const HotItemInfo& slave_item) const {
  base::TimeDelta delta = slave_item.publish_time - main_item.publish_time;
  if (delta.InHours() < -1 * FLAGS_event_item_hour_interval
      || delta.InHours() > FLAGS_event_item_hour_interval) {
    return false;
  }
  // sim match 个数
  int sim_match_num = 0;
  for (auto main_iter = main_item.sim_ids.begin(); main_iter != main_item.sim_ids.end(); ++main_iter) {
    for (auto slave_iter = slave_item.sim_ids.begin(); slave_iter != slave_item.sim_ids.end(); ++slave_iter) {
      if (*main_iter == *slave_iter) {
        ++sim_match_num;
      }
    }
  }
  if (sim_match_num >= 2) {
    float main_match_ratio = sim_match_num * 1.0 / main_item.sim_ids.size();
    float slave_match_ratio = sim_match_num * 1.0 / slave_item.sim_ids.size();
    if (main_match_ratio >= 0.2 || slave_match_ratio >= 0.2) {
      LOG_IF(INFO, FLAGS_hot_event_cluster_debug_mode)
          << "[DEBUG_SAME], sim match"
          << ", main_id:" << main_item.item_id << ", main_title:" << main_item.title
          << ", main_sim:" << main_item.sim_ids.size() << ", main_ratio:" << main_match_ratio
          << ", slave_id:" << slave_item.item_id << ", slave_title:" << slave_item.title
          << ", slave_sim:" << slave_item.sim_ids.size() << ", slave_ratio:" << slave_match_ratio;
      return true;
    }
  }

  // keyword match
  float main_match_score = 0;
  float slave_match_score = 0;
  int kw_match_num = 0;
  for (auto main_iter = main_item.keywords.begin(); main_iter != main_item.keywords.end(); ++main_iter) {
    const auto slave_iter = slave_item.keywords.find(main_iter->first);
    if (slave_iter == slave_item.keywords.end()) continue;
    main_match_score += main_iter->second;
    slave_match_score += slave_iter->second;
    ++kw_match_num;
  }
  if (kw_match_num >= 2 &&
      (main_match_score >= 0.45 || slave_match_score >= 0.45)) {
    LOG_IF(INFO, FLAGS_hot_event_cluster_debug_mode)
        << "[DEBUG_SAME], keyword match"
        << ", main_id:" << main_item.item_id << ", main_title:" << main_item.title
        << ", main_score:" << main_match_score
        << ", slave_id:" << slave_item.item_id << ", slave_title:" << slave_item.title
        << ", slave_score:" << slave_match_score;
    return true;
  }

  // title match
  int title_match_width = 0;
  int title_match_term = 0;
  std::unordered_set<std::string> title_unigrams;
  title_unigrams.insert(main_item.title_unigrams.begin(), main_item.title_unigrams.end());
  for (size_t idx = 0; idx < slave_item.title_unigrams.size(); ++idx) {
    const std::string& unigram = slave_item.title_unigrams[idx];
    if (title_unigrams.find(unigram) != title_unigrams.end()) {
      int width = 0;
      if (base::GetUTF8TextWidth(unigram, &width)) {
        title_match_width += width;
        title_match_term += 1;
      }
    }
  }
  if (title_match_term >= 3 && title_match_width >= 6) {
    int main_title_width = 0;
    int slave_title_width = 0;
    float main_match_ratio = 0;
    float slave_match_ratio = 0;
    if (base::GetUTF8TextWidth(main_item.title, &main_title_width)
        && base::GetUTF8TextWidth(slave_item.title, &slave_title_width)
        && main_title_width > 0
        && slave_title_width > 0) {
      main_match_ratio = title_match_width * 1.0 / main_title_width;
      slave_match_ratio = title_match_width * 1.0 / slave_title_width;
    }
    if (main_match_ratio >= 0.6 || slave_match_ratio >= 0.6) {
      LOG_IF(INFO, FLAGS_hot_event_cluster_debug_mode)
          << "[DEBUG_SAME], title match"
          << ", main_id:" << main_item.item_id << ", main_title:" << main_item.title
          << ", match_num:" << title_match_width << ", main_ratio:" << main_match_ratio
          << ", slave_id:" << slave_item.item_id << ", slave_title:" << slave_item.title
          << ", slave_ratio:" << slave_match_ratio;
      return true;
    }
  }

  return false;
}

bool HotEventCluster::GenerateEvent(const std::vector<HotItemInfo>& hot_items,
                                    const std::vector<int>& cluster_items,
                                    base::dense_hash_set<uint64>* dedup_items,
                                    HotEventInfo* hot_event) const {
  if (hot_items.empty() || cluster_items.empty()) return false;

  const HotItemInfo& main_item = hot_items[cluster_items.at(0)];

  base::Time now = base::Time::Now();
  dedup_items->clear();
  hot_event->Clear();
  for (size_t idx = 0; idx < cluster_items.size(); ++idx) {
    const HotItemInfo& hot_item = hot_items[cluster_items.at(idx)];
    if (dedup_items->find(hot_item.item_id) == dedup_items->end()) {
      if (idx == 0) {
        hot_event->event_id = hot_item.item_id;
        hot_event->represent_item_id = hot_item.item_id;
        hot_event->represent_title = hot_item.title;
        hot_event->event_name = hot_item.title;
        hot_event->hot_score = hot_item.hot_score;
        hot_event->create_time = now;
      }
      hot_event->item_list.push_back(hot_item);
      AddToSimCluster(hot_item, dedup_items);
    } else {
      HotItemInfo sim_hot_item;
      for (auto iter = hot_item.sim_ids.begin(); iter != hot_item.sim_ids.end(); ++iter) {
        uint64 sim_id = *iter;
        if (dedup_items->find(sim_id) != dedup_items->end()) continue;
        if (!GetHotItemByItemId(sim_id, &sim_hot_item)) continue;
        if (!IsSameCluster(main_item, sim_hot_item)) continue;
        hot_event->item_list.push_back(sim_hot_item);
        AddToSimCluster(sim_hot_item, dedup_items);
        break;
      }
    }
  }

  return true;
}

inline bool HotEventCluster::GetHotItemByItemId(uint64 item_id, HotItemInfo* hot_item) const {
  hot_item->Clear();
  RecoItem reco_item;
  if (!hbase_get_item_->GetRecoItem(item_id, &reco_item)) {
    LOG(WARNING) << "item does not exist in hbase, " << item_id;
    return false;
  }
  if (!RecoItemToHotItem(reco_item, 0, hot_item)) {
    LOG(WARNING) << "do reco_item to hot_item fail, " << item_id;
    return false;
  }
  return true;
}

inline void HotEventCluster::AddToSimCluster(const HotItemInfo& hot_item,
                                             base::dense_hash_set<uint64>* cluster_items) const {
  cluster_items->insert(hot_item.item_id);
  cluster_items->insert(hot_item.sim_ids.begin(), hot_item.sim_ids.end());
}

} // namespace reco
} // namespace item_level
