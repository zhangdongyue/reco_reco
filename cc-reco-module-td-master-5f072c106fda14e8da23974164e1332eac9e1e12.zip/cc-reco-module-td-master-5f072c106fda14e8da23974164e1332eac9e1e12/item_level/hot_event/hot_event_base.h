#pragma once

#include <string>
#include <vector>
#include <unordered_map>

#include "reco/bizc/proto/item.pb.h"
#include "base/time/time.h"

namespace reco {
namespace item_level {

struct HotItemInfo {
  uint64 item_id;
  reco::ItemType item_type;
  int hot_score;
  std::string title;
  std::vector<std::string> title_unigrams;
  std::string category;
  std::string source;
  base::Time publish_time;
  std::unordered_set<uint64> sim_ids;
  std::unordered_map<std::string, float> tags;
  std::unordered_map<std::string, float> keywords;

  HotItemInfo() {
  }
  void Clear() {
    hot_score = 0;
    title.clear();
    category.clear();
    source.clear();
    title_unigrams.clear();
    sim_ids.clear();
    tags.clear();
    keywords.clear();
  }
};

struct HotEventInfo {
  uint64 event_id;
  std::string event_name;

  int hot_score;
  uint64 represent_item_id;
  std::string represent_title;

  base::Time create_time;

  std::vector<HotItemInfo> item_list;

  HotEventInfo() {
  }

  void Clear() {
    event_name.clear();
    represent_title.clear();
    item_list.clear();
  }
};

}
}
