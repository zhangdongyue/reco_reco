#pragma once

#include <unordered_map>
#include <string>
#include <vector>

#include "reco/bizc/item_service/hbase_pool_get_sim.h"
// #include "reco/bizc/item_service/hbase_pool_get_item.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/module/item_level/hot_event/hot_event_base.h"
#include "base/container/dense_hash_set.h"

namespace reco {
namespace item_level {

class HotEventCluster {
 public:
  HotEventCluster();
  ~HotEventCluster();

  // 给定热门文章列表, 对热点文章进行聚簇，得到事件列表
  void DoHotEventCluster(const std::vector<std::pair<uint64, int> >& hot_items,
                         std::vector<HotEventInfo>* hot_events);

 private:
  // 聚簇算法
  // 当期算法比较简单，通过共同 sim 和 共同 keyword 进行聚簇，需要持续优化
  void DoHotEventClusterAlg(const std::vector<HotItemInfo>& hot_items,
                            std::vector<HotEventInfo>* hot_events);
  // 通过 itemid 获取 hot item
  bool GetHotItemByItemId(uint64 item_id, HotItemInfo* hot_item) const;
  // reco item 转换成 hot item
  bool RecoItemToHotItem(const reco::RecoItem& reco_item, int hot_score,
                         HotItemInfo* hot_item) const;
  // 加入相似簇
  void AddToSimCluster(const HotItemInfo& hot_item, base::dense_hash_set<uint64>* cluster_items) const;
  // 判断两个 hot item 是否归属到同一个 event
  bool IsSameCluster(const HotItemInfo& main_item, const HotItemInfo& slave_item) const;
  // 生成簇
  // TODO(jiawei / jianhuang) 计算事件名
  bool GenerateEvent(const std::vector<HotItemInfo>& hot_items, const std::vector<int>& cluster_items,
                     base::dense_hash_set<uint64>* dedup_items, HotEventInfo* hot_event) const;
 private:
  reco::HBasePoolGetSim* hbase_get_sim_;
//  reco::HBasePoolGetItem* hbase_get_item_;
  reco::HBaseGetItem* hbase_get_item_;
};

} // namespace reco
} // namespace item_level
