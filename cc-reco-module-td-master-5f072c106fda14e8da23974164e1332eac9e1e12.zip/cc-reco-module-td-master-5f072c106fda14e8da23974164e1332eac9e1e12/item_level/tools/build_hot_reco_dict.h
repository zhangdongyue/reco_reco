#pragma once

#include <utility>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <unordered_map>
#include <unordered_set>

#include "reco/bizc/proto/common.pb.h"
#include "base/strings/utf_char_iterator.h"
#include "base/container/dense_hash_map.h"
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/common/rune_type.h"
#include "nlp/common/term_container.h"
#include "nlp/idf/idf.h"
#include "web/url/url.h"
#include "query/filter/valid_codepoint.h"
#include "reco/module/item_level/base/define.h"

namespace reco {
namespace item_level {

class HotRecoDictBuilder {
 public:
  HotRecoDictBuilder() {
  }

  ~HotRecoDictBuilder() {}

  void BuildDict(const std::string& hot_news_file, const std::string& hot_news_monitor_file);
  void BuildDictBaseHotNews(const std::string& hot_news_file);
  void BuildDictBaseHotMonitorNews(const std::string& hot_news_monitor_file);
  void WriteIndexToDisk(const std::string& index_file_name) const;

  void WriteTitleScoreToDisk(const std::string& title_score_file) const;

  void WriteTermMapToDisk(const std::string& term_map_file_name) const;

  void WriteDebugInfoToDisk(const std::string& debug_file_name) const;

 private:
  void PutToInvertedIndex(const std::string& title,
                          uint64 tit_sign,
                          const nlp::term::TermContainer& term_container);

  // title 切词,
  // 会检查 title 是否合法, 不合法时返回 false, 此时得到的 term_container 数据无效
  bool SegmentTitle(const std::string &title, nlp::term::TermContainer* term_container);

 private:
  struct TitleInfo {
    std::string literal;
    std::string news_time;
    std::string source;
    bool is_manual;
    nlp::term::TermContainer term_container;
    std::unordered_map<int32, int32> seed_type_score_dict;
    TitleInfo() {
      seed_type_score_dict.clear();
      is_manual = false;
    }
  };

 private:
  static const int kTitleMaxTermNum = 50;
  static const int kTitleMinTermNum = 3;
  static const float kAsciiTermRatio;
  static const float kCoincidenceRatio;

  std::unordered_map<uint64, TitleInfo> title_infos_;
  std::unordered_map<uint64, std::string> term_infos_;
  std::unordered_map<uint64, float> dedup_terms_;
  // 每个 term 对应的 title 及得分列表
  std::unordered_map<uint64, std::vector<std::pair<uint64, float>> > term_index_;

  nlp::idf::IdfDicts idf_dicts_;
  nlp::segment::Segmenter segmenter_;
  nlp::postag::PosTagger postagger_;
};
}
}
