#include <sys/time.h>

#include <fstream>
#include <iomanip>
#include <iostream>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "net/rpc/rpc.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/reco_search_server.pb.h"

DEFINE_string(search_server_ip, "11.251.203.136", "search server ip");
DEFINE_int32(search_server_port, 20011, "search server port");

const char kTable[] = "tb_reco_item";

reco::searchserver::GeneralSearchRequest CreateRequest(const std::string& query) {
  reco::searchserver::GeneralSearchRequest request;
  request.add_query(query);
  request.set_result_num(20);
  request.set_dedup_method(reco::kNoDedup);
  request.set_sort_method(reco::kRelevantSort);
  request.set_only_high_relevant(true);
  request.set_only_reco_index(false);
  return request;
}

// 计算汉明距离 (simhash)
int32 HammingDistance(int64 hash1, int64 hash2) {
  int64 i = hash1 ^ hash2;
  i = i - ((i >> 1) & 0x5555555555555555L);
  i = (i & 0x3333333333333333L) + ((i >> 2) & 0x3333333333333333L);
  i = (i + (i >> 4)) & 0x0f0f0f0f0f0f0f0fL;
  i = i + (i >> 8);
  i = i + (i >> 16);
  i = i + (i >> 32);
  return (int32) i & 0x7f;
}

bool CheckTimeInterval(const reco::RecoItem& first, const reco::RecoItem& second) {
  base::Time first_time, second_time;
  if (!base::Time::FromStringInFormat(first.create_time().c_str(), "%Y-%m-%d %H:%M:%S", &first_time)
     || !base::Time::FromStringInFormat(second.create_time().c_str(), "%Y-%m-%d %H:%M:%S", &second_time)) {
    return false;
  }
  base::TimeDelta delta = first_time - second_time;
  return (delta.InDays() >= 3);
}


int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "test for connect to search server");

  std::string table(kTable);
  reco::HBaseGetItem hbase_get_item(table, -1);

  net::rpc::RpcClientChannel channel(FLAGS_search_server_ip.c_str(), FLAGS_search_server_port);
  CHECK(channel.Connect());
  reco::searchserver::SearchService::Stub stub(&channel);

  uint64 item_id;
  std::cin >> item_id;
  reco::RecoItem item_result;
  bool result = hbase_get_item.GetRecoItem(item_id, &item_result);
  if (result) {
    std::cout << item_result.identity().item_id() << "\t" << item_result.title() << "\t" <<
            item_result.create_time() << "\t" << item_result.source() << std::endl;

    reco::searchserver::GeneralSearchRequest request = CreateRequest(item_result.title());
    reco::searchserver::GeneralSearchResponse response;

    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(1000);
    stub.GeneralSearch(&rpc, &request, &response, NULL);
    rpc.Wait();

    if (rpc.status() != net::rpc::RpcClientController::kOk ||
        !response.success()) {
      LOG(ERROR) << "general search failed, rpc msg: " << rpc.error_text();
      LOG(ERROR) << "response msg: " << base::StringReplace(response.Utf8DebugString(), "\n", " ", true);
      return 0;
    }

    std::vector<std::string> latest, oldest;
    for (int i = 0; i < response.result_size(); ++i) {
      reco::searchserver::SearchResult result = response.result(i);
      for (int j = 0; j < result.doc_info_size(); ++j) {
        reco::RecoItem similar;
        if (hbase_get_item.GetRecoItem(result.doc_info(j).item_id(), &similar)) {
          std::string str_id = base::Uint64ToString(similar.identity().item_id());
          int32 hm_dis = HammingDistance(item_result.raw_item().simhash(), similar.raw_item().simhash());
          std::string str_dis = base::IntToString(hm_dis);
          std::string str = str_id + "\t" + str_dis + "\t" + similar.title() + "\t"
                          + similar.create_time() + "\t" + similar.source();
          if (CheckTimeInterval(item_result, similar)) {
            oldest.push_back(str);
          } else {
            latest.push_back(str);
          }
        }
      }
    }
    std::cout << "LATEST:" << std::endl;
    for (auto it = latest.begin(); it != latest.end(); ++it) {
      std::cout << "  " << (*it) << std::endl;
    }
    std::cout << std::endl << "OLDEST:" << std::endl;
    for (auto it = oldest.begin(); it != oldest.end(); ++it) {
      std::cout << "  " << (*it) << std::endl;
    }
  }
  channel.Close();
  return 0;
}
