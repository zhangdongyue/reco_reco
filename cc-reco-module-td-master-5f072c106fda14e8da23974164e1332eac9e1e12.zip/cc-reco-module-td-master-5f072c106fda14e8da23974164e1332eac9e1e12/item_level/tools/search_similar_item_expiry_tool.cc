#include <iostream>

#include <set>
#include <string>
#include <vector>

#include "reco/module/item_level/base/connection_manager.h"
#include "reco/module/item_level/time_level/search_similar_item_expiry_calculator.h"
#include "reco/bizc/item_service/hbase_get_item.h"

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"

DEFINE_uint64(item_id, 0, "item id");
DECLARE_string(reco_item_hbase_table);

void GetRecoItem() {
  LOG(INFO) << "itemid: " << FLAGS_item_id;
  CHECK(reco::item_level::ConnectionManager::InitConnection()) << "set up connection";
  reco::HBaseGetItem* hbase = new reco::HBaseGetItem(FLAGS_reco_item_hbase_table, -1);
  reco::RecoItem source_item;
  if (!hbase->GetRecoItem(FLAGS_item_id, &source_item)) {
    LOG(ERROR) << "query failed when query source item id: " << FLAGS_item_id;
  }
  LOG(INFO) << source_item.Utf8DebugString();
}

void CheckSingleItem() {
  LOG(INFO) << "itemid: " << FLAGS_item_id;
  CHECK(reco::item_level::ConnectionManager::InitConnection()) << "set up connection";
  reco::HBaseGetItem* hbase = new reco::HBaseGetItem(FLAGS_reco_item_hbase_table, -1);
  reco::item_level::SearchSimilarItemExpiryCalculator item_expiry_calculator(hbase);
  reco::RecoItem source_item;
  reco::RecoItem similar_item;
  bool is_expiry = item_expiry_calculator.IsExpiryItem(FLAGS_item_id, &source_item, &similar_item);
  if (is_expiry) {
    LOG(INFO) << " is expiry item.";
    LOG(INFO) << "itemid: " << FLAGS_item_id;
    LOG(INFO) << "title: " << source_item.title();
    LOG(INFO) << "is simialr to item: " << similar_item.identity().item_id();
    LOG(INFO) << "title: " << similar_item.title();
  } else {
    LOG(INFO) << " is NOT expiry item.";
    LOG(INFO) << "title: " << source_item.title();
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "search similar item expiry calculator");
  GetRecoItem();
  CheckSingleItem();
  return 0;
}
