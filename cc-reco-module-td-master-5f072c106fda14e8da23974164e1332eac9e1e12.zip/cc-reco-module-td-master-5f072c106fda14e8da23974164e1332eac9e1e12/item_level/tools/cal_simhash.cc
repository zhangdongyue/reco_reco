#include <iostream>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"

#include "reco/module/item_level/time_level/text_similarity.h"

const std::string table = "tb_reco_item";

using std::cout;
using std::endl;

int32 hammingDistance(int64 hash1, int64 hash2) {
  int64 i = hash1 ^ hash2;
  i = i - ((i >> 1) & 0x5555555555555555L);
  i = (i & 0x3333333333333333L) + ((i >> 2) & 0x3333333333333333L);
  i = (i + (i >> 4)) & 0x0f0f0f0f0f0f0f0fL;
  i = i + (i >> 8);
  i = i + (i >> 16);
  i = i + (i >> 32);
  return (int32) i & 0x7f;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "Image Simhash Hamming Distance");

  reco::HBaseGetItem hbase_get_item(table, -1);

  reco::RecoItem item_1;
  reco::RecoItem item_2;
  uint64 item_id_1, item_id_2;

  std::cin >> item_id_1 >> item_id_2;
  bool result_1 = hbase_get_item.GetRecoItem(item_id_1, &item_1);
  bool result_2 = hbase_get_item.GetRecoItem(item_id_2, &item_2);

  if (!result_1 || !result_2) {
    cout << "get failed" << endl;
  } else {
    cout << "Title: " << item_1.title() << "\tType: " << item_1.identity().type() << endl;
    cout << "Title: " << item_2.title() << "\tType: " << item_2.identity().type() << endl;
    if (item_1.has_raw_item() && item_2.has_raw_item()) {
      if (item_1.raw_item().has_simhash() && item_2.raw_item().has_simhash()) {
        std::cout << "content difference: "
                  << hammingDistance(item_1.raw_item().simhash(), item_2.raw_item().simhash()) << std::endl;
      }
      std::cout << "P1: " << item_1.raw_item().paragraph_simhash_size() << "\t"
                << "P2: " << item_2.raw_item().paragraph_simhash_size() << std::endl;
    }
    std::cout << "img cnt 1: " << item_1.image_size();
    if (item_1.has_raw_item()) {
      int zero_count = 0;
      for (int i = 0; i < item_1.raw_item().image_size() && item_1.raw_item().image(i).has_simhash(); ++i) {
        if (item_1.raw_item().image(i).simhash() == 0) {
          ++zero_count;
        }
      }
      std::cout << "\tzero count: " << zero_count << std::endl;
    } else {
      std::cout << std::endl;
    }

    std::cout << "img cnt 2: " << item_2.image_size();
    if (item_2.has_raw_item()) {
      int zero_count = 0;
      for (int i = 0; i < item_2.raw_item().image_size() && item_2.raw_item().image(i).has_simhash(); ++i) {
        if (item_2.raw_item().image(i).simhash() == 0) {
          ++zero_count;
        }
      }
      std::cout << "\tzero count: " << zero_count << std::endl;
    } else {
      std::cout << std::endl;
    }

    if (item_1.has_raw_item() && item_2.has_raw_item()) {
      for (int i = 0; i < item_1.raw_item().image_size() && item_1.raw_item().image(i).has_simhash(); ++i) {
        int32 min_hash = 0x3f3f3f3f;
        for (int j = 0; j < item_2.raw_item().image_size() && item_2.raw_item().image(j).has_simhash(); ++j) {
          std::cout
            << hammingDistance(item_1.raw_item().image(i).simhash(), item_2.raw_item().image(j).simhash())
            << " ";
          min_hash = std::min(min_hash, hammingDistance(item_1.raw_item().image(i).simhash(),
                                                       item_2.raw_item().image(j).simhash()));
        }
        std::cout << "\tMIN: " <<  min_hash <<  std::endl;
      }
    }
  }
  return 0;
}
