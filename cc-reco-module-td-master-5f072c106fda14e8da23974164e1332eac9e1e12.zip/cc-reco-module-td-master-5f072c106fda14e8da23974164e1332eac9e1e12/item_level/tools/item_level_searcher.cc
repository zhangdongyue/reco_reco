#include <iostream>

#include "reco/module/item_level/base.h"
#include "rpc/redis/client.h"

#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"
#include "base/time/timestamp.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"

DEFINE_string(redis_ip, "127.0.0.1", "redis server ip");
DEFINE_int32(redis_port, 6379, "redis_server port");
DEFINE_string(item_id, "", "");
int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "");
  redis::Client* redis_client = new redis::Client(FLAGS_redis_ip, FLAGS_redis_port);
  CHECK(redis_client->Connect());

  std::string key = base::StringPrintf("%s%s", reco::item_level::kItemRedisKeyPrefix, FLAGS_item_id.c_str());

  std::map<std::string, std::string> field_values;
  int redis_response = redis_client->HashGetAllFields(key.c_str(), key.length(), &field_values);
  if (redis_response != 0) {
    LOG(ERROR) << "get data from redis fail, key: " << key;
    return 1;
  }

  for (auto iter = field_values.begin(); iter != field_values.end(); ++iter) {
    std::cout << iter->first << ": " << iter->second << std::endl;
  }

  return 0;
}
