#include <iostream>
#include <fstream>
#include <unordered_map>

#include "serving_base/mysql_util/db_conn_manager.h"

#include "base/common/logging.h"
#include "base/common/base.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/hash_function/term.h"

DEFINE_string(site_level_file, "", "");
DEFINE_string(db_host, "tcp://192.168.11.162:3306", "mysql host name");
DEFINE_string(db_user, "root", "mysql user name");
DEFINE_string(db_passwd, "chuheridangwu", "mysql user password");
DEFINE_string(db_schema, "test", "dbname");

namespace reco {
namespace item_level {

void LoadSiteLevelDict(const std::string& file_path, std::unordered_map<int, int>* site_level_dict) {
  site_level_dict->clear();

  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(file_path, &lines)) << file_path;

  int seed;
  int score;
  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() != 2u) {
      LOG(ERROR) << "site level format error, " << lines[i];
      continue;
    }
    if (!base::StringToInt(flds[0], &seed)) {
      LOG(ERROR) << "seed id format error, " << lines[i];
      continue;
    }
    if (!base::StringToInt(flds[1], &score)) {
      LOG(ERROR) << "seed score format error, " << lines[i];
      continue;
    }
    score = std::min(2, score);
    site_level_dict->insert(std::make_pair(seed, score));
  }
}

void UpdateSiteLevelToDB(const std::unordered_map<int, int>& site_level_dict) {
  serving_base::mysql_util::DbConnManager::Option option;
  option.host = FLAGS_db_host;
  option.schema = FLAGS_db_schema;
  option.user = FLAGS_db_user;
  option.passwd = FLAGS_db_passwd;

  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(option);
  CHECK(db_manager->CheckConnection());
  LOG(INFO) << "db connected.";

  std::string sql;
  for (auto iter = site_level_dict.begin(); iter != site_level_dict.end(); ++iter) {
    sql = base::StringPrintf("update tb_seed set `authority_score`=%d where `id`=%d",
                             iter->second, iter->first);
    LOG(INFO) << "sql: " << sql;
    if (!db_manager->ExecuteSQLWithRetry(sql, 3)) {
      LOG(ERROR) << "excute sql error, sql is: " << sql;
    }
  }

  delete db_manager;
}
}
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "build term->query inverted index");

  std::unordered_map<int, int> site_level_dict;
  reco::item_level::LoadSiteLevelDict(FLAGS_site_level_file, &site_level_dict);
  LOG(INFO) << "total record, " << site_level_dict.size();

  reco::item_level::UpdateSiteLevelToDB(site_level_dict);

  return 0;
}

