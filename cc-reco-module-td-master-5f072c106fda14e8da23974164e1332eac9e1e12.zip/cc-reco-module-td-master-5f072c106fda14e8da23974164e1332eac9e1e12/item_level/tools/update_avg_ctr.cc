#include <iostream>
#include <fstream>
#include <unordered_map>
#include <unordered_set>

#include "serving_base/mysql_util/db_conn_manager.h"

#include "rpc/redis/client_pool.h"
#include "rpc/redis/client.h"

#include "base/common/logging.h"
#include "base/common/base.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/hash_function/term.h"

DEFINE_string(db_host, "tcp://10.99.48.74:3306", "mysql host name");
DEFINE_string(db_user, "recodev", "mysql user name");
DEFINE_string(db_passwd, "tkDn19DHeVZkNA", "mysql user password");
DEFINE_string(db_schema, "reco", "dbname");

DEFINE_string(redis_ip, "10.99.20.43", "redis server ip");
DEFINE_int32(redis_port, 6379, "redis_server port");

DEFINE_string(start_date, "2014-12-25", "start date");
DEFINE_string(end_date, "2014-12-28", "end date");

DEFINE_string(item_result_file, "", "");
DEFINE_string(category_result_file, "", "");

namespace reco {
namespace item_level {

struct ItemData {
  uint64 item_id;
  std::string category;
  int item_type;
  int show_num;
  int click_num;
  ItemData() : item_id(0), category(""), item_type(0), show_num(0), click_num(0) {}
};

void ReadItemIdList(const std::string& start_date, const std::string& end_date,
                    std::vector<ItemData>* item_list) {
  item_list->clear();

  serving_base::mysql_util::DbConnManager::Option option;
  option.host = FLAGS_db_host;
  option.schema = FLAGS_db_schema;
  option.user = FLAGS_db_user;
  option.passwd = FLAGS_db_passwd;

  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(option);
  CHECK(db_manager->CheckConnection());
  LOG(INFO) << "db connected.";

  std::string sql = base::StringPrintf("select item_id,category,item_type from tb_item_info"
                                       " where is_valid=1 and create_time>='%s' and create_time<='%s'",
                                       start_date.c_str(), end_date.c_str());
  LOG(INFO) << sql;
  sql::ResultSet* resultSet = db_manager->ExecuteQueryWithRetry(sql, 3);
  CHECK_NOTNULL(resultSet);
  resultSet->beforeFirst();
  ItemData item_info;
  std::vector<std::string> flds;
  while (resultSet->next()) {
    item_info.item_id = resultSet->getUInt64("item_id");
    item_info.category = resultSet->getString("category");
    flds.clear();
    base::SplitString(item_info.category, ",", &flds);
    if (flds.size() > 1u) {
      item_info.category = flds[0];
    }
    item_info.item_type = resultSet->getInt("item_type");
    item_list->push_back(item_info);
  }

  delete db_manager;
}

void BatchUpdateItemStatInfos(std::vector<ItemData>* item_list) {
  redis::ClientPool *redis_client_pool;
  redis::GenerateMultiRedisConnect(FLAGS_redis_ip, FLAGS_redis_port, 5);
  redis_client_pool = redis::GetClientPool(FLAGS_redis_ip, FLAGS_redis_port);

  CHECK_NOTNULL(redis_client_pool);

  redis::AutoPutback redis(redis_client_pool);
  redis::Client* client = redis.TimedTake(10);
  CHECK(client != NULL) << "redis time take error.";

  for (int i = 0; i < (int)item_list->size(); ++i) {
    ItemData& info = item_list->at(i);
    std::map<std::string, std::string> field_values;
    std::string key = base::StringPrintf("ItemLevel-%lu", info.item_id);
    int redis_response = client->HashGetAllFields(key.c_str(), key.length(), &field_values);
    if (redis_response != 0) {
      continue;
    }
    auto iter = field_values.find("ShowCount");
    if (iter != field_values.end()) {
      if (!base::StringToInt(iter->second, &info.show_num) || info.show_num < 0) {
        LOG(ERROR) << "error show format, " << iter->second;
        info.show_num = 0;
        continue;
      }
    }

    iter = field_values.find("ClickCount");
    if (iter != field_values.end()) {
      if (!base::StringToInt(iter->second, &info.click_num) || info.click_num < 0) {
        LOG(ERROR) << "error click format, " << iter->second;
        info.click_num = 0;
        continue;
      }
    }

    info.click_num = std::min(info.click_num, info.show_num);
  }
}

void WriteItemResult(const std::vector<ItemData>& item_list,
                     const std::string& item_result_file) {
  std::ofstream os(item_result_file);
  for (int i = 0; i < (int)item_list.size(); ++i) {
    const ItemData& data = item_list.at(i);
    os << base::StringPrintf("%lu\t%s\t%d\t%d\t%d\n",
                             data.item_id, data.category.c_str(), data.item_type,
                             data.show_num, data.click_num);
  }
  os.close();
}

static bool remain_category(const std::string& category) {
  static std::string remain_categories[] = {
    "两性情感", "体育", "健康", "军事", "历史", "国内", "国际", "地方", "奇闻", "娱乐", "幽默",
    "干货", "彩票", "房产", "摄影", "教育", "旅游", "时尚", "未分类", "汽车", "游戏", "留学",
    "社会", "科学探索", "科技", "移民", "美女写真", "美食", "职场", "育儿", "财经", "社会"
  };
  static bool first = true;
  static std::unordered_set<std::string> remain_category_set;
  if (first) {
    for (size_t idx = 0; idx < ARRAYSIZE_UNSAFE(remain_categories); ++idx) {
      remain_category_set.insert(remain_categories[idx]);
    }
    first = false;
  }
  return (remain_category_set.find(category) != remain_category_set.end());
}

void WriteCategoryResult(const std::vector<ItemData>& item_list,
                         const std::string& category_result_file) {
  std::unordered_map<std::string, std::pair<uint64, uint64> > category_stats;
  int error_num = 0;
  for (int i = 0; i < (int)item_list.size(); ++i) {
    const ItemData& data = item_list.at(i);
    if (!remain_category(data.category)) {
      ++error_num;
      continue;
    }
    std::pair<uint64, uint64>& stats = category_stats[data.category];
    stats.first += data.show_num;
    stats.second += data.click_num;
  }
  LOG(INFO) << "error category num: " << error_num;

  std::ofstream os(category_result_file);
  for (auto iter = category_stats.begin(); iter != category_stats.end(); ++iter) {
    const std::string& category = iter->first;
    uint64 show_num = iter->second.first;
    uint64 clk_num  = iter->second.second;
    float ctr = 0;
    if (show_num > 0) ctr = clk_num * 1.0 / show_num;
    os << base::StringPrintf("%s\t%.4f\t%lu\t%lu\n",
                             category.c_str(), ctr, show_num, clk_num);
  }
  os.close();
}
}
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "build term->query inverted index");

  LOG(INFO) << "begin to read item list, " << FLAGS_start_date << ", " << FLAGS_end_date;
  std::vector<reco::item_level::ItemData> item_list;
  reco::item_level::ReadItemIdList(FLAGS_start_date, FLAGS_end_date, &item_list);
  LOG(INFO) << "finish to read item list, " << item_list.size();

  LOG(INFO) << "begin to update item stats.";
  reco::item_level::BatchUpdateItemStatInfos(&item_list);
  LOG(INFO) << "finish to update item stats.";

  if (!FLAGS_item_result_file.empty()) {
    LOG(INFO) << "begin to write item result.";
    reco::item_level::WriteItemResult(item_list, FLAGS_item_result_file);
    LOG(INFO) << "finish to write item result.";
  }

  if (!FLAGS_category_result_file.empty()) {
    LOG(INFO) << "begin to write category result.";
    reco::item_level::WriteCategoryResult(item_list, FLAGS_category_result_file);
    LOG(INFO) << "finish to write category result.";
  }

  return 0;
}

