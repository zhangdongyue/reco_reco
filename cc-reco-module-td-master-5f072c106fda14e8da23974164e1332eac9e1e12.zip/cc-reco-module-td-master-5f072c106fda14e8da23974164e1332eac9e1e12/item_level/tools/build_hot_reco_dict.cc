#include "reco/module/item_level/tools/build_hot_reco_dict.h"

#include <algorithm>

#include "base/common/logging.h"
#include "base/common/base.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/hash_function/term.h"

DEFINE_string(hot_news_file, "", "");
DEFINE_string(hot_news_monitor_file, "", "");
DEFINE_string(index_title_file, "", "");
DEFINE_string(title_score_file, "", "title score, title_id\tscore\ttitle");
DEFINE_string(debug_file, "", "");

namespace reco {
namespace item_level {

const float HotRecoDictBuilder::kAsciiTermRatio = 0.8;
const float HotRecoDictBuilder::kCoincidenceRatio = 0.6;

void HotRecoDictBuilder::BuildDictBaseHotMonitorNews(const std::string& hot_news_monitor_file) {
  std::string title;
  nlp::term::TermContainer term_container;
  std::vector<std::string> lines, cols;
  base::FilePath file(hot_news_monitor_file);
  CHECK(base::file_util::ReadFileToLines(file, &lines));
  for (int i  = 0; i < (int)lines.size(); ++i) {
    cols.clear();
    base::SplitString(lines[i], "\t", &cols);
    if (cols.size() < 6u) {
      LOG(ERROR) << "cols num error, line is: " << lines[i];
      continue;
    }
    int32 seed_type;
    if (!base::StringToInt(cols[5], &seed_type)) continue;
    const std::string& news_time = cols[4];
    title = nlp::util::NormalizeLine(cols[0]);
    uint64 tit_sign = base::CalcTermSign(title.data(), title.length());
    auto iter = title_infos_.find(tit_sign);
    if (iter == title_infos_.end()) {
      TitleInfo info;
      info.literal = title;
      info.news_time = news_time;
      info.source = nlp::util::NormalizeLine(cols[2]);
      info.is_manual = false;
      info.seed_type_score_dict.insert(std::make_pair(seed_type, 1));
      if (!SegmentTitle(info.literal, &info.term_container)) {
        LOG(ERROR) << "SegmentTitle error, line is: " << lines[i];
        continue;
      }
      title_infos_.insert(std::make_pair(tit_sign, info));
    } else {
      iter->second.news_time = std::min(iter->second.news_time, news_time);
      auto seed_type_iter = iter->second.seed_type_score_dict.find(seed_type);
      if (seed_type_iter == iter->second.seed_type_score_dict.end()) {
        seed_type_iter = iter->second.seed_type_score_dict.insert(std::make_pair(seed_type, 0)).first;
      }
      seed_type_iter->second += 1;
      iter->second.is_manual = false;
    }
  }

  LOG(INFO) << "uniq title size: " << title_infos_.size();
}


void HotRecoDictBuilder::BuildDictBaseHotNews(const std::string& hot_news_file) {
  std::string title;
  nlp::term::TermContainer term_container;
  double score;
  std::vector<std::string> lines, cols;
  base::FilePath file(hot_news_file);
  CHECK(base::file_util::ReadFileToLines(file, &lines));
  for (int i  = 0; i < (int)lines.size(); ++i) {
    cols.clear();
    base::SplitString(lines[i], "\t", &cols);
    if (cols.size() < 5u) {
      LOG(ERROR) << "cols num error, line is: " << lines[i];
      continue;
    }
    if (!base::StringToDouble(cols[1], &score)) {
      LOG(ERROR) << "StringToDouble error, line is: " << lines[i];
      continue;
    }
    int32 seed_type = kHotNews;
    bool is_manual = false;
    if (score >= 3) {
      is_manual = true;
      seed_type = kManual;
    }
    const std::string& news_time = cols[4];
    title = nlp::util::NormalizeLine(cols[0]);
    uint64 tit_sign = base::CalcTermSign(title.data(), title.length());
    auto iter = title_infos_.find(tit_sign);
    if (iter == title_infos_.end()) {
      TitleInfo info;
      info.literal = title;
      info.news_time = news_time;
      info.source = nlp::util::NormalizeLine(cols[2]);
      info.is_manual = is_manual;
      info.seed_type_score_dict.insert(std::make_pair(kHotNews, 1));
      if (!SegmentTitle(info.literal, &info.term_container)) {
        LOG(ERROR) << "SegmentTitle error, line is: " << lines[i];
        continue;
      }
      title_infos_.insert(std::make_pair(tit_sign, info));
    } else {
      iter->second.news_time = std::min(iter->second.news_time, news_time);
      auto seed_type_iter = iter->second.seed_type_score_dict.find(kHotNews);
      seed_type_iter->second += 1;
      if (is_manual) {
        iter->second.is_manual = true;
      }
    }
  }

  LOG(INFO) << "uniq title size: " << title_infos_.size();
}

void HotRecoDictBuilder::BuildDict(const std::string& hot_news_file,
                                   const std::string& hot_news_monitor_file) {
  BuildDictBaseHotNews(hot_news_file);
  BuildDictBaseHotMonitorNews(hot_news_monitor_file);
}

void HotRecoDictBuilder::WriteIndexToDisk(const std::string& index_file_name) const {
  std::ofstream os(index_file_name.c_str());
  for (auto it = term_index_.begin(); it != term_index_.end(); ++it) {
    const std::vector<std::pair<uint64, float> >& vec = it->second;
    os << it->first;
    for (int i = 0; i < (int)vec.size(); ++i) {
      os << base::StringPrintf("\t%lu:%.2f", vec[i].first, vec[i].second);
    }
    os << std::endl;
  }
  os.close();
}

void HotRecoDictBuilder::WriteTitleScoreToDisk(const std::string& title_score_file_name) const {
  std::ofstream os(title_score_file_name.c_str());
  for (auto iter = title_infos_.begin(); iter != title_infos_.end(); ++iter) {
    const TitleInfo& info = iter->second;
    std::string seed_score_str = "";
    for (auto seed_iter = info.seed_type_score_dict.begin();
         seed_iter != info.seed_type_score_dict.end(); ++seed_iter) {
      if (seed_iter != info.seed_type_score_dict.begin()) seed_score_str += ",";
      seed_score_str += base::IntToString(seed_iter->first) + ":" + base::IntToString(seed_iter->second);
    }
    os << iter->first << "\t" << info.news_time << "\t"<< info.is_manual << "\t"
       << info.source << "\t" << info.literal << "\t" << seed_score_str;
    if (iter != title_infos_.end()) {
      os << std::endl;
    }
  }
  os.close();
}

void HotRecoDictBuilder::WriteDebugInfoToDisk(const std::string& debug_file_name) const {
  std::ofstream os(debug_file_name.c_str());
  for (auto it = term_index_.begin(); it != term_index_.end(); ++it) {
    auto term_it = term_infos_.find(it->first);
    CHECK(term_it != term_infos_.end());
    os << term_it->second;
    const std::vector<std::pair<uint64, float> >& vec = it->second;
    for (int i = 0; i < (int)vec.size(); ++i) {
      auto title_it = title_infos_.find(vec[i].first);
      CHECK(title_it != title_infos_.end());
      os << "\t" << title_it->second.literal << "(" << vec[i].second << ")";
    }
    os << std::endl;
  }
}

void HotRecoDictBuilder::PutToInvertedIndex(const std::string& title,
                                            uint64 tit_sign,
                                            const nlp::term::TermContainer& term_container) {
  dedup_terms_.clear();
  float idf = 0, accu_idf = 0;
  for (int i = 0; i < term_container.basic_term_num(); ++i) {
    const nlp::term::TermInfo& term_info = term_container.basic_term_info(i);
    // 空格及标点符号不进入倒排
    if (term_info.is_postag(nlp::term::kWhiteSpace) ||
        term_info.is_postag(nlp::term::kPunctuation)) {
      continue;
    }
    // 单字英文不进倒排
    if (base::IsStringASCII(term_info.term(title)) &&
        base::GetUTF8CharNumOrDie(term_info.term(title)) == 1) {
      continue;
    }
    const base::Slice& term_slice = term_info.term(title);
    uint64 term_sign = base::CalcTermSign(term_slice.data(), term_slice.length());
    // 多个相同的 term 只建立一次索引
    if (dedup_terms_.find(term_sign) != dedup_terms_.end()) continue;
    // 保存好该 term 的 idf 值
    idf = static_cast<float>(idf_dicts_.get_idf(term_slice, nlp::idf::IdfDicts::kTitle));
    accu_idf += idf;
    dedup_terms_.insert(std::make_pair(term_sign, idf));
    auto term_it = term_infos_.find(term_sign);
    if (term_it ==  term_infos_.end()) {
      term_infos_.insert(std::make_pair(term_sign, term_slice.as_string()));
    }
  }

  if (accu_idf <= 0 || dedup_terms_.empty()) return;

  // 建立针对该 title 对应 term 的索引
  for (auto dedup_it = dedup_terms_.begin(); dedup_it != dedup_terms_.end(); ++dedup_it) {
    idf = dedup_it->second / accu_idf;
    auto it = term_index_.find(dedup_it->first);
    if (it == term_index_.end()) {
      term_index_.insert(std::make_pair(dedup_it->first, std::vector<std::pair<uint64, float> >()));
      term_index_[dedup_it->first].push_back(std::make_pair(tit_sign, idf));
    } else {
      it->second.push_back(std::make_pair(tit_sign, idf));
    }
  }
}

bool HotRecoDictBuilder::SegmentTitle(const std::string& title,
                                      nlp::term::TermContainer* term_container) {
  // 1, 编码检查
  int char_num = 0;
  if (!base::GetUTF8CharNum(title, &char_num)) {
    LOG(INFO) << title << " contain not utf8 char " << char_num;
    return false;
  }
  // 2. 乱码检查
  // 3, 不能是 url
  if (base::IsStringASCII(title) && GURL(title).is_valid()) {
    LOG(INFO) << title << " is a url";
    return false;
  }
  // 4. 切词是否成功
  if (!segmenter_.SegmentT(title, term_container) ||
      !postagger_.PosTagT(title, term_container)) {
    LOG(INFO) << title << " segment error!";
    return false;
  }
  // 5. 字数检查
  int term_num = term_container->basic_term_num();
  if (term_num > kTitleMaxTermNum || term_num < kTitleMinTermNum) {
    LOG(INFO) << title << " is too long or too short, term num is: " << term_num;
    return false;
  }
  // 6. 空格及标点符号为无用字符
  int unused_term_num = 0;
  for (int i =0; i < term_num; ++i) {
    const nlp::term::TermInfo& term_info = term_container->basic_term_info(i);
    if (term_info.is_postag(nlp::term::kWhiteSpace) ||
        term_info.is_postag(nlp::term::kPunctuation)) {
      ++unused_term_num;
    }
  }
  if (unused_term_num > term_num * kAsciiTermRatio) {
    LOG(INFO) << title << " too much unused_term!";
    return false;
  }

  return true;
}

}
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "build term->query inverted index");

  reco::item_level::HotRecoDictBuilder builder;

  CHECK(!FLAGS_hot_news_file.empty());
  CHECK(!FLAGS_index_title_file.empty());
  CHECK(!FLAGS_title_score_file.empty());
  CHECK(!FLAGS_hot_news_monitor_file.empty());

  builder.BuildDict(FLAGS_hot_news_file, FLAGS_hot_news_monitor_file);

  builder.WriteIndexToDisk(FLAGS_index_title_file);

  builder.WriteTitleScoreToDisk(FLAGS_title_score_file);

  if (!FLAGS_debug_file.empty()) {
    builder.WriteDebugInfoToDisk(FLAGS_debug_file);
  }

  return 0;
}

