#include <string>
#include <set>
#include <unordered_set>
#include <fstream>
#include <iostream>
#include "nlp/common/nlp_util.h"
#include "nlp/common/rune_type.h"
#include "nlp/segment/internal/segment_model.h"
#include "extend/static_dict/darts_clone/darts_clone.h"
#include "base/common/slice.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/gflags_completions.h"
#include "base/common/base.h"
#include "base/mapreduce/mapreduce.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/file/file_stream.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_number_conversions.h"
#include "base/encoding/line_escape.h"
#include "reco/bizc/proto/log.pb.h"
#include "rpc/redis/client.h"
#include "rpc/redis/client_pool.h"

DEFINE_bool(mapper, true, "is mapper");
DEFINE_int64(channel, 100, "channel id");
DEFINE_int32(max_view_time, 300, "channel id");

DEFINE_string(redis_ip, "10.3.5.70", "redis server ip");
DEFINE_int32(redis_port, 6379, "redis_server port");

DEFINE_bool(save_to_redis, false, "save result to redis");
DEFINE_int32(redis_record_expire_second, 3600*24, "time interval to inc update item info in seconds.");


void split_kv(const std::string& line, std::string* key, std::string* value) {
  std::vector<std::string> flds;
  base::SplitStringWithMoreOptions(line, "\t", false, false, 1, &flds);
  if (flds.size() == 2u) {
    *key = flds[0];
    *value = flds[1];
  } else if (flds.size() == 1u) {
    *key = flds[0];
    value->clear();
  } else {
    CHECK(false);
  }
}

void mapper() {
  std::string key;
  std::string value;
  std::string line;
  while (std::getline(std::cin, line)) {
    base::TrimTrailingWhitespaces(&line);
    split_kv(line, &key, &value);
    if (key.empty()) continue;

    std::string line;
    if (!base::LineUnescape(value, &line)) {
      LOG(ERROR) << "log unescape failed";
      continue;
    }

    reco::ServerLog server_log;
    if (!server_log.ParseFromString(line)) {
      LOG(ERROR) << "parse proto failed";
      continue;
    }

    // show log
    if (server_log.head().log_type() == reco::kLeafServer) {
      reco::LeafServerLogBody body;
      if (!body.ParseFromString(server_log.body())) {
        LOG(ERROR) << "failed to parse body";
        continue;
      }

      uint64 user_id = body.user().identity().user_id();
      if (user_id == 0) continue;
      std::string user_id_str = base::Uint64ToString(user_id);

      for (int i = 0; i < body.misc_info_size(); ++i) {
        uint64 item_id = 0;
        if (!base::StringToUint64(body.misc_info(i).item_id(), &item_id)) {
          LOG(ERROR) << "error item id: " << body.misc_info(i).item_id();
          continue;
        }

        // item_id, show, user_id
        std::cout << item_id << "\tshow\t" << user_id_str << std::endl;
      }
    } else if (server_log.head().log_type() == reco::kClickServer) {
      reco::ClickServerLogBody body;
      if (!body.ParseFromString(server_log.body())) {
        LOG(ERROR) << "failed to parse body";
        continue;
      }

      uint64 item_id;
      if (!base::StringToUint64(body.clicked_item_id(), &item_id)) continue;
      const std::string& item_id_str = body.clicked_item_id();
      if (item_id_str.empty()) continue;

      uint64 user_id = body.user().identity().user_id();
      if (user_id == 0) {
        LOG(ERROR) << "uid == 0";
        continue;
      }
      std::string user_id_str = base::Uint64ToString(user_id);

      int read_tm = std::max(1, std::min(body.view_duration(), FLAGS_max_view_time));
      if (read_tm < 3) {
        LOG(ERROR) << "filter show read";
        continue;
      }
      std::string read_tm_str = base::IntToString(read_tm);
      if (read_tm_str.empty()) continue;

      // item_id, click, user_id, read_tm
      std::cout << item_id_str << "\tclick\t" << user_id_str << "\t" << read_tm_str << std::endl;
    } else if (server_log.head().log_type() == reco::kApiServer) {
      reco::ApiServerLogBody body;
      if (!body.ParseFromString(server_log.body())) {
        LOG(ERROR) << "failed to parse body";
        continue;
      }

      // if (!body.has_action_type() || !body.has_item_id()) {
      //   continue;
      // }
      // LOG(INFO) << "here";


      // uint64 user_id = body.user().user_id();
      // if (user_id == 0) {
      //   LOG(ERROR) << "user id == 0";
      //   continue;
      // }
      // std::string user_id_str = base::Uint64ToString(user_id);

      if (body.has_wa_log() && !body.wa_log().empty()) {
        std::vector<std::string> flds;
        std::vector<std::string> tmp;
        base::SplitString(body.wa_log(), "`", &flds);
        std::map<std::string, std::string> kv;
        for (int i = 0; i < (int)flds.size(); ++i) {
          tmp.clear();
          base::SplitString(flds[i], "=", &tmp);
          if (tmp.size() != 2 || tmp[1].empty()) continue;
          if (tmp[0] != "sn" && tmp[0] != "ev_ac" && tmp[0] != "ck_id") continue;
          kv[tmp[0]] = tmp[1];
        }

        std::string act;
        uint64 item_id = 0;
        if (!kv.empty()) {
          if (kv["ev_ac"] == "分享") {
            if (!base::StringToUint64(kv["ck_id"], &item_id)) {
              item_id = 0;
            } else {
              act = "share";
            }
          } else if (kv["ev_ac"] == "加入收藏") {
            if (!base::StringToUint64(kv["ck_id"], &item_id)) {
              item_id = 0;
            } else {
              act = "fav";
            }
          }
        }
        if (!act.empty() && item_id != 0) {
          std::string user_id_str = kv["sn"];
          if (user_id_str.empty()) continue;
          std::cout << base::Uint64ToString(item_id) << "\t" << act << "\t" << user_id_str << std::endl;
        }
      }

      // switch (body.action_type()) {
      //   case reco::kFavorite:
      //     // item_id, fav, user_id
      //     std::cout << item_id_str << "\tfav\t" << user_id_str << std::endl;
      //     break;
      //   case reco::kShare:
      //     // item_id, share, user_id
      //     std::cout << item_id_str << "\tshare\t" << user_id_str << std::endl;
      //     break;
      //   default:
      //     break;
      // }
    }
  }
}

void save_to_redis(const std::string& item_id,
                   const std::string& field,
                   int64 count, redis::ClientPool *redis_client_pool) {
  redis::AutoPutback redis(redis_client_pool);
  redis::Client* client = redis.TimedTake(10);
  if (client == NULL) {
    LOG(FATAL) << "time take redis client fail.";
    return;
  }

  std::string key = "ItemLevel-" + item_id;
  std::string val = base::Int64ToString(count);
  if (!client->HashSetEx(key.c_str(), key.size(), field.c_str(), field.size(),
                         val.c_str(), val.size(), FLAGS_redis_record_expire_second)) {
    LOG(ERROR) << "write sitelevel error, key: " << key << ", val: " << val;
  }
}

void reduce_output(const std::string& key, std::set<std::string>* show,
                   std::map<std::string, int64>* click, std::set<std::string>* fav,
                   std::set<std::string>* share, redis::ClientPool *redis_client_pool) {
  static const std::string kClickCountField = "ClickCount";
  static const std::string kFavouriteCountField = "FavouriteCount";
  static const std::string kShowCountField = "ShowCount";
  static const std::string kShareCountField = "ShareCount";
  static const std::string kReadTimeCountField = "ReadTimeCount";

  // share 和 fav 直接输出 uv
  if (!share->empty()) {
    std::cout << key << "\tshare\t" << share->size() << std::endl;
    if (FLAGS_save_to_redis) {
      save_to_redis(key, kShareCountField, share->size(), redis_client_pool);
    }
  }
  if (!fav->empty()) {
    std::cout << key << "\tfav\t" << fav->size() << std::endl;
    if (FLAGS_save_to_redis) {
      save_to_redis(key, kFavouriteCountField, fav->size(), redis_client_pool);
    }
  }
  if (!show->empty()) {
    std::cout << key << "\tshow\t" << show->size() << std::endl;
    if (FLAGS_save_to_redis) {
      save_to_redis(key, kShowCountField, show->size(), redis_client_pool);
    }
  }

  if (!click->empty()) {
    int64 read_tm = 0;
    int64 uv = 0;
    for (auto it = click->begin(); it != click->end(); ++it) {
      // click 必须能够找到 show
      if (show->find(it->first) == show->end()) continue;
      ++uv;
      read_tm += it->second;
    }
    if (uv > 0 && read_tm > 0) {
      std::cout << key << "\tclick\t" << uv << std::endl;
      std::cout << key << "\tread\t" << read_tm << std::endl;
      if (FLAGS_save_to_redis) {
        save_to_redis(key, kClickCountField, uv, redis_client_pool);
        save_to_redis(key, kReadTimeCountField, read_tm, redis_client_pool);
      }
    }
  }
  show->clear();
  click->clear();
  fav->clear();
  share->clear();
}

void reducer() {
  std::string line;
  std::string key;
  std::string value;
  std::vector<std::string> flds;

  redis::ClientPool *redis_client_pool = NULL;
  if (FLAGS_save_to_redis) {
    redis::GenerateMultiRedisConnect(FLAGS_redis_ip, FLAGS_redis_port, 5);
    redis_client_pool = redis::GetClientPool(FLAGS_redis_ip, FLAGS_redis_port);
  }

  // user deduped actions
  std::set<std::string> show;
  std::map<std::string, int64> click;
  std::set<std::string> fav;
  std::set<std::string> share;

  std::string last_key;
  while (std::getline(std::cin, line)) {
    base::TrimTrailingWhitespaces(&line);
    split_kv(line, &key, &value);

    if (!last_key.empty() && key != last_key) {
      reduce_output(last_key, &show, &click, &fav, &share, redis_client_pool);
    }

    // item_id, show, user_id
    // item_id, fav, user_id
    // item_id, share, user_id
    // item_id, click, user_id, read_tm
    flds.clear();
    base::SplitString(value, "\t", &flds);
    CHECK(flds.size() == 2u || flds.size() == 3u);

    const std::string& act = flds[0];
    const std::string& user_id = flds[1];
    int read_tm = 0;
    if (flds.size() == 3u) {
      read_tm = base::ParseInt32OrDie(flds[2]);
    }

    if (act == "show") {
      show.insert(user_id);
    } else if (act == "share") {
      share.insert(user_id);
    } else if (act == "fav") {
      fav.insert(user_id);
    } else if (act == "click") {
      click[user_id] = click[user_id] > read_tm ? click[user_id] : read_tm;
    }

    last_key = key;
  }

  reduce_output(last_key, &show, &click, &fav, &share, redis_client_pool);
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");
  if (FLAGS_mapper) {
    mapper();
  } else {
    reducer();
  }
}
