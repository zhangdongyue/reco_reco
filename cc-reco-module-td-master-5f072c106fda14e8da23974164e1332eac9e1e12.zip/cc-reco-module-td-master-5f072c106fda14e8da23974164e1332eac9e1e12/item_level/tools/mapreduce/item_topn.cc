#include <string>
#include <set>
#include <unordered_set>
#include <fstream>
#include <iostream>
#include "nlp/common/nlp_util.h"
#include "nlp/common/rune_type.h"
#include "nlp/segment/internal/segment_model.h"
#include "extend/static_dict/darts_clone/darts_clone.h"
#include "base/common/slice.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/gflags_completions.h"
#include "base/common/base.h"
#include "base/mapreduce/mapreduce.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/file/file_stream.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_number_conversions.h"
#include "base/encoding/line_escape.h"
#include "reco/bizc/proto/log.pb.h"
#include "rpc/redis/client.h"
#include "rpc/redis/client_pool.h"

DEFINE_bool(mapper, true, "is mapper");

DEFINE_string(redis_ip, "10.3.5.70", "redis server ip");
DEFINE_int32(redis_port, 6379, "redis_server port");

DEFINE_bool(save_to_redis, false, "save result to redis");
DEFINE_int32(redis_record_expire_second, 3600*24, "time interval to inc update item info in seconds.");

DEFINE_int32(redis_topn, 10000, "time interval to inc update item info in seconds.");

static const std::string kClickCountField = "ClickCount";
static const std::string kShowCountField = "ShowCount";

void split_kv(const std::string& line, std::string* key, std::string* value) {
  std::vector<std::string> flds;
  base::SplitStringWithMoreOptions(line, "\t", false, false, 1, &flds);
  if (flds.size() == 2u) {
    *key = flds[0];
    *value = flds[1];
  } else if (flds.size() == 1u) {
    *key = flds[0];
    value->clear();
  } else {
    CHECK(false);
  }
}

void mapper() {
  std::string key;
  std::string value;
  std::string line;
  while (std::getline(std::cin, line)) {
    base::TrimTrailingWhitespaces(&line);
    split_kv(line, &key, &value);
    if (key.empty()) continue;

    std::string line;
    if (!base::LineUnescape(value, &line)) {
      LOG(ERROR) << "log unescape failed";
      continue;
    }

    reco::ServerLog server_log;
    if (!server_log.ParseFromString(line)) {
      LOG(ERROR) << "parse proto failed";
      continue;
    }

    // show log
    if (server_log.head().log_type() == reco::kLeafServer) {
      reco::LeafServerLogBody body;
      if (!body.ParseFromString(server_log.body())) {
        LOG(ERROR) << "failed to parse body";
        continue;
      }

      uint64 user_id = body.user().identity().user_id();
      if (user_id == 0) continue;
      std::string user_id_str = base::Uint64ToString(user_id);

      for (int i = 0; i < body.misc_info_size(); ++i) {
        uint64 item_id = 0;
        if (!base::StringToUint64(body.misc_info(i).item_id(), &item_id)) {
          LOG(ERROR) << "error item id: " << body.misc_info(i).item_id();
          continue;
        }

        // item_id, show, user_id
        std::cout << item_id << "\tshow\t" << user_id_str << std::endl;
      }
    } else if (server_log.head().log_type() == reco::kClickServer) {
      reco::ClickServerLogBody body;
      if (!body.ParseFromString(server_log.body())) {
        LOG(ERROR) << "failed to parse body";
        continue;
      }

      uint64 item_id;
      if (!base::StringToUint64(body.clicked_item_id(), &item_id)) continue;
      const std::string& item_id_str = body.clicked_item_id();

      uint64 user_id = body.user().identity().user_id();
      if (user_id == 0) {
        LOG(ERROR) << "uid == 0";
        continue;
      }
      std::string user_id_str = base::Uint64ToString(user_id);

      // item_id, click, user_id
      std::cout << item_id_str << "\tclick\t" << user_id_str << std::endl;
    }
  }
}

void save_to_redis(const std::string& item_id,
                   const std::string& field,
                   int64 count, redis::ClientPool *redis_client_pool) {
  redis::AutoPutback redis(redis_client_pool);
  redis::Client* client = redis.TimedTake(10);
  if (client == NULL) {
    LOG(ERROR) << "time take redis client fail.";
    return;
  }

  std::string list_key = "Review-" + field + "-List";
  if (!client->SSAddInt64(list_key.c_str(), list_key.size(),
                          item_id.c_str(), item_id.size(),
                          count)) {
    LOG(ERROR) << base::StringPrintf("write sset error, key[%s], item[%s]",
                                     list_key.c_str(), item_id.c_str());
    return;
  }

  int64 topn = 0;
  if (!client->SSSize(list_key.c_str(), list_key.size(), &topn)) {
    LOG(ERROR) << "get topn size failed, key: " << list_key;
    return;
  }

  if (topn > FLAGS_redis_topn) {
    int64 del_cnt;
    if (!client->SSRemRangeByIndex(list_key.c_str(), list_key.size(),
                                   0, topn - FLAGS_redis_topn - 1, &del_cnt)) {
      LOG(ERROR) << "failed to del topn, key: " << list_key;
      return;
    }
  }

  if (0 != client->Expire(list_key.c_str(), list_key.size(), FLAGS_redis_record_expire_second)) {
    LOG(ERROR) << "set expire failed, key: " << list_key;
  }
}

void save_to_redis_comment(const std::string& item_id,
                   const std::string& field,
                   int64 count, redis::ClientPool *redis_client_pool) {
  redis::AutoPutback redis(redis_client_pool);
  redis::Client* client = redis.TimedTake(10);
  if (client == NULL) {
    LOG(ERROR) << "time take redis client fail.";
    return;
  }

  std::string list_key = "CommentReview-" + field + "-List";
  if (!client->SSAddInt64(list_key.c_str(), list_key.size(),
                          item_id.c_str(), item_id.size(),
                          count)) {
    LOG(ERROR) << base::StringPrintf("write sset error, key[%s], item[%s]",
                                     list_key.c_str(), item_id.c_str());
    return;
  }

  int64 topn = 0;
  if (!client->SSSize(list_key.c_str(), list_key.size(), &topn)) {
    LOG(ERROR) << "get topn size failed, key: " << list_key;
    return;
  }

  if (topn > FLAGS_redis_topn) {
    int64 del_cnt;
    if (!client->SSRemRangeByIndex(list_key.c_str(), list_key.size(),
                                   0, topn - FLAGS_redis_topn - 1, &del_cnt)) {
      LOG(ERROR) << "failed to del topn, key: " << list_key;
      return;
    }
  }

  if (0 != client->Expire(list_key.c_str(), list_key.size(), FLAGS_redis_record_expire_second)) {
    LOG(ERROR) << "set expire failed, key: " << list_key;
  }
}

void reduce_output(const std::string& key, std::set<std::string>* show,
                   std::set<std::string>* click, redis::ClientPool *redis_client_pool) {
  if (!show->empty()) {
    std::cout << key << "\tshow\t" << show->size() << std::endl;
    if (FLAGS_save_to_redis) {
      save_to_redis(key, kShowCountField, show->size(), redis_client_pool);
      save_to_redis_comment(key, kShowCountField, show->size(), redis_client_pool);
    }
  }

  if (!click->empty()) {
    int64 uv = 0;
    for (auto it = click->begin(); it != click->end(); ++it) {
      // click 必须能够找到 show
      if (show->find(*it) == show->end()) continue;
      ++uv;
    }
    if (uv > 0) {
      std::cout << key << "\tclick\t" << uv << std::endl;
      if (FLAGS_save_to_redis) {
        save_to_redis(key, kClickCountField, uv, redis_client_pool);
        save_to_redis_comment(key, kClickCountField, uv, redis_client_pool);
      }
    }
  }
  show->clear();
  click->clear();
}

void reducer() {
  // NOTE: Only one reduce!
  std::string line;
  std::string key;
  std::string value;
  std::vector<std::string> flds;

  redis::ClientPool *redis_client_pool = NULL;
  if (FLAGS_save_to_redis) {
    redis::GenerateMultiRedisConnect(FLAGS_redis_ip, FLAGS_redis_port, 5);
    redis_client_pool = redis::GetClientPool(FLAGS_redis_ip, FLAGS_redis_port);

    redis::AutoPutback redis(redis_client_pool);
    redis::Client* client = redis.TimedTake(10);
    if (client == NULL) {
      LOG(ERROR) << "time take redis client fail.";
      return;
    }

    std::string list_key = "Review-" + kClickCountField + "-List";
    if (!client->Delete(list_key.c_str(), list_key.size())) {
      LOG(ERROR) << "failed to del: " << list_key;
    }

    list_key = "Review-" + kShowCountField + "-List";
    if (!client->Delete(list_key.c_str(), list_key.size())) {
      LOG(ERROR) << "failed to del: " << list_key;
    }

    list_key = "CommentReview-" + kClickCountField + "-List";
    if (!client->Delete(list_key.c_str(), list_key.size())) {
      LOG(ERROR) << "failed to del: " << list_key;
    }

    list_key = "CommentReview-" + kShowCountField + "-List";
    if (!client->Delete(list_key.c_str(), list_key.size())) {
      LOG(ERROR) << "failed to del: " << list_key;
    }
  }

  // user deduped actions
  std::set<std::string> show;
  std::set<std::string> click;

  std::string last_key;
  while (std::getline(std::cin, line)) {
    base::TrimTrailingWhitespaces(&line);
    split_kv(line, &key, &value);

    if (!last_key.empty() && key != last_key) {
      reduce_output(last_key, &show, &click, redis_client_pool);
    }

    // item_id, show, user_id
    // item_id, click, user_id
    flds.clear();
    base::SplitString(value, "\t", &flds);
    CHECK_EQ(flds.size(), 2u);

    const std::string& act = flds[0];
    const std::string& user_id = flds[1];
    if (act == "show") {
      show.insert(user_id);
    } else if (act == "click") {
      click.insert(user_id);
    }

    last_key = key;
  }

  reduce_output(last_key, &show, &click, redis_client_pool);
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");
  if (FLAGS_mapper) {
    mapper();
  } else {
    reducer();
  }
}
