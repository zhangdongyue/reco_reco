#include <string>
#include <set>
#include <unordered_set>
#include <fstream>
#include <iostream>
#include "nlp/common/nlp_util.h"
#include "nlp/common/rune_type.h"
#include "base/common/slice.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/mapreduce/mapreduce.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/file/file_stream.h"
#include "base/strings/utf_char_iterator.h"
#include "base/encoding/line_escape.h"
#include "reco/bizc/proto/log.pb.h"

DEFINE_bool(mapper, true, "is mapper");

void mapper() {
  std::string key;
  std::string value;
  std::vector<std::string> flds;
  std::string line;
  while (std::getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() >= 15u) {
      if (flds[12] != "100") continue;
      std::cout << flds[1] << "\tshow\t" << flds[0] << "\t" << flds[6] << "\t" << flds[2]<< std::endl;
    } else if (flds.size() >= 9u) {
      std::cout << flds[1] << "\tclick\t" << flds[0] << std::endl;
    }
  }
}

void reduce_output(const std::string& key, std::set<std::string>* shows,
                   std::set<std::string>* clicks, std::string* category, std::string* item_type) {
  int show_num = shows->size();
  int clk_num  = 0;
  for (auto iter = clicks->begin(); iter != clicks->end(); ++iter) {
    if (shows->find(*iter) != shows->end()) ++clk_num;
  }
  std::vector<std::string> flds;
  base::SplitString(*category, "-", &flds);
  if (show_num > 0) {
    std::cout << key << "\t" << flds[0] << "\t" << *item_type
              << "\t" << show_num << "\t" << clk_num << std::endl;
  }
  shows->clear();
  clicks->clear();
  category->clear();
}


void reducer() {
  std::string line;
  std::string key;
  std::vector<std::string> flds;
  std::set<std::string> show;
  std::set<std::string> click;
  std::string category;
  std::string item_type;

  std::string last_key;
  while (std::getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 3u && flds.size() != 5u) continue;
    const std::string& key = flds[0];
    const std::string& act = flds[1];
    const std::string& uid = flds[2];
    if (!last_key.empty() && key != last_key) {
      reduce_output(last_key, &show, &click, &category, &item_type);
    }
    if (act == "show") {
      show.insert(uid);
      category = flds[3];
      item_type = flds[4];
    } else {
      click.insert(uid);
    }
    last_key = key;
  }

  reduce_output(last_key, &show, &click, &category, &item_type);
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");
  if (FLAGS_mapper) {
    mapper();
  } else {
    reducer();
  }
}
