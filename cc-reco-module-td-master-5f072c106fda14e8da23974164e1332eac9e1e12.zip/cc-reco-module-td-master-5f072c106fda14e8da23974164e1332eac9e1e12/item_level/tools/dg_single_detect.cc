#include <sys/time.h>

#include <iomanip>
#include <iostream>

#include "reco/module/item_level/time_level/search_similar_item_expiry_calculator.h"
#include "reco/bizc/item_service/hbase_get_item.h"

#include "base/common/base.h"
#include "base/common/logging.h"

DEFINE_string(table_name, "tb_reco_item", "the hbase table name that query from.");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "dig grave calculator");
  reco::HBaseGetItem* hbase = new reco::HBaseGetItem(FLAGS_table_name, -1);
  reco::item_level::SearchSimilarItemExpiryCalculator item_expiry_calculator(hbase);
  item_expiry_calculator.Init();
  reco::RecoItem source_item;
  reco::RecoItem similar_item;
  uint64 item_id;
  std::cin >> item_id;
  struct timeval start, end;
  gettimeofday(&start, NULL);
  bool is_expiry = item_expiry_calculator.IsExpiryItem(item_id, &source_item, &similar_item);
  gettimeofday(&end, NULL);
  int start_time = start.tv_sec * 1000000 + start.tv_usec;
  int end_time = end.tv_sec * 1000000 + end.tv_usec;
  int delta_time = end_time - start_time;

  std::cout << std::fixed << std::setprecision(3) << (delta_time * 1.0) / 1000 << " ms" << std::endl;
  LOG(INFO) << "itemid: " << item_id;
  if (is_expiry) {
    LOG(INFO) << " is expiry item.";
    LOG(INFO) << "itemid: " << item_id;
    LOG(INFO) << "title: " << source_item.title();
    LOG(INFO) << "is simialr to item: " << similar_item.identity().item_id();
    LOG(INFO) << "title: " << similar_item.title();
  } else {
    LOG(INFO) << " is NOT expiry item.";
    LOG(INFO) << "title: " << source_item.title();
  }
  return 0;
}
