
#include <iostream>
#include <string>
#include <vector>

#include "base/common/base.h"
#include "base/file/file_util.h"
#include "extend/regexp/re2/re2.h"

DEFINE_string(input_file, "", "input file");

class DateDetector {
 public:
  DateDetector() {
    // 年月日
    full_date_regex_.push_back(new extend::re2::RE2(".*(\\d{4})年(\\d{1,2})月(\\d{1,2})日.*"));
    full_date_regex_.push_back(new extend::re2::RE2(".*(\\d{4})[-./](\\d{1,2})[-./](\\d{1,2}).*"));
    // 月日
    part_date_regex_.push_back(new extend::re2::RE2(".*(\\d{1,2})月(\\d{1,2})日.*"));
    part_date_regex_.push_back(new extend::re2::RE2(".*(\\d{1,2})[-./](\\d{1,2})[-./].*"));
    // 年
  }
  void Detect(const std::string& title) {
    base::Slice input(title);
    int32 year = 0, month = 0, day = 0;
    for (auto i = full_date_regex_.begin(); i != full_date_regex_.end(); ++i) {
      if (extend::re2::RE2::Consume(&input, **i, &year, &month, &day)) {
        std::cout << title << " index:" << (i - full_date_regex_.begin())
                  << " year:" << year << ",month:" << month << ",day:" << day << std::endl;
        return;
      }
    }
    for (auto i = part_date_regex_.begin(); i != part_date_regex_.end(); ++i) {
      if (extend::re2::RE2::Consume(&input, **i, &month, &day)) {
        std::cout << title << " index:" << (i - full_date_regex_.begin())
                  << " year:" << year << ",month:" << month << ",day:" << day << std::endl;
        return;
      }
    }
  }
 private:
  std::vector<extend::re2::RE2*> full_date_regex_;
  std::vector<extend::re2::RE2*> part_date_regex_;
};

class SerialDetector {
 public:
  SerialDetector() {
    regex_pattern_.push_back(new extend::re2::RE2(".*第(\\d+)期.*"));
    regex_pattern_.push_back(new extend::re2::RE2(".*(\\d+)期.*"));
    regex_pattern_.push_back(new extend::re2::RE2(".*(\\d+)人.*"));
  }
  void Detect(const std::string& title) {
    int32 num = 0;
    base::Slice input(title);
    for (auto i = regex_pattern_.begin(); i != regex_pattern_.end(); ++i) {
      if (extend::re2::RE2::Consume(&input, **i, &num)) {
        std::cout << title << " index:" << (i - regex_pattern_.begin()) << " num:" << num << std::endl;
        break;
      }
    }
    extend::re2::RE2 a(".*第(.*)期.*");
    std::string n;
    if (extend::re2::RE2::Consume(&input, a, &n)) {
      std::cout << title << " index:100"  << " num:" << n << std::endl;
    }
  }
 private:
  std::vector<extend::re2::RE2*> regex_pattern_;
};

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "dig grave calculator");
  std::vector<std::string> titles;
  base::file_util::ReadFileToLines(FLAGS_input_file, &titles);
  DateDetector d;
  SerialDetector s;
  for (auto i = titles.begin(); i != titles.end(); ++i) {
    std::cout << *i << std::endl;
    d.Detect(*i);
    s.Detect(*i);
  }

  return 0;
}
