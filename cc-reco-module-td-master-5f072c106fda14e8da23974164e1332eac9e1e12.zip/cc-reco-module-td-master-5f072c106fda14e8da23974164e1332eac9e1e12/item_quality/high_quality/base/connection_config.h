#pragma once

#include "base/common/gflags.h"
#include "base/common/base.h"

namespace reco {
namespace high_quality {

DEFINE_string(kafka_brokers, "", "");
DEFINE_string(kafka_topic_name, "", "");
DEFINE_int32(kafka_total_partition, 0, "");
DEFINE_string(hbase_table, "tb_reco_item", "");
// mysql config
DEFINE_string(db_host, "11.251.206.209:3306", "host ip");
DEFINE_string(db_user, "test", "db user");
DEFINE_string(db_passwd, "chuheridangwu", "db passwd");
DEFINE_string(schema, "test_reco", "shcema");

DEFINE_bool(enable_keeper, false, "");
DEFINE_bool(enable_redis, true, "");
DEFINE_bool(enable_mysql, true, "");
DEFINE_bool(enable_kafka, true, "");
DEFINE_string(service_name, "high_quality", "");

}  // namespace high_quality
}  // namespace reco
