#include <string>
#include <vector>

#include "reco/module/item_quality/high_quality/base/connection_manager.h"
#include "base/strings/string_split.h"

namespace reco {
namespace high_quality {

reco::redis::RedisCli* ConnectionManager::redis_cli_ = NULL;
reco::redis::RedisCli* ConnectionManager::slave_redis_cli_ = NULL;
reco::redis::RedisCli* ConnectionManager::third_redis_cli_ = NULL;
serving_base::mysql_util::DbConnManager* ConnectionManager::mysql_cli_ = NULL;
reco::itemkeeper::ItemKeeper::Stub* ConnectionManager::rpc_stub_ = NULL;
net::rpc::RpcGroup* ConnectionManager::rpc_group_ = NULL;

// mysql config
DECLARE_string(db_host);
DECLARE_string(db_user);
DECLARE_string(db_passwd);
DECLARE_string(schema);
// item_keeper_server config
DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_int32(item_keeper_server_timeout, 3000, "");

DECLARE_bool(enable_keeper);
DECLARE_bool(enable_redis);
DECLARE_bool(enable_mysql);
DECLARE_bool(enable_kafka);

bool ConnectionManager::InitConnection() {
  CHECK(reco::item_level::ConnectionManager::InitConnection()) << "Initialize connection error.";
  if (FLAGS_enable_redis) {
    redis_cli_ = reco::item_level::ConnectionManager::GetRedisClient();
    slave_redis_cli_ = reco::item_level::ConnectionManager::GetSlaveRedisClient();
    third_redis_cli_ = reco::item_level::ConnectionManager::GetThirdRedisClient();
  }
  if (FLAGS_enable_mysql) {
    if (!FLAGS_db_host.empty()) {
      serving_base::mysql_util::DbConnManager::Option db_option;
      db_option.host = FLAGS_db_host;
      db_option.user = FLAGS_db_user;
      db_option.passwd = FLAGS_db_passwd;
      db_option.schema = FLAGS_schema;
      mysql_cli_ = new serving_base::mysql_util::DbConnManager(db_option);
      CHECK_NOTNULL(mysql_cli_);
      mysql_cli_->ConnectUntilSuccess();
      LOG(INFO) << "succ to connect to db, " << FLAGS_db_host;
    } else {
      LOG(WARNING) << "skip to connect to db.";
    }
  }
  if (FLAGS_item_keeper_server_ip != "") {
    // item_keeper_ = new reco::ItemKeeperGetItem(FLAGS_item_keeper_server_ip, FLAGS_item_keeper_server_port);
    // Init Item Keeper
    std::vector<std::string> flds;
    net::rpc::RpcGroup::Options options;
    options.max_retry_times = 1;
    options.timeout = FLAGS_item_keeper_server_timeout;
    base::SplitString(FLAGS_item_keeper_server_ip, ",", &flds);
    for (int i = 0; i < (int)flds.size(); ++i) {
      net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_item_keeper_server_port, 3000);
      options.servers.push_back(si);
    }
    rpc_group_ = new net::rpc::RpcGroup(options);
    CHECK(rpc_group_->Connect());
    rpc_stub_ = new reco::itemkeeper::ItemKeeper::Stub(rpc_group_);
  }
  return true;
}

void ConnectionManager::CleanConnection() {
  reco::item_level::ConnectionManager::CleanConnection();
  delete mysql_cli_;
  delete rpc_group_;
  delete rpc_stub_;
}

bool ConnectionManager::GetRecoItemFromItemKeeper(uint64 item_id, reco::RecoItem* reco_item) {
  reco::itemkeeper::GetRecoItemRequest request;
  reco::itemkeeper::GetRecoItemResponse response;
  request.add_item_id(item_id);
  net::rpc::RpcClientController rpc;
  rpc_stub_->getRecoItem(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()
      || response.reco_item_size() != 1) {
    LOG(ERROR) << "Get reco item failed. "
               << " item id: "
               << item_id << ", "
               << response.Utf8DebugString();
    return false;
  } else {
    reco_item->CopyFrom(response.reco_item(0));
  }
  return true;
}

bool ConnectionManager::UpdateItemFields(const uint64 item_id, const reco::RecoItem& reco_item,
                                         const std::vector<reco::itemkeeper::ItemStorageEnum>& exclude_vec,
                                         const std::string& service_name) {
  net::rpc::RpcClientController rpc;
  reco::itemkeeper::UpdateItemRequest request;
  reco::itemkeeper::UpdateItemFieldResponse response;
  request.mutable_service_identity()->set_service_name(service_name);
  request.set_item_id(item_id);
  reco_item.SerializePartialToString(request.mutable_reco_item_bytes());
  for (size_t i = 0; i < exclude_vec.size(); ++i) {
    request.add_exclude_storages(exclude_vec[i]);
  }
  rpc_stub_->updateItemFields(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "Update reco item failed. "
               << " item id: "
               << item_id << ", "
               << response.Utf8DebugString();
    return false;
  }
  return true;
}
}  // high_quality
}  // reco

