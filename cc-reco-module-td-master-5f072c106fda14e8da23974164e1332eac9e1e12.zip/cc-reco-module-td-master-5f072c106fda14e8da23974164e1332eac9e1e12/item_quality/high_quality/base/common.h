#pragma once
#include <string>
#include <unordered_set>
#include <vector>
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/time/timestamp.h"

#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace high_quality {

#define LEVEL_6 90
#define LEVEL_5 80
#define LEVEL_4 60
#define LEVEL_3 30
#define LEVEL_2 20
#define LEVEL_1 0

const std::string kItemLevelKey = "ItemLevel-";
const std::string kPosteriorItemQField = "StatItemq";
const std::string kPrioriItemQField = "PrioriItemq";

struct HitsData {
  uint64 user_id;
  uint64 item_id;
  bool is_wemedia;
  uint32 article_height;
  uint32 read_height;
  uint32 read_time;
  // 主动行为
  bool is_like;  // 0 or 1
  bool is_collect;  // 0 or 1
  uint32 share_num;
  uint32 content_length;
  std::string category;
  std::string source;
  std::string media;
  float pic_scale;
  float hub;
  float authority;
  float pre_authority;
  bool Init(const std::vector<std::string>& flds) {
    uint32 like_uint, collect_uint;
    if (!base::StringToUint64(flds[0], &user_id)
        || !base::StringToUint64(flds[1], &item_id)
        || !base::StringToUint(flds[2], &article_height)
        || !base::StringToUint(flds[3], &read_height)
        || !base::StringToUint(flds[4], &read_time)
        || !base::StringToUint(flds[5], &like_uint)
        || !base::StringToUint(flds[6], &collect_uint)
        || !base::StringToUint(flds[7], &share_num)) {
      LOG(INFO) << "Parse Data To UserItemData Fail, line is: " << base::JoinStrings(flds, "\t");
      return false;
    }
    if (like_uint == 1) {
      is_like = true;
    } else {
      is_like = false;
    }
    if (collect_uint == 1) {
      is_collect = true;
    } else {
      is_collect = false;
    }

    pic_scale = 0.0;
    if (read_height <= 0 || article_height <= 0 || read_time <= 0) {
      LOG(WARNING) << "read_height or article_height or read_time is:zero, item_id is: "
                   << item_id << " user_id is: " << user_id;
      return false;
    }
    hub = 1.0;
    authority = 1.0;
    pre_authority = 1.0;
    return true;
  }
  void Print() {
    float read_ratio = static_cast<float>(read_height) / static_cast<float>(article_height);
    float speed = static_cast<float>(read_time) / static_cast<float>(read_height);
    LOG(INFO) << "user_id:" << user_id << "\t"
              << "item_id:" << item_id << "\t"
              << "article_height:" << article_height << "\t"
              << "read_height:" << read_height << "\t"
              << "read_time:" << read_time << "\t"
              << "is_like:" << is_like << "\t"
              << "is_collect:" << is_collect << "\t"
              << "share_num:" << share_num << "\t"
              << "speed:" << speed << "\t"
              << "read_ratio:" << read_ratio << "\t"
              << "hub:" << hub << "\t"
              << "authority:" << authority;
  }
};

struct ItemInfoCache {
  bool is_good_item;
  int32 content_length;
  std::string category;
  std::string source;
  int64 timestamp;
  ItemInfoCache() {
    is_good_item = false;
    content_length = 0;
    UpdateTimeStamp();
  }
  void UpdateTimeStamp() {
    timestamp = base::GetTimestamp();
  }
};

struct DebugInfoForInitData {
  int32 success_num;
  int32 filter_by_height_num;
  int32 filter_by_item_quality;
  int32 init_fail_num;
  DebugInfoForInitData() {
    success_num = 0;
    filter_by_height_num = 0;
    filter_by_item_quality = 0;
    init_fail_num = 0;
  }
};

// 因为内存原因 HighQualityResult 不再返回 detail 信息 详情字段由外部根据 hbase 自行包装
struct HighQualityResult {
  uint64 item_id;
  float avg_article_height;
  float avg_read_height;
  float avg_read_time;
  float pic_scale;
  int32 score_level;
  float score;
  // Debug Info
  // 看过 item 的用户数
  uint32 user_num;
  // 用户平均种子得分
  float avg_hub;
  // 收藏 喜欢 分享
  uint32 share_num;
  uint32 collect_num;
  uint32 like_num;
  // 一级类别
  void Init(uint64 item_id_input) {
    item_id = item_id_input;
    avg_article_height = 0;
    avg_read_height = 0;
    avg_read_time = 0;
    pic_scale = 0;
    score_level = 0;
    score = 0;
    user_num = 0;
    avg_hub = 0;
    share_num = 0;
    collect_num = 0;
    like_num = 0;
  }
};

struct InsertData {
  uint64 item_id;
  float avg_article_height;
  float avg_read_height;
  float avg_read_time;
  float pic_scale;
  float score;
  // Debug Info
  // 看过 item 的用户数
  uint32 user_num;
  // 用户平均种子得分
  float avg_hub;
  // 收藏 喜欢 分享
  uint32 share_num;
  uint32 collect_num;
  uint32 like_num;

  reco::RecoItem reco_item;

  void InitBaseHighQualityResult(const HighQualityResult& result) {
    item_id = result.item_id;
    avg_article_height = result.avg_article_height;
    avg_read_height = result.avg_read_height;
    avg_read_time = result.avg_read_time;
    pic_scale = result.pic_scale;
    score = result.score;
    user_num = result.user_num;
    avg_hub = result.avg_hub;
    share_num = result.share_num;
    collect_num = result.collect_num;
    like_num = result.like_num;
  }
};

struct WeMediaDataInfo {
  std::string source;
  std::unordered_set<std::string> category_set;
  float source_dislike_ratio;
  int32 wmedia_level;
  WeMediaDataInfo() {
    source = "";
    source_dislike_ratio = 0;
    wmedia_level = 0;
  }
};

struct CategoryDataInfo {
  std::string category;
  double wemedia_source_dislike_ratio;
  double wemedia_ctr;
  double wemedia_share_ratio;
  double wemedia_fav_ratio;
  double wemedia_avg_dura;
  double wemedia_reading_speed;

  double ctr;
  int32 item_num;
  double share_ratio;
  double fav_ratio;
  double avg_dura;
  double reading_speed;

  CategoryDataInfo() {
    wemedia_source_dislike_ratio = 0;
    wemedia_ctr = 0;
    wemedia_share_ratio = 0;
    wemedia_fav_ratio = 0;
    wemedia_avg_dura = 0;
    wemedia_reading_speed = 0;
    item_num = 0;
    ctr = 0;
    share_ratio = 0;
    fav_ratio = 0;
    avg_dura = 0;
    reading_speed = 0;
  }
};

}  // namespace high_quality
}  // namespace reco
