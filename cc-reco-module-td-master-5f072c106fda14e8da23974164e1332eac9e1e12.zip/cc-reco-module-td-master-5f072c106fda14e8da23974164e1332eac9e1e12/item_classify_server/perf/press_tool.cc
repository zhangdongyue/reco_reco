#include <fstream>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/file/file_util.h"
#include "base/common/sleep.h"

#include "reco/module/item_classify_server/perf/press_worker.h"
#include "reco/module/item_classify_server/perf/press_responser.h"
#include "reco/module/item_classify_server/perf/define.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/proto/item.pb.h"

DEFINE_int32(thread_num, 16, "thread num for send request");
DEFINE_int32(hbase_thread_num, 32, "thread num for get item from hbase");
DEFINE_string(source_title_file, "press.data", "file contains source and title, keywords");
DEFINE_string(id_file, "press.id", "file contains source and title, keywords");

DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table");

using reco::item_classify::ItemClassifyRequest;
static bool ConstructAllRequest(const std::string& source_title_file,
                                std::vector<ItemClassifyRequest>* request_pool) {
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(source_title_file, &lines);
  request_pool->reserve(lines.size());

  CHECK(!lines.empty());
  std::vector<std::string> flds;
  std::vector<std::string> keywords;

  for (int i =0; i < (int)lines.size(); ++i) {
    base::TrimTrailingWhitespaces(&(lines[i]));
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 4) continue;

    request_pool->push_back(reco::item_classify::ItemClassifyRequest());
    request_pool->back().set_title(flds[1]);
    request_pool->back().set_source(flds[0]);
    request_pool->back().set_level(2);
    request_pool->back().set_item_type(base::ParseIntOrDie(flds[2]));
    request_pool->back().set_content(flds[3]);

    if (flds.size() > 4 && flds[4].size() > 2) {
      keywords.clear();
      base::SplitString(flds[4], ",", &keywords);
      request_pool->back().add_tags(keywords[4]);
    }
  }

  LOG(INFO) << "total request: " << request_pool->size();
  return request_pool->size() > 10;
}

static void ConvertRecoItemToRequest(thread::BlockingQueue<uint64>* item_id_q,
                                     thread::Mutex* mutex,
                                     std::vector<ItemClassifyRequest>* request_pool) {
  reco::HBaseGetItem* hbase_get_item = new reco::HBaseGetItem(FLAGS_hbase_item_table);

  std::vector<uint64> item_ids;
  std::vector<reco::RecoItem> reco_items;
  uint64 item_id;
  int n = 0;
  int m = 0;
  ItemClassifyRequest request;
  while (!(item_id_q->Closed() && item_id_q->Empty())) {
    if (item_id_q->Empty()) {
      base::SleepForMilliseconds(100);
      continue;
    }

    if (!item_id_q->Take(&item_id)) break;

    item_ids.push_back(item_id);

    if (item_ids.size() > 128) {
      m += item_ids.size();
      reco_items.clear();
      hbase_get_item->GetRecoItems(item_ids, &reco_items);

      for (size_t i = 0; i < reco_items.size(); ++i) {
        request.Clear();
        request.set_source(reco_items[i].source());
        request.set_title(reco_items[i].title());

        request.set_item_type(reco_items[i].identity().type());

        request.set_content(reco_items[i].raw_item().content());

        // keyword and tag
        const reco::FeatureVector& keyword_fea = reco_items[i].keyword();
        for (int j = 0; j < keyword_fea.feature_size(); ++j) {
          request.add_keywords(keyword_fea.feature(j).literal());
        }

        const reco::FeatureVector& tag_fea= reco_items[i].tag();
        for (int j = 0; j < tag_fea.feature_size(); ++j) {
          request.add_tags(tag_fea.feature(j).literal());
        }
        const reco::FeatureVector& fea_topic = reco_items[i].topic();
        auto topic = request.mutable_topic();
        topic->set_norm(1.0);
        auto topic_feature = topic->mutable_feature();
        for (int j = 0; j < fea_topic.feature_size(); ++j) {
          auto it = topic_feature->Add();
          it->set_literal(fea_topic.feature(j).literal());
          it->set_weight(fea_topic.feature(j).weight());
          // LOG(INFO) << fea_topic.feature(j).literal()<<fea_topic.feature(j).weight();
        }
        const reco::FeatureVector& title_lda = reco_items[i].title_lda();
        auto topic_lda = request.mutable_title_lda_topic();

        topic_lda->set_norm(1.0);
        auto topic_lda_feature = topic_lda->mutable_feature();
        for (int j = 0; j < title_lda.feature_size(); ++j) {
          auto it = topic_lda_feature->Add();
          it->set_literal(title_lda.feature(j).literal());
          it->set_weight(title_lda.feature(j).weight());
          // LOG(INFO) << fea_topic.feature(j).literal()<<fea_topic.feature(j).weight();
        }
        /////
        // 添加 simhash
        for (int j = 0; j < reco_items[i].paragraph_simhash_size(); ++j) {
          request.add_para_simhash(reco_items[i].paragraph_simhash(j));
        }
        for (int j = 0; j < reco_items[i].image_size(); ++j) {
          request.add_picture_simhash(reco_items[i].image(j).simhash());
        }
        request.set_level(2);
        request.set_is_debug(false);
        mutex->Lock();
        request_pool->push_back(request);
        mutex->Unlock();
        ++n;
      }
      item_ids.clear();
    }
  }
  if (!item_ids.empty()) {
    m+=item_ids.size();
    reco_items.clear();
    hbase_get_item->GetRecoItems(item_ids, &reco_items);

    for (size_t i = 0; i < reco_items.size(); ++i) {
      request.Clear();
      request.set_source(reco_items[i].source());
      request.set_title(reco_items[i].title());

      request.set_item_type(reco_items[i].identity().type());

      request.set_content(reco_items[i].raw_item().content());

      // keyword and tag
      const reco::FeatureVector& keyword_fea = reco_items[i].keyword();
      for (int j = 0; j < keyword_fea.feature_size(); ++j) {
        request.add_keywords(keyword_fea.feature(j).literal());
      }

      const reco::FeatureVector& tag_fea= reco_items[i].tag();
      for (int j = 0; j < tag_fea.feature_size(); ++j) {
        request.add_tags(tag_fea.feature(j).literal());
      }
      const reco::FeatureVector& fea_topic = reco_items[i].topic();
      auto topic = request.mutable_topic();
      topic->set_norm(1.0);
      auto topic_feature = topic->mutable_feature();
      for (int j = 0; j < fea_topic.feature_size(); ++j) {
        auto it = topic_feature->Add();
        it->set_literal(fea_topic.feature(j).literal());
        it->set_weight(fea_topic.feature(j).weight());
        // LOG(INFO) << fea_topic.feature(j).literal()<<fea_topic.feature(j).weight();
      }
      const reco::FeatureVector& title_lda = reco_items[i].title_lda();
      auto topic_lda = request.mutable_title_lda_topic();

      topic_lda->set_norm(1.0);
      auto topic_lda_feature = topic_lda->mutable_feature();
      for (int j = 0; j < title_lda.feature_size(); ++j) {
        auto it = topic_lda_feature->Add();
        it->set_literal(title_lda.feature(j).literal());
        it->set_weight(title_lda.feature(j).weight());
        // LOG(INFO) << fea_topic.feature(j).literal()<<fea_topic.feature(j).weight();
      }
      /////
      // 添加 simhash
      for (int j = 0; j < reco_items[i].paragraph_simhash_size(); ++j) {
        request.add_para_simhash(reco_items[i].paragraph_simhash(j));
      }
      for (int j = 0; j < reco_items[i].image_size(); ++j) {
        request.add_picture_simhash(reco_items[i].image(j).simhash());
      }
      request.set_level(2);
      request.set_is_debug(false);

      mutex->Lock();
      request_pool->push_back(request);
      mutex->Unlock();
      ++n;
    }
  }
  LOG(ERROR) << "threadend gen " << n << "request" << " get " << m << " from item id q";
}

static bool ConstructAllRequestFromHBase(std::string id_filename,
                                         std::vector<ItemClassifyRequest>* request_pool) {
  std::vector<uint64> item_ids;
  std::vector<std::string> tokens;
  std::vector<reco::RecoItem> reco_items;
  std::vector<bool> rets;

  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(id_filename), &lines)) << id_filename;
  LOG(INFO) << "finish reading " << lines.size();

  thread::BlockingQueue<uint64> item_id_q;
  thread::ThreadPool pool(FLAGS_hbase_thread_num);
  thread::Mutex mutex;
  for (int i = 0;  i < FLAGS_hbase_thread_num; ++i) {
    pool.AddTask(::NewCallback(&ConvertRecoItemToRequest, &item_id_q, &mutex, request_pool));
  }

  for (size_t i = 0; i < lines.size(); ++i) {
    tokens.clear();
    if (lines[i].size() < 2) {
      LOG(ERROR) << "erro line: " << lines[i];
      continue;
    }
    base::TrimWhitespaces(&lines[i]);
    base::SplitString(lines[i], "\t", &tokens);

    uint64 item_id = 0;
    if (!base::StringToUint64(tokens[0], &item_id)) continue;
    item_id_q.Put(item_id);
  }
  item_id_q.Close();
  LOG(INFO) << "finishing! remain id: " << item_id_q.Size();

  pool.JoinAll();

  LOG(INFO) << "finish generating all rquest!: " << request_pool->size();
  return true;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "press tool");
  using namespace reco;  // NOLINT

  int thread_num_ = FLAGS_thread_num;

  thread::BlockingQueue<ResponseDumpInfo*> response_queue;

  reco::item_classify::PressResponser responser(&response_queue);

  std::vector<reco::item_classify::ItemClassifyRequest> request_pool;
  if (!FLAGS_id_file.empty()) {
    CHECK(ConstructAllRequestFromHBase(FLAGS_id_file, &request_pool));
  } else {
    CHECK(ConstructAllRequest(FLAGS_source_title_file, &request_pool));
  }

  std::vector<reco::item_classify::PressWorker*> workers;

  thread::ThreadPool pool(thread_num_ + 3);

  thread::BlockingVar<int> remain_num;
  remain_num.TryPut(thread_num_);
  for (int i = 0; i < thread_num_; ++i) {
    workers.push_back(new reco::item_classify::PressWorker(request_pool, &response_queue, &remain_num));
    pool.AddTask(::NewCallback(workers.back(), &reco::item_classify::PressWorker::run, i));
  }

  pool.AddTask(::NewCallback(&responser, &reco::item_classify::PressResponser::run));

  int total_workers = thread_num_;
  while (total_workers > 0) {
    base::SleepForMilliseconds(200);
    total_workers = 0;
    for (int i = 0; i < (int)workers.size(); ++i) {
      if (workers[i]->running()) {
        ++total_workers;
      }
    }
  }
  response_queue.Close();
  responser.stop();

  pool.JoinAll();
  return 0;
}
