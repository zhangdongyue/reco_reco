#pragma once
#include <vector>
#include <string>
#include <utility>
#include "base/random/pseudo_random.h"
#include "base/strings/string_printf.h"
#include "base/file/file_util.h"
#include "base/strings/string_util.h"

namespace reco {
namespace item_classify {
class SourceTitlePool {
 public:
  explicit SourceTitlePool(const std::string& source_title_file) {
    std::vector<std::string> lines;
    base::file_util::ReadFileToLines(source_title_file, &lines);
    CHECK(!lines.empty());
    restrictions_.reserve(lines.size());
    std::vector<std::string> flds;
    for (int i =0; i < (int)lines.size(); ++i) {
      base::TrimTrailingWhitespaces(&(lines[i]));
      flds.clear();
      base::SplitString(lines[i], "\t", &flds);
      source_titles_.push_back(std::make_pair(flds[0], flds[1]));
    }
    max_num_ = source_titles_.size();
    LOG(INFO) << "total title: " << max_num_;
  }

  const std::pair<std::string, std::string>& get_restriction() {
    int index = rand_.GetInt(0, max_num_ - 1);
    return source_titles_[index];
  }

 private:
  std::vector<std::pair<std::string, std::string> > source_titles_;
  base::PseudoRandom rand_;
  int max_num_;
};
}
}
