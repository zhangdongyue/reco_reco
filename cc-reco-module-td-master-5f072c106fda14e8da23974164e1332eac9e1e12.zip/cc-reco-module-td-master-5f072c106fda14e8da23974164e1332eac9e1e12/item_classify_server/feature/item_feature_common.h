#pragma once

#include <string>

namespace reco {
namespace item_classify {
static const std::string kNumberStr = "NUMBER_TERM";
static const std::string kTimeStr = "TIME_TERM";
static const std::string kLabelPrefix = "label_";
static const std::string kSourcePrefix = "";
static const std::string kMediaPrefix = "media_";

static const std::string kKeywordPrefix = "##";
static const std::string kNgramSplit = "\t";
static const double kUnknownFlag = -1e10;

static const std::string kBeginTerm = "BEGIN";
static const std::string kEndTerm = "END";
static const int kLDAMaxTopicNumber = 2000;
}
}
