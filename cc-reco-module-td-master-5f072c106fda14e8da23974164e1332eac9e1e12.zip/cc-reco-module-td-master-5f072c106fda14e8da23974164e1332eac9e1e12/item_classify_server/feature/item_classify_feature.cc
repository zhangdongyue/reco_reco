#include "reco/module/item_classify_server/feature/item_classify_feature.h"

#include <cmath>
#include <algorithm>
#include <utility>
#include <functional>
#include <vector>
#include <unordered_map>

#include "base/common/slice.h"
#include "base/strings/string_printf.h"
#include "reco/module/item_classify_server/feature/item_basic_feature.h"
#include "reco/module/item_classify_server/feature/item_feature_common.h"
#include "reco/module/item_classify_server/global_data/define.h"

DEFINE_int32(cate_topic_bins, 10, "the bins number for cate topic values (0-1) Discretization");
DEFINE_bool(use_unigram, true, "use unigram including title, keywords , labels");
DEFINE_double(topic_min_value, 0.2, "min value to use topic as feature");
DEFINE_int32(ngram_window_size, 6, "ngram feature window size");
namespace reco {
namespace item_classify {

FeatureExtractor::FeatureExtractor() {
  fea_extractor_ = new ItemBasicFeatureExtractor();
}

FeatureExtractor::~FeatureExtractor() {
  delete fea_extractor_;
}

void FeatureExtractor::Extract(const RawItem& raw_item, ItemClassifyFeature* fea) {
  fea->basic_fea.renew();
  fea_extractor_->Extract(raw_item, &(fea->basic_fea));
  const ItemBasicFeature& basic_fea = fea->basic_fea;
  GenerateNgramFeature(raw_item, basic_fea, fea);

  GenerteTopicFeature(basic_fea, fea);
  GenerateFlagFeatures(basic_fea.flags, &(fea->post_flag_fea));
  GenerateContentFeature(basic_fea.paragraphs_unigrams_words, basic_fea, &(fea->para_ngram_fea));

  if (raw_item.item_type == 30) {
    GenerateVideoNgramFeature(raw_item, *fea, &(fea->video_ngram_fea));
  }
  // GenerateStatFeatures(basic_fea, &(fea->stat_fea));
}

void FeatureExtractor::GenerateVideoNgramFeature(const RawItem& raw_item,
                                                 const ItemClassifyFeature& fea,
                                                 std::vector<std::string>* video_ngram) {
  video_ngram->clear();
  // title
  for (int i = 0; i < (int) fea.ngram_fea.size(); ++i) {
    video_ngram->push_back("#video#\t$");
    video_ngram->back().append(raw_item.source);
    video_ngram->back().append("$\t");
    video_ngram->back().append(fea.ngram_fea[i]);

    video_ngram->push_back("#video#\t");
    video_ngram->back().append(fea.ngram_fea[i]);
  }
  // spider :tags
  for (size_t i = 0; i < raw_item.keywords.size(); ++i) {
    video_ngram->push_back("#video#\t##\t");
    video_ngram->back().append(raw_item.keywords[i].first);
  }
}

void FeatureExtractor::GenerateFlagFeatures(const std::vector<std::pair<std::string, std::string> >& in_flags,
                                            std::vector<std::string>* post_flag_fea) {
  for (auto it = in_flags.begin();
       it != in_flags.end(); ++it) {
    post_flag_fea->push_back(it->first);
  }
}

void FeatureExtractor::GenerateNgramFeature(const RawItem& raw_item,
                                            const ItemBasicFeature& basic_fea,
                                            ItemClassifyFeature* fea) {
  const std::vector<std::pair<std::string, std::string> >& labels = basic_fea.labels;
  const std::string& source = raw_item.source;

  // 先处理一下 label ， 后面去掉自叉乘用
  // value 是多个来源摞起来， 多个的话，不去掉自叉乘
  std::unordered_map<std::string, std::string> label_source;
  if (labels.size() > 0) {
    for (int i = 0; i < (int) labels.size(); ++i) {
      const std::string& label = labels[i].first;
      const std::string& word = labels[i].second;
      if (base::GetUTF8CharNumOrDie(word) <= 1) continue;   // 单字匹配的全部去掉
      auto it = label_source.find(label);
      if (it != label_source.end()) {
        if (it->second.find(word) != std::string::npos) continue;
        it->second.append(",");
        it->second.append(word);
        continue;
      }
      label_source.insert(std::make_pair(label, word));
    }
  }

  // pure title ngrams
  std::vector<std::string> title_unigrams(basic_fea.title_unigrams_words.begin(),
                                          basic_fea.title_unigrams_words.end());

  std::sort(title_unigrams.begin(), title_unigrams.end(), std::less<std::string>());
  std::string ngram;
  for (int i = 0; i < (int) title_unigrams.size(); ++i) {
    // 兼容标注平台特征
    if (FLAGS_use_unigram) {
      fea->ngram_fea.push_back(title_unigrams[i]);
    }
    if (base::GetUTF8CharNumOrDie(title_unigrams[i]) <= 1) continue;
    for (int j = i + 1; j < (int) title_unigrams.size(); ++j) {
      if (base::GetUTF8CharNumOrDie(title_unigrams[j]) <= 1) continue;
      if (title_unigrams[i] < title_unigrams[j]) {
        fea->ngram_fea.push_back(title_unigrams[i]);
        fea->ngram_fea.back() += kNgramSplit;
        fea->ngram_fea.back() += title_unigrams[j];
      } else {
        fea->ngram_fea.push_back(title_unigrams[j]);
        fea->ngram_fea.back() += kNgramSplit;
        fea->ngram_fea.back() += title_unigrams[i];
      }
    }
  }
  // keywords
  std::vector<base::Slice> keywords;
  for (int i = 0; i < (int) raw_item.keywords.size(); ++i) {
    keywords.push_back(raw_item.keywords[i].first);
  }
  std::sort(keywords.begin(), keywords.end(), std::less<base::Slice>());

  std::string unigram;
  std::string bigram;
  for (int i = 0; i < (int) keywords.size(); ++i) {
    unigram = kKeywordPrefix;
    unigram.append("\t");
    unigram.append(keywords[i].as_string());
    // 兼容标注平台特征
    if (FLAGS_use_unigram) {
      fea->ngram_fea.push_back(unigram);
    }
    for (int j = i + 1; j < (int) keywords.size(); ++j) {
      bigram = unigram;
      bigram.append("\t");
      bigram.append(keywords[j].as_string());
      fea->ngram_fea.push_back(bigram);
    }
  }
  // with label
  if (label_source.size() > 0) {
    for (auto it = label_source.begin(); it != label_source.end(); ++it) {
      const std::string& label = it->first;
      const std::string& sources = it->second;
      // 兼容标注平台特征
      if (FLAGS_use_unigram) {
        fea->ngram_fea.push_back("$" + kLabelPrefix + label + "$");
      }
      // 叉乘上 unigram
      for (size_t i = 0; i < title_unigrams.size(); ++i) {
        if (base::GetUTF8CharNumOrDie(title_unigrams[i]) <= 1) continue;
        const std::string& ngram = title_unigrams[i];
        // 去掉自叉乘 但是有两个以上的情况不管 比如 范冰冰和唐嫣同时出现 都差乘上 |女演员|
        if (ngram.find(sources) != std::string::npos) {
          // LOG(INFO) << ngram << "|" << label << (int) ngram.find(sources);
          continue;
        }
        fea->ngram_fea.push_back("$" + kLabelPrefix + label + "$" + kNgramSplit + ngram);
      }
      // 叉乘上 keywords
      for (size_t i = 0; i < keywords.size(); ++i) {
        const std::string& ngram = keywords[i].as_string();
        if (sources.find(ngram) != std::string::npos) continue;
        fea->ngram_fea.push_back(kKeywordPrefix + "\t$" + kLabelPrefix + label + "$" + kNgramSplit + ngram);
      }
    }
  }
  // with topic
  for (size_t k = 0; k < fea->ngram_fea.size(); ++k) {
    fea->topic_ngram_fea.push_back("#topic#\t" + fea->ngram_fea.at(k));
  }
  for (size_t i = 0; i < basic_fea.topics.size(); ++i) {
    const nlp::plsa::Topic& topic = basic_fea.topics[i];
    if (topic.value > FLAGS_topic_min_value) {
      std::string prefix = base::StringPrintf("$topic-%d", (int) topic.aspect);
      for (size_t j = 0; j < title_unigrams.size(); ++j) {
        if (base::GetUTF8CharNumOrDie(title_unigrams[j]) <= 1) continue;
        fea->topic_ngram_fea.push_back("#topic#\t" + prefix + kNgramSplit + title_unigrams[j]);
      }
    }
  }
  // with lda topic
  for (size_t k = 0; k < fea->ngram_fea.size(); ++k) {
    fea->title_lda_ngram_fea.push_back("#lda#\t" + fea->ngram_fea[k]);
  }
  for (size_t i = 0; i < basic_fea.lda_topics.size(); ++i) {
    const nlp::plsa::Topic& topic = basic_fea.lda_topics[i];
    if (topic.value > FLAGS_topic_min_value) {
      std::string prefix = base::StringPrintf("$lda-%d", (int) topic.aspect);
      for (size_t j = 0; j < title_unigrams.size(); ++j) {
        if (base::GetUTF8CharNumOrDie(title_unigrams[j]) <= 1) continue;
        fea->title_lda_ngram_fea.push_back("#lda#\t" + prefix + kNgramSplit + title_unigrams[j]);
      }
    }
  }
  if (raw_item.item_type == 30) {
    for (size_t i = 0; i < basic_fea.lda_topics.size(); ++i) {
      const nlp::plsa::Topic& topic = basic_fea.lda_topics[i];
      if (topic.value > FLAGS_topic_min_value) {
        std::string prefix = base::StringPrintf("$vide_lda-%d", (int) topic.aspect);
        for (size_t j = 0; j < title_unigrams.size(); ++j) {
          if (base::GetUTF8CharNumOrDie(title_unigrams[j]) <= 1) continue;
          fea->title_lda_ngram_fea.push_back("#video_lda#\t" + prefix + kNgramSplit + title_unigrams[j]);
        }
      }
    }
  }
  // with source
  if (source.size() > 0) {
    for (int i = 0; i < (int) fea->ngram_fea.size(); ++i) {
      // source_ngrams.push_back("$" + kSourcePrefix + source + "$" + kNgramSplit + ori_ngrams[i]);
      fea->source_ngram_fea.push_back("$");
      fea->source_ngram_fea.back() += kSourcePrefix;
      fea->source_ngram_fea.back() += source;
      fea->source_ngram_fea.back() += "$";
      fea->source_ngram_fea.back() += kNgramSplit;
      fea->source_ngram_fea.back() += fea->ngram_fea[i];
    }
  }
}

static void GenerateNgrams(const std::vector<std::string>& words,
                           const ItemBasicFeature& basic_fea,
                           std::vector<std::string>* ngrams,
                           int window_size) {
  ngrams->clear();
  const std::vector<std::pair<std::string, std::string> >& labels = basic_fea.labels;
  std::unordered_map<std::string, std::string> label_source;
  if (labels.size() > 0) {
    for (int i = 0; i < (int) labels.size(); ++i) {
      const std::string& label = labels[i].first;
      const std::string& word = labels[i].second;
      if (base::GetUTF8CharNumOrDie(word) <= 1) continue;   // 单字匹配的全部去掉
      auto it = label_source.find(label);
      if (it != label_source.end()) {
        if (it->second.find(word) != std::string::npos) continue;
        it->second.append(",");
        it->second.append(word);
        continue;
      }
      label_source.insert(std::make_pair(label, word));
    }
  }

  for (int i = 0; i < (int) words.size(); ++i) {
    for (int j = 0; j < (int) words.size(); ++j) {
      if (words[i] < words[j]) {
        ngrams->push_back(words[i]);
        ngrams->back() += kNgramSplit;
        ngrams->back() += words[j];
      }
    }
  }


  // with label
  if (label_source.size() > 0) {
    for (auto it = label_source.begin(); it != label_source.end(); ++it) {
      const std::string& label = it->first;
      const std::string& sources = it->second;
      // 叉乘上 unigram
      for (size_t i = 0; i < words.size(); ++i) {
        const std::string& ngram = words[i];
        if (base::GetUTF8CharNumOrDie(ngram) <= 1) continue;
        // 去掉自叉乘 但是有两个以上的情况不管 比如 范冰冰和唐嫣同时出现 都差乘上 |女演员|
        if (ngram.find(sources) != std::string::npos) {
          // LOG(INFO) << ngram << "|" << label << (int) ngram.find(sources);
          continue;
        }
        ngrams->push_back("$" + kLabelPrefix + label + "$" + kNgramSplit + ngram);
      }
    }
  }
}

void FeatureExtractor::GenerateContentFeature(const std::vector<std::vector<std::string> >& para_unigrams,
                                              const ItemBasicFeature& basic_fea,
                                              std::vector<std::vector<std::string> >* para_ngram_fea) {
  std::vector<std::string> ngrams;
  for (size_t i = 0; i < para_unigrams.size(); ++i) {
    GenerateNgrams(para_unigrams[i], basic_fea, &ngrams, FLAGS_ngram_window_size);
    para_ngram_fea->push_back(ngrams);
  }
}

void FeatureExtractor::GenerteTopicFeature(const ItemBasicFeature& basic_fea, ItemClassifyFeature* fea) {
  // lda topics
  for (size_t i = 0; i < basic_fea.lda_topics.size(); ++i) {
    auto& topic = basic_fea.lda_topics[i];
    fea->lda_topic_fea.push_back(std::make_pair(topic.aspect, topic.value));
  }
  // plsa topic
  for (size_t j = 0; j < basic_fea.topics.size(); ++j) {
    auto& topic = basic_fea.topics[j];
    fea->l1_topic_gbdt_fea.push_back(std::make_pair(topic.aspect, topic.value));
  }
  // plsa cate topic
  for (int i = 0; i < (int) basic_fea.cate_topics.size(); ++i) {
    const std::string prefix = basic_fea.cate_topics[i].first
                               + "_"
                               + base::IntToString(basic_fea.cate_topics[i].second.aspect);
    const std::string prefix2 = basic_fea.cate_topics[i].first
                                + "_l2_"
                                + base::IntToString(basic_fea.cate_topics[i].second.aspect);
    int v = (int) std::floor(basic_fea.cate_topics[i].second.value
                             * FLAGS_cate_topic_bins);
    if (v == FLAGS_cate_topic_bins) v -= 1;   // 1.0 的情况
    fea->cate_topic_fea.push_back(base::StringPrintf("%s_%d",
                                                     prefix.c_str(), v));
    fea->cate_topic_fea.push_back(base::StringPrintf("%s_%d",
                                                     prefix2.c_str(), v));
  }
}
}
}
