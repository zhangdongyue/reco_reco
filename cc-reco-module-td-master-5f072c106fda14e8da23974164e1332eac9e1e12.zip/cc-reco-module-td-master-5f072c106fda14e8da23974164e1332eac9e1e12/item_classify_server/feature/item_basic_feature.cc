#include "reco/module/item_classify_server/feature/item_basic_feature.h"

#include <unordered_map>
#include <unordered_set>

#include "base/strings/string_split.h"
#include "nlp/plsa/pwz_dict.h"
#include "nlp/plsa/pzd_predictor.h"
#include "nlp/common/term_container.h"
#include "nlp/word2vec/word2vec.h"
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/time/time_recognizer.h"
#include "nlp/common/nlp_util.h"

#include "reco/bizc/reco_plsa/reco_plsa_all_ctg.h"
#include "reco/module/item_classify_server/global_data/global_data.h"
#include "reco/module/item_classify_server/feature/item_feature_common.h"

namespace reco {
namespace item_classify {

ItemBasicFeatureExtractor::ItemBasicFeatureExtractor() {
  segmenter_ = new nlp::segment::Segmenter();
  pos_tagger_ = new nlp::postag::PosTagger();
  time_reco_ = new nlp::time::TimeRecognizer();
  entity_ = new nlp::ner::Ner();
  pzd_predictor_ = new nlp::plsa::PzdPredictor();
  reco_plsa_ = new reco::RecoPlsa();
}

bool ItemBasicFeatureExtractor::Extract(const RawItem& raw_item, ItemBasicFeature* item_basic_fea) {
  WordSegmentation(raw_item.title, &(item_basic_fea->title_terms),
                   &(item_basic_fea->title_unigrams_words),
                    &(item_basic_fea->title_unigrams_ordered_words));

  MarkLabel(raw_item, item_basic_fea);
  GenerateTopicFeature(raw_item, item_basic_fea->title_unigrams_words,
                       &(item_basic_fea->cate_topics),
                       &(item_basic_fea->topics),
                       &(item_basic_fea->lda_topics));

  GenerateContentFeature(raw_item, item_basic_fea);
  return true;
}

inline bool IsFilteredByPostag(const nlp::term::TermInfo &info) {
  if (info.is_postag(nlp::term::kWhiteSpace)
      || info.is_postag(nlp::term::kPunctuation)
      || info.is_postag(nlp::term::kPreposition)
      || info.is_postag(nlp::term::kAuxiliary)
      || info.is_postag(nlp::term::kExclamation)
      || info.is_postag(nlp::term::kQuantity)
      || info.is_postag(nlp::term::kPronoun)
      || info.is_postag(nlp::term::kConjunction)) {
    return true;
  }
  return false;
}

void ItemBasicFeatureExtractor::WordSegmentation(const std::string& norm_text,
                                                 nlp::term::TermContainer* term_container,
                                                 std::vector<std::string>* unigrams_word,
                                                 std::vector<std::string>* unigrams_word_ordered) {
  if (norm_text.size() < 1)
    return;

  term_container->renew();
  unigrams_word->clear();
  unigrams_word_ordered->clear();
  CHECK(segmenter_->SegmentT(norm_text, term_container));
  CHECK(pos_tagger_->PosTagT(norm_text, term_container));
  CHECK(entity_->DetectEntityT(norm_text, term_container));
  nlp::util::ConstructMixTerms(norm_text, false, term_container);

  const std::unordered_set<std::string>* stopwords = GlobalDataIns::instance().GetStopword().get();

  std::unordered_map<std::string, int> term_count;
  for (int i = 0; i < (int) term_container->mix_terms().size(); i++) {
    std::string word = term_container->mix_term_slice(norm_text, i).as_string();
    // 过滤掉停用词
    if (stopwords->find(word) != stopwords->end()) {
      continue;
    }

    // 过滤掉几个类型的词
    if (term_container->mix_term_info(i).is_postag(nlp::term::kWhiteSpace)
        || term_container->mix_term_info(i).is_postag(nlp::term::kPunctuation)) {
      continue;
    }
    // numberTerm
    if (term_container->mix_term_info(i).is_postag(nlp::term::kNumber)) {
      int char_num = 0;
      if (base::GetUTF8CharNum(word, &char_num) && (int) word.size() == char_num) {
        word = kNumberStr;
      }
    }
    auto it = term_count.find(word);
    if (it == term_count.end()) {
      term_count[word] = 1;
    } else {
      it->second += 1;
    }
    unigrams_word_ordered->push_back(word);
  }

  // base::Time current_time = base::Time::Now();
  // time_reco_->DetectTime(current_time, norm_text, *term_container, &time_tokens_);
  for (auto iter = term_count.begin(); iter != term_count.end(); ++iter) {
    unigrams_word->push_back(iter->first);
  }
}

void ItemBasicFeatureExtractor::MarkLabel(const RawItem& raw_item, ItemBasicFeature* item_basic_fea) {
  for (size_t i = 0; i < item_basic_fea->title_terms.mix_terms().size(); ++i) {
    const std::string& term = item_basic_fea->title_terms.mix_term_info(i).term(raw_item.title).as_string();
    item_basic_fea->flags.push_back(std::make_pair("flag_title_" + term, term));

    if (raw_item.item_type == 30) {
      item_basic_fea->flags.push_back(std::make_pair("video_title_" + term, term));
    }
  }

  std::vector<base::Slice> words;
  for (int i = 0; i < item_basic_fea->title_terms.basic_term_num(); i++) {
    if (IsFilteredByPostag(item_basic_fea->title_terms.basic_term_info(i))) continue;
    words.push_back(item_basic_fea->title_terms.basic_term_slice(raw_item.title, i));
  }

  item_basic_fea->flags.push_back(std::make_pair("source_" + raw_item.source, raw_item.source));
  item_basic_fea->flags.push_back(std::make_pair("media_" + raw_item.media, raw_item.media));

  for (int i = 0; i < (int) raw_item.keywords.size(); i++) {
    words.push_back("$$##++++##$$");   // 分隔符
    const std::string& keyword = raw_item.keywords[i].first;
    words.push_back(keyword);
    item_basic_fea->flags.push_back(std::make_pair("flag_keyword_" + keyword, keyword));
  }

  std::vector<std::pair<int, int>> matches;
  std::vector<int> values;
  std::string match_value;
  std::vector<std::string> tokens;
  word_tag_dict_ = GlobalDataIns::instance().GetWordTagDict().get();
  nlp::util::ForwardMaxMatch(word_tag_dict_->dict, words, &matches, &values);
  for (int i = 0; i < (int) matches.size(); ++i) {
    const int &value = values[i];
    const std::pair<int, int> &match = matches[i];
    tokens.clear();
    // TODO(weipeng): word_tags_list_ 存已经分割好的可用的结果, 这里 string 还有几处优化
    match_value = "";
    for (int j = match.first; j < match.second; j++) {
      match_value.append(words[j].as_string());
    }
    if (value >= (int) word_tag_dict_->tags.size()) {
      LOG(ERROR) << "FATAL: " << match_value << " value=" << value
                 << " word_tag_dict_->tags.size()="
                 << word_tag_dict_->tags.size();
      continue;
    };
    base::SplitString(word_tag_dict_->tags[value], "|", &tokens);

    for (int j = 0; j < (int) tokens.size(); j++) {
      const std::string &tagWithType = tokens[j];
      if (tagWithType.at(1) == '#') {
        if (tagWithType.at(0) == '1') {
          item_basic_fea->labels.push_back(std::make_pair(tagWithType.substr(2), match_value));
          item_basic_fea->flags.push_back(std::make_pair(tagWithType.substr(2), match_value));
        } else if (tagWithType.at(0) == '2') {
          item_basic_fea->flags.push_back(std::make_pair(tagWithType.substr(2), match_value));
        }
      }
    }
  }

  // 额外的 flag
  for (int i = 0; i < (int) item_basic_fea->title_terms.mix_terms().size(); ++i) {
    if (item_basic_fea->title_terms.mix_term_info(i).is_postag(nlp::term::kHumanName)) {
      item_basic_fea->flags.push_back(std::make_pair("f_human_name",
                                                     item_basic_fea->title_terms.mix_term_slice(raw_item.title, i).as_string())); // NOLINT
      break;
    }
  }
}

void ItemBasicFeatureExtractor::GenerateTopicFeature(const RawItem& raw_item,
                                                     const std::vector<std::string>& title_unigrams_words,
                                                     std::vector<std::pair<std::string, nlp::plsa::Topic> >* cate_topics,  // NOLINT
                                                     std::vector<nlp::plsa::Topic>* topics,
                                                     std::vector<nlp::plsa::Topic>* lda_topics) {
  // 直接从 raw_item 里面取 topic
  topics->clear();
  std::vector<std::string> tokens;
  int topic_index;
  for (uint32 i = 0; i < raw_item.topics.size(); i++) {
    tokens.clear();
    base::SplitString(raw_item.topics[i].first, "-", &tokens);
    base::StringToInt(tokens[1], &topic_index);
    nlp::plsa::Topic topic;
    topic.aspect = static_cast<int16>(topic_index);
    topic.value = static_cast<float>(raw_item.topics[i].second);
    topics->push_back(topic);
  }
  // lda topics
  lda_topics->clear();
  for (uint32 i = 0; i < raw_item.title_lda_topics.size(); i++) {
    tokens.clear();
    base::SplitString(raw_item.title_lda_topics[i].first, "-", &tokens);
    base::StringToInt(tokens[1], &topic_index);
    nlp::plsa::Topic topic;
    topic.aspect = static_cast<int16>(topic_index);
    topic.value = static_cast<float>(raw_item.title_lda_topics[i].second);
    lda_topics->push_back(topic);
  }
  // generate reco_plsa features
  std::vector<base::Slice> words;
  for (int j = 0; j < (int) title_unigrams_words.size(); ++j) {
    words.push_back(title_unigrams_words[j]);
  }
  reco_plsa_->PredictPzdAllCtg(words, cate_topics);
}

void ItemBasicFeatureExtractor::GenerateContentFeature(const RawItem &raw_item, ItemBasicFeature* fea) {
  std::vector<std::string> tokens;
  nlp::term::TermContainer terms;
  std::vector<std::string> terms_word;

  base::SplitString(raw_item.content, "\n", &tokens);

  std::unordered_map<int, int> stat;
  // TOOD(*): 没必要切成段这么浪费, 每个 slice 参与处理即可
  std::vector<base::Slice> words;
  std::vector<std::string> words_ordered;
  for (int i = 0; i < (int)tokens.size(); ++i) {
    if (i > 100) break;
    std::string& content = tokens[i];
    if (content.size() > 1000) {
      content = content.substr(0, 1000);
    }
    if (content.size() < 30) {
      continue;
    }
    nlp::util::NormalizeLineInPlaceS(&content);

    WordSegmentation(content, &terms, &terms_word, &words_ordered);
    fea->paragraphs_unigrams_words.push_back(terms_word);
  }
}

ItemBasicFeatureExtractor::~ItemBasicFeatureExtractor() {
  delete segmenter_;
  delete pos_tagger_;
  delete time_reco_;
  delete entity_;
  delete pzd_predictor_;
  delete reco_plsa_;
}
}
}
