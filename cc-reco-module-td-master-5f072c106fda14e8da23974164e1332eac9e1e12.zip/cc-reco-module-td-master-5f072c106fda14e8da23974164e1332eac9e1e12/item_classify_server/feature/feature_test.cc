#include "base/common/basic_types.h"
#include "base/hash_function/term.h"
#include "base/strings/string_split.h"
#include "base/testing/gtest.h"

namespace reco {
namespace item_classify {
TEST(FeatureTest, TestTitleFeature) {
  struct {
    std::string title;
    std::string unigram;
    std::string bigram;
    std::string trigram;
  } cases[] = {
    {"京媒曝埃神下赛季或离恒大：就像上赛季的孔卡", "恒大\t埃神\t孔卡\t赛季", "京媒|埃神\t埃神|恒大"""},
    {"胖妹游日本 边走边吃的米其林美食之旅", "游日本\t美食之旅", ""},
    {"中国体操世界冠军已达七十人 近十年登历史最高点", "体操\t世界冠军", "体操|世界冠军", ""},
    {"国内航空公司之间的兼并重组或将加速 七只概念股飞升", "国内\t航空\t重组\t兼并", "概念股|飞升\t公司|重组", ""},  // NOLINT
    {"佛山一拆解公司被爆大卖报废摩托 50元回收360元卖出", "拆解公司", "报废|摩托", ""},
    {"太古汇停车费今起涨六成 广图停车场开始收费引混乱", "停车\t收费", "收费|混乱", ""},
    {"周传雄因胃病暴瘦与昔日判若两人 娇妻被藏13年现身", "周传雄\t娇妻\t胃病\t暴瘦", "周传雄|娇妻", ""},
    {"高清图：女排归京惠若琪受追捧 郎平遭媒体围堵", "女排\t郎平\t惠若琪", "郎平|惠若琪", ""},
    {"传哈文将第3次执导央视春晚 本人未回应", "哈文\t执导\t春晚", "哈文|执导", ""},
  };

  int num = ARRAYSIZE_UNSAFE(cases);
  for (int i = 0; i < num; ++i) {
  }
}
}
}
