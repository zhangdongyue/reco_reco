#pragma once

#include <string>
#include <vector>
#include <utility>
#include <unordered_map>

#include "base/strings/string_number_conversions.h"
#include "base/container/dense_hash_map.h"
#include "base/common/slice.h"
#include "nlp/common/term_container.h"
#include "nlp/time/time_recognizer.h"
#include "nlp/word2vec/word2vec.h"
#include "nlp/plsa/pzd_predictor.h"
#include "nlp/ner/ner.h"

#include "reco/bizc/reco_plsa/reco_plsa_all_ctg.h"

namespace reco {
namespace item_classify {
class RawItem;
// TODO(*): some of them same with convertor
struct ItemBasicFeature {
  void renew() {
    cate_topics.clear();
    topics.clear();
    lda_topics.clear();
    title_unigrams_words.clear();
    title_unigrams_ordered_words.clear();
    labels.clear();
    flags.clear();
    title_terms.renew();
    paragraphs_unigrams.clear();
    paragraphs_unigrams_words.clear();
  }

  std::vector<std::pair<std::string, nlp::plsa::Topic>> cate_topics;
  std::vector<nlp::plsa::Topic> topics;
  std::vector<nlp::plsa::Topic> lda_topics;

  std::vector<std::unordered_map<std::string, int>> paragraphs_unigrams;
  std::vector<std::vector<std::string>> paragraphs_unigrams_words;

  nlp::term::TermContainer title_terms;

  int parapgrah_size;
  int sentences_size;
  std::vector<std::string> title_unigrams_words;
  std::vector<std::string> title_unigrams_ordered_words;   // 有序

  std::vector<std::pair<std::string, std::string>> labels;
  std::vector<std::pair<std::string, std::string>> flags;
};

struct WordTagDict;
class ItemBasicFeatureExtractor {
 public:
  ItemBasicFeatureExtractor();

  virtual ~ItemBasicFeatureExtractor();

  bool Extract(const RawItem& raw_item, ItemBasicFeature* fea);

 private:
  nlp::segment::Segmenter* segmenter_;
  nlp::postag::PosTagger* pos_tagger_;
  nlp::ner::Ner* entity_;
  nlp::time::TimeRecognizer* time_reco_;
  std::vector<nlp::time::TimeEntity> time_tokens_;

  nlp::plsa::PzdPredictor* pzd_predictor_;
  reco::RecoPlsa* reco_plsa_;

  const WordTagDict* word_tag_dict_;

  void WordSegmentation(const std::string& norm_text,
                        nlp::term::TermContainer* term_container,
                        std::vector<std::string>* unigrams_word,
                        std::vector<std::string>* unigrams_word_ordered);

  void MarkLabel(const RawItem& raw_item, ItemBasicFeature* item_basic_fea);

  void GenerateTopicFeature(const RawItem& raw_item,
                            const std::vector<std::string>& words,
                            std::vector<std::pair<std::string, nlp::plsa::Topic> >* cate_topics,
                            std::vector<nlp::plsa::Topic>* topics,
                            std::vector<nlp::plsa::Topic>* lda_topics);

  void GenerateContentFeature(const RawItem& raw_item, ItemBasicFeature* fea);
};
}
}
