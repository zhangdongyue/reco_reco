#pragma once

#include <string>
#include <vector>
#include <utility>

#include "reco/module/item_classify_server/feature/item_basic_feature.h"

namespace nlp {
namespace plsa {
struct Topic;
}
}
namespace reco {
namespace item_classify {

// 蛋疼把特征搞成这几个 group
struct ItemClassifyFeature {
  void clear() {
    l1_topic_gbdt_fea.clear();
    video_ngram_fea.clear();
    cate_topic_fea.clear();
    stat_fea.clear();
    ngram_fea.clear();
    source_ngram_fea.clear();
    para_ngram_fea.clear();
    topic_ngram_fea.clear();
    post_flag_fea.clear();
    title_lda_ngram_fea.clear();
    lda_topic_fea.clear();
    video_title_lda_ngram_fea.clear();
  }

  std::vector<std::pair<std::string, float> > stat_fea;
  // TODO(*): rm all these fea, lr only has one vec fea
  std::vector<std::string> cate_topic_fea;

  std::vector<std::string> video_ngram_fea;

  // ngram features
  std::vector<std::string> ngram_fea;
  // source ngram features
  std::vector<std::string> source_ngram_fea;
  // parapraph ngram features
  std::vector<std::vector<std::string>> para_ngram_fea;
  // topic ngram features
  std::vector<std::string> topic_ngram_fea;
  // lda ngram features
  std::vector<std::string> title_lda_ngram_fea;
  // lda ngram features
  std::vector<std::string> video_title_lda_ngram_fea;

  // level1 topic feature
  std::vector<std::pair<uint32, float> > l1_topic_gbdt_fea;
  // lda topic
  std::vector<std::pair<uint32, float>> lda_topic_fea;
  // post flags
  std::vector<std::string> post_flag_fea;

  ItemBasicFeature basic_fea;
};

struct RawItem;
class ItemBasicFeatureExtractor;
// thread not safe
class FeatureExtractor {
 public:
  FeatureExtractor();

  virtual ~FeatureExtractor();

  void Extract(const RawItem& raw_item, ItemClassifyFeature* fea);

 private:
  ItemBasicFeatureExtractor* fea_extractor_;

  void GenerateNgramFeature(const RawItem& raw_item,
                            const ItemBasicFeature& basic_fea,
                            ItemClassifyFeature* fea);

  void GenerateContentFeature(const std::vector<std::vector<std::string> >& para_unigrams,
                              const ItemBasicFeature& basic_fea,
                              std::vector<std::vector<std::string> >* para_ngram_fea);

  void GenerteTopicFeature(const ItemBasicFeature& basic_fea, ItemClassifyFeature* fea);

  void GenerateFlagFeatures(const std::vector<std::pair<std::string, std::string> >& flags,
                            std::vector<std::string>* post_flag_fea);

  void GenerateVideoNgramFeature(const RawItem& raw_item,
                                 const ItemClassifyFeature& fea,
                                 std::vector<std::string>* video_ngram);
};
}
}
