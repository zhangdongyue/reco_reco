/**
 * Copyright (c) 2016-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */

#include "reco/module/item_classify_server/fasttext/matrix.h"

#include <random>
#include <algorithm>

#include "reco/module/item_classify_server/fasttext/utils.h"
#include "reco/module/item_classify_server/fasttext/vector.h"
#include "base/random/pseudo_random.h"
#include "base/common/logging.h"

namespace fasttext {

Matrix::Matrix() {
  m_ = 0;
  n_ = 0;
  data_ = NULL;
}

Matrix::Matrix(int64_t m, int64_t n) {
  m_ = m;
  n_ = n;
  data_ = new float[m * n];
}

Matrix::Matrix(const Matrix& other) {
  m_ = other.m_;
  n_ = other.n_;
  data_ = new float[m_ * n_];
  for (int64_t i = 0; i < (m_ * n_); i++) {
    data_[i] = other.data_[i];
  }
}

Matrix& Matrix::operator=(const Matrix& other) {
  Matrix temp(other);
  m_ = temp.m_;
  n_ = temp.n_;
  std::swap(data_, temp.data_);
  return *this;
}

Matrix::~Matrix() {
  delete[] data_;
}

void Matrix::zero() {
  for (int64_t i = 0; i < (m_ * n_); i++) {
      data_[i] = 0.0;
  }
}

void Matrix::uniform(float a) {
  // std::minstd_rand rng(1);
  // std::uniform_float_distribution<> uniform(-a, a);
  base::PseudoRandom pr;
  for (int64_t i = 0; i < (m_ * n_); i++) {
    float tmp = (float)pr.GetDouble();
    float rndNum = (tmp-0.5) * (0.5/a);
    // data_[i] = uniform(rng);
    data_[i] = rndNum;
  }
}

void Matrix::addRow(const Vector& vec, int64_t i, float a) {
  CHECK_GE(i, 0);
  CHECK_LT(i, m_);
  CHECK_EQ(vec.m_, n_);
  for (int64_t j = 0; j < n_; j++) {
    data_[i * n_ + j] += a * vec.data_[j];
  }
}

float Matrix::dotRow(const Vector& vec, int64_t i) {
  CHECK_GE(i, 0);
  CHECK_LT(i, m_);
  CHECK_EQ(vec.m_, n_);
  float d = 0.0;
  for (int64_t j = 0; j < n_; j++) {
    d += data_[i * n_ + j] * vec.data_[j];
  }
  return d;
}

void Matrix::save(std::ostream* out) {
  out->write(reinterpret_cast<const char*>(&m_), sizeof(int64_t));
  out->write(reinterpret_cast<const char*>(&n_), sizeof(int64_t));
  out->write(reinterpret_cast<const char*>(data_), m_ * n_ * sizeof(float));
}

void Matrix::load(std::istream* in) {
  in->read(reinterpret_cast<char*>(&m_), sizeof(int64_t));
  in->read(reinterpret_cast<char*>(&n_), sizeof(int64_t));
  delete[] data_;
  data_ = new float[m_ * n_];
  in->read(reinterpret_cast<char*>(data_), m_ * n_ * sizeof(float));
}
}
