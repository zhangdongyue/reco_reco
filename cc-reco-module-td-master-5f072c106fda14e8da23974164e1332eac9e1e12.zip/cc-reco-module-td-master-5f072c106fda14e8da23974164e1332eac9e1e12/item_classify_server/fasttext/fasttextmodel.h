#pragma once

#include <string>
#include <vector>
#include <memory>

#include "reco/module/item_classify_server/fasttext/args.h"
#include "reco/module/item_classify_server/fasttext/dictionary.h"
#include "reco/module/item_classify_server/fasttext/matrix.h"
#include "reco/module/item_classify_server/fasttext/model.h"
#include "base/random/pseudo_random.h"
#include "base/thread/blocking_queue.h"

namespace fasttext {
class FastTextModel {
 private:
  std::shared_ptr<Dictionary> dict_;
  int ngram_num_;  // work with dict
  thread::BlockingQueue<std::shared_ptr<Model> >* models_;

 public:
  FastTextModel() {}

  void Init(thread::BlockingQueue<std::shared_ptr<Model> >* models, std::shared_ptr<Dictionary> dict,
            int ngram_num) {
    models_ = models;
    dict_ = dict;
    ngram_num_ = ngram_num;
  }

  bool Predict(const std::string& text, int k, std::vector<std::string>* results);
  bool Predict(const std::string& t, int ki, std::vector<std::pair<std::string,float> >* r) const;  // NOLINT
};

void LoadModelWrapper(std::string filename, FastTextModel* model);
}
