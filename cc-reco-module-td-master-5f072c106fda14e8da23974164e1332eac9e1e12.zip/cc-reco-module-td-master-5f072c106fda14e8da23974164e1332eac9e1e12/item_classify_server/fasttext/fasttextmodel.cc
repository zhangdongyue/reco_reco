#include "reco/module/item_classify_server/fasttext/fasttextmodel.h"
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <utility>

#include "reco/module/item_classify_server/fasttext/args.h"
#include "reco/module/item_classify_server/fasttext/dictionary.h"
#include "reco/module/item_classify_server/fasttext/matrix.h"
#include "reco/module/item_classify_server/fasttext/model.h"
#include "base/thread/blocking_queue.h"

namespace fasttext {
DEFINE_int32(fast_worker_num, 32, "equal to thread num would be best");

bool FastTextModel::Predict(const std::string& text, int k, std::vector<std::string>* results) {
  /* Hardcoded here; since we need this variable but the variable
   * is private in dictionary.h */
  const int max_line_size = 1024;

  /* List of word ids */
  std::vector<int> text_word_ids;
  std::istringstream iss(text);
  std::string token;

  /* We implement the same logic as Dictionary::getLine */
  base::PseudoRandom pr;
  while (iss >> token) {
    int word_id = dict_->getId(token);
    if (word_id < 0) continue;
    entry_type type = dict_->getType(word_id);
    if (type == entry_type::word &&
        !dict_->discard(word_id, (float)pr.GetDouble())) {
      text_word_ids.push_back(word_id);
    }
    if (text_word_ids.size() > (unsigned)max_line_size) break;
  }
  dict_->addNgrams(&text_word_ids, ngram_num_);

  if (text_word_ids.size() > 0) {
    std::vector<std::pair<float, int>> predictions;
    std::shared_ptr<Model> model = models_->Take();
    model->predict(text_word_ids, k, &predictions);
    models_->Put(model);
    for (auto it = predictions.cbegin(); it != predictions.cend(); it++) {
      results->push_back(dict_->getLabel(it->second));
    }

    return true;
  } else {
    return false;
  }
}

bool FastTextModel::Predict(const std::string& text, int k,
                            std::vector<std::pair<std::string, float> >* results) const {
  /* Hardcoded here; since we need this variable but the variable
   * is private in dictionary.h */
  const int max_line_size = 1024;

  /* List of word ids */
  std::vector<int> text_word_ids;
  std::istringstream iss(text);
  std::string token;

  /* We implement the same logic as Dictionary::getLine */
  base::PseudoRandom pr;
  while (iss >> token) {
    int word_id = dict_->getId(token);
    if (word_id < 0) continue;
    entry_type type = dict_->getType(word_id);
    if (type == entry_type::word &&
        !dict_->discard(word_id, (float)pr.GetDouble())) {
      text_word_ids.push_back(word_id);
    }
    if (text_word_ids.size() > (unsigned)max_line_size) break;
  }
  dict_->addNgrams(&text_word_ids, ngram_num_);

  if (text_word_ids.size() > 0) {
    std::vector<std::pair<float, int>> predictions;
    std::shared_ptr<Model> model = models_->Take();
    model->predict(text_word_ids, k, &predictions);
    models_->Put(model);
    for (auto it = predictions.cbegin(); it != predictions.cend(); it++) {
      results->push_back(std::make_pair(dict_->getLabel(it->second),
                                        exp(it->first)));
    }
    return true;
  } else {
    return false;
  }
}

/* The logic is the same as FastText::loadModel, we roll our own
 * to be able to access data from args, dictionary etc since this
 * data is private in FastText class */
void LoadModelWrapper(std::string filename, FastTextModel* model) {
  int thread_num = FLAGS_fast_worker_num;
  std::ifstream ifs(filename);
  if (!ifs.is_open()) {
    LOG(ERROR)<< "interface.cc: cannot load model file ";
    LOG(ERROR) << filename << std::endl;
    exit(EXIT_FAILURE);
  }

  std::shared_ptr<Args> args = std::make_shared<Args>();
  std::shared_ptr<Dictionary> dict = std::make_shared<Dictionary>(args);
  std::shared_ptr<Matrix> input_matrix = std::make_shared<Matrix>();
  std::shared_ptr<Matrix> output_matrix = std::make_shared<Matrix>();
  args->load(&ifs);
  if (args->model != model_name::sup) {
    LOG(ERROR) << "interface.cc: cannot load model file ";
    LOG(ERROR) << filename << std::endl;
    exit(EXIT_FAILURE);
  }

  dict->load(&ifs);
  input_matrix->load(&ifs);
  output_matrix->load(&ifs);
  ifs.close();

  thread::BlockingQueue<std::shared_ptr<Model> >* model_queue = new thread::BlockingQueue<std::shared_ptr<Model> >();  // NOLINT

  for (int i = 0; i < thread_num; ++i) {
    std::shared_ptr<Model> model_p = std::make_shared<Model>(input_matrix, output_matrix, args, 0);
    model_p->setTargetCounts(dict->getCounts(entry_type::label));
    model_queue->Put(model_p);
  }
  model->Init(model_queue, dict, args->wordNgrams);
}
}  // end of namespace fasttext
