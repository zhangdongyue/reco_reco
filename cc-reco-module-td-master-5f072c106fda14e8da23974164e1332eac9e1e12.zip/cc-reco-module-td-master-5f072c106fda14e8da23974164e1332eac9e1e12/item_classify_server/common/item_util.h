#pragma once

#include <vector>
#include <utility>
#include <unordered_map>
#include <string>
#include "reco/bizc/proto/item_classify.pb.h"

#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/hbase_pool_get_sim.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace item_classify {
enum SampleOutputType {
  kLibsvm = 1
};
struct RawItem;

class ItemUtil {
 public:
  static std::string Featureinfo2Text(const FeatureInfo& feature_info);

  static std::string Classifyinfo2Text(const ClassifyInfo& classify_info, int level, bool show_detail);

  static bool GetRawitem(HBaseGetItem* hbase_pool_get_item,
                         const std::vector<uint64>& item_ids,
                         std::vector<RawItem>* raw_items);

  static bool ExpandItemFromOrigin(HBasePoolGetSim* hbase_pool_get_sim,
                                   const std::vector<std::pair<uint64, int> >& item_ids,
                                   int pos_item_count,
                                   int neg_item_count,
                                   std::unordered_map<uint64, std::pair<int, int> >* expand_samples);

  static bool GetSimItems(HBasePoolGetSim* hbase_pool_get_sim,
                          const std::vector<uint64>& item_ids,
                          std::vector<uint64>* new_item_ids,
                          int max_number,
                          int max_per_number);

  static std::string RawitemToString(const RawItem& raw_item);
};
}
}
