#pragma once

#include <string>
#include <unordered_set>
#include <vector>
#include <unordered_map>
#include "base/common/basic_types.h"

namespace reco {
namespace item_classify {
typedef std::unordered_map<std::string, std::vector<int64>> simhash_index;

class SimHashIndex {
 public:
  static void Load(std::string file_name, int k, simhash_index* index);

  static bool
  FindSimiliar(const simhash_index* index, int64 sim_hash, int k, const std::unordered_set<std::string>* black_list);

  static int FindSimiliar(const simhash_index* index, std::vector<int64> sim_hashs, int k,
                          const std::unordered_set<std::string>* black_list);
};
}
}

