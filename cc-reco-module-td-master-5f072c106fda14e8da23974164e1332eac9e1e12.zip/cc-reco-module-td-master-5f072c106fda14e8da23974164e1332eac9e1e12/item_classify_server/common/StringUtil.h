#pragma once
#include <unordered_map>
#include <string>
#include <vector>
#include <utility>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
namespace reco {
namespace item_classify {
class StringUtil {
 public:
  static bool String2Map(const std::string str,
                         std::unordered_map<std::string, std::string>* map_result,
                         const std::string& item_split_char = "|",
                         const std::string& kv_split_char = "=") {
    std::vector<std::pair<std::string, std::string> > vector_result;
    String2Vector(str, &vector_result, item_split_char, kv_split_char);
    for (size_t i = 0; i < vector_result.size(); ++i) {
      map_result->insert(std::make_pair(vector_result[i].first, vector_result[i].second));
    }
    return true;
  }

  static bool Map2String(const std::unordered_map<std::string, double>& map_input,
                         std::string *str_result,
                         const std::string& item_split_char = "|",
                         const std::string& kv_split_char = "=") {
    std::vector<std::string> str_list;
    for (auto it = map_input.begin(); it != map_input.end(); it++) {
      str_list.push_back(base::StringPrintf("%s%s%4.2f",
                                            it->first.c_str(), kv_split_char.c_str(), it->second));
    }
    base::FastJoinStrings(str_list, item_split_char, str_result);
    return true;
  }
  static bool Vector2String(const std::vector<std::pair<std::string, double> >& vec_input,
                            std::string* str_result,
                            const std::string& item_split_char = "|",
                            const std::string& kv_split_char = "=") {
    std::vector<std::string> str_list;
    for (auto it = vec_input.begin(); it != vec_input.end(); it++) {
      str_list.push_back(base::StringPrintf("%s%s%4.2f",
                                            it->first.c_str(), kv_split_char.c_str(), it->second));
    }
    base::FastJoinStrings(str_list, item_split_char, str_result);
    return true;
  }
  static bool String2Map(const std::string& str,
                         std::unordered_map<std::string, double>* map_result,
                         const std::string& item_split_char = "|",
                         const std::string& kv_split_char = "=") {
    std::vector<std::pair<std::string, std::string> > vector_result;
    String2Vector(str, &vector_result, item_split_char, kv_split_char);
    for (size_t i = 0; i < vector_result.size(); ++i) {
      double value;
      if (!base::StringToDouble(vector_result[i].second, &value)) continue;
      map_result->insert(std::make_pair(vector_result[i].first, value));
    }
    return true;
  }

  static bool String2Vector(const std::string& str,
                            std::vector<std::pair<std::string, std::string> >* vector_result,
                            const std::string& item_split_char = "|",
                            const std::string& kv_split_char = "=") {
    std::vector<std::string> tokens;
    base::SplitString(str, item_split_char, &tokens);
    for (size_t i = 0; i < tokens.size(); ++i) {
      size_t pos = tokens[i].find(kv_split_char);
      if (pos == std::string::npos) {
        LOG(ERROR) << tokens[i] << " faild to parse";
        continue;
      }
      vector_result->push_back(
          std::make_pair(tokens[i].substr(0, pos), tokens[i].substr(pos + 1, tokens[i].length() - 1)));
    }
    return true;
  }
};
}
}
