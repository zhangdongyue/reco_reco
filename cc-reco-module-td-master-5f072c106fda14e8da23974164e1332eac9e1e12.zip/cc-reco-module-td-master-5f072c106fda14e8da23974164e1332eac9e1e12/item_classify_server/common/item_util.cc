#include <unordered_map>
#include <string>
#include <utility>

#include "reco/module/item_classify_server/common/item_util.h"
#include "reco/module/item_classify_server/global_data/define.h"
#include "base/strings/string_printf.h"
#include "nlp/common/nlp_util.h"

DEFINE_int32(max_loop, 10, "max_loop");
DEFINE_bool(use_sim_score, false, "use sim score");

namespace reco {
namespace item_classify {
std::string ItemUtil::Featureinfo2Text(const FeatureInfo& feature_info) {
  std::string debug_str;
  debug_str.append(feature_info.feature_list_name());
  debug_str.append(":");
  for (int i = 0; i < feature_info.feature_name_size(); ++i) {
    if (feature_info.feature_name(i).empty()) continue;
    debug_str.append(base::StringPrintf("%s",
                                        feature_info.feature_name(i).c_str()));
    if (i != feature_info.feature_name_size()) {
      debug_str.append(",");
    }
  }
  debug_str.append("");
  return debug_str;
}

std::string ItemUtil::Classifyinfo2Text(const ClassifyInfo& classify_info, int level, bool show_detail) {
  std::string debug_str;
  debug_str.append(classify_info.method_name());
  debug_str.append(":");
  if (!show_detail) {
    for (int i = 0; i < classify_info.cate_name_size(); ++i) {
      if (level == 1 && classify_info.cate_name(i).find(",") != std::string::npos) continue;
      if (level == 2 && classify_info.cate_name(i).find(",") == std::string::npos) continue;
      debug_str.append(base::StringPrintf("%s[%2.4f]",
                                          classify_info.cate_name(i).c_str(),
                                          classify_info.cate_score(i)));
    }
  } else {
    for (int j = 0; j < classify_info.classify_detail_size(); ++j) {
      debug_str.append("\n");
      debug_str.append(classify_info.classify_detail(j));
    }
  }
  return debug_str;
}

bool ItemUtil::GetRawitem(HBaseGetItem* hbase_pool_get_item,
                          const std::vector<uint64>& item_ids,
                          std::vector<RawItem>* raw_items) {
  std::vector<reco::RecoItem> reco_items;

  hbase_pool_get_item->GetRecoItems(item_ids, &reco_items);
  RawItem raw_item;
  for (int i = 0; i < (int) reco_items.size(); i++) {
    raw_item.clear();
    raw_item.item_id = reco_items[i].identity().item_id();
    raw_item.title = reco_items[i].title();
    raw_item.source = reco_items[i].source();
    // raw_item.content = reco_items[i].raw_item().content();
    raw_item.content = reco_items[i].content();
    raw_item.media = reco_items[i].orig_source_media();
    raw_item.item_type = reco_items[i].identity().type();
    raw_item.category = reco_items[i].category(0);
    if (reco_items[i].has_region()) {
      raw_item.region = reco_items[i].region();
    }
    if (reco_items[i].category_size() == 2) {
      raw_item.category += "," + reco_items[i].category(1);
    }
    const reco::FeatureVector& fea_vec = reco_items[i].keyword();
    for (int j = 0; j < fea_vec.feature_size(); ++j) {
      raw_item.keywords.push_back(std::make_pair(fea_vec.feature(j).literal(),
                                                 fea_vec.feature(j).weight()));
    }
    const reco::FeatureVector& fea_topic = reco_items[i].topic();
    for (int j = 0; j < fea_topic.feature_size(); ++j) {
      raw_item.topics.push_back(std::make_pair(fea_topic.feature(j).literal(),
                                               fea_topic.feature(j).weight()));
    }
    const reco::FeatureVector& fea_title_lda = reco_items[i].title_lda();
    for (int k = 0; k < fea_title_lda.feature_size(); ++k) {
      if (fea_title_lda.feature(k).weight() < 0.1) continue;
      raw_item.title_lda_topics.push_back(std::make_pair(fea_title_lda.feature(k).literal(),
                                                         fea_title_lda.feature(k).weight()));
    }
    if (raw_item.item_type == 30) {
      // 视频添加爬虫标签
      raw_item.keywords.clear();
      for (int j = 0; j < reco_items[i].raw_item().spider_tags_size(); ++j) {
        raw_item.keywords.push_back(std::make_pair(reco_items[i].raw_item().spider_tags(j),
                                                   1.0));
      }
    }
    // 添加 simhash
    for (int j = 0; j < reco_items[i].paragraph_simhash_size(); ++j) {
      raw_item.para_simhash.push_back(reco_items[i].paragraph_simhash(j));
    }
    for (int j = 0; j < reco_items[i].image_size(); ++j) {
      raw_item.picture_simhash.push_back(reco_items[i].image(j).simhash());
    }
    nlp::util::NormalizeLineInPlaceS(&raw_item.title);
    nlp::util::NormalizeLineInPlaceS(&raw_item.source);
    nlp::util::NormalizeLineInPlaceS(&raw_item.media);
    std::string tmp;
    nlp::util::QuanJiaoToBanJiao(raw_item.content, &tmp);
    raw_item.content = tmp;
    raw_items->push_back(raw_item);
    LOG_EVERY_N(INFO, 300) << i << "/" << reco_items.size();
  }

  return true;
}

// bool ItemUtil::GetRawitem(const std::string& hbase_item_table,
//                           const std::vector<uint64>& item_ids,
//                           std::vector<RawItem>* raw_items) {
//   raw_items->clear();
//   reco::HBasePoolGetItem *hbase_pool_get_item = new reco::HBasePoolGetItem(hbase_item_table, 0);
//   GetRawitem(hbase_pool_get_item, item_ids, raw_items);
//   delete hbase_pool_get_item;
//   return true;
// }

bool ItemUtil::GetSimItems(HBasePoolGetSim* hbase_pool_get_sim,
                           const std::vector<uint64>& item_ids,
                           std::vector<uint64>* new_item_ids,
                           int max_number,
                           int max_per_number) {
  // 从 sim 中拉取补充数据
  std::unordered_map<uint64, int> items_map;
  for (int i = 0; i < (int) item_ids.size(); ++i) {
    items_map.insert(std::make_pair(item_ids[i], 1));
  }
  // 利用 sim 扩充样本
  std::vector<SimResult> sims;
  for (int i = 0; i < (int) item_ids.size(); ++i) {
    sims.clear();
    if (hbase_pool_get_sim->GetSimItem(item_ids[i], &sims)) {
      for (int j = 0; j < (int) sims.size(); ++j) {
        if (j > max_per_number) {
          break;
        }
        const uint64& itemid = sims[j].item_id;
        if (items_map.find(itemid) == items_map.end()) {
          items_map.insert(std::make_pair(itemid, 1));
        }
      }
    }
    // 数量够了
    if ((int) items_map.size() >= max_number) {
      break;
    }
  }
  // 扔回去
  for (auto iterator = items_map.begin(); iterator != items_map.end(); ++iterator) {
    new_item_ids->push_back(iterator->first);
  }
  return true;
}

bool ItemUtil::ExpandItemFromOrigin(HBasePoolGetSim* hbase_pool_get_sim,
                                    const std::vector<std::pair<uint64, int> >& item_ids,
                                    int pos_item_count, int neg_item_count,
                                    std::unordered_map<uint64, std::pair<int, int> >* expand_samples) {
  const int kPos = 1;
  const int kNeg = -1;
  expand_samples->clear();

  std::vector<uint64> id_vector;

  const double pos_label = 1.0;
  const double neg_label = 0.0;
  const double unknown_label = -1.0;

  std::unordered_map<uint64, double> originid_vector;
  std::unordered_map<uint64, double> item_label;
  for (int i = 0; i < (int) item_ids.size(); i++) {
    const uint64& item_id = item_ids[i].first;
    const int& item_type = item_ids[i].second;

    double label = unknown_label;
    if (item_type == kPos) {
      label = pos_label;
    } else if (item_type == kNeg) {
      label = neg_label;
    }

    id_vector.push_back(item_id);

    if (label != unknown_label) {
      originid_vector.insert(std::make_pair(item_id, label));
    }
    item_label.insert(std::make_pair(item_id, label));
  }

  // 2. 利用 sim 扩展样本
  const int max_number = 3 * (pos_item_count + neg_item_count);

  std::vector<uint64> id_quence;
  std::vector<std::vector<SimResult>> sims;
  std::unordered_map<uint64, std::vector<SimResult>> sim_result;
  std::vector<bool> rets;
  while (!id_vector.empty() && (int) sim_result.size() < max_number) {
    sims.clear();
    id_quence.clear();
    if ((int) id_vector.size() > 5) {
      for (int j = 5; j < (int) id_vector.size(); j++) {
        id_quence.push_back(id_vector[j]);
      }
    }
    id_vector.resize(5);

    sims.reserve(id_vector.size());
    rets.clear();
    hbase_pool_get_sim->GetSimItems(id_vector, &rets, &sims);
    for (int i = 0; i < (int) sims.size(); i++) {
      if (!rets[i]) continue;

      sim_result[id_vector[i]] = sims[i];
      for (int j = 0; j < (int) sims[i].size(); j++) {
        if (sim_result.find(sims[i][j].item_id) == sim_result.end()) {
          if (item_label.find(sims[i][j].item_id) == item_label.end()) {
            id_quence.push_back(sims[i][j].item_id);
            item_label.insert(std::make_pair(sims[i][j].item_id, unknown_label));
          }
        }
      }
    }
    id_vector.swap(id_quence);

    if (id_vector.empty()) break;
  }
  // 标签传播
  int loop = 0;
  double self_weight = 0.95;
  std::unordered_map<uint64, std::pair<double, double>> item_label_tmp;

  while (loop <= FLAGS_max_loop) {
    double sum = 0.0;
    item_label_tmp.clear();
    // 标签传播
    for (auto it = sim_result.begin(); it != sim_result.end(); it++) {
      const uint64& itemid = it->first;
      if (item_label[itemid] == unknown_label) continue;
      const std::vector<SimResult>& sim_list = it->second;
      for (int i = 0; i < (int) sim_list.size(); i++) {
        if (item_label_tmp.find(sim_list[i].item_id) == item_label_tmp.end()) {
          item_label_tmp[sim_list[i].item_id] = std::make_pair(0.0, 0.0);
        }
        if (FLAGS_use_sim_score) {
          item_label_tmp[sim_list[i].item_id].first += item_label[itemid] * sim_list[i].score;
          item_label_tmp[sim_list[i].item_id].second += sim_list[i].score;
        } else {
          item_label_tmp[sim_list[i].item_id].first += item_label[itemid];
          item_label_tmp[sim_list[i].item_id].second += 1;
        }
      }
    }
    // 更新
    for (auto it = item_label_tmp.begin(); it != item_label_tmp.end(); it++) {
      const uint64& itemid = it->first;
      const double score = it->second.first / it->second.second;
      if (item_label.find(itemid) != item_label.end()) {
        if (item_label[itemid] == unknown_label) {
          item_label[itemid] = score;
        } else {
          item_label[itemid] = item_label[itemid] * self_weight;
          item_label[itemid] += (1.0 - self_weight) * score;
        }
      } else {
        item_label[itemid] = score;
      }
      sum += item_label[itemid];
    }
    LOG(INFO) << "Loop:" << loop << " avg=" << sum / item_label.size();
    loop++;
  }

  int c1 = 0;
  int c2 = 0;

  for (auto it = originid_vector.begin(); it != originid_vector.end(); it++) {
    if (it->second >= neg_label) {
      if (it->second > 0.7) {
        c1++;
        expand_samples->insert(std::make_pair(it->first, std::make_pair(kPos, 1)));
      }
      if (it->second < 0.3) {
        c2++;
        expand_samples->insert(std::make_pair(it->first, std::make_pair(kNeg, 1)));
      }
    }
  }

  for (auto it = item_label.begin(); it != item_label.end(); it++) {
    if (it->second >= neg_label) {
      if (originid_vector.find(it->first) != originid_vector.end()) continue;

      if (it->second > 0.7 && c1 <= pos_item_count) {
        c1++;
        expand_samples->insert(std::make_pair(it->first, std::make_pair(kPos, 0)));
      }
      if (it->second < 0.3 && c2 <= neg_item_count) {
        c2++;
        expand_samples->insert(std::make_pair(it->first, std::make_pair(kNeg, 0)));
      }
      if (c1 > pos_item_count && c2 > neg_item_count) {
        break;
      }
    }
  }
  return true;
}

std::string ItemUtil::RawitemToString(const RawItem& raw_item) {
  std::string str;
  str.append(base::Uint64ToString(raw_item.item_id) + "\t");
  str.append(raw_item.title + "\t");
  str.append(raw_item.source + "\t");
  str.append(raw_item.media + "\t");
  for (int i = 0; i < (int) raw_item.keywords.size(); ++i) {
    str.append(raw_item.keywords[i].first);
    str.append("|");
  }
  str.append("\t");
  str.append(base::IntToString(raw_item.item_type));
  return str;
}
}
}
