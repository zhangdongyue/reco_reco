#pragma once

#include <string>
#include "base/strings/string_util.h"
#include "base/common/gflags.h"
#include "base/common/base.h"

DEFINE_string(dingding_shell, "python dingding.py text $token $msg", " ");
DEFINE_string(dingding_token, "83f61b964da2f3c7eb1913391b64416610cb1766114377458474d17eac4dea4e", " ");

namespace reco {
namespace item_classify {
class DingdingMsg {
 public:
  static void sendDingdingMsg(std::string msg) {
    std::string dingding_commond = FLAGS_dingding_shell;
    dingding_commond = base::StringReplace(dingding_commond, "$token", FLAGS_dingding_token, true);
    dingding_commond = base::StringReplace(dingding_commond, "$msg", msg, true);
    system(dingding_commond.c_str());
  }
};
}
}
