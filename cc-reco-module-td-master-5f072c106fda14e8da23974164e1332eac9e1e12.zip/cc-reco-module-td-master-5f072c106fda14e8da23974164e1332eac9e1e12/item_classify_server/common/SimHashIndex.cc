#include <fstream>
#include <iostream>
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "reco/module/item_classify_server/common/SimHashIndex.h"
#include "SimHashIndex.h"

namespace reco {
namespace item_classify {

void inline GenOffsets(int k, std::vector<int>* offsets) {
  for (int i = 0; i <= k; i++) {
    int off = 64 / (k + 1) * i;
    offsets->push_back(off);
  }
}

void inline Split2Keys(int64 simhash, int k, std::vector<int32>* keys) {
  std::vector<int> offsets;
  GenOffsets(k, &offsets);
  int32 m = 0, c;
  for (int i = 0; i <= k; i++) {
    if (i == k) {
      m = (1 << (64 - offsets[i])) - 1;
    } else {
      m = (1 << (offsets[i + 1] - offsets[i])) - 1;
    }
    c = (simhash >> offsets[i]) & m;
    keys->push_back(c);
  }
}

void SimHashIndex::Load(std::string file_name, int k, simhash_index* index) {
  std::ifstream fin(file_name, std::ifstream::binary);
  int size;
  fin.read(reinterpret_cast<char*>(&size), sizeof(size));
  std::vector<int64>* hash_list = new std::vector<int64>();
  hash_list->resize(size);
  fin.read(reinterpret_cast<char*>(&hash_list->front()), size * sizeof(hash_list->front()));
  fin.close();
  //构建索引
  std::vector<int32> keys;
  for (size_t i = 0; i < hash_list->size(); ++i) {
    keys.clear();
    int64 simhash = hash_list->at(i);
    Split2Keys(simhash, k, &keys);
    std::string key;
    for (int j = 0; j < k + 1; ++j) {
      key = base::StringPrintf("%d-%d", j, keys[j]);
      auto it = index->find(key);
      if (it == index->end()) {
        index->insert(std::make_pair(key, std::vector<int64>()));
        it = index->find(key);
      }
      it->second.push_back(simhash);
    }
  }
}

inline int32 HammingDistance(int64 hash1, int64 hash2) {
  int64 i = hash1 ^hash2;
  i = i - ((i >> 1) & 0x5555555555555555L);
  i = (i & 0x3333333333333333L) + ((i >> 2) & 0x3333333333333333L);
  i = (i + (i >> 4)) & 0x0f0f0f0f0f0f0f0fL;
  i = i + (i >> 8);
  i = i + (i >> 16);
  i = i + (i >> 32);
  return (int32) i & 0x7f;
}

bool SimHashIndex::FindSimiliar(const simhash_index* index, int64 sim_hash, int k,
                                const std::unordered_set<std::string>* black_list) {
  if (black_list->find(base::Int64ToString(sim_hash)) != black_list->end()) {
    return false;
  }
  std::vector<int32> keys;
  Split2Keys(sim_hash, k, &keys);

  std::string key;
  for (int j = 0; j < k + 1; ++j) {
    key = base::StringPrintf("%d-%d", j, keys[j]);
    auto it = index->find(key);
    if (it == index->end()) continue;
    const auto& simhash_list = it->second;
    for (size_t i = 0; i < simhash_list.size(); ++i) {
      if (HammingDistance(simhash_list[i], sim_hash) <= k) return true;
    }
  }
  return false;
}

int SimHashIndex::FindSimiliar(const simhash_index* index, std::vector<int64> sim_hashs, int k,
                               const std::unordered_set<std::string>* black_list) {
  int c = 0;
  for (size_t i = 0; i < sim_hashs.size(); ++i) {
    if (FindSimiliar(index, sim_hashs[i], k, black_list)) c++;
  }
  return c;
}
}
}