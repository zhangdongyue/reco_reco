#pragma once
#include <cstring>
#include "base/strings/string_printf.h"
#include "reco/bizc/proto/item_classify.pb.h"
#include "base/common/slice.h"
namespace reco {
namespace item_classify {

struct CStrHash {
  size_t operator()(const char *str) const {
    size_t h = 0;
    for (; *str; ++str)
      h += *str;
    return h;
  }
};

struct SliceHash {
  size_t operator()(const base::Slice &str) const {
    size_t h = 0;
    for (int i = 0; i < (int) str.size(); ++i) h += str[i];
    return h;
  }
};

struct CStrLessCmp {
  bool operator()(const char *a, const char *b) const {
    return std::strcmp(a, b) < 0;
  }
};

struct CStrEqualCmp {
  bool operator()(const char *a, const char *b) const {
    return std::strcmp(a, b) == 0;
  }
};

template<typename CharType>
static inline const CharType *read_ptr(const CharType **ptr, size_t size) {
  const CharType *r = *ptr;
  *ptr += size;
  return r;
}

template<typename CharType, typename ValueType>
static inline void read_static(const CharType **ptr, ValueType *value) {
  const CharType *r = read_ptr(ptr, sizeof(ValueType));
  memcpy(value, r, sizeof(ValueType));
}
}
}
