#pragma once
#include "reco/bizc/proto/item_classify.pb.h"
#include "base/thread/blocking_queue.h"

namespace reco {
namespace item_classify {
class ItemClassifyController;
class ItemClassifyServiceImpl: public ItemClassifyService {
 public:
  ItemClassifyServiceImpl() {}
  explicit ItemClassifyServiceImpl(thread::BlockingQueue<ItemClassifyController* >* workers):
      workers_(workers) {}
  ~ItemClassifyServiceImpl() {}

  void ClassifyItem(::stumy::RpcController* controller,
                   const ItemClassifyRequest* request,
                   ItemClassifyResponse* response,
                   Closure* done);

  void ReloadClassifyModel(::stumy::RpcController* controller,
                           const ReloadClassifyModelRequest* request,
                           ReloadClassifyModelResponse* response,
                           Closure* done);

  void StatCategoryHist(::stumy::RpcController* controller,
                        const StatCategoryHistRequest* request,
                        StatCategoryHistResponse* response,
                        Closure* done);
 private:
  thread::BlockingQueue<ItemClassifyController*>* workers_;
};
}
}
