#include "reco/module/item_classify_server/frame/item_classify_controller.h"

#include <utility>
#include <unordered_set>
#include <unordered_map>
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"

#include "reco/module/item_classify_server/strategy/item_classifier.h"
#include "reco/module/item_classify_server/strategy/video_classifier.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

namespace reco {
namespace item_classify {

ItemClassifyController::ItemClassifyController() {
  item_classifier_ = new ItemClassifier();
  video_classifier_ = new VideoClassifier();

  useless_tags_.insert("新闻");
  useless_tags_.insert("视频:");
  useless_tags_.insert("视频");
  useless_tags_.insert("搞笑");
  useless_tags_.insert("美女");
  useless_tags_.insert("国内");
}

ItemClassifyController::~ItemClassifyController() {
  delete item_classifier_;
  delete video_classifier_;
}

static void GenerateRawItem(const std::unordered_set<std::string>& useless_tags,
                            const ItemClassifyRequest& request,
                            RawItem* raw_item) {
  raw_item->clear();
  // debug level
  raw_item->is_debug = false;
  if (request.has_is_debug()) raw_item->is_debug = request.is_debug();
  raw_item->debug_level = 0;
  // debug level: 0 无 =1 分类; =2 特征; =3 分类+特征
  if (request.has_debug_level()) raw_item->debug_level = request.debug_level();
  if (raw_item->debug_level > 0) raw_item->is_debug = true;

  // keywords
  const std::unordered_set<std::string>* kw_stopwords
          = GlobalDataIns::instance().GetKeywordStopword().get();

  std::vector<std::pair<std::string, double> >& keywords = raw_item->keywords;
  keywords.clear();
  keywords.reserve(request.keywords_size());
  for (int i = 0; i < request.keywords_size(); ++i) {
    if (kw_stopwords->find(request.keywords(i)) != kw_stopwords->end()) continue;
    keywords.push_back(std::make_pair(request.keywords(i), 1.0));
  }
  // topic
  std::vector<std::pair<std::string, double> >& topics = raw_item->topics;
  for (int i = 0; i < request.topic().feature_size(); ++i) {
    topics.push_back(std::make_pair(request.topic().feature(i).literal(),
                                   request.topic().feature(i).weight()));
  }
  // lda topic
  std::vector<std::pair<std::string, double> >& lda_topics = raw_item->title_lda_topics;
  for (int i = 0; i < request.title_lda_topic().feature_size(); ++i) {
    lda_topics.push_back(std::make_pair(request.title_lda_topic().feature(i).literal(),
                                    request.title_lda_topic().feature(i).weight()));
  }
  // tags
  std::vector<std::string>& tags = raw_item->tags;
  std::string cate_names="";
  for (int i = 0;  i < 32 && i < (int)request.tags().size(); ++i) {
    if (useless_tags.find(request.tags(i)) == useless_tags.end()) {
      tags.push_back(request.tags(i));
    }
  }
  std::unordered_set<int64> simhash_uniq;
  // para simhash
  std::vector<int64>& para_simhash = raw_item->para_simhash;
  for (int j = 0; j < request.para_simhash_size() && j <= 10; ++j) {
    if (simhash_uniq.find(request.para_simhash(j)) != simhash_uniq.end()) continue;
    para_simhash.push_back(request.para_simhash(j));
    simhash_uniq.insert(request.para_simhash(j));
  }
  // picture simhash
  std::vector<int64>& picture_simhash = raw_item->picture_simhash;
  for (int j = 0; j < request.picture_simhash_size() && j <= 10; ++j) {
    if (simhash_uniq.find(request.picture_simhash(j)) != simhash_uniq.end()) continue;
    picture_simhash.push_back(request.picture_simhash(j));
    simhash_uniq.insert(request.picture_simhash(j));
  }
  raw_item->item_id = request.item_id();
  raw_item->title = request.title();
  // 标题截断
  if (raw_item->title.length() > 100) raw_item->title = raw_item->title.substr(0, 100);
  raw_item->content = request.content();
  raw_item->source = request.source();
  raw_item->item_type = request.item_type();
  raw_item->media = request.media();

  nlp::util::NormalizeLineInPlaceS(&raw_item->title);
  nlp::util::NormalizeLineInPlaceS(&raw_item->source);
  nlp::util::NormalizeLineInPlaceS(&raw_item->media);
}

static void WriteDebugInfo(const std::vector<FeatureInfo>& feature_debug_info,
                           const std::vector<ClassifyInfo>& classify_debug_info,
                           int debug_level,
                           ItemClassifyResponse* response) {
  auto debug_info = response->mutable_debug_info();
  // 特征 debug 信息
  if (debug_level == 1 || debug_level >= 3) {
    for (int j = 0; j < (int) feature_debug_info.size(); ++j) {
      auto it = debug_info->add_feature_info();
      it->set_feature_list_name(feature_debug_info[j].feature_list_name());
      for (int k = 0; k < feature_debug_info[j].feature_name_size(); ++k) {
        it->add_feature_name(feature_debug_info[j].feature_name(k));
        it->add_feature_value(feature_debug_info[j].feature_value(k));
      }
    }
  }
  // 分类 debug 信息
  if (debug_level == 2 || debug_level >= 3) {
    for (int j = 0; j < (int) classify_debug_info.size(); ++j) {
      auto it = debug_info->add_classify_info();
      it->set_method_name(classify_debug_info[j].method_name());
      for (int k = 0; k < classify_debug_info[j].cate_name_size(); ++k) {
        it->add_cate_name(classify_debug_info[j].cate_name(k));
        it->add_cate_score(classify_debug_info[j].cate_score(k));
      }
      if (debug_level >= 4) {
        for (int k = 0; k < classify_debug_info[j].classify_detail_size(); ++k) {
          it->add_classify_detail(classify_debug_info[j].classify_detail(k));
        }
      }
    }
  }
}

void ItemClassifyController::Classify(const ItemClassifyRequest* request, ItemClassifyResponse* response) {
  // preprae
  response->set_success(false);
  item_classify_result_.clear();
  raw_item_.clear();
  GenerateRawItem(useless_tags_, *request, &raw_item_);

  if (request->item_type() != 30) {
    item_classifier_->Classify(raw_item_, &item_classify_result_);
    if (raw_item_.is_debug) {
      WriteDebugInfo(item_classifier_->feature_infos(), item_classifier_->classify_infos(),
                     raw_item_.debug_level, response);
    }
  } else {
    video_classifier_->Classify(raw_item_, &item_classify_result_.best_result,
                                &item_classify_result_.multi_result, &item_classify_result_.tag_result);
    if (raw_item_.is_debug) {
      WriteDebugInfo(video_classifier_->feature_infos(), video_classifier_->classify_infos(),
                     raw_item_.debug_level, response);
    }
  }

  for (int j = 0; j < (int) item_classify_result_.multi_result.size(); ++j) {
    response->add_category_candidates(item_classify_result_.multi_result[j].second);
    response->add_score(item_classify_result_.multi_result[j].first);
  }
  for (size_t j = 0; j < item_classify_result_.tag_result.size(); ++j) {
    response->add_tag_score(item_classify_result_.tag_result[j].first);
    response->add_tag_candidates(item_classify_result_.tag_result[j].second);
  }
  for (size_t j = 0; j < item_classify_result_.post_tag_result.size(); ++j) {
    response->add_post_tag_score(item_classify_result_.post_tag_result[j].first);
    response->add_post_tag_candidates(item_classify_result_.post_tag_result[j].second);
  }

  if (item_classify_result_.best_result.size() == 0 || item_classify_result_.best_result[0].second.size() < 1) { // NOLINT
    LOG(INFO) << request->title() << " id=" << request->item_id()
              << " cate=未分类";
    return;
  }

  LOG(INFO) << request->title() << " id=" << request->item_id()
            << " cate=" << item_classify_result_.best_result[item_classify_result_.best_result.size()-1].second; // NOLINT
  response->set_success(true);

  for (int i = 0; i < (int) item_classify_result_.best_result.size(); ++i) {
    std::string cate_name = item_classify_result_.best_result[i].second;
    size_t pos = cate_name.rfind(",");
    if (pos != std::string::npos) {
      cate_name = cate_name.substr(pos + 1);
    }
    response->add_category(cate_name);
  }
}

void ItemClassifyController::StatHist(const StatCategoryHistRequest* request,
                                      StatCategoryHistResponse* response) {
  std::unordered_map<std::string, int> hist;
  std::vector<std::string> tokens;

  for (int i = 0; i < request->title_size(); ++i) {
    raw_item_.clear();
    raw_item_.is_debug = false;
    raw_item_.item_id = 0;
    raw_item_.title = request->title(i);
    nlp::util::NormalizeLineInPlaceS(&raw_item_.title);
    nlp::util::NormalizeLineInPlaceS(&raw_item_.source);
    nlp::util::NormalizeLineInPlaceS(&raw_item_.media);

    item_classify_result_.clear();

    bool find = false;
    item_classifier_->Classify(raw_item_, &item_classify_result_);
    for (int j = 0; j < (int)item_classify_result_.best_result.size(); ++j) {
      if (item_classify_result_.best_result[j].second.size() < 1) {
        LOG(ERROR) << base::StringPrintf(
            "empty category for title: %s and source: %s",
            request->title(i).c_str(),
            request->source().c_str());
        continue;
      }
      tokens.clear();
      base::SplitString(item_classify_result_.best_result[j].second, ",", &tokens);
      auto it_pair = hist.insert(std::make_pair(tokens.front(), 1));
      if (!it_pair.second) {
        it_pair.first->second += 1;
      }
      auto it_pair2 = hist.insert(std::make_pair(item_classify_result_.best_result[j].second, 1));
      if (!it_pair2.second) {
        it_pair2.first->second += 1;
      }
      response->add_title_result(request->title(i) + "\t" + item_classify_result_.best_result[j].second);
      find = true;
      break;
    }
    if (!find) {
      response->add_title_result(request->title(i) + "\t" + "未分类");
    }
  }
}
}
}
