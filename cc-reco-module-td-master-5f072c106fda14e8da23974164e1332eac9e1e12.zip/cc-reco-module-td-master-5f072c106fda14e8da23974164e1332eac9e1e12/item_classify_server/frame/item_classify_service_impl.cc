#include "reco/module/item_classify_server/frame/item_classify_service_impl.h"

#include <string>
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "serving_base/data_manager/data_manager.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/utility/timer.h"

#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/module/item_classify_server/global_data/global_data.h"
#include "reco/module/item_classify_server/frame/item_classify_controller.h"

namespace reco {
namespace item_classify {

DEFINE_int64_counter(classify, total_request, 0, "");
DEFINE_int64_counter(classify, total_response_time, 0, "total response time, unit: ms");

void ItemClassifyServiceImpl::ClassifyItem(::stumy::RpcController* controller,
                                           const ItemClassifyRequest* request,
                                           ItemClassifyResponse* response,
                                           Closure* done) {
  COUNTERS_classify__total_request.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_done(done);
  response->set_success(false);
  ItemClassifyController* classify_controller = NULL;
  int status = workers_->TimedTake(20, &classify_controller);
  if (status == -1) {
    LOG(ERROR) << "server maybe closed";
    return;
  }

  if (status == 0) {
    LOG(ERROR) << "timeout, server is busy";
    return;
  }

  classify_controller->Classify(request, response);
  response->set_success(true);
  workers_->Put(classify_controller);

  COUNTERS_classify__total_response_time.Increase(timer.Stop() / 1000);
}

void ItemClassifyServiceImpl::ReloadClassifyModel(::stumy::RpcController* controller,
                                                  const ReloadClassifyModelRequest* request,
                                                  ReloadClassifyModelResponse* response,
                                                  Closure* done) {
  ScopedClosure scoped_done(done);
  response->set_success(false);
  std::string timestr;
  CHECK(serving_base::TimeHelper::TimestampToString(
                request->timestamp(), serving_base::TimeHelper::kSecond, &timestr));
  LOG(INFO) << "reload model in: " << timestr;
  response->set_success(true);
}

void ItemClassifyServiceImpl::StatCategoryHist(::stumy::RpcController* controller,
                                               const StatCategoryHistRequest* request,
                                               StatCategoryHistResponse* response,
                                               Closure* done) {
  ScopedClosure scoped_done(done);
  response->set_success(false);

  ItemClassifyController* classify_controller = NULL;
  int status = workers_->TimedTake(20, &classify_controller);
  if (status == -1) {
    LOG(ERROR) << "server maybe closed";
    return;
  }

  if (status == 0) {
    LOG(ERROR) << "timeout, server is busy";
    return;
  }

  classify_controller->StatHist(request, response);
  workers_->Put(classify_controller);

  response->set_success(true);
}
}
}
