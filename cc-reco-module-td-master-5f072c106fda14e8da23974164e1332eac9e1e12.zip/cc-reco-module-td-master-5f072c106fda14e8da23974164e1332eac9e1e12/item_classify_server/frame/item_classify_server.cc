#include <iostream>
#include <sstream>

#include "base/common/gflags.h"
#include "base/common/basic_types.h"
#include "base/file/file_path.h"
#include "base/thread/thread.h"
#include "base/thread/blocking_var.h"
#include "base/time/timestamp.h"
#include "net/rpc/rpc.h"
#include "net/counter/export.h"
#include "serving_base/utility/signal.h"

#include "reco/module/item_classify_server/frame/item_classify_service_impl.h"
#include "reco/module/item_classify_server/frame/item_classify_controller.h"
#include "reco/module/item_classify_server/global_data/global_data.h"
#include "reco/base/dict_manager/reload_service_impl.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

DEFINE_int32(port, 20004, "item classify server port");
DEFINE_int32(thread_num, 4, "thread_num");

void Reloader(thread::BlockingVar<int>* finish_num) {
  // reload every 10 min
  uint64 start = base::GetTimestamp();
  while (true) {
    int n = finish_num->Take();
    if (n > 0) break;
    CHECK(finish_num->TryPut(n));
    uint64 end = base::GetTimestamp();
    if ((end - start) / 1000000 > 600) {
      start = end;
      thread::AutoLock(&reco::item_classify::GlobalDataIns::instance().dict_reload_mutex_);
      if (end - reco::item_classify::GlobalDataIns::instance().last_reload_time_ < 5000000) {
        LOG(INFO) << "drop current reloading";
        continue;
      }

      std::string reason;
      bool succ = reco::dm::DictManagerSingleton::instance().ReloadByDictName("kSourceCategoryName");
      if (!succ) {
        LOG(ERROR) << "failed to reload dict: ";
        base::SleepForSeconds(10);
        continue;
      }
      reco::item_classify::GlobalDataIns::instance().last_reload_time_ = end;
    }
    base::SleepForSeconds(10);
  }
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "item classify server");
  reco::item_classify::GlobalDataIns::instance().Init();
  reco::hbase::HBasePoolIns::instance().Init();

  // controller
  thread::BlockingQueue<reco::item_classify::ItemClassifyController*> workers;
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    workers.Put(new reco::item_classify::ItemClassifyController());
  }

  reco::item_classify::ItemClassifyServiceImpl classify_service(&workers);
  reco::dm::ReloadServiceImpl reload_service;

  net::rpc::RpcServer::Options opt;
  opt.port = FLAGS_port;
  opt.server_thread_num = FLAGS_thread_num;
  opt.pump_thread_num = 4;
  net::rpc::RpcServer* server = new net::rpc::RpcServer(opt);

  CHECK(server->ExportService(&classify_service));
  CHECK(server->ExportService(&reload_service));

  server->Start();
  LOG(INFO) << "item classify server start";

  net::counter::HttpCounterExport();

  serving_base::SignalCatcher::Initialize();

  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
//  thread::Thread load_thread;
//  load_thread.Start(::NewCallback(Reloader, &finish_num));
  serving_base::SignalCatcher::WaitForSignal();
  int n = finish_num.Take() + 1;
  CHECK(finish_num.TryPut(n));
  server->Stop();
//  load_thread.Join();
  LOG(INFO) << "server frame stop";

  return 0;
}
