#pragma once

#include <string>
#include <vector>
#include <unordered_set>
#include <utility>

#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/module/item_classify_server/global_data/define.h"

namespace reco {
namespace item_classify {

class ItemClassifier;
class VideoClassifier;
class ItemClassifyRequest;
class ItemClassifyResponse;

class ItemClassifyController {
 public:
  explicit ItemClassifyController();
  ~ItemClassifyController();

  void Classify(const ItemClassifyRequest* request,
                ItemClassifyResponse* response);

  void StatHist(const StatCategoryHistRequest* request, StatCategoryHistResponse* response);
 private:
  ItemClassifier* item_classifier_;
  VideoClassifier* video_classifier_;

 private:
  std::unordered_set<std::string> useless_tags_;
  ItemClassifyResult item_classify_result_;
  RawItem raw_item_;
};
}
}
