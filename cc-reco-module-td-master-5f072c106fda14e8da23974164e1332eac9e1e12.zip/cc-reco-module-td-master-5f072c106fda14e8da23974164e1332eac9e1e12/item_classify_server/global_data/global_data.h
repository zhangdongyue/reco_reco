#pragma once

#include <boost/shared_ptr.hpp>
#include <cstdatomic>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
#include <set>
#include "reco/bizc/proto/common.pb.h"

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/file/file_path.h"
#include "base/thread/sync.h"
#include "reco/base/common/singleton.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/module/item_classify_server/global_data/define.h"
#include "reco/module/item_classify_server/common/SimHashIndex.h"

// |GlobalData| 管理所有的静态数据资源, 在策略部分可以被直接使用
namespace serving_base {
namespace mysql_util {
class DbConnManager;
}
}
namespace reco {
namespace redis {
class RedisCli;
}

namespace item_classify {
class SourceCategoryDict;
class GlobalData {
 public:
  GlobalData() {}

  ~GlobalData() {}

  void Init();

  // 非在线服务使用的， 只加载特征相关词表
  void InitFeatureDicts();

 public:
  boost::shared_ptr<const std::unordered_map<std::string, double> > GetCateThreshold() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrDouble, kCateThresholdFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::string> > GetCateDefaultCate() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrStr, kSourceDefaultCateFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::string> > GetCateMap() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrStr, kCateMapFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::string> > GetCateAppendMap() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrStr, kCateAppendListFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::string> > GetMultiCateAppendMap() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrStr, kMultiCateAppendListFile);
  }

  boost::shared_ptr<const simhash_index> GetHumorHashList() {
    return DM_GET_DICT(simhash_index, kHumorHashFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string> > GetHumorHashBlackList() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kHumorHashBlackListFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string> > GetForbiddenCateMap() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kForbiddenCateFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, double> > GetTagList() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrDouble, kTagListFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, double> > GetVideoTagList() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrDouble, kVideoTagListFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, double> > GetPostTagList() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrDouble, kPostTagListFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string> > GetDefaultAllowCate() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kDefaultAllowCateFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string> > GetSpecialSourceDict(const std::string& cate) {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kMeinvSourceDict);
  }

  boost::shared_ptr<const std::unordered_set<std::string> > GetStopword() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kStopwordFile);
  }
  boost::shared_ptr<const std::unordered_set<std::string> > GetKeywordStopword() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kKeywordStopwordFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::vector<std::string> > > GetCateConstraint() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrVectorStr, kCateConstraintFile);
  }

  boost::shared_ptr<const RuleDict> GetPreRuleDict() {
    return DM_GET_DICT(RuleDict, kPreRuleDictFile);
  }
  boost::shared_ptr<const RuleDict> GetPostRuleDict() {
    return DM_GET_DICT(RuleDict, kPostRuleDictFile);
  }

  boost::shared_ptr<const RawRuleDict> GetRawRuleDict() {
    return DM_GET_DICT(RawRuleDict, kRawRuleDictFile);
  }

  boost::shared_ptr<const RawRuleDict> GetPairSemanticDict() {
    return DM_GET_DICT(RawRuleDict, kPairSemanticDictFile);
  }

  boost::shared_ptr<const RuleDict> GetVideoRuleDict() {
    return DM_GET_DICT(RuleDict, kVideoRuleDictFile);
  }

  boost::shared_ptr<const PostDict> GetPostRuleList() {
    return DM_GET_DICT(PostDict, kPostRuleFile);
  }

  boost::shared_ptr<const PostDict> GetVideoPostRuleList() {
    return DM_GET_DICT(PostDict, kVideoPostRuleFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, double> > GetVideoCategory() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrDouble, kVideoCategoryFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::string> > GetVideoCateMap() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrStr, kVideoCateMapFile);
  }

  // NOTE(*): 一个 pured dict 一个 default dict 代替原来的 source category manager
  boost::shared_ptr<const std::unordered_map<std::string, std::string> > GetPureDict() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrStr, kPureDictFile);
  }

  boost::shared_ptr<const std::unordered_set<std::string> > GetBadSource() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kBadSource);
  }

  boost::shared_ptr<const SourceCategoryDict> GetSourceCategoryDict() {
    return DM_GET_DICT(SourceCategoryDict, kSourceCategoryName);
  }

  boost::shared_ptr<const LRModel> GetLRModel() {
    return DM_GET_DICT(LRModel, kLRModelFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::unordered_map<std::string, double> > >
  GetSourceHistoryStat() { // NOLINT
    typedef std::unordered_map<std::string, std::unordered_map<std::string, double>> MapStrMapStrDouble;
    return DM_GET_DICT(MapStrMapStrDouble, KSourceHistoryStatFile); // NOLINT
  }

  boost::shared_ptr<const WordTagDict> GetWordTagDict() {
    return DM_GET_DICT(WordTagDict, kWordTagFile);
  }

  boost::shared_ptr<const XGboostModel> GetXGBoostModel(const std::string& XGboostModelName) {
    return reco::dm::DictManagerSingleton::instance().GetDict<const XGboostModel>(XGboostModelName);
  }

  boost::shared_ptr<const fasttext::FastTextModel::FastTextModel> GetFastTextModel() {
    return DM_GET_DICT(fasttext::FastTextModel::FastTextModel, kFastTextModelFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, std::vector<std::pair<std::string, double> > > >
  GetHighLevelModel() { // NOLINT
    typedef std::unordered_map<std::string, std::vector<std::pair<std::string, double> > > MapStrVectorStrDouble;  // NOLINT
    return DM_GET_DICT(MapStrVectorStrDouble, kHighLevelModelFile); // NOLINT
  }

  boost::shared_ptr<const std::vector<XGboostModel*>> GetXGBoostMultiModel(const std::string& model_name) { // NOLINT
    typedef std::vector<XGboostModel*> XGBoostMutModel;  // NOLINT
    return reco::dm::DictManagerSingleton::instance().GetDict<const XGBoostMutModel>(model_name);
  }

 public:
  //   // static dict
  const CategoryMap* category_map() {
    return category_map_;
  }

  serving_base::mysql_util::DbConnManager* db_manager_;
  thread::Mutex dict_reload_mutex_;
  uint64 last_reload_time_;

 public:
  int GetCategoryIDbyName(const std::string& category) {
    if (category.empty()) return 0;
    auto it = category_map_->category_dict.find(category);
    if (it == category_map_->category_dict.end()) return 0;
    return it->second & 0xffff;
  }

  int GetCategoryType(const std::string& category) {
    if (category.empty()) return 0;
    auto it = category_map_->category_dict.find(category);
    if (it == category_map_->category_dict.end()) return 0;
    return it->second >> 16 & 0xff;
  }

 private:
  WordTagDict* word_tag_dict_;
  CategoryMap* category_map_;
  LRModel* lr_model_;

  std::vector<PostRule>* post_rule_list_;
  std::unordered_map<std::string, std::unordered_map<std::string, double> >* source_stat_;
};
typedef reco::common::singleton_default<GlobalData> GlobalDataIns;
}  // namespace item_classify
}  // namespace reco
