#include "reco/module/item_classify_server/global_data/global_data.h"

#include <vector>
#include <string>
#include <unordered_map>

#include "base/file/file_path.h"
#include "nlp/word2vec/word2vec.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/base/dict_manager/dynamic_dict.h"
#include "reco/base/dict_manager/dict_manager.h"

#include "reco/module/item_classify_server/global_data/dict_loader.h"
#include "reco/module/item_classify_server/global_data/source_category_dict.h"

DEFINE_bool(default_init, true, "默认初始化为 true 时,加载所有词典,为false时,由调用方自行加载词典,用于测试");
DEFINE_string(data_dir, "../data", "data dir");

namespace reco {
namespace item_classify {
const std::string kCateThresholdFile = "threshold.txt";
const std::string kCateMapFile = "catemap.txt";

const std::string kCateAppendListFile = "cate_append.txt";
const std::string kMultiCateAppendListFile = "cate_multi.txt";

const std::string kForbiddenCateFile = "forbidden_cate.txt";

const std::string kDefaultAllowCateFile = "cate_default_allow.txt";

const std::string kSourceDefaultCateFile = "default_category.txt";  // source 的绑定分类信息
const std::string KSourceHistoryStatFile = "source_stat.txt";  // source 后验统计信息

const std::string kCateConstraintFile = "cate_constraint.txt";
const std::string kTagListFile = "tag_list.txt";
const std::string kVideoTagListFile = "video_tag_list.txt";

const std::string kPostTagListFile = "post_tag_list.txt";
const std::string kStopwordFile = "stopword.txt";
const std::string kKeywordStopwordFile = "kw_stopword.txt";


const std::string kWordTagFile = "word_tags.bin";

const std::string kAllCategoryFile = "all_category.txt";

const std::string kPreRuleDictFile = "ngram_rule.txt";
const std::string kPostRuleDictFile = "ngram_post_rule.txt";

const std::string  kHumorHashFile = "humor_hash.bin";
const std::string  kHumorHashBlackListFile = "humor_hash_black.txt";

const std::string kLRModelFile = "lr.dat";

const std::string kL1TopicGBDTModelFile = "level1_topic_gbdt.bin";

const std::string kLDAXGBoostModelFile = "lda_xgboost.model";

const std::string kFastTextModelFile = "fasttext.bin";

const std::string kHighLevelModelFile = "high_level_model.dat";

const std::string kPostRuleFile = "post_classify_rule.txt";
const std::string kVideoPostRuleFile = "video_post_rule.txt";

const std::string kVideoCategoryFile = "video_categoy.txt";
const std::string kVideoCateMapFile = "video_cate_map.txt";
const std::string kVideoRuleDictFile = "video_rule.txt";

const std::string kPureDictFile = "pure_dict.txt";
const std::string kBadSource = "bad_source.txt";
const std::string kRawRuleDictFile = "raw_rule_dict.dat";
const std::string kPairSemanticDictFile = "pair_semantic.dat";
const std::string kMeinvSourceDict = "meinv_source.txt";

// do not exist just for reload source category dict
// const std::string kSourceCategoryName = "source.dummy";
void GlobalData::Init() {
  // 默认初始化会加载所有词典,但在单元测试之类的场景则没有必要,
  // 所以单测时可以设置默认初始化为 false,然后手工调用指定词典的加载函数;
  if (!FLAGS_default_init) return;

  base::FilePath rdir(FLAGS_data_dir);
  // 3: dynamic dicts
  DM_REGISTER_COMMON_DICT(UnorderedMapStrDouble, kCateThresholdFile);
  DM_REGISTER_COMMON_DICT(UnorderedMapStrStr, kCateMapFile);
  DM_REGISTER_COMMON_DICT(UnorderedMapStrStr, kCateAppendListFile);
  DM_REGISTER_COMMON_DICT(UnorderedMapStrStr, kMultiCateAppendListFile);
  DM_REGISTER_COMMON_DICT(UnorderedMapStrStr, kSourceDefaultCateFile);
  DM_REGISTER_COMMON_DICT(UnorderedSetStr, kForbiddenCateFile);
  DM_REGISTER_COMMON_DICT(UnorderedSetStr, kDefaultAllowCateFile);
  DM_REGISTER_COMMON_DICT(UnorderedSetStr, kStopwordFile);
  DM_REGISTER_COMMON_DICT(UnorderedSetStr, kKeywordStopwordFile);

  DM_REGISTER_COMMON_DICT(UnorderedMapStrVectorStr, kCateConstraintFile);
  DM_REGISTER_COMMON_DICT(UnorderedMapStrDouble, kTagListFile);
  DM_REGISTER_COMMON_DICT(UnorderedMapStrDouble, kVideoTagListFile);

  DM_REGISTER_COMMON_DICT(UnorderedMapStrDouble, kPostTagListFile);

  DM_REGISTER_COMMON_DICT(UnorderedMapStrDouble, kVideoCategoryFile);
  DM_REGISTER_COMMON_DICT(UnorderedMapStrStr, kVideoCateMapFile);
  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrStr, kPureDictFile);
  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kBadSource);
  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kMeinvSourceDict);

  DM_REGISTER_COMMON_DICT(UnorderedSetStr, kHumorHashBlackListFile);


  // special dict registering
  reco::dm::DictManagerSingleton::instance().RegisterDict<RuleDict>("kPreRuleDictFile",
                                                                    rdir.Append(kPreRuleDictFile),
                                                                    RuleDictLoader);
  reco::dm::DictManagerSingleton::instance().RegisterDict<RuleDict>("kPostRuleDictFile",
                                                                    rdir.Append(kPostRuleDictFile),
                                                                    RuleDictLoader);
  reco::dm::DictManagerSingleton::instance().RegisterDict<RuleDict>("kVideoRuleDictFile",
                                                                    rdir.Append(kVideoRuleDictFile),
                                                                    RuleDictLoader);

  reco::dm::DictManagerSingleton::instance().RegisterDict<RuleDict>("kRawRuleDictFile",
                                                                    rdir.Append(kRawRuleDictFile),
                                                                    RawRuleDictLoader);

  reco::dm::DictManagerSingleton::instance().RegisterDict<RuleDict>("kPairSemanticDictFile",
                                                                    rdir.Append(kPairSemanticDictFile),
                                                                    RawRuleDictLoader);

  reco::dm::DictManagerSingleton::instance().RegisterDict<PostDict>("kPostRuleFile",
                                                                    rdir.Append(kPostRuleFile),
                                                                    PostRuleListLoader);

  reco::dm::DictManagerSingleton::instance().RegisterDict<PostDict>("kVideoPostRuleFile",
                                                                    rdir.Append(kVideoPostRuleFile),
                                                                    PostRuleListLoader);

  reco::dm::DictManagerSingleton::instance().RegisterDict<LRModel>("kLRModelFile",
                                                                   rdir.Append(kLRModelFile),
                                                                   LRModelLoader);

  reco::dm::DictManagerSingleton::instance().RegisterDict<XGboostModel>("kL1TopicGBDTModelFile",
                                                                        rdir.Append(kL1TopicGBDTModelFile),
                                                                        XGboostModelLoader);

  reco::dm::DictManagerSingleton::instance().RegisterDict<XGboostModel>("kHumorHashFile",
                                                                        rdir.Append(kHumorHashFile),
                                                                        HashFileModelLoader);
  reco::dm::DictManagerSingleton::instance().RegisterDict<std::vector<XGboostModel> >("kLDAXGBoostModelFile",
                                                                                     rdir.Append(kLDAXGBoostModelFile), //NOLINT
                                                                                     XGboostMultiModelLoader);
  reco::dm::DictManagerSingleton::instance().RegisterDict<WordTagDict>("kWordTagFile",
                                                                       rdir.Append(kWordTagFile),
                                                                       WordTagLoader);

  reco::dm::DictManagerSingleton::instance().RegisterDict<std::unordered_map<std::string, std::unordered_map<std::string, double> > >( // NOLINT
          "KSourceHistoryStatFile", // NOLINT
          rdir.Append(KSourceHistoryStatFile),
          SourceHistoryStatLoader);

  reco::dm::DictManagerSingleton::instance().RegisterDict<fasttext::FastTextModel::FastTextModel>
          ("kFastTextModelFile",
           rdir.Append(kFastTextModelFile),
           FastTextModelLoader);
  reco::dm::DictManagerSingleton::instance().RegisterDict<std::unordered_map<std::string, double>>
          ("kHighLevelModelFile",
           rdir.Append(kHighLevelModelFile),
           HighlevelModelLoader);
  CHECK(reco::dm::DictManagerSingleton::instance().LoadAllDicts());

  // 4: static dict
  // cate map, special dict, many model and strategy use, don't use dynamic, dangerous
  category_map_ = new CategoryMap;
  LoadCategoryMap(rdir.Append(kAllCategoryFile), category_map_);
}

void GlobalData::InitFeatureDicts() {
  base::FilePath rdir(FLAGS_data_dir);
  DM_REGISTER_COMMON_DICT(UnorderedSetStr, kStopwordFile);
  reco::dm::DictManagerSingleton::instance().RegisterDict<WordTagDict>("kWordTagFile",
                                                                       rdir.Append(kWordTagFile),
                                                                       WordTagLoader);
  CHECK(reco::dm::DictManagerSingleton::instance().LoadAllDicts());
}
}
}
