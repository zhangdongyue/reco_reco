#include <string>

#include "base/testing/gtest.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "reco/module/item_classify_server/global_data/xgboost_util.h"

namespace reco {
namespace item_classify {

DEFINE_string(data_dir, "/home/bojing.lj/tmp/predict_dir", "data dir");
DEFINE_string(model_name, "0002.model", "model name");

TEST(StreamTester, TestRead) {
  std::string model_path = FLAGS_data_dir + "/" + FLAGS_model_name;
  Stream *fi = Stream::Create(model_path.c_str(), "r");
  std::string header;
  header.resize(4);
  size_t ret = fi->Read(&header[0], 4);
  ASSERT_EQ(ret, 4u);
  ASSERT_STREQ(header.c_str(), "binf");
}
}  // namespace item_classify
}  // namesapce reco
