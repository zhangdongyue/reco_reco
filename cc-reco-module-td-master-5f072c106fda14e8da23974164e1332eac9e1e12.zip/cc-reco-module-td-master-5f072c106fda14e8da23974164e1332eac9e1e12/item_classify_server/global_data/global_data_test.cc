#include <boost/shared_ptr.hpp>
#include <unordered_map>
#include <vector>
#include <fstream>

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_split.h"
#include "base/random/pseudo_random.h"

#include "reco/base/dict_manager/dynamic_dict.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/module/item_classify_server/global_data/global_data.h"
#include "reco/module/item_classify_server/global_data/define.h"

DECLARE_string(data_dir);
DECLARE_string(nlp_dicts_root);
DECLARE_string(db_host);
DECLARE_string(db_user);
DECLARE_string(db_passwd);
DECLARE_string(schema);
namespace reco {
namespace redis {
DECLARE_string(redis_pool_ips);
}
namespace item_classify {
TEST(GlobalDataTest, TestDictLoader) {
  reco::redis::FLAGS_redis_pool_ips="10.195.157.9:6510";
  FLAGS_data_dir = "../data";
  FLAGS_nlp_dicts_root = "/serving/dict/nlp/dicts";
  FLAGS_db_host="tcp://11.251.202.229:3307";
  FLAGS_db_user="recodev";
  FLAGS_db_passwd="tkDn19DHeVZkNA";
  FLAGS_schema="reco";

  GlobalDataIns::instance().Init();

  boost::shared_ptr<const std::unordered_map<std::string, double> > cate_threshold =
      GlobalDataIns::instance().GetCateThreshold();
  ASSERT_TRUE(cate_threshold.get() != NULL);
  ASSERT_GT(cate_threshold->size(), 1u);

  boost::shared_ptr<const std::unordered_map<std::string, std::string> > cate_map =
      GlobalDataIns::instance().GetCateMap();
  ASSERT_TRUE(cate_map.get() != NULL);
  ASSERT_GT(cate_map->size(), 1u);

  boost::shared_ptr<const std::unordered_set<std::string> > forbidden_cate_map =
      GlobalDataIns::instance().GetForbiddenCateMap();
  ASSERT_TRUE(forbidden_cate_map.get() != NULL);
  ASSERT_GT(forbidden_cate_map->size(), 1u);

  boost::shared_ptr<const std::unordered_map<std::string, double> > tag_list =
      GlobalDataIns::instance().GetTagList();
  ASSERT_TRUE(tag_list.get() != NULL);
  ASSERT_GT(tag_list->size(), 1u);

  boost::shared_ptr<const std::unordered_set<std::string> > default_allow_cate =
      GlobalDataIns::instance().GetDefaultAllowCate();
  ASSERT_TRUE(default_allow_cate.get() != NULL);
  ASSERT_GT(default_allow_cate->size(), 1u);

  boost::shared_ptr<const std::unordered_set<std::string> > stopword =
      GlobalDataIns::instance().GetStopword();
  ASSERT_TRUE(stopword.get() != NULL);
  ASSERT_GT(stopword->size(), 1u);

  boost::shared_ptr<const std::unordered_map<std::string, std::vector<std::string> > > cate_constraint =
      GlobalDataIns::instance().GetCateConstraint();
  ASSERT_TRUE(cate_constraint.get() != NULL);
  ASSERT_GT(cate_constraint->size(), 1u);

  boost::shared_ptr<const RuleDict> rule_dict = GlobalDataIns::instance().GetRuleDict();
  ASSERT_TRUE(rule_dict.get() != NULL);
  ASSERT_GT(rule_dict->rule_index.size(), 1u);
  ASSERT_GT(rule_dict->rule_list.size(), 1u);
  // ASSERT_EQ(rule_dict->rule_list.size(), rule_dict->rule_index.size());

  boost::shared_ptr<const RuleDict> video_rule_dict = GlobalDataIns::instance().GetVideoRuleDict();
  ASSERT_TRUE(video_rule_dict.get() != NULL);
  ASSERT_GT(video_rule_dict->rule_index.size(), 1u);
  ASSERT_GT(video_rule_dict->rule_list.size(), 1u);
  // ASSERT_EQ(video_rule_dict->rule_list.size(), video_rule_dict->rule_index.size());

  boost::shared_ptr<const PostDict> post_dict = GlobalDataIns::instance().GetPostRuleList();
  ASSERT_TRUE(post_dict.get() != NULL);
  ASSERT_GT(post_dict->post_rule_list.size(), 1u);

  boost::shared_ptr<const std::unordered_map<std::string, double> > video_category =
      GlobalDataIns::instance().GetVideoCategory();
  ASSERT_TRUE(video_category.get() != NULL);
  ASSERT_GT(video_category->size(), 1u);

  boost::shared_ptr<const std::unordered_map<std::string, std::string> > video_cate_map =
      GlobalDataIns::instance().GetVideoCateMap();
  ASSERT_TRUE(video_cate_map.get() != NULL);
  ASSERT_GT(video_cate_map->size(), 1u);
}
}
}
