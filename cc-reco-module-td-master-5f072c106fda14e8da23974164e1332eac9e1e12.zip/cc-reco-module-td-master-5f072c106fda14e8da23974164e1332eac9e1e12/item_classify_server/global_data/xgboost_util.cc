#include <iostream>
#include <cstdio>
#include <string>

#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "reco/module/item_classify_server/global_data/xgboost_util.h"
#include "base/common/logging.h"

namespace reco {
namespace item_classify {
// XGboost 读写模型数据结构
// Stream 类
Stream* Stream::Create(const char* path,
                       const char* const flag,
                       bool try_create) {
  bool use_stdio = false;
  FILE *fp = NULL;
  fp = fopen64(path, flag);
  if (fp != NULL) {
    return new FileStream(fp, use_stdio);
  } else {
    return NULL;
  }
}

// FileStream 类
FileStream::~FileStream() {
  this->Close();
}

size_t FileStream::Read(void* ptr, size_t size) {
  return std::fread(ptr, 1, size, fp_);
}

void FileStream::Write(const void* ptr, size_t size) {
  CHECK(std::fwrite(ptr, 1, size, fp_) ==  size);
}

void FileStream::Seek(size_t pos) {
  CHECK(!std::fseek(fp_, static_cast<int64>(pos), SEEK_SET));
}

size_t FileStream::Tell() {
  return std::ftell(fp_);
}

bool FileStream::AtEnd() const {
  return std::feof(fp_) != 0;
}

/** GBM相关定义 */
GBTree::~GBTree() {
  this->Clear();
}

inline void GBTree::Clear() {
  for (size_t i = 0; i < trees.size(); i++) {
    delete trees[i];
  }
  trees.clear();
  pred_buffer.clear();
  pred_counter.clear();
  map_id2name_.clear();
}

void GBTree::SetParam(const char* name, const char* val) {
  if (!std::strncmp(name, "bst:", 4)) {
    cfg.push_back(std::make_pair(std::string(name + 4), std::string(val)));
  }
  if (trees.size() == 0) {
    mparam.SetParam(name, val);
  }
}

void GBTree::LoadModel(Stream* fi, bool with_pbuffer) {
  CHECK_GT(fi->Read(&mparam, sizeof(ModelParam)), 0u);
  trees.resize(mparam.num_trees);
  for (size_t i = 0; i < trees.size(); i++) {
    trees[i] = new RegTree();
    trees[i]->LoadModel(fi);
  }
  tree_info.resize(mparam.num_trees);
  if (mparam.num_trees != 0) {
    CHECK_GT(fi->Read(&tree_info[0], sizeof(int)*mparam.num_trees), 0u);
  }
  if (mparam.num_pbuffer != 0 && with_pbuffer) {
    pred_buffer.resize(mparam.PredBufferSize());
    pred_counter.resize(mparam.PredBufferSize());
    CHECK_GT(fi->Read(&pred_buffer[0], pred_buffer.size() * sizeof(float)), 0u);
    CHECK_GT(fi->Read(&pred_counter[0], pred_counter.size() * sizeof(unsigned)), 0u);
  }
}

void GBTree::LoadCateMap(Stream* fi) {
  this->Clear();
  int cate_map_size;
  fi->Read(&cate_map_size, sizeof(int));
  std::string cate_map;
  cate_map.resize(cate_map_size);
  fi->Read(BeginPtr(cate_map), cate_map_size);
  std::vector<std::string> classes;
  base::SplitString(cate_map, "\t", &classes);
  std::vector<std::string> tokens;
  int cate_id;
  for (size_t i = 0; i < classes.size(); i++) {
    tokens.clear();
    base::SplitString(classes[i], ":", &tokens);
    if (tokens.size() < 2) continue;
    base::StringToInt(tokens[1], &cate_id);
    if (this->map_id2name_.find(cate_id) != this->map_id2name_.end()) continue;
    this->map_id2name_[cate_id] = tokens[0];
  }
}

std::string GBTree::GetCateNameById(int cate_id) {
  return this->map_id2name_[cate_id];
}

void GBTree::SaveModel(Stream* fo, bool with_pbuffer) const {
  if (with_pbuffer) {
    fo->Write(&mparam, sizeof(ModelParam));
  } else {
    ModelParam p = mparam;
    p.num_pbuffer = 0;
    fo->Write(&p, sizeof(ModelParam));
  }
  for (size_t i = 0; i < trees.size(); ++i) {
    trees[i]->SaveModel(fo);
  }
  if (tree_info.size() != 0) {
    fo->Write(BeginPtr(tree_info), sizeof(int) * tree_info.size());
  }
  if (mparam.num_pbuffer != 0 && with_pbuffer) {
    fo->Write(BeginPtr(pred_buffer), pred_buffer.size() * sizeof(float));
    fo->Write(BeginPtr(pred_counter), pred_counter.size() * sizeof(unsigned));
  }
}

void GBTree::Predict(const SparseBatch::Inst &inst,
                     std::vector<float> *out_preds,
                     unsigned ntree_limit,
                     unsigned root_index) {
  RegTree::FVec fvec_temp = RegTree::FVec();
  fvec_temp.Init(mparam.num_feature);
  out_preds->resize(mparam.num_output_group * (mparam.size_leaf_vector+1));
  // loop over output groups
  for (int gid = 0; gid < mparam.num_output_group; ++gid) {
    this->Pred(inst, -1, gid, root_index, &fvec_temp,
               &(*out_preds)[gid], mparam.num_output_group,
               ntree_limit);
  }
}

// 分类模型相关参数
// XParam
XParam::XParam() {
  std::memset(this, 0, sizeof(XParam));
  base_score = 0.5f;
  num_feature = 0;
  num_class = 0;
  saved_with_pbuffer = 0;
}

void XParam::SetParam(const char* name, const char* val) {
  if (!strcmp("base_score", name)) base_score = static_cast<float>(atof(val));
  if (!strcmp("num_class", name)) num_class = atoi(val);
  if (!strcmp("bst:num_feature", name)) num_feature = atoi(val);
}
}  // namespace item_classify
}  // namespace reco

