#pragma once
#include <string>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "base/common/basic_types.h"
#include "base/file/file_path.h"
#include "serving_base/mysql_util/db_conn_manager.h"

namespace reco {
namespace item_classify {
enum {
  kNormal = 0,
  kStrict = 1,
  kOpen = 2,
};

enum {
  kLevel1 = 0,
  kLevel2 = 1,
};

class SourceCategoryDict {
 public:
  SourceCategoryDict();
  ~SourceCategoryDict();
  // for reload
  bool Load(const base::FilePath& dir, serving_base::mysql_util::DbConnManager* db_manager);
  bool is_valid() const { return is_valid_; }

  const std::unordered_map<uint64, int>* source_dict() const {
    return &source_dict_;
  }

  const std::vector<std::pair<std::string, int> >* sources() const {
    return &sources_;
  }

  const std::vector<std::map<std::string, std::pair<int, std::map<std::string, int>* >>*>* category_matrix () const { // NOLINT
    return &category_matrix_;
  }

  const std::unordered_map<std::string, std::pair<int, std::map<std::string, int> >>* category_dict() const {
    return &category_dict_;
  }
  const std::unordered_map<std::string, std::pair<std::string, std::string >>* default_category() const {
    return &source_to_default_category_;
  }

  std::string erro_str() { return erro_str_; }
 private:
  static const int kRetryTimes = 3;
  static const char* kCategorySupplementFile;
  static const char* kDefaultCategoryFile;
  std::unordered_map<uint64, int> source_dict_;
  std::unordered_map<uint64, int> seed_dict_;
  std::vector<std::map<std::string, std::pair<int, std::map<std::string, int>* > >*> category_matrix_;
  std::vector<std::pair<std::string, int> > sources_;
  // NOTE(xielang): category_dict 里面存二级类别时没有前缀一级
  std::unordered_map<std::string, std::pair<int, std::map<std::string, int> > > category_dict_;
  // NOTE(xielang): trick
  std::unordered_map<std::string, std::pair<std::string, std::string> > source_to_default_category_;

  std::unordered_set<std::string> open_categories_;

  serving_base::mysql_util::DbConnManager* db_manager_;

  base::FilePath data_dir_;

  std::string erro_str_;
  bool is_valid_;

  bool InitOpenCategories();

  bool LoadCategoryDict(std::unordered_map<std::string, std::pair<int, std::map<std::string, int>>>*category_dict, // NOLINT
                        std::unordered_map<uint64, std::pair<std::string, std::string >>* id_to_category);

  bool LoadVideoCategoryDict(std::unordered_map<std::string, std::pair<int, std::map<std::string, int> >>*category_dict, // NOLINT
                            std::unordered_map<uint64, std::pair<std::string, std::string >>* id_to_category);

  bool LoadAllSeed();

  bool SupplementCategory();

  bool ValidateSourceCategoryDict();

  bool LoadDictFromDb();
  bool LoadVideoDictFromDb();
  bool LoadDefaultCategory(const base::FilePath& dir);
  void Clear();

  bool SupplmentCategory();
};
}
}
