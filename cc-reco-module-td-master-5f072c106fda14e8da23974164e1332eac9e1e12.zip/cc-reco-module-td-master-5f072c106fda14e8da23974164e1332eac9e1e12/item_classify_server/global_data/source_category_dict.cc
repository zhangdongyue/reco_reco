#include "reco/module/item_classify_server/global_data/source_category_dict.h"

#include <map>
#include <unordered_map>
#include <set>
#include <fstream>
#include <vector>
#include <string>
#include <utility>
#include <cstdlib>

#include "third_party/mysql-connector/cppconn/resultset.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/scoped_ptr.h"
#include "base/hash_function/term.h"
#include "base/file/file_path.h"
#include "nlp/common/nlp_util.h"
namespace reco {
namespace item_classify {
const char* SourceCategoryDict::kCategorySupplementFile = "supplement.txt";
const char* SourceCategoryDict::kDefaultCategoryFile = "default_category.txt";
static const std::string kDummy = "dummy";
bool SourceCategoryDict::InitOpenCategories() {
  open_categories_.insert("财经");
  open_categories_.insert("宠物");
  open_categories_.insert("房产");
  open_categories_.insert("国内");
  open_categories_.insert("健康");
  open_categories_.insert("教育");
  open_categories_.insert("科学探索");
  // open_categories_.insert("旅游");
  open_categories_.insert("美食");
  open_categories_.insert("美文");
  open_categories_.insert("社会");
  open_categories_.insert("时尚");
  open_categories_.insert("游戏");
  open_categories_.insert("育儿");
  open_categories_.insert("干货");
  open_categories_.insert("科技");
  open_categories_.insert("军事");
  open_categories_.insert("职场");
  return true;
}

bool SourceCategoryDict::ValidateSourceCategoryDict() {
  std::map<int, std::string> level1_type;
  std::map<int, std::string> level2_type;
  float empty_ratio = 0;
  for (int i = 0; i < (int)category_matrix_.size(); ++i) {
    if (category_matrix_[i] == NULL || category_matrix_[i]->empty()) {
      empty_ratio += 1;
      continue;
    }
    level1_type.clear();
    for (auto it = category_matrix_[i]->begin(); it != category_matrix_[i]->end(); ++it) {
      if (it->second.first == kStrict) {
        if (category_matrix_[i]->size() != 1) {
          LOG(ERROR) << base::StringPrintf("source %s conflict in level1, level1num=%lu",
                                           sources_[i].first.c_str(),
                                           category_matrix_[i]->size());
          for (auto it = category_matrix_[i]->begin(); it != category_matrix_[i]->end(); ++it) {
            LOG(ERROR) << "category: " << it->first;
          }
          return false;
        }
        CHECK_EQ(category_matrix_[i]->size(), 1u);
      }

      auto level1_it = category_dict_.find(it->first);
      if (level1_it == category_dict_.end()) {
        LOG(ERROR) << base::StringPrintf("cannot find category %s in category table: ", it->first.c_str());
        return false;
      }
      level1_type.insert(std::make_pair(level1_it->second.first, it->first));
      // check for level1 auto exist with none auto
      if (level1_type.size() > 1) {
        auto tmp_it = level1_type.begin();
        std::pair<int, std::string> pair1 = *tmp_it;
        ++tmp_it;
        std::pair<int, std::string> pair2 = *tmp_it;
        LOG(ERROR) << base::StringPrintf("level1 auto category occur with manual category, source=%s, %s:%d and %s:%d", // NOLINT
                                       sources_[i].first.c_str(),
                                       pair1.second.c_str(),
                                       pair1.first,
                                       pair2.second.c_str(),
                                       pair2.first);
        return false;
      }

      if (it->second.second == NULL) continue;
      const std::map<std::string, int>* level2_candidates = it->second.second;
      level2_type.clear();
      for (auto it2 = level2_candidates->begin(); it2 != level2_candidates->end(); ++it2) {
        if (it2->second == kStrict) {
          if (level2_candidates->size() > 1) {
            LOG(ERROR) << base::StringPrintf("strick with multi level2, level1=%s, source=%s",
                                             it->first.c_str(),  sources_[i].first.c_str());
            return false;
          }
          CHECK_EQ(level2_candidates->size(), 1u);
        }
        auto level2_it = level1_it->second.second.find(it2->first);
        if (it2->first != kDummy && level2_it == level1_it->second.second.end()) {
          LOG(ERROR) << base::StringPrintf("cannot find category %s\t%s in category table",
                                           it->first.c_str(), it2->first.c_str());
          return false;
        } else if (level2_it != level1_it->second.second.end()) {
          level2_type.insert(std::make_pair(level2_it->second, it2->first));
        }

        if (level2_type.size() > 1) {
          auto tmp_it = level2_type.begin();
          std::pair<int, std::string> pair1 = *tmp_it;
          ++tmp_it;
          std::pair<int, std::string> pair2 = *tmp_it;
          LOG(ERROR) << base::StringPrintf("level2 conflict: %s:%d vs %s:%d, source=%s, level1=%s",
                                           pair1.second.c_str(),
                                           pair1.first,
                                           pair2.second.c_str(),
                                           pair2.first,
                                           sources_[i].first.c_str(),
                                           it->first.c_str());
          return false;
        }
      }
    }
  }
  LOG(INFO) << "empty ratio: " << empty_ratio / category_matrix_.size();
  return true;
}

SourceCategoryDict::SourceCategoryDict() {
  InitOpenCategories();
}

SourceCategoryDict::~SourceCategoryDict() {
  Clear();
}

void SourceCategoryDict::Clear() {
  sources_.clear();
  source_dict_.clear();
  category_dict_.clear();
  seed_dict_.clear();
  for (size_t i = 0; i < category_matrix_.size(); ++i) {
    for (auto it = category_matrix_[i]->begin(); it != category_matrix_[i]->end(); ++it) {
      if (it->second.second != NULL) {
        delete it->second.second;
      }
    }
    delete category_matrix_[i];
  }
  category_matrix_.clear();
}

bool SourceCategoryDict::Load(const base::FilePath& rdir,
                              serving_base::mysql_util::DbConnManager* db_manager) {
  db_manager_ = db_manager;
  data_dir_ = rdir;
  Clear();
  is_valid_ = true;

  CHECK(LoadAllSeed());
  is_valid_ = LoadDictFromDb() && LoadVideoDictFromDb();
  is_valid_ = is_valid_ && ValidateSourceCategoryDict();
  // load all defualt category
  if (!is_valid_) {
    int status = std::system("touch core.reload");
    if (status != 0) {
      LOG(ERROR) << "excute system command [touch core.reload] falied "  << status;
    }
    LOG(ERROR) << "FATAL: reload dict failed: " << erro_str_;
  }

  LoadDefaultCategory(data_dir_);
  return true;
}

bool SourceCategoryDict::LoadDefaultCategory(const base::FilePath& dir) {
  std::ifstream fin(dir.Append(kDefaultCategoryFile).value());
  std::string line;
  std::vector<std::string> flds;
  std::vector<std::string> categories;
  while (std::getline(fin, line)) {
    if (line.size() < 3) continue;
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 3) {
      LOG(ERROR) << "erro line " << line;
      continue;
    }
    nlp::util::NormalizeLineInPlaceS(&flds[0]);
    nlp::util::NormalizeLineInPlaceS(&flds[2]);
    int ngram_type = base::ParseIntOrDie(flds[1]);
    categories.clear();
    base::SplitString(flds[2], "|", &categories);
    CHECK_EQ((int)categories.size(), ngram_type) << line;
    CHECK_GT(ngram_type, 0);
    CHECK_GT(3, ngram_type);

    {
      auto it = category_dict_.find(categories[0]);
      CHECK(it != category_dict_.end()) << line;
      if (it->second.second.empty()) CHECK_EQ(ngram_type, 1);
      if (ngram_type == 2) {
        auto it2 = it->second.second.find(categories[1]);
        if (it2 == it->second.second.end()) {
          VLOG(1) << base::StringPrintf("FATAL: miss category: %s for level1: %s", categories[1].c_str(), categories[0].c_str()); // NOLINT
          it->second.second.insert(std::make_pair(categories[1], 1));
        }
        // CHECK(it2 != it->second.second.end()) << line;
      }
    }

    if (ngram_type == 1) {
      source_to_default_category_[flds[0]] = std::make_pair(flds[2], "");
    } else {
      source_to_default_category_[flds[0]] = std::make_pair(categories[1], categories[0]);
    }
  }
  LOG(INFO) << "defualt source category num " << source_to_default_category_.size();
  return true;
}

bool SourceCategoryDict::LoadAllSeed() {
  // load all seed
  std::string sql = "select id,name,item_type from tb_seed;";
  uint64 seed_id = 0;
  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, kRetryTimes));
  if (res.get() == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }

  while (res->next()) {
    std::string seed_id_str = res->getString("id");
    std::string seed_name = res->getString("name");
    int item_type = res->getInt("item_type");
    nlp::util::NormalizeLineInPlaceS(&seed_name);
    if (!base::StringToUint64(seed_id_str, &seed_id)) {
      LOG(ERROR) << "error seed id: " << seed_id;
      continue;
    }
    auto it_pair = seed_dict_.insert(std::make_pair(seed_id, sources_.size()));
    if (!it_pair.second) {
      LOG(ERROR) << "dedup seed id: "<< seed_id;
      continue;
    }
    sources_.push_back(std::make_pair(seed_name, item_type));
    uint64 sign = base::CalcTermSign(seed_name.c_str(), seed_name.size());
    auto it_pair2 = source_dict_.insert(std::make_pair(sign, it_pair.first->second));
    if (!it_pair2.second) {
      LOG(ERROR) << "dedup source name: "<< seed_name;
      continue;
    }
  }
  // init matrix
  category_matrix_.resize(sources_.size());
  for (size_t i = 0; i < sources_.size(); ++i) {
    category_matrix_[i] = new std::map<std::string, std::pair<int, std::map<std::string, int>* >>();
  }
  return true;
}

bool SourceCategoryDict::LoadVideoCategoryDict(std::unordered_map<std::string, std::pair<int, std::map<std::string, int> >>*category_dict, // NOLINT
                                               std::unordered_map<uint64, std::pair<std::string, std::string >>* id_to_category) { // NOLINT
  CHECK_NOTNULL(category_dict);
  std::string sql = "select id,word from tb_video_category_word;";
  std::vector<std::string> tokens;
  uint64 id = 0;
  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, kRetryTimes));
  if (res.get() == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }

  while (res->next()) {
    std::string category = res->getString("word");
    std::string id_str = res->getString("id");
    if (category.empty()) {
      LOG(ERROR) << "empty category: ";
      continue;
    }
    if (!base::StringToUint64(id_str, &id)) {
      LOG(ERROR) << "erro id: " << id_str;
      continue;
    }

    tokens.clear();
    base::SplitString(category, "\t", &tokens);
    if (tokens.size() > 2) {
      LOG(ERROR) << "erro category: " << category;
      continue;
    }

    // insert level1
    category_dict->insert(std::make_pair(tokens[0], std::make_pair(1, std::map<std::string, int>()))); // NOLINT
    if (tokens.size() == 1u) {
      CHECK(id_to_category->insert(std::make_pair(id, std::make_pair(tokens[0], ""))).second);
    }
  }
  return true;
}

bool SourceCategoryDict::LoadCategoryDict(std::unordered_map<std::string, std::pair<int, std::map<std::string, int> >>*category_dict, // NOLINT
                                          std::unordered_map<uint64, std::pair<std::string, std::string >>* id_to_category) { // NOLINT
  CHECK_NOTNULL(category_dict);
  // load all category
  std::string sql = "select id,word,can_auto from tb_seed_category_word;";
  std::vector<std::string> tokens;
  uint64 id = 0;
  int can_auto = 0;
  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, kRetryTimes));
  if (res.get() == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }

  while (res->next()) {
    std::string category = res->getString("word");
    std::string id_str = res->getString("id");
    std::string can_auto_str = res->getString("can_auto");
    if (category.empty()) {
      LOG(ERROR) << "empty category: ";
      continue;
    }
    if (!base::StringToUint64(id_str, &id)) {
      LOG(ERROR) << "erro id: " << id_str;
      continue;
    }

    if (!base::StringToInt(can_auto_str, &can_auto)) {
      LOG(ERROR) << "erro id: " << id_str;
      continue;
    }
    tokens.clear();
    base::SplitString(category, "\t", &tokens);
    if (tokens.size() > 2) {
      LOG(ERROR) << "erro category: " << category;
      continue;
    }

    int level1_type = 0;
    if (tokens.size() == 1u) {
      CHECK(id_to_category->insert(std::make_pair(id, std::make_pair(tokens[0], ""))).second);
      if (can_auto > 0) level1_type = 1;
    }
    int level2_type = 0;
    if (tokens.size() == 2u) {
      CHECK(id_to_category->insert(std::make_pair(id, std::make_pair(tokens[0], tokens[1]))).second);
      if (can_auto > 0) level2_type = 1;
    }

    // insert level1
    auto it_pair = category_dict->insert(std::make_pair(tokens[0], std::make_pair(level1_type, std::map<std::string, int>()))); // NOLINT
    if (!it_pair.second && level1_type > it_pair.first->second.first) {
      it_pair.first->second.first = level1_type;
    }
    // insert level2 if exist
    if (tokens.size() == 1) continue;
    auto it_pair2 = it_pair.first->second.second.insert(std::make_pair(tokens[1], level2_type));
    CHECK(it_pair2.second);
  }
  // check valid
  bool is_valid = true;
  // for (auto it = category_dict->begin(); it != category_dict->end(); ++it) {
  //   // 如果一个一级下面多个二级，要么都是 auto，要么都不是 auto
  //   if (it->second.second.size() == 0) continue;
  //   auto it2 = it->second.second.begin();
  //   int last_type = it2->second;
  //   ++it2;
  //   for (;it2 != it->second.second.end(); ++it2) {
  //     if (last_type != it2->second) {
  //       LOG(ERROR) << base::StringPrintf("level1 %s has conflict level2", it->first.c_str());
  //       is_valid = false;
  //       break;
  //     }
  //   }
  // }
  return is_valid;
}

bool SourceCategoryDict::LoadVideoDictFromDb() {
  std::unordered_map<uint64, std::pair<std::string, std::string>> id_to_category;
  CHECK(LoadVideoCategoryDict(&category_dict_, &id_to_category));

  // load source category dict
  std::string sql = "select t1.seed_id, t1.category_word_id, t2.word from tb_seed_video_category as t1, tb_video_category_word as t2 where t1.category_word_id=t2.id;"; // NOLINT
  uint64 seed_id = 0;
  uint64 category_id = 0;

  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, kRetryTimes));
  if (res.get() == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }
  while (res->next()) {
    std::string seed_id_str = res->getString("seed_id");
    std::string category_id_str = res->getString("category_word_id");
    std::string word = res->getString("word");

    if (!base::StringToUint64(seed_id_str, &seed_id)) {
      LOG(ERROR) << "error seed id: " << seed_id;
      continue;
    }
    if (!base::StringToUint64(category_id_str, &category_id)) {
      LOG(ERROR) << "error category id: " << category_id;
      continue;
    }
    auto it_seed = seed_dict_.find(seed_id);
    if (it_seed == seed_dict_.end()) {
      VLOG(1) << base::StringPrintf("cannot find seed id in seed table %lu", seed_id);
      continue;
    }

    int idx = it_seed->second;
    CHECK_GT((int)category_matrix_.size(), idx);

    auto it_category = id_to_category.find(category_id);
    if (it_category == id_to_category.end()) {
      LOG(ERROR) << base::StringPrintf("cannot find category id in category table %lu for source: %s",
                                       category_id,
                                       sources_[idx].first.c_str());
      continue;
    } else if (word != it_category->second.first) {
      LOG(ERROR) << " fuck neq category: " << word << " and " << it_category->second.first;
    }

    int level1_type = kStrict;
    std::map<std::string, int>* dummy = new std::map<std::string, int>();
    dummy->insert(std::make_pair(kDummy, 0));
    auto it_pair2 = category_matrix_[idx]->insert(std::make_pair(word,
                                                                 std::make_pair(level1_type, dummy)));
  }
  return true;
}

bool SourceCategoryDict::LoadDictFromDb() {
  std::unordered_map<uint64, std::pair<std::string, std::string>> id_to_category;
  CHECK(LoadCategoryDict(&category_dict_, &id_to_category));

  // load source category dict
  std::string sql = "select t1.seed_id, t1.category_word_id, t1.is_force, t2.word from tb_seed_category as t1, tb_seed_category_word as t2 where t1.category_word_id=t2.id;"; // NOLINT
  uint64 seed_id = 0;
  uint64 category_id = 0;
  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, kRetryTimes));
  if (res.get() == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }
  while (res->next()) {
    std::string seed_id_str = res->getString("seed_id");
    std::string category_id_str = res->getString("category_word_id");
    std::string word = res->getString("word");
    bool is_force = base::ParseIntOrDie(res->getString("is_force")) > 0;

    if (!base::StringToUint64(seed_id_str, &seed_id)) {
      LOG(ERROR) << "error seed id: " << seed_id;
      continue;
    }
    if (!base::StringToUint64(category_id_str, &category_id)) {
      LOG(ERROR) << "error category id: " << category_id;
      continue;
    }
    auto it_seed = seed_dict_.find(seed_id);
    if (it_seed == seed_dict_.end()) {
      VLOG(1) << base::StringPrintf("cannot find seed id in seed table %lu", seed_id);
      continue;
    }
    int idx = it_seed->second;

    CHECK_GT((int)category_matrix_.size(), idx);
    auto it_category = id_to_category.find(category_id);
    if (it_category == id_to_category.end()) {
      LOG(ERROR) << base::StringPrintf("cannot find category id in category table %lu for source: %s",
                                       category_id,
                                       sources_[idx].first.c_str());
      continue;
    }

    int level1_type = kNormal;
    if (is_force) {
      if (open_categories_.find(it_category->second.first) != open_categories_.end()) {
        level1_type = kOpen;
      } else {
        level1_type = kStrict;
      }
    }
    if (it_category->second.first == "旅游") {
      level1_type = kNormal;
    }

    auto it_pair2 = category_matrix_[idx]->insert(std::make_pair(it_category->second.first,
                                                                 std::make_pair(level1_type, new std::map<std::string, int>()))); // NOLINT
    if (!it_pair2.second && level1_type == kStrict) {
      it_pair2.first->second.first = level1_type;
    }

    std::map<std::string, int>* level2_candidates = it_pair2.first->second.second;
    if (it_category->second.second.size() > 1) {
      if (level2_candidates == NULL) {
        level2_candidates = new std::map<std::string, int>();
        it_pair2.first->second.second = level2_candidates;
      }
      int level2_type = kNormal;
      if (is_force) {
        if (open_categories_.find(word) != open_categories_.end()) {
          level2_type = kOpen;
        } else {
          level2_type = kStrict;
        }
      }
      auto it_pair = level2_candidates->insert(std::make_pair(it_category->second.second, level2_type));
      CHECK(it_pair.second) << base::StringPrintf("source:%s,add %s failed", sources_[idx].first.c_str(),
                                                  it_category->second.second.c_str());
    }
  }
  LOG(INFO) << "finish reload source dict";
  CHECK(SupplementCategory());
  return true;
}

bool SourceCategoryDict::SupplementCategory() {
  std::unordered_map<std::string, std::set<std::string>> category_supplement_dict;
  std::ifstream fin(data_dir_.Append(kCategorySupplementFile).value());
  std::string line;
  std::vector<std::string> tokens;
  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 2) {
      LOG(ERROR) << "erro category record: " << line;
      continue;
    }
    CHECK_GT(tokens.size(), 1u) << line;
    CHECK_GT(32u, tokens.size());
    nlp::util::NormalizeLineInPlaceS(&tokens[0]);
    auto it_pair = category_supplement_dict.insert(std::make_pair(tokens[0], std::set<std::string>()));
    if (!it_pair.second) {
      LOG(ERROR) << "write them in one single line!" << tokens[0];
    }
    for (size_t i = 1; i < tokens.size(); ++i) {
      nlp::util::NormalizeLineInPlaceS(&tokens[i]);
      it_pair.first->second.insert(tokens[i]);
    }
  }
  // check each source for its level1
  std::set<std::string> adds;
  for (size_t i = 0; i < category_matrix_.size(); ++i) {
    std::map<std::string, std::pair<int, std::map<std::string, int>* >>* level1_dict = category_matrix_[i];
    if (level1_dict->size() == 1u && level1_dict->begin()->second.first != kNormal) continue;
    adds.clear();
    for (auto it = level1_dict->begin(); it != level1_dict->end(); ++it) {
      auto it2 = category_supplement_dict.find(it->first);
      if (it2 == category_supplement_dict.end()) continue;

      const std::set<std::string>& category_set = it2->second;
      for (auto it3 = category_set.begin(); it3 != category_set.end(); ++it3) {
        if (level1_dict->find(*it3) == level1_dict->end()) adds.insert(*it3);
      }
    }
    for (auto it = adds.begin(); it != adds.end(); ++it) {
      level1_dict->insert(std::make_pair(*it, std::make_pair(0, reinterpret_cast<std::map<std::string, int>*>(NULL)))); // NOLINT
    }
  }
  return true;
}
}
}
