#pragma once
#include "base/file/file_path.h"
#include "base/common/basic_types.h"
#include "reco/module/item_classify_server/global_data/define.h"

namespace reco {
namespace item_classify {
void RuleDictLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void RawRuleDictLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void PostRuleListLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void CatePairLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void SourceCategoryLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void LRModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void WordTagLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void XGboostModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void XGboostMultiModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void FastTextModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void SourceHistoryStatLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void HighlevelModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);
void HashFileModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);
// NOTE: word tag dict 需要打包成一个
void LoadWordTagDict(const base::FilePath& word_tag_file, const base::FilePath& word_tag_list_file,
                     WordTagDict* word_tag_dict);
// NOTE: 该文件尽快去除
void LoadCategoryMap(const base::FilePath& all_cate_file, CategoryMap* category_map);

// for test usage
void LoadLRModel(const base::FilePath& model_path, LRModel* model);
}
}
