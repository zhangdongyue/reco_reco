#include "reco/module/item_classify_server/global_data/dict_loader.h"

#include <boost/shared_ptr.hpp>
#include <fstream>
#include <iostream>
#include <utility>
#include <unordered_set>
#include <algorithm>
#include <string>
#include <map>
#include <vector>
#include "extend/static_dict/dawg/dictionary-builder.h"
#include "extend/static_dict/dawg/dawg-builder.h"

#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/basic_types.h"
#include "base/strings/string_split.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "extend/static_dict/dawg/dictionary.h"
#include "nlp/common/nlp_util.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "nlp/segment/segmenter.h"
#include "reco/base/dict_manager/dynamic_dict.h"
#include "reco/module/item_classify_server/global_data/define.h"
#include "reco/module/item_classify_server/global_data/xgboost_util.h"
#include "reco/module/item_classify_server/common/SimHashIndex.h"
#include "reco/module/item_classify_server/common/StringUtil.h"

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

namespace reco {
namespace item_classify {
void LoadWordTagDict(const base::FilePath& word_tag_file, const base::FilePath& word_tag_list_file,
                     WordTagDict* word_tag_dict) {
  // word2tag
  std::ifstream fin(word_tag_file.value());
  CHECK(word_tag_dict->dict.Read(&fin));
  LOG(INFO) << "finish loading dict size=" << word_tag_dict->dict.size();

  CHECK(base::file_util::ReadFileToLines(word_tag_list_file, &(word_tag_dict->tags)));
  LOG(INFO) << "finish loading word_tags_list_  size=" << word_tag_dict->tags.size();
}

void LoadCategoryMap(const base::FilePath& all_cate_file, CategoryMap* category_map) {
  std::vector<std::pair<std::string, int> >& all_category = category_map->all_category;
  // the first one must be zero, with nothing
  all_category.push_back(std::make_pair("", 0));
  std::unordered_map<std::string, int>& category_dict = category_map->category_dict;
  LOG(INFO) << "begin read category idx file";
  // std::ifstream fin(data_dir.Append(kCategoryIdxFile).value());
  std::ifstream fin(all_cate_file.value());
  CHECK(fin.good()) << all_cate_file.value();
  std::string line;
  std::vector<std::string> tokens;
  while (std::getline(fin, line)) {
    if (line.size() < 2) {
      LOG(ERROR) << "erro category line:" << line;
      continue;
    }
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    CHECK_EQ(tokens.size(), 2u);

    nlp::util::NormalizeLineInPlaceS(&tokens[0]);
    const std::string& category = tokens[0];
    auto it = category_dict.find(category);
    if (it != category_dict.end()) {
      LOG(ERROR) << "dump category: " << category << " in line: " << line;
      continue;
    }

    int idx = all_category.size();
    category_dict[category] = idx;

    int v = base::ParseIntOrDie(tokens[1]) << 16 | idx;
    all_category.push_back(std::make_pair(category, v));
  }
  LOG(INFO) << "finish loading category idx file";
}

void LoadLRModel(const base::FilePath& model_path, LRModel* model) {
  std::ifstream fin(model_path.value(), std::ifstream::binary);
  fin.clear();
  CHECK(fin.good());
  // part3 : all category
  CHECK(fin.good());
  uint32 buf_size = 0;
  fin.read(reinterpret_cast<char*>(&buf_size), sizeof(buf_size));
  LOG(INFO) << "category buf size: " << buf_size;
  CHECK_GT(16u * 65536, buf_size);
  char* buf = new char[buf_size + 1];
  fin.read(buf, buf_size);
  buf[buf_size] = '\0';
  LOG(INFO) << "all category: " << buf;
  base::SplitString(std::string(buf, buf_size), "\t", &model->all_category);
  LOG(INFO) << "category num: " << model->all_category.size();
  // part 1: dict
  model->dict.Read(&fin);
  LOG(INFO) << "fea_dict: " << model->dict.size();
  LOG(INFO) << "fin offset: " << fin.tellg();

  CHECK(fin.good());
  LOG(INFO) << "begin read ngram weights";

  // part 2: weight
  uint32 offset_num = 0;
  fin.read(reinterpret_cast<char*>(&offset_num), sizeof(offset_num));
  CHECK_GT(offset_num, 1u);
  model->fea_num = offset_num - 1;
  LOG(INFO) << "fea num: " << model->fea_num;

  uint32* offset = new uint32[offset_num];
  fin.read(reinterpret_cast<char*>(offset), sizeof(offset[0]) * offset_num);
  model->offset = offset;

  float* weights = new float[offset[offset_num - 1]];
  uint64 weight_size = offset[offset_num - 1] * sizeof(weights[0]);
  fin.read(reinterpret_cast<char*>(weights), weight_size);
  model->weights = weights;
  LOG(INFO) << "weight num " << offset[offset_num - 1];
  LOG(INFO) << "fin offset: " << fin.tellg();
  LOG(INFO) << "weight_size: " << weight_size;
  offset = NULL;
  weights = NULL;

  fin.close();
}

void LRModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  LRModel* model = new LRModel();
  LoadLRModel(file_path, model);

  boost::shared_ptr <LRModel> ptr(model);
  reco::dm::DynamicDict<LRModel>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<LRModel>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
}

static void LoadWordtagDict(const base::FilePath& dict_path, WordTagDict* word_tag_dict) {
  std::ifstream fin(dict_path.value(), std::ifstream::binary);
  CHECK(fin.good());

  // part 1: dict
  word_tag_dict->dict.Read(&fin);
  LOG(INFO) << "fea_dict: " << word_tag_dict->dict.size();

  CHECK(fin.good());
  // part3 : all types
  CHECK(fin.good());
  uint32 buf_size = 0;
  fin.read(reinterpret_cast<char*>(&buf_size), sizeof(buf_size));
  char* buf = new char[buf_size + 1];
  fin.read(buf, buf_size);
  buf[buf_size] = '\0';
  base::SplitString(std::string(buf, buf_size), "\t", &word_tag_dict->tags);
  LOG(INFO) << "tag names num: " << word_tag_dict->tags.size();
  fin.close();
}

static void LoadSourceHistoryStatList(base::FilePath file_path,
                                      std::unordered_map<std::string, std::unordered_map<std::string, double> >* source_history_stat) {  // NOLINT
  std::ifstream fin(file_path.value());

  std::vector<std::string> tokens;
  std::string line;

  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    const std::string& source = tokens[0];
    std::unordered_map<std::string, double> data;
    StringUtil::String2Map(tokens[1], &data);
    source_history_stat->insert(std::make_pair(source, data));
  }
}

void SourceHistoryStatLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;
  std::unordered_map<std::string, std::unordered_map<std::string, double> >* source_history_stat
          = new std::unordered_map<std::string, std::unordered_map<std::string, double> >();
  LoadSourceHistoryStatList(file_path, source_history_stat);

  boost::shared_ptr <std::unordered_map<std::string, std::unordered_map<std::string, double> >> ptr(
          source_history_stat); // NOLINT
  reco::dm::DynamicDict<std::unordered_map<std::string, std::unordered_map<std::string, double>>>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<std::unordered_map<std::string, std::unordered_map<std::string, double>>>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
  *cnt = source_history_stat->size();
  *succ = true;
}

void WordTagLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  WordTagDict* word_tag_dict = new WordTagDict();
  LoadWordtagDict(file_path, word_tag_dict);

  boost::shared_ptr <WordTagDict> ptr(word_tag_dict);
  reco::dm::DynamicDict<WordTagDict>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<WordTagDict>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
}

static void LoadXGboostModel(const base::FilePath& dict_path, XGboostModel* p_model) {
  // 载入模型
  LOG(INFO) << "start load xgboost model..";
  // 创建 Stream 对象，GBTree 对象
  Stream* p_fin = Stream::Create(dict_path.value().c_str(), "r");
  // Load 模型头部声明
  std::string header;
  header.resize(4);
  CHECK_EQ(p_fin->Read(&header[0], 4), 4u);
  // Load 模型参数
  p_fin->Read(&p_model->model_param, sizeof(XParam));
  // 构建归一化对象
  std::string obj_name;
  p_fin->Read(&obj_name);
  p_model->p_obj = CreateObjFunction(obj_name.c_str());
  std::string tmp = base::IntToString(p_model->model_param.num_class);
  p_model->p_obj->SetParam("num_class", tmp.c_str());
  // 构建 gbm 对象，Load 模型
  std::string gbm_name;
  p_fin->Read(&gbm_name);
  p_model->p_gbm = new GBTree();
  p_model->p_gbm->LoadCateMap(p_fin);
  p_model->p_gbm->LoadModel(p_fin, false);
  LOG(INFO) << "finish load xgboost model.";
}

static void LoadXGboostMultiModel(const base::FilePath& dict_path, std::vector<XGboostModel*>* models) {
  // 载入模型
  LOG(INFO) << "start load xgboost multi model..";
  // 创建 Stream 对象，GBTree 对象
  Stream* p_fin = Stream::Create(dict_path.value().c_str(), "r");
  size_t model_num;
  p_fin->Read(&model_num, sizeof(size_t));
  std::vector<std::string> tokens;
  for (size_t i = 0; i < model_num; ++i) {
    auto p_model = new XGboostModel();
    // cate list
    std::string cate_list;
    p_fin->Read(&cate_list);
    LOG(INFO) << cate_list;
    tokens.clear();
    base::SplitString(cate_list, "|", &tokens);
    p_model->cates_list.clear();

    for (size_t j = 0; j < tokens.size(); ++j) {
      p_model->cates_list.push_back(tokens[j]);
    }
    // Load 模型头部声明
    std::string header;
    header.resize(4);
    CHECK_EQ(p_fin->Read(&header[0], 4), 4u);
    // Load 模型参数
    p_fin->Read(&p_model->model_param, sizeof(XParam));
    // 构建归一化对象
    std::string obj_name;
    p_fin->Read(&obj_name);
    p_model->p_obj = CreateObjFunction(obj_name.c_str());
    std::string tmp = base::IntToString(p_model->model_param.num_class);
    p_model->p_obj->SetParam("num_class", tmp.c_str());
    // 构建 gbm 对象，Load 模型
    std::string gbm_name;
    p_fin->Read(&gbm_name);
    p_model->p_gbm = new GBTree();
    p_model->p_gbm->LoadModel(p_fin, false);
    models->push_back(p_model);
  }
  LOG(INFO) << "finish load xgboost model.";
}

void XGboostModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  XGboostModel* model = new XGboostModel();
  LoadXGboostModel(file_path, model);

  boost::shared_ptr <XGboostModel> ptr(model);
  reco::dm::DynamicDict<XGboostModel>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<XGboostModel>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
}

void XGboostMultiModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  std::vector<XGboostModel*>* model = new std::vector<XGboostModel*>();
  LoadXGboostMultiModel(file_path, model);

  boost::shared_ptr <std::vector<XGboostModel*>> ptr(model);
  reco::dm::DynamicDict<std::vector<XGboostModel*>>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<std::vector<XGboostModel*>>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
}

void FastTextModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  fasttext::FastTextModel::FastTextModel* model = new fasttext::FastTextModel::FastTextModel();
  fasttext::LoadModelWrapper(file_path.value(), model);

  boost::shared_ptr <fasttext::FastTextModel::FastTextModel> ptr(model);
  reco::dm::DynamicDict<fasttext::FastTextModel::FastTextModel>* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<fasttext::FastTextModel::FastTextModel>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *succ = true;
}

static void LoadHighLevelModel(const base::FilePath& path,
                               std::unordered_map<std::string, std::vector<std::pair<std::string, double> > >* model) {  // NOLINT
  std::ifstream fin(path.value());

  std::string line;
  std::vector<std::string> tokens;
  std::vector<std::string> methods;
  std::vector<std::string> cates;

  int line_idx = 0;
  const std::vector<std::pair<std::string, double>> empty_vector;
  while (std::getline(fin, line)) {
    if (line_idx == 0) {
      base::SplitString(line, "\t", &methods);
      for (size_t i = 0; i < methods.size(); ++i) {
        model->insert(std::make_pair(methods[i], empty_vector));
      }
    } else if (line_idx == 1) {
      base::SplitString(line, "\t", &cates);
    } else {
      tokens.clear();
      base::SplitString(line, "\t", &tokens);
      const std::string& cate_name = cates[line_idx - 2];
      CHECK_GE(methods.size(), tokens.size());
      for (size_t i = 0; i < tokens.size(); ++i) {
        const std::string& method_name = methods[i];
        auto it = model->find(method_name);
        CHECK(it != model->end());
        double score;
        CHECK(base::StringToDouble(tokens[i], &score));
        it->second.push_back(std::make_pair(cate_name, score));
      }
    }
    line_idx++;
  }
}

void HighlevelModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;
  typedef std::unordered_map<std::string, std::vector<std::pair<std::string, double> > > MapStrVectorStrDouble;  // NOLINT
  MapStrVectorStrDouble* model
          = new MapStrVectorStrDouble();
  LoadHighLevelModel(file_path, model);
  boost::shared_ptr <MapStrVectorStrDouble> ptr(model);
  reco::dm::DynamicDict<MapStrVectorStrDouble>* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<MapStrVectorStrDouble>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *succ = true;
  *cnt = model->size();
}

static void LoadRuleList(const base::FilePath& path, RuleDict* rule_dict) {
  std::ifstream fin(path.value());

  std::vector<std::string> words;
  std::string line;
  std::vector<std::string> tokens;
  std::map<std::string, int> full_word_rules;
  dawgdic::DawgBuilder builder;
  std::unordered_map<std::string, int> cate_id_map;
  std::unordered_map<std::string, int> rule_idx_map;
  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (line.size() < 5) continue;
    CHECK_EQ(tokens.size(), 3u) << line;

    int rule_type = base::ParseIntOrDie(tokens[2]);
    CHECK_GT(3, rule_type);
    CHECK_GT(rule_type, 0);

    // find category index
    nlp::util::NormalizeLineInPlaceS(&tokens[1]);
    std::string& category = tokens[1];
    size_t pos = category.find('|');
    if (pos != std::string::npos) {
      category[pos] = ',';
    }

    words.clear();
    nlp::util::NormalizeLineInPlaceS(&tokens[0]);
    auto it = rule_idx_map.find(tokens[0]);
    if (it == rule_idx_map.end()) {
      base::SplitString(tokens[0], "|", &words);

      rule_dict->rule_list.push_back(ClassifierRule());
      rule_dict->rule_list.back().cates = {category};
      rule_dict->rule_list.back().rule_types = {rule_type};
      rule_dict->rule_list.back().ngram_length = words.size();
      rule_dict->rule_list.back().rule_define = tokens[0];
      const int rule_idx = (int) rule_dict->rule_list.size() - 1;
      rule_idx_map.insert(std::make_pair(tokens[0], rule_idx));
      if (words.size() == 1u && tokens[0].find("source_") != 0) {
        // 全文匹配
        auto it = full_word_rules.find(tokens[0]);
        if (it != full_word_rules.end()) {
          rule_dict->rule_list[it->second].cates.push_back(category);
        }
        full_word_rules.insert(std::make_pair(tokens[0], rule_idx));
        continue;
      }

      for (int i = 0; i < (int) words.size(); ++i) {
        const std::string& word = words[i];
        auto it = rule_dict->rule_index.find(word);
        if (it != rule_dict->rule_index.end()) {
          it->second.push_back(rule_idx);
        } else {
          std::vector<int> v = {rule_idx};
          rule_dict->rule_index.insert(std::make_pair(word, v));
        }
      }
    } else {
      rule_dict->rule_list[it->second].cates.push_back(category);
      rule_dict->rule_list[it->second].rule_types.push_back(rule_type);
    }
  }

  for (auto it = full_word_rules.begin(); it != full_word_rules.end(); it++) {
    builder.Insert(it->first.c_str(), it->second);
  }
  dawgdic::Dawg dawg;
  CHECK(builder.Finish(&dawg));
  dawgdic::DictionaryBuilder::Build(dawg, &(rule_dict->fullword_rule_dict));
  LOG(INFO) << "fullword_rule_dict=" << rule_dict->fullword_rule_dict.size();
}

void RuleDictLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  RuleDict* rule_dict = new RuleDict();
  LoadRuleList(file_path, rule_dict);

  boost::shared_ptr <RuleDict> ptr(rule_dict);
  reco::dm::DynamicDict<RuleDict>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<RuleDict>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
  *cnt = rule_dict->rule_list.size();
}

static void LoadPostRuleList(const base::FilePath& path,
                             std::unordered_map<std::string, std::vector<int> >* included_index,
                             std::unordered_map<std::string, std::vector<int> >* excluded_index,
                             std::vector<PostRule>* post_rule_list) {
  std::ifstream fin(path.value());
  std::vector<std::string> words;
  std::vector<std::string> tokens;
  std::string line;

  while (std::getline(fin, line)) {
    tokens.clear();
    words.clear();

    base::SplitString(line, "\t", &tokens);

    if (tokens.size() != 5) {
      LOG(ERROR) << "error load pos rule: " << line
                 << " elements.size()=" << tokens.size() << " which should be 5";
      continue;
    }

    int tmp_size = post_rule_list->size();
    PostRule post_rule;

    post_rule.included_length = 0;
    post_rule.model_class = tokens[0];
    post_rule.manual_class = tokens[1];
    base::SplitString(tokens[2], "|", &words);
    base::StringToDouble(tokens[3], &(post_rule.priority));
    base::StringToInt(tokens[4], &(post_rule.rule_type));

    if (post_rule.rule_type == 2 && post_rule.manual_class.find(",") == std::string::npos) {
      LOG(ERROR) << "error pos rule: " << line;
      continue;
    }

    for (int i = 0; i < (int) words.size(); ++i) {
      if (words[i][0] == '!') {
        std::string tmp_word = words[i].substr(1);
        if (excluded_index->find(tmp_word) != excluded_index->end()) {
          excluded_index->find(tmp_word)->second.push_back(tmp_size);
        } else {
          std::vector<int> v = {tmp_size};
          excluded_index->insert(std::make_pair(tmp_word, v));
        }
      } else {
        post_rule.included_length++;
        if (included_index->find(words[i]) != included_index->end()) {
          included_index->find(words[i])->second.push_back(tmp_size);
        } else {
          std::vector<int> v = {tmp_size};
          included_index->insert(std::make_pair(words[i], v));
        }
      }
    }
    post_rule_list->push_back(post_rule);
  }
}

void PostRuleListLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  PostDict* post_dict = new PostDict();
  LoadPostRuleList(file_path, &(post_dict->included_index), &(post_dict->excluded_index),
                   &(post_dict->post_rule_list));  // NOLINT

  boost::shared_ptr <PostDict> ptr(post_dict);
  reco::dm::DynamicDict<PostDict>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<PostDict>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
  *cnt = post_dict->post_rule_list.size();
}

static void LoadCatePair(const base::FilePath& path,
                         std::unordered_map<std::string, std::set<std::string> >* dict) {
  std::ifstream input(path.value());
  CHECK(input.good());

  std::vector<std::string> tokens;
  std::string line;
  while (std::getline(input, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    CHECK_GT((int) tokens.size(), 1);
    nlp::util::NormalizeLineInPlaceS(&tokens[0]);
    auto it_pair = dict->insert(std::make_pair(tokens[0], std::set<std::string>()));
    if (!it_pair.second) {
      LOG(ERROR) << "dedup " << line;
      continue;
    }
    std::set<std::string>& pairs = it_pair.first->second;
    for (int i = 1; i < (int) tokens.size(); ++i) {
      pairs.insert(tokens[i]);
    }
  }
}

void CatePairLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  std::unordered_map<std::string, std::set<std::string> >* cate_pair_dict =
          new std::unordered_map<std::string, std::set<std::string> >();
  LoadCatePair(file_path, cate_pair_dict);

  boost::shared_ptr <std::unordered_map<std::string, std::set<std::string> >> ptr(cate_pair_dict);
  reco::dm::DynamicDict<std::unordered_map<std::string, std::set<std::string> > >* dynamic_dict =
          reinterpret_cast<reco::dm::DynamicDict<std::unordered_map<std::string, std::set<std::string> > >* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
  *cnt = cate_pair_dict->size();
}

void LoadRawRule(const base::FilePath& file_path, RawRuleDict* rule_dict) {
  std::ifstream fin(file_path.value());
  CHECK(fin.good());
  uint32 buf_size = 0;
  fin.read(reinterpret_cast<char*>(&buf_size), sizeof(buf_size));
  LOG(INFO) << "category buf size: " << buf_size;
  CHECK_GT(4098u, buf_size);
  char* buf = new char[buf_size + 1];
  fin.read(buf, buf_size);
  buf[buf_size] = '\0';
  LOG(INFO) << "raw dict category: " << buf;
  base::SplitString(std::string(buf, buf_size), "\t", &rule_dict->categories);
  LOG(INFO) << "raw category num: " << rule_dict->categories.size();
  // part 2: dict
  rule_dict->dict.Read(&fin);
  LOG(INFO) << "raw rule dict size: " << rule_dict->dict.size();
  LOG(INFO) << "raw rule fin offset: " << fin.tellg();

  CHECK(fin.good());
}

void RawRuleDictLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  RawRuleDict* rule_dict = new RawRuleDict();
  LoadRawRule(file_path, rule_dict);

  boost::shared_ptr <RawRuleDict> ptr(rule_dict);
  reco::dm::DynamicDict<RawRuleDict>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<RawRuleDict>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
  *cnt = rule_dict->dict.size();
}

void HashFileModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  simhash_index* hash_list = new simhash_index();
  SimHashIndex::Load(file_path.value(), 7, hash_list);
  LOG(INFO) << "finish building";
  boost::shared_ptr <simhash_index> ptr(hash_list);
  reco::dm::DynamicDict<simhash_index>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<simhash_index>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
  *cnt = hash_list->size();
}
}
}
