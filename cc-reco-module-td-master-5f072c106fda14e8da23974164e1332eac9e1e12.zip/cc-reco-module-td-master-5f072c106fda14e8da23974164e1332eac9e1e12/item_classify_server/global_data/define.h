#pragma once
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

#include "base/common/basic_types.h"
#include "extend/static_dict/dawg/dictionary.h"
#include "reco/module/item_classify_server/global_data/xgboost_util.h"
#include "reco/module/item_classify_server/fasttext/fasttextmodel.h"

namespace reco {
namespace item_classify {

struct WordTagDict {
  dawgdic::Dictionary dict;
  std::vector<std::string> tags;
};

struct CategoryMap {
  std::vector<std::pair<std::string, int> > all_category;
  std::unordered_map<std::string, int> category_dict;
};

struct ClassifierRule {
  std::vector<std::string> cates;
  std::vector<int> rule_types; // 和 cates一一对应
  int ngram_length;
  std::string rule_define;
};

struct RuleDict {
  std::unordered_map<std::string, std::vector<int> > rule_index;
  std::vector<ClassifierRule> rule_list;
  dawgdic::Dictionary fullword_rule_dict;
};

struct RawRuleDict {
  std::vector<std::string> categories;
  dawgdic::Dictionary dict;
};

struct LRModel {
  dawgdic::Dictionary dict;
  uint32 fea_num;

  const uint32* offset;
  const float* weights;

  std::vector<std::string> all_category;
};

struct XGboostModel {
  std::vector<std::string> cates_list;
  XParam model_param;  // 模型相关参数
  GBTree* p_gbm;  // GBM
  IObjFunction* p_obj;  // 归一化
};

struct PostRule {
  std::string model_class;
  std::string manual_class;
  int included_length;  // 必须包含的 flag 个数
  double priority;
  int rule_type;
};

struct PostDict {
  std::vector<PostRule> post_rule_list;
  std::unordered_map <std::string, std::vector<int> > included_index;
  std::unordered_map <std::string, std::vector<int> > excluded_index;
};

// input for item basic fea extractor
struct RawItem {
  uint64 item_id;
  std::string title;    // 标题
  std::string source;   // 种子源
  std::string media;   // 媒体
  std::string content;   // 正文内容
  std::string category;
  int item_type;
  bool is_debug;
  int debug_level;

  std::vector<std::pair<std::string, double> > keywords;   // 关键词
  std::vector<std::pair<std::string, double> > topics;
  std::vector<std::pair<std::string, double> > title_lda_topics;

  std::vector<std::string> tags;   // 标签
  std::vector<int64> para_simhash; // 段落 simhash
  std::vector<int64> picture_simhash; // 图片 simhash
  std::string region;

  void clear() {
    keywords.clear();
    tags.clear();
    topics.clear();
    title_lda_topics.clear();
    para_simhash.clear();
    picture_simhash.clear();
    item_id = 0;
    title = "";
    source = "";
    media = "";
    content = "";
    category = "";
    item_type = -1;
    is_debug = false;
    region = "";
  }
};

enum ClassifyMethod {
  kLR = 0,
  kMediaDefault = 1,
  kSourceDefault = 2,
  kVideoLR = 3,
  kGBDT = 4,
  kRule = 5,
  kAggregate = 6,
  kFastText = 7,
  kLinear = 8,
  kRawRule = 9,
  kWideDeep = 10,
  kSimiResult = 11,
};

struct ItemClassifyResult {
  std::vector<std::pair<double, std::string>> best_result;
  std::vector<std::pair<double, std::string>> multi_result;
  std::vector<std::pair<double, std::string>> tag_result;
  std::vector<std::pair<double, std::string>> post_tag_result;
  void clear() {
      best_result.clear();
      multi_result.clear();
      tag_result.clear();
      post_tag_result.clear();
  }
};
struct ClassifyResult {
 public:
  int cate_id;
  std::string cate_name;   // use , to separte different levels
  double score;
  int classify_feature_type;   // feature type
  int classify_method;   // 分类方法

  bool operator>(const ClassifyResult &another) const {
    return score > another.score;
  }
};

enum FeatureType {
  kTitle = 1,
  kLabelTitle = 2,
  kSourceTitle = 3,
  kMediaTitle = 4,
  kKeyword = 5,
  kTopic = 6,
  kCateTopic = 7,
  kTitleW2v = 8,
  kContent = 9,
  kFlag = 10,
  kHighLevel = 11,
  kStat = 12,  // 用于体裁分类的一些统计特征
  kLDA = 13,
  kParagraphF0 = 1000,  // 第 X 段就在此后面 + X, 中间位置占位
  kParagraphL0 = 2000,  // 倒数第 X 段就在后面 + X, 中间位置占位

  kSentenceF0 = 3000,  // 第 X 句就在此后面 + X, 中间位置占位
  kSentenceL0 = 4000,  // 倒数第 X 句就在后面 + X, 中间位置占位

  kOtherFeatureType = 255
};
}
}
