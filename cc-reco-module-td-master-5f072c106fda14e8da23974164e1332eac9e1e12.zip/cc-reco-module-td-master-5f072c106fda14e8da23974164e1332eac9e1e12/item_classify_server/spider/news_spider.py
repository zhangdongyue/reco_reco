#!encoding=utf8
from bs4 import BeautifulSoup
import urllib2, urlparse, sys, Queue, threading, time

class SpiderWorker(threading.Thread):
  def __init__(self, thread_id, task_queue, title_category_queue):
    threading.Thread.__init__(self)
    self.thread_id = thread_id
    self.task_queue = task_queue
    self.title_category_queue  = title_category_queue
    self.running = True
  
  def ParseTitleAndNextUrl(self, soup, url, category, titles):
    # parse next page  url
    next_url = ""
    parse_result = urlparse.urlparse(url)
    base_url = parse_result.scheme + "://" + parse_result.hostname
    if parse_result.hostname == None or len(parse_result.hostname) < 1:
      sys.stderr.write("erro url: " + url)
      return ""
  
    elements = soup.select("p[class=pg] > a")
    if len(elements) > 0:
      e = elements[len(elements) - 1]
      if e.getText().encode("utf8") == "下一页":
        next_url = e.get("href")
        if next_url == None or len(next_url) < 1:
          sys.stderr.write("empty next url")
          next_url = ""
  
      next_url = urlparse.urljoin(base_url, next_url)
    
    # parse title
    for anchor in soup.select("div[class=p2] > div > a[mon=ph]"):
      title = anchor.getText().encode("utf8")
      if len(title) < 3:
        sys.stderr.write("erro title: %s\n" %title)
        continue
      titles.append("%s\t%s" %(title, category))

    return next_url
  
  def is_running(self):
    return self.running

  def run(self):
    print "start spider worker: %d" %self.thread_id
    while not self.task_queue.empty():
      (category,url) = ("", "");
      try:
        (category, url) = self.task_queue.get(True, 5)
      except:
        sys.stderr.write("get task failed")
        continue

      if len(category) == 0:
        continue
      
      print "begin deal: %s" %url
      soup = BeautifulSoup(urllib2.urlopen(url).read())
    
      titles = []
      next_url = self.ParseTitleAndNextUrl(soup, url, category, titles);

      if len(next_url) > 7:
        self.task_queue.put((category, next_url))

      for title in titles:
        if len(title) < 2:
          sys.stderr.write("error title: %s" %title)
          continue
        
      self.title_category_queue.put(titles)

      print "after process url: %s, current title category queue size: %d" %(url, self.title_category_queue.qsize())

    self.running = False 
    print "exist spider worker: %d" %self.thread_id

def main():
  if len(sys.argv) != 4:
    sys.stderr.write("usage: %s $level2_input $out_file thread_num")
    exit(-1)

  spider_queue = Queue.Queue(1000)
  for line in open(sys.argv[1]):
    elements = line.split("\t")
    if len(elements) < 2 or len(elements) > 3:
      sys.stderr.write("erro record: %s"% line)
      continue
    
    url = elements[1]
    category = elements[0]

    if len(elements) == 3:
      url = elements[2]
      category += "\t" + elements[1]
    
    spider_queue.put((category, url))
  
  title_category_queue = Queue.Queue(1000)
  # spider worker start
  thread_num = int(sys.argv[3])
  threads = []
  for i in range(0, thread_num):
    threads.append(SpiderWorker(i, spider_queue, title_category_queue))
    threads[len(threads) - 1].start()
  
  fout = open(sys.argv[2], "w")
  num = 0 
  while True:
    if title_category_queue.qsize() < 1:
      stop_num = 0
      for worker in threads:
        if not worker.is_running():
          stop_num += 1

      if stop_num == len(threads):
        break;
      
      print "stopnum=%d and sleep for 2 seconds" %stop_num
      time.sleep(2)
      continue

    strs = title_category_queue.get(True, 5)
    num += len(strs)
    for title_category_str in strs:
      fout.write(title_category_str)
      fout.write("\n")

  fout.flush()
  print "title num: %d" %num
    
def GenerateLevel2CategoryCandidate():
  # level1 category url only used for generate level2 candidates
  level1_category_url = {"国内"  : "http://news.baidu.com/n?cmd=4&class=civilnews",
                         "国际"  : "http://news.baidu.com/n?cmd=4&class=internews",
                         "军事"  : "http://news.baidu.com/n?cmd=4&class=mil",
                         "财经"  : "http://news.baidu.com/n?cmd=4&class=finannews",
                         "互联网": "http://news.baidu.com/n?cmd=4&class=internet",
                         "房产"  : "http://news.baidu.com/n?cmd=4&class=housenews",
                         "汽车"  : "http://news.baidu.com/n?cmd=4&class=autonews",
                         "体育"  : "http://news.baidu.com/n?cmd=4&class=sportnews",
                         "娱乐"  : "http://news.baidu.com/n?cmd=4&class=enternews",
                         "游戏"  : "http://news.baidu.com/n?cmd=4&class=gamenews",
                         "教育"  : "http://news.baidu.com/n?cmd=4&class=edunews",
                         "女人"  : "http://news.baidu.com/n?cmd=4&class=healthnews",
                         "科技"  : "http://news.baidu.com/n?cmd=4&class=technnews",
                         "社会"  : "http://news.baidu.com/n?cmd=4&class=socianews",
                         };

  fout = open("candidate.txt", "w")
  for level1_category, url in level1_category_url.items():
    response = urllib2.urlopen(url)
    soup = BeautifulSoup(response.read())

    # parse all the level2 category
    for e in soup.select('#nav_sub > a'):
      fout.write("%s\t%s\t%s\n" %(level1_category, e.getText().encode("utf8"), e.get("href")))

if __name__ == "__main__":
  # GenerateLevel2CategoryCandidate()
  main()
