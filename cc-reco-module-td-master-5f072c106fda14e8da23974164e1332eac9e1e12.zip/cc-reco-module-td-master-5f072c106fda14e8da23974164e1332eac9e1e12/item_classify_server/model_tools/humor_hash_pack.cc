#include <fstream>
#include <base/file/file_path.h>
#include <base/file/file_util.h>
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_split.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_printf.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "reco/module/item_classify_server/global_data/define.h"

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_string(output_file, "humor_hash.bin", "shcema");
DEFINE_string(input_file, "input.txt", "shcema");
DEFINE_string(exclude_file, "exclude_file.txt", "shcema");

DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table");
DEFINE_bool(use_db, true, "whether use db to collect data");

DEFINE_int32(thread_num, 8, "thread num");
DEFINE_int32(stat_days, 120, "stat in last XXX days");
DEFINE_int32(limit, 20000, "max return number");
DEFINE_string(cate, "幽默", "shcema");


void Extract(std::vector<uint64>* ids, thread::BlockingQueue<int64>* result_queue_feature,
             thread::BlockingVar<int>* finish_num) {
  std::vector<reco::item_classify::RawItem> raw_items;
  reco::HBaseGetItem hbase_pool_get_item(FLAGS_hbase_item_table, 0);

  LOG(WARNING) << "准备读取数据";
  reco::item_classify::ItemUtil::GetRawitem(&hbase_pool_get_item, *ids, &raw_items);
  for (int i = 0; i < (int) raw_items.size(); i++) {
    for (size_t j = 0; j < raw_items[i].para_simhash.size(); ++j) {
      result_queue_feature->Put(raw_items[i].para_simhash[j]);
    }
    for (size_t j = 0; j < raw_items[i].picture_simhash.size(); ++j) {
      result_queue_feature->Put(raw_items[i].picture_simhash[j]);
    }
  }
  LOG(WARNING) << "完成读取数据";
  int n = finish_num->Take() + 1;
  if (n == FLAGS_thread_num) {
    result_queue_feature->Close();
  }
  CHECK(finish_num->TryPut(n));

}

void Output(thread::BlockingQueue<int64>* result_queue_feature) {
  std::unordered_set<int64> out_hash;
  std::vector<int64> out_hash_vector;
  int64 element;
  // 读取要排除的 item 的 simhash
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_exclude_file), &lines)) << FLAGS_input_file;

  uint64 item_id_n;
  std::vector<uint64> id_vector;
  for (size_t j = 0; j < lines.size(); ++j) {
    item_id_n = base::ParseUint64OrDie(lines[j]);
    id_vector.push_back(item_id_n);
  }

  std::vector<reco::item_classify::RawItem> raw_items;
  reco::HBaseGetItem hbase_pool_get_item(FLAGS_hbase_item_table, 0);
  std::unordered_set<int64> exclude_simhash;
  LOG(WARNING) << "准备读取数据";
  reco::item_classify::ItemUtil::GetRawitem(&hbase_pool_get_item, id_vector, &raw_items);
  for (int i = 0; i < (int) raw_items.size(); i++) {
    for (size_t j = 0; j < raw_items[i].para_simhash.size(); ++j) {
      exclude_simhash.insert(raw_items[i].para_simhash[j]);
    }
    for (size_t j = 0; j < raw_items[i].picture_simhash.size(); ++j) {
      exclude_simhash.insert(raw_items[i].picture_simhash[j]);
    }
  }

  // 读取已有数据然后合并到一起
  std::ifstream fin(FLAGS_output_file, std::ifstream::binary);
  int size;

  fin.read(reinterpret_cast<char*>(&size), sizeof(size));
  out_hash_vector.resize(size);
  fin.read(reinterpret_cast<char*>(&out_hash_vector.front()), size * sizeof(out_hash_vector.front()));

  fin.close();
  for (size_t i = 0; i < out_hash_vector.size(); ++i) {
    if (exclude_simhash.find(out_hash_vector[i]) != exclude_simhash.end()) continue;
    out_hash.insert(out_hash_vector[i]);
  }
  out_hash_vector.clear();
  while (!(result_queue_feature->Closed() && result_queue_feature->Empty())) {
    if (!result_queue_feature->Take(&element)) break;
    out_hash.insert(element);
  }
  for (auto it = out_hash.begin(); it != out_hash.end(); ++it) {
    if (exclude_simhash.find(*it) != exclude_simhash.end()) continue;
    out_hash_vector.push_back(*it);
  }
  std::ofstream fout(FLAGS_output_file);
  int length = out_hash_vector.size();
  fout.write(reinterpret_cast<char*>(&length), sizeof(length));
  fout.write(reinterpret_cast<char*>(&out_hash_vector.front()), out_hash_vector.size() * sizeof(out_hash_vector.front()));  // NOLINT

  fout.close();
}
int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "humor hash pack");

  std::vector<std::vector<uint64>*> id_vector;
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    id_vector.push_back(new std::vector<uint64>());
  }

  uint64 item_id_n;

  if (FLAGS_use_db) {
    serving_base::mysql_util::DbConnManager::Option db_option;
    db_option.host = FLAGS_db_host;
    db_option.user = FLAGS_db_user;
    db_option.passwd = FLAGS_db_passwd;
    db_option.schema = FLAGS_schema;

    serving_base::mysql_util::DbConnManager* db_manager =
            new serving_base::mysql_util::DbConnManager(db_option);

    uint64 timestamp = 0;
    CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond, &timestamp));
    timestamp -= FLAGS_stat_days * 24 * 3600 * 1000000lu;  // last 30 days

    std::string time_str;
    CHECK(serving_base::TimeHelper::TimestampToString(timestamp, serving_base::TimeHelper::kSecond, &time_str));
    LOG(INFO) << "从数据库读取itemid列表";
    // 拉取数据
    std::string sql = "select item_id from tb_item_info_tddl where item_type<>30 and source<>'' and create_time >'" +
                      time_str //NOLINT
                      +
                      "' and create_time < '2020-03-01' and category like '" //NOLINT
                      + FLAGS_cate + "\%'  limit " + base::IntToString(FLAGS_limit); //NOLINT
    LOG(INFO) << sql;
    sql::ResultSet* res = db_manager->ExecuteQueryWithRetry(sql, 3);
    std::unordered_map<std::string, std::vector<std::pair<std::string, int >>> data;
    if (res == NULL) {
      LOG(ERROR) << "FAILED in reading data" << sql;
      return -1;
    }
    while (res->next()) {
      const std::string item_id = res->getString("item_id");
      item_id_n = base::ParseUint64OrDie(item_id);
      id_vector[item_id_n % FLAGS_thread_num]->push_back(item_id_n);
    }
  }
  // 文件中人工添加的数据
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_input_file), &lines)) << FLAGS_input_file;
  for (size_t j = 0; j < lines.size(); ++j) {
    item_id_n = base::ParseUint64OrDie(lines[j]);
    id_vector[item_id_n % FLAGS_thread_num]->push_back(item_id_n);
  }


  thread::BlockingQueue<int64> result_queue_feature;
  thread::BlockingVar<int> finish_num;

  thread::ThreadPool pool(FLAGS_thread_num + 1);
  CHECK(finish_num.TryPut(0));

  pool.AddTask(
            ::NewCallback(Output, &result_queue_feature)); // NOLINT

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(Extract, id_vector[i], &result_queue_feature, &finish_num)); // NOLINT
  }
  pool.JoinAll();
  return 0;
}
