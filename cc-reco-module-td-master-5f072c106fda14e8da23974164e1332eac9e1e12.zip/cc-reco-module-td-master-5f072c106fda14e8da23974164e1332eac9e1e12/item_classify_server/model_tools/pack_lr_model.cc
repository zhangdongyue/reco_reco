#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>
#include <map>

#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "nlp/common/nlp_util.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"
#include "reco/module/item_classify_server/global_data/dict_loader.h"
#include "reco/module/item_classify_server/global_data/define.h"

DEFINE_string(plan_model, "./model.txt", "data, with or without stat");
DEFINE_string(model_bin, "lr.dat", "lr model, three part, category ");

class LRModelPacker {
 public:
  LRModelPacker() {}

  void LoadPlanModel(const base::FilePath& plan_model);
  bool Package(const base::FilePath& out);

  static const int kMaxCategoryIdx = 0xffff;  // 256 * 256
  static const int kMaxFeaIdx = 0x7ffffff;  // 128 * 256 * 256 * 256

 private:
  bool AddFea(const std::string& literal, int start, const std::vector<std::string>& tokens);

  int AddCategory(const std::string& category) {
    if (category.empty()) return 0;

    auto it_pair = category_dict_.insert(std::make_pair(category, all_category_.size()));
    if (it_pair.second) {
      all_category_.push_back(category);
    }
    return it_pair.first->second;
  }

  std::unordered_map<std::string, int> category_dict_;
  std::vector<std::string> all_category_;

  std::map<std::string, int> fea_dict_;
  std::vector<float> fea_weights_;  // 三个一组，第一个是 category idx，第二个为 prob，第三个为 confidence
  std::vector<uint32> weight_offset_;
};

bool LRModelPacker::AddFea(const std::string& literal,
                           int start,
                           const std::vector<std::string>& tokens) {
  // TODO(xielang): 统一 不用区分终结节点，全部用来做 feature
  uint32 fea_idx = fea_dict_.size();
  auto it_pair = fea_dict_.insert(std::make_pair(literal, fea_idx));
  if (!it_pair.second) {
    LOG(ERROR) << "dedup fea:" << literal;
    return false;
  }

  int first_pos = fea_weights_.size();

  for (int i = start; i < (int)tokens.size(); i += 3) {
    CHECK_GT((int)tokens.size(), i + 2);
    std::string category = tokens[i];
    base::TrimWhitespaces(&category);

    int category_idx = AddCategory(category);
    CHECK_GT(kMaxCategoryIdx, category_idx);
    CHECK_GT(category_idx, 0) << category_dict_.size() << " miss: " << category << " orig "
                              << tokens[i];

    fea_weights_.push_back(0);
    memcpy(reinterpret_cast<char*>(&(fea_weights_.back())),
           reinterpret_cast<const char*>(&category_idx),
           sizeof(float));

    fea_weights_.push_back(base::ParseDoubleOrDie(tokens[i + 1]));
    // double count = base::ParseDoubleOrDie(tokens[i + 2]);
    // fea_weights_.push_back(count);
  }

  CHECK_GT((int)fea_weights_.size(), first_pos);

  int bitmap = 0;
  memcpy(reinterpret_cast<char*>(&bitmap),
         reinterpret_cast<char*>(&fea_weights_[first_pos]),
         sizeof(bitmap));
  uint32 fea_weight_num = (fea_weights_.size() - first_pos) / 2;
  CHECK_GE(1u << 16, fea_weight_num);
  bitmap |= fea_weight_num << 16;
  memcpy(reinterpret_cast<char*>(&fea_weights_[first_pos]),
         reinterpret_cast<char*>(&bitmap),
         sizeof(bitmap));

  return true;
}

void LRModelPacker::LoadPlanModel(const base::FilePath& plan_model) {
  std::string line;
  std::vector<std::string> tokens;
  std::vector<std::string> words;

  weight_offset_.reserve(1024 * 1024 * 20);

  fea_dict_.clear();
  std::ifstream fin(plan_model.value());
  std::string ngram;

  uint32 offset = 0;
  int ngram_start = 1;
  all_category_.push_back("");
  while (std::getline(fin, line)) {
    if (line.size() < 2) continue;

    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    CHECK_GT(tokens.size(), 4u) << line;

    words.clear();
    int ngram_type = base::ParseIntOrDie(tokens[0]);
    int ngram_end = ngram_start + ngram_type;
    words.assign(tokens.begin() + ngram_start, tokens.begin() + ngram_end);
    CHECK_EQ(ngram_type, (int)words.size()) << tokens[0] << " : " << line;

    for (int i = 0; i < ngram_type; ++i) {
      nlp::util::NormalizeLineInPlaceS(&words[i]);
    }
    // add by lijing，处理 video 特征
    if (words[0] == "#video#") {
      std::sort(words.begin() + 1, words.end());
    }
    // 之前已经排好序了，不需要再排了
//    else {
//      // NOTE(xielang): special term is $, source term would always at the first
//      std::sort(words.begin(), words.end());
//    }

    // add whole ngram
    ngram.clear();
    base::FastJoinStrings(words, "\t", &ngram);


    CHECK_GE(ngram.size(), 1u);
    if (AddFea(ngram, ngram_type + 1, tokens)) {
      weight_offset_.push_back(offset);
      offset += 2 * (tokens.size() - 1 - ngram_type) / 3;
    } else {
      LOG(ERROR) << "drop " << line << " for dedup fea:" << ngram;
    }
  }
  weight_offset_.push_back(offset);
}

bool LRModelPacker::Package(const base::FilePath& out_file) {
  // part 1: fea dict
  std::ofstream bofs(out_file.value());
  // part 3: all category for lr
  std::string buf;
  base::FastJoinStrings(all_category_, "\t", &buf);
  uint32 len = buf.size();
  bofs.write(reinterpret_cast<char*>(&len), sizeof(len));
  LOG(INFO) << " write all category: " << buf;
  bofs.write(buf.c_str(), buf.size());

  LOG(INFO) << "begin to build fea dict";
  CHECK_GT(fea_dict_.size(), 0u);
  dawgdic::DawgBuilder builder;
  for (auto it = fea_dict_.begin(); it != fea_dict_.end(); ++it) {
    CHECK(builder.Insert(it->first.c_str(), it->second));
  }
  dawgdic::Dawg dawg;
  builder.Finish(&dawg);
  dawgdic::Dictionary dict;
  CHECK(dawgdic::DictionaryBuilder::Build(dawg, &dict));

  dict.Write(&bofs);
  LOG(INFO) << "fea_dict: " << dict.size() << "; dict file size: " << dict.file_size();

  // part 2: weights
  uint32 offset_num = weight_offset_.size();
  bofs.write(reinterpret_cast<char*>(&offset_num), sizeof(offset_num));
  bofs.write(reinterpret_cast<char*>(&weight_offset_.front()), weight_offset_.size() * sizeof(weight_offset_.front()));  // NOLINT
  uint64 weight_size = fea_weights_.size() * sizeof(fea_weights_[0]);
  bofs.write(reinterpret_cast<char*>(&fea_weights_.front()), weight_size);
  LOG(INFO) << "finish write ngram weights weight size: " << weight_size << " total offset: " << offset_num;



  bofs.close();
  return true;
}

bool Validate(const base::FilePath& plan_model, const base::FilePath& model_bin) {
  // load model first
  reco::item_classify::LRModel model;
  reco::item_classify::LoadLRModel(model_bin, &model);
  // use plan model validate
  std::vector<std::string> feas;
  std::ifstream fin(plan_model.value());
  int max_line = 100000;
  std::string line;
  std::vector<std::string> flds;

  std::unordered_map<std::string, double> cate_truth;
  std::unordered_map<std::string, double> cate_model;

  int miss = 0;
  int hit = 0;
  std::unordered_set<std::string> fea_dict;
  while (max_line > 0 and std::getline(fin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    CHECK_GT(flds.size(), 4u);
    int n = base::ParseIntOrDie(flds[0]);
    CHECK_GT((int)flds.size(), n + 1);

    for (int j = 1; j < n + 1; ++j) {
      nlp::util::NormalizeLineInPlaceS(&(flds[j]));
    }
    // add by lijing: 处理 video 类型的特征
    if (flds[1] == "#video#") {
      std::sort(flds.begin() + 2, flds.begin() + n + 1);
    }
    std::string term = flds[1];
    for (int j = 2; j < n + 1; ++j) {
      term.append("\t");
      term.append(flds[j]);
    }
    // NOTE(xielang): 模型打包发现了同样 fea 不再同一行，忽略所有后面的
    auto it_pair = fea_dict.insert(term);
    if (!it_pair.second) {
      LOG(ERROR) << "dedup fea " << term;
      continue;
    }

    int value = model.dict.Find(term.c_str(), term.size());
    if (value < 0) {
      LOG(ERROR) << "miss fea: " << term;
      ++miss;
      continue;
    }
    ++hit;

    const float* weight = model.weights + model.offset[value];
    // LOG(INFO) << "offset: " << model.offset[value];
    int category_num = (reinterpret_cast<const int &>(*weight) >> 16);

    cate_model.clear();
    for (int j = 0; j < category_num; ++j) {
      int v = reinterpret_cast<const int &>(*weight);
      int category_idx = v & 0xffff;
      CHECK_GT(category_idx, 0);
      VLOG(1) << term << " fea: " << category_idx << " " << *(weight + 1);
      // TODO(xielang): 升级 category idx 位 快不够用
      CHECK_GT((int)model.all_category.size(), category_idx);

      cate_model[model.all_category[category_idx]] += *(weight + 1);
      weight += 2;
    }

    cate_truth.clear();
    for (int j = n + 1; j < (int)flds.size(); j += 3) {
      base::TrimWhitespaces(&flds[j]);
      float score = base::ParseDoubleOrDie(flds[j + 1]);
      auto it_pair = cate_truth.insert(std::make_pair(flds[j], score));
      if (!it_pair.second) {
        VLOG(1) << "dup category: " << flds[j] << " for line: " << line;
        it_pair.first->second += score;
      }
    }

    CHECK_EQ(cate_model.size(), cate_truth.size());
    for (auto it = cate_truth.begin(); it != cate_truth.end(); ++it) {
      auto it2 = cate_model.find(it->first);
      if (it2 == cate_model.end()) {
        // for (auto it3 = cate_model.begin(); it3 != cate_model.end(); ++it3) {
        //   LOG(INFO) << it3->first << " " << it3->second;
        // }
      }
      CHECK(it2 != cate_model.end()) << "fail fea: " << term << " model miss: " << it->first;
      float delta = it->second - it2->second;
      if (delta > 1e-6 || delta < -1e-6) {
        LOG(ERROR) << "term: " << term << " weight diff " << it->second << " vs " << it2->second;
        for (auto it3 = cate_model.begin(); it3 != cate_model.end(); ++it3) {
          LOG(INFO) << it3->first << " " << it3->second;
        }
        return false;
      }
    }
  }
  LOG(INFO) << " hit ratio : " << static_cast<float>(hit) / (hit + miss);
  return true;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "pack lr model");
  LRModelPacker lr_packer;
  lr_packer.LoadPlanModel(base::FilePath(FLAGS_plan_model));
  lr_packer.Package(base::FilePath(FLAGS_model_bin));
  CHECK(Validate(base::FilePath(FLAGS_plan_model), base::FilePath(FLAGS_model_bin)));
  return 0;
}
