#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>
#include <map>

#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "nlp/common/nlp_util.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"
#include "reco/module/item_classify_server/global_data/dict_loader.h"
#include "reco/module/item_classify_server/global_data/define.h"

DEFINE_string(plan_dict_file, "./pair_semantic.txt", "data, with or without stat");
DEFINE_string(bin_dict_file, "pair_semantic.dat", "lr model, three part, category ");

void LoadPlanDict(const base::FilePath& plan_dict_file, std::map<std::string, int>* load_cache,
                  std::vector<std::string>* categories) {
  std::string line;
  std::vector<std::string> tokens;

  std::ifstream fin(plan_dict_file.value());

  categories->push_back("");

  std::unordered_map<std::string, int> cate_dict;

  while (std::getline(fin, line)) {
    if (line.size() < 2) continue;

    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    CHECK_GT(tokens.size(), 2u) << line;

    nlp::util::NormalizeLineInPlaceS(&tokens[0]);
    int v = base::ParseIntOrDie(tokens[1]);
    CHECK_GT(128, v);

    auto it_pair = cate_dict.insert(std::make_pair(tokens[2], categories->size()));
    if (it_pair.second) {
      categories->push_back(tokens[2]);
    }

    auto it_pair2 = load_cache->insert(std::make_pair(tokens[0], v | it_pair.first->second << 8));
    if (!it_pair2.second) {
      LOG(ERROR) << "dup: " << line;
    }
  }
}

bool Package(const base::FilePath& out_file, const std::map<std::string, int>& load_cache,
             const std::vector<std::string>& categories) {
  // part 1: fea dict
  std::ofstream bofs(out_file.value());
  // part 3: all category for lr
  std::string buf;
  base::FastJoinStrings(categories, "\t", &buf);
  uint32 len = buf.size();
  bofs.write(reinterpret_cast<char*>(&len), sizeof(len));
  LOG(INFO) << " write all category: " << buf;
  bofs.write(buf.c_str(), buf.size());

  LOG(INFO) << "begin to build fea dict";
  CHECK_GT(load_cache.size(), 0u);
  dawgdic::DawgBuilder builder;
  for (auto it = load_cache.begin(); it != load_cache.end(); ++it) {
    CHECK(builder.Insert(it->first.c_str(), it->second));
  }
  dawgdic::Dawg dawg;
  builder.Finish(&dawg);
  dawgdic::Dictionary dict;
  CHECK(dawgdic::DictionaryBuilder::Build(dawg, &dict));

  dict.Write(&bofs);
  LOG(INFO) << "fea_dict: " << dict.size() << "; dict file size: " << dict.file_size();
  return true;
}

bool Validate(const base::FilePath& plan_model, const base::FilePath& model_bin) {
  return true;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "pack lr model");
  std::vector<std::string> categories;
  std::map<std::string, int> load_cache;
  LoadPlanDict(base::FilePath(FLAGS_plan_dict_file), &load_cache, &categories);
  Package(base::FilePath(FLAGS_bin_dict_file), load_cache, categories);
  CHECK(Validate(base::FilePath(FLAGS_plan_dict_file), base::FilePath(FLAGS_bin_dict_file)));
  return 0;
}
