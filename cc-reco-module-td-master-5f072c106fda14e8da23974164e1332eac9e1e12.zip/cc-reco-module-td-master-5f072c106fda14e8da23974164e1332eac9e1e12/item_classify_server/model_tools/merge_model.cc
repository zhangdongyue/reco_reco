#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/hash_function/term.h"
#include "base/container/dense_hash_map.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"
#include "base/file/dir_reader_posix.h"

DEFINE_string(input_paths, "sep by space", "input path for model file");
DEFINE_string(output, "model.txt", "output model file");
DEFINE_int32(thread_num, 4, "thread_num for each file");

void GetFileList(const base::FilePath& dir, std::vector<std::string>* file_list) {
  base::DirReaderPosix reader(dir.value().c_str());
  CHECK(reader.IsValid());

  for (; reader.Next(); ) {
    std::string filename(reader.name());
    if (filename.find(".txt") != filename.size() - 4) continue;

    LOG(INFO) << "find file: " << filename;
    file_list->push_back(dir.Append(filename).value());
  }
}

void process(std::vector<std::string>* lines, int id, int thread_num,
             thread::BlockingQueue<std::pair<std::string, std::string> >* key_value_queue) {
  std::string line;
  std::vector<std::string> tokens;
  std::pair<std::string, std::string> key_value;
  for (int i = id; i < (int)lines->size(); i += thread_num) {
    tokens.clear();
    base::SplitString(lines->at(i), "\t", &tokens);
    if (tokens.size() < 3) {
      LOG(ERROR) << "erro line: " << lines->at(i);
      continue;
    }

    double weight = base::ParseDoubleOrDie(tokens[0]);
    int n = tokens.size() - 2;
    key_value.first.clear();
    base::AppendIntToString(n, &key_value.first);
    for (int i = 1; i < n + 1; ++i) {
      key_value.first.append("\t");
      key_value.first.append(tokens[i]);
    }
    key_value.second = base::StringPrintf("%s\t%lf\t1", tokens.back().c_str(), weight);
    key_value_queue->Put(key_value);
  }
}

void GenerateKeyValuePair(std::string file,
                          int file_num,
                          thread::BlockingQueue<std::pair<std::string, std::string> >* key_value_queue,
                          thread::BlockingVar<int>* finish_num) {
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(base::FilePath(file), &lines);
  int thread_num = FLAGS_thread_num;
  thread::ThreadPool pool(thread_num);
  for (int i = 0; i < thread_num && i < (int)lines.size(); ++i) {
    pool.AddTask(::NewCallback(&process, &lines, i, thread_num, key_value_queue));
  }
  pool.JoinAll();

  int n = finish_num->Take() + 1;
  if (n >= file_num) {
    key_value_queue->Close();
  }
  finish_num->TryPut(n);
  LOG(INFO) << "finish read and generate key value for " << file;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "calc term sign");

  base::dense_hash_map<std::string, std::string> fea_dict;
  fea_dict.set_empty_key("");

  // get all model file
  std::vector<std::string> file_list;
  std::vector<std::string> dir_list;
  base::SplitString(FLAGS_input_paths, " ", &dir_list);
  for (size_t i = 0; i < dir_list.size(); ++i) {
    GetFileList(dir_list[i], &file_list);
  }

  // multi thread generate plan file
  thread::ThreadPool pool(file_list.size());
  thread::BlockingQueue<std::pair<std::string, std::string>> key_value_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  for (size_t i = 0; i < file_list.size(); ++i) {
    pool.AddTask(::NewCallback(&GenerateKeyValuePair, file_list[i], (int)file_list.size(),
                               &key_value_queue, &finish_num));
  }

  std::pair<std::string, std::string> key_value;
  while (!(key_value_queue.Closed() && key_value_queue.Empty())) {
    if (!key_value_queue.Take(&key_value)) break;
    auto it = fea_dict.find(key_value.first);
    if (it == fea_dict.end()) {
      fea_dict[key_value.first] = key_value.second;
    } else {
      it->second.append("\t");
      it->second.append(key_value.second);
    }
  }
  pool.JoinAll();

  LOG(INFO) << "begin to write fea dict ";
  std::ofstream fout(FLAGS_output);
  for (auto it = fea_dict.begin(); it != fea_dict.end(); ++it) {
    fout << it->first << "\t" << it->second << "\n";
  }
  fout.close();
}
