#include <fstream>
#include "reco/module/item_classify_server/common/StringUtil.h"

#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_split.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/strings/string_printf.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "serving_base/utility/time_helper.h"

#include "reco/base/redis_c/api/redis_cli_pool.h"

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_int32(thread_num, 8, "thread num");
DEFINE_bool(is_debug, true, "if set print key value out");

DEFINE_int32(stat_days, 5, "stat in last XXX days");

DEFINE_string(output_file, "source_stat.txt", "output_file");
int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "put source history stat info into redis");

  // 写入 redis
  LOG(INFO) << "Init...";

  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;


  serving_base::mysql_util::DbConnManager* db_manager =
          new serving_base::mysql_util::DbConnManager(db_option);

  uint64 timestamp = 0;
  CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond, &timestamp));
  timestamp -= FLAGS_stat_days * 24 * 3600 * 1000000lu;  // last 30 days

  std::string time_str;
  CHECK(serving_base::TimeHelper::TimestampToString(timestamp, serving_base::TimeHelper::kSecond, &time_str));
  LOG(INFO) << "Reading  Data from mysql";
  // 拉取数据
  std::string sql = "select category,source,count(*) as c from tb_item_info where item_type<>30 and source<>'' and create_time >'" + time_str //NOLINT
                    + "' and source not like 'probe_query' and source not like '%竞品%' and category not like '未分类' group by category,source"; //NOLINT

  sql::ResultSet* res = db_manager->ExecuteQueryWithRetry(sql, 3);
  std::unordered_map<std::string, std::vector<std::pair<std::string, int> >> data;
  if (res == NULL) {
    LOG(ERROR) << "FAILED in reading data" << sql;
    return -1;
  }
  std::vector<std::pair<std::string, int>> empty_vector;
  int c =0;
  while (res->next()) {
    const std::string cateory = res->getString("category");
    const std::string source = res->getString("source");
    const int count = res->getInt("c");

    auto it= data.find(source);
    if (it == data.end()) {
      data.insert(std::make_pair(source, empty_vector));
    }
    data[source].push_back(std::make_pair(cateory, count));
    c+=1;
    LOG_EVERY_N(INFO, 5000)
      << base::StringPrintf("Fininish Reading%d source=%s & category =%s",
                            c, source.c_str(), cateory.c_str());
  }
  // 做统计
  c = 0;
  std::string buf_out = "";
  for (auto it = data.begin(); it != data.end(); ++it) {
    int allcount = 0;
    const std::vector<std::pair<std::string, int> >& source_data = it->second;
    for (size_t i = 0; i < source_data.size(); ++i) {
      allcount += source_data[i].second;
    }
    if (allcount <= 10) continue;
    std::unordered_map<std::string, double> out_data;
    for (size_t i = 0; i < source_data.size(); ++i) {
      std::string cate = source_data[i].first;
      auto it = out_data.find(cate);
      // 给当前类累加一个占比
      if ( it == out_data.end()) {
        out_data.insert(std::make_pair(cate, 0.0));
      }
      out_data[cate] += source_data[i].second * 100.0 / allcount;
      if (cate.find(",") != std::string::npos) {
        cate = cate.substr(0, cate.find(","));

        it = out_data.find(cate);
        // 给当前类累加一个占比
        if ( it == out_data.end()) {
          out_data.insert(std::make_pair(cate, 0.0));
        }
        out_data[cate] += source_data[i].second * 100.0 / allcount;
      }
    }
    const std::string& key = it->first;
    std::string value;
    reco::item_classify::StringUtil::Map2String(out_data, &value);
    buf_out.append(base::StringPrintf("%s\t%s\n", key.c_str(), value.c_str()));
    c+=1;
    LOG_EVERY_N(INFO, 1000)
      << base::StringPrintf("Finishing Generate Key & values: %d/%d source=%s",
                            c, (int) data.size(), key.c_str());
  }
  std::ofstream fout(FLAGS_output_file);
  fout << buf_out;
  delete db_manager;
}
