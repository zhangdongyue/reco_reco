#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/hash_function/term.h"
#include "serving_base/utility/signal.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/proto/item_classify.pb.h"
#include "reco/proto/item.pb.h"
#include "reco/item_service/hbase_pool_get_item.h"

DEFINE_string(item_classify_server_ip, "127.0.0.1", "sim item server ip");
DEFINE_int32(item_classify_server_port, 20004, "sim item server port");

DEFINE_int32(send_worker_num, 8, "thread num for send request");
DEFINE_int32(hbase_thread_num, 16, "thread num for send request");

DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table");

DEFINE_bool(is_debug, false, "if set, print debug info");
using reco::item_classify::GetAllModelRequest;
using reco::item_classify::GetAllModelResponse;
using reco::RecoItem;

inline void Transfer(const RecoItem& reco_item, GetAllModelRequest* request) {
  request->set_source(reco_item.source());
  request->set_title(reco_item.title());
  request->set_content(reco_item.content());
  request->set_is_debug(FLAGS_is_debug);

  // keyword and tag
  const reco::FeatureVector& keyword_fea = reco_item.keyword();
  for (int j = 0; j < keyword_fea.feature_size(); ++j) {
    request->add_keyword(keyword_fea.feature(j).literal());
  }

  const reco::FeatureVector& tag_fea = reco_item.tag();
  for (int j = 0; j < tag_fea.feature_size(); ++j) {
    request->add_tag(tag_fea.feature(j).literal());
  }
  request->mutable_topic()->CopyFrom(reco_item.topic());
  if (!request->topic().has_norm()) {
    request->mutable_topic()->set_norm(1.0);
  }
}

static void ConvertRecoItemToRequest(thread::BlockingQueue<uint64>* item_id_q,
                                     thread::BlockingQueue<std::pair<uint64, GetAllModelRequest*> >* req_q) {
  reco::HBasePoolGetItem* hbase_get_item = new reco::HBasePoolGetItem(FLAGS_hbase_item_table, 0);

  std::vector<uint64> item_ids;
  std::vector<reco::RecoItem> reco_items;
  std::vector<bool> rets;
  uint64 item_id;
  int n = 0;
  int m = 0;
  int fail = 0;
  while (!(item_id_q->Closed() && item_id_q->Empty())) {
    if (item_id_q->Empty()) {
      base::SleepForMilliseconds(100);
      continue;
    }

    if (!item_id_q->Take(&item_id)) break;

    item_ids.push_back(item_id);

    if (item_ids.size() > 128) {
      m += item_ids.size();
      reco_items.clear();
      rets.clear();
      hbase_get_item->GetRecoItems(item_ids, &rets, &reco_items);
      for (size_t i = 0; i < reco_items.size(); ++i) {
        if (!rets[i]) {
          ++fail;
          continue;
        }

        if (reco_items[i].identity().type() == reco::kPureVideo) continue;

        GetAllModelRequest* request = new GetAllModelRequest();
        Transfer(reco_items[i], request);

        req_q->Put(std::make_pair(reco_items[i].identity().item_id(), request));
        ++n;
      }
      item_ids.clear();
    }
  }
  if (!item_ids.empty()) {
    m+=item_ids.size();
    reco_items.clear();
    rets.clear();
    hbase_get_item->GetRecoItems(item_ids, &rets, &reco_items);

    for (size_t i = 0; i < reco_items.size(); ++i) {
      if (!rets[i]) {
        ++fail;
        continue;
      }
      GetAllModelRequest* request = new GetAllModelRequest();
      Transfer(reco_items[i], request);

      req_q->Put(std::make_pair(reco_items[i].identity().item_id(), request));
      ++n;
    }
  }
  LOG(ERROR) << "thread finish gen " << n << "req" << " get " << m << " from item id q" << " fail: " << fail;
}

static void GenerateRequestFromHBase(thread::BlockingQueue<std::pair<uint64, GetAllModelRequest*> >* req_q) {
  std::vector<uint64> item_ids;
  std::vector<std::string> tokens;
  std::vector<reco::RecoItem> reco_items;
  std::vector<bool> rets;

  thread::BlockingQueue<uint64> item_id_q;
  thread::ThreadPool pool(FLAGS_hbase_thread_num);
  for (int i = 0;  i < FLAGS_hbase_thread_num; ++i) {
    pool.AddTask(::NewCallback(&ConvertRecoItemToRequest, &item_id_q, req_q));
  }
  std::string line;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    if (line.size() < 2) {
      LOG(ERROR) << "erro line: " << line;
      continue;
    }
    base::TrimWhitespaces(&line);
    base::SplitString(line, "\t", &tokens);

    uint64 item_id = 0;
    if (!base::StringToUint64(tokens[0], &item_id)) continue;
    item_id_q.Put(item_id);
  }
  item_id_q.Close();
  LOG(INFO) << "finishing! remain id: " << item_id_q.Size();
  pool.JoinAll();
  LOG(INFO) << "finish generating all rquest! remain request: " << req_q->Size();
  req_q->Close();
}

static void SendWorker(thread::BlockingQueue<std::pair<uint64, GetAllModelRequest*> >* request_queue,
                       thread::BlockingQueue<std::string>* result_queue,
                       thread::BlockingVar<int>* sender_num) {
  net::rpc::RpcClientChannel channel(FLAGS_item_classify_server_ip.c_str(), FLAGS_item_classify_server_port);
  CHECK(channel.Connect());
  reco::item_classify::ItemClassifyService::Stub stub(&channel);
  reco::item_classify::GetAllModelResponse response;
  std::pair<uint64, GetAllModelRequest*> element;
  std::string buf;
  std::vector<uint64> signs;
  while (!(request_queue->Closed() && request_queue->Empty())) {
    if (request_queue->Empty()) {
      LOG_EVERY_N(INFO, 1000) << "send workersleep";
      base::SleepForSeconds(1);
      continue;
    }
    if (!request_queue->Take(&element)) break;
    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(100);
    const GetAllModelRequest* request = element.second;
    stub.GetAllModelResult(&rpc, request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.succ()) {
      LOG(ERROR) << "get model result failed: ";
      continue;
    }

    buf.clear();
    buf.append(response.category());
    buf.append("\t");
    buf.append(request->source());
    buf.append("\t");
    buf.append(request->title());
    buf.append("\t");
    signs.clear();
    for (int i = 0; i < response.literal_size(); ++i) {
      buf.append(base::StringPrintf("%s:%lf", response.literal(i).c_str(), response.score(i)));
      buf.append(" ");
      uint64 sign = base::CalcTermSign(response.literal(i).c_str(), response.literal(i).size());
      signs.push_back(sign);
    }

    buf.append("\t");
    for (size_t i = 0; i < signs.size(); ++i) {
      buf.append(base::StringPrintf("%lu:%lf ", signs[i], response.score(i)));
    }

    if (request->is_debug()) {
      buf.append("\t");
      buf.append(response.debug_str());
    }


    result_queue->Put(buf);
    delete request;
  }

  int n = sender_num->Take() + 1;
  if (n == FLAGS_send_worker_num) result_queue->Close();
  CHECK(sender_num->TryPut(n));
}

static void SaveResult(thread::BlockingQueue<std::string>* result_queue) {
  std::string buf;
  while (!(result_queue->Closed() && result_queue->Empty())) {
    if (result_queue->Empty()) {
      LOG(INFO) << "save result thread sleep";
      base::SleepForSeconds(5);
      continue;
    }

    if (!result_queue->Take(&buf)) break;
    std::cout << buf << "\n";
  }
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "sim item client");
  thread::ThreadPool pool(FLAGS_send_worker_num + 2);

  thread::BlockingQueue<std::pair<uint64, GetAllModelRequest*> > request_queue;
  thread::BlockingQueue<std::string > result_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));

  pool.AddTask(::NewCallback(&GenerateRequestFromHBase, &request_queue));

  for (int i = 0; i < FLAGS_send_worker_num; ++i) {
    pool.AddTask(::NewCallback(&SendWorker, &request_queue, &result_queue, &finish_num));
  }

  pool.AddTask(::NewCallback(&SaveResult, &result_queue));

  pool.JoinAll();
  return 0;
}
