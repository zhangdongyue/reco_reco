#!usr/bin/env python
# -*- coding:utf-8 -*-  
import sys

def genDict(filename):
  orig_dict = {}
  for line in open(filename, "r"):
    elements = line.strip().split("\t")

    title = elements[0]
    source = ""

    if len(elements) >1:
      source = elements[1]

    category = ""
    if len(elements) > 2 and len(elements[2]) > 1:
      category = ",".join(elements[2:-1])
      # category = elements[2]
    orig_dict[title + "\t" + source] = category

  return orig_dict

orig_dict = genDict(sys.argv[1])
new_dict = genDict(sys.argv[2])

fout1 = open(sys.argv[3], "w")
fout_dict={}

for title, category in orig_dict.items():
  if not new_dict.has_key(title):
    sys.stderr.write("new miss title: %s\n" %title)
    continue
  new_category = new_dict[title]
  
  old = category.split(",")
  new = new_category.split(",")

  if category == new_category:
    continue

  if old[0]=="" and new[0]!="":
    fout1.write("%s\t%s\t%s\n" %(title, category, new_category))
    continue

'''
  level1 = old[0]

  if len(old) != len(new) or old[1] != new[1]:
    if not fout_dict.has_key(level1):
      fout_dict[level1] = open("diff_allCases_%s.txt" %level1, "w")

    fout_dict[level1].write("%s\t%s\t%s\n" %(title, category, new_category))
'''

