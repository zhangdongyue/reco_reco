#include <math.h>
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/file/file_util.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "base/common/gflags.h"
#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "net/rpc/rpc.h"
#include "reco/module/item_classify_server/global_data/define.h"
DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_string(input_file, "item.txt", "model dir");
DEFINE_string(cate_name, "时尚,明星时尚", "model dir");

// 通过 diff 盲测标注平台评估的结果， 确定一个 tag 的阈值给线上使用
int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "getting threashold");
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  serving_base::mysql_util::DbConnManager *db_manager
          = new serving_base::mysql_util::DbConnManager(db_option);

  // 从文件中读取要上线的分类及标签列表
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(base::FilePath(FLAGS_input_file), &lines)) {
    LOG(ERROR) << "少年，读文件出错了";
    return false;
  }

  std::vector<std::string> cates;
  base::SplitString(FLAGS_cate_name, ",", &cates);

  std::vector<std::string> tokens;
  int label = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    std::string item_id = tokens[0];
    std::string title = tokens[1];
    if (tokens[7] == "+1") {
      label = 1;
    } else {
      label = -1;
    }
    std::string sql = base::StringPrintf(
            "insert into tb_label_labelled_data(level1, level2, itemid, title, status) values('%s', '%s', '%s', '%s', %d)",  // NOLINT
            cates[0].c_str(), cates[1].c_str(), item_id.c_str(), title.c_str(), label);
    LOG(INFO) << sql;
    int32 sql_status = db_manager->ExecuteUpdateWithRetry(sql, 3);
    if (sql_status < 1) {
       LOG(ERROR) << "sql: " << sql;
    }
  }
}
