#include <iostream>
#include <fstream>
#include <string>

#include "reco/item_service/hbase_pool_get_item.h"
#include "reco/proto/item.pb.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table");
DEFINE_int32(thread_num, 1, "thread num");

void GetItemWorker(thread::BlockingQueue<uint64>* id_queue,
                   thread::BlockingQueue<std::string>* result_queue,
                   thread::BlockingVar<int>* finish_num) {
  reco::HBasePoolGetItem* hbase_get_item = new reco::HBasePoolGetItem(FLAGS_hbase_item_table, 1000);
  std::vector<uint64> item_ids;
  std::vector<bool> rets;
  std::vector<reco::RecoItem> reco_items;
  uint64 item_id;
  std::string buf;

  while (!id_queue->Closed() || !id_queue->Empty()) {
    int status = id_queue->TimedTake(10, &item_id);
    if (status == 0) {
      continue;
    }
    if (status == -1) break;

    if (status != 1) {
      LOG(ERROR) << base::StringPrintf("erro status: %d", status);
      continue;
    }

    item_ids.push_back(item_id);
    if (item_ids.size() > 1024) {
      rets.clear();
      reco_items.clear();
      hbase_get_item->GetRecoItems(item_ids, &rets, &reco_items);
      for (int i = 0; i < (int)reco_items.size(); ++i) {
        if (!rets[i]) continue;

        buf.clear();
        if (reco_items[i].category_size() > 0) {
          buf.append(reco_items[i].category(0));
          if (reco_items[i].category_size() > 1) {
            buf.append(",");
            buf.append(reco_items[i].category(1));
          }
        }
        buf.append("\t");
        buf.append(reco_items[i].create_time());

        buf.append(base::StringPrintf("\t%d", reco_items[i].identity().type()));
        result_queue->Put(buf);
      }
      item_ids.clear();
    }
  }

  if (!item_ids.empty()) {
    rets.clear();
    reco_items.clear();
    hbase_get_item->GetRecoItems(item_ids, &rets, &reco_items);
    for (int i = 0; i < (int)reco_items.size(); ++i) {
      if (!rets[i]) continue;

      buf.clear();
      if (reco_items[i].category_size() > 0) {
        buf.append(reco_items[i].category(0));
        if (reco_items[i].category_size() > 1) {
          buf.append(",");
          buf.append(reco_items[i].category(1));
        }
      }
      buf.append("\t");
      buf.append(reco_items[i].create_time());

      buf.append(base::StringPrintf("\t%d", reco_items[i].identity().type()));
      result_queue->Put(buf);
    }
  }
  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    result_queue->Close();
  }

  CHECK(finish_num->TryPut(n));
}

void SaveWorker(thread::BlockingQueue<std::string>* result_queue) {
  std::string result;
  int n = 0;
  while (!result_queue->Closed() || !result_queue->Empty()) {
    int status = result_queue->TimedTake(10, &result);
    if (status == 0) {
      continue;
    }
    if (status == -1) break;

    if (status != 1) {
      LOG(ERROR) << base::StringPrintf("erro status: %d", status);
      continue;
    }
    std::cout << result << "\n";
    ++n;
  }
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "generate source title data");
  thread::ThreadPool pool(FLAGS_thread_num + 2);
  thread::BlockingQueue<uint64> id_queue;
  thread::BlockingQueue<std::string> result_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(&GetItemWorker, &id_queue, &result_queue, &finish_num));
  }
  pool.AddTask(::NewCallback(&SaveWorker, &result_queue));

  std::string line;
  uint64 item_id;
  std::vector<std::string> tokens;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (base::StringToUint64(tokens[0], &item_id)) {
      id_queue.Put(item_id);
    }
  }
  id_queue.Close();

  pool.JoinAll();
}
