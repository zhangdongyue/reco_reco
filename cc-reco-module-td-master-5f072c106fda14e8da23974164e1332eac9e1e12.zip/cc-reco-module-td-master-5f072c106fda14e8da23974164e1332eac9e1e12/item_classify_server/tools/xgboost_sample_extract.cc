#include <iostream>
#include <string>
#include <cstdlib>
#include <unordered_map>
#include <fstream>
#include "reco/base/common/singleton.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "serving_base/mysql_util/db_conn_manager.h"

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_printf.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

#include "reco/module/item_classify_server/global_data/define.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/feature/item_feature_common.h"
#include "../feature/item_classify_feature.h"
#include "../feature/item_feature_common.h"

DEFINE_string(hbase_item_table, "tb_reco_item", "table name");
DEFINE_int32(extract_thread_num, 8, "extract thread num");
DEFINE_string(cate_file, "cates.txt", "cate list file");

void WriteSamples(thread::BlockingQueue<std::string>* result_queue) {
  std::string buf;
  while (!result_queue->Closed() || !result_queue->Empty()) {
    int status = result_queue->TimedTake(10, &buf);

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    if (status == -1) {
      LOG(WARNING) << "result queue has been closed by other thread, must be empty " << result_queue->Size();
      break;
    }
    CHECK_EQ(status, 1) << "fucking new status: " << status;
    std::cout << buf << "\n";
  }
}

void Extract(std::vector<uint64>* input_queue,
             thread::BlockingQueue<std::string>* result_queue,
             std::unordered_map<std::string, int>* cate_mapping,
             thread::BlockingVar<int>* finish_num) {
  std::vector<reco::item_classify::RawItem> raw_items;
  reco::HBaseGetItem hbase_pool_get_item(FLAGS_hbase_item_table, 0);

  LOG(WARNING) << "准备读取数据";
  reco::item_classify::ItemUtil::GetRawitem(&hbase_pool_get_item, *input_queue, &raw_items);

  reco::item_classify::ItemClassifyFeature item_classify_feature;
  reco::item_classify::FeatureExtractor feature_extractor;
  std::vector<double> fea;
  std::string buf;
  for (int i = 0; i < (int) raw_items.size(); i++) {
    buf.clear();
    const reco::item_classify::RawItem& raw_item = raw_items[i];
    const std::string& cate = raw_item.category;
    auto it = cate_mapping->find(cate);
    if (it == cate_mapping->end()) continue;
    int cate_idx = it->second;
    item_classify_feature.clear();
    buf.append(base::IntToString(cate_idx));
    feature_extractor.Extract(raw_item, &item_classify_feature);
    const auto& lda_topic = item_classify_feature.lda_topic_fea;
    fea.clear();
    fea.resize(reco::item_classify::kLDAMaxTopicNumber);
    for (size_t j = 0; j < lda_topic.size(); ++j) {
      fea[lda_topic[j].first] = lda_topic[j].second;
    }
    for (int k = 0; k < (int) fea.size(); ++k) {
      buf.append(base::StringPrintf(" %d:%f", k, fea[k]));
    }
    result_queue->Put(buf);
  }
  int n = finish_num->Take() + 1;
  if (n == FLAGS_extract_thread_num) {
    result_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "generate trainning samples");

  reco::item_classify::GlobalDataIns::instance().InitFeatureDicts();
  /*
   * 读取类别体系
   * */
  std::vector<std::string> cates;
  std::unordered_map<std::string, int> cate_mapping;
  base::file_util::ReadFileToLines(base::FilePath(FLAGS_cate_file), &cates);
  for (size_t j = 0; j < cates.size(); ++j) {
    cate_mapping.insert(std::make_pair(cates[j], j));
  }

  std::vector<std::vector<uint64>*> input_queue;
  thread::BlockingVar<int> finish_num;
  thread::BlockingQueue<std::string> result_queue_feature;

  thread::ThreadPool pool(FLAGS_extract_thread_num + 1);
  CHECK(finish_num.TryPut(0));

  std::string line;
  uint64 item_id;
  pool.AddTask(
          ::NewCallback(WriteSamples,&result_queue_feature)); // NOLINT
  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    input_queue.push_back(new std::vector<uint64>());
  }

  while (std::getline(std::cin, line)) {
    if (line.size() < 3) continue;
    base::StringToUint64(line, &item_id);
    input_queue[item_id % FLAGS_extract_thread_num]->push_back(item_id);
  }
  LOG(INFO) << "线程开始启动";
  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    pool.AddTask(
            ::NewCallback(Extract, input_queue[i], &result_queue_feature, &cate_mapping, &finish_num)); // NOLINT
  }
  pool.JoinAll();
}
