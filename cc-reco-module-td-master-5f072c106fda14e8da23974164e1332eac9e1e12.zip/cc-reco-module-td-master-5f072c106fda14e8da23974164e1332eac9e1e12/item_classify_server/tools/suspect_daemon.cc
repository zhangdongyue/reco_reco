#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "base/container/lru_cache.h"
#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");
DEFINE_string(start_time, "2016-09-18", "start time for reload cache");
DEFINE_int32(thread_num, 32, "thread num");
DEFINE_int32(cache_size, 100000, "cache size for reviewed element");

struct CateElement {
  std::string create_time;
  uint64 item_id;
  int item_type;
  std::string category;
  std::string source;
  std::string org_source;
  std::string title;
};

class Dao {
 public:
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option, int cache_size,
            const std::string& start_time);

  bool AddRecord(const CateElement& element);

  Dao();
  ~Dao() {}

  bool GetReviewedItem();
 protected:
  static const int kRetryTimes = 3;
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  base::LRUCache<uint64, int>* reviewed_item_cache_;
  std::string sql_str_;
};

Dao::Dao() {
  sql_str_ = "insert into tb_category_modify (create_time,item_id,item_type,org_category,org_source,source,";
  sql_str_ += "title) values";
}

void Dao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option,
               int cache_size,
               const std::string& start_time) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);

  reviewed_item_cache_ = new base::LRUCache<uint64, int>(cache_size, false);
  GetReviewedItem();
}

bool Dao::GetReviewedItem() {
  // get item_id record to cache
  const std::string& sql = base::StringPrintf("select item_id,op_status from tb_category_modify where create_time>\"%s\" && op_status>0",  // NOLINT
                                              FLAGS_start_time.c_str());
  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

      while (res->next()) {
        std::string item_id_str = res->getString("item_id");
        uint64 item_id = 0;
        if (!base::StringToUint64(item_id_str, &item_id)) {
          LOG(ERROR) << "error item_id: " << item_id_str;
          continue;
        }
        // NOTE(xielang): ask spider, status or reviewed_type to judge ?
        std::string status_str = res->getString("op_status");
        int status = 0;
        if (!base::StringToInt(status_str, &status)) {
          LOG(ERROR) << "error count : " << status_str;
        }

        if (status == 1 || status == 2) {
          reviewed_item_cache_->Add(item_id, status);
        }
      }
      break;
    } catch(sql::SQLException& e) {  // NOLINT
      LOG(ERROR) << "Exception: " << e.what();
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
    }
  }
  return true;
}


bool Dao::AddRecord(const CateElement& ele) {
  const std::string sql = base::StringPrintf("%s (\"%s\",\"%lu\",\"%d\",\"%s\",\"%s\",\"%s\",\"%s\");",
                                              sql_str_.c_str(),
                                              ele.create_time.c_str(),
                                              ele.item_id,
                                              ele.item_type,
                                              ele.category.c_str(),
                                              ele.org_source.c_str(),
                                              ele.source.c_str(),
                                              ele.title.c_str());
  int status = 0;
  if (reviewed_item_cache_->Get(ele.item_id, &status)) {
    LOG(INFO) << base::StringPrintf("item: %lu has been reviewed, status: %d", ele.item_id, status);
    return true;
  }

  for (int j = 0; j < kRetryTimes; ++j) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      stmt->executeUpdate(sql);
      return true;
    } catch (sql::SQLException& e) {  // NOLINT
      LOG(ERROR) << "Exception: " << e.what() << "\n" << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
    }
  }
  return false;
}

static bool g_stop = false;

void PushToDb(thread::BlockingQueue<CateElement>* db_queue) {
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  Dao* db_agent = new Dao();
  db_agent->Init(db_option, FLAGS_cache_size, FLAGS_start_time);

  CateElement ele;
  while (!(db_queue->Empty() && db_queue->Closed())) {
    int status = db_queue->TimedTake(100, &ele);

    if (status == -1) {
      LOG(ERROR) << "get cate element failed! status: " << status;
      break;
    }

    if (status == 0) {
      LOG_EVERY_N(ERROR, 1000) << "db queue empty";
      base::SleepForMilliseconds(2000);
      continue;
    }

    bool succ = db_agent->AddRecord(ele);
    if (!succ) {
      db_queue->Put(ele);
    }
  }
}

// TODO(xielang): 用队列 input
void GenerateElement(thread::BlockingQueue<CateElement>* db_queue) {
  std::string line;
  std::vector<std::string> flds;
  CateElement ele;
  while (!g_stop && std::getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 7) {
      LOG(ERROR) << "err: " << flds.size() << " " << line;
      continue;
    }

    ele.create_time = flds[0];
    if (!base::StringToUint64(flds[1], &ele.item_id)) {
      LOG(ERROR) << "err item id: " << flds[1] << " in " << line;
    }

    if (!base::StringToInt(flds[2], &ele.item_type)) {
      LOG(ERROR) << "err item type: " << flds[2] << " in " << line;
    }

    ele.category = flds[3];
    ele.org_source = flds[4];
    ele.source = flds[5];
    ele.title = flds[6];
  }
  LOG(INFO) << "finish reading!";
  db_queue->Close();
}

void GenerateFromKafka(thread::BlockingQueue<CateElement>* db_queue) {
  std::string line;
  std::vector<std::string> flds;

  CateElement ele;
  while (!g_stop && std::getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 7) {
      LOG(ERROR) << "err: " << flds.size() << " " << line;
      continue;
    }

    ele.create_time = flds[0];
    if (!base::StringToUint64(flds[1], &ele.item_id)) {
      LOG(ERROR) << "err item id: " << flds[1] << " in " << line;
    }

    if (!base::StringToInt(flds[2], &ele.item_type)) {
      LOG(ERROR) << "err item type: " << flds[2] << " in " << line;
    }

    ele.category = flds[3];
    ele.org_source = flds[4];
    ele.source = flds[5];
    ele.title = flds[6];
  }
  LOG(INFO) << "finish reading!";
  db_queue->Close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "init app");
  thread::BlockingQueue<CateElement> db_queue;
  thread::ThreadPool pool(FLAGS_thread_num + 1);
  pool.AddTask(::NewCallback(GenerateElement, &db_queue));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(PushToDb, &db_queue));
  }

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();
  g_stop = true;
  pool.JoinAll();
}
