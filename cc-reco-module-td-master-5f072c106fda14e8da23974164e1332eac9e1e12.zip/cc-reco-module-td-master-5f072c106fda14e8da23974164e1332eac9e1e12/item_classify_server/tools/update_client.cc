#include <vector>
#include <string>

#include "reco/proto/item_classify.pb.h"
#include "base/strings/string_printf.h"
#include "net/rpc/rpc.h"
#include "base/time/timestamp.h"

DEFINE_string(classify_server_ip, "10.3.5.70", "ip of classify server");
DEFINE_int32(classify_server_port, 20004, "port for classify server");
DEFINE_string(user, "serving", "user of classify server's machine");
DEFINE_string(target_data_path, "/data/reco/classify_server/data", "target data path");
DEFINE_string(source_data_path, "./data", "source data path");
DEFINE_bool(need_scp, false, "if false, only send reload request");

DEFINE_int32(reload_type, 0, "if false, only send reload request");

void ReloadModel() {
  // step 1: send file to classify server
  int retry = 3;
  if (FLAGS_need_scp) {
    std::string scp_cmd = base::StringPrintf("scp %s/* %s@%s:%s",
                                             FLAGS_source_data_path.c_str(),
                                             FLAGS_user.c_str(),
                                             FLAGS_classify_server_ip.c_str(),
                                             FLAGS_target_data_path.c_str());
    while (retry-- > 0) {
      int ret = system(scp_cmd.c_str());
      if (ret != 0) {
        LOG(ERROR) << "scp send file fail, cmd is: " << scp_cmd;
        continue;
      }
      break;
    }

    if (retry < 0) {
      LOG(ERROR) << "failed to update model, because of scp failed for fixed retry times" << scp_cmd;
      return;
    }
  }

  reco::item_classify::ReloadClassifyModelRequest request;
  request.set_timestamp(base::GetTimestamp());
  reco::item_classify::ReloadClassifyModelResponse response;
  net::rpc::RpcClientChannel channel(FLAGS_classify_server_ip.c_str(), FLAGS_classify_server_port);
  CHECK(channel.Connect());
  reco::item_classify::ItemClassifyService::Stub stub(&channel);
  // step 2: send request
  retry = 3;
  while (retry-- > 0) {
    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(10000);
    stub.ReloadClassifyModel(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "reload model failed, retry";
      continue;
    }
    break;
  }

  if (retry < 0) {
    LOG(ERROR) << "failed to update model, failed for fixed retry times";
  }
}

void ReloadSourceDict() {
  reco::item_classify::ReloadSourceCategoryRequest request;
  request.set_timestamp(base::GetTimestamp());
  reco::item_classify::ReloadSourceCategoryResponse response;
  net::rpc::RpcClientChannel channel(FLAGS_classify_server_ip.c_str(), FLAGS_classify_server_port);
  CHECK(channel.Connect());
  reco::item_classify::ItemClassifyService::Stub stub(&channel);
  net::rpc::RpcClientController rpc;
  stub.ReloadSourceCategory(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "reload source dict failed";
  } else {
    LOG(INFO) << "reload source dict succ";
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "update client");
  if (FLAGS_reload_type == 0) {
    ReloadSourceDict();
  } else if (FLAGS_reload_type == 1) {
    ReloadModel();
  } else {
    LOG(ERROR) << "erro reload type: " << FLAGS_reload_type;
  }
  return 0;
}
