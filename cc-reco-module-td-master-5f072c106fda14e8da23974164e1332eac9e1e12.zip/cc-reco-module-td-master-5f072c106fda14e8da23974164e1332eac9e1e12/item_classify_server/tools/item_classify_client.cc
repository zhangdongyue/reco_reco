#include <iostream>
#include <fstream>
#include <unordered_map>
#include <math.h>
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc/rpc.h"

#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/module/item_classify_server/common/item_util.h"

DEFINE_string(item_classify_server_ip, "127.0.0.1", "sim item server ip");
DEFINE_int32(item_classify_server_port, 20004, "sim item server port");

DEFINE_string(result_file, "classify_result_file.txt", "the output file");
DEFINE_string(input, "",
              "input file for raw item ,seprated by tab, three fls, title,categories, only title is needed");  // NOLINT

DEFINE_int32(send_worker_num, 8, "thread num for send request");
DEFINE_int32(hbase_thread_num, 16, "thread num for send request");
// 0: source, 1: title
DEFINE_int32(content_fld, 3, "fld for content, set -1 for no content");
DEFINE_int32(tag_fld, 4, "fld for tags, set -1 for no tag");
DEFINE_int32(item_type_fld, 2, "fld for tags, set -1 for no tag");
DEFINE_int32(item_id_fld, 5, "fld for tags, set -1 for no tag");

DEFINE_string(hbase_item_table, "tb_reco_item", "h`ase table");

DEFINE_int32(debug_level, 0, "debug log info");
DEFINE_bool(mutli_lines, true, "using multi lines to show debug infos");
DEFINE_bool(show_level2_debug, false, "show level debug infos");
DEFINE_bool(show_method_stat, true, "show method score stat to detetmine threhold");
using reco::item_classify::ItemClassifyRequest;
using reco::RecoItem;

static void ConvertRecoItemToRequest(thread::BlockingQueue<uint64>* item_id_q,
                                     thread::BlockingQueue<std::pair<uint64, ItemClassifyRequest*> >* req_q) {
  reco::HBaseGetItem* hbase_get_item = new reco::HBaseGetItem(FLAGS_hbase_item_table);

  std::vector<uint64> item_ids;
  std::vector<reco::RecoItem> reco_items;
  uint64 item_id;
  int n = 0;
  while (!(item_id_q->Closed() && item_id_q->Empty())) {
    if (item_id_q->Empty()) {
      base::SleepForMilliseconds(100);
      continue;
    }

    if (!item_id_q->Take(&item_id)) break;

    item_ids.push_back(item_id);
  }
  reco_items.clear();
  hbase_get_item->GetRecoItems(item_ids, &reco_items);

  for (size_t i = 0; i < reco_items.size(); ++i) {
    reco::item_classify::ItemClassifyRequest* request = new reco::item_classify::ItemClassifyRequest();
    request->set_source(reco_items[i].source());
    request->set_title(reco_items[i].title());

    request->set_item_type(reco_items[i].identity().type());

    request->set_content(reco_items[i].raw_item().content());
    request->set_item_id(reco_items[i].identity().item_id());

    // keyword and tag
    const reco::FeatureVector& keyword_fea = reco_items[i].keyword();
    for (int j = 0; j < keyword_fea.feature_size(); ++j) {
      request->add_keywords(keyword_fea.feature(j).literal());
    }

    const reco::FeatureVector& tag_fea = reco_items[i].tag();
    for (int j = 0; j < tag_fea.feature_size(); ++j) {
      request->add_tags(tag_fea.feature(j).literal());
    }
    const reco::FeatureVector& fea_topic = reco_items[i].topic();
    auto topic = request->mutable_topic();
    topic->set_norm(1.0);
    auto topic_feature = topic->mutable_feature();
    for (int j = 0; j < fea_topic.feature_size(); ++j) {
      auto it = topic_feature->Add();
      it->set_literal(fea_topic.feature(j).literal());
      it->set_weight(fea_topic.feature(j).weight());
      // LOG(INFO) << fea_topic.feature(j).literal()<<fea_topic.feature(j).weight();
    }
    const reco::FeatureVector& title_lda = reco_items[i].title_lda();
    auto topic_lda = request->mutable_title_lda_topic();

    topic_lda->set_norm(1.0);
    auto topic_lda_feature = topic_lda->mutable_feature();
    for (int j = 0; j < title_lda.feature_size(); ++j) {
      auto it = topic_lda_feature->Add();
      it->set_literal(title_lda.feature(j).literal());
      it->set_weight(title_lda.feature(j).weight());
      // LOG(INFO) << fea_topic.feature(j).literal()<<fea_topic.feature(j).weight();
    }
    /////
    // 添加 simhash
    for (int j = 0; j < reco_items[i].paragraph_simhash_size(); ++j) {
      request->add_para_simhash(reco_items[i].paragraph_simhash(j));
    }
    for (int j = 0; j < reco_items[i].image_size(); ++j) {
      request->add_picture_simhash(reco_items[i].image(j).simhash());
    }

    request->set_level(2);
    request->set_is_debug(FLAGS_debug_level > 0);
    request->set_debug_level(FLAGS_debug_level);
    // 如果有统计的请求，自动把 debug_level 定为 3
    if (FLAGS_show_method_stat) {
      request->set_debug_level(3);
    }

    req_q->Put(std::make_pair(reco_items[i].identity().item_id(), request));
    ++n;
  }
  item_ids.clear();
}

static void GenerateRequestFromHBase(std::string filename,
                                     thread::BlockingQueue<std::pair<uint64, ItemClassifyRequest*> >* req_q) {
  std::vector<uint64> item_ids;
  std::vector<std::string> tokens;
  std::vector<reco::RecoItem> reco_items;
  std::vector<bool> rets;

  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(filename), &lines)) << filename;
  LOG(INFO) << "finish reading " << lines.size();

  thread::BlockingQueue<uint64> item_id_q;
  thread::ThreadPool pool(FLAGS_hbase_thread_num);
  for (int i = 0; i < FLAGS_hbase_thread_num; ++i) {
    pool.AddTask(::NewCallback(&ConvertRecoItemToRequest, &item_id_q, req_q));
  }

  for (size_t i = 0; i < lines.size(); ++i) {
    tokens.clear();
    if (lines[i].size() < 2) {
      LOG(ERROR) << "erro line: " << lines[i];
      continue;
    }
    base::TrimWhitespaces(&lines[i]);
    base::SplitString(lines[i], "\t", &tokens);

    uint64 item_id = 0;
    if (!base::StringToUint64(tokens[0], &item_id)) continue;
    item_id_q.Put(item_id);
  }
  item_id_q.Close();
  LOG(INFO) << "finishing! remain id: " << item_id_q.Size();
  pool.JoinAll();
  LOG(INFO) << "finish generating all rquest! remain request: " << req_q->Size();
  req_q->Close();
}

static void GenerateRequestFromStream(std::istream* in,
                                      thread::BlockingQueue<std::pair<uint64, reco::item_classify::ItemClassifyRequest*>>* request_queue) {  // NOLINT
  std::string line;
  std::vector<std::string> tokens;
  std::vector<std::string> tokens2;

  std::vector<uint64> item_ids;
  while (std::getline(*in, line)) {
    tokens.clear();
    if (line.size() < 3) {
      LOG(ERROR) << "erro line: " << line;
      continue;
    }
    base::SplitString(line, "\t", &tokens);

    // only id
    if (tokens.size() < 3) continue;

    reco::item_classify::ItemClassifyRequest* request = new reco::item_classify::ItemClassifyRequest();
    request->set_source(tokens[0]);
    request->set_title(tokens[1]);
    if (FLAGS_item_type_fld > 1 && FLAGS_item_type_fld < (int) tokens.size()) {
      request->set_item_type(base::ParseIntOrDie(tokens[FLAGS_item_type_fld]));
    } else {
      request->set_item_type(0);
    }

    if (FLAGS_content_fld > 2 && FLAGS_content_fld < (int) tokens.size()) {
      request->set_content(tokens[FLAGS_content_fld]);
    }

    if (FLAGS_tag_fld > 2 && FLAGS_tag_fld < (int) tokens.size() && FLAGS_tag_fld != FLAGS_content_fld) {
      tokens2.clear();
      base::SplitString(tokens[FLAGS_tag_fld], "|", &tokens2);
      for (size_t i = 0; i < tokens2.size(); ++i) {
        request->add_tags(tokens2[i]);
      }
    }
    request->set_level(2);
    request->set_is_debug(FLAGS_debug_level > 0);
    request->set_debug_level(FLAGS_debug_level);
    uint64 item_id = 0;
    if (FLAGS_item_id_fld > -1 && FLAGS_item_id_fld < (int) tokens.size()) {
      item_id = base::ParseUint64OrDie(tokens[FLAGS_item_id_fld]);
    }
    request_queue->Put(std::make_pair(item_id, request));

    if (in->eof()) break;
  }
  LOG(INFO) << "finish reading";
  request_queue->Close();
}

static void SendWorker(
        thread::BlockingQueue<std::pair<uint64, reco::item_classify::ItemClassifyRequest*>>* request_queue,  // NOLINT
        thread::BlockingQueue<std::string>* result_queue,
        thread::BlockingQueue<std::pair<std::string, double> >* stat_queue,
        thread::BlockingVar<int>* sender_num) {
  net::rpc::RpcClientChannel channel(FLAGS_item_classify_server_ip.c_str(), FLAGS_item_classify_server_port);
  CHECK(channel.Connect());
  reco::item_classify::ItemClassifyService::Stub stub(&channel);
  reco::item_classify::ItemClassifyResponse response;
  std::pair<uint64, reco::item_classify::ItemClassifyRequest*> element;
  while (!(request_queue->Closed() && request_queue->Empty())) {
    if (request_queue->Empty()) {
      LOG_EVERY_N(INFO, 1000) << "send workersleep";
      base::SleepForSeconds(1);
      continue;
    }
    if (!request_queue->Take(&element)) break;
    net::rpc::RpcClientController rpc;
    rpc.SetTimeout(2000);
    const reco::item_classify::ItemClassifyRequest* request = element.second;
    stub.ClassifyItem(&rpc, request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "failed: " << request->item_id()
                 << "rpc.status()=" << rpc.status() << " response.success())=" << response.success();
      continue;
    }

    std::string category = "";

    for (int i = 0; i < response.category_size(); ++i) {
      if (i > 0) category += ",";
      category += response.category(i);
    }
    // CHECK_EQ(response.CategorySize(), response.score_size());
    // float score = 0;
    std::string source = request->source();
    if (source.empty()) {
      source = "source";
    }
    if (category.empty()) {
      category = "None";
    }

    std::string multi_classify_result = "";
    std::string output_category = "";
    double score;
    for (int i = 0; i < (int) response.category_candidates_size(); i++) {
      output_category = response.category_candidates(i);
      output_category = base::StringReplace(output_category, "\t", ",", true);
      multi_classify_result.append(output_category);
      multi_classify_result.append("[");
      multi_classify_result.append(base::DoubleToString((float) response.score(i)));
      multi_classify_result.append("]");
    }
    for (int i = 0; i < (int) response.tag_candidates_size() && i <= 1; i++) {
      output_category = response.tag_candidates(i);
      output_category = base::StringReplace(output_category, "\t", ",", true);
      score = response.tag_score(i);
      if (score < response.tag_score(0) * 0.8) continue;
      multi_classify_result.append("tag" + output_category);
      multi_classify_result.append("[");
      multi_classify_result.append(base::DoubleToString(score));
      multi_classify_result.append("]");
    }
    for (int i = 0; i < (int) response.post_tag_candidates_size() && i <= 1; i++) {
      output_category = response.post_tag_candidates(i);
      output_category = base::StringReplace(output_category, "\t", ",", true);
      score = response.post_tag_score(i);
      if (score < response.post_tag_score(0) * 0.8) continue;
      multi_classify_result.append("posttag" + output_category);
      multi_classify_result.append("[");
      multi_classify_result.append(base::DoubleToString(score));
      multi_classify_result.append("]");
    }
    std::string debug_info_str;
    // 特征 debug 信息
    debug_info_str.append("基础特征:{\n");
    for (int j = 0; j < response.debug_info().feature_info_size(); ++j) {
      debug_info_str.append("  ");
      debug_info_str.append(
              reco::item_classify::ItemUtil::Featureinfo2Text(response.debug_info().feature_info(j)));  //NOLINT
      debug_info_str.append("\n");
    }
    debug_info_str.append("}\n\n");
    // 策略一级分数
    debug_info_str.append("一级分类:{\n");
    for (int j = 0; j < response.debug_info().classify_info_size(); ++j) {
      if (response.debug_info().classify_info(j).cate_name_size() == 0) continue;
      debug_info_str.append("  ");
      debug_info_str.append(
              reco::item_classify::ItemUtil::Classifyinfo2Text(response.debug_info().classify_info(j), 1,
                                                               false));  //NOLINT
      debug_info_str.append("\n");
    }
    debug_info_str.append("}\n\n");
    // 策略二级分数
    if (FLAGS_show_level2_debug) {
      debug_info_str.append("二级分类:{\n");
      for (int j = 0; j < response.debug_info().classify_info_size(); ++j) {
        if (response.debug_info().classify_info(j).cate_name_size() == 0) continue;
        debug_info_str.append("  ");
        debug_info_str.append(
                reco::item_classify::ItemUtil::Classifyinfo2Text(response.debug_info().classify_info(j), 2,
                                                                 false));  //NOLINT
        debug_info_str.append("\n");
      }
      debug_info_str.append("}\n\n");
    }
    // 分数统计信息
    for (int j = 0; j < response.debug_info().classify_info_size(); ++j) {
      if (response.debug_info().classify_info(j).cate_name_size() == 0) continue;
      const std::string& method_name = response.debug_info().classify_info(j).method_name();
      for (int k = 0; k < response.debug_info().classify_info(j).cate_name_size(); ++k) {
        const std::string& cate_name = response.debug_info().classify_info(j).cate_name(k);
        if (category.find(cate_name) != 0) continue;
        double score = response.debug_info().classify_info(j).cate_score(k);
        stat_queue->Put(std::make_pair(method_name, score));
        stat_queue->Put(std::make_pair(method_name + "|" + cate_name, score));
        stat_queue->Put(std::make_pair(cate_name, score));
      }
    }

    // 策略细节
    if (FLAGS_debug_level >= 4) {
      debug_info_str.append("分类策略细节:{\n");
      for (int j = 0; j < response.debug_info().classify_info_size(); ++j) {
        debug_info_str.append("  ");
        debug_info_str.append(
                reco::item_classify::ItemUtil::Classifyinfo2Text(response.debug_info().classify_info(j), 2,
                                                                 true));  //NOLINT
        debug_info_str.append("\n");
      }
      debug_info_str.append("}\n\n");
    }
    if (response.has_debug_str()) {
      debug_info_str.append(response.debug_str());
    }
    if (!FLAGS_mutli_lines) {
      debug_info_str = base::StringReplace(debug_info_str,
                                           "\n", " ", true);
    }

    if (request->has_is_debug() && request->is_debug()) {
      result_queue->Put(base::StringPrintf("%s\t%s\t%s\t%s\t%lu\n%s",
                                           request->title().c_str(),
                                           request->source().c_str(),
                                           category.c_str(),
                                           multi_classify_result.c_str(),
                                           element.first,
                                           debug_info_str.c_str()));
    } else {
      result_queue->Put(base::StringPrintf("%s\t%s\t%s\t%s\t%lu",
                                           request->title().c_str(),
                                           request->source().c_str(),
                                           category.c_str(),
                                           multi_classify_result.c_str(),
                                           element.first));
    }

    delete request;
  }

  int n = sender_num->Take() + 1;
  if (n == FLAGS_send_worker_num) {
    result_queue->Close();
    stat_queue->Close();
  }
  CHECK(sender_num->TryPut(n));
}

static void SaveResult(std::string filename, thread::BlockingQueue<std::string>* result_queue) {
  std::ofstream fout(filename);
  std::string buf;
  while (!(result_queue->Closed() && result_queue->Empty())) {
    if (result_queue->Empty()) {
      LOG(INFO) << "save result thread sleep";
      base::SleepForSeconds(5);
      continue;
    }

    if (!result_queue->Take(&buf)) break;
    fout << buf << std::endl;
  }
}

static void SaveStatResult(std::string filename, thread::BlockingQueue<std::pair<std::string, double> >* stat_queue) {
  std::unordered_map<std::string, std::vector<double>*> score_stat;
  std::pair<std::string, double> ele;
  while (!(stat_queue->Empty() && stat_queue->Closed())) {
    if (stat_queue->Empty()) {
      base::SleepForSeconds(5);
      continue;
    }
    if (!stat_queue->Take(&ele)) break;
    const std::string& key = ele.first;
    double& score = ele.second;
    auto it = score_stat.find(key);
    if (it == score_stat.end()) {
      score_stat.insert(std::make_pair(key, new std::vector<double>(100)));
      it = score_stat.find(key);
    }
    int idx = static_cast<int>(score * 100);
    if (idx >= 100) idx = 99;
    it->second->at(idx) += 1.0;
  }
  std::ofstream fout(filename);
  for (auto it = score_stat.begin(); it != score_stat.end(); ++it) {
    double avg_value = 0.0;
    double std_value = 0.0;
    int all_cnt = 0;
    for (size_t i = 0; i < it->second->size(); ++i) {
      all_cnt += it->second->at(i);
      avg_value += it->second->at(i) * i / 100.0;
    }
    avg_value = avg_value / all_cnt;
    for (size_t i = 0; i < it->second->size(); ++i) {
      std_value += it->second->at(i) * (i / 100.0 - avg_value) * (i / 100.0 - avg_value);
    }
    std_value = sqrt(std_value / all_cnt);
    fout << it->first << "\t" << avg_value - std_value << "\t" << avg_value - 2 * std_value << "\t" << avg_value << "\t"
         << std_value << "\n"; // NOLINT
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "sim item client");
  thread::ThreadPool pool(FLAGS_send_worker_num + 2);

  thread::BlockingQueue<std::pair<uint64, reco::item_classify::ItemClassifyRequest*> > request_queue;
  thread::BlockingQueue<std::string> result_queue;
  thread::BlockingQueue<std::pair<std::string, double> > stat_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));

  if (FLAGS_item_id_fld == 0) {
    pool.AddTask(::NewCallback(&GenerateRequestFromHBase, FLAGS_input, &request_queue));
  } else {
    std::istream* in = &std::cin;
    if (FLAGS_input.size() > 0) {
      in = new std::ifstream(FLAGS_input.c_str());
    }
    pool.AddTask(::NewCallback(&GenerateRequestFromStream, in, &request_queue));
  }

  for (int i = 0; i < FLAGS_send_worker_num; ++i) {
    pool.AddTask(::NewCallback(&SendWorker, &request_queue, &result_queue, &stat_queue, &finish_num));
  }

  pool.AddTask(::NewCallback(&SaveResult, FLAGS_result_file, &result_queue));
  pool.AddTask(::NewCallback(&SaveStatResult, FLAGS_result_file + ".stat", &stat_queue));

  pool.JoinAll();
  return 0;
}
