/*
 * function: 生成 gbdt 训练集、测试集
 * author: bojing.lj@alibaba-inc.com
 */

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <map>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "nlp/common/nlp_util.h"

// FLAG 定义
// category_dict: 原 item category 词典路径
// cate_map_dict: 做了 id 映射之后的 item category 一级类别词典
// train_set: 训练集存储路径
// valid_set: 校验集存储路径
// train_set_rate: 训练集占总数据集比例
// neg_pos_rate: 负样本/正样本 比例
// pos_cate_id: 正样本的 item id
// pos_max_num: 正样本最大个数，大于该值的正样本将会被过滤
DEFINE_string(category_dict, "lijing_data/item_category", "item category dict path");
DEFINE_string(cate_map_dict, "lijing_data/item_cate_map", "item category map dict path");
DEFINE_string(train_set, "lijing_data/train_set", "train set");
DEFINE_string(valid_set, "lijing_data/valid_set", "valid set");
DEFINE_double(train_set_rate, 0.7, "train set rate");
DEFINE_double(neg_pos_rate, 2, "neg/pos rate");
DEFINE_int32(pos_cate_id, 1, "positive cate id");
DEFINE_int32(pos_max_num, 100000, "max positive samples number");

// 函数功能: 根据 item category 词典，生成一级类别映射表
void GenCategoryDict(const std::map<std::string, int>& cate_map) {
  std::fstream fin;
  fin.open(FLAGS_category_dict, std::fstream::in);
  if (!fin.is_open()) {
    std::cerr << "open item category dict error!" << std::endl;
    exit(1);
  }
  std::string line;
  std::vector<std::string> tokens;
  int count = 0;
  while (getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (cate_map.find(tokens[0]) != cate_map.end()) continue;
    cate_map[tokens[0]] = count;
    count += 1;
  }
  fin.close();
}

// 函数功能: 保存 item category 一级映射词典
void SaveCateDict(const std::map<std::string, int>& cate_map) {
  std::fstream fout;
  fout.open(FLAGS_cate_map_dict, std::fstream::out);
  if (!fout.is_open()) {
    std::cerr << "open item cate map file error!" << std::endl;
    exit(1);
  }
  std::map<std::string, int>::iterator it = cate_map.begin();
  for (; it != cate_map.end(); it++) {
    fout << it->first << "\t" << it->second << std::endl;
  }
  fout.close();
}

void GenTrainValidSet(const std::map<std::string, int>& cate_map) {
  // 正例负例
  std::vector<std::string> pos_vec;
  std::vector<std::string> neg_vec;

  // 读取数据，输入数据的格式为 item_id , cate_id,features
  int cur_cate_id;
  std::string line;
  std::vector<std::string> tokens;
  while (getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() != 3 || tokens[2] == "" || tokens[1] == "") {
      // std::cerr << "invalid line" << std::cerr;
      continue;
    }
    base::StringToInt(tokens[1], &cur_cate_id);
    nlp::util::NormalizeLineInPlaceS(&tokens[2]);
    if (cur_cate_id == FLAGS_pos_cate_id) {
      if (static_cast<int32>(pos_vec.size()) < FLAGS_pos_max_num) {
        pos_vec.push_back("1 " + tokens[2]);
      }
    } else {
      if (static_cast<int32>(neg_vec.size()) < FLAGS_pos_max_num * FLAGS_neg_pos_rate) {
        neg_vec.push_back("0 " + tokens[2]);
      }
    }
    // if (int32(pos_vec.size()) > FLAGS_pos_max_num &&
    //          int32(neg_vec.size()) < FLAGS_pos_max_num * FLAGS_neg_pos_rate)
    //    break;
  }
  std::cout << "pos num:" << pos_vec.size() << "\t"
            << "neg num:" << pos_vec.size() * FLAGS_neg_pos_rate << std::endl;
  // 随机打散
  std::random_shuffle(pos_vec.begin(), pos_vec.end());
  std::random_shuffle(neg_vec.begin(), neg_vec.end());

  // 生成训练集、校验集
  std::vector<std::string> train_vec;
  std::vector<std::string> valid_vec;
  int pos_train_count = static_cast<int>(pos_vec.size()) * FLAGS_train_set_rate;
  for (int i = 0; i < static_cast<int>(pos_vec.size()); i++) {
    if (i < pos_train_count) {
      train_vec.push_back(pos_vec[i]);
    } else {
      valid_vec.push_back(pos_vec[i]);
    }
  }
  int neg_train_count = static_cast<int>(pos_vec.size()) * FLAGS_neg_pos_rate * FLAGS_train_set_rate;
  for (int i = 0; i < static_cast<int>(neg_vec.size()); i++) {
    if (i >= pos_vec.size() * FLAGS_neg_pos_rate) break;
    if (i < neg_train_count) {
      train_vec.push_back(neg_vec[i]);
    } else {
      valid_vec.push_back(neg_vec[i]);
    }
  }
  // 随机打散
  std::random_shuffle(train_vec.begin(), train_vec.end());
  std::random_shuffle(valid_vec.begin(), valid_vec.end());

  // 写文件
  std::fstream fout_train;
  fout_train.open(FLAGS_train_set, std::fstream::out);
  if (!fout_train.is_open()) {
    std::cerr << "open file fout_train error!" << std::endl;
    exit(1);
  }
  for (int i = 0; i < static_cast<int>(train_vec.size()); i++) {
    fout_train << train_vec[i] << std::endl;
  }
  std::fstream fout_valid;
  fout_valid.open(FLAGS_valid_set, std::fstream::out);
  if (!fout_valid.is_open()) {
    std::cerr << "open file fout_valid error!" << std::endl;
    exit(1);
  }
  for (int i = 0; i < static_cast<int>(valid_vec.size()); i++) {
    fout_valid << valid_vec[i] << std::endl;
  }
  fout_train.close();
  fout_valid.close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "process reco_item");
  std::map<std::string, int> cate_map;
  GenCategoryDict(cate_map);
  SaveCateDict(cate_map);
  GenTrainValidSet(cate_map);
  return 0;
}
