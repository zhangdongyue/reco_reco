#include <iostream>
#include <string>
#include <cstdlib>
#include <unordered_map>
#include <fstream>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_printf.h"

#include "reco/item_classify_server/feature/feature_extractor.h"
// NOTE(xielang): output format category \t source \t title \t features
DEFINE_string(dict_dir, "./dict", "ngram feature dir");
DEFINE_int32(source_fld, 0, "source fld");
DEFINE_int32(text_fld, 1, "text fld");
DEFINE_int32(category_fld, 2, "cateogry fld");

DEFINE_int32(keyword_fld, -1, "keyword fld, if words, mask text fea");

// wordvec and topic 单独程序获取
DEFINE_int32(feature_type, 1, "1:titlengram, 2:source*title_ngram, 3:keyword, 4:kw_unigram, 5:kw_bigram");
DEFINE_int32(level, 1, "1 level1, 2 level2");
DEFINE_int32(extract_thread_num, 8, "extract thread num");

DEFINE_int32(run_type, 0, "0 means extract feature, 1 means generate sign to term");

void ExtractKeyword(thread::BlockingQueue<std::string>* input_queue,
                    thread::BlockingQueue<std::string>* result_queue,
                    thread::BlockingVar<int>* finish_num) {
  CHECK_GT(FLAGS_source_fld, -1);
  CHECK_GT(FLAGS_keyword_fld, -1);
  CHECK_GT(FLAGS_text_fld, -1);
  CHECK_GT(FLAGS_category_fld, -1);

  std::vector<std::string> tokens;
  std::vector<std::string> keywords;
  std::string buf;
  std::string category;

  std::unordered_map<uint64, std::string> sign_dict;

  while (!input_queue->Closed() || !input_queue->Empty()) {
    int status = input_queue->TimedTake(10, &buf);

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    if (status == -1) {
      LOG(WARNING) << "title queue has been closed by other thread, it must be empty " << input_queue->Size();
      break;
    }
    CHECK_EQ(status, 1) << "fucking new status: " << status;
    tokens.clear();
    base::SplitString(buf, "\t", &tokens);
    if ((int)tokens.size() <= FLAGS_source_fld || (int)tokens.size() <= FLAGS_text_fld ||
        (int)tokens.size() <= FLAGS_category_fld || (int)tokens.size() <= FLAGS_keyword_fld) {
      LOG(ERROR) << "erro format line: " << buf;
      continue;
    }

    category = tokens[FLAGS_category_fld];
    if (FLAGS_level == 1) {
      size_t pos = category.find(",");
      if (pos != std::string::npos) category = category.substr(0, pos);
    }

    keywords.clear();
    base::SplitString(tokens[FLAGS_keyword_fld], "|", &keywords);

    std::unordered_map<uint64, std::string> fea_dict;

    for (int i = 0; i < (int)keywords.size(); ++i) {
      uint64 sign = base::CalcTermSign(keywords[i].c_str(), keywords[i].size());
      if (FLAGS_feature_type != 5) {
        auto it_pair = fea_dict.insert(std::make_pair(sign, keywords[i]));
        if (!it_pair.second) {
          LOG(ERROR) << "dup keyword:" << keywords[i];
          continue;
        }
      }

      std::string bigram = "";
      for (int j = i + 1; j < (int)keywords.size(); ++j) {
        if (FLAGS_feature_type == 4) break;
        if (keywords[i] < keywords[j]) {
          bigram = base::StringPrintf("%s\t%s", keywords[i].c_str(), keywords[j].c_str());
        } else {
          bigram = base::StringPrintf("%s\t%s", keywords[j].c_str(), keywords[i].c_str());
        }
        sign = base::CalcTermSign(bigram.c_str(), bigram.size());

        auto it_pair = fea_dict.insert(std::make_pair(sign, bigram));
        if (!it_pair.second) {
          LOG(ERROR) << "dup bigram:" << bigram;
          continue;
        }
      }
    }

    if (FLAGS_run_type == 0) {
      buf.clear();
      buf.append(category);
      buf.append("\t");
      buf.append(tokens[FLAGS_source_fld]);
      buf.append("\t");
      buf.append(tokens[FLAGS_text_fld]);
      buf.append("\t");
      buf.append(tokens[FLAGS_keyword_fld]);
      buf.append("\t");
      for (auto it = fea_dict.begin(); it != fea_dict.end(); ++it) {
        buf.append(base::StringPrintf("%lu:1 ", it->first));
      }
      result_queue->Put(buf);
    } else if (FLAGS_run_type == 1) {
      for (auto it = fea_dict.begin(); it != fea_dict.end(); ++it) {
        sign_dict.insert(std::make_pair(it->first, it->second));
      }
    }
  }

  if (FLAGS_run_type == 1) {
    for (auto it = sign_dict.begin(); it != sign_dict.end(); ++it) {
      result_queue->Put(base::StringPrintf("%lu\t%s", it->first, it->second.c_str()));
    }
  }
  int n = finish_num->Take() + 1;
  if (n == FLAGS_extract_thread_num) result_queue->Close();
  CHECK(finish_num->TryPut(n));
}

void Extract(thread::BlockingQueue<std::string>* input_queue,
             thread::BlockingQueue<std::string>* result_queue,
             thread::BlockingVar<int>* finish_num) {
  reco::item_classify::FeatureExtractor feature_extractor(1);
  reco::item_classify::ItemFeature item_fea;
  std::string norm_title;
  std::string normalized_source;

  std::set<uint64> feature_set;
  std::vector<std::pair<uint64, float>> instance;
  std::string buf;
  std::vector<std::string> tokens;
  std::ostringstream oss;

  std::string title = "";
  std::string source = "";
  std::string category = "";

  while (!input_queue->Closed() || !input_queue->Empty()) {
    int status = input_queue->TimedTake(10, &buf);

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    if (status == -1) {
      LOG(WARNING) << "title queue has been closed by other thread, it must be empty " << input_queue->Size();
      break;
    }
    CHECK_EQ(status, 1) << "fucking new status: " << status;
    tokens.clear();
    base::SplitString(buf, "\t", &tokens);

    if (FLAGS_text_fld > -1 && FLAGS_text_fld < (int)tokens.size()) {
      title = tokens[FLAGS_text_fld];
    }

    if (FLAGS_source_fld > -1 && FLAGS_source_fld < (int)tokens.size()) {
      source = tokens[FLAGS_source_fld];
    }

    if (FLAGS_category_fld > -1 && FLAGS_category_fld < (int)tokens.size()) {
      category = tokens[FLAGS_category_fld];
      if (FLAGS_level == 1) {
        size_t pos = category.find(",");
        if (pos != std::string::npos) category = category.substr(0, pos);
      }
    }

    if (title.empty()) continue;

    feature_extractor.renew();
    norm_title.clear();

    nlp::util::NormalizeLineCopy(title, &norm_title);
    nlp::util::NormalizeLineCopy(source, &normalized_source);
    item_fea.clear();
    std::vector<std::string> tags;
    feature_extractor.ExtractFeature(normalized_source, norm_title, tags, "", 1, false, 0, NULL, &item_fea);
    if (item_fea.ngram_features.empty()) {
      LOG(WARNING) << "empty feature for title: " << title << " source:" << source;
      continue;
    }
    // genearate result
    //
    if (FLAGS_run_type == 0) {
      oss.str("");
      feature_set.clear();
      instance.clear();

      if ((FLAGS_feature_type & 0x01) > 0) {
        instance.insert(instance.end(), item_fea.ngram_features.begin(), item_fea.ngram_features.end());
      }

      if ((FLAGS_feature_type & 0x02) > 0) {
        instance.insert(instance.end(),
                        item_fea.source_ngram_features.begin(),
                        item_fea.source_ngram_features.end());
      }

      if ((FLAGS_feature_type & 0x8) > 0) {
        instance.clear();
        for (size_t i = 0; i < item_fea.pzd.size(); ++i) {
          instance.push_back(std::make_pair(item_fea.pzd[i].aspect, item_fea.pzd[i].value));
        }
      }

      std::sort(instance.begin(), instance.end(), std::less<std::pair<uint64, float >>());

      for (int i = 0; i < (int)instance.size(); ++i) {
        if (i > 0) oss << " ";
        oss << instance[i].first << ":" << instance[i].second;
      }
      if (source.empty()) {
        source = "UC头条";
      }
      result_queue->Put(base::StringPrintf("%s\t%s\t%s\t%s", category.c_str(), source.c_str(), title.c_str(),
                                           oss.str().c_str()));
    } else if (FLAGS_run_type == 1) {
      // generate sign to term dict
      if ((FLAGS_feature_type & 0x01) > 0) {
        for (int i = 0; i < (int)item_fea.ngrams.size(); ++i) {
          result_queue->Put(base::StringPrintf("%lu\t%s",
                                               base::CalcTermSign(item_fea.ngrams[i].c_str(),
                                                                  item_fea.ngrams[i].size()),
                                               item_fea.ngrams[i].c_str()));
        }
      }
      if ((FLAGS_feature_type & 0x02) > 0) {
        for (int i = 0; i < (int)item_fea.source_ngrams.size(); ++i) {
          result_queue->Put(base::StringPrintf("%lu\t%s",
                                               base::CalcTermSign(item_fea.source_ngrams[i].c_str(),
                                                                  item_fea.source_ngrams[i].size()),
                                               item_fea.source_ngrams[i].c_str()));
        }
      }
    }
  }

  int n = finish_num->Take() + 1;
  if (n == FLAGS_extract_thread_num) result_queue->Close();
  CHECK(finish_num->TryPut(n));
}

void Write(thread::BlockingQueue<std::string>* result_queue) {
  std::string buf;
  while (!result_queue->Closed() || !result_queue->Empty()) {
    int status = result_queue->TimedTake(10, &buf);

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    if (status == -1) {
      LOG(WARNING) << "result queue has been closed by other thread, must be empty " << result_queue->Size();
      break;
    }
    CHECK_EQ(status, 1) << "fucking new status: " << status;
    std::cout << buf << "\n";
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "prepare pos samples");

  if (FLAGS_keyword_fld == -1) {
    CHECK(reco::item_classify::FeatureExtractor::Initial(base::FilePath(FLAGS_dict_dir), 1));
  }

  thread::BlockingQueue<std::string> input_queue;
  thread::BlockingVar<int> finish_num;
  thread::BlockingQueue<std::string> result_queue;
  thread::ThreadPool pool(FLAGS_extract_thread_num + 1);
  pool.AddTask(::NewCallback(Write, &result_queue));
  CHECK(finish_num.TryPut(0));

  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    if (FLAGS_keyword_fld > -1) {
      pool.AddTask(::NewCallback(ExtractKeyword, &input_queue, &result_queue, &finish_num));
    } else {
      pool.AddTask(::NewCallback(Extract, &input_queue, &result_queue, &finish_num));
    }
  }

  std::string line;
  while (std::getline(std::cin, line)) {
    if (line.size() < 3) continue;
    input_queue.Put(line);
  }
  input_queue.Close();
  pool.JoinAll();
}
