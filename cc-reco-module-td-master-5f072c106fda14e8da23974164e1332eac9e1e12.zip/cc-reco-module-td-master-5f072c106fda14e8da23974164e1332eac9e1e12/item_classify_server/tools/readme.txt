1 dump_raw_item.cc, 从raw item队列获取数据 dump出来，当时抓取rss数据会进索引，目前用不着了，不走sim，直接分类

2 item_classify_client.cc, 给item classify server 发请求，测试 item classify server用

3 feature_demo 是读词表抽特征， feature_hist 是重新生成特征
