#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <fstream>

#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "base/common/scoped_ptr.h"
#include "nlp/common/nlp_util.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

#include "serving_base/mysql_util/db_conn_manager.h"

DEFINE_string(source_to_category_file, "source_to_category.txt", "source category input");
DEFINE_string(all_category_file, "all_category.txt", "all category file");

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");
DEFINE_bool(need_import_all_category, false, "if set import all category first");
static int kRetryTimes = 3;

void ImportAllCategory(const base::FilePath& all_category_file,
                       const serving_base::mysql_util::DbConnManager::Option &db_option) {
  // init db manager
  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(db_option);  // NOLINT
  CHECK_NOTNULL(db_manager);
  db_manager->Connect();
  sql::Connection* db_connection = db_manager->conn();
  CHECK_NOTNULL(db_connection);

  std::ifstream fin(all_category_file.value());
  std::string line;
  std::vector<std::string> tokens;
  // load all category

  while (std::getline(fin, line)) {
    if (line.empty()) continue;
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 2u || tokens.size() > 3u) {
      LOG(ERROR) << "only level1 and level2 supoorted: " << line;
      continue;
    }

    int can_auto = base::ParseIntOrDie(tokens.back());
    nlp::util::NormalizeLineInPlaceS(&tokens[0]);
    std::string category = tokens.front();
    if (tokens.size() == 3u) {
      nlp::util::NormalizeLineInPlaceS(&tokens[1]);
      category += "\t";
      category += tokens[1];
    }
    // insert to db
    std::string sql = base::StringPrintf("insert into tb_seed_category_word (word, can_auto) values (\"%s\",%d)",  // NOLINT
                                          category.c_str(), can_auto);
    for (int i = 0; i < kRetryTimes; ++i) {
      try {
        scoped_ptr<sql::Statement> stmt(db_connection->createStatement());
        stmt->executeUpdate(sql);
        break;
      } catch(sql::SQLException& e) {  // NOLINT
        LOG(ERROR) << "Exception: " << e.what() << " sql: " << sql;
        db_manager->ConnectUntilSuccess();
        db_connection = db_manager->conn();
        CHECK_NOTNULL(db_connection);
        LOG(ERROR) << "Reconnectd to MySQL.";
      }
    }
  }
}

void LoadSeedFromDb(const serving_base::mysql_util::DbConnManager::Option &db_option,
                    std::unordered_map<std::string, uint64>* seed_to_id) {
  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(db_option);  // NOLINT
  CHECK_NOTNULL(db_manager);
  db_manager->Connect();
  sql::Connection* db_connection = db_manager->conn();
  CHECK_NOTNULL(db_connection);

  std::string sql = "select name,id from tb_seed;";
  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

      while (res->next()) {
        uint64 id = 0;
        std::string id_str = res->getString("id");
        std::string name = res->getString("name");
        if (!base::StringToUint64(id_str, &id)) {
          LOG(ERROR) << "error source id: " << id_str;
          continue;
        }
        nlp::util::NormalizeLineInPlaceS(&name);
        auto it_pair = seed_to_id->insert(std::make_pair(name, id));
      }
      break;
    } catch(sql::SQLException& e) {  // NOLINT
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager->ConnectUntilSuccess();
      db_connection = db_manager->conn();
      CHECK_NOTNULL(db_connection);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

void LoadCategoryFromDb(const serving_base::mysql_util::DbConnManager::Option &db_option,
                        std::unordered_map<std::string, uint64>* category_to_id) {
  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(db_option);  // NOLINT
  CHECK_NOTNULL(db_manager);
  db_manager->Connect();
  sql::Connection* db_connection = db_manager->conn();
  CHECK_NOTNULL(db_connection);

  std::string sql = "select word,id from tb_seed_category_word;";
  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

      while (res->next()) {
        uint64 id = 0;
        std::string id_str = res->getString("id");
        std::string word = res->getString("word");
        if (!base::StringToUint64(id_str, &id)) {
          LOG(ERROR) << "error source id: " << id_str;
          continue;
        }

        auto it_pair = category_to_id->insert(std::make_pair(word, id));
        CHECK(it_pair.second);
      }
      break;
    } catch(sql::SQLException& e) {  // NOLINT
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager->ConnectUntilSuccess();
      db_connection = db_manager->conn();
      CHECK_NOTNULL(db_connection);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
}

inline int process_category_type(std::string* category) {
  int type = 0;
  size_t pos = category->find(":");
  if (pos != std::string::npos) {
    type = 1;
    category->erase(pos);
  }

  nlp::util::NormalizeLineInPlaceS(category);
  return type;
}

void ImportSourceCategory(const base::FilePath& source_category_file,
                          const serving_base::mysql_util::DbConnManager::Option &db_option) {
  // init db manager
  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(db_option);  // NOLINT
  CHECK_NOTNULL(db_manager);
  db_manager->Connect();
  sql::Connection* db_connection = db_manager->conn();
  CHECK_NOTNULL(db_connection);

  std::unordered_map<std::string, uint64> category_to_id;
  std::unordered_map<std::string, uint64> seed_to_id;
  // load category and seed from db
  LoadCategoryFromDb(db_option, &category_to_id);
  LoadSeedFromDb(db_option, &seed_to_id);

  std::string line;
  std::vector<std::string> tokens;
  // 原先文件读写设计上造成写 level 的时候对是否写死并不清楚，先全部存下来再写数据裤
  std::unordered_map<std::string, std::map<std::string, int>> source_to_category;
  std::ifstream fin(source_category_file.value());
  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    CHECK_GT(tokens.size(), 1u) << line;
    CHECK_GT(4u, tokens.size());

    if (tokens.size() < 2 || tokens.size() > 3) {
      LOG(ERROR) << "erro line: " << line;
      continue;
    }

    nlp::util::NormalizeLineInPlaceS(&tokens[0]);
    auto it_pair = source_to_category.insert(std::make_pair(tokens[0], std::map<std::string, int>()));
    int type = process_category_type(&tokens[1]);
    std::string category = tokens[1];

    // insert level1 record
    auto level1_it_pair = it_pair.first->second.insert(std::make_pair(category, type));
    if (!level1_it_pair.second) {
      if (type > level1_it_pair.first->second) {
        level1_it_pair.first->second = type;
      }
    }

    if (tokens.size() == 3) {
      type = process_category_type(&tokens[2]);
      category += "\t";
      category += tokens[2];

      auto level2_it_pair = it_pair.first->second.insert(std::make_pair(category, type));
      if (!level2_it_pair.second) {
        LOG(ERROR) << "dup key: " << category << " source: " << tokens[0];
        if (type > level2_it_pair.first->second) level2_it_pair.first->second = type;
      }
    }
  }

  for (auto it = source_to_category.begin(); it != source_to_category.end(); ++it) {
    auto it_seed = seed_to_id.find(it->first);
    if (it_seed == seed_to_id.end()) {
      LOG(ERROR) << "cannot find seed in table: " << it->first;
      continue;
    }
    for (auto it2 = it->second.begin(); it2 != it->second.end(); ++it2) {
      auto it_category = category_to_id.find(it2->first);
      if (it_category == category_to_id.end()) {
        LOG(ERROR) << "erro category:" << it2->first;
        continue;
      }
      CHECK(it_category != category_to_id.end());

      std::string sql = base::StringPrintf("insert into tb_seed_category (category_word_id,is_force,seed_id) values (%lu,%d,%lu)",  // NOLINT
                                          it_category->second, it2->second, it_seed->second);
      for (int i = 0; i < kRetryTimes; ++i) {
        try {
          scoped_ptr<sql::Statement> stmt(db_connection->createStatement());
          stmt->executeUpdate(sql);
          break;
        } catch(sql::SQLException& e) {  // NOLINT
          LOG(ERROR) << "Exception: " << e.what();
          db_manager->ConnectUntilSuccess();
          db_connection = db_manager->conn();
          CHECK_NOTNULL(db_connection);
          LOG(ERROR) << "Reconnectd to MySQL.";
        }
      }
    }
  }
}

int main(int argc, char ** argv) {
  base::InitApp(&argc, &argv, "import source category dict to db");
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;

  if (FLAGS_need_import_all_category) ImportAllCategory(base::FilePath(FLAGS_all_category_file), db_option);
  ImportSourceCategory(base::FilePath(FLAGS_source_to_category_file), db_option);
  return 0;
}
