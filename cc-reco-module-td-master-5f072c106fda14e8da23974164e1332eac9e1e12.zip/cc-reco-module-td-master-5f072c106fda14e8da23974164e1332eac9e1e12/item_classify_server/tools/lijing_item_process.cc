/*
 * function: 使用mapreduce进行item查询，提取出title+content进行切词，提取出topic+wordvec字段
 * author: bojing.lj@alibaba-inc.com
 */

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <utility>
#include <map>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "reco/item_service/hbase_get_item.h"
#include "reco/item_service/hbase_pool_get_item.h"
#include "reco/proto/item.pb.h"
#include "nlp/segment/segmenter.h"
#include "nlp/common/nlp_util.h"
#include "nlp/common/rune_type.h"
#include "nlp/word2vec/word2vec.h"

// FLAG 定义:
//    step_type: 用于区分 map 任务与 reduce 任务，map 任务的 step_type 为 mapper，reduce 任务的 step_type 为 reducer // NOLINT
//    tb_reco_item:  item 在 HBase 中的表名
DEFINE_string(step_type, "step_type", "step type");
DEFINE_string(hbase_item_table, "tb_reco_item", "item table name");
DEFINE_string(category_dict, "lijing_data/item_category", "item category dict path");

// 输出结果类型
//    NORMAL: 表示正常获取 item 数据，并处理输出
//    INVALID_ITEM_ID: 表示 item_id 为非法 id
//    NOT_IN_HBASE: 表示 tb_reco_item 表中查不到该 item_id
//    EMPTY_TITLE: 表示该 item 数据的 title 字段为空
enum RetDataType {
  NORMAL,
  INVALID_ITEM_ID,
  NOT_IN_HBASE,
  EMPTY_CATEGORY,
  EMPTY_TITLE,
  EMPTY_CONTENT,
  EMPTY_TOPIC,
  EMPTY_WORDVEC
};

// 函数功能: 格式化结果输出，以 \t 分隔
// 输入参数:
//    item_id: 处理的 item_id
//    seg_result: 切词结果
//    topics: 主题结果
//    wordvec: 词向量结果
//    data_type: 输出结果类型
inline void MapPrinter(std::string item_id, std::string category,
                    std::string title, std::string content,
                    std::string title_seg_result, std::string content_seg_result,
                    std::string topics, std::string wordvec, RetDataType data_type) {
  // if (category.find("幽默") == std::string::npos)
  //  return;
  std::cout << item_id << "\t"
            << category << "\t"
            << title << "\t"
            << content << "\t"
            << title_seg_result << "\t"
            << content_seg_result << "\t"
            << topics << "\t"
            << wordvec << "\t"
            << static_cast<char>(data_type + static_cast<int>('A')) << std::endl;
}

// 函数功能: 替换子串
std::string& ReplaceStr(std::string& str, const std::string& old_value, const std::string& new_value) {
  for (std::string::size_type pos(0); pos != std::string::npos; pos += new_value.length()) {
    if ((pos = str.find(old_value, pos)) != std::string::npos)
      str.replace(pos, old_value.length(), new_value);
    else
      break;
  }
  return str;
}

// 函数功能: 根据 item category 词典，生成一级类别映射表
void GenCategoryDict(const std::map<std::string, int>& cate_map) {
  std::fstream fin;
  fin.open(FLAGS_category_dict, std::fstream::in);
  if (!fin.is_open()) {
    std::cerr << "open item category dict error!" << std::endl;
    exit(1);
  }
  std::string line;
  std::vector<std::string> tokens;
  int count = 0;
  while (getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (cate_map.find(tokens[0]) != cate_map.end()) continue;
    cate_map[tokens[0]] = count;
    count += 1;
  }
  fin.close();
}

// 函数功能: 切词
// 输入参数:
//    segmenter: 切词 obj
//    input_text: 需要处理的文本，即输入
//    output_text: 切词完的结果，词与词之间以空格分隔
void SegmentPhrase(const nlp::segment::Segmenter& segmenter, const std::string& input_text, const std::string& output_text) {// NOLINT
  // 格式化输入文本
  // input_text = ReplaceStr(input_text, std::string("\n"), std::string("$"));
  nlp::util::NormalizeLineInPlaceS(&input_text);
  nlp::term::TermContainer container;
  EXPECT_TRUE(segmenter.SegmentT(input_text, &container));

  // 混排切词
  std::vector<base::Slice> hybrid;
  const std::vector<nlp::term::TermInfo> &basic_terms =  container.basic_terms();
  for (int i = 0; i < (int)basic_terms.size(); i++) {
    const nlp::term::TermInfo &info = basic_terms[i];
    if (info.bitmap_misc & nlp::term::kSegmentPhraseB) {
      hybrid.push_back(info.term(input_text));
    } else if (info.bitmap_misc & nlp::term::kSegmentPhraseM ||
               info.bitmap_misc & nlp::term::kSegmentPhraseE) {
      base::Slice slice = info.term(input_text);
      hybrid.back().set(hybrid.back().data(), hybrid.back().size() + slice.size());
    } else {
      hybrid.push_back(info.term(input_text));
    }
  }

  // 格式化切词结果，保存到 output_text
  output_text = "";
  for (size_t i = 0; i < hybrid.size(); i++) {
    output_text += hybrid[i].as_string() + " ";
  }
}

// 函数功能: 生成 item 的 word2vec 特征向量
void GenWordVec(const std::string seg_text, const nlp::word2vec::Word2Vec& word2vec, \
                const std::vector<float>& item_vec, const int& word_count) {
  std::vector<std::string> tokens;
  base::SplitString(seg_text, " ", &tokens);
  std::vector<float> tmp_wordvec;
  for (int i = 0; i < static_cast<int>(tokens.size()); i++) {
    nlp::util::NormalizeLineInPlaceS(&tokens[i]);
    tmp_wordvec.clear();
    word2vec.getVec(tokens[i], &tmp_wordvec);
    if (tmp_wordvec[0] < 1e-4 && tmp_wordvec[1] < 1e-4) continue;
    for (int j = 0; j < (int)tmp_wordvec.size(); j++) {
      item_vec[j] += tmp_wordvec[j];
    }
    word_count += 1;
  }
}

// 函数功能: 排序比较函数
bool Compare(const std::pair<int, double> a, const std::pair<int, float> b) {
  return a.first < b.first;
}

// 函数功能(顺序处理过程):
//    (1) 使用标准流输入的 item_id 查询 HBase ，获取 item 数据
//    (2) 提取 item 的 title 和 content ，并进行混排切词
//    (3) 提取 item 的 topic 和 wordvec 中的 literal ，weight 和 category
//    (4) 格式化输出
void Mapper() {
  reco::HBasePoolGetItem *hbase_item_getter = new reco::HBasePoolGetItem(FLAGS_hbase_item_table, 0);
  nlp::segment::Segmenter segmenter;
  nlp::word2vec::Word2Vec word2vec;
  std::map<std::string, int> cate_map;
  uint64 item_id;
  std::string line;
  GenCategoryDict(cate_map);
  std::map<std::string, int>::iterator cate_map_it;
  while (std::getline(std::cin, line)) {
    std::string title = "";
    std::string content = "";
    std::string topics = "";
    std::string wordvec = "";
    std::string title_seg_result = "";
    std::string content_seg_result = "";
    std::string category = "";
    RetDataType ret_data_type = RetDataType::NORMAL;
    // 检查 item_id 的合法性
    if (!base::StringToUint64(line, &item_id)) {
      ret_data_type = RetDataType::INVALID_ITEM_ID;
    }

    reco::RecoItem item;
    // 检查 item_id 是否存在 HBase
    if (!hbase_item_getter->GetRecoItem(item_id, &item)) {
      ret_data_type = RetDataType::NOT_IN_HBASE;
    }

    // 检查 title 是否为空
    if (item.title().empty()) {
      ret_data_type = RetDataType::EMPTY_TITLE;
    }
    title = item.title();
    SegmentPhrase(segmenter, title, title_seg_result);

    // 检查 content 是否为空
    if (item.content().empty()) {
    // if(item.raw_item().content().empty()) {
      ret_data_type = RetDataType::EMPTY_CONTENT;
    }
    content = item.content();
    SegmentPhrase(segmenter, content, content_seg_result);

    // 获取 category ，并将一级分类标签编码
    // for (int i = 0; i < item.category().size(); i++) {
    //  category += item.category(i) + ";";
    // }
    if (item.category().size() <= 0) {
      ret_data_type = RetDataType::EMPTY_CATEGORY;
    } else {
      // 下标为 0 表示一级类别
      cate_map_it = cate_map.find(item.category(0));
      if (cate_map_it != cate_map.end()) {
        category = /*item.category(0) + "#" + */base::IntToString(cate_map_it->second);
      }
    }

    // 获取 topic
    const reco::FeatureVector &topic_vec = item.topic();
    std::vector<std::string> topic_tokens;
    std::vector<std::pair<int, double> > topic_pair;
    int topic_id;
    for (int i = 0; i < topic_vec.feature_size(); i++) {
      topic_tokens.clear();
      base::SplitString(topic_vec.feature(i).literal(), "-", &topic_tokens);
      base::StringToInt(topic_tokens[1], &topic_id);
      topic_pair.push_back(std::make_pair<int, double>(topic_id, topic_vec.feature(i).weight()));
    }
    sort(topic_pair.begin(), topic_pair.end(), Compare);
    std::vector<std::pair<int, double> >::iterator it = topic_pair.begin();
    for (; it != topic_pair.end();it++) {
      topics += base::IntToString(it->first) + ":" + base::DoubleToString(it->second) + " ";
    }
    if (topics == "") {
      ret_data_type = RetDataType::EMPTY_TOPIC;
    }

    // 生成 wordvec ，注: wordvec 字段为空，需要自己生成
    std::vector<float> item_vec(word2vec.vec_size(), 0);
    int word_count = 0;
    GenWordVec(title_seg_result, word2vec, item_vec, word_count);
    GenWordVec(content_seg_result, word2vec, item_vec, word_count);
    for (int i = 0; i < (int)item_vec.size(); i++) {
      item_vec[i] /= word_count;
    }
    for (int i = 0; i < (int)item_vec.size(); i++) {
      wordvec += base::IntToString(i) + ":" + base::DoubleToString(item_vec[i]) + " ";
    }
    if (wordvec == "") {
      ret_data_type = RetDataType::EMPTY_WORDVEC;
    }

    // 获取 keyword
    // const reco::FeatureVector &keyword_vec = item.keyword();
    // std::string keyword;
    // for (int i = 0; i < keyword_vec.feature_size(); i++) {
    //    keyword += keyword_vec.feature(i).literal() + " ";
    // }
    // GenWordVec(keyword, word2vec, item_vec);

    // 格式化输出
    MapPrinter(line, category, title, content, title_seg_result, \
            content_seg_result, topics, wordvec, RetDataType::NORMAL);
  }
}

void Reducer() {
  std::vector<std::string> tokens;
  std::string line;
  std::string cur_item_id = "";
  std::string item_id;
  std::string cur_title_output = "";
  std::string cur_topic_output = "";
  std::string cur_word2vec_output = "";
  std::string cur_content_output = "";
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    // A 标记表示 item 正常
    if (tokens[tokens.size()-1] != "A") continue;
    // 多路输出
    // std::string ret_str = tokens[tokens.size()-1] + "#" + tokens[0];
    // for (int i = 1; i < int(tokens.size())-1; i++) {
    //  ret_str += "\t" + tokens[i];
    // }
    // std::cout << ret_str << std::endl;
    item_id = tokens[0];
    if (cur_item_id == "") {
      cur_item_id = item_id;
    }
    if (cur_item_id != item_id) {
      std::cout << "title#" << cur_item_id << "\t" << cur_title_output << std::endl;
      std::cout << "topic#" << cur_item_id << "\t" << cur_topic_output << std::endl;
      std::cout << "word2vec#" << cur_item_id << "\t" << cur_word2vec_output << std::endl;
      std::cout << "content#" << cur_item_id << "\t" << cur_content_output << std::endl;
      cur_item_id = item_id;
    }
    // wordvec 特征
    cur_word2vec_output = tokens[1] + "\t" + tokens[7];
    // topic 特征
    cur_topic_output = tokens[1] + "\t" + tokens[6];
    // title 特征
    cur_title_output = tokens[1] + "\t" + tokens[2] + "\t" + tokens[4];
    // content 特征
    cur_content_output = tokens[1] + "\t" + tokens[3] + "\t" + tokens[5];
  }
  std::cout << "title#" << cur_item_id << "\t" << cur_title_output << std::endl;
  std::cout << "topic#" << cur_item_id << "\t" << cur_topic_output << std::endl;
  std::cout << "word2vec#" << cur_item_id << "\t" << cur_word2vec_output << std::endl;
  std::cout << "content#" << cur_item_id << "\t" << cur_content_output << std::endl;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "process reco_item");
  if (FLAGS_step_type == "mapper") {
    Mapper();
  } else if (FLAGS_step_type == "reducer") {
    Reducer();
  }
  return 0;
}
