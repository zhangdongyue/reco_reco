#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <deque>
#include "reco/item_classify_server/strategy/item_classifier.h"
#include "reco/item_classify_server/frame/global_data.h"
#include "reco/item_classify_server/frame/item_classify_controller.h"
#include "reco/item_classify_server/strategy/source_category_manager.h"
#include "serving_base/data_manager/data_manager.h"
#include "base/strings/string_split.h"
#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread.h"
#include "base/thread/blocking_queue.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/file/file_path.h"

DEFINE_string(result_file, "./result.txt", "");
DEFINE_bool(with_source, false, "with source or not, the second fld");
DEFINE_bool(is_debug, false, "if set, print debug feature info");
DEFINE_string(data_dir, "./data", "model dir");
DEFINE_int32(thread_num, 16, "thread num");

static void ClassifyWorker(thread::BlockingQueue<std::pair<std::string, std::string >>* title_queue,
                           thread::BlockingQueue<std::string>* result_queue) {
  std::vector<std::pair<double, std::string>> result;
  reco::item_classify::ItemClassifier item_classifier;
  if (FLAGS_is_debug) item_classifier.set_debug();
  std::deque<std::pair<std::string, std::string>> buffer;
  std::ostringstream oss;
  std::vector<std::string> keywords;

  while (!(title_queue->Empty() && title_queue->Closed())) {
    buffer.clear();
    int n = title_queue->TimedMultiTake(5, &buffer);
    if (n == -1) {
      LOG(ERROR) << "queue is closed, exit";
      break;
    }
    if (n == 0) {
      base::SleepForMilliseconds(50);
      continue;
    }

    std::vector<std::string> keyword;
    while (!buffer.empty()) {
      const std::pair<std::string, std::string> source_title = buffer.front();
      result.clear();
      item_classifier.Classify(source_title.first, source_title.second, keyword, NULL, &result);
      buffer.pop_front();
      oss.str("");
      oss << source_title.second;
      if (FLAGS_with_source) oss << "\t" << source_title.first;
      CHECK_GT(3u, result.size());

      if (result.size() == 1) {
        oss << "\t" << result.front().second << "\t" << result.front().first;
      } else if (result.size() == 2) {
        size_t pos = result[1].second.find("\t");
        if (pos == std::string::npos) {
          LOG(ERROR) << "erro level2: " << result[1].second;
        } else {
          result[1].second[pos] = ',';
        }
        oss << "\t" << result[1].second << "\t" << result[1].first;
      }
      result_queue->Put(oss.str());
    }
  }
}

static void PrintWorker(thread::BlockingQueue<std::string>* result_queue) {
  // output the result
  std::ofstream fout(FLAGS_result_file);
  std::string line;
  while (!result_queue->Closed()) {
    if (!result_queue->Take(&line)) {
      base::SleepForSeconds(1);
      continue;
    }
    fout << line << "\n";
  }
  fout.flush();
  fout.close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "classify demo");
  CHECK(reco::item_classify::ItemClassifier::Initial(base::FilePath(FLAGS_data_dir)));
  reco::item_classify::GlobalData global_data;

  serving_base::DataManangerConfig config;
  config.controller_item_num = FLAGS_thread_num;
  reco::item_classify::ItemClassifyDataManager::Initialize(config, &global_data);

  CHECK(reco::item_classify::ItemClassifyDataManager::RegisterDict(new reco::item_classify::SourceCategoryDict(reco::item_classify::kSourceCategoryDictName, base::FilePath(FLAGS_data_dir)),  // NOLINT
                                                                   new reco::item_classify::SourceCategoryDict(reco::item_classify::kSourceCategoryDictName, base::FilePath(FLAGS_data_dir))));  // NOLINT

  thread::BlockingQueue<std::pair<std::string, std::string>> title_queue;
  thread::BlockingQueue<std::string> result_queue;
  // start classify thread
  thread::ThreadPool pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(&ClassifyWorker, &title_queue, &result_queue));
  }
  // start print worker
  thread::Thread print_worker;
  print_worker.Start(::NewCallback(&PrintWorker, &result_queue));
  LOG(INFO) << "print worker start";

  // main thread read and output
  std::string line;
  std::vector<std::string> tokens;
  while (std::getline(std::cin, line)) {
    if (line.size() < 3) continue;
    tokens.clear();
    base::SplitString(line, "\t", &tokens);

    std::string source = "";
    if (FLAGS_with_source && tokens.size() > 1) source = tokens[1];
    title_queue.Put(std::make_pair(source, tokens[0]));
  }
  title_queue.Close();
  pool.JoinAll();
  result_queue.Close();
  print_worker.Join();
  return 0;
}
