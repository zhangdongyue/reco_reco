#include "reco/module/video_analysis/feature_service/hbase_pool_get_video_feature.h"
#include "reco/bizc/item_service/define.h"
#include "base/common/logging.h"
#include "base/common/base.h"
#include "base/time/time.h"
#include "base/random/pseudo_random.h"
#include "base/hash_function/term.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/common/sleep.h"

DEFINE_string(hbase_video_feature_table, "tb_video_feature", "hbase table");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "VIDEOFEA");

  reco::hbase::HBasePoolIns::instance().Init();
  reco::HBasePoolGetVideoFeature get_video_feature("tb_video_feature");

  std::string line;
  uint64 item_id;

  while (std::getline(std::cin, line)) {
    if (line.size() < 3) continue;
    if (!base::StringToUint64(line, &item_id)) continue;

    reco::VideoFeature video_feature;
    get_video_feature.GetVideoFeature(item_id, &video_feature);
       
    std::string wd_video = "";
    if (video_feature.classify_feature_size() > 0) {
      wd_video += base::DoubleToString(video_feature.classify_feature(0));
      for (int j = 1; j < (int)video_feature.classify_feature_size(); ++j) {
        wd_video = wd_video + "," + base::DoubleToString(video_feature.classify_feature(j));
      }
    }

    std::cout << wd_video << std::endl;
  
  
  
  
  }




  return 0;



}
