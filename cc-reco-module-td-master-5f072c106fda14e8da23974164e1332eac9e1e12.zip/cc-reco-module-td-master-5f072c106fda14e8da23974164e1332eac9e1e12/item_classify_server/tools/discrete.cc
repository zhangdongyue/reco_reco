#include <iostream>
#include "base/hash_function/term.h"
#include "base/common/base.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "dis");
  std::string line;
  std::vector<std::string> flds;
  std::vector<std::string> fea;

  while (std::getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 3) {
      continue;
    }

    fea.clear();
    base::SplitString(flds[3], " ", &fea);
    if (fea.empty()) continue;
    line.clear();
    line += flds[0];
    line += "\t";
    line += flds[1];
    line += "\t";
    line += flds[2];
    line += "\t";
    line += flds[3];
    line += "\t";

    bool is_begin = true;
    for (size_t i = 0; i < fea.size(); ++i) {
      size_t pos = fea[i].find(":");
      if (pos == std::string::npos) {
        continue;
      }
      double weight = 0;
      if (!base::StringToDouble(fea[i].substr(pos + 1), &weight)) continue;

      int idx = static_cast<int>((weight - 0.5) * 20);
      std::string literal = base::StringPrintf("%s_%d", fea[i].substr(0, pos).c_str(), idx);
      uint64 sign = base::CalcTermSign(literal.c_str(), literal.size());
      if (!is_begin) line += " ";
      line += base::StringPrintf("%lu:1", sign);
      is_begin = false;
    }
    std::cout << line << std::endl;
  }
}
