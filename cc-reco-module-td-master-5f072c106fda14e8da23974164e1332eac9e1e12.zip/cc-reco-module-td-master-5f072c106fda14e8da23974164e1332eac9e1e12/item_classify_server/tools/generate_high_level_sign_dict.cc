#include <iostream>
#include <string>
#include <unordered_map>
#include "base/hash_function/term.h"
#include "base/common/base.h"
#include "base/strings/string_printf.h"

int main(int argc, char** argv) {
  std::string line;
  const std::string prefix[] = {"T_BOW_", "TS_BOW_", "C_KW_", "C_P_", "T_SVM_", "T_KNN_"};
  int num = ARRAYSIZE_UNSAFE(prefix);
  // read all category
  std::unordered_map<std::string, int> category_dict;
  while (std::getline(std::cin, line)) {
    if (line.find(",") != std::string::npos) continue;

    size_t pos = line.find("\t");
    std::string category = line.substr(0, pos);
    if (category_dict.find(category) != category_dict.end()) continue;
    category_dict[category] = category_dict.size();
    for (int i = 0; i < num; ++i) {
      for (int j = 0; j < 11; ++j) {
        std::string literal = base::StringPrintf("%s-%s_%d", prefix[i].c_str(), category.c_str(), j);
        uint64 sign = base::CalcTermSign(literal.c_str(), literal.size());
        std::cout << sign << "\t" << literal << "\n";
      }
      std::string literal = base::StringPrintf("%s-%s", prefix[i].c_str(), category.c_str());
      uint64 sign = base::CalcTermSign(literal.c_str(), literal.size());
      std::cout << sign << "\t" << literal << "\n";
    }
  }
}

