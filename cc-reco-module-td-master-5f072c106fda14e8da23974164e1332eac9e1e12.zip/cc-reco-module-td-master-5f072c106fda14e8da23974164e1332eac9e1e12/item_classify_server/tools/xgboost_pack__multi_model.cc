#include <iostream>
#include <vector>
#include <fstream>
#include <string>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "reco/module/item_classify_server/global_data/xgboost_util.h"
#include "reco/module/item_classify_server/global_data/define.h"

DEFINE_string(cate_list_file, "cates.txt", "cate_list_file");
DEFINE_string(fea_list_file, "features.txt", "cate_list_file");
DEFINE_string(model_list_file, "packed_cate.txt", "model_list_file");

DEFINE_string(model_path, "model/", "model_path");
DEFINE_string(output_file, "lda_xgboost.model", "output_file");

void PackModel() {
  reco::item_classify::Stream* p_fout = reco::item_classify::Stream::Create(FLAGS_output_file.c_str(), "w");
  reco::item_classify::XGboostModel* p_model = new reco::item_classify::XGboostModel();

  std::unordered_map<std::string, std::vector<std::string>*> cate_map;
  // std::vector<reco::SparseFeatureMeta> fea_list;

  std::vector<std::string> lines;
  std::vector<std::string> tokens;
  // 读入所有类别 按照顺序归属到统一的上级类别
  base::file_util::ReadFileToLines(base::FilePath(FLAGS_cate_list_file), &lines);
  for (size_t i = 0; i < lines.size(); ++i) {
    const std::string& cate_name = lines[i];
    std::string parent = "root";
    if (cate_name.find(",") != std::string::npos) {
      parent = cate_name.substr(0, cate_name.find(","));
    }
    auto it = cate_map.find(parent);
    if (it == cate_map.end()) {
      cate_map.insert(std::make_pair(parent, new std::vector<std::string>()));
      it = cate_map.find(parent);
    }
    it->second->push_back(cate_name);
  }
  // 模型列表
  std::vector<std::pair<std::string, std::vector<std::string>*>> model_name;
  lines.clear();
  base::file_util::ReadFileToLines(base::FilePath(FLAGS_model_list_file), &lines);
  size_t sample_numer = lines.size();
  p_fout->Write(&sample_numer, sizeof(size_t));
  for (size_t i = 0; i < lines.size(); ++i) {
    const std::string& line = lines[i];
    tokens.clear();
    base::SplitString(line, " ", &tokens);

    const std::string& cate_name = tokens[0];
    const std::string& cate_name_pinyin = tokens[1];
    auto it = cate_map.find(cate_name);
    if (it == cate_map.end()) continue;
    std::string model_name = FLAGS_model_path + cate_name_pinyin + ".model";

    CHECK(base::file_util::PathExists(base::FilePath(model_name))) << model_name << " not exists";
    // 写入所有类的名字
    std::string cate_names_str;
    base::FastJoinStrings(*(it->second), "|", &cate_names_str);
    p_fout->Write(cate_names_str);
    LOG(INFO) << cate_names_str;
    // 创建 Stream 对象，GBTree 对象
    reco::item_classify::Stream* p_fin = reco::item_classify::Stream::Create(
            model_name.c_str(), "r");
    // Load 模型头部声明
    std::string header;
    header.resize(4);
    CHECK_EQ(p_fin->Read(&header[0], 4), 4u);
    // Load 模型参数
    p_fin->Read(&p_model->model_param, sizeof(reco::item_classify::XParam));
    // 构建归一化对象
    std::string obj_name;
    p_fin->Read(&obj_name);
    p_model->p_obj = reco::item_classify::CreateObjFunction(obj_name.c_str());
    std::string tmp = base::IntToString(p_model->model_param.num_class);
    p_model->p_obj->SetParam("num_class", tmp.c_str());
    // 构建 gbm 对象， Load 模型
    std::string gbm_name;
    p_fin->Read(&gbm_name);
    p_model->p_gbm = new reco::item_classify::GBTree();
    p_model->p_gbm->LoadModel(p_fin, false);
    delete p_fin;

    // 写入新的模型文件
    p_fout->Write("binf", 4);
    p_fout->Write(&p_model->model_param, sizeof(reco::item_classify::XParam));
    p_fout->Write(obj_name);
    p_fout->Write(gbm_name);

    p_model->p_gbm->SaveModel(p_fout, false);
  }
  delete p_fout;
}

void CheckModel() {
  // 创建 Stream 对象， GBTree 对象
  reco::item_classify::Stream* p_fin = reco::item_classify::Stream::Create(FLAGS_output_file.c_str(), "r");

  size_t model_number;
  p_fin->Read(&model_number, sizeof(size_t));
  LOG(INFO) << model_number;
  for (size_t i = 0; i < model_number; ++i) {
    std::string cate_names_str;
    p_fin->Read(&cate_names_str);
    LOG(INFO) << cate_names_str;
    reco::item_classify::XGboostModel* p_model = new reco::item_classify::XGboostModel();
    // Load 模型头部声明
    std::string header;
    header.resize(4);
    CHECK_EQ(p_fin->Read(&header[0], 4), 4u);
    // Load 模型参数
    p_fin->Read(&p_model->model_param, sizeof(reco::item_classify::XParam));
    // Load 归一化对象
    std::string obj_name;
    p_fin->Read(&obj_name);
    // 构建 gbm 对象， Load 模型
    std::string gbm_name;
    p_fin->Read(&gbm_name);
    p_model->p_gbm = new reco::item_classify::GBTree();
    // Load 映射词典
    p_model->p_gbm->LoadModel(p_fin, false);
  }
  delete p_fin;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "pack xgboost");
  PackModel();
  CheckModel();
  return 0;
}
