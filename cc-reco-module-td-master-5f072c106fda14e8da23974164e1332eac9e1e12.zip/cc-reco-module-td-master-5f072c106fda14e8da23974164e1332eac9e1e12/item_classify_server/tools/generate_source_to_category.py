#!encoding=utf8
import sys
last_elements = []
source_dict={}
strict_dict = {"育儿":1, "历史":1, "美女写真":1, "收藏":1, "幽默":1, "旅游":1, "科学探索":1, "星座":1, "星座":1, "美食":1, "职场":1,
"时尚\t彩妆":1, "房产\t海外地产":1, "财经\t美股":1, "财经\t港股":1,
"时尚\t男士":1, "时尚\t婚嫁":1, "时尚\t时装":1, "时尚\t奢侈品":1, "育儿\t亲子":1}

def check_valid(source, category_dict):
  if len(category_dict) > 1:
    for key, value_list in category_dict.items():
      level1_strict_type = int(value_list[0])
      if  level1_strict_type  == 1:
        sys.stderr.write("%s has strick category: %s, and with other category\n" %(source, key))
        return False
      if strict_dict.has_key(key):
        sys.stderr.write("%s has category without classifier: %s, and with other category\n" %(source, key))
        return False
  else:
    for key, value_list in category_dict.items():
      level1_strict_type = int(value_list[0])
      if  level1_strict_type  == 0 and strict_dict.has_key(key):
        sys.stderr.write("%s has strick category: %s, and not define as strick\n" %(source, key))
        return False
      
      has_strict = False
      for level2, level2_strict in value_list[1:]:
        if int(level2_strict) == 0 and strict_dict.has_key("%s\t%s" %(key, level2)):
          sys.stderr.write("%s has strick category: %s, and not define as strick\n" %(source, key))
          return False
        if int(level2_strict) == 1:
          has_strict = True

      if has_strict and len(value_list) > 2:
        sys.stderr.write("%s has strick level2 category: %s\t%s, and with other category\n" %(source, key, level2))
        return False
  return True
   
last_source = ""
for line in sys.stdin:
  elements = line.strip().split(",")
  if len(elements) < 5:
    sys.stderr.write("erro line;%s\n" %line)
    continue
  
  source = elements[0]
  if len(source) < 2:
    source = last_source

  level1 = elements[2]
  level1_strict = elements[3]
  if level1_strict == "写死" or level1_strict == "是":
    level1_strict = "1"
  else:
    level1_strict = "0"
    
  last_source = source
  if not source_dict.has_key(source):
    source_dict[source] = {}
    category_dict = source_dict[source]
  else:
    category_dict = source_dict[source]
  
  category_dict[level1] = [level1_strict]
   
  level2 = elements[4]
  level2_strict = elements[5]
  if level2_strict == "写死" or level2_strict == "是":
    level2_strict = "1"
  else:
    level2_strict = "0"
  if len(level2) > 1:
    category_dict[level1].append((level2, level2_strict))

for source, category_dict in source_dict.items():
  if check_valid(source, category_dict):
    for level1, value_list in category_dict.items():
      if int(value_list[0]) == 0:
        if len(value_list) < 2:
          print "%s\t%s" %(source, level1)
        else:
          for level2, level2_strict in value_list[1:]:
            if int(level2_strict) == 1:
              print "%s\t%s\t%s:1" %(source, level1, level2)
            else:
              print "%s\t%s\t%s" %(source, level1, level2)
      else:
        if len(value_list) < 2:
          print "%s\t%s:1" %(source, level1)
        elif len(value_list) == 2 and int(value_list[1][1]) == 1:
          print "%s\t%s:1\t%s:1" %(source, level1, value_list[1][0])
        elif len(value_list) == 2:
          print "%s\t%s:1\t%s" %(source, level1, value_list[1][0])
        else:
          sys.stderr.write("erro level1: %s with more than one level2:%s\n" %(level1, ",".join(value_list)))
  else:
    sys.stderr.write("skip source: %s , invalid\n" %source)

