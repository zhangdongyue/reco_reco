//
// Created by PengWei on 2017/2/24.
//
#include <math.h>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/file/file_util.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "base/common/gflags.h"

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_string(input_file, "diff1.txt", "input file");
DEFINE_int32(push_number, 300, "max number to evaluate");
DEFINE_string(task_name, "diff评估", "task name to show");
DEFINE_string(type, "diff评估", "task name to show");
DEFINE_string(tb_name, "tb_label_evaluation_data", "tb_name");
class DiffResult {
 public:
  std::string item_id;
  std::string title;
  std::string old_cate;
  std::string new_cate;

  DiffResult(std::string line) {
    std::vector<std::string> tokens;
    base::SplitString(line, "\t", &tokens);
    title = tokens[0];
    item_id = tokens[2];
    old_cate = tokens[3];
    new_cate = tokens[4];
    title = base::StringReplace(title, "'", "", true);
  }
};

// 将 diff 的结果推送到 diff 盲测 平台
int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "diff tools");
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  serving_base::mysql_util::DbConnManager* db_manager
          = new serving_base::mysql_util::DbConnManager(db_option);

  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(base::FilePath(FLAGS_input_file), &lines)) {
    LOG(ERROR) << "少年，读文件出错了";
    return false;
  }
  std::vector<DiffResult> results;
  for (size_t i = 0; i < lines.size(); ++i) {
    DiffResult diff_result(lines[i]);
    results.push_back(diff_result);
  }
  std::random_shuffle(results.begin(), results.end());
  // 常见一个新的task_id 在最大值的基础上加 1
  std::string sql = base::StringPrintf("select max(task_id) id from %s", FLAGS_tb_name.c_str());
  scoped_ptr<sql::ResultSet> res(db_manager->ExecuteQueryWithRetry(sql, 3));
  int task_id = 1;

  if (res->next()) {
    task_id = res->getInt("id") + 1;
  }
  std::string sql_base = base::StringPrintf(
          "insert into %s (task_id, task_name, item_id, title, type, new_cate, old_cate, score, update_time) values ",
          FLAGS_tb_name.c_str());
  sql = sql_base;
  for (int j = 0; j < FLAGS_push_number && j < (int) results.size(); ++j) {
    std::string type_name = "分类改变";
    if (results[j].new_cate == "None") type_name = "丢召回";
    if (results[j].old_cate == "None") type_name = "补充召回";
    sql.append(base::StringPrintf("(%d,'%s','%s','%s','%s','%s','%s',0.8,NOW())",
                                  task_id, FLAGS_task_name.c_str(), results[j].item_id.c_str(),
                                  results[j].title.c_str(),
                                  type_name.c_str(), results[j].new_cate.c_str(), results[j].old_cate.c_str()));

    if (j % 10 == 9 || j == FLAGS_push_number - 1 || j == (int) results.size() - 1) {
      sql.append(";");
      int32 sql_status = db_manager->ExecuteUpdateWithRetry(sql, 3);
      if (sql_status < 1) {
        LOG(ERROR) << "sql: " << sql;
      }
      sql = sql_base;
    } else {
      sql.append(",");
    }
  }
}

