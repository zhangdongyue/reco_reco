#include "nlp/common/nlp_util.h"
#include "nlp/segment/segmenter.h"
#include <vector>
#include <string>
#include <fstream>
#include "base/common/closure.h"
#include "base/common/base.h"
#include "base/strings/string_split.h"

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "gen train");
  std::string line;
  // nlp::term::TermContainer* term_container;
  nlp::segment::Segmenter segmenter;
  std::vector<std::string> tokens;
  std::vector<std::string> elements;
  std::ifstream fin("press.w2v.id");
  std::ofstream fout("w2v_train.txt");

  while(std::getline(fin, line)) {
    elements.clear();
    base::SplitString(line, "\t", &elements);
    line = elements[1];
    tokens.clear();
    bool seg_flag = segmenter.SegmentS(nlp::util::NormalizeLine(line), &tokens);

    // std::string join = base::JoinStrings(tokens, " ");
    //fout << join << "\n";
    if (!seg_flag) continue;
    fout << elements[0] << "\t";
    for (int i = 0; i < (int)tokens.size(); ++i)
      fout << tokens[i] << " ";
    fout << "\n";
  }
  fout.close();
}
