#include <fstream>
#include <string>
#include <cmath>

#include "reco/item_service/hbase_pool_get_item.h"
#include "reco/proto/item.pb.h"
#include "reco/reco_plsa/reco_plsa.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/hash_function/term.h"

DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table");
DEFINE_int32(thread_num, 1, "thread num");

void GetItemWorker(thread::BlockingQueue<uint64>* id_queue,
                   thread::BlockingQueue<std::string>* result_queue,
                   thread::BlockingVar<int>* finish_num) {
  reco::HBasePoolGetItem* hbase_get_item = new reco::HBasePoolGetItem(FLAGS_hbase_item_table, 1000);
  std::vector<uint64> item_ids;
  std::vector<bool> rets;
  std::vector<reco::RecoItem> reco_items;
  uint64 item_id;
  std::string buf;
  reco::RecoPlsa reco_plsa;

  while (!id_queue->Closed() || !id_queue->Empty()) {
    int status = id_queue->TimedTake(10, &item_id);

    if (status == 0) continue;
    if (status == -1) break;
    if (status != 1) {
      LOG(ERROR) << base::StringPrintf("erro status: %d", status);
      continue;
    }

    item_ids.push_back(item_id);
    if (item_ids.size() > 1024) {
      rets.clear();
      reco_items.clear();
      hbase_get_item->GetRecoItems(item_ids, &rets, &reco_items);

      for (int i = 0; i < (int)reco_items.size(); ++i) {
        if (!rets[i] || reco_items[i].title().empty() || reco_items[i].identity().type() == 30) continue;
        if (reco_items[i].category_size() <= 1) continue;

        buf = reco_items[i].category(0) + "," + reco_items[i].category(1) + '\t';
        // buf = base::StringPrintf("%lu", reco_items[i].identity().item_id()) + '\t';
        buf = buf + reco_items[i].source() + '\t' + reco_items[i].title() + '\t';

        std::vector<nlp::plsa::Topic> topic;
        reco_plsa.PredictPzd(reco_items[i].category(0), reco_items[i].title(), "", &topic);

        for (int j = 0; j < (int)topic.size(); ++j) {
          std::string l2_fea;
          l2_fea = reco_items[i].category(0) + "_l2_" + base::IntToString(topic[j].aspect) + "_";
          if (topic[j].value == 1)
            l2_fea += base::IntToString(9);
          else
            l2_fea += base::IntToString((int)floor(topic[j].value*10));

          uint64 l2_sign = base::CalcTermSign(l2_fea.c_str(), l2_fea.size());
          buf = buf + base::Uint64ToString(l2_sign) + ":1 ";
        }

        // for (int j = 0; j < reco_items[i].tag().feature_size(); ++j)
          // buf = buf + reco_items[i].tag().feature(j).literal() + '\t';

        result_queue->Put(buf);
      }
      item_ids.clear();
    }
  }

  if (!item_ids.empty()) {
      rets.clear();
      reco_items.clear();
      hbase_get_item->GetRecoItems(item_ids, &rets, &reco_items);

      for (int i = 0; i < (int)reco_items.size(); ++i) {
        if (!rets[i] || reco_items[i].title().empty() || reco_items[i].identity().type() == 30) continue;
        if (reco_items[i].category_size() <= 1) continue;

        buf = reco_items[i].category(0) + "," + reco_items[i].category(1) + '\t';
        // buf = base::StringPrintf("%lu", reco_items[i].identity().item_id()) + '\t';
        buf = buf + reco_items[i].source() + '\t' + reco_items[i].title() + '\t';

        std::vector<nlp::plsa::Topic> topic;
        reco_plsa.PredictPzd(reco_items[i].category(0), reco_items[i].title(), "", &topic);

        for (int j = 0; j < (int)topic.size(); ++j) {
          std::string l2_fea;
          l2_fea = reco_items[i].category(0) + "_l2_" + base::IntToString(topic[j].aspect) + "_";
          if (topic[j].value == 1)
            l2_fea += base::IntToString(9);
          else
            l2_fea += base::IntToString((int)floor(topic[j].value*10));

          uint64 l2_sign = base::CalcTermSign(l2_fea.c_str(), l2_fea.size());
          buf = buf + base::Uint64ToString(l2_sign) + ":1 ";
        }

        // for (int j = 0; j < reco_items[i].tag().feature_size(); ++j)
          // buf = buf + reco_items[i].tag().feature(j).literal() + '\t';

        result_queue->Put(buf);
      }
  }
  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    result_queue->Close();
  }

  CHECK(finish_num->TryPut(n));
}

void SaveWorker(thread::BlockingQueue<std::string>* result_queue) {
  std::string result;
  int n = 0;
  while (!result_queue->Closed() || !result_queue->Empty()) {
    int status = result_queue->TimedTake(10, &result);
    if (status == 0) {
      continue;
    }
    if (status == -1) break;

    if (status != 1) {
      LOG(ERROR) << base::StringPrintf("erro status: %d", status);
      continue;
    }
    std::cout << result << "\n";
    ++n;
  }
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "tag to train");
  thread::ThreadPool pool(FLAGS_thread_num + 2);
  thread::BlockingQueue<uint64> id_queue;
  thread::BlockingQueue<std::string> result_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(&GetItemWorker, &id_queue, &result_queue, &finish_num));
  }
  pool.AddTask(::NewCallback(&SaveWorker, &result_queue));

  std::string line;
  uint64 item_id;
  std::vector<std::string> tokens;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (base::StringToUint64(tokens[0], &item_id)) {
      id_queue.Put(item_id);
    }
  }
  id_queue.Close();

  pool.JoinAll();
}
