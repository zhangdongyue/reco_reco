#include <iostream>
#include <fstream>
#include <unordered_map>
#include <math.h>
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc/rpc.h"

#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/module/item_classify_server/common/item_util.h"

DEFINE_string(item_classify_server_ip, "127.0.0.1", "sim item server ip");
DEFINE_int32(item_classify_server_port, 20004, "sim item server port");

DEFINE_string(result_path, "result/", "the output path");
DEFINE_string(input, "",
              "input file for raw item ,seprated by tab, three fls, title,categories, only title is needed");  // NOLINT

DEFINE_int32(send_worker_num, 8, "thread num for send request");
DEFINE_int32(hbase_thread_num, 16, "thread num for send request");

DEFINE_string(hbase_item_table, "tb_reco_item", "h`ase table");
DEFINE_bool(use_level2, false, "use level2");
DEFINE_bool(use_multi_category, false, "use multi_category");

class Sample {
 public:
  std::string category;
  int label; // 1 正样本 -1 负样本 0 不确定
  std::vector<std::pair<std::string, double>> features;
};

using reco::item_classify::ItemClassifyRequest;
using reco::RecoItem;

static void ConvertRecoItemToRequest(thread::BlockingQueue<uint64>* item_id_q,
                                     thread::BlockingQueue<std::pair<uint64, ItemClassifyRequest*> >* req_q) {
  reco::HBaseGetItem* hbase_get_item = new reco::HBaseGetItem(FLAGS_hbase_item_table);

  std::vector<uint64> item_ids;
  std::vector<reco::RecoItem> reco_items;
  uint64 item_id;
  int n = 0;
  int m = 0;
  int fail = 0;
  while (!(item_id_q->Closed() && item_id_q->Empty())) {
    if (item_id_q->Empty()) {
      base::SleepForMilliseconds(100);
      continue;
    }

    if (!item_id_q->Take(&item_id)) break;

    item_ids.push_back(item_id);

    if (item_ids.size() > 128) {
      m += item_ids.size();
      reco_items.clear();
      hbase_get_item->GetRecoItems(item_ids, &reco_items);

      for (size_t i = 0; i < reco_items.size(); ++i) {
        reco::item_classify::ItemClassifyRequest* request = new reco::item_classify::ItemClassifyRequest();
        request->set_source(reco_items[i].source());
        request->set_title(reco_items[i].title());

        request->set_item_type(reco_items[i].identity().type());

        request->set_content(reco_items[i].raw_item().content());
        request->set_item_id(reco_items[i].identity().item_id());

        // keyword and tag
        const reco::FeatureVector& keyword_fea = reco_items[i].keyword();
        for (int j = 0; j < keyword_fea.feature_size(); ++j) {
          request->add_keywords(keyword_fea.feature(j).literal());
        }

        const reco::FeatureVector& tag_fea = reco_items[i].tag();
        for (int j = 0; j < tag_fea.feature_size(); ++j) {
          request->add_tags(tag_fea.feature(j).literal());
        }
        const reco::FeatureVector& fea_topic = reco_items[i].topic();
        auto topic = request->mutable_topic();
        topic->set_norm(1.0);
        auto topic_feature = topic->mutable_feature();
        for (int j = 0; j < fea_topic.feature_size(); ++j) {
          auto it = topic_feature->Add();
          it->set_literal(fea_topic.feature(j).literal());
          it->set_weight(fea_topic.feature(j).weight());
          // LOG(INFO) << fea_topic.feature(j).literal()<<fea_topic.feature(j).weight();
        }
        request->set_level(2);
        request->set_is_debug(true);
        request->set_debug_level(2);

        req_q->Put(std::make_pair(reco_items[i].identity().item_id(), request));
        ++n;
      }
      item_ids.clear();
    }
  }
  if (!item_ids.empty()) {
    m += item_ids.size();
    reco_items.clear();
    hbase_get_item->GetRecoItems(item_ids, &reco_items);

    for (size_t i = 0; i < reco_items.size(); ++i) {
      reco::item_classify::ItemClassifyRequest* request = new reco::item_classify::ItemClassifyRequest();
      request->set_source(reco_items[i].source());
      request->set_title(reco_items[i].title());

      request->set_item_type(reco_items[i].identity().type());

      request->set_content(reco_items[i].raw_item().content());
      request->set_item_id(reco_items[i].identity().item_id());

      // keyword and tag
      const reco::FeatureVector& keyword_fea = reco_items[i].keyword();
      for (int j = 0; j < keyword_fea.feature_size(); ++j) {
        request->add_keywords(keyword_fea.feature(j).literal());
      }

      const reco::FeatureVector& tag_fea = reco_items[i].tag();
      for (int j = 0; j < tag_fea.feature_size(); ++j) {
        request->add_tags(tag_fea.feature(j).literal());
      }
      //
      const reco::FeatureVector& fea_topic = reco_items[i].topic();
      auto topic = request->mutable_topic();
      topic->set_norm(1.0);
      auto topic_feature = topic->mutable_feature();
      for (int j = 0; j < fea_topic.feature_size(); ++j) {
        auto it = topic_feature->Add();
        it->set_literal(fea_topic.feature(j).literal());
        it->set_weight(fea_topic.feature(j).weight());
      }
      request->set_level(2);
      request->set_is_debug(true);
      request->set_debug_level(2);

      req_q->Put(std::make_pair(reco_items[i].identity().item_id(), request));
      ++n;
    }
  }
  LOG(ERROR) << "threadend gen " << n << "request" << " get " << m << " from item id q" << " fail: " << fail;
}

static void GenerateRequestFromHBase(std::string filename,
                                     thread::BlockingQueue<std::pair<uint64, ItemClassifyRequest*> >* req_q) {
  std::vector<uint64> item_ids;
  std::vector<std::string> tokens;
  std::vector<reco::RecoItem> reco_items;
  std::vector<bool> rets;

  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(filename), &lines)) << filename;
  LOG(INFO) << "finish reading " << lines.size();

  thread::BlockingQueue<uint64> item_id_q;
  thread::ThreadPool pool(FLAGS_hbase_thread_num);
  for (int i = 0; i < FLAGS_hbase_thread_num; ++i) {
    pool.AddTask(::NewCallback(&ConvertRecoItemToRequest, &item_id_q, req_q));
  }

  for (size_t i = 0; i < lines.size(); ++i) {
    tokens.clear();
    if (lines[i].size() < 2) {
      LOG(ERROR) << "erro line: " << lines[i];
      continue;
    }
    base::TrimWhitespaces(&lines[i]);
    base::SplitString(lines[i], "\t", &tokens);

    uint64 item_id = 0;
    if (!base::StringToUint64(tokens[0], &item_id)) continue;
    item_id_q.Put(item_id);
  }
  item_id_q.Close();
  LOG(INFO) << "finishing! remain id: " << item_id_q.Size();
  pool.JoinAll();
  LOG(INFO) << "finish generating all rquest! remain request: " << req_q->Size();
  req_q->Close();
}

static void SendWorker(
        thread::BlockingQueue<std::pair<uint64, reco::item_classify::ItemClassifyRequest*>>* request_queue,  // NOLINT
        thread::BlockingQueue<Sample>* result_queue,
        thread::BlockingVar<int>* sender_num) {
  net::rpc::RpcClientChannel channel(FLAGS_item_classify_server_ip.c_str(), FLAGS_item_classify_server_port);
  CHECK(channel.Connect());
  reco::item_classify::ItemClassifyService::Stub stub(&channel);
  reco::item_classify::ItemClassifyResponse response;
  std::pair<uint64, reco::item_classify::ItemClassifyRequest*> element;

  std::unordered_set<std::string> classified_cates;
  while (!(request_queue->Closed() && request_queue->Empty())) {
    if (request_queue->Empty()) {
      LOG_EVERY_N(INFO, 1000) << "send workersleep";
      base::SleepForSeconds(1);
      continue;
    }
    if (!request_queue->Take(&element)) break;
    net::rpc::RpcClientController rpc;
    rpc.SetTimeout(2000);
    const reco::item_classify::ItemClassifyRequest* request = element.second;
    stub.ClassifyItem(&rpc, request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "failed: " << request->item_id()
                 << "rpc.status()=" << rpc.status() << " response.success())=" << response.success();
      continue;
    }
    classified_cates.clear();
    for (int i = 0; i < response.category_size(); ++i) {
      const std::string& category = response.category(i);
      if (category.find(",") != std::string::npos && !FLAGS_use_level2) continue;
      classified_cates.insert(category);
    }
    if (FLAGS_use_multi_category) {
      for (int i = 0; i < (int) response.category_candidates_size(); i++) {
        const std::string& category = response.category_candidates(i);
        if (category.find(",") != std::string::npos && !FLAGS_use_level2) continue;
        classified_cates.insert(category);
      }
    }
    // 不同策略的的分数
    std::vector<std::pair<std::string, double>> features;
    std::unordered_set<std::string> cate_candianates;
    for (int j = 0; j < response.debug_info().classify_info_size(); ++j) {
      if (response.debug_info().classify_info(j).cate_name_size() == 0) continue;
      const std::string& method_name = response.debug_info().classify_info(j).method_name();
      for (int k = 0; k < response.debug_info().classify_info(j).cate_name_size(); ++k) {
        const std::string& cate_name = response.debug_info().classify_info(j).cate_name(k);
        if (cate_name.find(",") != std::string::npos && !FLAGS_use_level2) continue;
        double score = response.debug_info().classify_info(j).cate_score(k);

        features.push_back(std::make_pair(method_name + "|" + cate_name, score));
        cate_candianates.insert(cate_name);
      }
    }
    for (auto it = cate_candianates.begin(); it != cate_candianates.end(); ++it) {
      const std::string& cate_name = *it;
      int label = 1;
      if (classified_cates.find(cate_name) == classified_cates.end()) label = -1;
      Sample sample;
      sample.category = cate_name;
      sample.label = label;
      sample.features = features;

      result_queue->Put(sample);
    }
    delete request;
  }

  int n = sender_num->Take() + 1;
  if (n == FLAGS_send_worker_num) {
    result_queue->Close();
  }
  CHECK(sender_num->TryPut(n));
}

static void SaveResult(std::string path, thread::BlockingQueue<Sample>* result_queue) {
  Sample sample;
  std::unordered_map<std::string, std::ofstream*> fouts;
  std::unordered_map<std::string, int> feature_names;
  std::string buf;
  std::vector<std::pair<int, double>> scores;
  while (!(result_queue->Closed() && result_queue->Empty())) {
    if (result_queue->Empty()) {
      LOG_EVERY_N(INFO, 3000) << "save result thread sleep";
      base::SleepForMilliseconds(20);
      continue;
    }

    if (!result_queue->Take(&sample)) break;
    const std::string& cate_name = sample.category;
    auto it = fouts.find(cate_name);
    if (it == fouts.end()) {
      fouts.insert(std::make_pair(cate_name, new std::ofstream(path + cate_name)));
      it = fouts.find(cate_name);
    }
    buf = base::IntToString(sample.label);
    scores.clear();
    for (size_t i = 0; i < sample.features.size(); ++i) {
      auto it = feature_names.find(sample.features[i].first);
      if (it == feature_names.end()) {
        feature_names.insert(std::make_pair(sample.features[i].first, feature_names.size()+1));
        it = feature_names.find(sample.features[i].first);
      }
      scores.push_back(std::make_pair(it->second, sample.features[i].second));
    }
    std::sort(scores.begin(), scores.end(), std::less<std::pair<int, double>>());

    for (size_t i = 0; i < scores.size(); ++i) {
      buf.append(" ");
      buf.append(base::IntToString(scores[i].first));
      buf.append(":");
      buf.append(base::DoubleToString(scores[i].second));
    }


    buf.append("\n");
    it->second->write(buf.c_str(), buf.size());
  }
  for (auto it = fouts.begin(); it != fouts.end(); ++it) {
    it->second->close();
  }
  std::ofstream fout_features(path + "feature.map");
  for (auto it = feature_names.begin(); it != feature_names.end(); ++it) {
    fout_features << it->first << "\t" << it->second << "\n";
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "sim item client");
  thread::ThreadPool pool(FLAGS_send_worker_num + 2);

  thread::BlockingQueue<std::pair<uint64, reco::item_classify::ItemClassifyRequest*> > request_queue;
  thread::BlockingQueue<Sample> result_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));

  pool.AddTask(::NewCallback(&GenerateRequestFromHBase, FLAGS_input, &request_queue));

  for (int i = 0; i < FLAGS_send_worker_num; ++i) {
    pool.AddTask(::NewCallback(&SendWorker, &request_queue, &result_queue, &finish_num));
  }

  pool.AddTask(::NewCallback(&SaveResult, FLAGS_result_path, &result_queue));

  pool.JoinAll();
  return 0;
}
