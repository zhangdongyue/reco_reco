#include <math.h>
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/file/file_util.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "base/common/gflags.h"
#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "net/rpc/rpc.h"
#include "reco/module/item_classify_server/global_data/define.h"
DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_string(task_file, "task.txt", "model dir");
DEFINE_double(cutting_value, 0.9, "model dir");
DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table");
DEFINE_string(item_classify_server_ip, "11.251.177.94", "sim item server ip");
DEFINE_int32(item_classify_server_port, 20004, "sim item server port");

// 通过 diff 盲测标注平台评估的结果， 确定一个 tag 的阈值给线上使用
int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "getting threashold");
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  serving_base::mysql_util::DbConnManager *db_manager
          = new serving_base::mysql_util::DbConnManager(db_option);
  reco::HBaseGetItem* hbase_get_item = new reco::HBaseGetItem(FLAGS_hbase_item_table);

  net::rpc::RpcClientChannel channel(FLAGS_item_classify_server_ip.c_str(), FLAGS_item_classify_server_port);
  CHECK(channel.Connect());
  reco::item_classify::ItemClassifyService::Stub stub(&channel);
  reco::item_classify::ItemClassifyResponse response;
  std::pair<uint64, reco::item_classify::ItemClassifyRequest*> element;

  // 从文件中读取要上线的分类及标签列表
  std::vector<std::string> task_lines;
  if (!base::file_util::ReadFileToLines(base::FilePath(FLAGS_task_file), &task_lines)) {
    LOG(ERROR) << "少年，读文件出错了";
    return false;
  }

  std::vector<std::pair<std::string, int>> tasks;

  std::vector<std::string> tokens;
  int task_id;
  for (size_t m = 0; m < task_lines.size(); ++m) {
    tokens.clear();
    base::SplitString(task_lines[m], " ", &tokens);
    base::StringToInt(tokens[1], &task_id);
    tasks.push_back(std::make_pair(tokens[0], task_id));
  }

  uint64 item_id;
  // 分类别开始统计
  for (size_t i = 0; i < tasks.size(); ++i) {
    std::vector<double> cutting_nodes;
    std::vector<int> pos_sample_count;
    std::vector<int> neg_sample_count;

    std::vector<double> pos_sample_scores;
    double sum_pos_score = 0.0;
    int pos_count = 0;
    int neg_count = 0;
    for (size_t j = 1; j <= 10000; ++j) {
      cutting_nodes.push_back(j * 1.0/10000 - 1.0/10000);
      pos_sample_count.push_back(0);
      neg_sample_count.push_back(0);
    }

    const std::string& tag_name = tasks[i].first;
    const int task_id = tasks[i].second;
    // 从评估里面里面拉取标注数据
    std::string sql = base::StringPrintf(
            "select item_id,result from tb_label_evaluation_data where task_id=%d and result<>''", task_id);
    sql::ResultSet *res = db_manager->ExecuteQueryWithRetry(sql, 3);
    if (res == NULL) {
      LOG(ERROR) << "null resultset for sql: " << sql;
      return false;
    }
    std::vector<uint64> item_ids;
    std::unordered_map<uint64, int> items;
    while (res->next()) {
      base::StringToUint64(res->getString("item_id"), &item_id);
      item_ids.push_back(item_id);
      if(res->getString("result") == "bad") {
        items.insert(std::make_pair(item_id, 0));
      } else {
        items.insert(std::make_pair(item_id, 1));
      }
    }
    // 拉数据，朝分类服务发请求
    std::vector<reco::item_classify::RawItem> raw_items;
    reco::item_classify::ItemUtil::GetRawitem(hbase_get_item, item_ids, &raw_items);
    for (size_t j = 0; j < raw_items.size(); ++j) {
      const reco::item_classify::RawItem& raw_item = raw_items[j];
      reco::item_classify::ItemClassifyRequest* request = new reco::item_classify::ItemClassifyRequest();
      request->set_source(raw_item.source);
      request->set_title(raw_item.title);

      request->set_item_type(raw_item.item_type);

      request->set_content(raw_item.content);
      request->set_item_id(raw_item.item_id);

      // keyword and tag
      for (size_t k = 0; k < raw_item.keywords.size(); ++k) {
        request->add_keywords(raw_item.keywords[k].first);
      }
      request->set_level(2);
      request->set_is_debug(0);
      request->set_debug_level(0);

      net::rpc::RpcClientController rpc;
      rpc.SetTimeout(2000);

      stub.ClassifyItem(&rpc, request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()) {
        LOG(ERROR) << "failed: " << request->item_id()
                   << "rpc.status()=" << rpc.status() << " response.success())=" << response.success();
        continue;
      }


      double score = 0.0;

      for (int l = 0; l < response.tag_candidates_size(); ++l) {
        if (response.tag_candidates(l) == tag_name) {
          score = response.tag_score(l);
          break;
        }
      }
      int idx = static_cast<int>(score * 10000);
      if (idx >= (int)cutting_nodes.size()) idx = cutting_nodes.size() - 1;
      if (items[raw_item.item_id] > 0) {
        pos_count++;
        pos_sample_count[idx]++;

        pos_sample_scores.push_back(score);
        sum_pos_score += score;
      } else {
        neg_count++;
        neg_sample_count[idx]++;
      }
    }

    // 计算均值和标准差
    double avg_value = sum_pos_score / pos_sample_scores.size();
    double std_value = 0.0;
    for (size_t l = 0; l < pos_sample_scores.size(); ++l) {
      std_value += (pos_sample_scores[l] - avg_value) * (pos_sample_scores[l] - avg_value);
    }
    std_value = sqrt(std_value / pos_sample_scores.size());

    //
    std::vector<double> p_values;
    std::vector<double> r_values;
    p_values.resize(cutting_nodes.size());
    r_values.resize(cutting_nodes.size());
    int added_pos_count = 0;
    int added_neg_count = 0;
    for (int k = cutting_nodes.size() - 1; k >= 0; --k) {

      added_pos_count += pos_sample_count[k];
      added_neg_count += neg_sample_count[k];

      // 准确率
      p_values[k] = added_pos_count * 1.0 / (added_pos_count + added_neg_count);
      // 召回率
      r_values[k] = added_pos_count * 1.0 / pos_count;
      if (p_values[k] < FLAGS_cutting_value) {
        std::cout << tag_name << "\t" << cutting_nodes[k+1] << " " << p_values[k+1] << " " << r_values[k+1]
                  << "\n";
        break;
      }
      //      double p1 = added_pos_count * 1.0 / (added_pos_count + added_neg_count);
      //      double p2 = added_neg_count * 1.0 / (added_pos_count + added_neg_count);
      //      double entropy = -p1 * log(p1) - p2 * log(p2);
      //      double F = (1 + FLAGS_beta * FLAGS_beta) * p_values[k]
      //                 * r_values[k] / (FLAGS_beta * FLAGS_beta * p_values[k] + r_values[k]);
      //    LOG(INFO) << pos_sample_count[k] << " " << neg_sample_count[k] << " " << cutting_nodes[k] << " p=" << p_values[k]
      //              << " r=" << r_values[k]
      //              << " F=" << F << " E=" << entropy;
    }
  }
}
