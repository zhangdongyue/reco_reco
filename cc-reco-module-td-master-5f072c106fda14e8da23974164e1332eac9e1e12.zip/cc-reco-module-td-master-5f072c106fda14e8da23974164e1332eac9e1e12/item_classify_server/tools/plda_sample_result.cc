#include <iostream>
#include <string>
#include <cstdlib>
#include <unordered_map>
#include <fstream>
#include "reco/base/common/singleton.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "serving_base/mysql_util/db_conn_manager.h"

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_printf.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

#include "reco/module/item_classify_server/global_data/define.h"

DEFINE_string(hbase_item_table, "tb_reco_item", "table name");
DEFINE_int32(extract_thread_num, 8, "extract thread num");
DEFINE_string(model_file, "", "model file");
void WriteSamples(thread::BlockingQueue<std::string>* result_queue) {
  std::string buf;
  while (!result_queue->Closed() || !result_queue->Empty()) {
    int status = result_queue->TimedTake(10, &buf);

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    if (status == -1) {
      LOG(WARNING) << "result queue has been closed by other thread, must be empty " << result_queue->Size();
      break;
    }
    CHECK_EQ(status, 1) << "fucking new status: " << status;
    std::cout << buf << "\n";
  }
}


void Extract(int topic_number,
            std::unordered_map<uint64, std::vector<double>>* model,
              std::vector<uint64>* input_queue,
             thread::BlockingQueue<std::string>* result_queue,
             thread::BlockingVar<int>* finish_num) {
  std::vector<reco::item_classify::RawItem> raw_items;
  reco::HBaseGetItem hbase_pool_get_item(FLAGS_hbase_item_table, 0);

  LOG(WARNING) << "准备读取数据";
  reco::item_classify::ItemUtil::GetRawitem(&hbase_pool_get_item, *input_queue, &raw_items);

  std::unordered_map<uint64, std::string> dict;
  std::string buf_ori;
  std::string buf_sign;
  std::vector<std::string> ngrams;
  reco::item_classify::ItemClassifyFeature item_classify_feature;
  reco::item_classify::FeatureExtractor feature_extractor;
  std::vector<double> scores;
  for (int i = 0; i < (int) raw_items.size(); i++) {
    const reco::item_classify::RawItem& raw_item = raw_items[i];
    buf_ori.clear();
    buf_ori.append(raw_item.title);
    buf_ori.append("\t");
    buf_ori.append(base::Uint64ToString(raw_item.item_id));
    item_classify_feature.clear();
    feature_extractor.Extract(raw_item, &item_classify_feature);
    ngrams.clear();

    ngrams = item_classify_feature.ngram_fea;

    dict.clear();
    scores.clear();
    scores.resize(topic_number, 0.0);
    for (int j = 0; j < (int) ngrams.size(); j++) {
      uint64 sign = base::CalcTermSign(ngrams[j].c_str(),
                                       ngrams[j].size());
      auto it = model->find(sign);
      if (it == model->end()) continue;
      const std::vector<double>& score = it->second;
      for (size_t k = 0; k < score.size(); ++k) {
        scores[k] += score[k];
      }
      LOG(INFO) << scores[0];
    }
    for (size_t l = 0; l < scores.size(); ++l) {
      buf_ori.append("\t");
      buf_ori.append(base::DoubleToString(scores[l]));
    }
    result_queue->Put(buf_ori);
    LOG_EVERY_N(INFO, 1000) << i << "/" << raw_items.size();
  }
  int n = finish_num->Take() + 1;
  if (n == FLAGS_extract_thread_num) {
    result_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "generate trainning samples");

  reco::item_classify::GlobalDataIns::instance().InitFeatureDicts();
  std::vector<std::vector<uint64>*> input_queue;
  thread::BlockingVar<int> finish_num;
  thread::BlockingQueue<std::string> result_queue_feature;

  thread::ThreadPool pool(FLAGS_extract_thread_num + 1);
  pool.AddTask(::NewCallback(WriteSamples, &result_queue_feature));
  CHECK(finish_num.TryPut(0));

  std::string line;
  uint64 item_id;

  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    input_queue.push_back(new std::vector<uint64>());
  }

  while (std::getline(std::cin, line)) {
    if (line.size() < 3) continue;
    base::StringToUint64(line, &item_id);
    input_queue[item_id % FLAGS_extract_thread_num]->push_back(item_id);
  }
  std::unordered_map<uint64, std::vector<double>> model;
  LOG(INFO) << "读入模型";
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_model_file), &lines)) << FLAGS_model_file;
  std::vector<std::string> tokens;
  std::vector<double> scores;
  double score;
  uint64 sign;
  int topic_number = 0;
  for (size_t j = 0; j < lines.size(); ++j) {
    tokens.clear();
    base::SplitString(lines[j], " ", &tokens);

    scores.clear();
    base::StringToUint64(tokens[0], &sign);
    if ((int) tokens.size() - 1 > topic_number) {
      topic_number = (int) tokens.size() - 1;
    }
    for (size_t i = 1; i < tokens.size(); ++i) {
      base::StringToDouble(tokens[i], &score);
      scores.push_back(score);
    }
    model.insert(std::make_pair(sign, scores));
  }
  LOG(INFO) << "线程开始启动";
  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    pool.AddTask(::NewCallback(Extract, topic_number, &model, input_queue[i], &result_queue_feature,  &finish_num)); // NOLINT
  }
  pool.JoinAll();
}
