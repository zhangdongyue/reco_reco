#include <unordered_map>
#include <iostream>
#include <fstream>
#include <set>
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "nlp/common/nlp_util.h"
#include "base/file/dir_reader_posix.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/hash_function/term.h"
#include "base/common/closure.h"

DEFINE_string(source_title_file, "source_title.txt", "source title file");
DEFINE_string(input_dir, "./data", "inputdata dir");
DEFINE_string(out_dir, "./out_data", "output data dir");
void LoadSourceTitle(const std::string& filename, std::unordered_map<uint64, std::string>* source_dict,
                     std::unordered_map<uint64, std::set<uint64>>* title_dict) {
  std::ifstream fin(filename);
  std::string line;
  std::vector<std::string> flds;
  while (std::getline(fin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 2 || flds[1].size() < 2) continue;

    nlp::util::NormalizeLineInPlaceS(&flds[0]);
    nlp::util::NormalizeLineInPlaceS(&flds[1]);

    uint64 sign = base::CalcTermSign(flds[1].data(), flds[1].size());
    uint64 source_sign = base::CalcTermSign(flds[0].data(), flds[0].size());

    source_dict->insert(std::make_pair(source_sign, flds[0]));

    auto it_pair = title_dict->insert(std::make_pair(sign, std::set<uint64>()));
    it_pair.first->second.insert(source_sign);
  }
}

void MergeWorker(std::string filename,
                 std::unordered_map<uint64, std::set<uint64>>* title_dict,
                 std::unordered_map<uint64, std::string>* source_dict) {
  std::string input = FLAGS_input_dir + "/" + filename;
  std::string output = FLAGS_out_dir+ "/" + filename;
  std::ifstream fin(input);
  std::ofstream fout(output);

  std::string line;
  int num = 0;
  while (std::getline(fin, line)) {
    nlp::util::NormalizeLineInPlaceS(&line);

    uint64 sign = base::CalcTermSign(line.data(), line.size());
    auto it = title_dict->find(sign);
    std::string source = "神马早知道";
    if (it != title_dict->end()) {
      for (auto it2 = it->second.begin(); it2 != it->second.end(); ++it2) {
        auto it3 = source_dict->find(*it2);
        CHECK(it3 != source_dict->end()) << *it2;
        fout << base::StringPrintf("%s\t%s\n", it3->second.c_str(), line.c_str());
      }
    } else {
      fout << base::StringPrintf("神马早知道\t%s\n", line.c_str());
    }

    if (++num > 10000) {;
      LOG(INFO) << base::StringPrintf("deal %d for filename:%s", num, filename.c_str());
      num = 0;
    }
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "mege source title");
  // load soure, title, category file
  std::unordered_map<uint64, std::string> source_dict;
  std::unordered_map<uint64, std::set<uint64>> title_dict;
  LoadSourceTitle(FLAGS_source_title_file, &source_dict, &title_dict);

  if (base::DirReaderPosix::IsFallback()) {
    LOG(ERROR) << "dir fall back";
    return -1;
  }

  base::DirReaderPosix reader(FLAGS_input_dir.c_str());
  CHECK(reader.IsValid());
  thread::ThreadPool pool(32);
  for (; reader.Next(); ) {
    std::string name = reader.name();
    if (name.find(".txt") == std::string::npos) continue;
    pool.AddTask(::NewCallback(MergeWorker, name, &title_dict, &source_dict));
  }
  pool.JoinAll();
}
