#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <unordered_map>
#include <unordered_set>
#include <set>

#include <map>
#include "nlp/common/nlp_util.h"
#include "base/strings/string_split.h"
#include "base/common/gflags.h"
#include "base/common/base.h"

#include "extend/static_dict/dawg/dawg.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"
#include "base/strings/string_number_conversions.h"

DEFINE_string(input, "word_tag_all.txt", "input file");
DEFINE_string(output, "word_tags.bin", "output file");
int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "pakcage word tags file");
  // word tags
  std::string line;
  std::vector<std::string> tokens;

  std::string word;
  std::string tags;
  std::string tag_type;   // 1 = 高级特征用的标记 2 = postclassify 用到的 flag
  std::string tagWithtype;  // example :1 # 政治人物

  dawgdic::Dictionary word_tag_dict_;
  std::vector<std::string> word_tags_list_;

  std::unordered_map<std::string, int> word_tag_id;

  std::map<std::string, std::set<std::string>> word_tags;

  std::ifstream fin(FLAGS_input);

  int tagid;

  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    word = tokens[0];
    tags = tokens[1];
    tag_type = tokens[2];

    nlp::util::NormalizeLineInPlaceS(&word);

    if (word == "") continue;
    if (tokens.size() != 3) {
      LOG(ERROR) << line << " can not be converted into wordTAG ::" << tokens.size();
      continue;
    }
    tokens.clear();
    base::SplitString(tags, "|", &tokens);
    for (int idx = 0; idx < (int) tokens.size(); idx++) {
      const std::string& tag = tokens[idx];
      if (tag == "") continue;
      tagWithtype = tag_type + "#" + tag;
      auto it_pair = word_tags.insert(std::make_pair(word, std::set<std::string>()));
      it_pair.first->second.insert(tagWithtype);
    }
  }

  LOG(INFO) << "word size: " << word_tags.size();
  dawgdic::DawgBuilder builder;
  for (auto it = word_tags.begin(); it != word_tags.end(); ++it) {
    tags = base::JoinStrings(std::vector<std::string>(it->second.begin(), it->second.end()), "|");

    auto it_tag = word_tag_id.find(tags);
    if (it_tag != word_tag_id.end()) {
      tagid = it_tag->second;
    } else {
      word_tags_list_.push_back(tags);
      tagid = word_tags_list_.size() - 1;
      word_tag_id.insert(std::make_pair(tags, tagid));
    }
    CHECK(builder.Insert(it->first.c_str(), tagid));
  }
  dawgdic::Dawg dawg;
  CHECK(builder.Finish(&dawg));
  dawgdic::DictionaryBuilder::Build(dawg, &word_tag_dict_);
  LOG(INFO) << "finish building dict word_tag_dict_=" << word_tag_dict_.size();
  std::ofstream fout(FLAGS_output);
  word_tag_dict_.Write(&fout);
  LOG(INFO) << "finish writting dict word_tag_dict_=" << word_tag_dict_.size();

  std::string buf;
  base::FastJoinStrings(word_tags_list_, "\t", &buf);
  uint32 len = buf.size();
  fout.write(reinterpret_cast<char*>(&len), sizeof(len));
  LOG(INFO) << " write all category: " << buf;
  fout.write(buf.c_str(), buf.size());

  fout.close();
  LOG(INFO) << "finish writting word_tag_id word_tag_id=" << word_tag_id.size();
}
