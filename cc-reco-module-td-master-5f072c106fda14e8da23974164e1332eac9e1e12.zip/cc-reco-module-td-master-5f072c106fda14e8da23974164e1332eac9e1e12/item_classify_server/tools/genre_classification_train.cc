#include <fstream>
#include <string>
#include <unordered_map>
#include <vector>

#include "nlp/common/nlp_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"

#include "reco/module/item_classify_server/common/item_util.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/define.h"

DEFINE_string(input, "id.txt", "id file");
DEFINE_string(hbase_item_table, "tb_reco_item", "table name");
DEFINE_string(pos_sample_flag, "+", "pos_sample_flag");
DEFINE_string(neg_sample_flag, "-", "neg_sample_flag");

DEFINE_string(genre, "小说", " ");

DEFINE_string(data_dir, "../data", "data dir");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "文正体裁分类样本抽取");
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_input), &lines));
  std::unordered_map<uint64, int> item_ids;
  std::vector<uint64> pre_item_ids;
  uint64 item_id;

  for (int i = 0; i < (int) lines.size(); i++) {
    std::string &line = lines[i];
    nlp::util::NormalizeLineInPlaceS(&line);
    int label = 0;
    if (line.find(FLAGS_pos_sample_flag) != std::string::npos) {
      label = 1;
      line = line.substr(1);
    }
    if (line.find(FLAGS_neg_sample_flag) != std::string::npos) {
      label = -1;
      line = line.substr(1);
    }
    if (base::StringToUint64(line, &item_id)) {
      item_ids.insert(std::make_pair(item_id, label));
      pre_item_ids.push_back(item_id);
    }
  }
  LOG(INFO) << "特征抽取";
  std::vector<reco::item_classify::RawItem> items;
  reco::HBaseGetItem get_item(FLAGS_hbase_item_table);
  reco::item_classify::ItemUtil::GetRawitem(&get_item, pre_item_ids, &items);

  reco::item_classify::ItemClassifyFeature item_classify_feature;
  reco::item_classify::FeatureExtractor feature_extractor;
  std::string buf;
  std::unordered_map<std::string, int> dict;
  std::string buf_dict;

  std::vector<std::pair<uint64, float>> sign_features;
  for (size_t k = 0; k < items.size(); ++k) {
    item_classify_feature.clear();
    feature_extractor.Extract(items[k], &item_classify_feature);
    sign_features.clear();
    // 统计特征
    const std::vector<std::pair<std::string, float> >& features =
        item_classify_feature.stat_fea;
    for (size_t i = 0; i < features.size(); ++i) {
      const std::string &feature_name = features.at(i).first;
      auto it = dict.find(feature_name);
      if (it != dict.end()) {
        sign_features.push_back(std::make_pair(it->second, features.at(i).second));
      } else {
        sign_features.push_back(std::make_pair(dict.size() + 1, features.at(i).second));
        dict.insert(std::make_pair(feature_name, dict.size() + 1));
      }
    }
    // ngram 特征
    // item_classify_feature.GetFlagFeature(reco::item_classify::FeatureType::kTitle, &ngram_features);
    // item_classify_feature.GetFlagFeature(reco::item_classify::FeatureType::kKeyword, &ngram_features);
    // item_classify_feature.GetFlagFeature(reco::item_classify::FeatureType::kLabelTitle, &ngram_features);
    // for (size_t i = 0; i < ngram_features.size(); ++i) {
    //   const std::string &feature_name = ngram_features[i];
    //   auto it = dict.find(feature_name);
    //   if (it != dict.end()) {
    //     sign_features.push_back(std::make_pair(it->second, 1.0));
    //   } else {
    //     sign_features.push_back(std::make_pair(dict.size() + 1, 1.0));
    //     dict.insert(std::make_pair(feature_name, dict.size() + 1));
    //   }
    // }
    std::sort(sign_features.begin(), sign_features.end(), std::less<std::pair<uint64, float >> ());
    // buf.append("1 ");
    if (item_ids[items[k].item_id] < 0) {
      buf.append("0");
    } else {
      buf.append("1");
    }
    for (size_t j = 0; j < sign_features.size(); ++j) {
      buf.append(base::StringPrintf(" %lu:%f", sign_features[j].first, sign_features[j].second));
    }
    buf.append("\n");
    LOG_EVERY_N(INFO, 10) << k;
  }
  LOG(INFO) << "dict.size()=" << dict.size();
  for (auto it = dict.begin(); it != dict.end(); ++it) {
    buf_dict.append(base::StringPrintf("%d %s\n", it->second, it->first.c_str()));
  }
  std::ofstream fout("result/" + FLAGS_genre + "_sample.txt");
  fout << buf;
  fout.close();
  std::ofstream fout_dict("result/" + FLAGS_genre + "_dict.txt");
  fout_dict << buf_dict;
  fout_dict.close();
}
