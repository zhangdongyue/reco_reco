cate = open("all_category.txt")
new_cate = open("new.txt", 'a')
tmp = []

while True:
  line = cate.readline().strip()
  if not line:
    break
  elements = line.split(',')
  tmp.append(elements[0])
tmp = set(tmp)
print len(tmp)
for i in tmp:
  new_cate.write('\"' + i + '\"' + ',')

