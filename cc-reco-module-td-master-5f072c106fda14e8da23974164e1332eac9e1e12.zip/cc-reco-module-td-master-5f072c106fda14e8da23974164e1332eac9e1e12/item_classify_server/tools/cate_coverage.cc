#include <fstream>
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_split.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_util.h"

#include "serving_base/utility/time_helper.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "reco/module/item_classify_server/global_data/define.h"


DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table");

DEFINE_int32(thread_num, 8, "thread num");
DEFINE_int32(stat_days, 2, "stat in last XXX days");
DEFINE_int32(skip_days, 1, "stat in last XXX days");
DEFINE_int32(limit, 20000, "max return number");

DEFINE_string(result_file, "result.txt", "the output file");
DEFINE_string(cate, "财经", "the output file");

void Stat(int group_idx, serving_base::mysql_util::DbConnManager* db_manager,
          thread::BlockingQueue<std::string>* result_data,
          thread::BlockingVar<int>* finish_num) {
  uint64 timestamp1 = 0;
  uint64 timestamp2 = 0;

  std::string time_str1;
  std::string time_str2;

  std::vector<uint64> id_vector;
  reco::HBaseGetItem* hbase_get_item = new reco::HBaseGetItem(FLAGS_hbase_item_table);
  std::vector<reco::RecoItem> reco_items;
  for (int i = group_idx; i < FLAGS_stat_days;  i += FLAGS_thread_num ) {

    CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond, &timestamp1));
    timestamp1 -= i * 24 * 3600 * 1000000lu * FLAGS_skip_days;  // last 30 days
    timestamp2 = timestamp1 -  24 * 3600 * 1000000lu;  // last 30 days


    CHECK(serving_base::TimeHelper::TimestampToString(timestamp1, serving_base::TimeHelper::kDay, &time_str1));
    CHECK(serving_base::TimeHelper::TimestampToString(timestamp2, serving_base::TimeHelper::kDay, &time_str2));

    // 拉取数据
    std::string sql = "select item_id from tb_item_info_tddl where item_type<>30 and create_time >'" +
                      time_str2 +"' and  create_time <'"+ time_str1
                      +"' and category<>'未分类' order by item_id desc limit " +
                      base::IntToString(FLAGS_limit); //NOLINT
    if (FLAGS_cate != "all") {
      sql = base::StringReplace(sql, "where", "where category like '"+FLAGS_cate+"%' and", true);
    }
    sql::ResultSet* res = db_manager->ExecuteQueryWithRetry(sql, 3);
    if (res == NULL) {
      LOG(ERROR) << "FAILED in reading data" << sql;
      return;
    }
    id_vector.clear();
    while (res->next()) {
      const std::string item_id = res->getString("item_id");
      id_vector.push_back(base::ParseUint64OrDie(item_id));
    }

    reco_items.clear();
    hbase_get_item->GetRecoItems(id_vector, &reco_items);
    int count_all = reco_items.size();
    int count_sub_cate = 0;
    int count_tag = 0;
    int count_tag_item =0;
    for (size_t j = 0; j < reco_items.size(); ++j) {
      if (reco_items[j].category_size() > 1) count_sub_cate++;
      if (reco_items[j].semantic_tag().feature_size() > 0) count_tag_item++;
      count_tag += reco_items[j].semantic_tag().feature_size();
    }

    std::string result = base::StringPrintf("%s\t%2.4f\t%2.4f\t%2.4f", time_str1.c_str(), count_sub_cate * 100.0  / count_all,
                                           count_tag_item * 100.0 / count_all, count_tag * 100.0 /count_all);
    LOG(INFO) << result;
    result_data->Put(result);
  }

  int n = finish_num->Take() + 1;
  if (n == FLAGS_thread_num) {
    result_data->Close();
  }
  finish_num->TryPut(n);
}

static void SaveResult(std::string filename, thread::BlockingQueue<std::string>* result_queue) {
  std::ofstream fout(filename);
  std::string buf;
  while (!(result_queue->Closed() && result_queue->Empty())) {
    if (result_queue->Empty()) {
      base::SleepForSeconds(1);
      continue;
    }

    if (!result_queue->Take(&buf)) break;
    fout << buf << std::endl;
  }
}
int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "Category Coverage");
  LOG(INFO) << "程序开始启动喽~~~";

  thread::ThreadPool pool(FLAGS_thread_num + 1);
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;

  serving_base::mysql_util::DbConnManager* db_manager =
          new serving_base::mysql_util::DbConnManager(db_option);


  thread::BlockingQueue<std::string> result_data;
  thread::BlockingVar<int> finish_num;
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(&Stat, i, db_manager, &result_data, &finish_num));
  }

  pool.AddTask(::NewCallback(&SaveResult, FLAGS_result_file, &result_data));

  pool.JoinAll();

  delete db_manager;
}
