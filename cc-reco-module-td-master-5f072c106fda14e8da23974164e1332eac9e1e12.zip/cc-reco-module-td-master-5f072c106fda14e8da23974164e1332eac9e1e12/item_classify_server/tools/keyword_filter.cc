#include <string>
#include <vector>
#include <unordered_set>
#include <iostream>
#include <fstream>

#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"

DEFINE_string(bad_model, "bad_keyword.txt", "");
DEFINE_int32(keyword_fld, 3, "keyword fld");
DEFINE_int32(title_fld, 1, "title fld");
DEFINE_int32(thread_num, 2, "thread num");

void DetectKeyword(std::unordered_set<std::string>* dict, thread::BlockingQueue<std::string>* input_queue,
                   thread::BlockingQueue<std::string>* out_queue, thread::BlockingVar<int>* finish_num)  {
  std::string line;
  std::vector<std::string> tokens;
  std::vector<std::string> terms;
  while (!input_queue->Closed() || !input_queue->Empty()) {
    int status = input_queue->TimedTake(10, &line);
    if (status == 0) {
      continue;
    }
    if (status == -1) break;

    if (status != 1) {
      LOG(ERROR) << base::StringPrintf("erro status: %d", status);
      continue;
    }

    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if ((int)tokens.size() <= FLAGS_keyword_fld) {
      continue;
    }

    terms.clear();
    base::SplitString(tokens[FLAGS_keyword_fld], "|", &terms);
    if (terms.size() == 0) continue;

    bool find = false;
    std::string bigram;
    for (int i = 0; i < (int)terms.size(); ++i) {
      if (dict->find(terms[i]) != dict->end()) {
        find = true;
        break;
      }

      for (int j = i + 1; j < (int)terms.size(); ++j) {
        if (terms[i] < terms[j]) {
          bigram = base::StringPrintf("%s\t%s", terms[i].c_str(), terms[j].c_str());
        } else {
          bigram = base::StringPrintf("%s\t%s", terms[j].c_str(), terms[i].c_str());
        }
        if (dict->find(bigram) != dict->end()) {
          find = true;
          break;
        }
      }
      if (find) break;
    }
    if (find) {
      out_queue->Put(line);
    }
  }
  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    out_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

void OutWorker(thread::BlockingQueue<std::string>* out_queue) {
  std::string line;
  while (!out_queue->Closed() || !out_queue->Empty()) {
    int status = out_queue->TimedTake(10, &line);
    if (status == 0) {
      continue;
    }
    if (status == -1) break;

    if (status != 1) {
      LOG(ERROR) << base::StringPrintf("erro status: %d", status);
      continue;
    }
    std::cout << line << "\n";
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "keyword filter");
  std::unordered_set<std::string> keyword_dict;
  // load bad keyword
  std::ifstream fin(FLAGS_bad_model);
  std::string line;
  std::vector<std::string> tokens;
  while (std::getline(fin, line)) {
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 4) continue;
    int n = tokens.size() - 3;
    if (n == 1) {
      keyword_dict.insert(tokens[1]);
    } else {
      keyword_dict.insert(base::StringPrintf("%s\t%s", tokens[1].c_str(), tokens[2].c_str()));
    }
  }

  thread::BlockingQueue<std::string> input_queue;
  thread::BlockingQueue<std::string> out_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  thread::ThreadPool pool(FLAGS_thread_num + 1);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(DetectKeyword, &keyword_dict, &input_queue, &out_queue, &finish_num));
  }
  pool.AddTask(::NewCallback(OutWorker, &out_queue));

  // read data to input queue
  while (std::getline(std::cin, line)) {
    input_queue.Put(line);
  }
  input_queue.Close();
  pool.JoinAll();
}
