#include <iostream>
#include <string>
#include <cstdlib>
#include <unordered_map>
#include <fstream>
#include "reco/base/common/singleton.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "serving_base/mysql_util/db_conn_manager.h"

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_printf.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

#include "reco/module/item_classify_server/global_data/define.h"
#include "../feature/item_classify_feature.h"

DEFINE_string(hbase_item_table, "tb_reco_item", "table name");
DEFINE_int32(extract_thread_num, 8, "extract thread num");

void WriteSamples(thread::BlockingQueue<std::string>* result_queue) {
  std::string buf;
  while (!result_queue->Closed() || !result_queue->Empty()) {
    int status = result_queue->TimedTake(10, &buf);

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    if (status == -1) {
      LOG(WARNING) << "result queue has been closed by other thread, must be empty " << result_queue->Size();
      break;
    }
    CHECK_EQ(status, 1) << "fucking new status: " << status;
    std::cout << buf << "\n";
  }
}

void Extract(thread::BlockingQueue<uint64>* input_queue,
             thread::BlockingQueue<std::string>* result_queue,
             thread::BlockingQueue<std::pair<std::string, uint64>>* dict_quence,
             thread::BlockingVar<int>* finish_num) {
  reco::HBaseGetItem hbase_pool_get_item(FLAGS_hbase_item_table, 0);

  LOG(WARNING) << "准备读取数据";
  std::vector<reco::RecoItem> reco_items;
  std::vector<uint64> item_ids;

  std::string buf_ori;
  reco::item_classify::ItemBasicFeature item_feature;
  reco::item_classify::ItemBasicFeatureExtractor feature_extractor;

  reco::item_classify::RawItem raw_item;
  std::string tag_name;
  uint64 item_id;
  int k = 0;
  while (input_queue->Closed() || !input_queue->Empty()) {
    int status = input_queue->TimedTake(10, &item_id);

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    if (status == -1) {
      LOG(WARNING) << "result queue has been closed by other thread, must be empty " << result_queue->Size();
      break;
    }
    item_ids.push_back(item_id);
    if (item_ids.size() <= 100) continue;

    reco_items.clear();
    hbase_pool_get_item.GetRecoItems(item_ids, &reco_items);
    item_ids.clear();
    for (int i = 0; i < (int) reco_items.size(); i++) {
      buf_ori.clear();
      raw_item.clear();
      raw_item.title = reco_items[i].normalized_title();
      k ++;
      feature_extractor.Extract(raw_item, &item_feature);
      for (size_t j = 0; j < item_feature.title_unigrams_ordered_words.size(); j++) {
        if (j != 0) buf_ori.append(" ");
        buf_ori.append(item_feature.title_unigrams_ordered_words[j]);
      }

      for (int j = 0; j < reco_items[i].tag().feature_size(); j++) {
        tag_name.clear();
        base::FastStringReplace(reco_items[i].tag().feature(j).literal(), "label:", "", true, &tag_name);
        buf_ori.append(" ");
        buf_ori.append(tag_name);
      }
      LOG_EVERY_N(INFO, 1000) << k * FLAGS_extract_thread_num;
      result_queue->Put(buf_ori);
    }
  }
  int n = finish_num->Take() + 1;
  if (n == FLAGS_extract_thread_num) {
    result_queue->Close();
    dict_quence->Close();
  }
  CHECK(finish_num->TryPut(n));
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "generate trainning samples");

  reco::item_classify::GlobalDataIns::instance().InitFeatureDicts();
  thread::BlockingQueue<uint64> input_queue;
  thread::BlockingVar<int> finish_num;
  thread::BlockingQueue<std::string> result_queue_feature;
  thread::BlockingQueue<std::pair<std::string, uint64>> result_queue_dict;

  thread::ThreadPool pool(FLAGS_extract_thread_num + 1);
  pool.AddTask(::NewCallback(WriteSamples, &result_queue_feature));
  CHECK(finish_num.TryPut(0));

  std::string line;
  uint64 item_id;

  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    pool.AddTask(::NewCallback(Extract, &input_queue, &result_queue_feature, &result_queue_dict, &finish_num));
  }

  while (std::getline(std::cin, line)) {
    if (line.size() < 3) continue;
    base::StringToUint64(line, &item_id);
    input_queue.Put(item_id);
  }
  LOG(INFO) << "线程开始启动";
  pool.JoinAll();
}
