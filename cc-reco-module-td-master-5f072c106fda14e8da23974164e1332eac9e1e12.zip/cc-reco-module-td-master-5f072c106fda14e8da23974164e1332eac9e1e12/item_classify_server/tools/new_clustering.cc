#include <iostream>
#include <string>
#include <cstdlib>
#include <unordered_map>
#include <fstream>
#include <math.h>

#include "reco/base/common/singleton.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "serving_base/mysql_util/db_conn_manager.h"

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_printf.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

#include "reco/module/item_classify_server/global_data/define.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/feature/item_feature_common.h"
#include "../feature/item_classify_feature.h"
#include "../feature/item_feature_common.h"

DEFINE_string(hbase_item_table, "tb_reco_item", "table name");
DEFINE_int32(extract_thread_num, 8, "extract thread num");
DEFINE_string(cate_file, "cates.txt", "cate list file");

DEFINE_string(parent_cate, "社会", "");
DEFINE_bool(only_empty, true, "是否只用未分类数据");

DEFINE_int32(cluster_num, 60, "extract thread num");
DEFINE_int32(max_interations, 500, "extract thread num");

void Extract(std::vector<uint64>* input_queue,
             thread::BlockingQueue<reco::item_classify::RawItem>* result_queue,
             thread::BlockingVar<int>* finish_num) {
  std::vector<reco::item_classify::RawItem> raw_items;
  reco::HBaseGetItem hbase_pool_get_item(FLAGS_hbase_item_table, 0);

  LOG(WARNING) << "准备读取数据";
  reco::item_classify::ItemUtil::GetRawitem(&hbase_pool_get_item, *input_queue, &raw_items);
  for (int i = 0; i < (int) raw_items.size(); i++) {
    if (FLAGS_parent_cate == "root") {
      if (FLAGS_only_empty && raw_items[i].category != "未分类") continue;
    } else {
      if (raw_items[i].category.find(FLAGS_parent_cate) == std::string::npos
          || (raw_items[i].category.find(",") != std::string::npos && FLAGS_only_empty))
        continue;
    }
    result_queue->Put(raw_items[i]);
  }
  int n = finish_num->Take() + 1;
  if (n == FLAGS_extract_thread_num) {
    result_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

void AssignIdx(std::vector<std::vector<std::pair<int, float>>>* items_fea,
               std::vector<int>* cluster_idx,
               std::vector<std::vector<float>>* cluster_point,
               int group_idx) {
  for (size_t i = 0; i < cluster_idx->size(); ++i) {
    if ((int) i % FLAGS_cluster_num != group_idx) continue;

    const auto& item_fea = items_fea->at(i);
    float max_sim = 0.0;
    int max_idx = -1;
    for (size_t j = 0; j < cluster_point->size(); ++j) {
      float dis = 0;
      for (size_t k = 0; k < item_fea.size(); ++k) {
        dis += item_fea[k].second * cluster_point->at(j)[item_fea[k].first];
      }
      if (dis >= max_sim) {
        max_sim = dis;
        max_idx = j;
      }
    }
    cluster_idx->at(i) = max_idx;
  }
}

void GetClusterPoint(std::vector<std::vector<std::pair<int, float>>>* items_fea,
                     std::vector<int>* cluster_idx,
                     std::vector<std::vector<float>>* cluster_point,
                     int group_idx) {
  std::vector<float> point(reco::item_classify::kLDAMaxTopicNumber);
  for (size_t i = 0; i < cluster_idx->size(); ++i) {
    if (cluster_idx->at(i) != group_idx) continue;
    const auto& item_fea = items_fea->at(i);
    for (size_t j = 0; j < item_fea.size(); ++j) {
      point[item_fea[j].first] += item_fea[j].second;
    }
  }
  float sum = 0.0f;
  for (size_t k = 0; k < point.size(); ++k) {
    sum += point[k] * point[k];
  }
  for (size_t k = 0; k < point.size(); ++k) {
    point[k] /= sqrt(sum);
  }
  cluster_point->at(group_idx) = point;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "generate trainning samples");

  std::vector<std::vector<uint64>*> input_queue;
  thread::BlockingVar<int> finish_num;
  thread::BlockingQueue<reco::item_classify::RawItem> result_queue_feature;

  std::string line;
  uint64 item_id;
  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    input_queue.push_back(new std::vector<uint64>());
  }

  while (std::getline(std::cin, line)) {
    if (line.size() < 3) continue;
    base::StringToUint64(line, &item_id);
    input_queue[item_id % FLAGS_extract_thread_num]->push_back(item_id);
  }

  thread::ThreadPool pool(FLAGS_extract_thread_num + 1);
  CHECK(finish_num.TryPut(0));

  LOG(INFO) << "线程开始启动";
  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    pool.AddTask(
            ::NewCallback(Extract, input_queue[i], &result_queue_feature, &finish_num)); // NOLINT
  }
  pool.JoinAll();
  std::vector<reco::item_classify::RawItem> items;
  std::vector<std::vector<std::pair<int, float>>> items_fea;

  std::vector<int> cluster_idx;
  std::vector<std::vector<float>> cluster_point;


  int topic_index;
  std::vector<std::string> tokens;

  while (!result_queue_feature.Empty()) {
    reco::item_classify::RawItem item;
    result_queue_feature.Take(&item);
    items.push_back(item);

    cluster_idx.push_back(-1);
    std::vector<std::pair<int, float>> fea;
    for (size_t i = 0; i < item.title_lda_topics.size(); ++i) {
      tokens.clear();
      base::SplitString(item.title_lda_topics[i].first, "-", &tokens);
      base::StringToInt(tokens[1], &topic_index);

      fea.push_back(std::make_pair(topic_index, item.title_lda_topics[i].second));
    }

    items_fea.push_back(fea);
  }
  base::PseudoRandom* pseudo_random = new base::PseudoRandom();
  // 产生一个随机中心
  for (int i = 0; i < FLAGS_cluster_num; ++i) {
    std::vector<float> point(reco::item_classify::kLDAMaxTopicNumber);
    for (size_t j = 0; j < reco::item_classify::kLDAMaxTopicNumber / 2; ++j) {
      int idx = pseudo_random->GetInt(0, reco::item_classify::kLDAMaxTopicNumber);
      point[idx] = pseudo_random->GetDouble();
    }
    float sum = 0.0f;
    for (size_t k = 0; k < point.size(); ++k) {
      sum += point[k];
    }
    for (size_t l = 0; l < point.size(); ++l) {
      point[l] /= sqrt(sum);
    }
    cluster_point.push_back(point);
  }
  for (int k = 0; k < FLAGS_max_interations; ++k) {
    thread::ThreadPool pool_c(FLAGS_cluster_num);
    LOG(INFO) << "第 " << k << "次迭代";
    // 每一个点分到一个簇
    for (int i = 0; i < FLAGS_cluster_num; ++i) {
      pool_c.AddTask(
              ::NewCallback(AssignIdx, &items_fea, &cluster_idx, &cluster_point, i)); // NOLINT
    }
    pool_c.JoinAll();
    thread::ThreadPool pool_d(FLAGS_cluster_num);
    // 计算簇的中心
    for (int i = 0; i < FLAGS_cluster_num; ++i) {
      pool_d.AddTask(
              ::NewCallback(GetClusterPoint, &items_fea, &cluster_idx, &cluster_point, i)); // NOLINT
    }
    pool_d.JoinAll();
  }
  for (int i = 0; i < FLAGS_cluster_num; ++i) {
    std::cout << "簇:" << i << "\n";
    for (size_t m = 0; m < cluster_idx.size(); ++m) {
      if (cluster_idx[m] != i) continue;
      std::cout << cluster_idx[m] << "\t" << items[m].category << "\t" << items[m].title << "\t" << items[m].item_id
                << "\n";
    }
  }
}
