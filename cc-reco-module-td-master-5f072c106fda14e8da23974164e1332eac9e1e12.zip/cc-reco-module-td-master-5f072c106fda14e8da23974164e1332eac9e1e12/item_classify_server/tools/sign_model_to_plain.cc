#include <iostream>
#include <string>
#include <cstdlib>
#include <unordered_map>
#include <fstream>
#include <base/container/dense_hash_map.h>
#include "reco/base/common/singleton.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "serving_base/mysql_util/db_conn_manager.h"

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "base/strings/string_split.h"
#include "base/container/dense_hash_map.h"

#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_printf.h"
#include "base/file/dir_reader_posix.h"


DEFINE_string(sign_dict, "dict.txt", "dict_file");
DEFINE_string(input_dir, "input dir for sign model", "input dir");
DEFINE_int32(thread_num, 4, "thread_num for thransfer one file");
DEFINE_int32(load_thread_num, 4, "thread_num for thransfer one file");
void GetFileList(const base::FilePath& dir, std::vector<std::string>* file_list) {
  base::DirReaderPosix reader(dir.value().c_str());
  CHECK(reader.IsValid());

  for (; reader.Next(); ) {
    std::string filename(reader.name());
    if (filename[0] == '.') continue;
    if (filename.find(".txt") != std::string::npos) continue;

    LOG(INFO) << "find file: " << filename;
    file_list->push_back(filename);
  }
}

void KeyValueGenerator(int start, int thread_num, std::vector<std::string>* lines,
                       thread::BlockingQueue<std::pair<uint64, std::string> >* key_value_queue,
                       thread::BlockingVar<int>* finish_num) {
  std::vector<std::string> flds;
  std::pair<uint64, std::string> key_value;
  std::ifstream fin(FLAGS_sign_dict);
  for (int i = start; i < (int)lines->size(); i += thread_num) {
    flds.clear();
    base::SplitString((*lines)[i], "\t", &flds);
    if (flds.size() < 2) continue;

    if (!base::StringToUint64(flds[0], &key_value.first)) continue;

    key_value.second.clear();
    for (size_t j = 1; j < flds.size(); ++j) {
      if (!key_value.second.empty()) key_value.second.append("\t");
      key_value.second.append(flds[j]);
    }
    // LOG(INFO) << "put " <<  key_value.first << " " << key_value.second;
    key_value_queue->Put(key_value);
    LOG_FIRST_N(INFO, 10) << i << "/" << lines->size();
  }
  int n = finish_num->Take() + 1;
  if (n >= thread_num) {
    key_value_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}
void LoadDict(const base::FilePath& path, base::dense_hash_map<uint64, std::string>* dict) {
  std::vector<std::string> lines;
  LOG(INFO) << "begin to read sign file";
  CHECK(base::file_util::ReadFileToLines(path, &lines));
  LOG(INFO) << "finish reading sign file" << lines.size();
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  thread::BlockingQueue<std::pair<uint64, std::string>> key_value_queue;
  thread::ThreadPool pool(FLAGS_load_thread_num);
  for (int i = 0; i < FLAGS_load_thread_num; ++i) {
    pool.AddTask(::NewCallback(&KeyValueGenerator, i, FLAGS_load_thread_num, &lines, &key_value_queue, &finish_num));
  }
  std::pair<uint64, std::string> ele;
  std::deque<std::pair<uint64, std::string>> elements;
  while (!(key_value_queue.Empty() && key_value_queue.Closed())) {
    key_value_queue.TimedMultiTake(10, &elements);
    for (size_t j = 0; j < elements.size(); ++j) {
      dict->insert(elements[j]);
    }
    elements.clear();
  }
  LOG(INFO) << dict->size();
  pool.JoinAll();

  LOG(INFO) << "finish load dict" << dict->size();
}

void TransWorker(std::string category,
                 thread::BlockingQueue<std::string>* input_queue,
                 std::vector<std::pair<double, int> >* fea_weight,
                 std::vector<std::string>* fea_literal,
                 base::dense_hash_map<uint64, std::string>* dict) {
  std::string line;
  std::vector<std::string> flds;
  uint64 sign = 0;
  double weight = 0;
  while (!(input_queue->Closed() && input_queue->Empty())) {
    if (!input_queue->Take(&line)) break;
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 2) continue;

    if (!base::StringToUint64(flds[0], &sign)) {
      LOG(ERROR) << "erro sign " << line;
      continue;
    }

    if (!base::StringToDouble(flds[1], &weight)) {
      LOG(ERROR) << "erro weight " << line;
      continue;
    }
    auto it = dict->find(sign);
    if (it == dict->end()) {
      LOG(ERROR) << "miss key" << line;
      continue;
    }

    fea_weight->push_back(std::make_pair(weight, fea_weight->size()));
    fea_literal->push_back(base::StringPrintf("%s\t%s", it->second.c_str(), category.c_str()));
  }
  std::sort(fea_weight->begin(), fea_weight->end(), std::greater<std::pair<double, int> >());
}

void Transform(base::FilePath dir, std::string filename, std::string category,
               base::dense_hash_map<uint64, std::string>* sign_dict) {
  thread::BlockingQueue<std::string> input_queue;
  thread::BlockingQueue<std::string> out_queue;
  thread::ThreadPool pool(FLAGS_thread_num);

  std::vector<std::vector<std::pair<double, int> > > fea_weight_matrix(FLAGS_thread_num);
  std::vector<std::vector<std::string>> fea_literal_matrix(FLAGS_thread_num);

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    fea_weight_matrix[i].reserve(900000);
    fea_literal_matrix[i].reserve(900000);
    pool.AddTask(::NewCallback(&TransWorker, category, &input_queue, &(fea_weight_matrix[i]),
                               &(fea_literal_matrix[i]), sign_dict));
  }

  std::ifstream fin(dir.Append(filename).value());
  std::string line;
  int n = 0;
  while (std::getline(fin, line)) {
    input_queue.Put(line);
    ++n;
  }
  input_queue.Close();
  LOG(INFO) << base::StringPrintf("finish reading %d fea from %s", n, dir.Append(filename).value().c_str());
  pool.JoinAll();
  LOG(INFO) << base::StringPrintf("finish transfering %d from %s", n, dir.Append(filename).value().c_str());

  // merge sort
  std::vector<std::pair<double, int>> fea_weight(n);
  std::vector<std::string> fea_literal(n);

  auto literal_it = fea_literal.begin();
  auto weight_it = fea_weight.begin();

  int offset = 0;
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    literal_it = std::copy(fea_literal_matrix[i].begin(), fea_literal_matrix[i].end(), literal_it);

    for (size_t j = 0; j < fea_weight_matrix[i].size(); ++j) {
      fea_weight_matrix[i][j].second += offset;
    }

    auto end = std::copy(fea_weight_matrix[i].begin(), fea_weight_matrix[i].end(), weight_it);

    std::inplace_merge(fea_weight.begin(), weight_it, end, std::greater<std::pair<double, int> >());

    offset += fea_weight_matrix[i].size();
    weight_it = end;
  }
  if (offset != n) {
    CHECK_LT(offset, n);
    fea_weight.resize(offset);
  }

  std::string out_file = base::StringPrintf("%s/%s.txt", dir.value().c_str(), filename.c_str());
  std::ofstream fout(out_file);
  for (size_t i = 0; i < fea_weight.size(); ++i) {
    fout << fea_weight[i].first << "\t" << fea_literal[fea_weight[i].second] << "\n";
  }

  LOG(INFO) << "finsh write " << out_file;
}
int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "calc term sign");
  // load sign dict
  base::dense_hash_map<uint64, std::string> sign_dict;
  sign_dict.set_empty_key(0);
  LoadDict(base::FilePath(FLAGS_sign_dict), &sign_dict);

  // get all model file
  std::vector<std::string> file_list;
  base::FilePath dir(FLAGS_input_dir);
  GetFileList(dir, &file_list);

  // multi thread generate plan file
  thread::ThreadPool pool(file_list.size());
  for (size_t i = 0; i < file_list.size(); ++i) {
    pool.AddTask(::NewCallback(&Transform, dir, file_list[i], file_list[i], &sign_dict));
  }
  pool.JoinAll();
}
