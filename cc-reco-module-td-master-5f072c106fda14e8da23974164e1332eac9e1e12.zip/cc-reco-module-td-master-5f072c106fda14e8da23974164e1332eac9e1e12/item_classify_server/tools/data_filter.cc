#include <string>
#include <map>
#include <unordered_map>
#include <vector>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <functional>
#include <utility>

#include "base/time/timestamp.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/hash_function/term.h"
#include "base/common/gflags.h"
#include "base/common/base.h"

#include "reco/item_classify_server/strategy/rule_classifier.h"

DEFINE_string(input, "input.txt", "");
DEFINE_string(output_safe, "safe.txt", "");
DEFINE_string(output_suspect, "suspect.txt", "");
DEFINE_string(data_dir, "./data", "");

reco::item_classify::RuleClassifier* rule_classifier_;

void Initial() {
  rule_classifier_ = new reco::item_classify::RuleClassifier();
  CHECK(reco::item_classify::RuleClassifier::Initial(FLAGS_data_dir));
}

void Filter() {
  std::ifstream fin(FLAGS_input);
  std::ofstream fout_safe(FLAGS_output_safe);
  std::ofstream fout_suspect(FLAGS_output_suspect);
  CHECK(fin.good());
  std::vector<std::string> tokens;
  std::string line;
  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() != 3) {
      continue;
    }
    std::string rule_category = rule_classifier_->Classify(tokens[1], "", 0);
    if (rule_category == "财经") {
      fout_suspect << line << std::endl;
    } else {
      fout_safe << line << std::endl;
    }
  }
  fin.close();
  fout_safe.close();
  fout_suspect.close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "data filter");
  Initial();
  Filter();
}
