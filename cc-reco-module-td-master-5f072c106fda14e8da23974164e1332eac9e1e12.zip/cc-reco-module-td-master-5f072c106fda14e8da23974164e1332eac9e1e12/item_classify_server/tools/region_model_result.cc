#include <math.h>
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/file/file_util.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "base/common/gflags.h"
#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "net/rpc/rpc.h"
#include "reco/module/item_classify_server/global_data/define.h"

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_string(task_file, "task.txt", "model dir");
DEFINE_double(cutting_value, 0.9, "model dir");
DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table");
DEFINE_string(item_classify_server_ip, "11.251.177.94", "sim item server ip");
DEFINE_int32(item_classify_server_port, 20004, "sim item server port");
DEFINE_string(limit, "10000", "limit");
int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "getting threashold");
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  serving_base::mysql_util::DbConnManager* db_manager
          = new serving_base::mysql_util::DbConnManager(db_option);
  reco::HBaseGetItem* hbase_get_item = new reco::HBaseGetItem(FLAGS_hbase_item_table);

  net::rpc::RpcClientChannel channel(FLAGS_item_classify_server_ip.c_str(), FLAGS_item_classify_server_port);
  CHECK(channel.Connect());
  reco::item_classify::ItemClassifyService::Stub stub(&channel);
  reco::item_classify::ItemClassifyResponse response;
  std::pair<uint64, reco::item_classify::ItemClassifyRequest*> element;


  // 从评估里面里面拉取标注数据
  std::string sql =
          "select item_id from tb_item_info where item_type< 5 and title<>''  order by create_time desc limit " +FLAGS_limit;
  sql::ResultSet* res = db_manager->ExecuteQueryWithRetry(sql, 3);
  if (res == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }
  std::vector<uint64> item_ids;
  std::unordered_map<uint64, int> items;
  uint64 item_id;
  while (res->next()) {
    base::StringToUint64(res->getString("item_id"), &item_id);
    item_ids.push_back(item_id);
  }
  // 拉数据，朝分类服务发请求
  std::vector<reco::item_classify::RawItem> raw_items;
  reco::item_classify::ItemUtil::GetRawitem(hbase_get_item, item_ids, &raw_items);
  for (size_t j = 0; j < raw_items.size(); ++j) {
    const reco::item_classify::RawItem& raw_item = raw_items[j];
    reco::item_classify::ItemClassifyRequest* request = new reco::item_classify::ItemClassifyRequest();
    request->set_source(raw_item.source);
    request->set_title(raw_item.title);

    request->set_item_type(raw_item.item_type);

    request->set_content(raw_item.content);
    request->set_item_id(raw_item.item_id);

    // keyword and tag
    for (size_t k = 0; k < raw_item.keywords.size(); ++k) {
      request->add_keywords(raw_item.keywords[k].first);
    }
    request->set_level(2);
    request->set_is_debug(0);
    request->set_debug_level(0);

    net::rpc::RpcClientController rpc;
    rpc.SetTimeout(2000);

    stub.ClassifyItem(&rpc, request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "failed: " << request->item_id()
                 << "rpc.status()=" << rpc.status() << " response.success())=" << response.success();
      continue;
    }

    bool has_region = false;
    for (int l = 0; l < response.post_tag_candidates_size(); ++l) {
      if (response.post_tag_candidates(l) == "地方新闻") {
        has_region = true;
        break;
      }
    }
    std::string a = "hbase无区域";
    std::string b = "no地方新闻";
    if (raw_item.region != "") a = "hbase有区域" + raw_item.region;
    if(has_region) b = "yes地方新闻";
    std::cout  << raw_item.item_id << "\t" << raw_item.title << "\t" << a << "\t" << b <<"\n";
  }
}
