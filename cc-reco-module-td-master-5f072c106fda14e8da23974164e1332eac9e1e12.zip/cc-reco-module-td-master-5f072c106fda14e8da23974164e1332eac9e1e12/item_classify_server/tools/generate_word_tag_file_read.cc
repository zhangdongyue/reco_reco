#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <unordered_map>
#include <unordered_set>
#include <set>

#include <map>
#include "base/strings/string_split.h"
#include "base/common/gflags.h"
#include "base/common/base.h"

#include "extend/static_dict/dawg/dawg.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"
#include "base/strings/string_number_conversions.h"

DEFINE_string(output, "word_tags.bin", "output file");
DEFINE_string(test_case, "范冰冰", "");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "pakcage word tags file");
  // word tags
  dawgdic::Dictionary word_tag_dict_;
  std::vector<std::string> word_tags_list_;

  std::ifstream fin(FLAGS_output, std::ifstream::binary);
  CHECK(fin.good());

  // part 1: dict
  word_tag_dict_.Read(&fin);
  LOG(INFO) << "fea_dict: " << word_tag_dict_.size();
  LOG(INFO) << "fin offset: " << fin.tellg();

  CHECK(fin.good());
  LOG(INFO) << "begin read ngram weights";


  // part3 : all types
  CHECK(fin.good());
  uint32 buf_size = 0;
  fin.read(reinterpret_cast<char*>(&buf_size), sizeof(buf_size));
  LOG(INFO) << "tag names buf size: " << buf_size;
  char* buf = new char[buf_size + 1];
  fin.read(buf, buf_size);
  buf[buf_size] = '\0';
  base::SplitString(std::string(buf, buf_size), "\t", &word_tags_list_);
  LOG(INFO) << "tag names num: " << word_tags_list_.size();
  fin.close();

  int tagid = word_tag_dict_.Find(FLAGS_test_case.c_str());
  LOG(INFO) << FLAGS_test_case << " " << tagid << " " << word_tags_list_[tagid];
}
