#include <fstream>
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_split.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_printf.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "reco/module/item_classify_server/global_data/define.h"

DEFINE_string(redispool_ips, "100.81.1.68:6500,100.81.2.180:6500,100.81.4.141:6500", "");

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table");

DEFINE_int32(thread_num, 8, "thread num");
DEFINE_int32(stat_days, 120, "stat in last XXX days");
DEFINE_int32(limit, 20000, "max return number");
DEFINE_string(cate, "财经", "shcema");
DEFINE_string(condition, "and 1=1 ", "additional sql where");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "Get keywords candianate");
  LOG(INFO) << "程序开始启动喽~~~";

  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;

  serving_base::mysql_util::DbConnManager* db_manager =
          new serving_base::mysql_util::DbConnManager(db_option);

  uint64 timestamp = 0;
  CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond, &timestamp));
  timestamp -= FLAGS_stat_days * 24 * 3600 * 1000000lu;  // last 30 days

  std::string time_str;
  CHECK(serving_base::TimeHelper::TimestampToString(timestamp, serving_base::TimeHelper::kSecond, &time_str));
  LOG(INFO) << "从数据库读取itemid列表";
  // 拉取数据
  std::string sql = "select item_id from tb_item_info where item_type<>30 and source<>'' and create_time >'" + time_str //NOLINT
                    + "' and source not like 'probe_query' and source not like '%竞品%' and category like '"
                    + FLAGS_cate +"\%' "+ FLAGS_condition+" limit "+ base::IntToString(FLAGS_limit); //NOLINT

  sql::ResultSet* res = db_manager->ExecuteQueryWithRetry(sql, 3);
  std::unordered_map<std::string, std::vector<std::pair<std::string, int >> > data;
  if (res == NULL) {
    LOG(ERROR) << "FAILED in reading data" << sql;
    return -1;
  }
  std::vector<uint64> id_vector;
  while (res->next()) {
    const std::string item_id = res->getString("item_id");
    id_vector.push_back(base::ParseUint64OrDie(item_id));
  }
  LOG(INFO) << "itemid列表读取完成，数据合计:" << id_vector.size();
  LOG(INFO) << "从HBase拉取数据";
  std::vector<reco::item_classify::RawItem> items;
  reco::HBaseGetItem get_item(FLAGS_hbase_item_table);
  reco::item_classify::ItemUtil::GetRawitem(&get_item, id_vector, &items);
  LOG(INFO) << "从HBase拉取数据完成";
  std::unordered_map<std::string, int> stat_data;
  std::string key1;
  std::string key2;
  for (size_t i = 0; i < items.size(); ++i) {
    const std::vector<std::pair<std::string, double> >& keywords = items[i].keywords;
    for (size_t j = 0; j < keywords.size(); ++j) {
      key1 = keywords[j].first;
      auto it = stat_data.find(key1);
      if (it == stat_data.end()) {
        stat_data.insert(std::make_pair(key1, 1));
      } else {
        it->second++;
      }
      for (size_t k = 0; k < keywords.size(); ++k) {
        if (key1 >= keywords[k].first || key1.find(keywords[k].first) != std::string::npos) continue;
        key2 = key1 +"\t"+keywords[k].first;
        auto it = stat_data.find(key2);
        if (it == stat_data.end()) {
          stat_data.insert(std::make_pair(key2, 1));
        } else {
          it->second++;
        }
      }
    }
    LOG_EVERY_N(INFO, 500) << base::StringPrintf("%d/%d", (int) i + 1, (int) items.size());
  }
  LOG(INFO) << "统计完成,准备输出数据";
  std::string buf="";
  for (auto it = stat_data.begin(); it != stat_data.end(); ++it) {
    if (it->second < 3) continue;
    buf.append(base::StringPrintf("%d\t%s\n", it->second, it->first.c_str()));
  }
  std::ofstream fout(FLAGS_cate + ".txt");
  fout << buf;
  fout.close();
  delete db_manager;
}
