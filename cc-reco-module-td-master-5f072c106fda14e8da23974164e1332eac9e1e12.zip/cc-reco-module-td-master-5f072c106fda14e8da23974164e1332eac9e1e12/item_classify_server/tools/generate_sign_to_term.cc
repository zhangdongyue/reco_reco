#include <iostream>
#include <string>
#include <vector>
#include "base/strings/string_split.h"
#include "base/hash_function/term.h"
#include "nlp/common/nlp_util.h"

int main(int argc, char** argv) {
  std::string line;
  std::vector<std::string> tokens;
  std::vector<std::string> grams;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() == 1 && tokens.front().size() < 2) continue;
    grams.clear();
    for (size_t i = 1; i < tokens.size(); ++i) {
      nlp::util::NormalizeLineInPlaceS(&tokens[i]);
      grams.push_back(tokens[i]);
    }
    std::sort(grams.begin(), grams.end());
    std::string result;
    base::FastJoinStrings(grams, "\t", &result);
    uint64 sign = base::CalcTermSign(result.c_str(), result.size());
    std::cout << sign << "\t" << result << "\n";
  }
}

