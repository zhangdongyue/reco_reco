#include "reco/item_classify_server/strategy/source_category_manager.h"
#include "base/common/base.h"

DEFINE_string(data_dir, "./data", "");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "validate");
  reco::item_classify::SourceCategoryDict dict("test", base::FilePath(FLAGS_data_dir));
  CHECK(dict.Load());
}
