#include <fstream>
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_split.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_util.h"

#include "serving_base/utility/time_helper.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "reco/module/item_classify_server/global_data/define.h"


DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table");

DEFINE_int32(thread_num, 8, "thread num");
DEFINE_int32(stat_days, 20, "stat in last XXX days");
DEFINE_int32(limit, 20000, "max return number");

DEFINE_string(result_file, "result.txt", "the output file");

void Stat(int group_idx, serving_base::mysql_util::DbConnManager* db_manager,
          thread::BlockingQueue<std::string>* result_data,
          thread::BlockingVar<int>* finish_num) {
  uint64 timestamp1 = 0;
  uint64 timestamp2 = 0;

  std::string time_str1;
  std::string time_str2;

  std::vector<uint64> id_vector;
  reco::HBaseGetItem* hbase_get_item = new reco::HBaseGetItem(FLAGS_hbase_item_table);
  std::vector<reco::RecoItem> reco_items;
  std::unordered_map<uint64, std::string> item_tags;
  for (int i = group_idx; i < FLAGS_stat_days;  i += FLAGS_thread_num ) {
    CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond, &timestamp1));
    timestamp1 -= i * 24 * 3600 * 1000000lu ;  // last 30 days
    timestamp2 = timestamp1 -  24 * 3600 * 1000000lu;  // last 30 days


    CHECK(serving_base::TimeHelper::TimestampToString(timestamp1, serving_base::TimeHelper::kDay, &time_str1));
    CHECK(serving_base::TimeHelper::TimestampToString(timestamp2, serving_base::TimeHelper::kDay, &time_str2));

    // 拉取数据
    std::string sql = "select item_id,tags from tb_toutiao where item_type<>30 and create_time >'" +
                      time_str2 +"' and  create_time <'"+ time_str1
                      +"' order by item_id desc limit " +
                      base::IntToString(FLAGS_limit); //NOLINT

    sql::ResultSet* res = db_manager->ExecuteQueryWithRetry(sql, 3);
    if (res == NULL) {
      LOG(ERROR) << "FAILED in reading data" << sql;
      return;
    }

    id_vector.clear();
    while (res->next()) {
      const std::string item_id = res->getString("item_id");
      id_vector.push_back(base::ParseUint64OrDie(item_id));
      item_tags.insert(std::make_pair(base::ParseUint64OrDie(item_id), res->getString("tags")));
    }
    LOG(INFO) << sql << " finish";
    reco_items.clear();
    hbase_get_item->GetRecoItems(id_vector, &reco_items);
    LOG(INFO) << "hbase finish";
    for (size_t j = 0; j < reco_items.size(); ++j) {
      const std::string cate_name = reco_items[j].category(0);
      const uint64 item_id =  reco_items[j].identity().item_id();
      std::string result = base::StringPrintf("%s\t%s", cate_name.c_str(), item_tags[item_id].c_str());
      result_data->Put(result);
    }
  }

  LOG(INFO) << "group_idx:" << group_idx << "finish";
  int n = finish_num->Take() + 1;
  LOG(INFO) << n <<FLAGS_thread_num;
  if (n == FLAGS_thread_num) {
    result_data->Close();
  }
  finish_num->TryPut(n);
}

static void SaveResult(std::string filename, thread::BlockingQueue<std::string>* result_queue) {
  std::ofstream fout(filename);
  std::string buf;
  std::vector<std::string> tokens_all;
  std::vector<std::string> tokens_tags;
  std::unordered_map<std::string, int> tag_stat;
  while (!(result_queue->Closed() && result_queue->Empty())) {
    if (result_queue->Empty()) {
      base::SleepForSeconds(1);
      continue;
    }

    if (!result_queue->Take(&buf)) break;
    tokens_all.clear();
    tokens_tags.clear();
    base::SplitString(buf, "\t", &tokens_all);
    base::SplitString(tokens_all[1], ",", &tokens_tags);
    for (size_t i = 0; i < tokens_tags.size(); ++i) {
      const std::string key = tokens_all[0] + "\t" + tokens_tags [i];
      auto it = tag_stat.find(key);
      LOG(INFO) << key;
      if (it == tag_stat.end()) {
        tag_stat.insert(std::make_pair(key, 1));
      } else {
        it->second ++;
      }
    }

  }
  for (auto it = tag_stat.begin(); it != tag_stat.end(); ++it) {
    fout << it->first << "\t" << it->second << std::endl;
  }
}
int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "Category Coverage");
  LOG(INFO) << "程序开始启动喽~~~";

  thread::ThreadPool pool(FLAGS_thread_num + 1);
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;

  serving_base::mysql_util::DbConnManager* db_manager =
          new serving_base::mysql_util::DbConnManager(db_option);


  thread::BlockingQueue<std::string> result_data;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(&Stat, i, db_manager, &result_data, &finish_num));
  }

  pool.AddTask(::NewCallback(&SaveResult, FLAGS_result_file, &result_data));

  pool.JoinAll();

  delete db_manager;
}
