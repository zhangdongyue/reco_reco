#include <iostream>
#include <vector>
#include <fstream>
#include <string>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "reco/module/item_classify_server/global_data/xgboost_util.h"
#include "reco/module/item_classify_server/global_data/define.h"

DEFINE_string(map_dict_path, "cate_map_dict", "cate map dict");
DEFINE_string(model_path, "model_name", "model name");

// 封装映射词典到 Xgboost 模型文件中
void PackCateMap2Model(char* map_dict_path, char* model_path) {
  // 读取映射词典
  std::ifstream fin(map_dict_path);
  CHECK(fin.is_open());
  std::string line;
  std::vector<std::string> tokens;
  std::string str_cate_map = "";
  // std::vector<std::string> cate_map;
  while (std::getline(fin, line)) {
    tokens.clear();
    // 类别词典格式为: 类别名 \t 类别 id
    base::SplitString(line, "\t", &tokens);
    str_cate_map += tokens[0] + ":" + tokens[1] + "\t";
  }

  reco::item_classify::XGboostModel *p_model = new reco::item_classify::XGboostModel();
  // 创建 Stream 对象，GBTree 对象
  reco::item_classify::Stream *p_fin = reco::item_classify::Stream::Create(model_path, "r");
  // Load 模型头部声明
  std::string header;
  header.resize(4);
  CHECK_EQ(p_fin->Read(&header[0], 4), 4u);
  // Load 模型参数
  p_fin->Read(&p_model->model_param, sizeof(reco::item_classify::XParam));
  // 构建归一化对象
  std::string obj_name;
  p_fin->Read(&obj_name);
  p_model->p_obj = reco::item_classify::CreateObjFunction(obj_name.c_str());
  std::string tmp = base::IntToString(p_model->model_param.num_class);
  p_model->p_obj->SetParam("num_class", tmp.c_str());
  // 构建 gbm 对象， Load 模型
  std::string gbm_name;
  p_fin->Read(&gbm_name);
  p_model->p_gbm = new reco::item_classify::GBTree();
  p_model->p_gbm->LoadModel(p_fin, false);
  delete p_fin;

  // 写入新的模型文件
  reco::item_classify::Stream *p_fout = reco::item_classify::Stream::Create(model_path, "w");
  p_fout->Write("binf", 4);
  p_fout->Write(&p_model->model_param, sizeof(reco::item_classify::XParam));
  p_fout->Write(obj_name);
  p_fout->Write(gbm_name);
  // 写映射词典
  int cate_map_size = str_cate_map.size();
  p_fout->Write(&cate_map_size, sizeof(int));
  p_fout->Write(str_cate_map.c_str(), cate_map_size);
  p_model->p_gbm->SaveModel(p_fout, false);
  delete p_fout;
}

// Load 封装了映射词典的 Xgboost 模型文件
void TESTLoadNewModel(char* model_path) {
  reco::item_classify::XGboostModel *p_model = new reco::item_classify::XGboostModel();
  // 创建 Stream 对象， GBTree 对象
  reco::item_classify::Stream *p_fin = reco::item_classify::Stream::Create(model_path, "r");
  // Load 模型头部声明
  std::string header;
  header.resize(4);
  CHECK_EQ(p_fin->Read(&header[0], 4), 4u);
  // Load 模型参数
  p_fin->Read(&p_model->model_param, sizeof(reco::item_classify::XParam));
  // Load 归一化对象
  std::string obj_name;
  p_fin->Read(&obj_name);
  // 构建 gbm 对象， Load 模型
  std::string gbm_name;
  p_fin->Read(&gbm_name);
  p_model->p_gbm = new reco::item_classify::GBTree();
  // Load 映射词典
  p_model->p_gbm->LoadCateMap(p_fin);
  p_model->p_gbm->LoadModel(p_fin, false);
  delete p_fin;
}

int main(int argc, char** argv) {
    base::InitApp(&argc, &argv, "pack xgboost");
  // argv[1] 为映射文件，格式为 cate_map"\t"cate_id
  // argv[2] 为 xgboost 输出的模型文件 & 把映射文件打包到 xgboost 模型文件后的文件
  PackCateMap2Model(argv[1], argv[2]);
  TESTLoadNewModel(argv[2]);
  return 0;
}
