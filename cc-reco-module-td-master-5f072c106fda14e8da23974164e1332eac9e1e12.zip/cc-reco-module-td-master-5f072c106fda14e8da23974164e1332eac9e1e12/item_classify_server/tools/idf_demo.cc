#include "nlp/idf/idf.h"
#include "base/common/base.h"
#include <iostream>
#include <string>
int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "idf demo");
  std::string line;
  nlp::idf::IdfDicts idf_dict;
  while (std::getline(std::cin, line)) {
    float idf = idf_dict.get_idf(line, nlp::idf::IdfDicts::kTitle);
    std::cout << line << "\t" << idf << "\n";
  }
  return 0;
}
