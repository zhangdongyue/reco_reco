#include <math.h>
#include <base/strings/string_split.h>
#include "base/strings/string_printf.h"
#include "base/file/file_util.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "base/common/gflags.h"

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_string(cate_file, "cates.txt", "model dir");
DEFINE_double(beta, 2.0, "model dir");

// 通过标注平台评估的结果，确定一个类别的阈值给线上使用
int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "getting threashold");
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  serving_base::mysql_util::DbConnManager *db_manager
          = new serving_base::mysql_util::DbConnManager(db_option);

  // 从文件中读取要上线的分类及标签列表
  std::vector<std::string> cates;
  if (!base::file_util::ReadFileToLines(base::FilePath(FLAGS_cate_file), &cates)) {
    LOG(ERROR) << "少年，读文件出错了";
    return false;
  }
  double score;
  double label;

  // 开始统计数目
  for (size_t i = 0; i < cates.size(); ++i) {
    std::vector<double> cutting_nodes;
    std::vector<int> pos_sample_count;
    std::vector<int> neg_sample_count;

    std::vector<double> pos_sample_scores;
    double sum_pos_score = 0.0;
    int pos_count = 0;
    int neg_count = 0;
    for (size_t j = 1; j <= 20; ++j) {
      cutting_nodes.push_back(j * 0.05 - 0.05);
      pos_sample_count.push_back(0);
      neg_sample_count.push_back(0);
    }
    const std::string &cate_name = cates[i];
    std::vector<std::string> tokens;
    base::SplitString(cate_name, ",", &tokens);
    std::string sql = base::StringPrintf(
            "select predict_score,status from tb_label_model_recalled where status<>0  and level2=\"%s\"", // NOLINT
            tokens[1].c_str());
    sql::ResultSet *res = db_manager->ExecuteQueryWithRetry(sql, 3);
    if (res == NULL) {
      LOG(ERROR) << "null resultset for sql: " << sql;
      return false;
    }

    while (res->next()) {
      score = res->getDouble("predict_score");
      label = res->getInt("status");
      int idx = static_cast<int>(score / 0.05);
      if (idx >= (int)cutting_nodes.size()) idx = cutting_nodes.size() - 1;
      if (label > 0) {
        pos_count++;
        pos_sample_count[idx]++;

        pos_sample_scores.push_back(score);
        sum_pos_score += score;
      } else {
        neg_count++;
        neg_sample_count[idx]++;
      }
    }
    if (pos_count <=0 ) {
      std::cout << cate_name << "无评测数据\n";
      continue;
    }
    // 计算均值和标准差
    double avg_value = sum_pos_score / pos_sample_scores.size();
    double std_value = 0.0;
    for (size_t l = 0; l < pos_sample_scores.size(); ++l) {
      std_value += (pos_sample_scores[l] - avg_value) * (pos_sample_scores[l] - avg_value);
    }
    std_value = sqrt(std_value / pos_sample_scores.size());

    //
    std::vector<double> p_values;
    std::vector<double> r_values;
    p_values.resize(cutting_nodes.size());
    r_values.resize(cutting_nodes.size());
    int added_pos_count = 0;
    int added_neg_count = 0;
    for (int k = cutting_nodes.size() - 1; k >= 0; --k) {
      added_pos_count += pos_sample_count[k];
      added_neg_count += neg_sample_count[k];
      // 准确率
      p_values[k] = added_pos_count * 1.0 / (added_pos_count + added_neg_count);
      // 召回率
      r_values[k] = added_pos_count * 1.0 / pos_count;
      //      double p1 = added_pos_count * 1.0 / (added_pos_count + added_neg_count);
      //      double p2 = added_neg_count * 1.0 / (added_pos_count + added_neg_count);
      //      double entropy = -p1 * log(p1) - p2 * log(p2);
      //      double F = (1 + FLAGS_beta * FLAGS_beta) * p_values[k]
      //                 * r_values[k] / (FLAGS_beta * FLAGS_beta * p_values[k] + r_values[k]);
      //    LOG(INFO) << pos_sample_count[k] << " " << neg_sample_count[k] << " " << cutting_nodes[k] << " p=" << p_values[k]
      //              << " r=" << r_values[k]
      //              << " F=" << F << " E=" << entropy;
    }

    double value = avg_value - 2 * std_value;
    int idx = static_cast<int>(value / 0.05);
    std::cout << cate_name << "\t" << value << "\tavg=" << avg_value << "\tP=" << p_values[idx] << "\tR="
              << r_values[idx] <<"\n";
  }
}
