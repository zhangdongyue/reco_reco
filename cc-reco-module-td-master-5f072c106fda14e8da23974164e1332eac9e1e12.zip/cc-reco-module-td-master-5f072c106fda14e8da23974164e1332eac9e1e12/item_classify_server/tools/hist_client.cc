#include <fstream>

#include "base/strings/string_printf.h"
#include "base/common/base.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/time/timestamp.h"
#include "net/rpc/rpc.h"

#include "reco/proto/item_classify.pb.h"

DEFINE_string(item_classify_server_ip, "127.0.0.1", "sim item server ip");
DEFINE_int32(item_classify_server_port, 20004, "sim item server port");

DEFINE_bool(reload_source, false, "if set , reload the source categoy");

DEFINE_string(result_file, "hist.txt", "the output file");
DEFINE_string(title_file, "title.txt", "input file for raw item ,seprated by tab, three fls, title,categories, only title is needed");  // NOLINT
DEFINE_string(category_file, "category.txt", "candidate category,levels seprated by tab");
DEFINE_string(source, "", "if set, would mask the category file");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "sim item client");
  net::rpc::RpcClientChannel channel(FLAGS_item_classify_server_ip.c_str(), FLAGS_item_classify_server_port);
  CHECK(channel.Connect());
  reco::item_classify::ItemClassifyService::Stub stub(&channel);

  if (FLAGS_reload_source) {
    // read category candidates
    reco::item_classify::ReloadSourceCategoryRequest request;
    reco::item_classify::ReloadSourceCategoryResponse response;
    request.set_timestamp(base::GetTimestamp());
    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(100);
    stub.ReloadSourceCategory(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "get category hist failed: ";
    }
    return 0;
  }
  // read category candidates
  reco::item_classify::StatCategoryHistResponse response;
  reco::item_classify::StatCategoryHistRequest request;

  std::vector<std::string> titles;
  std::vector<std::string> categories;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_title_file), &titles));
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_category_file), &categories));

  for (size_t i = 0; i < titles.size(); ++i) {
    request.add_title(titles[i]);
  }
  for (size_t i = 0; i < categories.size(); ++i) {
    request.add_category(categories[i]);
  }

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(100);
  stub.StatCategoryHist(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "get category hist failed: ";
    return 0;
  }

  std::ofstream fout(FLAGS_result_file);
  for (int i = 0; i < response.hist_size(); ++i) {
    fout << response.category(i) << "\t" << response.hist(i) << "\n";
  }

  for (int i = 0; i < response.title_result_size(); ++i) {
    fout << response.title_result(i) << "\n";
  }
  return 0;
}
