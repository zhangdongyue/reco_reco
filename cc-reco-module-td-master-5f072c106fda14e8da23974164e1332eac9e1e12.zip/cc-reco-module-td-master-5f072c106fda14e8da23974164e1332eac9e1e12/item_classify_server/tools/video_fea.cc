#include <iostream>
#include <string>
#include <cstdlib>
#include <unordered_map>
#include <fstream>
#include "reco/base/common/singleton.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "reco/module/item_classify_server/common/item_util.h"

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_printf.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

#include "reco/module/item_classify_server/global_data/define.h"
#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/get_item.h"

DEFINE_string(hbase_item_table, "tb_reco_item", "table name");
DEFINE_int32(extract_thread_num, 24, "extract thread num");
DEFINE_string(category_name, "", "category name");

void WriteSamples(thread::BlockingQueue<std::string>* result_queue) {
  std::string buf;
  while (!result_queue->Closed() || !result_queue->Empty()) {
    int status = result_queue->TimedTake(10, &buf);

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    if (status == -1) {
      LOG(WARNING) << "result queue has been closed by other thread, must be empty " << result_queue->Size();
      break;
    }
    CHECK_EQ(status, 1) << "fucking new status: " << status;
    std::cout << buf << "\n";
  }
}

void Extract(std::vector<uint64> input_queue,
             std::vector<std::string> video_fea,
             thread::BlockingQueue<std::string>* result_queue,
             thread::BlockingVar<int>* finish_num) {
  reco::HBaseGetItem hbase_pool_get_item(FLAGS_hbase_item_table, 0);
  LOG(WARNING) << "准备读取数据";
  std::string buf_ori;
  std::vector<std::string> ngrams;
  reco::item_classify::FeatureExtractor feature_extractor;
  reco::item_classify::ItemClassifyFeature item_classify_feature;

  for (int i = 0; i < (int) input_queue.size(); ++i) {
    reco::RecoItem reco_item;
    if (!hbase_pool_get_item.GetRecoItem(input_queue[i], &reco_item)) continue;
    
    reco::item_classify::RawItem raw_item;
    raw_item.title = reco_item.title();
    raw_item.source = reco_item.source();
    raw_item.content = reco_item.content();
    raw_item.media = reco_item.orig_source_media();
    raw_item.item_type = reco_item.identity().type();
    raw_item.item_id = reco_item.identity().item_id();
    raw_item.category = reco_item.category(0);
    
    if (reco_item.has_region()) {
      raw_item.region = reco_item.region();
    }
    if (reco_item.category_size() == 2) {
      raw_item.category += "," + reco_item.category(1);
    }

    const reco::FeatureVector& fea_vec = reco_item.keyword();
    for (int j = 0; j < fea_vec.feature_size(); ++j) {
      raw_item.keywords.push_back(std::make_pair(fea_vec.feature(j).literal(),
                                                 fea_vec.feature(j).weight()));
    }
    const reco::FeatureVector& fea_topic = reco_item.topic();
    for (int j = 0; j < fea_topic.feature_size(); ++j) {
      raw_item.topics.push_back(std::make_pair(fea_topic.feature(j).literal(),
                                               fea_topic.feature(j).weight()));
    }
    if (reco_item.identity().type() == 30) {
      for (int j = 0; j < reco_item.raw_item().spider_tags_size(); ++j) {
        raw_item.keywords.push_back(std::make_pair(reco_item.raw_item().spider_tags(j), 1.0));
      }
    }

    nlp::util::NormalizeLineInPlaceS(&raw_item.title);
    nlp::util::NormalizeLineInPlaceS(&raw_item.source);
    nlp::util::NormalizeLineInPlaceS(&raw_item.media);
    std::string tmp;
    nlp::util::QuanJiaoToBanJiao(raw_item.content, &tmp);
    raw_item.content = tmp;

    buf_ori.clear();
   
    buf_ori.append("[|]");
    buf_ori.append("\n");
    
    buf_ori.append("LABEL=0:");
    std::vector<std::string> tmp_category;
    base::SplitString(raw_item.category, ",", &tmp_category);
    if (tmp_category[0] == FLAGS_category_name)
      buf_ori.append("1");
    else
      buf_ori.append("0");
    buf_ori.append("\n");

    buf_ori.append("ITEMID=0:");
    buf_ori.append(base::Uint64ToString(raw_item.item_id));
    buf_ori.append("\n");

    buf_ori.append("TAGS=0:");
    // if (raw_item.tags.size() > 0) {
      // buf_ori.append(raw_item.tags[0]);
      // for (int j = 1; j < (int) raw_item.tags.size(); ++j) {
        // buf_ori.append(",");
        // buf_ori.append(raw_item.tags[j]);
      // }
    // }
    buf_ori.append("\n");

    buf_ori.append("KEYWORDS=0:");
    // if (raw_item.keywords.size() > 0) {
      // buf_ori.append(raw_item.keywords[0].first);
      // for (int j = 1; j < (int) raw_item.keywords.size(); ++j) {
        // buf_ori.append(",");
        // buf_ori.append(raw_item.keywords[j].first);
      // }
    // }
    buf_ori.append("\n");

    buf_ori.append("TOPICS=0:");
    if (raw_item.topics.size() > 0) {
      buf_ori.append(raw_item.topics[0].first);
      for (int j = 1; j < (int) raw_item.topics.size(); ++j) {
        buf_ori.append(",");
        buf_ori.append(raw_item.topics[j].first);
      }
    }
    buf_ori.append("\n");

    item_classify_feature.clear();
    feature_extractor.Extract(raw_item, &item_classify_feature);
    ngrams.clear();
    ngrams = item_classify_feature.ngram_fea;

    buf_ori.append("NGRAMS=0:");
    if (ngrams.size() > 0) {
      buf_ori.append(ngrams[0]);
      for (int j = 1; j < (int) ngrams.size(); ++j) {
        if (ngrams[j][3] == '$' || ngrams[j][0] == '$') continue;
        buf_ori.append(",");
        buf_ori.append(ngrams[j]);
      }
    }
    buf_ori.append("\n");

    buf_ori.append("VIDEOFEA=0:");
    buf_ori.append(video_fea[i]);

    result_queue->Put(buf_ori);
  }
  int n = finish_num->Take() + 1;
  if (n == FLAGS_extract_thread_num) {
    result_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "generate trainning samples");
  
  reco::item_classify::GlobalDataIns::instance().InitFeatureDicts();
  std::vector<std::vector<uint64>> input_queue;
  std::vector<std::vector<std::string>> video_fea;
  thread::BlockingVar<int> finish_num;
  thread::BlockingQueue<std::string> result_queue_feature;

  thread::ThreadPool pool(FLAGS_extract_thread_num + 1);
  pool.AddTask(::NewCallback(WriteSamples, &result_queue_feature));
  CHECK(finish_num.TryPut(0));

  std::string line;
  uint64 item_id;

  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    input_queue.push_back(std::vector<uint64>());
    video_fea.push_back(std::vector<std::string>());
  }

  while (std::getline(std::cin, line)) {
    if (line.size() < 3) continue;
    std::vector<std::string> token;
    base::SplitString(line, "\t", &token);
    if (token.size() != 2) continue;
    if (!base::StringToUint64(token[0], &item_id)) continue;
    video_fea[item_id % FLAGS_extract_thread_num].push_back(token[1]);
    input_queue[item_id % FLAGS_extract_thread_num].push_back(item_id);
  }
  LOG(INFO) << "线程开始启动";
  for (int i = 0; i < FLAGS_extract_thread_num; ++i) {
    pool.AddTask(::NewCallback(Extract, input_queue[i], video_fea[i], &result_queue_feature, &finish_num)); // NOLINT
  }
  pool.JoinAll();
}
