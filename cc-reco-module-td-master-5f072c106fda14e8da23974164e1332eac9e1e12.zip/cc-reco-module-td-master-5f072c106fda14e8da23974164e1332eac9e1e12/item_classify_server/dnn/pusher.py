#!encoding=utf8
import sys
from pykafka import KafkaClient
import common_pb2

class Pusher:
  def __init__(self, hosts, topic):
    self_client = KafkaClient(hosts=hosts)
    self.client.topics  # 查看所有topic
    self.topic = client.topics[topic] # 选择一个topic
    self.producer = topic.get_producer()

  def push(item_id, category):
    request = common_pb2.reco.RawItemFieldUpdateRequest()
    item_fld = request.fields.add()
    item_fld.field_name = "category"
    item_fld.is_manual = False
    item_fld.value = category

    buf = request.SerializeToString()
    self.producer.produce([buf])

if __name__ == "__main__":
  pusher = Pusher(sys.argv[1], sys.argv[2])
  pusher.push(sys.argv[3], sys.argv[4])

