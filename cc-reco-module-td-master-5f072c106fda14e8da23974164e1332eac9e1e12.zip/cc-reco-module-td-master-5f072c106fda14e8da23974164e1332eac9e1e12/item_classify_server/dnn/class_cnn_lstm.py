#coding=utf-8
import os, sys
import numpy as np
from numpy import *
from keras.models import model_from_json

class cnn_lstm():
  def __init__(self, architecture_file, weights_file, category_map_file):
    self.word_length = 20
    self.word_dim = 200

    print ("loading model...\n")
    self.model = model_from_json(open(architecture_file).read())
    self.model.load_weights(weights_file)
    self.dict_category = {}
    for line in open(category_map_file, "r"):
      elements = line.strip().split(" ")
      if len(elements) != 2:
        sys.stderr.write("err line: %s" %line)
        continue
      self.dict_category[int(elements[0])] = elements[1]
  
# instance: 20 * 200, foat vec
  def predict(self, instance):
    dict_score = {}
    score = self.model.predict_proba(instance, batch_size=1, verbose=1)
    for i in range(len(score[0])):
      dict_score[i] = score[0][i]

    #按类别概率从大到小排序
    res = sorted(dict_score.iteritems(), key = lambda d:d[1], reverse = True)
    #将排序后的标号结果转为对应类别
    result = []
    for label_idx, score in res:
      if not self.dict_category.has_key(label_idx):
        sys.stderr.write("don't contain lable idx: %d" %label_idx)
        continue

      result.append((self.dict_category[label_idx], score))

    return result

  def size():
    return (self.word_length, self.word_dim)

if __name__=='__main__':
  lstm = cnn_lstm("cnn_architecture.json", "cnn_weights.h5", "category.txt")
  test_case = np.random.random(lstm.size())
  #测试用例（输入为二维，但需转换为三维）
  test_casee = zeros([1, word_length, word_dim], float)
  test_casee[0] = test_case
  #test = cnn_lstm(temp_test, sys.argv[1], sys.argv[2], sys.argv[3])
  wyman = lstm.predict(test_casee)
  print wyman
