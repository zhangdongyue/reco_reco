#!encoding=utf8
import sys, Queue, threading, time
import dao,pusher

# get item id from db check category from hbase, generate source,title,content for classifier
# class CandidatesDetector(threading.Thread):
#   def __init__(self):
class ItemClassifier(threading.Thread):
  def __init__(self, thread_id, task_queue, title_category_queue):
    threading.Thread.__init__(self)
    self.thread_id = thread_id
    self.task_queue = task_queue
    self.result_queue = result_queue

    self.running = True
  
  def is_running(self):
    return self.running

  def run(self):
    while not self.task_queue.empty():
      instance = [1, [], []];
      try:
        instance = self.task_queue.get(True, 5)
      except:
        sys.stderr.write("get task failed")
        continue

    self.running = False 
    print "exist spider worker: %d" %self.thread_id

def main():
  if len(sys.argv) != 4:
    sys.stderr.write("usage: %s $level2_input $out_file thread_num")
    exit(-1)

  item_id_queue = Queue.Queue(100000)
  # get  item_id from 
  title_category_queue = Queue.Queue(1000)
  # spider worker start
  thread_num = int(sys.argv[3])
  threads = []
  for i in range(0, thread_num):
    threads.append(SpiderWorker(i, spider_queue, title_category_queue))
    threads[len(threads) - 1].start()
  
  fout = open(sys.argv[2], "w")
  num = 0 
  while True:
    if title_category_queue.qsize() < 1:
      stop_num = 0
      for worker in threads:
        if not worker.is_running():
          stop_num += 1

      if stop_num == len(threads):
        break;
      
      print "stopnum=%d and sleep for 2 seconds" %stop_num
      time.sleep(2)
      continue

    strs = title_category_queue.get(True, 5)
    num += len(strs)
    for title_category_str in strs:
      fout.write(title_category_str)
      fout.write("\n")

  fout.flush()
  print "title num: %d" %num
    
def GenerateLevel2CategoryCandidate():
  # level1 category url only used for generate level2 candidates
  level1_category_url = {"国内"  : "http://news.baidu.com/n?cmd=4&class=civilnews",
                         "国际"  : "http://news.baidu.com/n?cmd=4&class=internews",
                         "军事"  : "http://news.baidu.com/n?cmd=4&class=mil",
                         "财经"  : "http://news.baidu.com/n?cmd=4&class=finannews",
                         "互联网": "http://news.baidu.com/n?cmd=4&class=internet",
                         "房产"  : "http://news.baidu.com/n?cmd=4&class=housenews",
                         "汽车"  : "http://news.baidu.com/n?cmd=4&class=autonews",
                         "体育"  : "http://news.baidu.com/n?cmd=4&class=sportnews",
                         "娱乐"  : "http://news.baidu.com/n?cmd=4&class=enternews",
                         "游戏"  : "http://news.baidu.com/n?cmd=4&class=gamenews",
                         "教育"  : "http://news.baidu.com/n?cmd=4&class=edunews",
                         "女人"  : "http://news.baidu.com/n?cmd=4&class=healthnews",
                         "科技"  : "http://news.baidu.com/n?cmd=4&class=technnews",
                         "社会"  : "http://news.baidu.com/n?cmd=4&class=socianews",
                         };

  fout = open("candidate.txt", "w")
  for level1_category, url in level1_category_url.items():
    response = urllib2.urlopen(url)
    soup = BeautifulSoup(response.read())

    # parse all the level2 category
    for e in soup.select('#nav_sub > a'):
      fout.write("%s\t%s\t%s\n" %(level1_category, e.getText().encode("utf8"), e.get("href")))

if __name__ == "__main__":
  # GenerateLevel2CategoryCandidate()
  main()
