#!/usr/local/bin/python
# encoding: utf-8
import sys,MySQLdb
class ItemDao:
  def __init__(self, host, port, user, passwd):
     # 打开数据库连接
    self.db = MySQLdb.connect(host=host, port=port, user=user, passwd=passwd, db="reco")

  # timestr: 2016-07-03 12:00:00
  def GetItemIdAfterTime(self, time_str):
    # 使用cursor()方法获取操作游标
    self.cursor = self.db.cursor()
    sql = "select item_id from tb_item_info where create_time>\"%s\"" %time_str
    item_id_list = []
    try:
      # 执行SQL语句
      self.cursor.execute(sql)
      # 获取所有记录列表
      results = self.cursor.fetchall()
      for row in results:
        item_id_list.append(row[0])
    except:
      sys.stderr.write("Error: unable to fecth data")

    return item_id_list

if __name__ == "__main__":
  if len(sys.argv) < 6:
    print "usage: %s host port user passwd timestr" %sys.argv[0]
    sys.exit(-1)

  dao = ItemDao(sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4])
  item_id_list = dao.GetItemIdAfterTime(sys.argv[5]);
  print item_id_list
  # print "\n".join(item_id_list)
