#pragma once

namespace reco {
namespace item_classify {
class Dao;
class LabelRequest;
class TaskScheduler;

class LabelController {
 public:
  explicit LabelController(Dao* dao, TaskScheduler* scheduler);

  ~LabelController();

  // 异步
  bool SearchForCandidates(const LabelRequest& request);

  // 异步
  bool Train(const LabelRequest& request);

  // 异步
  bool Predict(const LabelRequest& request);

 private:
  Dao* dao_;
  TaskScheduler* scheduler_;
};
}
}
