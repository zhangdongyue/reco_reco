#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/item_classify.pb.h"

DEFINE_string(label_server_ip, "127.0.0.1", "sim item server ip");
DEFINE_int32(label_server_port, 20004, "sim item server port");

DEFINE_int32(send_worker_num, 8, "thread num for send request");

static void GenerateRequest(std::istream* in,
                            thread::BlockingQueue<reco::item_classify::LabelRequest>* request_queue) {  // NOLINT
  std::string line;
  std::vector<std::string> tokens;
  std::vector<uint64> item_ids;
  std::vector<std::string> words;
  reco::item_classify::LabelRequest request;
  while (std::getline(*in, line)) {
    if (line.size() < 5) {
      LOG(ERROR) << "erro line: " << line;
      continue;
    }

    tokens.clear();
    base::SplitString(line, "\t", &tokens);

    if (tokens.size() < 4) continue;
    request.Clear();
    request.set_task_id(base::ParseUint64OrDie(tokens[0]));
    request.set_type(base::ParseIntOrDie(tokens[1]));
    request.set_level1(tokens[2]);
    request.set_level2(tokens[3]);

    if (request.type() == 0) {
      CHECK_GT(tokens.size(), 4u);
      request.set_data_num(1000);
      for (size_t i = 4; i < tokens.size(); ++i) {
        reco::item_classify::Keywords* keywords = request.add_condition();
        words.clear();
        base::SplitString(tokens[i], "|", &words);
        for (size_t j = 0; j < words.size(); ++j) {
          keywords->add_keyword(words[j]);
        }
      }
    }
    request_queue->Put(request);

    if (in->eof()) break;
  }
  LOG(INFO) << "finish reading";
  request_queue->Close();
}

static void SendWorker(thread::BlockingQueue<reco::item_classify::LabelRequest>* request_queue) {
  net::rpc::RpcClientChannel channel(FLAGS_label_server_ip.c_str(), FLAGS_label_server_port);
  CHECK(channel.Connect());
  reco::item_classify::LabelService::Stub stub(&channel);
  reco::item_classify::LabelResponse response;
  reco::item_classify::LabelRequest request;

  while (!(request_queue->Closed() && request_queue->Empty())) {
    if (request_queue->Empty()) {
      LOG_EVERY_N(INFO, 1000) << "send workersleep";
      base::SleepForSeconds(1);
      continue;
    }
    if (!request_queue->Take(&request)) break;
    net::rpc::RpcClientController rpc;
    rpc.SetTimeout(500);
    stub.LabelData(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.succ()) {
      LOG(ERROR) << "label failed: " << request.task_id()
                 << "rpc.status()=" << rpc.status() << " response.success())=" << response.succ();
      continue;
    }
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "label client");
  thread::ThreadPool pool(FLAGS_send_worker_num + 2);

  thread::BlockingQueue<reco::item_classify::LabelRequest> request_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));

  pool.AddTask(::NewCallback(&GenerateRequest, &std::cin, &request_queue));
  for (int i = 0; i < FLAGS_send_worker_num; ++i) {
    pool.AddTask(::NewCallback(&SendWorker, &request_queue));
  }

  pool.JoinAll();
  return 0;
}
