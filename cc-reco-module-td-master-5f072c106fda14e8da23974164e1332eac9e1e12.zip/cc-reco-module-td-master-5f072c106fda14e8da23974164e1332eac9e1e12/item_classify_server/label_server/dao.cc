#include "reco/module/item_classify_server/label_server/dao.h"

#include <unordered_map>
#include <vector>
#include <string>
#include "base/common/scoped_ptr.h"

#include "base/common/base.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_util.h"
#include "base/common/closure.h"
#include "base/time/timestamp.h"
#include "base/thread/thread_pool.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "serving_base/utility/time_helper.h"
#include "base/common/scoped_ptr.h"
#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/resultset.h"
#include "reco/module/item_classify_server/label_server/define.h"

namespace reco {
namespace item_classify {

const char* Dao::kTableLabelData = "tb_label_labelled_data";
const char* Dao::kTableLabelTask = "tb_label_task";
const char* Dao::kTablePredictData = "tb_label_model_recalled";
const char* Dao::kTableItemData = "tb_item_info";
const std::string kSmallCateName = "小众一级分类";

Dao::Dao(serving_base::mysql_util::DbConnManager* db_manager) {
  db_manager_ = db_manager;
}

Dao::~Dao() {}

bool Dao::FilterDataInTable(const std::string& level1, const std::string& level2,
                            std::vector<uint64>& items,
                            std::unordered_map<uint64, std::pair<int, std::string> >* old_dict) {
  std::string sql = base::StringPrintf("select itemid,status,title from %s where level1=\"%s\""
                                               "and level2=\"%s\" and itemid in (\"0\"",
                                       kTableLabelData, level1.c_str(), level2.c_str());
  for (int i = 0; i < (int) items.size(); ++i) {
    sql += ",";
    sql += base::StringPrintf("\"%lu\"", items.at(i));
  }
  sql += ");";

  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, 3));
  if (res == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }

  while (res->next()) {
    uint64 item_id;
    base::StringToUint64(res->getString("itemid"), &item_id);
    int status = res->getInt("status");
    std::string title = res->getString("title");
    old_dict->insert(std::make_pair(item_id, std::make_pair(status, title)));
  }
  return true;
}

bool Dao::FilterLabelData(const std::string& level1, const std::string& level2,
                          const std::vector<Sample>& samples,
                          std::unordered_map<uint64, int>* old_dict) {
  std::string sql = base::StringPrintf("select itemid,status from %s where level1=\"%s\""
                                               "and level2=\"%s\" and itemid in (\"0\"",
                                       kTableLabelData, level1.c_str(), level2.c_str());
  for (size_t i = 0; i < samples.size(); ++i) {
    sql += ",";
    sql += base::StringPrintf("%lu", samples[i].item_id);
  }
  sql += ");";
  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, 3));
  if (res == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }

  while (res->next()) {
    uint64 item_id;
    base::StringToUint64(res->getString("itemid"), &item_id);
    int status = res->getInt("status");
    if (status != 0) {
      old_dict->insert(std::make_pair(item_id, status));
    }
  }
  return true;
}

int Dao::ReadTaskStatus(uint64 task_id) {
  std::string sql = base::StringPrintf("select status from %s where task_id=%lu;", kTableLabelTask, task_id);
  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, 3));
  if (res == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return -1;
  }

  if (!res->next()) {
    LOG(ERROR) << "empty task record for " << task_id;
    return -1;
  }

  return res->getInt("status");
}

bool Dao::ModifyTask(uint64 task_id, int status, const std::string& note) {
  // std::string sql = base::StringPrintf("update %s t set t.status=%d,t.note=\"%s\" where t.task_id=%lu",
  //                                      kTableLabelTask, status, note.c_str(), task_id);
  std::string sql = base::StringPrintf(
          "update %s set status=%d, note=\"%s\",operator=\"Classification labeling server\" where task_id=%lu;",  // NOLINT
          kTableLabelTask, status, note.c_str(), task_id);

  int32 sql_status = db_manager_->ExecuteUpdateWithRetry(sql, 3);
  if (sql_status < 1) {
    LOG(ERROR) << "sql: " << sql;
    return false;
  }
  return true;
}

bool Dao::WriteLabelData(uint64 task_id, const std::string& level1, const std::string& level2,
                         std::vector<uint64>& item_ids,
                         std::vector<std::string>& titles) {
  // select from sql to decede new data
  std::unordered_map<uint64, std::pair<int, std::string>> old_dict;
  // 过滤掉不是当前一级的数据
  std::vector<uint64> valid_itemids;
  std::vector<std::string> valid_item_titles;
  std::string cate_sql;
  cate_sql = base::StringPrintf("select item_id,title,category from %s  where item_id in (\"0\"",
                                kTableItemData);

  for (int i = 0; i < (int) item_ids.size(); ++i) {
    cate_sql += ",";
    cate_sql += base::StringPrintf("\"%lu\"", item_ids[i]);

    if (i % 1000 == 999 || i == (int) item_ids.size() - 1) {
      cate_sql += ");";
      scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(cate_sql, 3));
      while (res->next()) {
        uint64 itemid;
        base::StringToUint64(res->getString("item_id"), &itemid);
        std::string category = res->getString("category");
        std::string title;
        base::FastStringReplace(res->getString("title"), "\"", "", true, &title);

        if (level1 != kSmallCateName && category.find(level1) == std::string::npos)
          continue;
        valid_itemids.push_back(itemid);
        valid_item_titles.push_back(title);
      }

      cate_sql = base::StringPrintf("select item_id,title,category from %s  where item_id in (\"0\"",
                                    kTableItemData);
    }
  }
  item_ids.swap(valid_itemids);
  titles.swap(valid_item_titles);
  FilterDataInTable(level1, level2, item_ids, &old_dict);
  std::unordered_map<std::string, int> item_titles;
  for (auto iterator = old_dict.begin(); iterator != old_dict.end(); ++iterator) {
    item_titles.insert(std::make_pair(iterator->second.second, 1));
  }
  std::unordered_map<uint64, std::string> new_items;
  for (int i = 0; i < (int) item_ids.size(); ++i) {
    if (old_dict.find(item_ids.at(i)) == old_dict.end()
        && new_items.find(item_ids.at(i)) == new_items.end()
        && item_titles.find(titles.at(i)) == item_titles.end()) {
      new_items.insert(std::make_pair(item_ids.at(i), titles.at(i)));
      item_titles.insert(std::make_pair(titles.at(i), 1));
    }
  }
  uint64 timestamp = base::GetTimestamp();
  std::string time_str;
  if (!serving_base::TimeHelper::TimestampToString(timestamp, serving_base::TimeHelper::kSecond, &time_str)) {
    LOG(ERROR) << "wrong timestamp " << timestamp;
    return false;
  }

  std::string str = base::StringPrintf("insert into %s(itemid,level1,level2,update_time,title) values",
                                       kTableLabelData);

  const int kBatch = 100;
  int count = 0;
  std::string sql = str;

  thread::ThreadPool write_label_pool(32);
  std::string title;
  for (auto it = new_items.begin(); it != new_items.end(); ++it) {
    if (count > 0) {
      sql.append(",");
    }
    title.clear();
    base::FastStringReplace(it->second, "\"", "", true, &title);
    sql += base::StringPrintf("(\"%lu\",\"%s\",\"%s\",\"%s\",\"%s\")", it->first, level1.c_str(),
                              level2.c_str(), time_str.c_str(), title.c_str());
    if (++count >= kBatch) {
      sql += ";";
      write_label_pool.AddTask(::NewCallback(this, &Dao::DoUpdate, sql));
      sql = str;
      count = 0;
    }
  }

  if (count > 0) {
    sql += ";";
    write_label_pool.AddTask(::NewCallback(this, &Dao::DoUpdate, sql));
  }
  write_label_pool.JoinAll();

  LOG(INFO) << base::StringPrintf("finish write label data for task: %lu, itemnum=%lu",
                                  task_id, new_items.size());
  return true;
}

bool Dao::WritePredictData(uint64 task_id, const std::string& level1, const std::string& level2,
                           const std::vector<Sample>& samples) {
  // select from sql to decede new data
  std::unordered_map<uint64, int> old_dict;
  FilterLabelData(level1, level2, samples, &old_dict);
  LOG(INFO) << "old_dict.size()" << old_dict.size();
  std::vector<std::pair<uint64, int> > new_items;
  new_items.reserve(samples.size());
  for (size_t i = 0; i < samples.size(); ++i) {
    if (old_dict.find(samples[i].item_id) == old_dict.end()) {
      new_items.push_back(std::make_pair(samples[i].item_id, i));
    }
  }

  uint64 timestamp = base::GetTimestamp();
  std::string time_str;
  if (!serving_base::TimeHelper::TimestampToString(timestamp, serving_base::TimeHelper::kSecond, &time_str)) {
    LOG(ERROR) << "wrong timestamp " << timestamp;
    return false;
  }
  // 清除对应的数据
  std::string sql = base::StringPrintf("delete from %s  where level1=\"%s\" and level2=\"%s\";",
                                       kTablePredictData, level1.c_str(), level2.c_str());

  int32 sql_status = db_manager_->ExecuteUpdateWithRetry(sql, 3);
  if (sql_status < 0) {
    LOG(ERROR) << "sql: " << sql;
    return false;
  }

  std::string base_str = base::StringPrintf(
          "insert into %s(itemid,level1,level2,update_time,predict,title,predict_score) values",  // NOLINT
          kTablePredictData);

  const int kBatch = 100;
  int count = 0;
  sql = base_str;

  thread::ThreadPool pool(32);
  std::string title;
  for (size_t i = 0; i < new_items.size(); ++i) {
    if (count > 0) {
      sql.append(",");
    }
    int idx = new_items[i].second;
    title.clear();
    base::FastStringReplace(samples[idx].title, "\"", "\\\"", true, &title);
    sql += base::StringPrintf("(\"%lu\",\"%s\",\"%s\",\"%s\",\"%d\",\"%s\",\"%f\")", samples[idx].item_id,
                              level1.c_str(), level2.c_str(), time_str.c_str(),
                              samples[idx].label, title.c_str(), samples[idx].score);
    if (++count >= kBatch) {
      sql += ";";
      pool.AddTask(::NewCallback(this, &Dao::DoUpdate, sql));
      sql = base_str;
      count = 0;
    }
  }

  if (count > 0) {
    sql += ";";
    pool.AddTask(::NewCallback(this, &Dao::DoUpdate, sql));
  }
  pool.JoinAll();

  LOG(INFO) << "finish write predict data for task: " << task_id;
  return true;
}

bool Dao::ReadAllLabelData(const std::string& level1, const std::string& level2,
                           std::vector<std::pair<uint64, int> >* samples) {
  std::string sql = base::StringPrintf("select itemid,status from %s where level1=\'%s\' and level2=\'%s\'",
                                       kTableLabelData, level1.c_str(), level2.c_str());

  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, 3));
  if (res == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }

  while (res->next()) {
    uint64 item_id;
    base::StringToUint64(res->getString("itemid"), &item_id);
    int status = res->getInt("status");
    samples->push_back(std::make_pair(item_id, status));
  }
  return true;
}

bool Dao::ReadRecentData(const std::string& level1, const std::string& level2,
                         std::vector<uint64>* samples) {
  uint64 timestamp = 0;
  CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond, &timestamp));
  timestamp -= 24 * 3600 * 1000000lu;  // last day

  std::string time_str;
  CHECK(serving_base::TimeHelper::TimestampToString(timestamp, serving_base::TimeHelper::kSecond, &time_str));

  std::string sql = base::StringPrintf(
          "select item_id from tb_item_info where category like \'%%%s\' and create_time>\"%s\";",  // NOLINT
          level1.c_str(), time_str.c_str());

  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, 3));
  if (res == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }

  while (res->next()) {
    uint64 item_id;
    base::StringToUint64(res->getString("item_id"), &item_id);
    samples->push_back(item_id);
  }

  return true;
}

bool Dao::ReadSourceData(const std::vector<std::string>& source,
                         const std::vector<int>& types,
                         int limit,
                         std::vector<std::pair<uint64, std::string> >* item_ids) {
  if (source.size() == 0u) {
    return false;
  }
  uint64 timestamp = 0;
  CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond, &timestamp));

  timestamp -= 30 * 24 * 3600 * 1000000lu;

  std::string time_str;
  CHECK(serving_base::TimeHelper::TimestampToString(timestamp, serving_base::TimeHelper::kSecond, &time_str));
  item_ids->clear();
  std::string sql = base::StringPrintf("select item_id,title from tb_item_info where (1=2");
  for (int i = 0; i < (int) source.size(); ++i) {
    sql.append(base::StringPrintf(" or source like '%s'", source[i].c_str()));
  }
  sql.append(" ) and item_type in (-1");
  for (size_t i = 0; i < types.size(); ++i) {
    sql.append(",");
    sql.append(base::IntToString(types[i]));
  }
  sql.append(base::StringPrintf(") and create_time >\"%s\"", time_str.c_str()));
  sql.append(base::StringPrintf("  order by create_time desc limit %d", limit));
  LOG(INFO) << sql;
  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, 3));
  if (res == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }

  while (res->next()) {
    uint64 itemid;
    base::StringToUint64(res->getString("item_id"), &itemid);
    item_ids->push_back(std::make_pair(itemid, res->getString("title")));
  }
  return true;
}

bool Dao::ReadCateData(const std::string& level1, const std::string& level2,
                       const std::vector<int>& types,
                       int limit, bool with_old_data,
                       std::vector<std::pair<uint64, std::string> >* item_ids) {
  item_ids->clear();
  std::string sql;
  uint64 timestamp = 0;
  CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond, &timestamp));

  timestamp -= 7 * 24 * 3600 * 1000000lu;

  std::string time_str;
  CHECK(serving_base::TimeHelper::TimestampToString(timestamp, serving_base::TimeHelper::kSecond, &time_str));
  if (level1 == kSmallCateName) {
    limit = limit * 5;
  }
  if (with_old_data) {
    // 当前二级分类下面的 item
    if (level1 != kSmallCateName) {
      sql = base::StringPrintf("select item_id,title from tb_item_info where category like '%s,%s'",
                               level1.c_str(), level2.c_str());
      sql.append(base::StringPrintf(" and create_time >\"%s\"", time_str.c_str()));
    } else {
      sql = base::StringPrintf("select item_id,title from tb_item_info where category = '%s'",
                               level2.c_str());
    }
    sql.append(" and item_type in (-1");
    for (size_t i = 0; i < types.size(); ++i) {
      sql.append(",");
      sql.append(base::IntToString(types[i]));
    }
    sql.append(base::StringPrintf(") order by create_time desc limit %d", limit));

    LOG(INFO) << sql;
    scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, 3));
    if (res.get() == NULL) {
      LOG(ERROR) << "null resultset for sql: " << sql;
      return false;
    }

    while (res->next()) {
      uint64 itemid;
      base::StringToUint64(res->getString("item_id"), &itemid);
      item_ids->push_back(std::make_pair(itemid, res->getString("title")));
    }
  }

  if (level1 != kSmallCateName) {
    // 一级下面对应的负样本
    sql = base::StringPrintf(
            "select item_id,title from tb_item_info where category not like '%s,%s'",
            level1.c_str(), level2.c_str());

    sql.append(" and category like '" + level1 + "\%' and create_time >\"" + time_str + "\"");  // NOLINT
  } else {
    sql = base::StringPrintf(
            "select item_id,title from tb_item_info where category not like '%s'",
            level2.c_str());
    sql.append(" and create_time >\"" + time_str + "\"");
  }
  sql.append(" and item_type in (-1");
  for (size_t i = 0; i < types.size(); ++i) {
    sql.append(",");
    sql.append(base::IntToString(types[i]));
  }
  sql.append(base::StringPrintf(") order by create_time desc limit %d", limit * 2));
  LOG(INFO) << sql;

  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, 3));

  if (res.get() == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }

  while (res->next()) {
    uint64 itemid;
    base::StringToUint64(res->getString("item_id"), &itemid);
    item_ids->push_back(std::make_pair(itemid, res->getString("title")));
  }
  return true;
}
}
}
