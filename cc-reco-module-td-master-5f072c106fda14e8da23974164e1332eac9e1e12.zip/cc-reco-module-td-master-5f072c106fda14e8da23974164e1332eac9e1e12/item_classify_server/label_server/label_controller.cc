#include "reco/module/item_classify_server/label_server/label_controller.h"

#include <vector>
#include <string>

#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "reco/module/item_classify_server/label_server/dao.h"
#include "reco/module/item_classify_server/label_server/define.h"
#include "reco/module/item_classify_server/label_server/task_scheduler.h"

namespace reco {
namespace item_classify {

LabelController::LabelController(Dao* dao, TaskScheduler* scheduler) {
  // TODO(xielang): use shared ptr
  dao_ = dao;
  scheduler_ = scheduler;
}

LabelController::~LabelController() {
  dao_ = NULL;
  scheduler_ = NULL;
}

bool LabelController::SearchForCandidates(const LabelRequest& request) {
  int status = dao_->ReadTaskStatus(request.task_id());
  if (status == kDataFilling) {
    LOG(ERROR) << " task is data filling! " << request.task_id();
    return false;
  }

  scheduler_->AddTask(request);
  return true;
}

bool LabelController::Train(const LabelRequest& request) {
  int status = dao_->ReadTaskStatus(request.task_id());
  if (status == kTraining) {
    LOG(ERROR) << " task is training!" << request.task_id();
    return false;
  }

  scheduler_->AddTask(request);
  return true;
}

bool LabelController::Predict(const LabelRequest& request) {
  int status = dao_->ReadTaskStatus(request.task_id());
  if (status == kPredicting) {
    LOG(ERROR) << " task is predicting!" << request.task_id();
    return false;
  }

  scheduler_->AddTask(request);
  return true;
}
}
}
