#include "reco/module/item_classify_server/label_server/task_scheduler.h"

#include <vector>
#include <string>
#include <utility>
#include "nlp/common/nlp_util.h"
#include "base/strings/string_util.h"
#include "base/common/basic_types.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/proto/reco_search_server.pb.h"
#include "reco/module/item_classify_server/label_server/label_ops.h"
#include "reco/module/item_classify_server/label_server/dao.h"
#include "reco/module/item_classify_server/common/DingdingMsg.h"

DEFINE_string(search_server_ips, "11.251.206.226", "sep by ,");
DEFINE_int32(search_server_port, 20011, "search server port");
DEFINE_int32(max_result_num, 2000, "max return num for search");
DEFINE_int32(max_source_result_num, 2000, "max return num for search");
DEFINE_int32(max_cate_result_num, 2000, "max return num for search");

DEFINE_int32(max_search_fail_num, 5, "max search fail num for search");

DEFINE_int32(neg_sample_number, 2000, "neg_sample_number");
DEFINE_int32(pos_sample_number, 4000, "pos_sample_number");

namespace reco {
namespace item_classify {
static const int kMinCoreDataNum = 100;

static net::rpc::RpcGroup* SetupConnection(const std::vector<std::string>& ips, int port,
                                           int timeout, int retry) {
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = retry;
  options.timeout = timeout;
  for (int i = 0; i < (int) ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], port, timeout);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup* group = new net::rpc::RpcGroup(options);
  CHECK(group->Connect());
  return group;
}

TaskScheduler::TaskScheduler(int thread_num, Dao* dao, reco::HBasePoolGetSim* hbase_pool_get_sim) {
  std::vector<std::string> flds;
  base::SplitString(FLAGS_search_server_ips, ",", &flds);
  search_rpc_group_ = SetupConnection(flds, FLAGS_search_server_port, 1000, 3);
  dao_ = dao;
  hbase_pool_get_sim_ = hbase_pool_get_sim;
  search_request_matrix_ = new std::vector<thread::BlockingQueue<LabelRequest>*>();
  train_request_matrix_ = new std::vector<thread::BlockingQueue<LabelRequest>*>();
  predict_request_matrix_ = new std::vector<thread::BlockingQueue<LabelRequest>*>();

  for (int i = 0; i < thread_num; ++i) {
    search_request_matrix_->push_back(new thread::BlockingQueue<LabelRequest>());
    train_request_matrix_->push_back(new thread::BlockingQueue<LabelRequest>());
    predict_request_matrix_->push_back(new thread::BlockingQueue<LabelRequest>());
  }

  search_data_pool_ = new thread::ThreadPool(thread_num);
  train_pool_ = new thread::ThreadPool(thread_num);
  predict_pool_ = new thread::ThreadPool(thread_num);

  stop_ = false;
  for (int i = 0; i < thread_num; ++i) {
    search_data_pool_->AddTask(::NewCallback(this, &TaskScheduler::SearchCandidatesWorker, i,
                                             search_request_matrix_->at(i)));
    train_pool_->AddTask(::NewCallback(this, &TaskScheduler::TrainWorker, i, train_request_matrix_->at(i)));
    predict_pool_->AddTask(::NewCallback(this, &TaskScheduler::PredictWorker, i,
                                         predict_request_matrix_->at(i)));
  }
}

void TaskScheduler::stop() {
  if (stop_) return;
  stop_ = true;
  for (size_t i = 0; i < search_request_matrix_->size(); ++i) {
    search_request_matrix_->at(i)->Close();
  }

  for (size_t i = 0; i < train_request_matrix_->size(); ++i) {
    train_request_matrix_->at(i)->Close();
  }

  for (size_t i = 0; i < predict_request_matrix_->size(); ++i) {
    predict_request_matrix_->at(i)->Close();
  }

  search_data_pool_->JoinAll();
  train_pool_->JoinAll();
  predict_pool_->JoinAll();
}

bool TaskScheduler::AddTask(const LabelRequest& request) {
  int idx = 0;
  switch (request.type()) {
    case 0:
      idx = request.task_id() % search_request_matrix_->size();
      search_request_matrix_->at(idx)->Put(request);
      break;
    case 1:
      idx = request.task_id() % train_request_matrix_->size();
      train_request_matrix_->at(idx)->Put(request);
      break;
    case 2:
      idx = request.task_id() % predict_request_matrix_->size();
      predict_request_matrix_->at(idx)->Put(request);
      break;
    default:
      LOG(ERROR) << "erro type task: " << request.type() << " for task: " << request.task_id();
      return false;
  }
  return true;
}

void inline GetItemtypeWhiteList(const LabelRequest& request, std::vector<int>* item_types) {
  item_types->clear();
  if (request.item_types_size() > 0) {
    for (int i = 0; i < request.item_types_size(); ++i) {
      item_types->push_back(request.item_types(i));
    }
  } else {
    // 如果不传的话，就默认认为是文本类型的, 兼容历史版本数据
    item_types->push_back((int) kNews);
    item_types->push_back((int) kReading);
    item_types->push_back((int) kPicture);
    item_types->push_back((int) kPictureNews);
  }
  return;
}

void TaskScheduler::SearchCandidatesWorker(int thread_id,
                                           thread::BlockingQueue<LabelRequest>* request_queue) {
  reco::searchserver::SearchService::Stub stub(search_rpc_group_);
  reco::searchserver::StructuredSearchRequest search_request;
  reco::searchserver::StructuredSearchResponse search_response;
  LabelRequest request;
  std::vector<int> item_types;
  while (!stop_ && !(request_queue->Closed() && request_queue->Empty())) {
    if (!request_queue->Take(&request)) {
      break;
    }
    LOG(INFO) << request.Utf8DebugString();
    GetItemtypeWhiteList(request, &item_types);
    int status = dao_->ReadTaskStatus(request.task_id());
    if (status == kDataFilling) {
      LOG(ERROR) << "skip task, already on filling data " << request.task_id();
      continue;
    }
    std::vector<uint64> item_ids;
    std::vector<std::string> item_titles;

    if (request.condition_size() == 0) {
      std::string msg = base::StringPrintf("关键字不能为空 task: %lu",
                                           request.task_id());
      LOG(ERROR) << msg;
      dao_->ModifyTask(request.task_id(), kFailed, msg);
      continue;
    }
    std::vector<std::string> sources;
    std::vector<std::string> keyword_sources;
    keyword_sources.push_back("%" + request.level2() + "%");
    bool use_old_data = false;

    for (int i = 0; i < request.condition_size(); ++i) {
      bool special_keyword = false;
      std::string buf = "";
      for (int j = 0; j < request.condition(i).keyword_size(); ++j) {
        buf.append(request.condition(i).keyword(j));
      }
      nlp::util::NormalizeLineInPlaceS(&buf);
      if (buf.find("source:") != std::string::npos) {
        buf = base::StringReplace(buf, "source:", "", true);
        sources.push_back(buf);
        special_keyword = true;
      }
      if (buf.find("onlinedata") != std::string::npos) {
        use_old_data = true;
        special_keyword = true;
      }
      search_request.set_use_cached_rslt(true);
      if (!special_keyword) {
        search_request.add_or_words(buf);
        keyword_sources.push_back("%" + buf + "%");
      }
      if (search_request.or_words_size() == 3 || i == request.condition_size() - 1) {
        search_request.set_result_num(FLAGS_max_result_num);
        if (request.data_num() < FLAGS_max_result_num && request.data_num() > 0) {
          search_request.set_result_num(request.data_num());
        }

        net::rpc::RpcClientController rpc;
        rpc.SetTimeout(20000);
        for (size_t l = 0; l < item_types.size(); ++l) {
          search_request.add_item_type(static_cast<reco::ItemType>(item_types[l]));
        }
        stub.StructuredSearch(&rpc, &search_request, &search_response, NULL);
        rpc.Wait();
        LOG(ERROR) << search_request.Utf8DebugString() << " search_response.item_id_size()="
                   << search_response.item_id_size();
        if (rpc.status() != net::rpc::RpcClientController::kOk
            || !search_response.success() || search_response.item_id_size() == 0) {
          std::string msg = base::StringPrintf("数据拉取失败，检查关键词或者重新拉取得数据 task: %lu msg:%s ",
                                               request.task_id(), search_response.err_message().c_str());
          LOG(ERROR) << msg;
          LOG(ERROR) << "rpc.status()=" << rpc.status() << "rpc.error_text()=" << rpc.error_text();
          search_request.Clear();
          // dao_->ModifyTask(request.task_id(), kFailed, msg);
          continue;
        }
        for (int j = 0; j < (int) search_response.item_id_size(); ++j) {
          item_ids.push_back(search_response.item_id().Get(j));
          item_titles.push_back(search_response.item_title().Get(j));
        }
        search_request.Clear();
        search_response.Clear();
      }
    }

    std::vector<std::pair<uint64, std::string>> items;
    if (sources.size() > 0) {
      dao_->ReadSourceData(sources, item_types, FLAGS_max_source_result_num, &items);
      for (int k = 0; k < (int) items.size(); ++k) {
        item_ids.push_back(items[k].first);
        item_titles.push_back(items[k].second);
      }
    }
    if (keyword_sources.size() > 0) {
      // 关键词扩展的源
      dao_->ReadSourceData(keyword_sources, item_types, FLAGS_max_source_result_num * 2, &items);
      for (int k = 0; k < (int) items.size(); ++k) {
        item_ids.push_back(items[k].first);
        item_titles.push_back(items[k].second);
      }
    }
    dao_->ReadCateData(request.level1(), request.level2(),
                       item_types,
                       FLAGS_max_cate_result_num, use_old_data, &items);
    for (int k = 0; k < (int) items.size(); ++k) {
      item_ids.push_back(items[k].first);
      item_titles.push_back(items[k].second);
    }
    if (item_ids.size() == 0) {
      std::string msg = base::StringPrintf("数据拉取失败，请检查关键词或者重新拉取得数据 task: %lu",
                                           request.task_id());
      LOG(ERROR) << msg;
      dao_->ModifyTask(request.task_id(), kFailed, msg);
      continue;
    }

    // LOG(INFO) << "search_response.item_id_size()=" << search_response.item_id_size();
    // write to db
    uint64 task_id = request.task_id();
    const std::string& level1 = request.level1();
    const std::string& level2 = request.level2();
    if (!dao_->WriteLabelData(task_id, level1, level2,
                              item_ids, item_titles)) {
      std::string msg = base::StringPrintf("write candidats fail for task: %lu", request.task_id());
      LOG(ERROR) << msg;
      dao_->ModifyTask(request.task_id(), kFailed, msg);
      continue;
    }

    if (!dao_->ModifyTask(request.task_id(), kDataFilled, "")) {
      LOG(ERROR) << " write kDataFilled failed! for " << request.task_id();
    }
    DingdingMsg::sendDingdingMsg("【" + level1 + "," + level2 + "】数据拉取完成");
  }
  LOG(INFO) << "SearchCandidatesWorker end " << thread_id;
}

void TaskScheduler::TrainWorker(int thread_id, thread::BlockingQueue<LabelRequest>* request_queue) {
  ClassificationLabelingOps label_ops(dao_, hbase_pool_get_sim_);
  std::vector<std::pair<uint64, int> > data;
  LabelRequest request;
  std::vector<int> item_types;
  while (!stop_ && !(request_queue->Closed() && request_queue->Empty())) {
    if (!request_queue->Take(&request)) {
      break;
    }
    GetItemtypeWhiteList(request, &item_types);
    int status = dao_->ReadTaskStatus(request.task_id());
    if (status == kTraining) {
      LOG(ERROR) << "skip task, already on training " << request.task_id();
      continue;
    }

    dao_->ModifyTask(request.task_id(), kTraining, "");

    data.clear();
    if (!dao_->ReadAllLabelData(request.level1(), request.level2(), &data)) {
      std::string msg = base::StringPrintf("read core data failed. task: %lu", request.task_id());
      LOG(ERROR) << msg;
      dao_->ModifyTask(request.task_id(), kFailed, msg);
      continue;
    }

    if ((int) data.size() < kMinCoreDataNum) {
      std::string msg = base::StringPrintf("tool less data for training. task: %lu", request.task_id());
      LOG(ERROR) << msg;
      dao_->ModifyTask(request.task_id(), kFailed, msg);
      continue;
    }

    if (!label_ops.Train(request.task_id(), request.level1() + "," + request.level2(),
                         data, item_types,
                         FLAGS_pos_sample_number, FLAGS_neg_sample_number, true)) {
      std::string msg = base::StringPrintf("train failed fail for task: %lu", request.task_id());
      LOG(ERROR) << msg;
      dao_->ModifyTask(request.task_id(), kFailed, msg);
      continue;
    }

    if (!dao_->ModifyTask(request.task_id(), kTrained, "")) {
      LOG(ERROR) << "fatal modify finish training failed for " << request.task_id();
    }
    DingdingMsg::sendDingdingMsg("【" + request.level1() + "," + request.level2() + "】模型训练完成");
  }
  LOG(INFO) << "end Train thread: " << thread_id;
}

void TaskScheduler::PredictWorker(int thread_id, thread::BlockingQueue<LabelRequest>* request_queue) {
  ClassificationLabelingOps label_ops(dao_, hbase_pool_get_sim_);
  std::vector<uint64> item_ids;
  std::vector<Sample> results;
  std::vector<std::pair<uint64, int> > data;
  LabelRequest request;
  std::vector<int> item_types;

  while (!stop_ && !(request_queue->Closed() && request_queue->Empty())) {
    if (!request_queue->Take(&request)) {
      break;
    }
    LOG(INFO) << request.Utf8DebugString();
    GetItemtypeWhiteList(request, &item_types);
    if (request.type() != 2) {
      LOG(ERROR) << "err task in predicting worker: " << request.Utf8DebugString();
      continue;
    }

    int status = dao_->ReadTaskStatus(request.task_id());
    if (status == kPredicting) {
      LOG(ERROR) << "skip task, already on predicting " << request.task_id();
      continue;
    }

    if (!dao_->ModifyTask(request.task_id(), kPredicting, "")) {
      LOG(ERROR) << "fatal: training task conflict for " << request.task_id();
      continue;
    }

    item_ids.clear();
    data.clear();
    if (!dao_->ReadAllLabelData(request.level1(), request.level2(), &data)) {
      std::string msg = base::StringPrintf("read test data failed for task: %lu", request.task_id());
      LOG(ERROR) << msg;
      dao_->ModifyTask(request.task_id(), kFailed, msg);
      continue;
    }

    results.clear();
    for (size_t i = 0; i < data.size(); ++i) item_ids.push_back(data[i].first);
    LOG(INFO) << "item_ids.size()=" << item_ids.size();
    if (!label_ops.Predict(request.task_id(), item_ids, request.level1() + "," + request.level2(),
                           item_types,
                           0.55, &results)) {
      std::string msg = base::StringPrintf("预测失败 task: %lu", request.task_id());
      LOG(ERROR) << msg;
      dao_->ModifyTask(request.task_id(), kFailed, msg);
      continue;
    }
    if (results.size() == 0) {
      std::string msg = base::StringPrintf("预测任务失败，taskid=%lu", request.task_id());
      LOG(ERROR) << msg;
      dao_->ModifyTask(request.task_id(), kFailed, msg);
      continue;
    }
    LOG(INFO) << "results.size()=" << results.size();

    if (!dao_->WritePredictData(request.task_id(), request.level1(), request.level2(), results)) {
      std::string msg = base::StringPrintf("写入预测数据失败  task: %lu", request.task_id());
      LOG(ERROR) << msg;
      dao_->ModifyTask(request.task_id(), kFailed, msg);
      continue;
    }

    if (!dao_->ModifyTask(request.task_id(), kPredicted, "")) {
      LOG(ERROR) << "fatal modify finish predicting failed for " << request.task_id();
    }
    DingdingMsg::sendDingdingMsg("【" + request.level1() + "," + request.level2() + "】评测数据生成完毕");
  }
  LOG(INFO) << "end predict thread: " << thread_id;
}
}
}
