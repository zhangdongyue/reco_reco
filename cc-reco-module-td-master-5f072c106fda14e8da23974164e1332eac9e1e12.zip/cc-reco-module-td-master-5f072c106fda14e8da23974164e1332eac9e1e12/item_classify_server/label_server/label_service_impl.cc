#include "base/common/logging.h"
#include "reco/module/item_classify_server/label_server/label_service_impl.h"

#include "base/common/base.h"
#include "base/strings/string_printf.h"

#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/module/item_classify_server/label_server/label_controller.h"

namespace reco {
namespace item_classify {
void LabelServiceImpl::LabelData(::stumy::RpcController* controller,
                                 const LabelRequest* request,
                                 LabelResponse* response,
                                 Closure* done) {
  ScopedClosure scoped_done(done);
  response->set_succ(false);

  if (request->type() < 0 || request->type() > 2) {
    response->set_err_msg(base::StringPrintf("wrong request type: %d", request->type()));
    return;
  }

  LabelController* worker = NULL;
  int status = workers_->TimedTake(10, &worker);

  if (status == -1) {
    response->set_err_msg("server maybe closed!");
    return;
  }

  if (status == 0) {
    response->set_err_msg("timeout, server is busy");
    return;
  }

  // 所有的处理均是立即返回, 重复请求也直接处理
  // 搜索数据的重复请求
  bool succ = false;
  switch (request->type()) {
    case 0:
      succ = worker->SearchForCandidates(*request);
      break;
    case 1:
      succ = worker->Train(*request);
      break;
    case 2:
      succ = worker->Predict(*request);
      break;
    default:
      LOG(ERROR) << "wrong request type: " << request->type();
  }
  workers_->Put(worker);
  response->set_succ(succ);
  if (!succ) {
    response->set_err_msg("Duplicate operation!!");
  }
  LOG(INFO) << response->Utf8DebugString();
}
}
}
