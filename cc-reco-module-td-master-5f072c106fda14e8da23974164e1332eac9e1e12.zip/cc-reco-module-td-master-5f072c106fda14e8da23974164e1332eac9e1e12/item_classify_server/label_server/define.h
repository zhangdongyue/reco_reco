#pragma once

#include <string>
#include "base/common/basic_types.h"

namespace reco {
namespace item_classify {
struct Sample {
  uint64 item_id;
  std::string title;
  int label;
  double score;
};
}
}
