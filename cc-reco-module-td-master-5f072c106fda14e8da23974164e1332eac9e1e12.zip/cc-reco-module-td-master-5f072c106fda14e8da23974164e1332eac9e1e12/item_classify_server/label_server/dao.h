#pragma once

#include <google/protobuf/repeated_field.h>
#include <vector>
#include <string>
#include <utility>
#include <unordered_map>
#include "base/common/basic_types.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "reco/module/item_classify_server/label_server/define.h"

namespace reco {
namespace item_classify {
// thread safe
class Dao {
 public:
  explicit Dao(serving_base::mysql_util::DbConnManager* db_manager);

  ~Dao();

  bool WriteLabelData(uint64 task_id, const std::string& level1, const std::string& level2,
                      std::vector<uint64>& item_ids,
                      std::vector<std::string>& titles);

  bool WritePredictData(uint64 task_id, const std::string& level1, const std::string& level2,
                        const std::vector<Sample>& samples);

  bool ModifyTask(uint64 task_id, int status, const std::string& note);

  int ReadTaskStatus(uint64 task_id);

  bool ReadAllLabelData(const std::string& level1, const std::string& level2,
                        std::vector<std::pair<uint64, int> >* samples);

  // read recent from tb_item_info
  bool ReadRecentData(const std::string& level1, const std::string& level2,
                      std::vector<uint64>* samples);
  // 读取某个 source 下的 item
  bool ReadSourceData(const std::vector<std::string>& source,
                      const std::vector<int>& types,
                      int limit, std::vector<std::pair<uint64, std::string> >* item_ids);
  // 读取某个 category 下的 item , 包括小类以及大类
  bool ReadCateData(const std::string& level1, const std::string& level2,
                    const std::vector<int>& types,
                    int limit, bool with_old_data, std::vector<std::pair<uint64, std::string> >* item_ids);

  void DoUpdate(std::string sql) {
    int32 status = db_manager_->ExecuteUpdateWithRetry(sql, 3);
    if (status < 1) {
      LOG(ERROR) << "failed: " << sql;
    }
  }

 private:
  bool FilterLabelData(const std::string& level1, const std::string& level2,
                       const std::vector<Sample>& samples,
                       std::unordered_map<uint64, int>* old_dict);

  bool FilterDataInTable(const std::string& level1, const std::string& level2,
                         std::vector<uint64>& items,
                         std::unordered_map<uint64, std::pair<int, std::string> >* old_dict);

  static const char* kTableLabelData;
  static const char* kTableLabelTask;
  static const char* kTablePredictData;
  static const char* kTableItemData;

  serving_base::mysql_util::DbConnManager* db_manager_;
};
}
}
