#include "reco/module/item_classify_server/label_server/task_scheduler.h"

#include <string>
#include <vector>
#include <fstream>

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/random/pseudo_random.h"
#include "reco/module/item_classify_server/label_server/define.h"
#include "reco/module/item_classify_server/label_server/dao.h"

DEFINE_string(db_host, "tcp://11.251.206.209:3306", "dbhost");
DEFINE_string(db_user, "test", "db user");
DEFINE_string(db_passwd, "chuheridangwu", "db passwd");
DEFINE_string(schema, "test_reco", "shcema");
DEFINE_int32(thread_num, 4, "thread_num");

namespace reco {
namespace item_classify {

class TaskSchedulerTest : public testing::Test {
 public:
  static void SetUpTestCase() {
    // dao
    serving_base::mysql_util::DbConnManager::Option db_option;
    db_option.host = FLAGS_db_host;
    db_option.user = FLAGS_db_user;
    db_option.passwd = FLAGS_db_passwd;
    db_option.schema = FLAGS_schema;
    dao_ = new Dao(db_option);
    // scheduler
    scheduler_ = new TaskScheduler(FLAGS_thread_num, dao_);
    CHECK_NOTNULL(dao_);
    LOG(INFO) << "finish init task scheduler!";
  }

  static Dao* dao_;
  static TaskScheduler* scheduler_;
};
Dao* TaskSchedulerTest::dao_ = NULL;
TaskScheduler* TaskSchedulerTest::scheduler_ = NULL;

TEST_F(TaskSchedulerTest, TestStop) {
  scheduler_->stop();
}
}
}
