#pragma once

#include <vector>
#include "reco/module/item_classify_server/label_server/label_ops.h"
#include "reco/bizc/proto/item_classify.pb.h"
#include "base/thread/thread_pool.h"

namespace net {
namespace rpc {
class RpcGroup;
}  // namespace rpc
}  // namespace net
namespace reco {
namespace item_classify {
class Dao;
enum TaskStatus {
  kInited = 1,
  kDataFilling = 2,
  kDataFilled = 3,
  kTraining = 4,
  kTrained = 5,
  kPredicting = 6,
  kPredicted = 7,
  kAborded = 8,
  kFailed = 9,
};

// thread safe, single obj is enough for u
class TaskScheduler {
 public:
  TaskScheduler(int thread_num, Dao* dao, reco::HBasePoolGetSim* hbase_pool_get_sim);

  ~TaskScheduler() {
    stop();
  }

  void stop();

  bool AddTask(const LabelRequest& requet);

 private:
  void SearchCandidatesWorker(int thread_id, thread::BlockingQueue<LabelRequest>* train_queue);

  void TrainWorker(int thread_id, thread::BlockingQueue<LabelRequest>* train_queue);

  void PredictWorker(int thread_id, thread::BlockingQueue<LabelRequest>* predict_queue);

 private:
  Dao* dao_;
  reco::HBasePoolGetSim* hbase_pool_get_sim_;
  std::vector<thread::BlockingQueue<LabelRequest>*>* search_request_matrix_;
  std::vector<thread::BlockingQueue<LabelRequest>*>* train_request_matrix_;
  std::vector<thread::BlockingQueue<LabelRequest>*>* predict_request_matrix_;

  thread::ThreadPool* search_data_pool_;
  thread::ThreadPool* train_pool_;
  thread::ThreadPool* predict_pool_;

  net::rpc::RpcGroup* search_rpc_group_;

  bool stop_;
};
}
}
