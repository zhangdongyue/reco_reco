#include "reco/module/item_classify_server/label_server/dao.h"

#include <string>
#include <vector>
#include <fstream>
#include <utility>
#include "reco/base/common/singleton.h"

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/random/pseudo_random.h"
#include "reco/module/item_classify_server/label_server/define.h"
#include "reco/module/item_classify_server/label_server/task_scheduler.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

DEFINE_int32(thread_num, 4, "thread_num");
DEFINE_string(db_host, "tcp://11.251.206.209:3306", "dbhost");
DEFINE_string(db_user, "test", "db user");
DEFINE_string(db_passwd, "chuheridangwu", "db passwd");
DEFINE_string(schema, "test_reco", "shcema");
DEFINE_string(hbase_sim_table, "tb_sim_item", "table name");
namespace reco {
namespace item_classify {

class DaoTest : public testing::Test {
 public:
  static void SetUpTestCase() {
    // dao
    serving_base::mysql_util::DbConnManager* db_manager
            = reco::item_classify::GlobalDataIns::instance().db_manager_;
    dao_ = new Dao(db_manager);
    CHECK_NOTNULL(dao_);
    hbase_pool_getsim_ = new reco::HBasePoolGetSim(FLAGS_hbase_sim_table);
    scheduler_ = new TaskScheduler(FLAGS_thread_num, dao_, hbase_pool_getsim_);
    LOG(INFO) << "finish init db!";
  }

  static Dao* dao_;
  static reco::HBasePoolGetSim* hbase_pool_getsim_;
  static TaskScheduler* scheduler_;
};
Dao* DaoTest::dao_ = NULL;
TaskScheduler* DaoTest::scheduler_ = NULL;
reco::HBasePoolGetSim* DaoTest::hbase_pool_getsim_ = NULL;
TEST_F(DaoTest, TestTask) {
  uint64 task_id = 1;
  int start_status = 1;
  int status = dao_->ReadTaskStatus(task_id);
  if (status == -1) {
    ASSERT_TRUE(dao_->ModifyTask(task_id, start_status, ""));
  } else {
    ASSERT_TRUE(dao_->ModifyTask(task_id, status + 1, ""));
  }
  int status2 = dao_->ReadTaskStatus(task_id);
  ASSERT_EQ(status + 1, status2);
}

TEST_F(DaoTest, TestWriteLabelData) {
  struct {
    uint64 task_id;
    std::string level1;
    std::string level2;
    std::string item_ids;
    std::string titles;
  } cases[] = {
    {1, "财经", "股票", "1,2,3,4,5", "\"t1\",'t2',t3,t4,t5"},
    {2, "财经", "股票", "3,4,5,6,7", "\"t31\",'t41',t51,t6,t7"},
  };

  int num = ARRAYSIZE_UNSAFE(cases);

  std::vector<uint64> item_ids;
  std::vector<std::string> titles;
  std::vector<std::string> flds;
  std::unordered_map<uint64, std::string> item_title;
  std::vector<std::pair<uint64, int> > samples;
  for (int i = 0; i < num; ++i) {
    item_ids.clear();
    titles.clear();
    item_title.clear();

    flds.clear();
    base::SplitString(cases[i].item_ids, ",", &flds);
    for (int j = 0; j < (int)flds.size(); ++j) {
      uint64 item_id = base::ParseUint64OrDie(flds[j]);
      item_ids.push_back(item_id);
    }

    flds.clear();
    base::SplitString(cases[i].titles, ",", &flds);
    for (int j = 0; j < (int)flds.size(); ++j) {
      titles.push_back(flds[j]);
    }

    for (int j = 0; j < (int)flds.size(); ++j) {
      item_title[item_ids.at(j)] = titles.at(j);
    }

    ASSERT_TRUE(dao_->WriteLabelData(cases[i].task_id, cases[i].level1, cases[i].level2, item_ids, titles));

    samples.clear();
    ASSERT_TRUE(dao_->ReadAllLabelData(cases[i].level1, cases[i].level2, &samples));
    ASSERT_GE(samples.size(), item_ids.size());
  }
}

TEST_F(DaoTest, TestWritePredictData) {
  uint64 task_id = 1;
  std::string level1 = "财经";
  std::string level2 = "理财";

  std::vector<uint64> item_ids;
  ASSERT_TRUE(dao_->ReadRecentData(level1, level2, &item_ids));
  ASSERT_GT(item_ids.size(), 5u);

  item_ids.resize(100);

  // generate samples
  base::PseudoRandom pr;
  std::vector<Sample> samples;
  samples.reserve(item_ids.size());
  for (size_t i = 0; i < item_ids.size(); ++i) {
    samples.push_back(Sample());
    samples.back().item_id = item_ids[i];
    samples.back().title = base::StringPrintf("title_%lu", item_ids[i]);
    samples.back().label = pr.GetInt(-1, 1);
  }
  ASSERT_TRUE(dao_->WritePredictData(task_id, level1, level2, samples));
}

TEST_F(DaoTest, TestStop) {
  scheduler_->stop();
}
}
}
