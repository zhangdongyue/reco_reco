#include "reco/base/common/singleton.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_path.h"
#include "net/rpc/rpc.h"
#include "net/counter/export.h"
#include "serving_base/data_manager/server_frame.h"
#include "serving_base/utility/signal.h"

#include "reco/module/item_classify_server/label_server/label_service_impl.h"
#include "reco/module/item_classify_server/label_server/dao.h"
#include "reco/module/item_classify_server/label_server/label_controller.h"
#include "reco/module/item_classify_server/label_server/task_scheduler.h"
#include "reco/module/item_classify_server/label_server/label_ops.h"
#include "reco/module/item_classify_server/global_data/global_data.h"
#include "serving_base/mysql_util/db_conn_manager.h"

DEFINE_int32(port, 20055, "label serverport");
DEFINE_int32(thread_num, 4, "thread_num");

DEFINE_string(db_host_l, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user_l, "admin", "db user");
DEFINE_string(db_passwd_l, "admin", "db passwd");
DEFINE_string(schema_l, "reco", "shcema");


DEFINE_string(hbase_sim_table, "tb_sim_item", "table name");

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "label server");

  reco::item_classify::GlobalDataIns::instance().Init();

  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host_l;
  db_option.user = FLAGS_db_user_l;
  db_option.passwd = FLAGS_db_passwd_l;
  db_option.schema = FLAGS_schema_l;
  serving_base::mysql_util::DbConnManager* db_manager
          = new serving_base::mysql_util::DbConnManager(db_option);
  reco::item_classify::Dao dao(db_manager);

  // hase get sim
  reco::HBasePoolGetSim hbase_pool_getsim(FLAGS_hbase_sim_table);
  // scheduler
  reco::item_classify::TaskScheduler scheduler(FLAGS_thread_num, &dao,  &hbase_pool_getsim);

  // controller
  thread::BlockingQueue<reco::item_classify::LabelController*> workers;
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    workers.Put(new reco::item_classify::LabelController(&dao, &scheduler));
  }

  // service frame
  reco::item_classify::LabelServiceImpl service(&workers);

  serving_base::ServerFrameConfig server_frame_config;
  server_frame_config.rpc_threads_num = FLAGS_thread_num;
  server_frame_config.rpc_server_port = FLAGS_port;
  server_frame_config.service = &service;

  serving_base::ServerFrame server_frame(server_frame_config);

  server_frame.Start();

  LOG(INFO) << "label server start";

  net::counter::HttpCounterExport();

  serving_base::SignalCatcher::Initialize();

  serving_base::SignalCatcher::WaitForSignal();
  scheduler.stop();
  server_frame.Stop();
  LOG(INFO) << "server frame stop";
  return 0;
}
