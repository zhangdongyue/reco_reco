#pragma once

#include "reco/bizc/proto/item_classify.pb.h"
#include "base/thread/blocking_queue.h"
#include "base/common/closure.h"

namespace stumy {
class RpcController;
}

namespace reco {
namespace item_classify {
class LabelController;
class LabelServiceImpl : public LabelService {
 public:
  explicit LabelServiceImpl(thread::BlockingQueue<LabelController*>* workers) : workers_(workers) {}

  ~LabelServiceImpl() {}

  void LabelData(::stumy::RpcController* controller,
                 const LabelRequest* request,
                 LabelResponse* response,
                 Closure* done);

 private:
  thread::BlockingQueue<LabelController*>* workers_;
};
}
}  // namespace reco_leaf
