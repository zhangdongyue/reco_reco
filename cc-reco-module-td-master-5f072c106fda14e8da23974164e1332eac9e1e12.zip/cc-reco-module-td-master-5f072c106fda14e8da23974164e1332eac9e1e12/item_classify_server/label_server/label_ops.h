#pragma once

#include <vector>
#include <unordered_map>
#include <utility>
#include <string>
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "base/file/file_path.h"
#include "base/common/basic_types.h"

#include "reco/bizc/item_service/hbase_pool_get_sim.h"
#include "reco/bizc/item_service/hbase_get_item.h"

namespace reco {
namespace item_classify {
class Dao;

class ItemClassifyFeature;

struct Sample;
struct RawItem;
enum ItemLabelType {
  kPos = 1,
  kNeg = -1,
  kUnknown = 0
};

class ClassificationLabelingOps {
 public:
  void Init();

  explicit ClassificationLabelingOps(Dao* dao, reco::HBasePoolGetSim* hbase_pool_get_sim);

  bool Train(int task_id,
             std::string cate,
             std::vector<std::pair<uint64, int>> item_ids,
             const std::vector<int>& types,
             int pos_item_count,
             int neg_item_count,
             bool expand_sample);

  bool Predict(int task_id,
               std::vector<uint64> item_ids,
               std::string cate,
               const std::vector<int>& types,
               double threshold,
               std::vector<Sample>* result);

 private:
  Dao* dao_;
  static const double pos_label = 1.0;
  static const double neg_label = 0.0;
  static const double unknown_label = -1.0;

  reco::HBaseGetItem* hbase_pool_get_item_;
  reco::HBasePoolGetSim* hbase_pool_get_sim_;
  FeatureExtractor feature_extractor_;

  bool ReadLRModel(const base::FilePath& path, std::unordered_map<uint64, double>* model);

  bool WritePlainModel(const std::string& cate, const std::string& dir,
                       std::unordered_map<uint64, std::string>& dict);
};
}
}
