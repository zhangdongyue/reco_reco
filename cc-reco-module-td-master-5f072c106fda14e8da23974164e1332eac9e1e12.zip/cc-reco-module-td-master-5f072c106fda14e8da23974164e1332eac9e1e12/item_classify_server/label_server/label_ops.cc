#include "reco/module/item_classify_server/label_server/label_ops.h"

#include <vector>
#include <fstream>
#include <cmath>
#include <string>
#include <utility>
#include <algorithm>
#include <functional>
#include "reco/module/item_classify_server/common/item_util.h"
#include "reco/module/item_classify_server/label_server/define.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/hbase_pool_get_sim.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/module/item_classify_server/feature/item_basic_feature.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/label_server/dao.h"
#include "reco/module/item_classify_server/global_data/define.h"

DEFINE_string(hbase_item_table, "tb_reco_item", "table name");
DEFINE_int32(hbase_request_number, 30, "neg_sample_number");
DEFINE_double(labeled_sample_weight, 5.0, "labeled_sample_weight");

DEFINE_string(dict_dir, "./dict", "ngram feature dir");
DEFINE_string(result_dir, "result/", "result dir");
DEFINE_string(model_dir, "model/", "model dir");
DEFINE_string(train_shell, "./train -d $input -m $output -c 1 -e 0.0001 -f 3", " ");

DEFINE_int32(max_predict_number, 5000, "max_loop");
DEFINE_int32(max_predict_sim_expand_number, 30, "max_loop");

namespace reco {
namespace item_classify {
const std::string kSmallCateName = "小众一级分类";
struct Sample;

bool ClassificationLabelingOps::Train(int task_id,
                                      std::string cate,
                                      std::vector<std::pair<uint64, int>> item_ids,
                                      const std::vector<int>& types,
                                      int pos_item_count,
                                      int neg_item_count,
                                      bool expand_sample) {
  // 利用 sim 扩展样本
  std::unordered_map<uint64, std::pair<int, int>> expand_samples;
  ItemUtil::ExpandItemFromOrigin(hbase_pool_get_sim_, item_ids,
                                 pos_item_count, neg_item_count, &expand_samples);
  std::vector<uint64> id_vector;
  for (auto it = expand_samples.begin(); it != expand_samples.end(); ++it) {
    id_vector.push_back(it->first);
  }
  // 从 HBase 拉取基本信息
  std::vector<RawItem> raw_items;
  ItemUtil::GetRawitem(hbase_pool_get_item_, id_vector, &raw_items);
  // 创建文件夹
  std::string dir = FLAGS_result_dir + base::IntToString(task_id) + "/";
  mkdir(dir.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);

  std::unordered_map<uint64, std::string> dict;
  std::vector<uint64> feature_signs;
  std::string buf;
  std::string buf_item;
  std::string buf_dict;
  std::vector<std::string> ngrams;
  ItemClassifyFeature item_classify_feature;
  for (int i = 0; i < (int) raw_items.size(); i++) {
    std::vector<std::string> tokens;
    base::SplitString(cate, ",", &tokens);
    if (tokens[0] != kSmallCateName && raw_items[i].category.find(tokens[0]) == std::string::npos) continue;
    if (std::find(types.begin(), types.end(), raw_items[i].item_type) == types.end()) continue;
    buf_item.append(ItemUtil::RawitemToString(raw_items[i]));
    buf_item.append("\t");
    feature_signs.clear();
    std::string label = "+1";
    std::string weight = "1.0";
    if (expand_samples[raw_items[i].item_id].first == ItemLabelType::kNeg) {
      label = "-1";
    }
    // 原始标记样本
    if (expand_samples[raw_items[i].item_id].second == 1) {
      weight = base::DoubleToString(FLAGS_labeled_sample_weight);
    }

    const RawItem& raw_item = raw_items[i];

    item_classify_feature.clear();
    feature_extractor_.Extract(raw_item, &item_classify_feature);
    ngrams.clear();
    const std::vector<std::string>* ngrams_title =
            item_classify_feature.GetFlagFeature(FeatureType::kTitle);
    if (ngrams_title != NULL) {
      for (size_t k = 0; k < ngrams_title->size(); ++k) {
        ngrams.push_back(ngrams_title->at(k));
      }
    }
    const std::vector<std::string>* ngrams_LabelTitle =
            item_classify_feature.GetFlagFeature(FeatureType::kLabelTitle);
    if (ngrams_LabelTitle != NULL) {
      for (size_t k = 0; k < ngrams_LabelTitle->size(); ++k) {
        ngrams.push_back(ngrams_LabelTitle->at(k));
      }
    }
    const std::vector<std::string>* ngrams_keyword =
            item_classify_feature.GetFlagFeature(FeatureType::kKeyword);
    if (ngrams_keyword != NULL) {
      for (size_t k = 0; k < ngrams_keyword->size(); ++k) {
        ngrams.push_back(ngrams_keyword->at(k));
      }
    }
    if (ngrams.size() <= 1) continue;
    for (int j = 0; j < (int) ngrams.size(); j++) {
      uint64 sign = base::CalcTermSign(ngrams[j].c_str(),
                                       ngrams[j].size());

      feature_signs.push_back(sign);
      if (dict.find(sign) != dict.end())
        continue;
      auto it_pair = dict.insert(std::make_pair(sign, ngrams[j]));

      buf_dict.append(base::Uint64ToString(sign));
      buf_dict.append("\t");
      buf_dict.append(ngrams[j]);
      buf_dict.append("\n");
    }
    std::sort(feature_signs.begin(), feature_signs.end(), std::less<uint64>());
    auto iter = std::unique(feature_signs.begin(), feature_signs.end());
    feature_signs.erase(iter, feature_signs.end());

    buf.append(weight);
    buf.append(" ");
    buf.append(label);
    buf_item.append(weight);
    buf_item.append("\t");
    buf_item.append(label);
    buf_item.append("\n");
    for (int j = 0; j < (int) feature_signs.size(); j++) {
      buf.append(base::StringPrintf(" %lu:1", feature_signs[j]));
    }
    buf.append("\n");
    LOG_EVERY_N(INFO, 100) << i << "/" << raw_items.size();
  }
  std::ofstream fout(dir + "/samples.txt");
  std::ofstream fout_dict(dir + "/dict.txt");
  std::ofstream fout_item(dir + "/items.txt");
  fout << buf;
  fout_dict << buf_dict;
  fout_item << buf_item;
  // 模型训练
  std::string train_commond = FLAGS_train_shell;
  train_commond = base::StringReplace(train_commond, "$input", dir + "/samples.txt", true);
  train_commond = base::StringReplace(train_commond, "$output", dir + "/model.txt", true);
  system(train_commond.c_str());
  // 输出一个明文 model
  return WritePlainModel(cate, dir, dict);
}

bool ClassificationLabelingOps::WritePlainModel(const std::string& cate, const std::string& dir,
                                                std::unordered_map<uint64, std::string>& dict) {
  std::vector<std::string> lines;
  std::vector<std::string> tokens;

  uint64 sign;
  double weight;
  std::string buf_model_plain;
  base::file_util::ReadFileToLines(base::FilePath(dir + "/model.txt"), &lines);
  if (lines.size() == 0u) return false;
  for (int i = 0; i < (int) lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], base::kWhitespace, &tokens);
    base::StringToUint64(tokens[0], &sign);
    base::StringToDouble(tokens[1], &weight);
    auto it = dict.find(sign);
    if (it != dict.end()) {
      buf_model_plain.append(tokens[1]);
      buf_model_plain.append("\t");
      buf_model_plain.append(it->second);
      buf_model_plain.append("\t");
      buf_model_plain.append(cate);
      buf_model_plain.append("\n");
    }
  }
  std::ofstream fout_model_plain(FLAGS_model_dir + cate + ".txt");
  fout_model_plain << buf_model_plain;
  return true;
}

void ClassificationLabelingOps::Init() {
}

bool ClassificationLabelingOps::Predict(int task_id,
                                        std::vector<uint64> item_ids,
                                        std::string cate,
                                        const std::vector<int>& types,
                                        double threshold,
                                        std::vector<Sample>* result) {
  // 读取模型
  std::unordered_map<uint64, double> model;
  std::string model_file = FLAGS_result_dir + base::IntToString(task_id) + "/model.txt";
  ReadLRModel(base::FilePath(model_file), &model);

  // 从 sim 中拉取补充数据
  std::vector<uint64> new_item_ids;
  ItemUtil::GetSimItems(hbase_pool_get_sim_, item_ids, &new_item_ids,
                        FLAGS_max_predict_number,
                        FLAGS_max_predict_sim_expand_number);
  if ((int) new_item_ids.size() > FLAGS_max_predict_number * 5) {
    std::random_shuffle(new_item_ids.begin(), new_item_ids.end());
    new_item_ids.resize(FLAGS_max_predict_number * 5);
  }

  LOG(INFO) << "item_ids.size()=" << item_ids.size();
  // 拉取当前一级分类的数据
  std::vector<std::string> tokens;
  base::SplitString(cate, ",", &tokens);
  item_ids.swap(new_item_ids);

  std::vector<std::pair<uint64, std::string> > cate_item_ids;
  dao_->ReadCateData(tokens[0], tokens[1], types, FLAGS_max_predict_number * 5, true, &cate_item_ids);
  for (size_t k = 0; k < cate_item_ids.size(); ++k) {
    item_ids.push_back(cate_item_ids[k].first);
  }

  LOG(INFO) << "item_ids.size()=" << item_ids.size();
  ItemClassifyFeature item_classify_feature;
  std::vector<RawItem> raw_items;
  ItemUtil::GetRawitem(hbase_pool_get_item_, item_ids, &raw_items);

  std::vector<std::string> ngrams;
  std::unordered_map<uint64, int> old_items;

  for (size_t i = 0; i < raw_items.size(); ++i) {
    const RawItem& raw_item = raw_items[i];

    if (std::find(types.begin(), types.end(), raw_items[i].item_type) == types.end()) continue;
    if (old_items.find(raw_item.item_id) != old_items.end()) {
      continue;
    }
    old_items.insert(std::make_pair(raw_item.item_id, 1));
    if (tokens[0] != kSmallCateName && raw_item.category.find(tokens[0]) == std::string::npos) {
      continue;
    }
    item_classify_feature.clear();
    feature_extractor_.Extract(raw_item, &item_classify_feature);
    ngrams.clear();
    const std::vector<std::string>* ngrams_title =
            item_classify_feature.GetFlagFeature(FeatureType::kTitle);
    if (ngrams_title != NULL) {
      for (size_t k = 0; k < ngrams_title->size(); ++k) {
        ngrams.push_back(ngrams_title->at(k));
      }
    }
    const std::vector<std::string>* ngrams_LabelTitle =
            item_classify_feature.GetFlagFeature(FeatureType::kLabelTitle);
    if (ngrams_LabelTitle != NULL) {
      for (size_t k = 0; k < ngrams_LabelTitle->size(); ++k) {
        ngrams.push_back(ngrams_LabelTitle->at(k));
      }
    }
    const std::vector<std::string>* ngrams_keyword =
            item_classify_feature.GetFlagFeature(FeatureType::kKeyword);
    if (ngrams_keyword != NULL) {
      for (size_t k = 0; k < ngrams_keyword->size(); ++k) {
        ngrams.push_back(ngrams_keyword->at(k));
      }
    }

    double score = 0.0;
    for (int j = 0; j < (int) ngrams.size(); j++) {
      uint64 sign = base::CalcTermSign(ngrams[j].c_str(),
                                       ngrams[j].size());
      auto it = model.find(sign);
      if (it != model.end()) {
        score += model[sign];
      }
    }

    Sample sample;
    sample.item_id = raw_item.item_id;
    sample.title = raw_item.title;
    sample.score = 1 / (1 + std::exp(0 - score));
    if (sample.score > threshold) {
      sample.label = ItemLabelType::kPos;
    } else {
      sample.label = ItemLabelType::kNeg;
    }
    result->push_back(sample);
    LOG_EVERY_N(INFO, 100) <<
                           base::StringPrintf("Predict complete %d/%d",
                                              (int) i + 1, (int) item_ids.size());
  }
  return true;
}

bool ClassificationLabelingOps::ReadLRModel(const base::FilePath& path,
                                            std::unordered_map<uint64, double>* model) {
  model->clear();
  // std::string dir = FLAGS_result_dir + base::IntToString(task_id) + "/";
  // 读 model
  std::vector<std::string> lines;
  std::vector<std::string> tokens;
  uint64 sign;
  double weight;

  if (!base::file_util::ReadFileToLines(path, &lines)) {
    return false;
  }
  for (int i = 0; i < (int) lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], base::kWhitespace, &tokens);
    base::StringToUint64(tokens[0], &sign);
    base::StringToDouble(tokens[1], &weight);
    model->insert(std::make_pair(sign, weight));
  }
  return true;
}

ClassificationLabelingOps::ClassificationLabelingOps(Dao* dao, reco::HBasePoolGetSim* hbase_pool_get_sim) {
  dao_ = dao;
  hbase_pool_get_item_ = new reco::HBaseGetItem(FLAGS_hbase_item_table, 100000);
  hbase_pool_get_sim_ = hbase_pool_get_sim;
}
}
}
