#include <vector>
#include <string>
#include <unordered_set>
#include <iostream>
#include <fstream>
#include "base/common/base.h"
#include "base/common/scoped_ptr.h"
#include "base/common/sleep.h"
#include "base/time/timestamp.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"
#include "net/counter/export.h"

#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/base/kafka_c/api_cc/producer.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/module/item_classify_server/async_classify/knn_generator.h"
#include "reco/module/item_classify_server/async_classify/rule_classifier.h"
#include "reco/base/dict_manager/common_dict_loader.h"

DEFINE_int32(thread_num, 16, "thread num for to vote");
DEFINE_int32(level1_confidence_threshold, 8, "confidence threshold for level1");
DEFINE_double(level1_support_threshold, 0.6, "support threshold for level1");

DEFINE_int32(message_buffer_size, 1024, "buffer size for cached message");

DEFINE_string(item_id_file, "item_id.txt", "input");
DEFINE_string(result_file, "sim.txt", "simresult");
DEFINE_string(all_category_file, "all_category.txt", "simresult");
DEFINE_string(data_dir, "../data", "data dir");

DEFINE_string(suspect_kafka_brokers, "10.181.169.194:9092", "kafka queue servers");
DEFINE_string(suspect_topic, "", "topic name");

DEFINE_string(item_kafka_brokers, "11.251.176.1:9092,11.251.176.2:9092,11.251.176.3:9092", "kafka queue servers");  // NOLINT
DEFINE_string(item_topic, "test_reco_item_new", "iten topic name");
DEFINE_int32(item_partition, 32, "partition num for item topic");

DEFINE_int32(retry_interval_in_second, 1, "failed retry interval");
DEFINE_int32(retry_timeout_in_second, 600, "failed retry timeout");

DEFINE_int32(sim_from, 0, "0 means redis, 1 means hbase");
DEFINE_int32(out_type, 1, "1: to file, 2: to kafka");

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_string(item_keeper_ips, "", "item keeper ips");
DEFINE_int32(item_keeper_port, 0, "");

DEFINE_string(start_time, "", "start time for queue");

DEFINE_int64_counter(async_category, parse_failed_num, 0, "failed parsed reco item num");
DEFINE_int64_counter(async_category, failed_get_sim_item_num, 0, "the num of item failed to get sim item");
DEFINE_int64_counter(async_category, failed_get_reco_item_num, 0, "the num of item failed to get sim item");
DEFINE_int64_counter(async_category, update_category_num, 0, "the num of update category");
DEFINE_int64_counter(async_category, un_voted_num, 0, "the num of update category");
DEFINE_int64_counter(async_category, remain_to_update, 0, "remain to update category");

bool g_stop = false;

inline void join_category(const std::string& level1, const std::string& level2, std::string* category) {
  category->clear();
  if (level1.empty()) return;

  category->append(level1);
  if (!level2.empty()) {
    category->append(",");
    category->append(level2);
  }
}

struct VoteResult {
 public:
  void renew() {
    item_id = 0;
    text = "";
    level1 = "";
    level2 = "";
    level1_confidence = 0;
    level1_support = 0;
    level2_confidence = 0;
    level2_support = 0;
  }

  uint64 item_id;
  std::string text;   // for output
  std::string level1;
  std::string level2;
  int level1_confidence;
  float level1_support;
  int level2_confidence;
  float level2_support;
};

static bool VoteForCategory(const std::vector<reco::item_classify::KnnGenerator::KnnElement>& items,
                            VoteResult* result) {
  if (items.empty()) return false;

  int confidence_threshold = FLAGS_level1_confidence_threshold;
  double support_threshold = FLAGS_level1_support_threshold;
  if (items.back().level1 == "未分类") {
    confidence_threshold /= 3;
    support_threshold *= 0.4;
  }

  if ((int)items.size() < confidence_threshold) return false;

  result->renew();

  std::unordered_map<std::string, float> cate_score;
  for (size_t i = 0; i < items.size(); ++i) {
    result->level1_confidence += 1;
    auto it_pair = cate_score.insert(make_pair(items[i].level1, 0));
    it_pair.first->second += items[i].score;
  }

  if (cate_score.empty() || result->level1_confidence < confidence_threshold) return false;

  float score_sum = 1e-6;
  std::pair<std::string, float> max_level1 = std::make_pair("", 0);
  for (auto it = cate_score.begin(); it != cate_score.end(); ++it) {
    if (it->second > max_level1.second) max_level1 = *it;
    score_sum += it->second;
  }
  result->level1_support = max_level1.second / score_sum;
  result->level1 = max_level1.first;
  if (result->level1_support < support_threshold) return false;
  // level2
  cate_score.clear();
  for (size_t i = 0; i < items.size(); ++i) {
    if (items[i].level1 != result->level1 || items[i].level2.empty()) continue;

    result->level2_confidence += 1;
    auto it_pair = cate_score.insert(make_pair(items[i].level2, 0));
    it_pair.first->second += items[i].score;
  }
  score_sum = 1e-6;
  std::pair<std::string, float> max_level2 = std::make_pair("", 0);
  for (auto it = cate_score.begin(); it != cate_score.end(); ++it) {
    if (it->second > max_level2.second) max_level2 = *it;
    score_sum += it->second;
  }

  if (max_level2.second > 0.2) {
    result->level2_support = max_level2.second / score_sum;
    result->level2 = max_level2.first;
  }
  return true;
}

// only single
void WriteFileWorker(thread::BlockingQueue<VoteResult>* vote_queue) {
  VoteResult vote_result;
  std::ofstream fout(FLAGS_result_file);
  LOG(INFO) << "begin to write to file";
  while (!(vote_queue->Closed() && vote_queue->Empty())) {
    if (!vote_queue->Take(&vote_result)) break;

    fout << base::StringPrintf("%lu\t%s\t%d\t%f\t%d\t%f\n",
                               vote_result.item_id, vote_result.text.c_str(),
                               vote_result.level1_confidence, vote_result.level1_support,
                               vote_result.level2_confidence, vote_result.level2_support);
    COUNTERS_async_category__remain_to_update.Reset(vote_queue->Size());
    std::string category;
    join_category(vote_result.level1, vote_result.level2, &category);
    LOG(INFO) << base::StringPrintf("update tb_item_info set category=\"%s\" where item_id=\"%lu\";",
                                     category.c_str(), vote_result.item_id);
    LOG(INFO) << vote_result.text;
    COUNTERS_async_category__update_category_num.Increase(1);
  }
  LOG(INFO) << "finish write file";
}

void PushWorker(thread::BlockingQueue<VoteResult>* vote_result_queue) {
  reco::kafka::Producer suspect_producer(FLAGS_suspect_kafka_brokers, FLAGS_suspect_topic);

  VoteResult vote_result;
  std::string category;

  reco::itemkeeper::UpdateItemRequest update_request;
  reco::RecoItem reco_item;

  std::vector<std::string> ips;
  base::SplitString(FLAGS_item_keeper_ips, ",", &ips);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 2;
  options.timeout = 5000;
  for (int i = 0; i < (int)ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], FLAGS_item_keeper_port, options.timeout);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup channel(options);
  CHECK(channel.Connect());
  reco::itemkeeper::ItemKeeper::Stub stub(&channel);
  while (!(vote_result_queue->Closed() && vote_result_queue->Empty())) {
    COUNTERS_async_category__remain_to_update.Reset(vote_result_queue->Size());
    int status = vote_result_queue->TryTake(&vote_result);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    if (status == -1) break;

    CHECK_EQ(status, 1) << "fucking status "  << status;
    join_category(vote_result.level1, vote_result.level2, &category);
    if (category.empty()) {
      LOG(ERROR) << "empty category for item: " << vote_result.item_id;
      continue;
    }
    reco_item.Clear();
    reco_item.add_category(vote_result.level1);
    if (!vote_result.level2.empty()) {
      reco_item.add_category(vote_result.level2);
    }

    update_request.Clear();
    update_request.mutable_service_identity()->set_service_name("async_classify");
    update_request.set_item_id(vote_result.item_id);
    if (!reco_item.SerializePartialToString(update_request.mutable_reco_item_bytes())) {
      LOG(ERROR) << "fail to transfer reco item for : " << vote_result.item_id;
      continue;
    }

    net::rpc::RpcClientController rpc;
    rpc.SetTimeout(5000);
    reco::itemkeeper::UpdateItemFieldResponse update_response;
    stub.updateItemFields(&rpc, &update_request, &update_response, NULL);
    rpc.Wait();

    if (rpc.status() == net::rpc::RpcClientController::kDeadlineExceeded) {
      LOG(ERROR) << "update parent timeout for: " << update_request.item_id();
      vote_result_queue->Put(vote_result);
      continue;
    }

    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !update_response.success()) {
      LOG(ERROR) << "update parent failed: " << update_request.item_id();
      vote_result_queue->Put(vote_result);
      base::SleepForSeconds(1);
      continue;
    }

    COUNTERS_async_category__update_category_num.Increase(1);

    std::string value = base::StringPrintf("%lu\t%s", vote_result.item_id, category.c_str());
    if (!suspect_producer.Produce(value, base::Uint64ToString(vote_result.item_id))) {
      LOG(ERROR) << base::StringPrintf("fail to push to kafka: %s, item id: %lu, category=%s",
                                       FLAGS_suspect_kafka_brokers.c_str(), vote_result.item_id,
                                       category.c_str());
    } else {
      LOG(INFO) << base::StringPrintf("succ push to kafka: %s, item id: %lu, category=%s",
                                      FLAGS_suspect_kafka_brokers.c_str(), vote_result.item_id,
                                      category.c_str());
    }
  }
}

void ProcessFailedItem(thread::BlockingQueue<std::pair<uint64, uint64> >* item_id_queue,
                       thread::BlockingQueue<std::pair<uint64, uint64>>* failed_item_queue) {
  std::pair<uint64, uint64> ele;
  while (!(failed_item_queue->Closed() && failed_item_queue->Empty())) {
    COUNTERS_async_category__failed_get_sim_item_num.Reset(failed_item_queue->Size());
    if (!failed_item_queue->Take(&ele)) break;
    uint64 timestamp = base::GetTimestamp();
    int interval = (timestamp - ele.second) / 1000000;
    if (interval > FLAGS_retry_timeout_in_second) {
      LOG(INFO) << "drop item: " << ele.first;
      continue;
    }

    if (interval  < FLAGS_retry_interval_in_second) {
      LOG(INFO) << "sleep 1 second for deal with item: " << ele.first;
      failed_item_queue->Put(ele);
      base::SleepForSeconds(10);
      continue;
    }

    if (item_id_queue->Size() > FLAGS_message_buffer_size) {
      VLOG(1) << "num of message in item id queeu equal to buffer size";
      base::SleepForMilliseconds(1000);
      failed_item_queue->Put(ele);
      continue;
    }

    item_id_queue->Put(ele);
  }
  LOG(INFO) << "end failed process thread";
}

inline void JoinId(const std::vector<reco::item_classify::KnnGenerator::KnnElement>& candidates,
                   std::string* buf) {
  buf->clear();
  for (size_t i = 0; i < candidates.size(); ++i) {
    buf->append(base::StringPrintf("%lu:%s_%s,", candidates[i].item_id, candidates[i].level1.c_str(),
                                   candidates[i].level2.c_str()));
  }
}

void VoteWorker(thread::BlockingQueue<std::pair<uint64, uint64> >* item_id_queue,
                thread::BlockingQueue<VoteResult>* result_queue,
                thread::BlockingQueue<std::pair<uint64, uint64> >* sim_failed_queue,
                thread::BlockingVar<int>* finish_num,
                std::unordered_map<std::string, int>* category_dict) {
  VoteResult vote_result;

  std::string orig_category;

  std::string category;

  std::pair<uint64, uint64> ele;

  std::string buf;
  std::vector<reco::item_classify::KnnGenerator::KnnElement> candidates;
  reco::item_classify::KnnGenerator candidates_generator;
  while (!(item_id_queue->Closed() && item_id_queue->Empty())) {
    if (!item_id_queue->Take(&ele)) break;
    uint64 item_id = ele.first;

    if (!candidates_generator.GenerateCandidates(item_id, &candidates)) {
      sim_failed_queue->Put(ele);
      continue;
    }

    if (!VoteForCategory(candidates, &vote_result)) {
      LOG(INFO)  << "vote failed " << item_id;
      continue;
    }

    JoinId(candidates, &buf);
    // judge if changed
    if (candidates.empty()) {
      orig_category = "";
    } else {
      join_category(candidates.back().level1, candidates.back().level2, &orig_category);
    }

    join_category(vote_result.level1, vote_result.level2, &category);

    vote_result.text = base::StringPrintf("%lu\t%lu\t%s\t%s, sim=%s",
                                          item_id, candidates.size(), orig_category.c_str(), category.c_str(),
                                          buf.c_str());

    if (vote_result.level1 == "未分类" || vote_result.level1.empty()) {
      LOG(INFO) << "skip empty " << vote_result.level1 << " for " << item_id << " sim:" << buf;
      continue;
    }

    if (!category_dict->empty() && category_dict->find(category) == category_dict->end()) {
      LOG(ERROR) << "erro category: " << category << " " << item_id;
      continue;
    }

    if (orig_category == category) continue;

    vote_result.item_id = item_id;
    result_queue->Put(vote_result);
  }

  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    result_queue->Close();
    sim_failed_queue->Close();
  }
  LOG(INFO) << "finish voting remain vote worker : " << FLAGS_thread_num - n;
  CHECK(finish_num->TryPut(n));
}

void GetItemWorker(thread::BlockingQueue<std::pair<uint64, uint64> >* item_id_queue,
                   thread::BlockingQueue<VoteResult>* vote_result_queue) {
  LOG(INFO) << "begin read kafka thread";
  // read from kafka
  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_item_topic;
  options.partition_num = FLAGS_item_partition;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = "0";
  uint64 timestamp = 0;
  if (!serving_base::TimeHelper::StringToTimestamp(FLAGS_start_time, serving_base::TimeHelper::kSecond,
                                                   &timestamp)) {
    CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond,
                                                        &timestamp));
  }
  options.start_timestamp = timestamp / 1000000;

  reco::kafka::Message msg;
  reco::kafka::Consumer consumer(FLAGS_item_kafka_brokers, options);
  reco::RecoItem reco_item;

  reco::item_classify::RuleClassifier rule_classifier_;
  std::string rule_result;

  while (!g_stop) {
    COUNTERS_async_category__un_voted_num.Reset(item_id_queue->Size());
    if (item_id_queue->Size() > FLAGS_message_buffer_size) {
      VLOG(1) << "num of message in sim_query_queueu equal to buffer size";
      base::SleepForMilliseconds(1000);
      continue;
    }
    if (!consumer.Consume(&msg, 100)) {
      LOG_EVERY_N(INFO, 1000) << "get message from kafka failed!";
      base::SleepForMilliseconds(500);
      continue;
    }

    if (!reco_item.ParseFromString(msg.content)) {
      LOG(ERROR) << "failed to parse RecoItem from message, " << msg.content;
      continue;
    }

    // fitler out item that we don't care about
    bool is_listen = (reco_item.updated_fields_size() == 0);
    if (!is_listen) {
      LOG(INFO) << "skip unlistening changing " << reco_item.identity().item_id();
      continue;
    }

    if (reco_item.has_raw_item() && !reco_item.raw_item().is_valid()) {
      LOG(INFO) << "invalid item: " << reco_item.identity().item_id();
      continue;
    }

    if (reco_item.identity().type() == reco::kPureVideo) {
      LOG(INFO) << "drop pure video " << reco_item.identity().item_id();
      continue;
    }

    if (rule_classifier_.Classify(reco_item, &rule_result)) {
      LOG(INFO) << "chagne directly: " << reco_item.identity().item_id() << " " << rule_result;
      VoteResult result;
      result.item_id = reco_item.identity().item_id();
      result.text = base::StringPrintf("change by rule: %lu, category:%s", result.item_id,
                                       rule_result.c_str());
      size_t pos = rule_result.find(",");
      if (pos == std::string::npos) {
        result.level1 = rule_result;
      } else {
        result.level1 = rule_result.substr(0, pos);
        result.level2 = rule_result.substr(pos + 1);
      }
      vote_result_queue->Put(result);
      continue;
    }

    LOG(INFO) << "fetch item: " << reco_item.identity().item_id();
    item_id_queue->Put(std::make_pair(reco_item.identity().item_id(), base::GetTimestamp()));
  }
  LOG(INFO) << "end get item from mq! remain: " << item_id_queue->Size();
  item_id_queue->Close();
}

static void LoadAllCategoryDict(std::unordered_map<std::string, int>* category_dict) {
  std::ifstream fin(FLAGS_all_category_file);
  std::string line;
  std::vector<std::string> tokens;
  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 2u) continue;
    auto it_pair = category_dict->insert(std::make_pair(tokens[0], base::ParseIntOrDie(tokens[1])));
    CHECK(it_pair.second) << line;
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "find sim");
  std::string line;
  thread::BlockingQueue<std::pair<uint64, uint64> > item_id_queue;
  thread::BlockingQueue<std::pair<uint64, uint64> > failed_item_id_queue;
  thread::BlockingQueue<VoteResult> vote_result_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));

  // load category dict
  std::unordered_map<std::string, int> category_dict;
  LoadAllCategoryDict(&category_dict);
  CHECK_GT(category_dict.size(), 1u);
  thread::ThreadPool pool(FLAGS_thread_num + 3);

  if (!FLAGS_item_id_file.empty()) {
    std::ifstream fin(FLAGS_item_id_file);
    while (std::getline(fin, line)) {
      if (line.size() < 2) continue;
      uint64 item_id = base::ParseUint64OrDie(line);
      item_id_queue.Put(std::make_pair(item_id, base::GetTimestamp()));
    }
    item_id_queue.Close();
  } else {
    pool.AddTask(::NewCallback(GetItemWorker, &item_id_queue, &vote_result_queue));
  }

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(VoteWorker, &item_id_queue, &vote_result_queue, &failed_item_id_queue,
                               &finish_num, &category_dict));
  }

  if (FLAGS_out_type == 1) {
    pool.AddTask(::NewCallback(WriteFileWorker, &vote_result_queue));
  } else if (FLAGS_out_type == 2) {
    pool.AddTask(::NewCallback(PushWorker, &vote_result_queue));
  }
  pool.AddTask(::NewCallback(ProcessFailedItem, &item_id_queue, &failed_item_id_queue));

  net::counter::HttpCounterExport();

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();
  g_stop = true;

  pool.JoinAll();
}
