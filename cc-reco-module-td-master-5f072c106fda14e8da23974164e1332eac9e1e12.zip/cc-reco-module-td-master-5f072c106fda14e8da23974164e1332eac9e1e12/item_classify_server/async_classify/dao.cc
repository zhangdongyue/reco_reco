#include "reco/module/item_classify_server/async_classify/dao.h"
#include <unordered_map>
#include <vector>
#include <string>

#include "base/common/base.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/common/scoped_ptr.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

namespace reco {
namespace item_classify {
Dao::Dao(serving_base::mysql_util::DbConnManager::Option db_option) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);
}

Dao::~Dao() {
  delete db_connection_;
  delete db_manager_;
}

bool Dao::LoadCategoryDict(std::unordered_map<std::string, int>* category_dict) {
  CHECK_NOTNULL(category_dict);
  sql::Connection* db_connection = db_manager_->conn();
  // load all category
  std::string sql = "select word,can_auto from tb_seed_category_word;";
  std::vector<std::string> tokens;
  int can_auto = 0;
  for (int i = 0; i < 3; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

      while (res->next()) {
        std::string category = res->getString("word");
        std::string can_auto_str = res->getString("can_auto");
        if (category.empty()) {
          LOG(ERROR) << "empty category: ";
          continue;
        }
        if (!base::StringToInt(can_auto_str, &can_auto)) {
          LOG(ERROR) << "erro canauto: " << can_auto_str;
          continue;
        }
        size_t pos = category.find('\t');
        if (pos != std::string::npos) {
          category[pos] = ',';
        }

        auto it_pair = category_dict->insert(std::make_pair(category, can_auto));
      }
      break;
    } catch (sql::SQLException& e) {  // NOLINT
      LOG(ERROR) << "Exception: " << e.what();
      LOG(ERROR) << "sql: " << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection = db_manager_->conn();
      CHECK_NOTNULL(db_connection);
      LOG(ERROR) << "Reconnectd to MySQL.";
    }
  }
  LOG(INFO) << "load category dict succ " << category_dict->size();
  return true;
}

bool Dao::GetSeedid(std::string source_name, uint64* seed_id) {
  std::string sql = base::StringPrintf("select id from tb_seed where name=\"%s\"",
                                       source_name.c_str());


  scoped_ptr<sql::ResultSet> res(db_manager_->ExecuteQueryWithRetry(sql, 3));
  if (res == NULL) {
    LOG(ERROR) << "null resultset for sql: " << sql;
    return false;
  }

  while (res->next()) {
    *seed_id = res->getUInt64("id");
    return true;
  }
  return false;
}
}
}
