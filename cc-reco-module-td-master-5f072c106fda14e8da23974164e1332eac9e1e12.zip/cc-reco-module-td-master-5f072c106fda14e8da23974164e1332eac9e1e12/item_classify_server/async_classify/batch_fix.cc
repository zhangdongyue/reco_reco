#include <vector>
#include <string>
#include <unordered_set>
#include <iostream>
#include <fstream>
#include "base/common/base.h"
#include "base/common/scoped_ptr.h"
#include "base/common/sleep.h"
#include "base/time/timestamp.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"

#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/hbase_get_item_attr.h"
#include "reco/bizc/item_service/define.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_keeper.pb.h"

DEFINE_int32(thread_num, 16, "thread num for to vote");

DEFINE_string(result_file, "result.txt", "if set, write file");

DEFINE_string(item_keeper_ips, "", "item keeper ips");
DEFINE_int32(item_keeper_port, 0, "");

DEFINE_int32(run_type, 0, "0 means filter itemid; 1 means modify for cateory 2 means filter by manual");
DEFINE_string(restrict_category, "社会,汽车动态", "wrong category");

// only single
void WriteFileWorker(thread::BlockingQueue<std::pair<uint64, std::string> >* result_queue) {
  std::pair<uint64, std::string> result;
  std::ofstream fout(FLAGS_result_file);
  LOG(INFO) << "begin to write to file";
  while (!(result_queue->Closed() && result_queue->Empty())) {
    if (!result_queue->Take(&result)) break;
    fout << result.first << "\t" << result.second << std::endl;
  }
  LOG(INFO) << "finish write file";
}

void PushWorker(thread::BlockingQueue<std::pair<uint64, std::string> >* result_queue) {
  reco::itemkeeper::UpdateItemRequest update_request;
  reco::RecoItem reco_item;

  std::vector<std::string> ips;
  base::SplitString(FLAGS_item_keeper_ips, ",", &ips);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 2;
  options.timeout = 5000;
  for (int i = 0; i < (int)ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], FLAGS_item_keeper_port, options.timeout);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup channel(options);
  CHECK(channel.Connect());
  reco::itemkeeper::ItemKeeper::Stub stub(&channel);

  std::pair<uint64, std::string> result;
  std::vector<std::string> cates;
  while (!(result_queue->Closed() && result_queue->Empty())) {
    int status = result_queue->TryTake(&result);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    if (status == -1) break;
    reco_item.Clear();
    cates.clear();
    base::SplitString(result.second, ",", &cates);
    reco_item.add_category(cates[0]);
    if (cates.size() > 1) {
      reco_item.add_category(cates[1]);
    }

    update_request.Clear();
    update_request.set_is_manual(true);
    update_request.mutable_service_identity()->set_service_name("async_classify");
    update_request.set_item_id(result.first);
    if (!reco_item.SerializePartialToString(update_request.mutable_reco_item_bytes())) {
      LOG(ERROR) << "fail to transfer reco item for : " << result.first;
      continue;
    }

    net::rpc::RpcClientController rpc;
    rpc.SetTimeout(5000);
    reco::itemkeeper::UpdateItemFieldResponse update_response;
    stub.updateItemFields(&rpc, &update_request, &update_response, NULL);
    rpc.Wait();

    if (rpc.status() == net::rpc::RpcClientController::kDeadlineExceeded) {
      LOG(ERROR) << "update parent timeout for: " << update_request.item_id();
      continue;
    }

    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !update_response.success()) {
      LOG(ERROR) << "update parent failed: " << update_request.item_id();
      continue;
    }
    LOG(INFO) << "finish update: " << update_request.item_id() << " " << result.second;
    CHECK_EQ(status, 1) << "fucking status "  << status;
  }
}

void FilterOut(thread::BlockingQueue<uint64>* input_queue,
               thread::BlockingQueue<std::pair<uint64, std::string> >* modify_queue,
               thread::BlockingVar<int>* finish_num) {
  // read item id from file, check with hbase
  reco::HBaseGetItem get_item("tb_reco_item", 0);
  uint64 item_id;
  reco::RecoItem reco_item;
  std::string category;
  while (!(input_queue->Closed() && input_queue->Empty())) {
    if (!input_queue->Take(&item_id)) break;

    if (get_item.GetRecoItem(item_id, &reco_item)) {
      category = reco_item.category(0);
      if (reco_item.category_size() > 1) {
        category += ",";
        category += reco_item.category(1);
      }

      if (category != FLAGS_restrict_category) continue;
      modify_queue->Put(std::make_pair(item_id, category));
    }
  }

  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    modify_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "check and modify category");
  std::string line;
  thread::BlockingQueue<uint64> item_id_queue;
  thread::BlockingQueue<std::pair<uint64, std::string>> category_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  // reco::hbase::HBasePoolIns::instance().Init();
  thread::ThreadPool pool(FLAGS_thread_num + 1);

  if (FLAGS_run_type == 0) {
    while (std::getline(std::cin, line)) {
      if (line.size() < 2) continue;
      uint64 item_id = base::ParseUint64OrDie(line);
      item_id_queue.Put(item_id);
    }
    item_id_queue.Close();

    for (int i = 0; i < FLAGS_thread_num; ++i) {
      pool.AddTask(::NewCallback(FilterOut, &item_id_queue, &category_queue, &finish_num));
    }
    pool.AddTask(::NewCallback(WriteFileWorker, &category_queue));
  } else {
    std::vector<std::string> tokens;
    while (std::getline(std::cin, line)) {
      if (line.size() < 2) continue;
      tokens.clear();
      base::SplitString(line, "\t", &tokens);
      if (tokens.size() != 2 || tokens[1].size() < 2) continue;

      uint64 item_id = base::ParseUint64OrDie(tokens[0]);
      category_queue.Put(std::make_pair(item_id, tokens[1]));
    }
    category_queue.Close();

    for (int i = 0; i < FLAGS_thread_num; ++i) {
      pool.AddTask(::NewCallback(PushWorker, &category_queue));
    }
  }
  pool.JoinAll();
}
