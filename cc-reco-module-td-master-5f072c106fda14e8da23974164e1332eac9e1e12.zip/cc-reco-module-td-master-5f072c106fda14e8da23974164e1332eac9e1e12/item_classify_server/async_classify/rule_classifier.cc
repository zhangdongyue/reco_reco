#include "reco/module/item_classify_server/async_classify/rule_classifier.h"

#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace item_classify {
RuleClassifier::RuleClassifier() {
  media_dict_.insert(std::make_pair("每天观星座", "星座"));
  media_dict_.insert(std::make_pair("星座控网", "星座"));
  media_dict_.insert(std::make_pair("紫微星座", "星座"));
}

RuleClassifier::~RuleClassifier() {
}

inline void JoinCategory(const reco::RecoItem& reco_item, std::string* category) {
  *category = reco_item.category(0);
  if (reco_item.category_size() > 1) {
    category->append(",");
    category->append(reco_item.category(1));
  }
}

bool RuleClassifier::Classify(const reco::RecoItem& reco_item, std::string* category) {
  std::string orig_category;
  JoinCategory(reco_item, &orig_category);
  if (reco_item.has_orig_source_media()) {
    auto it = media_dict_.find(reco_item.orig_source_media());
    if (it == media_dict_.end()) return false;
    if (orig_category == it->second) return false;
    *category = it->second;
    return true;
  }

  if (reco_item.has_source_media()) {
    auto it = media_dict_.find(reco_item.source_media());
    if (it == media_dict_.end()) return false;
    if (orig_category == it->second) return false;
    *category = it->second;
    return true;
  }

  return false;
}
}
}
