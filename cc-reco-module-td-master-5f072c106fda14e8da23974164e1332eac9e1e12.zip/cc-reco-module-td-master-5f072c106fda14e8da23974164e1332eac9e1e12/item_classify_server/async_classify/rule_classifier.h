#pragma once
#include <unordered_map>
#include <string>

namespace reco {
class RecoItem;
namespace item_classify {
class RuleClassifier {
 public:
  explicit RuleClassifier();
  ~RuleClassifier();
 public:
  bool Classify(const reco::RecoItem& reco_item, std::string* category);
 private:
  std::unordered_map<std::string, std::string> media_dict_;
};
}
}
