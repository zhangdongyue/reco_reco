#pragma once
#include <vector>
#include <string>
#include <unordered_map>
#include "base/common/basic_types.h"
#include "serving_base/mysql_util/db_conn_manager.h"

namespace reco {
namespace item_classify {
// thread unsafe
class Dao {
 public:
  explicit Dao(serving_base::mysql_util::DbConnManager::Option db_option);
  ~Dao();

  bool LoadCategoryDict(std::unordered_map<std::string, int>* special_item_dict);
  bool GetSeedid(std::string source_name, uint64* seed_id);
 private:
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  static const int kRetryTimes = 3;
};
}
}
