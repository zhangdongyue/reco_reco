#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/container/lru_cache.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "net/counter/export.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");
DEFINE_string(start_time, "2016-09-18", "start time for reload cache");

DEFINE_string(kafka_brokers, "11.251.176.1:9092,11.251.176.2:9092,11.251.176.3:9092,11.251.176.5:9092,11.251.176.8:9092,11.251.176.9:9092,11.251.176.21:9092,11.251.176.49:9092,11.251.176.51:9092,11.251.176.54:9092", "kafka brokers");  // NOLINT
DEFINE_string(suspect_category_topic, "suspect_topic", "kafka topic for suspect category");
DEFINE_int32(suspect_category_partition_num, 2, "kafka partition num for suspect category");
DEFINE_bool(is_mirror, false, "");
DEFINE_string(group_id, "", "");
DEFINE_int32(thread_num, 32, "thread num");
DEFINE_int32(cache_size, 100000, "cache size for reviewed element");
DEFINE_int32(input_type, 0, "0 from stdin, 1 from kafka");

DEFINE_int64_counter(suspect_category, get_item_num, 0, "the num of item that get failed from hbase");
DEFINE_int64_counter(suspect_category, get_reco_item_failed_num, 0, "num than get from upstream kafka");
DEFINE_int64_counter(suspect_category, failed_to_db, 0, "the num of item that failed to put in db");
DEFINE_int64_counter(suspect_category, succ_to_db, 0, "the num of update request sending to itemserver");
DEFINE_int64_counter(suspect_category, remain_num, 0, "the num of item in the queue");

struct CateElement {
  std::string create_time;
  uint64 item_id;
  int item_type;
  std::string category;
  std::string source;
  std::string org_source;
  std::string title;
};

class Dao {
 public:
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option, int cache_size,
            const std::string& start_time);

  bool AddRecord(const CateElement& element);

  Dao();
  ~Dao() {}

  bool GetReviewedItem();
 protected:
  static const int kRetryTimes = 3;
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  base::LRUCache<uint64, int>* reviewed_item_cache_;
  std::string sql_str_;
};

Dao::Dao() {
  sql_str_ = "insert into tb_category_modify (create_time,item_id,item_type,org_category,org_source,source,";
  sql_str_ += "title) values";
}

void Dao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option,
               int cache_size,
               const std::string& start_time) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);

  reviewed_item_cache_ = new base::LRUCache<uint64, int>(cache_size, false);
  GetReviewedItem();
}

bool Dao::GetReviewedItem() {
  // get item_id record to cache
  const std::string& sql = base::StringPrintf("select item_id,op_status from tb_category_modify where create_time>\"%s\" && op_status>0",  // NOLINT
                                              FLAGS_start_time.c_str());
  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

      while (res->next()) {
        std::string item_id_str = res->getString("item_id");
        uint64 item_id = 0;
        if (!base::StringToUint64(item_id_str, &item_id)) {
          LOG(ERROR) << "error item_id: " << item_id_str;
          continue;
        }
        // NOTE(xielang): ask spider, status or reviewed_type to judge ?
        std::string status_str = res->getString("op_status");
        int status = 0;
        if (!base::StringToInt(status_str, &status)) {
          LOG(ERROR) << "error count : " << status_str;
        }

        if (status == 1 || status == 2) {
          reviewed_item_cache_->Add(item_id, status);
        }
      }
      break;
    } catch(sql::SQLException& e) {  // NOLINT
      LOG(ERROR) << "Exception: " << e.what();
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
    }
  }
  return true;
}


bool Dao::AddRecord(const CateElement& ele) {
  const std::string sql = base::StringPrintf("%s (\"%s\",\"%lu\",\"%d\",\"%s\",\"%s\",\"%s\",\"%s\");",
                                              sql_str_.c_str(),
                                              ele.create_time.c_str(),
                                              ele.item_id,
                                              ele.item_type,
                                              ele.category.c_str(),
                                              ele.org_source.c_str(),
                                              ele.source.c_str(),
                                              ele.title.c_str());
  int status = 0;
  if (reviewed_item_cache_->Get(ele.item_id, &status)) {
    LOG(INFO) << base::StringPrintf("item: %lu has been reviewed, status: %d", ele.item_id, status);
    return true;
  }

  for (int j = 0; j < kRetryTimes; ++j) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      stmt->executeUpdate(sql);
      LOG(INFO) << "exx: "<< sql;
      return true;
    } catch (sql::SQLException& e) {  // NOLINT
      LOG(ERROR) << "Exception: " << e.what() << "\n" << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
    }
  }
  return false;
}

void PushToDb(thread::BlockingQueue<CateElement>* db_queue) {
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  Dao* db_agent = new Dao();
  db_agent->Init(db_option, FLAGS_cache_size, FLAGS_start_time);

  CateElement ele;
  while (!(db_queue->Empty() && db_queue->Closed())) {
    int status = db_queue->TimedTake(100, &ele);
    COUNTERS_suspect_category__remain_num.Reset(db_queue->Size());

    if (status == -1) {
      LOG(ERROR) << "get cate element failed! status: " << status;
      break;
    }

    if (status == 0) {
      LOG_EVERY_N(ERROR, 1000) << "db queue empty";
      base::SleepForMilliseconds(2000);
      continue;
    }

    bool succ = db_agent->AddRecord(ele);
    if (!succ) {
      db_queue->Put(ele);
      COUNTERS_suspect_category__failed_to_db.Increase(1);
    } else {
      COUNTERS_suspect_category__succ_to_db.Increase(1);
    }
  }
}

void GetItemIdWorker(thread::BlockingQueue<std::string>* msg_queue, bool* is_stop) {
  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_suspect_category_topic;
  options.partition_num = FLAGS_suspect_category_partition_num;
  if (FLAGS_is_mirror) {
    options.type = reco::kafka::kConsumerMirror;
  } else {
    options.type = reco::kafka::kConsumerExclusive;
  }
  options.group_id = FLAGS_group_id;
  uint64 timestamp = 0;
  if (!serving_base::TimeHelper::StringToTimestamp(FLAGS_start_time, serving_base::TimeHelper::kSecond,
                                                   &timestamp)) {
    CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond,
                                                        &timestamp));
  }
  options.start_timestamp = timestamp;
  reco::kafka::Message msg;
  reco::kafka::Consumer consumer(FLAGS_kafka_brokers, options);

  std::string str_id;
  while (!(*is_stop)) {
    if (consumer.Consume(&msg, 100)) {
      msg_queue->Put(msg.content);
      COUNTERS_suspect_category__get_item_num.Increase(1);
    } else {
      LOG(INFO) << "consumer error.";
      base::SleepForSeconds(1);
    }
  }
  msg_queue->Close();
  LOG(ERROR) << "finished reading kafka!";
}

void GenerateCateElement(thread::BlockingQueue<std::string>* msg_queue,
                         thread::BlockingQueue<CateElement>* db_queue,
                         thread::BlockingVar<int>* finish_num) {
  reco::HBaseGetItem get_item("tb_reco_item", 0);
  CateElement ele;
  reco::RecoItem reco_item;
  std::vector<std::string> flds;
  std::string msg;
  while (!msg_queue->Closed() || !msg_queue->Empty()) {
    if (!msg_queue->Take(&msg)) break;
    flds.clear();
    base::SplitString(msg, "\t", &flds);
    if (!base::StringToUint64(flds[0], &ele.item_id)) {
      LOG(ERROR) << "err id: " << flds[0];
      continue;
    }
    // get fld from hbase
    if (!get_item.GetRecoItem(ele.item_id, &reco_item)) {
      LOG(ERROR) << "get item: " << ele.item_id << " failed!";
      COUNTERS_suspect_category__get_reco_item_failed_num.Increase(1);
      continue;
    }
    ele.create_time = reco_item.create_time();
    if (flds.size() > 1) {
      ele.category = flds[1];
    } else {
      ele.category = reco_item.category(0);
      if (reco_item.category_size() > 1) {
        ele.category += ",";
        ele.category += reco_item.category(1);
      }
    }
    ele.org_source = reco_item.raw_item().orig_source();
    ele.source = reco_item.source();
    ele.title = reco_item.title();
    db_queue->Put(ele);
  }
  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    db_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

void GenerateElement(thread::BlockingQueue<CateElement>* db_queue, bool* is_stop) {
  std::string line;
  std::vector<std::string> flds;
  CateElement ele;
  while (!*is_stop && std::getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 7) {
      LOG(ERROR) << "err: " << flds.size() << " " << line;
      continue;
    }

    ele.create_time = flds[0];
    if (!base::StringToUint64(flds[1], &ele.item_id)) {
      LOG(ERROR) << "err item id: " << flds[1] << " in " << line;
    }

    if (!base::StringToInt(flds[2], &ele.item_type)) {
      LOG(ERROR) << "err item type: " << flds[2] << " in " << line;
    }

    ele.category = flds[3];
    ele.org_source = flds[4];
    ele.source = flds[5];
    ele.title = flds[6];
    db_queue->Put(ele);
  }
  LOG(INFO) << "finish reading!";
  db_queue->Close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "init app");
  thread::BlockingQueue<std::string> msg_queue;
  thread::BlockingQueue<CateElement> db_queue;
  thread::ThreadPool* pool = NULL;
  bool is_stop = false;
  thread::BlockingVar<int> finish_num;
  if (FLAGS_input_type == 0) {
    pool = new thread::ThreadPool(2);
    pool->AddTask(::NewCallback(GenerateElement, &db_queue, &is_stop));
  } else {
    pool = new thread::ThreadPool(FLAGS_thread_num + 2);
    pool->AddTask(::NewCallback(GetItemIdWorker, &msg_queue, &is_stop));
    CHECK(finish_num.TryPut(0));
    for (int i = 0; i < FLAGS_thread_num; ++i) {
      pool->AddTask(::NewCallback(GenerateCateElement, &msg_queue, &db_queue, &finish_num));
    }
  }
  pool->AddTask(::NewCallback(PushToDb, &db_queue));

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();
  is_stop = true;
  pool->JoinAll();
}
