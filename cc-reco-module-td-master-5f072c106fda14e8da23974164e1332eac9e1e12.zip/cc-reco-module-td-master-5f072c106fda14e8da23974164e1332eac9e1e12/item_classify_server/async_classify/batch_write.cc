#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "net/counter/export.h"
#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

struct CateElement {
  std::string create_time;
  uint64 item_id;
  int item_type;
  std::string category;
  std::string source;
  std::string org_source;
  std::string title;
};

class Dao {
 public:
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option, int cache_size,
            const std::string& start_time);

  bool AddRecord(const std::vector<CateElement>& element);

  Dao();
  ~Dao() {}

 protected:
  serving_base::mysql_util::DbConnManager* db_manager_;
  std::string base_sql_;
};

Dao::Dao() {
  base_sql_ = "insert into tb_category_modify (create_time,item_id,item_type,org_category,org_source,source,title) values ";  // NOLINT
}

void Dao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option,
               int cache_size,
               const std::string& start_time) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();
}

bool Dao::AddRecord(const std::vector<CateElement>& eles) {
  std::string sql = base_sql_;
  for (size_t i = 0; i < eles.size(); ++i) {
    sql += base::StringPrintf("(\"%s\",\"%lu\",\"%d\",\"%s\",\"%s\",\"%s\",\"%s\")",
                              ele.create_time.c_str(),
                              ele.item_id,
                              ele.item_type,
                              ele.category.c_str(),
                              ele.org_source.c_str(),
                              ele.source.c_str(),
                              ele.title.c_str());
    if (i < eles.size() - 1) sql += ",";
  }

  int32 sql_status = db_manager_->ExecuteUpdateWithRetry(sql, 3);
  if (sql_status < 0) {
    LOG(ERROR) << "sql: " << sql;
    return false;
  }
  return true;
}

void PushToDb(thread::BlockingQueue<CateElement>* db_queue) {
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  Dao* db_agent = new Dao();
  db_agent->Init(db_option, FLAGS_cache_size, FLAGS_start_time);

  std::vector<CateElement> eles;
  while (!(db_queue->Empty() && db_queue->Closed())) {
    if (!db_queue->Take(&ele)) break;
    bool succ = db_agent->AddRecord(eles);
  }
}

void GenerateElement(thread::BlockingQueue<CateElement>* db_queue, bool* is_stop) {
  std::string line;
  std::vector<std::string> flds;
  CateElement ele;
  while (!*is_stop && std::getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 7) {
      LOG(ERROR) << "err: " << flds.size() << " " << line;
      continue;
    }

    ele.create_time = flds[0];
    if (!base::StringToUint64(flds[1], &ele.item_id)) {
      LOG(ERROR) << "err item id: " << flds[1] << " in " << line;
    }

    if (!base::StringToInt(flds[2], &ele.item_type)) {
      LOG(ERROR) << "err item type: " << flds[2] << " in " << line;
    }

    ele.category = flds[3];
    ele.org_source = flds[4];
    ele.source = flds[5];
    ele.title = flds[6];
    db_queue->Put(ele);
  }
  LOG(INFO) << "finish reading!";
  db_queue->Close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "init app");
  thread::BlockingQueue<std::string> input_queue;
  thread::BlockingQueue<CateElement> db_queue;
  thread::ThreadPool* pool = new thread::ThreadPool(2);
  pool->AddTask(::NewCallback(GenerateElement, &db_queue, &is_stop));
  pool->AddTask(::NewCallback(PushToDb, &db_queue));

  pool->JoinAll();
}
