#include "reco/module/item_classify_server/async_classify/knn_generator.h"
#include <vector>
#include <string>

#include "reco/bizc/item_service/hbase_pool_get_sim.h"
#include "reco/bizc/item_service/define.h"
#include "reco/bizc/item_service/hbase_get_item.h"

namespace reco {
namespace item_classify {
static serving_base::ExpiryMap<uint64, KnnGenerator::KnnElement>* InitGlobalCache() {
  static serving_base::ExpiryMap<uint64, KnnGenerator::KnnElement>* cache = new serving_base::ExpiryMap<uint64, KnnGenerator::KnnElement>(9999);  // NOLINT
  return cache;
}

KnnGenerator::KnnGenerator() {
  get_item_ = new reco::HBaseGetItem("tb_reco_item", 0);
  get_sim_ = new reco::HBasePoolGetSim("tb_sim_item");
  item_cache_ = InitGlobalCache();
}

KnnGenerator::~KnnGenerator() {
  delete get_sim_;
  delete get_item_;
}

inline bool TransformToKnnElement(const reco::RecoItem& reco_item, KnnGenerator::KnnElement* ele) {
  ele->item_type = reco_item.identity().type();
  ele->item_id = reco_item.identity().item_id();
  if (reco_item.category_size() > 0) {
    ele->level1 = reco_item.category(0);
    if (reco_item.category_size() > 1) {
      ele->level2 = reco_item.category(1);
    } else {
      ele->level2 = "";
    }
  } else {
    ele->level1 = "未分类";
  }

  ele->score = 0.0;

  return true;
}

inline bool IsFilter(const KnnGenerator::KnnElement& ele) {
  if (ele.item_type == 30 || ele.level1.empty() || ele.level1 == "未分类") return true;
  return false;
}

bool KnnGenerator::GenerateCandidates(uint64 item_id, std::vector<KnnGenerator::KnnElement>* candidates) {
  candidates->clear();
  std::vector<SimResult> sims;
  if (!get_sim_->GetSimItem(item_id, &sims) || sims.empty()) return false;

  miss_ids_.clear();
  scores_.clear();

  KnnGenerator::KnnElement ele;
  for (int i = 0; i < (int)sims.size(); ++i) {
    if (sims[i].level > 2) continue;

    if (item_cache_->Find(sims[i].item_id, &ele)) {
      // mask video
      if (!IsFilter(ele)) {
        ele.score = sims[i].score;
        candidates->push_back(ele);
      }
      continue;
    }
    // get from hbase
    miss_ids_.push_back(sims[i].item_id);
    scores_.push_back(sims[i].score);
  }

  KnnGenerator::KnnElement orig_ele;
  bool find_orig = item_cache_->Find(item_id, &orig_ele);
  if (!find_orig) {
    miss_ids_.push_back(item_id);
    scores_.push_back(1.0);
  }

  std::vector<reco::RecoItem> reco_items;
  get_item_->GetRecoItems(miss_ids_, &reco_items);

  for (size_t i = 0; i < miss_ids_.size(); ++i) {
    if (!TransformToKnnElement(reco_items[i], &ele)) {
      LOG(ERROR) << "erro reco item: " << miss_ids_[i] << " for: " << item_id;
      continue;
    }
    ele.score = scores_[i];
    item_cache_->Add(miss_ids_[i], ele);
    if (!IsFilter(ele)) {
      candidates->push_back(ele);
    }
  }
  if (find_orig) candidates->push_back(orig_ele);
  return true;
}
}
}
