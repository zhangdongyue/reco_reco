#pragma once
#include <string>
#include <vector>

#include "base/common/basic_types.h"
#include "serving_base/expiry_map/expiry_map.h"

namespace reco {
class HBasePoolGetSim;
class HBaseGetItem;
namespace item_classify {
class KnnGenerator {
 public:
  KnnGenerator();
  ~KnnGenerator();

  struct KnnElement {
    uint64 item_id;
    std::string level1;
    std::string level2;
    int item_type;
    double score;
  };
 public:
  bool GenerateCandidates(uint64 item_id, std::vector<KnnElement>* candidates);
 private:
  reco::HBasePoolGetSim* get_sim_;
  reco::HBaseGetItem* get_item_;
  serving_base::ExpiryMap<uint64, KnnElement>* item_cache_;  // share

  std::vector<uint64> miss_ids_;
  std::vector<double> scores_;
};
}
}
