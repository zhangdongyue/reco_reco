#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include "reco/ml/model_server/api/model_server_api.h"
#include "reco/module/video_analysis/feature_service/hbase_pool_get_video_feature.h"

namespace reco {
namespace item_classify {
class RawItem;
class ClassifyResult;
class ItemClassifyFeature;
class ItemWDClassifier {
 public:
  ItemWDClassifier();
  ~ItemWDClassifier();

  bool Classify(const RawItem& raw_item,
                const std::vector<std::string>& feas,
                int feature_type,
                std::vector<ClassifyResult>* result,
                std::string* detail_info);

 private:
  net::rpc::RpcGroup* channel;
  reco::model_server::ModelService::Stub* stub;
  reco::HBasePoolGetVideoFeature* get_video_feature;
  std::unordered_map<std::string, std::string> text_model;
  std::unordered_map<std::string, std::string> video_model;
};
}
}
