#include "reco/module/item_classify_server/strategy/item_xgboost_classifier.h"

#include <string>
#include <vector>
#include <utility>

#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "reco/module/item_classify_server/global_data/xgboost_util.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

namespace reco {
namespace item_classify {
bool ItemXGboostClassifier::Classify(const std::vector<std::pair<uint32, float> >& sample,
                                     int feature_type,
                                     std::string model_name,
                                     std::vector<ClassifyResult>* p_result,
                                     std::string* detail_info,
                                     uint32 tree_num) {
  VLOG(1) << "start gbdt classify.";
  const std::vector<XGboostModel*>* xgboost_models =
          GlobalDataIns::instance().GetXGBoostMultiModel(model_name).get();
  // 将 sample 转换为 Inst 类型
  SparseBatch::Inst inst((SparseBatch::Entry*) sample.data(), sample.size());

  p_result->clear();
  for (size_t j = 0; j < xgboost_models->size(); ++j) {
    const XGboostModel* p_model = xgboost_models->at(j);
    std::vector<float> ret;
    p_model->p_gbm->Predict(inst, &ret, tree_num, 0);
    p_model->p_obj->PredTransform(&ret);
    for (size_t i = 0; i < ret.size(); i++) {
      // hard code, 强行过滤低阈值结果
      if (ret[i] < 0.6) continue;
      ClassifyResult one_result;
      one_result.cate_name = p_model->cates_list[i];
      // 映射回统一的 cate_id
      one_result.cate_id = GlobalDataIns::instance().GetCategoryIDbyName(one_result.cate_name);
      one_result.score = static_cast<double>(ret[i]);
      one_result.classify_feature_type = feature_type;
      one_result.classify_method = ClassifyMethod::kGBDT;
      p_result->push_back(one_result);
      if (detail_info != NULL) {
        detail_info->append(base::StringPrintf("%s[%2.5f]", one_result.cate_name.c_str(), one_result.score));
      }
    }
  }
  return true;
}
}  // namespace item_classify
}  // namespace reco
