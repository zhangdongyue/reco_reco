#include "reco/module/item_classify_server/strategy/item_rule_classifier.h"
#include <utility>
#include <vector>
#include <unordered_map>

#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/global_data.h"
#include "reco/module/item_classify_server/global_data/define.h"

namespace reco {
namespace item_classify {
// TODO(*): terms must be dedup
void ItemRuleClassifier::Classify(const RawItem& raw_item,
                                  const nlp::term::TermContainer& title_terms,
                                  const std::vector<std::string>& terms,
                                  std::vector<ClassifyResult>* result,
                                  bool is_pre) {
  static const float kRuleScore = 0.955;
  const RuleDict* dict = GlobalDataIns::instance().GetPreRuleDict().get();
  if (!is_pre) {
    // 后规则以补充分类为主 只有在没有一级分类或者二级分类的情况的才会起到作用  要比 prerule 安全很多
    dict =  GlobalDataIns::instance().GetPostRuleDict().get();
  }
  if (raw_item.item_type == 30) {
    dict = GlobalDataIns::instance().GetVideoRuleDict().get();
  }

  const std::unordered_map<std::string, std::vector<int> >& rule_index = dict->rule_index;
  const std::vector<ClassifierRule>& rule_list = dict->rule_list;

  std::unordered_map<int, int> rule_count;
  for (int i = 0; i < (int) terms.size(); ++i) {
    const std::string &term = terms[i];
    auto it = rule_index.find(term);
    if (it == rule_index.end()) continue;
    for (int j = 0; j < (int) it->second.size(); ++j) {
      const int &ruleidx = it->second[j];
      auto itt = rule_count.find(ruleidx);
      if (itt == rule_count.end()) {
        rule_count.insert(std::make_pair(ruleidx, 1));
      } else {
        itt->second += 1;
      }
    }
  }
  // 规则中可以包含 source_种子源 信息
  const std::string &source_term = "source_" + raw_item.source;
  auto it = rule_index.find(source_term);
  if (it != rule_index.end()) {
    for (int j = 0; j < (int) it->second.size(); ++j) {
      const int& ruleidx = it->second[j];
      auto itt = rule_count.find(ruleidx);
      if (itt == rule_count.end()) {
        rule_count.insert(std::make_pair(ruleidx, 1));
      } else {
        itt->second += 1;
      }
    }
  }

  std::unordered_map<std::string, int> classified_cates;
  ClassifyResult cr;
  // 全词匹配的逻辑
  std::vector<std::pair<int, int> > matches;
  std::vector<int> values;
  std::string match_value;
  std::vector<std::string> tokens;
  std::vector<base::Slice> unigrams;
  for (size_t k = 0; k < title_terms.mix_terms().size(); ++k) {
    unigrams.push_back(title_terms.mix_term_slice(raw_item.title, k));
  }
  nlp::util::ForwardMaxMatch(dict->fullword_rule_dict, unigrams, &matches, &values);

  for (size_t i = 0; i < matches.size(); ++i) {
    const ClassifierRule& classifier_rule = rule_list[values[i]];
    auto& cates = classifier_rule.cates;
    for (size_t j = 0; j < cates.size(); ++j) {
      LOG(INFO) << "Itemid:" << raw_item.item_id << " title:" << raw_item.title << " " << cates[j]
                << " met rule " << classifier_rule.rule_define;
      size_t pos = cates[j].find(",");
      if (pos != std::string::npos && classifier_rule.rule_types[j] == 1) {
        if (classified_cates.find(cates[j].substr(0, pos)) == classified_cates.end())
          classified_cates.insert(std::make_pair(cates[j].substr(0, pos), 1));
      }
      if (classified_cates.find(cates[j]) == classified_cates.end())
        classified_cates.insert(std::make_pair(cates[j], 1));
    }
  }

  // 影视剧与音乐的 rule 冲突时,输出音乐
  if (classified_cates.find("影视剧") != classified_cates.end() && classified_cates.find("音乐") != classified_cates.end()) {  // NOLINT
    auto it = classified_cates.find("影视剧");
    classified_cates.erase(it);
  }
  for (auto it = rule_count.begin(); it != rule_count.end(); ++it) {
    int rule_idx = it->first;
    int count = it->second;

    const ClassifierRule& classifier_rule = rule_list[rule_idx];
    if (count != classifier_rule.ngram_length) continue;
    auto& cates = classifier_rule.cates;
    for (size_t j = 0; j < cates.size(); ++j) {
      LOG(INFO) << "Itemid:" << raw_item.item_id << " title:" << raw_item.title << " " << cates[j]
                << " met rule " << classifier_rule.rule_define;
      size_t pos = cates[j].find(",");
      if (pos != std::string::npos && classifier_rule.rule_types[j] == 1) {
        if (classified_cates.find(cates[j].substr(0, pos)) == classified_cates.end())
          classified_cates.insert(std::make_pair(cates[j].substr(0, pos), 1));
      }
      if (classified_cates.find(cates[j]) == classified_cates.end())
        classified_cates.insert(std::make_pair(cates[j], 1));
    }
  }


  for (auto it = classified_cates.begin(); it != classified_cates.end(); ++it) {
    cr.cate_id = GlobalDataIns::instance().GetCategoryIDbyName(it->first);
    cr.cate_name = it->first;
    cr.classify_feature_type = FeatureType::kOtherFeatureType;
    cr.classify_method = ClassifyMethod::kRule;
    cr.score = kRuleScore;
    result->push_back(cr);
  }

}

// just a fucking strategy for tv and movie in video
void ItemRuleClassifier::Classify(const RawItem& raw_item,
                                  std::vector<ClassifyResult>* result) {
  static const float kRuleScore = 0.8;

  ClassifyPairSemantic(raw_item, result);
  if (!result->empty()) return;

  if (raw_item.item_type != 30) return;
  const RawRuleDict* dict = GlobalDataIns::instance().GetRawRuleDict().get();
  if (dict == NULL) {
    LOG(ERROR) << "emtpy dict";
    return;
  }

  std::vector<base::Slice> matches;
  std::vector<int> values;

  nlp::util::ForwardMaxMatch(dict->dict, raw_item.title, &matches, &values);

  if (matches.empty()) return;

  ClassifyResult cr;
  cr.cate_name = dict->categories[values.front()];
  cr.cate_id = GlobalDataIns::instance().GetCategoryIDbyName(cr.cate_name);
  cr.classify_feature_type = FeatureType::kOtherFeatureType;
  cr.classify_method = ClassifyMethod::kRawRule;
  cr.score = kRuleScore;
  result->push_back(cr);
}

void ItemRuleClassifier::ClassifyPairSemantic(const RawItem& raw_item, std::vector<ClassifyResult>* result) {
  static const float kRuleScore = 0.81;
  const RawRuleDict* dict = GlobalDataIns::instance().GetPairSemanticDict().get();
  if (dict == NULL) {
    LOG(ERROR) << "emtpy dict";
    return;
  }

  std::vector<base::Slice> matches;
  std::vector<int> values;

  nlp::util::ForwardMaxMatch(dict->dict, raw_item.title, &matches, &values);

  if (matches.empty()) return;
  std::unordered_map<int, int> cate_result_dict;
  for (int i = 0; i < (int)values.size(); ++i) {
    int word_type = values[i] & 0xFF;
    int category_idx = values[i] >> 8;
    if (category_idx >= (int)dict->categories.size()) {
      LOG(ERROR) << "erro idx: " << category_idx << " " << matches[i].as_string();
      continue;
    }
    // LOG(ERROR) << "match : " << matches[i].as_string() << " " << word_type;
    auto it_pair = cate_result_dict.insert(std::make_pair(category_idx, 1 << word_type));
    if (!it_pair.second) {
      it_pair.first->second |= 1 << word_type;
    }
  }
  for (auto it = cate_result_dict.begin(); it != cate_result_dict.end(); ++it) {
    if (it->second == 6 || it->second == 10 || it->second == 12 || it->second == 14) {
      ClassifyResult cr;
      cr.cate_name = dict->categories[it->first];
      cr.cate_id = GlobalDataIns::instance().GetCategoryIDbyName(cr.cate_name);
      cr.classify_feature_type = FeatureType::kOtherFeatureType;
      cr.classify_method = ClassifyMethod::kRawRule;
      cr.score = kRuleScore;
      result->push_back(cr);
      break;
    }
  }
}
}
}
