#pragma once

#include <string>
#include <unordered_map>
#include <vector>

namespace reco {
namespace item_classify {
class ItemPostClassifier {
 public:
  bool Classify(const std::vector<std::string>& flags,
                int item_type,
                std::vector<std::unordered_map<std::string, std::string> >* result);
};
}
}
