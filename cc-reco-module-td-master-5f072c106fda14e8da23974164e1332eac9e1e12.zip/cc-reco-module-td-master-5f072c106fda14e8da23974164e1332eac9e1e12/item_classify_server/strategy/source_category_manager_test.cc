#include "reco/module/item_classify_server/strategy/source_category_manager.h"

#include <string>
#include <vector>
#include <fstream>

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "nlp/common/nlp_util.h"
DEFINE_string(data_dir, "reco/item_classify_server/data", "data dir");
// Test for exsit category
// TEST(SourceCategoryManagerTest, TestExistCategory) {
//   reco::item_classify::GlobalData global_data;
//
//   serving_base::DataManangerConfig config;
//   config.controller_item_num = 1;
//   reco::item_classify::ItemClassifyDataManager::Initialize(config, &global_data);
//
//   CHECK(reco::item_classify::ItemClassifyDataManager::RegisterDict(new reco::item_classify::SourceCategoryDict(reco::item_classify::kSourceCategoryDictName, base::FilePath(FLAGS_data_dir)),  // NOLINT
//                                                                    new reco::item_classify::SourceCategoryDict(reco::item_classify::kSourceCategoryDictName, base::FilePath(FLAGS_data_dir))));  // NOLINT
//   std::string line;
//   std::vector<std::string> tokens;
//   std::string strict_category;
//   reco::item_classify::SourceCategoryManager source_category_manager;
//
//   std::ifstream fin("reco/item_classify_server/data/source_to_category.txt");
//   while (std::getline(fin, line)) {
//     tokens.clear();
//     base::SplitString(line, "\t", &tokens);
//     if (tokens.size() < 3 || tokens.size() > 4) {
//       LOG(ERROR) << "erro line: " << line;
//       continue;
//     }
//     int level1_type = 0;
//     int level2_type = 0;
//     int type = base::ParseIntOrDie(tokens.back());
//     if (tokens.size() == 3) {
//       level1_type = type;
//     } else {
//       level2_type = type;
//     }
//     source_category_manager.SetSource(tokens[0]);
//     ASSERT_TRUE(source_category_manager.IsValidLevel1(tokens[1]));
//
//     bool find_strict = source_category_manager.GetStrictLevel1(&strict_category);
//     if (level1_type == reco::item_classify::kStrict) {
//       ASSERT_TRUE(find_strict) << line;
//     } else if (find_strict) {
//       ASSERT_EQ(tokens[1], strict_category);
//     }
//
//     source_category_manager.SetLevel1(tokens[0], tokens[1]);
//     if (tokens.size() > 2) {
//       ASSERT_TRUE(source_category_manager.IsValidLevel2(tokens[2]));
//
//       if (leve2_type == reco::item_classify::kStrict) {
//         ASSERT_TRUE(source_category_manager.GetStrictLevel2(&strict_category));
//       } else {
//         ASSERT_TRUE(!source_category_manager.GetStrictLevel2(&strict_category));
//       }
//     }
//   }
// }

// Test for none exist category
// TEST(SourceCategoryManagerTest, TestNoneExistCategory) {
//   // reco::item_classify::SourceCategoryManager::Init(base::FilePath("reco/item_classify_server/data"));
//   std::ifstream fin("reco/item_classify_server/data/none_exist_source_category.txt");
//
//   std::string line;
//   std::vector<std::string> tokens;
//   std::string strict_category;
//   reco::item_classify::SourceCategoryManager source_category_manager;
//
//   while (std::getline(fin, line)) {
//     tokens.clear();
//     base::SplitString(line, "\t", &tokens);
//     if (tokens.size() < 3) {
//       LOG(ERROR) << "erro line: " << line;
//       continue;
//     }
//
//     int test_type = base::ParseIntOrDie(tokens[0]);
//     CHECK_GT(test_type, -1);
//     CHECK_GT(3, test_type);
//
//     bool source_valid = source_category_manager.SetSource(tokens[1]);
//
//     // none exist source
//     if (test_type == 0) {
//       ASSERT_TRUE(!source_valid);
//       continue;
//     }
//
//     process_category_type(&tokens[2]);
//     // none exist level1
//     if (test_type == 1) {
//       ASSERT_TRUE(!source_category_manager.IsValidLevel1(tokens[2]));
//       continue;
//     }
//     std::string default_level1 = source_category_manager.GetDefaultLevel1();
//     ASSERT_TRUE(default_level1.size() > 0) << "empty category for :" << line;
//
//     if (tokens.size() < 4) continue;
//
//     process_category_type(&tokens[3]);
//     ASSERT_TRUE(source_category_manager.SetLevel1(tokens[1], tokens[2]));
//     // none exist level2
//     ASSERT_TRUE(!source_category_manager.IsValidLevel2(tokens[3])) << line;
//   }
// }
