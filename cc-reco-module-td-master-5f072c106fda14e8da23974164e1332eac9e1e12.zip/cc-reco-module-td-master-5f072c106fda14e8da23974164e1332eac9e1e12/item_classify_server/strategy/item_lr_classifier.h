#pragma once

#include <string>
#include <vector>

namespace reco {
namespace item_classify {
class RawItem;
class ClassifyResult;
class ItemClassifyFeature;
class ItemLRClassifier {
 public:
  bool Classify(const RawItem& raw_item,
                const std::vector<std::string>& feas,
                int feature_type,
                std::vector<ClassifyResult>* result,
                std::string* detail_info);
 private:
  std::vector<double> acc_weight_;
};
}
}
