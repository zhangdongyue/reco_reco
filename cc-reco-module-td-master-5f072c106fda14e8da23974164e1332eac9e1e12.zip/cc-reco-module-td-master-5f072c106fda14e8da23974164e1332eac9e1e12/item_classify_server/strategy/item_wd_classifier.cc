#include "reco/module/item_classify_server/strategy/item_wd_classifier.h"
#include "base/strings/string_printf.h"
#include "base/common/logging.h"
#include "reco/module/item_classify_server/global_data/global_data.h"
#include "reco/ml/model_server/api/model_server_api.h"
#include "base/common/base.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/module/video_analysis/feature_service/hbase_pool_get_video_feature.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

using reco::model_server::ModelService;
DEFINE_string(model_server_ip, "11.251.198.163,11.251.198.142,11.251.198.141", "model server ip");
DEFINE_int32(model_server_port, 20045, "model_server_port");
namespace reco {
namespace item_classify {
ItemWDClassifier::ItemWDClassifier() {
  text_model["text_classify_junshi"] = "军事";
  // text_model["text_classify_keji"] = "科技";
  text_model["text_classify_jiaoyu"] = "教育";

  video_model["video_classify_dongman"] = "动漫";
  video_model["video_classify_youxi"] = "游戏";
  video_model["video_classify_qiche"] = "汽车";
  video_model["video_classify_shishang"] = "时尚";

  get_video_feature = new reco::HBasePoolGetVideoFeature("tb_video_feature");

  std::vector<std::string> ips;
  base::SplitString(FLAGS_model_server_ip, ",", &ips);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 2;
  options.timeout = 5000;

  for (int i = 0; i < (int) ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], FLAGS_model_server_port, options.timeout);
    options.servers.push_back(si);
  }
  channel = new net::rpc::RpcGroup(options);
  CHECK(channel->Connect()) << "wyman'rpc failed";
  stub = new reco::model_server::ModelService::Stub(channel);
}

ItemWDClassifier::~ItemWDClassifier() {
  delete channel;
  delete stub;
  delete get_video_feature;
}

bool ItemWDClassifier::Classify(const RawItem& raw_item,
                                const std::vector<std::string>& feas,
                                int feature_type,
                                std::vector<ClassifyResult>* result,
                                std::string* detail_info) {
  if (raw_item.item_type != 30) {
    std::string wd_tags = "";
    if (raw_item.tags.size() > 0) {
      wd_tags += raw_item.tags[0];
      for (int j = 1; j < (int) raw_item.tags.size(); ++j)
        wd_tags = wd_tags + "," + raw_item.tags[j];
    }

    std::string wd_keywords = "";
    if (raw_item.keywords.size() > 0) {
      wd_keywords += raw_item.keywords[0].first;
      for (int j = 1; j < (int) raw_item.keywords.size(); ++j)
        wd_keywords = wd_keywords + "," + raw_item.keywords[j].first;
    }

    std::string wd_topics = "";
    if (raw_item.topics.size() > 0) {
      wd_topics += raw_item.topics[0].first;
      for (int j = 0; j < (int) raw_item.topics.size(); ++j)
        wd_topics = wd_topics + "," + raw_item.topics[j].first;
    }

    std::string wd_ngrams = "";
    if (feas.size() > 0) {
      wd_ngrams += feas[0];
      for (int j = 1; j < (int) feas.size(); ++j) {
        if (feas[j][0] == '#' || feas[j][0] == '$') continue;
        wd_ngrams = wd_ngrams + "," + feas[j];
      }
    }

    for (auto it = text_model.begin(); it != text_model.end(); ++it) {
      reco::model_server::PackagedRequest packaged_request;
      reco::model_server::OneRequest* one_request = packaged_request.add_request_items();
      one_request->set_user_id(1);

      reco::model_server::WideDeepRequest* wd_request = one_request->add_wide_deep_requests();
      reco::model_server::Features* fea = wd_request->add_request_items();

      reco::model_server::FeatureInfo* fea_tags = fea->add_feature_info();
      fea_tags->set_literal("TAGS");
      fea_tags->set_text(wd_tags);

      reco::model_server::FeatureInfo* fea_keywords = fea->add_feature_info();
      fea_keywords->set_literal("KEYWORDS");
      fea_keywords->set_text(wd_keywords);

      reco::model_server::FeatureInfo* fea_topics = fea->add_feature_info();
      fea_topics->set_literal("TOPICS");
      fea_topics->set_text(wd_topics);

      reco::model_server::FeatureInfo* fea_ngrams = fea->add_feature_info();
      fea_ngrams->set_literal("NGRAMS");
      fea_ngrams->set_text(wd_ngrams);

      wd_request->mutable_model_info()->set_model_name(it->first);
      wd_request->set_sid(111);

      reco::model_server::PackagedResponse response;
      net::rpc::RpcClientController rpc;
      rpc.SetTimeout(100);
      stub->PackagedSearch(&rpc, &packaged_request, &response, NULL);
      rpc.Wait();

      if (rpc.status() == net::rpc::RpcClientController::kDeadlineExceeded) {
        LOG(ERROR) << "timeout: ";
        continue;
      }

      if (rpc.status() != net::rpc::RpcClientController::kOk || response.code() != 0) {
        LOG(ERROR) << "failed: " << response.code();
        continue;
      }

      if (response.responses_items_size() < 1
          || response.responses_items(0).wide_deep_responses_size() < 1)
        continue;
      const reco::model_server::WideDeepResponse& wd_response
              = response.responses_items(0).wide_deep_responses(0);
      if (wd_response.response_items_size() < 1) continue;
      if (wd_response.response_items(0).q() < 0.55) continue;

      result->push_back(ClassifyResult());
      ClassifyResult& cr = result->back();
      cr.cate_id = GlobalDataIns::instance().GetCategoryIDbyName(it->second);
      cr.cate_name = it->second;
      cr.classify_feature_type = feature_type;
      cr.classify_method = kWideDeep;
      cr.score = wd_response.response_items(0).q();
    }
  } else {
    std::string wd_tags = "";
    if (raw_item.tags.size() > 0) {
      wd_tags += raw_item.tags[0];
      for (int j = 1; j < (int) raw_item.tags.size(); ++j)
        wd_tags = wd_tags + "," + raw_item.tags[j];
    }

    std::string wd_keywords = "";
    if (raw_item.keywords.size() > 0) {
      wd_keywords += raw_item.keywords[0].first;
      for (int j = 1; j < (int) raw_item.keywords.size(); ++j)
        wd_keywords = wd_keywords + "," + raw_item.keywords[j].first;
    }

    std::string wd_topics = "";
    if (raw_item.topics.size() > 0) {
      wd_topics += raw_item.topics[0].first;
      for (int j = 0; j < (int) raw_item.topics.size(); ++j)
        wd_topics = wd_topics + "," + raw_item.topics[j].first;
    }

    std::string wd_ngrams = "";
    if (feas.size() > 0) {
      wd_ngrams += feas[0];
      for (int j = 1; j < (int) feas.size(); ++j) {
        if (feas[j][0] == '#' || feas[j][0] == '$') continue;
        wd_ngrams = wd_ngrams + "," + feas[j];
      }
    }

    reco::VideoFeature video_feature;
    std::string wd_video = "";
    if (video_feature.classify_feature_size() > 0) {
      wd_video += base::DoubleToString(video_feature.classify_feature(0));
      for (int j = 1; j < (int) video_feature.classify_feature_size(); ++j) {
        wd_video = wd_video + "," + base::DoubleToString(video_feature.classify_feature(j));
      }
    }
    LOG(INFO) << "wyman : " << wd_video;

    for (auto it = video_model.begin(); it != video_model.end(); ++it) {
      reco::model_server::PackagedRequest packaged_request;
      reco::model_server::OneRequest* one_request = packaged_request.add_request_items();
      one_request->set_user_id(1);

      reco::model_server::WideDeepRequest* wd_request = one_request->add_wide_deep_requests();
      reco::model_server::Features* fea = wd_request->add_request_items();

      reco::model_server::FeatureInfo* fea_tags = fea->add_feature_info();
      fea_tags->set_literal("TAGS");
      fea_tags->set_text(wd_tags);

      reco::model_server::FeatureInfo* fea_keywords = fea->add_feature_info();
      fea_keywords->set_literal("KEYWORDS");
      fea_keywords->set_text(wd_keywords);

      reco::model_server::FeatureInfo* fea_topics = fea->add_feature_info();
      fea_topics->set_literal("TOPICS");
      fea_topics->set_text(wd_topics);

      reco::model_server::FeatureInfo* fea_ngrams = fea->add_feature_info();
      fea_ngrams->set_literal("NGRAMS");
      fea_ngrams->set_text(wd_ngrams);

      reco::model_server::FeatureInfo* fea_video = fea->add_feature_info();
      fea_video->set_literal("VIDEOFEA");
      fea_video->set_text(wd_video);

      wd_request->mutable_model_info()->set_model_name(it->first);
      wd_request->set_sid(111);

      reco::model_server::PackagedResponse response;
      net::rpc::RpcClientController rpc;
      rpc.SetTimeout(100);
      stub->PackagedSearch(&rpc, &packaged_request, &response, NULL);
      rpc.Wait();

      if (rpc.status() == net::rpc::RpcClientController::kDeadlineExceeded) {
        LOG(ERROR) << "timeout: ";
        continue;
      }

      if (rpc.status() != net::rpc::RpcClientController::kOk || response.code() != 0) {
        LOG(ERROR) << "failed: " << response.code();
        continue;
      }

      if (response.responses_items_size() < 1 ||
              response.responses_items(0).wide_deep_responses_size() < 1)
        continue;
      const reco::model_server::WideDeepResponse& wd_response =
              response.responses_items(0).wide_deep_responses(0);
      if (wd_response.response_items_size() < 1) continue;
      if (wd_response.response_items(0).q() < 0.55) continue;

      result->push_back(ClassifyResult());
      ClassifyResult& cr = result->back();
      cr.cate_id = GlobalDataIns::instance().GetCategoryIDbyName(it->second);
      cr.cate_name = it->second;
      cr.classify_feature_type = feature_type;
      cr.classify_method = kWideDeep;
      cr.score = wd_response.response_items(0).q();
    }
  }

  return true;
}
}
}
