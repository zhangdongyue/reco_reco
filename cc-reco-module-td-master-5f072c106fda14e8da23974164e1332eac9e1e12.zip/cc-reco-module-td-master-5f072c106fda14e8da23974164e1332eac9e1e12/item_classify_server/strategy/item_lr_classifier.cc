#include "reco/module/item_classify_server/strategy/item_lr_classifier.h"

#include <vector>

#include "base/strings/string_printf.h"
#include "base/common/logging.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

namespace reco {
namespace item_classify {
bool ItemLRClassifier::Classify(const RawItem &raw_item,
                                const std::vector<std::string>& feas,
                                int feature_type,
                                std::vector<ClassifyResult>* result,
                                std::string* detail_info) {
  if (detail_info != NULL) {
    detail_info ->append(base::StringPrintf("feature_type=%d\t", feature_type));
  }

  const LRModel* model = GlobalDataIns::instance().GetLRModel().get();
  const dawgdic::Dictionary& dict = model->dict;
  const float* weights = model->weights;

  int category_size = model->all_category.size();
  acc_weight_.clear();
  acc_weight_.resize(category_size, 0);

  // 迭代计算分数
  for (size_t i = 0; i < feas.size(); ++i) {
    const std::string &term = feas[i];
    int value = dict.Find(term.c_str(), term.size());
    if (value < 0) continue;

    if (detail_info != NULL) {
      detail_info->append(term);
      detail_info->append("{");
    }

    const float* weight = weights + model->offset[value];
    int category_num = (reinterpret_cast<const int &>(*weight) >> 16);
    for (int j = 0; j < category_num; ++j) {
      int v = reinterpret_cast<const int &>(*weight);
      // NOTE(xielang): category idx 16 位 应该足够用
      int category_idx = v & 0xffff;
      CHECK_GT(category_idx, 0);
      CHECK_GT(category_size, category_idx);
      acc_weight_[category_idx] += *(weight + 1);
      if (*(weight + 1) > 1e-6 && acc_weight_[category_idx] > 1e-6 && detail_info != NULL) {
        detail_info->append(
                base::StringPrintf("%s[%2.5f]",
                                   model->all_category[category_idx].c_str(),
                                   acc_weight_[category_idx]));
      }
      weight += 2;
    }

    if (detail_info != NULL) {
      detail_info->append("}");
    }
  }

  for (int j = 1; j < category_size; ++j) {
    if (acc_weight_[j] < 1e-3) continue;
    result->push_back(ClassifyResult());
    ClassifyResult& cr = result->back();
    cr.cate_id = j;
    cr.cate_name = model->all_category[j];
    cr.classify_feature_type = feature_type;
    cr.classify_method = kLR;
    cr.score = acc_weight_[j];
  }
  return true;
}
}
}

