#pragma once
#include <boost/shared_ptr.hpp>
#include <vector>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#include "base/common/basic_types.h"
#include "base/strings/string_printf.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/define.h"

namespace base {
class FilePath;
}
namespace reco {
namespace item_classify {
class RawItem;
class FeatureExtractor;
class ItemRuleClassifier;
class ItemLRClassifier;
class ItemWDClassifier;
class ItemFastTextClassifier;
class ItemDefaultClassifier;
class ClassifyInfo;
class FeatureInfo;
class ItemPostClassifier;

class VideoClassifier {
 public:
  VideoClassifier();
  ~VideoClassifier();

  void Classify(const RawItem& raw_item,
                std::vector<std::pair<double, std::string> >* best_result,
                std::vector<std::pair<double, std::string> >* multi_result,
                std::vector<std::pair<double, std::string> >* tag_result);

  const std::vector<ClassifyInfo>& classify_infos() const {
    return classify_infos_;
  }

  const std::vector<FeatureInfo>& feature_infos() const {
    return feature_infos_;
  }

  inline double DecideThreshold(const std::string& strategy_name,
                                const std::string& cate_name,
                                const std::string& source) {
    // decide threshold, not include special threshold for  source|method|category
    auto it_special = cate_threshold_->find(base::StringPrintf("%s|%s|%s", source.c_str(),
                                                               strategy_name.c_str(),
                                                               cate_name.c_str()));
    if (it_special != cate_threshold_->end()) {
      return it_special->second;
    }

    float threshold = 0.5;
    if (!result_default_.empty() && result_default_[0].cate_name != cate_name) {
      threshold = result_default_[0].score;
      // LOG(INFO) << "default " << result_default_[0].cate_name << " " << threshold;
    }

    auto it_threshold = cate_threshold_->find(strategy_name);
    if (it_threshold != cate_threshold_->end() && threshold < it_threshold->second) {
      threshold = it_threshold->second;
    }

    if (bad_source_->find(source) != bad_source_->end() && threshold < 0.8) {
      threshold = 0.8;
    }
    // 类别的阈值
    auto it_cate = cate_threshold_->find(cate_name);
    if (it_cate != cate_threshold_->end() && it_cate->second > threshold) {
      threshold = it_cate->second;
    }

    // strategy + cate
    it_threshold = cate_threshold_->find(strategy_name + "|" + cate_name);
    if (it_threshold != cate_threshold_->end() && it_threshold->second > threshold) {
      threshold = it_threshold->second;
    }
    // level2 threshold
    size_t pos = cate_name.find(",");
    if (pos != std::string::npos) {
      auto it_threshold = cate_threshold_->find(strategy_name + "|" + cate_name.substr(0, pos));
      if (it_threshold != cate_threshold_->end() && it_threshold->second > threshold) {
        threshold = it_threshold->second;
      }
    }
    return threshold;
  }
 private:
  void DoSubClassify(const RawItem& raw_item);
  // do fiter and name mapping
  void ProcessResult(const RawItem& raw_item,
                     const std::string& strategy_name,
                     int score_type,
                     const std::vector<ClassifyResult>& result,
                     ClassifyInfo* classify_info);

  void GenFinalResult(const RawItem& raw_item,
                      std::vector<std::pair<double, std::string> >* best_result,
                      std::vector<std::pair<double, std::string> >* multi_result,
                      std::vector<std::pair<double, std::string> >* tag_result);

  bool DetermineBestLevel1(const RawItem& raw_item,
                           std::unordered_map<std::string, double>* level1_dict,
                           std::vector<std::pair<double, std::string> >* multi_result,
                           std::string* best_level1);

  bool DetermineBestLevel2(const RawItem& raw_item,
                           const std::string& best_level1,
                           std::unordered_map<std::string, double>* level2_dict,
                           std::vector<std::pair<double, std::string> >* multi_result,
                           std::vector<std::pair<double, std::string> >* tag_result,
                           std::string* best_level2);

  static const float kRuleScore;
  static const float kDefaultScore;

  boost::shared_ptr<const std::unordered_map<std::string, double> > video_category_;
  boost::shared_ptr<const std::unordered_map<std::string, std::string> > video_cate_map_;
  boost::shared_ptr<const std::unordered_map<std::string, double> > cate_threshold_;
  boost::shared_ptr<const std::unordered_map<std::string, std::string> > pure_dict_;
  boost::shared_ptr<const std::unordered_set<std::string> > bad_source_;

  std::unordered_map<std::string, std::string> cate_multi_map_;
  std::unordered_set<std::string> unstable_category_dict_;

  std::vector<ClassifyResult> result_lr_;
  std::vector<ClassifyResult> result_text_lr_;
  std::vector<ClassifyResult> result_fasttext_;
  std::vector<ClassifyResult> result_default_;
  std::vector<ClassifyResult> result_rule_;
  std::vector<ClassifyResult> raw_result_rule_;
  std::vector<ClassifyResult> result_widedeep_;

  std::vector<std::unordered_map<std::string, std::string> > post_result_;

  // after single fitler collect all result here, for determine multi result and best result
  std::vector<ClassifyResult> all_result_;

  FeatureExtractor* feature_extractor_;
  ItemClassifyFeature item_fea_;

  ItemRuleClassifier* rule_classifier_;
  ItemLRClassifier* lr_classifier_;
  ItemFastTextClassifier* item_fasttext_classifier_;
  ItemDefaultClassifier* item_defalut_classifier_;
  ItemPostClassifier* item_post_classifier_;
  ItemWDClassifier* item_wd_classifier_;
  // some reused variables
  std::vector<ClassifyInfo> classify_infos_;
  std::vector<FeatureInfo> feature_infos_;
};
}
}
