#include "reco/module/item_classify_server/strategy/video_classifier.h"

#include <algorithm>
#include <functional>
#include <string>
#include <vector>
#include <fstream>
#include <utility>
#include <set>
#include <cmath>

#include "base/file/file_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "nlp/common/nlp_util.h"

#include "reco/module/item_classify_server/global_data/global_data.h"
#include "reco/module/item_classify_server/strategy/item_rule_classifier.h"
#include "reco/module/item_classify_server/strategy/item_lr_classifier.h"
#include "reco/module/item_classify_server/strategy/item_wd_classifier.h"
#include "reco/module/item_classify_server/strategy/item_fasttext_classifier.h"
#include "reco/module/item_classify_server/strategy/item_default_classifier.h"
#include "reco/module/item_classify_server/strategy/item_post_classifier.h"
#include "reco/bizc/proto/item_classify.pb.h"
DEFINE_bool(use_wd_video, false, "whether use w&d");

namespace reco {
namespace item_classify {

VideoClassifier::VideoClassifier() {
  item_defalut_classifier_ = new ItemDefaultClassifier();
  rule_classifier_ = new ItemRuleClassifier();
  lr_classifier_ = new ItemLRClassifier();
  item_fasttext_classifier_ = new ItemFastTextClassifier();
  feature_extractor_ = new FeatureExtractor();
  item_post_classifier_ = new ItemPostClassifier();
//  item_wd_classifier_ = new ItemWDClassifier();

  // NOTE(xielang): 临时处理，体系统一删除
  cate_multi_map_["历史"] = "影视剧";
  cate_multi_map_["社会"] = "语言类";
  cate_multi_map_["娱乐"] = "音乐";
  cate_multi_map_["娱乐"] = "影视剧";
  cate_multi_map_["奇闻"] = "影视剧";
  cate_multi_map_["育儿"] = "综艺";

  unstable_category_dict_.insert("娱乐");
  unstable_category_dict_.insert("搞笑");
  unstable_category_dict_.insert("社会");
  unstable_category_dict_.insert("影视剧");
  unstable_category_dict_.insert("美女");
  unstable_category_dict_.insert("美女写真");
}

VideoClassifier::~VideoClassifier() {
  delete feature_extractor_;
  delete lr_classifier_;
  delete rule_classifier_;
  delete item_fasttext_classifier_;
  delete item_defalut_classifier_;
  delete item_post_classifier_;
  delete item_wd_classifier_;
}

inline double logit(double weight) {
  if (weight > 10) return 1.0;
  if (weight < -10) return 0.000045;
  return 1.0 / (1 + std::exp(0 - weight));
}

bool VideoClassifier::DetermineBestLevel1(const RawItem& raw_item,
                                          std::unordered_map<std::string, double>* level1_dict,
                                          std::vector<std::pair<double, std::string> >* multi_result,
                                          std::string* best_level1) {
  boost::shared_ptr<const std::unordered_set<std::string> > meinv_source_dict = GlobalDataIns::instance().GetSpecialSourceDict("美女");  // NOLINT
  for (size_t i = 0; i < all_result_.size(); ++i) {
    const std::string& cate_name = all_result_[i].cate_name;
    if (cate_name.find(",") != std::string::npos) continue;

    // controll meinv source
    if (cate_name.find("美女") != std::string::npos && meinv_source_dict->find(raw_item.source) == meinv_source_dict->end()) { // NOLINT
      continue;
    }

    auto it = level1_dict->insert(std::make_pair(cate_name, all_result_[i].score));
    if (it.second) multi_result->push_back(std::make_pair(all_result_[i].score, cate_name));
    if (best_level1->empty()) *best_level1 = cate_name;
  }

  if (!raw_result_rule_.empty() &&
      unstable_category_dict_.find(*best_level1) != unstable_category_dict_.end()) {
    *best_level1 = raw_result_rule_.front().cate_name;
    level1_dict->insert(std::make_pair(*best_level1, raw_result_rule_.front().score));
  }

  if (level1_dict->empty()) {
    LOG(INFO) << "empty parent for item: "<< raw_item.item_id;
    return false;
  }
  return true;
}

bool VideoClassifier::DetermineBestLevel2(const RawItem& raw_item,
                                          const std::string& best_level1,
                                          std::unordered_map<std::string, double>* level2_dict,
                                          std::vector<std::pair<double, std::string> >* multi_result,
                                          std::vector<std::pair<double, std::string> >* tag_result,
                                          std::string* best_level2) {
  const std::unordered_map<std::string, double>* tag_list = GlobalDataIns::instance().GetVideoTagList().get();
  for (size_t i = 0; i < all_result_.size(); ++i) {
    const std::string& cate_name = all_result_[i].cate_name;
    size_t pos = cate_name.find(",");
    if (cate_name == "娱乐,明星") continue;
    if (pos == std::string::npos || cate_name.substr(0, pos) != best_level1) {
      VLOG(1) << "filter out by level1: " << cate_name;
      continue;
    }

    double score = all_result_[i].score;

    // NOTE(xielang): 当前泛娱乐的标签会有麻烦
    if (tag_list->find(cate_name) != tag_list->end()) {
      auto it = level2_dict->insert(std::make_pair(cate_name, score));
      if (it.second) {
        tag_result->push_back(std::make_pair(score, cate_name));
      }
      continue;
    }

    auto it = level2_dict->insert(std::make_pair(cate_name, score));
    if (it.second) multi_result->push_back(std::make_pair(score, cate_name));
    if (best_level2->empty()) *best_level2 = cate_name;
  }
  return true;
}

void VideoClassifier::GenFinalResult(const RawItem& raw_item,
                                     std::vector<std::pair<double, std::string> >* best_result,
                                     std::vector<std::pair<double, std::string> >* multi_result,
                                     std::vector<std::pair<double, std::string> >* tag_result) {
  best_result->clear();
  multi_result->clear();
  tag_result->clear();

  // step 1 : get reasonalble level1
  std::unordered_map<std::string, double> level1_dict;
  std::string best_level1;
  if (!DetermineBestLevel1(raw_item, &level1_dict, multi_result, &best_level1) && !result_default_.empty()) {
    // TODO(xielang): 切换新框架，数据库批量修改, 使用 default 不需要做任何映射，default 保证新旧的问题
    auto it = video_cate_map_->find(result_default_[0].cate_name);
    if (it != video_cate_map_->end()) {
      best_result->push_back(std::make_pair(result_default_[0].score, it->second));
    } else {
      best_result->push_back(std::make_pair(result_default_[0].score, result_default_[0].cate_name));
    }
    return;
  }

  // step2 : get reasonalble level2
  std::unordered_map<std::string, double> level2_dict;
  std::string best_level2;
  DetermineBestLevel2(raw_item, best_level1, &level2_dict, multi_result, tag_result, &best_level2);
  // LOG(INFO) << "bes level2: " << best_level2;

  // step3: do name mapping, to get the write cate frame
  // NOTE(xielang): do the mapping for old result, 演讲 是唯一的意外，标签
  {
    // 经过 mapping 的不会是某种 parent 放心
    auto it1 = video_cate_map_->find(best_level1);
    auto it2 = video_cate_map_->find(best_level2);
    if (it1 != video_cate_map_->end()) {
      best_result->push_back(std::make_pair(level1_dict[best_level1], it1->second));
    } else if (it2 != video_cate_map_->end()) {
      best_result->push_back(std::make_pair(level2_dict[best_level2], it2->second));
    } else if (video_category_->find(best_level1) != video_category_->end()) {
      best_result->push_back(std::make_pair(level1_dict[best_level1], best_level1));
    } else {
      LOG(INFO) << "skip: " << best_level1 << " for " << raw_item.item_id;
    }
    // for multi cate
    for (size_t i = 0; i < multi_result->size(); ++i) {
      auto it = video_cate_map_->find(multi_result->at(i).second);
      if (it != video_cate_map_->end()) {
        multi_result->at(i).second = it->second;
      }
    }
  }

  // step 4: do some modifying
  // post 放到最后不管名字是新或者旧，新框架必须更新 post file
  if (!best_result->empty()) {
    // do post mapping
    CHECK_EQ(post_result_.size(), 2u);
    const std::unordered_map<std::string, std::string>& post_result_l1 = post_result_[0];

    std::string& cate_name = best_result->front().second;

    auto it_post = post_result_l1.find(cate_name);
    if (it_post != post_result_l1.end()) {
      cate_name = it_post->second;
    }

    // dp some pair mapping
    auto it = cate_multi_map_.find(best_result->front().second);
    if (it != cate_multi_map_.end()) {
      for (size_t i = 0; i < multi_result->size(); ++i) {
        if (multi_result->at(i).second == it->second) {
          best_result->at(0).second = it->second;
        }
      }
    }
    // 电影电视召回策略
    if (best_result->front().second == "娱乐") {
      for (size_t i = 0; i < result_lr_.size(); ++i) {
        if (result_lr_[i].score > 0.245 && result_lr_[i].cate_name == "影视剧") {
          best_result->front().second = result_lr_[i].cate_name;
          best_result->front().first = result_lr_[i].score;
        }
      }
    }
  }
}

// score change and merge result
void VideoClassifier::ProcessResult(const RawItem& raw_item,
                                    const std::string& strategy_name,
                                    int score_type,
                                    const std::vector<ClassifyResult>& result,
                                    ClassifyInfo* classify_info) {
  if (result.size() == 0u) return;
  classify_info->set_method_name(strategy_name);
  classify_info->clear_cate_name();
  classify_info->clear_cate_score();
  int start_pos = all_result_.size();
  for (size_t i = 0; i < result.size(); ++i) {
    const std::string& cate_name = result[i].cate_name;
    double score = result[i].score;
    if (score_type == 1) {
      score = logit(score);
    }

    classify_info->add_cate_name(cate_name);
    classify_info->add_cate_score(score);

    double threshold = DecideThreshold(strategy_name, result[i].cate_name, raw_item.source);
    // LOG(INFO) << result[i].cate_name << " " << threshold << " " << score;
    if (score < threshold) continue;

    all_result_.push_back(result[i]);
    all_result_.back().score = score;
  }
  std::sort(all_result_.begin() + start_pos, all_result_.end(), std::greater<ClassifyResult>());
}

void VideoClassifier::Classify(const RawItem& raw_item,
                               std::vector<std::pair<double, std::string> >* best_result,
                               std::vector<std::pair<double, std::string> >* multi_result,
                               std::vector<std::pair<double, std::string> >* tag_result) {
  video_category_ = GlobalDataIns::instance().GetVideoCategory();
  cate_threshold_ = GlobalDataIns::instance().GetCateThreshold();
  video_cate_map_ = GlobalDataIns::instance().GetVideoCateMap();
  pure_dict_ =  GlobalDataIns::instance().GetPureDict();
  bad_source_ = GlobalDataIns::instance().GetBadSource();
  if (raw_item.source.find("-ugc-") != std::string::npos) {
    best_result->push_back(std::make_pair(0.8, "ugc"));
    multi_result->push_back(best_result->front());
    LOG(INFO) << "ugc item_id : " << raw_item.item_id;
    return;
  }
  auto it = pure_dict_->find(raw_item.source);
  if (it != pure_dict_->end()) {
    best_result->push_back(std::make_pair(0.8, it->second));
    multi_result->push_back(best_result->front());
    LOG(INFO) << "hit pure dict: " << raw_item.item_id << " " << it->second;
    return;
  }

  // 1: 特征提取
  item_fea_.clear();
  feature_extractor_->Extract(raw_item, &item_fea_);

  // 2 do sub classifier
  classify_infos_.clear();
  all_result_.clear();
  DoSubClassify(raw_item);

  // 3: decide the final result from all classifier' result
  GenFinalResult(raw_item, best_result, multi_result, tag_result);
}

void VideoClassifier::DoSubClassify(const RawItem& raw_item) {
  // post 的结果先拿出来， 后面逻辑会用到
  {
    std::vector<std::string> other_flags;

    const std::vector<std::pair<std::string, std::string> >& flags = item_fea_.basic_fea.flags;

    for (size_t i = 0; i < flags.size(); ++i) {
      other_flags.push_back(flags[i].first);
    }
    std::sort(other_flags.begin(), other_flags.end());
    post_result_.clear();
    item_post_classifier_->Classify(other_flags, raw_item.item_type, &post_result_);
  }
  // 1: default category
  result_default_.clear();
  if (bad_source_->find(raw_item.source) == bad_source_->end()) {
    item_defalut_classifier_->Classify(raw_item, &result_default_);
  }

  // 2: rule
  result_rule_.clear();
  rule_classifier_->Classify(raw_item, item_fea_.basic_fea.title_terms, item_fea_.basic_fea.title_unigrams_words, &result_rule_, true); // NOLINT
  classify_infos_.push_back(ClassifyInfo());
  ProcessResult(raw_item, "rule", 0, result_rule_, &(classify_infos_.back()));
  raw_result_rule_.clear();
  if (result_rule_.empty()) {
    rule_classifier_->Classify(raw_item, &raw_result_rule_);
  }

  // ProcessResult(raw_item, "raw_rule", 0, result_rule_, &(classify_infos_.back()));

  // 3: videolr: source ngram and ngram 分类模型
  classify_infos_.push_back(ClassifyInfo());
  const std::vector<std::string>& video_ngrams = item_fea_.video_ngram_fea;
  result_lr_.clear();
  lr_classifier_->Classify(raw_item, video_ngrams, kSourceTitle, &result_lr_,
                           classify_infos_.back().add_classify_detail());
  ProcessResult(raw_item, "video_lr", 1, result_lr_, &classify_infos_.back());

  // 4 图文分类器 lr
  classify_infos_.push_back(ClassifyInfo());
  result_text_lr_.clear();
  lr_classifier_->Classify(raw_item, item_fea_.ngram_fea, kLabelTitle, &result_text_lr_,
                           classify_infos_.back().add_classify_detail());
  ProcessResult(raw_item, "video_text_lr", 1, result_text_lr_, &classify_infos_.back());

  // 5 图文 fasttext
  classify_infos_.push_back(ClassifyInfo());
  result_fasttext_.clear();
  item_fasttext_classifier_->Classify(raw_item, item_fea_, kTitle,
                                      &result_fasttext_,
                                      classify_infos_.back().add_classify_detail());
  ProcessResult(raw_item, "fasttext_video", 1, result_fasttext_, &classify_infos_.back());

  // widedeep
  if (FLAGS_use_wd_video) {
    classify_infos_.push_back(ClassifyInfo());
    result_widedeep_.clear();
    item_wd_classifier_->Classify(raw_item, video_ngrams, kLabelTitle, &result_widedeep_,
                                  classify_infos_.back().add_classify_detail());
    ProcessResult(raw_item, "video_widedeep", 1, result_widedeep_, &classify_infos_.back());
  }
}
}
}
