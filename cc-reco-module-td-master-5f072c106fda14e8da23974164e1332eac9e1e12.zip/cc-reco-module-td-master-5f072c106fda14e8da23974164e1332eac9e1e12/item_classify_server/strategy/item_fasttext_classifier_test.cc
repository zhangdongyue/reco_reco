#include "reco/module/item_classify_server/strategy/item_fasttext_classifier.h"

#include "base/common/basic_types.h"
#include "base/testing/gtest.h"
#include "nlp/common/nlp_util.h"
#include "base/file/file_path.h"

#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/feature/item_basic_feature.h"
#include "reco/module/item_classify_server/common/item_util.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/module/item_classify_server/global_data/global_data.h"


DECLARE_string(data_dir);
DECLARE_string(nlp_dicts_root);
DECLARE_string(db_host);
DECLARE_string(db_user);
DECLARE_string(db_passwd);
DECLARE_string(schema);

namespace reco {
namespace redis {
DECLARE_string(redis_pool_ips);
}
namespace item_classify {
DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table name");

TEST(ClassifierTest, TestFastText) {
  // setup
  reco::redis::FLAGS_redis_pool_ips="10.195.157.9:6510";
  FLAGS_data_dir = "../data";
  FLAGS_nlp_dicts_root = "/serving/dict/nlp/dicts";
  FLAGS_db_host="tcp://11.251.202.229:3307";
  FLAGS_db_user="recodev";
  FLAGS_db_passwd="tkDn19DHeVZkNA";
  FLAGS_schema="reco";

  GlobalDataIns::instance().Init();
  ItemFastTextClassifier classifier;
  std::vector<ClassifyResult> result_fasttext;
  FeatureExtractor* extractor = new FeatureExtractor();
  ItemClassifyFeature classify_feature;
  FeatureType fea_type = FeatureType::kTitle;

  // get reco item from hbase
  std::string item_id_str = "8711546069510951170";
  std::vector<uint64> item_id_vec;
  uint64 item_id;
  base::StringToUint64(item_id_str, &item_id);
  item_id_vec.push_back(item_id);

  reco::HBaseGetItem* hbase_item_getter = new reco::HBaseGetItem(FLAGS_hbase_item_table, 0);
  std::vector<reco::item_classify::RawItem> raw_items;
  ItemUtil::GetRawitem(hbase_item_getter, item_id_vec, &raw_items);
  delete hbase_item_getter;

  // classify and print the result
  for (size_t i = 0; i < raw_items.size(); ++i) {
    std::cout << raw_items[i].title << std::endl;
    std::vector<ClassifyResult> classify_result;
    std::string detail_info;
    classify_feature.clear();
    extractor->Extract(raw_items[i], &classify_feature);
    classifier.Classify(raw_items[i], classify_feature, fea_type, &classify_result, &detail_info);
    for (size_t j = 0; j < classify_result.size(); j++) {
      std::cout << classify_result[j].cate_name << " " << classify_result[j].score << std::endl;
    }
    std::cout << "--------------" << std::endl;
  }
}
}
}
