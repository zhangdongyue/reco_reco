#pragma once

#include <vector>
#include <string>

namespace reco {
namespace item_classify {
class RawItem;
class ClassifyResult;
class ItemClassifyFeature;
class ItemFastTextClassifier {
 public:
  // 函数功能: fasttext 分类
  // 输入参数:
  // raw_item:
  // fea :
  // feature_type: 特征类型
  // result: 分类结果指针
  // detail_info: 一些处理信息
  bool Classify(const RawItem& raw_item,
                const ItemClassifyFeature& fea,
                int feature_type,
                std::vector<ClassifyResult>* result,
                std::string* detail_info);
};  // class ItemFastTextClassifier
}  // namespace item_classify
}  // namespace reco
