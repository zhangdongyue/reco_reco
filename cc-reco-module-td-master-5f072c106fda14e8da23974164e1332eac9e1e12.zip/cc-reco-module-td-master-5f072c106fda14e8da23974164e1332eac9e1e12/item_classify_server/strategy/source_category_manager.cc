#include "reco/module/item_classify_server/strategy/source_category_manager.h"

#include <map>
#include <unordered_map>
#include <string>
#include <utility>

#include "base/hash_function/term.h"
#include "nlp/common/nlp_util.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

namespace reco {
namespace item_classify {

const char* SourceCategoryManager::kDummySource = "神马早知道";

bool SourceCategoryManager::SetSource(const std::string& source) {
  source_category_dict_ = GlobalDataIns::instance().GetSourceCategoryDict();

  category_matrix_ = source_category_dict_->category_matrix();
  source_dict_ = source_category_dict_->source_dict();
  sources_ = source_category_dict_->sources();

  level1_candidates_ = NULL;
  level2_candidates_ = NULL;

  if (source.size() == 0 || source.find(kDummySource) != std::string::npos) return true;

  std::string normalized_text;
  nlp::util::NormalizeLineCopy(source, &normalized_text);
  uint64 sign = base::CalcTermSign(normalized_text.c_str(), normalized_text.size());
  auto it = source_dict_->find(sign);
  if (it == source_dict_->end() || category_matrix_->at(it->second) == NULL ||
      category_matrix_->at(it->second)->empty()) {
    VLOG(1) << "cannnot find source: " << source;
    return false;
  }
  CHECK_GT((int)category_matrix_->size(), it->second);
  level1_candidates_ = (*category_matrix_)[it->second];
  if (level1_candidates_ != NULL && !level1_candidates_->empty() && level1_candidates_->begin()->first == "旅游") { // NOLINT
    const_cast<std::map<std::string, std::pair<int, std::map<std::string, int>*>>*>(level1_candidates_)->begin()->second.first = 0; // NOLINT
  }
  // LOG(ERROR) << "source: " << source;
  // for (auto it = level1_candidates_->begin(); it != level1_candidates_->end(); ++it) {
  //   LOG(ERROR) << "level1 candidates: " << it->first << " " << it->second.first;
  // }
  return true;
}

bool SourceCategoryManager::SetLevel1(const std::string& source, const std::string& level1) {
  if (level1_candidates_ == NULL) return true;
  if (level1_candidates_->empty()) {
    LOG(ERROR) << "level1 does not exist in candidats: " << level1;
    return true;
  }

  auto it = level1_candidates_->find(level1);
  if (it == level1_candidates_->end()) {
    VLOG(1) << "cannot find level1:" << level1 << "for current source:" << source;
    return false;
  }
  level2_candidates_ = it->second.second;
  return true;
}

bool SourceCategoryManager::GetDefaultCategory(const std::string& source,
                                               std::string* level1,
                                               std::string* level2) const {
  const std::unordered_map<std::string, std::pair<std::string, std::string>>* default_category = source_category_dict_->default_category(); // NOLINT
  if (default_category == NULL) {
    return false;
  }
  auto it = default_category->find(source);
  if (it == default_category->end()) return false;
  if (level1 != NULL) (*level1) = it->second.second.empty()? it->second.first:it->second.second;
  if (level2 != NULL && !it->second.second.empty()) (*level2) = it->second.first;
  return true;
}
}
}
