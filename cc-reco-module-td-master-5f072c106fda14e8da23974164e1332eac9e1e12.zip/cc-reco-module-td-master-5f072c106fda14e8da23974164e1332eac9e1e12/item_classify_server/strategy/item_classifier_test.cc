#include <cstdatomic>
#include <unordered_map>
#include <vector>
#include <fstream>

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_split.h"
#include "nlp/common/nlp_util.h"

#include "reco/module/item_classify_server/global_data/global_data.h"
#include "reco/module/item_classify_server/global_data/define.h"
#include "reco/module/item_classify_server/strategy/item_lr_classifier.h"

DECLARE_string(data_dir);
DECLARE_string(nlp_dicts_root);
DECLARE_string(db_host);
DECLARE_string(db_user);
DECLARE_string(db_passwd);
DECLARE_string(schema);
namespace reco {
namespace redis {
DECLARE_string(redis_pool_ips);
}
namespace item_classify {

class ClassifierTest: public testing::Test {
 public:
  static void SetUpTestCase() {
    reco::redis::FLAGS_redis_pool_ips="10.195.157.9:6510";
    FLAGS_data_dir = "../data";
    FLAGS_nlp_dicts_root = "/serving/dict/nlp/dicts";
    FLAGS_db_host="tcp://11.251.202.229:3307";
    FLAGS_db_user="recodev";
    FLAGS_db_passwd="tkDn19DHeVZkNA";
    FLAGS_schema="reco";

    GlobalDataIns::instance().Init();
  }
};

TEST_F(ClassifierTest, TestLRClassifier) {
  ItemLRClassifier lr_classifier;
  std::vector<std::string> feas;
  std::vector<ClassifyResult> result;

  std::ifstream fin("model.txt");
  int max_line = 10000;
  std::string line;
  std::vector<std::string> flds;
  RawItem raw_item;
  std::string debug_str;
  std::unordered_map<std::string, double> cate_dict;
  while (max_line > 0 and std::getline(fin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    CHECK_GT(flds.size(), 4u);
    int n = base::ParseIntOrDie(flds[0]);

    CHECK_GT((int)flds.size(), n + 1);
    for (int j = 1; j < n + 1; ++j) {
      nlp::util::NormalizeLineInPlaceS(&(flds[j]));
    }
    std::sort(flds.begin() + 1, flds.begin() + n + 1);

    feas.clear();
    feas.push_back("");
    for (int j = 1; j < n + 1; ++j) {
      if (j > 1) feas.back().append("\t");
      feas.back().append(flds[j]);
    }

    result.clear();
    lr_classifier.Classify(raw_item, feas, 0, &result, &debug_str);
    cate_dict.clear();
    for (int i = 0; i < (int)result.size(); ++i) {
      auto it_pair = cate_dict.insert(std::make_pair(result[i].cate_name, result[i].score));
      CHECK(it_pair.second);
    }

    std::unordered_map<std::string, float> tmp_dict;
    for (int j = n + 1; j < (int)flds.size(); j += 3) {
      double weight = base::ParseDoubleOrDie(flds[j + 1]);
      tmp_dict[flds[j]] += weight;
    }

    std::unordered_map<std::string, float> cate_truth;
    for (auto it = tmp_dict.begin(); it != tmp_dict.end(); ++it) {
      if (it->second > 1e-3) cate_truth[it->first] = it->second;
    }

    if (cate_truth.size() != cate_dict.size()) {
      LOG(INFO) << "actual: " << line;
      for (auto it = cate_dict.begin(); it != cate_dict.end(); ++it) {
        LOG(INFO) << it->first << " " << it->second;
      }
    }

    ASSERT_EQ(cate_truth.size(), cate_dict.size());

    for (auto it = cate_truth.begin(); it != cate_truth.end(); ++it) {
      auto it2 = cate_dict.find(it->first);
      if (it2 == cate_dict.end()) {
        LOG(INFO) << "actual: " << line;
        for (auto it = cate_dict.begin(); it != cate_dict.end(); ++it) {
          LOG(INFO) << it->first << " " << it->second;
        }
      }
      ASSERT_NEAR(it2->second, it->second, 1e-6) << feas.back();
    }
  }
}
}
}
