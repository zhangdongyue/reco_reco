#include "reco/module/item_classify_server/strategy/item_fasttext_classifier.h"

#include <boost/shared_ptr.hpp>
#include <vector>
#include <string>
#include <utility>

#include "base/common/logging.h"
#include "base/strings/string_printf.h"

#include "reco/module/item_classify_server/fasttext/fasttextmodel.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

namespace reco {
namespace item_classify {

bool ItemFastTextClassifier::Classify(const RawItem& raw_item,
                                      const ItemClassifyFeature& fea,
                                      int feature_type,
                                      std::vector<ClassifyResult>* p_result,
                                      std::string* detail_info) {
  VLOG(1) << "start fasttext classify.";
  boost::shared_ptr<const fasttext::FastTextModel::FastTextModel> p_model =
      GlobalDataIns::instance().GetFastTextModel();
  std::string title_keywords = "";

  // add title unigram
  const nlp::term::TermContainer& title_terms = fea.basic_fea.title_terms;
  for (int i = 0; i < (int) title_terms.mix_terms().size(); ++i) {
    if (i != 0) title_keywords += " ";
    title_keywords += title_terms.mix_term_slice(raw_item.title, i).as_string();
  }

  // add keywords
  std::vector<std::pair<std::string, double>> keywords = raw_item.keywords;
  for (size_t i = 0; i < keywords.size(); i++) {
    title_keywords += (" " + keywords[i].first);
  }

  std::vector<std::pair<std::string, float>> ret;
  p_model->Predict(title_keywords, 10, &ret);
  if (ret.empty()) {
    return false;
  }

  p_result->clear();
  for (size_t i = 0; i < ret.size(); i++) {
    if (ret[i].second <= 0.501f) continue;
    ClassifyResult one_result;
    one_result.cate_id = GlobalDataIns::instance().GetCategoryIDbyName(ret[i].first.substr(9));
    one_result.cate_name = ret[i].first.substr(9);
    one_result.classify_feature_type = feature_type;
    one_result.classify_method = ClassifyMethod::kFastText;
    one_result.score = (double) ret[i].second;
    p_result->push_back(one_result);
    if (detail_info != NULL) {
      detail_info->append(base::StringPrintf("%s[%2.5f]", one_result.cate_name.c_str(), one_result.score));
    }
  }
  VLOG(1) << "finish fasttext classify.";
  return true;
}
}  // namespace item_classify
}  // namespace reco
