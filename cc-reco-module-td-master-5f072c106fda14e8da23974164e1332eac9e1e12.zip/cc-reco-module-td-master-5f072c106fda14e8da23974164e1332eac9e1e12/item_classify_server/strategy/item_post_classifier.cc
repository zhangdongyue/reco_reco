#include "reco/module/item_classify_server/strategy/item_post_classifier.h"
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <functional>
#include <vector>
#include <utility>

#include "base/strings/string_split.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

namespace reco {
namespace item_classify {
bool ItemPostClassifier::Classify(const std::vector<std::string>& flags,
                                  int item_type,
                                  std::vector<std::unordered_map<std::string, std::string> >* result) {
  std::unordered_set <int> excluded;
  std::unordered_map <int, int> post_count;

  result->clear();
  result->resize(2);

  // 对 flag 去重
  std::unordered_set<std::string> diff_flags;
  for (int i = 0; i < (int)flags.size(); ++i)
    diff_flags.insert(flags[i]);
  std::vector<std::string> new_flags(diff_flags.begin(), diff_flags.end());

  const PostDict* post_dict = NULL;
  if (item_type == 30)
    post_dict = GlobalDataIns::instance().GetVideoPostRuleList().get();
  else
    post_dict = GlobalDataIns::instance().GetPostRuleList().get();

  const std::vector<PostRule>& post_rule_list = post_dict->post_rule_list;
  const std::unordered_map<std::string, std::vector<int> >& included_index = post_dict->included_index;
  const std::unordered_map<std::string, std::vector<int> >& excluded_index = post_dict->excluded_index;

  for (int i = 0; i < (int)new_flags.size(); ++i) {
    // LOG(INFO) << "wyman's flags:" << new_flags[i];
    if (included_index.find(new_flags[i]) != included_index.end()) {
      auto it = included_index.find(new_flags[i]);
      for (int j = 0; j < (int)it->second.size(); ++j) {
        if (post_count.find(it->second[j]) != post_count.end()) {
          post_count[it->second[j]] += 1;
        } else {
          post_count[it->second[j]] = 1;
        }
      }
    }
    if (excluded_index.find(new_flags[i]) != excluded_index.end()) {
       for (size_t k = 0; k < excluded_index.find(new_flags[i])->second.size(); ++k)
        excluded.insert(excluded_index.find(new_flags[i])->second[k]);
    }
  }

  for (auto i = post_count.begin(); i != post_count.end(); ++i) {
    PostRule tmp_post_rule = post_rule_list[i->first];
    int tmp_post_count = i->second;
    if (tmp_post_rule.included_length == tmp_post_count && excluded.find(i->first) == excluded.end()) {
      result->at(tmp_post_rule.rule_type - 1).insert(std::make_pair(tmp_post_rule.model_class, tmp_post_rule.manual_class));  // NOLINT
    }
  }
  return true;
}
}
}
