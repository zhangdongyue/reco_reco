#include <utility>
#include <string>
#include <vector>
#include <unordered_set>
#include "base/strings/string_split.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/module/item_classify_server/strategy/source_category_manager.h"
#include "reco/module/item_classify_server/strategy/item_default_classifier.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

namespace reco {
namespace item_classify {

ItemDefaultClassifier::ItemDefaultClassifier() {
}

ItemDefaultClassifier::~ItemDefaultClassifier() {
}

bool ItemDefaultClassifier::Classify(const RawItem &raw_item,
                                    std::vector<ClassifyResult>* result) {
  std::string level1;
  const std::unordered_set<std::string>* default_allow_cates =
          GlobalDataIns::instance().GetDefaultAllowCate().get();

  if (raw_item.item_type != 30 && raw_item.source.find("地方新闻接口") != std::string::npos) {
    level1 = "社会";

    ClassifyResult cr;
    cr.classify_feature_type = FeatureType::kOtherFeatureType;
    cr.classify_method = ClassifyMethod::kSourceDefault;
    cr.cate_id = GlobalDataIns::instance().GetCategoryIDbyName(level1);
    cr.cate_name = level1;
    cr.score = 0.7;
    result->push_back(cr);
    return true;
  }
  const std::unordered_map<std::string, std::string>*  strict_category_dict
          = GlobalDataIns::instance().GetCateDefaultCate().get();
  auto it = strict_category_dict->find(raw_item.source);
  if (it == strict_category_dict->end()) return false;
  level1 = it->second;
  if (level1 == "地方") level1 = "社会";
  if (!level1.empty()) {
    auto it = default_allow_cates->find(level1);
    if (it == default_allow_cates->end()) return false;
    ClassifyResult cr;
    cr.classify_feature_type = FeatureType::kOtherFeatureType;
    cr.classify_method = ClassifyMethod::kSourceDefault;

    cr.cate_id = GlobalDataIns::instance().GetCategoryIDbyName(level1);
    cr.cate_name = level1;
    cr.score = 0.7;
    if (raw_item.item_type == 30) {
      cr.score = 0.9;
    }
    result->push_back(cr);
  }
  return true;
}

bool ItemDefaultClassifier::GetHistoryStat(const RawItem &raw_item,
                                          std::unordered_map<std::string, double>* stat_data) {
  const std::unordered_map<std::string, std::unordered_map<std::string, double> >* source_history_stat
          = GlobalDataIns::instance().GetSourceHistoryStat().get();

  auto it = source_history_stat->find(raw_item.source);
  if (it == source_history_stat->end()) {
    return false;
  }
  *stat_data = it->second;
  return true;
}
}
}
