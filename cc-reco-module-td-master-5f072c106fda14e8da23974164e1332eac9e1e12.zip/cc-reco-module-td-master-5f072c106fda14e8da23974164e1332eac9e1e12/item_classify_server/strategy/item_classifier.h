#pragma once

#include <boost/shared_ptr.hpp>
#include <vector>
#include <string>
#include <utility>
#include <unordered_map>
#include <unordered_set>

#include "base/file/file_path.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/global_data/define.h"

namespace reco {
namespace item_classify {

class RawItem;
class ClassifyResult;
class ItemPostClassifier;
class ItemRuleClassifier;
class ItemLRClassifier;
class ItemWDClassifier;
class ItemXGboostClassifier;
class ItemFastTextClassifier;
class ItemDefaultClassifier;
class ItemSimiClassifier;
class FeatureInfo;
class ClassifyInfo;

enum ScoreType {
  kDefault = 0,
  kSumLogistic = 1,   // 加和到一起然后取 logistic
  kLogisticSum = 2,   // 先取 logistic，然后加和到一起
  kAverage = 3,   // 取平均
};

class ItemClassifier {
 public:
  ItemClassifier();
  ~ItemClassifier();

  bool Classify(const RawItem &raw_item, ItemClassifyResult *classify_result);

  const std::vector<FeatureInfo>& feature_infos() const {
    return feature_infos_;
  }

  const std::vector<ClassifyInfo>& classify_infos() const {
    return classify_infos_;
  }
 private:
  // 对所有结果的处理，包括 合并、阈值处理也都在这里处理
  void ProcessResult(const std::string& strategy_name,
                     int score_type,
                     const std::vector<ClassifyResult>& result,
                     ClassifyInfo* classify_info);

  // 控制最后输出的逻辑全部放到这里面， 包括 post 处理、类别映射等
  void FinalResult(ItemClassifyResult *classify_result);

  void WriteFeatureDebugInfo(const RawItem &raw_item);

  void DoSubClassify(const RawItem& raw_item, const ItemClassifyFeature& fea);
 private:
  boost::shared_ptr<const std::unordered_set<std::string> > forbidden_cate_map_;
  boost::shared_ptr<const std::unordered_map<std::string, double> > cate_threshold_;
 private:
  ItemRuleClassifier* item_rule_classifier_;  // 规则分类器
  ItemLRClassifier* item_lr_classifier_;  // LR 分类器
  ItemWDClassifier* item_wd_classifier_;  // widedeep
  ItemXGboostClassifier* item_xgboost_classifier_;  // XGboost 分类器
  ItemFastTextClassifier* item_fasttext_classifier_;  // FastText 分类器
  ItemPostClassifier* item_post_classifier_;  // post 分类器
  ItemDefaultClassifier* item_defalut_classifier_;  // 和源相关的分类结果 后验及缺省
  ItemSimiClassifier* item_simi_classifier_;
  FeatureExtractor* fea_extractor_;
  ItemClassifyFeature fea_;
 private:
  std::vector<ClassifyResult> result_default_;   // 默认分类
  std::vector<ClassifyResult> result_rule_;   // 规则分类的结果
  std::vector<ClassifyResult> result_post_rule_;   // 后置规则分类的结果
  std::vector<ClassifyResult> result_keyword_title_;   // 关键字 + title + label_title
  std::vector<ClassifyResult> result_widedeep_;  // widedeep
  std::vector<ClassifyResult> result_title_;   // title + label_title
  std::vector<ClassifyResult> result_source_title_;   // source * title
  std::vector<ClassifyResult> result_topic_ngram_;   // source * title
  std::vector<ClassifyResult> result_topic_;   // topic
  std::vector<ClassifyResult> result_cate_topic_;   // cate topic
  std::vector<ClassifyResult> result_content_;   // content
  std::vector<ClassifyResult> result_high_level_;   // high_level
  std::vector<ClassifyResult> result_simi_humor_;   //

  std::vector<ClassifyResult> result_lda_xgboost_;   // lda xgboost
  std::vector<ClassifyResult> result_lda_ngram_;   // lda ngram
  std::vector<std::unordered_map<std::string, std::string> > post_result_;

  std::vector<std::pair<std::string, std::vector<ClassifyResult> > > all_result_;

  std::unordered_map<std::string, double> stat_data_;
  std::vector<std::pair<std::string, double>> high_level_features_;
  // debug usage
  std::vector<FeatureInfo> feature_infos_;
  std::vector<ClassifyInfo> classify_infos_;
};
}
}
