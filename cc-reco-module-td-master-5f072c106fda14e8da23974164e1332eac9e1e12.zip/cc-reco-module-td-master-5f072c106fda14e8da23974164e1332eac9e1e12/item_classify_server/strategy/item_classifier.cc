#include "reco/module/item_classify_server/strategy/item_classifier.h"

#include <cmath>
#include <algorithm>
#include <functional>
#include <utility>
#include <unordered_set>

#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "reco/bizc/proto/item_classify.pb.h"
#include "reco/module/item_classify_server/feature/item_classify_feature.h"
#include "reco/module/item_classify_server/strategy/item_post_classifier.h"
#include "reco/module/item_classify_server/strategy/item_default_classifier.h"
#include "reco/module/item_classify_server/strategy/item_lr_classifier.h"
#include "reco/module/item_classify_server/strategy/item_wd_classifier.h"
#include "reco/module/item_classify_server/strategy/item_rule_classifier.h"
#include "reco/module/item_classify_server/strategy/item_xgboost_classifier.h"
#include "reco/module/item_classify_server/strategy/item_fasttext_classifier.h"
#include "reco/module/item_classify_server/strategy/item_simi_classifier.h"

#include "reco/module/item_classify_server/feature/item_basic_feature.h"
#include "reco/module/item_classify_server/global_data/global_data.h"
DEFINE_bool(use_wd_text, false, "whether use w&d");

namespace reco {
namespace item_classify {

DEFINE_double(multi_threshold, 0.8, "a threshold value to cut off multi categories ");
DEFINE_bool(use_post_threshold, true, "whether use post data to cut threshold");

ItemClassifier::ItemClassifier() {
  fea_extractor_ = new FeatureExtractor();
  item_rule_classifier_ = new ItemRuleClassifier();
  item_lr_classifier_ = new ItemLRClassifier();
 //  item_wd_classifier_ = new ItemWDClassifier();
  item_post_classifier_ = new ItemPostClassifier();
  item_defalut_classifier_ = new ItemDefaultClassifier();
  item_xgboost_classifier_ = new ItemXGboostClassifier();
  item_fasttext_classifier_ = new ItemFastTextClassifier();
}

ItemClassifier::~ItemClassifier() {
  delete fea_extractor_;
  delete item_rule_classifier_;
  delete item_lr_classifier_;
  delete item_wd_classifier_;
  delete item_post_classifier_;
  delete item_defalut_classifier_;
  delete item_xgboost_classifier_;
  delete item_fasttext_classifier_;
  delete item_simi_classifier_;
}

void ItemClassifier::DoSubClassify(const RawItem& raw_item, const ItemClassifyFeature& fea) {
  result_default_.clear();
  item_defalut_classifier_->Classify(raw_item, &result_default_);


  // 1: 规则分类
  result_rule_.clear();
  if (!fea.ngram_fea.empty())
    item_rule_classifier_->Classify(raw_item,
                                    fea.basic_fea.title_terms,
                                    fea.basic_fea.title_unigrams_words,
                                    &result_rule_,
                                    true);

  classify_infos_.push_back(ClassifyInfo());
  ProcessResult("rule", ScoreType::kDefault, result_rule_, &(classify_infos_.back()));

  // 2: title + label * title +keyword 分类结果
  classify_infos_.push_back(ClassifyInfo());
  result_keyword_title_.clear();
  item_lr_classifier_->Classify(raw_item, fea_.ngram_fea, FeatureType::kLabelTitle, &result_keyword_title_,
                                classify_infos_.back().add_classify_detail());

  ProcessResult("title_lr", ScoreType::kSumLogistic, result_keyword_title_, &(classify_infos_.back()));

  // 3: fasttext, title + keywords fea
  classify_infos_.push_back(ClassifyInfo());
  result_title_.clear();
  item_fasttext_classifier_->Classify(raw_item, fea_, FeatureType::kTitle,
                                      &result_title_,
                                      classify_infos_.back().add_classify_detail());
  ProcessResult("fasttext", ScoreType::kSumLogistic, result_title_, &classify_infos_.back());

  // widedeep
  if (FLAGS_use_wd_text) {
    classify_infos_.push_back(ClassifyInfo());
    result_widedeep_.clear();
    item_wd_classifier_->Classify(raw_item, fea_.ngram_fea, FeatureType::kLabelTitle, &result_widedeep_,
                                  classify_infos_.back().add_classify_detail());
    ProcessResult("widedeep", ScoreType::kDefault, result_widedeep_, &(classify_infos_.back()));
  }

  // 4: source * title 分类
  classify_infos_.push_back(ClassifyInfo());
  result_source_title_.clear();
  item_lr_classifier_->Classify(raw_item, fea_.source_ngram_fea, FeatureType::kSourceTitle,
                                &result_source_title_, classify_infos_.back().add_classify_detail());
  ProcessResult("source_title_lr", ScoreType::kSumLogistic, result_source_title_, &classify_infos_.back());
  // topic * ngram
  classify_infos_.push_back(ClassifyInfo());
  result_topic_ngram_.clear();
  item_lr_classifier_->Classify(raw_item, fea_.topic_ngram_fea, FeatureType::kTopic,
                                &result_topic_ngram_, classify_infos_.back().add_classify_detail());
  ProcessResult("topic_ngram_lr", ScoreType::kSumLogistic, result_topic_ngram_, &classify_infos_.back());

  // lda_topic ngram
  classify_infos_.push_back(ClassifyInfo());
  result_lda_ngram_.clear();
  item_lr_classifier_->Classify(raw_item, fea_.title_lda_ngram_fea, FeatureType::kLDA,
                                &result_lda_ngram_, classify_infos_.back().add_classify_detail());
  ProcessResult("lda_ngram", ScoreType::kSumLogistic, result_lda_ngram_, &classify_infos_.back());

  // LDA + XGBoost
  classify_infos_.push_back(ClassifyInfo());
  result_lda_xgboost_.clear();
  item_xgboost_classifier_->Classify(fea.lda_topic_fea, FeatureType::kLDA, "kLDAXGBoostModelFile",
                                     &result_lda_xgboost_, classify_infos_.back().add_classify_detail());
  ProcessResult("lda_topic_xgboost", ScoreType::kDefault, result_lda_xgboost_, &(classify_infos_.back()));

  // 5: cate topic 分类结果
  classify_infos_.push_back(ClassifyInfo());
  result_cate_topic_.clear();
  item_lr_classifier_->Classify(raw_item, fea_.cate_topic_fea, FeatureType::kCateTopic, &result_cate_topic_,
                                classify_infos_.back().add_classify_detail());
  ProcessResult("cate_topic", ScoreType::kSumLogistic, result_cate_topic_, &(classify_infos_.back()));

  // 6: content 分类结果
  classify_infos_.push_back(ClassifyInfo());
  result_content_.clear();
  for (int i = 0; i < 2 && i < (int) fea_.para_ngram_fea.size(); ++i) {
    std::string* debug_str = classify_infos_.back().add_classify_detail();
    item_lr_classifier_->Classify(raw_item, fea_.para_ngram_fea[i], FeatureType::kParagraphF0 + i + 1,
                                  &result_content_, debug_str);

    if (fea_.para_ngram_fea.size() - i > 2) {
      item_lr_classifier_->Classify(raw_item, fea_.para_ngram_fea[fea_.para_ngram_fea.size() - i - 1],
                                    FeatureType::kParagraphL0 + i + 1, &result_content_,
                                    debug_str);
    }
  }
  // 0308 韦鹏 正文基础上增加标题的结果
  item_lr_classifier_->Classify(raw_item, fea_.ngram_fea, FeatureType::kLabelTitle, &result_content_,
                                classify_infos_.back().add_classify_detail());

  ProcessResult("content_lr", ScoreType::kSumLogistic, result_content_, &classify_infos_.back());
  // post rule 在最后汇总的时候会用到
  result_post_rule_.clear();
  if (!fea.ngram_fea.empty())
    item_rule_classifier_->Classify(raw_item,
                                    fea.basic_fea.title_terms,
                                    fea.basic_fea.title_unigrams_words,
                                    &result_post_rule_,
                                    false);
}

bool ItemClassifier::Classify(const RawItem& raw_item, ItemClassifyResult* classify_result) {
  classify_result->clear();
  //  1: special process
  if (raw_item.item_type == kHumor) {
    classify_result->best_result.push_back(std::make_pair(1.0, "幽默"));
    classify_result->multi_result.push_back(std::make_pair(1.0, "幽默"));
    return true;
  }
  // 幽默数据做 hash
  result_simi_humor_.clear();
  item_simi_classifier_->Classify(raw_item, &result_simi_humor_);
  if (result_simi_humor_.size() > 0) {
    classify_result->best_result.push_back(std::make_pair(1.0, "幽默"));
    classify_result->multi_result.push_back(std::make_pair(1.0, "幽默"));
    return true;
  }

  if (raw_item.item_type == kNovel) {
    classify_result->best_result.push_back(std::make_pair(1.0, "小说"));
    classify_result->multi_result.push_back(std::make_pair(1.0, "小说"));
    return true;
  }

  if (raw_item.item_type == kSpecial) {
    return true;
  }
  // get dynamic dict
  forbidden_cate_map_ = GlobalDataIns::instance().GetForbiddenCateMap();
  cate_threshold_ = GlobalDataIns::instance().GetCateThreshold();

  // 2: fea extracting and some preprocess
  fea_.clear();
  fea_extractor_->Extract(raw_item, &fea_);

  // post 的结果先拿出来， 后面逻辑会用到
  {
    std::vector<std::string> other_flags;

    const std::vector<std::pair<std::string, std::string> >& flags = fea_.basic_fea.flags;

    for (size_t i = 0; i < flags.size(); ++i) {
      other_flags.push_back(flags[i].first);
    }
    std::sort(other_flags.begin(), other_flags.end());
    post_result_.clear();
    item_post_classifier_->Classify(other_flags, raw_item.item_type, &post_result_);
  }


  // 后验信息
  stat_data_.clear();
  item_defalut_classifier_->GetHistoryStat(raw_item, &stat_data_);

  // 3: all sub classifier
  all_result_.clear();
  classify_infos_.clear();
  feature_infos_.clear();
  high_level_features_.clear();

  DoSubClassify(raw_item, fea_);

  // 4: High level 分类结果
  classify_infos_.push_back(ClassifyInfo());
  result_high_level_.clear();
  std::string cate_name;

  const std::unordered_map<std::string, std::vector<std::pair<std::string, double> > >* high_level_model
          = GlobalDataIns::instance().GetHighLevelModel().get();
  if (high_level_features_.size() > 1) {
    for (size_t j = 0; j < high_level_features_.size(); ++j) {
      const std::string& key = high_level_features_[j].first;
      auto it = high_level_model->find(key);
      if (it == high_level_model->end()) continue;
      const std::vector<std::pair<std::string, double >>& scores = it->second;
      for (size_t i = 0; i < scores.size(); ++i) {
        ClassifyResult cr;
        cr.cate_id = GlobalDataIns::instance().GetCategoryIDbyName(scores[i].first);
        cr.cate_name = scores[i].first;
        cr.classify_feature_type = FeatureType::kOtherFeatureType;
        cr.classify_method = ClassifyMethod::kLinear;
        cr.score = scores[i].second * high_level_features_[j].second;
        if (cr.score < 0.6) continue;
        result_high_level_.push_back(cr);
      }
    }
    ProcessResult("high_level_linear", ScoreType::kSumLogistic, result_high_level_,
                  &(classify_infos_.back()));  // NOLINT
  }

  if (raw_item.is_debug) {
    WriteFeatureDebugInfo(raw_item);
  }
  // [3] 吐出最后的结果
  FinalResult(classify_result);
  return true;
}

inline void WriteFlagFeatureDebugInfo(const std::vector<std::string>& feas,
                                      const std::string& feature_name,
                                      FeatureInfo* debug_info) {
  debug_info->set_feature_list_name(feature_name);
  debug_info->clear_feature_name();
  debug_info->clear_feature_value();
  if (!feas.empty()) {
    for (int i = 0; i < (int) feas.size(); ++i) {
      debug_info->add_feature_name(feas.at(i));
      debug_info->add_feature_value(1.0);
    }
  }
}

void ItemClassifier::WriteFeatureDebugInfo(const RawItem& raw_item) {
  const ItemBasicFeature& item_basic_feature = fea_.basic_fea;
  feature_infos_.clear();
  // title 分词
  feature_infos_.push_back(FeatureInfo());
  feature_infos_.back().set_feature_list_name("Unigrams");
  for (auto it = item_basic_feature.title_unigrams_words.begin();
       it != item_basic_feature.title_unigrams_words.end();
       ++it) {
    feature_infos_.back().add_feature_name(*it);
    feature_infos_.back().add_feature_value(1);
  }

  // keywords
  if (raw_item.keywords.size() > 0) {
    feature_infos_.push_back(FeatureInfo());
    feature_infos_.back().set_feature_list_name("Keywords");
    for (int i = 0; i < (int) raw_item.keywords.size(); ++i) {
      feature_infos_.back().add_feature_name(raw_item.keywords[i].first);
      feature_infos_.back().add_feature_value(raw_item.keywords[i].second);
    }
  }

  // tags
  if (raw_item.tags.size() > 0) {
    feature_infos_.push_back(FeatureInfo());
    feature_infos_.back().set_feature_list_name("Tags");
    for (int i = 0; i < (int) raw_item.tags.size(); ++i) {
      feature_infos_.back().add_feature_name(raw_item.tags[i]);
      feature_infos_.back().add_feature_value(1);
    }
  }

  // high level
  if (!high_level_features_.empty()) {
    feature_infos_.push_back(FeatureInfo());
    feature_infos_.back().set_feature_list_name("HighLevel");
    feature_infos_.back().clear_feature_name();
    feature_infos_.back().clear_feature_value();
    for (int i = 0; i < (int) high_level_features_.size(); ++i) {
      feature_infos_.back().add_feature_name(high_level_features_[i].first);
      feature_infos_.back().add_feature_value(high_level_features_[i].second);
    }
  }

  // flags
  feature_infos_.push_back(FeatureInfo());
  feature_infos_.back().set_feature_list_name("Flags");
  feature_infos_.back().clear_feature_name();
  feature_infos_.back().clear_feature_value();
  for (int i = 0; i < (int) item_basic_feature.flags.size(); ++i) {
    feature_infos_.back().add_feature_name(StringPrintf("%s[%s]",
                                                        item_basic_feature.flags[i].second.c_str(),
                                                        item_basic_feature.flags[i].first.c_str()));
    feature_infos_.back().add_feature_value(1.0);
  }

  // 特征
  // feature_infos_.push_back(FeatureInfo());
  // WriteFlagFeatureDebugInfo(fea_.ngram_fea, "Keywords", &(feature_infos_.back()));

  // cate_topic
  feature_infos_.push_back(FeatureInfo());
  WriteFlagFeatureDebugInfo(fea_.cate_topic_fea, "Cate_topic", &(feature_infos_.back()));
}

inline double GetPostThreshold(const std::string& cate_name, double threshold, double post_data) {
  if (!FLAGS_use_post_threshold) {
    return threshold;
  }
  if (cate_name == "美女写真" || cate_name == "摄影") {
    if (post_data < 15) {
      return 1.01;
    }
  }
  double add_threshold = 0.0;
  if (post_data > 70) {
    add_threshold = (post_data - 70) / 30;
    return threshold - add_threshold * 0.1;
  } else if (post_data < 1) {
    add_threshold = (1 - post_data);
    return threshold + (0.85 - threshold) * add_threshold;
  } else {
    return threshold;
  }
}

void ItemClassifier::ProcessResult(const std::string& strategy_name,
                                   int score_type,
                                   const std::vector<ClassifyResult>& result,
                                   ClassifyInfo* classify_info) {
  if (result.size() == 0u) return;

  classify_info->set_method_name(strategy_name);
  classify_info->clear_cate_name();
  classify_info->clear_cate_score();

  std::unordered_map<std::string, double> cate_score;
  std::string cate_name = "";
  double score = 0;

  CHECK_EQ(post_result_.size(), 2u);
  const std::unordered_map<std::string, std::string>& post_result_l1 = post_result_[0];
  const std::unordered_map<std::string, std::string>& post_result_l2 = post_result_[1];

  std::vector<std::string> tokens;
  for (int i = 0; i < (int) result.size(); ++i) {
    // LOG(INFO) << "reuslt: " << result[i].cate_name << " " << result[i].score;
    cate_name = result[i].cate_name;
    // post 规则上场 改名称分数不改
    tokens.clear();
    base::SplitString(cate_name, ",", &tokens);
    if (tokens.size() == 1u) {
      auto it = post_result_l1.find(cate_name);
      if (it != post_result_l1.end()) {
        cate_name = it->second;
      }
    }
    if (tokens.size() == 2u) {
      auto it = post_result_l2.find(cate_name);
      if (it != post_result_l2.end()) {
        cate_name = it->second;
      } else {
        it = post_result_l2.find(tokens[0]);
        if (it != post_result_l2.end()) {
          cate_name = it->second;
        }
      }
    }

    score = result[i].score;
    if (score_type == ScoreType::kLogisticSum) {
      score = 1 / (1 + std::exp(0 - score));
    }
    // 检查是不是 forbidden 里面的类别
    auto it_forbidden = forbidden_cate_map_->find(cate_name);
    if (it_forbidden != forbidden_cate_map_->end()) continue;

    auto it = cate_score.find(cate_name);
    if (it == cate_score.end()) {
      cate_score.insert(std::make_pair(cate_name, score));
    } else {
      it->second += score;
    }
  }

  auto mapIterator = cate_threshold_->find(strategy_name);
  double strategy_threshold = 0.5;
  if (mapIterator != cate_threshold_->end()) {
    strategy_threshold = mapIterator->second;
  }
  // 过滤
  std::vector<ClassifyResult> aggregate_result;
  for (auto it = cate_score.begin(); it != cate_score.end(); ++it) {
    cate_name = it->first;
    score = it->second;

    if (score_type == ScoreType::kSumLogistic) {
      score = 1 / (1 + std::exp(0 - score));
    }
    if (score_type == ScoreType::kAverage) {
      score = score / result.size();
    }
    classify_info->add_cate_name(cate_name);
    classify_info->add_cate_score(score);
    // high level 特征扔进去
    auto const* high_level_model = GlobalDataIns::instance().GetHighLevelModel().get();
    if (high_level_model->find(strategy_name + "|" + cate_name) != high_level_model->end()) {
      high_level_features_.push_back(std::make_pair(strategy_name + "|" + cate_name, score));
    }
    // 利用后验数据修正阈值
    double post_stat_data = 50;
    if (stat_data_.size() > 0) {
      auto it_stat_data = stat_data_.find(cate_name);
      if (it_stat_data != stat_data_.end()) {
        post_stat_data = it_stat_data->second;
      } else {
        post_stat_data = 0.0;
      }
    }
    // 方法的最低阈值
    auto it_threshold = cate_threshold_->find(strategy_name + "|" + cate_name);
    if (it_threshold != cate_threshold_->end()
        && it_threshold->second > score) {
      continue;
    }
    if (cate_name.find(",") == std::string::npos
        && score < GetPostThreshold(cate_name, strategy_threshold, post_stat_data)) {
      continue;
    }
    if (cate_name.find(",") != std::string::npos
        && score < strategy_threshold)
      continue;
    // 类别的阈值
    auto it_cate = cate_threshold_->find(cate_name);
    if (it_cate != cate_threshold_->end()
        && it_cate->second > score) {
      continue;
    }
    ClassifyResult cr;
    cr.cate_id = GlobalDataIns::instance().GetCategoryIDbyName(cate_name);
    cr.cate_name = cate_name;
    cr.classify_feature_type = FeatureType::kOtherFeatureType;
    cr.classify_method = ClassifyMethod::kAggregate;
    cr.score = score;
    aggregate_result.push_back(cr);
  }
  std::sort(aggregate_result.begin(), aggregate_result.end(), std::greater<ClassifyResult>());
  all_result_.push_back(std::make_pair(strategy_name, aggregate_result));
}

void ItemClassifier::FinalResult(ItemClassifyResult* classify_result) {
  const std::unordered_map<std::string, std::vector<std::string> >* cate_constraint =
          GlobalDataIns::instance().GetCateConstraint().get();
  const std::unordered_map<std::string, std::string>* cate_map = GlobalDataIns::instance().GetCateMap().get();
  const std::unordered_map<std::string, double>* tag_list = GlobalDataIns::instance().GetTagList().get();
  const std::unordered_map<std::string, double>* post_tag_list = GlobalDataIns::instance().GetPostTagList().get(); // NOLINT
  const std::unordered_map<std::string, std::string>* cate_multi_map = GlobalDataIns::instance().GetMultiCateAppendMap().get(); // NOLINT
  const std::unordered_map<std::string, std::string>* cate_append_map = GlobalDataIns::instance().GetCateAppendMap().get(); // NOLINT

  std::vector<std::pair<double, std::string> > multi_result_candianates;

  std::vector<std::pair<double, std::string> > result_candianates;
  std::vector<std::pair<double, std::string> > tag_candianates;  // tag 候选
  std::vector<std::pair<double, std::string> > post_tag_candianates;  // post tag 候选
  std::unordered_map<std::string, double> classified_cate;
  // 记录某个类别下第一个子类 方便后面产生最优的结果
  std::unordered_map<std::string, std::pair<std::string, double> > parent_cate_map;

  std::string cate_name;
  double score;
  std::unordered_map<std::string, int> forbidden_cate;
  std::vector<std::string> tokens;
  int level1_count = 0;
  // 先把结果放进去，去掉重复的
  for (int i = 0; i < (int) all_result_.size(); ++i) {
    std::vector<ClassifyResult>& classify_result_list = all_result_[i].second;
    if (classify_result_list.size() == 0) continue;

    for (int j = 0; j < (int) classify_result_list.size(); ++j) {
      const ClassifyResult& classify_result = classify_result_list[j];
      cate_name = classify_result.cate_name;
      score = classify_result.score;
      auto it_constraint = cate_constraint->find(cate_name);
      if (it_constraint != cate_constraint->end()) {
        for (size_t k = 0; k < it_constraint->second.size(); ++k) {
          forbidden_cate.insert(std::make_pair(it_constraint->second[k], 1));
        }
      }

      auto it = cate_map->find(cate_name);
      if (it != cate_map->end()) {
        // 类别体系变动
        bool ori_class_is_level2 = (cate_name.find(",") != std::string::npos);
        bool map_class_is_level2 = (it->second.find(",") != std::string::npos);
        if (!ori_class_is_level2) {
          // 原来是一级类
          if (map_class_is_level2) {
            // 1->2 // 1->2
            tokens.clear();
            base::SplitString(it->second, ",", &tokens);
            ClassifyResult cr = classify_result_list[j];
            cr.cate_name = tokens[0];
            classify_result_list.push_back(cr);

            cate_name = it->second;
          } else {
            // 1->1 直接改名字
            cate_name = it->second;
          }
        } else {
          if (map_class_is_level2) {
            // 2->2  直接改名字
            cate_name = it->second;
          } else {
            // 2->1 不能改
            LOG(ERROR) << cate_name << "can not be changed into" << it->second;
          }
        }
      }

      auto it_result = classified_cate.find(cate_name);
      if (it_result != classified_cate.end()) continue;
      classified_cate.insert(std::make_pair(cate_name, score));
      auto it_tag = tag_list->find(cate_name);
      if (it_tag != tag_list->end()) {
        // tag 候选
        tag_candianates.push_back(std::make_pair(score, cate_name));
        if (it_tag->second < 1) {
          result_candianates.push_back(std::make_pair(score, cate_name));
        }
        continue;
      }
      it_tag = post_tag_list->find(cate_name);
      if (it_tag != post_tag_list->end()) {
        // post tag 候选
        post_tag_candianates.push_back(std::make_pair(score, cate_name));
        if (it_tag->second < 1) {
          result_candianates.push_back(std::make_pair(score, cate_name));
        }
        continue;
      }
      result_candianates.push_back(std::make_pair(score, cate_name));
      if (cate_name.find(",") == std::string::npos) level1_count++;
    }
  }
  if (level1_count == 0) {
    // 默认分类的逻辑前置到这里， 可以出来二级类别
    if (result_default_.size() > 0) {
      for (int j = 0; j < (int) result_default_.size(); ++j) {
        result_candianates.push_back(std::make_pair(result_default_[j].score, result_default_[j].cate_name));
      }
    }
  }
  // 对于所有的二级分类 实现一个扩展
  for (size_t l = 0; l < result_candianates.size(); ++l) {
    const std::string& cate_name = result_candianates[l].second;

    auto it = cate_append_map->find(cate_name);
    if ( it == cate_append_map->end()) continue;
    // 一级分类必须必须存在才能扩展
    size_t pos = cate_name.find(",");
    if (pos !=std::string::npos && classified_cate.find(cate_name.substr(0, pos)) == classified_cate.end()) continue;

    const std::string& append_cate_name = it->second;
    if (classified_cate.find(append_cate_name) != classified_cate.end()) continue;
    if (tag_list->find(append_cate_name) == tag_list->end()) {
      result_candianates.push_back(std::make_pair(result_candianates[l].first, append_cate_name));
    } else {
      tag_candianates.push_back(std::make_pair(result_candianates[l].first, append_cate_name));
    }
  }

  // 对于所有的语义标签 实现一个扩展
  for (size_t l = 0; l < tag_candianates.size(); ++l) {
    const std::string& cate_name = tag_candianates[l].second;

    auto it = cate_append_map->find(cate_name);
    if ( it == cate_append_map->end()) continue;
    // 一级分类必须必须存在才能扩展
    size_t pos = cate_name.find(",");
    if (pos !=std::string::npos && classified_cate.find(cate_name.substr(0, pos)) == classified_cate.end()) continue;

    const std::string& append_cate_name = it->second;
    if (classified_cate.find(append_cate_name) != classified_cate.end()) continue;
    if (tag_list->find(append_cate_name) == tag_list->end()) {
      result_candianates.push_back(std::make_pair(result_candianates[l].first, append_cate_name));
    } else {
      tag_candianates.push_back(std::make_pair(result_candianates[l].first, append_cate_name));
    }
  }

  // 过滤结果 同时出来多分类结果
  std::string parent_cate_name;
  for (int k = 0; k < (int) result_candianates.size(); ++k) {
    bool filter_flag = false;   // 标记是否要过滤
    cate_name = result_candianates[k].second;
    if (forbidden_cate.find(cate_name) != forbidden_cate.end()) continue;
    score = result_candianates[k].first;
    // 过滤逻辑 1  上一级分类不存在的过滤掉
    parent_cate_name.clear();
    tokens.clear();
    base::SplitString(cate_name, ",", &tokens);
    if (tokens.size() == 1u) {
      multi_result_candianates.push_back(std::make_pair(score, cate_name));
      parent_cate_map.insert(std::make_pair("root", std::make_pair(cate_name, score)));
      continue;
    }
    // 从第一级开始依次如果没有就 break
    for (int l = 0; l < (int) tokens.size() - 1; ++l) {
      if (!parent_cate_name.size() == 0) {
        parent_cate_name += ",";
      }
      parent_cate_name += tokens[l];
      if (classified_cate.find(parent_cate_name) == classified_cate.end()) {
        filter_flag = true;
        break;
      }
    }
    if (!filter_flag) {
      parent_cate_map.insert(std::make_pair(parent_cate_name, std::make_pair(cate_name, score)));
      // 二级的分数乘上一级的分数
      multi_result_candianates.push_back(std::make_pair(
              score * classified_cate[parent_cate_name], cate_name));
    }
  }
  // 筛选最优结果
  std::string parent = "root";
  while (true) {
    auto it = parent_cate_map.find(parent);
    if (it == parent_cate_map.end()) break;
    classify_result->best_result.push_back(std::make_pair(it->second.second, it->second.first));
    parent = it->second.first;
  }
  if (classify_result->best_result.size() > 0) {
    // 一级多分类的时候 后面分类的分数不能低于第一个一定比例  eg. 0.8
    const double best_score_level1 = classify_result->best_result.at(0).first;
    std::unordered_map<std::string, int> valid_level1;
    std::unordered_set<std::string> classified_cates;
    for (size_t i = 0; i < multi_result_candianates.size(); ++i) {
      if (multi_result_candianates[i].second.find(",") == std::string::npos) {
        if (multi_result_candianates[i].first > best_score_level1 * FLAGS_multi_threshold) {
          classify_result->multi_result.push_back(multi_result_candianates[i]);
          valid_level1.insert(std::make_pair(multi_result_candianates[i].second, 1));
          classified_cates.insert(multi_result_candianates[i].second);
        }
      }
    }
    int level2_count = 0;
    std::unordered_set<std::string> multi_append_results;
    for (size_t i = 0; i < multi_result_candianates.size(); ++i) {
      size_t pos = multi_result_candianates[i].second.find(",");
      if (pos != std::string::npos) {
        if (valid_level1.find(multi_result_candianates[i].second.substr(0, pos)) != valid_level1.end()) {
          classify_result->multi_result.push_back(multi_result_candianates[i]);
          classified_cates.insert(multi_result_candianates[i].second);
          level2_count++;
          // 个别二级类别做多分类扩展
          auto it_multi = cate_multi_map->find(multi_result_candianates[i].second);
          if (it_multi != cate_multi_map->end()) {
            const std::string& new_cate_name = it_multi->second;

            multi_append_results.insert(new_cate_name);

            pos = new_cate_name.find(",");
            if (pos != std::string::npos) {
              // 映射一个二级类别 对应一级和二级都要添加
              multi_append_results.insert(new_cate_name.substr(0, pos));
            }
          }
        }
      }
    }
    for (auto it = multi_append_results.begin(); it != multi_append_results.end(); ++it) {
      if (classified_cates.find(it->data()) != classified_cates.end()) continue;

      classified_cates.insert(it->data());
      classify_result->multi_result.push_back(std::make_pair(0.7, it->data()));
    }
    if (level2_count == 0 && result_post_rule_.size() > 0) {
      // 弱规则补充二级分类
      for (size_t i = 0; i < result_post_rule_.size(); ++i) {
        const std::string& cate_name = result_post_rule_[i].cate_name;
        if (tag_list->find(cate_name) != tag_list->end()) continue;
        if (forbidden_cate_map_->find(cate_name) != forbidden_cate_map_->end()) continue;
        tokens.clear();
        base::SplitString(cate_name, ",", &tokens);
        if (classified_cate.find(tokens[0]) == classified_cate.end()) continue;
        classify_result->multi_result.push_back(std::make_pair(result_post_rule_[i].score
                                                               * classified_cate[tokens[0]],
                                                               cate_name));
        classify_result->best_result.push_back(std::make_pair(result_post_rule_[i].score
                                                              * classified_cate[tokens[0]],
                                                              cate_name));
        break; // 只补充一个结果
      }
    }
    int tag_count = 0;
    for (size_t j = 0; j < tag_candianates.size(); ++j) {
      size_t pos = tag_candianates[j].second.find(",");
      if (pos != std::string::npos) {
        if (forbidden_cate.find(tag_candianates[j].second) != forbidden_cate.end()) continue;
        if (valid_level1.find(tag_candianates[j].second.substr(0, pos)) != valid_level1.end()) {
          classify_result->tag_result.push_back(tag_candianates[j]);
          tag_count++;
        }
      }
    }
    if (tag_count == 0 && result_post_rule_.size() > 0) {
      // 弱规则语义标签
      for (size_t i = 0; i < result_post_rule_.size(); ++i) {
        const std::string& cate_name = result_post_rule_[i].cate_name;
        if (tag_list->find(cate_name) == tag_list->end()) continue;
        if (forbidden_cate_map_->find(cate_name) != forbidden_cate_map_->end()) continue;
        tokens.clear();
        base::SplitString(cate_name, ",", &tokens);
        if (classified_cate.find(tokens[0]) == classified_cate.end()) continue;
        classify_result->tag_result.push_back(std::make_pair(result_post_rule_[i].score, cate_name));
      }
    }
    for (size_t j = 0; j < post_tag_candianates.size(); ++j) {
      if (forbidden_cate.find(post_tag_candianates[j].second) != forbidden_cate.end()) continue;
      size_t pos = post_tag_candianates[j].second.find(",");
      if (pos != std::string::npos) {
        if (valid_level1.find(post_tag_candianates[j].second.substr(0, pos)) != valid_level1.end()) {
          classify_result->post_tag_result.push_back(post_tag_candianates[j]);
        }
      } else {
        classify_result->post_tag_result.push_back(post_tag_candianates[j]);
      }
    }
    return;
  }
}
}
}
