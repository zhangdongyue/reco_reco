#pragma once

#include <unordered_map>
#include <string>
#include <vector>
#include "serving_base/expiry_map/expiry_map.h"

namespace reco {
namespace item_classify {
class RawItem;
class ClassifyResult;
class SourceCategoryManager;
class ItemDefaultClassifier {
 public:
  ItemDefaultClassifier();
  ~ItemDefaultClassifier();

  bool Classify(const RawItem &raw_item,
                std::vector<ClassifyResult>* result);

  bool GetHistoryStat(const RawItem &raw_item,
                      std::unordered_map<std::string, double>* stat_data);
};
};
}
