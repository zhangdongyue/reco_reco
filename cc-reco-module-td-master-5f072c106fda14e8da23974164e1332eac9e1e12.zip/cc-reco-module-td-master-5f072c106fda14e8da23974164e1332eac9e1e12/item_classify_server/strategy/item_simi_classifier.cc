#include <vector>
#include <unordered_set>
#include <reco/base/common/singleton.h>
#include "base/common/basic_types.h"
#include "reco/module/item_classify_server/strategy/item_simi_classifier.h"
#include "reco/module/item_classify_server/global_data/global_data.h"
#include "reco/module/item_classify_server/global_data/define.h"

#include "item_simi_classifier.h"
#include "reco/module/item_classify_server/common/util.h"
#include "reco/module/item_classify_server/common/SimHashIndex.h"

DEFINE_double(para_sim_ratio, 0.4, "");
DEFINE_double(picture_sim_ratio, 0.4, "");

namespace reco {
namespace item_classify {

bool ItemSimiClassifier::Classify(const RawItem& raw_item, std::vector<ClassifyResult>* result) {
  const simhash_index* index = GlobalDataIns::instance().GetHumorHashList().get();
  const std::unordered_set<std::string>* black_list = GlobalDataIns::instance().GetHumorHashBlackList().get(); // NOLINT

  int met_para = SimHashIndex::FindSimiliar(index, raw_item.para_simhash, 7, black_list);
  int met_picture =  SimHashIndex::FindSimiliar(index, raw_item.picture_simhash, 7, black_list);

  if (met_para <= 2 && met_picture <= 2) return false; // 匹配两个以内的不出结果 防止误伤
  LOG(INFO) << raw_item.item_id << "" << met_para <<" "<< raw_item.para_simhash.size() << " " << met_picture<< " " << raw_item.picture_simhash.size();

  if (met_para > raw_item.para_simhash.size() * FLAGS_para_sim_ratio ||
      met_picture > raw_item.picture_simhash.size() * FLAGS_picture_sim_ratio) {
    ClassifyResult cr;
    cr.cate_id = GlobalDataIns::instance().GetCategoryIDbyName("幽默");
    cr.cate_name = "幽默";
    cr.classify_feature_type = FeatureType::kOtherFeatureType;
    cr.classify_method = ClassifyMethod::kSimiResult;
    cr.score = 1.0;
    result->push_back(cr);
    return true;
  }
  return false;
}
}
}