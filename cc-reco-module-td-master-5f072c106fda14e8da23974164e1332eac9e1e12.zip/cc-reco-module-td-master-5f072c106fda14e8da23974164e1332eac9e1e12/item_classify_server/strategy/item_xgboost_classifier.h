#pragma once
#include <vector>
#include <string>
#include <utility>

#include "base/common/basic_types.h"
#include "reco/module/item_classify_server/global_data/define.h"
namespace reco {
namespace item_classify {

// XGboost 分类器
class ItemXGboostClassifier {
 public:
  // 函数功能: gbdt 分类
  // 输入参数:
  //  feas:
  //  p_model: xgboost 模型指针
  //  feature_type: 特征类型
  //  model_name: 模型名
  //  p_result: 分类结果指针
  //  detail_info: 一些处理信息
  //  tree_num: 用于预测的树的棵树，默认使用所有的树预测
  //            当 tree_num == 0 或者 tree_num > p_model 的树时，使用所有的树预测
  bool Classify(const std::vector<std::pair<uint32, float> >& feas,
                int feature_type,
                std::string model_name,
                std::vector<ClassifyResult>* p_result,
                std::string* detail_info,
                uint32 tree_num = 0);
  static void TransferNumericFeature(const std::vector<float>& input_fea,
                                     std::vector<std::pair<uint32, float> >* fea) {
    fea->clear();
    for (uint32 i = 0; i < input_fea.size(); i++) {
      if (input_fea[i] < 0.00001f) continue;
      fea->push_back(std::make_pair(i, input_fea[i]));
    }
  }
};  // class ItemXgboostClassifier

}  // namespace item_classify
}  // namespace reco
