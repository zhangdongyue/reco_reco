#pragma once

#include <string>
#include <vector>
#include "nlp/common/term_container.h"

namespace reco {
namespace item_classify {
struct RawItem;
class ClassifyResult;

class ItemRuleClassifier {
 public:
  void Classify(const RawItem& raw_item,
                const nlp::term::TermContainer& title_terms,
                const std::vector<std::string>& terms,
                std::vector<ClassifyResult>* result,
                bool is_pre);

  void Classify(const RawItem& raw_item,
                std::vector<ClassifyResult>* result);

 private:
  void ClassifyPairSemantic(const RawItem& raw_item, std::vector<ClassifyResult>* result);
};
}
}
