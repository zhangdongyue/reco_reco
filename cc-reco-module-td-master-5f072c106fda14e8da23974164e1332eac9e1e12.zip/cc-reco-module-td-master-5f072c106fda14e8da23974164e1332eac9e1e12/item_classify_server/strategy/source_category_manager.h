#pragma once
#include <boost/shared_ptr.hpp>
#include <map>
#include <unordered_map>
#include <vector>
#include <string>
#include "base/common/basic_types.h"
#include "base/hash_function/term.h"
#include "reco/module/item_classify_server/global_data/source_category_dict.h"

namespace reco {
namespace item_classify {
// thread unsafe
class SourceCategoryManager {
 public:
  SourceCategoryManager(): level1_candidates_(NULL), level2_candidates_(NULL) {}
  ~SourceCategoryManager() {}
  // called SetSource before judge valid category or get strict category
  // return false if source none exist, and not equal to "NULL"
  bool SetSource(const std::string& source);

  bool IsValidLevel1(const std::string& level1) const {
    if (level1_candidates_ == NULL ||
        level1_candidates_->empty() ||
        level1_candidates_->begin()->second.first != kNormal ||
        level1_candidates_->find(level1) != level1_candidates_->end()) {
      return true;
    }
    return false;
  }

  int GetLevel1Status() const {
    if (level1_candidates_ == NULL ||
        level1_candidates_->empty() ||
        level1_candidates_->size() != 1u ||
        level1_candidates_->begin()->second.first == kNormal) return 0;
    if (level1_candidates_->begin()->second.first == kOpen) {
      return 2;
    }
    CHECK(level1_candidates_->begin()->second.first == kStrict);
    CHECK_EQ(level1_candidates_->size(), 1u);
    return 1;
  }

  bool GetStrictLevel1(std::string* strick_category) const {
    int status = GetLevel1Status();
    if (status == 0) {
      return false;
    }
    *strick_category = level1_candidates_->begin()->first;
    return true;
  }

  bool SetLevel1(const std::string& source, const std::string& level1);

  void SetLevel1Candidates(const std::map<std::string, std::pair<int, std::map<std::string, int>* >>& level1_candidates) { // NOLINT
    level1_candidates_ = &level1_candidates;
  }
  void SetLevel2Candidates(const std::map<std::string, int>& level2_candidates) {
    level2_candidates_ = &level2_candidates;
  }

  bool HasCategoryInCandidate(const std::string& category) const {
    if (level1_candidates_ == NULL ||
        level1_candidates_->empty() ||
        level1_candidates_->find(category) == level1_candidates_->end()) {
      return false;
    }
    return true;
  }
  // level2 methods, level2 without parents
  bool IsValidLevel2(const std::string& level2) const {
    if (level2_candidates_ == NULL ||
        level2_candidates_->empty() ||
        level2_candidates_->begin()->second != kNormal ||
        level2_candidates_->find(level2) != level2_candidates_->end()) return true;
    return false;
  }

  int GetLevel2Status() const {
    // TODO(xielang): 增加允许多个一级类，每一个一级下面限制一个二级
    if (level2_candidates_ == NULL ||
        level2_candidates_->empty() ||
        level2_candidates_->size() != 1 ||
        level2_candidates_->begin()->second == kNormal) return 0;
    if (level2_candidates_->begin()->second == kOpen) {
      return 2;
    }
    return 1;
  }

  bool GetStrictLevel2(std::string* strick_category) const {
    int status = GetLevel2Status();
    if (status == 0) {
      return false;
    }
    *strick_category = level2_candidates_->begin()->first;
    return true;
  }

  bool GetDefaultCategory(const std::string& source, std::string* level1, std::string* level2) const;

  bool IsSkip(const std::string& source) const {
    if (source_dict_ == NULL) {
      LOG(ERROR) << "plz set source at first";
      return false;
    }

    uint64 sign = base::CalcTermSign(source.c_str(), source.size());
    auto it = source_dict_->find(sign);
    if (it == source_dict_->end()) {
      LOG(INFO) << "cannot find source in dict: " << source;
      return false;
    }
    if (sources_->at(it->second).second == 30 &&
        (category_matrix_->at(it->second) == NULL || category_matrix_->at(it->second)->empty())) {
      LOG(INFO) << "un config video source: " << source;
      return true;
    }
    return false;
  }

  static const char* kDummySource;
 private:
  const std::unordered_map<uint64, int>* source_dict_;
  const std::vector<std::pair<std::string, int> >* sources_;
  const std::vector<std::map<std::string, std::pair<int, std::map<std::string, int>* >>*>* category_matrix_;
  boost::shared_ptr<const SourceCategoryDict> source_category_dict_;
  const std::map<std::string, std::pair<int, std::map<std::string, int>* >>* level1_candidates_;
  const std::map<std::string, int>* level2_candidates_;
};
}
}
