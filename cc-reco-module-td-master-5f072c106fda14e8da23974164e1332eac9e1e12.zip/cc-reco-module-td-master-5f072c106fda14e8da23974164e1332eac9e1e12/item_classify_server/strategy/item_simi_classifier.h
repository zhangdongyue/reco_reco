#pragma once

#include <unordered_map>
#include <string>
#include <vector>

namespace reco {
namespace item_classify {
class RawItem;
class ClassifyResult;

class ItemSimiClassifier {
 public:
  bool Classify(const RawItem &raw_item,
                std::vector<ClassifyResult>* result);
};
}
}
