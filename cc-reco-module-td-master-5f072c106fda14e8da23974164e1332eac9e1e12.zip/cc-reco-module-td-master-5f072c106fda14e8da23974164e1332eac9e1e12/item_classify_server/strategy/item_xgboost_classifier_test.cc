#include <vector>
#include <map>
#include <utility>
#include <iostream>
#include <unordered_map>

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_split.h"
#include "nlp/common/nlp_util.h"

#include "base/file/file_path.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/module/item_classify_server/strategy/item_xgboost_classifier.h"
#include "reco/module/item_classify_server/global_data/define.h"
#include "reco/module/item_classify_server/global_data/global_data.h"

DECLARE_string(data_dir);
DECLARE_string(nlp_dicts_root);
DECLARE_string(db_host);
DECLARE_string(db_user);
DECLARE_string(db_passwd);
DECLARE_string(schema);

namespace reco {
namespace redis {
DECLARE_string(redis_pool_ips);
}
namespace item_classify {

class ClassifierTest: public testing::Test {
 public:
  static void SetUpTestCase() {
    reco::redis::FLAGS_redis_pool_ips="10.195.157.9:6510";
    FLAGS_data_dir = "../data";
    FLAGS_nlp_dicts_root = "/serving/dict/nlp/dicts";
    FLAGS_db_host="tcp://11.251.202.229:3307";
    FLAGS_db_user="recodev";
    FLAGS_db_passwd="tkDn19DHeVZkNA";
    FLAGS_schema="reco";

    GlobalDataIns::instance().Init();
  }
};

TEST_F(ClassifierTest, TestClassify) {
  ItemXGboostClassifier classifier;
  FeatureType fea_type = FeatureType::kTopic;
  std::vector<ClassifyResult> classify_result;
  std::string detail_info;
  std::vector<std::pair<unsigned int, float> > sample;
  // 主题特征
  if (fea_type == FeatureType::kTopic) {
    sample.push_back(std::make_pair<unsigned int, float>(83, .158812));
    sample.push_back(std::make_pair<unsigned int, float>(94, .2846741974));
    sample.push_back(std::make_pair<unsigned int, float>(136, .130393));
    sample.push_back(std::make_pair<unsigned int, float>(174, .279862));
    sample.push_back(std::make_pair<unsigned int, float>(196, .146259));
  }
  if (!classifier.Classify(sample, fea_type, "kL1TopicGBDTModelFile", &classify_result, &detail_info, 300)) {
    std::cout << "classify fail!" << std::endl;
  }
  ASSERT_STREQ(classify_result[0].cate_name.c_str(), "社会");
  ASSERT_EQ(classify_result[0].cate_id, 151);
  ASSERT_TRUE(((classify_result[0].score - 0.805338) < 0.00001f));
}
}  // namespace item_classify
}  // namespace reco
