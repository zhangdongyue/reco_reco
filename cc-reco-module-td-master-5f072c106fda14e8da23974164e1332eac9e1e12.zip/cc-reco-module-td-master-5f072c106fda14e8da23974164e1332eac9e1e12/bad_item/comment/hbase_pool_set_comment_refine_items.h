#pragma once

#include <string>
#include "base/common/base.h"
#include "base/testing/gtest_prod.h"

namespace reco {
// NOTE: thread safe
class HBasePoolSetCommentRefineItems {
 public:
  explicit HBasePoolSetCommentRefineItems(const std::string& hbase_table_name);
  ~HBasePoolSetCommentRefineItems();

  bool SetCommentRefineItem(uint64 item_id, const std::string& value);

 private:
  static const int kRetryTimes = 3;
  static const int kReconnectTimes = 10;

  std::string table_name_;
};
}  // namespace reco

