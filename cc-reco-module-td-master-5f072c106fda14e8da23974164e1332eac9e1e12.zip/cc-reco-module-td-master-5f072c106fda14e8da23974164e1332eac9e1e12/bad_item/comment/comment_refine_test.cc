#include "reco/module/bad_item/comment/hbase_pool_get_comment_refine_items.h"
#include "reco/module/bad_item/comment/hbase_pool_set_comment_refine_items.h"
#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "base/common/base.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

DEFINE_string(hbase_comment_refine_table, "tb_comment_refine_item_test", "hbase table");

namespace reco {
namespace hbase {
DECLARE_string(hbase_thrift_ips);
}

TEST(SourceStatTest, SourceStatGetSet) {
  reco::hbase::HBasePoolIns::instance().Init();
  reco::HBasePoolSetCommentRefineItems set_comment_refine_item(FLAGS_hbase_comment_refine_table);
  struct {
    uint64 item_id;
    std::string records;
  } cases[] = {
    {1000001ul, "0,1#0,2"},
    {1000002ul, "1,0#2,0\t2,0#2,1\t2,1#2,2"},
    {1000003ul, "1,0#1,1\t1,1#2,1\t2,1#2,0"}
  };

  int num = ARRAYSIZE_UNSAFE(cases);

  for (int i = 0; i < num; ++i) {
    ASSERT_TRUE(set_comment_refine_item.SetCommentRefineItem(cases[i].item_id, cases[i].records));
  }

  reco::HBasePoolGetCommentRefineItems get_comment_refine_item(FLAGS_hbase_comment_refine_table);
  std::string result;
  for (int i = 0; i < num; ++i) {
    ASSERT_TRUE(get_comment_refine_item.GetCommentRefineItem(cases[i].item_id, &result));
    ASSERT_EQ(result, cases[i].records);
  }
}
}
