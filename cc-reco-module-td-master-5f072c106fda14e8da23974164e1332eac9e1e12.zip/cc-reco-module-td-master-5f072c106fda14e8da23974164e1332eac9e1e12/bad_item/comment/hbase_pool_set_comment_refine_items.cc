#include "reco/module/bad_item/comment/hbase_pool_set_comment_refine_items.h"

#include "base/common/sleep.h"
#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
HBasePoolSetCommentRefineItems::HBasePoolSetCommentRefineItems(const std::string& hbase_table_name) {
  table_name_ = hbase_table_name;
}

HBasePoolSetCommentRefineItems::~HBasePoolSetCommentRefineItems() {
}

bool HBasePoolSetCommentRefineItems::SetCommentRefineItem(uint64 item_id, const std::string& value) {
  std::string row_key = base::StringPrintf("%lu", item_id);
  int retry = 0;
  bool succ = false;
  while (retry++ < kRetryTimes) {
    reco::hbase::HBaseAutoCli cli(10);
    if (!cli.Get()) {
      continue;
    }
    if (cli.Get()->Insert(table_name_, row_key, "data", "refine_record", value)) {
      succ = true;
      break;
    } else {
      LOG(ERROR) << "set item to hbase failed!";
      continue;
    }
  }
  return succ;
}
}  // namespace reco
