#include "reco/module/bad_item/comment/comment_processor.h"

#include <fstream>
#include <cmath>
#include "nlp/common/nlp_util.h"
#include "base/file/file_path.h"
#include "base/hash_function/term.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/utf_char_iterator.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"
#include "extend/web_client/web_client.h"

DEFINE_string(comment_data_dir, "../data", "");

char kUselessSimble[] = {' ', '\t', '\n', '\v', '\r', '\f', '!', '?', '.', '~', '*', '#', '@'};
const std::string kNumberStr = "NUMBER_TERM";
const std::string kTimeStr = "TIME_TERM";

std::string CommentProcessor::dict_path = "comment_rules.txt";
std::string CommentProcessor::duanzi_path = "duanzi.txt";
std::string CommentProcessor::dirty_model_file = "model.dirty";
std::string CommentProcessor::bluffing_model_file = "model.bluffing";
std::string CommentProcessor::stopwords_file = "stopwords.txt";

std::unordered_map<std::string, std::pair<std::string, int>> CommentProcessor::type_dict;
dawgdic::Dictionary CommentProcessor::comment_rules;
std::unordered_set<uint64> CommentProcessor::duanzi;
std::map<uint64, double> CommentProcessor::model_dirty;
std::map<uint64, double> CommentProcessor::model_bluffing;
std::set<std::string> CommentProcessor::stopwords;

CommentProcessor::CommentProcessor() {
  json_parser_ = new Json::Reader();
  segmenter_ = new nlp::segment::Segmenter();
  pos_tagger_ = new nlp::postag::PosTagger();
  ner_ = new nlp::ner::Ner();
}

CommentProcessor::~CommentProcessor() {
  delete json_parser_;
  json_parser_ = NULL;
  delete segmenter_;
  segmenter_ = NULL;
  delete pos_tagger_;
  pos_tagger_ = NULL;
  delete ner_;
  ner_ = NULL;
}

void CommentProcessor::Initial() {
  base::FilePath dir(FLAGS_comment_data_dir);
  // load duazi
  {
    std::ifstream fin(dir.Append(duanzi_path).value());
    CHECK(fin.is_open());
    std::string line;
    while (std::getline(fin, line)) {
      uint64 sign = base::CalcTermSign(line.c_str(), line.size());
      duanzi.insert(sign);
    }
    fin.close();
  }
  // load dict
  {
    std::ifstream fin(dir.Append(dict_path).value());
    std::string line;
    std::vector<std::string> tokens;
    std::vector<std::string> words;
    std::map<std::string, int> cache;
    std::string ngram;
    while (std::getline(fin, line)) {
      tokens.clear();
      base::SplitString(line, "\t", &tokens);
      CHECK_EQ((int)tokens.size(), 3);
      std::string type = tokens[1];
      int level = 1;
      base::StringToInt(tokens[2], &level);
      words.clear();
      base::SplitString(tokens[0], "|", &words);
      for (int i = 0; i < (int)words.size(); ++i) {
        nlp::util::NormalizeLineInPlaceS(&words[i]);
      }
      std::sort(words.begin(), words.end());
      if (words.size() == 1) {
        if (words.front().size() < 1) {
          LOG(ERROR) << "empty word in line: " << line;
        }
        auto it_pair = cache.insert(std::make_pair(words.front(), 2));
        type_dict.insert(std::make_pair(words.front(), std::make_pair(type, level)));
        continue;
      } else {
        for (int i = 0; i < (int)words.size(); ++i) {
          if (words[i].size() < 1) {
            LOG(ERROR) << "empty word in line: " << line;
          }
          auto it_pair = cache.insert(std::make_pair(words[i], 1));
        }
      }
      ngram.clear();
      base::FastJoinStrings(words, "", &ngram);
      auto it_pair = cache.insert(std::make_pair(ngram, 2));
      type_dict.insert(std::make_pair(ngram, std::make_pair(type, level)));
    }
    fin.close();
    dawgdic::DawgBuilder builder;
    for (auto it = cache.begin(); it != cache.end(); ++it) {
      CHECK(builder.Insert(it->first.c_str(), it->second));
    }
    dawgdic::Dawg dawg;
    CHECK(builder.Finish(&dawg));
    dawgdic::DictionaryBuilder::Build(dawg, &comment_rules);
  }
  // load models
  {
    std::ifstream fin(dir.Append(dirty_model_file).value());
    CHECK(fin.is_open());
    std::string line;
    std::vector<std::string> tokens;
    while (std::getline(fin, line)) {
      tokens.clear();
      base::SplitString(line, "\t", &tokens);
      uint64 sign = 0;
      base::StringToUint64(tokens[0], &sign);
      double weight = 0;
      base::StringToDouble(tokens[1], &weight);
      model_dirty.insert(std::make_pair(sign, weight));
    }
    fin.close();
    std::ifstream fin1(dir.Append(bluffing_model_file).value());
    CHECK(fin1.is_open());
    while (std::getline(fin1, line)) {
      tokens.clear();
      base::SplitString(line, "\t", &tokens);
      uint64 sign = 0;
      base::StringToUint64(tokens[0], &sign);
      double weight = 0;
      base::StringToDouble(tokens[1], &weight);
      model_bluffing.insert(std::make_pair(sign, weight));
    }
    fin1.close();
  }
  // load stopwords
  {
    std::ifstream fin(dir.Append(stopwords_file).value());
    CHECK(fin.is_open());
    std::string line;
    std::string norm_line;
    while (std::getline(fin, line)) {
      nlp::util::NormalizeLineCopy(line, &norm_line);
      stopwords.insert(norm_line);
    }
    fin.close();
  }
}

inline void generate_url_with_parent_id(uint64 item_id, std::string* url) {
  *url = base::StringPrintf("http://10.195.157.49:9200/index_comment_v3/type_comment/_search?q=article_id:%lu&size=%d", item_id, 5000);  // NOLINT
}

inline void generate_url_with_item_id(uint64 item_id, std::string* url) {
  *url = base::StringPrintf("http://10.195.157.49:9200/index_comment_v3/type_comment/_search?q=original_article_id:%lu&size=%d", item_id, 5000);  // NOLINT
}

inline void generate_url_with_comment_id(uint64 comment_id, std::string* url) {
  *url = base::StringPrintf("http://10.195.157.49:9200/index_comment/type_comment/_search?q=id:%lu", comment_id);  // NOLINT
}

inline bool IsFilteredByPostag(const nlp::term::TermInfo& info) {
  if (info.is_postag(nlp::term::kWhiteSpace)
      || info.is_postag(nlp::term::kPunctuation)
      || info.is_postag(nlp::term::kPreposition)
      || info.is_postag(nlp::term::kAuxiliary)
      || info.is_postag(nlp::term::kExclamation)
      || info.is_postag(nlp::term::kQuantity)
      || info.is_postag(nlp::term::kPronoun)
      || info.is_postag(nlp::term::kConjunction)) {
    return true;
  }
  return false;
}

bool CommentProcessor::IsValidUnigram(const base::Slice& unigram) {
  if (stopwords.find(unigram.as_string()) != stopwords.end()) {
    return false;
  }
  int len1 = 0;
  if (!base::GetUTF8CharNum(unigram, &len1) || len1 < 2) return false;
  return true;
}

bool CommentProcessor::IsValidBigram(const base::Slice& term1, const base::Slice& term2) {
  if (!IsValidUnigram(term1) && !IsValidUnigram(term2)) return false;
  int len1 = 0;
  int len2 = 0;
  if (!base::GetUTF8CharNum(term1, &len1) && !base::GetUTF8CharNum(term2, &len2)) return false;
  if (len1 < 2 && len2 < 2) return false;
  return true;
}

void CommentProcessor::GenerateUnigram(const base::Slice& norm_text,
                                       const nlp::term::TermContainer& container,
                                       std::vector<base::Slice>* mix_terms) {
  for (int i = 0; i < (int) container.mix_terms().size(); ++i) {
    const nlp::term::TermInfo& term_info = container.mix_term_info(i);
    const base::Slice& term_slice = container.mix_term_slice(norm_text, i);
    if (IsFilteredByPostag(term_info)) continue;
    if (term_info.is_postag(nlp::term::kNumber)) {
      int char_num = 0;
      if (base::GetUTF8CharNum(term_slice, &char_num) && (int)term_slice.size() == char_num) {
        mix_terms->push_back(kNumberStr);
      } else {
        mix_terms->push_back(term_slice);
      }
    } else {
      mix_terms->push_back(term_slice);
    }
  }
}

void CommentProcessor::GenerateNgrams(const std::string& line, std::set<std::string>* ngrams) {
  int char_num = 0;
  nlp::term::TermContainer term_container;
  if (!base::GetUTF8CharNum(line, &char_num) || char_num == 0) return;
  CHECK(segmenter_->SegmentT(line, &term_container));
  CHECK(pos_tagger_->PosTagT(line, &term_container));
  CHECK(ner_->DetectEntityT(line, &term_container));
  nlp::util::ConstructMixTerms(line, false, &term_container);
  std::vector<base::Slice> mix_unigrams;
  GenerateUnigram(line, term_container, &mix_unigrams);
  for (int i = 0; i < (int)mix_unigrams.size(); ++i) {
    uint32 skip_num = 3;
    std::string term = "";
    if (!IsValidUnigram(mix_unigrams[i])) continue;
    if (mix_unigrams[i].size() == 0) continue;
    for (size_t j = i + 1; j < mix_unigrams.size() && j < i + skip_num; ++j) {
      if (mix_unigrams[j].size() == 0) continue;
      if (!IsValidBigram(mix_unigrams[i], mix_unigrams[j])) continue;
      term.clear();
      if (mix_unigrams[i] < mix_unigrams[j]) {
        term += mix_unigrams[i].as_string();
        term += "#";
        term += mix_unigrams[j].as_string();
      } else {
        term += mix_unigrams[j].as_string();
        term += "#";
        term += mix_unigrams[i].as_string();
      }
      ngrams->insert(term);
      for (size_t k = j + 1; k < mix_unigrams.size() && k < j + skip_num; ++k) {
        term.clear();
        if (mix_unigrams[k].size() == 0) continue;
        std::string tri_term;
        if (mix_unigrams[i] < mix_unigrams[j] && mix_unigrams[i] < mix_unigrams[k]) {
          if (mix_unigrams[j] < mix_unigrams[k]) {
            term += mix_unigrams[i].as_string();
            term += "#";
            term += mix_unigrams[j].as_string();
            term += "#";
            term += mix_unigrams[k].as_string();
          } else {
            term += mix_unigrams[i].as_string();
            term += "#";
            term += mix_unigrams[k].as_string();
            term += "#";
            term += mix_unigrams[j].as_string();
          }
        }
        if (mix_unigrams[j] < mix_unigrams[i] && mix_unigrams[j] < mix_unigrams[k]) {
          if (mix_unigrams[i] < mix_unigrams[k]) {
            term += mix_unigrams[j].as_string();
            term += "#";
            term += mix_unigrams[i].as_string();
            term += "#";
            term += mix_unigrams[k].as_string();
          } else {
            term += mix_unigrams[j].as_string();
            term += "#";
            term += mix_unigrams[k].as_string();
            term += "#";
            term += mix_unigrams[i].as_string();
          }
        }
        if (mix_unigrams[k] < mix_unigrams[j] && mix_unigrams[k] < mix_unigrams[i]) {
          if (mix_unigrams[i] < mix_unigrams[j]) {
            term += mix_unigrams[k].as_string();
            term += "#";
            term += mix_unigrams[i].as_string();
            term += "#";
            term += mix_unigrams[j].as_string();
          } else {
            term += mix_unigrams[k].as_string();
            term += "#";
            term += mix_unigrams[j].as_string();
            term += "#";
            term += mix_unigrams[i].as_string();
          }
        }
        ngrams->insert(term);
      }
    }
  }
}

bool CommentProcessor::JudgeCommentByRule(const std::string& comment,
                                          std::set<std::string>* ngrams,
                                          std::string* type) {
  std::vector<base::Slice> matches;
  std::vector<int> values;
  std::vector<std::pair<base::Slice, int >> sorted_matches;
  std::vector<std::pair<int, std::string>> results;
  int c = nlp::util::ForwardMaxMatch(comment_rules, comment, &matches, &values);
  if (c == 0) return false;
  for (int i = 0; i < (int)matches.size(); ++i) {
    sorted_matches.push_back(std::make_pair(matches[i], values[i]));
    if (matches[i] == "小编") {
      sorted_matches.push_back(std::make_pair("小便", values[i]));
    }
    if (matches[i] == "小便") {
      sorted_matches.push_back(std::make_pair("小编", values[i]));
    }
  }
  // all matches are candidate unigram
  std::sort(sorted_matches.begin(), sorted_matches.end());
  for (int i = 0; i < (int)sorted_matches.size(); ++i) {
    if (sorted_matches[i].second == 2) {
      auto it = type_dict.find(sorted_matches[i].first.as_string());
      CHECK(it != type_dict.end());
      std::string current_type = it->second.first;
      int level = it->second.second;
      results.push_back(std::make_pair(level, current_type));
      ngrams->insert(sorted_matches[i].first.as_string());
      continue;
    }
    if (sorted_matches[i].second != 1) continue;
    dawgdic::BaseType node_pos = 0;
    CHECK(comment_rules.Follow(sorted_matches[i].first.data(), sorted_matches[i].first.size(), &node_pos));
    int result = comment_rules.value(node_pos);
    dawgdic::BaseType node_pos1 = node_pos;
    for (int j = i + 1; j < (int)sorted_matches.size(); ++j) {
      node_pos = node_pos1;
      if (!comment_rules.Follow(sorted_matches[j].first.data(), sorted_matches[j].first.size(), &node_pos)) continue; // NOLINT
      if (comment_rules.has_value(node_pos)) {
        result = comment_rules.value(node_pos);
        if (result == 2) {
          std::string key;
          key.append(sorted_matches[i].first.data(), sorted_matches[i].first.size());
          key.append(sorted_matches[j].first.data(), sorted_matches[j].first.size());
          auto it = type_dict.find(key);
          if (it != type_dict.end()) {
            std::string current_type = it->second.first;
            int level = it->second.second;
            results.push_back(std::make_pair(level, current_type));
          }
          ngrams->insert(key);
          continue;
        }
      }
      if (result != 1) continue;
      dawgdic::BaseType node_pos2 = node_pos;
      for (int k = j + 1; k < (int)sorted_matches.size(); ++k) {
        node_pos = node_pos2;
        if (!comment_rules.Follow(sorted_matches[k].first.data(), sorted_matches[k].first.size(), &node_pos)) continue; // NOLINT
        if (comment_rules.has_value(node_pos)) {
          result = comment_rules.value(node_pos);
          if (result == 2) {
            std::string key;
            key.append(sorted_matches[i].first.data(), sorted_matches[i].first.size());
            key.append(sorted_matches[j].first.data(), sorted_matches[j].first.size());
            key.append(sorted_matches[k].first.data(), sorted_matches[k].first.size());
            auto it = type_dict.find(key);
            if (it != type_dict.end()) {
              std::string current_type = it->second.first;
              int level = it->second.second;
              results.push_back(std::make_pair(level, current_type));
            }
            ngrams->insert(key);
            continue;
          }
        }
      }
    }
  }
  if (results.empty()) return false;
  std::sort(results.begin(), results.end(), std::greater<std::pair<int, std::string >>());
  *type = results[0].second;
  return true;
}

bool CommentProcessor::JudgeCommentByModel(uint64 item_id, int up_cnt,
                                          const std::string& comment,
                                          const std::set<std::string>& ngrams_rule,
                                          std::vector<float>* result) {
  if (result->empty()) result->resize(8, 0);
  bool low = false;
  std::set<std::string> comment_ngrams;
  GenerateNgrams(comment, &comment_ngrams);
  float weight_dirty = 0;
  float weight_bluffing = 0;
  for (auto it = comment_ngrams.begin(); it != comment_ngrams.end(); ++it) {
    std::string current = *it;
    uint64 sign = base::CalcTermSign(current.data(), current.size());
    if (model_dirty.find(sign) != model_dirty.end()) {
      VLOG(1) << comment << "hit dirty:\t" << current << "\t" << model_dirty.find(sign)->second;
      weight_dirty += model_dirty.find(sign)->second;
    }
    if (model_bluffing.find(sign) != model_bluffing.end()) {
      VLOG(1) << comment << "hit bluffing:\t" << current << "\t" << model_bluffing.find(sign)->second;
      weight_bluffing += model_bluffing.find(sign)->second;
    }
  }

  for (auto it = ngrams_rule.begin(); it != ngrams_rule.end(); ++it) {
    std::string current = *it;
    uint64 sign = base::CalcTermSign(current.data(), current.size());
    if (model_dirty.find(sign) != model_dirty.end()) {
      VLOG(1) << comment << "hit dirty:\t" << current << "\t" << model_dirty.find(sign)->second;
      weight_dirty += model_dirty.find(sign)->second;
    }
    if (model_bluffing.find(sign) != model_bluffing.end()) {
      VLOG(1) << comment << "hit bluffing:\t" << current << "\t" << model_bluffing.find(sign)->second;
      weight_bluffing += model_bluffing.find(sign)->second;
    }
  }

  double score_dirty = 1 / (1 + std::exp(0 - weight_dirty));
  double score_bluffing = 1 / (1 + std::exp(0 - weight_bluffing));

  if (score_dirty > 0.7) {
    low = true;
    LOG(INFO) << item_id << "\t" << comment << "\t低俗\t" << score_dirty;
    result->at(4) += 1;
  }
  if (score_bluffing > 0.6) {
    low = true;
    LOG(INFO) << item_id << "\t" << comment << "\t标题党\t" << score_bluffing;
    result->at(6) += 1;
    if (up_cnt > 10 && up_cnt < 50) {
      result->at(6) += 1;
    } else if (up_cnt >= 50) {
      result->at(6) += 2;
    }
  }
  return low;
}

void CommentProcessor::GetOriComments(uint64 parent_id, uint64 item_id,
                                      const std::string& cate,
                                      std::vector<float>* scores, int* comment_num) {
  extend::WebClient::Request request;
  extend::WebClient::Response response;
  Json::Value json_value;
  std::string url;
  generate_url_with_parent_id(parent_id, &url);
  request.url = url;
  extend::WebClient* web_client_ = new extend::WebClient();
  web_client_->Init();
  web_client_->AddTask(&request, &response, NULL);
  web_client_->WaitForAll();
  delete web_client_;
  web_client_ = NULL;
  if (!json_parser_->parse(response.http_body.c_str(),
                           response.http_body.c_str() + response.http_body.size(),
                           json_value, false)) {
    LOG(ERROR) << "error parse: " << response.http_body;
    return;
  }
  const Json::Value& data = json_value["hits"]["hits"];
  std::string nospace_comment;
  std::set<std::string> current;
  for (int i = 0; i < (int)data.size(); ++i) {
    current.clear();
    std::string content = data[i]["_source"]["content"].asString();
    nlp::util::NormalizeLineInPlaceS(&content);
    base::RemoveChars(content, kUselessSimble, &nospace_comment);
    uint64 sign = base::CalcTermSign(nospace_comment.c_str(), nospace_comment.size());
    *comment_num = *comment_num + 1;
    if (duanzi.find(sign) != duanzi.end()) continue;
    std::string type;
    std::set<std::string> ngrams_rule;
    JudgeCommentByRule(nospace_comment, &ngrams_rule, &type);
    if (!cate.empty()) {
      for (auto it = ngrams_rule.begin(); it != ngrams_rule.end(); ++it) {
        current.insert(base::StringPrintf("%s#%s", it->c_str(), cate.c_str()));
      }
    }
    int up_cnt = data[i]["_source"]["up_cnt"].asInt();
    if (!JudgeCommentByModel(item_id, up_cnt, nospace_comment, current, scores)) {
      current.clear();
      for (auto it = ngrams_rule.begin(); it != ngrams_rule.end(); ++it) {
        current.insert(*it);
      }
      JudgeCommentByModel(item_id, up_cnt, nospace_comment, current, scores);
    }
    if (type == "过时新闻" || type == "不专业") {
      LOG(INFO) << item_id << "\t" << nospace_comment << "\t" << type;
      scores->at(6) += 0.5;
    }
  }
}

// for offline tasks
void CommentProcessor::GetAllComments(uint64 item_id, int getter_type, const std::string& cate,
                                      std::vector<std::pair<std::string, std::string> >* results) {
  results->clear();
  extend::WebClient::Request request;
  extend::WebClient::Response response;
  Json::Value json_value;
  std::string url;
  generate_url_with_parent_id(item_id, &url);
  request.url = url;
  extend::WebClient* web_client_ = new extend::WebClient();
  web_client_->Init();
  web_client_->AddTask(&request, &response, NULL);
  web_client_->WaitForAll();
  delete web_client_;
  web_client_ = NULL;
  if (!json_parser_->parse(response.http_body.c_str(),
                           response.http_body.c_str() + response.http_body.size(),
                           json_value, false)) {
    LOG(ERROR) << "error parse: " << response.http_body;
    return;
  }
  const Json::Value& data = json_value["hits"]["hits"];
  std::string nospace_comment;
  std::set<std::string> ngrams_rule;
  std::vector<float> scores;
  std::set<std::string> current;
  for (int i = 0; i < (int)data.size(); ++i) {
    scores.clear();
    current.clear();
    ngrams_rule.clear();
    std::string content = data[i]["_source"]["content"].asString();
    int up_cnt = data[i]["_source"]["up_cnt"].asInt();
    int reply_cnt = data[i]["_source"]["reply_cnt"].asInt();
    nlp::util::NormalizeLineInPlaceS(&content);
    base::RemoveChars(content, kUselessSimble, &nospace_comment);
    uint64 sign = base::CalcTermSign(nospace_comment.c_str(), nospace_comment.size());
    if (duanzi.find(sign) != duanzi.end()) continue;
    std::string type;
    JudgeCommentByRule(nospace_comment, &ngrams_rule, &type);
    std::string comment_info = base::StringPrintf("%s\t%d\t%d", nospace_comment.c_str(), up_cnt, reply_cnt);
    bool is_bad = false;
    if (!cate.empty()) {
      for (auto it = ngrams_rule.begin(); it != ngrams_rule.end(); ++it) {
        current.insert(base::StringPrintf("%s#%s", it->c_str(), cate.c_str()));
      }
    }
    if (JudgeCommentByModel(item_id, up_cnt, nospace_comment, current, &scores)) {
      if (scores[4] != 0) {
        is_bad = true;
        results->push_back(std::make_pair(comment_info, "低俗"));
      }
      if (scores[6] != 0) {
        is_bad = true;
        results->push_back(std::make_pair(comment_info, "标题党"));
      }
    } else {
      current.clear();
      for (auto it = ngrams_rule.begin(); it != ngrams_rule.end(); ++it) {
        current.insert(*it);
      }
      JudgeCommentByModel(item_id, up_cnt, nospace_comment, current, &scores);
      if (scores[4] != 0) {
        is_bad = true;
        results->push_back(std::make_pair(comment_info, "低俗"));
      }
      if (scores[6] != 0) {
        is_bad = true;
        results->push_back(std::make_pair(comment_info, "标题党"));
      }
    }
    if (!type.empty() && type != "低俗" && type != "标题党") {
      is_bad = true;
      LOG(INFO) << nospace_comment << "\t" << type;
      results->push_back(std::make_pair(comment_info, type));
    }
    if (!is_bad && getter_type == 0)  {
      results->push_back(std::make_pair(comment_info, "正常"));
    }
  }
}

bool CommentProcessor::ProcessComment(uint64 comment_id, const std::string& cate,
                                      uint64* item_id, std::vector<float>* result) {
  result->clear();
  result->resize(8, 0);
  extend::WebClient::Request request;
  extend::WebClient::Response response;
  Json::Value json_value;
  std::string url;
  generate_url_with_comment_id(comment_id, &url);
  request.url = url;
  extend::WebClient* web_client_ = new extend::WebClient();
  web_client_->Init();
  web_client_->AddTask(&request, &response, NULL);
  web_client_->WaitForAll();
  delete web_client_;
  web_client_ = NULL;
  if (!json_parser_->parse(response.http_body.c_str(),
                           response.http_body.c_str() + response.http_body.size(),
                           json_value, false)) {
    LOG(ERROR) << "error parse: " << response.http_body << "\trequest:\t" << request.url;
    return false;
  }
  const Json::Value& data = json_value["hits"]["hits"];
  if (data.size() == 0) return false;
  base::StringToUint64(data[0]["_source"]["original_article_id"].asString(), item_id);
  std::string content = data[0]["_source"]["content"].asString();
  std::string nospace_comment;
  nlp::util::NormalizeLineInPlaceS(&content);
  base::RemoveChars(content, kUselessSimble, &nospace_comment);
  std::set<std::string> ngrams_rule;
  std::string type;
  JudgeCommentByRule(nospace_comment, &ngrams_rule, &type);
  std::set<std::string> current;
  if (!cate.empty()) {
    for (auto it = ngrams_rule.begin(); it != ngrams_rule.end(); ++it) {
      current.insert(base::StringPrintf("%s#%s", it->c_str(), cate.c_str()));
    }
  }
  int up_cnt = data[0]["_source"]["up_cnt"].asInt();
  if (!JudgeCommentByModel(*item_id, up_cnt, nospace_comment, current, result)) {
    current.clear();
    for (auto it = ngrams_rule.begin(); it != ngrams_rule.end(); ++it) {
      current.insert(*it);
    }
    JudgeCommentByModel(*item_id, up_cnt, nospace_comment, current, result);
  }
  if (type == "过时新闻" || type == "不专业") {
    LOG(INFO) << *item_id << "\t" << comment_id << "\t"
              << nospace_comment << "\t" << type;
    result->at(6) += 0.5;
  }
  return true;
}

// for offline tasks
bool CommentProcessor::ProcessComment(uint64 comment_id, std::string* current, std::string* result) {
  extend::WebClient::Request request;
  extend::WebClient::Response response;
  Json::Value json_value;
  std::string url;
  generate_url_with_comment_id(comment_id, &url);
  request.url = url;
  extend::WebClient* web_client_ = new extend::WebClient();
  web_client_->Init();
  web_client_->AddTask(&request, &response, NULL);
  web_client_->WaitForAll();
  delete web_client_;
  web_client_ = NULL;
  if (!json_parser_->parse(response.http_body.c_str(),
                           response.http_body.c_str() + response.http_body.size(),
                           json_value, false)) {
    LOG(ERROR) << "error parse: " << response.http_body << "\trequest:\t" << request.url;
    return false;
  }
  const Json::Value& data = json_value["hits"]["hits"];
  if (data.size() == 0) return false;
  std::string content = data[0]["_source"]["content"].asString();
  nlp::util::NormalizeLineInPlaceS(&content);
  base::RemoveChars(content, kUselessSimble, current);
  std::set<std::string> ngrams_rule;
  JudgeCommentByRule(*current, &ngrams_rule, result);
  return true;
}
