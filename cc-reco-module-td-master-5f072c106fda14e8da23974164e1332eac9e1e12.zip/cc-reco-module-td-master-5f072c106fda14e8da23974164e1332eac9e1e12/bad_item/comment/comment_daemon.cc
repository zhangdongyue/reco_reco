#include <unordered_map>
#include <unordered_set>
#include <fstream>

#include "base/hash_function/term.h"
#include "base/common/sleep.h"
#include "base/strings/utf_char_iterator.h"
#include "base/thread/rw_mutex.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/thread/blocking_queue.h"
#include "base/container/lru_cache.h"
#include "serving_base/utility/signal.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/base/kafka_c/api_cc/producer.h"
#include "reco/bizc/proto/elk_item_msg.pb.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/item_service/define.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "net/counter/export.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/bizc/proto/sim_item.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "serving_base/utility/time_helper.h"
#include "reco/module/bad_item/comment/comment_processor.h"
#include "reco/module/bad_item/comment/hbase_pool_get_comment_refine_items.h"
#include "reco/module/bad_item/comment/hbase_pool_set_comment_refine_items.h"

DEFINE_string(kafka_brokers, "10.181.169.190:9092,10.181.169.191:9092,10.181.169.192:9092,10.181.169.193:9092,10.181.169.194:9092", "kafka queue servers");  // NOLINT
DEFINE_string(comment_topic, "online_comment_review", "comment topic name");
DEFINE_string(bad_item_modify_topic, "bad_item_modify", "bad item modify topic name");

DEFINE_int32(partition_num, 10, "partition num");
DEFINE_int32(partition_num_bluffing_modify, 10, "partition num");
DEFINE_bool(is_mirror, true, "");
DEFINE_string(group_id, "0", "group id");
DEFINE_string(group_id_bad_item_modify, "1", "group id");

DEFINE_string(hbase_table, "tb_reco_item", "hbase table for reco item");
DEFINE_string(hbase_comment_refine_table_test, "tb_comment_refine_item_test", "hbase table for record--test");
DEFINE_string(hbase_comment_refine_table, "tb_comment_refine_item", "hbase table for reco record");

DEFINE_int32(thread_num, 16, "thread for updating feedback log");
DEFINE_bool(update, false, "");
DEFINE_bool(standalone, false, "");

DEFINE_int64_counter(bad_item, failed_get_comment_num, 0, "failed get comment num");
DEFINE_int64_counter(bad_item, succ_update_num, 0, "the num of update request sending to itemserver");
DEFINE_int64_counter(bad_item, failed_update_num, 0, "the num of item failed to push to kafka");
DEFINE_int64_counter(bad_item, comment_remain_num, 0, "the num of item in the queue");

DEFINE_string(input, "input.txt", "");
DEFINE_string(output, "output.txt", "");

DEFINE_string(data_dir, "../data", "");
DEFINE_string(start_time, "2017-01-12", "");
DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_string(sim_server_ip, "11.251.177.97", "sim server ip");
DEFINE_int32(sim_server_port, 20066, "server port");
DEFINE_double(threshold_bluffing, 10, "");
DEFINE_double(threshold_dirty, 15, "");

const int feature_legnth = 8;

struct ItemQualityScore {
  void Initial() {
    comment_num = 0;
    in_index = true;
    attr_scores.resize(feature_legnth, 0);
    scores.resize(feature_legnth, 0);
  }
  uint64 item_id;
  int comment_num;
  bool in_index;
  std::string title;
  std::vector<int> attr_scores;
  std::vector<float> scores;
};

struct ItemInfo {
  void Initial() {
    media = "";
    level1 = "未分类";
    level2 = "未分类";
    source = "";
    type = 0;
    producer = "";
  }
  uint64 item_id;
  int type;
  std::string title;
  std::string producer;
  std::string media;
  std::string level1;
  std::string level2;
  std::string source;
  reco::ContentAttr content_attr;
};

reco::ContentAttr::ContentAttrLevel attr_values[] = { reco::ContentAttr::kSureNo,
  reco::ContentAttr::kSuspect, reco::ContentAttr::kSureYes };

serving_base::ExpiryMap<uint64, ItemQualityScore>* item_qualities = new serving_base::ExpiryMap<uint64, ItemQualityScore>(3600 * 24); // NOLINT

serving_base::ExpiryMap<std::string, int>* processed_items = new serving_base::ExpiryMap<std::string, int>(60 * 30); // NOLINT

std::unordered_set<std::string> good_medias;
thread::RWMutex good_medias_mutex;

std::unordered_set<std::string> changeable_cates;
thread::RWMutex changeable_cates_mutex;

std::unordered_map<std::string, float> category_weights;
thread::RWMutex category_weights_mutex;

std::unordered_set<std::string> remit_sources;

std::string good_media_file = "good_media.txt";
std::string cate_weight_file = "cate_weights.txt";
std::string remit_source_file = "remit_sources.txt";

inline bool is_op_news(const std::string& producer) {
  if (producer != "uc" && producer != "tudou") return true;
  return false;
}

void Initial() {
  base::FilePath data_path(FLAGS_data_dir);
  {
    std::ifstream fin1(data_path.Append(good_media_file).ToString());
    CHECK(fin1.is_open());
    std::string line;
    while (std::getline(fin1, line)) {
      good_medias.insert(line);
    }
    fin1.close();
  }
  {
    std::ifstream fin2(data_path.Append(cate_weight_file).ToString());
    CHECK(fin2.is_open());
    std::string line;
    std::vector<std::string> tokens;
    while (std::getline(fin2, line)) {
      tokens.clear();
      base::SplitString(line, "\t", &tokens);
      CHECK_EQ((int)tokens.size(), 2);
      double weight;
      base::StringToDouble(tokens[1], &weight);
      category_weights.insert(std::make_pair(tokens[0], weight));
    }
    fin2.close();
  }
  {
    std::ifstream fin3(data_path.Append(remit_source_file).ToString());
    std::string line;
    while (std::getline(fin3, line)) {
      remit_sources.insert(line);
    }
    fin3.close();
  }
  changeable_cates.insert("娱乐");
  changeable_cates.insert("体育");
  changeable_cates.insert("科技");
}

void GetCommentId(thread::BlockingQueue<std::string>* modify_queue, bool* stop) {
  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_comment_topic;
  options.partition_num = FLAGS_partition_num;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = FLAGS_group_id;
  uint64 timestamp = 0;
  if (!serving_base::TimeHelper::StringToTimestamp(FLAGS_start_time, serving_base::TimeHelper::kSecond,
                                                   &timestamp)) {
    CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond,
                                                        &timestamp));
  }

  options.start_timestamp = timestamp;
  reco::kafka::Message msg;
  reco::kafka::Consumer consumer(FLAGS_kafka_brokers, options);
  int n = 0;
  while (!(*stop)) {
    if (modify_queue->Size() >= 1000) {
      LOG(INFO) << "too much modify info\t" << modify_queue->Size();
      base::SleepForSeconds(1);
      continue;
      COUNTERS_bad_item__comment_remain_num.Reset(modify_queue->Size());
    }
    if (++n % 1000 == 0) {
      COUNTERS_bad_item__comment_remain_num.Reset(modify_queue->Size());
      n = 0;
    }
    if (consumer.Consume(&msg, 100)) {
      modify_queue->Put(base::StringPrintf("comment\t%s", msg.content.c_str()));
    } else {
      base::SleepForSeconds(0.1);
    }
  }
  LOG(ERROR) << "finished reading kafka!";
  modify_queue->Close();
}

void GetBluffingResult(thread::BlockingQueue<std::string>* modify_queue, bool* stop) {
  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_bad_item_modify_topic;
  options.partition_num = FLAGS_partition_num_bluffing_modify;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = FLAGS_group_id_bad_item_modify;
  uint64 timestamp = 0;
  if (!serving_base::TimeHelper::StringToTimestamp(FLAGS_start_time, serving_base::TimeHelper::kSecond,
                                                   &timestamp)) {
    CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond,
                                                        &timestamp));
  }
  // 大搜同学没有按照秒算时间戳，用的是微秒，因此这里乘以 1000
  options.start_timestamp = timestamp * 1000;
  reco::kafka::Message msg;
  reco::kafka::Consumer consumer(FLAGS_kafka_brokers, options);
  int n = 0;
  while (!(*stop)) {
    if (modify_queue->Size() >= 1000) {
      LOG(INFO) << "too much modify infos\t" << modify_queue->Size();
      base::SleepForSeconds(1);
      continue;
      COUNTERS_bad_item__comment_remain_num.Reset(modify_queue->Size());
    }
    if (++n % 1000 == 0) {
      COUNTERS_bad_item__comment_remain_num.Reset(modify_queue->Size());
      n = 0;
    }
    if (consumer.Consume(&msg, 100)) {
      modify_queue->Put(base::StringPrintf("bluffing_modify\t%s", msg.content.c_str()));
    } else {
      base::SleepForSeconds(0.1);
    }
  }
  LOG(ERROR) << "finished reading kafka!";
  modify_queue->Close();
}

void GetCommentIdFromFile(thread::BlockingQueue<std::string>* comment_queue) {
  std::string line;
  std::ifstream fin(FLAGS_input);
  while (std::getline(fin, line)) {
    if (comment_queue->Size() > 100) {
      base::SleepForSeconds(1);
    }
    if (line.find("-") == std::string::npos) continue;
    comment_queue->Put(line);
  }
  fin.close();
  LOG(ERROR) << "finished reading file!";
  comment_queue->Close();
}

// 当前只判定低俗和标题党
bool Judge(const ItemInfo& item_info, int bluffing_score_modify,
           int sim_num, ItemQualityScore* item_quality) {
  bool result = false;
  double conf = 1;
  VLOG(1) << "judge\t" << item_info.item_id << "\t"
          << bluffing_score_modify << "\t"
          << item_quality->comment_num << "\tdirty: "
          << item_quality->scores[4] << "\tbluffing: "
          << item_quality->scores[6];
  float threshold_bluffing = FLAGS_threshold_bluffing;
  float threshold_dirty = FLAGS_threshold_dirty;
  // merge 大搜的结果
  if (bluffing_score_modify != -1) {
    if (item_quality->attr_scores[6] == bluffing_score_modify) {
      return result;
    } else {
      if (item_quality->attr_scores[6] == 0) {
        if (bluffing_score_modify == 2) {
          if (item_quality->scores[6] > 0 || item_quality->comment_num < 4 * threshold_bluffing) {
            item_quality->attr_scores[6] = 2;
            result = true;
          } else {
            item_quality->attr_scores[6] = 1;
            result = true;
          }
        } else if (bluffing_score_modify == 1) {
          if (item_quality->scores[6] > 0 || item_quality->comment_num < 10 * threshold_bluffing) {
            item_quality->attr_scores[6] = 1;
            result = true;
          } else {
            result = false;
          }
        } else {
          LOG(ERROR) << "error bluffing modify score\t" << bluffing_score_modify;
        }
      } else if (item_quality->attr_scores[6] == 1) {
        if (bluffing_score_modify == 2) {
          item_quality->attr_scores[6] = 2;
          result = true;
        } else if (bluffing_score_modify == 0) {
          if (item_quality->scores[6] == 0) {
            item_quality->attr_scores[6] = 0;
            result = true;
          } else {
            result = false;
          }
        } else {
          LOG(ERROR) << "error bluffing modify score\t" << bluffing_score_modify;
        }
      } else {
        if (bluffing_score_modify == 1) {
          item_quality->attr_scores[6] = 1;
          result = true;
        } else if (bluffing_score_modify == 0) {
          if (item_quality->scores[6] == 0) {
            item_quality->attr_scores[6] = 0;
            result = true;
          } else {
            item_quality->attr_scores[6] = 1;
            result = true;
          }
        } else {
          LOG(ERROR) << "error bluffing modify score\t" << bluffing_score_modify;
        }
      }
      return result;
    }
  }
  if (good_medias.find(item_info.media) != good_medias.end()) {
    conf *= 2;
  }
  if (category_weights.find(item_info.level1) != category_weights.end()) {
    conf *= category_weights.find(item_info.level1)->second;
  }
  if (category_weights.find(item_info.level2) != category_weights.end()) {
    conf *= category_weights.find(item_info.level2)->second;
  }
  // sim 数量多的, 加权
  if (sim_num >= 50 && sim_num < 100) {
    threshold_bluffing *= 2;
    threshold_dirty *= 2;
  } else if (sim_num >= 100) {
    threshold_bluffing *= 4;
    threshold_dirty *= 4;
  }
  if (item_quality->comment_num > threshold_bluffing) {
    // bluffing
    if (item_quality->attr_scores[6] == 0) {
      if (item_quality->scores[6] >  3 * threshold_bluffing * conf) {
        result = true;
        item_quality->attr_scores[6] = 2;
      } else if (item_quality->scores[6] >= threshold_bluffing * conf) {
        result = true;
        item_quality->attr_scores[6] = 1;
      }
    } else if (item_quality->attr_scores[6] == 1) {
      if (item_quality->scores[6] > 1.5 * threshold_bluffing * conf) {
        result = true;
        item_quality->attr_scores[6] = 2;
      }
      if (changeable_cates.find(item_info.level1) != changeable_cates.end()) {
        if (item_quality->scores[6] == 0 &&
            item_quality->comment_num > threshold_bluffing * conf * 4) {
          result = true;
          item_quality->attr_scores[6] = 0;
        }
      }
    } else {
      if (changeable_cates.find(item_info.level1) != changeable_cates.end()) {
        if (item_quality->scores[6] == 0 && item_quality->comment_num > threshold_bluffing * 10) {
          result = true;
          item_quality->attr_scores[6] = 0;
        } else if (item_quality->comment_num > threshold_bluffing * 10 &&
                   item_quality->scores[6] < threshold_bluffing * conf * 0.5) {
          result = true;
          item_quality->attr_scores[6] = 1;
        }
      }
    }
    // dirty
    if (item_quality->attr_scores[4] == 0) {
      if (item_quality->scores[4] >  4 * threshold_dirty * conf) {
        result = true;
        item_quality->attr_scores[4] = 2;
      } else if (item_quality->scores[4] >= threshold_dirty * conf) {
        result = true;
        item_quality->attr_scores[4] = 1;
      }
    } else if (item_quality->attr_scores[4] == 1) {
      if (item_quality->scores[4] > 3 * threshold_dirty * conf) {
        result = true;
        item_quality->attr_scores[4] = 2;
      }
      if (item_quality->scores[4] == 0 &&
          item_quality->comment_num > threshold_dirty * conf * 4 &&
          item_info.media != "uc自媒体" &&
          item_info.level1 != "两性情感" &&
          item_info.level1 != "社会") {
        result = true;
        item_quality->attr_scores[4] = 0;
      }
    } else {
      if (item_quality->scores[4] == 0 &&
          item_quality->comment_num > threshold_dirty * 10) {
        if (changeable_cates.find(item_info.level1) != changeable_cates.end() &&
            item_info.media != "uc自媒体" &&
            item_info.level1 != "两性情感" &&
            item_info.level1 != "社会") {
          result = true;
          item_quality->attr_scores[4] = 0;
        } else {
          result = true;
          item_quality->attr_scores[4] = 1;
        }
      } else if (item_quality->comment_num > threshold_dirty * 10 &&
                 item_quality->scores[4] < threshold_dirty * conf * 0.5) {
        result = true;
        item_quality->attr_scores[4] = 1;
      }
    }
  }
  // update item quality score
  item_qualities->Add(item_quality->item_id, *item_quality);
  return result;
}

bool GetItem(reco::BaseGetItem* item_getter,
             ItemInfo* item_info) {
  reco::RecoItem item;
  if (!item_getter->GetRecoItem(item_info->item_id, &item)) {
    LOG(ERROR) << "cannot get reco item:\t" << item_info->item_id;
    return false;
  }
  if ((item.identity().has_producer() && is_op_news(item.identity().producer())) ||
      item.identity().type() == reco::kPureVideo ||
      item.identity().type() == reco::kGoods ||
      item.identity().type() == reco::kAudio ||
      item.identity().type() == reco::kNovel ||
      item.identity().type() == reco::kAudioAlbum ||
      remit_sources.find(item.source()) != remit_sources.end()) {
    return false;
  }
  item_info->title = item.title();
  item_info->media = item.source_media();
  if (item.category_size() > 0) item_info->level1 = item.category(0);
  if (item.category_size() > 1) item_info->level2 = item.category(1);
  if (item.identity().has_producer()) {
    item_info->producer = item.identity().producer();
  }
  item_info->type = item.identity().type();
  if (item.has_content_attr()) {
    item_info->content_attr.set_erro_title(item.content_attr().erro_title());
    item_info->content_attr.set_advertorial(item.content_attr().advertorial());
    item_info->content_attr.set_short_content(item.content_attr().short_content());
    item_info->content_attr.set_dedup_paragraph(item.content_attr().dedup_paragraph());
    item_info->content_attr.set_dirty(item.content_attr().dirty());
    item_info->content_attr.set_politics(item.content_attr().politics());
    item_info->content_attr.set_bluffing_title(item.content_attr().bluffing_title());
    item_info->content_attr.set_negative(item.content_attr().negative());
  }
  return true;
}

void GetItemIds(uint64 parent_id, std::vector<uint64>* item_ids) {
  extend::WebClient::Request request;
  extend::WebClient::Response response;
  Json::Value json_value;
  Json::Reader json_parser;
  std::string url = base::StringPrintf("http://10.195.157.49:9200/index_iteminfo/type_iteminfo/_search?q=parent_id:%lu", parent_id); // NOLINT
  request.url = url;
  extend::WebClient* web_client_ = new extend::WebClient();
  web_client_->Init();
  web_client_->AddTask(&request, &response, NULL);
  web_client_->WaitForAll();
  delete web_client_;
  web_client_ = NULL;
  if (!json_parser.parse(response.http_body.c_str(),
                         response.http_body.c_str() + response.http_body.size(),
                         json_value, false)) {
    LOG(ERROR) << "error parse: " << response.http_body;
    return;
  }
  const Json::Value& data = json_value["hits"]["hits"];
  std::string item_id_str;
  uint64 item_id;
  for (int i = 0; i < (int)data.size(); ++i) {
    item_id_str = data[i]["_source"]["item_id"].asString();
    base::StringToUint64(item_id_str, &item_id);
    if ((int)data.size() > 1) {
      VLOG(1) << "parent_id:" << parent_id << "\titem_id:" << item_id;
    }
    item_ids->push_back(item_id);
  }
}

void Process(thread::BlockingQueue<std::string>* modify_queue,
             thread::BlockingQueue<std::pair<ItemQualityScore, std::string >>* update_queue_text) {
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = 3000;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_sim_server_ip, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_sim_server_port, 3000);
    options.servers.push_back(si);
  }
  net::rpc::RpcGroup* rpc_group = new net::rpc::RpcGroup(options);
  CHECK(rpc_group->Connect());
  reco::sim_item::SimItemService::Stub* rpc_stub = new reco::sim_item::SimItemService::Stub(rpc_group);

  CommentProcessor* processor = new CommentProcessor();
  reco::BaseGetItem* item_getter = new reco::ItemKeeperGetItem(FLAGS_item_keeper_server_ip, FLAGS_item_keeper_server_port); // NOLINT
  Json::Value json_value;
  Json::Reader json_parser;

  // 一些复用的变量
  std::string line;
  std::string result_str;
  std::string offline_result;
  std::vector<std::string> tokens;
  std::vector<std::string> tokens_temp;
  uint64 comment_id;
  uint64 parent_id;
  uint64 item_id;
  int bluffing_score_modify;
  // 记录评论识别的各类低质类型的分数
  std::vector<float> result;
  // 记录同一个 artical id 下面对应的所有 item ids
  std::vector<uint64> item_ids;
  while (!(modify_queue->Empty() && modify_queue->Closed())) {
    result.clear();
    item_ids.clear();
    tokens.clear();
    int status = modify_queue->TryTake(&line);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    if (status == -1) break;
    CHECK_EQ(status, 1) << "fucking status "  << status;
    bluffing_score_modify = -1;
    base::SplitString(line, "\t", &tokens);
    if ((int)tokens.size() < 2) continue;
    std::string type = tokens[0];
    if (type != "comment") {
      if (!json_parser.parse(tokens[1].c_str(),
                             tokens[1].c_str() + tokens[1].size(),
                             json_value, false)) {
        LOG(ERROR) << "error parse: " << tokens[1];
        continue;
      }
      const std::string& item_id_str = json_value["item_id"].asString();
      base::StringToUint64(item_id_str, &item_id);
      const std::string& bluffing_score_str = json_value["bluffing_score"].asString();
      base::StringToInt(bluffing_score_str, &bluffing_score_modify);
      offline_result = base::StringPrintf("%s\t%s", item_id_str.c_str(), bluffing_score_str.c_str());
      int temp = 0;
      if (processed_items->Find(offline_result, &temp)) {
        LOG(INFO) << "item_processed\t" << offline_result << "\tjump";
        continue;
      }
      LOG(INFO) << "result from bluffing modify:\t" << line;
      processed_items->Add(offline_result, 0);
      item_ids.push_back(item_id);
    } else {
      tokens_temp.clear();
      base::SplitString(tokens[1], "|", &tokens_temp);
      if (tokens_temp.empty()) continue;
      tokens.clear();
      base::SplitString(tokens_temp[0], "-", &tokens);
      base::StringToUint64(tokens[0], &parent_id);
      base::StringToUint64(tokens[1], &comment_id);
      if (!processor->ProcessComment(comment_id, "", &item_id, &result)) continue;
      GetItemIds(parent_id, &item_ids);
    }
    for (int i = 0; i < (int)item_ids.size(); ++i) {
      ItemInfo item_info;
      item_info.Initial();
      item_info.item_id = item_ids[i];
      if (!GetItem(item_getter, &item_info)) continue;

      ItemQualityScore item_quality_score;
      if (!item_qualities->Find(item_ids[i], &item_quality_score)) {
        item_quality_score.Initial();
        item_quality_score.item_id = item_ids[i];
        processor->GetOriComments(parent_id, item_ids[i], item_info.level1,
                                  &item_quality_score.scores,
                                  &item_quality_score.comment_num);
      }
      if (item_info.content_attr.has_erro_title()) {
        item_quality_score.attr_scores[0] = item_info.content_attr.erro_title();
      }
      if (item_info.content_attr.has_advertorial()) {
        item_quality_score.attr_scores[1] = item_info.content_attr.advertorial();
      }
      if (item_info.content_attr.has_short_content()) {
        item_quality_score.attr_scores[2] = item_info.content_attr.short_content();
      }
      if (item_info.content_attr.has_dedup_paragraph()) {
        item_quality_score.attr_scores[3] = item_info.content_attr.dedup_paragraph();
      }
      if (item_info.content_attr.has_dirty()) {
        item_quality_score.attr_scores[4] = item_info.content_attr.dirty();
      }
      if (item_info.content_attr.has_politics()) {
        item_quality_score.attr_scores[5] = item_info.content_attr.politics();
      }
      if (item_info.content_attr.has_bluffing_title()) {
        item_quality_score.attr_scores[6] = item_info.content_attr.bluffing_title();
      }
      if (item_info.content_attr.has_negative()) {
        item_quality_score.attr_scores[7] = item_info.content_attr.negative();
      }
      item_quality_score.title = item_info.title;
      if (!result.empty()) {
        for (int j = 0; j < (int)result.size(); ++j) {
          item_quality_score.scores[j] += result[j];
        }
        item_quality_score.comment_num += 1;
      }
      item_qualities->Add(item_ids[i], item_quality_score);
      result_str = base::StringPrintf("%d,%d\t", item_quality_score.attr_scores[4],
                                      item_quality_score.attr_scores[6]);
      // 判断 item 是否在索引里, 如果不在, 只更新低质字段, 不走 doc server
      reco::sim_item::GetSimFeatureRequest request;
      reco::sim_item::GetSimFeatureResponse response;
      request.mutable_item()->set_item_id(item_ids[i]);
      request.mutable_item()->set_title(item_info.title);
      net::rpc::RpcClientController rpc;
      rpc_stub->GetSimFeature(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()) {
        LOG(ERROR) << "get sim item info failed. "
                   << " item id: "
                   << item_ids[i] << ", "
                   << response.Utf8DebugString();
        item_quality_score.in_index = false;
      } else {
        item_quality_score.in_index = response.success();
      }
      if (Judge(item_info, bluffing_score_modify, item_ids.size(), &item_quality_score)) {
        result_str.append(base::StringPrintf("%d,%d\t%s", item_quality_score.attr_scores[4],
                                             item_quality_score.attr_scores[6], type.c_str()));
        update_queue_text->Put(std::make_pair(item_quality_score, result_str));
        item_qualities->Add(item_ids[i], item_quality_score);
        LOG(INFO) << base::StringPrintf("change item quality score:\t%lu\t%s\t%s\t%d\t%f\t%f",
                                        item_quality_score.item_id, item_quality_score.title.c_str(),
                                        result_str.c_str(), item_quality_score.comment_num,
                                        item_quality_score.scores[4], item_quality_score.scores[6]);
      }
    }
  }
}
void UpdateContentAttr(thread::BlockingQueue<std::pair<ItemQualityScore, std::string >>* update_queue_text) {
  std::ofstream fout(FLAGS_output);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = 3000;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_item_keeper_server_ip, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_item_keeper_server_port, 3000);
    options.servers.push_back(si);
  }
  net::rpc::RpcGroup* rpc_group = new net::rpc::RpcGroup(options);
  CHECK(rpc_group->Connect());
  reco::itemkeeper::ItemKeeper::Stub* rpc_stub = new reco::itemkeeper::ItemKeeper::Stub(rpc_group);
  reco::HBasePoolGetCommentRefineItems* get_comment_refine_item = new reco::HBasePoolGetCommentRefineItems(FLAGS_hbase_comment_refine_table); // NOLINT
  reco::HBasePoolSetCommentRefineItems* set_comment_refine_item = new reco::HBasePoolSetCommentRefineItems(FLAGS_hbase_comment_refine_table);  // NOLINT
  std::string result;
  std::string ori_result;
  std::vector<std::string> tokens;
  std::vector<std::string> ori_results;
  while (!(update_queue_text->Closed() && update_queue_text->Empty())) {
    std::pair<ItemQualityScore, std::string> item_quality_str;
    int status = update_queue_text->TryTake(&item_quality_str);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    if (status == -1) break;
    CHECK_EQ(status, 1) << "fucking status "  << status;
    reco::itemkeeper::UpdateItemRequest request;
    reco::itemkeeper::UpdateItemFieldResponse response;
    request.mutable_service_identity()->set_service_name("bad_item_update_comment");
    request.set_item_id(item_quality_str.first.item_id);
    request.set_is_manual(false);
    if (!item_quality_str.first.in_index) {
      LOG(INFO) << item_quality_str.first.item_id << "\tremit item because of item not in index";
      request.add_exclude_storages(reco::itemkeeper::kCdocQueue);
    }
    reco::RecoItem reco_item;
    reco::ContentAttr content_attr;
    content_attr.set_erro_title(attr_values[item_quality_str.first.attr_scores[0]]);
    content_attr.set_advertorial(attr_values[item_quality_str.first.attr_scores[1]]);
    content_attr.set_short_content(attr_values[item_quality_str.first.attr_scores[2]]);
    content_attr.set_dedup_paragraph(attr_values[item_quality_str.first.attr_scores[3]]);
    content_attr.set_dirty(attr_values[item_quality_str.first.attr_scores[4]]);
    content_attr.set_politics(attr_values[item_quality_str.first.attr_scores[5]]);
    content_attr.set_bluffing_title(attr_values[item_quality_str.first.attr_scores[6]]);
    content_attr.set_negative(attr_values[item_quality_str.first.attr_scores[7]]);
    reco_item.mutable_content_attr()->Swap(&content_attr);
    reco_item.SerializePartialToString(request.mutable_reco_item_bytes());
    net::rpc::RpcClientController rpc;
    rpc_stub->updateItemFields(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "refresh reco item failed. "
                 << " item id: "
                 << item_quality_str.first.item_id << ", "
                 << response.Utf8DebugString();
      continue;
    } else {
      tokens.clear();
      base::SplitString(item_quality_str.second, "\t", &tokens);
      if ((int)tokens.size() != 3) continue;
      if (tokens[2] == "comment") {
        result = base::StringPrintf("%s#%s", tokens[0].c_str(), tokens[1].c_str());
        if (!get_comment_refine_item->GetCommentRefineItem(item_quality_str.first.item_id, &ori_result)) {
          if (!set_comment_refine_item->SetCommentRefineItem(item_quality_str.first.item_id, result)) {
            LOG(ERROR) << "fail to set record:\t" << item_quality_str.first.item_id
                       << "\t" << item_quality_str.second;
          }
        } else {
          // 判断这次修改是否与前一次一样，如果一样，不记录
          ori_results.clear();
          base::SplitString(ori_result, "#", &ori_results);
          if (result == ori_results.back()) continue;
          std::string final_result = ori_result.append("\t").append(result);
          if (!set_comment_refine_item->SetCommentRefineItem(item_quality_str.first.item_id, result)) {
            LOG(ERROR) << "fail to set record:\t" << item_quality_str.first.item_id
                       << "\t" << item_quality_str.second;
          }
        }
      }
      fout << item_quality_str.first.item_id << "\t" << item_quality_str.first.title
           << "\t" << item_quality_str.second << "\t" << item_quality_str.first.in_index
           << std::endl;
      LOG(INFO) << "done update reco item: " << item_quality_str.first.item_id;
    }
  }
  fout.close();
  delete rpc_stub;
  delete rpc_group;
  delete get_comment_refine_item;
  delete set_comment_refine_item;
}

void RecordDiff(thread::BlockingQueue<std::pair<ItemQualityScore, std::string >>* update_queue) {
  std::ofstream fout(FLAGS_output);
  reco::HBasePoolGetCommentRefineItems* get_comment_refine_item = new reco::HBasePoolGetCommentRefineItems(FLAGS_hbase_comment_refine_table_test); // NOLINT
  reco::HBasePoolSetCommentRefineItems* set_comment_refine_item = new reco::HBasePoolSetCommentRefineItems(FLAGS_hbase_comment_refine_table_test); // NOLINT
  std::vector<std::string> tokens;
  std::vector<std::string> ori_results;
  std::string ori_result;
  std::string result;
  while (!(update_queue->Closed() && update_queue->Empty())) {
    tokens.clear();
    result.clear();
    std::pair<ItemQualityScore, std::string> item_quality_str;
    int status = update_queue->TryTake(&item_quality_str);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    if (status == -1) break;
    CHECK_EQ(status, 1) << "fucking status " << status;
    base::SplitString(item_quality_str.second, "\t", &tokens);
    if ((int)tokens.size() != 3) continue;
    if (tokens[2] == "comment") {
      result = base::StringPrintf("%s#%s", tokens[0].c_str(), tokens[1].c_str());
      if (!get_comment_refine_item->GetCommentRefineItem(item_quality_str.first.item_id, &ori_result)) {
        if (!set_comment_refine_item->SetCommentRefineItem(item_quality_str.first.item_id, result)) {
          LOG(ERROR) << "fail to set record:\t" << item_quality_str.first.item_id
                     << "\t" << item_quality_str.second;
        }
      } else {
        // 判断这次修改是否与前一次一样，如果一样，不记录
        ori_results.clear();
        base::SplitString(ori_result, "#", &ori_results);
        if (result == ori_results.back()) continue;
        std::string final_result = ori_result.append("\t").append(result);
        if (!set_comment_refine_item->SetCommentRefineItem(item_quality_str.first.item_id, result)) {
          LOG(ERROR) << "fail to set record:\t" << item_quality_str.first.item_id
                     << "\t" << item_quality_str.second;
        }
      }
    }
    fout << item_quality_str.first.item_id << "\t" << item_quality_str.first.title
         << "\t" << item_quality_str.second << "\t" << item_quality_str.first.in_index
         << std::endl;
  }
  fout.close();
  delete get_comment_refine_item;
  delete set_comment_refine_item;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "offline comment process");
  CommentProcessor::Initial();
  Initial();
  thread::ThreadPool pool(FLAGS_thread_num + 3);
  bool stop = false;
  thread::BlockingQueue<std::string> modify_queue;
  thread::BlockingQueue<std::pair<ItemQualityScore, std::string>> update_queue_text;
  if (FLAGS_standalone) {
    pool.AddTask(::NewCallback(GetCommentIdFromFile, &modify_queue));
  } else {
    pool.AddTask(::NewCallback(GetCommentId, &modify_queue, &stop));
    pool.AddTask(::NewCallback(GetBluffingResult, &modify_queue, &stop));
  }
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(Process, &modify_queue, &update_queue_text));
  }
  if (FLAGS_update) {
    pool.AddTask(::NewCallback(UpdateContentAttr, &update_queue_text));
  } else {
    pool.AddTask(::NewCallback(RecordDiff, &update_queue_text));
  }
  if (!FLAGS_standalone) {
    net::counter::HttpCounterExport();
    serving_base::SignalCatcher::Initialize();
    serving_base::SignalCatcher::WaitForSignal();
  }
  stop = true;
  pool.JoinAll();
  return 0;
}
