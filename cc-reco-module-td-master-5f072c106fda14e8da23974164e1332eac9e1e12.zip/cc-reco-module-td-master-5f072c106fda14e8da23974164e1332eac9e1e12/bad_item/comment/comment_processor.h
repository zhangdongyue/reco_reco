#pragma once

#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <string>
#include <unordered_map>
#include <unordered_set>

#include "base/common/base.h"
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "nlp/common/nlp_util.h"
#include "base/strings/string_number_conversions.h"
#include "third_party/jsoncpp/include/json/value.h"
#include "third_party/jsoncpp/include/json/reader.h"
#include "reco/bizc/proto/comment.pb.h"
#include "extend/static_dict/dawg/dictionary.h"
#include "extend/web_client/web_client.h"

class CommentProcessor {
 public:
  CommentProcessor();
  ~CommentProcessor();

  static void Initial();

  void GetOriComments(uint64 parent_id, uint64 item_id,
                      const std::string& cate,
                      std::vector<float>* scores, int* comment_num);

  bool ProcessComment(uint64 comment_id, const std::string& cate,
                      uint64* item_id, std::vector<float>* result);

  bool JudgeCommentByRule(const std::string& comment,
                          std::set<std::string>* ngrams,
                          std::string* type);

  bool JudgeCommentByModel(uint64 item_id, int up_cnt,
                           const std::string& comment,
                           const std::set<std::string>& ngrams_rule,
                           std::vector<float>* result);

  // for offline tasks
  void GetAllComments(uint64 item_id, int getter_type, const std::string& cate,
                      std::vector<std::pair<std::string, std::string> >* results);
  bool ProcessComment(uint64 comment_id, std::string* comment, std::string* result);


 private:
  void GenerateNgrams(const std::string& line, std::set<std::string>* ngrams);

  void GenerateUnigram(const base::Slice& norm_text,
                       const nlp::term::TermContainer& container,
                       std::vector<base::Slice>* mix_terms);

  bool IsValidUnigram(const base::Slice& unigram);
  bool IsValidBigram(const base::Slice& term1, const base::Slice& term2);

  Json::Reader* json_parser_;
  nlp::segment::Segmenter* segmenter_;
  nlp::postag::PosTagger* pos_tagger_;
  nlp::ner::Ner* ner_;

  static std::string dict_path;
  static std::string duanzi_path;
  static std::string good_media_file;
  static std::string cate_weight_file;
  static std::string dirty_model_file;
  static std::string bluffing_model_file;
  static std::string stopwords_file;

  static std::unordered_map<std::string, std::pair<std::string, int>> type_dict;
  static dawgdic::Dictionary comment_rules;
  static std::unordered_set<uint64> duanzi;
  static std::map<uint64, double> model_dirty;
  static std::map<uint64, double> model_bluffing;
  static std::set<std::string> stopwords;
};
