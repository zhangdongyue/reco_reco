#pragma once

#include <string>
#include <vector>
#include <map>
#include "base/common/base.h"

namespace reco {

// NOTE: thread safe
class HBasePoolGetCommentRefineItems {
 public:
  explicit HBasePoolGetCommentRefineItems(const std::string& hbase_table_name);
  ~HBasePoolGetCommentRefineItems();

  bool GetCommentRefineItem(uint64 item_id, std::string* result);

  void GetCommentRefineItem(const std::vector<uint64>& item_ids,
                            std::vector<bool>* rets,
                            std::vector<std::string>* results);

  void GetRawResult(const std::vector<std::string>& item_keys,
                    std::vector<bool>* rets,
                    std::vector<std::string>* result);

  std::string table_name_;
};
}  // namespace reco
