#include "reco/module/bad_item/comment/hbase_pool_get_comment_refine_items.h"

#include <map>
#include <string>
#include <vector>
#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

namespace reco {

HBasePoolGetCommentRefineItems::HBasePoolGetCommentRefineItems(const std::string& hbase_table_name) {
  table_name_ = hbase_table_name;
  reco::hbase::HBasePoolIns::instance().Init();
}

HBasePoolGetCommentRefineItems::~HBasePoolGetCommentRefineItems() {
}

bool HBasePoolGetCommentRefineItems::GetCommentRefineItem(uint64 item_id, std::string* result) {
  std::vector<uint64> item_ids;
  item_ids.push_back(item_id);

  std::vector<bool> rets;
  std::vector<std::string> results;
  GetCommentRefineItem(item_ids, &rets, &results);
  if (rets[0]) {
    *result = results[0];
  }
  return rets[0];
}

void HBasePoolGetCommentRefineItems::GetCommentRefineItem(const std::vector<uint64>& item_ids,
                                                          std::vector<bool>* rets,
                                                          std::vector<std::string>* results) {
  rets->clear();
  rets->resize(item_ids.size(), false);
  results->clear();
  results->resize(item_ids.size());

  if (item_ids.empty()) {
    return;
  }
  std::vector<std::string> item_keys;
  for (int i = 0; i < (int)item_ids.size(); ++i) {
    item_keys.push_back(base::Uint64ToString(item_ids[i]));
  }
  GetRawResult(item_keys, rets, results);
}

void HBasePoolGetCommentRefineItems::GetRawResult(const std::vector<std::string>& item_keys,
                                                  std::vector<bool>* rets,
                                                  std::vector<std::string>* result) {
  std::map<std::string, std::map<std::string, std::string> > row_map;
  int retry = 0;
  rets->clear();
  result->clear();
  rets->resize(item_keys.size(), false);
  result->resize(item_keys.size(), "");

  while (retry++ < 3) {
    reco::hbase::HBaseAutoCli cli = reco::hbase::HBaseAutoCli(10);
    reco::hbase::HBaseCli* client = cli.Get();
    if (client == NULL) {
      continue;
    }
    if (client->BatchGetByKeys(table_name_, item_keys, &row_map)) {
      break;
    } else {
      continue;
    }
  }

  if (retry >= 3) {
    std::string buf;
    base::FastJoinStrings(item_keys, ",", &buf);
    LOG(ERROR) << "batch get failed! and drop current task: " << buf;
    return;
  }

  for (size_t i = 0; i < item_keys.size(); ++i) {
    auto it = row_map.find(item_keys[i]);
    if (it == row_map.end()) continue;

    auto it2 = it->second.find("data:refine_record");
    if (it2 == it->second.end()) {
      VLOG(1) << "canot find refine record for row key: " << item_keys[i];
      continue;
    }
    rets->at(i) = true;
    result->at(i) = it2->second;
  }
}
}  // namespace reco
