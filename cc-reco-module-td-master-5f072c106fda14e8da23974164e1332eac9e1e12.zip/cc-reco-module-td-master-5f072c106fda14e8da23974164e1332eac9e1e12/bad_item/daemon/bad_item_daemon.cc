// 监控 reco item 队列，新的 reco item 去查 bad item server, 写入数据库和给 item server 发送
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "storage/message_queue/api/message_client_generator.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "net/rpc/rpc.h"
#include "net/counter/export.h"
#include "base/container/lru_cache.h"
#include "reco/base/kafka_c/api/topic_producer.h"

#include "reco/bizc/proto/bad_item.pb.h"
#include "reco/module/bad_item/daemon/dao.h"
#include "reco/module/bad_item/strategy/rubbish_detector.h"
#include "reco/bizc/item_service/hbase_pool_get_item.h"
#include "reco/bizc/proto/common.pb.h"

DEFINE_int32(thread_num, 2, "number of thread for save sim pair to db");
DEFINE_int32(message_buffer_size, 1024, "buffer size for cached message");

DEFINE_string(message_queue_servers, "10.3.5.73:1999", "message queue servers");
DEFINE_int32(message_queue_rpc_timeout, 300, "message_queue server's rpc timeout");
DEFINE_string(reco_item_queue, "reco::zhengying::reco_item", "message queue name of ");

DEFINE_string(message_reader, "bad_item", "message reader name");

DEFINE_string(data_dir, "./data", "");

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(start_time, "2014-12-10 00:00:00", "db start time");
DEFINE_string(schema, "reco", "shcema");
DEFINE_int32(cache_size, 20000, "cache size for rubbish item");

DEFINE_string(bad_item_server_ip, "127.0.0.1", "leaf server ip, seperated by comma");
DEFINE_int32(bad_item_server_port, 9090, "sim item server port");
DEFINE_int32(write_type, 0, "0 to db, 1: save result to file");
DEFINE_bool(is_debug, false, "if set put everything in ");

DEFINE_string(hbase_table, "tb_reco_item", "hbase table");
DEFINE_string(result_file, "result.txt", "result file");
DEFINE_string(item_id_file, "", "if given, resend id in file");

DEFINE_string(kafka_brokers, "10.181.169.190:9092,10.181.169.191:9092,10.181.169.192:9092,10.181.169.193:9092,10.181.169.194:9092", "kafka queue servers");  // NOLINT
DEFINE_string(kafka_topic_name, "", "topic name");
DEFINE_int32(kafka_total_partition, 9, "partition num for some topic");

DEFINE_int64_counter(bad_item, parse_failed_num, 0, "failed parsed reco item num");
DEFINE_int64_counter(bad_item, succ_to_db, 0, "the num of item that had been put in db");
DEFINE_int64_counter(bad_item, failed_to_db, 0, "the num of item that failed to put in db");
DEFINE_int64_counter(bad_item, succ_to_kafka, 0, "the num of update request sending to itemserver");
DEFINE_int64_counter(bad_item, failed_to_kafka, 0, "the num of item failed to push to kafka");

DEFINE_int64_counter(bad_item, remain_num, 0, "the num of item in the queue");
DEFINE_int64_counter(bad_item, send_num, 0, "the num of item had been send to sim server");

namespace reco {
namespace bad_item {

struct BadResult {
  uint64 item_id;
};

class BadItemGenerator {
 private:
  BadItemGenerator() {}
  ~BadItemGenerator() {}

 public:
  static void Start();
  static void Stop();

 private:
  static const int kAllBadItemBitmap;
  static void GenerateBadItemRequest();
  static void GenerateBadItem();
  // push to db and item server
  static void PushToDb();

  // update content attr in hbase and send rquest to item server
  static void UpdateContentAttr();
  static void UpdateVideoAttr();
  static void WriteContentAttrToHBase();

 private:
  static const char* kTimestampFile;

  static thread::BlockingQueue<BadItemRequest*> bad_item_request_queue_;
  static thread::BlockingQueue<std::pair<BadItemRequest*, reco::ContentAttr>> db_queue_;
  static thread::BlockingQueue<std::pair<uint64, reco::ContentAttr>> update_content_attr_queue_;
  static thread::BlockingQueue<std::pair<uint64, reco::VideoAttr>> update_video_attr_queue_;


  static thread::BlockingVar<int> finish_num_;
  static uint64 reader_start_time_;

  static thread::ThreadPool* thread_pool_;
  static bool stop_;
  static serving_base::ExpiryMap<uint64, int>* wemedia_item_dict_;
};

thread::BlockingVar<int> BadItemGenerator::finish_num_;
const char* BadItemGenerator::kTimestampFile = "timestamp.dat";
thread::BlockingQueue<BadItemRequest*> BadItemGenerator::bad_item_request_queue_;
thread::BlockingQueue<std::pair<BadItemRequest*, reco::ContentAttr> > BadItemGenerator::db_queue_;

thread::BlockingQueue<std::pair<uint64, reco::ContentAttr>> BadItemGenerator::update_content_attr_queue_;

thread::BlockingQueue<std::pair<uint64, reco::VideoAttr>> BadItemGenerator::update_video_attr_queue_;

serving_base::ExpiryMap<uint64, int>* BadItemGenerator::wemedia_item_dict_;

uint64 BadItemGenerator::reader_start_time_ = 0;

thread::ThreadPool* BadItemGenerator::thread_pool_ = NULL;
bool BadItemGenerator::stop_ = false;

void BadItemGenerator::Start() {
  // 1: init some values
  base::FilePath base_dir(FLAGS_data_dir);
  base::FilePath timestamp_file = base_dir.Append(kTimestampFile);
  CHECK(base::file_util::PathExists(timestamp_file));
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(timestamp_file, &lines);
  CHECK(lines.size()) << "invalid dump file: " << timestamp_file.value();
  CHECK(serving_base::TimeHelper::StringToTimestamp(lines[0],
                                                    serving_base::TimeHelper::kSecond,
                                                    &reader_start_time_))
      << "invalid dump timestamp: " << lines[0];

  wemedia_item_dict_ = new serving_base::ExpiryMap<uint64, int>(24 * 3600);

  thread_pool_ = new thread::ThreadPool(FLAGS_thread_num + 4);
  thread_pool_->AddTask(::NewCallback(&BadItemGenerator::GenerateBadItemRequest));
  CHECK(finish_num_.TryPut(0));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    thread_pool_->AddTask(::NewCallback(&BadItemGenerator::GenerateBadItem));
  }

  thread_pool_->AddTask(::NewCallback(&BadItemGenerator::PushToDb));
  thread_pool_->AddTask(::NewCallback(&BadItemGenerator::UpdateContentAttr));
  thread_pool_->AddTask(::NewCallback(&BadItemGenerator::UpdateVideoAttr));
}

void BadItemGenerator::Stop() {
  if (!stop_) {
    stop_ = true;
    LOG(INFO) << "begin to join all thread";
    thread_pool_->JoinAll();
  }
}

inline void TransferToBadItemEntity(const reco::RecoItem& reco_item,
                                    const reco::ContentAttr& content_attr,
                                    BadItemEntity* entity) {
  CHECK_NOTNULL(entity);
  base::Time time = base::Time::Now();
  std::string time_str;
  time.ToStringInSeconds(&time_str);

  std::string title;
  std::vector<std::string> tokens;
  base::SplitString(reco_item.title(), "\"", &tokens);
  for (int i = 0; i < (int)tokens.size(); ++i) {
    title.append(tokens[i].c_str(), tokens[i].size());
    if (i < (int)tokens.size() - 1) title.append("\\\"");
  }
  entity->item_id = reco_item.identity().item_id();
  entity->category = reco_item.category(0);
  entity->title = title;
  entity->source = reco_item.source();
  entity->create_time = reco_item.create_time();
  entity->import_time = time_str;
  entity->post_score = -1;
  entity->check_priority = 1;
  entity->pre_score = 1;

  // NOTE(xielang): 判断类型，目前审核平台支持一种类型，选择一种最有可能的给审核去审
  entity->rubbish_type = 0;
  entity->pre_score = 0;

  if (content_attr.has_bluffing_title() && content_attr.bluffing_title() != reco::ContentAttr::kSureNo) {
    entity->rubbish_type |= 32;
    if (content_attr.bluffing_title() == reco::ContentAttr::kSureYes) {
      entity->pre_score |= 32;
    }
  }

  if (content_attr.has_advertorial() && content_attr.advertorial() != reco::ContentAttr::kSureNo) {
    entity->rubbish_type |= 2;
    if (content_attr.advertorial() == reco::ContentAttr::kSureYes) {
      entity->pre_score |= 2;
    }
    entity->check_priority = 2;
  }

  if (content_attr.has_dirty() && content_attr.dirty() != reco::ContentAttr::kSureNo) {
    entity->rubbish_type |= 64;
    if (content_attr.dirty() == reco::ContentAttr::kSureYes) {
      entity->pre_score |= 64;
    }
  }

  if (content_attr.has_politics() && content_attr.politics() != reco::ContentAttr::kSureNo) {
    entity->rubbish_type |= 16;
    if (content_attr.dirty() == reco::ContentAttr::kSureYes) {
      entity->pre_score |= 16;
    }
  }
  entity->review_comment = "";
  entity->review_time = "";
  entity->score_reviewed = -1;
  entity->op = "";
  entity->status = 0;
}

void BadItemGenerator::PushToDb() {
  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  Dao* db_agent = new Dao();
  db_agent->Init(db_option, FLAGS_cache_size, FLAGS_start_time);

  base::FilePath base_dir(FLAGS_data_dir);

  std::string debug_str;
  std::pair<BadItemRequest*, reco::ContentAttr> result;
  BadItemEntity entity;

  std::ofstream fout(FLAGS_result_file);

  std::unordered_map<uint64, int> failed_cache;

  while (!(db_queue_.Empty() && db_queue_.Closed())) {
    int status = db_queue_.TimedTake(100, &result);
    scoped_ptr<BadItemRequest> request(result.first);

    if (status == -1) {
      LOG(ERROR) << "get bad item result failed! status: " << status;
      break;
    }

    if (status == 0) {
      LOG_EVERY_N(ERROR, 100) << "bad item result queue empty";
      base::SleepForMilliseconds(2000);
      continue;
    }
    int v = 0;
    if (wemedia_item_dict_->FindSilently(request->reco_item().identity().item_id(), &v)) {
      LOG(INFO) << "skip wemedia item: " << request->reco_item().identity().item_id();
      continue;
    }

    TransferToBadItemEntity(request->reco_item(), result.second, &entity);

    if (FLAGS_write_type == 1) {
      fout << base::StringPrintf("%lu\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%s\t%s\t%d\t%s\t%d\t%d\n",
                                 entity.item_id,
                                 entity.category.c_str(),
                                 entity.title.c_str(),
                                 entity.source.c_str(),
                                 entity.create_time.c_str(),
                                 entity.import_time.c_str(),
                                 entity.item_fea_info.c_str(),
                                 entity.post_score,
                                 entity.pre_score,
                                 entity.rubbish_type,
                                 entity.review_comment.c_str(),
                                 entity.review_time.c_str(),
                                 entity.score_reviewed,
                                 entity.op.c_str(),
                                 entity.check_priority,
                                 entity.status);
      continue;
    }

    bool succ = db_agent->AddBadItem(entity);
    if (!succ) {
      BadItemRequest* new_request = new BadItemRequest();
      new_request->Swap(request.get());
      auto it_pair = failed_cache.insert(std::make_pair(entity.item_id, 1));
      if (!it_pair.second) {
        it_pair.first->second += 1;
      } else {
        COUNTERS_bad_item__failed_to_db.Increase(1);
      }
      if (it_pair.first->second < 5) {
        db_queue_.Put(std::make_pair(new_request, result.second));
      } else {
        LOG(ERROR) << "drop item to push db: " << entity.item_id;
      }
    } else {
      COUNTERS_bad_item__succ_to_db.Increase(1);
    }
  }
}

inline bool is_rubbish(const reco::ContentAttr& content_attr) {
  if (content_attr.has_erro_title() && content_attr.erro_title() != reco::ContentAttr::kSureNo) return true;
  if (content_attr.has_advertorial() && content_attr.advertorial() != reco::ContentAttr::kSureNo) return true;
  if (content_attr.has_short_content() && content_attr.short_content() != reco::ContentAttr::kSureNo) return true;  // NOLINT
  if (content_attr.has_dedup_paragraph() && content_attr.dedup_paragraph() != reco::ContentAttr::kSureNo) return true;  // NOLINT
  if (content_attr.has_dirty() && content_attr.dirty() != reco::ContentAttr::kSureNo) return true;
  if (content_attr.has_politics() && content_attr.politics() != reco::ContentAttr::kSureNo) return true;
  if (content_attr.has_bluffing_title() && content_attr.bluffing_title() != reco::ContentAttr::kSureNo) return true;  // NOLINT
  if (content_attr.has_negative() && content_attr.negative() != reco::ContentAttr::kSureNo) return true;
  return false;
}

inline bool should_review(const reco::ContentAttr& content_attr) {
  if (content_attr.has_advertorial() && content_attr.advertorial() != reco::ContentAttr::kSureNo) return true;
  if (content_attr.has_dirty() && content_attr.dirty() != reco::ContentAttr::kSureNo) return true;
  if (content_attr.has_bluffing_title() && content_attr.bluffing_title() != reco::ContentAttr::kSureNo) return true;  // NOLINT
  if (content_attr.has_politics() && content_attr.politics() != reco::ContentAttr::kSureNo) return true;
  return false;
}

// 只看是否是低质视频, 即对应原来的垃圾视频。 低俗那边 zekun 自己有识别方法
inline bool should_update_rubbish_video(const reco::VideoAttr& video_attr) {
  if (video_attr.has_quality_level() && video_attr.quality_level() != reco::VideoAttr::kNormal) return true;  // NOLINT
  return false;
}

void BadItemGenerator::GenerateBadItem() {
  net::rpc::RpcClientChannel channel(FLAGS_bad_item_server_ip.c_str(), FLAGS_bad_item_server_port);
  CHECK(channel.Connect());
  reco::bad_item::BadItemService::Stub stub(&channel);

  base::LRUCache<uint64, int> failed_item_cache(10000, false);

  BadItemRequest* request = NULL;
  BadItemResponse response;
  const int kMaxRetryTimes = 3;
  while (!(bad_item_request_queue_.Closed() && bad_item_request_queue_.Empty())) {
    COUNTERS_bad_item__remain_num.Reset(bad_item_request_queue_.Size());
    int status = bad_item_request_queue_.TimedTake(100, &request);
    if (status == 0) {
      base::SleepForMilliseconds(1000);
      delete request;
      continue;
    }
    if (status < 0) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status: " << status;

    // generate the request for get sim items
    COUNTERS_bad_item__send_num.Increase(1);

    if (request->text().size() < 3  && !request->has_reco_item()) {
      LOG(ERROR) << "empty request " << request->item_id();
      delete request;
      continue;
    }

    int retry_times = 0;
    while (retry_times < kMaxRetryTimes) {
      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(2000);
      LOG(INFO) << "send item: " << request->reco_item().identity().item_id();
      stub.DetectBadItem(&rpc, request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()) {
        LOG_EVERY_N(ERROR, 200) << "get bad items failed: " << request->reco_item().identity().item_id();
        if (!channel.IsConnected() && !channel.Connect(200)) {
          LOG(ERROR) << "cannot conenct to bad item server";
          base::SleepForSeconds(5);
        }
        continue;
      }

      if (!response.success()) {
        ++retry_times;
        base::SleepForMilliseconds(200);
        continue;
      }
      break;
    }

    if (retry_times >= kMaxRetryTimes) {
      LOG(ERROR) << "put request in queue again: " << request->reco_item().identity().item_id();
      bad_item_request_queue_.Put(request);
      continue;
    }

    // 有垃圾类别存在才塞 item update 的 kafka 队列
    // 需要审核的类型才 push db
    // 如果 response 存在且 video attr 需要更新, 才塞 video kafka
    if (is_rubbish(response.content_attr())) {
      LOG(INFO) << "bad item: " << request->reco_item().identity().item_id();
      if (request->reco_item().identity().type() != 30) {
        if (should_review(response.content_attr())) {
          LOG(INFO) << "send item for reviewer: " << request->reco_item().identity().item_id();
          db_queue_.Put(std::make_pair(request, response.content_attr()));
        }
      }
      update_content_attr_queue_.Put(std::make_pair(response.item_id(), response.content_attr()));
    } else if (response.has_video_attr() &&
               should_update_rubbish_video(response.video_attr())) {
      LOG(INFO) << "bad video item: " << request->reco_item().identity().item_id();
      update_video_attr_queue_.Put(std::make_pair(response.item_id(), response.video_attr()));
    } else {
      LOG(INFO) << "normal item: " << request->reco_item().identity().item_id();
      delete request;
    }
  }

  int n = finish_num_.Take() + 1;
  if (n >= FLAGS_thread_num) {
    db_queue_.Close();
    update_content_attr_queue_.Close();
    update_video_attr_queue_.Close();
  }
  finish_num_.TryPut(n);
}

void BadItemGenerator::UpdateContentAttr() {
  reco::kafka::TopicProducer producer(FLAGS_kafka_brokers, FLAGS_kafka_topic_name, FLAGS_kafka_total_partition);  // NOLINT

  std::string message;
  message.reserve(4096);

  int partition = 0;

  reco::RawItemFieldUpdateRequest request;

  reco::RawItemField item_fld;

  std::string content_attr_str;
  std::pair<uint64, reco::ContentAttr> element;
  while (!(update_content_attr_queue_.Closed() && update_content_attr_queue_.Empty())) {
    int status = update_content_attr_queue_.TryTake(&element);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    if (status == -1) break;

    CHECK_EQ(status, 1) << "fucking status "  << status;
    if (!element.second.SerializeToString(&content_attr_str)) {
      LOG(ERROR) << "failed to serilize to string fo item: " << element.first;
      continue;
    }
    item_fld.set_field_name("content_attr");
    item_fld.set_is_manual(false);
    item_fld.set_value(content_attr_str);

    request.Clear();
    request.set_item_id(element.first);
    request.set_timestamp(base::GetTimestamp() / 1000);
    request.add_fields()->Swap(&item_fld);
    request.SerializeToString(&message);
    if (!producer.Push(partition, message)) {
      LOG(ERROR) << base::StringPrintf("failed to push to kafka queue: %s, partition: %d, item id: %lu",
                                       FLAGS_kafka_brokers.c_str(), partition, element.first);
    } else {
      LOG(INFO) << base::StringPrintf("succ push to kafka queue: %s, partition: %d, item id: %lu",
                                      FLAGS_kafka_brokers.c_str(), partition, element.first);
      partition = (partition + 1) % FLAGS_kafka_total_partition;
      COUNTERS_bad_item__succ_to_kafka.Increase(1);
    }
  }
}

void BadItemGenerator::UpdateVideoAttr() {
  reco::kafka::TopicProducer producer(FLAGS_kafka_brokers, FLAGS_kafka_topic_name, FLAGS_kafka_total_partition);  // NOLINT

  std::string message;
  message.reserve(4096);

  int partition = 0;

  reco::RawItemFieldUpdateRequest request;

  reco::RawItemField item_fld;

  std::string video_attr_str;
  std::pair<uint64, reco::VideoAttr> element;
  while (!(update_video_attr_queue_.Closed() && update_video_attr_queue_.Empty())) {
    int status = update_video_attr_queue_.TryTake(&element);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    if (status == -1) break;

    CHECK_EQ(status, 1) << "fucking status "  << status;
    if (!element.second.SerializeToString(&video_attr_str)) {
      LOG(ERROR) << "failed to serilize to string fo item: " << element.first;
      continue;
    }
    item_fld.set_field_name("video_attr");
    item_fld.set_is_manual(false);
    item_fld.set_value(video_attr_str);

    request.Clear();
    request.set_item_id(element.first);
    request.set_timestamp(base::GetTimestamp() / 1000);
    request.add_fields()->Swap(&item_fld);
    request.SerializeToString(&message);
    if (!producer.Push(partition, message)) {
      LOG(ERROR) << base::StringPrintf("failed to push low quality video to kafka queue: %s, partition: %d, item id: %lu", // NOLINT
                                       FLAGS_kafka_brokers.c_str(), partition, element.first);
    } else {
      LOG(INFO) << base::StringPrintf("succ push low quality video to kafka queue: %s, partition: %d, item id: %lu", // NOLINT
                                      FLAGS_kafka_brokers.c_str(), partition, element.first);
      partition = (partition + 1) % FLAGS_kafka_total_partition;
      COUNTERS_bad_item__succ_to_kafka.Increase(1);
    }
  }
}

void BadItemGenerator::GenerateBadItemRequest() {
  // get reco item from reco item queue
  message_queue::MessageQueueOptions options(FLAGS_message_queue_servers);
  options.create_if_missing_ = false;
  scoped_ptr<message_queue::MessageClientInterface> message_queue_client(message_queue::NewClient(options));

  if (reader_start_time_ > 0) {
    message_queue_client->SetStartTimet(FLAGS_reco_item_queue,
                                        FLAGS_message_reader,
                                        reader_start_time_ / 1000000);
  }

  message_queue::Fetcher *fetcher = message_queue_client->GetFetcher(FLAGS_reco_item_queue,
                                                                     FLAGS_message_reader,
                                                                     message_queue::FetchType::kMirrorFetch);
  message_queue::AutoUnRef auto_unref_fetcher(fetcher);
  std::string message;
  RecoItem reco_item;

  int64 dump_timestamp = reader_start_time_;
  std::unordered_map<uint64, int> skip_item_dict;
  while (!stop_) {
    if (base::GetTimestamp() - dump_timestamp > 1000000L * 60) {
      int t = 0;
      if (fetcher->GetCurrentTimet(&t)) {
        dump_timestamp = base::GetTimestamp();
        base::FilePath base_dir(FLAGS_data_dir);
        std::string timestamp_file = base_dir.Append(kTimestampFile).ToString();
        std::string data;
        CHECK(serving_base::TimeHelper::TimestampToString(
                (int64)(t) * 1000000L, serving_base::TimeHelper::kSecond, &data));
        std::string new_file = timestamp_file + ".new";
        CHECK_EQ(base::file_util::WriteFile(new_file, const_cast<char*>(data.data()),
                                            data.size()), (int)data.size());
        CHECK(base::file_util::Move(new_file, timestamp_file));
      }
    }

    if (fetcher->Pop(FLAGS_message_queue_rpc_timeout, &message) == message_queue::kPopSuccess) {
      if (!reco_item.ParseFromString(message)) {
        LOG(ERROR) << "failed to parse RecoItem from message, " << message;
        COUNTERS_bad_item__parse_failed_num.Increase(1);
      } else if (reco_item.has_raw_item() && !reco_item.raw_item().is_valid()) {
        LOG(ERROR) << "invalid item: " << reco_item.identity().item_id();
      } else if (reco_item.has_raw_item() && reco_item.raw_item().has_has_merged() &&
                 reco_item.raw_item().has_merged()) {
        LOG(INFO) << "merged item: " << reco_item.identity().item_id() << " skip!";
      } else if (skip_item_dict.find(reco_item.identity().item_id()) != skip_item_dict.end()) {
        LOG(INFO) << "skip item: " << reco_item.identity().item_id();
      } else if ((reco_item.has_raw_item() &&
                reco_item.raw_item().has_original_id() &&
                reco_item.raw_item().original_id().size() > 1) ||
                 (reco_item.identity().has_producer() && reco_item.identity().producer() != "uc")) {
        LOG(INFO) << "op item: " << reco_item.identity().item_id();
      } else {
        if (reco_item.has_raw_item() &&
            reco_item.raw_item().source().find("cp_wemedia_uc") != std::string::npos) {
          LOG(INFO) << "wemedia item: " << reco_item.identity().item_id();
          wemedia_item_dict_->Add(reco_item.identity().item_id(), 1);
        }
        BadItemRequest* request = new BadItemRequest();
        request->set_item_id(reco_item.identity().item_id());
        request->mutable_reco_item()->Swap(&reco_item);
        bad_item_request_queue_.Put(request);
        LOG(INFO) << "put request: " << request->item_id();
      }
    } else {
      LOG_EVERY_N(INFO, 1000) << "get message from queue failed!";
      base::SleepForMilliseconds(1000);
    }
    if (bad_item_request_queue_.Size() > FLAGS_message_buffer_size) {
      VLOG(1) << "num of message in bad item request queeu equal to buffer size";
      base::SleepForMilliseconds(1000);
    }
  }
  bad_item_request_queue_.Close();
}
}
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "bad itemn daemon");

  reco::bad_item::BadItemGenerator::Start();
  std::cout << "bad item daemon start" << std::endl;

  net::counter::HttpCounterExport();

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();
  reco::bad_item::BadItemGenerator::Stop();
  LOG(INFO) << "bad item daemon stop";
  return 0;
}
