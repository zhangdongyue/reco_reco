#pragma once
#include <vector>
#include <string>
#include <utility>
#include <unordered_map>
#include "base/common/basic_types.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "base/container/lru_cache.h"
#include "base/testing/gtest_prod.h"

namespace reco {
namespace bad_item {
class DaoTest;

struct BadItemEntity {
  uint64 item_id;
  std::string category;
  std::string title;
  std::string source;
  std::string create_time;
  std::string import_time;
  std::string item_fea_info;
  int post_score;
  int pre_score;
  int rubbish_type;
  std::string review_comment;
  std::string review_time;
  int score_reviewed;
  std::string op;
  int check_priority;
  int status;
};

class Dao {
 public:
  void Init(const serving_base::mysql_util::DbConnManager::Option &db_option,
            int cache_size, const std::string& start_time);

  bool AddBadItem(const BadItemEntity& entity);

  bool DeleteBadItem(uint64 item_id);

  Dao();
  ~Dao() {}
 protected:
  static const int kRetryTimes = 3;
  bool GetReviewedItem(const std::string& sql, std::unordered_map<uint64, int>* refer_count, int filter);

  base::LRUCache<uint64, int>* reviewed_item_cache_;
  std::string sql_str_;
  serving_base::mysql_util::DbConnManager* db_manager_;
  sql::Connection* db_connection_;
  FRIEND_TEST(DaoTest, TestWrite);
};
}
}

