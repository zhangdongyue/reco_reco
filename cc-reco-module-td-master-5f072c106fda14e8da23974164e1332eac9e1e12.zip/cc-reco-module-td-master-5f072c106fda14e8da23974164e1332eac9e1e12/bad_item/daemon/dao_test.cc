#include <vector>
#include <unordered_map>
#include <utility>
#include <set>
#include <string>
#include <fstream>

#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/file/file_path.h"
#include "base/time/time.h"
#include "base/strings/string_number_conversions.h"

#include "reco/module/bad_item/daemon/dao.h"
#include "reco/bizc/proto/item.pb.h"

using std::vector;
using std::unordered_map;
using std::set;
using std::string;
using std::pair;
using std::make_pair;
namespace reco {
namespace bad_item {
class DaoTest: public testing::Test {
 protected:
  reco::bad_item::Dao* db_agent_;
  virtual void SetUp() {
    serving_base::mysql_util::DbConnManager::Option db_options;
    db_options.host = "tcp://100.85.69.70:3031";
    db_options.user = "root";
    db_options.passwd = "chuheridangwu";
    db_options.schema = "reco";
    db_agent_ = new reco::bad_item::Dao();
    db_agent_->Init(db_options, 10000, "2015-11-19");
  }

  virtual void TearDown() {
    delete db_agent_;
  }
};

struct TestCase {
  uint64 item_id;
  int status;
  double score;
};

inline void TransferToBadItemEntity(const reco::RecoItem& reco_item,
                                    const std::vector<std::pair<double, int> >& results,
                                    BadItemEntity* entity) {
  CHECK_NOTNULL(entity);
  base::Time time = base::Time::Now();
  std::string time_str;
  time.ToStringInSeconds(&time_str);

  entity->item_id = reco_item.identity().item_id();
  entity->category = reco_item.category(0);
  entity->title = reco_item.title();
  entity->source = reco_item.source();
  entity->create_time = reco_item.create_time();
  entity->import_time = time_str;
  entity->post_score = -1;
  entity->pre_score = results.front().first;
  entity->rubbish_type = results.front().second;
  entity->review_comment = "";
  entity->review_time = "";
  entity->score_reviewed = -1;
  entity->op = "";
  entity->check_priority = 1;
  entity->status = 0;
}

TEST_F(DaoTest, TestWrite) {
  base::FilePath path("reco/module/bad_item/data/reco_item_test.txt");
  base::Time time = base::Time::Now();
  std::string time_str;
  time.ToStringInSeconds(&time_str);

  std::ifstream fin(path.value());
  std::string line;
  reco::RecoItem reco_item;
  std::vector<std::string> flds;

  std::vector<TestCase> cases;
  std::vector<std::pair<double, int>> result;
  result.push_back(std::make_pair(0.5, 1));
  BadItemEntity entity;
  while (std::getline(fin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    reco_item.mutable_identity()->set_item_id(base::ParseUint64OrDie(flds[0]));
    reco_item.add_category("财经");
    reco_item.set_create_time(time_str);
    reco_item.set_source("uc");
    cases.push_back(TestCase());
    cases.back().item_id = base::ParseUint64OrDie(flds[0]);
    cases.back().status = 0;
    cases.back().score = result.front().first;
    ASSERT_TRUE(db_agent_->DeleteBadItem(cases.back().item_id));
    TransferToBadItemEntity(reco_item, result, &entity);

    ASSERT_TRUE(db_agent_->AddBadItem(entity));
  }

  std::unordered_map<uint64, int> reviewed_item;
  std::string sql = "select item_id,status from tb_rubbish_item where create_time>2015-11-19";
  db_agent_->GetReviewedItem(sql, &reviewed_item, -1);

  for (size_t i = 0; i < cases.size(); ++i) {
    auto it = reviewed_item.find(cases[i].item_id);
    ASSERT_TRUE(it != reviewed_item.end()) << cases[i].item_id;
    ASSERT_EQ(it->second, cases[i].status) << cases[i].item_id;
  }
}
}
}
