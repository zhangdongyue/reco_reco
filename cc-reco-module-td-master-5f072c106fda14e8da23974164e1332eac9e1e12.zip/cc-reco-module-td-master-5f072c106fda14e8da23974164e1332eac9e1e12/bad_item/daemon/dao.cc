#include "reco/module/bad_item/daemon/dao.h"

#include <vector>
#include <unordered_map>
#include <sstream>
#include <algorithm>
#include <utility>

#include "serving_base/mysql_util/db_conn_manager.h"
#include "base/common/scoped_ptr.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/hash_function/term.h"
#include "reco/bizc/proto/item.pb.h"
#include "base/time/time.h"

#include "third_party/mysql-connector/cppconn/connection.h"
#include "third_party/mysql-connector/driver/mysql_connection.h"
#include "third_party/mysql-connector/cppconn/statement.h"
#include "third_party/mysql-connector/cppconn/exception.h"
#include "third_party/mysql-connector/cppconn/resultset.h"

namespace reco {
namespace bad_item {
void Dao::Init(const serving_base::mysql_util::DbConnManager::Option &db_option,
               int cache_size,
               const std::string& start_time) {
  db_manager_ = new serving_base::mysql_util::DbConnManager(db_option);
  CHECK_NOTNULL(db_manager_);
  db_manager_->Connect();

  db_connection_ = db_manager_->conn();
  CHECK_NOTNULL(db_connection_);

  reviewed_item_cache_ = new base::LRUCache<uint64, int>(cache_size, false);
  // get item_id record to cache
  const std::string& sql = base::StringPrintf("select item_id,status from tb_rubbish_item where import_time>\"%s\"",  // NOLINT
                                              start_time.c_str());
  GetReviewedItem(sql, NULL, -1);
}

Dao::Dao() {
  sql_str_ = "insert into tb_rubbish_item (item_id,category,title,source,create_time,import_time,";
  sql_str_ += "item_fea_info,post_score,pre_score,rubbish_type,review_comment,score_reviewed,operator,";
  sql_str_ += "check_priority,status) values ";
}

bool Dao::GetReviewedItem(const std::string& sql,
                          std::unordered_map<uint64, int>* reviewed_bad_item,
                          int filter_status) {
  for (int i = 0; i < kRetryTimes; ++i) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      scoped_ptr<sql::ResultSet> res(stmt->executeQuery(sql));

      while (res->next()) {
        std::string item_id_str = res->getString("item_id");
        uint64 item_id = 0;
        if (!base::StringToUint64(item_id_str, &item_id)) {
          LOG(ERROR) << "error item_id: " << item_id_str;
          continue;
        }
        // NOTE(xielang): ask spider, status or reviewed_type to judge ?
        std::string status_str = res->getString("status");
        int status = 0;
        if (!base::StringToInt(status_str, &status)) {
          LOG(ERROR) << "error count : " << status_str;
        }

        if (status == 1 || status == 2) {
          reviewed_item_cache_->Add(item_id, status);
        }

        if ((filter_status == -1 || status == 1 || status == 2) && reviewed_bad_item != NULL) {
          reviewed_bad_item->insert(std::make_pair(item_id, status));
        }
      }
      break;
    } catch(sql::SQLException& e) {  // NOLINT
      LOG(ERROR) << "Exception: " << e.what();
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
    }
  }
  return true;
}

bool Dao::DeleteBadItem(uint64 item_id) {
  // delete item
  const std::string sql = base::StringPrintf("delete from tb_rubbish_item where item_id=%lu", item_id);

  for (int j = 0; j < kRetryTimes; ++j) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      stmt->execute(sql);
      return true;
    } catch (sql::SQLException& e) {  // NOLINT
      LOG(ERROR) << "Exception: " << e.what() << "\n" << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
    }
  }
  return false;
}

bool Dao::AddBadItem(const BadItemEntity& entity) {
  const std::string sql = base::StringPrintf("%s (\"%lu\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",%d,%d,%d,\"%s\",%d,\"%s\",%d,%d)",  // NOLINT
                                             sql_str_.c_str(),
                                             entity.item_id,
                                             entity.category.c_str(),
                                             entity.title.c_str(),
                                             entity.source.c_str(),
                                             entity.create_time.c_str(),
                                             entity.import_time.c_str(),
                                             entity.item_fea_info.c_str(),
                                             entity.post_score,
                                             entity.pre_score,
                                             entity.rubbish_type,
                                             entity.review_comment.c_str(),
                                             entity.score_reviewed,
                                             entity.op.c_str(),
                                             entity.check_priority,
                                             entity.status);

  int status = 0;
  if (reviewed_item_cache_->Get(entity.item_id, &status)) {
    LOG(INFO) << base::StringPrintf("item: %lu has been reviewed, status: %d", entity.item_id, status);
    return true;
  }

  for (int j = 0; j < kRetryTimes; ++j) {
    try {
      scoped_ptr<sql::Statement> stmt(db_connection_->createStatement());
      stmt->executeUpdate(sql);
      return true;
    } catch (sql::SQLException& e) {  // NOLINT
      LOG(ERROR) << "Exception: " << e.what() << "\n" << sql;
      db_manager_->ConnectUntilSuccess();
      db_connection_ = db_manager_->conn();
      CHECK_NOTNULL(db_connection_);
    }
  }
  return false;
}
}
}
