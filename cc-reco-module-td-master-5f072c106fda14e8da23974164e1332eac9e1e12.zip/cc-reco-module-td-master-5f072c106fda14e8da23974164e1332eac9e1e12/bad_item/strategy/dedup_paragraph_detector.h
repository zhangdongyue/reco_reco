#pragma once
#include <string>
#include <vector>
#include <utility>
#include "base/common/base.h"
#include "reco/ml/feature/item/low_quality_hit.h"

namespace reco {
namespace bad_item {
struct ItemInfo;
class DedupParagraphDetector {
 public:
  DedupParagraphDetector() {}
  ~DedupParagraphDetector() {}

  int Detect(const reco::RecoItem& reco_item,
             const reco::ml::item_fea::LowQualityHit& low_quality_hit,
             const std::vector<std::string>& norm_paragraphs);

 private:
  double Process(uint64 item_id,
                 const std::vector<std::string>& paragraphs,
                 const std::string& level1,
                 int insert_num);
};
}
}
