#include "reco/module/bad_item/strategy/dedup_paragraph_detector.h"
#include <string>
#include <set>
#include <unordered_set>
#include <unordered_map>

#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/hash_function/term.h"
#include "base/strings/utf_char_iterator.h"
#include "reco/bizc/proto/bad_item.pb.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "nlp/common/nlp_util.h"
#include "extend/simhash/simhash.h"

namespace reco {
namespace bad_item {
const std::string qiqu_source = "奇趣百科_";

inline bool remit(const reco::RecoItem& reco_item) {
  if (reco_item.identity().type() == reco::kHumor ||
      reco_item.identity().type() == reco::kGossip ||
      reco_item.identity().type() == reco::kPureVideo ||
      reco_item.identity().type() == reco::kSpecial ||
      !reco_item.is_valid()) {
    VLOG(1) << base::StringPrintf("dedup remit by: item_type=%d, producer=%s has_reviewed=%d is_valid=%d",
                                  reco_item.identity().type(),
                                  reco_item.identity().producer().c_str(),
                                  reco_item.has_reviewed(),
                                  reco_item.is_valid());
    return true;
  }

  if (reco_item.identity().has_producer() && (reco_item.identity().manual())) {
    return true;
  }

  if (reco_item.source().find(qiqu_source) != std::string::npos) {
    VLOG(1) << "remit dedup for qiqubaike\t" << reco_item.identity().item_id();
    return true;
  }
  return false;
}

double DedupParagraphDetector::Process(uint64 item_id,
                                       const std::vector<std::string>& paragraphs,
                                       const std::string& level1,
                                       int insert_num) {
  double result = 0;
  std::unordered_set<uint64> signs;
  std::vector<std::string> lines;
  std::string pattern = "。";
  // 段内句子相似判定
  int title_same_count = 0;
  std::set<std::string> title_lines;
  for (int i = 0; i < (int)paragraphs.size(); ++i) {
    signs.clear();
    lines.clear();
    base::SplitString(paragraphs[i], ".!? \t", &lines);

    int count_num = 0;
    for (int j = 0; j < (int)lines.size() && count_num < 5; ++j) {
      size_t index1 = 0;
      std::string current;
      while (index1 < lines[j].size()) {
        int charNum = 0;
        size_t index2 = lines[j].find(pattern, index1);
        if (index2 == std::string::npos) {
          current = lines[j].substr(index1, lines[j].size() - index1);
          if (base::GetUTF8CharNum(current, &charNum) && charNum >= 6 && current.size() >= 10) {
            uint64 sign = base::CalcTermSign(current.c_str(), current.size());
            signs.insert(sign);
            ++count_num;
          }
          if (i == 0 && charNum >= 10) title_lines.insert(current);
          if (i > 0 && count_num > 1 && title_lines.find(current) != title_lines.end()) {
            VLOG(1) << item_id << "\thit title:\t" << current;
            ++title_same_count;
          }
          break;
        }
        current = lines[j].substr(index1, index2 - index1);
        if (base::GetUTF8CharNum(current, &charNum) && charNum >= 6 && current.size() >= 10) {
          uint64 sign = base::CalcTermSign(current.c_str(), current.size());
          signs.insert(sign);
          ++count_num;
          if (i == 0) title_lines.insert(current);
          if (i > 0 && count_num > 1 && title_lines.find(current) != title_lines.end()) {
            VLOG(1) << item_id << "\thit title:\t" << current;
            ++title_same_count;
          }
        }
        index1 = index2 + pattern.size();
      }
    }

    if (count_num - (int)signs.size() > 2) {
      LOG(INFO) << item_id << "\tdedup in one paragraph\t" << paragraphs[i];
      result += 1.0;
    }
  }

  if (title_same_count >= 3) {
    LOG(INFO) << item_id << "\tdedup line in paragraphs, same as title";
    result += 1.0;
  }
  // 段落之间相似判定
  std::vector<std::pair<uint64, int>> hashs;
  int char_num = 0;
  std::unordered_map<uint64, std::pair<int, int>> sim_dict;

  std::string normalized_line;
  // title 不算在堆砌的计算中
  for (size_t i = 1; i < paragraphs.size(); ++i) {
    nlp::util::NormalizeLineCopy(paragraphs[i], &normalized_line);
    if (!base::GetUTF8CharNum(normalized_line, &char_num) ||
        normalized_line == " " || char_num <= 8) {
      continue;
    }
    hashs.push_back(std::make_pair(simhash::CharikarSimHash::GetTokenHash(normalized_line), char_num));
    sim_dict[hashs.back().first] = std::make_pair(0, i);
  }

  std::unordered_set<uint64> occured_ids;
  for (int i = 0; i < (int)hashs.size() - 1; ++i) {
    if (occured_ids.find(hashs[i].first) != occured_ids.end()) continue;
    occured_ids.insert(hashs[i].first);
    for (int j = i + 1; j < (int)hashs.size(); ++j) {
      int distance = simhash::CharikarSimHash::HammingDistance(hashs[i].first, hashs[j].first);
      if (distance < 3) {
        sim_dict[hashs[i].first].first += 1;
        VLOG(1) << base::StringPrintf("%lu:\t%s vs %s", item_id,
                                      paragraphs[sim_dict[hashs[i].first].second].c_str(),
                                      paragraphs[sim_dict[hashs[j].first].second].c_str());
      }
    }
  }

  float sim_ratio = 0;
  for (auto it = sim_dict.begin(); it != sim_dict.end(); ++it) {
    sim_ratio += it->second.first;
  }
  if (sim_ratio > 3) sim_ratio *= 2;
  float total_size = hashs.size() + insert_num;
  VLOG(1) << "dedup detection, sim ratio:\t" << item_id << "\t" << sim_ratio << "\t" << total_size;
  if (!hashs.empty()) {
    result += sim_ratio / total_size;
  }
  if (level1 == "美食") result /= 2;
  return result;
}

int DedupParagraphDetector::Detect(const reco::RecoItem& reco_item,
                                   const reco::ml::item_fea::LowQualityHit& low_quality_hit,
                                   const std::vector<std::string>& norm_paragraphs) {
  double dedup_yes = 0.2;
  double dedup_suspect = 0.1;
  auto it = GlobalDataIns::instance().GetLowQualityThresholds().get()->find("dedup_suspect");
  if (it != GlobalDataIns::instance().GetLowQualityThresholds().get()->end()) {
    dedup_suspect = it->second;
  }
  it = GlobalDataIns::instance().GetLowQualityThresholds().get()->find("dedup_yes");
  if (it != GlobalDataIns::instance().GetLowQualityThresholds().get()->end()) {
    dedup_yes = it->second;
  }

  // remit some item type
  if (remit(reco_item)) return 0;
  uint64 item_id = reco_item.identity().item_id();
  int total = reco_item.image_size();
  std::set<int64> image_hashes;
  for (int i = 0;  i < (int)reco_item.image_size(); ++i) {
    if (reco_item.image(i).simhash() == 0) {
      --total;
      continue;
    }
    if ((reco_item.image(i).height() < 200 || reco_item.image(i).width() < 200) &&
        reco_item.image(i).height() * reco_item.image(i).width() < 100000) {
      --total;
      continue;
    }
    if (!image_hashes.insert(reco_item.image(i).simhash()).second) {
      VLOG(1) << reco_item.identity().item_id() << "\tsame image\t"
              << reco_item.image(i).simhash();
    }
  }

  int image_dedup_threshold = 2;
  if (low_quality_hit.content_basic_terms.size() >= 2000) {
    image_dedup_threshold *= 3;
  } else if (low_quality_hit.content_basic_terms.size() >= 800) {
    image_dedup_threshold *= 2;
  }
  int gap = total - (int)image_hashes.size();
  if (gap >= 2 * image_dedup_threshold ||
      (gap >= image_dedup_threshold && (float)gap / (float)image_hashes.size() > 0.4)) {
    LOG(INFO) << reco_item.identity().item_id() << "\timage dedup: ";
    return 2;
  }

  double score = 0;
  if ((int)image_hashes.size() != (int)reco_item.image_size()) {
    score += 0.05;
  }

  // 如果是图片新闻, 且图片不堆砌, 则认为不堆砌
  if (reco_item.identity().type() == reco::kPicture) return 0;

  // 正文图文插花情况下, 在图片下出现的第一段短文本不记录在堆砌里
  std::unordered_set<std::string> remit;
  std::vector<std::string> paragraphs;
  const std::string& content = reco_item.content();
  std::string pattern = "\1";
  size_t index1 = 0;
  size_t index2 = 0;
  int image_count = 0;
  int insert_num = 0;
  int dedup_num = 0;
  std::string nospace_line;
  std::string line;
  std::vector<std::string> tokens;
  index2 = content.find(pattern, index1);
  while (index1 != std::string::npos) {
    ++image_count;
    tokens.clear();
    base::SplitString(content.substr(index1, index2 - index1), "\n", &tokens);
    int line_count = 0;
    for (int i = 0; i < (int)tokens.size(); ++i) {
      nlp::util::NormalizeLineInPlaceS(&tokens[i]);
      reco::ml::item_fea::RemoveHtmlTag(tokens[i], &line);
      base::RemoveChars(line, base::kWhitespace, &nospace_line);
      int char_num = 0;
      if (!base::GetUTF8CharNum(nospace_line, &char_num) || char_num == 0) continue;
      ++line_count;
      if (image_count > 1 && line_count == 1 && char_num <= 20) {
        remit.insert(line);
        ++insert_num;
      } else {
        // 如果在图底下出现过, 又在非图底下出现过, 记录次数
        if (char_num > 8 && remit.find(line) != remit.end()) {
          VLOG(1) << item_id << "\toccured line:\t" << line;
          ++dedup_num;
        }
      }
    }
    if (index2 == std::string::npos) {
      index1 = std::string::npos;
      continue;
    }
    index1 = index2 + pattern.size();
    index2 = content.find(pattern, index1);
  }
  paragraphs.push_back(reco_item.normalized_title());
  for (int i = 0; i < (int)norm_paragraphs.size(); ++i) {
    reco::ml::item_fea::RemoveHtmlTag(norm_paragraphs[i], &line);
    if (remit.find(line) != remit.end()) continue;
    paragraphs.push_back(line);
  }
  if ((float)dedup_num / (float)(paragraphs.size() + insert_num) > 0.1) {
    LOG(INFO) << item_id << "\thit occured lines below image too much times";
    return 2;
  }
  std::string cate = "";
  if (reco_item.category_size() > 0) cate = reco_item.category(0);
  score = Process(item_id, paragraphs, cate, insert_num);
  if (score > dedup_yes) return 2;
  if (score > dedup_suspect) return 1;
  return 0;
}
}
}
