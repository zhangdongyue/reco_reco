#pragma once
#include <unordered_set>
#include <unordered_map>
#include <string>
#include <vector>
#include "base/file/file_path.h"
#include "extend/static_dict/dawg/dictionary.h"
#include "reco/ml/feature/item/low_quality_hit.h"

namespace reco {
namespace bad_item {

struct ItemInfo;

class BluffingTitleDetector {
 public:
  BluffingTitleDetector() {}
  ~BluffingTitleDetector() {}

  int Detect(const reco::RecoItem& reco_item,
             const reco::ml::item_fea::LowQualityHit& low_quality_hit,
             const std::vector<std::string>& norm_paragraphs,
             const std::unordered_map<std::string, int>& hit_nums,
             const std::vector<int>& punctuation_nums);

 private:
  double Process(const reco::RecoItem& reco_item,
                 const std::string& norm_title,
                 const std::unordered_map<std::string, int>& hit_nums,
                 const std::vector<int>& punctuation_nums,
                 double bluffing_suspect,
                 double bluffing_yes);

  bool DetectShortParagraph(const reco::RecoItem& reco_item,
                            const std::string& norm_title,
                            const std::vector<std::string>& norm_paragraphs);
 private:
  const std::unordered_map<std::string, int>* rubbish_sources;
};
}
}
