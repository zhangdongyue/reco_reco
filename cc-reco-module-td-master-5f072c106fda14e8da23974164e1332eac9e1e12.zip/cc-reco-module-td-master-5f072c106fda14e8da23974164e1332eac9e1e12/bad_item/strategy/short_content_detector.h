#pragma once
#include <vector>
#include <string>
#include <unordered_map>
#include <set>
#include <utility>
#include "base/common/basic_types.h"
#include "base/file/file_path.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/ml/feature/item/low_quality_hit.h"

namespace extend {
class WebClient;
}

namespace reco {
namespace bad_item {
struct ItemInfo;

class ShortContentDetector {
 public:
  ShortContentDetector();
  ~ShortContentDetector();

  int Detect(const reco::RecoItem& reco_item,
             const reco::ml::item_fea::LowQualityHit& low_quality_hit);

 private:
  void ProcessImages(const RecoItem& item, int* useful_image_num,
                     int* long_image_num, int* gif_num,
                     double image_height_threshold);

  bool Remit(const reco::RecoItem& reco_item);
};
}
}
