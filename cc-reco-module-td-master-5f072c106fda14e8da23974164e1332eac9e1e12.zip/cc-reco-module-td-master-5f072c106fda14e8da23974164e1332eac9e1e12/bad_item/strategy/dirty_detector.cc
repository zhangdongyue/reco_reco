#include "reco/module/bad_item/strategy/dirty_detector.h"
#include <algorithm>
#include <fstream>
#include <map>
#include <utility>

#include "base/hash_function/term.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "base/strings/utf_char_iterator.h"
#include "base/hash_function/city.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"

namespace reco {
namespace bad_item {
inline bool isNumOrAlpha(char c) {
  if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == ' ') {
    return true;
  }
  return false;
}

void DirtyDetector::AddWeight(uint64 item_id,
                              const std::string& feature,
                              std::unordered_set<uint64>* calced_features,
                              float* model_value) {
  uint64 sign = base::CalcTermSign(feature.data(), feature.size());
  if (calced_features->find(sign) == calced_features->end() &&
      dirty_model->find(sign) != dirty_model->end()) {
    calced_features->insert(sign);
    *model_value = *model_value + dirty_model->find(sign)->second;
    VLOG(1) << item_id << "\thit dirty model feature:\t" << feature
            << "\tscore:\t" << dirty_model->find(sign)->second;
  }
}

int DirtyDetector::kMaxTermNum = 3000;

bool DirtyDetector::AllowedKill(const std::string& cate,
                                const reco::RecoItem& reco_item,
                                bool is_video) {
  if (!is_video) {
    if (reco_item.source().find("竞品") != std::string::npos ||
        reco_item.source().find("cp_wemedia_uc_") != std::string::npos) {
      return true;
    }
    std::string key = base::StringPrintf("can_kill\t%s", cate.c_str());
    if (low_quality_thresholds->find(key) != low_quality_thresholds->end() &&
        1 == low_quality_thresholds->find(key)->second) {
      return true;
    }
  } else {
    if (reco_item.video_meta_settings_size() > 0 &&
        reco_item.video_meta_settings(0).frame_porn_labels_size() > 0) {
      std::vector<std::string> tokens;
      for (int i = 0; i < reco_item.video_meta_settings(0).frame_porn_labels_size(); ++i) {
        tokens.clear();
        base::SplitString(reco_item.video_meta_settings(0).frame_porn_labels(0), "\t", &tokens);
        if (tokens.size() != 2) {
          LOG(ERROR) << "error record of frame porn result!\t" << reco_item.identity().item_id();
          continue;
        }
        if (tokens[0] == "seqing") return true;
      }
    }
  }
  return false;
}

void DirtyDetector::ReWeight(const std::string cate, int type, float* score) {
  std::string key = "";
  if (type == 0) {
    key = base::StringPrintf("dirty_title\t%s", cate.c_str());
  } else {
    key = base::StringPrintf("dirty_content\t%s", cate.c_str());
  }
  if (low_quality_thresholds->find(key) != low_quality_thresholds->end()) {
    *score = *score - low_quality_thresholds->find(key)->second;
  }
}

bool DirtyDetector::IsSimbleCase(uint64 item_id, const std::string& title) {
  std::vector<int> places;
  float count = 0;
  std::string temp;
  int char_num = 0;
  for (int i = 0; i < (int)title.size(); ++i) {
    char_num = 0;
    temp.clear();
    temp += title[i];
    if (!base::GetUTF8CharNum(temp, &char_num)) continue;
    if (title[i] == '.' || title[i] == '_' ||
        title[i] == '\'' || title[i] == '$' ||
        title[i] == '*' || title[i] == '#' ||
        title[i] == '@' || title[i] == '-' ||
        title[i] == '~') {
      VLOG(1) << item_id << "\thit simble:\t" << title[i] << "\t" << i;
      places.push_back(i);
    }
  }
  for (int i = 0; i < (int)places.size() - 1; ++i) {
    if (places[i + 1] - places[i] > 1 && places[i + 1] - places[i] < 7) {
      int alpha_num_count = 0;
      for (int j = places[i] + 1; j < places[i + 1]; ++j) {
        if (isNumOrAlpha(title[j])) {
          ++alpha_num_count;
        }
      }
      if (alpha_num_count != (places[i + 1] - places[i] - 1)) {
        char_num = 0;
        temp = title.substr(places[i] + 1, places[i + 1] - places[i] - 1);
        VLOG(1) << item_id << "\t" << temp << "\t" <<  alpha_num_count
                << "\t" << places[i + 1] - places[i] - 1;
        if (base::GetUTF8CharNum(temp, &char_num)) {
          ++count;
        }
      }
    }
  }
  if (count >= 2) {
    return true;
  }
  return false;
}

float DirtyDetector::DetectWithModel(int type, uint64 item_id, bool remit_content, double threshold,
                                     const std::unordered_map<std::string, std::vector<std::string> >& dirty_features, // NOLINT
                                     const std::unordered_map<std::string, int>& hit_nums) {
  float model_value = 0;
  int hit_rule_num = 0;
  int hit_keyword_num = 0;
  std::unordered_set<uint64> calced_features;
  if (type == 0) {
    if (dirty_features.find("title_model") != dirty_features.end()) {
      for (int i = 0; i < (int)dirty_features.find("title_model")->second.size(); ++i) {
        AddWeight(item_id, dirty_features.find("title_model")->second[i], &calced_features, &model_value);
      }
    }
    if (hit_nums.find("dirty_title_rule") != hit_nums.end()) {
      hit_rule_num = hit_nums.find("dirty_title_rule")->second;
    }
    if (hit_nums.find("dirty_title_keyword") != hit_nums.end()) {
      hit_keyword_num = hit_nums.find("dirty_title_keyword")->second;
    }
    if (1 / (1 + std::exp(0 - model_value)) <= (threshold + 0.1)) {
      if (hit_rule_num >= 3) {
        AddWeight(item_id, "title_hit_rule_num:high", &calced_features, &model_value);
      } else {
        if (hit_keyword_num >= 3) {
          AddWeight(item_id, "title_hit_keyword_num:high", &calced_features, &model_value);
        } else {
          if (hit_rule_num > 0 && hit_rule_num < 3) {
            AddWeight(item_id, "title_hit_rule_num:low", &calced_features, &model_value);
          } else if (hit_keyword_num > 0 && hit_keyword_num < 3) {
            AddWeight(item_id, "title_hit_keyword_num:low", &calced_features, &model_value);
          }
        }
      }
    }
  } else {
    if (dirty_features.find("content_model") != dirty_features.end()) {
      for (int i = 0; i < (int)dirty_features.find("content_model")->second.size(); ++i) {
        AddWeight(item_id, dirty_features.find("content_model")->second[i], &calced_features, &model_value);
      }
    }
    int threshold_high = 8;
    if (remit_content) threshold_high = 12;
    if (hit_nums.find("dirty_content_rule") != hit_nums.end()) {
      hit_rule_num = hit_nums.find("dirty_content_rule")->second;
    }
    if (hit_nums.find("dirty_content_keyword") != hit_nums.end()) {
      hit_keyword_num = hit_nums.find("dirty_content_keyword")->second;
    }
    if (1 / (1 + std::exp(0 - model_value)) <= (threshold + 0.1)) {
      if (hit_rule_num >= 3) {
        AddWeight(item_id, "content_hit_rule_num:high", &calced_features, &model_value);
      } else {
        if (hit_keyword_num >= threshold_high) {
          AddWeight(item_id, "content_hit_keyword_num:high", &calced_features, &model_value);
        } else {
          if (hit_rule_num > 0 && hit_rule_num < 3) {
            AddWeight(item_id, "content_hit_rule_num:low", &calced_features, &model_value);
          } else if (hit_keyword_num > 0 && hit_keyword_num < threshold_high && !remit_content) {
            AddWeight(item_id, "content_hit_keyword_num:low", &calced_features, &model_value);
          }
        }
      }
    }
  }
  double score = 1 / (1 + std::exp(0 - model_value));
  return score;
}

void DirtyDetector::Process(const reco::RecoItem& reco_item,
                            const std::string& norm_title,
                            const std::unordered_map<std::string, std::vector<std::string> >& dirty_features,
                            const std::unordered_map<std::string, int>& hit_nums,
                            int* status) {
  uint64 item_id = reco_item.identity().item_id();
  bool is_video = (reco_item.identity().type() == reco::kPureVideo);
  // title 过符号, 暂时将 title 中符号文字交叉这种 case 算作低俗
  if (!norm_title.empty() && IsSimbleCase(item_id, norm_title) && !is_video) {
    VLOG(1) << item_id << "\t" << norm_title << "\t" << "simble case!";
    *status = 1;
  }

  /////////////////////////
  if (dirty_features.find("title_rule") != dirty_features.end()) {
    for (int i = 0; i < (int)dirty_features.find("title_rule")->second.size(); ++i) {
      VLOG(1) << item_id << "\tdirty rule:\t" << dirty_features.find("title_rule")->second[i];
    }
  }
  if (dirty_features.find("title_keyword") != dirty_features.end()) {
    for (int i = 0; i < (int)dirty_features.find("title_keyword")->second.size(); ++i) {
      VLOG(1) << item_id << "\tdirty keyword:\t" << dirty_features.find("title_keyword")->second[i];
    }
  }
  /////////////////////////////

  double kLrYesTitle = 0.9;
  double kLrSuspectTitle = 0.75;
  double kLrYesContent = 0.94;
  double kLrSuspectContent = 0.85;
  double kLrYesMerge= 0.85;
  double kLrSuspectMerge = 0.62;
  double kLrMinMerge = 0.4;
  double kLrMinTitle = 0.65;
  double kLrMinContent = 0.7;
  if (low_quality_thresholds->find("dirty_lr_yes_title") != low_quality_thresholds->end()) {
    kLrYesTitle = low_quality_thresholds->find("dirty_lr_yes_title")->second;
  }
  if (low_quality_thresholds->find("dirty_lr_suspect_title") != low_quality_thresholds->end()) {
    kLrSuspectTitle = low_quality_thresholds->find("dirty_lr_suspect_title")->second;
  }
  if (low_quality_thresholds->find("dirty_lr_yes_content") != low_quality_thresholds->end()) {
    kLrYesContent = low_quality_thresholds->find("dirty_lr_yes_content")->second;
  }
  if (low_quality_thresholds->find("dirty_lr_suspect_content") != low_quality_thresholds->end()) {
    kLrSuspectContent = low_quality_thresholds->find("dirty_lr_suspect_content")->second;
  }
  if (low_quality_thresholds->find("dirty_lr_yes_merge") != low_quality_thresholds->end()) {
    kLrYesMerge = low_quality_thresholds->find("dirty_lr_yes_merge")->second;
  }
  if (low_quality_thresholds->find("dirty_lr_suspect_merge") != low_quality_thresholds->end()) {
    kLrSuspectMerge = low_quality_thresholds->find("dirty_lr_suspect_merge")->second;
  }
  if (low_quality_thresholds->find("dirty_lr_min_merge") != low_quality_thresholds->end()) {
    kLrMinMerge = low_quality_thresholds->find("dirty_lr_min_merge")->second;
  }
  if (low_quality_thresholds->find("dirty_lr_min_title") != low_quality_thresholds->end()) {
    kLrMinTitle = low_quality_thresholds->find("dirty_lr_min_title")->second;
  }
  if (low_quality_thresholds->find("dirty_lr_min_content") != low_quality_thresholds->end()) {
    kLrMinContent = low_quality_thresholds->find("dirty_lr_min_content")->second;
  }

  // video 独立阈值
  if (is_video) {
    if (low_quality_thresholds->find("video_dirty_lr_yes_title") != low_quality_thresholds->end()) {
      kLrSuspectTitle = low_quality_thresholds->find("video_dirty_lr_yes_title")->second;
    }
    if (low_quality_thresholds->find("video_dirty_lr_suspect_title") != low_quality_thresholds->end()) {
      kLrSuspectTitle = low_quality_thresholds->find("video_dirty_lr_suspect_title")->second;
    }
  }

  std::string cate = "";
  if (reco_item.category_size() > 0) cate = reco_item.category(0);

  bool remit_content = false;
  std::string key = base::StringPrintf("remit_content\t%s", cate.c_str());
  if (low_quality_thresholds->find(key) != low_quality_thresholds->end() &&
      low_quality_thresholds->find(key)->second == 1) {
    remit_content = true;
  }

  float score = DetectWithModel(0, item_id, remit_content, kLrSuspectTitle, dirty_features, hit_nums);
  ReWeight(cate, 0, &score);
  VLOG(1) << item_id << "\ttitle dirty lr score:\t" << score;
  if (score > kLrYesTitle) {
    if (AllowedKill(cate, reco_item, is_video)) {
      *status = 2;
    } else {
      *status = 1;
    }
    return;
  } else if (score > kLrSuspectTitle) {
    *status = 1;
  }

  // video 暂时先不考虑 content
  if (!is_video) {
    float score_content = DetectWithModel(1, item_id, remit_content, kLrSuspectContent, dirty_features, hit_nums); // NOLINT
    // merge title & content scores
    float merged_score = 0;
    float conf_title = 0.7;
    key = base::StringPrintf("dirty_conf_title\t%s", cate.c_str());
    if (low_quality_thresholds->find(key) != low_quality_thresholds->end()) {
      conf_title = low_quality_thresholds->find(key)->second;
    }
    float conf_content = 1 - conf_title;
    if (score > kLrMinTitle || score_content > kLrMinContent) {
      merged_score = score * conf_title + score_content * conf_content;
      VLOG(1) << item_id << "\tmerger dirty lr score:\t" << merged_score;
    }

    ReWeight(cate, 1, &score_content);
    VLOG(1) << item_id << "\tcontent dirty lr score:\t" << score_content;
    if (score_content > kLrYesContent) {
      if (AllowedKill(cate, reco_item, is_video)) {
        *status = 2;
      } else {
        *status = 1;
      }
      return;
    } else if (score_content > kLrSuspectContent && merged_score > kLrMinMerge) {
      *status = 1;
    }
    if (merged_score > kLrYesMerge) {
      if (AllowedKill(cate, reco_item, is_video)) {
        *status = 2;
      } else {
        *status = 1;
      }
      return;
    } else if (merged_score > kLrSuspectMerge) {
      *status = 1;
    }
  }
  return;
}

void DirtyDetector::GetSubClass(const reco::RecoItem& reco_item,
                                const std::string& norm_content,
                                const std::vector<std::string>& paragraphs,
                                const std::unordered_map<std::string, std::vector<std::string> >& dirty_features, // NOLINT
                                const std::vector<std::pair<std::string, int >>& ngrams,
                                std::vector<int>* sub_status) {
  uint64 item_id = reco_item.identity().item_id();
  std::unordered_set<int> sort_results;
  std::string cate = "";
  std::string sub_cate = "";
  if (reco_item.category_size() > 0) cate = reco_item.category(0);
  if (reco_item.category_size() > 1) sub_cate = reco_item.category(1);
  if (cate == "幽默") sort_results.insert(13);
  if (cate == "历史") sort_results.insert(5);
  if (cate == "健康" || cate == "育儿" || sub_cate == "两性健康") {
    sort_results.insert(7);
  }
  if (cate == "动漫") sort_results.insert(11);
  int content_char_num = 0;
  float ave_para_length = 0;
  if (!base::GetUTF8CharNum(norm_content, &content_char_num)) {
    LOG(ERROR) << "cannot calc content length:\t" << item_id;
  }
  if (!paragraphs.empty()) {
    ave_para_length = (float)content_char_num / (float)paragraphs.size();
  }
  if ((content_char_num < 300 || ave_para_length < 100) &&
      reco_item.image_size() >= 3 &&
      (cate == "娱乐" || cate == "时尚")) {
    sort_results.insert(4);
  }
  if (cate == "美女写真") sort_results.insert(4);

  if (cate == "娱乐" || cate == "体育") sort_results.insert(3);

  if (dirty_features.find("title_rule") != dirty_features.end()) {
    for (int i = 0; i < (int)dirty_features.find("title_rule")->second.size(); ++i) {
      auto it = dirty_sub_rule->find(dirty_features.find("title_rule")->second[i]);
      if (it != dirty_sub_rule->end()) sort_results.insert(it->second);
    }
  }
  if (dirty_features.find("title_keyword") != dirty_features.end()) {
    for (int i = 0; i < (int)dirty_features.find("title_keyword")->second.size(); ++i) {
      auto it = dirty_sub_rule->find(dirty_features.find("title_keyword")->second[i]);
      if (it != dirty_sub_rule->end()) sort_results.insert(it->second);
    }
  }
  if (dirty_features.find("content_rule") != dirty_features.end()) {
    for (int i = 0; i < (int)dirty_features.find("content_rule")->second.size(); ++i) {
      auto it = dirty_sub_rule->find(dirty_features.find("content_rule")->second[i]);
      if (it != dirty_sub_rule->end()) sort_results.insert(it->second);
    }
  }
  if (dirty_features.find("content_keyword") != dirty_features.end()) {
    for (int i = 0; i < (int)dirty_features.find("content_keyword")->second.size(); ++i) {
      auto it = dirty_sub_rule->find(dirty_features.find("content_keyword")->second[i]);
      if (it != dirty_sub_rule->end()) sort_results.insert(it->second);
    }
  }

  std::vector<std::string> tokens;
  for (int i = 0; i < (int)ngrams.size(); ++i) {
    if (ngrams[i].second != 0) continue;
    auto it = dirty_sub_rule->find(ngrams[i].first);
    if (it != dirty_sub_rule->end()) {
      sort_results.insert(it->second);
    }
    tokens.clear();
    base::SplitString(ngrams[i].first, "#", &tokens);
    if (tokens.size() == 2) {
      std::string temp = base::StringPrintf("%s%s", tokens[0].c_str(), tokens[1].c_str());
      it = dirty_sub_rule->find(temp);
      if (it != dirty_sub_rule->end()) {
        sort_results.insert(it->second);
      }
    }
  }
  for (auto it = sort_results.begin(); it != sort_results.end(); ++it) {
    sub_status->push_back(*it);
  }
}

int DirtyDetector::Detect(bool is_video,
                          const reco::RecoItem& reco_item,
                          const reco::ml::item_fea::LowQualityHit& low_quality_hit,
                          const std::unordered_map<std::string, std::vector<std::string> >& dirty_features,
                          const std::unordered_map<std::string, int>& hit_nums,
                          int* video_dirty_status) {
  dirty_model = GlobalDataIns::instance().GetDirtyModel().get();
  rubbish_sources = GlobalDataIns::instance().GetRubbishSource().get();
  // 命中低俗源，直接打 2 分
  low_quality_thresholds = GlobalDataIns::instance().GetLowQualityThresholds().get();
  int status = 0;
  std::string norm_source;
  nlp::util::NormalizeLineCopy(reco_item.source(), &norm_source);
  auto it = rubbish_sources->find(norm_source);
  if (it != rubbish_sources->end() && it->second == 2) {
    return 2;
  }
  Process(reco_item, low_quality_hit.nospace_title, dirty_features, hit_nums, &status);
  // 视频特殊处理一下，计算低俗类型
  if (is_video) {
    if (status > 0) {
      *video_dirty_status = ((*video_dirty_status) | (1));
    }
  }
  return status;
}

void DirtyDetector::DetectSub(const reco::RecoItem& reco_item,
                              const reco::ml::item_fea::LowQualityHit& low_quality_hit,
                              const std::vector<std::string>& paragraphs,
                              const std::unordered_map<std::string, std::vector<std::string> >& dirty_features, // NOLINT
                              std::vector<int>* sub_status) {
  dirty_sub_rule = GlobalDataIns::instance().GetDirtySubRule().get();
  GetSubClass(reco_item, low_quality_hit.nospace_content, paragraphs,
              dirty_features, low_quality_hit.ngrams, sub_status);
}
}  // namespace bad_item
}  // namespace reco
