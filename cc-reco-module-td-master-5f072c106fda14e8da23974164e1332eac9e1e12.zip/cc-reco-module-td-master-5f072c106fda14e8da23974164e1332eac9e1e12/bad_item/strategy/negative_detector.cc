#include "reco/module/bad_item/strategy/negative_detector.h"
#include <algorithm>
#include <map>
#include <vector>
#include <string>
#include <fstream>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <set>

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "base/file/file_path.h"
#include "base/hash_function/term.h"
#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "extend/static_dict/dawg/dictionary.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"

DEFINE_bool(negative_content, false, "if set, use content to decide, or only use title");

namespace reco {
namespace bad_item {

int NegativeDetector::Detect(const reco::RecoItem& reco_item,
                             const reco::ml::item_fea::LowQualityHit& low_quality_hit) {
  const dawgdic::Dictionary* negative_rules = GlobalDataIns::instance().GetNegativeRules().get();
  const dawgdic::Dictionary* negative_keywords = GlobalDataIns::instance().GetNegativeKeywords().get();
  uint64 item_id = reco_item.identity().item_id();
  std::unordered_set<std::string> hit_terms;
  hit_terms.clear();
  // title 过强规则
  low_quality_hit.DetectWithDict(*negative_rules, low_quality_hit.title_basic_terms,
                                 low_quality_hit.nospace_title, &hit_terms);
  if (!hit_terms.empty()) {
    LOG(INFO) << "title negative detector:\t" << item_id << "\trule yes";
    return 2;
  }

  hit_terms.clear();
  if (FLAGS_negative_content) {
    // content 过强规则
    low_quality_hit.DetectWithDict(*negative_rules, low_quality_hit.content_basic_terms,
                                   low_quality_hit.nospace_content, &hit_terms);
    if (!hit_terms.empty()) {
      LOG(INFO) << "content negative detector:\t" << item_id << "\trule yes";
      return 2;
    }
  }

  // title 过关键字
  hit_terms.clear();
  low_quality_hit.DetectWithDict(*negative_keywords, low_quality_hit.title_basic_terms,
                                 low_quality_hit.nospace_title, &hit_terms);
  if (!hit_terms.empty()) {
    LOG(INFO) << "negative detector:\t" << item_id << "\ttitle keyword yes";
    return 1;
  }

  hit_terms.clear();
  if (FLAGS_negative_content) {
    // content 过关键字
    low_quality_hit.DetectWithDict(*negative_keywords, low_quality_hit.content_basic_terms,
                                   low_quality_hit.nospace_content, &hit_terms);
    if (!hit_terms.empty()) {
      LOG(INFO) << "negative detector:\t" << item_id << "\tcontent keyword yes";
      return 1;
    }
  }
  return 0;
}
}
}
