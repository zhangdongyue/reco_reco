#pragma once
#include <string>
#include <vector>
#include <utility>
#include <unordered_map>
#include <unordered_set>
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/ml/feature/item/low_quality_hit.h"
#include "reco/ml/feature/item/image_adver.h"
#include "nlp/time/time_recognizer.h"
#include "base/testing/gtest_prod.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

namespace base {
class FilePath;
}
class RecoItem;
namespace reco {
namespace bad_item {
// 目前从 bad item server 判定的低质类型共有九种，分四类
// 第一类：文章质量差 包括：文不对题, 广告软文（尾部杂质）, 空短文章, 堆砌文章
// 第二类：文章内容查 包括：色情低俗, 标题党
// 第三类：敏感文章 包括：政治敏感, 负面新闻(思想负面低潮)
// 第四类：垃圾视频
class ErrorTitleDetector;
class AdvertorialDetector;
class ShortContentDetector;
class DedupParagraphDetector;

class DirtyDetector;
class BluffingTitleDetector;

class PoliticsDetector;
class NegativeDetector;
class VideoDetector;
// 总控, 分别判定当前 item 是否是九种不同的低质类型中的一种, 并返回
class RubbishDetector {
 public:
  explicit RubbishDetector(const reco::redis::RedisCli* redis_cli_);
  ~RubbishDetector();

  // 常用对外接口
  void Detect(const reco::RecoItem& reco_item, reco::ContentAttr* content_attr);

  // 常用对外接口
  void Detect(const reco::RecoItem& reco_item,
              std::unordered_map<std::string, std::vector<int> >* results);

 private:
  bool Remit(const std::unordered_set<std::string>& remit_sources, const reco::RecoItem& reco_item);

  void GenerateParagraphs(const reco::RecoItem& reco_item,
                          std::vector<std::string>* paragraphs,
                          std::vector<std::string>* norm_paragraphs);

  // 用于统计各种命中特征
  // adver_features 存储广告命中的各种特征
  // dirty_features 存储低俗命中的各种特征
  // hit_nums 记录各类低质类型命中的规则/关键词 的数量
  // punctuation_nums 一共有三维，分别代表 title start/middle/end 命中数量
  void ProcessFeatures(std::unordered_map<std::string, std::vector<std::string> >* adver_features,
                       std::unordered_map<std::string, std::vector<std::string> >* dirty_features,
                       std::unordered_map<std::string, int>* hit_nums,
                       std::vector<int>* punctuation_nums);

  ErrorTitleDetector* error_title_detector_;
  AdvertorialDetector* ad_detector_;
  ShortContentDetector* short_content_detector_;
  DedupParagraphDetector* dedup_detector_;
  DirtyDetector* dirty_detector_;
  PoliticsDetector* politics_detector_;
  BluffingTitleDetector* bluffing_title_detector_;
  NegativeDetector* negative_detector_;

  reco::ml::item_fea::LowQualityHit* low_quality_hit_;
  reco::ml::item_fea::ImageAdver* image_adver_;

  const reco::redis::RedisCli* redis_cli;
  FRIEND_TEST(BadItemTest, DetectBadItem);
};
}
}
