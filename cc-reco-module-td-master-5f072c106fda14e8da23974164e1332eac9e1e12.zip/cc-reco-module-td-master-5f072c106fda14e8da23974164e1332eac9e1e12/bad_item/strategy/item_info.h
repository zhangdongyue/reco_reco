#pragma once
#include <string>
#include <utility>
#include <vector>

#include "base/common/slice.h"
#include "nlp/common/term_container.h"

namespace reco {
class RecoItem;

namespace bad_item {

struct ItemInfo {
  ItemInfo() {
    reco_item = NULL;
  }

  void clear() {
    reco_item = NULL;
    media_level = 0;
    orig_source_media.clear();
    source_media.clear();
    level1.clear();
    level2.clear();
    norm_title.clear();
    norm_content.clear();
    image_desc.clear();
    terms.renew();
    ngrams.clear();
    basic_content_ngrams.clear();
    basic_image_desc_ngrams.clear();
    basic_title_ngrams.clear();
    paragraphs.clear();
    norm_paragraphs.clear();
  }

  const reco::RecoItem* reco_item;
  // 这里记录 media
  std::string source_media;
  std::string orig_source_media;
  int media_level;

  std::string level1;
  std::string level2;
  // 这里的 title 和 content 都去掉了 kWhiteSpace
  std::string norm_title;
  std::string norm_content;
  std::string image_desc;

  nlp::term::TermContainer terms;

  // 粒度: basic term
  std::vector<base::Slice> basic_title_ngrams;
  std::vector<base::Slice> basic_content_ngrams;
  std::vector<base::Slice> basic_image_desc_ngrams;
  // 各种 ngram , type 0: title, type 1: content (with image desc)
  std::vector<std::pair<std::string, int>> ngrams;
  // paragraphs 不去掉 kWhiteSpace, 且不包含 title
  // 想用带 title 的后期自己加上 norm_title 即可
  std::vector<std::string> paragraphs;
  std::vector<std::string> norm_paragraphs;
};
}
}
