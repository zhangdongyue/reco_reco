#pragma once

#include <cstdatomic>
#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#include "base/common/base.h"
#include "base/file/file_path.h"
#include "reco/ml/feature/item/low_quality_hit.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "nlp/common/term_container.h"
#include "extend/static_dict/dawg/dictionary.h"

namespace reco {
namespace bad_item {
class AdvertorialDetector {
 public:
  AdvertorialDetector();
  ~AdvertorialDetector();
  int Detect(const reco::RecoItem& reco_item,
             const reco::redis::RedisCli* redis_cli,
             const reco::ml::item_fea::LowQualityHit& low_quality_hit,
             const std::vector<std::string>& norm_paragraphs,
             const std::unordered_map<std::string, std::vector<std::string> >& adver_features,
             const std::unordered_map<std::string, int>& hit_nums,
             bool has_adver_image,
             std::vector<int>* sub_status);

 private:
  bool IsAdverMedia(const std::string& media);

  bool ProcessOcr(const reco::RecoItem& reco_item,
                  const reco::redis::RedisCli* redis_cli,
                  const reco::ml::item_fea::LowQualityHit& low_quality_hit);

  bool RightDown(uint64 item_id,
                 const reco::RecoItem& reco_item,
                 const std::string& content,
                 bool is_adver_media,
                 double adver_remit_content_length,
                 double adver_remit_image_num);

  float JudgeByModel(int type,
                     uint64 item_id,
                     const std::unordered_map<std::string, std::vector<std::string> >& adver_features);

  bool Remit(const std::string& source);

 private:
  void AddWeight(uint64 item_id,
                 const std::string& feature,
                 std::unordered_set<uint64>* calced_features,
                 float* model_value);

  const dawgdic::Dictionary* adver_rules_;
  const dawgdic::Dictionary* adver_keywords_;
  const dawgdic::Dictionary* adver_impurity_keywords_;
  const std::unordered_map<uint64, double>* adver_model_;
  const std::unordered_map<std::string, int>* rubbish_sources_;
};
// adver rule type
enum {
  kAdverPhone = 0,
  kAdverID = 1,
  kTitleCandidate = 2
};
}  // namespace bad_item
}  // namespace reco
