#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/item_service/hbase_set_item.h"
#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "base/common/base.h"
#include "base/hash_function/term.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "base/common/sleep.h"
#include "reco/bizc/proto/bad_item.pb.h"

#include "reco/module/bad_item/strategy/rubbish_detector.h"

DEFINE_string(hbase_table, "tb_reco_item", "hbase table");
DEFINE_string(data_dir, "../data", "data dir");
DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

namespace reco {
namespace bad_item {
class RubbishDetector;
class BadItemTest : public testing::Test {
 public:
  void SetUp() {
  }
  void TearDown() {
  }
};
// 低质识别模块使用流程 -- 1
// 0. 要先初始化 RubbishDetector, 调用静态方法 Initial, 参数为 FALGS_data_dir
// 1. 调用 Detect(const reco::RecoItem& reco_item, reco::ContentAttr) 接口
TEST(BadItemTest, DetectBadItemContentAttr) {
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());
  serving_base::mysql_util::DbConnManager::Option option;
  option.host = FLAGS_db_host;
  option.user = FLAGS_db_user;
  option.passwd = FLAGS_db_passwd;
  option.schema = FLAGS_schema;
  static serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(option); // NOLINT
  static struct {
    uint64 item_id;
    std::string result;
  } cases[] = {
    // pos samples
    {16314745893030748265ul, "00000000"},
    {18328856883540533067ul, "00001000"},
    {17131761987321845755ul, "00001000"},
    {8037692616790826805ul, "01000000"},
    {6339881110998455360ul, "00000020"},
    {13385068756462613926ul, "00000000"},
    {13238730334647154423ul, "00000000"},
    // neg samples,
    {8751900827784960088ul, "11110011"},
    {16743487886273747352ul, "22331111"},
    {4264748191506414015ul, "00000000"},
    {7012759456994116032ul, "00000000"},
  };
  std::vector<std::pair<uint64, std::string>> cases_;
  for (int i = 0; i < (int)ARRAYSIZE_UNSAFE(cases); ++i) {
    cases_.push_back(std::make_pair(cases[i].item_id, cases[i].result));
  }
  reco::HBaseGetItem get_item(FLAGS_hbase_table, 100);
  reco::ContentAttr::ContentAttrLevel attr_values[] = { reco::ContentAttr::kSureNo,
    reco::ContentAttr::kSuspect, reco::ContentAttr::kSureYes };
  std::string result_str;
  RubbishDetector* detector = new RubbishDetector(db_manager);
  for (size_t i = 0; i < cases_.size(); ++i) {
    reco::ContentAttr content_attr;
    result_str.clear();
    uint64 item_id = cases_[i].first;
    reco::RecoItem reco_item;
    if (!get_item.GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "cannot get reco item\t" << item_id;
    }
    reco::RawItem raw_item = reco_item.raw_item();
    std::string* content = reco_item.mutable_content();
    *content = reco_item.raw_item().content();
    reco_item.clear_image();
    for (int j = 0; j < (int)raw_item.image_size(); ++j) {
      reco_item.add_image()->CopyFrom(raw_item.image(j));
    }
    reco_item.clear_video_meta_settings();
    for (int j = 0; j < (int)raw_item.video_meta_settings_size(); ++j) {
      reco_item.add_video_meta_settings()->CopyFrom(raw_item.video_meta_settings(j));
    }
    LOG(INFO) << item_id << "\t" << reco_item.image_size() << "\t" << reco_item.video_meta_settings_size();
    detector->Detect(reco_item, &content_attr);
    result_str += base::IntToString(content_attr.erro_title());
    result_str += base::IntToString(content_attr.advertorial());
    result_str += base::IntToString(content_attr.short_content());
    result_str += base::IntToString(content_attr.dedup_paragraph());
    result_str += base::IntToString(content_attr.dirty());
    result_str += base::IntToString(content_attr.politics());
    result_str += base::IntToString(content_attr.bluffing_title());
    result_str += base::IntToString(content_attr.negative());
    if (i < 7) {
      ASSERT_EQ(cases_[i].second, result_str) << item_id;
    } else {
      ASSERT_NE(cases_[i].second, result_str) << item_id;
    }
    if (i == 9) {
      ASSERT_EQ(content_attr.advertorial(), attr_values[1]);
      ASSERT_EQ(content_attr.dedup_paragraph(), attr_values[2]);
      ASSERT_EQ(content_attr.bluffing_title(), attr_values[2]);
    }
  }
}
}
}
