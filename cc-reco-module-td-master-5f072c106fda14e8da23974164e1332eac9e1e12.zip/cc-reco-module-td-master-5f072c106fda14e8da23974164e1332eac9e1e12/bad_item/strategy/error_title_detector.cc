#include "reco/module/bad_item/strategy/error_title_detector.h"

#include <string>
#include <map>
#include <fstream>
#include <vector>
#include <unordered_set>
#include <algorithm>

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/hash_function/term.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"

namespace reco {
namespace bad_item {
void ErrorTitleDetector::CalcTitleContentSet(const std::vector<std::pair<std::string, int> >& ngrams,
                                             std::unordered_map<uint64, std::string>* title_set,
                                             std::unordered_map<uint64, std::string>* content_set) {
  title_set->clear();
  content_set->clear();
  std::string norm_line;
  for (int i = 0; i < (int)ngrams.size(); ++i) {
    if (ngrams[i].second == 0) {
      nlp::util::NormalizeLineCopy(ngrams[i].first, &norm_line);
      if (stopwords->find(norm_line) != stopwords->end()) continue;
      uint64 sign = base::CalcTermSign(ngrams[i].first.data(), ngrams[i].first.size());
      title_set->insert(std::make_pair(sign, ngrams[i].first));
    } else {
      nlp::util::NormalizeLineCopy(ngrams[i].first, &norm_line);
      if (stopwords->find(norm_line) != stopwords->end()) continue;
      uint64 sign = base::CalcTermSign(ngrams[i].first.data(), ngrams[i].first.size());
      content_set->insert(std::make_pair(sign, ngrams[i].first));
    }
  }
}

double ErrorTitleDetector::CalcTitleContentMatch(const std::unordered_map<uint64, std::string>& title_set,
                                                 const std::unordered_map<uint64, std::string>& content_set) {
  int hit = 0;
  for (auto it = title_set.begin(); it != title_set.end(); ++it) {
    if (content_set.find(it->first) != content_set.end()) ++hit;
  }
  return 1.0 * (float)hit / (float)title_set.size();
}

double ErrorTitleDetector::CalcTitleParagraphMatch(const reco::RecoItem& reco_item,
                                                   const std::vector<std::string>& paragraphs,
                                                   const std::unordered_map<uint64, std::string>& title_set) {
  int title_term_num = 0;
  dawgdic::Dictionary dict;
  {
    title_term_num = title_set.size();
    std::vector<std::string> sorted_terms;
    for (auto it = title_set.begin(); it != title_set.end(); ++it) {
      sorted_terms.push_back(it->second);
    }

    dawgdic::DawgBuilder builder;
    std::sort(sorted_terms.begin(), sorted_terms.end());
    for (size_t i = 0; i < sorted_terms.size(); ++i) {
      CHECK(builder.Insert(sorted_terms[i].c_str(), i));
    }

    dawgdic::Dawg dawg;
    builder.Finish(&dawg);
    CHECK(dawgdic::DictionaryBuilder::Build(dawg, &dict));
  }

  int match = 0;
  std::vector<base::Slice> matches;
  std::vector<int> values;
  for (int i = 0; i < (int)paragraphs.size(); ++i) {
    if (paragraphs[i].size() < 3) continue;
    matches.clear();
    values.clear();
    int match_num = nlp::util::ForwardMaxMatch(dict, paragraphs[i], &matches, &values);
    if (match_num == 0) continue;
    float ratio = 1.0 * match_num / title_term_num;
    if (ratio > 0) ++match;
  }
  return 1.0 * (float)match / (float)paragraphs.size();
}

inline bool remit(const reco::RecoItem& reco_item,
                  const std::string& norm_title,
                  const std::string& norm_content) {
  // 太短的交给空短处理，标题党不处理
  if (norm_title.empty() || norm_content.size() < norm_title.size()) return true;
  if (reco_item.identity().type() == reco::kHumor ||
      reco_item.identity().type() == reco::kGossip ||
      reco_item.identity().type() == reco::kPicture ||
      reco_item.identity().type() == reco::kPictureNews ||
      reco_item.identity().type() == reco::kPureVideo ||
      reco_item.identity().type() == reco::kSpecial ||
      reco_item.has_reviewed() ||
      reco_item.is_valid() ||
      reco_item.source().find("奇趣百科") != std::string::npos) {
    return true;
    if (reco_item.category_size() > 0 && reco_item.category(0) == "幽默") {
      return true;
    }
    if (reco_item.identity().has_producer() && (reco_item.identity().manual())) {
      return true;
    }
  }
  return false;
}

int ErrorTitleDetector::Detect(const reco::RecoItem& reco_item,
                               const reco::ml::item_fea::LowQualityHit& low_quality_hit,
                               const std::vector<std::string>& paragraphs) {
  stopwords = GlobalDataIns::instance().GetStopwords().get();
  const std::unordered_set<std::string>* rubbish_titles = GlobalDataIns::instance().GetRubbishTitles().get();
  const std::unordered_map<std::string, int>* rubbish_sources = GlobalDataIns::instance().GetRubbishSource().get(); // NOLINT


  double error_title_yes = 0.975;
  double error_title_suspect = 0.97;
  auto it = GlobalDataIns::instance().GetLowQualityThresholds().get()->find("error_title_suspect");
  if (it != GlobalDataIns::instance().GetLowQualityThresholds().get()->end()) {
    error_title_suspect = it->second;
  }
  it = GlobalDataIns::instance().GetLowQualityThresholds().get()->find("error_title_yes");
  if (it != GlobalDataIns::instance().GetLowQualityThresholds().get()->end()) {
    error_title_yes = it->second;
  }

  std::unordered_map<uint64, std::string> title_set;
  std::unordered_map<uint64, std::string> content_set;
  // 如果是垃圾标题直接干掉
  if (rubbish_titles->find(low_quality_hit.nospace_title) != rubbish_titles->end()) {
    return 2;
  }
  if (remit(reco_item, low_quality_hit.nospace_title, low_quality_hit.nospace_content)) {
    return 0;
  }
  int charNum = 0;
  CHECK(base::GetUTF8CharNum(low_quality_hit.nospace_title, &charNum));

  double ori_score = 1.0;

  // 垃圾源增加初始分数
  std::string norm_source;
  nlp::util::NormalizeLineCopy(reco_item.source(), &norm_source);
  auto it2 = rubbish_sources->find(norm_source);
  if (it2 != rubbish_sources->end() && it2->second == 2) {
    ori_score = 1.2;
  }

  // 如果只有 1-2 段, 或者每段字数都很少, 则降低初始分数, 避免误杀, 交给空短来搞
  int content_char_num = 0;
  bool is_short = true;
  if ((int)paragraphs.size() > 2) {
    for (int i = 1; i < (int)paragraphs.size(); ++i) {
      CHECK(base::GetUTF8CharNum(paragraphs[i], &content_char_num));
      if (content_char_num > 100) {
        is_short = false;
        break;
      }
    }
  }
  if (is_short) ori_score = 0.5;

  // 通过 title 和 content 相似性计算出的原始分数
  CalcTitleContentSet(low_quality_hit.ngrams, &title_set, &content_set);
  double match_score1 = CalcTitleContentMatch(title_set, content_set);
  double match_score2 = CalcTitleParagraphMatch(reco_item, paragraphs, title_set);
  double score = ori_score - (0.3 * match_score1 + 0.7 * match_score2);

  // 用原分数减 basic unigram terms 的倒数 . 这样可以在一定程度上对短标题降权 , 减少误识别的 case
  if (low_quality_hit.title_basic_terms.size() != 0) {
    score = score - (ori_score / static_cast<double>(low_quality_hit.title_basic_terms.size()));
  }

  if (score >= error_title_yes) {
    LOG(INFO) << "error title:\t" << reco_item.identity().item_id() << "\t"
              << low_quality_hit.nospace_title << "\tdetected as error title\t"
              << match_score1 << "\t" << match_score2;
    return 2;
  }
  if (score >= error_title_suspect) {
    LOG(INFO) << "error title:\t" << reco_item.identity().item_id() << "\t"
              << low_quality_hit.nospace_content << "\tdetected as suspect error title\t"
              << match_score1 << "\t" << match_score2;
    return 1;
  }
  return 0;
}
}
}
