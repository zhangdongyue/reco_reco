#pragma once
#include <string>
#include <vector>
#include <map>
#include <set>
#include <unordered_set>
#include <unordered_map>
#include <utility>
#include <cmath>

#include "base/common/base.h"
#include "base/file/file_path.h"
#include "reco/bizc/proto/item.pb.h"
#include "nlp/common/term_container.h"
#include "extend/static_dict/dawg/dictionary.h"
#include "reco/ml/feature/item/low_quality_hit.h"

namespace reco {
namespace bad_item {
struct ItemInfo;
class DirtyDetector {
 public:
  DirtyDetector() {}
  ~DirtyDetector() {}

  int Detect(bool is_video,
             const reco::RecoItem& reco_item,
             const reco::ml::item_fea::LowQualityHit& low_quality_hit,
             const std::unordered_map<std::string, std::vector<std::string> >& dirty_features,
             const std::unordered_map<std::string, int>& hit_nums,
             int* video_dirty_status);

  void DetectSub(const reco::RecoItem& reco_item,
                 const reco::ml::item_fea::LowQualityHit& low_quality_hit,
                 const std::vector<std::string>& paragraphs,
                 const std::unordered_map<std::string, std::vector<std::string> >& dirty_features,
                 std::vector<int>* sub_status);
 private:
  static int kMaxTermNum;
  const std::unordered_map<std::string, int>* dirty_sub_rule;
  const std::unordered_map<uint64, double>* dirty_model;
  const std::unordered_map<std::string, double>* low_quality_thresholds;
  const std::unordered_map<std::string, int>* rubbish_sources;

  bool IsSimbleCase(uint64 item_id, const std::string& title);
  bool AllowedKill(const std::string& cate, const reco::RecoItem& reco_item, bool is_video);
  void ReWeight(const std::string cate, int type, float* score);

  void AddWeight(uint64 item_id,
                 const std::string& feature,
                 std::unordered_set<uint64>* calced_features,
                 float* model_value);

  float DetectWithModel(int type, uint64 item_id, bool remit_content, double threshold,
                        const std::unordered_map<std::string, std::vector<std::string> >& dirty_features,
                        const std::unordered_map<std::string, int>& hit_nums);

  void Process(const reco::RecoItem& reco_item,
               const std::string& norm_title,
               const std::unordered_map<std::string, std::vector<std::string> >& dirty_features,
               const std::unordered_map<std::string, int>& hit_nums,
               int* status);

  void GetSubClass(const reco::RecoItem& reco_item,
                   const std::string& norm_content,
                   const std::vector<std::string>& paragraphs,
                   const std::unordered_map<std::string, std::vector<std::string> >& dirty_features,
                   const std::vector<std::pair<std::string, int >>& ngrams,
                   std::vector<int>* sub_status);
};
}
}
