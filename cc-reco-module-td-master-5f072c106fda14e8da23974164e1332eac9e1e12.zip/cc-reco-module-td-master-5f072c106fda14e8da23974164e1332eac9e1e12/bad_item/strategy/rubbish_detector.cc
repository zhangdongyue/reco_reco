#include "reco/module/bad_item/strategy/rubbish_detector.h"
#include <vector>
#include <algorithm>
#include <functional>
#include <utility>
#include "reco/module/bad_item/strategy/error_title_detector.h"
#include "reco/module/bad_item/strategy/advertorial_detector.h"
#include "reco/module/bad_item/strategy/short_content_detector.h"
#include "reco/module/bad_item/strategy/dedup_paragraph_detector.h"
#include "reco/module/bad_item/strategy/dirty_detector.h"
#include "reco/module/bad_item/strategy/politics_detector.h"
#include "reco/module/bad_item/strategy/bluffing_title_detector.h"
#include "reco/module/bad_item/strategy/negative_detector.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"

#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "nlp/common/nlp_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/utf_char_iterator.h"
#include "reco/bizc/reco_ner/reco_ner.h"

namespace reco {
namespace bad_item {
const std::string lowQualityKey = "low_quality";
const std::string subDirtyKey = "dirty";
const std::string subVideoDirtyStatusKey = "video_dirty_status";
const std::string subAdverKey = "adver";

bool inline process_feature(int type, const std::string& feature, std::string* result) {
  std::vector<std::string> tokens;
  base::SplitString(feature, "_", &tokens);
  if (0 == type) {
    for (int i = 1; i < (int)tokens.size(); ++i) {
      result->append(tokens[i].c_str(), tokens[i].size());
    }
  }
  if (result->empty()) return false;
  return true;
}

RubbishDetector::RubbishDetector(const reco::redis::RedisCli* redis_cli_) {
  error_title_detector_ = new ErrorTitleDetector();
  ad_detector_ = new AdvertorialDetector();
  short_content_detector_ = new ShortContentDetector();
  dedup_detector_ = new DedupParagraphDetector();
  dirty_detector_ = new DirtyDetector();
  politics_detector_ = new PoliticsDetector();
  bluffing_title_detector_ = new BluffingTitleDetector();
  negative_detector_= new NegativeDetector();

  low_quality_hit_ = new reco::ml::item_fea::LowQualityHit();
  image_adver_ = new reco::ml::item_fea::ImageAdver();

  redis_cli = redis_cli_;
}

RubbishDetector::~RubbishDetector() {
  delete error_title_detector_;
  error_title_detector_ = NULL;
  delete ad_detector_;
  ad_detector_ = NULL;
  delete short_content_detector_;
  short_content_detector_ = NULL;
  delete dedup_detector_;
  dedup_detector_ = NULL;
  delete dirty_detector_;
  dirty_detector_ = NULL;
  delete politics_detector_;
  politics_detector_ = NULL;
  delete bluffing_title_detector_;
  bluffing_title_detector_ = NULL;
  delete negative_detector_;
  negative_detector_ = NULL;

  delete low_quality_hit_;
  low_quality_hit_ = NULL;
  delete image_adver_;
  image_adver_ = NULL;
}

void RubbishDetector::GenerateParagraphs(const reco::RecoItem& reco_item,
                                         std::vector<std::string>* paragraphs,
                                         std::vector<std::string>* norm_paragraphs) {
  paragraphs->clear();
  norm_paragraphs->clear();
  std::string nospace_str;
  std::vector<std::string> tokens;
  base::SplitString(reco_item.content(), "\n", &tokens);
  for (int i = 0; i < (int)tokens.size(); ++i) {
    nospace_str.clear();
    nlp::util::NormalizeLineInPlaceS(&tokens[i]);
    base::RemoveChars(tokens[i], base::kWhitespace, &nospace_str);
    int length = 0;
    if (base::GetUTF8CharNum(nospace_str, &length) && length != 0) {
      norm_paragraphs->push_back(nospace_str);
      paragraphs->push_back(tokens[i]);
    }
  }
}

bool RubbishDetector::Remit(const std::unordered_set<std::string>& remit_sources,
                            const reco::RecoItem& reco_item) {
  std::string norm_source;
  nlp::util::NormalizeLineCopy(reco_item.source(), &norm_source);
  // 豁免运营新闻的低质识别
  if (reco_item.identity().has_manual() &&
      reco_item.identity().manual()) {
    return true;
  }
  if (remit_sources.find(norm_source) != remit_sources.end()) return true;
  if (reco_item.identity().type() == reco::kGoods ||
      reco_item.identity().type() == reco::kAudio ||
      reco_item.identity().type() == reco::kAudioAlbum ||
      reco_item.identity().type() == reco::kMultiAudio ||
      reco_item.identity().type() == reco::kNovel) {
    return true;
  }
  return false;
}

void RubbishDetector::Detect(const reco::RecoItem& reco_item, reco::ContentAttr* content_attr) {
  reco::ContentAttr::ContentAttrLevel attr_values[] = { reco::ContentAttr::kSureNo,
    reco::ContentAttr::kSuspect, reco::ContentAttr::kSureYes };
  reco::ContentAttr::SubDirty sub_dirtys[] = { reco::ContentAttr::kNone,
    reco::ContentAttr::kEthic, reco::ContentAttr::kSocial, reco::ContentAttr::kStar,
    reco::ContentAttr::kGallary, reco::ContentAttr::kHistory, reco::ContentAttr::kSex,
    reco::ContentAttr::kHealthy, reco::ContentAttr::kAvPlayer, reco::ContentAttr::kChasingGirls,
    reco::ContentAttr::kDisgusting, reco::ContentAttr::kComic, reco::ContentAttr::kNoval,
    reco::ContentAttr::kHumor};
  reco::ContentAttr::SubAdver sub_advers[] = { reco::ContentAttr::kAdver, reco::ContentAttr::kImpurity};

  const std::unordered_set<std::string>* remit_sources = GlobalDataIns::instance().GetLowQualityRemitSources().get(); // NOLINT
  if (Remit(*remit_sources, reco_item)) {
    content_attr->set_erro_title(attr_values[0]);
    content_attr->set_advertorial(attr_values[0]);
    content_attr->set_short_content(attr_values[0]);
    content_attr->set_dedup_paragraph(attr_values[0]);
    content_attr->set_dirty(attr_values[0]);
    content_attr->set_politics(attr_values[0]);
    content_attr->set_bluffing_title(attr_values[0]);
    content_attr->set_negative(attr_values[0]);
    content_attr->set_video_dirty(attr_values[0]);
    LOG(INFO) << "remit item:\t" << reco_item.identity().item_id();
    return;
  }

  std::string debug;
  std::unordered_map<std::string, std::vector<int> > results;
  Detect(reco_item, &results);
  for (auto it = results.begin(); it != results.end(); ++it) {
    if (it->first == lowQualityKey) {
      debug.clear();
      content_attr->set_erro_title(attr_values[it->second[0]]);
      debug.append(base::StringPrintf("errot_title:%d", it->second[0]));
      content_attr->set_advertorial(attr_values[it->second[1]]);
      debug.append(base::StringPrintf(", adver:%d", it->second[1]));
      content_attr->set_short_content(attr_values[it->second[2]]);
      debug.append(base::StringPrintf(", short:%d", it->second[2]));
      content_attr->set_dedup_paragraph(attr_values[it->second[3]]);
      debug.append(base::StringPrintf(", dedup:%d", it->second[3]));
      content_attr->set_dirty(attr_values[it->second[4]]);
      debug.append(base::StringPrintf(", dirty:%d", it->second[4]));
      content_attr->set_politics(attr_values[it->second[5]]);
      debug.append(base::StringPrintf(", politics:%d", it->second[5]));
      content_attr->set_bluffing_title(attr_values[it->second[6]]);
      debug.append(base::StringPrintf(", bluffing:%d", it->second[6]));
      content_attr->set_negative(attr_values[it->second[7]]);
      debug.append(base::StringPrintf(", negative:%d", it->second[7]));
      content_attr->set_video_dirty(attr_values[it->second[8]]);
      debug.append(base::StringPrintf(", video_dirty:%d", it->second[8]));
      // 十九大策略，如果是视频，将视频标题党结果也同步设置成低俗结果
      if (reco_item.identity().type() == reco::kPureVideo) {
        content_attr->set_bluffing_title(attr_values[it->second[8]]);
      }
      LOG(INFO) << base::StringPrintf("%lu\t%s", reco_item.identity().item_id(), debug.c_str());
    } else if (it->first == subDirtyKey) {
      debug = base::StringPrintf("%lu\t%s:", reco_item.identity().item_id(), subDirtyKey.c_str());
      for (int i = 0; i < (int)it->second.size(); ++i) {
        content_attr->add_sub_dirty(sub_dirtys[it->second[i]]);
        debug.append(base::StringPrintf("\t%d", it->second[i]));
      }
      LOG(INFO) << debug;
    } else if (it->first == subAdverKey) {
      debug = base::StringPrintf("%lu\t%s:", reco_item.identity().item_id(), subAdverKey.c_str());
      for (int i = 0; i < (int)it->second.size(); ++i) {
        content_attr->add_sub_adver(sub_advers[it->second[i]]);
        debug.append(base::StringPrintf("\t%d", it->second[i]));
      }
      LOG(INFO) << debug;
    } else if (it->first == subVideoDirtyStatusKey && (int)it->second.size() > 0) {
      debug = base::StringPrintf("%lu\t%s\t%d:", reco_item.identity().item_id(),
                                 subVideoDirtyStatusKey.c_str(),
                                 it->second[0]);
      content_attr->set_video_dirty_status(it->second[0]);
      LOG(INFO) << debug;
    }
  }
}

inline bool GetHitNum(const std::string& input, const std::string& pattern, int* result) {
  if (input.find(pattern) == std::string::npos) return false;
  int start = input.find(pattern) + (int)pattern.size();
  std::string temp = input.substr(start, (int)input.size() - start);
  base::StringToInt(temp, result);
  return true;
}

bool GetHitFeature(const std::string& input, const std::string& pattern, std::string* result) {
  if (input.find(pattern) == std::string::npos) return false;
  int start = input.find(pattern) + (int)pattern.size();
  *result = input.substr(start, (int)input.size() - start);
  return true;
}

void RubbishDetector::ProcessFeatures(std::unordered_map<std::string, std::vector<std::string> >* adver_features, // NOLINT
                                      std::unordered_map<std::string, std::vector<std::string> >* dirty_features, // NOLINT
                                      std::unordered_map<std::string, int>* hit_nums,
                                      std::vector<int>* punctuation_nums) {
  CHECK_NOTNULL(low_quality_hit_);
  // punctuations
  punctuation_nums->clear();
  hit_nums->clear();
  adver_features->clear();
  dirty_features->clear();
  punctuation_nums->resize(3, 0);
  for (int i = 0; i < (int)low_quality_hit_->GetFeatureSize(); ++i) {
    if (low_quality_hit_->GetFeature(i).find("TitlePunctuation_") != std::string::npos) {
      if (low_quality_hit_->GetFeature(i).find("start") != std::string::npos) {
        punctuation_nums->at(0) += 1;
      } else if (low_quality_hit_->GetFeature(i).find("middle") != std::string::npos) {
        punctuation_nums->at(1) += 1;
      } else if (low_quality_hit_->GetFeature(i).find("end") != std::string::npos) {
        punctuation_nums->at(2) += 1;
      }
      continue;
    }

    // hit_nums
    int current = 0;
    if (GetHitNum(low_quality_hit_->GetFeature(i), "BluffingRuleNum_", &current)) {
      hit_nums->insert(std::make_pair("bluffing_rule_num", current));
      continue;
    }
    if (GetHitNum(low_quality_hit_->GetFeature(i), "BluffingKeywordNum_", &current)) {
      hit_nums->insert(std::make_pair("bluffing_keyword_num", current));
      continue;
    }
    if (GetHitNum(low_quality_hit_->GetFeature(i), "TitleDirtyRuleNum_", &current)) {
      hit_nums->insert(std::make_pair("dirty_title_rule", current));
      continue;
    }
    if (GetHitNum(low_quality_hit_->GetFeature(i), "TitleDirtyKeywordNum_", &current)) {
      hit_nums->insert(std::make_pair("dirty_title_keyword", current));
      continue;
    }
    if (GetHitNum(low_quality_hit_->GetFeature(i), "ContentDirtyRuleNum_", &current)) {
      if (hit_nums->find("dirty_content_rule") == hit_nums->end()) {
        hit_nums->insert(std::make_pair("dirty_content_rule", current));
      } else {
        hit_nums->find("dirty_content_rule")->second += current;
      }
      continue;
    }
    if (GetHitNum(low_quality_hit_->GetFeature(i), "ImageDescDirtyRuleNum_", &current)) {
      if (hit_nums->find("dirty_content_rule") == hit_nums->end()) {
        hit_nums->insert(std::make_pair("dirty_content_rule", current));
      } else {
        hit_nums->find("dirty_content_rule")->second += current;
      }
      continue;
    }

    if (GetHitNum(low_quality_hit_->GetFeature(i), "ContentDirtyKeywordNum_", &current)) {
      if (hit_nums->find("dirty_content_keyword") == hit_nums->end()) {
        hit_nums->insert(std::make_pair("dirty_content_keyword", current));
      } else {
        hit_nums->find("dirty_content_keyword")->second += current;
      }
      continue;
    }
    if (GetHitNum(low_quality_hit_->GetFeature(i), "ImageDescDirtyKeywordNum_", &current)) {
      if (hit_nums->find("dirty_content_keyword") == hit_nums->end()) {
        hit_nums->insert(std::make_pair("dirty_content_keyword", current));
      } else {
        hit_nums->find("dirty_content_keyword")->second += current;
      }
      continue;
    }

    if (GetHitNum(low_quality_hit_->GetFeature(i), "TitleAdverRuleNum_", &current)) {
      hit_nums->insert(std::make_pair("adver_title_rule", current));
      continue;
    }
    if (GetHitNum(low_quality_hit_->GetFeature(i), "TitleAdverKeywordNum_", &current)) {
      hit_nums->insert(std::make_pair("adver_title_keyword", current));
      continue;
    }
    if (GetHitNum(low_quality_hit_->GetFeature(i), "ContentAdverRuleNum_", &current)) {
      if (hit_nums->find("adver_content_rule") == hit_nums->end()) {
        hit_nums->insert(std::make_pair("adver_content_rule", current));
      } else {
        hit_nums->find("adver_content_rule")->second += current;
      }
      continue;
    }
    if (GetHitNum(low_quality_hit_->GetFeature(i), "ImageDescAdverRuleNum_", &current)) {
      if (hit_nums->find("adver_content_rule") == hit_nums->end()) {
        hit_nums->insert(std::make_pair("adver_content_rule", current));
      } else {
        hit_nums->find("adver_content_rule")->second += current;
      }
      continue;
    }

    if (GetHitNum(low_quality_hit_->GetFeature(i), "ContentAdverKeywordNum_", &current)) {
      if (hit_nums->find("adver_content_keyword") == hit_nums->end()) {
        hit_nums->insert(std::make_pair("adver_content_keyword", current));
      } else {
        hit_nums->find("adver_content_keyword")->second += current;
      }
      continue;
    }
    if (GetHitNum(low_quality_hit_->GetFeature(i), "ImageDescAdverKeywordNum_", &current)) {
      if (hit_nums->find("adver_content_keyword") == hit_nums->end()) {
        hit_nums->insert(std::make_pair("adver_content_keyword", current));
      } else {
        hit_nums->find("adver_content_keyword")->second += current;
      }
      continue;
    }

    if (GetHitNum(low_quality_hit_->GetFeature(i), "ContentAdverImpurityKeywordNum_", &current)) {
      if (hit_nums->find("adver_impurity_keyword") == hit_nums->end()) {
        hit_nums->insert(std::make_pair("adver_impurity_keyword", current));
      } else {
        hit_nums->find("adver_impurity_keyword")->second += current;
      }
      continue;
    }
    if (GetHitNum(low_quality_hit_->GetFeature(i), "ImageDescAdverImpurityKeywordNum_", &current)) {
      if (hit_nums->find("adver_impurity_keyword") == hit_nums->end()) {
        hit_nums->insert(std::make_pair("adver_impurity_keyword", current));
      } else {
        hit_nums->find("adver_impurity_keyword")->second += current;
      }
      continue;
    }

    std::string current_str = "";
    // adver_features
    if (GetHitFeature(low_quality_hit_->GetFeature(i), "AdverModelFeature_", &current_str)) {
      if (current_str.find("content")  != std::string::npos) {
        if (adver_features->find("content_model") == adver_features->end()) {
          std::vector<std::string> temp;
          temp.push_back(current_str);
          adver_features->insert(std::make_pair("content_model", temp));
        } else {
          adver_features->find("content_model")->second.push_back(current_str);
        }
      } else if (current_str.find("title")  != std::string::npos) {
        if (adver_features->find("title_model") == adver_features->end()) {
          std::vector<std::string> temp;
          temp.push_back(current_str);
          adver_features->insert(std::make_pair("title_model", temp));
        } else {
          adver_features->find("title_model")->second.push_back(current_str);
        }
      }
      continue;
    }
    // dirty_features
    if (GetHitFeature(low_quality_hit_->GetFeature(i), "DirtyModelFeature_", &current_str)) {
      if (current_str.find("content")  != std::string::npos) {
        if (dirty_features->find("content_model") == dirty_features->end()) {
          std::vector<std::string> temp;
          temp.push_back(current_str);
          dirty_features->insert(std::make_pair("content_model", temp));
        } else {
          dirty_features->find("content_model")->second.push_back(current_str);
        }
      } else if (current_str.find("title")  != std::string::npos) {
        if (dirty_features->find("title_model") == dirty_features->end()) {
          std::vector<std::string> temp;
          temp.push_back(current_str);
          dirty_features->insert(std::make_pair("title_model", temp));
        } else {
          dirty_features->find("title_model")->second.push_back(current_str);
        }
      }
      continue;
    }
    if (GetHitFeature(low_quality_hit_->GetFeature(i), "TitleDirtyKeywordFeature_", &current_str)) {
      if (dirty_features->find("title_keyword") == dirty_features->end()) {
        std::vector<std::string> temp;
        temp.push_back(current_str);
        dirty_features->insert(std::make_pair("title_keyword", temp));
      } else {
        dirty_features->find("title_keyword")->second.push_back(current_str);
      }
      continue;
    }
    if (GetHitFeature(low_quality_hit_->GetFeature(i), "ContentDirtyKeywordFeature_", &current_str)) {
      if (dirty_features->find("content_keyword") == dirty_features->end()) {
        std::vector<std::string> temp;
        temp.push_back(current_str);
        dirty_features->insert(std::make_pair("content_keyword", temp));
      } else {
        dirty_features->find("content_keyword")->second.push_back(current_str);
      }
      continue;
    }
    if (GetHitFeature(low_quality_hit_->GetFeature(i), "TitleDirtyRuleFeature_", &current_str)) {
      if (dirty_features->find("title_rule") == dirty_features->end()) {
        std::vector<std::string> temp;
        temp.push_back(current_str);
        dirty_features->insert(std::make_pair("title_rule", temp));
      } else {
        dirty_features->find("title_rule")->second.push_back(current_str);
      }
      continue;
    }
    if (GetHitFeature(low_quality_hit_->GetFeature(i), "ContentDirtyRuleFeature_", &current_str)) {
      if (dirty_features->find("content_rule") == dirty_features->end()) {
        std::vector<std::string> temp;
        temp.push_back(current_str);
        dirty_features->insert(std::make_pair("content_rule", temp));
      } else {
        dirty_features->find("content_rule")->second.push_back(current_str);
      }
      continue;
    }
  }
}

void RubbishDetector::Detect(const reco::RecoItem& reco_item,
                             std::unordered_map<std::string, std::vector<int> >* results) {
  CHECK_NOTNULL(results);
  results->clear();
  int status = 0;
  std::vector<int> low_quality_status;
  std::vector<int> sub_status;

  std::vector<std::string> paragraphs;
  std::vector<std::string> norm_paragraphs;
  GenerateParagraphs(reco_item, &paragraphs, &norm_paragraphs);

  // 调用 ml 模块的特征抽取方法, 并对抽取到的特征进行分析归类
  low_quality_hit_->ClearFeature();
  image_adver_->ClearFeature();
  low_quality_hit_->SetRecoItem(reco_item);
  image_adver_->SetRecoItem(reco_item);
  if (!low_quality_hit_->ExtractFeature()) {
    LOG(ERROR) << "error! cannot calc low quality fatures of item:\t" << reco_item.identity().item_id();
  }
  if (!image_adver_->ExtractFeature()) {
    LOG(ERROR) << "error! cannot calc image fatures of item:\t" << reco_item.identity().item_id();
  }

  std::unordered_map<std::string, std::vector<std::string> > adver_features;
  std::unordered_map<std::string, std::vector<std::string> > dirty_features;
  std::unordered_map<std::string, int> hit_nums;
  std::vector<int> punctuation_nums;

  ProcessFeatures(&adver_features, &dirty_features, &hit_nums, &punctuation_nums);

  bool is_video = (reco_item.identity().type() == reco::kPureVideo);
  int video_dirty_status = 0;

  if (is_video) {
    for (int i = 0; i < 8; ++i) {
      low_quality_status.push_back(0);
    }
    if (reco_item.has_content_attr() &&
        reco_item.content_attr().has_video_dirty_status()) {
      video_dirty_status = reco_item.content_attr().video_dirty_status();
    }
    status = politics_detector_->Detect(reco_item, *low_quality_hit_);
    low_quality_status[5] = status;
    status = negative_detector_->Detect(reco_item, *low_quality_hit_);
    low_quality_status[7] = status;
  } else {
    status = error_title_detector_->Detect(reco_item, *low_quality_hit_, paragraphs);
    low_quality_status.push_back(status);

    sub_status.clear();
    bool has_adver_image = false;
    if ((image_adver_->GetFeatureSize() > 0 && image_adver_->GetFeature(0) == "HasAdverImage_1") ||
        (image_adver_->GetFeatureSize() > 1 && image_adver_->GetFeature(1) == "HasQRCodeImage_1")) {
      has_adver_image = true;
    }
    status = ad_detector_->Detect(reco_item, redis_cli, *low_quality_hit_, norm_paragraphs,
                                  adver_features, hit_nums, has_adver_image, &sub_status);
    low_quality_status.push_back(status);
    if (!sub_status.empty()) {
      results->insert(std::make_pair(subAdverKey, sub_status));
    }

    status = short_content_detector_->Detect(reco_item, *low_quality_hit_);
    low_quality_status.push_back(status);

    status = dedup_detector_->Detect(reco_item, *low_quality_hit_, paragraphs);
    low_quality_status.push_back(status);

    status = dirty_detector_->Detect(is_video, reco_item, *low_quality_hit_,
                                     dirty_features, hit_nums, &video_dirty_status);
    low_quality_status.push_back(status);
    sub_status.clear();
    if (low_quality_status.back() != 0) {
      dirty_detector_->DetectSub(reco_item, *low_quality_hit_, paragraphs,
                                 dirty_features, &sub_status);
    }
    if (!sub_status.empty()) {
      results->insert(std::make_pair(subDirtyKey, sub_status));
    }

    status = politics_detector_->Detect(reco_item, *low_quality_hit_);
    low_quality_status.push_back(status);

    // 标题党特殊处理, 如果之前的 reco item 有标题党结果了, 不再识别, 直接用原有结果
    if (reco_item.has_content_attr() && reco_item.content_attr().has_bluffing_title()) {
      status = reco_item.content_attr().bluffing_title();
    } else {
      status = bluffing_title_detector_->Detect(reco_item, *low_quality_hit_, norm_paragraphs,
                                                hit_nums, punctuation_nums);
    }
    low_quality_status.push_back(status);

    status = negative_detector_->Detect(reco_item, *low_quality_hit_);
    low_quality_status.push_back(status);
  }
  // 处理视频低俗类型
  if (is_video) {
    status = dirty_detector_->Detect(is_video, reco_item, *low_quality_hit_,
                                     dirty_features, hit_nums, &video_dirty_status);
    low_quality_status.push_back(status);
    sub_status.clear();
    sub_status.push_back(video_dirty_status);
    results->insert(std::make_pair(subVideoDirtyStatusKey, sub_status));
  } else {
    low_quality_status.push_back(0);
  }
  results->insert(std::make_pair(lowQualityKey, low_quality_status));
}
}
}
