#include "reco/module/bad_item/strategy/advertorial_detector.h"
#include <algorithm>
#include <fstream>
#include <map>
#include <set>
#include <utility>

#include "base/hash_function/term.h"
#include "base/hash_function/city.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "base/strings/utf_char_iterator.h"

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"

#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "extend/static_dict/dawg/dictionary.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"
#include "extend/simhash/simhash.h"

namespace reco {
namespace bad_item {
const std::string kImageLevelKey = "ImageBadLevel-";
const int kRedisRetryTime = 3;

// type 0: 没有 url; type 1: 在段中; type 2: 在段末
inline int HasURL(const std::string& str, const std::string& pattern) {
  std::string url;
  int type = 0;
  std::size_t pos = str.find(pattern);
  if (pos == std::string::npos) {
    return 0;
  }
  while (pos != str.size()) {
    if (pos == std::string::npos) return type;
    if ((str[pos] >= '0' && str[pos] <= '9') ||
        (str[pos] <= 'z' && str[pos] >= 'a') ||
        (str[pos] <= 'Z' && str[pos] >= 'A') ||
        str[pos] == '_' || str[pos] == '?' || str[pos] == '&' ||
        str[pos] == '=' || str[pos] == '/' || str[pos] == ':' ||
        str[pos] == '.') {
      url += str[pos];
      ++pos;
      continue;
    }
    if (pos != str.size()) {
      if ((int)url.size() >= 10 && type < 1) type = 1;
      pos = str.find(pattern, pos + 1);
      url.clear();
      continue;
    } else {
      type = 2;
    }
  }
  return 2;
}

bool AdvertorialDetector::IsAdverMedia(const std::string& media) {
  std::string norm_media;
  nlp::util::NormalizeLineCopy(media, &norm_media);
  auto it = rubbish_sources_->find(norm_media);
  if (it != rubbish_sources_->end() && it->second == 0) {
    return true;
  }
  return false;
}

bool AdvertorialDetector::Remit(const std::string& source) {
  if (source.find("奇趣百科_") != std::string::npos) return true;
  return false;
}

void AdvertorialDetector::AddWeight(uint64 item_id,
                                    const std::string& feature,
                                    std::unordered_set<uint64>* calced_features,
                                    float* model_value) {
  uint64 sign = base::CalcTermSign(feature.data(), feature.size());
  if (calced_features->find(sign) == calced_features->end() &&
      adver_model_->find(sign) != adver_model_->end()) {
    calced_features->insert(sign);
    VLOG(1) << item_id << "\thit adver feature:\t" << feature << "\t" << adver_model_->find(sign)->second;
    *model_value = *model_value + adver_model_->find(sign)->second;
  }
}

bool AdvertorialDetector::RightDown(uint64 item_id,
                                    const reco::RecoItem& reco_item,
                                    const std::string& content,
                                    bool is_adver_media,
                                    double adver_remit_content_length,
                                    double adver_remit_image_num) {
  std::string source_media = "";
  std::string cate = "";
  std::string sub_cate = "";
  if (reco_item.has_source_media()) source_media = reco_item.source_media();
  if (reco_item.category_size() > 0) cate = reco_item.category(0);
  if (reco_item.category_size() > 1) sub_cate = reco_item.category(1);

  if (source_media == "地方新闻接口" || source_media == "UC自媒体") return false;
  if (reco_item.identity().type() == reco::kPicture) return false;
  if (is_adver_media) return false;
  // 对于某些类别, 如果文章较长, 或图片较多, 则在广告结果中降权
  if (cate == "体育" || cate == "娱乐" || cate == "国际" || cate == "互联网" ||
      (cate == "科技" && sub_cate == "")) {
    int content_char_num = 0;
    if (!base::GetUTF8CharNum(content, &content_char_num)) return false;
    if (content_char_num >= adver_remit_content_length &&
        reco_item.image_size() >= adver_remit_image_num) {
      VLOG(1) << "right down for adver" << item_id << "\t"
              << content_char_num << "\t" << reco_item.image_size();
      return true;
    }
    if (content_char_num >= 4 * adver_remit_content_length) return true;
  }
  return false;
}

bool AdvertorialDetector::ProcessOcr(const reco::RecoItem& reco_item,
                                     const reco::redis::RedisCli* redis_cli,
                                     const reco::ml::item_fea::LowQualityHit& low_quality_hit) {
  // 如果 image 数量等于 0, 则直接返回 false
  if ((int)reco_item.image_size() == 0) return false;
  std::string cate = "";
  if (reco_item.category_size() > 0) cate = reco_item.category(0);

  std::vector<uint64> image_ids;
  uint64 image_id;
  std::string value;
  for (int i = 0; i < (int)reco_item.image_size(); ++i) {
    int retry_time = 0;
    image_id = base::CityHash64(reco_item.image(i).url().c_str(), reco_item.image(i).url().size());
    if (reco_item.image(i).is_qrcode()) {
      LOG(INFO) << reco_item.identity().item_id() << "hit qrcode image:\t" << image_id;
      return 2;
    }
    // 从 redis 中取结果, 如果可以取到, 则说明是广告图片
    std::string key = base::StringPrintf("%s%lu", kImageLevelKey.c_str(), image_id);
    int status = const_cast<reco::redis::RedisCli*>(redis_cli)->Exist(key);
    while (status == -1 && retry_time < kRedisRetryTime) {
      ++retry_time;
      status = const_cast<reco::redis::RedisCli*>(redis_cli)->Exist(key);
    }
    if (retry_time >= kRedisRetryTime && status == -1) {
      LOG(ERROR) << "cannot get image info from redis:\t" << image_id;
    }
    if (status == 0) {
      value.clear();
      int adver_type = const_cast<reco::redis::RedisCli*>(redis_cli)->Get(key, &value);
      if (adver_type != 0 || value == "adver") {
        LOG(INFO) << reco_item.identity().item_id() << "\thit adver image:\t" << image_id;
        return true;
      }
      if (cate != "娱乐" && cate != "体育" && cate != "社会" && cate != "科技") {
        return true;
      }
      if (value != "1") return true;
    }
  }
  return false;
}

float AdvertorialDetector::JudgeByModel(int type,
                                        uint64 item_id,
                                        const std::unordered_map<std::string, std::vector<std::string> >& adver_features) { // NOLINT
  float model_value = 0;
  std::unordered_set<uint64> calced_features;
  if (0 == type) {
    if (adver_features.find("title_model") != adver_features.end()) {
      for (int i = 0; i < (int)adver_features.find("title_model")->second.size(); ++i) {
        AddWeight(item_id, adver_features.find("title_model")->second[i], &calced_features, &model_value);
      }
    }
  } else {
    if (adver_features.find("content_model") != adver_features.end()) {
      for (int i = 0; i < (int)adver_features.find("content_model")->second.size(); ++i) {
        AddWeight(item_id, adver_features.find("content_model")->second[i], &calced_features, &model_value);
      }
    }
  }
  return model_value;
}

int AdvertorialDetector::Detect(const reco::RecoItem& reco_item,
                                const reco::redis::RedisCli* redis_cli,
                                const reco::ml::item_fea::LowQualityHit& low_quality_hit,
                                const std::vector<std::string>& norm_paragraphs,
                                const std::unordered_map<std::string, std::vector<std::string> >& adver_features, // NOLINT
                                const std::unordered_map<std::string, int>& hit_nums,
                                bool has_adver_image,
                                std::vector<int>* sub_status) {
  rubbish_sources_ = GlobalDataIns::instance().GetRubbishSource().get();
  adver_model_ = GlobalDataIns::instance().GetAdverModel().get();
  adver_rules_ = GlobalDataIns::instance().GetAdverRules().get();
  adver_keywords_ = GlobalDataIns::instance().GetAdverKeywords().get();
  adver_impurity_keywords_ = GlobalDataIns::instance().GetAdverImpurityKeywords().get();
  sub_status->clear();
  std::unordered_set<int> sub_results;
  if (Remit(reco_item.source())) return 0;
  double adver_yes = 0.8;
  double adver_suspect = 0.4;
  double adver_remit_content_length = 1800;
  double adver_remit_image_num = 3;
  double adver_model_title_yes = 0.85;
  double adver_model_title_suspect = 0.7;
  double adver_model_content_yes = 0.9;
  double adver_model_content_suspect = 0.75;

  const std::unordered_map<std::string, double>* low_quality_thresholds = GlobalDataIns::instance().GetLowQualityThresholds().get(); // NOLINT
  auto it = low_quality_thresholds->find("adver_yes");
  if (it != low_quality_thresholds->end()) {
    adver_yes= it->second;
  }
  it = low_quality_thresholds->find("adver_suspect");
  if (it != low_quality_thresholds->end()) {
    adver_suspect = it->second;
  }
  it = low_quality_thresholds->find("adver_remit_content_length");
  if (it != low_quality_thresholds->end()) {
    adver_remit_content_length = it->second;
  }
  it = low_quality_thresholds->find("adver_remit_image_num");
  if (it != low_quality_thresholds->end()) {
    adver_remit_image_num = it->second;
  }
  it = low_quality_thresholds->find("adver_model_title_yes");
  if (it != low_quality_thresholds->end()) {
    adver_model_title_yes = it->second;
  }
  it = low_quality_thresholds->find("adver_model_title_suspect");
  if (it != low_quality_thresholds->end()) {
    adver_model_title_suspect = it->second;
  }
  it = low_quality_thresholds->find("adver_model_content_yes");
  if (it != low_quality_thresholds->end()) {
    adver_model_content_yes = it->second;
  }
  it = low_quality_thresholds->find("adver_model_content_suspect");
  if (it != low_quality_thresholds->end()) {
    adver_model_content_suspect = it->second;
  }

  uint64 item_id = reco_item.identity().item_id();
  double score = 0;

  // 如果有广告图片, 直接打广告 2 分
  if (has_adver_image) score += adver_yes;

  // orig media 或者 media 命中了广告媒体, 直接加到疑似分, 至少保证打上一分
  bool is_adver_media = false;
  if (reco_item.has_orig_source_media() && IsAdverMedia(reco_item.orig_source_media())) {
    score += adver_suspect;
    is_adver_media = true;
    LOG(INFO) << item_id << "\thit adver media\t" << reco_item.orig_source_media();
  } else if (reco_item.has_source_media() && IsAdverMedia(reco_item.source_media())) {
    score += adver_suspect;
    is_adver_media = true;
    LOG(INFO) << item_id << "\thit adver media\t" << reco_item.source_media();
  } else if (IsAdverMedia(reco_item.source())) {
    score += adver_suspect;
    is_adver_media = true;
    LOG(INFO) << item_id << "\thit adver media\t" << reco_item.source();
  }

  // 判断 是否有 URL, 如果有, 按位置加分
  int url_type = 0;
  for (int i = 0; i < (int)norm_paragraphs.size(); ++i) {
    url_type = HasURL(norm_paragraphs[i], "http:");
    if (url_type == 0) {
      url_type = HasURL(norm_paragraphs[i], "www.");
    }
    if (url_type == 1) {
      score += adver_suspect / 2;
    } else if (url_type == 2) {
      if (i != (int)norm_paragraphs.size() - 1) {
        score += adver_suspect;
      } else {
        score += adver_yes;
      }
    }
    VLOG(1) << item_id << "\thas_url:\t" << url_type << "\tscore:\t" << score;
  }

  std::string cate = "未分类";
  if (reco_item.category_size() > 0) cate = reco_item.category(0);

  // ocr 处理
  if (ProcessOcr(reco_item, redis_cli, low_quality_hit)) return 2;
  // 处理各类规则和关键词, 同时记录个数, 后期根据命中个数和命中类型补召回
  float weight = JudgeByModel(0, item_id, adver_features);
  double title_model_value = 1 / (1 + std::exp(0 - weight));

  if (title_model_value >= adver_model_title_yes) {
    score += adver_yes;
  } else if (title_model_value >= adver_model_title_suspect) {
    score += adver_suspect;
  }
  int title_rule_num = 0;
  int title_keyword_num = 0;
  if (hit_nums.find("adver_title_rule") != hit_nums.end()) {
    title_rule_num = hit_nums.find("adver_title_rule")->second;
    score += title_rule_num * adver_yes;
  }
  if (hit_nums.find("adver_title_keyword") != hit_nums.end()) {
    title_keyword_num = hit_nums.find("adver_title_keyword")->second;
    score += title_keyword_num * adver_suspect;
  }

  VLOG(1) << item_id << "\ttitle score\t:" << score << "\t" << title_model_value
          << "\ttitle rule num:\t" << title_rule_num
          << "\ttitle keyword num:\t" << title_keyword_num;

  weight = JudgeByModel(1, item_id, adver_features);
  double content_model_value = 1 / (1 + std::exp(0 - weight));

  if (content_model_value >= adver_model_content_yes) {
    score += adver_yes;
  } else if (content_model_value >= adver_model_content_suspect) {
    score += adver_suspect;
  }
  int content_rule_num = 0;
  int content_keyword_num = 0;
  int impurity_keyword_num = 0;
  if (hit_nums.find("adver_content_rule") != hit_nums.end()) {
    content_rule_num = hit_nums.find("adver_content_rule")->second;
    score += content_rule_num * adver_yes;
  }
  if (hit_nums.find("adver_content_keyword") != hit_nums.end()) {
    content_keyword_num = hit_nums.find("adver_content_keyword")->second;
    score += content_keyword_num * adver_suspect;
  }
  if (hit_nums.find("adver_impurity_keyword") != hit_nums.end()) {
    impurity_keyword_num = hit_nums.find("adver_impurity_keyword")->second;
    if (impurity_keyword_num > 0) {
      sub_results.insert(1);
    }
  }
  VLOG(1) << item_id << "\tcontent score\t:" << score << "\t" << content_model_value
          << "\tcontent rule num:\t" << content_rule_num
          << "\tcontent keyword num:\t" << content_keyword_num
          << "\timpurity keyword num:\t" << impurity_keyword_num;

  bool right_down = RightDown(item_id, reco_item, low_quality_hit.nospace_content, is_adver_media,
                              adver_remit_content_length, adver_remit_image_num);
  VLOG(1) << item_id << "\tadver final score:\t" << score << "\t" << right_down;
  int result = 0;
  if (score >= adver_yes) {
    sub_results.insert(0);
    if (!right_down || score > 1) {
      result = 2;
    } else {
      result = 1;
    }
  }
  if (result < 1 && score >= adver_suspect && !right_down) {
    sub_results.insert(0);
    result = 1;
  }
  if (result < 1 && sub_results.find(1) != sub_results.end()) {
    result = 1;
  }
  for (auto it = sub_results.begin(); it != sub_results.end(); ++it) {
    sub_status->push_back(*it);
  }
  return result;
}

AdvertorialDetector::AdvertorialDetector() {}
AdvertorialDetector::~AdvertorialDetector() {}
}  // namespace item_model
}  // namespace reco
