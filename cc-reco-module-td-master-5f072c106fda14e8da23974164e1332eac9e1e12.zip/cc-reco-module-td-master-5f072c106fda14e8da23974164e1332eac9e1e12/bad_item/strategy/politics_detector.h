#pragma once
#include <string>
#include <set>
#include <unordered_set>
#include <vector>
#include "base/file/file_path.h"
#include "extend/static_dict/dawg/dictionary.h"
#include "reco/ml/feature/item/low_quality_hit.h"

namespace reco {
namespace bad_item {
struct ItemInfo;
class PoliticsDetector {
 public:
  PoliticsDetector() {}
  ~PoliticsDetector() {}

  int Detect(const reco::RecoItem& reco_item,
             const reco::ml::item_fea::LowQualityHit& low_quality_hit);
};
}
}
