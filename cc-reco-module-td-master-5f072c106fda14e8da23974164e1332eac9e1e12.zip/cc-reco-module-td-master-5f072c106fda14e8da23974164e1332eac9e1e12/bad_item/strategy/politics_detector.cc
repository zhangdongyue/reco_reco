#include "reco/module/bad_item/strategy/politics_detector.h"
#include <algorithm>
#include <map>
#include <vector>
#include <string>
#include <fstream>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <set>

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "base/file/file_path.h"
#include "base/hash_function/term.h"
#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "extend/static_dict/dawg/dictionary.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"

DEFINE_bool(politics_content, false, "if set, use content to decide, or only use title");

namespace reco {
namespace bad_item {
int PoliticsDetector::Detect(const reco::RecoItem& reco_item,
                             const reco::ml::item_fea::LowQualityHit& low_quality_hit) {
  const dawgdic::Dictionary* politics_rules = GlobalDataIns::instance().GetPoliticsRules().get();
  const dawgdic::Dictionary* politics_keywords = GlobalDataIns::instance().GetPoliticsKeywords().get();
  uint64 item_id = reco_item.identity().item_id();
  std::unordered_set<std::string> hit_terms;
  // title 过强规则
  low_quality_hit.DetectWithDict(*politics_rules, low_quality_hit.title_basic_terms,
                                 low_quality_hit.nospace_title, &hit_terms);
  if (!hit_terms.empty()) {
    LOG(INFO) << "title politics detector:\t" << item_id << "\trule yes";
    return 2;
  }

  if (FLAGS_politics_content) {
    // content 过强规则
    low_quality_hit.DetectWithDict(*politics_rules, low_quality_hit.content_basic_terms,
                                   low_quality_hit.nospace_content, &hit_terms);
    if (!hit_terms.empty()) {
      LOG(INFO) << "content politics detector:\t" << item_id << "\trule yes";
      return 2;
    }
  }

  // title 过关键字
  low_quality_hit.DetectWithDict(*politics_keywords, low_quality_hit.title_basic_terms,
                                 low_quality_hit.nospace_title, &hit_terms);
  if (!hit_terms.empty()) {
    LOG(INFO) << "politics detector:\t" << item_id << "\ttitle keyword yes";
    return 1;
  }

  if (FLAGS_politics_content) {
    // content 过关键字
    low_quality_hit.DetectWithDict(*politics_keywords, low_quality_hit.content_basic_terms,
                                   low_quality_hit.nospace_content, &hit_terms);
    if (!hit_terms.empty()) {
      LOG(INFO) << "politics detector:\t" << item_id << "\tcontent keyword yes";
      return 1;
    }
  }
  return 0;
}
}
}
