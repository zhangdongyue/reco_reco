#pragma once

#include <string>
#include <map>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include "base/common/base.h"
#include "base/common/slice.h"
#include "base/file/file_path.h"
#include "reco/ml/feature/item/low_quality_hit.h"

namespace reco {
namespace bad_item {
struct ItemInfo;

class ErrorTitleDetector {
 public:
  ErrorTitleDetector() {}
  ~ErrorTitleDetector() {}

  int Detect(const reco::RecoItem& reco_item,
             const reco::ml::item_fea::LowQualityHit& low_quality_hit,
             const std::vector<std::string>& paragraphs);

  double CalcTitleContentMatch(const std::unordered_map<uint64, std::string>& title_set,
                               const std::unordered_map<uint64, std::string>& content_set);

  double CalcTitleParagraphMatch(const reco::RecoItem& reco_item,
                                 const std::vector<std::string>& paragraphs,
                                 const std::unordered_map<uint64, std::string>& title_set);

 private:
  void CalcTitleContentSet(const std::vector<std::pair<std::string, int> >& ngrams,
                           std::unordered_map<uint64, std::string>* title_set,
                           std::unordered_map<uint64, std::string>* content_set);

  const std::unordered_set<std::string>* stopwords;
};
}
}
