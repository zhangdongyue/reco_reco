#include "reco/module/bad_item/strategy/short_content_detector.h"
#include <vector>
#include <string>
#include <fstream>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/file/file_path.h"
#include "base/hash_function/term.h"
#include "third_party/jsoncpp/include/json/value.h"
#include "third_party/jsoncpp/include/json/reader.h"
#include "extend/web_client/web_client.h"
#include "base/encoding/url_encode.h"
#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"

namespace reco {
namespace bad_item {

ShortContentDetector::ShortContentDetector() {
}
ShortContentDetector::~ShortContentDetector() {
}

bool ShortContentDetector::Remit(const reco::RecoItem& reco_item) {
  if (reco_item.identity().type() == reco::kHumor ||
      reco_item.identity().type() == reco::kGossip ||
      reco_item.identity().type() == reco::kPicture ||
      reco_item.identity().type() == reco::kPureVideo ||
      reco_item.identity().type() == reco::kSpecial ||
      reco_item.source().find("问啊") != std::string::npos ||
      !reco_item.is_valid()) {
    VLOG(1) << reco_item.identity().item_id() << "\tshort content remit, item type:\t"
            << reco_item.identity().type();
    return true;
  }

  if (reco_item.identity().has_producer() && (reco_item.identity().manual())) {
    return true;
  }

  if (reco_item.source().find("奇趣百科") != std::string::npos) {
    VLOG(1) << reco_item.identity().item_id() << "\tshort content remit for qiqubaike";
    return true;
  }
  return false;
}

void ShortContentDetector::ProcessImages(const RecoItem& item, int* useful_image_num,
                                         int* long_image_num, int* gif_num,
                                         double image_height_threshold) {
  for (int i = 0; i < (int)item.image_size(); ++i) {
    if (item.image(i).type() == "gif") {
      *gif_num = *gif_num + 1;
      *useful_image_num = *useful_image_num + 1;
      continue;
    } else {
      //  处理有些图依然是 0 * 0 的特殊情况
      if (item.image(i).width() == 0 && item.image(i).height() == 0) {
        *useful_image_num = *useful_image_num + 1;
        continue;
      }
      if (item.image(i).width() * item.image(i).height() < 10000) continue;
      *useful_image_num = *useful_image_num + 1;
      if (item.image(i).height() > image_height_threshold &&
          item.image(i).height() / item.image(i).width() > 1.5) {
        *long_image_num = *long_image_num + 1;
      }
    }
  }
}

int ShortContentDetector::Detect(const reco::RecoItem& reco_item,
                                 const reco::ml::item_fea::LowQualityHit& low_quality_hit) {
  int char_num = 0;
  if (Remit(reco_item)) return 0;
  if (!base::GetUTF8CharNum(low_quality_hit.nospace_content, &char_num)) {
    LOG(INFO) << reco_item.identity().item_id() << "\tcannot get char num";
    return 2;
  }

  double image_height_threshold = 1000;
  auto it = GlobalDataIns::instance().GetLowQualityThresholds().get()->find("short_image_height_threshold");
  if (it != GlobalDataIns::instance().GetLowQualityThresholds().get()->end()) {
    image_height_threshold = it->second;
  }

  int useful_image_num = 0;
  int gif_num = 0;
  int long_image_num = 0;
  ProcessImages(reco_item, &useful_image_num, &long_image_num, &gif_num, image_height_threshold);
  // 有效图片数量大于 3 或者有视频, 则认为不是空短, 小于 100 * 100 的非动图, 不算有效图片
  if (useful_image_num > 3 ||
      reco_item.video_meta_settings_size() != 0) {
    VLOG(1) << "remit for short content:\t" << reco_item.identity().item_id()
            << "\tuserful image num:\t" << useful_image_num
            << "\tvideo num:\t" << reco_item.video_meta_settings_size();
    return 0;
  }
  // 如果有长图, 不算空短
  if (long_image_num > 0) {
    VLOG(1) << reco_item.identity().item_id() << "\tremit for long image";
    return 0;
  }
  std::string cate = "";
  if (reco_item.category_size() > 0) cate = reco_item.category(0);
  // 幽默类的特殊策略
  if (cate == "幽默" && (char_num > 50 || gif_num > 0)) {
    VLOG(1) << "remit for humor\tcharnum:\t" << char_num << "\tgif num:\t" << gif_num;
    return 0;
  }
  int threshold = 150;
  if (useful_image_num < 5) {
    threshold += (3 - useful_image_num) * 25;
  }
  VLOG(1) << reco_item.identity().item_id() << "\t" << char_num << "\t"
          << useful_image_num << "\t" << threshold;
  if (char_num < threshold / 2) {
    LOG(INFO) << reco_item.identity().item_id() << "\tshort content, char num:\t"
              << base::IntToString(char_num);
    return 2;
  }
  if (char_num < threshold) {
    LOG(INFO) << reco_item.identity().item_id() << "\tshort content, char num:\t"
              << base::IntToString(char_num);
    return 1;
  }
  const std::unordered_map<std::string, double>* cate_length_threshold = GlobalDataIns::instance().GetCategoryLengthThreshold().get(); // NOLINT
  auto it2 = cate_length_threshold->find(cate);
  if (it2 == cate_length_threshold->end() || (double)char_num > it2->second) {
    return 0;
  }
  if (char_num >= threshold) return 1;
  return 2;
}
}
}
