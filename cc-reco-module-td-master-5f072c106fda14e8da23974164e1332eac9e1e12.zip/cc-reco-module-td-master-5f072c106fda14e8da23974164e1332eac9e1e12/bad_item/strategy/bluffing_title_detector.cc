#include "reco/module/bad_item/strategy/bluffing_title_detector.h"
#include <string>
#include <algorithm>
#include <map>
#include <utility>

#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/file/file_path.h"
#include "base/hash_function/term.h"
#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "extend/static_dict/dawg/dictionary.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"

namespace reco {
namespace bad_item {
const std::string qiqu_url = "http://qiqu.uc.cn/";

inline bool Remit(const reco::RecoItem& reco_item) {
  if (reco_item.source().find("问啊") != std::string::npos) {
    VLOG(1) << "remit item for bluffing, source:\t" << reco_item.source();
    return true;
  }
  if (reco_item.identity().type() == reco::kGoods) {
    VLOG(1) << "remit goods item for bluffing:\t" << reco_item.identity().item_id();
    return true;
  }
  if (reco_item.has_original_url() &&
      reco_item.original_url().find(qiqu_url) == 0) {
    LOG(INFO) << "remit qiqubaike for bluffing:\t" << reco_item.identity().item_id();
    return true;
  }
  return false;
}

inline void ReWeight(const std::string& level1, const std::string& level2, double* count) {
  // 类别调权, 最少也要有一分
  if (level1 == "娱乐" || level1 == "体育" || level1 == "旅游" || level1 == "幽默") {
    *count = *count / 2;
  }
  if (*count < 2) *count = 2;
}

double BluffingTitleDetector::Process(const reco::RecoItem& reco_item,
                                      const std::string& norm_title,
                                      const std::unordered_map<std::string, int>& hit_nums,
                                      const std::vector<int>& punctuation_nums,
                                      double bluffing_suspect,
                                      double bluffing_yes) {
  double result = 0;
  uint64 item_id = reco_item.identity().item_id();
  // title 过强规则
  if (hit_nums.find("bluffing_rule_num") != hit_nums.end() &&
      hit_nums.find("bluffing_rule_num")->second > 0) {
    result += 4;
  }
  if (result == 0 &&
      hit_nums.find("bluffing_keyword_num") != hit_nums.end() &&
      hit_nums.find("bluffing_keyword_num")->second > 0) {
    result += 2;
  }

  // 判定 title 中特殊符号的数量, 如果符号在末尾, 加权
  if (result < 2) {
    int total = 0;
    result += punctuation_nums[0] * 1.5;
    total += punctuation_nums[0];
    result += punctuation_nums[1] * 1;
    total += punctuation_nums[1];
    result += punctuation_nums[2] * 1.5;
    total += punctuation_nums[2];
    if (total > 2) {
      result *= 2;
    }
  }

  std::string level1 = "";
  std::string level2 = "";
  if (reco_item.category_size() > 0) level1 = reco_item.category(0);
  if (reco_item.category_size() > 1) level2 = reco_item.category(1);
  if (result > bluffing_suspect) {
    ReWeight(level1, level2, &result);
  }
  // 如果都没识别，走 source 识别
  if (result < 2) {
    std::string norm_source;
    nlp::util::NormalizeLineCopy(reco_item.source(), &norm_source);
    auto it = rubbish_sources->find(norm_source);
    if (it != rubbish_sources->end() && it->second == 1) {
      result = 2;
    }
  }
  VLOG(1) << base::StringPrintf("%lu\tbluffing, score:%f\tlevel1: %s\tlevel2: %s",
                                item_id, result, level1.c_str(), level2.c_str());
  return result;
}

bool BluffingTitleDetector::DetectShortParagraph(const reco::RecoItem& reco_item,
                                                 const std::string& norm_title,
                                                 const std::vector<std::string>& norm_paragraphs) {
  uint64 item_id = reco_item.identity().item_id();
  if (reco_item.video_meta_settings_size() != 0) return false;
  if (!reco_item.has_source_media() ||
      (reco_item.source_media() != "微信自媒体" &&
       reco_item.source_media() != "UC自媒体" &&
       reco_item.source_media() != "地方新闻接口")) {
    return false;
  }
  int count_comma = 0;
  int title_length = 0;
  for (int i = 0; i < (int)norm_title.size(); ++i) {
    if (norm_title[i] == ',') {
      ++count_comma;
    }
  }
  if (!base::GetUTF8CharNum(norm_title, &title_length)) {
    LOG(ERROR) << "cannot calc title length:\t" << norm_title << "\t" << item_id;
  }
  std::string cate = "";
  std::string sub_cate = "";
  if (reco_item.category_size() > 0) cate = reco_item.category(0);
  if (reco_item.category_size() > 1) sub_cate = reco_item.category(1);
  if (cate == "社会" || cate == "奇闻" || sub_cate == "情感") {
    if ((title_length >= 24 && count_comma > 0) ||
        (title_length > 20 && count_comma > 2)) {
      LOG(INFO) << "long title for bluffing:\t" << item_id << "\t" << norm_title;
      return true;
    }
  }
  int charNum = 0;
  double average_length = 0;
  int count = 0;
  for (int i = 0; i < (int)norm_paragraphs.size(); ++i) {
    if (!base::GetUTF8CharNum(norm_paragraphs[i], &charNum) || charNum < 10) continue;
    average_length += charNum;
    ++count;
  }
  if (count == 0) return false;
  average_length /= (double)count;
  if (average_length >= 50 ||
      count >= 30 ||
      (average_length >=40 && count >= 20)) return false;
  if (cate == "娱乐" || cate == "社会" ||
      cate == "奇闻" || cate == "科技") {
    return true;
  }
  return false;
}

int BluffingTitleDetector::Detect(const reco::RecoItem& reco_item,
                                  const reco::ml::item_fea::LowQualityHit& low_quality_hit,
                                  const std::vector<std::string>& norm_paragraphs,
                                  const std::unordered_map<std::string, int>& hit_nums,
                                  const std::vector<int>& punctuation_nums) {
  if (Remit(reco_item))  {
    return 0;
  }

  rubbish_sources = GlobalDataIns::instance().GetRubbishSource().get();

  double bluffing_suspect = 1.9;
  double bluffing_yes = 2.9;
  auto it = GlobalDataIns::instance().GetLowQualityThresholds().get()->find("bluffing_suspect");
  if (it != GlobalDataIns::instance().GetLowQualityThresholds().get()->end()) {
    bluffing_suspect = it->second;
  }
  it = GlobalDataIns::instance().GetLowQualityThresholds().get()->find("bluffing_yes");
  if (it != GlobalDataIns::instance().GetLowQualityThresholds().get()->end()) {
    bluffing_suspect = it->second;
  }
  double result = Process(reco_item, low_quality_hit.nospace_title, hit_nums,
                          punctuation_nums, bluffing_suspect, bluffing_yes);
  if (result > bluffing_yes) return 2;
  if (result > bluffing_suspect) return 1;
  // 内容垃圾或者没内容的新闻, 直接打两分
  if (DetectShortParagraph(reco_item, low_quality_hit.nospace_title, norm_paragraphs)) return 2;
  return 0;
}
}
}
