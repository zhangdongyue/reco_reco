#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "storage/message_queue/api/message_client_generator.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc/rpc.h"
#include "net/counter/export.h"
#include "base/container/lru_cache.h"

#include "reco/bizc/proto/bad_item.pb.h"
#include "reco/module/bad_item/daemon/dao.h"
#include "reco/bizc/item_service/hbase_get_item.h"

DEFINE_string(db_host, "tcp://100.85.69.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(start_time, "2014-12-10 00:00:00", "db start time");
DEFINE_string(schema, "reco", "shcema");
DEFINE_int32(thread_num, 64, "thread num for write to db");

DEFINE_string(hbase_ip, "10.3.5.72", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table, "", "hbase table");

struct BadItem {
  uint64 item_id;
  int rubbish_type;
  double pre_score;
};

inline void TransferToBadItemEntity(const reco::RecoItem& reco_item,
                                    double pre_score,
                                    int rubbish_type,
                                    reco::bad_item::BadItemEntity* entity) {
  CHECK_NOTNULL(entity);
  base::Time time = base::Time::Now();
  std::string time_str;
  time.ToStringInSeconds(&time_str);

  entity->item_id = reco_item.identity().item_id();
  entity->category = reco_item.category(0);
  entity->title = reco_item.title();
  entity->source = reco_item.source();
  entity->create_time = reco_item.create_time();
  entity->import_time = time_str;
  entity->post_score = -1;

  entity->pre_score = 1;
  entity->rubbish_type = rubbish_type;
  if (entity->rubbish_type == reco::bad_item::kShortContent ||
      entity->rubbish_type == reco::bad_item::kDedupParagraph ||
      entity->rubbish_type == reco::bad_item::kDirty) {
    entity->pre_score = 0;
  }

  entity->review_comment = "";
  entity->review_time = "";
  entity->score_reviewed = -1;
  entity->op = "";
  entity->check_priority = 1;
  if (entity->rubbish_type == reco::bad_item::kShortContent ||
      entity->rubbish_type == reco::bad_item::kDedupParagraph ||
      entity->rubbish_type == reco::bad_item::kDirty) {
    entity->check_priority = 2;
  }
  entity->status = 0;
}

void GenerateEntities(thread::BlockingQueue<BadItem>* bad_item_queue) {
  reco::HBaseGetItem get_item_service(FLAGS_hbase_ip, FLAGS_hbase_port, FLAGS_hbase_table, 0);

  serving_base::mysql_util::DbConnManager::Option db_option;
  db_option.host = FLAGS_db_host;
  db_option.user = FLAGS_db_user;
  db_option.passwd = FLAGS_db_passwd;
  db_option.schema = FLAGS_schema;
  reco::bad_item::Dao db_agent;
  db_agent.Init(db_option, 20000, FLAGS_start_time);

  BadItem bad_item;
  reco::bad_item::BadItemEntity entity;
  reco::RecoItem reco_item;
  while (!(bad_item_queue->Empty() && bad_item_queue->Closed())) {
    int status = bad_item_queue->TimedTake(10, &bad_item);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    if (status < 0) break;
    CHECK_EQ(status, 1) << "fucking status " << status;
    
    // transfer to entity
    if (!get_item_service.GetRecoItem(bad_item.item_id, &reco_item)) {
      LOG(ERROR) << "failed to get item: " << bad_item.item_id;
      return;
    }

    TransferToBadItemEntity(reco_item, bad_item.pre_score, bad_item.rubbish_type, &entity);
    
    // write to db
    db_agent.AddBadItem(entity);
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "batch write to db");
  thread::BlockingQueue<BadItem> bad_item_queue;

  thread::ThreadPool pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(GenerateEntities, &bad_item_queue));
  }
  std::unordered_map<std::string, int> rubbish_type_dict;
  rubbish_type_dict.insert(std::make_pair("标题党", 0));
  rubbish_type_dict.insert(std::make_pair("软文", 1));
  rubbish_type_dict.insert(std::make_pair("空短", 2));
  rubbish_type_dict.insert(std::make_pair("堆砌", 3));
  rubbish_type_dict.insert(std::make_pair("低俗", 4));
  rubbish_type_dict.insert(std::make_pair("其他", 31));

  std::string line;
  std::vector<std::string> flds;
  BadItem bad_item;
  while (std::getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 3) {
      LOG(ERROR) << "fucking erro line: " << line;
      continue;
    }

    bad_item.item_id = base::ParseUint64OrDie(flds[0]);
    auto it = rubbish_type_dict.find(flds[1]);
    if (it != rubbish_type_dict.end()) {
      bad_item.rubbish_type = it->second;
    } else {
      bad_item.rubbish_type = base::ParseIntOrDie(flds[1]);
    }
    
    bad_item.pre_score = base::ParseDoubleOrDie(flds[2]);
    bad_item_queue.Put(bad_item);
  }
  bad_item_queue.Close();

  pool.JoinAll();
  return 0;
}
