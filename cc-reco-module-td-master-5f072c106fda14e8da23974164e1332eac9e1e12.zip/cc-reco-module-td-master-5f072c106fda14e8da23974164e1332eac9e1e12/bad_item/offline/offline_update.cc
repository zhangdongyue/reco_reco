#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>
#include <unordered_map>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "reco/base/kafka_c/api/topic_producer.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "net/counter/export.h"

#include "reco/bizc/proto/common.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/bad_item.pb.h"

DEFINE_string(input_file, "input.txt", "input file path contains items to be updated");

DEFINE_string(kafka_brokers, "10.181.169.190:9092,10.181.169.191:9092,10.181.169.192:9092,10.181.169.193:9092,10.181.169.194:9092", "kafka queue servers");  // NOLINT
DEFINE_string(kafka_topic_name, "", "topic name");
DEFINE_int32(kafka_total_partition, 9, "partition num for some topic");

DEFINE_int32(thread_num, 2, "number of thread for save sim pair to db");

DEFINE_string(hbase_ip, "10.181.169.20", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table, "tb_reco_item", "hbase table");

namespace reco {
namespace bad_item {

thread::ThreadPool* thread_pool_ = NULL;
thread::BlockingVar<int> finish_num_;
bool stop_ = false;
reco::HBaseGetItem* get_item_service_ = new reco::HBaseGetItem(FLAGS_hbase_table, 10);
reco::ContentAttr::ContentAttrLevel attr_values[] = {
  reco::ContentAttr::kSureNo,
  reco::ContentAttr::kSuspect,
  reco::ContentAttr::kSureYes
};

thread::BlockingQueue<std::pair<uint64, std::vector<int> >> bad_item_request_queue_;
thread::BlockingQueue<std::pair<uint64, reco::ContentAttr>> update_content_attr_queue_;

void UpdateContentAttr() {
  reco::kafka::TopicProducer producer(FLAGS_kafka_brokers, FLAGS_kafka_topic_name, FLAGS_kafka_total_partition);  // NOLINT

  std::string message;
  message.reserve(4096);

  int partition = 0;
  reco::RawItemFieldUpdateRequest request;
  reco::RawItemField item_fld;
  std::string content_attr_str;
  std::pair<uint64, reco::ContentAttr> element;
  while (!(update_content_attr_queue_.Closed() && update_content_attr_queue_.Empty())) {
    int status = update_content_attr_queue_.TryTake(&element);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    if (status == -1) break;

    CHECK_EQ(status, 1) << "fucking status "  << status;
    if (!element.second.SerializeToString(&content_attr_str)) {
      LOG(ERROR) << "failed to serilize to string fo item: " << element.first;
      continue;
    }
    item_fld.set_field_name("content_attr");
    item_fld.set_is_manual(false);
    item_fld.set_value(content_attr_str);

    request.Clear();
    request.set_item_id(element.first);
    request.set_timestamp(base::GetTimestamp() / 1000);
    request.add_fields()->Swap(&item_fld);
    request.SerializeToString(&message);
    /**
    if (!producer.Push(partition, message)) {
      LOG(ERROR) << base::StringPrintf("failed to push to kafka queue: %s, partition: %d, item id: %lu",
                                       FLAGS_kafka_brokers.c_str(), partition, element.first);
    } else {
      LOG(INFO) << base::StringPrintf("succ push to kafka queue: %s, partition: %d, item id: %lu",
                                      FLAGS_kafka_brokers.c_str(), partition, element.first);
      partition = (partition + 1) % FLAGS_kafka_total_partition;
    }
    */
    partition = (partition + 1) % FLAGS_kafka_total_partition;
    LOG(INFO) << element.first << "\t" << partition;
  }
}

void GenerateBadItem() {
  while (!(bad_item_request_queue_.Closed() && bad_item_request_queue_.Empty())) {
    std::pair<uint64, std::vector<int>> request;
    int status = bad_item_request_queue_.TimedTake(100, &request);
    if (status == 0) {
      base::SleepForMilliseconds(1000);
      continue;
    }
    if (status < 0) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status: " << status;
    LOG(INFO) << "right status\t" << status;

    reco::RecoItem reco_item;
    if (!get_item_service_->GetRecoItem(request.first, &reco_item)) {
      LOG(ERROR) << "failed to get item: " << request.first;
      continue;
    }
    reco::ContentAttr content_attr = reco_item.raw_item().content_attr();
    LOG(INFO) << request.first << "\tcontent attr:\t" << content_attr.advertorial();
    /**
    // update in content_attr
    if (content_attr.advertorial() == attr_values[0] && request->second[0] != 0) {
      content_attr.set_advertorial(attr_values[1]);
    }
    if (content_attr.dirty() == attr_values[0] && request->second[1] != 0) {
      content_attr.set_dirty(attr_values[1]);
    }
    if (content_attr.dedup_paragraph() == attr_values[0] && request->second[2] != 0) {
      content_attr.set_dedup_paragraph(attr_values[1]);
    }
    if (content_attr.bluffing_title() == attr_values[0] && request->second[3] != 0) {
      content_attr.set_bluffing_title(attr_values[1]);
    }
    if (content_attr.short_content() == attr_values[0] && request->second[4] != 0) {
      content_attr.set_short_content(attr_values[1]);
    }
    */
    update_content_attr_queue_.Put(std::make_pair(request.first, content_attr));
  }
  int n = finish_num_.Take() + 1;
  if (n >= FLAGS_thread_num) {
    update_content_attr_queue_.Close();
  }
  finish_num_.TryPut(n);
}

void GenerateRequestFromFile(std::string path) {
  std::ifstream fin(path);
  if (!fin.is_open()) {
    LOG(INFO) << base::GetTimestamp() << "load fail, no file: "  << path;
    return;
  }
  std::string line;
  std::vector<std::string> tokens;
  while (!stop_ && std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    CHECK_EQ((int)tokens.size(), 6);
    uint64 item_id = base::ParseUint64OrDie(tokens[0]);
    std::vector<int> tags;
    tags.reserve(32);
    for (int i = 1; i < (int)tokens.size(); ++i) {
      tags.push_back(base::ParseIntOrDie(tokens[i]));
    }
    bad_item_request_queue_.Put(std::make_pair(item_id, tags));
  }
}

void UpdateBadItemInfo() {
  thread_pool_ = new thread::ThreadPool(FLAGS_thread_num + 2);
  if (!FLAGS_input_file.empty()) {
    thread_pool_->AddTask(::NewCallback(&GenerateRequestFromFile, FLAGS_input_file));
  }
  CHECK(finish_num_.TryPut(0));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    thread_pool_->AddTask(::NewCallback(&GenerateBadItem));
  }
  // thread_pool_->AddTask(::NewCallback(&UpdateContentAttr));
}

void Stop() {
  if (!stop_) {
    stop_ = true;
    LOG(INFO) << "begin to join all thread";
    thread_pool_->JoinAll();
  }
}
}
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "bad item offline update");
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());

  LOG(INFO) << "begin update offline bad item";
  reco::bad_item::UpdateBadItemInfo();
  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();
  reco::bad_item::Stop();
  LOG(INFO) << "finish update offline bad item";
  return 0;
}
