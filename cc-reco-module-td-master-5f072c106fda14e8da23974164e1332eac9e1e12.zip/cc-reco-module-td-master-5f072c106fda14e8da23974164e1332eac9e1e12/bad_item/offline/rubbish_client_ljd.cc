#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/thread/rw_mutex.h"
#include "base/hash_function/term.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc/rpc.h"
#include "net/counter/export.h"
#include "base/container/lru_cache.h"
#include "nlp/common/nlp_util.h"
#include "reco/base/common/singleton.h"
#include "reco/ml/feature/item/low_quality_hit.h"
#include "reco/bizc/proto/bad_item.pb.h"
#include "reco/module/bad_item/daemon/dao.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/module/bad_item/strategy/rubbish_detector.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "reco/ml/feature/global_data/global_data.h"
#include "reco/ml/feature/global_data/dict_loader.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"

DEFINE_int32(thread_num, 4, "number of thread");

DEFINE_string(input_file, "test.txt", "input file path");
DEFINE_string(result_file, "result.txt", "result file");
DEFINE_string(safe_file, "safe.txt", "safe file");

DEFINE_string(long_time_file, "long_ids.txt", "");

DEFINE_string(hbase_table, "tb_reco_item", "hbase table for reco item");
DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");

// rubbish detactor
const char* kAdverRuleFile = "advertorial_rule.txt";
const char* kAdverKeywordFile = "advertorial_keywords.txt";
const char* kAdverImpurityKeywordFile = "advertorial_impurity_keywords.txt";
const char* kAdverModelFile = "advertorial_model.txt";
const char* kRubbishSourceFile = "rubbish_sources.txt";
const char* kBluffingRuleFile = "bluffing_rule.txt";
const char* kBluffingKeywordFile = "bluffing_keywords.txt";
const char* kDirtyRuleFile = "dirty_rule.txt";
const char* kDirtyKeywordFile = "dirty_keywords.txt";
const char* kDirtyModelFile = "dirty_model.txt";
const char* kDirtySubRuleFile = "dirty_sub_rule.txt";
const char* kRubbishTitleFile = "rubbish_title.txt";
const char* kNegativeRuleFile = "negative_rule.txt";
const char* kNegativeKeywordFile = "negative_keywords.txt";
const char* kPoliticsRuleFile = "politics_rule.txt";
const char* kPoliticsKeywordFile = "politics_keywords.txt";
const char* kTextLenStatFile = "text_len.txt";
const char* kStopwordFile = "stopword.txt";
const char* kMediaQualityFile = "media_quality.txt";
const char* kLowQualityRemitSourceFile = "low_quality_remit_source.txt";
const char* kLowQualityThresholdFile = "low_quality_thresholds.txt";
const char* kLowQualityImageHashFile = "bad_image_hash.txt";

reco::ContentAttr::ContentAttrLevel attr_values[] = { reco::ContentAttr::kSureNo,
  reco::ContentAttr::kSuspect, reco::ContentAttr::kSureYes };
reco::ContentAttr::SubDirty sub_dirtys[] = { reco::ContentAttr::kNone,
  reco::ContentAttr::kEthic, reco::ContentAttr::kSocial, reco::ContentAttr::kStar,
  reco::ContentAttr::kGallary, reco::ContentAttr::kHistory, reco::ContentAttr::kSex,
  reco::ContentAttr::kHealthy, reco::ContentAttr::kAvPlayer, reco::ContentAttr::kChasingGirls,
  reco::ContentAttr::kDisgusting, reco::ContentAttr::kComic, reco::ContentAttr::kNoval,
  reco::ContentAttr::kHumor};
reco::ContentAttr::SubAdver sub_advers[] = { reco::ContentAttr::kAdver, reco::ContentAttr::kImpurity};

std::string item_labels[] = { "error_title", "advertorial", "short_content", "dedup",
  "dirty", "politics", "bluffing" };

std::map<uint64, int64> item_time;
thread::RWMutex item_time_mutex_;

void GenerateBadItem(reco::redis::RedisCli* redis_cli_,
                     thread::BlockingQueue<reco::RecoItem>* bad_item_request_queue,
                     thread::BlockingQueue<std::pair<reco::RecoItem, reco::ContentAttr>>* bad_item_result_queue, //NOLINT
                     thread::BlockingVar<int>* finish_num) {
  reco::bad_item::RubbishDetector* detector = new reco::bad_item::RubbishDetector(redis_cli_);
  while (!(bad_item_request_queue->Closed() && bad_item_request_queue->Empty())) {
    reco::RecoItem request;
    int status = bad_item_request_queue->TimedTake(100, &request);
    if (status == 0) {
      base::SleepForMilliseconds(1000);
      continue;
    }
    if (status < 0) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status: " << status;
    reco::ContentAttr result;

    int64 timestamp1 = base::GetTimestamp();
    detector->Detect(request, &result);
    int64 timestamp2 = base::GetTimestamp();
    int64 gap = timestamp2 - timestamp1;
    item_time_mutex_.Lock();
    item_time.insert(std::make_pair(request.identity().item_id(), gap));
    item_time_mutex_.Unlock();
    bad_item_result_queue->Put(std::make_pair(request, result));
  }

  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    bad_item_result_queue->Close();
  }
  finish_num->TryPut(n);
  delete detector;
  detector = NULL;
}

void SaveResult(thread::BlockingQueue<std::pair<reco::RecoItem, reco::ContentAttr>>* result_queue) {
  std::ofstream fout(FLAGS_result_file);
  std::ofstream fout_safe(FLAGS_safe_file);

  std::pair<reco::RecoItem, reco::ContentAttr> result;

  while (!(result_queue->Empty() && result_queue->Closed())) {
    int status = result_queue->TimedTake(100, &result);
    reco::RecoItem request = result.first;
    reco::ContentAttr rubbish_result(result.second);

    if (status == -1) {
      LOG(ERROR) << "get bad item result failed! status: " << status;
      break;
    }

    if (status == 0) {
      LOG_EVERY_N(ERROR, 100) << "bad item result queue empty";
      base::SleepForMilliseconds(2000);
      continue;
    }
    bool print = false;
    bool safe = true;
    if (rubbish_result.erro_title() != reco::ContentAttr::kSureNo) {
      safe = false;
    }
    if (rubbish_result.erro_title() != reco::ContentAttr::kSureYes) {
      print = true;
    }
    if (rubbish_result.advertorial() != reco::ContentAttr::kSureNo) {
      safe = false;
    }
    if (rubbish_result.advertorial() != reco::ContentAttr::kSureYes) {
      print = true;
    }
    if (rubbish_result.short_content() != reco::ContentAttr::kSureNo) {
      safe = false;
    }
    if (rubbish_result.short_content() != reco::ContentAttr::kSureYes) {
      print = true;
    }
    if (rubbish_result.dedup_paragraph() != reco::ContentAttr::kSureNo) {
      safe = false;
    }
    if (rubbish_result.dedup_paragraph() != reco::ContentAttr::kSureYes) {
      print = true;
    }
    if (rubbish_result.dirty() != reco::ContentAttr::kSureNo) {
      safe = false;
    }
    if (rubbish_result.dirty() != reco::ContentAttr::kSureYes) {
      print = true;
    }
    if (rubbish_result.politics() != reco::ContentAttr::kSureNo) {
      safe = false;
    }
    if (rubbish_result.politics() != reco::ContentAttr::kSureYes) {
      print = true;
    }
    if (rubbish_result.bluffing_title() != reco::ContentAttr::kSureNo) {
      safe = false;
    }
    if (rubbish_result.bluffing_title() != reco::ContentAttr::kSureYes) {
      print = true;
    }
    if (rubbish_result.negative() != reco::ContentAttr::kSureNo) {
      safe = false;
    }
    if (rubbish_result.negative() != reco::ContentAttr::kSureYes) {
      print = true;
    }
    std::string attr_str;
    if (print) {
      attr_str = base::StringPrintf("%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d", rubbish_result.erro_title(),
                                    rubbish_result.advertorial(), rubbish_result.short_content(),
                                    rubbish_result.dedup_paragraph(), rubbish_result.dirty(),
                                    rubbish_result.politics(), rubbish_result.bluffing_title(),
                                    rubbish_result.negative());

      if (rubbish_result.sub_dirty_size() > 0) {
        attr_str.append("\tsub_dirty:\t");
        for (int i = 0; i < (int)rubbish_result.sub_dirty_size(); ++i) {
          attr_str.append(base::IntToString(rubbish_result.sub_dirty(i)));
          if (i != (int)rubbish_result.sub_dirty_size() - 1) {
            attr_str.append(",");
          }
        }
      }
      if (rubbish_result.sub_adver_size() > 0) {
        attr_str.append("\tsub_adver:\t");
        for (int i = 0; i < (int)rubbish_result.sub_adver_size(); ++i) {
          attr_str.append(base::IntToString(rubbish_result.sub_adver(i)));
          if (i != (int)rubbish_result.sub_adver_size() - 1) {
            attr_str.append(",");
          }
        }
      }
    }
    std::string cate = "未分类";
    if (request.category_size() > 0) cate = request.category(0);
    if (!safe) {
      fout << request.identity().item_id() << "\t" << request.title() << "\t"
           << cate << "\t" << request.source() << "\t"
           << request.identity().type() << "\t" << attr_str << "\n";
    }

    if (safe) {
      fout_safe << request.identity().item_id() << "\t" << request.title() << "\t"
                << cate << "\t" << request.source() << "\t"
                << request.identity().type() << "\t" << attr_str << "\n";
    }
  }
  fout.close();
  fout_safe.close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "bad item client ljd");
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());
  thread::BlockingVar<int> ret;

  reco::redis::RedisCli* redis_cli_ = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);
  CHECK(redis_cli_->GetPool()->IsRun());

  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedMapStrInt,
                            kDirtySubRuleFile, reco::dm::LoadLowQualitySubRuleFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kRubbishTitleFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kPoliticsRuleFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kPoliticsKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kNegativeRuleFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kNegativeKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrInt, kRubbishSourceFile);

  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedMapStrDouble,
                            kTextLenStatFile, reco::dm::LoadTextLenStatFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrInt, kMediaQualityFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kLowQualityRemitSourceFile);

  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedMapStrDouble,
                            kLowQualityThresholdFile, reco::dm::LoadLowQualityThresholdFile);

  // ml 模块加载的文件
  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverRuleFile,
                            reco::ml::LoadAdverRuleFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverImpurityKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_DICT(UnorderedMapUint64Double, kAdverModelFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kDirtyRuleFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kDirtyKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_DICT(UnorderedMapUint64Double, kDirtyModelFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kBluffingRuleFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kBluffingKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kStopwordFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrInt, kLowQualityImageHashFile);

  reco::dm::DictManagerSingleton::instance().LoadAllDicts();

  std::ifstream fin(FLAGS_input_file);
  std::string line;

  std::set<uint64> cache;
  reco::BaseGetItem* get_item_service_ = new reco::ItemKeeperGetItem(FLAGS_item_keeper_server_ip, FLAGS_item_keeper_server_port); // NOLINT

  thread::BlockingQueue<reco::RecoItem> bad_item_request_queue;
  thread::BlockingQueue<std::pair<reco::RecoItem, reco::ContentAttr>> result_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));

  thread::ThreadPool pool(FLAGS_thread_num + 1);
  pool.AddTask(::NewCallback(SaveResult, &result_queue));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(GenerateBadItem, redis_cli_, &bad_item_request_queue, &result_queue, &finish_num)); // NOLINT
  }

  while (std::getline(fin, line)) {
    if (line.size() < 2) {
      LOG(ERROR) << "erro line: " << line;
      continue;
    }
    uint64 item_id = base::ParseUint64OrDie(line);
    reco::RecoItem reco_item;
    if (!get_item_service_->GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "failed to get item: " << item_id;
      continue;
    }
    reco::RawItem raw_item = reco_item.raw_item();
    std::string* content = reco_item.mutable_content();
    *content = reco_item.raw_item().content();
    reco_item.clear_image();
    for (int j = 0; j < (int)raw_item.image_size(); ++j) {
      reco_item.add_image()->CopyFrom(raw_item.image(j));
    }
    reco_item.clear_video_meta_settings();
    for (int j = 0; j < (int)raw_item.video_meta_settings_size(); ++j) {
      reco_item.add_video_meta_settings()->CopyFrom(raw_item.video_meta_settings(j));
    }
    std::string title_source = reco_item.title() + "$" + reco_item.source();
    std::string norm_title;
    nlp::util::NormalizeLineCopy(title_source, &norm_title);
    uint64 sign = base::CalcTermSign(norm_title.c_str(), norm_title.size());
    if (cache.find(sign) == cache.end()) {
      cache.insert(sign);
      bad_item_request_queue.Put(reco_item);
    }
  }
  bad_item_request_queue.Close();
  pool.JoinAll();
  delete get_item_service_;
  get_item_service_ = NULL;
  std::ofstream fout(FLAGS_long_time_file);
  int64 total_time = 0;
  float ave_time = 0;
  int64 max_time = 0;
  uint64 max_id = 0;
  for (auto it = item_time.begin(); it != item_time.end(); ++it) {
    total_time += it->second;
    if (it->second > max_time) {
      max_time = it->second;
      max_id = it->first;
    }
    if (it->second > 1000000) {
      fout << it->first << std::endl;
    }
  }
  if (item_time.size() != 0) {
    ave_time = (float) total_time / (float)item_time.size();
  }
  LOG(INFO) << item_time.size() << "\ttotal_time:\t" << total_time << "\tave_time:\t" << ave_time;
  LOG(INFO) << "max:\t" << max_time << "\t" << max_id;
  fout.close();
}
