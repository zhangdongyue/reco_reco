#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include "base/common/gflags.h"
#include "base/common/base.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/item_classify_server/feature/feature_extractor.h"
#include "nlp/common/nlp_util.h"
#include "base/common/basic_types.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "nlp/common/nlp_util.h"

const std::string kNumberStr = "NUMBER_TERM";
const std::string kTimeStr = "TIME_TERM";

inline bool IsValidUnigram (const base::Slice& term) {
  if (term.as_string() == kNumberStr || term.as_string() == kTimeStr) return false;
  int len = 0;
  if (!base::GetUTF8CharNum(term, &len) || len < 2 || term.size() < 3) return false;
  return true;
}

inline bool IsValidBigram(const base::Slice& term1, const base::Slice& term2) {
  int len1 = 0;
  int len2 = 0;
  if (!base::GetUTF8CharNum(term1, &len1) || !base::GetUTF8CharNum(term2, &len2)) return false;
  if (!IsValidUnigram(term1) && !IsValidUnigram(term2)) return false;
  return true;
}

inline bool IsFilteredByPostag(const nlp::term::TermInfo& info) {
  if (info.is_postag(nlp::term::kWhiteSpace)
      || info.is_postag(nlp::term::kPunctuation)
      || info.is_postag(nlp::term::kPreposition)
      || info.is_postag(nlp::term::kAuxiliary)
      || info.is_postag(nlp::term::kExclamation)
      || info.is_postag(nlp::term::kQuantity)
      || info.is_postag(nlp::term::kPronoun)
      || info.is_postag(nlp::term::kConjunction)) {
    return true;
  }
  return false;
}

void GenerateSentences(const std::string& paragraph, std::vector<std::string>* sentences) {
  std::vector<std::string> lines;
  lines.reserve(256);
  base::SplitString(paragraph, ".!? \t", &lines);
  std::string pattern = "。";
  for (int i = 0; i < (int)lines.size(); ++i) {
    size_t index1 = 0;
    size_t end = lines[i].size();
    while (index1 < end) {
      size_t index2 = lines[i].find(pattern, index1);
      if (index2 == std::string::npos) {
        sentences->push_back(lines[i].substr(index1, lines[i].size() - index1));
        break;
      }
      sentences->push_back(lines[i].substr(index1, index2 - index1));
      index1 = index2 + pattern.size();
    }
  }
}

int GenerateUnigram(const base::Slice& norm_text,
                    const nlp::term::TermContainer& container,
                    const std::vector<nlp::time::TimeEntity>& time_terms,
                    std::vector<base::Slice>* mix_terms) {
  int time_idx = -1;
  if (time_terms.size() > 0 && !time_terms.front().term_indices.empty()) {
    time_idx = 0;
  }
  bool has_insert_time = false;
  for (int i = 0; i < (int) container.mix_terms().size(); ++i) {
    const nlp::term::TermInfo& term_info = container.mix_term_info(i);
    const base::Slice& term_slice = container.mix_term_slice(norm_text, i);
    if (IsFilteredByPostag(term_info)) continue;
    if (time_idx > -1 && time_idx < (int)time_terms[0].term_indices.size()) {
      if (time_terms[0].term_indices[time_idx] < i) {
        ++time_idx;
        --i;
        continue;
      }
      if (container.basic_term_slice(norm_text, time_terms[0].term_indices[time_idx]) == term_slice) {
        if (!has_insert_time) {
          mix_terms->push_back(kTimeStr);
          has_insert_time = true;
        }
        ++time_idx;
        continue;
      }
    }
    if (term_info.is_postag(nlp::term::kNumber)) {
      int char_num = 0;
      if (base::GetUTF8CharNum(term_slice, &char_num) && (int)term_slice.size() == char_num) {
        mix_terms->push_back(kNumberStr);
      } else {
        mix_terms->push_back(term_slice);
      }
    } else {
      mix_terms->push_back(term_slice);
    }
  }
  return mix_terms->size();
}

void GenerateParagraphs(const std::string& sentence, std::vector<std::string>* paragraphs) {
  paragraphs->clear();
  size_t start_pos = 0;
  size_t end_pos = 0;
  std::string normalized_text;
  std::string nospace_str;
  while (start_pos < sentence.size()) {
    normalized_text.clear();
    nospace_str.clear();
    if (end_pos >= sentence.size() || sentence[end_pos] == '\n') {
      if (end_pos > start_pos) {
        nlp::util::NormalizeLineCopy(sentence.substr(start_pos, (end_pos - start_pos)), &normalized_text);
        base::RemoveChars(normalized_text, base::kWhitespace, &nospace_str);
        paragraphs->push_back(nospace_str);
      }
      start_pos = end_pos + 1;
      end_pos = start_pos;
    }
    ++end_pos;
  }
}

void GenerateTitleNgram(nlp::segment::Segmenter* segmenter_,
                        nlp::postag::PosTagger* pos_tagger_,
                        nlp::ner::Ner* ner_,
                        nlp::time::TimeRecognizer* time_reco_,
                        const reco::RecoItem& item, std::vector<std::string>* results) {
  std::string line;
  std::string title = item.title();
  nlp::util::NormalizeLineInPlaceS(&title);
  base::RemoveChars(title, base::kWhitespace, &line);
  std::vector<std::string> terms;
  nlp::term::TermContainer term_container;
  CHECK(segmenter_->SegmentT(line, &term_container));
  CHECK(pos_tagger_->PosTagT(line, &term_container));
  CHECK(ner_->DetectEntityT(line, &term_container));
  if (term_container.basic_term_num() > 0) {
    nlp::util::ConstructMixTerms(line, false, &term_container);
  }
  std::vector<nlp::time::TimeEntity> time_tokens;
  base::Time current_time = base::Time::Now();
  time_reco_->DetectTime(current_time, line,
                         term_container, &time_tokens);

  std::vector<base::Slice> mix_unigrams;
  int skip_num = 3;
  GenerateUnigram(line, term_container, time_tokens, &mix_unigrams);
  for (size_t i = 0; i < mix_unigrams.size(); ++i) {
    const base::Slice& term1 = mix_unigrams[i];
    for (size_t j = i + 1; j < mix_unigrams.size() && j < i + skip_num; ++j) {
      const base::Slice& term2 = mix_unigrams[j];
      if (!IsValidBigram(term1, term2)) continue;
      std::string term = base::StringPrintf("%s#%s", term1.as_string().c_str(), term2.as_string().c_str());
      if (term1 > term2) {
        term = base::StringPrintf("%s#%s", term2.as_string().c_str(), term1.as_string().c_str());
      }
      terms.push_back(term);
    }
  }
  std::string res;
  std::string temp;
  for (int i = 0; i < (int)terms.size(); ++i) {
    temp.clear();
    res = base::StringPrintf("title#%s", terms[i].c_str());
    base::RemoveChars(res, base::kWhitespace, &temp);
    results->push_back(temp);
  }
}

void GenerateTitleMediaNgram(nlp::segment::Segmenter* segmenter_,
                             nlp::postag::PosTagger* pos_tagger_,
                             nlp::ner::Ner* ner_,
                             nlp::time::TimeRecognizer* time_reco_,
                             const reco::RecoItem& item, std::vector<std::string>* results) {
  std::string line;
  std::string title = item.title();
  nlp::util::NormalizeLineInPlaceS(&title);
  base::RemoveChars(title, base::kWhitespace, &line);
  std::string media;
  if (item.has_orig_source_media()) {
    media = item.orig_source_media();
  } else if (item.has_source_media()){
    media = item.source_media();
  } else {
    return;
  }
  std::vector<std::string> terms;
  int skip_num = 3;
  nlp::term::TermContainer term_container;
  CHECK(segmenter_->SegmentT(line, &term_container));
  CHECK(pos_tagger_->PosTagT(line, &term_container));
  CHECK(ner_->DetectEntityT(line, &term_container));
  if (term_container.basic_term_num() > 0) {
    nlp::util::ConstructMixTerms(line, false, &term_container);
  }
  std::vector<nlp::time::TimeEntity> time_tokens;
  base::Time current_time = base::Time::Now();
  time_reco_->DetectTime(current_time, line,
                         term_container, &time_tokens);

  std::vector<base::Slice> mix_unigrams;
  GenerateUnigram(line, term_container, time_tokens, &mix_unigrams);
  for (size_t i = 0; i < mix_unigrams.size(); ++i) {
    const base::Slice& term1 = mix_unigrams[i];
    for (size_t j = i + 1; j < mix_unigrams.size() && j < i + skip_num; ++j) {
      const base::Slice& term2 = mix_unigrams[j];
      if (!IsValidBigram(term1, term2)) continue;
      std::string term = base::StringPrintf("%s#%s", term1.as_string().c_str(), term2.as_string().c_str());
      if (term1 > term2) {
        term = base::StringPrintf("%s#%s", term2.as_string().c_str(), term1.as_string().c_str());
      }
      terms.push_back(term);
    }
  }
  std::string res;
  std::string temp;
  for (int i = 0; i < (int)terms.size(); ++i) {
    temp.clear();
    res = base::StringPrintf("title_media#%s#%s", terms[i].c_str(), media.c_str());
    base::RemoveChars(res, base::kWhitespace, &temp);
    results->push_back(temp);
  }
}

void GenerateParagraphNgram(nlp::segment::Segmenter* segmenter_,
                            nlp::postag::PosTagger* pos_tagger_,
                            nlp::ner::Ner* ner_,
                            nlp::time::TimeRecognizer* time_reco_,
                            const reco::RecoItem& item, std::vector<std::string>* results) {
  std::string content = item.raw_item().content();
  std::vector<std::string> paragraphs;
  GenerateParagraphs(content, &paragraphs);
  std::vector<std::string> lines;
  if (paragraphs.empty()) return;
  if (paragraphs.size() < 2) {
    lines.push_back(paragraphs[0]);
  } else {
    lines.push_back(paragraphs.back());
  }
  std::string line;
  std::vector<std::string> terms;
  nlp::term::TermContainer term_container;
  std::vector<base::Slice> mix_unigrams;
  for (int l = 0; l < (int)lines.size(); ++l) {
    line = lines[l];
    int char_num = 0;
    if (!base::GetUTF8CharNum(line, &char_num) || char_num == 0) continue;
    terms.clear();
    term_container.renew();
    mix_unigrams.clear();
    int skip_num = 3;
    CHECK(segmenter_->SegmentT(line, &term_container));
    CHECK(pos_tagger_->PosTagT(line, &term_container));
    CHECK(ner_->DetectEntityT(line, &term_container));
    if (term_container.basic_term_num() > 0) {
      nlp::util::ConstructMixTerms(line, false, &term_container);
    }
    std::vector<nlp::time::TimeEntity> time_tokens;
    base::Time current_time = base::Time::Now();
    time_reco_->DetectTime(current_time, line,
                           term_container, &time_tokens);

    GenerateUnigram(line, term_container, time_tokens, &mix_unigrams);
    for (size_t i = 0; i < mix_unigrams.size(); ++i) {
      const base::Slice& term1 = mix_unigrams[i];
      for (size_t j = i + 1; j < mix_unigrams.size() && j < i + skip_num; ++j) {
        const base::Slice& term2 = mix_unigrams[j];
        if (!IsValidBigram(term1, term2)) continue;
        std::string term = base::StringPrintf("%s#%s", term1.as_string().c_str(), term2.as_string().c_str());
        if (term1 > term2) {
          term = base::StringPrintf("%s#%s", term2.as_string().c_str(), term1.as_string().c_str());
        }
        terms.push_back(term);
      }
    }
    std::string res;
    std::string temp;
    for (int i = 0; i < (int)terms.size(); ++i) {
      temp.clear();
      res = base::StringPrintf("paragraph#%s", terms[i].c_str());
      base::RemoveChars(res, base::kWhitespace, &temp);
      results->push_back(temp);
    }
  }
}

void GenerateContentNgram(nlp::segment::Segmenter* segmenter_,
                          nlp::postag::PosTagger* pos_tagger_,
                          nlp::ner::Ner* ner_,
                          nlp::time::TimeRecognizer* time_reco_,
                          const reco::RecoItem& item, std::vector<std::string>* results) {
  std::string content = item.raw_item().content();
  std::vector<std::string> paragraphs;
  GenerateParagraphs(content, &paragraphs);
  std::vector<std::string> lines;
  if (paragraphs.empty()) return;
  for (int i = 0; i < (int)paragraphs.size(); ++i) {
    lines.push_back(paragraphs[i]);
  }
  std::string line;
  std::vector<std::string> terms;
  nlp::term::TermContainer term_container;
  std::vector<base::Slice> mix_unigrams;
  for (int l = 0; l < (int)lines.size(); ++l) {
    line = lines[l];
    int char_num = 0;
    if (!base::GetUTF8CharNum(line, &char_num) || char_num == 0) continue;
    terms.clear();
    term_container.renew();
    mix_unigrams.clear();
    int skip_num = 3;
    CHECK(segmenter_->SegmentT(line, &term_container));
    CHECK(pos_tagger_->PosTagT(line, &term_container));
    CHECK(ner_->DetectEntityT(line, &term_container));
    if (term_container.basic_term_num() > 0) {
      nlp::util::ConstructMixTerms(line, false, &term_container);
    }
    std::vector<nlp::time::TimeEntity> time_tokens;
    base::Time current_time = base::Time::Now();
    time_reco_->DetectTime(current_time, line,
                           term_container, &time_tokens);

    GenerateUnigram(line, term_container, time_tokens, &mix_unigrams);
    for (size_t i = 0; i < mix_unigrams.size(); ++i) {
      const base::Slice& term1 = mix_unigrams[i];
      for (size_t j = i + 1; j < mix_unigrams.size() && j < i + skip_num; ++j) {
        const base::Slice& term2 = mix_unigrams[j];
        if (!IsValidBigram(term1, term2)) continue;
        std::string term = base::StringPrintf("%s#%s", term1.as_string().c_str(), term2.as_string().c_str());
        if (term1 > term2) {
          term = base::StringPrintf("%s#%s", term2.as_string().c_str(), term1.as_string().c_str());
        }
        terms.push_back(term);
      }
    }
    std::string res;
    std::string temp;
    for (int i = 0; i < (int)terms.size(); ++i) {
      temp.clear();
      res = base::StringPrintf("content#%s", terms[i].c_str());
      base::RemoveChars(res, base::kWhitespace, &temp);
      results->push_back(temp);
    }
  }
}

void GenerateSentenceNgram(nlp::segment::Segmenter* segmenter_,
                           nlp::postag::PosTagger* pos_tagger_,
                           nlp::ner::Ner* ner_,
                           nlp::time::TimeRecognizer* time_reco_,
                           const reco::RecoItem& item, std::vector<std::string>* results) {
  std::string content = item.raw_item().content();
  std::vector<std::string> paragraphs;
  GenerateParagraphs(content, &paragraphs);
  std::string line;
  int skip_num = 3;
  std::vector<std::string> sentences;
  std::vector<std::string> lines;
  for (int i = 0; i < (int)paragraphs.size(); ++i) {
    sentences.clear();
    GenerateSentences(paragraphs[i], &sentences);
    if (sentences.empty()) continue;
    if (sentences.size() < 2) {
      lines.push_back(line);
      continue;
    }
    lines.push_back(sentences.back());
  }
  std::vector<std::string> terms;
  nlp::term::TermContainer term_container;
  std::vector<base::Slice> mix_unigrams;
  for (int l = 0; l < (int)lines.size(); ++l) {
    line = lines[l];
    terms.clear();
    term_container.renew();
    mix_unigrams.clear();
    CHECK(segmenter_->SegmentT(line, &term_container));
    CHECK(pos_tagger_->PosTagT(line, &term_container));
    CHECK(ner_->DetectEntityT(line, &term_container));
    if (term_container.basic_term_num() > 0) {
      nlp::util::ConstructMixTerms(line, false, &term_container);
    }
    std::vector<nlp::time::TimeEntity> time_tokens;
    base::Time current_time = base::Time::Now();
    time_reco_->DetectTime(current_time, line,
                           term_container, &time_tokens);

    GenerateUnigram(line, term_container, time_tokens, &mix_unigrams);
    for (size_t i = 0; i < mix_unigrams.size(); ++i) {
      const base::Slice& term1 = mix_unigrams[i];
      for (size_t j = i + 1; j < mix_unigrams.size() && j < i + skip_num; ++j) {
        const base::Slice& term2 = mix_unigrams[j];
        if (!IsValidBigram(term1, term2)) continue;
        std::string term = base::StringPrintf("%s#%s", term1.as_string().c_str(), term2.as_string().c_str());
        if (term1 > term2) {
          term = base::StringPrintf("%s#%s", term2.as_string().c_str(), term1.as_string().c_str());
        }
        terms.push_back(term);
      }
    }
    std::string res;
    std::string temp;
    for (int i = 0; i < (int)terms.size(); ++i) {
      temp.clear();
      res = base::StringPrintf("sentence#%s", terms[i].c_str());
      base::RemoveChars(res, base::kWhitespace, &temp);
      results->push_back(temp);
    }
  }
}

void GenerateKeywords(const reco::RecoItem& item, std::vector<std::string>* results) {
  std::string res;
  for (int i = 0; i < (int)item.keyword().feature_size(); ++i) {
    if (!IsValidUnigram(item.keyword().feature(i).literal())) continue;
    res = base::StringPrintf("keyword#%s", item.keyword().feature(i).literal().data());
    base::TrimLeadingWhitespaces(&res);
    results->push_back(res);;
  }
}

void GenerateTitleCategoryNgram(nlp::segment::Segmenter* segmenter_,
                                nlp::postag::PosTagger* pos_tagger_,
                                nlp::ner::Ner* ner_,
                                nlp::time::TimeRecognizer* time_reco_,
                                const reco::RecoItem& item, std::vector<std::string>* results) {
  std::string line;
  std::string title = item.title();
  nlp::util::NormalizeLineInPlaceS(&title);
  base::RemoveChars(title, base::kWhitespace, &line);
  std::string category = item.category(0);
  if (category.empty() || category == "未分类") return;
  std::vector<std::string> terms;
  int skip_num = 3;
  nlp::term::TermContainer term_container;
  CHECK(segmenter_->SegmentT(line, &term_container));
  CHECK(pos_tagger_->PosTagT(line, &term_container));
  CHECK(ner_->DetectEntityT(line, &term_container));
  if (term_container.basic_term_num() > 0) {
    nlp::util::ConstructMixTerms(line, false, &term_container);
  }
  std::vector<nlp::time::TimeEntity> time_tokens;
  base::Time current_time = base::Time::Now();
  time_reco_->DetectTime(current_time, line,
                         term_container, &time_tokens);

  std::vector<base::Slice> mix_unigrams;
  GenerateUnigram(line, term_container, time_tokens, &mix_unigrams);
  for (size_t i = 0; i < mix_unigrams.size(); ++i) {
    const base::Slice& term1 = mix_unigrams[i];
    for (size_t j = i + 1; j < mix_unigrams.size() && j < i + skip_num; ++j) {
      const base::Slice& term2 = mix_unigrams[j];
      if (!IsValidBigram(term1, term2)) continue;
      std::string term = base::StringPrintf("%s#%s", term1.as_string().c_str(), term2.as_string().c_str());
      if (term1 > term2) {
        term = base::StringPrintf("%s#%s", term2.as_string().c_str(), term1.as_string().c_str());
      }
      terms.push_back(term);
    }
  }
  std::string res;
  std::string temp;
  for (int i = 0; i < (int)terms.size(); ++i) {
    temp.clear();
    res = base::StringPrintf("title_category#%s#%s", terms[i].c_str(), category.c_str());
    base::RemoveChars(res, base::kWhitespace, &temp);
    results->push_back(temp);
  }
}

void GenerateTitleSimbleNgram(nlp::segment::Segmenter* segmenter_,
                              nlp::postag::PosTagger* pos_tagger_,
                              nlp::ner::Ner* ner_,
                              nlp::time::TimeRecognizer* time_reco_,
                              const reco::RecoItem& item, std::vector<std::string>* results) {
  std::string line;
  std::string title = item.title();
  nlp::util::NormalizeLineInPlaceS(&title);
  base::RemoveChars(title, base::kWhitespace, &line);
  // calc simbles
  std::set<std::string> simbles;
  if (line.find("?") != std::string::npos) simbles.insert("?");
  if (line.find("!") != std::string::npos) simbles.insert("!");
  if (line.find(".") != std::string::npos) simbles.insert(".");
  if (line.find("。") != std::string::npos) simbles.insert("。");
  if (line.find("|") != std::string::npos) simbles.insert("|");
  if (line.find("*") != std::string::npos) simbles.insert("*");
  std::vector<std::string> terms;
  int skip_num = 3;
  nlp::term::TermContainer term_container;
  CHECK(segmenter_->SegmentT(line, &term_container));
  CHECK(pos_tagger_->PosTagT(line, &term_container));
  CHECK(ner_->DetectEntityT(line, &term_container));
  if (term_container.basic_term_num() > 0) {
    nlp::util::ConstructMixTerms(line, false, &term_container);
  }
  std::vector<nlp::time::TimeEntity> time_tokens;
  base::Time current_time = base::Time::Now();
  time_reco_->DetectTime(current_time, line,
                         term_container, &time_tokens);

  std::vector<base::Slice> mix_unigrams;
  GenerateUnigram(line, term_container, time_tokens, &mix_unigrams);
  for (size_t i = 0; i < mix_unigrams.size(); ++i) {
    const base::Slice& term1 = mix_unigrams[i];
    for (size_t j = i + 1; j < mix_unigrams.size() && j < i + skip_num; ++j) {
      const base::Slice& term2 = mix_unigrams[j];
      if (!IsValidBigram(term1, term2)) continue;
      std::string term = base::StringPrintf("%s#%s", term1.as_string().c_str(), term2.as_string().c_str());
      if (term1 > term2) {
        term = base::StringPrintf("%s#%s", term2.as_string().c_str(), term1.as_string().c_str());
      }
      terms.push_back(term);
    }
  }
  std::string res;
  std::string temp;
  for (int i = 0; i < (int)terms.size(); ++i) {
    for (auto it = simbles.begin(); it != simbles.end(); ++it) {
      temp.clear();
      res = base::StringPrintf("title_simble#%s#%s", terms[i].c_str(), it->c_str());
      base::RemoveChars(res, base::kWhitespace, &temp);
      results->push_back(temp);
    }
  }
}

void GenerateMediaRatio(const reco::RecoItem& item, int type, std::vector<std::string>* results) {
  if (item.has_orig_source_media()) {
    results->push_back(base::StringPrintf("%s\t%d", item.orig_source_media().c_str(), type));
    return;
  }
  if (item.has_source_media()) {
    results->push_back(base::StringPrintf("%s\t%d", item.source_media().c_str(), type));
    return;
  }
}

