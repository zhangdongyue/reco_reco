#include <string>
#include <vector>
#include <fstream>
#include "reco/module/bad_item/strategy/rubbish_detector.h"
#include "reco/module/bad_item/strategy/item_info.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/closure.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "reco/bizc/reco_ner/reco_ner.h"
#include "reco/bizc/proto/bad_item.pb.h"

DEFINE_int32(thread_num, 8, "thread_num");
DEFINE_int32(run_type, 0, "0 means use title, content, category in input, 1 means get item from habse");
DEFINE_int32(detect_type, 0, "0 means all, 1 means only fake title, 2 means only ad, 3 means only short content, 4 means dedup, 5 means dirty");  // NOLINT
DEFINE_string(result_file, "result.txt", "result file");
DEFINE_string(data_dir, "./data", "data dir");

void PredictWorker(thread::BlockingQueue<std::string>* input_queue,
                   thread::BlockingQueue<std::string>* result_queue,
                   thread::BlockingVar<int>* finish_num) {
  bool with_hbase = false;
  if (FLAGS_run_type == 1) with_hbase = true;
  reco::bad_item::RubbishDetector* detector = new reco::bad_item::RubbishDetector(with_hbase);

  int bitmap = 0;
  if (FLAGS_detect_type == 0) {
    bitmap = 1 << reco::bad_item::kFakeTitle | 1 << reco::bad_item::kAdvertorial
        | 1 << reco::bad_item::kShortContent | 1 << reco::bad_item::kDedupParagraph
        | 1 << reco::bad_item::kDirty;
  } else {
    bitmap = 1 << (FLAGS_detect_type - 1);
  }

  std::string line;
  std::vector<std::string> flds;
  std::vector<std::pair<double, int>> results;
  while (!(input_queue->Closed() && input_queue->Empty())) {
    int status = input_queue->TimedTake(10, &line);
    if (status == 0) {
      base::SleepForMilliseconds(100);
      continue;
    }
    if (status == -1) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status " << status;

    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (line.size() < 2) continue;

    detector->Detect(flds, bitmap, &results);

    for (size_t i = 0; i < results.size(); ++i) {
      result_queue->Put(base::StringPrintf("%s\t%s\t%lf", flds[0].c_str(),
                                           reco::bad_item::kAllRubbish[results[i].second].c_str(),
                                           results[i].first));
    }
  }

  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    result_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

void SaveWorker(thread::BlockingQueue<std::string>* result_queue) {
  std::string line;
  std::ofstream fout(FLAGS_result_file);
  while (!(result_queue->Closed() && result_queue->Empty())) {
    int status = result_queue->TimedTake(10, &line);
    if (status == 0) {
      base::SleepForMilliseconds(100);
      continue;
    }
    if (status == -1) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status " << status;

    fout << line << std::endl;
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "ruanwen demo");
  CHECK(reco::bad_item::RubbishDetector::ReloadDict(base::FilePath(FLAGS_data_dir), true));
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  thread::BlockingQueue<std::string> input_queue;
  thread::BlockingQueue<std::string> result_queue;
  thread::ThreadPool pool(FLAGS_thread_num + 1);
  pool.AddTask(::NewCallback(SaveWorker, &result_queue));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(PredictWorker, &input_queue, &result_queue, &finish_num));
  }

  std::string line;
  while (std::getline(std::cin, line)) {
    input_queue.Put(line);
  }
  input_queue.Close();

  pool.JoinAll();

  return 0;
}
