#include <vector>
#include <string>
#include <unordered_map>
#include <iostream>
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/hash_function/term.h"
#include "base/common/base.h"

const char* kSourceLevelPrefix = "SourceLevel-";
const char* kReadRatioPrefix  = "ReadRatio-";
const char* kReadSpeedPrefix = "ReadSpeed-";
const char* kSupportPrefix = "Support-";
const char* kCollectPrefix = "Collect-";
const char* kForwardPrefix = "Forward-";
const char* kImagePrefix = "Image-";
const char* kCommentPrefix = "Comment-";

struct RawFea {
  int click;
  float read_ratio;
  float read_speed;
  int comment;
  int image_num;
  int item_type;
  int source_level;
};

bool ParseRawFea(const std::vector<std::string>& flds, RawFea* fea) {
  fea->click = base::ParseIntOrDie(flds[1]);
  fea->read_ratio = base::ParseDoubleOrDie(flds[2]);
  fea->read_speed = base::ParseDoubleOrDie(flds[3]);
  fea->comment = base::ParseIntOrDie(flds[4]);
  fea->image_num = base::ParseIntOrDie(flds[5]);
  fea->item_type = base::ParseIntOrDie(flds[6]);
  if (flds[9].empty()) {
    fea->source_level = 1;
  } else {
    fea->source_level = base::ParseIntOrDie(flds[9]);
  }

  return true;
}

void add_fea(const char* prefix, const std::string& fea_str, std::vector<std::pair<uint64, float> >* feas,
             std::unordered_map<uint64, std::string>* sign_to_text) {
  std::string str = base::StringPrintf("%s%s", prefix, fea_str.c_str());
  uint64 sign = base::CalcTermSign(str.c_str(), str.size());
  if (sign_to_text != NULL) {
    sign_to_text->insert(std::make_pair(sign, str));
  }

  feas->push_back(std::make_pair(sign, 1.0));
}

inline int dis_read_speed(float read_speed) {
  if (read_speed < 0.01) {
    return 0;
  } else if (read_speed < 0.1) {
    return 1;
  } else if (read_speed < 1) {
    return 2;
  } else if (read_speed < 2) {
    return 3;
  }
  return 4;
}

inline int dis_comment(int comment) {
  if (comment < 1) {
    return 0;
  } else if (comment < 5) {
    return 1;
  } else if (comment < 10) {
    return 2;
  } else if (comment < 20) {
    return 3;
  }
  return 4;
}

inline int dis_image(int image_num) {
  if (image_num < 1) {
    return 0;
  } else if (image_num < 3) {
    return 1;
  } else if (image_num < 6) {
    return 2;
  } else if (image_num < 10) {
    return 3;
  }
  return 4;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "post feature extractor");
  std::string line;
  std::vector<std::string> flds;
  RawFea fea;
  std::vector<std::pair<uint64, float>> features;
  std::unordered_map<uint64, std::string> sign_dict;
  std::string fea_str;
  while (std::getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 10) continue;

    if (!ParseRawFea(flds, &fea)) {
      continue;
    }
    features.clear();

    add_fea(kSourceLevelPrefix, base::IntToString(fea.source_level), &features, &sign_dict);

    int dis_value = (int)(fea.read_ratio * 10);
    add_fea(kReadRatioPrefix, base::IntToString(dis_value), &features, &sign_dict);

    add_fea(kReadSpeedPrefix, base::IntToString(dis_read_speed(fea.read_speed)), &features, &sign_dict);
    add_fea(kCommentPrefix, base::IntToString(dis_comment(fea.comment)), &features, &sign_dict);
    add_fea(kImagePrefix, base::IntToString(dis_image(fea.image_num)), &features, &sign_dict);

    std::sort(features.begin(), features.end());
    std::cout << fea.click << "\t" << (int)(fea.click * fea.read_ratio);
    for (size_t i = 0; i < features.size(); ++i) {
      std::cout << "\t" << features[i].first << ":" << features[i].second;
    }
    std::cout << "\n";
  }
  return 0;
}
