#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/strings/string_split.h"
#include "base/hash_function/term.h"

DEFINE_string(input, "input.txt", "");
DEFINE_string(output, "output.txt", "");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "text to sign");
  std::ifstream fin(FLAGS_input);
  std::ofstream fout(FLAGS_output);
  std::string line;
  while (std::getline(fin, line)) {
    uint64 sign = base::CalcTermSign(line.c_str(), line.size());
    fout << line << "\t:\t" << sign << std::endl;
  }
  fin.close();
  fout.close();
}
