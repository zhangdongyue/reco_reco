#include "reco/module/bad_item/offline/training_util.h"

#include "base/hash_function/term.h"
#include "reco/bizc/item_service/hbase_pool_get_item.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

DEFINE_string(hbase_table, "tb_reco_item", "hbase table");
DEFINE_string(sign_path, "signs.txt", "");
DEFINE_int32(run_type, 0, "");

std::unordered_set<uint64> signs;
nlp::segment::Segmenter* segmenter_;
nlp::postag::PosTagger* pos_tagger_;
nlp::ner::Ner* ner_;
nlp::time::TimeRecognizer* time_reco_;

void Initial() {
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());
  std::ifstream fin(FLAGS_sign_path);
  std::string line;
  while (std::getline(fin, line)) {
    uint64 sign;
    base::StringToUint64(line, &sign);
    signs.insert(sign);
  }
  fin.close();
  segmenter_ = new nlp::segment::Segmenter;
  pos_tagger_ = new nlp::postag::PosTagger;
  ner_ = new nlp::ner::Ner;
  time_reco_ = new nlp::time::TimeRecognizer();
}

void Destory() {
  delete ner_;
  ner_ = NULL;
  delete pos_tagger_;
  pos_tagger_ = NULL;
  delete segmenter_;
  segmenter_ = NULL;
  delete time_reco_;
  time_reco_ = NULL;
}

void mapper() {
  reco::HBasePoolGetItem* item_getter = new reco::HBasePoolGetItem(FLAGS_hbase_table, 20000);
  std::string line;
  std::vector<std::string> tokens;
  uint64 item_id;
  int type;
  std::vector<std::string> result;
  std::set<uint64> features;
  std::string result_str;
  reco::item_classify::FeatureExtractor *feature_extractor = new reco::item_classify::FeatureExtractor(0);
  while (std::getline(std::cin, line)) {
    features.clear();
    result_str.clear();
    result.clear();
    tokens.clear();
    feature_extractor->renew();
    base::SplitString(line, "\t", &tokens);
    CHECK_EQ((int)tokens.size(), 2);
    if (!base::StringToUint64(tokens[0], &item_id)) continue;
    if (!base::StringToInt(tokens[1], &type)) continue;
    reco::RecoItem reco_item;
    if (!item_getter->GetRecoItem(item_id, &reco_item)) continue;

    GenerateTitleNgram(segmenter_, pos_tagger_, ner_, time_reco_, reco_item, &result);
    GenerateTitleMediaNgram(segmenter_, pos_tagger_, ner_, time_reco_, reco_item, &result);
    GenerateTitleCategoryNgram(segmenter_, pos_tagger_, ner_, time_reco_, reco_item, &result);
    GenerateContentNgram(segmenter_, pos_tagger_, ner_, time_reco_, reco_item, &result);
    GenerateKeywords(reco_item, &result);
    for (int i = 0; i < (int)result.size(); ++i) {
      uint64 sign = base::CalcTermSign(result[i].c_str(), result[i].size());
      if (signs.find(sign) != signs.end()) features.insert(sign);
    }
    if (features.empty()) continue;
    // generate result string
    result_str = "1\t0\t";
    if (type == 1) {
      result_str = "1\t1\t";
    }
    for (auto it = features.begin(); it != features.end(); ++it) {
      result_str += base::StringPrintf("%lu:1 ", *it);
    }
    base::TrimTrailingWhitespaces(&result_str);
    std::cout << "A#" << result_str << std::endl;
    std::cout << "B#" << reco_item.title() << "\t" << result_str << std::endl;
  }
  delete feature_extractor;
  feature_extractor = NULL;
}

void reducer() {
  std::string line;
  while (std::getline(std::cin, line)) {
    std::cout << line << std::endl;
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "generate training samples");
  if (FLAGS_run_type == 0) {
    Initial();
    mapper();
    Destory();
  } else {
    reducer();
  }
  return 0;
}
