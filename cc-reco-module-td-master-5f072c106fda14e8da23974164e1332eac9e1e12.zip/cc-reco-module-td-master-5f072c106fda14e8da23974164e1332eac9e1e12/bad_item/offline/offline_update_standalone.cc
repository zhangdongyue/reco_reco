#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <unordered_set>
#include <unordered_map>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "reco/base/kafka_c/api/topic_producer.h"
#include "reco/bizc/item_service/hbase_get_item_attr.h"
#include "reco/bizc/item_service/hbase_get_item.h"

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/bad_item.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"

DEFINE_string(input_file, "input.txt", "input file path contains items to be updated");

DEFINE_string(kafka_brokers, "10.181.169.190:9092,10.181.169.191:9092,10.181.169.192:9092,10.181.169.193:9092,10.181.169.194:9092", "kafka queue servers");  // NOLINT
DEFINE_string(kafka_topic_name, "", "topic name");
DEFINE_int32(kafka_total_partition, 9, "partition num for some topic");

DEFINE_string(hbase_ip, "10.181.169.20", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table_item, "tb_reco_item", "hbase table");
DEFINE_string(hbase_table_attr, "tb_item_field", "hbase table");

namespace reco {
namespace bad_item {

std::map<uint64, std::vector<int>> bad_items;
std::map<uint64, reco::ContentAttr> update_items;
reco::ContentAttr::ContentAttrLevel attr_values[] = {
  reco::ContentAttr::kSureNo,
  reco::ContentAttr::kSuspect,
  reco::ContentAttr::kSureYes
};
reco::HBaseGetItemAttr* get_item_attr_;
reco::HBaseGetItem* get_item_service_;

void Initial() {
  get_item_attr_= new reco::HBaseGetItemAttr(FLAGS_hbase_table_attr);
  get_item_service_= new reco::HBaseGetItem(FLAGS_hbase_table_item, 10);
}
void LoadBadItemInfo() {
  std::ifstream fin(FLAGS_input_file);
  if (!fin.is_open()) {
    LOG(INFO) << base::GetTimestamp() << "load fail, no file: "  << FLAGS_input_file;
    return;
  }
  std::string line;
  std::vector<std::string> tokens;
  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    CHECK_EQ((int)tokens.size(), 6);
    uint64 item_id = base::ParseUint64OrDie(tokens[0]);
    std::vector<int> tags;
    tags.reserve(32);
    for (int i = 1; i < (int)tokens.size(); ++i) {
      tags.push_back(base::ParseIntOrDie(tokens[i]));
    }
    bad_items.insert(std::make_pair(item_id, tags));
  }
}

void GenerateBadItem() {
  for (auto it = bad_items.begin(); it != bad_items.end(); ++it) {
    bool exist = true;
    reco::ContentAttr content_attr;
    if (!get_item_attr_->GetItemAttr(it->first, 0, &content_attr)) {
      exist = false;
    }
    // update in content_attr
    if (exist) {
      if (content_attr.advertorial() == attr_values[0] && it->second[0] != 0) {
        content_attr.set_advertorial(attr_values[1]);
      }
      if (content_attr.dirty() == attr_values[0] && it->second[1] != 0) {
        content_attr.set_dirty(attr_values[1]);
      }
      if (content_attr.dedup_paragraph() == attr_values[0] && it->second[2] != 0) {
        content_attr.set_dedup_paragraph(attr_values[1]);
      }
      if (content_attr.bluffing_title() == attr_values[0] && it->second[3] != 0) {
        content_attr.set_bluffing_title(attr_values[1]);
      }
      if (content_attr.short_content() == attr_values[0] && it->second[4] != 0) {
        content_attr.set_short_content(attr_values[1]);
      }
    } else {
      reco::RecoItem item;
      if (!get_item_service_->GetRecoItem(it->first, &item)) {
        LOG(INFO) << "cannot find item from hbase: " << it->first;
        continue;
      }
      content_attr.set_advertorial(attr_values[it->second[0]]);
      content_attr.set_dirty(attr_values[it->second[1]]);
      content_attr.set_dedup_paragraph(attr_values[it->second[2]]);
      content_attr.set_bluffing_title(attr_values[it->second[3]]);
      content_attr.set_short_content(attr_values[it->second[4]]);
      content_attr.set_erro_title(attr_values[0]);
      content_attr.set_politics(attr_values[0]);
    }
    update_items.insert(std::make_pair(it->first, content_attr));
  }
}

void Update() {
  reco::kafka::TopicProducer producer(FLAGS_kafka_brokers,
                                      FLAGS_kafka_topic_name,
                                      FLAGS_kafka_total_partition);
  std::string message;
  message.reserve(4096);
  int partition = 0;
  reco::RawItemFieldUpdateRequest request;
  reco::RawItemField item_fld;
  std::string content_attr_str;
  std::pair<uint64, reco::ContentAttr> element;
  for (auto it = update_items.begin(); it != update_items.end(); ++it) {
    if (!it->second.SerializeToString(&content_attr_str)) {
      LOG(ERROR) << "failed to serilize to string fo item: " << it->first;
      continue;
    }
    LOG(INFO) << "success!\t" << it->first
              << "\t" << it->second.erro_title()
              << "\t" << it->second.advertorial()
              << "\t" << it->second.short_content()
              << "\t" << it->second.dedup_paragraph()
              << "\t" << it->second.dirty()
              << "\t" << it->second.politics()
              << "\t" << it->second.bluffing_title();
    item_fld.set_field_name("content_attr");
    item_fld.set_is_manual(false);
    item_fld.set_value(content_attr_str);

    request.Clear();
    request.set_item_id(it->first);
    request.set_timestamp(base::GetTimestamp() / 1000);
    request.add_fields()->Swap(&item_fld);
    request.SerializeToString(&message);
    if (!producer.Push(partition, message)) {
      LOG(ERROR) << base::StringPrintf("failed to push to kafka queue: %s, partition: %d, item id: %lu",
                                       FLAGS_kafka_brokers.c_str(), partition, it->first);
    } else {
      LOG(INFO) << base::StringPrintf("succ push to kafka queue: %s, partition: %d, item id: %lu",
                                      FLAGS_kafka_brokers.c_str(), partition, it->first);
      partition = (partition + 1) % FLAGS_kafka_total_partition;
    }
    partition = (partition + 1) % FLAGS_kafka_total_partition;
  }
}
}
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "bad item offline update");
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());

  LOG(INFO) << "begin update offline bad item";
  reco::bad_item::Initial();
  reco::bad_item::LoadBadItemInfo();
  reco::bad_item::GenerateBadItem();
  reco::bad_item::Update();
  LOG(INFO) << "finish update offline bad item";
  return 0;
}
