#include <string>
#include "base/strings/string_number_conversions.h"
#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "base/common/sleep.h"
#include "reco/bizc/item_service/define.h"
#include "reco/bizc/item_service/hbase_get_item_attr.h"
#include "reco/base/hbase_c/api/hbase_client.h"

DEFINE_string(hbase_ip, "100.85.69.80", "hbase ip");
DEFINE_string(hbase_item_attr_table, "tb_item_field", "hbase item attr table name");
DEFINE_int32(hbase_port, 9090, "hbase port");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "batch delete from hbase");
  reco::hbase::HBaseCli* hbase = new reco::hbase::HBaseCli(FLAGS_hbase_ip, base::IntToString(FLAGS_hbase_port));
  CHECK(hbase->Connect());

  const std::string& table_name = FLAGS_hbase_item_attr_table;
  
  reco::HBaseGetItemAttr get_item_attr(FLAGS_hbase_ip, FLAGS_hbase_port, table_name);

  std::string line;
  std::vector<std::string> keys;
  keys.reserve(10000);
  reco::ContentAttr content_attr;
  while (std::getline(std::cin, line)) {
    uint64 item_id = base::ParseUint64OrDie(line);
    std::string row_key = base::StringPrintf("%lu_%s", item_id, reco::item_attr::kAllSuffix[reco::item_attr::kContentAttr]);
    
    if (!get_item_attr.GetItemAttr(item_id, reco::item_attr::kContentAttr, &content_attr)) {
      LOG(ERROR) << "get item content attr from hbase failed! " << item_id;
      continue;
    }

    if (hbase->DelByKey(table_name, row_key)) {
      LOG(ERROR) << "delte from hbase succ! " << row_key;
    } else {
      LOG(ERROR) << "delte from hbase failed! " << row_key;
    }
  }
  return 0;
}
