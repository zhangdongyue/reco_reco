#include <string>
#include <vector>

#include "reco/module/bad_item/strategy/comment_detector.h"
#include "base/common/base.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

DEFINE_string(data_dir, "./dict", "dict dir");
DEFINE_int32(run_type, 0, "0 mean use item id to fetch comments; 1 means to use comments as inputs");
DEFINE_bool(is_plan_text_model, false, "is plan text model");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "fake title demo");

  reco::bad_item::CommentDetector detector;
  std::string line;
  std::vector<std::string> tokens;
  CHECK(reco::bad_item::CommentModel::ReloadDict(base::FilePath(FLAGS_data_dir), FLAGS_is_plan_text_model));
  std::vector<std::string> comments;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    uint64 item_id = base::ParseUint64OrDie(tokens[0]);
    double score = 0;
    comments.clear();
    if (FLAGS_run_type == 0) {
      score = detector.Predict(item_id);
    } else if (FLAGS_run_type == 1) {
      comments.assign(tokens.begin() + 1, tokens.end());
      score = detector.Predict(item_id, comments);
    } else {
      LOG(ERROR) << "erro run type: " << FLAGS_run_type;
      break;
    }

    std::cout << base::StringPrintf("%lf\t%s\n", score, line.c_str());
  }
  return 0;
}
