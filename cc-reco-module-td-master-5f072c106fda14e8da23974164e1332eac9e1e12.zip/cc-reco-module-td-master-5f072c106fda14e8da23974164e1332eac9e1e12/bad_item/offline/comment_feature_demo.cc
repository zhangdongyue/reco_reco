#include <string>
#include <vector>
#include <fstream>

#include "reco/module/bad_item/feature/comment_feature_extractor.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/file/file_path.h"

DEFINE_string(data_dir, "./dict", "data dir");
DEFINE_string(feature_dict_file, "feature_dict.txt", "fea sign to text");

void GenerateOutStr(int label, const std::vector<std::pair<uint64, float> >& fea, std::string* result) {
  result->clear();
  *result += base::IntToString(label);
  for (size_t i = 0; i < fea.size(); ++i) {
    *result += base::StringPrintf("\t%lu:%f", fea[i].first, fea[i].second);
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "feature demo");
  std::string line;
  std::vector<std::string> tokens;
  reco::bad_item::CommentFeatureExtractor extractor;

  extractor.Initial(base::FilePath(FLAGS_data_dir));
  std::vector<std::pair<uint64, float>> features;
  std::unordered_map<uint64, std::string> feature_dict;

  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 2) continue;

    features.clear();
    int fea_num = extractor.Extract(tokens[1], false, &features, &feature_dict);
    if (fea_num < 1) continue;
    GenerateOutStr(base::ParseIntOrDie(tokens[0]), features, &line);
    std::cout << line << std::endl;
  }

  // save feature dict
  std::ofstream fout(FLAGS_feature_dict_file);
  for (auto it = feature_dict.begin(); it != feature_dict.end(); ++it) {
    fout << base::StringPrintf("%lu\t%s\n", it->first, it->second.c_str());
  }
  return 0;
}
