#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"

#include "extend/web_client/web_client.h"

DEFINE_string(item_server_address, "http://100.85.69.70:20005/item/", "itemserver address");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "test url get");
  extend::WebClient web_client;
  extend::WebClient::Request web_request;
  extend::WebClient::Response web_response;
  web_client.Init();

  web_request.url = base::StringPrintf("%s/quality_attr/123456789/1/1",
                                       FLAGS_item_server_address.c_str());
  
  web_client.AddTask(&web_request, &web_response, NULL);

  web_client.WaitForAll();
  if (!web_response.success) {
    LOG(ERROR) << base::StringPrintf("failed request for item: %s",
                                     web_request.url.c_str());
    return -1;
  }

  if (!web_response.error_desc.empty()) {
    LOG(ERROR) << base::StringPrintf("erro happend for item: %s",
                                     web_request.url.c_str());
    return -1;
  }

  LOG(INFO) << base::StringPrintf("succ push item %s to item server, http code=%d",
                                  web_request.url.c_str(),
                                  web_response.http_response_code);
  return 0;
}
