#include <string>
#include <map>
#include <iostream>
#include <fstream>
#include "base/common/base.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "rpc/redis/client.h"
#include "rpc/redis/client_pool.h"
#include "reco/module/item_level/base.h"
#include "rpc/redis/twemp_client_pool.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"

// 更新 item meta info 所使用的 redis
DEFINE_string(item_redis_server_ip, "10.181.170.169", "redis ip");
DEFINE_int32(item_redis_server_port, 6379, "redis port");
DEFINE_int32(redis_pool_size, 16, "redis pool size");
DEFINE_int32(thread_num, 16, "thread num for push item to redis");

DEFINE_string(twemp_redis_ip, "10.182.2.123", "redis ip");
DEFINE_int32(twemp_redis_port, 6497, "redis port");

DEFINE_string(succ_file, "succ.txt", "succ file for debuging");
DEFINE_int32(run_type, 0, "0 means both normal redis and twemp, 1:normal redis only, 2:twemp only");
DEFINE_int32(life_in_days, 30, "life in days");
DEFINE_bool(delete_first, false, "if set delete key first");

inline void GenRedisKey(uint64 key_id, std::string* key) {
  *key = base::StringPrintf("RubishItemQuality-%lu", key_id);
}

void SendWorker(thread::BlockingQueue<std::string>* input_queue,
                redis::TwempClientPool* twemp_client_pool,
                redis::ClientPool* client_pool)  {
  std::string value;
  std::string orig_value;
  std::string key;
  int life_in_seconds = FLAGS_life_in_days * 86400;

  std::vector<std::string> flds;
  std::string line;
  const std::string rubbish = "0";
  const std::string low = "1";
  const std::string field = "Score";
  while (!(input_queue->Closed() && input_queue->Empty())) {
    int status = input_queue->TimedTake(10, &line);
    if (status == 0) {
      base::SleepForMilliseconds(200);
      continue;
    }

    if (status < 0) {
      break;
    }
    CHECK_EQ(status, 1) << "check fucking status " << status;
    
    flds.clear();
    base::SplitString(line, "\t", &flds);
    uint64 item_id = base::ParseUint64OrDie(flds[0]);
    GenRedisKey(item_id, &key);
  
    if (twemp_client_pool != NULL) {
      redis::TwempAutoPutback twemp_put_back(twemp_client_pool);
      redis::TwempClient* twemp_client = twemp_put_back.TimedTake(100);
      if (twemp_client == NULL) {
        LOG(ERROR) << "cannot get redisclient!";
        LOG(ERROR) << "write to redis failed! " << line;
        continue;
      }

      if (FLAGS_delete_first && twemp_client->Delete(key.c_str(), key.size()) != 0) {
        LOG(ERROR) << base::StringPrintf("delete key: %s, failed", key.c_str());
      }
      if (!twemp_client->HashSetEx(key.c_str(), key.size(), field.c_str(), field.size(), rubbish.c_str(), rubbish.size(), life_in_seconds)) {
        LOG(ERROR) << base::StringPrintf("write to redis failed! key: %s, field:%s, value:%s",
                   key.c_str(), field.c_str(), rubbish.c_str());
      } else {
        LOG(INFO) << base::StringPrintf("update redis succ! key: %s, field:%s, value:%s",
                   key.c_str(), field.c_str(), rubbish.c_str());
      }
    }

    if (client_pool != NULL) {
      redis::AutoPutback put_back(client_pool);
      redis::Client* client = put_back.TimedTake(100);
      if (client == NULL) {
        LOG(ERROR) << "cannot get redisclient!";
        LOG(ERROR) << "write to redis failed! " << line;
        continue;
      }

      if (FLAGS_delete_first && client->Delete(key.c_str(), key.size()) != 0) {
        LOG(ERROR) << base::StringPrintf("delete key: %s, failed", key.c_str());
      }

      if (!client->HashSetEx(key.c_str(), key.size(), field.c_str(), field.size(), rubbish.c_str(), rubbish.size(), life_in_seconds)) {
        LOG(ERROR) << base::StringPrintf("write to redis failed! key: %s, field:%s, value:%s",
                   key.c_str(), field.c_str(), rubbish.c_str());
      } else {
        LOG(INFO) << base::StringPrintf("update redis succ! key: %s, field:%s, value:%s",
                   key.c_str(), field.c_str(), rubbish.c_str());
      }
    }
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "batch write redis value");
  redis::TwempClientPool* twemp_client_pool = NULL;
  redis::ClientPool* client_pool = NULL;
  
  if (FLAGS_run_type == 0 || FLAGS_run_type == 1) {
    redis::GenerateMultiRedisConnect(FLAGS_item_redis_server_ip,
                                     FLAGS_item_redis_server_port,
                                     FLAGS_redis_pool_size);

    client_pool = redis::GetClientPool(FLAGS_item_redis_server_ip,
                                       FLAGS_item_redis_server_port);
    CHECK_NOTNULL(client_pool);
  } else if (FLAGS_run_type == 0 || FLAGS_run_type == 2) {
    redis::GenerateMultiTwempRedisConnect(FLAGS_twemp_redis_ip,
                                          FLAGS_twemp_redis_port,
                                          FLAGS_redis_pool_size);

    twemp_client_pool = redis::GetTwempClientPool(FLAGS_twemp_redis_ip,
                                                  FLAGS_twemp_redis_port);
    CHECK_NOTNULL(twemp_client_pool);
  }


  thread::ThreadPool pool(FLAGS_thread_num);
  thread::BlockingQueue<std::string> input_queue;
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(SendWorker, &input_queue, twemp_client_pool, client_pool));
  }

  std::string line;
  while (std::getline(std::cin, line)) {
    input_queue.Put(line);
  }
  input_queue.Close();
  pool.JoinAll();
  return 0;
}
