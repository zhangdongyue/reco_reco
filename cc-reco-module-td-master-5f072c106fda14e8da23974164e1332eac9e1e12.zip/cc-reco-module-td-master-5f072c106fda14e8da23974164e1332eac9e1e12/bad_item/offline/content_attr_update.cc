// 输入item id ，向 server 发请求 ， 结果直接写入 hbase content attr 字段
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "serving_base/utility/signal.h"
#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"
#include "serving_base/utility/time_helper.h"
#include "storage/message_queue/api/message_client_generator.h"

#include "reco/bizc/proto/bad_item.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/item_service/hbase_pool_get_item.h"
#include "reco/bizc/item_service/hbase_pool_set_item_attr.h"

DEFINE_string(bad_item_server_ip, "127.0.0.1", "bad item server ip, seperated by comma");
DEFINE_int32(bad_item_server_port, 9090, "bad item server port");

DEFINE_int32(bad_item_server_timeout, 2000, "search server rpc timeout in ms");
DEFINE_int32(bad_item_server_retry_times, 0, "search server rpc retry times");

DEFINE_string(hbase_table, "tb_reco_item", "hbase table");
DEFINE_string(hbase_update_table, "tb_item_field", "update hbase table");

DEFINE_int32(thread_num, 2, "number of thread for save sim pair to db");

DEFINE_string(input, "", "ids file");

using reco::bad_item::BadItemRequest;
using reco::bad_item::BadItemResponse;

net::rpc::RpcGroup* bad_item_rpc_group_ = NULL;

static net::rpc::RpcGroup* SetupConnection(const std::vector<std::string>& ips, int port,
                                           int timeout, int retry) {
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = retry;
  options.timeout = timeout;
  for (int i = 0; i < (int)ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], port, timeout);
    options.servers.push_back(si);
  }

  auto group = new net::rpc::RpcGroup(options);
  CHECK(group->Connect());
  return group;
}

static void GenerateRequest(std::string filename,
                            thread::BlockingQueue<uint64>* req_q) {
  std::ifstream input(filename);
  if (!input.good()) {
    LOG(ERROR) << "err in read item id from file" << filename;
    req_q->Close();
    return;
  }

  std::string line;
  while (std::getline(input, line)) {
    uint64 item_id = 0;
    if (!base::StringToUint64(line, &item_id)) {
      LOG(ERROR) << "erro line: " << line;
      continue;
    }
    LOG(INFO) << "put item from file: " << item_id;
    req_q->Put(item_id);
  }
  input.close();
  LOG(INFO) << "read file finished!";
  req_q->Close();
}

static bool is_rubbish(const reco::ContentAttr& content_attr, int* type) {
  if (content_attr.has_erro_title() && content_attr.erro_title() != reco::ContentAttr::kSureNo) return true;
  if (content_attr.has_advertorial() && content_attr.advertorial() != reco::ContentAttr::kSureNo) return true;
  if (content_attr.has_short_content() && content_attr.short_content() != reco::ContentAttr::kSureNo) return true;  // NOLINT
  if (content_attr.has_dedup_paragraph() && content_attr.dedup_paragraph() != reco::ContentAttr::kSureNo) return true;  // NOLINT
  if (content_attr.has_dirty() && content_attr.dirty() != reco::ContentAttr::kSureNo) return true;
  if (content_attr.has_politics() && content_attr.politics() != reco::ContentAttr::kSureNo) return true;
  if (content_attr.has_bluffing_title() && content_attr.bluffing_title() != reco::ContentAttr::kSureNo) return true;  // NOLINT
  if (content_attr.has_negative() && content_attr.negative() != reco::ContentAttr::kSureNo) {
    *type = 1;
    return true;
  }
  return false;
}

static void Updator(thread::BlockingQueue<uint64>* request_queue) {  // NOLINT
  reco::HBasePoolSetItemAttr* hbase_seter = new reco::HBasePoolSetItemAttr(FLAGS_hbase_update_table);
  reco::HBasePoolGetItem* hbase_get_item = new reco::HBasePoolGetItem(FLAGS_hbase_table, 0);
  reco::bad_item::BadItemService::Stub stub(bad_item_rpc_group_);
  BadItemResponse response;
  uint64 item_id;
  int count = 0;
  while (!(request_queue->Closed() && request_queue->Empty())) {
    int status = request_queue->TimedTake(100, &item_id);
    if (status == 0) {
      base::SleepForMilliseconds(1000);
      continue;
    }
    if (status < 0) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status: " << status;

    reco::RecoItem *reco_item = new reco::RecoItem();
    if (!hbase_get_item->GetRecoItem(item_id, reco_item)) {
      LOG(ERROR) << "failed to get item from hbase: " << item_id;
      delete reco_item;
      reco_item = NULL;
      continue;
    }
    if (!reco_item->has_raw_item()) {
      delete reco_item;
      reco_item = NULL;
      continue;
    }
    BadItemRequest* request = new BadItemRequest();
    request->set_item_id(reco_item->identity().item_id());
    request->mutable_reco_item()->Swap(reco_item);
    if (!request->has_reco_item()) {
      LOG(ERROR) << "empty request " << item_id;
      delete request;
      request = NULL;
      delete reco_item;
      reco_item = NULL;
      continue;
    }

    count++;
    if (count == 500000) {
      count = 0;
      base::SleepForSeconds(1);
    }

    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(15);
    LOG(INFO) << "send item: " << item_id;
    stub.DetectBadItem(&rpc, request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
      if (!bad_item_rpc_group_->IsConnected() && !bad_item_rpc_group_->Connect()) {
        LOG(ERROR) << "cannot conenct to bad item server";
        base::SleepForSeconds(5);
      }
      LOG(ERROR) << "get bad item failed for:\t" << item_id;
      delete request;
      request = NULL;
      delete reco_item;
      reco_item = NULL;
      continue;
    }

    // 发现 bad item 直接改 habse 中的值
    int type = 0;
    if (is_rubbish(response.content_attr(), &type) && type == 1) {
      LOG(INFO) << "negative item: " << item_id;
      if(!hbase_seter->SetItemAttr(item_id, 0, response.content_attr())) {
        LOG(ERROR) << "failed to set item attr:\t" << item_id;
      }
    } else {
      LOG(INFO) << "other item: " << item_id;
    }
    delete request;
    request = NULL;
    delete reco_item;
    reco_item = NULL;
  }
  delete hbase_seter;
  hbase_seter = NULL;
  delete hbase_get_item;
  hbase_get_item = NULL;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "bad item updator client");
  std::vector<std::string> flds;
  base::SplitString(FLAGS_bad_item_server_ip, ",", &flds);
  bad_item_rpc_group_ = SetupConnection(flds, FLAGS_bad_item_server_port,
                                        FLAGS_bad_item_server_timeout, FLAGS_bad_item_server_retry_times);
  flds.clear();
  thread::ThreadPool pool(FLAGS_thread_num + 1);

  thread::BlockingQueue<uint64> request_queue;
  pool.AddTask(::NewCallback(&GenerateRequest, FLAGS_input, &request_queue));

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(&Updator, &request_queue));
  }
  pool.JoinAll();
  delete bad_item_rpc_group_;
  return 0;
}
