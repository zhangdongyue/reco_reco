#include <string>
#include <map>
#include <iostream>
#include <fstream>
#include "base/common/base.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "rpc/redis/client.h"
#include "rpc/redis/client_pool.h"
#include "reco/module/item_level/base.h"

// 更新 item meta info 所使用的 redis
DEFINE_string(item_redis_server_ip, "10.181.170.169", "redis ip");
DEFINE_int32(item_redis_server_port, 6379, "redis port");

DEFINE_string(twemp_redis_ip, "10.182.2.123", "redis ip");
DEFINE_int32(twemp_redis_port, 6497, "redis port");

DEFINE_string(succ_file, "succ.txt", "succ file for debuging");
DEFINE_int32(run_type, 0, "0 means both normal redis and twemp, 1:normal redis only, 2:twemp only");

void rm_unexist_keys(const std::vector<std::string>& keys,
                     const std::vector<std::string>& fields,
                     const std::vector<std::string>& values,
                     std::vector<std::string>* out_keys,
                     std::vector<std::string>* out_fields,
                     std::vector<std::string>* out_values) {
  redis::GenerateMultiRedisConnect(FLAGS_item_redis_server_ip, FLAGS_item_redis_server_port, 2);
  redis::ClientPool* client_pool = redis::GetClientPool(FLAGS_item_redis_server_ip, FLAGS_item_redis_server_port);  // NOLINT
  CHECK_NOTNULL(client_pool);

  redis::AutoPutback put_back(client_pool);
  redis::Client* client = put_back.TimedTake(100);
  if (client == NULL) {
    LOG(ERROR) << "cannot get redisclient! skip key: ";
    return;
  }
  std::vector<std::map<std::string, std::string>> fields_values;
  std::vector<int> rets;

  if (!client->MultiHashGetAllFields(keys, &fields_values, &rets)) {
    LOG(ERROR) << "get batch redis all failed";
  }

  for (size_t i = 0; i < rets.size(); ++i) {
    int ret_code = rets[i];
    const std::string& item_key = keys[i];
    if (ret_code != 0) {
      if (ret_code == -1) {
        LOG(ERROR) << "redis error. item_key: " << item_key << ", ret: " << ret_code << "," << client->last_error();  // NOLINT
      } else {
        // key not exist
        LOG(ERROR) << "item not exist in itemlevel redis. item_key: " << item_key;
      }
      continue;
    }
    out_keys->push_back(keys[i]);
    out_fields->push_back(fields[i]);
    out_values->push_back(values[i]);
  }
}

void write_redis() {
  redis::GenerateMultiRedisConnect(FLAGS_item_redis_server_ip, FLAGS_item_redis_server_port, 2);
  redis::ClientPool* client_pool = redis::GetClientPool(FLAGS_item_redis_server_ip, FLAGS_item_redis_server_port);  // NOLINT
  CHECK_NOTNULL(client_pool);

  std::string line;
  std::vector<std::string> tokens;
  std::vector<std::string> candidate_keys;
  std::vector<std::string> candidate_fields;
  std::vector<std::string> candidate_values;
  std::vector<std::string> keys;
  std::vector<std::string> fields;
  std::vector<std::string> values;
  std::vector<bool> rets;

  size_t batch = 100;
  int life = 3600*24*30;

  int succ = 0;
  int num = 0;

  std::ofstream fout(FLAGS_succ_file);
  while (std::getline(std::cin, line)) {
    if (candidate_keys.size() >= batch) {
      redis::AutoPutback put_back(client_pool);
      redis::Client* client = put_back.TimedTake(100);
      if (client == NULL) {
        LOG(ERROR) << "cannot get redisclient! skip key: ";
        continue;
      }

      keys.clear();
      fields.clear();
      values.clear();
      rm_unexist_keys(candidate_keys, candidate_fields, candidate_values, &keys, &fields, &values);

      num += candidate_keys.size();

      rets.clear();
      std::string failed_str;
      for (size_t i = 0; i < keys.size(); ++i) {
        bool is_succ = client->HashSetEx(keys[i].c_str(), keys[i].size(),
                                         fields[i].c_str(), fields[i].size(),
                                         values[i].c_str(), values[i].size(), life);
        if (is_succ) {
          fout << keys[i] << "\t" << fields[i] << std::endl;
          ++succ;
        } else {
          failed_str += base::StringPrintf("\t%s,%s,%s",
                                           keys[i].c_str(), fields[i].c_str(), values[i].c_str());
        }
      }

      // CHECK(client->MultiHashSetEx(keys, fields, values, life, &rets));

      if (!failed_str.empty()) {
        LOG(ERROR) << "failed item: " << failed_str;
      }

      candidate_values.clear();
      candidate_keys.clear();
      candidate_fields.clear();
    }

    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    uint64 item_id = base::ParseUint64OrDie(tokens[0]);
    int level = base::ParseInt32OrDie(tokens[1]);
    CHECK_GT(level, -1);
    CHECK_GT(3, level);

    candidate_keys.push_back(base::StringPrintf("ItemLevel-%lu", item_id));
    candidate_fields.push_back(reco::item_level::kContentLevelField);
    candidate_values.push_back(tokens[1]);
  }
  LOG(INFO) << "succ ratio: " << (float)succ / num;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "test redis value");
  write_redis();
  return 0;
}
