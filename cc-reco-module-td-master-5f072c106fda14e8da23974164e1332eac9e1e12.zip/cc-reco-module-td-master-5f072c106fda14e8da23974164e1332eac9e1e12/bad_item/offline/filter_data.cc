#include <string>
#include <map>
#include <iostream>
#include <fstream>
#include <set>
#include <unordered_map>
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/common.pb.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_path.h"
#include "base/hash_function/term.h"
#include "base/encoding/url_encode.h"
#include "reco/module/bad_item/feature/comment_feature_extractor.h"
#include "third_party/jsoncpp/include/json/value.h"
#include "third_party/jsoncpp/include/json/reader.h"
#include "extend/web_client/web_client.h"

DEFINE_string(hbase_ip, "10.3.5.72", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table, "", "hbase table");

DEFINE_int32(run_type, 0, "0 reducer, 1 reducer for shortcontent");

DEFINE_string(data_dir, "./data", "data dir for all dict");
DEFINE_int32(width, 300, "width to define big picture");
DEFINE_int32(height, 1500, "height to define big picture");

DEFINE_int32(filter_type, -1, "-1 means only item type, 0 means kongduan");

void filter() {
  reco::HBaseGetItem get_item_service(FLAGS_hbase_ip, FLAGS_hbase_port, FLAGS_hbase_table, 0);
  reco::RecoItem reco_item;

  std::string line;
  std::vector<std::string> tokens;

  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 2) continue;

    uint64 item_id = base::ParseUint64OrDie(tokens[0]);

    if (!get_item_service.GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "faile to get item: " << tokens[0];
      continue;
    }

    if (reco_item.identity().type() == reco::kPureVideo ||
        reco_item.identity().type() == reco::kGossip ||
        reco_item.identity().type() == reco::kSpecial ||
        reco_item.identity().type() == reco::kPicture ||
        reco_item.identity().type() == reco::kPictureNews ||
        reco_item.identity().producer() == "uc_br_op" ||
        !reco_item.raw_item().is_valid()) {
      continue;
    }
    std::cout << line << std::endl;
  }
}

class ShortContentRemit {
 private:
  reco::bad_item::CommentFeatureExtractor* extractor_;

  std::unordered_map<uint64, std::string> game_keyword_;
  std::unordered_map<std::string, float> source_dict_;
  std::set<std::string> remit_keyword_;
  std::set<std::string> guonei_guoji_source_;

  extend::WebClient* web_client_;

  bool IsBigImage(const std::string& image_url);
 public:
  bool Remit(const reco::RecoItem& reco_item);
  ShortContentRemit();
  ~ShortContentRemit();
};

const char* kGameKeywordFile = "game_keyword.txt";
const char* kSourceLevelFile = "source_level.txt";

bool ShortContentRemit::IsBigImage(const std::string& image_url) {
  extend::WebClient::Request request;
  extend::WebClient::Response response;
  Json::Value json_value;

  Json::Reader json_parser;

  std::string encoded_url;
  base::FastEncodeUrlComponent(image_url.c_str(), &encoded_url);
  request.url = base::StringPrintf("http://image.zzd.sm.cn/?fun=meta&url=%s", encoded_url.c_str());

  int retry = 3;
  while (retry > 0) {
    web_client_->AddTask(&request, &response, NULL);
    web_client_->WaitForAll();
    if (!response.success) {
      LOG(ERROR) << "get response failed for " << request.url;
      --retry;
      continue;
    }
      break;
  }

  if (!json_parser.parse(response.http_body.c_str(),
                         response.http_body.c_str() + response.http_body.size(),
                         json_value, false)) {
    LOG(ERROR) << "error parse: " << response.http_body;
    return false;
  }
  const Json::Value& height = json_value["height"];
  const Json::Value& width = json_value["width"];

  if (height.isNull() || width.isNull()) {
    LOG(ERROR) << base::StringPrintf("empty width or height for image: %s", image_url.c_str());
    return false;
  }

  if (height.asInt() > FLAGS_height && width.asInt() > FLAGS_width) return true;

  return false;
}


ShortContentRemit::ShortContentRemit() {
  extractor_ = new reco::bad_item::CommentFeatureExtractor();

  // loading game keywords
  base::FilePath data_dir(FLAGS_data_dir);
  std::string line;
  std::vector<std::string> tokens;

  {
    std::ifstream fin(data_dir.Append(kGameKeywordFile).value());
    const char* kUnigramPrefix = "Unigram";
    const char* kBigramPrefix = "Bigram";
    std::string literal;
    while (std::getline(fin, line)) {
      tokens.clear();
      base::SplitString(line, "\t", &tokens);
      if (tokens.size() == 1) {
        literal = base::StringPrintf("%s:%s", kUnigramPrefix, tokens[0].c_str());
      } else if (tokens.size() == 2) {
        literal = base::StringPrintf("%s:%s:%s", kBigramPrefix, tokens[0].c_str(), tokens[1].c_str());
      }

      uint64 sign = base::CalcTermSign(literal.c_str(), literal.size());
      game_keyword_.insert(std::make_pair(sign, literal));
    }
  }

  // web client
  web_client_ = new extend::WebClient();
  web_client_->Init();

  // loading source quality file
  {
    std::ifstream fin(data_dir.Append(kSourceLevelFile).value());
    while (std::getline(fin, line)) {
      tokens.clear();
      base::SplitString(line, "\t", &tokens);
      if (tokens.size() < 2) continue;

      source_dict_.insert(std::make_pair(tokens[0], base::ParseDoubleOrDie(tokens[1])));
    }
  }

  remit_keyword_.insert("快讯");
  guonei_guoji_source_.insert("新华网");
  guonei_guoji_source_.insert("中国新闻网");
}

ShortContentRemit::~ShortContentRemit() {
  delete extractor_;
}

// for short content strategy
bool ShortContentRemit::Remit(const reco::RecoItem& reco_item) {
  if (!reco_item.has_raw_item() ||
      reco_item.source().find("奇趣百科") != std::string::npos) return true;

  if (reco_item.image_count() >= 3) return true;

  // title
  for (auto it = remit_keyword_.begin(); it != remit_keyword_.end(); ++it) {
    size_t pos = reco_item.title().find(*it);
    if (pos  != std::string::npos && (reco_item.title().size() < 6 || pos < reco_item.title().size() / 3)) {
      return true;
    }
  }

  // the first paragraph
  std::vector<std::string> paragraphs;
  base::SplitString(reco_item.content(), "\t", &paragraphs);
  for (auto it = remit_keyword_.begin(); it != remit_keyword_.end(); ++it) {
    if (paragraphs[0].find(*it) != std::string::npos ||
        (paragraphs.size() > 1 && paragraphs[1].find(*it) != std::string::npos)) {
      return true;
    }
  }

  for (int i = 0; i < reco_item.raw_item().image_size(); ++i) {
    if (IsBigImage(reco_item.raw_item().image(i).url())) {
      return true;
    }
  }

  // by category
  bool has_video = reco_item.raw_item().video_meta_setting_size() > 0?true:false;
  std::vector<std::pair<uint64, float>> features;
  if (reco_item.category(0) == "体育") {
    if (has_video) return true;
    auto it = source_dict_.find(reco_item.source());
    if (it != source_dict_.end() && it->second > 2) return true;

  } else if (reco_item.category(0) == "游戏") {
    features.clear();
    extractor_->Extract(reco_item.title(), false, &features, NULL);
    for (size_t i = 0; i < features.size(); ++i) {
      if (game_keyword_.find(features[i].first) != game_keyword_.end()) return true;
    }
    auto it = source_dict_.find(reco_item.source());
    if (it != source_dict_.end() && it->second > 2) return true;
  } else if (reco_item.category(0) == "国内" || reco_item.category(0) == "国际") {
    if (guonei_guoji_source_.find(reco_item.source()) != guonei_guoji_source_.end()) return true;
  }
  return false;
}

void filter1() {
  reco::HBaseGetItem get_item_service(FLAGS_hbase_ip, FLAGS_hbase_port, FLAGS_hbase_table, 0);
  reco::RecoItem reco_item;

  std::string line;
  std::vector<std::string> tokens;
  // load the stat file
  std::unordered_map<std::string, double> category_threshold;
  base::FilePath dir(FLAGS_data_dir);
  const char* kTextLenStat = "textLen.stat";
  std::ifstream fin(dir.Append(kTextLenStat).value());
  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 10 || tokens[1] == "num") continue;
    double cur_threshold = 0;
    size_t i = 3;
    for (; i < tokens.size(); ++i) {
      double threshold = base::ParseDoubleOrDie(tokens[i]);
      if (threshold < 1) break;
      cur_threshold = threshold;
    }
    if (i == tokens.size()) continue;
    auto it_pair = category_threshold.insert(std::make_pair(tokens[0], cur_threshold + 0.5));
    CHECK(it_pair.second);
  }

  ShortContentRemit remittor;

  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 2) continue;

    uint64 item_id = base::ParseUint64OrDie(tokens[0]);

    if (!get_item_service.GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "faile to get item: " << tokens[0];
      continue;
    }

    std::string level1 = reco_item.category(0);
    double stat = base::ParseDoubleOrDie(tokens[1]);

    auto it = category_threshold.find(level1);
    if (it == category_threshold.end()) continue;

    if (stat > it->second) continue;

    if (reco_item.identity().type() == reco::kPureVideo ||
        reco_item.identity().type() == reco::kGossip ||
        reco_item.identity().type() == reco::kSpecial ||
        reco_item.identity().type() == reco::kPicture ||
        reco_item.identity().type() == reco::kPictureNews ||
        reco_item.identity().producer() == "uc_br_op" ||
        !reco_item.raw_item().is_valid()) {
      continue;
    }

    if (remittor.Remit(reco_item)) {
      continue;
    }

    std::cout << base::StringPrintf("%lu\t%s\t%lf\n", item_id, level1.c_str(), stat);
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "gen sample from item id");
  if (FLAGS_run_type == 0) {
    filter();
  } else if (FLAGS_run_type == 1) {
    filter1();
  }
  return 0;
}
