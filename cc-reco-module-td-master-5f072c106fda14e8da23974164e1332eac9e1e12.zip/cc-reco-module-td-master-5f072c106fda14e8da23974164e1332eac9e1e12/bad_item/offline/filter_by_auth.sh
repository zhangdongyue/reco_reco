n=0
buf=""
tmp_dir=./tmp
seed_score_file=$tmp_dir/'seed_score.txt'
item_seed_file=$tmp_dir/'item_seed.txt'
if [ -e $seed_score_file  ];then
  rm $seed_score_file
fi
touch $seed_score_file
if [ -e $item_seed_file ];then
  rm $item_seed_file
fi
touch $item_seed_file

mysql -h10.182.2.62 -ptkDn19DHeVZkNA -urecodev reco -e "select t1.name,t1.authority_score,t3.word from tb_seed as t1,tb_seed_category as t2,tb_seed_category_word as t3 where t1.id=t2.seed_id && t2.category_word_id=t3.id" | sed 's/\\t/,/g' > $seed_score_file

while read line
do
 item_id=$(echo $line | sed 's/\r//g' | awk '{print $1}')

 if [ "$buf" == "" ];then
   buf=\"$item_id\"
 else
   buf=$(printf "%s,\"%s\"" $buf $item_id)
 fi

 ((n+=1))
 if [ $n -gt 100 ];then
   mysql -h10.182.2.62 -ptkDn19DHeVZkNA -urecodev reco -e 'select item_id,source,category from tb_item_info where item_id in ('$buf')' >> $item_seed_file
   buf=""
   n=0
 fi
done < $1

if [ $n -gt 0 ];then
 mysql -h10.182.2.62 -ptkDn19DHeVZkNA -urecodev reco -e 'select item_id,source,category from tb_item_info where item_id in ('$buf')' >> $item_seed_file
fi

awk -F\\t 'BEGIN{}
	ARGIND==1{
          if($1!="name"){
            n=split($3,myarray,",")
            
            if($1 in dict) {
              if(index(dict[$1], myarray[0])<1) {
                dict[$1]=dict[$1]","myarray[1]
              }
            } else {
              dict[$1]=$2"\t"myarray[1]
            }
          }
        }
	ARGIND==2{
          if($1!="item_id"){
            n=split($3,myarray, ",")
            dict2[$1]=myarray[1]"\t"$2"\t"dict[$2]
          }
	}
	ARGIND==3{
          n=split($0, myarray, "\t")
          print $0"\t"dict2[$1]
	}' \
	$seed_score_file $item_seed_file $1 > $2
