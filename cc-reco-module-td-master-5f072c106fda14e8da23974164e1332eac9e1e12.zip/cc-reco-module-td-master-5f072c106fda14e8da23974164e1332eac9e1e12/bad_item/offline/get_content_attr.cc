#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "serving_base/utility/signal.h"

#include "reco/bizc/proto/bad_item.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/item_service/hbase_get_item_attr.h"

DEFINE_string(hbase_ip, "10.181.169.20", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table_attr, "tb_item_field", "hbase table");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "get item content attr");
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());

  reco::HBaseGetItemAttr* get_item_attr_ = new reco::HBaseGetItemAttr(FLAGS_hbase_table_attr);
  std::string line;
  int count_adver = 0;
  int count_dirty = 0;
  int count_politics = 0;
  while(std::getline(std::cin, line)) {
    uint64 id;
    base::StringToUint64(line, &id);
    reco::ContentAttr content_attr;
    if (count_adver == 500 && count_politics == 500 && count_politics == 500) break;
    if (!get_item_attr_->GetItemAttr(id, 0, &content_attr)) {
      // LOG(INFO) << "error cannot get item attr:\t" << id;
      continue;
    }
    /**
    if (content_attr.has_erro_title() && content_attr.erro_title() != 0) {
      LOG(INFO) << "error title\t" << id;
    }
    */
    if (content_attr.has_advertorial() && content_attr.advertorial() != 0 && count_adver < 500) {
      ++count_adver;
      std::cout << "adver\t" << id << std::endl;
    }
    /**
    if (content_attr.has_short_content() && content_attr.short_content() != 0) {
      LOG(INFO) << "short\t" << id;
    }
    if (content_attr.has_bluffing_title() && content_attr.bluffing_title() != 0) {
      std::cout << "bluffing\t" << id << std::endl;
    }
    */
    if (content_attr.has_dirty() && content_attr.dirty() != 0 && count_dirty < 500) {
      ++count_dirty;
      std::cout << "dirty\t" << id << std::endl;
    }
    if (content_attr.has_politics() && content_attr.politics() != 0 && count_politics < 500) {
      ++count_politics;
      std::cout << "politics\t" << id << std::endl;
    }
    /**
    if (content_attr.has_dedup_paragraph() && content_attr.dedup_paragraph() != 0) {
      LOG(INFO) << "dedup\t" << id;
    }
    if (content_attr.has_negative() && content_attr.negative() != 0) {
      LOG(INFO) << "negative\t" << id << "\t" << content_attr.negative();
    }
    */
  }
}
