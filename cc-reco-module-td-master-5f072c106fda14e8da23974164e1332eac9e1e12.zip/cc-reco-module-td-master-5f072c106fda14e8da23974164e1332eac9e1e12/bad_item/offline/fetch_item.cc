#include <string>
#include <map>
#include <iostream>
#include <fstream>
#include <unordered_map>
#include "reco/bizc/item_service/hbase_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/common.pb.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/hash_function/term.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"

DEFINE_string(hbase_ip, "10.3.5.72", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table, "", "hbase table");
DEFINE_string(result_file, "result.txt", "result file");

DEFINE_int32(item_id_pos, 0, "the item id pos");
DEFINE_int32(thread_num, 8, "thread num");

inline void replace_newline(std::string* content) {
  for (size_t i = 0; i < content->size(); ++i) {
    if ((*content)[i] == '\n') (*content)[i] = '\t';
  }
}

void FetchWorker(thread::BlockingQueue<uint64>* item_id_queue,
                 thread::BlockingQueue<std::string>* result_queue,
                 thread::BlockingVar<int>* finish_num) {
  reco::HBaseGetItem get_item_service(FLAGS_hbase_ip, FLAGS_hbase_port, FLAGS_hbase_table, 0);
  reco::RecoItem reco_item;

  uint64 item_id = 0;

  while (!(item_id_queue->Closed() && item_id_queue->Empty())) {
    int status = item_id_queue->TimedTake(10, &item_id);
    if (status == -1) break;

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    CHECK_EQ(status, 1) << "fuck status " << status;

    if (!get_item_service.GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "faile to get item: " << item_id;
      continue;
    }
    replace_newline(reco_item.mutable_content());

    result_queue->Put(base::StringPrintf("%lu\t%s\t%s\t%s", item_id, reco_item.title().c_str(),
                                         reco_item.category(0).c_str(), reco_item.content().c_str()));
  }

  int n = finish_num->Take() + 1;
  if (n == FLAGS_thread_num) {
    result_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

void SaveResult(thread::BlockingQueue<std::string>* result_queue) {
  std::string result;
  std::ofstream fout(FLAGS_result_file);
  while (!(result_queue->Closed() && result_queue->Empty())) {
    int status = result_queue->TimedTake(10, &result);
    if (status == -1) break;

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    fout << result << std::endl;
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "gen sample from item id");

  thread::ThreadPool pool(FLAGS_thread_num + 1);
  thread::BlockingQueue<std::string> result_queue;
  thread::BlockingQueue<uint64> item_id_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(FetchWorker, &item_id_queue, &result_queue, &finish_num));
  }
  pool.AddTask(::NewCallback(SaveResult, &result_queue));

  std::string line;
  std::vector<std::string> tokens;

  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if ((int)tokens.size() <= FLAGS_item_id_pos) {
      LOG(ERROR) << "erro input: " << line;
      continue;
    }

    uint64 item_id = base::ParseUint64OrDie(tokens[FLAGS_item_id_pos]);

    item_id_queue.Put(item_id);
  }
  item_id_queue.Close();

  pool.JoinAll();
  return 0;
}
