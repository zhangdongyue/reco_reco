#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "serving_base/utility/signal.h"

#include "reco/bizc/proto/sim_item.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/item_service/hbase_pool_get_sim.h"

DEFINE_string(hbase_table_sim, "tb_sim_item", "hbase sim table");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "get sim item");
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());

  reco::HBasePoolGetSim* get_sim_item_ = new reco::HBasePoolGetSim(FLAGS_hbase_table_sim, 0);
  std::string line;
  int no_sim = 0;
  int total_num = 0;
  std::vector<uint64> sims;
  while(std::getline(std::cin, line)) {
    uint64 id;
    total_num++;
    base::StringToUint64(line, &id);
    get_sim_item_->GetSimItem(id, &sims);
    if (sims.empty()) ++no_sim;
  }
  LOG(INFO) << "total items:\t" << total_num << "\t" << "nosim:\t" << no_sim;
}
