#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "storage/message_queue/api/message_client_generator.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc/rpc.h"
#include "net/counter/export.h"
#include "base/container/lru_cache.h"

#include "reco/bizc/proto/bad_item.pb.h"
#include "reco/module/bad_item/daemon/dao.h"
#include "reco/module/bad_item/strategy/rubbish_detector.h"

DEFINE_int32(thread_num, 2, "number of thread for save sim pair to db");

DEFINE_string(item_content_file, "", "4 flds, item_id,title,level1,content");
DEFINE_string(result_file, "result.txt", "result file");

DEFINE_string(bad_item_server_ip, "127.0.0.1", "leaf server ip, seperated by comma");
DEFINE_int32(bad_item_server_port, 9090, "sim item server port");

void GenerateBadItem(thread::BlockingQueue<reco::bad_item::BadItemRequest*>* bad_item_request_queue,
                     thread::BlockingQueue<std::pair<reco::bad_item::BadItemRequest*, std::vector<std::pair<double, int> >* > >* bad_item_result_queue,
                     thread::BlockingVar<int>* finish_num) {
  net::rpc::RpcClientChannel channel(FLAGS_bad_item_server_ip.c_str(), FLAGS_bad_item_server_port);
  CHECK(channel.Connect());
  reco::bad_item::BadItemService::Stub stub(&channel);

  reco::bad_item::BadItemRequest* request = NULL;
  reco::bad_item::BadItemResponse response;
  while (!(bad_item_request_queue->Closed() && bad_item_request_queue->Empty())) {
    int status = bad_item_request_queue->TimedTake(100, &request);
    if (status == 0) {
      base::SleepForMilliseconds(1000);
      delete request;
      continue;
    }
    if (status < 0) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status: " << status;

    if (request->text().size() < 3 && !request->has_reco_item()) {
      LOG(ERROR) << "empty request ";
      delete request;
      continue;
    }

    int retry_times = 0;
    while (retry_times < 3) {
      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(1000);
      stub.DetectBadItem(&rpc, request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()) {
        LOG_EVERY_N(ERROR, 100) << "get bad items failed: ";
        if (!channel.IsConnected() && !channel.Connect(200)) {
          LOG(ERROR) << "cannot conenct to bad item server";
          base::SleepForSeconds(1);
        }
        continue;
      }

      if (!response.success()) {
        ++retry_times;
        base::SleepForMilliseconds(100);
        continue;
      }
      break;
    }

    if (response.score_size() == 0) {
      delete request;
      continue;
    }

    std::vector<std::pair<double, int> >* result = new std::vector<std::pair<double, int> >();
    result->reserve(response.score_size());
    CHECK_EQ(response.score_size(), response.bad_item_type_size());
    for (int i = 0; i < response.score_size(); ++i) {
      result->push_back(std::make_pair(response.score(i), response.bad_item_type(i)));
    }
    bad_item_result_queue->Put(std::make_pair(request, result));
  }

  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    bad_item_result_queue->Close();
  }
  finish_num->TryPut(n);
}

void SaveResult(thread::BlockingQueue<std::pair<reco::bad_item::BadItemRequest*, std::vector<std::pair<double, int>>* >>* result_queue) {  // NOLINT
  std::ofstream fout(FLAGS_result_file);
  std::pair<reco::bad_item::BadItemRequest*, std::vector<std::pair<double, int >>* > result;

  while (!(result_queue->Empty() && result_queue->Closed())) {
    int status = result_queue->TimedTake(100, &result);
    scoped_ptr<reco::bad_item::BadItemRequest> request(result.first);
    scoped_ptr<std::vector<std::pair<double, int>> > rubbish_result(result.second);

    if (status == -1) {
      LOG(ERROR) << "get bad item result failed! status: " << status;
      break;
    }

    if (status == 0) {
      LOG_EVERY_N(ERROR, 100) << "bad item result queue empty";
      base::SleepForMilliseconds(2000);
      continue;
    }

    fout << base::StringPrintf("%s\t%s\n", request->text().c_str(), reco::bad_item::kAllRubbish[rubbish_result->front().second].c_str());
  }
  fout.close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "bad item client");
  std::ifstream fin(FLAGS_item_content_file);
  std::string line;

  thread::BlockingQueue<reco::bad_item::BadItemRequest*> bad_item_request_queue;
  thread::BlockingQueue<std::pair<reco::bad_item::BadItemRequest*, std::vector<std::pair<double, int>>* >> result_queue;  // NOLINT
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));

  thread::ThreadPool pool(FLAGS_thread_num + 1);
  pool.AddTask(::NewCallback(SaveResult, &result_queue));

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(GenerateBadItem, &bad_item_request_queue, &result_queue, &finish_num));
  }

  int bitmap = 1 << reco::bad_item::kFakeTitle | 1 << reco::bad_item::kAdvertorial |
      1 << reco::bad_item::kShortContent | 1 << reco::bad_item::kDedupParagraph | 1 << reco::bad_item::kDirty;

  while (std::getline(fin, line)) {
    if (line.size() < 2) {
      LOG(ERROR) << "erro line: " << line;
      continue;
    }
    reco::bad_item::BadItemRequest* request = new reco::bad_item::BadItemRequest;
    request->set_text(line);
    request->set_bitmap(bitmap);
    bad_item_request_queue.Put(request);
  }
  bad_item_request_queue.Close();
  pool.JoinAll();
}
