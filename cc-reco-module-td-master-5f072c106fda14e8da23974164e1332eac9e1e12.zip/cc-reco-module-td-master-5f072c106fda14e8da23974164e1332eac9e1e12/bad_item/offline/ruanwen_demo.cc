#include <string>
#include <vector>
#include <fstream>
#include "reco/module/bad_item/strategy/ruanwen_detector.h"
#include "reco/module/bad_item/strategy/dedup_paragraph.h"
#include "reco/module/bad_item/strategy/fake_title_detector.h"
#include "reco/module/bad_item/strategy/item_info.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/closure.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "reco/bizc/reco_ner/reco_ner.h"

DEFINE_int32(thread_num, 8, "thread_num");
DEFINE_int32(run_type, 0, "0 means use title, content, category in input, 1 means get item from habse");
DEFINE_int32(detect_type, 0, "0 means all, 1 means only ruanwen, 2 means only dedup, 3 mean only fake title");
DEFINE_string(result_file, "result.txt", "result file");
DEFINE_string(data_dir, "./data", "data dir");

DEFINE_string(hbase_ip, "10.3.5.72", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table, "", "hbase table");

class ItemInfoGenerator {
 public:
  explicit ItemInfoGenerator(bool with_hbase);
  ~ItemInfoGenerator();

  void FillItemInfo(int run_type, const std::vector<std::string>& flds, reco::bad_item::ItemInfo* item_info);

 private:
  nlp::segment::Segmenter* segmenter_;
  nlp::postag::PosTagger* pos_tagger_;
  nlp::ner::Ner* ner_;
  reco::ner::RecoNer* reco_ner_;

  reco::HBaseGetItem* get_item_service_;
};

ItemInfoGenerator::ItemInfoGenerator(bool with_hbase) {
  segmenter_ = new nlp::segment::Segmenter;
  pos_tagger_ = new nlp::postag::PosTagger;
  ner_ = new nlp::ner::Ner;
  reco_ner_ = new reco::ner::RecoNer;

  get_item_service_ = NULL;
  if (with_hbase) {
    get_item_service_ = new reco::HBaseGetItem(FLAGS_hbase_ip, FLAGS_hbase_port, FLAGS_hbase_table, 0);
  }
}

ItemInfoGenerator::~ItemInfoGenerator() {
  delete get_item_service_;
  delete reco_ner_;
  delete ner_;
  delete pos_tagger_;
  delete segmenter_;
}

void ItemInfoGenerator::FillItemInfo(int run_type, const std::vector<std::string>& flds,
                                     reco::bad_item::ItemInfo* item_info) {
  if (run_type == 0) {
    CHECK_GT(flds.size(), 3u);
    nlp::util::NormalizeLineCopy(flds[3], &(item_info->norm_content));
    nlp::util::NormalizeLineCopy(flds[1], &(item_info->norm_title));
    item_info->level1 = flds[2];
  } else if (run_type == 1) {
    uint64 item_id = base::ParseUint64OrDie(flds.front());
    reco::RecoItem reco_item;
    CHECK_NOTNULL(get_item_service_);
    if (!get_item_service_->GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "failed to get item: " << item_id;
      return;
    }

    nlp::util::NormalizeLineCopy(reco_item.content(), &(item_info->norm_content));
    nlp::util::NormalizeLineCopy(reco_item.title(), &(item_info->norm_title));
    item_info->level1 = reco_item.category(0);
  } else {
    LOG(ERROR) << "fucking run type: " << run_type;
  }

  // some basic task
  item_info->content_terms.renew();
  CHECK(segmenter_->SegmentT(item_info->norm_content, &item_info->content_terms));
  CHECK(pos_tagger_->PosTagT(item_info->norm_content, &item_info->content_terms));
  CHECK(ner_->DetectEntityT(item_info->norm_content, &item_info->content_terms));
  nlp::util::ConstructMixTerms(item_info->norm_content, false, &item_info->content_terms);

  item_info->content_mix_words.clear();
  CHECK(reco_ner_->DetectEntity(item_info->norm_content, item_info->content_terms,
                                "", &item_info->content_mix_words, NULL));

  item_info->title_terms.renew();
  CHECK(segmenter_->SegmentT(item_info->norm_title, &item_info->title_terms));
  CHECK(pos_tagger_->PosTagT(item_info->norm_title, &item_info->title_terms));
  CHECK(ner_->DetectEntityT(item_info->norm_title, &item_info->title_terms));
  nlp::util::ConstructMixTerms(item_info->norm_title, false, &item_info->title_terms);

  item_info->content_mix_words.clear();
  CHECK(reco_ner_->DetectEntity(item_info->norm_title, item_info->title_terms,
                                "", &item_info->title_mix_words, NULL));
}

void PredictWorker(thread::BlockingQueue<std::string>* input_queue,
                   thread::BlockingQueue<std::string>* result_queue,
                   thread::BlockingVar<int>* finish_num) {
  reco::bad_item::AdvertorialDetector* detector = new reco::bad_item::AdvertorialDetector();
  reco::bad_item::DedupParagraph* dedup_paragraph = new reco::bad_item::DedupParagraph();
  reco::bad_item::FakeTitleDetector* fake_title = new reco::bad_item::FakeTitleDetector();

  bool with_hbase = false;
  if (FLAGS_run_type == 1) with_hbase = true;
  ItemInfoGenerator item_generator(with_hbase);

  std::string line;
  std::vector<std::string> flds;
  reco::bad_item::ItemInfo item_info;

  while (!(input_queue->Closed() && input_queue->Empty())) {
    int status = input_queue->TimedTake(10, &line);
    if (status == 0) {
      base::SleepForMilliseconds(100);
      continue;
    }
    if (status == -1) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status " << status;

    flds.clear();
    base::SplitString(line, "\t", &flds);
    uint64 item_id = base::ParseUint64OrDie(flds.front());
    item_generator.FillItemInfo(FLAGS_run_type, flds, &item_info);

    if (FLAGS_detect_type == 0 || FLAGS_detect_type == 1) {
      double score = detector->Predict(item_info);
      if (score > 0.1) {
        result_queue->Put(base::StringPrintf("%lu\t软文\t%lf", item_id, score));
      }
    }

    if (FLAGS_detect_type == 0 || FLAGS_detect_type == 2) {
      double dedup_score = dedup_paragraph->Detect(flds[3], " ");
      if (dedup_score > 0.1) {
        result_queue->Put(base::StringPrintf("%lu\t堆砌\t%lf", item_id, dedup_score));
      }
    }

    if (FLAGS_detect_type == 0 || FLAGS_detect_type == 3) {
      double match_score = fake_title->CalcTitleContentMatch(item_info);
      if (match_score < 0.1) {
        result_queue->Put(base::StringPrintf("%lu\t标题党\t%lf", item_id, match_score));
      }
    }
  }

  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    result_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

void SaveWorker(thread::BlockingQueue<std::string>* result_queue) {
  std::string line;
  std::ofstream fout(FLAGS_result_file);
  while (!(result_queue->Closed() && result_queue->Empty())) {
    int status = result_queue->TimedTake(10, &line);
    if (status == 0) {
      base::SleepForMilliseconds(100);
      continue;
    }
    if (status == -1) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status " << status;

    fout << line << std::endl;
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "ruanwen demo");
  CHECK(reco::bad_item::AdvertorialDetector::ReloadDict(base::FilePath(FLAGS_data_dir), true));
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  thread::BlockingQueue<std::string> input_queue;
  thread::BlockingQueue<std::string> result_queue;
  thread::ThreadPool pool(FLAGS_thread_num + 1);
  pool.AddTask(::NewCallback(SaveWorker, &result_queue));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(PredictWorker, &input_queue, &result_queue, &finish_num));
  }

  std::string line;
  while (std::getline(std::cin, line)) {
    input_queue.Put(line);
  }
  input_queue.Close();

  pool.JoinAll();

  return 0;
}
