#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/encoding/url_encode.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/thread/rw_mutex.h"
#include "base/hash_function/term.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "net/rpc/rpc.h"
#include "net/counter/export.h"
#include "nlp/common/nlp_util.h"
#include "reco/ml/feature/item/low_quality_hit.h"
#include "reco/bizc/proto/bad_item.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/module/bad_item/daemon/dao.h"
#include "reco/module/bad_item/strategy/rubbish_detector.h"
#include "reco/module/video_quality/strategy/video_rubbish_detector.h"
#include "reco/module/cdoc_convertor/global_data/global_data.h"
#include "reco/ml/feature/global_data/global_data.h"
#include "reco/ml/feature/global_data/dict_loader.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "third_party/jsoncpp/include/json/value.h"
#include "third_party/jsoncpp/include/json/reader.h"
#include "third_party/jsoncpp/include/json/writer.h"
#include "extend/web_client/web_client.h"

DEFINE_int32(thread_num, 4, "number of thread");

DEFINE_string(input_file, "test.txt", "input file path");
DEFINE_string(result_file, "dirty_result.txt", "result file");

DEFINE_string(http_ip_port, "100.67.80.141:80", "");

DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");

// rubbish detactor
const char* kAdverRuleFile = "advertorial_rule.txt";
const char* kAdverKeywordFile = "advertorial_keywords.txt";
const char* kAdverImpurityKeywordFile = "advertorial_impurity_keywords.txt";
const char* kAdverModelFile = "advertorial_model.txt";
const char* kRubbishSourceFile = "rubbish_sources.txt";
const char* kBluffingRuleFile = "bluffing_rule.txt";
const char* kBluffingKeywordFile = "bluffing_keywords.txt";
const char* kDirtyRuleFile = "dirty_rule.txt";
const char* kDirtyKeywordFile = "dirty_keywords.txt";
const char* kDirtyModelFile = "dirty_model.txt";
const char* kDirtySubRuleFile = "dirty_sub_rule.txt";
const char* kRubbishTitleFile = "rubbish_title.txt";
const char* kNegativeRuleFile = "negative_rule.txt";
const char* kNegativeKeywordFile = "negative_keywords.txt";
const char* kPoliticsRuleFile = "politics_rule.txt";
const char* kPoliticsKeywordFile = "politics_keywords.txt";
const char* kTextLenStatFile = "text_len.txt";
const char* kStopwordFile = "stopword.txt";
const char* kMediaQualityFile = "media_quality.txt";
const char* kLowQualityRemitSourceFile = "low_quality_remit_source.txt";
const char* kLowQualityThresholdFile = "low_quality_thresholds.txt";
const char* kLowQualityImageHashFile = "bad_image_hash.txt";
const char* kVideoDirtyRuleFile = "video_quality_dirty_rule.txt";
const char* kVideoDirtyKeywordFile = "video_quality_dirty_keywords.txt";

reco::ContentAttr::ContentAttrLevel attr_values[] = { reco::ContentAttr::kSureNo,
  reco::ContentAttr::kSuspect, reco::ContentAttr::kSureYes };
reco::ContentAttr::SubDirty sub_dirtys[] = { reco::ContentAttr::kNone,
  reco::ContentAttr::kEthic, reco::ContentAttr::kSocial, reco::ContentAttr::kStar,
  reco::ContentAttr::kGallary, reco::ContentAttr::kHistory, reco::ContentAttr::kSex,
  reco::ContentAttr::kHealthy, reco::ContentAttr::kAvPlayer, reco::ContentAttr::kChasingGirls,
  reco::ContentAttr::kDisgusting, reco::ContentAttr::kComic, reco::ContentAttr::kNoval,
  reco::ContentAttr::kHumor};
reco::ContentAttr::SubAdver sub_advers[] = { reco::ContentAttr::kAdver, reco::ContentAttr::kImpurity};

std::string sub_dirtys_str[] = { "无", "伦理", "社会新闻", "明星低俗",
  "图集低俗", "低俗历史故事", "啪啪啪低俗", "两性健康低俗", "AV影星",
  "泡妞技巧", "恶心反胃", "低俗漫画", "情感口述", "低俗段子" };

std::unordered_set<std::string> remit_cates;

bool ClacPronScore(uint64 item_id, const std::string& poster_url) {
  std::string encoded_url = base::EncodeUrlComponent(poster_url.c_str());
  Json::Value json_url;
  json_url["0"] = Json::Value(base::StringPrintf("web@%s", encoded_url.c_str()));
  Json::Value request;
  request["session_id"] = Json::Value(base::StringPrintf("%lu", item_id));
  request["tasks"] = json_url;

  Json::FastWriter fastWriter;
  std::string output = fastWriter.write(request);
  std::string url = base::StringPrintf("http://%s/video_analysis?outfmt=json&bucketid=-1&src=sm_tudou&appchain=porn&model=blocking&resource_type=video_frameset&session_id=0&task=%s", // NOLINT
                                       FLAGS_http_ip_port.c_str(), output.c_str());

  int count = 0;
  std::string label_str;
  std::string score_str;
  double score = 0;
  while (count < 3) {
    label_str.clear();
    score_str.clear();
    extend::WebClient::Request web_request;
    extend::WebClient::Response response;
    Json::Value json_value;
    Json::Reader json_parser;
    extend::WebClient* web_client = new extend::WebClient();
    web_client->Init();
    web_request.url = url;
    web_client->AddTask(&web_request, &response, NULL);
    web_client->WaitForAll();
    delete web_client;
    web_client = NULL;
    if (!json_parser.parse(response.http_body.c_str(),
                           response.http_body.c_str() + response.http_body.size(),
                           json_value, false)) {
      ++count;
      base::SleepForMilliseconds(100);
      continue;
    }
    if (json_value["code"].type() != Json::intValue ||
        json_value["code"].asInt() != 0 ||
        json_value["msg"].asString() != "successful") {
      ++count;
      base::SleepForMilliseconds(100);
      continue;
    }
    label_str = json_value["VideoPornRecog"]["label"].asString();
    score_str = json_value["VideoPornRecog"]["score"].asString();
    if (score_str == "-nan") {
      ++count;
      continue;
    }
    if (!base::StringToDouble(score_str, &score)) {
      score = 0;
      base::SleepForMilliseconds(100);
      ++count;
      continue;
    }
    break;
  }
  if (count == 3) {
    LOG(ERROR) << "fail to get porn score\t" << item_id;
    return false;
  }
  if (label_str == "seqing" && score > 0.8) {
    LOG(INFO) << "item is seqing:\t" << item_id;
    return true;
  }
  if (label_str == "xinggan" && score > 0.95) {
    LOG(INFO) << "item is xinggan:\t" << item_id;
    return true;
  }
  return false;
}

void GenerateBadItem(reco::redis::RedisCli* redis_cli_,
                     thread::BlockingQueue<reco::RecoItem>* bad_item_request_queue,
                     thread::BlockingQueue<std::pair<reco::RecoItem, std::vector<int> >>* bad_item_result_queue, //NOLINT
                     thread::BlockingVar<int>* finish_num) {
  reco::bad_item::RubbishDetector* detector = new reco::bad_item::RubbishDetector(redis_cli_);
  std::vector<int> final_result;
  std::string poster_url;
  std::string url;
  reco::RecoItem request;
  while (!(bad_item_request_queue->Closed() && bad_item_request_queue->Empty())) {
    final_result.clear();
    poster_url.clear();
    url.clear();
    int status = bad_item_request_queue->TimedTake(100, &request);
    if (status == 0) {
      base::SleepForMilliseconds(1000);
      continue;
    }
    if (status < 0) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status: " << status;
    if (request.video_meta_settings_size() != 0 &&
        request.video_meta_settings(0).has_poster()) {
      poster_url = request.video_meta_settings(0).poster();
    }
    std::string cate;
    if (request.category_size() > 0) cate = request.category(0);
    bool is_porn_poster = false;
    if (request.video_meta_settings_size() > 0 &&
        request.video_meta_settings(0).has_poster_porn_label()) {
      std::vector<std::string> tokens;
      base::SplitString(request.video_meta_settings(0).poster_porn_label(), "\t", &tokens);
      if (tokens[0] != "normal") {
        is_porn_poster = true;
      }
    }
    if (!is_porn_poster && remit_cates.find(cate) == remit_cates.end()) {
      is_porn_poster = ClacPronScore(request.identity().item_id(), poster_url);
    }

    reco::ContentAttr result;
    detector->Detect(request, &result);
    int video_dirty_status = 0;
    final_result.push_back(0);
    if (result.has_video_dirty() && result.video_dirty() > 0) {
      final_result.back() = result.video_dirty();
      if (result.has_video_dirty_status()) {
        video_dirty_status = result.video_dirty_status();
      } else {
        video_dirty_status |= 0x1;
      }
    }
    if (is_porn_poster) {
      if (final_result.back() == 0) {
        final_result.back() = 1;
      }
      video_dirty_status |= 0x2;
    }
    final_result.push_back(video_dirty_status);
    final_result.push_back(result.negative());
    bad_item_result_queue->Put(std::make_pair(request, final_result));
  }

  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    bad_item_result_queue->Close();
  }
  finish_num->TryPut(n);
  delete detector;
  detector = NULL;
}

void SaveResult(thread::BlockingQueue<std::pair<reco::RecoItem, std::vector<int> >>* result_queue) {
  std::ofstream fout(FLAGS_result_file);
  std::pair<reco::RecoItem, std::vector<int> > result;

  std::string final_result;
  while (!(result_queue->Empty() && result_queue->Closed())) {
    final_result.clear();
    int status = result_queue->TimedTake(100, &result);
    reco::RecoItem request = result.first;
    std::vector<int> rubbish_result(result.second);

    if (status == -1) {
      LOG(ERROR) << "get bad item result failed! status: " << status;
      break;
    }

    if (status == 0) {
      LOG_EVERY_N(ERROR, 100) << "bad item result queue empty";
      base::SleepForMilliseconds(2000);
      continue;
    }
    std::string cate = "未分类";
    if (request.category_size() > 0) cate = request.category(0);
    bool is_dirty = false;
    if (request.has_content_attr() &&
        request.content_attr().has_dirty() &&
        request.content_attr().dirty() != 0) {
      is_dirty = true;
    }
    final_result = base::StringPrintf("%lu\t%s\t%s\t%s\t%d",
                                      request.identity().item_id(),
                                      request.title().c_str(),
                                      request.source().c_str(),
                                      cate.c_str(),
                                      is_dirty);
    CHECK_EQ((int)rubbish_result.size(), 3);
    final_result.append("\t");
    final_result.append(base::IntToString(rubbish_result[0]));
    final_result.append("\t");
    final_result.append(base::IntToString(rubbish_result[1]));
    final_result.append("\t");
    final_result.append(base::IntToString(rubbish_result[2]));
    fout << final_result << std::endl;
  }
  fout.close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "bad item client ljd");
  thread::BlockingVar<int> ret;

  remit_cates.insert("萌宠");
  remit_cates.insert("科技");
  remit_cates.insert("萌娃");
  remit_cates.insert("育儿");
  remit_cates.insert("游戏");
  remit_cates.insert("美食");

  reco::redis::RedisCli* redis_cli_ = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);
  CHECK(redis_cli_->GetPool()->IsRun());

  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedMapStrInt,
                            kDirtySubRuleFile, reco::dm::LoadLowQualitySubRuleFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kRubbishTitleFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kPoliticsRuleFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kPoliticsKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kNegativeRuleFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kNegativeKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrInt, kRubbishSourceFile);

  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedMapStrDouble,
                            kTextLenStatFile, reco::dm::LoadTextLenStatFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrInt, kMediaQualityFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kLowQualityRemitSourceFile);

  DM_REGISTER_CUSTOMER_DICT(reco::dm::DictManager::UnorderedMapStrDouble,
                            kLowQualityThresholdFile, reco::dm::LoadLowQualityThresholdFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kVideoDirtyRuleFile,
                            reco::dm::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kVideoDirtyKeywordFile,
                            reco::dm::LoadLowQualityDawgDict);

  // ml 模块加载的文件
  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverRuleFile,
                            reco::ml::LoadAdverRuleFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverImpurityKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_DICT(UnorderedMapUint64Double, kAdverModelFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kDirtyRuleFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kDirtyKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_DICT(UnorderedMapUint64Double, kDirtyModelFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kBluffingRuleFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kBluffingKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kStopwordFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrInt, kLowQualityImageHashFile);

  reco::dm::DictManagerSingleton::instance().LoadAllDicts();

  std::ifstream fin(FLAGS_input_file);
  std::string line;

  std::set<uint64> cache;
  reco::BaseGetItem* get_item_service_ = new reco::ItemKeeperGetItem(FLAGS_item_keeper_server_ip, FLAGS_item_keeper_server_port); // NOLINT

  thread::BlockingQueue<reco::RecoItem> bad_item_request_queue;
  thread::BlockingQueue<std::pair<reco::RecoItem, std::vector<int> >> result_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));

  thread::ThreadPool pool(FLAGS_thread_num + 1);
  pool.AddTask(::NewCallback(SaveResult, &result_queue));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(GenerateBadItem, redis_cli_, &bad_item_request_queue, &result_queue, &finish_num)); // NOLINT
  }

  while (std::getline(fin, line)) {
    if (line.size() < 2) {
      LOG(ERROR) << "erro line: " << line;
      continue;
    }
    uint64 item_id = base::ParseUint64OrDie(line);
    reco::RecoItem reco_item;
    if (!get_item_service_->GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "failed to get item: " << item_id;
      continue;
    }
    if (cache.find(item_id) == cache.end()) {
      cache.insert(item_id);
      if (!reco_item.identity().has_manual() || !reco_item.identity().manual()) {
        bad_item_request_queue.Put(reco_item);
      }
    }
  }
  bad_item_request_queue.Close();
  pool.JoinAll();
  delete get_item_service_;
  get_item_service_ = NULL;
}
