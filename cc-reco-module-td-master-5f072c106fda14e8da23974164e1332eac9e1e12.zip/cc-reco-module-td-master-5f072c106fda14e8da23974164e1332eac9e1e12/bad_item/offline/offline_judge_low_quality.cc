#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "storage/message_queue/api/message_client_generator.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"

#include "net/rpc/rpc.h"
#include "net/counter/export.h"
#include "base/container/lru_cache.h"
#include "reco/base/kafka_c/api/topic_producer.h"

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/bad_item.pb.h"
#include "reco/bizc/item_service/hbase_pool_get_item.h"

DEFINE_string(message_queue_servers, "10.3.5.73:1999", "message queue servers");
DEFINE_int32(message_queue_rpc_timeout, 300, "message_queue server's rpc timeout");
DEFINE_string(reco_item_queue, "reco::zhengying::reco_item", "message queue name of ");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "offline judge low quality");

  reco::bad_item::BadItemGenerator::Start();
  std::cout << "offline judge start" << std::endl;

  net::counter::HttpCounterExport();

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();
  reco::bad_item::BadItemGenerator::Stop();
  LOG(INFO) << "offline judge stop";
  return 0;
}
