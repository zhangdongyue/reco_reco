model_file=$1
test_data=$2
orig_test_data=$3
result_data=$4
predict_bin=/home/xielang/wly/bin/predict

tmp_dir=./tmp

if [ -e $tmp_dir ];then
  echo "./tmp exist, we would use it!"
else
  mkdir $tmp_dir
fi

predict_result=$tmp_dir/predict.txt

$predict_bin -f 1 -m $model_file -d $test_data -r $predict_result

awk -F\\t 'BEGIN{idx1=0;idx2=0}
  ARGIND==1{
    dict[idx1++] = $0
    }
  ARGIND==2{
    print $1"\t"dict[idx2++]
    }' \
  $orig_test_data $predict_result > $result_data
