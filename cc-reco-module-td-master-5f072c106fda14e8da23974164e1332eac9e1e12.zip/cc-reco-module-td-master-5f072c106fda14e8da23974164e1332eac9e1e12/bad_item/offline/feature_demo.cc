#include <string>
#include <vector>

#include "reco/module/bad_item/feature/feature_extractor.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"

DEFINE_string(hbase_ip, "10.3.5.72", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table, "", "hbase table");
DEFINE_int32(thread_num, 16, "thread num for extracting");

void GenerateOutStr(uint64 item_id, const reco::bad_item::ItemFeature& item_fea, std::string* result) {
  result->clear();
  //  title feature
  // *result += "\t";
  // for (size_t i = 0; i < item_fea.title_words.size(); ++i) {
  //   *result += item_fea.title_words[i];
  //   *result += "|";
  // }

  result->append(base::StringPrintf("%lu\t%lu,%d\t%f,%f,%f\t%f,%f,%f\t%f,%f,%f\t%f,%f,%f\t%f,%f", item_id,
                                    item_fea.paragraph_words.size(), item_fea.content_len,
                                    item_fea.avg_paragraph_topic_sim,
                                    item_fea.max_paragraph_topic_sim,
                                    item_fea.min_paragraph_topic_sim,
                                    item_fea.avg_paragraph_wordvec_sim,
                                    item_fea.max_paragraph_wordvec_sim,
                                    item_fea.min_paragraph_wordvec_sim,
                                    item_fea.avg_title_paragraph_topic_sim,
                                    item_fea.max_title_paragraph_topic_sim,
                                    item_fea.min_title_paragraph_topic_sim,
                                    item_fea.avg_title_paragraph_wordvec_sim,
                                    item_fea.max_title_paragraph_wordvec_sim,
                                    item_fea.min_title_paragraph_wordvec_sim,
                                    item_fea.title_content_topic_sim,
                                    item_fea.title_content_wordvec_sim));
}

void Extract(thread::BlockingQueue<uint64>* item_id_queue, thread::BlockingQueue<std::string>* result,
             thread::BlockingVar<int>* finish_num) {
  reco::bad_item::FeatureExtractor feature_extractor;
  std::string result_str;
  reco::RecoItem reco_item;

  reco::HBaseGetItem get_item_service(FLAGS_hbase_ip, FLAGS_hbase_port, FLAGS_hbase_table, 0);

  uint64 item_id;
  reco::bad_item::ItemFeature item_fea;
  while (!(item_id_queue->Closed() && item_id_queue->Empty())) {
    int status = item_id_queue->TimedTake(10, &item_id);
    if (status == -1) break;
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    CHECK_EQ(status, 1) << "fucking status " << status;

    if (!get_item_service.GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "faile to get item: " << item_id;
      continue;
    }
    if (!reco_item.has_raw_item()) {
      LOG(ERROR) << "item without raw item: " << item_id;
      continue;
    }

    feature_extractor.Extract(reco_item, &item_fea);
    // output
    GenerateOutStr(item_id, item_fea, &result_str);
    result->Put(result_str);
  }
  int n = finish_num->Take() + 1;

  if (n >= FLAGS_thread_num) result->Close();

  CHECK(finish_num->TryPut(n));
}

void save(thread::BlockingQueue<std::string>* result_queue) {
  std::string result;
  while (!(result_queue->Closed() && result_queue->Empty())) {
    int status = result_queue->TimedTake(10, &result);
    if (status == -1) break;
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    CHECK_EQ(status, 1) << "fucking status " << status;
    std::cout << result << std::endl;
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "feature demo");
  thread::BlockingQueue<std::string> result_queue;
  thread::BlockingQueue<uint64> item_id_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  thread::ThreadPool pool(FLAGS_thread_num + 1);
  pool.AddTask(::NewCallback(save, &result_queue));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(Extract, &item_id_queue, &result_queue, &finish_num));
  }

  std::string line;
  uint64 item_id = 0;
  std::vector<std::string> tokens;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);

    if (!base::StringToUint64(tokens.front(), &item_id)) {
      LOG(ERROR) << "error item id " << line;
      continue;
    }
    item_id_queue.Put(item_id);
  }
  item_id_queue.Close();
  pool.JoinAll();
  return 0;
}
