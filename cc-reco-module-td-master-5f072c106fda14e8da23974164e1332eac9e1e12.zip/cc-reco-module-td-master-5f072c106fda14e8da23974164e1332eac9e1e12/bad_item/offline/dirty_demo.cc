#include <string>
#include <vector>
#include <fstream>

#include "reco/module/bad_item/strategy/item_info.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/hbase_get_item.h"
#include "nlp/segment/segmenter.h"
#include "nlp/common/nlp_util.h"
#include "nlp/common/term_container.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"

DEFINE_string(hbase_ip, "10.3.5.72", "hbase ip");
DEFINE_int32(hbase_port, 9090, "hbase thrift port");
DEFINE_string(hbase_table, "", "hbase table");
DEFINE_int32(thread_num, 32, "thread num for extracting");

DEFINE_string(word_file, "word.txt", "keyword file");

// thread unsafe 
class SimpleMatch {
 public:
  SimpleMatch() {
    segmenter_ = new nlp::segment::Segmenter();
  }
  ~SimpleMatch() {
    delete segmenter_;
  }

  std::pair<int, int> CalcMatch(const reco::RecoItem& reco_item);
  int CalcMatch(const std::string& content);

  static bool Init(const base::FilePath& path);
 private:
  static dawgdic::Dictionary dict_;
  nlp::segment::Segmenter* segmenter_;
  nlp::term::TermContainer term_container_;
};
dawgdic::Dictionary SimpleMatch::dict_;

bool SimpleMatch::Init(const base::FilePath& path) {
  std::string line;
  std::vector<std::string> tokens;
  // load ngram dict
  std::map<std::string, int> cache;
  {
    int idx = 0;
    std::ifstream fin(path.value());
    std::vector<std::string> words;
    std::string ngram;
    while (std::getline(fin, line)) {
      words.clear();
      base::SplitString(line, "\t", &words);

      for (int i = 0; i < (int)words.size(); ++i) {
        nlp::util::NormalizeLineInPlaceS(&words[i]);
      }

      if (words.size() == 1) {
        if (words.front().size() < 1) {
          LOG(ERROR) << "empty word in line: " << line;
        }

        auto it_pair = cache.insert(std::make_pair(words.front(), 0));
        if (!it_pair.second) {
          LOG(WARNING) << base::StringPrintf("dup ngram: %s, ngrma职能保留，类型覆盖", words.front().c_str());
          it_pair.first->second &= 0x3;
        }

        it_pair.first->second |= 2;
        continue;
      } else {
        for (int i = 0; i < (int)words.size(); ++i) {
          if (words[i].size() < 1) {
            LOG(ERROR) << "empty word in line: " << line;
          }
          auto it_pair = cache.insert(std::make_pair(words[i], 0));
          if ((int)words.size() == i + 1) {
            it_pair.first->second |= 2;
          } else {
            it_pair.first->second |= 1;
          }
        }
      }
      // add whole ngram
      ngram.clear();
      base::FastJoinStrings(words, "", &ngram);
      auto it_pair = cache.insert(std::make_pair(ngram, 2));
      if (!it_pair.second) {
        LOG(ERROR) << base::StringPrintf("ngram: %s has been occured before", ngram.c_str());
        continue;
      }

      it_pair.first->second |= (idx << 4);
      ++idx;
    }
  }
  // build dawgdict
  dawgdic::DawgBuilder builder;
  for (auto it = cache.begin(); it != cache.end(); ++it) {
    CHECK_GT(4, it->second) << it->first;
    CHECK(builder.Insert(it->first.c_str(), it->second));
  }
  dawgdic::Dawg dawg;
  CHECK(builder.Finish(&dawg));
  dawgdic::DictionaryBuilder::Build(dawg, &dict_);
  LOG(INFO) << "rule dict_size: " << dict_.file_size();
  
  return true;
}

inline bool has_terminal(int v) { return (v & 2) > 0; }
inline bool has_nonterminal(int v) { return (v & 1) > 0; }

int SimpleMatch::CalcMatch(const std::string& norm_content) {
  term_container_.renew();
  CHECK(segmenter_->SegmentT(norm_content, &term_container_));

  std::vector<base::Slice> words;
  std::vector<std::pair<int, int>> matches;
  std::vector<int> values;
  words.reserve(term_container_.basic_term_num());
  for (int i = 0; i < term_container_.basic_term_num(); ++i) {
    words.push_back(term_container_.basic_term_slice(norm_content, i));
  }

  int match_num = nlp::util::ForwardMaxMatch(dict_, words, &matches, &values);
  
  if (match_num == 0) return 0;

  int score = 0;
  
  for (int i = 0 ;i < (int)matches.size(); ++i) {
    if (has_terminal(values[i])) score += 1;

    dawgdic::BaseType node_pos = 0;
    for (int s = matches[i].first; s < matches[i].second; ++s) {
      LOG(INFO) << "follow " << words[s].as_string();
      CHECK_GT((int)words.size(), s);
      CHECK(dict_.Follow(words[s].data(), words[s].size(), &node_pos));
    }

    if (!dict_.has_value(node_pos)) continue;
    int result = dict_.value(node_pos);
    CHECK_EQ(result, values[i]);

    for (int j = i + 1; j < i + 3; ++j) {
      if (matches[j].first - matches[i].second > 2) break;
      
      dawgdic::BaseType node_pos1 = node_pos;
      bool find = true;
      for (int s = matches[j].first; s < matches[j].second; ++s) {
        LOG(INFO) << "follow2 " << words[s].as_string();
        CHECK_GT((int)words.size(), s);
        if (!(dict_.Follow(words[s].data(), words[s].size(), &node_pos1))) {
          find = false;
          break;
        }
      }
      if (!find) continue;
      if (!dict_.has_value(node_pos1)) continue;
      int result = dict_.value(node_pos1);
      CHECK_EQ(result, values[j]) << result << " vs " << values[j] << " \n " << norm_content;

      if (has_terminal(values[j])) score += 10;
    }
  }
  return score;
}

std::pair<int, int> SimpleMatch::CalcMatch(const reco::RecoItem& reco_item) {
  std::string norm_title;
  std::string norm_content;
  nlp::util::NormalizeLineCopy(reco_item.content(), &norm_content);
  nlp::util::NormalizeLineCopy(reco_item.title(), &norm_title);
  
  int title_score = CalcMatch(norm_title);
  int content_score = CalcMatch(norm_content);
  return std::make_pair(title_score, content_score);
}

void GetItem(thread::BlockingQueue<uint64>* item_id_queue,
             thread::BlockingQueue<reco::RecoItem* >* reco_item_queue) {
  reco::HBaseGetItem get_item_service(FLAGS_hbase_ip, FLAGS_hbase_port, FLAGS_hbase_table, 0);
  uint64 item_id = 0;
  reco::RecoItem reco_item;
  while (!(item_id_queue->Closed() && item_id_queue->Empty())) {
    int status = item_id_queue->TimedTake(10, &item_id);
    if (status == -1) break;
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    CHECK_EQ(status, 1) << "fucking status " << status;

    if (!get_item_service.GetRecoItem(item_id, &reco_item)) {
      LOG(ERROR) << "faile to get item: " << item_id;
      continue;
    }
    if (!reco_item.has_raw_item()) {
      LOG(ERROR) << "item without raw item: " << item_id;
      continue;
    }
    
    reco::RecoItem* item = new reco::RecoItem();
    item->Swap(&reco_item);
    reco_item_queue->Put(item);
  }
  LOG(INFO) << "read item id finished";
  reco_item_queue->Close();
}

void Extract(thread::BlockingQueue<reco::RecoItem*>* item_queue, thread::BlockingQueue<std::string>* result,
             thread::BlockingVar<int>* finish_num) {
  std::string result_str;
  reco::RecoItem* reco_item = NULL;
  SimpleMatch simple_match;
  while (!(item_queue->Closed() && item_queue->Empty())) {
    int status = item_queue->TimedTake(10, &reco_item);
    if (status == -1) break;
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    CHECK_EQ(status, 1) << "fucking status " << status;

    std::pair<int, int> score = simple_match.CalcMatch(*reco_item);
    
    // output
    result->Put(base::StringPrintf("%lu\t%s\t%d\t%d", reco_item->identity().item_id(),
                                   reco_item->title().c_str(), score.first, score.second));
    delete reco_item;
  }
  int n = finish_num->Take() + 1;

  if (n >= FLAGS_thread_num) result->Close();

  CHECK(finish_num->TryPut(n));
}

void save(thread::BlockingQueue<std::string>* result_queue) {
  std::string result;
  while (!(result_queue->Closed() && result_queue->Empty())) {
    int status = result_queue->TimedTake(10, &result);
    if (status == -1) break;
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    CHECK_EQ(status, 1) << "fucking status " << status;
    std::cout << result << std::endl;
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "feature demo");
  CHECK(SimpleMatch::Init(base::FilePath(FLAGS_word_file)));

  thread::BlockingQueue<std::string> result_queue;
  thread::BlockingQueue<uint64> item_id_queue;
  thread::BlockingQueue<reco::RecoItem*> reco_item_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  thread::ThreadPool pool(FLAGS_thread_num + 2);
  pool.AddTask(::NewCallback(save, &result_queue));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(Extract, &reco_item_queue, &result_queue, &finish_num));
  }
  pool.AddTask(::NewCallback(GetItem, &item_id_queue, &reco_item_queue));

  std::string line;
  uint64 item_id = 0;
  std::vector<std::string> tokens;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);

    if (!base::StringToUint64(tokens.front(), &item_id)) {
      LOG(ERROR) << "error item id " << line;
      continue;
    }
    item_id_queue.Put(item_id);
  }
  item_id_queue.Close();
  pool.JoinAll();
  return 0;
}
