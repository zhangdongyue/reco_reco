import sys
for line in sys.stdin:
  elements = line.strip().split("\t")
  if len(elements) < 2:
    continue
  
  ngrams = elements[0].split("|")
  if len(ngrams) > 2:
    continue

  weight = 0
  for i in range(2, len(elements), 2):
    if elements[i] == "seqing":
      weight = float(elements[i + 1])
      break
  
  if len(ngrams) == 2:
    if ngrams[0].find("NUMBER") > -1 or ngrams[0].find("BEGIN") > -1 or ngrams[0].find("END") > -1:
      continue

    print "Bigram:%s:%s\t%lf" %(ngrams[0], ngrams[1], weight)
    print "Bigram:%s:%s\t%lf" %(ngrams[1], ngrams[0], weight)
  elif len(ngrams) == 1:
    print "Unigram:%s\t%lf" %(ngrams[0], weight)

  else:
    sys.stderr.write("fucku : %s" %line)

