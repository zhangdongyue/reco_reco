#include <vector>
#include <algorithm>
#include <functional>
#include <utility>

#include "reco/module/bad_item/offline/training_util.h"
#include "reco/bizc/item_service/hbase_pool_get_item.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "nlp/common/nlp_util.h"


DEFINE_int32(run_type, 0, "run_type");
DEFINE_string(hbase_table, "tb_reco_item", "hbase table");
DEFINE_int32(threshold, 100, "");
// 0: title ngram; 1: ngram * media; 2: 首尾段 ngram; 3: 每段首尾句 ngram; 4: keyword, 5: 媒体低质占比
DEFINE_int32(feature_type, 0, "");

nlp::segment::Segmenter* segmenter_;
nlp::postag::PosTagger* pos_tagger_;
nlp::ner::Ner* ner_;
nlp::time::TimeRecognizer* time_reco_;

void Initial() {
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());
  segmenter_ = new nlp::segment::Segmenter;
  pos_tagger_ = new nlp::postag::PosTagger;
  ner_ = new nlp::ner::Ner;
  time_reco_ = new nlp::time::TimeRecognizer();
}

void Destory() {
  delete ner_;
  ner_ = NULL;
  delete pos_tagger_;
  pos_tagger_ = NULL;
  delete segmenter_;
  segmenter_ = NULL;
  delete time_reco_;
  time_reco_ = NULL;
}

void mapper() {
  reco::HBasePoolGetItem* item_getter = new reco::HBasePoolGetItem(FLAGS_hbase_table, 20000);
  std::string line;
  std::vector<std::string> tokens;
  uint64 item_id;
  int type;
  std::vector<std::string> result;
  while (std::getline(std::cin, line)) {
    result.clear();
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    CHECK_EQ((int)tokens.size(), 2);
    if (!base::StringToUint64(tokens[0], &item_id)) continue;
    if (!base::StringToInt(tokens[1], &type)) continue;
    reco::RecoItem reco_item;
    if (!item_getter->GetRecoItem(item_id, &reco_item)) continue;
    if (FLAGS_feature_type == 0) {
      GenerateTitleNgram(segmenter_, pos_tagger_, ner_, time_reco_, reco_item, &result);
      if (result.empty()) continue;
      for (int i = 0; i < (int)result.size(); ++i) {
        std::cout << result[i] << "\t" << type << std::endl;
      }
      continue;
    }
    if (FLAGS_feature_type == 1) {
      GenerateTitleMediaNgram(segmenter_, pos_tagger_, ner_, time_reco_, reco_item, &result);
      if (result.empty()) continue;
      for (int i = 0; i < (int)result.size(); ++i) {
        std::cout << result[i] << "\t" << type << std::endl;
      }
      continue;
    }
    if (FLAGS_feature_type == 2) {
      GenerateParagraphNgram(segmenter_, pos_tagger_, ner_, time_reco_, reco_item, &result);
      if (result.empty()) continue;
      for (int i = 0; i < (int)result.size(); ++i) {
        std::cout << result[i] << "\t" << type << std::endl;
      }
      continue;
    }
    if (FLAGS_feature_type == 3) {
      GenerateSentenceNgram(segmenter_, pos_tagger_, ner_, time_reco_, reco_item, &result);
      if (result.empty()) continue;
      for (int i = 0; i < (int)result.size(); ++i) {
        std::cout << result[i] << "\t" << type << std::endl;
      }
      continue;
    }
    if (FLAGS_feature_type == 4) {
      GenerateKeywords(reco_item, &result);
      if (result.empty()) continue;
      for (int i = 0; i < (int)result.size(); ++i) {
        std::cout << result[i] << "\t" << type << std::endl;
      }
      continue;
    }
    if (FLAGS_feature_type == 5) {
      GenerateMediaRatio(reco_item, type, &result);
      if (result.empty()) continue;
      for (int i = 0; i < (int)result.size(); ++i) {
        std::cout << result[i] << std::endl;
      }
      continue;
    }
    if (FLAGS_feature_type == 6) {
      GenerateTitleCategoryNgram(segmenter_, pos_tagger_, ner_, time_reco_, reco_item, &result);
      if (result.empty()) continue;
      for (int i = 0; i < (int)result.size(); ++i) {
        std::cout << result[i] << "\t" << type << std::endl;
      }
      continue;
    }
    if (FLAGS_feature_type == 7) {
      GenerateContentNgram(segmenter_, pos_tagger_, ner_, time_reco_, reco_item, &result);
      if (result.empty()) continue;
      for (int i = 0; i < (int)result.size(); ++i) {
        std::cout << result[i] << "\t" << type << std::endl;
      }
      continue;
    }
    if (FLAGS_feature_type == 8) {
      GenerateTitleSimbleNgram(segmenter_, pos_tagger_, ner_, time_reco_, reco_item, &result);
      if (result.empty()) continue;
      for (int i = 0; i < (int)result.size(); ++i) {
        std::cout << result[i] << "\t" << type << std::endl;
      }
      continue;
    }
  }
}

void reducer() {
  std::string line;
  std::string before = "";
  int count = 0;
  int count_all = 0;
  int count_pos = 0;
  std::vector<std::string> tokens;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    CHECK_EQ((int)tokens.size(), 2);
    count_all++;
    std::string current = tokens[0];
    if (count_all == 1) {
      before = current;
    }
    if (current != before) {
      float ratio = (float)count_pos / (float)count;
      if (count > FLAGS_threshold && (ratio >= 0.9 || ratio <= 0.10)) {
        std::cout << before << std::endl;
      }
      if (tokens[1] == "1") {
        count_pos = 1;
      } else {
        count_pos = 0;
      }
      count = 1;
      before = current;
    } else {
      count++;
      if (tokens[1] == "1") count_pos++;
    }
  }
  // last line
  float ratio = (float)count_pos / (float)count;
  if (count > FLAGS_threshold && (ratio >= 0.9 || ratio <= 0.10)) {
    std::cout << before << std::endl;
  }
}

void reducer_media() {
  std::string line;
  std::string media;
  std::string before = "";
  int total_media = 0;
  int bad_media = 0;
  int count_all = 0;
  std::vector<std::string> tokens;
  while (std::getline(std::cin, line)) {
    count_all++;
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    CHECK_EQ((int)tokens.size(), 2);
    std::string current = tokens[0];
    if (count_all == 1) {
      before = current;
    }
    if (current != before) {
      float ratio = (float)bad_media / (float)total_media;
      if (ratio > 0.90) {
        std::cout << before << "\t" << ratio << "\t" << total_media << std::endl;
      }
      before = current;
      total_media = 1;
      bad_media = 0;
      if (tokens[1] == "1") bad_media = 1;
    } else {
      total_media++;
      if (tokens[1] == "1") bad_media++;
    }
  }
  // last line
  float ratio = (float)bad_media / (float)total_media;
  if (ratio> 0.90) {
    std::cout << before << "\t" << ratio << "\t" << total_media << std::endl;
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "generate ngrams");
  if (FLAGS_run_type == 0) {
    Initial();
    mapper();
    Destory();
  } else {
    if (FLAGS_feature_type != 5) {
      reducer();
    } else {
      reducer_media();
    }
  }
  return 0;
}
