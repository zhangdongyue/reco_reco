#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <map>
#include <set>

#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "serving_base/utility/signal.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"

DEFINE_string(input, "item_ids.txt", "input file");
DEFINE_string(output_hit, "pos.txt", "output file");
DEFINE_string(output_unhit, "neg.txt", "output file");
DEFINE_int32(thread_num, 2, "number of thread");
DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");

void GenerateRequest(std::string path, thread::BlockingQueue<uint64>* request_queue) {
  std::string line;
  uint64 item_id;
  std::ifstream fin(path);
  while (std::getline(fin, line)) {
    if (!base::StringToUint64(line, &item_id)) {
      LOG(ERROR) << "erro line: " << line;
      continue;
    }
    request_queue->Put(item_id);
  }
  fin.close();
  LOG(INFO) << "read file finished!";
  request_queue->Close();
}

void Dump(thread::BlockingQueue<uint64>* request_queue,
          thread::BlockingVar<int>* finish_num,
          thread::BlockingQueue<std::pair<int, std::string>>* result_queue) {
  reco::BaseGetItem* item_getter = new reco::ItemKeeperGetItem(FLAGS_item_keeper_server_ip, FLAGS_item_keeper_server_port); // NOLINT
  uint64 item_id;
  std::string result;
  while (!(request_queue->Closed() && request_queue->Empty())) {
    result.clear();
    int status = request_queue->Take(&item_id);
    if (status == 0) {
      base::SleepForMilliseconds(1000);
      continue;
    }
    if (status < 0) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status: " << status;

    reco::RecoItem item;
    if (!item_getter->GetRecoItem(item_id, &item) ||
        item.identity().type() == 30 ||
        item.identity().producer() == "uc_br_op") continue;
    if (!item.has_content_attr()) continue;
    reco::ContentAttr content_attr = item.content_attr();
    std::string cate = "未分类";
    if (item.category_size() > 0) cate = item.category(0);
    result = base::StringPrintf("%lu\t%s\t%s\t%s\t%d", item_id,
                                item.title().c_str(), item.source_media().c_str(),
                                cate.c_str(), content_attr.bluffing_title());
    if (content_attr.bluffing_title() != 0) {
      result_queue->Put(std::make_pair(1, result));
    } else {
      result_queue->Put(std::make_pair(0, result));
    }
  }
  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    result_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
  delete item_getter;
  item_getter = NULL;
}

void RecordResult(thread::BlockingQueue<std::pair<int, std::string>>* result_queue) {
  std::ofstream fout_hit(FLAGS_output_hit);
  std::ofstream fout_unhit(FLAGS_output_unhit);
  std::pair<int, std::string> result;
  while (!(result_queue->Closed() && result_queue->Empty())) {
    int status = result_queue->Take(&result);
    if (status < 0) {
      break;
    }
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }
    CHECK_EQ(status, 1) << "fucking status: " << status;
    if (result.first == 1) {
      fout_hit << result.second << std::endl;
    } else {
      fout_unhit << result.second << std::endl;
    }
  }
  fout_hit.close();
  fout_unhit.close();
  LOG(INFO) << "writing file finished!";
  result_queue->Close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "dump samples");
  LOG(INFO) << "begin dump samples";

  thread::BlockingQueue<uint64> request_queue;
  thread::BlockingQueue<std::pair<int, std::string>> result_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  thread::ThreadPool pool(FLAGS_thread_num + 2);
  pool.AddTask(::NewCallback(&GenerateRequest, FLAGS_input, &request_queue));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(&Dump, &request_queue, &finish_num, &result_queue));
  }
  pool.AddTask(::NewCallback(&RecordResult, &result_queue));
  pool.JoinAll();
  LOG(INFO) << "finish dump samples";
  return 0;
}
