#include <string>
#include <vector>
#include <fstream>
#include <unordered_map>

#include "reco/module/bad_item/feature/comment_feature_extractor.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"
#include "base/thread/blocking_var.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/file/file_path.h"

DEFINE_string(data_dir, "./dict", "data dir");
DEFINE_string(result_file, "./result.txt", "data dir");
DEFINE_int32(thread_num, 8, "thread num");

void ExtractorWorker(thread::BlockingQueue<std::string>* input_queue,
                     thread::BlockingQueue<std::string>* result_queue,
                     thread::BlockingVar<int>* finish_num) {
  std::string line;
  std::vector<std::string> tokens;
  std::vector<std::pair<uint64, float>> features;
  std::unordered_map<uint64, std::string> feature_dict;

  std::unordered_map<std::string, int> stat_dict;

  reco::bad_item::CommentFeatureExtractor extractor;
  extractor.Initial(base::FilePath(FLAGS_data_dir));

  while (!(input_queue->Closed() && input_queue->Empty())) {
    int status = input_queue->TimedTake(10, &line);
    if (status == -1) break;

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    CHECK_EQ(status, 1) << "fuck status " << status;

    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 4) continue;

    // uint64 item_id = base::ParseUint64OrDie(tokens[0]);
    features.clear();
    int fea_num = extractor.Extract(tokens[1], false, &features, &feature_dict);

    if (fea_num < 1) continue;

    for (size_t i = 0; i < features.size(); ++i) {
      auto it = feature_dict.find(features[i].first);
      if (it == feature_dict.end()) continue;
      std::string term = base::StringPrintf("%s:%s", tokens[2].c_str(), it->second.c_str());
      auto it_pair = stat_dict.insert(std::make_pair(term, 1));
      if (!it_pair.second) {
        it_pair.first->second += 1;
      }
    }

    features.clear();
    fea_num = extractor.Extract(tokens[3], false, &features, &feature_dict);

    if (fea_num < 1) continue;

    for (size_t i = 0; i < features.size(); ++i) {
      auto it = feature_dict.find(features[i].first);
      if (it == feature_dict.end()) continue;
      std::string term = base::StringPrintf("%s:%s", tokens[2].c_str(), it->second.c_str());
      auto it_pair = stat_dict.insert(std::make_pair(term, 1));
      if (!it_pair.second) {
        it_pair.first->second += 1;
      }
    }
  }

  for (auto it = stat_dict.begin(); it != stat_dict.end(); ++it) {
    result_queue->Put(base::StringPrintf("%s\t%d", it->first.c_str(), it->second));
  }

  int n = finish_num->Take() + 1;
  if (n == FLAGS_thread_num) {
    result_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

void StatWorker(thread::BlockingQueue<std::string>* result_queue) {
  std::string line;
  std::vector<std::string> tokens;
  std::unordered_map<std::string, int> stat_dict;

  while (!(result_queue->Closed() && result_queue->Empty())) {
    int status = result_queue->TimedTake(10, &line);
    if (status == -1) break;

    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    CHECK_EQ(status, 1) << "fuck status " << status;

    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 2) continue;
    int count = base::ParseIntOrDie(tokens[1]);
    auto it_pair = stat_dict.insert(std::make_pair(tokens[0], count));

    if (!it_pair.second) stat_dict[tokens[0]] += count;
  }

  std::ofstream fout(FLAGS_result_file);
  for (auto it = stat_dict.begin(); it != stat_dict.end(); ++it) {
    fout << it->first << "\t" << it->second << "\n";
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "feature demo");
  thread::BlockingQueue<std::string> input_queue;
  thread::BlockingQueue<std::string> stat_queue;
  thread::BlockingVar<int> finish_num;
  thread::ThreadPool pool(FLAGS_thread_num + 1);
  CHECK(finish_num.TryPut(0));

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(ExtractorWorker, &input_queue, &stat_queue, &finish_num));
  }
  pool.AddTask(::NewCallback(StatWorker, &stat_queue));

  std::string line;
  while (std::getline(std::cin, line)) {
    input_queue.Put(line);
  }
  input_queue.Close();
  pool.JoinAll();
  return 0;
}
