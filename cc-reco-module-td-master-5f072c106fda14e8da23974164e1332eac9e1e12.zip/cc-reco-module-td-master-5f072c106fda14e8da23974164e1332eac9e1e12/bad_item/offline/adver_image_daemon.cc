#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "nlp/common/nlp_util.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "net/counter/export.h"
#include "reco/ml/feature/global_data/global_data.h"
#include "reco/ml/feature/global_data/dict_loader.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

DEFINE_int32(thread_num, 2, "number of thread for process image ocr");

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_int64_counter(adver_image, success_num, 0, "total adver image num");
DEFINE_int64_counter(adver_image, fail_num, 0, "total failed to be saved image num");
DEFINE_int64_counter(adver_image, process_num, 0, "the num of processed images");
DEFINE_int64_counter(adver_image, remain_num, 0, "the num of remain images");

DEFINE_string(timestamp_file, "timestamp.txt", "timestammp file");
DEFINE_string(data_dir, "../data", "data dir");

DEFINE_bool(stand_alone, false, "");
DEFINE_string(record_file, "adver_images.txt", "file for stand alone save adver images");

enum {
  kAdverPhone = 0,
  kAdverID = 1,
  kTitleCandidate = 2
};

namespace reco {
namespace bad_item {

const char* kAdverRuleFile = "advertorial_rule.txt";
const char* kAdverKeywordFile = "advertorial_keywords.txt";
const char* kAdverImpurityKeywordFile = "advertorial_impurity_keywords.txt";
const std::string kImageLevelKey = "ImageBadLevel-";

class AdverImageProcessor {
 private:
  AdverImageProcessor() {}
  ~AdverImageProcessor() {}

 public:
  static void Start();
  static void Stop();

 private:
  static void GenerateImageRequest();
  static void Process();
  static void SaveToRedis();

 private:
  static const char* kTimestampFile;
  static std::string start_time_;
  static thread::BlockingQueue<std::pair<uint64, std::string> > request_queue_;
  static thread::BlockingQueue<std::pair<uint64, int> > result_queue_;

  static thread::BlockingVar<int> finish_num_;
  static thread::ThreadPool* thread_pool_;
  static bool stop_;
};

bool inline has_id(const std::string& content, int p, int end, std::string* id) {
  while (p != end) {
    if ((content[p] >= '0' && content[p] <= '9') || content[p] == '-' ||
        (content[p] <= 'z' && content[p] >= 'a') || (content[p] <= 'Z' && content[p] >= 'A') ||
        content[p] == '_' || content[p] == ']' || content[p] == '[') {
      *id += content[p];
      ++p;
    } else {
      if (id->size() >= 7) {
        if (*id == "wechat" || *id == "strong" || *id == "emoji") {
          *id = "";
          ++p;
          continue;
        }
        return true;
      }
      *id = "";
      ++p;
    }
  }
  if (id->size() >= 5) {
    if (*id == "wechat" || *id == "strong" || *id == "emoji") return false;
    return true;
  }
  return false;
}

bool inline has_phone_number(const std::string& content, int p, int end, std::string* number) {
  while (p != end && number->size() < 15) {
    if (content[p] == ' ' || (content[p] >= '0' && content[p] <= '9') || content[p] == '-' ||
        content[p] == '_' || content[p] == ':' || content[p] == ']' || content[p] == '[' ||
        content[p] == '(' || content[p] == ')' || content[p] == '*') {
      *number += content[p];
      ++p;
    } else if (content[p] == '.' || content[p] == '%' || content[p] == 'x') {
      ++p;
      number->clear();
    } else {
      if (number->size() > 6) {
        return true;
      }
      *number = "";
      ++p;
    }
  }
  if (number->size() > 6) {
    return true;
  }
  return false;
}

void MatchAdverRule(const dawgdic::Dictionary& adver_rules_,
                    const std::string& line,
                    std::unordered_set<std::string>* hit_terms) {
  std::vector<std::string> matches;
  std::vector<base::Slice> term_matches;
  std::vector<int> values;
  nlp::util::ForwardMaxMatch(adver_rules_, line, &term_matches, &values);
  for (int i = 0; i < (int)term_matches.size(); ++i) {
    matches.push_back(term_matches[i].as_string());
  }
  int pos = 0;
  std::vector<std::string> features;
  std::string num_or_id;
  for (int i = 0; i < (int)values.size(); ++i) {
    if (values[i] == kTitleCandidate) continue;
    if (values[i] == kAdverPhone) {
      int length = 0;
      if (i > 0) length = matches[i - 1].size();
      pos = line.find(matches[i], pos + length) + matches[i].size();
      int end = pos + 15;
      int start = pos - matches[i].size() - 15;
      if (start < 0) start = 0;
      if (end >= (int)line.size()) end = line.size();
      num_or_id.clear();
      if (has_phone_number(line, start, end, &num_or_id)) {
        hit_terms->insert(base::StringPrintf("%s_hit_number", matches[i].c_str()));
      }
    } else if (values[i] == kAdverID) {
      int length = 0;
      if (i > 0) length = matches[i - 1].size();
      pos = line.find(matches[i], pos + length) + matches[i].size();
      int start = pos - matches[i].size() - 15;
      if (start < 0) start = 0;
      int end = pos + 15;
      if (end >= (int)line.size()) end = line.size();
      num_or_id.clear();
      if (has_id(line, start, end, &num_or_id)) {
        hit_terms->insert(base::StringPrintf("%s_hit_id", matches[i].c_str()));
      }
    } else {
      hit_terms->insert(matches[i]);
    }
  }
}

void DetectLineWithDict(const dawgdic::Dictionary& dict,
                        const std::string& sentence,
                        std::unordered_set<std::string>* hit_terms) {
  std::vector<base::Slice> matches;
  std::vector<int> values;
  if (nlp::util::ForwardMaxMatch(dict, sentence, &matches, &values) == 0) return;
  CHECK_EQ(matches.size(), values.size());
  std::vector<std::pair<base::Slice, int>> sorted_matches;
  for (int i = 0; i < (int)matches.size(); ++i) {
    if (values[i] == 2 || values[i] > 3) {
      hit_terms->insert(matches[i].as_string());
    }
    sorted_matches.push_back(std::make_pair(matches[i], values[i]));
  }
  std::string ngram;
  dawgdic::BaseType index = dict.root();
  for (int i = 0;  i < (int)sorted_matches.size(); ++i) {
    index = dict.root();
    if (!dict.Follow(sorted_matches[i].first.data(), sorted_matches[i].first.size(), &index)) {
      continue;
    }
    for (int j = i + 1; j < (int)sorted_matches.size(); ++j) {
      dawgdic::BaseType index_temp = index;
      if (sorted_matches[j].second == 0 || sorted_matches[j].second == 5) continue;
      if (!dict.Follow(sorted_matches[j].first.data(), sorted_matches[j].first.size(), &index_temp)) {
        continue;
      }
      if (dict.has_value(index_temp) &&
          (dict.value(index_temp) == 2 || dict.value(index_temp) > 3)) {
        if (sentence.find(sorted_matches[j].first.as_string()) - sentence.find(sorted_matches[i].first.as_string()) > 50) continue; // NOLINT
        std::string temp = base::StringPrintf("%s#%s",
                                              sorted_matches[i].first.as_string().c_str(),
                                              sorted_matches[j].first.as_string().c_str());
        hit_terms->insert(temp);
      }
    }
  }
}

//------------- class AdverImageProcessor -----------------------------
const char* AdverImageProcessor::kTimestampFile = "timestamp.txt";
std::string AdverImageProcessor::start_time_ = "2016-10-27 00:00:00";
thread::BlockingQueue<std::pair<uint64, std::string>> AdverImageProcessor::request_queue_;
thread::BlockingQueue<std::pair<uint64, int> > AdverImageProcessor::result_queue_;
thread::BlockingVar<int> AdverImageProcessor::finish_num_;
thread::ThreadPool* AdverImageProcessor::thread_pool_ = NULL;
bool AdverImageProcessor::stop_ = false;

void AdverImageProcessor::Start() {
  base::FilePath base_dir(FLAGS_data_dir);
  base::FilePath timestamp_file = base_dir.Append(kTimestampFile);
  CHECK(base::file_util::PathExists(timestamp_file));
  std::string line;
  std::ifstream fin(base_dir.Append(FLAGS_timestamp_file).ToString());
  while (std::getline(fin, line)) {
    if (line.size() < 1) continue;
    nlp::util::NormalizeLineCopy(line, &start_time_);
  }
  fin.close();

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverRuleFile,
                            reco::ml::LoadAdverRuleFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverImpurityKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  reco::dm::DictManagerSingleton::instance().LoadAllDicts();

  thread_pool_ = new thread::ThreadPool(FLAGS_thread_num + 2);
  thread_pool_->AddTask(::NewCallback(&AdverImageProcessor::GenerateImageRequest));
  CHECK(finish_num_.TryPut(0));
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    thread_pool_->AddTask(::NewCallback(&AdverImageProcessor::Process));
  }
  thread_pool_->AddTask(::NewCallback(&AdverImageProcessor::SaveToRedis));
}

void AdverImageProcessor::Stop() {
  if (!stop_) {
    stop_ = true;
    LOG(INFO) << "begin to join all thread";
    thread_pool_->JoinAll();
  }
}

void AdverImageProcessor::GenerateImageRequest() {
  serving_base::mysql_util::DbConnManager::Option option;
  option.host = FLAGS_db_host;
  option.user = FLAGS_db_user;
  option.passwd = FLAGS_db_passwd;
  option.schema = FLAGS_schema;
  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(option);
  uint64 ori_time = 0;
  uint64 now = 0;
  while (!stop_) {
    CHECK(serving_base::TimeHelper::StringToTimestamp(start_time_,
                                                      serving_base::TimeHelper::kSecond,
                                                      &ori_time));
    CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond, &now));
    if (now - ori_time > 1000000L * 5) {
      std::string current_time = "";
      CHECK(serving_base::TimeHelper::TimestampToString(now, serving_base::TimeHelper::kSecond, &current_time)); // NOLINT
      std::string sql = base::StringPrintf("select image_id, ocr from tb_image_meta where create_time>='%s' and create_time<='%s';", start_time_.c_str(), current_time.c_str()); // NOLINT

      start_time_ = current_time;
      base::FilePath base_dir(FLAGS_data_dir);
      base::FilePath timestamp_file = base_dir.Append(kTimestampFile);
      CHECK(base::file_util::PathExists(timestamp_file));
      std::ofstream fout(base_dir.Append(FLAGS_timestamp_file).ToString());
      fout << start_time_ << std::endl;
      fout.close();

      // generate iamge ocrs
      std::string ocr;
      uint64 image_id = 0;
      std::string id_str;
      std::string key;
      scoped_ptr<sql::ResultSet> res(db_manager->ExecuteQueryWithRetry(sql, 3));
      while (res->next()) {
        ocr = res->getString("ocr");
        id_str = res->getString("image_id");
        base::StringToUint64(id_str, &image_id);
        nlp::util::NormalizeLineInPlaceS(&ocr);
        request_queue_.Put(std::make_pair(image_id, ocr));
      }
    }
  }
  request_queue_.Close();
  delete db_manager;
  db_manager = NULL;
}

void AdverImageProcessor::Process() {
  const dawgdic::Dictionary* adver_rules_ = reco::ml::GlobalDataIns::instance().GetAdverRules().get();
  const dawgdic::Dictionary* adver_keywords_ = reco::ml::GlobalDataIns::instance().GetAdverKeywords().get();

  std::pair<uint64, std::string> request;
  std::unordered_set<std::string> temp;
  // type 1: 只命中规则，type 2: 只命中关键字, type 3: 命中规则和关键字
  while (!(request_queue_.Closed() && request_queue_.Empty())) {
    int count_rule = 0;
    int count_keyword = 0;
    int type = 0;
    temp.clear();
    COUNTERS_adver_image__remain_num.Reset(request_queue_.Size());
    int status = request_queue_.TimedTake(100, &request);
    if (status == 0) {
      base::SleepForMilliseconds(100);
      continue;
    }
    if (status < 0) {
      break;
    }
    CHECK_EQ(status, 1) << "fucking status: " << status;
    MatchAdverRule(*adver_rules_, request.second, &temp);
    count_rule = temp.size();
    if (count_rule > 0) type = 1;

    DetectLineWithDict(*adver_keywords_, request.second, &temp);
    count_keyword = temp.size() - count_rule;
    if (type == 0 && count_keyword > 0) {
      type = 2;
    } else if (type == 1 && count_keyword > 0) {
      type = 3;
    }

    COUNTERS_adver_image__process_num.Increase(1);
    if (type == 0) continue;
    result_queue_.Put(std::make_pair(request.first, type));
  }

  int n = finish_num_.Take() + 1;
  if (n >= FLAGS_thread_num) {
    request_queue_.Close();
    result_queue_.Close();
  }
  finish_num_.TryPut(n);
}

void AdverImageProcessor::SaveToRedis() {
  reco::redis::RedisCli *redis_cli = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);
  CHECK(redis_cli->GetPool()->IsRun());
  std::pair<uint64, int> result;
  std::string key;
  while (!(result_queue_.Closed() && result_queue_.Empty())) {
    key.clear();
    int status = result_queue_.TimedTake(100, &result);
    if (status == 0) {
      base::SleepForMilliseconds(100);
      continue;
    }
    if (status < 0) break;
    CHECK_EQ(status, 1) << "fucking status: " << status;

    key = base::StringPrintf("%s%lu", kImageLevelKey.c_str(), result.first);
    if (!FLAGS_stand_alone) {
      int count = 0;
      while (count < 3 && !redis_cli->SetEx(key, base::IntToString(result.second), 3600 * 24 * 185)) {
        ++count;
        base::SleepForSeconds(0.1);
      }
      if (count < 3) {
        LOG(INFO) << "success to set image into redis!\t" << result.first << "\t" << result.second;
        COUNTERS_adver_image__success_num.Increase(1);
      } else {
        LOG(ERROR) << "fail to set image into redis!\t" << result.first << "\t" << result.second;
        COUNTERS_adver_image__fail_num.Increase(1);
      }
    } else {
      LOG(INFO) << "success to set image into file!\t" << result.first << "\t" << result.second;
      std::ofstream fout(FLAGS_record_file, std::ios::app);
      fout << result.first << "\t" << result.second << std::endl;
      fout.close();
    }
  }
}
}
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "offline comment process");

  reco::bad_item::AdverImageProcessor::Start();
  std::cout << "adver image processor daemon start" << std::endl;

  net::counter::HttpCounterExport();
  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();

  reco::bad_item::AdverImageProcessor::Stop();
  LOG(INFO) << "adver image processor daemon stop";
  return 0;
}
