#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <unordered_set>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "base/common/base.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/sim_item.pb.h"
#include "net/counter/export.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/item_service/hbase_pool_get_sim.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"

DEFINE_string(input, "expire_ids.txt", "item ids to be expired");
DEFINE_string(kafka_brokers, "10.181.169.190:9092,10.181.169.191:9092,10.181.169.192:9092,10.181.169.193:9092,10.181.169.194:9092", "kafka queue servers");  // NOLINT
DEFINE_string(item_field_kafka_brokers, "10.181.169.190:9092,10.181.169.191:9092,10.181.169.192:9092,10.181.169.193:9092,10.181.169.194:9092", "kafka queue servers");  // NOLINT
DEFINE_string(item_field_topic, "", "ation log topic name");
DEFINE_int32(item_field_partition_num, 9, "action log partition num");
DEFINE_string(hbase_table, "tb_reco_item", "hbase table");
DEFINE_string(hbase_sim_table, "tb_sim_item", "hbase table");
DEFINE_bool(expire, false, "");
DEFINE_bool(calc_sim, false, "");
DEFINE_string(item_keeper_server_ip, "11.251.177.97", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_string(sim_server_ip, "11.251.177.97", "sim server ip");
DEFINE_int32(sim_server_port, 20066, "server port");

reco::ContentAttr::ContentAttrLevel attr_values[] = { reco::ContentAttr::kSureNo,
  reco::ContentAttr::kSuspect, reco::ContentAttr::kSureYes };

void ChangeContentAttr(uint64 item_id,
                       const std::vector<std::string>& tokens,
                       bool in_index,
                       reco::itemkeeper::ItemKeeper::Stub* rpc_stub) {
  reco::itemkeeper::UpdateItemRequest request;
  reco::itemkeeper::UpdateItemFieldResponse response;
  request.mutable_service_identity()->set_service_name("offline_change_content_attr");
  request.set_item_id(item_id);
  request.set_is_manual(true);
  if (!in_index) {
    LOG(INFO) << "item not in index, only change content attr, no cdoc";
    request.add_exclude_storages(reco::itemkeeper::kCdocQueue);
  }
  reco::RecoItem reco_item;
  reco::ContentAttr content_attr;
  content_attr.set_erro_title(attr_values[base::ParseIntOrDie(tokens[1])]);
  content_attr.set_advertorial(attr_values[base::ParseIntOrDie(tokens[2])]);
  content_attr.set_short_content(attr_values[base::ParseIntOrDie(tokens[3])]);
  content_attr.set_dedup_paragraph(attr_values[base::ParseIntOrDie(tokens[4])]);
  content_attr.set_dirty(attr_values[base::ParseIntOrDie(tokens[5])]);
  content_attr.set_politics(attr_values[base::ParseIntOrDie(tokens[6])]);
  content_attr.set_bluffing_title(attr_values[base::ParseIntOrDie(tokens[7])]);
  content_attr.set_negative(attr_values[0]);
  reco_item.mutable_content_attr()->Swap(&content_attr);

  if (FLAGS_expire) {
    reco_item.SerializePartialToString(request.mutable_reco_item_bytes());
    net::rpc::RpcClientController rpc;
    rpc_stub->updateItemFields(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "refresh reco item failed. "
                 << " item id: "
                 << item_id << ", "
                 << response.Utf8DebugString();
      return;
    } else {
      LOG(INFO) << "done update reco item: " << item_id;
    }
  } else {
    LOG(INFO) << "change item:\t" << item_id << "\t" << tokens[1] << "\t" << tokens[2] << "\t"
              << tokens[3] << "\t" << tokens[4] << "\t" << tokens[5] << "\t" << tokens[6] << "\t"
              << tokens[7];
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "offline change content attr");
  reco::hbase::HBasePoolIns::instance().Init();
  CHECK(reco::hbase::HBasePoolIns::instance().is_inited());
  reco::BaseGetItem* item_getter = new reco::ItemKeeperGetItem(FLAGS_item_keeper_server_ip, FLAGS_item_keeper_server_port); // NOLINT
  reco::HBasePoolGetSim* sim_getter = new reco::HBasePoolGetSim(FLAGS_hbase_sim_table);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 1;
  options.timeout = 3000;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_item_keeper_server_ip, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_item_keeper_server_port, 3000);
    options.servers.push_back(si);
  }
  net::rpc::RpcGroup* rpc_group = new net::rpc::RpcGroup(options);
  CHECK(rpc_group->Connect());
  reco::itemkeeper::ItemKeeper::Stub* rpc_stub = new reco::itemkeeper::ItemKeeper::Stub(rpc_group);

  net::rpc::RpcGroup::Options options_sim;
  options_sim.max_retry_times = 1;
  options_sim.timeout = 3000;
  flds.clear();
  base::SplitString(FLAGS_sim_server_ip, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo server_info_sim(flds[i], FLAGS_sim_server_port, 3000);
    options_sim.servers.push_back(server_info_sim);
  }
  net::rpc::RpcGroup* rpc_group_sim = new net::rpc::RpcGroup(options_sim);
  CHECK(rpc_group_sim->Connect());
  reco::sim_item::SimItemService::Stub* rpc_stub_sim = new reco::sim_item::SimItemService::Stub(rpc_group_sim); // NOLINT

  std::ifstream fin(FLAGS_input);
  std::string line;
  std::vector<std::string> tokens;
  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if ((int)tokens.size() != 8) {
      LOG(ERROR) << "input error:\t" << line;
      continue;
    }
    uint64 item_id;
    base::StringToUint64(tokens[0], &item_id);
    LOG(INFO) << "item\t" << item_id;
    reco::RecoItem item;
    if (!item_getter->GetRecoItem(item_id, &item)) {
      LOG(ERROR) << "cannot get reco item\t" << item_id;
      continue;
    }
    std::vector<uint64> ids;
    ids.push_back(item_id);
    if (FLAGS_calc_sim) {
      std::vector<reco::SimResult> sims;
      sim_getter->GetSimItem(item_id, &sims);
      for (int i = 0; i < (int)sims.size(); ++i) {
        if (sims[i].level < 3) ids.push_back(sims[i].item_id);
      }
    }
    for (int i = 0; i < (int)ids.size(); ++i) {
      bool in_index = true;
      // 判断 item 是否在索引里, 如果不在, 只更新低质字段, 不走 doc server
      reco::sim_item::GetSimFeatureRequest request;
      reco::sim_item::GetSimFeatureResponse response;
      request.mutable_item()->set_item_id(ids[i]);
      request.mutable_item()->set_title(item.title());
      net::rpc::RpcClientController rpc;
      rpc_stub_sim->GetSimFeature(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk
          || !response.success()) {
        LOG(ERROR) << "get sim item info failed. "
                   << " item id: "
                   << ids[i] << ", "
                   << response.Utf8DebugString();
        in_index = false;
      } else {
        in_index = response.success();
      }
      LOG(INFO) << "start change content attr\t" << ids[i] << "\t in index:" << in_index;
      ChangeContentAttr(ids[i], tokens, in_index, rpc_stub);
    }
  }
  delete rpc_group;
  rpc_group = NULL;
  delete rpc_stub;
  rpc_stub = NULL;
  delete sim_getter;
  sim_getter = NULL;
  delete item_getter;
  item_getter = NULL;
  return 0;
}
