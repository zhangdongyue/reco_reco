#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <fstream>
#include <iostream>
#include <utility>

#include "nlp/common/term_container.h"
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "base/file/file_path.h"
#include "base/common/basic_types.h"
#include "base/strings/string_printf.h"
#include "base/hash_function/term.h"
#include "base/common/base.h"
#include "reco/bizc/reco_ner/reco_ner.h"

namespace reco {
namespace bad_item {
// singleton used
class FreqNgramStat {
 public:
  FreqNgramStat();
  ~FreqNgramStat() {}

  bool Initial(const base::FilePath& data_dir);

  int Extract(const base::Slice& sentence,
              std::vector<std::pair<std::string, int> >* ngrams);

 private:
  nlp::segment::Segmenter* segmenter_;
  nlp::postag::PosTagger* pos_tagger_;
  nlp::ner::Ner* ner_;
  reco::ner::RecoNer* reco_ner_;
  std::vector<base::Slice> mix_words_;

  nlp::term::TermContainer term_container_;

  std::unordered_map<uint64, std::string> stopword_;
};

bool FreqNgramStat::Initial(const base::FilePath& dir) {
  std::ifstream fin(dir.Append("stopword.txt").value());
  CHECK(fin.good());
  std::string line;
  std::string normalized_text;
  while (std::getline(fin, line)) {
    nlp::util::NormalizeLineCopy(line, &normalized_text);
    uint64 sign = base::CalcTermSign(normalized_text.data(), normalized_text.size());
    stopword_.insert(std::make_pair(sign, normalized_text));
  }
  return true;
}

FreqNgramStat::FreqNgramStat() {
  segmenter_ = new nlp::segment::Segmenter();
  pos_tagger_ = new nlp::postag::PosTagger();
  ner_ = new nlp::ner::Ner();
  reco_ner_ = new reco::ner::RecoNer();
}

inline bool IsFilteredByPostag(const nlp::term::TermInfo& info) {
  if (info.is_postag(nlp::term::kWhiteSpace)
      || info.is_postag(nlp::term::kPunctuation)
      || info.is_postag(nlp::term::kPreposition)
      || info.is_postag(nlp::term::kAuxiliary)
      || info.is_postag(nlp::term::kExclamation)
      || info.is_postag(nlp::term::kNumber)
      || info.is_postag(nlp::term::kQuantity)) {
    return true;
  }
  return false;
}

int FreqNgramStat::Extract(const base::Slice& sentence,
                           std::vector<std::pair<std::string, int> >* ngrams) {
  // some basic task
  std::string normalized_text;
  nlp::util::NormalizeLineCopy(sentence, &normalized_text);
  term_container_.renew();
  CHECK(segmenter_->SegmentT(normalized_text, &term_container_));
  CHECK(pos_tagger_->PosTagT(normalized_text, &term_container_));
  CHECK(ner_->DetectEntityT(normalized_text, &term_container_));
  nlp::util::ConstructMixTerms(normalized_text, false, &term_container_);

  mix_words_.clear();
  CHECK(reco_ner_->DetectEntity(normalized_text, term_container_, "", &mix_words_, NULL));

  // add stopword
  std::unordered_set<uint64> tmp_stop;
  for (int i = 0; i < term_container_.basic_term_num(); ++i) {
    const nlp::term::TermInfo& term_info = term_container_.basic_term_info(i);
    if (IsFilteredByPostag(term_info)) {
      const base::Slice term = term_container_.basic_term_slice(normalized_text, i);
      uint64 sign = base::CalcTermSign(term.data(), term.size());
      tmp_stop.insert(sign);
    }
  }

  // select words
  std::unordered_set<uint64> words_dict;
  for (size_t i = 0; i < mix_words_.size(); ++i) {
    uint64 sign = base::CalcTermSign(mix_words_[i].data(), mix_words_[i].size());
    if (stopword_.find(sign) != stopword_.end() || tmp_stop.find(sign) != tmp_stop.end()) continue;
    auto it_pair = words_dict.insert(sign);
    if (it_pair.second) {
      ngrams->push_back(std::make_pair(mix_words_[i].as_string(), i));
    }
  }
  return ngrams->size();
}
}
}

DEFINE_string(run_type, "m1", "m1");
DEFINE_string(data_dir, "./data", "data dir");

void mapper1() {
  reco::bad_item::FreqNgramStat ngram_stat;
  ngram_stat.Initial(base::FilePath(FLAGS_data_dir));

  std::string line;
  std::vector<std::pair<std::string, int>> ngrams;
  size_t skip = 3;
  while (std::getline(std::cin, line)) {
    ngrams.clear();
    if (ngram_stat.Extract(line, &ngrams) == 0) {
      continue;
    }


    for (size_t i = 0; i < ngrams.size(); ++i) {
      if (ngrams[i].first.size() > 3) {
        std::cout << ngrams[i].first << "\t1\n";
      }
      for (size_t j = i + 1; j < i + skip && j < ngrams.size(); ++j) {
        std::cout << base::StringPrintf("%s\t%s\t1\n", ngrams[i].first.c_str(), ngrams[j].first.c_str());
      }
    }
  }
}

int main(int argc, char** argv ) {
  base::InitApp(&argc, &argv, "generate freq ngram");
  if (FLAGS_run_type == "m1") {
    mapper1();
  } else {
    LOG(ERROR) << "are u fucking kidding me!" << FLAGS_run_type;
  }
  return 0;
}
