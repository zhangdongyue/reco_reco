#include <iostream>
#include <fstream>
#include <map>
#include <set>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <algorithm>

#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/time/timestamp.h"
#include "base/file/file_path.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "nlp/common/nlp_util.h"
#include "serving_base/mysql_util/db_conn_manager.h"
#include "serving_base/utility/time_helper.h"
#include "reco/ml/feature/global_data/global_data.h"
#include "reco/ml/feature/global_data/dict_loader.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(schema, "reco", "shcema");

DEFINE_string(timestamp_file, "timestamp.txt", "timestammp file");
DEFINE_string(data_dir, "../data", "data dir");

DEFINE_string(end_time, "", "end time for sql");

DEFINE_bool(standalone, false, "");
DEFINE_bool(debug, false, "");
DEFINE_string(input_ids, "fail_image_ids.txt", "");

const char* kAdverRuleFile = "advertorial_rule.txt";
const char* kAdverKeywordFile = "advertorial_keywords.txt";
const char* kAdverImpurityKeywordFile = "advertorial_impurity_keywords.txt";

const std::string kImageLevelKey = "ImageBadLevel-";

enum {
  kAdverPhone = 0,
  kAdverID = 1,
  kTitleCandidate = 2
};

bool inline has_id(const std::string& content, int p, int end, std::string* id) {
  while (p != end) {
    if ((content[p] >= '0' && content[p] <= '9') || content[p] == '-' ||
        (content[p] <= 'z' && content[p] >= 'a') || (content[p] <= 'Z' && content[p] >= 'A') ||
        content[p] == '_' || content[p] == ']' || content[p] == '[') {
      *id += content[p];
      ++p;
    } else {
      if (id->size() >= 7) {
        if (*id == "wechat" || *id == "strong" || *id == "emoji") {
          *id = "";
          ++p;
          continue;
        }
        return true;
      }
      *id = "";
      ++p;
    }
  }
  if (id->size() >= 5) {
    if (*id == "wechat" || *id == "strong" || *id == "emoji") return false;
    return true;
  }
  return false;
}

bool inline has_phone_number(const std::string& content, int p, int end, std::string* number) {
  while (p != end && number->size() < 15) {
    if (content[p] == ' ' || (content[p] >= '0' && content[p] <= '9') || content[p] == '-' ||
        content[p] == '_' || content[p] == ':' || content[p] == ']' || content[p] == '[' ||
        content[p] == '(' || content[p] == ')' || content[p] == '*') {
      *number += content[p];
      ++p;
    } else if (content[p] == '.' || content[p] == '%' || content[p] == 'x') {
      ++p;
      number->clear();
    } else {
      if (number->size() > 6) {
        return true;
      }
      *number = "";
      ++p;
    }
  }
  if (number->size() > 6) {
    return true;
  }
  return false;
}

void MatchAdverRule(const dawgdic::Dictionary& adver_rules_,
                    const std::string& line,
                    std::unordered_set<std::string>* hit_terms) {
  std::vector<std::string> matches;
  std::vector<base::Slice> term_matches;
  std::vector<int> values;
  nlp::util::ForwardMaxMatch(adver_rules_, line, &term_matches, &values);
  for (int i = 0; i < (int)term_matches.size(); ++i) {
    matches.push_back(term_matches[i].as_string());
  }
  int pos = 0;
  std::vector<std::string> features;
  std::string num_or_id;
  for (int i = 0; i < (int)values.size(); ++i) {
    if (values[i] == kTitleCandidate) continue;
    if (values[i] == kAdverPhone) {
      int length = 0;
      if (i > 0) length = matches[i - 1].size();
      pos = line.find(matches[i], pos + length) + matches[i].size();
      int end = pos + 15;
      int start = pos - matches[i].size() - 15;
      if (start < 0) start = 0;
      if (end >= (int)line.size()) end = line.size();
      num_or_id.clear();
      if (has_phone_number(line, start, end, &num_or_id)) {
        hit_terms->insert(base::StringPrintf("%s_hit_number", matches[i].c_str()));
      }
    } else if (values[i] == kAdverID) {
      int length = 0;
      if (i > 0) length = matches[i - 1].size();
      pos = line.find(matches[i], pos + length) + matches[i].size();
      int start = pos - matches[i].size() - 15;
      if (start < 0) start = 0;
      int end = pos + 15;
      if (end >= (int)line.size()) end = line.size();
      num_or_id.clear();
      if (has_id(line, start, end, &num_or_id)) {
        hit_terms->insert(base::StringPrintf("%s_hit_id", matches[i].c_str()));
      }
    } else {
      hit_terms->insert(matches[i]);
    }
  }
}

void DetectLineWithDict(const dawgdic::Dictionary& dict,
                        const std::string& sentence,
                        std::unordered_set<std::string>* hit_terms) {
  std::vector<base::Slice> matches;
  std::vector<int> values;
  if (nlp::util::ForwardMaxMatch(dict, sentence, &matches, &values) == 0) return;
  CHECK_EQ(matches.size(), values.size());
  std::vector<std::pair<base::Slice, int>> sorted_matches;
  for (int i = 0; i < (int)matches.size(); ++i) {
    if (values[i] == 2 || values[i] > 3) {
      hit_terms->insert(matches[i].as_string());
    }
    sorted_matches.push_back(std::make_pair(matches[i], values[i]));
  }
  std::string ngram;
  dawgdic::BaseType index = dict.root();
  for (int i = 0;  i < (int)sorted_matches.size(); ++i) {
    index = dict.root();
    if (!dict.Follow(sorted_matches[i].first.data(), sorted_matches[i].first.size(), &index)) {
      continue;
    }
    for (int j = i + 1; j < (int)sorted_matches.size(); ++j) {
      dawgdic::BaseType index_temp = index;
      if (sorted_matches[j].second == 0 || sorted_matches[j].second == 5) continue;
      if (!dict.Follow(sorted_matches[j].first.data(), sorted_matches[j].first.size(), &index_temp)) {
        continue;
      }
      if (dict.has_value(index_temp) &&
          (dict.value(index_temp) == 2 || dict.value(index_temp) > 3)) {
        if (sentence.find(sorted_matches[j].first.as_string()) - sentence.find(sorted_matches[i].first.as_string()) > 50) continue; // NOLINT
        std::string temp = base::StringPrintf("%s#%s",
                                              sorted_matches[i].first.as_string().c_str(),
                                              sorted_matches[j].first.as_string().c_str());
        hit_terms->insert(temp);
      }
    }
  }
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "offline process images");
  serving_base::mysql_util::DbConnManager::Option option;
  option.host = FLAGS_db_host;
  option.user = FLAGS_db_user;
  option.passwd = FLAGS_db_passwd;
  option.schema = FLAGS_schema;
  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(option);
  reco::redis::RedisCli *redis_cli = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);
  CHECK(redis_cli->GetPool()->IsRun());

  std::string ori_time = "2016-10-27 00:00:00";
  std::string current_time = "";

  base::FilePath base_dir(FLAGS_data_dir);
  std::string line;
  std::ifstream fin(base_dir.Append(FLAGS_timestamp_file).ToString());
  while (std::getline(fin, line)) {
    if (line.size() < 1) continue;
    nlp::util::NormalizeLineCopy(line, &ori_time);
  }
  fin.close();
  if (FLAGS_end_time.empty()) {
    uint64 timestamp = 0;
    CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond, &timestamp));
    CHECK(serving_base::TimeHelper::TimestampToString(timestamp, serving_base::TimeHelper::kSecond, &current_time)); // NOLINT
  } else {
    current_time = FLAGS_end_time;
  }

  std::ofstream fout(base_dir.Append(FLAGS_timestamp_file).ToString());
  fout << current_time << std::endl;
  fout.close();

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverRuleFile,
                            reco::ml::LoadAdverRuleFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverImpurityKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  reco::dm::DictManagerSingleton::instance().LoadAllDicts();

  const dawgdic::Dictionary* adver_rules_ = reco::ml::GlobalDataIns::instance().GetAdverRules().get();
  const dawgdic::Dictionary* adver_keywords_ = reco::ml::GlobalDataIns::instance().GetAdverKeywords().get();
  const dawgdic::Dictionary* adver_impurity_keywords_ = reco::ml::GlobalDataIns::instance().GetAdverImpurityKeywords().get();

  if (FLAGS_standalone) {
    std::string line;
    std::ifstream input_ids(FLAGS_input_ids);
    while (std::getline(input_ids, line)) {
      std::string key = base::StringPrintf("%s%s", kImageLevelKey.c_str(), line.c_str());
      if (!redis_cli->SetEx(key, "adver", 3600 * 24 * 185)) {
        LOG(ERROR) << "fail to set image into redis!\t" << line;
      } else {
        LOG(INFO) << "success to set image into redis!\t" << line;
      }
    }
    input_ids.close();
  } else {
    if (FLAGS_debug) {
      std::ifstream input_ids(FLAGS_input_ids);
      while (std::getline(input_ids, line)) {
        std::string sql = base::StringPrintf("select ocr from tb_image_meta where image_id='%s'", line.c_str()); // NOLINT
        LOG(INFO) << "current sql is:\t" << sql;
        scoped_ptr<sql::ResultSet> res(db_manager->ExecuteQueryWithRetry(sql, 3));
        std::string ocr = "";
        std::unordered_set<std::string> temp;
        std::unordered_map<std::string, std::string> field_values;
        while (res->next()) {
          temp.clear();
          field_values.clear();
          ocr = res->getString("ocr");
          nlp::util::NormalizeLineInPlaceS(&ocr);
          // process ocr
          MatchAdverRule(*adver_rules_, ocr, &temp);
          DetectLineWithDict(*adver_keywords_, ocr, &temp);
          DetectLineWithDict(*adver_impurity_keywords_, ocr, &temp);
          for (auto it = temp.begin(); it != temp.end(); ++it) {
            LOG(INFO) << line << "\thit adver feature:\t" << *it;
          }
        }
      }
    } else {
      std::string sql = base::StringPrintf("select image_id, ocr from tb_image_meta where create_time>='%s' and create_time<='%s';", ori_time.c_str(), current_time.c_str()); // NOLINT
      LOG(INFO) << "current sql is:\t" << sql;

      std::ofstream input_ids(FLAGS_input_ids, std::ios::app);

      scoped_ptr<sql::ResultSet> res(db_manager->ExecuteQueryWithRetry(sql, 3));
      std::string ocr = "";
      uint64 image_id;
      std::string id_str;
      std::string key;
      std::unordered_set<std::string> temp;
      std::unordered_map<std::string, std::string> field_values;
      while (res->next()) {
        int count = 0;
        temp.clear();
        field_values.clear();
        ocr = res->getString("ocr");
        id_str = res->getString("image_id");
        base::StringToUint64(id_str, &image_id);
        nlp::util::NormalizeLineInPlaceS(&ocr);
        // process ocr
        MatchAdverRule(*adver_rules_, ocr, &temp);
        DetectLineWithDict(*adver_keywords_, ocr, &temp);
        DetectLineWithDict(*adver_impurity_keywords_, ocr, &temp);
        if (temp.empty()) continue;
        // record image into redis
        key = base::StringPrintf("%s%lu", kImageLevelKey.c_str(), image_id);
        while (count < 3 && !redis_cli->SetEx(key, "adver", 3600 * 24 * 185)) {
          ++count;
          base::SleepForSeconds(0.1);
        }
        if (count < 3) {
          VLOG(1) << "success to set image into redis!\t" << image_id;
        } else {
          LOG(ERROR) << "fail to set image into redis!\t" << image_id;
          input_ids << image_id << std::endl;
        }
      }
      input_ids.close();
    }
  }
  if (redis_cli) {
    delete redis_cli;
    redis_cli = NULL;
  }
  if (db_manager) {
    delete db_manager;
    db_manager = NULL;
  }
  return 0;
}
