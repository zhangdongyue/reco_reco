#pragma once

#include <cstdatomic>
#include <string>
#include "base/common/basic_types.h"
#include "base/thread/sync.h"
// |GlobalData| 管理所有的静态数据资源, 在策略部分可以被直接使用

namespace serving_base {
template<typename Controller, typename GlobalData>
class DataManager;
}

namespace reco {
namespace bad_item {

// forward declare
class BadItemController;
struct GlobalData;
typedef serving_base::DataManager<BadItemController, GlobalData> BadItemDataManager;
// dicts need to reload, manage them with |DictManager| in |SimItemDataManager|
// static dicts, manage them with |GlobalData|
struct GlobalData {
  thread::Mutex dict_reload_mutex;
  uint64 last_reload_time;
};
}  // namespace item_classify
}  // namespace reco
