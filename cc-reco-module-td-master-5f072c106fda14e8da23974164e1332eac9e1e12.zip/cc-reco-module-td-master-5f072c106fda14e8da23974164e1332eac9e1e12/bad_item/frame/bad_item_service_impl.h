#pragma once
#include "reco/bizc/proto/bad_item.pb.h"

namespace reco {
namespace bad_item {

class BadItemServiceImpl: public BadItemService {
 public:
  BadItemServiceImpl() {}
  ~BadItemServiceImpl() {}

  // 获得 相似的 item
  void DetectBadItem(::stumy::RpcController* controller,
                     const BadItemRequest* request,
                     BadItemResponse* resonse,
                     Closure* done);

  void ReloadDict(::stumy::RpcController* controller,
                  const ReloadDictRequest* request,
                  ReloadDictResponse* resonse,
                  Closure* done);
};
}
}  // namespace reco_leaf
