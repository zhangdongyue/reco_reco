#pragma once

#include <string>
#include <vector>
#include <map>
#include <utility>

#include "reco/bizc/proto/bad_item.pb.h"
#include "serving_base/utility/timer.h"

namespace reco {
namespace bad_item {

class BadItemRequest;
class BadItemResponse;
class RubbishDetector;
class BadItemController {
 public:
  explicit BadItemController();
  ~BadItemController();

  bool Initialize(const BadItemRequest* request,
                  BadItemResponse* response);
  void Start();
  void Done();

 private:
  const BadItemRequest* request_;
  BadItemResponse* response_;

  RubbishDetector* detector_;
  serving_base::Timer timer_;
};
}
}
