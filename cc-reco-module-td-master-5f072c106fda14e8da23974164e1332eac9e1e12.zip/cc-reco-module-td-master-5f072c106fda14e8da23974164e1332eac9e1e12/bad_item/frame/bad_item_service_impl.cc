#include "reco/module/bad_item/frame/bad_item_service_impl.h"

#include <string>
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "serving_base/data_manager/data_manager.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/bad_item.pb.h"
#include "reco/module/bad_item/frame/global_data.h"
#include "reco/module/bad_item/frame/bad_item_controller.h"

namespace reco {
namespace bad_item {

void BadItemServiceImpl::DetectBadItem(::stumy::RpcController* controller,
                                       const BadItemRequest* request,
                                       BadItemResponse* response,
                                       Closure* done) {
  ScopedClosure scoped_done(done);
  response->set_success(false);
  BadItemController* bad_item_controller = BadItemDataManager::GetControllerItem();
  if (!bad_item_controller) {
    BadItemDataManager::ReleaseControllerItem(bad_item_controller);
    LOG(ERROR) << "cannot get new searcher";
    return;
  }
  bad_item_controller->Initialize(request, response);
  bad_item_controller->Start();

  bad_item_controller->Done();

  response->set_success(true);
}

void BadItemServiceImpl::ReloadDict(::stumy::RpcController* controller,
                                    const ReloadDictRequest* request,
                                    ReloadDictResponse* response,
                                    Closure* done) {
  ScopedClosure scoped_done(done);
  std::string timestr;
  CHECK(serving_base::TimeHelper::TimestampToString(
                request->timestamp(), serving_base::TimeHelper::kSecond, &timestr));
  LOG(INFO) << "reload dict in: " << timestr;
  LOG(INFO) << "currently, donot support dict reload " << timestr;
  response->set_success(false);
}
}
}
