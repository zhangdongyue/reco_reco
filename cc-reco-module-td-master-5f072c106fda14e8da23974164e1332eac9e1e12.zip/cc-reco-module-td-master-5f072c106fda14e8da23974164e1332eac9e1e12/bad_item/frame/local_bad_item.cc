#include <vector>
#include <string>
#include <fstream>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "serving_base/utility/signal.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/mysql_util/db_conn_manager.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/item_service/hbase_pool_get_item.h"
#include "reco/module/bad_item/strategy/rubbish_detector.h"

DEFINE_string(hbase_item_table, "tb_reco_item", "hbase table");
DEFINE_int32(thread_num, 8, "thread num for send request");
DEFINE_string(db_host, "tcp://10.3.5.70:3031", "dbhost");
DEFINE_string(db_user, "admin", "db user");
DEFINE_string(db_passwd, "admin", "db passwd");
DEFINE_string(data_dir, "./data", "data dir");
DEFINE_string(start_time, "2014-12-10 00:00:00", "db start time");
DEFINE_string(schema, "reco", "shcema");
DEFINE_int32(cache_size, 20000, "cache size for rubbish item");
DEFINE_string(item_id_file, "item_id.txt", "item id file");

void DetectWorker(thread::BlockingQueue<uint64>* item_id_q,
                  serving_base::mysql_util::DbConnManager* db_manager) {
  reco::bad_item::RubbishDetector* rubbish_detector = new reco::bad_item::RubbishDetector(db_manager);
  reco::ContentAttr content_attr;
  reco::HBasePoolGetItem* hbase_get_item = new reco::HBasePoolGetItem(FLAGS_hbase_item_table, 0);

  std::vector<uint64> item_ids;
  std::vector<reco::RecoItem> reco_items;
  std::vector<bool> rets;
  uint64 item_id;
  int finish = 0;
  int num = 0;
  int fail = 0;
  while (!(item_id_q->Closed() && item_id_q->Empty())) {
    if (item_id_q->Empty()) {
      base::SleepForMilliseconds(100);
      continue;
    }

    if (!item_id_q->Take(&item_id)) break;

    item_ids.push_back(item_id);

    if (item_ids.size() > 32) {
      num += item_ids.size();
      reco_items.clear();
      rets.clear();
      hbase_get_item->GetRecoItems(item_ids, &rets, &reco_items);

      for (size_t i = 0; i < reco_items.size(); ++i) {
        if (!rets[i]) {
          ++fail;
          continue;
        }
        rubbish_detector->Detect(reco_items[i], &content_attr);
        // reco_items[i].mutable_content_attr()->Swap(&content_attr);
        ++finish;
      }
      item_ids.clear();
    }
  }

  if (!item_ids.empty()) {
    num += item_ids.size();
    reco_items.clear();
    rets.clear();
    hbase_get_item->GetRecoItems(item_ids, &rets, &reco_items);

    for (size_t i = 0; i < reco_items.size(); ++i) {
      if (!rets[i]) {
        ++fail;
        continue;
      }

      rubbish_detector->Detect(reco_items[i], &content_attr);
      // reco_items[i].mutable_content_attr()->Swap(&content_attr);
      ++finish;
    }
  }
  delete rubbish_detector;
  LOG(ERROR) << "threadend detect " << finish << " item " << " get " << num << " from item id q" << " fail: " << fail;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "local bad item");
  // readn item id
  serving_base::mysql_util::DbConnManager::Option option;
  option.host = FLAGS_db_host;
  option.user = FLAGS_db_user;
  option.passwd = FLAGS_db_passwd;
  option.schema = FLAGS_schema;
  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(option); // NOLINT
  CHECK(reco::bad_item::RubbishDetector::Initial(FLAGS_data_dir));

  thread::ThreadPool pool(FLAGS_thread_num);
  thread::BlockingQueue<uint64> item_id_q;
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(DetectWorker, &item_id_q, db_manager));
  }

  // reco::bad_item::RubbishDetector* rubbish_detector = new reco::bad_item::RubbishDetector(db_manager);
  // reco::ContentAttr content_attr;
  // reco::HBasePoolGetItem* hbase_get_item = new reco::HBasePoolGetItem(FLAGS_hbase_item_table, 0);

  std::ifstream fin(FLAGS_item_id_file);
  std::string line;
  std::vector<std::string> tokens;
  reco::RecoItem reco_item;
  while (std::getline(fin, line)) {
    tokens.clear();
    if (line.size() < 2) {
      LOG(ERROR) << "erro line: " << line;
      continue;
    }
    base::TrimWhitespaces(&line);
    base::SplitString(line, "\t", &tokens);

    uint64 item_id = 0;
    if (!base::StringToUint64(tokens[0], &item_id)) continue;
    // if (!hbase_get_item->GetRecoItem(item_id, &reco_item)) continue;
    // rubbish_detector->Detect(reco_item, &content_attr);
    // reco_item.mutable_content_attr()->Swap(&content_attr);
    item_id_q.Put(item_id);
  }
  item_id_q.Close();
  pool.JoinAll();
}
