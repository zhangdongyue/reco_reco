#include <iostream>
#include <sstream>

#include "base/common/gflags.h"
#include "base/common/basic_types.h"
#include "base/file/file_path.h"
#include "base/thread/thread.h"
#include "base/thread/blocking_var.h"
#include "net/rpc/rpc.h"
#include "net/counter/export.h"
#include "serving_base/data_manager/server_frame.h"
#include "serving_base/data_manager/data_manager.h"
#include "serving_base/utility/signal.h"

#include "reco/module/bad_item/frame/bad_item_service_impl.h"
#include "reco/module/bad_item/frame/bad_item_controller.h"
#include "reco/module/bad_item/frame/global_data.h"
#include "reco/module/bad_item/strategy/rubbish_detector.h"

DEFINE_int32(port, 20099, "item classify server port");
DEFINE_int32(thread_num, 4, "thread_num");
DEFINE_string(data_dir, "./data", "root data dir for all model");

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "bad item server");

  base::FilePath data_path(FLAGS_data_dir);
  CHECK(reco::bad_item::RubbishDetector::Initial(data_path));
  reco::bad_item::GlobalData global_data;

  serving_base::DataManangerConfig config;
  config.controller_item_num = FLAGS_thread_num;
  reco::bad_item::BadItemDataManager::Initialize(config, &global_data);

  reco::bad_item::BadItemServiceImpl service;
  serving_base::ServerFrameConfig server_frame_config;
  server_frame_config.rpc_threads_num = FLAGS_thread_num;
  server_frame_config.rpc_server_port = FLAGS_port;
  server_frame_config.service = &service;
  server_frame_config.dict_manager = reco::bad_item::BadItemDataManager::GetDictManager();
  serving_base::ServerFrame server_frame(server_frame_config);

  server_frame.Start();
  LOG(INFO) << "bad item server start";

  net::counter::HttpCounterExport();

  serving_base::SignalCatcher::Initialize();

  serving_base::SignalCatcher::WaitForSignal();
  server_frame.Stop();
  LOG(INFO) << "server frame stop";

  reco::bad_item::BadItemDataManager::Release();
  LOG(INFO) << "data manager release";

  std::cout << "bad item server safe quit" << std::endl;
  return 0;
}
