#include "reco/module/bad_item/frame/bad_item_controller.h"

#include <utility>
#include <map>
#include <unordered_map>
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "reco/module/bad_item/strategy/rubbish_detector.h"
#include "ads_index/api/public.h"
#include "serving_base/data_manager/data_manager.h"
#include "reco/module/bad_item/frame/global_data.h"

namespace reco {
namespace bad_item {
BadItemController::BadItemController() {
  request_ = NULL;
  response_ = NULL;
  detector_ = new RubbishDetector();
}

BadItemController::~BadItemController() {
  delete detector_;
}

bool BadItemController::Initialize(const BadItemRequest* request, BadItemResponse* response) {
  request_ = request;
  response_ = response;
  response_->set_success(false);
  response_->set_item_id(0);
  return true;
}

void BadItemController::Start() {
  timer_.Start();
  std::vector<int> results;
  response_->Clear();
  if (request_->has_reco_item()) {
    detector_->Detect(request_->reco_item(), &results);
    response_->set_item_id(request_->reco_item().identity().item_id());
  } else {
    LOG(ERROR) << "reco item is the must one, no reco item in request!";
    return;
  }

  reco::ContentAttr::ContentAttrLevel attr_values[] = { reco::ContentAttr::kSureNo,
    reco::ContentAttr::kSuspect, reco::ContentAttr::kSureYes };
  CHECK_EQ((int)results.size(), 8);
  response_->set_success(true);
  reco::ContentAttr* content_attr = response_->mutable_content_attr();
  content_attr->set_erro_title(attr_values[results[0]]);
  content_attr->set_advertorial(attr_values[results[1]]);
  content_attr->set_short_content(attr_values[results[2]]);
  content_attr->set_dedup_paragraph(attr_values[results[3]]);
  content_attr->set_dirty(attr_values[results[4]]);
  content_attr->set_politics(attr_values[results[5]]);
  content_attr->set_bluffing_title(attr_values[results[6]]);
  content_attr->set_negative(attr_values[results[7]]);
  LOG(INFO) << base::StringPrintf("etitle=%d, ad=%d, short=%d, dedup=%d, dirty=%d, politics=%d, bluffin=%d, negative=%d", // NOLINT
                                  content_attr->erro_title(), content_attr->advertorial(),
                                  content_attr->short_content(), content_attr->dedup_paragraph(),
                                  content_attr->dirty(), content_attr->politics(),
                                  content_attr->bluffing_title(), content_attr->negative());
}

void BadItemController::Done() {
  double total_time = timer_.Stop();
  // success
  if (response_->success()) {
    VLOG(2)<< "total_time=" << total_time;
  } else {
    if (request_->text().size() > 0) {
      VLOG(1) << "get bad item error! item=" << request_->text() << " total_time=" << total_time;
    } else {
      VLOG(1) << "get bad item error! item_id=" << request_->reco_item().identity().item_id() << " total_time=" << total_time;  // NOLINT
    }
  }
  BadItemDataManager::ReleaseControllerItem(this);
}
}
}
