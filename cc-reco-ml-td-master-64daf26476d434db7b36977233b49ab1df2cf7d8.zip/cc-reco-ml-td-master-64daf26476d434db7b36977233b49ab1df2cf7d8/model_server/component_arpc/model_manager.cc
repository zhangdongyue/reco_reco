#include "reco/ml/model_server/component_arpc/model_manager.h"

#include "base/file/file_util.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"

#include "serving_base/utility/timer.h"
#include "reco/ml/model/model.h"
#include "reco/ml/model/factory.h"
#include "reco/base/xml/xml.h"


namespace reco {
namespace model_server {

DEFINE_int32(init_thread_num, 4, "init_thread_num");

thread::Mutex ModelManager::mutex_;
std::unordered_map<std::string, reco::ml::ModelPtr> ModelManager::model_map_;
std::unordered_map<std::string, std::string> ModelManager::model_file_map_;
std::atomic_int ModelManager::unfinished_model_num_(0);

void ModelManager::AddModelUnit(std::string model_file) {
  CHECK(AddModel(model_file));
  unfinished_model_num_--;
}

bool ModelManager::Initialize(const std::string &root_config_file, thread::ThreadPool* pool) {
  serving_base::Timer timer;
  timer.Start();

  std::string config_content;
  if (!base::file_util::ReadFileToString(root_config_file, &config_content)) {
    LOG(ERROR) << "Failed to read root config file:" << root_config_file;
    return false;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(config_content, &context)) {
    LOG(ERROR) << "Failed to parse root config xml:" << config_content;
    return false;
  }

  util::xml::XPathContext xpathcontext;
  util::xml::XPath xpath("/config/models/model");
  context.execute(xpath, &xpathcontext);
  const std::vector<util::xml::Node*>& res = xpathcontext.GetResult();
  unfinished_model_num_ = res.size();
  for (uint32 i = 0; i < res.size(); i++) {
    if (res[i]->type() != util::xml::Node::kElementNode) {
      LOG(ERROR) << "Error model node format!"
                 << " model_index:" << i
                 << " node_type:" << res[i]->type();
      return false;
    }

    std::string model_config_path = "";
    if (!reco::xml::GetXPathString("/config_path", res[i]->ToElement(), &model_config_path)) {
      LOG(ERROR) << "Failed to get config_file_path for model!"
                 << " model_index:" << i;
      return false;
    }

    ::Closure* load_task = ::NewCallback(&(ModelManager::AddModelUnit), model_config_path);
    pool->AddTask(load_task);
  }

  while (unfinished_model_num_ > 0) {
    base::SleepForMilliseconds(10);
  }

  LOG(INFO) << "ModelManager::Initialize success"
            << " cost " << timer.Stop() << " us";
  return true;
}

void ModelManager::Release() {
  thread::AutoLock lock(&mutex_);
  model_map_.clear();
  model_file_map_.clear();
}

std::vector<reco::ml::ModelPtr> ModelManager::GetAllModel() {
  std::vector<reco::ml::ModelPtr> model_list;

  for (auto it = model_map_.begin(); it != model_map_.end(); it++) {
    model_list.push_back(it->second);
  }

  return model_list;
}

reco::ml::ModelPtr ModelManager::GetModelByName(const std::string &model_name) {
  if (model_map_.count(model_name) > 0) {
    return model_map_[model_name];
  }

  return reco::ml::ModelPtr();
}

bool ModelManager::AddModel(const std::string &model_file) {
  serving_base::Timer timer;
  timer.Start();
  std::string model_type = reco::ml::Model::GetModelTypeFromConfig(model_file);
  reco::ml::ModelPtr model(reco::ml::ModelFactory::CreateModel(model_type));
  if (model.get() == NULL || !model->Initialize(model_file)) {
    LOG(ERROR) << "Failed to add model! model_file:" << model_file
               << " model_type:" << model_type;
    return false;
  }

  {
    thread::AutoLock lock(&mutex_);
    std::string model_name = model->name();
    model_map_[model_name] = model;
    model_file_map_[model_name] = model_file;
  }
  LOG(INFO) << "AddModel " << model->name() << " success"
            << " cost " << timer.Stop() << " us";

  return true;
}

bool ModelManager::ReloadModel(const std::string &name) {
  serving_base::Timer timer;
  timer.Start();
  if (model_file_map_.count(name) <= 0) {
    LOG(ERROR) << "model not exist! name:" << name;
    return false;
  }

  std::string model_file = model_file_map_[name];
  std::string model_type = reco::ml::Model::GetModelTypeFromConfig(model_file);
  reco::ml::ModelPtr model(reco::ml::ModelFactory::CreateModel(model_type));
  if (model.get() == NULL || !model->Initialize(model_file)) {
    LOG(ERROR) << "Failed to add model! model_file:" << model_file
               << " model_type:" << model_type;
    return false;
  }

  std::string model_name = model->name();
  if (name != model_name) {
    LOG(ERROR) << "reload model error! name:" << name
               << " reason: model name changed after reload!";
    return false;
  }

  model_map_[model_name] = model;
  LOG(INFO) << "ReloadModel " << model->name() << " success"
            << " cost " << timer.Stop() << " us";
  return true;
}
}  // namespaec model_server
}  // namespace reco
