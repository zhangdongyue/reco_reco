#include "reco/ml/model_server/component_arpc/model_manager_server.h"

#include "base/common/base.h"
#include "base/strings/string_number_conversions.h"

#include "arpc/RPCInterface.h"
#include "arpc/ANetRPCServer.h"
#include "arpc/CommonMacros.h"

//#include "net/rpc/rpc.h"

#include "reco/ml/model_server/component_arpc/model_manager.h"
#include "reco/ml/model_server/component_arpc/model_manager_service.h"

using namespace arpc;

DEFINE_string(root_config_file, "../config/model/config", "root model config");
DEFINE_int32(reload_model_thread_num, 2, "reload_model_thread_num");

namespace reco {
namespace model_server {

ModelManagerServer::ModelManagerServer(int port, thread::ThreadPool* init_pool) {
  port_ =  port;
  server_ = NULL;

  CHECK(reco::model_server::ModelManager::Initialize(FLAGS_root_config_file, init_pool))
      << "Initialize ModelManager error!";

  service_ = new ModelManagerServiceImpl();
  CHECK(service_ != NULL);
}

ModelManagerServer::~ModelManagerServer() {
  Stop();
  delete service_;
  reco::model_server::ModelManager::Release();
}

void ModelManagerServer::Start() {
 if (server_ != NULL) return;

  // start server
  server_ = new arpc::ANetRPCServer(NULL, FLAGS_reload_model_thread_num);
  server_->StartPrivateTransport();
  server_->RegisterService(new ModelManagerServiceImpl);
  std::string spec = "tcp:0.0.0.0:" + base::IntToString(port_);
  LOG(INFO) << "listen:" << spec;
  if (!server_->Listen(spec)) {
      LOG(ERROR) << "listen fail:" << spec;
      return;
  }
  LOG(INFO) << "start video server succ.";
}

void ModelManagerServer::Stop() {
  if (server_ == NULL) return;

  server_->Close();
  server_->StopPrivateTransport();
  delete server_;
  server_ = NULL;
}
}
}
