#pragma once

#include <unordered_map>
#include <string>

#include "base/common/base.h"
#include "base/thread/sync.h"
#include "reco/ml/model_server/component_arpc/model_manager.pb.h"

namespace reco {
namespace model_server {

class ModelManagerServiceImpl : public ModelManagerService {
 public:
  ModelManagerServiceImpl() { }
  ~ModelManagerServiceImpl() { }

  virtual void ExcuteCommand(::google::protobuf::RpcController* controller,
                       const ::reco::model_server::CommandRequest* request,
                       ::reco::model_server::CommandResponse* response,
                       ::google::protobuf::Closure* done);
  
 private:
  thread::Mutex mutex_;
  std::unordered_map<std::string, bool> loading_model_map_;
 private:
  DISALLOW_COPY_AND_ASSIGN(ModelManagerServiceImpl);
};
}
}
