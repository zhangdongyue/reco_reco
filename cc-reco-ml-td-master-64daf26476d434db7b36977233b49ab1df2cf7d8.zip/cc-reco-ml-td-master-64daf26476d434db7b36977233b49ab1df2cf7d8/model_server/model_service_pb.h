#if __cplusplus < 201103L
#include "reco/ml/model_server/api/model_service.pb.h"
#else
#include "reco/ml/model_server/api_arpc/model_service.pb.h"
#endif
