#pragma once
#include <vector>

#include "base/common/basic_types.h"
#include "base/strings/string_number_conversions.h"
#include "base/time/timestamp.h"
#include "base/common/sleep.h"
#include "base/strings/string_printf.h"
#include "base/thread/blocking_var.h"
#include "serving_base/utility/timer.h"
#include "net/rpc/rpc.h"
#include "reco/ml/model_server/perf/define.h"
#include "reco/ml/model_server/api/model_service.pb.h"

DEFINE_string(model_server_ip, "127.0.0.1", "server ip");
DEFINE_int32(model_server_port, 20004, "server port");
DEFINE_int32(time_slice, 1000, "time slice in ms");
DEFINE_int32(min_num_in_slice, 1, "min num sample in slice");

DEFINE_int32(qps, 1000, "qps");
DEFINE_int64(total_request, 100000, "total request");

namespace reco {
namespace model_server {
class PressWorker {
 private:
  atomic_bool running_;
  int qps_;
  int64 total_request_;

  thread::BlockingQueue<ResponseDumpInfo*>* response_queue_;
  thread::BlockingVar<int>* remain_num_;
  int queue_buff_size_;

  // buffer for all data
  const std::vector<PackagedRequest>* request_pool_;

  base::PseudoRandom rand_;

 public:
  bool running() {
    return running_;
  }

  PressWorker(const std::vector<PackagedRequest>& request_pool,
              thread::BlockingQueue<ResponseDumpInfo*>* response_queue,
              thread::BlockingVar<int>* remain_num) {
    request_pool_ = &request_pool;

    running_ = true;
    qps_ = FLAGS_qps;
    total_request_ = FLAGS_total_request;
    queue_buff_size_ = qps_ * 1000;

    response_queue_ = response_queue;
    remain_num_ = remain_num;
  }

  void run(int thread_id) {
    running_ = true;
    float coeff = qps_ / 1000.0;
    float p_gain = coeff * FLAGS_time_slice;  // send num in timeslice
    if (p_gain < FLAGS_min_num_in_slice) {
      p_gain = FLAGS_min_num_in_slice;
    }
    int time_slice = (int) (p_gain / coeff);  // in ms
    int grain_num = (int) p_gain;  // num in slice

    LOG(INFO) << "Thread " << thread_id << " start.";

    int64 very_start = base::GetTimestamp() / 1000;
    int64 send_num = 0;
    int64 start = 0;
    int64 tick = -1;
    bool from_begin = true;
    int total_send = 0;
    int total_err = 0;

    net::rpc::RpcClientChannel channel(FLAGS_model_server_ip, FLAGS_model_server_port);
    CHECK(channel.Connect());

    ModelService::Stub stub(&channel);
    PackagedResponse response;

    while (running_) {
      if (send_num >= grain_num) {
        tick = base::GetTimestamp() / 1000;
        int64 time_consume = tick - start;
        if (time_consume <= time_slice) {
          base::SleepForMilliseconds(time_slice - time_consume);
        }
        from_begin = true;
        send_num = 0;
      }

      if (from_begin) {
        start = base::GetTimestamp() / 1000;
        from_begin = false;
      }

      ResponseDumpInfo* dumpInfo = new ResponseDumpInfo();
      dumpInfo->send_timestamp = base::GetTimestamp() / 1000;

      net::rpc::RpcClientController rpc;

      int index = rand_.GetInt(0, (int)request_pool_->size() - 1);
      const PackagedRequest& request = request_pool_->at(index);

      stub.PackagedSearch(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk || response.code() != 0) {
        LOG(ERROR) << "erro in search user: " << rpc.error_text() << " " << response.code();
        ++total_err;
        continue;
      }

      dumpInfo->response_timestamp = base::GetTimestamp() / 1000;
      dumpInfo->body_size = response.ByteSize();
      dumpInfo->status = 200;

      if (response_queue_->Size() > queue_buff_size_) {
        LOG(INFO) << "response queue is full, sleep for 10 ms";
        base::SleepForMilliseconds(10);
      }

      // should alway be success to add
      response_queue_->Put(dumpInfo);
      ++total_send;
      ++send_num;
      if (total_send > total_request_) {
        running_ = false;
        break;
      }
    }

    int remain = remain_num_->Take() - 1;
    if (remain <= 0) {
      response_queue_->Close();
    } else {
      CHECK(remain_num_->TryPut(remain));
    }

    int64 final_end = base::GetTimestamp();

    LOG(INFO) << base::StringPrintf("Thread %d end, total send: %d total err: %d, total consume: %ld ms",
                                    thread_id, total_send, total_err, (final_end - very_start) / 1000);
  }
};
}
}

