#include <fstream>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "base/common/sleep.h"

#include "reco/ml/model_server/perf/press_worker.h"
#include "reco/ml/model_server/perf/press_responser.h"
#include "reco/ml/model_server/perf/define.h"

DEFINE_int32(thread_num, 16, "thread num for send request");
DEFINE_string(model_type, "fm", "fm, lr, or wd");
DEFINE_string(model_name, "text_fm", "fm, lr, or wd");
DEFINE_string(input_file, "ins.txt", "ins file");
DEFINE_string(static_fld_file, "static_fld.txt", "ins file");
DEFINE_int32(batch_num, 100, "only use for wd");

using reco::model_server::PackagedRequest;
void GenerateWDRequest(std::vector<reco::model_server::PackagedRequest>* request_pool) {
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_input_file), &lines));
 
  reco::model_server::PackagedRequest packaged_request;
  
  reco::model_server::OneRequest* one_request = NULL;
  reco::model_server::WideDeepRequest* wide_deep_request = NULL;
  reco::model_server::Features* ins = NULL;
  uint32 last_ins_start = 0;
  int ins_num = 0;

  std::unordered_set<std::string> skip_set;
  {
    std::vector<std::string> lines;
    CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_static_fld_file), &lines)) << FLAGS_static_fld_file;  // NOLINT
    for (size_t i = 0; i < lines.size(); ++i) {
      skip_set.insert(lines[i]);
    }
  }
  LOG(INFO) << "skip: " << skip_set.size();
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].size() < 3) continue;
    base::TrimWhitespaces(&lines[i]);

    if (lines[i].substr(0, 7) == "user_id") {
      if (packaged_request.request_items_size() > 0) {
        request_pool->push_back(packaged_request);
      }
      if (ins_num % FLAGS_batch_num == 0 || ins_num == 1) {
        packaged_request.Clear();
        one_request = packaged_request.add_request_items();
        one_request->set_user_id(base::ParseUint64OrDie(lines[i].substr(10)));
      }
    }

    if (lines[i][0] == '[' && lines[i][lines[i].size() - 1] == ']') {
      ++ins_num;
      if (last_ins_start < i) {
        wide_deep_request = one_request->add_wide_deep_requests();
        wide_deep_request->mutable_model_info()->set_model_name(FLAGS_model_name);
        ins = wide_deep_request->add_request_items();
        uint64 item_id = 0;
        for (uint32 j = last_ins_start + 1; j < i; ++j) {
          size_t pos = lines[j].find("=0:");
          if (pos == std::string::npos) {
            continue;
          }

          if (skip_set.find(lines[j].substr(0, pos)) == skip_set.end()) {
            reco::model_server::FeatureInfo* fea = ins->add_feature_info();
            fea->set_literal(lines[j].substr(0, pos));
            fea->set_text(lines[j].substr(pos + 3));
          }

          if (lines[j].find("item_id") != std::string::npos && lines[j].size() > 10) {
            item_id = base::ParseUint64OrDie(lines[j].substr(10));
          }
        }
        wide_deep_request->set_sid(item_id);
      }
      last_ins_start = i;
    }
  }

  if (packaged_request.request_items_size() > 0) {
    request_pool->push_back(packaged_request);
  }

  LOG(INFO) << "finish reading remain " << request_pool->size();
}

void GenerateFMRequest(const std::vector<std::string>& lines,
                       std::vector<reco::model_server::PackagedRequest>* request_pool) {
  reco::model_server::PackagedRequest request;

  std::vector<std::string> tokens;
  for (int i = 0; i < (int)lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t ", &tokens);
    if (tokens.size() < 3u) continue;
    request.Clear();
    reco::model_server::OneRequest* one_request = request.add_request_items();
    one_request->set_user_id(i);

    reco::model_server::FMRequest* fm_request = one_request->add_fm_requests();
    fm_request->mutable_model_info()->set_model_name(FLAGS_model_name);
    reco::model_server::Features* ins = fm_request->add_request_items();
    std::unordered_set<uint64> dict;

    if (tokens.size() < 2) continue;

    double label = base::ParseDoubleOrDie(tokens[1]);
    if (label > 0) label = 1.0;

    for (size_t i = 2; i < tokens.size(); ++i) {
      size_t pos = tokens[i].find(":");
      if (pos == std::string::npos) continue;

      uint64 sign = base::ParseUint64OrDie(tokens[i].substr(0, pos));

      if (dict.find(sign) != dict.end()) continue;
      dict.insert(sign);

      reco::model_server::FeatureInfo* fea = ins->add_feature_info();
      fea->set_sign(sign);
      VLOG(1) << sign << " " << tokens[i];
    }
    request_pool->push_back(request);
  }
}

static bool ConstructAllRequest(const std::string& input_file,
                                const std::string& model_type,
                                std::vector<reco::model_server::PackagedRequest>* request_pool) {
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(input_file, &lines);
  request_pool->reserve(lines.size());

  CHECK(!lines.empty());
  std::vector<std::string> tokens;
  PackagedRequest request;
  if (model_type == "fm") {
    GenerateFMRequest(lines, request_pool);
  } else if (model_type == "lr") {
  } else if (model_type == "wd") {
    GenerateWDRequest(request_pool);
  }

  LOG(INFO) << "total request: " << request_pool->size();
  return request_pool->size() > 10;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "press tool");
  using namespace reco;  // NOLINT

  int thread_num_ = FLAGS_thread_num;

  thread::BlockingQueue<ResponseDumpInfo*> response_queue;

  reco::model_server::PressResponser responser(&response_queue);

  std::vector<reco::model_server::PackagedRequest> request_pool;
  CHECK(ConstructAllRequest(FLAGS_input_file, FLAGS_model_type, &request_pool));

  std::vector<reco::model_server::PressWorker*> workers;

  thread::ThreadPool pool(thread_num_ + 3);

  thread::BlockingVar<int> remain_num;
  remain_num.TryPut(thread_num_);
  for (int i = 0; i < thread_num_; ++i) {
    workers.push_back(new reco::model_server::PressWorker(request_pool, &response_queue, &remain_num));
    pool.AddTask(::NewCallback(workers.back(), &reco::model_server::PressWorker::run, i));
  }

  pool.AddTask(::NewCallback(&responser, &reco::model_server::PressResponser::run));

  int total_workers = thread_num_;
  while (total_workers > 0) {
    base::SleepForMilliseconds(200);
    total_workers = 0;
    for (int i = 0; i < (int)workers.size(); ++i) {
      if (workers[i]->running()) {
        ++total_workers;
      }
    }
  }
  response_queue.Close();
  responser.stop();

  pool.JoinAll();
  return 0;
}
