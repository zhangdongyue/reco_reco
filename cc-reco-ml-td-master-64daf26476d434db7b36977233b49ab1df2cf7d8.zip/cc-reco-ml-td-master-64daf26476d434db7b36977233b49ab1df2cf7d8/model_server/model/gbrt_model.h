#pragma once

#include <string>

#include "wolong/proto/gbrt_feature.pb.h"
#include "wolong/model_server/model/model.h"
#include "wolong/model_server/api/model_service.pb.h"
#include "wolong/model_server/strategy/feature_bucketing/gbrt_feature.h"

namespace wolong {
namespace model_server {

class GbrtModel : public Model {
 public:
  GbrtModel() : Model() {}
  virtual ~GbrtModel() {}
  virtual bool Initialize(const std::string& config_file);

  int32 Process(const wolong::GbrtReqFeature& item,
                wolong::GbrtResFeature* fea,
                wolong::GbrtStat* stat);
 private:
  std::string dict_dir_;
  ::GBRTFeature gbrt_feature_;
 private:
  DISALLOW_COPY_AND_ASSIGN(GbrtModel);
};
}  // namespace model_server
}  // namespace wolong
