#pragma once

#include <math.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "util/xml/xml.h"

#include "boost/shared_ptr.hpp"

namespace reco {
namespace ml {

class Model {
 public:
  Model() {}
  virtual ~Model() {
    LOG(INFO) << "Release Model! type:" << type_
              << " name:" << name_;
  }
  static std::string GetModelTypeFromConfig(const std::string &config_file);

  virtual bool Initialize(const std::string &config_file);

  bool enable() { return enable_; }
  std::string type() { return type_; }
  std::string name() { return name_; }

 protected:
  std::string config_file_;
  bool enable_;
  std::string type_;
  std::string name_;
 private:
  DISALLOW_COPY_AND_ASSIGN(Model);
};
typedef boost::shared_ptr<Model> ModelPtr;
inline double LRScore(double sum_weight) { return 1.0 / (1 + exp(-sum_weight)); }
}  // namespace model_server
}  // namespace wolong
