#include <string>
#include <algorithm>
#include <utility>
#include <limits>

#include "wolong/model_server/model/dnn_model.h"

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/file/file_util.h"
#include "vertical/framework/util/util.h"
#include "vertical/framework/util/xml.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"

namespace wolong {
namespace model_server {

bool DNNModel::Initialize(const std::string &config_file) {
  if (!Model::Initialize(config_file)) {
    LOG(ERROR) << "Model::Initialize error!";
    return false;
  }

  if (!enable_) {
    return true;
  }

  std::string content;
  if (!base::file_util::ReadFileToString(config_file, &content)) {
    LOG(ERROR) << "Failed to open model config file: " << config_file;
    return false;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(content, &context)) {
    LOG(ERROR) << "Failed to parse model config xml: " << content;
    return false;
  }

  if (!vsf::xml::GetXPathString(&context, "/config/dict_path_base", &dict_path_base_)) {
    LOG(ERROR) << "Error: read dict_path_base: " << dict_path_base_;
    return false;
  }
  if (dict_path_base_.empty()) {
    LOG(ERROR) << "Error: dict_path_base is empty.";
    return false;
  }

  if (!vsf::xml::GetXPathString(&context, "/config/cvm_dict_name", &cvm_dict_name_)) {
    LOG(ERROR) << "Error: read cvm_dict_name";
    return false;
  }
  if (cvm_dict_name_.empty()) {
    LOG(ERROR) << "Error: cvm_dict_name can not be empty.";
    return false;
  }

  if (!vsf::xml::GetXPathString(&context, "/config/dnn_model_name", &dnn_model_name_)) {
    LOG(ERROR) << "Error: read dnn_model_name";
    return false;
  }
  if (dnn_model_name_.empty()) {
    LOG(ERROR) << "Error: dnn_model_name can not be empty.";
    return false;
  }

  if (!vsf::xml::GetXPathString(&context, "/config/dnn_model_config_name", &dnn_model_config_name_)) {
    LOG(ERROR) << "Error: read dnn_model_config_name";
    return false;
  }
  if (dnn_model_config_name_.empty()) {
    LOG(ERROR) << "Error: dnn_model_config_name can not be empty.";
    return false;
  }

  if (!Load()) {
    LOG(ERROR) << "DNN Model Load error!";
    return false;
  }

  return true;
}

bool DNNModel::Load() {
  // 清理工作
  std::vector<NetworkLayer>().swap(layers_);
  layers_.clear();

  std::vector<uint32>().swap(layer_sizes_);
  layer_sizes_.clear();

  std::map<uint32, NormElement>().swap(map_norm_);
  map_norm_.clear();

  std::map<std::string, double>().swap(conf_dict_);
  conf_dict_.clear();

  if (map_cvm_) {
    delete map_cvm_;
    map_cvm_ = NULL;
  }
  if (map_cvm_data_) {
    delete map_cvm_data_;
    map_cvm_data_ = NULL;
  }

  std::string dnn_model_path = dict_path_base_ + dnn_model_name_;
  if (!LoadModel(dnn_model_path)) {
    LOG(ERROR) << "Load DNN Model " << dnn_model_path << " failed.";
    return false;
  } else {
    LOG(WARNING) << "Load DNN Model " << dnn_model_path << " success.";
  }

  std::string cvm_dict_path = dict_path_base_ + cvm_dict_name_;
  if (!LoadCVM(cvm_dict_path)) {
    LOG(ERROR) << "Load DNN CVM " << cvm_dict_path << " failed.";
    return false;
  } else {
    LOG(WARNING) << "Load DNN CVM " << cvm_dict_path << " success.";
  }

  std::string dnn_model_config_path = dict_path_base_ + dnn_model_config_name_;
  if (!LoadModelConfig(dnn_model_config_path)) {
    LOG(ERROR) << "Load DNN CONFIG " << dnn_model_config_path << " failed.";
    return false;
  } else {
    LOG(WARNING) << "Load DNN CONFIG " << dnn_model_config_path << " success.";
  }
  //
  //
  return true;
}

// important!
// DNN Model 文件格式发生了重大变化，由二进制文件换为明文，同时将模型参数与
// 归一化词表整合到一个文件中，上半部分为模型参数，下半部分为归一化参数，模
// 型文件格式必须离线确保正确，否则线上程序做正确性检查会发生 core。
// 参数表由[MODEL]..[END]包围
bool DNNModel::LoadModel(const std::string& filename) {
  // duplicated cleaning
  layers_.clear();
  layer_sizes_.clear();
  map_norm_.clear();

  std::ifstream in_file(filename);
  if (!in_file.good()) {
    LOG(ERROR) << "Open file " << filename << " error.";
    return false;
  }
  std::string line;
  // 三个布尔变量 用以记录各部分加载是否成功
  bool layersize_prepared = false;
  bool model_prepared = false;
  bool norm_prepared = false;

  while (std::getline(in_file, line)) {
    if (base::StartsWith(line, "#", true)) continue;
    if (line == "[MODEL]") {
      if (!layersize_prepared) {
        LOG(ERROR) << "DNNModel load error: Must load LAYERSIZE before loading MODEL.";
        return false;
      }
      model_prepared = LoadModelParams(&in_file);
      if (!model_prepared) {
        LOG(ERROR) << "DNNModel Load error: Loading Model parameters failed.";
        return false;
      }
    } else if (line == "[NORM]") {
      if (!layersize_prepared) {
        LOG(ERROR) << "DNNModel load error: Must load LAYERSIZE before loading NORM.";
        return false;
      }
      norm_prepared = LoadNormParams(&in_file);
      if (!norm_prepared) {
        LOG(ERROR) << "DNNModel Load error: Loading Norm parameters failed.";
        return false;
      } else {
        LOG(WARNING) << "DNNModel Load norm dict success, size:" << map_norm_.size();
      }
    } else if (line == "[LAYERSIZE]") {
      layersize_prepared = LoadLayerSize(&in_file);
      if (!layersize_prepared) {
        LOG(ERROR) << "DNNModel Load error: layer size initial failed.";
        return false;
      }
    }
  }
  // double check
  if (layersize_prepared & norm_prepared & model_prepared)
    return true;
  else
    return false;
}

// auxilary functions
// reading model params into DNN MODEL
// 从这里开始会进行严格的格式检查
bool DNNModel::LoadModelParams(std::ifstream *ifs) {
  // 参数表从输入层一直到顶层对应原来的 param 表
  // 格式必须严格保证，不允许空行出现，这部分参数格式必须做严格的离线检查
  uint32 total_param_num = 0;
  uint32 param_num_read = 0;
  for (uint32 index = 0; index < layer_sizes_.size()-1; index++) {
    std::string line;
    uint32 in_num = layer_sizes_[index];
    uint32 out_num = layer_sizes_[index+1];
    total_param_num += in_num * out_num + out_num;
    // initial Layer
    NetworkLayer layer;
    // 最后一层使用 sigmoid，其他使用 relu
    // layer_sizes_ 的 size 比 layers_ 多 1，因为包括了输入输出
    if (index != layer_sizes_.size()-2) {
      layer = NetworkLayer(in_num, out_num, true, index, "relu");
    } else {
      layer = NetworkLayer(in_num, out_num, true, index, "sigmoid");
    }
    // 开始给 layer 中的 w 和 b 赋值
    // 先读取一行 包含了行数列数信息，解析行列数值并且加以格式检查
    if (!std::getline(*ifs, line)) {
      LOG(ERROR) << "DNNModel::LoadModelParams There is no line to be read.";
      return false;
    }
    std::vector<std::string> fields;
    base::SplitStringWithOptions(line, " ", true, true, &fields);
    if (fields.size() != 2) {
      LOG(ERROR) << "DNNModel::LoadModelParams Matrix indicator wrong: " << line;
      return false;
    }
    uint32 rows, cols;
    if (!base::StringToUint(fields[0], &rows)) {
      LOG(ERROR) << "DNNModel::LoadModelParams Error format: " << fields[0];
      return false;
    }
    if (!base::StringToUint(fields[1], &cols)) {
      LOG(ERROR) << "DNNModel::LoadModelParams Error format: " << fields[1];
      return false;
    }
    // 严格检查 行列数是否对应
    if (rows - 1 != in_num || cols != out_num) {
      LOG(ERROR) << "DNNModel::LoadModelParams Weights Matrix's columns and rows number:" << rows << " "
          << cols << " are not equal to" << "layer_sizes' predefined number : " << in_num << " " << out_num;
      return false;
    }
    // 开始读取矩阵，沿用之前 W 与 b 分拆做法，更容易理解，参数表中最后一行是 bias
    for (uint32 i = 0; i < rows-1; i++) {
      std::string param_str;
      if (!std::getline(*ifs, param_str)) {
        LOG(ERROR) << "DNNModel::LoadModelParams Reading file error.";
        return false;
      }
      std::vector<std::string> tokens;
      base::SplitStringWithOptions(param_str, " ", true, true, &tokens);
      if (tokens.size() != cols) {
        LOG(ERROR) << "DNNModel::LoadModelParams This row has no enough paramaters: " << tokens.size()
            << " Should be: " << cols;
        return false;
      }
      for (uint32 j = 0; j < cols; j++) {
        double value;
        if (!base::StringToDouble(tokens[j], &value)) {
          LOG(ERROR) << "DNNModel::LoadModelParams Invalid number conversion." << tokens[j];
          return false;
        }
        layer.W(j, i) = value;
        param_num_read++;
      }
    }
    // 读取 bias 行，最后一行
    std::string bias_str;
    if (!std::getline(*ifs, bias_str)) {
      LOG(ERROR) << "DNNModel::LoadModelParams Reading file error.";
      return false;
    }
    std::vector<std::string> bias_tokens;
    base::SplitStringWithOptions(bias_str, " ", true, true, &bias_tokens);
    if (bias_tokens.size() != cols) {
      LOG(ERROR) << "DNNModel::LoadModelParams Bias should has " << cols << "parameters"
          << " but" << bias_tokens.size();
      return false;
    }
    for (uint32 i = 0; i < cols; i++) {
      double value;
      if (!base::StringToDouble(bias_tokens[i], &value)) {
        LOG(ERROR) << "DNNModel::LoadModelParams Invalid number conversion." << bias_tokens[i];
        return false;
      }
      layer.b(i) = value;
      param_num_read++;
    }
    // END
    LOG(WARNING) << "DNNModel Layer [" << index << "] includes " << rows << "x" << cols << " parameters.";
    layers_.push_back(layer);
  }
  // final check
  if (total_param_num != param_num_read || layers_.size() != layer_sizes_.size()-1) {
    LOG(ERROR) << "DNNModel::LoadModelParams Final Check failed.";
    return false;
  } else {
    LOG(WARNING) << "DNNModel Load " << param_num_read << " paramaters totally.";
  }
  // 读取的这部分最后一行必须是 [END]
  std::string str;
  if (!std::getline(*ifs, str)) {
    LOG(ERROR) << "DNNModel::LoadModelParams File FORMAT error: NO END TAG";
    return false;
  } else if (str != "[END]") {
    return false;
  }
  return true;
}

bool DNNModel::LoadLayerSize(std::ifstream* ifs) {
  std::string line;
  // 该行配置只可能出现一行，这一行一定是层结点配置，否则认为发生
  // 错误，返回 false
  if (!std::getline(*ifs, line)) {
    LOG(ERROR) << "DNNModel::LoadLayerSize Fatal error: No line to read.";
    return false;
  }
  std::vector<std::string> tokens;
  base::SplitStringWithOptions(line, " ", true, true, &tokens);
  if (tokens.size() < 1) {
    LOG(ERROR) << "DNNModel::LoadLayerSize Too few parameters.";
    return false;
  }
  uint32 layer_count;
  if (!base::StringToUint(tokens[0], &layer_count)) {
    LOG(ERROR) << "DNNModel::LoadLayerSize Convert string to a number failed.";
    return false;
  }
  if (layer_count+1 != tokens.size()) {
    LOG(ERROR) << "DNNModel::LoadLayerSize: layer count not equal to number of following parameters.";
    return false;
  }
  for (uint32 i = 1; i < tokens.size(); i++) {
    uint32 value = 0;
    if (!base::StringToUint(tokens[i], &value)) {
      LOG(ERROR) << "DNNModel::LoadLayerSize Convert string to a number failed.";
      return false;
    }
    layer_sizes_.push_back(value);
  }
  // double check
  if (layer_sizes_.size() != layer_count) {
    LOG(ERROR) << "DNNModel::LoadLayerSize: Final size of layer_sizes_ != layer_count.";
    return false;
  }
  for (auto it = layer_sizes_.begin(); it != layer_sizes_.end(); it++) {
    if (*it == 0) {
      LOG(ERROR) << "DNNMode::LoadLayerSize: Final Check, layer size must be non-zero.";
      return false;
    }
  }
  // 执行严格检查，下一行必须以 [END] 结束，否则认为错误
  if (std::getline(*ifs, line) && line == "[END]") {
    LOG(INFO) << "DNNModel Load Layer Size success:";
    for (uint32 i = 0; i < layer_sizes_.size(); i++) {
      LOG(INFO) << i << ": " << layer_sizes_[i];
    }
    return true;
  } else {
    LOG(ERROR) << "DNNModel::LoadLayerSize: No END TAG founded.";
    return false;
  }
}

// 载入归一化参数，参数表格式在原本格式的基础上在开头添加一列 slot id
// slot id 必须与特征名严格对应，迁移首期暂时保留原有归一化词表格式，后期
// 如有需要可以对此读取函数进行升级
// [NORM]...[END]
bool DNNModel::LoadNormParams(std::ifstream* ifs) {
  bool rt_status = false;
  bool get_end = false;
  // 目前的网络结构输入的维度等于特征类目数 * 2 - 1
  uint32 feature_num = 0;
  std::string line;
  while (std::getline(*ifs, line)) {
    if (line == "[END]") {
      get_end = true;
      break;
    }
    if (line.empty()) continue;
    std::vector<std::string> tokens;
    base::SplitStringWithOptions(line, "\t", true, true, &tokens);
    // 目前的 norm 表含有 12 个域，新增一个 slot 列，共 13 个列
    if (tokens.size() != 13) {
      LOG(WARNING) << "DNNModel::LoadNormParams Invalid norm config record:" << line;
      continue;
    }
    // slot id 位于第一列 tokens[0]
    // 逐个处理 norm 表参数
    uint32 slot;
    if (!base::StringToUint(tokens[0], &slot)) {
      // 执行严格检查，一旦发现错误，立即返回错误，对有内容的行内错误零容忍
      LOG(ERROR) << "DNNModel::LoadNormParams Norm Dict Format Error:" << line;
      return rt_status;
    }
    double show_m, show_v, click_m, click_v, show_default, click_default;
    if (!base::StringToDouble(tokens[7], &show_m)) {
      LOG(ERROR) << "DNNModel::LoadNormParams Norm Dict Format Error:" << line;
      return rt_status;
    }
    if (!base::StringToDouble(tokens[9], &show_v)) {
      LOG(ERROR) << "DNNModel::LoadNormParams Norm Dict Format Error:" << line;
      return rt_status;
    }
    if (!base::StringToDouble(tokens[8], &click_m)) {
      LOG(ERROR) << "DNNModel::LoadNormParams Norm Dict Format Error:" << line;
      return rt_status;
    }
    if (!base::StringToDouble(tokens[10], &click_v)) {
      LOG(ERROR) << "DNNModel::LoadNormParams Norm Dict Format Error:" << line;
      return rt_status;
    }
    if (!base::StringToDouble(tokens[11], &show_default)) {
      LOG(ERROR) << "DNNModel::LoadNormParams Norm Dict Format Error:" << line;
      return rt_status;
    }
    if (!base::StringToDouble(tokens[12], &click_default)) {
      LOG(ERROR) << "DNNModel::LoadNormParams Norm Dict Format Error:" << line;
      return rt_status;
    }
    // fix
    if (show_v <= std::numeric_limits<double>::min()) {
      LOG(WARNING) << "Show Variance is zero, has been set as 1.0";
      show_v = 1.0;
    }
    if (click_v <= std::numeric_limits<double>::min()) {
      LOG(WARNING) << "Show Variance is zero, has been set as 1.0";
      click_v = 1.0;
    }
    map_norm_[slot] = NormElement(show_m, show_v, click_m, click_v, show_default,
                                  click_default, tokens[1], feature_num);
    feature_num++;
  }

  // final check
  if ((feature_num * 2 - 1 == layer_sizes_[0]) & (feature_num == map_norm_.size())) {
    rt_status = true;
  } else {
    LOG(ERROR) << "DNNModel::LoadNormParams Final Check error.";
  }

  return rt_status & get_end;
}

// dnn model load end

bool DNNModel::LoadCVM(const std::string& filename) {
  // duplicated cleaning
  if (map_cvm_) {
    delete map_cvm_;
    map_cvm_ = NULL;
  }
  map_cvm_ = new base::dense_hash_map<uint64_t, ShowClickTuple>();
  map_cvm_->set_empty_key(0u);
  if (map_cvm_data_) {
    delete map_cvm_data_;
    map_cvm_data_ = NULL;
  }

  map_cvm_data_ = new std::string();
  if (!base::file_util::ReadFileToString(filename, map_cvm_data_)) {
    LOG(ERROR) << "Load DNN CVM " << filename << " failed.";
    return false;
  }
  if (!map_cvm_->Read(map_cvm_data_->data(), map_cvm_data_->size())) {
    LOG(ERROR) << "Load DNN CVM " << filename << " failed.";
    return false;
  }

  LOG(WARNING) << "Load DNN CVM success:" << filename << ", load record number: " << map_cvm_->size();
  return true;
}

bool DNNModel::LoadModelConfig(const std::string& filename) {
  // duplicated?
  conf_dict_.clear();

  std::ifstream in_file(filename);
  if (!in_file.good()) {
    LOG(ERROR) << "Error: Load DNN CONFIG file " << filename << " failed.";
    return false;
  }
  std::string line;
  while (std::getline(in_file, line)) {
    if (line.empty()) continue;
    if (base::StartsWith(line, "#", true)) continue;
    std::vector<std::string> tokens;
    base::SplitString(line, "=", &tokens);
    if (tokens.size() != 2) {
      LOG(WARNING) << "Invalid dnn config: " << filename << ":" << line;
      continue;
    }
    double value = 0.0;
    if (!base::StringToDouble(tokens[1], &value)) {
      LOG(WARNING) << "Invalid dnn config: " << filename << ":" << line;
      continue;
    }
    std::string k = tokens[0];
    conf_dict_[k] = value;
  }
  if (!in_file.eof()) {
    LOG(ERROR) << "Read file " << filename << " error.";
    return false;
  }
  LOG(WARNING) << "DNN CONFIG Loading list:";
  for (auto it = conf_dict_.begin(); it != conf_dict_.end(); it++) {
    LOG(WARNING) << it->first << ":\t" << it->second;
  }
  LOG(WARNING) << "DNN CONFIG Load success.";
  return true;
}

// 获取配置参数值
bool DNNModel::GetConfValue(const std::string& key, double* value) const {
  auto it = conf_dict_.find(key);
  if (it == conf_dict_.end()) {
    return false;
  } else {
    *value = it->second;
    return true;
  }
}

bool DNNModel::GenInstance(const std::vector<uint64>* features, const std::vector<uint32>* feature_slots,
                           const double lr_q, std::vector<double>* dnn_ins) const {
  /*
  if (dnn_ins->size() != map_norm_.size() *2 -1) {
    LOG(ERROR) << "dnn instance's length must be equal to map norm size*2-1.";
    return;
  }
  */
  DCHECK(NULL != features) << "Feature can not be empty!";
  DCHECK(NULL != feature_slots) << "Feature slots can not be empty!";
  uint32 features_size, feature_slots_size;
  features_size = features->size();
  feature_slots_size = feature_slots->size();
  if (features_size != feature_slots_size) {
    LOG_EVERY_N(WARNING, 10) << "Features size != Featureslots size";
    return false;
  }
  if (0 == features_size || 0 == feature_slots_size) {
    LOG_EVERY_N(WARNING, 10) << "Features or Featureslots can not be empty!";
    return false;
  }
  // 遍历传过来的特征列表 查找 cvm
  dnn_ins->at(dnn_ins->size() - 1) = lr_q;
  // LOG(WARNING) << "feature length:" << features->size();
  for (uint32 i = 0; i < features_size; i++) {
    uint32 slot = feature_slots->at(i);
    auto it_norm =  map_norm_.find(slot);
    if (it_norm == map_norm_.end()) continue;
    auto& norm_elem = it_norm->second;
    // 需要这个特征 查 CVM 理论上这个特征不可能是 ADQ
    auto it_cvm = map_cvm_->find(features->at(i));
    if (it_cvm == map_cvm_->end()) continue;
    auto& sc = it_cvm->second;
    dnn_ins->at(norm_elem.index*2) += sc.show;
    dnn_ins->at(norm_elem.index*2+1) += sc.click;
  }
  // 遍历 map norm，做归一化处理
  for (auto it = map_norm_.begin(); it != map_norm_.end(); it++) {
    auto& elem = it->second;
    /*
     * 本段代码用于处理默认值情况，目前线上采用默认值为 0 
     * 暂时不启用该段逻辑
    if (fabs(dnn_ins->at(elem.index*2)) <= std::numeric_limits<double>::min() &&
        elem.feature_name != "ADQ") {
      dnn_ins->at(elem.index*2) = elem.show_default;
      dnn_ins->at(elem.index*2+1) = elem.click_default;
    }
    */
    if (elem.feature_name == "ADQ") {
      double t = dnn_ins->at(elem.index*2);
      // std::cout << elem.index*2 << std::endl;
      dnn_ins->at(elem.index*2) = (t-elem.show_mean)/sqrt(elem.show_variance);
      // std::cout << t << " " << elem.show_mean << " " << elem.show_variance << std::endl;
    } else {
      double t1 = dnn_ins->at(elem.index*2), t2 = dnn_ins->at(elem.index*2+1);
      dnn_ins->at(elem.index*2) = (log10(t1+1)-elem.show_mean)/sqrt(elem.show_variance);
      dnn_ins->at(elem.index*2+1) = (log10(t2+1)-elem.click_mean)/sqrt(elem.click_variance);
      // std::cout << t1 << " " << elem.show_mean << " " << elem.show_variance << std::endl;
      // std::cout << t2 << " " << elem.click_mean << " " << elem.click_variance << std::endl;
    }
  }
  return true;
}


// FOR DNN COMPUTATION
inline double Tanh(double x) {
  if (x < -15)
    return -1;
  if (x > 15)
    return 1;
  return (exp(2*x)-1.0)/(exp(2*x)+1.0);
};

inline double Sigmoid(double x) {
  if (x < -30)
    return 0;
  if (x > 30)
    return 1;
  return exp(x)/(exp(x)+1.0);
};

inline double Relu(double x) {
  return x < 0 ? 0 : x;
};

void Activate(Eigen::VectorXf* inputX, uint32 outsize, std::string acttype) {
  for (uint32 i = 0; i < outsize; i++) {
    if (acttype == "relu")
      (*inputX)(i) = Relu((*inputX)(i));
    else if (acttype == "sigmoid")
      (*inputX)(i) = Sigmoid((*inputX)(i));
    else if (acttype == "tanh")
      (*inputX)(i) = Tanh((*inputX)(i));
  }
};
//
// END

void DNNModel::DNNPredict(const std::vector<double>& ins, double* dnn_q) const {
  uint32 len = layer_sizes_[0];
  CHECK(len == ins.size()) << "DNN Predict exception: default length != given "
      << "feature length: " << len << "!=" << ins.size();
  // optimized as FLAGS or Global variables maybe
  uint32 id = layer_sizes_.size()-1;
  Eigen::VectorXf inputX(len);
  for (uint32 i = 0; i < len; i++) {
    inputX(i) = ins[i];
  }
  Eigen::VectorXf rtv = GetVector(inputX, id);
  *dnn_q = rtv(0);
  return;
}

Eigen::VectorXf DNNModel::GetVector(const Eigen::VectorXf &inputX, uint32 layerid) const {
  std::vector<Eigen::VectorXf> outs(layers_.size());
  for (uint32 i = 0; i < layers_.size(); i++) {
    outs[i].setZero(layer_sizes_[i+1]);
  }

  // feed forward
  if (layers_.size() > 0) {
    // first layer
    if (layers_[0].use_bias)
      outs[0].noalias() = layers_[0].W * inputX + layers_[0].b;
    else
      outs[0].noalias() = layers_[0].W * inputX;
    Activate(&outs[0], layers_[0].out_size, layers_[0].act_type);
    if (layerid == 1)
      return outs[0];
    // higher layers
    for (uint32 i = 1; i< layers_.size(); i++) {
      if (layers_[i].use_bias)
        outs[i].noalias() = layers_[i].W * outs[i-1] + layers_[i].b;
      else
        outs[i].noalias() = layers_[i].W * outs[i-1];
      Activate(&outs[i], layers_[i].out_size, layers_[i].act_type);
      if (layerid == i+1)
        return outs[i];
    }
  }
  return outs[outs.size()-1];
}

int32 DNNModel::Predict(const std::vector<uint64>* features,
                        const std::vector<uint32>* feature_slots,
                        const double lr_q,
                        double* dnn_q) {
  std::vector<double> ins(layer_sizes_[0], 0.0);
  if (!GenInstance(features, feature_slots, lr_q, &ins)) {
    LOG(WARNING) << "DNN Prediction: Generate isntance failed.";
    return -1;
  }
  DNNPredict(ins, dnn_q);
  if (*dnn_q <= 0 || *dnn_q >= 1) {
    LOG(WARNING) << "DNN Q should be in range(0,1):" << dnn_q;
    return -1;
  }
  return 0;
}

}  // namespace model_server
}  // namespace wolong
