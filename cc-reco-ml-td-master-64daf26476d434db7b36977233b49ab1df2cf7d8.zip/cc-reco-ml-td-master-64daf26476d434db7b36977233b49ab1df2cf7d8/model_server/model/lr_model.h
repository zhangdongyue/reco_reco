#pragma once

#include <string>
#include <vector>

#include "base/common/base.h"
#include "base/container/dense_hash_map.h"

#include "wolong/model_server/model/model.h"

namespace wolong {
namespace model_server {

class LRModel : public Model {
 public:
  LRModel() {}
  virtual ~LRModel() {}
  virtual bool Initialize(const std::string &config_file);

  int32 Predict(const std::vector<uint64>* features,
                const std::vector<std::string>* fea_literal,
                double* ctr, uint32* show);

 private:
  bool Load(const std::string& dict_path);
  void LookupWeight(uint64 sign, double* weight, uint32* show) const;
  void LRPredict(const std::vector<uint64>* features,
                 const std::vector<std::string>* fea_literal,
                 double* sum_weight, uint32* show);

 private:
  std::string dict_path_;
  std::string id_feature_name_;
  double min_feature_show_;
  double min_feature_weight_;
  struct Weight {
    double weight;
    uint32 show;
  };
  base::dense_hash_map<uint64, Weight> feature_map_;
 private:
  DISALLOW_COPY_AND_ASSIGN(LRModel);
};
}  // namespace model_server
}  // namespace wolong
