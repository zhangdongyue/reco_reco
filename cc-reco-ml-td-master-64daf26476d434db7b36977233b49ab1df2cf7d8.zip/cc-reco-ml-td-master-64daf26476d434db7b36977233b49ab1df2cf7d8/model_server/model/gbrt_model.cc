#include "wolong/model_server/model/gbrt_model.h"

#include <string>
#include <vector>
#include <unordered_map>

#include "base/common/base.h"
#include "base/common/logging.h"

#include "base/file/file_util.h"

#include "vertical/framework/util/util.h"
#include "vertical/framework/util/xml.h"

namespace wolong {
namespace model_server {

bool GbrtModel::Initialize(const std::string &config_file) {
  if (!Model::Initialize(config_file)) {
    LOG(ERROR) << "Model::Initialize error!";
    return false;
  }

  if (!enable_) {
    return true;
  }

  std::string content;
  if (!base::file_util::ReadFileToString(config_file, &content)) {
    LOG(ERROR) << "Failed to open model config file! file:" << config_file;
    return false;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(content, &context)) {
    LOG(ERROR) << "Failed to parse model config xml:" << content;
    return false;
  }

  if (!vsf::xml::GetXPathString(&context, "/config/dict_dir", &dict_dir_)) {
    LOG(ERROR) << "error read dict_dir! dict_dir:" << dict_dir_;
    return false;
  }

  if (dict_dir_.empty()) {
    LOG(ERROR) << "dict dir empty!";
    return false;
  }

  if (!gbrt_feature_.Load(dict_dir_, true, true)) {
    LOG(ERROR) << "gbrt load error!";
    return false;
  }

  return true;
}

int32 GbrtModel::Process(const wolong::GbrtReqFeature& item,
                         wolong::GbrtResFeature* fea,
                         wolong::GbrtStat* stat) {
  // prepare
  GBRTInsKeys gbrt_fea_evi;
  gbrt_fea_evi.winfo_id = item.winfo_id();
  gbrt_fea_evi.idea_id = item.idea_id();
  gbrt_fea_evi.unit_id = item.unit_id();
  gbrt_fea_evi.plan_id = item.plan_id();
  gbrt_fea_evi.user_id = item.user_id();
  gbrt_fea_evi.pattern_id = item.pattern_id();
  gbrt_fea_evi.word = item.word();
  gbrt_fea_evi.query = item.query();
  gbrt_fea_evi.ucid = item.ucid();
  gbrt_fea_evi.match_type = item.match_type();
  gbrt_fea_evi.day_hour = item.day_hour();
  gbrt_fea_evi.show_url = item.show_url();

  // compute
  std::vector<int> gbrt_res;
  std::vector<GBRTPair> gbrt_stat_pair;
  gbrt_feature_.GetGBRTFeature(gbrt_fea_evi, &gbrt_res, &gbrt_stat_pair);

  // fill
  fea->mutable_gbrt_nodeids()->Reserve(gbrt_res.size() + 1);
  for (int j = 0; j < (int)gbrt_res.size(); j++) {
    fea->add_gbrt_nodeids(gbrt_res[j]);
  }

  stat->mutable_gbrt_stat_pair()->Reserve(gbrt_stat_pair.size() + 1);
  for (int t = 0; t < (int)gbrt_stat_pair.size(); t++) {
    GbrtStatPair * gbrt_stat_pair_item = stat->add_gbrt_stat_pair();
    gbrt_stat_pair_item->set_name(gbrt_stat_pair[t].name);
    gbrt_stat_pair_item->set_value(gbrt_stat_pair[t].value);
  }

  return 0;
}
}
}

