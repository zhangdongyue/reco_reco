#pragma once

#include <string>
#include <vector>

#include "base/common/base.h"
#include "base/container/dense_hash_map.h"

#include "wolong/model_server/model/model.h"

namespace wolong {

namespace model_server {

class FMModel : public Model {
 public:
  FMModel() {}
  virtual ~FMModel() {}
  virtual bool Initialize(const std::string &config_file);

  int32 Predict(const std::vector<uint64>* features,
                const std::vector<std::string>* fea_literal,
                double* ctr);
 private:
  bool Load(const std::string& dict_name);
  void LookupWeight(uint64 sign, double* w, const double** v, std::vector<double>* lookup_val) const;
  void FMPredict(const std::vector<uint64>* features,
                 const std::vector<std::string>* fea_literal,
                 double* sum_weight);

 private:
  struct FMWeight {
    char bitmap_[2];
    std::string value_;

    void clear() {
      bitmap_[0] = 0;
      bitmap_[1] = 0;
      if (value_.size() > 0) {
        value_.clear();
      }
    }
    void BitmapSet(int index) {
      bitmap_[index >>3] |= (1 << (index & 0x7));
    }
    int BitmapGet(int index) {
      return bitmap_[index>>3] & (1 << (index & 0x7));
    }
  };
  bool CompressToFMWeight(const std::vector<double> *val, FMWeight *fm_val, size_t max_len);
  bool DecompressFromFMWeight(std::vector<double> *val, FMWeight *fm_val, size_t max_len) const;

 private:
  std::string dict_path_;
  base::dense_hash_map<uint64, std::string > map_;
  // base::sparse_hash_map<uint64, std::string >* map_;
  size_t v_dim_;
  std::vector<double> default_value_;
 private:
  DISALLOW_COPY_AND_ASSIGN(FMModel);
};
}  // namespace model_server
}  // namespace wolong
