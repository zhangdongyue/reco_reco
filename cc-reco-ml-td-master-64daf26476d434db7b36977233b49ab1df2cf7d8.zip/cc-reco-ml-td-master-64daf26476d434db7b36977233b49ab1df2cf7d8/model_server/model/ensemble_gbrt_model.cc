#include "wolong/model_server/model/ensemble_gbrt_model.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_map>

#include "base/common/base.h"
#include "base/common/logging.h"

#include "base/file/file_util.h"

#include "vertical/framework/util/util.h"
#include "vertical/framework/util/xml.h"

DEFINE_int32(ensemble_ternary_tree_num, 120, "tree number");
DEFINE_int32(ensemble_tree_branch, 2, "tree branch");
DEFINE_int32(ensemble_tree_depth, 8, "tree depth");
DEFINE_string(ensemble_model_type, "xgboost", "gbrt model type");

DECLARE_double(gbrt_average_ctr);

namespace wolong {
namespace model_server {

bool EnsembleGbrtModel::Initialize(const std::string &config_file) {
  if (!Model::Initialize(config_file)) {
    LOG(ERROR) << "Model::Initialize error!";
    return false;
  }

  if (!enable_) {
    return true;
  }

  std::string content;
  if (!base::file_util::ReadFileToString(config_file, &content)) {
    LOG(ERROR) << "Failed to open model config file! file:" << config_file;
    return false;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(content, &context)) {
    LOG(ERROR) << "Failed to parse model config xml:" << content;
    return false;
  }

  if (!vsf::xml::GetXPathString(&context, "/config/dict_dir", &dict_dir_)) {
    LOG(ERROR) << "error read dict_dir:" << dict_dir_;
    return false;
  }

  if (dict_dir_.empty()) {
    LOG(ERROR) << dict_dir_ << " empty! ";
    return false;
  }

  if (!vsf::xml::GetXPathString(&context, "/config/cvm_dict_name", &cvm_dict_name_)) {
    LOG(ERROR) << "error read cvm_dict_name:" << cvm_dict_name_;
    return false;
  }

  if (cvm_dict_name_.empty()) {
    LOG(ERROR) << cvm_dict_name_ << " empty! ";
    return false;
  }

  if (!vsf::xml::GetXPathString(&context, "/config/reserved_feaset_name", &reserved_feaset_name_)) {
    LOG(ERROR) << "error read reserved_feaset_name:" << reserved_feaset_name_;
    return false;
  }

  if (reserved_feaset_name_.empty()) {
    LOG(ERROR) << reserved_feaset_name_ << " empty! ";
    return false;
  }

  if (!vsf::xml::GetXPathString(&context, "/config/ensemble_gbrt_model_name", &ensemble_gbrt_model_name_)) {
    LOG(ERROR) << "error read ensemble_gbrt_model_name:" << ensemble_gbrt_model_name_;
    return false;
  }

  if (ensemble_gbrt_model_name_.empty()) {
    LOG(ERROR) << ensemble_gbrt_model_name_ << " empty! ";
    return false;
  }

  if (!Load(dict_dir_)) {
    LOG(ERROR) << "gbrt load error!";
    return false;
  }

  return true;
}

bool EnsembleGbrtModel::Load(const std::string& dict_path) {
  if (NULL != ensemble_booster_) delete ensemble_booster_;
  ensemble_booster_ = new mgbrt::predict::Booster(FLAGS_ensemble_ternary_tree_num, FLAGS_ensemble_tree_branch,
                                                  FLAGS_ensemble_tree_depth, FLAGS_ensemble_model_type);
  if (NULL != cvm_dict_) delete cvm_dict_;
  cvm_dict_ = new Cvm_Dict();
  std::string cvm_dict_path = dict_path + cvm_dict_name_;
  if (!cvm_dict_->Load(cvm_dict_path)) {
    LOG(ERROR) << "Load " << cvm_dict_path << " fail!";
    return false;
  }
  LOG(WARNING) << "Load " << cvm_dict_path << " success";

  std::string reserved_feaset_path = dict_path + reserved_feaset_name_;
  if (!LoadReservedFeaSet(reserved_feaset_path)) {
    LOG(ERROR) << "Load " << reserved_feaset_path << " fail!";
    return false;
  }
  LOG(WARNING) << "Load " << reserved_feaset_path << " success";

  std::string ensemble_gbrt_model_path = dict_path + ensemble_gbrt_model_name_;
  if (!LoadModelTernary(ensemble_gbrt_model_path)) {
    LOG(ERROR) << "Load " << ensemble_gbrt_model_path << " fail!";
    return false;
  }
  LOG(WARNING) << "Load " << ensemble_gbrt_model_path << " success";

  return true;
}

bool EnsembleGbrtModel::LoadModelTernary(const std::string& dict_path) {
  CHECK(ensemble_booster_->LoadTree(dict_path));
  return true;
}

bool EnsembleGbrtModel::LoadReservedFeaSet(const std::string& dict_path) {
  reserved_feaset_.clear();
  std::ifstream in_file(dict_path);
  if (!in_file.good()) {
    LOG(ERROR) << dict_path << " not exist!";
    return false;
  }
  std::string line;
  uint64 line_cnt = 0;
  while (std::getline(in_file, line)) {
    if (line.empty()) {
      continue;
    }
    std::vector<std::string> reserved_field;
    base::SplitStringWithOptions(line, "\t", true, true, &reserved_field);
    if (!reserved_field.empty()) {
      line_cnt++;
      std::string str_slot_name = reserved_field[0];
      std::string str_slot = reserved_field[1];
      uint32 slot;
      if (!base::StringToUint(str_slot, &slot)) {
        LOG(ERROR) << "Error format line: " << line;
        continue;
      } else {
        reserved_feaset_.insert(slot);
      }
    }
  }
  in_file.close();
  return true;
}

void EnsembleGbrtModel::GenInstance(const std::vector<uint64>* features,
                                    const std::vector<uint32>* feature_slots,
                                    const double lr_q,
                                    std::vector<double>* gbrt_ins) const {
  DCHECK(NULL != features) << "BUG: features is empty";
  DCHECK(NULL != feature_slots) << "BUG: feature_slots is empty";
  int32 features_size, feature_slots_size;
  features_size = features->size();
  feature_slots_size = feature_slots->size();
  if (features_size != feature_slots_size) {
    LOG(WARNING) << "features And featureslots not equal !";
    return;
  }
  if (0 == features_size || 0 == feature_slots_size) {
    LOG(WARNING) << "features or featureslots empty !";
    return;
  }
  std::map<uint32, MultiVariateFeaStat> stat_ins;
  std::set<uint32>::iterator set_iter = reserved_feaset_.begin();
  uint32 slot;
  uint32 max_slot = 0u;
  for (; set_iter != reserved_feaset_.end(); set_iter++) {
    slot = *set_iter;
    if (slot > max_slot) max_slot = slot;
    MultiVariateFeaStat st;
    st.show = 0u;
    st.clk = 0u;
    stat_ins.insert(std::pair<uint32, MultiVariateFeaStat>(slot, st));
  }
  uint64 feasign;
  uint32 show, clk;
  std::map<uint32, MultiVariateFeaStat>::iterator map_iter;
  for (int32 i = 0; i < feature_slots_size; i++) {
    slot = feature_slots->at(i);
    map_iter = stat_ins.find(slot);
    if (map_iter != stat_ins.end()) {
      feasign = features->at(i);
      cvm_dict_->LookupWeight(feasign, &show, &clk);
      map_iter->second.show += show;
      map_iter->second.clk += clk;
    }
  }
  double default_value = FLAGS_gbrt_average_ctr;
  gbrt_ins->resize(max_slot + 1, default_value);
  for (map_iter = stat_ins.begin(); map_iter != stat_ins.end(); map_iter++) {
    slot = map_iter->first;
    MultiVariateFeaStat fea_stat = map_iter->second;
    if (fea_stat.show == 0u) continue;
    double fea_ctr = (double)fea_stat.clk / fea_stat.show;
    gbrt_ins->at(slot) = fea_ctr;
  }
  gbrt_ins->at(0) = lr_q;
}

int32 EnsembleGbrtModel::Predict(const std::vector<uint64>* features,
                                 const std::vector<uint32>* feature_slots,
                                 const double lr_q,
                                 double* gbrt_q) {
  std::vector<double> ins;
  GenInstance(features, feature_slots, lr_q, &ins);
  if (0 == ins.size()) {
    LOG(WARNING) << "Empty GBRT Ins !";
    return -1;
  }
  double sum_weight = 0.0;
  GBRTPredict(ins, &sum_weight);
  *gbrt_q =  LRScore(sum_weight);
  return 0;
}

void EnsembleGbrtModel::GBRTPredict(const std::vector<double>& ins,
                                    double* sum_weight) {
  *sum_weight = 0.0;
  std::vector<int> tree_leaf_nodes;
  *sum_weight = ensemble_booster_->Predict(ins, &tree_leaf_nodes);
}
}
}
