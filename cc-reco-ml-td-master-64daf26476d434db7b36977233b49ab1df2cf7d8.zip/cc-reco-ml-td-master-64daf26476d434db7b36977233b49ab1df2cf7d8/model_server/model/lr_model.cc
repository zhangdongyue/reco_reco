#include "wolong/model_server/model/lr_model.h"

#include <math.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <iostream>
#include <utility>
#include <fstream>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

#include "base/file/file_util.h"

#include "vertical/framework/util/xml.h"

namespace wolong {
namespace model_server {

bool LRModel::Initialize(const std::string &config_file) {
  if (!Model::Initialize(config_file)) {
    LOG(ERROR) << "Model::Initialize error!";
    return false;
  }

  if (!enable_) {
    return true;
  }

  std::string content;
  if (!base::file_util::ReadFileToString(config_file, &content)) {
    LOG(ERROR) << "Failed to open model config file! file:" << config_file;
    return false;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(content, &context)) {
    LOG(ERROR) << "Failed to parse model config xml:" << content;
    return false;
  }

  if (!vsf::xml::GetXPathString(&context, "/config/id_feature_name", &id_feature_name_)) {
    LOG(ERROR) << "error read id_feature_name.";
    return false;
  }

  if (!vsf::xml::GetXPathDouble(&context, "/config/min_feature_weight", &min_feature_weight_)) {
    LOG(ERROR) << "error read min_feature_weight.";
    return false;
  }

  if (!vsf::xml::GetXPathDouble(&context, "/config/min_feature_show", &min_feature_show_)) {
    LOG(ERROR) << "error read min_feature_show.";
    return false;
  }

  if (!vsf::xml::GetXPathString(&context, "/config/dict_path", &dict_path_)) {
    LOG(ERROR) << "error read dict_path! dict_path:" << dict_path_;
    return false;
  }
  if (dict_path_.empty()) {
    LOG(ERROR) << "dict name empty!";
    return false;
  }

  if (!Load(dict_path_)) {
    LOG(ERROR) << "lr dict load error!";
    return false;
  }

  return true;
}

bool LRModel::Load(const std::string& dict_path) {
  feature_map_.set_empty_key(0u);
  std::ifstream in_file(dict_path);
  if (!in_file.good()) {
    LOG(ERROR) << dict_path << " not exist!";
    return false;
  }
  std::string line;
  uint64 line_cnt = 0;
  while (std::getline(in_file, line)) {
    if (line.empty()) continue;
    std::vector<std::string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() != 6) {
      LOG(ERROR) << "Error format line: " << line;
      continue;
    }
    const std::string& str_feature = tokens[0];
    const std::string& str_sign    = tokens[1];
    const std::string& str_show    = tokens[2];
    const std::string& str_weight  = tokens[5];
    uint64 sign = 0u;
    double weight = 0.0;
    uint32 show = 0u;
    if (!base::StringToUint64(str_sign, &sign)) {
      LOG(ERROR) << "Error format line: " << line;
      continue;
    }
    if (!base::StringToUint(str_show, &show)) {
      LOG(ERROR) << "Error format line: " << line;
      continue;
    }
    if (!base::StringToDouble(str_weight, &weight)) {
      LOG(ERROR) << "Error format line: " << line;
      continue;
    }
    bool id_feature = str_feature.size() > id_feature_name_.size()
      && str_feature.substr(0, id_feature_name_.size() +1) == (id_feature_name_ + ":")
      && show >= min_feature_show_;
    if (fabs(weight) >= min_feature_weight_ || id_feature) {
      Weight feature_weight;
      feature_weight.weight = weight;
      feature_weight.show = id_feature ? show : 0u;
      feature_map_[sign] = feature_weight;
    }
    ++line_cnt;
  }
  if (!in_file.eof()) {
    LOG(ERROR) << "Read file " << dict_path << " error.";
    return false;
  }
  if (line_cnt < 10000) {
    LOG(ERROR) << "Read file " << dict_path
      << " error, line count abnormal[" << line_cnt << ".";
    return false;
  }
  LOG(WARNING) << "Load " << name_ << " success!"
    << ", Read " << line_cnt << " lines from " << dict_path
    << ", " << feature_map_.size() << " feature in weight model";
  return true;
}

void LRModel::LookupWeight(uint64 sign, double* weight, uint32* show) const {
  *weight = 0.0;
  *show   = 0u;
  if (sign == 0u) return;
  auto weight_it = feature_map_.find(sign);
  if (weight_it != feature_map_.end()) {
    *weight = weight_it->second.weight;
    *show = weight_it->second.show;
  }
}

void LRModel::LRPredict(const std::vector<uint64>* features,
                        const std::vector<std::string>* fea_literal,
                        double* sum_weight, uint32* show) {
  *show = 0u;
  *sum_weight = 0.0;
  for (size_t i = 0; i < features->size(); ++i) {
    double weight = 0.0;
    uint32  feature_show = 0u;
    LookupWeight(features->at(i), &weight, &feature_show);
    *sum_weight += weight;
    // only id feature can get show
    if (feature_show > *show) *show = feature_show;
  }
}

int32 LRModel::Predict(const std::vector<uint64>* features,
                       const std::vector<std::string>* fea_literal,
                       double* ctr, uint32* show) {
  double sum_weight = 0.0;
  LRPredict(features, fea_literal, &sum_weight, show);
  *ctr =  LRScore(sum_weight);
  return 0;
}
}
}
