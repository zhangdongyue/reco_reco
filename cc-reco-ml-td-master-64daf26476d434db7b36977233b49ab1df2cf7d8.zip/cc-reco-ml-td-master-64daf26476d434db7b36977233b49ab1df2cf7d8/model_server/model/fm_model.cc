#include "wolong/model_server/model/fm_model.h"

#include <math.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <iostream>
#include <fstream>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

#include "base/file/file_util.h"

#include "vertical/framework/util/xml.h"

namespace wolong {
namespace model_server {

bool FMModel::Initialize(const std::string &config_file) {
  if (!Model::Initialize(config_file)) {
    LOG(ERROR) << "Model::Initialize error!";
    return false;
  }

  if (!enable_) {
    return true;
  }

  std::string content;
  if (!base::file_util::ReadFileToString(config_file, &content)) {
    LOG(ERROR) << "Failed to open model config file! file:" << config_file;
    return false;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(content, &context)) {
    LOG(ERROR) << "Failed to parse model config xml:" << content;
    return false;
  }

  int64 v_dim = 0;
  if (!vsf::xml::GetXPathInt64(&context, "/config/v_dim", &v_dim)) {
    LOG(ERROR) << "error read v_dim.";
    return false;
  }
  v_dim_ = (size_t)v_dim;
  for (int32 j = 0; j < v_dim + 1; j++) {
    default_value_.push_back(0.0);
  }

  if (!vsf::xml::GetXPathString(&context, "/config/dict_path", &dict_path_)) {
    LOG(ERROR) << "error read dict_path! dict_path:" << dict_path_;
    return false;
  }

  if (dict_path_.empty()) {
    LOG(ERROR) << "dict name empty!";
    return false;
  }

  if (!Load(dict_path_)) {
    LOG(ERROR) << "fm dict load error!";
    return false;
  }

  return true;
}

void FMModel::LookupWeight(uint64 sign, double* w, const double** v, std::vector<double>* lookup_val) const {
  auto it = map_.find(sign);
  if (it != map_.end()) {
    FMWeight fm_val;
    fm_val.clear();
    fm_val.value_ = it->second;
    DecompressFromFMWeight(lookup_val, &fm_val, v_dim_+1);
    *w = lookup_val->at(0);
    *v = &(lookup_val->at(1));
  } else {
    *w = default_value_[0];
    *v = &default_value_[1];
  }
}

bool FMModel::CompressToFMWeight(const std::vector<double> *val, FMWeight *fm_val, size_t max_len) {
  // 由于采用 2 字节 压缩 bitmap，因此 v_dim + 1 不能大于 16
  if ( val->size() > max_len || max_len > 16 ) {
    LOG(WARNING) << "CompressToFMWeight error! val size:" << val->size() << " "
      << "max_len:" <<max_len;
    return false;
  }
  fm_val->bitmap_[0]=0;
  fm_val->bitmap_[1]=0;
  std::string temp_str;
  for (size_t i = 0; i < max_len; ++i) {
    if (val->at(i) >= 0.000001 || val->at(i) <= -0.000001) {
      fm_val->BitmapSet(i);
      float temp_val = static_cast<float>(val->at(i));
      temp_str.append(reinterpret_cast<const char *>(&temp_val), sizeof(float) );
    }
  }
  if (temp_str.size() == 0) {
    return false;
  }
  fm_val->value_.append(fm_val->bitmap_, 2);
  fm_val->value_.append(temp_str);
  return true;
}

bool FMModel::DecompressFromFMWeight(std::vector<double> *val, FMWeight *fm_val,
                                        size_t max_len) const {
  // 由于采用 2 字节 压缩 bitmap，因此 v_dim + 1 不能大于 16
  if ( val->size() < max_len || max_len > 16 ) {
    LOG(WARNING) << "DecompressFromFMWeight error! val size:" << val->size() << " "
      << "max_len:" <<max_len;
    return false;
  }
  fm_val->bitmap_[0] = fm_val->value_[0];
  fm_val->bitmap_[1] = fm_val->value_[1];
  size_t string_pos = 2;
  for (size_t i = 0; i < max_len; ++i) {
    if (fm_val->BitmapGet(i) != 0 && (string_pos + sizeof(float)) <= fm_val->value_.size()) {
      float temp_val = *(reinterpret_cast<float *> (&(fm_val->value_[string_pos])));
      val->at(i) = static_cast<double> (temp_val);
      string_pos += sizeof(float);
    } else {
      val->at(i) = 0.0;
    }
  }
  return true;
}

bool FMModel::Load(const std::string& dict_path) {
  map_.set_empty_key(0u);
  map_.max_load_factor(1.0);
  std::ifstream in_file(dict_path);
  if (!in_file.good()) {
    LOG(ERROR) << "Open file " << dict_path << " error.";
    return false;
  }
  std::string line;
  uint32 line_count = 0u;
  while (std::getline(in_file, line)) {
    std::vector<std::string> flds;
    base::SplitString(line, " \t", &flds);
    if (flds.size() != 2u && flds.size() != 2+v_dim_) {
      LOG(WARNING) << "Format error, fields size[" << flds.size()
        << "] v_dim[ " << v_dim_ << "], line[" << line << "].";
      return false;
    }

    uint64 key = 0u;
    std::vector<double> val(v_dim_+1, 0.0);
    FMWeight fm_val;
    if (!base::StringToUint64(flds[0], &key)) {
      LOG(WARNING) << "Format error[" << line << "].";
      return false;
    }
    for (size_t i = 1; i < flds.size(); ++i) {
      if (!base::StringToDouble(flds[i], &val[i-1])) {
        LOG(WARNING) << "Format error[" << line << "].";
        return false;
      }
    }
    fm_val.clear();
    if (true == CompressToFMWeight(&val, &fm_val, v_dim_+1)) {
      ++line_count;
      map_.insert(std::make_pair(key, fm_val.value_));
    }
  }
  if (!in_file.eof()) {
    LOG(ERROR) << "Read file " << dict_path << " error.";
    return false;
  }
  LOG(WARNING) << "Load FM model success, " << line_count << " line loaded.";
  LOG(WARNING) << "map size: "<< map_.size() << ", bucket: " << map_.bucket_count()
    << ", max_load_factor: " << map_.max_load_factor();
  return true;
}

void FMModel::FMPredict(const std::vector<uint64>* features,
                        const std::vector<std::string>* fea_literal,
                        double* sum_weight) {
  *sum_weight = 0.0;
  std::vector<double> v_sum(v_dim_, 0.0);
  std::vector<double> lookup_v(v_dim_ + 1, 0.0);
  for (size_t i = 0; i < features->size(); ++i) {
    double w = 0.0;
    const double* v = NULL;
    LookupWeight(features->at(i), &w, &v, &lookup_v);
    *sum_weight += w;
    for (size_t j = 0; j < v_dim_; ++j) {
      v_sum[j] += v[j];
      *sum_weight -= v[j] * v[j] * 0.5;
    }
  }
  for (size_t i = 0; i < v_sum.size(); ++i) {
    *sum_weight += v_sum[i] * v_sum[i] * 0.5;
  }
}

int32 FMModel::Predict(const std::vector<uint64>* features,
                       const std::vector<std::string>* fea_literal,
                       double* ctr) {
  double sum_weight = 0.0;
  FMPredict(features, fea_literal, &sum_weight);
  *ctr = wolong::model_server::LRScore(sum_weight);
  return 0;
}
}
}
