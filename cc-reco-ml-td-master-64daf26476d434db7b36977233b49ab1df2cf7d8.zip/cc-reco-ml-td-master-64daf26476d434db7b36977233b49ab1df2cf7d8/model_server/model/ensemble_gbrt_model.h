#pragma once

#include <string>
#include <vector>
#include <set>

#include "base/common/base.h"
#include "wolong/proto/gbrt_feature.pb.h"
#include "wolong/model_server/model/model.h"
#include "wolong/model_server/api/model_service.pb.h"
#include "wolong/model_server/strategy/feature_bucketing/cvm_data.h"
#include "wolong/model_server/strategy/feature_bucketing/mgbrt_data.h"

namespace wolong {
namespace model_server {

struct MultiVariateFeaStat {
  uint64 show;
  uint64 clk;
};

class EnsembleGbrtModel : public Model {
 public:
  EnsembleGbrtModel() : Model() {
    cvm_dict_ = NULL;
    ensemble_booster_ = NULL;
  }
  virtual ~EnsembleGbrtModel() {
    LOG(WARNING) << "Will Free Dict_Mem";
    delete cvm_dict_;
    delete ensemble_booster_;
  }
  virtual bool Initialize(const std::string& config_file);

  int32 Predict(const std::vector<uint64>* features,
                const std::vector<uint32>* feature_slots,
                const double lr_q,
                double* gbrt_q);
 private:
  bool Load(const std::string& dict_path);
  bool LoadModelTernary(const std::string& dict_path);
  bool LoadReservedFeaSet(const std::string& dict_path);
  void GenInstance(const std::vector<uint64>* features,
                   const std::vector<uint32>* feature_slots,
                   const double lr_q,
                   std::vector<double>* gbrt_ins) const;

  void GBRTPredict(const std::vector<double>& ins, double* sum_weight);
  Cvm_Dict* cvm_dict_;
  std::set<uint32> reserved_feaset_;
  mgbrt::predict::Booster* ensemble_booster_;
  std::string dict_dir_;
  std::string cvm_dict_name_, reserved_feaset_name_, ensemble_gbrt_model_name_;
 private:
  DISALLOW_COPY_AND_ASSIGN(EnsembleGbrtModel);
};
}  // namespace model_server
}  // namespace wolong
