#define private public
#include "wolong/model_server/model/dnn_model.h"

#include <limits>
#include <string>
#include <vector>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/logging.h"
#include "base/testing/gtest.h"

class DNNModelTest : public ::testing::Test {
 public:
  virtual void SetUp() {
    // model.Initialize("wolong/model_server/test_data/config/model/dnn/config");
    CHECK(model.Initialize(
        "wolong/model_server/test_data/config/model/dnn/config"))
        << "dnn_model init fail.";
  }
  virtual void TearDown() {}
  wolong::model_server::DNNModel model;
};

TEST_F(DNNModelTest, common) {
  EXPECT_TRUE(model.Load());
  EXPECT_TRUE(model.Load());
  EXPECT_TRUE(model.Load());
}

TEST_F(DNNModelTest, LoadCVM) {
  std::string filename = model.dict_path_base_ + model.cvm_dict_name_;
  LOG(INFO) << filename;
  EXPECT_TRUE(model.LoadCVM(filename));
  EXPECT_TRUE(model.LoadCVM(filename));
  EXPECT_TRUE(model.LoadCVM(filename));
}

TEST_F(DNNModelTest, LoadModelConfig) {
  std::string filename = model.dict_path_base_ + model.dnn_model_config_name_;
  LOG(INFO) << filename;
  EXPECT_TRUE(model.LoadModelConfig(filename));
  EXPECT_TRUE(model.LoadModelConfig(filename));
  EXPECT_TRUE(model.LoadModelConfig(filename));
}

TEST_F(DNNModelTest, LoadModel) {
  std::string filename = model.dict_path_base_ + model.dnn_model_name_;
  LOG(INFO) << filename;
  EXPECT_TRUE(model.LoadModel(filename));
  EXPECT_TRUE(model.LoadModel(filename));
  EXPECT_TRUE(model.LoadModel(filename));
  float value0_0_0 = model.layers_[0].W(0, 0);
  float value0_2_3 = model.layers_[0].W(3, 2);
  float value0_202_2 = model.layers_[0].b(2);
  float value5_128_0 = model.layers_[5].b(0);
  float value5_0_0 = model.layers_[5].W(0, 0);
  EXPECT_NEAR(value0_0_0, -0.320990, 0.0001);
  EXPECT_NEAR(value0_2_3, 0.084960, 0.0001);
  EXPECT_NEAR(value0_202_2, -4.775701, 0.0001);
  EXPECT_NEAR(value5_128_0, -1.528373, 0.0001);
  EXPECT_NEAR(value5_0_0, -0.143741, 0.0001);
  LOG(INFO) << model.layers_[0].W.rows() << " " << model.layers_[0].W.cols();

  uint32 sid = 33u;
  EXPECT_EQ(model.map_norm_[sid].index, 89);
  EXPECT_NEAR(model.map_norm_[sid].show_mean, 3.9702480415, 0.0000001);
  EXPECT_NEAR(model.map_norm_[sid].show_variance, 15.1548497108, 0.0000001);
  EXPECT_NEAR(model.map_norm_[sid].click_mean, 3.1736676237, 0.0000001);
  EXPECT_NEAR(model.map_norm_[sid].click_variance, 12.5543531665, 0.0000001);
  EXPECT_NEAR(model.map_norm_[sid].default_show, 0, 0.0000001);
  EXPECT_NEAR(model.map_norm_[sid].default_click, 0, 0.0000001);
}

TEST_F(DNNModelTest, GetConfValue) {
  double value;
  EXPECT_TRUE(model.GetConfValue("q_threshold", &value));
  EXPECT_NEAR(value, 0.01, 0.000001);
}

TEST_F(DNNModelTest, GenInstance) {
  std::vector<uint64> features;
  std::vector<uint32> features_slots;
  features.reserve(10);
  features_slots.reserve(10);
  features.push_back(10000038562905510364UL);
  features.push_back(10000134286155978446UL);
  features_slots.push_back(64);
  features_slots.push_back(64);
  features.push_back(10000181174809187879UL);
  features_slots.push_back(33);
  double lr_q = 0.5;
  std::vector<double> dnn_ins(201);
  model.GenInstance(&features, &features_slots, lr_q, &dnn_ins);
  EXPECT_EQ(dnn_ins.size(), 201u);
  EXPECT_NEAR(dnn_ins[0], -14.501809911810192, 0.000001);
  EXPECT_NEAR(dnn_ins[1], -16.126895235443865, 0.000001);
  EXPECT_NEAR(dnn_ins[2], -2.2898542022816066, 0.000001);
  EXPECT_NEAR(dnn_ins[3], -1.6665547109203342, 0.000001);
  EXPECT_NEAR(dnn_ins[178], -0.78788047735598288, 0.000001);
  EXPECT_NEAR(dnn_ins[179], -0.810743029217, 0.000001);
  EXPECT_NEAR(dnn_ins[200], 3.655337180059099, 0.000001);
  // for (uint32 i = 0; i < dnn_ins.size(); i++)
  //  std::cout << dnn_ins[i] << " ";
  // std::cout << "\n";
}

TEST_F(DNNModelTest, Predict) {
  std::vector<uint64> features;
  std::vector<uint32> features_slots;
  features.reserve(10);
  features_slots.reserve(10);
  features.push_back(10000038562905510364UL);
  features.push_back(10000134286155978446UL);
  features_slots.push_back(64);
  features_slots.push_back(64);
  features.push_back(10000181174809187879UL);
  features_slots.push_back(33);
  double lr_q = 0.5;
  double dnn_q = 0;
  EXPECT_EQ(model.Predict(&features, &features_slots, lr_q, &dnn_q), 0);
  EXPECT_NEAR(dnn_q, 0.00256561, 0.00001);
}

TEST_F(DNNModelTest, PredictInvalidInstance) {
  std::vector<uint64> features;
  std::vector<uint32> features_slots;
  double lr_q = 0.0;
  double dnn_q = 0;
  EXPECT_EQ(model.Predict(&features, &features_slots, lr_q, &dnn_q), -1);
  EXPECT_NEAR(dnn_q, 0, 0.0000001);
}
