#define private public
#include "wolong/model_server/model/ensemble_gbrt_model.h"

#include <limits>
#include <string>
#include <vector>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/logging.h"
#include "base/testing/gtest.h"

DECLARE_double(gbrt_average_ctr);

class EnsembleGbrtModelTest : public ::testing::Test {
 public:
  virtual void SetUp() {
    CHECK(ensemble_gbrt_model.Initialize(
        "wolong/model_server/test_data/config/model/ensemble_gbrt/config"))
        << "ensemble_gbrt_model init fail.";
  }
  virtual void TearDown() {}
  wolong::model_server::EnsembleGbrtModel ensemble_gbrt_model;
};

TEST_F(EnsembleGbrtModelTest, GenInstanceReserved) {
  const double default_value = FLAGS_gbrt_average_ctr;
  EXPECT_NEAR(default_value, -1.0, 0.0001);
  std::vector<uint64> features;
  std::vector<uint32> features_slots;
  features.reserve(10);
  features_slots.reserve(10);
  features.push_back(17394697368969963617UL);
  features.push_back(7978231228176381043UL);
  features.push_back(6068193539323497136UL);
  features_slots.push_back(16);
  features_slots.push_back(16);
  features_slots.push_back(16);
  features.push_back(16925053901752961011UL);
  features_slots.push_back(34);
  features.push_back(1139106401876931908UL);
  features_slots.push_back(1);
  features.push_back(10000793362047370529UL);
  features.push_back(6868561182533098719UL);
  features_slots.push_back(95);
  features_slots.push_back(95);
  features.push_back(9948114637485763872UL);
  features_slots.push_back(53);
  features.push_back(2896129378318444494UL);
  features_slots.push_back(55);
  features.push_back(15163459532614081074UL);
  features_slots.push_back(59);
  double lr_q = 0.0217;
  std::vector<double> gbrt_ins;
  ensemble_gbrt_model.GenInstance(&features, &features_slots, lr_q, &gbrt_ins);
  EXPECT_EQ(gbrt_ins.size(), 135u);
  EXPECT_NEAR(gbrt_ins[0], 0.0217, 0.0001);
  EXPECT_NEAR(gbrt_ins[1], 0.18182, 0.0001);
  EXPECT_NEAR(gbrt_ins[16], 0.00177, 0.0001);
  EXPECT_NEAR(gbrt_ins[34], 0.15038, 0.0001);
  EXPECT_NEAR(gbrt_ins[53], -1.0, 0.0001);
  EXPECT_NEAR(gbrt_ins[55], -1.0, 0.0001);
  EXPECT_NEAR(gbrt_ins[59], -1.0, 0.0001);
  EXPECT_NEAR(gbrt_ins[95], -1.0, 0.0001);
}

TEST_F(EnsembleGbrtModelTest, PredictReserved) {
  const double default_value = FLAGS_gbrt_average_ctr;
  EXPECT_NEAR(default_value, -1.0, 0.0001);
  std::vector<uint64> features;
  std::vector<uint32> features_slots;
  features.reserve(10);
  features_slots.reserve(10);
  features.push_back(17394697368969963617UL);
  features.push_back(7978231228176381043UL);
  features.push_back(6068193539323497136UL);
  features_slots.push_back(16);
  features_slots.push_back(16);
  features_slots.push_back(16);
  features.push_back(16925053901752961011UL);
  features_slots.push_back(34);
  features.push_back(1139106401876931908UL);
  features_slots.push_back(1);
  features.push_back(10000793362047370529UL);
  features.push_back(6868561182533098719UL);
  features_slots.push_back(95);
  features_slots.push_back(95);
  features.push_back(9948114637485763872UL);
  features_slots.push_back(53);
  features.push_back(2896129378318444494UL);
  features_slots.push_back(55);
  features.push_back(15163459532614081074UL);
  features_slots.push_back(59);
  double lr_q = 0.0217;
  double gbrt_q;
  ensemble_gbrt_model.Predict(&features, &features_slots, lr_q, &gbrt_q);
  EXPECT_NEAR(gbrt_q, 0.0198994, 0.0001);
}


TEST_F(EnsembleGbrtModelTest, GenInstanceInvalid) {
  std::vector<uint64> features;
  std::vector<uint32> features_slots;
  features.reserve(10);
  features_slots.reserve(10);
  features.push_back(17394697368969963617UL);
  features_slots.push_back(16);
  features.push_back(1139106401876931908UL);
  features_slots.push_back(1);
  features.push_back(15163459532614081074UL);
  double lr_q = 0.0217;
  std::vector<double> gbrt_ins;
  ensemble_gbrt_model.GenInstance(&features, &features_slots, lr_q, &gbrt_ins);
  EXPECT_EQ(gbrt_ins.size(), 0u);
}
