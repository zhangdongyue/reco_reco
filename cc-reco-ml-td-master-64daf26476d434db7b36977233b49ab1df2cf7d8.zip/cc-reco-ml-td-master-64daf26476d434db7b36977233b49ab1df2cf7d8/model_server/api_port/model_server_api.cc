#include "reco/ml/model_server/api_port/model_server_api.h"

#include  <algorithm>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"

namespace reco {
namespace model_server {

using namespace std;

DEFINE_string(model_server_machine_list, "test_model_server.yaml", "model server config file");
DEFINE_int32(model_server_timeout, 200, "model server timeout");
DEFINE_int32(model_server_retry, 0, "");

ModelServerAPI::ModelServerAPI() {
}

ModelServerAPI::~ModelServerAPI() {
}

void ModelServerAPI::Init() {
    serving_base::CommunicateConfig config("");
    config.file_name = FLAGS_model_server_machine_list;
    config.timeout = FLAGS_model_server_timeout;
    config.max_retry_times = FLAGS_model_server_retry;
    config.enable_heart_beat = false;
    config.heart_beat_timeout = 50;
    config.heart_beat_slow_times = 3;
    config.heart_beat_ignore_times = 50;
    config.total_timeout = FLAGS_model_server_timeout * FLAGS_model_server_retry;
    config.enable_child_reload = false;
    port_rpc_comm_.CreateCommunicator("PackagedSearch", config, FLAGS_model_server_timeout, 
            FLAGS_model_server_retry, FLAGS_model_server_timeout * FLAGS_model_server_retry);
}

bool ModelServerAPI::PackagedSearch(const reco::model_server::PackagedRequest &request,
                                    reco::model_server::PackagedResponse *p_response,
                                    const int &timeout_ms, const int &retry) {
    reco::model_server::PackagedRequest *p_request = const_cast<reco::model_server::PackagedRequest*>(&request);
    string err_msg;
    bool ret = port_rpc_comm_.CallMethod("PackagedSearch", p_request, p_response, &err_msg);
    if (!ret) {
        LOG(ERROR) << "PackagedSearch error, err msg:" << err_msg;
        return false;
    }
    return true;
}
}
}

