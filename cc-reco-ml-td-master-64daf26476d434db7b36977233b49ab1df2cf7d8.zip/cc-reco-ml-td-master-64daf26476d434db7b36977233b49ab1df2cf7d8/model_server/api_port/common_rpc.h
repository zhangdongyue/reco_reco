#pragma once

#include <string>
#include <vector>
#include "reco/ml/model_server/api_port/communicate_config.h"

namespace reco {
namespace common {

class PortRpcComm {
public:
    PortRpcComm();
    ~PortRpcComm();
    bool CallMethod(const std::string& method, void* request, void* response, std::string* err_msg);
    void CreateCommunicator(const std::string& method,
                            const serving_base::CommunicateConfig &comm_config,
                            int32 timeout,
                            int32 total_timeout,
                            int32 retry_times);
private:
    void* rpc_comm_;
    void* rpc_comm_conf_;
};



}
}
