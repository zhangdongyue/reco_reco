#pragma once
#include <string>
#include <vector>
#include "reco/bizc/proto_arpc/model_service.pb.h"
#include "reco/base/common/singleton.h"
#include "base/common/logging.h"
#include "reco/ml/model_server/api_port/common_rpc.h"

namespace reco {
namespace model_server {

DECLARE_int32(model_server_timeout);
DECLARE_int32(model_server_retry);



class ModelServerAPI {
 public:
  ModelServerAPI();
  ~ModelServerAPI();

  bool PackagedSearch(const reco::model_server::PackagedRequest &request,
                      reco::model_server::PackagedResponse *p_response,
                      const int &timeout_ms = FLAGS_model_server_timeout,
                      const int &retry = FLAGS_model_server_retry);

  void Init(void);

 private:
  reco::common::PortRpcComm port_rpc_comm_;
};

typedef reco::common::singleton_default<ModelServerAPI> ModelServerAPIIns;
}
}
