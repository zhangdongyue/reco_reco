#pragma once
#include <string>

#include "base/common/basic_types.h"

namespace serving_base {

struct CommunicateConfig {
  // 整个交互的超时时间, 单位 ms, default : 150
  int total_timeout;
  // 对于某一曾的单次通信的超时时间, 单位 ms, default : 100
  int timeout;
  // 对于每一层, 失败后的最大的重试次数, default : 1
  int max_retry_times;
  // 是否开启心跳，default: false
  bool enable_heart_beat;
  // 心跳超时时间, 单位 ms, default : 50
  int heart_beat_timeout;
  // 慢链接的判定阈值, 连续超时几次, default : 3
  int heart_beat_slow_times;
  // 慢链接时, 多少个心跳周期内不再连接, default : 50
  int heart_beat_ignore_times;
  // child config file name
  std::string file_name;
  // 子节点是否允许配置 reload
  bool enable_child_reload;

  explicit CommunicateConfig(const std::string &child_file_name) {}
};
}  // end of base
