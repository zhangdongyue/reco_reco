#include "reco/ml/model_server/api/model_server_api.h"

#include  <algorithm>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"

namespace reco {
namespace model_server {

DEFINE_string(model_server_machine_list, "test_model_server.yaml", "model server config file");
DEFINE_int32(model_server_timeout, 200, "model server timeout");
DEFINE_int32(model_server_retry, 0, "");

void RpcCompleteCallback(thread::BlockingVar<bool>* rpc_complete) {
  if (rpc_complete != NULL) {
    rpc_complete->TryPut(true);
  }
}

ModelServerAPI::ModelServerAPI() {
}

ModelServerAPI::~ModelServerAPI() {
  if (packaged_search_communicator_) {
    delete packaged_search_communicator_;
  }
}

void ModelServerAPI::Init() {
  serving_base::CommunicateConfig config("");
  config.file_name = FLAGS_model_server_machine_list;
  config.timeout = FLAGS_model_server_timeout;
  config.max_retry_times = FLAGS_model_server_retry;
  config.enable_heart_beat = false;
  config.heart_beat_timeout = 50;
  config.heart_beat_slow_times = 3;
  config.heart_beat_ignore_times = 50;
  config.total_timeout = FLAGS_model_server_timeout * FLAGS_model_server_retry;
  config.enable_child_reload = false;

  packaged_search_communicator_ = new PackagedSearchCommunicator(config,
                                     &reco::model_server::ModelService::PackagedSearch);

  CHECK_NOTNULL(packaged_search_communicator_);
}

bool ModelServerAPI::PackagedSearch(const reco::model_server::PackagedRequest &request,
                                    reco::model_server::PackagedResponse *p_response,
                                    const int &timeout_ms, const int &retry) {
  PackagedSearchCommunicator::RequestConfig config;
  config.method = PackagedSearchCommunicator::Random;
  config.timeout = timeout_ms;
  config.total_timeout = timeout_ms * retry;
  config.retry_times = retry;

  PackagedSearchCommunicator::ResponseCollection resp_collect;
  thread::BlockingVar<bool> rpc_complete;

  packaged_search_communicator_->RemoteCall(request, config, &resp_collect,
                                            NewCallback(&RpcCompleteCallback, &rpc_complete));
  rpc_complete.Take();

  if (!resp_collect.success) {
    LOG(ERROR) << "PackagedSearch resp_collect fail:" << request.sid();
    return false;
  }

  for (auto i = 0u; i < resp_collect.responses->size(); ++i) {
    reco::model_server::PackagedResponse *response_i = resp_collect.responses->at(i);
    if (response_i && response_i->code() == 0) {
      *p_response = *(response_i);
      VLOG(1) << "PackagedSearch API ok:" << request.sid();
      return true;
    }
  }

  LOG(ERROR) << "PackagedSearch all responses' codes err:" << request.sid();
  return false;
}
}
}
