#pragma once
#include <string>
#include <vector>
#include "net/rpc/rpc.h"
#include "serving_base/rpc_communicator/remote_caller.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/proto/model_service.pb.h"
#include "reco/base/common/singleton.h"

namespace reco {
namespace model_server {

DECLARE_int32(model_server_timeout);
DECLARE_int32(model_server_retry);

typedef serving_base::RemoteCaller<reco::model_server::ModelService::Stub,
                                   reco::model_server::PackagedRequest,
                                   reco::model_server::PackagedResponse>
                                   PackagedSearchCommunicator;

class ModelServerAPI {
 public:
  ModelServerAPI();
  ~ModelServerAPI();

  bool PackagedSearch(const reco::model_server::PackagedRequest &request,
                      reco::model_server::PackagedResponse *p_response,
                      const int &timeout_ms = FLAGS_model_server_timeout,
                      const int &retry = FLAGS_model_server_retry);

  void Init(void);

 private:
  PackagedSearchCommunicator* packaged_search_communicator_;
  DISALLOW_COPY_AND_ASSIGN(ModelServerAPI);
};

typedef reco::common::singleton_default<ModelServerAPI> ModelServerAPIIns;
}
}
