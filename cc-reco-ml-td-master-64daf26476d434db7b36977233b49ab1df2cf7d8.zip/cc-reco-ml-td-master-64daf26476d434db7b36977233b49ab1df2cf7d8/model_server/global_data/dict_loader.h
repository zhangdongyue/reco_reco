#pragma once
#include "base/file/file_path.h"
#include "base/common/basic_types.h"

namespace reco {
namespace model_server {
void LRModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void FMModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);

void TFModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt);
}
}
