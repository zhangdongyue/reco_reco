#include "reco/ml/model_server/global_data/dict_loader.h"

#include <fstream>
#include <iostream>
#include <utility>
#include <unordered_set>
#include <algorithm>
#include <vector>

#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/basic_types.h"
#include "base/strings/string_split.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "reco/base/dict_manager/dynamic_dict.h"
#include "reco/ml/model/fm_model.h"
#include "reco/ml/model/lr_model.h"
#include "reco/ml/model/tf.h"

namespace reco {
namespace model_server {

void OlmLRModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  ml::OlmMqDenseHashLRModel* model = new ml::OlmMqDenseHashLRModel();
  model->Initialize(file_path.value());

  boost::shared_ptr<ml::OlmMqDenseHashLRModel> ptr(model);
  reco::dm::DynamicDict<ml::OlmMqDenseHashLRModel>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<ml::OlmMqDenseHashLRModel>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
}

void FMModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  ml::UserItemFMModel* model = new ml::UserItemFMModel();
  model->Initialize(file_path.value());

  boost::shared_ptr<ml::UserItemFMModel> ptr(model);
  reco::dm::DynamicDict<ml::UserItemFMModel>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<ml::UserItemFMModel>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
}

void TFModelLoader(base::FilePath file_path, void* dict_address, bool* succ, int64* cnt) {
  *succ = false;
  *cnt = 0;

  ml::TFModel* model = new ml::TFModel();
  model->Initialize(file_path.value());

  boost::shared_ptr<ml::TFModel> ptr(model);
  reco::dm::DynamicDict<ml::TFModel>* dynamic_dict = reinterpret_cast<reco::dm::DynamicDict<ml::TFModel>* >(dict_address);  // NOLINT
  dynamic_dict->Swap(ptr);
  *succ = true;
}
}
}
