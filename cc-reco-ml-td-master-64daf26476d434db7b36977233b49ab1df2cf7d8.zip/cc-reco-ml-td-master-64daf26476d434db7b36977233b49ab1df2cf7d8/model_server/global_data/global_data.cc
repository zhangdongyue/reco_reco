#include "reco/ml/model_server/global_data/global_data.h"

#include <string>
#include <vector>
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/common/closure.h"

DEFINE_string(data_dir, "../data", "data dir");
DEFINE_bool(default_init, true, "默认初始化为 true 时,加载所有词典,为false时,由调用方自行加载词典,用于测试");

namespace reco {
namespace model_server  {

GlobalData::GlobalData() {}

void GlobalData::Init(thread::BlockingQueue<ModelSearcher*>* searcher_queue) {
  if (!FLAGS_default_init) return;
  searchers = searcher_queue;
  work_pool = new ::thread::ThreadPool(searchers->Size());

}

GlobalData::~GlobalData() {
  if (work_pool != NULL) {
    work_pool->JoinAll();
    delete work_pool;
  }
}
}
}  // namespace reco
