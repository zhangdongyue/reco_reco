#include <boost/shared_ptr.hpp>
#include <unordered_map>
#include <vector>

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_split.h"

#include "reco/base/dict_manager/dynamic_dict.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/ml/model_server/global_data/global_data.h"
#include "reco/ml/model_server/frame/model_searcher.h"

DECLARE_string(data_dir);
namespace reco {
namespace model_server {
TEST(GlobalDataTest, TestDictLoader) {
  FLAGS_data_dir = "../data";
  thread::BlockingQueue<ModelSearcher*>* searchers = new ::thread::BlockingQueue<ModelSearcher*>();
  for (int i = 0; i < 4; ++i) {
    searchers->Put(new ModelSearcher());
  }
  GlobalDataIns::instance().Init(searchers);

  boost::shared_ptr<const ml::TFModel > tf_model =
      GlobalDataIns::instance().GetTFModel();
  ASSERT_TRUE(tf_model.get() != NULL);
  
  ModelSearcher* searcher;
  while (searchers->Empty()) {
    searchers->Take(&searcher);
    delete searcher;
  }
}
}
}
