#pragma once

#include <string>
#include <vector>
#include "reco/base/common/atomic.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread.h"
#include "base/thread/blocking_queue.h"
#include "reco/base/common/singleton.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/ml/model/tf.h"

namespace reco {
namespace model_server {
class ModelSearcher;
struct PackagedRequestTaskUnit;
typedef ::thread::BlockingQueue<PackagedRequestTaskUnit*> TaskQueue;
class ModelSearcher;
// dicts need to reload, manage them with |DictManager| in |AdDataManager|
// static dicts, manage them with |GlobalData|
struct GlobalData {
  GlobalData();
  ~GlobalData();

  void Init(thread::BlockingQueue<ModelSearcher*>* seachers);

  TaskQueue packaged_task_queue;
  ::thread::ThreadPool* work_pool;
  thread::BlockingQueue<ModelSearcher*>* searchers;
};
typedef reco::common::singleton_default<GlobalData> GlobalDataIns;
}
}  // namespace reco
