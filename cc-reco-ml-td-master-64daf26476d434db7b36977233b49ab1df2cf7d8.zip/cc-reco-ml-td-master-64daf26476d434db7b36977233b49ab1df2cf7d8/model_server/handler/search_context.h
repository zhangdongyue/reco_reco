#pragma once

#include <string>
#include <unordered_map>
#include <vector>

#include "reco/base/common/atomic.h"
#include "base/common/base.h"
#include "reco/base/common/atomic.h"
#include "base/strings/string_number_conversions.h"

#include "serving_base/utility/timer.h"
#include "base/common/closure.h"
#include "reco/ml/model_server/handler/model_service_pb.h"

namespace reco {
namespace model_server  {

struct PackagedRequestContext {
  int32 request_index;
  const OneRequest* request;
  // use gbrt result as fea
  Features gbrt_features;
  const Features* common_feature;
  OneResponse* response;
};

struct PackagedRequestTaskUnit {
  int32 taskid;
  uint64 sid;
  std::vector<PackagedRequestContext> requests;
  serving_base::Timer timer;
  int64 max_time;
  int64 wait_time;
  int64 cost_time;
  int32 finished_item_num;
  int32 request_num;
  int32 finished_request_num;
  PackagedRequestTaskUnit() {
    sid = 0;
    max_time = 0;
    wait_time = 0;
    cost_time = 0;
    finished_item_num = 0;
    request_num = 0;
    finished_request_num = 0;
  }
  std::string print() {
    std::string info = "sid=" + base::Uint64ToString(sid);
    info.append(" taskid=" + base::IntToString(taskid));
    info.append(" item_num=" + base::UintToString(requests.size()));
    info.append(" max_time=" + base::Int64ToString(max_time));
    info.append(" wait_time=" + base::Int64ToString(wait_time));
    info.append(" cost_time=" + base::Int64ToString(cost_time));
    info.append(" finished_item_num=" + base::IntToString(finished_item_num));
    return info;
  }
};

struct PackagedSearchContext {
  const PackagedRequest* request;
  PackagedResponse* response;
  ::Closure* done;

  std::vector<PackagedRequestTaskUnit> tasks;
  int32 task_num;
  std::atomic_int unfinished_task_num;

  uint64 sid;
  int32 item_num;
  int32 finished_item_num;
  bool success;

  serving_base::Timer timer;
  int64 init_time;
  int64 split_time;
  int64 compute_time;
  int64 avg_wait_time;
  int64 max_wait_time;
  int64 total_wait_time;
  int64 package_time;
  int64 total_time;
  bool Initialize(const PackagedRequest* request,
                  PackagedResponse* response,
                  ::Closure* done);
};
}
}
