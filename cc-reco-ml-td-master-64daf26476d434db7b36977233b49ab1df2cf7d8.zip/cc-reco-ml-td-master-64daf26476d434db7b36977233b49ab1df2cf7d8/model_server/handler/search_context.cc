#include "reco/ml//model_server/handler/search_context.h"

namespace reco {
namespace model_server {

bool PackagedSearchContext::Initialize(const PackagedRequest* prequest,
                                       PackagedResponse* presponse,
                                       ::Closure* pdone) {
  request = prequest;
  response = presponse;
  done = pdone;

  task_num = 0;
  unfinished_task_num = 0;
  sid = request->sid();
  item_num = request->request_items_size();
  finished_item_num = 0;
  success = false;

  init_time = 0;
  split_time = 0;
  compute_time = 0;
  avg_wait_time = 0;
  max_wait_time = 0;
  total_wait_time = 0;
  package_time = 0;
  total_time = 0;
  return true;
}
}
}
