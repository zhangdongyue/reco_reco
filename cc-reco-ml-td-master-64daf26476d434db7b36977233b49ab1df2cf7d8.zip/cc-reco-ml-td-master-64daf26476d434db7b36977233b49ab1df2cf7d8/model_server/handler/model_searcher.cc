#include "reco/ml/model_server/handler/model_searcher.h"

#include <cygnet/cygnet.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <algorithm>
#include <string>

#include "base/strings/string_printf.h"
#include "reco/ml/model_server/global_data/global_data.h"
#include "reco/ml/model/model.h"
#include "reco/ml/model/lr_model.h"
#include "reco/ml/model/fm_model.h"
#include "reco/ml/model/tf.h"
#include "reco/ml/model_server/handler/search_context.h"
#include "reco/ml/model_server/component/model_manager.h"

namespace reco {
namespace model_server  {

DEFINE_int32(max_item_num_per_task, 100, "max_item_num_per_task");
DEFINE_int32(max_process_time, 30, "max_process_time, (ms)");
DEFINE_int32(max_feature_num, 200, "");

DEFINE_int64_counter(model_server, processed_request_num, 0, "");
DEFINE_int64_counter(model_server, request_item_num, 0, "");
DEFINE_int64_counter(model_server, finished_request_item_num, 0, "");
DEFINE_int64_counter(model_server, task_num, 0, "");

DEFINE_double_counter(model_server, total_time, 0.0, "");
DEFINE_double_counter(model_server, compute_time, 0.0, "");
DEFINE_double_counter(model_server, total_task_wait_time, 0.0, "");

ModelSearcher::ModelSearcher() {
}

ModelSearcher::~ModelSearcher() {
}

void ModelSearcher::ProcessPackagedRequest(const PackagedRequest* request,
                                           PackagedResponse* response,
        ::Closure* done) {
  PackagedSearchContext* c = new PackagedSearchContext;
  c->timer.Start();
  if (!c->Initialize(request, response, done)) {
    PackagedSearchDone(c);
    return;
  }
  c->init_time = c->timer.Interval();
  COUNTERS_model_server__processed_request_num.Increase(1);
  COUNTERS_model_server__request_item_num.Increase(c->item_num);

  SplitToTasks(c);
  c->split_time = c->timer.Interval();
  VLOG(1) << "sid=" << c->request->sid()
          << " request_item_num=" << c->item_num
          << " split_task_num=" << c->tasks.size();

  c->task_num = c->tasks.size();
  c->unfinished_task_num = c->task_num;
  COUNTERS_model_server__task_num.Increase(c->task_num);
  if (c->task_num <= 0) {
    LOG(ERROR) << "sid" << c->request->sid() << " task_num <= 0 after SplitToTasks";
    PackagedSearchDone(c);
    return;
  }

  int32 task_size = c->tasks.size();
  for (int32 i = 0; i < task_size; i++) {
    ::Closure* task =
        ::NewCallback(this, &ModelSearcher::ComputeOneTask, c, &(c->tasks[i]));
    c->tasks[i].timer.Start();
    GlobalDataIns::instance().work_pool->AddTask(task);
  }
}

void ModelSearcher::SplitToTasks(PackagedSearchContext* context) {
  int32 max_item_per_task = FLAGS_max_item_num_per_task;
  if (context->request->has_control_param()
      && context->request->control_param().has_max_item_num_per_task()) {
    max_item_per_task = context->request->control_param().max_item_num_per_task();
  }

  int32 max_process_time = FLAGS_max_process_time;
  if (context->request->has_control_param()
      && context->request->control_param().has_max_process_time()) {
    max_process_time = context->request->control_param().max_process_time();
  }

  int32 task_num = context->item_num / max_item_per_task;
  if (context->item_num % max_item_per_task != 0) {
    task_num++;
  }

  context->tasks.resize(task_num);
  for (int32 i = 0; i < task_num; i++) {
    auto& task = context->tasks[i];
    task.sid = context->request->sid();
    task.taskid = i;
    task.max_time = max_process_time;
    task.requests.reserve(max_item_per_task);
  }

  context->response->mutable_responses_items()->Reserve(context->item_num + 1);
  for (int32 i = 0; i < context->item_num; i++) {
    int32 task_id = i % task_num;
    PackagedRequestContext item;
    item.request_index = i;
    item.request = &(context->request->request_items(i));
    item.response = context->response->add_responses_items();
    item.response->set_user_id(context->request->request_items(i).user_id());
    item.common_feature = &(context->request->request_items(i).common_feature());

    context->tasks[task_id].requests.push_back(item);
  }
}

reco::ml::ModelPtr ModelSearcher::GetModel(const ModelInfo& model_info, const std::string& type) {
  const std::string& model_name = model_info.model_name();

  reco::ml::ModelPtr model = ModelManager::GetModelByName(model_name);
  if (model.get() == NULL) {
    LOG(ERROR) << "error in GetModelByName! model_name:" << model_info.model_name();
    return reco::ml::ModelPtr();
  }
  if (model->type() != type) {
    LOG(ERROR) << "error model_type! expect gbrt, model_name:" << model_info.model_name()
               << " real_type:" << type;
    return reco::ml::ModelPtr();
  }

  return model;
}

void ModelSearcher::ComputeLRRequest(const OneRequest* request,
                                     const Features& gbrt_feature,
                                     OneResponse* response) {
  serving_base::Timer timer;
  timer.Start();

  response->mutable_lr_responses()->Reserve(request->lr_requests_size() + 1);
  std::vector<uint64> feature_signs;
  feature_signs.reserve(FLAGS_max_feature_num);
  for (int32 i = 0; i < (int32)request->lr_requests_size(); i++) {
    feature_signs.clear();
    const LRRequest& lr_request = request->lr_requests(i);
    LRResponse* lr_response = response->add_lr_responses();
    reco::ml::ModelPtr model = GetModel(lr_request.model_info(), "lr_olm");
    if (model.get() == NULL) {
      lr_response->set_code(1);
      continue;
    }
    if (lr_request.request_items_size() > 1) {
      LOG(ERROR) << "lr request item > 1 in one request";
      continue;
    }

    // lr feature
    for (int32 j = 0;
         lr_request.request_items_size() == 1 && j < (int32)lr_request.request_items(0).feature_info_size();
         j++) {
      auto& feature_info = lr_request.request_items(0).feature_info(j);
      feature_signs.push_back(feature_info.sign());
    }

    double ctr;
    int show = 0;
    double weight;
    (static_cast<reco::ml::OlmDenseHashLRModel*>(model.get()))->Predict(feature_signs, &weight, &show, &ctr);
    lr_response->set_code(0);
    ModelResInfo* model_res_info = lr_response->add_response_items();
    model_res_info->set_q(ctr);
    model_res_info->set_confidence(show);
  }
  VLOG(2) << "ComputeLRRequest cost: " << timer.Stop()
          << " us";
}

void ModelSearcher::ComputeFMRequest(const OneRequest* request,
                                     const Features& user_fea,
                                     OneResponse* response) {
  if (request->fm_requests_size() == 0) {
    VLOG(1) << "empty request: ";
    return;
  }

  serving_base::Timer timer;
  timer.Start();
  response->mutable_fm_responses()->Reserve(request->fm_requests_size() + 1);
  std::vector<uint64> feature_signs;
  feature_signs.reserve(FLAGS_max_feature_num);


  for (int32 i = 0; i < (int32)request->fm_requests_size(); i++) {
    auto& fm_request = request->fm_requests(i);
    FMResponse* fm_response = response->add_fm_responses();
    reco::ml::ModelPtr model = GetModel(fm_request.model_info(), "fm_user");
    if (model.get() == NULL) {
      fm_response->set_code(1);
      return;
    }
    reco::ml::UserItemFMModel* fm_model = static_cast<reco::ml::UserItemFMModel*>(model.get());

    double ctr = 0;
    if (user_fea.feature_info_size() > 0) {
      feature_signs.clear();
      for (int32 j = 0; j < user_fea.feature_info_size(); ++j) {
        const FeatureInfo& feature_info = user_fea.feature_info(j);
        feature_signs.push_back(feature_info.sign());
      }
      reco::ml::FacMachineScore user_score;
      fm_model->CalcPartScore(feature_signs, &user_score);

      for (int32 j = 0; j < fm_request.request_items_size(); ++j) {
        feature_signs.clear();
        for (int32 k = 0; k < (int32)fm_request.request_items(j).feature_info_size(); ++k) {
          const FeatureInfo& feature_info = fm_request.request_items(j).feature_info(k);
          feature_signs.push_back(feature_info.sign());
        }
        bool succ = fm_model->Predict(user_score, fm_request.sid(), feature_signs, &ctr);
        if (succ) {
          fm_response->set_code(0);
          ModelResInfo* model_res_info = fm_response->add_response_items();
          model_res_info->set_q(ctr);
        }
      }
    } else if (fm_request.request_items_size() == 1) {
      feature_signs.clear();
      for (int32 j = 0; j < (int32)fm_request.request_items(0).feature_info_size(); j++) {
        const FeatureInfo& feature_info = fm_request.request_items(0).feature_info(j);
        feature_signs.push_back(feature_info.sign());
      }

      bool succ = fm_model->FMModel::Predict(feature_signs, &ctr);
      if (succ) {
        fm_response->set_code(0);
        ModelResInfo* model_res_info = fm_response->add_response_items();
        // LOG(INFO) << "ctr : " << ctr;
        model_res_info->set_q(ctr);
        // LOG(INFO) << "q: " <<model_res_info->q();
      }
    } else {
      LOG(ERROR) << "erro rquest";
    }
  }
  VLOG(2) << "ComputeFMRequest cost: " << timer.Stop()
          << " us";
}

void ModelSearcher::ComputeOneRequest(PackagedSearchContext* context, PackagedRequestContext* c) {
  // 模型计算过程
  // wide&deep (async) ==> lr ==> fm
  // TODO(xielang): wide deep 需要 fm score ？
  serving_base::Timer timer;
  timer.Start();
  const OneRequest* request = c->request;
  OneResponse* response = c->response;
  if (request->user_id() == 0) return;

  if (request->wide_deep_requests_size() > 0) {
    reco::ml::ModelPtr model = GetModel(request->wide_deep_requests(0).model_info(), "tf");
    reco::ml::TFModel* tf_model = static_cast<reco::ml::TFModel*>(model.get());
    if (tf_model == NULL) {
      LOG(ERROR) << "[fatal]: erro model name: " << request->wide_deep_requests(0).model_info().model_name();
      return;
    }
    tf_model->Predict(*request, *(c->common_feature), response);
    // LOG(INFO) << "after predict: " << context->request->sid() << " " << response->wide_deep_responses_size();
  }

  if (request->lr_requests_size() > 0) ComputeLRRequest(request, c->gbrt_features, response);

  if (request->fm_requests_size() > 0) ComputeFMRequest(request, *(c->common_feature), response);

  response->set_valid(1);
  // LOG(INFO) << "ComputeOneRequest cost: " << timer.Stop() << " us";
}

void ModelSearcher::ComputeOneTask(PackagedSearchContext* context,
                                   PackagedRequestTaskUnit* c) {
  c->wait_time = c->timer.Stop();

  for (int32 i = 0; i < (int32)c->requests.size(); i++) {
    int64 total_time = c->timer.Stop();
    if (total_time > c->max_time * 1000) break;
    ComputeOneRequest(context, &(c->requests[i]));
    c->finished_item_num++;
  }
  c->cost_time = c->timer.Stop() - c->wait_time;
  VLOG(1) << "task finished! info: " << c->print();

  if (--context->unfinished_task_num <= 0) {
    ::Closure* c = ::NewCallback(this, &ModelSearcher::ComputeDone, context);
    GlobalDataIns::instance().work_pool->AddTask(c);
  }
}

void ModelSearcher::ComputeDone(PackagedSearchContext* context) {
  context->compute_time = context->timer.Interval();
  COUNTERS_model_server__compute_time.Increase(((double)(context->compute_time)));
  // start package response
  int64 total_wait_time = 0;
  int64 avg_wait_time = 0;
  int64 max_wait_time = 0;
  for (int32 i = 0; i < (int32)context->tasks.size(); i++) {
    auto& task = context->tasks[i];
    total_wait_time += task.wait_time;
    if (task.wait_time > max_wait_time) {
      max_wait_time = task.wait_time;
    }
    context->finished_item_num += task.finished_item_num;
  }
  avg_wait_time = total_wait_time / context->tasks.size();
  context->max_wait_time = max_wait_time;
  context->avg_wait_time = avg_wait_time;
  context->total_wait_time = total_wait_time;
  COUNTERS_model_server__total_task_wait_time.Increase(((double)(total_wait_time)));
  COUNTERS_model_server__finished_request_item_num.Increase(context->finished_item_num);

  context->package_time = context->timer.Interval();
  // set success
  context->success = true;
  context->response->set_code(0);
  PackagedSearchDone(context);
}

void ModelSearcher::PackagedSearchDone(PackagedSearchContext* c) {
  std::string log_str = "";
  if (c->success) {
    log_str = "Model search success!";
  } else {
    log_str = "Model search error!";
  }
  c->total_time = c->timer.Stop();
  COUNTERS_model_server__total_time.Increase(((double)(c->total_time)));

  int finished_num = 0;
  if (c->response->responses_items_size() > 0) {
    finished_num = c->response->responses_items(0).wide_deep_responses_size();
  }

  int request_num = 0;
  if (c->request->request_items_size() > 0) {
    request_num = c->request->request_items(0).wide_deep_requests_size();
  }

  log_str = base::StringPrintf("%s sid=[%lu] item_num=[%d] finished_num=[%d]"
                               " task_num=[%d] init_time=[%ld] compute_time=[%ld]"
                               " avg_wait_time=[%ld] max_wait_time=[%ld]"
                               " total_time=[%ld] finished_num=[%d] request_num=[%d]", log_str.c_str(),
                               c->sid,
                               c->item_num,
                               c->finished_item_num,
                               c->task_num,
                               c->init_time,
                               c->compute_time,
                               c->avg_wait_time,
                               c->max_wait_time,
                               c->total_time,
                               finished_num,
                               request_num);
  {
    ScopedClosure scoped_closure(c->done);
  }
  LOG(INFO) << log_str;
  if (c) delete c;
  c = NULL;
  // std::unordered_map<std::string, reco::ml::ModelPtr>().swap(used_models_);
}
}  // namespace model server
}  // namespace reco
