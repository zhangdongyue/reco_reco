#if __cplusplus < 201103L
#include "reco/bizc/proto/model_service.pb.h"
#else
#include "reco/bizc/proto_arpc/model_service.pb.h"
#endif
