#pragma once

#include <vector>
#include <unordered_map>
#include <string>

#include "reco/base/common/atomic.h"
#include "base/common/base.h"
#include "serving_base/utility/timer.h"
#include "base/thread/sync.h"
#include "base/thread/blocking_queue.h"
#include "base/common/closure.h"
#include "base/thread/blocking_var.h"

#include "reco/ml/model/model.h"
#include "reco/ml/model_server/global_data/global_data.h"
#include "reco/ml/model_server/handler/model_service_pb.h"

namespace reco {
namespace model_server {
struct GlobalData;
struct PackagedSearchContext;
struct PackagedRequestContext;
// 处理一次检索请求,
// 不支持多线程, 一个请求一个实例
class ModelSearcher {
 public:
  ModelSearcher();
  ~ModelSearcher();

  // 处理一次请求
  void ProcessPackagedRequest(const PackagedRequest* request,
                              PackagedResponse* response,
                              ::Closure* done);
 private:
  void SplitToTasks(PackagedSearchContext* context);
  void ComputeOneTask(PackagedSearchContext* context, PackagedRequestTaskUnit* c);
  void ComputeOneRequest(PackagedSearchContext* context, PackagedRequestContext* c);
  void ComputeDone(PackagedSearchContext* context);
  void PackagedSearchDone(PackagedSearchContext* context);

 private:
  reco::ml::ModelPtr GetModel(const ModelInfo& model_ifo, const std::string& type);
  void ComputeLRRequest(const OneRequest* request, const Features& features, OneResponse* response);
  void ComputeFMRequest(const OneRequest* request, const Features& features, OneResponse* response);

 private:
  DISALLOW_COPY_AND_ASSIGN(ModelSearcher);
};
}  // namespace model_server
}  // namespace reco
