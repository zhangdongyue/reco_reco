#pragma once
#include <string>
#include <vector>
//#include "net/rpc/rpc.h"
//#include "serving_base/rpc_communicator/remote_caller.h"
//#include "net/rpc_util/rpc_group.h"
#include "base/common/logging.h"
#include "reco/bizc/proto_arpc/model_service.pb.h"
#include "reco/base/common/singleton.h"
#include "client_pool/ArpcClientPool.h"

namespace reco {
namespace model_server {

DECLARE_int32(model_server_timeout);
DECLARE_int32(model_server_retry);

class ModelServerAPI {
 public:
  ModelServerAPI();
  ~ModelServerAPI();

  bool PackagedSearch(const reco::model_server::PackagedRequest &request,
                      reco::model_server::PackagedResponse *p_response,
                      const int &timeout_ms = FLAGS_model_server_timeout,
                      const int &retry = FLAGS_model_server_retry);

  void Init(void);
  void Stop(void);

 private:
  arpc_client_pool::client_pool::ArpcClientPool<reco::model_server::ModelService_Stub>* model_service_pool_;

};

typedef reco::common::singleton_default<ModelServerAPI> ModelServerAPIIns;
}
}
