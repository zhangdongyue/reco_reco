#include "reco/ml/model_server/api_arpc/model_server_api.h"

#include  <algorithm>
#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"

namespace reco {
namespace model_server {

DEFINE_string(model_server_machine_list, "model_server_ip", "model server machine list");
DEFINE_int32(model_server_timeout, 500, "model server timeout");
DEFINE_int32(model_server_retry, 2, "");

using namespace arpc_client_pool::client_pool;

ModelServerAPI::ModelServerAPI() {
}

ModelServerAPI::~ModelServerAPI() {
}

void ModelServerAPI::Stop() {
  if (model_service_pool_) {
    delete model_service_pool_;
    model_service_pool_ = NULL;
  }
}

void ModelServerAPI::Init() {
  PoolParams params;

  std::vector<std::string> ips_vec;
  base::SplitString(FLAGS_model_server_machine_list, ",", &ips_vec);
  params.clientCount = 20 * (int)ips_vec.size();
  std::set<StubInfo> stub_info;
  for (const auto& ip_info : ips_vec) {
    std::vector<std::string> ip_port;
    base::SplitString(ip_info, ":", &ip_port);
    int port = 0;
    if (base::StringToInt(ip_port[1], &port)) {
      stub_info.insert(StubInfo(ip_port[0], port));
    }
  }

  model_service_pool_ = new ArpcClientPool<reco::model_server::ModelService_Stub>();
  if (!model_service_pool_->init(params, stub_info)) {
    LOG(FATAL) << "init model modelservice pool failed" << FLAGS_model_server_machine_list;
  }  
  LOG(INFO) << "init model modelservice pool succ " << FLAGS_model_server_machine_list;
}

bool ModelServerAPI::PackagedSearch(const reco::model_server::PackagedRequest &request,
                                    reco::model_server::PackagedResponse *p_response,
                                    const int &timeout_ms, const int &retry) {
  bool ret = false;
  int retryNum = retry;
  while (retryNum-- >= 0 && !ret) {
    arpc::ANetRPCController cntler;
    cntler.SetExpireTime(timeout_ms);
    cntler.SetErrorCode(arpc::ARPC_ERROR_NONE);

    auto stub_ptr = model_service_pool_->get();
    if (!stub_ptr) {
      base::SleepForMilliseconds(5);
      continue;
    }
    stub_ptr->stub()->PackagedSearch(&cntler, &request, p_response, NULL);
    int err_code = cntler.GetErrorCode();
    if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
      stub_ptr->setErrorCode(err_code);
      LOG(ERROR) << "rpc fail:" << err_code
        << " ip=" << stub_ptr->info().ip();
      continue;
    }

    ret = true;
    break;
  }

  if (!ret) {
    return false;
  }
  
  return true;
}

}
}
