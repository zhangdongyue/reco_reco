#include <cygnet/cygnet.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>
#include "base/common/logging.h"

using namespace cygnet;  // NOLINT

int main(int argc, char* argv[]) {
  if (argc < 4) {
    std::cerr << "usage: " << argv[0]
              << " type[http/https] spec uri data_file" << std::endl;
    return -1;
  }

  const std::string type(argv[1]);
  const std::string spec(argv[2]);
  const std::string uri(argv[3]);
  std::ifstream is(argv[4], std::ifstream::binary);
  char* buffer = NULL;
  int length = 0;
  if (is) {
    is.seekg(0, is.end);
    length = is.tellg();
    is.seekg(0, is.beg);
    buffer = new char[length];
    is.read(buffer, length);
    if (!is) {
      std::cerr << "error: only " << is.gcount() << " could be read";
      return -1;
    }
    is.close();
  }

  bool isSecure = type == "https";

  HttpTransport::TlsEnvironmentInit();
  HttpTransport transport(isSecure);

  HttpTransport::Config config;
  config._threadNum = 1;  // NOLINT

  if (!transport.Init(config)) {
    LOG(ERROR) << "init transport failed";
    return -1;
  }

  if (!transport.Start()) {
    LOG(ERROR) << "start transport failed";
    return -1;
  }

  HttpClientConnection* conn = transport.CreateConnection(spec, "", 0);
  if (conn == NULL) {
    LOG(ERROR) << "create connection failed";
    return -1;
  }

  HttpRequestPacket* requestPacket = HttpPacketFactory::CreateRequest();
  requestPacket->SetVersion(HV_11);
  requestPacket->SetMethod(HM_POST);
  requestPacket->SetUri(uri);
  requestPacket->AddHeader("Content-Type", "application/json");
  requestPacket->AppendBody(buffer, length);

  Packet* packet = NULL;
  if (!conn->Request(*requestPacket, 0, &packet)) {
    LOG(ERROR) << "request packet failed";
    requestPacket->Free();
    return -1;
  }

  if (packet->IsCmdPacket()) {
    LOG(ERROR) << "cmd packet recv";
    return -1;
  }

  HttpResponsePacket* responsePacket = dynamic_cast<HttpResponsePacket*>(packet);  // NOLINT
  assert(responsePacket != NULL);
  const std::vector<char>& msg = responsePacket->GetBody();
  std::cout << &msg[0] << std::endl;
  packet->Free();

  conn->Destroy();
  transport.Stop();
  transport.Destroy();

  HttpTransport::TlsEnvironmentDestroy();
  return 0;
}
