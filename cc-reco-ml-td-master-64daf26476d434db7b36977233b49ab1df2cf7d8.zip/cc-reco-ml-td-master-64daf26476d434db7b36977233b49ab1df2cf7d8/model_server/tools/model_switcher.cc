#include <string>
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/common/sleep.h"
#include "net/rpc/rpc.h"
#include "reco/ml/model_server/component/model_manager.pb.h"

DEFINE_string(model_server_ip, "sep by comma", "model server ips");
DEFINE_int32(model_server_port, 2000, "model server port");
DEFINE_string(model_name, "", "model name");

class DictSwitcher {
 public:
  bool DoSwitch();

 private:
  bool SwitchOneServer(const std::string &ip);

 private:
  thread::BlockingQueue<std::string> ip_queue_;
};

bool DictSwitcher::DoSwitch() {
  std::vector<std::string> ips;
  base::SplitString(FLAGS_model_server_ip, ",", &ips);
  for (int i = 0; i < (int)ips.size(); ++i) {
    ip_queue_.Put(ips[i]);
  }

  LOG(INFO) << "is list size:" << ip_queue_.Size();
  uint32 try_cnt = 0;
  std::string ip;
  while (!ip_queue_.Empty() && try_cnt < ips.size() * 3) {
    if (!ip_queue_.TryTake(&ip)) {
      continue;
    }

    ++try_cnt;
    if (!SwitchOneServer(ip)) {
      ip_queue_.Put(ip);
    }
  }

  if (ip_queue_.Empty()) {
    LOG(INFO) << "videoq model switch success";
    return true;
  } else {
    LOG(ERROR) << "videoq model switch fail";
    return false;
  }
}

bool DictSwitcher::SwitchOneServer(const std::string &ip) {
  LOG(INFO) << "model reload start:" << ip;
  net::rpc::RpcClientChannel::Options rpc_option;
  rpc_option.idle_timeout = 5000;
  net::rpc::RpcClientChannel channel(ip, FLAGS_model_server_port, rpc_option);
  if (!channel.Connect()) {
    LOG(ERROR) << "connect to server fail:" << ip;
    return false;
  }

  reco::model_server::ModelManagerService::Stub stub(&channel);
  reco::model_server::CommandRequest request;
  request.set_cmd("reload");
  request.set_model_name(FLAGS_model_name);
  reco::model_server::CommandResponse response;
  net::rpc::RpcClientController rpc_controller;
  stub.ExcuteCommand(&rpc_controller, &request, &response, NULL);
  rpc_controller.Wait();
  if (rpc_controller.GetRpcErrno() != net::rpc::kOk) {
    LOG(ERROR) << "rpc error " << ip << "[" << rpc_controller.error_text() << "]";
    return false;
  }

  if (response.code() == reco::model_server::RetCode::kOk) {
    LOG(INFO) << "response success " << ip;
  } else {
    LOG(ERROR) << "response fail " << ip << "[" << response.reason() << "]";
    return false;
  }

  LOG(INFO) << "model switch one success:" << ip;
  return true;
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  DictSwitcher switcher;
  if (!switcher.DoSwitch()) return -1;
  return 0;
}
