#include <vector>
#include <string>
#include <iostream>

#include "net/web_client/web_client.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/hash_function/city.h"
#include "base/time/timestamp.h"
#include "reco/ml/util/json.h"

#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"

DEFINE_string(input_file, "test.dat", "input file for http body");
DEFINE_string(url, "tf serving url", "");
DEFINE_int32(thread_num, 4, "thread num for sen request");

void Save(net::WebClient::Request* request,
          net::WebClient::Response* response,
          uint64 start,
          thread::Mutex* mutex) {
  uint64 end = base::GetTimestamp();
  LOG(INFO) << "start time: " << start << " spend ms: " << (end - start) / 1000;
  std::vector<double> probs;
  if (!reco::json::ParseTFServingResult(response->http_body, &probs)) {
    LOG(ERROR) << "parse probs failed: " << response->http_body;
    return;
  }

  std::string buf = request->body;
  for (size_t i = 0; i < probs.size(); ++i) {
    buf += "\n";
    base::AppendDoubleToString(probs[i], &buf);
  }
  mutex->Lock();
  std::cout << buf << std::endl;
  mutex->Unlock();

  delete response;
  delete request;
}

void SendWorker(thread::BlockingQueue<std::string>* request_queue) {
  net::WebClient::Options option;

  net::WebClient web_client(option);
  web_client.Init();
  thread::Mutex mutex;
  std::string body;
  while (!(request_queue->Closed() && request_queue->Empty())) {
    if (!request_queue->Take(&body)) break;
    net::WebClient::Request* request = new net::WebClient::Request();
    request->url = FLAGS_url;
    request->method = ::net::HTTPConstants::kPOST;
    request->body = body;

    uint64 timestamp = base::GetTimestamp();
    net::WebClient::Response* response = new net::WebClient::Response;
    web_client.AddTask(request, response, ::NewCallback(&Save, request, response, timestamp, &mutex));
  }
  LOG(INFO) << "finish reading.complete num:  " <<  web_client.CompletedNum()
            << " pendding: " << web_client.GetPendingNum();

  web_client.JoinAll();
  LOG(INFO) << "finish1";
}

void GenerateRequest(thread::BlockingQueue<std::string>* request_queue) {
  std::string buf;
  CHECK(base::file_util::ReadFileToString(base::FilePath(FLAGS_input_file), &buf));

  request_queue->Put(buf);

  request_queue->Close();
  LOG(INFO) << "finish reading remain " << request_queue->Size();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "model client");

  thread::BlockingQueue<std::string> request_queue;
  GenerateRequest(&request_queue);
  thread::ThreadPool pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(SendWorker, &request_queue));
  }

  pool.JoinAll();
  return 0;
}
