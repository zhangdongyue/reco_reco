#include <string>

#include "reco/base/zkconfig/cloud_setting.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"

DEFINE_string(zk_sockets, "11.251.203.133:2181,11.251.203.169:2181,11.251.203.239:2181,11.251.204.7:2181,11.251.204.18:2181", "zk address");  // NOLINT
DEFINE_string(zk_root, "/tf_serving", "zkroot");
DEFINE_string(zk_config, "video_ctr_predict_a4", "zkroot");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "zk test");
  reco::zkconfig::CloudSetting zk(FLAGS_zk_sockets.c_str(), FLAGS_zk_root.c_str());
  // zk.MonitorStringConfChange(FLAGS_zk_config.c_str());
  zk.MonitorChildrenChange(FLAGS_zk_config.c_str());
  std::vector<std::string> children;
  zk.GetChildren(FLAGS_zk_config.c_str(), &children);
  for (size_t i = 0; i < children.size(); ++i) {
    LOG(INFO) << "child: " << children[i];
  }
  std::string conf;
  if (zk.GetStringConf(FLAGS_zk_config.c_str(), &conf)) {
    LOG(INFO) << conf;
  }
  return 0;
}
