#include <string>
#include <vector>
#include <iostream>
#include <unordered_map>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/hash_function/city.h"

#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "reco/bizc/proto/model_service.pb.h"
#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"

DEFINE_string(model_server_ip, "sep by comma", "model server ips");
DEFINE_string(model_name, "lr", "model server ips");
DEFINE_string(model_type, "lr", "model server ips");
DEFINE_string(input_file, "test.dat", "only for tf useag");
DEFINE_string(static_fld_file, "static_fld.txt.", "static fld for fea");
DEFINE_int32(model_server_port, 2000, "model server port");
DEFINE_int32(user_fea_num, 0, "for test user item fm");
DEFINE_int32(thread_num, 16, "thread num for send request");
DEFINE_int32(batch_num, 128, "num of one request in one package request");
DEFINE_bool(is_fea_sign, false, "if set, fea is sign");

struct Result {
  uint64 item_id;
  double predict;
  int label;
  int ms;
  std::string text;
};

void SendWorker(thread::BlockingQueue<std::pair<reco::model_server::PackagedRequest, double> >* request_queue,
                thread::BlockingQueue<Result>* result_queue,
                thread::BlockingVar<int>* finish_num) {
  std::vector<std::string> ips;
  base::SplitString(FLAGS_model_server_ip, ",", &ips);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 2;
  options.timeout = 5000;
  for (int i = 0; i < (int)ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], FLAGS_model_server_port, options.timeout);
    options.servers.push_back(si);
  }

  net::rpc::RpcGroup channel(options);
  CHECK(channel.Connect());
  reco::model_server::ModelService::Stub stub(&channel);

  reco::model_server::PackagedResponse response;
  std::pair<reco::model_server::PackagedRequest, double> request_pair;
  Result result;
  while (!(request_queue->Closed() && request_queue->Empty())) {
    if (!request_queue->Take(&request_pair)) break;
    net::rpc::RpcClientController rpc;
    // LOG(INFO) << "request size: " << request_pair.first.request_items(0).wide_deep_requests_size();
    rpc.SetTimeout(100);
    stub.PackagedSearch(&rpc, &request_pair.first, &response, NULL);
    rpc.Wait();

    if (rpc.status() == net::rpc::RpcClientController::kDeadlineExceeded) {
      LOG(ERROR) << "timeout: ";
      continue;
    }

    if (rpc.status() != net::rpc::RpcClientController::kOk
        || response.code() != 0) {
      LOG(ERROR) << "failed: " << response.code();
      continue;
    }

    if (FLAGS_model_type == "lr_olm") {
      for (int i = 0; i < response.responses_items_size(); ++i) {
        result.item_id = response.responses_items(i).user_id();
        if (response.responses_items(i).lr_responses_size() < 1) {
          LOG(ERROR) << "empty lr response " << response.responses_items(i).user_id();
          continue;
        }
        const reco::model_server::LRResponse& lr_response = response.responses_items(i).lr_responses(0);
        if (lr_response.response_items_size() < 1) {
          LOG(ERROR) << "empty lr response items: " << response.responses_items(i).user_id();
          continue;
        }
        result.predict = lr_response.response_items(0).q() * 100;
        result.label = 0;
        result_queue->Put(result);
      }
    } else if (FLAGS_model_type == "fm_user") {
      for (int i = 0; i < response.responses_items_size(); ++i) {
        result.item_id = response.responses_items(i).user_id();
        if (response.responses_items(i).fm_responses_size() < 1) {
          LOG(ERROR) << "empty fm response " << response.responses_items(i).user_id();
          continue;
        }
        const reco::model_server::FMResponse& fm_response = response.responses_items(i).fm_responses(0);
        if (fm_response.response_items_size() < 1) {
          LOG(ERROR) << "empty fm response items: " << response.responses_items(i).user_id();
          continue;
        }
        result.predict = fm_response.response_items(0).q();
        result.label = request_pair.second;
        result_queue->Put(result);
      }
    } else if (FLAGS_model_type.find("tf") != std::string::npos) {
      LOG(INFO) << "response size: " << response.responses_items(0).wide_deep_responses_size();
      if (response.responses_items_size() == 0) {
        LOG(ERROR) << "empty reponse items";
      } else {
        for (int k = 0; k < response.responses_items_size(); ++k) {
          result.item_id = response.responses_items(k).user_id();
          if (response.responses_items(k).wide_deep_responses_size() < 1) {
            LOG(INFO) << "empty response for : " << result.item_id;
            continue;
          }
          for (int i = 0; i < response.responses_items(k).wide_deep_responses_size(); ++i) {
            const reco::model_server::WideDeepResponse& wide_deep_response = response.responses_items(k).wide_deep_responses(i);  // NOLINT
            if (wide_deep_response.response_items_size() < 1) {
              LOG(ERROR) << "empty fm response items: " << response.responses_items(i).user_id();
              continue;
            }
            result.predict = wide_deep_response.response_items(0).q();
            // parse for label from request
            const reco::model_server::Features& feas = request_pair.first.request_items(k).wide_deep_requests(i).request_items(0);  // NOLINT
            double label = 0;
            for (int j = 0; j < feas.feature_info_size(); ++j) {
              if (feas.feature_info(j).literal() == "label") {
                label = base::ParseDoubleOrDie(feas.feature_info(j).text());
                break;
              }
            }
            result.label = label;
            // LOG(INFO) << result.predict << " " << result.label;
            result.text = base::StringPrintf("%lu\t%lu", result.item_id,
                                             wide_deep_response.sid());
            result_queue->Put(result);
          }
        }
      }
    }
  }
  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    result_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

void SaveWorker(thread::BlockingQueue<Result>* result_queue) {
  Result result;
  int n = 0;
  while (!(result_queue->Closed() && result_queue->Empty())) {
    if (!result_queue->Take(&result)) break;
    std::cout << result.predict << "\t" << result.label << "\t" << result.text << std::endl;
    ++n;
  }
  LOG(INFO) << "out num: " << n;
}

void GenerateLRRequest(thread::BlockingQueue<std::pair<reco::model_server::PackagedRequest, double> >* request_queue) {  // NOLINT
  std::string line;
  std::vector<std::string> flds;
  std::vector<std::string> tokens;
  reco::model_server::PackagedRequest request;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 3u) continue;
    uint64 item_id = base::ParseUint64OrDie(tokens[0]);
    // int label = base::ParseIntOrDie(tokens[2]);
    flds.clear();
    base::SplitString(tokens[1], "`", &flds);
    request.Clear();
    reco::model_server::OneRequest* one_request = request.add_request_items();
    one_request->set_user_id(item_id);
    reco::model_server::LRRequest* lr_request = one_request->add_lr_requests();
    lr_request->mutable_model_info()->set_model_name(FLAGS_model_name);
    reco::model_server::Features* ins = lr_request->add_request_items();
    std::unordered_set<uint64> dict;

    for (size_t i = 0; i < flds.size(); ++i) {
      uint64 sign =0;
      if (FLAGS_is_fea_sign) {
        sign = base::ParseUint64OrDie(flds[i]);
      } else {
        sign = base::CityHash64(flds[i].c_str(), flds[i].size());
      }

      if (dict.find(sign) != dict.end()) continue;
      dict.insert(sign);

      reco::model_server::FeatureInfo* fea = ins->add_feature_info();
      fea->set_sign(sign);
      VLOG(1) << sign << " " << flds[i];
    }
    request_queue->Put(std::make_pair(request, 1.0));
  }
  request_queue->Close();
  LOG(INFO) << "finish reading remain " << request_queue->Size();
}

void GenerateFMRequest(thread::BlockingQueue<std::pair<reco::model_server::PackagedRequest, double> >* request_queue) {  // NOLINT
  uint64 id = 0;
  std::string line;
  std::vector<std::string> tokens;
  reco::model_server::PackagedRequest request;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t ", &tokens);
    if (tokens.size() < 3u) continue;
    request.Clear();
    reco::model_server::OneRequest* one_request = request.add_request_items();
    one_request->set_user_id(++id);

    reco::model_server::FMRequest* fm_request = one_request->add_fm_requests();
    fm_request->mutable_model_info()->set_model_name(FLAGS_model_name);
    reco::model_server::Features* ins = fm_request->add_request_items();
    std::unordered_set<uint64> dict;

    if (tokens.size() < 2) continue;

    double label = base::ParseDoubleOrDie(tokens[1]);
    if (label > 0) label = 1.0;

    for (size_t i = 2; i < tokens.size(); ++i) {
      size_t pos = tokens[i].find(":");
      if (pos == std::string::npos) continue;

      uint64 sign = base::ParseUint64OrDie(tokens[i].substr(0, pos));

      if (dict.find(sign) != dict.end()) continue;
      dict.insert(sign);

      reco::model_server::FeatureInfo* fea = ins->add_feature_info();
      fea->set_sign(sign);
      VLOG(1) << sign << " " << tokens[i];
    }
    request_queue->Put(std::make_pair(request, label));
  }
  request_queue->Close();
  LOG(INFO) << "finish reading remain " << request_queue->Size();
}

void GenerateWDRequest(thread::BlockingQueue<std::pair<reco::model_server::PackagedRequest, double> >* request_pool) {  // NOLINT
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_input_file), &lines));
 
  reco::model_server::PackagedRequest packaged_request;
  
  reco::model_server::OneRequest* one_request = NULL;
  reco::model_server::WideDeepRequest* wide_deep_request = NULL;
  reco::model_server::Features* ins = NULL;
  uint32 last_ins_start = 0;
  
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].size() < 3) continue;
    base::TrimWhitespaces(&lines[i]);

    if (i == (lines.size() - 1) || (lines[i][0] == '[' && lines[i][lines[i].size() - 1] == ']')) {
      if (last_ins_start < i) {
        one_request = packaged_request.add_request_items();
        one_request->set_user_id(1);

        wide_deep_request = one_request->add_wide_deep_requests();
        wide_deep_request->mutable_model_info()->set_model_name(FLAGS_model_name);
        ins = wide_deep_request->add_request_items();
        for (uint32 j = last_ins_start + 1; j < i; ++j) {
          size_t pos = lines[j].find("=0:");
          if (pos == std::string::npos) {
            continue;
          }

          std::string fea_key = lines[j].substr(0, pos);
          std::string fea_value = lines[j].substr(pos + 3);

          reco::model_server::FeatureInfo* fea = ins->add_feature_info();
          fea->set_literal(fea_key);
          fea->set_text(fea_value);
        }
        wide_deep_request->set_sid(11111);
        if (packaged_request.request_items_size() % FLAGS_batch_num == 0) {
          LOG(INFO) << "packaged " << packaged_request.request_items_size();
          request_pool->Put(std::make_pair(packaged_request, 10));
          packaged_request.Clear();
          packaged_request.set_sid(666);  // fucking 666
        }
      }
      last_ins_start = i;
    }
  }

  if (packaged_request.request_items_size() > 0) {
    LOG(INFO) << "packaged " << packaged_request.request_items_size();
    request_pool->Put(std::make_pair(packaged_request, 10));
  }

  LOG(INFO) << "finish reading remain " << request_pool->Size();
  request_pool->Close();
}

void GenerateWDUserRequest(thread::BlockingQueue<std::pair<reco::model_server::PackagedRequest, double> >* request_pool) {  // NOLINT
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_input_file), &lines));

  reco::model_server::PackagedRequest packaged_request;

  std::string last_user_id = "";
  reco::model_server::OneRequest* one_request = NULL;
  reco::model_server::WideDeepRequest* wide_deep_request = NULL;
  reco::model_server::Features* ins = NULL;
  uint32 last_ins_start = 0;

  std::unordered_set<std::string> skip_set;
  {
    std::vector<std::string> lines;
    CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_static_fld_file), &lines)) << FLAGS_static_fld_file;  // NOLINT
    for (size_t i = 0; i < lines.size(); ++i) {
      skip_set.insert(lines[i]);
    }
  }
  LOG(INFO) << "skip: " << skip_set.size();

  std::unordered_map<std::string, std::string> user_fea_dict;
  uint32 ins_num = 0;
  for (size_t i = 0; i <= lines.size(); ++i) {
    if (i < lines.size()) {
      if (lines[i].size() < 3) continue;
      base::TrimWhitespaces(&lines[i]);
      if (lines[i].substr(0, 7) == "user_id" && lines[i].substr(10) != last_user_id) {
        if (packaged_request.request_items_size() > 0) {
          for (auto it = user_fea_dict.begin(); it != user_fea_dict.end(); ++it) {
            reco::model_server::FeatureInfo* fea = one_request->mutable_common_feature()->add_feature_info();
            fea->set_literal(it->first);
            fea->set_text(it->second);
          }
          user_fea_dict.clear();

          request_pool->Put(std::make_pair(packaged_request, 1.0));
        }
        last_user_id = lines[i].substr(10);

        packaged_request.Clear();
        one_request = packaged_request.add_request_items();
        one_request->set_user_id(base::ParseUint64OrDie(last_user_id));
      }
    }

    if (i == lines.size() || (lines[i][0] == '[' && lines[i][lines[i].size() - 1] == ']')) {
      if (last_ins_start < i) {
        wide_deep_request = one_request->add_wide_deep_requests();
        wide_deep_request->mutable_model_info()->set_model_name(FLAGS_model_name);
        ins = wide_deep_request->add_request_items();
        ins_num += 1;

        uint64 item_id = 0;
        double label = 0;
        for (uint32 j = last_ins_start + 1; j < i; ++j) {
          size_t pos = lines[j].find("=0:");
          if (pos == std::string::npos) {
            continue;
          }
          std::string fea_key = lines[j].substr(0, pos);
          std::string fea_value = lines[j].substr(pos + 3);
          if (lines[j].find("user") == 0) {
            if (user_fea_dict.find(fea_key) == user_fea_dict.end()) {
              user_fea_dict[fea_key] = fea_value;
            }
            continue;
          }

          if (skip_set.find(fea_key) == skip_set.end()) {
            reco::model_server::FeatureInfo* fea = ins->add_feature_info();
            fea->set_literal(fea_key);
            fea->set_text(fea_value);
          }
          
          size_t id_pos = lines[j].find("item_id=");
          if (id_pos != std::string::npos && lines[j].size() > 10) {
            item_id = base::ParseUint64OrDie(lines[j].substr(id_pos + 10));
          }
          if (lines[j].find("label=0:") != std::string::npos) {
            label = base::ParseDoubleOrDie(lines[j].substr(8));
          }
        }
        wide_deep_request->set_sid(item_id);
      }
      last_ins_start = i;
    }
  }

  if (packaged_request.request_items_size() > 0) {
    for (auto it = user_fea_dict.begin(); it != user_fea_dict.end(); ++it) {
      reco::model_server::FeatureInfo* fea = one_request->mutable_common_feature()->add_feature_info();
      fea->set_literal(it->first);
      fea->set_text(it->second);
    }
    LOG(INFO) << packaged_request.Utf8DebugString();
    request_pool->Put(std::make_pair(packaged_request, 10));
  }

  LOG(INFO) << "finish reading remain " << ins_num;
  request_pool->Close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "model client");

  thread::BlockingQueue<std::pair<reco::model_server::PackagedRequest, double> > request_queue;
  thread::BlockingQueue<Result> result_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  thread::ThreadPool pool(1 + FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(SendWorker, &request_queue, &result_queue, &finish_num));
  }
  pool.AddTask(::NewCallback(SaveWorker, &result_queue));

  if (FLAGS_model_type == "lr_olm") GenerateLRRequest(&request_queue);
  if (FLAGS_model_type == "fm_user") GenerateFMRequest(&request_queue);
  if (FLAGS_model_type == "tf_user") GenerateWDUserRequest(&request_queue);
  if (FLAGS_model_type == "tf") GenerateWDRequest(&request_queue);
  pool.JoinAll();
}
