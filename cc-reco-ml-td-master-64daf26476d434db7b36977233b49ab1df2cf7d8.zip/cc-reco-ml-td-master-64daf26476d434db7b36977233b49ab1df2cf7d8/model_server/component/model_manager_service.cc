#include "reco/ml/model_server/component/model_manager_service.h"

#include <string>
#include "base/common/base.h"
#include "reco/ml/model_server/component/model_manager.h"

namespace reco {
namespace model_server {

void ModelManagerServiceImpl::ExcuteCommand(stumy::RpcController* controller,
                                            const CommandRequest *request,
                                            CommandResponse *response,
                                            Closure *done) {
  ScopedClosure scoped_closure(done);
  std::string reason;
  response->set_code(kInnerError);
  response->set_reason("Inner error!");
  if (request->cmd() != "reload") {
    response->set_code(kUnSupportedCmd);
    response->set_reason("Unsupported cmd!");
    return;
  }

  if (request->model_name().empty()) {
    response->set_code(kModelNameEmpty);
    response->set_reason("Model_name empty!");
    return;
  }

  {
    ::thread::AutoLock lock(&mutex_);
    if (loading_model_map_.count(request->model_name()) > 0
        && loading_model_map_.at(request->model_name())) {
      response->set_code(kModelLoading);
      response->set_reason("Model loading now!");
      return;
    }
    loading_model_map_[request->model_name()] = true;
  }

  bool success = ModelManager::ReloadModel(request->model_name());
  if (!success) {
    response->set_code(kModelLoadError);
    response->set_reason("Model load error!");
  } else {
    response->set_code(kOk);
  }

  {
    ::thread::AutoLock lock(&mutex_);
    loading_model_map_[request->model_name()] = false;
  }

  return;
}
}
}
