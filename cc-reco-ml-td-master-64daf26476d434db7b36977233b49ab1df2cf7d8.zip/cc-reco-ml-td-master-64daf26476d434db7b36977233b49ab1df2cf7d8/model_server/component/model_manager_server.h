#pragma once

#include "base/thread/internal/synchronization/lock.h"
#include "base/thread/thread.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"

#include "net/rpc/rpc.h"

namespace reco {
namespace model_server {

class ModelManager;
class ModelManagerServiceImpl;

class ModelManagerServer {
 public:
  ModelManagerServer(int port, thread::ThreadPool* init_pool);
  ~ModelManagerServer();

  void Start();
  void Stop();

 private:
  int port_;

  ModelManagerServiceImpl* service_;
  net::rpc::RpcServer* server_;
 private:
  DISALLOW_COPY_AND_ASSIGN(ModelManagerServer);
};
}
}
