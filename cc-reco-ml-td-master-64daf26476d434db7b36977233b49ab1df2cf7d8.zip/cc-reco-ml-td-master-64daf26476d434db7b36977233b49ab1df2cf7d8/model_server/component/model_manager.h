#pragma once

#include <string>
#include <vector>
#include <unordered_map>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/thread/sync.h"
#include "base/thread/thread_pool.h"

#include "reco/ml/model/model.h"
namespace reco {
namespace model_server {
class ModelManager {
 public:
  // initialize and release
  static bool Initialize(const std::string &root_file, thread::ThreadPool* init_pool);
  static void Release();
  // model get api
  static std::vector<reco::ml::ModelPtr> GetAllModel();
  static reco::ml::ModelPtr GetModelByName(const std::string &model_name);

  // model set api
  static bool ReloadModel(const std::string &name);

 private:
  static bool AddModel(const std::string &model_file);
  static void AddModelUnit(std::string model_file);

 private:
  static std::atomic_int unfinished_model_num_;
  static thread::Mutex mutex_;
  static std::unordered_map<std::string, reco::ml::ModelPtr> model_map_;
  static std::unordered_map<std::string, std::string> model_file_map_;

 private:
  DISALLOW_COPY_AND_ASSIGN(ModelManager);
};
}
}
