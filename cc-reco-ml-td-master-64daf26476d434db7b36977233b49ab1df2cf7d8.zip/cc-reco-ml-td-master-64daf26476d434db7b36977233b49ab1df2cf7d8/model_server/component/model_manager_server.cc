#include "reco/ml/model_server/component/model_manager_server.h"

#include "base/common/base.h"
#include "net/rpc/rpc.h"

#include "reco/ml/model_server/component/model_manager.h"
#include "reco/ml/model_server/component/model_manager_service.h"

DEFINE_string(root_config_file, "../config/model/config", "root model config");
DEFINE_int32(reload_model_thread_num, 2, "reload_model_thread_num");

namespace reco {
namespace model_server {

ModelManagerServer::ModelManagerServer(int port, thread::ThreadPool* init_pool) {
  port_ =  port;
  server_ = NULL;

  CHECK(reco::model_server::ModelManager::Initialize(FLAGS_root_config_file, init_pool))
      << "Initialize ModelManager error!";

  service_ = new ModelManagerServiceImpl();
  CHECK(service_ != NULL);
}

ModelManagerServer::~ModelManagerServer() {
  Stop();
  delete service_;
  reco::model_server::ModelManager::Release();
}

void ModelManagerServer::Start() {
  if (server_ != NULL) return;

  net::rpc::RpcServer::Options opt;
  opt.port = port_;
  opt.server_thread_num = FLAGS_reload_model_thread_num;
  opt.pump_thread_num = 1;
  server_ = new net::rpc::RpcServer(opt);
  CHECK(server_ != NULL);
  CHECK(server_->ExportService(service_));
  CHECK(server_->Start());
}

void ModelManagerServer::Stop() {
  if (server_ == NULL) return;

  server_->Stop();
  delete server_;
  server_ = NULL;
}
}
}
