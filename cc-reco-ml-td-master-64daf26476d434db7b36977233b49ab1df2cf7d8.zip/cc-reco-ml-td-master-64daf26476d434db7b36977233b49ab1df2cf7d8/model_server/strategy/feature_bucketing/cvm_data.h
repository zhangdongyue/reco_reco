#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <cmath>

#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/container/dense_hash_map.h"


struct FeaStat {
  uint32 show;
  uint32 clk;
};

class Cvm_Dict {
 public:
  Cvm_Dict() : fea_ctr_map_(NULL), str_cvm_(NULL) {}
  virtual ~Cvm_Dict() {
    delete fea_ctr_map_;
    delete str_cvm_;
  }
  bool Load(const std::string& dict_path);
  void LookupWeight(uint64 sign, uint32* show, uint32* clk) const;
 private:
  base::dense_hash_map<uint64, FeaStat>* fea_ctr_map_;
  std::string* str_cvm_;
};

