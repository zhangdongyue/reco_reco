#include "wolong/model_server/strategy/feature_bucketing/gbrt_feature.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <limits>
#include <cmath>
#include <map>

#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/hash_function/city.h"
#include "serving_base/net_logging/net_logging.h"

DEFINE_int32(ternary_tree_num, 45, "tree number");
DEFINE_int32(tree_branch, 2, "tree branch");
DEFINE_int32(tree_depth, 12, "tree depth");
DEFINE_int32(exp_id, 31, "gbrt model server exp id");
DEFINE_string(model_type, "xgboost", "gbrt model type");

DECLARE_double(gbrt_average_ctr);

bool GBRTFeature::Load(const std::string& gbrt_fea_dict_dir,
                       bool load_24_dim_ctr, bool load_7_dim_ctr) {
  delete booster_;
  booster_ = new mgbrt::predict::Booster(FLAGS_ternary_tree_num, FLAGS_tree_branch,
                                         FLAGS_tree_depth, FLAGS_model_type);
  delete ctr_map_24_;
  ctr_map_24_ = new StaticCtrMap;
  ctr_map_24_->set_empty_key(0u);

  delete ctr_map_7_;
  ctr_map_7_ = new StaticCtrMap;
  ctr_map_7_->set_empty_key(0u);

  delete ctr_data_24_;
  ctr_data_24_ = new std::string;

  delete ctr_data_7_;
  ctr_data_7_ = new std::string;

  std::string loaded_model;
  std::string loaded_ctr;
  std::string loaded_ctr_extended;
  if (FLAGS_model_type == "mgbrt") {
    loaded_model = gbrt_fea_dict_dir + "/gbrt_feature_bucketing.txt.ternary";
    loaded_ctr = gbrt_fea_dict_dir + "/gbrt_feature_bucketing.ctr";
  } else if (FLAGS_model_type == "xgboost") {
    loaded_model = gbrt_fea_dict_dir + "/xgboost_feature_bucketing.txt.ternary";
    loaded_ctr = gbrt_fea_dict_dir + "/gbrt_feature_bucketing.ctr";
    loaded_ctr_extended = gbrt_fea_dict_dir + "/gbrt_feature_bucketing.ctr.extended";
  } else {
    LOG(ERROR) << "Invalid model type ";
    return false;
  }
  if (!LoadModelTernary(loaded_model)) {
    LOG(ERROR) << "Load " << loaded_model << " fail!";
    return false;
  }
  LOG(WARNING) << "Load " << loaded_model << " success";

  if (load_24_dim_ctr && !LoadCtrData24Dim(loaded_ctr)) {
    LOG(ERROR) << "Load " << loaded_ctr << " fail!";
    return false;
  }
  LOG(WARNING) << "Load " << loaded_ctr
               << (load_24_dim_ctr ? " success" : " ignored");

  if (load_7_dim_ctr && !LoadCtrData7Dim(loaded_ctr_extended)) {
    LOG(ERROR) << "Load " << loaded_ctr_extended << " fail!";
    return false;
  }
  LOG(WARNING) << "Load " << loaded_ctr_extended
               << (load_7_dim_ctr ? " success" : " ignored");

  return true;
}

bool GBRTFeature::LoadModelTernary(const std::string& file_path) {
  CHECK(booster_->LoadTree(file_path));
  return true;
}

bool GBRTFeature::LoadCtrData24Dim(const std::string& file_path) {
  if (ctr_data_24_ != NULL) {
    delete ctr_data_24_;
  }
  ctr_data_24_ = new std::string();
  if (!base::file_util::ReadFileToString(file_path, ctr_data_24_)) {
    LOG(ERROR) << "Load " << file_path << " fail!";
    return false;
  }
  double sum_weight;
  if (!ctr_map_24_->Read(ctr_data_24_->data(), ctr_data_24_->size())) {
     LOG(ERROR) << "Load " << file_path << " fail!";
     return false;
  }
  // Warmup
  sum_weight = 0.0;
  for (auto it = ctr_map_24_->begin(); it != ctr_map_24_->end(); ++it) {
    sum_weight += it->second;
  }
  VLOG(4) << "sum weight(base) in model is " << sum_weight;
  LOG(INFO) << "Load " << file_path << " to Memory.";
  return true;
}

bool GBRTFeature::LoadCtrData7Dim(const std::string& file_path) {
  if (ctr_data_7_ != NULL) {
    delete ctr_data_7_;
  }
  ctr_data_7_ = new std::string();
  if (!base::file_util::ReadFileToString(file_path, ctr_data_7_)) {
    LOG(ERROR) << "Load " << file_path << " fail!";
    return false;
  }
  double sum_weight;
  if (!ctr_map_7_->Read(ctr_data_7_->data(), ctr_data_7_->size())) {
     LOG(ERROR) << "Load " << file_path << " fail!";
     return false;
  }
  // Warmup
  sum_weight = 0.0;
  for (auto it = ctr_map_7_->begin(); it != ctr_map_7_->end(); ++it) {
    sum_weight += it->second;
  }
  VLOG(4) << "sum weight(extend) in model is " << sum_weight;
  LOG(INFO) << "Load " << file_path << " to Memory.";
  return true;
}

double GBRTFeature::FindCtrData24Dim(const std::string& feature, double default_value,
                                     std::vector<GBRTPair>* gbrt_stat_pair) const {
  uint64_t hash_value = base::CityHash64(feature.data(), feature.size());
  DCHECK(ctr_data_24_ != NULL) << "BUG: this model not load";
  const StaticCtrMap* map = ctr_map_24_;
  auto it = map->find(hash_value);
  if (gbrt_stat_pair != NULL) {
    GBRTPair gbrt_pair;
    gbrt_pair.name = feature;
    gbrt_pair.value = it == map->end() ? default_value : it->second;
    gbrt_stat_pair->push_back(gbrt_pair);
  }
  return it == map->end() ? default_value : it->second;
}

double GBRTFeature::FindCtrData7Dim(const std::string& feature, double default_value,
                                    std::vector<GBRTPair>* gbrt_stat_pair) const {
  uint64_t hash_value = base::CityHash64(feature.data(), feature.size());
  DCHECK(ctr_data_7_ != NULL) << "BUG: this model not load";
  const StaticCtrMap* map = ctr_map_7_;
  auto it = map->find(hash_value);
  if (gbrt_stat_pair != NULL) {
    GBRTPair gbrt_pair;
    gbrt_pair.name = feature;
    gbrt_pair.value = it == map->end() ? default_value : it->second;
    gbrt_stat_pair->push_back(gbrt_pair);
  }
  return it == map->end() ? default_value : it->second;
}

double GBRTFeature::GetAvgCtr() const {
  double default_value = FLAGS_gbrt_average_ctr;
  return default_value;
}

std::vector<double> GBRTFeature::InsKeys2GBRTInput(const GBRTInsKeys& ins_key,
                                                   std::vector<GBRTPair>* gbrt_stat_pair) const {
  double default_value = FLAGS_gbrt_average_ctr;

  std::vector<double> result;
  result.reserve(256);

  result.push_back(FindCtrData24Dim("Ucid_" + ins_key.ucid, default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Query_" + ins_key.query, default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("IdeaId_" + base::Uint64ToString(ins_key.idea_id),
                               default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("PatternId_" + base::Uint64ToString(ins_key.pattern_id),
                               default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("PlanId_" + base::Uint64ToString(ins_key.plan_id),
                               default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("UnitId_" + base::Uint64ToString(ins_key.unit_id),
                               default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("UserId_" + base::Uint64ToString(ins_key.user_id),
                               default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("WinfoId_" + base::Uint64ToString(ins_key.winfo_id),
                               default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Word_" + ins_key.word, default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Query-IdeaId_" + ins_key.query + "-" +
                               base::Uint64ToString(ins_key.idea_id), default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Query-PatternId_" + ins_key.query + "-" +
                               base::Uint64ToString(ins_key.pattern_id),
                               default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Query-PlanId_" + ins_key.query + "-" +
                               base::Uint64ToString(ins_key.plan_id), default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Query-UnitId_" + ins_key.query + "-" +
                               base::Uint64ToString(ins_key.unit_id), default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Query-UserId_" + ins_key.query + "-" +
                               base::Uint64ToString(ins_key.user_id), default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Query-WinfoId_" + ins_key.query + "-" +
                               base::Uint64ToString(ins_key.winfo_id), default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Ucid-IdeaId_" + ins_key.ucid + "-" +
                               base::Uint64ToString(ins_key.idea_id), default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Ucid-PatternId_" + ins_key.ucid + "-" +
                               base::Uint64ToString(ins_key.pattern_id),
                               default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Ucid-PlanId_" + ins_key.ucid + "-" +
                               base::Uint64ToString(ins_key.plan_id), default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Ucid-UnitId_" + ins_key.ucid + "-" +
                               base::Uint64ToString(ins_key.unit_id), default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Ucid-UserId_" + ins_key.ucid + "-" +
                               base::Uint64ToString(ins_key.user_id), default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Ucid-WinfoId_" + ins_key.ucid + "-" +
                               base::Uint64ToString(ins_key.winfo_id), default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Ucid-Query_" + ins_key.ucid + "-" + ins_key.query,
                               default_value, gbrt_stat_pair));
  result.push_back(FindCtrData24Dim("Ucid-Word_" + ins_key.ucid + "-" + ins_key.word,
                               default_value, gbrt_stat_pair));
  result.push_back(ins_key.match_type);


  if (FLAGS_model_type == "xgboost") {
    result.push_back(FindCtrData7Dim("Hour_" + ins_key.day_hour,
                                 default_value, gbrt_stat_pair));
    result.push_back(FindCtrData7Dim("Showurl_" + ins_key.show_url,
                                 default_value, gbrt_stat_pair));
    result.push_back(FindCtrData7Dim("Hour-IdeaId_" + ins_key.day_hour +
                                 "-" + base::Uint64ToString(ins_key.idea_id),
                                 default_value, gbrt_stat_pair));
    result.push_back(FindCtrData7Dim("Hour-WinfoId_" + ins_key.day_hour + "-" +
                                 base::Uint64ToString(ins_key.winfo_id),
                                 default_value, gbrt_stat_pair));
    result.push_back(FindCtrData7Dim("Hour-Query_" + ins_key.day_hour + "-" + ins_key.query,
                                 default_value, gbrt_stat_pair));
    result.push_back(FindCtrData7Dim("Query-Showurl_" + ins_key.query + "-" + ins_key.show_url,
                                 default_value, gbrt_stat_pair));
    result.push_back(FindCtrData7Dim("Ucid-Showurl_" + ins_key.ucid + "-" + ins_key.show_url,
                                 default_value, gbrt_stat_pair));
  }
  return result;
}

void GBRTFeature::Append7DimGBRTInput(const GBRTInsKeys& ins_key, std::vector<GBRTPair>* gbrt_stat_pair,
                                      std::vector<double>* result) const {
  double default_value = FLAGS_gbrt_average_ctr;
  if (FLAGS_model_type == "xgboost") {
    result->push_back(FindCtrData7Dim("Hour_" + ins_key.day_hour,
                                  default_value, gbrt_stat_pair));
    result->push_back(FindCtrData7Dim("Showurl_" + ins_key.show_url,
                                  default_value, gbrt_stat_pair));
    result->push_back(FindCtrData7Dim("Hour-IdeaId_" + ins_key.day_hour +
                                  "-" + base::Uint64ToString(ins_key.idea_id),
                                  default_value, gbrt_stat_pair));
    result->push_back(FindCtrData7Dim("Hour-WinfoId_" + ins_key.day_hour + "-" +
                                  base::Uint64ToString(ins_key.winfo_id),
                                  default_value, gbrt_stat_pair));
    result->push_back(FindCtrData7Dim("Hour-Query_" + ins_key.day_hour + "-" + ins_key.query,
                                  default_value, gbrt_stat_pair));
    result->push_back(FindCtrData7Dim("Query-Showurl_" + ins_key.query + "-" + ins_key.show_url,
                                  default_value, gbrt_stat_pair));
    result->push_back(FindCtrData7Dim("Ucid-Showurl_" + ins_key.ucid + "-" + ins_key.show_url,
                                  default_value, gbrt_stat_pair));
  }
}

void GBRTFeature::GetGBRTFeature(const GBRTInsKeys& ins_key, std::vector<int>* result,
                                 std::vector<GBRTPair>* gbrt_stat_pair) const {
  std::vector<double> feas;
  feas = InsKeys2GBRTInput(ins_key, gbrt_stat_pair);
  booster_->Predict(feas, result);
}

void GBRTFeature::GetGBRTFeature(const std::vector<double>& ctr_value, std::vector<int>* result) const {
  booster_->Predict(ctr_value, result);
}

