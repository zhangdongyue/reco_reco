#include <fstream>
#include <cmath>
#include <limits>
#include <string>
#include "base/common/logging.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "wolong/model_server/strategy/feature_bucketing/mgbrt_data.h"
#include "reco/base/common/atomic.h"

DEFINE_double(gbrt_average_ctr, -1.0, "base average ctr");
DEFINE_double(epsilon, 0.000001, "numerical epsilon");

namespace mgbrt {
namespace predict {

Tree::Tree(int32 depth, int32 branch, const std::string& modeltype)
    : kDepth(depth), kBranch(branch), kNodeNum((powl(branch, depth + 1) - 1) / (branch - 1)),
      kModelType(modeltype) {
      nodes.resize(kNodeNum);
      nodes[0].splitValid = 1;
    }

Tree::~Tree() {}

bool Tree::BuildTree(const std::string& Serialization) {
  if (Serialization.empty()) return false;
  std::vector<std::string> terms;
  base::SplitStringWithOptions(Serialization, "\t", true, false, &terms);
  CHECK(nodes.size() >= (terms.size()))
      << "kNodeNum:" << kNodeNum << " Serizalization node nums:" << terms.size();
  for (size_t i = 0; i < terms.size(); ++i)
    if (!BuildNode(terms[i], &(nodes[i])))
      return false;
  return true;
}

bool Tree::BuildNode(const std::string& str, TreeNode* node) const {
  if (str.empty()) return false;
  CHECK(node) << "node is empty, tree: ";
  auto& workNode = *node;
  std::vector<std::string> terms;
  base::SplitStringWithOptions(str, ":", true, false, &terms);
  int num = 0;
  int nodId = atoi(terms[num++].c_str());
  if (kModelType == "mgbrt") {
    workNode.leftChildIdx = nodId * 3 + 1;
    workNode.rightChildIdx = nodId * 3 + 2;
    workNode.unknownChildIdx = nodId * 3 + 3;
  } else if (kModelType == "xgboost") {
    workNode.leftChildIdx = atoi(terms[num++].c_str());
    workNode.rightChildIdx = atoi(terms[num++].c_str());
    workNode.unknownChildIdx = atoi(terms[num++].c_str());
  } else {
    LOG(ERROR) << "Unknow kModelType[" << kModelType << "].";
    return false;
  }
  workNode.feaDimIdx = atoi(terms[num++].c_str());
  workNode.splitValue = atof(terms[num++].c_str());
  workNode.label = atof(terms[num++].c_str());
  workNode.splitValid = atol(terms[num++].c_str());
  VLOG(2) << "BUILDNODE:" << DumpTreeNode(*node);
  return true;
}

double Tree::Predict(const std::vector<double>& feature, int32* node) const {
  int deep = 0;
  int nod = 0;
  while (deep < this->kDepth) {
    ++deep;
    auto& workNode = nodes[nod];
    int32 feaId = workNode.feaDimIdx;
    double feaVal = workNode.splitValue;
    if (workNode.splitValid == 0) {
      *node = nod;
      return workNode.label;
    }
    double gap = feature[feaId] - FLAGS_gbrt_average_ctr;
    if (std::fabs(gap) < FLAGS_epsilon) {
      nod = workNode.unknownChildIdx;
      VLOG(2) << nod << std::endl;
      continue;
    }
    if (kModelType == "mgbrt") {
      if (feature[feaId] <= feaVal) {
        nod = workNode.leftChildIdx;
      } else {
        nod = workNode.rightChildIdx;
      }
    } else if (kModelType == "xgboost") {
      if (feature[feaId] < feaVal) {
        nod = workNode.leftChildIdx;
      } else {
        nod = workNode.rightChildIdx;
      }
    } else {
      LOG(ERROR) << " unrecognized modeltype ";
    }
  }
  *node = nod;
  return nodes[nod].label;
}

Booster::Booster(int32 treeNum, int32 branch, int32 depth, const std::string& modeltype)
  : treeNum_(treeNum), treeBranch_(branch), treeDepth_(depth), treeModelType_(modeltype) {
  trees_.resize(treeNum);
  for (int32 i = 0; i < treeNum; ++i)
    trees_[i].reset(new Tree(treeDepth_, treeBranch_, treeModelType_));
}

bool Booster::LoadTree(const std::string& filename) {
  std::ifstream ifile(filename);
  if (!(ifile.is_open())) {
    LOG(ERROR) << "load tree failed, tree filename path:" << filename;
    return false;
  }
  std::string treeSeri;
  int32 treeIdx = 0;
  while (std::getline(ifile, treeSeri)) {
    CHECK(trees_[treeIdx]->BuildTree(treeSeri));
    treeIdx += 1;
    VLOG(1) << "load tree success, tree:" << treeIdx;
  }
  ifile.close();
  return true;
}

double Booster::Predict(const std::vector<double>& feaInfos, std::vector<int32>* nods) const {
  CHECK(nods) << "return nods is NULL!";
  for (uint32 i = 0; i < feaInfos.size(); ++i) {
    VLOG(2) << feaInfos[i];
  }
  nods->resize(treeNum_);
  double sum = 0;
  for (int32 i = 0; i < treeNum_; ++i) {
    sum += trees_[i]->Predict(feaInfos, &(nods->at(i)));
  }
  return sum;
}
}
}
