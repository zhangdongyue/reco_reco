#include "wolong/model_server/strategy/feature_bucketing/data.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>

#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"

bool Tree::SetTree(const std::string &str) {
  std::vector<std::string> parts;
  std::vector<std::string> terms;
  parts.clear();
  base::SplitStringWithOptions(str, ",", true, true, &parts);
  CHECK_GT(parts.size(), 0u);
  nodes_.resize(parts.size());
  int node_id;
  for (uint32 i = 0; i < parts.size(); ++i) {
    terms.clear();
    base::SplitStringWithOptions(parts[i], ":", true, true, &terms);
    CHECK_EQ(terms.size(), 4u);
    CHECK(base::StringToInt(terms[0], &node_id));
    CHECK_EQ((int) i, node_id);
    CHECK(base::StringToInt(terms[1], &(nodes_[i].feature_id)));
    CHECK(base::StringToDouble(terms[2], &(nodes_[i].split_value)));
    CHECK(base::StringToDouble(terms[3], &(nodes_[i].label)));
  }
  return true;
}

double Tree::GetLabel(const std::vector<double> &feas) const {
  int node = 0;
  double label = 0;
  while (node < (int) nodes_.size()) {
    label = nodes_[node].label;
    if (nodes_[node].feature_id < 0 || nodes_[node].feature_id >= (int)feas.size()) break;
    double value = 0.0;
    value = feas[nodes_[node].feature_id];
    if (value < nodes_[node].split_value) {
      node = 2 * node + 1;
    } else {
      node = 2 * node + 2;
    }
  }
  return label;
}

int Tree::GetNode(const std::vector<double> &feas) const {
  int node = 0;
  while (node < (int) nodes_.size()) {
    if (nodes_[node].feature_id < 0 || nodes_[node].feature_id >= (int)feas.size()) break;
    double value = 0.0;
    value = feas[nodes_[node].feature_id];
    if (value < nodes_[node].split_value) {
      node = 2 * node + 1;
    } else {
      node = 2 * node + 2;
    }
  }
  return node;
}

int Tree::GetValidNodeNum() const {
  int num = 0;
  for (auto it = nodes_.begin(); it != nodes_.end(); ++it) {
    num += (it->feature_id >= 0) ? 1 : 0;
  }
  return 2 * num + 1;
}

bool Forest::AddTree(const std::string &str) {
  trees_.push_back(Tree());
  return trees_.back().SetTree(str);
}

double Forest::GetLabel(const std::vector<double> &feas) const {
  double label = 0.0;
  for (int i = 0; i < tree_num_; ++i) {
    label += trees_[i].GetLabel(feas);
  }
  // label = 1.0 / (1.0 + exp(-label));
  return label;
}

bool Forest::Check() const {
  if (trees_.size() == 0u)
    return false;
  const int kTreeNodeNumber = trees_[0].GetNodeNum();
  for (auto it = trees_.begin(); it != trees_.end(); ++it) {
    if (it->GetNodeNum() != kTreeNodeNumber)
      return false;
  }
  return true;
}

double Forest::GetAverageValidNodeNum(const int tree_num) const {
  int tnum = (tree_num > (int) trees_.size()) ? tree_num : (int) trees_.size();
  int num = 0;
  for (int i = 0; i < tnum; ++i) {
    num += trees_[i].GetValidNodeNum();
  }
  return (double) num / (double) tnum;
}

std::vector<int> Forest::GetNodeVec(const std::vector<double> &feas) const {
  std::vector<int> node_vec(tree_num_);
  for (int i = 0; i < tree_num_; ++i) {
    node_vec[i] = trees_[i].GetNode(feas);
  }
  return node_vec;
}
