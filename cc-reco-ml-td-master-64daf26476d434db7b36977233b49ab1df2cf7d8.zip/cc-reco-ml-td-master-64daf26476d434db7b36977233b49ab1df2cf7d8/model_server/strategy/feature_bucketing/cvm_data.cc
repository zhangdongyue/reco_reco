#include "wolong/model_server/strategy/feature_bucketing/cvm_data.h"

bool Cvm_Dict::Load(const std::string& dict_path) {
  if (NULL != str_cvm_) delete str_cvm_;
  str_cvm_ = new std::string();
  if (NULL != fea_ctr_map_) delete fea_ctr_map_;
  fea_ctr_map_ = new base::dense_hash_map<uint64, FeaStat>();
  fea_ctr_map_->set_empty_key(0u);
  if (!base::file_util::ReadFileToString(dict_path, str_cvm_)) {
    LOG(ERROR) << "Load " << dict_path << " fail!";
    return false;
  }
  if (!fea_ctr_map_->Read(str_cvm_->data(), str_cvm_->size())) {
    LOG(ERROR) << "Load " << dict_path << " fail!";
    return false;
  }
  LOG(WARNING) << "Load " << dict_path << " to memory.";
  return true;
}

void Cvm_Dict::LookupWeight(uint64 sign, uint32* show, uint32* clk) const {
  *show = 0u;
  *clk = 0u;
  if (sign == 0u) return;
  auto ctr_it = fea_ctr_map_->find(sign);
  if (ctr_it != fea_ctr_map_->end()) {
    *show = ctr_it->second.show;
    *clk = ctr_it->second.clk;
  }
}

