#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>
#include <map>

#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/container/dense_hash_map.h"
#include "wolong/model_server/strategy/feature_bucketing/data.h"
#include "wolong/model_server/strategy/feature_bucketing/mgbrt_data.h"

typedef base::dense_hash_map<uint64, double> StaticCtrMap;

class GBRTFeature {
 public:
  GBRTFeature() : booster_(NULL),
    ctr_map_24_(NULL), ctr_map_7_(NULL),
    ctr_data_24_(NULL), ctr_data_7_(NULL) {}
  ~GBRTFeature() {
    delete booster_;
    delete ctr_map_24_;
    delete ctr_map_7_;
    delete ctr_data_24_;
    delete ctr_data_7_;
  }
  bool Load(const std::string& dict_dir, bool load_24_dim_ctr, bool load_7_dim_ctr);

  double GetAvgCtr() const;

  void GetGBRTFeature(const GBRTInsKeys& ins_key, std::vector<int>* result,
                      std::vector<GBRTPair>* gbrt_stat_pair) const;

  // 不需要 FindCtr 的版本
  void GetGBRTFeature(const std::vector<double>& ctr_value, std::vector<int>* result) const;
  // |gbrt_pair| can be NULL
  void Append7DimGBRTInput(const GBRTInsKeys& ins_key, std::vector<GBRTPair>* gbrt_pair,
                           std::vector<double>* ctr_value) const;

 private:
  bool LoadModelTernary(const std::string& file_path);
  bool LoadCtrData24Dim(const std::string& file_path);
  bool LoadCtrData7Dim(const std::string& file_path);
  bool LoadFiltedFeaSet(const std::string& file_path);
  double FindCtrData24Dim(const std::string& feature, double default_value,
                          std::vector<GBRTPair>* gbrt_stat_pair = NULL) const;
  double FindCtrData7Dim(const std::string& feature, double default_value,
                         std::vector<GBRTPair>* gbrt_stat_pair = NULL) const;

  std::vector<double> InsKeys2GBRTInput(const GBRTInsKeys& ins_key, std::vector<GBRTPair>*) const;

  mgbrt::predict::Booster* booster_;
  StaticCtrMap* ctr_map_24_;
  StaticCtrMap* ctr_map_7_;
  std::string* ctr_data_24_;
  std::string* ctr_data_7_;
};

