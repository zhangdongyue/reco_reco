#pragma once

#include <boost/shared_ptr.hpp>
#include <iostream>
#include <vector>
#include <string>
#include "base/common/base.h"
#include "base/strings/string_printf.h"

namespace mgbrt {
namespace predict {
struct TreeNode {
  int32 leftChildIdx;
  int32 rightChildIdx;
  int32 unknownChildIdx;
  int32 feaDimIdx;
  double splitValue;
  double label;
  int64 splitValid;
};

inline std::string DumpTreeNode(const TreeNode& treeNode) {
  return base::StringPrintf("%d:%lf:%lf:%ld",
                            treeNode.feaDimIdx, treeNode.splitValue,
                            treeNode.label, treeNode.splitValid);
}

class Tree {
 public:
  Tree(int32 depth, int32 branch, const std::string& modeltype);
  ~Tree();
  bool BuildTree(const std::string& serialization);
  bool BuildNode(const std::string& str, TreeNode* node) const;
  double Predict(const std::vector<double>& feature, int32* node) const;
 public:
  std::vector<TreeNode> nodes;
  const int32 kDepth;
  const int32 kBranch;
  const int32 kNodeNum;
  const std::string kModelType;
};

class Booster {
 public:
  Booster(int32 treeNum, int32 branch, int32 depth, const std::string& modeltype);
  ~Booster() {}
  bool LoadTree(const std::string& filename);
  double Predict(const std::vector<double>& feaInfos, std::vector<int32>* nods) const;
 private:
  int32 treeNum_;
  int32 treeBranch_;
  int32 treeDepth_;
  std::string treeModelType_;
  std::vector<boost::shared_ptr<Tree> > trees_;
  DISALLOW_COPY_AND_ASSIGN(Booster);
};
}
}
