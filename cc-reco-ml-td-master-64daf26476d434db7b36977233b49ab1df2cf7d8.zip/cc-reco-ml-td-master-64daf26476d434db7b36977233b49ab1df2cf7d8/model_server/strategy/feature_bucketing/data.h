#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <cmath>

#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"

struct GBRTInsKeys {
  uint64_t idea_id;
  uint64_t pattern_id;
  uint64_t plan_id;
  uint64_t unit_id;
  uint64_t user_id;
  uint64_t winfo_id;
  uint32_t match_type;
  std::string ucid;
  std::string query;
  std::string word;
  std::string day_hour;
  std::string show_url;
};

struct GBRTPair {
  std::string name;
  float value;
};

class Tree {
 public:
  bool SetTree(const std::string &str);
  double GetLabel(const std::vector<double> &feas) const;
  int GetNode(const std::vector<double> &feas) const;
  int GetNodeNum() const { return (int) nodes_.size(); }
  int GetValidNodeNum() const;

 private:
  struct TreeNode {
    int feature_id;
    double split_value;
    double label;
  };
  std::vector<TreeNode> nodes_;
};

class Forest {
 public:
  Forest() { trees_.clear(); }
  bool AddTree(const std::string &str);
  double GetLabel(const std::vector<double> &feas) const;
  std::vector<int> GetNodeVec(const std::vector<double> &feas) const;
  int GetTreeNum() const { return (int) trees_.size(); }
  double GetAverageValidNodeNum(const int tree_num) const;
  bool Check() const;
  int32_t tree_num_;
 private:
  std::vector<Tree> trees_;
};
