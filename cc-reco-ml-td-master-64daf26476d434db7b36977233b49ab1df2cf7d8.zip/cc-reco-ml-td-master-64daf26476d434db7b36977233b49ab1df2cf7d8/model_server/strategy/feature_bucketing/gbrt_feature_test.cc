#define private public
#include "wolong/model_server/strategy/feature_bucketing/gbrt_feature.h"

#include <limits>
#include <string>
#include <unordered_map>
#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

DECLARE_double(gbrt_average_ctr);

class GBRTFeatureTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    gbrt_feature_ = new GBRTFeature;
    CHECK(gbrt_feature_->Load("wolong/model_server/test_data", true, true));
  }

  virtual void TearDown() {
    delete gbrt_feature_;
  }

  GBRTFeature* gbrt_feature_;
};


TEST_F(GBRTFeatureTest, FindCtrData) {
  const double default_value = FLAGS_gbrt_average_ctr;
  EXPECT_NEAR(default_value, -1.0, 0.0001);

  std::string feature = "IdeaId_50000000004642784";
  double value = gbrt_feature_->FindCtrData24Dim(feature, default_value);
  EXPECT_NEAR(value, 0.1281, 0.0001);
  feature = "WinfoId_105659967";
  value = gbrt_feature_->FindCtrData24Dim(feature, default_value);
  EXPECT_NEAR(value, 0.1647, 0.0001);
  feature = "Ucid_8988068962";
  value = gbrt_feature_->FindCtrData24Dim(feature, default_value);
  EXPECT_NEAR(value, 0.3461, 0.0001);
  feature = "Query_2016欧洲杯决赛";
  value = gbrt_feature_->FindCtrData24Dim(feature, default_value);
  EXPECT_NEAR(value, 0.1795, 0.0001);

  feature = "Hour_00";
  value = gbrt_feature_->FindCtrData7Dim(feature, default_value);
  EXPECT_NEAR(value, 0.1538, 0.0001);
  feature = "Hour-IdeaId_00-50000000004642784";
  value = gbrt_feature_->FindCtrData7Dim(feature, default_value);
  EXPECT_NEAR(value, 0.2142, 0.0001);
  feature = "Hour-WinfoId_00-105659967";
  value = gbrt_feature_->FindCtrData7Dim(feature, default_value);
  EXPECT_NEAR(value, 0.0526, 0.0001);
  feature = "Hour-Query_00-2016欧洲杯决赛";
  value = gbrt_feature_->FindCtrData7Dim(feature, default_value);
  EXPECT_NEAR(value, 0.1333, 0.0001);
  feature = "Query-Showurl_2016欧洲杯决赛-app.cmvideo.cn";
  value = gbrt_feature_->FindCtrData7Dim(feature, default_value);
  EXPECT_NEAR(value, 0.1666, 0.0001);
  feature = "Ucid-Showurl_8988068962-app.cmvideo.cn";
  value = gbrt_feature_->FindCtrData7Dim(feature, default_value);
  EXPECT_NEAR(value, 0.3571, 0.0001);
  feature = "Showurl_app.cmvideo.cn";
  value = gbrt_feature_->FindCtrData7Dim(feature, default_value);
  EXPECT_NEAR(value, 0.1517, 0.0001);
}

TEST_F(GBRTFeatureTest, FeatureList2TrainInput) {
  GBRTInsKeys feature_list;
  std::vector<GBRTPair> gbrt_stat_pair;
  feature_list.ucid = "8988068962";
  feature_list.query = "2016欧洲杯决赛";
  feature_list.idea_id = 50000000004642784;
  feature_list.pattern_id = 10135931;
  feature_list.plan_id = 10136327;
  feature_list.unit_id = 10136778;
  feature_list.user_id = 10136822;
  feature_list.winfo_id = 105659967;
  feature_list.word = "阅兵";
  feature_list.match_type = 4;
  feature_list.day_hour = "00";
  feature_list.show_url = "app.cmvideo.cn";

  std::vector<double> result = gbrt_feature_->InsKeys2GBRTInput(feature_list, &gbrt_stat_pair);
  EXPECT_NEAR(result[3], -1.0, 0.0001);
  EXPECT_NEAR(result[5], -1.0, 0.0001);
  EXPECT_NEAR(result[23], 4, 0.1);
  EXPECT_NEAR(result[24], 0.1538, 0.0001);
  EXPECT_NEAR(result[25], 0.1517, 0.0001);
  EXPECT_NEAR(result[26], 0.2142, 0.0001);
  EXPECT_NEAR(result[27], 0.0526, 0.0001);
  EXPECT_NEAR(result[28], 0.1333, 0.0001);
  EXPECT_NEAR(result[29], 0.1666, 0.0001);
  EXPECT_NEAR(result[30], 0.3571, 0.0001);
}

TEST_F(GBRTFeatureTest, GetGBRTFeatureTernary) {
  GBRTInsKeys feature_list;
  std::vector<GBRTPair> gbrt_stat_pair;
  feature_list.ucid = "8988068962";
  feature_list.query = "2016欧洲杯决赛";
  feature_list.idea_id = 50000000004642784;
  feature_list.pattern_id = 10135931;
  feature_list.plan_id = 10136327;
  feature_list.unit_id = 10136778;
  feature_list.user_id = 10136822;
  feature_list.winfo_id = 105659967;
  feature_list.word = "阅兵";
  feature_list.match_type = 4;
  feature_list.day_hour = "00";
  feature_list.show_url = "app.cmvideo.cn";
  std::vector<int> result;
  gbrt_feature_->GetGBRTFeature(feature_list, &result, &gbrt_stat_pair);
  EXPECT_EQ(result[0], 4065);
  EXPECT_EQ(result[15], 4353);
  EXPECT_EQ(result[29], 2743);
}

TEST_F(GBRTFeatureTest, GetAvgCtr) {
  double gbrt_average_ctr = gbrt_feature_->GetAvgCtr();
  EXPECT_NEAR(gbrt_average_ctr, -1.0, 0.0001);
}
