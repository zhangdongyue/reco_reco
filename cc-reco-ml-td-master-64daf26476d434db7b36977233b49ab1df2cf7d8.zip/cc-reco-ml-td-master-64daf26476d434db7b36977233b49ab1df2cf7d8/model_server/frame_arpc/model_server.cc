#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/thread/blocking_queue.h"

#include "net/counter/export.h"

#include "serving_base/utility/signal.h"

#include "arpc/RPCInterface.h"
#include "arpc/ANetRPCServer.h"
#include "arpc/CommonMacros.h"
#include "client_pool/ArpcClientPool.h"

#include "reco/ml/model_server/handler/model_searcher.h"
#include "reco/ml/model_server/frame_arpc/model_service_impl.h"
#include "reco/ml/model_server/global_data/global_data.h"
#include "reco/ml/model_server/component_arpc/model_manager_server.h"
#include "reco/ml/model_server/component_arpc/model_manager.pb.h"

using namespace arpc;
using namespace arpc_client_pool::client_pool;

DEFINE_int32(port, 2805, "ad server port");
DEFINE_int32(threads_num, 32, "number of ad server thread");
DEFINE_int32(model_manager_port, 29000, "model reload port");

DECLARE_int32(heart_beat_port);
DEFINE_string(mode, "serving", "工作模式 : 正常为 serving, 其他为 tools");
DEFINE_string(model_name, "gbrt", "操作模型名");
DEFINE_string(cmd, "reload", "命令");

int32 ExcuteCmd(const std::string& cmd, const std::string& model_name) {
  PoolParams params;
  params.clientCount = 1;

  std::set<StubInfo> stub_info;
  stub_info.insert(StubInfo("127.0.0.1", FLAGS_model_manager_port));
   
  ArpcClientPool<reco::model_server::ModelManagerService_Stub> conn_pool;
  if (!conn_pool.init(params, stub_info)) {
    cout << "conn pool init failed." << endl;
    return -1;
  }

  // get channels as test data
  auto stub_ptr = conn_pool.get();
  if(!stub_ptr || !stub_ptr->stub()){
    return 1;
  }
  ANetRPCController cntler;

  reco::model_server::CommandRequest request;
  reco::model_server::CommandResponse response;
  request.set_cmd(cmd);
  request.set_model_name(model_name);

  stub_ptr->stub()->ExcuteCommand(&cntler, &request, &response, NULL);
  int err_code = cntler.GetErrorCode();
  if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
    std::cerr << "rpc error" << cntler.ErrorText() << std::endl;
    return 1;
  }

  if (response.code() == 0) {
    std::cerr << "success" << std::endl;
  } else {
    std::cerr << "fail: " << response.reason() << std::endl;
    return 2;
  }
  return 0;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "model server");
  thread::BlockingQueue<reco::model_server::ModelSearcher*>* searchers = new ::thread::BlockingQueue<reco::model_server::ModelSearcher*>();  // NOLINT
  for (int i = 0; i < FLAGS_threads_num; ++i) {
    searchers->Put(new reco::model_server::ModelSearcher());
  }
  reco::model_server::GlobalDataIns::instance().Init(searchers);

  if (FLAGS_mode != "serving") {
    if (FLAGS_mode == "tools") {
      int32 ret = ExcuteCmd(FLAGS_cmd, FLAGS_model_name);
      return ret;
    }
    std::cerr << "Unknown working mode! mode: " << FLAGS_mode;
    return -1;
  }

  LOG(INFO) << "new NetworkLogger success";
  ::google::FlushLogFiles(::google::INFO);

  reco::model_server::ModelManagerServer model_manager_server(FLAGS_model_manager_port, reco::model_server::GlobalDataIns::instance().work_pool);  // NOLINT
  model_manager_server.Start();
  LOG(INFO) << "ModelManagerServer start success";
  ::google::FlushLogFiles(::google::INFO);

  ANetRPCServer rpcServer(NULL, FLAGS_threads_num);
  rpcServer.StartPrivateTransport();

  rpcServer.RegisterService(new reco::model_server::ModelServiceImpl);
  std::string spec = "tcp:0.0.0.0:" + base::IntToString(FLAGS_port);
  LOG(INFO) << "listen:" << spec;
  if (!rpcServer.Listen(spec)) {
    LOG(ERROR) << "listen fail:" << spec;
    return -1;
  }
  LOG(INFO) << "Rpc server start!";
  ::google::FlushLogFiles(::google::INFO);

  net::counter::HttpCounterExport();
  LOG(INFO) << "Open counter port!";
  ::google::FlushLogFiles(::google::INFO);

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();

  // close server
  rpcServer.Close();
  rpcServer.StopPrivateTransport();
  LOG(INFO) << "rpc server stop";
  ::google::FlushLogFiles(::google::INFO);

  model_manager_server.Stop();
  LOG(INFO) << "ModelManagerServer stop";
  ::google::FlushLogFiles(::google::INFO);

  LOG(INFO) << "model server safe quit";
  ::google::FlushLogFiles(::google::INFO);

  reco::model_server::ModelSearcher* searcher = NULL;
  while (!searchers->Empty()) {
    searchers->Take(&searcher);
    delete searcher;
  }

  return 0;
}
