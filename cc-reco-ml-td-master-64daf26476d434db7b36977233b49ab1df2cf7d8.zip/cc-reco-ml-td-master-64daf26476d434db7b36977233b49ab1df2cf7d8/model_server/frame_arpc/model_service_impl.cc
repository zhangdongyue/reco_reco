#include "reco/ml/model_server/frame_arpc/model_service_impl.h"

#include <string>
#include <vector>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/closure.h"
//#include "serving_base/data_manager/data_manager.h"
#include "reco/ml/model_server/handler/model_searcher.h"
#include "reco/ml/model_server/global_data/global_data.h"
#include "reco/ml/model_server/component_arpc/model_manager.h"
#include "reco/bizc/common/error_code.h"

namespace reco {
namespace model_server {

DEFINE_int32(max_block_time, 20, "time static per doc num, in ms");

DEFINE_int64_counter(model_server, overload_request_num, 0, "refuse num");

void ModelServiceImpl::InnerProcess(Context* c) {
  int64 cur_time = base::GetTimestamp();
  if (cur_time - c->timestamp >= FLAGS_max_block_time * 1000) {
    c->response->set_code(ENUM_OVER_LOAD);
    COUNTERS_model_server__overload_request_num.Increase(1);
    LOG(WARNING) << "server overload, do not process req";
    InnerProcessDone(c);
    return;
  }

  ::Closure* inner_done = ::NewCallback(this, &ModelServiceImpl::InnerProcessDone, c);
  c->item->ProcessPackagedRequest(c->request, c->response, inner_done);
}

void ModelServiceImpl::InnerProcessDone(Context* c) {
  VLOG(2) << "Debug response:" << c->response->Utf8DebugString();
  {
    c->done->Run();
  }
  GlobalDataIns::instance().searchers->Put(c->item);
  delete c;
}

void ModelServiceImpl::PackagedSearch(::google::protobuf::RpcController* controller,
                       const ::reco::model_server::PackagedRequest* request,
                       ::reco::model_server::PackagedResponse* response,
                       ::google::protobuf::Closure* done)
{
  VLOG(2) << "Debug request:" << request->Utf8DebugString();

  response->set_code(1);
  ModelSearcher* item = NULL;
  int status = GlobalDataIns::instance().searchers->TimedTake(FLAGS_max_block_time, &item);
  if (status != 1 || NULL == item) {
    response->set_code(ENUM_OVER_LOAD);
    response->set_reason("overload error");
    COUNTERS_model_server__overload_request_num.Increase(1);
    done->Run();
    return;
  }

  Context* c = new Context;
  c->req_type = kRequestTypePackaged;
  c->request = request;
  c->response = response;
  c->done = done;
  c->item = item;
  c->timestamp = base::GetTimestamp();

  ::Closure* work_done = ::NewCallback(this, &ModelServiceImpl::InnerProcess, c);
  GlobalDataIns::instance().work_pool->AddTask(work_done);
}
}
}  // namespace reco
