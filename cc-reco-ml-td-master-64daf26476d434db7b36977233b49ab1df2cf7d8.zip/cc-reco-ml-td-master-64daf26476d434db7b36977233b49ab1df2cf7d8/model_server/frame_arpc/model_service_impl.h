#pragma once

#include "reco/bizc/proto_arpc/model_service.pb.h"
#include "base/common/base.h"

namespace reco {
namespace model_server {

enum RequestType {
  kRequestTypeStart = 1,
  kRequestTypePackaged,
  kRequestTypeEnd = 1000
};

class ModelSearcher;

struct Context {
  RequestType req_type;
  const PackagedRequest* request;
  PackagedResponse* response;
  ::google::protobuf::Closure* done;
  ModelSearcher* item;
  int64 timestamp;
};

class ModelServiceImpl : public ModelService {
 public:
  virtual void PackagedSearch(::google::protobuf::RpcController* controller,
                       const ::reco::model_server::PackagedRequest* request,
                       ::reco::model_server::PackagedResponse* response,
                       ::google::protobuf::Closure* done);

 private:
  void InnerProcess(Context* c);
  void InnerProcessDone(Context* c);
};
}  // namespace ml
}  // namespace reco
