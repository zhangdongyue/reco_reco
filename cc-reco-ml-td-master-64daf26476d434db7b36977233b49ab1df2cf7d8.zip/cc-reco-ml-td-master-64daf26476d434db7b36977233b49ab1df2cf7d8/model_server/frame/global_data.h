#pragma once

#include <memory>
#include "reco/base/common/atomic.h"
#include <string>
#include <vector>
#include "base/thread/thread_pool.h"
#include "base/thread/thread.h"
#include "base/thread/blocking_queue.h"
#include "reco/base/common/singleton.h"

namespace net {
class WebClient;
}
namespace reco {
namespace zkconfig {
class CloudSetting;
}
namespace model_server {
struct PackagedRequestTaskUnit;
typedef ::thread::BlockingQueue<PackagedRequestTaskUnit*> TaskQueue;
class ModelSearcher;
// dicts need to reload, manage them with |DictManager| in |AdDataManager|
// static dicts, manage them with |GlobalData|
struct GlobalData {
  GlobalData();
  ~GlobalData();
  
  void Init();

  TaskQueue packaged_task_queue;
  ::thread::ThreadPool* work_pool;
  thread::BlockingQueue<ModelSearcher*>* searchers;
  net::WebClient* web_client;
  zkconfig::CloudSetting* zk_setting;

  std::shared_ptr<std::vector<std::string> > text_wd_urls;
  std::shared_ptr<std::vector<std::string> > video_wd_urls;

  std::atomic<uint32> text_idx;
  std::atomic<uint32> video_idx;

  // TODO(xielang): use dict to store model_name and config
  void GetModelUrl(const std::string& model_name, std::string* url) {
    if (model_name.find("video") != std::string::npos) {
      std::shared_ptr<std::vector<std::string> > urls = text_wd_urls;
      if (urls->empty()) {
        LOG(ERROR) << "faltal: empty predict url: ";
        return;
      }

      if (text_idx >= urls->size()) {
        text_idx = 0;
      }
      *url = text_wd_urls->at(text_idx++);
    } else {
      std::shared_ptr<std::vector<std::string> > urls = video_wd_urls;
      if (urls->empty()) {
        LOG(ERROR) << "faltal: empty predict url: ";
        return;
      }

      if (video_idx >= urls->size()) {
        video_idx = 0;
      }
      *url = urls->at(video_idx++);
    }
  }

  bool stop;
  void UpdateWorker(int seconds);
  void UpdateTFUrl(const std::string& conf, std::shared_ptr<std::vector<std::string> > urls);
  thread::Thread zk_thread_;
};
typedef reco::common::singleton_default<GlobalData> GlobalDataIns;
}
}  // namespace reco
