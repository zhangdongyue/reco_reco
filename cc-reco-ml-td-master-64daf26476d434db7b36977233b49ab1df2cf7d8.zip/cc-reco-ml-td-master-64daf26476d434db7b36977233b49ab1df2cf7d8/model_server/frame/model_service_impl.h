#pragma once

#include "reco/bizc/proto/model_service.pb.h"

namespace reco {
namespace model_server {

enum RequestType {
  kRequestTypeStart = 1,
  kRequestTypePackaged,
  kRequestTypeEnd = 1000
};

class ModelSearcher;

struct Context {
  RequestType req_type;
  const PackagedRequest* request;
  PackagedResponse* response;
  ::Closure* done;
  ModelSearcher* item;
  int64 timestamp;
};

class ModelServiceImpl : public ModelService {
 public:
  virtual void PackagedSearch(::stumy::RpcController* controller,
                              const PackagedRequest* request,
                              PackagedResponse* response,
                              ::Closure* done);
 private:
  void InnerProcess(Context* c);
  void InnerProcessDone(Context* c);
};
}  // namespace ml
}  // namespace reco
