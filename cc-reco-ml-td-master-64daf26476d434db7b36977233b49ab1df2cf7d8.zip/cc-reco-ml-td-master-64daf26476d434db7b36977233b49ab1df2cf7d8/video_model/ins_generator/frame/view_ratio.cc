#include "reco/ml/video_model/ins_generator/frame/view_ratio.h"
#include <cmath>
#include <algorithm>

namespace reco {
namespace video_model {

void VideoViewRatio::Init() {
  view_priori_length_.reserve(kMaxVideoLength + 1);
  view_priori_length_.push_back(0);
  for (int i = 1; i <= kMaxVideoLength; ++i) {
    view_priori_length_.push_back(CalcAvgViewTimeByLength(i));
  }
}

inline double VideoViewRatio::CalcAvgViewTimeByLength(const double video_length) {
  static const double a = 49.57;
  static const double b = 0.001628;
  static const double c = -49.84;
  static const double d = -0.0173;
  double view_length = a * std::exp(b * video_length) + c * std::exp(d * video_length);
  return std::min(view_length, video_length);
}

bool VideoViewRatio::GetViewRatio(const int video_length, const double view_duration,
                                  double* view_ratio) const {
  *view_ratio = 0;
  if (view_duration <= 0) return false;
  if (video_length < 1) return false;
  int idx = std::min(video_length, (int)kMaxVideoLength);
  *view_ratio = view_duration / view_priori_length_[idx];
  return true;
}
}
}
