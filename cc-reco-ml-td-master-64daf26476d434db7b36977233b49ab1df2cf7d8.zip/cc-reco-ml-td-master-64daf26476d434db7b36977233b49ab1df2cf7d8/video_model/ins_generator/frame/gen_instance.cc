#include "reco/ml/video_model/ins_generator/frame/gen_frame.h"
#include "base/common/base.h"
#include "reco/ml/video_model/util/video_keeper/video_keeper.h"

DEFINE_int32(item_fea_mask, 2, "item fea mask");
DEFINE_bool(use_video_keeper, true, "use video keeper");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "gen cates instances");

  if (FLAGS_use_video_keeper && !reco::video_util::VideoKeeperIns::instance().Init()) {
    LOG(ERROR) << "init video keeper failed";
    return 1;
  }

  reco::video_model::Generator generator;
  generator.SetItemFeatureMask(FLAGS_item_fea_mask);
  generator.GenInstMultiThread();

  LOG(INFO) << "gen instance finished";

  return 0;
}
