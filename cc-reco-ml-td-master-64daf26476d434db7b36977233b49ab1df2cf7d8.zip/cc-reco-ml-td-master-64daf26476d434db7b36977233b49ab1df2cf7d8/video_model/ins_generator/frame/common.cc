#include "reco/ml/video_model/ins_generator/frame/common.h"

namespace reco {
namespace video_model {

DEFINE_string(fields_delimiter, "`", "field delimiter");
DEFINE_string(data_flag, "[dat]", "data flags");
DEFINE_string(key_equal_mark, "=0:", "key equal mark");

DEFINE_bool(is_compress_format, false, "is compress format for output instance");
DEFINE_bool(do_sort_by_weight, true, "do sort for map");
DEFINE_bool(weight_as_float, false, "weight as float");

int GetHour(const base::Time& tm) {
  int hour = 6;
  if (!tm.is_null()) {
    base::Time::Exploded exploded;
    tm.LocalExplode(&exploded);
    hour = exploded.hour;
  }

  return hour;
}

inline std::string DoubleToString(const double& data) {
  char buf[32];
  sprintf(buf, "%.3f", data);
  return std::string(buf);
}

std::string MapToString(const std::unordered_map<std::string, int>& map) {
  static const std::string digit_delim = "_";
  std::string str;
  if (FLAGS_do_sort_by_weight) {
    std::vector<std::pair<int, std::string> > vec;
    for (auto iter = map.begin(); iter != map.end(); ++iter) {
      vec.push_back(std::make_pair(iter->second, iter->first));
    }
    std::sort(vec.begin(), vec.end(), std::greater<std::pair<int, std::string> >());
    for (auto iter = vec.begin(); iter != vec.end(); ++iter) {
      if (str.empty()) {
        str = iter->second + digit_delim + base::IntToString(iter->first);
      } else {
        str += FLAGS_fields_delimiter + iter->second + digit_delim + base::IntToString(iter->first);
      }
    }
  } else {
    for (auto iter = map.begin(); iter != map.end(); ++iter) {
      if (str.empty()) {
        str = iter->first + digit_delim + base::IntToString(iter->second);
      } else {
        str += FLAGS_fields_delimiter + iter->first + digit_delim + base::IntToString(iter->second);
      }
    }
  }

  return str;
}

std::string MapKeyToString(const std::unordered_map<std::string, int>& map) {
  std::string str;
  if (FLAGS_do_sort_by_weight) {
    std::vector<std::pair<int, std::string> > vec;
    for (auto iter = map.begin(); iter != map.end(); ++iter) {
      vec.push_back(std::make_pair(iter->second, iter->first));
    }
    std::sort(vec.begin(), vec.end(), std::greater<std::pair<int, std::string> >());
    for (auto iter = vec.begin(); iter != vec.end(); ++iter) {
      if (str.empty()) {
        str = iter->second;
      } else {
        str += FLAGS_fields_delimiter + iter->second;
      }
    }
  } else {
    for (auto iter = map.begin(); iter != map.end(); ++iter) {
      if (str.empty()) {
        str = iter->first;
      } else {
        str += FLAGS_fields_delimiter + iter->first;
      }
    }
  }

  return str;
}

std::string StringVectorToString(const std::vector<std::string>& str_vec) {
  std::string str;
  for (auto iter = str_vec.begin(); iter != str_vec.end(); ++iter) {
    if (str.empty()) {
      str = *iter;
    } else {
      str += FLAGS_fields_delimiter + *iter;
    }
  }

  return str;
}

std::string GetRealTag(const std::string& raw_tag) {
  std::vector<std::string> fields;
  base::SplitString(raw_tag, ":", &fields);

  return fields.back();
}

std::string Uint64VectorToString(const std::vector<uint64>& uint64_vec) {
  std::string str;
  for (auto iter = uint64_vec.begin(); iter != uint64_vec.end(); ++iter) {
    if (str.empty()) {
      str = base::Uint64ToString(*iter);
    } else {
      str += FLAGS_fields_delimiter + base::Uint64ToString(*iter);
    }
  }

  return str;
}

std::string IntVectorToString(const std::vector<int>& int_vec) {
  std::string str;
  for (auto iter = int_vec.begin(); iter != int_vec.end(); ++iter) {
    if (str.empty()) {
      str = base::IntToString(*iter);
    } else {
      str += FLAGS_fields_delimiter + base::IntToString(*iter);
    }
  }

  return str;
}
std::string ToWeightString(const std::vector<uint64>& uint64_vec) {
  if (uint64_vec.empty()) return std::string();

  std::string str;
  std::string weight_str;
  if (FLAGS_weight_as_float) {
    double weight = 1.0 / static_cast<double>(uint64_vec.size());
    weight_str = DoubleToString(weight);
  } else {
    weight_str = "1";
  }
  for (auto iter = uint64_vec.begin(); iter != uint64_vec.end(); ++iter) {
    if (str.empty()) {
      str = weight_str;
    } else {
      str += FLAGS_fields_delimiter + weight_str;
    }
  }

  return str;
}

void MapToVectors(const std::unordered_map<std::string, int>& map,
                  std::vector<std::string>* key_list,
                  std::vector<std::string>* value_list) {
  key_list->clear();
  value_list->clear();
  if (FLAGS_weight_as_float) {
    double sum = 0;
    for (auto iter = map.begin(); iter != map.end(); ++iter) {
      sum += iter->second;
    }
    if (FLAGS_do_sort_by_weight) {
      std::vector<std::pair<int, std::string> > vec;
      for (auto iter = map.begin(); iter != map.end(); ++iter) {
        vec.push_back(std::make_pair(iter->second, iter->first));
      }
      std::sort(vec.begin(), vec.end(), std::greater<std::pair<int, std::string> >());
      for (auto iter = vec.begin(); iter != vec.end(); ++iter) {
        key_list->push_back(iter->second);
        value_list->push_back(DoubleToString(iter->first / sum));
      }
    } else {
      for (auto iter = map.begin(); iter != map.end(); ++iter) {
        key_list->push_back(iter->first);
        value_list->push_back(base::DoubleToString(iter->second / sum));
      }
    }
  } else {
    if (FLAGS_do_sort_by_weight) {
      std::vector<std::pair<int, std::string> > vec;
      for (auto iter = map.begin(); iter != map.end(); ++iter) {
        vec.push_back(std::make_pair(iter->second, iter->first));
      }
      std::sort(vec.begin(), vec.end(), std::greater<std::pair<int, std::string> >());
      for (auto iter = vec.begin(); iter != vec.end(); ++iter) {
        key_list->push_back(iter->second);
        value_list->push_back(base::IntToString(iter->first));
      }
    } else {
      for (auto iter = map.begin(); iter != map.end(); ++iter) {
        key_list->push_back(iter->first);
        value_list->push_back(base::IntToString(iter->second));
      }
    }
  }
}

std::string ToValueString(const std::string& str) {
  int len = str.length();
  std::string len_str = base::IntToString(len);
  std::string value_str = "=" + len_str + ":" + str;

  return value_str;
}

bool ParseRecentClick(const std::string& raw_recent_click,
                      std::vector<uint64>* recent_click) {
  if (raw_recent_click.length() < 10) {
    return false;
  }

  std::vector<std::string> fields;
  base::SplitString(raw_recent_click, "\t", &fields);
  if (fields.size() < 4 || fields.size() % 2 != 0 || fields[1] != "click") {
    return false;
  }
  for (uint32 i = 2; i + 2 <= fields.size(); i += 2) {
    uint64 item_id = 0;
    if (base::StringToUint64(fields[i], &item_id)) {
      recent_click->push_back(item_id);
    }
  }

  return true;
}
}
}
