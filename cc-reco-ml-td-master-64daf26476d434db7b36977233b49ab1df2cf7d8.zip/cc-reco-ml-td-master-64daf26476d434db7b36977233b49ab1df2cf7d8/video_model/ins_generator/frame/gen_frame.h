#pragma once

#include <cstdatomic>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>

#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "reco/ml/video_model/ins_generator/extractor/lr_extractor.h"
#include "reco/ml/video_model/ins_generator/frame/common.h"

namespace reco {
namespace video_model {

class Generator {
 public:
  Generator();
  ~Generator();

  void SetItemFeatureMask(const uint64 mask);

  void GenInstMultiThread();

 private:
  void ReadFile();

  void ParseUserNRecentClick();

  void ExtractLrFeas();

  void ExtractSessionFeas();

  void ExtractStSessionFeas();

  void ExtractNUSessionFeas();

  void ExtractMatchFeas();

  void DumpLrInstance();

  void DumpSessionInstance();

  void DumpStSessionInstance();

  void DumpNUSessionInstance();

  void DumpMatchInstance();
 private:
  struct ItemFeatureMask {
    bool do_item_id;
    bool do_cate;
    bool do_source;
    bool do_tags;

    ItemFeatureMask() {
      do_item_id = false;
      do_cate = false;
      do_source = false;
      do_tags = false;
    }
  };

  ItemFeatureMask item_feature_mask_;

  thread::BlockingQueue<RawUserRecoContainer*>* raw_info_queue_;

  thread::BlockingQueue<UserRecoContainer*>* info_queue_;

  thread::BlockingQueue<std::string>* instance_queue_;

  atomic_int parse_user_finished_num_;

  atomic_int extract_feas_finished_num_;
};
}
}
