#pragma once

#include <vector>
#include "base/common/base.h"
#include "reco/base/common/singleton.h"

namespace reco {
namespace video_model {
class VideoViewRatio {
 public:
  VideoViewRatio() {
    Init();
  }
  ~VideoViewRatio() {}

  bool GetViewRatio(const int video_length, const double view_duration, double *view_ratio) const;

 private:
  void Init();
  double CalcAvgViewTimeByLength(const double video_length);

 private:
  static const int kMaxVideoLength = 1000;
  std::vector<double> view_priori_length_;
};

typedef reco::common::singleton_default<VideoViewRatio> ViewRatioCalcIns;
}
}
