#include "reco/ml/video_model/ins_generator/extractor/nu_session_extractor.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>

#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "nlp/common/nlp_util.h"
#include "base/time/time.h"
#include "base/time/timestamp.h"

namespace reco {
namespace video_model {

DECLARE_string(data_flag);
DECLARE_string(key_equal_mark);
DECLARE_bool(is_compress_format);

DEFINE_int32(nu_min_session_size, 0, "min session size");

DECLARE_string(fields_delimiter);

const std::string NUSessionExtractor::kLabelKey = "label";

NUSessionExtractor::NUSessionExtractor() {
  session_feas_.SetSessionId(0);
  random_ = new base::PseudoRandom(base::GetTimestamp());
}

bool NUSessionExtractor::BatchExtractFeas(const reco::user::UserInfo& user_info,
                                          const std::vector<uint64>& recent_click,
                                          std::vector<MergeLogRecoFeas>& merge_log_reco_feas_vec,
                                          std::vector<std::string>* instances) {
  instances->clear();
  user_feas_.ExtractFeas(user_info, recent_click);
  ali_profile_feas_.ExtractFeas(user_info);
  uint32 cut_off = 0;
  if (merge_log_reco_feas_vec.size() > (uint32)(FLAGS_nu_min_session_size)) {
    cut_off = merge_log_reco_feas_vec.size() - (uint32)(FLAGS_nu_min_session_size);
  }
  for (uint32 i = 0; i < cut_off; ++i) {
    main_item_feas_.ExtractFeas(merge_log_reco_feas_vec[i]);
    if (merge_log_reco_feas_vec[i].click) {
      if (merge_log_reco_feas_vec[i].video_len < 40.0) {
        if (random_->GetDouble() > 0.2) {
          continue;
        }
        if (merge_log_reco_feas_vec[i].played < 10.0) {
          label_ = 0;
        }
      }
      label_ = 1;
    } else {
      label_ = 0;
    }

    std::vector<MergeLogRecoFeas>::iterator begin_iter0 =
        merge_log_reco_feas_vec.end();
    if (i + 1 < merge_log_reco_feas_vec.size()) {
      begin_iter0 = merge_log_reco_feas_vec.begin() + i + 1;
    }
    std::vector<MergeLogRecoFeas>::iterator end_iter0 =
        merge_log_reco_feas_vec.end();
    if (i + kSessionSize < merge_log_reco_feas_vec.size()) {
      end_iter0 = merge_log_reco_feas_vec.begin() + i + kSessionSize;
    }
    session_feas_.ExtractFeas(begin_iter0, end_iter0);

    instances->push_back(std::string());
    ToTFString(&(instances->back()));
  }

  return true;
}

std::string NUSessionExtractor::ToTFString() {
  std::string str;
  str.reserve(3 << 10);
  str = FLAGS_data_flag + "\n";
  if (FLAGS_is_compress_format) {
    str = kLabelKey + ToValueString(base::IntToString(label_));
    str += user_feas_.ToCompressTFString();
    str += ali_profile_feas_.ToCompressTFString();
    str += main_item_feas_.ToCompressTFString();
    str += session_feas_.ToCompressTFString();
    str += "\n";
  } else {
    str = kLabelKey + FLAGS_key_equal_mark + base::IntToString(label_) + "\n";
    str += user_feas_.ToTFString();
    str += ali_profile_feas_.ToTFString();
    str += main_item_feas_.ToTFString();
    str += session_feas_.ToTFString();
  }

  return str;
}

void NUSessionExtractor::ToTFString(std::string* instance) {
  instance->clear();
  instance->reserve(3 << 10);
  *instance = FLAGS_data_flag + "\n";
  if (FLAGS_is_compress_format) {
    *instance += kLabelKey + ToValueString(base::IntToString(label_));
    *instance += user_feas_.ToCompressTFString();
    *instance += ali_profile_feas_.ToCompressTFString();
    *instance += main_item_feas_.ToCompressTFString();
    *instance += session_feas_.ToCompressTFString();
    *instance += "\n";
  } else {
    *instance += kLabelKey + FLAGS_key_equal_mark + base::IntToString(label_) + "\n";
    *instance += user_feas_.ToTFString();
    *instance += ali_profile_feas_.ToTFString();
    *instance += main_item_feas_.ToTFString();
    *instance += session_feas_.ToTFString();
  }
}
}
}
