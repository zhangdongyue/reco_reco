#include "reco/ml/video_model/ins_generator/extractor/match_extractor.h"

#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>

#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "nlp/common/nlp_util.h"
#include "base/time/timestamp.h"

namespace reco {
namespace video_model {

DECLARE_string(data_flag);
DECLARE_string(key_equal_mark);

DECLARE_bool(is_compress_format);

DECLARE_string(fields_delimiter);

DEFINE_double(neg_sampling_rate, 0.02, "negative sampling rate");

DEFINE_string(match_model_loss_type, "ce", "ce for cross entropy, l2 for l2 loss");

const std::string MatchExtractor::kLabelKey = "label";

MatchExtractor::MatchExtractor() {
  random_ = new base::PseudoRandom(base::GetTimestamp());
}

MatchExtractor::~MatchExtractor() {
  delete random_;
}

int MatchExtractor::CalcRating(const MergeLogRecoFeas& merge_log_reco_feas) {
  float view_ratio = merge_log_reco_feas.view_ratio;
  if (view_ratio < 0.3) return 1;
  else if (view_ratio < 0.6) return 2;
  else if (view_ratio < 1.0) return 3;
  else if (view_ratio < 1.3) return 4;
  else return 5;
}

bool MatchExtractor::BatchExtractFeas(const reco::user::UserInfo& user_info,
                                      std::vector<MergeLogRecoFeas>& merge_log_reco_feas_vec,
                                      std::vector<std::string>* instances) {
  instances->clear();
  user_feas_.ExtractFeas(user_info);
  for (uint32 i = 0; i < merge_log_reco_feas_vec.size(); ++i) {
    item_feas_.ExtractFeas(merge_log_reco_feas_vec[i]);
    if (FLAGS_match_model_loss_type == "ce") {
      label_ = merge_log_reco_feas_vec[i].click > 0? 1: 0;
    } else if (FLAGS_match_model_loss_type == "l2") {
      if (merge_log_reco_feas_vec[i].click) {
        label_ = CalcRating(merge_log_reco_feas_vec[i]);
      } else {
        if (random_->GetDouble() < FLAGS_neg_sampling_rate) {
          label_ = 0;
        } else {
          continue;
        }
      }
    } else {
      LOG(ERROR) << "FUCK LOSS TYPE";
      exit(1);
    }

    instances->push_back(std::string());
    ToTFString(&(instances->back()));
  }

  return true;
}

std::string MatchExtractor::ToTFString() {
  std::string str;
  str.reserve(1 << 10);
  str = FLAGS_data_flag + "\n";
  if (FLAGS_is_compress_format) {
    str = kLabelKey + ToValueString(base::IntToString(label_));
    str += user_feas_.ToCompressTFString();
    str += item_feas_.ToCompressTFString();
    str += "\n";
  } else {
    str = kLabelKey + FLAGS_key_equal_mark + base::IntToString(label_) + "\n";
    str += user_feas_.ToTFString();
    str += item_feas_.ToTFString();
  }

  return str;
}

void MatchExtractor::ToTFString(std::string* instance) {
  instance->clear();
  instance->reserve(1 << 10);
  *instance = FLAGS_data_flag + "\n";
  if (FLAGS_is_compress_format) {
    *instance += kLabelKey + ToValueString(base::IntToString(label_));
    *instance += user_feas_.ToCompressTFString();
    *instance += item_feas_.ToCompressTFString();
    *instance += "\n";
  } else {
    *instance += kLabelKey + FLAGS_key_equal_mark + base::IntToString(label_) + "\n";
    *instance += user_feas_.ToTFString();
    *instance += item_feas_.ToTFString();
  }
}
}
}
