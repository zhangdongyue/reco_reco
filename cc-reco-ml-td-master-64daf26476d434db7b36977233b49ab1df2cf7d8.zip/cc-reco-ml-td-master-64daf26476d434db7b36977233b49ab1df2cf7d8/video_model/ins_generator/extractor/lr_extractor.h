#pragma once

#include <functional>
#include <algorithm>
#include <utility>
#include <string>
#include <vector>
#include <unordered_set>

#include "reco/serv/reco_model/frame/reco_model_predict.h"
#include "reco/serv/reco_model/frame/reco_model_extract_fealib.h"
#include "reco/serv/reco_video/strategy/common/feature_api-inl.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace video_model {

class LRExtractor {
 public:
  LRExtractor();
  ~LRExtractor();

  void GenUserFea(const reco::user::UserInfo& user_info,
                  reco::reco_model::UserFeature* user_feature);

  bool GenCombineFea(reco::reco_model::UserFeature& user_feature,
                     reco::reco_model::ItemFeature& item_feature,
                     reco::reco_model::LrFeature* lr_features);

  bool GenInstance(const int label,
                   const bool sign,
                   reco::reco_model::LrFeature* lr_features,
                   std::string* instance);

 private:
  void SignFeas(reco::reco_model::LrFeature* lr_features);

  reco::reco_model::Product* fea_generator_;
};
}
}
