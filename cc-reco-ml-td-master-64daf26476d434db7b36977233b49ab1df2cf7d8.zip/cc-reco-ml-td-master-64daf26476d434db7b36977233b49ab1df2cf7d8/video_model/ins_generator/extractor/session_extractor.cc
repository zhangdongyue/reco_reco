#include "reco/ml/video_model/ins_generator/extractor/session_extractor.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <cmath>

#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "nlp/common/nlp_util.h"

namespace reco {
namespace video_model {

DECLARE_string(data_flag);
DECLARE_string(key_equal_mark);
DECLARE_bool(is_compress_format);

DEFINE_int32(min_session_size, 0, "min session size");
DEFINE_bool(binary_session_label, true, "binary session label");

DECLARE_string(fields_delimiter);

const std::string SessionExtractor::kLabelKey = "label";
const std::string SessionExtractor::kWeightKey = "weight";

SessionExtractor::SessionExtractor() {
  session_0_feas_.SetSessionId(0);
  session_1_feas_.SetSessionId(1);
}


bool SessionExtractor::BatchExtractFeas(const reco::user::UserInfo& user_info,
                                        std::vector<MergeLogRecoFeas>& merge_log_reco_feas_vec,
                                        std::vector<std::string>* instances) {
  instances->clear();
  user_feas_.ExtractFeas(user_info);
  uint32 cut_off = 0;
  if (merge_log_reco_feas_vec.size() > (uint32)(FLAGS_min_session_size)) {
    cut_off = merge_log_reco_feas_vec.size() - (uint32)(FLAGS_min_session_size);
  }
  for (uint32 i = 0; i < cut_off; ++i) {
    main_item_feas_.ExtractFeas(merge_log_reco_feas_vec[i]);
    // set context feas, hour only now!
    context_feas_.SetHour(merge_log_reco_feas_vec[i].GetHour());
    label_ = 0;
    weight_ = 1.0f;
    if (merge_log_reco_feas_vec[i].click > 0) {
      label_ = 1;
      weight_ = CalcWeight(merge_log_reco_feas_vec[i]);
    }

    std::vector<MergeLogRecoFeas>::iterator begin_iter0 =
        merge_log_reco_feas_vec.end();
    if (i + 1 < merge_log_reco_feas_vec.size()) {
      begin_iter0 = merge_log_reco_feas_vec.begin() + i + 1;
    }
    std::vector<MergeLogRecoFeas>::iterator end_iter0 =
        merge_log_reco_feas_vec.end();
    if (i + kSessionFirstSize < merge_log_reco_feas_vec.size()) {
      end_iter0 = merge_log_reco_feas_vec.begin() + i + kSessionFirstSize;
    }
    session_0_feas_.ExtractFeas(begin_iter0, end_iter0);

    std::vector<MergeLogRecoFeas>::iterator begin_iter1 =
        merge_log_reco_feas_vec.end();
    if (i + kSessionFirstSize + 1 < merge_log_reco_feas_vec.size()) {
      begin_iter1 = merge_log_reco_feas_vec.begin() + i + 1 + kSessionFirstSize;
    }
    std::vector<MergeLogRecoFeas>::iterator end_iter1 =
        merge_log_reco_feas_vec.end();
    if (i + kSessionFirstSize + kSessionSecondSize < merge_log_reco_feas_vec.size()) {
      end_iter1 = merge_log_reco_feas_vec.begin() + (i + kSessionFirstSize + kSessionSecondSize);
    }
    session_1_feas_.ExtractFeas(begin_iter1, end_iter1);

    instances->push_back(std::string());
    ToTFString(&(instances->back()));
  }

  return true;
}

std::string SessionExtractor::ToTFString() {
  std::string str;
  str.reserve(3 << 10);
  str = FLAGS_data_flag + "\n";
  if (FLAGS_is_compress_format) {
    str = kLabelKey + ToValueString(base::IntToString(label_));
    str += kWeightKey + ToValueString(base::DoubleToString(weight_));
    str += user_feas_.ToCompressTFString();
    str += main_item_feas_.ToCompressTFString();
    str += context_feas_.ToCompressTFString();
    str += session_0_feas_.ToCompressTFString();
    str += session_1_feas_.ToCompressTFString();
    str += "\n";
  } else {
    str = kLabelKey + FLAGS_key_equal_mark + base::IntToString(label_) + "\n";
    str += kWeightKey + FLAGS_key_equal_mark + base::DoubleToString(weight_) + "\n";
    str += user_feas_.ToTFString();
    str += main_item_feas_.ToTFString();
    str += context_feas_.ToTFString();
    str += session_0_feas_.ToTFString();
    str += session_1_feas_.ToTFString();
  }

  return str;
}

void SessionExtractor::ToTFString(std::string* instance) {
  instance->clear();
  instance->reserve(3 << 10);
  *instance = FLAGS_data_flag + "\n";
  if (FLAGS_is_compress_format) {
    *instance += kLabelKey + ToValueString(base::IntToString(label_));
    *instance += kWeightKey + ToValueString(base::DoubleToString(weight_));
    *instance += user_feas_.ToCompressTFString();
    *instance += main_item_feas_.ToCompressTFString();
    *instance += context_feas_.ToCompressTFString();
    *instance += session_0_feas_.ToCompressTFString();
    *instance += session_1_feas_.ToCompressTFString();
    *instance += "\n";
  } else {
    *instance += kLabelKey + FLAGS_key_equal_mark + base::IntToString(label_) + "\n";
    *instance += kWeightKey + FLAGS_key_equal_mark + base::DoubleToString(weight_) + "\n";
    *instance += user_feas_.ToTFString();
    *instance += main_item_feas_.ToTFString();
    *instance += context_feas_.ToTFString();
    *instance += session_0_feas_.ToTFString();
    *instance += session_1_feas_.ToTFString();
  }
}

float SessionExtractor::CalcLabel(const MergeLogRecoFeas& merge_log_feas) {
  float label = 0.0f;
  if (merge_log_feas.click > 0) {
    float played = merge_log_feas.played;
    label = 1.0f / (1.0f + std::exp(-(played - 30.0f) / 40.0f));
  }
 
  return label;
}

float SessionExtractor::CalcWeight(const MergeLogRecoFeas& merge_log_feas) {
  float weight = 1.0f;
  if (merge_log_feas.played > 0) {
    float played = static_cast<float>(merge_log_feas.played);
    weight = 1.0 + 1.0f / (1.0f + std::exp(-(played - 30.0f) / 40.0f));
  }

  return weight;
}
}
}
