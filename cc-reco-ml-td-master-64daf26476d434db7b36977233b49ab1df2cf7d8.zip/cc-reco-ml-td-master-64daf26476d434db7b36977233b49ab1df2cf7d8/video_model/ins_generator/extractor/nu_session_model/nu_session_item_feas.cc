#include "reco/ml/video_model/ins_generator/extractor/nu_session_model/nu_session_item_feas.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>

#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "nlp/common/nlp_util.h"


namespace reco {
namespace video_model {

DECLARE_string(key_equal_mark);

DECLARE_bool(is_compress_format);

DECLARE_string(fields_delimiter);

const std::string NUSessionItemFeas::kMainItemIdKey = "main_item_id";
const std::string NUSessionItemFeas::kMainItemTagsKey = "main_item_tags";
const std::string NUSessionItemFeas::kMainItemTagsWeightKey = "main_item_tags_weight";
const std::string NUSessionItemFeas::kMainItemCateKey = "main_item_cate";
const std::string NUSessionItemFeas::kMainItemSourceKey = "main_item_source";
const std::string NUSessionItemFeas::kMainItemOrigSourceKey = "main_item_orig_source";

bool NUSessionItemFeas::ExtractFeas(const MergeLogRecoFeas& merge_log_feas) {
  Reset();
  item_id = merge_log_feas.item_id;
  tags = merge_log_feas.tags;
  category = merge_log_feas.category;
  source = merge_log_feas.source;
  orig_source = merge_log_feas.orig_source;

  return true;
}

std::string NUSessionItemFeas::ToTFString() {
  std::string str;
  str = kMainItemIdKey + FLAGS_key_equal_mark + base::Uint64ToString(item_id) + "\n";
  std::string tag_str;
  std::string tag_weight_str;
  for (auto iter = tags.begin(); iter != tags.end(); ++iter) {
    if (tag_str.empty()) {
      tag_str = *iter;
      tag_weight_str = "1";
    } else {
      tag_str += FLAGS_fields_delimiter + *iter;
      tag_weight_str += FLAGS_fields_delimiter + "1";
    }
  }
  str += kMainItemTagsKey + FLAGS_key_equal_mark + tag_str + "\n";
  str += kMainItemTagsWeightKey + FLAGS_key_equal_mark + tag_weight_str + "\n";
  str += kMainItemCateKey + FLAGS_key_equal_mark + category + "\n";
  str += kMainItemSourceKey + FLAGS_key_equal_mark + source + "\n";
  str += kMainItemOrigSourceKey + FLAGS_key_equal_mark + orig_source + "\n";

  return str;
}

std::string NUSessionItemFeas::ToCompressTFString() {
  std::string str;
  str = kMainItemIdKey + ToValueString(base::Uint64ToString(item_id));
  std::string tag_str;
  std::string tag_weight_str;
  for (auto iter = tags.begin(); iter != tags.end(); ++iter) {
    if (tag_str.empty()) {
      tag_str = *iter;
      tag_weight_str = "1";
    } else {
      tag_str += FLAGS_fields_delimiter + *iter;
      tag_weight_str += FLAGS_fields_delimiter + "1";
    }
  }
  str += kMainItemTagsKey + ToValueString(tag_str);
  str += kMainItemTagsWeightKey + ToValueString(tag_weight_str);
  str += kMainItemCateKey + ToValueString(category);
  str += kMainItemSourceKey + ToValueString(source);
  str += kMainItemOrigSourceKey + ToValueString(orig_source);

  return str;
}
}
}
