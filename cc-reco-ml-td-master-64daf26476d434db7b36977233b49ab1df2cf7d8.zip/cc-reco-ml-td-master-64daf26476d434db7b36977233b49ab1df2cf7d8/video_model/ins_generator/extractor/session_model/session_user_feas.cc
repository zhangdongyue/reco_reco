#include "reco/ml/video_model/ins_generator/extractor/session_model/session_user_feas.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>

#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/proto/user.pb.h"
#include "nlp/common/nlp_util.h"

namespace reco {
namespace video_model {


DEFINE_int32(max_lt_video_tag, 50, "max user lt video tag num");
DEFINE_int32(max_lt_video_cate, 5, "max user lt video cate num");
DEFINE_int32(scale_up, 10, "scale up for user feas");

DECLARE_string(key_equal_mark);
DECLARE_bool(is_compress_format);

DECLARE_string(fields_delimiter);

const std::string SessionUserFeas::kUserIdKey = "user_id";
const std::string SessionUserFeas::kUserLtVideoTagsKey = "lt_video_tags";
const std::string SessionUserFeas::kUserLtVideoTagsWeightKey = "lt_video_tags_weight";
const std::string SessionUserFeas::kUserLtVideoCatesKey = "lt_video_cates";
const std::string SessionUserFeas::kUserLtVideoCatesWeightKey = "lt_video_cates_weight";
const std::string SessionUserFeas::kUserLtVideoCateTagsKey = "lt_video_cate_tags";
const std::string SessionUserFeas::kUserLtVideoCateTagsWeight = "lt_video_cate_tags_weight";

bool SessionUserFeas::ExtractFeas(const reco::user::UserInfo& user_info) {
  Reset();

  if (!ExtractLtFeas(user_info)) {
    return false;
  }

  return true;
}

bool SessionUserFeas::ExtractLtFeas(const reco::user::UserInfo& user_info) {
  user_id = user_info.identity().user_id();
  if (user_id == 0) {
    return false;
  }
  auto &v_tag_vec = user_info.profile().video_tag_without_cat_feavec();
  float norm_vtag = 0.001;
  int count_v = 0;
  for (int i = 0; i < v_tag_vec.feature_size() && count_v < FLAGS_max_lt_video_tag; ++i) {
    norm_vtag += v_tag_vec.feature(i).weight();
    ++count_v;
  }
  for (int i = 0; i < count_v; ++i) {
    auto &tag = v_tag_vec.feature(i);
    std::string tag_lt = tag.literal();
    nlp::util::NormalizeLineInPlaceS(&tag_lt);
    std::string real_tag = GetRealTag(tag_lt);
    int weight = int((tag.weight() * FLAGS_scale_up) / norm_vtag * count_v);
    weight = std::max(weight, 1);
    lt_video_tags.insert(std::make_pair(real_tag, weight));
  }

  if (user_info.profile().has_video_category_feavec()) {
    float norm_category = 0.001;
    int count = 0;
    auto& v_cates = user_info.profile().video_category_feavec();
    for (int i = 0; i < v_cates.feature_size() && count < FLAGS_max_lt_video_cate; ++i) {
      norm_category += v_cates.feature(i).weight();
      ++count;
    }
    for (int i = 0; i < count; ++i) {
      auto& cate = v_cates.feature(i);
      std::string lt_cate = cate.literal().category();
      nlp::util::NormalizeLineInPlaceS(&lt_cate);
      int weight = int((cate.weight() * FLAGS_scale_up) / norm_category * count);
      weight = std::max(weight, 1);
      lt_video_cates.insert(std::make_pair(lt_cate, weight));
    }
  }

  return true;
}

std::string SessionUserFeas::ToTFString() {
  std::string str;
  str.reserve(1 << 10);

  str = kUserIdKey + FLAGS_key_equal_mark + base::Uint64ToString(user_id) + "\n";

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // lt video tags
  MapToVectors(lt_video_tags, &key_list, &value_list);
  str += kUserLtVideoTagsKey + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += kUserLtVideoTagsWeightKey + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // lt video cates
  MapToVectors(lt_video_cates, &key_list, &value_list);
  str += kUserLtVideoCatesKey + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += kUserLtVideoCatesWeightKey + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // // lt video cate tags
  // MapToVectors(lt_video_cate_tags, &key_list, &value_list);
  // str += kUserLtVideoCateTagsKey + FLAGS_key_equal_mark
  //     + StringVectorToString(key_list) + "\n";
  // str += kUserLtVideoCateTagsWeightKey + FLAGS_key_equal_mark
  //     + StringVectorToString(value_list) + "\n";
  
  return str;
}

std::string SessionUserFeas::ToCompressTFString() {
  std::string str;
  str.reserve(1 << 10);

  str = kUserIdKey + ToValueString(base::Uint64ToString(user_id));

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // lt video tags
  MapToVectors(lt_video_tags, &key_list, &value_list);
  str += kUserLtVideoTagsKey + ToValueString(StringVectorToString(key_list));
  str += kUserLtVideoTagsWeightKey + ToValueString(StringVectorToString(value_list));

  // lt video cates
  MapToVectors(lt_video_cates, &key_list, &value_list);
  str += kUserLtVideoCatesKey + ToValueString(StringVectorToString(key_list));
  str += kUserLtVideoCatesWeightKey + ToValueString(StringVectorToString(value_list));

  // // lt video cate tags
  // MapToVectors(lt_video_cate_tags, &key_list, &value_list);
  // str += kUserLtVideoCateTagsKey + FLAGS_key_equal_mark
  //     + StringVectorToString(key_list) + "\n";
  // str += kUserLtVideoCateTagsWeightKey + FLAGS_key_equal_mark
  //     + StringVectorToString(value_list) + "\n";

  return str;
}
}
}
