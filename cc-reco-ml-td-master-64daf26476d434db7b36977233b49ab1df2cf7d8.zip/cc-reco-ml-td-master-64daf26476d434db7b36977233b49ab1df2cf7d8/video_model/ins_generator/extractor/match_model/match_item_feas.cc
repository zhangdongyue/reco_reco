#include "reco/ml/video_model/ins_generator/extractor/match_model/match_item_feas.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>

#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "nlp/common/nlp_util.h"


namespace reco {
namespace video_model {

DECLARE_string(key_equal_mark);

DECLARE_bool(is_compress_format);

DECLARE_string(fields_delimiter);

const std::string MatchItemFeas::kItemIdKey = "main_item_id";
const std::string MatchItemFeas::kItemTagsKey = "main_item_tags";
const std::string MatchItemFeas::kItemTagsWeightKey = "main_item_tags_weight";
const std::string MatchItemFeas::kItemCateKey = "main_item_cate";
const std::string MatchItemFeas::kItemSourceKey = "main_item_source";
const std::string MatchItemFeas::kItemOrigSourceKey = "main_item_orig_source";

bool MatchItemFeas::ExtractFeas(const MergeLogRecoFeas& merge_log_feas) {
  Reset();
  item_id = merge_log_feas.item_id;
  tags = merge_log_feas.tags;
  category = merge_log_feas.category;
  source = merge_log_feas.source;
  orig_source = merge_log_feas.orig_source;

  return true;
}

std::string MatchItemFeas::ToTFString() {
  std::string str;
  str = kItemIdKey + FLAGS_key_equal_mark + base::Uint64ToString(item_id) + "\n";
  std::string tag_str;
  std::string tag_weight_str;
  for (auto iter = tags.begin(); iter != tags.end(); ++iter) {
    if (tag_str.empty()) {
      tag_str = *iter;
      tag_weight_str = "1";
    } else {
      tag_str += FLAGS_fields_delimiter + *iter;
      tag_weight_str += FLAGS_fields_delimiter + "1";
    }
  }
  str += kItemTagsKey + FLAGS_key_equal_mark + tag_str + "\n";
  str += kItemTagsWeightKey + FLAGS_key_equal_mark + tag_weight_str + "\n";
  str += kItemCateKey + FLAGS_key_equal_mark + category + "\n";
  str += kItemSourceKey + FLAGS_key_equal_mark + source + "\n";
  str += kItemOrigSourceKey + FLAGS_key_equal_mark + orig_source + "\n";

  return str;
}

std::string MatchItemFeas::ToCompressTFString() {
  std::string str;
  str = kItemIdKey + ToValueString(base::Uint64ToString(item_id));
  std::string tag_str;
  std::string tag_weight_str;
  for (auto iter = tags.begin(); iter != tags.end(); ++iter) {
    if (tag_str.empty()) {
      tag_str = *iter;
      tag_weight_str = "1";
    } else {
      tag_str += FLAGS_fields_delimiter + *iter;
      tag_weight_str += FLAGS_fields_delimiter + "1";
    }
  }
  str += kItemTagsKey + ToValueString(tag_str);
  str += kItemTagsWeightKey + ToValueString(tag_weight_str);
  str += kItemCateKey + ToValueString(category);
  str += kItemSourceKey + ToValueString(source);
  str += kItemOrigSourceKey + ToValueString(orig_source);

  return str;
}
}
}
