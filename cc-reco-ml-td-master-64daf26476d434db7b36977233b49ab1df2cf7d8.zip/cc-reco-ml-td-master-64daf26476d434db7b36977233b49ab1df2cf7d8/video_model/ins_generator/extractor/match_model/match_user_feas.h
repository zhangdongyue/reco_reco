#pragma once

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>

#include "reco/ml/video_model/ins_generator/frame/common.h"

namespace reco {
namespace video_model {

// online offline share
class MatchUserFeas {
 public:
  bool ExtractFeas(const reco::user::UserInfo& user_info);

  std::string ToTFString();

  std::string ToCompressTFString();

  void Reset() {
    user_id = 0;
    lt_video_tags.clear();
    lt_video_cates.clear();
    // lt_video_cate_tags.clear();
  }

 public:
  static const std::string kUserIdKey;
  static const std::string kUserLtVideoTagsKey;
  static const std::string kUserLtVideoTagsWeightKey;
  static const std::string kUserLtVideoCatesKey;
  static const std::string kUserLtVideoCatesWeightKey;
  static const std::string kUserLtVideoCateTagsKey;
  static const std::string kUserLtVideoCateTagsWeight;

  uint64 user_id;
  std::unordered_map<std::string, int> lt_video_tags;
  std::unordered_map<std::string, int> lt_video_cates;
  // std::unordered_map<std::string, int> lt_video_cate_tags;
};
}
}
