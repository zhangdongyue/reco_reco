#pragma once

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>

#include "reco/ml/video_model/ins_generator/frame/common.h"

namespace reco {
namespace video_model {

// online offline share
class MatchItemFeas {
 public:
  void Assign(const uint64 item_id,
              const std::vector<std::string>& tags,
              const std::string& category,
              const std::string& source) {
    this->item_id = item_id;
    this->tags = tags;
    this->category = category;
    this->source = source;
  }

  bool ExtractFeas(const MergeLogRecoFeas& merge_log_feas);

  std::string ToTFString();

  std::string ToCompressTFString();

  void Reset() {
    item_id = 0;
    tags.clear();
    category.clear();
    source.clear();
    orig_source.clear();
  }

 public:
  static const std::string kItemIdKey;
  static const std::string kItemTagsKey;
  static const std::string kItemTagsWeightKey;
  static const std::string kItemCateKey;
  static const std::string kItemSourceKey;
  static const std::string kItemOrigSourceKey;

  uint64 item_id;
  std::vector<std::string> tags;
  std::string category;
  std::string source;
  std::string orig_source;
};
}
}
