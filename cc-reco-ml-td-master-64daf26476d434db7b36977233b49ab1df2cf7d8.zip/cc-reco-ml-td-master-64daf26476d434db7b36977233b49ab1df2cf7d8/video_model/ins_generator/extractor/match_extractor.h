#pragma once

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>

#include "base/random/pseudo_random.h"
#include "reco/ml/video_model/ins_generator/frame/common.h"
#include "reco/ml/video_model/ins_generator/extractor/match_model/match_user_feas.h"
#include "reco/ml/video_model/ins_generator/extractor/match_model/match_item_feas.h"

namespace reco {
namespace video_model {

// not thread safe
class MatchExtractor {
 public:
  MatchExtractor();

  ~MatchExtractor();

  bool BatchExtractFeas(const reco::user::UserInfo& user_info,
                        std::vector<MergeLogRecoFeas>& merge_log_reco_feas_vec,
                        std::vector<std::string>* instances);

  std::string ToTFString();

  void ToTFString(std::string* instance);
 private:
  int CalcRating(const MergeLogRecoFeas& merge_log_reco_feas);

 private:
  static const std::string kLabelKey;

  int label_;
  MatchUserFeas user_feas_;
  MatchItemFeas item_feas_;

  base::PseudoRandom* random_;
};
}
}
