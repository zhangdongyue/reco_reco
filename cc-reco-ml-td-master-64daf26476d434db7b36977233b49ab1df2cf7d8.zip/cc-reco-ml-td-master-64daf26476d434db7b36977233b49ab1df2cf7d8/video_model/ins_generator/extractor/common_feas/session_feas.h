#pragma once

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>

#include "reco/ml/video_model/ins_generator/frame/common.h"
#include "reco/ml/video_model/ins_generator/extractor/session_model/session_user_feas.h"
#include "reco/ml/video_model/ins_generator/extractor/session_model/session_item_feas.h"

namespace reco {
namespace video_model {

class SessionFeasKeys {
 public:
  static std::vector<std::string> BuildKey(const std::string& key_prefix, const int num);

 public:
  static const std::vector<std::string> kSessionShowItemIdsKey;
  static const std::vector<std::string> kSessionShowItemIdsWeightKey;
  static const std::vector<std::string> kSessionClickItemIdsKey;
  static const std::vector<std::string> kSessionClickItemIdsWeightKey;
  static const std::vector<std::string> kSessionShowTagsKey;
  static const std::vector<std::string> kSessionShowTagsWeightKey;
  static const std::vector<std::string> kSessionClickTagsKey;
  static const std::vector<std::string> kSessionClickTagsWeightKey;
  static const std::vector<std::string> kSessionShowCatesKey;
  static const std::vector<std::string> kSessionShowCatesWeightKey;
  static const std::vector<std::string> kSessionClickCatesKey;
  static const std::vector<std::string> kSessionClickCatesWeightKey;
  static const std::vector<std::string> kSessionShowCateTagsKey;
  static const std::vector<std::string> kSessionShowCateTagsWeightKey;
  static const std::vector<std::string> kSessionClickCateTagsKey;
  static const std::vector<std::string> kSessionClickCateTagsWeightKey;
  static const std::vector<std::string> kSessionShowSourcesKey;
  static const std::vector<std::string> kSessionShowSourcesWeightKey;
  static const std::vector<std::string> kSessionClickSourcesKey;
  static const std::vector<std::string> kSessionClickSourcesWeightKey;
};

// offline session feas
class SessionFeas {
 public:
  bool ExtractFeas(std::vector<MergeLogRecoFeas>::iterator begin,
                   std::vector<MergeLogRecoFeas>::iterator end);

  std::string ToTFString();

  std::string ToCompressTFString();

  void Reset() {
    show_item_ids.clear();
    click_item_ids.clear();
    show_tags.clear();
    click_tags.clear();
    show_cates.clear();
    click_cates.clear();
    show_cate_tags.clear();
    click_cate_tags.clear();
    show_sources.clear();
    click_sources.clear();
  }

  void SetSessionId(const int session_id) {
    this->session_id = session_id;
  }

 public:
  int session_id;
  std::vector<uint64> show_item_ids;
  std::vector<uint64> click_item_ids;
  std::unordered_map<std::string, int> show_tags;
  std::unordered_map<std::string, int> click_tags;
  std::unordered_map<std::string, int> show_cates;
  std::unordered_map<std::string, int> click_cates;
  std::unordered_map<std::string, int> show_cate_tags;
  std::unordered_map<std::string, int> click_cate_tags;
  std::unordered_map<std::string, int> show_sources;
  std::unordered_map<std::string, int> click_sources;
};

/*
 * online feature part
 */
class RecoFeas {
 public:
  RecoFeas() {
    item_id = 0u;
    click = 0;
    category.clear();
    tags.clear();
    source.clear();
  }

  void Reset() {
    item_id = 0u;
    click = 0;
    category.clear();
    tags.clear();
    source.clear();
  }

  std::string ToString() {
    std::string str;
    std::string tag_str;
    for (auto iter = tags.begin(); iter != tags.end(); ++iter) {
      tag_str += " " + *iter;
    }
    str = "item_id: " + base::Uint64ToString(item_id) + " cate: " + category
        + " source: " + source + " tags:" + tag_str
        + " click: " + base::IntToString(click);

    return str;
  }

 public:
  uint64 item_id;
  int click;
  std::string category;
  std::vector<std::string> tags;
  std::string source;
};

class RecoFeasContainer {
 public:
  void Insert(const RecoFeas& reco_feas) {
    index.insert(std::make_pair(reco_feas.item_id, reco_feas_vec.size()));
    reco_feas_vec.push_back(reco_feas);
  }

  bool SetClick(const uint64 item_id,
                const int click) {
    auto iter = index.find(item_id);
    if (iter == index.end()) return false;
    reco_feas_vec[iter->second].click = click;
    return true;
  }

 public:
  std::unordered_map<uint64, int> index;
  std::vector<RecoFeas> reco_feas_vec;
};

class OnlineSessionFeas {
 public:
  bool ExtractFeas(const RecoFeasContainer& reco_feas_container,
                   const int begin,
                   const int end);

  std::string ToTFString();

  std::string ToCompressTFString();

  void Reset() {
    show_item_ids.clear();
    click_item_ids.clear();
    show_tags.clear();
    click_tags.clear();
    show_cates.clear();
    click_cates.clear();
    show_cate_tags.clear();
    click_cate_tags.clear();
    show_sources.clear();
    click_sources.clear();
  }

  void SetSessionId(const int session_id) {
    this->session_id = session_id;
  }

 public:
  int session_id;
  std::vector<uint64> show_item_ids;
  std::vector<uint64> click_item_ids;
  std::unordered_map<std::string, int> show_tags;
  std::unordered_map<std::string, int> click_tags;
  std::unordered_map<std::string, int> show_cates;
  std::unordered_map<std::string, int> click_cates;
  std::unordered_map<std::string, int> show_cate_tags;
  std::unordered_map<std::string, int> click_cate_tags;
  std::unordered_map<std::string, int> show_sources;
  std::unordered_map<std::string, int> click_sources;
};
}
}
