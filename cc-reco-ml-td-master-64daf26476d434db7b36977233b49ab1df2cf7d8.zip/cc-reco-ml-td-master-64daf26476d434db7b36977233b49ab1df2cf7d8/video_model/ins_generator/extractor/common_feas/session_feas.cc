#include "reco/ml/video_model/ins_generator/extractor/common_feas/session_feas.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>

#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "nlp/common/nlp_util.h"


namespace reco {
namespace video_model {

DECLARE_string(key_equal_mark);

DECLARE_bool(is_compress_format);

DECLARE_string(fields_delimiter);

std::vector<std::string> SessionFeasKeys::BuildKey(const std::string& key_prefix, const int num) {
  std::vector<std::string> keys;
  for (int i = 0; i < num; ++i) {
    std::string id_str = base::IntToString(i);
    std::string key = key_prefix + id_str;
    keys.push_back(key);
  }

  return keys;
}

#define SESSION_NUM (2)

const std::vector<std::string> SessionFeasKeys::kSessionShowItemIdsKey
  = SessionFeasKeys::BuildKey("session_show_item_ids_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowItemIdsWeightKey
  = SessionFeasKeys::BuildKey("session_show_item_ids_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickItemIdsKey
  = SessionFeasKeys::BuildKey("session_click_item_ids_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickItemIdsWeightKey
  = SessionFeasKeys::BuildKey("session_click_item_ids_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowTagsKey
  = SessionFeasKeys::BuildKey("session_show_tags_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowTagsWeightKey
  = SessionFeasKeys::BuildKey("session_show_tags_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickTagsKey
  = SessionFeasKeys::BuildKey("session_click_tags_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickTagsWeightKey
  = SessionFeasKeys::BuildKey("session_click_tags_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowCatesKey
  = SessionFeasKeys::BuildKey("session_show_cates_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowCatesWeightKey
  = SessionFeasKeys::BuildKey("session_show_cates_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickCatesKey
  = SessionFeasKeys::BuildKey("session_click_cates_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickCatesWeightKey
  = SessionFeasKeys::BuildKey("session_click_cates_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowCateTagsKey
  = SessionFeasKeys::BuildKey("session_show_cate_tags_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowCateTagsWeightKey
  = SessionFeasKeys::BuildKey("session_show_cate_tags_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickCateTagsKey
  = SessionFeasKeys::BuildKey("session_click_cate_tags_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickCateTagsWeightKey
  = SessionFeasKeys::BuildKey("session_click_cate_tags_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowSourcesKey
  = SessionFeasKeys::BuildKey("session_show_sources_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowSourcesWeightKey
  = SessionFeasKeys::BuildKey("session_show_sources_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickSourcesKey
  = SessionFeasKeys::BuildKey("session_click_sources_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickSourcesWeightKey
  = SessionFeasKeys::BuildKey("session_click_sources_weight_", SESSION_NUM);

bool SessionFeas::ExtractFeas(std::vector<MergeLogRecoFeas>::iterator begin,
                              std::vector<MergeLogRecoFeas>::iterator end) {
  Reset();
  for (auto iter = begin; iter != end; ++iter) {
    auto& item_id = iter->item_id;
    auto& tags = iter->tags;
    auto& category = iter->category;
    auto& click = iter->click;
    auto& source = iter->source;
    show_item_ids.push_back(item_id);
    for (auto it_tag = tags.begin(); it_tag != tags.end(); ++it_tag) {
      std::string tag = *it_tag;
      show_tags[tag] += 1;
      std::string cate_tag = category + "_" + tag;
      show_cate_tags[cate_tag] += 1;
      if (click) {
        click_tags[tag] += 1;
        click_cate_tags[cate_tag] += 1;
      }
    }

    show_cates[category] += 1;
    show_sources[source] += 1;
    if (click) {
      click_item_ids.push_back(item_id);
      click_cates[category] += 1;
      click_sources[source] += 1;
    }
  }

  return true;
}

std::string SessionFeas::ToTFString() {
  std::string str;
  str.reserve(2 << 10);
  // item ids
  str = SessionFeasKeys::kSessionShowItemIdsKey[session_id] + FLAGS_key_equal_mark
      + Uint64VectorToString(show_item_ids) + "\n";
  std::string show_item_id_weights = ToWeightString(show_item_ids);
  str += SessionFeasKeys::kSessionShowItemIdsWeightKey[session_id] + FLAGS_key_equal_mark + show_item_id_weights + "\n";

  str += SessionFeasKeys::kSessionClickItemIdsKey[session_id] + FLAGS_key_equal_mark
      + Uint64VectorToString(click_item_ids) + "\n";
  std::string click_item_id_weights = ToWeightString(click_item_ids);
  str += SessionFeasKeys::kSessionClickItemIdsWeightKey[session_id] + FLAGS_key_equal_mark + click_item_id_weights + "\n";

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // tags
  // show tags
  MapToVectors(show_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click tags
  MapToVectors(click_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // cates
  // show cates
  MapToVectors(show_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCatesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowCatesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click_cates
  MapToVectors(click_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCatesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickCatesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // cate tags
  // show cate tags
  MapToVectors(show_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCateTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowCateTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click cate tags
  MapToVectors(click_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCateTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickCateTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // sources
  // show sources
  MapToVectors(show_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowSourcesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowSourcesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click sources
  MapToVectors(click_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickSourcesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickSourcesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  return str;
}

std::string SessionFeas::ToCompressTFString() {
  std::string str;
  str.reserve(2 << 10);
  // item ids
  str = SessionFeasKeys::kSessionShowItemIdsKey[session_id]
      + ToValueString(Uint64VectorToString(show_item_ids));
  std::string show_item_id_weights = ToWeightString(show_item_ids);
  str += SessionFeasKeys::kSessionShowItemIdsWeightKey[session_id]
      + ToValueString(show_item_id_weights);

  str += SessionFeasKeys::kSessionClickItemIdsKey[session_id]
      + ToValueString(Uint64VectorToString(click_item_ids));
  std::string click_item_id_weights = ToWeightString(click_item_ids);
  str += SessionFeasKeys::kSessionClickItemIdsWeightKey[session_id]
      + ToValueString(click_item_id_weights);

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // tags
  // show tags
  MapToVectors(show_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click tags
  MapToVectors(click_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // cates
  // show cates
  MapToVectors(show_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCatesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowCatesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click_cates
  MapToVectors(click_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCatesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickCatesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // cate tags
  // show cate tags
  MapToVectors(show_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCateTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowCateTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click cate tags
  MapToVectors(click_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCateTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickCateTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // sources
  // show sources
  MapToVectors(show_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowSourcesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowSourcesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click sources
  MapToVectors(click_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickSourcesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickSourcesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  return str;
}

bool OnlineSessionFeas::ExtractFeas(const RecoFeasContainer& reco_feas_container,
                                    const int begin,
                                    const int end) {
  if (begin >= end
      || reco_feas_container.reco_feas_vec.size() < (uint32)end) return false;
  Reset();

  for (int i = begin; i < end; ++i) {
    auto& reco_feas = reco_feas_container.reco_feas_vec[i];
    auto& item_id = reco_feas.item_id;
    auto& tags = reco_feas.tags;
    auto& category = reco_feas.category;
    auto& click = reco_feas.click;
    auto& source = reco_feas.source;
    show_item_ids.push_back(item_id);
    for (auto it_tag = tags.begin(); it_tag != tags.end(); ++it_tag) {
      std::string tag = *it_tag;
      show_tags[tag] += 1;
      std::string cate_tag = category + "_" + tag;
      show_cate_tags[cate_tag] += 1;
      if (click) {
        click_tags[tag] += 1;
        click_cate_tags[cate_tag] += 1;
      }
    }

    show_cates[category] += 1;
    show_sources[source] += 1;
    if (click) {
      click_item_ids.push_back(item_id);
      click_cates[category] += 1;
      click_sources[source] += 1;
    }
  }

  return true;
}

std::string OnlineSessionFeas::ToTFString() {
  std::string str;
  str.reserve(2 << 10);
  // item ids
  str = SessionFeasKeys::kSessionShowItemIdsKey[session_id] + FLAGS_key_equal_mark
      + Uint64VectorToString(show_item_ids) + "\n";
  std::string show_item_id_weights = ToWeightString(show_item_ids);
  str += SessionFeasKeys::kSessionShowItemIdsWeightKey[session_id]
      + FLAGS_key_equal_mark + show_item_id_weights + "\n";

  str += SessionFeasKeys::kSessionClickItemIdsKey[session_id] + FLAGS_key_equal_mark
      + Uint64VectorToString(click_item_ids) + "\n";
  std::string click_item_id_weights = ToWeightString(click_item_ids);
  str += SessionFeasKeys::kSessionClickItemIdsWeightKey[session_id]
      + FLAGS_key_equal_mark + click_item_id_weights + "\n";

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // tags
  // show tags
  MapToVectors(show_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click tags
  MapToVectors(click_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // cates
  // show cates
  MapToVectors(show_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCatesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowCatesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click_cates
  MapToVectors(click_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCatesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickCatesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // cate tags
  // show cate tags
  MapToVectors(show_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCateTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowCateTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click cate tags
  MapToVectors(click_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCateTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickCateTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // sources
  // show sources
  MapToVectors(show_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowSourcesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowSourcesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click sources
  MapToVectors(click_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickSourcesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickSourcesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  return str;
}

std::string OnlineSessionFeas::ToCompressTFString() {
  std::string str;
  str.reserve(2 << 10);
  // item ids
  str = SessionFeasKeys::kSessionShowItemIdsKey[session_id]
      + ToValueString(Uint64VectorToString(show_item_ids));
  std::string show_item_id_weights = ToWeightString(show_item_ids);
  str += SessionFeasKeys::kSessionShowItemIdsWeightKey[session_id]
      + ToValueString(show_item_id_weights);

  str += SessionFeasKeys::kSessionClickItemIdsKey[session_id]
      + ToValueString(Uint64VectorToString(click_item_ids));
  std::string click_item_id_weights = ToWeightString(click_item_ids);
  str += SessionFeasKeys::kSessionClickItemIdsWeightKey[session_id]
      + ToValueString(click_item_id_weights);

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // tags
  // show tags
  MapToVectors(show_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowTagsWeightKey[session_id] 
      + ToValueString(StringVectorToString(value_list));

  // click tags
  MapToVectors(click_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // cates
  // show cates
  MapToVectors(show_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCatesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowCatesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click_cates
  MapToVectors(click_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCatesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickCatesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // cate tags
  // show cate tags
  MapToVectors(show_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCateTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowCateTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click cate tags
  MapToVectors(click_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCateTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickCateTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // sources
  // show sources
  MapToVectors(show_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowSourcesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowSourcesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click sources
  MapToVectors(click_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickSourcesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickSourcesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  return str;
}
}
}
