#pragma once

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>

#include "reco/ml/video_model/ins_generator/frame/common.h"

namespace reco {
namespace video_model {

class AliProfileFeas {
 public:
  bool ExtractFeas(const reco::user::UserInfo& user_info);

  std::string ToTFString();

  std::string ToCompressTFString();

  void Reset() {
    binary_feas.clear();
    age_level.clear();
    degree.clear();
    career.clear();
    life_stage.clear();
    interest_group.clear();
  }

  bool ExtractBinaryFeas(const reco::user::UserInfo& user_info);

 public:
  static const std::string kBinaryFeasKey;
  static const std::string kAgeLevelKey;
  static const std::string kDegreeKey;
  static const std::string kCareerKey;
  static const std::string kSchoolKey;
  static const std::string kLifeStageKey;
  static const std::string kInterestGroupKey;
  static const std::string kInterestGroupWeightKey;

  std::vector<int> binary_feas;
  std::string age_level;
  std::string degree;
  std::string career;
  std::string school;
  std::vector<std::string> life_stage;
  std::unordered_map<std::string, int> interest_group;
};
}
}
