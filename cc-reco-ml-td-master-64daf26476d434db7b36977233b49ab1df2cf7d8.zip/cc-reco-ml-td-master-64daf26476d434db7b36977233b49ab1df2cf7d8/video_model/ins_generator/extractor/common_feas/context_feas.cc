#include "reco/ml/video_model/ins_generator/extractor/common_feas/context_feas.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>

#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "nlp/common/nlp_util.h"


namespace reco {
namespace video_model {

DECLARE_string(key_equal_mark);

DECLARE_bool(is_compress_format);

DECLARE_string(fields_delimiter);

const std::string ContextFeas::kHourKey = "hour";

bool ContextFeas::ExtractFeas(const reco::user::UserInfo& user_info) {

  return true;
}

void ContextFeas::SetHour(const int hour) {
  this->hour = hour;
}

std::string ContextFeas::ToTFString() {
  std::string str;
  str = kHourKey + FLAGS_key_equal_mark + base::IntToString(hour) + "\n";

  return str;
}

std::string ContextFeas::ToCompressTFString() {
  std::string str;

  str = kHourKey + ToValueString(base::IntToString(hour));

  return str;
}
}
}
