#include "reco/ml/video_model/ins_generator/extractor/common_feas/ali_profile_feas.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>

#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "nlp/common/nlp_util.h"


namespace reco {
namespace video_model {

DECLARE_string(key_equal_mark);

DECLARE_bool(is_compress_format);

DECLARE_string(fields_delimiter);

const std::string AliProfileFeas::kBinaryFeasKey = "alip_binary";
const std::string AliProfileFeas::kAgeLevelKey = "age_level";
const std::string AliProfileFeas::kDegreeKey = "degree";
const std::string AliProfileFeas::kCareerKey = "career";
const std::string AliProfileFeas::kSchoolKey = "school";
const std::string AliProfileFeas::kLifeStageKey = "life_stage";
const std::string AliProfileFeas::kInterestGroupKey = "interest_group";
const std::string AliProfileFeas::kInterestGroupWeightKey = "interest_group_weight";


bool AliProfileFeas::ExtractFeas(const reco::user::UserInfo& user_info) {
  if (!user_info.has_ali_profile()) return false;
  Reset();
  ExtractBinaryFeas(user_info);

  auto& ali_profile = user_info.ali_profile();
  if (ali_profile.has_gp_age_level()) {
    age_level = ali_profile.gp_age_level();
  }
  if (ali_profile.has_gp_degree()) {
    degree = ali_profile.gp_degree();
  }
  if (ali_profile.has_gp_school()) {
    school = ali_profile.gp_school();
  }
  for (int i = 0; i < ali_profile.gp_life_stage_size(); ++i) {
    life_stage.push_back(ali_profile.gp_life_stage(i));
  }
  if (ali_profile.has_gp_interest_group()) {
    auto& interest_group_fv = ali_profile.gp_interest_group();
    double norm = 0.001;
    int cnt = 0;
    for (int i = 0; i < interest_group_fv.feature_size() && i < 5; ++i) {
      norm += interest_group_fv.feature(i).weight();
      ++cnt;
    }
    for (int i = 0; i < cnt; ++i) {
      int w = static_cast<int>(cnt * 10 * (interest_group_fv.feature(i).weight() / norm));
      w = std::max(1, w);
      interest_group.insert(std::make_pair(interest_group_fv.feature(i).literal(), w));
    }
  }

  return true;
}

bool AliProfileFeas::ExtractBinaryFeas(const reco::user::UserInfo& user_info) {
  if (!user_info.has_ali_profile()) return false;
  auto& ali_profile = user_info.ali_profile();
  uint32 cnt = 0;
  if (ali_profile.has_gp_gender() && ali_profile.gp_gender() == "F") {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_is_undergraduate() && ali_profile.gp_is_undergraduate()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_has_pet() && ali_profile.gp_has_pet()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_has_car() && ali_profile.gp_has_car()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_has_house() && ali_profile.gp_has_house()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_life_stage_single() && ali_profile.gp_life_stage_single()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_life_stage_marrying() && ali_profile.gp_life_stage_marrying()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_life_stage_in_love() && ali_profile.gp_life_stage_in_love()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_life_stage_married() && ali_profile.gp_life_stage_married()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_life_stage_has_child() && ali_profile.gp_life_stage_has_child()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_life_stage_has_baby() && ali_profile.gp_life_stage_has_baby()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_life_stage_honor_parent() && ali_profile.gp_life_stage_honor_parent()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }
  if (ali_profile.has_gp_life_stage_decoration() && ali_profile.gp_life_stage_decoration()) {
    binary_feas.push_back(1);
  } else {
    binary_feas.push_back(0);
    ++cnt;
  }

  if (cnt == binary_feas.size()) return false;

  return true;
}

std::string AliProfileFeas::ToTFString() {
  std::string str;
  str.reserve(2 << 10);

  // binary_feas
  str = kBinaryFeasKey + FLAGS_key_equal_mark + IntVectorToString(binary_feas) + "\n";

  // age_level
  str += kAgeLevelKey + FLAGS_key_equal_mark + age_level + "\n";

  // degree
  str += kDegreeKey + FLAGS_key_equal_mark + degree + "\n";

  // career
  str += kCareerKey + FLAGS_key_equal_mark + career + "\n";

  // school
  str += kSchoolKey + FLAGS_key_equal_mark + school + "\n";

  // life_stage
  str += kLifeStageKey + FLAGS_key_equal_mark + StringVectorToString(life_stage) + "\n";

  // interest group
  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  MapToVectors(interest_group, &key_list, &value_list);
  str += kInterestGroupKey + FLAGS_key_equal_mark + StringVectorToString(key_list) + "\n";
  str += kInterestGroupWeightKey + FLAGS_key_equal_mark + StringVectorToString(value_list) + "\n";

  return str;
}

std::string AliProfileFeas::ToCompressTFString() {
  std::string str;
  str.reserve(2 << 10);

  // binary_feas
  str = kBinaryFeasKey + ToValueString(IntVectorToString(binary_feas));

  // age_level
  str += kAgeLevelKey + ToValueString(age_level);

  // degree
  str += kDegreeKey + ToValueString(degree);

  // career
  str += kCareerKey + ToValueString(career);

  // school
  str += kSchoolKey + ToValueString(school);

  // life_stage
  str += kLifeStageKey + ToValueString(StringVectorToString(life_stage));

  // interest group
  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  MapToVectors(interest_group, &key_list, &value_list);
  str += kInterestGroupKey + ToValueString(StringVectorToString(key_list));
  str += kInterestGroupWeightKey + ToValueString(StringVectorToString(value_list));

  return str;
}
}
}
