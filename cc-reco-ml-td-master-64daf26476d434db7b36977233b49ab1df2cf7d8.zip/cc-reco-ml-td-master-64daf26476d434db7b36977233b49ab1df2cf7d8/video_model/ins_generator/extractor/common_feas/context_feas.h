#pragma once

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>

#include "reco/ml/video_model/ins_generator/frame/common.h"

namespace reco {
namespace video_model {

class ContextFeas {
 public:
  bool ExtractFeas(const reco::user::UserInfo& user_info);

  void SetHour(const int hour);

  std::string ToTFString();

  std::string ToCompressTFString();

  void Reset() {
    hour = 0;
  }

 public:
  static const std::string kHourKey;

  int hour;
};
}
}
