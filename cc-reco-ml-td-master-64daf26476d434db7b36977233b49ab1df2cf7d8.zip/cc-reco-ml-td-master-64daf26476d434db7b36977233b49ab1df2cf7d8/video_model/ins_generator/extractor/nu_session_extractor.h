#pragma once

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>

#include "base/random/pseudo_random.h"
#include "reco/ml/video_model/ins_generator/frame/common.h"
#include "reco/ml/video_model/ins_generator/extractor/nu_session_model/nu_session_user_feas.h"
#include "reco/ml/video_model/ins_generator/extractor/nu_session_model/nu_session_item_feas.h"
#include "reco/ml/video_model/ins_generator/extractor/common_feas/session_feas.h"
#include "reco/ml/video_model/ins_generator/extractor/common_feas/ali_profile_feas.h"

namespace reco {
namespace video_model {

// not thread safe
class NUSessionExtractor {
 public:
  NUSessionExtractor();

  // NOTE(CONGHUI): merge log reco feas vec 是按从近到远的顺序排列的
  bool ExtractFeas(const reco::user::UserInfo& user_info,
                   const std::vector<uint64>& recent_click,
                   const std::vector<MergeLogRecoFeas> merge_log_reco_feas_vec);

  bool BatchExtractFeas(const reco::user::UserInfo& user_info,
                        const std::vector<uint64>& recent_click,
                        std::vector<MergeLogRecoFeas>& merge_log_reco_feas_vec,
                        std::vector<std::string>* instances);
  std::string ToTFString();

  std::vector<std::string> BatchToTFString();

  void ToTFString(std::string* instance);
 private:
  static const std::string kLabelKey;

  static const uint32 kSessionSize = 20;
  base::PseudoRandom* random_;
  int label_;
  NUSessionUserFeas user_feas_;
  AliProfileFeas ali_profile_feas_;
  SessionItemFeas main_item_feas_;
  SessionFeas session_feas_;
};
}
}
