#pragma once

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>

#include "reco/ml/video_model/ins_generator/frame/common.h"
#include "reco/ml/video_model/ins_generator/extractor/session_model/session_user_feas.h"
#include "reco/ml/video_model/ins_generator/extractor/session_model/session_item_feas.h"
#include "reco/ml/video_model/ins_generator/extractor/common_feas/session_feas.h"
#include "reco/ml/video_model/ins_generator/extractor/common_feas/context_feas.h"

namespace reco {
namespace video_model {

// not thread safe
class SessionExtractor {
 public:
  SessionExtractor();

  // NOTE(CONGHUI): merge log reco feas vec 是按从近到远的顺序排列的
  bool ExtractFeas(const reco::user::UserInfo& user_info,
                   const std::vector<MergeLogRecoFeas> merge_log_reco_feas_vec);

  bool BatchExtractFeas(const reco::user::UserInfo& user_info,
                        std::vector<MergeLogRecoFeas>& merge_log_reco_feas_vec,
                        std::vector<std::string>* instances);

  std::string ToTFString();

  std::vector<std::string> BatchToTFString();

  void ToTFString(std::string* instance);

  float CalcLabel(const MergeLogRecoFeas& merge_log_feas);
  float CalcWeight(const MergeLogRecoFeas& merge_log_feas);
 private:
  static const std::string kLabelKey;
  static const std::string kWeightKey;

  static const uint32 kSessionFirstSize = 10;
  static const uint32 kSessionSecondSize = 10;

  int label_;
  float weight_;
  SessionUserFeas user_feas_;
  SessionItemFeas main_item_feas_;
  ContextFeas context_feas_;
  SessionFeas session_0_feas_;
  SessionFeas session_1_feas_;
};
}
}
