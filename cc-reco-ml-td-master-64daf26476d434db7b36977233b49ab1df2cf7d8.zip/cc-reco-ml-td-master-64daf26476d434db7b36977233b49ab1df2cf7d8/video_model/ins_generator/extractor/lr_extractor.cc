#include "reco/ml/video_model/ins_generator/extractor/lr_extractor.h"

#include <functional>
#include <algorithm>
#include <utility>
#include <string>
#include <vector>
#include <unordered_set>

#include "reco/serv/reco_model/frame/reco_model_predict.h"
#include "reco/serv/reco_model/frame/reco_model_extract_fealib.h"
#include "reco/serv/reco_video/strategy/common/feature_api-inl.h"
#include "base/strings/string_number_conversions.h"
#include "base/hash_function/city.h"

namespace reco {
namespace video_model {

LRExtractor::LRExtractor() {
  fea_generator_ = new reco::reco_model::GenerateUserAliFeaCombItemFea();
}

LRExtractor::~LRExtractor() {
  delete fea_generator_;
}

void LRExtractor::GenUserFea(const reco::user::UserInfo& user_info,
                           reco::reco_model::UserFeature* user_feature) {
  if (!user_feature) return;
  if (!user_info.has_identity()) return;

  uint64 user_id = user_info.identity().user_id();
  user_feature->ResetUserFeature();
  user_feature->user_id = user_id;
  user_feature->SetUserFeature(user_info);
}

bool LRExtractor::GenCombineFea(reco::reco_model::UserFeature& user_feature,
                              reco::reco_model::ItemFeature& item_feature,
                              reco::reco_model::LrFeature* lr_features) {
  reco::reco_model::RecoFeature reco_fea;
  reco_fea.user_feature = &user_feature;
  reco_fea.item_feature = &item_feature;
  fea_generator_->ExtractFea(&reco_fea, lr_features, NULL);

  if (lr_features->literal_fea.size() < 1) {
    return false;
  }

  return true;
}

void LRExtractor::SignFeas(reco::reco_model::LrFeature* lr_features) {
  size_t size = lr_features->literal_fea.size();
  for (uint32 i = 0; i < size; ++i) {
    std::string& fea = lr_features->literal_fea[i];
    uint64 sign = base::CityHash64(fea.c_str(), fea.length());
    lr_features->sign_fea.push_back(sign);
  }
}

bool LRExtractor::GenInstance(const int label,
                            const bool sign,
                            reco::reco_model::LrFeature* lr_features,
                            std::string* instance) {
  std::string label_str;
  if (label) {
    label_str = "1\t0";
  } else {
    label_str = "0\t1";
  }
  instance->reserve(1024);
  *instance = label_str;

  size_t size = lr_features->literal_fea.size();
  if (sign) {
    SignFeas(lr_features);
    for (uint64 i = 0; i < size; ++i) {
      *instance += "\t" + base::Uint64ToString(lr_features->sign_fea[i]) + ":1.0";
    }
  } else {
    for (uint64 i = 0; i < size; ++i) {
      *instance += "\t" + lr_features->literal_fea[i] + ":1.0";
    }
  }

  return true;
}
}
}

