#include "reco/ml/video_model/ins_generator/extractor/st_session_model/st_session_user_feas.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>

#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/proto/user.pb.h"
#include "nlp/common/nlp_util.h"
#include "reco/ml/video_model/util/video_keeper/video_keeper.h"

namespace reco {
namespace video_model {


DEFINE_int32(st_max_lt_video_tag, 50, "max user lt video tag num");
DEFINE_int32(st_max_lt_video_cate, 5, "max user lt video cate num");
DEFINE_int32(st_scale_up, 10, "scale up for user feas");

DEFINE_int32(st_begin_hours, 24, "short term start hours");
DEFINE_int32(st_end_hours, 72, "short term end hours");

DECLARE_string(key_equal_mark);
DECLARE_bool(is_compress_format);

DECLARE_string(fields_delimiter);

const std::string StSessionUserFeas::kUserIdKey = "user_id";
const std::string StSessionUserFeas::kUserLtVideoTagsKey = "lt_video_tags";
const std::string StSessionUserFeas::kUserLtVideoTagsWeightKey = "lt_video_tags_weight";
const std::string StSessionUserFeas::kUserLtVideoCatesKey = "lt_video_cates";
const std::string StSessionUserFeas::kUserLtVideoCatesWeightKey = "lt_video_cates_weight";
const std::string StSessionUserFeas::kUserLtVideoCateTagsKey = "lt_video_cate_tags";
const std::string StSessionUserFeas::kUserLtVideoCateTagsWeight = "lt_video_cate_tags_weight";

const std::string StSessionUserFeas::kUserStVideoItemIdsKey = "st_video_item_ids";
const std::string StSessionUserFeas::kUserStVideoTagsKey = "st_video_tags";
const std::string StSessionUserFeas::kUserStVideoTagsWeightKey = "st_video_tags_weight";
const std::string StSessionUserFeas::kUserStVideoCatesKey = "st_video_cates";
const std::string StSessionUserFeas::kUserStVideoCatesWeightKey = "st_video_cates_weight";

bool StSessionUserFeas::ExtractFeas(const reco::user::UserInfo& user_info,
                                  const std::vector<uint64>& recent_click) {
  Reset();

  if (!ExtractLtFeas(user_info)) {
    return false;
  }
  ExtractStFeas(recent_click);

  return true;
}

bool StSessionUserFeas::ExtractFeas(const reco::user::UserInfo& user_info) {
  Reset();

  if (!ExtractLtFeas(user_info)) {
    return false;
  }
  // ExtractStFeas(user_info);

  return true;
}

bool StSessionUserFeas::ExtractLtFeas(const reco::user::UserInfo& user_info) {
  user_id = user_info.identity().user_id();
  if (user_id == 0) {
    return false;
  }
  auto &v_tag_vec = user_info.profile().video_tag_without_cat_feavec();
  float norm_vtag = 0.001;
  int count_v = 0;
  for (int i = 0; i < v_tag_vec.feature_size() && count_v < FLAGS_st_max_lt_video_tag; ++i) {
    norm_vtag += v_tag_vec.feature(i).weight();
    ++count_v;
  }
  for (int i = 0; i < count_v; ++i) {
    auto &tag = v_tag_vec.feature(i);
    std::string tag_lt = tag.literal();
    nlp::util::NormalizeLineInPlaceS(&tag_lt);
    std::string real_tag = GetRealTag(tag_lt);
    int weight = int((tag.weight() * FLAGS_st_scale_up) / norm_vtag * count_v);
    weight = std::max(weight, 1);
    lt_video_tags.insert(std::make_pair(real_tag, weight));
  }

  if (user_info.profile().has_video_category_feavec()) {
    float norm_category = 0.001;
    int count = 0;
    auto& v_cates = user_info.profile().video_category_feavec();
    for (int i = 0; i < v_cates.feature_size() && count < FLAGS_st_max_lt_video_cate; ++i) {
      norm_category += v_cates.feature(i).weight();
      ++count;
    }
    for (int i = 0; i < count; ++i) {
      auto& cate = v_cates.feature(i);
      std::string lt_cate = cate.literal().category();
      nlp::util::NormalizeLineInPlaceS(&lt_cate);
      int weight = int((cate.weight() * FLAGS_st_scale_up) / norm_category * count);
      weight = std::max(weight, 1);
      lt_video_cates.insert(std::make_pair(lt_cate, weight));
    }
  }

  return true;
}

bool StSessionUserFeas::ExtractStFeas(const reco::user::UserInfo& user_info) {
  base::Time now = base::Time::Now();
  // int64 cur_timestamp = now.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  base::Time begin_time = now - base::TimeDelta::FromHours(FLAGS_st_begin_hours);
  int64 begin_timestamp = begin_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  base::Time end_time = now - base::TimeDelta::FromHours(FLAGS_st_end_hours);
  int64 end_timestamp = end_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  VLOG(2) << "begin_timestamp: " << begin_timestamp << " end_timestamp: " << end_timestamp;

  static const uint32 kMaxStClickItemNum = 20;
  int recent_click_size = user_info.recent_click_size();
  VLOG(2) << "recent_click_size: " << recent_click_size
          << " show_history_size: " << user_info.shown_history_size();
  for (int i = recent_click_size - 1; i >= 0; --i) {
    auto& recent_click = user_info.recent_click(i);
    // 只计算最近 n 天的结果
    if (recent_click.click_timestamp() > begin_timestamp) {
      VLOG(2) << "click_timestamp: " << recent_click.click_timestamp()
              << " begin_timestamp: " << begin_timestamp;
      continue;
    } else if (recent_click.click_timestamp() < end_timestamp
               || st_video_item_ids.size() >= kMaxStClickItemNum) {
      VLOG(2) << "click_timestamp: " << recent_click.click_timestamp()
              << " end_timestamp: " << end_timestamp;
      break;
    } else {
      // 过滤自动播放的结果
      // if (!recent_click.has_click_type()) continue;
      reco::video_util::BasicItemInfo basic_item_info;
      if (reco::video_util::VideoKeeperIns::instance().GetFromAir(recent_click.item_id(),
                                                                  &basic_item_info)) {
        VLOG(2) << basic_item_info.ToString();
        if (basic_item_info.item_type == 30) {
          st_video_item_ids.push_back(basic_item_info.item_id);
          for (auto iter = basic_item_info.tags.begin();
               iter != basic_item_info.tags.end(); ++iter) {
            st_video_tags[*iter] += 1;
          }
          st_video_cates[basic_item_info.category] += 1;
        }
      }
    }
  }

  return true;
}

bool StSessionUserFeas::ExtractStFeas(const std::vector<uint64>& recent_click) {
  static const uint32 kMaxRecentClickNum = 20;
  for (uint32 i = 0; i < recent_click.size(); ++i) {
    if (st_video_item_ids.size() >= kMaxRecentClickNum) {
      break;
    }
    reco::video_util::BasicItemInfo basic_item_info;
    if (reco::video_util::VideoKeeperIns::instance().GetFromAir(recent_click[i],
                                                                &basic_item_info)) {
      VLOG(2) << basic_item_info.ToString();
      if (basic_item_info.item_type == 30) {
        st_video_item_ids.push_back(basic_item_info.item_id);
        for (auto iter = basic_item_info.tags.begin();
             iter != basic_item_info.tags.end(); ++iter) {
          st_video_tags[*iter] += 1;
        }
        st_video_cates[basic_item_info.category] += 1;
      }
    }
  }

  return true;
}

std::string StSessionUserFeas::ToTFString() {
  std::string str;
  str.reserve(1 << 10);

  str = kUserIdKey + FLAGS_key_equal_mark + base::Uint64ToString(user_id) + "\n";

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // lt video tags
  MapToVectors(lt_video_tags, &key_list, &value_list);
  str += kUserLtVideoTagsKey + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += kUserLtVideoTagsWeightKey + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // lt video cates
  MapToVectors(lt_video_cates, &key_list, &value_list);
  str += kUserLtVideoCatesKey + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += kUserLtVideoCatesWeightKey + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // // lt video cate tags
  // MapToVectors(lt_video_cate_tags, &key_list, &value_list);
  // str += kUserLtVideoCateTagsKey + FLAGS_key_equal_mark
  //     + StringVectorToString(key_list) + "\n";
  // str += kUserLtVideoCateTagsWeightKey + FLAGS_key_equal_mark
  //     + StringVectorToString(value_list) + "\n";
  
  // st video item ids
  str += kUserStVideoItemIdsKey + FLAGS_key_equal_mark
      + Uint64VectorToString(st_video_item_ids) + "\n";

  // st video tags
  MapToVectors(st_video_tags, &key_list, &value_list);
  str += kUserStVideoTagsKey + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += kUserStVideoTagsWeightKey + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // st video cates
  MapToVectors(st_video_cates, &key_list, &value_list);
  str += kUserStVideoCatesKey + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += kUserStVideoCatesWeightKey + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  return str;
}

std::string StSessionUserFeas::ToCompressTFString() {
  std::string str;
  str.reserve(1 << 10);

  str = kUserIdKey + ToValueString(base::Uint64ToString(user_id));

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // lt video tags
  MapToVectors(lt_video_tags, &key_list, &value_list);
  str += kUserLtVideoTagsKey + ToValueString(StringVectorToString(key_list));
  str += kUserLtVideoTagsWeightKey + ToValueString(StringVectorToString(value_list));

  // lt video cates
  MapToVectors(lt_video_cates, &key_list, &value_list);
  str += kUserLtVideoCatesKey + ToValueString(StringVectorToString(key_list));
  str += kUserLtVideoCatesWeightKey + ToValueString(StringVectorToString(value_list));

  // // lt video cate tags
  // MapToVectors(lt_video_cate_tags, &key_list, &value_list);
  // str += kUserLtVideoCateTagsKey + FLAGS_key_equal_mark
  //     + StringVectorToString(key_list) + "\n";
  // str += kUserLtVideoCateTagsWeightKey + FLAGS_key_equal_mark
  //     + StringVectorToString(value_list) + "\n";

  // st video item id
  str += kUserStVideoItemIdsKey + ToValueString(Uint64VectorToString(st_video_item_ids));

  // st video tags
  MapToVectors(st_video_tags, &key_list, &value_list);
  str += kUserStVideoTagsKey + ToValueString(StringVectorToString(key_list));
  str += kUserStVideoTagsWeightKey + ToValueString(StringVectorToString(value_list));

  // st video cates
  MapToVectors(st_video_cates, &key_list, &value_list);
  str += kUserStVideoCatesKey + ToValueString(StringVectorToString(key_list));
  str += kUserStVideoCatesWeightKey + ToValueString(StringVectorToString(value_list));

  return str;
}
}
}
