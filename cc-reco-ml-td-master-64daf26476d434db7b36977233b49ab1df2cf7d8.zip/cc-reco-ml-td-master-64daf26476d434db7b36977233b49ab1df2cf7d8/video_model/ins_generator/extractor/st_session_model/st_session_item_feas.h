#pragma once

#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>

#include "reco/ml/video_model/ins_generator/frame/common.h"

namespace reco {
namespace video_model {

// online offline share
class StSessionItemFeas {
 public:
  void Assign(const uint64 item_id,
              const std::vector<std::string>& tags,
              const std::string& category,
              const std::string& source) {
    this->item_id = item_id;
    this->tags = tags;
    this->category = category;
    this->source = source;
  }

  bool ExtractFeas(const MergeLogRecoFeas& merge_log_feas);

  std::string ToTFString();

  std::string ToCompressTFString();

  void Reset() {
    item_id = 0;
    tags.clear();
    category.clear();
    source.clear();
    orig_source.clear();
  }

 public:
  static const std::string kMainItemIdKey;
  static const std::string kMainItemTagsKey;
  static const std::string kMainItemTagsWeightKey;
  static const std::string kMainItemCateKey;
  static const std::string kMainItemSourceKey;
  static const std::string kMainItemOrigSourceKey;

  uint64 item_id;
  std::vector<std::string> tags;
  std::string category;
  std::string source;
  std::string orig_source;
};
}
}
