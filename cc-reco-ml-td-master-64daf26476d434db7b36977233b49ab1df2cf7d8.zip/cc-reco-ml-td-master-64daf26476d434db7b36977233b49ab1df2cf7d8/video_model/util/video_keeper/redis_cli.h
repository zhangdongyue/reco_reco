#pragma once

#include <vector>
#include <string>
#include <functional>
#include <algorithm>

#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "base/random/pseudo_random.h"

namespace reco {
namespace video_util {

class RedisCli {
 public:
  RedisCli();

  ~RedisCli();

  bool Init(const std::string& redis_hosts);

  int Get(const std::string &key, std::string *value);

  bool SetEx(const std::string &key, const std::string &value, const int ttl = 15 * 24 * 60 * 60);

 private:
  int RandomPick() {
    const int kCliNum = redis_clis_.size();

    return random_->GetInt(0, kCliNum - 1);
  }

 private:
  std::vector<reco::redis::RedisCli*> redis_clis_;

  base::PseudoRandom* random_;
};
}
}
