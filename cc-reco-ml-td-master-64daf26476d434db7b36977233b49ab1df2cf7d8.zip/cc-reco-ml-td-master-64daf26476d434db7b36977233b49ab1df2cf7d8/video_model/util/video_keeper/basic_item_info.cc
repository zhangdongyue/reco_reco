#include "reco/ml/video_model/util/video_keeper/basic_item_info.h"

#include <string>
#include <vector>

#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace video_util {

DEFINE_string(basic_item_info_sep, "\t", "basic item info string sep");

BasicItemInfo::BasicItemInfo() {
  item_id = 0u;
  play_len = 0;
  item_type = 0;
}

bool BasicItemInfo::ParseFromString(const std::string& str) {
  std::vector<std::string> vec;
  base::SplitString(str, FLAGS_basic_item_info_sep, &vec);
  if (vec.size() != 7) return false;
  if (!base::StringToUint64(vec[0], &item_id)
      || !base::StringToInt(vec[5], &play_len)
      || !base::StringToInt(vec[6], &item_type)) {
    return false;
  }
  if (vec[1] != "0") category = vec[1];
  if (vec[2] != "0") {
    base::SplitString(vec[2], "\01", &tags);
  }
  if (vec[3] != "0") source = vec[3];
  if (vec[4] != "0") orig_source = vec[4];

  return true;
}

std::string BasicItemInfo::SaveToString() {
  std::string str;
  str = base::Uint64ToString(item_id);
  if (category.empty()) str += FLAGS_basic_item_info_sep + "0";
  else str += FLAGS_basic_item_info_sep + category;

  if (tags.empty()) str += FLAGS_basic_item_info_sep + "0";
  else {
    std::string tag_str;
    for (auto iter = tags.begin(); iter != tags.end(); ++iter) {
      if (tag_str.empty()) {
        tag_str += *iter;
      } else {
        tag_str += "\01" + *iter;
      }
    }
    str += FLAGS_basic_item_info_sep + tag_str;
  }

  if (source.empty()) str += FLAGS_basic_item_info_sep + "0";
  else str += FLAGS_basic_item_info_sep + source;

  if (orig_source.empty()) str += FLAGS_basic_item_info_sep + "0";
  else str += FLAGS_basic_item_info_sep + orig_source;

  str += FLAGS_basic_item_info_sep + base::IntToString(play_len);
  str += FLAGS_basic_item_info_sep + base::IntToString(item_type);

  return str;
}

std::string BasicItemInfo::ToString() {
  std::string str;

  std::string tag_str;
  for (auto iter = tags.begin(); iter != tags.end(); ++iter) {
    if (tag_str.empty()) {
      tag_str += *iter;
    } else {
      tag_str += "|" + *iter;
    }
  }

  str = "item_id: " + base::Uint64ToString(item_id)
      + " category: " + category
      + " tags: " + tag_str
      + " source: " + source
      + " orig_source: " + orig_source
      + " play_len: " + base::IntToString(play_len)
      + " item_type: " + base::IntToString(item_type);

  return str;
}

void BasicItemInfo::ParseVideoTagFeatureVector(const reco::FeatureVector& raw_feature) {
  tags.clear();
  bool manual_checked = false;
  for (int i = 0; i < raw_feature.feature_size(); ++i) {
    const std::string &raw_tag = raw_feature.feature(i).literal();
    std::vector<std::string> tokens;
    base::SplitString(raw_tag, ":", &tokens);
    if (tokens.size() > 1 && tokens[0] == "manual") {
      manual_checked = true;
      break;
    }
  }
  for (int i = 0; i < raw_feature.feature_size(); ++i) {
    const std::string &raw_tag = raw_feature.feature(i).literal();
    std::vector<std::string> tokens;
    base::SplitString(raw_tag, ":", &tokens);
    std::string real_tag = "";
    if (tokens.size() <= 1) {
      // 没有前缀的直接认为是正确的 tag
      real_tag = tokens[0];
    } else if (!manual_checked && (tokens[0] == "label" || tokens[0] == "manual")) {
      real_tag = tokens[1];
    } else if (manual_checked && tokens[0] == "manual") {
      real_tag = tokens[1];
    }
    if (!real_tag.empty()) {
      tags.push_back(real_tag);
    }
  }
}

bool BasicItemInfo::ParseFromRecoItem(const reco::RecoItem& reco_item) {
  item_id = reco_item.identity().item_id();
  if (reco_item.category_size() > 0) {
    category = reco_item.category(0);
  }
  item_type = static_cast<int>(reco_item.identity().type());

  if (reco_item.has_tag()) {
    const reco::FeatureVector& tag_feas = reco_item.tag();
    ParseVideoTagFeatureVector(tag_feas);
  }

  source = reco_item.source();
  if (reco_item.has_orig_source()) orig_source = reco_item.orig_source();

  if (reco_item.video_meta_settings_size() > 0
      && reco_item.video_meta_settings(0).has_play_length()) {
    play_len = reco_item.video_meta_settings(0).play_length();
  }

  return true;
}
}
}
