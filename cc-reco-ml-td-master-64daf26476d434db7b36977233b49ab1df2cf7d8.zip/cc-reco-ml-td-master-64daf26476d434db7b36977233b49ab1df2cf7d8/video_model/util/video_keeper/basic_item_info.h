#pragma once

#include <string>
#include <vector>

#include "base/common/basic_types.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace video_util {

class BasicItemInfo {
 public:
  BasicItemInfo();

  bool ParseFromString(const std::string& str);

  bool ParseFromRecoItem(const reco::RecoItem& reco_item);

  std::string SaveToString();

  std::string ToString();

 private:
  void ParseVideoTagFeatureVector(const reco::FeatureVector& raw_feature);

 public:
  uint64 item_id;
  std::string category;
  std::vector<std::string> tags;
  std::string source;
  std::string orig_source;
  int play_len;
  int item_type;
};
}
}
