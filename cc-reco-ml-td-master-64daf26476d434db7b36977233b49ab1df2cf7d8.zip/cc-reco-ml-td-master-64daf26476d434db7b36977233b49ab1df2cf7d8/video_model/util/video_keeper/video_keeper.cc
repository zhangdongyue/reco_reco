#include "reco/ml/video_model/util/video_keeper/video_keeper.h"
#include "reco/ml/video_model/util/video_keeper/redis_cli.h"
#include "reco/base/vipserver/api/vipserver_manager.h"

namespace reco {
namespace video_util {

DEFINE_int32(basic_item_info_bucket_num, 64, "cache bucket");
DEFINE_string(video_redis_hosts, "", "video_redis_hosts");

DEFINE_string(item_keeper_ips, "11.251.193.230", "item keeper");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");

DEFINE_string(basic_item_info_key_prefix, "BIIKP", "basic_item_info_key_prefix");
DEFINE_bool(from_item_keeper, false, "only from item keeper");

DEFINE_int32(video_keeper_expire_seconds, 86400, "video_keeper_expire_seconds");

VideoKeeper::VideoKeeper() {
  is_initialized_ = false;
  is_quit_ = false;
  basic_item_info_vec_.resize(FLAGS_basic_item_info_bucket_num, NULL);
  mutex_vec_.resize(FLAGS_basic_item_info_bucket_num, NULL);
  for (size_t i = 0; i < basic_item_info_vec_.size(); ++i) {
    basic_item_info_vec_[i] = new BasicItemInfoMap();
    mutex_vec_[i] = new thread::RWMutex();
  }

  ik_mutex_ = new thread::Mutex();
}

VideoKeeper::~VideoKeeper() {
  is_quit_ = true;
  if (!is_initialized_) {
    return;
  }

  for (size_t i = 0; i < basic_item_info_vec_.size(); ++i) {
    delete basic_item_info_vec_[i];
    basic_item_info_vec_[i] = NULL;
    delete mutex_vec_[i];
    mutex_vec_[i] = NULL;
  }
  basic_item_info_vec_.clear();
  mutex_vec_.clear();

  delete redis_cli_;
  delete get_item_;
  delete ik_mutex_;
}

bool VideoKeeper::Init() {
  if (is_initialized_) {
    LOG(WARNING) << "BasicItemInfoCacheIns repeat init.";
    return true;
  }

  reco::vipserver::VSClientMgrIns::instance().Init();
  redis_cli_ = new reco::redis::RedisCli(FLAGS_video_redis_hosts);
  if (!redis_cli_) {
    LOG(ERROR) << "init redis failed";
    return false;
  }

  get_item_ = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips,
                                          FLAGS_item_keeper_port, -1);
  if (!get_item_) {
    LOG(ERROR) << "init item_keeper failed";
    return false;
  }

  is_initialized_ = true;
  LOG(INFO) << "VideoKeeper init succ.";

  return true;
}

inline size_t get_bucket(const uint64& item_id) {
  return item_id & (FLAGS_basic_item_info_bucket_num - 1);
}

inline std::string VideoKeeper::GetRedisKey(const uint64& item_id) {
  return FLAGS_basic_item_info_key_prefix + base::Uint64ToString(item_id);
}

void VideoKeeper::Add(const uint64& item_id, const BasicItemInfo& basic_item_info) {
  size_t bucket = get_bucket(item_id);
  mutex_vec_[bucket]->WriterLock();
  BasicItemInfoMap* map = basic_item_info_vec_[bucket];
  if (map->find(item_id) == map->end()) {
    map->insert(std::make_pair(item_id, basic_item_info));
  }
  mutex_vec_[bucket]->WriterUnlock();
}

bool VideoKeeper::Get(const uint64& item_id, BasicItemInfo* basic_item_info) {
  size_t bucket = get_bucket(item_id);
  mutex_vec_[bucket]->ReaderLock();
  BasicItemInfoMap* map = basic_item_info_vec_[bucket];
  bool rtn = false;
  auto iter = map->find(item_id);
  if (iter != map->end()) {
    *basic_item_info = iter->second;
    rtn = true;
  }
  mutex_vec_[bucket]->ReaderUnlock();

  return rtn;
}

bool VideoKeeper::GetFromAir(const uint64& item_id, BasicItemInfo* basic_item_info) {
  if (item_id == 0) {
    LOG(ERROR) << "shit! itemid == 0";
    return false;
  }
  if (Get(item_id, basic_item_info)) {
    return true;
  }

  std::string redis_key = GetRedisKey(item_id);
  std::string value;
  if (FLAGS_from_item_keeper || redis_cli_->Get(redis_key, &value) != 0) {
    bool flag = true;
    reco::RecoItem reco_item;
    {
      thread::AutoLock lock(ik_mutex_);
      flag = get_item_->GetRecoItem(item_id, &reco_item);
    }
    if (!flag) {
      LOG(ERROR) << "fuck item-keeper get item from item-keeper failed: " << item_id;
      return false;
    } else {
      basic_item_info->ParseFromRecoItem(reco_item);
      value = basic_item_info->SaveToString();
      if (!redis_cli_->SetEx(redis_key, value, FLAGS_video_keeper_expire_seconds)) {
        VLOG(2) << "set redis failed: " << redis_key << " " << value;
      }
    }
  } else {
    if (!basic_item_info->ParseFromString(value)) {
      VLOG(2) << "parse from string failed: " << value;
      return false;
    } else {
      VLOG(2) << "parse from string success: " << redis_key << " " << value;
    }
  }
  Add(item_id, *basic_item_info);

  return true;
}
}
}
