#include "reco/ml/video_model/util/video_keeper/redis_cli.h"

#include <string>
#include <vector>

#include "base/strings/string_split.h"
#include "base/time/time.h"

namespace reco {
namespace video_util {

RedisCli::RedisCli() {
}

RedisCli::~RedisCli() {
  for (uint32 i = 0; i < redis_clis_.size(); ++i) {
    delete redis_clis_[i];
    redis_clis_[i] = NULL;
  }

  redis_clis_.clear();
}

bool RedisCli::Init(const std::string& redis_hosts) {
  std::vector<std::string> hosts;
  base::SplitString(redis_hosts, ",", &hosts);
  if (hosts.size() < 1) return false;
  for (auto iter = hosts.begin(); iter != hosts.end(); ++iter) {
    reco::redis::RedisCli* redis_cli = new reco::redis::RedisCli(*iter, 3);
    if (!redis_cli) {
      LOG(ERROR) << "create redis client failed: " << *iter;
    } else {
      redis_clis_.push_back(redis_cli);
      LOG(INFO) << "create redis client success: " << *iter;
    }
  }

  double success_rate = static_cast<double>(redis_clis_.size()) / hosts.size();
  LOG(INFO) << "redis cli num: " << redis_clis_.size()
            << " hosts num: " << hosts.size()
            << " success_rate: " << success_rate;

  if (success_rate < 0.3) {
    return false;
  }

  random_ = new base::PseudoRandom(base::GetTimestamp());

  return true;
}

int RedisCli::Get(const std::string &key, std::string* value) {
  int index = RandomPick();
  return redis_clis_[index]->Get(key, value);
}

bool RedisCli::SetEx(const std::string &key, const std::string &value, const int ttl) {
  bool flag = true;
  for (uint32 i = 0; i < redis_clis_.size(); ++i) {
    if (!redis_clis_[i]->SetEx(key, value, ttl)) {
      flag = false;
      LOG(ERROR) << "redis set failed: " << key << " in redis [" << i << "]";
    }
  }

  return flag;
}
}
}
