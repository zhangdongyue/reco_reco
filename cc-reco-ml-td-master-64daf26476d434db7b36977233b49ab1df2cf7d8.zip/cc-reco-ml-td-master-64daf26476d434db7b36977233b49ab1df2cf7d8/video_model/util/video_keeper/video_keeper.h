#pragma once
#include <cstdatomic>
#include <string>
#include <vector>
#include <utility>
#include <unordered_map>

#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/thread/thread.h"
#include "base/thread/rw_mutex.h"
#include "reco/base/common/singleton.h"
#include "reco/ml/video_model/util/video_keeper/basic_item_info.h"
#include "reco/ml/video_model/util/video_keeper/redis_cli.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

namespace reco {
namespace video_util {

class VideoKeeper;
typedef reco::common::singleton_default<VideoKeeper> VideoKeeperIns;
typedef std::unordered_map<uint64, BasicItemInfo> BasicItemInfoMap;

class VideoKeeper {
 public:
  VideoKeeper();

  ~VideoKeeper();

  bool Init();

  // only for local cache
  void Add(const uint64& item_id, const BasicItemInfo& basic_item_info);

  // only for local cache
  bool Get(const uint64& item_id, BasicItemInfo* basic_item_info);

  // NOTE(CONGHUI): this is all your need
  bool GetFromAir(const uint64& item_id, BasicItemInfo* basic_item_info);

 private:
  std::string GetRedisKey(const uint64& item_id);

 private:
  std::atomic<bool> is_initialized_;
  std::atomic<bool> is_quit_;
  std::vector<BasicItemInfoMap*> basic_item_info_vec_;
  std::vector<thread::RWMutex*> mutex_vec_;

  reco::redis::RedisCli* redis_cli_;

  reco::BaseGetItem* get_item_;
  thread::Mutex* ik_mutex_;
 private:
  DISALLOW_COPY_AND_ASSIGN(VideoKeeper);
};
}
}
