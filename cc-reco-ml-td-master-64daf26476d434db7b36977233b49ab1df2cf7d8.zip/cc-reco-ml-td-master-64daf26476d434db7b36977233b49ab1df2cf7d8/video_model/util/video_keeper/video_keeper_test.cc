#include <string>
#include <iostream>

#include "base/common/base.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "serving_base/utility/timer.h"
#include "reco/ml/video_model/util/video_keeper/video_keeper.h"

DEFINE_string(video_keeper_item_id_file, "", "video keeper item id file");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "video keeper test");
  base::FilePath file_path(FLAGS_video_keeper_item_id_file);

  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines) || lines.empty()) {
    LOG(ERROR) << "read file failed " << FLAGS_video_keeper_item_id_file;
    return 1;
  }

  if (!reco::video_util::VideoKeeperIns::instance().Init()) {
    LOG(ERROR) << "init video keeper failed";
    return 1;
  }
  for (uint32 i = 0; i < lines.size(); ++i) {
    uint64 item_id;
    if (!base::StringToUint64(lines[i], &item_id)) {
      LOG(INFO) << "strint to uint64 failed: " << lines[i];
      continue;
    }
    LOG(INFO) << "item_id: " << item_id;

    reco::video_util::BasicItemInfo basic_item_info;
    if (reco::video_util::VideoKeeperIns::instance().GetFromAir(item_id, &basic_item_info)) {
      std::cout << basic_item_info.SaveToString() << std::endl;
    } else {
      LOG(INFO) << "get from air failed: " << item_id;
    }
  }

  return 0;
}
