#pragma once

#include <string>
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

#include "extend/json/jansson/jansson.h"

namespace reco {
namespace json {
std::string GetFieldValue(json_t* json, const std::string &name);
bool GetStringFieldValue(json_t* json, const std::string &name, std::string *value);
bool GetInt64FieldValue(json_t* json, const std::string &name, int64 *value);
bool GetDoubleFieldValue(json_t* json, const std::string &name, double *value);
bool ParseTFServingResult(const std::string& json_str, std::vector<double>* probs);
}
}
