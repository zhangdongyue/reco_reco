#include "reco/ml/video_model/util/util/util.h"

#include "base/common/base.h"
#include "base/common/logging.h"

#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"

#include "util/xml/xml.h"

namespace reco {
bool GetXPathString(const std::string& path, util::xml::XMLContext* context,
                    std::string* str) {
  util::xml::XPathContext xpathcontext;
  util::xml::XPath xpath(path);
  context->execute(xpath, &xpathcontext);
  const std::vector<util::xml::Node*>& res = xpathcontext.GetResult();
  if (res.size() == 0) {
    LOG(INFO) << "no \"" << path << "\" specified.";
    return false;
  } else if (res.size() > 1) {
    LOG(INFO) << "multiple \"" << path << "\" specified.";
    return false;
  }
  if (res[0]->type() != util::xml::Node::kElementNode) {
    LOG(INFO) << "Multi \"" << path << "\" specified.";
    return false;
  }

  util::xml::Element* ele = res[0]->ToElement();
  return ele->GetText(str);
}

bool GetXPathString(const std::string& path, util::xml::Element* pele,
                    std::string* str) {
  util::xml::XPathContext xpathcontext;
  util::xml::XPath xpath(path);
  pele->execute(xpath, &xpathcontext);
  const std::vector<util::xml::Node*>& res = xpathcontext.GetResult();
  if (res.size() == 0) {
    VLOG(5) << "no \"" << path << "\" specified.";
    return false;
  } else if (res.size() > 1) {
    LOG(INFO) << "multiple \"" << path << "\" specified.";
    return false;
  }
  if (res[0]->type() != util::xml::Node::kElementNode) {
    LOG(INFO) << "Multi \"" << path << "\" specified.";
    return false;
  }

  util::xml::Element* ele = res[0]->ToElement();
  return ele->GetText(str);
}

bool GetXPathDouble(const std::string& path, util::xml::Element* ele,
                    double* value) {
  std::string str;
  if (!GetXPathString(path, ele, &str)) return false;
  if (!base::StringToDouble(str, value)) return false;
  return true;
}

bool GetXPathInt32(const std::string& path, util::xml::Element* ele,
                   int32* value) {
  std::string str;
  if (!GetXPathString(path, ele, &str)) return false;
  if (!base::StringToInt(str, value)) return false;
  return true;
}

void GetXmlDouble(util::xml::Element *config, const std::string &name, double *value, double default_value) {
  double tmp = default_value;
  if (GetXPathDouble(name, config, &tmp)) {
    LOG(INFO) << "Get config! " << name
              << "=" << tmp;
  } else {
    LOG(INFO) << "Default config! " << name
              << "=" << tmp;
  }
  *value = tmp;
}

void GetXmlInt32(util::xml::Element *config, const std::string &name, int32 *value, int32 default_value) {
  int32 tmp = default_value;
  if (GetXPathInt32(name, config, &tmp)) {
    LOG(INFO) << "Get config! " << name
              << "=" << tmp;
  } else {
    LOG(INFO) << "Default config! " << name
              << "=" << tmp;
  }
  *value = tmp;
}

void GetXmlString(util::xml::Element *config,
                  const std::string &name,
                  std::string* value,
                  const std::string& default_value) {
  std::string tmp = default_value;
  if (GetXPathString(name, config, &tmp)) {
    LOG(INFO) << "Get config! " << name
              << "=" << tmp;
  } else {
    LOG(INFO) << "Default config! " << name
              << "=" << tmp;
  }
  *value = tmp;
}

void GetXmlBool(util::xml::Element *config,
                const std::string &name,
                bool* value,
                bool default_value) {
  std::string tmp = (default_value ? "true" : "false");
  if (GetXPathString(name, config, &tmp)) {
    LOG(INFO) << "Get config! " << name
              << "=" << tmp;
  } else {
    LOG(INFO) << "Default config! " << name
              << "=" << tmp;
  }
  base::LowerString(&tmp);
  if (tmp == "true") {
    *value = true;
  } else {
    *value = false;
  }
}
}  // namespace reco
