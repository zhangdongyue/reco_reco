#pragma once

#include <map>
#include <set>
#include <string>
#include <vector>

#include "util/xml/xml.h"

namespace reco {

bool GetXPathString(const std::string& path, util::xml::XMLContext* context,
                    std::string* str);
bool GetXPathString(const std::string& path, util::xml::Element* ele,
                    std::string* str);
bool GetXPathDouble(const std::string& path, util::xml::Element* ele,
                    double* value);
bool GetXPathInt32(const std::string& path, util::xml::Element* ele,
                    int32* value);
void GetXmlString(util::xml::Element *config,
                  const std::string &name,
                  std::string* value,
                  const std::string& default_value);

void GetXmlInt32(util::xml::Element *config,
                  const std::string &name,
                  int32* value,
                  int32 default_value);

void GetXmlDouble(util::xml::Element *config,
                  const std::string &name,
                  double* value,
                  double default_value);

void GetXmlBool(util::xml::Element *config,
                const std::string &name,
                bool* value,
                bool default_value);

}  // namespace
