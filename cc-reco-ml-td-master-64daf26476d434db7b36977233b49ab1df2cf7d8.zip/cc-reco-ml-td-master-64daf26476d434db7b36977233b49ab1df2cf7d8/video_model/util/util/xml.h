#pragma once

#include <map>
#include <set>
#include <string>
#include <vector>

#include "util/xml/xml.h"

namespace reco {
namespace xml {

bool GetXmlContext(const std::string &file_path, util::xml::XMLContext* context);

bool GetXPathString(util::xml::XMLContext* context, const std::string& path, std::string* value);
bool GetXPathInt64(util::xml::XMLContext* context, const std::string& path, int64* value);
bool GetXPathInt32(util::xml::XMLContext* context, const std::string& path, int32* value);
bool GetXPathDouble(util::xml::XMLContext* context, const std::string& path, double* value);
bool GetXPathBool(util::xml::XMLContext* context, const std::string& path, bool* value);
bool GetXPathArrayString(util::xml::XMLContext* context, const std::string& path,
                         std::vector<std::string>* strs);
}
}  // namespace reco

