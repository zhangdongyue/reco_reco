#include <cmath>
namespace reco {
namespace ml {
inline double logit(double sum_w, double up = 30) {
  double f = 0;
  if (sum_w > up) {
    f = 1;
  } else if (sum_w < -up) {
    f = 0;
  } else if (sum_w > 0) {
    f = 1 / (1 + exp(-sum_w));
  } else {
    double e = exp(sum_w);
    f = e / (1 + e);
  }
  return f;
}
}
}
