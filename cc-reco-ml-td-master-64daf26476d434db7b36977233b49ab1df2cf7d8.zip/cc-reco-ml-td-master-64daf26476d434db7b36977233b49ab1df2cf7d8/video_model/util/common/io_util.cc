#include "reco/ml/video_model/util/common/io_util.h"


#include "base/thread/thread_util.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_split.h"

#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/user_lib/user_info.h"

#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {

// serialzie and line escape ，so an item can be dumped to disk
bool SerializeLineEscapeProto(const ::google::protobuf::Message* msg, std::string* str) {
  std::string s;
  if (!msg->SerializeToString(&s)) {
    return false;
  }
  base::LineEscape(s, str);
  return true;
}

bool UnSerializeLineEscapeProto(const std::string& str, ::google::protobuf::Message* msg) {
  std::string unescape;
  if (!base::LineUnescape(str, &unescape)) {
    return false;
  }
  msg->Clear();
  if (!msg->ParseFromString(unescape)) {
    return false;
  }
  return true;
}

// 训练可能需要某些 item 信息从文件读，搞多个输入文件容易乱，故允许在 item_id 文件中以 \t 分割附着
static void GetItem(std::string item_keeper_ips,
                    int item_keeper_port,
                    std::vector<std::string>* item_ids,
                    thread::BlockingQueue<reco::RecoItem*>* queue) {
  std::vector<std::string> pure_item_ids;
  for (size_t i = 0; i < item_ids->size(); ++i) {
    std::vector<std::string> flds;
    base::SplitString(item_ids->at(i), "\t", &flds);
    if (!flds.empty()) {
      pure_item_ids.push_back(flds[0]);
    }
  }

  reco::BaseGetItem* get_item = new reco::ItemKeeperGetItem(item_keeper_ips, item_keeper_port);
  std::vector<reco::RecoItem> reco_items;
  get_item->GetRecoItems(pure_item_ids, &reco_items);
  LOG(INFO) << "thread " << thread::GetThreadID()
            << " get " << reco_items.size()
            << " from " << item_ids->size() << " ids,pure:" << pure_item_ids.size();;

  for (size_t i = 0; i < reco_items.size(); ++i) {
    const reco::RecoItem& item = reco_items[i];
    queue->Put(new reco::RecoItem(item));
  }

  delete get_item;
  delete item_ids;
}

void GetItemMultiThread(const std::vector<std::string>& item_id_list,
                        const std::string& item_keeper_ips,
                        int item_keeper_port,
                        int thread_num, thread::BlockingQueue<reco::RecoItem*>* item_queue) {
  thread::ThreadPool pool(thread_num);
  const int kStepSize = 100;
  for (size_t i = 0; i < item_id_list.size(); i += kStepSize) {
    size_t end = std::min(i + kStepSize, item_id_list.size());
    std::vector<std::string> *subs =
        new std::vector<std::string>(item_id_list.begin() + i, item_id_list.begin() + end);
    pool.AddTask(::NewCallback(GetItem,
                               item_keeper_ips,
                               item_keeper_port,
                               subs,
                               item_queue));
  }
  pool.JoinAll();
}

static void GetUser(std::string user_server_machine_list,
                    std::string user_profile_machine_list,
                    std::vector<std::string>* user_ids,
                    bool clear_show,
                    thread::BlockingQueue<reco::user::UserInfo*>* queue) {
  reco::common::UserComm* get_user = new reco::common::UserComm(user_server_machine_list,
                                                            user_profile_machine_list,
                                                            250, 450, 1, true);
  int64 got_cnt = 0;
  std::vector<std::string> flds;
  std::vector<std::string> subs;
  for (auto it = user_ids->begin(); it != user_ids->end(); ++it) {
    reco::user::UserInfo* user_info = new reco::user::UserInfo();
    reco::UserIdentity user;
    flds.clear();
    base::SplitString(*it, "\t", &flds);
    CHECK(flds.size() > 0);
    subs.clear();
    base::SplitString(flds[0], "`", &subs);
    if (subs.size() == 1) {
      user.set_app_token("uc-iflow");
      user.set_user_id(base::ParseUint64OrDie(subs[0]));
      user.set_outer_id(subs[0]);
    } else if (subs.size() == 2) {
      user.set_app_token(subs[0]);
      user.set_user_id(base::ParseUint64OrDie(subs[1]));
      user.set_outer_id(subs[1]);
    } else {
      CHECK(false) << *it;
    }
    
    if (flds.size() > 1) {
      user.set_utdid(flds[1]);
    }
    if (flds.size() > 2) {
      user.set_imei(flds[2]);
    }
    user_info->mutable_identity()->CopyFrom(user);

    std::string err;
    if (!get_user->GetUserInfo(user_info, &err)) {
      LOG(ERROR) << base::StringPrintf("failed to get user %s-%lu, err: %s",
                                       user_info->identity().app_token().c_str(),
                                       user_info->identity().user_id(),
                                       err.c_str());
      delete user_info;
    }
    if (clear_show) {
      user_info->clear_shown_history();
    }
    queue->Put(user_info);
    ++got_cnt;
  }
  LOG(INFO) << "thread " << thread::GetThreadID()
            << " get " << got_cnt
            << " from " << user_ids->size() << " ids";


  delete get_user;
  delete user_ids;
}

void GetUserMultiThread(const std::string& user_info_file,
                        const std::string& user_server_machine_list,
                        const std::string& user_profile_machine_list,
                        int thread_num, bool clear_show, thread::BlockingQueue<reco::user::UserInfo*>* user_queue) {
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(user_info_file, &lines);
  thread::ThreadPool pool(thread_num);
  const int kStepSize = 100;
  for (size_t i = 0; i < lines.size(); i += kStepSize) {
    size_t end = std::min(i + kStepSize, lines.size());
    std::vector<std::string> *subs =
        new std::vector<std::string>(lines.begin() + i, lines.begin() + end);
    pool.AddTask(::NewCallback(GetUser,
                               user_server_machine_list,
                               user_profile_machine_list,
                               subs,
                               clear_show,
                               user_queue));
  }
  pool.JoinAll();
}
}  // namespace ml
}  // namespace reco


