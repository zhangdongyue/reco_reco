#pragma once
#include <cmath>
#include "base/random/pseudo_random.h"

namespace reco {
namespace ml {
inline double logit(double sum_w) {
  double f = 0;
  if (sum_w > 30) {
    f = 1;
  } else if (sum_w < -30) {
    f = 0;
  } else if (sum_w > 0) {
    f = 1 / (1 + exp(-sum_w));
  } else {
    double e = exp(sum_w);
    f = e / (1 + e);
  }
  return f;
}

inline double GaussianRandom(double m, double d) {
  static base::PseudoRandom rand;
  double u, v, r;
  do {
    u = rand.GetDouble() * 2 - 1;
    v = rand.GetDouble() * 2 - 1;
    r = u * u + v * v;
  } while (r == 0 || r > 1);
  double c = sqrt(-2 * log(r) / r);
  return (u * c + m) * d;
}

inline bool all_zero(const std::vector<double>& v, float threshold) {
  bool all_zero = true;
  for (size_t i = 0; i < v.size(); ++i) {
    if (v[i] > threshold || v[i] < -threshold) {
      all_zero = false;
      break;
    }
  }
  return all_zero;
}
}
}
