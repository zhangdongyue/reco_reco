#pragma once

#include <vector>
#include <fstream>

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "base/thread/blocking_queue.h"
#include "base/strings/string_util.h"
#include "base/encoding/line_escape.h"
#include "base/common/logging.h"
#include "base/common/scoped_ptr.h"
#include <google/protobuf/generated_message_util.h>

/**** 提供训练相关的文件 IO 操作 ******/

namespace reco {
namespace ml {
bool SerializeLineEscapeProto(const ::google::protobuf::Message* msg, std::string* str);

bool UnSerializeLineEscapeProto(const std::string& str, ::google::protobuf::Message* msg);

// 从本机文件中读取 reco item
template <class T>
void LoadDumpProtoFile(const std::string& file_path, thread::BlockingQueue<T*>* queue) {
  std::ifstream in_file(file_path);
  CHECK(in_file.good()) << file_path << " not exist!";
  std::string line;
  uint64 line_cnt = 0;
  LOG(INFO) << "begin to load: " << file_path;
  while (std::getline(in_file, line)) {
    if (line.empty()) continue;
    base::TrimTrailingWhitespaces(&line);
    T* msg = new T();
    if (!UnSerializeLineEscapeProto(line, msg)) {
      delete msg;
      continue;
    }
    queue->Put(msg);
    ++line_cnt;
  }
  if (!in_file.eof()) {
    LOG(ERROR) << "Read file " << file_path << " error.";
    return;
  }
  LOG(INFO) << "load " << line_cnt << " proto from " << file_path;
  in_file.close();
}

template <class T>
void DumpProtoFile(std::string file_path, thread::BlockingQueue<T*>* queue) {
  std::ofstream out(file_path.c_str());
  int64 cnt = 0;
  while (!queue->Closed() || !queue->Empty()) {
    T* p = queue->Take();
    if (p == NULL) continue;

    scoped_ptr<T> scoped_p(p);
    std::string escape_str;
    reco::ml::SerializeLineEscapeProto(p, &escape_str);
    out << escape_str << std::endl;
    ++cnt;
  }
  out.close();
  LOG(INFO) << "total " << cnt << " protos dumped";
}

// 内部起多线程去 get item
void GetItemMultiThread(const std::vector<std::string>& item_id_list,
                        const std::string& item_keeper_ips,
                        int item_keeper_port,
                        int thread_num, thread::BlockingQueue<reco::RecoItem*>* item_queue);

// user info file: app_name`user_id \t utdid \t imei
void GetUserMultiThread(const std::string& user_info_file,
                        const std::string& user_server_machine_list,
                        const std::string& user_profile_machine_list,
                        int thread_num, bool clear_show, thread::BlockingQueue<reco::user::UserInfo*>* user_queue);

}  // namespace ml
}  // namespace reco
