#include "reco/ml/model/lr_model.h"

#include <math.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <iostream>
#include <utility>
#include <fstream>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

#include "base/file/file_util.h"

namespace reco {
namespace ml {

bool DenseHashLRModel::LoadBinaryModel(const std::string& dict_path) {
  feature_map_.clear();
  feature_map_.set_empty_key(0u);
  std::ifstream in_file(dict_path);
  if (!in_file.good()) {
    LOG(ERROR) << dict_path << " not exist!";
    return false;
  }
  std::string line;
  uint64 line_cnt = 0;
  while (std::getline(in_file, line)) {
    if (line.empty()) continue;
    std::vector<std::string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() != 2) {
      LOG(ERROR) << "Error format line: " << line;
      continue;
    }
    const std::string& str_feature = tokens[0];
    const std::string& str_sign    = tokens[1];
    const std::string& str_weight  = tokens[2];
    uint64 sign = 0u;
    double weight = 0.0;
    if (!base::StringToUint64(str_sign, &sign)) {
      LOG(ERROR) << "Error format line: " << line;
      continue;
    }
    if (!base::StringToDouble(str_weight, &weight)) {
      LOG(ERROR) << "Error format line: " << line;
      continue;
    }
    feature_map_[sign] = weight;
    ++line_cnt;
  }
  if (!in_file.eof()) {
    LOG(ERROR) << "Read file " << dict_path << " error.";
    return false;
  }
  LOG(INFO) << "Read " << line_cnt << " lines from " << dict_path
    << ", " << feature_map_.size() << " feature in weight model";
  return true;
}

void DenseHashLRModel::Predict(const std::vector<uint64>* features,
                               double* sum_weight, int* hits, double* ctr) {
  *sum_weight = 0.0;
  *hits = 0;
  for (size_t i = 0; i < features->size(); ++i) {
    LookupWeight(features->at(i), sum_weight, hits);
  }
  *ctr =  LRScore(*sum_weight);
}

void DenseHashLRModel::Predict(const std::vector<std::string>* features,
                               double* sum_weight, int* hits, double* ctr) {
  *sum_weight = 0.0;
  *hits = 0;
  for (size_t i = 0; i < features->size(); ++i) {
    uint64 sign = base::CityHash(features->at(i).c_str(), features->at(i).size());
    LookupWeight(sign, sum_weight, hits);
  }
  *ctr =  LRScore(*sum_weight);
}
}   // namespace ml
}   // namespace reco
