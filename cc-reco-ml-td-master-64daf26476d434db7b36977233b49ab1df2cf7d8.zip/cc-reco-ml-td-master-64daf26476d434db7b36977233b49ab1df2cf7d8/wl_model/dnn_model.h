#pragma once

#include <string>
#include <vector>
#include <map>
#include <set>
#include <fstream>
#include <iostream>
#include <numeric>

#include "base/common/base.h"
#include "base/container/dense_hash_map.h"
#include "wolong/model_server/model/model.h"

#include "wolong/eigen/Dense"

namespace wolong {
namespace model_server {

struct ShowClickTuple {
  uint32 show;
  uint32 click;
};

struct NetworkLayer {
  NetworkLayer() : in_size(0u), out_size(0u), use_bias(false) {}
  NetworkLayer(uint32 t_in, uint32 t_out, bool t_bias, uint32 t_index, std::string t_act) :
      in_size(t_in), out_size(t_out), use_bias(t_bias), layer_index(t_index), act_type(t_act) {
    W.resize(out_size, in_size);
    b.resize(out_size);
  }

  uint32 in_size;
  uint32 out_size;
  bool use_bias;
  uint32 layer_index;
  Eigen::MatrixXf W;
  Eigen::VectorXf b;
  std::string act_type;
};

struct NormElement {
  NormElement() : show_mean(0.0), show_variance(0.0), click_mean(0.0), click_variance(0.0),
                  default_show(0.0), default_click(0.0) {
    feature_name = "";
    index = -1;
  }

  NormElement(double a, double b, double c, double d, double e, double f, std::string name, int32 idx) :
      show_mean(a), show_variance(b), click_mean(c), click_variance(d), default_show(e),
      default_click(f) {
    feature_name = name;
    index = idx;
  }

  double show_mean;
  double show_variance;
  double click_mean;
  double click_variance;
  double default_show;
  double default_click;
  std::string feature_name;
  int32 index;
};

class DNNModel : public Model {
 public:
  DNNModel() : Model() {
    conf_dict_.clear();
    layers_.clear();
    layer_sizes_.clear();
    map_cvm_ = NULL;
    map_cvm_data_ = NULL;
  }

  virtual ~DNNModel() {
    std::vector<NetworkLayer>().swap(layers_);
    layers_.clear();

    std::vector<uint32>().swap(layer_sizes_);
    layer_sizes_.clear();

    std::map<uint32, NormElement>().swap(map_norm_);
    map_norm_.clear();

    std::map<std::string, double>().swap(conf_dict_);
    conf_dict_.clear();

    if (map_cvm_data_) delete map_cvm_data_;
    if (map_cvm_) delete map_cvm_;
  }

  virtual bool Initialize(const std::string &config_file);

  int32 Predict(const std::vector<uint64>* features,
                const std::vector<uint32>* feature_slots,
                const double lr_q,
                double* dnn_q);

  const std::vector<uint32>& GetLayerSizes() {return layer_sizes_;}
  bool GetConfValue(const std::string& key, double* value) const;

 private:
  bool Load();
  bool LoadModel(const std::string& filename);
  bool LoadModelConfig(const std::string& filename);
  bool LoadCVM(const std::string& filename);

  void GenInstance(const std::vector<uint64>* features,
                   const std::vector<uint32>* feature_slots,
                   const double lr_q,
                   std::vector<double>* dnn_ins) const;

  void DNNPredict(const std::vector<double>& ins, double* dnn_q) const;
  Eigen::VectorXf GetVector(const Eigen::VectorXf &inputX, uint32 layer_index) const;

 private:
  // 辅助函数，读取网络参数与归一化词表参数
  bool LoadModelParams(std::ifstream* ifs);
  bool LoadNormParams(std::ifstream *ifs);
  bool LoadLayerSize(std::ifstream *ifs);

 private:
  std::string dict_path_base_;
  std::string cvm_dict_name_;
  std::string dnn_model_name_;
  std::string dnn_model_config_name_;

  // CVM 相关
  base::dense_hash_map<uint64_t, ShowClickTuple>* map_cvm_;
  std::string* map_cvm_data_;

  // NORM 词表
  // 特征拼接时特征顺序根据该表决定，此表十分重要，必须确保无误才能保证
  // 特征拼接不会发生混乱
  std::map<uint32, NormElement> map_norm_;

  // 原 conf 词典用于对 DNN 模型进行分流量 Q 值调整，模型迁移至 model server
  // 后该词典原本功能失效，接口保留，留做未来使用
  std::map<std::string, double> conf_dict_;
  // 记录每一层的输入输出维度，包含输入维度，所以大小是 layers_.size+1
  std::vector<uint32> layer_sizes_;
  // 存放 layer 的 vector
  std::vector<NetworkLayer> layers_;

 private:
  DISALLOW_COPY_AND_ASSIGN(DNNModel);
};
}  // namespace model_server
}  // namespace wolong
