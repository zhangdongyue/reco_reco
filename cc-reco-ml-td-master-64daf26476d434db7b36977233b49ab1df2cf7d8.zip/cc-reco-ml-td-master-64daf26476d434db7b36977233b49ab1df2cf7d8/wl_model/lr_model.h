#pragma once

#include <string>
#include <vector>

#include "base/common/base.h"
#include "base/container/dense_hash_map.h"

namespace reco {
namespace ml {

class DenseHashLRModel;
class LRModel {
 public:
  LRModel() {}
  virtual ~LRModel() {}

  void Predict(const std::vector<std::string>* features, double* sum_weight, int* hits, double* ctr) = 0;

  void Predict(const std::vector<uint64>* features, double* sum_weight, int* hits, double* ctr) = 0;

  bool LoadModel(const std::string& dict_path) = 0;

 protected:
  static double LRScore(double sum_weight) {
    return 1.0 / (1 + exp(-sum_weight));
  }
};

class DenseHashLRModel : public LRModel (
 public:
  DenseHashLRModel();
  virtual ~DenseHashLRModel();

  void Predict(const std::vector<std::string>* features, double* sum_weight, int* hits, double* ctr);

  void Predict(const std::vector<uint64>* features, double* sum_weight, int* hits, double* ctr);

  bool LoadModel(const std::string& dict_path);

 private:
  void LookupWeight(uint64 sign, double* w, int32* hits) const {
    if (sign == 0u) return;
    auto it = feature_map_.find(sign);
    if (it != feature_map_.end()) {
      w += it->second;
      (*hits)++;
    }
  }

  base::dense_hash_map<uint64, float> feature_map_;
 private:
  DISALLOW_COPY_AND_ASSIGN(LRModel);
};
}  // namespace ml
}  // namespace reco
