#pragma once
#include <string>
#include <vector>
#include "base/common/base.h"
#include "base/common/logging.h"

class CalcAUC {
 public:
  CalcAUC();
  ~CalcAUC();

  bool GetAUC(double *auc);
  void AddInstance(double score, bool label);
  
 private:
  double trapezoid_area(uint64 X1, uint64 X2, uint64 Y1, uint64 Y2);
  std::vector<uint32> *pos_inst_num_;
  std::vector<uint32> *neg_inst_num_;
};

CalcAUC::CalcAUC() {
  pos_inst_num_ = new std::vector<uint32>((int)1e6 + 1, 0);
  neg_inst_num_ = new std::vector<uint32>((int)1e6 + 1, 0);
}

CalcAUC::~CalcAUC() {
  delete pos_inst_num_;
  delete neg_inst_num_;
}

double CalcAUC::trapezoid_area(uint64 X1, uint64 X2, uint64 Y1, uint64 Y2) {
  double base = (double)labs(X1 - X2);
  double hight = (double)(Y1 + Y2) / 2.0;
  return base*hight;
}

void CalcAUC::AddInstance(double score, bool label) {
  if (score < 0) score = 0;
  if (score > 1) score = 1;
  int idx = static_cast<int>(score * 1e6);
  if (idx < 0 || idx > 1e6) {
    LOG(ERROR) << "score out of range " << score;
    return;
  }
  label ? ++(*pos_inst_num_)[idx] : ++(*neg_inst_num_)[idx];
}

bool CalcAUC::GetAUC(double *auc) {
  uint64 FP = 0;
  uint64 TP = 0;
  uint64 FPprev = 0;
  uint64 TPprev = 0;
  *auc = 0;
  for (int64 i = 1e6; i >= 0; --i) {
    if ((*pos_inst_num_)[i] == 0 &&
        (*neg_inst_num_)[i] == 0) continue;

    TP += (*pos_inst_num_)[i];
    FP += (*neg_inst_num_)[i];

    *auc += trapezoid_area(FP, FPprev, TP, TPprev);
    FPprev = FP;
    TPprev = TP;
  }
  if (TP*FP != 0) {
    *auc /= TP*FP;
    return true;
  } 
  return false;
}


