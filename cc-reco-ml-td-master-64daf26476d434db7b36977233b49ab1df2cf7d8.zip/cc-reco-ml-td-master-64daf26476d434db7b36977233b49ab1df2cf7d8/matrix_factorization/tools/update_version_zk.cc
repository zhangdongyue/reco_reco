#include <iostream>
#include "base/common/base.h"
#include "reco/base/zkconfig/cloud_setting.h"
#include "base/strings/string_split.h"
#include "serving_base/utility/system_util.h"

DEFINE_string(zk_hosts,
              "11.251.203.133:2181,11.251.203.169:2181,11.251.203.239:2181,"
              "11.251.204.7:2181,11.251.204.18:2181", "zookeeper 地址");
DEFINE_string(zk_path_root, "/mf_version", "zookeeper 配置根路径");
DEFINE_string(zk_path_node, "video_em21", "");
DEFINE_string(mf_version, "0", "");
DEFINE_string(run_mode, "set", "");

namespace reco {
namespace zkconfig {
DECLARE_int32(zk_recv_timeout);
}
}

class UpdateVersionZK {
 public:
  UpdateVersionZK();
  ~UpdateVersionZK();

  void UpdateVersion();
  void GetVersion();

 private:
  reco::zkconfig::WatchContext *watch_ctx_;
};

UpdateVersionZK::UpdateVersionZK() {
  watch_ctx_ = new reco::zkconfig::WatchContext(FLAGS_zk_hosts.c_str());
}

UpdateVersionZK::~UpdateVersionZK() {
  delete watch_ctx_;
}

void UpdateVersionZK::UpdateVersion() {
  zookeeper_init(FLAGS_zk_hosts.c_str(), reco::zkconfig::WatchContext::watcher,
                 reco::zkconfig::FLAGS_zk_recv_timeout, 0, watch_ctx_, 0);
  zhandle_t *zh;
  while ((zh = watch_ctx_->get_zhandle()) == NULL) {
    LOG(INFO) << "waiting for zookeeper connection, sleep, ip:" << FLAGS_zk_hosts;
    base::SleepForSeconds(1);
  }

  int retry = 0;
  std::string zk_node = FLAGS_zk_path_root + "/" + FLAGS_zk_path_node;
  while (retry++ < 5) {
    if (ZOK != zoo_exists(zh, zk_node.c_str(), 0, NULL)) {
      LOG(INFO) << "not exist " << zk_node << ", will create it";
      if (ZOK != zoo_create(zh, zk_node.c_str(), "", 0,
                            &ZOO_OPEN_ACL_UNSAFE, 0, 0, 0)) {
        LOG(ERROR) << "fail to create path " << zk_node;
        base::SleepForSeconds(2);
        continue;
      }
    }
    break;
  }
  if (retry >= 5) return;

  retry = 0;
  while (retry++ < 5) {
    if (ZOK != zoo_set(zh, zk_node.c_str(), FLAGS_mf_version.c_str(), FLAGS_mf_version.size(), -1)) {
      LOG(ERROR) << "fail to set path " << zk_node << ", " << FLAGS_mf_version;
      continue;
    }
    break;
  }
  if (retry >= 5) return;
}

void UpdateVersionZK::GetVersion() {
  reco::zkconfig::CloudSetting setting(FLAGS_zk_hosts.c_str(), FLAGS_zk_path_root.c_str());
  static const std::string kServerName = "video";
  std::string hostname = serving_base::GetHostName();
  size_t pos = hostname.rfind(".");
  if (pos == std::string::npos) {
    LOG(ERROR) << "hostname error: " << hostname;
    return;
  }
  std::string group = hostname.substr(pos + 1);
  std::string zk_node = kServerName + "_" + group;
  setting.MonitorStringConfChange(zk_node.c_str());
  std::string value;
  while (true) {
    if (setting.GetStringConf(zk_node.c_str(), &value)) {
      std::cout << zk_node << ": " << value << std::endl;
    }
    base::SleepForSeconds(5);
  }
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "");
  UpdateVersionZK version_update;
  if (FLAGS_run_mode == "set") {
    version_update.UpdateVersion();
  } else if (FLAGS_run_mode == "get") {
    version_update.GetVersion();
  }
  return 0;
}
