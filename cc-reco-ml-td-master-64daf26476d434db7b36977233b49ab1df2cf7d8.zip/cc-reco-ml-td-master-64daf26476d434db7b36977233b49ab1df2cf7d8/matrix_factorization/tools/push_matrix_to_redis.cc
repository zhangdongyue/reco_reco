#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
//#include "base/hdfs/hdfs_file_util.h"
#include "base/file/file_util.h"
#include "base/common/sleep.h"
#include "reco/serv/reco_video/strategy/component/scorer/model_inner/mf_model.h"
#include "reco/serv/dict_server/api/dict_server_api.h"
#include "reco/bizc/proto/mf_interface.pb.h"
#include "reco/ml/matrix_factorization/strategy/train_data.h"

DEFINE_bool(push_user_matrix, false, "");
DEFINE_bool(push_item_matrix, false, "");
DEFINE_bool(push_base_info, false, "");
DEFINE_bool(push_item_list, false, "");
DEFINE_bool(update_version, false, "");

DEFINE_string(item_list_local_path, "", "item list at local");
DEFINE_bool(get_matrix, false, "");
DEFINE_bool(item_or_user, true, "");
DEFINE_string(mf_version, "", "");
DEFINE_bool(get_base_info, false, "");
DEFINE_bool(get_version, false, "");
DEFINE_bool(get_next_version, false, "");
DEFINE_bool(get_value, false, "");
DEFINE_string(mf_shard, "", "icate_usercluster in chn");
DEFINE_int32(min_item_show, 4000, "min item show in mf model for sim expand");

using std::string;
using std::vector;
using std::pair;

class PushMatrixToRedis {
 public:
  PushMatrixToRedis();
  ~PushMatrixToRedis();

  bool GetNextVersion();
  bool UpdateVersion();

  bool PushUserMatrix();
  bool PushItemMatrix();
  bool PushBaseInfo();
  bool PushItemList();

  void GetMatrix();
  void GetBaseInfo();

  bool GetVersion();
  void GetValue();

 private:
  reco::videoserver::MFModel *mf_model_;
  std::unordered_set<uint64> test_users; // debug
};

PushMatrixToRedis::PushMatrixToRedis() {
  mf_model_ = new reco::videoserver::MFModel;
  reco::videoserver::MFModel::StaticInit();

  // debug
  test_users.insert(6559556848555282366u);
  test_users.insert(10954188796091960523u);
  test_users.insert(850687533492127706u);
  test_users.insert(1200673175415174799u);
  test_users.insert(10966624649819380742u);
  test_users.insert(12928311005991498361u);
}

PushMatrixToRedis::~PushMatrixToRedis() {
  delete mf_model_;
}

bool PushMatrixToRedis::UpdateVersion() {
  if (!mf_model_->UpdateVersion(FLAGS_mf_version)) {
    LOG(INFO) << "update version fail";
    return false;
  }
  LOG(INFO) << "update version success [" << FLAGS_mf_version << "]";
  return true;
}

// [IN] format:item_id, user_cluster
bool PushMatrixToRedis::PushItemList() {
  std::ifstream fin(FLAGS_item_list_local_path);
  if (!fin.good()) {
    LOG(ERROR) << "open local file fail [" << FLAGS_item_list_local_path << "]";
    return false;
  }

  std::string line;
  std::vector<std::string> item_list;
  while (std::getline(fin, line)) {
    std::vector<std::string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() == 2) {
      item_list.push_back(tokens[0] + "-" + tokens[1]);
    }
  }

  fin.close();

  if (item_list.empty()) {
    LOG(ERROR) << "item_list empty";
    return false;
  }
  LOG(INFO) << "load item list success [" << item_list.size() << "]";

  if (!mf_model_->UpdateItemList(FLAGS_mf_version, item_list)) {
    return false;
  }
  LOG(INFO) << "push item list to redis success";

  return true;
}

// [IN] 0:itemid'-'usercluster 1:bias 2+:factor
bool PushMatrixToRedis::PushItemMatrix() {
  std::string line;
  uint32 cnt = 0;
  while (std::getline(std::cin, line)) { // each item
    std::vector<std::string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 3) {
      continue;
    }

    // push item matrix
    reco::MFFeatureVector item_fea_vec;
    for (int i = 1; i < (int)tokens.size(); ++i) {
      double weight = 0;
      if (!base::StringToDouble(tokens[i], &weight)) {
        LOG(ERROR) << "convert feature vector to double fail [" << tokens[i] << "]";
        return false;
      }

      item_fea_vec.add_weight((float)weight);
    }

    if (!mf_model_->UpdateItemMatrix(FLAGS_mf_version, tokens[0], item_fea_vec)) {
      return false;
    }

    if (++cnt >= 200) {
      cnt = 0;
      base::SleepForMilliseconds(1000);
    }

  }

  return true;
}

// 0:userid 1:icateid 2:cluster 3:bias 4:ins_cnt 5-54:factor 55+:cate2-score
bool PushMatrixToRedis::PushUserMatrix() {
  std::string line;
  std::vector<std::string> tokens;
  uint64 uid = 0;
  uint64 last_uid = 0;
  double ins_cnt = 0;
  double bias = 0;
  double weight = 0;
  reco::MFFeatureVectorArray user_fea_vec_array;
  while (std::getline(std::cin, line)) {  // each user with icate
    std::vector<std::string> tokens;
    base::SplitString(line, "\t", &tokens);

    if ((int)tokens.size() < reco::mf::FLAGS_fea_num + 5) {
      continue;
    }

    if (!base::StringToUint64(tokens[0], &uid)) {
      LOG(ERROR) << "convert ID to uint64 fail [" << tokens[0] << "]";
      return false;
    }

    if (uid != last_uid) {
      if (last_uid > 0) {
        if (!mf_model_->UpdateUserMatrix(FLAGS_mf_version, last_uid, user_fea_vec_array)) {
          return false;
        }
      }
      user_fea_vec_array.Clear();
      last_uid = uid;
    }

    reco::MFFeatureVectorWithCate *p_mf_feature_vector_cate =
                                  user_fea_vec_array.add_mf_feature_vector_cate();
    // icate
    p_mf_feature_vector_cate->set_category(tokens[1]);
    // cluster
    p_mf_feature_vector_cate->set_cluster(tokens[2]);
    // ins_cnt
    if (!base::StringToDouble(tokens[4], &ins_cnt)) {
      LOG(ERROR) << "ins_cnt format error [" << tokens[4] << "]";
      return false;
    }
    p_mf_feature_vector_cate->add_weight((float)ins_cnt);
    // bias
    if (!base::StringToDouble(tokens[3], &bias)) {
      LOG(ERROR) << "bias format error [" << tokens[3] << "]";
      return false;
    }
    p_mf_feature_vector_cate->add_weight((float)bias);
    // factors
    for (int i = 5; i < reco::mf::FLAGS_fea_num + 5; ++i) {
      if (!base::StringToDouble(tokens[i], &weight)) {
        LOG(ERROR) << "factor format error [" << tokens[i] << "]";
        return false;
      }
      p_mf_feature_vector_cate->add_weight((float)weight);
    }
  }

  if (!mf_model_->UpdateUserMatrix(FLAGS_mf_version, last_uid, user_fea_vec_array)) {
    return false;
  }

  return true;
}


bool PushMatrixToRedis::PushBaseInfo() {
  LOG(INFO) << "push base info to redis start";
  uint32 fea_num;
  std::string line;
  if (!std::getline(std::cin, line)) {
    LOG(ERROR) << "get fea_num fail";
    return false;
  }
  if (!base::StringToUint(line, &fea_num)) {
    LOG(ERROR) << "convert fea_num to uint32 fail [" << line << "]";
    return false;
  }

  double avg_score;
  if (!std::getline(std::cin, line)) {
    LOG(ERROR) << "get avg_score fail";
    return false;
  }
  if (!base::StringToDouble(line, &avg_score)) {
    LOG(ERROR) << "convert avg_score to double fail [" << line << "]";
    return false;
  }

  double item_avg_score;
  if (!std::getline(std::cin, line)) {
    LOG(ERROR) << "get item avg score fail";
    return false;
  }
  if (!base::StringToDouble(line, &item_avg_score)) {
    LOG(ERROR) << "convert item_avg_score to double fail [" << line << "]";
    return false;
  }

  double user_avg_score;
  if (!std::getline(std::cin, line)) {
    LOG(ERROR) << "get user_avg_score fail";
    return false;
  }
  if (!base::StringToDouble(line, &user_avg_score)) {
    LOG(ERROR) << "convert user_avg_score to double fail [" << line << "]";
    return false;
  }

  if (!mf_model_->UpdateBaseInfo(FLAGS_mf_version, FLAGS_mf_shard, fea_num,
                  (float)avg_score, (float)user_avg_score, (float)item_avg_score)) {
    return false;
  }
  LOG(INFO) << "push base info to redis success [fea_num: " << fea_num
            << ", avg_score: " << avg_score
            << ", item_avg_score: " << item_avg_score
            << ", user_avg_score: " << user_avg_score << "]";
  return true;
}

bool PushMatrixToRedis::GetVersion() {
  std::string version;
  if (!mf_model_->GetVersion(&version)) return false;
  std::cout << "current version:" << version << std::endl;
  return true;
}

bool PushMatrixToRedis::GetNextVersion() {
  std::string version;
  mf_model_->GetNextVersion(&version);
  LOG(INFO) << "get next version:" << version << " feanum:" << reco::mf::FLAGS_fea_num;
  // cout is NECESSARY for python judegment!!!!!!!!!!!!!!!!!!
  std::cout << version << std::endl;
  return true;
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  reco::dictserver::DictServerAPIIns::instance().Init();
  PushMatrixToRedis push_to_redis;
  if (FLAGS_push_user_matrix) {
    if (!push_to_redis.PushUserMatrix()) return -1;
  }
  else if (FLAGS_push_item_matrix) {
    if (!push_to_redis.PushItemMatrix()) return -1;
  }
  else if (FLAGS_push_base_info) {
    if (!push_to_redis.PushBaseInfo()) return -1;
  }
  else if (FLAGS_push_item_list) {
    if (!push_to_redis.PushItemList()) return -1;
  }
  else if (FLAGS_update_version) {
    if (!push_to_redis.UpdateVersion()) return -1;
  }
  else if (FLAGS_get_next_version) {
    if (!push_to_redis.GetNextVersion()) return -1;
  }

  return 0;
}
