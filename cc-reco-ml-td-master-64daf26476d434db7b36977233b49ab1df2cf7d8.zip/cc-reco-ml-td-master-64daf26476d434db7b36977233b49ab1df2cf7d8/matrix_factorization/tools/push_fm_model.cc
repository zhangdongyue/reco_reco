#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/hdfs/hdfs_file_util.h"
#include "base/file/file_util.h"
#include "base/common/sleep.h"
#include "reco/reco_leaf/strategy/component/scorer/fm_inner/fm_model.h"
#include "reco/dict_server/api/dict_server_api.h"
#include "reco/proto/fm_interface.pb.h"

DEFINE_bool(push_model, false, "");
DEFINE_bool(push_tag_list, false, "");
DEFINE_bool(update_version, false, "");
DEFINE_string(tag_list_local_path, "", "tag list at local");
DEFINE_string(tag_list_name, "", "tag list at hdfs");
DEFINE_string(fm_version, "", "");
DEFINE_bool(get_version, false, "");
DEFINE_bool(get_next_version, false, "");

using std::string;
using std::vector;
using std::pair;

class PushFMModel {
 public:
  PushFMModel();
  ~PushFMModel();

  bool GetNextVersion();
  bool UpdateVersion();

  bool PushModel();
  bool PushTagList();

  bool GetVersion();
  void GetValue();

 private:
  reco::leafserver::FMModel *fm_model_;
};

PushFMModel::PushFMModel() {
  fm_model_ = new reco::leafserver::FMModel;
  reco::leafserver::FMModel::StaticInit();
}

PushFMModel::~PushFMModel() {
  delete fm_model_;
}

bool PushFMModel::UpdateVersion() {
  if (!fm_model_->UpdateVersion(FLAGS_fm_version)) {
    LOG(INFO) << "update version fail";
    return false;
  }

  LOG(INFO) << "update version success [" << FLAGS_fm_version << "]";
  return true;
}

// [IN] format:tag sign(from $category_$tag)
bool PushFMModel::PushTagList() {
  std::ifstream fin(FLAGS_tag_list_local_path);
  if (!fin.good()) {
    LOG(ERROR) << "open local file fail [" << FLAGS_tag_list_local_path << "]";
    return false;
  }

  std::string line;
  reco::FMItemTagList item_tag_list;
  while (std::getline(fin, line)) {
    base::TrimWhitespaces(&line);
    item_tag_list.add_tag_sign(line);
  }

  fin.close();
  LOG(INFO) << "load tag list success [" << item_tag_list.tag_sign_size() << "]";

  if (!fm_model_->UpdateItemTagList(FLAGS_fm_version, item_tag_list)) {
    return false;
  }
  LOG(INFO) << "push tag list to dictserver success";

  return true;
}

bool PushFMModel::SetFeature(const vector<string> &tokens, reco::FMFeature &fm_feature) {
  double weight = 0;
  if (!base::StringToDouble(tokens[2], &weight)) {
    LOG(ERROR) << "convert to double fail [" << tokens[2] << "]";
    return false;
  }
  fm_feature.set_w_weight(weight);

  for (uint32 i = 3; i < tokens.size(); ++i) {
    if (!base::StringToDouble(tokens[i], &weight)) {
      LOG(ERROR) << "convert to double fail [" << tokens[i] << "]";
      return false;
    }

    fm_feature.add_v_vector(weight);
  }

  return true;
}

// [in]0:feature sign 1:category 2:w 3+:[v]
bool PushFMModel::PushModel() {
  string line;
  // load taglist file
  std::ifstream fin(FLAGS_tag_list_name);
  if (!fin.good()) {
    LOG(ERROR) << "open file fail [" << FLAGS_tag_list_name << "]";
    return false;
  }

  unordered_set<uint64> tag_signs;
  uint64 sign = 0;
  while (std::getline(fin, line)) {
    base::TrimWhitespaces(&line);
    if (base::StringToUint64(line, &sign)) {
      tag_signs.insert(sign);
    }
  }

  fin.close();

  // read from hdfs
  vector<string> tokens;
  uint64 last_sign = 0;
  double ins_cnt = 0;
  double weight = 0;
  reco::FMFeatureArray user_fea_array;
  while (std::getline(std::cin, line)) { // each feature
    vector<string> tokens;
    base::SplitString(line, "\t", &tokens);

    if (tokens.size() < 3) {
      continue;
    }

    if (!base::StringToUint64(tokens[0], &sign)) {
      LOG(ERROR) << "convert sign to uint64 fail [" << tokens[0] << "]";
      return false;
    }

    if (tag_signs.find(sign) != tag_signs.end()) { // is tag
      reco::FMFeature tag_fea;
      if (!SetFeature(tokens, tag_fea)) {
        LOG(ERROR) << "tag SetFeature fail [" << sign << "]";
        return false;
      }

      if (!fm_model_->UpdateItemTagMatrix(FLAGS_fm_version, sign, tag_fea)) {
        LOG(ERROR) << "UpdateItemTagMatrix fail [" << sign << "]";
        return false;
      }

      continue;
    }

    // is user
    if (sign != last_sign) {
      if (last_sign > 0) {
        if (!fm_model_->UpdateUserMatrix(FLAGS_fm_version, last_sign, user_fea_array)) {
          return false;
        }
      }
      user_fea_array.Clear();
      last_sign = sign;
    }

    reco::FMFeatureWithCate *p_fm_feature_cate =
                                  user_fea_array.add_fm_feature_cate();
    p_fm_feature_cate->set_category(tokens[1]);
    if (!SetFeature(tokens, p_fm_feature_cate->fm_feature())) {
      LOG(ERROR) << "user SetFeature fail [" << sign << "]";
      return false;
    }
  }

  if (!fm_model_->UpdateUserMatrix(FLAGS_fm_version, last_sign, user_fea_array)) {
    return false;
  }

  return true;
}

bool PushFMModel::GetVersion() {
  string version;
  if (!fm_model_->GetVersion(&version)) {
    return false;
  }

  std::cout << "current version:" << version << std::endl;
  return true;
}

bool PushFMModel::GetNextVersion() {
  string version;
  fm_model_->GetNextVersion(&version);
  LOG(INFO) << "get next version:" << version;
  // cout is NECESSARY for python judegment!!!!!!!!!!!!!!!!!!
  std::cout << version << std::endl;
  return true;
}


int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  reco::dictserver::DictServerAPIIns::instance().Init();
  PushFMModel push_fm_model;
  if (FLAGS_push_model) {
    if (!push_fm_model.PushModel()) return -1;
  }
  else if (FLAGS_push_tag_list) {
    if (!push_fm_model.PushTagList()) return -1;
  }
  else if (FLAGS_update_version) {
    if (!push_fm_model.UpdateVersion()) return -1;
  }
  else if (FLAGS_get_next_version) {
    if (!push_fm_model.GetNextVersion()) return -1;
  }

  return 0;
}

