#include <iostream>
#include <string>
#include <cmath>
#include "base/strings/string_number_conversions.h"
#include "reco/reco_leaf/strategy/news_reco/mf_model.h"
#include "reco/cache_manager/cache_manager.h"
#include "reco/proto/mf_interface.pb.h"

DEFINE_string(item_id, "", "");
DEFINE_string(user_id, "", "");
DEFINE_string(mf_version, "", "");

using reco::cache_manager::CacheMgrIns;
int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  reco::cache_manager::CacheMgrIns::instance().Run();

  uint64 item_id, user_id;
  if (!base::StringToUint64(FLAGS_item_id, &item_id) ||
      !base::StringToUint64(FLAGS_user_id, &user_id)) {
    LOG(ERROR) << "item_id or user_id format error";
    return -1;
  }

  std::string version;
  if (FLAGS_mf_version.empty()) {
    if (!reco::leafserver::MFModel::GetVersionFromRedis(&version)) {
      LOG(ERROR) << "Get version from redis fail";
      return -1;
    }
  } else {
    version = FLAGS_mf_version;
  }

  std::string key, val;
  reco::leafserver::MFModel::GenBaseInfoKey(version, &key);
  if (!CacheMgrIns::instance().Get(key, &val)) {
    LOG(ERROR) << "base info key not found [" << key << "]";
    return -1;
  }
  reco::MFBaseInfo base_info;
  if (!base_info.ParseFromString(val)) {
    LOG(ERROR) << "parse base info fail";
    return -1;
  }
  std::cout << base_info.Utf8DebugString() << std::endl;

  std::string user_id_key, item_id_key;
  reco::leafserver::MFModel::GenUserIDKey(version, user_id, &user_id_key);
  reco::leafserver::MFModel::GenItemIDKey(version, item_id, &item_id_key);

  reco::MFFeatureVector user_fea_vec, item_fea_vec;
  if (!CacheMgrIns::instance().Get(user_id_key, &val)) {
    LOG(INFO) << "user_id not found in redis";
  } else {
    if (!user_fea_vec.ParseFromString(val)) {
      LOG(ERROR) << "parse user feature vector fail";
      return -1;
    }
  }
  if (!CacheMgrIns::instance().Get(item_id_key, &val)) {
    LOG(INFO) << "item_id not found in redis";
  } else {
    if (!item_fea_vec.ParseFromString(val)) {
      LOG(ERROR) << "parse item feature vector fail";
      return -1;
    }
  }

  double score = base_info.avg_score();
  if (user_fea_vec.weight_size() == 0) {
    score += base_info.user_avg_score();
    VLOG(1) << "user not found in user matrix [" << key << "]";
  } else {
    if (user_fea_vec.weight_size() != ((int)base_info.fea_num() + 1)) {
      LOG(ERROR) << "user feature vector size error ["
                 << user_fea_vec.weight_size() << ", " << base_info.fea_num() << "]";
      return -1;
    }
    score += user_fea_vec.weight(0);
    LOG(INFO) << "user avg score: " << user_fea_vec.weight(0);
  }

  if (item_fea_vec.weight_size() == 0) {
    score += base_info.item_avg_score();
    VLOG(1) << "item not found in item matrix [" << key << "]";
  } else {
    if (item_fea_vec.weight_size() != ((int)base_info.fea_num() + 1)) {
      LOG(ERROR) << "user feature vector size error ["
                 << item_fea_vec.weight_size() << ", " << base_info.fea_num() << "]";
      return -1;
    }
    score += item_fea_vec.weight(0);
  }

  if (user_fea_vec.weight_size() > 0 &&
      item_fea_vec.weight_size() > 0) {
    for (int i = 0; i < (int)base_info.fea_num(); ++i) {
      score += user_fea_vec.weight(i+1) * item_fea_vec.weight(i+1);
    }
  }
  score = 1 / (1 + exp(-score));
  LOG(INFO) << "calculate MF score success [" << user_id << "][" << item_id << "][" << score << "]";
  return 0;
}
