#pragma once
#include <string>
#include <vector>
#include "base/common/base.h"
#include "base/thread/blocking_queue.h"
#include "reco/matrix_factorization_mpi/proto/distr_psgd_mf.pb.h"

namespace net {
namespace rpc {
class RpcClientChannel;
}
}

namespace reco {
namespace leafserver {
class MFModel;
}

namespace mf {
class MFTrainClient {
 public:
  MFTrainClient();
  ~MFTrainClient();
  bool DoTrain();

  // only for debug
  void LoadTrainData();
  bool UpdateItemMatrix();

 private:
  bool ParseMachineList();
  bool InitConnect();
  bool ParseTrainDataPathList();
  bool ParseItemListPathList();
  bool ParseUserCountPathList();

  void LoadTrainData(int machine_id);
  void DoMFTrain(int machine_id);
  bool MergeMatrix();
  bool PushBaseInfoToHdfs();

  template <typename Class, typename Arg1>
  void MultiThreadProcess(void (Class::*method)(Arg1));

 private:
  std::vector<std::pair<std::string, int32> > machine_list_;
  std::vector<net::rpc::RpcClientChannel*> rpc_channels_;

  std::vector<std::string> item_list_path_list_;
  std::vector<std::string> train_data_path_list_;
  std::vector<std::string> user_count_path_list_;

  thread::BlockingQueue<std::pair<int, LoadTrainDataResponse> > load_response_queue_;
  thread::BlockingQueue<std::pair<int, DistrPSGDMFTrainResponse> > train_response_queue_;

  double avg_rating_score_;
  double item_avg_score_;
  double user_avg_score_;
  uint64 item_num_;
  uint64 user_num_;
  
  reco::leafserver::MFModel *mf_model_;
  std::string version_;
  static const char *kMFBaseInfoPath;
};
}
}
