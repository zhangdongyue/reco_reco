#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <math.h>
#include "base/common/base.h"
#include "base/strings/string_split.h"
#include "reco/proto/user.pb.h"
#include "reco/reco_model/frame/reco_model_base.h"

using std::string;
using std::vector;
using std::cout;
using std::endl;

// [IN]prefix-userid, user profile pb
// [OUT]category, userid, [topic id, topic weight]
int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  string line;
  while (std::getline(std::cin, line)) {  // each user
    vector<string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 2 || tokens[0].substr(0,8) != "uc-iflow") {
      continue;
    }

    reco::Profile user_profile;
    if (!reco::reco_model::StringToProtobuf(tokens[1], &user_profile)) {
      continue;
    }


    auto &topic_vec = user_profile.plsa_topic_feavec();
    std::unordered_map< string, vector<reco::Feature> > cate_topics;
    for (int i = 0; i < topic_vec.feature_size(); ++i) { // each topic
      auto &topic = topic_vec.feature(i);
      cate_topics[topic.category()].push_back(topic);
    }

    vector<string> keytokens;
    base::SplitString(tokens[0], "-", &keytokens);
    if (keytokens.size() < 3) {
      continue;
    }

    std::unordered_map< string, vector<reco::Feature> >::iterator ct_it;
    for (ct_it = cate_topics.begin(); ct_it != cate_topics.end(); ++ct_it) { // each cate
      cout << ct_it->first << "\t" << keytokens[2];
      // compute norm
      vector<reco::Feature>::iterator t_it;
      float norm = 0;
      for (t_it = ct_it->second.begin(); t_it != ct_it->second.end(); ++t_it) { // each topic
        norm += t_it->weight() * t_it->weight();
      }
      if (norm < 0.001) {
        continue;
      }

      norm = sqrt(norm);
      // normlize
      for (t_it = ct_it->second.begin(); t_it != ct_it->second.end(); ++t_it) { // each topic
        vector<string> topic_tokens;
        base::SplitString(t_it->literal(), "-", &topic_tokens);
        cout << "\t" << topic_tokens[1] << "\t" << t_it->weight()/norm;
      }

      cout << std::endl;
    }
  }

  return 0;
}

