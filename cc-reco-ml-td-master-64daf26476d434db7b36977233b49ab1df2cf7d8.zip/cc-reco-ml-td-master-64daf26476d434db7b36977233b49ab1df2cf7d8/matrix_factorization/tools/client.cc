#include "reco/matrix_factorization_mpi/tools/client.h"
#include <cmath>
#include <fstream>
#include "net/rpc/rpc.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/hdfs/hdfs_file_util.h"
#include "reco/cache_manager/cache_manager.h"
#include "dmp/news_recom/feature/utility/string_utility.h"

DEFINE_bool(load_train_data, false, "");
DEFINE_bool(update_item_matrix, false, "");

namespace reco {
namespace mf {

DEFINE_int32(machine_num, 3, "总共的机器数量");
DEFINE_string(machine_list, "", "MF模型训练的机器列表 \",\"分隔 e.g. 127.0.0.1:29368,127.0.0.1:29367");

DEFINE_string(item_info_dfs_path, "", "");
DEFINE_string(item_list_dfs_path_list, "", "item list 的 hdfs 路径列表");
DEFINE_string(train_data_dfs_path_list, "", "train data hdfs路径列表 \",\"分隔 e.g. path0,path1,path2");
DEFINE_string(user_count_dfs_path_list, "", "user count 的 hdfs 路径列表");

DEFINE_int32(fea_num, 50, "特征数量");
DEFINE_double(random_noise, 0.01, "random noise for initialize");
DEFINE_int32(iteration_num, 50, "迭代次数");
DEFINE_double(bias_step_ratio, 0.5, "");
DEFINE_double(bias_lambda_ratio, 0.1, "bias lambda ratio");
DEFINE_double(lambda, 0.02, "lambda");
DEFINE_double(step_len, 0.001, "step length");
DEFINE_double(step_decay_factor, 0.9, "step decay factor");
DEFINE_double(step_offset, 0, "step offset");
DEFINE_double(forgetting_exponent, 0, "forgetting Exponent");
DEFINE_string(matrix_dfs_path, "", "matrix hdfs 存放路径, 使用之前必须清空里面的文件");

// 超时时间为 5 个小时
DEFINE_int64(timeout, 1000 * 3600 * 5, "");

// for debug
DEFINE_string(ip, "", "");
DEFINE_int32(port, 0, "");
DEFINE_int32(update_group_id, 0, "");
DEFINE_int32(update_index_in_group, 0, "");

const char *MFTrainClient::kMFBaseInfoPath = "../data/base_info.txt";
MFTrainClient::MFTrainClient() {
}

MFTrainClient::~MFTrainClient() {
  for (int i = 0; i < (int)rpc_channels_.size(); ++i) {
    rpc_channels_[i]->Close();
    delete rpc_channels_[i];
  }
}

bool MFTrainClient::ParseMachineList() {
  std::vector<std::string> tokens;
  base::SplitString(FLAGS_machine_list, ",", &tokens);
  if (tokens.size() < 2) {
    LOG(ERROR) << "machine list error [" << FLAGS_machine_list << "]";
    return false;
  }
  machine_list_.clear();
  std::string key, val;
  for (int i = 0; i < (int)tokens.size(); ++i) {
    if (!dmp::string_utility::SplitKeyVal(tokens[i], ":", &key, &val)) {
      LOG(WARNING) << "machine format error [" << tokens[i] << "]";
      continue;
    }
    auto &ip = key;
    int32 port;
    if (!base::StringToInt(val, &port)) {
      LOG(WARNING) << "machine format error [" << tokens[i] << "]";
      continue;
    }
    machine_list_.push_back(std::make_pair(ip, port));
  }
  if ((int)machine_list_.size() != FLAGS_machine_num) {
    LOG(ERROR) << "machine number not match";
    return false;
  }
  return true;
}

bool MFTrainClient::ParseTrainDataPathList() {
  std::vector<std::string> tokens;
  base::SplitString(FLAGS_train_data_dfs_path_list, ",", &tokens);
  if (tokens.size() < 2) {
    LOG(ERROR) << "train data path list error [" << FLAGS_train_data_dfs_path_list << "]";
    return false;
  }
  train_data_path_list_.clear();
  for (int i = 0; i < (int)tokens.size(); ++i) {
    if (tokens[i].empty()) continue;
    train_data_path_list_.push_back(tokens[i]);
  }
  if ((int)train_data_path_list_.size() != FLAGS_machine_num) {
    LOG(ERROR) << "size of train data path not match";
    return false;
  }
  return true;
}
  
bool MFTrainClient::ParseUserCountPathList() {
  std::vector<std::string> tokens;
  base::SplitString(FLAGS_user_count_dfs_path_list, ",", &tokens);
  if (tokens.size() < 2) {
    LOG(ERROR) << "user count path list error [" << FLAGS_user_count_dfs_path_list << "]";
    return false;
  }
  user_count_path_list_.clear();
  for (int i = 0; i < (int)tokens.size(); ++i) {
    if (tokens[i].empty()) continue;
    user_count_path_list_.push_back(tokens[i]);
  }
  if ((int)user_count_path_list_.size() != FLAGS_machine_num) {
    LOG(ERROR) << "size of user count path not match";
    return false;
  }
  return true;
}

bool MFTrainClient::ParseItemListPathList() {
  std::vector<std::string> tokens;
  base::SplitString(FLAGS_item_list_dfs_path_list, ",", &tokens);
  if (tokens.size() < 2) {
    LOG(ERROR) << "item list path list error [" << FLAGS_item_list_dfs_path_list << "]";
    return false;
  }
  item_list_path_list_.clear();
  for (int i = 0; i < (int)tokens.size(); ++i) {
    if (tokens[i].empty()) continue;
    item_list_path_list_.push_back(tokens[i]);
  }
  if ((int)item_list_path_list_.size() != FLAGS_machine_num) {
    LOG(ERROR) << "size of item list path not match";
    return false;
  }
  return true;
}

bool MFTrainClient::InitConnect() {
  net::rpc::RpcClientChannel::Options rpc_option;
  rpc_option.idle_timeout = FLAGS_timeout;
  for (int i = 0; i < (int)machine_list_.size(); ++i) {
    auto channel = new net::rpc::RpcClientChannel(machine_list_[i].first,
                                                  machine_list_[i].second, rpc_option);
    if (!channel->Connect()) {
      LOG(ERROR) << "connect to server fail ["
                 << machine_list_[i].first << ":"
                 << machine_list_[i].second << "]";
      return false;
    }
    rpc_channels_.push_back(channel);
  }
  return true;
}

bool MFTrainClient::DoTrain() {
  CHECK(ParseMachineList());
  CHECK(ParseTrainDataPathList());
  CHECK(ParseItemListPathList());
  CHECK(ParseUserCountPathList());
  
  if (!InitConnect()) {
    LOG(ERROR) << "initialize connect fail";
    return false;
  }
  MultiThreadProcess(&MFTrainClient::LoadTrainData);
  double rating_score_sum = 0;
  uint64 train_instance_num = 0;
  int response_count = 0;
  std::pair<int, LoadTrainDataResponse> load_response;
  while (load_response_queue_.TryTake(&load_response) == 1) {
    int machine_id = load_response.first;
    auto &response = load_response.second;
    if (!response.success()) {
      LOG(ERROR) << "load train data fail ["
                 << machine_list_[machine_id].first << ":"
                 << machine_list_[machine_id].second << "]";
      continue;
    }
    ++response_count;
    rating_score_sum += response.rating_score_sum();
    train_instance_num += response.train_instance_num();
    LOG(INFO) << "load train data success ["
              << machine_list_[machine_id].first << ":"
              << machine_list_[machine_id].second << "]";
  }
  if (response_count != FLAGS_machine_num) {
    LOG(ERROR) << "NOT all node loading data success";
    return false;
  }

  double avg_score = rating_score_sum / train_instance_num;
  avg_rating_score_ = -log(1 / avg_score - 1);
  LOG(INFO) << "average socre " << avg_score << " " << avg_rating_score_;

  std::pair<int, DistrPSGDMFTrainResponse> train_response;
  MultiThreadProcess(&MFTrainClient::DoMFTrain);
  item_avg_score_ = 0;
  user_avg_score_ = 0;
  item_num_ = 0;
  user_num_ = 0;
  response_count = 0;
  while (train_response_queue_.TryTake(&train_response) == 1) {
    int machine_id = train_response.first;
    auto &response = train_response.second;
    if (!response.success()) {
      LOG(ERROR) << "train mf matrix fail ["
                 << machine_list_[machine_id].first << ":"
                 << machine_list_[machine_id].second << "]";
      continue;
    }
   
    ++response_count;
    item_avg_score_ += response.item_avg_score() * response.item_num();
    item_num_ += response.item_num();
    user_avg_score_ += response.user_avg_score() * response.user_num();
    user_num_ += response.user_num();
    LOG(INFO) << "train mf matrix success ["
              << machine_list_[machine_id].first << ":"
              << machine_list_[machine_id].second << "]";
  }
  if (response_count != FLAGS_machine_num) {
    LOG(ERROR) << "NOT all node training success";
    return false;
  }
  
  item_avg_score_ /= item_num_;
  user_avg_score_ /= user_num_;
  if (!PushBaseInfoToHdfs()) return false;
  return true;
}

bool MFTrainClient::PushBaseInfoToHdfs() {
  std::ofstream fout(kMFBaseInfoPath);
  if (!fout.good()) {
    LOG(ERROR) << "open mf base info file fail [" << kMFBaseInfoPath << ']';
    return false;
  }

  fout << FLAGS_fea_num << std::endl;
  fout << avg_rating_score_ << std::endl;
  fout << item_avg_score_ << std::endl;
  fout << user_avg_score_ << std::endl;
  fout.close();

  std::string dfs_path = FLAGS_matrix_dfs_path + "/base_info.txt";
  if (hadoop::HDFSExists(dfs_path.c_str()) && !hadoop::HDFSRmr(dfs_path.c_str())) {
    LOG(ERROR) << "base info file exist in hdfs and remove it fail [" << dfs_path << "]";
    return false;
  }

  LOG(INFO) << "put file to hdfs start [" << kMFBaseInfoPath << " " << dfs_path << "]";
  if (hadoop::HDFSPut(kMFBaseInfoPath, dfs_path.c_str()) != 0) {
    LOG(ERROR) << "put file to hdfs fail [" << kMFBaseInfoPath << ", " << dfs_path << "]";
    return false;
  }
  LOG(INFO) << "put file to hdfs success [" << kMFBaseInfoPath << " " << dfs_path << "]";
  return true;
}

template <typename Class, typename Arg1>
void MFTrainClient::MultiThreadProcess(void (Class::*method)(Arg1)) {
  thread::ThreadPool thread_pool(FLAGS_machine_num);
  for (int i = 0; i < FLAGS_machine_num; ++i) {
    thread_pool.AddTask(NewCallback(this, method, i));
  }
  thread_pool.JoinAll();
}

void MFTrainClient::DoMFTrain(int machine_id) {
  if (machine_id >= (int)rpc_channels_.size()) return;
  DistrPSGDMFService::Stub stub(rpc_channels_[machine_id]);
  net::rpc::RpcClientController rpc;

  DistrPSGDMFTrainRequest request;
  DistrPSGDMFTrainResponse response;
  request.set_iteration_num(FLAGS_iteration_num);

  request.set_avg_rating_score(avg_rating_score_);
  request.set_bias_step_ratio(FLAGS_bias_step_ratio);
  request.set_bias_lambda_ratio(FLAGS_bias_lambda_ratio);
  request.set_lambda(FLAGS_lambda);
  request.set_step_len(FLAGS_step_len);
  request.set_step_decay_factor(FLAGS_step_decay_factor);
  request.set_step_offset(FLAGS_step_offset);
  request.set_forgetting_exponent(FLAGS_forgetting_exponent);
  request.set_matrix_dfs_path(FLAGS_matrix_dfs_path);

  int next_id = (machine_id + FLAGS_machine_num - 1) % FLAGS_machine_num;
  request.set_update_server_ip(machine_list_[next_id].first);
  request.set_update_server_port(machine_list_[next_id].second);

  LOG(INFO) << "send distributed PSGD MF training request to "
            << machine_list_[machine_id].first << ":" << machine_list_[machine_id].second;
  stub.DistrPSGDMFTrain(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk) {
    LOG(ERROR) << "train MF matrix rpc error [" << rpc.error_text() << "]["
               << machine_list_[machine_id].first << ":"
               << machine_list_[machine_id].second << "]";
  } else {
    train_response_queue_.Put(std::make_pair(machine_id, response));
  }
  VLOG(1) << response.Utf8DebugString();
}

void MFTrainClient::LoadTrainData(int machine_id) {
  if (machine_id >= (int)rpc_channels_.size()) return;
  DistrPSGDMFService::Stub stub(rpc_channels_[machine_id]);
  net::rpc::RpcClientController rpc;

  LoadTrainDataRequest request;
  LoadTrainDataResponse response;
  request.set_item_info_dfs_path(FLAGS_item_info_dfs_path);
  request.set_item_list_dfs_path(item_list_path_list_[machine_id]);
  request.set_train_data_dfs_path(train_data_path_list_[machine_id]);
  request.set_user_count_dfs_path(user_count_path_list_[machine_id]);

  request.set_machine_num(FLAGS_machine_num);
  request.set_machine_id(machine_id);
  request.set_fea_num(FLAGS_fea_num);
  request.set_random_noise(FLAGS_random_noise);

  LOG(INFO) << "send load train data request to "
            << machine_list_[machine_id].first << ":" << machine_list_[machine_id].second;
  stub.LoadTrainData(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk) {
    LOG(ERROR) << "load train data rpc error [" << rpc.error_text() << "]["
               << machine_list_[machine_id].first << ":"
               << machine_list_[machine_id].second << "]";
  } else {
    CHECK(load_response_queue_.Put(std::make_pair(machine_id, response)));
  }
  VLOG(1) << response.Utf8DebugString();
}


bool MFTrainClient::UpdateItemMatrix() {
  net::rpc::RpcClientChannel channel(FLAGS_ip.c_str(), FLAGS_port);
  CHECK(channel.Connect());
  DistrPSGDMFService::Stub stub(&channel);
  net::rpc::RpcClientController rpc;

  UpdateItemMatrixRequest request;
  UpdateItemMatrixResponse response;

  auto item_feature = request.add_item_feature();
  item_feature->set_group_id(FLAGS_update_group_id);
  item_feature->set_index_in_group(FLAGS_update_index_in_group);
  for (int i = 0; i < FLAGS_fea_num + 1; ++i) {
    item_feature->add_weight(i);
  }
  
  stub.UpdateItemMatrix(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk ||
      !response.success()) {
    LOG(ERROR) << "update fail";
    return false;
  }
  LOG(INFO) << response.Utf8DebugString();
  return true;
}

void MFTrainClient::LoadTrainData() {
  net::rpc::RpcClientChannel channel(FLAGS_ip.c_str(), FLAGS_port);
  CHECK(channel.Connect());
  DistrPSGDMFService::Stub stub(&channel);
  net::rpc::RpcClientController rpc;

  LoadTrainDataRequest request;
  LoadTrainDataResponse response;
  request.set_item_info_dfs_path(FLAGS_item_info_dfs_path);
  request.set_item_list_dfs_path(FLAGS_item_list_dfs_path_list);
  request.set_train_data_dfs_path(FLAGS_train_data_dfs_path_list);
  request.set_user_count_dfs_path(FLAGS_user_count_dfs_path_list);
  request.set_machine_num(FLAGS_machine_num);
  request.set_machine_id(0);
  request.set_fea_num(FLAGS_fea_num);
  request.set_random_noise(FLAGS_random_noise);

  stub.LoadTrainData(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk) {
    LOG(ERROR) << "load train data fail [" << rpc.error_text() << "]";
    return;
  }
  LOG(INFO) << response.Utf8DebugString();
}
}
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "");
  reco::cache_manager::CacheMgrIns::instance().Run();
  reco::mf::MFTrainClient client;
  if (FLAGS_load_train_data) {
    client.LoadTrainData();
  } else if (FLAGS_update_item_matrix) {
    client.UpdateItemMatrix();
  } else {
    if (!client.DoTrain()) return -1;
  }
  return 0;
}
