#include <string>
#include <iostream>
#include <fstream>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "reco/matrix_factorization/tools/auc.h"

void CalcAUCF(const char* inputpath) {
  std::string line;
  CalcAUC calc_auc;
  std::vector<std::string> tokens;
  std::ifstream f_instance(inputpath);
  std::cout << "begin to load:" << std::string(inputpath) << std::endl;
  while (std::getline(f_instance, line)) {
    tokens.clear();
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 2) continue;
    double score;
    if (!base::StringToDouble(tokens[0], &score)) continue;
    int label;
    if (!base::StringToInt(tokens[1], &label)) continue;
    calc_auc.AddInstance(score, label > 0);
  }
  f_instance.close();
  std::cout << "load ok" << std::endl;
  double auc;
  if (calc_auc.GetAUC(&auc)) {
    std::cout << "auc:"<< auc << std::endl;
  }
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  CalcAUCF(argv[1]);
  return 0;
}
