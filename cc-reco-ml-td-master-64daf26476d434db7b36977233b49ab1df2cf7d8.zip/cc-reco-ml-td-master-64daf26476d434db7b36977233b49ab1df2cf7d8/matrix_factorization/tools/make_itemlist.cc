#include <iostream>
#include <fstream>
#include <string>
#include "reco/hbase_c/api/hbase_client.h"

using namespace std;

DEFINE_string(hbase_id, "10.181.169.19", "host of hbase server");
DEFINE_string(hbase_port, "9090", "port of hbase thrift2 service");
DEFINE_string(hbase_table, "tb_item_statistics", "hbase table name");
DEFINE_string(hbase_row, "9257174527797353169", "[for test]hbase table row");

bool Output(const string& itemid, reco::hbase::HBaseCli* hb_client) {
  reco::hbase::StrMap strMap;
  if (!hb_client->GetByKey(FLAGS_hbase_table, itemid, &strMap)) {
    cout<<"no key:"<<itemid<<endl;
    return false;
  }
  for (reco::hbase::StrMap::const_iterator it = strMap.begin();
      it != strMap.end(); it++) {
    cout<<"column=" << it->first << " value=" << it->second<<endl;
  }
  json_string(strMap["data:user_action"].c_str());
  return true;
}


int main(int argc, char *argv[]) {
  reco::hbase::HBaseCli *hb_client = new reco::hbase::HBaseCli(FLAGS_hbase_id, FLAGS_hbase_port);
  if (!hb_client->Connect()) {
    cout<<"Connect failed"<<endl;
    delete hb_client;
    return -1;
  }
  cout<<"Connect ok"<<endl;
//  while (std::getline(fin, line)) {
//  }
  Output(FLAGS_hbase_row, hb_client);
  hb_client->Disconnect();
  delete hb_client;
  return 0;
}

