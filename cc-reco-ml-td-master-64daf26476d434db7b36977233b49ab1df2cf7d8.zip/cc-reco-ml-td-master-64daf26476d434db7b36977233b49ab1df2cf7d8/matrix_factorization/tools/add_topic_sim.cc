#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <tr1/unordered_set>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "reco/hbase_c/api/hbase_client.h"
#include "reco/item_service/hbase_get_item.h"


using std::string;
using std::vector;
using std::tr1::unordered_set;
using std::cout;
using reco::hbase::HBaseCli;

DEFINE_string(hbase_host, "10.3.5.70", "host of hbase server");
DEFINE_string(hbase_port_str, "9090", "port of hbase thrift2 service");
DEFINE_int32(hbase_port, 9090, "port of hbase thrift2 service");

string GetParent(const string &key, HBaseCli *h_cli) {
  reco::hbase::StrMap str_map;
  reco::hbase::StrMap::iterator m_it;
  if (h_cli->GetByKey("tb_sim_item", key, &str_map) &&
      (m_it = str_map.find("sim:parentid")) != str_map.end()) {
    return m_it->second;
  }
  else {
    return key;
  }
}

void Output(const string &key, const int &show, const int &click,
            const int &trained_cnt, const string &subcate,
            HBaseCli *h_cli, reco::HBaseGetItem *p_hbgi) {
  if (key.empty()) {
    return;
  }
  cout << key << "\t" << show << "\t" << click << "\t" << trained_cnt << "\t" << subcate;

  unordered_set<string> sim_parents;
  // get sim items
  reco::hbase::StrMap str_map;
  if (h_cli->GetByKey("tb_sim_item", key, &str_map)) {
    vector<string> sim_items;
    base::SplitString(str_map["sim:list"], ",", &sim_items);
    vector<string>::iterator si_it;
    for (si_it = sim_items.begin(); si_it != sim_items.end(); ++si_it) {
      // transfer to parent
      sim_parents.insert(GetParent(*si_it, h_cli));
    }
  }
  // cout sim items
  unordered_set<string>::iterator ex_it;
  uint64 item_id;
  for (ex_it = sim_parents.begin(); ex_it != sim_parents.end(); ++ex_it) {
    if (*ex_it != key && !(ex_it->empty()) &&
        base::StringToUint64(*ex_it, &item_id)) {
      cout << "\t" << *ex_it;
    }
  }
  // get topics
  reco::RecoItem reco_item;
  if (base::StringToUint64(key, &item_id) && p_hbgi->GetRecoItem(item_id, &reco_item) &&
      reco_item.plsa_topic().norm() > 0) {
    cout << "\t" << "topics";
    for (int i = 0; i < reco_item.plsa_topic().feature_size(); ++i) { // each topic
      auto &topic = reco_item.plsa_topic().feature(i);
      cout << "\t" << topic.category() << "-" << topic.literal() << "\t"
           << topic.weight() / reco_item.plsa_topic().norm();
    }
  }

  cout << std::endl;
}

//[IN] item_id, label, trained_cnt, subcate
//[OUT] item_id, show, click, trained_cnt, subcate, [sim item's parent], "topics", [cate-plsa topic]
int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  string key;
  int click = 0;
  int this_click = 0;
  int show = 0;
  int trained_cnt = 0;
  int this_trained_cnt = 0;
  string subcate;
  string line;
  HBaseCli *h_cli = new reco::hbase::HBaseCli(FLAGS_hbase_host, FLAGS_hbase_port_str);
  reco::HBaseGetItem *p_hbgi = new reco::HBaseGetItem(FLAGS_hbase_host, FLAGS_hbase_port,
                               "tb_reco_item", 0);

  if (h_cli == NULL) {
    LOG(ERROR) << "hbase cli connect failed";
    return -1;
  }
  if (!h_cli->Connect()) {
    LOG(ERROR) << "hbase cli connect failed";
    delete h_cli;
    return -1;
  }

  while (std::getline(std::cin, line)) {
    vector<string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() != 4) {
      continue;
    }

    if (tokens[0] != key) {
      Output(key, show, click, trained_cnt, subcate, h_cli, p_hbgi);
      key = tokens[0];
      click = 0;
      show = 0;
      trained_cnt = 0;
      subcate = tokens[3];
    }

    show += 1;
    base::StringToInt(tokens[1], &this_click);
    click += this_click;
    base::StringToInt(tokens[2], &this_trained_cnt);
    if (this_trained_cnt > trained_cnt) {
      trained_cnt = this_trained_cnt;
    }

  }

  Output(key, show, click, trained_cnt, subcate, h_cli, p_hbgi);
  h_cli->Disconnect();
  delete h_cli;
  delete p_hbgi;

  return 0;
}

