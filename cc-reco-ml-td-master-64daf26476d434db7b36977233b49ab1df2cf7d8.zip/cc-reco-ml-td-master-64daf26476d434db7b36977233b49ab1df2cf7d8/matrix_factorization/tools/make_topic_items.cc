#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "reco/item_service/hbase_get_item.h"


using std::string;
using std::vector;
using std::cout;

DEFINE_string(hbase_host, "10.3.5.70", "host of hbase server");
DEFINE_int32(hbase_port, 9090, "port of hbase thrift2 service");

//[IN] item_id(already parent), [sim ids]
//[OUT] topic, itemid, weight
int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  reco::HBaseGetItem *p_hbgi = new reco::HBaseGetItem(FLAGS_hbase_host, FLAGS_hbase_port,
                                                "tb_reco_item", 0);
  string line;

  while (std::getline(std::cin, line)) {
    vector<string> tokens;
    base::SplitString(line, "\t", &tokens);
    uint64 item_id = 0;
    if (tokens.empty() || tokens[0].empty() ||
        !base::StringToUint64(tokens[0], &item_id)) {
      continue;
    }

    reco::RecoItem reco_item;
    if (p_hbgi->GetRecoItem(item_id, &reco_item)) {
      for (int i = 0; i < reco_item.plsa_topic().feature_size(); ++i) { // each topic
        auto &topic = reco_item.plsa_topic().feature(i);
        cout << topic.category() << "-" << topic.literal() << "\t" << tokens[0]
             << "\t" << topic.weight() << std::endl;
      }
    }
  }

  delete p_hbgi;
  return 0;
}

