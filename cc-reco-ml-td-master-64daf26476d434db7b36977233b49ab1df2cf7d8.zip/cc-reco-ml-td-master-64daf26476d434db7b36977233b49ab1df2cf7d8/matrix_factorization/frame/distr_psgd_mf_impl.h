#pragma once
#include "reco/matrix_factorization_mpi/proto/distr_psgd_mf.pb.h"

namespace reco {
namespace mf {

class DistrParallelSGDMFImpl : public DistrPSGDMFService {
 public:
  DistrParallelSGDMFImpl();
  virtual ~DistrParallelSGDMFImpl();

  virtual void LoadTrainData(stumy::RpcController* controller,
                             const LoadTrainDataRequest *request,
                             LoadTrainDataResponse *response,
                             Closure *done);

  virtual void DistrPSGDMFTrain(stumy::RpcController* controller,
                                const DistrPSGDMFTrainRequest *request,
                                DistrPSGDMFTrainResponse *response,
                                Closure* done);
  
  virtual void UpdateItemMatrix(stumy::RpcController* controller,
                                const UpdateItemMatrixRequest *request,
                                UpdateItemMatrixResponse *response,
                                Closure* done);
};
}
}
