#include "reco/matrix_factorization_mpi/frame/train_controller.h"
#include "reco/matrix_factorization_mpi/frame/global_data.h"
#include "base/file/file_util.h"
#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "reco/matrix_factorization_mpi/strategy/distr_psgd_mf_sigmoid.h"
#include "reco/matrix_factorization_mpi/strategy/train_data.h"

namespace reco {
namespace mf {

TrainController::TrainController() {
  global_data_ = TrainDataManager::GetGlobalData();
  CHECK(global_data_);
}

TrainController::~TrainController() {
}

bool TrainController::LoadTrainData(const LoadTrainDataRequest *request,
                                    LoadTrainDataResponse *response) {
  LOG(INFO) << request->Utf8DebugString();

  if (global_data_->mf_train_) {
    delete global_data_->mf_train_;
  }
  global_data_->machine_num = request->machine_num();
  global_data_->machine_id = request->machine_id();
  global_data_->fea_num = request->fea_num();
  global_data_->random_noise = request->random_noise();

  double rating_score_sum = 0;
  uint64 train_instance_num = 0;
  MFTrainData *mf_train_data = new MFTrainData(request);
  if (mf_train_data->ReadTrainData(&rating_score_sum, &train_instance_num)) {
    response->set_rating_score_sum(rating_score_sum);
    response->set_train_instance_num(train_instance_num);
    response->set_success(true);
    global_data_->mf_train_ = new DistrParallelSGDMF(mf_train_data);
  } else {
    delete mf_train_data;
  }
  return response->success();
}

bool TrainController::PSGDMFTrain(const DistrPSGDMFTrainRequest *request,
                                  DistrPSGDMFTrainResponse *response) {
  LOG(INFO) << request->Utf8DebugString();
  if (global_data_->mf_train_ == NULL) {
    LOG(ERROR) << "update item matrix fail: mf_train is NULL";
    return false;
  }
  if (global_data_->mf_train_->DoTrain(request, response)) {
    response->set_success(true);
  }
  return response->success();
}

bool TrainController::UpdateItemMatrix(const UpdateItemMatrixRequest *request,
                                       UpdateItemMatrixResponse *response) {
  if (global_data_->mf_train_ == NULL) {
    LOG(ERROR) << "update item matrix fail: mf_train is NULL";
    return false;
  }
  for (int i = 0; i < request->item_feature_size(); ++i) {
    if (!global_data_->mf_train_->UpdateItemMatrix(request->item_feature(i))) {
      return false;
    }
  }
  response->set_success(true);
  return true;
}

}
}
