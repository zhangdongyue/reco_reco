#pragma once
#include "serving_base/data_manager/data_manager.h"
//#include "reco/matrix_factorization_mpi/frame/train_controller.h"

namespace reco {
namespace mf {

class DistrParallelSGDMF;
class MFTrainData;
struct GlobalData;
typedef serving_base::DataManager<TrainController, GlobalData> TrainDataManager;
struct GlobalData {
  GlobalData();
  ~GlobalData();

  uint32_t machine_num;
  uint32_t machine_id;
//  int fea_num;
//  double random_noise;
//  DistrParallelSGDMF *mf_train_;
};
}
}
