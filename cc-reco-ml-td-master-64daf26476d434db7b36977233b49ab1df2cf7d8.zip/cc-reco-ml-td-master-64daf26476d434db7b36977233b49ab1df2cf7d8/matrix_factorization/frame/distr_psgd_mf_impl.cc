#include "reco/matrix_factorization_mpi/frame/distr_psgd_mf_impl.h"
#include "reco/matrix_factorization_mpi/frame/global_data.h"

namespace reco {
namespace mf {

DistrParallelSGDMFImpl::DistrParallelSGDMFImpl() {
}

DistrParallelSGDMFImpl::~DistrParallelSGDMFImpl() {
}


void DistrParallelSGDMFImpl::LoadTrainData(stumy::RpcController* controller,
                                           const LoadTrainDataRequest *request,
                                           LoadTrainDataResponse *response,
                                           Closure *done) {
  ScopedClosure scoped_closure(done);
  response->set_rating_score_sum(0);
  response->set_train_instance_num(0);
  response->set_success(false);

  TrainController *train_controller = TrainDataManager::GetControllerItem();
  if (train_controller == NULL) {
    LOG(ERROR) << "controller empty";
    return;
  }

  if (!train_controller->LoadTrainData(request, response)) {
    LOG(ERROR) << "psgd mf train fail";
    return;
  }

  TrainDataManager::ReleaseControllerItem(train_controller);
}

void DistrParallelSGDMFImpl::DistrPSGDMFTrain(stumy::RpcController* controller,
                                              const DistrPSGDMFTrainRequest *request,
                                              DistrPSGDMFTrainResponse *response,
                                              Closure* done) {
  ScopedClosure scoped_closure(done);
  response->set_success(false);
  response->set_item_matrix_dfs_path("");
  response->set_user_matrix_dfs_path("");

  TrainController *train_controller = TrainDataManager::GetControllerItem();
  if (train_controller == NULL) {
    LOG(ERROR) << "controller empty";
    return;
  }

  if (!train_controller->PSGDMFTrain(request, response)) {
    LOG(ERROR) << "psgd mf train fail";
    return;
  }

  TrainDataManager::ReleaseControllerItem(train_controller);
}

void DistrParallelSGDMFImpl::UpdateItemMatrix(stumy::RpcController* controller,
                                              const UpdateItemMatrixRequest *request,
                                              UpdateItemMatrixResponse *response,
                                              Closure* done) {
  ScopedClosure scoped_closure(done);
  response->set_success(false);
  TrainController *train_controller = TrainDataManager::GetControllerItem();
  if (train_controller == NULL) {
    LOG(ERROR) << "controller empty";
    return;
  }

  if (!train_controller->UpdateItemMatrix(request, response)) {
    LOG(ERROR) << "update item matrix fail";
    return;
  }

  TrainDataManager::ReleaseControllerItem(train_controller);
}

}
}
