#include "base/common/base.h"
#include "reco/matrix_factorization_mpi/strategy/distr_psgd_mf_sigmoid.h"
//#include "serving_base/data_manager/server_frame.h"
//#include "serving_base/utility/signal.h"
//#include "reco/matrix_factorization_mpi/frame/distr_psgd_mf_impl.h"
//#include "reco/matrix_factorization_mpi/frame/global_data.h"

//DEFINE_int32(port, 29368, "the port on which the serving application listens");
//DEFINE_int32(thread_num, 10, "thread num");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
/*  
  reco::mf::GlobalData global_data;
  serving_base::DataManangerConfig config;
  config.controller_item_num = FLAGS_thread_num;
  reco::mf::TrainDataManager::Initialize(config, &global_data);

  reco::mf::DistrParallelSGDMFImpl service;
  serving_base::ServerFrameConfig server_frame_config;
  server_frame_config.rpc_threads_num = FLAGS_thread_num;
  server_frame_config.rpc_server_port = FLAGS_port;
  server_frame_config.service = &service;
  server_frame_config.dict_manager = reco::mf::TrainDataManager::GetDictManager();
  serving_base::ServerFrame server_frame(server_frame_config);

  server_frame.Start();
  LOG(INFO) << "distributed training psgd_mf server start, thread num:"<<FLAGS_thread_num;

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();
  server_frame.Stop();
*/

  reco::mf::DistrParallelSGDMF psgdmf;
  if (psgdmf.LoadTrainData() < 0) {
    LOG(ERROR) << "server frame load data failed!";
    return -1;
  }
  LOG(INFO) << "server frame load data ok";
  if (!psgdmf.DoTrain()) {
    LOG(ERROR) << "server frame do train failed!";
    return -1;
  }
  LOG(INFO) << "server frame stop";

  return 0;

}
