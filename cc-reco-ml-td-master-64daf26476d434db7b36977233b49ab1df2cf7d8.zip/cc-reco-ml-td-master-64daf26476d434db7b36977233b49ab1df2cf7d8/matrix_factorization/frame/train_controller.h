#pragma once
#include "reco/matrix_factorization_mpi/proto/distr_psgd_mf.pb.h"

namespace reco {
namespace mf {
struct GlobalData;

class TrainController {
 public:
  explicit TrainController();
  ~TrainController();

  bool LoadTrainData(const LoadTrainDataRequest *request,
                     LoadTrainDataResponse *response);

  bool PSGDMFTrain(const DistrPSGDMFTrainRequest *request,
                   DistrPSGDMFTrainResponse *response);

  bool UpdateItemMatrix(const UpdateItemMatrixRequest *request,
                        UpdateItemMatrixResponse *response);

 private:
  GlobalData* global_data_;

  bool GetFileFromHdfs(const std::string &hdfs_path,
                       const std::string &local_path);

  bool PutFileToHdfs(const std::string &local_path,
                     const std::string &hdfs_path);
};

}
}
