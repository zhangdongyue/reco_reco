#include "reco/matrix_factorization_mpi/frame/global_data.h"
#include "reco/matrix_factorization_mpi/strategy/train_data.h"
#include "reco/matrix_factorization_mpi/strategy/distr_psgd_mf_sigmoid.h"

namespace reco {
namespace mf {

GlobalData::GlobalData() {
//  mf_train_ = NULL;
}

GlobalData::~GlobalData() {
//  delete mf_train_;
}

}
}
