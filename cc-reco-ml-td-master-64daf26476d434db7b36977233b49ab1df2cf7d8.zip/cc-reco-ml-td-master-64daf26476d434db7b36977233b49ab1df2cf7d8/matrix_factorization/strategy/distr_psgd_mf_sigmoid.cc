//mpi edition
//decong.li

#include "reco/ml/matrix_factorization/strategy/distr_psgd_mf_sigmoid.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "reco/base/hdfs/hdfs_file_util.h"
#include "mpi.h"
#include <sys/time.h>

using std::string;
using std::vector;
using std::tr1::unordered_map;
using std::tr1::unordered_set;

namespace reco {
namespace mf {

// algorithm parametres
DEFINE_int32(iteration_num, 50, "迭代次数");
DEFINE_double(bias_step_ratio, 0.5, "");
DEFINE_double(bias_lambda_ratio, 0.1, "bias lambda ratio");
DEFINE_double(lambda, 0.02, "lambda");
DEFINE_double(step_len, 0.001, "step length");
DEFINE_double(step_decay_factor, 0.9, "step decay factor");
DEFINE_double(step_offset, 0, "step offset");
DEFINE_double(forgetting_exponent, 0, "forgetting Exponent");
DEFINE_int32(shuffle_degree, 1, "shuffle degree, [1,MAX], 1=no shuffle");
DEFINE_string(train_mode, "online", "online/batch");
DEFINE_double(neighbor_param, 1.0, "neighbor discount param, MUST > 0!!!");
// engineering parametres
DEFINE_int32(update_thread_num, 5, "number of updating thread");
DEFINE_string(item_matrix_path, "../data/item_matrix.txt", "");
DEFINE_string(user_matrix_path, "../data/user_matrix.txt", "");
DEFINE_string(base_info_path, "../data/base_info.txt", "");
DEFINE_int32(mpibuddle_size, 500, "number of item in each mpi send");
DEFINE_string(matrix_dfs_path, "", "matrix hdfs 存放路径, 使用之前必须清空里面的文件");
DEFINE_int32(root_process, 0, "root process id");
DEFINE_int32(max_waitcnt, 100, "max waitcnt for send&recv");
DEFINE_int32(sleepms, 10, "sleep miliseconds");
DEFINE_int32(max_mpibuf, 46600, "max mpibuf size");


int64_t GetTimeCostU(const timeval& start, const timeval& end) {
  return (end.tv_sec-start.tv_sec)*1000000 + end.tv_usec - start.tv_usec;
}

double Sigmoid(double x) {
  if (x > 100) return 1;
  if (x < -100) return 0;
  return 1.0 / (1.0 + exp(-1.0 * x));
}

DistrParallelSGDMF::DistrParallelSGDMF() {
  train_data_ = NULL;
  block_users_ = NULL;
  block_items_ = NULL;

  int mpists = MPI_Init(NULL, NULL);
  CHECK(mpists == MPI_SUCCESS);
  int machine_id = 0;
  MPI_Comm_rank(MPI_COMM_WORLD, &machine_id);
  global_data_.machine_id = machine_id;
  int machine_num = 0;
  MPI_Comm_size(MPI_COMM_WORLD, &machine_num);
  global_data_.machine_num = (uint32_t)machine_num;

  random_ = new base::PseudoRandom(base::GetTimestamp());
  update_item_queue_ = new thread::BlockingQueue<ItemFeature>();
  train_item_queue_ = new thread::BlockingQueue<ItemTrainParameter>();

//  train_done_ = false;
  update_done_ = false;
  rating_avg_score_ = 0;
  item_avg_score_ = 0;
  user_avg_score_ = 0;
  item_num_ = 0;
  user_num_ = 0;
  iter_sum_ = 0;

  LOG(INFO) << "construted, fea_num="<< FLAGS_fea_num <<
                " train_thread_num=" << FLAGS_train_thread_num;
}

DistrParallelSGDMF::~DistrParallelSGDMF() {
  MPI_Finalize();
  delete train_data_;
  delete random_;
  delete update_item_queue_;
  delete train_item_queue_;
  delete []block_users_;
  delete []block_items_;
}

int DistrParallelSGDMF::LoadTrainData() {
  train_data_ = new MFTrainData(global_data_);
  if (!train_data_->ReadTrainData()) {
    LOG(ERROR) << "process "<< global_data_.machine_id << " read train data failed!";
    delete train_data_;
    train_data_ = NULL;
    return -1;
  }

  StatResult load_res = train_data_->results_.Take();
  double rating_score_sum = 0;
  MPI_Allreduce(&load_res.rating_score_sum, &rating_score_sum, 1,
                MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
  uint64_t train_instance_sum = 0;
  MPI_Allreduce(&load_res.train_instance_sum, &train_instance_sum, 1,
                MPI_UNSIGNED_LONG, MPI_SUM, MPI_COMM_WORLD);
  double avg_score = rating_score_sum / train_instance_sum;
  if (avg_score < 0.01) {
    avg_score = 0.01;
  }
  else if (avg_score > 0.99) {
    avg_score = 0.99;
  }
  rating_avg_score_ = -log(1 / avg_score - 1);
  iter_sum_ = train_data_->item_vectors_.size() * FLAGS_iteration_num;
  LOG(INFO) << "average score " << avg_score << " " << rating_avg_score_ <<
               " iter_sum_:" << iter_sum_;

  return 0;
}

int DistrParallelSGDMF::Shuffle(std::vector<uint32_t>& vec) {
  for (int last = vec.size()-1; last > 0; --last) {
    int swapid = random_->GetInt(0, last);
    uint32_t tmp = vec[swapid];
    vec[swapid] = vec[last];
    vec[last] = tmp;
  }
  return 0;
}

double DistrParallelSGDMF::DotProduct(const std::vector<double> &user_fea,
                                      const std::vector<double> &item_fea) {
  double score = 0;
  for (int i = 1; i < (int)user_fea.size(); ++i) {
    score += user_fea[i] * item_fea[i];
  }
  return score;
}

/*
void DistrParallelSGDMF::GetItemLock(const uint32 &item_idx, bool *p_item_flag) {
  int count = 0;
  while (!block_items_[item_idx].TryTake(p_item_flag)) {
    base::SleepForMilliseconds(FLAGS_sleepms);
    if (++count > FLAGS_max_waitcnt) {
      VLOG(1) << "item locked too long [" << item_idx << "]";
      count = 0;
    }
  }
}
*/

void DistrParallelSGDMF::OptimizeItem(ItemTrainInfo *item_train_info,
                                      const ItemTrainParameter item_train_param) {
  double step_len = item_train_param.step_len;
  bool user_flag = true;
//  bool item_flag = true;
  auto &train_instances = item_train_info->train_instances;
  struct timeval startu, endu;
  gettimeofday(&startu, NULL);
  std::vector<uint32_t> shuffle_vec;
  for (uint32_t i = 0; i < train_instances.size(); ++i) {
    shuffle_vec.push_back(i);
  }
  uint64_t seed = base::GetTimestamp();
  if (seed % FLAGS_shuffle_degree != 0) {
    random_->Reset(seed);
    Shuffle(shuffle_vec); // shuffle users
  }
  gettimeofday(&endu, NULL);

  for (uint32_t j = 0; j < shuffle_vec.size(); ++j) {  // each user of the item
    uint32_t i = shuffle_vec[j];
    uint64 user_idx = train_instances[i].first;
    double rating_score = train_instances[i].second;
    VLOG(3) << "Optimization for user [" << train_data_->user_vectors_[user_idx].user_id << "]";
    int count = 0;
    // 判断当前的 user 是否加锁
    while (!block_users_[user_idx].TryTake(&user_flag)) {
      base::SleepForMilliseconds(FLAGS_sleepms);
      if (++count > FLAGS_max_waitcnt) {
        VLOG(1) << "user locked too long [" << user_idx << "]";
        count = 0;
      }
    }

    double neighbor_score = 0;
    uint32 neighbor_size = 0;
    auto &user_train_info = train_data_->user_vectors_[user_idx];
    auto &user_fea_vec = user_train_info.fea_vec;

/*
    unordered_map<string, vector<ItemLabel> >::iterator neighbors_it;
    if ((neighbors_it = user_train_info.subcate_items.find(item_train_info->subcate))
         != user_train_info.subcate_items.end()) { // has neighbors
      vector<ItemLabel>::iterator neighbor_it;
      
      for (neighbor_it = neighbors_it->second.begin();
           neighbor_it != neighbors_it->second.end(); ++neighbor_it) {  // each neighbor item for this user-item
//        GetItemLock(neighbor_it->index, &item_flag);
        block_items_[neighbor_it->index].ReaderLock();
        neighbor_score += neighbor_it->siginver_label - rating_avg_score_ - user_fea_vec[0]
                          - train_data_->item_vectors_[neighbor_it->index].fea_vec[0];
//        CHECK(block_items_[neighbor_it->index].TryPut(item_flag));
        block_items_[neighbor_it->index].ReaderUnlock();
      }

      neighbor_size = neighbors_it->second.size();
      neighbor_score /= neighbors_it->second.size() + FLAGS_neighbor_param;
    }
*/

    auto &item_fea_vec = item_train_info->fea_vec;
    double sum_score = rating_avg_score_ + user_fea_vec[0] + item_fea_vec[0] +
                       DotProduct(user_fea_vec, item_fea_vec) + neighbor_score;
    double exp_negsum = exp(-1.0 * sum_score);
    double predict_score = 1 / (1 + exp_negsum);
    double err = rating_score - predict_score;
    double alter = exp_negsum / (1 + exp_negsum) / (1 + exp_negsum);
    user_fea_vec[0] += FLAGS_bias_step_ratio * step_len *
         (err * alter * FLAGS_neighbor_param / (neighbor_size + FLAGS_neighbor_param) -
         FLAGS_bias_lambda_ratio * FLAGS_lambda * user_fea_vec[0]);
//    block_items_[item_train_param.index].WriterLock();
    item_fea_vec[0] += FLAGS_bias_step_ratio * step_len *
                       (err * alter - FLAGS_bias_lambda_ratio * FLAGS_lambda * item_fea_vec[0]);
//    block_items_[item_train_param.index].WriterUnlock();

    for (int k = 1; k < (int)user_fea_vec.size(); ++k) {
      double user_fea_weight = user_fea_vec[k];
      double item_fea_weight = item_fea_vec[k];
      user_fea_vec[k] += step_len *
                         (err * alter * item_fea_weight - FLAGS_lambda * user_fea_weight);
      item_fea_vec[k] += step_len * 
                         (err * alter * user_fea_weight - FLAGS_lambda * item_fea_weight);
    }

    // 释放 user 锁
    CHECK(block_users_[user_idx].TryPut(user_flag));
  }
}

void DistrParallelSGDMF::OptimizeItemVector(int thread_id) {
  LOG(INFO) << "optimize item vector thread start [thread_id: " << thread_id << "]";
  ItemTrainParameter item_train_param(0, 0);
  while (true) {
    uint32_t itercnt = iter_cnt_.Take();
    iter_cnt_.TryPut(itercnt);
    if (itercnt >= iter_sum_ && train_item_queue_->Empty()) {
      break;
    }

    if (train_item_queue_->TryTake(&item_train_param) != 1) {
      VLOG(2) << "want to train item, update_Q:" << update_item_queue_->Size() <<
                 " train_Q:" << train_item_queue_->Size();
      base::SleepForMilliseconds(FLAGS_sleepms);
      continue;
    }

    auto &item_train_info = train_data_->item_vectors_[item_train_param.index];
    VLOG(2) << "got a item:" << item_train_info.item_id;
    // 优化 Item 向量
    OptimizeItem(&item_train_info, item_train_param);
    VLOG(2) << "finish Optimize item:" << item_train_info.item_id;
    // 放入更新队列
    UpdateItemQueue(item_train_param.index, item_train_info);
    VLOG(2) << "finish into ItemQueue item:" << item_train_info.item_id;
  }

  LOG(INFO) << "optimize item vector thread end [thread_id: " << thread_id << "]";
}

void DistrParallelSGDMF::CollectItems() {
  double step_len = GetStepLength(0);
  int cnt = 0;
  for (uint32 idx = 0; idx < train_data_->item_vectors_.size(); ++idx) {
    if (train_data_->item_vectors_[idx].item_id % global_data_.machine_num ==
        global_data_.machine_id) {
      CHECK(train_item_queue_->Put(ItemTrainParameter(idx, step_len)));
      cnt++;
    }
  }
  iter_cnt_.TryPut(cnt);
  LOG(INFO) << "initial collect items end,size:"<<cnt;
}

void DistrParallelSGDMF::UpdateItemQueue(const uint32 index,
                                         const ItemTrainInfo& item_train_info) {
  ItemFeature item_feature;
  item_feature.set_index(index);
  auto &fea_vec = item_train_info.fea_vec;
  for (int i = 0; i < (int)fea_vec.size(); ++i) {
    item_feature.add_weight(fea_vec[i]);
  }
  CHECK(update_item_queue_->Put(item_feature));
  VLOG(2)<<"into updateQ:"<< index;
}

double DistrParallelSGDMF::GetStepLength(int iter_time) {
  double step_len = FLAGS_step_len *
                    pow(FLAGS_step_decay_factor, iter_time) *
                    pow(iter_time + 1 + FLAGS_step_offset, FLAGS_forgetting_exponent);
  return step_len;
}

bool DistrParallelSGDMF::DoTrain() {
  int user_num = (int)train_data_->user_vectors_.size();
  if (block_users_) {
    delete []block_users_;
  }
  block_users_ = new thread::BlockingVar<bool>[user_num];
  for (int i = 0; i < (int)user_num; ++i) {
    CHECK(block_users_[i].TryPut(true));
  }

  int item_num = (int)train_data_->item_vectors_.size();
  if (block_items_) {
    delete []block_items_;
  }
  block_items_ = new thread::RWMutex[item_num];

  CollectItems();
  mpi_lock_.TryPut(true);
  LOG(INFO) << "mpi init ok";
  thread::ThreadPool send_thread_pool(FLAGS_update_thread_num);
  thread::ThreadPool recv_thread_pool(FLAGS_update_thread_num);
  for (int i = 0; i < FLAGS_update_thread_num; ++i) {
    send_thread_pool.AddTask(NewCallback(this, &DistrParallelSGDMF::SendItemMatrix, i));
    recv_thread_pool.AddTask(NewCallback(this, &DistrParallelSGDMF::RecvItemMatrix, i));
  }

  thread::ThreadPool train_thread_pool(FLAGS_train_thread_num);
  for (int i = 0; i < FLAGS_train_thread_num; ++i) {
    train_thread_pool.AddTask(NewCallback(this, &DistrParallelSGDMF::OptimizeItemVector, i));
  }
  train_thread_pool.JoinAll();
  LOG(INFO) << "PSGD Optimization succeed [node_id: " << global_data_.machine_id << "]";

  update_done_ = true;
  send_thread_pool.JoinAll();
  recv_thread_pool.JoinAll();
  LOG(INFO) << "all update item feature vector thread succeed [node_id: "
            << global_data_.machine_id << "]";
  delete []block_users_;
  block_users_ = NULL;

  if (!WriteItemMatrix() || !WriteUserMatrix() || !UploadToHdfs()) {
    return false;
  }
  LOG(INFO) << "all train process succeed [node_id: " << global_data_.machine_id << "]";

  if (!PushBaseInfoToHdfs()) {
    LOG(ERROR) << "process id:" << global_data_.machine_id << "PushBaseInfoToHdfs falied";
    return false;
  }

  return true;
}

bool DistrParallelSGDMF::PushBaseInfoToHdfs() {  
  uint32_t item_num_sum = 0;
  MPI_Reduce(&item_num_, &item_num_sum, 1, MPI_UNSIGNED, MPI_SUM,
             FLAGS_root_process, MPI_COMM_WORLD);
  LOG(INFO) << "reduce item_num ok";
  double item_score = item_avg_score_ * item_num_;
  double item_avg_score_all = 0;
  MPI_Reduce(&item_score, &item_avg_score_all, 1, MPI_DOUBLE, MPI_SUM,
             FLAGS_root_process, MPI_COMM_WORLD);
  LOG(INFO) << "reduce item_score ok";
  item_avg_score_all /= item_num_sum;

  uint32_t user_num_sum = 0;
  MPI_Reduce(&user_num_, &user_num_sum, 1, MPI_UNSIGNED, MPI_SUM,
             FLAGS_root_process, MPI_COMM_WORLD);
  LOG(INFO) << "reduce user_num ok";
  double user_score = user_avg_score_ * user_num_;
  double user_avg_score_all = 0;
  MPI_Reduce(&user_score, &user_avg_score_all, 1, MPI_DOUBLE, MPI_SUM,
             FLAGS_root_process, MPI_COMM_WORLD);
  LOG(INFO) << "reduce user_score ok";
  user_avg_score_all /= user_num_sum;

  if ((int)global_data_.machine_id == FLAGS_root_process) {
    std::ofstream fout(FLAGS_base_info_path);
    if (!fout.good()) {
      LOG(ERROR) << "open mf base info file fail [" << FLAGS_base_info_path << ']';
      return false;
    }
    fout << FLAGS_fea_num << std::endl;
    fout << rating_avg_score_ << std::endl;
    fout << item_avg_score_all << std::endl;
    fout << user_avg_score_all << std::endl;
    fout.close();

    std::string dfs_path = FLAGS_matrix_dfs_path + "/base_info.txt";
    if (hdfs::HDFSExists(dfs_path.c_str())) {
      LOG(ERROR) << "hdfs alredy exist [" << dfs_path << ']';
      return false;
    }
    if (!MFTrainData::PutFileToHdfs(FLAGS_base_info_path, dfs_path)) {
      return false;
    }
  }

  return true;
}

bool DistrParallelSGDMF::WriteItemMatrix() {
  std::string path = FLAGS_item_matrix_path + "." +
                     base::IntToString(global_data_.machine_id);
  std::ofstream item_fout(path);
  if (!item_fout.good()) {
    LOG(ERROR) << "open item matrix file fail [" << path << "]";
    return false;
  }

  LOG(INFO) << "write item matrix to file start [" << path << "]";
  item_num_ = 0;
  for (uint32 idx = 0; idx < train_data_->item_vectors_.size(); ++idx) {
    if (train_data_->item_vectors_[idx].item_id % global_data_.machine_num !=
        global_data_.machine_id) {
      continue;
    }
    uint64 item_id = train_data_->item_vectors_[idx].item_id;
    auto &fea_vec = train_data_->item_vectors_[idx].fea_vec;
    item_avg_score_ += fea_vec[0];
    item_fout << "M\t" << item_id << "\t1\t1";
    for (int j = 0; j < (int)fea_vec.size(); ++j) {
      item_fout << '\t' << std::fixed << std::setprecision(5) << fea_vec[j];
    }
    item_fout << std::endl;
    ++item_num_;
  }

  item_fout.close();
  LOG(INFO) << "write item matrix to file succeed [" << item_num_ << "][" << path << "]";  
  item_avg_score_ /= item_num_;

  return true;
}

bool DistrParallelSGDMF::WriteUserMatrix() {
  std::string path = FLAGS_user_matrix_path + "." +
                     base::IntToString(global_data_.machine_id);
  std::ofstream user_fout(path);
  if (!user_fout.good()) {
    LOG(ERROR) << "open user matrix file fail [" << path << "]";
    return false;
  }

  LOG(INFO) << "write user matrix to file start [" << path << "]";
  auto &user_vectors = train_data_->user_vectors_;
  user_num_ = 0;
  for (int i = 0; i < (int)user_vectors.size(); ++i) { // each user
    if (!user_vectors[i].avaliable) {
      continue;
    }
    uint64 user_id = user_vectors[i].user_id;
    auto &fea_vec = user_vectors[i].fea_vec;
    user_avg_score_ += fea_vec[0];
    user_fout << "U\t" << user_id << '\t' << rating_avg_score_ << '\t'
              << fea_vec[0] << '\t' << user_vectors[i].ins_cnt;
    for (int j = 1; j < (int)fea_vec.size(); ++j) {
      user_fout << '\t' << std::fixed << std::setprecision(5) << fea_vec[j];
    }
/*
    auto &subcate_items = user_vectors[i].subcate_items;
    unordered_map<string, vector<ItemLabel> >::iterator ci_it;
    for (ci_it = subcate_items.begin(); ci_it != subcate_items.end();
         ++ci_it) { // each 2nd cate under the user
      vector<ItemLabel>::iterator il_it;
      float neighbor_score = 0;
      for (il_it = ci_it->second.begin(); il_it != ci_it->second.end();
           ++il_it) { // each item under the 2nd cate
        neighbor_score += il_it->siginver_label - rating_avg_score_ - fea_vec[0] -
                          train_data_->item_vectors_[il_it->index].fea_vec[0];
      }
      neighbor_score /= ci_it->second.size() + FLAGS_neighbor_param;
      user_fout << '\t' << ci_it->first << '\t' << neighbor_score;
    }
*/
    user_fout << std::endl;
    ++user_num_;
    if (i && i % 1000000 == 0) {
      double r = (double)i / user_vectors.size();
      LOG(INFO) << "write user matrix proceeding [" << r << "]";
    }

  }
  user_fout.close();
  LOG(INFO) << "write user matrix to file succeed [" << user_num_ << "][" << path << "]";
  user_avg_score_ /= user_vectors.size();

  return true;
}

bool DistrParallelSGDMF::UploadToHdfs() {
  std::string item_dfs_path = base::StringPrintf("%s/item_matrix_%05d",
              FLAGS_matrix_dfs_path.c_str(), global_data_.machine_id);
  if (hdfs::HDFSExists(item_dfs_path.c_str())) {
    LOG(ERROR) << "hdfs alredy exist [" << item_dfs_path << ']';
    return false;
  }
  std::string user_dfs_path = base::StringPrintf("%s/user_matrix_%05d",
              FLAGS_matrix_dfs_path.c_str(), global_data_.machine_id);
  if (hdfs::HDFSExists(user_dfs_path.c_str())) {
    LOG(ERROR) << "hdfs alredy exist [" << user_dfs_path << ']';
    return false;
  }
  std::string item_matrix_path = FLAGS_item_matrix_path + "." +
                                 base::IntToString(global_data_.machine_id);
  std::string user_matrix_path = FLAGS_user_matrix_path + "." +
                                 base::IntToString(global_data_.machine_id);
  if (!MFTrainData::PutFileToHdfs(item_matrix_path, item_dfs_path) ||
      !MFTrainData::PutFileToHdfs(user_matrix_path, user_dfs_path)) {
    return false;
  }

  return true;
}

bool DistrParallelSGDMF::UpdateItemMatrix(const ItemFeature &item_feature,
                                          const bool &need_train) {
  auto &item_train_info = train_data_->item_vectors_[item_feature.index()];
  if ((int)item_train_info.fea_vec.size() != item_feature.weight_size()) {
    LOG(ERROR) << "item feature size not match [" << item_feature.index() <<
                   "]fsize=" << item_train_info.fea_vec.size() <<
                   " wsize=" << item_feature.weight_size();
    return false;
  }

/*
  block_items_[item_feature.index()].WriterLock();
  item_train_info.fea_vec[0] = item_feature.weight(0);
  block_items_[item_feature.index()].WriterUnlock();
*/

  if (!need_train) { // for non-downstream process, just update item bias
    return true;
  }

  for (int i = 1; i < item_feature.weight_size(); ++i) {
    item_train_info.fea_vec[i] = item_feature.weight(i);
  }
  uint32_t itercnt = iter_cnt_.Take();
  if (itercnt >= iter_sum_) {
    iter_cnt_.TryPut(itercnt);
    return true;
  }
  ++itercnt;
  iter_cnt_.TryPut(itercnt);
  double step_len = GetStepLength(itercnt / train_data_->item_vectors_.size());
  CHECK(train_item_queue_->Put(ItemTrainParameter(item_feature.index(), step_len)));
  VLOG(2) << "iter:" << itercnt << " update item:" << item_feature.index()
          << "-" << item_train_info.item_id;
  if (itercnt % 10000 == 0) {
    LOG(INFO) << "milestone:" << itercnt << "-" << (float)itercnt / iter_sum_;
  }

  return true;
}

void DistrParallelSGDMF::SendItemMatrix(int thread_id) {
  LOG(INFO) << "send item feature vector thread start [thread_id: " << thread_id << "]";
  UpdateItemMatrixRequest itempack_s;
  ItemFeature item_feature;
  MPI_Status status_s;
//  MPI_Request mpirequest_s;
  int process_id = 0, process_num = 0;
  mpi_lock_.Take();
  MPI_Comm_rank(MPI_COMM_WORLD, &process_id);
  MPI_Comm_size(MPI_COMM_WORLD, &process_num);
  mpi_lock_.TryPut(true);
  vector<MPI_Request> mpirequest_s_vec(process_num);
//  int recv_id = (process_id + process_num - 1) % process_num;
  VLOG(2) << "processid:" << process_id;
  int waitcnt = 0;
  int round = 1;  // 0 is for end signal
  int bufsize_s = 0;
  char* buf_s = new char[FLAGS_max_mpibuf];
  int flag = 1;
  bool total_flag = true;

  while (!update_done_ || !update_item_queue_->Empty() ||
         itempack_s.item_feature_size() > 0) {
    // check if can do send
    if (itempack_s.item_feature_size() < FLAGS_mpibuddle_size) {  // < max buffsize
      if (update_item_queue_->TryTake(&item_feature) == 1) {  // get item ok
        VLOG(2) << "thread " << thread_id << " send item "<< item_feature.index();
        itempack_s.add_item_feature()->CopyFrom(item_feature);
        item_feature.Clear();
        continue;
      }
      // get item fail
      VLOG(2) << "thread " << thread_id << " meet empty update_Q";
      if (waitcnt < FLAGS_max_waitcnt || itempack_s.item_feature_size() <= 0) {
        VLOG(2) << "thread " << thread_id << " wc:" << waitcnt <<
                   " ifs:" << itempack_s.item_feature_size();
        ++waitcnt;
        base::SleepForMilliseconds(FLAGS_sleepms);
        continue;
      }
    }
    // check last send
    if (round > 1) {
      total_flag = true;
      for (int recv_id = 0; recv_id < process_num; ++recv_id) {
        if (recv_id != process_id) {
          mpi_lock_.Take();
          MPI_Test(&mpirequest_s_vec[recv_id], &flag, &status_s);
          mpi_lock_.TryPut(true);
          if (!flag) {
            VLOG(2) << "thread " << thread_id << " send not ok to " << recv_id;
            total_flag = false;
            break;
          }
        }
      }

      if (!total_flag) {
        VLOG(2) << "thread " << thread_id << " sending";
        base::SleepForMilliseconds(FLAGS_sleepms);
        continue;
      }
    }
    // do send
    VLOG(2) << "thread " << thread_id << " do send, item num:" <<
               itempack_s.item_feature_size();
    waitcnt = 0;
    bufsize_s = itempack_s.ByteSize();
    if (bufsize_s > FLAGS_max_mpibuf) {
      LOG(ERROR) << "bufsize_s too large!";
      return;
    }
    if (!itempack_s.SerializeToArray(buf_s, bufsize_s)) {
      LOG(ERROR) << "thread " << thread_id << " SerializeToArray fail";
    }
    int ifsize_tmp = itempack_s.item_feature_size();
    itempack_s.Clear();

    for (int recv_id = 0; recv_id < process_num; ++recv_id) {
      if (recv_id != process_id) {
        mpi_lock_.Take();
        MPI_Isend(buf_s, bufsize_s, MPI_CHAR, recv_id, round, MPI_COMM_WORLD,
                  &mpirequest_s_vec[recv_id]);
        mpi_lock_.TryPut(true);
        VLOG(2) << "thread:" << thread_id << " send to:" << recv_id <<
                   " item num:" << ifsize_tmp << " bufsize:" << bufsize_s << " tag:" << round;
      }
    }

    VLOG(2) << "thread " << thread_id << " round "<< round << " done";
    ++round;
  }

  // test last send
  while (true) {
    total_flag = true;
    for (int recv_id = 0; recv_id < process_num; ++recv_id) {
      if (recv_id != process_id) {
        mpi_lock_.Take();
        MPI_Test(&mpirequest_s_vec[recv_id], &flag, &status_s);
        mpi_lock_.TryPut(true);
        if (!flag) {
          total_flag = false;
          break;
        }
      }
    }

    if (total_flag) {
      VLOG(2) << "thread " << thread_id << " last send ok";
      break;
    }
    base::SleepForMilliseconds(FLAGS_sleepms);
  }

  // send end signal
  itempack_s.Clear();
  bufsize_s = itempack_s.ByteSize();
  if (!itempack_s.SerializeToArray(buf_s, bufsize_s)) {
    LOG(ERROR) << "thread " << thread_id << " SerializeToArray fail";
  }

  VLOG(2) << "thread " << thread_id << " will send end";
  for (int recv_id = 0; recv_id < process_num; ++recv_id) {
    if (recv_id != process_id) {
      VLOG(2) << "thread " << thread_id << " will send end to " << recv_id;
      mpi_lock_.Take();
      MPI_Isend(buf_s, bufsize_s, MPI_CHAR, recv_id, 0, MPI_COMM_WORLD,
                &mpirequest_s_vec[recv_id]);
      mpi_lock_.TryPut(true);
    }
  }
  
  while (true) {
    total_flag = true;
    for (int recv_id = 0; recv_id < process_num; ++recv_id) {
      if (recv_id != process_id) {
        mpi_lock_.Take();
        MPI_Test(&mpirequest_s_vec[recv_id], &flag, &status_s);
        mpi_lock_.TryPut(true);
        if (!flag) {
          total_flag = false;
          break;
        }
      }
    }

    if (total_flag) {
      VLOG(2) << "thread " << thread_id << " send end signal ok";
      break;
    }
    base::SleepForMilliseconds(FLAGS_sleepms);
  }

  delete [] buf_s;
  buf_s = NULL;
  LOG(INFO) << "send item feature vector thread end [thread_id: " << thread_id << "]";
}

void DistrParallelSGDMF::RecvItemMatrix(const int thread_id) {
  LOG(INFO) << "recv item feature vector thread start [thread_id: " << thread_id << "]";
  ItemFeature item_feature;
  int process_id = 0, process_num = 0;
  mpi_lock_.Take();
  MPI_Comm_rank(MPI_COMM_WORLD, &process_id);
  MPI_Comm_size(MPI_COMM_WORLD, &process_num);
  mpi_lock_.TryPut(true);
  vector<MPI_Status> status_r_vec(process_num);
  vector<MPI_Request> mpirequest_r_vec(process_num);
  int main_send_id = (process_id + 1) % process_num;
  VLOG(2) << "processid:" << process_id << "<=" << main_send_id;
  int round = 1; // not 0
  int bufsize_r = 0;
  char **buf_r_vec = new char*[process_num];
  for (int i = 0; i < process_num; ++i) {
    buf_r_vec[i] = new char[FLAGS_max_mpibuf];
  }

//  vector<bool> process_doing(process_num, true);
//  process_doing[process_id] = false; // self is excluded
  unordered_set<int> end_processes;
  end_processes.insert(process_id); // self is excluded

  while (true) {
    vector<UpdateItemMatrixRequest> itempack_r_vec(process_num);
    unordered_set<int> unrecv_processes;
    unrecv_processes.insert(process_id);
    // check last recv
    if (round > 1) {
      // check if recv ok
//      bool total_recv_flag = true;
//      bool total_end = true;
      for (int send_id = 0; send_id < process_num; ++send_id) {
        if (end_processes.find(send_id) != end_processes.end()) {
          continue;
        }

        int recv_flag = 0;
        mpi_lock_.Take();
        int mpires = MPI_Test(&mpirequest_r_vec[send_id], &recv_flag, &status_r_vec[send_id]);
        mpi_lock_.TryPut(true);
        VLOG(2) << "thread:" << thread_id << " process " << process_id <<
                   " from " << send_id << ":" << status_r_vec[send_id].MPI_SOURCE << 
                   " flag " << recv_flag << " mpires " << mpires <<
                   " tag " << status_r_vec[send_id].MPI_TAG;

        if (!recv_flag) { // hasn't been recv
//          total_recv_flag = false;
          unrecv_processes.insert(send_id);
          continue;
        }

        if (status_r_vec[send_id].MPI_TAG == 0) { // recv end signal
          end_processes.insert(send_id);
        }
        else if (status_r_vec[send_id].MPI_TAG > 0) { // recv ok          
          mpi_lock_.Take();
          MPI_Get_count(&status_r_vec[send_id], MPI_CHAR, &bufsize_r);
          mpi_lock_.TryPut(true);
          if (!itempack_r_vec[send_id].ParseFromArray(buf_r_vec[send_id], bufsize_r)) {
            LOG(ERROR) << "thread " << thread_id << " parse fail from " << send_id;
          }
//          total_end = false;
        }
      }

      if ((int)end_processes.size() == process_num) { // all are end
        VLOG(2) << "thread " << thread_id << " recv total end signal";
        break;
      }

      if ((int)unrecv_processes.size() == process_num) { // non is recv
        VLOG(2) << "thread " << thread_id << " recving";
        base::SleepForMilliseconds(FLAGS_sleepms);
        continue;
      }

    }

    // get this recv
    for (int send_id = 0; send_id < process_num; ++send_id) {
      if (end_processes.find(send_id) != end_processes.end() ||
          unrecv_processes.find(send_id) != unrecv_processes.end()) {
        continue;
      }
      mpi_lock_.Take();
      MPI_Irecv(buf_r_vec[send_id], FLAGS_max_mpibuf, MPI_CHAR, send_id, MPI_ANY_TAG,
                MPI_COMM_WORLD, &mpirequest_r_vec[send_id]);
      mpi_lock_.TryPut(true);
    }

    // process last recv
    for (int send_id = 0; send_id < process_num; ++send_id) {
      if (end_processes.find(send_id) != end_processes.end() ||
          unrecv_processes.find(send_id) != unrecv_processes.end()) {
        continue;
      }
      bool need_train = false;
      if (send_id == main_send_id) {
        need_train = true;
      }
      auto &itempack_r = itempack_r_vec[send_id];
      for (int i = 0; i < itempack_r.item_feature_size(); ++i) {
        if (!UpdateItemMatrix(itempack_r.item_feature(i), need_train)) {
          LOG(ERROR) << "mpi update item matrix fail.";
          return;
        }
      }
    }

    VLOG(2) << "thread " << thread_id << " round "<< round << " done";
    ++round;
  }

  for (int i = 0; i < process_num; ++i) {
    delete []buf_r_vec[i];
  }
  delete []buf_r_vec;
  buf_r_vec = NULL;

  LOG(INFO) << "recv item feature vector thread end [thread_id: " << thread_id << "]";

/*
  LOG(INFO) << "recv item feature vector thread start [thread_id: " << thread_id << "]";
  ItemFeature item_feature;
  MPI_Status status_r;
  MPI_Request mpirequest_r;
  int process_id = 0, process_num = 0;
  mpi_lock_.Take();
  MPI_Comm_rank(MPI_COMM_WORLD, &process_id);
  MPI_Comm_size(MPI_COMM_WORLD, &process_num);
  mpi_lock_.TryPut(true);
  int main_send_id = (process_id + 1) % process_num;
  VLOG(2) << "processid:" << process_id << "<=" <<send_id;
  int round_sub = 0;
  int bufsize_r = 0;
  char* buf_r = new char[FLAGS_max_mpibuf];
  int flag = 1;
  bool all_doing = true;
  vector<bool> process_doing(process_num, true);
  int tocheck_id = 0;

  while (all_doing) {
    all_doing = false;
    for (int send_id = thread_id; send_id < process_num; send_id += thread_num;) {
      if (send_id == process_id) {
        continue;
      }
      // check last recv
      UpdateItemMatrixRequest itempack_r;
      if (round_sub > 0 && process_doing[tocheck_id]) {
        mpi_lock_.Take();
        MPI_Test(&mpirequest_r, &flag, &status_r);
        if (flag) {
          MPI_Get_count(&status_r, MPI_CHAR, &bufsize_r);
        }
        mpi_lock_.TryPut(true);
        if (flag) {
          itempack_r.ParseFromArray(buf_r, bufsize_r);
          if (itempack_r.item_feature_size() == 0) {
            process_doing[tocheck_id] = false;
            VLOG(2) << "thread " << thread_id << "recv end signal from " << tocheck_id;
            //break;
          } else {
            all_doing = true;
          }
        } else {
          VLOG(2) << "thread " << thread_id << " recving from " << tocheck_id;
          base::SleepForMilliseconds(FLAGS_sleepms);
          continue;
        }
      }

      // get new recv
      if 
      mpi_lock_.Take();
      MPI_Irecv(buf_r, FLAGS_max_mpibuf, MPI_CHAR, send_id, 0, MPI_COMM_WORLD, &mpirequest_r);
      mpi_lock_.TryPut(true);
      tocheck_id = send_id;

      // process last recv
      for (int i = 0; i < itempack_r.item_feature_size(); ++i) {
        if (!UpdateItemMatrix(itempack_r.item_feature(i))) {
          LOG(ERROR) << "mpi update item matrix fail.";
          return;
        }
      }
      VLOG(2) << "thread " << thread_id << " round_sub " << round_sub << " done";
      ++round_sub;
    }

  }

  delete [] buf_r;
  buf_r = NULL;
  LOG(INFO) << "recv item feature vector thread end [thread_id: " << thread_id << "]";
*/

}

}
}
