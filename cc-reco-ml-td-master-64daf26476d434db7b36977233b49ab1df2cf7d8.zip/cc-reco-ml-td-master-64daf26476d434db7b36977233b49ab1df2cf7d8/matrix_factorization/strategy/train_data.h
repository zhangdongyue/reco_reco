#pragma once
#include <string>
#include <vector>
#include <tr1/unordered_map>
#include <tr1/unordered_set>
#include <fstream>
#include "base/common/base.h"
#include "base/random/pseudo_random.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "reco/ml/matrix_factorization/proto/distr_psgd_mf.pb.h"

namespace reco {
namespace mf {

DECLARE_int32(fea_num);
DECLARE_int32(train_thread_num);

struct GlobalData {
  uint32_t machine_num;
  uint32_t machine_id;
};

typedef std::vector<double> FeaVec;

typedef std::pair<uint64, double> UserLabel;  // user_index, label

struct ItemLabel {
  uint32 index;
  double siginver_label; // inverse sigmoid label;
};

struct UserTrainInfo {
  UserTrainInfo() {
    user_id = 0;
    fea_vec.resize(FLAGS_fea_num + 1, 0);
    avaliable = true;
  }
  uint64 user_id;
  FeaVec fea_vec;
  bool avaliable;
  int ins_cnt;
  std::tr1::unordered_map<std::string, std::vector<ItemLabel> > subcate_items;
};

typedef std::vector<UserTrainInfo> UserTrainInfoVector;

struct ItemTrainInfo {
  ItemTrainInfo() {
    item_id = 0;
    fea_vec.resize(FLAGS_fea_num + 1, 0);
    train_instances.reserve(50000);
  }
  uint64 item_id;
  FeaVec fea_vec;
  std::vector<UserLabel> train_instances;
  std::string subcate;  // sub category
};

typedef std::vector<ItemTrainInfo> ItemTrainInfoVector;

struct StatResult {
  StatResult() {
    rating_score_sum = 0;
    train_instance_sum = 0;
  }
  void Update(double r, uint64 t) {
    rating_score_sum += r;
    train_instance_sum += t;
  }
  double rating_score_sum;
  uint64 train_instance_sum;
};

struct ExpandedItem {
  uint64 id;
  double score;
};

class MFTrainData {
 public:
  MFTrainData(const GlobalData& global_data);
  ~MFTrainData();

  bool ReadTrainData();

  static bool PutFileToHdfs(const std::string &local_path, const std::string &hdfs_path);

 public:
  UserTrainInfoVector user_vectors_;
  ItemTrainInfoVector item_vectors_;
  thread::BlockingVar<StatResult> results_;
  std::tr1::unordered_map<uint64, uint32> itemid_idx_;
  std::vector<std::string> unchanged_item_matrix_;

 private:
  bool read_done_;
  thread::BlockingQueue<std::string> train_instance_queue_;
  thread::BlockingVar<bool> user_vectors_lock_;
  thread::BlockingVar<bool> *item_instance_lock_;
  uint32 group_num_;
  GlobalData global_data_;
  base::PseudoRandom *random_;
  std::tr1::unordered_map< uint64, std::vector<ExpandedItem> > expanded_items_;

 private:
  void InitFeaVec(FeaVec& fea_vec, double factor);
  bool ReadItemList();
  void ReadTrainInstanceFile();
  void MultiThreadAddTrainInstance(int thread_id);
  bool AddTrainInstance(const std::string &line,
                        double &rating_score_sum, uint64 &train_instance_sum);
  bool ParseMatrixLine(const std::vector<std::string> tokens,
                       const bool is_item, FeaVec& fea_vec);

};
}
}
