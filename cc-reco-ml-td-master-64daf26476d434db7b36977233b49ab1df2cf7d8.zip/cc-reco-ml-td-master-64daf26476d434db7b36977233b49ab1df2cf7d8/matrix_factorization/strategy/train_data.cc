#include "reco/ml/matrix_factorization/strategy/train_data.h"
#include "base/time/timestamp.h"
#include "base/file/file_util.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/dir_reader_linux.h"
#include "reco/base/hdfs/hdfs_file_util.h"
#include "reco/base/hdfs/hdfs_file_stream.h"
#include "base/thread/thread_pool.h"


using std::string;
using std::vector;
using std::tr1::unordered_map;
using std::tr1::unordered_set;

namespace reco {
namespace mf {

// algorithm parametres
DEFINE_int32(fea_num, 50, "特征数量");
DEFINE_double(random_noise, 0.01, "random noise for initialize");
DEFINE_bool(train_online, false, "true=online,false=batch");
DEFINE_int32(max_show, 2000, "max show to cut hot item");
DEFINE_double(max_ctr, 0.1, "max ctr to cut hot item");
DEFINE_double(min_simscore, 0.6, "min sim score for expand");
// 正例占0.1,设逆sigmoid正例为a,故其均值为-0.8a,sigmoid(-0.8a)=0.1 => a=2.8
DEFINE_double(expanded_rating, 0.5, "base expanded rating");
DEFINE_bool(expand_item, true, "whether expand item");

// engineering parametres
DEFINE_int32(train_thread_num, 32, "number of trainning thread");
DEFINE_int32(load_thread_num, 32, "number of load thread(much is not better!!)");
DEFINE_string(item_info_dfs_path, "", "");
DEFINE_string(item_list_dfs_path_list, "", "item list 的 hdfs 路径列表");
DEFINE_string(train_data_dfs_path_list, "", "train data hdfs路径列表 \",\"分隔 e.g. path0,path1,path2");
DEFINE_string(last_item_matrix, "", "last item matrix");
DEFINE_int32(part_in_group, 10, "num of parts each group is divided into");
// for debug
DEFINE_bool(download_train_data, true, "");

const uint32 kInstanceInfoLen = 4;


MFTrainData::MFTrainData(const GlobalData& global_data) {
  global_data_ = global_data;
  LOG(INFO)<<"In MFTrainData, machine_id:" << global_data_.machine_id <<
           "machine_num:"<< global_data_.machine_num;
  random_ = new base::PseudoRandom(base::GetTimestamp());
  read_done_ = false;
  item_instance_lock_ = NULL;
  item_vectors_.reserve(1000000);
  user_vectors_.reserve(100000000/global_data_.machine_num);
}

MFTrainData::~MFTrainData() {
  delete random_;
  delete [] item_instance_lock_;
}

void MFTrainData::InitFeaVec(FeaVec& fea_vec, const double factor) {
  for (int i = 0; i < FLAGS_fea_num; ++i) {
    fea_vec[i+1] = random_->GetDouble() * FLAGS_random_noise * factor;
  }
}

bool MFTrainData::ParseMatrixLine(const std::vector<std::string> tokens, const bool is_item,
     FeaVec& fea_vec) {
  double bias = 0;
  if (is_item) {
    if (!base::StringToDouble(tokens[4], &bias)) {
      LOG(ERROR) << "Error item bias in matrix:["<<tokens[4]<<"]";
      return false;
    }
  } else {
    if (!base::StringToDouble(tokens[3], &bias)) {
      LOG(ERROR) << "Error user bias in matrix:["<<tokens[3]<<"]";
      return false;
    }
  }
  fea_vec.push_back(bias);
  double factor = 0;
  for (uint32 i = 5; i < tokens.size(); ++i) {
    base::StringToDouble(tokens[i], &factor);
    fea_vec.push_back(factor);
  }
  return true;
}


bool MFTrainData::ReadItemList() {
  hdfs::HDFSFileStream hf_stream(hdfs::FLAGS_hadoop_namenode_ip.c_str(),
                                 hdfs::FLAGS_hadoop_namenode_port);
  uint64 item_id = 0;
  int show = 0, click = 0, trained_cnt = 0;
  if (FLAGS_expand_item) {
    LOG(INFO) << "need to expand item";
  }

  for (int i = 0; ; ++i) { // each part-xxxxx
    std::string path = FLAGS_item_list_dfs_path_list + StringPrintf("/part-%05d", i);
    if (!hf_stream.Open(path.c_str(), O_RDONLY)) {
      LOG(ERROR) << "read hdfs item list fail(maybe end) [" << path << "]";
      break;
    }    
    // format: itemid, show, click, trained_cnt, subcate (FNR of input files as idx), [expand item]
    std::string line = "";
    while (hf_stream.ReadLine(&line)) {
      std::vector<std::string> tokens;
      base::SplitString(line, "\t", &tokens);
      if (tokens.size() < 5) {
        LOG(ERROR) << "Error item list line format:" << line;
        continue;
      }

      ItemTrainInfo item_train_info;
      if (!base::StringToUint64(tokens[0], &item_train_info.item_id) ||
          !base::StringToInt(tokens[1], &show) ||
          !base::StringToInt(tokens[2], &click) ||
          !base::StringToInt(tokens[3], &trained_cnt)) {
        LOG(ERROR) << "Error item list line:" << line;
        continue;
      }

      if (show > FLAGS_max_show && click/(show+0.01) > FLAGS_max_ctr) { // cut hot item
        continue;
      }

      if (item_train_info.item_id % global_data_.machine_num == global_data_.machine_id) {
        InitFeaVec(item_train_info.fea_vec, -1);
      }

      item_train_info.subcate = tokens[4];
      itemid_idx_[item_train_info.item_id] = item_vectors_.size();
      item_vectors_.push_back(item_train_info);
      // add expand item
      if (FLAGS_expand_item) {
        for (uint i = 5; i < tokens.size() - 1; i += 2) {
          ExpandedItem exp_item;
          if (!base::StringToUint64(tokens[i], &exp_item.id) ||
              !base::StringToDouble(tokens[i+1], &exp_item.score) ||
              exp_item.score < FLAGS_min_simscore) {
            continue;
          }

          expanded_items_[item_train_info.item_id].push_back(exp_item);
        }
      }
    }

    if (!hf_stream.Eof()) {
      LOG(ERROR) << "eof hdfs item list fail [" << path << "]";
    }

    if (!hf_stream.Close()) {
      LOG(ERROR) << "close hdfs item list fail [" << path << "]";
    }

    LOG(INFO) << "read hdfs item list ok [" << path << "]";
  }

  if (FLAGS_train_online) {
    // load last item matrix
    std::ifstream fin(FLAGS_last_item_matrix);
    std::tr1::unordered_map<uint64, uint32>::iterator p_ididx;
    std::string line = "";
    while (std::getline(fin, line)) {
      std::vector<std::string> tokens;
      base::SplitString(line, "\t", &tokens);
      if ((int)tokens.size() != FLAGS_fea_num + 5) {
        LOG(ERROR) << "Error matrix line";
        continue;
      }
      if (!base::StringToUint64(tokens[0], &item_id)) {
        LOG(ERROR) << "Error id in matrix:["<< tokens[0] <<"]";
        continue;
      }
      if ((p_ididx = itemid_idx_.find(item_id)) != itemid_idx_.end()) {
        FeaVec fea_vec;
        if (!ParseMatrixLine(tokens, true, fea_vec)) {
          LOG(ERROR) << "Error factor in matrix:"<< tokens[0] <<"]";
          continue;
        }
        item_vectors_[p_ididx->second].fea_vec = fea_vec;
      } else {
        unchanged_item_matrix_.push_back(line);
      }
    }
    fin.close();
  }

  item_instance_lock_ = new thread::BlockingVar<bool>[item_vectors_.size()];
  for (uint32 i = 0; i < item_vectors_.size(); ++i) {
    CHECK(item_instance_lock_[i].TryPut(true));
  }
  LOG(INFO) << "read item list all ok [" << FLAGS_item_list_dfs_path_list << 
            "] itemnum=" << item_vectors_.size();
  return true;
}

void MFTrainData::ReadTrainInstanceFile() {
  hdfs::HDFSFileStream hf_stream(hdfs::FLAGS_hadoop_namenode_ip.c_str(),
                                 hdfs::FLAGS_hadoop_namenode_port);
  uint64 line_count = 0;
  for (int i = 0; i < FLAGS_part_in_group; ++i) { // each part-xxxxx for this machine
    std::string path = FLAGS_train_data_dfs_path_list + StringPrintf("/part-%05d",
                       i*global_data_.machine_num + global_data_.machine_id);
    if (!hf_stream.Open(path.c_str(), O_RDONLY)) {
      LOG(ERROR) << "read hdfs train data fail [" << path << "]";
      return;
    }
    static const int kMaxTrainInstanceQueueSize = 2000000;
    std::string line;
    while (hf_stream.ReadLine(&line)) {
      while (train_instance_queue_.Size() > kMaxTrainInstanceQueueSize) {
        base::SleepForMilliseconds(400);
        LOG(INFO) << "train_instance_queue full [" << train_instance_queue_.Size() << "]";
      }
      CHECK(train_instance_queue_.Put(line));
      if (++line_count % 100000 == 0) {
        LOG(INFO) << line_count << " instances loaded";
      }
    }

    if (!hf_stream.Eof()) {
      LOG(ERROR) << "eof hdfs train data fail [" << path << "]";
    }
    if (!hf_stream.Close()) {
      LOG(ERROR) << "close hdfs train data fail [" << path << "]";
    }

    LOG(INFO) << "train instance file loaded [" << path << "]";
  }

  LOG(INFO) << "train instance all file loaded [" << FLAGS_train_data_dfs_path_list << "]";
  read_done_ = true;
}

// format: part_id[SPACE]user_id, [itemid, label, trained_cnt, subcate]
bool MFTrainData::AddTrainInstance(const std::string &line,
                                   double& rating_score_sum,
                                   uint64& train_instance_sum) {
  std::vector<std::string> tokens;
  base::SplitString(line, "\t ", &tokens); // ' ' is REQUIRED by delimiters!!!!!
  if (tokens.size() <= kInstanceInfoLen || tokens.size() % kInstanceInfoLen != 2) {
//    LOG(WARNING) << "read line error: " << line;
    return false;
  }
  // add user_vectors_
  UserTrainInfo user_train_info;
  if (!base::StringToUint64(tokens[1], &user_train_info.user_id) ||
      user_train_info.user_id == 0) {
    LOG(WARNING) << "user_id error [" << tokens[1] << "]";
    return false;
  }
  InitFeaVec(user_train_info.fea_vec, 1);
  user_vectors_lock_.Take();
  uint32 user_idx = user_vectors_.size();
  user_vectors_.push_back(user_train_info);
  CHECK(user_vectors_lock_.TryPut(true));
  uint64 item_id = 0;
  double rating_score = 0;
  int ins_cnt = 0;
  unordered_map<uint64, uint32>::iterator p_ididx;
  int tokens_cnt = (int)tokens.size();
  unordered_set<uint64> already_instances;
  vector< std::pair<uint64, double> > to_expand;
  // add original intances
  for (int i = 2; i < tokens_cnt; i += kInstanceInfoLen) { // each item under user
    if (!base::StringToUint64(tokens[i], &item_id) ||
        !base::StringToDouble(tokens[i+1], &rating_score)) {
      LOG(WARNING) << "convert item_info to number fail ["
                   << tokens[i] << ", " << tokens[i+1] << "]";
      continue;
    }
    if ((p_ididx = itemid_idx_.find(item_id)) == itemid_idx_.end()) {
      continue;
    }

    if (rating_score > 1) {
      rating_score = 1;
    }
    else if (rating_score < 0) {
      rating_score = 0;
    }

    item_instance_lock_[p_ididx->second].Take();
    item_vectors_[p_ididx->second].train_instances.push_back(
                          std::make_pair(user_idx, rating_score));
    CHECK(item_instance_lock_[p_ididx->second].TryPut(true));
    rating_score_sum += rating_score;
    train_instance_sum += 1;
    ++ins_cnt;
    // for later expand
    already_instances.insert(item_id);
    if ( // rating_score > 0.99 &&
        expanded_items_.find(item_id) != expanded_items_.end()) {
      to_expand.push_back(std::make_pair(item_id, rating_score));
    }
  }
  // add topic-sim instances
  vector< std::pair<uint64, double> >::iterator te_it;
  for (te_it = to_expand.begin(); te_it != to_expand.end(); ++te_it) { // each to-expand item
    auto &expanded_items = expanded_items_[te_it->first];
    vector<ExpandedItem>::iterator ei_it;
    for (ei_it = expanded_items.begin(); ei_it != expanded_items.end(); ++ei_it) { // each expanded item
      if (already_instances.find(ei_it->id) != already_instances.end() ||
         (p_ididx = itemid_idx_.find(ei_it->id)) == itemid_idx_.end()) {
        continue;
      }

      double expd_rating = 0;
      if (te_it->second > 0.5) { // positive instance
        expd_rating = FLAGS_expanded_rating * ei_it->score;
      } else {
        expd_rating = 1 - FLAGS_expanded_rating * ei_it->score;
      }
      item_instance_lock_[p_ididx->second].Take();
      item_vectors_[p_ididx->second].train_instances.push_back(
                    std::make_pair(user_idx, expd_rating));
      CHECK(item_instance_lock_[p_ididx->second].TryPut(true));
      rating_score_sum += expd_rating;
      train_instance_sum += 1;
      ++ins_cnt;
      already_instances.insert(ei_it->id);
    }
  }
  // final process
  user_vectors_lock_.Take();
  auto &user_vector =  user_vectors_[user_idx];
  user_vector.ins_cnt = ins_cnt;
  if (ins_cnt == 0) { // the user has not avaliable instance
    user_vector.avaliable = false;
  }
  CHECK(user_vectors_lock_.TryPut(true));

  return true;
}

void MFTrainData::MultiThreadAddTrainInstance(int thread_id) {
  double rating_score_sum = 0;
  uint64 train_instance_sum = 0;
  LOG(INFO) << "read train instance thread start [" << thread_id << "]";
  std::string element;
  while (!read_done_ || !train_instance_queue_.Empty()) {
    if (train_instance_queue_.TryTake(&element) == 0) {
      VLOG(1) << "get train instance fail, go to sleep";
      continue;
    }
    AddTrainInstance(element, rating_score_sum, train_instance_sum);
  }
  LOG(INFO) << "read train instance thread done [" << thread_id << "]";
  StatResult res = results_.Take();
  res.Update(rating_score_sum, train_instance_sum);
  CHECK(results_.TryPut(res));
}

bool MFTrainData::ReadTrainData() {
  if (!ReadItemList()) {
    return false;
  }
  StatResult res;
  CHECK(results_.TryPut(res));
  CHECK(user_vectors_lock_.TryPut(true));
  thread::ThreadPool thread_pool(FLAGS_load_thread_num + 1);
  thread_pool.AddTask(NewCallback(this, &MFTrainData::ReadTrainInstanceFile));
  for (int i = 0; i < FLAGS_load_thread_num; ++i) {
    thread_pool.AddTask(NewCallback(this, &MFTrainData::MultiThreadAddTrainInstance, i));
  }
  thread_pool.JoinAll();
  CHECK(results_.TryTake(&res));
  CHECK(results_.TryPut(res));
  LOG(INFO) << "read train data success [" << FLAGS_train_data_dfs_path_list
            << "][instance_num: " << res.train_instance_sum
            << ", rating_score_sum: " << res.rating_score_sum
            << "]";
  return true;
}

bool MFTrainData::PutFileToHdfs(const std::string &local_path,
                                const std::string &hdfs_path) {
  if (hdfs::HDFSExists(hdfs_path.c_str()) && !hdfs::HDFSRmr(hdfs_path.c_str())) {
    LOG(ERROR) << "hdfs path exist and remove fail [" << hdfs_path << "]";
    return false;
  }
  LOG(INFO) << "put file to hdfs start [" << local_path << " " << hdfs_path << "]";
  if (hdfs::HDFSPut(local_path.c_str(), hdfs_path.c_str()) != 0) {
    LOG(ERROR) << "put file to hdfs fail [" << local_path << ", " << hdfs_path << "]";
    return false;
  }
  LOG(INFO) << "put file to hdfs success [" << local_path << " " << hdfs_path << "]";
  return true;
}

}
}

