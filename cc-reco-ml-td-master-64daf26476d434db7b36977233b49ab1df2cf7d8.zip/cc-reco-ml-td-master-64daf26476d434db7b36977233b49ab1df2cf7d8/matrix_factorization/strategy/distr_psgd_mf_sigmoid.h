#pragma once
#include <string>
#include <unordered_map>
#include <vector>
#include "base/common/base.h"
#include "base/random/pseudo_random.h"
#include "base/thread/rw_mutex.h"
#include "base/thread/blocking_var.h"
#include "base/thread/blocking_queue.h"
#include "reco/ml/matrix_factorization/proto/distr_psgd_mf.pb.h"
#include "reco/ml/matrix_factorization/strategy/train_data.h"

namespace reco {
namespace mf {

class MFTrainData;
//struct GlobalData;

struct ItemTrainParameter {
  ItemTrainParameter(uint32 idx, double step) {
    index = idx;
    step_len = step;
  }
  uint32 index;
  double step_len;
};

class DistrParallelSGDMF {
 public:
  DistrParallelSGDMF();
  ~DistrParallelSGDMF();

  // load training data
  int LoadTrainData();
  // 多线程并发训练 
  bool DoTrain();

  // 更新 item 矩阵
  bool UpdateItemMatrix(const ItemFeature &item_feature, const bool &need_train);

 private:
  // 计算当前迭代的优化的步长 
  double GetStepLength(int iter_time);
  double DotProduct(const std::vector<double> &user_fea,
                    const std::vector<double> &item_fea);

  // 发送当前节点已优化结束的 item 向量
  void SendItemMatrix(int thread_id);
  // recv itemmatrix from other node
  void RecvItemMatrix(int thread_id);

  // 收集需要优化 item
  void CollectItems();

  // 优化 Item 特征向量 
  void OptimizeItemVector(const int thread_id);
  void OptimizeItem(ItemTrainInfo *item_train_info,
                    const ItemTrainParameter item_train_param);
  void UpdateItemQueue(const uint32 index, const ItemTrainInfo& item_train_info);

  bool WriteItemMatrix();
  bool WriteUserMatrix();
  bool UploadToHdfs();
  bool PushBaseInfoToHdfs();

  int Shuffle(std::vector<uint32_t>& vec);

//  void GetItemLock(const uint32 &item_idx, bool *p_item_flag);

 private:
  MFTrainData *train_data_;
  GlobalData global_data_;
  base::PseudoRandom *random_;
  thread::BlockingQueue<ItemFeature> *update_item_queue_;
  thread::BlockingQueue<ItemTrainParameter> *train_item_queue_;
  thread::BlockingVar<bool> *block_users_;
//  thread::BlockingVar<bool> *block_items_;
  thread::RWMutex *block_items_;
  thread::BlockingVar<bool> mpi_lock_;
  thread::BlockingVar<uint32_t> iter_cnt_;
  bool update_done_;

  double rating_avg_score_;
  double item_avg_score_;
  double user_avg_score_;
  uint32_t item_num_; // item num of this machine
  uint32_t user_num_; // avaliable user num of this machine
  uint32_t iter_sum_;
};


}
}
