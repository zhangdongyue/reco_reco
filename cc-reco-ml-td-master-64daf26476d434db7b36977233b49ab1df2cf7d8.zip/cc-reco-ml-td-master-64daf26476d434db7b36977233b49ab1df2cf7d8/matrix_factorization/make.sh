source ~/.bashrc

cd ~/wly/
make -j 16 opt -f Makefile.mpi

if [[ $? -ne 0 ]];then
  echo "make failed"
  exit -1
fi
echo "make ok"

#exit 1

#ossupload .build/opt/targets/reco/matrix_factorization_mpi/tools/calc_auc

cd ~/wly/reco/matrix_factorization_mpi/
cp ~/wly/.build/opt/targets/reco/matrix_factorization_mpi/frame/distr_psgd_mf_train ./
tar -czvf distr_psgd_mf_train.tar.gz distr_psgd_mf_train
ossupload distr_psgd_mf_train.tar.gz

