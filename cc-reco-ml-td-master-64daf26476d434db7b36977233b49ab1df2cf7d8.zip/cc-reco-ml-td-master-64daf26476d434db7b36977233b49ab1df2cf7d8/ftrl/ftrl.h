#pragma once
#include <math.h>
#include <unordered_map>
#include <string>
#include <vector>
#include <utility>
#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/thread/sync.h"
#include "reco/ml/ftrl/define.h"

namespace reco {
namespace ml {
struct FtrlData {
  explicit FtrlData(size_t d): w(0), z(0), g_square(0), v_dim(d), t(0), v_inited(false) {}
  void InitV();

  double w;
  double z;
  double g_square;
  // fm
  size_t v_dim;
  std::vector<double> v;
  std::vector<double> v_z;
  std::vector<double> v_g_square;
  // expose times
  size_t t;
  bool v_inited;
};

// Logistic regression on FTRL or RDA
// FTRL-Proximal: H.Brendan Mcmahan, etc. Ad Click Prediction: a View from the Trenches, ACM 2013
// RDA: Lin Xiao, Dual Averaging Methods for Regularized Stochastic Learning and Online Optimization, 2010
// FTRL 对象线程安全, 每个接口都用 Mutex 保护. 单线程调用时只会带来很少的额外开销.
// 但是多线程竞争厉害时,性能会大幅下降.
class FTRL {
 public:
  enum Algo {
    Ftrlp = 0,  // FTRL-Proximal
    Rda,    // RDA
  };

  struct Option {
    size_t v_dim;
    double learning_rate_alpha;
    double learning_rate_beta;
    double l1weight;
    double l2weight;
    Algo algo;  // Ftrlp or Rda
    double ftrl_output_thresh;  // always use 1e-6
    double min_fea_t;  // always use 0
  };

  explicit FTRL(const Option& option);
  ~FTRL() {}

  FTRL(const FTRL& r);
  FTRL& operator=(const FTRL& r);

  double ftrl_weight(double z, double g_sqr) {
    const double sgn_z = (z >= 0) ? 1 : -1;
    if (z <= l1weight_ && z >= -l1weight_) {
      return 0.0;
    } else {
      return -1.0/((beta_+sqrt(g_sqr))/alpha_+l2weight_)*(z-sgn_z*l1weight_);
    }
  }

  // note: g_sq == g * g
  double ftrl_z(double w, double g, double g_sq, double n) {
    return g - w*(1/alpha_*(sqrt(n+g_sq)-sqrt(n)));
  }

  // |InitWithPriors| 与 |LoadFromDisk| 对 model 的影响会相互覆盖.
  void InitWithPriors(const std::unordered_map<uint64, PriorInfo>& prior_infos, bool reinit_learning_rate);

  void LoadFtrlFromDisk(const std::string& file);
  void SaveFtrlToDisk(const std::string& file) const;

  double Update(const Sample& ins, std::vector<std::pair<uint64, double> >* fea_w);
  void Clear();
  int64 Size() const;

  std::unordered_map<uint64, FtrlData> model_;

  double alpha_;
  double beta_;
  double l1weight_;
  double l2weight_;
  size_t v_dim_;
  Algo algo_;

  double ftrl_output_thresh_;
  double min_fea_t_;
  mutable thread::Mutex mutex_;
};
}  // namespace ml
}  // namespace reco
