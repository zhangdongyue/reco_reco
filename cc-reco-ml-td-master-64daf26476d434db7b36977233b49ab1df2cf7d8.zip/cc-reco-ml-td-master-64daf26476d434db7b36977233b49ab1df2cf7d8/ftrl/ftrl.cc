#include "reco/ml/ftrl/ftrl.h"

#include <cmath>
#include <utility>
#include <fstream>
#include <string>
#include <vector>

#include "base/common/logging.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "reco/ml/common/math_util.h"

namespace reco {
namespace ml {

void FtrlData::InitV() {
  v.resize(v_dim);
  v_z.resize(v_dim);
  v_g_square.resize(v_dim);
  // Init v with gaussian random
  for (size_t i = 0; i < v_dim; ++i) {
    v[i] = GaussianRandom(0, 0.1);
  }
  v_inited = true;
}

FTRL::FTRL(const Option& option) {
  if (algo_ == Algo::Ftrlp) {
    LOG(INFO) << "algo is FTRL-Proximal";
  } else if (algo_ == Algo::Rda) {
    LOG(INFO) << "algo is RDA";
  } else {
    NOT_REACHED();
  }

  alpha_ = option.learning_rate_alpha;
  beta_ = option.learning_rate_beta;
  l1weight_= option.l1weight;
  l2weight_ = option.l2weight;
  v_dim_ = option.v_dim;
  algo_ = option.algo;
  ftrl_output_thresh_ = option.ftrl_output_thresh;
  min_fea_t_= option.min_fea_t;

  CHECK_GT(beta_, 1e-12);
  CHECK_GE(l1weight_, 0);
  CHECK_GE(l2weight_, 0);
}

FTRL::FTRL(const FTRL& r) {
  thread::AutoLock lock1(&r.mutex_);
  thread::AutoLock lock2(&mutex_);
  model_ = r.model_;
  alpha_ = r.alpha_;
  beta_ = r.beta_;
  l1weight_ = r.l1weight_;
  l2weight_ = r.l2weight_;
  algo_ = r.algo_;
  v_dim_ = r.v_dim_;
}

FTRL& FTRL::operator=(const FTRL& r) {
  thread::AutoLock lock1(&r.mutex_);
  thread::AutoLock lock2(&mutex_);
  model_ = r.model_;
  alpha_ = r.alpha_;
  beta_ = r.beta_;
  l1weight_ = r.l1weight_;
  l2weight_ = r.l2weight_;
  algo_ = r.algo_;
  v_dim_ = r.v_dim_;
  return *this;
}

void FTRL::InitWithPriors(const std::unordered_map<uint64, PriorInfo>& prior_infos,
                          bool reinit_learning_rate) {
  thread::AutoLock lock(&mutex_);

  for (auto it = prior_infos.begin(); it != prior_infos.end(); ++it) {
    uint64 fea = it->first;
    const PriorInfo& info = it->second;
    float pos = info.pos_event+1e-6;
    float neg = info.neg_event+1e-6;
    CHECK(pos > 0 && neg > 0) << pos << ", " << neg;

    auto it_o = model_.find(fea);
    if (it_o == model_.end()) {
      FtrlData data(v_dim_);
      bool flag = false;
      if (reinit_learning_rate) {
        data.g_square = pos*neg/(pos+neg);
        flag = true;
      }
      if (flag) {
        model_.insert(std::make_pair(fea, data));
      }
    } else {
      FtrlData& data = it_o->second;
      if (reinit_learning_rate) {
        data.g_square = pos*neg/(pos+neg);
      }
    }
  }
}

void StringToFtrlDataOrDie(const std::string& str, uint64* fea_sign, FtrlData* d) {
  std::vector<std::string> flds;
  base::SplitString(str, "\t", &flds);
  CHECK_GE(flds.size(), 5u) << "Format error[" << str << "].";

  *fea_sign = base::ParseUint64OrDie(flds[0]);
  d->t = base::ParseUintOrDie(flds[1]);
  d->w = base::ParseDoubleOrDie(flds[2]);
  d->z = base::ParseDoubleOrDie(flds[3]);
  d->g_square = base::ParseDoubleOrDie(flds[4]);

  if (flds.size() > 5u) {
    CHECK_EQ(flds.size(), 8u) << "Format error[" << str << "].";
    std::vector<std::string> sub_flds;
    d->InitV();

    sub_flds.clear();
    base::SplitStringWithOptions(flds[5], " ", true, true, &sub_flds);
    CHECK_EQ(sub_flds.size(), d->v_dim);
    for (size_t i = 0; i < d->v_dim; ++i) {
      d->v[i] = base::ParseDoubleOrDie(sub_flds[i]);
    }
    sub_flds.clear();
    base::SplitStringWithOptions(flds[6], " ", true, true, &sub_flds);
    CHECK_EQ(sub_flds.size(), d->v_dim);
    for (size_t i = 0; i < d->v_dim; ++i) {
      d->v_z[i] = base::ParseDoubleOrDie(sub_flds[i]);
    }
    sub_flds.clear();
    base::SplitStringWithOptions(flds[7], " ", true, true, &sub_flds);
    CHECK_EQ(sub_flds.size(), d->v_dim);
    for (size_t i = 0; i < d->v_dim; ++i) {
      d->v_g_square[i] = base::ParseDoubleOrDie(sub_flds[i]);
    }
  }
}

std::string FtrlDataToString(const FtrlData& d) {
  std::string ret = base::StringPrintf("%lu\t%f\t%f\t%f", d.t, d.w, d.z, d.g_square);
  if (d.v_inited) {
    ret += "\t";
    for (size_t i = 0; i < d.v_dim; ++i) {
      if (i != 0) ret += " ";
      ret += base::StringPrintf("%f", d.v[i]);
    }

    ret += "\t";
    for (size_t i = 0; i < d.v_dim; ++i) {
      if (i != 0) ret += " ";
      ret += base::StringPrintf("%f", d.v_z[i]);
    }

    ret += "\t";
    for (size_t i = 0; i < d.v_dim; ++i) {
      if (i != 0) ret += " ";
      ret += base::StringPrintf("%f", d.v_g_square[i]);
    }
  }
  return ret;
}

double FTRL::Update(const Sample& ins, std::vector<std::pair<uint64, double> >* fea_w) {
  thread::AutoLock lock(&mutex_);
  if (fea_w) {
    fea_w->resize(ins.elements.size());
  }

  CHECK_NEAR(ins.weight, 1.0, 1e-6);
  double y = 0;
  if (fabs(ins.pos_weight-1.0) < 1e-6) {
    y = 1;
  } else if (fabs(ins.pos_weight) < 1e-6) {
    y = 0;
  } else {
    NOT_REACHED();
  }

  double sum_w = ins.prior;
  // TODO(duyanlong): reuse these vector
  std::vector<double> v_sum(v_dim_, 0.0);
  std::vector<double> v_sum_sqr(v_dim_, 0.0);
  for (int64 i = 0; i < (int64)ins.elements.size(); ++i) {
    uint64 fea = ins.elements[i];
    double fea_weight = 0;
    auto it = model_.find(fea);
    if (it == model_.end()) {
      FtrlData data(v_dim_);
      data.t = 0;
      it = model_.insert(std::make_pair(fea, data)).first;
    }
    FtrlData& data = it->second;
    ++data.t;
    // update w
    it->second.w = ftrl_weight(it->second.z, it->second.g_square);
    sum_w += it->second.w;
    fea_weight = it->second.w;
    // update v
    if (data.t >= min_fea_t_) {
      if (!data.v_inited) {
        data.InitV();
      } else {
        for (size_t v_idx = 0; v_idx < v_dim_; ++v_idx) {
          it->second.v[v_idx] = ftrl_weight(it->second.v_z[v_idx],
                                            it->second.v_g_square[v_idx]);
        }
      }
      const std::vector<double>& v = it->second.v;
      for (size_t v_idx = 0; v_idx < v_dim_; ++v_idx) {
        v_sum[v_idx] += v[v_idx];
        v_sum_sqr[v_idx] += v[v_idx] * v[v_idx];
      }
    }

    if (fea_w) {
      (*fea_w)[i].first = fea;
      (*fea_w)[i].second = fea_weight;
    }
  }

  for (size_t v_idx = 0; v_idx < v_dim_; ++v_idx) {
    sum_w += 0.5 * (v_sum[v_idx] * v_sum[v_idx] - v_sum_sqr[v_idx]);
  }

  double pctr = logit(sum_w);
  double g = pctr - y;
  double g_sq = g * g;
  for (int64 i = 0; i < (int64)ins.elements.size(); ++i) {
    uint64 fea = ins.elements[i];
    auto it = model_.find(fea);
    CHECK(it != model_.end());
    const double w = it->second.w;
    double& z = it->second.z;
    double& n = it->second.g_square;
    // update z, g_square
    if (algo_ == Algo::Ftrlp) {
      z += ftrl_z(w, g, g_sq, n);
    } else if (algo_ == Algo::Rda) {
      z += g;
    } else {
      NOT_REACHED();
    }
    n += g_sq;
    // update v_z, v_g_square
    if (it->second.v_inited) {
      std::vector<double>& v = it->second.v;
      std::vector<double>& v_z = it->second.v_z;
      std::vector<double>& v_g_square = it->second.v_g_square;
      for (size_t v_idx = 0; v_idx < v_dim_; ++v_idx) {
        double v_g = g * (v_sum[v_idx] - v[v_idx]);
        double v_g_sqr = v_g * v_g;
        if (algo_ == Algo::Ftrlp) {
          v_z[v_idx] += ftrl_z(v[v_idx], v_g, v_g_sqr, v_g_square[v_idx]);
        } else if (algo_ == Algo::Rda) {
          v_z[v_idx] += v_g;
        } else {
          NOT_REACHED();
        }
        v_g_square[v_idx] += v_g_sqr;
      }
    }
    // LOG(INFO) << "update fea[" << fea << "] 's info:" << DebugInfo(it->second);
  }

  return pctr;
}

void FTRL::Clear(void) {
  thread::AutoLock lock(&mutex_);
  model_.clear();
  std::unordered_map<uint64, FtrlData> tmp(model_);
  tmp.swap(model_);
}

void FTRL::LoadFtrlFromDisk(const std::string& file) {
  thread::AutoLock lock(&mutex_);

  std::ifstream is(file.c_str());
  CHECK(is.good()) << "Cannot open file " << file;
  std::string line;
  std::vector<std::string> flds;
  std::vector<std::string> sub_flds;
  while (std::getline(is, line)) {
    if (line.empty()) continue;
    uint64 fea;
    FtrlData data(v_dim_);
    StringToFtrlDataOrDie(line, &fea, &data);
    model_.insert(std::make_pair(fea, data));
    LOG_EVERY_N(INFO, 1000000) << "Read " << google::COUNTER << " line from " << file;
  }
  LOG(INFO) << "FTRL model loaded from file " << file;
}

void FTRL::SaveFtrlToDisk(const std::string& file) const {
  thread::AutoLock lock(&mutex_);
  std::ofstream os(file.c_str());
  CHECK(os.good()) << "Cannot open file " << file;
  LOG(INFO) << "FTRL model start writing to file " << file;
  for (auto it = model_.begin(); it != model_.end(); ++it) {
    LOG_EVERY_N(INFO, 1000000) << "Writing " << google::COUNTER << " item of " << model_.size();
    const FtrlData& data = it->second;
    if (data.w > ftrl_output_thresh_ || data.w < -ftrl_output_thresh_ ||
        !all_zero(data.v, ftrl_output_thresh_)) {
      os << it->first << "\t" << FtrlDataToString(data) << std::endl;
    }
  }
  LOG(INFO) << "FTRL model saved to file " << file;
}

int64 FTRL::Size(void) const {
  thread::AutoLock lock(&mutex_);
  return model_.size();
}
}  // namespace ml
}  // namespace reco
