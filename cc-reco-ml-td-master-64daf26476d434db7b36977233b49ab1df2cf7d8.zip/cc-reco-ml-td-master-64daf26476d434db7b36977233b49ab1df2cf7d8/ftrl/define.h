#pragma once
#include <vector>
#include <string>
#include "base/common/basic_types.h"
namespace reco {
namespace ml {
struct Sample {
  float weight;
  float pos_weight;
  float prior;
  std::vector<uint64> elements;
  std::string query;  // option, if has
  Sample(): weight(0), pos_weight(0), prior(0) {
  }
};

struct PriorInfo {
  float w;
  float pos_event;
  float neg_event;
  PriorInfo(): w(0), pos_event(0), neg_event(0) {}
};
}
}
