#include <vector>
#include <cmath>
#include <iostream>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "reco/ml/auc/auc.h"

int main(int argc, char** argv) {
  std::string line;
  std::vector<std::string> tokens;
  std::vector<reco::ml::PredCTR> ctrs;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t",  &tokens);
    if (tokens.size() < 2) continue;
    
    reco::ml::PredCTR pred;
    pred.prediction = base::ParseDoubleOrDie(tokens[0]);
    double label = base::ParseDoubleOrDie(tokens[1]);
    pred.pos_weight = 0;
    pred.neg_weight = 0;
    if (label > 0) {
      pred.pos_weight = 1;
    } else {
      pred.neg_weight = 1;
    }
    ctrs.push_back(pred);
  }
  std::cout << "auc: " << reco::ml::CalcRocAuc(ctrs);

  return 0;
}
