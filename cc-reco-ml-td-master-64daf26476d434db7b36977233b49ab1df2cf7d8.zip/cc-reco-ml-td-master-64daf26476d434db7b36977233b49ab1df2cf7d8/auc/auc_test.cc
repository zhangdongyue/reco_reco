#include <vector>

#include "reco/ml/auc/auc.h"
#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

TEST(AucTest, HandCalculation) {
  std::vector<reco::ml::PredCTR> pred_ctrs;
  pred_ctrs.push_back(reco::ml::PredCTR("q1", 0.1, 20, 10));
  pred_ctrs.push_back(reco::ml::PredCTR("q1", 0.2, 10, 20));
  pred_ctrs.push_back(reco::ml::PredCTR("q2", 0.3, 30, 30));
  pred_ctrs.push_back(reco::ml::PredCTR("q2", 0.05, 10, 10));

  // 验证 auc 正确
  const double correct_auc = 0.4693877551;
  double auc = reco::ml::CalcRocAuc(pred_ctrs);
  ASSERT_NEAR(auc, correct_auc, 1e-6);

  std::vector<reco::ml::PredCTR> q1_ctrs(pred_ctrs.begin(), pred_ctrs.begin()+2);
  const double correct_q1_auc = 0.33333333;
  double q1_auc = reco::ml::CalcRocAuc(q1_ctrs);
  ASSERT_NEAR(q1_auc, correct_q1_auc, 1e-6);

  std::vector<reco::ml::PredCTR> q2_ctrs(pred_ctrs.begin()+2, pred_ctrs.end());
  const double correct_q2_auc = 0.5;
  double q2_auc = reco::ml::CalcRocAuc(q2_ctrs);
  ASSERT_NEAR(q2_auc, correct_q2_auc, 1e-6);

  // 验证 qauc 和 wqauc 正确
  const double correct_qauc = (correct_q1_auc + correct_q2_auc)/2;
  const double correct_wqauc = (correct_q1_auc*60+correct_q2_auc*80)/140;
  double qauc, wqauc;
  reco::ml::CalcQueryAuc(pred_ctrs, &qauc, &wqauc);
  ASSERT_NEAR(qauc, correct_qauc, 1e-6);
  ASSERT_NEAR(wqauc, correct_wqauc, 1e-6);
}

// 只有 1 个预估值, 全是 0.5
TEST(AucTest, HandCalculation2) {
  std::vector<reco::ml::PredCTR> pred_ctrs;
  pred_ctrs.push_back(reco::ml::PredCTR("q1", 0.1, 20, 10));

  const double correct_auc = 0.5;
  const double correct_qauc = 0.5;
  const double correct_wqauc = 0.5;
  double auc = reco::ml::CalcRocAuc(pred_ctrs);
  ASSERT_NEAR(auc, correct_auc, 1e-6);
  double qauc, wqauc;
  reco::ml::CalcQueryAuc(pred_ctrs, &qauc, &wqauc);
  ASSERT_NEAR(qauc, correct_qauc, 1e-6);
  ASSERT_NEAR(wqauc, correct_wqauc, 1e-6);
}

// pos/neg weight 有全零, 全是 0.5
TEST(AucTest, HandCalculation3) {
  std::vector<reco::ml::PredCTR> pred_ctrs;
  pred_ctrs.push_back(reco::ml::PredCTR("q1", 0.1, 20, 0));
  pred_ctrs.push_back(reco::ml::PredCTR("q1", 0.2, 30, 0));
  pred_ctrs.push_back(reco::ml::PredCTR("q2", 0.3, 30, 0));
  pred_ctrs.push_back(reco::ml::PredCTR("q2", 0.4, 40, 0));

  const double correct_auc = 0.5;
  const double correct_qauc = 0.5;
  const double correct_wqauc = 0.5;
  double auc = reco::ml::CalcRocAuc(pred_ctrs);
  ASSERT_NEAR(auc, correct_auc, 1e-6);
  double qauc, wqauc;
  reco::ml::CalcQueryAuc(pred_ctrs, &qauc, &wqauc);
  ASSERT_NEAR(qauc, correct_qauc, 1e-6);
  ASSERT_NEAR(wqauc, correct_wqauc, 1e-6);
}

TEST(AucTest, InterQueryAuc) {
  std::vector<reco::ml::PredCTR> pred_ctrs;
  pred_ctrs.push_back(reco::ml::PredCTR("q1", 0.1, 20, 10));
  pred_ctrs.push_back(reco::ml::PredCTR("q1", 0.2, 10, 20));
  pred_ctrs.push_back(reco::ml::PredCTR("q2", 0.3, 30, 30));
  pred_ctrs.push_back(reco::ml::PredCTR("q2", 0.05, 10, 10));

  std::vector<reco::ml::PredCTR> correct;
  correct.push_back(reco::ml::PredCTR("q1", 9, 30, 30));
  correct.push_back(reco::ml::PredCTR("q2", 19, 40, 40));
  double correct_auc = reco::ml::CalcRocAuc(correct);

  ASSERT_NEAR(reco::ml::CalcInterQueryAuc(pred_ctrs), correct_auc, 1e-6);
}

