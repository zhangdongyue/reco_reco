#include "reco/ml/auc/auc.h"

#include <math.h>
#include <algorithm>
#include "base/common/basic_types.h"
#include "base/common/logging.h"

namespace reco {
namespace ml {

static bool pctr_comp(const PredCTR& l, const PredCTR& r) {
  return l.prediction < r.prediction;
}

static bool query_comp(const PredCTR& l, const PredCTR& r) {
  return l.query < r.query;
}

static bool query_pctr_comp(const PredCTR& l, const PredCTR& r) {
  if (query_comp(l, r)) {
    return true;
  } else if (query_comp(r, l)) {
    return false;
  } else {
    return pctr_comp(l, r);
  }

  NOT_REACHED();
  return true;
}

template<typename Iterator>
double CalcRocAuc(Iterator begin, Iterator end, bool reverse_sorted) {
  std::vector<PredCTR> results(begin, end);
  if (!reverse_sorted) {
    std::sort(results.begin(), results.end(), pctr_comp);
    std::reverse(results.begin(), results.end());
  }

  double sum_pos = 0, sum_neg = 0, area = 0;
  for (int64 i = 0; i < (int64)results.size(); ++i) {
    PredCTR r = results[i];
    while (i + 1 < (int64)results.size() && r.prediction <= results[i+1].prediction) {
      r.pos_weight += results[i+1].pos_weight;
      r.neg_weight += results[i+1].neg_weight;
      ++i;
    }
    area += (sum_pos + r.pos_weight/2) * r.neg_weight;
    sum_pos += r.pos_weight;
    sum_neg += r.neg_weight;
  }

  double total_area = sum_pos * sum_neg;

  if (total_area <= 0) {
    return 0.5;
  }
  return area / total_area;
}

double CalcRocAuc(const std::vector<PredCTR>& pctrs) {
  return CalcRocAuc(pctrs.begin(), pctrs.end(), false);
}

void CalcQueryAuc(const std::vector<PredCTR>& pctrs, double* qauc, double* wqauc) {
  std::vector<PredCTR> results(pctrs);
  std::sort(results.begin(), results.end(), query_pctr_comp);
  std::reverse(results.begin(), results.end());
  double query_count = 0, sum_auc = 0;
  double weighted_sum_auc = 0, sum_weight = 0;
  int64 begin = 0;
  while (begin < (int64)results.size()) {
    int64 end = begin + 1;
    double query_weight = results[begin].pos_weight + results[begin].neg_weight;
    while (end < (int64)results.size() && results[begin].query <= results[end].query) {
      query_weight += results[end].pos_weight + results[end].neg_weight;
      ++end;
    }
    double query_auc = CalcRocAuc(results.begin()+begin, results.begin()+end, true);
    sum_auc += query_auc;
    ++query_count;
    weighted_sum_auc += query_auc * query_weight;
    sum_weight += query_weight;

    begin = end;
  }
  if (qauc) {
    *qauc = query_count > 0 ? sum_auc / query_count : 0;
  }
  if (wqauc) {
    *wqauc = sum_weight > 0 ? weighted_sum_auc / sum_weight : 0;
  }
  return;
}

double CalcInterQueryAuc(const std::vector<PredCTR>& pctrs) {
  std::vector<PredCTR> results(pctrs);
  std::sort(results.begin(), results.end(), query_comp);
  int64 pos = 0, begin = 0;
  int64 end = -1;
  while (begin < (int64)results.size()) {
    end = begin + 1;
    double sum_pos = results[begin].pos_weight;
    double sum_neg = results[begin].neg_weight;
    double pred_pos = results[begin].prediction * (sum_pos + sum_neg);
    while (end < (int64)results.size() && results[begin].query == results[end].query) {
      double pos = results[end].pos_weight;
      double neg = results[end].neg_weight;
      pred_pos += results[end].prediction * (pos + neg);
      sum_pos += pos;
      sum_neg += neg;
      ++end;
    }
    if (sum_pos + sum_neg <= 0) {
      begin = end;
      continue;
    }
    results[pos].query = results[begin].query;
    results[pos].prediction = pred_pos / (sum_pos + sum_neg);
    results[pos].pos_weight = sum_pos;
    results[pos].neg_weight = sum_neg;

    begin = end;
    ++pos;
  }
  if (!results.empty()) {
    results.resize(pos + 1);
  }
  return CalcRocAuc(results);
}

double AveragePredictionCtr(const std::vector<PredCTR>& pctrs) {
  double sum_pred = 0, sum = 0;
  for (int64 i = 0; i < (int64)pctrs.size(); ++i) {
    sum_pred += pctrs[i].prediction * (pctrs[i].pos_weight + pctrs[i].neg_weight);
    sum += (pctrs[i].pos_weight + pctrs[i].neg_weight);
  }
  return (sum <= 0) ? 0 : sum_pred / sum;
}

double AverageEmpiricalCtr(const std::vector<PredCTR>& pctrs) {
  double sum_pos = 0, sum_neg = 0;
  for (int64 i = 0; i < (int64)pctrs.size(); ++i) {
    sum_pos += pctrs[i].pos_weight;
    sum_neg += pctrs[i].neg_weight;
  }
  double sum = sum_pos + sum_neg;
  return (sum <= 0) ? 0 : sum_pos / sum;
}

double LogLoss(const std::vector<PredCTR>& pctrs) {
  double logloss = 0;
  double sum_w = 0;
  for (int64 i = 0; i < (int64)pctrs.size(); ++i) {
    const PredCTR& pctr = pctrs[i];
    const double p = pctr.prediction;
    double pos = pctr.pos_weight;
    double neg = pctr.neg_weight;
    if (p > 0 && p < 1) {
      logloss -= (pos*log(p) + neg*log(1-p));
      sum_w += (pos + neg);
    }
  }
  if (sum_w > 0u) {
    logloss /= sum_w;
  }
  return logloss;
}
}  // namespace ml
}  // namespace reco
