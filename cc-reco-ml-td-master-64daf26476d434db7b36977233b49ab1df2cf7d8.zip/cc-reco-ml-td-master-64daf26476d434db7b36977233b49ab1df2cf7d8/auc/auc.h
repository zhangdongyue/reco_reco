#pragma once
#include <vector>
#include <string>

namespace reco {
namespace ml {

struct PredCTR {
  std::string query;
  double prediction;
  float pos_weight;
  float neg_weight;
  PredCTR()
      : query(""),
      prediction(0),
      pos_weight(0),
      neg_weight(0) {
      }
  PredCTR(std::string s, double p, float pos, float neg)
      : query(s),
      prediction(p),
      pos_weight(pos),
      neg_weight(neg) {
      }
};

double CalcRocAuc(const std::vector<PredCTR>& pctrs);
// 计算同一 query 下的队列的 AUC
void CalcQueryAuc(const std::vector<PredCTR>& pctrs, double* qauc, double* wqauc);
// 把一个 query 看作一个整体, 计算 query 间的 AUC
double CalcInterQueryAuc(const std::vector<PredCTR>& pctrs);
double AveragePredictionCtr(const std::vector<PredCTR>& pctrs);
double AverageEmpiricalCtr(const std::vector<PredCTR>& pctrs);

// logloss = -sigma((pos*log(p) + neg*log(1-p)))
double LogLoss(const std::vector<PredCTR>& pctrs);
}  // namespace ml
}  // namespace reco
