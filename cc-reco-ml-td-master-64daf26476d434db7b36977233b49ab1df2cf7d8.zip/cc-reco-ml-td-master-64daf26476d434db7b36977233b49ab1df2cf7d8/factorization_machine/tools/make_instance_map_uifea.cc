// this is for text

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/hdfs/hdfs_file_util.h"
#include "base/encoding/line_escape.h"
#include "base/hash_function/city.h"
#include "reco/bizc/proto/user.pb.h"

using std::string;
using std::vector;
using std::cout;
using std::endl;

//[in1] mergelog
//[in2] prefix-userid, user info pb
//[out1] 0:uid"-"icate 1:show(=1){ }click{ }item_parentid(as sign):1.0
//[out2] 0:uid"-"icate 1:"U" 2:[{ }user feature sign:1.0]
//user topic sign = hash(icate_topic_weightseg)
//user cate sign = hash(icate_'ulike'_weightseg) 
int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  // read hdfs
  string line;
  while (std::getline(std::cin, line)) {
    vector<string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() > 70) { // in1
      if (tokens[70].empty()) {
        continue;
      }
      // icate
      vector<string> cates;
      base::SplitString(tokens[17], ",", &cates);
      // click
      if (tokens[10] != "0") {
        tokens[10] = "1";
      }
      // out1
      cout << tokens[9] << "-" << cates[0] << "\t1 " << tokens[10] << " "
           << tokens[70] << ":1.0" << endl;

    } else { // in2
      vector<string> subtokens;
      base::SplitString(tokens[0], "-", &subtokens);
      // get "uc-iflow-$uid"
      if (subtokens.size() == 3 && subtokens[0] + subtokens[1] == "uciflow") {
        string userinfo_str;
        reco::UserInfo user_info;
        if (!base::LineUnescape(tokens[1], &userinfo_str) ||
            !user_info.ParseFromString(userinfo_str) ||
            !user_info.has_profile() ||
            !user_info.profile().has_plsa_topic_feavec() ||
            !user_info.profile().has_category_feavec() ||
            !user_info.profile().has_tag_feavec()) {
          continue;
        }
        // topic
        auto &topic_vec = user_info.profile().plsa_topic_feavec();
        std::unordered_map< string, vector<reco::Feature> > cate_topics;
        for (int i = 0; i < topic_vec.feature_size(); ++i) { // each topic
          auto &topic = topic_vec.feature(i);
          if (!topic.has_category()) {
            continue;
          }

          cate_topics[topic.category()].push_back(topic);
        }
        // category
        auto &cate_vec = user_info.profile().category_feavec();
        std::unordered_map<string, float> cate_weight;
        float cate_norm = 0.001;
        for (int i = 0; i < cate_vec.feature_size(); ++i) { // each cate
          auto &cate = cate_vec.feature(i);
          if (cate.literal().level() == 0) {
            cate_weight[cate.literal().category()] = cate.weight();
            cate_norm += cate.weight();
          }
        }
        // tag
        auto &tag_vec = user_info.profile().tag_feavec();
        std::unordered_map< string, vector<reco::Feature> > cate_tags;
        for (int i = 0; i < tag_vec.feature_size(); ++i) { // each tag
          auto &tag = tag_vec.feature(i);
          if (!tag.has_category()) {
            continue;
          }

          cate_tags[tag.category()].push_back(tag);
        }
        // out2
        // topic is more important than tag, so scan topic's icate and check it in tags
        std::unordered_map< string, vector<reco::Feature> >::iterator ct_it;
        std::unordered_map< string, vector<reco::Feature> >::iterator ctag_it;
        for (ct_it = cate_topics.begin(); ct_it != cate_topics.end(); ++ct_it) { // each icate
          // topic norm
          vector<reco::Feature>::iterator t_it;
          float norm_topic = 0.001; // to make sure no normed weight can >= 1
          for (t_it = ct_it->second.begin(); t_it != ct_it->second.end(); ++t_it) { // each topic
            norm_topic += t_it->weight();
          }

          if (norm_topic < 0.001) {
            continue;
          }
          // tag norm
          float norm_tag = 0.001;
          vector<reco::Feature>::iterator tag_it;
          if ((ctag_it = cate_tags.find(ct_it->first)) != cate_tags.end()) {
            for (tag_it = ctag_it->second.begin(); tag_it != ctag_it->second.end();
                 ++tag_it) { // each tag
              norm_tag += tag_it->weight();
            }
          }

          cout << subtokens[2] << "-" << ct_it->first << "\tU\t";
          // whether user cate hit item cate
          std::unordered_map<string, float>::iterator cw_it;
          string cate_str;
          if (cate_norm > 0.001 &&
              (cw_it = cate_weight.find(ct_it->first)) != cate_weight.end()) {
            cate_str = cw_it->first + "_ulike_" +
                       base::StringPrintf("%d", int(cw_it->second / cate_norm / 0.2));
          } else {
            cate_str = cw_it->first + "_ulike_0";
          }

          cout << " " << base::CityHash64(cate_str.c_str(), cate_str.size()) << ":1.0";
          // topic
          for (t_it = ct_it->second.begin(); t_it != ct_it->second.end(); ++t_it) {
            string topic_str = ct_it->first + "_" + t_it->literal() + "_" +
                               base::StringPrintf("%d", int(t_it->weight() / norm_topic / 0.1));
            cout << " " << base::CityHash64(topic_str.c_str(), topic_str.size()) << ":1.0";
          }
          // tag
          if (cate_tags.find(ct_it->first) != cate_tags.end()) {
            for (tag_it = ctag_it->second.begin(); tag_it != ctag_it->second.end();
                 ++tag_it) {
              string tag_str = ctag_it->first + "_" + tag_it->literal() + "_" +
                               base::StringPrintf("%d", int(tag_it->weight() / norm_tag / 0.1));
              cout << " " << base::CityHash64(tag_str.c_str(), tag_str.size()) << ":1.0";
            }
          }
          // end
          cout << endl;
        }

      }

    }

  }

  return 0;
}

