// for video
// user video tag + user text tag
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/hdfs/hdfs_file_util.h"
#include "base/encoding/line_escape.h"
#include "base/hash_function/city.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "third_party/jsoncpp/include/json/json.h"
#include "nlp/common/nlp_util.h"

using std::string;
using std::vector;
using std::cout;
using std::endl;

DEFINE_int32(max_vtag, 50, "max video tag num");
DEFINE_int32(max_ttag, 30, "max text tag num");
DEFINE_string(item_keeper_ips, "11.251.177.96", "item keeper ips");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");

// 和 news_index.cc 的同名函数保持一致
void ParseVideoTagFeatureVector(const reco::FeatureVector& raw_feature,
                                reco::FeatureVector *real_feature) {
  real_feature->Clear();
  bool manual_checked = false;
  for (int i = 0; i < raw_feature.feature_size(); ++i) {
    const std::string &raw_tag = raw_feature.feature(i).literal();
    std::vector<std::string> tokens;
    base::SplitString(raw_tag, ":", &tokens);
    if (tokens.size() > 1 && tokens[0] == "manual") {
      manual_checked = true;
      break;
    }
  }

  for (int i = 0; i < raw_feature.feature_size(); ++i) {
    const std::string &raw_tag = raw_feature.feature(i).literal();
    std::vector<std::string> tokens;
    base::SplitString(raw_tag, ":", &tokens);
    std::string real_tag = "";
    if (tokens.size() <= 1) {
      // 没有前缀的直接认为是正确的 tag
      real_tag = tokens[0];
    } else if (!manual_checked && (tokens[0] == "label" || tokens[0] == "manual")) {
      real_tag = tokens[1];
    } else if (manual_checked && tokens[0] == "manual") {
      real_tag = tokens[1];
    }
    if (!real_tag.empty()) {
      auto fea = real_feature->add_feature();
      fea->CopyFrom(raw_feature.feature(i));
      fea->set_literal(real_tag);
    }
  }
}

//[in1] mergelog
//[in2] prefix-userid, user info pb
//[out1] 0:uid 1:show(=1){ }click{ }item_parentid(as sign):1.0[{ }item_tag_sign:1.0]
//[out2] 0:uid 1:"U" 2:[{ }user feature sign:1.0]
int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  reco::BaseGetItem* get_item = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips,
                                                            FLAGS_item_keeper_port);
  std::unordered_map<uint64, vector<string> > item_tags;
  // read hdfs
  string line;
  while (std::getline(std::cin, line)) {
    vector<string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() > 83) { // in1
      if (tokens[4] != "30" || tokens[70].empty()) {
        continue;
      }
      // click
      float click = 0;
      if (tokens[10] != "0") {
        if (tokens[84].empty()) {
          continue;
        }

        Json::Reader j_reader;
        Json::Value j_value;
        if (!j_reader.parse(tokens[84], j_value)) {
          continue;
        }

        if (j_value.isMember("played") && j_value.isMember("video_len")) {
          vector<string> subtokens1;
          base::SplitString(j_value["played"].toStyledString(), "\"", &subtokens1);
          double played = 0;
          vector<string> subtokens2;
          base::SplitString(j_value["video_len"].toStyledString(), "\"", &subtokens2);
          double video_len = 0;
          if (base::StringToDouble(subtokens1[1], &played) &&
              base::StringToDouble(subtokens2[1], &video_len)) {
            click = played / (video_len * 0.8 + 0.1) / 1000; // play is milisecond, vlen is second
          } else {
            click = 1;
          }
          
        } else {
          click = 1;
        }

        if (click > 1) {
          click = 1;
        } else if (click < 0) {
          click = 0;
        }

        if (j_value.isMember("auto") && j_value["auto"].toStyledString() == "1") {
          click *= 0.5;
        }
      }
      // out1
      uint64 item_id = 0;
      if (!base::StringToUint64(tokens[70], &item_id)) {
        continue;
      }

      cout << tokens[9] << "\t1 " << click << " " << tokens[70] << ":1.0";
      if (item_tags.find(item_id) == item_tags.end()) {  // fill buf
        reco::RecoItem reco_item;
        vector<string> final_tags;
        if (get_item->GetRecoItem(item_id, &reco_item) && reco_item.has_tag()) {
          auto &raw_tags = reco_item.tag();
          reco::FeatureVector real_tags;
          ParseVideoTagFeatureVector(raw_tags, &real_tags);
          for (int i = 0; i < real_tags.feature_size(); ++i) {  // each tag
            final_tags.push_back("IT_" + real_tags.feature(i).literal());
          }
        }

        item_tags[item_id] = final_tags;  // fill even if value is empty
      }

      auto &final_tags = item_tags[item_id];
      for (auto i = 0u; i < final_tags.size(); ++i) {
        cout << " " << base::CityHash64(final_tags[i].c_str(), final_tags[i].size()) << ":1.0";
      }

      cout << endl;

    } else { // in2
      vector<string> subtokens;
      base::SplitString(tokens[0], "-", &subtokens);
      // get "uc-iflow-$uid"
      if (subtokens.size() == 3 && subtokens[0] + subtokens[1] == "uciflow") {
        string userinfo_str;
        reco::UserInfo user_info;
        // video tag 
        if (!base::LineUnescape(tokens[1], &userinfo_str) ||
            !user_info.ParseFromString(userinfo_str) ||
            !user_info.has_profile() ||
            !user_info.profile().has_video_tag_without_cat_feavec()) {
          continue;
        }

        auto &v_tag_vec = user_info.profile().video_tag_without_cat_feavec();
        float norm_vtag = 0.001;
        int count_v = 0;
        for (int i = 0; i < v_tag_vec.feature_size() && count_v < FLAGS_max_vtag; ++i) { // top video tag
          norm_vtag += v_tag_vec.feature(i).weight();
          ++count_v;
        }
        // out2
        cout << subtokens[2] << "\tU\t";
        for (int i = 0; i < count_v; ++i) {
          auto &tag = v_tag_vec.feature(i);
          string tag_lt = tag.literal();
          nlp::util::NormalizeLineInPlaceS(&tag_lt);
          string tag_str = "UT_" + tag_lt + "_" +
                           base::StringPrintf("%d", int(tag.weight() / norm_vtag * count_v));
          cout << " " << base::CityHash64(tag_str.c_str(), tag_str.size()) << ":1.0";
        }

        // text tag 
        if (user_info.profile().has_category_feavec() &&
            user_info.profile().has_tag_feavec()) {
          // user-like cates
          auto &category_feavec = user_info.profile().category_feavec();
          std::unordered_set<string> like_cates;
          for (int i = 0; i < category_feavec.feature_size() && i < 3; ++i) { // top 3 user like cate
            like_cates.insert(category_feavec.feature(i).literal().category());
          }
          // tags of user-like cates
          auto &t_tag_vec = user_info.profile().tag_feavec();
          std::unordered_map< string, vector<reco::Feature> > cate_ttags;
          int count_t = 0;
          for (int i = 0; i < t_tag_vec.feature_size() && count_t < FLAGS_max_ttag; ++i) { // top text tag
            auto &tag = t_tag_vec.feature(i);
            if (!tag.has_category() || like_cates.find(tag.category()) == like_cates.end()) {
              continue;
            }

            cate_ttags[tag.category()].push_back(tag);
            ++count_t;
          }
          // out2
          std::unordered_map< string, vector<reco::Feature> >::iterator ctag_it;
          for (ctag_it = cate_ttags.begin(); ctag_it != cate_ttags.end(); ++ctag_it) { // each cate
            vector<reco::Feature>::iterator t_it;
            float norm_ttag = 0.001;
            for (t_it = ctag_it->second.begin(); t_it != ctag_it->second.end(); ++t_it) { // each tag
              norm_ttag += t_it->weight();
            }

            for (t_it = ctag_it->second.begin(); t_it != ctag_it->second.end(); ++t_it) {
              string tag_lt = t_it->literal();
              nlp::util::NormalizeLineInPlaceS(&tag_lt);
              string tag_str = ctag_it->first + "_" + tag_lt + "_" +
                               base::StringPrintf("%d", int(t_it->weight() / norm_ttag * count_t));
              cout << " " << base::CityHash64(tag_str.c_str(), tag_str.size()) << ":1.0";
//              cout << " " << tag_str.c_str() << ":1.0";
            }
          }
        }

        // end
        cout << endl;
      } // end if

    } // end else

  }

  delete get_item;

  return 0;
}

