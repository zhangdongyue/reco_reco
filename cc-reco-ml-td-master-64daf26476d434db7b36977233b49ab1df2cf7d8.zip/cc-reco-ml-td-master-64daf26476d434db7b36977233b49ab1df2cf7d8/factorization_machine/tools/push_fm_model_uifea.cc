#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/hdfs/hdfs_file_util.h"
#include "base/file/file_util.h"
#include "base/common/sleep.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/fm_inner/fm_model.h"
#include "reco/serv/dict_server/api/dict_server_api.h"
#include "reco/bizc/proto/fm_interface.pb.h"

DEFINE_bool(push_model, false, "");
DEFINE_bool(push_fea_list, false, "");
DEFINE_bool(update_version, false, "");
DEFINE_string(fea_list_local_path, "", "fea list at local");
DEFINE_string(fac_machine_version, "", "");
DEFINE_bool(get_version, false, "");
DEFINE_bool(get_next_version, false, "");

using std::string;
using std::vector;
using std::pair;

class PushFMModel {
 public:
  PushFMModel();
  ~PushFMModel();

  bool GetNextVersion();
  bool UpdateVersion();
  bool PushModel();
  bool PushFeatureList();
  bool GetVersion();
  void GetValue();

 private:
  bool SetFeature(const vector<string> &tokens, reco::FacMachineFeature *fm_feature);
  reco::leafserver::FacMachineModel *fm_model_;
};

PushFMModel::PushFMModel() {
  fm_model_ = new reco::leafserver::FacMachineModel;
  reco::leafserver::FacMachineModel::StaticInit();
}

PushFMModel::~PushFMModel() {
  delete fm_model_;
}

bool PushFMModel::UpdateVersion() {
  if (!fm_model_->UpdateVersion(FLAGS_fac_machine_version)) {
    LOG(INFO) << "update version fail";
    return false;
  }

  LOG(INFO) << "update version success [" << FLAGS_fac_machine_version << "]";
  return true;
}

// [IN] format:feature sign
bool PushFMModel::PushFeatureList() {
  std::ifstream fin(FLAGS_fea_list_local_path);
  if (!fin.good()) {
    LOG(ERROR) << "open local file fail [" << FLAGS_fea_list_local_path << "]";
    return false;
  }

  std::string line;
  vector<reco::FacMachineFeatureList> fea_lists(reco::leafserver::FLAGS_fea_group_num);
  uint64 sign = 0;
  int count = 0;
  while (std::getline(fin, line)) {
    base::TrimWhitespaces(&line);
    base::StringToUint64(line, &sign);
    fea_lists[sign % reco::leafserver::FLAGS_fea_group_num].add_sign(sign);
    ++count;
  }

  fin.close();
  LOG(INFO) << "load fea list success [" << count << "]";

  if (!fm_model_->UpdateFeatureList(FLAGS_fac_machine_version, fea_lists)) {
    return false;
  }

  LOG(INFO) << "push fea list to dictserver success";

  return true;
}

bool PushFMModel::SetFeature(const vector<string> &tokens, reco::FacMachineFeature *fm_feature) {
  double weight = 0;
  if (!base::StringToDouble(tokens[2], &weight)) {
    LOG(ERROR) << "convert to double fail [" << tokens[2] << "]";
    return false;
  }

  fm_feature->set_confidence(1);
  fm_feature->set_w_weight(weight);
  if (tokens.size() < 4) {
    return true;
  }

  vector<string> v_weights;
  base::SplitString(tokens[3], " ", &v_weights);
  for (uint32 i = 0; i < v_weights.size(); ++i) {
    if (!base::StringToDouble(v_weights[i], &weight)) {
      LOG(ERROR) << "convert to double fail [" << v_weights[i] << "]";
      return false;
    }

    fm_feature->add_v_vector(weight);
  }

  return true;
}

// [in]0:feature sign 1:category 2:w 3:[v(sep by space)]
bool PushFMModel::PushModel() {
  string line;
  while (std::getline(std::cin, line)) { // each feature
    vector<string> tokens;
    base::SplitString(line, "\t", &tokens);

    if (tokens.size() < 3) {
      continue;
    }

    uint64 sign = 0;
    if (!base::StringToUint64(tokens[0], &sign)) {
      LOG(ERROR) << "convert sign to uint64 fail [" << tokens[0] << "]";
      continue;
    }

    reco::FacMachineFeature feature;
    if (!SetFeature(tokens, &feature)) {
      LOG(ERROR) << "tag SetFeature fail [" << sign << "]";
      return false;
    }

    if (!fm_model_->UpdateFeatureMatrix(FLAGS_fac_machine_version, sign, feature)) {
      LOG(ERROR) << "UpdateItemTagMatrix fail [" << sign << "]";
      return false;
    }
  }

  return true;
}

bool PushFMModel::GetVersion() {
  string version;
  if (!fm_model_->GetVersion(&version)) {
    return false;
  }

  std::cout << "current version:" << version << std::endl;
  return true;
}

bool PushFMModel::GetNextVersion() {
  string version;
  fm_model_->GetNextVersion(&version);
  LOG(INFO) << "get next version:" << version;
  // cout is NECESSARY for python judegment!!!!!!!!!!!!!!!!!!
  std::cout << version << std::endl;
  return true;
}


int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  reco::dictserver::DictServerAPIIns::instance().Init();
  PushFMModel push_fm_model;
  if (FLAGS_push_model) {
    if (!push_fm_model.PushModel()) return -1;
  }
  else if (FLAGS_push_fea_list) {
   if (!push_fm_model.PushFeatureList()) return -1;
  }
  else if (FLAGS_update_version) {
    if (!push_fm_model.UpdateVersion()) return -1;
  }
  else if (FLAGS_get_next_version) {
    if (!push_fm_model.GetNextVersion()) return -1;
  }

  return 0;
}

