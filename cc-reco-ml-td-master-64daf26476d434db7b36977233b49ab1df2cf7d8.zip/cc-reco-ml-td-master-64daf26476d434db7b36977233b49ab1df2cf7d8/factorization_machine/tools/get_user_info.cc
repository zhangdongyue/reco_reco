#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/hdfs/hdfs_file_util.h"
#include "base/encoding/line_escape.h"
#include "reco/bizc/proto/user.pb.h"


using std::string;
using std::vector;
using std::cout;

//[in] user info str
int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  string line;
  while (std::getline(std::cin, line)) {
    vector<string> tokens;
    base::SplitString(line, "\t", &tokens);
    string line_unes;
    if (!base::LineUnescape(tokens[1], &line_unes)) {
      cout << "LineUnescape failed" << std::endl;
    }

    reco::UserInfo user_info;
    if (!user_info.ParseFromString(line_unes)) {
      cout << "parse user info failed:" << line_unes.size() << std::endl;
      continue;
    }

    cout << "uid:" << user_info.identity().user_id();
    if (!user_info.has_user_group_info()) {
      cout << " has no group_info" << std::endl;
      continue;
    }

    auto &user_group_info = user_info.user_group_info();
    for (int i = 0; i < user_group_info.user_groups_size(); ++i) {
      cout << " " << user_group_info.user_groups(i).group_id() << " "
           << user_group_info.user_groups(i).group_name() << " "
           << user_group_info.user_groups(i).weight();
    }

    cout << std::endl;
  }

  return 0;
}

