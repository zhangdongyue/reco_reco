#include "reco/ml/word2vec/word2vec.h"

#include <cstdio>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <algorithm>

#include "base/file/file_util.h"
#include "reco/base/common/topn_priority_queue.h"
#include "base/thread/thread_util.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"

namespace reco {
namespace ml {

std::string SimilarTermsToString(const SimilarTerms& similar_terms,
                                 const std::string& item_delim,
                                 const std::string& field_delim) {
  std::string str;
  for (auto iter = similar_terms.begin(); iter != similar_terms.end(); ++iter) {
    if (str.empty()) {
      str = iter->first + field_delim + base::DoubleToString(iter->second);
    } else {
      str += item_delim + iter->first + field_delim + base::DoubleToString(iter->second);
    }
  }

  return str;
}

bool SimilarTermsParseFromString(const std::string& origin,
                                 const std::string& item_delim,
                                 const std::string& field_delim,
                                 SimilarTerms* similar_terms) {
  similar_terms->clear();
  std::vector<std::string> items;
  base::SplitString(origin, item_delim, &items);
  if (items.size() < 1) return false;
  for (auto iter = items.begin(); iter != items.end(); ++iter) {
    std::vector<std::string> kv;
    base::SplitString(*iter, field_delim, &kv);
    if (kv.size() != 2) return false;
    double cosine;
    if (!base::StringToDouble(kv[1], &cosine)) {
      VLOG(2) << "value not double";
      return false;
    }
    similar_terms->push_back(std::make_pair(kv[0], cosine));
  }

  return true;
}

bool Word2Vec::LoadModel(const base::FilePath& model_path, const bool binary) {
  if (binary) {
    return LoadBinaryModel(model_path);
  }

  return false;
}

bool Word2Vec::LoadBinaryModel(const base::FilePath& model_path) {
  if (!base::file_util::PathExists(model_path)) {
    LOG(ERROR) << "word2vec file does not exist";
    return false;
  }

  FILE* file = NULL;
  if (!(file = fopen(model_path.value().c_str(), "rb"))) {
    LOG(ERROR) << "open word2vec file failed";
    return false;
  }

  fscanf(file, "%lld", &words_);
  if (words_ <= 0) return false;

  fscanf(file, "%lld", &size_);
  if (size_ <= 0) return false;

  char ch;
  char term[200];
  for (int32 i = 0; i < words_; ++i) {
    fscanf(file, "%s%c", term, &ch);
    std::string word = term;
    dict_.insert(std::make_pair(word, i));
    terms_.push_back(word);
    vectors_.push_back(std::vector<float>());
    std::vector<float>& vec = vectors_.back();
    vec.reserve(size_);
    float value = 0;
    for (int32 j = 0; j < size_; ++j) {
      fread(&value, sizeof(float), 1, file);
      vec.push_back(value);
    }
    float norm = 0.0f;
    for (int32 j = 0; j < size_; ++j) {
      norm += vec.at(j) * vec.at(j);
    }
    norm = std::sqrt(norm);
    for (int32 j = 0; j < size_; ++j) {
      vec[j] /= norm;
    }
  }

  fclose(file);

  return true;
}

bool Word2Vec::Cosine(const std::vector<float>& lhs, const std::vector<float>& rhs, float* cosine) {
  if (lhs.size() != rhs.size()) return false;
  float dot = 0.0f;
  for (uint32 i = 0; i < size_; ++i) {
    dot += lhs.at(i) * rhs.at(i);
  }

  *cosine = dot;

  return true;
}

bool Word2Vec::Similarity(const std::string& lhs, const std::string& rhs, float* similarity) {
  auto lhs_it = dict_.find(lhs);
  if (lhs_it == dict_.end()) return false;
  auto rhs_it = dict_.find(rhs);
  if (rhs_it == dict_.end()) return false;

  uint64 lhs_index = 0, rhs_index = 0;
  lhs_index = lhs_it->second;
  rhs_index = rhs_it->second;

  return Cosine(vectors_.at(lhs_index), vectors_.at(rhs_index), similarity);
}

bool Word2Vec::MostSimilar(const std::string& word,
                           const int top_k,
                           SimilarTerms* similar_words) {
  auto main_it = dict_.find(word);
  if (main_it == dict_.end()) return false;
  uint64 main_index = main_it->second;
  similar_words->clear();

  TopNPriorityQueue<std::string> most_like(top_k);
  for (auto iter = dict_.begin(); iter != dict_.end(); ++iter) {
    if (iter->second == main_index) continue;
    float cosine = 0;
    if (Cosine(vectors_.at(main_index), vectors_.at(iter->second), &cosine)) {
      most_like.add(iter->first, static_cast<double>(cosine));
    }
  }

  most_like.get_top_n_ordered(similar_words);

  return true;
}

void Word2Vec::MostSimilarMultiThread(const std::vector<std::string>& terms,
                                      const int top_k,
                                      const int thread_num,
                                      thread::BlockingQueue<SimilarPair*>* output_queue) {
  ScopedMostSimilarMultiThread(terms, top_k, terms_, thread_num, output_queue);
}

bool Word2Vec::ScopedMostSimilar(const std::string& word,
                                 const int top_k,
                                 const std::vector<std::string>& scope,
                                 SimilarTerms* similar_words) {
  auto main_it = dict_.find(word);
  if (main_it == dict_.end()) return false;
  uint64 main_index = main_it->second;
  similar_words->clear();

  TopNPriorityQueue<std::string> most_like(top_k);
  for (auto iter = scope.begin(); iter != scope.end(); ++iter) {
    auto idx_iter = dict_.find(*iter);
    if (idx_iter == dict_.end()) continue;
    if (idx_iter->second == main_index) continue;
    float cosine = 0;
    if (Cosine(vectors_.at(main_index), vectors_.at(idx_iter->second), &cosine)) {
      most_like.add(idx_iter->first, static_cast<double>(cosine));
    }
  }

  most_like.get_top_n_ordered(similar_words);

  return true;
}

void Word2Vec::ScopedMostSimilarThread(const std::vector<std::string>* terms,
                                       const int top_k,
                                       const std::vector<std::string>* scope,
                                       thread::BlockingQueue<SimilarPair*>* output_queue) {
  for (auto iter = terms->begin(); iter != terms->end(); ++iter) {
    SimilarPair* similar_pair = new SimilarPair;
    if (!similar_pair) {
      LOG(ERROR) << "OOM in ScopedMostSimilarThread";
      delete terms;
      return;
    }
    if (ScopedMostSimilar(*iter, top_k, *scope, &(similar_pair->similar_terms))) {
      similar_pair->main_term = *iter;
      output_queue->Put(similar_pair);
      continue;
    }

    delete similar_pair;
    similar_pair = NULL;
  }
  delete terms;
}

void Word2Vec::ScopedMostSimilarMultiThread(const std::vector<std::string>& terms,
                                            const int top_k,
                                            const std::vector<std::string> &scope,
                                            const int thread_num,
                                            thread::BlockingQueue<SimilarPair*>* output_queue) {
  if (terms.empty() || scope.empty()) return;
  thread::ThreadPool pool(thread_num);
  const int kStepSize = 1000;
  for (size_t i = 0; i < terms.size(); i += kStepSize) {
    size_t end = std::min(i + kStepSize, terms.size());
    std::vector<std::string>* subs =
        new std::vector<std::string>(terms.begin() + i, terms.begin() + end);
    pool.AddTask(::NewCallback<reco::ml::Word2Vec, const std::vector<std::string>*,
                 const int, const std::vector<std::string>*, thread::BlockingQueue<SimilarPair*>*>
                 (this, &Word2Vec::ScopedMostSimilarThread, subs, top_k, &scope, output_queue));
  }

  pool.JoinAll();
}

bool Word2Vec::DumpSimilarPairs(const std::string& output_path,
                                thread::BlockingQueue<SimilarPair*>* output_queue) {
  std::ofstream output(output_path);
  if (!output.is_open()) {
    LOG(ERROR) << "error opening file: " << output_path;
    return false;
  }

  int retry = 5;
  SimilarPair* similar_pair = NULL;
  while (!output_queue->Closed() && !output_queue->Empty()) {
    if (output_queue->TryTake(&similar_pair) != 1) {
      base::SleepForMilliseconds(50);
      if (--retry == 0) {
        break;
      }
      continue;
    }
    if (!similar_pair) break;
    retry = 5;
    std::string str = similar_pair->ToString();
    output << str << std::endl;
    delete similar_pair;
    similar_pair = NULL;
  }

  output.close();
  return true;
}
}
}
