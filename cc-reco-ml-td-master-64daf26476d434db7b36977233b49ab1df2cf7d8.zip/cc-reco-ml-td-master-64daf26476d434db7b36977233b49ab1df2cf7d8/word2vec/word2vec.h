#pragma once

#include <vector>
#include <unordered_map>
#include <string>
#include <utility>

#include "base/file/file_path.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/thread/blocking_queue.h"

namespace reco {
namespace ml {

typedef std::vector<std::pair<std::string, double> > SimilarTerms;

std::string SimilarTermsToString(const SimilarTerms& similar_terms,
                                 const std::string& item_delim,
                                 const std::string& field_delim);

bool SimilarTermsParseFromString(const std::string& origin,
                                 const std::string& item_delim,
                                 const std::string& field_delim,
                                 SimilarTerms* similar_terms);

struct SimilarPair {
  std::string main_term;
  SimilarTerms similar_terms;

  std::string ToString() {
    return main_term + "\t" + SimilarTermsToString(this->similar_terms, "\02", "\01");
  }
};

class Word2Vec {
 public:
  bool LoadModel(const base::FilePath& model_path, const bool binary);

  bool Similarity(const std::string& lhs, const std::string& rhs, float* similarity);

  bool MostSimilar(const std::string& word,
                   const int top_k,
                   SimilarTerms* similar_words);

  void MostSimilarMultiThread(const std::vector<std::string>& terms,
                              const int top_k,
                              const int thread_num,
                              thread::BlockingQueue<SimilarPair*>* output_queue);

  bool ScopedMostSimilar(const std::string& word,
                         const int top_k,
                         const std::vector<std::string>& scope,
                         SimilarTerms* similar_words);

  void ScopedMostSimilarMultiThread(const std::vector<std::string>& terms,
                                    const int top_k,
                                    const std::vector<std::string>& scope,
                                    const int thread_num,
                                    thread::BlockingQueue<SimilarPair*>* output_queue);

  bool DumpSimilarPairs(const std::string& output_path,
                        thread::BlockingQueue<SimilarPair*>* output_queue);

  const std::vector<std::string>& GetAllTerms() const {
    return terms_;
  }

 private:
  bool LoadBinaryModel(const base::FilePath& model_path);

  bool Cosine(const std::vector<float>& lhs, const std::vector<float>& rhs, float* cosine);

  void ScopedMostSimilarThread(const std::vector<std::string>* terms,
                               const int top_k,
                               const std::vector<std::string>* scope,
                               thread::BlockingQueue<SimilarPair*>* output_queue);
 private:
  long long words_;
  long long size_;
  std::unordered_map<std::string, uint64> dict_;
  std::vector<std::string> terms_;
  std::vector<std::vector<float> > vectors_;
};
}
}
