#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include "base/random/pseudo_random.h"
#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/hdfs/hdfs_file_util.h"
#include "base/encoding/line_escape.h"
#include "base/hash_function/city.h"
#include "reco/bizc/proto/user.pb.h"
#include "third_party/jsoncpp/include/json/json.h"
#include "nlp/common/nlp_util.h"
#include "reco/ml/video_model/util/video_keeper.h"

using std::string;
using std::vector;
using std::cout;
using std::endl;

DEFINE_int32(max_vtag, 50, "max video tag num");
DEFINE_int32(max_ttag, 30, "max text tag num");

//[in1] mergelog
//[in2] prefix-userid, user info pb
//[out1] 0:uid 1:clickitem_parentid[item_feature/scene_feature]
//[out2] 0:uid 1:"U" 2:[user_feature]
int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  if (!reco::video_util::VideoKeeperIns::instance().Init()) {
    LOG(ERROR) << "init video keeper failed";
    return 1;
  }

  string line;
  // read hdfs
  while (std::getline(std::cin, line)) {
    vector<string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() > 83) { // in1
      if (tokens[4] != "30" || tokens[70].empty()) {
        continue;
      }
      // click
      float click = 0;
      if (tokens[10] != "0") {
        if (tokens[84].empty()) {
          continue;
        }

        Json::Reader j_reader;
        Json::Value j_value;
        if (!j_reader.parse(tokens[84], j_value)) {
          continue;
        }

        if (j_value.isMember("played") && j_value.isMember("video_len")) {
          vector<string> subtokens1;
          base::SplitString(j_value["played"].toStyledString(), "\"", &subtokens1);
          double played = 0;
          vector<string> subtokens2;
          base::SplitString(j_value["video_len"].toStyledString(), "\"", &subtokens2);
          double video_len = 0;
          if (base::StringToDouble(subtokens1[1], &played) &&
              base::StringToDouble(subtokens2[1], &video_len)) {
            click = played / (video_len * 0.8 + 0.1) / 1000;  // play is milisecond, vlen is second
          } else {
            click = 1;
          }
          
        } else {
          click = 1;
        }

        if (click > 1) {
          click = 1;
        } else if (click < 0) {
          click = 0;
        }

        if (j_value.isMember("auto") && j_value["auto"].toStyledString() == "1") {
          click *= 0.5;
        }
      }
      // out1
      uint64 item_id = 0;
      if (!base::StringToUint64(tokens[70], &item_id)) {
        continue;
      }

      cout << tokens[9] << "\tlabel=0:" << click << "item_id=0:" << tokens[70];
      reco::video_util::BasicItemInfo basic_item_info;
      if (reco::video_util::VideoKeeperIns::instance().GetFromAir(
          item_id, &basic_item_info)) {
        for (auto i = 0u; i < basic_item_info.tags.size(); ++i) {
          if (i == 0u) {
            cout << "item_tags=0:";
          } else {
            cout << "`";
          }

          cout << basic_item_info.tags[i];
        }

        if (basic_item_info.category.size() > 0) {
          cout << "item_category=0:" << basic_item_info.category;
        }

        if (basic_item_info.source.size() > 0) {
          cout << "item_source=0:" << basic_item_info.source;
        }
      }

      // channel
      cout << "channel=0:" << tokens[5];

      cout << endl;
    }
    else { // in2
      vector<string> subtokens;
      base::SplitString(tokens[0], "-", &subtokens);
      // get "uc-iflow-$uid"
      if (subtokens.size() == 3 && subtokens[0] + subtokens[1] == "uciflow") {
        string userinfo_str;
        reco::user::UserInfo user_info;
        // video tag 
        if (!base::LineUnescape(tokens[1], &userinfo_str) ||
            !user_info.ParseFromString(userinfo_str) ||
            !user_info.has_profile() ||
            !user_info.profile().has_video_tag_without_cat_feavec()) {
          continue;
        }

        const reco::user::Profile &profile = user_info.profile();
        auto &v_tag_vec = profile.video_tag_without_cat_feavec();
        float norm_vtag = 0.001;
        int count_v = 0;
        for (int i = 0; i < v_tag_vec.feature_size() && count_v < FLAGS_max_vtag; ++i) { // top video tag
          norm_vtag += v_tag_vec.feature(i).weight();
          ++count_v;
        }
        // out2
        cout << subtokens[2] << "\tU\t";
        for (int i = 0; i < count_v; ++i) {
          auto &tag = v_tag_vec.feature(i);
          string tag_lt = tag.literal();
          nlp::util::NormalizeLineInPlaceS(&tag_lt);
          // 归一方法：权重相对于平均权重之比，映射到整数，其他归一同理
          string tag_str = tag_lt + "_" +
                           base::StringPrintf("%d", int(tag.weight() / norm_vtag * count_v));
          if (i == 0) {
            cout << "user_video_tags=0:";
          } else {
            cout << "`";
          }

          cout << tag_str;
        }

        // text tag 
        if (profile.has_category_feavec() &&
            profile.has_tag_feavec()) {
          // user-like cates
          auto &category_feavec = profile.category_feavec();
          std::unordered_set<string> like_cates;
          for (int i = 0; i < category_feavec.feature_size() && i < 3; ++i) { // top 3 user like cate
            like_cates.insert(category_feavec.feature(i).literal().category());
          }
          // tags of user-like cates
          auto &t_tag_vec = profile.tag_feavec();
          std::unordered_map< string, vector<reco::Feature> > cate_ttags;
          int count_t = 0;
          for (int i = 0; i < t_tag_vec.feature_size() && count_t < FLAGS_max_ttag; ++i) { // top text tag
            auto &tag = t_tag_vec.feature(i);
            if (!tag.has_category() || like_cates.find(tag.category()) == like_cates.end()) {
              continue;
            }

            cate_ttags[tag.category()].push_back(tag);
            ++count_t;
          }
          // out2
          std::unordered_map< string, vector<reco::Feature> >::iterator ctag_it;
          bool is_first = true;
          for (ctag_it = cate_ttags.begin(); ctag_it != cate_ttags.end(); ++ctag_it) { // each cate
            vector<reco::Feature>::iterator t_it;
            float norm_ttag = 0.001;
            for (t_it = ctag_it->second.begin(); t_it != ctag_it->second.end(); ++t_it) { // each tag
              norm_ttag += t_it->weight();
            }

            for (t_it = ctag_it->second.begin(); t_it != ctag_it->second.end(); ++t_it) {
              string tag_lt = t_it->literal();
              nlp::util::NormalizeLineInPlaceS(&tag_lt);
              string tag_str = ctag_it->first + "_" + tag_lt + "_" +
                               base::StringPrintf("%d", int(t_it->weight() / norm_ttag * count_t));
              if (is_first) {
                cout << "user_text_tags=0:";
                is_first = false;
              } else {
                cout << "`";
              }

              cout << tag_str;
            }
          }
        }

        // category
        if (profile.has_video_category_feavec()) {
          auto &video_category_feavec = profile.video_category_feavec();
          float norm_cate = 0.001;
          int count_c = 0;
          for (int i = 0; i < video_category_feavec.feature_size() && i < 3; ++i) { // top 3
            norm_cate += video_category_feavec.feature(i).weight();
            ++count_c;
          }

          bool is_first = true;
          for (int i = 0; i < video_category_feavec.feature_size() && i < 3; ++i) {
            if (is_first) {
              cout << "user_cates=0:";
              is_first = false;
            } else {
              cout << "`";
            }

            auto &cate = video_category_feavec.feature(i);
            cout << cate.literal().category() + "_" +
                    base::StringPrintf("%d", int(cate.weight() / norm_cate * count_c));
          }
        }

        // end
        cout << endl;
      } // end if

    } // end else
  }

  return 0;
}

