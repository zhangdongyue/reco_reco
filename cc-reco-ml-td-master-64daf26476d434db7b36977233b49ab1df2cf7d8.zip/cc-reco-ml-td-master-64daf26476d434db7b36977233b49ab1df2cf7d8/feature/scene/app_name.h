#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_scene_feature.h"

namespace reco {
namespace ml {
namespace scene_fea {

class AppName : public BaseSceneFeature {
 public:
  AppName() {}
  virtual ~AppName() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kAppName";
    return name;
  }

 protected:
  virtual bool ExtractSceneFeatureImpl(std::vector<std::string>* fea_parts) {
    if (scene_->app_name().empty()) return false;
    fea_parts->push_back(scene_->app_name());
    return true;
  }
};
}  // namespace scene_fea
}  // namespace ml
}  // namespace reco
