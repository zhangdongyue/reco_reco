#include <string>
#include <limits>
#include <iostream>
#include <unordered_map>

#include "reco/ml/feature/scene/include.h"

#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {
namespace scene_fea {

class SceneFeatureTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    // required fields
    scene_.set_app_name("uc-iflow");
  }

  virtual void TearDown() {
    delete feature_;
  }

  BaseSceneFeature* feature_;
  reco::SceneInfo scene_;
};

TEST_F(SceneFeatureTest, AppName) {
  feature_ = new AppName();
  feature_->SetScene(scene_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "uc-iflow");
}

}  // namespace scene_fea
}  // namespace ml
}  // namespace reco
