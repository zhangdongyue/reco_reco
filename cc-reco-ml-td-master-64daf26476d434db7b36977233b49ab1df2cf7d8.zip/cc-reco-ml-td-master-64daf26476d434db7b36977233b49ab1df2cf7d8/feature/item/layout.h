#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"
#include "nlp/common/nlp_util.h"
#include "base/math/discrete.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {
namespace item_fea {

class Layout : public BaseItemFeature {
 public:
  Layout() {}
  virtual ~Layout() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kLayout";
    return name;
  }

 public:
    static const int kMinParaLen = 10;
    static const int32 avg_para_num = 1e5;
 protected:
  // 段落和图片占比
  // 图片和图片之间的平均段落数
  // 图片和图片之间的平均文字个数
  // 段落间平均的图片个数
  // 是否以图片开头
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    const std::string kPicPlaceholder = "PicPlaceholder";
    static const std::vector<double> graphic_ratio_bounds = {0.1, 0.4, 0.8, 1.2, 1.6};
    static const std::vector<double> avg_pic_num_bounds = {0.1, 0.5, 1.0, 1.5, 2.0};
    static const std::vector<double> avg_para_num_bounds = {0.1, 0.5, 1.0, 1.5, 2.0};
    static const std::vector<double> avg_literal_len_bounds = {50, 100, 150, 250, 478, 700};
    const std::string& content = item_->content();
    std::vector<std::string> layout;
    std::vector<std::string> flds;
    // 按图片占位符分割 content
    auto pos = content.find("\1", 0);
    int32 index = 0;
    int32 pic_index = 0;
    while (pos != std::string::npos) {
      std::string para = content.substr(index, pos - index);
      flds.clear();
      base::SplitString(para, "\n", &flds);
      for (size_t j = 0; j < flds.size(); ++j) {
        if (flds[j] != "") layout.push_back(flds[j]);
      }
      layout.push_back(kPicPlaceholder);
      if (pic_index >= item_->image_size()) {
        return false;
      }
      if (item_->image(pic_index).has_desc() && item_->image(pic_index).desc() != "") {
        layout.push_back(item_->image(pic_index).desc());
      }
      ++pic_index;
      index = pos + sizeof("\1");
      pos = content.find("\1", pos + sizeof("\1"));
    }
    if (layout.size() == 0) return false;
    // 图, 段落个数和占比
    int32 pic_num = 0;
    int32 para_num = 0;
    float graphic_ratio = 0;
    for (size_t i = 0; i < layout.size(); ++i) {
      if (layout[i] == kPicPlaceholder) {
        ++pic_num;
      } else {
        int length = 0;
        if (!base::GetUTF8CharNum(layout[i], &length)) continue;
        if (length >= kMinParaLen) ++para_num;
      }
    }
    if (para_num == 0) return false;
    graphic_ratio = static_cast<float>(pic_num) / static_cast<float>(para_num);
    // 图片和图片之间的平均段落数 以及 文字数
    float avg_para_num = 0;
    float avg_literal_len = 0;
    int32 para_num_during_pic = 0;
    int32 literal_len_during_pic = 0;
    int32 pic_count = 0;
    for (size_t i = 0; i < layout.size(); ++i) {
      if (layout[i] == kPicPlaceholder) {
        if (pic_count == 0) {
          ++pic_count;
        } else {
          avg_para_num
            = ((avg_para_num * static_cast<float>(pic_count - 1))
                + static_cast<float>(para_num_during_pic))
              / static_cast<float>(pic_count);

          avg_literal_len = ((avg_literal_len * static_cast<float>(pic_count - 1))
                             + static_cast<float>(literal_len_during_pic))
                            / static_cast<float>(pic_count);
          ++pic_count;
          para_num_during_pic = 0;
          literal_len_during_pic = 0;
        }
      } else {
        if (pic_count != 0) {
          ++para_num_during_pic;
          int length = 0;
          if (base::GetUTF8CharNum(layout[i], &length)) {
            literal_len_during_pic += length;
          }
        }
      }
    }
    if (pic_count >= 2) {
      fea_parts->push_back("AvgParaNumDuringPic_"
                           + base::IntToString(base::math::Discretize(avg_para_num,
                                                                      avg_para_num_bounds)));
      fea_parts->push_back("AvgLiteralLen_"
                           + base::IntToString(base::math::Discretize(avg_literal_len,
                                                                      avg_literal_len_bounds)));
    }
    // 段落和段落之间的图片数
    float avg_pic_num = 0;
    int32 pic_num_during_para = 0;
    int32 para_count = 0;
    for (size_t i = 0; i < layout.size(); ++i) {
      if (layout[i] == kPicPlaceholder) {
        if (para_count > 0) ++pic_num_during_para;
      } else {
        int length = 0;
        if (!base::GetUTF8CharNum(layout[i], &length) || length < kMinParaLen) continue;
        if (para_count > 0) {
          avg_pic_num
            = (avg_pic_num * static_cast<float>(para_count - 1) + pic_num_during_para)
              / static_cast<float>(para_count);
        }
        pic_num_during_para= 0;
        ++para_count;
      }
    }
    fea_parts->push_back("PicParaRatio_"
                         + base::IntToString(base::math::Discretize(graphic_ratio,
                                                                    graphic_ratio_bounds)));
    if (avg_pic_num > 0) {
      fea_parts->push_back("AvgPicNumDuringPara_"
                           + base::IntToString(base::math::Discretize(avg_pic_num,
                                                                      avg_pic_num_bounds)));
    }
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
