#include "reco/ml/feature/item/low_quality_hit.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/utf_char_iterator.h"
#include "reco/ml/feature/item/include.h"

namespace reco {
namespace ml {
namespace item_fea {
const std::string kNumberStr = "NUMBER_TERM";
const std::string kTimeStr = "TIME_TERM";

bool inline has_id(const std::string& content, int p, int end, std::string* id) {
  while (p != end) {
    if ((content[p] >= '0' && content[p] <= '9') || content[p] == '-' ||
        (content[p] <= 'z' && content[p] >= 'a') || (content[p] <= 'Z' && content[p] >= 'A') ||
        content[p] == '_' || content[p] == ']' || content[p] == '[') {
      *id += content[p];
      ++p;
    } else {
      if (id->size() >= 7) {
        if (*id == "wechat" || *id == "strong" || *id == "emoji") {
          *id = "";
          ++p;
          continue;
        }
        return true;
      }
      *id = "";
      ++p;
    }
  }
  if (id->size() >= 5) {
    if (*id == "wechat" || *id == "strong" || *id == "emoji") return false;
    return true;
  }
  return false;
}

bool inline has_phone_number(const std::string& content, int p, int end, std::string* number) {
  while (p != end && number->size() < 15) {
    if (content[p] == ' ' || (content[p] >= '0' && content[p] <= '9') || content[p] == '-' ||
        content[p] == '_' || content[p] == ':' || content[p] == ']' || content[p] == '[' ||
        content[p] == '(' || content[p] == ')' || content[p] == '*') {
      *number += content[p];
      ++p;
    } else if (content[p] == '.' || content[p] == '%' || content[p] == 'x') {
      ++p;
      number->clear();
    } else {
      if (number->size() > 6) {
        return true;
      }
      *number = "";
      ++p;
    }
  }
  if (number->size() > 6) {
    return true;
  }
  return false;
}

inline bool IsFilteredByPostag(const nlp::term::TermInfo& info, const base::Slice& term) {
  if (info.is_postag(nlp::term::kPreposition)
      || info.is_postag(nlp::term::kAuxiliary)
      || info.is_postag(nlp::term::kExclamation)
      || info.is_postag(nlp::term::kQuantity)
      || info.is_postag(nlp::term::kPronoun)
      || info.is_postag(nlp::term::kConjunction)
      || info.is_postag(nlp::term::kPunctuation)) {
    return true;
  }
  return false;
}

void GenerateUnigram(const base::Slice& norm_text,
                     const nlp::term::TermContainer& container,
                     const std::vector<nlp::time::TimeEntity>& time_terms,
                     std::vector<base::Slice>* mix_terms) {
  int time_idx = -1;
  if (time_terms.size() > 0 && !time_terms.front().term_indices.empty()) {
    time_idx = 0;
  }
  bool has_insert_time = false;
  for (int i = 0; i < (int) container.mix_terms().size(); ++i) {
    const nlp::term::TermInfo& term_info = container.mix_term_info(i);
    const base::Slice& term_slice = container.mix_term_slice(norm_text, i);
    if (IsFilteredByPostag(term_info, term_slice)) continue;
    if (time_idx > -1 && time_idx < (int)time_terms[0].term_indices.size()) {
      if (time_terms[0].term_indices[time_idx] < i) {
        ++time_idx;
        --i;
        continue;
      }
      if (container.basic_term_slice(norm_text, time_terms[0].term_indices[time_idx]) == term_slice) {
        if (!has_insert_time) {
          mix_terms->push_back(kTimeStr);
          has_insert_time = true;
        }
        ++time_idx;
        continue;
      }
    }
    if (term_info.is_postag(nlp::term::kNumber)) {
      int char_num = 0;
      if (base::GetUTF8CharNum(term_slice, &char_num) && (int)term_slice.size() == char_num) {
        mix_terms->push_back(kNumberStr);
      } else {
        mix_terms->push_back(term_slice);
      }
    } else {
      mix_terms->push_back(term_slice);
    }
  }
}

bool LowQualityHit::IsValidUnigram(const base::Slice& unigram) {
  if (stopwords_->find(unigram.as_string()) != stopwords_->end()) {
    return false;
  }
  return true;
}

bool LowQualityHit::IsValidBigram(const base::Slice& term1, const base::Slice& term2) {
  if (!IsValidUnigram(term1) && !IsValidUnigram(term2)) return false;
  int len1 = 0;
  int len2 = 0;
  if (!base::GetUTF8CharNum(term1, &len1) && !base::GetUTF8CharNum(term2, &len2)) return false;
  if (len1 < 2 && len2 < 2) return false;
  return true;
}

// 直接用句子进行规则匹配
void LowQualityHit::DetectLineWithDict(const dawgdic::Dictionary& dict,
                                       const std::string& sentence,
                                       std::unordered_set<std::string>* hit_terms) const {
  std::vector<base::Slice> matches;
  std::vector<int> values;
  if (nlp::util::ForwardMaxMatch(dict, sentence, &matches, &values) == 0) return;
  CHECK_EQ(matches.size(), values.size());
  std::vector<std::pair<base::Slice, int>> sorted_matches;
  for (int i = 0; i < (int)matches.size(); ++i) {
    if (values[i] == 2 || values[i] > 3) {
      hit_terms->insert(matches[i].as_string());
    }
    sorted_matches.push_back(std::make_pair(matches[i], values[i]));
  }
  std::string ngram;
  dawgdic::BaseType index = dict.root();
  for (int i = 0;  i < (int)sorted_matches.size(); ++i) {
    index = dict.root();
    if (!dict.Follow(sorted_matches[i].first.data(), sorted_matches[i].first.size(), &index)) {
      continue;
    }
    for (int j = i + 1; j < (int)sorted_matches.size(); ++j) {
      dawgdic::BaseType index_temp = index;
      if (sorted_matches[j].second == 0 || sorted_matches[j].second == 5) continue;
      if (!dict.Follow(sorted_matches[j].first.data(), sorted_matches[j].first.size(), &index_temp)) {
        continue;
      }
      if (dict.has_value(index_temp) &&
          (dict.value(index_temp) == 2 || dict.value(index_temp) > 3)) {
        if (sentence.find(sorted_matches[j].first.as_string()) - sentence.find(sorted_matches[i].first.as_string()) > 50) continue; // NOLINT
        std::string temp = base::StringPrintf("%s#%s",
                                              sorted_matches[i].first.as_string().c_str(),
                                              sorted_matches[j].first.as_string().c_str());
        hit_terms->insert(temp);
      }
    }
  }
}

// 使用分词之后的结果进行匹配
void LowQualityHit::DetectWithDict(const dawgdic::Dictionary& dict,
                                   const std::vector<std::string>& terms,
                                   const std::string& sentence,
                                   std::unordered_set<std::string>* hit_terms) const {
  std::vector<std::pair<int, int> > matches;
  std::vector<int> values;
  std::vector<std::pair<std::string, int>> sorted_matches;
  std::vector<base::Slice> slice_terms;
  for (int i = 0; i < (int)terms.size(); ++i) {
    slice_terms.push_back(base::Slice(terms[i]));
  }
  if (nlp::util::ForwardMaxMatch(dict, slice_terms, &matches, &values) == 0) return;
  CHECK_EQ(matches.size(), values.size());
  std::string current_match;
  for (int i = 0; i < (int)matches.size(); ++i) {
    current_match.clear();
    int start = matches[i].first;
    int end = matches[i].second;
    while (start < end) {
      current_match += terms[start];
      ++start;
    }
    if (values[i] == 2 || values[i] > 3) {
      hit_terms->insert(current_match);
      continue;
    }
    sorted_matches.push_back(std::make_pair(current_match, values[i]));
  }
  std::string ngram;
  dawgdic::BaseType index = dict.root();
  for (int i = 0;  i < (int)sorted_matches.size(); ++i) {
    index = dict.root();
    if (sorted_matches[i].second == 1 || sorted_matches[i].second == 4) continue;
    if (!dict.Follow(sorted_matches[i].first.data(), sorted_matches[i].first.size(), &index)) continue;
    for (int j = i + 1; j < (int)sorted_matches.size(); ++j) {
      dawgdic::BaseType index_temp = index;
      if (sorted_matches[j].second == 0 || sorted_matches[j].second == 5) continue;
      if (!dict.Follow(sorted_matches[j].first.data(), sorted_matches[j].first.size(), &index_temp)) continue; // NOLINT
      if (dict.has_value(index_temp) &&
          (dict.value(index_temp) == 2 || dict.value(index_temp) > 3)) {
        if (sentence.find(sorted_matches[j].first) - sentence.find(sorted_matches[i].first) > 50) continue;
        std::string current = sorted_matches[i].first + "#" + sorted_matches[j].first;
        hit_terms->insert(current);
      }
    }
  }
}

// type 0: title
// type 1: content & image desc
void LowQualityHit::ProcessLine(int type, const std::string& line,
                                std::vector<std::string>* basic_ngrams,
                                std::vector<std::pair<std::string, int >>* result) {
  nlp::term::TermContainer term_container;
  int char_num = 0;
  if (!base::GetUTF8CharNum(line, &char_num) || char_num == 0) return;
  CHECK(segmenter_->SegmentT(line, &term_container));
  CHECK(pos_tagger_->PosTagT(line, &term_container));
  CHECK(ner_->DetectEntityT(line, &term_container));
  nlp::util::ConstructMixTerms(line, false, &term_container);
  std::vector<nlp::time::TimeEntity> time_tokens;
  base::Time current_time = base::Time::Now();
  time_reco_->DetectTime(current_time, line, term_container, &time_tokens);
  if (basic_ngrams != NULL) {
    for (size_t i = 0; i < term_container.basic_terms().size(); ++i) {
      basic_ngrams->push_back(term_container.basic_term_slice(line, i).as_string());
    }
  }
  std::vector<base::Slice> mix_unigrams;
  GenerateUnigram(line, term_container, time_tokens, &mix_unigrams);
  // fill basic terms
  for (int k = 0; k < (int)mix_unigrams.size(); ++k) {
    uint32 skip_num = 3;
    if (0 == type) skip_num = 10;  // 对于 title, 提升 skip num
    std::string term = "";
    if (!IsValidUnigram(mix_unigrams[k])) continue;
    const base::Slice& term1 = mix_unigrams[k];
    if (term1.size() == 0) continue;
    result->push_back(std::make_pair(term1.as_string(), type));
    for (size_t j = k + 1; j < mix_unigrams.size() && j < k + skip_num; ++j) {
      const base::Slice& term2 = mix_unigrams[j];
      if (term2.size() == 0) continue;
      if (!IsValidBigram(term1, term2)) continue;
      term.clear();
      if (term1 < term2) {
        term += term1.as_string();
        term += "#";
        term += term2.as_string();
      } else {
        term += term2.as_string();
        term += "#";
        term += term1.as_string();
      }
      result->push_back(std::make_pair(term, type));
    }
  }
}

void LowQualityHit::GenerateAdverHitFeaure(int type,
                                           const std::string& str,
                                           const std::string& cate,
                                           std::vector<std::string>* features) const {
  features->clear();
  if (0 == type) {
    if (cate != "未分类") {
      features->push_back(base::StringPrintf("title_cate:%s#%s", str.c_str(), cate.c_str()));
    } else {
      features->push_back(base::StringPrintf("title_ngram:%s", str.c_str()));
    }
  } else {
    if (cate != "未分类") {
      features->push_back(base::StringPrintf("content_cate:%s#%s", str.c_str(), cate.c_str()));
    } else {
      features->push_back(base::StringPrintf("content_ngram:%s", str.c_str()));
    }
  }
}

// type 0: title, tpye 1: content
void LowQualityHit::GenerateDirtyHitFeaure(int type,
                                           const std::string& str,
                                           const std::string& cate,
                                           const std::string& media,
                                           std::vector<std::string>* features) const {
  features->clear();
  if (0 == type) {
    if (cate == "未分类") {
      features->push_back(base::StringPrintf("title_ngram:%s", str.c_str()));
      if (media != "other_media") {
        features->push_back(base::StringPrintf("title_media:%s#%s", str.c_str(), media.c_str()));
      }
    } else {
      features->push_back(base::StringPrintf("title_cate:%s#%s", str.c_str(), cate.c_str()));
      if (media != "other_media") {
        features->push_back(base::StringPrintf("title_media:%s#%s", str.c_str(), media.c_str()));
      } else {
        features->push_back(base::StringPrintf("title_ngram:%s", str.c_str()));
      }
    }
  } else {
    if (cate == "未分类") {
      features->push_back(base::StringPrintf("content_ngram:%s", str.c_str()));
      if (media != "other_media") {
        features->push_back(base::StringPrintf("content_media:%s#%s", str.c_str(), media.c_str()));
      }
    } else {
      features->push_back(base::StringPrintf("content_cate:%s#%s", str.c_str(), cate.c_str()));
      if (media != "other_media") {
        features->push_back(base::StringPrintf("content_media:%s#%s", str.c_str(), media.c_str()));
      } else {
        features->push_back(base::StringPrintf("content_ngram:%s", str.c_str()));
      }
    }
  }
}


void LowQualityHit::MatchAdverRule(int type, int input_type,
                                   const std::vector<std::string>* terms,
                                   const std::string& line,
                                   std::unordered_set<std::string>* hit_terms) const {
  std::vector<int> values;
  std::vector<std::string> matches;
  if (0 == input_type) {
    std::vector<base::Slice> term_matches;
    nlp::util::ForwardMaxMatch(*adver_rules_, line, &term_matches, &values);
    for (int i = 0; i < (int)term_matches.size(); ++i) {
      matches.push_back(term_matches[i].as_string());
    }
  } else {
    if (terms == NULL) return;
    std::vector<std::pair<int, int> > term_matches;
    std::vector<base::Slice> slice_terms;
    for (int i = 0; i < (int)terms->size(); ++i) {
      slice_terms.push_back(base::Slice(terms->at(i)));
    }
    nlp::util::ForwardMaxMatch(*adver_rules_, slice_terms, &term_matches, &values);
    std::string current_match;
    for (int i = 0; i < (int)term_matches.size(); ++i) {
      current_match.clear();
      int start = term_matches[i].first;
      int end = term_matches[i].second;
      while (start < end) {
        current_match += terms->at(start);
        ++start;
      }
      matches.push_back(current_match);
    }
  }
  int pos = 0;
  std::vector<std::string> features;
  std::string num_or_id;
  for (int i = 0; i < (int)values.size(); ++i) {
    if (values[i] == kTitleCandidate && type == 1) continue;
    if (values[i] == kAdverPhone) {
      int length = 0;
      if (i > 0) length = matches[i - 1].size();
      pos = line.find(matches[i], pos + length) + matches[i].size();
      int end = pos + 15;
      int start = pos - matches[i].size() - 15;
      if (start < 0) start = 0;
      if (end >= (int)line.size()) end = line.size();
      num_or_id.clear();
      if (has_phone_number(line, start, end, &num_or_id)) {
        hit_terms->insert(base::StringPrintf("%s_hit_number", matches[i].c_str()));
      }
    } else if (values[i] == kAdverID) {
      int length = 0;
      if (i > 0) length = matches[i - 1].size();
      pos = line.find(matches[i], pos + length) + matches[i].size();
      int start = pos - matches[i].size() - 15;
      if (start < 0) start = 0;
      int end = pos + 15;
      if (end >= (int)line.size()) end = line.size();
      num_or_id.clear();
      if (has_id(line, start, end, &num_or_id)) {
        hit_terms->insert(base::StringPrintf("%s_hit_id", matches[i].c_str()));
      }
    } else {
      hit_terms->insert(matches[i]);
    }
  }
}

void LowQualityHit::MatchAdverFeatures(int type, const std::string& cate,
                                       std::unordered_set<std::string>* features) const {
  std::unordered_set<std::string> temp;
  std::unordered_set<std::string> hit_model_candidates;
  std::vector<std::string> temp_features;
  if (0 == type) {
    hit_model_candidates.clear();
    temp.clear();
    MatchAdverRule(type, 1, &title_basic_terms, nospace_title, &temp);
    features->insert(base::StringPrintf("TitleAdverRuleNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("TitleAdverRuleFeature_%s", it->c_str()));
      GenerateAdverHitFeaure(type, *it, cate, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    temp.clear();
    DetectWithDict(*adver_keywords_, title_basic_terms, nospace_title, &temp);
    features->insert(base::StringPrintf("TitleAdverKeywordNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("TitleAdverKeywordFeature_%s", it->c_str()));
      GenerateAdverHitFeaure(type, *it, cate, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    for (int i = 0; i < (int)ngrams.size(); ++i) {
      if (ngrams[i].second != 0) continue;
      GenerateAdverHitFeaure(type, ngrams[i].first, cate, &temp_features);
      for (int j = 0; j < (int)temp_features.size(); ++j) {
        hit_model_candidates.insert(temp_features[j]);
      }
    }
    for (auto it = hit_model_candidates.begin(); it != hit_model_candidates.end(); ++it) {
      uint64 sign = base::CalcTermSign(it->data(), it->size());
      auto current_it = adver_model_->find(sign);
      if (current_it == adver_model_->end()) continue;
      features->insert(base::StringPrintf("AdverModelFeature_%s", it->c_str()));
    }
  } else {
    hit_model_candidates.clear();
    temp.clear();
    MatchAdverRule(type, 1, &content_basic_terms, nospace_content, &temp);
    features->insert(base::StringPrintf("ContentAdverRuleNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("ContentAdverRuleFeature_%s", it->c_str()));
      GenerateAdverHitFeaure(type, *it, cate, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    temp.clear();
    MatchAdverRule(type, 1, &image_desc_basic_terms, image_desc, &temp);
    features->insert(base::StringPrintf("ImageDescAdverRuleNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("ImageDescAdverRuleFeature_%s", it->c_str()));
      GenerateAdverHitFeaure(type, *it, cate, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    temp.clear();
    DetectWithDict(*adver_keywords_, content_basic_terms, nospace_content, &temp);
    features->insert(base::StringPrintf("ContentAdverKeywordNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("ContentAdverKeywordFeature_%s", it->c_str()));
      GenerateAdverHitFeaure(type, *it, cate, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    temp.clear();
    DetectWithDict(*adver_keywords_, image_desc_basic_terms, image_desc, &temp);
    features->insert(base::StringPrintf("ImageDescAdverKeywordNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("ImageDescAdverKeywordFeature_%s", it->c_str()));
      GenerateAdverHitFeaure(type, *it, cate, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    temp.clear();
    DetectWithDict(*adver_impurity_keywords_, content_basic_terms, nospace_content, &temp);
    features->insert(base::StringPrintf("ContentAdverImpurityKeywordNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("ContentAdverImpurityKeywordFeature_%s", it->c_str()));
      GenerateAdverHitFeaure(type, *it, cate, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    temp.clear();
    DetectWithDict(*adver_impurity_keywords_, image_desc_basic_terms, image_desc, &temp);
    features->insert(base::StringPrintf("ImageDescAdverImpurityKeywordNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("ImageDescAdverImpurityKeywordFeature_%s", it->c_str()));
      GenerateAdverHitFeaure(type, *it, cate, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    for (int i = 0; i < (int)ngrams.size(); ++i) {
      if (ngrams[i].second != 1) continue;
      GenerateAdverHitFeaure(type, ngrams[i].first, cate, &temp_features);
      for (int j = 0; j < (int)temp_features.size(); ++j) {
        hit_model_candidates.insert(temp_features[j]);
      }
    }
    for (auto it = hit_model_candidates.begin(); it != hit_model_candidates.end(); ++it) {
      uint64 sign = base::CalcTermSign(it->data(), it->size());
      auto current_it = adver_model_->find(sign);
      if (current_it == adver_model_->end()) continue;
      features->insert(base::StringPrintf("AdverModelFeature_%s", it->c_str()));
    }
  }
}

void LowQualityHit::MatchDirtyFeatures(int type,
                                       bool is_video,
                                       const std::string& media,
                                       const std::string& cate,
                                       std::unordered_set<std::string>* features) const {
  std::unordered_set<std::string> temp;
  std::unordered_set<std::string> hit_model_candidates;
  std::vector<std::string> temp_features;
  if (0 == type) {
    if (!is_video) {
      DetectWithDict(*dirty_rules_, title_basic_terms, nospace_title, &temp);
    } else {
      DetectWithDict(*video_dirty_rules_, title_basic_terms, nospace_title, &temp);
    }
    features->insert(base::StringPrintf("TitleDirtyRuleNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("TitleDirtyRuleFeature_%s", it->c_str()));
      GenerateDirtyHitFeaure(type, *it, cate, media, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    temp.clear();
    if (!is_video) {
      DetectWithDict(*dirty_keywords_, title_basic_terms, nospace_title, &temp);
    } else {
      DetectWithDict(*video_dirty_keywords_, title_basic_terms, nospace_title, &temp);
    }
    features->insert(base::StringPrintf("TitleDirtyKeywordNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("TitleDirtyKeywordFeature_%s", it->c_str()));
      GenerateDirtyHitFeaure(type, *it, cate, media, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    for (int i = 0; i < (int)ngrams.size(); ++i) {
      if (ngrams[i].second != type || ngrams[i].first.find("#") == std::string::npos) continue;
      GenerateDirtyHitFeaure(type, ngrams[i].first, cate, media, &temp_features);
      for (int j = 0; j < (int)temp_features.size(); ++j) {
        hit_model_candidates.insert(temp_features[j]);
      }
    }
    for (auto it = hit_model_candidates.begin(); it != hit_model_candidates.end(); ++it) {
      uint64 sign = base::CalcTermSign(it->data(), it->size());
      auto current_it = dirty_model_->find(sign);
      if (current_it == dirty_model_->end()) continue;
      features->insert(base::StringPrintf("DirtyModelFeature_%s", it->c_str()));
    }
  } else {
    DetectWithDict(*dirty_rules_, content_basic_terms, nospace_content, &temp);
    features->insert(base::StringPrintf("ContentDirtyRuleNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("ContentDirtyRuleFeature_%s", it->c_str()));
      GenerateDirtyHitFeaure(type, *it, cate, media, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    temp.clear();
    DetectWithDict(*dirty_rules_, image_desc_basic_terms, image_desc, &temp);
    features->insert(base::StringPrintf("ImageDescDirtyRuleNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("ImageDescDirtyRuleFeature_%s", it->c_str()));
      GenerateDirtyHitFeaure(type, *it, cate, media, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    temp.clear();
    DetectWithDict(*dirty_keywords_, content_basic_terms, nospace_content, &temp);
    features->insert(base::StringPrintf("ContentDirtyKeywordNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("ContentDirtyKeywordFeature_%s", it->c_str()));
      GenerateDirtyHitFeaure(type, *it, cate, media, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    temp.clear();
    DetectWithDict(*dirty_keywords_, image_desc_basic_terms, image_desc, &temp);
    features->insert(base::StringPrintf("ImageDescDirtyKeywordNum_%d", (int)temp.size()));
    for (auto it = temp.begin(); it != temp.end(); ++it) {
      features->insert(base::StringPrintf("ImageDescDirtyKeywordFeature_%s", it->c_str()));
      GenerateDirtyHitFeaure(type, *it, cate, media, &temp_features);
      for (int i = 0; i < (int)temp_features.size(); ++i) {
        hit_model_candidates.insert(temp_features[i]);
      }
    }
    for (int i = 0; i < (int)ngrams.size(); ++i) {
      if (ngrams[i].second != type || ngrams[i].first.find("#") == std::string::npos) continue;
      GenerateDirtyHitFeaure(type, ngrams[i].first, cate, media, &temp_features);
      for (int j = 0; j < (int)temp_features.size(); ++j) {
        hit_model_candidates.insert(temp_features[j]);
      }
    }
    for (auto it = hit_model_candidates.begin(); it != hit_model_candidates.end(); ++it) {
      uint64 sign = base::CalcTermSign(it->data(), it->size());
      auto current_it = dirty_model_->find(sign);
      if (current_it == dirty_model_->end()) continue;
      features->insert(base::StringPrintf("DirtyModelFeature_%s", it->c_str()));
    }
  }
}

void LowQualityHit::MatchBluffingFeatures(std::unordered_set<std::string>* features) const {
  std::unordered_set<std::string> temp;
  DetectLineWithDict(*bluffing_rules_, nospace_title, &temp);
  features->insert(base::StringPrintf("BluffingRuleNum_%d", (int)temp.size()));
  for (auto it = temp.begin(); it != temp.end(); ++it) {
    features->insert(base::StringPrintf("TitleBluffingRuleFeature_%s", it->c_str()));
  }
  temp.clear();
  DetectLineWithDict(*bluffing_keywords_, nospace_title, &temp);
  features->insert(base::StringPrintf("BluffingKeywordNum_%d", (int)temp.size()));
  for (auto it = temp.begin(); it != temp.end(); ++it) {
    features->insert(base::StringPrintf("TitleBluffingKeywordFeature_%s", it->c_str()));
  }
}

bool LowQualityHit::ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
  bool is_video = (item_->identity().type() == reco::kPureVideo);
  // 获取各种词表
  if (is_video) {
    video_dirty_rules_ = GlobalDataIns::instance().GetVideoDirtyRules().get();
    video_dirty_keywords_ = GlobalDataIns::instance().GetVideoDirtyKeywords().get();
  } else {
    adver_rules_ = GlobalDataIns::instance().GetAdverRules().get();
    adver_keywords_ = GlobalDataIns::instance().GetAdverKeywords().get();
    adver_impurity_keywords_ = GlobalDataIns::instance().GetAdverImpurityKeywords().get();
    adver_model_ = GlobalDataIns::instance().GetAdverModel().get();
    bluffing_rules_ = GlobalDataIns::instance().GetBluffingRules().get();
    bluffing_keywords_ = GlobalDataIns::instance().GetBluffingKeywords().get();
    dirty_rules_ = GlobalDataIns::instance().GetDirtyRules().get();
    dirty_keywords_ = GlobalDataIns::instance().GetDirtyKeywords().get();
  }
  dirty_model_ = GlobalDataIns::instance().GetDirtyModel().get();
  stopwords_ = GlobalDataIns::instance().GetStopwords().get();

  nospace_content.clear();
  nospace_title.clear();
  image_desc.clear();
  title_basic_terms.clear();
  content_basic_terms.clear();
  image_desc_basic_terms.clear();
  ngrams.clear();

  std::string norm_line;
  RemoveHtmlTag(item_->content(), &norm_line);
  nlp::util::NormalizeLineInPlaceS(&norm_line);
  base::RemoveChars(norm_line, base::kWhitespace, &nospace_content);
  RemoveHtmlTag(item_->title(), &norm_line);
  nlp::util::NormalizeLineInPlaceS(&norm_line);
  base::RemoveChars(norm_line, base::kWhitespace, &nospace_title);

  if (!is_video) {
    std::string nospace_line;
    for (int i = 0; i < (int)item_->image_size(); ++i) {
      norm_line.clear();
      if (item_->image(i).has_desc()) {
        nlp::util::NormalizeLineCopy(item_->image(i).desc(), &norm_line);
        base::RemoveChars(norm_line, base::kWhitespace, &nospace_line);
        image_desc.append(norm_line.data(), norm_line.size());
        image_desc.append(",");
      }
    }
  }

  // 抽取各种命中的特征: 各种关键词, 各种规则以及模型
  ProcessLine(0, nospace_title, &title_basic_terms, &ngrams);
  if (!is_video) {
    ProcessLine(1, nospace_content, &content_basic_terms, &ngrams);
    ProcessLine(1, image_desc, &image_desc_basic_terms, &ngrams);
  }

  // 计算 title 中各种符号及其出现的位置 (start, middle, end)
  if (!is_video) {
    std::string key;
    std::unordered_map<std::string, int> punctuation_count;
    for (int i = 0; i < (int)nospace_title.size(); ++i) {
      std::string place = "middle";
      if (i == 0) {
        place = "start";
      } else if (i == (int)nospace_title.size() - 1) {
        place = "end";
      }
      if (nospace_title.at(i) == '?' || nospace_title.at(i) == '!' ||
          nospace_title.at(i) == '{' || nospace_title.at(i) == '}' ||
          nospace_title.at(i) == '~' || nospace_title.at(i) == '*') {
        key = base::StringPrintf("%c_%s", nospace_title.at(i), place.c_str());
        if (punctuation_count.find(key) == punctuation_count.end()) {
          punctuation_count.insert(std::make_pair(key, 1));
        } else {
          punctuation_count.find(key)->second += 1;
        }
      }
    }
    for (auto it = punctuation_count.begin(); it != punctuation_count.end(); ++it) {
      fea_parts->push_back(base::StringPrintf("TitlePunctuation_%s_%d", it->first.c_str(), it->second));
    }
  }
  std::string cate = "未分类";
  if (item_->category_size() > 0) cate = item_->category(0);
  std::string media = "other_media";
  if (item_->has_source_media()) {
    nlp::util::NormalizeLineCopy(item_->source_media(), &media);
  }

  std::unordered_set<std::string> features;
  if (!is_video) {
    MatchAdverFeatures(0, cate, &features);
    MatchAdverFeatures(1, cate, &features);
    MatchBluffingFeatures(&features);
    MatchDirtyFeatures(1, false, media, cate, &features);
  }
  MatchDirtyFeatures(0, is_video, media, cate, &features);
  for (auto it = features.begin(); it != features.end(); ++it) {
    fea_parts->push_back(*it);
  }
  return true;
}
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
