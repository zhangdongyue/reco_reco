#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/ml/model/doc_server_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/common/item_util.h"
#include "reco/ml/common/io_util.h"

#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/feature/item/include.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_string(item_keeper_ips, "11.251.202.129", "item keeper");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");

DEFINE_string(item_id, "", "item id");
DEFINE_string(item_id_file, "", "item id file, one id per line");
DEFINE_string(item_dump_file, "", "dumped reco item file");

DEFINE_string(data, "../data", "");

namespace reco {
namespace ml {
class ItemFeatureExtractor : public BaseFeatureExtractor {
 public:
  ItemFeatureExtractor() {}
  virtual ~ItemFeatureExtractor() {}

  virtual void SetupFeatureLayout() {
    using namespace item_fea; // NOLINT
    ClearFeatureExtractors();

    std::set<std::string> dedup;

    AddFeature<TitleBigram>(&dedup, true);
    AddFeature<TitleSkipBigram>(&dedup, true);
    AddFeature<TitleTrigram>(&dedup, true);
    AddFeature<Media>(&dedup, true);
    AddFeature<ShowTag>(&dedup, true);
    AddFeature<TitleCoreTag>(&dedup, true);
    AddFeature<Category>(&dedup, true);
    AddFeature<PlsaTopic>(&dedup, true);
    AddFeature<CategoryPlsaTopic>(&dedup, true);
    AddFeature<Paragraph>(&dedup, true);
    AddFeature<Image>(&dedup, true);
    AddFeature<LowQualityHit>(&dedup, true);

    layout_done_ = true;
  }
};
}  // namespace ml
}  // namespace reco

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");

  reco::ml::GlobalDataIns::instance().Init();
  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }

  thread::BlockingQueue<reco::RecoItem*> item_queue;
  if (!FLAGS_item_dump_file.empty() && !item_id_list.empty()) {
    CHECK(false) << "item id or dump item file should chose just one";
  } else if (!FLAGS_item_dump_file.empty()) {
    reco::ml::LoadDumpProtoFile<reco::RecoItem>(FLAGS_item_dump_file, &item_queue);
  } else if (!item_id_list.empty()) {
    reco::ml::GetItemMultiThread(item_id_list, FLAGS_item_keeper_ips, FLAGS_item_keeper_port,
                                 4, &item_queue);
  } else {
    CHECK(false) << "no input item";
  }

  item_queue.Close();
  // item meta, fea literal
  reco::ml::BaseFeatureExtractor* extractor = new reco::ml::ItemFeatureExtractor();
  extractor->SetupFeatureLayout();
  std::vector<std::string> feas;
  std::vector<std::string> metas;
  while (!item_queue.Empty()) {
    reco::RecoItem* pitem = item_queue.Take();
    if (pitem == NULL) continue;

    scoped_ptr<reco::RecoItem> p(pitem);

    const reco::RecoItem& item = *pitem;
    if (0 == item.quality_attr().posterior_itemq()) {
      continue;
    }

    // feature
    feas.clear();
    extractor->ExtractItemFeature(item, &feas);
    if (feas.empty()) {
      continue;
    }
    // meta
    metas.clear();
    metas.push_back(base::Uint64ToString(item.identity().item_id()));
    metas.push_back(item.title());
    std::vector<std::string> category;
    reco::common::RepeatedToVector<std::string>(item.category(), &category);
    metas.push_back(base::JoinStrings(category, ","));
    std::string media;
    reco::ml::item_fea::Media::GetItemMedia(item, &media);
    metas.push_back(media);

    std::cout << base::JoinStrings(metas, "\t") << "\t" << base::JoinStrings(feas, "\t") << std::endl;
  }
  delete extractor;

  return 0;
}
