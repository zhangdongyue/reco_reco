#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"
#include "reco/bizc/common/item_util.h"

namespace reco {
namespace ml {
namespace item_fea {

class ShowTag : public BaseItemFeature {
 public:
  ShowTag() {}
  virtual ~ShowTag() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kShowTag";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (item_->show_tag_size() == 0) return false;

    for (int i = 0; i < item_->show_tag_size(); ++i) {
      std::string tag;
      if (reco::common::ExtractRealTag(*item_, item_->show_tag(i), &tag)) {
        fea_parts->push_back(tag);
      }
    }
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
