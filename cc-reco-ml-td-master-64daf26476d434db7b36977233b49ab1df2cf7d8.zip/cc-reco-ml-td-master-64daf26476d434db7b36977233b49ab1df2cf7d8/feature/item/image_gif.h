#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"
#include "nlp/common/nlp_util.h"
#include "base/math/discrete.h"

namespace reco {
namespace ml {
namespace item_fea {

class ImageGif : public BaseItemFeature {
 public:
  ImageGif() {}
  virtual ~ImageGif() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kImageGif";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    // 为了把 0 单独区分一个桶
    static const std::vector<double> gif_type_boundaries = {1, 3, 4, 6};
    int32 image_num = item_->image_size();
    int32 gif_image_num = 0;
    for (int32 idx = 0; idx < image_num; ++idx) {
      const reco::NewsImage& news_image = item_->image(idx);
      if (news_image.has_type() && news_image.type() == "gif") {
        ++gif_image_num;
      }
    }
    int gif_num_type = base::math::Discretize(gif_image_num, gif_type_boundaries);
    fea_parts->push_back("GifImgNumType_" + base::IntToString(gif_num_type));
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
