#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"
#include "nlp/common/nlp_util.h"
#include "base/math/discrete.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {
namespace item_fea {

class Image : public BaseItemFeature {
 public:
  Image() {}
  virtual ~Image() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kImage";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    // 为了把 0 单独区分一个桶
    static const std::vector<double> boundaries = {1, 3, 4, 6};
    int32 image_num = item_->image_size();
    int num_type = base::math::Discretize(image_num, boundaries);
    fea_parts->push_back("ImgNumType_" + base::IntToString(num_type));

    if (image_num == 0) {
      return true;
    }

    bool has_image_desc = false;
    for (int idx = 0; idx < item_->image_size(); ++idx) {
      const reco::NewsImage& news_image = item_->image(idx);
      if (news_image.has_desc() && news_image.desc().size() > 0) {
        has_image_desc = true;
        break;
      }
    }
    if (has_image_desc) {
      fea_parts->push_back("HasImgDesc");
    } else {
      fea_parts->push_back("HasNoImgDesc");
    }

    std::vector<std::string::size_type> positions;
    const std::string& content = item_->content();
    auto pos = content.find("\1", 0);
    while (pos != std::string::npos) {
      positions.push_back(pos);
      pos = content.find("\1", pos + 1);
    }
    int head_num = 0;
    int mid_num = 0;
    int tail_num = 0;
    int low_pos = content.size() / 3;
    int high_pos = 2 * low_pos;
    for (auto it = positions.begin(); it != positions.end(); ++it) {
      if (static_cast<int>(*it) < low_pos) {
        ++head_num;
      } else if (static_cast<int>(*it) > high_pos) {
        ++tail_num;
      } else {
        ++mid_num;
      }
    }

    int layout_type = -1;
    if (head_num > 0 && mid_num == 0 && tail_num == 0) {
      layout_type = 0;
    } else if (head_num == 0 && mid_num == 0 && tail_num > 0) {
      layout_type = 2;
    } else {
      layout_type = 1;
    }
    switch (layout_type) {
      case 0:
        fea_parts->push_back("ImgHeadLayout");
        break;
      case 1:
        fea_parts->push_back("ImgMixLayout");
        break;
      case 2:
        fea_parts->push_back("ImgTailLayout");
        break;
      default:
        break;
    }
    fea_parts->push_back(base::StringPrintf("ImgNumLayout_%d_%d",
                                            num_type, layout_type));
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
