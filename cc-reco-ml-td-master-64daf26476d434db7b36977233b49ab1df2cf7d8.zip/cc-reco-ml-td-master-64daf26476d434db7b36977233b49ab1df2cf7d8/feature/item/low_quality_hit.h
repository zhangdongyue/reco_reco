#pragma once
#include <string>
#include <utility>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include "reco/ml/feature/base/base_item_feature.h"
#include "reco/ml/feature/global_data/global_data.h"
#include "nlp/common/nlp_util.h"
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "nlp/time/time_recognizer.h"
#include "extend/regexp/re3/re3.h"

namespace reco {
namespace ml {
namespace item_fea {

class LowQualityHit: public BaseItemFeature {
 public:
  LowQualityHit() {
    segmenter_ = new nlp::segment::Segmenter;
    pos_tagger_ = new nlp::postag::PosTagger;
    ner_ = new nlp::ner::Ner;
    time_reco_ = new nlp::time::TimeRecognizer();
  }
  virtual ~LowQualityHit() {
    delete ner_;
    ner_ = NULL;
    delete pos_tagger_;
    pos_tagger_ = NULL;
    delete segmenter_;
    segmenter_ = NULL;
    delete time_reco_;
    time_reco_ = NULL;
  }

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kLowQualityHit";
    return name;
  }

  bool IsValidUnigram(const base::Slice& unigram);

  bool IsValidBigram(const base::Slice& term1, const base::Slice& term2);

  // result type 0: title, type 1: content & image desc
  void ProcessLine(int type, const std::string& line,
                   std::vector<std::string>* basic_ngrams,
                   std::vector<std::pair<std::string, int >>* result);

  void DetectWithDict(const dawgdic::Dictionary& dict,
                      const std::vector<std::string>& terms,
                      const std::string& sentence,
                      std::unordered_set<std::string>* hit_terms) const;

  void DetectLineWithDict(const dawgdic::Dictionary& dict,
                          const std::string& sentence,
                          std::unordered_set<std::string>* hit_terms) const;

  // type 0: title, type 1: content
  // input_type 0: 整句匹配
  // input_type 1: 切词结果匹配
  void MatchAdverRule(int type, int input_type,
                      const std::vector<std::string>* terms,
                      const std::string& line,
                      std::unordered_set<std::string>* hit_terms) const;

  // type 0: title, type 1: content 2: image desc
  void MatchAdverFeatures(int type, const std::string& cate,
                          std::unordered_set<std::string>* features) const;

  // type 0: title, type 1: content & image desc
  void MatchDirtyFeatures(int type,
                          bool is_video,
                          const std::string& media,
                          const std::string& cate,
                          std::unordered_set<std::string>* features) const;

  void MatchBluffingFeatures(std::unordered_set<std::string>* features) const;

  // type 0: title, tpye 1: content
  void GenerateAdverHitFeaure(int type,
                              const std::string& str,
                              const std::string& cate,
                              std::vector<std::string>* features) const;

  // type 0: title, tpye 1: content
  void GenerateDirtyHitFeaure(int type,
                              const std::string& str,
                              const std::string& cate,
                              const std::string& media,
                              std::vector<std::string>* features) const;
 public:
  // 需要被外部 (如 bad item 模块) 使用的变量
  std::string nospace_content;
  std::string nospace_title;
  std::string image_desc;

  std::vector<std::string> title_basic_terms;
  std::vector<std::string> content_basic_terms;
  std::vector<std::string> image_desc_basic_terms;
  std::vector<std::pair<std::string, int >> ngrams;

 protected:
  nlp::segment::Segmenter* segmenter_;
  nlp::postag::PosTagger* pos_tagger_;
  nlp::ner::Ner* ner_;
  nlp::time::TimeRecognizer* time_reco_;
  // 各种需要匹配的词表
  const std::unordered_set<std::string>* stopwords_;
  const dawgdic::Dictionary* adver_rules_;
  const dawgdic::Dictionary* adver_keywords_;
  const dawgdic::Dictionary* adver_impurity_keywords_;
  const std::unordered_map<uint64, double>* adver_model_;
  const dawgdic::Dictionary* bluffing_rules_;
  const dawgdic::Dictionary* bluffing_keywords_;
  const dawgdic::Dictionary* dirty_rules_;
  const dawgdic::Dictionary* dirty_keywords_;
  const dawgdic::Dictionary* video_dirty_rules_;
  const dawgdic::Dictionary* video_dirty_keywords_;
  const std::unordered_map<uint64, double>* dirty_model_;

  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts);
};
// adver rule type
enum AdverRuleType {
  kAdverPhone = 0,
  kAdverID = 1,
  kTitleCandidate = 2,
};

inline void RemoveHtmlTag(const std::string& old_string, std::string* new_string) {
  // 处理掉各种 http tag
  //  比如<!--IMG#0-->   <p> <!--VIDEO#0--> <!--IMG#0--> 等内容
  CHECK_NOTNULL(new_string);
  *new_string = old_string;
  extend::re3::Re3::GlobalReplace(new_string, "<[[:ascii:]]+>", " ");
}
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
