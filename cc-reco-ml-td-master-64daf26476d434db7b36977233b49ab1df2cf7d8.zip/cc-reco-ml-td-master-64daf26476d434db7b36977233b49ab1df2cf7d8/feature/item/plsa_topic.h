#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"

namespace reco {
namespace ml {
namespace item_fea {

class PlsaTopic : public BaseItemFeature {
 public:
  PlsaTopic() {}
  virtual ~PlsaTopic() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kPlsaTopic";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!item_->has_topic()) return false;

    const reco::FeatureVector& v = item_->topic();
    for (int i = 0; i < v.feature_size(); ++i) {
      fea_parts->push_back(v.feature(i).literal());
      // 只输出第一个 topic
      break;
    }
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
