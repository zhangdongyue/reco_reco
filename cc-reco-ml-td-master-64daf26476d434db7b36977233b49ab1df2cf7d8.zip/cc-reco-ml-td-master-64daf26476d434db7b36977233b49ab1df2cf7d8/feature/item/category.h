#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"

namespace reco {
namespace ml {
namespace item_fea {

class Category : public BaseItemFeature {
 public:
  Category() {}
  virtual ~Category() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kCategory";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (item_->category_size() == 0) return false;

    std::string cate;
    for (int i = 0; i < item_->category_size(); ++i) {
      if (!cate.empty()) cate += ",";
      cate += item_->category(i);
      fea_parts->push_back(cate);
    }
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
