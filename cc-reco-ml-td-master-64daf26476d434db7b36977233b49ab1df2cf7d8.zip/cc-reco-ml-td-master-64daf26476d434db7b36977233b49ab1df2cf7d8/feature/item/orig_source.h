#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"

namespace reco {
namespace ml {
namespace item_fea {

class OrigSource : public BaseItemFeature {
 public:
  OrigSource() {}
  virtual ~OrigSource() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kOrigSource";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!item_->has_orig_source() || item_->orig_source() == "Unknown") {
      return false;
    }

    fea_parts->push_back(item_->orig_source());

    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
