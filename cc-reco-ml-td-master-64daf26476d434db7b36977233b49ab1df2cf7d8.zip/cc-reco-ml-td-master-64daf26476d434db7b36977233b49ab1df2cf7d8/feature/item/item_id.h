#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {
namespace item_fea {

class ItemId : public BaseItemFeature {
 public:
  ItemId() {}
  virtual ~ItemId() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kItemId";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    fea_parts->push_back(base::Uint64ToString(item_->identity().item_id()));
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
