#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"

namespace reco {
namespace ml {
namespace item_fea {

// item 的一级类目
class TopCategory : public BaseItemFeature {
 public:
  TopCategory() {}
  virtual ~TopCategory() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kL1Category";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (item_->category_size() == 0) return false;
    std::string cate = item_->category(0);
    if (cate.empty()) return false;

    fea_parts->push_back(cate);
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
