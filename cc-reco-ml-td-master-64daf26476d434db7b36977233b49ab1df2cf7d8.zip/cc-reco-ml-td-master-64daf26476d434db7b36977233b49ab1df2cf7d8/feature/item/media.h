#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"

namespace reco {
namespace ml {
namespace item_fea {

class Media : public BaseItemFeature {
 public:
  Media() {}
  virtual ~Media() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kMedia";
    return name;
  }

  static void GetItemMedia(const RecoItem& item, std::string* media) {
    // items.put(Integer.valueOf(0), "未确定");
    // items.put(Integer.valueOf(1), "机构媒体");
    // items.put(Integer.valueOf(2), "自媒体平台");
    // items.put(Integer.valueOf(3), "自媒体人");
    *media = "";
    std::string src_media = item.has_source_media() ? item.source_media() : "";
    int src_media_type = item.has_source_media_type() ? item.source_media_type() : -1;

    std::string orig_src_media = item.has_orig_source_media() ? item.orig_source_media() : "";

    // orig source media 不为空肯定使用
    if (!orig_src_media.empty()) {
      *media = orig_src_media;
      return;
    }

    std::string orig_src;
    if (item.has_orig_source() && item.orig_source() != "Unknown") {
      orig_src = item.orig_source();
    }

    if (!src_media.empty()) {
      if (src_media == "今日头条" || src_media == "天天快报" || src_media_type == 2) {
        // 自媒体平台，不作为媒体; 此时如果 orig source 不为空, 则用 orig_source
        if (!orig_src.empty()) {
          *media = orig_src;
          return;
        }
      } else {
        *media = src_media;
      }
    }
  }
 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    std::string media;
    Media::GetItemMedia(*item_, &media);
    if (!media.empty()) {
      fea_parts->push_back(media);
    } else {
      return false;
    }
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
