#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"
#include "base/strings/utf_char_iterator.h"

namespace reco {
namespace ml {
namespace item_fea {

class TitleTrigram : public BaseItemFeature {
 public:
  TitleTrigram() {}
  virtual ~TitleTrigram() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kTitleTrigram";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (item_->title_unigram_size() < 3) return false;
    for (int i = 0; i < item_->title_unigram_size() - 2; ++i) {
      const std::string& lhs = item_->title_unigram(i);
      const std::string& mhs = item_->title_unigram(i + 1);
      const std::string& rhs = item_->title_unigram(i + 2);
      if (IsBlackGram(lhs) || IsBlackGram(mhs) || IsBlackGram(rhs)) {
        continue;
      }

      int len_l = 0;
      int len_m = 0;
      int len_r = 0;
      if (!base::GetUTF8CharNum(lhs, &len_l)
          || !base::GetUTF8CharNum(mhs, &len_m)
          || !base::GetUTF8CharNum(rhs, &len_r)) {
        continue;
      }
      if (len_l == 1 && len_m == 1 && len_r == 1) {
        // 过滤都是单字组成的 ngram
        continue;
      }
      fea_parts->push_back(lhs + "_" + mhs + "_" + rhs);
    }
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
