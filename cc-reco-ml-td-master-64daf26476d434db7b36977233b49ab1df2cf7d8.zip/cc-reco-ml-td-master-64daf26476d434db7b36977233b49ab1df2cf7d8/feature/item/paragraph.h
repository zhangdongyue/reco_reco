#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"
#include "nlp/common/nlp_util.h"
#include "base/math/discrete.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {
namespace item_fea {

class Paragraph : public BaseItemFeature {
 public:
  Paragraph() {}
  virtual ~Paragraph() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kParagraph";
    return name;
  }

 public:
    static const int kMinParaLen = 10;
 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    static const std::vector<double> para_num_bounds = {6, 10, 17};
    static const std::vector<double> para_avelen_bounds = {52, 78, 113};
    static const std::vector<double> charnum_bounds = {354, 549, 775, 1089, 1683};
    std::string content = nlp::util::NormalizeMultiLines(item_->content());
    std::vector<std::string> paragraphs;
    std::string nospace_str;
    std::vector<std::string> tokens;
    base::SplitString(content, "\n", &paragraphs);
    int para_num = 0;
    int64 total_len = 0;
    for (size_t i = 0; i < paragraphs.size(); ++i) {
      std::string str;
      nlp::util::NormalizeLineInPlaceS(&paragraphs[i]);
      base::RemoveChars(paragraphs[i], base::kWhitespace, &str);
      int length = 0;
      if (base::GetUTF8CharNum(str, &length) && length >= kMinParaLen) {
        ++para_num;
        total_len += length;
      }
    }

    if (para_num == 0) {
      return false;
    }

    fea_parts->push_back(
        "ParaNum_" + base::IntToString(base::math::Discretize(para_num, para_num_bounds)));
    fea_parts->push_back(
        "ParaAveLen_" + base::IntToString(base::math::Discretize(total_len / para_num, para_avelen_bounds)));
    fea_parts->push_back(
        "CharLen_" + base::IntToString(base::math::Discretize(total_len, charnum_bounds)));

    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
