#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"
#include "reco/bizc/common/item_util.h"

namespace reco {
namespace ml {
namespace item_fea {

class Tag : public BaseItemFeature {
 public:
  Tag() {}
  virtual ~Tag() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kTag";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!item_->has_tag()) return false;

    auto& tag = item_->tag();
    for (int i = 0; i < tag.feature_size(); ++i) {
      std::string real_tag;
      if (reco::common::ExtractRealTag(*item_, tag.feature(i).literal(), &real_tag)) {
        fea_parts->push_back(real_tag);
      }
    }

    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
