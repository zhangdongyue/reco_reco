#pragma once

#include <vector>
#include <string>
#include "reco/ml/feature/base/base_item_feature.h"
#include "base/strings/utf_char_iterator.h"

namespace reco {
namespace ml {
namespace item_fea {

class TitleUnigram : public BaseItemFeature {
 public:
  TitleUnigram() {}
  virtual ~TitleUnigram() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kTitleUnigram";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (item_->title_unigram_size() == 0) return false;
    for (int i = 0; i < item_->title_unigram_size(); ++i) {
      const std::string& gram = item_->title_unigram(i);
      if (IsBlackGram(gram)) continue;

      int len = 0;
      if (!base::GetUTF8CharNum(gram, &len)) {
        continue;
      }

      fea_parts->push_back(item_->title_unigram(i));
    }
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
