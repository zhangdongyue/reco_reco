#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"
#include "nlp/common/nlp_util.h"
#include "base/math/discrete.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {
namespace item_fea {

class ShortParagraph : public BaseItemFeature {
 public:
  ShortParagraph() {}
  virtual ~ShortParagraph() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kShortParagraph";
    return name;
  }

 public:
    static const int kShortParaLen = 80;
 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    static const std::vector<double> short_para_num_bounds = {6, 10, 17};
    int short_para_num = 0;
    std::string content = nlp::util::NormalizeMultiLines(item_->content());
    std::vector<std::string> paragraphs;
    base::SplitString(content, "\n", &paragraphs);
    for (size_t i = 0; i < paragraphs.size(); ++i) {
      std::string str;
      nlp::util::NormalizeLineInPlaceS(&paragraphs[i]);
      base::RemoveChars(paragraphs[i], base::kWhitespace, &str);
      int length = 0;
      if (base::GetUTF8CharNum(str, &length)) {
        if (length > 0 && length <= kShortParaLen) {
          ++short_para_num;
        }
      }
    }
    if (short_para_num == 0) {
      return false;
    }
    fea_parts->push_back(
        "ShortParaNum_" + base::IntToString(base::math::Discretize(short_para_num, short_para_num_bounds)));
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
