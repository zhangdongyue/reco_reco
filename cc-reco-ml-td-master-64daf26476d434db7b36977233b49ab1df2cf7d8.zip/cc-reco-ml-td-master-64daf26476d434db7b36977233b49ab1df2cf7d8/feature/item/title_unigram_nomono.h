#pragma once

#include <vector>
#include <string>
#include <cctype>
#include "reco/ml/feature/base/base_item_feature.h"

namespace reco {
namespace ml {
namespace item_fea {

class TitleUnigramNoMono : public BaseItemFeature {
 public:
  TitleUnigramNoMono() {}
  virtual ~TitleUnigramNoMono() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kTitleUnigramNoMono";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (item_->title_unigram_size() == 0) {
      return false;
    }

    for (int i = 0; i < item_->title_unigram_size(); ++i) {
      auto& unigram = item_->title_unigram(i);
      if (unigram.size() > 3) {
        fea_parts->push_back(unigram);
      } else if (unigram.size() > 1 && (isdigit(unigram[0]) || isalpha(unigram[0]))) {
        fea_parts->push_back(unigram);
      }
    }

    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
