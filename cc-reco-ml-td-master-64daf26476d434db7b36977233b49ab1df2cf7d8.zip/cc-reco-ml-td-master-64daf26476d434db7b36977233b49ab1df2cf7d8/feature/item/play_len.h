#pragma once
#include <string>
#include <vector>

#include "reco/ml/feature/base/base_item_feature.h"
#include "reco/bizc/common/item_util.h"

namespace reco {
namespace ml {
namespace item_fea {

class PlayLen : public BaseItemFeature {
 public:
  PlayLen() {}
  virtual ~PlayLen() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kPlayLen";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (item_->video_meta_settings_size() == 0) {
      return false;
    }

    for (int i = 0; i < item_->video_meta_settings_size(); ++i) {
      if (item_->video_meta_settings(i).has_play_length()) {
        int32 play_len = item_->video_meta_settings(i).play_length();
        if (play_len < 60) {
          fea_parts->push_back("playlen_1");
        } else if (play_len < 180) {
          fea_parts->push_back("playlen_3");
        } else if (play_len < 300) {
          fea_parts->push_back("playlen_5");
        } else {
          fea_parts->push_back("playlen_max");
        }

        break;
      }
    }

    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
