#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"

namespace reco {
namespace ml {
namespace item_fea {

class CategoryPlsaTopic : public BaseItemFeature {
 public:
  CategoryPlsaTopic() {}
  virtual ~CategoryPlsaTopic() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kCategoryPlsaTopic";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (item_->category_size() == 0) return false;
    if (!item_->has_plsa_topic()) return false;
    const std::string& cate = item_->category(0);

    const reco::FeatureVector& v = item_->plsa_topic();
    for (int i = 0; i < v.feature_size(); ++i) {
      fea_parts->push_back(cate + "_" + v.feature(i).literal());
      // 只输出第一个 topic
      break;
    }
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
