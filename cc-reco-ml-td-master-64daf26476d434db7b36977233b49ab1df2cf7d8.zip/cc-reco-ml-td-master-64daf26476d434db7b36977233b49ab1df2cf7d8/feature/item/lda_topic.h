#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_item_feature.h"

namespace reco {
namespace ml {
namespace item_fea {

class LdaTopic : public BaseItemFeature {
 public:
  LdaTopic() {}
  virtual ~LdaTopic() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kLdaTopic";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!item_->has_title_lda()) return false;

    const reco::FeatureVector& v = item_->title_lda();
    for (int i = 0; i < v.feature_size() && i < 3; ++i) {
      fea_parts->push_back(v.feature(i).literal());
    }
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
