#pragma once
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include "reco/ml/feature/base/base_item_feature.h"
#include "reco/ml/feature/global_data/global_data.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "extend/simhash/simhash.h"

namespace reco {
namespace ml {
namespace item_fea {

class ImageAdver: public BaseItemFeature {
 public:
  ImageAdver() {}
  virtual ~ImageAdver() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kImageAdver";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    const std::unordered_map<std::string, int>* bad_image_hashes = GlobalDataIns::instance().GetLowQualityImageHashs().get(); // NOLINT
    CHECK_NOTNULL(bad_image_hashes);
    std::unordered_set<int64> adver_image_hashes;
    for (auto it = bad_image_hashes->begin(); it != bad_image_hashes->end(); ++it) {
      if (it->second != 0) continue;
      int64 sign = 0;
      if (base::StringToInt64(it->first, &sign)) adver_image_hashes.insert(sign);
    }
    int32 image_num = item_->image_size();
    bool has_adver_image = false;
    bool has_qrcode_image = false;
    for (int32 idx = 0; idx < image_num; ++idx) {
      if (!has_qrcode_image && item_->image(idx).is_qrcode()) has_qrcode_image = true;
      if (!item_->image(idx).has_simhash()) continue;
      for (auto it = adver_image_hashes.begin(); it != adver_image_hashes.end(); ++it) {
        int distance = simhash::CharikarSimHash::HammingDistance(*it, item_->image(idx).simhash());
        if (distance < 10) {
          has_adver_image = true;
          break;
        }
      }
      if (has_adver_image) break;
    }
    fea_parts->push_back(base::StringPrintf("HasAdverImage_%d", has_adver_image));
    fea_parts->push_back(base::StringPrintf("HasQRCodeImage_%d", has_qrcode_image));
    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
