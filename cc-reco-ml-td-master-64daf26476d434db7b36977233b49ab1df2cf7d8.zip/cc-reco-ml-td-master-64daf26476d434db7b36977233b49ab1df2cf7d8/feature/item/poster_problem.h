#pragma once
#include <string>
#include <vector>

#include "reco/ml/feature/base/base_item_feature.h"
#include "reco/bizc/common/item_util.h"

namespace reco {
namespace ml {
namespace item_fea {

class PosterProblem : public BaseItemFeature {
 public:
  PosterProblem() {}
  virtual ~PosterProblem() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kPosterProblem";
    return name;
  }

 protected:
  virtual bool ExtractRecoItemFeatureImpl(std::vector<std::string>* fea_parts) {
    if (item_->video_meta_settings_size() == 0) return false;

    for (int i = 0; i < item_->video_meta_settings_size(); ++i) {
      auto &meta = item_->video_meta_settings(i);
      if (meta.has_poster_problem_info() && meta.poster_problem_info().has_is_black_edge() &&
          meta.poster_problem_info().is_black_edge()) {
        fea_parts->push_back("black_edge");
        break;
      }
    }

    return true;
  }
};
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
