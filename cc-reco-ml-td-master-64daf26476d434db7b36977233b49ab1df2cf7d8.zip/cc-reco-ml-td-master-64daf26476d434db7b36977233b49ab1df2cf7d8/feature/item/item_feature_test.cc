#include <string>
#include <limits>
#include <iostream>
#include <unordered_map>

#include "reco/ml/feature/item/include.h"

#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {
namespace item_fea {

class ItemFeatureTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    if (GlobalDataIns::instance().GetLowQualityImageHashs().get() == NULL) {
      GlobalDataIns::instance().Init();
    }
    // required fields
    item_.mutable_identity()->set_app_token("app");
    item_.mutable_identity()->set_item_id(1ul);
    item_.mutable_identity()->set_outer_id("1");
    item_.mutable_identity()->set_type(reco::kNews);

    item_.set_is_valid(true);
    base::Time now = base::Time::Now();
    now.ToStringInSeconds(item_.mutable_create_time());
    item_.set_title("title");
    item_.set_content("this is content");
    item_.set_source("source");

    // diy fields
    item_.add_title_unigram("term1");
    item_.add_title_unigram("term2");
    item_.add_title_unigram("term3");
    item_.add_title_unigram("term4");
    item_.add_title_unigram("term5");

    item_.set_source_media("source_media");
    item_.set_orig_source_media("orig_source_media");

    item_.set_normalized_title("tag1,tag2,synon");
    item_.add_show_tag("abc:tag1");
    item_.add_show_tag(":tag2");
    item_.add_show_tag(":tag3:4");
    item_.add_synonymous_tags("synon");

    item_.add_category("cate1");
    item_.add_category("cate2");

    FeatureVector fea_vec;
    Feature fea;
    fea.set_literal("topic1");
    fea.set_weight(1.0f);
    fea_vec.add_feature()->CopyFrom(fea);
    fea_vec.set_norm(1.0);
    item_.mutable_topic()->CopyFrom(fea_vec);
    item_.mutable_plsa_topic()->CopyFrom(fea_vec);
  }

  virtual void TearDown() {
    delete feature_;
  }

  BaseItemFeature* feature_;
  reco::RecoItem item_;
};

TEST_F(ItemFeatureTest, ItemId) {
  feature_ = new ItemId();
  feature_->SetRecoItem(item_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "1");
}

TEST_F(ItemFeatureTest, TitleUnigram) {
  feature_ = new TitleUnigram();
  feature_->SetRecoItem(item_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 5);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "term1");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "term2");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "term3");
  ASSERT_STREQ(feature_->GetFeature(3).c_str(), "term4");
  ASSERT_STREQ(feature_->GetFeature(4).c_str(), "term5");
}

TEST_F(ItemFeatureTest, TitleBigram) {
  feature_ = new TitleBigram();
  feature_->SetRecoItem(item_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 4);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "term1_term2");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "term2_term3");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "term3_term4");
  ASSERT_STREQ(feature_->GetFeature(3).c_str(), "term4_term5");
}

TEST_F(ItemFeatureTest, TitleSkipBigram) {
  feature_ = new TitleSkipBigram();
  feature_->SetRecoItem(item_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 3);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "term1_term3");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "term2_term4");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "term3_term5");
}

TEST_F(ItemFeatureTest, TitleTrigram) {
  feature_ = new TitleTrigram();
  feature_->SetRecoItem(item_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 3);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "term1_term2_term3");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "term2_term3_term4");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "term3_term4_term5");
}

TEST_F(ItemFeatureTest, Meida) {
  feature_ = new Media();
  feature_->SetRecoItem(item_);

  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "orig_source_media");

  item_.clear_orig_source_media();
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "source_media");

  item_.clear_source_media();
  ASSERT_FALSE(feature_->ExtractFeature());
}

TEST_F(ItemFeatureTest, ShowTag) {
  feature_ = new ShowTag();
  feature_->SetRecoItem(item_);

  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 3);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "tag1");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "tag2");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "tag3:4");
}

TEST_F(ItemFeatureTest, TitleCoreTag) {
  feature_ = new TitleCoreTag();
  feature_->SetRecoItem(item_);

  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 3);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "tag1");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "tag2");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "synon");
}

TEST_F(ItemFeatureTest, Category) {
  feature_ = new Category();
  feature_->SetRecoItem(item_);

  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 2);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "cate1");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "cate1,cate2");
}

TEST_F(ItemFeatureTest, PlsaTopic) {
  feature_ = new PlsaTopic();
  feature_->SetRecoItem(item_);

  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "topic1");
}

TEST_F(ItemFeatureTest, CategoryPlsaTopic) {
  feature_ = new CategoryPlsaTopic();
  feature_->SetRecoItem(item_);

  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "cate1_topic1");
}

TEST_F(ItemFeatureTest, Paragraph) {
  feature_ = new Paragraph();
  feature_->SetRecoItem(item_);

  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 3);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "ParaNum_0");
  // 去掉空格算的长度
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "ParaAveLen_0");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "CharLen_0");

  std::string content;
  for (int p = 0; p < 10; ++p) {
    content += "\n";
    for (int i = 0; i < 40; ++i) {
      content += "我";
    }
    content += "\n";
  }
  item_.set_content(content);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 3);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "ParaNum_2");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "ParaAveLen_0");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "CharLen_1");
}

TEST_F(ItemFeatureTest, ShortParagraph) {
  feature_ = new ShortParagraph();
  feature_->SetRecoItem(item_);

  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "ShortParaNum_0");

  std::string content;
  for (int p = 0; p < 10; ++p) {
    content += "\n";
    for (int i = 0; i < 40; ++i) {
      content += "我";
    }
    content += "\n";
  }
  item_.set_content(content);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "ShortParaNum_2");
}


TEST_F(ItemFeatureTest, Image) {
  feature_ = new Image();
  feature_->SetRecoItem(item_);

  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "ImgNumType_0");

  reco::NewsImage image;
  image.set_url("ss");
  item_.add_image()->CopyFrom(image);
  item_.set_content(item_.content() + "\1");
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 4);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "ImgNumType_1");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "HasNoImgDesc");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "ImgTailLayout");
  ASSERT_STREQ(feature_->GetFeature(3).c_str(), "ImgNumLayout_1_2");
}

TEST_F(ItemFeatureTest, ImageGif) {
  feature_ = new ImageGif();
  feature_->SetRecoItem(item_);

  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);

  reco::NewsImage image;
  image.set_url("ss");
  image.set_type("gif");
  item_.add_image()->CopyFrom(image);
  item_.add_image()->CopyFrom(image);
  item_.set_content(item_.content() + "\1");
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "GifImgNumType_1");
}

TEST_F(ItemFeatureTest, ImageAdver) {
  feature_ = new ImageAdver();
  feature_->SetRecoItem(item_);

  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 2);

  reco::NewsImage image;
  image.set_url("ss");
  image.set_simhash(0);
  item_.add_image()->CopyFrom(image);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 2);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "HasAdverImage_0");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "HasQRCodeImage_0");

  image.set_simhash(6418939690144257718);
  item_.add_image()->CopyFrom(image);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 2);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "HasAdverImage_1");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "HasQRCodeImage_0");
}

TEST_F(ItemFeatureTest, Layout) {
  feature_ = new Layout();
  feature_->SetRecoItem(item_);
  ASSERT_FALSE(feature_->ExtractFeature());
  // ASSERT_EQ(feature_->GetFeatureSize(), 1);
  // ASSERT_STREQ(feature_->GetFeature(0).c_str(), "GifImgNumType_1");
}

TEST_F(ItemFeatureTest, LowQualityHit) {
  feature_ = new LowQualityHit();
  item_.set_title("大众娱乐网央视已经曝光，性骚扰合适才能停? 啪过之后才知道! 看了心酸!!!");
  item_.set_category(0, "社会");
  item_.set_source_media("uc自媒体");
  std::string content = "联系电话：123465535353, 最新福利咨询微信:mx28121sds, 为各业主抢盘!\n";
  content.append("第一章总则\n");
  content.append("定制女仆, 性工作者, 受美联储加息、缩表影响，世界各国货币政策纷纷转向收紧，目前尚只是开端阶段。中国身处美元的影响之下，货币政策也不得不随着大环境由宽松走向收紧。另外，国内抑制资产泡沫的需求也不得不让货币政策转向，没有回旋的余地。当前限购限贷政策已扩大到全国40余城，央行也在加紧回收资金。这将对楼市造成打击。\n"); // NOLINT
  content.append("[相关阅读]\n");
  item_.set_content(content);
  feature_->SetRecoItem(item_);
  ASSERT_TRUE(feature_->ExtractFeature());
  CHECK_EQ((int)feature_->GetFeatureSize(), 47);
  for (int i = 0; i < (int)feature_->GetFeatureSize(); ++i) {
    VLOG(1) << feature_->GetFeature(i);
  }
}
}  // namespace item_fea
}  // namespace ml
}  // namespace reco
