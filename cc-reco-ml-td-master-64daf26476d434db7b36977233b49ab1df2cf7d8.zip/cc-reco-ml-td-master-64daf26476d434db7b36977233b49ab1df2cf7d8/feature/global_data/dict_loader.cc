#include "reco/ml/feature/global_data/dict_loader.h"
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include "base/strings/string_printf.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/utf_string_conversions.h"
#include "base/hash_function/term.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "nlp/common/nlp_util.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"


namespace reco {
namespace ml {
void LoadAdverRuleFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  dawgdic::Dictionary* dict = new dawgdic::Dictionary();
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "read file error:" << file_path.value();
    return;
  }
  std::vector<std::string> fields;
  std::map<std::string, int> load_cache;
  for (auto it = lines.begin(); it != lines.end(); ++it) {
    fields.clear();
    base::SplitString(*it, "\t", &fields);
    CHECK_EQ((int)fields.size(), 2);
    nlp::util::NormalizeLineInPlaceS(&fields[0]);
    load_cache.insert(std::make_pair(fields[0], base::ParseIntOrDie(fields[1])));
  }
  dawgdic::DawgBuilder builder;
  for (auto it = load_cache.begin(); it != load_cache.end(); ++it) {
    CHECK(builder.Insert(it->first.c_str(), it->second));
  }
  dawgdic::Dawg dawg;
  builder.Finish(&dawg);
  CHECK(dawgdic::DictionaryBuilder::Build(dawg, dict));

  boost::shared_ptr<dawgdic::Dictionary> ptr(dict);
  reco::dm::DynamicDict<dawgdic::Dictionary>* dynamic_dict =
      reinterpret_cast<reco::dm::DynamicDict<dawgdic::Dictionary>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

void LoadLowQualityDawgDict(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "failed to open file: " << file_path.ToString();
    return;
  }

  dawgdic::Dictionary* dict = new dawgdic::Dictionary();

  std::vector<std::string> tokens;
  std::map<std::string, int> cache;
  std::string ngram;
  for (int i = 0; i < (int)lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    CHECK_GT((int)tokens.size(), 0);
    CHECK_LT((int)tokens.size(), 3);
    if ((int)tokens.size() == 1) {
      nlp::util::NormalizeLineInPlaceS(&tokens[0]);
      if (cache.find(tokens[0]) != cache.end()) {
        cache.find(tokens[0])->second = 2;
      } else {
        cache.insert(std::make_pair<std::string, int>(tokens[0].c_str(), 2));
      }
    } else {
      nlp::util::NormalizeLineInPlaceS(&tokens[0]);
      if (cache.find(tokens[0]) != cache.end()) {
        if (cache.find(tokens[0])->second == 1) cache.find(tokens[0])->second = 3;
        if (cache.find(tokens[0])->second == 2) cache.find(tokens[0])->second = 5;
        if (cache.find(tokens[0])->second == 4) cache.find(tokens[0])->second = 6;
      } else {
        cache.insert(std::make_pair(tokens[0], 0));
      }
      nlp::util::NormalizeLineInPlaceS(&tokens[1]);
      if (cache.find(tokens[1]) != cache.end()) {
        if (cache.find(tokens[1])->second == 0) cache.find(tokens[1])->second = 3;
        if (cache.find(tokens[1])->second == 2) cache.find(tokens[1])->second = 4;
        if (cache.find(tokens[1])->second == 5) cache.find(tokens[1])->second = 6;
      } else {
        cache.insert(std::make_pair(tokens[1], 1));
      }
      ngram = tokens[0] + tokens[1];
      nlp::util::NormalizeLineInPlaceS(&ngram);
      if (cache.find(ngram) != cache.end()) {
        cache.find(ngram)->second = 2;
      } else {
        cache.insert(std::make_pair<std::string, int>(ngram.c_str(), 2));
      }
    }
  }
  dawgdic::DawgBuilder builder;
  for (auto it = cache.begin(); it != cache.end(); ++it) {
    CHECK(builder.Insert(it->first.c_str(), it->second));
  }
  dawgdic::Dawg dawg;
  CHECK(builder.Finish(&dawg));
  dawgdic::DictionaryBuilder::Build(dawg, dict);

  boost::shared_ptr<dawgdic::Dictionary> ptr(dict);
  reco::dm::DynamicDict<dawgdic::Dictionary>* dynamic_dict =
      reinterpret_cast<reco::dm::DynamicDict<dawgdic::Dictionary>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

void LoadLowQualitySubRuleFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "failed to open file: " << file_path.ToString();
    return;
  }
  std::unordered_map<std::string, int>* dict = new std::unordered_map<std::string, int>();
  std::vector<std::string> tokens;
  std::string key;
  int type = 0;
  for (int i = 0; i < (int)lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    if ((int)tokens.size() > 3 || (int)tokens.size() < 2) {
      LOG(ERROR) << "error line:\t" << lines[i];
      continue;
    }
    base::StringToInt(tokens.back(), &type);
    if (tokens.size() == 2) {
      dict->insert(std::make_pair(tokens[0], type));
    } else {
      if (tokens[0] < tokens[1]) {
        key = base::StringPrintf("%s#%s", tokens[0].c_str(), tokens[1].c_str());
      } else {
        key = base::StringPrintf("%s#%s", tokens[1].c_str(), tokens[0].c_str());
      }
      dict->insert(std::make_pair(key, type));
    }
  }
  boost::shared_ptr<std::unordered_map<std::string, int> > ptr(dict);
  reco::dm::DynamicDict<std::unordered_map<std::string, int> >* dynamic_dict =
      reinterpret_cast<reco::dm::DynamicDict<std::unordered_map<std::string, int >>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}
}
}
