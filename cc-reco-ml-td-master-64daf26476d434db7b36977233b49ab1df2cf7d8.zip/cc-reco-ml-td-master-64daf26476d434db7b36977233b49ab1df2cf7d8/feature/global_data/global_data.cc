#include "reco/ml/feature/global_data/global_data.h"
#include "reco/ml/feature/global_data/dict_loader.h"

DEFINE_bool(ml_default_init, true, "默认初始化为true时,加载所有词典,为false时,由调用方自行加载词典,用于测试");  // NOLINT
DEFINE_string(ml_data_dir, "../data", "data dir");

namespace reco {
namespace ml {
const char* GlobalData::kStopwordFile = "stopword.txt";
const char* GlobalData::kAdverRuleFile = "advertorial_rule.txt";
const char* GlobalData::kAdverKeywordFile = "advertorial_keywords.txt";
const char* GlobalData::kAdverImpurityKeywordFile = "advertorial_impurity_keywords.txt";
const char* GlobalData::kAdverModelFile = "advertorial_model.txt";
const char* GlobalData::kBluffingRuleFile = "bluffing_rule.txt";
const char* GlobalData::kBluffingKeywordFile= "bluffing_keywords.txt";
const char* GlobalData::kDirtyRuleFile = "dirty_rule.txt";
const char* GlobalData::kDirtyKeywordFile = "dirty_keywords.txt";
const char* GlobalData::kDirtyModelFile = "dirty_model.txt";
const char* GlobalData::kVideoDirtyRuleFile = "video_quality_dirty_rule.txt";
const char* GlobalData::kVideoDirtyKeywordFile = "video_quality_dirty_keywords.txt";
const char* GlobalData::kLowQualityImageHashFile = "bad_image_hash.txt";

GlobalData::GlobalData() {}
GlobalData::~GlobalData() {}

void GlobalData::Init() {
  base::FilePath root_dir(FLAGS_ml_data_dir);

  // 加载低质词表
  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverRuleFile,
                            reco::ml::LoadAdverRuleFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kAdverImpurityKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_DICT(UnorderedMapUint64Double, kAdverModelFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kDirtyRuleFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kDirtyKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kVideoDirtyRuleFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kVideoDirtyKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_DICT(UnorderedMapUint64Double, kDirtyModelFile);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kBluffingRuleFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_CUSTOMER_DICT(dawgdic::Dictionary, kBluffingKeywordFile,
                            reco::ml::LoadLowQualityDawgDict);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedSetStr, kStopwordFile);

  DM_REGISTER_COMMON_NORMALIZED_DICT(UnorderedMapStrInt, kLowQualityImageHashFile);

  if (FLAGS_ml_default_init) {
    reco::dm::DictManagerSingleton::instance().LoadAllDicts();
  }
}
}
}
