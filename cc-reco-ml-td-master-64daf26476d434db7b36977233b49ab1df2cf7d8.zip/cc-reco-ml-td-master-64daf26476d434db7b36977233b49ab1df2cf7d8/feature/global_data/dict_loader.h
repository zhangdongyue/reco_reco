#pragma once
#include "base/file/file_path.h"
#include "base/common/basic_types.h"

namespace reco {
namespace ml {
// 用户自定义的加载词表方法
void LoadAdverRuleFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadLowQualityDawgDict(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
void LoadLowQualitySubRuleFile(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);
}
}
