#pragma once
#include <unordered_set>
#include <unordered_map>
#include <string>
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "reco/base/common/singleton.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "extend/static_dict/dawg/dictionary.h"

namespace reco {
namespace ml {

class GlobalData {
 public:
  GlobalData();
  ~GlobalData();

  void Init();

 public:
  boost::shared_ptr<const std::unordered_set<std::string> > GetStopwords() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr, kStopwordFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetAdverRules() {
    return DM_GET_DICT(dawgdic::Dictionary, kAdverRuleFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetAdverKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kAdverKeywordFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetAdverImpurityKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kAdverImpurityKeywordFile);
  }

  boost::shared_ptr<const std::unordered_map<uint64, double> > GetAdverModel() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapUint64Double, kAdverModelFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetBluffingRules() {
    return DM_GET_DICT(dawgdic::Dictionary, kBluffingRuleFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetBluffingKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kBluffingKeywordFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetDirtyRules() {
    return DM_GET_DICT(dawgdic::Dictionary, kDirtyRuleFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetDirtyKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kDirtyKeywordFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetVideoDirtyRules() {
    return DM_GET_DICT(dawgdic::Dictionary, kVideoDirtyRuleFile);
  }

  boost::shared_ptr<const dawgdic::Dictionary> GetVideoDirtyKeywords() {
    return DM_GET_DICT(dawgdic::Dictionary, kVideoDirtyKeywordFile);
  }

  boost::shared_ptr<const std::unordered_map<uint64, double> > GetDirtyModel() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapUint64Double, kDirtyModelFile);
  }

  boost::shared_ptr<const std::unordered_map<std::string, int> > GetLowQualityImageHashs() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrInt, kLowQualityImageHashFile);
  }


 private:
  // 低质相关词表
  static const char* kStopwordFile;
  static const char* kAdverRuleFile;
  static const char* kAdverKeywordFile;
  static const char* kAdverImpurityKeywordFile;
  static const char* kAdverModelFile;
  static const char* kBluffingRuleFile;
  static const char* kBluffingKeywordFile;
  static const char* kDirtyRuleFile;
  static const char* kDirtyKeywordFile;
  static const char* kVideoDirtyRuleFile;
  static const char* kVideoDirtyKeywordFile;
  static const char* kDirtyModelFile;
  static const char* kLowQualityImageHashFile;
};

typedef reco::common::singleton_default<GlobalData> GlobalDataIns;
}  // namespace ml
}  // namespace reco
