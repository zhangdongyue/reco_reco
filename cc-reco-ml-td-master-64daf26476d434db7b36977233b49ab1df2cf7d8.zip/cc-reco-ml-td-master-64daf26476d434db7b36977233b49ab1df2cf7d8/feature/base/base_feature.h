#pragma once
#include <string>
#include <vector>
#include <set>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/scene.pb.h"

namespace reco {
namespace ml {

/**
 * item 特征抽取基类,提供了特征抽取的共性部分
 * 用户基于这个类派生，实现其中的纯虚函数 GetFeatureName() ExtractRecoItemFeatureImpl()
 *
 * NOTE: 几个关键注意点一定要看
 * 1. 只需要实现单边特征，组合特征有模版类 DualCombineFeature 来搞定
 *    具体请看 dual_combine_feature.h
 * 2. 特征数据存储在 feas_ 成员中，只存特征本身，不要存类似前缀、分隔符之类的。
 *    比如有一个标题的 term： a b c， 那么 feas_ 里存的就是 a b c
 * 3. 实现的 GetFeatureName 返回的名称必须全局唯一，否则在抽取框架中会 CHECK
 * 4. 添加一个新的特征类，必须在 item_feature_test.cc 添加相应单测
 *
 */
class BaseFeature {
 public:
  enum FeatureType {
    // 基础特征，直接继承于 BaseFeature，目前只有 Bias 这个特征
    kBaseFea = 0,
    // 抽取 item 的特征，需要传入 RecoItem
    kItemFea = 1,
    // 抽取 user 的特征，需要传入 UserInfo
    kUserFea = 2,
    // 抽取 scene 的特征，场景类，涉及的参数较多，如 UserInfo, RecoRequest 等
    kSceneFea = 3,
    // 组合特征，特征提取其实只做已有特征的组合
    kCombineFea = 10,
  };

  BaseFeature() {
  }
  virtual ~BaseFeature() {}

  void SetRecoItem(const reco::RecoItem& item) {
    item_ = &item;
  }

  void SetUser(const reco::user::UserInfo& user) {
    user_ = &user;
  }

  void SetScene(const reco::SceneInfo& scene) {
    scene_ = &scene;
  }

  const std::vector<std::string>& GetFeatures() const {
    return feas_;
  }

  int GetFeatureSize() const {
    CHECK_NOTNULL(this);
    return feas_.size();
  }

  const std::string& GetFeature(int i) const {
    DCHECK_LT(i, (int) feas_.size());
    return feas_.at(i);
  }

  void ClearFeature() {
    return feas_.clear();
  }

  // 直接继承 BaseFeature 的类必须重载此函数
  // 但此函数又不能声明为纯虚函数，否则孙子类也要重载，那很麻烦了
  virtual bool ExtractFeature() WARN_UNUSED_RESULT {
    CHECK(false) << "derived class don't override ExtractFeature";
    return true;
  }

  virtual FeatureType GetFeatureType() const {
    CHECK(false) << "derived class don't override GetFeatureType";
    return kBaseFea;
  }
  virtual const std::string& GetFeatureName() const = 0;
 protected:
  std::vector<std::string> feas_;
  const reco::RecoItem* item_;
  const reco::user::UserInfo* user_;
  const reco::SceneInfo* scene_;
};
}  // namespace ml
}  // namespace reco
