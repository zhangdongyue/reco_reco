#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_feature.h"

namespace reco {
namespace ml {

/**
 * item 组合特征抽取类
 * 传入两个需要组合的类，模版里声明类型，构造函数传入指针
 * 这个类将两个单边特征抽取类 A B 的计算结果组合
 *
 * NOTE:
 * 1. 使用本模版类，基本对于双边特征不要新增文件和类，都转为实现单边特征类
 *    最大化代码重用
 * 2. 在调用本类的 ExtractRecoItemFeaeture 之前，保证单边类的此函数已经被调用过了
 *
 */
template <class A, class B>
class DualCombineFeature : public BaseFeature {
 public:
  DualCombineFeature(const A* a, const B* b) : kJoinTag("-"), a_(a), b_(b) {}
  virtual ~DualCombineFeature() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = a_->GetFeatureName() + b_->GetFeatureName();
    return name;
  }

  virtual bool ExtractFeature() WARN_UNUSED_RESULT {
    feas_.clear();
    DCHECK_NOTNULL(a_);
    DCHECK_NOTNULL(b_);
    if (a_->GetFeatureSize() == 0 || b_->GetFeatureSize() == 0) return false;

    for (int i = 0; i < a_->GetFeatureSize(); ++i) {
      for (int j = 0; j < b_->GetFeatureSize(); ++j) {
        feas_.push_back(a_->GetFeature(i) + kJoinTag + b_->GetFeature(j));
      }
    }
    return true;
  }

  virtual FeatureType GetFeatureType() const {
    return kCombineFea;
  }
 protected:
  const std::string kJoinTag;
  const A* const a_;
  const B* const b_;
};
}  // namespace ml
}  // namespace reco
