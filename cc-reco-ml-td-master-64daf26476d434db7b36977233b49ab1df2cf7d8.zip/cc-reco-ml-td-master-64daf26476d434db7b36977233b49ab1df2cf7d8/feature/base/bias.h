#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_feature.h"

namespace reco {
namespace ml {

class Bias : public BaseFeature {
 public:
  Bias() {}
  virtual ~Bias() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kBias";
    return name;
  }

  virtual bool ExtractFeature() WARN_UNUSED_RESULT {
    feas_.clear();
    feas_.push_back("beta0");
    return true;
  }

  virtual FeatureType GetFeatureType() const {
    return kBaseFea;
  }
};
}  // namespace ml
}  // namespace reco
