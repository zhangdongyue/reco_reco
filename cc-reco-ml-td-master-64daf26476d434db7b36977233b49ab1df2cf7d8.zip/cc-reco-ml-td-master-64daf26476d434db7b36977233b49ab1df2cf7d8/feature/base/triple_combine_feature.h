#pragma once

#include <vector>
#include <string>
#include "reco/ml/feature/base/base_feature.h"

namespace reco {
namespace ml {

/**
 * item 组合特征抽取类
 * 传入 3 个需要组合的类，模版里声明类型，构造函数传入指针
 * 这个类将 3 个单边特征抽取类 A B C 的计算结果组合
 *
 * NOTE:
 * 1. 使用本模版类，基本对于 3 边特征不要新增文件和类，都转为实现单边特征类
 *    最大化代码重用
 * 2. 在调用本类的 ExtractRecoItemFeaeture 之前，保证单边类的此函数已经被调用过了
 *
 */
template <class A, class B, class C>
class TripleCombineFeature: public BaseFeature {
 public:
  TripleCombineFeature(const A* a, const B* b, const C* c) : kJoinTag("-"), a_(a), b_(b), c_(c) {}
  virtual ~TripleCombineFeature() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = a_->GetFeatureName() + b_->GetFeatureName() + c_->GetFeatureName();
    return name;
  }

  virtual bool ExtractFeature() WARN_UNUSED_RESULT {
    feas_.clear();
    DCHECK_NOTNULL(a_);
    DCHECK_NOTNULL(b_);
    DCHECK_NOTNULL(c_);

    if (a_->GetFeatureSize() == 0 || b_->GetFeatureSize() == 0 || c_->GetFeatureSize() == 0) return false;

    size_t incr_num = a_->GetFeatureSize() * b_->GetFeatureSize() * c_->GetFeatureSize();

    if (feas_.capacity() - feas_.size()  < incr_num) {
      feas_.reserve(incr_num);
    }

    for (int i = 0; i < a_->GetFeatureSize(); ++i) {
      for (int j = 0; j < b_->GetFeatureSize(); ++j) {
        for (int k = 0; k < c_->GetFeatureSize(); ++k) {
          feas_.push_back(a_->GetFeature(i));
          feas_.back() += kJoinTag;
          feas_.back() += b_->GetFeature(j);
          feas_.back() += kJoinTag;
          feas_.back() += c_->GetFeature(k);
        }
      }
    }
    return true;
  }

  virtual FeatureType GetFeatureType() const {
    return kCombineFea;
  }
 protected:
  const std::string kJoinTag;
  const A* const a_;
  const B* const b_;
  const C* const c_;
};
}  // namespace ml
}  // namespace reco
