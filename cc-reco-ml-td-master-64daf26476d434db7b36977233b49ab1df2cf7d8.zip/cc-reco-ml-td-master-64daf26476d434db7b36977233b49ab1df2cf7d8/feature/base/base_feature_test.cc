#include <string>
#include <limits>
#include <iostream>
#include <unordered_map>

#include "reco/ml/feature/base/base_feature.h"
#include "reco/ml/feature/base/base_item_feature.h"
#include "reco/ml/feature/base/base_user_feature.h"
#include "reco/ml/feature/base/base_scene_feature.h"
#include "reco/ml/feature/base/dual_combine_feature.h"
#include "reco/ml/feature/base/triple_combine_feature.h"
#include "reco/ml/feature/base/bias.h"
#include "reco/ml/feature/item/image.h"
#include "reco/ml/feature/user/gender.h"
#include "reco/ml/feature/scene/app_name.h"

#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {

TEST(BaseFeatureTest, GetTopInterests) {
  std::map<std::string, double> term_weight;
  std::vector<double> bounds = {0, 2, 4};
  term_weight["a"] = 3.0;
  term_weight["b"] = 5.0;
  term_weight["c"] = 2.0;
  std::vector<std::pair<std::string, int> > interests;
  BaseUserFeature::GetTopInterests(term_weight, 3, 0.3, bounds, &interests);
  ASSERT_EQ(interests.size(), 2u);
  ASSERT_EQ(interests[0].first, "b");
  ASSERT_EQ(interests[0].second, 3);

  ASSERT_EQ(interests[1].first, "a");
  ASSERT_EQ(interests[1].second, 2);
}

TEST(BaseFeatureTest, Bias) {
  Bias feature;
  ASSERT_TRUE(feature.ExtractFeature());
  ASSERT_EQ(feature.GetFeatureSize(), 1);
  ASSERT_STREQ(feature.GetFeature(0).c_str(), "beta0");
}

TEST(BaseFeatureTest, DualCombineFeature) {
  BaseFeature* fea1 = new Bias();
  BaseFeature* fea2 = new Bias();
  BaseFeature* feature = new DualCombineFeature<Bias, Bias>(
      dynamic_cast<const Bias*>(fea1),
      dynamic_cast<const Bias*>(fea2));

  ASSERT_TRUE(fea1->ExtractFeature());
  ASSERT_EQ(fea1->GetFeatureSize(), 1);
  ASSERT_TRUE(fea2->ExtractFeature());
  ASSERT_EQ(fea2->GetFeatureSize(), 1);

  ASSERT_TRUE(feature->ExtractFeature());
  ASSERT_EQ(feature->GetFeatureSize(), 1);

  ASSERT_STREQ(feature->GetFeature(0).c_str(), "beta0-beta0");
  delete fea1;
  delete fea2;
  delete feature;
}

TEST(BaseFeatureTest, TripleCombineFeature) {
  BaseFeature* fea1 = new Bias();
  BaseFeature* fea2 = new Bias();
  BaseFeature* fea3 = new Bias();
  BaseFeature* feature = new TripleCombineFeature<Bias, Bias, Bias> (
      dynamic_cast<const Bias*>(fea1),
      dynamic_cast<const Bias*>(fea2),
      dynamic_cast<const Bias*>(fea3));

  ASSERT_TRUE(fea1->ExtractFeature());
  ASSERT_EQ(fea1->GetFeatureSize(), 1);
  ASSERT_TRUE(fea2->ExtractFeature());
  ASSERT_EQ(fea2->GetFeatureSize(), 1);
  ASSERT_TRUE(fea3->ExtractFeature());
  ASSERT_EQ(fea3->GetFeatureSize(), 1);

  ASSERT_TRUE(feature->ExtractFeature());
  ASSERT_EQ(feature->GetFeatureSize(), 1);

  ASSERT_STREQ(feature->GetFeature(0).c_str(), "beta0-beta0-beta0");
  delete fea1;
  delete fea2;
  delete fea3;
  delete feature;
}

TEST(BaseFeatureTest, DynamicCast) {
  BaseFeature* item_fea = new item_fea::Image();
  BaseFeature* user_fea = new user_fea::Gender();
  BaseFeature* scene_fea = new scene_fea::AppName();

  ASSERT_TRUE(dynamic_cast<BaseItemFeature*>(item_fea) != NULL);
  ASSERT_TRUE(dynamic_cast<BaseUserFeature*>(item_fea) == NULL);
  ASSERT_TRUE(dynamic_cast<BaseSceneFeature*>(item_fea) == NULL);
  ASSERT_TRUE(dynamic_cast<BaseItemFeature*>(user_fea) == NULL);
  ASSERT_TRUE(dynamic_cast<BaseUserFeature*>(user_fea) != NULL);
  ASSERT_TRUE(dynamic_cast<BaseSceneFeature*>(user_fea) == NULL);
  ASSERT_TRUE(dynamic_cast<BaseItemFeature*>(scene_fea) == NULL);
  ASSERT_TRUE(dynamic_cast<BaseUserFeature*>(scene_fea) == NULL);
  ASSERT_TRUE(dynamic_cast<BaseSceneFeature*>(scene_fea) != NULL);

  delete item_fea;
  delete user_fea;
  delete scene_fea;
}

TEST(BaseFeatureTest, FeatureType) {
  BaseFeature* base = new Bias();
  BaseFeature* item_fea = new item_fea::Image();
  BaseFeature* user_fea = new user_fea::Gender();
  BaseFeature* scene_fea = new scene_fea::AppName();
  BaseFeature* combine = new DualCombineFeature<item_fea::Image, user_fea::Gender>(
      dynamic_cast<const item_fea::Image*>(item_fea),
      dynamic_cast<const user_fea::Gender*>(user_fea));

  ASSERT_EQ(base->GetFeatureType(), BaseFeature::kBaseFea);
  ASSERT_EQ(item_fea->GetFeatureType(), BaseFeature::kItemFea);
  ASSERT_EQ(user_fea->GetFeatureType(), BaseFeature::kUserFea);
  ASSERT_EQ(scene_fea->GetFeatureType(), BaseFeature::kSceneFea);
  ASSERT_EQ(combine->GetFeatureType(), BaseFeature::kCombineFea);

  delete base;
  delete item_fea;
  delete user_fea;
  delete scene_fea;
  delete combine;
}

}  // namespace ml
}  // namespace reco
