#pragma once
#include <string>
#include <vector>
#include <set>
#include "reco/base/common/topn_priority_queue.h"
#include "reco/ml/feature/base/base_feature.h"
#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/testing/gtest_prod.h"
#include "base/math/discrete.h"

namespace reco {
namespace ml {

/**
 * user 特征抽取基类,提供了特征抽取的共性部分
 * 用户基于这个类派生，实现其中的纯虚函数 GetFeatureName() ExtractUserFeatureImpl()
 *
 * NOTE: 几个关键注意点一定要看
 * 1. 只需要实现单边特征，组合特征有模版类 DualCombineFeature 来搞定
 *    具体请看 dual_combine_feature.h
 * 2. 特征数据存储在 feas_ 成员中，只存特征本身，不要存类似前缀、分隔符之类的。
 *    比如有一个标题的 term： a b c， 那么 feas_ 里存的就是 a b c
 * 3. 实现的 GetFeatureName 返回的名称必须全局唯一，否则在抽取框架中会 CHECK
 * 4. 添加一个新的特征类，必须在 item_feature_test.cc 添加相应单测
 *
 */
class BaseUserFeature : public BaseFeature {
 public:
  BaseUserFeature() {}
  virtual ~BaseUserFeature() {}

  // NOTE: 目前的需求只有通过 reco item 来预估，
  // 以后有需要在线通过索引来预估时再增加接口
  virtual bool ExtractFeature() WARN_UNUSED_RESULT {
    feas_.clear();
    return ExtractUserFeatureImpl(&feas_);
  }

  virtual FeatureType GetFeatureType() const {
    return kUserFea;
  }
 protected:
  FRIEND_TEST(BaseFeatureTest, GetTopInterests);
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* feas) = 0;

  // 通用的 top 兴趣点抽取函数
  // intest_weight: 原始的 兴趣点 和 点击权重
  // max_interest_num: 最多的兴趣点个数
  // min_norm_weight: 对进入候选的兴趣点，进行权重归一化以后保留权重
  // discrete_bounds: 离散化区间
  // interests: 选择的兴趣点及离散化后的强度
  static void GetTopInterests(const std::map<std::string, double>& interest_weight,
                       const int max_interest_num,
                       const double min_norm_weight,
                       const std::vector<double>& discrete_bounds,
                       std::vector<std::pair<std::string, int> >* interests) {
    ::TopNPriorityQueue<std::string> topn(max_interest_num);
    for (auto it = interest_weight.begin(); it != interest_weight.end(); ++it) {
      topn.add(it->first, it->second);
    }

    // 取 topn 并排序
    std::vector<std::pair<std::string, double> > sorted;
    topn.get_top_n_ordered(&sorted);

    // 权重归一化到 1
    Normalize(&sorted);

    for (auto it = sorted.begin(); it < sorted.end(); ++it) {
      const std::string& term = it->first;
      const double& norm_weight = it->second;
      if (norm_weight < min_norm_weight) {
        // 只取归一化后权重占比达到一定阈值的类别
        break;
      }

      // 查询原始权重，并做离散化
      auto jt = interest_weight.find(term);
      if (jt == interest_weight.end()) {
        continue;
      }
      const double& raw_weight = jt->second;
      interests->push_back(std::make_pair(term, base::math::Discretize(raw_weight, discrete_bounds)));
    }
  }

  template <class T>
  static void Normalize(T* feature) {
    if (feature->empty()) return;
    double sum_weight = 0;
    for (auto it = feature->begin(); it != feature->end(); ++it) {
      sum_weight += it->second;
    }
    if (sum_weight < 1e-9) return;
    for (auto it = feature->begin(); it != feature->end(); ++it) {
      it->second = it->second/sum_weight;
    }
  }
};
}  // namespace ml
}  // namespace reco
