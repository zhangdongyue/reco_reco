#pragma once
#include <string>
#include <vector>
#include <set>
#include "reco/base/common/topn_priority_queue.h"
#include "reco/ml/feature/base/base_feature.h"
#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/testing/gtest_prod.h"
#include "base/math/discrete.h"

namespace reco {
namespace ml {

/**
 * scene 特征抽取基类,提供了特征抽取的共性部分
 * 用户基于这个类派生，实现其中的纯虚函数 GetFeatureName() ExtractSceneFeatureImpl()
 *
 * NOTE: 几个关键注意点一定要看
 * 1. 只需要实现单边特征，组合特征有模版类 DualCombineFeature 来搞定
 *    具体请看 dual_combine_feature.h
 * 2. 特征数据存储在 feas_ 成员中，只存特征本身，不要存类似前缀、分隔符之类的。
 *    比如有一个标题的 term： a b c， 那么 feas_ 里存的就是 a b c
 * 3. 实现的 GetFeatureName 返回的名称必须全局唯一，否则在抽取框架中会 CHECK
 * 4. 添加一个新的特征类，必须在 scene_feature_test.cc 添加相应单测
 *
 */
class BaseSceneFeature : public BaseFeature {
 public:
  BaseSceneFeature() {}
  virtual ~BaseSceneFeature() {}

  // NOTE: 目前的需求只有通过 reco item 来预估，
  // 以后有需要在线通过索引来预估时再增加接口
  virtual bool ExtractFeature() WARN_UNUSED_RESULT {
    feas_.clear();
    return ExtractSceneFeatureImpl(&feas_);
  }

  virtual FeatureType GetFeatureType() const {
    return kSceneFea;
  }
 protected:
  virtual bool ExtractSceneFeatureImpl(std::vector<std::string>* feas) = 0;
};
}  // namespace ml
}  // namespace reco
