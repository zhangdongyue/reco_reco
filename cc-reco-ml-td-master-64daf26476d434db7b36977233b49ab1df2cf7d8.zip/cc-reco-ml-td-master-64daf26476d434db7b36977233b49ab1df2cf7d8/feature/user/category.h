#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"
#include "reco/bizc/common/wrapped_category.h"

namespace reco {
namespace ml {
namespace user_fea {

class Category : public BaseUserFeature {
 public:
  Category() {}
  virtual ~Category() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kUserCate";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    static const std::vector<double> l1_weight_bounds = {10, 16, 24, 32};
    static const std::vector<double> l2_weight_bounds = {8, 12, 20, 30};

    if (!user_->has_profile()) return false;
    const reco::user::Profile& profile = user_->profile();

    if (!profile.has_category_feavec()) return false;
    const reco::CategoryFeatureVector& fea_vec = profile.category_feavec();

    std::map<std::string, double> l1_weight;
    std::map<std::string, double> l2_weight;
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      const reco::CategoryFeature& fea = fea_vec.feature(i);
      if (fea.weight() < kMinWeight) {
        continue;
      }

      std::string term = reco::common::WrappedCategory(fea.literal()).ToString(",");
      if (fea.literal().level() == 0) {
        l1_weight[term] = fea.weight();
      } else if (fea.literal().level() == 1) {
        l2_weight[term] = fea.weight();
      }
    }

    std::vector<std::pair<std::string, int> > l1_interests;
    GetTopInterests(l1_weight, kTopN, 1.0/kTopN, l1_weight_bounds, &l1_interests);
    for (auto it = l1_interests.begin(); it < l1_interests.end(); ++it) {
      fea_parts->push_back(it->first + "_" + base::IntToString(it->second));
    }

    std::vector<std::pair<std::string, int> > l2_interests;
    GetTopInterests(l2_weight, kTopN, 1.0/kTopN, l2_weight_bounds, &l2_interests);
    for (auto it = l2_interests.begin(); it < l2_interests.end(); ++it) {
      fea_parts->push_back(it->first + "_" + base::IntToString(it->second));
    }
    return true;
  }
  
 private:
  // 次数（不管是点击还是刷新）的最低权重
  static const int kMinWeight = 5;
  static const int kTopN = 3;
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
