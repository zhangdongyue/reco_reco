#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"
#include "reco/bizc/common/wrapped_category.h"
#include "base/time/timestamp.h"

namespace reco {
namespace ml {
namespace user_fea {

class TaobaoQueryCategory : public BaseUserFeature {
 public:
  TaobaoQueryCategory() {}
  virtual ~TaobaoQueryCategory() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kTbQueryCate";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    static const std::vector<double> l1_weight_bounds = {2, 5, 10};
    static const int expire_hours = 14 * 24;
    int64 earliest_timestamp = base::GetTimestamp() - expire_hours * base::Time::kMicrosecondsPerHour;
    std::map<std::string, int> cate_map;
    for (int i = user_->taobao_query_history_size() - 1; i >= 0; --i) {
      const reco::user::QueryInfo& query_info = user_->taobao_query_history(i);
      
      // 按搜索时间过滤
      int64 query_timestamp =
          (query_info.has_search_time() ? query_info.search_time() : 0) * base::Time::kMicrosecondsPerSecond;
      if (query_timestamp < earliest_timestamp) continue;

      if (!query_info.has_query()) continue;
    
      if (query_info.category_size() < 1) continue;
      cate_map[query_info.category(0)] += 1;
    }

    for (auto it = cate_map.begin(); it != cate_map.end(); it++) {
      int level = base::math::Discretize(it->second, l1_weight_bounds);
      fea_parts->push_back(it->first + "_" + base::IntToString(level));
    }
  
    return true;
  }
  
 private:
  // 仅使用最新的 top n 条搜索记录
  // static const int kTopN = 20;
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
