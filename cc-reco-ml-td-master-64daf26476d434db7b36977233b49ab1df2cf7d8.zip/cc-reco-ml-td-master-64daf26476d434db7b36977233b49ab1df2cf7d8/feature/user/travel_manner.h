#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {
namespace user_fea {

class TravelManner : public BaseUserFeature {
 public:
  TravelManner() {}
  virtual ~TravelManner() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kTravelManner";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!user_->has_region_profile()) return false;
    const reco::user::RegionProfile& region_profile = user_->region_profile();

    if (region_profile.has_travel_by_drive()
        && region_profile.travel_by_drive()) {
      fea_parts->push_back("TravelByCar");
    }

    if (region_profile.has_travel_by_bus()
        && region_profile.travel_by_bus()) {
      fea_parts->push_back("TravelByBus");
    }

    if (region_profile.has_travel_by_others()
        && region_profile.travel_by_others()) {
      fea_parts->push_back("TravelByOther");
    }

    return true;
  }
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
