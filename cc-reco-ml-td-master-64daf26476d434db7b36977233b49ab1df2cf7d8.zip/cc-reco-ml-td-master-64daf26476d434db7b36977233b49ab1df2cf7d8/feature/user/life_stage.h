#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base//base_user_feature.h"

namespace reco {
namespace ml {
namespace user_fea {

class LifeStage : public BaseUserFeature {
 public:
  LifeStage() {}
  virtual ~LifeStage() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kLifeStage";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!user_->has_ali_profile()) return false;

    const reco::user::AliProfile& ali_profile = user_->ali_profile();

    for (int i = 0; i < ali_profile.gp_life_stage_size(); ++i) {
      if (ali_profile.gp_life_stage(i).empty()) continue;
      fea_parts->push_back(ali_profile.gp_life_stage(i));
    }
    return true;
  }
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
