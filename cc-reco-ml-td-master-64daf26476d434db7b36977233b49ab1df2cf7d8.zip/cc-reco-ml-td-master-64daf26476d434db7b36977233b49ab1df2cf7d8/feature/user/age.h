#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"

namespace reco {
namespace ml {
namespace user_fea {

class Age : public BaseUserFeature {
 public:
  Age() {}
  virtual ~Age() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kAge";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!user_->has_ali_profile()) return false;

    const reco::user::AliProfile& ali_profile = user_->ali_profile();

    if (ali_profile.has_gp_age_level() && !ali_profile.gp_age_level().empty()) {
      fea_parts->push_back(ali_profile.gp_age_level());
    }

    return true;
  }
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
