#include <string>
#include <limits>
#include <iostream>
#include <unordered_map>

#include "reco/ml/feature/user/include.h"

#include "reco/bizc/common/wrapped_category.h"

#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {
namespace user_fea {

class UserFeatureTest : public ::testing::Test {
 protected:
  Feature GenFeature(const std::string& category, const std::string& literal, double weight) {
    Feature feature;
    feature.set_category(category);
    feature.set_literal(literal);
    feature.set_weight(weight);
    return feature;
  }

  CategoryFeature GenCategoryFeature(const std::string& literal, double weight) {
    CategoryFeature feature;
    feature.mutable_literal()->CopyFrom(reco::common::WrappedCategory(literal).ToCategory());
    feature.set_weight(weight);
    return feature;
  }

  virtual void SetUp() {
    // required fields
    user_.mutable_identity()->set_app_token("app");
    user_.mutable_identity()->set_user_id(1ul);
    user_.mutable_identity()->set_outer_id("1");

    AliProfile ali_profile;
    ali_profile.set_gp_gender("M");
    ali_profile.set_gp_age_level("31-35");
    ali_profile.set_gp_decade("80后");
    ali_profile.set_gp_career("码农");
    ali_profile.set_gp_degree("博士");
    ali_profile.set_gp_school("中国科学技术大学");
    ali_profile.set_gp_attending_college("UC大五");
    ali_profile.add_gp_life_stage("已婚");
    ali_profile.add_gp_life_stage("已育");
    ali_profile.add_gp_life_stage("已有车");
    ali_profile.mutable_gp_interest_group()->add_feature()->CopyFrom(GenFeature("", "科技数码", 1.0));
    user_.mutable_ali_profile()->CopyFrom(ali_profile);

    RegionProfile region_profile;
    region_profile.set_permanent_adcodes("441800:0.2449489742783178;440100:0.4242640687119285;110000:0.95");
    AddressInfo addr_info;
    addr_info.set_province("北京");
    addr_info.set_city("市辖市");
    addr_info.set_area("望京");
    region_profile.mutable_home_address_info()->CopyFrom(addr_info);
    addr_info.set_area("五道口");
    region_profile.mutable_company_address_info()->CopyFrom(addr_info);
    addr_info.set_area("西三旗");
    region_profile.mutable_freq_address_info()->CopyFrom(addr_info);
    region_profile.set_travel_by_drive(true);
    user_.mutable_region_profile()->CopyFrom(region_profile);

    Profile profile;
    profile.mutable_category_feavec()->add_feature()->CopyFrom(GenCategoryFeature("科技", 10));
    profile.mutable_category_feavec()->add_feature()->CopyFrom(GenCategoryFeature("科技\t互联网", 8));
    profile.mutable_plsa_topic_feavec()->add_feature()->CopyFrom(GenFeature("科技", "topic1", 8));
    profile.mutable_plsa_topic_feavec()->add_feature()->CopyFrom(GenFeature("财经", "topic1", 10));
    profile.mutable_refresh_channel_feavec()->add_feature()->CopyFrom(GenFeature("", "100", 100));
    profile.mutable_refresh_channel_feavec()->add_feature()->CopyFrom(GenFeature("", "1525483516", 27));
    profile.set_is_loyal_user(true);
    profile.mutable_tag_feavec()->add_feature()->CopyFrom(GenFeature("科技", "label:马云", 11));
    profile.mutable_politics_fea()->CopyFrom(GenFeature("", "L", 1));
    profile.mutable_dirty_fea()->CopyFrom(GenFeature("", "M", 1));
    profile.mutable_bluffing_title_fea()->CopyFrom(GenFeature("", "VH", 1));
    user_.mutable_profile()->CopyFrom(profile);

    AppUsageInfo usage_info;
    usage_info.set_app_name("com.UCMobile");
    user_.add_app_usage_history()->CopyFrom(usage_info);

  }

  virtual void TearDown() {
    delete feature_;
  }

  BaseUserFeature* feature_;
  reco::user::UserInfo user_;
};

TEST_F(UserFeatureTest, Gender) {
  feature_ = new Gender();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "M");
}

TEST_F(UserFeatureTest, Age) {
  feature_ = new Age();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 2);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "31-35");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "80后");
}

TEST_F(UserFeatureTest, Career) {
  feature_ = new Career();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "码农");
}

TEST_F(UserFeatureTest, Education) {
  feature_ = new Education();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 3);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "博士");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "中国科学技术大学");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "UC大五");
}

TEST_F(UserFeatureTest, LifeStage) {
  feature_ = new LifeStage();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 3);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "已婚");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "已育");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "已有车");
}

TEST_F(UserFeatureTest, EcomInterest) {
  feature_ = new EcomInterest();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "科技数码");
}

TEST_F(UserFeatureTest, Region) {
  feature_ = new Region();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 6);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "ResidentCity_441800");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "ResidentCity_440100");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "ResidentCity_110000");
  ASSERT_STREQ(feature_->GetFeature(3).c_str(), "Home_北京市辖市望京");
  ASSERT_STREQ(feature_->GetFeature(4).c_str(), "Company_北京市辖市五道口");
  ASSERT_STREQ(feature_->GetFeature(5).c_str(), "Freq_北京市辖市西三旗");
}

TEST_F(UserFeatureTest, TravelManner) {
  feature_ = new TravelManner();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "TravelByCar");
}

TEST_F(UserFeatureTest, Category) {
  feature_ = new Category();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 2);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "科技_1");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "科技,互联网_1");
}

TEST_F(UserFeatureTest, PlsaTopic) {
  feature_ = new PlsaTopic();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 2);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "财经_topic1_3");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "科技_topic1_2");
}

TEST_F(UserFeatureTest, RefreshChannel) {
  feature_ = new RefreshChannel();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "ch_1525483516_3");
}

TEST_F(UserFeatureTest, IsLoyal) {
  feature_ = new IsLoyal();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "loyal");
}

TEST_F(UserFeatureTest, Tag) {
  feature_ = new Tag();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "科技_马云_3");
}

TEST_F(UserFeatureTest, ContentProblem) {
  feature_ = new ContentProblem();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 3);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "politics_L");
  ASSERT_STREQ(feature_->GetFeature(1).c_str(), "dirty_M");
  ASSERT_STREQ(feature_->GetFeature(2).c_str(), "bluffing_VH");
}

TEST_F(UserFeatureTest, AppUsage) {
  feature_ = new AppUsage();
  feature_->SetUser(user_);
  ASSERT_TRUE(feature_->ExtractFeature());
  ASSERT_EQ(feature_->GetFeatureSize(), 1);
  ASSERT_STREQ(feature_->GetFeature(0).c_str(), "com.UCMobile");
}
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
