#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base//base_user_feature.h"

namespace reco {
namespace ml {
namespace user_fea {

class EcomInterest : public BaseUserFeature {
 public:
  EcomInterest() {}
  virtual ~EcomInterest() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kEcomInterest";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!user_->has_ali_profile()) return false;
    const reco::user::AliProfile& ali_profile = user_->ali_profile();

    if (!ali_profile.has_gp_interest_group()) return false;
    const reco::FeatureVector& fv = ali_profile.gp_interest_group();

    for (int i = 0; i < fv.feature_size(); ++i) {
      if (fv.feature(i).literal().empty()) continue;
      fea_parts->push_back(fv.feature(i).literal());
    }
    return true;
  }
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
