#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"
#include "reco/bizc/common/wrapped_category.h"
#include "base/time/timestamp.h"

namespace reco {
namespace ml {
namespace user_fea {

class UcbLogCategory : public BaseUserFeature {
 public:
  UcbLogCategory() {}
  virtual ~UcbLogCategory() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kUcbCate";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    static const std::vector<double> l1_weight_bounds = {2, 5, 10};
    static const int expire_hours = 14 * 24;
    int64 earliest_timestamp = base::GetTimestamp() - expire_hours * base::Time::kMicrosecondsPerHour;
    std::map<std::string, int> cate_map;
    for (int i = user_->ucb_log_history_size() - 1; i >= 0; --i) {
      const reco::user::UcbLogInfo& log_info = user_->ucb_log_history(i);
      
      // 按时间过滤
      int64 log_timestamp =
          (log_info.has_view_time() ? log_info.view_time() : 0) * base::Time::kMicrosecondsPerSecond;
      if (log_timestamp < earliest_timestamp) continue;

      if (!log_info.has_title()) continue;
    
      const std::string& title = log_info.title();
      if (title.find("天气") != std::string::npos
          || title.find("限行") != std::string::npos
          || title.find("百度") != std::string::npos) {
        continue;
      }

      if (log_info.category_size() < 1) continue;
      
      cate_map[log_info.category(0)] += 1;
    }

    for (auto it = cate_map.begin(); it != cate_map.end(); it++) {
      int level = base::math::Discretize(it->second, l1_weight_bounds);
      fea_parts->push_back(it->first + "_" + base::IntToString(level));
    }
  
    return true;
  }
  
 private:
  // 仅使用最新的 top n 条搜索记录
  //static const int kTopN = 20;
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
