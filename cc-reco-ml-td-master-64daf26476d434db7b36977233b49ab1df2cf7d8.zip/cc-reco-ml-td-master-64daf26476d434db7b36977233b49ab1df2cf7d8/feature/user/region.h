#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {
namespace user_fea {

class Region : public BaseUserFeature {
 public:
  Region() {}
  virtual ~Region() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kUsrRegion";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!user_->has_region_profile()) return false;
    const reco::user::RegionProfile& region_profile = user_->region_profile();

    std::vector<std::string> flds;
    std::vector<std::string> subs;
    if (region_profile.has_permanent_adcodes()) {
      flds.clear();
      base::SplitString(region_profile.permanent_adcodes(), ";", &flds);
      for (size_t i = 0; i < flds.size(); ++i) {
        subs.clear();
        base::SplitString(flds[i], ":", &subs);
        int64 adcode;
        if (!base::StringToInt64(subs[0], &adcode)) {
          continue;
        }
        fea_parts->push_back("ResidentCity_" + subs[0]);
      }
    }
                        
    if (region_profile.has_home_address_info()) {
      const AddressInfo& addr = region_profile.home_address_info();
      std::string r = addr.province() + addr.city() + addr.area();
      if (!r.empty()) {
        fea_parts->push_back("Home_" + r);
      }
    }

    if (region_profile.has_company_address_info()) {
      const AddressInfo& addr = region_profile.company_address_info();
      std::string r = addr.province() + addr.city() + addr.area();
      if (!r.empty()) {
        fea_parts->push_back("Company_" + r);
      }
    }

    if (region_profile.has_freq_address_info()) {
      const AddressInfo& addr = region_profile.freq_address_info();
      std::string r = addr.province() + addr.city() + addr.area();
      if (!r.empty()) {
        fea_parts->push_back("Freq_" + r);
      }
    }

    return true;
  }
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
