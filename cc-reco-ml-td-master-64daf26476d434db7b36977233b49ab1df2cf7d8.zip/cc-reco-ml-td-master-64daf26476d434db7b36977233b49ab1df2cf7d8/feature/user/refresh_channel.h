#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {
namespace user_fea {

class RefreshChannel : public BaseUserFeature {
 public:
  RefreshChannel() {}
  virtual ~RefreshChannel() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kRefreshChannel";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    static const std::vector<double> weight_bounds = {10, 12, 16, 30};
    if (!user_->has_profile()) return false;
    const reco::user::Profile& profile = user_->profile();

    if (!profile.has_refresh_channel_feavec()) return false;
    const reco::FeatureVector& fea_vec = profile.refresh_channel_feavec();

    std::map<std::string, double> term_weight;
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      const reco::Feature& fea = fea_vec.feature(i);
      if (fea.weight() <= kMinWeight) {
        continue;
      }
      if (fea.literal() == "100") {
        continue;
      }

      std::string term = "ch_" + fea.literal();
      term_weight[term] = fea.weight();
    }

    std::vector<std::pair<std::string, int> > interests;
    GetTopInterests(term_weight, kTopN, 1.0/kTopN, weight_bounds, &interests);
    for (auto it = interests.begin(); it < interests.end(); ++it) {
      fea_parts->push_back(it->first + "_" + base::IntToString(it->second));
    }
    return true;
  }

 private:
  // 次数（不管是点击还是刷新）的最低权重
  static const int kMinWeight = 10;
  static const int kTopN = 6;
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
