#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"

namespace reco {
namespace ml {
namespace user_fea {

class Career : public BaseUserFeature {
 public:
  Career() {}
  virtual ~Career() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kCareer";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!user_->has_ali_profile()) return false;

    const reco::user::AliProfile& ali_profile = user_->ali_profile();

    if (ali_profile.has_gp_career() && !ali_profile.gp_career().empty()) {
      fea_parts->push_back(ali_profile.gp_career());
    }
    return true;
  }
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
