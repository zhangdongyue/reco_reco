#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"
#include "reco/base/common/topn_heap.h"

namespace reco {
namespace ml {
namespace user_fea {

class AppUsage : public BaseUserFeature {
 public:
  AppUsage() {}
  virtual ~AppUsage() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kAppUsage";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    if (user_->app_usage_history_size() == 0) return false;

    std::map<std::string, int> use_cnt;
    for (int i = 0; i < user_->app_usage_history_size(); ++i) {
      const reco::user::AppUsageInfo& info = user_->app_usage_history(i);
      use_cnt[info.app_name()] += 1;
    }

    ::TopNHeap<std::string> topn(10);
    for (auto it = use_cnt.begin(); it != use_cnt.end(); ++it) {
      topn.add(it->first, it->second);
    }
    std::vector<std::pair<std::string, double> > apps;
    topn.get_top_n_unordered(&apps);
    for (auto it = apps.begin(); it != apps.end(); ++it) {
      fea_parts->push_back(it->first);
    }

    return true;
  }
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
