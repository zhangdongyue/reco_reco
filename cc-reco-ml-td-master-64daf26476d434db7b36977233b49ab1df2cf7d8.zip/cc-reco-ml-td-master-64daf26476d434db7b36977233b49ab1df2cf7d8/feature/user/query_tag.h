#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"
#include "reco/bizc/common/wrapped_category.h"
#include "base/time/timestamp.h"

namespace reco {
namespace ml {
namespace user_fea {

class QueryTag : public BaseUserFeature {
 public:
  QueryTag() {}
  virtual ~QueryTag() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kQueryTag";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    static const std::vector<double> weight_bounds = {2, 5, 10};
    static const int expire_hours = 14 * 24;
    int64 earliest_timestamp = base::GetTimestamp() - expire_hours * base::Time::kMicrosecondsPerHour;
    std::map<std::string, int> fea_map;
    for (int i = user_->query_history_size() - 1; i >= 0; --i) {
      const reco::user::QueryInfo& query_info = user_->query_history(i);
      
      // 按搜索时间过滤
      int64 query_timestamp =
          (query_info.has_search_time() ? query_info.search_time() : 0) * base::Time::kMicrosecondsPerSecond;
      if (query_timestamp < earliest_timestamp) continue;

      if (!query_info.has_query()) continue;
    
      const std::string& query = query_info.query();
      if (query.find("天气") != std::string::npos
          || query.find("限行") != std::string::npos
          || query.find("百度") != std::string::npos) {
        continue;
      }
      
      for (int j = 0; j < query_info.tags_size(); ++j) {
        if (query_info.tags(j).empty()) continue;
        fea_map[query_info.tags(j)] += 1;
      }
    }

    for (auto it = fea_map.begin(); it != fea_map.end(); it++) {
      int level = base::math::Discretize(it->second, weight_bounds);
      fea_parts->push_back(it->first + "_" + base::IntToString(level));
    }
  
    return true;
  }
  
 private:
  // 仅使用最新的 top n 条搜索记录
  // static const int kTopN = 20;
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
