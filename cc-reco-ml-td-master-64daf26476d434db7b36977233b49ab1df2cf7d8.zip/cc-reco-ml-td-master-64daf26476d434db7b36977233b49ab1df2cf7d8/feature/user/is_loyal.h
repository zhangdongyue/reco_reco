#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"

namespace reco {
namespace ml {
namespace user_fea {

class IsLoyal : public BaseUserFeature {
 public:
  IsLoyal() {}
  virtual ~IsLoyal() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kIsLoyal";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!user_->has_profile()) return false;
    const reco::user::Profile& profile = user_->profile();

    if (profile.has_is_loyal_user() && profile.is_loyal_user()) {
      fea_parts->push_back("loyal");
    }
    return true;
  }
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
