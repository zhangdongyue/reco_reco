#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/user_lib/user_info.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/ml/common/io_util.h"

#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/feature/user/include.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_string(user_server_machine_list, "../config/user_server_machine.yaml.em21", "user server");
DEFINE_string(user_profile_machine_list, "../config/user_profile_machine.yaml.em21", "user profile server");

DEFINE_string(user_file, "", "user id file, one id per line");
DEFINE_string(user_dump_file, "", "dumped reco user file");

DEFINE_bool(clear_show, true, "clear shown history");

namespace reco {
namespace ml {
class UserFeatureExtractor : public BaseFeatureExtractor {
 public:
  UserFeatureExtractor() {}
  virtual ~UserFeatureExtractor() {}

  virtual void SetupFeatureLayout() {
    using namespace user_fea;
    ClearFeatureExtractors();

    std::set<std::string> dedup;

    AddFeature<Gender>(&dedup, true);
    AddFeature<Age>(&dedup, true);
    AddFeature<Career>(&dedup, true);
    AddFeature<Education>(&dedup, true);
    AddFeature<LifeStage>(&dedup, true);
    AddFeature<EcomInterest>(&dedup, true);
    AddFeature<Region>(&dedup, true);
    AddFeature<TravelManner>(&dedup, true);
    AddFeature<Category>(&dedup, true);
    AddFeature<PlsaTopic>(&dedup, true);
    AddFeature<RefreshChannel>(&dedup, true);
    AddFeature<IsLoyal>(&dedup, true);
    AddFeature<Tag>(&dedup, true);
    AddFeature<ContentProblem>(&dedup, true);
    AddFeature<AppUsage>(&dedup, true);

    layout_done_ = true;
  }
};
}  // namespace ml
}  // namespace reco

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");

  thread::BlockingQueue<reco::UserInfo*> user_queue;
  if (!FLAGS_user_dump_file.empty() && !FLAGS_user_file.empty()) {
    CHECK(false) << "item id or dump item file should chose just one";
  } else if (!FLAGS_user_dump_file.empty()) {
    reco::ml::LoadDumpProtoFile<reco::UserInfo>(FLAGS_user_dump_file, &user_queue);
  } else if (!FLAGS_user_file.empty()) {
    reco::ml::GetUserMultiThread(FLAGS_user_file,
                                 FLAGS_user_server_machine_list,
                                 FLAGS_user_profile_machine_list,
                                 4, FLAGS_clear_show, &user_queue);
  } else {
    CHECK(false) << "no input item";
  }
  user_queue.Close();

  // item meta, fea literal
  reco::ml::BaseFeatureExtractor* extractor = new reco::ml::UserFeatureExtractor();
  extractor->SetupFeatureLayout();
  std::vector<std::string> feas;
  std::vector<std::string> metas;
  while (!user_queue.Empty()) {
    reco::UserInfo* puser = user_queue.Take();
    if (puser == NULL) continue;

    scoped_ptr<reco::UserInfo> p(puser);

    const reco::UserInfo& user = *puser;
    // LOG(INFO) << puser->Utf8DebugString();

    // feature
    feas.clear();
    extractor->ExtractUserFeature(user, &feas);
    if (feas.empty()) {
      continue;
    }

    // meta
    metas.clear();
    metas.push_back(user.identity().app_token());
    metas.push_back(base::Uint64ToString(user.identity().user_id()));

    std::cout << base::JoinStrings(metas, "\t") << "\t" << base::JoinStrings(feas, "\t") << std::endl;
  }
  delete extractor;

  return 0;
}
