#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"
#include "base/strings/string_split.h"

namespace reco {
namespace ml {
namespace user_fea {

class SmTag : public BaseUserFeature {
 public:
  SmTag() {}
  virtual ~SmTag() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kSmTag";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    static const std::vector<double> weight_bounds = {0.1, 0.3, 0.6, 0.9};
    if (!user_->has_sm_profile()) return false;
    const reco::user::SmUserProfile& profile = user_->sm_profile();

    if (!profile.has_tag_feavec()) return false;
    const reco::FeatureVector& fea_vec = profile.tag_feavec();

    std::map<std::string, double> term_weight;
    std::vector<std::string> flds;
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      const reco::Feature& fea = fea_vec.feature(i);
      if (fea.weight() <= kMinWeight) {
        continue;
      }

      flds.clear();
      base::SplitStringWithMoreOptions(fea.literal(), ":", false, false, 1, &flds);
      std::string tag;
      if (flds.size() <= 1) {
        tag = flds[0];
      } else {
        tag = flds[1];
      }
      std::string term = fea.category() + "_" + tag;
      term_weight[term] = fea.weight();
    }

    std::vector<std::pair<std::string, int> > interests;
    GetTopInterests(term_weight, kTopN, 1.5/kTopN, weight_bounds, &interests);
    for (auto it = interests.begin(); it < interests.end(); ++it) {
      fea_parts->push_back(it->first + "_" + base::IntToString(it->second));
    }

    return true;
  }

 private:
  // 次数（不管是点击还是刷新）的最低权重
  static const double kMinWeight;
  static const int kTopN;
};
const double SmTag::kMinWeight = 0.2;
const int SmTag::kTopN = 20;
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
