#pragma once
#include <string>
#include <vector>
#include "reco/ml/feature/base/base_user_feature.h"

namespace reco {
namespace ml {
namespace user_fea {

class Education : public BaseUserFeature {
 public:
  Education() {}
  virtual ~Education() {}

  virtual const std::string& GetFeatureName() const {
    static const std::string name = "kEducation";
    return name;
  }

 protected:
  virtual bool ExtractUserFeatureImpl(std::vector<std::string>* fea_parts) {
    if (!user_->has_ali_profile()) return false;

    const reco::user::AliProfile& ali_profile = user_->ali_profile();

    if (ali_profile.has_gp_degree() && !ali_profile.gp_degree().empty()) {
      fea_parts->push_back(ali_profile.gp_degree());
    }

    //if (ali_profile.has_gp_school()) {
    //  fea_parts->push_back(ali_profile.gp_school());
    //}

    //if (ali_profile.has_gp_attending_college()) {
    //  fea_parts->push_back(ali_profile.gp_attending_college());
    //}

    if (ali_profile.has_gp_is_undergraduate() && ali_profile.gp_is_undergraduate()) {
      fea_parts->push_back("IsUndergraduate");
    }

    return true;
  }
};
}  // namespace user_fea
}  // namespace ml
}  // namespace reco
