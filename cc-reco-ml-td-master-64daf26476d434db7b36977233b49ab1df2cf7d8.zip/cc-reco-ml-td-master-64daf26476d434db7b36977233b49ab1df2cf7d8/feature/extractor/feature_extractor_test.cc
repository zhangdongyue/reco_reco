#include "reco/ml/feature/extractor/feature_extractor.h"

#include <string>
#include <limits>
#include <iostream>
#include <unordered_map>

#include "reco/ml/feature/item/include.h"
#include "reco/ml/feature/user/include.h"
#include "reco/ml/feature/scene/include.h"
#include "reco/ml/feature/base/bias.h"

#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {

class FeatureExtractorTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    // required fields
    item_.mutable_identity()->set_app_token("app");
    item_.mutable_identity()->set_item_id(1ul);
    item_.mutable_identity()->set_outer_id("1");
    item_.mutable_identity()->set_type(reco::kNews);

    item_.set_is_valid(true);
    base::Time now = base::Time::Now();
    now.ToStringInSeconds(item_.mutable_create_time());
    item_.set_title("title");
    item_.set_normalized_title("title");
    item_.set_content("content");
    item_.set_source("source");

    // diy fields
    item_.add_title_unigram("term");
    item_.set_orig_source_media("media");

    // required fields
    user_.mutable_identity()->set_app_token("app");
    user_.mutable_identity()->set_user_id(1ul);
    user_.mutable_identity()->set_outer_id("1");

    AliProfile ali_profile;
    ali_profile.set_gp_gender("M");
    ali_profile.set_gp_career("码农");
    user_.mutable_ali_profile()->CopyFrom(ali_profile);

    scene_.set_app_name("uc-iflow");
  }

  virtual void TearDown() {
    delete extractor_;
  }

  BaseFeatureExtractor* extractor_;
  reco::RecoItem item_;
  reco::UserInfo user_;
  reco::SceneInfo scene_;
};

class TestItemFeatureExtractor : public BaseFeatureExtractor {
 public:
  TestItemFeatureExtractor() {}
  virtual ~TestItemFeatureExtractor() {}

  virtual void SetupFeatureLayout() {
    ClearFeatureExtractors();

    std::set<std::string> dedup;

    AddFeature<Bias>(&dedup, true);
    AddFeature<item_fea::TitleUnigram>(&dedup, true);
    AddFeature<item_fea::Media>(&dedup, true);

    AddFeature<Bias, item_fea::TitleUnigram>(&dedup, true);
    AddFeature<Bias, item_fea::Media>(&dedup, true);
    AddFeature<item_fea::TitleUnigram, item_fea::Media>(&dedup, true);

    AddFeature<Bias, item_fea::TitleUnigram, item_fea::Media>(&dedup, true);
    layout_done_ = true;
  }
};

TEST_F(FeatureExtractorTest, ItemFeatureExtract) {
  extractor_ = new TestItemFeatureExtractor();
  extractor_->SetupFeatureLayout();

  std::vector<std::string> fea_literal;
  extractor_->ExtractItemFeature(item_, &fea_literal);
  ASSERT_EQ(fea_literal.size(), 7u);
  ASSERT_EQ(fea_literal[0], "kBias:beta0");
  ASSERT_EQ(fea_literal[1], "kTitleUnigram:term");
  ASSERT_EQ(fea_literal[2], "kMedia:media");
  ASSERT_EQ(fea_literal[3], "kBiaskTitleUnigram:beta0-term");
  ASSERT_EQ(fea_literal[4], "kBiaskMedia:beta0-media");
  ASSERT_EQ(fea_literal[5], "kTitleUnigramkMedia:term-media");
  ASSERT_EQ(fea_literal[6], "kBiaskTitleUnigramkMedia:beta0-term-media");
}

class TestUserFeatureExtractor : public BaseFeatureExtractor {
 public:
  TestUserFeatureExtractor() {}
  virtual ~TestUserFeatureExtractor() {}

  virtual void SetupFeatureLayout() {
    ClearFeatureExtractors();

    std::set<std::string> dedup;

    AddFeature<Bias>(&dedup, true);
    AddFeature<user_fea::Gender>(&dedup, true);
    AddFeature<user_fea::Career>(&dedup, true);

    AddFeature<Bias, user_fea::Gender>(&dedup, true);
    AddFeature<Bias, user_fea::Career>(&dedup, true);
    AddFeature<user_fea::Gender, user_fea::Career>(&dedup, true);

    AddFeature<Bias, user_fea::Gender, user_fea::Career>(&dedup, true);
    layout_done_ = true;
  }
};

TEST_F(FeatureExtractorTest, UserFeatureExtract) {
  extractor_ = new TestUserFeatureExtractor();
  extractor_->SetupFeatureLayout();

  std::vector<std::string> fea_literal;
  extractor_->ExtractUserFeature(user_, &fea_literal);
  ASSERT_EQ(fea_literal.size(), 7u);
  ASSERT_EQ(fea_literal[0], "kBias:beta0");
  ASSERT_EQ(fea_literal[1], "kGender:M");
  ASSERT_EQ(fea_literal[2], "kCareer:码农");
  ASSERT_EQ(fea_literal[3], "kBiaskGender:beta0-M");
  ASSERT_EQ(fea_literal[4], "kBiaskCareer:beta0-码农");
  ASSERT_EQ(fea_literal[5], "kGenderkCareer:M-码农");
  ASSERT_EQ(fea_literal[6], "kBiaskGenderkCareer:beta0-M-码农");
}

class TestSceneFeatureExtractor : public BaseFeatureExtractor {
 public:
  TestSceneFeatureExtractor() {}
  virtual ~TestSceneFeatureExtractor() {}

  virtual void SetupFeatureLayout() {
    ClearFeatureExtractors();

    std::set<std::string> dedup;

    AddFeature<Bias>(&dedup, true);
    AddFeature<scene_fea::AppName>(&dedup, true);

    AddFeature<Bias, scene_fea::AppName>(&dedup, true);

    layout_done_ = true;
  }
};

TEST_F(FeatureExtractorTest, SceneFeatureExtract) {
  extractor_ = new TestSceneFeatureExtractor();
  extractor_->SetupFeatureLayout();

  std::vector<std::string> fea_literal;
  extractor_->ExtractSceneFeature(scene_, &fea_literal);
  ASSERT_EQ(fea_literal.size(), 3u);
  ASSERT_EQ(fea_literal[0], "kBias:beta0");
  ASSERT_EQ(fea_literal[1], "kAppName:uc-iflow");
  ASSERT_EQ(fea_literal[2], "kBiaskAppName:beta0-uc-iflow");
}

class TestUserItemFeatureExtractor : public BaseFeatureExtractor {
 public:
  TestUserItemFeatureExtractor() {}
  virtual ~TestUserItemFeatureExtractor() {}

  virtual void SetupFeatureLayout() {
    ClearFeatureExtractors();

    std::set<std::string> dedup;

    AddFeature<Bias>(&dedup, true);
    AddFeature<user_fea::Gender>(&dedup, true);
    AddFeature<item_fea::Media>(&dedup, true);

    AddFeature<Bias, user_fea::Gender>(&dedup, true);
    AddFeature<Bias, item_fea::Media>(&dedup, true);
    AddFeature<user_fea::Gender, item_fea::Media>(&dedup, true);

    AddFeature<Bias, user_fea::Gender, item_fea::Media>(&dedup, true);
    layout_done_ = true;
  }
};

TEST_F(FeatureExtractorTest, UserItemFeatureExtract) {
  extractor_ = new TestUserItemFeatureExtractor();
  extractor_->SetupFeatureLayout();

  std::vector<std::string> fea_literal;
  extractor_->ResetUser(user_);
  extractor_->ExtractUserItemFeature(item_, &fea_literal);
  ASSERT_EQ(fea_literal.size(), 7u);
  ASSERT_EQ(fea_literal[0], "kBias:beta0");
  ASSERT_EQ(fea_literal[1], "kGender:M");
  ASSERT_EQ(fea_literal[2], "kMedia:media");
  ASSERT_EQ(fea_literal[3], "kBiaskGender:beta0-M");
  ASSERT_EQ(fea_literal[4], "kBiaskMedia:beta0-media");
  ASSERT_EQ(fea_literal[5], "kGenderkMedia:M-media");
  ASSERT_EQ(fea_literal[6], "kBiaskGenderkMedia:beta0-M-media");

  reco::RecoItem another_item = item_;
  another_item.set_orig_source_media("media1");
  extractor_->ExtractUserItemFeature(another_item, &fea_literal);
  ASSERT_EQ(fea_literal.size(), 7u);
  ASSERT_EQ(fea_literal[0], "kBias:beta0");
  ASSERT_EQ(fea_literal[1], "kGender:M");
  ASSERT_EQ(fea_literal[2], "kMedia:media1");
  ASSERT_EQ(fea_literal[3], "kBiaskGender:beta0-M");
  ASSERT_EQ(fea_literal[4], "kBiaskMedia:beta0-media1");
  ASSERT_EQ(fea_literal[5], "kGenderkMedia:M-media1");
  ASSERT_EQ(fea_literal[6], "kBiaskGenderkMedia:beta0-M-media1");

  reco::UserInfo another_user = user_;
  another_user.mutable_ali_profile()->set_gp_gender("F");
  extractor_->ResetUser(another_user);
  extractor_->ExtractUserItemFeature(item_, &fea_literal);
  ASSERT_EQ(fea_literal.size(), 7u);
  ASSERT_EQ(fea_literal[0], "kBias:beta0");
  ASSERT_EQ(fea_literal[1], "kGender:F");
  ASSERT_EQ(fea_literal[2], "kMedia:media");
  ASSERT_EQ(fea_literal[3], "kBiaskGender:beta0-F");
  ASSERT_EQ(fea_literal[4], "kBiaskMedia:beta0-media");
  ASSERT_EQ(fea_literal[5], "kGenderkMedia:F-media");
  ASSERT_EQ(fea_literal[6], "kBiaskGenderkMedia:beta0-F-media");

  extractor_->ExtractUserItemFeature(another_item, &fea_literal);
  ASSERT_EQ(fea_literal.size(), 7u);
  ASSERT_EQ(fea_literal[0], "kBias:beta0");
  ASSERT_EQ(fea_literal[1], "kGender:F");
  ASSERT_EQ(fea_literal[2], "kMedia:media1");
  ASSERT_EQ(fea_literal[3], "kBiaskGender:beta0-F");
  ASSERT_EQ(fea_literal[4], "kBiaskMedia:beta0-media1");
  ASSERT_EQ(fea_literal[5], "kGenderkMedia:F-media1");
  ASSERT_EQ(fea_literal[6], "kBiaskGenderkMedia:beta0-F-media1");
}
}  // namespace ml
}  // namespace reco

