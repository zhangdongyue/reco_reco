#include "reco/ml/feature/extractor/feature_extractor.h"
#include <math.h>
#include <unordered_set>
#include <string>
#include <algorithm>
#include <vector>

#include "reco/ml/feature/base/base_user_feature.h"
#include "reco/ml/feature/base/base_item_feature.h"
#include "reco/ml/feature/base/bias.h"
#include "reco/ml/feature/item/include.h"
#include "reco/ml/feature/user/include.h"
#include "base/hash_function/city.h"

namespace reco {
namespace ml {

// DEFINE_string(video_feature_names, "", "video用的特征");

BaseFeatureExtractor::BaseFeatureExtractor() : kJoinTag(":") {
  layout_done_ = false;
  Bias bias;
  CHECK(bias.ExtractFeature());
  const std::vector<std::string>& feas = bias.GetFeatures();
  bias_literal_ = bias.GetFeatureName() + kJoinTag + feas[0];
  bias_sign_ = base::CityHash64(bias_literal_.c_str(), bias_literal_.size());
}

BaseFeatureExtractor::~BaseFeatureExtractor() {
  ClearFeatureExtractors();
  user_ = NULL;
}

void BaseFeatureExtractor::ExtractUserFeature(const reco::user::UserInfo& user,
                                              std::vector<std::string>* fea_literal) {
  CHECK(layout_done_);
  fea_literal->clear();
  for (size_t i = 0; i < features_.size(); ++i) {
    BaseFeature* feature = features_[i].first;
    if (!IsUserFeature(feature)
        && !IsBaseFeature(feature)
        && !IsCombineFeature(feature)) {
      continue;
    }

    bool output = features_[i].second;
    feature->SetUser(user);
    if (!feature->ExtractFeature()) {
      continue;
    }
    if (output) {
      const std::vector<std::string>& feas = feature->GetFeatures();
      for (size_t j = 0; j < feas.size(); ++j) {
        fea_literal->push_back(feature->GetFeatureName() + kJoinTag + feas[j]);
      }
    }
  }
}

void BaseFeatureExtractor::ExtractItemFeature(const reco::RecoItem& item,
                                              std::vector<std::string>* fea_literal) {
  CHECK(layout_done_);
  fea_literal->clear();
  for (size_t i = 0; i < features_.size(); ++i) {
    BaseFeature* feature = features_[i].first;
    if (!IsItemFeature(feature)
        && !IsBaseFeature(feature)
        && !IsCombineFeature(feature)) {
      continue;
    }

    bool output = features_[i].second;
    feature->SetRecoItem(item);
    if (!feature->ExtractFeature()) {
      continue;
    }
    if (output) {
      const std::vector<std::string>& feas = feature->GetFeatures();
      for (size_t j = 0; j < feas.size(); ++j) {
        fea_literal->push_back(feature->GetFeatureName() + kJoinTag + feas[j]);
      }
    }
  }
}

void BaseFeatureExtractor::ExtractSceneFeature(const reco::SceneInfo& scene,
                                              std::vector<std::string>* fea_literal) {
  CHECK(layout_done_);
  fea_literal->clear();
  for (size_t i = 0; i < features_.size(); ++i) {
    BaseFeature* feature = features_[i].first;
    if (!IsSceneFeature(feature)
        && !IsBaseFeature(feature)
        && !IsCombineFeature(feature)) {
      continue;
    }

    bool output = features_[i].second;
    feature->SetScene(scene);
    if (!feature->ExtractFeature()) {
      continue;
    }
    if (output) {
      const std::vector<std::string>& feas = feature->GetFeatures();
      for (size_t j = 0; j < feas.size(); ++j) {
        fea_literal->push_back(feature->GetFeatureName() + kJoinTag + feas[j]);
      }
    }
  }
}

void BaseFeatureExtractor::ResetUser(const reco::user::UserInfo& user) {
  CHECK(layout_done_);
  user_ = &user;
  user_fea_literal_.clear();
  for (size_t i = 0; i < features_.size(); ++i) {
    BaseFeature* feature = features_[i].first;
    if (!IsUserFeature(feature)
        && !IsBaseFeature(feature)) {
      continue;
    }

    bool output = features_[i].second;
    feature->SetUser(user);
    if (!feature->ExtractFeature()) {
      continue;
    }
    if (output) {
      const std::vector<std::string>& feas = feature->GetFeatures();
      for (size_t j = 0; j < feas.size(); ++j) {
        user_fea_literal_.push_back(feature->GetFeatureName() + kJoinTag + feas[j]);
      }
    }
  }
}

void BaseFeatureExtractor::ExtractUserItemFeature(const reco::RecoItem& item,
                                                  std::vector<std::string>* fea_literal) {
  CHECK(layout_done_);
  CHECK_NOTNULL(user_);
  fea_literal->clear();
  fea_literal->insert(fea_literal->end(), user_fea_literal_.begin(), user_fea_literal_.end());
  for (size_t i = 0; i < features_.size(); ++i) {
    BaseFeature* feature = features_[i].first;
    if (!IsItemFeature(feature)
        && !IsCombineFeature(feature)) {
      continue;
    }

    bool output = features_[i].second;
    feature->SetRecoItem(item);
    if (!feature->ExtractFeature()) {
      continue;
    }
    if (output) {
      const std::vector<std::string>& feas = feature->GetFeatures();
      for (size_t j = 0; j < feas.size(); ++j) {
        fea_literal->push_back(feature->GetFeatureName() + kJoinTag + feas[j]);
      }
    }
  }
}
void NewsItemFeatureExtractor::SetupFeatureLayout() {
  // 因为全是 item feature，可以使用 using
  using namespace item_fea;
  ClearFeatureExtractors();

  std::set<std::string> dedup;

  AddFeature<Bias>(&dedup, true);
  AddFeature<TitleBigram>(&dedup, false);
  AddFeature<TitleSkipBigram>(&dedup, false);
  AddFeature<TitleTrigram>(&dedup, true);
  AddFeature<Media>(&dedup, false);
  AddFeature<ShowTag>(&dedup, true);
  AddFeature<TitleCoreTag>(&dedup, true);
  AddFeature<Category>(&dedup, false);
  AddFeature<PlsaTopic>(&dedup, false);
  AddFeature<CategoryPlsaTopic>(&dedup, false);
  AddFeature<Paragraph>(&dedup, true);
  AddFeature<ShortParagraph>(&dedup, true);
  AddFeature<Image>(&dedup, true);
  AddFeature<ImageGif>(&dedup, true);
  AddFeature<Layout>(&dedup, true);
  AddFeature<OrigSource>(&dedup, false);
  AddFeature<Tag>(&dedup, false);

  AddFeature<CategoryPlsaTopic, Media>(&dedup, true);
  AddFeature<PlsaTopic, Media>(&dedup, true);
  AddFeature<Category, Image>(&dedup, true);
  AddFeature<Category, ImageGif>(&dedup, true);
  AddFeature<Category, Tag>(&dedup, true);
  AddFeature<Category, Paragraph>(&dedup, true);
  AddFeature<Category, ShortParagraph>(&dedup, true);
  AddFeature<Category, OrigSource>(&dedup, true);
  AddFeature<CategoryPlsaTopic, Image>(&dedup, true);
  AddFeature<CategoryPlsaTopic, ImageGif>(&dedup, true);
  AddFeature<CategoryPlsaTopic, Paragraph>(&dedup, true);
  AddFeature<CategoryPlsaTopic, ShortParagraph>(&dedup, true);
  AddFeature<PlsaTopic, ShowTag>(&dedup, true);
  // AddFeature<ShowTag, ShowTag>(&dedup, true);
  AddFeature<Image, Paragraph>(&dedup, true);
  AddFeature<Image, ShortParagraph>(&dedup, true);
  AddFeature<ImageGif, Paragraph>(&dedup, true);
  AddFeature<ImageGif, ShortParagraph>(&dedup, true);
  AddFeature<Category, Layout>(&dedup, true);
  AddFeature<ShowTag, Layout>(&dedup, true);
  AddFeature<Category,TitleTrigram>(&dedup, true);

  // AddFeature<Tag, Tag, Tag>(&dedup, false);
  AddFeature<Category, TitleBigram, Media>(&dedup, true);
  // AddFeature<Category, TitleSkipBigram, Media>(&dedup, true);
  AddFeature<Category, TitleTrigram, Media>(&dedup, true);
  AddFeature<Category, TitleCoreTag, Media>(&dedup, true);
  AddFeature<Category, ShowTag, Media>(&dedup, true);
  AddFeature<Category, Media, OrigSource>(&dedup, true);
  // AddFeature<Category, Layout, Media>(&dedup, true);

  layout_done_ = true;
}

void VideoItemFeatureExtractor::SetupFeatureLayout() {
  // 因为全是 item feature，可以使用 using
  using namespace item_fea;
  ClearFeatureExtractors();

  std::set<std::string> dedup;

  // single
//  AddFeature<Bias>(&dedup, true);
//  AddFeature<TitleUnigram>(&dedup, true);
  AddFeature<TitleUnigramNoMono>(&dedup, true);
//  AddFeature<TitleBigram>(&dedup, true);
//  AddFeature<TitleSkipBigram>(&dedup, true);
//  AddFeature<Media>(&dedup, true);
//  AddFeature<OrigSource>(&dedup, true);
  AddFeature<ShowTag>(&dedup, true);
//  AddFeature<Tag>(&dedup, true);
//  AddFeature<CategoryPlsaTopic>(&dedup, true);
//  AddFeature<PosterProblem>(&dedup, true);
//  AddFeature<PlayLen>(&dedup, true);
//  AddFeature<Category>(&dedup, true);

  // dual
//  AddFeature<TitleUnigram, OrigSource>(&dedup, true);
//  AddFeature<TitleUnigramNoMono, OrigSource>(&dedup, true);
//  AddFeature<TitleBigram, OrigSource>(&dedup, true);
//  AddFeature<TitleSkipBigram, OrigSource>(&dedup, true);
//  AddFeature<ShowTag, OrigSource>(&dedup, true);
//  AddFeature<Tag, OrigSource>(&dedup, true);
//  AddFeature<Tag, PlayLen>(&dedup, true);
//  AddFeature<Tag, PosterProblem>(&dedup, true);
//  AddFeature<CategoryPlsaTopic, OrigSource>(&dedup, true);
//  AddFeature<PlayLen, OrigSource>(&dedup, true);
//  AddFeature<ShowTag, ShowTag>(&dedup, true);
//  AddFeature<PosterProblem, PlayLen>(&dedup, true);
//  AddFeature<CategoryPlsaTopic, PosterProblem>(&dedup, true);
//  AddFeature<CategoryPlsaTopic, PlayLen>(&dedup, true);
//  AddFeature<Category, PosterProblem>(&dedup, true);
//  AddFeature<Category, PlayLen>(&dedup, true);

  // triple
//  AddFeature<Category, TitleBigram, OrigSource>(&dedup, true);
//  AddFeature<Category, ShowTag, OrigSource>(&dedup, true);

  layout_done_ = true;
}

void UserItemIdFeatureExtractor::SetupFeatureLayout() {
  // 因为全是 item feature，可以使用 using
  ClearFeatureExtractors();

  std::set<std::string> dedup;

  AddFeature<Bias>(&dedup, true);
  AddFeature<item_fea::ItemId>(&dedup, false);

  AddFeature<user_fea::Gender>(&dedup, false);
  AddFeature<user_fea::Age>(&dedup, false);
  AddFeature<user_fea::Education>(&dedup, false);
  AddFeature<user_fea::LifeStage>(&dedup, false);
  AddFeature<user_fea::EcomInterest>(&dedup, false);
  AddFeature<user_fea::Region>(&dedup, false);
  AddFeature<user_fea::TravelManner>(&dedup, false);
  AddFeature<user_fea::Category>(&dedup, false);
  AddFeature<user_fea::PlsaTopic>(&dedup, false);
  AddFeature<user_fea::RefreshChannel>(&dedup, false);
  AddFeature<user_fea::IsLoyal>(&dedup, false);
  AddFeature<user_fea::Tag>(&dedup, false);
  AddFeature<user_fea::ContentProblem>(&dedup, false);
  AddFeature<user_fea::AppUsage>(&dedup, false);

  AddFeature<item_fea::ItemId, user_fea::Gender>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::Age>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::Education>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::LifeStage>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::EcomInterest>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::Region>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::TravelManner>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::Category>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::PlsaTopic>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::RefreshChannel>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::IsLoyal>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::Tag>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::ContentProblem>(&dedup, true);
  AddFeature<item_fea::ItemId, user_fea::AppUsage>(&dedup, true);

  layout_done_ = true;
}

void UserItemCategoryFeatureExtractor::SetupFeatureLayout() {
  ClearFeatureExtractors();

  std::set<std::string> dedup;

  AddFeature<Bias>(&dedup, true);
  AddFeature<item_fea::TopCategory>(&dedup, false);

  AddFeature<user_fea::Gender>(&dedup, false);
  AddFeature<user_fea::Age>(&dedup, false);
  AddFeature<user_fea::Education>(&dedup, false);
  AddFeature<user_fea::LifeStage>(&dedup, false);
  AddFeature<user_fea::EcomInterest>(&dedup, false);
  AddFeature<user_fea::Region>(&dedup, false);
  AddFeature<user_fea::TravelManner>(&dedup, false);
  AddFeature<user_fea::Category>(&dedup, false);
  AddFeature<user_fea::PlsaTopic>(&dedup, false);
  AddFeature<user_fea::RefreshChannel>(&dedup, false);
  AddFeature<user_fea::IsLoyal>(&dedup, false);
  AddFeature<user_fea::Tag>(&dedup, false);
  AddFeature<user_fea::ContentProblem>(&dedup, false);
  AddFeature<user_fea::AppUsage>(&dedup, false);
  AddFeature<user_fea::SmCategory>(&dedup, false);
  AddFeature<user_fea::SmTag>(&dedup, false);
  AddFeature<user_fea::QueryCategory>(&dedup, false);
  AddFeature<user_fea::QueryTag>(&dedup, false);
  AddFeature<user_fea::QueryKeyword>(&dedup, false);
  
  // 基础自然属性
  AddFeature<item_fea::TopCategory, user_fea::Gender>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::Age>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::Education>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::LifeStage>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::EcomInterest>(&dedup, true);
  
  // 地域属性
  //AddFeature<item_fea::TopCategory, user_fea::Region>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::TravelManner>(&dedup, true);
  
  // 用户行为
  AddFeature<item_fea::TopCategory, user_fea::SmCategory>(&dedup, true);
  //AddFeature<item_fea::TopCategory, user_fea::SmTag>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::QueryCategory>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::QueryTag>(&dedup, true);
  //AddFeature<item_fea::TopCategory, user_fea::QueryKeyword>(&dedup, true);
  
  // 喜刷刷画像
  //AddFeature<item_fea::TopCategory, user_fea::Category>(&dedup, true);
  //AddFeature<item_fea::TopCategory, user_fea::PlsaTopic>(&dedup, true);
  //AddFeature<item_fea::TopCategory, user_fea::RefreshChannel>(&dedup, true);
  //AddFeature<item_fea::TopCategory, user_fea::IsLoyal>(&dedup, true);
  //AddFeature<item_fea::TopCategory, user_fea::Tag>(&dedup, true);
  //AddFeature<item_fea::TopCategory, user_fea::ContentProblem>(&dedup, true);
  //AddFeature<item_fea::TopCategory, user_fea::AppUsage>(&dedup, true);
 
  layout_done_ = true;
}

void ThirdPartyDataCategoryFeatureExtractor::SetupFeatureLayout() {
  ClearFeatureExtractors();

  std::set<std::string> dedup;

  AddFeature<Bias>(&dedup, true);
  AddFeature<item_fea::TopCategory>(&dedup, false);

  AddFeature<user_fea::Gender>(&dedup, false);
  AddFeature<user_fea::Age>(&dedup, false);
  AddFeature<user_fea::Education>(&dedup, false);
  AddFeature<user_fea::Career>(&dedup, false);
  AddFeature<user_fea::LifeStage>(&dedup, false);
  AddFeature<user_fea::EcomInterest>(&dedup, false);
  AddFeature<user_fea::Region>(&dedup, false);
  AddFeature<user_fea::TravelManner>(&dedup, false);
  AddFeature<user_fea::Category>(&dedup, false);
  AddFeature<user_fea::PlsaTopic>(&dedup, false);
  AddFeature<user_fea::RefreshChannel>(&dedup, false);
  AddFeature<user_fea::IsLoyal>(&dedup, false);
  AddFeature<user_fea::Tag>(&dedup, false);
  AddFeature<user_fea::ContentProblem>(&dedup, false);
  AddFeature<user_fea::AppUsage>(&dedup, false);
  AddFeature<user_fea::SmCategory>(&dedup, false);
  AddFeature<user_fea::SmTag>(&dedup, false);
  AddFeature<user_fea::QueryCategory>(&dedup, false);
  AddFeature<user_fea::QueryTag>(&dedup, false);
  AddFeature<user_fea::QueryKeyword>(&dedup, false);
  AddFeature<user_fea::TaobaoQueryCategory>(&dedup, false);
  AddFeature<user_fea::TaobaoQueryTag>(&dedup, false);
  AddFeature<user_fea::TaobaoQueryKeyword>(&dedup, false);
  AddFeature<user_fea::UcbLogCategory>(&dedup, false);
  AddFeature<user_fea::UcbLogTag>(&dedup, false);
  AddFeature<user_fea::UcbLogKeyword>(&dedup, false);

  // 基础自然属性
  AddFeature<item_fea::TopCategory, user_fea::Gender>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::Age>(&dedup, true);
  //AddFeature<item_fea::TopCategory, user_fea::Education>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::Career>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::LifeStage>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::EcomInterest>(&dedup, true);
  
  // 地域属性
  //AddFeature<item_fea::TopCategory, user_fea::Region>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::TravelManner>(&dedup, true);
  
  // 用户行为
  AddFeature<item_fea::TopCategory, user_fea::SmCategory>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::SmTag>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::QueryCategory>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::QueryTag>(&dedup, true);
  //AddFeature<item_fea::TopCategory, user_fea::QueryKeyword>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::UcbLogCategory>(&dedup, true);
  AddFeature<item_fea::TopCategory, user_fea::UcbLogTag>(&dedup, true);
  
  layout_done_ = true;
}

void ThirdPartyDataItemFeatureExtractor::SetupFeatureLayout() {
  ClearFeatureExtractors();

  std::set<std::string> dedup;

  // item fea
  AddFeature<Bias>(&dedup, true);
  AddFeature<item_fea::Category>(&dedup, false);
  AddFeature<item_fea::Tag>(&dedup, false);
  AddFeature<item_fea::LdaTopic>(&dedup, false);
  //AddFeature<item_fea::CategoryPlsaTopic>(&dedup, false);
  //AddFeature<item_fea::ItemId>(&dedup, false);

  // user fea
  AddFeature<user_fea::Gender>(&dedup, false);
  AddFeature<user_fea::Age>(&dedup, false);
  AddFeature<user_fea::Decade>(&dedup, false);
  AddFeature<user_fea::Education>(&dedup, false);
  AddFeature<user_fea::Career>(&dedup, false);
  AddFeature<user_fea::LifeStage>(&dedup, false);
  AddFeature<user_fea::EcomInterest>(&dedup, false);
  AddFeature<user_fea::HasCar>(&dedup, false);
  AddFeature<user_fea::HasPet>(&dedup, false);
  //AddFeature<user_fea::Region>(&dedup, false);
  //AddFeature<user_fea::TravelManner>(&dedup, false);
  //AddFeature<user_fea::Category>(&dedup, false);
  //AddFeature<user_fea::PlsaTopic>(&dedup, false);
  //AddFeature<user_fea::RefreshChannel>(&dedup, false);
  //AddFeature<user_fea::IsLoyal>(&dedup, false);
  //AddFeature<user_fea::Tag>(&dedup, false);
  //AddFeature<user_fea::ContentProblem>(&dedup, false);
  //AddFeature<user_fea::AppUsage>(&dedup, false);
  AddFeature<user_fea::SmCategory>(&dedup, false);
  AddFeature<user_fea::SmTag>(&dedup, false);
  AddFeature<user_fea::QueryCategory>(&dedup, false);
  AddFeature<user_fea::QueryTag>(&dedup, false);
  AddFeature<user_fea::QueryKeyword>(&dedup, false);
  AddFeature<user_fea::TaobaoQueryCategory>(&dedup, false);
  AddFeature<user_fea::TaobaoQueryTag>(&dedup, false);
  AddFeature<user_fea::TaobaoQueryKeyword>(&dedup, false);
  AddFeature<user_fea::UcbLogCategory>(&dedup, false);
  AddFeature<user_fea::UcbLogTag>(&dedup, false);
  AddFeature<user_fea::UcbLogKeyword>(&dedup, false);

  // combine fea
  // 特征组合原则：粗粒度特征预测粗粒度目标(category)，细粒度特征预测细粒度目标(tag, item id)

  // Category
  /*
  AddFeature<item_fea::Category, user_fea::Gender>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::Age>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::Decade>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::Education>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::Career>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::LifeStage>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::EcomInterest>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::HasCar>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::HasPet>(&dedup, true);
  //AddFeature<item_fea::Category, user_fea::Region>(&dedup, true);
  //AddFeature<item_fea::Category, user_fea::TravelManner>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::SmCategory>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::SmTag>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::QueryCategory>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::QueryTag>(&dedup, true);
  //AddFeature<item_fea::Category, user_fea::QueryKeyword>(&dedup, true);
  //AddFeature<item_fea::Category, user_fea::TaobaoQueryCategory>(&dedup, true);
  //AddFeature<item_fea::Category, user_fea::TaobaoQueryTag>(&dedup, true);
  //AddFeature<item_fea::Category, user_fea::TaobaoQueryKeyword>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::UcbLogCategory>(&dedup, true);
  AddFeature<item_fea::Category, user_fea::UcbLogTag>(&dedup, true);
  //AddFeature<item_fea::Category, user_fea::UcbLogKeyword>(&dedup, true);
  */

  // tag
  //AddFeature<item_fea::Tag, user_fea::Gender>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::Age>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::Decade>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::Education>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::Career>(&dedup, true);
  AddFeature<item_fea::Tag, user_fea::LifeStage>(&dedup, true);
  AddFeature<item_fea::Tag, user_fea::EcomInterest>(&dedup, true);
  AddFeature<item_fea::Tag, user_fea::HasCar>(&dedup, true);
  AddFeature<item_fea::Tag, user_fea::HasPet>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::TravelManner>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::SmCategory>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::SmTag>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::QueryCategory>(&dedup, true);
  AddFeature<item_fea::Tag, user_fea::QueryTag>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::QueryKeyword>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::TaobaoQueryCategory>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::TaobaoQueryTag>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::TaobaoQueryKeyword>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::UcbLogCategory>(&dedup, true);
  AddFeature<item_fea::Tag, user_fea::UcbLogTag>(&dedup, true);
  //AddFeature<item_fea::Tag, user_fea::UcbLogKeyword>(&dedup, true);

  // lda topic
  //AddFeature<item_fea::LdaTopic, user_fea::Gender>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::Age>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::Decade>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::Education>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::Career>(&dedup, true);
  AddFeature<item_fea::LdaTopic, user_fea::LifeStage>(&dedup, true);
  AddFeature<item_fea::LdaTopic, user_fea::EcomInterest>(&dedup, true);
  AddFeature<item_fea::LdaTopic, user_fea::HasCar>(&dedup, true);
  AddFeature<item_fea::LdaTopic, user_fea::HasPet>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::TravelManner>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::SmCategory>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::SmTag>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::QueryCategory>(&dedup, true);
  AddFeature<item_fea::LdaTopic, user_fea::QueryTag>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::QueryKeyword>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::TaobaoQueryCategory>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::TaobaoQueryTag>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::TaobaoQueryKeyword>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::UcbLogCategory>(&dedup, true);
  AddFeature<item_fea::LdaTopic, user_fea::UcbLogTag>(&dedup, true);
  //AddFeature<item_fea::LdaTopic, user_fea::UcbLogKeyword>(&dedup, true);

  layout_done_ = true;
}

}  // namespace ml
}  // namespace reco
