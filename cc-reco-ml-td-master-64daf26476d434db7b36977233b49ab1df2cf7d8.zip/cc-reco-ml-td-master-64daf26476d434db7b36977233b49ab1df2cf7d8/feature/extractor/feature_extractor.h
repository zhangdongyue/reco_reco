#pragma once

#include <string>
#include <vector>
#include <utility>
#include <typeinfo>
#include <set>

#include "reco/base/common/atomic.h"
#include "base/common/base.h"
#include "reco/ml/feature/base/base_feature.h"
#include "reco/ml/feature/base/base_user_feature.h"
#include "reco/ml/feature/base/base_item_feature.h"
#include "reco/ml/feature/base/dual_combine_feature.h"
#include "reco/ml/feature/base/triple_combine_feature.h"

namespace reco {
namespace ml {

/**
 * 特征抽取基类，实现了主要的特征抽取功能
 * 并执行抽取，输出最终的组合特征
 *
 * 用户基于此类派生并重载 SetupFeatureLayout 函数，
 * 以指定具体要使用的特征组合
 *
 * 比如图文质量特征抽取与视频质量特征抽取所用的类集合不同，
 * 实现不同的 layout 即可
 *
 * 派生类直接实现在本 h 及 cc 文件中即可
 *
 */
class NewsItemFeatureExtractor;
class VideoItemFeatureExtractor;
class UserItemIdFeatureExtractor;
class BaseFeatureExtractor {
 public:
  BaseFeatureExtractor();
  virtual ~BaseFeatureExtractor();

  // 实现特征的 layout
  // NOTE: 注意事项
  // 1. 单边特征要写在多边特征的前面
  // 2. 要求每个特征类的 GetFeatureName 不同
  // 3. 要先调用这个函数。再进行下面的 ExtractFeature
  virtual void SetupFeatureLayout() = 0;

  // bias 特征的文本和签名，用于某些过滤场景
  const std::string& GetBiasLiteral() const {
    return bias_literal_;
  }

  uint64 GetBiasSign() const {
    return bias_sign_;
  }
  // 执行特征抽取
  // 区分只抽取 user 特征、只抽取 item 特征、抽取 user 和 item 组合特征几种情况
  //
  // 1. 仅抽取 item 特征
  void ExtractItemFeature(const reco::RecoItem& item, std::vector<std::string>* fea_literal);

  // 2. 仅抽取 user 特征
  void ExtractUserFeature(const reco::user::UserInfo& user, std::vector<std::string>* fea_literal);

  // 2. 仅抽取 scene 特征
  void ExtractSceneFeature(const reco::SceneInfo& user, std::vector<std::string>* fea_literal);

  // 3. 抽取 user 和 item 的组合特征
  // 首先 ResetUser 以抽取 user 特征
  void ResetUser(const reco::user::UserInfo& user);
  // 然后 ExtractUserItemFeature 以抽签 item 特征和 user item的组合特征
  void ExtractUserItemFeature(const reco::RecoItem& item, std::vector<std::string>* fea_literal);
 protected:
  bool IsBaseFeature(const BaseFeature* feature) const {
    return feature->GetFeatureType() == BaseFeature::kBaseFea;
  }

  bool IsCombineFeature(const BaseFeature* feature) const {
    return feature->GetFeatureType() == BaseFeature::kCombineFea;
  }

  // 是否可以用于抽取 user 特征
  bool IsUserFeature(const BaseFeature* feature) const {
    return feature->GetFeatureType() == BaseFeature::kUserFea;
  }

  bool IsItemFeature(const BaseFeature* feature) const {
    return feature->GetFeatureType() == BaseFeature::kItemFea;
  }

  bool IsSceneFeature(const BaseFeature* feature) const {
    return feature->GetFeatureType() == BaseFeature::kSceneFea;
  }

  void ClearFeatureExtractors() {
    for (size_t i = 0; i < features_.size(); ++i) {
      delete features_[i].first;
    }
    features_.clear();
    layout_done_ = false;
  }
  // 从已有的特征类中，根据传入模版的类型，找到匹配这个类型的指针, 从而构建双边特征类
  template<class A, class B>
  BaseFeature* NewCombineFeature() {
    BaseFeature* a = NULL;
    for (auto it = features_.begin(); it != features_.end(); ++it) {
      if (typeid(*(it->first)) == typeid(A)) {
        a = it->first;
        break;
      }
    }
    CHECK_NOTNULL(a);
  
    BaseFeature* b = NULL;
    for (auto it = features_.begin(); it != features_.end(); ++it) {
      if (typeid(*(it->first)) == typeid(B)) {
        b = it->first;
        break;
      }
    }
    CHECK_NOTNULL(b);
  
    return new DualCombineFeature<A, B>(dynamic_cast<const A*>(a), dynamic_cast<const B*>(b));  // NOLINT
  }

  // 从已有的特征类中，根据传入模版的类型，找到匹配这个类型的指针, 从而构建双边特征类
  template<class A, class B, class C>
  BaseFeature* NewCombineFeature() {
    BaseFeature* a = NULL;
    for (auto it = features_.begin(); it != features_.end(); ++it) {
      if (typeid(*(it->first)) == typeid(A)) {
        a = it->first;
        break;
      }
    }
    CHECK_NOTNULL(a);
  
    BaseFeature* b = NULL;
    for (auto it = features_.begin(); it != features_.end(); ++it) {
      if (typeid(*(it->first)) == typeid(B)) {
        b = it->first;
        break;
      }
    }
    CHECK_NOTNULL(b);
  
    BaseFeature* c = NULL;
    for (auto it = features_.begin(); it != features_.end(); ++it) {
      if (typeid(*(it->first)) == typeid(C)) {
        c = it->first;
        break;
      }
    }
    CHECK_NOTNULL(c);
    return new TripleCombineFeature<A, B, C>(
        dynamic_cast<const A*>(a), dynamic_cast<const B*>(b), dynamic_cast<const C*>(c));  // NOLINT
  }
  
  template<class T>
  void AddFeature(std::set<std::string>* dedup, bool output) {
    BaseFeature* feature = new T();
    CHECK(dedup->find(feature->GetFeatureName()) == dedup->end());
    dedup->insert(feature->GetFeatureName());
    features_.push_back(std::make_pair(feature, output));
    VLOG(1) << "add feature: " << feature->GetFeatureName() << ", output: " << output;
  }

  template<class A, class B>
  void AddFeature(std::set<std::string>* dedup, bool output) {
    BaseFeature* feature = NewCombineFeature<A, B>();
    CHECK(dedup->find(feature->GetFeatureName()) == dedup->end());
    dedup->insert(feature->GetFeatureName());
    features_.push_back(std::make_pair(feature, output));
    VLOG(1) << "add feature: " << feature->GetFeatureName() << ", output: " << output;
  }

  template<class A, class B, class C>
  void AddFeature(std::set<std::string>* dedup, bool output) {
    BaseFeature* feature = NewCombineFeature<A, B, C>();
    CHECK(dedup->find(feature->GetFeatureName()) == dedup->end());
    dedup->insert(feature->GetFeatureName());
    features_.push_back(std::make_pair(feature, output));
    VLOG(1) << "add feature: " << feature->GetFeatureName() << ", output: " << output;
  }
protected:
  const std::string kJoinTag;
  std::atomic<bool> layout_done_;
  // pair.first: feature pointer,
  // pair.second: is output this feature, if true output this feature
  // 只能用 vector，因为要保证特征调用顺序严格按照构建顺序
  std::vector<std::pair<BaseFeature*, bool> > features_;
  const reco::user::UserInfo* user_;
  std::vector<std::string> user_fea_literal_;
  // bias 特征的文本和签名，用于某些过滤场景
  std::string bias_literal_;
  uint64 bias_sign_;
};

class NewsItemFeatureExtractor : public BaseFeatureExtractor {
 public:
  NewsItemFeatureExtractor() {}
  virtual ~NewsItemFeatureExtractor() {}

  virtual void SetupFeatureLayout();
};

// TODO(lidecong) : from here
class VideoItemFeatureExtractor : public BaseFeatureExtractor {
 public:
  VideoItemFeatureExtractor() {}
  virtual ~VideoItemFeatureExtractor() {}

  virtual void SetupFeatureLayout();
};

class UserItemIdFeatureExtractor : public BaseFeatureExtractor {
 public:
  UserItemIdFeatureExtractor() {}
  virtual ~UserItemIdFeatureExtractor() {}

  virtual void SetupFeatureLayout();
};

// 冷启动类别预测用
// 使用第三方数据预测 category 点击
class UserItemCategoryFeatureExtractor : public BaseFeatureExtractor {
 public:
  UserItemCategoryFeatureExtractor() {}
  virtual ~UserItemCategoryFeatureExtractor() {}

  virtual void SetupFeatureLayout();
};

// 使用第三方数据预测 profile 中的 category
class ThirdPartyDataCategoryFeatureExtractor : public BaseFeatureExtractor {
 public:
  ThirdPartyDataCategoryFeatureExtractor() {}
  virtual ~ThirdPartyDataCategoryFeatureExtractor() {}

  virtual void SetupFeatureLayout();
};

// 使用第三方数据直接预测 item tag, topic, item id
class ThirdPartyDataItemFeatureExtractor : public BaseFeatureExtractor {
 public:
  ThirdPartyDataItemFeatureExtractor() {}
  virtual ~ThirdPartyDataItemFeatureExtractor() {}

  virtual void SetupFeatureLayout();
};

}  // namespace ml
}  // namespace reco
