#include "reco/ml/online_model/predictor/itemq_predictor.h"

#include <vector>
#include <utility>
#include "serving_base/utility/time_helper.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "reco/ml/online_model/proto/online_model.pb.h"
#include "reco/ml/model/lr_model.h"
#include "reco/ml/feature/extractor/feature_extractor.h"

namespace reco {
namespace ml {
ItemQPredictor::ItemQPredictor(const std::string& data_type, const OlmMqDenseHashLRModel* model) {
  if (data_type == "news") {
    fea_extractor_ = new reco::ml::NewsItemFeatureExtractor();
    item_type_set_.insert(reco::kNews);
    item_type_set_.insert(reco::kReading);
  } else if (data_type == "video") {
    fea_extractor_ = new reco::ml::VideoItemFeatureExtractor();
    item_type_set_.insert(reco::kPureVideo);
  } else {
    LOG(ERROR) << "illegal data type:" << data_type;
    return;
  }
  fea_extractor_->SetupFeatureLayout();
  model_ = model;
}

ItemQPredictor::~ItemQPredictor() {
  delete fea_extractor_;
  model_ = NULL;
}

bool ItemQPredictor::Predict(const RecoItem& reco_item, PredictResult* result) {
  if (item_type_set_.find(reco_item.identity().type()) == item_type_set_.end()) {
    LOG(INFO) << "skip not correct item type: " << reco_item.identity().item_id();
    return false;
  }

  fea_literal_.clear();
  fea_extractor_->ExtractItemFeature(reco_item, &fea_literal_);

  result->item_id = reco_item.identity().item_id();
  result->title = reco_item.title();
  model_->Predict(fea_literal_, &result->sum_weight, &result->hits, &result->ctr, NULL);
  return true;
}
}
}
