#pragma once
#include <vector>
#include <utility>
#include <string>
#include <unordered_set>

#include "base/common/basic_types.h"
#include "reco/base/common/singleton.h"

#include "reco/ml/model/lr_model.h"

namespace reco {
class RecoItem;
class OlmMqDenseHashLRModel;
namespace ml {
class BaseFeatureExtractor;
// thread not safe
class ItemQPredictor {
 public:
  struct PredictResult {
    uint64 item_id;
    std::string title;
    int hits;
    double ctr;
    double sum_weight;
  };

  ItemQPredictor(const std::string& data_type, const OlmMqDenseHashLRModel* model);  // news or video
  ~ItemQPredictor();

  bool Predict(const RecoItem& reco_item, PredictResult* result);
 private:
  reco::ml::BaseFeatureExtractor* fea_extractor_;
  std::vector<std::string> fea_literal_;
  std::unordered_set<int> item_type_set_;
  // singleton
  const OlmMqDenseHashLRModel* model_;
};
}
}
