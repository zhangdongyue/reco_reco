#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/thread/thread.h"
#include "net/rpc/rpc.h"
#include "net/counter/export.h"
#include "serving_base/utility/signal.h"

#include "reco/ml/online_model/learner/itemq_learner.h"
#include "reco/ml/online_model/server/itemq_learner_service_impl.h"

DEFINE_int32(port, 20004, "item classify server port");
DEFINE_int32(thread_num, 4, "thread_num");
DEFINE_string(prior_path, "../data/prior_model.txt", "for start init");
int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "online model learner");

  // start learning
  reco::ml::ItemQLearnerIns::instance().Init();
  std::string reason;
  CHECK(reco::ml::ItemQLearnerIns::instance().Reinit(base::FilePath(FLAGS_prior_path), &reason)) << reason;
  reco::ml::ItemQLearnerIns::instance().Start();

  // export service
  reco::ml::ItemQLearnerServiceImpl service;

  net::rpc::RpcServer::Options opt;
  opt.port = FLAGS_port;
  opt.server_thread_num = FLAGS_thread_num;
  opt.pump_thread_num = 4;
  net::rpc::RpcServer *server = new net::rpc::RpcServer(opt);

  CHECK(server->ExportService(&service));

  server->Start();
  LOG(INFO) << "itemq leaner server start";

  net::counter::HttpCounterExport();

  serving_base::SignalCatcher::Initialize();

  serving_base::SignalCatcher::WaitForSignal();

  server->Stop();
  reco::ml::ItemQLearnerIns::instance().stop();
  LOG(INFO) << "server frame stop";

  return 0;
}
