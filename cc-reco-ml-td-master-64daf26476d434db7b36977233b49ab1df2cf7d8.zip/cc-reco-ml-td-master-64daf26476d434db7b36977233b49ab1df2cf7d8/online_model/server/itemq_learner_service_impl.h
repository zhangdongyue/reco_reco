#pragma once

#include "reco/ml/online_model/proto/itemq_learner.pb.h"
namespace reco {
namespace ml {

class ItemQLearnerServiceImpl: public ItemQLearnerService {
 public:
  virtual ~ItemQLearnerServiceImpl() {}

  virtual void ReInitModel(::stumy::RpcController* controller,
                           const Reload::Request* request,
                           Reload::Response* response,
                           ::Closure* done);
 private:
  static int64 prev_init_time_;
  static int64 prev_dump_time_;
  static thread::Mutex learner_mutex_;  // any op must be mutex.
};
}  // namespace
}  // namespace
