#include "reco/ml/online_model/server/itemq_learner_service_impl.h"

#include <string>

#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/common/closure.h"
#include "base/time/timestamp.h"
#include "base/strings/string_printf.h"
#include "net/rpc/rpc.h"

#include "reco/ml/online_model/learner/itemq_learner.h"
#include "reco/ml/online_model/proto/itemq_learner.pb.h"

namespace reco {
namespace ml {

DEFINE_int32(rpc_min_interval, 100, "minimal rpc interval in seconds");

thread::Mutex ItemQLearnerServiceImpl::learner_mutex_;
int64 ItemQLearnerServiceImpl::prev_init_time_ = 0;
int64 ItemQLearnerServiceImpl::prev_dump_time_ = 0;

void ItemQLearnerServiceImpl::ReInitModel(::stumy::RpcController* controller,
                                          const Reload::Request* request,
                                          Reload::Response* response,
                                          ::Closure* done) {
  LOG(INFO) << "Rpc server recv request to re-init model"
            << ", name=" << request->name()
            << ", date_back=" << request->date_back();

  ::ScopedClosure auto_closure(done);

  int ret = 1;
  std::string reason = "Protective initialization";
  std::string name = request->name();

  // 保护性初始化
  response->set_ret_code(1);
  response->set_reason(reason);
  response->set_name(name);

  if (base::GetTimestamp() - prev_init_time_ < FLAGS_rpc_min_interval * 1e6) {
    response->set_reason("Reinit too frequently.");
    LOG(WARNING) << response->reason();
    return;
  }

  thread::AutoLock lock(&learner_mutex_);

  if (!ItemQLearnerIns::instance().has_initialized()) {
    response->set_reason("Learner under initialization, accept no request.");
    LOG(WARNING) << response->reason();
    return;
  }

  if (name == "prior") {
    ret = ItemQLearnerIns::instance().Reinit(request->path(), &reason);
  } else {
    reason = base::StringPrintf("Invalid name=%s, should be prior", name.c_str());
    ret = 1;
  }

  response->set_ret_code(ret);

  // 执行失败
  if (ret != 0) {
    response->set_reason(reason);
    LOG(ERROR) << "failed to reinit learner model"
               << ", name=" << name
               << ", path=" << request->path()
               << ", reason=" << reason;
    return;
  }

  reason = base::StringPrintf("Successfully reinit learner model"
                              ", name=%s, path=%s", name.c_str(), request->path().c_str());
  response->set_reason(reason);
  LOG(INFO) << reason;

  prev_init_time_ = base::GetTimestamp();
  return;
}
}  // namespace
}  // namespace
