#include "reco/ml/online_model/learner/model.h"

#include <vector>
#include <string>
#include <utility>
#include <algorithm>
#include <fstream>

#include "base/common/basic_types.h"
#include "base/random/pseudo_random.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/time/time.h"
#include "base/file/file_path.h"
#include "base/common/logging.h"
#include "reco/ml/auc/auc.h"
#include "reco/ml/ftrl/define.h"
#include "reco/ml/common/math_util.h"

namespace reco {
namespace ml  {
DEFINE_string(prior_model_path, "./data/model.txt", "prior model");
class ModelTest: public testing::Test {
 public:
  void SetUp() {
    std::string reason;
    ASSERT_TRUE(olm_model_.ReInitWithPriorModel(base::FilePath(FLAGS_prior_model_path), &reason)) << reason;
  }

  void TearDown() {
    LOG(INFO) << "tear dwon!";
  }
 protected:
  OlmModel olm_model_;
};

TEST_F(ModelTest, TestLearnOneSampel) {
  struct {
    int show;
    int click;
    std::string feas;
  } cases[] = {
    {100, 100, "1,2,3,4"},
    {100, 50, "2,3,4"},
    {100, 10, "3,4"},
  };

  int num = ARRAYSIZE_UNSAFE(cases);
  std::vector<std::pair<uint64, double> > fea_w;
  std::vector<std::string> tokens;
  PredCTR pctr;
  std::vector<Sample> samples;
  std::vector<uint64> feas;
  base::PseudoRandom random;
  std::unordered_map<uint64, double> post_weight;
  for (int i = 0; i < num; ++i) {
    // cal prior ctr
    tokens.clear();
    base::SplitString(cases[i].feas, ",", &tokens);
    feas.clear();
    for (int j = 0; j < (int)tokens.size(); ++j) {
      feas.push_back(base::ParseUint64OrDie(tokens[j]));
    }

    for (int k = 0; k < cases[i].show; ++k) {
      samples.push_back(Sample());
      samples.back().weight = 1.0;
      int a = random.GetInt(0, cases[i].show);
      samples.back().pos_weight = 1.0;
      if (a > cases[i].click) samples.back().pos_weight = 0;
      samples.back().elements.assign(feas.begin(), feas.end());
      samples.back().prior = olm_model_.CalcPriorCtr(samples.back().elements);
      // LOG(INFO) << "prior:  "  << samples.back().prior;
    }
  }

  std::random_shuffle(samples.begin(), samples.end());
  std::unordered_map<uint64, double> model;
  for (int i = 0; i < (int)samples.size(); ++i)  {
    olm_model_.LearnOneSample(samples[i], &fea_w, &pctr);
    for (int j = 0; j < (int)fea_w.size(); ++j) {
      model[fea_w[j].first] = fea_w[j].second;
    }
  }

  for (auto it = model.begin(); it != model.end(); ++it) {
    LOG(INFO) << it->first << " : " << it->second;
  }
  ASSERT_GT(model[1], 0.03);
  ASSERT_GT(model[2], 0.03);
  ASSERT_NEAR(model[2], model[1], 0.1);
  ASSERT_GT(-0.01, model[3]);
  ASSERT_GT(-0.01, model[4]);
  ASSERT_NEAR(model[3], model[4], 0.01);
}

static void LoadSamples(base::FilePath sample_file, thread::BlockingQueue<Sample>* sample_queue) {
  std::ifstream fin(sample_file.value());
  std::string line;
  std::vector<std::string> tokens;
  std::vector<uint64> feas;
  std::vector<Sample> samples;
  base::PseudoRandom random;
  while (true) {
    if (sample_queue->Size() > 100000) {
      LOG(INFO) << "sleep for 5 second";
      base::SleepForSeconds(5);
      continue;
    }

    if (!std::getline(fin, line)) break;
    tokens.clear();
    base::SplitString(line, " ", &tokens);
    if (tokens.size() < 3) continue;
    int show = base::ParseIntOrDie(tokens[0]) / 10;
    int click = base::ParseIntOrDie(tokens[1]) / 10;
    // if (click > 10 and click < 61) continue;

    feas.clear();
    for (int i = 2; i < (int)tokens.size(); ++i) {
      size_t pos = tokens[i].find(":");
      CHECK_NE(pos, std::string::npos) << tokens[i];
      feas.push_back(base::ParseUint64OrDie(tokens[i].substr(0, pos)));
    }
    // generate sample
    for (int k = 0; k < show; ++k) {
      samples.push_back(Sample());
      samples.back().weight = 1.0;
      int a = random.GetInt(0, show);
      samples.back().pos_weight = 1.0;
      if (a > click) samples.back().pos_weight = 0;
      samples.back().elements.assign(feas.begin(), feas.end());
      samples.back().prior = 0.5;
    }

    if (samples.size() > 10000) {
      std::random_shuffle(samples.begin(), samples.end());
      for (int i = 0; i < (int)samples.size(); ++i) {
        sample_queue->Put(samples[i]);
      }
      samples.clear();
    }
  }

  if (samples.size() > 0) {
    std::random_shuffle(samples.begin(), samples.end());
    for (int i = 0; i < (int)samples.size(); ++i) {
      sample_queue->Put(samples[i]);
    }
    samples.clear();
  }
  LOG(INFO) << "finish loading remain: " << sample_queue->Size();
  sample_queue->Close();
}

static void LoadAllSamples(const base::FilePath& sample_file, std::vector<Sample>* samples) {
  std::ifstream fin(sample_file.value());
  std::string line;
  std::vector<std::string> tokens;
  std::vector<uint64> feas;
  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, " ", &tokens);
    if (tokens.size() < 3) continue;
    samples->push_back(Sample());
    samples->back().weight = base::ParseIntOrDie(tokens[0]);
    samples->back().pos_weight = base::ParseIntOrDie(tokens[1]);
    samples->back().prior = 0.5;
    for (int i = 2; i < (int)tokens.size(); ++i) {
      size_t pos = tokens[i].find(":");
      CHECK_NE(pos, std::string::npos) << tokens[i];
      samples->back().elements.push_back(base::ParseUint64OrDie(tokens[i].substr(0, pos)));
    }
  }
}

TEST_F(ModelTest, TestItemQCase) {
  // loadcases
  thread::ThreadPool pool(1);
  thread::BlockingQueue<Sample> sample_queue;
  base::FilePath sample_path("./data/train_ins");
  pool.AddTask(::NewCallback(&reco::ml::LoadSamples, sample_path, &sample_queue));
  Sample sample;
  PredCTR pctr;
  std::unordered_map<uint64, double> model;
  std::vector<std::pair<uint64, double> > fea_w;
  while (!(sample_queue.Closed() && sample_queue.Empty())) {
    if (!sample_queue.Take(&sample)) break;
    olm_model_.LearnOneSample(sample, &fea_w, &pctr);
    // LOG(INFO) << sample.pos_weight << " " << sample.elements.size();
    for (int j = 0; j < (int)fea_w.size(); ++j) {
      model[fea_w[j].first] = fea_w[j].second;
    }
  }
  // predict for calc auc
  pool.JoinAll();
  std::vector<Sample> samples;
  LoadAllSamples(sample_path, &samples);
  std::vector<PredCTR> pctrs;
  pctrs.reserve(samples.size());
  for (int i = 0; i < (int)samples.size(); ++i) {
    pctrs.push_back(PredCTR());
    float sum_w = 0;
    for (int j = 0; j < (int)samples[i].elements.size(); ++j) {
      auto it = model.find(samples[i].elements[j]);
      if (it == model.end()) continue;
      sum_w += it->second;
    }
    pctrs.back().prediction = logit(sum_w);
    pctrs.back().pos_weight = samples[i].pos_weight;
    pctrs.back().neg_weight = samples[i].weight - samples[i].pos_weight;
  }

  double auc = CalcRocAuc(pctrs);
  LOG(INFO) << auc;
}
}
}
