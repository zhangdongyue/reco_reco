#include "reco/ml/online_model/learner/itemq_learner.h"
#include <vector>
#include <string>
#include <unordered_map>

#include "base/common/gflags.h"
#include "base/common/scoped_ptr.h"
#include "base/hash_function/term.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/strings/string_number_conversions.h"
#include "serving_base/utility/time_helper.h"
#include "reco/base/kafka_c/api_cc/producer.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/online_model/learner/model.h"
#include "reco/ml/online_model/proto/online_model.pb.h"
#include "reco/ml/ftrl/define.h"

namespace reco {
namespace ml {

DEFINE_string(item_kafka_brokers, "11.251.206.207:9092", "for incr item id");
DEFINE_string(item_topic, "reco_item", "reco item kafka topic");
DEFINE_int32(item_partition, 32, "max sendout fea num");
DEFINE_string(start_time, "2017-03-01 00:00:00", "start time for read data");

DEFINE_string(fea_topic, "itemq_olm_fea", "itemq fea weight topic");
DEFINE_string(fea_brokers, "11.251.176.1:9092", "itemq fea weight topic");

DEFINE_int32(max_send_out, 1000, "max sendout fea num");
DEFINE_int32(sample_buddle, 100, "update fea, after each buddle");
DEFINE_int32(message_buffer_size, 10000, "message buf size");

ItemQLearner::ItemQLearner() {
}

ItemQLearner::~ItemQLearner() {
  stop();
  delete pool_;
  delete fea_producer_;
  delete fea_extractor_;
  delete consumer_;
}

void ItemQLearner::Init() {
  stop_ = false;
  fea_extractor_ = new reco::ml::NewsItemFeatureExtractor();
  fea_extractor_->SetupFeatureLayout();

  fea_producer_ = new reco::kafka::Producer(FLAGS_fea_brokers, FLAGS_fea_topic);
  pool_ = new thread::ThreadPool(2);

  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_item_topic;
  options.partition_num = FLAGS_item_partition;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = "0";
  uint64 timestamp = 0;
  if (!serving_base::TimeHelper::StringToTimestamp(FLAGS_start_time, serving_base::TimeHelper::kSecond,
                                                   &timestamp)) {
    CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond,
                                                        &timestamp));
  }
  options.start_timestamp = timestamp / 1000000;
  consumer_ = new reco::kafka::Consumer(FLAGS_item_kafka_brokers, options);

  fea_queue_ = new thread::BlockingQueue<const std::vector<std::pair<uint64, double> >* >();
  pool_->AddTask(::NewCallback(this, &ItemQLearner::PushFeaWorker, fea_queue_));
}

void ItemQLearner::stop() {
  if (stop_) return;

  Learner::stop();

  stop_ = true;
  fea_queue_->Close();
  pool_->JoinAll();
}

bool ItemQLearner::ExtractFeature(const reco::RecoItem& reco_item, std::vector<Sample>* samples) {
  if (0 == reco_item.quality_attr().posterior_itemq()) {
    return false;
  }
  // feature
  strs_.clear();
  fea_extractor_->ExtractItemFeature(reco_item, &strs_);
  // LOG(INFO) << "item: " << reco_item.identity().item_id() << " " << strs_.size();
  if (strs_.empty())  {
    return false;
  }

  std::vector<uint64> signs;
  for (size_t i = 0; i < strs_.size(); ++i) {
    uint64 sign = base::CalcTermSign(strs_[i].c_str(), strs_[i].size());
    signs.push_back(sign);
  }
  
  VLOG(1) << "get reco item: " << reco_item.identity().item_id();
  int show = 10;
  int click = reco_item.quality_attr().posterior_itemq() / 10;
  for (int i = 0; i < show; ++i) {
    samples->push_back(Sample());
    samples->back().weight = 1;
    if (i > click) continue;
    samples->back().pos_weight = 1;
    samples->back().elements.assign(signs.begin(), signs.end());
    // calc prior pctr
    // const PriorModel& prior_model = olm_model_-prec
  }
  return true;
}

bool ItemQLearner::GetSample(std::vector<Sample>* samples) {
  reco::kafka::Message msg;
  reco::RecoItem reco_item;

  if (!consumer_->Consume(&msg, 100)) {
    LOG_EVERY_N(INFO, 100) << "get message from kafka failed!";
    return false;
  }

  if (!reco_item.ParseFromString(msg.content)) {
    LOG(ERROR) << "failed to parse RecoItem from message, " << msg.content;
    return false;
  }

  return ExtractFeature(reco_item, samples);
}

void ItemQLearner::PushFeaOut(const std::unordered_map<uint64, double>& fea_buf) {
  BundleFeaWeight bundle_fea_w;
  std::string value;
  std::string key;
  bundle_fea_w.set_batch_time(batch_timestamp_);
  for (auto it = fea_buf.begin(); it != fea_buf.end(); ++it) {
    auto fea = bundle_fea_w.add_bfw();
    fea->set_fea(it->first);
    fea->set_weight(it->second);
    // TODO(xielang): confidence
    fea->set_confidence(100);

    if (bundle_fea_w.bfw_size() > FLAGS_max_send_out) {
      bundle_fea_w.set_time_ms(base::GetTimestamp() / 1000);
      key = base::Int64ToString(bundle_fea_w.time_ms());

      if (bundle_fea_w.SerializeToString(&value)) {
        if (!fea_producer_->Produce(value, key)) {
          LOG(ERROR) << "bunle fea w kafka Produce failed " << key;
        } else {
          LOG(INFO) << key << "\t" << bundle_fea_w.Utf8DebugString();
        }
      } else {
        LOG(ERROR) << "bundle fea :SerializeToString falied";
      }
      bundle_fea_w.clear_bfw();
    }
  }

  if (bundle_fea_w.bfw_size() > 0) {
    bundle_fea_w.set_time_ms(base::GetTimestamp() / 1000);
    key = base::Int64ToString(bundle_fea_w.time_ms());

    if (bundle_fea_w.SerializeToString(&value)) {
      if (!fea_producer_->Produce(value, key)) {
        LOG(ERROR) << "bunle fea w kafka Produce failed " << key;
      } else {
        LOG(INFO) << key << "\t" << bundle_fea_w.Utf8DebugString();
      }
    } else {
      LOG(ERROR) << "bundle fea :SerializeToString falied";
    }
  }
}

void ItemQLearner::PushFeaWorker(thread::BlockingQueue<const std::vector<std::pair<uint64, double> >* >* fea_queue) {  // NOLINT
  std::unordered_map<uint64, double> fea_buf;
  const std::vector<std::pair<uint64, double> >* fea_w;
  int n = 0;
  while (!stop_) {
    LOG_EVERY_N(INFO, 100) << "fea queue size: " << fea_queue->Size();
    if (!fea_queue->Take(&fea_w)) break;
    scoped_ptr<const std::vector<std::pair<uint64, double> > > fea_ptr(fea_w);
    for (size_t i = 0; i < fea_w->size(); ++i) {
      fea_buf[fea_w->at(i).first] = fea_w->at(i).second;
    }

    if (++n > FLAGS_sample_buddle) {
      LOG(INFO) << "push fea out: " << fea_buf.size();
      PushFeaOut(fea_buf);
      fea_buf.clear();
      n = 0;
    }
  }
}
}
}
