#include "reco/ml/online_model/learner/learner.h"

#include <vector>
#include <unordered_map>
#include <string>
#include <utility>

#include "base/common/logging.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/time/timestamp.h"
#include "base/file/file_util.h"
#include "base/strings/string_printf.h"
#include "serving_base/utility/time_helper.h"

#include "reco/ml/auc/auc.h"
#include "reco/ml/online_model/learner/model.h"

DEFINE_int32(calc_auc_in_seconds, -1, "calc train data auc periodically. Disabled if is -1");

namespace reco {
namespace ml {
const std::string Learner::kTimestampFile = "dump_timestamp.dat";
// NOTE(xielang): olm_model from outside, multi learner to update one model
Learner::Learner() {
  stop_ = false;
  olm_model_ = new OlmModel();
}

Learner::~Learner() {
  stop();
  delete olm_model_;
}

bool Learner::Reinit(const base::FilePath& prior_path, std::string* reason) {
  reason->clear();
  LOG(INFO) << "Learner starts reinitialization";

  // when init, blocking others
  write_pause_flag(true);
  thread::AutoLock auto_lock(&mutex_);

  if (!olm_model_->ReInitWithPriorModel(prior_path, reason)) return false;

  base::FilePath timestamp_path = prior_path.DirName().Append(kTimestampFile);

  // read timestamp file
  batch_timestamp_ = 0;
  if (base::file_util::PathExists(timestamp_path)) {
    std::vector<std::string> lines;
    base::file_util::ReadFileToLines(timestamp_path, &lines);
    CHECK(lines.size()) << "invalid dump file: " << timestamp_path.value();
    CHECK(serving_base::TimeHelper::StringToTimestamp(lines[0],
                                                      serving_base::TimeHelper::kSecond,
                                                      &batch_timestamp_))
        << "invalid dump timestamp: " << lines[0];
  }

  write_pause_flag(false);
  return true;
}

void CalcPriorAuc(thread::BlockingQueue<PredCTR>* pctr_queue, int auc_interval_in_seconds) {
  if (auc_interval_in_seconds < 1) {
    LOG(WARNING) << "zero interval, calc prior auc thread end";
    return;
  }

  LOG(INFO) << "prior auc calc thread begin, interval=" << auc_interval_in_seconds;

  int64 prev_auc_ts = base::GetTimestamp() / 1e6;
  PredCTR pred_ctr;

  std::vector<PredCTR> prior_pctrs;

  while ((pctr_queue->Empty() && pctr_queue->Closed())) {
    if (base::GetTimestamp() / 1e6 - prev_auc_ts > auc_interval_in_seconds && prior_pctrs.size() > 100) {
      double prior_auc = CalcRocAuc(prior_pctrs);
      double prior_qauc, prior_wqauc;
      CalcQueryAuc(prior_pctrs, &prior_qauc, &prior_wqauc);
      double prior_iqauc = CalcInterQueryAuc(prior_pctrs);
      double prior_logloss = LogLoss(prior_pctrs);

      LOG(INFO) << "Prior model AUC=" << prior_auc
                << ", QAUC=" << prior_qauc
                << ", WQAUC=" << prior_wqauc
                << ", IQAUC=" << prior_iqauc
                << ", LogLoss=" << prior_logloss
                << ", avgPred=" << AveragePredictionCtr(prior_pctrs)
                << ", avgEmp=" << AverageEmpiricalCtr(prior_pctrs)
                << ", in the last "
                << auc_interval_in_seconds << " seconds, "
                << prior_pctrs.size() << " training samples";

      prior_pctrs.clear();

      prev_auc_ts = base::GetTimestamp() / 1e6;
    }

    // pop all the pctr item
    int status = pctr_queue->TimedTake(20, &pred_ctr);
    if (status == -1) {
      LOG(WARNING) << "ctr queu has benn closed!";
      break;
    }

    LOG_EVERY_N(INFO, 100000) << base::StringPrintf("remain %d prior queue, get %d in prior_pctrs status=%d",
                                                    pctr_queue->Size(), (int)prior_pctrs.size(), status);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    CHECK_EQ(status, 1) << "fucking unknow status: " << status;
    prior_pctrs.push_back(pred_ctr);
  }
  LOG(INFO) << "prior thread end";
}

void CalcOlmAuc(thread::BlockingQueue<PredCTR>* pctr_queue, int auc_interval_in_seconds) {
  if (auc_interval_in_seconds  < 1) {
    LOG(WARNING) << "zero interval, calc olm auc thread end";
    return;
  }

  LOG(INFO) << "olm auc calc thread begin, interval=" << auc_interval_in_seconds;

  std::vector<PredCTR> olm_pctrs;

  int64 prev_auc_ts = base::GetTimestamp() / 1e6;
  PredCTR pred_ctr;

  while (!(pctr_queue->Empty() && pctr_queue->Closed())) {
    if (base::GetTimestamp() / 1e6 - prev_auc_ts > auc_interval_in_seconds && olm_pctrs.size() > 100) {
      double olm_auc = CalcRocAuc(olm_pctrs);
      double olm_qauc, olm_wqauc;
      CalcQueryAuc(olm_pctrs, &olm_qauc, &olm_wqauc);
      double olm_iqauc = CalcInterQueryAuc(olm_pctrs);
      double olm_logloss = LogLoss(olm_pctrs);

      LOG(INFO) << "Online model AUC=" << olm_auc
                << ", QAUC=" << olm_qauc
                << ", WQAUC=" << olm_wqauc
                << ", IQAUC=" << olm_iqauc
                << ", LogLoss=" << olm_logloss
                << ", avgPred=" << AveragePredictionCtr(olm_pctrs)
                << ", avgEmp=" << AverageEmpiricalCtr(olm_pctrs)
                << ", in the last "
                << auc_interval_in_seconds << " seconds, "
                << olm_pctrs.size() << " training samples";
      olm_pctrs.clear();

      prev_auc_ts = base::GetTimestamp()/1e6;
    }
    // pop all the pctr item
    int status = pctr_queue->TimedTake(10, &pred_ctr);
    if (status == -1) {
      LOG(WARNING) << "ctr queu has benn closed!";
      break;
    }

    LOG_EVERY_N(INFO, 100000) << base::StringPrintf("remain %d olm queue, get %d in olm_pctrs, status=%d",
                                                    pctr_queue->Size(), (int)olm_pctrs.size(), status);
    if (status == 0) {
      base::SleepForSeconds(1);
      continue;
    }

    CHECK_EQ(status, 1) << "fucking unknow status: " << status;
    olm_pctrs.push_back(pred_ctr);
  }
  LOG(INFO) << "olm thread end";
}

bool Learner::has_initialized(void) const {
  return olm_model_->has_initialized();
}

void Learner::Start(void) {
  pool_ = new thread::ThreadPool(4);
  if (!olm_model_->has_initialized()) {
    LOG(ERROR) << "model has not init yet; would start with empty fea";
  }
  // for calc auc
  if (FLAGS_calc_auc_in_seconds > 0) {
    pool_->AddTask(::NewCallback(reco::ml::CalcOlmAuc, &olm_pctr_queue_, FLAGS_calc_auc_in_seconds));
    pool_->AddTask(::NewCallback(reco::ml::CalcPriorAuc, &prior_pctr_queue_, FLAGS_calc_auc_in_seconds));
  }

  pool_->AddTask(::NewCallback(this, &Learner::UpdateWorker, &sample_queue_, &olm_pctr_queue_));
  pool_->AddTask(::NewCallback(this, &Learner::GenerateSampleWorker, &sample_queue_, &prior_pctr_queue_));

  LOG(INFO) << "Learner started.";
  return;
}

void Learner::UpdateWorker(thread::BlockingQueue<Sample>* sample_queue,
                           thread::BlockingQueue<PredCTR>* pctr_queue) {
  Sample sample;
  PredCTR pctr;
  std::vector<std::pair<uint64, double> > fea_w;
  while (!(sample_queue->Closed() && sample_queue->Empty())) {
    if (pause_) {
      LOG(INFO) << "pause for 10 second";
      base::SleepForSeconds(10);
    }

    LOG_EVERY_N(INFO, 1000) << "sample queue size: " << sample_queue->Size();
    if (!sample_queue->Take(&sample)) break;

    fea_w.clear();
    olm_model_->LearnOneSample(sample, &fea_w, &pctr);
    // LOG(INFO) << "learn sample: " << sample.elements.size();

    if (pctr_queue != NULL) pctr_queue->Put(pctr);
    OutputIncrWeight(fea_w);
  }

  pctr_queue->Close();
}

void Learner::GenerateSampleWorker(thread::BlockingQueue<Sample>* sample_queue,
                                   thread::BlockingQueue<PredCTR>* prior_pctrs) {
  std::vector<Sample> samples;
  while (!stop_) {
    // LOG(INFO) << "samle queeu: remain: " << sample_queue->Size();
    samples.clear();
    if (!GetSample(&samples)) {
      LOG_EVERY_N(ERROR, 1000) << "get sample failed!";
      continue;
    }

    for (size_t i = 0; i < samples.size(); ++i) {
      sample_queue->Put(samples[i]);
    }

    if (prior_pctrs != NULL) {
      for (size_t i = 0; i < samples.size(); ++i) {
        PredCTR pctr;
        // TODO(xielang):
        pctr.query = samples[i].query;
        pctr.pos_weight = samples[i].pos_weight;
        pctr.neg_weight = samples[i].weight - samples[i].pos_weight;
        pctr.prediction = samples[i].prior;
        if (prior_pctrs != NULL) prior_pctrs->Put(pctr);
      }
    }
  }
  LOG(INFO) << "finish generate samples: " << sample_queue->Size();
}
}  // namespace
}  // namespace
