#include "reco/online_model/learner/learner_test_helper.h"

#include <stdlib.h>
#include <math.h>
#include <string>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <limits>

#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/strings/string_printf.h"
#include "base/thread/thread.h"
#include "base/time/timestamp.h"
#include "base/strings/string_split.h"
#include "storage/message_queue/mock_message_queue/mock_message_queue.h"
#include "storage/message_queue/api/message_client_interface.h"
#include "storage/message_queue/api/message_client_generator.h"
#include "reco/learning/ftrl/kiss/ftrl.h"

#include "reco/online_model/util/util.h"
#include "reco/online_model/learner/util.h"
#include "reco/online_model/learner/learner.h"
#include "reco/online_model/proto/online_model.pb.h"

#include "third_party/leveldb/filter_policy.h"

namespace reco {
namespace olm {

DECLARE_string(message_queue_servers);
DECLARE_string(joiner_queue_name);
DECLARE_string(predictor_queue_name);
DECLARE_string(prior_model_dir);
DECLARE_string(prior_model_prefix);
DECLARE_string(message_tmp_root);

DECLARE_double(olm_beta);
DECLARE_double(olm_alpha);
DECLARE_double(olm_l1weight);
DECLARE_double(olm_l2weight);
DECLARE_string(olm_algo);
namespace testing {

SimpleMockServer* StartMockMessageQueueServer(std::string* queue_servers,
                                              int stochastic_port, int queue_port) {
  FLAGS_message_queue_servers = base::StringPrintf("127.0.0.1:%d", queue_port);

  std::vector<std::string> queues;
  queues.push_back(FLAGS_joiner_queue_name);
  queues.push_back(FLAGS_predictor_queue_name);

  SimpleMockServer* mock_server = new SimpleMockServer(stochastic_port, queue_port, queues);
  CHECK_NOTNULL(mock_server);

  if (queue_servers) {
    *queue_servers = FLAGS_message_queue_servers;
  }
  return mock_server;
}

LearnerTestHelper::LearnerTestHelper(const std::string& test_leveldb_dirs)
  : thread_stop_(false),
    model_(NULL),
    fill_joiner_(NULL),
    run_learner_(NULL) {
      ftrl_kiss::FTRL::Algo algo;
      if (FLAGS_olm_algo == "RDA") {
        algo = ftrl_kiss::FTRL::Rda;
      } else if (FLAGS_olm_algo == "FTRLP") {
        algo = ftrl_kiss::FTRL::Ftrlp;
      } else {
        LOG(FATAL) << "Invalid algo " << FLAGS_olm_algo;
      }
      model_ = new ftrl_kiss::FTRL(FLAGS_olm_alpha, FLAGS_olm_beta,
                                   FLAGS_olm_l1weight, FLAGS_olm_l2weight, algo);
      // init level dbs
      CHECK(!test_leveldb_dirs.empty());
      std::vector<std::string> db_names;
      base::SplitString(test_leveldb_dirs, ";", &db_names);

      leveldb::Options leveldb_options;
      leveldb_options.create_if_missing = true;
      leveldb_options.paranoid_checks = false;
      leveldb_options.write_buffer_size = 1000 * 1024 * 1024;
      leveldb_options.max_open_files = 100 / db_names.size();
      leveldb_options.compression = leveldb::kNoCompression;
      leveldb_options.filter_policy = leveldb::NewBloomFilterPolicy(8);

      CHECK(model_->InitWithLevelDb(leveldb_options, db_names));
    }

LearnerTestHelper::~LearnerTestHelper() {
  thread_stop_ = true;
  // 不能设置 gStop 标记, 否则会导致 Learner 停止.
  // reco::olm::RunningProcedure::gStop = true;
  if (fill_joiner_) {
    fill_joiner_->Join();
  }
  if (run_learner_) {
    run_learner_->Join();
  }
  delete fill_joiner_;
  delete run_learner_;
  delete model_;
}

std::string LearnerTestHelper::GenerateRandomSamples(int32 sample_cnt, int32 prior_model_size) {
  base::PseudoRandom random(base::GetTimestamp());

  // 产生随机 prior model, 并写磁盘.
  std::string prior_model_path = FLAGS_prior_model_dir + "/" + FLAGS_prior_model_prefix + "_"
      + TimetToString(base::GetTimestamp()/1e6, "%Y%m%d%H%M%S") + "_"
      + TimetToString(base::GetTimestamp()/1e6, "%Y%m%d%H%M%S") + ".txt";
  {
    system(base::StringPrintf("mkdir -p %s", FLAGS_prior_model_dir.c_str()).c_str());
    std::ofstream os(prior_model_path);
    CHECK(os.good()) << prior_model_path;

    for (int32 i = 0; i < prior_model_size && i < LearnerTestHelper::gMaxFea; ++i) {
      int32 click = random.GetInt(0, 10);
      int32 show = click + random.GetInt(1, 100);
      os << "fea_lital\t" << random.GetUint64LT(LearnerTestHelper::gMaxFea)
         << "\t" << show
         << "\t" << click
         << "\t" << ((double)click)/show
         << "\t" << (random.GetDouble() - 0.5) * 2 << std::endl;
    }
    os.close();
  }

  std::string reason;
  CHECK_EQ(0, ReInitWithPriorModel(prior_model_path, std::unordered_set<std::string>(),
                                   model_, &prior_model_, &reason)) << reason;

  // 产生随机样本
  samples_.resize(sample_cnt);
  for (int32 i = 0; i < sample_cnt; ++i) {
    ftrl_kiss::Sample& sample = samples_[i];
    sample.weight = 1;
    sample.pos_weight = (random.GetDouble() <= 0.1) ? 1 : 0;
    sample.elements.resize(50+random.GetInt(0, 30));
    sample.prior = 0;
    for (int32 j = 0; j < (int32)sample.elements.size(); ++j) {
      uint64 fea = random.GetUint64LT(LearnerTestHelper::gMaxFea);
      auto it = prior_model_.model.find(fea);
      if (it != prior_model_.model.end()) {
        sample.prior += it->second.first;
      }
      sample.elements[j] = fea;
    }
  }

  // 学习在线模型.
  for (int32 i = 0; i < (int32)samples_.size(); ++i) {
    model_->Update(samples_[i], false, NULL);
  }

  return prior_model_path;
}

void LearnerTestHelper::FillJoinerQueue(void) {
  MessageClientInterface* joiner = NewMessageClientWithUniqDir(FLAGS_message_tmp_root,
                                                               FLAGS_message_queue_servers, NULL);
  message_queue::AutoDeleteClient auto_client(joiner);

  for (int32 i = 0; i < (int32)samples_.size() && !thread_stop_; ++i) {
    const ftrl_kiss::Sample& sample = samples_[i];
    reco::olm::Instance ins;
    if (sample.pos_weight > 1-1e-6) {
      ins.set_label(1);
    } else {
      ins.set_label(-1);
    }
    for (int32 j = 0; j < (int32)sample.elements.size(); ++j) {
      ins.add_features(sample.elements[j]);
    }
    std::string message;
    ins.SerializeToString(&message);
    joiner->Push(FLAGS_joiner_queue_name, message);
  }
}

void LearnerTestHelper::StartFillingJoinerQueue(void) {
  CHECK(fill_joiner_ == NULL);
  fill_joiner_ = new thread::Thread;
  fill_joiner_->Start(::NewCallback(this, &LearnerTestHelper::FillJoinerQueue));
}

void LearnerTestHelper::WaitJoinerQueue(void) {
  if (fill_joiner_) {
    fill_joiner_->Join();
  }
  delete fill_joiner_;
  fill_joiner_ = NULL;
}

void LearnerTestHelper::StartLearner() {
  CHECK(run_learner_ == NULL);
  run_learner_ = new thread::Thread;
  run_learner_->Start(::NewCallback(&Learner::Instance(), &Learner::Run));
}

void LearnerTestHelper::WaitLearner(void) {
  if (run_learner_) {
    run_learner_->Join();
  }
  delete run_learner_;
  run_learner_ = NULL;
}

bool LearnerTestHelper::IsLearnerCorrect(void) const {
  static thread::Mutex mutex;
  thread::AutoLock lock(&mutex);

  const ftrl_kiss::FTRL& learner_result = Learner::Instance().olm_model_->model();
  const ftrl_kiss::FTRL& correct_result = *model_;

  std::unordered_map<uint64, float> nz_learner, nz_correct;
  correct_result.NonZeroWeights(&nz_correct);
  learner_result.NonZeroWeights(&nz_learner);

  LOG_IF(ERROR, nz_correct.size() != nz_learner.size())
      << "non-zeros cnt unmatch, correct=" << nz_correct.size()
      << ", learner=" << nz_learner.size();
  int32 match = 0, unmatch = 0;
  for (auto it = nz_correct.begin(); it != nz_correct.end(); ++it) {
    auto found = nz_learner.find(it->first);
    if (found == nz_learner.end()) {
      LOG(ERROR) << it->first << " not found";
      ++unmatch;
      continue;
    } else if (fabs(found->second - it->second) > 1e-6) {
      LOG(ERROR) << it->first << ", correct=" << it->second
                 << ", learner=" << found->second;
      ++unmatch;
      continue;
    }
    ++match;
  }
  // LOG(ERROR) << "match=" << match << ", unmatch=" << unmatch;
  return (unmatch == 0);
}

void LearnerTestHelper::WaitTillLearnerInitialized(void) {
  while (!Learner::Instance().has_initialized()) {
    LOG(INFO) << "Wait for Learner initialization, sleep 1s";
    LOG(ERROR) << "Wait for Learner initialization, sleep 1s";  // 单测的时候可以看得见
    base::SleepForSeconds(1);
  }
  base::SleepForSeconds(1);
}

// 满足两个条件则表示 "NoDataToLearn"
// 1. joiner queue 剩余 message 为 0
// 2. predictor queue 剩余 message 不增长.
void LearnerTestHelper::WaitTillNoDataToLearn(void) {
  MessageClientInterface* client = NewMessageClientWithUniqDir(FLAGS_message_tmp_root,
                                                               FLAGS_message_queue_servers, NULL);
  message_queue::AutoDeleteClient auto_client(client);
  int32 prev_left = std::numeric_limits<int32>::max();
  while (true) {
    int32 left = client->GetRemainMessageNum(FLAGS_predictor_queue_name, "fake_predictor_reader");
    int32 left2 = Learner::Instance().olm_model_->fetcher()->GetRemainMessageNum();
    LOG(INFO) << "Predictor queue remaining " << left << ", joiner queue remaining " << left2;
    if (prev_left == left && left2 == 0) {
      break;
    }
    LOG(INFO) << "Wait till no more learning data, sleep 1s";
    LOG(ERROR) << "Wait till no more learning data, sleep 1s";  // 单测的时候可以看得见
    prev_left = left;
    base::SleepForSeconds(1);
  }
}
}  // namespace
}  // namespace
}  // namespace
