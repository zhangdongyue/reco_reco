#pragma once
#include <vector>
#include <string>
#include <utility>
#include <unordered_map>

#include "reco/ml/online_model/learner/learner.h"
#include "reco/ml/ftrl/define.h"
#include "reco/base/common/singleton.h"
#include "base/thread/blocking_queue.h"

namespace thread {
class ThreadPool;
}

namespace reco {
class RecoItem;

namespace kafka {
class Producer;
class Consumer;
}

namespace ml {
class BaseFeatureExtractor;
// thread unsafe, singletone
class ItemQLearner: public Learner {
 public:
  ItemQLearner();
  ~ItemQLearner();

  void Init();

  void stop();
 private:
  virtual bool GetSample(std::vector<Sample>* samples);

  virtual void OutputIncrWeight(const std::vector<std::pair<uint64, double> >& fea_w) {
    std::vector<std::pair<uint64, double> >* feas = new std::vector<std::pair<uint64, double> >();
    feas->assign(fea_w.begin(), fea_w.end());
    fea_queue_->Put(feas);
  }

 private:
  void PushFeaOut(const std::unordered_map<uint64, double>& fea_buf);

  void PushFeaWorker(thread::BlockingQueue<const std::vector<std::pair<uint64, double> >* >* fea_queue);

  bool ExtractFeature(const reco::RecoItem& reco_item, std::vector<Sample>* sample);

 private:
  thread::ThreadPool* pool_;
  thread::BlockingQueue<const std::vector<std::pair<uint64, double> >* >* fea_queue_;

  std::vector<std::string> strs_;

  reco::ml::BaseFeatureExtractor* fea_extractor_;

  bool stop_;
  reco::kafka::Producer* fea_producer_;
  reco::kafka::Consumer* consumer_;
};
typedef reco::common::singleton_default<ItemQLearner> ItemQLearnerIns;
}
}
