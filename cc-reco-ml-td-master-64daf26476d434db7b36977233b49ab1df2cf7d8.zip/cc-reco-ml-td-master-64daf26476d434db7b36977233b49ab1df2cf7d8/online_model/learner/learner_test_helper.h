#pragma once
#include <string>
#include <vector>

#include "base/common/basic_types.h"
#include "base/thread/thread_pool.h"
#include "reco/ml/online_model/learner/itemq_learner.h"
#include "reco/ml/online_model/learner/model.h"

namespace thread {
class Thread;
}

namespace reco {
namespace ml {
namespace testing {

// 产生训练样本
class LearnerTestHelper {
 public:
  explicit LearnerTestHelper();
  ~LearnerTestHelper();

  void GenerateRandomSamples(int32 sample_cnt);

  void StartLearner();
  void WaitLearner(void);

 public:
  static void WaitTillLearnerInitialized(void);
 private:
  thread::ThreadPool* pool_;
};

}  // namespace
}  // namespace
}  // namespace
