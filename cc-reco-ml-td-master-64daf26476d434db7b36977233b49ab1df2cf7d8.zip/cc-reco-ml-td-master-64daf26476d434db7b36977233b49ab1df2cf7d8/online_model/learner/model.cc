#include "reco/ml/online_model/learner/model.h"

#include <vector>
#include <unordered_map>
#include <fstream>
#include <string>
#include <utility>

#include "base/common/logging.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "serving_base/utility/time_helper.h"

#include "reco/ml/ftrl/ftrl.h"
#include "reco/ml/auc/auc.h"

DEFINE_int32(v_dim, 0, "dim for fm; 0 for lr");
DEFINE_double(olm_alpha, 0.005, "online model learning rate alpha");
DEFINE_double(olm_beta, 0.005, "online model learning rate beta");
DEFINE_double(olm_l1weight, 0.9, "online model L1 norm");
DEFINE_double(olm_l2weight, 1.0, "online model L2 norm");
DEFINE_string(olm_algo, "FTRLP", "RDA or FTRLP");
DEFINE_double(ftrl_output_threshold, 0.000001, "");
DEFINE_double(min_fea_t, 0, "");

DEFINE_bool(reinit_learning_rate, false, "reinit learning rate beta");

namespace reco {
namespace ml {
OlmModel::OlmModel() {
  FTRL::Option ftrl_option;
  ftrl_option.v_dim = FLAGS_v_dim;
  ftrl_option.learning_rate_alpha = FLAGS_olm_alpha;
  ftrl_option.learning_rate_beta = FLAGS_olm_beta;
  ftrl_option.l1weight = FLAGS_olm_l1weight;
  ftrl_option.l2weight = FLAGS_olm_l2weight;
  ftrl_option.algo = FLAGS_olm_algo == "RDA" ? FTRL::Rda : FTRL::Ftrlp;

  ftrl_option.ftrl_output_thresh = FLAGS_ftrl_output_threshold;
  ftrl_option.min_fea_t = FLAGS_min_fea_t;
  ftrl_ = new FTRL(ftrl_option);
}

OlmModel::~OlmModel() {
  delete ftrl_;
}

// mv to global data
static bool LoadPriorModel(const base::FilePath& path,
                           uint64* timestamp,
                           std::unordered_map<uint64, PriorInfo>* prior_model) {
  prior_model->clear();
  std::ifstream is(path.value());
  CHECK(is.good()) << "Cannot open file " << path.value();
  LOG(INFO) << "reading " << path.value();

  std::vector<std::string> flds;
  std::string line;

  // get timestamp
  std::getline(is, line);
  if (!serving_base::TimeHelper::StringToTimestamp(line, serving_base::TimeHelper::kSecond,
                                                   timestamp)) {
    LOG(ERROR) << "error batch timestamp " << line;
    return false;
  }

  while (std::getline(is, line)) {
    if (line.empty()) continue;
    flds.clear();
    base::SplitString(line, " \t", &flds);
    CHECK_GE(flds.size(), 2u) << line;
    uint64 fea = base::ParseUint64OrDie(flds[0]);
    double show = 0, click = 0;
    double w = base::ParseDoubleOrDie(flds[1]);
    if (flds.size() >= 4u) {
      show = base::ParseDoubleOrDie(flds[2]);
      click = base::ParseDoubleOrDie(flds[3]);
      CHECK(show >= click && show > 0) << line;
    }
    PriorInfo info;
    info.w = w;
    info.pos_event = click;
    info.neg_event = show - click;
    prior_model->insert(std::make_pair(fea, info));
  }
  is.close();
  LOG(INFO) << "prior model loaded, size=" << prior_model->size();
  return true;
}

std::string OlmModel::printable_infos(void) const {
  return base::StringPrintf("Online model alpha=%f,beta=%f,l1w=%f,l2w=%f,algo=%s,"
                            "prior_sz=%ld,olm_sz=%ld",
                            FLAGS_olm_alpha, FLAGS_olm_beta, FLAGS_olm_l1weight, FLAGS_olm_l2weight,
                            FLAGS_olm_algo.c_str(), prior_model_.model.size(), ftrl_->Size());
}

bool OlmModel::ReInitWithPriorModel(const base::FilePath& prior_path, std::string* reason) {
  reason->clear();
  if (!base::file_util::PathExists(prior_path)) {
    *reason = prior_path.value() + " not found";
    return false;
  }

  std::unordered_map<uint64, PriorInfo> prior_infos;
  if (!LoadPriorModel(prior_path, &(prior_model_.timestamp), &prior_infos)) {
    return false;
  }

  if (ftrl_) {
    ftrl_->Clear();
    LOG(INFO) << "begin to init batch model in memory" << prior_infos.size();
    ftrl_->InitWithPriors(prior_infos, FLAGS_reinit_learning_rate);
    LOG(INFO) << "after to init batch model in memory" << prior_infos.size();
  }

  prior_model_.model.clear();
  for (auto it = prior_infos.begin(); it != prior_infos.end(); ++it) {
    prior_model_.model[it->first] = it->second.w;
  }

  LOG(INFO) << "Learner reinitialization success, current info " << printable_infos();
  return true;
}

void OlmModel::LearnOneSample(const Sample& sample,
                              std::vector<std::pair<uint64, double> >* fea_w,
                              PredCTR* pctr) {
  float ctr = ftrl_->Update(sample, fea_w);
  pctr->prediction = ctr;
  pctr->query = sample.query;

  pctr->pos_weight = (sample.pos_weight > 1e-6) ? 1 : 0;
  pctr->neg_weight = (sample.pos_weight > 1e-6) ? 0 : 1;
}

// TODO(xielang): mv to some common module:
static double logit(double sum_w) {
  double f = 0;
  if (sum_w > 30) {
    f = 1;
  } else if (sum_w < -30) {
    f = 0;
  } else if (sum_w > 0) {
    f = 1 / (1 + exp(-sum_w));
  } else {
    double e = exp(sum_w);
    f = e / (1 + e);
  }
  return f;
}

float OlmModel::CalcPriorCtr(const std::vector<uint64>& feas) {
  double sum_w = 0;
  for (size_t i = 0; i < feas.size(); ++i) {
    auto it = prior_model_.model.find(feas[i]);
    if (it == prior_model_.model.end()) continue;
    sum_w += it->second;
  }
  return logit(sum_w);
}
}
}
