#include <string>

#include "base/common/basic_types.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/common/logging.h"
#include "serving_base/utility/time_helper.h"
#include "reco/ml/online_model/learner/itemq_learner.h"
#include "reco/ml/online_model/predictor/itemq_predictor.h"

namespace reco {
namespace olm {

namespace testing {

DECLARE_string(item_kafka_brokers);
DECLARE_string(item_topic);
DECLARE_int32(item_partition);
DECLARE_string(start_time);

DEFINE_string(fea_topic);
DEFINE_string(fea_brokers);

DEFINE_int32(max_send_out);
DEFINE_int32(sample_buddle);
DEFINE_int32(message_buffer_size);

class LearnerTest : public testing::Test {
  static void SetUpTestCase() {
    ItemQLearnerIns::instance().Start();
  }

  static void TearDownTestCase() {
    LOG(INFO) << "tear dwon!";
  }

 protected:
};

TEST(LearnerTest, reinit) {
  base::SleepForSenconds(5);
  std::string str;
  ASSERT_TRUElearner_->Reinit(base::FilePath("../data/prior.txt"), &str) << str;
}

TEST(LearnerTest, TestUpdate) {
}
}  // namespace
}  // namespace
}  // namespace
