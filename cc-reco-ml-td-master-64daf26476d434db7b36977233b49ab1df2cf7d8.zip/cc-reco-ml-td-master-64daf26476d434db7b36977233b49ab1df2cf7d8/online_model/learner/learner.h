#pragma once
#include <cstdatomic>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
#include <string>

#include "base/common/basic_types.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/file/file_path.h"
#include "base/thread/sync.h"

namespace reco {
namespace ml {
struct Sample;
struct PredCTR;
class OlmModel;

// thread unsafke, single instance is enough
class Learner {
 public:
  Learner();
  virtual ~Learner();

  bool has_initialized(void) const;
  void Start(void);

  bool Reinit(const base::FilePath& file_path, std::string* reason);

  void write_pause_flag(bool val) { pause_ = val; }

  void stop() {
    if (stop_ ) return;
    stop_ = true;
    pool_->JoinAll();
    LOG(INFO) << "Learner stopped!";
  }
 private:
  void UpdateWorker(thread::BlockingQueue<Sample>* sample_queue,
                    thread::BlockingQueue<PredCTR>* olm_pctrs);

  void GenerateSampleWorker(thread::BlockingQueue<Sample>* sample_queue,
                            thread::BlockingQueue<PredCTR>* prior_pctrs);

  virtual bool GetSample(std::vector<Sample>* sample_queue) = 0;
  virtual void OutputIncrWeight(const std::vector<std::pair<uint64, double> >& fea_w) = 0;
 private:
  void CalcOlmAuc(thread::BlockingQueue<PredCTR>* pctr_queue);
  void CalcPriorAuc(thread::BlockingQueue<PredCTR>* pctr_queue);

  thread::Mutex mutex_;
  bool pause_;
 protected:
  static const std::string kTimestampFile;
  bool stop_;
  OlmModel* olm_model_;
  uint64 batch_timestamp_;

  thread::ThreadPool* pool_;

  thread::BlockingQueue<PredCTR> olm_pctr_queue_;
  thread::BlockingQueue<PredCTR> prior_pctr_queue_;
  thread::BlockingQueue<Sample> sample_queue_;

  DISALLOW_COPY_AND_ASSIGN(Learner);
};
}  // namespace
}  // namespace
