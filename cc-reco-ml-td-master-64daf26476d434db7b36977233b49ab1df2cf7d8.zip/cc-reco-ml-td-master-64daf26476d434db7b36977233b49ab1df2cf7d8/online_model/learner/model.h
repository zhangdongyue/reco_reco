#pragma once
#include <unordered_map>
#include <string>
#include <vector>
#include <utility>

#include "base/common/basic_types.h"
#include "reco/ml/ftrl/ftrl.h"

namespace base {
class FilePath;
}
namespace reco {
namespace ml {
class PredCTR;

struct PriorModel {
  std::unordered_map<uint64, float> model;
  uint64 timestamp;
};

class OlmModel {
 public:
  OlmModel();
  ~OlmModel();

  bool ReInitWithPriorModel(const base::FilePath& prior_path, std::string* reason);

  void LearnOneSample(const Sample& sample, std::vector<std::pair<uint64, double> >* fea_w, PredCTR* pctr);

  bool has_initialized() {
    return ftrl_ != NULL && ftrl_->Size() > 0;
  }

  const PriorModel& prior_model() {
    return prior_model_;
  }

  float CalcPriorCtr(const std::vector<uint64>& fea_w);
 private:
  std::string printable_infos(void) const;

 private:
  PriorModel prior_model_;
  FTRL* ftrl_;
};
}
}
