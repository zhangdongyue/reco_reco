set -u

local_model_root=../model
ins_path_root=/reco/video/new/train/
sh -x train.sh  --ins_path=$ins_path_root --model_path=$local_model_root/coldstart
