#!/usr/local/bin/bash
yesterday_date=`date -d "-1 day $current_date" +"%Y%m%d"`
# bin
jar_name=/data8/sam.zk/bin/profile-hadoop-0.1.0.jar

# date dir
root=/reco/user_profile/video_cold_start/user_category

export HADOOP_CLIENT_OPTS="-Djava.io.tmpdir=/data2/tmp"


input=/reco/user_info_dump/user_info_online/$yesterday_date/
output=$root/instance/coldstart/all
allroot=$root/instance/coldstart/all
$HADOOP_HOME/bin/hadoop fs -rm -r $output
$HADOOP_HOME/bin/hadoop jar $HADOOP_STREAMING_JAR \
  -D mapred.reduce.tasks=0 \
  -D mapreduce.reduce.memory.mb=8096 \
  -D mapreduce.job.running.map.limit=2000 \
  -D mapreduce.job.running.reduce.limit=1000 \
  -files "gen_instance" \
  -input $input \
  -output $output \
  -mapper "./gen_instance --job_name=instance_map" \

input=$root/instance/coldstart/all/
output=$root/instance/coldstart/train/

$HADOOP_HOME/bin/hadoop fs -rm -r $output
$HADOOP_HOME/bin/hadoop jar $HADOOP_STREAMING_JAR \
  -D mapred.reduce.tasks=0 \
  -D mapreduce.reduce.memory.mb=16384 \
  -D mapreduce.job.running.map.limit=2000 \
  -D mapreduce.job.running.reduce.limit=1000 \
  -files "gen_instance" \
  -input $input \
  -output $output \
  -mapper "./gen_instance --job_name=train_instance_map" \

output=$root/instance/coldstart/literal/

$HADOOP_HOME/bin/hadoop fs -rm -r $output
$HADOOP_HOME/bin/hadoop jar $HADOOP_STREAMING_JAR \
  -D mapred.reduce.tasks=0 \
  -D mapreduce.reduce.memory.mb=16384 \
  -D mapreduce.job.running.map.limit=2000 \
  -D mapreduce.job.running.reduce.limit=1000 \
  -files "gen_instance" \
  -input $input \
  -output $output \
  -mapper "./gen_instance --job_name=literal_instance_map" \

output=$root/instance/coldstart/fea

$HADOOP_HOME/bin/hadoop fs -rm -r $output
$HADOOP_HOME/bin/hadoop jar $HADOOP_STREAMING_JAR \
  -D mapred.reduce.tasks=199 \
  -D mapreduce.reduce.memory.mb=16384 \
  -D mapreduce.job.running.map.limit=2000 \
  -D mapreduce.job.running.reduce.limit=1000 \
  -files "gen_instance" \
  -input $input \
  -output $output \
  -mapper "./gen_instance --job_name=fea_id_map" \
  -reducer "./gen_instance --job_name=fea_id_reduce" \

