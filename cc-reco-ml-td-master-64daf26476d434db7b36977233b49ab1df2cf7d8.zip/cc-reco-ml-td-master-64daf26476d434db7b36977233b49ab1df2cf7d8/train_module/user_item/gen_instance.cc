#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/proto/item.pb.h"
#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/common/io_util.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_int32(thread_num, 10, "get item thread num");

DEFINE_string(user_server_machine_list, "../config/user_server_machine.yaml.em21", "user server");
DEFINE_string(user_profile_machine_list, "../config/user_profile_machine.yaml.em21", "user profile server");
DEFINE_string(user_file, "", "user id file, one id per line");
DEFINE_string(user_dump_file, "", "dumped reco user file");
DEFINE_string(sample_file, "", "sample file for generating instances");
DEFINE_bool(clear_show, true, "clear user shown history");
DEFINE_string(train_ins_file, "train_ins", "用于最终训练的格式");
DEFINE_string(literal_ins_file, "literal_ins", "明文的训练文件，主要用于检查训练样本");
DEFINE_string(fea_id_file, "fea_id", "特征明文到特征 id 映射文件");
DEFINE_string(reco_meta_file, "reco_meta", "reco meta 信息文件");

std::atomic<int> g_finished_threads(0);
thread::Mutex g_mutex;

struct InstanceInfo {
  uint64 reco_id;
  uint64 item_id;
  int64 read_tm;
  int show_num;
  int click_num;
  std::string app_name;
  std::string utdid;
  std::string imei;
  std::vector<std::string> fea_literal;
  std::vector<std::string> reco_meta;
};

void LoadSampleFile(std::unordered_map<uint64, std::vector<InstanceInfo> >* sample_dict) {
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_sample_file, &lines);
  std::vector<std::string> flds;
  std::vector<std::string> subs;
  for (size_t i = 0; i < lines.size(); ++i) {
    flds.clear();
    // app+"`"+userid, utdid, imei, recoid, itemid, click
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 6u) continue;
    subs.clear();
    base::SplitString(flds[0], "`", &subs);
    if (subs.size() != 2u) continue;
    uint64 user_id = base::ParseUint64OrDie(subs[1]);
    InstanceInfo info;
    info.reco_id = base::ParseUint64OrDie(flds[3]);
    info.item_id = base::ParseUint64OrDie(flds[4]);
    info.read_tm = base::ParseIntOrDie(flds[5]);
    info.app_name = subs[0];
    info.utdid = flds[1];
    info.imei = flds[2];
    (*sample_dict)[user_id].push_back(info);
  }
  LOG(INFO) << "done loading " << sample_dict->size() << " samples";
}

void ExtractFeature(thread::BlockingQueue<reco::UserInfo*>* user_queue,
                    std::unordered_map<uint64, std::vector<InstanceInfo>>* sample_dict,
                    std::vector<InstanceInfo>* ins_infos) {
  reco::ml::UserItemIdFeatureExtractor* extractor = new reco::ml::UserItemIdFeatureExtractor();

  std::vector<std::string> strs;
  extractor->SetupFeatureLayout();
  while (!user_queue->Empty()) {
    reco::UserInfo* puser = user_queue->Take();
    if (puser == NULL) continue;

    scoped_ptr<reco::UserInfo> p(puser);

    const reco::UserInfo& user = *puser;
    auto it = sample_dict->find(user.identity().user_id());
    if (it == sample_dict->end()) continue;

    const std::vector<InstanceInfo>& samples = it->second;
    extractor->ResetUser(user);
    reco::RecoItem item;
    for (size_t i = 0; i < samples.size(); ++i) {
      strs.clear();
      const InstanceInfo& sample = samples[i];
      item.mutable_identity()->set_item_id(sample.item_id);
      extractor->ExtractUserItemFeature(item, &strs);
      if (strs.empty()) {
        continue;
      }
      ins_infos->push_back(sample);
      InstanceInfo& info = ins_infos->back();
      std::swap(info.fea_literal, strs);
      info.show_num = 1;
      info.click_num = info.read_tm > 0 ? 1 : 0;

      // meta
      strs.clear();
      strs.push_back(info.app_name);
      strs.push_back(base::Uint64ToString(user.identity().user_id()));
      strs.push_back(info.utdid);
      strs.push_back(info.imei);
      strs.push_back(base::Uint64ToString(info.reco_id));
      strs.push_back(base::Uint64ToString(info.item_id));
      std::swap(info.reco_meta, strs);
    }
  }

  delete extractor;

  LOG(INFO) << "thread " << thread::GetThreadID() << " finished, gen instance: " << ins_infos->size();
  thread::AutoLock lock(&g_mutex);
  ++g_finished_threads;
}

void GenerateTrainInsFile(std::vector<std::vector<InstanceInfo> >* ins_infos) {
  std::ofstream out(FLAGS_train_ins_file.c_str());
  std::set<int64> dedup;
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      const InstanceInfo& info = *jt;
      out << info.show_num << " " << info.click_num;
      dedup.clear();
      for (size_t i = 0; i < info.fea_literal.size(); ++i) {
        uint64 sign = base::CityHash64(info.fea_literal[i].c_str(), info.fea_literal[i].size());
        if (dedup.find(sign) == dedup.end()) {
          dedup.insert(sign);
          out << " " << sign << ":1";
        }
      }
      out << std::endl;
    }
  }
  LOG(INFO) << "dump train ins thread ends";
}

static bool cmp(const std::pair<std::string, int64>& lhs, const std::pair<std::string, int64>& rhs) {
  if (lhs.second > rhs.second) {
    return true;
  } else {
    return false;
  }
}

void GenerateFeaIdFile(std::vector<std::vector<InstanceInfo> >* ins_infos) {
  std::ofstream out(FLAGS_fea_id_file.c_str());
  std::map<std::string, int64> dedup;
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      const InstanceInfo& info = *jt;
      for (size_t i = 0; i < info.fea_literal.size(); ++i) {
        dedup[info.fea_literal[i]] += 1;
      }
    }
  }

  std::vector<std::pair<std::string, int64> > v;
  v.reserve(dedup.size());
  for (auto it = dedup.begin(); it != dedup.end(); ++it) {
    v.push_back(*it);
  }
  std::sort(v.begin(), v.end(), cmp);
  for (auto it = v.begin(); it != v.end(); ++it) {
    uint64 sign = base::CityHash64(it->first.c_str(), it->first.size());
    out << it->first << "\t" << sign << "\t" << it->second << std::endl;
  }
  out.close();
  LOG(INFO) << "dump fea id thread ends";
}

void GenerateLiteralInsFile(std::vector<std::vector<InstanceInfo> >* ins_infos) {
  std::ofstream out(FLAGS_literal_ins_file.c_str());
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      const InstanceInfo& info = *jt;
      out << info.show_num << " " << info.click_num;
      for (size_t i = 0; i < info.fea_literal.size(); ++i) {
        out << " " << info.fea_literal[i];
      }
      out << std::endl;
    }
  }
  out.close();
  LOG(INFO) << "dump literal ins thread ends";
}

void GenerateRecoMetaFile(std::vector<std::vector<InstanceInfo> >* ins_infos) {
  std::ofstream out(FLAGS_reco_meta_file.c_str());
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      const InstanceInfo& info = *jt;
      for (size_t i = 0; i < info.reco_meta.size(); ++i) {
        if (i != 0) out << " ";
        out << info.reco_meta[i];
      }
      out << std::endl;
    }
  }
  out.close();
  LOG(INFO) << "dump item meta thread ends";
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");

  std::unordered_map<uint64, std::vector<InstanceInfo> > sample_dict;
  LoadSampleFile(&sample_dict);
  thread::BlockingQueue<reco::UserInfo*> user_queue;
  thread::ThreadPool pool(FLAGS_thread_num);
  if (!FLAGS_user_dump_file.empty() && !FLAGS_user_file.empty()) {
    CHECK(false) << "item id or dump item file should chose just one";
  } else if (!FLAGS_user_dump_file.empty()) {
    reco::ml::LoadDumpProtoFile<reco::UserInfo>(FLAGS_user_dump_file, &user_queue);
  } else if (!FLAGS_user_file.empty()) {
    reco::ml::GetUserMultiThread(FLAGS_user_file,
                                 FLAGS_user_server_machine_list,
                                 FLAGS_user_profile_machine_list,
                                 4, FLAGS_clear_show, &user_queue);
  } else {
    CHECK(false) << "no input item";
  }

  user_queue.Close();
  // meta, fea literal
  std::vector<std::vector<InstanceInfo> > ins_infos(FLAGS_thread_num);

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(ExtractFeature, &user_queue,
                               &sample_dict,
                               &(ins_infos[i])));
  }
  while (g_finished_threads != FLAGS_thread_num) {
    base::SleepForSeconds(5);
  }

  if (!FLAGS_train_ins_file.empty()) {
    pool.AddTask(::NewCallback(GenerateTrainInsFile, &ins_infos));
  }
  if (!FLAGS_literal_ins_file.empty()) {
    pool.AddTask(::NewCallback(GenerateLiteralInsFile, &ins_infos));
  }
  if (!FLAGS_fea_id_file.empty()) {
    pool.AddTask(::NewCallback(GenerateFeaIdFile, &ins_infos));
  }
  if (!FLAGS_reco_meta_file.empty()) {
    pool.AddTask(::NewCallback(GenerateRecoMetaFile, &ins_infos));
  }
  pool.JoinAll();
}
