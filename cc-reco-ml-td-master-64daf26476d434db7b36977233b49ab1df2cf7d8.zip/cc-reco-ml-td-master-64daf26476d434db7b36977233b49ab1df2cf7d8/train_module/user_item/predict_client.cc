#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/ml/model/lr_model.h"
#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/common/io_util.h"
#include "reco/ml/auc/auc.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"
#include "base/thread/thread_util.h"
#include "base/hash_function/city.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_int32(thread_num, 4, "生成样本的处理线程");

DEFINE_string(user_server_machine_list, "../config/user_server_machine.yaml.em21", "user server");
DEFINE_string(user_profile_machine_list, "../config/user_profile_machine.yaml.em21", "user profile server");

DEFINE_string(sample_file, "", "sample file for generating instances");

DEFINE_bool(clear_show, true, "clear user shown history");
DEFINE_string(user_file, "", "user id file, one id per line");
DEFINE_string(user_dump_file, "", "dumped reco user file");

DEFINE_string(predict_result_file, "predict_result", "预测的结果");
DEFINE_string(model_file, "model", "模型文件");

DEFINE_int32(min_feature_hits, 3, "min feature hits to trust the predict result");

std::atomic<int> g_finished_threads(0);
thread::Mutex g_mutex;

struct InstanceInfo {
  uint64 reco_id;
  uint64 item_id;
  int64 read_tm;
  int show_num;
  int click_num;
  double ctr;
  std::string app_name;
  std::string utdid;
  std::string imei;
  std::vector<std::string> fea_literal;
  std::vector<std::string> reco_meta;
  std::vector<std::string> hit_features;
};

void LoadSampleFile(std::unordered_map<uint64, std::vector<InstanceInfo> >* sample_dict) {
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_sample_file, &lines);
  std::vector<std::string> flds;
  std::vector<std::string> subs;
  for (size_t i = 0; i < lines.size(); ++i) {
    flds.clear();
    // app+"`"+userid, utdid, imei, recoid, itemid, click
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 6u) continue;
    subs.clear();
    base::SplitString(flds[0], "`", &subs);
    if (subs.size() != 2u) continue;
    uint64 user_id = base::ParseUint64OrDie(subs[1]);
    InstanceInfo info;
    info.reco_id = base::ParseUint64OrDie(flds[3]);
    info.item_id = base::ParseUint64OrDie(flds[4]);
    info.read_tm = base::ParseIntOrDie(flds[5]);
    info.app_name = subs[0];
    info.utdid = flds[1];
    info.imei = flds[2];
    (*sample_dict)[user_id].push_back(info);
  }
}

void Predict(reco::ml::LRModel* model,
             thread::BlockingQueue<reco::UserInfo*>* user_queue,
             std::unordered_map<uint64, std::vector<InstanceInfo>>* sample_dict,
             std::vector<InstanceInfo>* ins_infos) {
  reco::ml::BaseFeatureExtractor* extractor = new reco::ml::UserItemIdFeatureExtractor();

  std::vector<std::string> strs;
  extractor->SetupFeatureLayout();
  while (!user_queue->Empty()) {
    reco::UserInfo* puser = user_queue->Take();
    if (puser == NULL) continue;

    scoped_ptr<reco::UserInfo> p(puser);

    const reco::UserInfo& user = *puser;
    auto it = sample_dict->find(user.identity().user_id());
    if (it == sample_dict->end()) continue;

    const std::vector<InstanceInfo>& samples = it->second;
    extractor->ResetUser(user);
    reco::RecoItem item;
    for (size_t i = 0; i < samples.size(); ++i) {
      strs.clear();
      const InstanceInfo& sample = samples[i];
      item.mutable_identity()->set_item_id(sample.item_id);
      extractor->ExtractUserItemFeature(item, &strs);
      if (strs.empty()) {
        continue;
      }

      ins_infos->push_back(sample);
      InstanceInfo& info = ins_infos->back();
      std::swap(info.fea_literal, strs);

      // ins
      double sum_w;
      int hits;
      model->Predict(info.fea_literal, &sum_w, &hits, &info.ctr, &info.hit_features);
      if (hits < FLAGS_min_feature_hits) {
        ins_infos->pop_back();
        continue;
      }

      info.show_num = 1;
      info.click_num = info.read_tm > 0 ? 1 : 0;

      // meta
      strs.clear();
      strs.push_back(info.app_name);
      strs.push_back(base::Uint64ToString(user.identity().user_id()));
      strs.push_back(info.utdid);
      strs.push_back(info.imei);
      strs.push_back(base::Uint64ToString(info.reco_id));
      strs.push_back(base::Uint64ToString(info.item_id));
      std::swap(info.reco_meta, strs);
    }
  }

  delete extractor;

  LOG(INFO) << "thread " << thread::GetThreadID() << " finished, gen instance: " << ins_infos->size();
  thread::AutoLock lock(&g_mutex);
  ++g_finished_threads;
}

void GeneratePredictResultFile(std::vector<std::vector<InstanceInfo> >* ins_infos) {
  std::ofstream out(FLAGS_predict_result_file.c_str());
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      const InstanceInfo& info = *jt;
      for (size_t i = 0; i < info.reco_meta.size(); ++i) {
        if (i != 0) out << "\t";
        out << info.reco_meta[i];
      }
      out << "\t" << static_cast<int>(10000 * info.ctr) / 10000.0;
      if (!info.hit_features.empty()) {
        out << "\t";
        for (size_t i = 0; i < info.hit_features.size(); ++i) {
          out << info.hit_features[i] << ",";
        }
      }
      out << std::endl;
    }
  }
  out.close();
  LOG(INFO) << "dump item meta thread ends";
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");


  std::unordered_map<uint64, std::vector<InstanceInfo> > sample_dict;
  LoadSampleFile(&sample_dict);
  thread::BlockingQueue<reco::UserInfo*> user_queue;
  thread::ThreadPool pool(FLAGS_thread_num);
  if (!FLAGS_user_dump_file.empty() && !FLAGS_user_file.empty()) {
    CHECK(false) << "item id or dump item file should chose just one";
  } else if (!FLAGS_user_dump_file.empty()) {
    reco::ml::LoadDumpProtoFile<reco::UserInfo>(FLAGS_user_dump_file, &user_queue);
  } else if (!FLAGS_user_file.empty()) {
    reco::ml::GetUserMultiThread(FLAGS_user_file,
                                 FLAGS_user_server_machine_list,
                                 FLAGS_user_profile_machine_list,
                                 4, FLAGS_clear_show, &user_queue);
  } else {
    CHECK(false) << "no input item";
  }

  user_queue.Close();
  // meta, fea literal
  std::vector<std::vector<InstanceInfo> > ins_infos(FLAGS_thread_num);

  reco::ml::LRModel* model = new reco::ml::DenseHashLRModel();
  model->LoadText(FLAGS_model_file);

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(Predict,
                               model,
                               &user_queue,
                               &sample_dict,
                               &(ins_infos[i])));
  }
  while (g_finished_threads != FLAGS_thread_num) {
    base::SleepForSeconds(5);
  }

  if (!FLAGS_predict_result_file.empty()) {
    pool.AddTask(::NewCallback(GeneratePredictResultFile, &ins_infos));
  }
  pool.JoinAll();

  std::vector<reco::ml::PredCTR> pctrs;
  for (auto it = ins_infos.begin(); it != ins_infos.end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      if (jt->click_num == 0) continue;
      reco::ml::PredCTR pctr;
      pctr.query = jt->reco_meta[1];
      pctr.pos_weight = jt->click_num;
      pctr.neg_weight = jt->show_num - jt->click_num;
      pctr.prediction = jt->ctr;
      pctrs.push_back(pctr);
    }
  }
  double auc, qauc, wqauc, iqauc;
  auc = reco::ml::CalcRocAuc(pctrs);
  reco::ml::CalcQueryAuc(pctrs, &qauc, &wqauc);
  iqauc = reco::ml::CalcInterQueryAuc(pctrs);
  double logloss = reco::ml::LogLoss(pctrs);
  LOG(INFO) << "Instance cnt=" << pctrs.size();
  LOG(INFO) << "Prior model auc=" << auc
            << ", qauc=" << qauc
            << ", wqauc=" << wqauc
            << ", iqauc=" << iqauc
            << ", logloss=" << logloss;

  delete model;
}
