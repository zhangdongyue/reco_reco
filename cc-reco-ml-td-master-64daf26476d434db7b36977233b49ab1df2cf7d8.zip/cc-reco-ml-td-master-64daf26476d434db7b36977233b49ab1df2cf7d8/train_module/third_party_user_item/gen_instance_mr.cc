#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/proto/item.pb.h"
#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/common/io_util.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_string(job_name, "unknown","mr job name");
DEFINE_int32(min_instance_fea_num, 1, "minimun of feature num for a training instance");
DEFINE_int32(fea_sparse_threshold, 10, "sparse fea threshold");

struct InstanceInfo {
  uint64 reco_id;
  uint64 user_id;
  std::string app_name;
  uint64 item_id;
  std::string category;
  std::string tag;
  int show_num;
  int click_num;
  std::vector<std::string> fea_literal;
  std::vector<std::string> reco_meta;
};

void ExtractFeature(reco::ml::ThirdPartyDataItemFeatureExtractor* extractor,
                    const std::vector<reco::user::UserInfo>& user_info_vec,
                    const std::vector<InstanceInfo>& sample_vec,
                    std::vector<InstanceInfo>* ins_infos) {
  ins_infos->clear();

  std::vector<std::string> strs;
  std::vector<std::string> flds;
  for (size_t i = 0; i < user_info_vec.size(); ++i) {
    const reco::user::UserInfo& user = user_info_vec[i];
    extractor->ResetUser(user);
    for (size_t j = 0; j < sample_vec.size(); ++j) {
      reco::RecoItem item;
      const InstanceInfo& sample = sample_vec[j];
      item.mutable_identity()->set_item_id(sample.item_id);
      flds.clear();
      base::SplitString(sample.category, ",", &flds);
      for (size_t k = 0; k < flds.size(); ++k) {
        item.add_category(flds[k]);
      }
      flds.clear();
      base::SplitString(sample.tag, ",", &flds);
      reco::FeatureVector tag_fea_vec;
      tag_fea_vec.set_norm(1);
      for (size_t k = 0; k < flds.size(); ++k) {
        reco::Feature* tag_fea = tag_fea_vec.add_feature();
        tag_fea->set_literal(flds[k]);
        tag_fea->set_weight(1.0);
      }
      item.mutable_tag()->CopyFrom(tag_fea_vec);
      
      strs.clear();
      extractor->ExtractUserItemFeature(item, &strs);
      // 默认会添加一个 bias , 所以判断 fea num 需要加 1
      if ((int)strs.size() < FLAGS_min_instance_fea_num + 1) {
        continue;
      }

      ins_infos->push_back(sample);
      InstanceInfo& info = ins_infos->back();
      std::swap(info.fea_literal, strs);

      // meta
      strs.clear();
      strs.push_back(base::Uint64ToString(user.identity().user_id()));
      strs.push_back(base::Uint64ToString(info.item_id));
      strs.push_back(info.category);
      std::swap(info.reco_meta, strs);
    }
  }
}

void GenerateTrainIns(std::vector<InstanceInfo>* ins_infos) {
  std::set<int64> dedup;
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    const InstanceInfo& info = *it;
    std::cout << "A\t" << info.show_num << " " << info.click_num;
    dedup.clear();
    for (size_t i = 0; i < info.fea_literal.size(); ++i) {
      uint64 sign = base::CityHash64(info.fea_literal[i].c_str(), info.fea_literal[i].size());
      if (dedup.find(sign) == dedup.end()) {
        dedup.insert(sign);
        std::cout << " " << sign << ":1";
      }
    }
    std::cout << std::endl;
  }
}

void GenerateLiteralIns(std::vector<InstanceInfo>* ins_infos) {
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    const InstanceInfo& info = *it;
    std::cout << "B\t" << info.show_num << " " << info.click_num;
    for (size_t i = 0; i < info.fea_literal.size(); ++i) {
      std::cout << " " << info.fea_literal[i];
    }
    std::cout << std::endl;
  }
}

void GenerateRecoMeta(std::vector<InstanceInfo>* ins_infos) {
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    const InstanceInfo& info = *it;
    std::cout << "D\t";
    for (size_t i = 0; i < info.reco_meta.size(); ++i) {
      if (i != 0) std::cout << " ";
      std::cout << info.reco_meta[i];
    }
    std::cout << std::endl;
  }
}

void GenerateFeaId(std::vector<InstanceInfo>* ins_infos) {
  std::map<std::string, int64> dedup;
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    const InstanceInfo& info = *it;
    for (size_t i = 0; i < info.fea_literal.size(); ++i) {
      dedup[info.fea_literal[i]] += 1;
    }
  }

  std::vector<std::pair<std::string, int64> > v;
  v.reserve(dedup.size());
  for (auto it = dedup.begin(); it != dedup.end(); ++it) {
    v.push_back(*it);
  }
  for (auto it = v.begin(); it != v.end(); ++it) {
    uint64 sign = base::CityHash64(it->first.c_str(), it->first.size());
    std::cout << "C\t" << it->first << "\t" << sign << "\t" << it->second << std::endl;
  }
}

void OutputInsInfos(std::vector<InstanceInfo>* ins_infos) {
  GenerateTrainIns(ins_infos);
  GenerateLiteralIns(ins_infos);
  GenerateFeaId(ins_infos);
  // GenerateRecoMeta(ins_infos);
}

// map: 将离线 user info 和 merge log 按 user id 分发到 reducer 
void InstanceMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    // 根据长度判断 user info 和 merge log
    if (flds.size() == 11u) {
      // preprocessed merge log
      // uid ~ itemid ~ category ~ tag ~ click
      std::cout << base::StringPrintf("%s\t%s\t%s\t%s\t%s", flds[6].c_str(),
                                      flds[7].c_str(), flds[8].c_str(), flds[9].c_str(), flds[10].c_str())
                << std::endl;
    } else if (flds.size() == 2u) {
      // preprocessed user info
      std::cout << base::StringPrintf("%s\t%s", flds[0].c_str(), flds[1].c_str()) << std::endl;
    }
  }
}

void InstanceReduce() {
  reco::ml::ThirdPartyDataItemFeatureExtractor* extractor = new reco::ml::ThirdPartyDataItemFeatureExtractor();
  extractor->SetupFeatureLayout();

  std::string line;
  std::string current_key;
  std::vector<std::string> flds;
  std::vector<reco::user::UserInfo> user_info_vec; // 用户信息
  std::vector<InstanceInfo> sample_vec; // 用户点击信息
  std::vector<InstanceInfo> ins_infos; // 训练样本
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds[0] != current_key) {
      if (!current_key.empty()) {
        // generate train instances
        ExtractFeature(extractor, user_info_vec, sample_vec, &ins_infos);
        OutputInsInfos(&ins_infos);
      }
      current_key = flds[0];
      user_info_vec.clear();
      sample_vec.clear();
      ins_infos.clear();
    }

    if (flds.size() == 2u) {
      // user info
      //VLOG(1) << "input user info: " << line;
      std::string unescape;
      if (!base::LineUnescape(flds[1], &unescape)) {
        continue;
      }
      reco::user::UserInfo user_info;
      if (!user_info.ParseFromString(unescape)) {
        continue;
      }
      user_info_vec.push_back(user_info);
    } else if (flds.size() == 5u) {
      // merge log
      //VLOG(1) << "input merge log: " << line;
      InstanceInfo sample;
      if (!base::StringToUint64(flds[1], &sample.item_id)) continue;
      sample.category = flds[2];
      sample.tag = flds[3];
      sample.show_num = 1;
      if (!base::StringToInt(flds[4], &sample.click_num)) continue;
      sample_vec.push_back(sample);
    }
  }
  if (!current_key.empty()) {
    // generate train instances
    ExtractFeature(extractor, user_info_vec, sample_vec, &ins_infos);
    OutputInsInfos(&ins_infos);
  }
  user_info_vec.clear();
  sample_vec.clear();
  ins_infos.clear();

  delete extractor;
}

// 对离线 dump 的 user info 进行清洗和格式转换
void UserInfoMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 2u) {
      continue;
    }
    std::cout << line << std::endl;
  }
}

void UserInfoReduce() {
  std::string line;
  while (getline(std::cin, line)) {
    std::cout << line << std::endl;
  }
}

void MergeLogMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 65u) {
      continue;
    }
    std::string app_name = flds[1];
    uint64 reco_id;
    if (!base::StringToUint64(flds[2], &reco_id)) continue;
    uint64 item_id;
    if (!base::StringToUint64(flds[3], &item_id)) continue;
    int item_type;
    if (!base::StringToInt(flds[4], &item_type)) continue;
    int64 cid;
    if (!base::StringToInt64(flds[5], &cid)) continue;
    int pos;
    if (!base::StringToInt(flds[6], &pos)) continue;
    uint64 user_id;
    if (!base::StringToUint64(flds[9], &user_id)) continue;
    int click;
    if (!base::StringToInt(flds[10], &click)) continue;
    std::string category = flds[17];
    int refresh_type;
    if (!base::StringToInt(flds[45], &refresh_type)) continue;
    std::string tag = flds[64];

    // filter
    if (item_type == 0 || item_type == 1 || item_type == 2 || item_type == 4) {
    } else {
      continue;
    }

    if (app_name == "uc-iflow") {
    } else {
      continue;
    }

    // 只取推荐频道主动刷新数据
    if (cid != 100 || reco_id == 0u || user_id == 0u
        || category.empty() || category == "未分类"
        || refresh_type != 0) {
      continue;
    }

    std::cout << base::StringPrintf("%lu\t%ld\t%d\t%d\t%d\t%s\t%lu\t%lu\t%s\t%s",
                  reco_id, cid, pos, refresh_type, click, app_name.c_str(), user_id,
                  item_id, category.c_str(), tag.c_str())
              << std::endl;
  }
}

void GenMergeLogReduceOutput(std::map<int, std::string>& merge_logs, std::set<int>& clicked_pos) {
  std::set<int> unclicked_pos;
  for (auto it = clicked_pos.begin(); it != clicked_pos.end(); ++it) {
    for (int idx = *it - 2; idx <= *it + 2; idx++) {
      if (idx >= 0 && clicked_pos.find(idx) == clicked_pos.end()) {
        unclicked_pos.insert(idx);
      }
    }
  }
  for (auto it = merge_logs.begin(); it != merge_logs.end(); ++it) {
    if (clicked_pos.find(it->first) != clicked_pos.end()) {
      // 正样本
      std::cout << it->second << "\t1" << std::endl;
    } else if (unclicked_pos.find(it->first) != unclicked_pos.end()) {
      // 负样本
      std::cout << it->second << "\t0" << std::endl;
    }
  }
}

void MergeLogReduce() {
  std::string current_key;
  std::set<int> clicked_pos; // 用户点击过的位置
  std::map<int, std::string> merge_logs; // pos - mergelog

  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 10u) {
      continue;
    }
    
    if (current_key != flds[0]) {
      GenMergeLogReduceOutput(merge_logs, clicked_pos);
      clicked_pos.clear();
      merge_logs.clear();
      current_key = flds[0];
    }

    int pos;
    if (!base::StringToInt(flds[2], &pos)) continue;
    int click;
    if (!base::StringToInt(flds[4], &click)) continue;
    merge_logs[pos] = line;
    if (click > 3) {
      clicked_pos.insert(pos);
    }
  }
  GenMergeLogReduceOutput(merge_logs, clicked_pos);
  clicked_pos.clear();
  merge_logs.clear();
}

void TrainInstanceMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds[0] != "A") {
      continue;
    }
    for (size_t i = 1; i < flds.size(); ++i) {
      if (i > 1) std::cout << "\t";
      std::cout << flds[i];
    }
    std::cout << std::endl;
  }
}

void TrainInstanceReduce() {
  std::string line;
  while (getline(std::cin, line)) {
    std::cout << line << std::endl;
  }
}

void LiteralInstanceMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds[0] != "B") {
      continue;
    }
    for (size_t i = 1; i < flds.size(); ++i) {
      if (i > 1) std::cout << "\t";
      std::cout << flds[i];
    }
    std::cout << std::endl;
  }
}

void LiteralInstanceReduce() {
  std::string line;
  while (getline(std::cin, line)) {
    std::cout << line << std::endl;
  }
}

void FeaIdMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds[0] != "C") {
      continue;
    }
    for (size_t i = 1; i < flds.size(); ++i) {
      if (i > 1) std::cout << "\t";
      std::cout << flds[i];
    }
    std::cout << std::endl;
  }
}

void FeaIdReduce() {
  std::string current_key;
  std::string line;
  std::vector<std::string> flds;
  int num = 0;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 3u) {
      continue;
    }
    if (flds[1] + "\t" + flds[0] != current_key) {
      if (!current_key.empty() && num >= FLAGS_fea_sparse_threshold) {
        std::cout << current_key << "\t" << num << std::endl;
      }
      current_key = flds[1] + "\t" + flds[0];
      num = 0;
    }
    num += base::ParseIntOrDie(flds[2]);
  }

  if (!current_key.empty()) {
    std::cout << current_key << "\t" << num << std::endl;
  }
}

void ReadFeaDict(std::string file_path, std::unordered_set<uint64>* dict) {
  std::ifstream ifs(file_path);
  std::string line;
  std::vector<std::string> flds;
  uint64 fea_id;
  while (getline(ifs, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (!base::StringToUint64(flds[0], &fea_id)) continue;
    dict->insert(fea_id);
    // if (dict->size() % 10000 == 0) std::cout << "dict_size=" << dict->size() << std::endl;
  }
}

void FeaIdFilterMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 3u) {
      continue;
    }
    int num;
    if (!base::StringToInt(flds[2], &num) || num < FLAGS_fea_sparse_threshold) continue;

    std::cout << flds[0] << std::endl;
  }
}

void TrainInstanceFilterMap() {
  std::string line;
  while (getline(std::cin, line)) {
    uint64 sign = base::CityHash64(line.c_str(), line.size());
    std::cout << sign << "\t" << line << std::endl;
  }
}

void TrainInstanceFilterReduce() {
  // read fea dict
  std::unordered_set<uint64> fea_id_set;
  ReadFeaDict("fea_id_set.txt", &fea_id_set);

  std::string line;
  std::vector<std::string> flds;
  std::vector<std::string> fea_vec;
  std::vector<std::string> fea_flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 3u) continue;

    fea_vec.clear();
    base::SplitString(flds[1], " ", &fea_vec);
    if (fea_vec.size() < 3u) continue;

    // 1-3 项分别为 click show bias, 直接跳过
    int p = 3;
    uint64 fea_id;
    for (size_t i = 3; i < fea_vec.size(); ++i) {
      fea_flds.clear();
      base::SplitString(fea_vec[i], ":", &fea_flds);
      if (fea_flds.size() != 2u) continue;
      if (!base::StringToUint64(fea_flds[0], &fea_id)) continue;
      if (fea_id_set.find(fea_id) == fea_id_set.end()) continue;

      fea_vec[p] = fea_vec[i];
      p++;
    }
    fea_vec.resize(p);

    // 剔除过滤后 fea num 过少的 train instance
    if (p >= 3 + FLAGS_min_instance_fea_num) {
      std::cout << base::JoinStrings(fea_vec, " ") << "\t" << flds[2] << std::endl;
    }
  }
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "tp_item_lr_train_instance");
  if (FLAGS_job_name == "instance_map") {
    InstanceMap();
  } else if (FLAGS_job_name == "instance_reduce") {
    InstanceReduce();
  } else if (FLAGS_job_name == "user_info_map") {
    UserInfoMap();
  } else if (FLAGS_job_name == "user_info_reduce") {
    UserInfoReduce();
  } else if (FLAGS_job_name == "merge_log_map") {
    MergeLogMap();
  } else if (FLAGS_job_name == "merge_log_reduce") {
    MergeLogReduce();
  } else if (FLAGS_job_name == "train_instance_map") {
    TrainInstanceMap();
  } else if (FLAGS_job_name == "train_instance_reduce") {
    TrainInstanceReduce();
  } else if (FLAGS_job_name == "train_instance_filter_map") {
    TrainInstanceFilterMap();
  } else if (FLAGS_job_name == "train_instance_filter_reduce") {
    TrainInstanceFilterReduce();
  } else if (FLAGS_job_name == "literal_instance_map") {
    LiteralInstanceMap();
  } else if (FLAGS_job_name == "literal_instance_reduce") {
    LiteralInstanceReduce();
  } else if (FLAGS_job_name == "fea_id_map") {
    FeaIdMap();
  } else if (FLAGS_job_name == "fea_id_reduce") {
    FeaIdReduce();
  } else if (FLAGS_job_name == "fea_id_filter_map") {
    FeaIdFilterMap();
  } else {
    CHECK(false) << "invalid mr type: " << FLAGS_job_name;
  }
}
