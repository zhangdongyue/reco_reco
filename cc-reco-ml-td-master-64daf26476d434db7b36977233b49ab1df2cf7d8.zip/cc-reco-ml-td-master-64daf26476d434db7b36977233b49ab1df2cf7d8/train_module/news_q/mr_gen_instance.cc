#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <sstream>

#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/common/item_util.h"
#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/feature/base/bias.h"
#include "reco/ml/common/io_util.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"
#include "base/random/pseudo_random.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_string(item_keeper_ips, "11.251.202.129", "item keeper");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");

DEFINE_string(instance_subdir, "instance", "");
DEFINE_string(feaset_subdir, "feaset", "");

DEFINE_bool(mapper, false, "");
DEFINE_bool(reducer, false, "");

void reducer() {
  std::string last_key;
  std::vector<std::string> flds;
  std::pair<int, std::string> max_instance = std::make_pair(0, "");
  // fea id -> fea liter, fea cnt
  std::map<uint64, std::pair<uint64, std::string> > feaset;
  std::string line;
  while (std::getline(std::cin, line)) {
    base::TrimTrailingWhitespaces(&line);
    flds.clear();
    base::SplitStringWithMoreOptions(line, "\t", false, false, 1, &flds);
    std::string key = flds[0];
    std::string val = flds[1];
    if (key != last_key) {
      if (last_key[0] == 'I') {
        if (!max_instance.second.empty()) {
          std::cout << FLAGS_instance_subdir << "#" << max_instance.second << std::endl;
          max_instance = std::make_pair(0, "");
        }
      } else if (last_key[0] == 'F') {
        for (auto it = feaset.begin(); it != feaset.end(); ++it) {
          std::cout << FLAGS_feaset_subdir << "#"
                    << it->first << "\t" << it->second.second << "\t" << it->second.first << std::endl;
        }
        feaset.clear();
      }
    }
    last_key = key;
    if (last_key[0] == 'I') {
      flds.clear();
      base::SplitString(val, " ", &flds);
      int click = base::ParseIntOrDie(flds[1]);
      if (click > max_instance.first) {
        max_instance = std::make_pair(click, val);
      }
    } else if (last_key[0] == 'F') {
      uint64 sign = base::ParseUint64OrDie(last_key.substr(1));
      auto it = feaset.find(sign);
      if (it == feaset.end()) {
        feaset[sign] = std::make_pair(1, val);
      } else {
        feaset[sign].first++;
      }
    }
  }

  if (last_key[0] == 'I') {
    if (!max_instance.second.empty()) {
      std::cout << FLAGS_instance_subdir << "#" << max_instance.second << std::endl;
      max_instance = std::make_pair(0, "");
    }
  } else if (last_key[0] == 'F') {
    for (auto it = feaset.begin(); it != feaset.end(); ++it) {
      std::cout << FLAGS_feaset_subdir << "#"
                << it->first << "\t" << it->second.second << "\t" << it->second.first << std::endl;
    }
    feaset.clear();
  }
}

void mapper() {
  std::vector<uint64> item_ids;
  std::string line;
  std::vector<std::string> flds;
  while (std::getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    uint64 item_id;
    if (!base::StringToUint64(flds[0], &item_id)) {
      continue;
    }
    item_ids.push_back(item_id);
  }

  reco::ml::BaseFeatureExtractor* extractor = new reco::ml::NewsItemFeatureExtractor();
  extractor->SetupFeatureLayout();
  reco::BaseGetItem* get_item = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips, FLAGS_item_keeper_port);
  static int kStepSize = 100;

  std::vector<reco::RecoItem> reco_items;
  std::vector<std::string> strs;
  std::set<int64> dedup;
  base::PseudoRandom rand;
  for (size_t i = 0; i < item_ids.size(); i += kStepSize) {
    size_t end = std::min(i + kStepSize, item_ids.size());
    std::vector<uint64> subs(item_ids.begin() + i, item_ids.begin() + end);
    reco_items.clear();
    get_item->GetRecoItems(subs, &reco_items);
    for (size_t j = 0; j < reco_items.size(); ++j) {
      const reco::RecoItem& item = reco_items[j];
      int click_num = item.quality_attr().posterior_itemq();
      if (0 == click_num) {
        continue;
      }
      uint64 title_sign = base::CityHash64(item.title().c_str(), item.title().size());
      strs.clear();
      extractor->ExtractItemFeature(item, &strs);
      if (strs.empty()) {
        continue;
      }
      std::stringstream ss;
      ss << "I" << title_sign << "\t100 " << click_num;

      dedup.clear();
      for (size_t i = 0; i < strs.size(); ++i) {
        const std::string& fea = strs[i];
        if (fea.find("#") != std::string::npos) {
          continue;
        }
        uint64 sign = base::CityHash64(fea.c_str(), fea.size());
        if (sign == extractor->GetBiasSign() && rand.GetDouble() < 0.9) {
          // bias 特征低概率随机输出 feaset，不然分桶不均
          continue;
        }
        if (dedup.find(sign) == dedup.end()) {
          dedup.insert(sign);
          ss << " " << sign << ":1";
          std::cout << "F" << sign << "\t" << fea << std::endl;
        }
      }
      std::cout << ss.str() << std::endl;
    }
  }

  delete get_item;
  delete extractor;
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "mr_gen_instance");

  if (FLAGS_mapper) {
    mapper();
  }
  if (FLAGS_reducer) {
    reducer();
  }
  return 0;
}
