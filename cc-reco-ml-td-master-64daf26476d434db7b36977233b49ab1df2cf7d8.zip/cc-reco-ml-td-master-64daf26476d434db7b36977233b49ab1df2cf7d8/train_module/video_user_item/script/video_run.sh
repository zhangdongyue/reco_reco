
# data dir

current_date=$(date +"%Y%m%d")
echo $current_date
hadoop fs -test -e /reco/video/useritem/instance/$current_date/train/_SUCCESS
if [ $? -eq 0 ] ;then
    echo 'train data exist'
    exit 0;
fi
datenum=3
mergeloginput=""
userinfoinput=""
mergelogpre=/reco/user_profile/cold_start/user_item/merge_log_joined/
userinfopre=/reco/user_info_dump/user_info_online/
for((i=2;i<2+$datenum;i++))
  do
    date=`date -d "-$i day $current_date" +"%Y%m%d"`
    if [ -z "$mergeloginput" ];then
      mergeloginput=$mergelogpre$date
      userinfoinput=$userinfopre$date
    else
      mergeloginput=$mergeloginput,$mergelogpre$date
      userinfoinput=$userinfoinput,$userinfopre$date
    fi
  done

input=$mergeloginput
output=/reco/video/useritem/mergelog/$current_date

echo $input
echo $output

$HADOOP_HOME/bin/hadoop fs -rm -r $output
$HADOOP_HOME/bin/hadoop jar $HADOOP_STREAMING_JAR \
  -D mapred.reduce.tasks=399 \
  -D mapreduce.reduce.memory.mb=16384 \
  -D mapreduce.job.running.map.limit=2000 \
  -D mapreduce.job.running.reduce.limit=1000 \
  -files "gen_instance" \
  -input $mergeloginput \
  -output $output \
  -mapper "./gen_instance --job_name=merge_log_map" \
  -reducer "./gen_instance --job_name=merge_log_reduce" \

input=${userinfoinput},${output}
output=/reco/video/useritem/instance/$current_date/literal

echo $input
echo $output

$HADOOP_HOME/bin/hadoop fs -rm -r $output
$HADOOP_HOME/bin/hadoop jar $HADOOP_STREAMING_JAR \
  -D mapred.reduce.tasks=1000 \
  -D mapreduce.reduce.memory.mb=8000 \
  -D mapreduce.job.running.map.limit=3000 \
  -D mapreduce.job.running.reduce.limit=1000 \
  -files "gen_instance" \
  -input $input \
  -output $output \
  -mapper "./gen_instance --job_name=literal_instance_map" \
  -reducer "./gen_instance --job_name=literal_instance_reduce" \

input=/reco/video/useritem/instance/$current_date/literal
output=/reco/video/useritem/instance/$current_date/newfea

echo $input
echo $output

$HADOOP_HOME/bin/hadoop fs -rm -r $output
$HADOOP_HOME/bin/hadoop jar $HADOOP_STREAMING_JAR \
  -D mapred.reduce.tasks=500 \
  -D mapreduce.reduce.memory.mb=8000 \
  -D mapreduce.job.running.map.limit=3000 \
  -D mapreduce.job.running.reduce.limit=1000 \
  -files "gen_instance" \
  -input $input \
  -output $output \
  -mapper "./gen_instance --job_name=fea_dict_map" \
  -reducer "./gen_instance --job_name=fea_dict_reduce --fea_sparse_threshold=100" \

if [ $? -eq 0 ];then
  rm -f ./fea_dict.txt
  rm -f ./fea_id_set.txt
  $HADOOP_HOME/bin/hadoop fs -getmerge ${output} ./fea_dict.txt
  cat ./fea_dict.txt | awk -F '\t' '{print $1}' > ./fea_id_set.txt
  echo "finished"
else
  exit 255
fi

input=/reco/video/useritem/instance/$current_date/literal
output=/reco/video/useritem/instance/$current_date/train

echo $input
echo $output

rm -f .fea_id_set.txt.crc

$HADOOP_HOME/bin/hadoop fs -rm -r $output
$HADOOP_HOME/bin/hadoop jar $HADOOP_STREAMING_JAR \
  -D mapred.reduce.tasks=1000 \
  -D mapreduce.reduce.memory.mb=8000 \
  -D mapreduce.job.running.map.limit=2000 \
  -D mapreduce.job.running.reduce.limit=1000 \
  -files "gen_instance" \
  -file "fea_id_set.txt" \
  -input $input \
  -output $output \
  -mapper "./gen_instance --job_name=train_instance_map" \
  -reducer "./gen_instance --job_name=train_instance_reduce" \

