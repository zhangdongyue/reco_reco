#!/bin/bash

set -u

cd /home/serving/sam.zk/user_item/

sh ./video_run.sh

current_date=$(date +"%Y%m%d")

local_model_root=model/coldstart$current_date
ins_path_root=/reco/video/useritem/instance/$current_date/train

output=/user/serving/sam.zk/reco/video/useritem/outmodel/$current_date/

hadoop fs -test -e $output/_SUCCESS
if [ $? -eq 0 ] ;then
    echo "model exist"
    exit 0;
fi

cd training
sh -x train.sh --ins_path=$ins_path_root --model_path=../$local_model_root
cd ..
hdfsmodeldir=/reco/video/useritem/model/coldstart$current_date
hadoop fs -put $local_model_root $hdfsmodeldir

fea_dict_dir=/reco/video/useritem/instance/$current_date/newfea/

${HADOOP_HOME}/bin/hadoop jar  ${HADOOP_STREAMING_JAR} \
 -D stream.num.map.output.key.fields=1 \
 -D mapreduce.job.maps=10 \
 -D mapreduce.job.reduces=10 \
 -D mapreduce.reduce.memory.mb=8192 \
 -D mapreduce.job.running.map.limit=1000 \
 -D mapreduce.job.running.reduce.limit=100 \
 -D mapreduce.job.reduce.slowstart.completedmaps=1.0 \
 -D mapreduce.job.priority=VERY_HIGH \
 -D mapreduce.job.name=cold_start_model \
 -files "mr_merge_model" \
 -input "${fea_dict_dir},${hdfsmodeldir}" \
 -output "${output}" \
 -mapper "cat" \
 -reducer  "./mr_merge_model"

[[ $? -ne 0 ]] && alarm && exit 1

exit 0;

