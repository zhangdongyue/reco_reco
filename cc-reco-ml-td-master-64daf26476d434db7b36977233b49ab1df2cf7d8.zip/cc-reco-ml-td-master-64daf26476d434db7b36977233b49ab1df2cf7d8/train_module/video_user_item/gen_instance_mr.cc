#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/proto/item.pb.h"
#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/common/io_util.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_string(job_name, "unknown","mr job name");
DEFINE_int32(min_instance_fea_num, 1, "minimun of feature num for a training instance");
DEFINE_int32(fea_sparse_threshold, 10, "sparse fea threshold");
DEFINE_double(min_profile_click_sum, -1, "");
DEFINE_double(max_profile_click_sum, 100000, "");
DEFINE_string(item_keeper_ips, "127.0.0.1", "");
DEFINE_int32(item_keeper_port, 20066, "");

struct InstanceInfo {
  uint64 reco_id;
  uint64 user_id;
  std::string app_name;
  uint64 item_id;
  std::string category;
  std::string tag;
  std::string lda_topic;
  int show_num;
  int click_num;
  std::vector<std::string> fea_literal;
  std::vector<std::string> reco_meta;
};

// 对离线 dump 的 user info 进行清洗和格式转换
void UserInfoMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 2u) {
      continue;
    }

    // filter by click sum
    std::string unescape;
    if (!base::LineUnescape(flds[1], &unescape)) continue;
    reco::user::UserInfo user_info;
    if (!user_info.ParseFromString(unescape)) continue;
    double click_sum = 0;
    if (!user_info.has_profile()) continue;
    reco::user::Profile profile = user_info.profile();
    if (!profile.has_category_feavec()) continue;
    const reco::CategoryFeatureVector& fea_vec = profile.category_feavec();
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      if (fea_vec.feature(i).literal().level() == 0) {
        click_sum += fea_vec.feature(i).confidence();
      }
    }
    if (click_sum >= FLAGS_min_profile_click_sum && click_sum < FLAGS_max_profile_click_sum) {
      std::cout << line << std::endl;
    }
  }
}

void UserInfoReduce() {
  std::string line;
  while (getline(std::cin, line)) {
    std::cout << line << std::endl;
  }
}

void MergeLogItemInfoMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 65u) {
      std::cerr << "reporter:counter:user,invalid_size,1" << std::endl;
      continue;
    }
    std::string app_name = flds[1];
    uint64 reco_id;
    if (!base::StringToUint64(flds[2], &reco_id)) {
      std::cerr << "reporter:counter:user,invalid_reco_id,1" << std::endl;
      continue;
    }
    uint64 item_id;
    if (!base::StringToUint64(flds[3], &item_id) || item_id == 0u) {
      std::cerr << "reporter:counter:user,invalid_item_id,1" << std::endl;
      continue;
    }
    int64 cid;
    if (!base::StringToInt64(flds[5], &cid)) {
      std::cerr << "reporter:counter:user,invalid_cid,1" << std::endl;
      continue;
    }
    int pos;
    if (!base::StringToInt(flds[6], &pos)) {
      std::cerr << "reporter:counter:user,invalid_pos,1" << std::endl;
      continue;
    }
    uint64 user_id;
    if (!base::StringToUint64(flds[9], &user_id)) {
      std::cerr << "reporter:counter:user,invalid_user_id,1" << std::endl;
      continue;
    }
    int click;
    if (!base::StringToInt(flds[10], &click)) {
      std::cerr << "reporter:counter:user,invalid_click,1" << std::endl;
      continue;
    }
    int refresh_type;
    if (!base::StringToInt(flds[45], &refresh_type)) {
      std::cerr << "reporter:counter:user,invalid_refresh_type,1" << std::endl;
      continue;
    }

    std::cout << base::StringPrintf("%lu\t%lu\t%ld\t%d\t%d\t%d\t%s\t%lu",
                  item_id, reco_id, cid, pos, refresh_type, click, app_name.c_str(), user_id)
              << std::endl;
  }
}

void MergeLogItemInfoReduce() {
  reco::BaseGetItem* get_item = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips, FLAGS_item_keeper_port);

  std::string line;
  std::vector<std::string> flds;
  uint64 current_item_id = 0;
  reco::RecoItem current_reco_item;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 8u) {
      std::cerr << "reporter:counter:user,invalid_reduce_input,1" << std::endl;
      continue;
    }
    uint64 item_id;
    if (!base::StringToUint64(flds[0], &item_id)) {
      std::cerr << "reporter:counter:user,failed_to_convert_item_id,1" << std::endl;
      continue;
    }
    if (item_id != current_item_id) {
      // get reco item from item keeper
      current_item_id = item_id;
      if (!get_item->GetRecoItem(item_id, &current_reco_item)) {
        std::cerr << "reporter:counter:user,failed_to_get_item_info,1" << std::endl;
        continue;
      }
    }
    std::vector<std::string> category;
    std::vector<std::string> tag;
    std::vector<std::string> lda_topic;
    int32 item_type = 0;
    if (current_reco_item.identity().item_id() == item_id) {
      // join item info
      for (int i = 0; i < current_reco_item.category_size(); ++i) {
        category.push_back(current_reco_item.category(i));
      }
      if (current_reco_item.has_tag()) {
        const reco::FeatureVector& fea_vec = current_reco_item.tag();
        for (int i = 0; i < fea_vec.feature_size(); ++i) {
          tag.push_back(fea_vec.feature(i).literal());
        }
      }
      if (current_reco_item.has_title_lda()) {
        const reco::FeatureVector& fea_vec = current_reco_item.title_lda();
        for (int i = 0; i < fea_vec.feature_size(); ++i) {
          lda_topic.push_back(fea_vec.feature(i).literal());
        }
      }
      item_type = current_reco_item.identity().type();
    }

    std::cout << line << "\t" << base::JoinStrings(category, ",")
        << "\t" << base::JoinStrings(tag, ",") << "\t" << base::JoinStrings(lda_topic, ",")
        << "\t" << item_type << std::endl;
  }

  delete get_item;
}

void MergeLogMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 12u) {
      std::cerr << "reporter:counter:user,invalid_size,1" << std::endl;
      continue;
    }
    uint64 item_id;
    if (!base::StringToUint64(flds[0], &item_id)) {
      std::cerr << "reporter:counter:user,invalid_item_id,1" << std::endl;
      continue;
    }
    uint64 reco_id;
    if (!base::StringToUint64(flds[1], &reco_id)) {
      std::cerr << "reporter:counter:user,invalid_reco_id,1" << std::endl;
      continue;
    }
    int64 cid;
    if (!base::StringToInt64(flds[2], &cid)) {
      std::cerr << "reporter:counter:user,invalid_cid,1" << std::endl;
      continue;
    }
    int pos;
    if (!base::StringToInt(flds[3], &pos)) {
      std::cerr << "reporter:counter:user,invalid_pos,1" << std::endl;
      continue;
    }
    int refresh_type;
    if (!base::StringToInt(flds[4], &refresh_type)) {
      std::cerr << "reporter:counter:user,invalid_refresh_type,1" << std::endl;
      continue;
    }
    int click;
    if (!base::StringToInt(flds[5], &click)) {
      std::cerr << "reporter:counter:user,invalid_click,1" << std::endl;
      continue;
    }
    std::string app_name = flds[6];
    uint64 user_id;
    if (!base::StringToUint64(flds[7], &user_id)) {
      std::cerr << "reporter:counter:user,invalid_user_id,1" << std::endl;
      continue;
    }
    std::string category = flds[8];
    std::string tag = flds[9];
    std::string lda_topic = flds[10];
    int item_type;
    if (!base::StringToInt(flds[11], &item_type)) {
      std::cerr << "reporter:counter:user,invalid_item_type,1" << std::endl;
      continue;
    }

    // filter
    if (item_type == 30) {
    } else {
      std::cerr << "reporter:counter:user,filter_by_item_type,1" << std::endl;
      continue;
    }

    if (app_name == "uc-iflow") {
    } else {
      std::cerr << "reporter:counter:user,filter_by_app_name,1" << std::endl;
      continue;
    }

    // 只取推荐频道主动刷新数据
    if (cid != 10016) {
      std::cerr << "reporter:counter:user,filter_by_cid,1" << std::endl;
      continue;
    }
    if (refresh_type == 2) {
      std::cerr << "reporter:counter:user,filter_by_refresh_type,1" << std::endl;
      continue;
    }
    if (reco_id == 0u || user_id == 0u || category.empty() || category == "未分类") {
      std::cerr << "reporter:counter:user,filter_by_other,1" << std::endl;
      continue;
    }

    std::cout << base::StringPrintf("%lu\t%ld\t%d\t%d\t%d\t%s\t%lu\t%lu\t%s\t%s\t%s",
                  reco_id, cid, pos, refresh_type, click, app_name.c_str(), user_id,
                  item_id, category.c_str(), tag.c_str(), lda_topic.c_str())
              << std::endl;
  }
}

void GenMergeLogReduceOutput(std::map<int, std::string>& merge_logs, std::set<int>& clicked_pos) {
  std::set<int> unclicked_pos;
  for (auto it = clicked_pos.begin(); it != clicked_pos.end(); ++it) {
    for (int idx = *it - 2; idx <= *it + 2; idx++) {
      if (idx >= 0 && clicked_pos.find(idx) == clicked_pos.end()) {
        unclicked_pos.insert(idx);
      }
    }
  }
  for (auto it = merge_logs.begin(); it != merge_logs.end(); ++it) {
    if (clicked_pos.find(it->first) != clicked_pos.end()) {
      // 正样本
      std::cout << it->second << "\t1" << std::endl;
    } else if (unclicked_pos.find(it->first) != unclicked_pos.end()) {
      // 负样本
      std::cout << it->second << "\t0" << std::endl;
    }
  }
}

void MergeLogReduce() {
  std::string current_key;
  std::set<int> clicked_pos; // 用户点击过的位置
  std::map<int, std::string> merge_logs; // pos - mergelog

  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 11u) {
      continue;
    }

    if (current_key != flds[0]) {
      GenMergeLogReduceOutput(merge_logs, clicked_pos);
      clicked_pos.clear();
      merge_logs.clear();
      current_key = flds[0];
    }

    int pos;
    if (!base::StringToInt(flds[2], &pos)) continue;
    int click;
    if (!base::StringToInt(flds[4], &click)) continue;
    merge_logs[pos] = line;
    if (click > 3) {
      clicked_pos.insert(pos);
    }
  }
  GenMergeLogReduceOutput(merge_logs, clicked_pos);
  clicked_pos.clear();
  merge_logs.clear();
}


void ExtractFeature(reco::ml::ThirdPartyDataItemFeatureExtractor* extractor,
                    const std::vector<reco::user::UserInfo>& user_info_vec,
                    const std::vector<InstanceInfo>& sample_vec,
                    std::vector<InstanceInfo>* ins_infos) {
  ins_infos->clear();

  std::vector<std::string> strs;
  std::vector<std::string> flds;
  for (size_t i = 0; i < user_info_vec.size(); ++i) {
    const reco::user::UserInfo& user = user_info_vec[i];
    extractor->ResetUser(user);
    for (size_t j = 0; j < sample_vec.size(); ++j) {
      reco::RecoItem item;
      const InstanceInfo& sample = sample_vec[j];
      item.mutable_identity()->set_item_id(sample.item_id);

      flds.clear();
      base::SplitString(sample.category, ",", &flds);
      for (size_t k = 0; k < flds.size(); ++k) {
        item.add_category(flds[k]);
      }

      flds.clear();
      base::SplitString(sample.tag, ",", &flds);
      reco::FeatureVector tag_fea_vec;
      tag_fea_vec.set_norm(1);
      for (size_t k = 0; k < flds.size(); ++k) {
        reco::Feature* tag_fea = tag_fea_vec.add_feature();
        tag_fea->set_literal(flds[k]);
        tag_fea->set_weight(1.0);
      }
      item.mutable_tag()->CopyFrom(tag_fea_vec);

      flds.clear();
      base::SplitString(sample.lda_topic, ",", &flds);
      reco::FeatureVector lda_topic_fea_vec;
      lda_topic_fea_vec.set_norm(1);
      for (size_t k = 0; k < flds.size(); ++k) {
        reco::Feature* topic_fea = lda_topic_fea_vec.add_feature();
        topic_fea->set_literal(flds[k]);
        topic_fea->set_weight(1.0);
      }
      item.mutable_title_lda()->CopyFrom(lda_topic_fea_vec);

      strs.clear();
      extractor->ExtractUserItemFeature(item, &strs);
      // 默认会添加一个 bias , 所以判断 fea num 需要加 1
      if ((int)strs.size() < FLAGS_min_instance_fea_num + 1) {
        continue;
      }

      ins_infos->push_back(sample);
      InstanceInfo& info = ins_infos->back();
      std::swap(info.fea_literal, strs);

      // meta
      strs.clear();
      strs.push_back(base::Uint64ToString(info.reco_id));
      strs.push_back(base::Uint64ToString(info.user_id));
      strs.push_back(base::Uint64ToString(info.item_id));
      strs.push_back(info.category);
      std::swap(info.reco_meta, strs);
    }
  }
}

// note: tag 中可能含有空格
void GenerateLiteralIns(std::vector<InstanceInfo>* ins_infos) {
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    const InstanceInfo& info = *it;
    // meta
    for (size_t i = 0; i < info.reco_meta.size(); ++i) {
      if (i > 0) {
        std::cout << "\t";
      }
      std::cout << info.reco_meta[i];
    }
    // show click
    std::cout << "\t" << info.show_num << "\t" << info.click_num;
    for (size_t i = 0; i < info.fea_literal.size(); ++i) {
      std::cout << "\t" << info.fea_literal[i];
    }
    std::cout << std::endl;
  }
}

void LiteralInstanceMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    // 根据长度判断 user info 和 merge log
    if (flds.size() == 12u) {
      // preprocessed merge log
      // uid ~ reco_id ~ itemid ~ category ~ tag ~ lda_topic ~ click
      std::cout << base::StringPrintf("%s\t%s\t%s\t%s\t%s\t%s\t%s", flds[6].c_str(),
                                      flds[0].c_str(), flds[7].c_str(), flds[8].c_str(),
                                      flds[9].c_str(), flds[10].c_str(), flds[11].c_str())
                << std::endl;
    } else if (flds.size() == 2u) {
      // preprocessed user info
      std::cout << base::StringPrintf("%s\t%s", flds[0].c_str(), flds[1].c_str()) << std::endl;
    }
  }
}

void LiteralInstanceReduce() {
  reco::ml::ThirdPartyDataItemFeatureExtractor* extractor = new reco::ml::ThirdPartyDataItemFeatureExtractor();
  extractor->SetupFeatureLayout();

  std::string line;
  std::string current_key;
  std::vector<std::string> flds;
  std::vector<reco::user::UserInfo> user_info_vec; // 用户信息
  std::vector<InstanceInfo> sample_vec; // 用户点击信息
  std::vector<InstanceInfo> ins_infos; // 训练样本
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds[0] != current_key) {
      if (!current_key.empty()) {
        // generate train instances
        ExtractFeature(extractor, user_info_vec, sample_vec, &ins_infos);
        GenerateLiteralIns(&ins_infos);
        //OutputInsInfos(&ins_infos);
      }
      current_key = flds[0];
      user_info_vec.clear();
      sample_vec.clear();
      ins_infos.clear();
    }

    if (flds.size() == 2u) {
      // user info
      //VLOG(1) << "input user info: " << line;
      std::string unescape;
      if (!base::LineUnescape(flds[1], &unescape)) {
        continue;
      }
      reco::user::UserInfo user_info;
      if (!user_info.ParseFromString(unescape)) {
        continue;
      }
      user_info_vec.push_back(user_info);
    } else if (flds.size() == 7u) {
      // merge log
      //VLOG(1) << "input merge log: " << line;
      InstanceInfo sample;
      if (!base::StringToUint64(flds[0], &sample.user_id)) continue;
      if (!base::StringToUint64(flds[1], &sample.reco_id)) continue;
      if (!base::StringToUint64(flds[2], &sample.item_id)) continue;
      sample.category = flds[3];
      sample.tag = flds[4];
      sample.lda_topic = flds[5];
      sample.show_num = 1;
      if (!base::StringToInt(flds[6], &sample.click_num)) continue;
      sample_vec.push_back(sample);
    }
  }
  if (!current_key.empty()) {
    // generate train instances
    ExtractFeature(extractor, user_info_vec, sample_vec, &ins_infos);
    GenerateLiteralIns(&ins_infos);
    //OutputInsInfos(&ins_infos);
  }
  user_info_vec.clear();
  sample_vec.clear();
  ins_infos.clear();

  delete extractor;
}

void FeaDictMap() {
  std::string line;
  std::vector<std::string> flds;
  std::map<std::string, int> fea_num;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 7u) {
      std::cerr << "reporter:counter:user,invalid_size,1" << std::endl;
      continue;
    }
    for (size_t i = 6; i < flds.size(); ++i) {
      fea_num[flds[i]] += 1;
    }
  }

  for (auto it = fea_num.begin(); it != fea_num.end(); ++it) {
    std::cout << it->first << "\t" << it->second << std::endl;
  }
}

void FeaDictReduce() {
  std::string current_key;
  std::string line;
  std::vector<std::string> flds;
  int num = 0;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 2u) {
      continue;
    }
    if (flds[0] != current_key) {
      if (!current_key.empty() && num >= FLAGS_fea_sparse_threshold) {
        uint64 sign = base::CityHash64(current_key.c_str(), current_key.size());
        std::cout << sign << "\t" << current_key << "\t" << num << std::endl;
      }
      current_key = flds[0];
      num = 0;
    }
    num += base::ParseIntOrDie(flds[1]);
  }

  if (!current_key.empty() && num >= FLAGS_fea_sparse_threshold) {
    uint64 sign = base::CityHash64(current_key.c_str(), current_key.size());
    std::cout << sign << "\t" << current_key << "\t" << num << std::endl;
  }
}

void TrainInstanceMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 7u) {
      std::cerr << "reporter:counter:user,invalid_size,1" << std::endl;
      continue;
    }
    std::cout << line << std::endl;
  }
}

void ReadFeaDict(std::string file_path, std::unordered_set<uint64>* dict) {
  std::ifstream ifs(file_path);
  std::string line;
  uint64 fea_id;
  while (getline(ifs, line)) {
    if (!base::StringToUint64(line, &fea_id)) continue;
    dict->insert(fea_id);
    // if (dict->size() % 10000 == 0) std::cout << "dict_size=" << dict->size() << std::endl;
  }
}

void TrainInstanceReduce() {
  // read fea dict
  std::unordered_set<uint64> fea_id_set;
  ReadFeaDict("fea_id_set.txt", &fea_id_set);

  std::string line;
  std::vector<std::string> flds;
  std::vector<uint64> fea_id_vec;
  std::set<uint64> dedup;
  while (getline(std::cin, line)) {
    flds.clear();
    fea_id_vec.clear();
    dedup.clear();

    // reco_id show click bias [feas]
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 7u) continue;
    uint64 bias_fea_id = base::CityHash64(flds[6].c_str(), flds[6].size());
    dedup.insert(bias_fea_id);
    fea_id_vec.push_back(bias_fea_id);

    uint64 fea_id;
    for (size_t i = 7; i < flds.size(); ++i) {
      fea_id = base::CityHash64(flds[i].c_str(), flds[i].size());
      if (fea_id_set.find(fea_id) == fea_id_set.end()) continue;
      if (dedup.find(fea_id) != dedup.end()) continue;
      dedup.insert(fea_id);
      fea_id_vec.push_back(fea_id);
    }

    // 剔除过滤后 fea num 过少的 train instance
    if ((int)fea_id_vec.size() >= 1 + FLAGS_min_instance_fea_num) {
      std::cout << flds[4] << " " << flds[5];
      for (size_t i = 0; i < fea_id_vec.size(); ++i) {
        std::cout << " " << fea_id_vec[i] << ":1";
      }
      std::cout << std::endl;
    }
  }
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "tp_item_lr_train_instance");

  if (FLAGS_job_name == "user_info_map") {
    UserInfoMap();
  } else if (FLAGS_job_name == "user_info_reduce") {
    UserInfoReduce();
  } else if (FLAGS_job_name == "merge_log_item_info_map") {
    MergeLogItemInfoMap();
  } else if (FLAGS_job_name == "merge_log_item_info_reduce") {
    MergeLogItemInfoReduce();
  } else if (FLAGS_job_name == "merge_log_map") {
    MergeLogMap();
  } else if (FLAGS_job_name == "merge_log_reduce") {
    MergeLogReduce();
  } else if (FLAGS_job_name == "literal_instance_map") {
    LiteralInstanceMap();
  } else if (FLAGS_job_name == "literal_instance_reduce") {
    LiteralInstanceReduce();
  } else if (FLAGS_job_name == "fea_dict_map") {
    FeaDictMap();
  } else if (FLAGS_job_name == "fea_dict_reduce") {
    FeaDictReduce();
  } else if (FLAGS_job_name == "train_instance_map") {
    TrainInstanceMap();
  } else if (FLAGS_job_name == "train_instance_reduce") {
    TrainInstanceReduce();
  } else {
    CHECK(false) << "invalid mr type: " << FLAGS_job_name;
  }
}
