#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/common/item_util.h"
#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/common/io_util.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_string(item_keeper_ips, "11.251.202.129", "item keeper");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");

DEFINE_string(item_id, "", "item id");
DEFINE_string(item_id_file, "", "item id file, one id per line");
DEFINE_string(item_dump_file, "", "dumped reco item file");

DEFINE_int32(thread_num, 4, "生成样本的处理线程");

DEFINE_string(train_ins_file, "train_ins", "用于最终训练的格式");
DEFINE_string(literal_ins_file, "literal_ins", "明文的训练文件，主要用于检查训练样本");
DEFINE_string(fea_id_file, "fea_id", "特征明文到特征 id 映射文件");
DEFINE_string(item_meta_file, "item_meta", "item meta 信息文件");

std::atomic<int> g_finished_threads(0);
thread::Mutex g_mutex;
std::unordered_set<uint64> g_title_dedup;
thread::Mutex g_dedup_mutex;

struct InstanceInfo {
  int64 show_num;
  int64 click_num;
  std::vector<std::string> item_meta;
  std::vector<std::string> fea_literal;
};

void ExtractFeature(thread::BlockingQueue<reco::RecoItem*>* item_queue,
                    std::vector<InstanceInfo>* ins_infos) {
  reco::ml::BaseFeatureExtractor* extractor = new reco::ml::NewsItemFeatureExtractor();

  std::vector<std::string> strs;
  extractor->SetupFeatureLayout();
  while (!item_queue->Empty()) {
    reco::RecoItem* pitem = item_queue->Take();
    if (pitem == NULL) continue;

    scoped_ptr<reco::RecoItem> p(pitem);

    const reco::RecoItem& item = *pitem;
    if (0 == item.quality_attr().posterior_itemq()) {
      continue;
    }
    uint64 title_sign = base::CityHash64(item.title().c_str(), item.title().size());
    {
      thread::AutoLock lock(&g_dedup_mutex);
      if (g_title_dedup.find(title_sign) != g_title_dedup.end()) {
        continue;
      } else {
        g_title_dedup.insert(title_sign);
      }
    }

    // feature
    strs.clear();
    extractor->ExtractItemFeature(item, &strs);
    if (strs.empty()) {
      continue;
    }
    ins_infos->push_back(InstanceInfo());
    InstanceInfo& info = ins_infos->back();
    std::swap(info.fea_literal, strs);

    // meta
    strs.clear();
    strs.push_back(base::Uint64ToString(item.identity().item_id()));
    strs.push_back(item.title());
    std::vector<std::string> category;
    reco::common::RepeatedToVector<std::string>(item.category(), &category);
    strs.push_back(base::JoinStrings(category, ","));
    strs.push_back(base::IntToString(item.quality_attr().posterior_itemq()));
    std::swap(info.item_meta, strs);

    // ins
    info.show_num = 100;
    info.click_num = item.quality_attr().posterior_itemq();
  }

  delete extractor;

  LOG(INFO) << "thread " << thread::GetThreadID() << " finished, gen instance: " << ins_infos->size();
  thread::AutoLock lock(&g_mutex);
  ++g_finished_threads;
}

void GenerateTrainInsFile(std::vector<std::vector<InstanceInfo> >* ins_infos) {
  std::ofstream out(FLAGS_train_ins_file.c_str());
  std::set<int64> dedup;
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      const InstanceInfo& info = *jt;
      out << info.show_num << " " << info.click_num;
      dedup.clear();
      for (size_t i = 0; i < info.fea_literal.size(); ++i) {
        uint64 sign = base::CityHash64(info.fea_literal[i].c_str(), info.fea_literal[i].size());
        if (dedup.find(sign) == dedup.end()) {
          dedup.insert(sign);
          out << " " << sign << ":1";
        }
      }
      out << std::endl;
    }
  }
  LOG(INFO) << "dump train ins thread ends";
}

void GenerateFeaIdFile(std::vector<std::vector<InstanceInfo> >* ins_infos) {
  std::ofstream out(FLAGS_fea_id_file.c_str());
  std::set<int64> dedup;
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      const InstanceInfo& info = *jt;
      for (size_t i = 0; i < info.fea_literal.size(); ++i) {
        uint64 sign = base::CityHash64(info.fea_literal[i].c_str(), info.fea_literal[i].size());
        if (dedup.find(sign) == dedup.end()) {
          dedup.insert(sign);
          out << info.fea_literal[i] << "\t" << sign << std::endl;
        }
      }
    }
  }
  out.close();
  LOG(INFO) << "dump fea id thread ends";
}

void GenerateLiteralInsFile(std::vector<std::vector<InstanceInfo> >* ins_infos) {
  std::ofstream out(FLAGS_literal_ins_file.c_str());
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      const InstanceInfo& info = *jt;
      out << info.show_num << " " << info.click_num;
      for (size_t i = 0; i < info.fea_literal.size(); ++i) {
        out << " " << info.fea_literal[i];
      }
      out << std::endl;
    }
  }
  out.close();
  LOG(INFO) << "dump literal ins thread ends";
}

void GenerateItemMetaFile(std::vector<std::vector<InstanceInfo> >* ins_infos) {
  std::ofstream out(FLAGS_item_meta_file.c_str());
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      const InstanceInfo& info = *jt;
      for (size_t i = 0; i < info.item_meta.size(); ++i) {
        if (i != 0) out << " ";
        out << info.item_meta[i];
      }
      out << std::endl;
    }
  }
  out.close();
  LOG(INFO) << "dump item meta thread ends";
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");

  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }

  thread::BlockingQueue<reco::RecoItem*> item_queue;
  thread::ThreadPool pool(FLAGS_thread_num);
  if (!FLAGS_item_dump_file.empty() && !item_id_list.empty()) {
    CHECK(false) << "item id or dump item file should chose just one";
  } else if (!FLAGS_item_dump_file.empty()) {
    reco::ml::LoadDumpProtoFile<reco::RecoItem>(FLAGS_item_dump_file, &item_queue);
  } else if (!item_id_list.empty()) {
    reco::ml::GetItemMultiThread(item_id_list, FLAGS_item_keeper_ips, FLAGS_item_keeper_port,
                                 FLAGS_thread_num, &item_queue);
  } else {
    CHECK(false) << "no input item";
  }

  item_queue.Close();
  // item meta, fea literal
  std::vector<std::vector<InstanceInfo> > ins_infos(FLAGS_thread_num);

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(ExtractFeature, &item_queue,
                               &(ins_infos[i])));
  }
  while (g_finished_threads != FLAGS_thread_num) {
    base::SleepForSeconds(5);
  }

  if (!FLAGS_train_ins_file.empty()) {
    pool.AddTask(::NewCallback(GenerateTrainInsFile, &ins_infos));
  }
  if (!FLAGS_literal_ins_file.empty()) {
    pool.AddTask(::NewCallback(GenerateLiteralInsFile, &ins_infos));
  }
  if (!FLAGS_fea_id_file.empty()) {
    pool.AddTask(::NewCallback(GenerateFeaIdFile, &ins_infos));
  }
  if (!FLAGS_item_meta_file.empty()) {
    pool.AddTask(::NewCallback(GenerateItemMetaFile, &ins_infos));
  }
  pool.JoinAll();
}
