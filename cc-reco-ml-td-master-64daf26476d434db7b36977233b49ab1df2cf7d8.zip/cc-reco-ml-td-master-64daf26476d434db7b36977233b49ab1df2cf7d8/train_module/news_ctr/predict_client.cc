#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/common/item_util.h"

#include "reco/ml/model/lr_model.h"
#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/feature/item/media.h"
#include "reco/ml/common/io_util.h"
#include "reco/ml/auc/auc.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"
#include "base/thread/thread_util.h"
#include "base/hash_function/city.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_string(item_keeper_ips, "11.251.202.129", "item keeper");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");

DEFINE_string(item_id, "", "");
DEFINE_string(item_id_file, "", "");
DEFINE_string(item_dump_file, "", "dumped reco item file");

DEFINE_int32(thread_num, 4, "生成样本的处理线程");

DEFINE_string(predict_result_file, "predict_result", "预测的结果");
DEFINE_string(model_file, "model", "模型文件");

std::atomic<int> g_finished_threads(0);
thread::Mutex g_mutex;

struct InstanceInfo {
  std::vector<std::string> item_meta;
  std::vector<std::string> fea_literal;
  std::vector<std::string> hit_features;
  double ctr;
  int show_num;
  int click_num;
};

void Predict(reco::ml::LRModel* model,
             thread::BlockingQueue<reco::RecoItem*>* item_queue,
             std::vector<InstanceInfo>* ins_infos) {
  reco::ml::BaseFeatureExtractor* extractor = new reco::ml::NewsItemFeatureExtractor();

  std::vector<std::string> strs;
  extractor->SetupFeatureLayout();
  while (!item_queue->Empty()) {
    reco::RecoItem* pitem = item_queue->Take();
    if (pitem == NULL) continue;

    scoped_ptr<reco::RecoItem> p(pitem);

    const reco::RecoItem& item = *pitem;

    // feature
    strs.clear();
    extractor->ExtractItemFeature(item, &strs);
    if (strs.empty()) {
      continue;
    }
    ins_infos->push_back(InstanceInfo());
    InstanceInfo& info = ins_infos->back();
    std::swap(info.fea_literal, strs);

    // meta
    strs.clear();
    strs.push_back(base::Uint64ToString(item.identity().item_id()));
    strs.push_back(item.title());
    // std::vector<std::string> category;
    // reco::common::RepeatedToVector<std::string>(item.category(), &category);
    // strs.push_back(base::JoinStrings(category, ","));
    strs.push_back(item.category_size() > 0 ? item.category(0) : "");
    std::string media;
    reco::ml::item_fea::Media::GetItemMedia(item, &media);
    strs.push_back(media);
    strs.push_back(base::IntToString(item.quality_attr().posterior_itemq()));
    std::swap(info.item_meta, strs);

    // ins
    double sum_w;
    int hits;
    model->Predict(info.fea_literal, &sum_w, &hits, &info.ctr, &info.hit_features);

    info.show_num = 100;
    info.click_num = item.quality_attr().posterior_itemq();
  }

  delete extractor;

  LOG(INFO) << "thread " << thread::GetThreadID() << " finished, gen instance: " << ins_infos->size();
  thread::AutoLock lock(&g_mutex);
  ++g_finished_threads;
}

void GeneratePredictResultFile(std::vector<std::vector<InstanceInfo> >* ins_infos) {
  std::ofstream out(FLAGS_predict_result_file.c_str());
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      const InstanceInfo& info = *jt;
      for (size_t i = 0; i < info.item_meta.size(); ++i) {
        if (i != 0) out << "\t";
        out << info.item_meta[i];
      }
      out << "\t" << static_cast<int>(100 * info.ctr);
      if (!info.hit_features.empty()) {
        out << "\t";
        for (size_t i = 0; i < info.hit_features.size(); ++i) {
          out << info.hit_features[i] << ",";
        }
      }
      out << std::endl;
    }
  }
  out.close();
  LOG(INFO) << "dump item meta thread ends";
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");

  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }

  thread::BlockingQueue<reco::RecoItem*> item_queue;
  thread::ThreadPool pool(FLAGS_thread_num);
  if (!FLAGS_item_dump_file.empty() && !item_id_list.empty()) {
    CHECK(false) << "item id or dump item file should chose just one";
  } else if (!FLAGS_item_dump_file.empty()) {
    reco::ml::LoadDumpProtoFile<reco::RecoItem>(FLAGS_item_dump_file, &item_queue);
  } else if (!item_id_list.empty()) {
    reco::ml::GetItemMultiThread(item_id_list, FLAGS_item_keeper_ips, FLAGS_item_keeper_port,
                                 FLAGS_thread_num, &item_queue);
  } else {
    CHECK(false) << "no input item";
  }

  item_queue.Close();

  reco::ml::LRModel* model = new reco::ml::DenseHashLRModel();
  model->LoadText(FLAGS_model_file);

  // item meta, fea literal
  std::vector<std::vector<InstanceInfo> > ins_infos(FLAGS_thread_num);

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(Predict,
                               model,
                               &item_queue,
                               &(ins_infos[i])));
  }
  while (g_finished_threads != FLAGS_thread_num) {
    base::SleepForSeconds(5);
  }

  if (!FLAGS_predict_result_file.empty()) {
    pool.AddTask(::NewCallback(GeneratePredictResultFile, &ins_infos));
  }
  pool.JoinAll();

  std::vector<reco::ml::PredCTR> pctrs;
  for (auto it = ins_infos.begin(); it != ins_infos.end(); ++it) {
    for (auto jt = it->begin(); jt != it->end(); ++jt) {
      if (jt->click_num == 0) continue;
      reco::ml::PredCTR pctr;
      pctr.query = jt->item_meta[2];
      pctr.pos_weight = jt->click_num;
      pctr.neg_weight = jt->show_num - jt->click_num;
      pctr.prediction = jt->ctr;
      pctrs.push_back(pctr);
    }
  }
  double auc, qauc, wqauc, iqauc;
  auc = reco::ml::CalcRocAuc(pctrs);
  reco::ml::CalcQueryAuc(pctrs, &qauc, &wqauc);
  iqauc = reco::ml::CalcInterQueryAuc(pctrs);
  double logloss = reco::ml::LogLoss(pctrs);
  LOG(INFO) << "Instance cnt=" << pctrs.size();
  LOG(INFO) << "Prior model auc=" << auc
            << ", qauc=" << qauc
            << ", wqauc=" << wqauc
            << ", iqauc=" << iqauc
            << ", logloss=" << logloss;

  delete model;
}
