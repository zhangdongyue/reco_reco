#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/proto/item.pb.h"
#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/common/io_util.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_string(job_name, "unknown","mr job name");

struct InstanceInfo {
  uint64 reco_id;
  uint64 user_id;
  int64 read_tm;
  int show_num;
  int click_num;
  std::string category;
  std::string app_name;
  std::vector<std::string> fea_literal;
  std::vector<std::string> reco_meta;
};

// 对画像稠密的老用户，取 profile 中权重大于等于阈值
// 或排名小于等于阈值的 category 作为正样本，剩余 category
// 作为负样本
void ExtractFeature(const reco::user::UserInfo& user_info,
                    std::vector<InstanceInfo>* ins_infos) {
  // 画像稀疏程度阈值
  const double kProfileSparseThre = 20;
  // 类目权重阈值
  const double kCategoryWeightThre = 5;
  // 类目排名阈值
  const int kCategoryRankThre = 3;
  // 一级类目列表(样本范围)
  const std::unordered_set<std::string> kDefaultCategories = {"科技", "体育", "健康", "军事",
     "历史", "国际", "奇闻", "娱乐", "干货", "房产", "收藏", "教育", "旅游", "时尚", "星座",
     "汽车", "游戏", "社会", "美食", "职场", "育儿", "财经", "两性情感", "国内"};
 
  ins_infos->clear();
  const reco::user::Profile& profile = user_info.profile();
  if (!profile.has_category_feavec()) return;
  const reco::CategoryFeatureVector& fea_vec = profile.category_feavec();

  // 获取一级类目，并统计画像稠密度
  std::unordered_set<std::string> positive_categories;
  std::unordered_set<std::string> negtive_categories;
  int rank = 0;
  double weight_sum = 0;
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const reco::CategoryFeature& fea = fea_vec.feature(i);
    if (fea.literal().level() != 0) continue;
    double weight = fea.weight();
    ++rank;
    weight_sum += weight;

    // 排名靠前或权重较大的 category 作为正样本
    if (kDefaultCategories.find(fea.literal().category()) != kDefaultCategories.end()
        && (rank <= kCategoryRankThre && weight >= kCategoryWeightThre)) {
      positive_categories.insert(fea.literal().category());
    }
  }
  if (weight_sum < kProfileSparseThre) return;

  // 获取负样本
  for (auto it = kDefaultCategories.begin(); it != kDefaultCategories.end(); ++it) {
    if (positive_categories.find(*it) == positive_categories.end()) {
      negtive_categories.insert(*it);
    }
  }

  // 生成训练样本
  reco::ml::ThirdPartyDataCategoryFeatureExtractor* extractor
      = new reco::ml::ThirdPartyDataCategoryFeatureExtractor();
  extractor->SetupFeatureLayout();
  extractor->ResetUser(user_info);

  for (auto it = positive_categories.begin(); it != positive_categories.end(); ++it) {
    std::vector<std::string> fea_strs;
    reco::RecoItem item;
    item.mutable_identity()->set_item_id(100);
    // 设置 category， 否则抽不到特征
    item.add_category(*it);
    extractor->ExtractUserItemFeature(item, &fea_strs);
    // 默认会添加一个 bias , 所以 size 小于等于 1 表示 fea 为空
    if (fea_strs.size() <= 1u) {
      continue;
    }
    
    InstanceInfo info;
    std::swap(info.fea_literal, fea_strs);
    info.show_num = 1;
    info.click_num = 1;
    ins_infos->push_back(info);
  }
  for (auto it = negtive_categories.begin(); it != negtive_categories.end(); ++it) {
    std::vector<std::string> fea_strs;
    reco::RecoItem item;
    item.mutable_identity()->set_item_id(100);
    // 设置 category， 否则抽不到特征
    item.add_category(*it);
    extractor->ExtractUserItemFeature(item, &fea_strs);
    // 默认会添加一个 bias , 所以 size 小于等于 1 表示 fea 为空
    if (fea_strs.size() <= 1u) {
      continue;
    }
    
    InstanceInfo info;
    std::swap(info.fea_literal, fea_strs);
    info.show_num = 1;
    info.click_num = 0;
    ins_infos->push_back(info);
  }

  delete extractor;
}

void GenerateTrainIns(std::vector<InstanceInfo>* ins_infos) {
  std::set<int64> dedup;
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    const InstanceInfo& info = *it;
    std::cout << "A\t" << info.show_num << " " << info.click_num;
    dedup.clear();
    for (size_t i = 0; i < info.fea_literal.size(); ++i) {
      uint64 sign = base::CityHash64(info.fea_literal[i].c_str(), info.fea_literal[i].size());
      if (dedup.find(sign) == dedup.end()) {
        dedup.insert(sign);
        std::cout << " " << sign << ":1";
      }
    }
    std::cout << std::endl;
  }
}

void GenerateLiteralIns(std::vector<InstanceInfo>* ins_infos) {
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    const InstanceInfo& info = *it;
    std::cout << "B\t" << info.show_num << " " << info.click_num;
    for (size_t i = 0; i < info.fea_literal.size(); ++i) {
      std::cout << " " << info.fea_literal[i];
    }
    std::cout << std::endl;
  }
}

void GenerateRecoMeta(std::vector<InstanceInfo>* ins_infos) {
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    const InstanceInfo& info = *it;
    std::cout << "D\t";
    for (size_t i = 0; i < info.reco_meta.size(); ++i) {
      if (i != 0) std::cout << " ";
      std::cout << info.reco_meta[i];
    }
    std::cout << std::endl;
  }
}

void GenerateFeaId(std::vector<InstanceInfo>* ins_infos) {
  std::map<std::string, int64> dedup;
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    const InstanceInfo& info = *it;
    for (size_t i = 0; i < info.fea_literal.size(); ++i) {
      dedup[info.fea_literal[i]] += 1;
    }
  }

  std::vector<std::pair<std::string, int64> > v;
  v.reserve(dedup.size());
  for (auto it = dedup.begin(); it != dedup.end(); ++it) {
    v.push_back(*it);
  }
  for (auto it = v.begin(); it != v.end(); ++it) {
    uint64 sign = base::CityHash64(it->first.c_str(), it->first.size());
    std::cout << "C\t" << it->first << "\t" << sign << "\t" << it->second << std::endl;
  }
}

void OutputInsInfos(std::vector<InstanceInfo>* ins_infos) {
  GenerateTrainIns(ins_infos);
  GenerateLiteralIns(ins_infos);
  GenerateFeaId(ins_infos);
  // GenerateRecoMeta(ins_infos);
}

// 统计一次 reco 中展示和点击过的 category
// 同一 category 展示多条 item, 只要一条被点击过就算该 category 被点击过
void GenUserCategorySamples(std::vector<InstanceInfo>& sample_vec) {
  std::map<std::string, int> cate_map;
  std::vector<std::string> flds;
  std::string app_name;
  uint64 user_id;
  uint64 reco_id;
  for (auto it = sample_vec.begin(); it != sample_vec.end(); ++it) {
    InstanceInfo info = *it;
    app_name = info.app_name;
    user_id = info.user_id;
    reco_id = info.reco_id;
    // exp: 只取一级类目
    flds.clear();
    base::SplitString(info.category, ",", &flds);
    if (!flds[0].empty()) {
      int click = info.read_tm > 3 ? 1 : 0;
      cate_map[flds[0]] += click;
    }
  }
  for (auto it = cate_map.begin(); it != cate_map.end(); ++it) {
    std::cout << base::StringPrintf("%lu\t%s\t%lu\t%s\t%d",
                                    user_id, app_name.c_str(), reco_id, it->first.c_str(), it->second)
        << std::endl;
  }
}

void InstanceMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 2u) continue;

    // parse user info
    std::string unescape;
    if (!base::LineUnescape(flds[1], &unescape)) continue;
    reco::user::UserInfo user_info;
    if (!user_info.ParseFromString(unescape)
        || !user_info.has_profile()) continue;
    const reco::user::Profile& profile = user_info.profile();
    if (!profile.has_category_feavec()) continue;

    // generate train instances
    std::vector<InstanceInfo> ins_infos; // 训练样本
    ExtractFeature(user_info, &ins_infos);
    OutputInsInfos(&ins_infos);
  }
}

void InstanceReduce() {
  std::string line;
  while (getline(std::cin, line)) {
    std::cout << line << std::endl;
  }
}

// 对离线 dump 的 user info 进行清洗和格式转换
void UserInfoMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 2u) {
      continue;
    }
    std::cout << line << std::endl;
  }
}

void UserInfoReduce() {
  std::string line;
  while (getline(std::cin, line)) {
    std::cout << line << std::endl;
  }
}

void MergeLogMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() < 18u) {
      continue;
    }
    std::string app_name = flds[1];
    uint64 reco_id = base::ParseUint64OrDie(flds[2]);
    int item_type = base::ParseIntOrDie(flds[4]);
    int64 cid = base::ParseInt64OrDie(flds[5]);
    uint64 user_id = base::ParseUint64OrDie(flds[9]);
    int click = base::ParseIntOrDie(flds[10]);
    std::string category = flds[17];

    if (item_type == 0 || item_type == 1 || item_type == 2 || item_type == 4) {
    } else {
      continue;
    }

    if (app_name == "uc-iflow" || app_name == "ucnews-iflow") {
    } else {
      continue;
    }

    // 只取推荐频道数据
    if (cid != 100 || reco_id == 0u || user_id == 0u
        || category.empty() || category == "未分类") {
      continue;
    }

    std::cout << base::StringPrintf("%lu\t%s\t%lu\t%s\t%d", reco_id, app_name.c_str(),
                                    user_id, category.c_str(), click) << std::endl;
  }
}

void MergeLogReduce() {
  std::string current_key;
  std::string line;
  std::vector<std::string> flds;
  std::vector<InstanceInfo> sample_vec;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 5u) {
      continue;
    }
    if (flds[0] != current_key) {
      if(!current_key.empty()) {
        GenUserCategorySamples(sample_vec);
      }
      current_key = flds[0];
      sample_vec.clear();
    }
    
    InstanceInfo info;
    info.reco_id = base::ParseUint64OrDie(flds[0]);
    info.app_name = flds[1];
    info.user_id = base::ParseUint64OrDie(flds[2]);
    info.category = flds[3];
    info.show_num = 1;
    info.read_tm = base::ParseIntOrDie(flds[4]);
    sample_vec.push_back(info);
  }

  if (!current_key.empty()) {
    GenUserCategorySamples(sample_vec);
    sample_vec.clear();
  }
}

void TrainInstanceMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds[0] != "A") {
      continue;
    }
    for (size_t i = 1; i < flds.size(); ++i) {
      if (i > 1) std::cout << "\t";
      std::cout << flds[i];
    }
    std::cout << std::endl;
  }
}

void TrainInstanceReduce() {
  std::string line;
  while (getline(std::cin, line)) {
    std::cout << line << std::endl;
  }
}

void LiteralInstanceMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds[0] != "B") {
      continue;
    }
    for (size_t i = 1; i < flds.size(); ++i) {
      if (i > 1) std::cout << "\t";
      std::cout << flds[i];
    }
    std::cout << std::endl;
  }
}

void LiteralInstanceReduce() {
  std::string line;
  while (getline(std::cin, line)) {
    std::cout << line << std::endl;
  }
}

void FeaIdMap() {
  std::string line;
  std::vector<std::string> flds;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds[0] != "C") {
      continue;
    }
    for (size_t i = 1; i < flds.size(); ++i) {
      if (i > 1) std::cout << "\t";
      std::cout << flds[i];
    }
    std::cout << std::endl;
  }
}

void FeaIdReduce() {
  std::string current_key;
  std::string line;
  std::vector<std::string> flds;
  int num = 0;
  while (getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    if (flds.size() != 3u) {
      continue;
    }
    if (flds[1] + "\t" + flds[0] != current_key) {
      if (!current_key.empty()) {
        std::cout << current_key << "\t" << num << std::endl;
      }
      current_key = flds[1] + "\t" + flds[0];
      num = 0;
    }
    num += base::ParseIntOrDie(flds[2]);
  }

  if (!current_key.empty()) {
    std::cout << current_key << "\t" << num << std::endl;
  }
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "user_category_lr_train_instance");
  if (FLAGS_job_name == "instance_map") {
    InstanceMap();
  } else if (FLAGS_job_name == "instance_reduce") {
    InstanceReduce();
  } else if (FLAGS_job_name == "user_info_map") {
    UserInfoMap();
  } else if (FLAGS_job_name == "user_info_reduce") {
    UserInfoReduce();
  } else if (FLAGS_job_name == "merge_log_map") {
    MergeLogMap();
  } else if (FLAGS_job_name == "merge_log_reduce") {
    MergeLogReduce();
  } else if (FLAGS_job_name == "train_instance_map") {
    TrainInstanceMap();
  } else if (FLAGS_job_name == "train_instance_reduce") {
    TrainInstanceReduce();
  } else if (FLAGS_job_name == "literal_instance_map") {
    LiteralInstanceMap();
  } else if (FLAGS_job_name == "literal_instance_reduce") {
    LiteralInstanceReduce();
  } else if (FLAGS_job_name == "fea_id_map") {
    FeaIdMap();
  } else if (FLAGS_job_name == "fea_id_reduce") {
    FeaIdReduce();
  } else {
    CHECK(false) << "invalid mr type: " << FLAGS_job_name;
  }
}
