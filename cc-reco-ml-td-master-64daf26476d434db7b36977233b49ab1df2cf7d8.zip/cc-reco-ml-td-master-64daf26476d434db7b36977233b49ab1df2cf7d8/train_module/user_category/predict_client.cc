#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/ml/model/lr_model.h"
#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/ml/common/io_util.h"
#include "reco/ml/auc/auc.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/file/file_util.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"
#include "base/thread/thread_util.h"
#include "base/hash_function/city.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_string(sample_file, "training_sample.txt", "sample file for generating instances");
DEFINE_bool(clear_show, true, "clear user shown history");
DEFINE_string(predict_result_file, "predict_result.txt", "预测的结果");
DEFINE_string(model_file, "tp_cate_lr_model.txt", "模型文件");
DEFINE_int32(min_feature_hits, 2, "min feature hits to trust the predict result");

std::atomic<int> g_finished_threads(0);
thread::Mutex g_mutex;

struct InstanceInfo {
  int show_num;
  int click_num;
  double ctr;
  std::vector<std::string> fea_literal;
  std::vector<std::string> reco_meta;
  std::vector<std::string> hit_features;

  std::string ToString() {
    std::stringstream ss;
    ss << "show=" << show_num << ", click=" << click_num << ", ctr=" << ctr;
    ss << ", fea_literal=" << base::JoinStrings(fea_literal, ",");
    ss << ", meta=" << base::JoinStrings(reco_meta, ",");
    ss << ", hit_fea=" << base::JoinStrings(hit_features, ",");
    return ss.str();
  };
};

void LoadSampleFile(std::vector<InstanceInfo>* sample_dict) {
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_sample_file, &lines);
  std::vector<std::string> flds;
  std::vector<std::string> subs;
  for (size_t i = 0; i < lines.size(); ++i) {
    flds.clear();
    // show click [literal_fea]
    base::SplitString(lines[i], "\t", &flds);
    subs.clear();
    base::SplitString(flds[0], " ", &subs);
    if (subs.size() < 3u) continue;
    InstanceInfo info;
    info.show_num = base::ParseIntOrDie(subs[0]);
    info.click_num = base::ParseIntOrDie(subs[1]);
    for (size_t j = 2; j < subs.size(); ++j) {
      info.fea_literal.push_back(subs[j]);
    }
    
    sample_dict->push_back(info);
  }
  LOG(INFO) << "lines of sample read: " << sample_dict->size();
}

void Predict(reco::ml::LRModel* model,
             std::vector<InstanceInfo>* sample_dict,
             std::vector<InstanceInfo>* ins_infos) {
  for (size_t i = 0; i < sample_dict->size(); ++i) {
    ins_infos->push_back(sample_dict->at(i));
    InstanceInfo& info = ins_infos->back();
 
    // ins
    double sum_w;
    int hits;
    model->Predict(info.fea_literal, &sum_w, &hits, &info.ctr, &info.hit_features);
    VLOG(1) << info.ToString();
    if (hits < FLAGS_min_feature_hits) {
      ins_infos->pop_back();
      continue;
    }
  }
}

void GeneratePredictResultFile(std::vector<InstanceInfo>* ins_infos) {
  std::ofstream out(FLAGS_predict_result_file.c_str());
  for (auto it = ins_infos->begin(); it != ins_infos->end(); ++it) {
    const InstanceInfo& info = *it;
    for (size_t i = 0; i < info.reco_meta.size(); ++i) {
      if (i != 0) out << "\t";
      out << info.reco_meta[i];
    }
    out << "\t" << static_cast<int>(10000 * info.ctr) / 10000.0;
    if (!info.hit_features.empty()) {
      out << "\t";
      for (size_t i = 0; i < info.hit_features.size(); ++i) {
        out << info.hit_features[i] << ",";
      }
    }
    out << std::endl;
  }
  out.close();
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "user category lr predict");

  std::vector<InstanceInfo> sample_dict;
  LoadSampleFile(&sample_dict);

  // meta, fea literal
  std::vector<InstanceInfo> ins_infos;

  reco::ml::LRModel* model = new reco::ml::DenseHashLRModel();
  model->LoadText(FLAGS_model_file);
  Predict(model, &sample_dict, &ins_infos);

  if (!FLAGS_predict_result_file.empty()) {
    GeneratePredictResultFile(&ins_infos);
  }

  std::vector<reco::ml::PredCTR> pctrs;
  for (auto it = ins_infos.begin(); it != ins_infos.end(); ++it) {
    // if (it->click_num == 0) continue;
    reco::ml::PredCTR pctr;
    pctr.query = base::JoinStrings(it->fea_literal, ",");
    pctr.pos_weight = it->click_num;
    pctr.neg_weight = it->show_num - it->click_num;
    pctr.prediction = it->ctr;
    pctrs.push_back(pctr);
  }
  double auc, qauc, wqauc, iqauc;
  auc = reco::ml::CalcRocAuc(pctrs);
  reco::ml::CalcQueryAuc(pctrs, &qauc, &wqauc);
  iqauc = reco::ml::CalcInterQueryAuc(pctrs);
  double logloss = reco::ml::LogLoss(pctrs);
  LOG(INFO) << "Instance cnt=" << pctrs.size();
  LOG(INFO) << "Prior model auc=" << auc
            << ", qauc=" << qauc
            << ", wqauc=" << wqauc
            << ", iqauc=" << iqauc
            << ", logloss=" << logloss;

  delete model;
}
