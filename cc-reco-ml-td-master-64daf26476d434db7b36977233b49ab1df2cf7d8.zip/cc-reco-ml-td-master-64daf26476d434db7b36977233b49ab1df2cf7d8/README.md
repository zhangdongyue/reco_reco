1. 仓库定位和主要模块介绍
==========================================

本仓库用于维护机器学习相关的训练模块，包括样本准备，离线特征抽取，训练程序等
如果是在线服务需要的特征抽取 lib 库，可以放到 serv 里

目前已有模块如下
├── auc
    评估 auc 有关的 lib
├── common
    为模型所写的公共函数。目前有通用的 item 数据 IO 方法
├── feature
    所有的特征抽取类都放在这里
    base        提供特征的基类
    item        item 相关单边特征抽取的派生类
    user        user 相关单边特征抽取的派生类
    extractor   基于单边特征类，抽取组合特征
├── model
    推荐场景所有用到的模型类，提供了模型的输入输出方法和预估方法
├── train_module
    模型训练的样本准备、特征抽取、预估等各种串流程程序。注意这个目录应该只放二进制文件，
    任何涉及特征和模型的修改，都药放到 X_featurea 和 model 目录中，以做到最大化的复用
    这个目录下的子目录对应的训练任务是
    news_q   图文的质量度模型
    news_ctr 图文的 ctr 预估模型
├── item_predict_daemon
    线上模块，监控 item 队列对 item 的某个属性，调用预估程序，结果写入线上存储
|-- model_server 
    所有 model 的预测服务，包括加载，olm的更新逻辑

TODO: 
1. factorization_machine  matrix_factorization  整理后放入 train_module
2. video 预估线下部分放入 train_module, 线上部分在 item_predict_daemon 里加代码

2. 仓库本地配置
==========================================

首先需要 git clone git@gitlab.alibaba-inc.com:sm-xss/cc-pub.git
cc-pub 仓库提供了编译环境和基础库。请认真阅读 cc-pub 的 README

git clone git@gitlab.alibaba-inc.com:sm-xss/cc-reco-ml.git
会得到 cc-reco-ml 目录

在 cc-pub 下面新建一个 reco 文件夹 （reco 目录会被 cc-pub 这个仓库忽略）
然后通过符号链接或者 mv 的方式，把 cc-reco-ml 仓库放到 reco 子目录下
最终目录结构如下

cc-pub
 ├──reco
     ├──ml  -> cc-reco-ml
