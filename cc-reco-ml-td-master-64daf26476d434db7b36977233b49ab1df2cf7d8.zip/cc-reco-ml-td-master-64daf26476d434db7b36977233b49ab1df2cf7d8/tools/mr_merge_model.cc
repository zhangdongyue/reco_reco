#include <cstdatomic>
#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <sstream>

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/file/file_util.h"
#include "base/hash_function/city.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "mr_merge_model");

  std::string last_key;
  std::vector<std::string> flds;
  std::string line;
  std::string weight, literal, cnt;
  while (std::getline(std::cin, line)) {
    base::TrimTrailingWhitespaces(&line);
    flds.clear();
    base::SplitString(line, "\t", &flds);
    const std::string& key = flds[0];
    if (key != last_key) {
      if (!weight.empty() && !literal.empty() && !cnt.empty()) {
        std::cout << literal << "\t" << last_key << "\t" << weight << std::endl;
      }
      weight.clear();
      literal.clear();
      cnt.clear();
    }
    last_key = key;
    if (flds.size() == 2u) {  // model
      weight = flds[1];
    } else if (flds.size() == 3u) {  // feaset
      literal = flds[1];
      cnt = flds[2];
    }
  }
  if (!weight.empty() && !literal.empty() && !cnt.empty()) {
    std::cout << literal << "\t" << last_key << "\t" << weight << std::endl;
  }
  return 0;
}
