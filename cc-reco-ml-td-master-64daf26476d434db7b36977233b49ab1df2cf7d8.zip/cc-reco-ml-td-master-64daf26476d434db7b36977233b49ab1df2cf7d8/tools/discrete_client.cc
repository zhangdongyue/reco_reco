#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "base/math/discrete.h"

#include "base/common/gflags.h"
#include "base/common/base.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_int32(method, 1, "0:equal range; 1:equal freq; 2:powlow");
DEFINE_int32(bucket_num, 3, "bucket num");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");

  std::string line;
  std::vector<double> values;
  while (std::getline(std::cin, line)) {
    double value = base::ParseDoubleOrDie(line);
    values.push_back(value);
  }

  std::vector<double> boundaries;
  std::map<double, int64> stat;
  std::vector<std::pair<double, int64>> sampled_values;
  std::vector<int64> counts_per_bin;
  for (size_t i = 0; i < values.size(); ++i) {
    stat[values[i]]++;
  }
  for (auto it = stat.begin(); it != stat.end(); ++it) {
    sampled_values.push_back(std::make_pair(it->first, it->second));
  }
  switch (FLAGS_method) {
    case 0:
      CHECK(base::math::EqualRangePartition(values, FLAGS_bucket_num, &boundaries));
      break;
    case 1:
      CHECK(base::math::EqualFreqPartition(sampled_values, FLAGS_bucket_num, &boundaries, &counts_per_bin));
      break;
    case 2:
      base::math::PowLawPartition(sampled_values, FLAGS_bucket_num, &boundaries);
      break;
    default:
      CHECK(false) << FLAGS_method << " method unknown";
  }

  for (size_t i = 0; i < boundaries.size(); ++i) {
    std::cout << boundaries[i] << std::endl;
  }
  return 0;
}
