#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/proto/item.pb.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "base/thread/thread_pool.h"
#include "base/encoding/line_escape.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_int32(thread_num, 10, "get item thread num");

DEFINE_string(item_keeper_ips, "11.251.202.129", "item keeper");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");

DEFINE_string(result_file, "result.txt", "line escaped item dump");

void GetItem(thread::BlockingQueue<std::pair<uint64, std::string> >* item_id_queue, thread::BlockingQueue<std::string>* result_queue,
             thread::BlockingVar<int>* finish_num) {
  reco::ItemKeeperGetItem get_item(FLAGS_item_keeper_ips, FLAGS_item_keeper_port);
  std::pair<uint64, std::string> ele;
  reco::RecoItem reco_item;
  while (not (item_id_queue->Closed() && item_id_queue->Empty())) {
    if (not item_id_queue->Take(&ele)) break;
    get_item.GetRecoItem(ele.first, &reco_item);
    result_queue->Put(base::StringPrintf("%lu\t%s\t%s", ele.first, reco_item.category(0).c_str(), ele.second.c_str()));
  }
  
  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    result_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

void DumpItem(thread::BlockingQueue<std::string>* result_queue) {
  std::ofstream fout(FLAGS_result_file);
  std::string buf;
  while (not (result_queue->Closed() && result_queue->Empty())) {
    result_queue->Take(&buf);
    fout << buf << "\n";
  }
  fout.close();
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "dump item");
  thread::BlockingQueue<std::string> result_queue;
  thread::BlockingQueue<std::pair<uint64, std::string> > item_id_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  thread::ThreadPool pool(FLAGS_thread_num + 1);
  pool.AddTask(::NewCallback(&DumpItem, &result_queue));
  for (int i = 0; i < FLAGS_thread_num + 1; ++i) {
    pool.AddTask(::NewCallback(GetItem, &item_id_queue, &result_queue, &finish_num));
  }
  
  std::string line;
  std::vector<std::string> tokens;
  while (std::getline(std::cin, line)) {
    tokens.clear();
    base::SplitString(line, "\t ", &tokens);
    uint64 item_id = 0;
    if (!base::StringToUint64(tokens[0], &item_id)) {
      LOG(ERROR) << "skip " << line;
      continue;
    }
    item_id_queue.Put(std::make_pair(item_id, tokens.back()));
  }
  item_id_queue.Close();
  pool.JoinAll();
}
