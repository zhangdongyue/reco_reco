#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/ml/common/io_util.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/encoding/line_escape.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_int32(thread_num, 10, "get item thread num");

DEFINE_string(item_keeper_ips, "11.251.202.129", "item keeper");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");

DEFINE_string(item_id, "", "");
DEFINE_string(item_id_file, "", "");

DEFINE_string(item_dump_file, "reco_item.dump", "line escaped item dump");
DEFINE_int32(batch_size, 100, "");

std::atomic<int> g_running_threads(0);
thread::Mutex g_mutex;

void GetItem(std::vector<std::string>* item_ids, thread::BlockingQueue<reco::RecoItem>* queue) {
  {
    thread::AutoLock lock(&g_mutex);
    ++g_running_threads;
  }

  reco::BaseGetItem* get_item = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips, FLAGS_item_keeper_port);
  std::vector<reco::RecoItem> reco_items;
  get_item->GetRecoItems(*item_ids, &reco_items);
  // LOG(INFO) << "get " << reco_items.size() << " from " << item_ids->size() << " ids";
  for (size_t i = 0; i < reco_items.size(); ++i) {
    reco_items[i].clear_raw_item();
    // const reco::RecoItem& item = reco_items[i];
    // if (0 == item.quality_attr().posterior_itemq()) {
    //   continue;
    // }
    queue->Put(reco_items[i]);
  }

  delete get_item;
  delete item_ids;
  {
    thread::AutoLock lock(&g_mutex);
    --g_running_threads;
  }
}

void DumpItem(thread::BlockingQueue<reco::RecoItem>* queue) {
  {
    thread::AutoLock lock(&g_mutex);
    ++g_running_threads;
  }

  std::ofstream out(FLAGS_item_dump_file.c_str());
  int64 item_cnt = 0;
  while (true) {
    reco::RecoItem item;
    if (!queue->TimedTake(10, &item)) {
      if (g_running_threads == 1) {
        break;
      }
      continue;
    }
    std::string escape_str;
    reco::ml::SerializeLineEscapeItem(item, &escape_str);
    out << escape_str << std::endl;
    ++item_cnt;
  }
  out.close();

  {
    thread::AutoLock lock(&g_mutex);
    --g_running_threads;
  }
  LOG(INFO) << "total " << item_cnt << " items dumped";
}

DEFINE_string(em21_redis_ips, "", "em21 redis ips");
DEFINE_string(su18_redis_ips, "", "su18 redis ips");
DEFINE_int32(redis_poolsize, 32, "redis pool size");
DEFINE_int32(redis_timeout, 500, "in ms");

void MetaInfoUpdator::ParseMeta(uint64 item_id,
                                const std::unordered_map<std::string, std::string>& field_values,
                                MetaInfo* meta) {
  int value = 0;
  auto iter = field_values.find(reco::item_level::kTimeLevelField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->time_level = reco::TimeLevel(value);
    }
  }

  iter = field_values.find(reco::item_level::kSiteLevelField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->site_level = reco::SiteLevel(value);
    }
  }

  iter = field_values.find(reco::item_level::kHotLevelField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      value = std::min(reco::item_level::kManualHotScoreThres, value);
      meta->hot_level = value;
    }
  }

  iter = field_values.find(reco::item_level::kPRScoreField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->pr_level = value;
    }
  }

  iter = field_values.find(reco::item_level::kStatItemqField);
  if (iter != field_values.end()
      && base::StringToInt(iter->second, &value)
      && reco::kBadItemq <= value
      && value < reco::kBoundaryItemq) {
    meta->item_quality = value;
  } else {
    meta->item_quality = reco::kNormalItemq;
  }
  ItemQualityAttr quality_attr;
  if (meta->item_quality < reco::kJingpinItemq
      && news_index_->GetItemQualityAttrByItemId(item_id, &quality_attr)) {
    if (quality_attr.manual_jingpin_level() > 0) {
      meta->item_quality = reco::kJingpinItemq;
    }
  }

  iter = field_values.find(reco::item_level::kSensitiveTypeField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->sensitive_type = reco::SensitiveType(value);
    }
  }

  // iter = field_values.find(reco::item_level::kShowCountField);
  iter = field_values.find(reco::item_level::kShowField);
  if (iter != field_values.end()) {
    if (!base::StringToUint64(iter->second, &meta->show_count)) {
      meta->show_count = 0;
    }
  }

  // iter = field_values.find(reco::item_level::kClickCountField);
  iter = field_values.find(reco::item_level::kClickField);
  if (iter != field_values.end()) {
    if (!base::StringToUint64(iter->second, &meta->click_count)) {
      meta->click_count = 0;
    }
  }

  // iter = field_values.find(reco::item_level::kClickCountField);
  iter = field_values.find("new_pr");
  if (iter != field_values.end()) {
    int32 new_pr_orgi_score = 0;
    if (!base::StringToInt(iter->second, &new_pr_orgi_score) || new_pr_orgi_score <= 0) {
      meta->new_pr = 0;
    } else {
      ItemInfo item_info;
      if (!news_index_->GetItemInfoByItemId(item_id, &item_info, false)) {
        meta->new_pr = 0;
      } else {
        // 统计 media_quality  2 和 3 的媒体数量
        const std::string super_level_key = item_info.category + "-3";
        const std::string good_level_key = item_info.category + "-2";
        int32 super_level_num = news_index_->GetCateMediaLevelNum(super_level_key);
        int32 good_level_num = news_index_->GetCateMediaLevelNum(good_level_key);
        int32 base_score = super_level_num * 3 + good_level_num * 1;
        int64 tm = base::GetTimestamp();
        if (base_score <= 20
            || tm - item_info.create_timestamp > base::Time::kMicrosecondsPerDay) {
          meta->new_pr = 0;
        } else {
          float new_pr_score = static_cast<float>(new_pr_orgi_score) / static_cast<float>(base_score);
          meta->new_pr = std::min(100, static_cast<int>(new_pr_score * 100));
        }
      }
    }
  }

  iter = field_values.find(reco::item_level::kSpiderScoreField);
  if (iter != field_values.end()) {
    double spider_score = 0;
    base::StringToDouble(iter->second, &spider_score);
    meta->spider_score = (float)spider_score;
  } else {
    int spider_comment = 0;
    iter = field_values.find(reco::item_level::kSpiderCommentCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_comment);
    }
    int spider_up = 0;
    iter = field_values.find(reco::item_level::kSpiderUpCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_up);
    }
    int spider_down = 0;
    iter = field_values.find(reco::item_level::kSpiderDownCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_down);
    }
    int spider_read_count = 0;
    iter = field_values.find(reco::item_level::kSpiderReadCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_read_count);
    }
    meta->spider_score = static_cast<float>(spider_comment) * 2 + static_cast<float>(spider_up) * 1.5
        + static_cast<float>(spider_down) * 0.5 + static_cast<float>(spider_read_count);
  }

  // add by wangye
  iter = field_values.find(reco::item_level::kCtrqField);
  if (iter != field_values.end()) {
    double p_ctr = 0.0;
    if (base::StringToDouble(iter->second, &p_ctr)) {
      meta->p_ctr = p_ctr;
    } else {
      meta->p_ctr = 0.0;
    }
  }
}

void MetaInfoUpdator::GetMeta(const uint64 item_id,
                              std::unordered_map<uint64, MetaInfo>* item_metas,
                              int64* err_num,
                              int64* not_exist_num) {
  std::string key;
  base::StringAppendF(&key, "%s%lu", reco::item_level::kItemRedisKeyPrefix, item_id);

  std::unordered_map<std::string, std::string> field_values;
  if (!redis_->HGetAll(key, &field_values)) {
    thread::AutoLock lock(&update_meta_mutex_);
    ++(*err_num);
    return;
  }

  if (field_values.empty()) {
    thread::AutoLock lock(&update_meta_mutex_);
    ++(*not_exist_num);
    return;
  }

  thread::AutoLock lock(&update_meta_mutex_);
  auto iter = item_metas->insert(std::make_pair(item_id, MetaInfo()));
  ParseMeta(item_id, field_values, &(iter.first->second));
  return;
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");

  if (FLAGS_em21_redis_ips.empty()) {
    redis_em21_ = new reco::redis::RedisCli(FLAGS_em21_redis_ips, FLAGS_redis_poolsize, FLAGS_redis_timeout);
  } else {
    redis_em21_ = NULL;
  }

  std::vector<std::string> item_id_list;
  if (!FLAGS_item_id.empty()) {
    item_id_list.push_back(FLAGS_item_id);
  }
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &item_id_list);
  }

  thread::ThreadPool pool(FLAGS_thread_num);
  thread::BlockingQueue<reco::RecoItem> item_queue;
  pool.AddTask(::NewCallback(DumpItem, &item_queue));
  // item meta, fea literal
  for (size_t i = 0; i < item_id_list.size(); i += FLAGS_batch_size) {
    size_t end = std::min(i + FLAGS_batch_size, item_id_list.size());
    // LOG(INFO) << i << "," << end;
    std::vector<std::string> *subs =
        new std::vector<std::string>(item_id_list.begin() + i, item_id_list.begin() + end);
    // for (auto it = subs->begin(); it != subs->end(); ++it) {
    //   LOG(INFO) << "item: " << *it;
    // }
    pool.AddTask(::NewCallback(GetItem, subs, &item_queue));
  }
    get_meta_thread_pool.AddTask(NewCallback(this, &MetaInfoUpdator::GetMeta,
                                             item_id, dict, &err_num, &not_exist_num));

  pool.JoinAll();
  if (redis_) {
    delete redis_;
    redis_ = NULL;
  }
}
