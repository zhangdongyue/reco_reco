#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "reco/bizc/proto/item.pb.h"

#include "base/common/gflags.h"
#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/file/file_util.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/encoding/line_escape.h"

#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

DEFINE_int32(thread_num, 1, "get item thread num");

DEFINE_string(user_server_machine_list, "../config/user_server_machine.yaml.em21", "user server");
DEFINE_string(user_profile_machine_list, "../config/user_profile_machine.yaml.em21", "user profile server");

DEFINE_string(user_file, "", "user id file, one id per line");
DEFINE_string(user_dump_file, "", "dumped reco user file");

DEFINE_bool(clear_show, true, "clear user shown history");

void GetUser(thread::BlockingQueue<reco::UserInfo*>* queue) {
  reco::ml::GetUserMultiThread(FLAGS_user_file,
                               FLAGS_user_server_machine_list,
                               FLAGS_user_profile_machine_list,
                               FLAGS_thread_num,
                               FLAGS_clear_show,
                               queue);
  queue->Close();
}

void DumpUser(thread::BlockingQueue<reco::UserInfo*>* queue) {
  reco::ml::DumpProtoFile<reco::UserInfo>(FLAGS_user_dump_file, queue);
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "dump user");

  thread::BlockingQueue<reco::UserInfo*> user_queue;
  thread::ThreadPool pool(2);
  pool.AddTask(::NewCallback(DumpUser, &user_queue));
  pool.AddTask(::NewCallback(GetUser, &user_queue));
  pool.JoinAll();
}
