#include <string>
#include <vector>
#include <fstream>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"

#include "reco/ml/model/lr_model.h"

DEFINE_string(output, "model.bin", "");
DEFINE_string(input, "model.literal", "");

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "");
  reco::ml::DenseHashLRModel lr_model;
  lr_model.LoadText(base::FilePath(FLAGS_input));
  lr_model.SaveBin(base::FilePath(FLAGS_output));
  return 0;
}
