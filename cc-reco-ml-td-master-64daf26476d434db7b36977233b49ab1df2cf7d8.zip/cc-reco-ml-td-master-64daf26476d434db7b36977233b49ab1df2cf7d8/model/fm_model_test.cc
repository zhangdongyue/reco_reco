#include <string>
#include <limits>
#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/file/file_util.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

#include "reco/ml/model/fm_model.h"
#include "reco/base/math/math.h"

namespace reco {
namespace ml {
DEFINE_string(model_config, "../config/model/fm/text_fm_config", "running in model server data dir");
DEFINE_string(test_case, "fm_inc_test", "test case for fm inc");

class FMModelTest : public ::testing::Test {
 protected:
  base::FilePath WriteLinesToTempFile(const std::vector<std::string>& lines) {
    base::FilePath path;
    CHECK(base::file_util::CreateTemporaryFileInDir("/tmp", &path));
    std::string str = base::JoinStrings(lines, "\n");
    CHECK(base::file_util::WriteFile(path, str.c_str(), str.size()));

    return path;
  }

  virtual void SetUp() {
    std::vector<std::string> lines;

    // create pure key cases
    lines.push_back("1\t0.5\t0.3\t0.4");
    lines.push_back("2\t1\t0.6\t0.8");
    dense_hash_file_ = WriteLinesToTempFile(lines);
    dense_hash_bin_file_ = base::FilePath(dense_hash_file_.value() + ".bin");
  }

  virtual void TearDown() {
    CHECK(base::file_util::Delete(dense_hash_file_, false));
    CHECK(base::file_util::Delete(dense_hash_bin_file_, false));
  }

  base::FilePath dense_hash_file_;
  base::FilePath dense_hash_bin_file_;
};

TEST_F(FMModelTest, TestPredict) {
  double ctr = 0;
  FMModel* model = new FMModel();
  ASSERT_TRUE(model->Load(dense_hash_file_.value()));

  std::vector<uint64> feas;
  feas.push_back(1);
  model->Predict(feas, &ctr);
  ASSERT_FLOAT_EQ(reco::logit(0.5), ctr);

  feas.push_back(2);
  model->Predict(feas, &ctr);
  ASSERT_FLOAT_EQ(reco::logit(2), ctr);

  delete model;

  model = new UserItemFMModel();
  ASSERT_TRUE(model->Load(dense_hash_file_.value()));
  std::vector<uint64> user_fea;
  user_fea.push_back(1);
  std::vector<uint64> item_fea;
  item_fea.push_back(2);

  FacMachineScore user_score;
  dynamic_cast<UserItemFMModel*>(model)->CalcPartScore(user_fea, &user_score);
  dynamic_cast<UserItemFMModel*>(model)->Predict(user_score, 1u, item_fea, &ctr);
  ASSERT_FLOAT_EQ(reco::logit(2), ctr);
  // test cache
  dynamic_cast<UserItemFMModel*>(model)->Predict(user_score, 1u, item_fea, &ctr);
  ASSERT_FLOAT_EQ(reco::logit(2), ctr);
}

TEST_F(FMModelTest, TestReadCase) {
  double ctr = 0;
  UserItemFMModel* model = new UserItemFMModel();
  ASSERT_TRUE(model->Initialize(FLAGS_model_config));

  // read cases
  std::ifstream fin(FLAGS_test_case);
  std::string line;
  std::vector<std::string> tokens;
  std::vector<uint64> feas;
  std::vector<uint64> user_feas;
  std::vector<uint64> item_feas;
  while (std::getline(fin, line)) {
    tokens.clear();
    base::SplitString(line, " ", &tokens);
    double real_score = reco::logit(base::ParseDoubleOrDie(tokens[0]));
    feas.clear();
    for (int i = 1; i < (int)tokens.size(); ++i) {
      size_t pos = tokens[i].find(":");
      uint64 sign = base::ParseUint64OrDie(tokens[i].substr(0, pos));
      feas.push_back(sign);
    }

    model->FMModel::Predict(feas, &ctr);
    ASSERT_FLOAT_EQ(real_score, ctr);

    if (feas.size() < 2) continue;
    user_feas.assign(feas.begin(), feas.begin() + feas.size() / 2);
    item_feas.assign(feas.begin() + feas.size() / 2, feas.end());
    FacMachineScore user_score;

    dynamic_cast<UserItemFMModel*>(model)->CalcPartScore(user_feas, &user_score);
    dynamic_cast<UserItemFMModel*>(model)->Predict(user_score, 1u, item_feas, &ctr);
    ASSERT_FLOAT_EQ(real_score,  ctr);
    // test cache
    dynamic_cast<UserItemFMModel*>(model)->Predict(user_score, 1u, item_feas, &ctr);
    ASSERT_FLOAT_EQ(real_score, ctr);
  }
}
}  // namespace ml
}  // namespace reco
