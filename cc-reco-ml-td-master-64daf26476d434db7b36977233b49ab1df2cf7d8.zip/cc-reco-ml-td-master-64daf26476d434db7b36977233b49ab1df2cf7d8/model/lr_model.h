#pragma once

#include <cmath>
#include <string>
#include <vector>
#include <utility>

#include "base/common/base.h"
#include "base/container/dense_hash_map.h"
#include "base/thread/rw_mutex.h"
#include "base/thread/thread.h"
#include "base/file/file_path.h"
#include "reco/ml/model/model.h"

namespace reco {
namespace kafka {
class Consumer;
}
namespace ml {

class DenseHashLRModel;
class LRModel : public Model  {
 public:
  LRModel() {}
  virtual ~LRModel() {}

  virtual bool Initialize(const std::string &config_file) {
    return Model::Initialize(config_file);
  }

  virtual void Predict(const std::vector<std::string>& features,
                       double* sum_weight, int* hits, double* ctr,
                       std::vector<std::string>* hit_features = NULL) const = 0;

  virtual void Predict(const std::vector<uint64>& features,
                       double* sum_weight, int* hits, double* ctr,
                       std::vector<uint64>* hit_features = NULL) const = 0;

  virtual bool LoadText(base::FilePath dict_path, float load_factor = 0.5) = 0;

  virtual bool LoadBin(base::FilePath dict_path) = 0;

  virtual bool SaveBin(base::FilePath dict_path) = 0;
 protected:
  static double LRScore(double sum_weight) {
    return 1.0 / (1 + exp(-sum_weight));
  }
};

class DenseHashLRModel : public LRModel {
 public:
  DenseHashLRModel(): feature_map_(NULL), str_model_(NULL) {}
  virtual ~DenseHashLRModel() {
    delete feature_map_;
    delete str_model_;
  }

  virtual bool Initialize(const std::string &config_file);

  virtual void Predict(const std::vector<std::string>& features, double* sum_weight, int* hits, double* ctr,
                       std::vector<std::string>* hit_features = NULL) const;

  virtual void Predict(const std::vector<uint64>& features, double* sum_weight, int* hits, double* ctr,
                       std::vector<uint64>* hit_features = NULL) const;

  virtual bool LoadText(base::FilePath dict_path,
                        float load_factor = 0.5);

  virtual bool LoadBin(base::FilePath dict_path);

  virtual bool SaveBin(base::FilePath dict_path);

 protected:
  bool LookupWeight(uint64 sign, double* w, int32* hits) const {
    if (sign == 0u) return false;
    auto it = feature_map_->find(sign);
    if (it != feature_map_->end()) {
      *w += it->second;
      (*hits)++;
      return true;
    } else {
      return false;
    }
  }

  base::dense_hash_map<uint64, float>* feature_map_;
  std::string* str_model_;  // for load binary model
  std::string dict_type_;   // "bin or text"
  std::string dict_path_;
};

class OlmDenseHashLRModel : public DenseHashLRModel {
 public:
  OlmDenseHashLRModel();
  ~OlmDenseHashLRModel();

  virtual bool Initialize(const std::string &config_file);
  virtual void Predict(const std::vector<std::string>& features, double* sum_weight, int* hits, double* ctr,
                       std::vector<std::string>* hit_features = NULL) const;

  virtual void Predict(const std::vector<uint64>& features, double* sum_weight, int* hits, double* ctr,
                       std::vector<uint64>* hit_features = NULL) const;

  bool ReloadBatchModel(const base::FilePath& config_file);

  void StartUpdate();
  void stop();
 protected:
  virtual bool GetNewFea(std::vector<std::pair<uint64, double> >* fea_w, uint64* batch_timestamp) = 0;
  void ModelUpdateWorker();

  mutable thread::RWMutex rw_mutex_;
  thread::Thread update_thread_;
  bool stop_;
  uint64 batch_timestamp_;
};

// thread safe, singleton usage
class OlmMqDenseHashLRModel: public OlmDenseHashLRModel {
 public:
  OlmMqDenseHashLRModel() { consumer_ = NULL; }
  ~OlmMqDenseHashLRModel() {}

  virtual bool Initialize(const std::string &config_file);
 public:
  virtual bool GetNewFea(std::vector<std::pair<uint64, double> >* fea_w, uint64* timestamp);
 protected:
  reco::kafka::Consumer* consumer_;
};
}  // namespace ml
}  // namespace reco
