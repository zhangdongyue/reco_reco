#if __cplusplus < 201103L
#include "reco/bizc/item_service/doc_server_get_item.h"
#else
#include "reco/bizc/item_service_arpc/doc_server_get_item.h"
#endif
