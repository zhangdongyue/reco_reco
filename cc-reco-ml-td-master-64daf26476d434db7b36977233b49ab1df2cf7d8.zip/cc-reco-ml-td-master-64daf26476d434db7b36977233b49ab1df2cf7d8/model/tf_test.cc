#include <string>
#include <limits>
#include <iostream>
#include <fstream>
#include <utility>
#include <unordered_map>

#include "base/file/file_util.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

#include "reco/ml/model/factory.h"
#include "reco/base/math/math.h"

namespace reco {
namespace ml {
DEFINE_string(tf_model_config, "../config/model/tf/tudou_wnd_v3.em21", "running in model server data dir");
DEFINE_string(tf_case_file, "./test.dat", "");

class TFModelTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
  }

  virtual void TearDown() {
  }
};

void GenerateOneRequest(reco::model_server::OneRequest* one_request) {
  const std::string sep = "[dat]";
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_tf_case_file), &lines));

  one_request->set_user_id(1);

  reco::model_server::WideDeepRequest* wide_deep_request = NULL;
  reco::model_server::Features* ins = NULL;

  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i] == sep) {
      wide_deep_request = one_request->add_wide_deep_requests();
      wide_deep_request->mutable_model_info()->set_model_name("tudou_wnd_v3");
      ins = wide_deep_request->add_request_items();
    }

    size_t pos = lines[i].find("=0:");
    if (pos == std::string::npos) {
      continue;
    }

    reco::model_server::FeatureInfo* fea = ins->add_feature_info();
    fea->set_literal(lines[i].substr(0, pos));
    fea->set_text(lines[i].substr(pos + 3));
  }
}

TEST_F(TFModelTest, TestPredict) {
  TFModel* tf_model = dynamic_cast<TFModel*>(ModelFactory::CreateModel("tf"));
  ASSERT_TRUE(tf_model != NULL);
  tf_model->Initialize(FLAGS_tf_model_config);
  reco::model_server::OneRequest one_request;
  GenerateOneRequest(&one_request);
  reco::model_server::OneResponse one_response;
  reco::model_server::Features user_fea;
  tf_model->Predict(one_request, user_fea, &one_response);
  for (int i = 0; i < one_response.wide_deep_responses_size(); ++i) {
    const reco::model_server::WideDeepResponse& wide_deep_response = one_response.wide_deep_responses(i);
    if (wide_deep_response.response_items_size() < 1) {
      LOG(ERROR) << "empty fm response items: " << one_request.user_id();
      continue;
    }
    LOG(INFO) << "predict: " << i << " " << wide_deep_response.response_items(0).q();
  }
}
}  // namespace ml
}  // namespace reco
