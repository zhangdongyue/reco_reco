#pragma once

#include <string>

#include "base/common/base.h"
#include "base/common/logging.h"

#include "reco/ml/model/lr_model.h"
#include "reco/ml/model/fm_model.h"
#include "reco/ml/model/tf.h"

#define BEGIN_REGISTER_MODEL() \
namespace reco { \
namespace ml { \
class ModelFactory { \
  public: \
  static reco::ml::Model* CreateModel(const std::string &type) { \
    if (type.empty()) { \
      return NULL; \
    }

#define REGISTER_MODEL(NAME, CLASS) \
    if (type == (NAME)) { \
      LOG(INFO) << "New Model! type:" << (NAME); \
      return new (CLASS); \
    }

#define END_REGISTER_MODEL() \
    LOG(ERROR) << "error! invalid type:" << (type); \
    return NULL; \
  } \
}; \
} \
}

BEGIN_REGISTER_MODEL()
REGISTER_MODEL("lr_olm", reco::ml::OlmMqDenseHashLRModel)
REGISTER_MODEL("fm_user", reco::ml::UserItemFMModel)
REGISTER_MODEL("tf", reco::ml::TFModel)
END_REGISTER_MODEL()
