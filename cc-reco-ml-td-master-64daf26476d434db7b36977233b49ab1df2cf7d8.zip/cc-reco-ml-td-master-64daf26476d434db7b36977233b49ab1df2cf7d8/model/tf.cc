#include <fstream>
#include <utility>

#include "reco/ml/model/tf.h"

#include "reco/base/xml/xml.h"
#include "reco/base/json/json.h"
#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/strings/string_printf.h"
#include "base/hash_function/term.h"
#include "base/file/file_util.h"
#include "serving_base/utility/timer.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "reco/ml/wd_feature/factory.h"
#include "net/counter/export.h"

namespace reco {
namespace ml {
DEFINE_string(zk_sockets, "11.251.203.133:2181,11.251.203.169:2181,11.251.203.239:2181,11.251.204.7:2181,11.251.204.18:2181", "zk address");  // NOLINT
DEFINE_string(press_ip, "", "only for pressing useage; if set would mask zk");
DEFINE_int32(update_interval_in_seconds, 1, "zk config update interval");

static cygnet::HttpTransport* InitTransport(int thread_num) {
#if __cplusplus < 201103L
  cygnet::HttpTransport::TlsEnvironmentInit();
#else
  static  cygnet::CygnetLogger cygnet_logger;
  cygnet::GlobalInit(cygnet_logger);
#endif
  cygnet::HttpTransport* transport = new cygnet::HttpTransport(false);
  cygnet::HttpTransport::Config config;
  config._threadNum = thread_num;  // NOLINT
  config._maxBody = 10 * 1024 * 1024;  // NOLINT

  if (!transport->Init(config)) {
    LOG(ERROR) << "init transport failed";
  }

  if (!transport->Start()) {
    LOG(ERROR) << "start transport failed";
  }
  return transport;
}

static cygnet::HttpTransport* CreateSingleTransport(int thread_num) {
  static cygnet::HttpTransport* transport = InitTransport(thread_num);
  return transport;
}

TFModel::~TFModel() {
  if (!is_running_) return;
  stop_ = true;
  update_thread_.Join();

  is_running_ = false;
#if __cplusplus < 201103L
//  cygnet::HttpTransport::TlsEnvironmentDestroy();
#else
  transport_->Stop();
  transport_->Destroy();
  cygnet::GlobalDestroy();
#endif
  delete fea_extractor_;

  // if (!transport_delete_) {
  //   transport_delete_ = true;
  //   transport_->Stop();
  //   transport_->Destroy();
  //   cygnet::HttpTransport::TlsEnvironmentDestroy();
  // }
}

void TFModel::UpdateTFHosts(const std::string& conf, std::shared_ptr<std::vector<std::string> > hosts) {
  if (FLAGS_press_ip.size() > 0) {
    hosts->push_back(FLAGS_press_ip);
    return;
  }

  static const std::string kSep = "spec=";
  std::vector<std::string> children;
  zk_setting_->GetChildren(conf.c_str(), &children);
  std::vector<std::string> flds;
  for (size_t i = 0; i < children.size(); ++i) {
    flds.clear();
    base::SplitString(children[i], ",", &flds);
    size_t pos = flds[0].find(kSep);
    if (pos == std::string::npos) {
      LOG(ERROR) << "erro conf: " << children[i];
      continue;
    }
    hosts->push_back(flds[0].substr(pos + kSep.size()));
  }
}
// must be single thread
void TFModel::UpdateWorker(int seconds) {
  serving_base::Timer timer;
  timer.Start();
  while (!stop_) {
    base::SleepForSeconds(seconds);
    std::shared_ptr<std::vector<std::string>> hosts = std::make_shared<std::vector<std::string> >();
    UpdateTFHosts(server_info_.zk_path, hosts);
    model_mutex_.WriterLock();
    server_info_.hosts = hosts;
    model_mutex_.WriterUnlock();
  }
}

// 动态加载调用改函数没有风险，动态加载每次生成的新的对象，没有 update 线程运行
bool TFModel::Initialize(const std::string& config_file) {
  transport_ = CreateSingleTransport(128);

  if (!Model::Initialize(config_file)) {
    LOG(ERROR) << "Model::Initialize error!";
    return false;
  }
  if (!enable_) {
    return true;
  }

//  cygnet::HttpTransport::TlsEnvironmentInit();
  model_mutex_.WriterLock();

  CHECK(!is_running_) << "init must used in new item";
  zk_setting_ = new zkconfig::CloudSetting(FLAGS_zk_sockets.c_str(), "");


  std::string content;
  if (!base::file_util::ReadFileToString(config_file, &content)) {
    LOG(ERROR) << "Failed to open model config file! file:" << config_file;
    return false;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(content, &context)) {
    LOG(ERROR) << "Failed to parse model config xml:" << content;
    return false;
  }

  if (!reco::xml::GetXPathString("/config/zk_path", &context, &server_info_.zk_path)) {
    LOG(ERROR) << "error read zk_path! " << name_;
    return false;
  }

  if (!reco::xml::GetXPathString("/config/sep", &context, &server_info_.sep)) {
    LOG(ERROR) << "error read sep! " << name_;
    return false;
  }

  if (!reco::xml::GetXPathInt32("/config/fea_cache", &context, &server_info_.fea_cache)) {
    LOG(ERROR) << "error read fea_cache " << name_;
    return false;
  }

  std::string extractor_name;
  if (!reco::xml::GetXPathString("/config/item_fea_extractor", &context, &extractor_name)) {
    LOG(WARNING) << "error read extractor! " << name_;
  }

  std::string fea_file;
  if (!reco::xml::GetXPathString("/config/fea_file", &context, &fea_file)) {
    LOG(WARNING) << "error fea file for model: " << name_;
  }

  LOG(INFO) << name_ << " " << extractor_name;
  fea_extractor_ = FeatureExtractorFactory::CreateExtractor(extractor_name);
  if (fea_extractor_ != NULL) {
    fea_extractor_->Initialize(name_ + "--" + extractor_name, fea_file);
  }

  zk_setting_->MonitorChildrenChange(server_info_.zk_path.c_str());
  // read from zk to get the hosts
  server_info_.uri = "/predict";
  server_info_.protocol = "http";

  // 主动更新一次
  server_info_.hosts = std::make_shared<std::vector<std::string> >();
  UpdateTFHosts(server_info_.zk_path, server_info_.hosts);
  LOG(INFO) << "update : " << name_ << " " << server_info_.hosts->size();

  model_mutex_.WriterUnlock();

  // 启动 update 线程
  update_thread_.Start(::NewCallback(this, &TFModel::UpdateWorker, 5));

  is_running_ = true;
  return true;
}

bool TFModel::GetModelInfo(const std::string& model_name, std::string* host, std::string* sep) const {
  if (name_ != model_name) {
    LOG(ERROR) << "non exist model: " << model_name << ", current=" << name_;
    return false;
  }

  model_mutex_.ReaderLock();
  std::shared_ptr<std::vector<std::string> > hosts = server_info_.hosts;
  model_mutex_.ReaderUnlock();
  if (hosts->empty()) {
    LOG(ERROR) << "empty host list";
    return false;
  }

  uint32 index = server_info_.index->Take();
  if (index >= hosts->size()) {
    index = 0;
  }
  CHECK(server_info_.index->TryPut(index + 1));

  *host = hosts->at(index);
  *sep = server_info_.sep;
  return true;
}

void AddUserFea(const reco::model_server::Features& user_fea, const std::string& sep, std::string* buf) {
  *buf = sep;

  for (int32 j = 0; j < (int32)user_fea.feature_info_size(); j++) {
    *buf += "\n";
    const reco::model_server::FeatureInfo& feature_info = user_fea.feature_info(j);
    *buf += feature_info.literal();
    *buf += "=0:";
    *buf += feature_info.text();
  }
}

void AddDynamicItemFea(const reco::model_server::Features& feature, std::string* buf) {
  bool first = true;
  for (int32 j = 0; j < (int32)feature.feature_info_size(); j++) {
    if (feature.feature_info(j).text().empty()) continue;
    if (!first) *buf += "\n";
    first = false;
    const reco::model_server::FeatureInfo& feature_info = feature.feature_info(j);
    *buf += feature_info.literal();
    *buf += "=0:";
    *buf += feature_info.text();
  }
}

void TFModel::Predict(const model_server::OneRequest& request, const reco::model_server::Features& user_fea,
                      model_server::OneResponse* response) const {
  if (request.wide_deep_requests_size() == 0) {
    LOG(ERROR) << "empty wd request: ";
    return;
  }

  serving_base::Timer timer;
  timer.Start();
  response->mutable_wide_deep_responses()->Reserve(request.wide_deep_requests_size() + 1);

  std::string host;
  std::string sep;
  const std::string& model_name = request.wide_deep_requests(0).model_info().model_name();

  if (!GetModelInfo(model_name, &host, &sep)) {
    return;
  }
  // host = "11.251.196.228:6868";

  cygnet::HttpClientConnection* conn = transport_->CreateConnection(host, "", 100);
  if (conn == NULL) {
    LOG(ERROR) << "create connection failed";
    return;
  }

  cygnet::HttpRequestPacket* requestPacket = cygnet::HttpPacketFactory::CreateRequest();
  requestPacket->SetVersion(cygnet::HV_11);
  requestPacket->SetMethod(cygnet::HM_POST);
  requestPacket->SetUri("/predict");
  requestPacket->AddHeader("Content-Type", "application/json");

  std::string buf;
  buf.reserve(1024 * 32);
  std::string user_str;
  AddUserFea(user_fea, sep, &user_str);
  std::string item_fea_str;
  // LOG(ERROR) << "user fea: " << user_str;
  for (int32 i = 0; i < (int32)request.wide_deep_requests_size(); i++) {
    auto& wide_deep_request = request.wide_deep_requests(i);
    if (wide_deep_request.request_items_size() > 1) {
      LOG(ERROR) << "wide deep request must contain only one item";
      return;
    }

    // append user fea
    if (requestPacket->GetBody().size() > 0) {
      requestPacket->AppendBody("\n", 1);
    }
    requestPacket->AppendBody(user_str.c_str(), user_str.size());

    // append dynamic item fea
    if (wide_deep_request.request_items_size() > 0) {
      buf.clear();
      AddDynamicItemFea(wide_deep_request.request_items(0), &buf);
      if (buf.size() > 0) {
        requestPacket->AppendBody("\n", 1);
        requestPacket->AppendBody(buf.c_str(), buf.size());
      }
      // LOG(ERROR) << "dynamic fea: " << buf;
    }
    // append static item_fea
    if (fea_extractor_ != NULL) {
      uint64 item_id = wide_deep_request.sid();
      item_fea_str.clear();
      fea_extractor_->ExtractFea(item_id, server_info_.fea_cache > 0, &item_fea_str);
      if (item_fea_str.size() > 0) {
        requestPacket->AppendBody("\n", 1);
        requestPacket->AppendBody(item_fea_str.c_str(), item_fea_str.size());
      }
      // LOG(ERROR) << "static fea: " << item_fea_str;
    }
  }
  LOG_EVERY_N(INFO, 10000) << std::string(&(requestPacket->GetBody()[0]), requestPacket->GetBody().size());
  // LOG(ERROR) << std::string(&(requestPacket->GetBody()[0]), requestPacket->GetBody().size());

  int fea_time = timer.Interval();
  if (requestPacket->GetBody().size() < 3) {
    LOG(ERROR) << "empty body: " << request.user_id();
    requestPacket->Free();
    return;
  }

  cygnet::Packet* packet = NULL;
  if (!conn->Request(*requestPacket, 0, &packet)) {
    LOG(ERROR) << "request packet failed";
    return;
  }

  if (packet->IsCmdPacket()) {
    LOG(ERROR) << "cmd packet recv";
    conn->Destroy();
    return;
  }
  int tf_time = timer.Interval();

  cygnet::HttpResponsePacket* responsePacket = static_cast<cygnet::HttpResponsePacket*>(packet);
  CHECK_NOTNULL(responsePacket);
  const std::vector<char>& msg = responsePacket->GetBody();

  std::vector<double> probs;
  if (!reco::json::ParseTFServingResult(std::string(&msg[0], msg.size()), &probs)) {
    LOG(ERROR) << "parse faield for " << &msg[0];
    LOG(ERROR) << "request user: " << request.user_id();
  }
  int parse_time = timer.Interval();
  LOG_EVERY_N(INFO, 10000) << "tf time: " << fea_time << " " << tf_time << " " << parse_time;
  // LOG(ERROR) << "tf time: " << fea_time << " " << tf_time << " " << parse_time;

  if ((int)probs.size() != request.wide_deep_requests_size()) {
    LOG(ERROR) << " erro size match: " << probs.size() << " vs " << request.wide_deep_requests_size();
  }

  // LOG(ERROR) << "prob size: " << probs.size() << " " << request.wide_deep_requests_size();;
  // std::string debug_str = base::StringPrintf("debug: %lu", request.user_id());
  for (size_t i = 0;  i < probs.size(); ++i) {
    reco::model_server::WideDeepResponse* wide_deep_response = response->add_wide_deep_responses();
    wide_deep_response->set_sid(request.wide_deep_requests(i).sid());
    wide_deep_response->set_code(0);
    reco::model_server::ModelResInfo* model_res_info = wide_deep_response->add_response_items();
    model_res_info->set_q(probs[i]);
    // debug_str += base::StringPrintf(" %lu,%lf", request.wide_deep_requests(i).sid(), probs[i]);
    // LOG(ERROR) << "host: " << host << " " << probs[i];
  }
  // LOG(INFO) << debug_str;
  conn->Destroy();
  responsePacket->Free();
}
}  // namespace ml
}  // namespace reco
