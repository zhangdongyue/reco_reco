#include "reco/ml/model/lr_model.h"

#include <math.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <iostream>
#include <utility>
#include <fstream>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/file_util.h"
#include "base/hash_function/city.h"
#include "base/thread/rw_mutex.h"
#include "reco/base/xml/xml.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/ml/online_model/proto/online_model.pb.h"
#include "serving_base/utility/time_helper.h"

namespace reco {
namespace ml {

bool DenseHashLRModel::Initialize(const std::string &config_file) {
  if (!Model::Initialize(config_file)) {
    LOG(ERROR) << "Model::Initialize error!";
    return false;
  }

  if (!enable_) {
    return true;
  }

  std::string content;
  if (!base::file_util::ReadFileToString(config_file, &content)) {
    LOG(ERROR) << "Failed to open model config file! file:" << config_file;
    return false;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(content, &context)) {
    LOG(ERROR) << "Failed to parse model config xml:" << content;
    return false;
  }

  if (!reco::xml::GetXPathString("/config/dict_path", &context, &dict_path_)) {
    LOG(ERROR) << "error read dict_path! dict_path:" << dict_path_;
    return false;
  }

  if (!reco::xml::GetXPathString("/config/dict_type", &context, &dict_type_)) {
    LOG(ERROR) << "error read dict_type! dict_type:" << dict_type_;
    return false;
  }

  if (dict_path_.empty()) {
    LOG(ERROR) << "dict name empty!";
    return false;
  }

  if (dict_type_ == "bin") {
    if (!LoadBin(dict_path_)) {
      LOG(ERROR) << "lr bin dict load error!";
      return false;
    }
  } else if (dict_type_ == "text") {
    if (!LoadText(dict_path_, 0.6)) {
      LOG(ERROR) << "lr text dict load error!";
      return false;
    }
  } else {
    LOG(ERROR) << "unknow dict type! " << dict_type_;
    return false;
  }
  return true;
}

bool DenseHashLRModel::LoadText(base::FilePath dict_path, float load_factor) {
  if (NULL != feature_map_) delete feature_map_;
  feature_map_ = new base::dense_hash_map<uint64, float>();

  feature_map_->set_empty_key(0u);
  feature_map_->max_load_factor(load_factor);

  LOG(INFO) << "Start size:" << feature_map_->size()
            << " max_size:" << feature_map_->max_size()
            << " bucket_count:" << feature_map_->bucket_count()
            << " max_bucket_count:" << feature_map_->max_bucket_count();

  std::ifstream in_file(dict_path.ToString());
  if (!in_file.good()) {
    LOG(ERROR) << dict_path.ToString() << " not exist!";
    return false;
  }
  std::string line;
  uint64 line_cnt = 0;
  while (std::getline(in_file, line)) {
    if (line.empty()) continue;
    std::vector<std::string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 2) {
      LOG(ERROR) << "Error format line: " << line;
      continue;
    }
    int sign_pos = 0;
    if (tokens.size() == 3) sign_pos = 1;
    const std::string& str_sign   = tokens[sign_pos];
    const std::string& str_weight = tokens[sign_pos + 1];
    uint64 sign = 0u;
    double weight = 0.0;
    if (!base::StringToUint64(str_sign, &sign)) {
      LOG(ERROR) << "Error format line: " << line;
      continue;
    }
    if (!base::StringToDouble(str_weight, &weight)) {
      LOG(ERROR) << "Error format line: " << line;
      continue;
    }
    (*feature_map_)[sign] = weight;
    ++line_cnt;

    LOG_EVERY_N(INFO, 1000000)
        << "size:" << feature_map_->size()
        << " max_size:" << feature_map_->max_size()
        << " bucket_count:" << feature_map_->bucket_count()
        << " max_bucket_count:" << feature_map_->max_bucket_count();
  }

  if (!in_file.eof()) {
    LOG(ERROR) << "Read file " << dict_path.ToString() << " error.";
    return false;
  }

  LOG(INFO) << "Read " << line_cnt << " lines from " << dict_path.ToString()
            << "Finally, size:" << feature_map_->size()
            << " max_size:" << feature_map_->max_size()
            << " bucket_count:" << feature_map_->bucket_count()
            << " max_bucket_count:" << feature_map_->max_bucket_count();

  return true;
}

bool DenseHashLRModel::LoadBin(base::FilePath dict_path) {
  if (NULL != str_model_) delete str_model_;
  str_model_ = new std::string();

  if (NULL != feature_map_) delete feature_map_;
  feature_map_ = new base::dense_hash_map<uint64, float>();

  feature_map_->set_empty_key(0u);
  if (!base::file_util::ReadFileToString(dict_path, str_model_)) {
    LOG(ERROR) << "Load " << dict_path.value() << " fail!";
    return false;
  }

  if (!feature_map_->Read(str_model_->data(), str_model_->size())) {
    LOG(ERROR) << "Load " << dict_path.value() << " fail!";
    return false;
  }
  LOG(WARNING) << "Load " << dict_path.value() << " to memory.";
  return true;
}

bool DenseHashLRModel::SaveBin(base::FilePath dict_path) {
  if (feature_map_ == NULL || feature_map_->empty()) {
    LOG(ERROR) << "empty dict to save";
    return false;
  }
  std::ofstream mmap_out(dict_path.value());
  feature_map_->MemoryMapWrite(&mmap_out);
  mmap_out.close();
  return true;
}

void DenseHashLRModel::Predict(const std::vector<uint64>& features,
                               double* sum_weight, int* hits, double* ctr,
                               std::vector<uint64>* hit_features) const {
  *sum_weight = 0.0;
  *hits = 0;
  for (size_t i = 0; i < features.size(); ++i) {
    bool hit = LookupWeight(features.at(i), sum_weight, hits);
    if (hit && hit_features != NULL) {
      hit_features->push_back(features.at(i));
    }
  }
  *ctr =  LRScore(*sum_weight);
}

void DenseHashLRModel::Predict(const std::vector<std::string>& features,
                               double* sum_weight, int* hits, double* ctr,
                               std::vector<std::string>* hit_features) const {
  *sum_weight = 0.0;
  *hits = 0;
  for (size_t i = 0; i < features.size(); ++i) {
    uint64 sign = base::CityHash64(features.at(i).c_str(), features.at(i).size());
    bool hit = LookupWeight(sign, sum_weight, hits);
    if (hit && hit_features != NULL) {
      hit_features->push_back(features.at(i));
    }
  }
  *ctr =  LRScore(*sum_weight);
}

// olm lr model
OlmDenseHashLRModel::OlmDenseHashLRModel() {
  stop_ = false;
}

void OlmDenseHashLRModel::stop() {
  if (stop_) return;
  stop_ = true;
  update_thread_.Join();
}

OlmDenseHashLRModel::~OlmDenseHashLRModel() {
  stop();
}

bool OlmDenseHashLRModel::ReloadBatchModel(const base::FilePath& path) {
  rw_mutex_.WriterLock();
  // bool succ = false;
  // if (load_type == "text") {
  //   succ = LoadText(path, 0.5);
  // } else if (load_type == "bin") {
  //   succ = LoadBin(path);
  // } else {
  //   LOG(ERROR) << "err load type: " << load_type;
  // }
  bool succ = Initialize(path.value());
  rw_mutex_.WriterUnlock();
  return succ;
}

bool OlmDenseHashLRModel::Initialize(const std::string& config_file) {
  bool succ = DenseHashLRModel::Initialize(config_file);
  std::string content;
  if (!base::file_util::ReadFileToString(config_file, &content)) {
    LOG(ERROR) << "Failed to open model config file! file:" << config_file;
    return false;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(content, &context)) {
    LOG(ERROR) << "Failed to parse model config xml:" << content;
    return false;
  }

  std::string time_str;
  if (!reco::xml::GetXPathString("/config/batch_timestamp", &context, &time_str)) {
    LOG(ERROR) << "error read batch_timestamp";
    return false;
  }

  if (!serving_base::TimeHelper::StringToTimestamp(time_str, serving_base::TimeHelper::kSecond,
                                                   &batch_timestamp_)) {
    LOG(ERROR) << "error batch timestamp " << time_str;
    return false;
  }
  return succ;
}

void OlmDenseHashLRModel::StartUpdate() {
  update_thread_.Start(::NewCallback(this, &OlmDenseHashLRModel::ModelUpdateWorker));
}

void OlmDenseHashLRModel::ModelUpdateWorker() {
  std::vector<std::pair<uint64, double> > fea_w;
  uint64 timestamp = 0;
  while (!stop_) {
    if (!GetNewFea(&fea_w, &timestamp)) {
      base::SleepForSeconds(1);
      continue;
    }
    LOG_EVERY_N(INFO, 1000) << "get feaw: " << fea_w.size();

    if (timestamp != 0 && timestamp != batch_timestamp_) continue;

    rw_mutex_.WriterLock();
    for (int i = 0; i < (int)fea_w.size(); ++i) {
      (*feature_map_)[fea_w[i].first] = fea_w[i].second;
    }
    rw_mutex_.WriterUnlock();
  }
}

void OlmDenseHashLRModel::Predict(const std::vector<std::string>& features,
                                  double* sum_weight, int* hits, double* ctr,
                                  std::vector<std::string>* hit_features) const {
  rw_mutex_.ReaderLock();
  DenseHashLRModel::Predict(features, sum_weight, hits, ctr, hit_features);
  rw_mutex_.ReaderUnlock();
}

void OlmDenseHashLRModel::Predict(const std::vector<uint64>& features,
                                  double* sum_weight, int* hits, double* ctr,
                                  std::vector<uint64>* hit_features) const {
  rw_mutex_.ReaderLock();
  DenseHashLRModel::Predict(features, sum_weight, hits, ctr, hit_features);
  rw_mutex_.ReaderUnlock();
}

bool OlmMqDenseHashLRModel::Initialize(const std::string& config_file) {
  bool succ = OlmDenseHashLRModel::Initialize(config_file);
  std::string content;
  if (!base::file_util::ReadFileToString(config_file, &content)) {
    LOG(ERROR) << "Failed to open model config file! file:" << config_file;
    return false;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(content, &context)) {
    LOG(ERROR) << "Failed to parse model config xml:" << content;
    return false;
  }

  std::string brokers;
  if (!reco::xml::GetXPathString("/config/kafka_brokers", &context, &brokers)) {
    LOG(WARNING) << "cannot read brokers, would run like batch lr";
    return true;
  }

  std::string topic;
  if (!reco::xml::GetXPathString("/config/kafka_topic", &context, &topic)) {
    LOG(ERROR) << "error read kafka topic";
    return false;
  }

  std::string partition_str;
  if (!reco::xml::GetXPathString("/config/kafka_partition", &context, &partition_str)) {
    LOG(ERROR) << "error read kafka partition";
    return false;
  }
  int partition = 0;
  if (!base::StringToInt(partition_str, &partition)) {
    LOG(ERROR) << "error partition number " << partition_str;
    return false;
  }

  uint64 timestamp = 0;
  std::string time_str;
  if (reco::xml::GetXPathString("/config/kafka_time", &context, &time_str)) {
    LOG(WARNING) << "read from " << time_str;

    if (!serving_base::TimeHelper::StringToTimestamp(time_str, serving_base::TimeHelper::kSecond,
                                                     &timestamp)) {
      CHECK(serving_base::TimeHelper::GetCurrentTimestamp(serving_base::TimeHelper::kSecond,
                                                          &timestamp));
    }
  }

  reco::kafka::ConsumerOptions options;
  options.topic = topic;
  options.partition_num = partition;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = "0";
  options.start_timestamp = timestamp / 1000000;
  consumer_ = new reco::kafka::Consumer(brokers, options);

  StartUpdate();
  return succ;
}

bool OlmMqDenseHashLRModel::GetNewFea(std::vector<std::pair<uint64, double> >* fea_w, uint64* timestamp) {
  if (consumer_ == NULL) return false;

  reco::kafka::Message msg;
  BundleFeaWeight bundle_weight;
  if (!consumer_->Consume(&msg, 100)) {
    LOG_EVERY_N(INFO, 1000) << "get message from kafka failed!";
    return false;
  }

  if (!bundle_weight.ParseFromString(msg.content)) {
    LOG(ERROR) << "failed to parse bundle weight from message, " << msg.content;
    return false;
  }

  *timestamp = 0;
  if (bundle_weight.has_batch_time()) {
    *timestamp = bundle_weight.batch_time();
  }

  fea_w->clear();
  for (int i = 0; i < bundle_weight.bfw_size(); ++i) {
    fea_w->push_back(std::make_pair(bundle_weight.bfw(i).fea(),
                                    bundle_weight.bfw(i).weight()));
  }
  // LOG(INFO) << "get feaw " << fea_w->size();
  return true;
}
}   // namespace ml
}   // namespace reco
