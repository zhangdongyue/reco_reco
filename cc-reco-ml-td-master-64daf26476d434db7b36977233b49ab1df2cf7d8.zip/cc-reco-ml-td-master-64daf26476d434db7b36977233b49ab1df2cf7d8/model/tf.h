#pragma once
#include <cygnet/cygnet.h>
#if __cplusplus >= 201103L
#include <cygnet/cygnet_logger.h>
#endif
//#include <cstdatomic>
#include <vector>
#include <unordered_map>
#include <string>
#include <utility>
#include <memory>

#include "reco/base/common/atomic.h"
#include "base/thread/rw_mutex.h"
#include "base/thread/blocking_var.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread.h"
#include "base/thread/thread_pool.h"
#include "reco/ml/model/model.h"
#include "reco/base/zkconfig/cloud_setting.h"
#include "reco/bizc/proto/model_type.pb.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/testing/gtest_prod.h"

namespace reco {
namespace ml {
class WDFeatureExtractor;
// thread safe, single instance
class TFModel: public Model {
 public:
  TFModel(): stop_(false), is_running_(false) {}
  virtual ~TFModel();

  // NOTE: when call init, it cannot be using
  virtual bool Initialize(const std::string& config_file);

  void Predict(const model_server::OneRequest& request, const reco::model_server::Features& user_fea,
               model_server::OneResponse* response) const;

 private:
  struct TFServerInfo {
    TFServerInfo(): hosts(std::make_shared<std::vector<std::string> >()), index(new thread::BlockingVar<uint32>()) {CHECK(index->TryPut(0));}  // NOLINT
    std::shared_ptr<std::vector<std::string> > hosts;
    std::string uri;
    std::string protocol;
    std::string zk_path;
    std::string sep;
    thread::BlockingVar<uint32>* index;
    int fea_cache;
  };

  bool stop_;
  bool is_running_;
  // only read by memeber function
  cygnet::HttpTransport* transport_;
  mutable thread::RWMutex model_mutex_;

  WDFeatureExtractor* fea_extractor_;

  zkconfig::CloudSetting* zk_setting_;

  TFServerInfo server_info_;

  thread::Thread update_thread_;
 protected:
  void UpdateTFHosts(const std::string& conf, std::shared_ptr<std::vector<std::string> > hosts);
  bool GetModelInfo(const std::string& model_name, std::string* host, std::string* sep) const;

  bool MergeScores(const std::vector<double>& probs, bool use_cache,
                   std::vector<std::pair<double, uint64> >* scores) const;

  void UpdateWorker(int seconds);

  FRIEND_TEST(TFModelTest, TestMergeScore);
};
}
}
