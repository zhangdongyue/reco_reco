#include "reco/ml/model/model.h"

#include <string>
#include <vector>
#include <unordered_map>

#include "base/common/base.h"
#include "base/common/logging.h"

#include "base/file/file_util.h"
#include "base/strings/string_util.h"

#include "reco/base/xml/xml.h"

namespace reco {
namespace ml {

std::string Model::GetModelTypeFromConfig(const std::string &config_file) {
  std::string model_type = "";
  if (config_file.empty()) return model_type;

  std::string content;
  if (!base::file_util::ReadFileToString(config_file, &content)) {
    LOG(ERROR) << "Failed to open model root file! file:" << config_file;
    return model_type;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(content, &context)) {
    LOG(ERROR) << "Failed to parse model root xml:" << content;
    return model_type;
  }

  if (!reco::xml::GetXPathString("/config/type", &context, &model_type)) {
    LOG(ERROR) << "Failed to parse type xml config!";
    model_type = "";
    return model_type;
  }

  return model_type;
}

bool Model::Initialize(const std::string& config_file) {
  if (config_file.empty()) return false;
  config_file_ = config_file;

  std::string content;
  if (!base::file_util::ReadFileToString(config_file, &content)) {
    LOG(ERROR) << "Failed to open model config file! file:" << config_file;
    return false;
  }

  util::xml::XMLParser parser;
  util::xml::XMLContext context;
  if (!parser.Parse(content, &context)) {
    LOG(ERROR) << "Failed to parse model config xml:" << content;
    return false;
  }

  enable_ = false;
  std::string enable_string = "";
  if (!reco::xml::GetXPathString("/config/enable", &context, &enable_string)) {
    LOG(ERROR) << "Failed to parse enable in model config!" << config_file_;
    return false;
  }
  base::LowerString(&enable_string);
  if (enable_string == "true") {
    enable_ = true;
  }

  if (!reco::xml::GetXPathString("/config/type", &context, &type_)) {
    LOG(ERROR) << "Failed to parse type in model config!" << config_file_;
    return false;
  }

  if (!reco::xml::GetXPathString("/config/name", &context, &name_)) {
    LOG(ERROR) << "Failed to parse name in model config!" << config_file_;
    return false;
  }
  return true;
}
}
}
