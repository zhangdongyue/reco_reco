#include <string>
#include <limits>
#include <iostream>
#include <unordered_map>

#include "base/file/file_util.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

#include "reco/ml/model/lr_model.h"

namespace reco {
namespace ml {

class LRModelTest : public ::testing::Test {
 protected:
  base::FilePath WriteLinesToTempFile(const std::vector<std::string>& lines) {
    base::FilePath path;
    CHECK(base::file_util::CreateTemporaryFileInDir("/tmp", &path));
    std::string str = base::JoinStrings(lines, "\n");
    CHECK(base::file_util::WriteFile(path, str.c_str(), str.size()));

    return path;
  }

  virtual void SetUp() {
    std::vector<std::string> lines;

    // create pure key cases
    lines.push_back("ab\t1\t1");
    lines.push_back("ab\t2\t2");
    dense_hash_file_ = WriteLinesToTempFile(lines);
    dense_hash_bin_file_ = base::FilePath(dense_hash_file_.value() + ".bin");
  }

  virtual void TearDown() {
    CHECK(base::file_util::Delete(dense_hash_file_, false));
    CHECK(base::file_util::Delete(dense_hash_bin_file_, false));
  }

  base::FilePath dense_hash_file_;
  base::FilePath dense_hash_bin_file_;
};

TEST_F(LRModelTest, DenseHash) {
  double ctr, weight;
  int hits;
  LRModel* model = new DenseHashLRModel();
  ASSERT_TRUE(model->LoadText(dense_hash_file_));
  // test save bin
  ASSERT_TRUE(model->SaveBin(dense_hash_bin_file_));
  ASSERT_TRUE(model->LoadBin(dense_hash_bin_file_));

  std::vector<uint64> feas;
  feas.push_back(1);
  model->Predict(feas, &weight, &hits, &ctr);
  ASSERT_FLOAT_EQ(1.0, weight);
  ASSERT_FLOAT_EQ(0.73105857, ctr);
  ASSERT_EQ(hits, 1);

  feas.push_back(2);
  model->Predict(feas, &weight, &hits, &ctr);
  ASSERT_FLOAT_EQ(3.0, weight);
  ASSERT_FLOAT_EQ(0.95257412, ctr);
  ASSERT_EQ(hits, 2);

  feas.push_back(3);
  model->Predict(feas, &weight, &hits, &ctr);
  ASSERT_FLOAT_EQ(3.0, weight);
  ASSERT_FLOAT_EQ(0.95257412, ctr);
  ASSERT_EQ(hits, 2);

  delete model;
}

}  // namespace ml
}  // namespace reco
