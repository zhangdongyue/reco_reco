#pragma once

#include <string>
#include <vector>

#include "base/common/base.h"
#include "base/container/dense_hash_map.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/testing/gtest_prod.h"

#include "reco/ml/model/model.h"

namespace reco {
namespace ml {

class FMModel : public Model {
 public:
  FMModel(): v_dim_(0) {}
  virtual ~FMModel() {}
  virtual bool Initialize(const std::string &config_file);
  // for test usage and none model server binary loading usage
  bool Load(const std::string& dict_name);

  bool Predict(const std::vector<uint64>& features, double* ctr);
 protected:
  bool LookupWeight(uint64 sign, double* w, const double** v, std::vector<double>* lookup_val) const;
  struct FMWeight {
    char bitmap_[2];
    std::string value_;

    void clear() {
      bitmap_[0] = 0;
      bitmap_[1] = 0;
      if (value_.size() > 0) {
        value_.clear();
      }
    }
    void BitmapSet(int index) {
      bitmap_[index >>3] |= (1 << (index & 0x7));
    }
    int BitmapGet(int index) {
      return bitmap_[index>>3] & (1 << (index & 0x7));
    }
  };

 private:
  void FMPredict(const std::vector<uint64>& features, double* sum_weight);
  bool CompressToFMWeight(const std::vector<double> *val, FMWeight *fm_val, size_t max_len);
  bool DecompressFromFMWeight(std::vector<double> *val, FMWeight *fm_val, size_t max_len) const;

 protected:
  size_t v_dim_;
 private:
  std::string dict_path_;
  base::dense_hash_map<uint64, std::string > map_;
  // base::sparse_hash_map<uint64, std::string >* map_;
  std::vector<double> default_value_;
 private:
  DISALLOW_COPY_AND_ASSIGN(FMModel);
};

struct FacMachineScore {
  float sum_w;  // sum_n(w)
  float sum_v2;  // sum_n_k(v^2)
  std::vector<float> sum_v;  // sum_n(v)
};

class UserItemFMModel: public FMModel {
 public:
  bool Predict(const FacMachineScore& user_score,
               uint64 item_id,
               const std::vector<uint64>& item_fea,
               double* ctr);

  bool CalcPartScore(const std::vector<uint64>& fea, FacMachineScore* fm_score);
 private:
  double CalcUserItemCtr(const FacMachineScore& user_score, FacMachineScore& item_score);
  static serving_base::ExpiryMap<uint64, FacMachineScore> item_cache_;
};
}  // namespace ml
}  // namespace re
