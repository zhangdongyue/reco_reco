#include "reco/ml/wd_feature/video_rank_feature_extractor.h"
#include <string>
#include <vector>
#include <algorithm>

#include "reco/bizc/proto/item.pb.h"
#include "base/strings/string_number_conversions.h"
//#include "reco/bizc/item_service/doc_server_get_item.h"
#include "base/encoding/line_escape.h"

namespace reco {
namespace ml {
VideoRankFeatureExtractor::VideoRankFeatureExtractor() {
}

VideoRankFeatureExtractor::~VideoRankFeatureExtractor() {
}
// inline void ExtractFeatureVectorAppend(const reco::FeatureVector& fea_vec,
//                                        const std::string& prefix,
//                                        const std::string& sep,
//                                        int cut_size,
//                                        std::string* buf) {
//   if (fea_vec.feature_size() == 0) return;
//
//   *buf += "\n";
//   *buf += prefix;
//   int size = std::min(cut_size, fea_vec.feature_size());
//   for (int i = 0; i < size; ++i) {
//     if (i > 0) *buf += sep;
//     *buf += fea_vec.feature(i).literal();
//   }
// }
//
// inline void AddFea(const std::string& key, const std::string& value, std::string* buf) {
//   *buf += "\n";
//   *buf += key;
//   *buf += "=0:";
//   *buf += value;
// }
//

bool VideoRankFeatureExtractor::DoExtract(const reco::RecoItem& reco_item, std::string* video_fea) {
  if (reco_item.identity().type() < 30) return false;
  video_fea->clear();
  // id
  *video_fea += "item_id=0:";
  *video_fea += base::Uint64ToString(reco_item.identity().item_id());

  // tag
  if (reco_item.has_tag()) {
    const reco::FeatureVector& tag_fea = reco_item.tag();
    for (auto i = 0; i < tag_fea.feature_size(); ++i) {
      if (i == 0) {
        *video_fea += "\nitem_tags=0:";
      } else {
        *video_fea += "`";
      }

      const std::string& tag_str = tag_fea.feature(i).literal();
      size_t pos = tag_str.find(":");
      if (pos == std::string::npos) {
        *video_fea += tag_str;
      } else {
        const std::string& prefix = tag_str.substr(0, pos);
        if (prefix == "label" || prefix == "manual") {
          *video_fea += tag_str.substr(pos + 1);
        }
      }
    }
  }

  // category
  // if (reco_item.category_size() > 0) {
  //   *video_fea += "\nitem_category=0:";
  //   *video_fea += reco_item.category(0);
  // }

  // // source
  // if (reco_item.has_source()) {
  //   *video_fea += "\nitem_source=0:";
  //   *video_fea += reco_item.source();
  // }
  return true;
}
}
}
