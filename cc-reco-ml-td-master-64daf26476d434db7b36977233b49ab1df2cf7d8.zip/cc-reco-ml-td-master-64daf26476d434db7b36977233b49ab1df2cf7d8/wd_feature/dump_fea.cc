#include <string>
#include <vector>
#include <iostream>

#include "base/thread/thread_pool.h"
#include "base/thread/blocking_var.h"
#include "base/thread/blocking_queue.h"
#include "base/strings/string_number_conversions.h"
#include "reco/ml/wd_feature/factory.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"
#include "base/common/gflags.h"
#include "base/common/closure.h"
#include "serving_base/expiry_map/expiry_map.h"

DEFINE_int32(thread_num, 32, "");
DEFINE_string(extractor_name, "text_rank", "");
DEFINE_string(fea_file, "wd_feature.dat", "");

DEFINE_string(item_keeper_ips, "", "item keeper ips");
DEFINE_int32(item_keeper_port, 0, "");

static void DumpWorker(thread::BlockingQueue<std::pair<uint64, std::string> >* fea_queue) {
  std::pair<uint64, std::string> ele;
  std::ofstream fout(FLAGS_fea_file);
  while (not(fea_queue->Closed() && fea_queue->Empty())) {
    if (not fea_queue->Take(&ele)) break;

    reco::ml::WDFeatureExtractor::DumpRecord(ele.first, ele.second, &fout);
  }
  fout.close();
}

static void ExtractWorker(thread::BlockingQueue<uint64>* id_queue,
                          thread::BlockingQueue<std::pair<uint64, std::string> >* fea_queue,
                          thread::BlockingVar<int>* finish_num,
                          serving_base::ExpiryMap<uint64, int>* item_dict) {
  uint64 item_id = 0;
  reco::ml::WDFeatureExtractor* extractor = reco::ml::FeatureExtractorFactory::CreateExtractor(FLAGS_extractor_name);  // NOLINT
  std::string buf;
  extractor->Initialize(FLAGS_extractor_name + "_dump", "");
  reco::ItemKeeperGetItem get_item(FLAGS_item_keeper_ips, FLAGS_item_keeper_port);
  reco::RecoItem reco_item;
  while (not(id_queue->Closed() && id_queue->Empty())) {
    if (not id_queue->Take(&item_id)) break;
    int v;
    if (item_dict->FindSilently(item_id, &v)) continue;
    item_dict->Add(item_id, 1);
    // get reco_item
    reco_item.Clear();
    get_item.GetRecoItem(item_id, &reco_item);

    buf.clear();
    if (not extractor->DoExtract(reco_item, &buf)) {
      id_queue->Put(item_id);
    } else {
      fea_queue->Put(std::make_pair(item_id, buf));
    }
    // check parent
    uint64 parent_id = 0;
    if (reco_item.has_parent_id() &&
        not reco_item.parent_id().empty() &&
        base::StringToUint64(reco_item.parent_id(), &parent_id) &&
        not item_dict->FindSilently(parent_id, &v)) {
      id_queue->Put(parent_id);
      item_dict->Add(parent_id, 1);
    }

    LOG_EVERY_N(INFO, 10000) << "remian: " << id_queue->Size();
  }
  int n = finish_num->Take() + 1;
  if (n >= FLAGS_thread_num) {
    fea_queue->Close();
  }
  CHECK(finish_num->TryPut(n));
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "dump fea");
  thread::ThreadPool pool(FLAGS_thread_num + 1);
  thread::BlockingQueue<std::pair<uint64, std::string> > fea_queue;
  thread::BlockingQueue<uint64> id_queue;
  thread::BlockingVar<int> finish_num;
  CHECK(finish_num.TryPut(0));
  pool.AddTask(::NewCallback(DumpWorker, &fea_queue));
  serving_base::ExpiryMap<uint64, int> item_dict(24 * 3600);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(ExtractWorker, &id_queue, &fea_queue, &finish_num, &item_dict));
  }
  std::string line;
  while (getline(std::cin, line)) {
    uint64 item_id = 0;
    if (!base::StringToUint64(line, &item_id)) continue;
    id_queue.Put(item_id);
  }
  id_queue.Close();
  LOG(INFO) << "finish reading, remain id: " << id_queue.Size();
  pool.JoinAll();
  return 0;
}
