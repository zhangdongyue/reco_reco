#include "reco/ml/wd_feature/text_rank_feature_extractor.h"
#include <string>
#include <vector>
#include <algorithm>

#include "reco/bizc/proto/item.pb.h"
#include "reco/ml/model/doc_server_get_item.h"
#include "reco/ml/wd_feature/text_feature/item_feature.h"

namespace reco {
namespace ml {
TextRankFeatureExtractor::TextRankFeatureExtractor() {
  reco::ml::WDItemFeature::Instance().Init();
}

TextRankFeatureExtractor::~TextRankFeatureExtractor() {
}

inline void AddFea(const std::string& key, const std::string& value, std::string* buf) {
  *buf += key;
  *buf += "=0:";
  *buf += value;
}

bool TextRankFeatureExtractor::DoExtract(const reco::RecoItem& reco_item, std::string* text_fea) {
  if (reco_item.identity().type() > 29) {
    LOG_EVERY_N(ERROR, 100000) << "un supported type for texrank: " << reco_item.identity().item_id() << " " << reco_item.identity().type();  // NOLINT
    return false;
  }

  std::vector<reco::model_server::FeatureInfo> wd_feas;
  reco::ml::WDItemFeature::Instance().ExtractItemStaticFeaByRecoItem(reco_item, &wd_feas);
  text_fea->clear();
  for (size_t i = 0; i < wd_feas.size(); ++i) {
    if (i > 0) *text_fea += "\n";
    AddFea(wd_feas[i].literal(), wd_feas[i].text(), text_fea);
  }
  return true;
}
}
}
