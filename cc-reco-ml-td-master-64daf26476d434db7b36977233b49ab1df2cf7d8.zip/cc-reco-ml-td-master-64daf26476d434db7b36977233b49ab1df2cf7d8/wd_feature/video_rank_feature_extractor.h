#pragma once
#include <string>
#include "base/common/base.h"
#include "reco/ml/wd_feature/wd_feature_extractor.h"

namespace reco {
class RecoItem;
class HBaseGetItem;
namespace ml {
class VideoRankFeatureExtractor: public WDFeatureExtractor {
 public:
  // if u don't have any fea file, use empty str
  VideoRankFeatureExtractor();
  virtual ~VideoRankFeatureExtractor();

  bool DoExtract(const reco::RecoItem& reco_item, std::string* video_fea);
 private:

  DISALLOW_COPY_AND_ASSIGN(VideoRankFeatureExtractor);
};
}
}
