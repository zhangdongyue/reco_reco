#include <unordered_set>
#include <cmath>

#include "reco/ml/wd_feature/text_feature/feature.h"

DEFINE_bool(open_word_len, true, "");
DEFINE_bool(open_stop_word, false, "");

namespace reco {
namespace ml {

static bool Filter(const std::string& word, const std::unordered_set<std::string>& stop_words_dict) {
  if (FLAGS_open_word_len && word.size() <= 3) return true;
  if (FLAGS_open_stop_word && stop_words_dict.find(word) != stop_words_dict.end()) return true;
  return false;
}

static std::string ExtractItemFea(const reco::FeatureVector& tag, int num = 5) {
  int tag_size = std::min(num, tag.feature_size());
  std::string tags;
  for (int i = 0; i < tag_size; ++i) {
    if (tags.empty()) tags = tag.feature(i).literal();
    else tags += "," + tag.feature(i).literal();
  }

  return tags;
}

void GetItemIdFea(const std::string& item_id, std::vector<reco::model_server::FeatureInfo>* item_feas) {
  PushFea("item_id", item_id, item_feas);
}

void GetItemTagFea(const reco::RecoItem& reco_item, std::vector<reco::model_server::FeatureInfo>* item_feas) {
  if (!reco_item.has_tag()) return;
  std::string tags = ExtractItemFea(reco_item.tag());
  if (!tags.empty()) {
    PushFea("item_tag", tags, item_feas);
  }
}

void GetItemKeywordFea(const reco::RecoItem& reco_item, std::vector<reco::model_server::FeatureInfo>* item_feas) {
  if (!reco_item.has_keyword()) return;
  std::string keywords = ExtractItemFea(reco_item.keyword(), 10);
  if (!keywords.empty()) {
    PushFea("item_keywords", keywords, item_feas);
  }
}

void GetItemSemanticTagFea(const reco::RecoItem& reco_item, std::vector<reco::model_server::FeatureInfo>* item_feas) {
  if (!reco_item.has_semantic_tag()) return;
  std::string sem_tags = ExtractItemFea(reco_item.semantic_tag());
  if (!sem_tags.empty()) {
    PushFea("semantic_tag", sem_tags, item_feas);
  }
}

void GetItemTitleLdaFea(const reco::RecoItem& reco_item, std::vector<reco::model_server::FeatureInfo>* item_feas) {
  if (!reco_item.has_title_lda()) return;
  std::string title_lda = ExtractItemFea(reco_item.title_lda());
  if (!title_lda.empty()) {
    PushFea("title_lda", title_lda, item_feas);
  }
}

void GetItemPlsaTopicFea(const std::string& category, const reco::RecoItem& reco_item,
                         std::vector<reco::model_server::FeatureInfo>* item_feas) { 
  const reco::FeatureVector& plsa_topic = reco_item.plsa_topic();
  int plsa_topic_size = std::min(5, plsa_topic.feature_size());
  std::string cate_topics;
  for (int i = 0; i < plsa_topic_size; ++i) {
    if (cate_topics.empty())
      cate_topics = category + "_" + plsa_topic.feature(i).literal();
    else
      cate_topics += "," + category+ "_" + plsa_topic.feature(i).literal();
  }

  if (!cate_topics.empty()) {
    PushFea("item_plsa_topic", cate_topics, item_feas);
  }
  return;
}


void GetItemSourceFea(const std::string& category, const reco::RecoItem& reco_item,
                      std::vector<reco::model_server::FeatureInfo>* item_feas) { 
  // orgi_source_media ＞　orgi_source > source_media > source
  std::string source = "";
  if (reco_item.has_orig_source_media()) source = reco_item.orig_source_media();
  else if (reco_item.has_orig_source()) source = reco_item.orig_source();
  else if (reco_item.has_source_media()) source = reco_item.source_media();
  else if (reco_item.has_source()) source = reco_item.source();
  if (!source.empty()) {
    PushFea("source", source, item_feas);
    // source 在不同的源上点击率差别还是挺大的
    if (!category.empty()) PushFea("category_source", category + "_" + source, item_feas);
  }
}

void GetItemTypeFea(const reco::RecoItem& reco_item,
                    std::vector<reco::model_server::FeatureInfo>* item_feas) {
  // add item type
  int32 item_type = reco_item.identity().type();
  PushFea("item_type", base::IntToString(item_type), item_feas);
}

void GetItemSecondCategoryFea(const reco::RecoItem& reco_item,
                              std::vector<reco::model_server::FeatureInfo>* item_feas) {
  std::string second_category;
  if (reco_item.category_size() > 1) {
    second_category = reco_item.category(0) + "_" + reco_item.category(1);
    PushFea("second_category", second_category, item_feas);
  }
}

void GetItemTitleUniAndBigFea(const reco::RecoItem& reco_item,
                              const std::unordered_set<std::string>& stop_word_dict,
                           std::vector<reco::model_server::FeatureInfo>* item_feas) {
  if (reco_item.title_unigram_size() > 0) {
    std::string title_u, title_b, pre, cur;
    int size = std::min(50, reco_item.title_unigram_size());
    for (int i = 0; i < size; ++i) {
      cur = reco_item.title_unigram(i);
      if (Filter(cur, stop_word_dict)) continue;
      if (!pre.empty()) {
        if (!title_b.empty()) title_b = title_b + "," + pre + cur;
        else title_b = pre + cur;
      }
      pre = cur;
      if (title_u.empty()) title_u = cur;
      else title_u = title_u + "," + cur;
    }
    if (!title_u.empty()) PushFea("title_uni", title_u, item_feas);
    if (!title_b.empty()) PushFea("title_big", title_b, item_feas);
  }

}

void GetItemImageNumFea(const reco::RecoItem& reco_item,
                        std::vector<reco::model_server::FeatureInfo>* item_feas) {
  int image_num = reco_item.image_size();
  PushFea("image_num", base::IntToString(image_num), item_feas);
}

void GetItemNewTitleBigFea(const reco::RecoItem& reco_item,
                           std::vector<reco::model_server::FeatureInfo>* item_feas) {
  if (reco_item.title_unigram_size() > 0) {
    std::string title_b, pre, cur;
    int size = std::min(50, reco_item.title_unigram_size());
    for (int i = 0; i < size; ++i) {
      cur = reco_item.title_unigram(i);
      if (!pre.empty()) {
        if (!title_b.empty()) title_b = title_b + "," + pre + cur;
        else title_b = pre + cur;
      }
      pre = cur;
    }
    if (!title_b.empty()) PushFea("new_title_big", title_b, item_feas);
  }
}

void GetItemShowFea(const int64 show_num, std::vector<reco::model_server::FeatureInfo>* item_feas) {
  int show = kShowDefault;
  if (show_num > 0) show = (int)std::log(show_num);
  PushFea("show", base::IntToString(show), item_feas);
}

void GetItemCtrFea(const int64 show_num, const int64 click_num,
                   std::vector<reco::model_server::FeatureInfo>* item_feas) {

  // int32 ctr = kCtrDefault;
  // if (show_num > 0) {
  //   if (show_num < 1000 || click_num >= show_num) ctr = kCtrNotConfidence;
  //   else ctr = int(click_num * 1000.0 / show_num);
  // }
  int32 ctr = int(click_num * 1000.0 / (show_num + 1.0));
  PushFea("ctr", base::IntToString(ctr), item_feas);
}
}  // namespace ml
}  // namespace reco
