#pragma once

#include <unordered_map>
#include <utility>
#include <string>
#include <vector>
#include "base/common/gflags.h"
#include "reco/bizc/proto/reco_log.pb.h"
#include "reco/ml/wd_feature/text_feature/common.h"

namespace reco {
namespace ml {

// NOTE:
//   user fea 暂时先不迁移过来

// item fea
void GetItemIdFea(const std::string& item_id, std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemTagFea(const reco::RecoItem& reco_item, std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemKeywordFea(const reco::RecoItem& reco_item,
                       std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemSemanticTagFea(const reco::RecoItem& reco_item,
                           std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemTitleLdaFea(const reco::RecoItem& reco_item,
                        std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemPlsaTopicFea(const std::string& category, const reco::RecoItem& reco_item,
                         std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemSourceFea(const std::string& category, const reco::RecoItem& reco_item,
                      std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemTypeFea(const reco::RecoItem& reco_item,
                    std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemSecondCategoryFea(const reco::RecoItem& reco_item,
                              std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemTitleUniAndBigFea(const reco::RecoItem& reco_item,
                              const std::unordered_set<std::string>& stop_word_dict,
                              std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemImageNumFea(const reco::RecoItem& reco_item,
                     std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemNewTitleBigFea(const reco::RecoItem& reco_item,
                           std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemShowFea(const int64 show_num, std::vector<reco::model_server::FeatureInfo>* item_feas);
void GetItemCtrFea(const int64 show_num, const int64 click_num,
                   std::vector<reco::model_server::FeatureInfo>* item_feas);
}  // namespace ml
}  // namespace reco
