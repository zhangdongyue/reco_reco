#pragma once

#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <string>
#include <vector>

#include "reco/bizc/proto/reco_log.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/process/process_util.h"
#include "base/container/dense_hash_map.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"
#include "reco/bizc/proto/model_type.pb.h"

#include "common.h"

namespace reco {
namespace ml {

class WDUserFeature {
 public:
  static WDUserFeature& Instance() {
    static WDUserFeature instance_;
    return instance_;
  }
  ~WDUserFeature() {}

 public:
  void Init();

  void ExtractUserStaticFea(const reco::user::UserInfo& user_info,
                            std::vector<reco::model_server::FeatureInfo>* user_feas);
  void ExtractUserDynamicFea(const WDInfo& wd_info,
                             std::vector<reco::model_server::FeatureInfo>* user_feas);
  void ExtractUserDynamicFea(const reco::user::UserInfo& user_info,
                             std::vector<reco::model_server::FeatureInfo>* user_feas);

 private:
  void AddUserLdaFea(const std::unordered_set<std::string>& like_cates, const reco::user::Profile& profile,
                     std::vector<reco::model_server::FeatureInfo>* wd_feas);
  void AddUserTagFea(const std::unordered_set<std::string>& like_cates, const reco::user::Profile& profile,
                     std::vector<reco::model_server::FeatureInfo>* wd_feas);
  void AddUserPlsaTopicFea(const std::unordered_set<std::string>& like_cates, const reco::user::Profile& profile,
                     std::vector<reco::model_server::FeatureInfo>* wd_feas);
  bool LoadUserGroupFea();
 private:
  WDUserFeature() {}
  WDUserFeature(const WDUserFeature&);

 private:
  // 加载线下挖掘的用户人群
  std::unordered_map<uint64, std::vector<reco::model_server::FeatureInfo>> user_group_fea_;
  static bool has_init_;
};
}  // namespace ml
}  // namespace reco
