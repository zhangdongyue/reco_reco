#include <unordered_map>
#include <utility>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <fstream>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/encoding/line_escape.h"
#include "base/strings/string_printf.h"
#include "reco/bizc/proto/reco_log.pb.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/process/process_util.h"
#include "base/container/dense_hash_map.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"
#include "base/hash_function/city.h"
#include "base/file/file_util.h"

#include "user_feature.h"

DEFINE_int32(max_tag, 50, "");
DEFINE_int32(max_lda, 50, "");
DEFINE_int32(max_topic, 50, "");
DEFINE_string(user_group_fea_file, "", "");

namespace reco {
namespace ml {

bool WDUserFeature::has_init_ = false;

void WDUserFeature::Init() {
  if (!FLAGS_user_group_fea_file.empty()) {
    CHECK(LoadUserGroupFea()) << FLAGS_user_group_fea_file;
  }
  has_init_ = true;
}

bool WDUserFeature::LoadUserGroupFea() {
  LOG(INFO) << "start to load [" << FLAGS_user_group_fea_file << "]";
  std::vector<std::string> flds;
  base::file_util::ReadFileToLines(FLAGS_user_group_fea_file, &flds);
  std::unordered_map<uint64, std::string> dict;
  for (size_t idx = 0; idx < flds.size(); ++idx) {
    std::vector<std::string> split_line;
    base::TrimWhitespaces(&flds[idx]);
    base::SplitString(flds[idx], ",", &split_line);
    if (split_line.size() < 2u) continue;
    uint64 user_id = base::ParseUint64OrDie(split_line[0]);

    std::string ugf;
    for (size_t i = 1; i < split_line.size(); ++i) {
      const std::string& group_name = split_line[1];
      if (ugf.empty()) ugf = group_name;
      else ugf += "," + group_name;
    }

    if (dict[user_id].empty()) dict[user_id] = ugf;
    else dict[user_id] += "," + ugf;
  }

  for (auto item = dict.begin(); item != dict.end(); ++item) {
    std::vector<reco::model_server::FeatureInfo>& uf = user_group_fea_[item->first];
    PushFea("user_group", item->second, &uf);
    VLOG(1) << item->first << " " << item->second;
  }

  LOG(INFO) << "load suc : [" << FLAGS_user_group_fea_file
            << "] size : [" << user_group_fea_.size()
            << "]";

  return true;
}

void WDUserFeature::ExtractUserDynamicFea(const WDInfo& wd_info,
                                          std::vector<reco::model_server::FeatureInfo>* user_feas) {
  CHECK(has_init_) << "must recall init : " << has_init_;
  PushFea("channel_id", base::Uint64ToString(wd_info.channel_id), user_feas);
  PushFea("province", wd_info.province, user_feas);
  PushFea("city", wd_info.city, user_feas);

  if (wd_info.timestamp > 0) {
    int hour = GetIntHour(wd_info.timestamp);
    PushFea("hour", base::IntToString(hour), user_feas);

    std::string week;
    base::Time t = base::Time::FromDoubleT(wd_info.timestamp / base::Time::kMicrosecondsPerSecond);
    t.ToStringInFormat("%u", &week);
    PushFea("week", week, user_feas);
  }

  return;
}

void WDUserFeature::ExtractUserDynamicFea(const reco::user::UserInfo& user_info,
                                          std::vector<reco::model_server::FeatureInfo>* user_feas) {
  CHECK(has_init_) << "must recall init : " << has_init_;
  if (user_info.recent_click_size() <= 0) {
    LOG(INFO) << "user : " << user_info.identity().user_id() << " has no recent click items";
    return;
  }

  int size = user_info.recent_click_size();
  int64 timestamp = base::GetTimestamp() / base::Time::kMicrosecondsPerSecond;
  int num = 0;
  std::string user_click_history;
  for (int i = size - 1; i >= 0; --i) {
    // 类型过滤
    if (user_info.recent_click(i).item_type() >= 3) continue;
    int64 click_tm = user_info.recent_click(i).click_timestamp() / base::Time::kMicrosecondsPerSecond;
    if (timestamp - 3600 * 24 <= click_tm) {
      std::string str_item_id = base::Uint64ToString(user_info.recent_click(i).item_id());
      if (user_click_history.empty()) user_click_history = str_item_id;
      else user_click_history += "," + str_item_id;
      num += 1;
      if (num >= 50) break;
    }
  }

  if (!user_click_history.empty()) {
    PushFea("user_click_history", user_click_history, user_feas);
  }

  std::string cur_click;
  std::string pre_one_click;
  std::string pre_two_click;
  int64 cur_day = GetCurDay();
  int64 pre_one_day = GetPreDay(1);
  int64 pre_two_day = GetPreDay(2);
  int click_num[3] = {0};
  for (int i = size - 1; i >= 0; --i) {
    // 类型过滤
    if (user_info.recent_click(i).item_type() >= 3) continue;
    int64 click_tm = user_info.recent_click(i).click_timestamp() / base::Time::kMicrosecondsPerSecond;
    if (click_tm < pre_two_day) break;

    if (click_tm >= cur_day && click_tm < timestamp && click_num[0] < 20) {
      std::string str_item_id = base::Uint64ToString(user_info.recent_click(i).item_id());
      if (cur_click.empty()) cur_click = str_item_id;
      else cur_click += "," + str_item_id;
      click_num[0] += 1;
      continue;
    }

    if (click_tm >= pre_one_day && click_tm < cur_day && click_num[1] < 20) {
      std::string str_item_id = base::Uint64ToString(user_info.recent_click(i).item_id());
      if (pre_one_click.empty()) pre_one_click = str_item_id;
      else pre_one_click += "," + str_item_id;
      click_num[1] += 1;
      continue;
    }

    if (click_tm >= pre_two_day && click_tm < pre_one_day && click_num[2] < 20) {
      std::string str_item_id = base::Uint64ToString(user_info.recent_click(i).item_id());
      if (pre_two_click.empty()) pre_two_click = str_item_id;
      else pre_two_click += "," + str_item_id;
      click_num[2] += 1;
    }
  }

  if (!cur_click.empty()) PushFea("user_cur_click", cur_click, user_feas);
  if (!pre_one_click.empty()) PushFea("pre_one_click", pre_one_click, user_feas);
  if (!pre_two_click.empty()) PushFea("pre_two_click", pre_two_click, user_feas);

  return;
}

void WDUserFeature::AddUserLdaFea(const std::unordered_set<std::string>& like_cates,
                                  const reco::user::Profile& profile,
                                  std::vector<reco::model_server::FeatureInfo>* user_feas) {
  auto &title_lda = profile.title_lda_topic_feavec();
  int count = 0;
  std::string title_lda_fea;
  float norm_lda = 0.001;
  for (int i = 0; i < title_lda.feature_size() && count < FLAGS_max_lda; ++i) {
    auto &lda = title_lda.feature(i);
    ++count;
    norm_lda += lda.weight();
  }

  for (int i = 0; i < title_lda.feature_size() && i < FLAGS_max_lda; ++i) {
    auto &lda = title_lda.feature(i);
    int w = int(lda.weight() / norm_lda * count);
    std::string lda_str = lda.literal() + "_" + base::StringPrintf("%d", w);
    if (title_lda_fea.empty()) title_lda_fea = lda_str;
    else title_lda_fea = title_lda_fea + "," + lda_str;
  }

  if (!title_lda_fea.empty()) {
    PushFea("user_lda", title_lda_fea, user_feas);
  }

  return;
}

void WDUserFeature::ExtractUserStaticFea(const reco::user::UserInfo& user_info,
                                         std::vector<reco::model_server::FeatureInfo>* user_feas) {
  CHECK(has_init_) << "must recall init : " << has_init_;

  // userid 自身作为特征
  // 这段代码之前在 if 内部
  if (user_info.has_profile()
      && user_info.profile().has_category_feavec()
      && user_info.profile().has_tag_feavec()
      && user_info.profile().has_plsa_topic_feavec()) {
    // 选取权重最高的三个类别
    auto &category_feavec = user_info.profile().category_feavec();
    std::unordered_set<std::string> like_cates;
    for (int i = 0; i < category_feavec.feature_size() && i < 3; ++i) {
      like_cates.insert(category_feavec.feature(i).literal().category());
    }
    PushFea("user_id", base::Uint64ToString(user_info.identity().user_id()), user_feas);
    // 加入 usertag
    AddUserTagFea(like_cates, user_info.profile(), user_feas);
    // 加入 user lda
    AddUserLdaFea(like_cates, user_info.profile(), user_feas);
    // 加入 userplsatopic
    AddUserPlsaTopicFea(like_cates, user_info.profile(), user_feas);
  }

  if (user_info.has_ali_profile()) {
    const reco::user::AliProfile& ali_profile = user_info.ali_profile();
    if (ali_profile.has_gp_age()) PushFea("age", base::IntToString(ali_profile.gp_age()), user_feas);
    if (ali_profile.has_gp_gender()) {
      if (ali_profile.gp_gender() == "M") PushFea("sex", "0", user_feas);
      else PushFea("sex", "1", user_feas);
    }
  }

  if (!FLAGS_user_group_fea_file.empty()) {
    uint64 user_id = user_info.identity().user_id();
    auto find = user_group_fea_.find(user_id);
    if (find != user_group_fea_.end()) {
      user_feas->insert(user_feas->end(), find->second.begin(), find->second.end());
    }
  }

  return;
}

void WDUserFeature::AddUserTagFea(const std::unordered_set<std::string>& like_cates,
                                const reco::user::Profile& profile,
                                std::vector<reco::model_server::FeatureInfo>* user_feas) {
  if (like_cates.empty()) return;
  auto &tag_vec = profile.tag_feavec();
  int count = 0;
  std::string tag_fea;
  std::unordered_map<std::string, std::vector<reco::Feature>> cate_tags;
  for (int i = 0; i < tag_vec.feature_size() && count < FLAGS_max_tag; ++i) {
    auto &tag = tag_vec.feature(i);
    if (!tag.has_category() || like_cates.find(tag.category()) == like_cates.end()) {
      continue;
    }
    cate_tags[tag.category()].push_back(tag);
    ++count;
  }

  // user tag fea
  std::unordered_map<std::string, std::vector<reco::Feature> >::iterator it;
  for (it = cate_tags.begin(); it != cate_tags.end(); ++it) {
    std::vector<reco::Feature>::iterator fea_it;
    float norm_tag = 0.001;
    for (fea_it = it->second.begin(); fea_it != it->second.end(); ++fea_it) {
      norm_tag += fea_it->weight();
    }

    for (fea_it = it->second.begin(); fea_it != it->second.end(); ++fea_it) {
      std::string tag = fea_it->literal();
      int w = int(fea_it->weight() / norm_tag * count);
      std::string tag_str = tag + "_" + base::StringPrintf("%d", w);
      if (tag_fea.empty()) tag_fea = tag_str;
      else tag_fea = tag_fea + "," + tag_str;
    }
  }

  if (!tag_fea.empty()) {
    PushFea("user_tag", tag_fea, user_feas);
  }

  return;
}

void WDUserFeature::AddUserPlsaTopicFea(const std::unordered_set<std::string>& like_cates,
                                      const reco::user::Profile& profile,
                                      std::vector<reco::model_server::FeatureInfo>* user_feas) {
  if (like_cates.empty()) return;
  // topics of user-like cates
  auto &topic_vec = profile.plsa_topic_feavec();
  std::unordered_map<std::string, std::vector<reco::Feature> > cate_topics;
  int count = 0;
  std::string topic_fea;
  for (int i = 0; i < topic_vec.feature_size() && count < FLAGS_max_topic; ++i) { // top text topic
    auto &topic = topic_vec.feature(i);
    if (!topic.has_category() || like_cates.find(topic.category()) == like_cates.end()) {
      continue;
    }
    cate_topics[topic.category()].push_back(topic);
    ++count;
  }

  // user topic fea
  std::unordered_map<std::string, std::vector<reco::Feature> >::iterator it;
  for (it = cate_topics.begin(); it != cate_topics.end(); ++it) {
    std::vector<reco::Feature>::iterator fea_it;
    float norm_topic = 0.001;
    for (fea_it = it->second.begin(); fea_it != it->second.end(); ++fea_it) {
      norm_topic += fea_it->weight();
    }

    std::string cate = it->first;
    for (fea_it = it->second.begin(); fea_it != it->second.end(); ++fea_it) {
      int w = int(fea_it->weight() / norm_topic * count);
      std::string  topic = fea_it->literal();
      std::string topic_str = cate + "_" + topic + "_" + base::StringPrintf("%d", w);
      if (topic_fea.empty()) topic_fea = topic_str;
      else topic_fea = topic_fea + "," + topic_str;
    }
  }

  if (!topic_fea.empty()) {
    PushFea("user_topic", topic_fea, user_feas);
  }

  return;
}
}  // namespace ml
}  // namespace reco
