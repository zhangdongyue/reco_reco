#include <unordered_map>
#include <utility>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <fstream>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/encoding/line_escape.h"
#include "base/strings/string_printf.h"
#include "reco/bizc/proto/reco_log.pb.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "base/strings/string_number_conversions.h"
// #include "reco/bizc/ml/news_index.h"
#include "base/file/file_util.h"

#include "reco/ml/wd_feature/text_feature/item_feature.h"
#include "reco/ml/wd_feature/text_feature/common.h"

DEFINE_string(stop_words_file, "", "");

namespace reco {
namespace ml {

bool WDItemFeature::has_init_ = false;

void WDItemFeature::LoadStopWords() {
  if (!FLAGS_stop_words_file.empty()) {
    std::vector<std::string> flds;
    base::file_util::ReadFileToLines(FLAGS_stop_words_file, &flds);
    for (size_t i = 0; i < flds.size(); ++i) {
      stop_words_dict_.insert(flds[i]);
    }
    LOG(INFO) << "load stop words : " << stop_words_dict_.size();
  }
}

void WDItemFeature::ExtractItemStaticFeaByRecoItem(const reco::RecoItem& reco_item,
                                                   std::vector<reco::model_server::FeatureInfo>* item_feas) {
  CHECK(has_init_);

  if (reco_item.category_size() <= 0) return;
  std::string category = "";
  category = reco_item.category(0);

  // item id
  GetItemIdFea(base::Uint64ToString(reco_item.identity().item_id()), item_feas);
  // item tag
  GetItemTagFea(reco_item, item_feas);
  // cate plsa topic
  GetItemPlsaTopicFea(category, reco_item, item_feas);
  // source
  GetItemSourceFea(category, reco_item, item_feas);
  // add item type
  GetItemTypeFea(reco_item, item_feas);
  // second category
  GetItemSecondCategoryFea(reco_item, item_feas);
  // title uni and big
  GetItemTitleUniAndBigFea(reco_item, stop_words_dict_, item_feas);
  // iamge num
  GetItemImageNumFea(reco_item, item_feas);
  // semantic tag
  GetItemSemanticTagFea(reco_item, item_feas);
  // title lda
  GetItemTitleLdaFea(reco_item, item_feas);
  // new title big
  GetItemNewTitleBigFea(reco_item, item_feas);
  // item keyword
  GetItemKeywordFea(reco_item, item_feas);

  return;
}

void WDItemFeature::ExtractItemStaticFeaByMetaUpdater(const WDInfo& wd_info,
                                                      std::vector<reco::model_server::FeatureInfo>* item_feas) {
  CHECK(has_init_);
  if (meta_info_updator_ == NULL) return;

  reco::MetaInfo meta_info;
  uint64 item_id = wd_info.item_id;
  meta_info_updator_->GetMetaInfo(item_id, &meta_info);
  PushFea("site_level", base::IntToString(meta_info.site_level), item_feas);
  // TODO(ye.wangy1):media level 线下使用的话需要加载词表
  // PushFea("media_level", base::IntToString(meta_info.media_level), item_feas);

  return;
}

// void WDItemFeature::ExtractItemDynamicFeaByIndex(const WDInfo& wd_info,
//                                                  std::vector<reco::model_server::FeatureInfo>* item_feas) {
//   CHECK(has_init_);
// 
//   reco::ItemInfo item_info;
//   if (!news_index_->GetItemInfoByItemId(wd_info.item_id, &item_info, false)) return;
// 
//   GetItemCtrFea(item_info.show_num, item_info.click_num, item_feas);
//   GetItemShowFea(item_info.show_num, item_feas);
// 
//   return;
// }

void WDItemFeature::ExtractItemDynamicFeaByExternal(const WDInfo& wd_info,
                                                    std::vector<reco::model_server::FeatureInfo>* item_feas) {
  CHECK(has_init_);

  GetItemCtrFea(wd_info.show_num, wd_info.click_num, item_feas);
  GetItemShowFea(wd_info.show_num, item_feas);

  return;
}
}  // namespace ml
}  // namespace reco
