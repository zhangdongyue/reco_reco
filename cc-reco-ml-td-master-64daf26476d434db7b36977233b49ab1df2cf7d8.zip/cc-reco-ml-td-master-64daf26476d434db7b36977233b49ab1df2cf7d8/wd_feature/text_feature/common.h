#pragma once

#include <string>

#include "reco/bizc/proto/model_type.pb.h"
#include "base/common/base.h"
#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace ml {

enum {
  kCtrDefault = -2,
  // 设置了，但 show_num 不置信
  kCtrNotConfidence = -1,
  kShowDefault = -1
};

struct WDInfo {
  WDInfo() {
    province = "UnKnown";
    city = "UnKnown";
    channel_id = 0;
    item_id = 0;
    user_id = 0;
    label = 0;
    show_num = 0;
    click_num = 0;
    timestamp = 0;
  }
  std::string province;
  std::string city;
  int32 channel_id;
  uint64 item_id;
  uint64 user_id;
  int32 label;
  int64 show_num;
  int64 click_num;
  int64 timestamp;
};

void AddFea(const std::string& literal, const std::string& text, reco::model_server::FeatureInfo* info);
void PushFea(const std::string& literal, const std::string& text,
             std::vector<reco::model_server::FeatureInfo>* feas);
std::string GetStrHour(const int64 timestamp);
int32 GetIntHour(const int64 timestamp);

// 单位是 s
uint64 GetCurDay();
// 往前数 pre_num 天，单位 s
uint64 GetPreDay(int32 pre_num = 1);
}  // namespace ml
}  // namespace reco
