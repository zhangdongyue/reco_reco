#pragma once

#include <unordered_map>
#include <utility>
#include <string>
#include <vector>

#include "reco/bizc/proto/reco_log.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "base/hash_function/city.h"
#include "reco/bizc/proto/model_type.pb.h"
#include "reco/ml/wd_feature/text_feature/common.h"
#include "reco/bizc/meta_info/light_meta_info_updator.h"

#include "feature.h"

namespace reco {
class NewsIndex;
class SortItem;

namespace ml {

class WDItemFeature {
 public:
  static WDItemFeature& Instance() {
    static WDItemFeature instance_;
    return instance_;
  }

  void Init(const reco::NewsIndex* news_index = NULL,
            reco::LightMetaInfoUpdator* meta_info_updator = NULL) {
    // news_index_ = news_index;
    meta_info_updator_ = meta_info_updator;

    LoadStopWords();

    has_init_ = true;
  }
  ~WDItemFeature() {}

  void ExtractItemDynamicFeaByIndex(const WDInfo& wd_info,
                                    std::vector<reco::model_server::FeatureInfo>* item_feas);

  // 通过外部数据导入相关特征
  void ExtractItemDynamicFeaByExternal(const WDInfo& wd_info,
                                       std::vector<reco::model_server::FeatureInfo>* item_feas);

  void ExtractItemStaticFeaByMetaUpdater(const WDInfo& wd_info,
                                                      std::vector<reco::model_server::FeatureInfo>* item_feas);

  void ExtractItemStaticFeaByRecoItem(const reco::RecoItem& reco_item,
                                      std::vector<reco::model_server::FeatureInfo>* item_feas);
 private:
  WDItemFeature() {}
  WDItemFeature(const WDItemFeature&);

 private:
  void LoadStopWords();

 private:
  // const reco::NewsIndex* news_index_;
  reco::LightMetaInfoUpdator* meta_info_updator_;
  std::unordered_set<std::string> stop_words_dict_;
  static bool has_init_;
};
}  // namespace ml
}  // namespace reco
