#include <string>
#include "common.h"
#include "serving_base/utility/time_helper.h"

namespace reco {
namespace ml {

void AddFea(const std::string& literal, const std::string& text, reco::model_server::FeatureInfo* info) {
  info->set_literal(literal);
  info->set_text(text);
}

void PushFea(const std::string& literal, const std::string& text,
             std::vector<reco::model_server::FeatureInfo>* feas) {
  feas->push_back(reco::model_server::FeatureInfo());
  reco::model_server::FeatureInfo* info = &feas->back();
  AddFea(literal, text, info);
}

std::string GetStrHour(const int64 timestamp) {
  base::Time t = base::Time::FromDoubleT(timestamp / base::Time::kMicrosecondsPerSecond);
  std::string str;
  t.ToStringInFormat("%H", &str);
  return str;
}

int32 GetIntHour(const int64 timestamp) {
  std::string str = GetStrHour(timestamp);
  int num = 0;
  while (num < (int)str.size() && str[num] == '0') ++num;
  if (num == int(str.size())) return 0;
  int h = base::ParseInt32OrDie(str.c_str() + num);
  return h;
}

uint64 GetCurDay() {
  uint64 tm = base::GetTimestamp();
  std::string str_tm;
  serving_base::TimeHelper::TimestampToString(tm, serving_base::TimeHelper::kDay, &str_tm);
  uint64 new_tm = 0;
  serving_base::TimeHelper::StringToTimestamp(str_tm, serving_base::TimeHelper::kDay, &new_tm);
  return new_tm / 1000000;
}

uint64 GetPreDay(int32 pre_num) {
  uint64 tm = base::GetTimestamp();
  tm = tm - 3600 * 24 * 1000000L * pre_num;
  std::string str_tm;
  serving_base::TimeHelper::TimestampToString(tm, serving_base::TimeHelper::kDay, &str_tm);
  uint64 new_tm = 0;
  serving_base::TimeHelper::StringToTimestamp(str_tm, serving_base::TimeHelper::kDay, &new_tm);
  return new_tm / 1000000;
}
}  // namespace ml
}  // namespace reco
