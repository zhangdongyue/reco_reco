#pragma once
#include <string>
#include "base/common/base.h"
#include "reco/ml/wd_feature/wd_feature_extractor.h"
namespace reco {
class RecoItem;
class DocServerGetItem;
namespace ml {
class TextRankFeatureExtractor: public WDFeatureExtractor {
 public:
  // if u don't have any fea file, use empty str
  TextRankFeatureExtractor();
  virtual ~TextRankFeatureExtractor();

  bool DoExtract(const reco::RecoItem& reco_item, std::string* fea);
 private:

  DISALLOW_COPY_AND_ASSIGN(TextRankFeatureExtractor);
};
}
}
