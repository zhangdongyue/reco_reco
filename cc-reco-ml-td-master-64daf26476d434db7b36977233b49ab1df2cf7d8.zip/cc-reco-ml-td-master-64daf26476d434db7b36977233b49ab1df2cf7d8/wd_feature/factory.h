#pragma once

#include <string>

#include "base/common/base.h"
#include "base/common/logging.h"

#include "reco/ml/wd_feature/text_rank_feature_extractor.h"
#include "reco/ml/wd_feature/video_rank_feature_extractor.h"

#define BEGIN_REGISTER_EXTRACTOR() \
namespace reco { \
namespace ml { \
class FeatureExtractorFactory { \
  public: \
  static reco::ml::WDFeatureExtractor* CreateExtractor(const std::string& name) { \
    if (name.empty()) { \
      return NULL; \
    }

#define REGISTER_EXTRACTOR(NAME, CLASS) \
    if (name == (NAME)) { \
      LOG(INFO) << "New Extractor! extractor:" << (NAME); \
      return new (CLASS); \
    }

#define END_REGISTER_EXTRACTOR() \
    LOG(ERROR) << "error! invalid extractor:" << (name); \
    return NULL; \
  } \
}; \
} \
}

BEGIN_REGISTER_EXTRACTOR()
REGISTER_EXTRACTOR("text_rank", reco::ml::TextRankFeatureExtractor)
REGISTER_EXTRACTOR("video_rank", reco::ml::VideoRankFeatureExtractor)
END_REGISTER_EXTRACTOR()
