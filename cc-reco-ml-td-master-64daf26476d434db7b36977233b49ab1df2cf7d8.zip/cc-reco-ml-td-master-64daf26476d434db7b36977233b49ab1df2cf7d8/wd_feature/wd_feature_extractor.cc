#include "reco/ml/wd_feature/wd_feature_extractor.h"
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>

#include "reco/ml/model/doc_server_get_item.h"
#include "reco/bizc/proto/item.pb.h"
#include "base/encoding/line_escape.h"
#include "base/strings/string_split.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/time/time.h"
#include "serving_base/utility/timer.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"

DEFINE_int32(fea_thread, 6, "thread num for extract fea");
DEFINE_int32(fea_dump_interval, 3600, "interval for dump fea");
DEFINE_int32(fea_check_interval, 5, "interval for dump fea");
DEFINE_int32(single_cache_size, 100000, "single cache size");

DEFINE_int32(doc_server_port, 20013, "");
DEFINE_string(doc_server_ips, "11.251.203.139", "");

namespace reco {
namespace ml {
static uint32 kCacheNum = 32;
inline uint32 get_idx(uint64 n, uint32 s) {
  return n & (s - 1);
}

bool WDFeatureExtractor::Initialize(const std::string& name,
                                    const std::string& fea_file) {
  name_ = name;
  stop_ = false;
    // TODO(xielang): 考虑把 三天 内的有效新闻先加载进来
  miss_item_queue_ = new thread::BlockingQueue<uint64>();
  item_fea_cache_.resize(kCacheNum);
  for (size_t i = 0; i < item_fea_cache_.size(); ++i) {
    item_fea_cache_[i] = new base::LRUCache<uint64, std::shared_ptr<std::string> >(FLAGS_single_cache_size, true);  // NOLINT
  }
  fea_thread_pool_ = new thread::ThreadPool(FLAGS_fea_thread + 1);
  if (not fea_file.empty()) {
    // preload fea
    fea_file_ = fea_file;
    LoadItemFea(base::FilePath(fea_file));
    // dump fea file thread
    fea_thread_pool_->AddTask(::NewCallback(this, &WDFeatureExtractor::CacheDump, FLAGS_fea_dump_interval));

    for (int i = 0; i < FLAGS_fea_thread; ++i) {
      fea_thread_pool_->AddTask(::NewCallback(this, &WDFeatureExtractor::CacheWriter));
    }
  }

  failed_cache_ = new base::LRUCache<uint64, int>(10000, true);
  get_item_service_ = new reco::DocServerGetItem(FLAGS_doc_server_ips, FLAGS_doc_server_port);
  return true;
}

bool WDFeatureExtractor::DoExtract(uint64 item_id, std::string* text_fea) {
  reco::RecoItem reco_item;
  if (!get_item_service_->GetRecoItem(item_id, &reco_item)) {
    LOG(ERROR) << "get reco item failed: " << item_id;
    return false;
  }
  return DoExtract(reco_item, text_fea);
}

bool WDFeatureExtractor::ExtractFea(uint64 item_id, bool use_cache, std::string* fea_str) {
  if (item_id < 100000) return false;

  std::shared_ptr<std::string> fea_ptr;
  uint32 idx = get_idx(item_id, item_fea_cache_.size());
  if (use_cache && item_fea_cache_[idx]->Get(item_id, &fea_ptr)) {
    *fea_str = *fea_ptr;
    return true;
  } else if (use_cache) {
    if (not failed_cache_->Exists(item_id)) {
      miss_item_queue_->Put(item_id);
      failed_cache_->Add(item_id, 1);
    }
    return false;
  }
  bool succ = DoExtract(item_id, fea_str);
  if (!succ) {
    failed_cache_->Add(item_id, 1);
  }
  return succ;
}

void WDFeatureExtractor::CacheWriter() {
  uint64 item_id;
  std::string buf;
  std::shared_ptr<std::string> fea_ptr;
  while (!stop_ && !(miss_item_queue_->Closed() && miss_item_queue_->Empty())) {
    if (!miss_item_queue_->Take(&item_id)) break;
    uint32 idx = get_idx(item_id, item_fea_cache_.size());
    if (item_fea_cache_[idx]->Get(item_id, &fea_ptr)) continue;

    buf.clear();
    if (DoExtract(item_id, &buf)) {
      item_fea_cache_[idx]->Add(item_id, std::make_shared<std::string>(buf));
    } else {
      // miss_item_queue_->Put(item_id);
    }
    LOG_EVERY_N(INFO, 10000) << "fea queue: " << miss_item_queue_->Size();
  }
  LOG(ERROR) << "finish writing cache thread";
}

bool WDFeatureExtractor::DumpAllFea() {
  // do dump
  std::string tmp_file = fea_file_ + ".tmp";
  int record_num = 0;
  std::ofstream fout(tmp_file);
  std::vector<uint64> keys;
  std::vector<std::shared_ptr<std::string> > values;
  std::vector<bool> fetch_infos;
  keys.reserve(FLAGS_single_cache_size);
  uint32 key_num = 0;
  for (size_t idx = 0; idx < item_fea_cache_.size(); ++idx) {
    keys.clear();
    item_fea_cache_[idx]->GetAllKeys(&keys);
    values.resize(keys.size());
    fetch_infos.resize(keys.size());
    item_fea_cache_[idx]->BatchGet(keys, &values, &fetch_infos);
    for (size_t i = 0; i < keys.size(); ++i) {
      if (not fetch_infos[i]) continue;
      DumpRecord(keys[i], *(values[i]), &fout);
      ++record_num;
    }
    key_num += keys.size();
  }
  if (record_num < 1000) {
    LOG(WARNING) << "too less fea in cache, skip for dump " << record_num << " "  << name_;
    return false;
  } else {
    base::FilePath path(tmp_file);
    base::FilePath path2(fea_file_);
    base::file_util::Move(path, path2);
    LOG(INFO) << "save fea file " << fea_file_ << " reordnum " << record_num << " keynum: " << key_num;
    return true;
  }
}

void WDFeatureExtractor::CacheDump(int interval_in_second) {
  if (fea_file_.empty()) {
    LOG(INFO) << "empty fea file for " << name_;
    return;
  }

  std::string time_str;
  base::Time last_time = base::Time::Now();

  while (!stop_) {
    base::Time current_time = base::Time::Now();
    base::TimeDelta time_delta = current_time - last_time;
    if (time_delta.InSeconds() > interval_in_second) {
      DumpAllFea();
      last_time = base::Time::Now();
    }
    base::SleepForSeconds(FLAGS_fea_check_interval);
  }
}

bool WDFeatureExtractor::LoadItemFea(const base::FilePath& path) {
  // load sim data
  if (!base::file_util::PathExists(path)) {
    LOG(ERROR) << " matrix file none exist! " << path.value();
    return false;
  }

  base::file_util::MemoryMappedFile file;
  CHECK(file.Initialize(path.value()));

  auto data = file.data();
  auto data_end = data + file.size();
  int record_num = 0;
  serving_base::Timer timer;
  timer.Start();
  std::string buf;
  while (data < data_end) {
    uint64 item_id = *reinterpret_cast<const uint64*>(data);
    data += sizeof(uint64);
    int size = *reinterpret_cast<const int *>(data);
    data += sizeof(int);
    const char* p = reinterpret_cast<const char*>(data);
    data += size;
    if (size > 100000 or size < 0) {
      LOG(WARNING) << "maybe erro record. " << size;
      continue;
    }
    uint32 idx = get_idx(item_id, item_fea_cache_.size());
    if (item_fea_cache_[idx]->Exists(item_id)) {
      continue;
    }
    ++record_num;
    buf.assign(p, size);
    item_fea_cache_[idx]->Add(item_id, std::make_shared<std::string>(buf));
  }
  CHECK_EQ(data, data_end);
  LOG(INFO) << "load item num : " << record_num << " spend s:" << timer.Stop() / 1e6 << " " << path.value();
  return true;
}
}
}
