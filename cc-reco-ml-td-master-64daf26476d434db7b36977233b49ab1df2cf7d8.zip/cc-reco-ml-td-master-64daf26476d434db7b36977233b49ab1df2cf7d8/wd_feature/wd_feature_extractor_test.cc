#include <string>
#include <limits>
#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/file/file_util.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "serving_base/utility/timer.h"
#include "base/common/sleep.h"

#include "reco/ml/wd_feature/factory.h"

DEFINE_string(test_case, "wd_fea_test", "test case for wd fea");

DECLARE_int32(fea_dump_interval);
namespace reco {
namespace hbase {
DECLARE_string(hbase_thrift_ips);
DECLARE_int32(hbase_pool_size);
}
namespace ml {
class WDFeatureExtractorTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    FLAGS_fea_dump_interval = 5;
  }

  virtual void TearDown() {
  }
};

static void Save(const std::vector<std::pair<uint64, std::string> >& feas, const base::FilePath& path) {
  std::ofstream fout(path.value());
  for (int i = 0; i < (int)feas.size(); ++i) {
    WDFeatureExtractor::DumpRecord(feas[i].first, feas[i].second, &fout);
  }
  fout.close();
  LOG(INFO) << "save: " << feas.size();
}

TEST_F(WDFeatureExtractorTest, TestTextFea) {
  WDFeatureExtractor* extractor = FeatureExtractorFactory::CreateExtractor("text_rank");
  extractor->Initialize("test_video_test", "");

  std::ifstream fin(FLAGS_test_case);
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_test_case), &lines));
  int load_num = lines.size() / 2;
  int uncache_num = lines.size() - load_num;
  std::vector<std::pair<uint64, std::string> > cache_feas;
  std::vector<std::pair<uint64, std::string> > un_cache_feas;
  cache_feas.reserve(load_num);
  un_cache_feas.reserve(uncache_num);

  serving_base::Timer timer;
  timer.Start();
  std::vector<std::string> tokens;
  for (int i = 0; i < (int)lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    CHECK_EQ(tokens.size(), 2u);
    uint64 item_id = base::ParseUint64OrDie(tokens[0]);
    int item_type = base::ParseIntOrDie(tokens[1]);
    if (item_type > 4) continue;

    if (i < load_num) {
      cache_feas.push_back(std::make_pair(item_id, ""));
      ASSERT_TRUE(extractor->DoExtract(item_id, &(cache_feas.back().second))) << item_id;
    } else {
      un_cache_feas.push_back(std::make_pair(item_id, ""));
      ASSERT_TRUE(extractor->DoExtract(item_id, &(un_cache_feas.back().second))) << item_id;
    }
  }
  LOG(INFO) << "extract all; spend ms: " << timer.Interval() / 1000;
  base::FilePath text_path("./text_fea.tmp");
  Save(cache_feas, text_path);

  // test preload
  WDFeatureExtractor* extractor2 = FeatureExtractorFactory::CreateExtractor("text_rank");
  extractor2->Initialize("extractor2", text_path.value());
  std::string fea_str;
  for (int i = 0; i < (int)cache_feas.size(); ++i) {
    ASSERT_TRUE(extractor2->ExtractFea(cache_feas[i].first, true, &fea_str)) << cache_feas[i].first;
    ASSERT_EQ(fea_str, cache_feas[i].second);
  }
  int ms = timer.Interval() / 1000;
  LOG(INFO) << "extract by preload cache spend ms: " << ms;

  for (int i = 0; i < (int)un_cache_feas.size(); ++i) {
    ASSERT_TRUE(not extractor2->ExtractFea(un_cache_feas[i].first, true, &fea_str)) << un_cache_feas[i].first;
    // ASSERT_EQ(fea_str, un_cache_feas[i].second);
  }
  LOG(INFO) << "extract and write to cache; spend ms: " << timer.Interval() / 1000;

  for (int i = 0; i < (int)un_cache_feas.size(); ++i) {
    ASSERT_TRUE(extractor2->ExtractFea(un_cache_feas[i].first, false, &fea_str)) << un_cache_feas[i].first;
    ASSERT_EQ(fea_str, un_cache_feas[i].second);
  }
  LOG(INFO) << "extract uncache spend ms: " << timer.Interval() / 1000;

  while (extractor2->cache_queue_size() > 0) {
    base::SleepForSeconds(1);
  }
  int failed_num = 0;
  for (int i = 0; i < (int)un_cache_feas.size(); ++i) {
    ASSERT_TRUE(extractor2->ExtractFea(un_cache_feas[i].first, true, &fea_str));
    ASSERT_EQ(fea_str, un_cache_feas[i].second);
  }
  LOG(INFO) << "extract by dynamic cache spend ms: " << timer.Interval() / 1000;

  // test dump
  base::SleepForSeconds(10);
  WDFeatureExtractor* extractor3 = FeatureExtractorFactory::CreateExtractor("text_rank");
  extractor3->Initialize("extractor3", text_path.value());
  for (int i = 0; i < (int)un_cache_feas.size(); ++i) {
    ASSERT_TRUE(extractor3->ExtractFea(un_cache_feas[i].first, true, &fea_str));
    ASSERT_EQ(fea_str, un_cache_feas[i].second);
  }

  for (int i = 0; i < (int)cache_feas.size(); ++i) {
    if (not extractor3->ExtractFea(cache_feas[i].first, true, &fea_str)) {
      LOG(ERROR) << "failed to get " << cache_feas[i].first;
      ++failed_num;
      continue;
    }
    ASSERT_EQ(fea_str, cache_feas[i].second);
  }
  LOG(INFO) << "failed ration: " << static_cast<float>(failed_num) / cache_feas.size();
}

TEST_F(WDFeatureExtractorTest, TestVideoFea) {
  WDFeatureExtractor* extractor = FeatureExtractorFactory::CreateExtractor("video_rank");
  extractor->Initialize("extractor", "");
  std::ifstream fin(FLAGS_test_case);
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(base::FilePath(FLAGS_test_case), &lines));
  int load_num = lines.size() / 2;
  int uncache_num = lines.size() - load_num;
  std::vector<std::pair<uint64, std::string> > cache_feas;
  std::vector<std::pair<uint64, std::string> > un_cache_feas;
  cache_feas.reserve(load_num);
  un_cache_feas.reserve(uncache_num);

  serving_base::Timer timer;
  timer.Start();
  std::vector<std::string> tokens;
  for (int i = 0; i < (int)lines.size(); ++i) {
    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    CHECK_EQ(tokens.size(), 2u);
    uint64 item_id = base::ParseUint64OrDie(tokens[0]);
    int item_type = base::ParseIntOrDie(tokens[1]);
    if (item_type != 30) continue;

    if (i < load_num) {
      cache_feas.push_back(std::make_pair(item_id, ""));
      ASSERT_TRUE(extractor->DoExtract(item_id, &(cache_feas.back().second))) << item_id;
    } else {
      un_cache_feas.push_back(std::make_pair(item_id, ""));
      ASSERT_TRUE(extractor->DoExtract(item_id, &(un_cache_feas.back().second))) << item_id;
    }
  }
  LOG(INFO) << "extract all; spend ms: " << timer.Interval() / 1000;
  base::FilePath video_path("./video_fea.tmp");
  Save(cache_feas, video_path);

  // test preload
  WDFeatureExtractor* extractor2 = FeatureExtractorFactory::CreateExtractor("video_rank");
  extractor2->Initialize("extractor2", video_path.value());

  std::string fea_str;
  for (int i = 0; i < (int)cache_feas.size(); ++i) {
    ASSERT_TRUE(extractor2->ExtractFea(cache_feas[i].first, true, &fea_str)) << cache_feas[i].first;
    ASSERT_EQ(fea_str, cache_feas[i].second);
  }
  int ms = timer.Interval() / 1000;
  LOG(INFO) << "extract by preload cache spend ms: " << ms;

  for (int i = 0; i < (int)un_cache_feas.size(); ++i) {
    ASSERT_TRUE(not extractor2->ExtractFea(un_cache_feas[i].first, true, &fea_str)) << un_cache_feas[i].first;
    // ASSERT_EQ(fea_str, un_cache_feas[i].second);
  }
  LOG(INFO) << "extract and write to cache; spend ms: " << timer.Interval() / 1000;

  for (int i = 0; i < (int)un_cache_feas.size(); ++i) {
    ASSERT_TRUE(extractor2->ExtractFea(un_cache_feas[i].first, false, &fea_str)) << un_cache_feas[i].first;
    ASSERT_EQ(fea_str, un_cache_feas[i].second);
  }
  LOG(INFO) << "extract uncache spend ms: " << timer.Interval() / 1000;

  while (extractor2->cache_queue_size() > 0) {
    base::SleepForSeconds(1);
  }

  int failed_num = 0;
  for (int i = 0; i < (int)un_cache_feas.size(); ++i) {
    if (not extractor2->ExtractFea(un_cache_feas[i].first, true, &fea_str)) {
      LOG(ERROR) << "failed to get " << un_cache_feas[i].first;
      ++failed_num;
      continue;
    }
    ASSERT_EQ(fea_str, un_cache_feas[i].second);
  }
  LOG(INFO) << "failed ration: " << static_cast<float>(failed_num) / un_cache_feas.size();
  LOG(INFO) << "extract by dynamic cache spend ms: " << timer.Interval() / 1000;
}

TEST_F(WDFeatureExtractorTest, TestDumpAndLoad) {
  // test preload
  base::FilePath video_path("video_rank_fea.dat");
  WDFeatureExtractor* extractor_tmp  = FeatureExtractorFactory::CreateExtractor("video_rank");
  extractor_tmp->Initialize("extractor_tmp", video_path.value());
  int dump_num = extractor_tmp->cache_size();
  LOG(INFO) << "dump_num: " << dump_num;
  extractor_tmp->DumpAllFea();
  delete extractor_tmp;

  WDFeatureExtractor* extractor = FeatureExtractorFactory::CreateExtractor("video_rank");
  extractor->Initialize("extractor", video_path.value());
  int read_num = extractor->cache_size();
  ASSERT_EQ(dump_num, read_num);
}

}  // namespace ml
}  // namespace reco
