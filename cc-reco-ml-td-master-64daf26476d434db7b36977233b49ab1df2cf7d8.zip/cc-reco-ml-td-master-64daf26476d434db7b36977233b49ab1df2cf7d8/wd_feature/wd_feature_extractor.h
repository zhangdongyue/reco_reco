#pragma once
#include <string>
#include <memory>
#include <fstream>
#include <vector>

#include "base/common/base.h"
#include "base/container/lru_cache.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread.h"
#include "base/testing/gtest_prod.h"

namespace base {
class FilePath;
}
namespace reco {
class DocServerGetItem;
class RecoItem;
namespace ml {

class WDFeatureExtractorTest;
class WDFeatureExtractor {
 public:
  WDFeatureExtractor() {}
  virtual ~WDFeatureExtractor() { stop_ = true; }

 public:
  // if u don't have any fea file, use empty str
  virtual bool Initialize(const std::string& name, const std::string& fea_file);

  bool ExtractFea(uint64 item_id, bool use_cache, std::string* fea);

  int cache_queue_size() { return miss_item_queue_->Size(); }

  int cache_size() {
    int num = 0;
    for (uint32 i = 0; i < item_fea_cache_.size(); ++i) {
      num += item_fea_cache_.at(i)->size();
    }
    return num;
  }
  static inline void DumpRecord(uint64 item_id, const std::string& value, std::ofstream* fout) {
    fout->write(reinterpret_cast<const char*>(&item_id), sizeof(item_id));
    int size = value.size();
    fout->write(reinterpret_cast<const char*>(&size), sizeof(size));
    fout->write(value.c_str(), value.size());
  }

  virtual bool DoExtract(const reco::RecoItem& reco_item, std::string* fea) = 0;

 protected:
  bool DoExtract(uint64 item_id, std::string* fea);

 protected:
  reco::DocServerGetItem* get_item_service_;

 private:
  // cache fea
  mutable std::vector<base::LRUCache<uint64, std::shared_ptr<std::string> >* > item_fea_cache_;
  base::LRUCache<uint64, int>* failed_cache_;
  mutable thread::BlockingQueue<uint64>* miss_item_queue_;

  thread::ThreadPool* fea_thread_pool_;

  bool stop_;
  std::string fea_file_;
  std::string name_;
 protected:
  bool LoadItemFea(const base::FilePath& path);
  void CacheDump(int interval_in_minute);
  bool DumpAllFea();
  void UpdateWorker(int seconds);
  void CacheWriter();

  FRIEND_TEST(WDFeatureExtractorTest, TestTextFea);
  FRIEND_TEST(WDFeatureExtractorTest, TestVideoFea);
  FRIEND_TEST(WDFeatureExtractorTest, TestDumpAndLoad);
  DISALLOW_COPY_AND_ASSIGN(WDFeatureExtractor);
};
}
}
