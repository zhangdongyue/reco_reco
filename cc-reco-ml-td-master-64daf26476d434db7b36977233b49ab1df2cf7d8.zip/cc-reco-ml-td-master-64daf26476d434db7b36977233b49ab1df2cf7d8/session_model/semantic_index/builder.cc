#include "reco/ml/session_model/semantic_index/semantic_index_builder.h"

DEFINE_string(w2v_result_file, "", "w2v item id result file");
DEFINE_string(dump_file, "", "dump semantic index file");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "semantic index builder");

  reco::session::SemanticIndexBuilder semantic_index_builder;
  semantic_index_builder.BuildSemanticIndex(FLAGS_w2v_result_file);
  semantic_index_builder.DumpToFile(FLAGS_dump_file);

  return 0;
}
