#include "reco/ml/session_model/semantic_index/semantic_index_builder.h"

#include <vector>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <functional>
#include <fstream>

#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/time/timestamp.h"
#include "base/common/closure.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/time/time.h"
#include "base/encoding/line_escape.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/item.pb.h"

#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"

DEFINE_string(item_keeper_ips, "11.251.202.129", "item keeper");
DEFINE_int32(item_keeper_port, 20066, "item keeper port");

namespace reco {
namespace session {

bool RelevantList::ParseFromString(const std::string& str) {
  if (str.empty()) return false;
  std::vector<std::string> fields;
  base::SplitString(str, "\t", &fields);
  if (fields.size() < 5) return false;
  if (!base::StringToUint64(fields[0], &item_id_)) {
    return false;
  }

  terms_.push_back(TermInfo(item_id_, 1.0));

  uint64 item_id = 0u;
  double w2v_score = 0.0;
  for (uint32 i = 1; i < fields.size(); i += 2) {
    if (!base::StringToUint64(fields[i], &item_id)
        || !base::StringToDouble(fields[i + 1], &w2v_score)) {
      return false;
    }
    if (w2v_score < 0.75) {
      break;
    }
    terms_.push_back(TermInfo());
    terms_.back().item_id = item_id;
    terms_.back().w2v_score = w2v_score;
  }

  return true;
}

bool RelevantList::InitMainItemInfo(const reco::RecoItem& reco_item) {
  if (reco_item.category_size() > 0) {
    category_ = reco_item.category(0);
  }
  if (reco_item.has_orig_source()) {
    orig_source_ = reco_item.orig_source();
  }
  if (reco_item.has_tag()) {
    for (int i = 0; i < reco_item.tag().feature_size(); ++i) {
      const std::string& tag = reco_item.tag().feature(i).literal();
      std::vector<std::string> real_tags;
      base::SplitString(tag, ":", &real_tags);
      tags_.push_back(real_tags.back());
    }
  }

  return true;
}

bool InvertList::AddTermInfo(const TermInfo& term_info) {
  if (dedup_.find(term_info.item_id) != dedup_.end()) {
    return true;
  }
  terms_.push_back(term_info);
  return true;
}

std::string InvertList::ToString() {
  std::string str;
  str = main_term_;
  for (auto iter = terms_.begin(); iter != terms_.end(); ++iter) {
    str += "\t" + base::Uint64ToString(iter->item_id)
          + "\t" + base::DoubleToString(iter->w2v_score);
  }

  return str;
}

bool SemanticIndexBuilder::BuildSemanticIndex(const std::string& path) {
  if (path.empty()) return false;
  std::vector<std::string> lines;
  base::FilePath file_path(path);
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "read file error: " << path;
    return false;
  }
  reco::BaseGetItem* get_item = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips,
                                                            FLAGS_item_keeper_port, -1);
  LOG(INFO) << "total lines: " << lines.size();
  for (uint32 i = 0; i < lines.size(); ++i) {
    RelevantList relevant_list;
    if (i % 1000 == 0) {
      LOG(INFO) << "process num: " << i;
    }
    if (!relevant_list.ParseFromString(lines[i])) {
      LOG(ERROR) << "parse line error: " << lines[i];
      continue;
    }
    reco::RecoItem reco_item;
    if (!get_item->GetRecoItem(relevant_list.item_id_, &reco_item)) {
      LOG(ERROR) << "get reco item failed: " << relevant_list.item_id_;
      continue;
    } else {
      relevant_list.InitMainItemInfo(reco_item);
    }
    if (!AddRelevantList(relevant_list)) {
      LOG(ERROR) << "add relevant_list failed: " << relevant_list.item_id_;
    }
  }
  delete get_item;
  get_item = NULL;

  return true;
}

bool SemanticIndexBuilder::AddRelevantList(const RelevantList& relevant_list) {
  if (relevant_list.tags_.empty()) return false;
  for (auto iter = relevant_list.tags_.begin(); iter != relevant_list.tags_.end(); ++iter) {
    auto it = tag_invert_index_.find(*iter);
    if (it == tag_invert_index_.end()) {
      it = tag_invert_index_.insert(std::make_pair(*iter, InvertList())).first;
      it->second.main_term_ = *iter;
    }
    for (auto item_it = relevant_list.terms_.begin(); item_it != relevant_list.terms_.end(); ++item_it) {
      it->second.AddTermInfo(*item_it);
    }
  }

  return true;
}

bool SemanticIndexBuilder::DumpToFile(const std::string& output_path) {
  std::ofstream fout(output_path);
  if (!fout.good()) {
    LOG(ERROR) << "open file failed: " << output_path;
    return false;
  }
  for (auto iter = tag_invert_index_.begin(); iter != tag_invert_index_.end(); ++iter) {
    fout << iter->second.ToString() << std::endl;
  }
  fout.close();

  return true;
}
}
}
