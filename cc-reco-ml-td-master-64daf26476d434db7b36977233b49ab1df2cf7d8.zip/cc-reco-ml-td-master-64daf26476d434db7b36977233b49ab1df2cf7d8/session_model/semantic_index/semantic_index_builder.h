#pragma once

#include <vector>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <functional>

#include "base/common/base.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
namespace session {

struct TermInfo {
  uint64 item_id;
  double w2v_score;
  TermInfo() {
    item_id = 0u;
    w2v_score = 0.0;
  }
  TermInfo(uint64 item_id, double w2v_score) {
    this->item_id = item_id;
    this->w2v_score = w2v_score;
  }
};

class RelevantList {
 public:
  RelevantList() {}
  ~RelevantList() {}

  bool ParseFromString(const std::string& str);

  bool InitMainItemInfo(const reco::RecoItem& reco_item);

 public:
  uint64 item_id_;
  std::string category_;
  std::string source_;
  std::string orig_source_;
  std::vector<std::string> tags_;
  std::vector<TermInfo> terms_;
};

class InvertList {
 public:
  InvertList() {}
  ~InvertList() {}

  bool AddTermInfo(const TermInfo& term_info);

  std::string ToString();
 public:
  std::string main_term_;
  std::unordered_set<uint64> dedup_;
  std::vector<TermInfo> terms_;
};

class SemanticIndexBuilder {
 public:
  SemanticIndexBuilder() {}
  ~SemanticIndexBuilder() {}

  bool BuildSemanticIndex(const std::string& path);

  bool DumpToFile(const std::string& output_path);

 private:
  bool AddRelevantList(const RelevantList& relevant_list);

 private:
  std::unordered_map<std::string, InvertList> tag_invert_index_;
};
}
}
