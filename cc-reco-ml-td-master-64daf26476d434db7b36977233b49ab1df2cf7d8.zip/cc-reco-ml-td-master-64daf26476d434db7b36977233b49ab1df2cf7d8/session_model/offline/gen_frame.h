#pragma once

#include <cstdatomic>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>

#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "reco/ml/session_model/offline/extractor.h"
#include "reco/ml/session_model/offline/common.h"

namespace reco {
namespace session {

class Generator {
 public:
  Generator();
  ~Generator();

  void SetItemFeatureMask(const uint64 mask);

  void GenInstMultiThread();

 private:

  void ReadFile();

  void ParseUserInfo();

  void ExtractLrFeas();

  void ExtractSessionFeas();

  void DumpLrInstance();

  void DumpSessionInstance();
 private:
  struct ItemFeatureMask {
    bool do_item_id;
    bool do_cate;
    bool do_source;
    bool do_tags;

    ItemFeatureMask() {
      do_item_id = false;
      do_cate = false;
      do_source = false;
      do_tags = false;
    }
  };

  ItemFeatureMask item_feature_mask_;

  thread::BlockingQueue<RawUserRecoContainer*>* raw_info_queue_;

  thread::BlockingQueue<UserRecoContainer*>* info_queue_;

  thread::BlockingQueue<std::string>* instance_queue_;

  atomic_int parse_user_finished_num_;

  atomic_int extract_feas_finished_num_;
};
}
}
