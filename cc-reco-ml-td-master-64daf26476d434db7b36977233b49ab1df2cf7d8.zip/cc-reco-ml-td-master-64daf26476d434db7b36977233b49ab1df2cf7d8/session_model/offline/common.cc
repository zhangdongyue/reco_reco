#include "reco/ml/session_model/offline/common.h"

namespace reco {
namespace session {

DEFINE_string(fields_delimiter, "`", "field delimiter");

std::string MapToString(const std::unordered_map<std::string, int>& map) {
  static const std::string digit_delim = "_";
  std::string str;
  for (auto iter = map.begin(); iter != map.end(); ++iter) {
    if (str.empty()) {
      str = iter->first + digit_delim + base::IntToString(iter->second);
    } else {
      str += FLAGS_fields_delimiter + iter->first + digit_delim + base::IntToString(iter->second);
    }
  }

  return str;
}

std::string MapKeyToString(const std::unordered_map<std::string, int>& map) {
  std::string str;
  for (auto iter = map.begin(); iter != map.end(); ++iter) {
    if (str.empty()) {
      str = iter->first;
    } else {
      str += FLAGS_fields_delimiter + iter->first;
    }
  }

  return str;
}

std::string StringVectorToString(const std::vector<std::string>& str_vec) {
  std::string str;
  for (auto iter = str_vec.begin(); iter != str_vec.end(); ++iter) {
    if (str.empty()) {
      str = *iter;
    } else {
      str += FLAGS_fields_delimiter + *iter;
    }
  }

  return str;
}

std::string GetRealTag(const std::string& raw_tag) {
  std::vector<std::string> fields;
  base::SplitString(raw_tag, ":", &fields);

  return fields.back();
}

std::string Uint64VectorToString(const std::vector<uint64>& uint64_vec) {
  std::string str;
  for (auto iter = uint64_vec.begin(); iter != uint64_vec.end(); ++iter) {
    if (str.empty()) {
      str = base::Uint64ToString(*iter);
    } else {
      str += FLAGS_fields_delimiter + base::Uint64ToString(*iter);
    }
  }

  return str;
}

std::string ToWeightString(const std::vector<uint64>& uint64_vec) {
  std::string str;
  for (auto iter = uint64_vec.begin(); iter != uint64_vec.end(); ++iter) {
    if (str.empty()) {
      str = "1";
    } else {
      str += FLAGS_fields_delimiter + "1";
    }
  }

  return str;
}

void MapToVectors(const std::unordered_map<std::string, int>& map,
                 std::vector<std::string>* key_list,
                 std::vector<std::string>* value_list) {
  key_list->clear();
  value_list->clear();
  for (auto iter = map.begin(); iter != map.end(); ++iter) {
    key_list->push_back(iter->first);
    value_list->push_back(base::IntToString(iter->second));
  }
}

std::string ToValueString(const std::string& str) {
  int len = str.length();
  std::string len_str = base::IntToString(len);
  std::string value_str = "=" + len_str + ":" + str;

  return value_str;
}
}
}
