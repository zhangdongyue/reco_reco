#pragma once

#include "reco/base/common/atomic.h"
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <functional>

#include "base/time/time.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "reco/bizc/proto/user.pb.h"
// #include "reco/ml/session_model/offline/extractor.h"

namespace reco {
namespace session {

std::string MapToString(const std::unordered_map<std::string, int>& map);

std::string MapKeyToString(const std::unordered_map<std::string, int>& map);

std::string StringVectorToString(const std::vector<std::string>& str_vec);

std::string GetRealTag(const std::string& raw_tag);

std::string Uint64VectorToString(const std::vector<uint64>& uint64_vec);

std::string ToWeightString(const std::vector<uint64>& uint64_vec);

void MapToVectors(const std::unordered_map<std::string, int>& map,
                 std::vector<std::string>* key_list,
                 std::vector<std::string>* value_list);

std::string ToValueString(const std::string& str);

struct MergeLogRecoFeas {
  uint64 user_id;
  uint64 item_id;
  int click;
  int cid;
  std::string category;
  std::string source;
  std::string orig_source;
  std::vector<std::string> tags;
  int strategy_type;
  base::Time ctm;
  base::Time tm;
  uint64 reco_id;

  MergeLogRecoFeas() {
    user_id = 0;
    item_id = 0;
    click = 0;
    cid = -1;
    strategy_type = -1;
    reco_id = 0;
  }

  std::string ToString() {
    std::string str;
    std::string tags_str;
    for (auto iter = tags.begin(); iter != tags.end(); ++iter) {
      if (tags_str.empty()) {
        tags_str = *iter;
      } else {
        tags_str += "|" + *iter;
      }
    }

    std::string ctm_str;
    ctm.ToStringInSeconds(&ctm_str);
    std::string tm_str;
    tm.ToStringInSeconds(&tm_str);

    str = "user_id: " + base::Uint64ToString(user_id) +
        " item_id: " + base::Uint64ToString(item_id) +
        " click: " + base::IntToString(click) +
        " cid: " + base::IntToString(cid) +
        " category: " + category +
        " source: " + source +
        " orig_source: " + orig_source +
        " tags: " + tags_str +
        " strategy_type: " + base::IntToString(strategy_type) +
        " ctm: " + ctm_str +
        " tm: " + tm_str +
        " reco_id: " + base::Uint64ToString(reco_id);

    return str;
  }

  bool ParseTags(const std::string& tag_str, std::vector<std::string>* tags) {
    tags->clear();
    base::SplitString(tag_str, "|", tags);
    if (!tags->size()) {
      return false;
    }

    return true;
  }

  bool ParseRawTags(const std::string& tag_str, std::vector<std::string>* tags) {
    tags->clear();
    std::vector<std::string> fields;
    base::SplitString(tag_str, ",", &fields);
    for (uint32 i = 0; i < fields.size(); ++i) {
      std::vector<std::string> sub_fields;
      base::SplitString(fields[i], ":", &sub_fields);
      if (sub_fields.size() > 0) {
        tags->push_back(sub_fields.back());
      }
    }
    if (!tags->size()) {
      return false;
    }

    return true;
  }

  bool ParseFromString(const std::string& raw) {
    std::vector<std::string> fields;
    base::SplitString(raw, "\t", &fields);
    if (fields.size() != 9) {
      return false;
    }
    if (!base::StringToUint64(fields[0], &user_id)
        || !base::StringToUint64(fields[2], &item_id)
        || !base::StringToInt(fields[4], &click)
        || !base::StringToInt(fields[5], &cid)
        || !base::StringToUint64(fields[8], &reco_id)) {
      return false;
    }
    std::vector<std::string> sub_fields;
    base::SplitString(fields[3], "\01", &sub_fields);
    if (sub_fields.size() != 5) return false;
    if (sub_fields[0] != "0") category = sub_fields[0];
    else return false;
    if (sub_fields[1] != "0") source = sub_fields[1];
    else return false;
    if (sub_fields[2] != "0") orig_source = sub_fields[2];
    if (sub_fields[3] != "0") {
      ParseTags(sub_fields[3], &tags);
    }
    if (!base::StringToInt(sub_fields[4], &strategy_type)) {
      return false;
    }
    // ctm not zero but parse failed
    if (fields[6] != "0"
        && !base::Time::FromStringInSeconds(fields[6].c_str(), &ctm)) {
      VLOG(2) << "parse ctm failed " << item_id;
      return false;
    }
    // tm not zero but parse failed
    if (fields[7] != "0"
        && !base::Time::FromStringInSeconds(fields[7].c_str(), &tm)) {
      VLOG(2) << "parse tm failed " << item_id;
      return false;
    }

    return true;
  }

  bool operator < (const MergeLogRecoFeas& rhs) const {
    if (this->tm < rhs.tm) {
      return true;
    }

    return false;
  }

  bool operator > (const MergeLogRecoFeas& rhs) const {
    return !(*this < rhs);
  }
};

struct RawUserRecoContainer {
  std::string raw_user_info;
  std::vector<std::string> recos;
};

struct UserRecoContainer {
  reco::user::UserInfo user_info;
  std::vector<std::string> recos;
};

struct UserRecoFeaContainer {
  reco::user::UserInfo user_info;
  std::vector<MergeLogRecoFeas> recos_fea;
};
}
}
