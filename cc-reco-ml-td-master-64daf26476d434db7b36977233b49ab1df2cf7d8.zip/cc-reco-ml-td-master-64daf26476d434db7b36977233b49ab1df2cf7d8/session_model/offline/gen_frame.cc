#include "reco/ml/session_model/offline/gen_frame.h"

#include <iostream>
#include <string>

#include "reco/ml/common/io_util.h"
#include "reco/ml/session_model/offline/extractor.h"
#include "reco/ml/session_model/offline/session_extractor.h"

namespace reco {
namespace session {

DEFINE_int32(parse_user_info_thread_num, 10, "parse user info thread num");
DEFINE_int32(extract_feas_thread_num, 10, "extract feas thread num");
DEFINE_int32(min_click_seconds, 5, "min click seconds");
DEFINE_bool(do_sign, false, "sign feature or not");
DEFINE_string(lr_or_tf, "tf", "do lr or tf instance extractor");

DECLARE_int32(min_session_size);

const std::string sep = "\t";

Generator::Generator() {
  raw_info_queue_ = new thread::BlockingQueue<RawUserRecoContainer*>();
  info_queue_ = new thread::BlockingQueue<UserRecoContainer*>();
  instance_queue_ = new thread::BlockingQueue<std::string>();
  parse_user_finished_num_ = 0;
  extract_feas_finished_num_ = 0;
}

Generator::~Generator() {
  delete raw_info_queue_;
  delete info_queue_;
  delete instance_queue_;
}

void Generator::ReadFile() {
  std::string line;
  std::vector<std::string> fields;
  std::string user_id;
  bool first = true;
  RawUserRecoContainer* raw_info = NULL;
  while(std::getline(std::cin, line)) {
    if (line.empty()) continue;
    base::TrimTrailingWhitespaces(&line);
    fields.clear();
    base::SplitString(line, sep, &fields);
    if (fields.size() == 2) {
      if (raw_info && first == false) {
        // NOTE(CONGHUI): do some filter here
        if (raw_info->recos.size() < (uint32)(FLAGS_min_session_size)) {
          delete raw_info;
          raw_info = NULL;
        } else {
          raw_info_queue_->Put(raw_info);
          VLOG(2) << raw_info->raw_user_info.length() << " " << raw_info->recos.size();
        }
      }
      raw_info = new RawUserRecoContainer();
      raw_info->raw_user_info = fields[1];
      user_id = fields[0];
      first = false;
    } else {
      if (user_id == fields[0] && raw_info != NULL) {
        raw_info->recos.push_back(line);
      }
    }
  }

  LOG(INFO) << "raw_info_queue close";
  raw_info_queue_->Close();
}

void Generator::ParseUserInfo() {
  while (!raw_info_queue_->Closed() || !raw_info_queue_->Empty()) {
    RawUserRecoContainer* raw_info = NULL;
    if (raw_info_queue_->TimedTake(5, &raw_info) != 1) {
      base::SleepForMilliseconds(50);
      continue;
    }
    UserRecoContainer* info = new UserRecoContainer();
    if (reco::ml::UnSerializeLineEscapeProto(raw_info->raw_user_info, &(info->user_info))) {
      VLOG(2) << "user id : " << info->user_info.identity().user_id();
      info->recos.insert(info->recos.begin(), raw_info->recos.begin(), raw_info->recos.end());
      info_queue_->Put(info);
    }
    if (raw_info) {
      delete raw_info;
      raw_info = NULL;
    }
  }

  parse_user_finished_num_++;
  LOG(INFO) << "parse user finished thread num: " << parse_user_finished_num_;
  if (parse_user_finished_num_ >= FLAGS_parse_user_info_thread_num) {
    LOG(INFO) << "info_queue close";
    info_queue_->Close();
  }
}

void Generator::ExtractLrFeas() {
  Extractor extractor;
  while (!info_queue_->Closed() || !info_queue_->Empty()) {
    UserRecoContainer* info = NULL;
    if (info_queue_->TimedTake(5, &info) != 1) {
      base::SleepForMilliseconds(50);
      continue;
    }
    reco::reco_model::UserFeature user_feature;
    extractor.GenUserFea(info->user_info, &user_feature);
    auto& recos = info->recos;
    for (auto iter = recos.begin(); iter != recos.end(); ++iter) {
      MergeLogRecoFeas merge_log_feas;
      if (merge_log_feas.ParseFromString(*iter)) {
        VLOG(2) << merge_log_feas.ToString();
        reco::reco_model::ItemFeature item_feature;
        if (item_feature_mask_.do_item_id) {
          item_feature.item_id = merge_log_feas.item_id;
        } else {
          item_feature.item_id = 100u;
        }
        if (item_feature_mask_.do_cate) {
          item_feature.category.push_back(merge_log_feas.category);
        }
        if (item_feature_mask_.do_source) {
          item_feature.source = merge_log_feas.source;
        }
        if (item_feature_mask_.do_tags) {
          for (auto it = merge_log_feas.tags.begin(); it != merge_log_feas.tags.end(); ++it) {
            reco::Feature* tag_fea = item_feature.tag.add_feature();
            tag_fea->set_literal(*it);
          }
        }

        reco::reco_model::LrFeature lr_features;
        if (!extractor.GenCombineFea(user_feature, item_feature, &lr_features)) {
          VLOG(2) << "gen combine fea failed";
          continue;
        }
        int label = 0;
        if (merge_log_feas.click > FLAGS_min_click_seconds) {
          label = 1;
        }
        std::string instance;
        if (extractor.GenInstance(label, FLAGS_do_sign, &lr_features, &instance)
            && instance.length() > 50) {
          VLOG(2) << "put to instance queue " << instance;
          instance_queue_->Put(instance);
        }
      }
    }
  }

  extract_feas_finished_num_++;
  LOG(INFO) << "extract feas finished thread num: " << extract_feas_finished_num_;
  if (extract_feas_finished_num_ >= FLAGS_extract_feas_thread_num) {
    LOG(INFO) << "instance_queue close";
    instance_queue_->Close();
  }
}

bool CmpBaseTime(const MergeLogRecoFeas& lhs,
                 const MergeLogRecoFeas& rhs) {
  if (lhs.tm > rhs.tm) {
    return true;
  }

  return false;
}

void Generator::ExtractSessionFeas() {
  std::vector<std::string> instances;
  std::vector<MergeLogRecoFeas> merge_log_reco_feas;
  SessionExtractor extractor;
  while (!info_queue_->Closed() || !info_queue_->Empty()) {
    UserRecoContainer* info = NULL;
    if (info_queue_->TimedTake(5, &info) != 1) {
      base::SleepForMilliseconds(50);
      continue;
    }
    instances.clear();
    merge_log_reco_feas.clear();
    auto& recos = info->recos;
    for (auto iter = recos.begin(); iter != recos.end(); ++iter) {
      MergeLogRecoFeas merge_log_feas;
      if (merge_log_feas.ParseFromString(*iter)) {
        VLOG(2) << merge_log_feas.ToString();
        merge_log_reco_feas.push_back(merge_log_feas);
      }
    }
    if (merge_log_reco_feas.size() >= 5) {
      std::sort(merge_log_reco_feas.begin(), merge_log_reco_feas.end(), CmpBaseTime);
              //  std::greater<MergeLogRecoFeas>());

      if (extractor.BatchExtractFeas(info->user_info, merge_log_reco_feas, &instances)) {
        for (uint32 i = 0; i < instances.size(); ++i) {
          auto& instance = instances[i];
          VLOG(2) << "put to instance queue " << instance;
          instance_queue_->Put(instance);
        }
      }
    }
  }

  extract_feas_finished_num_++;
  LOG(INFO) << "extract feas finished thread num: " << extract_feas_finished_num_;
  if (extract_feas_finished_num_ >= FLAGS_extract_feas_thread_num) {
    LOG(INFO) << "instance_queue close";
    instance_queue_->Close();
  }
}

void Generator::DumpLrInstance() {
  int count = 0;
  int all_count = 0;
  while (!instance_queue_->Closed() || !instance_queue_->Empty()) {
    std::string instance;
    if (instance_queue_->TimedTake(5, &instance) != 1) {
      base::SleepForMilliseconds(50);
      continue;
    }
    ++all_count;
    if (all_count % 1000 == 0) {
      LOG(INFO) << "calc instance count: " << all_count;
    }
    if (instance.size() < 10) continue;
    ++count;
    if (count % 1000 == 0) {
      LOG(INFO) << "dump instance count: " << count;
    }
    std::cout << instance << std::endl;
  }

  LOG(INFO) << "total instance: " << all_count
      << " dumped instance: " << count;
}

void Generator::DumpSessionInstance() {
  int count = 0;
  int all_count = 0;
  while (!instance_queue_->Closed() || !instance_queue_->Empty()) {
    std::string instance;
    if (instance_queue_->TimedTake(5, &instance) != 1) {
      base::SleepForMilliseconds(50);
      continue;
    }
    ++all_count;
    if (all_count % 1000 == 0) {
      LOG(INFO) << "calc instance count: " << all_count;
    }
    if (instance.size() < 10) continue;
    ++count;
    if (count % 1000 == 0) {
      LOG(INFO) << "dump instance count: " << count;
    }
    std::cout << instance;
  }

  LOG(INFO) << "total instance: " << all_count
      << " dumped instance: " << count;
}
void Generator::SetItemFeatureMask(const uint64 mask) {
  if (mask & 0x01) item_feature_mask_.do_item_id = true;
  if (mask & 0x02) item_feature_mask_.do_cate = true;
  if (mask & 0x04) item_feature_mask_.do_source = true;
  if (mask & 0x08) item_feature_mask_.do_tags = true;
}

void Generator::GenInstMultiThread() {
  int thread_num = 2 + FLAGS_parse_user_info_thread_num + FLAGS_extract_feas_thread_num;
  thread::ThreadPool pool(thread_num);
  pool.AddTask(::NewCallback(this, &Generator::ReadFile));
  for (int i = 0; i < FLAGS_parse_user_info_thread_num; ++i) {
    pool.AddTask(::NewCallback(this, &Generator::ParseUserInfo));
  }
  for (int i = 0; i < FLAGS_extract_feas_thread_num; ++i) {
    if (FLAGS_lr_or_tf == "tf") {
      pool.AddTask(::NewCallback(this, &Generator::ExtractSessionFeas));
    } else {
      pool.AddTask(::NewCallback(this, &Generator::ExtractLrFeas));
    }
  }
  if (FLAGS_lr_or_tf == "tf") {
    pool.AddTask(::NewCallback(this, &Generator::DumpSessionInstance));
  } else {
    pool.AddTask(::NewCallback(this, &Generator::DumpLrInstance));
  }

  pool.JoinAll();
}
}
}
