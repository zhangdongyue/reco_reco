#include "reco/ml/session_model/offline/gen_frame.h"
#include "base/common/base.h"

DEFINE_int32(item_fea_mask, 2, "item fea mask");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "gen cates instances");

  reco::session::Generator generator;
  generator.SetItemFeatureMask(FLAGS_item_fea_mask);
  generator.GenInstMultiThread();

  LOG(INFO) << "gen instance finished";

  return 0;
}
