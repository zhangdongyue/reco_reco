#include "reco/ml/session_model/offline/session_extractor.h"

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>

#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/proto/user.pb.h"
#include "nlp/common/nlp_util.h"


namespace reco {
namespace session {

DEFINE_string(data_flag, "[dat]", "data flags");
DEFINE_string(key_equal_mark, "=0:", "key equal mark");

DEFINE_int32(max_lt_video_tag, 50, "max user lt video tag num");
DEFINE_int32(max_lt_video_cate, 5, "max user lt video cate num");
DEFINE_int32(scale_up, 10, "scale up for user feas");
DEFINE_bool(is_compress_format, false, "is compress format for output instance");
DEFINE_int32(min_session_size, 0, "min session size");

DECLARE_string(fields_delimiter);

const std::string UserFeas::kUserIdKey = "user_id";
const std::string UserFeas::kUserLtVideoTagsKey = "lt_video_tags";
const std::string UserFeas::kUserLtVideoTagsWeightKey = "lt_video_tags_weight";
const std::string UserFeas::kUserLtVideoCatesKey = "lt_video_cates";
const std::string UserFeas::kUserLtVideoCatesWeightKey = "lt_video_cates_weight";
const std::string UserFeas::kUserLtVideoCateTagsKey = "lt_video_cate_tags";
const std::string UserFeas::kUserLtVideoCateTagsWeight = "lt_video_cate_tags_weight";

bool UserFeas::ExtractFeas(const reco::user::UserInfo& user_info) {
  Reset();

  user_id = user_info.identity().user_id();
  if (user_id == 0) {
    return false;
  }
  auto &v_tag_vec = user_info.profile().video_tag_without_cat_feavec();
  float norm_vtag = 0.001;
  int count_v = 0;
  for (int i = 0; i < v_tag_vec.feature_size() && count_v < FLAGS_max_lt_video_tag; ++i) {
    norm_vtag += v_tag_vec.feature(i).weight();
    ++count_v;
  }
  for (int i = 0; i < count_v; ++i) {
    auto &tag = v_tag_vec.feature(i);
    std::string tag_lt = tag.literal();
    nlp::util::NormalizeLineInPlaceS(&tag_lt);
    std::string real_tag = GetRealTag(tag_lt);
    int weight = int((tag.weight() * FLAGS_scale_up) / norm_vtag * count_v);
    weight = std::max(weight, 1);
    lt_video_tags.insert(std::make_pair(real_tag, weight));
  }

  if (user_info.profile().has_video_category_feavec()) {
    float norm_category = 0.001;
    int count = 0;
    auto& v_cates = user_info.profile().video_category_feavec();
    for (int i = 0; i < v_cates.feature_size() && count < FLAGS_max_lt_video_cate; ++i) {
      norm_category += v_cates.feature(i).weight();
      ++count;
    }
    for (int i = 0; i < count; ++i) {
      auto& cate = v_cates.feature(i);
      std::string lt_cate = cate.literal().category();
      nlp::util::NormalizeLineInPlaceS(&lt_cate);
      int weight = int((cate.weight() * FLAGS_scale_up) / norm_category * count);
      weight = std::max(weight, 1);
      lt_video_cates.insert(std::make_pair(lt_cate, weight));
    }
  }

  return true;
}

std::string UserFeas::ToTFString() {
  std::string str;

  str = kUserIdKey + FLAGS_key_equal_mark + base::Uint64ToString(user_id) + "\n";

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // lt video tags
  MapToVectors(lt_video_tags, &key_list, &value_list);
  str += kUserLtVideoTagsKey + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += kUserLtVideoTagsWeightKey + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // lt video cates
  MapToVectors(lt_video_cates, &key_list, &value_list);
  str += kUserLtVideoCatesKey + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += kUserLtVideoCatesWeightKey + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // // lt video cate tags
  // MapToVectors(lt_video_cate_tags, &key_list, &value_list);
  // str += kUserLtVideoCateTagsKey + FLAGS_key_equal_mark
  //     + StringVectorToString(key_list) + "\n";
  // str += kUserLtVideoCateTagsWeightKey + FLAGS_key_equal_mark
  //     + StringVectorToString(value_list) + "\n";

  return str;
}

std::string UserFeas::ToCompressTFString() {
  std::string str;

  str = kUserIdKey + ToValueString(base::Uint64ToString(user_id));

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // lt video tags
  MapToVectors(lt_video_tags, &key_list, &value_list);
  str += kUserLtVideoTagsKey + ToValueString(StringVectorToString(key_list));
  str += kUserLtVideoTagsWeightKey + ToValueString(StringVectorToString(value_list));

  // lt video cates
  MapToVectors(lt_video_cates, &key_list, &value_list);
  str += kUserLtVideoCatesKey + ToValueString(StringVectorToString(key_list));
  str += kUserLtVideoCatesWeightKey + ToValueString(StringVectorToString(value_list));

  // // lt video cate tags
  // MapToVectors(lt_video_cate_tags, &key_list, &value_list);
  // str += kUserLtVideoCateTagsKey + FLAGS_key_equal_mark
  //     + StringVectorToString(key_list) + "\n";
  // str += kUserLtVideoCateTagsWeightKey + FLAGS_key_equal_mark
  //     + StringVectorToString(value_list) + "\n";

  return str;
}

const std::string ItemFeas::kMainItemIdKey = "main_item_id";
const std::string ItemFeas::kMainItemTagsKey = "main_item_tags";
const std::string ItemFeas::kMainItemTagsWeightKey = "main_item_tags_weight";
const std::string ItemFeas::kMainItemCateKey = "main_item_cate";
const std::string ItemFeas::kMainItemSourceKey = "main_item_source";
const std::string ItemFeas::kMainItemOrigSourceKey = "main_item_orig_source";

bool ItemFeas::ExtractFeas(const MergeLogRecoFeas& merge_log_feas) {
  Reset();
  item_id = merge_log_feas.item_id;
  tags = merge_log_feas.tags;
  category = merge_log_feas.category;
  source = merge_log_feas.source;
  orig_source = merge_log_feas.orig_source;

  return true;
}

std::string ItemFeas::ToTFString() {
  std::string str;
  str = kMainItemIdKey + FLAGS_key_equal_mark + base::Uint64ToString(item_id) + "\n";
  std::string tag_str;
  std::string tag_weight_str;
  for (auto iter = tags.begin(); iter != tags.end(); ++iter) {
    if (tag_str.empty()) {
      tag_str = *iter;
      tag_weight_str = "1";
    } else {
      tag_str += FLAGS_fields_delimiter + *iter;
      tag_weight_str += FLAGS_fields_delimiter + "1";
    }
  }
  str += kMainItemTagsKey + FLAGS_key_equal_mark + tag_str + "\n";
  str += kMainItemTagsWeightKey + FLAGS_key_equal_mark + tag_weight_str + "\n";
  str += kMainItemCateKey + FLAGS_key_equal_mark + category + "\n";
  str += kMainItemSourceKey + FLAGS_key_equal_mark + source + "\n";
  str += kMainItemOrigSourceKey + FLAGS_key_equal_mark + orig_source + "\n";

  return str;
}

std::string ItemFeas::ToCompressTFString() {
  std::string str;
  str = kMainItemIdKey + ToValueString(base::Uint64ToString(item_id));
  std::string tag_str;
  std::string tag_weight_str;
  for (auto iter = tags.begin(); iter != tags.end(); ++iter) {
    if (tag_str.empty()) {
      tag_str = *iter;
      tag_weight_str = "1";
    } else {
      tag_str += FLAGS_fields_delimiter + *iter;
      tag_weight_str += FLAGS_fields_delimiter + "1";
    }
  }
  str += kMainItemTagsKey + ToValueString(tag_str);
  str += kMainItemTagsWeightKey + ToValueString(tag_weight_str);
  str += kMainItemCateKey + ToValueString(category);
  str += kMainItemSourceKey + ToValueString(source);
  str += kMainItemOrigSourceKey + ToValueString(orig_source);

  return str;
}

std::vector<std::string> SessionFeasKeys::BuildKey(const std::string& key_prefix, const int num) {
  std::vector<std::string> keys;
  for (int i = 0; i < num; ++i) {
    std::string id_str = base::IntToString(i);
    std::string key = key_prefix + id_str;
    keys.push_back(key);
  }

  return keys;
}

#define SESSION_NUM (2)

const std::vector<std::string> SessionFeasKeys::kSessionShowItemIdsKey
  = SessionFeasKeys::BuildKey("session_show_item_ids_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowItemIdsWeightKey
  = SessionFeasKeys::BuildKey("session_show_item_ids_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickItemIdsKey
  = SessionFeasKeys::BuildKey("session_click_item_ids_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickItemIdsWeightKey
  = SessionFeasKeys::BuildKey("session_click_item_ids_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowTagsKey
  = SessionFeasKeys::BuildKey("session_show_tags_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowTagsWeightKey
  = SessionFeasKeys::BuildKey("session_show_tags_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickTagsKey
  = SessionFeasKeys::BuildKey("session_click_tags_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickTagsWeightKey
  = SessionFeasKeys::BuildKey("session_click_tags_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowCatesKey
  = SessionFeasKeys::BuildKey("session_show_cates_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowCatesWeightKey
  = SessionFeasKeys::BuildKey("session_show_cates_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickCatesKey
  = SessionFeasKeys::BuildKey("session_click_cates_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickCatesWeightKey
  = SessionFeasKeys::BuildKey("session_click_cates_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowCateTagsKey
  = SessionFeasKeys::BuildKey("session_show_cate_tags_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowCateTagsWeightKey
  = SessionFeasKeys::BuildKey("session_show_cate_tags_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickCateTagsKey
  = SessionFeasKeys::BuildKey("session_click_cate_tags_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickCateTagsWeightKey
  = SessionFeasKeys::BuildKey("session_click_cate_tags_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowSourcesKey
  = SessionFeasKeys::BuildKey("session_show_sources_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionShowSourcesWeightKey
  = SessionFeasKeys::BuildKey("session_show_sources_weight_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickSourcesKey
  = SessionFeasKeys::BuildKey("session_click_sources_", SESSION_NUM);
const std::vector<std::string> SessionFeasKeys::kSessionClickSourcesWeightKey
  = SessionFeasKeys::BuildKey("session_click_sources_weight_", SESSION_NUM);

bool SessionFeas::ExtractFeas(std::vector<MergeLogRecoFeas>::iterator begin,
                              std::vector<MergeLogRecoFeas>::iterator end) {
  Reset();
  for (auto iter = begin; iter != end; ++iter) {
    auto& item_id = iter->item_id;
    auto& tags = iter->tags;
    auto& category = iter->category;
    auto& click = iter->click;
    auto& source = iter->source;
    show_item_ids.push_back(item_id);
    for (auto it_tag = tags.begin(); it_tag != tags.end(); ++it_tag) {
      std::string tag = *it_tag;
      show_tags[tag] += 1;
      std::string cate_tag = category + "_" + tag;
      show_cate_tags[cate_tag] += 1;
      if (click) {
        click_tags[tag] += 1;
        click_cate_tags[cate_tag] += 1;
      }
    }

    show_cates[category] += 1;
    show_sources[source] += 1;
    if (click) {
      click_item_ids.push_back(item_id);
      click_cates[category] += 1;
      click_sources[source] += 1;
    }
  }

  return true;
}

std::string SessionFeas::ToTFString() {
  std::string str;
  str.reserve(2 << 10);
  // item ids
  str = SessionFeasKeys::kSessionShowItemIdsKey[session_id] + FLAGS_key_equal_mark
      + Uint64VectorToString(show_item_ids) + "\n";
  std::string show_item_id_weights = ToWeightString(show_item_ids);
  str += SessionFeasKeys::kSessionShowItemIdsWeightKey[session_id] + FLAGS_key_equal_mark + show_item_id_weights + "\n";

  str += SessionFeasKeys::kSessionClickItemIdsKey[session_id] + FLAGS_key_equal_mark
      + Uint64VectorToString(click_item_ids) + "\n";
  std::string click_item_id_weights = ToWeightString(click_item_ids);
  str += SessionFeasKeys::kSessionClickItemIdsWeightKey[session_id] + FLAGS_key_equal_mark + click_item_id_weights + "\n";

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // tags
  // show tags
  MapToVectors(show_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click tags
  MapToVectors(click_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // cates
  // show cates
  MapToVectors(show_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCatesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowCatesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click_cates
  MapToVectors(click_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCatesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickCatesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // cate tags
  // show cate tags
  MapToVectors(show_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCateTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowCateTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click cate tags
  MapToVectors(click_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCateTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickCateTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // sources
  // show sources
  MapToVectors(show_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowSourcesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowSourcesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click sources
  MapToVectors(click_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickSourcesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickSourcesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  return str;
}

std::string SessionFeas::ToCompressTFString() {
  std::string str;
  str.reserve(2 << 10);
  // item ids
  str = SessionFeasKeys::kSessionShowItemIdsKey[session_id]
      + ToValueString(Uint64VectorToString(show_item_ids));
  std::string show_item_id_weights = ToWeightString(show_item_ids);
  str += SessionFeasKeys::kSessionShowItemIdsWeightKey[session_id]
      + ToValueString(show_item_id_weights);

  str += SessionFeasKeys::kSessionClickItemIdsKey[session_id]
      + ToValueString(Uint64VectorToString(click_item_ids));
  std::string click_item_id_weights = ToWeightString(click_item_ids);
  str += SessionFeasKeys::kSessionClickItemIdsWeightKey[session_id]
      + ToValueString(click_item_id_weights);

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // tags
  // show tags
  MapToVectors(show_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click tags
  MapToVectors(click_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // cates
  // show cates
  MapToVectors(show_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCatesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowCatesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click_cates
  MapToVectors(click_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCatesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickCatesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // cate tags
  // show cate tags
  MapToVectors(show_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCateTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowCateTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click cate tags
  MapToVectors(click_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCateTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickCateTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // sources
  // show sources
  MapToVectors(show_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowSourcesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowSourcesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click sources
  MapToVectors(click_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickSourcesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickSourcesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  return str;
}

const std::string SessionExtractor::kLabelKey = "label";

SessionExtractor::SessionExtractor() {
  session_0_feas_.SetSessionId(0);
  session_1_feas_.SetSessionId(1);
}


bool SessionExtractor::BatchExtractFeas(const reco::user::UserInfo& user_info,
                                        std::vector<MergeLogRecoFeas>& merge_log_reco_feas_vec,
                                        std::vector<std::string>* instances) {
  instances->clear();
  user_feas_.ExtractFeas(user_info);
  uint32 cut_off = 0;
  if (merge_log_reco_feas_vec.size() > (uint32)(FLAGS_min_session_size)) {
    cut_off = merge_log_reco_feas_vec.size() - (uint32)(FLAGS_min_session_size);
  }
  for (uint32 i = 0; i <= cut_off; ++i) {
    main_item_feas_.ExtractFeas(merge_log_reco_feas_vec[i]);
    if (merge_log_reco_feas_vec[i].click) {
      label_ = 1;
    } else {
      label_ = 0;
    }

    std::vector<MergeLogRecoFeas>::iterator begin_iter0 =
        merge_log_reco_feas_vec.end();
    if (i + 1 < merge_log_reco_feas_vec.size()) {
      begin_iter0 = merge_log_reco_feas_vec.begin() + i + 1;
    }
    std::vector<MergeLogRecoFeas>::iterator end_iter0 =
        merge_log_reco_feas_vec.end();
    if (i + kSessionFirstSize + 1 < merge_log_reco_feas_vec.size()) {
      end_iter0 = merge_log_reco_feas_vec.begin() + i + 1 + kSessionFirstSize;
    }
    session_0_feas_.ExtractFeas(begin_iter0, end_iter0);

    std::vector<MergeLogRecoFeas>::iterator begin_iter1 =
        merge_log_reco_feas_vec.end();
    if (i + kSessionFirstSize + 2 < merge_log_reco_feas_vec.size()) {
      begin_iter1 = merge_log_reco_feas_vec.begin() + i + 2 + kSessionFirstSize;
    }
    std::vector<MergeLogRecoFeas>::iterator end_iter1 =
        merge_log_reco_feas_vec.end();
    if (i + kSessionFirstSize + 2 + kSessionSecondSize < merge_log_reco_feas_vec.size()) {
      end_iter1 = merge_log_reco_feas_vec.begin() + (i + 2 + kSessionFirstSize + kSessionSecondSize);
    }
    session_1_feas_.ExtractFeas(begin_iter1, end_iter1);

    instances->push_back(std::string());
    ToTFString(&(instances->back()));
  }

  return true;
}

std::string SessionExtractor::ToTFString() {
  std::string str;
  str.reserve(3 << 10);
  str = FLAGS_data_flag + "\n";
  if (FLAGS_is_compress_format) {
    str = kLabelKey + ToValueString(base::IntToString(label_));
    str += user_feas_.ToCompressTFString();
    str += main_item_feas_.ToCompressTFString();
    str += session_0_feas_.ToCompressTFString();
    str += session_1_feas_.ToCompressTFString();
    str += "\n";
  } else {
    str = kLabelKey + FLAGS_key_equal_mark + base::IntToString(label_) + "\n";
    str += user_feas_.ToTFString();
    str += main_item_feas_.ToTFString();
    str += session_0_feas_.ToTFString();
    str += session_1_feas_.ToTFString();
  }

  return str;
}

void SessionExtractor::ToTFString(std::string* instance) {
  instance->clear();
  instance->reserve(3 << 10);
  *instance = FLAGS_data_flag + "\n";
  if (FLAGS_is_compress_format) {
    *instance += kLabelKey + ToValueString(base::IntToString(label_));
    *instance += user_feas_.ToCompressTFString();
    *instance += main_item_feas_.ToCompressTFString();
    *instance += session_0_feas_.ToCompressTFString();
    *instance += session_1_feas_.ToCompressTFString();
    *instance += "\n";
  } else {
    *instance += kLabelKey + FLAGS_key_equal_mark + base::IntToString(label_) + "\n";
    *instance += user_feas_.ToTFString();
    *instance += main_item_feas_.ToTFString();
    *instance += session_0_feas_.ToTFString();
    *instance += session_1_feas_.ToTFString();
  }
}

bool OnlineSessionFeas::ExtractFeas(const RecoFeasContainer& reco_feas_container,
                                    const int begin,
                                    const int end) {
  if (begin >= end
      || reco_feas_container.reco_feas_vec.size() < (uint32)end) return false;
  Reset();

  for (int i = begin; i < end; ++i) {
    auto& reco_feas = reco_feas_container.reco_feas_vec[i];
    auto& item_id = reco_feas.item_id;
    auto& tags = reco_feas.tags;
    auto& category = reco_feas.category;
    auto& click = reco_feas.click;
    auto& source = reco_feas.source;
    show_item_ids.push_back(item_id);
    for (auto it_tag = tags.begin(); it_tag != tags.end(); ++it_tag) {
      std::string tag = *it_tag;
      show_tags[tag] += 1;
      std::string cate_tag = category + "_" + tag;
      show_cate_tags[cate_tag] += 1;
      if (click) {
        click_tags[tag] += 1;
        click_cate_tags[cate_tag] += 1;
      }
    }

    show_cates[category] += 1;
    show_sources[source] += 1;
    if (click) {
      click_item_ids.push_back(item_id);
      click_cates[category] += 1;
      click_sources[source] += 1;
    }
  }

  return true;
}

std::string OnlineSessionFeas::ToTFString() {
  std::string str;
  str.reserve(2 << 10);
  // item ids
  str = SessionFeasKeys::kSessionShowItemIdsKey[session_id] + FLAGS_key_equal_mark
      + Uint64VectorToString(show_item_ids) + "\n";
  std::string show_item_id_weights = ToWeightString(show_item_ids);
  str += SessionFeasKeys::kSessionShowItemIdsWeightKey[session_id]
      + FLAGS_key_equal_mark + show_item_id_weights + "\n";

  str += SessionFeasKeys::kSessionClickItemIdsKey[session_id] + FLAGS_key_equal_mark
      + Uint64VectorToString(click_item_ids) + "\n";
  std::string click_item_id_weights = ToWeightString(click_item_ids);
  str += SessionFeasKeys::kSessionClickItemIdsWeightKey[session_id]
      + FLAGS_key_equal_mark + click_item_id_weights + "\n";

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // tags
  // show tags
  MapToVectors(show_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click tags
  MapToVectors(click_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // cates
  // show cates
  MapToVectors(show_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCatesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowCatesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click_cates
  MapToVectors(click_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCatesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickCatesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // cate tags
  // show cate tags
  MapToVectors(show_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCateTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowCateTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click cate tags
  MapToVectors(click_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCateTagsKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickCateTagsWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // sources
  // show sources
  MapToVectors(show_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowSourcesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionShowSourcesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  // click sources
  MapToVectors(click_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickSourcesKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(key_list) + "\n";
  str += SessionFeasKeys::kSessionClickSourcesWeightKey[session_id] + FLAGS_key_equal_mark
      + StringVectorToString(value_list) + "\n";

  return str;
}

std::string OnlineSessionFeas::ToCompressTFString() {
  std::string str;
  str.reserve(2 << 10);
  // item ids
  str = SessionFeasKeys::kSessionShowItemIdsKey[session_id]
      + ToValueString(Uint64VectorToString(show_item_ids));
  std::string show_item_id_weights = ToWeightString(show_item_ids);
  str += SessionFeasKeys::kSessionShowItemIdsWeightKey[session_id]
      + ToValueString(show_item_id_weights);

  str += SessionFeasKeys::kSessionClickItemIdsKey[session_id]
      + ToValueString(Uint64VectorToString(click_item_ids));
  std::string click_item_id_weights = ToWeightString(click_item_ids);
  str += SessionFeasKeys::kSessionClickItemIdsWeightKey[session_id]
      + ToValueString(click_item_id_weights);

  std::vector<std::string> key_list;
  std::vector<std::string> value_list;
  // tags
  // show tags
  MapToVectors(show_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowTagsWeightKey[session_id] 
      + ToValueString(StringVectorToString(value_list));

  // click tags
  MapToVectors(click_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // cates
  // show cates
  MapToVectors(show_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCatesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowCatesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click_cates
  MapToVectors(click_cates, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCatesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickCatesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // cate tags
  // show cate tags
  MapToVectors(show_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowCateTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowCateTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click cate tags
  MapToVectors(click_cate_tags, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickCateTagsKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickCateTagsWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // sources
  // show sources
  MapToVectors(show_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionShowSourcesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionShowSourcesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  // click sources
  MapToVectors(click_sources, &key_list, &value_list);
  str += SessionFeasKeys::kSessionClickSourcesKey[session_id]
      + ToValueString(StringVectorToString(key_list));
  str += SessionFeasKeys::kSessionClickSourcesWeightKey[session_id]
      + ToValueString(StringVectorToString(value_list));

  return str;
}
}
}
