import time
import traceback
from odps import ODPS
from odps.models import Schema
from tensorflow.python.platform import tf_logging as logging

KV_SPLIT = chr(1)
odps_end_point = "http://service-corp.odps.aliyun-inc.com/api"


def upload(access_id, access_key, task_id, data_file, project, table_name, ds, field_names, field_types, split_key,
           piece_size=40960000):
    partition = 'ds=' + ds
    odps = ODPS(
        access_id=access_id,
        secret_access_key=access_key,
        project=project,
        endpoint=odps_end_point
    )
    schema = Schema.from_lists(field_names, field_types, partition_names=["ds"], partition_types=["string"])
    for i in range(1, 4):
        try:
            odps_table = odps.create_table(table_name, schema, if_not_exists=True, lifecycle=7)
            odps_table.create_partition(partition, if_not_exists=True)
        except:
            logging.error("Create table or add partition error during {} try".format(i))
        else:
            logging.info("Create table and add partition successfully!")
            break
    with open(data_file, 'r') as f:
        while True:
            lines = f.readlines(piece_size)
            if not lines or len(lines) == 0:
                break
            else:
                start_time = time.time()
                records = list()
                for line in lines:
                    records.append(line[:-1].split(split_key))
                for i in range(1, 4):
                    flag = write(odps_table, partition, task_id, records)
                    if flag:
                        break
                    else:
                        logging.info("open_writer ready to retry")
                        continue
                cost = time.time() - start_time
                logging.info("writing [%s.%s/ds=%s] to file len--> %d cost --> %d s" % (
                    project, table_name, ds, len(lines), cost))
    logging.info("Finish uploading")


def write(table, partition, task_id, records):
    try:
        with table.open_writer(partition=partition, blocks=[task_id], reopen=True) as writer:
            for record in records:
                table_record = table.new_record(record)
                writer.write(task_id, table_record)
        return True
    except Exception:
        logging.error('writer : %s' % traceback.format_exc())
        return False
