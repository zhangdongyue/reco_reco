# -*- coding: utf-8 -*-

import time
import os
import json
import traceback
import contextlib
import odps as Odps
import multiprocessing
import tensorflow as tf
from tensorflow.python.lib.io import file_io
from train.utils import parse_features
from smart_io.console_log import log, log_error

try:
    from tensorflow.python.platform import tf_logging as logging
except ImportError:
    import logging
from filesystem import HDFSFilesystem, LocalFilesystem

online_end_point = 'http://service-corp.odps.aliyun-inc.com/api'
daily_end_point = 'http://service.odps.aliyun-inc.com/api'


def _retry_writer(parser, retry_times, *args, **kwargs):
    while retry_times > 0:
        try:
            return parser(*args, **kwargs)
        except Exception:
            logging.error('exception happend: %d times rety left', retry_times)
            logging.error('---------------------------------------------------')
            logging.error(traceback.format_exc())
            logging.error('---------------------------------------------------')
            retry_times -= 1
    raise Exception('all retry failed')


def _default_parser(dst_dir, table, partition, file_name, start, end, filesystem, field_delim):
    dest_file = os.path.join(dst_dir, file_name)
    if filesystem.exists(dest_file):
        logging.info('%s exists, no need to download', dest_file)
        return [dest_file]
    logging.info('download file begin -> %s', dest_file)
    tmp_file = dest_file + '.tmp'
    with table.open_reader(partition=partition) as reader:
        with filesystem.open_file(tmp_file) as f:
            counter = 0
            one_percent_count = max(int((end - start) / 100.0), 1)
            for record in reader[start:end]:
                record_value = ""
                for column in table.schema.simple_columns:
                    value = record[column.name]
                    if value is None:
                        field_value = ''
                    elif type(value) is not unicode:
                        field_value = str(value)
                    else:
                        field_value = value.encode('utf-8')
                    if field_delim in field_value:
                        logging.info('partition %s file %s record %s field %s %s is invalid',
                                     partition, tmp_file, str(record), column.name, field_value)
                        field_value = field_value.replace(field_delim, '')
                    record_value += field_value
                    record_value += field_delim
                record_value = record_value[0:len(record_value) - 1]
                record_value += "\n"
                counter += 1
                if counter % one_percent_count == 0:
                    logging.info('download %s progress: %d%%',
                                 dest_file, counter / one_percent_count)
                f.write(record_value)
    filesystem.rename(tmp_file, dest_file)
    logging.info('download file end -> %s', dest_file)
    return [dest_file]


def tf_record_parser(dst_dir, table, partition, file_name, start, end, filesystem, field_delim, **kwargs):
    dest_file = os.path.join(dst_dir, file_name)
    if filesystem.exists(dest_file):
        logging.info('%s exists, no need to download' % dest_file)
        filesystem.rm(dest_file)
    #    return [dest_file]
    feature_conf_file = kwargs.get('feature_conf_file')
    label_conf = kwargs.get("label_conf")
    feature_type_map = _parse_feature_conf(feature_conf_file)
    dest_file = "/".join(feature_conf_file.split("/")[:-1] + [file_name])
    tmp_file = dest_file + '.tmp'
    logging.info('download file begin -> %s' % dest_file)
    logging.info('shared_download_id is %s' % kwargs.get("shared_download_id"))
    # with table.open_reader(partition=partition) as reader:
    with open_table_reader(table=table, shared_download_id=kwargs.get('shared_download_id'),
                           partition=partition) as reader:
        with tf.python_io.TFRecordWriter(tmp_file) as record_writer:
            counter, one_percent_count = 0, max(int((end - start) / 100.0), 1)
            for record in reader[start:end]:
                try:
                    feature_map = {
                        #"label": tf.train.Feature(int64_list=tf.train.Int64List(value=[int(record['label'].split(";")[0])]))
                        "label": tf.train.Feature(
                            float_list=tf.train.FloatList(value=[float(
                                record['label'].split(";")[label_conf])]))
                    }
                    if counter == 0 or counter == 1:
                        logging.info("label is %s"%(record['label'].split(";")[label_conf],))
                        logging.info("record 1  %s, fnum=%d"%(record, len(feature_type_map.items())))
                        for fname, ftype in feature_type_map.items():
                            logging.info("%s,%s"%(fname, ftype))
                    features = parse_features(record['features'], chr(2), chr(3))
                    for feature_name, feature_type in feature_type_map.items():
                        if feature_type.lower() == 'double':
                            feature_value = float(features[feature_name]) if feature_name in features else 0.0
                            feature_map[feature_name] = tf.train.Feature(
                                float_list=tf.train.FloatList(value=[feature_value]))
                        elif feature_type.lower() == 'int':
                            feature_value = int(features[feature_name]) if feature_name in features else 0
                            feature_map[feature_name] = tf.train.Feature(
                                int64_list=tf.train.Int64List(value=[feature_value]))
                        else:
                            feature_value = features[feature_name] if feature_name in features else ""
                            value_list = feature_value.split("`")
                            new_list = map(lambda value: value.encode('utf-8') if value.startswith(feature_name) else "_".join([feature_name, value]).encode('utf-8'), value_list)
                            if counter == 0:
                                logging.info("feature_name:%s, feature_value:%s"%(feature_name, new_list))
                            feature_map[feature_name] = tf.train.Feature(
                                bytes_list=tf.train.BytesList(value=new_list))
                    example = tf.train.Example(
                        features=tf.train.Features(
                            feature=feature_map
                        )
                    )
                    record_writer.write(example.SerializeToString())
                except ValueError:
                    logging.error(traceback.format_exc())
                    logging.error("[Bad entry format] %s" % record)

                counter += 1
                if counter % one_percent_count == 0:
                    logging.info('download %s progress: %d%%' % (dest_file, counter / one_percent_count))
    # filesystem.rename(tmp_file, dest_file)
    filesys = LocalFilesystem()
    filesys.rename(tmp_file, dest_file)
    logging.info('download file end -> %s' % dest_file)
    return [dest_file]


def _parse_feature_conf(feature_conf_file):
    feature_conf_json = json.load(file_io.FileIO(feature_conf_file, 'r'))
    return {feature_conf['feature_name']: feature_conf['value_type'] for feature_conf in
            feature_conf_json['features']}


def _get_filesystem(path, system_type=None):
    if system_type is not None:
        assert system_type in ('hdfs', 'local'), "Unknown filesystem %s" % system_type
        return HDFSFilesystem() if system_type == 'hdfs' else LocalFilesystem()
    else:
        return HDFSFilesystem() if path.startswith('hdfs://') else LocalFilesystem()


def pre_check_if_file_exists(target_file_num, task_id, filesystem, dst_dir):
    expect = []
    exists = filesystem.list(dst_dir)
    for i in range(target_file_num):
        file_name = "instd_%s_%s" % (task_id, i)
        if file_name not in exists:
            logging.info("file {} not downloaded yet, will download again ...".format(file_name))
            return []
        else:
            expect.append(os.path.join(dst_dir, file_name))
    return expect


class OdpsDownload:
    def __init__(self, access_id, access_key, project, task_id, worker_num, process_count=3, env='online'):
        self._access_id = access_id
        self._access_key = access_key
        self._project = project
        self._env = env
        self._process_count = process_count
        self._worker_num = worker_num
        self._task_id = task_id

    def download(self, table_name, partition, dst_dir, filesystem=None, field_delim=',', retry_times=5,
                 parser=_default_parser, **kwargs):
        filesystem = _get_filesystem(dst_dir, filesystem)
        if not filesystem.exists(dst_dir):
            logging.info("target dir does not exists, will create it!")
            filesystem.mkdir(dst_dir)

        odps = Odps.ODPS(self._access_id, self._access_key, self._project,
                         online_end_point if self._env == 'online' else daily_end_point)
        table = odps.get_table(table_name)
        table_schema = [(column.name, str(column.type).lower())
                        for column in table.schema.columns]

        target_file_num = self._process_count
        total_file_num = kwargs.get("total_file_num")
        if total_file_num:
            target_file_num = total_file_num / self._worker_num
        dest_files = pre_check_if_file_exists(target_file_num, self._task_id, filesystem, dst_dir)
        dest_files = []
        # if dest_files:
        #     logging.info("All files exist, no need to download")
        #     return dest_files, table_schema

        # wait_for_partition_ready(table, partition)
        logging.info("task id is %d, will download %s %s ", self._task_id, table_name, partition)
        # with table.open_reader(partition=partition) as reader:
        shared_download_id = new_session_and_sync(filesystem, table, partition, self._task_id, dst_dir)
        kwargs['shared_download_id'] = shared_download_id
        logging.info("shared download id %s", shared_download_id)
        totalcount = 0
        with open_table_reader(table=table, shared_download_id=shared_download_id, partition=partition) as reader:
            totalcount = reader.count
        count = totalcount
        logging.info("total count is %d", count)
        worker_count = count / self._worker_num
        start = self._task_id * count / self._worker_num
        start_time = time.time()
        if worker_count < target_file_num:
            target_file_num = worker_count
        pool = multiprocessing.Pool(
            processes=self._process_count if self._process_count < worker_count else worker_count)
        result = []
        for i in range(target_file_num):
            process_start = start + worker_count * i / target_file_num
            process_end = start + worker_count * (i + 1) / target_file_num
            if i == target_file_num - 1:
                process_end = (self._task_id + 1) * count / self._worker_num
            file_name = "instd_%s_%s" % (self._task_id, i)
            logging.info("[%d] process start is %d, and process end is %d", i, process_start, process_end)
            result.append(
                pool.apply_async(_retry_writer, (
                    parser or _default_parser, retry_times, dst_dir, table, partition, file_name, process_start,
                    process_end,
                    filesystem, field_delim), kwargs))
        pool.close()
        pool.join()
        end_time = time.time()
        for res in result:
            dest_files += res.get()
        if len(dest_files) == target_file_num:
            logging.info("download completed %d", target_file_num)
        logging.info("the total time cost is %d", (end_time - start_time))
        return dest_files, table_schema


def download_data_from_odps_table(project, access_id, access_key, table_name, partition, task_id, worker_num,
                                  target_dir, odps_read_process=4, env='online', parser=None, filesystem=None,
                                  **kwargs):
    downloader = OdpsDownload(access_id=access_id,
                              access_key=access_key,
                              project=project,
                              task_id=task_id,
                              worker_num=worker_num,
                              process_count=odps_read_process,
                              env=env)
    filesys = _get_filesystem(target_dir, filesystem)
    if filesys.exists(os.path.join(target_dir, "_SUCCESS")) and task_id == 0:
        filesys.rm(os.path.join(target_dir, "_SUCCESS"))
    if task_id != 0:
        time.sleep(20)
    if isinstance(partition, str):
        files, schema = downloader.download(table_name, partition, target_dir, filesystem=filesystem, parser=parser,
                                            **kwargs)
    elif isinstance(partition, list):
        files, schema = [], None
        for one_partition in partition:
            one_files, schema = downloader.download(table_name, one_partition, target_dir, parser=parser, **kwargs)
            files += one_files
    else:
        raise Exception('unkown partition format %s' % partition)

    logging.info("target dir = %s", target_dir)
    logging.info("training files = %s", files)
    if task_id == 0:
        feature_conf_file = kwargs.get('feature_conf_file')
        filesystem = HDFSFilesystem()
        filesystem.put(feature_conf_file, os.path.join(target_dir, '_SUCCESS'))
    return files, schema


@contextlib.contextmanager
def open_table_reader(table, shared_download_id, partition=None, **kw):
    endpoint = kw.pop('endpoint', None)
    tunnel = table._create_table_tunnel(endpoint=endpoint)
    download_session = tunnel.create_download_session(table=table, partition_spec=partition,
                                                      download_id=shared_download_id, **kw)
    table._download_ids[partition] = shared_download_id

    from odps import readers

    class RecordReader(readers.AbstractRecordReader):
        def __init__(self):
            self._it = iter(self)

        @property
        def count(self):
            return download_session.count

        @property
        def status(self):
            return download_session.status

        def __iter__(self):
            for record in self.read():
                yield record

        def __next__(self):
            return next(self._it)

        next = __next__

        def _iter(self, start=None, end=None, step=None):
            count = self._calc_count(start, end, step)
            return self.read(start=start, count=count, step=step)

        def read(self, start=None, count=None, step=None,
                 compress=False, columns=None):
            start = start or 0
            step = step or 1
            count = count * step if count is not None else self.count - start

            if count == 0:
                return

            with download_session.open_record_reader(
                    start, count, compress=compress, columns=columns) as reader:
                for record in reader[::step]:
                    yield record

    yield RecordReader()


def new_session_and_sync(filesystem, table, partition, task_id, dst_dir):
    import cPickle as pickle
    download_id_file_name = 'download_id'
    remote_download_id_file_name = '{}_{}'.format(dst_dir, download_id_file_name)
    if task_id == 0:
        # if filesystem.exists(remote_download_id_file_name):
        #     log("Chief work is getting existing download session id")
        #     filesystem.get(remote_download_id_file_name, download_id_file_name)
        #     with open(download_id_file_name, 'rb') as input_file:
        #         log("Now loading download session id ...")
        #         return pickle.load(input_file)
        log("Chief work is now creating download session ...")
        tunnel = table._create_table_tunnel()
        for i in range(10):
            try:
                download_session = tunnel.create_download_session(table=table, partition_spec=partition)
                break
            except Exception:
                log_error('-------------------------------------------')
                log_error(traceback.format_exc())
                log_error('-------------------------------------------')
                time.sleep(300)
        else:
            raise ValueError('Try to create odps download session 10 times still failed!')
        with open(download_id_file_name, 'wb') as output:
            pickle.dump(download_session.id, output, pickle.HIGHEST_PROTOCOL)
        filesystem.put(download_id_file_name, remote_download_id_file_name)
        return download_session.id

    else:
        while not filesystem.exists(remote_download_id_file_name):
            log("Chief has not create odps download session yet, sleep 30s ...")
            time.sleep(30)
        else:
            filesystem.get(remote_download_id_file_name, download_id_file_name)
            with open(download_id_file_name, 'rb') as input_file:
                log("Now loading download session id ...")
                return pickle.load(input_file)


def wait_for_partition_ready(table, target_partition):
    partition_list = get_partition_list(table)
    tmp_partition = target_partition+".done"
    count = 0
    while tmp_partition not in partition_list:
        if count % 30 == 0:
            log("Partition {} of table {} not ready yet, sleep 5 min ...".format(target_partition, table.name))
        time.sleep(10)
        count += 1
        partition_list = get_partition_list(table)

def get_last_partition(table):
    partition_list = get_partition_list(table)
    partition_list.sort()
    tmp_list = partition_list[-2:]
    logging.info("partitions %s", tmp_list)
    return tmp_list[0]


def get_partition_list(table):
    partition_list = None
    while partition_list is None:
        try:
            partition_list = [str(partition).replace("'", '') for partition in table.iterate_partitions()]
        except:
            log_error(traceback.format_exc)
            time.sleep(5)
    return partition_list

if __name__ == '__main__':
    print(_parse_feature_conf('/Users/stallone/Downloads/aioplus_wdl.json'))
