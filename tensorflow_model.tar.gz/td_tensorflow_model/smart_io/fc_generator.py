# coding=utf-8
import json
import tensorflow as tf
from tensorflow.contrib import layers
from tensorflow.contrib.layers.python.layers.feature_column import _SparseColumnHashed
from tensorflow.python.platform import tf_logging as logging


class FeatureConfKeys(object):
    SAMPLE_ID = 'id'
    SAMPLE_LABEL = 'label'
    FEATURES = 'features'
    VALUE_TYPE = 'value_type'
    FEATURE_TYPE = 'feature_type'
    FEATURE_NAME = 'feature_name'


class FeatureColumnGenerator(object):
    def __init__(self, conf_file_path, has_label=True, has_sample_id=False):
        # Parse feature conf file
        self._feature_map = dict()
        if has_label:
            self._feature_map[FeatureConfKeys.SAMPLE_LABEL] = tf.FixedLenFeature([1], tf.float32)
        if has_sample_id:
            self._feature_map[FeatureConfKeys.SAMPLE_ID] = tf.FixedLenFeature([1], tf.string)
        self._feature_conf_map = dict()
        with open(conf_file_path) as f:
            config = json.load(f)
            self._feature_conf_list = config[FeatureConfKeys.FEATURES]
            self._build_feature_map(self._feature_conf_list)

        # Generate features
        self._wide_feature_list = []
        self._wide_dim = 0
        self._deep_feature_list = []
        self._deep_dim = 0
        self._feature_list = list()
        self._feature_column_conf = dict()
        self._generate_features()

    def _generate_features(self):
        shared_feature_map = dict()
        for key, value in self._feature_conf_map.items():
            if 'shared_embedding_name' in value:
                shared_embedding_name = value['shared_embedding_name']
                shared_feature_map[shared_embedding_name].append(
                    value) if shared_embedding_name in shared_feature_map else shared_feature_map.setdefault(
                    shared_embedding_name, [value])
            else:
                feature = self._new_feature(key, value)
                self._wide_feature_list.append(
                    feature) if isinstance(feature, _SparseColumnHashed) else self._deep_feature_list.append(feature)
                self._feature_list.append(feature)
                self._feature_column_conf[feature] = value
        # generate share embedding features
        for key, value in shared_feature_map.items():
            sparse_id_columns = [layers.sparse_column_with_hash_bucket(
                column_name=feature_conf[FeatureConfKeys.FEATURE_NAME],
                hash_bucket_size=feature_conf['hash_bucket_size']) for feature_conf in value]
            combiner = _get_combiner(value[0])
            dimension = value[0]['embedding_dimension']
            shared_embedding_columns = layers.shared_embedding_columns(sparse_id_columns, dimension, combiner, key)
            for feature_conf, column in zip(value, shared_embedding_columns):
                self._feature_list.append(column)
                self._deep_feature_list.append(column)
                self._deep_dim += int(dimension)
                self._feature_column_conf[column] = feature_conf

    def _new_feature(self, name, feature_conf):
        """
        新建feature_column，模型训练时使用
        :param name: 特征名称
        :param feature_conf: 特征配置
        :return: 返回一个新建的feature_column
        """
        if "wide_feature" in feature_conf and feature_conf["wide_feature"]:
            self._wide_dim += 1
            return layers.sparse_column_with_hash_bucket(column_name=name,
                                                         hash_bucket_size=feature_conf['hash_bucket_size'],
                                                         combiner=_get_combiner(feature_conf))
        elif "embedding_dimension" in feature_conf and "hash_bucket_size" in feature_conf:
            if 'serialized' in feature_conf and feature_conf['serialized']:
                self._deep_dim += int(feature_conf['embedding_dimension'])
                logging.info("Feature %s is claimed to be serialized!", name)
                return layers.embedding_column(
                    sparse_id_column=layers.sparse_column_with_integerized_feature(
                        column_name=name,
                        bucket_size=feature_conf['hash_bucket_size'], combiner=_get_combiner(feature_conf)
                    ), dimension=feature_conf['embedding_dimension'], combiner=_get_combiner(feature_conf))
            else:
                self._deep_dim += int(feature_conf['embedding_dimension'])
                id_feature = layers.sparse_column_with_hash_bucket(
                    column_name=name,
                    hash_bucket_size=feature_conf['hash_bucket_size'],
                    combiner=_get_combiner(feature_conf))
                return layers.embedding_column(
                    id_feature,
                    dimension=feature_conf['embedding_dimension'],
                    combiner=_get_combiner(feature_conf))
        else:
            self._deep_dim += 1
            return layers.real_valued_column(column_name=name, default_value=0.0)

    def _build_feature_map(self, feature_conf_list):
        """
        用于读入数据，与离线产出TFRecords的MR任务配合使用
        :param feature_conf_list: 每个feature的配置
        :return: 填充self._feature_map
        """
        for feature_conf in feature_conf_list:
            feature_name = feature_conf[FeatureConfKeys.FEATURE_NAME]
            value_type = feature_conf[FeatureConfKeys.VALUE_TYPE]
            self._feature_conf_map[feature_name] = feature_conf

            if "hash_bucket_size" not in feature_conf:
                if value_type == "Double":
                    self._feature_map[feature_name] = tf.FixedLenFeature([1], tf.float32)
                elif value_type == "Float":
                    self._feature_map[feature_name] = tf.FixedLenFeature([1], tf.float32)
                elif value_type == "Int":
                    self._feature_map[feature_name] = tf.FixedLenFeature([1], tf.int64)
                elif value_type == "String":
                    self._feature_map[feature_name] = tf.FixedLenFeature([1], tf.string)
            else:
                if value_type == "Double":
                    self._feature_map[feature_name] = tf.VarLenFeature(tf.float32)
                elif value_type == "Float":
                    self._feature_map[feature_name] = tf.VarLenFeature(tf.float32)
                elif value_type == "Int":
                    self._feature_map[feature_name] = tf.VarLenFeature(tf.int64)
                elif value_type == "String":
                    self._feature_map[feature_name] = tf.VarLenFeature(tf.string)

    def feature_value_type(self, feature_name):
        if feature_name in self._feature_conf_map:
            return self._feature_conf_map[feature_name][FeatureConfKeys.VALUE_TYPE]
        else:
            return None

    @property
    def feature_conf_map(self):
        return self._feature_conf_map

    @property
    def feature_map(self):
        return self._feature_map

    @property
    def wide_feature_list(self):
        return self._wide_feature_list

    @property
    def deep_feature_list(self):
        return self._deep_feature_list

    @property
    def feature_list(self):
        return self._feature_list

    @property
    def feature_column_conf(self):
        return self._feature_column_conf

    @property
    def get_wide_dim(self):
        return self._wide_dim

    @property
    def get_deep_dim(self):
        return self._deep_dim

def _get_combiner(feature_conf):
    if "combiner" in feature_conf:
        return feature_conf["combiner"]
    else:
        return "sum"


if __name__ == '__main__':
    fg = FeatureColumnGenerator('../config/yk_guesslike_wdl_feature_conf_v1.json')
    print ("deep : %d" % len(fg.deep_feature_list))
    print ("wide : %d" % len(fg.wide_feature_list))
    print ("dim: %d, %d" % (fg.get_wide_dim, fg.get_deep_dim))
