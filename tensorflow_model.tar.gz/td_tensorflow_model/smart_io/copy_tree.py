from tensorflow.python.lib.io import file_io
import os


def copy_tree(src, dst, overwrite):
    """ recursive copy hdfs files
    :param src: string, name of the file or folder who's contents need to be copied
    :param dst: string, name of the folder to which to copy to
    :param overwrite:  boolean, if false its an error for newpath to be occupied by an
        existing file.
    """
    names = file_io.list_directory(src)
    file_io.recursive_create_dir(dst)

    for name in names:
        srcname = os.path.join(src, name)
        dstname = os.path.join(dst, name)

        if file_io.is_directory(srcname):
            copy_tree(srcname, dstname, overwrite)
        else:
            file_io.copy(srcname, dstname, overwrite=overwrite)
