from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import inspect
import multiprocessing
import time
import os
import odps as Odps
import traceback


from smart_io.console_log import log

try:
    from hdfs_client import get_hdfs_client, client
except ImportError:
    log("hdfs_client is not included")

online_end_point = 'http://service-corp.odps.aliyun-inc.com/api'
daily_end_point = 'http://service.odps.aliyun-inc.com/api'


class VolumeDumper:
    '''
    piece_size: Byte
    '''

    def __init__(self, access_id, access_key, project, piece_size=40960000, process_count=10, env='online'):
        self._access_id = access_id
        self._access_key = access_key
        self._project = project
        self._piece_size = piece_size
        self._process_count = process_count
        self._env = env

    '''
        volume_name : first level of project
        partition : path to of final dir
        dst_dir : data_dir

        Examples: /yuanfang/wdl4/20160917_worker_48_instid_248.tfrecords
        volume_name: yuanfang
        partiton:wdl4
        prefix:20160917_worker_48

    '''

    def download_tohdfs(self, volume_name, partition, part, worker_num, dst_dir, hack_count=None):
        while True:
            try:
                # thread
                start_time = time.time()
                odps = Odps.ODPS(self._access_id, self._access_key, self._project,
                                 online_end_point if self._env == 'online' else daily_end_point)
                files = odps.list_volume_files(volume_name, partition)
                if inspect.ismethod(files):
                    files = files()

                tf_files = list()
                for file in files:
                    file_name = file.name
                    index = file_name.find("instid")
                    if index < 0:
                        break
                    index_end = file_name.find("tfrecords")
                    instid = int(file_name[7 + index:index_end - 1])
                    if instid % worker_num == part:
                        tf_files.append(file_name)
                if hack_count:
                    tf_files = tf_files[0:hack_count]

                log('TF files [Totally %d]: %s' % (len(tf_files), tf_files))
                log('dst_dir:%s' % dst_dir)
                # hdfs_exist_files = client.list(dst_dir)
                # log("hdfs_exist_files = %s" % hdfs_exist_files)
                # client.status(hdfs_path=dst_dir, strict=False)
                not_exists_files = []
                dest_files = []

                hdfs_exist_files = []
                dst_dir_exist = True if client.status(hdfs_path=dst_dir, strict=False) is not None else False
                if dst_dir_exist:
                    hdfs_exist_files = client.list(dst_dir)
                    log("dst dir = %s" % dst_dir)
                    log("dst dir contains = %s" % hdfs_exist_files)
                else:
                    log("oh no dst_dir:%s" % dst_dir)

                for f in tf_files:
                    if dst_dir_exist and ("%s.done" % f) in hdfs_exist_files and f in hdfs_exist_files:
                        log("file exists : %s" % f)
                        dest_files.append(dst_dir + "/" + f)
                    elif dst_dir_exist and ("%s.done" % f) not in hdfs_exist_files and f in hdfs_exist_files:
                        log("file exists [%s], but not done completely, download again." % f)
                        not_exists_files.append(f)
                    else:
                        log("file to download : %s" % f)
                        not_exists_files.append(f)

                self._process_count = min(len(not_exists_files), self._process_count)
                if self._process_count <= 0:
                    return dest_files
                split_files = div_list(not_exists_files, self._process_count)

                result = []
                pool = multiprocessing.Pool(processes=self._process_count)
                for file_names in split_files:
                    result.append(
                        pool.apply_async(_write_hdfs,
                                         (dst_dir, file_names, odps, volume_name, partition, self._piece_size))
                    )

                pool.close()
                pool.join()

                for res in result:
                    dest_files += res.get()

                cost = time.time() - start_time
                log("writing tf records to file cost --> %d s" % cost)
                return dest_files
            except Exception as e:
                log('yy')
                log(repr(e))
                log('traceback.print_exc():%s' % traceback.print_exc())
                log("failed download odps [%s] in prefix, try again" % (e))
                time.sleep(60)

    def download(self, volume_name, partition, prefix, dst_dir, hack_count=None):
        while True:
            try:
                # thread
                start_time = time.time()
                odps = Odps.ODPS(self._access_id, self._access_key, self._project,
                                 online_end_point if self._env == 'online' else daily_end_point)
                files = odps.list_volume_files(volume_name, partition)
                if inspect.ismethod(files):
                    files = files()

                tf_files = list()
                for file in files:
                    file_name = file.name
                    if file_name.startswith(prefix):
                        tf_files.append(file_name)
                if hack_count:
                    tf_files = tf_files[0:hack_count]

                log('TF files [Totally %d]: %s' % (len(tf_files), tf_files))

                not_exists_files = []
                dest_files = []
                for f in tf_files:
                    if not os.path.exists(dst_dir + "/" + f):
                        not_exists_files.append(f)
                        log("file [not] exists : %s" % f)
                    else:
                        log("file exists : %s" % f)
                        dest_files.append(dst_dir + "/" + f)

                self._process_count = min(len(not_exists_files), self._process_count)
                if self._process_count <= 0:
                    return dest_files
                split_files = div_list(not_exists_files, self._process_count)
                result = []
                pool = multiprocessing.Pool(processes=self._process_count)
                for file_names in split_files:
                    result.append(
                        pool.apply_async(_write, (dst_dir, file_names, odps, volume_name, partition, self._piece_size))
                    )

                pool.close()
                pool.join()

                for res in result:
                    dest_files += res.get()

                cost = time.time() - start_time
                log("writing tf records to file cost --> %d s" % cost)
                return dest_files
            except Exception as e:
                print("failed download odps [%s] in prefix [%s], try again" % (e, prefix))
                time.sleep(60)


def div_list(ls, n):
    if not isinstance(ls, list) or not isinstance(n, int):
        return []
    ls_len = len(ls)
    if n <= 0 or 0 == ls_len:
        return []
    if n > ls_len:
        return []
    elif n == ls_len:
        return [[i] for i in ls]
    else:
        j = ls_len // n
        k = ls_len % n
        ls_return = []
        for i in xrange(0, (n - 1) * j, j):
            ls_return.append(ls[i:i + j])
        ls_return.append(ls[(n - 1) * j:])
        return ls_return


def _write_hdfs(dst_dir, file_names, odps, volume_name, partition, piece_size):
    new_client = get_hdfs_client()
    dest_files = list()
    for file_name in file_names:
        dest_file = dst_dir + "/" + file_name
        log('TF file begin ->%s' % dest_file)
        start = time.time()
        with new_client.write(dest_file, overwrite=True) as writer, \
                odps.open_volume_reader(volume_name, partition, file_name) as reader:
            while True:
                piece = reader.read(piece_size)
                if not piece:
                    break
                writer.write(piece)

        new_client2 = get_hdfs_client()
        with new_client2.write(dest_file + ".done", overwrite=True) as done_write:
            done_write.write("done with %s" % dest_file)

        end = time.time()
        log('Cost %s s' % (end - start))
        log('TF file finished ->%s' % dest_file)
        dest_files.append(dest_file)
    return dest_files


def _write(dst_dir, file_names, odps, volume_name, partition, piece_size):
    dest_files = list()
    for file_name in file_names:
        dest_file = dst_dir + "/" + file_name

        log('TF file begin ->%s' % dest_file)

        with open(dest_file, 'wb') as f:
            with odps.open_volume_reader(volume_name, partition, file_name) as reader:
                while True:
                    piece = reader.read(piece_size)
                    if not piece:
                        break  # end of file
                    f.write(piece)
                    f.flush()
        log('TF file finished ->%s' % dest_file)
        dest_files.append(dest_file)
    return dest_files
