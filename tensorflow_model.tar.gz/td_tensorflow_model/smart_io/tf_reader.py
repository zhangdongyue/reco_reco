from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import tensorflow as tf
from smart_io.graph_io import read_batch_record_features, read_batch_features
from smart_io.volume_downloader import VolumeDumper
from smart_io.console_log import log

try:
    from hdfs_client import *
except ImportError:
    log("hdfs_client is not included")

FLAGS = tf.app.flags.FLAGS


def feature_map(tf_conf):
    return tf_conf.get_tf_feature_map()


def read_tf_records_from_odps_volume(project, access_id, access_key, part, volume_name, volume_partition,
                                     piece_size=40960000,
                                     process_count=10,
                                     hack_count=None, env='online'):
    target_dir = os.path.join(FLAGS.work_dir + "/" + FLAGS.data_dir)
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
    prefix = '%s_worker' % part
    return VolumeDumper(
        access_id=access_id,
        access_key=access_key,
        project=project,
        piece_size=piece_size,
        process_count=process_count,
        env=env
    ).download(
        volume_name,
        volume_partition,
        prefix,
        target_dir,
        hack_count
    )


def read_tf_records_from_odps_volume_tohdfs(project, access_id, access_key, part, volume_name, volume_partition,
                                            worker_num,
                                            piece_size=40960000,
                                            process_count=10,
                                            hack_count=None, env='online'):
    target_dir = r"%s/%s/%s" % (FLAGS.work_dir, volume_name, volume_partition)
    dest_files = VolumeDumper(access_id=access_id, access_key=access_key, project=project, piece_size=piece_size,
                              process_count=process_count, env=env).download_tohdfs(volume_name, volume_partition, part,
                                                                                    worker_num=worker_num,
                                                                                    dst_dir=target_dir,
                                                                                    hack_count=hack_count)
    if not target_dir.startswith('hdfs://'):
        hdfs_prefix = get_defaultFS()
        dest_files = ["%s%s" % (hdfs_prefix, f) for f in dest_files]
    log("[part = %d] training hdfs files = %s" % (part, dest_files))
    return dest_files


def build_features_from_tf_records(tf_record_file_list, feature_map, batch_size, capacity, num_threads=2,
                                   num_epochs=None,
                                   name='build_features_from_tf_records'):
    features = read_batch_record_features(
        tf_record_file_list, batch_size,
        features=feature_map,
        randomize_input=True,
        queue_capacity=capacity,
        reader_num_threads=num_threads,
        num_epochs=num_epochs,
        name=name
    )
    return features


def download_files_from_volume(
        odps_id,
        odps_key,
        part,
        project,
        volume,
        partition,
        worker_num,
        file_count=None,
        process_count=9,
        env="online"):
    return read_tf_records_from_odps_volume_tohdfs(
        project=project,
        access_id=odps_id,
        access_key=odps_key,
        part=part,
        volume_name=volume,
        volume_partition=partition,
        worker_num=worker_num,
        piece_size=404800000,
        hack_count=file_count,
        process_count=process_count,
        env=env
    )


def build_batch_from_tf_records(file_list, feature_map, batch_size=200, capacity=5000, num_threads=1, num_epochs=None):
    """
    :param file_list:
    :param feature_map:
    :param batch_size:
    :param capacity:
    :param num_threads:
    :param num_epochs:
    :return: features is a map feature_name -> Tensor/SparseTensor
    """
    features = build_features_from_tf_records(
        tf_record_file_list=file_list,
        feature_map=feature_map,
        batch_size=batch_size,
        capacity=capacity,
        num_threads=num_threads,
        num_epochs=num_epochs,
        name="resulting_op"
    )
    return features, features['label']


def build_features_from_text(file_list, feature_map, batch_size=200, capacity=5000, num_threads=64, num_epochs=None):
    features = read_batch_features(
        file_pattern=file_list,
        batch_size=batch_size,
        features=feature_map,
        reader=tf.io_ops.TextLineReader,
        randomize_input=True,
        queue_capacity=capacity,
        reader_num_threads=num_threads,
        num_epochs=num_epochs,
        name="build_features_from_text"
    )
    return features


def bulid_batch_from_text(file_list, feature_map, batch_size=200, capacity=5000, num_threads=64, num_epochs=None):
    features = build_features_from_text(
        file_list,
        feature_map,
        batch_size,
        capacity,
        num_threads,
        num_epochs=num_epochs,
    )
    return features, features['label']
