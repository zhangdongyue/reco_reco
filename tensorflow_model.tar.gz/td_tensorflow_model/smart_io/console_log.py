from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import time
from tensorflow.python.platform import tf_logging as logging


def log_every_N(msg, current_n, every_N=1000):
    if current_n % every_N == 0:
        logging.info(time.strftime('%Y-%m-%d %H:%M:%S') + " - {}".format(msg))


def log(msg):
    logging.info(time.strftime('%Y-%m-%d %H:%M:%S') + " - {}".format(msg))


def log_error(msg):
    logging.error(time.strftime('%Y-%m-%d %H:%M:%S') + " - {}".format(msg))
