from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import sys
import Queue
import threading
import tensorflow as tf
from tensorflow.python.training.session_run_hook import SessionRunHook

FLAGS = tf.app.flags.FLAGS
inputQueue = Queue.Queue(maxsize=200)


def get_default_value(type):
    if type == "String":
        return ""
    elif type == "Int":
        return 0
    elif type == "Double":
        return 0.0
    elif type == "Float":
        return 0.0
    else:
        return ""


def get_tf_type(type):
    if type == "String":
        return tf.string
    elif type == "Int":
        return tf.int32
    elif type == "Double":
        return tf.float32
    elif type == "Float":
        return tf.float32
    else:
        return tf.string


def transform_to_tensor(type, value):
    if type == "String":
        return value
    elif type == "Int":
        return tf.string_to_number(value, out_type=get_tf_type(type))
    elif type == "Double":
        return tf.string_to_number(value, out_type=get_tf_type(type))
    elif type == "Float":
        return tf.string_to_number(value, out_type=get_tf_type(type))
    else:
        return value


def parse_record(record, source_schema, full_schema):
    res = []
    dict = {}
    fields = record.split('\t')  # id, features, label, type
    schemas = source_schema.split(',')
    for idx, field_name in enumerate(schemas):
        if field_name == "features":
            kv_array = fields[idx].split(chr(2))
            for tmp in kv_array:
                kv = tmp.split(chr(3))
                key = kv[0]
                value = kv[1]
                dict[key] = value
        else:
            dict[field_name] = fields[idx]
    for featureItem in full_schema:
        feature_name = featureItem.get_feature_name()
        feature_type = featureItem.get_feature_type()
        if dict.has_key(feature_name):
            res.append(str(dict[feature_name]))
        else:
            res.append(str(get_default_value(feature_type)))
    return res


class FeedHook(SessionRunHook):
    def __init__(self, batch_size, env, source_schema, full_schema):
        self.batch_size = batch_size
        self.env = env
        self.source_schema = source_schema
        self.full_schema = full_schema

    def batch_thread(self, coord):
        batch_list = []
        batch_num = 0
        while not coord.should_stop():
            records = self.env.data_service().takeMany()
            for record in records:
                singleRecord = parse_record(str(record), self.source_schema, self.full_schema)
                batch_list.append(singleRecord)
                batch_num += 1
                if self.batch_size == batch_num:
                    inputQueue.put(batch_list)
                    batch_list = []
                    batch_num = 0

    def input_thread(self, session, coord):
        with session.as_default():
            while not coord.should_stop():
                feed_dict = {input_placeholder: inputQueue.get()}
                session.run(enqueue_op, feed_dict=feed_dict)

    def after_create_session(self, session, coord):
        batch_threads = [threading.Thread(target=self.batch_thread, args=(coord,))
                         for i in range(1)]
        i = 0
        for t in batch_threads:
            print("start batch thread:" + str(i))
            sys.stdout.flush()
            t.start()
            i += 1

        threads = [threading.Thread(target=self.input_thread, args=(session, coord))
                   for i in range(1)]
        i = 0
        for t in threads:
            print("start feed thread:" + str(i))
            sys.stdout.flush()
            t.start()
            i += 1

    def __repr__(self):
        return "batch_size:%s, env:%s, source_schema:%s, full_schema:%s" % (
            self.batch_size, self.env, self.source_schema, self.full_schema)

    def __str__(self):
        return "batch_size:%s, env:%s, source_schema:%s, full_schema:%s" % (
            self.batch_size, self.env, self.source_schema, self.full_schema)


def read_input_from_blink(full_schema, batch_size):
    len_schema = len(full_schema)
    global input_placeholder
    input_placeholder = tf.placeholder(tf.string, shape=[batch_size, len_schema])
    stream_queue = tf.FIFOQueue(2000, dtypes=[tf.string], shapes=[[batch_size, len_schema]])
    global enqueue_op
    enqueue_op = stream_queue.enqueue(input_placeholder)
    dequeue_op = stream_queue.dequeue()
    tf.summary.scalar("input_queue_size",
                      tf.cast(stream_queue.size(), tf.float32))
    examples = tf.split(dequeue_op, num_or_size_splits=len_schema, axis=1)
    columns_to_tensors = {}
    for index, feature_item in enumerate(full_schema):
        feature_name = feature_item.get_feature_name()
        feature_type = feature_item.get_feature_type()
        input_tensor = tf.reshape(examples[index], shape=[batch_size])
        after_Tensor = transform_to_tensor(feature_type, input_tensor)
        columns_to_tensors[feature_name] = after_Tensor
    return columns_to_tensors, columns_to_tensors['label']


class FeatureItem:
    def __init__(self, feature_name, feature_type):
        self.feature_name = feature_name
        self.feature_type = feature_type

    def get_feature_name(self):
        return self.feature_name

    def get_feature_type(self):
        return self.feature_type

    def __repr__(self):
        return "feature_name:%s, feature_type:%s" % (self.feature_name, self.feature_type)

    def __str__(self):
        return "feature_name:%s, feature_type:%s" % (self.feature_name, self.feature_type)
