from odps.udf import annotate
from odps.udf import BaseUDTF
import re, sys


def process(user_id, track_info, pv, click):
    if track_info is None:
        return
    output_name = {
        'appType',
        'btsId',
        'contentId',
        'content_type',
        'itemId',
        'layer',
        'matchScore',
        'matchType',
        'pos',
        'pvid',
        'triggerId'
    }
    detail_apps = track_info.split('__')

    for detail_app in detail_apps:
        #2 app in a row
        log_list = []
        app_info = {}
        detail_info = detail_app.split('##')
        for index, detail_info in enumerate(detail_info):
            print(detail_info)
            item_infos = {}
            # print detail_info
            detail_items = detail_info.split('@')
            for detail_item in detail_items:
                if re.match("item\\d", detail_item):
                    item_infos["content_type"] = 'item'
                    item_infos["pos"] = detail_item.split("item")[1]
                    continue
                if re.match("banner", detail_item):
                    item_infos["content_type"] = 'banner'
                    item_infos["pos"] = "-1"
                    continue
                detail_values = detail_item.split('^^')
                if len(detail_values) < 2 <= len(detail_items):
                    app_info[detail_items[0]] = detail_items[1]
                for detail_value in detail_values:
                    # 2 item in a row
                    detail_value_info = detail_value.split('$')
                    if re.match("mutexCategoryId", detail_value_info[0]):
                        continue
                    if len(detail_value_info) == 2:
                        item_infos[detail_value_info[0]] = detail_value_info[1]

            if len(item_infos) > 1:
                log_list.append(item_infos)
        # print(log_list)
        for log_detail in log_list:
            logs = dict(log_detail.items() + app_info.items())
            logs = sorted(logs.items(), key=lambda a: a[0])
            log_out = []
            for log in logs:
                if log[0] in output_name:
                    log_out.append(log[1])
            try:
                print(
                    long(user_id),
                    long(log_out[0]),  # appType,
                    long(log_out[1]),  # btsId,
                    long(log_out[2]),  # contentId
                    str(log_out[3]),  # content_type
                    long(log_out[4]),  # itemId
                    long(log_out[5]),  # layer
                    round(float(log_out[6]), 6),  # matchScore
                    str(log_out[7]),  # matchType
                    long(log_out[8]),  # pos
                    str(log_out[9]),  # pvid
                    long(log_out[10]),  # triggerid
                    pv,  # pv
                    click  # click
                )

            except Exception as e:
                pass
            #     sys.stderr.write("error logs %s\n" % str(track_info))
            #     sys.stderr.write("error reason %s\n" % str(e))


# args = "item0@itemId$14419804760^^matchScore$0.3776915974529001^^score$0.010467072611902793^^simRank$0^^picType$-1^^matchType$HOT^^triggerId$0^^contentId$232745023^^rankScore$0.02771327898870741^^triggerNum$0^^categoryId$50020632^^marketId$-1##item1@itemId$533905536911^^matchScore$0.3806963854858791^^score$0.00975248401363236^^simRank$0^^picType$-1^^matchType$HOT^^triggerId$0^^contentId$277887304^^rankScore$0.0256174851809674^^triggerNum$0^^categoryId$50015847^^marketId$-1##pvid@8eaefb02-0ccc-4be1-a973-9cea856f011b##appType@1234##btsId@82834##scm@1007.15047.82834.000##layer@2__item0@itemId$543577895475^^matchScore$0.0010201468496313453^^score$8.000031856470232^^simRank$0^^picType$-1^^matchType$OFFLINE_ITEM^^triggerId$527652552223^^contentId$276064817^^rankScore$0.031227337754070272^^triggerNum$0^^categoryId$124558013^^marketId$-1##item1@itemId$542777501768^^matchScore$1.463942501907008E-4^^score$8.000002748567393^^simRank$0^^picType$-1^^matchType$OFFLINE_ITEM^^triggerId$548924187568^^contentId$244906387^^rankScore$0.018775104820276653^^triggerNum$0^^categoryId$121408043^^marketId$-1##pvid@8eaefb02-0ccc-4be1-a973-9cea856f011b##appType@1227##btsId@82834##scm@1007.15047.82834.000##layer@2"
# args="scm=2019.1004.100.1,itemId=548112528259,spm=a2141.1.card4-busi.1,trackInfo=pvid@4422d98c-2681-4500-825c-456925d5899f##appType@1224##btsId@82835##scm@1007.15047.82835.000##layer@1##item1@itemId$548112528259^^matchScore$0.2713595978360276^^score$0.02016403256231522^^simRank$0^^picType$-1^^matchType$HOT^^triggerId$0^^contentId$205926379^^rankScore$0.07430742351888209^^triggerNum$0^^categoryId$50010159^^marketId$-1,targetUrl=https%3A%2F%2Fmarket.m.taobao.com%2Fapps%2Fclkw%2Fclkw%2Fmanfashion.html%3Fspm%3Da2141.1.card4-busi.1%26itemIds%3D546271466619%25252C548112528259%26scm%3D2019.1004.100.1%26wh_weex%3Dtrue%26data_prefetch%3Dtrue,contentId=205926379"
# args="pvid@4422d98c-2681-4500-825c-456925d5899f##appType@1224##btsId@82835##scm@1007.15047.82835.000##layer@1##item1@itemId$548112528259^^matchScore$0.2713595978360276^^score$0.02016403256231522^^simRank$0^^picType$-1^^matchType$HOT^^triggerId$0^^contentId$205926379^^rankScore$0.07430742351888209^^triggerNum$0^^categoryId$50010159^^marketId$-1"
args="pvid@b84218f7-52e5-4b33-bff4-cbc5fa1b32ff##appType@1306##btsId@82831##banner@itemId$546854343574^^matchScore$0.24586532489006638^^score$8.245865324890067^^simRank$0^^picType$-1^^matchType$ONLINE_ITEM^^triggerId$546783912752^^contentId$249077039^^rankScore$1.0E-6^^triggerNum$0^^categoryId$50012033##scm@1007.15047.82831.000##layer@0"

process(user_id="123", track_info=args, pv=1, click=0)
