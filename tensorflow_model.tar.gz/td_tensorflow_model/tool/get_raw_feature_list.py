import json

f = open("/Users/wangjz/Documents/wide_n_deep/config/yuanfang_clkw_conf.json")
json_obj = json.load(f)
features = json_obj["features"]

for fea in features:
    if fea["feature_type"] in ["raw_feature", "match_feature", "lookup_feature"]:
        # print("CAST(coalesce(keyvalue(features, chr(2), chr(3), '%s'),0.0) AS DOUBLE) AS %s," % (
        # fea["feature_name"], fea["feature_name"]))
        print("%s DOUBLE," % (fea["feature_name"]))
