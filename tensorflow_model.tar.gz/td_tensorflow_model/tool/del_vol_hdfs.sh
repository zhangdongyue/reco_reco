#!/usr/bin/env bash
project=palgo_shopping
volume=yuanfang
user=jizhe.wjz
ds=`date -d"4 day ago" +%Y%m%d`

echo "start delete ${ds} data"
hadoop fs -ls hdfs://hdpet2rt/user/${user}/.slider/odps/${volume}/ | grep ${ds} | awk '{print $8}' | xargs hadoop fs -rm -r