from odps import ODPS

def get_table_features(table_name,project):
    if "." not in table_name:
        _project = project
    else:
        _project = table_name.split(".")[0]
        table_name = table_name.split(".")[1]
    odps = ODPS(odps_access_id, odps_access_key, project, endpoint='http://service-corp.odps.aliyun-inc.com/api')
    t = odps.get_table(table_name, project=_project)
    return [(col.name, str(col.type)) for col in t.schema.columns]

def generate_table(table_name, features, partitions):
    features_str = ",\n".join(["\t" + k + " " + v for k, v in features])
    partition_str = ",\n".join(["\t" + k + " " + v for k, v in partitions])
    print("""CREATE TABLE IF NOT EXISTS %s (%s) PARTITIONED BY (%s) LIFECYCLE 7;\n""" % (table_name, features_str, partition_str))


odps_access_id = "zE4gwV1YtBbkT5NL"
odps_access_key = "Mxp10c29mySFjcQsejcTvOB41EPsUQ"
table_name="yuanfang_small_graph_rw_fasttext_tmp"
project="palgo_fpage"
create_table_name="yuanfang_small_graph_rw_fasttext"

table_features = get_table_features(table_name,project)
generate_table(create_table_name, table_features, [("ds", "STRING")])
