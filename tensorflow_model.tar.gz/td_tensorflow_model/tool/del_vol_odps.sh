#!/usr/bin/env bash
project=palgo_shopping
volume=yuanfang
ds=`date -d"2 day ago" +%Y%m%d`
echo "start delete ${ds} data"
odpscmd -e "use ${project};fs -ls ${volume};" |grep ${ds}|grep -v wdl10 |awk  '{print "use '${project}';fs -rmp " $1";"}' | odpscmd -e

project=palgo_fpage
volume=yuanfang
ds=`date -d"2 day ago" +%Y%m%d`
echo "start delete ${ds} data"
odpscmd -e "use ${project};fs -ls ${volume};" |grep ${ds}|awk '{print "use '${project}';fs -rmp " $1";"}' | odpscmd -e