import json

file_path = "../config/aioplus_wdl.json"

a = json.load(open(file_path))

deep = 0
wide = 0
for fea in a['features']:
    if fea.has_key("embedding_dimension"):
        deep += fea["embedding_dimension"]

    elif fea.has_key("wide_feature"):
        wide += 1
    else:
        deep += 1

print("deep dimension = %d" % deep)
print("wide dimension = %d" % wide)
