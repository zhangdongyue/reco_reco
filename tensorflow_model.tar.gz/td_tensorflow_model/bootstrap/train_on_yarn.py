import os
import sys

currentPath = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(currentPath + os.sep + '../')
sys.path.append(currentPath + os.sep + '../..')

import tensorflow as tf
from train import distribution_run
from flink.yarn_bootstrap import *

tf.app.flags.DEFINE_string("data_dir", "tfdata", "Relative directory of data")


class train(YarnBootstrap):
    def worker_do(self, server, cluster_spec, task_id):
        super(train, self).worker_do(server=server, cluster_spec=cluster_spec, task_id=task_id)
        distribution_run.run(server.target, cluster_spec, task_id)

    def ps_do(self, server, cluster_spec, task_id):
        super(train, self).ps_do(server=server, cluster_spec=cluster_spec, task_id=task_id)


def main(unused_argv):
    train().start(unused_args=unused_argv)


if __name__ == '__main__':
    tf.app.run()
