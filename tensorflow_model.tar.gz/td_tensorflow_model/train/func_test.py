import tensorflow as tf
from tensorflow.python.ops import array_ops


def shape_test():
    arr = [[[1.0, 3.0, 5.0], [2.0, 4.0, 6.0]], [[1.0, 3.0, 5.0], [2.0, 4.0, 6.0]]]
    x = tf.constant(arr, name='input')

    sess = tf.Session()
    sess.run(tf.initialize_all_variables())
    w = tf.square(tf.reduce_sum(x, axis=2)) - tf.reduce_sum(tf.square(x), axis=2)
    y = 0.5 * tf.reduce_sum(w, axis=1)
    output_shape = array_ops.concat([tf.shape(y), [1]], 0)
    z = tf.stack([])
    print(sess.run(tf.reshape(y, output_shape)))
    print(sess.run(tf.shape(x)))
    print(sess.run(tf.shape(w)))


def record_parser():
    from smart_io import FeatureColumnGenerator
    feature_conf_path = '/Users/stallone/Downloads/aio_wdl_conf_618.json'
    fg = FeatureColumnGenerator(feature_conf_path)
    feature_map = fg.feature_map
    filename = '/Users/stallone/Downloads/0_worker_instid_0.tfrecords'
    # filename = '/Users/stallone/Downloads/0_worker_instid_0.tfrecords'
    filename_queue = tf.train.string_input_producer([filename])
    reader = tf.TFRecordReader()
    _, serialized_examples = reader.read_up_to(filename_queue, num_records=20)
    print(serialized_examples)
    features = tf.parse_example(serialized_examples, features=feature_map)
    init = tf.initialize_all_variables()
    with tf.Session() as sess:
        sess.run(init)
        tf.train.start_queue_runners(sess=sess)
        print(sess.run(features))


if __name__ == '__main__':
    shape_test()
    record_parser()
