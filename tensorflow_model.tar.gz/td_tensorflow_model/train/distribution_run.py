"""
Distributed training procedure.

FLAGS.ckp_dir is the variable given by yarn -- "user.checkpoint.prefix" in yarn json configuration.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import ast
import os
import time
import datetime
import tensorflow as tf
from hdfs_client import get_defaultFS
from tensorflow.contrib.learn.python.learn.estimators import prediction_key
from tensorflow.contrib.learn.python.learn.monitors import ValidationMonitor
from smart_io import odps_writer
from smart_io.blink_reader import FeedHook, read_input_from_blink, FeatureItem
from smart_io.filesystem import HDFSFilesystem
from smart_io.console_log import log, log_error
from smart_io.fc_generator import FeatureColumnGenerator, FeatureConfKeys
from smart_io.odps_downloader import download_data_from_odps_table, tf_record_parser
from smart_io.tf_reader import build_batch_from_tf_records, download_files_from_volume
from train.task_config import TaskConfig
from train.utils import build_run_config, parse_parameter_map, parent_directory
from train.dnn_linear_combined import DNNLinearCombinedClassifier, MODEL_FN_MAP

FLAGS = tf.app.flags.FLAGS


def run(target, cluster_spec, task_id, env):
    tf.logging.set_verbosity(tf.logging.INFO)
    param_map = parse_parameter_map(FLAGS.param)
    mode = param_map.get("mode", "train")
    if mode == "train":
        log("Start training ...")
        run_training(target, cluster_spec, task_id, param_map)
    elif mode == "predict":
        log("Start predicting ...")
        run_predicting(target, cluster_spec, task_id, param_map)
    elif mode == "online_train":
        realtime_training(target, cluster_spec, task_id, param_map, env)
    else:
        log_error("Unknown mode %s" % mode)


def run_training(target, cluster_spec, task_id, param_map):
    log("Checkpoint Dir == %s" % FLAGS.ckp_dir)
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # Parse config parameters
    conf_file_path = os.path.join(parent_directory(current_dir, 3),
                                  param_map.get("task_conf_file")) if param_map.has_key(
        "task_conf_file") else os.path.join(parent_directory(current_dir), 'config/task_config.json')
    log("Will use task conf file %s" % conf_file_path)
    task_config = TaskConfig(param_map=param_map, conf_file_path=conf_file_path)
    bizdate = (datetime.date.today() - datetime.timedelta(days=1)).strftime('%Y%m%d')
    task_config.add_if_not_contain("bizdate", bizdate)
    worker_num = FLAGS.worker_num
    run_config = build_run_config(target, cluster_spec, task_id, task_config.save_chckpnt_steps)

    # copy feature config file to hdfs
    feature_conf_path = os.path.join(parent_directory(current_dir, 3),
                                     task_config.get_config("feature_conf_file")) if task_config.contains(
        "feature_conf_file") else os.path.join(parent_directory(current_dir), 'config/aioplus_wdl.json')
    log("conf file path == %s" % feature_conf_path)
    if run_config.is_chief:
        filesystem = HDFSFilesystem()
        if not filesystem.exists(FLAGS.ckp_dir):
            filesystem.mkdir(FLAGS.ckp_dir)
        filesystem.put(feature_conf_path, FLAGS.ckp_dir + '/fg.json')

    # 1. build Classifier
    fg = FeatureColumnGenerator(feature_conf_path)
    feature_map = fg.feature_map
    feature_column_conf = fg.feature_column_conf
    wide_dim = fg.get_wide_dim
    deep_dim = fg.get_deep_dim
    deep_net = task_config.get_config("deep_net")
    assert deep_net, "parameter dnn_net is needed to bulid model!"
    deep_net = ast.literal_eval(deep_net)
    model_fn = MODEL_FN_MAP.get(task_config.get_config("model"))
    assert model_fn, "currently support only {}!".format(MODEL_FN_MAP.keys())
    log("will train a {} model".format(task_config.get_config("model")))
    classifier = DNNLinearCombinedClassifier(
        dnn_hidden_units=deep_net,
        config=run_config,
        linear_feature_columns=None if len(fg.wide_feature_list) == 0 else fg.wide_feature_list,
        dnn_feature_columns=None if len(fg.deep_feature_list) == 0 else fg.deep_feature_list,
        model_dir=FLAGS.ckp_dir,
        linear_optimizer=tf.train.FtrlOptimizer(
            learning_rate=0.1,
            learning_rate_power=task_config.learning_rate_power,
            initial_accumulator_value=task_config.initial_accumulator_value,
            l1_regularization_strength=task_config.l1_regularization_strength,
            l2_regularization_strength=task_config.l2_regularization_strength
        ),
        input_layer_min_slice_size=2048 << 20,
        hidden_layer_min_slice_size=2048 << 20,
        model_fn=model_fn,
        wide_dim=wide_dim,
        deep_dim=deep_dim,
        feature_column_conf=feature_column_conf,
        fix_global_step_increment_bug=True
    )

    # 2. prepare data
    log("start downloading training files..........")
    train_set = []
    if task_config.odps_volume_biz and task_config.odps_volume:
        # Download from odps volume
        odps_volume_biz = task_config.odps_volume_biz + '_' + task_config.bizdate
        train_set = download_files_from_volume(
            odps_id=task_config.odps_access_id,
            odps_key=task_config.odps_access_key,
            part=task_id,
            project=task_config.odps_project,
            volume=task_config.odps_volume,
            partition=odps_volume_biz,
            worker_num=worker_num,
            process_count=4
        )
        if train_set is None or len(train_set) == 0:
            log_error("No train files found in [%s]/[%s]/[%s]" % (
                task_config.odps_project, task_config.odps_volume, odps_volume_biz))
            return
    elif task_config.odps_table:
        # Download from odps table
        if task_config.get_config("convert_to_records") and ast.literal_eval(
                task_config.get_config("convert_to_records")):
            partition = r"ds=%s" % task_config.bizdate
            data_dir = r"%s%s/%s" % (FLAGS.work_dir, task_config.odps_table, task_config.bizdate)
            if not data_dir.startswith('hdfs://'):
                data_dir = "%s%s" % (get_defaultFS(), data_dir)
            log("Download data to %s" % data_dir)
            train_set, _ = download_data_from_odps_table(
                task_config.odps_project,
                task_config.odps_access_id,
                task_config.odps_access_key,
                task_config.odps_table,
                partition.encode(),
                task_id,
                worker_num,
                data_dir,
                parser=tf_record_parser,
                filesystem='hdfs',
                env=task_config.get_config('odps_env', 'online'),
                feature_conf_file=feature_conf_path,
                total_file_num=task_config.get_config_as_int('total_file_num', 10000)
            )
        else:
            # TODO Add parser_fn for tf.TextLineReader
            log_error("Currently we do not support download plain text for wdl like model!")
            return
    assert len(train_set) >= 2, "too short train file list!"
    log("training files prepare ready!")
    train_max_steps = task_config.train_steps
    if task_config.get_config("incremental") and ast.literal_eval(
            task_config.get_config("incremental")):
        model_checkpoint_path = tf.train.latest_checkpoint(FLAGS.ckp_dir)
        if model_checkpoint_path:
            global_step = int(model_checkpoint_path[model_checkpoint_path.rfind('-') + 1:])
            train_max_steps += global_step
            log("Incremental learning from step {} to step {}.".format(global_step, train_max_steps))
        else:
            log_error("Configured incremental learning, but no checkpoint!")
    if task_id == 0:
        train_set = train_set[:-2]
        valid_set = train_set[:2]
        test_set = train_set[-2:]

        # 3. set monitor
        def _get_val_monitor(input_fn, monitor_name):
            log("Create validation monitor [%s] with [%d vali_per_steps] " % (
                monitor_name, task_config.vali_per_steps))
            return ValidationMonitor(
                input_fn=input_fn,
                every_n_steps=task_config.vali_per_steps,
                eval_steps=task_config.val_max_steps,
                name=monitor_name
            )

        monitor1 = _get_val_monitor(
            lambda: build_batch_from_tf_records(valid_set, feature_map, task_config.train_batch_size, num_epochs=1),
            "train_monitor")
        monitor2 = _get_val_monitor(
            lambda: build_batch_from_tf_records(test_set, feature_map, task_config.train_batch_size, num_epochs=1),
            "test_monitor")

        # 4. training
        classifier.fit(
            input_fn=lambda: build_batch_from_tf_records(file_list=train_set, feature_map=feature_map,
                                                         batch_size=task_config.train_batch_size),
            max_steps=train_max_steps,
            monitors=[monitor1, monitor2]
        )
    else:
        classifier.fit(
            input_fn=lambda: build_batch_from_tf_records(file_list=train_set, feature_map=feature_map,
                                                         batch_size=task_config.train_batch_size),
            max_steps=train_max_steps
        )

    log("End Training.")


def run_predicting(target, cluster_spec, task_id, param_map):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    conf_file_path = os.path.join(parent_directory(current_dir, 3),
                                  param_map.get("task_conf_file")) if param_map.has_key(
        "task_conf_file") else os.path.join(parent_directory(current_dir), 'config/task_config.json')
    log("Will use task conf file %s" % conf_file_path)
    task_config = TaskConfig(param_map=param_map, conf_file_path=conf_file_path)
    run_config = build_run_config(target, cluster_spec, task_id, task_config.save_chckpnt_steps)

    feature_conf_path = os.path.join(parent_directory(current_dir, 3),
                                     task_config.get_config("feature_conf_file")) if task_config.contains(
        "feature_conf_file") else os.path.join(parent_directory(current_dir), 'config/aioplus_wdl.json')
    log("conf file path == %s" % feature_conf_path)

    # 1. build Classifier
    fg = FeatureColumnGenerator(feature_conf_path)
    feature_map = fg.feature_map
    feature_column_conf = fg.feature_column_conf
    deep_net = task_config.get_config("deep_net")
    assert deep_net, "parameter dnn_net is needed to bulid model!"
    deep_net = ast.literal_eval(deep_net)
    model_fn = MODEL_FN_MAP.get(task_config.get_config("model"))
    assert model_fn, "currently support only wdl, pnn, deepFM or nfm!"
    log("will train a {} model".format(task_config.get_config("model")))
    classifier = DNNLinearCombinedClassifier(
        dnn_hidden_units=deep_net,
        config=run_config,
        linear_feature_columns=None if len(fg.wide_feature_list) == 0 else fg.wide_feature_list,
        dnn_feature_columns=None if len(fg.deep_feature_list) == 0 else fg.deep_feature_list,
        model_dir=FLAGS.ckp_dir,
        linear_optimizer=tf.train.FtrlOptimizer(
            learning_rate=0.1,
            learning_rate_power=task_config.learning_rate_power,
            initial_accumulator_value=task_config.initial_accumulator_value,
            l1_regularization_strength=task_config.l1_regularization_strength,
            l2_regularization_strength=task_config.l2_regularization_strength
        ),
        input_layer_min_slice_size=2048 << 20,
        hidden_layer_min_slice_size=2048 << 20,
        model_fn=model_fn,
        feature_column_conf=feature_column_conf,
        fix_global_step_increment_bug=True
    )

    # 2. prepare predicting files
    log("start downloading training files..........")
    worker_num = FLAGS.worker_num
    predicting_files_list = []
    if task_config.odps_volume_biz and task_config.odps_volume:
        # Download from odps volume
        odps_volume_biz = task_config.odps_volume_biz + '_' + task_config.bizdate
        predicting_files_list = download_files_from_volume(
            odps_id=task_config.odps_access_id,
            odps_key=task_config.odps_access_key,
            part=task_id,
            project=task_config.odps_project,
            volume=task_config.odps_volume,
            partition=odps_volume_biz,
            worker_num=worker_num,
            process_count=4
        )
        if predicting_files_list is None or len(predicting_files_list) == 0:
            log_error("No predict files found in [%s]/[%s]/[%s]" % (
                task_config.odps_project, task_config.odps_volume, odps_volume_biz))
            return
    elif task_config.odps_table:
        # Download from odps table
        if task_config.get_config("convert_to_records") and ast.literal_eval(
                task_config.get_config("convert_to_records")):
            partition = r"ds=%s" % task_config.bizdate
            data_dir = r"%s/%s/%s" % (FLAGS.work_dir, task_config.odps_table, task_config.bizdate)
            if not data_dir.startswith('hdfs://'):
                data_dir = "%s%s" % (get_defaultFS(), data_dir)
            log("Download data to %s" % data_dir)
            predicting_files_list, _ = download_data_from_odps_table(
                task_config.odps_project,
                task_config.odps_access_id,
                task_config.odps_access_key,
                task_config.odps_table,
                partition.encode(),
                task_id,
                worker_num,
                data_dir,
                parser=tf_record_parser,
                filesystem='hdfs',
                env=task_config.get_config('odps_env', 'online'),
                feature_conf_file=feature_conf_path,
                total_file_num=task_config.get_config_as_int('total_file_num', 10000)
            )
        else:
            # TODO Add parser_fn for tf.TextLineReader
            log_error("Currently we do not support download plain text for wdl like model!")
            return

    start_time = time.time()
    log("Predicting files: {}".format(predicting_files_list))
    if len(predicting_files_list) > 0:
        predictions = classifier.predict(
            input_fn=lambda: build_batch_from_tf_records(file_list=predicting_files_list, feature_map=feature_map,
                                                         batch_size=task_config.predict_batch_size, num_epochs=1),
            outputs=[FeatureConfKeys.SAMPLE_ID, FeatureConfKeys.SAMPLE_LABEL, prediction_key.PredictionKey.LOGISTIC]
        )
        predictions_file = os.path.join(FLAGS.work_dir, 'predictions.txt')

        with open(predictions_file, "w") as f:
            for num, p in enumerate(predictions):
                sample_id = p[FeatureConfKeys.SAMPLE_ID][0]
                label = p[FeatureConfKeys.SAMPLE_LABEL][0]
                score = p[prediction_key.PredictionKey.LOGISTIC][0]
                f.write("{};{};{}\n".format(sample_id, label, score))
                if num % 100 == 0:
                    log("predicting {} entries ....".format(num))
                if num >= task_config.predict_steps:
                    break

        # upload predict result to odps
        result_table = task_config.get_config("result_table")
        if result_table:
            log("Will upload data to {} ".format(result_table))
            odps_writer.upload(
                access_id=task_config.odps_access_id,
                access_key=task_config.odps_access_key,
                task_id=task_id,
                data_file=predictions_file,
                project=task_config.odps_project,
                table_name=result_table,
                ds=task_config.bizdate,
                split_key=";",
                field_names=["id", "label", "score"],
                field_types=["string", "string", "string"]
            )
    cost = time.time() - start_time
    log("All done, predicting totally cost --> [%d] s." % cost)


def realtime_training(target, cluster_spec, task_id, param_map, env):
    log("Checkpoint Dir == %s" % FLAGS.ckp_dir)
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # Parse config parameters
    conf_file_path = os.path.join(parent_directory(current_dir, 3),
                                  param_map.get("task_conf_file")) if param_map.has_key(
        "task_conf_file") else os.path.join(parent_directory(current_dir), 'config/task_config.json')
    log("Will use task conf file %s" % conf_file_path)
    task_config = TaskConfig(param_map=param_map, conf_file_path=conf_file_path)
    bizdate = (datetime.date.today() - datetime.timedelta(days=1)).strftime('%Y%m%d')
    task_config.add_if_not_contain("bizdate", bizdate)
    worker_num = FLAGS.worker_num
    run_config = build_run_config(target, cluster_spec, task_id, task_config.save_chckpnt_steps)

    # copy feature config file to hdfs
    feature_conf_path = os.path.join(parent_directory(current_dir, 3),
                                     task_config.get_config("feature_conf_file")) if task_config.contains(
        "feature_conf_file") else os.path.join(parent_directory(current_dir), 'config/aioplus_wdl.json')
    log("conf file path == %s" % feature_conf_path)
    if run_config.is_chief:
        filesystem = HDFSFilesystem()
        if not filesystem.exists(FLAGS.ckp_dir):
            filesystem.mkdir(FLAGS.ckp_dir)
        filesystem.put(feature_conf_path, FLAGS.ckp_dir + '/fg.json')

    # 1. build Classifier
    fg = FeatureColumnGenerator(feature_conf_path)
    feature_map = fg.feature_map
    feature_column_conf = fg.feature_column_conf
    deep_net = task_config.get_config("deep_net")
    assert deep_net, "parameter dnn_net is needed to bulid model!"
    deep_net = ast.literal_eval(deep_net)
    model_fn = MODEL_FN_MAP.get(task_config.get_config("model"))
    assert model_fn, "currently support only wdl, pnn, deepFM or nfm!"
    log("will train a {} model".format(task_config.get_config("model")))
    classifier = DNNLinearCombinedClassifier(
        dnn_hidden_units=deep_net,
        config=run_config,
        linear_feature_columns=None if len(fg.wide_feature_list) == 0 else fg.wide_feature_list,
        dnn_feature_columns=None if len(fg.deep_feature_list) == 0 else fg.deep_feature_list,
        model_dir=FLAGS.ckp_dir,
        linear_optimizer=tf.train.FtrlOptimizer(
            learning_rate=0.1,
            learning_rate_power=task_config.learning_rate_power,
            initial_accumulator_value=task_config.initial_accumulator_value,
            l1_regularization_strength=task_config.l1_regularization_strength,
            l2_regularization_strength=task_config.l2_regularization_strength
        ),
        input_layer_min_slice_size=2048 << 20,
        hidden_layer_min_slice_size=2048 << 20,
        model_fn=model_fn,
        feature_column_conf=feature_column_conf,
        fix_global_step_increment_bug=True
    )

    # read data from blink and train, TODO: configurable schema
    full_schema = map(lambda x: FeatureItem(x[0], x[1][FeatureConfKeys.VALUE_TYPE]), fg.feature_conf_map.items())
    full_schema += [FeatureItem(x, y) for (x, y) in [('id', 'String'), ('label', 'Int'), ('type', 'String')]]
    source_schema = 'id,features,label,type'
    log("full_schema: %s" % full_schema)
    feed_hook = FeedHook(task_config.train_batch_size, env, source_schema, full_schema)
    classifier.fit(
        input_fn=lambda: read_input_from_blink(full_schema, task_config.train_batch_size),
        steps=task_config.train_steps,
        monitors=[feed_hook]
    )
    log("End Training.")
