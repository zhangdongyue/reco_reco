import os
import ast
import sys
import time
import datetime
import traceback
import odps as Odps
import tensorflow as tf
from tensorflow.contrib.learn import RunConfig
from tensorflow.contrib.learn.python.learn.estimators import prediction_key
from tensorflow.contrib.learn.python.learn.monitors import ValidationMonitor
from tensorflow.python.estimator.run_config import RunConfig
from tensorflow.python.ops import variables

currentPath = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(currentPath + os.sep + '../')
sys.path.append(currentPath + os.sep + '../..')

from train.task_config import TaskConfig
from hdfs_client import get_defaultFS
from smart_io import odps_writer
from smart_io.blink_reader import FeedHook, read_input_from_blink, FeatureItem
from smart_io.filesystem import HDFSFilesystem
from smart_io.console_log import log, log_error
from smart_io.fc_generator import FeatureColumnGenerator, FeatureConfKeys
from smart_io.odps_downloader import download_data_from_odps_table, tf_record_parser, get_last_partition
from smart_io.tf_reader import build_batch_from_tf_records, download_files_from_volume
from train.utils import parse_parameter_map, parent_directory
from train.dnn_linear_combined import DNNLinearCombinedClassifier, MODEL_FN_MAP
from flink_tensorflow.python_sdk.blink_bootstrap import *
from flink_tensorflow.python_sdk.stream_io.stream_utils import *
from tensorflow.python.training import session_run_hook

FLAGS = tf.app.flags.FLAGS


class Train(BlinkBootstrap):
    def run(self, target, data_stream, task_id, context):
        tf.logging.set_verbosity(tf.logging.INFO)
        #param_map = parse_parameter_map(FLAGS.param)
        model_param = context.get_param()
        log("Model Param == %s" % model_param)
        param_map = parse_parameter_map(model_param)
        mode = param_map.get("mode", "train")
        if mode == "train":
            log("Start training ...")
            run_training(target, task_id, param_map, context)
        elif mode == "predict":
            log("Start predicting ...")
            run_predicting(target, task_id, param_map, context)
        elif mode == "online_train":
            realtime_training(target, param_map, context)
        elif mode == "download":
            run_training(target, task_id, param_map, context, True)
        else:
            log_error("Unknown mode %s" % mode)


def run_training(target, task_id, param_map, context, onlydown=False):
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # Get Context Param
    ckp_dir = context.get_ckp_dir()
    log("Checkpoint Dir == %s" % ckp_dir)
    work_dir = context.get_work_dir()
    log("TrainData Dir == %s" % work_dir)
    worker_num = context.get_worker_num()
    log("Worker Num == %s" % worker_num)


    # Parse config parameters
    conf_file_path = os.path.join(parent_directory(current_dir, 1), param_map.get("task_conf_file")) if param_map.has_key(
        "task_conf_file") else os.path.join(parent_directory(current_dir), 'config/task_config.json')
    log("Will use task conf file path ==%s" % conf_file_path)
    task_config = TaskConfig(param_map=param_map, conf_file_path=conf_file_path)
    bizdate = (datetime.date.today() - datetime.timedelta(days=1)).strftime('%Y%m%d')
    task_config.add_if_not_contain("bizdate", bizdate)

    # Copy feature json file to hdfs (If you do not use FG, this step must be removed!)
    feature_conf_path = os.path.join(parent_directory(current_dir, 1), param_map.get("feature_conf_file")) if param_map.has_key(
        "feature_conf_file") else os.path.join(parent_directory(current_dir), 'config/td_feature_conf.json')
    log("Will use feature conf file path ==%s" % feature_conf_path)
    if task_id == 0:
        filesystem = HDFSFilesystem()
        if not filesystem.exists(ckp_dir):
            filesystem.mkdir(ckp_dir)
        filesystem.put(feature_conf_path, ckp_dir + 'fg.json')

    # 1. build Classifier
    fg = FeatureColumnGenerator(feature_conf_path)
    feature_map = fg.feature_map
    log("feature map = %s" % feature_map)
    feature_column_conf = fg.feature_column_conf
    wide_dim = fg.get_wide_dim
    log("wide_dim is %s" % str(wide_dim))
    deep_dim = fg.get_deep_dim
    log("deep_dim is %s" % str(deep_dim))
    deep_net = task_config.get_config("deep_net")
    assert deep_net, "parameter dnn_net is needed to bulid model!"
    deep_net = ast.literal_eval(deep_net)
    model_fn = MODEL_FN_MAP.get(task_config.get_config("model"))
    assert model_fn, "currently support only wdl, pnn, deepFM or nfm!"
    log("will train a {} model".format(task_config.get_config("model")))
    classifier = DNNLinearCombinedClassifier(
        dnn_hidden_units=deep_net,
        linear_feature_columns=None if len(fg.wide_feature_list) == 0 else fg.wide_feature_list,
        dnn_feature_columns=None if len(fg.deep_feature_list) == 0 else fg.deep_feature_list,
        model_dir=ckp_dir,
        linear_optimizer=tf.train.FtrlOptimizer(
            learning_rate=task_config.learning_rate,
            learning_rate_power=task_config.learning_rate_power,
            initial_accumulator_value=task_config.initial_accumulator_value,
            l1_regularization_strength=task_config.l1_regularization_strength,
            l2_regularization_strength=task_config.l2_regularization_strength
        ),
        # dnn_optimizer=tf.train.RMSPropOptimizer(learning_rate=0.02, decay=0.9, momentum=0.9, epsilon=1.0),
        input_layer_min_slice_size=2048 << 20,
        hidden_layer_min_slice_size=2048 << 20,
        model_fn=model_fn,
        feature_column_conf=feature_column_conf,
        wide_dim=wide_dim,
        deep_dim=deep_dim,
        fix_global_step_increment_bug=True,
        config=tf.contrib.learn.RunConfig(save_checkpoints_secs=600) # default : 600
    )

    label_idx = int(param_map.get("label_conf")) if param_map.has_key("label_conf") else 1
    train_days = int(param_map.get("train_days")) if param_map.has_key("train_days") else 10
    startdate = datetime.datetime.strptime(task_config.bizdate, '%Y%m%d')
    firstrun = True
    if True:
        startdate = startdate + datetime.timedelta(days=1)
        task_config.add_config("bizdate", startdate.strftime('%Y%m%d'))
        # 2. prepare data
        log("start downloading training files..........%s"%(task_config.bizdate))
        train_set = []
        if task_config.odps_volume_biz and task_config.odps_volume:
            # Download from odps volume
            odps_volume_biz = task_config.odps_volume_biz + '_' + task_config.bizdate
            train_set = download_files_from_volume(
                odps_id=task_config.odps_access_id,
                odps_key=task_config.odps_access_key,
                part=task_id,
                project=task_config.odps_project,
                volume=task_config.odps_volume,
                partition=odps_volume_biz,
                worker_num=worker_num,
                process_count=4
            )
            if train_set is None or len(train_set) == 0:
                log_error("No train files found in [%s]/[%s]/[%s]" % (
                    task_config.odps_project, task_config.odps_volume, odps_volume_biz))
                return
        elif task_config.odps_table:
            # Download from odps table
            if task_config.get_config("convert_to_records") and ast.literal_eval(
                    task_config.get_config("convert_to_records")):
                odps = Odps.ODPS(task_config.odps_access_id, task_config.odps_access_key, task_config.odps_project, 'http://service-corp.odps.aliyun-inc.com/api')
                table = odps.get_table(task_config.odps_table)
                partition = get_last_partition(table)
                # partition = r"ds=%s" % task_config.bizdate
                # data_dir = r"%s%s/%s" % (work_dir, task_config.odps_table, task_config.bizdate)
                data_dir = r"%s%s/%s" % (work_dir, task_config.odps_table, partition)
                if not data_dir.startswith('hdfs://'):
                    data_dir = "%s%s" % (get_defaultFS(), data_dir)
                log("Download data to %s" % data_dir)
                train_set, _ = download_data_from_odps_table(
                    task_config.odps_project,
                    task_config.odps_access_id,
                    task_config.odps_access_key,
                    task_config.odps_table,
                    partition.encode(),
                    task_id,
                    worker_num,
                    data_dir,
                    odps_read_process=4,
                    parser=tf_record_parser,
                    filesystem='hdfs',
                    env=task_config.get_config('odps_env', 'online'),
                    feature_conf_file=feature_conf_path,
                    label_conf=label_idx
                )
            else:
                # TODO Add parser_fn for tf.TextLineReader
                log_error("Currently we do not support download plain text for wdl like model!")
                return
        assert len(train_set) > 2, "too short train file list!"
        log("Checking master status ...")
        if onlydown:
            if task_id == 0:
                time.sleep(3600)
            return
        if task_id > 0:
            while True:
                time.sleep(10)
                filesystem = HDFSFilesystem()
                data_dir = r"%s%s/%s" % (work_dir, task_config.odps_table, task_config.bizdate)
                if not data_dir.startswith('hdfs://'):
                    data_dir = "%s%s" % (get_defaultFS(), data_dir)
                if filesystem.exists(os.path.join(data_dir, "_SUCCESS")):
                    log("Master worker download done, start training ...")
                    break
        # if task_id == 0:
        #     train_set = train_set[:-2]
        #     valid_set = train_set[:2]
        #     test_set = train_set[-2:]

        #     # 3. set monitor
        #     def _get_val_monitor(input_fn, monitor_name):
        #         log("Create validation monitor [%s] with [%d vali_per_steps] " % (
        #             monitor_name, task_config.vali_per_steps))
        #         return ValidationMonitor(
        #             input_fn=input_fn,
        #             every_n_steps=task_config.vali_per_steps,
        #             eval_steps=task_config.val_max_steps,
        #             name=monitor_name
        #         )

        #     monitor1 = _get_val_monitor(
        #         lambda: build_batch_from_tf_records(valid_set, feature_map, task_config.train_batch_size, num_epochs=1),
        #         "train_monitor")
        #     monitor2 = _get_val_monitor(
        #         lambda: build_batch_from_tf_records(test_set, feature_map, task_config.train_batch_size, num_epochs=1),
        #         "test_monitor")

        #     # 4. training
        #     classifier.fit(
        #         input_fn=lambda: build_batch_from_tf_records(file_list=train_set, feature_map=feature_map,
        #                                                      batch_size=task_config.train_batch_size, num_epochs=2),
        #         max_steps=task_config.train_steps,
        #         monitors=[monitor1, monitor2]
        #     )
        # else:
        #     classifier.fit(
        #         input_fn=lambda: build_batch_from_tf_records(file_list=train_set, feature_map=feature_map,
        #                                                      batch_size=task_config.train_batch_size, num_epochs=2),
        #         max_steps=task_config.train_steps
        #     )
        log("before %s" % train_set)

        if firstrun:
            firstrun = False
            pass
        else:
            pass

        try:
            classifier.fit(
                input_fn=lambda: build_batch_from_tf_records(file_list=train_set, feature_map=feature_map,
                                                             batch_size=task_config.train_batch_size, num_epochs=1),
                steps=task_config.train_steps, 
            )
        except Exception:
            log_error('exception during training')
            log_error(traceback.format_exc())

        log("End Training !!!!!!!!!!!!!!!!!!!!!!!")
        # try export model periodically
        try:
            # if task_config.bizdate.startswith(datetime.date.today().strftime("%Y%m%d")):
            if task_id == 0:
                run_export_model(ckp_dir)
        except Exception:
            log_error("export model exception !!!!!!")
            log_error(traceback.format_exc())

def run_export_model(ckpt_dir):
    assert(ckpt_dir.startswith("hdfs"))
    target_dir = ckpt_dir.split("save")[0] + "tfonblink/temp/" + ckpt_dir.split("save")[1].split("/")[1] + "/" + datetime.datetime.now().strftime("%Y%m%d%H%M") + "/data/"
    dest_dir = ckpt_dir.split("save")[0] + "tfonblink/release/" + ckpt_dir.split("save")[1].split("/")[1] + "/" + datetime.datetime.now().strftime("%Y%m%d%H%M")
    filesystem = HDFSFilesystem()
    filesystem.get(ckpt_dir+"checkpoint", "./checkpoint")
    with open("./checkpoint", "r") as fp:
        model_prefix = fp.readline().strip().split("\"")[1]
        log("start export model %s"%(model_prefix,))
        if not filesystem.exists(target_dir):
            filesystem.mkdir(target_dir)
        filesystem.copy(ckpt_dir+"checkpoint", target_dir)
        filesystem.copy(ckpt_dir+"fg.json", target_dir)
        filesystem.copy(ckpt_dir+"graph.pbtxt", target_dir)
        filesystem.distcopy(ckpt_dir+model_prefix+"*", target_dir)

        if not filesystem.exists(dest_dir):
            filesystem.mkdir(dest_dir)
        filesystem.rename(target_dir, dest_dir)

def run_predicting(target, task_id, param_map, context):
    ckp_dir = context.get_ckp_dir()
    log("Checkpoint Dir == %s" % ckp_dir)
    work_dir = context.get_work_dir()
    log("TrainData Dir == %s" % work_dir)
    worker_num = context.get_worker_num()
    log("Worker Num == %s" % worker_num)

    current_dir = os.path.dirname(os.path.abspath(__file__))
    conf_file_path = os.path.join(parent_directory(current_dir, 1),
                                  param_map.get("task_conf_file")) if param_map.has_key(
        "task_conf_file") else os.path.join(parent_directory(current_dir), 'config/task_config.json')
    log("Will use task conf file %s" % conf_file_path)
    task_config = TaskConfig(param_map=param_map, conf_file_path=conf_file_path)
    # run_config = RunConfig(
    #     master=target,
    #     num_cores=0,
    #     save_summary_steps=1000,
    #     keep_checkpoint_max=2,
    #     save_checkpoints_secs=None,
    #     save_checkpoints_steps=task_config.save_chckpnt_steps,
    #     log_device_placement=False,
    # )
    feature_conf_path = os.path.join(parent_directory(current_dir, 1),
                                     param_map.get("feature_conf_file")) if param_map.has_key(
        "feature_conf_file") else os.path.join(parent_directory(current_dir), 'config/td_feature_conf.json')
    log("conf file path == %s" % feature_conf_path)

    # 1. build Classifier
    fg = FeatureColumnGenerator(feature_conf_path)
    feature_map = fg.feature_map
    feature_column_conf = fg.feature_column_conf
    wide_dim = fg.get_wide_dim
    deep_dim = fg.get_deep_dim
    deep_net = task_config.get_config("deep_net")
    assert deep_net, "parameter dnn_net is needed to bulid model!"
    deep_net = ast.literal_eval(deep_net)
    model_fn = MODEL_FN_MAP.get(task_config.get_config("model"))
    assert model_fn, "currently support only wdl, pnn, deepFM or nfm!"
    log("will train a {} model".format(task_config.get_config("model")))
    classifier = DNNLinearCombinedClassifier(
        dnn_hidden_units=deep_net,
        linear_feature_columns=None if len(fg.wide_feature_list) == 0 else fg.wide_feature_list,
        dnn_feature_columns=None if len(fg.deep_feature_list) == 0 else fg.deep_feature_list,
        model_dir=ckp_dir,
        linear_optimizer=tf.train.FtrlOptimizer(
            learning_rate=0.1,
            learning_rate_power=task_config.learning_rate_power,
            initial_accumulator_value=task_config.initial_accumulator_value,
            l1_regularization_strength=task_config.l1_regularization_strength,
            l2_regularization_strength=task_config.l2_regularization_strength
        ),
        input_layer_min_slice_size=2048 << 20,
        hidden_layer_min_slice_size=2048 << 20,
        model_fn=model_fn,
        feature_column_conf=feature_column_conf,
        wide_dim=wide_dim,
        deep_dim=deep_dim,
        fix_global_step_increment_bug=True
    )

    # 2. prepare predicting files
    label_idx = int(param_map.get("label_conf")) if param_map.has_key("label_conf") else 1
    log("start downloading training files..........")
    predicting_files_list = []
    if task_config.odps_volume_biz and task_config.odps_volume:
        # Download from odps volume
        odps_volume_biz = task_config.odps_volume_biz + '_' + task_config.bizdate
        predicting_files_list = download_files_from_volume(
            odps_id=task_config.odps_access_id,
            odps_key=task_config.odps_access_key,
            part=task_id,
            project=task_config.odps_project,
            volume=task_config.odps_volume,
            partition=odps_volume_biz,
            worker_num=worker_num,
            process_count=4
        )
        if predicting_files_list is None or len(predicting_files_list) == 0:
            log_error("No predict files found in [%s]/[%s]/[%s]" % (
                task_config.odps_project, task_config.odps_volume, odps_volume_biz))
            return
    elif task_config.odps_table:
        # Download from odps table
        if task_config.get_config("convert_to_records") and ast.literal_eval(
                task_config.get_config("convert_to_records")):
            partition = r"ds=%s" % task_config.bizdate
            data_dir = r"%s/%s/%s" % (work_dir, task_config.odps_table, task_config.bizdate)
            if not data_dir.startswith('hdfs://'):
                data_dir = "%s%s" % (get_defaultFS(), data_dir)
            log("Download data to %s" % data_dir)
            predicting_files_list, _ = download_data_from_odps_table(
                task_config.odps_project,
                task_config.odps_access_id,
                task_config.odps_access_key,
                task_config.odps_table,
                partition.encode(),
                task_id,
                worker_num,
                data_dir,
                parser=tf_record_parser,
                filesystem='hdfs',
                env=task_config.get_config('odps_env', 'online'),
                feature_conf_file=feature_conf_path,
                label_conf=label_idx
            )
        else:
            # TODO Add parser_fn for tf.TextLineReader
            log_error("Currently we do not support download plain text for wdl like model!")
            return

    start_time = time.time()
    log("Predicting files: {}".format(predicting_files_list))
    if len(predicting_files_list) > 0:
        predictions = classifier.predict(
            input_fn=lambda: build_batch_from_tf_records(file_list=predicting_files_list, feature_map=feature_map,
                                                         batch_size=task_config.predict_batch_size, num_epochs=1),
            outputs=[FeatureConfKeys.SAMPLE_LABEL, prediction_key.PredictionKey.LOGISTIC]
        )
        predictions_file = os.path.join(current_dir, 'predictions.txt')
        log("Predicting output: {}".format(predictions_file))

        with open(predictions_file, "w") as f:
            for num, p in enumerate(predictions):
                # log("predictions size::::: %d, %s" % (len(p), p.keys()))
                # sample_id = p[FeatureConfKeys.SAMPLE_ID][0]
                label = p[FeatureConfKeys.SAMPLE_LABEL][0]
                score = p[prediction_key.PredictionKey.LOGISTIC][0]
                f.write("{};{}\n".format(score, label))
                if num % 100 == 0:
                    log("predicting {} entries ....".format(num))
                if num >= task_config.predict_steps:
                    break

        # upload predict result to odps
        result_table = task_config.get_config("result_table")
        if result_table:
            log("Will upload data to {} ".format(result_table))
            odps_writer.upload(
                access_id=task_config.odps_access_id,
                access_key=task_config.odps_access_key,
                task_id=task_id,
                data_file=predictions_file,
                project=task_config.odps_project,
                table_name=result_table,
                ds=task_config.bizdate,
                split_key=";",
                field_names=["score", "label"],
                field_types=["string", "string"]
            )
    cost = time.time() - start_time
    log("All done, predicting totally cost --> [%d] s." % cost)


def realtime_training(target, param_map, context):
    log("Checkpoint Dir == %s" % FLAGS.ckp_dir)
    current_dir = os.path.dirname(os.path.abspath(__file__))

    # Parse config parameters
    conf_file_path = os.path.join(parent_directory(current_dir, 1),
                                  param_map.get("task_conf_file")) if param_map.has_key(
        "task_conf_file") else os.path.join(parent_directory(current_dir), 'config/task_config.json')
    log("Will use task conf file %s" % conf_file_path)
    task_config = TaskConfig(param_map=param_map, conf_file_path=conf_file_path)
    bizdate = (datetime.date.today() - datetime.timedelta(days=1)).strftime('%Y%m%d')
    task_config.add_if_not_contain("bizdate", bizdate)
    run_config = RunConfig(
        master=target,
        num_cores=0,
        save_summary_steps=1000,
        keep_checkpoint_max=2,
        save_checkpoints_secs=None,
        save_checkpoints_steps=task_config.save_chckpnt_steps,
        log_device_placement=False,
    )

    # copy feature config file to hdfs
    feature_conf_path = os.path.join(parent_directory(current_dir, 1),
                                     param_map.get("feature_conf_file")) if param_map.has_key(
        "feature_conf_file") else os.path.join(parent_directory(current_dir), 'config/td_feature_conf.json')
    log("conf file path == %s" % feature_conf_path)
    if run_config.is_chief:
        filesystem = HDFSFilesystem()
        if not filesystem.exists(FLAGS.ckp_dir):
            filesystem.mkdir(FLAGS.ckp_dir)
        filesystem.put(feature_conf_path, FLAGS.ckp_dir + '/fg.json')

    # 1. build Classifier
    fg = FeatureColumnGenerator(feature_conf_path)
    feature_map = fg.feature_map
    feature_column_conf = fg.feature_column_conf
    wide_dim = fg.get_wide_dim
    deep_dim = fg.get_deep_dim
    deep_net = task_config.get_config("deep_net")
    assert deep_net, "parameter dnn_net is needed to bulid model!"
    deep_net = ast.literal_eval(deep_net)
    model_fn = MODEL_FN_MAP.get(task_config.get_config("model"))
    assert model_fn, "currently support only wdl, pnn, deepFM or nfm!"
    log("will train a {} model".format(task_config.get_config("model")))
    classifier = DNNLinearCombinedClassifier(
        dnn_hidden_units=deep_net,
        config=run_config,
        linear_feature_columns=None if len(fg.wide_feature_list) == 0 else fg.wide_feature_list,
        dnn_feature_columns=None if len(fg.deep_feature_list) == 0 else fg.deep_feature_list,
        model_dir=FLAGS.ckp_dir,
        linear_optimizer=tf.train.FtrlOptimizer(
            learning_rate=0.1,
            learning_rate_power=task_config.learning_rate_power,
            initial_accumulator_value=task_config.initial_accumulator_value,
            l1_regularization_strength=task_config.l1_regularization_strength,
            l2_regularization_strength=task_config.l2_regularization_strength
        ),
        input_layer_min_slice_size=2048 << 20,
        hidden_layer_min_slice_size=2048 << 20,
        model_fn=model_fn,
        wide_dim=wide_dim,
        deep_dim=deep_dim,
        feature_column_conf=feature_column_conf,
        fix_global_step_increment_bug=True
    )

    # read data from blink and train, TODO: configurable schema
    full_schema = map(lambda x: FeatureItem(x[0], x[1][FeatureConfKeys.VALUE_TYPE]), fg.feature_conf_map.items())
    full_schema += [FeatureItem(x, y) for (x, y) in [('id', 'String'), ('label', 'Int'), ('type', 'String')]]
    source_schema = 'id,features,label,type'
    log("full_schema: %s" % full_schema)
    feed_hook = FeedHook(task_config.train_batch_size, env, source_schema, full_schema)
    classifier.fit(
        input_fn=lambda: read_input_from_blink(full_schema, task_config.train_batch_size),
        steps=task_config.train_steps,
        monitors=[feed_hook]
    )
    log("End Training.")


def main(unused_argv):
    Train().start(unused_args=unused_argv)


if __name__ == '__main__':
    Train().start()
