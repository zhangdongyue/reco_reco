from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import os
import json
from tensorflow.contrib.learn import RunConfig
from smart_io.console_log import log, log_error


def parse_parameter_map(params):
    param_map = {}
    try:
        param_map.update(parse_parameters(params))
        log("Parameter map %s" % param_map)
    except AttributeError:
        log_error("None parameters!")
    return param_map


def parse_parameters(params, delim=';', spliter='='):
    """
    :param delim: first level delim
    :param spliter: second level delim
    :param params: parameters in format key1=value1;key2=value2 to dict
    :return: result dict
    """
    return dict((key, value) for key, value in (line.partition(spliter)[::2] for line in params.strip().split(delim)))


def parse_features(params, delim=';', spliter=':'):
    """
    :param delim: first level delim
    :param spliter: second level delim
    :param params: parameters in format key1=value1;key2=value2 to dict
    :return: result dict
    """
    feature_map = {}
    if delim in params and spliter in params:
        for fea in params.strip().split(delim):
            key, value = fea.partition(spliter)[::2]
            if not feature_map.has_key(key):
                feature_map[key] = value
            else:
                feature_map[key] += '`' + value
    return feature_map



def parent_directory(path, times=1):
    backup_path = path
    for i in range(times):
        backup_path = os.path.dirname(backup_path)
    return backup_path


def build_run_config(target, cluster_spec, task_id, save_chckpnt_steps):
    os.environ['TF_CONFIG'] = json.dumps(
        {
            'cluster': cluster_spec.as_dict(),
            'task': {'type': 'worker',
                     'index': task_id},
        }
    )

    run_config = RunConfig(
        master=target,
        num_cores=0,
        save_summary_steps=1000,
        keep_checkpoint_max=2,
        save_checkpoints_secs=None,
        save_checkpoints_steps=save_chckpnt_steps,
        log_device_placement=False,
    )
    return run_config
