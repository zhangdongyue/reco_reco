import ast
import json

import sys
from tensorflow.python.lib.io import file_io


class TaskConfig(object):
    def __init__(self, param_map=None, conf_file_path=None):
        self._param_map = {}
        if conf_file_path:
            param_json_obj = json.load(file_io.FileIO(conf_file_path, 'r'))
            self._param_map = param_json_obj['parameters']
        if param_map:
            self._param_map.update(param_map)

    @property
    def odps_access_id(self):
        return self._param_map.get("odps_access_id", None)

    @property
    def odps_access_key(self):
        return self._param_map.get("odps_access_key", None)

    @property
    def odps_project(self):
        return self._param_map.get("odps_project", None)

    @property
    def odps_table(self):
        return self._param_map.get("odps_table", None)

    @property
    def odps_volume(self):
        return self._param_map.get("odps_volume", None)

    @property
    def odps_volume_biz(self):
        return self._param_map.get("odps_volume_biz", None)

    @property
    def bizdate(self):
        return self._param_map.get("bizdate", None)

    @property
    def train_steps(self):
        train_steps = self._param_map.get("train_steps", None)
        return int(train_steps) if train_steps else None

    @property
    def predict_steps(self):
        predict_steps = self._param_map.get("predict_steps", None)
        return int(predict_steps) if predict_steps else sys.maxint

    @property
    def train_batch_size(self):
        train_batch_size = self._param_map.get("train_batch_size", None)
        return int(train_batch_size) if train_batch_size else None

    @property
    def predict_batch_size(self):
        predict_batch_size = self._param_map.get("predict_batch_size", None)
        return int(predict_batch_size) if predict_batch_size else self.train_batch_size

    @property
    def save_chckpnt_steps(self):
        save_chckpnt_steps = self._param_map.get("save_chckpnt_steps", None)
        return int(save_chckpnt_steps) if save_chckpnt_steps else None

    @property
    def vali_per_steps(self):
        vali_per_steps = self._param_map.get("vali_per_steps", None)
        return int(vali_per_steps) if vali_per_steps else None

    @property
    def val_max_steps(self):
        val_max_steps = self._param_map.get("val_max_steps", None)
        return int(val_max_steps) if val_max_steps else None

    @property
    def learning_rate(self):
        learning_rate = self._param_map.get("learning_rate", None)
        return float(learning_rate) if learning_rate else None

    @property
    def learning_rate_power(self):
        learning_rate_power = self._param_map.get("learning_rate_power", None)
        return float(learning_rate_power) if learning_rate_power else None

    @property
    def initial_accumulator_value(self):
        initial_accumulator_value = self._param_map.get("initial_accumulator_value", None)
        return float(initial_accumulator_value) if initial_accumulator_value else None

    @property
    def l1_regularization_strength(self):
        l1_regularization_strength = self._param_map.get("l1_regularization_strength", None)
        return float(l1_regularization_strength) if l1_regularization_strength else None

    @property
    def l2_regularization_strength(self):
        l2_regularization_strength = self._param_map.get("l2_regularization_strength", None)
        return float(l2_regularization_strength) if l2_regularization_strength else None

    @property
    def config_map(self):
        return self._param_map

    def get_config(self, config_name, default=None):
        return self._param_map.get(config_name, default)

    def get_config_as_int(self, config_name, default=None):
        value_str = self.get_config(config_name, default)
        return int(value_str) if value_str else value_str

    def get_config_as_float(self, config_name, default=None):
        value_str = self.get_config(config_name, default)
        return float(value_str) if value_str else value_str

    def get_config_as_bool(self, config_name, default=None):
        raw_value = self.get_config(config_name, default)
        if raw_value and isinstance(raw_value, bool):
            return raw_value
        elif raw_value and isinstance(raw_value, str):
            return ast.literal_eval(raw_value)
        else:
            return False

    def contains(self, config_name):
        return config_name in self._param_map

    def add_config(self, key, value):
        self._param_map[key] = value

    def add_if_not_contain(self, key, value):
        if not self.contains(key):
            self.add_config(key, value)


if __name__ == '__main__':
    task_config = TaskConfig(param_map={'odps_project': 'ytrec'}, conf_file_path='../config/task_config.json')
    print(task_config.config_map)
