#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <string>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/basic_types.h"
#include "base/time/timestamp.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/hash_function/city.h"
#include "serving_base/utility/system_util.h"
#include "serving_base/utility/time_helper.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "swift/common/Common.h"
#include "swift/client/MessageInfo.h"
#include "swift/client/SwiftClient.h"
#include "swift/client/SwiftReader.h"
#include "autil/TimeUtility.h"
#include "reco/serv/ha3_data_flow/common/checkpoint.h"

using std::string;
using reco::kafka::Consumer;
using reco::kafka::Message;

// kafka
DEFINE_string(kafka_brokers, "127.0.0.1:9092,127.0.0.1:9092", "item kafka server");
DEFINE_string(kafka_group_id, "kafka2swift_reader", "");
DEFINE_string(kafka_topic, "test_ha3doc_item", "");
DEFINE_int32(kafka_partition_num, 2, "");
DEFINE_string(history_dir, "history", "history_dir of reader");
DEFINE_int32(sleep_seconds, 1, "");
DEFINE_int64_counter(reco_index, kafka2swift_consume_num, 0, "");

// swift
DEFINE_string(swift_zk_root, "zfs://11.180.60.200:2181/hippo_swift", "swift zookeeper root path");
DEFINE_string(swift_topic, "news_ha3_test", "swift topic name");
DEFINE_string(swift_alog_conf_file, "config/swift_alog.conf", "swift alog config file");
DEFINE_string(swift_retry_num, "3", "swift retry num");
DEFINE_string(swift_write_mode, "async|safe", "swift write mode");
DEFINE_int32(send_interval_seconds, 10, "swift send time interval by seconds");
DEFINE_int32(records_num_per_batch, 100, "swift send max records num in one batch");
DEFINE_string(wait_finish_miliseconds, "20000000", "wait timeout (us) for swift broker to write msg to disk");
DEFINE_int64_counter(reco_index, swift_produce_num, 0, "");

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "transmit kafka msg to swift");

  uint64 start_timestamp = 0;
  std::string timestamp_file = FLAGS_history_dir+ "/dump_timestamp.dat";
  reco::index_monitor::CheckPoint chp;
  chp.ReadCheckPoint(timestamp_file, &start_timestamp);

  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_kafka_topic;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = FLAGS_kafka_group_id;
  options.partition_num = FLAGS_kafka_partition_num;
  options.start_timestamp = start_timestamp/1000000;
  reco::kafka::Consumer* consumer = new reco::kafka::Consumer(FLAGS_kafka_brokers, options);
  CHECK_NOTNULL(consumer);

  swift::client::SwiftClient swiftClient;
  std::string  configStr = "zkPath="+std::string(FLAGS_swift_zk_root)
    +";logConfigFile="+std::string(FLAGS_swift_alog_conf_file)
    +";retryTime="+std::string(FLAGS_swift_retry_num);
  swift::protocol::ErrorCode ec = swiftClient.initByConfigStr(configStr);
  if (ec != swift::protocol::ERROR_NONE) {
    return -1;
  }

  swift::protocol::ErrorInfo errorInfo;
  std::string writerConf = "topicName="+std::string(FLAGS_swift_topic)
    +";mode="+std::string(FLAGS_swift_write_mode)
    +";waitFinishedWriterTime="+std::string(FLAGS_wait_finish_miliseconds)
    +";functionChain=HASH,hashId2partId";
  swift::client::SwiftWriter* swiftWriter = swiftClient.createWriter(writerConf, &errorInfo);
  if (errorInfo.has_errcode()) {
    LOG(ERROR) << "Create SwiftWriter failed. ErrorCode " << errorInfo.errcode();
    DELETE_AND_SET_NULL(swiftWriter);
    return -1;
  }

  std::string sstr = "";
  serving_base::TimeHelper::TimestampToString(options.start_timestamp*1000000L,
    serving_base::TimeHelper::kSecond, &sstr);
  LOG(INFO) << "kafka consumer start time:" << options.start_timestamp
    << " " << sstr;
  ::google::FlushLogFiles(::google::INFO);

  uint64 consume_timestamp = 0;
  uint64 msg_num = 0;
  int64 last_send_time = base::GetTimestamp()/1000000;
  std::vector<swift::client::MessageInfo> messageInfo_arr;
  bool send_flag = false;
  while (true) {
    reco::kafka::Message msg;
    if (!consumer->Consume(&msg)) {
      base::SleepForSeconds(FLAGS_sleep_seconds);
      LOG(INFO) << "nothing to read";
    } else {
      msg_num++;
      COUNTERS_reco_index__kafka2swift_consume_num.Increase(1);

      swift::client::MessageInfo messageInfo;

      messageInfo.hashStr = msg.key;
      messageInfo.data = msg.content;

      messageInfo_arr.push_back(messageInfo);

      LOG(INFO) << "\tkey=" << msg.key
        << ",time=" << msg.timestamp_ms
        << ",pt=" << msg.partition
        << ",offset=" << msg.offset;

      consume_timestamp = msg.timestamp_ms*1000;
    }

    int64 cur_time = base::GetTimestamp()/1000000;
    int64 time_interval = cur_time-last_send_time;
    if (time_interval >= FLAGS_send_interval_seconds && !messageInfo_arr.empty()) {
      LOG(INFO) << "time_interval=" << time_interval << ", need send";
      send_flag = true;
    }

    if (messageInfo_arr.size() >= static_cast<uint32>(FLAGS_records_num_per_batch)) {
      LOG(INFO) << "batch size=" << messageInfo_arr.size() << ", need send";
      send_flag = true;
    }

    if ( send_flag ) {
      int retry_num = 0;

      while (retry_num <= 3) {
        ec = swiftWriter->writes(messageInfo_arr, true);
        if (ec != swift::protocol::ERROR_NONE) {
          LOG(INFO) << "write swift fail, ec=" << ec <<" retry=" << ++retry_num;
          base::SleepForMilliseconds(100);
        } else {
          LOG(INFO) << "write swift succ, num=" << messageInfo_arr.size();
          break;
        }
      }

      chp.WriteCheckPoint(timestamp_file, consume_timestamp);

      last_send_time = cur_time;
      messageInfo_arr.clear();
      send_flag = false;
    }
  }

  if (consumer) {
    delete consumer;
    consumer = NULL;
  }

  DELETE_AND_SET_NULL(swiftWriter);
}

