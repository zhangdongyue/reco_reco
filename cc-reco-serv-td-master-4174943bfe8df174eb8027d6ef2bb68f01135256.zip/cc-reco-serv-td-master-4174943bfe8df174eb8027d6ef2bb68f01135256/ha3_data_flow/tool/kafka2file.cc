#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <string>
#include <set>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/basic_types.h"
#include "base/time/timestamp.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/hash_function/city.h"
#include "serving_base/utility/system_util.h"
#include "serving_base/utility/time_helper.h"
#include "reco/base/kafka_c/api_cc/consumer.h"

using std::string;
using reco::kafka::Consumer;
using reco::kafka::Message;

// kafka
DEFINE_string(kafka_brokers, "127.0.0.1:9092,127.0.0.1:9092", "item kafka server");
DEFINE_string(kafka_group_id, "kafka2file_reader", "");
DEFINE_string(kafka_topic, "test_ha3doc_item", "");
DEFINE_int32(kafka_partition_num, 2, "");
DEFINE_string(history_dir, "data", "history_dir of reader");
DEFINE_int32(sleep_seconds, 1, "");
DEFINE_int32(start_timestamp_sec, 0, " msg start timestamp");
DEFINE_int32(stop_timestamp_sec, 0, " msg stop timestamp");
DEFINE_int64_counter(reco_index, kafka2file_consume_num, 0, "");
DEFINE_string(dump_filepath, "dump.dat", "output file ");

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "read kafka msg to file");

  int64 start_timestamp = 0;
  int64 stop_timestamp = 0;
  int64 consume_timestamp = 0;

  std::string msg_start_sstr = "";
  std::string msg_stop_sstr = "";

  if ( FLAGS_start_timestamp_sec >= 0 ) {
    start_timestamp = (FLAGS_start_timestamp_sec-60) * 1000000L;
  }

  if (start_timestamp < 0) {
    start_timestamp = 0;
  }

  if ( FLAGS_stop_timestamp_sec > 0 ) {
    stop_timestamp = (FLAGS_stop_timestamp_sec+60) * 1000000L;
  } else {
    stop_timestamp = base::GetTimestamp();
  }

  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_kafka_topic;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = FLAGS_kafka_group_id;
  options.partition_num = FLAGS_kafka_partition_num;
  options.start_timestamp = start_timestamp/1000000;
  reco::kafka::Consumer* consumer = new reco::kafka::Consumer(FLAGS_kafka_brokers, options);
  CHECK_NOTNULL(consumer);

  serving_base::TimeHelper::TimestampToString(start_timestamp,
    serving_base::TimeHelper::kSecond, &msg_start_sstr);

  serving_base::TimeHelper::TimestampToString(stop_timestamp,
    serving_base::TimeHelper::kSecond, &msg_stop_sstr);


  LOG(INFO) << "kafkaread, start=" << start_timestamp
    << " " << msg_start_sstr
    << ", stop=" << stop_timestamp
    << " " << msg_stop_sstr;
  ::google::FlushLogFiles(::google::INFO);

  std::ofstream   ofresult;
  std::string ofname = FLAGS_dump_filepath;
  ofresult.open(ofname);

  if (ofresult.is_open()) {
    LOG(ERROR) << "open file succ: " << ofname;
  } else {
    LOG(ERROR) << "open file fail: " << ofname;
    return -1;
  }

  uint64 msg_num = 0;
  int retry_num = 0;
  std::set<int> exceed_set;

  while (true) {
    reco::kafka::Message msg;
    if (!consumer->Consume(&msg)) {
      LOG(INFO) << "nothing to read, retry=" << retry_num;
      base::SleepForSeconds(FLAGS_sleep_seconds);
      retry_num++;
    } else {
      retry_num = 0;
      COUNTERS_reco_index__kafka2file_consume_num.Increase(1);
      consume_timestamp = msg.timestamp_ms*1000;

      if ((consume_timestamp-stop_timestamp) > 1000000L) {
        LOG(INFO) << "\tkey=" << msg.key
          << ",time=" << msg.timestamp_ms
          << ",pt=" << msg.partition
          << ",offset=" << msg.offset
          << ", timeout";
        exceed_set.insert(msg.partition);

        if (static_cast<int>(exceed_set.size()) < FLAGS_kafka_partition_num) {
          continue;
        } else {
          LOG(INFO) << "all exceed, stop";
          break;
        }
      } else {
        LOG(INFO) << "\tkey=" << msg.key
          << ",time=" << msg.timestamp_ms
          << ",pt=" << msg.partition
          << ",offset=" << msg.offset;

        ofresult << msg.content;
        msg_num++;
      }
    }
  }

  if (consumer) {
    delete consumer;
    consumer = NULL;
  }

  LOG(INFO) << "dump_num=" << msg_num;
  ofresult.flush();
  ofresult.close();
}

