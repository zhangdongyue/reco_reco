#include "reco/serv/ha3_data_flow/common/checkpoint.h"

#include <iostream>
#include <fstream>
#include <vector>
#include <string>

#include "base/common/gflags.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/time/timestamp.h"
#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"

#include "serving_base/utility/system_util.h"
#include "serving_base/utility/time_helper.h"

namespace reco {
  namespace index_monitor {

    void CheckPoint::ReadCheckPoint(const std::string& timestamp_file, uint64* start_timestamp ) {
      if (base::file_util::PathExists(timestamp_file)) {
        base::file_util::MemoryMappedFile mapped_file;
        CHECK(mapped_file.Initialize(timestamp_file)) << "mapped timestamp file failed: " << timestamp_file;
        if (mapped_file.size() == 8) {
          *start_timestamp = *reinterpret_cast<const int64 *>(mapped_file.data());
        } else {
          std::vector<std::string> lines;
          base::file_util::ReadFileToLines(timestamp_file, &lines);
          CHECK(lines.size()) << "invalid dump file: " << timestamp_file;
          CHECK(serving_base::TimeHelper::StringToTimestamp(lines[0],
              serving_base::TimeHelper::kSecond,
              start_timestamp))
            << "invalid dump timestamp: " << lines[0];
        }
      }
    }

    void CheckPoint::WriteCheckPoint(const std::string& timestamp_file, uint64 consumer_timestamp) {
      if (consumer_timestamp < 86400*1000*1000u) {
        return;
      }

      consumer_timestamp -= 600*1000*1000u;

      std::string data;
      CHECK(serving_base::TimeHelper::TimestampToString(
          consumer_timestamp, serving_base::TimeHelper::kSecond, &data));
      const std::string new_file = timestamp_file + ".new";
      CHECK_EQ(base::file_util::WriteFile(new_file, const_cast<char*>(data.data()),
          data.size()), (int)data.size());
      CHECK(base::file_util::Move(new_file, timestamp_file));
      LOG(INFO) << "write checkpoint " << consumer_timestamp << "," << data;
    }
  }
}
