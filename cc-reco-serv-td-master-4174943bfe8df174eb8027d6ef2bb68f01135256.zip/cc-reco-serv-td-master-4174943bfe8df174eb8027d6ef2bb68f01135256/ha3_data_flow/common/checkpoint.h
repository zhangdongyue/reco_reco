#pragma once
#include<string>
#include "base/common/basic_types.h"

namespace reco {
  namespace index_monitor {

    class  CheckPoint {
    public:
      void ReadCheckPoint(const std::string& fpath, uint64* t);
      void WriteCheckPoint(const std::string& fpath, uint64 t);
    };
  }
}
