#include "base/common/base.h"
#include "base/common/gflags.h"
#include "net/counter/export.h"
#include "base/strings/string_split.h"
#include "serving_base/utility/signal.h"
#include "serving_base/data_manager/server_frame.h"
#include "serving_base/data_manager/data_manager.h"

#include "reco/serv/dict_server/frame/dict_impl.h"
#include "reco/serv/dict_server/frame/global_manager.h"
#include "reco/serv/dict_server/handler/global_data.h"
#include "reco/serv/dict_server/handler/data_manager.h"
#include "reco/serv/dict_server/handler/data_consumer.h"

DEFINE_int32(port, 20006, "the listening port on which the serving application listens");
DEFINE_int32(work_thread_num, 8, "work_thread_num");
DEFINE_int32(rpc_thread_num, 8, "rpc_thread_num");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "dict server");
  net::counter::HttpCounterExport();

  reco::dict::GlobalData global_data;
  serving_base::DataManangerConfig config;
  config.controller_item_num = FLAGS_work_thread_num;
  reco::dictserver::DictDataManager::Initialize(config, &global_data);
  reco::dictserver::DictDataManager::GetGlobalData()->Init();
  reco::dictserver::DictImpl dict_service;

  reco::dict::DataMgr::instance().Init();
  reco::dict::DataConsumerIns::instance().Init();

  serving_base::ServerFrameConfig server_frame_config;
  server_frame_config.rpc_threads_num = FLAGS_rpc_thread_num;
  server_frame_config.rpc_server_port = FLAGS_port;
  server_frame_config.service = &dict_service;
  server_frame_config.dict_manager = reco::dictserver::DictDataManager::GetDictManager();
  serving_base::ServerFrame server_frame(server_frame_config);

  // dict server
  server_frame.Start();
  LOG(INFO) << "dict server start";

  // data consumer
  reco::dict::DataConsumerIns::instance().Run();
  LOG(INFO) << "data consumer start";

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();

  server_frame.Stop();
  LOG(INFO)<< "dict server safe quit";

  reco::dictserver::DictDataManager::GetGlobalData()->Stop();
  reco::dictserver::DictDataManager::Release();

  reco::dict::DataMgr::instance().Stop();
  reco::dict::DataConsumerIns::instance().Stop();

  return 0;
}
