#include <iostream>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/testing/gtest.h"
#include "base/common/logging.h"

#include "reco/serv/dict_server/handler/dict_mgmt.h"

namespace reco {
namespace dictserver {
using reco::dict::DictMgmt;

class DictMgmtTest : public testing::Test {
 public:
  DictMgmt dict_mgmt_;
  virtual void SetUp() {
  }
};

TEST_F(DictMgmtTest, SetData) {
  const std::string key = DictMgmt::GenRealKey("mf", "key1", "1");
  std::string value;

  ASSERT_TRUE(dict_mgmt_.SetData(key, "value1"));
  ASSERT_TRUE(dict_mgmt_.GetData(true, key, &value));
  ASSERT_EQ(value, "value1");
}

TEST_F(DictMgmtTest, GetData) {
  const std::string key = DictMgmt::GenRealKey("mf", "key1", "1");
  std::string value;
  ASSERT_TRUE(dict_mgmt_.GetData(true, key, &value));
  ASSERT_EQ(value, "value1");
}

TEST_F(DictMgmtTest, DelKey) {
  const std::string key = DictMgmt::GenRealKey("mf", "key1", "1");
  std::string value;

  ASSERT_TRUE(dict_mgmt_.DelKey(key));
  dict_mgmt_.GetData(true, key, &value);
  ASSERT_EQ(value, "");
}
}
}
