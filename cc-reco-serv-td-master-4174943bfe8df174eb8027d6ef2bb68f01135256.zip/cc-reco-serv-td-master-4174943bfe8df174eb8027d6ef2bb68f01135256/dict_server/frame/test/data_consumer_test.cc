#include <iostream>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"

#include "reco/base/kafka_c/api_cc/producer.h"
#include "reco/bizc/proto/reco_dict_server.pb.h"
#include "base/strings/string_number_conversions.h"

#include "reco/serv/dict_server/api/dict_server_api.h"

namespace reco {
namespace dictserver {

DEFINE_string(kafka_brokers, "", "");
DEFINE_string(dict_server_topic, "", "");
DEFINE_int32(dict_server_partition_num, 10, "");

class DataConsumerTest : public testing::Test {
 public:
  virtual void SetUp() {
    DictServerAPIIns::instance().Init();
  }
};

TEST_F(DataConsumerTest, FetchFromKafka) {
  DictServerAPIIns::instance().DelKey("data_consumer", "key", "version");
  reco::dict::SetDataRequest request;
  request.mutable_key_elements()->set_product("data_consumer");
  request.mutable_key_elements()->set_key("key");
  request.mutable_key_elements()->set_version("version");
  request.set_value("value");
  std::string str;
  ASSERT_TRUE(request.SerializeToString(&str));
  reco::kafka::Producer producer(FLAGS_kafka_brokers,
                                 FLAGS_dict_server_topic);
  for (int i = 0; i < FLAGS_dict_server_partition_num; ++i) {
    ASSERT_TRUE(producer.Produce(str));
  }
  base::SleepForSeconds(3);
  std::string value;
  ASSERT_TRUE(DictServerAPIIns::instance().GetData("data_consumer", "key", "version", &value));
  ASSERT_EQ("value", value);
}
}
}
