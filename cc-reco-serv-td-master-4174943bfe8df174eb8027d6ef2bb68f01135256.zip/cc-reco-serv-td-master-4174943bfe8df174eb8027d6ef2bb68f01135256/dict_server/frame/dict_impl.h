#pragma once

#include "reco/bizc/proto/reco_dict_server.pb.h"
#include "base/thread/blocking_queue.h"

namespace reco {
namespace dictserver {
class DictService_Stub;

enum ReqType {
  kInvalidType = 0,
  kGetData,
  kSetData,
  kDelKey,
};

struct StWorkParam {
  const ::google::protobuf::Message* request;
  ::google::protobuf::Message* response;
  ::Closure* done;
  int64 time_stamp;
  ReqType type;

  StWorkParam() : request(NULL), response(NULL), done(NULL), time_stamp(NULL), type(kInvalidType) {}

  StWorkParam(const ::google::protobuf::Message *req, ::google::protobuf::Message *resp,
              ::Closure *closure_done, const int64 stamp, const ReqType req_type) {
    request = req;
    response = resp;
    done = closure_done;
    time_stamp = stamp;
    type = req_type;
  }
};

class DictImpl : public DictService {
 public:
  DictImpl();
  ~DictImpl();

  // 获取 key value
  virtual void getData(stumy::RpcController* controller,
                       const reco::dict::GetDataRequest* request,
                       reco::dict::GetDataResponse* response,
                       Closure* done);

  // 设置 key value
  virtual void setData(stumy::RpcController* controller,
                       const reco::dict::SetDataRequest* request,
                       reco::dict::SetDataResponse* response,
                       Closure* done);

  // 删除 key 以及它的 value
  virtual void delKey(stumy::RpcController* controller,
                      const reco::dict::DelKeyRequest* request,
                      reco::dict::DelKeyResponse* response,
                      Closure* done);
 private:
  // 所有请求的入口
  void Process(StWorkParam param);

  void getData(const int64 timestamp,
               const reco::dict::GetDataRequest* request,
               reco::dict::GetDataResponse* response,
               Closure* done);

  void setData(const int64 timestamp,
               const reco::dict::SetDataRequest* request,
               reco::dict::SetDataResponse* response,
               Closure* done);

  void delKey(const int64 timestamp,
              const reco::dict::DelKeyRequest* request,
              reco::dict::DelKeyResponse* response,
              Closure* done);

 private:
  mutable thread::Mutex mutex_;
  double get_data_max_cost_;
  double set_data_max_cost_;
  double del_key_max_cost_;
};

}  // namespace userserver
}  // namespace reco
