#pragma once

#include "base/common/basic_types.h"
#include "base/thread/sync.h"
#include "serving_base/data_manager/data_manager.h"

#include "reco/serv/dict_server/handler/global_data.h"
#include "reco/serv/dict_server/handler/dict_mgmt.h"

namespace serving_base {
template<typename Controller, typename GlobalData>
class DataManager;
}

namespace reco {
namespace dictserver {
// forward declare
// struct reco::dict::GlobalData;
typedef serving_base::DataManager<reco::dict::DictMgmt, reco::dict::GlobalData> DictDataManager;
}  // namespace dictserver
}  // namespace reco
