#include "reco/serv/dict_server/api_arpc/dict_server_api.h"

#include <algorithm>

#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "serving_base/utility/timer.h"

using namespace arpc_client_pool::client_pool;

namespace reco {
namespace dictserver {
DEFINE_string(dict_server_ips, "127.0.0.1:20006", "dict server ip");
DEFINE_int32(dict_server_timeout, 500, "dict server timeout");
DEFINE_int32(dict_server_retry, 2, "");
DEFINE_int32(dict_server_pool_size, 6, "");

DictServerAPI::DictServerAPI() : init_(false) {
}

DictServerAPI::~DictServerAPI() {
}

void DictServerAPI::Init() {
  if (init_) {
    return;
  }

  init_ = true;
  LOG(INFO) << "init";

  std::vector<std::string> ips_vec;
  base::SplitString(FLAGS_dict_server_ips, ",", &ips_vec);

  PoolParams params;
  params.clientCount = FLAGS_dict_server_pool_size * (int)ips_vec.size();

  std::set<StubInfo> stub_info;
  for (const auto& ip_info : ips_vec) {
    std::vector<std::string> ip_port;
    base::SplitString(ip_info, ":", &ip_port);
    int port = 0;
    if (base::StringToInt(ip_port[1], &port)) {
      stub_info.insert(StubInfo(ip_port[0], port));
    }
  }

  conn_pool_ = new ArpcClientPool<reco::dictserver::DictService_Stub>();
  if (!conn_pool_->init(params, stub_info)) {
    LOG(FATAL) << "conn pool fail:" << FLAGS_dict_server_ips;
  }
}

void DictServerAPI::Stop() {
  init_ = false;
  if (conn_pool_) {
    delete conn_pool_;
    conn_pool_ = NULL;
  }
}

bool DictServerAPI::GetData(const std::string &product,
                            const std::string &key,
                            const std::string &version,
                            std::string *value,
                            const bool &use_cache,
                            const int timeout_ms,
                            int retry) {
  serving_base::Timer timer;
  timer.Start();

  reco::dict::GetDataRequest request;
  LoadGetDataRequest(product, key, version, use_cache, &request);
  reco::dict::GetDataResponse response;

  bool ret = false;
  while (retry-- >= 0 && !ret) {
    arpc::ANetRPCController cntler;
    cntler.SetExpireTime(timeout_ms);
    cntler.SetErrorCode(arpc::ARPC_ERROR_NONE);

    auto stub_ptr = conn_pool_->get();
    if (!stub_ptr) {
      base::SleepForMilliseconds(5);
      continue;
    }

    timer.Interval();
    stub_ptr->stub()->getData(&cntler, &request, &response, NULL);
    VLOG(1) << " dict get retry=" << retry << " tout=" << timeout_ms << " getData(ms):" << timer.Interval()/1000;
    int err_code = cntler.GetErrorCode();
    if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
      stub_ptr->setErrorCode(err_code);
      LOG(ERROR) << "rpc fail:" << err_code
        << " ip=" << stub_ptr->info().ip();
      continue;
    }
    ret = true;
    break;
  }

  if (ret) {
    *value = response.value();
  }

  return ret;
}

bool DictServerAPI::SetData(const std::string &product,
                            const std::string &key,
                            const std::string &version,
                            const std::string &value,
                            const int timeout_ms,
                            int retry) {
  reco::dict::SetDataRequest request;
  LoadSetDataRequest(product, key, version, value, &request);
  reco::dict::SetDataResponse response;

  bool ret = false;
  while (retry-- >= 0 && !ret) {
    arpc::ANetRPCController cntler;
    cntler.SetExpireTime(timeout_ms);
    cntler.SetErrorCode(arpc::ARPC_ERROR_NONE);

    auto stub_ptr = conn_pool_->get();
    stub_ptr->stub()->setData(&cntler, &request, &response, NULL);
    int err_code = cntler.GetErrorCode();
    if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
      LOG(ERROR) << "rpc fail:" << err_code
        << " ip=" << stub_ptr->info().ip();
      continue;
    }
    ret = true;
    break;
  }

  return ret;
}


bool DictServerAPI::DelKey(const std::string &product,
                           const std::string &key,
                           const std::string &version,
                           const int timeout_ms,
                           int retry) {
  reco::dict::DelKeyRequest request;
  LoadDelKeyRequest(product, key, version, &request);
  reco::dict::DelKeyResponse response;

  bool ret = false;
  while (retry-- >= 0 && !ret) {
    arpc::ANetRPCController cntler;
    cntler.SetExpireTime(timeout_ms);
    cntler.SetErrorCode(arpc::ARPC_ERROR_NONE);

    auto stub_ptr = conn_pool_->get();
    stub_ptr->stub()->delKey(&cntler, &request, &response, NULL);
    int err_code = cntler.GetErrorCode();
    if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
      LOG(ERROR) << "rpc fail:" << err_code
        << " ip=" << stub_ptr->info().ip();
      continue;
    }
    ret = true;
    break;
  }

  return ret;
}
}
}
