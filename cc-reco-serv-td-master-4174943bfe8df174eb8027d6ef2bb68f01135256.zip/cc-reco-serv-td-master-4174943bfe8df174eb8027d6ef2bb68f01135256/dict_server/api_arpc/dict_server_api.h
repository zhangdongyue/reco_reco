#pragma once

#include <string>
#include <vector>

#include "base/common/gflags.h"
#include "base/common/basic_types.h"
#include "client_pool/ArpcClientPool.h"

#include "reco/base/common/singleton.h"
#include "reco/bizc/proto_arpc/reco_dict_server.pb.h"

namespace reco {
namespace dictserver {
DECLARE_int32(dict_server_timeout);
DECLARE_int32(dict_server_retry);

class DictServerAPI {
 public:
  DictServerAPI();
  ~DictServerAPI();

  bool GetData(const std::string &product,
               const std::string &key,
               const std::string &version,
               std::string *value,
               const bool &use_cache = true,
               const int timeout_ms = FLAGS_dict_server_timeout,
               int retry = FLAGS_dict_server_retry);

  bool SetData(const std::string &product,
               const std::string &key,
               const std::string &version,
               const std::string &value,
               const int timeout_ms = FLAGS_dict_server_timeout,
               int retry = FLAGS_dict_server_retry);

  bool DelKey(const std::string &product,
              const std::string &key,
              const std::string &version,
              const int timeout_ms = FLAGS_dict_server_timeout,
              int retry = FLAGS_dict_server_retry);

  void Init(void);

  void Stop(void);

 private:

  void LoadKeyElements(const std::string &product,
                       const std::string &key,
                       const std::string &version,
                       reco::dict::KeyElements *key_elements) {
    key_elements->set_product(product);
    key_elements->set_key(key);
    key_elements->set_version(version);
  }

  void LoadGetDataRequest(const std::string &product,
                          const std::string &key,
                          const std::string &version,
                          const bool &use_cache,
                          reco::dict::GetDataRequest *request) {
    LoadKeyElements(product, key, version, request->mutable_key_elements());
    request->set_use_cache(use_cache);
  }

  void LoadSetDataRequest(const std::string &product,
                          const std::string &key,
                          const std::string &version,
                          const std::string &value,
                          reco::dict::SetDataRequest *request) {
    LoadKeyElements(product, key, version, request->mutable_key_elements());
    request->set_value(value);
  }

  void LoadDelKeyRequest(const std::string &product,
                         const std::string &key,
                         const std::string &version,
                         reco::dict::DelKeyRequest *request) {
    LoadKeyElements(product, key, version, request->mutable_key_elements());
  }

 private:
  arpc_client_pool::client_pool::ArpcClientPool<reco::dictserver::DictService_Stub> *conn_pool_;
  std::atomic<bool> init_;

  // DISALLOW_COPY_AND_ASSIGN(DictServerAPI);
};

typedef reco::common::singleton_default<DictServerAPI> DictServerAPIIns;
}
}
