#include <iostream>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/testing/gtest.h"
#include "base/common/logging.h"

#include "reco/serv/dict_server/api_arpc/dict_server_api.h"

namespace reco {
namespace dictserver {
class DictServerAPITest : public testing::Test {
 public:
  virtual void SetUp() {
    DictServerAPIIns::instance().Init();
    LOG(INFO) << "set up";
  }

  void TearDown() {
    DictServerAPIIns::instance().Stop();
    LOG(INFO) << "tear down";
  }
};

TEST_F(DictServerAPITest, DelKey) {
  ASSERT_TRUE(DictServerAPIIns::instance().DelKey("prodcut", "test_key", "version"));
  std::string value;
  ASSERT_TRUE(DictServerAPIIns::instance().GetData("prodcut", "test_key", "version", &value));
  ASSERT_EQ(value, "");
}

TEST_F(DictServerAPITest, SetData) {
  ASSERT_TRUE(DictServerAPIIns::instance().SetData("prodcut", "test_key", "version", "value"));
  std::string value;
  ASSERT_TRUE(DictServerAPIIns::instance().GetData("prodcut", "test_key", "version", &value));
  ASSERT_EQ(value, "value");
}
}
}
