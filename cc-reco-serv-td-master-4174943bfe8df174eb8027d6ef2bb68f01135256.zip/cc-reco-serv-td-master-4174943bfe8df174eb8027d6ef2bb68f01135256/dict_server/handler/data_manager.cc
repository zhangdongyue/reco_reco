#include "reco/serv/dict_server/handler/data_manager.h"

namespace reco {
namespace dict {
DEFINE_string(aero_nodes, "127.0.0.1:3000", "");
DEFINE_string(dict_aero_ns, "dict_server", "dict durable data");
DEFINE_string(dict_aero_set, "dict_set", "");

// 命中率
DEFINE_int64_counter(dict, get_from_aero_total, 0, "");

const char *kAeroBinName = "data";

void DataManager::Init() {
  aero_cli_.reset(new reco::aero::Client(FLAGS_aero_nodes));
  redis_cli_.reset(new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips));
  LOG(INFO) << "init";
}

void DataManager::Stop() {
  aero_cli_.reset();
  redis_cli_.reset();
  LOG(INFO) << "stop";
}

bool DataManager::GetData(const bool &use_cache, const std::string &key, std::string *value) {
  CHECK_NOTNULL(value);
  if (key.empty()) {
    value->clear();
    LOG(WARNING) << "key is empty!";
    return true;
  }

  // from redis
  if (use_cache && redis_cli_->Get(key, value) == 0) return true;

  // aero
  std::vector<std::string> values;
  std::vector<std::string> aero_bins;
  aero_bins.push_back(kAeroBinName);
  if (aero_cli_->GetData(key, aero_bins, &values,
                        FLAGS_dict_aero_ns, FLAGS_dict_aero_set)) {
    // 回写到 redis
    if (use_cache) redis_cli_->SetEx(key, values[0]);

    COUNTERS_dict__get_from_aero_total.Increase(1);
    *value = values[0];
    return true;
  }

  DLOG(INFO) << "get from aero fail! " << key;
  return false;
}

bool DataManager::SetData(const std::string &key, const std::string &value) {
  if (key.empty()) return true;

  // redis
  if (!redis_cli_->Del(key)) {
    DLOG(ERROR) << "del redis fail! key:" << key;
  }

  // aero 只要成功一次就算成功
  if (aero_cli_->SetData(key, kAeroBinName, value, FLAGS_dict_aero_ns, FLAGS_dict_aero_set)) {
    return true;
  }

  LOG(ERROR) << "set data to aero error! " << key;
  return false;
}

bool DataManager::DelKey(const std::string &key) {
  if (key.empty()) return true;

  // del redis
  const bool redis_ret = redis_cli_->Del(key);
  if (!redis_ret) {
    LOG(ERROR) << "del redis fail! key:" << key;
  }

  // del aero
  const bool aero_ret = aero_cli_->DelKey(key, FLAGS_dict_aero_ns, FLAGS_dict_aero_set);
  if (!aero_ret) {
    LOG(ERROR) << "del aero fail! key:" << key;
  }

  return redis_ret && aero_ret;
}
}
}
