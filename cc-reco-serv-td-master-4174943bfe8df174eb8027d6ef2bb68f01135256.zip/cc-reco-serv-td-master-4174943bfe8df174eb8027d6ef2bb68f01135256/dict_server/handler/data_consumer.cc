#include "reco/serv/dict_server/handler/data_consumer.h"

#include "base/hash_function/term.h"
#include "base/time/time.h"
#include "serving_base/utility/timer.h"

#include "reco/base/diamond/diamond_client.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/serv/dict_server/handler/dict_mgmt.h"
#include "reco/bizc/proto/reco_dict_server.pb.h"

namespace reco {
namespace dict {
DEFINE_int32(set_data_pool_size, 10, "");
DEFINE_int32(global_set_data_pool_size, 10, "");
DEFINE_string(kafka_brokers, "127.0.0.1:9092", "blocker list");
DEFINE_string(dict_server_topic, "dict_server_topic", "当前机房的kafka topic");
DEFINE_string(dict_server_group, "dict_server_group", "当前机房的kafka group");
DEFINE_int32(dict_server_partition_num, 10, "");

DEFINE_string(global_kafka_brokers, "127.0.0.1:9092", "blocker list");
DEFINE_string(global_dict_server_topic, "dict_server_topic", "所有机房都要消费的kafka topic");
DEFINE_string(global_dict_server_group, "dict_server_group", "所有机房都要消费的kafka group");
DEFINE_int32(global_dict_server_partition_num, 10, "");
DEFINE_int64(max_consume_num, 10000, "每秒消费的kafka数量阈值");

DEFINE_int64_counter(dict, set_data_from_kafka_total, 0, "");
DEFINE_double_counter(dict, set_data_from_kafka_cost, 0.0, "");
DEFINE_double_counter(dict, set_data_from_kafka_max_cost, 0.0, "");

DEFINE_int64_counter(dict, async_set_gap, 0, "当前机房异步写与进kafka的间隔");
DEFINE_int64_counter(dict, global_async_set_gap, 0, "所有机房异步写与进kafka的间隔");
DEFINE_int64_counter(dict, local_consume_total, 0, "所有机房异步写与进kafka的间隔");
DEFINE_int64_counter(dict, global_consume_total, 0, "所有机房异步写与进kafka的间隔");

void DataConsumer::Init() {
  set_data_pool_ = new thread::ThreadPool(FLAGS_set_data_pool_size);
  CHECK_NOTNULL(set_data_pool_);
  global_set_data_pool_ = new thread::ThreadPool(FLAGS_set_data_pool_size);
  CHECK_NOTNULL(global_set_data_pool_);
  all_thread_run_ = true;
}

void DataConsumer::Stop() {
  all_thread_run_ = false;
  logic_run_ = false;
  set_data_pool_->JoinAll();
  global_set_data_pool_->JoinAll();

  if (set_data_pool_) {
    delete set_data_pool_;
    set_data_pool_ = NULL;
  }

  if (global_set_data_pool_) {
    delete global_set_data_pool_;
    global_set_data_pool_ = NULL;
  }

  if (topic_consumer_) {
    delete topic_consumer_;
    topic_consumer_ = NULL;
  }

  if (global_topic_consumer_) {
    delete global_topic_consumer_;
    global_topic_consumer_ = NULL;
  }
}

void DataConsumer::Run() {
  if (logic_run_) {
    LOG(INFO) << "DataConsumer had run";
    return;
  }
  logic_run_ = true;

  Init();

  LOG(INFO) << "dict_server partition_num is: " << FLAGS_dict_server_partition_num;
  // init kafka show log consumer
  reco::kafka::ConsumerOptions option;
  option.topic = FLAGS_dict_server_topic;
  option.group_id = FLAGS_dict_server_group;
  option.partition_num = FLAGS_dict_server_partition_num;
  option.type = reco::kafka::kConsumerExclusive;

  if (FLAGS_set_data_pool_size > 0) {
    topic_consumer_ = new reco::kafka::Consumer(FLAGS_kafka_brokers, option);
  }
  for (int i = 0; i < FLAGS_set_data_pool_size; ++i) {
    set_data_pool_->AddTask(::NewCallback(this, &DataConsumer::ConsumeDataFromKafka, topic_consumer_));
  }

  reco::kafka::ConsumerOptions global_option;
  global_option.topic = FLAGS_global_dict_server_topic;
  global_option.group_id = FLAGS_global_dict_server_group;
  global_option.partition_num = FLAGS_global_dict_server_partition_num;
  global_option.type = reco::kafka::kConsumerExclusive;

  if (FLAGS_global_set_data_pool_size > 0) {
    global_topic_consumer_ = new reco::kafka::Consumer(FLAGS_global_kafka_brokers, global_option);
  }

  for (int i = 0; i < FLAGS_global_set_data_pool_size; ++i) {
    global_set_data_pool_->AddTask(::NewCallback(this,
                                                 &DataConsumer::ConsumeDataFromKafka,
                                                 global_topic_consumer_));
  }
}

void DataConsumer::ConsumeDataFromKafka(reco::kafka::Consumer* consumer) {
  DictMgmt dict_mgmt;
  reco::kafka::Message msg;
  SetDataRequest request;
  std::string real_key;
  LOG(INFO) << "start consume data from kafka.";

  using reco::diamondclient::DiamondClient;

  static const int64 sampling_num = 100;
  int64 estimated_time = 1000 * sampling_num / DiamondClient::IntValue("max_consume_num");
  static std::atomic<int64> consume_kafka_count{0};
  static std::atomic<int64> next_reset_count_time{base::GetTimestamp() / 1000};
  while (all_thread_run_) {
    msg.Clear();
    if (!consumer->Consume(&msg)) {
      base::SleepForMilliseconds(200);
      DLOG(INFO) << "fetch from kafka fail " << msg.content;
      continue;
    }

    const int64 interval_in_seconds = (base::GetTimestamp() - msg.timestamp_ms) / 1000;
    if (consumer == topic_consumer_) {
      COUNTERS_dict__async_set_gap.Reset(interval_in_seconds);
      COUNTERS_dict__local_consume_total.Increase(1);
    } else if (consumer == global_topic_consumer_) {
      COUNTERS_dict__global_async_set_gap.Reset(interval_in_seconds);
      COUNTERS_dict__global_consume_total.Increase(1);
    }

    DLOG(INFO) << "fetch from kafka: " << msg.content;
    request.Clear();
    if (!request.ParseFromString(msg.content)) {
      LOG(ERROR) << "failed to parse SetDataRequest from pb: " << msg.content;
      continue;
    }

    real_key = DictMgmt::GenRealKey(request.key_elements().product(),
                                    request.key_elements().key(),
                                    request.key_elements().version());

    // timer
    serving_base::Timer timer;
    timer.Start();
    bool set_ret = dict_mgmt.SetData(DictMgmt::GenRealKey(request.key_elements()), request.value());
    const double total_time = timer.Stop();
    COUNTERS_dict__set_data_from_kafka_cost.Increase(total_time);
    if (total_time > set_data_from_kafka_max_cost_) {
      set_data_from_kafka_max_cost_ = total_time;
      COUNTERS_dict__set_data_from_kafka_max_cost.Reset(total_time);
    }
    COUNTERS_dict__set_data_from_kafka_total.Increase(1);
    LOG(INFO) << "set data from kafka. success: " << set_ret
              << ", real_key: " << real_key;
    int64 now_time = base::GetTimestamp() / 1000;
    if (++consume_kafka_count >= sampling_num) {
      // 动态参数重算步长
      estimated_time = 1000 * sampling_num / DiamondClient::IntValue("max_consume_num");

      consume_kafka_count = 0;
      if (now_time > next_reset_count_time) {
        next_reset_count_time = std::max(now_time, next_reset_count_time + estimated_time);
      }
    }
    if (now_time < next_reset_count_time) {
      base::SleepForMilliseconds(next_reset_count_time - now_time);
    }
  }  // while all_thread_run_
}
}
}
