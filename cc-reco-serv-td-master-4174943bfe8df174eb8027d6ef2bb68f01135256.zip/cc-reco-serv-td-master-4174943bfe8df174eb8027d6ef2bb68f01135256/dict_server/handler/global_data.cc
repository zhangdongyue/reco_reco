#include "reco/serv/dict_server/handler/global_data.h"
#include "reco/base/diamond/diamond_client.h"

DEFINE_string(diamond_data_id, "shenma.xss.dict_server", "diamond data id");
DEFINE_string(diamond_group, "em21.offline", "diamond group");
DEFINE_string(diamond_jmenv, "", "diamond域名，只有张北等受限机房才需要设置");

namespace reco {
namespace dict {

const reco::diamondclient::ValueMap default_value = {
  {"max_consume_num", 10000}
};

void GlobalData::Init() {
  reco::dict::DataMgr::instance().Init();
  work_thread_pool = new thread::ThreadPool(FLAGS_work_thread_num);
  CHECK_NOTNULL(work_thread_pool);
  thread_pool_enable = true;

  // 初始化动态参数
  diamondclient::DiamondClient::SetDefaultValue(default_value);
  diamondclient::DiamondClient::AddMasterListener(FLAGS_diamond_data_id, FLAGS_diamond_group);
  if (!FLAGS_diamond_jmenv.empty()) diamondclient::DiamondClient::SetGlobalJMENV(FLAGS_diamond_jmenv);
}

}
}
