#pragma once
#include <vector>
#include <string>

#include "reco/bizc/proto/reco_dict_server.pb.h"
#include "reco/serv/dict_server/handler/data_manager.h"

namespace reco {
namespace dict {
class DictMgmt {
 public:
  DictMgmt() {}

  ~DictMgmt() {}

  // 不同的产品有不同的名字 每个 key 都有版本 product + '##' + key + '##' + version 组成真正存的 key
  bool GetData(const bool &use_cache, const std::string &key, std::string *value) {
    return DataMgr::instance().GetData(use_cache, key, value);
  }

  bool SetData(const std::string &key, const std::string &value) {
    return DataMgr::instance().SetData(key, value);
  }

  bool DelKey(const std::string &key) {
    return DataMgr::instance().DelKey(key);
  }

  static std::string GenRealKey(const reco::dict::KeyElements &key_elems) {
    return GenRealKey(key_elems.product(), key_elems.key(), key_elems.version());
  }

  static std::string GenRealKey(const std::string &product,
                                const std::string &key,
                                const std::string &version) {
    return product + "##" + key + "##" + version;
  }
};
}
}
