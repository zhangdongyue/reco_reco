#pragma once

#include "base/common/basic_types.h"
#include "base/thread/thread_pool.h"

#include "reco/serv/dict_server/handler/dict_mgmt.h"

DECLARE_int32(work_thread_num);

namespace reco {
namespace dict {
struct GlobalData {
  ::thread::ThreadPool *work_thread_pool;
  std::atomic_bool thread_pool_enable;

  GlobalData() : work_thread_pool(NULL), thread_pool_enable(false) {}

  ~GlobalData() {}

  void Init();

  void Stop() {
    if (work_thread_pool) {
      StopThreads();
      delete work_thread_pool;
      work_thread_pool = NULL;
    }

    reco::dict::DataMgr::instance().Stop();
  }

  bool IsThreadPoolEnabled() {
    return (work_thread_pool != NULL) && thread_pool_enable;
  }

  // 与本结构体的析构过程线程不安全，不能并行
  void StopThreads() {
    if (work_thread_pool) {
      thread_pool_enable = false;
      work_thread_pool->StopAll();
      delete work_thread_pool;
      work_thread_pool = NULL;
      LOG(INFO) << "stopped";
      ::google::FlushLogFiles(::google::INFO);
    }
  }
};

}  // namespace dictserver
}  // namespace reco
