#pragma once

#include <string>
#include <vector>

#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"

#include "reco/base/common/singleton.h"

namespace reco {
namespace kafka {
class Consumer;
}

namespace dict {
class DataConsumer {
 public:
  DataConsumer() {}
  ~DataConsumer() {}

  void Init();

  void Stop();

  // 整个 DataConsumer 运行入口
  void Run();

 private:
  // 从 kafka 队列中取数据并消费入库
  void ConsumeDataFromKafka(reco::kafka::Consumer* consumer);

 private:
  thread::ThreadPool *set_data_pool_;
  thread::ThreadPool *global_set_data_pool_;
  std::atomic_bool all_thread_run_;
  std::atomic_bool logic_run_;
  // kafka
  reco::kafka::Consumer* topic_consumer_;
  reco::kafka::Consumer* global_topic_consumer_;
  double set_data_from_kafka_max_cost_;
  DISALLOW_COPY_AND_ASSIGN(DataConsumer);
};

typedef reco::common::singleton_default<DataConsumer> DataConsumerIns;
}
}
