#pragma once

#include <vector>
#include <string>
#include <memory>

#include "reco/base/common/singleton.h"
#include "reco/base/aerospike_c/api/client.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

namespace reco {
namespace dict {
class DataManager {
 public:
  DataManager() {}

  ~DataManager() {}

  void Init();

  void Stop();

  bool GetData(const bool &use_cache, const std::string &key, std::string *value);

  bool SetData(const std::string &key, const std::string &value);

  bool DelKey(const std::string &key);

 private:
  std::shared_ptr<reco::aero::Client> aero_cli_;
  std::shared_ptr<reco::redis::RedisCli> redis_cli_;

  DISALLOW_COPY_AND_ASSIGN(DataManager);
};

typedef reco::common::singleton_default<DataManager> DataMgr;
}
}
