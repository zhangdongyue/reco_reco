#include <iostream>
#include <string>

#include "base/common/base.h"
#include "reco/bizc/proto/reco_dict_server.pb.h"
#include "reco/base/kafka_c/api/topic_producer.h"
#include "reco/base/kafka_c/api/topic_consumer.h"
#include "base/random/pseudo_random.h"
#include "base/common/sleep.h"

DEFINE_string(pb_name, "GetDataRequest", "GetDataRequest/SetDataRequest/DelKeyRequest");
DEFINE_string(product, "product", "");
DEFINE_string(key, "key", "");
DEFINE_string(key_version, "version", "");
DEFINE_string(value, "value", "");
DEFINE_string(dict_server_brokers, "127.0.0.1:9092", "blocker list");
DEFINE_string(dict_server_topic, "dict_server_topic", "");
DEFINE_int32(dict_server_partition_num, 10, "");

template<class T>
bool ProtoToString(const T &proto, std::string *str) {
  CHECK(str);
  return proto.SerializeToString(str);
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "dict server client");
  std::string str;
  if (FLAGS_pb_name == "GetDataRequest") {
    reco::dict::GetDataRequest request;
    request.mutable_key_elements()->set_product(FLAGS_product);
    request.mutable_key_elements()->set_key(FLAGS_key);
    request.mutable_key_elements()->set_version(FLAGS_key_version);
    if (ProtoToString(request, &str)) {
      std::cout << str << std::endl;
    }
  }
  if (FLAGS_pb_name == "SetDataRequest") {
    reco::dict::SetDataRequest request;
    request.mutable_key_elements()->set_product(FLAGS_product);
    request.mutable_key_elements()->set_key(FLAGS_key);
    request.mutable_key_elements()->set_version(FLAGS_key_version);
    request.set_value(FLAGS_value);
    if (ProtoToString(request, &str)) {
      std::cout << str << std::endl;
    }
  }
  if (FLAGS_pb_name == "DelKeyRequest") {
    reco::dict::DelKeyRequest request;
    request.mutable_key_elements()->set_product(FLAGS_product);
    request.mutable_key_elements()->set_key(FLAGS_key);
    request.mutable_key_elements()->set_version(FLAGS_key_version);
    if (ProtoToString(request, &str)) {
      std::cout << str << std::endl;
    }
  }


  base::SleepForSeconds(3);
  reco::kafka::TopicProducer producer(FLAGS_dict_server_brokers,
                                      FLAGS_dict_server_topic,
                                      FLAGS_dict_server_partition_num);
  for (int i = 0; i < FLAGS_dict_server_partition_num; ++i) {
    if (producer.Push(i, str)) {
      std::cout << "push " << str << " success!" << std::endl;
    }
  }
  return 0;
}
