#include <iostream>
#include <unordered_map>
#include <fstream>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"

#include "reco/bizc/proto/reco_dict_server.pb.h"
#include "reco/serv/dict_server/api/dict_server_api.h"


int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "dict server batch_get_client");
  reco::dictserver::DictServerAPIIns::instance().Init();
  std::string line;
  int total = 0;
  int suc = 0;
  while (std::getline(std::cin, line)) {
    std::vector<std::string> tokens;
    base::SplitString(line, "\t", &tokens);
    if (tokens.size() < 3) continue;
    auto product = tokens[0];
    auto key = tokens[1];
    auto version = tokens[2];
    std::string value;
    if (reco::dictserver::DictServerAPIIns::instance().GetData(product, key, version, &value, true)) {
      if (value.size() > 0) {
        suc++;
      }
    }
    total++;
  }
  std::cout << total << " " << suc << std::endl;
  return 0;
}
