#include <iostream>
#include <unordered_map>
#include <fstream>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "net/rpc/rpc.h"
#include "net/rpc_util/rpc_group.h"

#include "reco/bizc/proto/reco_dict_server.pb.h"
#include "reco/serv/dict_server/api/dict_server_api.h"

DEFINE_int32(server_timeout, 500, "dict server timeout");
DEFINE_string(method, "get", "get/read/set/del");
DEFINE_string(product, "reco", "");
DEFINE_string(key, "", "");
DEFINE_string(key_version, "", "");
DEFINE_string(value, "", "");
DEFINE_bool(use_cache, false, "");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "dict server client");
/*
  bool is_get = false;
  bool is_del = false;
  if (FLAGS_method == "get") {
    is_get = true;
  } else if (FLAGS_method == "read") {
    is_read = true;
  } else if (FLAGS_method == "set") {
    is_get = false;
  } else if (FLAGS_method == "del") {
    is_del = true;
  } else {
    CHECK(false) << "method only be get or set";
  }
*/
  reco::dictserver::DictServerAPIIns::instance().Init();
  if (FLAGS_method == "get") {
    std::string value;
    if (!reco::dictserver::DictServerAPIIns::instance().GetData(FLAGS_product,
                                                                FLAGS_key,
                                                                FLAGS_key_version,
                                                                &value,
                                                                FLAGS_use_cache)) {
      LOG(ERROR) << "get data fail!";
    } else {
      std::cout << FLAGS_key << "\tvalue size:" << value.size() << std::endl;
    }
  }
  else if (FLAGS_method == "read") {
    std::string value;
    if (!reco::dictserver::DictServerAPIIns::instance().GetData(FLAGS_product,
                                                                FLAGS_key,
                                                                FLAGS_key_version,
                                                                &value,
                                                                FLAGS_use_cache)) {
      LOG(ERROR) << "read data fail!";
    } else {
      std::cout << FLAGS_key << "\tvalue:" << value << std::endl;
    }
  }
  else if (FLAGS_method == "del") {
    if (!reco::dictserver::DictServerAPIIns::instance().DelKey(FLAGS_product, FLAGS_key, FLAGS_key_version)) {
      LOG(ERROR) << "del key fail!";
    } else {
      std::cout << "del key " << FLAGS_key << std::endl;
    }
  }
  else if (FLAGS_method == "set") {
    if (!reco::dictserver::DictServerAPIIns::instance().SetData(FLAGS_product,
                                                                FLAGS_key,
                                                                FLAGS_key_version,
                                                                FLAGS_value)) {
      LOG(ERROR) << "set data fail!";
    } else {
      std::cout << "set key:" << FLAGS_key << " value:" << FLAGS_value << std::endl;
    }
  } else {
    CHECK(false) << "method only be get/read/set/del";
  }

  return 0;
}

