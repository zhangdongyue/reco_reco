#include "reco/serv/dict_server/api/dict_server_api.h"

#include  <algorithm>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"

namespace reco {
namespace dictserver {

DEFINE_string(dict_server_machine_list, "test_dict_server.yaml", "dict server config file");
DEFINE_int32(dict_server_timeout, 500, "dict server timeout");
DEFINE_int32(dict_server_retry, 2, "");

void RpcCompleteCallback(thread::BlockingVar<bool>* rpc_complete) {
  if (rpc_complete != NULL) {
    rpc_complete->TryPut(true);
  }
}

DictServerAPI::DictServerAPI() {
}

DictServerAPI::~DictServerAPI() {
  if (get_data_communicator) {
    delete get_data_communicator;
  }
  if (set_data_communicator) {
    delete set_data_communicator;
  }
  if (del_key_communicator) {
    delete del_key_communicator;
  }
}

void DictServerAPI::Init() {
  serving_base::CommunicateConfig config("");
  config.file_name = FLAGS_dict_server_machine_list;
  config.timeout = FLAGS_dict_server_timeout;
  config.max_retry_times = FLAGS_dict_server_retry;
  config.enable_heart_beat = false;
  config.heart_beat_timeout = 50;
  config.heart_beat_slow_times = 3;
  config.heart_beat_ignore_times = 50;
  config.total_timeout = FLAGS_dict_server_timeout * FLAGS_dict_server_retry;
  config.enable_child_reload = false;

  get_data_communicator = new GetDataCommunicator(config, &reco::dictserver::DictService::getData);
  set_data_communicator = new SetDataCommunicator(config, &reco::dictserver::DictService::setData);
  del_key_communicator = new DelKeyCommunicator(config, &reco::dictserver::DictService::delKey);

  CHECK_NOTNULL(get_data_communicator);
  CHECK_NOTNULL(set_data_communicator);
  CHECK_NOTNULL(del_key_communicator);
}

bool DictServerAPI::GetData(const std::string &product,
                            const std::string &key,
                            const std::string &version,
                            std::string *value,
                            const bool &use_cache,
                            const int timeout_ms,
                            const int retry) {
  reco::dict::GetDataRequest request;
  LoadGetDataRequest(product, key, version, use_cache, &request);
  reco::dict::GetDataResponse response;

  GetDataCommunicator::RequestConfig config;
  config.method = GetDataCommunicator::Random;
  config.timeout = timeout_ms;
  config.total_timeout = timeout_ms * retry;
  config.retry_times = retry;

  GetDataCommunicator::ResponseCollection resp_collect;
  thread::BlockingVar<bool> rpc_complete;

  get_data_communicator->RemoteCall(request,
                                    config,
                                    &resp_collect,
                                    NewCallback(&RpcCompleteCallback, &rpc_complete));
  rpc_complete.Take();

  if (!resp_collect.success) {
    return false;
  }

  for (auto i = 0u; i < resp_collect.responses->size(); ++i) {
    if (resp_collect.responses->at(i) && resp_collect.responses->at(i)->success()) {
      *value = resp_collect.responses->at(i)->value();
      return true;
    }
  }
  return false;
}


bool DictServerAPI::SetData(const std::string &product,
                            const std::string &key,
                            const std::string &version,
                            const std::string &value,
                            const int timeout_ms,
                            const int retry) {
  reco::dict::SetDataRequest request;
  LoadSetDataRequest(product, key, version, value, &request);

  SetDataCommunicator::RequestConfig config;
  config.method = SetDataCommunicator::Random;
  config.timeout = timeout_ms;
  config.total_timeout = timeout_ms * retry;
  config.retry_times = retry;

  SetDataCommunicator::ResponseCollection resp_collect;
  thread::BlockingVar<bool> rpc_complete;

  set_data_communicator->RemoteCall(request,
                                    config,
                                    &resp_collect,
                                    NewCallback(&RpcCompleteCallback, &rpc_complete));
  rpc_complete.Take();

  if (!resp_collect.success) {
    return false;
  }

  for (auto i = 0u; i < resp_collect.responses->size(); ++i) {
    if (resp_collect.responses->at(i) && resp_collect.responses->at(i)->success()) {
      return true;
    }
  }
  return false;
}


bool DictServerAPI::DelKey(const std::string &product,
                           const std::string &key,
                           const std::string &version,
                           const int timeout_ms,
                           const int retry) {
  reco::dict::DelKeyRequest request;
  LoadDelKeyRequest(product, key, version, &request);

  DelKeyCommunicator::RequestConfig config;
  config.method = DelKeyCommunicator::Random;
  config.timeout = timeout_ms;
  config.total_timeout = timeout_ms * retry;
  config.retry_times = retry;

  DelKeyCommunicator::ResponseCollection resp_collect;
  thread::BlockingVar<bool> rpc_complete;

  del_key_communicator->RemoteCall(request,
                                    config,
                                    &resp_collect,
                                    NewCallback(&RpcCompleteCallback, &rpc_complete));
  rpc_complete.Take();

  if (!resp_collect.success) {
    return false;
  }

  for (auto i = 0u; i < resp_collect.responses->size(); ++i) {
    if (resp_collect.responses->at(i) && resp_collect.responses->at(i)->success()) {
      return true;
    }
  }
  return false;
}
}
}
