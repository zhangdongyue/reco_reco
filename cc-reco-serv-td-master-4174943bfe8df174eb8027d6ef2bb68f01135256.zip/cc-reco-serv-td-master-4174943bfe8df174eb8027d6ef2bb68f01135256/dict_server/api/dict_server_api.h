#pragma once
#include <string>
#include <vector>
#include "net/rpc/rpc.h"
#include "serving_base/rpc_communicator/remote_caller.h"
#include "net/rpc_util/rpc_group.h"

#include "reco/bizc/proto/reco_dict_server.pb.h"
#include "reco/base/common/singleton.h"

namespace reco {
namespace dictserver {

DECLARE_int32(dict_server_timeout);
DECLARE_int32(dict_server_retry);

typedef serving_base::RemoteCaller<reco::dictserver::DictService::Stub,
        reco::dict::GetDataRequest,
        reco::dict::GetDataResponse> GetDataCommunicator;
typedef serving_base::RemoteCaller<reco::dictserver::DictService::Stub,
        reco::dict::SetDataRequest,
        reco::dict::SetDataResponse> SetDataCommunicator;
typedef serving_base::RemoteCaller<reco::dictserver::DictService::Stub,
        reco::dict::DelKeyRequest,
        reco::dict::DelKeyResponse> DelKeyCommunicator;

class DictServerAPI {
 public:
  DictServerAPI();
  ~DictServerAPI();

  bool GetData(const std::string &product,
               const std::string &key,
               const std::string &version,
               std::string *value,
               const bool &use_cache = true,
               const int timeout_ms = FLAGS_dict_server_timeout,
               const int retry = FLAGS_dict_server_retry);

  bool SetData(const std::string &product,
               const std::string &key,
               const std::string &version,
               const std::string &value,
               const int timeout_ms = FLAGS_dict_server_timeout,
               const int retry = FLAGS_dict_server_retry);

  bool DelKey(const std::string &product,
              const std::string &key,
              const std::string &version,
              const int timeout_ms = FLAGS_dict_server_timeout,
              const int retry = FLAGS_dict_server_retry);

  void Init(void);

 private:

  void LoadKeyElements(const std::string &product,
                       const std::string &key,
                       const std::string &version,
                       reco::dict::KeyElements *key_elements) {
    key_elements->set_product(product);
    key_elements->set_key(key);
    key_elements->set_version(version);
  }

  void LoadGetDataRequest(const std::string &product,
                          const std::string &key,
                          const std::string &version,
                          const bool &use_cache,
                          reco::dict::GetDataRequest *request) {
    LoadKeyElements(product, key, version, request->mutable_key_elements());
    request->set_use_cache(use_cache);
  }

  void LoadSetDataRequest(const std::string &product,
                          const std::string &key,
                          const std::string &version,
                          const std::string &value,
                          reco::dict::SetDataRequest *request) {
    LoadKeyElements(product, key, version, request->mutable_key_elements());
    request->set_value(value);
  }

  void LoadDelKeyRequest(const std::string &product,
                         const std::string &key,
                         const std::string &version,
                         reco::dict::DelKeyRequest *request) {
    LoadKeyElements(product, key, version, request->mutable_key_elements());
  }

 private:
  GetDataCommunicator* get_data_communicator;
  SetDataCommunicator* set_data_communicator;
  DelKeyCommunicator* del_key_communicator;
  DISALLOW_COPY_AND_ASSIGN(DictServerAPI);
};

typedef reco::common::singleton_default<DictServerAPI> DictServerAPIIns;
}
}
