#include <vector>
#include <iostream>

#include "base/common/basic_types.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/time/timestamp.h"
#include "base/common/sleep.h"
#include "serving_base/utility/timer.h"
#include "base/file/file_util.h"

#include "reco/bizc/proto/reco_dict_server.pb.h"
#include "reco/serv/dict_server/api/dict_server_api.h"
#include "reco/base/kafka_c/api_cc/producer.h"

DEFINE_int32(thread_num, 10, "");
DEFINE_int32(request_num_per_thread, 1000, "");
DEFINE_int32(key_length, 10, "");
DEFINE_int32(value_length, 10, "");
DEFINE_string(method, "getData", "getData/SetData/DelKey");
DEFINE_string(test_case, "random", "random/file/kafka");
DEFINE_string(press_file, "press_file.txt", "");
DEFINE_string(kafka_brokers, "", "");
DEFINE_string(dict_server_topic, "", "");

struct Status {
  int success_num;
  int all_num;
  double max_cost;
  double all_cost;
  Status() {
    success_num = 0;
    all_num = 0;
    max_cost = 0.0;
    all_cost = 0.0;
  }
};

void run(std::vector<Status>* status_list, int index) {
  std::string id = base::IntToString(index);
  std::string value = "";
  for (int i = 0; i < FLAGS_value_length; ++i) {
    value += "b";
  }
  for (int i = 0; i < FLAGS_request_num_per_thread; ++i) {
    serving_base::Timer timer;
    std::string key = id + base::IntToString(i);
    bool ok = false;
    double total_time = 0;
    if (FLAGS_method == "getData") {
      std::string v;
      timer.Start();
      ok = reco::dictserver::DictServerAPIIns::instance().GetData("test_mf", key, "1", &v);
      total_time = timer.Stop();
    } else if (FLAGS_method == "setData") {
      timer.Start();
      ok = reco::dictserver::DictServerAPIIns::instance().SetData("test_mf", key, "1", value);
      total_time = timer.Stop();
    } else if (FLAGS_method == "delKey") {
      timer.Start();
      ok = reco::dictserver::DictServerAPIIns::instance().DelKey("test_mf", key, "1");
      total_time = timer.Stop();
    }

    status_list->at(index).all_num += 1;
    if (ok) {
      status_list->at(index).success_num += 1;
    }
    if (total_time > status_list->at(index).max_cost) {
      status_list->at(index).max_cost = total_time;
    }
    status_list->at(index).all_cost += total_time;
  }
}

void PushToKafka(std::vector<Status>* status_list, int index) {
  std::string id = base::IntToString(index);
  std::string value = "";
  for (int i = 0; i < FLAGS_value_length; ++i) {
    value += "b";
  }
  reco::kafka::Producer producer(FLAGS_kafka_brokers,
                                 FLAGS_dict_server_topic);
  for (int i = 0; i < FLAGS_request_num_per_thread; ++i) {
    serving_base::Timer timer;
    std::string key = id + base::IntToString(i);
    double total_time = 0;
    reco::dictserver::SetDataRequest request;
    request.mutable_key_elements()->set_product("test_kafka");
    request.mutable_key_elements()->set_key(key);
    request.mutable_key_elements()->set_version("version");
    request.set_value(value);
    std::string str;
    if (request.SerializeToString(&str)) {
      producer.Produce(str, key);
    }
    total_time = timer.Stop();

    status_list->at(index).all_num += 1;
    status_list->at(index).success_num += 1;
    if (total_time > status_list->at(index).max_cost) {
      status_list->at(index).max_cost = total_time;
    }
    status_list->at(index).all_cost += total_time;
  }
}

void AsyncSet() {
  std::vector<Status> status_list;
  thread::ThreadPool pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    status_list.push_back(Status());
    pool.AddTask(::NewCallback(&PushToKafka, &status_list, i));
  }
  pool.JoinAll();
  int all_num = 0;
  int success_num = 0;
  double all_cost = 0;
  double max_cost = 0;
  double qps = 0;
  for (auto i = 0u; i < status_list.size(); ++i) {
    all_num += status_list[i].all_num;
    success_num += status_list[i].success_num;
    all_cost += status_list[i].all_cost;
    if (status_list[i].max_cost > max_cost) {
      max_cost = status_list[i].max_cost;
    }
    qps += status_list[i].all_num / status_list[i].all_cost * 1000 * 1000;
  }
  std::cout << "avg cost(ms): " << all_cost / all_num / 1000 << std::endl;
  std::cout << "max cost(ms): " << max_cost / 1000<< std::endl;
  std::cout << "success num: " << success_num << std::endl;
  std::cout << "all num: " << all_num << std::endl;
  std::cout << "qps: " << qps << std::endl;
}

void RandomRequest() {
  std::vector<Status> status_list;
  thread::ThreadPool pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    status_list.push_back(Status());
    pool.AddTask(::NewCallback(&run, &status_list, i));
  }
  pool.JoinAll();
  int all_num = 0;
  int success_num = 0;
  double all_cost = 0;
  double max_cost = 0;
  double qps = 0;
  for (auto i = 0u; i < status_list.size(); ++i) {
    all_num += status_list[i].all_num;
    success_num += status_list[i].success_num;
    all_cost += status_list[i].all_cost;
    if (status_list[i].max_cost > max_cost) {
      max_cost = status_list[i].max_cost;
    }
    qps += status_list[i].all_num / status_list[i].all_cost * 1000 * 1000;
  }
  std::cout << "avg cost(ms): " << all_cost / all_num / 1000 << std::endl;
  std::cout << "max cost(ms): " << max_cost / 1000<< std::endl;
  std::cout << "success num: " << success_num << std::endl;
  std::cout << "all num: " << all_num << std::endl;
  std::cout << "qps: " << qps << std::endl;
}

void PressLines(std::vector<std::string> *lines, int index) {
  for (int i = index; i < (int)lines->size(); i += FLAGS_thread_num) {
    std::vector<std::string> tokens;
    base::SplitString(lines->at(i), "\t", &tokens);
    if ((int)tokens.size() < 2) {
      continue;
    }
    reco::dictserver::DictServerAPIIns::instance().SetData("press_tool", tokens[0], "1", tokens[1]);
  }
}

void PressFromFile() {
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_press_file, &lines);
  serving_base::Timer timer;
  timer.Start();
  thread::ThreadPool pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    pool.AddTask(::NewCallback(&PressLines, &lines, i));
  }
  pool.JoinAll();
  double cost = timer.Stop();
  std::cout << "press " << lines.size() << " lines" << " cost " << cost/1000000 << " seconds" << std::endl;
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "press tool");
  reco::dictserver::DictServerAPIIns::instance().Init();
  if (FLAGS_test_case == "random") {
    RandomRequest();
  } else if (FLAGS_test_case == "file") {
    PressFromFile();
  } else if (FLAGS_test_case == "kafka") {
    AsyncSet();
  }
  return 0;
}
