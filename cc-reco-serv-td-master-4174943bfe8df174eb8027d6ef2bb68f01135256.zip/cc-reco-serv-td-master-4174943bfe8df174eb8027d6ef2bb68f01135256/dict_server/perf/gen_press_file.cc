#include <vector>
#include <iostream>
#include <fstream>

#include "base/common/basic_types.h"
#include "base/common/base.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/time/timestamp.h"
#include "base/common/sleep.h"
#include "base/random/uuid.h"
#include "base/thread/thread_pool.h"

#include "reco/base/kafka_c/api/topic_producer.h"
#include "reco/bizc/proto/reco_dict_server.pb.h"

DEFINE_int32(user_num, 100000, "");
DEFINE_int32(item_num_per_user, 210, "");
DEFINE_bool(gen_press_file, false, "");
DEFINE_string(press_file_path, "press_file.txt", "");
DEFINE_bool(push_to_dict_server, true, "");
DEFINE_int32(thread_num, 10, "");
DEFINE_string(dict_server_brokers, "127.0.0.1:9092", "blocker list");
DEFINE_string(dict_server_topic, "dict_server_topic", "");
DEFINE_int32(dict_server_partition_num, 10, "");

void GenUserRecoItemList() {
  std::string name;
  base::GenerateUuid(&name);
  std::ofstream fout(FLAGS_press_file_path + "_" + name);
  std::string user_id;
  std::string item_id;
  reco::kafka::TopicProducer producer(FLAGS_dict_server_brokers,
                                      FLAGS_dict_server_topic,
                                      FLAGS_dict_server_partition_num);
  std::string str;
  reco::dictserver::SetDataRequest request;
  for (int i = 0; i < FLAGS_user_num; ++i) {
    base::GenerateUuid(&user_id);
    std::vector<std::string> item_list;
    for (int j = 0; j < FLAGS_item_num_per_user; ++j) {
      base::GenerateUuid(&item_id);
      item_list.push_back(item_id);
    }
    if (FLAGS_gen_press_file) {
      fout << user_id << "\t" << base::JoinStrings(item_list, ",") << std::endl;
    }
    request.Clear();
    request.mutable_key_elements()->set_product("product");
    request.mutable_key_elements()->set_key(user_id);
    request.mutable_key_elements()->set_version("version");
    request.set_value(base::JoinStrings(item_list, ","));
    request.SerializeToString(&str);
    producer.Push(i, str);
  }
  fout.close();
}

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "gen_press_file");
  thread::ThreadPool thread_pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    thread_pool.AddTask(::NewCallback(&GenUserRecoItemList));
  }
  thread_pool.JoinAll();
  return 0;
}
