#pragma once

#include "reco/serv/dict_server/handler/global_data.h"

namespace reco {
namespace dictserver {

typedef reco::common::singleton_default<reco::dict::GlobalData> GlobalDataMgr;

}  // namespace dictserver
}  // namespace reco
