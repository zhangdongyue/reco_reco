#pragma once

#include "arpc/CommonMacros.h"
#include "base/thread/blocking_queue.h"
#include "reco/bizc/proto_arpc/reco_dict_server.pb.h"
#include "reco/serv/dict_server/handler/dict_mgmt.h"

namespace reco {
namespace dictserver {

class DictService_Stub;

enum ReqType {
  kInvalidType = 0,
  kGetData,
  kSetData,
  kDelKey,
};

struct StWorkParam {
  ::google::protobuf::RpcController* controller;
  const ::google::protobuf::Message* request;
  ::google::protobuf::Message* response;
  ::google::protobuf::Closure* done;
  int64 time_stamp;
  ReqType type;
  reco::dict::DictMgmt* dict_mgmt;

  StWorkParam() { Clear(); }

  void Clear() {
    controller = nullptr;
    request = nullptr;
    response = nullptr;
    done = nullptr;
    time_stamp = 0;
    type = kInvalidType;
    dict_mgmt = nullptr;
  }

  StWorkParam(::google::protobuf::RpcController* ctlr,
              const ::google::protobuf::Message *req, 
              ::google::protobuf::Message *resp,
              ::google::protobuf::Closure *closure_done, 
              const int64 stamp, const ReqType req_type) {
    controller = ctlr;
    request = req;
    response = resp;
    done = closure_done;
    time_stamp = stamp;
    type = req_type;
  }
};

class DictImpl : public DictService {
 public:
  DictImpl();
  ~DictImpl();

  // 获取 key value
  virtual void getData(::google::protobuf::RpcController* controller,
                       const ::reco::dict::GetDataRequest* request,
                       ::reco::dict::GetDataResponse* response,
                       ::google::protobuf::Closure* done);

  // 设置 key value
  virtual void setData(::google::protobuf::RpcController* controller,
                       const ::reco::dict::SetDataRequest* request,
                       ::reco::dict::SetDataResponse* response,
                       ::google::protobuf::Closure* done);

  // 删除 key 以及它的 value
  virtual void delKey(::google::protobuf::RpcController* controller,
                      const ::reco::dict::DelKeyRequest* request,
                      ::reco::dict::DelKeyResponse* response,
                      ::google::protobuf::Closure* done);
 private:
  // 所有请求的入口
  void Process(const int thread_idx);

  void GetData(StWorkParam param, std::string *details = nullptr);

  void SetData(StWorkParam param, std::string *details = nullptr);

  void DelKey(StWorkParam param, std::string *details = nullptr);

 private:
  ::thread::BlockingQueue<StWorkParam> request_queue_;
  std::atomic<bool> is_run_;
  mutable thread::Mutex mutex_;
  double get_data_max_cost_;
  double set_data_max_cost_;
  double del_key_max_cost_;
};

}  // namespace userserver
}  // namespace reco
