#include "base/common/base.h"
#include "base/common/gflags.h"
#include "net/counter/export.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "serving_base/utility/signal.h"
#include "arpc/ANetRPCServer.h"
#include "arpc/CommonMacros.h"
#include "arpc/RPCInterface.h"

#include "reco/serv/dict_server/frame_arpc/dict_impl.h"
#include "reco/serv/dict_server/frame_arpc/global_manager.h"
#include "reco/serv/dict_server/handler/global_data.h"
#include "reco/serv/dict_server/handler/data_consumer.h"

DEFINE_int32(port, 20006, "the listening port on which the serving application listens");
DEFINE_int32(work_thread_num, 8, "work_thread_num");
DEFINE_int32(rpc_thread_num, 8, "rpc_thread_num");
DEFINE_int32(rpc_queue_size, 1000, "rpc queue size for single thread");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "dict server");
  net::counter::HttpCounterExport();

  // init worker thread pool
  reco::dictserver::GlobalDataMgr::instance().Init();

  // start server
  auto transport = new anet::Transport(FLAGS_rpc_thread_num);
  arpc::ANetRPCServer rpcServer(transport, FLAGS_rpc_thread_num, FLAGS_rpc_queue_size * FLAGS_rpc_thread_num);
  rpcServer.StartPrivateTransport();
  transport->start();

  rpcServer.RegisterService(new reco::dictserver::DictImpl);
  std::string spec = "tcp:0.0.0.0:" + base::IntToString(FLAGS_port);
  LOG(INFO) << "listen:" << spec;
  if (!rpcServer.Listen(spec)) {
    LOG(ERROR) << "listen fail:" << spec;
    return -1;
  }
  LOG(INFO) << "start server succ.";

  // data consumer
  reco::dict::DataConsumerIns::instance().Run();
  LOG(INFO) << "data consumer start";

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();

  // close server
  rpcServer.Close();
  rpcServer.StopPrivateTransport();
  LOG(INFO)<< "dict server safe quit";

  // stop worker thread pool
  reco::dictserver::GlobalDataMgr::instance().Stop();
  return 0;
}
