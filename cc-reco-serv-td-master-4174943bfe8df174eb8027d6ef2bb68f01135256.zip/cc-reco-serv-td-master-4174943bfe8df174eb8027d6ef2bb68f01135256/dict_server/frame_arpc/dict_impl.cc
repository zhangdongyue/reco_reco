#include "reco/serv/dict_server/frame_arpc/dict_impl.h"

#include <string>

#include "base/common/base.h"
#include "base/common/closure.h"
#include "base/common/counters.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"

#include "serving_base/utility/timer.h"
#include "reco/serv/dict_server/frame_arpc/global_manager.h"
#include "reco/serv/dict_server/handler/global_data.h"
#include "reco/serv/dict_server/handler/dict_mgmt.h"

using namespace reco::dict;

namespace reco {
namespace dictserver {
DEFINE_int32(max_block_time, 200, "timeout per req block waiting, ms");

DEFINE_int64_counter(dict, get_data_total, 0, "");
DEFINE_double_counter(dict, get_data_cost, 0.0, "");
DEFINE_double_counter(dict, get_data_max_cost, 0.0, "");
DEFINE_int64_counter(dict, set_data_total, 0, "");
DEFINE_double_counter(dict, set_data_cost, 0.0, "");
DEFINE_double_counter(dict, set_data_max_cost, 0.0, "");
DEFINE_int64_counter(dict, del_key_total, 0, "");
DEFINE_double_counter(dict, del_key_cost, 0.0, "");
DEFINE_double_counter(dict, del_key_max_cost, 0.0, "");
DEFINE_int64_counter(dict, server_overload_req_total, 0, "");

DictImpl::DictImpl() 
    : is_run_(true), get_data_max_cost_(0.0), set_data_max_cost_(0.0), del_key_max_cost_(0.0) {
    if (reco::dictserver::GlobalDataMgr::instance().work_thread_pool) {
        const int thread_num = reco::dictserver::GlobalDataMgr::instance().work_thread_pool->thread_num();
        for (auto i = 0; i < thread_num; ++i) {
            GlobalDataMgr::instance().work_thread_pool->AddTask( ::NewCallback(this, &DictImpl::Process, i));
        }
    } else {
        LOG(FATAL) << "thread pool is empty.";
    }
}

DictImpl::~DictImpl() {
    is_run_ = false;
}

void DictImpl::getData(::google::protobuf::RpcController* controller,
                       const ::reco::dict::GetDataRequest* request,
                       ::reco::dict::GetDataResponse* response,
                       ::google::protobuf::Closure* done) {
    request_queue_.Put(StWorkParam(controller, request, response, done, 
                                   base::GetTimestamp(), kGetData));
}

void DictImpl::GetData(StWorkParam param, std::string* details) {
    const ::reco::dict::GetDataRequest* request = 
        static_cast<const ::reco::dict::GetDataRequest*>(param.request);
    ::reco::dict::GetDataResponse* response = 
        static_cast<::reco::dict::GetDataResponse*>(param.response);

    // 首先初始化，默认的出错处理
    response->Clear();
    response->set_success(false);

    // timeout
    if (base::GetTimestamp() - param.time_stamp > FLAGS_max_block_time * 1000) {
        LOG(ERROR) << "server overload, do not process req.";
        COUNTERS_dict__server_overload_req_total.Increase(1);
        return;
    }

    // timer
    serving_base::Timer timer;
    timer.Start();

    // 成功返回
    bool use_cache = true;
    if (request->has_use_cache() && request->use_cache() == false) use_cache = false;

    const std::string key = DictMgmt::GenRealKey(request->key_elements());
    DictMgmt* dict_mgmt = param.dict_mgmt;
    if (dict_mgmt && dict_mgmt->GetData(use_cache, key, response->mutable_value())) {
        response->set_success(true);
    }

    const double total_time = timer.Stop();
    LOG(INFO) << "ret:" << response->success()
        << ", cache:" << use_cache
        << ", key:" << key
        << ", len:" << response->value().size()
        << ", cost:" << total_time;

    COUNTERS_dict__get_data_cost.Increase(total_time);
    if (total_time > get_data_max_cost_) {
        get_data_max_cost_ = total_time;
        COUNTERS_dict__get_data_max_cost.Reset(total_time);
    }
    COUNTERS_dict__get_data_total.Increase(1);
}

void DictImpl::setData(::google::protobuf::RpcController* controller,
                       const ::reco::dict::SetDataRequest* request,
                       ::reco::dict::SetDataResponse* response,
                       ::google::protobuf::Closure* done) {
    request_queue_.Put(StWorkParam(controller, request, response, done, 
                                   base::GetTimestamp(), kSetData));
}

void DictImpl::SetData(StWorkParam param, std::string* details) {
    const ::reco::dict::SetDataRequest* request = 
        static_cast<const ::reco::dict::SetDataRequest*>(param.request);
    ::reco::dict::SetDataResponse* response = 
        static_cast<::reco::dict::SetDataResponse*>(param.response);

    // 首先初始化，默认的出错处理
    response->Clear();
    response->set_success(false);

    // timeout
    if (base::GetTimestamp() - param.time_stamp > FLAGS_max_block_time * 1000) {
        LOG(ERROR) << "server overload, do not process req.";
        COUNTERS_dict__server_overload_req_total.Increase(1);
        return;
    }

    // timer
    serving_base::Timer timer;
    timer.Start();

    // 成功返回
    const std::string key = DictMgmt::GenRealKey(request->key_elements());
    DictMgmt* dict_mgmt = param.dict_mgmt;
    if (dict_mgmt && dict_mgmt->SetData(key, request->value())) {
        response->set_success(true);
    }

    const double total_time = timer.Stop();
    LOG(INFO) << "ret:" << response->success()
        << ", key:" << key
        << ", len:" << request->value().size()
        << ", cost:" << total_time;

    COUNTERS_dict__set_data_cost.Increase(total_time);
    if (total_time > set_data_max_cost_) {
        set_data_max_cost_ = total_time;
        COUNTERS_dict__set_data_max_cost.Reset(total_time);
    }
    COUNTERS_dict__set_data_total.Increase(1);
}

void DictImpl::delKey(::google::protobuf::RpcController* controller,
                      const ::reco::dict::DelKeyRequest* request,
                      ::reco::dict::DelKeyResponse* response,
                      ::google::protobuf::Closure* done) {
    request_queue_.Put(StWorkParam(controller, request, response, done, 
                                   base::GetTimestamp(), kDelKey));
}

void DictImpl::DelKey(StWorkParam param, std::string* details) {
    const ::reco::dict::DelKeyRequest* request = 
        static_cast<const ::reco::dict::DelKeyRequest*>(param.request);
    ::reco::dict::DelKeyResponse* response = 
        static_cast<::reco::dict::DelKeyResponse*>(param.response);

    // 首先初始化，默认的出错处理
    response->Clear();
    response->set_success(false);

    // timeout
    if (base::GetTimestamp() - param.time_stamp > FLAGS_max_block_time * 1000) {
        LOG(ERROR) << "server overload, do not process req.";
        COUNTERS_dict__server_overload_req_total.Increase(1);
        return;
    }

    // timer
    serving_base::Timer timer;
    timer.Start();

    // 成功返回
    const std::string key = DictMgmt::GenRealKey(request->key_elements());
    DictMgmt* dict_mgmt = param.dict_mgmt;
    if (dict_mgmt && dict_mgmt->DelKey(key)) {
        response->set_success(true);
    }

    const double total_time = timer.Stop();
    LOG(INFO) << "ret:" << response->success()
        << ", key:" << key
        << ", cost:" << total_time;

    COUNTERS_dict__del_key_cost.Increase(total_time);
    if (total_time > del_key_max_cost_) {
        del_key_max_cost_ = total_time;
        COUNTERS_dict__del_key_max_cost.Reset(total_time);
    }
    COUNTERS_dict__del_key_total.Increase(1);
}

void DictImpl::Process(const int thread_idx) {
    LOG(INFO) << "thread pool idx open:" << thread_idx;
    reco::dict::DictMgmt* dict_mgmt = new reco::dict::DictMgmt;
    CHECK_NOTNULL(dict_mgmt);
    
    StWorkParam param;
    std::string details;
    while (is_run_) {
        param.Clear();
        if (request_queue_.TryTake(&param) != 1) {
          base::SleepForMilliseconds(20);
          continue;
        }
        param.dict_mgmt = dict_mgmt;
        details.clear();
        switch (param.type) {
            case kGetData:
                GetData(param, &details);
                break;
            case kSetData:
                SetData(param, &details);
                break;
            case kDelKey:
                DelKey(param, &details);
                break;
            default:
                LOG(ERROR) << "process req type fail, type:" << param.type;
                break;
        }
        param.done->Run();
    }
    
    if (dict_mgmt) {
        delete dict_mgmt;
        dict_mgmt = NULL;
    }
    LOG(INFO) << "thread pool idx close:" << thread_idx;
    return;
}

}  // namespace dictserver
}  // namespace reco
