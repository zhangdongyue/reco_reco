#include <string>
#include <iostream>
#include "nlp/synonym/synonym.h"
#include "nlp/synonym/synonym_term.h"
#include "nlp/segment/segmenter.h"
#include "nlp/common/nlp_util.h"
#include "base/common/base.h"

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "syn_demo");
  nlp::segment::Segmenter segmenter;
  nlp::term::TermContainer wordsfsafsa;

  nlp::synonym::Synonym synonym;
  std::vector<nlp::synonym::SynonymResult> results;

  std::string line;
  while (std::getline(std::cin, line)) {
    nlp::util::NormalizeLineInPlaceS(&line);
    if (line.empty()) continue;
    if (!segmenter.SegmentT(line, &words)) {
      LOG(ERROR) << "Failed to segment: " << line;
      continue;
    }
    if (!synonym.GetSynonyms(line, words.basic_terms(), &results)) {
      LOG(ERROR) << "Failed to detect synonyms: " << line;
      continue;
    }

    const std::vector<nlp::term::TermInfo>& basic_terms = words.basic_terms();
    for (uint32 i = 0; i < results.size(); ++i) {
      const nlp::synonym::SynonymResult& synonym_result = results[i];
      std::cout << line << " the original word: " <<
          basic_terms[synonym_result.id].term(line).as_string() << std::endl;
      for (uint32 j = 0; j < synonym_result.terms.size(); ++j) {
        std::cout << synonym_result.terms[j].word << " "
                 << synonym_result.terms[j].score << "\n";
      }
      std::cout << std::endl;
    }
  }
  return 0;
}

