#include "reco/serv/nlp_server/nlp_service_common.h"
#include <iostream>
#include <string>
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/common/gflags.h"

namespace reco {
namespace nlpserver {
DEFINE_int32(samples_nlp_requests, 300, "concurrent request to server");
DEFINE_string(samples_nlp_ip, "127.0.0.1", "The ip address of the RPC server");
DEFINE_int32(samples_nlp_port, 2012, "The port number of the RPC server");
// DEFINE_string(samples_nlp_file_in, "/dev/stdin", "Input file, each line is a text for NLP process");
// DEFINE_string(samples_nlp_file_out, "/dev/stdout",
//               "Output file, the first line is requested text, the followings are segment results, "
//               "postag results, named entity results");

DEFINE_int32(samples_nlp_request_type, NLPRequest::kSegment,
             base::StringPrintf("nlp request type. %d for just segment; %d for segment and postag;"
                                "%d for segment, postag and named entity recognization",
                                NLPRequest::kSegment, NLPRequest::kSegmentPostag,
                                NLPRequest::kSegmentPostagEntity).c_str());

bool InputRequest(NLPRequest* request) {
  // static std::istream ifs(FLAGS_samples_nlp_file_in.c_str());
  request->set_request_type(static_cast<NLPRequest::RequestType>(FLAGS_samples_nlp_request_type));
  request->set_do_normalize(true);
  std::string* line = request->mutable_raw_text();
  *line = "";
  if (std::getline(std::cin, *line)) {
    base::TrimTrailingWhitespaces(line);
    return true;
  } else {
    return false;
  }
}

void OutputResponse(const NLPResponse& response) {
  // static std::ostream std::cout(FLAGS_samples_nlp_file_out);
  std::cout << response.raw_text() << std::endl;

  if (response.segments_size() > 0) {
    for (int i = 0; i < (int)response.segments_size(); ++i) {
      std::cout << response.segments(i) << "\t";
    }
    std::cout << std::endl;
  } else {
    std::cout << "None segments" << std::endl;
  }

  if (response.postags_size() > 0) {
    for (int i = 0; i < (int)response.postags_size(); ++i) {
      std::cout << response.postags(i) << "\t";
    }
    std::cout << std::endl;
  } else {
    std::cout << "None postags" << std::endl;
  }

  if (response.entities_size() > 0) {
    for (int i = 0; i < (int)response.entities_size(); ++i) {
      std::cout << response.entities(i).entity() << ":" << response.entities(i).type() << "\t";
    }
    std::cout << std::endl;
  } else {
    std::cout << "None entities" << std::endl;
  }

}
} // namespace
} // namespace
