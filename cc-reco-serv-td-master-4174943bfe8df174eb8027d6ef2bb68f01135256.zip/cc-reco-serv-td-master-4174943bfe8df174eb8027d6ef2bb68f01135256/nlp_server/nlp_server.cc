#include "reco/serv/nlp_server/nlp_service_impl.h"
#include "reco/base/dict_manager/reload_service_impl.h"
#include <string>
#include <utility>
#include <list>
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/gflags_completions.h"
#include "net/rpc/rpc.h"
#include "net/counter/export.h"
#include "serving_base/utility/signal.h"

DEFINE_int32(port, 20008, "The tcp port this RPC server listens to");
DEFINE_int32(thread_num, 40, "thread num");
DEFINE_int32(reload_port, 30008, "");
DEFINE_int32(reload_thread_num, 2, "reload thread num");


int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "Segment RPC server.");
  net::counter::HttpCounterExport();

  reco::nlpserver::NLPServiceImpl service;
  net::rpc::RpcServer::Options opt;
  opt.port = FLAGS_port;
  opt.server_thread_num = FLAGS_thread_num;
  net::rpc::RpcServer rpc_server(opt);
  CHECK(rpc_server.ExportService(&service));

  reco::dm::ReloadServiceImpl reload_service;
  net::rpc::RpcServer::Options rl_opt;
  rl_opt.port = FLAGS_reload_port;
  rl_opt.server_thread_num = FLAGS_reload_thread_num;
  net::rpc::RpcServer reload_server(rl_opt);
  CHECK(reload_server.ExportService(&reload_service));

  rpc_server.Start();
  reload_server.Start();
  LOG(INFO) << "nlp server started";
  ::google::FlushLogFiles(::google::INFO);

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();
}

