#include <math.h>
#include <algorithm>
#include <map>
#include <set>
#include <stack>
#include <unordered_set>
#include <utility>

#include "reco/serv/nlp_server/parser/structured_query_parser.h"
#include "query/tree/query_tree.h"

#include "nlp/common/nlp_util.h"
#include "nlp/common/rune_type.h"
#include "nlp/segment/segmenter.h"

#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_util.h"

namespace reco {
namespace nlpserver {

// 清理挂载在树上的数据. query 分析子模块不必调用, 统一由 QueryParser 调用
// 抽象词词表如有扩展,再讨论如何放置
StructuredQueryParser::StructuredQueryParser() {
  term_container_ = new nlp::term::TermContainer;
  segmenter_ = new nlp::segment::Segmenter;
}

StructuredQueryParser::~StructuredQueryParser() {
  delete term_container_;
  delete segmenter_;
}

bool StructuredQueryParser::ParseQuery(const std::vector<std::string>& and_phrases,
                             const std::vector<std::string>& or_phrases,
                             const std::vector<std::string>& not_phrases,
                             queries::QueryTree* include_tree,
                             queries::QueryTree* exclude_tree) {
  using namespace queries;
  // NOTE: 每 new 一个 node，就挂到树上，这样出错返回到时候，new 的内存能在树销毁时一并销毁
  include_tree->clear();
  exclude_tree->clear();

  QueryTreeNode* and_root = NULL;
  QueryTreeNode* or_root = NULL;
  QueryTreeNode* not_root = NULL;

  if (!and_phrases.empty()) {
    and_root = new QueryTreeNode(QueryTreeNode::kAnd);
  }

  if (!or_phrases.empty()) {
    or_root = new QueryTreeNode(QueryTreeNode::kOr);
  }

  if (!not_phrases.empty()) {
    not_root = new QueryTreeNode(QueryTreeNode::kOr);
  }

  QueryTreeNode* include_tree_root = NULL;
  if (and_root != NULL && or_root != NULL) {
    // tree structure:
    //         and
    // or -> phrase -> phrase
    BecomeLastChildOf(or_root, and_root);
    include_tree->set_root(and_root);
    include_tree_root = and_root;
  } else if (and_root == NULL && or_root != NULL) {
    // tree structure:
    //         or
    // phrase -> phrase
    include_tree->set_root(or_root);
    include_tree_root = or_root;
  } else if (and_root != NULL && or_root == NULL) {
    // tree structure:
    //        and 
    // phrase -> phrase
    include_tree->set_root(and_root);
    include_tree_root = and_root;
  }

  QueryTreeNode* exclude_tree_root= NULL;
  if (not_root != NULL) {
    // 要求以 And 为根
    QueryTreeNode* root = new QueryTreeNode(QueryTreeNode::kAnd);
    BecomeLastChildOf(not_root, root);
    exclude_tree->set_root(root);
    exclude_tree_root = root;
  }

  int total_node = 0;
  for (int i = 0; i < (int)and_phrases.size(); ++i) {
    if (!ConstructPhraseTree(and_phrases[i], term_container_, &total_node, and_root)) {
      return false;
    }
  }

  for (int i = 0; i < (int)or_phrases.size(); ++i) {
    if (!ConstructPhraseTree(or_phrases[i], term_container_, &total_node, or_root)) {
      return false;
    }
  }

  for (int i = 0; i < (int)not_phrases.size(); ++i) {
    if (!ConstructPhraseTree(not_phrases[i], term_container_, &total_node, not_root)) {
      return false;
    }
  }

  if (include_tree_root) {
    CompressTree(include_tree);
    CollapsePhrase(include_tree_root);
  }

  if (exclude_tree_root) {
    CompressTree(exclude_tree);
    CollapsePhrase(exclude_tree_root);
  }

  return true;
}

void StructuredQueryParser::CollapsePhrase(queries::QueryTreeNode* root) {
  std::vector<const queries::QueryTreeNode*> node_list;
  PostOrderTraverse(root, &node_list);
  for (int i = 0; i < (int)node_list.size(); ++i) {
    queries::QueryTreeNode* node = const_cast<queries::QueryTreeNode*>(node_list[i]);
    if (node->type() == queries::QueryTreeNode::kPhrase
        && node->first_child() == node->last_child()) {  // phrase 下只有一个 儿子
      DeleteNode(&node);
    }
  }
}

queries::QueryTreeNode* StructuredQueryParser::NewLeafNode(base::Slice literal) {
  queries::QueryTreeNode* node = new queries::QueryTreeNode(queries::QueryTreeNode::kLeaf);
  if (!node->set_literal(literal)) {
    delete node;
    return NULL;
  }
  return node;
}

void StructuredQueryParser::CompressTree(queries::QueryTree* tree) {
  queries::QueryTreeNode* root = const_cast<queries::QueryTreeNode*>(tree->root());
  std::vector<const queries::QueryTreeNode*> node_list;
  PostOrderTraverse(root, &node_list);
  for (int i = 0; i < (int)node_list.size(); ++i) {
    queries::QueryTreeNode* node = const_cast<queries::QueryTreeNode*>(node_list[i]);
    if (node == root) continue;
    // 删除空 Operator 节点
    if (node->type() != queries::QueryTreeNode::kLeaf
        && node->first_child() == NULL) {
      // 不删除根节点
      if (node->parent()) {
        DeleteNode(&node);
        continue;
      }
    }

    // Or 下只有一个儿子，删除 Or 节点
    if (node->type() == queries::QueryTreeNode::kOr
        && node->first_child() != NULL && node->first_child() == node->last_child()) {
      // 不删除根节点
      if (node->parent()) {
        DeleteNode(&node);
        continue;
      }
    }

    // 删除 Phrase 下面嵌套 Phrase 或 And 节点的情况
    if ((node->type() == queries::QueryTreeNode::kPhrase || node->type() == queries::QueryTreeNode::kAnd)
        && (node->parent() != NULL && node->parent()->type() == queries::QueryTreeNode::kPhrase)) {
      // 不删除根节点
      if (node->parent()) {
        DeleteNode(&node);
        continue;
      }
    }


  }
}

bool StructuredQueryParser::ConstructPhraseTree(const base::Slice& phrase,
                                                nlp::term::TermContainer* term_container,
                                                int* total_node, queries::QueryTreeNode* root) {
  using namespace queries;
  term_container->renew();
  if (!segmenter_->SegmentT(phrase, term_container)) {
    LOG(ERROR) << "segment failed: " << phrase.as_string();
    return false;
  }

  QueryTreeNode* phrase_root = new QueryTreeNode(QueryTreeNode::kPhrase);
  BecomeLastChildOf(phrase_root, root);

  const std::vector<nlp::term::TermInfo>& basic_terms = term_container->basic_terms();

  for (int i = 0; i < (int)basic_terms.size(); ++i) {
    ++(*total_node);
    if (*total_node > kQueryMaxTermNum) {
      LOG(ERROR) << "total term num exceeds " << kQueryMaxTermNum;
      return false;
    }
    const nlp::term::TermInfo& term_info = basic_terms[i];
    // 正常的节点, 都需要能够正确设置 literal 且不为空, 否则不添加该节点
    QueryTreeNode* node = NewLeafNode(term_info.term(phrase));
    if (NULL == node) {
      // : 空格 ( ) 是保留字符, 不建立叶子节点, 需要特殊处理.
      // 这里构造一个节点, 但节点的 literal 为空
      // 在 Prune 逻辑中统一将这些节点删除
      LOG(ERROR) << "phrase contains reserved runes: " << phrase.as_string();
      return false;
    } else {
      BecomeLastChildOf(node, phrase_root);
    }
  }
  return true;
}

void StructuredQueryParser::PostOrderTraverse(const queries::QueryTreeNode* subroot,
                                              std::vector<const queries::QueryTreeNode*>* node_list) {
  CHECK_NOTNULL(node_list);
  if (subroot == NULL) {
    return;
  }
  for (const queries::QueryTreeNode* child = subroot->first_child();
       child != NULL; child = child->next_sibling()) {
    PostOrderTraverse(child, node_list);
  }
  node_list->push_back(subroot);
}

}  // namespace nlpserver
}  // namespace reco

