#pragma once

#include <string>
#include <vector>

#include "query/parser_util/parser_define.h"
#include "serving_base/http_communicator/http_communicator.h"
#include "base/common/slice.h"
#include "base/common/basic_types.h"
#include "base/common/gflags.h"
#include "base/hash_function/city.h"

namespace reco {
namespace nlpserver {

class QPParser{
public:
  QPParser();
  ~QPParser();
  
  bool QPParse(const std::string& query, queries::QpResult *qp_result);
  bool ParseRawQPResult(const std::string& json_string, queries::QpResult* qp_result);
  const std::vector<std::string>& GetRankPhrases() const;
  const std::string& GeRawQPResult() const;

private:
  int ParseRankPhrase(const std::string &str);
  int ParseSyncQuery(const std::string &str, std::vector<queries::SynQueryInfo> *sync_result,
                             std::string *normal_query);
  
  std::vector<std::string> qp_host_;
  serving_base::HttpCommunicator *qp_communicator_;
  std::vector<std::string> rank_phrases_;
  std::string raw_qp_result_;
};

}  // namespace
}  // namespace
