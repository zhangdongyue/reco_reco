#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <utility>

#include "query/tree/query_tree_node.h"
#include "query/tree/tree_util.h"
#include "query/tree/query_tree.h"

#include "base/common/slice.h"
#include "base/common/basic_types.h"
#include "base/common/gflags.h"

namespace nlp {
namespace term {
class TermContainer;
}

namespace segment {
class Segmenter;
}
}

namespace reco {
namespace nlpserver {

class StructuredQueryParser {
 public:
  StructuredQueryParser();
  ~StructuredQueryParser();

  // query 分析入口.
  // 对 and  or  not 语法给予解析
  // 内部只做切词
  // 对于 and 词，每个词是一个 phrase，多个词用 and 连接
  // 对于 or 词， 增加一个 or 节点，挂载多个 or term， 外部再用 and term 连接
  // 对于 not 词，类似 or, 词构造一个树 and -> or ->
  // NOTE: 词不能包含以下字符 :()空格
  bool ParseQuery(const std::vector<std::string>& and_phrases,
                  const std::vector<std::string>& or_phrases,
                  const std::vector<std::string>& not_phrases,
                  queries::QueryTree* include_tree,
                  queries::QueryTree* exclude_tree) WARN_UNUSED_RESULT;

 private:
  static const int kQueryMaxTermNum = 100;

  // 基本建树, 生成 And,Phrase 和叶子节点
  bool ConstructPhraseTree(const base::Slice& phrase,
                           nlp::term::TermContainer* term_container,
                           int* total_node, queries::QueryTreeNode* root) WARN_UNUSED_RESULT;
  // 解开嵌套的 Phrase, 删除空 Operator 节点
  // 
  void CompressTree(queries::QueryTree* tree);
  // 按照应用方要求, 对树进行一些修剪. 当前的处理是去除单 term 的 phrase 节点
  void CollapsePhrase(queries::QueryTreeNode* root);

  /////////////////////////// 树相关操作 /////////////////////////////////
  // 给定 basic term idx 建立相应叶子节点，并设置节点字面和属性值。 会对 term
  // 字面按照 QueryTree 的字面规则进行过滤，去除 QueryTree 保留的字符
  // 如果过滤后的字面为空，则返或 NULL, 否则返回新建节点的指针
  static queries::QueryTreeNode* NewLeafNode(base::Slice literal) WARN_UNUSED_RESULT;
  void PostOrderTraverse(const queries::QueryTreeNode* subroot,
                         std::vector<const queries::QueryTreeNode*>* node_list);
 private:
  // nlp 相关模块
  nlp::term::TermContainer* term_container_;
  nlp::segment::Segmenter* segmenter_;
};
}  // namespace
}  // namespace
