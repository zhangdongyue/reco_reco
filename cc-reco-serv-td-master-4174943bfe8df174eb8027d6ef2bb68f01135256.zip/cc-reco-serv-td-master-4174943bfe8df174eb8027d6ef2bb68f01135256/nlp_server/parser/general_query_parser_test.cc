#include "reco/serv/nlp_server/parser/general_query_parser.h"

#include <vector>
#include <string>
#include <utility>
#include <set>

#include "query/parser_util/parser_util.h"
#include "query/tree/query_tree.h"
#include "query/tree/tree_util.h"
#include "base/testing/gtest.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/random/pseudo_random.h"

namespace reco {
namespace nlpserver {

TEST(GeneralQueryParser, Parse) {
  static struct {
    const char* query;
    const char* tree;
  } cases[] = {
    {"ipad", "(AND ipad :o :imp=1 :rws=1)"},
    {"1a\t2b", "(AND 1 :o :imp=0.216431 :rws=1 a :o :imp=0.27066 :rws=1 2 :o :imp=0.200034 :rws=1 b :o :imp=0.312875 :rws=1)"},
  };

  GeneralQueryParser parser;
  std::vector<std::string> queries;
  queries::QueryTree tree;
  for (int i = 0; i < (int)ARRAYSIZE_UNSAFE(cases); ++i) {
    ASSERT_TRUE(parser.ParseQuery(cases[i].query, &tree));

    std::string dump;
    dump.clear();
    tree.ToString(&dump);
    ASSERT_STREQ(cases[i].tree, dump.c_str());
  }
}

static std::string getword() {
  static const char* list = "0123456789abcdefghik";
  static base::PseudoRandom random;
  std::string word;
  while (word.size() < 10) {
    int j = random.GetInt(0, 20);
    if (j < 10) {
      word.push_back(list[j]);
    }
  }
  return word;
}

TEST(GeneralQueryParser, Press) {
  GeneralQueryParser parser;
  queries::QueryTree tree;

  int loop = 10000;
  for (int i = 0; i < loop; ++i) {
    ASSERT_TRUE(parser.ParseQuery(getword(), &tree));
  }
}
}  // namespace
}  // namespace

