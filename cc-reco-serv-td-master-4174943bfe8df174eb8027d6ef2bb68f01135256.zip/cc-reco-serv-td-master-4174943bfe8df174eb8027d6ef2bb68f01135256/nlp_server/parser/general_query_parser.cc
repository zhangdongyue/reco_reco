#include "reco/serv/nlp_server/parser/general_query_parser.h"

#include <math.h>
#include <algorithm>
#include <map>
#include <set>
#include <stack>
#include <unordered_set>
#include <utility>

#include "query/tree/query_tree.h"
#include "query/parser2/query_parser.h"

#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_util.h"

namespace reco {
namespace nlpserver {

// 清理挂载在树上的数据. query 分析子模块不必调用, 统一由 QueryParser 调用
// 抽象词词表如有扩展,再讨论如何放置
GeneralQueryParser::GeneralQueryParser() {
  query_dicts_ = new queries::QueryDicts();
  query_dicts_->LoadAllDicts();

  query_parser_ = new queries::QueryParser();
  query_parser_->SetDicts(query_dicts_);

  query_config_ = new queries::QueryParserConfig();
  query_config_->Initialize();
  query_config_->do_importance = true;
  query_config_->do_subs = true;
  query_config_->do_omit = true;
  query_config_->do_plsa = false;
  query_config_->do_intent = false;
  query_config_->do_expand = false;
  query_config_->do_correct = false;
  query_config_->use_qp = false;
}

GeneralQueryParser::~GeneralQueryParser() {
  delete query_parser_;
  delete query_dicts_;
  delete query_config_;
}

bool GeneralQueryParser::ParseQuery(const std::string& query, queries::QueryTree* tree) {
  if (!query_parser_->ParseQuery(query, *query_config_, tree)) {
    LOG(ERROR) << "failed to parse query: " << query;
    return false;
  } else {
    return true;
  }
}

bool GeneralQueryParser::ParseQuery(const std::string& query, const queries::QpResult* qp_result,
                                    queries::QueryTree* tree) {
  if (!query_parser_->ParseQuery(query, qp_result, *query_config_, tree)) {
    LOG(ERROR) << "failed to parse query: " << query;
    return false;
  } else {
    return true;
  }
}

void GeneralQueryParser::SetUseQp() {
  query_config_->use_qp = true;
  query_config_->do_correct = true;
}

}  // namespace nlpserver
}  // namespace reco

