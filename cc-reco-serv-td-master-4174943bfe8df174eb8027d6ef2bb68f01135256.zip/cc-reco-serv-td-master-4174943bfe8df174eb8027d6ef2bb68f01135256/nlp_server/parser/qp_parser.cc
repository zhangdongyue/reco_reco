#include "reco/serv/nlp_server/parser/qp_parser.h"

#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_util.h"
#include "base/strings/internal/string_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/blocking_var.h"
#include "extend/json/jansson/jansson.h"

#define SUCC 1
#define FAILD 0

namespace nlp {
namespace util {
void NormalizeLineInPlaceS(std::string* in_out_string);
}
}

enum {
  EN_RW_LEVEL_1 = 1,
  EN_RW_LEVEL_4 = 4,
  EN_RW_LEVEL_7 = 7,
  EN_RW_LEVEL_9 = 9,
};

DEFINE_string(qp_host, "", "QP server's IPs, splited by ;");
DEFINE_int32(qp_port, 0, "QP servers' port");
DEFINE_int32(qp_retry_times, 2, "");
DEFINE_int32(qp_connect_timeout_in_ms, 2000, "");
DEFINE_int32(qp_transfer_timeout_in_ms, 2000, "");
DEFINE_int32(communicator_client_num, 1, "");
DEFINE_int32(communicator_thread_num, 1, "");

static const std::string g_qp_url_suffix = "uip=127.0.0.1&q=cluster%3Dfastindex%2Cgalaxy%26%26"
  "config%3DnavigationalQuery%3Aon%2Cfiltermode%3A11%2Cstart%3A0%2Chit%3A10%2Csearcher_return_hits%3A10%2C"
  "kvpairs%3Aip%2358.58.75.70%3Bst%23wap%3Btl%2354%3Bsl%23100%3Bfr%23other%26%26distinct%3Ddist_key%3A"
  "V_HOST_HASH%2Cdist_count%3A5%3Bdist_key%3AV_HOST_HASH%2Cdist_count%3A2%26%26query%3D"
  "phrase%3A%27%E7%88%B1%E4%BA%BA%27&t=xishuashua_nlp_server&fi=0&v=rerank";

static const std::string g_qp_result_json_key = "HA2xishuashua_nlp_server";

namespace reco {
namespace nlpserver {
 
void UrlComplete(thread::BlockingVar<bool> *url_complete) {
  url_complete->TryPut(true);
}

QPParser::QPParser() {
  if (FLAGS_qp_host == "") return;

  base::SplitString(FLAGS_qp_host, ";", &qp_host_);

  serving_base::HttpCommunicator::Config qp_config;
  qp_config.retry_times = FLAGS_qp_retry_times;
  qp_config.connect_timeout_in_ms = FLAGS_qp_connect_timeout_in_ms;
  qp_config.transfer_timeout_in_ms = FLAGS_qp_transfer_timeout_in_ms;
  qp_config.client_num = FLAGS_communicator_client_num;
  qp_config.thread_num = FLAGS_communicator_thread_num;
  qp_communicator_ = new serving_base::HttpCommunicator(qp_config);
  CHECK(qp_communicator_ != NULL);
}

QPParser::~QPParser() {
  if (qp_communicator_) delete qp_communicator_;
}

const std::vector<std::string>& QPParser::GetRankPhrases() const {
  return rank_phrases_;
}

const std::string& QPParser::GeRawQPResult() const {
  return raw_qp_result_;
}

int QPParser::ParseRankPhrase(const std::string &str) {
  rank_phrases_.clear();
  std::string query_phrase = "query=";
  std::string::size_type start = str.find(query_phrase.c_str());
  if (start == std::string::npos) {
    return 0;
  }
  std::string::size_type end = str.find(";", start);
  if (end == std::string::npos) {
    end = str.find(",", start);
  }
  if (end == std::string::npos) {
    end = str.find("\"", start);
  }
  if (end == std::string::npos) {
    end = str.length();
  }
  std::string content = str.substr(start + 6, end - start - 6);
  // get all phrases
  start = 0;
  std::string::size_type end_pos = content.find("RANK phrase:\'", start);
  if (end_pos == std::string::npos) {
    return 0;
  }
  std::vector<std::string> all_phrases;
  while ((start = content.find("phrase:\'", start)) != std::string::npos) {
    if (start > end_pos) {
      break;
    }
    end = content.find("\'", start + 8);
    if ((end == std::string::npos) || (end > end_pos)) {
      break;
    }
    all_phrases.push_back(content.substr(start + 8, end - start - 8));
    start = end + 1;
  }
  // extract all RANK phrases
  start = 0;
  while ((start = content.find("RANK phrase:\'", start)) != std::string::npos) {
    end = content.find("\'", start + 13);
    if ((end == std::string::npos) || (end > content.length())) {
      break;
    }
    std::string phrase = content.substr(start + 13, end - start -13);
    bool duplicated = false;
    for (size_t i = 0; i < all_phrases.size(); i++) {
      if (all_phrases[i] == phrase) {
        duplicated = true;
        break;
      }
    }
    if (!duplicated) {
      rank_phrases_.push_back(phrase);
    }
    start = end + 1;
  }
  return rank_phrases_.size();
}

int QPParser::ParseSyncQuery(const std::string &str, std::vector<queries::SynQueryInfo> *sync_result,
                                 std::string *normal_query) {
  if (NULL == sync_result || NULL == normal_query) {
    return FAILD;
  }
  std::vector<std::string> tokens;
  base::SplitStringWithOptions(str, ";", true, true, &tokens);
  std::string query_parten = "scoring_query#";
  std::string level_parten = "querysyn_level#";
  std::string normal_parten = "norm_query#";
  std::string group_split = "`0";
  std::string term_split = "`1";

  std::vector<int> level_vec;

  for (uint32 i = 0; i < tokens.size(); i++) {
    std::string::size_type pos = tokens[i].find(query_parten.c_str());
    if (pos != std::string::npos) {
      std::string syn_querys = tokens[i].substr(pos+strlen(query_parten.c_str()));
      // for querys
      std::vector<std::string> group_vec;
      base::SplitStringUsingSubstrWithOptions(syn_querys, group_split, true, true, &group_vec);
      for (uint32 j = 0; j < group_vec.size(); j++) {
        std::vector<std::string> term_vec;
        queries::SynQueryInfo sync_query;
        // for split terms
        base::SplitStringUsingSubstrWithOptions(group_vec[j], term_split, true, true, &term_vec);
        for (uint32 k = 0; k < term_vec.size(); k++) {
          sync_query.scoring_terms.push_back(term_vec[k]);
        }
        // for default value
        sync_query.querysyn_level = 1;
        sync_result->push_back(sync_query);
      }
    } else if ((pos = tokens[i].find(level_parten.c_str())) != std::string::npos) {
      // for query level
      std::vector<std::string> lvl_vec;
      std::string levels = tokens[i].substr(pos+strlen(level_parten.c_str()));
      base::SplitStringUsingSubstrWithOptions(levels, group_split, true, true, &lvl_vec);
      for (uint32 j = 0; j < lvl_vec.size(); j++) {
        int level = atol(lvl_vec[j].c_str());
        level_vec.push_back(level);
      }
    } else if ((pos = tokens[i].find(normal_parten.c_str())) != std::string::npos) {
      *normal_query = tokens[i].substr(pos+strlen(normal_parten.c_str()));
    }
  }

  // for real level
  int num = (sync_result->size() > level_vec.size()) ? level_vec.size() : sync_result->size();
  for (int i = 0; i < num; i++) {
    (*sync_result)[i].querysyn_level = level_vec[i];
  }
  return SUCC;
}

bool QPParser::ParseRawQPResult(const std::string& json_string,
                                        queries::QpResult* qp_result) {
  raw_qp_result_ = json_string;
  
  json_error_t json_error;
  int val = SUCC;
  bool has_rw = false;
  json_t *json_item = json_loads(json_string.c_str(), &json_error);
  if (NULL == json_item) {
    return false;
  }

  if (!json_is_object(json_item)) {
    json_decref(json_item);
    return false;
  }

  json_t *qar = json_object_get(json_item, "qar");
  if (NULL == qar || !json_is_array(qar)) {
    json_decref(json_item);
    return false;
  }
  int qar_size = json_array_size(qar);
  if (qar_size <= 0) {
    json_decref(json_item);
    return false;
  }

  json_t *qar_item = json_array_get(qar, 0);
  if (NULL == qar_item || !json_is_object(qar_item)) {
    json_decref(json_item);
    return false;
  }

  json_t *item0 = json_object_get(qar_item, "search0");
  if (NULL == item0 || !json_is_array(item0)) {
    json_decref(json_item);
    return false;
  }

  int se_array_size = json_array_size(item0);
  if (se_array_size <= 0) {
    json_decref(json_item);
    return false;
  }
  for (int i = 0; i < se_array_size; i++) {
    json_t *se_item = json_array_get(item0, i);
    if (NULL == se_item || !json_is_object(se_item)) {
      continue;
    }

    for (void *it = json_object_iter(se_item); it != NULL; it = json_object_iter_next(se_item, it)) {
      std::string key = json_object_iter_key(it);
      json_t *value = json_object_iter_value(it);

      if (g_qp_result_json_key == key) {
        std::string normal_query;
        val = ParseSyncQuery(json_string_value(value), &qp_result->syn_query_vec, &normal_query);
        if (qp_result->syn_query_vec.size() > 0 && normal_query.size() > 0) {
          for (size_t j = 0; j < qp_result->syn_query_vec.size(); j++) {
            std::string tmp;
            for (size_t k = 0; k < qp_result->syn_query_vec[j].scoring_terms.size(); k++) {
              tmp.append(qp_result->syn_query_vec[j].scoring_terms[k]);
            }
            if (tmp.size() > 0 && normal_query != tmp) {
              qp_result->syn_rw_querys.push_back(tmp);
              qp_result->syn_rw_levels.push_back(EN_RW_LEVEL_9);
              has_rw = true;
            }
          }
        }
        // parse RANK phrase
        val = ParseRankPhrase(json_string_value(value));
      } else if ("rw" == key) {
        qp_result->rw_query = json_string_value(value);
        has_rw = true;
      } else if ("spellcheck" == key) {
        qp_result->rw_query = json_string_value(value);
        has_rw = true;
      } else if ("SpellCheckLevel" == key) {
        int level;
        base::StringToInt(json_string_value(value), &level);
        qp_result->rw_level = level;
      }
    }
  }
  if (!has_rw) {
    json_t *item2 = json_object_get(qar_item, "search2");
    if (item2 != NULL && json_is_array(item2)) {
      json_decref(json_item);
      return true;
    }
    int se_array_size = json_array_size(item2);
    if (se_array_size <= 0) {
      json_decref(json_item);
      return true;
    }
    for (int i = 0; i < se_array_size; i++) {
      json_t *se_item = json_array_get(item2, i);
      if (NULL == se_item || !json_is_object(se_item)) {
        continue;
      }
      for (void *it = json_object_iter(se_item); it != NULL; it = json_object_iter_next(se_item, it)) {
        std::string key = json_object_iter_key(it);
        json_t *value = json_object_iter_value(it);

        if (g_qp_result_json_key == key) {
          std::vector<std::string> tokens;
          base::SplitStringWithOptions(json_string_value(value), ";", true, true, &tokens);
          std::string query_parten = "scoring_query#";
          std::string group_split = "`0";
          std::string term_split = "`1";
          std::string rw_tmp;
          for (uint32 i = 0; i < tokens.size(); i++) {
            std::string::size_type pos = tokens[i].find(query_parten.c_str());
            if (pos != std::string::npos) {
              std::string syn_querys = tokens[i].substr(pos+strlen(query_parten.c_str()));
              // for querys
              std::vector<std::string> group_vec;
              base::SplitStringUsingSubstrWithOptions(syn_querys, group_split, true, true, &group_vec);
              if (group_vec.size() > 0) {
                std::vector<std::string> term_vec;
                queries::SynQueryInfo sync_query;
                // for split terms
                base::SplitStringUsingSubstrWithOptions(group_vec[0], term_split, true, true, &term_vec);
                for (uint32 k = 0; k < term_vec.size(); k++) {
                  rw_tmp.append(term_vec[k]);
                }
              }
              break;
            }
          }
          if (rw_tmp.size() > 0) {
            qp_result->rw_query = rw_tmp;
            qp_result->rw_level = 4;
            has_rw = true;
          }
        }
      }
    }
  }
  json_decref(json_item);

  // Normalize
  nlp::util::NormalizeLineInPlaceS(&qp_result->rw_query);
  for (size_t i = 0; i < qp_result->syn_rw_querys.size(); i++) {
    nlp::util::NormalizeLineInPlaceS(&(qp_result->syn_rw_querys[i]));
  }

  return true;
}

bool QPParser::QPParse(const std::string& query, queries::QpResult* qp_result){
  char qp_url[1024];
  uint64 query_hash = base::CityHash64(query.c_str(), query.size());
  uint32 qp_host_idx = query_hash % qp_host_.size();
  base::snprintf(qp_url, sizeof(qp_url), "%s:%d/qp?p=%s&%s",
                 qp_host_[qp_host_idx].c_str(), FLAGS_qp_port, query.c_str(), g_qp_url_suffix.c_str());
  
  thread::BlockingVar<bool> url_complete;
  std::string qp_response;
  int url_ret_code;
  qp_communicator_->AcquireUrlResult(qp_url, &qp_response, &url_ret_code, 
                                     NewCallback(UrlComplete, &url_complete));
  url_complete.Take();

  if (url_ret_code != 200 || qp_response.size() == 0) {
    LOG(ERROR) << "QP parse failed. " << "ret_code: " << url_ret_code;
    return false;
  }

  if(ParseRawQPResult(qp_response, qp_result) != SUCC) {
    LOG(ERROR) << "QP decode failed. qp_response: " << qp_response;
    return false;
  }

  return true;
}

}  // namespace nlpserver
}  // namespace reco

