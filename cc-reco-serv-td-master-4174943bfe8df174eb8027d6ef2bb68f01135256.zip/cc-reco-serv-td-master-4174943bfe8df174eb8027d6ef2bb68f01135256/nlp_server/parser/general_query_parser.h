#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <utility>

#include "query/tree/query_tree_node.h"
#include "query/tree/tree_util.h"
#include "query/tree/query_tree.h"

#include "base/common/slice.h"
#include "base/common/basic_types.h"
#include "base/common/gflags.h"

namespace queries{
class QueryParser;
class QueryDicts;
class QueryParserConfig;
class QpResult;
}  // namespace queries

namespace reco {
namespace nlpserver {

class GeneralQueryParser {
 public:
  GeneralQueryParser();
  ~GeneralQueryParser();

  // query 分析入口.
  // 对 and  or  not 语法给予解析
  // 内部只做切词
  // 对于 and 词，每个词是一个 phrase，多个词用 and 连接
  // 对于 or 词， 增加一个 or 节点，挂载多个 or term， 外部再用 and term 连接
  // 对于 not 词，类似 or, 词构造一个树 and -> or ->
  // NOTE: 词不能包含以下字符 :()空格
  bool ParseQuery(const std::string& query, const queries::QpResult* qp_result,
                  queries::QueryTree* tree) WARN_UNUSED_RESULT;

  bool ParseQuery(const std::string& query, queries::QueryTree* tree) WARN_UNUSED_RESULT;

  void SetUseQp();

 private:
  // query 相关模块
  queries::QueryParser* query_parser_;
  queries::QueryDicts *query_dicts_;
  queries::QueryParserConfig* query_config_;
};
}  // namespace
}  // namespace
