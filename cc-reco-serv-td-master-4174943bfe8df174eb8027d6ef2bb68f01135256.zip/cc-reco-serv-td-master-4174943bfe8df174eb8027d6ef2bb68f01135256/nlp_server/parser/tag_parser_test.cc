#include "reco/serv/nlp_server/parser/tag_parser.h"

#include <vector>
#include <string>
#include <utility>
#include <set>

#include "query/parser_util/parser_util.h"
#include "query/tree/query_tree.h"
#include "query/tree/tree_util.h"
#include "base/testing/gtest.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/random/pseudo_random.h"
#include "reco/base/dict_manager/dict_manager.h"

namespace reco {
namespace nlpserver {

TEST(TagParser, Parse) {
  reco::dm::FLAGS_dict_manager_root_dir = "/tmp";
  system("echo '金正男\t金正男遇刺' > /tmp/news_tag.txt");
  system("echo '金正恩哥哥\t金正男遇刺' >> /tmp/news_tag.txt");
  system("echo '金正南' > /tmp/tag.txt");
  system("echo '金正恩' >> /tmp/tag.txt");
  system("echo '金三胖' >> /tmp/tag.txt");
  TagParser* parser = new TagParser();
  
  std::string tag;
  std::vector<std::string> queries;
  
  // 原始query全部命中订阅词表
  queries.clear();
  queries.push_back("金正恩");
  queries.push_back("金三胖视察工厂");
  tag = parser->ParseTag(queries);
  ASSERT_STREQ(tag.c_str(), "金正恩");
  
  // 原始query部分命中订阅词表
  queries.clear();
  queries.push_back("金正恩视察工厂");
  queries.push_back("金三胖视察工厂");
  tag = parser->ParseTag(queries);
  ASSERT_STREQ(tag.c_str(), "金正恩");
  
  // 改写query全部命中订阅词表
  queries.clear();
  queries.push_back("金正恩视察工厂");
  queries.push_back("金三胖");
  tag = parser->ParseTag(queries);
  ASSERT_STREQ(tag.c_str(), "金三胖");
  
  // 原始query无命中，改写query部分命中订阅词表
  queries.clear();
  queries.push_back("不可描述人物视察工厂");
  queries.push_back("金三胖视察工厂");
  tag = parser->ParseTag(queries);
  ASSERT_STREQ(tag.c_str(), "");
  
  // 原始query无命中，改写query部分命中订阅词表
  queries.clear();
  queries.push_back("不可描述人物视察工厂");
  queries.push_back("金三胖视察工厂");
  tag = parser->ParseTag(queries);
  ASSERT_STREQ(tag.c_str(), "");
  
  // 原始query同时命中事件词表和订阅词表
  queries.clear();
  queries.push_back("金正男");
  tag = parser->ParseTag(queries);
  ASSERT_STREQ(tag.c_str(), "金正男遇刺");
}


}  // namespace
}  // namespace

