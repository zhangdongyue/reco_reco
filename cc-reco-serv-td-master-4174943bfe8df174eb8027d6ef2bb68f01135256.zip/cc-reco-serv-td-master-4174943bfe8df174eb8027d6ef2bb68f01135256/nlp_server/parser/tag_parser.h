#pragma once

#include <string>
#include <vector>

#include "extend/static_dict/darts_clone/darts_clone.h"
#include "query/parser_util/parser_define.h"
#include "base/common/slice.h"
#include "base/common/basic_types.h"
#include "base/common/gflags.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "base/file/file_path.h"

namespace reco {

namespace dm {
// tag dict relatived
struct TagDict {
  darts_clone::DoubleArray tag_dict;

  // conversion map
  std::unordered_map<std::string, std::string> cmap;
};

void LoadTagFile(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
void LoadNewsTagFile(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
}  // namespace

namespace nlpserver {

class TagParser{
public:
  TagParser();
  ~TagParser();

  std::string ParseTag(const std::vector<std::string>& rw_queries);

private:
  static const char* kTagFile;
  static const char* kNewsTagFile;
};

}  // namespace
}  // namespace
