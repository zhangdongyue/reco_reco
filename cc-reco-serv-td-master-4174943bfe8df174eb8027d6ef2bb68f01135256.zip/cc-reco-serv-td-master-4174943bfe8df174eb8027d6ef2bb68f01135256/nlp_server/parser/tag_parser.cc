#include "reco/serv/nlp_server/parser/tag_parser.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "nlp/common/nlp_util.h"
#include "query/parser_util/parser_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_util.h"
#include "base/strings/internal/string_util.h"
#include "base/strings/string_number_conversions.h"

namespace reco {

namespace dm {

void LoadNewsTagFile(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }

  auto dict = static_cast<DynamicDict<TagDict>*>(dict_address);
  boost::shared_ptr<TagDict> new_dict(new TagDict());

  new_dict->cmap[""] = "";
  std::set<std::string> queries;
  for (size_t i = 0; i < lines.size(); ++i) {
    std::vector<std::string> cols;
    base::SplitString(lines[i], "\t", &cols);
    if (cols.size() < 2) continue;

    std::string nmlz_li_query;
    queries::NormalizeQueryLight(cols[0], &nmlz_li_query);
    nlp::util::NormalizeLineInPlaceS(&cols[1]);
    queries.insert(nmlz_li_query);
    new_dict->cmap[nmlz_li_query] = cols[1];
  }
  LOG(INFO) << "total " << queries.size() << " tags loaded";

  std::vector<const char*> keys;
  for (auto it = queries.begin(); it != queries.end(); ++it) {
    keys.push_back(it->c_str());
  }
  if (new_dict->tag_dict.build(keys.size(), &(keys[0]), NULL, NULL, NULL) != 0) {
    *suc=false;
    return;
  }

  dict->Swap(new_dict);
  *suc = true;
  *cnt = keys.size();
}

void LoadTagFile(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }

  auto dict = static_cast<DynamicDict<TagDict>*>(dict_address);
  boost::shared_ptr<TagDict> new_dict(new TagDict());

  new_dict->cmap[""] = "";
  std::set<std::string> tags;
  for (size_t i = 0; i < lines.size(); ++i) {
    std::string nmlz_li_tag;
    queries::NormalizeQueryLight(lines[i], &nmlz_li_tag);
    nlp::util::NormalizeLineInPlaceS(&lines[i]);
    tags.insert(nmlz_li_tag);

    new_dict->cmap[nmlz_li_tag] = lines[i];
  }
  LOG(INFO) << "total " << tags.size() << " tags loaded";

  std::vector<const char*> keys;
  for (auto it = tags.begin(); it != tags.end(); ++it) {
    keys.push_back(it->c_str());
  }
  if (new_dict->tag_dict.build(keys.size(), &(keys[0]), NULL, NULL, NULL) != 0) {
    *suc=false;
    return;
  }

  dict->Swap(new_dict);
  *suc = true;
  *cnt = keys.size();
}

} // namespace


namespace nlpserver {

const char* TagParser::kTagFile = "tag.txt";
const char* TagParser::kNewsTagFile = "news_tag.txt";

TagParser::TagParser() {
  // register dynamic dicts for rpc call
  DM_REGISTER_CUSTOMER_DICT(reco::dm::TagDict, kTagFile, reco::dm::LoadTagFile);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::TagDict, kNewsTagFile, reco::dm::LoadNewsTagFile);
  reco::dm::DictManagerSingleton::instance().LoadAllDicts();
}

TagParser::~TagParser() {

}

std::string TagParser::ParseTag(const std::vector<std::string>& rw_queries) {
  if (rw_queries.size() < 1) return "";

  std::string hit_tag = "";
  const std::string& orig_query = rw_queries[0];

  // 先匹配事件标签词典,如果匹配到,则使用事件标签
  auto news_dict = DM_GET_DICT(reco::dm::TagDict, kNewsTagFile);
  for (size_t i = 0; i < rw_queries.size(); i++) {
    std::vector<base::Slice> matches;
    std::vector<int> values;

    int match = nlp::util::ForwardMaxMatch(news_dict->tag_dict, rw_queries[i], &matches, &values);
    if (match > 0 && orig_query.length() == matches[0].length()) {
      hit_tag = news_dict->cmap.at(matches[0].as_string());
      break;
    }
  }

  // 如果没有匹配到事件标签,则匹配普通订阅标签词典
  if (hit_tag == "") {
    auto dict = DM_GET_DICT(reco::dm::TagDict, kTagFile);
    for (size_t i = 0; i < rw_queries.size(); i++) {
      std::vector<base::Slice> matches;
      std::vector<int> values;

      int match = nlp::util::ForwardMaxMatch(dict->tag_dict, rw_queries[i], &matches, &values);
      if (match > 0 && i == 0 && orig_query.length() == matches[0].length()) {  // 原始query全匹配,直接break
        hit_tag = matches[0].as_string();
        break;
      } else if (match > 0 && i == 0) {  // 原始query部分匹配,先记录下来
        hit_tag = matches[0].as_string();
      } else if (match > 0 && rw_queries[i].length() == matches[0].length()) {  // 改写query全匹配,则覆盖原始query部分匹配
        hit_tag = matches[0].as_string();
      } else {  // 其他情况认为没命中tag
        ;
      }
    }
    hit_tag = dict->cmap.at(hit_tag);
  }

  return hit_tag;
}


}  // namespace nlpserver
}  // namespace reco

