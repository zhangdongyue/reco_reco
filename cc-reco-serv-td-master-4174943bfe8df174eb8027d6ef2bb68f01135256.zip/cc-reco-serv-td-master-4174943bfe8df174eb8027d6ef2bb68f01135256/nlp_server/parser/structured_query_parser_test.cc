#include "reco/serv/nlp_server/parser/structured_query_parser.h"

#include <vector>
#include <string>
#include <utility>
#include <set>

#include "query/parser_util/parser_util.h"
#include "query/tree/query_tree.h"
#include "query/tree/tree_util.h"
#include "base/testing/gtest.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/random/pseudo_random.h"

namespace reco {
namespace nlpserver {

TEST(StructuredQueryParser, Parse) {
  static struct {
    const char* and_words;
    const char* or_words;
    const char* not_words;
    const char* include_tree;
    const char* exclude_tree;
  } cases[] = {
    {"“\t”", "", "ab", "(AND “ ”)", "(AND ab)"},
    {"《", "》", "", "(AND 》 《)", ""},
    {"ipad", "", "mini air", "(AND ipad)", ""},
    {"1a\t2b", "", "ab", "(AND (PHRASE 1 a) (PHRASE 2 b))", "(AND ab)"},
    {"1a\t2b", "bc\t1d", "ab\t2b", "(AND (OR bc (PHRASE 1 d)) (PHRASE 1 a) (PHRASE 2 b))",
      "(AND (OR ab (PHRASE 2 b)))"},
  };

  StructuredQueryParser parser;
  std::vector<std::string> and_words;
  std::vector<std::string> or_words;
  std::vector<std::string> not_words;
  queries::QueryTree include_tree, exclude_tree;
  for (int i = 0; i < (int)ARRAYSIZE_UNSAFE(cases); ++i) {
    and_words.clear();
    base::SplitStringWithOptions(cases[i].and_words, "\t", true, true, &and_words);
    or_words.clear();
    base::SplitStringWithOptions(cases[i].or_words, "\t", true, true, &or_words);
    not_words.clear();
    base::SplitStringWithOptions(cases[i].not_words, "\t", true, true, &not_words);

    ASSERT_TRUE(parser.ParseQuery(and_words, or_words, not_words, &include_tree, &exclude_tree));

    std::string dump;
    dump.clear();
    if (include_tree.root() != NULL) {
      include_tree.ToString(&dump);
    }
    ASSERT_STREQ(cases[i].include_tree, dump.c_str());

    dump.clear();
    if (exclude_tree.root() != NULL) {
      exclude_tree.ToString(&dump);
    }
    ASSERT_STREQ(cases[i].exclude_tree, dump.c_str());
  }
}

std::string getword() {
  static const char* list = "0123456789abcdefghik";
  static base::PseudoRandom random;
  std::string word;
  for (int i = 0; i < 10; ++i) {
    int j = random.GetInt(0, 20);
    if (j < 10) {
      word.push_back(list[j]);
    }
  }
  return word;
}

TEST(StructuredQueryParser, Press) {
  StructuredQueryParser parser;
  std::vector<std::string> and_words;
  std::vector<std::string> or_words;
  std::vector<std::string> not_words;
  queries::QueryTree include_tree, exclude_tree;

  int loop = 10000;
  for (int i = 0; i < loop; ++i) {
    and_words.clear();
    base::SplitStringWithOptions(getword(), "\t", true, true, &and_words);
    or_words.clear();
    base::SplitStringWithOptions(getword(), "\t", true, true, &or_words);
    not_words.clear();
    base::SplitStringWithOptions(getword(), "\t", true, true, &not_words);

    ASSERT_TRUE(parser.ParseQuery(and_words, or_words, not_words, &include_tree, &exclude_tree));

    std::string dump;
    dump.clear();
    if (include_tree.root() != NULL) {
      include_tree.ToString(&dump);
    }

    dump.clear();
    if (exclude_tree.root() != NULL) {
      exclude_tree.ToString(&dump);
    }
  }
}
}  // namespace
}  // namespace

