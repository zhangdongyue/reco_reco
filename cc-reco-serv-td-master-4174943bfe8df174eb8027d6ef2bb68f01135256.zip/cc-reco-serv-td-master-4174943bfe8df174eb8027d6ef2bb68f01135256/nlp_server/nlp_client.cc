#include "reco/bizc/proto/reco_nlp_server.pb.h"
#include <iostream>  // NOLINT
#include <fstream>  // NOLINT
#include "reco/serv/nlp_server/nlp_service_common.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/gflags_completions.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"
#include "base/thread/thread_pool.h"
#include "net/rpc/rpc.h"

DEFINE_string(query, "", "");
DEFINE_string(ip, "127.0.0.1", "");
DEFINE_int32(port, 20008, "");
DEFINE_int32(api, 0, "0-iflow, 1-general, 2-structure");

void ParseStructuredQuery(const std::string& line,
                          std::vector<std::string>* and_words,
                          std::vector<std::string>* or_words,
                          std::vector<std::string>* not_words) {
  and_words->clear();
  or_words->clear();
  not_words->clear();

  std::vector<std::string> flds;
  base::SplitString(line, " ", &flds);

  std::vector<std::string> subs;
  if (flds.size() > 0) {
    subs.clear();
    base::SplitString(flds[0], "|", &subs);
    and_words->insert(and_words->end(), subs.begin(), subs.end());
  }

  if (flds.size() > 1) {
    subs.clear();
    base::SplitString(flds[1], "|", &subs);
    or_words->insert(or_words->end(), subs.begin(), subs.end());
  }

  if (flds.size() > 2) {
    subs.clear();
    base::SplitString(flds[2], "|", &subs);
    not_words->insert(not_words->end(), subs.begin(), subs.end());
  }
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "NLP RPC client.");
  using namespace reco::nlpserver;

  net::rpc::RpcClientChannel channel(FLAGS_ip.c_str(), FLAGS_port);
  CHECK(channel.Connect());
  NLPService::Stub service(&channel);

  if (FLAGS_api == 0) {
    reco::nlpserver::ParseQueryRequest request;
    reco::nlpserver::ParseQueryResponse response;
    request.set_query(FLAGS_query);

    net::rpc::RpcClientController rpc;
    service.ParseQuery(&rpc, &request, &response, NULL);
    rpc.Wait();

    std::cout << response.Utf8DebugString() << std::endl;
  } else if (FLAGS_api == 1) {
    reco::nlpserver::GeneralQueryRequest request;
    reco::nlpserver::GeneralQueryResponse response;
    request.add_query(FLAGS_query);

    net::rpc::RpcClientController rpc;
    service.generalQueryAnalyze(&rpc, &request, &response, NULL);
    rpc.Wait();

    std::cout << response.tree(0) << std::endl;
    std::cout << "source: " << response.in_site(0) << std::endl;
    std::cout << "region: " << response.in_region(0) << std::endl;
    std::cout << "category: " << response.in_category(0) << std::endl;
    std::cout << "tag : " << response.tag(0) << std::endl;
    std::cout << response.Utf8DebugString() << std::endl;
  } else if (FLAGS_api == 2) {
    reco::nlpserver::StructuredQueryRequest request;
    reco::nlpserver::StructuredQueryResponse response;

    std::vector<std::string> and_words;
    std::vector<std::string> or_words;
    std::vector<std::string> not_words;
    ParseStructuredQuery(FLAGS_query, &and_words, &or_words, &not_words);
    for (size_t i = 0; i < and_words.size(); ++i) {
      request.add_and_words(and_words[i]);
    }
    for (size_t i = 0; i < or_words.size(); ++i) {
      request.add_or_words(or_words[i]);
    }
    for (size_t i = 0; i < not_words.size(); ++i) {
      request.add_not_words(not_words[i]);
    }

    std::cout << request.Utf8DebugString() << std::endl;
    net::rpc::RpcClientController rpc;
    service.structuredQueryAnalyze(&rpc, &request, &response, NULL);
    rpc.Wait();

    std::cout << response.Utf8DebugString() << std::endl;
  }

  return 0;
}

