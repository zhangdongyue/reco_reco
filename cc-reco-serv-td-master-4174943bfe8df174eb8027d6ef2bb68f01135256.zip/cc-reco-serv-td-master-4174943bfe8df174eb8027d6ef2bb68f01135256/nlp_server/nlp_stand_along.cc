#include <iostream>  // NOLINT
#include <fstream>  // NOLINT
#include <string>
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/splice/splice.h"
#include "nlp/ner/ner.h"
#include "nlp/common/nlp_util.h"
#include "nlp/common/term_container.h"
#include "base/common/slice.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/gflags_completions.h"
#include "base/common/base.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"

DEFINE_bool(postag, false, "if set, output postag results, after each segmented term");
DEFINE_bool(ner, false, "if set, output ner terms, in a new line");
DEFINE_bool(using_model, false, "if set, using model");
DEFINE_string(data_file, "", "if give, use file instead stdin");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "nlp_demo");

  nlp::segment::Segmenter segmenter;
  nlp::postag::PosTagger postager;
  nlp::splice::Splicer splicer;
  nlp::ner::Ner ner;
  if (FLAGS_using_model) ner.set_using_model();

  nlp::term::TermContainer terms;
  std::vector<nlp::term::TermInfo> mix_terms;

  std::string line;
  std::istream* myin = &(std::cin);
  std::ifstream fin;
  if (FLAGS_data_file.size() > 1) {
    fin.open(FLAGS_data_file.c_str());
    myin = &fin;
  }

  while (std::getline(*myin, line)) {
    nlp::util::NormalizeLineInPlaceS(&line);
    if (line.empty()) continue;
    if (!segmenter.SegmentT(line, &terms)) {
      LOG(ERROR) << "Failed to segment: " << line;
      continue;
    }

    if (FLAGS_postag) {
      if (!postager.PosTagT(line, &terms)) {
        LOG(ERROR) << "Failed to postag: " << line;
        continue;
      }
    }

    if (FLAGS_ner) {
      if (!FLAGS_postag) {
        LOG(WARNING) << "you should call postag first, and we force the proram to call postag before ner";
        if (!postager.PosTagT(line, &terms)) {
          LOG(ERROR) << "Failed to postag: " << line;
          continue;
        }
      }
      CHECK_GT(splicer.SpliceT(line, &terms), 0);
      terms.set_splice_tag();
      if (!ner.DetectEntityT(line, &terms)) {
        LOG(ERROR) << "Failed to ner: " << line;
        continue;
      }
    }

    int token_num = terms.basic_term_num();
    for (int i = 0; i < token_num; ++i) {
      const nlp::term::TermInfo& term = terms.basic_term_info(i);
      std::cout << base::StringPrintf("%s:[%d] ", term.term(line).as_string().c_str(), term.entity_index);
      if (FLAGS_postag) {
        std::cout << postager.GetTagName(term.enum_postag) << " ";
      }
    }
    std::cout << std::endl;

    if (FLAGS_ner) {
      std::cout << "NER:";
      int entity_num = terms.entity_term_num();
      for (int i = 0; i < entity_num; ++i) {
        std::cout << base::StringPrintf("\t%s type: %d", terms.entity_term_slice(line, i).as_string().c_str(),
                                        static_cast<int>(terms.entity_terms()[i].enum_entity));
      }
      std::cout << std::endl;
    }
  }
}

