#pragma once

#include <map>
#include <string>
#include <unordered_map>

#include "base/strings/fast_number_conversions.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/base/cache/cache.h"
#include "reco/bizc/proto/reco_nlp_server.pb.h"
#include "reco/bizc/region/region_dict.h"
#include "reco/base/common/request_manager.h"
#include "reco/base/dict_manager/reload_service_impl.h"
#include "reco/serv/nlp_server/parser/tag_parser.h"

namespace nlp {

namespace segment {
class Segmenter;
}
namespace postag {
class PosTagger;
}
namespace ner {
class Ner;
}

} // namespace nlp

namespace util {
class SensitiveDict;
}

namespace thread {
template <class E>
class BlockingQueue;
}  // namespace

namespace reco {
namespace nlpserver {

class StructuredQueryParser;
class GeneralQueryParser;
class QPParser;

struct NLPWorker {
  nlp::segment::Segmenter* segmenter;
  nlp::postag::PosTagger* postager;
  nlp::ner::Ner* ner;
  StructuredQueryParser* structured_parser;
  GeneralQueryParser* general_parser;
  QPParser* qp_parser;
};


class NLPServiceImpl: public NLPService {
public:
  NLPServiceImpl();
  ~NLPServiceImpl();

  virtual void process(stumy::RpcController* controller,
                       const NLPRequest* request,
                       NLPResponse* response,
                       Closure* done);

  virtual void structuredQueryAnalyze(stumy::RpcController* controller,
                                      const StructuredQueryRequest* request,
                                      StructuredQueryResponse* response,
                                      Closure* done);

  virtual void generalQueryAnalyze(stumy::RpcController* controller,
                                   const GeneralQueryRequest* request,
                                   GeneralQueryResponse* response,
                                   Closure* done);
  void generalQueryAnalyze_(const GeneralQueryRequest* request,
                           GeneralQueryResponse* response,
                           Closure* done);

  virtual void ParseQuery(stumy::RpcController* controller,
                          const ParseQueryRequest* request,
                          ParseQueryResponse* response,
                          Closure* done);
  void ParseQuery_(const ParseQueryRequest* request,
                  ParseQueryResponse* response,
                  Closure* done);

  void ExtractRegionInfoFromRawQuery(std::string* query, std::string* in_region);

private:
  static const std::string REDIS_QP_KEY_PREFIX;
  static const std::string REDIS_RSLT_KEY_PREFIX;

  inline std::string GenQpKey(uint64 key) {
    char buf[128];
    base::FastUInt64ToBuffer(key, buf);
    return REDIS_QP_KEY_PREFIX + buf;
  }

  inline std::string GenResultKey(const std::string& key) {
    return REDIS_RSLT_KEY_PREFIX + key;
  }

  inline bool GetQPCache(uint64 key, std::string* value) {
    LOG(INFO) << "try get cache: " << key;
    return cache_->Get(GenQpKey(key), value);
  }

  inline void DelQPCache(uint64 key) {
    LOG(INFO) << "try del cache: " << key;
    cache_->Del(GenQpKey(key));
  }

  inline bool SetQPCache(uint64 key, const std::string& value) {
    LOG(INFO) << "try set cache: " << key;
    return cache_->Set(GenQpKey(key), value);
  }

  inline bool GetResultCache(const std::string& key, std::string* value) {
    LOG(INFO) << "try get result cache: " << key;
    return cache_->Get(GenResultKey(key), value);
  }

  inline bool SetResultCache(const std::string& key, const std::string& value) {
    LOG(INFO) << "try set result cache: " << key;
    return cache_->Set(GenResultKey(key), value);
  }

private:
  thread::BlockingQueue<NLPWorker*>* nlp_worker_pool_;
  reco::common::RegionDict* region_dict_;
  reco::common::Cache* cache_;
  TagParser* tag_parser_;

  reco::common::RequestManager* req_manager_;

  DISALLOW_COPY_AND_ASSIGN(NLPServiceImpl);
};
} // namespace
} // namespace
