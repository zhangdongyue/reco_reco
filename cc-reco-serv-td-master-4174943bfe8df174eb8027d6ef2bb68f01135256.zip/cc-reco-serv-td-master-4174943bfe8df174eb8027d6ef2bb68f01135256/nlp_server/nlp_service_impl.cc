#include <vector>
#include "reco/serv/nlp_server/nlp_service_impl.h"
#include "nlp/common/nlp_util.h"
#include "query/parser_util/parser_util.h"
#include "query/tree/tree_util.h"
#include "query/dnf/dnf_util.h"
#include "query/tree/query_tree.h"
#include "query/parser_util/parser_define.h"
#include "nlp/segment/segmenter.h"
#include "nlp/postag/pos_tagger.h"
#include "nlp/ner/ner.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/internal/string_util.h"
#include "base/thread/blocking_queue.h"
#include "extend/json/jansson/jansson.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/base/cache/cache.h"
#include "reco/serv/nlp_server/parser/structured_query_parser.h"
#include "reco/serv/nlp_server/parser/general_query_parser.h"
#include "reco/serv/nlp_server/parser/qp_parser.h"

DEFINE_bool(use_cache, true, "use redis cache");
DEFINE_bool(use_qp, true, "use QP parser");
DECLARE_string(redis_pool_ips);
DEFINE_int32(cache_expire_time, 3600, "");

DEFINE_int32(worker_num, 128, "");
DEFINE_int64(request_time_out_ms, 500, "");

DEFINE_int64_counter(nlp, gnrl_request_total, 0, "");
DEFINE_int64_counter(nlp, gnrl_request_total_resp_time, 0, "");
DEFINE_int64_counter(nlp, iflow_request_total, 0, "");
DEFINE_int64_counter(nlp, iflow_request_total_hit_cache, 0, "");
DEFINE_int64_counter(nlp, iflow_request_total_resp_time, 0, "");
DEFINE_int64_counter(nlp, qp_request, 0, "");
DEFINE_int64_counter(nlp, qp_fail, 0, "");

namespace reco {
namespace nlpserver {

DEFINE_string(data_abs_dir, "", "data dir absolute path");
DEFINE_int32(samples_nlp_worker_num, 10, "worker number, better >= server thread number");
DEFINE_string(region_file, "/data/reco/dict/nlp/dicts/common/region_dict.txt", "region file");

const std::string NLPServiceImpl::REDIS_QP_KEY_PREFIX = "NLP_QP_KEY_";
const std::string NLPServiceImpl::REDIS_RSLT_KEY_PREFIX = "NLP_RSLT_KEY_";

NLPServiceImpl::NLPServiceImpl() {
  nlp_worker_pool_ = new thread::BlockingQueue<NLPWorker*>;
  for (int i = 0; i < FLAGS_samples_nlp_worker_num; ++i) {
    NLPWorker *worker = new NLPWorker;
    worker->segmenter = new nlp::segment::Segmenter;
    worker->postager = new nlp::postag::PosTagger;
    worker->ner = new nlp::ner::Ner;
    worker->structured_parser = new StructuredQueryParser;
    worker->general_parser = new GeneralQueryParser;
    if(FLAGS_use_qp) worker->general_parser->SetUseQp();
    worker->qp_parser = new QPParser;
    nlp_worker_pool_->Put(worker);
  }
  LOG(INFO) << "worker all initialized";

  tag_parser_ = new TagParser();

  // Init region search module
  reco::common::RegionSearcher::instance().Load(FLAGS_region_file);
  region_dict_ = &reco::common::RegionSearcher::instance();

  // cache
  cache_ = new reco::common::Cache(FLAGS_cache_expire_time,
                                  reco::redis::FLAGS_redis_pool_ips,
                                  FLAGS_cache_expire_time);

  req_manager_ = new reco::common::RequestManager();
  req_manager_->Init(FLAGS_worker_num, FLAGS_request_time_out_ms);

  reco::common::ReqFuncMapBase* parse_gnrl_query = new reco::common::ReqFuncMap<NLPServiceImpl,
                                           GeneralQueryRequest,
                                           GeneralQueryResponse>(this, &NLPServiceImpl::generalQueryAnalyze_);
  req_manager_->RegisterReqFuncMap(parse_gnrl_query);

  reco::common::ReqFuncMapBase* parse_iflow_query = new reco::common::ReqFuncMap<NLPServiceImpl,
                                           ParseQueryRequest,
                                           ParseQueryResponse>(this, &NLPServiceImpl::ParseQuery_);
  req_manager_->RegisterReqFuncMap(parse_iflow_query);
}

NLPServiceImpl::~NLPServiceImpl() {
  while (!nlp_worker_pool_->Empty()) {
    NLPWorker *worker = nlp_worker_pool_->Take();
    delete worker->segmenter;
    delete worker->postager;
    delete worker->ner;
    delete worker->structured_parser;
    delete worker->general_parser;
    delete worker;
  }
  delete nlp_worker_pool_;
  if (cache_) delete cache_;
}

void NLPServiceImpl::process(stumy::RpcController* controller,
                             const NLPRequest* request,
                             NLPResponse* response,
                             Closure* done) {
  LOG(INFO) << "request: " << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);
  ScopedClosure scoped_closure(done);
  // get a worker from pool
  NLPWorker *worker = nlp_worker_pool_->Take();

  if (request->do_normalize()) {
    response->set_raw_text(nlp::util::NormalizeLine(request->raw_text()));
  } else {
    response->set_raw_text(request->raw_text());
  }
  // do nlp work
  std::vector<std::string> segment_results;
  std::vector<std::string> postag_results;
  nlp::term::TermContainer word_infos;

  const std::string& text = response->raw_text();

  bool success = true;
  switch (request->request_type()) {
    case NLPRequest::kSegment:
      success = success && worker->segmenter->SegmentT(text, &word_infos);
      if (success) {
        for (int i = 0; i < (int)word_infos.basic_term_num(); ++i) {
          const base::Slice& slice = word_infos.basic_term_slice(text, i);
          response->add_segments(slice.data(), slice.size());
        }
      }
      break;
    case NLPRequest::kSegmentPostag:
      success = success && worker->segmenter->SegmentT(text, &word_infos);
      success = success && worker->postager->PosTagT(text, &word_infos);
      if (success) {
        for (int i = 0; i < (int)word_infos.basic_term_num(); ++i) {
          const base::Slice& slice = word_infos.basic_term_slice(text, i);
          response->add_segments(slice.data(), slice.size());
          response->add_postags(worker->postager->GetTagName(word_infos.basic_term_info(i).enum_postag));
        }
      }
      break;
    case NLPRequest::kSegmentPostagEntity:
      success = success && worker->segmenter->SegmentT(text, &word_infos);
      success = success && worker->postager->PosTagT(text, &word_infos);
      success = success && worker->ner->DetectEntityT(text, &word_infos);
      if (success) {
        for (int i = 0; i < (int)word_infos.basic_term_num(); ++i) {
          const base::Slice& slice = word_infos.basic_term_slice(text, i);
          response->add_segments(slice.data(), slice.size());
          response->add_postags(worker->postager->GetTagName(word_infos.basic_term_info(i).enum_postag));
        }
        for (int i = 0; i < (int)word_infos.entity_term_num(); ++i) {
          const nlp::term::TermInfo& term_info = word_infos.entity_term_info(i);
          base::Slice slice = term_info.term(text);
          auto entity = response->add_entities();
          entity->set_type(NLPResponse_EntityType(term_info.enum_entity));
          entity->set_entity(slice.as_string());
        }
      }
      break;
  }

  // all require field in protobuf should be set
  response->set_success(success);
  if (!success) {
    LOG(ERROR) << "nlp process (request type: " << request->request_type() <<
        " failed for raw text: " << request->raw_text();
  }

  // put worker back to pool so that it can be used by other thread
  nlp_worker_pool_->Put(worker);
}

void NLPServiceImpl::structuredQueryAnalyze(stumy::RpcController* controller,
                                            const StructuredQueryRequest* request,
                                            StructuredQueryResponse* response,
                                            Closure* done) {
  ScopedClosure scoped_closure(done);
  // get a worker from pool
  NLPWorker *worker = nlp_worker_pool_->Take();
  auto parser = worker->structured_parser;

  std::vector<std::string> and_words;
  and_words.reserve(request->and_words_size());
  for (int i = 0; i < (int)request->and_words_size(); ++i) {
    and_words.push_back(nlp::util::NormalizeLine(request->and_words(i)));
  }

  std::vector<std::string> or_words;
  or_words.reserve(request->or_words_size());
  for (int i = 0; i < (int)request->or_words_size(); ++i) {
    or_words.push_back(nlp::util::NormalizeLine(request->or_words(i)));
  }

  std::vector<std::string> not_words;
  not_words.reserve(request->not_words_size());
  for (int i = 0; i < (int)request->not_words_size(); ++i) {
    not_words.push_back(nlp::util::NormalizeLine(request->not_words(i)));
  }

  queries::QueryTree include_tree;
  queries::QueryTree exclude_tree;
  bool ret = parser->ParseQuery(and_words, or_words, not_words, &include_tree, &exclude_tree);
  if (ret) {
    response->set_success(true);
    if (include_tree.root() != NULL) {
      include_tree.ToString(response->mutable_include_tree());
    }
    if (exclude_tree.root() != NULL) {
      exclude_tree.ToString(response->mutable_exclude_tree());
    }
  } else {
    response->set_success(false);
  }

  LOG(INFO) << "request: " << base::StringReplace(request->Utf8DebugString(), "\n", " ", true)
            << " process result: " << ret;
  nlp_worker_pool_->Put(worker);
}

static std::string DetectSpecialExpression(const std::string& orig_query,
                                           std::string* in_site,
                                           std::string* in_category,
                                           std::string* tag) {
  static const std::string kInSitePrefix = "@";
  static const std::string kCategoryBoundary = "##";
  static const std::string kTagBoundary = "#";

  std::string query = orig_query;

  std::vector<std::pair<size_t, size_t>> special_pos;
  std::set<char> blank_set = {' ', '\t', '\v', '\n', '\r'};

  // find @ and the word
  size_t begin = query.find("@");
  if (begin != std::string::npos) {
    ++begin;
    size_t end = begin;
    while (++end < query.size() && (blank_set.find(query[end]) == blank_set.end() && query[end] != '#'));

    if (end - begin < 2) {
      LOG(ERROR) << "short source: " << query.substr(end - begin);
    } else {
      *in_site = query.substr(begin, end - begin);
      special_pos.push_back(std::make_pair(begin - 1, end));
      // LOG(ERROR) << base::StringPrintf("site: %s, begin: %lu, end: %lu", in_site->c_str(), begin, end);
    }
  }

  // find ##$category##
  begin = query.find(kCategoryBoundary);
  if (begin != std::string::npos) {
    begin += 2;
    // LOG(ERROR) << " begin: " << begin;
    size_t end = query.find(kCategoryBoundary, begin + 1);
    if (end != std::string::npos && end > begin) {
      // check for special pos overlap
      // LOG(ERROR) << " begin: " << begin << "end: " << end;
      bool conflict = false;
      for (size_t i = 0; i < special_pos.size(); ++i) {
        if ((special_pos[i].first < begin && special_pos[i].second > begin) ||
            (special_pos[i].first < end && special_pos[i].second > end)) {
          LOG(ERROR) << "## overlap special expression";
          conflict = true;
          break;
        }
      }
      if (!conflict && end - begin >= 2) {
        *in_category= query.substr(begin, end - begin);
        special_pos.push_back(std::make_pair(begin - 1, end + 1));
        // LOG(ERROR) << base::StringPrintf("category: %s, begin: %lu, end: %lu", in_category->c_str(), begin, end);
      }
    }
  }

  begin = query.find(kTagBoundary);
  if (begin != std::string::npos) {
    ++begin;
    // LOG(ERROR) << " begin: " << begin;
    size_t end = query.find(kTagBoundary, begin + 1);
    if (end != std::string::npos && end > begin) {
      // check for special pos overlap
      // LOG(ERROR) << " begin: " << begin << "end: " << end;
      bool conflict = false;
      for (size_t i = 0; i < special_pos.size(); ++i) {
        if ((special_pos[i].first < begin && special_pos[i].second > begin) ||
            (special_pos[i].first < end && special_pos[i].second > end)) {
          LOG(ERROR) << "# overlap special expression";
          conflict = true;
          break;
        }
      }
      if (!conflict && end - begin >= 2) {
        *tag = query.substr(begin, end - begin);
        special_pos.push_back(std::make_pair(begin - 1, end + 1));
        // LOG(ERROR) << base::StringPrintf("category: %s, begin: %lu, end: %lu", in_category->c_str(), begin, end);
      }
    }
  }

  if (special_pos.empty()) return query;
  // sort
  std::string result;
  result.reserve(query.size());
  std::sort(special_pos.begin(), special_pos.end());
  size_t start = 0;
  for (size_t i = 0; i < special_pos.size(); ++i) {
    // overlap
    if (special_pos[i].first < start && special_pos[i].first > 0) {
      LOG(ERROR) << base::StringPrintf("erro pos: start: %lu, special begin: %lu", start, special_pos[i].first);
      continue;
    }

    if (start < special_pos[i].first) {
      result.append(query.substr(start, special_pos[i].first - start));
    }

    start = special_pos[i].second;
  }

  if (start < query.size()) {
    result.append(query.substr(start));
  }
  return result;
}

void NLPServiceImpl::ExtractRegionInfoFromRawQuery(std::string* query, std::string* in_region) {
  static const std::string kRegionDelim = " ";

  std::vector<std::string> tokens;
  base::SplitString(*query, kRegionDelim, &tokens);

  // judge if region names exist in tokens, if do, erase them
  for (auto it = tokens.begin(); it != tokens.end(); it++) {
    *in_region = region_dict_->SearchRegionCode(*it);
    if (*in_region != "") {
      tokens.erase(it);
      base::FastJoinStrings(tokens, kRegionDelim, query);

      // currently only need to support single region search
      return;
    }
  }
}

void NLPServiceImpl::generalQueryAnalyze_(const GeneralQueryRequest* request,
                                          GeneralQueryResponse* response,
                                          Closure* done) {
  serving_base::Timer timer;
  timer.Start();
  ScopedClosure scoped_closure(done);

  // get a worker from pool
  NLPWorker *worker = nlp_worker_pool_->Take();
  auto parser = worker->general_parser;

  response->set_success(false);
  std::string in_site;
  std::string in_category;
  std::string tag;
  std::string in_region;
  for (int i = 0; i < (int)request->query_size(); ++i) {
    const std::string& orig_query = request->query(i);
    response->add_query(orig_query);
    // find some special expression
    in_site.clear();
    in_category.clear();
    tag.clear();
    std::string query = DetectSpecialExpression(orig_query, &in_site, &in_category, &tag);
    // Only extract region info when none special expression exists
    if (query.length() == orig_query.length()) {
      ExtractRegionInfoFromRawQuery(&query, &in_region);
    }
    // query, tag 在索引里都做了归一化； site 和 category没有，因此要区别对待
    std::string nmlz_query = nlp::util::NormalizeLine(query);
    response->add_in_site(in_site);
    response->add_in_category(in_category);
    response->add_tag(nlp::util::NormalizeLine(tag));
    response->add_in_region(in_region);

    queries::QueryTree tree;
    if (parser->ParseQuery(nmlz_query, &tree)) {
      response->add_parse_ok(true);
      tree.ToString(response->add_tree());
      response->set_success(true);
    } else {
      if (!response->in_site(i).empty() || !response->in_category(i).empty()
          || !response->tag(i).empty() || !response->in_region(i).empty()) {
        response->set_success(true);
      } else {
        response->set_success(false);
      }
      response->add_parse_ok(false);
      response->add_tree("");
    }

    // proc hit tag
    std::string nmlz_li_query;
    queries::NormalizeQueryLight(query, &nmlz_li_query);
    std::vector<std::string> rw_queries;
    rw_queries.push_back(nmlz_li_query);

    queries::QueryTree dnf_tree;  // 用来释放内存
    queries::QueryTreeNode* dnf_root = NULL;
    if (tree.root() && (dnf_root = queries::BuildDNF(tree.root(), 10)) != NULL) {
      dnf_tree.set_root(dnf_root);
      for (auto it = dnf_root->first_child(); it != NULL; it = it->next_sibling()) {
        std::vector<const queries::QueryTreeNode*> node_list;
        std::string combine_literal;
        std::string nmlz_li_literal;
        queries::GetLeafNodes(it, &node_list, &combine_literal);
        if (combine_literal == "") continue;
        queries::NormalizeQueryLight(combine_literal, &nmlz_li_literal);
        rw_queries.push_back(nmlz_li_literal);
      }
    }

    std::string hit_tag = tag_parser_->ParseTag(rw_queries);
    response->add_hit_tag(hit_tag);
  }

  LOG(INFO) << "request: " << base::StringReplace(request->Utf8DebugString(), "\n", " ", true)
            << " process result: " << response->success();
  nlp_worker_pool_->Put(worker);

  COUNTERS_nlp__gnrl_request_total_resp_time.Increase(timer.Stop() / 1000);
  COUNTERS_nlp__gnrl_request_total.Increase(1);
}

void NLPServiceImpl::generalQueryAnalyze(stumy::RpcController* controller,
                                         const GeneralQueryRequest* request,
                                         GeneralQueryResponse* response,
                                         Closure* done) {
  req_manager_->AddReqTask(request, response, done);
}


void NLPServiceImpl::ParseQuery_(const ParseQueryRequest* request,
                                 ParseQueryResponse* response,
                                 Closure* done) {
  ScopedClosure scoped_closure(done);

  // find in cache first
  std::string normalized_key = nlp::util::NormalizeLine(request->query());
  std::string serialized_rslt;
  if (FLAGS_use_cache && GetResultCache(normalized_key, &serialized_rslt)
                      && response->ParseFromString(serialized_rslt)) {
    COUNTERS_nlp__iflow_request_total_hit_cache.Increase(1);
    return;
  }

  serving_base::Timer timer;
  timer.Start();

  // get a worker from pool
  NLPWorker *worker = nlp_worker_pool_->Take();
  auto parser = worker->general_parser;
  auto qp_parser = worker->qp_parser;

  response->set_success(false);

  // find some special expression
  const std::string& orig_query = request->query();
  std::string in_site;
  std::string in_category;
  std::string tag;
  std::string query = DetectSpecialExpression(orig_query, &in_site, &in_category, &tag);

  // query, tag 在索引里都做了归一化； site 和 category没有，因此要区别对待
  std::string nmlz_query = nlp::util::NormalizeLine(query);
  response->set_in_site(in_site);
  response->set_in_category(in_category);
  response->set_tag(nlp::util::NormalizeLine(tag));

  // QP parse
  bool qp_ret = false;
  queries::QpResult* qp_result = NULL;
  if (FLAGS_use_qp && !nmlz_query.empty()) {
    qp_result = new queries::QpResult;

    std::string raw_qp_result;
    uint64 query_hash = base::CityHash64(nmlz_query.c_str(), nmlz_query.size());
    if(GetQPCache(query_hash, &raw_qp_result)){
      qp_ret = qp_parser->ParseRawQPResult(raw_qp_result, qp_result);
      if (!qp_ret) {
        DelQPCache(query_hash ); // Invalid cache
      }
    } else {
      COUNTERS_nlp__qp_request.Increase(1);
      qp_ret = qp_parser->QPParse(nmlz_query, qp_result);
      if (qp_ret) {
        SetQPCache(query_hash, qp_parser->GeRawQPResult());
      } else {
        COUNTERS_nlp__qp_fail.Increase(1);
      }
    }
  }

  if (qp_ret) {
    VLOG(1) << "QP result raw: " << qp_parser->GeRawQPResult();
    LOG(INFO) << "QP result parsed: " << qp_result->ToString();
  }

  queries::QueryTree tree;
  if (parser->ParseQuery(nmlz_query, qp_result, &tree)) {
    tree.ToString(response->mutable_tree());
    response->set_success(true);
  } else {
    if (!response->in_site().empty() || !response->in_category().empty() || !response->tag().empty()) {
      response->set_success(true);
    } else {
      response->set_success(false);
    }
    response->set_tree("");
  }

  // proc hit tag
  std::string nmlz_li_query;
  queries::NormalizeQueryLight(query, &nmlz_li_query);
  std::vector<std::string> rw_queries;
  rw_queries.push_back(nmlz_li_query);

  queries::QueryTree dnf_tree;  // 用来释放内存
  queries::QueryTreeNode* dnf_root = NULL;
  if (tree.root() && (dnf_root = queries::BuildDNF(tree.root(), 10)) != NULL) {
    dnf_tree.set_root(dnf_root);
    for (auto it = dnf_root->first_child(); it != NULL; it = it->next_sibling()) {
      std::vector<const queries::QueryTreeNode*> node_list;
      std::string combine_literal;
      std::string nmlz_li_literal;
      queries::GetLeafNodes(it, &node_list, &combine_literal);
      if (combine_literal == "") continue;
      queries::NormalizeQueryLight(combine_literal, &nmlz_li_literal);
      rw_queries.push_back(nmlz_li_literal);
    }
  }

  std::string hit_tag = tag_parser_->ParseTag(rw_queries);
  response->set_hit_tag(hit_tag);

  if (qp_result) delete qp_result;

  LOG(INFO) << "request: " << base::StringReplace(request->Utf8DebugString(), "\n", " ", true)
            << " process result: " << response->success() << ", QPret: " << qp_ret;
  nlp_worker_pool_->Put(worker);

  if (FLAGS_use_cache && response->SerializeToString(&serialized_rslt)) {
    SetResultCache(normalized_key, serialized_rslt);
  }

  COUNTERS_nlp__iflow_request_total_resp_time.Increase(timer.Stop() / 1000);
  COUNTERS_nlp__iflow_request_total.Increase(1);
}

void NLPServiceImpl::ParseQuery(stumy::RpcController* controller,
                                const ParseQueryRequest* request,
                                ParseQueryResponse* response,
                                Closure* done) {
  req_manager_->AddReqTask(request, response, done);
}
}  // namespace
}  // namespace
