#include <iostream>  // NOLINT
#include <fstream>  // NOLINT
#include <string>
#include "nlp/common/nlp_util.h"
#include "base/common/slice.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/gflags_completions.h"
#include "base/common/base.h"
#include "base/strings/string_util.h"

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "nlp_demo");

  std::string line;
  while (std::getline(std::cin, line)) {
    std::string str_ban;
    nlp::util::QuanJiaoToBanJiao(line, &str_ban);
    std::cout << str_ban << std::endl;
  }
}

