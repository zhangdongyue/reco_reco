#pragma once

#include "reco/bizc/proto/reco_nlp_server.pb.h"

namespace reco {
namespace nlpserver {
DECLARE_int32(samples_nlp_requests);
DECLARE_string(samples_nlp_ip);
DECLARE_int32(samples_nlp_port);
DECLARE_string(samples_nlp_file_in);
DECLARE_string(samples_nlp_file_out);

void OutputResponse(const NLPResponse& response);
bool InputRequest(NLPRequest* request);
} // namespace
} // namespace
