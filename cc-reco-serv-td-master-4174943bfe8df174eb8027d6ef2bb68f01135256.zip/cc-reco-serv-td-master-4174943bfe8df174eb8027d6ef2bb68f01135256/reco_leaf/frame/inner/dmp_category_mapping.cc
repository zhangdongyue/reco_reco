#include "reco/serv/reco_leaf/frame/inner/dmp_category_mapping.h"

#include <utility>
#include <string>
#include <vector>
#include "reco/bizc/proto/common.pb.h"

#include "nlp/common/nlp_util.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace leafserver {

const char* DmpCategoryMapping::kDmpCategoryMapFile = "dmp_category_mapping.txt";

bool DmpCategoryMapping::LoadDict(const std::string& leaf_data_dir) {
  base::FilePath base_dir(leaf_data_dir);
  base::FilePath mapping_file = base_dir.Append(kDmpCategoryMapFile);
  std::vector<std::string> lines;
  CHECK(base::file_util::ReadFileToLines(mapping_file, &lines));

  std::string dmp_category;
  std::string reco_category;
  double transfer_weight = 0;
  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 3u) {
      LOG(ERROR) << "dmp category map record error, " << lines[i];
      continue;
    }
    dmp_category = nlp::util::NormalizeLine(flds[0]);
    reco_category = nlp::util::NormalizeLine(flds[1]);
    if (dmp_category.empty()
        || reco_category.empty()
        || !base::StringToDouble(flds[2], &transfer_weight)) {
      LOG(ERROR) << "dmp category map record error, " << lines[i];
      continue;
    }
    dmp_category_map.insert(std::make_pair(dmp_category, std::make_pair(reco_category, transfer_weight)));
  }

  LOG(INFO) << "succ to load dmp category mapping file, total record: " << dmp_category_map.size();

  return true;
}

bool DmpCategoryMapping::ConvertToRecoCategory(const reco::CategoryFeature& dmp_category_fea,
                                               reco::CategoryFeature* reco_category_fea) const {
  // 优先找二级的映射表
  const reco::Category& dmp_category = dmp_category_fea.literal();
  if (dmp_category.level() > 0 && dmp_category.parents_size() <= 0) return false;

  const double dmp_weight = dmp_category_fea.weight();
  if (dmp_category.level() == 1) {
    std::string key = dmp_category.parents(0) + "-" + dmp_category.category();
    auto iter = dmp_category_map.find(key);
    if (iter != dmp_category_map.end()) {
      return BuildRecoCategory(iter->second, dmp_weight, reco_category_fea);
    }
  }

  // 找一级的映射表
  std::string key = dmp_category.level() > 0 ? dmp_category.parents(0) : dmp_category.category();
  auto iter = dmp_category_map.find(key);
  if (iter != dmp_category_map.end()) {
    return BuildRecoCategory(iter->second, dmp_weight, reco_category_fea);
  }

  // 找不到返回失败
  return false;
}

bool DmpCategoryMapping::ConvertToRecoCategoryLiteral(const std::string& dmp_category,
                                                      std::string* reco_category) const {
  const std::string& key = dmp_category;
  auto iter = dmp_category_map.find(key);
  if (iter != dmp_category_map.end()) {
    *reco_category = iter->second.first;
    return true;
  }
  return false;
}

bool DmpCategoryMapping::BuildRecoCategory(const std::pair<std::string, float>& map_val,
                                           double org_weight,
                                           reco::CategoryFeature* reco_category_fea) const {
  if (map_val.first.empty() || map_val.second < 1e-6 || org_weight < 1e-6) return false;

  // set category
  std::vector<std::string> flds;
  base::SplitString(map_val.first, "-", &flds);
  reco::Category* reco_category = reco_category_fea->mutable_literal();
  reco_category->clear_parents();
  if (flds.size() == 2u) {
    if (flds[0].empty() || flds[1].empty()) return false;
    reco_category->set_level(1);
    reco_category->set_category(flds[1]);
    reco_category->add_parents(flds[0]);
  } else if (flds.size() == 1u) {
    if (flds[0].empty()) return false;
    reco_category->set_level(0);
    reco_category->set_category(flds[0]);
  } else {
    return false;
  }
  // set fea info
  reco_category_fea->set_weight(org_weight * map_val.second);
  reco_category_fea->set_item_type(reco::kNews);
  reco_category_fea->set_confidence(1.0);

  return true;
}
}
}
