#pragma once

#include <unordered_map>
#include <utility>
#include <string>

#include "reco/bizc/proto/common.pb.h"

#include "nlp/common/nlp_util.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace leafserver {

class DmpCategoryMapping {
 public:
  DmpCategoryMapping() {}
  ~DmpCategoryMapping() {}

  bool LoadDict(const std::string& leaf_data_dir);

  // 一级类别的字面转换
  bool ConvertToRecoCategoryLiteral(const std::string& dmp_category, std::string* reco_category) const;

  // dmp category fea 转换成 reco category fea
  bool ConvertToRecoCategory(const reco::CategoryFeature& dmp_category_fea,
                             reco::CategoryFeature* reco_category_fea) const;

 private:
  bool BuildRecoCategory(const std::pair<std::string, float>& map_val, double org_weight,
                         reco::CategoryFeature* reco_category_fea) const;

 private:
  static const char* kDmpCategoryMapFile;

  std::unordered_map<std::string, std::pair<std::string, float>> dmp_category_map;
};
}
}
