#include "base/time/time.h"
#include "reco/serv/reco_leaf/frame/inner/video_communicator.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/reco_leaf/strategy/reco/video/video_reco.h"
#include "reco/serv/dict_server/api/dict_server_api.h"
#include "reco/serv/reco_leaf/proto/leaf_data.pb.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

/*
DEFINE_string(video_server_machine_list, "test_video.yaml", "video server config file");
DEFINE_int32(video_server_timeout_per_communicate, 150, "video server time out, ms");
DEFINE_int32(video_server_total_timeout, 290, "video server total timeout");
DEFINE_int32(video_server_retry_times, 1, "video server retry num");
DEFINE_int32(video_results_timeout, 60, "visit dict server get video result timeout");
*/

DEFINE_string(video_cache_prefix, "VIDEO_CALC_CACHE", "");

DEFINE_int64_counter(recommend, get_video_error_num, 0, "get video result error num");
DEFINE_int64_counter(recommend, get_video_from_cache_num, 0, "get video result from cache num");
DEFINE_int64_counter(recommend, get_video_from_server_num, 0, "get video result from server num");
DEFINE_int64_counter(recommend, get_video_req_cost, 0, "");

serving_base::ExpiryMap<std::string, std::string>* VideoComm::cache_ =
    new serving_base::ExpiryMap<std::string, std::string>(10 * 60);

void RpcCompleteCallback(thread::BlockingVar<bool>* rpc_complete) {
  if (rpc_complete != NULL) {
    rpc_complete->TryPut(true);
  }
  // 这里把结果缓存
}

VideoComm::VideoComm(const reco::NewsIndex* news_index) {
  news_index_ = news_index;
  // Init();
}

VideoComm::~VideoComm() {
}
/*
void VideoComm::Init() {
  serving_base::CommunicateConfig config("");
  config.file_name = FLAGS_video_server_machine_list;
  config.timeout = FLAGS_video_server_timeout_per_communicate;
  config.max_retry_times = FLAGS_video_server_retry_times;
  config.enable_heart_beat = false;
  config.heart_beat_timeout = 50;
  config.heart_beat_slow_times = 3;
  config.heart_beat_ignore_times = 50;
  config.total_timeout = FLAGS_video_server_total_timeout;
  config.enable_child_reload = false;

  video_communicator_ = new VideoCommunicator(config,
                                              &reco::leafserver::RecommendService::getDataFromVideoServer);
  CHECK_NOTNULL(video_communicator_);
}
*/
bool VideoComm::GetVideoCandidateCache(const std::string& key, std::string* value) {
  value->clear();
  if (cache_ && cache_->FindSilently(key, value)) {
    return true;
  } else {
    if (reco::dictserver::DictServerAPIIns::instance().GetData("VideoAsyncTask", key, "", value, true)) {
      if (cache_)
        cache_->Add(key, *value);
      return true;
    } else {
      return false;
    }
  }
  return false;
}

void VideoComm::GetVideoResults(const UserInfo& user_info,
                                const reco::leafserver::RecommendRequest* request,
                                reco::leafserver::DataFromVideoServerResponse* video_response,
                                bool* ret,
                                std::string* err_msg) {
  *ret = true;
  // 先从缓存取
  if (VideoReco::GetVideoResponseFromCache(*request, video_response)) {
    VLOG(1) << "get video_response from cache " << request->user().user_id();
    COUNTERS_recommend__get_video_from_cache_num.Increase(1);
    video_response->set_success(true);
    return;
  }

  const uint64 user_id = request->user().user_id();
  std::string key;
  key = base::StringPrintf("%s_%lu", FLAGS_video_cache_prefix.c_str(), user_id);
  bool get_cache_success = false;
  CachedNewsRecoData cached_results;
  do {
    std::string value;
    if (!GetVideoCandidateCache(key, &value)) {
      LOG(WARNING) << "get video candidate fail:" << key;
      break;
    }

    if (value.empty()) {
      break;
    }

    if (!cached_results.ParseFromString(value)) {
      LOG(WARNING) << "fail to parse string:" << value;
      break;
    }
    get_cache_success = true;
  } while (false);

  if (!get_cache_success) {
    LOG(WARNING) << "get video result fail.";
    video_response->Clear();
    video_response->set_success(true);
    return;
  }

  base::dense_hash_set<uint64> item_dedup;
  item_dedup.set_empty_key(0);
  for (int i = 0; i < cached_results.item_misc_size(); ++i) {
    const CachedItemMisc& item_misc = cached_results.item_misc(i);
    ItemInfo item;
    item.item_id = item_misc.item_id();
    item.category = item_misc.category();

    ItemType item_type;
    if (!news_index_->GetItemTypeByItemId(item_misc.item_id(), &item_type)) {
      continue;
    }
    // 暂时只要纯视频
    if (item_type != reco::kPureVideo) {
      continue;
    }

    if (!news_index_->GetItemInfoByItemId(item_misc.item_id(), &item, false)) {
      continue;
    }

    base::Time current_time = base::Time::Now();
    int64 current_timestamp = current_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
    if (!NewsFilter::ItemIsValid(item, current_timestamp)) {
      continue;
    }

    if (NewsFilter::IsDeduped(item, &item_dedup)) {
      continue;
    }
    std::string title;
    if (!news_index_->GetItemTitleByItemId(item.item_id, &title)) {
      continue;
    }

    auto result = video_response->add_items();
    result->set_title(title);
    result->set_strategy_type(reco::kVideo);
    result->set_item_id(item.item_id);
    if (item_misc.has_reco_score()) {
      result->set_reco_score(item_misc.reco_score());
    }
    result->set_outer_id(base::Uint64ToString(item.item_id));
    int64 timestamp = news_index_->GetCreateTimestampByItemId(item.item_id);
    result->set_create_timestamp(timestamp);
    result->set_parent_id(news_index_->GetParentId(item.item_id));
    result->set_reco_id(request->reco_id());
    result->set_item_type(item.item_type);
    std::vector<reco::Category> categories;
    if (news_index_->GetCategoriesByItemId(item.item_id, &categories)) {
      for (int j = 0; j < (int)categories.size(); ++j) {
        result->add_category(categories[j].category());
      }
    }
    reco::FeatureVector tag_fea;
    if (news_index_->GetVideoTagFeatureVectorByItemId(item.item_id, &tag_fea)) {
      for (int j = 0; j < tag_fea.feature_size(); ++j) {
        result->add_tags(tag_fea.feature(j).literal());
      }
    }
  }

  if (!cached_results.shunt_tag().empty()) {
    video_response->add_shunt_tags(cached_results.shunt_tag());
  }

  video_response->set_success(true);


  /*
     reco::leafserver::DataFromVideoServerRequest video_request;
     video_request.mutable_user()->CopyFrom(request->user());
     video_request.set_return_num(200);
     video_request.set_reco_id(request->reco_id());
     video_request.set_strategy_type(0);
     video_request.mutable_uc_user_param()->CopyFrom(request->uc_user_param());
     video_request.set_channel_id(request->channel_id());
     video_request.mutable_shunt_tags()->CopyFrom(request->shunt_tags());
     video_request.mutable_user_info()->CopyFrom(user_info);

     std::string str_shunt_tags;
     for (auto i = 0; i < request->shunt_tags_size(); ++i) {
     str_shunt_tags += request->shunt_tags(i) + ",";
     }
     if (!str_shunt_tags.empty()) {
     VLOG(2) << "video shunt tags: " << request->reco_id()
             << ", " << request->user().user_id()
             << ", " << str_shunt_tags;
             }

             VideoCommunicator::RequestConfig config;
             config.method = VideoCommunicator::RequestSign;
             config.request_sign = video_request.user().user_id();
             config.timeout = FLAGS_video_server_timeout_per_communicate;
             config.total_timeout = FLAGS_video_server_total_timeout;
             config.retry_times = FLAGS_video_server_retry_times;

  // resp
  VideoCommunicator::ResponseCollection resp_collect;
  thread::BlockingVar<bool> rpc_complete;

  // rpc
  serving_base::Timer timer;
  timer.Start();
  COUNTERS_recommend__get_video_from_server_num.Increase(1);
  video_communicator_->RemoteCall(video_request,
  config,
  &resp_collect,
  NewCallback(&RpcCompleteCallback, &rpc_complete));
  rpc_complete.Take();
  COUNTERS_recommend__get_video_req_cost.Increase(timer.Stop() / 1000);

  if (!resp_collect.success) {
   *err_msg = "get video result fail.";
   COUNTERS_recommend__get_video_error_num.Increase(1);
   return;
   }

  // result
   *ret = false;
   video_response->Clear();

   for (auto i = 0u; i < resp_collect.responses->size(); ++i) {
   if (!(*ret) && resp_collect.responses->at(i) && resp_collect.responses->at(i)->success()) {
   *ret = true;
   video_response->CopyFrom(*(resp_collect.responses->at(i)));
   LOG(INFO) << "video comm ret, uid:" << request->user().user_id()
             << ", num:" << video_response->items_size();
             break;
             }

             LOG(ERROR) << "get video result null, reason:" << resp_collect.reasons->at(i);
             }

             if (!(*ret)) {
             LOG(WARNING) << "get video result fail.";
             COUNTERS_recommend__get_video_error_num.Increase(1);
             video_response->Clear();
             video_response->set_success(false);
             video_response->set_err_message("get video result fail");
return;
}
*/

VideoReco::SetVideoResponseToCache(*request, *video_response);
}
}
}
