#pragma once

#include <string>
#include <vector>

#include "serving_base/expiry_map/expiry_map.h"
#include "serving_base/rpc_communicator/remote_caller.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/reco_index/item_info.h"

namespace reco {
class NewsIndex;
namespace leafserver {
struct GlobalData;

// typedef serving_base::RemoteCaller<reco::leafserver::RecommendService::Stub,
//        reco::leafserver::DataFromVideoServerRequest,
//        reco::leafserver::DataFromVideoServerResponse> VideoCommunicator;

class VideoComm {
 public:
  explicit VideoComm(const reco::NewsIndex* news_index);
  ~VideoComm();

  void GetVideoResults(const reco::user::UserInfo& user_info,
                       const reco::leafserver::RecommendRequest* request,
                       reco::leafserver::DataFromVideoServerResponse* video_response,
                       bool* ret, std::string* err_msg);

  // 后面不同场景可以再加接口，总之都是给 user 返回视频 candidates
 private:
  // void Init();
  bool GetVideoCandidateCache(const std::string& key, std::string* value);

 private:
  GlobalData *global_data_;
  const reco::NewsIndex* news_index_;
  // VideoCommunicator* video_communicator_;
  static serving_base::ExpiryMap<std::string, std::string>* cache_;
};
}
}

