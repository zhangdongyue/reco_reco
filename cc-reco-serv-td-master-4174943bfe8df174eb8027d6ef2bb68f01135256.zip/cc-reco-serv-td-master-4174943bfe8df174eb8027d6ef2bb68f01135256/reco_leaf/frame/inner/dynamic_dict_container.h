#pragma once
#include <bitset>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "base/container/dense_hash_map.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/bizc/common/trie.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/xgboost_util.h"
#include "base/strings/string_printf.h"
#include "reco/ml/model/lr_model.h"

namespace reco {
namespace dm {

struct RecoReasonTagDict {
  // 推荐理由候选归一化 tag 映射到 展示标签
  std::unordered_map<std::string, std::string> reco_reason_tag_mapping;
  // 推荐理由候选归一化 tag 和对应类别
  std::unordered_map<std::string, std::unordered_set<std::string> > reco_reason_tag_category;
};
void LoadRecoReasonTagDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct SubscriptTagRelevenceDict {
  // 订阅标签对应的关联标签列表：单向和双向，list 是基于关联程度排好序的
  std::unordered_map<std::string, std::vector<std::string> > subscript_tag_relevence_oneway;
  std::unordered_map<std::string, std::vector<std::string> > subscript_tag_relevence_twoway;
  // 单个标签的关联标签
  std::unordered_map<std::string, std::vector<std::string> > subscript_tag_relevence_merged;
};
void LoadSubscriptTagRelevenceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct SourceMediaInfo {
  enum Level {
    kLevelNoRisk = 0,
    kLevelUnAuth,
    kLevelHostile,
    kLevelForbiden
  };

  Level level;
  reco::common::Trie cities;
};

struct SourceMediaDict {
  std::unordered_map<uint64_t, SourceMediaInfo> source_media_map_;
};
void LoadSourceMediaDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct CrowdOperItemInfo {
  std::string deliver_task_id;
  std::vector<uint64> item_ids;
};
struct CrowdOperDict {
  struct ItemMeta {
    int64_t timeout;
    std::string crowd;
  };
  base::dense_hash_map<uint64_t, ItemMeta> item_meta_dict_;
  base::dense_hash_map<uint64_t, CrowdOperItemInfo> crowd_oper_dict_;
};

struct RoughModel {
  reco::xgboost::XGboostModel xgboost_model_;
};

struct HotModel {
  reco::xgboost::XGboostModel xgboost_model_;
};

struct CateClickRatio {
  base::dense_hash_map<std::string, float> cate_clik_ratio_;
};

struct HotCateClickRatio {
  base::dense_hash_map<std::string, float> cate_clik_ratio_;
};

void LoadCrowdOperDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
void LoadRoughModel(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
void LoadHotModel(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
void LoadHotCateClickRatio(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
void LoadCateClickRatio(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

struct AppTokenCateBoostDict {
  std::unordered_map<std::string, double> app_token_cate_boost_dict_;
};
void LoadAppTokenCateBoostDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
// uc 大投放回传的 SID 对应的类别关键词信息
// 用于冷启动触发
struct UcSidInfo {
  std::string sid;
  std::string biz;
  std::string category;
  std::string keyword;

  std::string ToString() {
    return base::StringPrintf("sid[%s], biz[%s], cate[%s], kw[%s]",
                              sid.c_str(), biz.c_str(), category.c_str(), keyword.c_str());
  }
};
struct UcSidDict {
  std::unordered_map<std::string, UcSidInfo> uc_sid_dict_;
};
void LoadUcSidDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

// 机型信息词典
// 存储机型对应的品牌, 名称, 标签词等信息
struct DeviceInfo {
  std::string brand;
  std::string name;
  std::string tag;
};
struct DeviceInfoDict {
  std::unordered_map<std::string, DeviceInfo> device_info_dict_;
};
void LoadDeviceInfoDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

// iflow 排序词典
typedef std::unordered_map<uint64, int> IflowItemSortDict;
void LoadIflowItemSortDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

// 通过动态词典加载的 lr 模型
struct LrModel {
  reco::ml::DenseHashLRModel lr_model_;
};
void LoadTpCateLrModel(base::FilePath path, void* dict_address, bool* suc, int64* cnt);
void LoadTpItemLrModel(base::FilePath path, void* dict_address, bool* suc, int64* cnt);

}

namespace leafserver {

class DynamicDictContainer {
 public:
  DynamicDictContainer() {}
  ~DynamicDictContainer() {}
  static void RegisterAndLoadAllDict();
  static const char* kOtherMainCityFile_;
  static const char* kRecoReasonTagFile_;
  static const char* kSubscriptTagRelevenceFile_;
  // static const char* kSourceMediaFile_;
  static const char* kRoughModelFile_;
  static const char* kHotModelFile_;
  static const char* kCateClickRatioFile_;
  static const char* kHotCateClickRatioFile_;
  static const char* kAppTokenCateBoostFile_;
  static const char* kUcSidFile_;
  static const char* kDeviceInfoFile_;
  static const char* kCrowdOperExpFile_;
  static const char* kCrowdOperWholeFile_;
  static const char* kIflowItemSortFile_;
  static const char* kThirdPartyCategoryLrModelFile_;
  static const char* kThirdPartyItemLrModelFile_;
};
}
}
