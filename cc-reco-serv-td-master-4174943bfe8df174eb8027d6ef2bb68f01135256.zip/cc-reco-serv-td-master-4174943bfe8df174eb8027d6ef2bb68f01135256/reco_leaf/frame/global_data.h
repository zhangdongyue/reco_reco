#pragma once

#include <cstdatomic>
#include <string>
#include <deque>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#include "base/hash_function/city.h"
#include "base/container/dense_hash_set.h"
#include "base/container/dense_hash_map.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "base/common/logging.h"
#include "serving_base/rpc_communicator/remote_caller.h"
#include "serving_base/data_manager/data_manager.h"
#include "extend/static_dict/dawg/dictionary.h"

#include "reco/bizc/filter_dict/common_filter.h"
#include "reco/base/kafka_c/api_cc/producer.h"
#include "reco/serv/reco_model/frame/reco_model_predict.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/reco_index/file_monitor_mult.h"
#include "reco/bizc/user_lib/user_info.h"
#include "reco/ml/model/lr_model.h"
#include "reco/ml/model/model.h"

// declare
namespace adsindexing {
class Index;
}

namespace serving_base {
template<typename Controller, typename GlobalData>
class DataManager;
}

namespace VLDC {
class MultiStringVLDC;
}

namespace reco {

namespace filter {
class StreamFilterSignAsyncCalc;
class FilterMonster;
}

class NewsIndex;

namespace leafserver {

enum SysStatus {
  kSysFree = 1,
  kSysNormal = 2,
  kSysBusy = 3,
  kSysFull = 4,
  kSysDanger = 5,
  kSysMax,
};

class LeafController;
class RKGraph;
struct GlobalData;
class VideoComm;
class DmpCategoryMapping;

typedef serving_base::DataManager<LeafController, GlobalData> LeafDataManager;
typedef std::vector<std::pair<std::string, float> > CategoryDistributes;
typedef std::vector<std::pair<std::string, float> > KeywordDistributes;
typedef base::dense_hash_set<std::string> StageTag;
typedef base::dense_hash_map<std::string, StageTag> StageMap;

// dicts need to reload, manage them with |DictManager| in |LeafDataManager|
// static dicts, manage them with |GlobalData|
struct GlobalData : public MultFileMonitor<GlobalData> {
 public:
  GlobalData() {}
  explicit GlobalData(adsindexing::Index *ext_index, int work_thread_num);
  ~GlobalData();

  // 平响添加计数
  // void SysCounter(const double cost_us);

  // 获取 cpu 负载状态
  int GetCPUIdleStatus(const int last_status);

  // 是否是内部用户
  bool IsInnerUserId(uint64 user_id);

  // 获取 w2v 推荐结果
  void GetW2vRecoResult(const uint64 &item_id, std::string *proto_str);

  // 根据系统等级获取召回数量系数
  float GetSelectionRatio(void);

  // 根据系统等级获取并发线程数量
  int GetParallelNum(void);

  int GetSysLevel(void) {
    return sys_status_;
  }

 private:
  void InitNewsIndex();
  void loadDict();
  bool parseFeas(const std::string& fea_wt_str, std::vector<std::pair<std::string, float> >* feas);
  bool normalizeFeas(std::vector<std::pair<std::string, float> >* feas);
  void loadQudaoBlackSourceDict(const base::FilePath& base_dir);
  void loadQudaoCategoryDict(const base::FilePath& base_dir);
  void loadQueryBlackListDict(const base::FilePath& base_dir);
  void loadLifeStageTagsDict(const base::FilePath& base_dir);
  void LoadChannelNameDict(const base::FilePath& base_dir);
  void SystemMonitor();
  void LoadCategoryCf(const base::FilePath& base_dir);
  void LoadRecoReasonTagCategoryDict(const base::FilePath& file_path);
  void LoadSubscriptiTagRelevence(const base::FilePath& file_path);
  void LoadInnerUserIdList(const base::FilePath& base_dir);
  void LoadValidVideoTagDict(const base::FilePath& base_dir);
  void LoadSubscribedShowClickFile(const base::FilePath& file_path);
  void LoadHotTagsFile(const base::FilePath& file_path);
  // void loadTpCateLrModel(const base::FilePath& base_dir);
  // void loadTpItemLrModel(const base::FilePath& base_dir);
  void FetchW2vRecoResults();
 public:
  const adsindexing::Index* index;
  const reco::NewsIndex *news_index;
  bool is_ext_index;
  // channel 对应的 category 及 权重
  std::unordered_map<int64, CategoryDistributes> channel_categories;
  // channel 对应的名称
  std::unordered_map<int64, std::string> channel_name;
  // user_role 对应的 keyword 及 权重
  std::unordered_map<std::string, KeywordDistributes> user_role_keywords;
  // user_role 对应的 category 及 权重
  std::unordered_map<std::string, CategoryDistributes> user_role_categories;
  // app 对应的 category
  std::unordered_map<uint64, std::vector<std::string> > app_categories;
  // 分渠道的源黑名单
  // TODO(jianhuang) 后续在索引处考虑该需求
  std::unordered_map<std::string, std::unordered_set<std::string> > qudao_black_source_dict;
  // query 探索黑名单 (暂时在 leaf 里加载试一下效果)
  std::unordered_map<std::string, int> query_black_list_dict;
  // 阶段特征调权词典
  StageMap life_stage_tags_dict;
  // related keyword graph
  // RKGraph *rk_graph_;
  // dmp category mapping
  DmpCategoryMapping* dmp_category_mapping;

  // city id 和 name 的映射关系表
  std::unordered_map<std::string, std::string> city_id_name_map;

  // iflow 渠道对应类别配置
  std::unordered_map<std::string, std::unordered_set<std::string> > qudao_categories_dict;


  // video comm 无结果的 uid 集合
  serving_base::ExpiryMap<uint64, bool> *video_result_null_cache;
  // category cf 字典
  std::unordered_map<std::string, std::unordered_map<std::string, float> > category_cf_dict;

  serving_base::ExpiryMap<uint64, uint64>* ucnews_userid_cache;

  ::thread::ThreadPool *work_thread_pool;

  reco::redis::RedisCli *redis;

  reco::common::CommonFilter *common_filter;
/*
  // 推荐理由候选归一化 tag 和对应类别
  DynamicDict<std::unordered_map<std::string, std::unordered_set<std::string> > > reco_reason_tag_category;
  // 推荐理由候选归一化 tag 映射到 展示标签
  DynamicDict<std::unordered_map<std::string, std::string> > reco_reason_tag_mapping;


  // 订阅标签对应的关联标签列表：单向和双向，list 是基于关联程度排好序的
  DynamicDict<std::unordered_map<std::string, std::vector<std::string> > > subscript_tag_relevence_oneway;
  DynamicDict<std::unordered_map<std::string, std::vector<std::string> > > subscript_tag_relevence_twoway;
  // 单个标签的关联标签
  DynamicDict<std::unordered_map<std::string, std::vector<std::string> > > subscript_tag_relevence_merged;
*/
  std::unordered_set<std::string> valid_video_tag_;
  // 已订阅标签的展现点击词典
  std::unordered_map<std::string, std::pair<uint32_t, double> > subscribed_show_click_dict_;
  // 热点标签，用于我的频道
  DynamicDict<std::unordered_set<std::string> > hot_tags_;

  // 基于第三方数据的类型预测 LR 模型
  // reco::ml::DenseHashLRModel* tp_cate_lr_model_;

  // 基于第三方数据的 item 预测 LR 模型
  // reco::ml::DenseHashLRModel* tp_item_lr_model_;

  // 记录用户访问历史
  reco::kafka::Producer* user_trace_producer;

  // query 探索历史
  reco::kafka::Producer* query_probe_producer;

  reco::common::UserComm* user_comm;
  VideoComm *video_comm;

  reco::filter::FilterMonster* filter_monster;
  reco::filter::StreamFilterSignAsyncCalc* stream_filter;

 private:
  void PackKeyDict(const base::FilePath& path, dawgdic::Dictionary* dict);

  static const char* kChannelCategoryFile;
  static const char* kUserRoleKeywordFile;
  static const char* kUserRoleCategoryFile;
  static const char* kAppCategoryFile;
  static const char* kRegionDictFile;
  static const char* kCityIdNameMapFile;
  static const char* kIflowCategoryConfFile;
  static const char* kLifeStageTagsDictFile;
  static const char* kQudaoBlackSourceDictFile;
  static const char* kQueryBlackListDictFile;
  static const char* kChannelNameFile;
/*
  // 可以作为推荐理由的 tag
  static const char* kRecoReasonTagFile;
  // 订阅标签对应的关联标签
  static const char* kSubscriptTagRelevenceFile;
*/
  // r
  // 内部用户 ID 列表文件
  static const char* kInnerUserIdListFile;
  // 视频 valid tag
  static const char* kValidVideoTagFile;
  // 内部用户列表
  std::unordered_set<uint64> inner_user_ids;
  // 已订阅标签展现点击信息
  static const char* kSubscribedShowClickFile;
  // 热门标签, 用于我的频道管理页展现
  static const char* kHotTagsFile;
  // 第三方数据类别预测 LR 模型文件
  // static const char* kThirdPartyCategoryLrModelFile;
  // 第三方数据 item 预测 LR 模型文件
  // static const char* kThirdPartyItemLrModelFile;

  // 系统负载检测线程
  std::atomic<int> cpu_idle_;
  bool thread_quit_;
  thread::Thread system_monitor_thread_;
  // std::atomic<int> resp_time_status_;

  // 异步获取 w2v 结果
  serving_base::ExpiryMap<uint64, std::string>* w2v_cache_;
  thread::BlockingQueue<uint64> *w2v_fetch_queue_;
  thread::Thread w2v_fetch_thread_;
  std::atomic<int> sys_status_;
};
}  // end of
}  // end of namespace reco
