#pragma once

#include <string>
#include <vector>

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/reco_nlp_server.pb.h"
// #include "reco/bizc/proto/user_search.pb.h"
#include "base/strings/string_printf.h"
#include "serving_base/utility/timer.h"

namespace reco {
namespace leafserver {

struct CostTrace {
  int64 ts;  // total cost
  int64 us;  // user info cost
  int64 ins;  // 初始化请求包
  int64 ss;  // 策略耗时
  int64 outs;  // 打包返回包耗时
  int64 pps;  // 构建推荐 request
  int64 mans;  // manual reco
  int64 hrs;  // hot reco
  int64 qrs; // query reco
  int64 hvrs;  // hot video reco
  int64 poirs;  // poi reco
  int64 prs;  // personal reco
  int64 pbs;  // probe reco
  int64 srs;  // search reco
  int64 ims;  // im card reco
  int64 scs;  // scene card reco
  int64 hcs;  // hot card reco
  int64 mrs;  // merge reco result
  int64 rsbs;  // 计算各个策略分支的展现概率
  int64 ccs;  // cache 过程耗时
  int64 cfs;  // 生成 CF dict
  int64 rks;  // 个性化推荐
  int64 mcs;  // merge category cost
  int64 cvs;  // call video server cost
  int64 crt;  // category reco threadnum
  int64 brict;  // basic reco in category time
  int64 hrict;  // head reco in category time
  int64 rict;   // reco in category total time
  int64 cos;  // crowd oper reco
  int64 lbs;  // local breaking reco
  int64 gds;  // guarantee deliver cost
  int64 ses;  // session reco
  int64 rels; // push relate strategy
  int64 tprs; // third party reco
  int64 ucsids; // uc sid reco

  std::string ToString() {
    return base::StringPrintf("(ts:%jd,us:%jd,ins:%jd,ss:%jd,outs:%jd,mans:%jd,hrs:%jd,qrs:%jd,"
                              "hvrs:%jd,prs:%jd,pbs:%jd,srs:%jd,mrs:%jd,pps:%jd,ccs:%jd,"
                              "cfs:%jd,rsbs:%jd,rks:%jd,mcs:%jd,poirs:%jd,scs:%jd,cvs:%jd,"
                              "crt:%jd,brict:%jd,hrict:%jd,rict:%jd,cos:%jd,lbs:%jd,gds:%jd,"
                              "ses:%jd,rels:%jd,tprs:%jd,ucsids:%jd)",
                              ts, us, ins, ss, outs, mans, hrs, qrs,
                              hvrs, prs, pbs, srs, mrs, pps, ccs,
                              cfs, rsbs, rks, mcs, poirs, scs, cvs,
                              crt, brict, hrict, rict, cos, lbs, gds,
                              ses, rels, tprs, ucsids);
  }
};

// declare
class UserCommunication;
class RankHooker;
struct GlobalData;
class TagReco;
class ExternalApi;

class LeafController {
 public:
  explicit LeafController();
  ~LeafController();

  bool Recommend(const bool is_demote,
                 const RecommendRequest *request,
                 RecommendResponse *response);

  // 获取热门新闻接口
  bool GetHotNews(const GetHotNewsRequest* request,
                  GetHotNewsResponse* response);

  // 垂直类目的检索
  bool VerticalRecommend(const VerticalRequest *request,
                         VerticalResponse *response);

  bool GetModelVersion(const ModelVerRequest *request,
                       ModelVerResponse *response);

  bool SetModelVersion(const ModelVerRequest *request,
                       ModelVerResponse *response);

  bool WeMediaRecommend(const bool is_demote,
                        const WeMediaRecommendRequest *request,
                        WeMediaRecommendResponse *response);

  bool ImCardRecommend(const bool is_demote,
                       const ImCardRecoRequest *request,
                       ImCardRecoResponse *response);

  bool SceneCardRecommend(const bool is_demote,
                          const SceneCardRecoRequest *request,
                          SceneCardRecoResponse *response);

  bool HotCardRecommend(const bool is_demote,
                        const HotCardRecommendRequest *request,
                        HotCardRecommendResponse *response);

  bool GetNewsMap(const NewsMapRequest *request,
                  NewsMapResponse *response);

  bool GetIndexStatus(const GetIndexStatusRequest& request,
                      GetIndexStatusResponse* response);

  bool GetIndexQueue(const GetIndexQueueRequest& request,
                     GetIndexQueueResponse* response);

  bool GetIndexQueueUnsort(const GetIndexQueueUnsortRequest& request,
                     GetIndexQueueUnsortResponse* response);


  bool GetIndexItemInfo(const GetIndexItemInfoRequest& request,
                        GetIndexItemInfoResponse* response);

  bool TagRecommend(const TagRecommendRequest &request,
                    TagRecommendResponse *response);
 private:
  void SetUserInfoToResponse(const RecommendRequest *request,
                             const reco::user::UserInfo& user_info,
                             RecommendResponse *response);

  void LeafRecommend(const bool user_valid,
                     reco::user::UserInfo* user_info,
                     const RecommendRequest *request,
                     RecommendResponse *response,
                     thread::Thread *video_thread);

  void VideoRecommend(reco::user::UserInfo* user_info,
                      RecommendRequest* request,
                      DataFromVideoServerResponse* video_response);

  void GetUserInfo(const bool is_demote,
                   const RecommendRequest* request,
                   reco::user::UserInfo* user_info,
                   RecommendResponse *response,
                   bool* user_valid);

 private:
  RankHooker* ranker_;
  ExternalApi* external_api_;
  ::serving_base::Timer timer_;
  GlobalData* global_data_;
  CostTrace cost_trace_;
  TagReco* tag_reco_;
  std::string video_hostname_;
};
}  // namespace leafserver
}  // namespace reco
