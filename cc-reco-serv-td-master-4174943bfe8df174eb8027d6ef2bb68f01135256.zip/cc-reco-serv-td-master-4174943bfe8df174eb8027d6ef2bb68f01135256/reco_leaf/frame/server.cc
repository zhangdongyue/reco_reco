#include "base/common/base.h"
#include "base/thread/thread.h"
#include "net/counter/export.h"
#include "serving_base/data_manager/data_manager.h"
#include "serving_base/data_manager/heart_beat_server.h"
#include "serving_base/data_manager/server_frame.h"
#include "serving_base/utility/signal.h"

#include "reco/serv/reco_leaf/frame/leaf_impl.h"
#include "reco/base/dict_manager/reload_service_impl.h"
#include "reco/bizc/index_monitor/api/index_monitor.h"
#include "reco/bizc/news_map/strategy/news_map_strategy.h"
#include "reco/bizc/poi/city_area_hash_dict.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/frame/connection_manager.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"
#include "reco/serv/reco_leaf/strategy/rank_hooker.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/model_inner/model_buffer_manager.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/fm_inner/fm_buffer_manager.h"
// #include "reco/serv/reco_leaf/strategy/reco/offline/cf_item_dict.h"
#include "reco/serv/dict_server/api/dict_server_api.h"
#include "reco/ml/model_server/api/model_server_api.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/wd_predictor.h"

DEFINE_int32(port, 17911, "the port on which the serving application listens");
DEFINE_int32(rpc_thread_num, 1, "rpc thread num");
DEFINE_int32(work_thread_num, 10, "work thread num");
DEFINE_bool(load_fac_machine_model, false, "是否加载fac machine模型");

DECLARE_int32(dict_reload_port);
DECLARE_int32(heart_beat_port);

// DECLARE_string(message_queue_servers);
// DECLARE_string(reco_leaf_data_dir);

namespace reco {
namespace leafserver {
// DECLARE_bool(fm_score_on);
DECLARE_string(leaf_data_dir);
}
}

/*
void LoadLRModel() {
  LOG(INFO) << "begin to load lr batch model.";
  CHECK(reco::reco_model::RecoModelProc::Instance()->Initialize()) << "reco model init failed";
  LOG(INFO) << "succ to load lr batch model!";
}

void LoadBuffModel() {
  LOG(INFO) << "begin to load buff model.";
  reco::leafserver::ModelBufMgr::instance().Init();
  LOG(INFO) << "succ to load buff model!";
}

void LoadFacMachineModel() {
  LOG(INFO) << "begin to load fm model.";
  reco::leafserver::FacMachineBufMgr::instance().Init();
  LOG(INFO) << "succ to load fm model!";
}
*/

void LoadPOIData() {
  LOG(INFO) << "begin to load poi data.";
  CHECK(reco::poi::CityAreaHashSearcher::instance().Load(reco::leafserver::FLAGS_leaf_data_dir));
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "the intermediate node of serving");

  net::counter::HttpCounterExport();

  /*
  // lr 加载模型
  thread::Thread load_lr_model_thread;
  load_lr_model_thread.Start(NewCallback(&LoadLRModel));
  */

  // 加载 poi 数据
  thread::Thread load_poi_data_thread;
  load_poi_data_thread.Start(NewCallback(&LoadPOIData));

  // model server api
  if (FLAGS_open_model_server_wd) {
    reco::model_server::ModelServerAPIIns::instance().Init();
  }

  CHECK(reco::leafserver::ConnectionManagerIns::instance().InitConnection()) << "Initialize Connection error";
  reco::dictserver::DictServerAPIIns::instance().Init();

  // index monitor
  reco::index_monitor::IndexMonitor index_monitor;
  index_monitor.Start();
  LOG(INFO) << "index monitor start";

  // global data
  reco::leafserver::GlobalData global_data(index_monitor.GetIndex(), FLAGS_work_thread_num);
  serving_base::DataManangerConfig config;
  config.controller_item_num = FLAGS_work_thread_num;
  reco::leafserver::LeafDataManager::Initialize(config, &global_data);
  LOG(INFO) << "LeafDataManager start";

  load_poi_data_thread.Join();

  /*
  // mf 加载模型(rely on global_data so must be after it!!!!)
  thread::Thread load_mf_model_thread;
  load_mf_model_thread.Start(NewCallback(&LoadBuffModel));

  // fac machine 加载模型
  thread::Thread load_fac_machine_model_thread;
  if (FLAGS_load_fac_machine_model) {
    load_fac_machine_model_thread.Start(NewCallback(&LoadFacMachineModel));
  }
  */

  // 开启 CF 词典加载线程
  // reco::leafserver::CFItemDict::StartFillCacheThread();

  // 新闻地图加载
  reco::news_map::NewsMapProc::instance().Start(global_data.news_index);

  /*
  // 等待 lr model 和 mf model, fac_machine model 加载线程完成
  load_lr_model_thread.Join();
  load_mf_model_thread.Join();
  if (FLAGS_load_fac_machine_model) {
    load_fac_machine_model_thread.Join();
  }
  */

  LOG(INFO) << "async thread start succ.";

  reco::leafserver::LeafImpl service;
  reco::dm::ReloadServiceImpl reload_service;
  net::rpc::RpcServer::Options opt;
  opt.server_thread_num = FLAGS_rpc_thread_num;
  opt.pump_thread_num = 4;
  opt.port = FLAGS_port;
  net::rpc::RpcServer server(opt);
  CHECK(server.ExportService(&service));
  CHECK(server.ExportService(&reload_service));
  server.Start();

  serving_base::HeartBeatServer* hb_server = NULL;
  if (FLAGS_heart_beat_port > 0) {
    hb_server = new serving_base::HeartBeatServer(FLAGS_heart_beat_port);
    hb_server->Start();
  }

  LOG(INFO) << "leaf server start";
  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();

  // stop process
  server.Stop();
  if (hb_server) {
    hb_server->Stop();
    delete hb_server;
    hb_server = NULL;
  }
  LOG(INFO) << "leaf server stop";

  // 停止 CF 词典加载线程
  // reco::leafserver::CFItemDict::StopFillCacheThread();

  // 停止新闻地图更新线程
  reco::news_map::NewsMapProc::instance().Stop();

  reco::leafserver::LeafDataManager::Release();
  LOG(INFO) << "data manager release";

  std::cout << "leaf server safe quit" << std::endl;
  return 0;
}
