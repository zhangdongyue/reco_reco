#include "reco/serv/reco_leaf/frame/connection_manager.h"

#include <string>
#include <utility>
#include <vector>

#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "net/rpc_util/rpc_group.h"

DEFINE_string(nlp_server_ips, "11.251.203.136", "nlp server ips, by ','");
DEFINE_int32(nlp_server_port, 20008, "nlp server server port");
DEFINE_int32(nlp_server_timeout, 200, "nlp server rpc timeout in ms");
DEFINE_int32(nlp_server_retry_times, 2, "nlp server rpc retry times");

namespace reco {
namespace leafserver {

net::rpc::RpcGroup* SetupConnection(const std::vector<std::string>& ips, int port,
                                           int timeout, int retry) {
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = retry;
  options.timeout = timeout;
  for (int i = 0; i < (int)ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], port, timeout);
    options.servers.push_back(si);
  }

  auto group = new net::rpc::RpcGroup(options);
  CHECK(group->Connect());
  return group;
}

bool ConnectionManager::InitConnection() {
  std::vector<std::string> flds;
  base::SplitString(FLAGS_nlp_server_ips, ",", &flds);
  nlp_rpc_group_ = SetupConnection(flds, FLAGS_nlp_server_port,
                                   FLAGS_nlp_server_timeout, FLAGS_nlp_server_retry_times);

  return true;
}

void ConnectionManager::CleanConnection() {
  delete nlp_rpc_group_;
}
}  // namespace leafserver
}  // namespace reco
