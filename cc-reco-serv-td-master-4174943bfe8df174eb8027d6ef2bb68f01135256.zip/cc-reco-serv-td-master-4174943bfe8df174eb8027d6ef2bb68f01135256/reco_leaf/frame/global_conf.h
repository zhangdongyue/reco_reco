#pragma once
#include <string>

#include "base/thread/thread.h"
#include "base/thread/sync.h"
#include "base/common/logging.h"

namespace reco {
namespace leafserver {

// leaf server 服务级别
enum LeafServiceLevel {
  // 0：正常服务
  kNormalService = 0,
  // 1：降一级服务: 无个性化, 默认排序
  kNoPersonalService = 1,
  // 2：降二极服务: 无个性化，无排重，随机结果
  kNoDedupService = 2,
};

// static global conf
struct GlobalConf {
 public:
  // 重载一个配置项，该配置项全局有效
  // conf field 和 conf value 需要双方进行协商
  static bool ReloadConf(const std::string& conf_field, const std::string& conf_value);

  static LeafServiceLevel GetServiceLevel() {
    return service_level_;
  }

 private:
  GlobalConf() {}
  ~GlobalConf() {}

  static bool ParseServiceLevel(const std::string& value, LeafServiceLevel* service_level);

 private:
  static const char* kServiceLevelField;

  static thread::Mutex mutex_;
  // leaf server 服务级别
  static LeafServiceLevel service_level_;
};

}  // end of namespace leafserver
}  // end of namespace reco
