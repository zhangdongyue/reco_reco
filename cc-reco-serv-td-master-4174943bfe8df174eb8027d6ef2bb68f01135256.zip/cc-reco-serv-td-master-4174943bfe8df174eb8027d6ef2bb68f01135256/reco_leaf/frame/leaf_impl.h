#pragma once

#include <string>

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "serving_base/utility/system_util.h"

namespace reco {
namespace leafserver {

enum ReqType {
  kInvalidReq = 0,
  kRecommendReq,
  kGetHotNewsReq,
  kVerticalRecommend,
  kWemediaRecommend,
  kImCardRecommend,
  kNewsMapRecommend,
  kSceneCardRecommend,
  kHotCardRecommend,
  kGetIndexItemInfo,
  kGetIndexStatus,
  kGetIndexQueue,
  kGetIndexQueueUnsort,
  kTagRecommend,
  kSetCommandLineOption,
};

struct StWorkParam {
  const ::google::protobuf::Message* request;
  ::google::protobuf::Message* response;
  ::Closure* done;
  int64 time_stamp;
  ReqType type;

  StWorkParam() : request(NULL), response(NULL), done(NULL), time_stamp(0), type(kInvalidReq) {}

  StWorkParam(const ::google::protobuf::Message *req, ::google::protobuf::Message *resp,
              ::Closure *closure_done, const int64 stamp, const ReqType req_type) {
    request = req;
    response = resp;
    done = closure_done;
    time_stamp = stamp;
    type = req_type;
  }
};

class LeafImpl : public RecommendService {
 public:
  LeafImpl();
  virtual ~LeafImpl();

  // 推荐系统 api
  virtual void recommend(stumy::RpcController* controller,
                         const RecommendRequest* request,
                         RecommendResponse* response,
                         Closure* done);

  // reload 字典
  virtual void reloadDict(stumy::RpcController* controller,
                          const ReloadDictRequest* request,
                          ReloadDictResponse* response,
                          Closure* done);

  virtual void reloadLeafConf(stumy::RpcController* controller,
                              const ReloadLeafConfRequest* request,
                              ReloadLeafConfResponse* response,
                              Closure* done);

  // 检查索引
  virtual void checkIndex(stumy::RpcController* controller,
                          const CheckIndexRequest* request,
                          CheckIndexResponse* response,
                          Closure* done);

  // 热门新闻获取接口
  virtual void getHotNews(stumy::RpcController* controller,
                          const GetHotNewsRequest* request,
                          GetHotNewsResponse* response,
                          Closure* done);

  virtual void verticalRecommend(stumy::RpcController* controller,
                                 const VerticalRequest* request,
                                 VerticalResponse* response,
                                 Closure* done);

  virtual void getModelVersion(stumy::RpcController* controller,
                               const ModelVerRequest* request,
                               ModelVerResponse* response,
                               Closure* done);

  virtual void setModelVersion(stumy::RpcController* controller,
                               const ModelVerRequest* request,
                               ModelVerResponse* response,
                               Closure* done);

  // 自媒体人推荐
  virtual void wemediaRecommend(stumy::RpcController* controller,
                                const reco::leafserver::WeMediaRecommendRequest* request,
                                reco::leafserver::WeMediaRecommendResponse* response,
                                Closure* done);
  // im 卡片推荐
  virtual void imCardRecommend(stumy::RpcController* controller,
                               const reco::leafserver::ImCardRecoRequest* request,
                               reco::leafserver::ImCardRecoResponse* response,
                               Closure* done);
  // 场景化 卡片推荐
  virtual void sceneCardRecommend(stumy::RpcController* controller,
                                  const reco::leafserver::SceneCardRecoRequest* request,
                                  reco::leafserver::SceneCardRecoResponse* response,
                                  Closure* done);

  // 热点 卡片推荐
  virtual void hotCardRecommend(stumy::RpcController* controller,
                                  const reco::leafserver::HotCardRecommendRequest* request,
                                  reco::leafserver::HotCardRecommendResponse* response,
                                  Closure* done);

  // 获取索引里面的 item 信息
  virtual void getIndexItemInfo(stumy::RpcController* controller,
                                const GetIndexItemInfoRequest* request,
                                GetIndexItemInfoResponse* response,
                                Closure* done);

  // 新闻地图相关的接口
  virtual void getNewsMap(stumy::RpcController* controller,
                          const reco::leafserver::NewsMapRequest* request,
                          reco::leafserver::NewsMapResponse* response,
                          Closure* done);

  // 获取当前索引状态接口
  virtual void getIndexStatus(stumy::RpcController* controller,
                              const reco::leafserver::GetIndexStatusRequest* request,
                              reco::leafserver::GetIndexStatusResponse* response,
                              Closure* done);

  // 获取索引下的文章列表
  virtual void getIndexQueue(stumy::RpcController* controller,
                             const reco::leafserver::GetIndexQueueRequest* request,
                             reco::leafserver::GetIndexQueueResponse* response,
                             Closure* done);

  // 获取索引下的未经过 sortItem 处理的文章列表
  virtual void getIndexQueueUnsort(stumy::RpcController* controller,
                             const
                             reco::leafserver::GetIndexQueueUnsortRequest* request,
                             reco::leafserver::GetIndexQueueUnsortResponse* response,
                             Closure* done);

  // 获取关联标签
  virtual void tagRecommend(stumy::RpcController* controller,
                            const reco::leafserver::TagRecommendRequest* request,
                            reco::leafserver::TagRecommendResponse* response,
                            Closure* done);

  // 实验使用：参数动态修改
  virtual void setCommandLineOption(stumy::RpcController* controller,
                            const reco::leafserver::SetCommandLineOptionRequest* request,
                            reco::leafserver::SetCommandLineOptionResponse* response,
                            Closure* done);
 private:
  void Process(StWorkParam param);

  void recommend(const int64 timestamp,
                 const RecommendRequest* request,
                 RecommendResponse* response,
                 Closure* done);

  void getHotNews(const int64 timestamp,
                  const GetHotNewsRequest* request,
                  GetHotNewsResponse* response,
                  Closure* done);

  void verticalRecommend(const int64 timestamp,
                         const VerticalRequest* request,
                         VerticalResponse* response,
                         Closure* done);

  void wemediaRecommend(const int64 timestamp,
                        const reco::leafserver::WeMediaRecommendRequest* request,
                        reco::leafserver::WeMediaRecommendResponse* response,
                        Closure* done);

  void imCardRecommend(const int64 timestamp,
                       const reco::leafserver::ImCardRecoRequest* request,
                       reco::leafserver::ImCardRecoResponse* response,
                       Closure* done);

  void getNewsMap(const int64 timestamp,
                  const reco::leafserver::NewsMapRequest* request,
                  reco::leafserver::NewsMapResponse* response,
                  Closure* done);

  void sceneCardRecommend(const int64 timestamp,
                          const reco::leafserver::SceneCardRecoRequest* request,
                          reco::leafserver::SceneCardRecoResponse* response,
                          Closure* done);

  void hotCardRecommend(const int64 timestamp,
                          const reco::leafserver::HotCardRecommendRequest* request,
                          reco::leafserver::HotCardRecommendResponse* response,
                          Closure* done);

  void getIndexItemInfo(const int64 timestamp,
                        const GetIndexItemInfoRequest* request,
                        GetIndexItemInfoResponse* response,
                        Closure* done);

  void getIndexStatus(const int64 timestamp,
                      const reco::leafserver::GetIndexStatusRequest* request,
                      reco::leafserver::GetIndexStatusResponse* response,
                      Closure* done);

  void getIndexQueue(const int64 timestamp,
                     const reco::leafserver::GetIndexQueueRequest* request,
                     reco::leafserver::GetIndexQueueResponse* response,
                     Closure* done);

  void getIndexQueueUnsort(const int64 timestamp,
                     const reco::leafserver::GetIndexQueueUnsortRequest* request,
                     reco::leafserver::GetIndexQueueUnsortResponse* response,
                     Closure* done);


  void tagRecommend(const int64 timestamp,
                    const reco::leafserver::TagRecommendRequest* request,
                    reco::leafserver::TagRecommendResponse* response,
                    Closure* done);

  void setCommandLineOption(const int64 timestamp,
                            const reco::leafserver::SetCommandLineOptionRequest* request,
                            reco::leafserver::SetCommandLineOptionResponse* response,
                            Closure* done);
 private:
  std::string hostname_;
  thread::Mutex mutex_;
};
}  // namespace leafserver
}  // namespace reco
