#pragma once

#include <string>
#include <vector>

#include "net/rpc/rpc.h"
#include "reco/base/common/singleton.h"

namespace net {
namespace rpc {
class RpcGroup;
}  // namespace rpc
}  // namespace net
namespace rpc {
namespace redis {
class ClientPool;
}
}

namespace reco {
namespace leafserver {

class ConnectionManager;
typedef reco::common::singleton_default<ConnectionManager> ConnectionManagerIns;

class ConnectionManager {
 public:
  ConnectionManager() {}
  ~ConnectionManager() {}

  bool InitConnection();
  void CleanConnection();

  net::rpc::RpcGroup* GetNlpServerGroup() {
    return nlp_rpc_group_;
  }

 private:
  net::rpc::RpcGroup* nlp_rpc_group_;
};
}  // end of namespace reco_leaf
}
