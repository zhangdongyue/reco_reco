#include <iostream>
#include <fstream>
#include <unordered_map>

#include "base/common/base.h"
#include "base/thread/thread.h"
#include "base/strings/string_split.h"
#include "serving_base/data_manager/server_frame.h"
#include "serving_base/data_manager/data_manager.h"
#include "serving_base/utility/signal.h"

#include "net/counter/export.h"
#include "reco/bizc/index_monitor/api/index_monitor.h"
#include "reco/serv/reco_leaf/frame/leaf_impl.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/frame/connection_manager.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"
#include "reco/serv/reco_leaf/strategy/rank_hooker.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/model_inner/model_buffer_manager.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/fm_inner/fm_buffer_manager.h"
// #include "reco/serv/reco_leaf/strategy/reco/offline/cf_item_dict.h"
#include "reco/serv/dict_server/api/dict_server_api.h"
#include "reco/bizc/poi/city_area_hash_dict.h"
#include "reco/bizc/news_map/strategy/news_map_strategy.h"

#include "reco/serv/reco_leaf/strategy/search/leaf_searcher.h"
#include "reco/serv/reco_leaf/strategy/search/structured_searcher.h"
#include "reco/serv/reco_leaf/strategy/search/tag_searcher.h"

DEFINE_string(result_file, "", "the output file");
DEFINE_string(input, "", "input file");
DEFINE_int32(result_num, 5, "result num for each query");

DEFINE_int32(port, 17911, "the port on which the serving application listens");
DEFINE_int32(rpc_thread_num, 1, "rpc thread num");
DEFINE_int32(work_thread_num, 1, "work thread num");

DEFINE_int32(search_mode, 1, "1: general, 2: structured, 3: tag");
DEFINE_bool(add_shown_list, false, "search result add to user shown list");
DEFINE_string(media_list, "", "white media in structured search");
DEFINE_string(category_list_l1, "", "white level1 category");
DEFINE_string(category_list_l2, "", "white level2 category");

DECLARE_int32(dict_reload_port);
DECLARE_int32(heart_beat_port);

DECLARE_string(message_queue_servers);
DECLARE_string(reco_leaf_data_dir);

// DEFINE_string(and_words, "", "and words, splitted by ','");
// DEFINE_string(or_words, "", "or words, splitted by ','");
// DEFINE_string(not_words, "", "not words, splitted by ','");


namespace reco {
namespace leafserver {
// DECLARE_bool(fm_score_on);
DECLARE_string(leaf_data_dir);
}
}

void LoadPOIData() {
  LOG(INFO) << "begin to load poi data.";
  CHECK(reco::poi::CityAreaHashSearcher::instance().Load(reco::leafserver::FLAGS_leaf_data_dir));
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "the intermediate node of serving");

  reco::dictserver::DictServerAPIIns::instance().Init();

  // 加载 poi 数据
  thread::Thread load_poi_data_thread;
  load_poi_data_thread.Start(NewCallback(&LoadPOIData));

  // user server
  CHECK(reco::leafserver::ConnectionManagerIns::instance().InitConnection()) << "Initialize Connection error";

  // index monitor
  reco::index_monitor::IndexMonitor index_monitor;
  index_monitor.Start();
  LOG(INFO) << "index monitor start";

  load_poi_data_thread.Join();

  // global data
  reco::leafserver::GlobalData global_data(index_monitor.GetIndex(), FLAGS_work_thread_num);

  serving_base::DataManangerConfig config;
  config.controller_item_num = 1;
  reco::leafserver::LeafDataManager::Initialize(config, &global_data);
  LOG(INFO) << "LeafDataManager start";

  // 新闻地图加载
  reco::news_map::NewsMapProc::instance().Start(global_data.news_index);

  LOG(INFO) << "async thread start succ.";

  std::istream* in = &std::cin;
  if (FLAGS_input.size() > 0) {
    in = new std::ifstream(FLAGS_input.c_str());
  }

  reco::leafserver::RecoRequest reco_request;
  reco::leafserver::RecommendRequest request;
  reco::user::UserInfo user_info;
  user_info.mutable_identity()->set_app_token("uc-iflow");
  user_info.mutable_identity()->set_user_id(1);
  user_info.mutable_identity()->set_outer_id("1");

  reco::leafserver::UserFeature user_feas;
  base::dense_hash_set<uint64> shown_dict;
  shown_dict.set_empty_key(0);
  reco::leafserver::UserCategoryDistributes distributes;
  reco_request.Reset(&request, &user_info, &user_feas, &shown_dict, &distributes);

  const reco::NewsIndex *news_index = global_data.news_index;
  reco::leafserver::LeafSearcher leaf_searcher(news_index);
  reco::leafserver::StructuredSearcher structured_searcher(news_index);
  reco::leafserver::TagSearcher tag_searcher(news_index);

  std::string line;
  // std::vector<std::string> and_words;
  // std::vector<std::string> or_words;
  // std::vector<std::string> not_words;
  std::vector<std::string> medias;
  base::SplitString(FLAGS_media_list, ",", &medias);

  std::vector<std::string> title_unigrams;
  std::vector<reco::ItemInfo> item_list;
  std::cout << "leaf search tool start, wait for input" << std::endl;
  while (std::getline(*in, line)) {
    item_list.clear();
    if (FLAGS_search_mode == 1) {
      reco::leafserver::BaseSearcher::Config config("test");
      config.return_num = FLAGS_result_num;
      config.ir_num = 1000;
      config.use_cache = false;
      reco::leafserver::LeafSearcher::DebugInfo debug_info;
      leaf_searcher.Search(&reco_request, line, config, &item_list, &debug_info);
      std::cout << "search " << line
                << " returns " << item_list.size() << " results, "
                << " debug_info: " << debug_info.ToString() << std::endl;
    } else if (FLAGS_search_mode == 2) {
      reco::leafserver::BaseSearcher::Config config("test");
      config.return_num = FLAGS_result_num;
      config.ir_num = 5000;
      config.use_cache = false;
      config.timelevel_threshold = reco::kBadTimeliness;
      config.title_all_hit = true;
      config.white_media_dict.insert(medias.begin(), medias.end());
      reco::leafserver::BaseSearcher::DebugInfo debug_info;
      structured_searcher.Search(&reco_request, line, config, &item_list, &debug_info);
      std::cout << "search " << line
                << " returns " << item_list.size() << " results, "
                << " debug_info: " << debug_info.ToString() << std::endl;
    } else if (FLAGS_search_mode == 3) {
      reco::leafserver::BaseSearcher::Config config("test");
      config.return_num = FLAGS_result_num;
      config.ir_num = 5000;
      config.use_cache = false;
      config.timelevel_threshold = reco::kBadTimeliness;
      config.title_all_hit = true;
      config.white_media_dict.insert(medias.begin(), medias.end());
      reco::leafserver::BaseSearcher::DebugInfo debug_info;
      tag_searcher.Search(&reco_request, line, config, &item_list, &debug_info);
      std::cout << "search " << line
                << " returns " << item_list.size() << " results, "
                << " debug_info: " << debug_info.ToString() << std::endl;
    }

    for (size_t i = 0; i < item_list.size(); ++i) {
      // 模拟用户请求加入 shown history
      if (FLAGS_add_shown_list) {
        shown_dict.insert(item_list[i].item_id);
      }

      std::string title;
      title_unigrams.clear();
      if (!news_index->GetAreaUnigramsByDocId(item_list[i].doc_id,
                                              adsindexing::kTitleArea, &title_unigrams)) {
        LOG(ERROR) << "cannot find title for item: " << item_list[i].item_id;
        continue;
      }

      title.clear();
      base::FastJoinStrings(title_unigrams, "", &title);
      std::cout << base::StringPrintf("%lu:%s:%.3f",
                                      item_list[i].item_id,
                                      title.c_str(),
                                      item_list[i].ctr) << std::endl;
    }
  }

  // 停止新闻地图更新线程
  reco::news_map::NewsMapProc::instance().Stop();

  reco::leafserver::LeafDataManager::Release();
  LOG(INFO) << "data manager release";

  std::cout << "leaf server safe quit" << std::endl;
  return 0;
}

