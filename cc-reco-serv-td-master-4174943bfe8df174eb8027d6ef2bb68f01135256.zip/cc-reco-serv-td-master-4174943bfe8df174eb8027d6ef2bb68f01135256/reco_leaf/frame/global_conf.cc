#include <string>
#include "reco/serv/reco_leaf/frame/global_conf.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace leafserver {

const char* GlobalConf::kServiceLevelField = "service_level";

LeafServiceLevel GlobalConf::service_level_  = kNormalService;
thread::Mutex    GlobalConf::mutex_;

bool GlobalConf::ReloadConf(const std::string& conf_field, const std::string& conf_value) {
  thread::AutoLock auto_lock(&mutex_);

  if (conf_field == kServiceLevelField) {
    LeafServiceLevel level;
    if (!ParseServiceLevel(conf_value, &level)) {
      LOG(WARNING) << "reload conf fail, conf_field: " << conf_field << ", conf_value: " << conf_value;
      return false;
    }
    service_level_ = level;
    LOG(INFO) << "succ to update service level, " << service_level_;
    return true;
  }

  LOG(WARNING) << "reload conf fail, conf_field: " << conf_field << ", conf_value: " << conf_value;
  return false;
}

bool GlobalConf::ParseServiceLevel(const std::string& value, LeafServiceLevel* level) {
  *level = service_level_;
  int int_val = service_level_;
  if (!base::StringToInt(value, &int_val)) return false;
  if (int_val < 0 || int_val > kNoDedupService ) return false;
  *level = LeafServiceLevel(int_val);
  return true;
}

}  // namespace leafserver
}  // namespace reco

