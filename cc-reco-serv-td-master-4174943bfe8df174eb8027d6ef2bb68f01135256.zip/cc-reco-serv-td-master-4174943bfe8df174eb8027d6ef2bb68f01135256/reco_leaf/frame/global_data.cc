#include "reco/serv/reco_leaf/frame/global_data.h"

#include <fstream>
#include <numeric>
#include <utility>
#include <unordered_set>
#include <algorithm>
#include <set>
#include "boost/concept_check.hpp"

#include "ads_index/api/public.h"
#include "nlp/common/nlp_util.h"
#include "serving_base/utility/system_util.h"
#include "extend/multi_strings/multi_strings_vldc.h"

#include "reco/base/vipserver/api/vipserver_manager.h"
#include "reco/bizc/region/region_dict.h"
#include "reco/bizc/filter_rule/online/filter_monster.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/frame/inner/dmp_category_mapping.h"
#include "reco/serv/reco_leaf/frame/inner/video_communicator.h"
#include "reco/serv/reco_leaf/frame/inner/dynamic_dict_container.h"
#include "reco/serv/dict_server/api/dict_server_api.h"

namespace reco {
DECLARE_string(log_kafka_brokers);

namespace leafserver {
DEFINE_string(leaf_data_dir, "/serving/leaf_server/data", "");
// DEFINE_string(hdfs_ip, "10.3.5.72", "hadoop fs 地址");
// DEFINE_int32(hdfs_port, 9000, "hadoop port");
// DEFINE_int32(sys_level_upper_cost, 170, "");
DEFINE_bool(enable_user_trace_kafka, true, "记录内部用户的访问历史");
DEFINE_string(kafka_leaf_trace_topic, "test_reco_analysis", "kafka 用户推荐历史分析的 topic");
DEFINE_bool(enable_query_probe_kafka, true, "记录 query 的探索历史");
DEFINE_string(kafka_query_probe_topic, "test_probe_query", "kafka query 探索历史 topic");
DEFINE_string(category_cf_dict_file, "", "category_cf_dict file name");
DEFINE_bool(rank_parallel, true, "rank parallel compute");
DEFINE_bool(check_loyal_user, true, "");

DEFINE_string(user_server_machine_list, "test_user.yaml", "user server config file");
DEFINE_string(user_profile_machine_list, "test_profile.yaml", "user profile server config file");
DEFINE_int32(user_server_timeout_per_communicate, 250, "user server time out, ms");
DEFINE_int32(user_server_total_timeout, 450, "user server total timeout");
DEFINE_int32(user_server_retry_times, 1, "user server retry num");
DEFINE_bool(use_user_cache, true, "");

// 根据地域，指定时间，限制只下发审查过的文章
DEFINE_int32(reviewed_filter_begin_time, -1, "规则开始生效的时间戳，单位秒");
DEFINE_int32(reviewed_filter_end_time, -1, "规则结束的时间戳，单位秒");

// w2v 缓存
DEFINE_int32(w2v_cache_seconds, 600, "w2v 结果本地缓存时间，单位秒");
DEFINE_int32(max_w2v_fetch_quene_length, 100000, "w2v 异步队列最大长度");

DEFINE_int64_counter(leaf, cpu_idle, 0, "");
DEFINE_int64_counter(leaf, system_status, 0, "");

// TODO(KouYan): test
DEFINE_int32(debug_loyal_user, 0, "1是忠实用户，2是非忠实用户");

DEFINE_int64_counter(leaf, w2v_queue_size, 0, "");
DEFINE_int64_counter(leaf, w2v_consumed, 0, "");
DEFINE_int64_counter(leaf, w2v_cache_size, 0, "");

const char* GlobalData::kChannelCategoryFile  = "channel_category.txt";
const char* GlobalData::kUserRoleKeywordFile  = "user_role_keyword.txt";
const char* GlobalData::kUserRoleCategoryFile = "user_role_category.txt";
const char* GlobalData::kAppCategoryFile      = "app_category.txt";
const char* GlobalData::kRegionDictFile       = "city_code.txt";
const char* GlobalData::kCityIdNameMapFile    = "city_id_name_map.txt";
const char* GlobalData::kIflowCategoryConfFile = "iflow_category_conf_dict.txt";
const char* GlobalData::kLifeStageTagsDictFile = "life_stage_tags.dict";
const char* GlobalData::kQudaoBlackSourceDictFile = "qudao_black_source_dict.txt";
const char* GlobalData::kQueryBlackListDictFile = "query_black_list.txt";
// const char* GlobalData::kRecoReasonTagFile = "reco_reason_tag_cat.txt";
// const char* GlobalData::kSubscriptTagRelevenceFile = "subscript_tag_relevence.txt";
const char* GlobalData::kInnerUserIdListFile = "inner_user_ids.txt";
const char* GlobalData::kValidVideoTagFile = "valid_video_tag.txt";
const char* GlobalData::kSubscribedShowClickFile = "subscription_show_click.txt";
const char* GlobalData::kHotTagsFile = "hot_tags.txt";
const char* GlobalData::kChannelNameFile = "channel_name.txt";
// const char* GlobalData::kThirdPartyCategoryLrModelFile = "tp_cate_lr_model.txt";
// const char* GlobalData::kThirdPartyItemLrModelFile = "tp_item_lr_model.txt";

GlobalData::GlobalData(adsindexing::Index *ext_index, int work_thread_num)
    : index(ext_index), is_ext_index(true), redis(NULL),
    common_filter(NULL), thread_quit_(false) {
  // vipserver
  reco::vipserver::VSClientMgrIns::instance().Init();

  // redis
  redis = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);
  CHECK_NOTNULL(redis);

  sys_status_ = kSysNormal;

  life_stage_tags_dict.set_empty_key(std::string());

  work_thread_pool = new thread::ThreadPool(work_thread_num);
  CHECK_NOTNULL(work_thread_pool);

  thread::Thread load_index_thread;
  load_index_thread.Start(NewCallback(this, &GlobalData::InitNewsIndex));

  // load dmp category mapping
  dmp_category_mapping = new DmpCategoryMapping();

  // third party category lr model
  // tp_cate_lr_model_ = new reco::ml::DenseHashLRModel();
  // third party item lr model
  // tp_item_lr_model_ = new reco::ml::DenseHashLRModel();

  // load dict
  loadDict();
  // load rk graph
  // rk_graph_ = new RKGraph;
  // CHECK(rk_graph_->LoadGraph());

  video_result_null_cache = new serving_base::ExpiryMap<uint64, bool>(0.5 * 60 * 60);
  CHECK_NOTNULL(video_result_null_cache);

  ucnews_userid_cache = new serving_base::ExpiryMap<uint64, uint64>(3600 * 24);
  CHECK_NOTNULL(ucnews_userid_cache);

  system_monitor_thread_.Start(::NewCallback(this, &GlobalData::SystemMonitor));

  common_filter = new reco::common::CommonFilter(FLAGS_leaf_data_dir);
  CHECK_NOTNULL(common_filter);

  load_index_thread.Join();

  if (FLAGS_enable_user_trace_kafka) {
    user_trace_producer = new reco::kafka::Producer(FLAGS_log_kafka_brokers, FLAGS_kafka_leaf_trace_topic);
    LOG(INFO) << "enable user trace kafka";
  } else {
    user_trace_producer = NULL;
  }
  if (FLAGS_enable_query_probe_kafka) {
    query_probe_producer = new reco::kafka::Producer(FLAGS_log_kafka_brokers, FLAGS_kafka_query_probe_topic);
    LOG(INFO) << "enable query probe kafka";
  } else {
    query_probe_producer = NULL;
  }

  user_comm = new reco::common::UserComm(FLAGS_user_server_machine_list,
                                         FLAGS_user_profile_machine_list,
                                         FLAGS_user_server_timeout_per_communicate,
                                         FLAGS_user_server_total_timeout,
                                         FLAGS_user_server_retry_times,
                                         FLAGS_use_user_cache);
  video_comm = new VideoComm(news_index);

  uint64 filter_sign =
      reco::filter::ItemFilter + reco::filter::SessionFilter +
      reco::filter::RiskMediaFilter + reco::filter::AppTokenFilter;

  filter_monster = new reco::filter::FilterMonster(filter_sign, news_index);

  stream_filter = new reco::filter::StreamFilterSignAsyncCalc(news_index);

  stream_filter->Start();

  // w2v 异步加载
  w2v_cache_ = new serving_base::ExpiryMap<uint64, std::string>(FLAGS_w2v_cache_seconds);
  CHECK_NOTNULL(w2v_cache_);
  w2v_fetch_queue_ = new thread::BlockingQueue<uint64>();
  CHECK_NOTNULL(w2v_fetch_queue_);
  w2v_fetch_thread_.Start(::NewCallback(this, &GlobalData::FetchW2vRecoResults));

  reco::dm::DictManagerSingleton::instance().LoadAllDicts();
}

void GlobalData::InitNewsIndex() {
  CHECK(index) << "index should not be NULL";
  news_index = reco::InitializeNewsIndex(index);
}

GlobalData::~GlobalData() {
  thread_quit_ = true;

  if (work_thread_pool) {
    work_thread_pool->JoinAll();
     delete work_thread_pool;
     work_thread_pool = NULL;
  }

  // 停止 w2v 异步加载线程
  w2v_fetch_thread_.Join();

  if (!is_ext_index) delete index;
  if (news_index) delete news_index;
  // delete rk_graph_;
  delete dmp_category_mapping;
  // delete tp_cate_lr_model_;
  // delete tp_item_lr_model_;

  if (video_result_null_cache) {
    delete video_result_null_cache;
    video_result_null_cache = NULL;
  }

  if (ucnews_userid_cache) {
    delete ucnews_userid_cache;
    ucnews_userid_cache = NULL;
  }

  if (redis) {
    delete redis;
    redis = NULL;
  }

  if (common_filter) {
    delete common_filter;
    common_filter = NULL;
  }

  if (user_trace_producer) {
    delete user_trace_producer;
    user_trace_producer = NULL;
  }

  if (query_probe_producer) {
    delete query_probe_producer;
    query_probe_producer = NULL;
  }

  if (video_comm) {
    delete video_comm;
    video_comm = NULL;
  }

  if (filter_monster) {
    delete filter_monster;
    filter_monster = NULL;
  }

  if (stream_filter) {
    stream_filter->Stop();
    delete stream_filter;
    stream_filter = NULL;
  }

  if (w2v_cache_) {
    delete w2v_cache_;
    w2v_cache_ = NULL;
  }

  if (w2v_fetch_queue_) {
    w2v_fetch_queue_->Close();
    delete w2v_fetch_queue_;
    w2v_fetch_queue_ = NULL;
  }

  // vipserver
  reco::vipserver::VSClientMgrIns::instance().Destroy();
}

void GlobalData::loadDict() {
  base::FilePath base_dir(FLAGS_leaf_data_dir);

  // register and load dynamic dict
  DynamicDictContainer::RegisterAndLoadAllDict();

  CHECK(dmp_category_mapping->LoadDict(FLAGS_leaf_data_dir));
  base::FilePath region_map_file = base_dir.Append(kRegionDictFile);
  CHECK(reco::common::RegionSearcher::instance().Load(region_map_file.ToString()));

  // 加载渠道黑名单表
  loadQudaoBlackSourceDict(base_dir);
  // 加载 iflow category
  loadQudaoCategoryDict(base_dir);
  // 加载 life stage tags.dict
  loadLifeStageTagsDict(base_dir);
  // 加载 query 探索黑名单
  loadQueryBlackListDict(base_dir);
  // 加载 third party category lr 模型
  // loadTpCateLrModel(base_dir);
  // 加载 third party category item 模型
  // loadTpItemLrModel(base_dir);
  // 加载频道名称
  LoadChannelNameDict(base_dir);

  std::string nor_str;
  std::vector<std::string> lines;
  std::vector<std::string> flds;
  base::FilePath channel_category_file = base_dir.Append(kChannelCategoryFile);
  CHECK(base::file_util::ReadFileToLines(channel_category_file, &lines));
  int64 channel_id;
  // TODO(jianhuang) 词表越来越多，拆开到各个函数
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u ||
        !base::StringToInt64(flds[0], &channel_id)) {
      LOG(ERROR) << "channel category record field error, line is: " << lines[i];
      continue;
    }

    CategoryDistributes category_weights;
    for (int j = 1; j < (int)flds.size(); ++j) {
      if (!parseFeas(flds[j], &category_weights)) {
        LOG(ERROR) << "channel category record field error, line is: " << lines[i];
      }
    }
    if (normalizeFeas(&category_weights)) {
      channel_categories.insert(std::make_pair(channel_id, category_weights));
    }
  }
  LOG(INFO) << "load channel categories dict succ, total record " << channel_categories.size();

  lines.clear();
  base::FilePath user_role_kw_file = base_dir.Append(kUserRoleKeywordFile);
  CHECK(base::file_util::ReadFileToLines(user_role_kw_file, &lines));
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u) {
      LOG(ERROR) << "user role keywords record field error, line is: " << lines[i];
      continue;
    }
    nor_str = nlp::util::NormalizeLine(flds[0]);
    KeywordDistributes kw_weights;
    for (int j = 1; j < (int)flds.size(); ++j) {
      if (!parseFeas(flds[j], &kw_weights)) {
        LOG(ERROR) << "user role keywords record field error, line is: " << lines[i];
      }
    }
    if (normalizeFeas(&kw_weights)) {
      user_role_keywords.insert(std::make_pair(nor_str, kw_weights));
    }
  }
  LOG(INFO) << "load user_role keywords dict succ, total record " << user_role_keywords.size();

  lines.clear();
  base::FilePath user_role_category_file = base_dir.Append(kUserRoleCategoryFile);
  CHECK(base::file_util::ReadFileToLines(user_role_category_file, &lines));
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u) {
      LOG(ERROR) << "user_role category record field error, line is: " << lines[i];
      continue;
    }
    nor_str = nlp::util::NormalizeLine(flds[0]);
    CategoryDistributes category_weights;
    for (int j = 1; j < (int)flds.size(); ++j) {
      if (!parseFeas(flds[j], &category_weights)) {
        LOG(ERROR) << "user_role category record field error, line is: " << lines[i];
      }
    }
    if (normalizeFeas(&category_weights)) {
      user_role_categories.insert(std::make_pair(nor_str, category_weights));
    }
  }
  LOG(INFO) << "load user_role category dict succ, total record " << user_role_categories.size();

  lines.clear();
  base::FilePath app_category_file = base_dir.Append(kAppCategoryFile);
  CHECK(base::file_util::ReadFileToLines(app_category_file, &lines));
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u) {
      LOG(ERROR) << "app category record field error, line is: " << lines[i];
      continue;
    }
    nor_str = nlp::util::NormalizeLine(flds[0]);
    uint64 sign = base::CalcTermSign(nor_str.c_str(), nor_str.length());
    std::vector<std::string>& categories = app_categories[sign];
    categories.clear();
    base::SplitString(flds[1], ",", &categories);
    CHECK_GT(categories.size(), 0u);
  }
  LOG(INFO) << "load app category dict succ, total record " << app_categories.size();

  lines.clear();
  city_id_name_map.clear();
  base::FilePath city_id_name_file = base_dir.Append(kCityIdNameMapFile);
  CHECK(base::file_util::ReadFileToLines(city_id_name_file, &lines));
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u) {
      LOG(ERROR) << "city_id_name map file record field error, line is: " << lines[i];
      continue;
    }
    city_id_name_map[flds[0]] = flds[1];
  }
  LOG(INFO) << "load city_id_name map file succ, total record " << city_id_name_map.size();

  // load category cf dict
  LoadCategoryCf(base_dir);

  // load Inner User Id List
  LoadInnerUserIdList(base_dir);

  LoadValidVideoTagDict(base_dir);

  base::FilePath subscribed_show_click_file = base_dir.Append(kSubscribedShowClickFile);
  LoadSubscribedShowClickFile(subscribed_show_click_file);

  base::FilePath hot_tags_file = base_dir.Append(kHotTagsFile);
  LoadHotTagsFile(hot_tags_file);
}

void GlobalData::LoadValidVideoTagDict(const base::FilePath& base_dir) {
  valid_video_tag_.clear();
  std::vector<std::string> lines;
  base::FilePath path = base_dir.Append(kValidVideoTagFile);
  if (!base::file_util::PathExists(path)) return;
  if (!base::file_util::ReadFileToLines(path, &lines) || lines.empty()) {
    LOG(WARNING) << "Read valid_video_tag data error, " << path.ToString();
    return;
  }
  for (size_t i = 0; i < lines.size(); ++i) {
    base::TrimWhitespaces(&lines[i]);
    valid_video_tag_.insert(lines[i]);
  }
  LOG(INFO) << "valid_video_tag: " << valid_video_tag_.size();
}

void GlobalData::LoadInnerUserIdList(const base::FilePath& base_dir) {
  inner_user_ids.clear();
  std::vector<std::string> lines;
  base::FilePath path = base_dir.Append(kInnerUserIdListFile);
  if (!base::file_util::PathExists(path)) return;
  if (!base::file_util::ReadFileToLines(path, &lines) || lines.empty()) {
    LOG(WARNING) << "Read Reco Reason Tag Category data error, " << path.ToString();
    return;
  }

  uint64 user_id;
  for (size_t i = 0; i < lines.size(); ++i) {
    base::TrimWhitespaces(&lines[i]);
    if (!base::StringToUint64(lines[i], &user_id)) {
      continue;
    }
    inner_user_ids.insert(user_id);
  }
  LOG(INFO) << "load inner user id list success: " << inner_user_ids.size();
}

/*
void GlobalData::LoadRecoReasonTagCategoryDict(const base::FilePath& file_path) {
  std::vector<std::string> lines;
  if (!base::file_util::PathExists(file_path)) return;
  if (!base::file_util::ReadFileToLines(file_path, &lines) || lines.empty()) {
    LOG(WARNING) << "Read Reco Reason Tag Category data error, " << file_path.ToString();
    return;
  }

  auto dyn_dict = reco_reason_tag_category.GetInactiveDict();
  dyn_dict->clear();
  auto dyn_tag_mapping = reco_reason_tag_mapping.GetInactiveDict();
  dyn_tag_mapping->clear();

  std::vector<std::string> fields;
  for (size_t i = 0; i < lines.size(); ++i) {
    fields.clear();
    base::SplitString(lines[i], "\t", &fields);
    if (fields.size() < 2u) continue;
    std::string tag = nlp::util::NormalizeLine(fields[0]);
    auto &category = fields[1];

    (*dyn_tag_mapping)[tag] = fields[0];

    std::unordered_set<std::string> *cates;
    auto iter = dyn_dict->find(tag);
    if (iter == dyn_dict->end()) {
      cates = &(dyn_dict->insert(
          std::make_pair(tag, std::unordered_set<std::string>())).first->second);
    } else {
      cates = &(iter->second);
    }
    cates->insert(category);
  }
  if (!dyn_dict->empty()) {
    reco_reason_tag_category.SwitchDict();
  }
  if (!dyn_tag_mapping->empty()) {
    reco_reason_tag_mapping.SwitchDict();
  }
  LOG(INFO) << "load dynamic reco reason tag category dict success: "
    << reco_reason_tag_category.GetDict()->size()
    << ", tag_mapping_dict_size:" << reco_reason_tag_mapping.GetDict()->size();
}

void GlobalData::LoadSubscriptiTagRelevence(const base::FilePath& file_path) {
  std::vector<std::string> lines;
  if (!base::file_util::PathExists(file_path)) return;
  if (!base::file_util::ReadFileToLines(file_path, &lines) || lines.empty()) {
    LOG(WARNING) << "Read Subscript Tag Relevence data error, " << file_path.ToString();
    return;
  }

  auto dyn_oneway_dict = subscript_tag_relevence_oneway.GetInactiveDict();
  auto dyn_twoway_dict = subscript_tag_relevence_twoway.GetInactiveDict();
  auto dyn_merged_dict = subscript_tag_relevence_merged.GetInactiveDict();
  dyn_oneway_dict->clear();
  dyn_twoway_dict->clear();
  dyn_merged_dict->clear();

  std::vector<std::string> fields, oneway_list, twoway_list;
  for (size_t i = 0; i < lines.size(); ++i) {
    fields.clear();
    oneway_list.clear();
    twoway_list.clear();
    base::SplitString(lines[i], "\t", &fields);
    if (fields.size() < 3u) continue;
    std::string tag = nlp::util::NormalizeLine(fields[0]);
    if (!fields[1].empty()) {
      base::SplitString(nlp::util::NormalizeLine(fields[1]), "|", &twoway_list);
      dyn_twoway_dict->insert(make_pair(tag, twoway_list));
    }
    if (!fields[2].empty()) {
      base::SplitString(nlp::util::NormalizeLine(fields[2]), "|", &oneway_list);
      dyn_oneway_dict->insert(make_pair(tag, oneway_list));
    }

    // 每个标签的关联标签通常较少，所以此处用 vector 遍历
    std::vector<std::string> merged_vec;
    for (auto it_two = twoway_list.begin(); it_two != twoway_list.end(); ++it_two) {
      bool found = false;
      for (auto it_merged = merged_vec.begin(); it_merged != merged_vec.end(); ++it_merged) {
        if (*it_two == *it_merged) {
          found = true;
        }
      }
      if (!found) {
        merged_vec.push_back(*it_two);
      }
    }
    for (auto it_one = oneway_list.begin(); it_one != oneway_list.end(); ++it_one) {
      bool found = false;
      for (auto it_merged = merged_vec.begin(); it_merged != merged_vec.end(); ++it_merged) {
        if (*it_one == *it_merged) {
          found = true;
        }
      }
      if (!found) {
        merged_vec.push_back(*it_one);
      }
    }
    if (!merged_vec.empty()) {
      dyn_merged_dict->insert(make_pair(tag, merged_vec));
    }
  }

  if (!dyn_oneway_dict->empty()) {
    subscript_tag_relevence_oneway.SwitchDict();
  }

  if (!dyn_twoway_dict->empty()) {
    subscript_tag_relevence_twoway.SwitchDict();
  }

  if (!dyn_merged_dict->empty()) {
    subscript_tag_relevence_merged.SwitchDict();
  }

  LOG(INFO) << "load subscript tag relevence dict success. one-way size:"
            << subscript_tag_relevence_oneway.GetDict()->size()
            << ", two-way size:" << subscript_tag_relevence_twoway.GetDict()->size()
            << ", merge size:" << subscript_tag_relevence_merged.GetDict()->size();
}
*/

void GlobalData::LoadSubscribedShowClickFile(const base::FilePath& file_path) {
  std::vector<std::string> lines;
  if (!base::file_util::PathExists(file_path)) return;
  if (!base::file_util::ReadFileToLines(file_path, &lines) || lines.empty()) {
    LOG(WARNING) << "Read subscribed show click data error, " << file_path.ToString();
    return;
  }

  subscribed_show_click_dict_.clear();

  std::vector<std::string> fields;
  for (size_t i = 0; i < lines.size(); ++i) {
    fields.clear();
    base::SplitString(lines[i], "\t", &fields);
    if (fields.size() < 4u) continue;
    const std::string &tag = nlp::util::NormalizeLine(fields[0]);

    uint32_t show = 0;
    if (!base::StringToUint(fields[1], &show)) {
      continue;
    }

    double ctr = 0.0;
    if (!base::StringToDouble(fields[3], &ctr)) {
      continue;
    }

    subscribed_show_click_dict_[tag] = std::make_pair(show, ctr);
  }
  LOG(INFO) << "load subscribed show click dict success: " << subscribed_show_click_dict_.size();
}


void GlobalData::LoadCategoryCf(const base::FilePath& base_dir) {
  category_cf_dict.clear();
  if (FLAGS_category_cf_dict_file.empty()) return;

  std::vector<std::string> lines;
  base::FilePath category_cf_path = base_dir.Append(FLAGS_category_cf_dict_file);
  if (!base::file_util::PathExists(category_cf_path)) return;
  if (!base::file_util::ReadFileToLines(category_cf_path, &lines) || lines.empty()) {
    LOG(WARNING) << "Read Category Cf data error, " << category_cf_path.ToString();
    return;
  }

  std::vector<std::string> data_cell;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    data_cell.clear();
    base::SplitString(lines[idx], "\t", &data_cell);
    if (data_cell.size() != 3) {
      LOG(ERROR) << "category cf data parse fail data is:" << lines[idx];
      continue;
    }
    if (category_cf_dict.find(data_cell[0]) == category_cf_dict.end())
      category_cf_dict[data_cell[0]].clear();
    double cf_score = 0.0;
    if (base::StringToDouble(data_cell[2], &cf_score)) {
      category_cf_dict[data_cell[0]][data_cell[1]] = cf_score;
    }
  }
  LOG(INFO) << "succ to load category cf dict, line size: " << lines.size()
            << ", dict size: " << category_cf_dict.size();
}

void GlobalData::loadQudaoCategoryDict(const base::FilePath& base_dir) {
  std::vector<std::string> lines;
  qudao_categories_dict.clear();
  base::FilePath iflow_category_conf_file = base_dir.Append(kIflowCategoryConfFile);
  std::vector<std::string> flds;
  std::vector<std::string> categories;
  CHECK(base::file_util::ReadFileToLines(iflow_category_conf_file, &lines));
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    categories.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u) {
      LOG(ERROR) << "iflow_category map file record field error, line is: " << lines[i];
      continue;
    }
    std::unordered_set<std::string>& category_set = qudao_categories_dict[flds[0]];
    category_set.clear();
    base::SplitString(flds[1], ",", &categories);
    for (int j = 0; j < (int)categories.size(); ++j) {
      category_set.insert(categories[j]);
    }
    LOG(INFO) << "qudao: " << flds[0] << ", category num: " << category_set.size()
              << ", specific: "<< flds[1];
  }
  LOG(INFO) << "load iflow_category map file succ, total record " << qudao_categories_dict.size();
}

void GlobalData::loadLifeStageTagsDict(const base::FilePath& base_dir) {
  std::vector<std::string> lines;
  life_stage_tags_dict.clear();
  base::FilePath life_stage_tags_dict_file = base_dir.Append(kLifeStageTagsDictFile);
  std::vector<std::string> flds;
  std::vector<std::string> tags;
  CHECK(base::file_util::ReadFileToLines(life_stage_tags_dict_file, &lines));
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    tags.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 3u) {
      LOG(ERROR) << "life stage tags dict file record field error, line is: " << lines[i];
      break;
    }
    std::string mapkey = flds[0] + "_" + flds[1];
    if (life_stage_tags_dict.find(mapkey) != life_stage_tags_dict.end()) {
      LOG(ERROR) << "life stage tags dict file find duplicate line, line is: " << lines[i];
      break;
    }
    life_stage_tags_dict[mapkey] = StageTag();
    life_stage_tags_dict[mapkey].set_empty_key(std::string());

    StageTag &stage_tag = life_stage_tags_dict[mapkey];
    base::SplitString(flds[2], ",", &tags);
    for (int j = 0; j < (int)tags.size(); ++j) {
      if (tags[j].length() == 0) {
        LOG(ERROR) << "life stage tags dict find tag is null string, line is: " << lines[i];
        continue;
      }
      stage_tag.insert(tags[j]);
    }
    LOG(INFO) << "channel_id: " << flds[0] << ", tags num: " << tags.size()
              << ", phase stage: "<< flds[1];
  }
  LOG(INFO) << "load life stage tags dict file succ, total record "
            << lines.size();
}

void GlobalData::loadQudaoBlackSourceDict(const base::FilePath& base_dir) {
  qudao_black_source_dict.clear();
  base::FilePath qudao_black_source_file = base_dir.Append(kQudaoBlackSourceDictFile);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(qudao_black_source_file, &lines)) {
    LOG(WARNING) << "fail to read qudao black source file, " << qudao_black_source_file.ToString();
    return;
  }
  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u || flds[0].empty() || flds[1].empty()) {
      LOG(ERROR) << "qudao black_source map file record field error, line is: " << lines[i];
      continue;
    }
    qudao_black_source_dict[flds[0]].insert(flds[1]);
  }

  LOG(INFO) << "succ to load qudao black_source dict:" << qudao_black_source_dict.size();
}

void GlobalData::loadQueryBlackListDict(const base::FilePath& base_dir) {
  query_black_list_dict.clear();
  base::FilePath query_black_list_file = base_dir.Append(kQueryBlackListDictFile);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(query_black_list_file, &lines)) {
    LOG(WARNING) << "fail to read query black list file, " << query_black_list_file.ToString();
    return;
  }
  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u || flds[1].empty()) {
      LOG(ERROR) << "query black list file record field error, line is: " << lines[i];
      continue;
    }
    int query_level;
    if (!base::StringToInt(flds[0], &query_level)) {
      continue;
    }
    std::string query = nlp::util::NormalizeLine(flds[1]);
    query_black_list_dict[query] = query_level;
  }

  LOG(INFO) << "succ to load query black list dict:" << query_black_list_dict.size();
}

void GlobalData::LoadChannelNameDict(const base::FilePath& base_dir) {
  base::FilePath file = base_dir.Append(kChannelNameFile);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file, &lines)) {
    LOG(WARNING) << "fail to read channel name file, " << file.ToString();
    return;
  }
  std::vector<std::string> flds;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u || flds[1].empty()) {
      LOG(ERROR) << "query channel name file record field error, line is: " << lines[i];
      continue;
    }
    int64 channel_id;
    if (!base::StringToInt64(flds[0], &channel_id)) {
      continue;
    }
    channel_name[channel_id] = flds[1];
  }

  LOG(INFO) << "succ to load channel name list dict:" << channel_name.size();
}

/*
void GlobalData::loadTpCateLrModel(const base::FilePath& base_dir) {
  base::FilePath model_file = base_dir.Append(kThirdPartyCategoryLrModelFile);
  if (tp_cate_lr_model_->LoadText(model_file)) {
    LOG(INFO) << "succ to load third party category lr model";
  } else {
    LOG(ERROR) << "failed to load third party category lr model";
  }
}
*/
/*
void GlobalData::loadTpItemLrModel(const base::FilePath& base_dir) {
  base::FilePath model_file = base_dir.Append(kThirdPartyItemLrModelFile);
  if (tp_item_lr_model_->LoadText(model_file)) {
    LOG(INFO) << "succ to load third party item lr model";
  } else {
    LOG(ERROR) << "failed to load third party item lr model";
  }
}
*/

void GlobalData::LoadHotTagsFile(const base::FilePath& file_path) {
  std::vector<std::string> lines;
  if (!base::file_util::PathExists(file_path)) return;
  if (!base::file_util::ReadFileToLines(file_path, &lines) || lines.empty()) {
    LOG(WARNING) << "Read hot tags data error, " << file_path.ToString();
    return;
  }

  auto dyn_dict = hot_tags_.GetInactiveDict();
  dyn_dict->clear();

  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) continue;
    dyn_dict->insert(nlp::util::NormalizeLine(lines[i]));
  }

  if (!dyn_dict->empty()) {
    hot_tags_.SwitchDict();
  }
  LOG(INFO) << "load hot_tags dyn dict success: " << hot_tags_.GetDict()->size();
}

bool GlobalData::parseFeas(const std::string& fea_wt_str,
                           std::vector<std::pair<std::string, float> >* feas) {
  double weight = 0;
  std::vector<std::string> cols;
  base::SplitString(fea_wt_str, ":", &cols);
  if (cols.size() != 2u || !base::StringToDouble(cols[1], &weight)) {
    return false;
  }
  std::string nor_str = nlp::util::NormalizeLine(cols[0]);
  if (nor_str.empty()) {
    return false;
  }
  feas->push_back(std::make_pair(nor_str, static_cast<float>(weight)));
  return true;
}

bool GlobalData::normalizeFeas(std::vector<std::pair<std::string, float> >* feas) {
  float total_weight = 0;
  for (int j = 0; j < (int)feas->size(); ++j) {
    total_weight += (*feas)[j].second;
  }
  if (total_weight < 1e-6) return false;
  for (int j = 0; j < (int)feas->size(); ++j) {
    (*feas)[j].second /= total_weight;
  }
  return true;
}

std::vector<size_t> get_cpu_times() {
  std::ifstream proc_stat("/proc/stat");
  proc_stat.ignore(5, ' ');  // Skip the 'cpu' prefix.
  std::vector<size_t> times;
  for (size_t time; proc_stat >> time; times.push_back(time));
  return times;
}

bool get_cpu_times(size_t *idle_time, size_t *total_time) {
  const std::vector<size_t> cpu_times = get_cpu_times();
  if (cpu_times.size() < 4)
    return false;
  *idle_time = cpu_times[3];
  *total_time = std::accumulate(cpu_times.begin(), cpu_times.end(), 0);
  return true;
}

void GlobalData::SystemMonitor() {
  LOG(INFO) << "system monitor thread run.";
  int status = kSysBusy;
  int last_sys_status = status;

  while (!thread_quit_) {
    // sys_status = std::max(GetCPUIdleStatus(), resp_time_status_.load());
    status = GetCPUIdleStatus(sys_status_);

    if (status < sys_status_) {
      status = sys_status_ - 1;
    }

    last_sys_status = sys_status_;
    sys_status_ = status;
    COUNTERS_leaf__system_status.Reset(sys_status_);

    if (last_sys_status < sys_status_) {
      LOG(INFO) << "new sys status:" << sys_status_;
      base::SleepForSeconds(sys_status_);
    } else if (last_sys_status > sys_status_) {
      LOG(INFO) << "new sys status:" << sys_status_;
      base::SleepForSeconds(std::max(sys_status_ / 2, 1));
    } else {
      base::SleepForMilliseconds(200);
    }
  }
}


int GlobalData::GetCPUIdleStatus(const int last_status) {
  static size_t previous_idle_time = 0, previous_total_time = 0, idle_time = 0, total_time = 0;

  // cpu idle
  SysStatus status = static_cast<SysStatus>(last_status);
  if (get_cpu_times(&idle_time, &total_time)) {
    const float total_time_delta = total_time - previous_total_time;
    if (total_time_delta > 500) {
      if (previous_idle_time > 0) {
        const float idle_time_delta = idle_time - previous_idle_time;
        const int cpu_idle = 100. * (idle_time_delta / total_time_delta);
        // LOG(INFO) << "cpu_idle:" << cpu_idle;
        COUNTERS_leaf__cpu_idle.Reset(cpu_idle);

        if (cpu_idle > 75) {
          status = kSysFree;
        } else if (cpu_idle > 60) {
          status = kSysNormal;
        } else if (cpu_idle > 50) {
          status = kSysBusy;
        } else if (cpu_idle > 40) {
          status = kSysFull;
        } else {
          status = kSysDanger;
        }
      }
      previous_idle_time = idle_time;
      previous_total_time = total_time;
    }
  }

  return status;
}


/*
void GlobalData::SysCounter(const double cost_us) {
  static base::Time next_check_time = base::Time::Now();
  static uint64 old_count = 0;
  static double old_cost_ms = 0.0;
  static uint64 sys_req_count = 0;
  static double sys_total_cost_ms = 0;
  static thread::Mutex mutex;

  thread::AutoLock lock(&mutex);
  sys_req_count++;
  sys_total_cost_ms += cost_us / 1000.0f;

  // system status determination
  const base::Time curr_t = base::Time::Now();
  if (curr_t > next_check_time) {
    next_check_time += base::TimeDelta::FromSeconds(2);
    if (sys_req_count <= old_count) {
      resp_time_status_ = kSysFree;
    } else {
      const double avg_cost_ms = (sys_total_cost_ms - old_cost_ms) / (sys_req_count - old_count);
      if (avg_cost_ms <= FLAGS_sys_level_upper_cost) {
        resp_time_status_ = kSysFree;
      } else {
        resp_time_status_ = kSysCritical;
      }
    }

    if (sys_req_count > 100000000) {
      sys_req_count = 0;
      sys_total_cost_ms = 0.;
    }

    old_count = sys_req_count;
    old_cost_ms = sys_total_cost_ms;
  }

  return;
}
*/


void GlobalData::PackKeyDict(const base::FilePath& path, dawgdic::Dictionary* dict) {
  std::set<std::string> sets;
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(path, &lines);
  for (int i = 0; i < (int)lines.size(); ++i) {
    nlp::util::NormalizeLineInPlaceS(&lines[i]);
    sets.insert(lines[i]);
  }

  dawgdic::DawgBuilder dawg_builder;
  for (auto it = sets.begin(); it != sets.end(); ++it) {
    CHECK(dawg_builder.Insert(it->c_str()));
  }
  dawgdic::Dawg dawg;
  dawg_builder.Finish(&dawg);
  CHECK(dawgdic::DictionaryBuilder::Build(dawg, dict));
}

bool GlobalData::IsInnerUserId(uint64 user_id) {
  return inner_user_ids.find(user_id) != inner_user_ids.end();
}

void GlobalData::FetchW2vRecoResults() {
  LOG(INFO) << "start FetchW2vRecoResults thread";
  while (!thread_quit_) {
    uint64 item_id;
    std::string proto_str;

    if (!w2v_fetch_queue_ || !w2v_cache_ || w2v_fetch_queue_->Size() < 1
        || !w2v_fetch_queue_->TryTake(&item_id)) {
      base::SleepForMilliseconds(200);
      continue;
    }
    COUNTERS_leaf__w2v_consumed.Increase(1);

    if (w2v_cache_->FindSilently(item_id, &proto_str)) {
      continue;
    }

    // 从 dict server 读取结果写入本地缓存
    bool read_ret = reco::dictserver::DictServerAPIIns::instance().GetData(
          "ItemW2v", base::Uint64ToString(item_id), "0", &proto_str);
    // dict server 返回的空结果也写入缓存，避免多次查询 dict server
    if (!read_ret) {
      VLOG(1) << "failed to get w2v reco result from dict server: key=" << item_id;
      continue;
    } else {
      w2v_cache_->Add(item_id, proto_str);
      COUNTERS_leaf__w2v_cache_size.Reset(w2v_cache_->Size());
      VLOG(1) << "success to get w2v reco result from dict server: key=" << item_id;
    }
  }
  LOG(INFO) << "stop FetchW2vRecoResults thread";
}

// 获取 w2v 推荐结果，若未命中本地缓存，则加入队列异步获取
void GlobalData::GetW2vRecoResult(const uint64 &item_id, std::string *proto_str) {
  if (w2v_cache_ && w2v_cache_->FindSilently(item_id, proto_str)) {
    // 命中缓存直接返回
    VLOG(1) << "matched w2v cache, item_id=" << item_id;
    return;
  } else {
    // 加入异步队列
    if (w2v_fetch_queue_ && w2v_fetch_queue_->Size() < FLAGS_max_w2v_fetch_quene_length) {
      w2v_fetch_queue_->Put(item_id);
      COUNTERS_leaf__w2v_queue_size.Reset(w2v_fetch_queue_->Size());
      VLOG(1) << "put to w2v queue: " << item_id;
      return;
    }
  }
}

float GlobalData::GetSelectionRatio(void) {
  float ratio = 0.2f;
  switch (sys_status_) {
    case kSysFree:
      ratio = 1.2f;
      break;
    case kSysNormal:
      ratio = 1.0f;
      break;
    case kSysBusy:
      ratio = 0.7f;
      break;
    case kSysFull:
      ratio = 0.4f;
      break;
    case kSysDanger:
      ratio = 0.1f;
      break;
    default:
      break;
  }

  return ratio;
}

int GlobalData::GetParallelNum(void) {
  if (!FLAGS_rank_parallel) {
    return 1;
  }

  int num = 1;
  switch (sys_status_) {
    case kSysFree:
    case kSysNormal:
    case kSysBusy:
      num = 4;
      break;
    case kSysFull:
      num = 3;
      break;
    case kSysDanger:
      num = 2;
      break;
    default:
      break;
  }

  return num;
}
}  // namespace leafserver
}  // namespace reco
