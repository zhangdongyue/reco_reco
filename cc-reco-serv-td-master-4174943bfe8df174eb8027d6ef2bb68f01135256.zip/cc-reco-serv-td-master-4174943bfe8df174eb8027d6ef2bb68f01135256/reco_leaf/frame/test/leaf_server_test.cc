#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "storage/message_queue/api/message_client_generator.h"

#include "serving_base/data_manager/server_frame.h"
#include "serving_base/data_manager/data_manager.h"
#include "serving_base/api/heart_beat.pb.h"

#include "reco/serv/reco_leaf/frame/connection_manager.h"
// #include "reco/serv/reco_leaf/frame/config.h"
#include "reco/serv/user_server/frame/user_impl.h"
#include "reco/serv/user_server/frame/user_mgmt.h"
#include "reco/serv/user_server/frame/global_data.h"
#include "reco/serv/reco_leaf/frame/leaf_impl.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/bizc/index_monitor/api/index_monitor.h"
// XXX(pengdan): 跑 testcase 的前提:
// redis server 在 10.3.5.70:6379:/home/pengdan/pd 开启
DECLARE_string(user_redis_server_ip);
DECLARE_int32(user_redis_server_port);
TEST(LeafServer, TestRecoLeafServer) {
  // typedef std::vector<reco::leafserver::ServerInfo> ServerCluster;
  // std::string yaml_config_file = "reco/serv/reco_leaf/frame/testdata/user_machine_test.list";

  const int rpc_server_port1 = 12590;
  // const int rpc_server_port2 = 12591;

  // 0, 在本机开启两个 user server
  const int thread_num = 2;
  FLAGS_user_redis_server_ip = "10.3.5.70";
  FLAGS_user_redis_server_port = 6379;
  reco::userserver::UserMgmt::InitRedisPool();

  reco::userserver::GlobalData global_data;
  serving_base::DataManangerConfig config;
  config.controller_item_num = thread_num;
  reco::userserver::UserDataManager::Initialize(config, &global_data);

  reco::userserver::UserImpl user_service;
  serving_base::ServerFrameConfig server_frame_config1;
  server_frame_config1.rpc_threads_num = thread_num;
  server_frame_config1.rpc_server_port = rpc_server_port1;
  server_frame_config1.service = &user_service;
  server_frame_config1.dict_manager = reco::userserver::UserDataManager::GetDictManager();
  serving_base::ServerFrame server_frame1(server_frame_config1);

  server_frame1.Start();
  LOG(INFO)<< "user server1 start";

  // reco::userserver::UserImpl user_service2;
  // serving_base::ServerFrameConfig server_frame_config2;
  // server_frame_config2.rpc_threads_num = thread_num;
  // server_frame_config2.rpc_server_port = rpc_server_port2;
  // server_frame_config2.service = &user_service2;
  // server_frame_config2.dict_manager = reco::userserver::UserDataManager::GetDictManager();
  // serving_base::ServerFrame server_frame2(server_frame_config2);
  //
  // server_frame2.Start();
  // LOG(INFO )<< "user server2 start";

  // 2, 开启 leaf server
  int leaf_port = 17911;
  int leaf_thread_num = 1;
  const int heart_beat_port = 17912;

  std::string user_server_ip = "127.0.0.1";
  int port = 12590;
  CHECK(reco::leafserver::ConnectionManager::InitConnection(user_server_ip, port))
      << "Initialize Connection error";

  reco::index_monitor::IndexMonitor index_monitor;
  index_monitor.Start();

  message_queue::MessageQueueOptions message_queue_options("10.3.5.73:1999");
  message_queue_options.create_if_missing_ = true;
  message_queue_options.rpc_timeout_ = 300;

  reco::leafserver::GlobalData leaf_global_data(index_monitor.GetIndex(),
                                           message_queue::NewClient(message_queue_options));

  serving_base::DataManangerConfig leaf_config;
  leaf_config.controller_item_num = leaf_thread_num;
  reco::leafserver::LeafDataManager::Initialize(leaf_config, &leaf_global_data);

  reco::leafserver::LeafImpl service;
  serving_base::ServerFrameConfig server_frame_config;
  server_frame_config.rpc_threads_num = leaf_thread_num;
  server_frame_config.rpc_server_port = leaf_port;
  server_frame_config.service = &service;
  server_frame_config.dict_manager = reco::leafserver::LeafDataManager::GetDictManager();
  server_frame_config.heart_beat_port = heart_beat_port;

  serving_base::ServerFrame server_frame(server_frame_config);

  server_frame.Start();
  std::cout << "leaf server start" << std::endl;

  // 3. 使用 leaf server client 连接服务
  LOG(ERROR) << "start to test leaf server method";
  // Test Heart Beart
  // 测试心跳, 验证 channel 可用
  {
    net::rpc::RpcClientChannel channel("127.0.0.1", heart_beat_port);
    CHECK(channel.Connect()) << "connect fail, ip: 127.0.0.1, port: " << leaf_port;
    serving_base::HeartBeatService::Stub stub(&channel);
    net::rpc::RpcClientController rpc;
    serving_base::HeartBeatRequest request;
    serving_base::HeartBeatResponse response;
    request.set_request_id(1);
    stub.HeartBeat(&rpc, &request, &response, NULL);
    rpc.Wait();
    EXPECT_EQ(rpc.status(), stumy::RpcController::kOk);
    EXPECT_EQ(response.response_id(), request.request_id());
    EXPECT_GT(1.0, response.cpu_usage());
    channel.Close();
    LOG(ERROR) << "rpc server heartbeart test passed!";
  }
  // Test recommend
  {
    net::rpc::RpcClientChannel channel("127.0.0.1", leaf_port);
    CHECK(channel.Connect()) << "connect fail, ip: 127.0.0.1, port: " << leaf_port;
    reco::leafserver::RecommendService::Stub stub2(&channel);
    net::rpc::RpcClientController rpc2;
    reco::leafserver::RecommendRequest request;
    reco::leafserver::RecommendResponse response;
    request.set_reco_id("1001");
    request.set_app_token("uc");
    request.mutable_user()->set_user_id(110);
    request.mutable_user()->set_app_token("app_test");
    request.mutable_user()->set_outer_id("app_test_outer_id");
    request.set_recommend_type(0);
    request.set_return_num(10);
    request.set_query("It's a Test of 推荐请求");

    stub2.recommend(&rpc2, &request, &response, NULL);
    rpc2.Wait();
    EXPECT_EQ(rpc2.status(), stumy::RpcController::kOk);
    EXPECT_TRUE(response.success());
    channel.Close();
    LOG(ERROR) << "rpc server recommond test passed!";
  }


  server_frame.Stop();
  server_frame1.Stop();
  // server_frame2.Stop();

  LOG(INFO) << "server frame stop";

  reco::leafserver::LeafDataManager::Release();
  LOG(INFO) << "data manager release";

  std::cout << "leaf server safe quit" << std::endl;
}
