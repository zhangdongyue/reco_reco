#include <string>
#include <math.h>
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "net/rpc/rpc.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/model_inner/model_buffer_manager.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/model_inner/mf_model.h"
#include "reco/serv/reco_leaf/strategy/common/topn.h"
#include "reco/bizc/item_service/hbase_pool_get_item.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

// DEFINE_string(ip_list_path, "", "");
// DEFINE_int32(port, 20150, "");
// DEFINE_int64(timeout, 1000 * 60 * 5, "");
// DEFINE_bool(is_mf_matrix, false, "");
// DEFINE_bool(is_mf_retri, false, "");
DEFINE_string(mf_version, "0", "");

DEFINE_string(user_id_file, "", "user id file");
DEFINE_string(user_id, "", "user id");
DEFINE_string(item_id_file, "", "item id file");
DEFINE_string(item_id, "", "item id");

DEFINE_int32(thread_num, 10, "");
DEFINE_int32(predict_num, 10000, "mf predict num");
DEFINE_bool(output, false, "if true out put");
DEFINE_int32(topn, 30, "top n predict result");
DEFINE_string(hbase_table_name, "tb_reco_item", "");

double predict(uint64 user_id, uint64 item_id) {
  // using namespace reco::leafserver;
  // std::string key, val;
  // const std::string version = ModelBufMgr::instance().GetVersion();

  // double score = 0;
  // MFModel::GenBaseInfoKey(version, &key);
  // if (!ModelBufMgr::instance().GetMatrixData(key, &val, false)) {
  //   LOG(ERROR) << "get base info fail [" << key << "]";
  //   return 0;
  // }
  // reco::MFBaseInfo base_info;
  // if (!base_info.ParseFromString(val)) {
  //   LOG(ERROR) << "parse base info fail";
  //   return 0;
  // }
  // score += base_info.avg_score();

  // std::string user_id_key, item_id_key;
  // std::string user_id_val, item_id_val;
  // MFModel::GenUserIDKey(version, user_id, &user_id_key);
  // MFModel::GenItemIDKey(version, item_id, &item_id_key);
  // if (!ModelBufMgr::instance().GetMatrixData(item_id_key, &item_id_val, false)) {
  //   VLOG(1) << "get item feature vector fail";
  // }
  // if (!ModelBufMgr::instance().GetMatrixData(user_id_key, &user_id_val, true)) {
  //   VLOG(1) << "get user feature vector fail";
  // }

  // reco::MFFeatureVector user_fea_vec, item_fea_vec;
  // if (!user_fea_vec.ParseFromString(user_id_val)) {
  //   LOG(ERROR) << "parse user feature vector fail";
  // }
  // if (!item_fea_vec.ParseFromString(item_id_val)) {
  //   LOG(ERROR) << "parse item feature vector fail";
  // }

  // if (user_fea_vec.weight_size() == 0) {
  //   score += base_info.user_avg_score();
  //   VLOG(1) << "user not found in user matrix [" << key << "]";
  // } else {
  //   if (user_fea_vec.weight_size() != ((int)base_info.fea_num() + 1)) {
  //     LOG(ERROR) << "user feature vector size error ["
  //                << user_fea_vec.weight_size() << ", " << base_info.fea_num() << "]";
  //     return 0;
  //   }
  //   score += user_fea_vec.weight(0);
  // }

  // if (item_fea_vec.weight_size() == 0) {
  //   score += base_info.item_avg_score();
  //   VLOG(1) << "item not found in item matrix [" << key << "]";
  // } else {
  //   if (item_fea_vec.weight_size() != ((int)base_info.fea_num() + 1)) {
  //     LOG(ERROR) << "user feature vector size error ["
  //                << item_fea_vec.weight_size() << ", " << base_info.fea_num() << "]";
  //     return 0;
  //   }
  //   score += item_fea_vec.weight(0);
  // }

  // if (user_fea_vec.weight_size() > 0 &&
  //     item_fea_vec.weight_size() > 0) {
  //   for (int i = 0; i < (int)base_info.fea_num(); ++i) {
  //     score += user_fea_vec.weight(i+1) * item_fea_vec.weight(i+1);
  //   }
  // }
  // score = 1 / (1 + exp(-score));
  // return score;
  return 0;
}

void mf_predict(thread::BlockingQueue<uint64>* user_queue,
                std::vector<uint64>* item_vec,
                reco::HBasePoolGetItem* get_item,
                thread::Mutex* get_lock) {
  using namespace reco::leafserver;
  std::vector<uint64> items(*item_vec);
  while (!user_queue->Empty()) {
    uint64 user_id;
    int ret = user_queue->TryTake(&user_id);
    if (ret != 1) continue;
    // ModelBufMgr::instance().AddUser(user_id);
    base::PseudoRandom random(base::GetTimestamp());
    int cut = std::min((int)items.size(), FLAGS_predict_num);
    for (int i = 0; i < cut; ++i) {
      if ((int)items.size()-1 > i+1) {
        int j = random.GetInt(i+1, (int)items.size() - 1);
        std::swap(items.at(i), items.at(j));
      }
    }
    TopN<uint64> topn(FLAGS_topn);
    for (int i = 0; i < cut; ++i) {
      double score = predict(user_id, items[i]);
      topn.add(items[i], score);
    }
    if (FLAGS_output) {
      std::vector<uint64> item_list;
      topn.get_top_n(&item_list);
      for (size_t i = 0; i < item_list.size(); ++i) {
        thread::AutoLock lock(get_lock);
        reco::RecoItem item;
        get_item->GetRecoItem(item_list[i], &item);
        LOG(INFO) << user_id << "\t" << item.title();
      }
    }
  }
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  reco::redis::RedisCliPoolIns::instance().Init();
  reco::leafserver::ModelBufMgr::instance().Init();
  reco::HBasePoolGetItem get_item(FLAGS_hbase_table_name, 1000);
  thread::Mutex get_lock;

  std::vector<std::string> lines;
  if (!FLAGS_user_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_user_id_file, &lines);
  }
  if (!FLAGS_user_id.empty()) {
    lines.push_back(FLAGS_user_id);
  }
  thread::BlockingQueue<uint64> user_queue;
  for (size_t i = 0; i < lines.size(); ++i) {
    user_queue.Put(base::ParseUint64OrDie(lines[i]));
  }

  lines.clear();
  if (!FLAGS_item_id_file.empty()) {
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines);
  }
  if (!FLAGS_item_id.empty()) {
    lines.push_back(FLAGS_item_id);
  }
  std::vector<uint64> item_vec;
  for (size_t i = 0; i < lines.size(); ++i) {
    item_vec.push_back(base::ParseUint64OrDie(lines[i]));
  }

  thread::ThreadPool thread_pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    thread_pool.AddTask(NewCallback(mf_predict, &user_queue, &item_vec, &get_item, &get_lock));
  }

  // int ver = 0;
  // int t = 0;
  // while (true) {
  //   ver = 1 - ver;
  //   reco::leafserver::ModelBufMgr::instance().NeedExchangeMatrixBuf(base::IntToString(ver));
  //   base::SleepForSeconds(30*60);
  //   if (++t > 20) {
  //     break;
  //   }
  // }

  thread_pool.JoinAll();
  return 0;
}
