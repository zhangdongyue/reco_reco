#include <iostream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/reco_user_server.pb.h"
#include "reco/bizc/proto/item.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20001, "leaf server port");
DEFINE_string(user_server_ip, "127.0.0.1", "user server ip");
DEFINE_int32(user_server_port, 20002, "user server port");

DEFINE_string(user_id, "", "user id");
DEFINE_string(app_token, "uc-iflow", "doc server ip");

DEFINE_string(news_date, "", "news date");
DEFINE_string(region_id, "", "region id");
DEFINE_int32(return_num, 8, "return num");
DEFINE_int32(reco_type, 0, "recommend type, default 0, news");
DEFINE_int64(channel_id, 100, "channel id");
DEFINE_string(subscriptions, "", "subscription words");
DEFINE_string(subscript_time, "2015-10-15 10:00:00", "subscription words");

DEFINE_string(category, "", "requre category");
DEFINE_string(last_item_time, "", "");
DEFINE_bool(for_update, true, "");

bool BuildUserInfo(reco::UserInfo* user) {
  net::rpc::RpcClientChannel channel(FLAGS_user_server_ip.c_str(), FLAGS_user_server_port);
  CHECK(channel.Connect());
  reco::userserver::UserService::Stub stub(&channel);

  reco::userserver::GetUserRequest request;
  reco::userserver::GetUserResponse response;

  uint64 user_id;
  CHECK(base::StringToUint64(FLAGS_user_id, &user_id));
  reco::UserIdentity user_identity;
  user_identity.set_app_token(FLAGS_app_token);
  user_identity.set_outer_id(FLAGS_user_id);
  user_identity.set_user_id(user_id);
  request.mutable_user()->CopyFrom(user_identity);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(500);
  stub.getUserInfo(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "get user info fail. ";
    return false;
  } else {
    user->CopyFrom(response.user_info());
  }

  if (!FLAGS_subscriptions.empty()) {
    std::vector<std::string> flds;
    base::SplitString(FLAGS_subscriptions, ",", &flds);
    reco::Subscription subscript;
    for (int i = 0; i < (int)flds.size(); ++i) {
      subscript.add_subscription(flds[i]);
      subscript.add_setting_time(FLAGS_subscript_time);
    }
    user->mutable_subscription()->CopyFrom(subscript);
    LOG(INFO) << "subscription: " << user->subscription().Utf8DebugString();
  }

  return true;
}

bool BuildRecoRequest(reco::leafserver::RecommendRequest* reco_request) {
  reco::leafserver::RecommendRequest request;

  uint64 uid;
  CHECK(base::StringToUint64(FLAGS_user_id, &uid));

  reco::UserIdentity user;
  std::string key = base::StringPrintf("uid-%lu-%ld", uid, base::GetTimestamp());
  uint64 reco_id = base::CalcTermSign(key.c_str(), key.size());
  user.set_user_id(uid);
  user.set_app_token(FLAGS_app_token);
  user.set_outer_id(FLAGS_user_id);
  request.set_app_token(FLAGS_app_token);
  request.set_return_num(FLAGS_return_num);
  request.mutable_user()->CopyFrom(user);
  request.set_reco_id(base::Uint64ToString(reco_id));
  request.set_recommend_type(FLAGS_reco_type);
  if (FLAGS_app_token == reco::common::kUCBIflowUser) {
    reco::leafserver::UcBrowserUserParam param;
    param.set_province("广东");
    param.set_city("广州");
    request.mutable_uc_user_param()->CopyFrom(param);
  }
  if (FLAGS_channel_id != reco::common::kRecoChannelId) {
    request.set_channel_id(FLAGS_channel_id);
  }
  if (!FLAGS_news_date.empty()) {
    request.set_news_date(FLAGS_news_date);
  } else if (!FLAGS_category.empty()) {
    // TODO
  }
  if (!FLAGS_region_id.empty()) {
    request.set_region_id(FLAGS_region_id);
  }

  reco_request->CopyFrom(request);

  return true;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client");

  reco::UserInfo user_info;
  reco::leafserver::DebugRecommendRequest debug_request;
  reco::leafserver::RecommendRequest reco_request;
  reco::leafserver::RecommendResponse response;

  CHECK(BuildUserInfo(&user_info));
  CHECK(BuildRecoRequest(&reco_request));
  debug_request.mutable_user_info()->CopyFrom(user_info);
  debug_request.mutable_request()->CopyFrom(reco_request);

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  stub.debugRecommend(&rpc, &debug_request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "recommend fail.";
  } else {
    for (int i = 0; i < response.result_size(); ++i) {
      LOG(INFO) << response.result(i).Utf8DebugString();
    }
  }

  return 0;
}
