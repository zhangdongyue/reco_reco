#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/scoped_ptr.h"
#include "net/rpc/rpc.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/item.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20011, "leaf server port");
DEFINE_string(start_time, "2015-01-16 00:00:00", "request news start time");
DEFINE_string(end_time, "2015-01-17 00:00:00", "request news end time");
DEFINE_string(category, "", "request news's category");
DEFINE_int64(channel_id, 0, "request news's channel id");
DEFINE_int32(max_return_num, 3000, "max return num");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "related item client");

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  reco::leafserver::GetHotNewsRequest request;
  reco::leafserver::GetHotNewsResponse response;

  request.set_start_time(FLAGS_start_time);
  request.set_end_time(FLAGS_end_time);
  request.set_max_return_num(FLAGS_max_return_num);
  if (!FLAGS_category.empty()) {
    request.set_category(FLAGS_category);
  }
  if (FLAGS_channel_id != 0) {
    request.set_channel_id(FLAGS_channel_id);
  }

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  stub.getHotNews(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "get hot news fail.";
    return 0;
  }
  std::cout << "total hot news count, " << response.hot_news_size() << std::endl;
  for (int i = 0; i < response.hot_news_size(); ++i) {
    const reco::leafserver::HotNewsInfo& info = response.hot_news(i);
    std::cout << info.item_id() << "\t" << info.item_time() << "\t" << info.item_title()
              << "\t" << info.item_category(0) << "\t" << info.hot_score() << std::endl;
  }
  return 0;
}
