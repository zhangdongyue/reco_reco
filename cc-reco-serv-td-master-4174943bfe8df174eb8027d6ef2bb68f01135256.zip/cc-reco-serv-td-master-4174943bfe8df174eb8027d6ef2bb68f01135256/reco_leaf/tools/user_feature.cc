#include "reco/serv/reco_leaf/tools/user_feature.h"

#include <algorithm>

#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

#include "serving_base/data_manager/data_manager.h"
#include "nlp/common/nlp_util.h"

#include "base/time/timestamp.h"
#include "base/hash_function/term.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_tokenize.h"
#include "base/strings/string_printf.h"
#include "base/common/logging.h"

namespace reco {
namespace leafserver {
DEFINE_int32(recent_click_expire_hours, 2, "");
DEFINE_int32(max_user_keyword_fea_num, 60, "");
DEFINE_int32(max_user_topic_fea_num, 20, "");
DEFINE_int32(max_user_tag_fea_num, 30, "");

DEFINE_string(leaf_data_dir, "/serving/leaf_server/data", "");

const char* UserFeature::kChannelCategoryFile  = "channel_category.txt";
const char* UserFeature::kUserRoleKeywordFile  = "user_role_keyword.txt";
const char* UserFeature::kUserRoleCategoryFile = "user_role_category.txt";
const char* UserFeature::kTimeCategoryBoostFile = "time_category_boost.txt";


bool FeaWeightSortFunc(const std::pair<std::string, double>& left,
                       const std::pair<std::string, double>& right) {
  if (left.second != right.second) {
    return left.second > right.second;
  }
  return left.first <= right.first;
}

UserFeature::UserFeature(const reco::NewsIndex* index) {
  news_index_ = index;
  // UserFeature* global_data = LeafDataManager::GetUserFeature();
  // channel_categories_ = &global_data->channel_categories;
  // user_role_categories_ = &global_data->user_role_categories;
  // user_role_keywords_ = &global_data->user_role_keywords;
}

UserFeature::~UserFeature() {
}

void UserFeature::ResetUser(const reco::UserInfo* user_info, bool debug_user) {
  user_info_ = user_info;
  current_time_ = base::Time::Now();
  is_debug_user_ = debug_user;
}

void UserFeature::MergeUserFeature() {
  PreProcessFeature();

  // 生成用户长期兴趣点向量
  MergeLongTermFeature();
  if (is_debug_user_) {
    PrintUserFeature("long term feature");
  }
  // 生成用户短期兴趣点向量
  MergeShortTermFeature();
  if (is_debug_user_) {
    PrintUserFeature("short term feature");
  }
  // dmp 冷启动 特征
  MergeDmpFeature();
  if (is_debug_user_) {
    PrintUserFeature("dmp feature");
  }
  // 微薄数据抽取的特征
  MergeWeiboFeature();
  // 频道选择特征
  MergeChannelFeature();
  if (is_debug_user_) {
    PrintUserFeature("channel feature");
  }
  // 用户角色特征
  MergeRoleFeature();
  if (is_debug_user_) {
    PrintUserFeature("role feature");
  }
  // 展现历史特征
  MergeShowFeature();
  if (is_debug_user_) {
    PrintUserFeature("show history feature");
  }
  // 屏幕选择特征
  MergeScreenFeature();
  if (is_debug_user_) {
    PrintUserFeature("screen feature");
  }
  // 不喜欢新闻特征
  MergeDislikeFeature();
  if (is_debug_user_) {
    PrintUserFeature("dislike feature");
  }

  PostProcessFeature();
  if (is_debug_user_) {
    PrintUserFeature("final feature");
  }
CalcCategoryDistributes();
}

void UserFeature::MergeLongTermFeature() {
  if (!user_info_->has_profile()) return;
  // 1 Keyword Fea
  const reco::Profile& profile = user_info_->profile();
  if (profile.has_keyword_feavec()) {
    const reco::FeatureVector& fea_vec = profile.keyword_feavec();
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      const reco::Feature& fea = fea_vec.feature(i);
      if (!fea.has_category()) {
        LOG(WARNING) << "keyword feature has no category, " << fea.Utf8DebugString();
        continue;
      }
      FeatureMap& keywords = category_keywords_[fea.category()];
      if (fea.has_item_type() && fea.item_type() == reco::kNews) {
        AddFeature(fea, 1.0, &keywords);
      }
    }
    for (auto iter = category_keywords_.begin(); iter != category_keywords_.end(); ++iter) {
      SelectFeature(&iter->second, FLAGS_max_user_keyword_fea_num);
      NormalizeFeature(&iter->second);
    }
  }
  // 2. tag Fea
  if (profile.has_tag_feavec()) {
    const reco::FeatureVector& fea_vec = profile.tag_feavec();
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      const reco::Feature& fea = fea_vec.feature(i);
      if (!fea.has_category()) {
        LOG(WARNING) << "tag feature has no category, " << fea.Utf8DebugString();
        continue;
      }
      FeatureMap& tags = category_tags_[fea.category()];
      if (fea.has_item_type() && fea.item_type() == reco::kNews) {
        AddFeature(fea, 1.0, &tags);
      }
    }
    for (auto iter = category_tags_.begin(); iter != category_tags_.end(); ++iter) {
      SelectFeature(&iter->second, FLAGS_max_user_tag_fea_num);
      NormalizeFeature(&iter->second);
    }
  }
  // 3. topic
  if (profile.has_topic_feavec()) {
    for (int i = 0; i < profile.topic_feavec().feature_size(); ++i) {
      const reco::Feature& fea = profile.topic_feavec().feature(i);
      if (fea.has_item_type() && fea.item_type() == reco::kNews) {
        AddFeature(fea, 1.0, &user_topics_);
      }
    }
    NormalizeFeature(&user_topics_);
  }
  // 4. word vec
  // 5. category
  if (profile.has_category_feavec()) {
    const reco::CategoryFeatureVector& fea_vec = profile.category_feavec();
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      const reco::CategoryFeature& fea = fea_vec.feature(i);
      // NOTE(jianhuang) 暂时去掉，后续确认长期兴趣有item_type再重启
      if (!fea.has_item_type() || fea.item_type() != reco::kNews) {
        LOG_IF(WARNING, is_debug_user_) << "user " << user_info_->identity().user_id()
                                        << " has feature of no kNews.";
        continue;
      }
      if (fea.literal().level() == 0) {
        AddFeature(fea, 1.0, &user_categories_);
      } else if (fea.literal().parents_size() > 0) {
        // NOTE(jianhuang) 在 UserDeadom 会做这个事情
        // Category con_category;
        // con_category.set_category(fea.literal().parents(0));
        // con_category.set_level(0);
        // CategoryFeature con_fea;
        // con_fea.mutable_literal()->CopyFrom(con_category);
        // con_fea.set_item_type(reco::kNews);
        // con_fea.set_weight(fea.weight());
        // AddFeature(con_fea, 1.0, &user_categories_);
      }
    }
    NormalizeFeature(&user_categories_);
  }
}

void UserFeature::MergeShortTermFeature() {
  base::Time earliest_click_time =
      current_time_ - base::TimeDelta::FromHours(FLAGS_recent_click_expire_hours);
  if (user_info_->has_profile_snapshot()) {
    const reco::ProfileSnapshot& snapshot = user_info_->profile_snapshot();
    base::Time snapshot_time;
    if (!base::Time::FromStringInFormat(snapshot.snapshot_time().c_str(),
                                        "%Y-%m-%d %H:%M:%S", &snapshot_time)) {
      LOG(ERROR) << "parse snapshort time error, " << snapshot.snapshot_time();
    } else if (earliest_click_time > snapshot_time) {
      earliest_click_time = snapshot_time;
    }
  } else {
    LOG(WARNING) << "user has no snapshot_time, user " << user_info_->identity().user_id();
  }

  int64 earliest_click_timestamp = earliest_click_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  double click_weight = 0.0;
  double click_idx_boost = 1;
  int click_count = 0;
  std::string category, key;
  std::unordered_set<uint64> uniq_ids;
  for (int i = user_info_->recent_click_size() - 1; i >= 0; --i) {
    if (click_count >= 100) break;

    const reco::ViewClickItem& clicked_item = user_info_->recent_click().Get(i);
    ItemType item_type;
    if (!news_index_->GetItemTypeByItemId(clicked_item.item_id(), &item_type))
      item_type = reco::kNews;

    if (item_type != reco::kNews) {
      continue;
    }

    if (uniq_ids.find(clicked_item.item_id()) != uniq_ids.end())
      continue;
    uniq_ids.insert(clicked_item.item_id());

    // 点击发生时间过于久远, 丢弃
    if (clicked_item.click_timestamp() < earliest_click_timestamp) {
      VLOG(1) << "filter out recent click at: " << clicked_item.click_timestamp()
              << ", which is longer than " << earliest_click_timestamp;
      // 按时间有序, 可以 break
      break;
    }

    ItemInfo item;
    if (!news_index_->GetItemInfoByItemId(clicked_item.item_id(), &item, false)
        || item.item_type != item_type || item.category.empty()) {
      LOG(ERROR) << "get item info error, item " << clicked_item.item_id();
      continue;
    }

    // 抽取 category 特征
    category = item.category;
    click_weight = CalcRecentClickInfluence(category) * click_idx_boost;
    {
      reco::CategoryFeature fea;
      reco::Category reco_category;
      reco_category.set_category(category);
      reco_category.set_level(0);
      fea.mutable_literal()->CopyFrom(reco_category);
      fea.set_weight(1);
      AddFeature(fea, click_weight, &user_categories_);
    }
    // 抽取 topic 特征
    reco::FeatureVector feature_vec;
    if (news_index_->GetFeatureVectorByItemId(clicked_item.item_id(), reco::common::kTopic, &feature_vec)) {
      AddFeature(feature_vec, click_weight, &user_topics_);
    }
    // 抽取 keyword 特征
    if (!category.empty() &&
        news_index_->GetFeatureVectorByItemId(clicked_item.item_id(), reco::common::kKeyword, &feature_vec)) {
      FeatureMap& keywords = category_keywords_[category];
      AddFeature(feature_vec, click_weight, &keywords);
    }
    // 抽取 tag 特征
    if (!category.empty() &&
        news_index_->GetFeatureVectorByItemId(clicked_item.item_id(), reco::common::kTag, &feature_vec)) {
      FeatureMap& tags = category_tags_[category];
      AddFeature(feature_vec, click_weight, &tags);
    }

    click_idx_boost *= 0.95;
    click_count += 1;
  }
}

void UserFeature::MergeDmpFeature() {
  if (!user_info_->has_dmp_profile()) return;
  const float kInfluence = (1 - user_info_->recent_click_size() / 100.0) * 0.2;
  if (kInfluence < 1e-6) return;
  // 1 Keyword Fea
  std::string key;
  const reco::DmpProfile& dmp_profile = user_info_->dmp_profile();
  if (dmp_profile.has_keyword_feavec()) {
    const reco::FeatureVector& fea_vec = dmp_profile.keyword_feavec();
    float sum_weight = 0;
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      sum_weight += fea_vec.feature(i).weight();
    }
    if (sum_weight > 1e-6) {
      for (int i = 0; i < fea_vec.feature_size(); ++i) {
        const reco::Feature& fea = fea_vec.feature(i);
        if (!fea.has_category()) {
          LOG(WARNING) << "keyword feature has no category, " << fea.Utf8DebugString();
          continue;
        }
        FeatureMap& keywords = category_keywords_[fea.category()];
        if (fea.has_item_type() && fea.item_type() == reco::kNews) {
          AddFeature(fea, kInfluence * fea.weight() / sum_weight, &keywords);
        }
      }
    }
  }
  // 2. tag Fea
  if (dmp_profile.has_tag_feavec()) {
    const reco::FeatureVector& fea_vec = dmp_profile.tag_feavec();
    float sum_weight = 0;
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      sum_weight += fea_vec.feature(i).weight();
    }
    if (sum_weight > 1e-6) {
      for (int i = 0; i < fea_vec.feature_size(); ++i) {
        const reco::Feature& fea = fea_vec.feature(i);
        if (!fea.has_category()) {
          LOG(WARNING) << "tag feature has no category, " << fea.Utf8DebugString();
          continue;
        }
        FeatureMap& tags = category_tags_[fea.category()];
        if (fea.has_item_type() && fea.item_type() == reco::kNews) {
          AddFeature(fea, kInfluence * fea.weight() / sum_weight, &tags);
        }
      }
    }
  }
  // 3. topic
  if (dmp_profile.has_topic_feavec()) {
    const reco::FeatureVector& fea_vec = dmp_profile.topic_feavec();
    float sum_weight = 0;
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      sum_weight += fea_vec.feature(i).weight();
    }
    if (sum_weight > 1e-6) {
      for (int i = 0; i < fea_vec.feature_size(); ++i) {
        const reco::Feature& fea = fea_vec.feature(i);
        if (fea.has_item_type() && fea.item_type() == reco::kNews) {
          AddFeature(fea, kInfluence * fea.weight() / sum_weight, &user_topics_);
        }
      }
    }
  }
  // 4. word vec
  // 5. category
  if (dmp_profile.has_category_feavec()) {
    const reco::CategoryFeatureVector& fea_vec = dmp_profile.category_feavec();
    float sum_weight = 0;
    for (int i = 0; i < fea_vec.feature_size(); ++i) {
      sum_weight += fea_vec.feature(i).weight();
    }
    if (sum_weight > 1e-6) {
      for (int i = 0; i < fea_vec.feature_size(); ++i) {
        const reco::CategoryFeature& fea = fea_vec.feature(i);
        if (fea.has_item_type() && fea.item_type() == reco::kNews && fea.literal().level() == 0) {
          // 暂时只要一级的 category 数据
          AddFeature(fea, kInfluence * fea.weight() / sum_weight, &user_categories_);
        }
      }
    }
  }
}

void UserFeature::MergeWeiboFeature() {
  if (!user_info_->has_weibo_info()) return;

  const reco::WeiboInfo& weibo_info = user_info_->weibo_info();
  // TODO (jianhuang) 上线后根据数据调节这组参数, 或者平滑之
  double weibo_fea_discount = 1;
  if (user_info_->shown_history_size() >= 1000) {
    weibo_fea_discount = 0.2;
  } else if (user_info_->shown_history_size() >= 100) {
    weibo_fea_discount = 0.5;
  }
  for (int i = 0; i < weibo_info.categories_size(); ++i) {
    const reco::CategoryFeature& fea = weibo_info.categories(i);
    if (fea.has_item_type() && fea.item_type() == reco::kNews) {
      AddFeature(fea, weibo_fea_discount, &user_categories_);
    }
  }
  for (int i = 0; i < weibo_info.tags_size(); ++i) {
    const reco::Feature& fea = weibo_info.tags(i);
    if (fea.has_item_type() && fea.item_type() == reco::kNews) {
      AddFeature(fea, weibo_fea_discount, &user_keywords_);
    }
  }
}

void UserFeature::MergeChannelFeature() {
  if (!user_info_->has_channel_info()
      || user_info_->channel_info().new_channel_list_size() == 0) {
    return;
  }

  const reco::ChannelInfo& channel_info = user_info_->channel_info();
  base::Time set_time;
  if (!base::Time::FromStringInFormat(channel_info.setting_time().c_str(),
                                      "%Y-%m-%d %H:%M:%S", &set_time)) {
    LOG(WARNING) << "channel settime format error, " << channel_info.setting_time();
    return;
  }

  base::TimeDelta delta = current_time_ - set_time;
  int hour_interval = delta.InHours();
  int day_interval  = delta.InDays();

  // 调整的时间已经过去很久而且积累点击已经很多时，不再使用用户选屏数据
  const int kExpiredDay = 7;
  if ((day_interval >= kExpiredDay && user_info_->recent_click_size() >= 10)
      || hour_interval < 0) {
    return;
  }

  // 新老订阅的频道
  std::unordered_set<int64> curr_channels;
  std::unordered_set<int64> prev_channels;
  for (int i = 0; i < channel_info.old_channel_list_size(); ++i) {
    prev_channels.insert(channel_info.old_channel_list(i));
  } 
  int curr_channel_size = channel_info.new_channel_list_size();

  // 当前选择的 channel 进行绝对值加权
  reco::Category category;
  reco::CategoryFeature category_fea;
  float influence = std::max((kExpiredDay - day_interval) * 0.04 / curr_channel_size,
                             0.02 / curr_channel_size);
  for (int i = 0; i < channel_info.new_channel_list_size(); ++i) {
    int64 channel_id = channel_info.new_channel_list(i);
    if (curr_channels.find(channel_id) != curr_channels.end()) continue;
    curr_channels.insert(channel_id);
    auto cate_iter = channel_categories.find(channel_id);
    if (cate_iter == channel_categories.end()) continue;
    const std::vector<std::pair<std::string, float> >& categories = cate_iter->second;
    for (int j = 0; j < (int)categories.size(); ++j) {
      if (categories[j].second <= 1e-6) continue;
      category.set_level(0);
      category.set_category(categories[j].first);
      category_fea.mutable_literal()->CopyFrom(category);
      category_fea.set_weight(categories[j].second);
      AddFeature(category_fea, influence, &user_categories_);
    }
    influence *= 0.9;
  }
  // 如果订阅的时间离现在很近, 需要对新订阅频道进行加权，同时对取消订阅的频道进行降权
  if (hour_interval < 24) {
    // 对新增订阅的频道加权
    for (auto curr_iter = curr_channels.begin(); curr_iter != curr_channels.end(); ++curr_iter) {
      if (prev_channels.find(*curr_iter) != prev_channels.end()) continue;
      auto cate_iter = channel_categories.find(*curr_iter);
      if (cate_iter == channel_categories.end()) continue;
      const std::vector<std::pair<std::string, float> >& categories = cate_iter->second;
      for (int i = 0; i < (int) categories.size(); ++i) {
        double boost = 1 + ((24 - hour_interval)) * 0.02 * categories[i].second;
        auto user_iter = user_categories_.find(categories[i].first);
        if (user_iter != user_categories_.end()) {
          user_iter->second *= boost;
        }
      }
    }
    // 对取消订阅的频道降权
    for (auto prev_iter = prev_channels.begin(); prev_iter != prev_channels.end(); ++prev_iter) {
      if (curr_channels.find(*prev_iter) != curr_channels.end()) continue;
      auto cate_iter = channel_categories.find(*prev_iter);
      if (cate_iter == channel_categories.end()) continue;
      const std::vector<std::pair<std::string, float> >& categories = cate_iter->second;
      for (int i = 0; i < (int) categories.size(); ++i) {
        double boost = std::max(1 - ((24 - hour_interval)) * 0.02 * categories[i].second, 0.1);
        auto user_iter = user_categories_.find(categories[i].first);
        if (user_iter != user_categories_.end()) {
          user_iter->second *= boost;
        }
      }
    }
  }
}

void UserFeature::MergeRoleFeature() {
  if (!user_info_->has_user_role() || user_info_->user_role().role_info_size() == 0) return;

  const reco::UserRole& user_role = user_info_->user_role();
  base::Time set_time;
  if (!base::Time::FromStringInFormat(user_role.setting_time().c_str(),
                                      "%Y-%m-%d %H:%M:%S", &set_time)) {
    LOG(WARNING) << "user role settime format error, " << user_role.setting_time();
    return;
  }

  base::TimeDelta delta = current_time_ - set_time;
  int day_interval  = delta.InDays();

  // 调整的时间已经过去很久而且积累点击已经很多时，不再使用用户角色数据
  const int kExpiredDay = 7;
  if ((day_interval >= kExpiredDay && user_info_->recent_click_size() >= 10)
      || day_interval < 0) {
    return;
  }

  std::unordered_map<std::string, std::unordered_set<std::string> > user_roles;
  for (int i = 0; i < user_role.role_info_size(); ++i) {
    const reco::RoleInfo& role = user_role.role_info(i);
    std::unordered_set<std::string>& attr_set = user_roles[nlp::util::NormalizeLine(role.role_name())];
    for (int j = 0; j < role.role_attr_size(); ++j) {
      attr_set.insert(role.role_attr(j));
    }
  }

  // 影响 category 分布, 绝对值的影响
  reco::Category category;
  reco::CategoryFeature category_fea;
  float kInfluenceRatio = std::max((kExpiredDay - day_interval) * 0.03 / user_roles.size(),
                                   0.015 / user_roles.size());
  for (auto iter = user_roles.begin(); iter != user_roles.end(); ++iter) {
    auto cate_iter = user_role_categories.find(iter->first);
    if (cate_iter == user_role_categories.end()) continue;
    const std::vector<std::pair<std::string, float> >& categories = cate_iter->second;
    for (int i = 0; i < (int)categories.size(); ++i) {
      if (categories[i].second <= 1e-6) continue;
      category.set_level(0);
      category.set_category(categories[i].first);
      category_fea.mutable_literal()->CopyFrom(category);
      category_fea.set_weight(categories[i].second);
      AddFeature(category_fea, kInfluenceRatio, &user_categories_);
    }
  }

  // 影响 keyword 分布, 绝对值的影响
  std::string key;
  double weight = 0;
  kInfluenceRatio = std::max((kExpiredDay - day_interval) * 0.01 / user_roles.size(), 0.005 / user_roles.size());
  for (auto iter = user_roles.begin(); iter != user_roles.end(); ++iter) {
    const std::unordered_set<std::string>& keywords = iter->second;
    if (keywords.empty()) continue;
    auto cate_iter = user_role_categories.find(iter->first);
    if (cate_iter == user_role_categories.end()) continue;

    const std::vector<std::pair<std::string, float> >& categories = cate_iter->second;
    reco::Feature fea;
    float kw_weight = 1.0 / keywords.size();
    for (auto kw_iter = keywords.begin(); kw_iter != keywords.end(); ++kw_iter) {
      for (int j = 0; j < (int)categories.size(); ++j) {
        FeatureMap& cate_keywords = category_keywords_[categories[j].first];
        key = genCategoryWordKey(categories[j].first, *kw_iter);
        weight = kw_weight * categories[j].second;
        fea.set_item_type(reco::kNews);
        fea.set_literal(key);
        fea.set_weight(weight);
        AddFeature(fea, kInfluenceRatio, &cate_keywords);
      }
    }
  }

  // TODO(jianhuang) 添加一批好关键词词表
  // for (auto iter = user_roles.begin(); iter != user_roles.end(); ++iter) {
  //   auto cate_iter = user_role_categories_->find(iter->first);
  //   auto kw_iter = user_role_keywords_->find(iter->first);
  //   if (kw_iter == user_role_keywords_->end()
  //       || cate_iter == user_role_categories_->end()) {
  //     continue;
  //   }
  //   const std::vector<std::pair<std::string, float> >& keywords = kw_iter->second;
  //   const std::vector<std::pair<std::string, float> >& categories = cate_iter->second;
  //   reco::Feature fea;
  //   for (int i = 0; i < (int)keywords.size(); ++i) {
  //     if (keywords[i].second <= 1e-6) continue;
  //     for (int j = 0; j < (int)categories.size(); ++j) {
  //       FeatureMap& cate_keywords = category_keywords_[categories[j].first];
  //       key = genCategoryWordKey(categories[j].first, keywords[i].first);
  //       weight = keywords[i].second * categories[j].second;
  //       fea.set_item_type(reco::kNews);
  //       fea.set_literal(key);
  //       fea.set_weight(weight);
  //       AddFeature(fea, kInfluenceRatio, &cate_keywords);
  //     }
  //   }
  // }
}

void UserFeature::MergeScreenFeature() {
  base::Time expire_time = current_time_ - base::TimeDelta::FromHours(7 * 24);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  std::unordered_map<std::string, float> screen_ratio_map;
  std::vector<reco::Category> categories;
  std::string category;
  for (int i = user_info_->shown_history_size() - 1; i >= 0; --i) {
    const reco::ViewClickItem& show_item = user_info_->shown_history(i);
    if (show_item.view_timestamp() < expire_timestamp) break;
    // 只要非推荐频道的展现
    if (show_item.has_channel_id() && show_item.channel_id() == 100) continue;
    categories.clear();
    if (!news_index_->GetCategoriesByItemId(show_item.item_id(), &categories)
        || categories.empty()) {
      // LOG(WARNING) << "item can't find category, " << show_item.item_id();
      continue;
    }
    category.clear();
    for (int j = 0; j < (int)categories.size(); ++j) {
      if (categories[j].level() == 0) {
        category = categories[j].category();
        break;
      }
    }
    if (category.empty()) continue;
    screen_ratio_map[category] += 1;
  }
  std::vector<std::pair<std::string, float> > screen_ratio_vec;
  float sum_weight = 0;
  for (auto iter = screen_ratio_map.begin(); iter != screen_ratio_map.end(); ++iter) {
    sum_weight += iter->second;
    screen_ratio_vec.push_back(std::make_pair(iter->first, iter->second));
  }
  if (sum_weight <= 1e-6) return;
  std::sort(screen_ratio_vec.begin(), screen_ratio_vec.end(), FeaWeightSortFunc);
  for (int i = 0; i < (int)screen_ratio_vec.size(); ++i) {
    float ratio = screen_ratio_vec[i].second / sum_weight;
    if (ratio < 0.3) break;
    float weight = std::max(user_categories_[screen_ratio_vec[i].first], 0.1);
    float boost = std::min(1 + ratio * screen_ratio_vec[i].second / 300, 3.0f);
    user_categories_[screen_ratio_vec[i].first] = weight * boost;
  }
}

void UserFeature::MergeShowFeature() {
  // 用户近期展现/点击分布
  typedef std::unordered_map<std::string, std::pair<float, float> > ShowClickInfo;
  ShowClickInfo category_infos;
  std::unordered_map<std::string, ShowClickInfo> cate_tag_infos;
  std::unordered_map<std::string, ShowClickInfo> cate_keyword_infos;
  std::unordered_set<uint64> click_ids;
  for (int i = 0; i < user_info_->recent_click_size(); ++i) {
    click_ids.insert(user_info_->recent_click(i).item_id());
  }
  base::Time expire_time = current_time_ - base::TimeDelta::FromHours(7 * 24);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  std::vector<reco::Category> categories;
  reco::FeatureVector fea_vec;
  std::string category;
  for (int i = user_info_->shown_history_size() - 1;
       i >= 0 && i >= user_info_->shown_history_size() - 500; --i) {
    const reco::ViewClickItem& show_item = user_info_->shown_history(i);
    if (show_item.view_timestamp() < expire_timestamp) break;
    // // 只要推荐频道的展现
    if (show_item.has_channel_id() && show_item.channel_id() != 100) continue;
    int click = click_ids.find(show_item.item_id()) != click_ids.end();
    categories.clear();
    if (!news_index_->GetCategoriesByItemId(show_item.item_id(), &categories)
        || categories.empty()) {
      continue;
    }
    category.clear();
    for (int j = 0; j < (int)categories.size(); ++j) {
      if (categories[j].level() == 0) {
        category = categories[j].category();
        break;
      }
    }
    if (category.empty()) continue;
    category_infos[category].first  += 1;
    category_infos[category].second += click;
    fea_vec.clear_feature();
    ShowClickInfo& keyword_infos = cate_keyword_infos[category];
    if (news_index_->GetFeatureVectorByItemId(show_item.item_id(), reco::common::kKeyword, &fea_vec)) {
      for (int j = 0; j < fea_vec.feature_size(); ++j) {
        const reco::Feature& fea = fea_vec.feature(j);
        keyword_infos[fea.literal()].first  += fea.weight();
        keyword_infos[fea.literal()].second += fea.weight() * click;
      }
    }
    fea_vec.clear_feature();
    ShowClickInfo& tag_infos = cate_tag_infos[category];
    if (news_index_->GetFeatureVectorByItemId(show_item.item_id(), reco::common::kTag, &fea_vec)) {
      for (int j = 0; j < fea_vec.feature_size(); ++j) {
        const reco::Feature& fea = fea_vec.feature(j);
        tag_infos[fea.literal()].first  += fea.weight();
        tag_infos[fea.literal()].second += fea.weight() * click;
      }
    }
  }
  // 展现量大且点击率低的 category 降权
  float kMinCtr = 0.05;
  for (auto iter = category_infos.begin(); iter != category_infos.end(); ++iter) {
    if (iter->second.first < 10
        || iter->second.second > kMinCtr * iter->second.first) {
      continue;
    }
    auto user_iter = user_categories_.find(iter->first);
    if (user_iter == user_categories_.end()) continue;
    float ctr_boost = 1 - (iter->second.second / kMinCtr) / iter->second.first;
    float show_boost = iter->second.first / 20;
    float boost = std::max(0.01f, 1 - ctr_boost * show_boost);
    user_iter->second *= boost;
  }
  // 展现量大且点击率低的 关键词 降权
  for (auto iter = cate_keyword_infos.begin(); iter != cate_keyword_infos.end(); ++iter) {
    const ShowClickInfo& infos = iter->second;
    FeatureMap& keywords = category_keywords_[iter->first];
    for (auto iter2 = infos.begin(); iter2 != infos.end(); ++iter2) {
      if (iter2->second.first < 3
          || iter2->second.second > kMinCtr * iter2->second.first) {
        continue;
      }
      auto kw_iter = keywords.find(iter2->first);
      if (kw_iter == keywords.end()) continue;
      float ctr_boost = 1 - (iter2->second.second / kMinCtr) / iter2->second.first;
      float show_boost = iter2->second.first / 5;
      float boost = std::max(0.01f, 1 - ctr_boost * show_boost);
      kw_iter->second *= boost;
    }
  }
  // 展现量大且点击率低的 tag 降权
  for (auto iter = cate_tag_infos.begin(); iter != cate_tag_infos.end(); ++iter) {
    const ShowClickInfo& infos = iter->second;
    FeatureMap& tags = category_tags_[iter->first];
    for (auto iter2 = infos.begin(); iter2 != infos.end(); ++iter2) {
      if (iter2->second.first < 5
          || iter2->second.second > kMinCtr * iter2->second.first) {
        continue;
      }
      auto tag_iter = tags.find(iter2->first);
      if (tag_iter == tags.end()) continue;
      float ctr_boost = 1 - (iter2->second.second / kMinCtr) / iter2->second.first;
      float show_boost = iter2->second.first / 5;
      float boost = std::max(0.01f, 1 - ctr_boost * show_boost);
      tag_iter->second *= boost;
    }
  }
}

void UserFeature::MergeDislikeFeature() {
  if (user_info_->dislike_info_size() == 0) return;
  // TODO dislike 特征按时间衰减
  reco::FeatureVector kw_feas, tag_feas;
  std::vector<reco::Category> categories;
  std::unordered_set<uint64> uniq_items;
  uniq_items.insert(0lu);
  std::string category;
  for (int i = 0; i < user_info_->dislike_info_size(); ++i) {
    const reco::ViewClickItem& dislike_item = user_info_->dislike_info(i);
    if (uniq_items.find(dislike_item.item_id()) != uniq_items.end()) continue;
    uniq_items.insert(dislike_item.item_id());
    categories.clear();
    if (news_index_->GetCategoriesByItemId(dislike_item.item_id(), &categories)) {
      for (int j = 0; j < (int)categories.size(); ++j) {
        if (categories[j].level() == 0) {
          category = categories[j].category();
          break;
        }
      }
    }
    if (category.empty()) continue;
    dislike_items_.push_back(DislikeItemInfo());
    DislikeItemInfo& item_info = dislike_items_.back();
    item_info.item_id = dislike_item.item_id();
    item_info.category = category;
    std::unordered_map<std::string, float>& item_feas = item_info.item_feas;
    kw_feas.clear_feature();
    if (news_index_->GetFeatureVectorByItemId(dislike_item.item_id(), reco::common::kKeyword, &kw_feas)) {
      for (int j = 0; j < kw_feas.feature_size(); ++j) {
        const reco::Feature& fea = kw_feas.feature(j);
        item_feas[fea.literal()] += fea.weight();
      }
    }
    tag_feas.clear_feature();
    if (!news_index_->GetFeatureVectorByItemId(dislike_item.item_id(), reco::common::kTag, &tag_feas)) {
      for (int j = 0; j < tag_feas.feature_size(); ++j) {
        const reco::Feature& fea = tag_feas.feature(j);
        item_feas[fea.literal()] += fea.weight();
      } 
    }
  }
  std::unordered_map<std::string, FeatureMap> dislike_merged_feas;
  for (int i = 0; i < (int)dislike_items_.size(); ++i) {
    const DislikeItemInfo& item_info = dislike_items_[i];
    if (!item_info.category.empty()) {
      FeatureMap& fea_map = dislike_merged_feas[item_info.category];
      for (auto iter = item_info.item_feas.begin(); iter != item_info.item_feas.end(); ++iter) {
        fea_map[iter->first] += iter->second;
      }
    }
  }

  for (auto iter = category_keywords_.begin(); iter != category_keywords_.end(); ++iter) {
    const std::string& category = iter->first;
    FeatureMap& fea_map = iter->second;
    auto dislike_iter = dislike_merged_feas.find(category);
    if (dislike_iter == dislike_merged_feas.end()) continue;
    const FeatureMap& dislike_fea_map = dislike_iter->second;
    for (auto fea_iter = fea_map.begin(); fea_iter != fea_map.end(); ++fea_iter) {
      auto dislike_fea_iter = dislike_fea_map.find(fea_iter->first);
      if (dislike_fea_iter == dislike_fea_map.end()) continue;
      float boost = std::max(0.05, 1 - (dislike_fea_iter->second * 0.1));
      fea_iter->second *= boost;
    }
  }
  for (auto iter = category_tags_.begin(); iter != category_tags_.end(); ++iter) {
    const std::string& category = iter->first;
    FeatureMap& fea_map = iter->second;
    auto dislike_iter = dislike_merged_feas.find(category);
    if (dislike_iter == dislike_merged_feas.end()) continue;
    const FeatureMap& dislike_fea_map = dislike_iter->second;
    for (auto fea_iter = fea_map.begin(); fea_iter != fea_map.end(); ++fea_iter) {
      auto dislike_fea_iter = dislike_fea_map.find(fea_iter->first);
      if (dislike_fea_iter == dislike_fea_map.end()) continue;
      float boost = std::max(0.05, 1 - (dislike_fea_iter->second * 0.1));
      fea_iter->second *= boost;
    }
  }
}

void UserFeature::PreProcessFeature() {
  user_keywords_.clear();
  user_topics_.clear();
  user_tags_.clear();
  user_categories_.clear();
  dislike_items_.clear();
  category_keywords_.clear();
  category_tags_.clear();
}

void UserFeature::PostProcessFeature() {
  std::string key;
  for (auto iter = category_keywords_.begin(); iter != category_keywords_.end(); ++iter) {
    FeatureMap& keywords = iter->second;
    SelectFeature(&keywords, FLAGS_max_user_keyword_fea_num);
    NormalizeFeature(&keywords);
    for (auto kw_iter = keywords.begin(); kw_iter != keywords.end(); ++kw_iter) {
      key = genCategoryWordKey(iter->first, kw_iter->first);
      user_keywords_[key] += kw_iter->second;
    }
  }
  NormalizeFeature(&user_keywords_);

  for (auto iter = category_tags_.begin(); iter != category_tags_.end(); ++iter) {
    FeatureMap& tags = iter->second;
    SelectFeature(&tags, FLAGS_max_user_tag_fea_num);
    NormalizeFeature(&tags);
    for (auto tag_iter = tags.begin(); tag_iter != tags.end(); ++tag_iter) {
      key = genCategoryWordKey(iter->first, tag_iter->first);
      user_tags_[key] += tag_iter->second;
    }
  }
  NormalizeFeature(&user_tags_);

  SelectFeature(&user_topics_, FLAGS_max_user_topic_fea_num);
  NormalizeFeature(&user_topics_);

  NormalizeFeature(&user_categories_);
}

void UserFeature::SelectFeature(std::map<std::string, double>* user_fea, size_t limit_size) {
  if (user_fea->size() <= limit_size) {
    return;
  }
  std::vector<std::pair<std::string, double> > fea_vec(user_fea->size());
  int idx = 0;
  for (auto iter = user_fea->begin(); iter != user_fea->end(); ++iter) {
    fea_vec[idx].first = iter->first;
    fea_vec[idx].second = iter->second;
    ++idx;
  }
  std::sort(fea_vec.begin(), fea_vec.end(), FeaWeightSortFunc);
  user_fea->clear();
  for (size_t i = 0; i < limit_size; ++i) {
    (*user_fea)[fea_vec[i].first] = fea_vec[i].second;
  }
}

void UserFeature::PrintUserFeature(const std::string& prefix_info) {
  LOG(INFO) << "UserFea debug, uid:" << user_info_->identity().user_id()
            << ",  prefix:[" << prefix_info << "].";

  std::string category;
  for (auto iter = user_categories_.begin(); iter != user_categories_.end(); ++iter) {
    category += base::StringPrintf("%s(%.3f),", iter->first.c_str(), iter->second);
  }
  if (!category.empty()) {
    LOG(INFO) << "Category-Fea, " <<  category;
  }

  std::string keyword;
  for (auto iter = category_keywords_.begin(); iter != category_keywords_.end(); ++iter) {
    const FeatureMap& fea_map = iter->second;
    if (fea_map.empty()) continue;
    keyword = "category(" + iter->first + "): ";
    for (auto fea_iter = fea_map.begin(); fea_iter != fea_map.end(); ++fea_iter) {
      keyword += base::StringPrintf("%s(%.3f),", fea_iter->first.c_str(), fea_iter->second);
    }
    LOG(INFO) << "Keyword-Fea, " << keyword;
  }

  std::string tag;
  for (auto iter = category_tags_.begin(); iter != category_tags_.end(); ++iter) {
    const FeatureMap& fea_map = iter->second;
    if (fea_map.empty()) continue;
    tag = "category(" + iter->first + "): ";
    for (auto fea_iter = fea_map.begin(); fea_iter != fea_map.end(); ++fea_iter) {
      tag += base::StringPrintf("%s(%.3f)", fea_iter->first.c_str(), fea_iter->second);
    }
    LOG(INFO) << "Tag-Fea, " << tag;
  }
}

float UserFeature::CalcRecentClickInfluence(const std::string& category) const {
  float influence = 0.1;
  auto iter = user_categories_.find(category);
  if (iter == user_categories_.end()) {
    influence = 0.1;
  } else if (iter->second >= 0.5) {
    influence = 0.02;
  } else if (iter->second >= 0.4) {
    influence = 0.02 + 0.2 * (0.5 - iter->second);
  } else if (iter->second >= 0.3) {
    influence = 0.04 + 0.2 * (0.4 - iter->second);
  } else if (iter->second >= 0.2) {
    influence = 0.06 + 0.2 * (0.3 - iter->second);
  } else if (iter->second >= 0.1) {
    influence = 0.08 + 0.2 * (0.2 - iter->second);
  } else {
    influence = 0.1;
  }
  return influence;
}

bool UserFeature::CalcCategoryDistributes() {
  std::vector<std::pair<float, reco::Category> > category_distributes_;
  category_distributes_.clear();

  std::vector<reco::Category> all_categories, raw_categories;
  news_index_->GetCategories("uc", 0, &all_categories);
  for (int i = 0; i < (int)all_categories.size(); ++i) {
    raw_categories.push_back(all_categories[i]);
  }
  if (raw_categories.empty()) {
    LOG(WARNING) << "news has no any tags!";
    return false;
  }
  std::vector<std::string> categories;
  for (int i = 0; i < (int)raw_categories.size(); ++i) {
    LOG(INFO) << "category, " << i << ", " << WrappedCategory(raw_categories[i]).ToString();
    categories.push_back(WrappedCategory(raw_categories[i]).ToString());
  }

  std::string tag;
  std::unordered_map<std::string, std::pair<int, float> > category_counter;
  float acc_weight = 0;
  for (int i = 0; i < (int)categories.size(); ++i) {
    category_counter[categories[i]] = std::make_pair(i, 0);
  }

  // category by user interest
  for (auto it_user = user_categories_.begin();
       it_user != user_categories_.end(); ++it_user) {
    auto it_category = category_counter.find(it_user->first);
    if (it_category == category_counter.end()) continue;
    it_category->second.second = float(it_user->second);
    acc_weight += it_category->second.second;
  }

  if (acc_weight == 0) {
    float ratio = 1.0 / (int)category_counter.size();
    for (auto iter = category_counter.begin(); iter != category_counter.end(); ++iter) {
      iter->second.second = ratio;
    }
    acc_weight = 1;
  }
  // level1 上的归一
  for (auto it = category_counter.begin(); it != category_counter.end(); ++it) {
    it->second.second /= acc_weight;
  }
  // NOTE(jianhuang) 为了开发用户新的兴趣点, 应该给用户未点击的tag一些小概率出现的机会
  // 如果用户的点击量已经较大, 则概率机会小点; 否则概率机会大点
  float kExploreRatio = CalcExploreRatio(user_info_);
  float kExploreTagWeight = kExploreRatio / category_counter.size();
  acc_weight = 0;
  for (auto it = category_counter.begin(); it != category_counter.end(); ++it) {
    const reco::Category& ref_category = raw_categories[it->second.first];
    int today_item_num = news_index_->GetTodayNewsNum("uc", ref_category);
    if (today_item_num == 0) today_item_num = 1;
    float item_num_score = std::pow(today_item_num, 0.2);
    it->second.second = (it->second.second * (1 - kExploreRatio) + kExploreTagWeight) * item_num_score;
    acc_weight += it->second.second;
  }
  if (acc_weight < 1e-7) {
    acc_weight = 1;
  }
  for (auto it = category_counter.begin(); it != category_counter.end(); ++it) {
    it->second.second /= acc_weight;
  }

  // 按照 category 权重排序
  int idx = 0;
  std::vector<std::pair<float, int> > tmp_sort(category_counter.size());
  for (auto it = category_counter.begin(); it != category_counter.end(); ++it) {
    tmp_sort[idx] = std::make_pair(it->second.second, it->second.first);
    ++idx;
  }
  std::sort(tmp_sort.begin(), tmp_sort.end(), std::greater<std::pair<float, int> >());

  // 最终的 category 分布结果
  // NOTE(jianhuang)
  // 不需要每次请求都计算所有的 category 的推荐列表。当然需要保证用户喜欢的 category 一定能得到展现
  category_distributes_.clear();
  std::unordered_set<int> select_set;
  acc_weight = 0;
  base::PseudoRandom* random_;
  random_ = new base::PseudoRandom(base::GetTimestamp());
  for (int i = 0; i < (int)tmp_sort.size(); ++i) {
    if (random_->GetDouble() <= tmp_sort[i].first * 10) {
      select_set.insert(i);
      acc_weight += tmp_sort[i].first;
    }
  }
  for (int i = 0; i < (int)tmp_sort.size(); ++i) {
    // 如果 category 足够多，至少取 8 个 category
    if (select_set.size() >= 8u) {
      break;
    }
    if (select_set.find(i) == select_set.end()) {
      select_set.insert(i);
      acc_weight += tmp_sort[i].first;
    }
  }
  if (acc_weight < 1e-6) acc_weight = 1;

  for (int i = 0; i < (int)tmp_sort.size(); ++i) {
    if (select_set.find(i) != select_set.end()) {
      category_distributes_.push_back(std::make_pair(tmp_sort[i].first / acc_weight,
                                                     raw_categories[tmp_sort[i].second]));
    }
  }

  // 控制一个类别最多展现占整体的比例, max_categroy_show_ratio
  float max_category_show_ratio = std::max(0.5f, 0.5f);
  if (category_distributes_.size() >= 2u && category_distributes_[0].first > max_category_show_ratio) {
    float smooth_ratio =
        (category_distributes_[0].first - max_category_show_ratio) / (category_distributes_.size() - 1);
    category_distributes_[0].first = max_category_show_ratio;
    for (int i = 1; i < (int) category_distributes_.size(); ++i) {
      category_distributes_[i].first += smooth_ratio;
    }
  }

  std::string debug_str;
  for (size_t i = 0; i < category_distributes_.size(); ++i) {
    const reco::Category& category = category_distributes_.at(i).second;
    float weight = category_distributes_.at(i).first;
    debug_str.append(base::StringPrintf("%s[%.3f], ", category.category().c_str(), weight));
  }
  LOG(INFO) << "category distribute, " << debug_str;
  delete random_;
  return true;
}

void UserFeature::loadDict() {
  base::FilePath base_dir(FLAGS_leaf_data_dir);

  std::vector<std::string> lines;
  base::FilePath channel_category_file = base_dir.Append(kChannelCategoryFile);
  CHECK(base::file_util::ReadFileToLines(channel_category_file, &lines));
  loadChannelCategoryDict(lines);

  lines.clear();
  base::FilePath user_role_kw_file = base_dir.Append(kUserRoleKeywordFile);
  CHECK(base::file_util::ReadFileToLines(user_role_kw_file, &lines));
  loadUserRoleKeywordDict(lines);

  lines.clear();
  base::FilePath user_role_category_file = base_dir.Append(kUserRoleCategoryFile);
  CHECK(base::file_util::ReadFileToLines(user_role_category_file, &lines));
  loadUserRoleCategoryDict(lines);
}

void UserFeature::loadChannelCategoryDict(const std::vector<std::string>& lines) {
  std::vector<std::string> flds;
  int64 channel_id;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u ||
        !base::StringToInt64(flds[0], &channel_id)) {
      LOG(ERROR) << "channel category record field error, line is: " << lines[i];
      continue;
    }

    CategoryDistributes category_weights;
    for (int j = 1; j < (int)flds.size(); ++j) {
      if (!parseFeas(flds[j], &category_weights)) {
        LOG(ERROR) << "channel category record field error, line is: " << lines[i];
      }
    }
    if (normalizeFeas(&category_weights)) {
      channel_categories.insert(std::make_pair(channel_id, category_weights));
    }
  }
  LOG(INFO) << "load channel categories dict succ, total record " << channel_categories.size();
}

void UserFeature::loadUserRoleCategoryDict(const std::vector<std::string>& lines) {
  std::vector<std::string> flds;
  std::string nor_str;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u) {
      LOG(ERROR) << "user_role category record field error, line is: " << lines[i];
      continue;
    }
    nor_str = nlp::util::NormalizeLine(flds[0]);
    CategoryDistributes category_weights;
    for (int j = 1; j < (int)flds.size(); ++j) {
      if (!parseFeas(flds[j], &category_weights)) {
        LOG(ERROR) << "user_role category record field error, line is: " << lines[i];
      }
    }
    if (normalizeFeas(&category_weights)) {
      user_role_categories.insert(std::make_pair(nor_str, category_weights));
    }
  }
  LOG(INFO) << "load user_role category dict succ, total record " << user_role_categories.size();
}

void UserFeature::loadUserRoleKeywordDict(const std::vector<std::string>& lines) {
  std::vector<std::string> flds;
  std::string nor_str;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u) {
      LOG(ERROR) << "user role keywords record field error, line is: " << lines[i];
      continue;
    }
    nor_str = nlp::util::NormalizeLine(flds[0]);
    KeywordDistributes kw_weights;
    for (int j = 1; j < (int)flds.size(); ++j) {
      if (!parseFeas(flds[j], &kw_weights)) {
        LOG(ERROR) << "user role keywords record field error, line is: " << lines[i];
      }
    }
    if (normalizeFeas(&kw_weights)) {
      user_role_keywords.insert(std::make_pair(nor_str, kw_weights));
    }
  }
  LOG(INFO) << "load user_role keywords dict succ, total record " << user_role_keywords.size();
}

bool UserFeature::parseFeas(const std::string& fea_wt_str,
                           std::vector<std::pair<std::string, float> >* feas) {
  double weight = 0;
  std::vector<std::string> cols;
  base::SplitString(fea_wt_str, ":", &cols);
  if (cols.size() != 2u || !base::StringToDouble(cols[1], &weight)) {
    return false;
  }
  std::string nor_str = nlp::util::NormalizeLine(cols[0]);
  if (nor_str.empty()) {
    return false;
  }
  feas->push_back(std::make_pair(nor_str, static_cast<float>(weight)));
  return true;
}

bool UserFeature::normalizeFeas(std::vector<std::pair<std::string, float> >* feas) {
  float total_weight = 0;
  for (int j = 0; j < (int)feas->size(); ++j) {
    total_weight += (*feas)[j].second;
  }
  if (total_weight < 1e-6) return false;
  for (int j = 0; j < (int)feas->size(); ++j) {
    (*feas)[j].second /= total_weight;
  }
  return true;
}
float UserFeature::CalcExploreRatio(const reco::UserInfo* user_info) const {
  int recent_click_num = user_info->recent_click_size();
  // 使用分段函数实现该效果
  float kExploreRatio = 0;
  if (recent_click_num >= 20) { // 0.3
    kExploreRatio = 0.3;
  } else if (recent_click_num >= 10) { // (0.3, 0.4]
    kExploreRatio = 0.3 + (20 - recent_click_num) * 0.01;
  } else if (recent_click_num >= 5) {  // (0.4, 0.5]
    kExploreRatio = 0.4 + (10 - recent_click_num) * 0.02;
  } else if (recent_click_num >= 2) {  // (0.5, 0.6]
    kExploreRatio = 0.5 + (5 - recent_click_num) * 0.033;
  } else { // (0.6, 0.75]
    kExploreRatio = 0.75;
  }
  return kExploreRatio;
}
}
}
