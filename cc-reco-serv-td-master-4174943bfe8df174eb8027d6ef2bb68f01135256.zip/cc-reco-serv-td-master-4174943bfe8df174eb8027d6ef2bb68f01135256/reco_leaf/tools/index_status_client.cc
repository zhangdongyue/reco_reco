#include <iostream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/item.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20001, "leaf server port");

DEFINE_string(mode, "GetIndexQueue", "GetIndexQueue/GetIndexStatus");

DEFINE_int32(item_type, 2, "2: picture, 3: humor");
DEFINE_int32(return_num, 10, "return num");
DEFINE_string(category, "美女写真", "categories splitted by ,");
DEFINE_int32(sort_method, 3, "2: time sort, 3: hot sort");

DEFINE_int32(index_type, 3, "index type");
DEFINE_string(literal, "科技", "索引名称");
DEFINE_int32(start_num, 0, "page number");
DEFINE_string(source, "", "源");
DEFINE_bool(only_id, false, "只出 id");
DEFINE_bool(virgin_rank_pos, false, "保留原始索引排名");
DEFINE_bool(filter_expiry, true, "过滤过期文章");
DEFINE_bool(filter_invalid, true, "过滤无效文章");
DEFINE_uint64(itemid, 0, "itemid");


std::string ItemTypeNumListToString(const reco::leafserver::IndexQueueStatus& status) {
  std::string result = "[";
  for (int i = 0; i < status.item_type_distribute_size(); ++i) {
    result += reco::ItemType_Name(status.item_type_distribute(i).item_type());
    result += ",";
    result += base::IntToString(status.item_type_distribute(i).num());
    result += ";";
  }
  result += "]";
  return result;
}

void GetIndexStatus() {
  reco::leafserver::GetIndexStatusRequest request;
  reco::leafserver::GetIndexStatusResponse response;
  if (reco::leafserver::IndexType_IsValid(FLAGS_index_type)) {
    request.set_index_type(reco::leafserver::IndexType(FLAGS_index_type));
    if (!FLAGS_literal.empty()) {
      request.set_literal(FLAGS_literal);
    }
  } else {
    request.set_index_type(reco::leafserver::kAllIndex);
  }
  LOG(INFO) << request.Utf8DebugString();

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(5);
  stub.getIndexStatus(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk) {
    LOG(ERROR) << "rpc failed";
    return;
  } else if (!response.success()) {
    LOG(ERROR) << "recommend fail." << response.err_message();
    return;
  }
  std::cout << response.Utf8DebugString() << std::endl;
  for (int i = 0; i < response.index_queue_status_size(); ++i) {
    const reco::leafserver::IndexQueueStatus& status = response.index_queue_status(i);
    std::cout << IndexType_Name(status.index_type())
              << "\t\t" << base::StringReplace(status.literal(), "\t", "-", true)
              << "\t\t" << status.index_size()
              << "\t\t" << status.today_news_num()
              << "\t\t" << status.invalid_num()
              << "\t\t" << status.expiry_num()
              << "\t\t" << ItemTypeNumListToString(status) << std::endl;
  }
}

void GetIndexQueue() {
  reco::leafserver::GetIndexQueueRequest request;
  reco::leafserver::GetIndexQueueResponse response;
  request.set_index_type((reco::leafserver::IndexType)FLAGS_index_type);
  request.set_literal(FLAGS_literal);
  request.set_return_num(FLAGS_return_num);
  request.set_start_num(FLAGS_start_num);
  if (!FLAGS_source.empty())
    request.set_source(FLAGS_source);
  request.set_only_id(FLAGS_only_id);
  request.set_virgin_rank_pos(FLAGS_virgin_rank_pos);
  request.set_filter_expiry(FLAGS_filter_expiry);
  request.set_filter_invalid(FLAGS_filter_invalid);
  if (FLAGS_itemid != 0UL)
    request.set_item_id(FLAGS_itemid);
  LOG(INFO) << request.Utf8DebugString();

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(5);
  stub.getIndexQueue(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk) {
    LOG(ERROR) << "rpc failed";
    return;
  } else if (!response.success()) {
    LOG(ERROR) << "recommend fail." << response.err_message();
    return;
  }
  std::cout << response.Utf8DebugString() << std::endl;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client");

  if (FLAGS_mode == "GetIndexStatus")
    GetIndexStatus();
  else
    GetIndexQueue();

  return 0;
}
