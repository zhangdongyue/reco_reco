#include <iostream>
#include <fstream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20001, "leaf server port");
DEFINE_int32(return_num, 10, "return num");
DEFINE_int32(start_num, 0, "page number");
DEFINE_int32(index_type, 3, "index type");
DEFINE_string(literal, "科技", "索引名称");
DEFINE_uint64(item_id, 0u, "只查询该item_id");
DEFINE_int32(need_attr, 0, "need attr or only item_id");
DEFINE_string(output_filepath, "./out", "输出结果文件路径");

int GetIndexQueue() {
  reco::leafserver::GetIndexQueueRequest request;
  reco::leafserver::GetIndexQueueResponse response;
  request.set_index_type((reco::leafserver::IndexType)FLAGS_index_type);
  request.set_literal(FLAGS_literal);
  request.set_return_num(FLAGS_return_num);
  request.set_start_num(FLAGS_start_num);
  request.set_only_id(FLAGS_need_attr == 0);
  if ( FLAGS_item_id != 0u) {
    request.set_item_id(FLAGS_item_id);
  }
  LOG(INFO) << request.Utf8DebugString();

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  if (!channel.Connect()) {
    LOG(ERROR) << "connect failed";
    return -1;
  }
  reco::leafserver::RecommendService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(5);
  stub.getIndexQueue(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk) {
    LOG(ERROR) << "rpc failed";
    return -1;
  } else if (!response.success()) {
    LOG(ERROR) << "get res fail, err_msg=" << response.err_message();
    return -1;
  }

  std::ofstream   ofresult;
  ofresult.open(FLAGS_output_filepath, std::ios::out);
  //ofresult << response.Utf8DebugString() << std::endl;

  for ( int i=0; i < response.item_info_size(); i++) {
      ofresult << "no=" << i << ",item_id=" << response.item_info(i).item_id() << std::endl;
  }

  return 0;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client for unsorted index, eg. ads index result");
  return GetIndexQueue();
}
