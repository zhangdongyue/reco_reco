#include <iostream>
#include <string>

#include "base/common/base.h"
#include "base/strings/string_split.h"

#include "net/rpc/rpc.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20001, "leaf server port");
DEFINE_string(param_string, "", "eg. a=b;c=d");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client");

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);
  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(10);

  reco::leafserver::SetCommandLineOptionRequest request;
  std::vector<std::string> cols;
  LOG(INFO) << "param_string: " << FLAGS_param_string;
  base::SplitString(FLAGS_param_string, ";", &cols);
  for (size_t i = 0; i < cols.size(); ++i) {
    std::vector<std::string> kv;
    size_t pos = cols[i].find('=');
    if (pos == std::string::npos) continue;
    reco::leafserver::SetCommandLineOptionRequest::Param* dkv = request.add_param();
    dkv->set_key(cols[i].substr(0, pos));
    dkv->set_value(cols[i].substr(pos + 1));
  }
  LOG(INFO) << "request: " << request.Utf8DebugString();
  if (request.param_size() == 0) {
    return 0;
  }
  reco::leafserver::SetCommandLineOptionResponse response;

  stub.setCommandLineOption(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
    LOG(ERROR) << "recommend fail.";
  } else {
    LOG(INFO) << "set command line option ok: " << response.Utf8DebugString();
  }

  return 0;
}

