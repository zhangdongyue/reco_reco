#include <math.h>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/model_inner/mf_model.h"
#include "reco/serv/dict_server/api/dict_server_api.h"


using namespace std;
using namespace reco::leafserver;

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  MFModel::StaticInit();
  reco::dictserver::DictServerAPIIns::instance().Init();

  string line;
  cout << "input userid, itemid, cateid:" << endl;
  // format: userid, itemid, cateid
  while (getline(cin, line)) {
    vector<string> tokens;
    base::SplitString(line, " ", &tokens);
    cout << "tokens:" << tokens[0] <<" "<< tokens[1] <<" "<< tokens[2] << endl;
    // version
    string version;
    MFModel::GetVersion(&version);
    // base
    string base_key;    
    MFModel::GenBaseInfoKey(tokens[2], &base_key);
    string base_val;
    MFModel::GetFromDictServer(base_key, version, &base_val, false);
    reco::MFBaseInfo base_info;
    base_info.ParseFromString(base_val);
    // user
    uint64 user_id = 0;
    base::StringToUint64(tokens[0], &user_id);
    string user_key;
    MFModel::GenUserIDKey(user_id, &user_key);
    string user_val;
    MFModel::GetFromDictServer(user_key, version, &user_val, false);
    reco::MFFeatureVectorArray user_fea_vec_array;
    user_fea_vec_array.ParseFromString(user_val);
    reco::MFFeatureVectorWithCate user_fea_vec;
    for (auto i = 0; i < user_fea_vec_array.mf_feature_vector_cate_size(); ++i) {
      if (user_fea_vec_array.mf_feature_vector_cate(i).category() == tokens[2]) {
        user_fea_vec = user_fea_vec_array.mf_feature_vector_cate(i);
      }
    }
    // item
    uint64 item_id = 0;
    base::StringToUint64(tokens[1], &item_id);
    string item_key;
    MFModel::GenItemIDKey(item_id, &item_key);
    string item_val;
    MFModel::GetFromDictServer(item_key, version, &item_val, false);
    reco::MFFeatureVector item_fea_vec;
    item_fea_vec.ParseFromString(item_val);
    // predict
    double score = 0;
    score += base_info.avg_score() + user_fea_vec.weight(1) + item_fea_vec.weight(0);
    cout << "b:" << base_info.avg_score() << " u1:" << user_fea_vec.weight(1) <<
            " i0:" << item_fea_vec.weight(0);
    for (int i = 1; i < (int)base_info.fea_num(); ++i) {
      score += user_fea_vec.weight(i+1) * item_fea_vec.weight(i);
      cout << " u:" << user_fea_vec.weight(i+1) << " i:" << item_fea_vec.weight(i);
    }
    cout << endl << "version:" << version << " basekey:" << base_key <<
            " userkey:" << user_key << " itemkey:" << item_key << endl;
    cout << "score:" << score << " sigmoid:" << 1 / (1 + exp(-score)) << endl;
    cout << endl << "input userid, itemid, cateid:" << endl;

  }

  return 0;
}

