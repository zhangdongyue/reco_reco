#include <iostream>
#include <fstream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "google/protobuf/text_format.h"
#include "net/rpc/rpc.h"
#include "nlp/common/nlp_util.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/serv/reco_leaf/strategy/common/reco_strategy_branch.h"

using google::protobuf::RepeatedPtrField;
using google::protobuf::RepeatedField;
using reco::leafserver::RecoDebugInfo;

// server config
DEFINE_string(leaf_server_ip1, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port1, 20001, "leaf server port");
DEFINE_string(leaf_server_ip2, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port2, 20001, "leaf server port");

// input config
DEFINE_string(user_request_file, "", "request of leaf");

// debug and output config
DEFINE_bool(enable_debug, true, "enable debug");
DEFINE_bool(turnoff_random, true, "turnoff random");
DEFINE_string(trace_item_ids, "", "trace itemids");
DEFINE_int32(debug_level, 0, "debug level");
DEFINE_string(trace_flags, "", "trace flags");
DEFINE_int32(trace_display_max_item_num, 10, "display in detail");
DEFINE_bool(display_response_user_info, true, "dispaly user info of response");
DEFINE_bool(display_response_result, true, "display result of response");
DEFINE_bool(display_raw_debug_info, false, "display raw debug info");
DEFINE_bool(diff_manual_whole, false, "diff manual whole items");
DEFINE_bool(diff_manual_personal, false, "diff manual personal items");

class LeafServerClient {
 public:
  LeafServerClient(const std::string& ip, int32 port) {
    ip_ = ip;
    port_ = port;

    channel_ = new net::rpc::RpcClientChannel(ip_.c_str(), port_);
    CHECK(channel_->Connect());
    stub_ = new reco::leafserver::RecommendService::Stub(channel_);
  }
  virtual ~LeafServerClient() {
    delete stub_;
    delete channel_;
  }

  bool Query(const reco::leafserver::RecommendRequest& request,
             reco::leafserver::RecommendResponse* response) {
    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(120);
    stub_->recommend(&rpc, &request, response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response->success()) {
      return false;
    }
    return true;
  }

  std::string ip_;
  int32 port_;
  net::rpc::RpcClientChannel* channel_;
  reco::leafserver::RecommendService::Stub* stub_;
};

void InitDebugParam(reco::leafserver::RecommendRequest* request);
void DisplayDebugParam(const reco::leafserver::RecommendResponse& response);

int g_manual_item_total = 0;
int g_manual_item_same = 0;
int g_manual_item_diff = 0;
void DiffDebugItemList(const char* name,
                       const RepeatedPtrField<RecoDebugInfo::ItemInfo>& items1,
                       const RepeatedPtrField<RecoDebugInfo::ItemInfo>& items2) {
  std::cout << "-- name --" << std::endl;
  std::vector<uint64> v1;
  for (int i = 0; i < items1.size(); i ++) {
    v1.push_back(items1.Get(i).item_id());
  }
  sort(v1.begin(), v1.end());
  std::vector<uint64> v2;
  for (int i = 0; i < items2.size(); i ++) {
    v2.push_back(items2.Get(i).item_id());
  }
  sort(v2.begin(), v2.end());
  size_t i1 = 0;
  size_t i2 = 0;
  while (i1 < v1.size() && i2 < v2.size()) {
    if (v1[i1] == v2[i2]) {
      g_manual_item_total += 2;
      g_manual_item_same += 2;
      std::cout << " -same: " << v1[i1] << " | " << v2[i2] << std::endl;
      i1++;
      i2++;
    } else if (v1[i1] < v2[i2]) {
      g_manual_item_total++;
      g_manual_item_diff++;
      std::cout << " -diff: " << v1[i1] << " | - " << std::endl;
      i1++;
    } else {
      g_manual_item_total++;
      g_manual_item_diff++;
      std::cout << " -diff: - | " << v2[i2] << std::endl;
      i2++;
    }
  }
  for (size_t i = i1; i < v1.size(); i ++) {
    g_manual_item_diff++;
    std::cout << " -r1: " << v1[i] << " | -" << std::endl;
  }
  for (size_t i = i2; i < v2.size(); i ++) {
    g_manual_item_diff++;
    std::cout << " -r2: - | " << v2[i] << std::endl;
  }
}

void DiffDebugManualWholeItems(const reco::leafserver::RecommendResponse& r1,
                               const reco::leafserver::RecommendResponse& r2) {
  if (!r1.has_reco_debug_info() || !r2.has_reco_debug_info())
    return;
  auto d1 = r1.reco_debug_info();
  auto d2 = r2.reco_debug_info();
  if (FLAGS_diff_manual_whole)
    DiffDebugItemList("manual_whole", d1.manual_whole_items(), d2.manual_whole_items());
  if (FLAGS_diff_manual_personal)
    DiffDebugItemList("manual_personal", d1.manual_whole_items(), d2.manual_whole_items());
}

int g_item_total = 0;
int g_item_same = 0;
int g_item_diff = 0;
bool DiffRecommendResponse(const reco::leafserver::RecommendResponse& r1,
                           const reco::leafserver::RecommendResponse& r2) {
  bool diff = false;
  const int num = std::min(r1.result_size(), r2.result_size());
  for (int i = 0; i < num; i ++) {
    if (r1.result(i).item_id() == r2.result(i).item_id()) {
      std::cout << " -same: " << r1.result(i).item_id() << " | " << r2.result(i).item_id() << std::endl;
    } else {
      diff = true;
      std::cout << " -diff: " << r1.result(i).item_id() << " | " << r2.result(i).item_id() << std::endl;
    }
  }
  for (int i = num; i < r1.result_size(); i ++) {
    diff = true;
    std::cout << " -r1: " << r1.result(i).item_id() << " | -" << std::endl;
  }
  for (int i = num; i < r2.result_size(); i ++) {
    diff = true;
    std::cout << " -r2: - | " << r2.result(i).item_id() << std::endl;
  }

  std::cout << "-- set compare --" << std::endl;
  std::vector<uint64> v1;
  for (int i = 0; i < r1.result_size(); i ++) {
    v1.push_back(r1.result(i).item_id());
  }
  sort(v1.begin(), v1.end());
  std::vector<uint64> v2;
  for (int i = 0; i < r2.result_size(); i ++) {
    v2.push_back(r2.result(i).item_id());
  }
  sort(v2.begin(), v2.end());
  size_t i1 = 0;
  size_t i2 = 0;
  while (i1 < v1.size() && i2 < v2.size()) {
    if (v1[i1] == v2[i2]) {
      g_item_total += 2;
      g_item_same += 2;
      std::cout << " -same: " << v1[i1] << " | " << v2[i2] << std::endl;
      i1++;
      i2++;
    } else if (v1[i1] < v2[i2]) {
      g_item_total++;
      g_item_diff++;
      std::cout << " -diff: " << v1[i1] << " | - " << std::endl;
      i1++;
    } else {
      g_item_total++;
      g_item_diff++;
      std::cout << " -diff: - | " << v2[i2] << std::endl;
      i2++;
    }
  }
  for (size_t i = i1; i < v1.size(); i ++) {
    g_item_diff++;
    std::cout << " -r1: " << v1[i] << " | -" << std::endl;
  }
  for (size_t i = i2; i < v2.size(); i ++) {
    g_item_diff++;
    std::cout << " -r2: - | " << v2[i] << std::endl;
  }

  return diff;
}

void BatchFileRequest() {
  std::cout << "BatchFileRequest..." << std::endl;

  LeafServerClient s1(FLAGS_leaf_server_ip1, FLAGS_leaf_server_port1);
  LeafServerClient s2(FLAGS_leaf_server_ip2, FLAGS_leaf_server_port2);
  int32 total = 0;
  int32 valid_request = 0;
  int32 both_success = 0;
  int32 same = 0;
  int32 diff = 0;
  int32 both_failed = 0;
  int32 s1_success_s2_failed = 0;
  int32 s1_failed_s1_success = 0;

  // read file
  std::ifstream fin(FLAGS_user_request_file.c_str());
  CHECK(fin) << "open file error: " << FLAGS_user_request_file;
  std::string line;
  while (getline(fin, line)) {
    total++;
    reco::leafserver::RecommendRequest request;
    if (!google::protobuf::TextFormat::ParseFromString(line, &request)) {
      std::cerr << "parse error: " << line << std::endl;
      continue;
    }
    InitDebugParam(&request);
    std::cout << "request: " << nlp::util::NormalizeLine(request.Utf8DebugString()) << std::endl;
    valid_request++;

    reco::leafserver::RecommendResponse r1;
    reco::leafserver::RecommendResponse r2;
    bool rs1 = s1.Query(request, &r1);
    bool rs2 = s2.Query(request, &r2);
    if (rs1 && rs2) {
      both_success++;
      if (!DiffRecommendResponse(r1, r2))
        same++;
      else
        diff++;
      DiffDebugManualWholeItems(r1, r2);
    } else if (!rs1 && !rs2) {
      both_failed++;
      std::cout << "both failed!" << std::endl;
    } else if (rs1 && !rs2) {
      s1_success_s2_failed++;
      std::cout << "s1 success, s2 failed" << std::endl;
    } else {
      s1_failed_s1_success++;
      std::cout << "s1 failed, s2 success" << std::endl;
    }
  }
  std::cout << std::endl;
  std::cout << "-- summary --" << std::endl;
  std::cout << "total = " << total << std::endl;
  std::cout << "valid_request = " << valid_request << std::endl;
  std::cout << "both_success = " << both_success << std::endl;
  std::cout << "same = " << same << std::endl;
  std::cout << "diff = " << diff << std::endl;
  std::cout << "both_failed = " << both_failed << std::endl;
  std::cout << "s1_success_s2_failed = " << s1_success_s2_failed << std::endl;
  std::cout << "s1_failed_s1_success = " << s1_failed_s1_success << std::endl;
  std::cout << "g_item_total = " << g_item_total << std::endl;
  std::cout << "g_item_same = " << g_item_same << std::endl;
  std::cout << "g_item_diff = " << g_item_diff << std::endl;
  if (FLAGS_diff_manual_whole) {
    std::cout << "g_manual_item_total = " << g_manual_item_total << std::endl;
    std::cout << "g_manual_item_same = " << g_manual_item_same << std::endl;
    std::cout << "g_manual_item_diff = " << g_manual_item_diff << std::endl;
  }

  fin.close();
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client");
  BatchFileRequest();
  return 0;
}

void InitDebugParam(reco::leafserver::RecommendRequest* request) {
  if (FLAGS_enable_debug) {
    reco::leafserver::RecoDebugParam* debug_param = request->mutable_reco_debug_param();
    debug_param->set_enable_debug(true);
    if (!FLAGS_trace_item_ids.empty()) {
      std::vector<std::string> itemids;
      base::SplitString(FLAGS_trace_item_ids, ",", &itemids);
      for (size_t i = 0;i < itemids.size(); i ++) {
        uint64 itemid;
        if (base::StringToUint64(itemids[i], &itemid))
          debug_param->add_trace_item_ids(itemid);
      }
    }
    debug_param->set_debug_level(FLAGS_debug_level);
    if (!FLAGS_trace_flags.empty()) {
      std::vector<std::string> flag_levels;
      base::SplitString(FLAGS_trace_flags, ",", &flag_levels);
      for (size_t i = 0; i < flag_levels.size(); i ++) {
        debug_param->add_debug_flag(flag_levels[i]);
      }
    }
  }
  if (FLAGS_turnoff_random) {
    request->mutable_reco_debug_param()->set_turnoff_random(true);
  }
}

void DisplayItemInfoList(const char* table_name, const RepeatedPtrField<RecoDebugInfo::ItemInfo>& items) {
  if (items.size() <= 0) return;
  std::cout << "-- Table: " << table_name << " - "
            << "ItemNumber: " << items.size() << " --"<< std::endl;
  std::cout << "| item_id | item_type | site_level | time_level "
            << "| hot_level | sensitive_type | reco_score | create_time "
            << "| priority | category | sub_category | item_quality "
            << "| spider_score | lr_score | fm_score | ctr | shown_num | click_num "
            << "| strategy_type |" << std::endl;
  for (int i = 0; i < items.size() && i < FLAGS_trace_display_max_item_num; i ++) {
    auto item = items.Get(i);
    std::cout << "| " << i << "\t| " << item.item_id() << "\t| " << ItemType_Name(item.item_type())
        << "\t| " << SiteLevel_Name(item.site_level())
        << "\t| " << TimeLevel_Name(item.time_level()) << "\t| " << item.hot_level()
        << "\t| " << item.sensitive_level() << "\t| " << item.reco_score()
        << "\t| " << item.create_timestamp() << "\t| " << item.priority()
        << "\t| " << item.category() << "\t| " << item.sub_category()
        << "\t| " << item.item_quality() << "\t| " << item.spider_score()
        << "\t| " << item.lr_score() << "\t| " << item.fm_score()
        << "\t| " << item.ctr() << "\t| " << item.shown_num()
        << "\t| " << item.click_num() << "\t| " << StrategyType_Name(item.strategy_type())
        << "\t| " << std::endl;
  }
  std::cout << std::endl;
}

// like proto enum api
const char* RecoStrategyBranch_Name(int32_t rsb) {
  switch (rsb) {
    case reco::leafserver::kManualRSB:
      return "kManualRSB";
    case reco::leafserver::kHotRSB:
      return "kHotRSB";
    case reco::leafserver::kPersonalRSB:
      return "kPersonalRSB";
    case reco::leafserver::kVideoRSB:
      return "kVideoRSB";
    case reco::leafserver::kHumorRSB:
      return "kHumorRSB";
    case reco::leafserver::kLocalRSB:
      return "kLocalRSB";
    case reco::leafserver::kOtherRSB:
      return "kOtherRSB";
  }
  return "kUnkownRSB";
}

void DisplayRsbNumber(const char* name, const RecoDebugInfo& debug_info) {
  if (debug_info.rsb_number().size() <= 0) return;
  std::cout << std::endl;
  std::cout << "rsb_number:" << std::endl;
  std::cout << "| reco_strategy_id | strategy_name | return_number |" << std::endl;
  for (int i = 0; i < debug_info.rsb_number().size(); i ++) {
    auto rsb = debug_info.rsb_number(i);
    std::cout << "| " << rsb.reco_strategy_branch()
              << "\t| " << RecoStrategyBranch_Name(rsb.reco_strategy_branch())
              << "\t| " << rsb.return_number() << " |" << std::endl;
  }
  std::cout << std::endl;
}
template <class Type>
void DisplayList(const char* name, const Type& type_list) {
  if (type_list.size() <= 0) return;
  for (int i = 0; i < type_list.size(); i ++) {
    std::cout << " -- " << type_list.Get(i) << std::endl;
  }
}

void DisplayUserFeatureVector(const char* name,
                              const RepeatedPtrField<RecoDebugInfo::FeatureKeyValue>& fkv) {
  if (fkv.size() <= 0) return;
  std::cout << "-- " << name << " --" << std::endl;
  std::cout << "| key | value |" << std::endl;
  for (int i = 0; i < fkv.size(); i ++) {
    std::cout << "| " << fkv.Get(i).key() << " | " << fkv.Get(i).value() << " |" << std::endl;
  }
}

struct CategorySortIn {
  std::string key;
  int index;
  CategorySortIn(const std::string& k, int i) {
    key = k;
    index = i;
  }
  bool operator < (const CategorySortIn& b) const {
    if (key == b.key)
      return index < b.index;
    else
      return key < b.key;
  }
};

void DisplayUserCategoryFeatureVector(const char* name,
                                      const RepeatedPtrField<RecoDebugInfo::CategoryFeatureKeyValue>& fkv) {
  if (fkv.size() <= 0) return;
  std::cout << std::endl << "-- " << name << " --" << std::endl;
  std::vector<CategorySortIn> sort_list;
  for (int i = 0; i < fkv.size(); i ++) {
    sort_list.push_back(CategorySortIn(fkv.Get(i).name(), i));
  }
  sort(sort_list.begin(), sort_list.end());
  for (size_t i = 0; i < sort_list.size(); i ++) {
    DisplayUserFeatureVector(fkv.Get(sort_list[i].index).name().c_str(),
                             fkv.Get(sort_list[i].index).feature());
  }
}

void DisplayUserFeature(const char* name, const RecoDebugInfo::UserFeature& user_feature) {
  std::cout << std::endl;
  std::cout << name << std::endl;
  std::cout << "debug_user: " << user_feature.debug_user() << std::endl;
  std::cout << "lt_click_num: " << user_feature.lt_click_num() << std::endl;
  std::cout << "st_click_num: " << user_feature.st_click_num() << std::endl;
  std::cout << "total_click_num: " << user_feature.total_click_num() << std::endl;
  std::cout << "video_click_ratio: " << user_feature.video_click_ratio() << std::endl;
  std::cout << "session_video_show_num: " << user_feature.session_video_show_num() << std::endl;
  std::cout << "session_video_click_num: " << user_feature.session_video_click_num() << std::endl;
  std::cout << "session_video_click_ratio: " << user_feature.session_video_click_ratio() << std::endl;
  std::cout << "total_video_click_num: " << user_feature.total_video_click_num() << std::endl;
  std::cout << "dirty_level: " << user_feature.dirty_level() << std::endl;
  std::cout << "prov_id: " << user_feature.prov_id() << std::endl;
  std::cout << "city_id: " << user_feature.city_id() << std::endl;

  DisplayUserFeatureVector("l1_cates", user_feature.l1_cates());
  DisplayUserCategoryFeatureVector("l2_cates", user_feature.l2_cates());
  DisplayUserCategoryFeatureVector("cate_keywords", user_feature.cate_keywords());
  DisplayUserCategoryFeatureVector("cate_tags", user_feature.cate_tags());
  DisplayUserFeatureVector("topics", user_feature.topics());
  DisplayUserFeatureVector("raw_l1_cates", user_feature.raw_l1_cates());

  DisplayUserFeatureVector("dislike_tags", user_feature.dislike_tags());
  DisplayUserFeatureVector("dislike_sources", user_feature.dislike_sources());
  DisplayUserFeatureVector("dislike_categories", user_feature.dislike_categories());
  DisplayUserFeatureVector("subscript_words", user_feature.subscript_words());
  DisplayUserFeatureVector("subscript_wemedias", user_feature.subscript_wemedias());
  DisplayList("dislike_item_ids", user_feature.dislike_item_ids());
  DisplayList("user_area_ids", user_feature.user_area_ids());
  DisplayList("confidence_l1_cates", user_feature.confidence_l1_cates());
}

void DisplayCategoryItemInfoList(const char* name,
                                 const RepeatedPtrField<RecoDebugInfo::CategoryItemInfo>& info) {
  if (info.size() <= 0) return;
  std::cout << std::endl << "| " << name << " | " << std::endl;
  for (int i = 0; i < info.size(); i ++) {
    DisplayItemInfoList(info.Get(i).name().c_str(), info.Get(i).items());
  }
}

void DisplayDebugParam(const reco::leafserver::RecommendResponse& response) {
  if (!FLAGS_enable_debug || !response.has_reco_debug_info())
    return;
  if (FLAGS_display_raw_debug_info) {
    std::cout << response.reco_debug_info().Utf8DebugString() << std::endl;
  }
  auto debug_info = response.reco_debug_info();
  if (debug_info.has_user_feature()) {
    DisplayUserFeature("user_feature", debug_info.user_feature());
    return;
  }
  // more user-friendly format
  DisplayRsbNumber("rsb_number", debug_info);
  DisplayUserFeatureVector("user_category_distributes", debug_info.category_distributes());
  if (debug_info.has_user_feature())
    DisplayUserFeature("user_feature", debug_info.user_feature());
  DisplayItemInfoList("manual_whole_items", debug_info.manual_whole_items());
  DisplayItemInfoList("manual_personal_items", debug_info.manual_personal_items());
  DisplayItemInfoList("hot_items", debug_info.hot_items());
  DisplayItemInfoList("vedio_items", debug_info.vedio_items());
  DisplayItemInfoList("personal_items", debug_info.personal_items());
  DisplayItemInfoList("poi_items", debug_info.poi_items());
  DisplayCategoryItemInfoList("manual_category_items" , debug_info.manual_category_items());
  DisplayCategoryItemInfoList("personal_category_items", debug_info.personal_category_items());
  DisplayItemInfoList("first_complex_merge_items", debug_info.first_complex_merge_items());
  DisplayItemInfoList("adjust_by_rule_merge_items", debug_info.adjust_by_rule_merge_items());
}

