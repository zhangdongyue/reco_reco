#include <iostream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/common/channel_define.h"
#include "reco/serv/reco_leaf/strategy/common/reco_strategy_branch.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20001, "leaf server port");

DEFINE_string(user_id, "", "user id");
DEFINE_string(utdid, "", "utdid");
DEFINE_string(app_token, "uc-iflow", "");

DEFINE_string(acpf_type, "", "");
DEFINE_string(tacid, "", "");
DEFINE_string(tuicid, "", "");
DEFINE_string(sn, "", "");
DEFINE_string(imei, "", "");

DEFINE_string(news_date, "", "news date");
DEFINE_string(region_id, "", "region id");
DEFINE_string(ve, "10.10.1.812", "region id");
DEFINE_string(fr, "android", "region id");
DEFINE_int32(return_num, 8, "return num");
DEFINE_int32(reco_type, 0, "recommend type, default 0, news");
DEFINE_int64(channel_id, 100, "channel id");
DEFINE_string(net, "2", "网络环境");

DEFINE_string(province, "广东", "province name");
DEFINE_string(city, "广州", "city name");
DEFINE_string(school, "", "清华大学");

DEFINE_string(category, "", "requre category");
DEFINE_string(last_item_time, "", "");
DEFINE_bool(for_update, true, "");
DEFINE_string(user_info_field, "", "user info fields, split by comma");
DEFINE_string(push_item_id, "", "push item id");
DEFINE_string(channel_tags, "", "channel_tags split by comma");

DEFINE_double(user_latitude, 0, "");
DEFINE_double(user_longitude, 0, "");
DEFINE_int32(refresh_type, 0, "");
DEFINE_bool(is_new_user, false, "");

DEFINE_bool(enable_debug, false, "enable debug");
DEFINE_string(trace_item_ids, "", "trace itemids");
DEFINE_int32(debug_level, 0, "debug level");
DEFINE_string(trace_flags, "", "trace flags");
DEFINE_int32(trace_display_max_item_num, 10, "display in detail");
DEFINE_bool(only_display_user_info, false, "only display user info when enable debug");
DEFINE_bool(display_virgin_debug_info, false, "display virgin debug info");

void InitDebugParam(reco::leafserver::RecommendRequest* request);
void DisplayDebugParam(const reco::leafserver::RecommendResponse& response);

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client");

  reco::leafserver::RecommendRequest request;
  reco::leafserver::RecommendResponse response;
  reco::UserIdentity user;
  uint64 uid;
  CHECK(base::StringToUint64(FLAGS_user_id, &uid));
  std::string key = base::StringPrintf("uid-%lu-%ld", uid, base::GetTimestamp());
  uint64 reco_id = base::CalcTermSign(key.c_str(), key.size());
  user.set_user_id(uid);
  user.set_app_token(FLAGS_app_token);
  user.set_outer_id(FLAGS_user_id);
  user.set_utdid(FLAGS_utdid);

  if (!FLAGS_acpf_type.empty() && !FLAGS_tacid.empty()) {
    user.set_acpf_type(FLAGS_acpf_type);
    user.set_tacid(FLAGS_tacid);
  }
  if (!FLAGS_tuicid.empty()) {
    user.set_tuicid(FLAGS_tuicid);
  }
  if (!FLAGS_sn.empty()) {
    user.set_sn(FLAGS_sn);
  }
  if (!FLAGS_imei.empty()) {
    user.set_imei(FLAGS_imei);
  }

  request.set_app_token(FLAGS_app_token);
  request.set_return_num(FLAGS_return_num);
  request.mutable_user()->CopyFrom(user);
  request.set_reco_id(base::Uint64ToString(reco_id));
  request.set_recommend_type(FLAGS_reco_type);
  reco::leafserver::UcBrowserUserParam param;
  param.set_province(FLAGS_province);
  param.set_city(FLAGS_city);
  param.set_ve(FLAGS_ve);
  param.set_fr(FLAGS_fr);
  param.set_nt(FLAGS_net);
  param.set_isp("电信");
  param.set_isp("25832808141-27ecdce3");
  param.set_sv("app");
  param.set_latitude(FLAGS_user_latitude);
  param.set_longitude(FLAGS_user_longitude);
  request.mutable_uc_user_param()->CopyFrom(param);
  request.set_is_new_user(FLAGS_is_new_user);
  request.set_refresh_type(FLAGS_refresh_type);
  request.set_school(FLAGS_school);
  if (!FLAGS_channel_tags.empty()) {
    std::vector<std::string> flds;
    base::SplitString(FLAGS_channel_tags, ",", &flds);
    for (size_t i = 0; i < flds.size(); ++i) {
      request.add_channel_tags(flds[i]);
    }
  }

  reco::leafserver::FilterCriterion filter;
  filter.set_title_min_len(7);
  filter.set_title_max_len(40);
  request.mutable_filter_criterion()->CopyFrom(filter);

  if (FLAGS_channel_id != reco::common::kRecoChannelId) {
    request.set_channel_id(FLAGS_channel_id);
  }
  if (!FLAGS_news_date.empty()) {
    request.set_news_date(FLAGS_news_date);
  } else if (!FLAGS_category.empty()) {
    // TODO(who): ?
  }
  if (!FLAGS_region_id.empty()) {
    request.set_region_id(FLAGS_region_id);
  }
  if (!FLAGS_user_info_field.empty()) {
    std::vector<std::string> flds;
    base::SplitString(FLAGS_user_info_field, ",", &flds);
    for (size_t i = 0; i < flds.size(); ++i) {
      request.add_user_field_type(reco::user::UserFieldType(base::ParseInt32OrDie(flds[i])));
    }
  }
  if (!FLAGS_push_item_id.empty()) {
    uint64 push_item_id;
    CHECK(base::StringToUint64(FLAGS_push_item_id, &push_item_id));
    request.set_pushed_item(push_item_id);
  }
  InitDebugParam(&request);

  std::cout << request.Utf8DebugString() << std::endl;

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  stub.recommend(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "recommend fail.";
  } else {
    if (!FLAGS_only_display_user_info) {
      std::cout << response.user_info().Utf8DebugString() << std::endl;
      for (int i = 0; i < response.result_size(); ++i) {
        std::cout << response.result(i).Utf8DebugString() << std::endl;
      }
    }
    DisplayDebugParam(response);
  }

  return 0;
}

void InitDebugParam(reco::leafserver::RecommendRequest* request) {
  if (FLAGS_enable_debug) {
    reco::leafserver::RecoDebugParam* debug_param = request->mutable_reco_debug_param();
    debug_param->set_enable_debug(true);
    if (!FLAGS_trace_item_ids.empty()) {
      std::vector<std::string> itemids;
      base::SplitString(FLAGS_trace_item_ids, ",", &itemids);
      for (size_t i = 0;i < itemids.size(); i ++) {
        uint64 itemid;
        if (base::StringToUint64(itemids[i], &itemid))
          debug_param->add_trace_item_ids(itemid);
      }
    }
    debug_param->set_debug_level(FLAGS_debug_level);
    if (!FLAGS_trace_flags.empty()) {
      std::vector<std::string> flag_levels;
      base::SplitString(FLAGS_trace_flags, ",", &flag_levels);
      for (size_t i = 0; i < flag_levels.size(); i ++) {
        debug_param->add_debug_flag(flag_levels[i]);
      }
    }
  }
}

using google::protobuf::RepeatedPtrField;
using google::protobuf::RepeatedField;
using reco::leafserver::RecoDebugInfo;

void DisplayItemInfoList(const char* table_name, const RepeatedPtrField<RecoDebugInfo::ItemInfo>& items) {
  if (items.size() <= 0) return;
  std::cout << "-- Table: " << table_name << " - "
            << "ItemNumber: " << items.size() << " --"<< std::endl;
  std::cout << "| item_id | item_type | doc_id | site_level | time_level "
            << "| hot_level | sensitive_type | reco_score | create_time "
            << "| priority | category | sub_category | item_quality "
            << "| spider_score | lr_score | fm_score | ctr | shown_num | click_num "
            << "| strategy_type |" << std::endl;
  for (int i = 0; i < items.size() && i < FLAGS_trace_display_max_item_num; i ++) {
    auto item = items.Get(i);
    std::cout << "| " << i << "\t| " << item.item_id() << "\t| " << ItemType_Name(item.item_type())
        << "\t| " << item.doc_id() << "\t| " << SiteLevel_Name(item.site_level())
        << "\t| " << TimeLevel_Name(item.time_level()) << "\t| " << item.hot_level()
        << "\t| " << item.sensitive_level() << "\t| " << item.reco_score()
        << "\t| " << item.create_timestamp() << "\t| " << item.priority()
        << "\t| " << item.category() << "\t| " << item.sub_category()
        << "\t| " << item.item_quality() << "\t| " << item.spider_score()
        << "\t| " << item.lr_score() << "\t| " << item.fm_score()
        << "\t| " << item.ctr() << "\t| " << item.shown_num()
        << "\t| " << item.click_num() << "\t| " << StrategyType_Name(item.strategy_type())
        << "\t| " << std::endl;
  }
  std::cout << std::endl;
}

// like proto enum api
const char* RecoStrategyBranch_Name(int32_t rsb) {
  switch (rsb) {
    case reco::leafserver::kManualRSB:
      return "kManualRSB";
    case reco::leafserver::kHotRSB:
      return "kHotRSB";
    case reco::leafserver::kPersonalRSB:
      return "kPersonalRSB";
    case reco::leafserver::kVideoRSB:
      return "kVideoRSB";
    case reco::leafserver::kHumorRSB:
      return "kHumorRSB";
    case reco::leafserver::kLocalRSB:
      return "kLocalRSB";
    case reco::leafserver::kOtherRSB:
      return "kOtherRSB";
  }
  return "kUnkownRSB";
}

void DisplayRsbNumber(const char* name, const RecoDebugInfo& debug_info) {
  if (debug_info.rsb_number().size() <= 0) return;
  std::cout << std::endl;
  std::cout << "rsb_number:" << std::endl;
  std::cout << "| reco_strategy_id | strategy_name | return_number |" << std::endl;
  for (int i = 0; i < debug_info.rsb_number().size(); i ++) {
    auto rsb = debug_info.rsb_number(i);
    std::cout << "| " << rsb.reco_strategy_branch()
              << "\t| " << RecoStrategyBranch_Name(rsb.reco_strategy_branch())
              << "\t| " << rsb.return_number() << " |" << std::endl;
  }
  std::cout << std::endl;
}
template <class Type>
void DisplayList(const char* name, const Type& type_list) {
  if (type_list.size() <= 0) return;
  for (int i = 0; i < type_list.size(); i ++) {
    std::cout << " -- " << type_list.Get(i) << std::endl;
  }
}

void DisplayUserFeatureVector(const char* name,
                              const RepeatedPtrField<RecoDebugInfo::FeatureKeyValue>& fkv) {
  if (fkv.size() <= 0) return;
  std::cout << "-- " << name << " --" << std::endl;
  std::cout << "| key | value |" << std::endl;
  for (int i = 0; i < fkv.size(); i ++) {
    std::cout << "| " << fkv.Get(i).key() << " | " << fkv.Get(i).value() << " |" << std::endl;
  }
}

struct CategorySortIn {
  std::string key;
  int index;
  CategorySortIn(const std::string& k, int i) {
    key = k;
    index = i;
  }
  bool operator < (const CategorySortIn& b) const {
    if (key == b.key)
      return index < b.index;
    else
      return key < b.key;
  }
};

void DisplayUserCategoryFeatureVector(const char* name,
                                      const RepeatedPtrField<RecoDebugInfo::CategoryFeatureKeyValue>& fkv) {
  if (fkv.size() <= 0) return;
  std::cout << std::endl << "-- " << name << " --" << std::endl;
  std::vector<CategorySortIn> sort_list;
  for (int i = 0; i < fkv.size(); i ++) {
    sort_list.push_back(CategorySortIn(fkv.Get(i).name(), i));
  }
  sort(sort_list.begin(), sort_list.end());
  for (size_t i = 0; i < sort_list.size(); i ++) {
    DisplayUserFeatureVector(fkv.Get(sort_list[i].index).name().c_str(),
                             fkv.Get(sort_list[i].index).feature());
  }
}

void DisplayUserFeature(const char* name, const RecoDebugInfo::UserFeature& user_feature) {
  std::cout << std::endl;
  std::cout << name << std::endl;
  std::cout << "debug_user: " << user_feature.debug_user() << std::endl;
  std::cout << "lt_click_num: " << user_feature.lt_click_num() << std::endl;
  std::cout << "st_click_num: " << user_feature.st_click_num() << std::endl;
  std::cout << "total_click_num: " << user_feature.total_click_num() << std::endl;
  std::cout << "video_click_ratio: " << user_feature.video_click_ratio() << std::endl;
  std::cout << "session_video_show_num: " << user_feature.session_video_show_num() << std::endl;
  std::cout << "session_video_click_num: " << user_feature.session_video_click_num() << std::endl;
  std::cout << "session_video_click_ratio: " << user_feature.session_video_click_ratio() << std::endl;
  std::cout << "total_video_click_num: " << user_feature.total_video_click_num() << std::endl;
  std::cout << "dirty_level: " << user_feature.dirty_level() << std::endl;
  std::cout << "prov_id: " << user_feature.prov_id() << std::endl;
  std::cout << "city_id: " << user_feature.city_id() << std::endl;

  DisplayUserFeatureVector("l1_cates", user_feature.l1_cates());
  DisplayUserCategoryFeatureVector("l2_cates", user_feature.l2_cates());
  DisplayUserCategoryFeatureVector("cate_keywords", user_feature.cate_keywords());
  DisplayUserCategoryFeatureVector("cate_tags", user_feature.cate_tags());
  DisplayUserFeatureVector("topics", user_feature.topics());
  DisplayUserFeatureVector("raw_l1_cates", user_feature.raw_l1_cates());

  DisplayUserFeatureVector("dislike_tags", user_feature.dislike_tags());
  DisplayUserFeatureVector("dislike_sources", user_feature.dislike_sources());
  DisplayUserFeatureVector("dislike_categories", user_feature.dislike_categories());
  DisplayUserFeatureVector("subscript_words", user_feature.subscript_words());
  DisplayUserFeatureVector("subscript_wemedias", user_feature.subscript_wemedias());
  DisplayList("dislike_item_ids", user_feature.dislike_item_ids());
  DisplayList("user_area_ids", user_feature.user_area_ids());
  DisplayList("confidence_l1_cates", user_feature.confidence_l1_cates());
}

void DisplayCategoryItemInfoList(const char* name,
                                 const RepeatedPtrField<RecoDebugInfo::CategoryItemInfo>& info) {
  if (info.size() <= 0) return;
  std::cout << std::endl << "| " << name << " | " << std::endl;
  for (int i = 0; i < info.size(); i ++) {
    DisplayItemInfoList(info.Get(i).name().c_str(), info.Get(i).items());
  }
}

void DisplayDebugParam(const reco::leafserver::RecommendResponse& response) {
  if (!FLAGS_enable_debug || !response.has_reco_debug_info())
    return;
  auto debug_info = response.reco_debug_info();
  if (FLAGS_only_display_user_info && debug_info.has_user_feature()) {
    DisplayUserFeature("user_feature", debug_info.user_feature());
    return;
  }
  if (FLAGS_display_virgin_debug_info) {
    std::cout << response.reco_debug_info().Utf8DebugString() << std::endl;
  }
  // more user-friendly format
  DisplayRsbNumber("rsb_number", debug_info);
  DisplayUserFeatureVector("user_category_distributes", debug_info.category_distributes());
  if (debug_info.has_user_feature())
    DisplayUserFeature("user_feature", debug_info.user_feature());
  DisplayItemInfoList("manual_whole_items", debug_info.manual_whole_items());
  DisplayItemInfoList("manual_personal_items", debug_info.manual_personal_items());
  DisplayItemInfoList("hot_items", debug_info.hot_items());
  DisplayItemInfoList("vedio_items", debug_info.vedio_items());
  DisplayItemInfoList("personal_items", debug_info.personal_items());
  DisplayItemInfoList("poi_items", debug_info.poi_items());
  DisplayCategoryItemInfoList("manual_category_items" , debug_info.manual_category_items());
  DisplayCategoryItemInfoList("personal_category_items", debug_info.personal_category_items());
  DisplayItemInfoList("first_complex_merge_items", debug_info.first_complex_merge_items());
  DisplayItemInfoList("adjust_by_rule_merge_items", debug_info.adjust_by_rule_merge_items());
}

