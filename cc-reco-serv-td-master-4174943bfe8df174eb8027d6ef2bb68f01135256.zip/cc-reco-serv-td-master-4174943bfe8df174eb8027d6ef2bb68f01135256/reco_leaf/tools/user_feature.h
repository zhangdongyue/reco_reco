#pragma once

#include <string>
#include <queue>
#include <vector>
#include <math.h>
#include <unordered_set>
#include <unordered_map>

#include "reco/serv/reco_leaf/strategy/feature_api.h"
#include "reco/bizc/proto/user.pb.h"
#include "base/time/time.h"

namespace reco {
class NewsIndex;

namespace leafserver {

// 用户特征相关
//
class UserFeature {
 public:
  UserFeature(const reco::NewsIndex* index);
  ~UserFeature();

  void ResetUser(const reco::UserInfo* user_info, bool debug_user);

  // 融合用户长期/短期兴趣点
  void MergeUserFeature();

 public:
  struct DislikeItemInfo {
    uint64 item_id;
    std::string category;
    std::unordered_map<std::string, float> item_feas;
  };
  typedef std::map<std::string, double> FeatureMap;

  // 用户信息
  const reco::UserInfo* user_info_;

  // 各类特征分别汇总
  FeatureMap user_keywords_;
  FeatureMap user_topics_;
  FeatureMap user_tags_;
  FeatureMap user_categories_;

  // keyword 和 tag 特征分类别存储
  std::unordered_map<std::string, FeatureMap> category_keywords_;
  std::unordered_map<std::string, FeatureMap> category_tags_;

  std::vector<DislikeItemInfo> dislike_items_;

  bool is_debug_user_;

 private:
  // 预处理
  void PreProcessFeature();
  // 长期兴趣特征
  void MergeLongTermFeature();
  // 短期兴趣特征
  void MergeShortTermFeature();
  // Dmp 兴趣
  void MergeDmpFeature();
  // 微薄特征
  void MergeWeiboFeature();
  // 频道选择特征
  void MergeChannelFeature();
  // 用户角色特征
  void MergeRoleFeature();
  // 展现历史特征 
  void MergeShowFeature();
  // 屏幕选择特征
  void MergeScreenFeature();
  // 不喜欢新闻特征
  void MergeDislikeFeature();
  // 后处理
  void PostProcessFeature();
  // 特征选择，主要是特征截断
  void SelectFeature(std::map<std::string, double>* user_fea, size_t limit_size);

  std::string genCategoryWordKey(const std::string& category, const std::string& word) {
    return category + "-" + word;
  }

  void PrintUserFeature(const std::string& prefix_info);

  // 计算给定类型一次点击的权重影响
  float CalcRecentClickInfluence(const std::string& category) const;

  void loadDict();
  bool parseFeas(const std::string& fea_wt_str, std::vector<std::pair<std::string, float> >* feas);
  bool normalizeFeas(std::vector<std::pair<std::string, float> >* feas);
  void loadChannelCategoryDict(const std::vector<std::string>& lines);
  void loadUserRoleCategoryDict(const std::vector<std::string>& lines);
  void loadUserRoleKeywordDict(const std::vector<std::string>& lines);
  void loadTimeCategoryBoostDict(const std::vector<std::string>& lines);

  bool CalcCategoryDistributes();

  float CalcExploreRatio(const reco::UserInfo* user_info) const;
 private:
  static const char* kChannelCategoryFile;
  static const char* kUserRoleKeywordFile;
  static const char* kUserRoleCategoryFile;
  static const char* kTimeCategoryBoostFile;

  const NewsIndex* news_index_;

  typedef std::vector<std::pair<std::string, float> > CategoryDistributes;
  typedef std::vector<std::pair<std::string, float> > KeywordDistributes;

  // channel 对应的 category 及 权重
  std::unordered_map<int64, CategoryDistributes> channel_categories;
  // user_role 对应的 keyword 及 权重
  std::unordered_map<std::string, KeywordDistributes> user_role_keywords;
  // user_role 对应的 category 及 权重
  std::unordered_map<std::string, CategoryDistributes> user_role_categories;

//   const std::unordered_map<int64, std::vector<std::pair<std::string, float> > >* channel_categories_;
//   const std::unordered_map<std::string, std::vector<std::pair<std::string, float> > >* user_role_categories_;
//   const std::unordered_map<std::string, std::vector<std::pair<std::string, float> > >* user_role_keywords_;
// 
  base::Time current_time_;
};
}
}

