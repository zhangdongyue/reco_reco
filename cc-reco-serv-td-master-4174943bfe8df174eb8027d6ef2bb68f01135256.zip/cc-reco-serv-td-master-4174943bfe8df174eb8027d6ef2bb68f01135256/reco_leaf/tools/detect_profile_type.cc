#include <iostream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"
#include "reco/serv/reco_leaf/strategy/common/profile_type.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/reco_user_server.pb.h"
#include "reco/bizc/proto/user.pb.h"


DEFINE_string(user_server_ip, "127.0.0.1", "user server ip");
DEFINE_int32(user_server_port, 23031, "user server port");

DEFINE_string(mergelog_file, "", "mereglog file");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "detect profile type");

  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_mergelog_file, &lines);
  std::vector<std::string> flds;
  std::unordered_map<uint64, std::string> userid_map;
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 10u) continue;
    uint64 user_id;
    if (!base::StringToUint64(flds[9], &user_id)) {
      LOG(ERROR) << lines[i];
      continue;
    }
    userid_map[user_id] = flds[1];
  }

  net::rpc::RpcClientChannel channel(FLAGS_user_server_ip.c_str(), FLAGS_user_server_port);
  CHECK(channel.Connect());
  reco::userserver::UserService::Stub stub(&channel);

  std::unordered_map<uint64, reco::user::UserInfo> user_map;
  for (auto it = userid_map.begin(); it != userid_map.end(); ++it) {
    reco::user::GetUserRequest request;
    reco::user::GetUserResponse response;

    reco::UserIdentity user;
    user.set_app_token(it->second);
    user.set_outer_id("");
    user.set_user_id(it->first);

    request.mutable_user()->CopyFrom(user);

    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(500);
    stub.getUserInfo(&rpc, &request, &response, NULL);
    rpc.Wait();

    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "request doc info failed. ";
      continue;
    } else {
      user_map[it->first] = response.user_info();
    }
  }

  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 10u) continue;
    uint64 user_id;
    if (!base::StringToUint64(flds[9], &user_id)) {
      LOG(ERROR) << lines[i];
      continue;
    }

    const std::string& title = flds[16];
    const std::string& category = flds[17];
    const reco::user::UserInfo& user_info = user_map[user_id];
    reco::leafserver::ProfileTypeDetect detect(user_info);
    reco::DmpProfileType dmp_profile_type;
    reco::ProfileType profile_type;
    detect.DetectProfileType(category, "", &profile_type, &dmp_profile_type);
    std::cout << user_id << "\t" << title << "\t" << category << "\t"
              << profile_type << "\t" << dmp_profile_type << std::endl;
  }


  return 0;
}
