#include <iostream>
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/time/timestamp.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20001, "leaf server port");

DEFINE_int32(request_type, 0, "");

DEFINE_string(user_id, "", "user id");
DEFINE_string(app_token, "uc-iflow", "doc server ip");

DEFINE_string(province, "广东", "province name");
DEFINE_string(city, "广州", "city name");
DEFINE_double(user_latitude, 0, "");
DEFINE_double(user_longitude, 0, "");

DEFINE_int64(region_id, 110000, "city region id");
DEFINE_string(channel_region_id, "", "channel region id");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client");

  uint64 uid;
  CHECK(base::StringToUint64(FLAGS_user_id, &uid));
  std::string key = base::StringPrintf("uid-%lu-%ld", uid, base::GetTimestamp());
  uint64 reco_id = base::CalcTermSign(key.c_str(), key.size());

  reco::UserIdentity user;
  user.set_user_id(uid);
  user.set_app_token(FLAGS_app_token);
  user.set_outer_id(FLAGS_user_id);

  reco::leafserver::UcBrowserUserParam param;
  param.set_province(FLAGS_province);
  param.set_city(FLAGS_city);
  param.set_latitude(FLAGS_user_latitude);
  param.set_longitude(FLAGS_user_longitude);

  reco::leafserver::NewsMapRequest request;
  reco::leafserver::NewsMapResponse response;
  if (FLAGS_request_type == 0) {
    request.set_request_type(reco::leafserver::NewsMapRequest::kGetUserPOIInfo);
    request.set_reco_id(base::Uint64ToString(reco_id));
    request.mutable_user()->CopyFrom(user);
    request.mutable_uc_user_param()->CopyFrom(param);
    request.set_channel_region_id(FLAGS_channel_region_id);
  } else if (FLAGS_request_type == 1) {
    request.set_request_type(reco::leafserver::NewsMapRequest::kGetPOINewsCount);
    request.set_reco_id(base::Uint64ToString(reco_id));
    request.mutable_user()->CopyFrom(user);
    request.set_region_id(FLAGS_region_id);
    request.set_channel_region_id(FLAGS_channel_region_id);
  } else if (FLAGS_request_type == 2) {
    request.set_request_type(reco::leafserver::NewsMapRequest::kGetPOINewsList);
    request.set_reco_id(base::Uint64ToString(reco_id));
    request.mutable_user()->CopyFrom(user);
    request.set_region_id(FLAGS_region_id);
    request.set_channel_region_id(FLAGS_channel_region_id);
  }

  std::cout << request.Utf8DebugString() << std::endl;
  std::cout << "request end" << std::endl;

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  stub.getNewsMap(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "recommend fail.";
  } else {
    std::cout << response.Utf8DebugString() << std::endl;
  }
  return 0;
}
