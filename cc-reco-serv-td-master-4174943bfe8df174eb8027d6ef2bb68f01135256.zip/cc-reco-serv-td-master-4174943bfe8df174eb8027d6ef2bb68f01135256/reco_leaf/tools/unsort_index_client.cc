#include <iostream>
#include <fstream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20001, "leaf server port");
DEFINE_int32(return_num, 10, "return num");
DEFINE_int32(start_num, 0, "page number");
DEFINE_int32(index_type, 3, "index type");
DEFINE_string(literal, "科技", "索引名称");
DEFINE_uint64(item_id, 0u, "只查询该item_id");
DEFINE_int32(need_attr, 0, "need attr or only item_id");
DEFINE_string(output_filepath, "./out", "输出结果文件路径");

int GetIndexQueueUnsort() {
  reco::leafserver::GetIndexQueueUnsortRequest request;
  reco::leafserver::GetIndexQueueUnsortResponse response;
  request.set_index_type((reco::leafserver::IndexType)FLAGS_index_type);
  request.set_literal(FLAGS_literal);
  request.set_return_num(FLAGS_return_num);
  request.set_start_num(FLAGS_start_num);
  request.set_need_attr(FLAGS_need_attr != 0);
  if ( FLAGS_item_id != 0u) {
    request.set_item_id(FLAGS_item_id);
  }
  LOG(INFO) << request.Utf8DebugString();

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  if (!channel.Connect()) {
    LOG(ERROR) << "connect failed";
    return -1;
  }
  reco::leafserver::RecommendService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(5);
  stub.getIndexQueueUnsort(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk) {
    LOG(ERROR) << "rpc failed";
    return -1;
  } else if (!response.success()) {
    LOG(ERROR) << "get res fail, err_msg=" << response.err_message();
    return -1;
  }

  std::ofstream   ofresult;
  ofresult.open(FLAGS_output_filepath, std::ios::out);

  for ( int i=0; i < response.item_id_size(); i++) {
    
    if( FLAGS_need_attr == 0 ) {
      ofresult << "item_id=" << response.item_id(i) << std::endl;
		} else {
			const reco::ItemInfoHa3& item = response.item_info(i); 
			auto item_id = item.item_id();
			ofresult << "item_id=" << item_id << " keyword_norm=" << item.keyword_norm() << std::endl;
			ofresult << "item_id=" << item_id << " plsa_topic_norm=" << item.plsa_topic_norm() << std::endl;
			ofresult << "item_id=" << item_id << " semantic_tag_norm=" << item.semantic_tag_norm() << std::endl;
			ofresult << "item_id=" << item_id << " tag_norm=" << item.tag_norm() << std::endl;
			ofresult << "item_id=" << item_id << " topic_norm=" << item.topic_norm() << std::endl;
			ofresult << "item_id=" << item_id << " video_black_edge_ratio=" << item.video_black_edge_ratio() << std::endl;
			ofresult << "item_id=" << item_id << " wordvec_norm=" << item.wordvec_norm() << std::endl;
			ofresult << "item_id=" << item_id << " content_attr=" << item.content_attr() << std::endl;
			ofresult << "item_id=" << item_id << " content_length=" << item.content_length() << std::endl;
			ofresult << "item_id=" << item_id << " crawl_timestamp=" << item.crawl_timestamp() << std::endl;
			ofresult << "item_id=" << item_id << " create_timestamp=" << item.create_timestamp() << std::endl;
			ofresult << "item_id=" << item_id << " docmask=" << item.docmask() << std::endl;
			ofresult << "item_id=" << item_id << " expire_timestamp=" << item.expire_timestamp() << std::endl;
			ofresult << "item_id=" << item_id << " has_video_storage_info=" << item.has_video_storage_info() << std::endl;
			ofresult << "item_id=" << item_id << " image_count=" << item.image_count() << std::endl;
			ofresult << "item_id=" << item_id << " item_has_reviewed=" << item.item_has_reviewed() << std::endl;
			ofresult << "item_id=" << item_id << " item_is_yuanchuang=" << item.item_is_yuanchuang() << std::endl;
			ofresult << "item_id=" << item_id << " item_type=" << item.item_type() << std::endl;
			ofresult << "item_id=" << item_id << " jingpin_score=" << item.jingpin_score() << std::endl;
			ofresult << "item_id=" << item_id << " novel_update_time=" << item.novel_update_time() << std::endl;
			ofresult << "item_id=" << item_id << " paragraph_num=" << item.paragraph_num() << std::endl;
			ofresult << "item_id=" << item_id << " popularity=" << item.popularity() << std::endl;
			ofresult << "item_id=" << item_id << " posterior_item_q=" << item.posterior_item_q() << std::endl;
			ofresult << "item_id=" << item_id << " publish_time=" << item.publish_time() << std::endl;
			ofresult << "item_id=" << item_id << " title_length=" << item.title_length() << std::endl;
			ofresult << "item_id=" << item_id << " ucbr_style_type=" << item.ucbr_style_type() << std::endl;
			ofresult << "item_id=" << item_id << " video_count=" << item.video_count() << std::endl;
			ofresult << "item_id=" << item_id << " video_length=" << item.video_length() << std::endl;
			ofresult << "item_id=" << item_id << " video_quality_level=" << item.video_quality_level() << std::endl;
			ofresult << "item_id=" << item_id << " video_storage_info_status=" << item.video_storage_info_status() << std::endl;
			ofresult << "item_id=" << item_id << " video_vulgar_level=" << item.video_vulgar_level() << std::endl;
			ofresult << "item_id=" << item_id << " app_token=" << item.app_token() << std::endl;
			ofresult << "item_id=" << item_id << " image_hash=" << item.image_hash() << std::endl;
			ofresult << "item_id=" << item_id << " item_subscripts=" << item.item_subscripts() << std::endl;
			ofresult << "item_id=" << item_id << " keyword_feature_list=" << item.keyword_feature_list() << std::endl;
			ofresult << "item_id=" << item_id << " keyword_list=" << item.keyword_list() << std::endl;
			ofresult << "item_id=" << item_id << " novel_id=" << item.novel_id() << std::endl;
			ofresult << "item_id=" << item_id << " orig_source_media=" << item.orig_source_media() << std::endl;
			ofresult << "item_id=" << item_id << " orig_source=" << item.orig_source() << std::endl;
			ofresult << "item_id=" << item_id << " outer_id=" << item.outer_id() << std::endl;
			ofresult << "item_id=" << item_id << " paragraph_hash=" << item.paragraph_hash() << std::endl;
			ofresult << "item_id=" << item_id << " plsa_topic_feature_list=" << item.plsa_topic_feature_list() << std::endl;
			ofresult << "item_id=" << item_id << " plsa_topic_list=" << item.plsa_topic_list() << std::endl;
			ofresult << "item_id=" << item_id << " raw_summary=" << item.raw_summary() << std::endl;
			ofresult << "item_id=" << item_id << " region_from_title=" << item.region_from_title() << std::endl;
			ofresult << "item_id=" << item_id << " region_restrict=" << item.region_restrict() << std::endl;
			ofresult << "item_id=" << item_id << " region=" << item.region() << std::endl;
			ofresult << "item_id=" << item_id << " semantic_tag_feature_list=" << item.semantic_tag_feature_list() << std::endl;
			ofresult << "item_id=" << item_id << " semantic_tag_list=" << item.semantic_tag_list() << std::endl;
			ofresult << "item_id=" << item_id << " source_media=" << item.source_media() << std::endl;
			ofresult << "item_id=" << item_id << " source=" << item.source() << std::endl;
			ofresult << "item_id=" << item_id << " tag_feature_list=" << item.tag_feature_list() << std::endl;
			ofresult << "item_id=" << item_id << " tag_list=" << item.tag_list() << std::endl;
			ofresult << "item_id=" << item_id << " topic_feature_list=" << item.topic_feature_list() << std::endl;
			ofresult << "item_id=" << item_id << " topic_list=" << item.topic_list() << std::endl;
			ofresult << "item_id=" << item_id << " ucb_editor_name=" << item.ucb_editor_name() << std::endl;
			ofresult << "item_id=" << item_id << " wemedia_person=" << item.wemedia_person() << std::endl;
			ofresult << "item_id=" << item_id << " wordvec_feature_list=" << item.wordvec_feature_list() << std::endl;
			ofresult << "item_id=" << item_id << " wordvec_list=" << item.wordvec_list() << std::endl;
			ofresult << "item_id=" << item_id << " youku_video_id=" << item.youku_video_id() << std::endl;
			ofresult << "item_id=" << item_id << " priority=" << item.priority() << std::endl;
			ofresult << "item_id=" << item_id << " special_contain_item_list=" << item.special_contain_item_list() << std::endl;
			ofresult << "item_id=" << item_id << " special_prevew_item_list=" << item.special_prevew_item_list() << std::endl;
			ofresult << "item_id=" << item_id << " video_poster_problem_info=" << item.video_poster_problem_info() << std::endl;
			ofresult << "item_id=" << item_id << " category=" << item.category() << std::endl;
			ofresult << "item_id=" << item_id << " channel=" << item.channel() << std::endl;
			ofresult << "item_id=" << item_id << " item_event_tag=" << item.item_event_tag() << std::endl;
			ofresult << "item_id=" << item_id << " item_show_tag=" << item.item_show_tag() << std::endl;
			ofresult << "item_id=" << item_id << " gaode_poi=" << item.gaode_poi() << std::endl;
			ofresult << "item_id=" << item_id << " item_quality_attr=" << item.item_quality_attr() << std::endl;
			ofresult << "item_id=" << item_id << " time_axis_results=" << item.time_axis_results() << std::endl;
			ofresult << "item_id=" << item_id << " ucbr_deliver=" << item.ucbr_deliver() << std::endl;
			ofresult << "item_id=" << item_id << " category_candidates=" << item.category_candidates() << std::endl;
			ofresult << "item_id=" << item_id << " title=" << item.title() << std::endl;
		}
  }

  return 0;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client for unsorted index, eg. ads index result");
  return GetIndexQueueUnsort();
}
