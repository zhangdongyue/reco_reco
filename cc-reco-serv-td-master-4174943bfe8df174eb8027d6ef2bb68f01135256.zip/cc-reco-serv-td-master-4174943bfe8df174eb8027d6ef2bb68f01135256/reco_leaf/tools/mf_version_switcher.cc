#include <string>
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/common/sleep.h"
#include "net/rpc/rpc.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"

DEFINE_string(ip_list_path, "", "");
DEFINE_int32(port, 20150, "");
DEFINE_int32(thread_num, 10, "");
DEFINE_int64(timeout, 1000 * 60 * 5, "");
DEFINE_bool(is_mf_matrix, false, "");
DEFINE_bool(is_fac_machine_matrix, false, "");
DEFINE_string(model_version, "0", "");
DEFINE_int32(sleep_time, 60000, "");

class DictSwitcher {
 public:
  bool DoSwitch();

 private:
  bool GetIPList();
  bool SingleThreadUpdate(const std::string &ip);
  void MultiThreadUpdateProcess();

 private:
  thread::BlockingQueue<std::string> ip_queue_;
  thread::BlockingQueue<std::string> fail_ip_queue_;
};

bool DictSwitcher::DoSwitch() {
  if (!GetIPList()) return false;

  int retry = 0;
  static const int kMaxRetryTime = 3;
  bool success = false;
  while (retry < kMaxRetryTime) {
    thread::ThreadPool thread_pool(FLAGS_thread_num);
    for (int i = 0; i < FLAGS_thread_num; ++i) {
      thread_pool.AddTask(NewCallback(this, &DictSwitcher::MultiThreadUpdateProcess));
    }
    thread_pool.JoinAll();
    if (fail_ip_queue_.Empty()) {
      success = true;
      break;
    }
    
    ++retry;
    while (!fail_ip_queue_.Empty()) {
      std::string fail_ip = fail_ip_queue_.Take();
      LOG(ERROR) << "mf version switch fail [" << fail_ip << ", retry: " << retry << "]";
      CHECK(ip_queue_.Put(fail_ip));
    }
  }
  if (success) {
    LOG(INFO) << "mf version switch success";
  } else {
    LOG(ERROR) << "mf version switch fail";
  }
  return success;
}

bool DictSwitcher::SingleThreadUpdate(const std::string &ip) {
  LOG(INFO) << "dict reload start [" << ip << ":" << FLAGS_port << "]";

  net::rpc::RpcClientChannel::Options rpc_option;
  rpc_option.idle_timeout = FLAGS_timeout;
  net::rpc::RpcClientChannel channel(ip, FLAGS_port, rpc_option);
  if (!channel.Connect()) {
    LOG(ERROR) << "connect to server fail [" << ip << ":" << FLAGS_port << "]";
    return false;
  }
  reco::leafserver::RecommendService::Stub stub(&channel);

  net::rpc::RpcClientController rpc_controller;
  reco::leafserver::ModelVerRequest request;
  reco::leafserver::ModelVerResponse response;
  
  if (FLAGS_is_mf_matrix) {
    request.set_model_type(reco::leafserver::MFMatrix);
    request.set_version(FLAGS_model_version);
  }
  else if (FLAGS_is_fac_machine_matrix) {
    request.set_model_type(reco::leafserver::FacMachineMatrix);
    request.set_version(FLAGS_model_version);
  } else {
    return false;
  }

  stub.setModelVersion(&rpc_controller, &request, &response, NULL);
  rpc_controller.Wait();
  if (rpc_controller.GetRpcErrno() != net::rpc::kOk) {
    LOG(ERROR) << "rpc error " << ip << "[" << rpc_controller.error_text() << "]";
    return false;
  }

  if (response.success()) {
    LOG(INFO) << "dict reload success " << ip;
  } else {
    LOG(ERROR) << "dict reload fail " << ip << "[" << response.err_message() << "]";
    return false;
  }
  return true;
}

void DictSwitcher::MultiThreadUpdateProcess() {
  std::string ip;
  while (!ip_queue_.Empty()) {
    if (ip_queue_.TryTake(&ip) != 1) {
      continue;
    }
    if (!SingleThreadUpdate(ip)) {
      CHECK(fail_ip_queue_.Put(ip));
      continue;
    }
    base::SleepForMilliseconds(FLAGS_sleep_time);
  }
}

bool DictSwitcher::GetIPList() {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(FLAGS_ip_list_path, &lines)) {
    LOG(ERROR) << "read ip list fail: " << FLAGS_ip_list_path;
    return false;
  }

  for (int i = 0; i < (int)lines.size(); ++i) {
    base::TrimWhitespaces(&lines[i]);
    if (lines[i].empty()) continue;
    if (lines[i][0] == '#') continue;
    std::vector<std::string> tokens;
    base::SplitString(lines[i], ".", &tokens);
    if (tokens.size() != 4) {
      LOG(WARNING) << "ip format error " << lines[i];
      continue;
    }

    bool ip_checked = true;
    for (int j = 0; j < (int)tokens.size(); ++j) {
      uint32 byte;
      if (!base::StringToUint(tokens[j], &byte) ||
          byte >= 256) {
        ip_checked = false;
        break;
      }
    }
    if (!ip_checked) {
      LOG(WARNING) << "ip format error " << lines[i];
      continue;
    }
    CHECK(ip_queue_.Put(lines[i]));
  }
  if (ip_queue_.Empty()) {
    LOG(ERROR) << "No IP found in " << FLAGS_ip_list_path;
    return false;
  }
  LOG(INFO) << "load ip list success [" << ip_queue_.Size() << "]";
  return true;
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");
  DictSwitcher switcher;
  if (!switcher.DoSwitch()) return -1;
  return 0;
}
