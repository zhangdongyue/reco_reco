#include <iostream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/item.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 23031, "leaf server port");

DEFINE_int32(dict_type, -1, "dict type, default -1, no type");
DEFINE_string(batch_model_name_for_online_learning, "", "");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client");

  reco::leafserver::ReloadDictRequest request;
  reco::leafserver::ReloadDictResponse response;

  if (!reco::leafserver::DynamicDictType_IsValid(FLAGS_dict_type)) {
    LOG(ERROR) << "error dict: " << FLAGS_dict_type;
    return 1;
  }
  request.set_dict_type(static_cast<reco::leafserver::DynamicDictType>(FLAGS_dict_type));
  if (!FLAGS_batch_model_name_for_online_learning.empty()) {
    request.set_batch_model_name_for_online_learning(FLAGS_batch_model_name_for_online_learning);
  }
  // request.set_dict_type(reco::leafserver::kRecoModel);

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  LOG(INFO) << "begin to load dict: " << FLAGS_dict_type;

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(3600);
  stub.reloadDict(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "reload fail.";
  } else {
    LOG(INFO) << "reload succ";
  }

  return 0;
}
