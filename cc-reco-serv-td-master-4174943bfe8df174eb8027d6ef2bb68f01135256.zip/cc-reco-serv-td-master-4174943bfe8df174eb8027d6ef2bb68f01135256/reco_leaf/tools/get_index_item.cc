#include <iostream>
#include <fstream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/item.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20001, "leaf server port");
DEFINE_string(item_id_file, "", "uint64 item id file");
DEFINE_string(item_id, "", "uint64 item id");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client");
  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  if (FLAGS_item_id_file.empty()) {  // load id from gflag
    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(120);
    reco::leafserver::GetIndexItemInfoRequest request;
    request.set_item_id(base::ParseUint64OrDie(FLAGS_item_id));
    reco::leafserver::GetIndexItemInfoResponse response;
    stub.getIndexItemInfo(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk) {
      LOG(ERROR) << "request fail: " << rpc.error_text();
    } else {
      std::cout << response.Utf8DebugString() << std::endl;
    }
  } else {  // load id from file
    std::ifstream fin(FLAGS_item_id_file.c_str());
    CHECK(fin) << "open file error: " << FLAGS_item_id_file;
    std::string line;
    while (getline(fin, line)) {
      net::rpc::RpcClientController rpc;
      rpc.SetDeadline(120);
      reco::leafserver::GetIndexItemInfoRequest request;
      request.set_item_id(base::ParseUint64OrDie(line));
      reco::leafserver::GetIndexItemInfoResponse response;
      stub.getIndexItemInfo(&rpc, &request, &response, NULL);
      rpc.Wait();
      if (rpc.status() != net::rpc::RpcClientController::kOk) {
        LOG(ERROR) << "request fail: " << rpc.error_text();
      } else {
        std::cout << response.Utf8DebugString() << std::endl;
      }
    }
  }

  return 0;
}
