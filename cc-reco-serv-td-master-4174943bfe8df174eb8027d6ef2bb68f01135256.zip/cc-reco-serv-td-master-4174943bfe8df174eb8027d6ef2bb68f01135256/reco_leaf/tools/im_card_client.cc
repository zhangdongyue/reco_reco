#include <iostream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/item.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20001, "leaf server port");

DEFINE_string(user_id, "", "user id");
DEFINE_string(utdid, "", "utdid");
DEFINE_string(app_token, "uc-iflow", "doc server ip");
DEFINE_string(news_date, "", "news date");
DEFINE_string(region_id, "", "region id");
DEFINE_string(ve, "10.10.1.812", "region id");
DEFINE_string(fr, "android", "region id");
DEFINE_int32(return_num, 8, "return num");
DEFINE_int32(reco_type, 0, "recommend type, default 0, news");
DEFINE_int64(channel_id, 100, "channel id");

DEFINE_string(province, "广东", "province name");
DEFINE_string(city, "广州", "city name");

DEFINE_string(category, "", "requre category");
DEFINE_string(last_item_time, "", "");
DEFINE_bool(for_update, true, "");
DEFINE_string(user_info_field, "", "user info fields, split by comma");

DEFINE_double(user_latitude, 0, "");
DEFINE_double(user_longitude, 0, "");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "im card client");

  reco::leafserver::ImCardRecoRequest request;
  reco::leafserver::ImCardRecoResponse response;
  reco::UserIdentity user;
  uint64 uid;
  CHECK(base::StringToUint64(FLAGS_user_id, &uid));
  std::string key = base::StringPrintf("uid-%lu-%ld", uid, base::GetTimestamp());
  uint64 reco_id = base::CalcTermSign(key.c_str(), key.size());
  user.set_user_id(uid);
  user.set_app_token(FLAGS_app_token);
  user.set_utdid(FLAGS_utdid);
  user.set_outer_id(FLAGS_user_id);

  request.set_app_token(FLAGS_app_token);
  request.set_return_num(FLAGS_return_num);
  request.mutable_user()->CopyFrom(user);
  request.set_reco_id(base::Uint64ToString(reco_id));
  request.set_card_type(reco::leafserver::kMidDayImCard);

  std::cout << request.Utf8DebugString() << std::endl;

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  stub.imCardRecommend(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "im card recommend fail.";
  } else {
    std::cout << response.user_info().Utf8DebugString() << std::endl;
    if (!response.has_im_result()) {
      LOG(ERROR) << "im card recommend success, but no im_result.";
      return 0;
    }
    for (int i = 0; i < response.im_result().sub_items_size(); ++i) {
      std::cout << response.im_result().sub_items(i).Utf8DebugString() << std::endl;
    }
  }

  return 0;
}
