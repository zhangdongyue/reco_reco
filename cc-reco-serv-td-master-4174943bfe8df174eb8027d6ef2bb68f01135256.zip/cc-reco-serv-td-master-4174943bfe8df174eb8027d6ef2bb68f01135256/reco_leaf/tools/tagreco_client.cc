#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <vector>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "net/rpc/rpc.h"
#include "nlp/common/nlp_util.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/item.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20011, "leaf server port");
DEFINE_string(app_token, "uc-iflow", "doc server ip");
// 输入文件有格式：请求类型 \t user_id \t tag
// 请求类型: ktag 或者 kuser
DEFINE_string(input_file, "", "ktag|kuser \t uid \t base_tag  \t req_count");
DEFINE_string(output_file, "", "");

bool MakeRequest(const std::string &line, reco::leafserver::TagRecommendRequest *request) {
  std::vector<std::string> fields;
  base::SplitString(line, "\t", &fields);
  if ((int)fields.size() < 4) {
    LOG(ERROR) << "missing fields! line:" << line;
    return false;
  }
  std::string type = fields[0];
  std::string uid_str = fields[1];
  std::string base_tag = fields[2];
  std::string req_count_str = fields[3];

  reco::UserIdentity user;
  uint64 uid;
  if (!base::StringToUint64(uid_str, &uid)) {
    LOG(ERROR) << "invalid user ! line:" << line;
    return false;
  }
  user.set_user_id(uid);
  user.set_app_token(FLAGS_app_token);
  user.set_outer_id(uid_str);
  request->mutable_user()->CopyFrom(user);

  uint32 req_count = 0;
  if (req_count_str != "" && base::StringToUint(req_count_str, &req_count)) {
    request->set_req_count(req_count);
  }

  if (type == "ktag") {
    request->set_request_type(reco::leafserver::TagRecommendRequest::kTag);
    request->set_base_tag(base_tag);
  } else if (type == "kuser") {
    request->set_request_type(reco::leafserver::TagRecommendRequest::kUser);
  } else {
    request->set_request_type(reco::leafserver::TagRecommendRequest::kNone3);
  }
  return true;
}

void BatchRequest() {
  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  std::ifstream fin(FLAGS_input_file.c_str());
  CHECK(fin) << "open file error: " << FLAGS_input_file;
  std::string line;
  std::ofstream fout(FLAGS_output_file.c_str());
  if (!fout) return;
  while (getline(fin, line)) {
    reco::leafserver::TagRecommendRequest request;

    if (!MakeRequest(line, &request)) {
      LOG(ERROR) << "make request failed ! line:" << line;
      continue;
    }
    LOG(INFO) << "request: " << nlp::util::NormalizeLine(request.Utf8DebugString()) << std::endl;

    std::string out_tags = "";

    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(120);
    reco::leafserver::TagRecommendResponse response;
    stub.tagRecommend(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "recommend fail.";
    } else {
      LOG(INFO) << "response: " << nlp::util::NormalizeLine(response.Utf8DebugString()) << std::endl;

      for (int i = 0; i < response.reco_tags_size(); ++i) {
        if (i != 0) {
          out_tags += ",";
        }
        const std::string& tag = response.reco_tags(i);
        out_tags += tag;
      }
    }
    int req_count = -1;
    if (request.has_req_count()) {
      req_count = request.req_count();
    }
    fout << (int)request.request_type() << "\t" << request.user().user_id() << "\t" << request.base_tag()
         << "\t" << req_count << "\t" << out_tags << std::endl;
  }
  fin.close();
  fout.close();
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "tag reco client");
  BatchRequest();
  return 0;
}
