#include <iostream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/common/channel_define.h"
#include "reco/serv/reco_leaf/strategy/common/reco_strategy_branch.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20035, "leaf server port");

DEFINE_string(user_id, "123", "user id");
DEFINE_string(utdid, "", "utdid");
DEFINE_string(app_token, "uc-iflow", "");

DEFINE_string(acpf_type, "", "");
DEFINE_string(tacid, "", "");
DEFINE_string(tuicid, "", "");
DEFINE_string(sn, "", "");
DEFINE_string(imei, "", "");

DEFINE_uint64(start_index, 0, "subject start index");
DEFINE_uint64(count, 8, "subject count");
DEFINE_uint64(ytid, 0, "subject youku tudou id");

using reco::leafserver::SubjectRecoRequest;
using reco::leafserver::SubjectRecoResponse;

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client");

  SubjectRecoRequest request;
  SubjectRecoResponse response;
  reco::UserIdentity user;
  uint64 uid;
  CHECK(base::StringToUint64(FLAGS_user_id, &uid));
  std::string key = base::StringPrintf("uid-%lu-%ld", uid, base::GetTimestamp());
  uint64 reco_id = base::CalcTermSign(key.c_str(), key.size());
  user.set_user_id(uid);
  user.set_app_token(FLAGS_app_token);
  user.set_outer_id(FLAGS_user_id);
  user.set_utdid(FLAGS_utdid);

  if (!FLAGS_acpf_type.empty() && !FLAGS_tacid.empty()) {
    user.set_acpf_type(FLAGS_acpf_type);
    user.set_tacid(FLAGS_tacid);
  }
  if (!FLAGS_tuicid.empty()) {
    user.set_tuicid(FLAGS_tuicid);
  }
  if (!FLAGS_sn.empty()) {
    user.set_sn(FLAGS_sn);
  }
  if (!FLAGS_imei.empty()) {
    user.set_imei(FLAGS_imei);
  }

  request.set_reco_id(base::Uint64ToString(reco_id));
  request.mutable_user()->CopyFrom(user);
  request.set_start_index(FLAGS_start_index);
  request.set_count(FLAGS_count);
  request.set_ytid(FLAGS_ytid);

  std::cout << request.Utf8DebugString() << std::endl;

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  stub.subjectRecommend(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk) {
    LOG(ERROR) << "recommend fail. error_text: " << rpc.error_text();
  } else if (!response.success()) {
    LOG(ERROR) << "response error";
  } else {
    std::cout << response.Utf8DebugString() << std::endl;
  }

  return 0;
}


