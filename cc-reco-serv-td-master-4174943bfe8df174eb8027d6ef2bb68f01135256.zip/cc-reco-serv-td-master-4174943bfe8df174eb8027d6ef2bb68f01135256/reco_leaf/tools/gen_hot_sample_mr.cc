#include <unordered_map>
#include <unordered_set>
#include <math.h>
#include <iostream>
#include "base/file/file_util.h"
#include "base/hash_function/city.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/encoding/line_escape.h"
#include "base/strings/string_printf.h"

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/item_service/item_keeper_get_item.h"

DEFINE_string(item_keeper_ips, "", "");
DEFINE_int32(item_keeper_port, 0, "");
DEFINE_string(cate_ctr_file, "", "");

template <typename T>
bool StringToProtobuf(const std::string& input_str, T* protobuf) {
  std::string unescape_str;
  if (!base::LineUnescape(input_str, &unescape_str)) {
    return false;
  }

  if (!protobuf->ParseFromString(unescape_str)) {
    VLOG(1) << "string to protobuf failed";
    return false;
  }

  return true;
}

struct Features {
  uint64 item_id;
  uint64 user_id;
  double keyword_score;
  double tag_score;
  double topic_score;
  double category_score;
  double ctr;
  double hour_interval;
  double cate_ctr;
  int32 hot_level;
  std::string category;
  int32 label;
  Features() {
    keyword_score = 0;
    tag_score = 0;
    topic_score = 0;
    category_score = 0;
    ctr = 0;
    hour_interval = -1;
    hot_level = -1;
    cate_ctr = 0;
  }
  void PrintFea() {
    std::cout << item_id << "\t" << user_id << "\t";
    std::cout << label << " ";
    if (keyword_score != 0) std::cout << "1:" << keyword_score << " ";
    if (tag_score != 0) std::cout << "2:" << tag_score << " ";
    if (topic_score != 0) std::cout << "3:" << topic_score << " ";
    if (category_score != 0) std::cout << "4:" << category_score << " ";
    std::cout << "5:" << ctr << " "
              << "6:" << hour_interval << " "
              << "7:" << hot_level << " ";
    if (cate_ctr != 0) std::cout << "8:" << cate_ctr;
    std::cout << std::endl;
  }
  // std::string category;
};

double GetCategoryScore(const std::string& category, const reco::CategoryFeatureVector& user_category) {
  double weight = 0;
  for (int32 i = 0; i < user_category.feature_size(); ++i) {
    const reco::Category& category_liter = user_category.feature(i).literal();
    double category_weight = user_category.feature(i).weight();
    if (category == category_liter.category()) {
      weight += category_weight;
      break;
    }
  }
  return weight;
}

double GetFeaVecScore(const reco::FeatureVector& item_fea_vec, const reco::FeatureVector& user_fea_vec) {
  double weight = 0;
  std::unordered_map<std::string, double> item_fea_vec_weight_dict;
  for (int32 i = 0; i < item_fea_vec.feature_size(); ++i) {
    // std::cout << "item:" << item_fea_vec.feature(i).literal() << std::endl;
    item_fea_vec_weight_dict[item_fea_vec.feature(i).literal()] = item_fea_vec.feature(i).weight();
  }
  for (int32 i = 0; i < user_fea_vec.feature_size(); ++i) {
    // std::cout << "user:" << user_fea_vec.feature(i).literal() << std::endl;
    const std::string& tag_literal = user_fea_vec.feature(i).literal();
    double user_weight = user_fea_vec.feature(i).weight();
    auto iter = item_fea_vec_weight_dict.find(tag_literal);
    if (iter != item_fea_vec_weight_dict.end()) {
      weight += iter->second * user_weight;
    }
  }
  return weight;
}

void LoadCategoryDict(std::unordered_map<std::string, double>* cate_ctr_dict) {
  std::vector<std::string> lines;
  if (base::file_util::ReadFileToLines(FLAGS_cate_ctr_file, &lines)) {
    std::vector<std::string> flds;
    for (size_t i = 0; i < lines.size(); ++i) {
      flds.clear();
      base::SplitString(lines[i], "\t", &flds);
      double ctr;
      if (!base::StringToDouble(flds[3], &ctr)) continue;
      cate_ctr_dict->insert(std::make_pair(flds[0], ctr));
    }
  }
  LOG(INFO) << "cate_ctr_dict size:" << cate_ctr_dict->size() ;
}

void Reducer() {
  std::string line;
  std::vector<std::string> flds;
  // item_id uid tm ctr hot_level label profile
  reco::ItemKeeperGetItem* get_item = new reco::ItemKeeperGetItem(FLAGS_item_keeper_ips,
                                                                   FLAGS_item_keeper_port, 0);
  uint32 pre_item_id = 0;
  std::unordered_map<std::string, double> cate_ctr_dict;
  LoadCategoryDict(&cate_ctr_dict);
  reco::RecoItem reco_item;
  while (std::getline(std::cin, line)) {
    flds.clear();
    base::SplitString(line, "\t", &flds);
    const std::string& profile_str = flds[6];
    reco::user::UserInfo user_info;
    // 通用特征填充
    Features features;
    uint64 item_id, user_id;
    if(!base::StringToUint64(flds[0], &item_id)
       || !base::StringToUint64(flds[1], &user_id)
       || !base::StringToInt(flds[4], &(features.hot_level))
       || !base::StringToDouble(flds[3], &(features.ctr))
       || !base::StringToInt(flds[5], &(features.label))) continue;
    if (features.label > 0) features.label = 1;
    features.item_id = item_id;
    features.user_id = user_id;
    // 获取reco_item
    if (item_id != pre_item_id) {
      if (!get_item->GetRecoItem(item_id, &reco_item)) continue;
      pre_item_id = item_id;
    }
    // 时效性特征
    const std::string& create_time = reco_item.create_time();
    base::Time pub_time_t;
    base::Time create_time_t;
    if (!base::Time::FromStringInFormat(flds[2].c_str(), "%Y-%m-%d %H:%M:%S", &pub_time_t)
        || !base::Time::FromStringInFormat(create_time.c_str(), "%Y-%m-%d %H:%M:%S", &create_time_t)) continue;
    base::TimeDelta delta = pub_time_t - create_time_t;
    features.hour_interval = delta.InHours();
    // 类别特征
    features.category = reco_item.category(0);
    auto iter = cate_ctr_dict.find(features.category);
    if (iter != cate_ctr_dict.end()) features.cate_ctr = iter->second;
    // TODO
    if (!StringToProtobuf(profile_str, &user_info)) {
      // 未命中 profile missing
    } else {
      // 填充相关性特征
      // tag score
      const reco::user::Profile& profile = user_info.profile();
      features.tag_score = GetFeaVecScore(reco_item.tag(), profile.tag_feavec());
      features.keyword_score = GetFeaVecScore(reco_item.keyword(), profile.keyword_feavec());
      features.topic_score = GetFeaVecScore(reco_item.topic(), profile.topic_feavec());
      features.category_score = GetCategoryScore(reco_item.category(0), profile.category_feavec());
    }
    features.PrintFea();
  }
  delete get_item;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "gen_hot_sample");
  Reducer();
  return 0;
}
