#include <iostream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/item.pb.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 20001, "leaf server port");

DEFINE_int32(item_type, 2, "2: picture, 3: humor");
DEFINE_int32(return_num, 10, "return num");
DEFINE_string(category, "美女写真", "categories splitted by ,");
DEFINE_int32(sort_method, 3, "2: time sort, 3: hot sort");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client");

  reco::leafserver::VerticalRequest request;
  reco::leafserver::VerticalResponse response;

  request.set_item_type(reco::ItemType(FLAGS_item_type));
  request.set_return_num(FLAGS_return_num);
  request.set_sort_method(reco::SortMethod(FLAGS_sort_method));
  request.set_only_id(false);

  std::vector<std::string> flds;
  base::SplitString(FLAGS_category, ",", &flds);
  for (size_t i = 0; i < flds.size(); ++i) {
    request.add_category(flds[i]);
  }

  LOG(INFO) << request.Utf8DebugString();

  net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip.c_str(), FLAGS_leaf_server_port);
  CHECK(channel.Connect());
  reco::leafserver::RecommendService::Stub stub(&channel);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(5);
  stub.verticalRecommend(&rpc, &request, &response, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk
      || !response.success()) {
    LOG(ERROR) << "recommend fail." << response.err_message();
  } else {
    LOG(INFO) << response.Utf8DebugString();
  }

  return 0;
}
