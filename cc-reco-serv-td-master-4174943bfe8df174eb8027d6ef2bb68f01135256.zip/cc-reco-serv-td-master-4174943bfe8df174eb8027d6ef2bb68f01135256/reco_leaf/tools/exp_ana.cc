#include <string>
#include <set>
#include <unordered_set>
#include <unordered_map>
#include <fstream>
#include <iostream>
#include "nlp/common/nlp_util.h"
#include "nlp/common/rune_type.h"
#include "nlp/segment/internal/segment_model.h"
#include "extend/static_dict/darts_clone/darts_clone.h"
#include "base/common/slice.h"
#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/gflags_completions.h"
#include "base/common/base.h"
#include "base/mapreduce/mapreduce.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/file/file_stream.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_number_conversions.h"
#include "base/encoding/line_escape.h"
#include "reco/bizc/proto/log.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/index_monitor/api/index_monitor.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/tools/user_feature.h"

DEFINE_string(show_file, "./", "inner user dict");

bool GetUserInfo(reco::UserInfo* user_info) {
  std::vector<std::string> lines, flds;
  CHECK(base::file_util::ReadFileToLines(FLAGS_show_file, &lines));
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() != 2u) {
      LOG(ERROR) << "line error, " << lines[i];
      continue;
    }
    std::string line;
    if (!base::LineUnescape(flds[1], &line)) {
      LOG(ERROR) << "log unescape failed";
      continue;
    }
    reco::ServerLog server_log;
    if (!server_log.ParseFromString(line)) {
      LOG(ERROR) << "parse proto failed";
      continue;
    }
    if (server_log.head().log_type() == reco::kLeafServer) {
      if (!server_log.head().has_platform()) {
        LOG(ERROR) << "leaf server has no platform info";
        continue;
      }
      const std::string& platform = server_log.head().platform();
      if (platform.find("021.cm8") == platform.npos
          && platform.find("023.cm8") == platform.npos) continue;

      reco::LeafServerLogBody body;
      if (!body.ParseFromString(server_log.body())) {
        LOG(ERROR) << "failed to parse body";
        continue;
      }
      if (body.reco_id() == "16987218296376402006") {
        user_info->CopyFrom(body.user());
        return true;
      }
    }
  }
  return false;
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "parse log");
  reco::UserInfo user_info;
  CHECK(GetUserInfo(&user_info));
  LOG(INFO) << "Get UserInfo succ.";

  reco::index_monitor::IndexMonitor monitor;
  monitor.Start();

  LOG(INFO) << "index monitor started";
  adsindexing::Index* index = monitor.GetIndex();
  // index->LogStatus();

  int32 doc_num = index->GetDocNum();
  LOG(INFO) << "doc_num: " << doc_num;

  reco::NewsIndex* news_index = reco::InitializeNewsIndex(index);

  reco::leafserver::UserFeature user_fea(news_index);
  user_fea.ResetUser(&user_info, true);
  user_fea.MergeUserFeature();
}
