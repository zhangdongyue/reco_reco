#pragma once
#include "base/common/basic_types.h"

struct ResponseDumpInfo {
  int status;
  uint64 send_timestamp;
  uint64 response_timestamp;
  uint64 body_size;
};
