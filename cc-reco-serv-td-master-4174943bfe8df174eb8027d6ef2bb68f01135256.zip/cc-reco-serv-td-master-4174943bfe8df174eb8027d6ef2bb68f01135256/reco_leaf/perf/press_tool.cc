#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"

#include "reco/serv/reco_leaf/perf/click_generator.h"
#include "reco/serv/reco_leaf/perf/wemedia_click_generator.h"
#include "reco/serv/reco_leaf/perf/press_worker.h"
#include "reco/serv/reco_leaf/perf/press_responser.h"
#include "reco/serv/reco_leaf/perf/wemedia_press_worker.h"
#include "reco/serv/reco_leaf/perf/request_pool.h"
#include "reco/serv/reco_leaf/perf/user_pool.h"

#include "base/common/sleep.h"
#include "reco/serv/reco_leaf/perf/define.h"
#include "reco/serv/reco_leaf/perf/subject_press_worker.h"

DEFINE_int32(thread_num, 8, "thread num for send request");
DEFINE_int32(user_num, 0, "user num");
DEFINE_double(ctr, 0.0, "ctr");
DEFINE_string(user_id_file, "", "file contains user id");
DEFINE_string(request_file, "", "file contains pb request");
DEFINE_string(item_id_file, "", "file contains item id");
DEFINE_int32(test_type, 0, "0:default recommond, 1:wemedia recommand, 2:subject recommend");

void TestRecommond();
void TestWeMediaRecommond();
bool TestSubjectRecommond();

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "press tool");
  switch (FLAGS_test_type) {
    case 0:
      TestRecommond();
      break;
    case 1:
      TestWeMediaRecommond();
      break;
    case 2:
      if (!TestSubjectRecommond()) {
        return -1;
      }
    default:
      return 0;
  }
  return 0;
}


void TestRecommond() {
  using namespace reco;

  int thread_num_ = FLAGS_thread_num;

  thread::BlockingQueue<std::string> item_queue;
  if (!FLAGS_item_id_file.empty()) {
    std::vector<std::string> lines;
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines);
    for (int i = 0; i < (int)lines.size(); ++i) {
      base::TrimTrailingWhitespaces(&(lines[i]));
      item_queue.Put(lines[i]);
    }
  }

  thread::BlockingQueue<ResponseDumpInfo*> response_queue;
  thread::BlockingQueue<std::pair<reco::leafserver::RecommendRequest*, reco::leafserver::RecommendResponse*>> reco_queue;

  PressResponser responser(&response_queue);
  float ctr_ = FLAGS_ctr;
  ClickGenerator clicker(&reco_queue, ctr_);

  UserPool* user_pool = NULL;
  if (!FLAGS_user_id_file.empty()) {
    user_pool = new UserPool(FLAGS_user_id_file);
  } else if (FLAGS_user_num > 0) {
    user_pool = new UserPool(FLAGS_user_num);
  }
  RequestPool* request_pool = NULL;
  if (!FLAGS_request_file.empty()) {
    request_pool = new RequestPool(FLAGS_request_file);
  }
  CHECK(user_pool != NULL || request_pool != NULL);

  std::vector<PressWorker*> workers;

  thread::ThreadPool pool(thread_num_ + 2);
  for (int i = 0; i < thread_num_; ++i) {
    workers.push_back(new PressWorker(request_pool, user_pool, &item_queue,
                                      &response_queue, &reco_queue));
    pool.AddTask(::NewCallback<PressWorker, int>(workers.back(), &PressWorker::run, i));
  }
  pool.AddTask(::NewCallback<PressResponser>(&responser, &PressResponser::run));
  pool.AddTask(::NewCallback<ClickGenerator>(&clicker, &ClickGenerator::run));

  int total_workers = thread_num_;
  while (total_workers > 0) {
    base::SleepForMilliseconds(200);
    total_workers = 0;
    for (int i = 0; i < (int)workers.size(); ++i) {
      if (workers[i]->running()) {
        ++total_workers;
      }
    }
  }
  response_queue.Close();
  reco_queue.Close();
  responser.stop();

  pool.JoinAll();
}

void TestWeMediaRecommond() {
  using namespace reco;

  int thread_num_ = FLAGS_thread_num;

  thread::BlockingQueue<std::string> item_queue;
  if (!FLAGS_item_id_file.empty()) {
    std::vector<std::string> lines;
    base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines);
    for (int i = 0; i < (int)lines.size(); ++i) {
      base::TrimTrailingWhitespaces(&(lines[i]));
      item_queue.Put(lines[i]);
    }
  }

  thread::BlockingQueue<ResponseDumpInfo*> response_queue;
  PressResponser responser(&response_queue);

  thread::BlockingQueue<std::pair<reco::leafserver::WeMediaRecommendRequest*,
      reco::leafserver::WeMediaRecommendResponse*>> reco_queue;

  float ctr_ = FLAGS_ctr;
  WeMediaClickGenerator clicker(&reco_queue, ctr_);

  UserPool* user_pool = NULL;
  if (!FLAGS_user_id_file.empty()) {
    user_pool = new UserPool(FLAGS_user_id_file);
  } else if (FLAGS_user_num > 0) {
    user_pool = new UserPool(FLAGS_user_num);
  }

  std::vector<WeMediaPressWorker*> workers;

  thread::ThreadPool pool(thread_num_ + 2);
  for (int i = 0; i < thread_num_; ++i) {
    workers.push_back(new WeMediaPressWorker(user_pool, &response_queue, &reco_queue));
    pool.AddTask(::NewCallback(workers.back(), &WeMediaPressWorker::run, i));
  }
  pool.AddTask(::NewCallback(&responser, &PressResponser::run));
  pool.AddTask(::NewCallback(&clicker, &WeMediaClickGenerator::run));

  int total_workers = thread_num_;
  while (total_workers > 0) {
    base::SleepForMilliseconds(200);
    total_workers = 0;
    for (int i = 0; i < (int)workers.size(); ++i) {
      if (workers[i]->running()) {
        ++total_workers;
      }
    }
  }
  response_queue.Close();
  responser.stop();
  reco_queue.Close();

  pool.JoinAll();
}

bool TestSubjectRecommond() {
  using namespace reco;

  int thread_num_ = FLAGS_thread_num;
  thread::BlockingQueue<ResponseDumpInfo*> response_queue;
  PressResponser responser(&response_queue);

  thread::BlockingQueue<std::pair<reco::leafserver::SubjectRecoRequest*,
          reco::leafserver::SubjectRecoResponse*>> reco_queue;

  UserPool* user_pool = NULL;
  if (!FLAGS_user_id_file.empty()) {
    user_pool = new UserPool(FLAGS_user_id_file);
  } else {
    int user_num = FLAGS_user_num;
    if (FLAGS_user_num <= 0) {
      user_num = 100;
    }
    user_pool = new UserPool(user_num);
  }
  std::vector<SubjectPressWorker*> workers;

  thread::ThreadPool pool(thread_num_ + 1);
  for (int i = 0; i < thread_num_; ++i) {
    workers.push_back(new SubjectPressWorker(user_pool, &response_queue, &reco_queue));
    pool.AddTask(::NewCallback(workers.back(), &SubjectPressWorker::run, i));
  }
  pool.AddTask(::NewCallback(&responser, &PressResponser::run));

  int total_workers = thread_num_;
  while (total_workers > 0) {
    base::SleepForMilliseconds(200);
    total_workers = 0;
    for (int i = 0; i < (int)workers.size(); ++i) {
      if (workers[i]->running()) {
        ++total_workers;
      }
    }
  }
  response_queue.Close();
  responser.stop();
  reco_queue.Close();

  pool.JoinAll();

  return true;
}
