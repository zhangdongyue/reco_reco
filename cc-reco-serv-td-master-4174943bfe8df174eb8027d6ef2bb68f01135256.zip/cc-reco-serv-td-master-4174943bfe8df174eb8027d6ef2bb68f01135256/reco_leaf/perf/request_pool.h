#pragma once

#include <string>
#include <vector>

#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/file/file_util.h"
#include "base/random/pseudo_random.h"
#include "google/protobuf/text_format.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"

namespace reco {

class RequestPool {
 public:
  explicit RequestPool(const std::string& request_file) {
    std::vector<std::string> lines;
    base::file_util::ReadFileToLines(request_file, &lines);
    CHECK(!lines.empty());
    request_.reserve(lines.size());
    for (size_t i = 0;i < lines.size(); i ++) {
      leafserver::RecommendRequest request;
      if (!google::protobuf::TextFormat::ParseFromString(lines[i], &request)) {
        LOG(ERROR) << "parse error: " << lines[i];
        continue;
      }
      request_.push_back(request);
    }
    LOG(INFO) << "total " << request_.size() << " requests.";
  }
  ~RequestPool() {}

  const leafserver::RecommendRequest& GetRequest() {
    return request_[rand_.GetInt(0, request_.size() - 1)];
  }

 private:
  std::vector<leafserver::RecommendRequest> request_;
  base::PseudoRandom rand_;
};

}  // namespace reco


