#include "serving/recommending/reco_leaf/perf/leaf_server_perf.h"
#include <iostream>
#include "serving/recommending/include/recommending.h"
#include "serving/recommending/click_server/click_service_impl.h"
#include "serving/recommending/log_analysis/log_analysis.h"
#include "crawler/fetcher/multi_fetcher.h"
#include "extend/json/jansson/jansson.h"
#include "base/common/scoped_ptr.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/file/dir_reader_posix.h"
#include "base/random/uuid.h"
#include "base/random/pseudo_random.h"
#include "base/container/sparse_hash_map.h"
#include "base/hash_function/term.h"
#include "base/common/sleep.h"

DEFINE_string(leaf_server_ip, "127.0.0.1", "leaf server ip");
DEFINE_int32(leaf_server_port, 5678, "leaf server port");
DEFINE_string(click_server_ip, "127.0.0.1", "click server ip");
DEFINE_int32(click_server_port, 5678, "click server port");
DEFINE_string(user_server_ip, "127.0.0.1", "user server ip");
DEFINE_int32(user_server_port, 5678, "user server port");

DEFINE_string(test_show_log_file, "", "用来做压力的 show_log 文件");
DEFINE_string(test_click_log_file, "", "用来做压力的 click_log 文件");

DEFINE_int32(thread_num, 10, "Concurrency.");
DEFINE_int32(update_interval_in_second, 600, "update user profile 的时间间隔(秒)");
DEFINE_double(qps, 10.0, "Targeted query-per-second rate. The actual qps is guaranteed to be no larger than the specified one.");
DEFINE_string(input_feed, "", "Input feed file for synthsizing traffics.");
DEFINE_int32(num_requests, 1000, "Num of requests to send.");
DEFINE_double(timeout, 5.0, "Timeout in seconds.");
DEFINE_int32(grain_millisec, 1000, "Time interval of tuning rates.");
DEFINE_int32(sleep_interval_step, 10, "Adjust step length of interval.");

LeafServerPerf::LeafServerPerf() :
    leaf_ip_(FLAGS_leaf_server_ip), leaf_port_(FLAGS_leaf_server_port),
    click_ip_(FLAGS_click_server_ip), click_port_(FLAGS_click_server_port),
    // user_ip_(FLAGS_user_server_ip), user_port_(FLAGS_user_server_port),
    pool_(FLAGS_thread_num + 1),
    click_channel_(click_ip_, click_port_),
    leaf_channel_(leaf_ip_, leaf_port_)
{
   CHECK(click_channel_.Connect());
   CHECK(leaf_channel_.Connect());
}

LeafServerPerf::~LeafServerPerf() {
  delete leaf_service_;
  delete click_service_;
  leaf_service_  = NULL;
  click_service_ = NULL;
}

void LeafServerPerf::Start() {
  if (leaf_service_)  delete leaf_service_;
  if (click_service_) delete click_service_;

  leaf_service_  = new recommending::RecommendService::Stub(&leaf_channel_);
  click_service_ = new recommending::ClickService::Stub(&click_channel_);

  CHECK_GT(FLAGS_thread_num, 0);
  num_threads_ = FLAGS_thread_num;
  num_working_threads_ = num_threads_;

  num_request_sent_ = 0;

  CHECK_GE(FLAGS_qps, 1);
  per_thread_qps_ = FLAGS_qps / static_cast<double>(num_threads_);

  CHECK_GT(FLAGS_num_requests, 0);
  num_requests_ = FLAGS_num_requests;

  round_secs_.resize(num_requests_, 0);
  response_ok_.resize(num_requests_, true);
}

void LeafServerPerf::Stop() {
}

void LeafServerPerf::Launch() {
  base::FilePath show_log_file(FLAGS_test_show_log_file.c_str());
  base::FilePath click_log_file(FLAGS_test_click_log_file.c_str());

  std::vector<SimulateRequest> sim_requests;
  GenSimulateRequests(show_log_file, click_log_file, &sim_requests);

  global_start_timestamp_ = base::GetTimestamp();

  // Add worker into thread pool
  for (int i = 0; i < num_threads_; ++i) {
    pool_.AddTask(NewCallback<LeafServerPerf, const std::vector<SimulateRequest>&, int>(
            this, &LeafServerPerf::Handle, sim_requests, i));
  }

  // Add coordinator into thread pool
  pool_.AddTask(::NewCallback<LeafServerPerf>(this, &LeafServerPerf::TuneSleepTime));

  pool_.JoinAll();
  global_end_timestamp_ = base::GetTimestamp();

  Show();

  LOG(INFO) << "Joined. All done.";
}

void LeafServerPerf:: GenSimulateRequests(const base::FilePath& show_log_file,
                                       const base::FilePath&  click_log_file,
                                       std::vector<SimulateRequest>* sim_requests) {
  std::vector<reco_log_analysis::ShowLog>  show_logs;
  std::vector<reco_log_analysis::ClickLog> click_logs;
  CHECK(reco_log_analysis::ReadShowLog(show_log_file, &show_logs));
  CHECK(reco_log_analysis::ReadClickLog(click_log_file, &click_logs));

  std::unordered_map<std::string, int> reco_clicks;
  for (int i = 0; i < (int)click_logs.size(); ++i) {
    auto it = reco_clicks.find(click_logs[i].reco_id);
    if (it == reco_clicks.end()) {
      reco_clicks.insert(std::make_pair(click_logs[i].reco_id, 1));
    } else {
      it->second += 1;
    }
  }
  click_logs.clear();

  base::PseudoRandom random(base::GetTimestamp());
  sim_requests->clear();
  for (int i = 0; i < (int)show_logs.size(); ++i) {
    const reco_log_analysis::ShowLog& log = show_logs[i];
    uint64 reco_id;
    if (base::StringToUint64(log.reco_id, &reco_id)) continue;
    sim_requests->push_back(SimulateRequest());
    SimulateRequest& sim_req = sim_requests->back();
    if (log.user_id.empty()) continue;
    // 1. recommend request
    recommending::RecommendRequest& reco_req = sim_req.reco_request;
    std::string uid = "test_" + log.user_id;
    recommending::User user;
    user.set_user_id(uid);
    user.set_user_type(log.user_type);
    reco_req.Clear();
    reco_req.set_app_name("xxsr");
    reco_req.mutable_user()->CopyFrom(user);
    reco_req.set_uid(uid);
    reco_req.set_recommend_type(log.req_type);
    reco_req.set_return_num(log.show_items.size());
    // 2. click request
    std::vector<recommending::ClickUpdateRequest>& click_reqs = sim_req.click_requests;
    int show_item_num = (int)log.show_items.size();
    // show 为空
    if (show_item_num == 0) continue;
    auto it = reco_clicks.find(log.reco_id);
    // 没有点击
    if (it == reco_clicks.end()) continue;
    int click_item_num = (show_item_num < it->second) ? show_item_num:it->second;
    double ratio = click_item_num * 1.0 / show_item_num;
    for (int j = 0; j < (int)log.show_items.size(); ++j) {
      if (random.GetDouble() > ratio) continue;
      uint64 item_id;
      if (!base::StringToUint64(log.show_items[j].second, &item_id)) continue;
      recommending::Item item;
      item.set_item_id(item_id);
      item.set_item_type(log.show_items[j].first);
      click_reqs.push_back(recommending::ClickUpdateRequest());
      recommending::ClickUpdateRequest& click_req = click_reqs.back();
      click_req.set_app_name("xxsr");
      recommending::ClickUpdateItem* update_item = click_req.add_items();
      update_item->set_reco_id(reco_id);
      update_item->mutable_user()->CopyFrom(user);
      update_item->mutable_clicked_item()->CopyFrom(item);
      for (int k = 0; k < (int)log.show_items.size(); ++k) {
        if (!base::StringToUint64(log.show_items[k].second, &item_id)) continue;
        recommending::Item* view_item = update_item->add_viewed_items();
        view_item->set_item_id(item_id);
        view_item->set_item_type(log.show_items[k].first);
      }
    }
  }
  show_logs.clear();
}

void LeafServerPerf::Handle(const std::vector<SimulateRequest>& sim_requests,
                         int id) {
  int last_request_interval_ms = 0;

  for (int k = id; k < num_requests_; k += num_threads_) {
    // 1. 处理recomend request
    int sleep_interval = sleep_interval_ - last_request_interval_ms;
    if (sleep_interval > 0) {
      base::SleepForMilliseconds(sleep_interval);
    }
    int line_id = k % sim_requests.size();
    const recommending::RecommendRequest& reco_request = sim_requests[line_id].reco_request;
    recommending::RecommendResponse reco_response;
    // 微秒
    int64 timestamp_start = base::GetTimestamp();
    bool res = HandleRecommendRequest(&reco_request, &reco_response);
    int64 timestamp_end = base::GetTimestamp();
    if (!res) {
      response_ok_[k] = false;
    } else {
      response_ok_[k] = true;
    }
    ++num_request_sent_;  // increase atomic counter
    LOG_EVERY_N(INFO, 50000) << num_request_sent_ << " requests sent";
    // 毫秒
    last_request_interval_ms = (timestamp_end - timestamp_start) / 1000;
    round_secs_[k] = double(last_request_interval_ms) / 1000.0;

    // 2. 处理click recomend
    const std::vector<recommending::ClickUpdateRequest>& click_requests = sim_requests[line_id].click_requests;
    for (int j = 0; j < (int)click_requests.size(); ++j) {
      recommending::ClickUpdateResponse click_update_response;
      res = HandleClickRequest(&(click_requests[j]), &click_update_response);
    }
  }
  num_working_threads_--;
  LOG(INFO) << "thread " << id << " end!";
}

bool LeafServerPerf::HandleRecommendRequest(const recommending::RecommendRequest* request,
                                         recommending::RecommendResponse* response) {
  stumy::RpcClientController rpc;
  rpc.SetDeadline(FLAGS_timeout);
  leaf_service_->Recommend(&rpc, request, response, NULL);
  rpc.Wait();
  if (rpc.status() != stumy::RpcController::kOk ||
      !response->success()) {
    LOG(ERROR) << "RPC failed: {" << rpc.error_text();
    return false;
  }
  return true;
}

bool LeafServerPerf::HandleClickRequest(const recommending::ClickUpdateRequest* request,
                                     recommending::ClickUpdateResponse* response) {
  stumy::RpcClientController rpc;
  rpc.SetDeadline(FLAGS_timeout);
  click_service_->UpdateClick(&rpc, request, response, NULL);
  rpc.Wait();
  if (rpc.status() != stumy::RpcController::kOk ||
      response->result() != recommending::kSuccess) {
    LOG(ERROR) << "RPC failed: {" << rpc.error_text();
    return false;
  }
  return true;
}

void LeafServerPerf::TuneSleepTime() {
  int pre_sent_requests = 0;
  int cur_sent_requests = 0;
  double targeted_qps = per_thread_qps_ * num_threads_;
  // 毫秒
  sleep_interval_ = 1000 / per_thread_qps_;
  while (num_working_threads_ > 0) {
    base::SleepForMilliseconds(FLAGS_grain_millisec);
    cur_sent_requests = num_request_sent_;
    double current_qps = static_cast<double>(cur_sent_requests - pre_sent_requests)
      * 1e3 / static_cast<double>(FLAGS_grain_millisec);
    LOG(INFO) << "Current QPS: " << current_qps;
    if (fabs(current_qps - targeted_qps) > 0.1 * (double)targeted_qps) {
      if (current_qps > targeted_qps) {
        // 压力大了
        sleep_interval_ += FLAGS_sleep_interval_step;
      } else if (current_qps < targeted_qps) {
        sleep_interval_ -= FLAGS_sleep_interval_step;
        if (sleep_interval_ < 0) {
          sleep_interval_ = 0;
        }
      }
    }
    pre_sent_requests = cur_sent_requests;
    VLOG(1) << "sleep interval is tuned to [" << sleep_interval_ << "]";
  }
  // over
}

void LeafServerPerf::Show() {
  std::cout << "Total requests: " << num_requests_ << std::endl;
  uint32 num_bad_responses = 0;
  for (int i = 0; i < (int)response_ok_.size(); ++i) {
    if (!response_ok_[i]) {
      ++num_bad_responses;
    }
  }

  float max_time = *(std::max_element(round_secs_.begin(), round_secs_.end()));
  float min_time = *(std::min_element(round_secs_.begin(), round_secs_.end()));
  double avg_time = 0;
  for (int i = 0; i < (int)round_secs_.size(); ++i) {
    avg_time += round_secs_[i];
  }
  avg_time /= (double)round_secs_.size();

  std::cout << "Num of bad responses: " << num_bad_responses << "\n";
  std::cout << "Avg processing time(second): " << avg_time << "\n";
  std::cout << "Max processing time(second): " << max_time << "\n";
  std::cout << "Min processing time(second): " << min_time << "\n";
  double estimated_qps = 0;
  double elapse = global_end_timestamp_ - global_start_timestamp_;
  if (elapse > 0) {
    estimated_qps = num_requests_ * 1e6 / elapse;
  }
  std::cout << "Estimated QPS (including bad requests): "
            << estimated_qps << "\n";
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "Server Performance tool.");

  LeafServerPerf launch;
  launch.Start();
  launch.Launch();
  launch.Stop();

  return 0;
}
