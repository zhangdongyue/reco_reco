#pragma once
#include <vector>
#include <string>

#include "base/random/pseudo_random.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/time/timestamp.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/reco_user_server.pb.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "net/rpc/rpc.h"

DEFINE_string(user_server_ip, "127.0.0.1", "user server ip");
DEFINE_int32(user_server_port, 20002, "user port");
DEFINE_bool(add_shown_history, false, "add leaf server response to shown history");

namespace reco {
class ClickGenerator {
  static const std::string kAppToken;
  
 private:
  thread::BlockingQueue<std::pair<reco::leafserver::RecommendRequest*,
      reco::leafserver::RecommendResponse*>>* reco_queue_;
  float ctr_;
  base::PseudoRandom rand_;
  
 public:
  ClickGenerator(thread::BlockingQueue<std::pair<reco::leafserver::RecommendRequest*,
                 reco::leafserver::RecommendResponse*>>* reco_queue,
                 float ctr):
  reco_queue_(reco_queue), ctr_(ctr) {}
  
  ~ClickGenerator() {}

  void run() {
    net::rpc::RpcClientChannel channel(FLAGS_user_server_ip, FLAGS_user_server_port);
    CHECK(channel.Connect());
    int total_click = 0;
    int total_show = 0;
    reco::userserver::UserService::Stub stub(&channel);
    while (!(reco_queue_->Empty() && reco_queue_->Closed())) {
      std::pair<reco::leafserver::RecommendRequest*, reco::leafserver::RecommendResponse*> entry;
      entry.first = NULL;
      entry.second = NULL;
      if (reco_queue_->TimedTake(3, &entry) != 1) continue;

      reco::leafserver::RecommendResponse* response = entry.second;
      reco::leafserver::RecommendRequest* request = entry.first;
      if (!response->success()) {
        LOG(ERROR) << " bad response: " << response->err_message();
        continue;
      }

      reco::user::UpdateUserFieldRequest user_request;
      reco::user::UserServerCommonResponse user_response;
      user_request.mutable_user()->CopyFrom(request->user());

      if (FLAGS_add_shown_history) {
        user_request.set_field_type(reco::user::kShownHistory);
        for (int i = 0; i < response->result_size(); ++i) {
          const reco::leafserver::RecoResult& result = response->result(i);
          reco::user::ViewClickItem* item = user_request.add_shown_items();
          item->set_item_id(result.item_id());
          item->set_item_type(reco::kNews);
        }
        net::rpc::RpcClientController rpc;
        stub.updateUserField(&rpc, &user_request, &user_response, NULL);
        if (!rpc.TimedWait(1000)) {
          LOG(ERROR) << "update user shown history failed!";
        } else {
          total_show += response->result_size();
        }
      }

      int64 ctime = base::GetTimestamp();  //微秒
      user_request.set_field_type(reco::user::kRecentClick);
      for (int i = 0; i < response->result_size(); ++i) {
        if (rand_.GetDouble() >= ctr_) {
          continue;
        }
        reco::user::ViewClickItem* item = user_request.mutable_click_item();
        const reco::leafserver::RecoResult& result = response->result(i);
        item->set_item_id(result.item_id());
        item->set_item_type(reco::kNews);
        item->set_view_duration(10);
        item->set_click_timestamp(ctime);
        net::rpc::RpcClientController rpc;
        stub.updateUserField(&rpc, &user_request, &user_response, NULL);
        if (!rpc.TimedWait(1000)) {
          LOG(ERROR) << "update user click failed!";
          continue;
        }
        ++total_click;
      }

      delete response;
      delete request;
    }
    LOG(INFO) << "click thread ends, total_show: " << total_show << ", total_click: " << total_click;
  }
};

const std::string ClickGenerator::kAppToken = "uc-iflow";
}

