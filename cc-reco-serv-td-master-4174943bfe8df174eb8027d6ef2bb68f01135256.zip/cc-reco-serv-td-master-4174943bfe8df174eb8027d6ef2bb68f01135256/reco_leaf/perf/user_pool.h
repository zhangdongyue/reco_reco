#pragma once
#include <vector>
#include <string>
#include "base/random/pseudo_random.h"
#include "base/hash_function/term.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/proto/common.pb.h"

DECLARE_string(app_token);
namespace reco {

class UserPool {
 public:
  // 生成随机用户id
  UserPool(int max_num): max_num_(max_num) {
    users_.reserve(max_num_);
    reco::UserIdentity user;
    for (int i = 0; i < max_num_; ++i) {
      uint64 id = rand_.GetUint64();
      std::string id_str = base::StringPrintf("test-%lu", id);
      uint64 sign = base::CalcTermSign(id_str.c_str(), id_str.size());
      user.set_user_id(sign);
      user.set_outer_id(id_str);
      user.set_app_token(FLAGS_app_token);
      users_.push_back(user);
    }
  }

  UserPool(const std::string& user_id_file) {
    std::vector<std::string> lines;
    base::file_util::ReadFileToLines(user_id_file, &lines);
    CHECK(!lines.empty());
    users_.reserve(lines.size());
    std::vector<std::string> flds;

    for (int i =0; i < (int)lines.size(); ++i) {
      users_.push_back(reco::UserIdentity());
      reco::UserIdentity& user = users_.back();

      base::TrimTrailingWhitespaces(&(lines[i]));
      flds.clear();
      base::SplitString(lines[i], "\t", &flds);

      user.set_user_id(base::ParseUint64OrDie(flds[0]));
      user.set_outer_id(flds[0]);
      user.set_app_token(FLAGS_app_token);
      if (flds.size() > 1u) {
        user.set_utdid(flds[1]);
      }
      if (flds.size() > 2u) {
        user.set_imei(flds[2]);
      }
    }
    max_num_ = users_.size();
    LOG(INFO) << "total user: " << max_num_;
  }

  const reco::UserIdentity& get_user() {
    int index = rand_.GetInt(0, max_num_ - 1);
    return users_[index];
  }

 private:
  std::vector<reco::UserIdentity> users_;
  base::PseudoRandom rand_;
  int max_num_;
};
}
