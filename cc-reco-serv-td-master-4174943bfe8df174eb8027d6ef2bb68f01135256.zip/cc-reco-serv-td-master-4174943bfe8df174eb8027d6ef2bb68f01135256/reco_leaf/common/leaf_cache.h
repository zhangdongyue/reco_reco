#pragma once
#include <string>
#include "base/common/basic_types.h"
#include "serving_base/expiry_map/expiry_map.h"

namespace redis {
class ClientPool;
}

namespace reco {
class UserInfo;

namespace leafserver {

DECLARE_int32(cache_exp_seconds);
class LeafCache {
 private:
  LeafCache();
  ~LeafCache();

 public: 
  /////////////////////// 最简单的 key-value 缓存方式，调用者自己去组装和解析 ///////////////
  // 读取
  static bool GetCachedReco(const std::string& key, std::string* reco_result) WARN_UNUSED_RESULT;
  // 写入
  static bool SetCachedReco(const std::string& key, const std::string& reco_result);
  static bool SetCachedReco(const std::string& key, const std::string& reco_result, int cache_exp_seconds);

  // 获取某个 item 下发的次数
  static bool GetItemIssuedCnt(uint64 item_id, int64* cnt);
  // 对应 item 下发次数计数增加
  static bool IncItemIssuedCnt(uint64 item_id, int64 times = 1);

 private:
  static const int kItemIssuedExpireSnds;
  static serving_base::ExpiryMap<std::string, std::string>* cache_;
};

}  // namespace leafserver
}  // namespace reco
