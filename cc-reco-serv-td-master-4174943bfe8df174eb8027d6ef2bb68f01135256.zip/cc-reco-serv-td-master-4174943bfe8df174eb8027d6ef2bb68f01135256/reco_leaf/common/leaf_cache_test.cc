#include "reco_cache.h"
#include "base/common/basic_types.h"
#include "base/testing/gtest.h"
#include "base/strings/string_number_conversions.h"
#include "base/time/timestamp.h"
#include "base/common/sleep.h"
#include "reco/bizc/proto/user.pb.h"

namespace reco {
namespace leafserver {
TEST(RecoCacheTest, TestPutAndFetch) {
  const std::string ip = "10.3.5.51";
  const int port = 6379;
  const int exp_seconds = 1;
  RecoCache::Initialize(ip, port, 1, exp_seconds);
  
  struct {
    uint64 user_id;
    std::string reco_result;
  }  cases[] = {
    {1, "0,1,2,3,4"},
    {2, "5,6,7,8"},
  };
  
  int case_num = ARRAYSIZE_UNSAFE(cases);
  UserInfo user_info;
  int64 timestamp;
  std::string reco_result;
  for (int i = 0; i < case_num; ++i) {
    UserIdentity user;
    user.set_user_id(cases[i].user_id);
    user.set_outer_id(base::Uint64ToString(cases[i].user_id));
    user.set_app_token("uc");
    user_info.mutable_identity()->CopyFrom(user);
    int64 real_timestamp = base::GetTimestamp();
    // ASSERT_TRUE(RecoCache::CacheReco(0, user_info, -1, real_timestamp, cases[i].reco_result));
    // ASSERT_TRUE(RecoCache::GetCachedReco(0, user_info, -1, &timestamp, &reco_result));
    // ASSERT_EQ(timestamp, real_timestamp);
    base::SleepForSeconds(exp_seconds + 1);
    // ASSERT_TRUE(!RecoCache::GetCachedReco(0, user_info, -1, &timestamp, &reco_result));
  }
}
}
}
