#pragma once

#include <string>
#include <vector>
#include <cmath>

#include "base/time/time.h"

#include "reco/bizc/proto/model_service.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_model/frame/reco_model_def.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/ml/model_server/api/model_server_api.h"
#include "reco/bizc/reco_index/extractor.h"

DECLARE_bool(open_model_server_wd);

namespace reco {
class NewsIndex;

namespace leafserver {
class WDPredictor {
 public:
  explicit WDPredictor(const reco::NewsIndex* index);

  ~WDPredictor();

  bool BatchCalcWDScore(const RecoRequest &request, const std::string& category,
                        std::vector<ItemInfo>* items);

 private:
  void WDExtract(int thread_id, int32 thread_num, const std::vector<ItemInfo>& reco_items,
                 reco::model_server::OneRequest* one_request);

 private:
  const NewsIndex* news_index_;
  const RecoRequest* reco_request_;

  DISALLOW_COPY_AND_ASSIGN(WDPredictor);
};

}  // namespace leafserver
}  // namespace reco
