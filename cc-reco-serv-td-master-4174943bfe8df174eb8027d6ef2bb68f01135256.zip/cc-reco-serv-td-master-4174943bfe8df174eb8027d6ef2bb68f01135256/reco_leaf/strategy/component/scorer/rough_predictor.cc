#include <algorithm>
#include <string>
#include <unordered_map>
#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "base/time/time.h"
#include "serving_base/data_manager/data_manager.h"
#include "serving_base/utility/timer.h"
#include "reco/bizc/common/item_level_define.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/rough_predictor.h"
#include "reco/serv/reco_leaf/frame/inner/dynamic_dict_container.h"

using std::string;
using std::vector;
using std::unordered_map;

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

DEFINE_int32(max_fea_count, 50, "");
DEFINE_int32(max_fea_size, 50, "");

RoughPredictor::RoughPredictor(const reco::NewsIndex* index) : news_index_(index) {}

RoughPredictor::~RoughPredictor() {}

void RoughPredictor::ExtractUserFea(const reco::FeatureVector& user_info,
                                    UserFea &user_fea,
                                    UserType user_type) {
  for (int i = 0; i < user_info.feature_size() && i < FLAGS_max_fea_count; ++i) { // top text topic
    const auto& fea = user_info.feature(i);
    if (fea.literal().empty()) continue;
    user_fea.fea[user_type].insert(std::make_pair(fea.literal(), fea.weight()));
    user_fea.norm_weight[user_type] += fea.weight();
  }
  VLOG(2) << "userfeatype: " << user_type << " size: " << user_info.feature_size();
  return;
}

void RoughPredictor::ExtractUserCateFea(const reco::CategoryFeatureVector& user_info,
                                    UserFea &user_fea,
                                    UserType user_type) {
  for (int i = 0; i < user_info.feature_size() && i < FLAGS_max_fea_count; ++i) { // top text topic
    const auto& fea = user_info.feature(i);
    const std::string& cate = fea.literal().category();
    if (cate.empty()) continue;
    user_fea.fea[user_type].insert(std::make_pair(cate, fea.weight()));
    user_fea.norm_weight[user_type] += fea.weight();
  }

  return;
}
bool RoughPredictor::PreProcessUserInfo(const UserInfo &user_info,
                                        UserFea &user_fea) {
  if (!user_info.has_profile() ||
      !user_info.profile().has_category_feavec()) {
    return false;
  }

  // userid
  user_fea.user_id = user_info.identity().user_id();
  // keyword
  user_fea.fea[kKeyword].set_empty_key("");
  user_fea.norm_weight[kKeyword] = 0.001;
  if (user_info.profile().has_keyword_feavec()) {
    const reco::FeatureVector& user_keyword = user_info.profile().keyword_feavec();
    ExtractUserFea(user_keyword, user_fea, kKeyword);
  }

  // tag
  user_fea.fea[kTag].set_empty_key("");
  user_fea.norm_weight[kTag] = 0.001;
  if (user_info.profile().has_tag_feavec()) {
    const reco::FeatureVector& user_tag = user_info.profile().tag_feavec();
    ExtractUserFea(user_tag, user_fea, kTag);
  }

  // topic
  user_fea.fea[kTopic].set_empty_key("");
  user_fea.norm_weight[kTopic] = 0.001;
  if (user_info.profile().has_topic_feavec()) {
    const reco::FeatureVector& user_topic = user_info.profile().topic_feavec();
    ExtractUserFea(user_topic, user_fea, kTopic);
  }

  // category
  user_fea.fea[kCategory].set_empty_key("");
  user_fea.norm_weight[kCategory] = 0.001;
  if (user_info.profile().has_category_feavec()) {
    const reco::CategoryFeatureVector& user_category = user_info.profile().category_feavec();
    ExtractUserCateFea(user_category, user_fea, kCategory);
  }

  return true;
}

bool RoughPredictor::BatchCalcScore(const UserInfo &user_info,
                                    std::vector<RoughScore> *candidate_vec,
                                    const std::vector<ItemInfo> *items) {
  if (!items) {
    LOG(WARNING) << "items is NULL";
    return false;
  }

  UserFea user_fea;
  if (!PreProcessUserInfo(user_info, user_fea)) {
    return false;
  }
  reco::xgboost::RegTree::FVec fvec_temp = reco::xgboost::RegTree::FVec();
  fvec_temp.Init(kFeatureSize);
  for (auto i = 0u; i < candidate_vec->size(); ++i) {
    RoughScore& rough_score = candidate_vec->at(i);
    const ItemInfo& item_info = items->at(rough_score.index);
    rough_score.score = DoPredict(user_fea, item_info, fvec_temp);
  }

  return true;
}

float RoughPredictor::CalScore(const std::vector<std::pair<std::string, float> >& item_fea,
                    const UserFea& user_fea,
                    UserType user_type) {
  float score = 0.0;

  for (size_t i = 0; i < item_fea.size(); ++i) {
    auto iter = user_fea.fea[user_type].find(item_fea.at(i).first);
    if (iter != user_fea.fea[user_type].end()) {
      score += iter->second / user_fea.norm_weight[user_type] * item_fea.at(i).second;
    }
  }
  return score;
}

float RoughPredictor::CalCategoryScore(const std::vector<reco::Category>& categorys,
                    const UserFea& user_fea,
                    UserType user_type) {
  float score = 0.0;
  int count = 0;
  for (size_t i = 0; i < categorys.size() && i < (size_t)FLAGS_max_fea_count; ++i) {
    auto iter = user_fea.fea[user_type].find(categorys[i].category());
    if (iter != user_fea.fea[user_type].end()) {
      score += iter->second / user_fea.norm_weight[user_type];
      count += 1;
      break;
    }
  }
  if (count > 0) {
    score = score / count;
  }
  return score;
}

int RoughPredictor::ExtractFea(const UserFea &user_fea,
                                  const ItemInfo &item_info,
                                  reco::xgboost::RegTree::FVec &features) {
  uint64 item_id = item_info.item_id;
  uint32 key = 1;
  int index = 0;

  int item_index = news_index_->GetItemIndex(item_info.item_id);
  if (item_index < 0) {
    return -1;
  }
  features.data[index].fvalue = -1.0;
  index += 1;

  const ItemFea& item_fea = news_index_->GetItemFea(item_index);
  // keyword
  float keyword_score = 0.0;
  keyword_score = CalScore(item_fea.keyword_info, user_fea, kKeyword);
  features.data[index].fvalue = keyword_score;
  index += 1;
  key += 1;

  // tag
  float tag_score = 0.0;
  tag_score = CalScore(item_fea.tag_info, user_fea, kTag);
  features.data[index].fvalue = tag_score;
  index += 1;
  key += 1;

  // topic
  float topic_score = 0.0;
  topic_score = CalScore(item_fea.topic_info, user_fea, kTopic);
  features.data[index].fvalue = topic_score;
  index += 1;
  key += 1;

  // category
  float category_score = CalScore(item_fea.category_info, user_fea, kCategory);
  features.data[index].fvalue = category_score;
  index += 1;
  key += 1;

  float ctr = item_info.wilson_ctr;
  features.data[index].fvalue = ctr;
  index += 1;
  key += 1;

  base::Time pub_time;
  base::Time search_time;
  int64 now_ts = base::GetTimestamp();
  int64 publish_time = news_index_->GetPublishSecondByItemId(item_id) * base::Time::kMicrosecondsPerSecond;
  base::TimeDelta delta = base::TimeDelta::FromMicroseconds(now_ts - publish_time);
  float day_interval = delta.InDays();
  features.data[index].fvalue = day_interval;
  index += 1;
  key += 1;

  auto click_ratio = DM_GET_DICT(reco::dm::CateClickRatio, DynamicDictContainer::kCateClickRatioFile_);
  float cateclickratio = 0.0;
  auto click_info = click_ratio.get()->cate_clik_ratio_.find(item_info.category);
  if (click_info != click_ratio.get()->cate_clik_ratio_.end()) {
    cateclickratio = click_info->second;
  }
  features.data[index].fvalue = cateclickratio;
  index += 1;
  key += 1;

  return index - 1;
}

float RoughPredictor::DoPredict(const UserFea &user_fea,
                                const ItemInfo &item_info,
                                reco::xgboost::RegTree::FVec &fvec_temp) {
  int feature_size = ExtractFea(user_fea, item_info, fvec_temp);
  if (feature_size < 0) {
    return -1.0;
  }

  auto rough_model = DM_GET_DICT(reco::dm::RoughModel, DynamicDictContainer::kRoughModelFile_);
  const reco::xgboost::XGboostModel* xgboost_model = &(rough_model.get()->xgboost_model_);

  float ret = xgboost_model->p_gbm->Predict(fvec_temp, -1, 0);
  float predict = xgboost_model->p_obj->PredTransform(ret);

  VLOG(2) << "itemid: " << item_info.item_id
          << " keyword_score: " << fvec_temp.data[1].fvalue
          << " tag_score: " << fvec_temp.data[2].fvalue
          << " topic_score: " << fvec_temp.data[3].fvalue
          << " cate_score: " << fvec_temp.data[4].fvalue
          << " ctr: " << fvec_temp.data[5].fvalue
          << " time: " << fvec_temp.data[6].fvalue
          << " cateclickratio: " << fvec_temp.data[7].fvalue
          << " category: " << item_info.category
          << " predict score pre: " << ret << " after: " << predict;
  return predict;

}
}  // namespace reco_leaf

}

