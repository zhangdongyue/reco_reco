#include <algorithm>

#include "base/time/time.h"
#include "base/strings/string_printf.h"
#include "base/common/logging.h"
#include "base/common/closure.h"

#include "base/hash_function/city.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/wd_predictor.h"

DEFINE_string(wd_text_model_name, "text_wd_online", "");
DEFINE_int32(wd_predict_thread_num, 20, "");
DEFINE_bool(open_model_server_wd, true, "");

namespace reco {
namespace leafserver {

WDPredictor::WDPredictor(const reco::NewsIndex* index) {
  news_index_ = index;
}

WDPredictor::~WDPredictor() {
}

bool WDPredictor::BatchCalcWDScore(const RecoRequest& request, const std::string& category,
                                   std::vector<ItemInfo>* items) {
  if (items->size() <= 0
      || !reco::reco_index::WDExtractor::Instance().HasReady()) return false;

  reco_request_ = &request;
  uint64 user_id = reco_request_->user_info->identity().user_id();
  serving_base::Timer timer;
  timer.Start();

  reco::model_server::PackagedRequest packaged_request;
  packaged_request.set_sid(user_id);
  reco::model_server::OneRequest* one_request = packaged_request.add_request_items();
  // 如果 one_request->set_user_id(1) 则浪浪那边不使用 cache
  // else 则以 userid 为 key 使用 cache
  one_request->set_user_id(1);
  for (size_t i = 0; i < items->size(); ++i) one_request->add_wide_deep_requests();

  // 抽取 user 静态特征，没命中缓存情况下需要重新抽取
  std::vector<reco::model_server::FeatureInfo> feature_info_vec;
  const reco::user::UserInfo& user_info = *reco_request_->user_info;
  if (reco::reco_index::WDExtractor::Instance().NeedExtractUserStaticFea(user_id)) {
    reco::reco_index::WDExtractor::Instance().ExtractUserStaticFea(user_info);
  }
  reco::reco_index::WDExtractor::Instance().GetUserStaticFea(user_id, &feature_info_vec);

  // 每次重新抽取 user 动态特征
  reco::ml::WDInfo wd_info;
  wd_info.channel_id = reco_request_->channel_id;
  wd_info.province = reco_request_->user_param_info.province;
  wd_info.city = reco_request_->user_param_info.city;
  wd_info.timestamp = base::GetTimestamp();
  reco::reco_index::WDExtractor::Instance().ExtractUserDynamicFea(wd_info, &feature_info_vec);
  reco::reco_index::WDExtractor::Instance().ExtractUserDynamicFea(user_info, &feature_info_vec);

  // 这里的 common feature 其实是 userfeture, 我理解 common 是指公共的 feature 的意思
  reco::model_server::Features* user_feature = one_request->mutable_common_feature();
  if (feature_info_vec.size() > 0) {
    for (size_t j = 0; j < feature_info_vec.size(); ++j) {
      user_feature->add_feature_info()->CopyFrom(feature_info_vec[j]);
      VLOG(1) << "[" << user_feature->feature_info(j).literal()
              << "] [" << user_feature->feature_info(j).text()
              << "]";
    }
  }

  // 并行抽取 item 特征
  thread::ThreadPool pool(FLAGS_wd_predict_thread_num);
  for (auto i = 0; i < FLAGS_wd_predict_thread_num; ++i) {
      pool.AddTask(NewCallback<WDPredictor, int, int32, const std::vector<ItemInfo>&,
                   reco::model_server::OneRequest*> (this, &WDPredictor::WDExtract, i,
                                                      FLAGS_wd_predict_thread_num, *items,
                                                      one_request));
  }
  pool.JoinAll();
  // LOG(INFO) << "extract_fea_time_cost : " << timer.Interval();

  if (FLAGS_open_model_server_wd) {
    // 解析 response
    reco::model_server::PackagedResponse response;
    VLOG(1) << "PackagedSearch begin:" << user_id << " items:" << items->size() 
            << " wdrequest:"<< one_request->wide_deep_requests_size();
    if (!reco::model_server::ModelServerAPIIns::instance().PackagedSearch(packaged_request, &response) ||
              response.responses_items_size() < 1) {
      LOG(ERROR) << "PackagedSearch err:" << user_id
                 << " responses_items_size:" << response.responses_items_size();
      return false;
    }
    const reco::model_server::OneResponse &one_response = response.responses_items(0);
    if ((int)items->size() != one_response.wide_deep_responses_size()) {
      LOG(ERROR) << "size diff:" << user_id << " request size:"
                 << one_request->wide_deep_requests_size() << " responses size:"
                 << one_response.wide_deep_responses_size();
      return false;
    }

    for (auto i = 0; i < one_response.wide_deep_responses_size(); ++i) {
      const reco::model_server::WideDeepResponse &wd_response = one_response.wide_deep_responses(i);
      if (wd_response.response_items_size() < 1) {
        LOG(ERROR) << "wd response has no response_items,code:" << wd_response.code();
        continue;
      }
      items->at(i).wd_text_score = wd_response.response_items(0).q();
      // 为了把日志打出来
      items->at(i).lr_score = wd_response.response_items(0).q() + 10000;
    }

    LOG(INFO) << "wd_text_response_suc " << items->back().item_id
              << " wdscore : " << items->back().wd_text_score
              << " wd_time_cost : " << timer.Stop()
              << " item size : " << items->size();
  }

  return true;
}

void WDPredictor::WDExtract(int thread_id, int32 thread_num, const std::vector<ItemInfo>& reco_items,
                            reco::model_server::OneRequest* one_request) {
  for (int i = thread_id; i < int(reco_items.size()); i += thread_num) {
    std::vector<reco::model_server::FeatureInfo> feature_info_vec;
    reco::ml::WDInfo wd_info;
    wd_info.item_id = reco_items[i].item_id;
    // 直接从索引里取得已经抽好的 item 特征
    wd_info.show_num = reco_items[i].show_num;
    wd_info.click_num = reco_items[i].click_num;
    reco::reco_index::WDExtractor::Instance().GetItemFeaByIndex(wd_info, &feature_info_vec);
    if (wd_info.show_num > 0) {
      VLOG(1) << "item_info : " << wd_info.click_num << " "
              << wd_info.show_num << " "
              << wd_info.click_num * 1000.0 / wd_info.show_num << " "
              << feature_info_vec[0].literal() << " "
              << feature_info_vec[0].text();
    }
    reco::model_server::WideDeepRequest* wide_deep_request = one_request->mutable_wide_deep_requests(i);
    wide_deep_request->mutable_model_info()->set_model_name(FLAGS_wd_text_model_name);
    wide_deep_request->set_sid(wd_info.item_id);
    if (feature_info_vec.size() > 0) {
      reco::model_server::Features* features = wide_deep_request->add_request_items();
      for (size_t j = 0; j < feature_info_vec.size(); ++j) {
        features->add_feature_info()->CopyFrom(feature_info_vec[j]);
        if (wd_info.show_num > 0) VLOG(1) << "thread_id : [" << thread_id
                << "] [" << features->feature_info(j).literal()
                << "] [" << features->feature_info(j).text()
                << "]";
      }
    }
  }
}

}  // namespace reco_leaf
}  // namespace reco
