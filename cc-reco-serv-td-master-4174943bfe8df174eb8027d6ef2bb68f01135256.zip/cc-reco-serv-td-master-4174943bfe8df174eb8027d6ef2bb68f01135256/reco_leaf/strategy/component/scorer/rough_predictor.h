#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include "base/time/time.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/xgboost_util.h"


namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {

static const int kFeatureSize = 8;

enum UserType {
  kKeyword = 0,
  kTag,
  kTopic,
  kCategory
};

struct RoughScore {
  int index;
  float score;
};

struct UserFea {
  uint64 user_id;
  base::dense_hash_map<std::string, float> fea[4];
  float norm_weight[4];
};

class RoughPredictor {
 public:
  explicit RoughPredictor(const reco::NewsIndex* index);

  ~RoughPredictor();

  bool BatchCalcScore(const reco::user::UserInfo &user_info,
                      std::vector<RoughScore> *candidate_vec,
                      const std::vector<ItemInfo> *items);

 private:
  const NewsIndex *news_index_;

  DISALLOW_COPY_AND_ASSIGN(RoughPredictor);

  float DoPredict(const UserFea &user_fea,
                  const ItemInfo &item_info,
                  reco::xgboost::RegTree::FVec &fvec_temp);

  float CalScore(const std::vector<std::pair<std::string, float> >& item_fea,
                    const UserFea& user_fea,
                    UserType user_type);

  float CalCategoryScore(const std::vector<reco::Category>& categorys,
                    const UserFea& user_fea,
                    UserType user_type);

  float WilsonIntervalRatio(int numerator, int denominator);

  bool PreProcessUserInfo(const reco::user::UserInfo &user_info,
                          UserFea &user_fea);

  void ExtractUserFea(const reco::FeatureVector& user_info,
                                    UserFea &user_fea,
                                    UserType user_type);

  void ExtractUserCateFea(const reco::CategoryFeatureVector& user_info,
                                    UserFea &user_fea,
                                    UserType user_type);
  int ExtractFea(const UserFea &user_fea,
                  const ItemInfo &item_info,
                  reco::xgboost::RegTree::FVec &fvec_temp);

};
}
}

