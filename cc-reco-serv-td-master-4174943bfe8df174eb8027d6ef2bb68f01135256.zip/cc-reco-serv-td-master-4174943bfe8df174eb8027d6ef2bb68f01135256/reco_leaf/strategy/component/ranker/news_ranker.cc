#include "reco/serv/reco_leaf/strategy/component/ranker/news_ranker.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/rank_model.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/ranker_reason.h"
#include "reco/serv/reco_leaf/strategy/reco/offline/item_dict_manager.h"
#include "reco/serv/reco_leaf/strategy/reco/offline/base_item_dict.h"
#include "reco/bizc/region/region_dict.h"

namespace reco {
namespace leafserver {
DEFINE_string(tag_prefix, "label:", "item tag的前缀,默认为 label:");
DEFINE_string(semantic_tag_prefix, "label2:", "item semantic tag的前缀,默认为 label2:");

DEFINE_double(mid_timelevel_boost, -0.2, "");
DEFINE_double(low_timelevel_boost, -0.4, "");
DEFINE_double(daily_interval_boost, -0.15, "daily interval item boost.");
DEFINE_double(extreme_mid_timelevel_boost, -0.2, "");
DEFINE_double(extreme_low_timelevel_boost, -0.4, "");

DEFINE_bool(open_region_tuning_switch, false, "是否开启地域调权策略");
DEFINE_int32(max_region_tuning_item_num, 200, "最大的调权条数");
DEFINE_double(region_matched_boost, 0.1, "匹配时的加权系数");
DEFINE_double(region_unmatched_boost, -0.05, "不匹配时的降权系数");

DEFINE_double(no_image_boost, -0.8, "无图调权");
DEFINE_double(multi_image_boost, 0, "多图调权");

DEFINE_double(stagetag_boost, 0.5, "阶段特征命中tag的item的调权系数, 默认0.5");

DEFINE_double(local_channel_personal_matched_boost, 0.1, "");
DEFINE_double(local_channel_personal_unmatched_boost, -0.3, "");

DECLARE_bool(open_cf_tuning_switch);
DEFINE_int32(max_cf_tuning_item_num, 500, "cf tunning 最大的 item 条数");
DEFINE_double(cf_tuning_boost, 0, "cf 加权的系数");

DEFINE_double(manual_item_boost, 0.08, "manual item reco score boost.");

DEFINE_double(subscript_wemedia_item_boost, 0, "subscript wemedia item boost.");
DEFINE_double(dislike_subcategory_boost_pow, 1, "");

DEFINE_bool(force_open_high_quality_user, false, "强制都走高端用户调权策略");
DEFINE_double(high_user_high_item_tune, 1.6, "");
DEFINE_double(high_user_mid_quality_boost, 0.9, "high user mid quality boost");
DEFINE_double(high_user_low_quality_boost, 0.8, "high user low quality boost");
DEFINE_bool(bad_item_quality_degrade, false, "bad_item_quality_degrade");

static const std::vector<float> kLrCtrMap
    = {0.06, 0.108, 0.131, 0.1595, 0.1678, 0.1679, 0.1659, 0.1659, 0.1659, 0.1659};

NewsRanker::NewsRanker(const reco::NewsIndex* index) {
  news_index_ = index;
  rank_model_ = new RankModel(index);
  random_ = new base::PseudoRandom(base::GetTimestamp());
  personal_item_dicts_ = NULL;
}

NewsRanker::~NewsRanker() {
  delete random_;
}

void NewsRanker::Rank(const std::string& category,
                      const RecoRequest* reco_request,
                      const std::vector<ItemInfo>& ir_items,
                      std::vector<ItemInfo>* reco_items,
                      RecoDebugger* debugger) {
  if (ir_items.empty()) return;
  reco_items->clear();

  reco_request_ = reco_request;

  // 计算各种模型得分
  std::vector<ModelData> model_results;
  model_results.resize(ir_items.size());
  for (size_t idx = 0; idx < ir_items.size(); ++idx) {
    model_results[idx].item_id = ir_items.at(idx).item_id;
  }
  ModelExtraInfo model_extra;
  // rank_model_->SetEnv(reco_request, user_feature_, ugm_model_, remain_prefix_);
  rank_model_->SetEnv(reco_request, user_feature_);
  rank_model_->BatchPredict(category, ir_items, &model_results, &model_extra);

  bool wd_is_available = true;
  if (model_extra.avg_wd <= 0.001) wd_is_available = false;
  LOG_IF(INFO, !wd_is_available) << "wd score not available : " << model_extra.avg_wd;

  // 对于特定类别，需要进行二级类别调权
  float l2_boost_pow = 0.0f;
  const FeaKeyVal* l2_cates = NULL;
  std::string map_category = category;
  GenSubCateTuneParam(category, &map_category, &l2_cates, &l2_boost_pow);

  int cf_item_count = 0;
  int cf_cover_count = 0;
  bool do_image_tune = IfDoImageTune(category);
  int region_tuning_count = DecideMaxRegionTuneItemNum(map_category);
  uint32 max_rank_num = kPersonalTraverseCutoff * LeafDataManager::GetGlobalData()->GetSelectionRatio();
  if (!reco_request_->user_param_info.is_inner_qudao) {
    max_rank_num /= 5;
  }

  for (size_t idx = 0; idx < ir_items.size(); ++idx) {
    if (reco_items->size() >= max_rank_num) break;
    reco_items->push_back(ir_items[idx]);
    ItemInfo& item = reco_items->back();
    const ModelData& model_data = model_results[idx];
    // wd 调权
    // double wd_score = model_data.wd_text_score > 0.001 ? model_data.wd_text_score : model_extra.avg_wd;
    double wd_score = model_data.wd_text_score;
    item.wd_text_score = wd_score;
    double merge_score = 0.001;
    if (wd_is_available) {
      merge_score = wd_score * 0.9 + item.reco_score * 0.1 / kRecoScoreFactor;
      // merge_score = std::max(0.001, wd_score);
    } else {
      merge_score = std::max(0.001f, item.reco_score * 1.0f / kRecoScoreFactor);
    }

    // 各种调权策略
    // 1) 二级类目调权
    RankerDebugReason ranker_reason(debugger, item.item_id, merge_score);
    merge_score = TuneByUserSubCate(item, merge_score, map_category, l2_cates, l2_boost_pow);
    ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kUserL2FeatureTuneFlag);

    // 2) 用户属性调权
    merge_score = TuneByUserAttr(item, merge_score);
    ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kUserAttributeTuneFlag);

    // 3) 时效性调权
    if (!reco::common::IsVideoChannel(reco_request_->channel_id)) {
      // 视频一二级频道不做时效性调权
      merge_score = TuneByItemTime(item, merge_score);
      ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kTimeTuneFlag);
    }
    // 5) 文章质量调权
    merge_score = TuneByItemQuality(item, merge_score);
    ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kQualityTuneFlag);
    // 6) CF 调权
    if (cf_item_count < FLAGS_max_cf_tuning_item_num) {
      // merge_score = TuneByCFDict(reco_request->personal_item_dicts,
      //                            item, merge_score, &cf_cover_count);
      merge_score = TuneByCFDict(personal_item_dicts_,
                                 item, merge_score, &cf_cover_count);
      ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kCollaboritiveFilterTuneFlag);
      ++cf_item_count;
    }
    // 7) 地域调权
    if (region_tuning_count < FLAGS_max_region_tuning_item_num) {
      merge_score = TuneByRegion(item, merge_score);
      ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kRegionTuneFlag);
      ++region_tuning_count;
    }
    // // 8) 图片数量调权
    if (do_image_tune && (int)idx < kImageTuneMaxItem) {
      merge_score = TuneByImageNum(item, merge_score);
      ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kImageNumTuneFlag);
    }
    // 9) 本地频道调权
    if (reco_request_->channel_id == reco::common::kLocalChannelId) {
      merge_score = LocalChannelPersonalTune(item, merge_score);
      ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kLocalChannelPersonalTuneFlag);
    }
    // 10) 生命阶段调权
    merge_score = TuneByLifeStageTag(item, merge_score);
    ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kLifeStageTuneFlag);
    // 11) 分类分数调权，打压分类不准的新闻，提升垂直频道效果
    if (reco_request_->channel_id == reco::common::kSocialChannelId
        || reco_request_->channel_id == reco::common::kFinanceChannelId
        || reco_request_->channel_id == reco::common::kScienceChannelId) {
      merge_score = TuneByCategoryScore(item, merge_score);
      ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kCategoryScoreTuneFlag);
    }
    // 12) 时长分数调权
    merge_score *= item.duration_score;
    ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kDurationTuneFlag);
    // 13) 高端人群调权
    merge_score = TuneByUserQuality(item, merge_score);
    ranker_reason.AddReasonFlagOnScoreChange(merge_score, RecoDebugInfo::kUserQualityTuneFlag);

    // 离散化
    merge_score = (static_cast<int>(merge_score * 1000)) / 1000.0;
    // 标准化
    item.reco_score = static_cast<int>(merge_score * kRecoScoreFactor + 0.5);
    // 防止越界
    item.reco_score = std::min(kRecoScoreFactor - 1, item.reco_score);

    ranker_reason.CommitDebugReason();
  }

  std::sort(reco_items->begin(), reco_items->end(), std::greater<ItemInfo>());
  GenerateReturnItems(map_category, reco_items);

  // PrintItems(*reco_items);

  if (reco_items->size() > 0) {
    VLOG(2) << base::StringPrintf("uid:%lu item size:%u (%lu:%d) (%lu:%d)",
                                  reco_request_->user_info->identity().user_id(),
                                  (unsigned)reco_items->size(),
                                  reco_items->front().item_id, reco_items->front().reco_score,
                                  reco_items->back().item_id, reco_items->back().reco_score);
  }

  // LOG(INFO) << "wd_score_avg : " << model_extra.avg_wd;
}

void NewsRanker::PrintItems(const std::vector<ItemInfo>& items) const {
  uint64 uid = reco_request_->user_info->identity().user_id();
  int64 cid = reco_request_->channel_id;
  std::string title;
  for (size_t i = 0; i < items.size(); ++i) {
    const ItemInfo& item = items[i];
    if (!news_index_->GetItemTitleByDocId(item.doc_id, &title)) {
      title = "no_title";
    }
    std::string subcate = item.sub_category.empty() ? "no_subcate" : item.sub_category;
    LOG(INFO) << "RANK, " << uid << "\t" << cid << "\t" << item.item_id
              << "\t" << subcate << "\t" << item.reco_score << "\t" << item.show_num
              << "\t" << item.click_num << "\t" << item.index_score << "\t" << item.wd_text_score << "\t" << title;
  }
}

float NewsRanker::TuneByCategoryScore(const reco::ItemInfo& item, double org_reco_score) const {
  // 只对科技、娱乐、财经三个频道运用此策略
  static const float kMultiCateDftScore = 0.8;
  static const float kCategoryWeightPow = 0.5;
  float cate_score = 0.0f;
  if (!news_index_->GetCategoryScore(item.item_id, item.category, &cate_score)) {
    cate_score = kMultiCateDftScore;
  }
  if (cate_score <= 1e-6) {
    cate_score = kMultiCateDftScore;
  } else if (cate_score > 1.0f) {
    cate_score = 1.0f;
  }

  // 对 kNews 的文章，以 0.5, 0.8 为区间作分段函数融合类目分数
  double reco_score = org_reco_score;
  if (item.item_type == reco::kNews
      && item.media_level == reco::kBadMedia) {
    if (cate_score < 0.5) {
      reco_score = org_reco_score * 0.17;
    } else if (cate_score < 0.8) {
      reco_score = org_reco_score * pow((cate_score - 0.49f) / 0.31f, kCategoryWeightPow);
    }
  }
  VLOG(1) << base::StringPrintf("multi cate ajust reco_score: %lu %s %s %d %.4f %.4f %.4f %d %d ",
                                item.item_id, item.category.c_str(),
                                reco::ItemType_Name(item.item_type).c_str(),
                                item.media_level,
                                org_reco_score, reco_score, cate_score,
                                item.show_num, item.click_num);
  return reco_score;
}

float NewsRanker::TuneByLifeStageTag(const reco::ItemInfo& item, double org_reco_score) const {
  static const std::string kTagPrefix = "label:";
  static const std::string kSemanticTagPrefix = "label2:";
  int life_stage = reco_request_->request->has_life_stage() ?
      reco_request_->request->life_stage() : reco::kNoStage;
  if (life_stage == reco::kNoStage) return org_reco_score;

  std::string channelstagekey = base::StringPrintf("%ld_%d", reco_request_->channel_id, life_stage);
  StageMap::iterator iter = LeafDataManager::GetGlobalData()->life_stage_tags_dict.find(channelstagekey);
  if (iter == LeafDataManager::GetGlobalData()->life_stage_tags_dict.end()) return org_reco_score;

  // process tag, literal start with "label:"
  reco::FeatureVector fevtag;
  StageTag::iterator it = iter->second.end();
  if (news_index_->GetFeatureVectorByItemId(item.item_id, reco::common::kTag, &fevtag)) {
    for (int j = 0; j < fevtag.feature_size(); ++j) {
      std::string tag = fevtag.feature(j).literal();
      if (tag.substr(0, kTagPrefix.length()) == kTagPrefix) {
        tag = tag.substr(kTagPrefix.length(), tag.length() - kTagPrefix.length());
      }
      if (iter->second.find(tag) != it) {
        double new_score = org_reco_score * (1 + FLAGS_stagetag_boost);
        return new_score;
      }
    }
  }
  // process semantic tag, literal start with "label2:"
  reco::FeatureVector fevsemanticag;
  if (news_index_->GetFeatureVectorByItemId(item.item_id,
                                            reco::common::kSemanticTag, &fevsemanticag)) {
    for (int j = 0; j < fevsemanticag.feature_size(); ++j) {
      std::string tag = fevsemanticag.feature(j).literal();
      if (tag.substr(0, kSemanticTagPrefix.length()) == kSemanticTagPrefix) {
        tag = tag.substr(kSemanticTagPrefix.length(), tag.length() - kSemanticTagPrefix.length());
      }
      if (iter->second.find(tag) != it) {
        double new_score = org_reco_score * (1 + FLAGS_stagetag_boost);
        return new_score;
      }
    }
  }
  return org_reco_score;
}

float NewsRanker::LocalChannelPersonalTune(const reco::ItemInfo& item, double org_reco_score) const {
  static const std::unordered_set<std::string> kLocalPersonalCategories = {
    "汽车", "房产", "历史", "健康", "体育", "娱乐"};
  if (kLocalPersonalCategories.find(item.category) == kLocalPersonalCategories.end()) {
    return org_reco_score;
  }
  auto const& personal_categories =  reco_request_->user_feas->merged_fea.confidence_l1_cates;
  bool personal_matched = (personal_categories.find(item.category) != personal_categories.end());
  double reco_score = org_reco_score;
  if (personal_matched) {
    reco_score *= (1 + FLAGS_local_channel_personal_matched_boost);
  } else {
    reco_score *= (1 + FLAGS_local_channel_personal_unmatched_boost);
  }
  VLOG(1) << "item tuning by local channel personalize: "
          << item.item_id << ", " << org_reco_score << ", " << reco_score;
  return reco_score;
}

float NewsRanker::TuneByImageNum(const reco::ItemInfo &item, double org_reco_score) const {
  int image_num = news_index_->GetImageCountByDocId(item.doc_id);
  float tune = 1;
  if (image_num == 0 || image_num >= 200) {
    tune = 1 + FLAGS_no_image_boost;
  } else if (image_num >= 3) {
    tune = 1 + FLAGS_multi_image_boost;
  }
  return org_reco_score * tune;
}

float NewsRanker::TuneByRegion(const reco::ItemInfo& item, double org_reco_score) const {
  std::vector<int64> region_ids;
  if (!news_index_->GetRegionIdByDocId(item.doc_id, &region_ids) ||
      region_ids.empty()) {
    return org_reco_score;
  }

  bool city_matched = false;
  bool prov_matched = false;
  for (size_t i = 0; i < region_ids.size(); ++i) {
    if (region_ids[i] == reco_request_->user_feas->attr.city_id) {
      city_matched = true;
      break;
    }

    std::string str_prov_id = reco::common::RegionSearcher::instance().
        GetProvinceCodeByRegionCode(base::Int64ToString(region_ids[i]));
    int64 prov_id;
    if (!base::StringToInt64(str_prov_id, &prov_id)) {
      continue;
    }
    if (prov_id == reco_request_->user_feas->attr.prov_id) {
      prov_matched = true;
      break;
    }
  }

  bool region_matched = city_matched || prov_matched;
  // 过滤地域不匹配且低质的内容
  if (!region_matched &&
      item.show_num > 500 && item.ctr < 0.05) {
    return 0;
  }
  // 根据匹配程度进行调权
  double new_score = region_matched ? org_reco_score * (1 + FLAGS_region_matched_boost) :
      org_reco_score * (1 + FLAGS_region_unmatched_boost);
  VLOG(1) << "item tuning by region: " << item.item_id << ", " << org_reco_score << ", " << new_score;
  return new_score;
}

float NewsRanker::TuneByCFDict(const std::unordered_map<uint64, ItemDictData> *personal_item_dicts,
                               const reco::ItemInfo &item, double org_reco_score, int *cf_cover_count) const {
  if (!FLAGS_open_cf_tuning_switch || personal_item_dicts == NULL || personal_item_dicts->empty()) {
    return org_reco_score;
  }

  double new_score = org_reco_score;
  auto iter = personal_item_dicts->find(item.item_id);
  if (iter == personal_item_dicts->end()) {
    return new_score;
  }

  *cf_cover_count += 1;
  auto &item_dict_data = iter->second;
  const uint32 &data = item_dict_data.data[kCFDict];
  if (!(data & 0x01)) {
    VLOG(1) << "cf candidate not valid: " << item.item_id << ", " << item.category;
    return new_score;
  }

  bool label = ((data >> 1) & 0x01);
  float score = std::min(std::max(static_cast<float>(data >> 16) / 1000, 0.0f), 1.0f);
  uint32 confidence = (data >> 2) & 0x3fff;
  if (confidence < 1 || score <= 1e-6) {
    VLOG(1) << "cf data error: " << item.item_id << ", " << score << ", " << confidence;
    return org_reco_score;
  }

  double cf_boost = FLAGS_cf_tuning_boost;
  if (confidence < 2) {
    cf_boost *= 1.0;
  } else if (confidence < 3) {
    cf_boost *= 1.1;
  } else if (confidence < 5) {
    cf_boost *= 1.2;
  } else if (confidence < 10) {
    cf_boost *= 1.3;
  } else {
    cf_boost *= 1.4;
  }

  if (!label) score *= (-1);
  new_score *= pow(1 + score, cf_boost);

  return new_score;
}

float NewsRanker::TuneByUserQuality(const reco::ItemInfo& item, double org_reco_score) const {
  float merge_score = org_reco_score;
  bool is_good_media = false;
  if ((item.is_source_wemedia && item.media_level >= reco::kGoodMedia)
      || (!item.is_source_wemedia && item.media_level >= reco::kNormalMedia)) is_good_media = true;
  if (FLAGS_force_open_high_quality_user || reco_request_->is_high_quality_user) {
    if (is_good_media
        || item.itemq >= reco::kGoodItemq) {
      // 文章质量在前面只对运营加权了，所以这里采用统一加权
      merge_score = merge_score * FLAGS_high_user_high_item_tune;
    } else if (item.strategy_type == reco::kManual) {
      // 运营文章前面有一点加权，这里要减去
      merge_score = merge_score * (FLAGS_high_user_high_item_tune - FLAGS_manual_item_boost);
    } else if (item.media_level < reco::kLowMedia || item.itemq < reco::kLowItemq) {
      double weight = FLAGS_high_user_mid_quality_boost;
      if (item.media_level == reco::kBadMedia || item.itemq == reco::kBadItemq) {
        weight = FLAGS_high_user_low_quality_boost;
      }
      merge_score = merge_score * weight;
    }
    // 低质和标题党一律强降权。
    bool is_trival = true;
    ContentAttr content_attr;
    if (news_index_->GetContentAttrByItemId(item.item_id, &content_attr, &is_trival) && !is_trival) {
      if ((content_attr.has_erro_title() && content_attr.erro_title() != reco::ContentAttr::kSureNo)
        || (content_attr.has_advertorial() && content_attr.advertorial() != reco::ContentAttr::kSureNo)
        || (content_attr.has_short_content() && content_attr.short_content() != reco::ContentAttr::kSureNo)
        || (content_attr.has_dedup_paragraph() && content_attr.dedup_paragraph() != reco::ContentAttr::kSureNo)
        || (content_attr.has_dirty() && content_attr.dirty() != reco::ContentAttr::kSureNo)
        || (content_attr.has_politics() && content_attr.politics() != reco::ContentAttr::kSureNo)
        || (content_attr.has_bluffing_title() && content_attr.bluffing_title() != reco::ContentAttr::kSureNo)
        || (content_attr.has_negative() && content_attr.negative() != reco::ContentAttr::kSureNo)) {
        merge_score = merge_score * FLAGS_high_user_low_quality_boost;
      }
    }
  }
  return merge_score;
}

float NewsRanker::TuneByItemQuality(const reco::ItemInfo& item, double org_reco_score) const {
  // 人工运营
  if (item.strategy_type == reco::kManual) {
    return org_reco_score * (1 + FLAGS_manual_item_boost);
  }
  float boost = 0;
  if (item.is_source_wemedia) {
    if (item.media_level == reco::kBadMedia || item.itemq == reco::kBadItemq) {
      boost = -0.2;
    } else if (item.media_level == reco::kLowMedia || item.itemq == reco::kLowItemq) {
      boost = -0.1;
    }
    if (FLAGS_bad_item_quality_degrade) {
      bool is_trival = true;
      ContentAttr content_attr;
      if (news_index_->GetContentAttrByItemId(item.item_id, &content_attr, &is_trival) && !is_trival) {
        if ((content_attr.has_erro_title() && content_attr.erro_title() != reco::ContentAttr::kSureNo)
          || (content_attr.has_advertorial() && content_attr.advertorial() != reco::ContentAttr::kSureNo)
          || (content_attr.has_short_content() && content_attr.short_content() != reco::ContentAttr::kSureNo)
          || (content_attr.has_dedup_paragraph() && content_attr.dedup_paragraph() != reco::ContentAttr::kSureNo)
          || (content_attr.has_dirty() && content_attr.dirty() != reco::ContentAttr::kSureNo)
          || (content_attr.has_politics() && content_attr.politics() != reco::ContentAttr::kSureNo)
          || (content_attr.has_bluffing_title() && content_attr.bluffing_title() != reco::ContentAttr::kSureNo)
          || (content_attr.has_negative() && content_attr.negative() != reco::ContentAttr::kSureNo)) {
          boost = -0.1;
        }
      }
    }
  }
  return org_reco_score * (1 + boost);
}

float NewsRanker::TuneByItemTime(const reco::ItemInfo& item, double org_reco_score) const {
  if (reco_request_->is_today_req) {
    if (item.time_level == reco::kGoodTimeliness) return org_reco_score;
    float tune_boost = 1;
    if (item.category == "体育") {
      if (item.time_level == reco::kMidTimeliness) {
        tune_boost = 1 + FLAGS_extreme_mid_timelevel_boost;
      } else if (item.time_level == reco::kBadTimeliness) {
        tune_boost = 1 + FLAGS_extreme_low_timelevel_boost;
      }
    } else {
      if (item.time_level == reco::kMidTimeliness) {
        tune_boost = 1 + FLAGS_mid_timelevel_boost;
      } else if (item.time_level == reco::kBadTimeliness) {
        tune_boost = 1 + FLAGS_low_timelevel_boost;
      }
    }
    return org_reco_score * tune_boost;

  } else {
    // 非当天的历史请求
    base::Time item_time = base::Time::FromDoubleT(
        (double)item.create_timestamp / base::Time::kMicrosecondsPerSecond);
    float boost = 1;
    int day_interval = 0;
    if (item_time >= reco_request_->req_news_date) {
      day_interval = (item_time - reco_request_->req_news_date).InDays();
    } else {
      day_interval = (reco_request_->req_news_date - item_time).InDays();
    }
    if (day_interval == 0) {
      boost = 1.1;
    } else {
      boost = std::pow((1 + FLAGS_daily_interval_boost), day_interval);
      boost = std::max(0.3f, boost);
    }
    return org_reco_score * boost;
  }
}

void NewsRanker::GenSubCateTuneParam(const std::string& category, std::string* map_category,
                                     const FeaKeyVal** user_sub_cates, float* boost_pow) {
  *boost_pow = 0.0f;
  *map_category = category;
  *user_sub_cates = NULL;

  if (!map_category->empty()) {
    // nothing
  } else if (reco_request_->channel_id == reco::common::kSportChannelId) {
    *map_category = reco::common::kSportCategory;
  } else if (reco_request_->channel_id == reco::common::kScienceChannelId) {
    *map_category = reco::common::kScienceCategory;
  } else if (reco_request_->channel_id == reco::common::kFinanceChannelId) {
    *map_category = reco::common::kFinanceCategory;
  }

  static const std::unordered_set<std::string> kDoL2Categories = {"体育", "财经", "科技"};
  if (kDoL2Categories.find(*map_category) != kDoL2Categories.end()) {
    auto const& ref_l1_raw_cates = reco_request_->user_feas->lt_fea.raw_l1_cates;
    auto raw_iter = ref_l1_raw_cates.find(*map_category);
    float kMaxL2BoostPow = category.empty() ? 0.8 : 1.5;
    if (raw_iter != ref_l1_raw_cates.end()) {
      *boost_pow = std::min(kMaxL2BoostPow, (float)raw_iter->second / 15);
    }
    auto const& ref_l2_cates = reco_request_->user_feas->merged_fea.l2_cates;
    auto l2_iter = ref_l2_cates.find(*map_category);
    if (l2_iter != ref_l2_cates.end()
        && !l2_iter->second.empty()) {
      *user_sub_cates = &(l2_iter->second);
    }
  }
}

float NewsRanker::TuneByUserSubCate(const reco::ItemInfo& item, double org_score,
                                    const std::string& category, const FeaKeyVal* l2_cates,
                                    float l2_boost_pow) const {
  if (l2_cates == NULL || org_score < 1e-4 || l2_boost_pow < 1e-4) return org_score;

  float l2_boost = 0;
  if (item.category == category) {
    auto iter = l2_cates->find(item.sub_category);
    if (iter != l2_cates->end()) {
      l2_boost = std::min(1.0, iter->second * 1.5);
    }
  }

  float tune_reco_score = org_score * std::pow((1 + l2_boost) * 0.5, l2_boost_pow);

  VLOG(1) << "TuneByUserSubCate: " << item.item_id
          << ", " << org_score << ", " << tune_reco_score;

  return tune_reco_score;
}


float NewsRanker::TuneByUserAttr(const reco::ItemInfo& item, double org_reco_score) const {
  double tune_reco_score = org_reco_score;

  // dislike category
  auto const& ref_dislike_cates = reco_request_->user_feas->behavior_fea.dislike_sub_cates;
  if (FLAGS_dislike_subcategory_boost_pow > 1e-6
      && !ref_dislike_cates.empty()
      && !item.sub_category.empty()) {
    auto dislike_iter = ref_dislike_cates.find(item.sub_category);
    if (dislike_iter != ref_dislike_cates.end()) {
      double tune_ratio = std::min(0.0f, 1 - dislike_iter->second);
      tune_ratio = std::pow(tune_ratio, FLAGS_dislike_subcategory_boost_pow);
      tune_reco_score *= tune_ratio;
    }
  }

  std::string wemedia_person;
  auto const& ref_subscript_sources = reco_request_->user_feas->behavior_fea.subscript_sources;
  if (FLAGS_subscript_wemedia_item_boost > 1e-6
      && item.is_source_wemedia
      && !ref_subscript_sources.empty()) {
    auto iter = ref_subscript_sources.find(wemedia_person);
    if (iter != ref_subscript_sources.end()) {
      tune_reco_score *= (1 + FLAGS_subscript_wemedia_item_boost) * iter->second;
    }
  }

  VLOG(1) << "TuneByUserAttr: " << item.item_id
          << ", " << org_reco_score << ", " << tune_reco_score;
  return tune_reco_score;
}

bool NewsRanker::IfDoImageTune(const std::string& category) const {
  bool do_image_tune = false;
  if (reco_request_->user_param_info.is_wifi
      && (FLAGS_no_image_boost != 0 || FLAGS_multi_image_boost != 0)) {
    if (reco_request_->channel_id == 100) {
      do_image_tune = (category != "财经");
    } else if (reco_request_->channel_id != reco::common::kFinanceChannelId) {
      do_image_tune = true;
    }
  }
  return do_image_tune;
}

int NewsRanker::DecideMaxRegionTuneItemNum(const std::string& category) const {
  static const std::unordered_set<std::string> kRegionTuningCategories = {"社会", "国内"};
  int region_tuning_count = 0;
  if (!FLAGS_open_region_tuning_switch
      || (reco_request_->user_feas->attr.city_id == 0
          && reco_request_->user_feas->attr.prov_id == 0)
      || kRegionTuningCategories.find(category) == kRegionTuningCategories.end()) {
    region_tuning_count = kInt32Max;
  }
  return region_tuning_count;
}

/*
uint32 NewsRanker::DecideMaxRankItemNum() const {
  uint32 dynamic_traverse_num = kPersonalTraverseCutoff;
  switch (LeafDataManager::GetGlobalData()->sys_status) {
    case kSysFree:
    case kSysNormal:
      dynamic_traverse_num *= 1.2;
      break;
    case kSysFull:
      dynamic_traverse_num *= 0.8;
      break;
    case kSysDanger:
      dynamic_traverse_num *= 0.5;
      break;
    case kSysCritical:
      dynamic_traverse_num *= 0.2;
      break;
    default:
      break;
  }
  return dynamic_traverse_num;
}
*/

void NewsRanker::GenerateReturnItems(const std::string& category,
                                     std::vector<ItemInfo>* reco_items) {
  static const uint32 kBarrelSize = 100;
  if (reco_items->size() <= kBarrelSize) return;
  
  base::dense_hash_map<std::string, int> subcate_num_dict;
  subcate_num_dict.set_empty_key("");
  if (category == "体育") {
    subcate_num_dict.insert(std::make_pair("nba", 0));
    subcate_num_dict.insert(std::make_pair("cba", 0));
    subcate_num_dict.insert(std::make_pair("国内足球", 0));
    subcate_num_dict.insert(std::make_pair("国际足球", 0));
  } else if (category == "科技") {
    subcate_num_dict.insert(std::make_pair("手机", 0));
    subcate_num_dict.insert(std::make_pair("互联网", 0));
  } else if (category == "财经") {
    subcate_num_dict.insert(std::make_pair("股票", 0));
    subcate_num_dict.insert(std::make_pair("经济民生", 0));
  }
  if (subcate_num_dict.empty()) {
    if (reco_items->size() > kMaxReturn) {
      reco_items->resize(kMaxReturn);
    }
    return;
  }

  int cut_pos = subcate_num_dict.size() >= 3 ? kBarrelSize / 3 : kBarrelSize / 2;
  std::vector<ItemInfo> swap_items;
  swap_items.insert(swap_items.begin(), reco_items->begin(), reco_items->begin() + cut_pos);

  std::vector<bool> used_idx_vec(reco_items->size(), false);
  for (size_t idx = 0; idx < swap_items.size(); ++idx) {
    used_idx_vec[idx] = true;
    const ItemInfo& item = swap_items.at(idx);
    if (item.sub_category.empty()) continue;
    auto const iter = subcate_num_dict.find(item.sub_category);
    if (iter != subcate_num_dict.end()) {
      iter->second += 1;
    }
  }

  for (size_t idx = cut_pos; idx < reco_items->size(); ++idx) {
    const ItemInfo& item = reco_items->at(idx);
    if (item.sub_category.empty()) continue;
    auto const iter = subcate_num_dict.find(item.sub_category);
    if (iter != subcate_num_dict.end() && iter->second < (int)kBarrelSize) {
      swap_items.push_back(item);
      iter->second += 1;
      used_idx_vec[idx] = true;
    }
  }

  for (size_t idx = cut_pos; idx < reco_items->size(); ++idx) {
    if (swap_items.size() >= kMaxReturn) break;
    if (used_idx_vec[idx]) continue;
    const ItemInfo& item = reco_items->at(idx);
    swap_items.push_back(item);
  }

  reco_items->swap(swap_items);
  swap_items.clear();
}

}
}
