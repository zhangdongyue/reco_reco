#include "reco/serv/reco_leaf/strategy/component/ranker/shopping_ranker.h"

#include <algorithm>
#include <unordered_map>
#include <functional>
#include <utility>

#include "boost/unordered_map.hpp"

#include "base/time/timestamp.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_tokenize.h"
#include "base/strings/string_printf.h"
#include "base/common/logging.h"
#include "base/math/discrete.h"

#include "reco/bizc/common/item_level_define.h"
#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"


namespace reco {
namespace leafserver {

ShoppingRanker::ShoppingRanker(const reco::NewsIndex* index) {
  news_index_ = index;
  item_dedup_.set_empty_key(0);
}

ShoppingRanker::~ShoppingRanker() {
}

void ShoppingRanker::Rank(const RecoRequest* reco_request,
                     std::vector<ItemInfo>* reco_items) {
  if (reco_items->size() <= 1u) return;
  SplitItems(reco_items);
  MergeItems(reco_items);
  return;
}

void ShoppingRanker::SplitItems(std::vector<ItemInfo> * reco_items) {
  shouTao_items_.clear();
  shenMa_items_.clear();
  wemedia_items_.clear();
  for (int idx = 0; idx < (int)reco_items->size(); ++idx) {
    const ItemInfo& item = reco_items->at(idx);
    std::string source;
    news_index_->GetSourceByItemId(item.item_id, &source);
    if ((source.find("UC_百川_双12_tt") != std::string::npos)
        || (source.find("UC_百川_双12_buy") != std::string::npos)) {
      shouTao_items_.push_back(item);
    } else if (source.find("神马好东西_购物") != std::string::npos) {
      shenMa_items_.push_back(item);
    } else if (item.item_type == 24) {
      wemedia_items_.push_back(item);
    }
  }
  LOG(INFO) << "shopping channel split item "
            << "shoutao " << shouTao_items_.size()
            << "shenMa " << shenMa_items_.size()
            << "wemedia " << wemedia_items_.size();
}

void ShoppingRanker::MergeItems(std::vector<ItemInfo> * reco_items) {
  std::vector<ItemInfo> mid_items;
  int shouTao_idx = 0;
  int shenMa_idx = 0;
  int wemedia_idx = 0;

  int shouTao_quota = 4;
  int shenMa_quota = 1;
  int wemedia_quota = 3;

  bool shouTao_alive = true;
  bool shenMa_alive = true;
  bool wemedia_alive = true;

  std::vector<ItemInfo> one_page_items;
  // quota 传递: 优先级 手淘 > 神马 > 自媒体
  while(shouTao_idx < (int)shouTao_items_.size()
        || shenMa_idx < (int)shenMa_items_.size()
        || wemedia_idx < (int)wemedia_items_.size()) {
    int shouTao_num = 0;
    int shenMa_num = 0;
    int wemedia_num = 0;

    one_page_items.clear();

    while (shouTao_idx < (int)shouTao_items_.size()
           && shouTao_num < shouTao_quota) {
      one_page_items.push_back(shouTao_items_[shouTao_idx++]);
      shouTao_num++;
    }
    if (shouTao_alive
        && (shouTao_num < shouTao_quota)) {
      if (shenMa_alive) {
        shenMa_quota += shouTao_quota;
      } else {
        wemedia_quota += shouTao_quota;
      }
      shouTao_quota = 0;
      shouTao_alive = false;
    }
    while (shenMa_idx < (int)shenMa_items_.size()
           && shenMa_num < shenMa_quota) {
      one_page_items.push_back(shenMa_items_[shenMa_idx++]);
      shenMa_num++;
    }
    if (shenMa_alive
        && (shenMa_num < shenMa_quota)) {
      if (shouTao_alive) {
        shouTao_quota += shenMa_quota;
      } else {
        wemedia_quota += shenMa_quota;
      }
      shenMa_quota = 0;
      shenMa_alive = false;
    }
    while (wemedia_idx < (int)wemedia_items_.size()
           && wemedia_num < wemedia_quota) {
      one_page_items.push_back(wemedia_items_[wemedia_idx++]);
      wemedia_num++;
    }
    if (wemedia_alive
        && wemedia_num < wemedia_quota) {
      if (shouTao_alive) {
        shouTao_quota += wemedia_quota;
      } else {
        shenMa_quota += wemedia_quota;
      }
      wemedia_quota = 0;
      wemedia_alive = false;
    }
    std::sort(one_page_items.begin(), one_page_items.end(), std::greater<ItemInfo>());
    mid_items.insert(mid_items.end(), one_page_items.begin(), one_page_items.end());
  }
  reco_items->swap(mid_items);
}

void ShoppingRanker::PrintDebugInfo(const std::vector<ItemInfo>& items,
                                    const std::string& prefix, size_t max_print) const {
  std::string title;
  for (size_t i = 0; i < items.size() && i < max_print; ++i) {
    const ItemInfo& item = items.at(i);
    int image_num = news_index_->GetImageCountByDocId(item.doc_id);
    news_index_->GetItemTitleByDocId(item.doc_id, &title);
    LOG(INFO) << prefix << ", "
              << i << ", "
              << item.item_id << ", "
              << title
              << ", hot: "
              << item.hot_level
              << ", ctr: "
              << item.ctr
              << ", show: "
              << item.show_num
              << ", image num: "
              << image_num
              << ", category: "
              << item.category;
  }
}

} // namespace leaf_server
} // namespace reco
