#include "reco/serv/reco_leaf/strategy/component/ranker/hot_ranker.h"

#include <algorithm>
#include <unordered_map>
#include <functional>
#include <utility>

#include "boost/unordered_map.hpp"

#include "base/time/timestamp.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_tokenize.h"
#include "base/strings/string_printf.h"
#include "base/common/logging.h"
#include "base/math/discrete.h"
#include "base/random/pseudo_random.h"

#include "reco/bizc/common/item_level_define.h"
#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"


namespace reco {
namespace leafserver {
using reco::user::UserInfo;

DEFINE_bool(debug_hot_rank, false, "if debug hot rank");
DEFINE_int32(hot_span_hours, 2, "hot hours span 间隔");
DEFINE_double(hot_channel_hourspan_weight, 0.2, "hours span weight");
DEFINE_double(hot_channel_time_boost, 1, "hot_channel_time_boost");
DEFINE_double(hot_channel_ctr_boost, 1, "hot_channel_ctr_boost");
DEFINE_double(hot_channel_hot_boost, 1, "hot_channel_hot_boost");
DEFINE_double(hot_channel_cate_boost, 1, "hot_channel_cate_boost");
DEFINE_double(hot_channel_base_cate, 0.2, "hot_channel_base_cate");
DEFINE_double(hot_channel_base_ctr, 0.2, "hot_channel_base_ctr");
DEFINE_double(hot_super_thresh, 65, "hot_super_thresh");
DEFINE_double(hot_common_thresh, 10, "hot_common_thresh");
DEFINE_double(no_image_hot_thresh, 35, "no image hot thresh");
DEFINE_int32(no_image_expire_hours, 36, "no image hot thresh");
DEFINE_int32(top_hot_expire_hours, 18, "top_hot expire hours");
DEFINE_int32(common_hot_expire_hours, 72, "common_hot expire hours");
DEFINE_int32(each_screen_no_image_num, 2, "each screen no image num");
DEFINE_int32(hot_candidates_cutoff, 8000, "hot candidate cutoff");

DEFINE_string(vertical_channel_hot_thresh, "社会:50#国际:50#科技:50#财经:50#体育:50#娱乐:50#汽车:50#健康:50#美食:50#历史:50#干货:50#奇闻:50#星座:50#两性情感:50#美女写真:50#旅游:50","the channel thresh, split by # ,like 国际:30#科技:30"); // NOLINT

DEFINE_string(first_category_tuning, "房产:0.7#财经:0.7#健康:0.5#时尚:0.4", "first category tuning, split by # like 房产:0.7#财经:0.7"); // NOLINT
DEFINE_string(sub_category_tuning, "两性健康:0.6#股票:0.6#期货:0.6#贵金属:0.6#港股:0.6#美股:0.6#基金:0.6#家居:0.5#智能家居:0.6#风水:0.4", "sub category tuning, split by # like 股票:0.5#家居#0.5"); // NOLINT
DEFINE_int32(max_predict_num, 5000, "最大预估条数");


HotRanker::HotRanker(const reco::NewsIndex* index) {
  news_index_ = index;
  hot_predict_ = new HotPredict(news_index_);
  candidates_extractor_ = new CandidatesExtractor(news_index_);
  random_ = new base::PseudoRandom(base::GetTimestamp());
  item_dedup_.set_empty_key(0);
  InitChannelNameMap();
  InitChannelCategoryMap();
  InitChannelHotThresh();
  InitCategoryTuning();
}

void HotRanker::InitChannelNameMap() {
  channel_name_map_["推荐"] = 100;
  channel_name_map_["热门"] = 51830095;
  channel_name_map_["国际"] = 1001932710;
  channel_name_map_["社会"] = 1192652582;
  channel_name_map_["财经"] = 26325229;
  channel_name_map_["体育"] = 923258246;
  channel_name_map_["娱乐"] = 179223212;
  channel_name_map_["地方"] = 200;
  channel_name_map_["科技"] = 1525483516;
  channel_name_map_["汽车"] = 323644874;
  channel_name_map_["军事"] = 1105405272;
}

void HotRanker::InitChannelCategoryMap() {
  channelId_category_map_[100] = "推荐";
  channelId_category_map_[1001932710] = "国际";
  channelId_category_map_[1192652582] = "社会";
  channelId_category_map_[26325229] = "财经";
  channelId_category_map_[923258246] = "体育";
  channelId_category_map_[179223212] = "娱乐";
  channelId_category_map_[1525483516] = "科技";
  channelId_category_map_[323644874] = "汽车";
  channelId_category_map_[1105405272] = "军事";
}

void HotRanker::InitChannelHotThresh() {
  std::vector<std::string> channel_thresh_vec;
  base::SplitString(FLAGS_vertical_channel_hot_thresh, "#" , &channel_thresh_vec);
  std::vector<std::string> key_value;
  for (int i = 0; i < (int)channel_thresh_vec.size(); ++i) {
    key_value.clear();
    base::SplitString(channel_thresh_vec[i], ":", &key_value);
    if ((int)key_value.size() != 2) continue;
    double thresh = kDefaultThresh;
    const std::string& name = key_value[0];
    auto iter = channel_name_map_.find(name);
    if (iter == channel_name_map_.end()) continue;
    int64 id = iter->second;
    if (!base::StringToDouble(key_value[1], &thresh)) {
      LOG(ERROR)<< "channel: thresh "<< name << "error";
      continue;
    }
    channel_hot_thresh_[id] = thresh;
  }
}

void HotRanker::InitCategoryTuning() {
  std::vector<std::string> first_category_tuning_vec;
  base::SplitString(FLAGS_first_category_tuning, "#" , &first_category_tuning_vec);
  std::vector<std::string> sub_category_tuning_vec;
  base::SplitString(FLAGS_sub_category_tuning, "#" , &sub_category_tuning_vec);

  std::vector<std::string> key_value;
  for (size_t i = 0; i < first_category_tuning_vec.size(); ++i) {
    key_value.clear();
    base::SplitString(first_category_tuning_vec[i], ":", &key_value);
    if (key_value.size() != 2u) continue;
    const std::string& category = key_value[0];
    double tuning = 1;
    if (!base::StringToDouble(key_value[1], &tuning)) {
      LOG(ERROR) << "hot rank: first category tuning: " << category << "load error!";
      continue;
    }
    first_category_tuning_map_[category] = tuning;
  }

  for (size_t i = 0; i < sub_category_tuning_vec.size(); ++i) {
    key_value.clear();
    base::SplitString(sub_category_tuning_vec[i], ":", &key_value);
    if (key_value.size() != 2u) continue;
    const std::string& sub_category = key_value[0];
    double tuning = 1;
    if (!base::StringToDouble(key_value[1], &tuning)) {
      LOG(ERROR) << "hot rank: second category tuning: " << sub_category << "load error!";
      continue;
    }
    sub_category_tuning_map_[sub_category] = tuning;
  }
}

HotRanker::~HotRanker() {
  delete candidates_extractor_;
  delete random_;
}

int HotRanker::GetChannelPrevReqHours(const UserInfo* user_info,
                                      const base::Time& current_time,
                                      int64 channel_id) {
  int last_req_hours = 8;
  base::Time expire_time = current_time - base::TimeDelta::FromHours(12);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  for (int i = user_info->shown_history_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& show_item = user_info->shown_history(i);
    if (show_item.view_timestamp() < expire_timestamp) break;
    if (show_item.has_channel_id() && show_item.channel_id() == channel_id) {
      base::Time req_time = base::Time::FromDoubleT((double)show_item.view_timestamp() / 1e6);
      last_req_hours = (current_time - req_time).InHours();
      break;
    }
  }
  return last_req_hours;
}

bool HotRanker::MeetTopHotTime(const ItemInfo& item, const base::Time& reco_time) const {
  if (item.time_level < reco::kGoodTimeliness) return false;
  // 小于给定时间
  const base::Time& news_time = base::Time::FromDoubleT((double)item.create_timestamp / 1e6);
  if ((reco_time - news_time).InHours() <= FLAGS_top_hot_expire_hours) return true;
  // 同一天也是
  if (FLAGS_top_hot_expire_hours < 24
      && (reco_time - news_time).InHours() < 24
      && RecoUtils::IsSameDay(news_time, reco_time)) {
    return true;
  }
  return false;
}

bool HotRanker::MeetCommonHotTime(const ItemInfo& item, const base::Time& reco_time) const {
  if (item.time_level >= reco::kMidTimeliness) return true;
  const base::Time& news_time = base::Time::FromDoubleT((double)item.create_timestamp / 1e6);

  // 无图额外时间限制
  if (IfNoImage(item) && ((reco_time - news_time).InHours() >= FLAGS_no_image_expire_hours)) return false;
  if ((reco_time - news_time).InHours() <= FLAGS_common_hot_expire_hours) return true;
  return false;
}

bool HotRanker::MeetComplexHotTime(const ItemInfo& item,
                                   const base::Time& reco_time) const {
  if (item.time_level < reco::kGoodTimeliness) return false;
  // 小于给定时间
  const base::Time& news_time = base::Time::FromDoubleT((double)item.create_timestamp / 1e6);
  if ((reco_time - news_time).InHours() <= 12
      && RecoUtils::IsSameDay(news_time, reco_time)) {
    return true;
  }
  return false;
}

void HotRanker::RankTopHotItems(const RecoRequest* reco_request,
                                std::vector<ItemInfo>* hot_items) {
  if (hot_items->size() <= 1u) return;

  std::vector<std::pair<int, int> > score_idx_vec(hot_items->size());

  for (size_t idx = 0; idx < hot_items->size(); ++idx) {
    const ItemInfo& item = hot_items->at(idx);
    const base::Time& news_time = base::Time::FromDoubleT((double)item.create_timestamp / 1e6);
    int hour = (reco_request->current_time - news_time).InHours();
    float time_ratio = 1;
    if (hour <= 6) {
      time_ratio = 1 - hour * 0.025;
    } else {
      time_ratio = 0.8;
    }

    double category_boost = 1;
    double sub_category_boost = 1;
    auto const iter = first_category_tuning_map_.find(item.category);
    if (iter != first_category_tuning_map_.end())
      category_boost = iter->second;

    auto const sub_iter = sub_category_tuning_map_.find(item.sub_category);
    if (sub_iter != sub_category_tuning_map_.end())
      sub_category_boost = sub_iter->second;
    // 无图降权微调
    double no_image_boost = 1;
    if (IfNoImage(item)) no_image_boost = 0.9;
    int score = item.hot_level * time_ratio * category_boost * sub_category_boost * no_image_boost;
    score_idx_vec[idx].first = score;
    score_idx_vec[idx].second = idx;
  }
  std::sort(score_idx_vec.begin(), score_idx_vec.end(), std::greater<std::pair<int, int> >());

  std::vector<ItemInfo> swap_items;
  for (size_t i = 0; i < score_idx_vec.size(); ++i) {
    int idx = score_idx_vec[i].second;
    swap_items.push_back(hot_items->at(idx));
  }

  hot_items->swap(swap_items);
}

void HotRanker::RankCommonHotItemsBaseModel(const RecoRequest* reco_request,
                                            std::vector<ItemInfo>* common_items) {
  if (common_items->size() <= 1u) return;
  std::vector<std::pair<float, int32> > score_idx_vec(common_items->size());
  UserFea user_fea;
  hot_predict_->SetUserFea(reco_request, user_fea);
  reco::xgboost::RegTree::FVec fvec_temp = reco::xgboost::RegTree::FVec();
  int32 predict_limit = FLAGS_max_predict_num;
  if (reco_request->channel_id == reco::common::kHotChannelId)
  for (size_t idx = 0; idx < common_items->size() && int32(idx) <= predict_limit; ++idx) {
    const ItemInfo& item = common_items->at(idx);
    float hot_model_score = hot_predict_->DoPredict(user_fea, item, fvec_temp);
    score_idx_vec[idx].first = hot_model_score;
    score_idx_vec[idx].second = idx;
  }
  std::sort(score_idx_vec.begin(), score_idx_vec.end(), std::greater<std::pair<float, int> >());

  std::vector<ItemInfo> swap_items;
  for (size_t i = 0; i < score_idx_vec.size(); ++i) {
    int idx = score_idx_vec[i].second;
    swap_items.push_back(common_items->at(idx));
  }
  common_items->swap(swap_items);
}

void HotRanker::GetTopCommonHot(const RecoRequest* reco_request,
                                const std::vector<ItemInfo>& reco_items,
                                  std::vector<ItemInfo>* top_hot_items) {
  top_hot_items->clear();

  // top hot item
  // 1. hot_score 高的文章
  // 2. 时效性满足
  for (size_t idx = 0; idx < reco_items.size(); ++idx) {
    const ItemInfo& item = reco_items[idx];
    if (item.hot_level < FLAGS_hot_super_thresh) continue;
    if (!MeetTopHotTime(item, reco_request->current_time)) continue;
    top_hot_items->push_back(item);
  }
}

void HotRanker::SplitTopCommonHot(const RecoRequest* reco_request,
                                  const std::vector<ItemInfo>& reco_items,
                                  std::vector<ItemInfo>* top_hot_items,
                                  std::vector<ItemInfo>* common_hot_items) {
  top_hot_items->clear();
  common_hot_items->clear();

  // top hot item
  // 1. hot_score 高的文章
  // 2. 时效性满足
  for (size_t idx = 0; idx < reco_items.size(); ++idx) {
    const ItemInfo& item = reco_items[idx];
    if (item.hot_level < FLAGS_hot_super_thresh) continue;
    if (!MeetTopHotTime(item, reco_request->current_time)) continue;
    top_hot_items->push_back(item);
  }

  // common hot item
  // 1. hot 和 时效性都满足一定条件的文章
  for (size_t idx = 0; idx < reco_items.size(); ++idx) {
    const ItemInfo& item = reco_items[idx];
    if (item.hot_level < FLAGS_hot_common_thresh) continue;
    if (!MeetCommonHotTime(item, reco_request->current_time)) continue;
    common_hot_items->push_back(item);
  }
}

bool HotRanker::DedupByKeywords(const reco::FeatureVector& keywords, int32 each_screen_item_num,
                                const std::unordered_map<std::string, int32>& keywords_appear_dict) const {
  int32 same_keyword_num = 0;
  bool is_filter_by_keywords = false;
  for (int32 i = 0; i < keywords.feature_size(); ++i) {
    auto keywords_iter = keywords_appear_dict.find(keywords.feature(i).literal());
    if (keywords_iter != keywords_appear_dict.end()) {
      if (keywords_iter->second > each_screen_item_num / 2) {
        is_filter_by_keywords = true;
        break;
      }
      ++same_keyword_num;
      if (same_keyword_num >= 3) {
        is_filter_by_keywords = true;
        break;
      }
    }
  }
  return is_filter_by_keywords;
}

void HotRanker::MergeTopCommonHot(const RecoRequest* reco_request,
                                  const std::vector<ItemInfo>& top_hot_items,
                                  const std::vector<ItemInfo>& common_hot_items,
                                  std::vector<ItemInfo>* final_hot_items) {
  final_hot_items->clear();
  item_dedup_.clear();
  int each_screen_item_num = reco_request->request->return_num();
  if (each_screen_item_num == 0) {
    return;
  }

  size_t top_hot_idx = 0;
  size_t common_hot_idx = 0;
  int add_no_image_num = 0;
  std::unordered_map<std::string, int32> keywords_appear_dict;
  reco::FeatureVector keywords;
  while (top_hot_idx < top_hot_items.size()
         || common_hot_idx < common_hot_items.size()) {
    int add_num = 0;
    while (top_hot_idx < top_hot_items.size()) {
      if (add_num >= 5) break;
      const ItemInfo& item = top_hot_items[top_hot_idx];
      if (IfNoImage(item) && add_no_image_num >= 2) {
        ++top_hot_idx;
        continue;
      }
      if (!NewsFilter::IsDeduped(item, &item_dedup_)) {
        // 同一屏 keyword 相同超过3个的最多出2条 某个 keyword 最多出现 1/2 屏
        if (!news_index_->GetFeatureVectorByItemId(item.item_id, reco::common::kKeyword, &keywords)) {
          continue;
        }
        if (DedupByKeywords(keywords, each_screen_item_num, keywords_appear_dict)) continue;
        for (int32 i = 0; i < keywords.feature_size(); ++i) {
          auto keywords_iter = keywords_appear_dict.find(keywords.feature(i).literal());
          if (keywords_iter == keywords_appear_dict.end()) {
            keywords_iter = keywords_appear_dict.insert(std::make_pair(keywords.feature(i).literal(), 0)).first;
          }
          ++(keywords_iter->second);
        }

        final_hot_items->push_back(item);
        ++add_num;
        if (IfNoImage(item)) ++add_no_image_num;
        if (final_hot_items->size() % each_screen_item_num == 0) {
          add_no_image_num = 0;
          keywords_appear_dict.clear();
        }
      }
      ++top_hot_idx;
    }

    add_num = 0;
    while (common_hot_idx < common_hot_items.size()) {
      if (add_num >= 1) break;
      if (top_hot_idx < top_hot_items.size() && common_hot_items[common_hot_idx].hot_level < 25) {
        ++common_hot_idx;
        continue;
      }
      // common 队列低分无图 hot 过滤
      const ItemInfo& item = common_hot_items[common_hot_idx];
      if (IfNoImage(item)
          && (item.hot_level < FLAGS_no_image_hot_thresh
              || add_no_image_num >= 1)) {
          ++common_hot_idx;
          continue;
      }

      if (!NewsFilter::IsDeduped(item, &item_dedup_)) {
        if (!news_index_->GetFeatureVectorByItemId(item.item_id, reco::common::kKeyword, &keywords)) {
          continue;
        }
        if (DedupByKeywords(keywords, each_screen_item_num, keywords_appear_dict)) continue;
        for (int32 i = 0; i < keywords.feature_size(); ++i) {
          auto keywords_iter = keywords_appear_dict.find(keywords.feature(i).literal());
          if (keywords_iter == keywords_appear_dict.end()) {
            keywords_iter = keywords_appear_dict.insert(std::make_pair(keywords.feature(i).literal(), 0)).first;
          }
          ++(keywords_iter->second);
        }
        final_hot_items->push_back(item);
        ++add_num;
        if (IfNoImage(item)) ++add_no_image_num;
        if (final_hot_items->size() % each_screen_item_num == 0) {
          add_no_image_num = 0;
          keywords_appear_dict.clear();
        }
      }
      ++common_hot_idx;
    }
  }
  // 首条无图控制, 与第一条有图 swap
  if (!final_hot_items->empty() && IfNoImage(final_hot_items->at(0))) {
    for (size_t idx = 1; idx < final_hot_items->size(); ++idx) {
      ItemInfo& item = final_hot_items->at(idx);
      if (!IfNoImage(item)) {
        std::swap(final_hot_items->at(0), item);
        break;
      }
    }
  }
}

void HotRanker::Rank(const RecoRequest* reco_request, std::vector<ItemInfo>* reco_items) {
  if (static_cast<int>(reco_items->size()) == 0) return;
  std::vector<ItemInfo> top_hot_items;
  std::vector<ItemInfo> common_hot_items;

  // splist and scorer
  SplitTopCommonHot(reco_request, *reco_items, &top_hot_items, &common_hot_items);

  // debug switch, online shut down
  LOG_IF(INFO, FLAGS_debug_hot_rank) << "DEBUG_HOT_RANK, SPLIT, TOP: "
                                     << top_hot_items.size()
                                     << ", COMMON: "
                                     << common_hot_items.size()
                                     << ", TOTAL: "
                                     << reco_items->size();

  // 各类 hot 单独排序
  RankTopHotItems(reco_request, &top_hot_items);
  RankCommonHotItemsBaseModel(reco_request, &common_hot_items);

  // merge 各路 hot 数据
  MergeTopCommonHot(reco_request, top_hot_items, common_hot_items, reco_items);

  if (FLAGS_debug_hot_rank) {
    PrintDebugInfo(top_hot_items, "top hot item", 100);
    PrintDebugInfo(common_hot_items, "common hot item", 100);
    PrintDebugInfo(*reco_items, "total hot item", 100);
  }
}

void HotRanker::RankForComplex(const RecoRequest* reco_request,
                               std::vector<ItemInfo>* reco_items,
                               int return_num) {
  double thresh = kDefaultThresh;
  auto iter = channel_hot_thresh_.find(reco::common::kRecoChannelId);
  if (iter != channel_hot_thresh_.end()) {
    thresh = iter->second;
  }
  std::vector<ItemInfo> top_hot_items;

  // 推荐频道只出高热
  GetTopCommonHot(reco_request, *reco_items, &top_hot_items);

  RankTopHotItems(reco_request, &top_hot_items);

  reco_items->swap(top_hot_items);

  int return_size = static_cast<int>(reco_items->size());
  if (return_size > return_num) {
    reco_items->resize(return_size);
  }
}

void HotRanker::RankForVertical(const RecoRequest* reco_request,
                                std::vector<ItemInfo>* return_items,
                                int return_num,
                                RecoContext* context) {
  std::vector<ItemInfo> candidate_items;
  return_items->clear();
  auto const category_iter = channelId_category_map_.find(reco_request->channel_id);
  if (category_iter == channelId_category_map_.end()) return;

  candidates_extractor_->GetCandidatesByChannelId(reco::common::kHotChannelId,
                                                  reco_request,
                                                  &candidate_items,
                                                  FLAGS_hot_candidates_cutoff,
                                                  context->debugger());

  const std::string& first_category = category_iter->second;
  for (size_t i = 0; i < candidate_items.size(); ++i) {
    const ItemInfo& item = candidate_items[i];
    if (item.category == first_category) {
      return_items->push_back(item);
    }
  }

  Rank(reco_request, return_items);
  double limit_thresh = kDefaultThresh;
  auto const thresh_iter = channel_hot_thresh_.find(reco_request->channel_id);
  if (thresh_iter != channel_hot_thresh_.end()) {
    limit_thresh = thresh_iter->second;
  }

  // 出口热点候选控制，一些过滤逻辑
  OuterHotControl(reco_request->channel_id, return_items, return_num, limit_thresh);
  if (FLAGS_debug_hot_rank) {
    PrintDebugInfo(*return_items, first_category, 200);
  }
}

void HotRanker::OuterHotControl(const int64 channel_id,
                                std::vector<ItemInfo>* return_items,
                                int limit_num,
                                double limit_thresh) {
  std::vector<ItemInfo> swap_items;
  for (size_t i = 0; i < return_items->size(); ++i) {
    ItemInfo& item = return_items->at(i);

    // 垂直频道不下发无图热点，财经频道豁免
    if (IfNoImage(item) && channel_id != reco::common::kFinanceChannelId) continue;
    if (item.hot_level < limit_thresh) continue;
    swap_items.push_back(item);
    item.strategy_type = reco::kHot;
    if ((int)swap_items.size() == limit_num) break;
  }
  return_items->swap(swap_items);
}

void HotRanker::PrintDebugInfo(const std::vector<ItemInfo>& items,
                               const std::string& prefix, size_t max_print) const {
  std::string title;
  for (size_t i = 0; i < items.size() && i < max_print; ++i) {
    const ItemInfo& item = items.at(i);
    int image_num = news_index_->GetImageCountByDocId(item.doc_id);
    news_index_->GetItemTitleByDocId(item.doc_id, &title);
    LOG(INFO) << prefix << ", "
              << i << ", "
              << item.item_id << ", "
              << title
              << ", hot: "
              << item.hot_level
              << ", ctr: "
              << item.ctr
              << ", show: "
              << item.show_num
              << ", image num: "
              << image_num;
  }
}
}
}
