#pragma once
#include <string>
#include <vector>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "base/time/time.h"

namespace reco {
class NewsIndex;
class RecoRequest;
class UserFeature;
class UserInfo;

namespace leafserver {
class RankModel;
struct ItemDictData;

class NewsRanker {
 public:
  explicit NewsRanker(const reco::NewsIndex* index);
  ~NewsRanker();

  void Rank(const std::string& category,
            const RecoRequest* reco_request,
            const std::vector<ItemInfo>& ir_items,
            std::vector<ItemInfo>* reco_items,
            RecoDebugger* debugger);

  void SetEnv(const reco::reco_model::UserFeature* user_feature) {
              /*
              const std::vector<base::dense_hash_map<uint64, reco::reco_model::ModelNode>*>* ugm_model,
              const std::vector<std::pair<std::string, float> >* remain_prefix = NULL) {
              */
    user_feature_ = user_feature;
    // ugm_model_ = ugm_model;
    // remain_prefix_ = remain_prefix;
  }
  void SetPersonalItemDicts(const std::unordered_map<uint64, ItemDictData>* personal_item_dicts) {
    personal_item_dicts_ = personal_item_dicts;
  }

 private:
  // uint32 DecideMaxRankItemNum() const;
  bool IfDoImageTune(const std::string& category) const;
  int DecideMaxRegionTuneItemNum(const std::string& category) const;


  void GenerateReturnItems(const std::string& category, std::vector<ItemInfo>* reco_items);

  //////////////////// 各种调权策略
  // 二级类别调权参数
  void GenSubCateTuneParam(const std::string& category, std::string* map_category,
                           const FeaKeyVal** user_sub_cates, float* boost_pow);
  // 二级类别调权策略
  float TuneByUserSubCate(const reco::ItemInfo& item, double org_reco_score,
                          const std::string& req_category, const FeaKeyVal* l2_cates,
                          float l2_boost_pow) const;
  // 用户属性调权
  float TuneByUserAttr(const reco::ItemInfo& item, double org_reco_score) const;
  // 时效性调权
  float TuneByItemTime(const reco::ItemInfo& item, double org_reco_score) const;
  // itemq 调权
  float TuneByItemQuality(const reco::ItemInfo& item, double org_reco_score) const;
  // 地域调权
  float TuneByRegion(const reco::ItemInfo& item, double org_reco_score) const;
  // 图片调权
  float TuneByImageNum(const reco::ItemInfo& item, double org_reco_score) const;
  // 本地频道个性化调权
  float LocalChannelPersonalTune(const reco::ItemInfo& item, double org_reco_score) const;
  // 生命周期
  float TuneByLifeStageTag(const reco::ItemInfo& item, double org_reco_score) const;
  // 类目分数调权
  float TuneByCategoryScore(const reco::ItemInfo& item, double org_reco_score) const;
  // cf 调权
  float TuneByCFDict(const std::unordered_map<uint64, ItemDictData>* personal_item_dicts,
                     const reco::ItemInfo& item, double org_reco_score, int* cf_cover_count) const;
  float TuneByUserQuality(const reco::ItemInfo& item, double org_reco_score) const;

  void PrintItems(const std::vector<ItemInfo>& items) const;

 private:
  static const uint32 kPersonalTraverseCutoff = 4000;
  static const int kPredictItemShowThres = 1200;
  static const int kRecoScoreFactor = 1000000;
  static const int kImageTuneMaxItem = 200;
  static const uint32 kMaxReturn = 1000;

  const reco::NewsIndex* news_index_;
  const RecoRequest* reco_request_;

  const reco::reco_model::UserFeature* user_feature_;
  // const std::vector<base::dense_hash_map<uint64, reco::reco_model::ModelNode>*>* ugm_model_;
  // const std::vector<std::pair<std::string, float> >* remain_prefix_;
  const std::unordered_map<uint64, ItemDictData>* personal_item_dicts_;

  base::PseudoRandom* random_;
  RankModel* rank_model_;
};

}
}
