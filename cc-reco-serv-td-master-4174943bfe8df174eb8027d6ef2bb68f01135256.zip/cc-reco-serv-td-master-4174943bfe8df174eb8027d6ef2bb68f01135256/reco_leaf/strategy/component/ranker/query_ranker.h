#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/random/pseudo_random.h"

#include "reco/serv/reco_leaf/strategy/component/scorer/wd_predictor.h"

namespace reco {
class RecoRequest;
class UserFeature;

namespace user {
class UserInfo;
}

namespace leafserver {

class RecommendRequest;
class CandidatesExtractor;

class QueryRanker {
 public:
  explicit QueryRanker(const reco::NewsIndex* index);
  ~QueryRanker();
  void Rank(const RecoRequest* reco_request, std::vector<ItemInfo>* reco_items);
 private:
  void GetWDScore(const RecoRequest* reco_request, std::vector<ItemInfo>* reco_items);
  void TunerByRecentQuery(const RecoRequest* reco_request,
                          std::vector<ItemInfo>* reco_items);
 private:
  const NewsIndex* news_index_;
  // wd model
  WDPredictor* wd_predictor_;
};

}  // namespace leafserver
}  // namespace reco
