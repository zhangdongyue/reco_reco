#include "reco/serv/reco_leaf/strategy/component/ranker/pic_ranker.h"

#include <algorithm>
#include <unordered_map>
#include <functional>
#include <utility>

#include "boost/unordered_map.hpp"

#include "base/time/timestamp.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_tokenize.h"
#include "base/strings/string_printf.h"
#include "base/common/logging.h"
#include "base/math/discrete.h"

#include "reco/bizc/common/item_level_define.h"
#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"


namespace reco {
namespace leafserver {

DEFINE_bool(debug_pic_rank, false, "if debug pic rank");
DEFINE_double(pic_channel_ctr_boost, 1, "pic_channel_ctr_boost");
DEFINE_double(pic_channel_hot_boost, 0, "pic_channel_hot_boost");
DEFINE_double(pic_channel_cate_boost, 1, "pic_channel_cate_boost");
DEFINE_double(pic_channel_base_ctr, 0.2, "pic_channel_base_ctr");
DEFINE_double(pic_channel_base_hot, 100, "pic_channel_base_hot");
DEFINE_double(pic_channel_base_cate, 0.2, "pic_channel_base_cate");
DEFINE_double(pic_reco_score_boost, 1, "pic_reco_score_boost");

PicRanker::PicRanker(const reco::NewsIndex* index) {
  news_index_ = index;
  item_dedup_.set_empty_key(0);
}

PicRanker::~PicRanker() {
}

void PicRanker::Rank(const RecoRequest* reco_request,
                     std::vector<ItemInfo>* pic_items) {
  if (pic_items->size() <= 1u) return;
  std::vector<std::pair<int, int> > score_idx_vec(pic_items->size());
  auto const& ref_l1_cates = reco_request->user_feas->merged_fea.l1_cates;
  int l1_cate_num = (int)(ref_l1_cates.size());
  for (size_t idx = 0; idx < pic_items->size(); ++idx) {
    const ItemInfo& item = pic_items->at(idx);
    // hot score
    double hot_level_score = FLAGS_pic_channel_base_hot;
    hot_level_score= pow(hot_level_score + item.hot_level, FLAGS_pic_channel_hot_boost);

    // category score
    double cate_level_score = FLAGS_pic_channel_base_cate;
    double l1_cate = 0;
    if (l1_cate_num > 0) {
      auto cate_iter = ref_l1_cates.find(item.category);
      if (cate_iter != ref_l1_cates.end()) {
         l1_cate = cate_iter->second;
      }
    }
    cate_level_score = pow(cate_level_score + l1_cate, FLAGS_pic_channel_cate_boost);

    // ctr score
    double ctr_level_score = FLAGS_pic_channel_base_ctr;
    ctr_level_score = pow(ctr_level_score + item.ctr, FLAGS_pic_channel_ctr_boost);

    // add score
    double score = hot_level_score * cate_level_score * ctr_level_score *
        pow(item.reco_score, FLAGS_pic_reco_score_boost);

    score_idx_vec[idx].first = score;
    score_idx_vec[idx].second = idx;
  }
  std::sort(score_idx_vec.begin(), score_idx_vec.end(), std::greater<std::pair<int, int> >());
  std::vector<ItemInfo> swap_items;
  item_dedup_.clear();
  for (size_t i = 0; i < score_idx_vec.size(); ++i) {
    int idx = score_idx_vec[i].second;
    if (NewsFilter::IsDeduped(pic_items->at(idx), &item_dedup_)) continue;
    swap_items.push_back(pic_items->at(idx));
  }
  pic_items->swap(swap_items);
  if (FLAGS_debug_pic_rank) {
    PrintDebugInfo(*pic_items, "pic item", 100);
  }
}

void PicRanker::PrintDebugInfo(const std::vector<ItemInfo>& items,
                               const std::string& prefix, size_t max_print) const {
  std::string title;
  for (size_t i = 0; i < items.size() && i < max_print; ++i) {
    const ItemInfo& item = items.at(i);
    int image_num = news_index_->GetImageCountByDocId(item.doc_id);
    news_index_->GetItemTitleByDocId(item.doc_id, &title);
    LOG(INFO) << prefix << ", "
              << i << ", "
              << item.item_id << ", "
              << title
              << ", hot: "
              << item.hot_level
              << ", ctr: "
              << item.ctr
              << ", show: "
              << item.show_num
              << ", image num: "
              << image_num
              << ", category: "
              << item.category;
  }
}
}   // namespace leaf_server
}   // namespace reco
