#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>

#include "base/time/time.h"
#include "reco/bizc/reco_index/item_info.h"

namespace adsindexing {
class Index;
}

namespace base {
class PseudoRandom;
}
namespace reco_model {
class RecoModel;
}

namespace reco {
class NewsIndex;

namespace leafserver {
class RecoRequest;
class ItemDictManager;
class JingpinRanker {
 public:
  explicit JingpinRanker(const reco::NewsIndex* index);
  ~JingpinRanker();

  void Rank(const std::string& category,
            const RecoRequest& reco_request,
            const std::vector<ItemInfo>& ir_items,
            std::vector<ItemInfo>* reco_items);

 private:
  static const uint32 kMaxReturn = 500;
  static const int kRecoScoreFactor = 1000000;
};

}  // namespace leafserver
}  // namespace reco
