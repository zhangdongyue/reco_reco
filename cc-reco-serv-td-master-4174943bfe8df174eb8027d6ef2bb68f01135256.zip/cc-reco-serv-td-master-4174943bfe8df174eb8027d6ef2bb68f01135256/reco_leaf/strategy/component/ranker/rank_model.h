#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "base/time/time.h"

namespace reco {

namespace leafserver {
class LRPredictor;
class MFPredictor;
class UGMPredictor;
class FMPredictor;
class FacMachinePredictor;
class WDPredictor;
struct ItemDictData;

// model data
struct ModelData {
  uint64 item_id;
  float lr_score;
  float mf_score;
  float fm_score;
  float ugm_score;
  float personal_lr_score;
  float wd_text_score;

  ModelData() : lr_score(0), mf_score(0), fm_score(0), ugm_score(0), personal_lr_score(0), wd_text_score(0) {}
};

struct ModelExtraInfo {
  float avg_fm;
  float avg_fm_punish;
  float avg_mf;
  float mf_weight_hit;
  float mf_enhance;
  float avg_wd;
  float avg_wd_punish;
  ModelExtraInfo() : avg_fm(0), avg_fm_punish(0), avg_mf(0), mf_weight_hit(0), mf_enhance(0),
                     avg_wd(0), avg_wd_punish(0) {}
};

// 封装排序相关的 model, 与排序规则区分开来
//
class RankModel {
 public:
  explicit RankModel(const reco::NewsIndex* index);
  ~RankModel();

  // 预估对外接口
  void BatchPredict(const std::string& category, const std::vector<ItemInfo>& items,
                    std::vector<ModelData>* model_vec, ModelExtraInfo* extra_info);

  // 相关参数设定
  void SetEnv(const RecoRequest* reco_request,
              const reco::reco_model::UserFeature* model_user_feature) {
              /*
              const std::vector<base::dense_hash_map<uint64, reco::reco_model::ModelNode>*>* ugm_model,
              const std::vector<std::pair<std::string, float> >* ugm_remain_prefix) {
              */
    model_user_feature_ = model_user_feature;
    reco_request_ = reco_request;
    // ugm_model_ = ugm_model;
    // ugm_remain_prefix_ = ugm_remain_prefix;
  }

 private:
  /*
  // lr predict
  void CalcLrScores(const std::string& category, const std::vector<ItemInfo>& items,
                    std::vector<ModelData>* model_vec, ModelExtraInfo* extra_info);
  // mf predict
  void CalcMfScores(const std::string& category, const std::vector<ItemInfo>& items,
                    std::vector<ModelData>* model_vec, ModelExtraInfo* extra_info);
  // fm predict
  void CalcFmScores(const std::string& category, const std::vector<ItemInfo>& items,
                    std::vector<ModelData>* model_vec, ModelExtraInfo* extra_info);
  // ugm predict
  void CalcUgmScores(const std::string& category, const std::vector<ItemInfo>& items,
                     std::vector<ModelData>* model_vec, ModelExtraInfo* extra_info);
  */

  // personal lr predict
  /*
  void CalcPersonalLrScores(const std::string& category, const std::vector<ItemInfo>& items,
                            std::vector<ModelData>* model_vec, ModelExtraInfo* extra_info);
  */

  // wd predict
  void CalcWDScores(const std::string& category, const std::vector<ItemInfo>& items,
                    std::vector<ModelData>* model_vec, ModelExtraInfo* extra_info);
 private:
  /*
  ///// personal lr related
  // 选取 lr 预估队列
  void DecideLrPredictQueue(const std::vector<ItemInfo>& items,
                            std::vector<ItemInfo>* predict_items, int max_num) const;
  // 计算 lr 预估条数
  int JudgeLrPredictNum(const std::string& category) const;
  */

  ///// ugm model realted
  // 从 LR dawg 模型获取特征对应的值
  void GetFeatureScore(const dawgdic::Dictionary* model, const std::vector<double>* weight,
                       const dawgdic::BaseType index, const char* tag, double* score);

  ///// mf related
  // 初始化 MF 参数
  /*
  bool InitMFParameter();
  bool CheckMfItemExist(uint64 item_id, const std::string& user_cluster) const;
  void DecideMfPredictQueue(const std::vector<ItemInfo>& items,
                            const std::string &icate_mf,
                            const std::string &user_cluster,
                            float user_confidence_mf,
                            std::vector<ItemInfo>* mf_items) const;

  ///// fm related
  bool CheckFmItemExist(uint64 item_id) const;
  void DecideFmPredictQueue(const std::vector<ItemInfo>& items,
                            const std::string &icate_fm,
                            bool user_confidence_fm,
                            std::vector<ItemInfo>* fm_items) const;
  */

  // personal lr
  // int CalcPersonalLrPredictNum(const std::string& category) const;

  void DecideWDPredictQueue(const std::string& cate, const std::vector<ItemInfo>& items,
                            std::vector<ItemInfo>* wd_items, float tune) const;

 private:
  static const int kRecoScoreFactor = 1000000;
  static const int kPersonalTraverseCutoff = 5000;

  const reco::NewsIndex* news_index_;
  const RecoRequest* reco_request_;
  const reco::reco_model::UserFeature* model_user_feature_;

  base::PseudoRandom* random_;

  ////// predictor
  /*
  // mf
  MFPredictor* mf_predictor_;
  // fm
  FacMachinePredictor* fm_predictor_;
  // lr
  LRPredictor* lr_predictor_;
  // ugm lr
  UGMPredictor* ugm_predictor_;
  */
  // wd model
  WDPredictor* wd_predictor_;

  ////// mid data
  // const std::vector<base::dense_hash_map<uint64, reco::reco_model::ModelNode>*>* ugm_model_;
  // const std::vector<std::pair<std::string, float> >* ugm_remain_prefix_;

  std::unordered_map<std::string, double> icate_showdiscount_;
  std::unordered_map<std::string, double> icate_mfenhance_;
  std::unordered_map<std::string, double> icate_minpostctr_;
  std::unordered_map<std::string, double> icate_avg_discount_;
  std::unordered_map<std::string, double> icate_mid_timelevel_boost_;
  std::unordered_map<std::string, double> fac_machine_ctr_high_;
  std::unordered_map<std::string, double> fac_machine_ctr_low_;
  std::unordered_map<std::string, double> fac_machine_predict_level_;
};

inline void RankModel::GetFeatureScore(const dawgdic::Dictionary* model, const std::vector<double>* weight,
                                       const dawgdic::BaseType index, const char* tag, double* score) {
  dawgdic::BaseType ind = index;
  model->Follow(tag, &ind);
  if (model->has_value(ind)) {
    int id = model->value(ind);
    if (id >= 0 && id < (int)weight->size()) {
      *score = weight->at(id);
    } else {
      LOG(ERROR) << "model has problem";
    }
  }
}

}
}
