#include "reco/serv/reco_leaf/strategy/component/ranker/query_ranker.h"

#include <algorithm>
#include <unordered_map>
#include <functional>
#include <utility>

#include "boost/unordered_map.hpp"

#include "base/time/timestamp.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_tokenize.h"
#include "base/strings/string_printf.h"
#include "base/common/logging.h"
#include "base/math/discrete.h"
#include "base/random/pseudo_random.h"

#include "reco/bizc/common/item_level_define.h"
#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"

DEFINE_bool(open_query_reco_wd_model, false, "开始query reco的推荐");

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

QueryRanker::QueryRanker(const reco::NewsIndex* index) {
  news_index_ = index;
  wd_predictor_ = NULL;
  if (FLAGS_open_query_reco_wd_model) {
    wd_predictor_ = new WDPredictor(news_index_);
  }
}

QueryRanker::~QueryRanker() {
  if (wd_predictor_ != NULL) {
    delete wd_predictor_;
  }
}

bool QueryCmp(const std::pair<float, int32>& first, const std::pair<float, int32>& second) {
  if (std::fabs(first.first - second.first) < 1e-4) {
    return first.second < second.second;
  } else {
    return first.first > second.first;
  }
}

void QueryRanker::Rank(const RecoRequest* reco_request, std::vector<ItemInfo>* reco_items) {
  if (static_cast<int>(reco_items->size()) == 0) return;
  std::vector<std::pair<float, int32> > index_score;
  // Init Score
  for (size_t i = 0; i < reco_items->size(); ++i) {
    reco_items->at(i).wd_text_score = 0;
    reco_items->at(i).reco_score = 1;
  }
  GetWDScore(reco_request, reco_items);
  TunerByRecentQuery(reco_request, reco_items);
  for (size_t i = 0; i < reco_items->size(); ++i) {
    float score = std::max(0.001f, reco_items->at(i).wd_text_score) * reco_items->at(i).reco_score;
    index_score.push_back(std::pair<float, int32>(score, i));
  }
  std::sort(index_score.begin(), index_score.end(), QueryCmp);
  std::vector<ItemInfo> new_reco_items;
  for (size_t i = 0; i < index_score.size(); ++i) {
    new_reco_items.push_back(reco_items->at(index_score[i].second));
  }
  reco_items->swap(new_reco_items);
}

void QueryRanker::GetWDScore(const RecoRequest* reco_request, std::vector<ItemInfo>* reco_items) {
  // 预估
  if (reco_items->empty()
      || !wd_predictor_->BatchCalcWDScore(*reco_request, "", reco_items)) {
    for (int i = 0; i < (int)reco_items->size(); ++i) {
      reco_items->at(i).wd_text_score = 0;
    }
    return;
  }
}


void QueryRanker::TunerByRecentQuery(const RecoRequest* reco_request,
                                     std::vector<ItemInfo>* reco_items) {
  double max_query_time = 0;
  std::string query_word;
  for (size_t i = 0; i < reco_items->size(); ++i) {
    if (reco_items->at(i).query_time > max_query_time) {
      max_query_time = reco_items->at(i).query_time;
      query_word = reco_items->at(i).ir_word;
    }
  }
  base::Time recent_query_time = base::Time::FromDoubleT(max_query_time / 1e6);
  base::Time current_time = base::Time::Now();
 
  // 5 小时外的 query 不加权
  if ((current_time - recent_query_time).InHours() > 5) return;
  int query_times = 0;
  const reco::user::UserInfo* user_info = reco_request->user_info;
  // 最新的 query 出现次数小于 2 次的 必出
  for (int32 i = user_info->shown_history_size() - 1; i >= 0; --i) {
    if (query_times >= 2) break;
    base::Time show_time = base::Time::FromDoubleT(user_info->shown_history(i).view_timestamp());
    if ((current_time - show_time).InHours() > 24) break;
    if (user_info->shown_history(i).strategy_type() != reco::kQueryReco) continue;
    if (user_info->shown_history(i).hit_tag() == query_word) ++query_times;
  }
  if (query_times < 2) {
    for (size_t i = 0; i < reco_items->size(); ++i) {
      if (reco_items->at(i).ir_word == query_word) {
        reco_items->at(i).reco_score += 10000;
      }
    }
    LOG(INFO) << "recent query tuner, user_id: " << user_info->identity().user_id()
              << ", query: " << query_word;
  }
}

}
}
