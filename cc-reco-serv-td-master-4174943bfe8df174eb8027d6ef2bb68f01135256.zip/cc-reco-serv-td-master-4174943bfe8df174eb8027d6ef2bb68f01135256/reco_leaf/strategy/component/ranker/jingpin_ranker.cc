#include "reco/serv/reco_leaf/strategy/component/ranker/jingpin_ranker.h"

#include <algorithm>
#include <unordered_map>
#include <functional>
#include <queue>
#include <map>

#include "boost/unordered_map.hpp"

#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/reco/offline/item_dict_manager.h"
#include "reco/serv/reco_leaf/strategy/reco/offline/jingpin_item_dict.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/common/item_level_define.h"

#include "base/time/timestamp.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_tokenize.h"
#include "base/strings/string_printf.h"
#include "base/common/logging.h"

namespace reco {
namespace leafserver {

JingpinRanker::JingpinRanker(const reco::NewsIndex* index) {
}

JingpinRanker::~JingpinRanker() {
}

void JingpinRanker::Rank(const std::string& category,
                         const RecoRequest& request,
                         const std::vector<ItemInfo>& ir_results,
                         std::vector<ItemInfo>* reco_items) {
  reco_items->clear();
  // 1) 用户感兴趣类目
  std::map<std::string, float> user_prefer_cate;
  for (auto i = request.category_distributes->begin();
       i != request.category_distributes->end(); ++i) {
    user_prefer_cate[i->second.category()] = i->first;
    VLOG(1) << "insert cate: " << i->second.category() << " , " << i->first;
  }

  // 2) 获取用户感兴趣类目下的文章
  float not_prefer_weight = 1.0f;
  std::map<std::string, int32> cate_item_num;
  for (auto i = ir_results.begin(); i != ir_results.end(); ++i) {
    if (reco_items->size() > kMaxReturn) break;
    auto iter = user_prefer_cate.find(i->category);
    if (iter != user_prefer_cate.end()) {
      if (++cate_item_num[i->category] >= 100) continue;
      // 获取感兴趣类目下的文章
      reco_items->push_back(*i);
      reco_items->back().strategy_type = reco::kExplore;
      reco_items->back().reco_score = reco_items->back().ctr * iter->second * kRecoScoreFactor;
      not_prefer_weight = std::min(iter->second, not_prefer_weight);
    }
  }
  // 3) 获取用户不感兴趣类目下的文章
  not_prefer_weight *= 0.8;
  for (auto i = ir_results.begin(); i != ir_results.end(); ++i) {
    if (reco_items->size() > kMaxReturn) break;
    auto iter = user_prefer_cate.find(i->category);
    if (iter == user_prefer_cate.end()) {
      if (++cate_item_num[i->category] >= 100) continue;
      reco_items->push_back(*i);
      reco_items->back().strategy_type = reco::kExplore;
      reco_items->back().reco_score = reco_items->back().ctr * not_prefer_weight * kRecoScoreFactor;
    }
  }
  // 4) 按调整后的 ctr 排序
  std::sort(reco_items->begin(), reco_items->end(), std::greater<reco::ItemInfo>());
  // 5) 打散：最多不出现两篇相同类目的文章
  std::string last_category;
  int count = 1;
  if (reco_items->size() > 1) {
    last_category = (*reco_items)[0].category;
  }
  for (size_t i = 1; i < reco_items->size(); ++i) {
    if ((*reco_items)[i].category != last_category) {
      last_category = (*reco_items)[i].category;
      count = 1;
      continue;
    }
    if (++count > 2) {
      size_t j = i + 1;
      for (; j < reco_items->size(); ++j) {
        if ((*reco_items)[j].category != last_category) {
          last_category = (*reco_items)[j].category;
          count = 1;
          break;
        }
      }
      if (j >= reco_items->size()) break;
      std::swap((*reco_items)[i], (*reco_items)[j]);
    }
  }

  if (reco_items->size() > 0) {
    LOG(INFO) << base::StringPrintf("user_id : %lu (item_id:%lu,score:%d) (item_id:%lu,score:%d)",
                                    request.user_info->identity().user_id(),
                                    reco_items->front().item_id, reco_items->front().reco_score,
                                    reco_items->back().item_id, reco_items->back().reco_score);
  }
}

}  // namespace leafserver
}  // namespace reco
