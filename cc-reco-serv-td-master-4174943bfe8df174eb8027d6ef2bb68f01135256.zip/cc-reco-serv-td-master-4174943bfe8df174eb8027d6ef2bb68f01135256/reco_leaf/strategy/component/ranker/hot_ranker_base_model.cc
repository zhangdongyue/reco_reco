#include "reco/serv/reco_leaf/strategy/component/ranker/hot_ranker_base_model.h"
#include "reco/serv/reco_leaf/frame/inner/dynamic_dict_container.h"

namespace reco {
namespace leafserver {

HotPredict::HotPredict(const reco::NewsIndex* index) {
  news_index_ = index;
}

void HotPredict::ExtractUserFea(const reco::FeatureVector& user_info,
                               UserFea &user_fea,
                               UserType user_type) {
  user_fea.fea[user_type].set_empty_key("");
  for (int i = 0; i < user_info.feature_size() && i <= 100; ++i) { // top text topic
    const auto& fea = user_info.feature(i);
    if (fea.literal().empty()) continue;
    if (fea.literal() == "") continue;
    user_fea.fea[user_type].insert(std::make_pair(fea.literal(), fea.weight()));
    user_fea.norm_weight[user_type] += fea.weight();
  }
  VLOG(2) << "userfeatype: " << user_type << " size: " << user_info.feature_size();
  return;
}

void HotPredict::ExtractUserFea(const reco::CategoryFeatureVector& user_category,
                                 UserFea &user_fea,
                                 UserType user_type) {
  user_fea.fea[user_type].set_empty_key("");
  for (int i = 0; i < user_category.feature_size() && i <= 100; ++i) { // top text topic
    const reco::Category& category_liter = user_category.feature(i).literal();
    double category_weight = user_category.feature(i).weight();
    if (category_liter.category() == "") continue;
    user_fea.fea[user_type].insert(std::make_pair(category_liter.category(), category_weight));
    user_fea.norm_weight[user_type] += category_weight;
  }
  VLOG(2) << "userfeatype: " << user_type << " size: " << user_category.feature_size();
  return;
}


void HotPredict::SetUserFea(const RecoRequest* reco_request, UserFea &user_fea) {
  // TODO INIT
  const reco::user::UserInfo* user_info = reco_request->user_info;
  if (user_info != NULL) {
    const reco::user::Profile& profile = user_info->profile();
    ExtractUserFea(profile.tag_feavec(), user_fea, kTag);
    ExtractUserFea(profile.keyword_feavec(), user_fea, kKeyword);
    ExtractUserFea(profile.topic_feavec(), user_fea, kTopic);
    ExtractUserFea(profile.category_feavec(), user_fea, kCategory);
  }
}

float HotPredict::CalScore(const std::string& category,
                           const UserFea& user_fea,
                           UserType user_type) {
  float score = 0.0;
  auto iter = user_fea.fea[user_type].find(category);
  if (iter != user_fea.fea[user_type].end()) {
    score += iter->second;
  }
  return score;
}



float HotPredict::CalScore(const std::vector<std::pair<std::string, float> > fea_vec,
                           const UserFea& user_fea,
                           UserType user_type) {
  float score = 0.0;
  for (uint32 i = 0; i < fea_vec.size(); ++i) {
    const std::string& literal = fea_vec[i].first;
    double weight = fea_vec[i].second;
    auto iter = user_fea.fea[user_type].find(literal);
    if (iter != user_fea.fea[user_type].end()) {
      score += iter->second * weight;
    }
  }
  return score;
}


float HotPredict::DoPredict(const UserFea &user_fea,
                            const ItemInfo &item_info,
                            reco::xgboost::RegTree::FVec &fvec_temp) {
  fvec_temp.Init(kHotFeatureSize);
  int feature_size = ExtractFea(user_fea, item_info, fvec_temp);
  if (feature_size < 0) {
    return -1;
  }
  auto hot_model = DM_GET_DICT(reco::dm::HotModel, DynamicDictContainer::kHotModelFile_);
  const reco::xgboost::XGboostModel* xgboost_model = &(hot_model.get()->xgboost_model_);

  float ret = xgboost_model->p_gbm->Predict(fvec_temp, -1, 0);
  float predict = xgboost_model->p_obj->PredTransform(ret);
  VLOG(2) << "itemid: " << item_info.item_id
            << " keyword_score: " << fvec_temp.data[1].fvalue
            << " tag_score: " << fvec_temp.data[2].fvalue
            << " topic_score: " << fvec_temp.data[3].fvalue
            << " cate_score: " << fvec_temp.data[4].fvalue
            << " ctr: " << fvec_temp.data[5].fvalue
            << " time: " << fvec_temp.data[6].fvalue
            << " hot_level: " << fvec_temp.data[7].fvalue
            << " cate_ctr: " << fvec_temp.data[8].fvalue
            << " predict score pre: " << ret << " after: " << predict;
  return predict;
}


int HotPredict::ExtractFea(const UserFea &user_fea,
                           const ItemInfo &item_info,
                           reco::xgboost::RegTree::FVec &features) {
  uint64 item_id = item_info.item_id;
  int item_index = news_index_->GetItemIndex(item_info.item_id);
  if (item_index < 0) {
    return -1;
  }
  features.data[0].fvalue = -1.0;
  const ItemFea& item_fea = news_index_->GetItemFea(item_index);
  int32 index = 0;
  // keyword
  float keyword_score = 0.0;
  keyword_score = CalScore(item_fea.keyword_info, user_fea, kKeyword);
  if (keyword_score != 0) {
    features.data[1].fvalue = keyword_score;
    index = std::max(index, 1);
  }
  // tag
  float tag_score = 0.0;
  tag_score = CalScore(item_fea.tag_info, user_fea, kTag);
  if (tag_score != 0) {
    features.data[2].fvalue = tag_score;
    index = std::max(index, 2);
  }
  // topic
  float topic_score = 0.0;
  topic_score = CalScore(item_fea.topic_info, user_fea, kTopic);
  if (topic_score != 0) {
    features.data[3].fvalue = topic_score;
    index = std::max(index, 3);
  }
  // category
  float catescore = CalScore(item_info.category, user_fea, kCategory);
  features.data[4].fvalue = catescore;
  index = std::max(index, 4);
  // ctr
  float ctr = item_info.wilson_ctr;
  features.data[5].fvalue = ctr;
  index = std::max(index, 5);
  // hot_level
  int32 hot_level = item_info.hot_level;
  features.data[7].fvalue = hot_level;
  index = std::max(index, 7);
  // hour interval
  base::Time pub_time;
  base::Time search_time;
  int64 now_ts = base::GetTimestamp();
  int64 publish_time = news_index_->GetPublishSecondByItemId(item_id) * base::Time::kMicrosecondsPerSecond;
  base::TimeDelta delta = base::TimeDelta::FromMicroseconds(now_ts - publish_time);
  float day_interval = delta.InHours();
  features.data[6].fvalue = day_interval;
  index = std::max(index, 6);
  // 类别ctr
  auto click_ratio = DM_GET_DICT(reco::dm::HotCateClickRatio, DynamicDictContainer::kHotCateClickRatioFile_);
  float cateclickratio = 0.0;
  auto click_info = click_ratio.get()->cate_clik_ratio_.find(item_info.category);
  if (click_info != click_ratio.get()->cate_clik_ratio_.end()) {
    cateclickratio = click_info->second;
    features.data[8].fvalue = cateclickratio;
    index = std::max(index, 8);
  }

  return index;
}

}  // namespace leafserver
}  // namespace reco
