#include "reco/serv/reco_leaf/strategy/component/ranker/rank_model.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/lr_predictor.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/mf_predictor.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/fm_predictor.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/model_inner/mf_model.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/fm_inner/fm_model.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/model_inner/model_buffer_manager.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/fm_inner/fm_buffer_manager.h"
// #include "reco/serv/reco_leaf/strategy/component/scorer/ugm_predictor.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/wd_predictor.h"
#include "reco/serv/reco_model/frame/reco_model_predict.h"
#include "reco/serv/reco_model/frame/reco_model_def.h"

namespace reco {
namespace leafserver {
// DEFINE_bool(open_personal_lr_model, true, "if open personal lr model");
// DEFINE_bool(open_common_lr_model, true, "if open personal lr model");
// DEFINE_bool(open_ugm_model, true, "if open ugm model");
// DEFINE_bool(open_fm_model, true, "if open personal lr model");
// DEFINE_bool(open_mf_model, true, "if open personal lr model");
DEFINE_bool(open_wd_model, true, "if open wd model");
DEFINE_int32(new_item_num, 2, "");

// personal lr related
// DEFINE_int32(lr_max_predict_num, 400, "每个类别预估的最多的item数");
// DEFINE_int32(lr_base_predict_num, 200, "每个类别基础预估的item数");

/*
// mf 相关配置
DEFINE_string(mf_icate_enhance, "", "icateid-mf enhance");
DEFINE_string(icate_minpostctr, "", "icateid-min postctr for mf & fac_machine");
DEFINE_string(mf_icate_showdiscount, "", "icate-user show discount");
DEFINE_double(min_usershow_mf, 70, "min mf user show in 7 days");
DEFINE_int32(min_itemshow_mf, 3000, "min mf item show in 7 days");
DEFINE_int32(max_itemshow_mf, 600000, "max mf item show in 7 days");
DEFINE_int32(base_usershow_mf, 600, "baseine mf user show in 7 days");
DEFINE_int32(max_mf_fm_queue_len, 300, "max MF&FacMachine queue length");
DEFINE_double(fac_machine_ctr_alter, 1.5, "fac_machine ctr threshold alter on that of mf");
DEFINE_double(queue_video_enhance, 1.5, "how many times is video fm/mf que longer than text");
DEFINE_int32(fac_machine_timeseg, 48, "fac_machine predict queue time limit");
DEFINE_double(fac_machine_punish_alter, 0.2, "cut down avg_fac_machine for punish");
*/

DEFINE_double(punish_alter_wd, 0.2, "cut down avg_fac_machine for punish");
DEFINE_int32(max_predict_num_wd, 200, "每个类别基础预估的item数");
DEFINE_int32(min_itemshow_wd, 1000, "min mf item show in 7 days");
DEFINE_int32(max_itemshow_wd, 6000000, "max mf item show in 7 days");
DEFINE_int32(timeback_wd, 48, "单位是小时");
DEFINE_double(dislike_cate_num_tune_wd, 0.5, "减少不喜欢类别的预估条数");
DEFINE_double(prefer_cate_num_tune_wd, 1.2, "减少不喜欢类别的预估条数");

DEFINE_int64_counter(leaf, hit_mf, 0, "mf命中数");
DEFINE_int64_counter(leaf, miss_mf, 0, "mf未命中数");
DEFINE_int64_counter(leaf, hit_facmachine, 0, "fac machine命中数");
DEFINE_int64_counter(leaf, miss_facmachine, 0, "fac machine未命中数");

/*
static bool ParseGFlagString(const std::string &gflag,
                             std::unordered_map<std::string, double> &gflag_map) {
  std::vector<std::string> tokens;
  base::SplitString(gflag, " ", &tokens);
  for (uint32 i = 0; i < tokens.size(); ++i) {
    std::vector<std::string> k_v;
    base::SplitString(tokens[i], ":", &k_v);
    double value = 0;
    if (k_v.size() == 2 && base::StringToDouble(k_v[1], &value)) {
      gflag_map[k_v[0]] = value;
      VLOG(1) << "gflag key:" << k_v[0] << " value:" << value;
    }
  }

  return true;
}
*/

RankModel::RankModel(const reco::NewsIndex* index) {
  news_index_ = index;
  random_ = new base::PseudoRandom(base::GetTimestamp());

  /*
  lr_predictor_ = NULL;
  if (FLAGS_open_personal_lr_model) {
    lr_predictor_ = new LRPredictor(news_index_);
  }

  mf_predictor_ = new MFPredictor(news_index_);
  InitMFParameter();

  fm_predictor_ = new FacMachinePredictor(news_index_);

  ugm_predictor_ = NULL;
  if (FLAGS_open_ugm_model) {
    ugm_predictor_ = new UGMPredictor(news_index_);
  }
  */

  wd_predictor_ = NULL;
  if (FLAGS_open_wd_model) {
    wd_predictor_ = new WDPredictor(news_index_);
  }

  model_user_feature_ = NULL;

  // ugm_model_ = NULL;
  // ugm_remain_prefix_ = NULL;
}

RankModel::~RankModel() {
  delete random_;
  /*
  delete lr_predictor_;
  delete mf_predictor_;
  delete fm_predictor_;
  delete ugm_predictor_;
  */
  delete wd_predictor_;
}

void RankModel::BatchPredict(const std::string& category,
                             const std::vector<ItemInfo>& items,
                             std::vector<ModelData>* model_vec,
                             ModelExtraInfo* extra_info) {
  if (items.empty()) return;

  CHECK_EQ(items.size(), model_vec->size());

  std::string map_category = category;
  if (map_category.empty()) {
    reco::leafserver::GlobalData* global_data = LeafDataManager::GetGlobalData();
    auto it = global_data->channel_categories.find(reco_request_->channel_id);
    if (it != global_data->channel_categories.end() && it->second.size() == 1u) {
      map_category = it->second[0].first;
    }
  }

  /*
  if (FLAGS_open_common_lr_model) {
    CalcLrScores(map_category, items, model_vec, extra_info);
  }
  if (FLAGS_open_ugm_model) {
    CalcUgmScores(map_category, items, model_vec, extra_info);
  }
  if (FLAGS_open_fm_model) {
    CalcFmScores(map_category, items, model_vec, extra_info);
  }
  if (FLAGS_open_mf_model) {
    CalcMfScores(map_category, items, model_vec, extra_info);
  }
  if (FLAGS_open_personal_lr_model) {
    CalcPersonalLrScores(map_category, items, model_vec, extra_info);
  }
  */
  if (FLAGS_open_wd_model) {
    CalcWDScores(map_category, items, model_vec, extra_info);
  }
}

/*
void RankModel::CalcLrScores(const std::string& category, const std::vector<ItemInfo>& items,
                             std::vector<ModelData>* model_vec, ModelExtraInfo* extra_info) {
  // 获取预估队列
  std::vector<ItemInfo> predict_items;
  const int max_predict_num = JudgeLrPredictNum(category);
  DecideLrPredictQueue(items, &predict_items, max_predict_num);

  // 计算预估值
  lr_predictor_->SetUserFeature(model_user_feature_);
  lr_predictor_->BatchCalcLRScore(*reco_request_, &predict_items);

  // 填充到返回结果中
  base::dense_hash_map<uint64, float> score_dict;
  score_dict.set_empty_key(0);
  for (size_t idx = 0; idx < predict_items.size(); ++idx) {
    const ItemInfo& item = predict_items.at(idx);
    score_dict.insert(std::make_pair(item.item_id, item.lr_score));
  }
  for (size_t idx = 0; idx < model_vec->size(); ++idx) {
    ModelData& data = model_vec->at(idx);
    const auto iter = score_dict.find(data.item_id);
    if (iter != score_dict.end()) {
      data.lr_score = iter->second;
    }
  }
}
*/

/*
void RankModel::CalcMfScores(const std::string& category, const std::vector<ItemInfo>& items,
                             std::vector<ModelData>* model_vec, ModelExtraInfo* extra_info) {
  // 获取 MF 所需要的参数
  std::string icate_mf;
  if (reco_request_->channel_id == 10016) {
    // video is special to other categories
    icate_mf = "视频";
  } else if (!category.empty()) {
    icate_mf = ModelBufMgr::instance().GetItemCateFromCate(category);
  } else {
    icate_mf = ModelBufMgr::instance().GetItemCateFromChannel(reco_request_->channel_id);
  }
  reco::MFFeatureVectorWithCate user_fea_vec;
  uint64 user_id = reco_request_->user_info->identity().user_id();
  float user_confidence_mf = mf_predictor_->EvaluateUser(user_id, icate_mf, &user_fea_vec);

  extra_info->mf_weight_hit = 0;
  const auto discount_iter = icate_showdiscount_.find(icate_mf);
  if (discount_iter != icate_showdiscount_.end()) {
    extra_info->mf_weight_hit =
        std::pow(user_confidence_mf / (FLAGS_base_usershow_mf * discount_iter->second), 0.5);
  }
  extra_info->mf_enhance = 0;
  const auto enhance_iter = icate_mfenhance_.find(icate_mf);
  if (enhance_iter != icate_mfenhance_.end()) {
    extra_info->mf_enhance = enhance_iter->second;
  }

  // 获取预估队列
  std::vector<ItemInfo> mf_items;
  DecideMfPredictQueue(items, icate_mf, user_fea_vec.cluster(), user_confidence_mf, &mf_items);

  // 计算 mf 分数
  if (mf_items.empty()
      || !mf_predictor_->BatchCalcScore(user_fea_vec, icate_mf, &mf_items)) {
    for (size_t idx = 0; idx < mf_items.size(); ++idx) {
      mf_items[idx].fm_score = 0;
    }
    extra_info->avg_mf = 0.01;
  } else {
    extra_info->avg_mf = 0.0f;
    for (int i = 0; i < (int)mf_items.size(); ++i) {
      extra_info->avg_mf += mf_items[i].fm_score;
    }
    extra_info->avg_mf = extra_info->avg_mf / mf_items.size() + 0.01;
  }

  // 填充到 返回的 model data
  base::dense_hash_map<uint64, float> score_dict;
  score_dict.set_empty_key(0);
  for (size_t idx = 0; idx < mf_items.size(); ++idx) {
    const ItemInfo& item = mf_items.at(idx);
    uint64 pid = news_index_->GetParentId(item.item_id);
    // NOTE(all) mf 填充的是 fm_score
    score_dict.insert(std::make_pair(pid, item.fm_score));
  }
  for (size_t idx = 0; idx < model_vec->size(); ++idx) {
    uint64 pid = news_index_->GetParentId(items[idx].item_id);
    const auto iter = score_dict.find(pid);
    ModelData& data = model_vec->at(idx);
    if (iter != score_dict.end()) {
      data.mf_score = iter->second;
    } else {
      data.mf_score = 0;
    }
  }
}
*/

/*
void RankModel::CalcFmScores(const std::string& category, const std::vector<ItemInfo>& items,
                             std::vector<ModelData>* model_vec, ModelExtraInfo* extra_info) {
  // 获取 FM 所需要的各种参数
  // uint64 uid = reco_request_->user_info->identity().user_id();
  std::string icate_fm;
  if (reco_request_->channel_id == 10016) {
    // video is special to other categories
  } else if (!category.empty()) {
    icate_fm = FacMachineBufMgr::instance().GetItemCateFromCate(category);
  } else {
    icate_fm = FacMachineBufMgr::instance().GetItemCateFromChannel(reco_request_->channel_id);
  }
  UserScore user_score;
  bool user_confidence = fm_predictor_->EvaluateUser(*(reco_request_->user_info), icate_fm, &user_score);

  // 计算预估队列
  std::vector<ItemInfo> fm_items;
  DecideFmPredictQueue(items, icate_fm, user_confidence, &fm_items);
  // LOG(INFO) << "DEBUG_FM, uid:"<< uid << ", cate:" << icate_fm << ", fm_size:" << fm_items.size()
  //          << ", conf:" << user_confidence;
  // 预估
  if (fm_items.empty()
      || !fm_predictor_->BatchCalcScore(user_score, icate_fm, &fm_items)) {
    for (int i = 0; i < (int)fm_items.size(); ++i) {
      fm_items[i].fac_machine_score = 0;
    }
    extra_info->avg_fm = 0.01;
  } else {
    // LOG(INFO) << "DEBUG2, succ to calc fm scores, " << uid;
    extra_info->avg_fm = 0.0f;
    for (int i = 0; i < (int)fm_items.size(); ++i) {
      extra_info->avg_fm += fm_items[i].fac_machine_score;
    }
    extra_info->avg_fm = extra_info->avg_fm / fm_items.size() + 0.01;
  }
  extra_info->avg_fm_punish = extra_info->avg_fm * FLAGS_fac_machine_punish_alter;
  // 填充结果到返回的模型数据
  base::dense_hash_map<uint64, float> score_dict;
  score_dict.set_empty_key(0);
  for (size_t idx = 0; idx < fm_items.size(); ++idx) {
    const ItemInfo& item = fm_items.at(idx);
    uint64 pid = news_index_->GetParentId(item.item_id);
    // NOTE(all) fm 填充的是 fac_machine_score
    score_dict.insert(std::make_pair(pid, item.fac_machine_score));
  }
  for (size_t idx = 0; idx < model_vec->size(); ++idx) {
    uint64 pid = news_index_->GetParentId(items[idx].item_id);
    const auto iter = score_dict.find(pid);
    ModelData& data = model_vec->at(idx);
    if (iter != score_dict.end()) {
      data.fm_score = iter->second;
    } else {
      data.fm_score = 0;
    }
  }
}
*/

/*
void RankModel::CalcUgmScores(const std::string& category, const std::vector<ItemInfo>& items,
                              std::vector<ModelData>* model_vec, ModelExtraInfo* extra_info) {
  // 设置预估参数，并进行预估
  ugm_predictor_->SetUGM(ugm_model_, ugm_remain_prefix_);
  std::vector<float> score_vec;
  score_vec.resize(items.size());
  ugm_predictor_->BatchCalcUGMScore(*reco_request_, category, items, &score_vec);

  // 填充结果到返回的模型数据
  base::dense_hash_map<uint64, float> score_dict;
  score_dict.set_empty_key(0);
  for (size_t idx = 0; idx < items.size(); ++idx) {
    const ItemInfo& item = items.at(idx);
    score_dict.insert(std::make_pair(item.item_id, score_vec.at(idx)));
  }
  for (size_t idx = 0; idx < model_vec->size(); ++idx) {
    ModelData& data = model_vec->at(idx);
    const auto iter = score_dict.find(data.item_id);
    if (iter != score_dict.end()) {
      data.ugm_score = iter->second;
    }
  }
}
*/

/*
void RankModel::CalcPersonalLrScores(const std::string& category,
                                     const std::vector<ItemInfo>& items,
                                     std::vector<ModelData>* model_vec,
                                     ModelExtraInfo* extra_info) {
  if (category.empty()) return;

  uint64 user_id = reco_request_->user_info->identity().user_id();
  std::string model_prefix = "Uid_" + base::Uint64ToString(user_id) + "_ITag_" + category + "_label:";
  const dawgdic::Dictionary* model_dict =
      reco::reco_model::RecoModelProc::Instance()->GetActivePersonalModel(user_id);
  const std::vector<double>* weight_dict =
      reco::reco_model::RecoModelProc::Instance()->GetActivePersonalWeight(user_id);
  bool has_user_model = false;
  dawgdic::BaseType model_index = 0;
  if (model_dict != NULL) {
    model_index = model_dict->root();
    has_user_model = model_dict->Follow(model_prefix.c_str(), &model_index);
  }

  if (!has_user_model) return;

  // int max_predict = CalcPersonalLrPredictNum(category);
  const int predict_num = reco_request_->channel_id == 100 ? 300 : 2000;
  int max_predict = predict_num * LeafDataManager::GetGlobalData()->GetSelectionRatio();
  max_predict = std::min(max_predict, int(items.size()));

  for (int i = 0; i < max_predict; ++i) {
    const ItemInfo& item = items[i];
    bool hit_fea = false;
    reco::FeatureVector fv;
    news_index_->GetFeatureVectorByItemId(item.item_id, reco::common::kTag, &fv);
    float ir_score = std::min(1.0f, item.reco_score * 1.0f / kRecoScoreFactor);
    float lr_score = 0;
    for (int idx = 0; idx < fv.feature_size(); ++idx) {
      double score = 0.0;
      // 所以这里再 follow 的时候要加上 6
      GetFeatureScore(model_dict, weight_dict, model_index, fv.feature(idx).literal().c_str() + 6, &score);

      if (score > 0) {
        if (score > 0.5 && ir_score > 0.08) {
          lr_score = 0.1;
        } else {
          lr_score = ir_score * score;
        }

        hit_fea = true;
        break;
      }
    }
    // 没命中的一样加权
    if (!hit_fea) lr_score = ir_score * 0.5;
    model_vec->at(i).personal_lr_score = lr_score;
  }
}
*/

/*
////////////////////// mf model related
bool RankModel::InitMFParameter() {
  ParseGFlagString(FLAGS_mf_icate_showdiscount, icate_showdiscount_);
  ParseGFlagString(FLAGS_mf_icate_enhance, icate_mfenhance_);
  ParseGFlagString(FLAGS_icate_minpostctr, icate_minpostctr_);
  return true;
}

bool RankModel::CheckMfItemExist(uint64 item_id, const std::string& user_cluster) const{
  std::string item_key_core = base::StringPrintf("%lu-%s", item_id, user_cluster.c_str());
  std::string item_key;
  MFModel::GenItemIDKey(item_key_core, &item_key);
  std::string item_val;
  if (!ModelBufMgr::instance().GetMatrixDataMf(item_key, &item_val, false)) {
    VLOG(1) << "mf item[" << item_key << "] not exist";
    COUNTERS_leaf__miss_mf.Increase(1);
    return false;
  } else {
    COUNTERS_leaf__hit_mf.Increase(1);
    return true;
  }
}

void RankModel::DecideMfPredictQueue(const std::vector<ItemInfo>& items,
                                     const std::string &icate_mf,
                                     const std::string &user_cluster,
                                     float user_confidence_mf,
                                     std::vector<ItemInfo>* mf_items) const {
  float min_uconf_mf = 0;
  const auto show_iter = icate_showdiscount_.find(icate_mf);
  if (show_iter != icate_showdiscount_.end()) {
     min_uconf_mf = FLAGS_min_usershow_mf * show_iter->second;
  }
  if (user_confidence_mf < min_uconf_mf) {
    VLOG(1) << "no mf & fac_machine, user_confidence_mf:"
            << user_confidence_mf << ":" << min_uconf_mf;
    return;
  }

  int max_predict_num_mf = FLAGS_max_mf_fm_queue_len;
  if (icate_mf == "视频") {
    max_predict_num_mf *= FLAGS_queue_video_enhance;
  }
  double min_postctr_mf = 0;
  const auto ctr_iter = icate_minpostctr_.find(icate_mf);
  if (ctr_iter != icate_minpostctr_.end()) {
    min_postctr_mf = ctr_iter->second;
  }

  base::dense_hash_set<uint64> topn_dedup;
  topn_dedup.set_empty_key(0);
  for (int i = 0; i < (int)items.size(); ++i) {
    const ItemInfo& item = items[i];

    if ((int)mf_items->size() >= max_predict_num_mf) break;
    // 数据不充分的 item mf 不再预估
    if (item.show_num < FLAGS_min_itemshow_mf || item.show_num > FLAGS_max_itemshow_mf) continue;
    // dedup by parentid (NOT simids)
    uint64 parent_id = news_index_->GetParentId(item.item_id);
    if (parent_id != 0 && topn_dedup.find(parent_id) != topn_dedup.end()) continue;
    // postctr 太小的不预估
    float ir_score = std::min(1.0f, item.reco_score * 1.0f / kRecoScoreFactor);
    // fill mf
    if (ir_score > min_postctr_mf
        && CheckMfItemExist(parent_id, user_cluster)) {
      mf_items->push_back(item);
      if (parent_id != 0) {
        topn_dedup.insert(parent_id);
      }
    }
  }
}
*/

/*
///////////////////////// fm model related
bool RankModel::CheckFmItemExist(uint64 item_id) const {
  reco::FacMachineFeature feature;
  if (!FacMachineBufMgr::instance().GetMatrixData(item_id, false, &feature)) {
    VLOG(1) << "fac_machine item[" << item_id << "] not valid";
    COUNTERS_leaf__miss_facmachine.Increase(1);
    return false;
  } else {
    COUNTERS_leaf__hit_facmachine.Increase(1);
    return true;
  }
}

void RankModel::DecideFmPredictQueue(const std::vector<ItemInfo>& items,
                                     const std::string &icate_fm,
                                     bool user_confidence_fm,
                                     std::vector<ItemInfo>* fm_items) const {
  fm_items->clear();

  if (!user_confidence_fm) {
    VLOG(1) << "no fac_machine, user_confidence_mf:"<< user_confidence_fm;
    return;
  }
  int max_predict_num_fm = FLAGS_max_mf_fm_queue_len;

  double min_postctr_fm = 0;
  const auto ctr_iter = icate_minpostctr_.find(icate_fm);
  if (ctr_iter != icate_minpostctr_.end()) {
    min_postctr_fm = ctr_iter->second * FLAGS_fac_machine_ctr_alter;
  }

  base::Time limit_time = reco_request_->current_time - base::TimeDelta::FromHours(FLAGS_fac_machine_timeseg);
  int64 limit_timestamp = limit_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  base::dense_hash_set<uint64> topn_dedup;
  topn_dedup.set_empty_key(0);
  for (int i = 0; i < (int)items.size(); ++i) {
    if ((int)fm_items->size() >= max_predict_num_fm) break;

    const ItemInfo& item = items[i];

    if (item.create_timestamp < limit_timestamp) continue;
    // LOG(INFO) << "DEBUG_11, " << item.item_id;

    // 数据不充分的 item mf 不再预估
    if (item.show_num < FLAGS_min_itemshow_mf || item.show_num > FLAGS_max_itemshow_mf) continue;
    // LOG(INFO) << "DEBUG_12, " << item.item_id;
    // dedup by parentid (NOT simids)
    uint64 parent_id = news_index_->GetParentId(item.item_id);
    if (parent_id != 0 && topn_dedup.find(parent_id) != topn_dedup.end()) continue;
    // LOG(INFO) << "DEBUG_13, " << item.item_id;
    // postctr 太小的不预估
    float ir_score = std::min(1.0f, item.reco_score * 1.0f / kRecoScoreFactor);
    if (ir_score > min_postctr_fm
        && CheckFmItemExist(parent_id)) {
      // LOG(INFO) << "DEBUG_14, " << item.item_id;
      fm_items->push_back(item);
      if (parent_id != 0) {
        topn_dedup.insert(parent_id);
      }
    }
  }
}
*/



////////////////////// lr related
/*
inline int RankModel::CalcPersonalLrPredictNum(const std::string& category) const {
  int predict_num = reco_request_->channel_id == 100 ? 300 : 4000;
  float dynamic_ratio = 1.f;
  switch (LeafDataManager::GetGlobalData()->sys_status) {
    case kSysFree:
    case kSysNormal:
      dynamic_ratio = 1.2f;
      break;
    case kSysFull:
      dynamic_ratio = 0.8f;
      break;
    case kSysDanger:
      dynamic_ratio *= 0.5f;
      break;
    case kSysCritical:
      dynamic_ratio = 0.2f;
      break;
    default:
      break;
  }
  return predict_num * dynamic_ratio;
}
*/

/*
int RankModel::JudgeLrPredictNum(const std::string& category) const {
  int max_predict_num = FLAGS_lr_max_predict_num * LeafDataManager::GetGlobalData()->GetSelectionRatio();
  int base_predict_num = FLAGS_lr_base_predict_num * LeafDataManager::GetGlobalData()->GetSelectionRatio();

  auto const& ref_raw_l1_cates = reco_request_->user_feas->lt_fea.raw_l1_cates;
  if (!category.empty() && base_predict_num < max_predict_num) {
    static const int inc_predict_per_click
        = std::max(1, static_cast<int>((max_predict_num - base_predict_num) / 50.0 + 0.5));  // NOLINT
    int predict_num = base_predict_num;
    auto iter = ref_raw_l1_cates.find(category);
    if (iter != ref_raw_l1_cates.end() && iter->second > 3) {
      predict_num += (iter->second - 3) * inc_predict_per_click;
    }

    if (0 <= predict_num && predict_num < max_predict_num) {
      max_predict_num = predict_num;
    }
  }

  return max_predict_num;
}
*/

/*
void RankModel::DecideLrPredictQueue(const std::vector<ItemInfo>& items,
                                     std::vector<ItemInfo>* predict_items, int max_num) const {
  predict_items->clear();
  // 限制预估的文章抓取时间限制在 6 小时内；发布时间在 30 小时内
  base::Time predict_crawl_time = reco_request_->current_time - base::TimeDelta::FromHours(6);
  int64 predict_crawl_timestamp = predict_crawl_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  base::Time predict_publish_time = reco_request_->current_time - base::TimeDelta::FromHours(25);
  int64 predict_publish_timestamp = predict_publish_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  base::Time limit_deliver_time = reco_request_->current_time - base::TimeDelta::FromMinutes(10);
  int64 limit_deliver_timestamp = limit_deliver_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  static const int kLrPredictItemShowLimit = 1000;
  base::dense_hash_set<uint64> topn_dedup;
  topn_dedup.set_empty_key(0);
  for (size_t i = 0; i < items.size(); ++i) {
    if ((int)predict_items->size() >= max_num) break;
    const ItemInfo& item = items[i];
    if (item.show_num >= kLrPredictItemShowLimit) continue;
    // 抓取时间太长, 不走 lr 预估了
    if (item.create_timestamp < predict_publish_timestamp) continue;
    // 发布时间太长, 不走 lr 预估
    int64 crawl_timestamp = news_index_->GetCrawlTimestampByDocId(item.doc_id);
    if (crawl_timestamp < predict_crawl_timestamp) continue;
    // 相似的 item，只预估一个
    if (topn_dedup.find(item.item_id) != topn_dedup.end()) continue;
    // 根据 item 已有信息决定此次是否参与预估
    float deliver_ratio = 1;
    if (item.show_num == 0) {
      // NOTE(jianhuang) 没有下发说明有可能因为图床原因无法下发，此时给予很小概率去尝试下发
      deliver_ratio = 0.1;
    } else if (item.show_num >= 100) {
      // 如果展现条数相对较多了，使用 ctr 来决定此次是否预估
      deliver_ratio = std::max(0.05f, item.ctr * 10);
    } else if (crawl_timestamp < limit_deliver_timestamp) {
      // 统计数据的更新有 5 分钟的延迟，不稍微做控制， 5 分钟可能已经有大量下发
      deliver_ratio = 0.3;
    }
    // 垃圾文章做一定的降权操作
    reco::ContentAttr content_attr;
    bool is_trival;
    news_index_->GetContentAttrByDocId(item.doc_id, &content_attr, &is_trival);
    if (!is_trival) {
      // 都设置了默认值了
      if (content_attr.erro_title() > reco::ContentAttr::kSuspect
          || content_attr.advertorial() > reco::ContentAttr::kSuspect
          || content_attr.short_content() > reco::ContentAttr::kSuspect
          || content_attr.dedup_paragraph() > reco::ContentAttr::kSuspect
          || content_attr.dirty() > reco::ContentAttr::kSuspect
          || content_attr.politics() > reco::ContentAttr::kSuspect
          || content_attr.bluffing_title() > reco::ContentAttr::kSuspect) {
        deliver_ratio *= 0.5;
      } else {
        deliver_ratio *= 0.8;
      }
    }
    // 按概率给予不展现
    if (random_->GetDouble() < 1 - deliver_ratio) continue;
    topn_dedup.insert(item.item_id);
    const std::set<uint64>* sim_ids = news_index_->GetSimItemIds(item.item_id);
    if (sim_ids != NULL) {
      for (auto it = sim_ids->begin(); it != sim_ids->end(); ++it) {
        topn_dedup.insert(*it);
      }
    }
    // 放入预估队列
    predict_items->push_back(item);
  }
}
*/

void RankModel::DecideWDPredictQueue(const std::string& cate,
                                     const std::vector<ItemInfo>& items,
                                     std::vector<ItemInfo>* wd_items, float tune) const {
  wd_items->clear();
  int max_predict_num_wd = int(FLAGS_max_predict_num_wd * tune);
  double min_postctr_wd = 0.01;
  base::Time limit_time = reco_request_->current_time - base::TimeDelta::FromHours(FLAGS_timeback_wd);
  int64 limit_timestamp = limit_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  static const std::unordered_set<std::string> kDoSubCates = { "科技", "财经", "体育"};
  static const std::unordered_set<int64> kSubCateLimitChannels = {
    reco::common::kSportChannelId, reco::common::kFinanceChannelId, reco::common::kScienceChannelId,};
  bool do_subcate_limit = false;
  int64 cid = reco_request_->channel_id;
  if (cid == 100) {
    do_subcate_limit = kDoSubCates.find(cate) != kDoSubCates.end();
  } else {
    do_subcate_limit = kSubCateLimitChannels.find(cid) != kSubCateLimitChannels.end();
  }
  std::unordered_map<std::string, int> subcate_map;

  base::dense_hash_set<uint64> topn_dedup;
  topn_dedup.set_empty_key(0);
  int new_item_num = 0;
  for (int i = 0; i < (int)items.size(); ++i) {
    if ((int)wd_items->size() >= max_predict_num_wd) break;
    const ItemInfo& item = items[i];
    // 太老的丢弃，保证时效性
    if (item.create_timestamp < limit_timestamp) continue;
    if (item.show_num > FLAGS_max_itemshow_wd) continue;
    // 保证低展现的 newitem 有机会进入模型
    // 可能会出现时效性不好但展现很低的 item，不过由于前面排序有时效性降权，影响不大
    if (item.show_num < FLAGS_min_itemshow_wd) {
      if (new_item_num >= FLAGS_new_item_num) continue;
      else
        new_item_num += 1;
    }
    // dedup by parentid (NOT simids)
    uint64 parent_id = news_index_->GetParentId(item.item_id);
    if (parent_id != 0 && topn_dedup.find(parent_id) != topn_dedup.end()) continue;
    // postctr 太小的不预估
    float ir_score = std::min(1.0f, item.reco_score * 1.0f / kRecoScoreFactor);
    if (ir_score < min_postctr_wd) continue;
    // 二级类别限制，尽可能包括更多的二级类别候选
    if (do_subcate_limit && !item.sub_category.empty()) {
      auto it = subcate_map.find(item.sub_category);
      if (it != subcate_map.end()) {
        if (it->second >= max_predict_num_wd / 2) {
          continue;
        } else {
          it->second += 1;
        }
      } else {
        subcate_map.insert(std::make_pair(item.sub_category, 1));
      }
    }
    wd_items->push_back(item);
    if (parent_id != 0) {
      topn_dedup.insert(parent_id);
    }
  }
}


void RankModel::CalcWDScores(const std::string& category,
                             const std::vector<ItemInfo>& items,
                             std::vector<ModelData>* model_vec,
                             ModelExtraInfo* extra_info) {
  float tune = FLAGS_dislike_cate_num_tune_wd;
  if (reco_request_->prefer_categories.find(category) != reco_request_->prefer_categories.end()) {
    tune = FLAGS_prefer_cate_num_tune_wd;
  }

  // 计算预估队列
  std::vector<ItemInfo> wd_items;
  DecideWDPredictQueue(category, items, &wd_items, tune);
  // 预估
  if (wd_items.empty()
      || !wd_predictor_->BatchCalcWDScore(*reco_request_, category, &wd_items)) {
    for (int i = 0; i < (int)wd_items.size(); ++i) {
      wd_items[i].wd_text_score = 0;
    }
    extra_info->avg_wd = 0.001;
    return;
  }

  extra_info->avg_wd = 0.0f;
  for (int i = 0; i < (int)wd_items.size(); ++i) {
    extra_info->avg_wd += wd_items[i].wd_text_score;
  }
  extra_info->avg_wd = extra_info->avg_wd / wd_items.size() + 0.001;
  extra_info->avg_wd_punish = extra_info->avg_wd * FLAGS_punish_alter_wd;

  base::dense_hash_map<uint64, float> score_dict;
  score_dict.set_empty_key(0);
  for (size_t idx = 0; idx < wd_items.size(); ++idx) {
    const ItemInfo& item = wd_items.at(idx);
    uint64 pid = news_index_->GetParentId(item.item_id);
    score_dict.insert(std::make_pair(pid, item.wd_text_score));
  }
  for (size_t idx = 0; idx < model_vec->size(); ++idx) {
    uint64 pid = news_index_->GetParentId(items[idx].item_id);
    const auto iter = score_dict.find(pid);
    ModelData& data = model_vec->at(idx);
    if (iter != score_dict.end()) {
      data.wd_text_score = iter->second;
    } else {
      data.wd_text_score = 0;
    }
  }
}


// void CalcPersonalLrScores(const std::string& category,
//                           const std::vector<ItemInfo>& items,
//                           std::vector<ModelData>* model_vec,
//                           ModelExtraInfo* extra_info) {
//   //// NOTE(jianhuang) 这用法太扯，暂时不要该模型，后续升级
//   // std::string suff = category;
//   // if (reco_request_->channel_id != 100) GetVerticleCategory(reco_request_->channel_id, &suff);
//   // if (category.empty()) return;
// 
//   // const std::string model_prefix = "Uid_" + base::Uint64ToString(user_id) + "_ITag_" + suff + "_label:";
//   // const dawgdic::Dictionary* model
//   //     = reco::reco_model::RankModelProc::Instance()->GetActivePersonalModel(user_id);
//   // const std::vector<double>*
//   //     weight = reco::reco_model::RankModelProc::Instance()->GetActivePersonalWeight(user_id);
//   // bool has_user_model = false;
//   // dawgdic::BaseType model_index = 0;
//   // if (model) {
//   //   model_index = model->root();
//   //   has_user_model = model->Follow(model_prefix.c_str(), &model_index);
//   // }
// 
//   // for (int i = 0; i < user_group_predict_num; ++i) {
//   //   if (reco_items->size() >= dynamic_traverse_num) {
//   //     VLOG(1) << "reach max num in ranking: " << category;
//   //     break;
//   //   }
//   //   ItemInfo& item_info = reco_items->at(i);
//   //   debug_items.push_back(item_info);
//   //   float ir_score = std::min(1.0f, item_info.reco_score * 1.0f / kRecoScoreFactor);
//   //   // personal lr
//   //   bool hit_personal_lr = false;
//   //   if (has_user_model && modify_num > 0) {
//   //     modify_num -= 1;
//   //     reco::FeatureVector fv;
//   //     news_index_->GetFeatureVectorByItemId(item_info.item_id, reco::common::kTag, &fv);
//   //     bool hit_fea = false;
//   //     for (int idx = 0; idx < fv.feature_size(); ++idx) {
//   //       double score = 0.0;
//   //       // 所以这里再 follow 的时候要加上 6
//   //       Predict(model, weight, model_index, fv.feature(idx).literal().c_str() + 6, &score);
//   //       VLOG(1) << "exp weight must > 0  : " << fv.feature(idx).literal() << "|" << score;
//   //       if (score > 0) {
//   //         if (score > FLAGS_prec_threshold && FLAGS_add_weight > 0 && ir_score > FLAGS_ctr_thres) {
//   //           ir_score = std::min(1.0, ir_score + FLAGS_add_weight);
//   //           VLOG(1) << "add_weight : " << ir_score;
//   //           prec_num += 1;
//   //         } else {
//   //           ir_score = ir_score * (1 + score);
//   //         }
// 
//   //         hit_fea = true;
//   //         hit_personal_lr = true;
//   //         VLOG(1) << "hit_feature : " << fv.feature(idx).literal() << " ir_score : " << ir_score
//   //                 << " itemid:" << item_info.item_id;
//   //         break;
//   //       }
//   //     }
//   //     // 没命中的一样加权
//   //     if (!hit_fea) ir_score = ir_score * (1 + FLAGS_prec_base);
//   //   }
//   // }
// }

}
}

