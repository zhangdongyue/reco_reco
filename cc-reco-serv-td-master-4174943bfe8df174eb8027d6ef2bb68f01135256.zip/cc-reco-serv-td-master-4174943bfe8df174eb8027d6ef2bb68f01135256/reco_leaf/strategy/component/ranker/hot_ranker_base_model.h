#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/random/pseudo_random.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/rough_predictor.h"

namespace reco {
class RecoRequest;
class UserFeature;

namespace user {
class UserInfo;
}

namespace leafserver {

class RecommendRequest;
class CandidatesExtractor;


const int32 kHotFeatureSize = 9;

class HotPredict {
 public:
  explicit HotPredict(const reco::NewsIndex* index);
  ~HotPredict() {};
 public:
  void SetUserFea(const RecoRequest* reco_request, UserFea &user_fea);
  float DoPredict(const UserFea &user_fea,
                  const ItemInfo &item_info,
                  reco::xgboost::RegTree::FVec &fvec_temp);
 private:
  int ExtractFea(const UserFea &user_fea,
                 const ItemInfo &item_info,
                 reco::xgboost::RegTree::FVec &features);

  void ExtractUserFea(const reco::FeatureVector& user_info, UserFea &user_fea, UserType user_type);
  void ExtractUserFea(const reco::CategoryFeatureVector& user_info,
                      UserFea &user_fea,
                      UserType user_type);
  float CalScore(const std::vector<std::pair<std::string, float> > fea_vec,
                 const UserFea& user_fea,
                 UserType user_type);
  float CalScore(const std::string& category,
                 const UserFea& user_fea,
                 UserType user_type);
 private:
  const reco::NewsIndex* news_index_;
};

}  // namespace leafserver
}  // namespace reco
