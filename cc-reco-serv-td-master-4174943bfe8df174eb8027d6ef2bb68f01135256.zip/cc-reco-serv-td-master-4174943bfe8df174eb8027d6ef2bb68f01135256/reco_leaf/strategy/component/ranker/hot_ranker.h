#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/random/pseudo_random.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/hot_ranker_base_model.h"

namespace reco {
class RecoRequest;
class UserFeature;

namespace user {
class UserInfo;
}

namespace leafserver {

class RecommendRequest;
class CandidatesExtractor;


class HotRanker {
 public:
  explicit HotRanker(const reco::NewsIndex* index);
  ~HotRanker();

  void InitChannelNameMap();
  void InitChannelCategoryMap();
  void InitChannelHotThresh();
  void InitCategoryTuning();

  // 可以强推多条 hot
  int GetChannelPrevReqHours(const reco::user::UserInfo* user_info,
                             const base::Time& current_time,
                             int64 channel_id);
  void Rank(const RecoRequest* reco_request, std::vector<ItemInfo>* reco_items);
  void RankForVertical(const RecoRequest* reco_request,
                       std::vector<ItemInfo>* return_items,
                       int return_num,
                       RecoContext* context);
  void GetTopCommonHot(const RecoRequest* reco_request,
                       const std::vector<ItemInfo>& reco_items,
                       std::vector<ItemInfo>* top_hot_items);

  void RankForComplex(const RecoRequest* reco_request,
                      std::vector<ItemInfo>* reco_items,
                      int return_num);

  void SplitTopCommonHot(const RecoRequest* reco_request,
                         const std::vector<ItemInfo>& reco_items,
                         std::vector<ItemInfo>* top_hot_items,
                         std::vector<ItemInfo>* common_hot_items);

  void MergeTopCommonHot(const RecoRequest* reco_request,
                         const std::vector<ItemInfo>& top_hot_items,
                         const std::vector<ItemInfo>& common_hot_items,
                         std::vector<ItemInfo>* ret_hot_items);

  bool MeetTopHotTime(const ItemInfo& item, const base::Time& reco_item) const;
  bool MeetCommonHotTime(const ItemInfo& item, const base::Time& reco_item) const;

  bool MeetComplexHotTime(const ItemInfo& item, const base::Time& reco_item) const;
  void RankTopHotItems(const RecoRequest* reco_request,
                       std::vector<ItemInfo>* hot_items);

  void RankCommonHotItemsBaseModel(const RecoRequest* reco_request,
                                   std::vector<ItemInfo>* common_items);
  void PrintDebugInfo(const std::vector<ItemInfo>& items,
                      const std::string& prefix,
                      size_t max_print) const;

  bool IfNoImage(const reco::ItemInfo &item_info) const;

  void OuterHotControl(const int64 channel_id,
                       std::vector<ItemInfo>* return_items,
                       int limit_num,
                       double limit_thresh);
 private:
  bool DedupByKeywords(const reco::FeatureVector& keywords, int32 each_screen_item_num,
                       const std::unordered_map<std::string, int32>& keywords_appear_dict) const;
 private:
  static const int kRecoScoreFactor = 1000000;
  static const uint32 kTopNSize = 200;
  static const double kDefaultThresh = 40;

  std::unordered_map<std::string, int64> channel_name_map_;
  std::unordered_map<int64, std::string> channelId_category_map_;
  std::unordered_map<int64, double> channel_hot_thresh_;
  std::unordered_map<std::string, double> first_category_tuning_map_;
  std::unordered_map<std::string, double> sub_category_tuning_map_;

  base::dense_hash_set<uint64> item_dedup_;

  const reco::NewsIndex* news_index_;
  HotPredict* hot_predict_;
  CandidatesExtractor* candidates_extractor_;

  base::PseudoRandom* random_;
};

inline bool HotRanker::IfNoImage(const reco::ItemInfo &item_info) const {
  int image_num = news_index_->GetImageCountByDocId(item_info.doc_id);
  return image_num < 1;
}
}  // namespace leafserver
}  // namespace reco
