#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/random/pseudo_random.h"


namespace reco {
class RecoRequest;
class UserFeature;
class UserInfo;

namespace leafserver {

class RecommendRequest;

class PicRanker {
 public:
  explicit PicRanker(const reco::NewsIndex* index);
  ~PicRanker();

  void Rank(const RecoRequest* reco_request, std::vector<ItemInfo>* reco_items);
  void PrintDebugInfo(const std::vector<ItemInfo>& items,
                      const std::string& prefix,
                      size_t max_print) const;
 private:
  static const int kRecoScoreFactor = 1000000;
  static const uint32 kTopNSize = 200;
  base::dense_hash_set<uint64> item_dedup_;
  const reco::NewsIndex* news_index_;
};

}  // namespace leafserver
}  // namespace reco
