#include <vector>
#include <string>

#include "base/testing/gtest.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/common/wrapped_category.h"
#include "reco/bizc/reco_index/mock_index_builder.h"
#include "reco/serv/reco_leaf/strategy/component/cache/reco_result_cache.h"
#include "reco/serv/reco_leaf/proto/leaf_data.pb.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

namespace reco {
namespace leafserver {

TEST(RecoResultCacheTest, cache) {
  MockIndexBuilder builder;
  std::vector<reco::ItemInfo> items;
  for (int i = 0; i < RecoResultCache::kMaxCacheItemNum; ++i) {
    builder.AddDoc(reco::kNews, i+1,
                    base::StringPrintf("title-%d", i),
                   "体育", "sina", "title");

    reco::ItemInfo item;
    item.item_type = reco::kNews;
    item.item_id = i+1;
    item.category = "体育";
    items.push_back(item);
  }
  builder.BuildIndex("./",
                      "ads_index/api/data/static_dict.dat");
  const reco::NewsIndex* index = builder.GetNewsIndex();

  reco::UserIdentity user;
  user.set_app_token("uc");
  user.set_outer_id("1");
  user.set_user_id(1L);

  reco::UserInfo user_info;
  user_info.mutable_identity()->CopyFrom(user);

  reco::leafserver::RecommendRequest request;
  request.set_reco_id("1");
  request.set_app_token("uc");
  request.mutable_user()->CopyFrom(user);
  request.set_return_num(5);
  request.set_recommend_type(0);

  std::vector<std::pair<float, reco::Category> > category_dist;
  category_dist.push_back(std::make_pair(1.0, common::WrappedCategory("体育").ToCategory()));

  reco::leafserver::RecoRequest reco_request;
  reco_request.Reset(&request, &user_info, NULL, NULL, &category_dist);
  // redis = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);

  RecoResultCache cache(index);
  ASSERT_TRUE(cache.SetCachedItems(&reco_request, items));

  CachedNewsRecoData cached_results;
  cache.GetCachedItems(&reco_request, &cached_results);
  ASSERT_TRUE(cached_results.IsInitialized());
  ASSERT_EQ(cached_results.category_distribution_size(), (int)category_dist.size());
  for (int i = 0; i < cached_results.category_distribution_size(); ++i) {
    ASSERT_EQ(cached_results.category_distribution(i).category(), category_dist[i].second.category());
  }
  for (int i = 0; i < RecoResultCache::kMaxCacheItemNum; ++i) {
  }
}

}  // namespace leafserver
}  // namespace reco
