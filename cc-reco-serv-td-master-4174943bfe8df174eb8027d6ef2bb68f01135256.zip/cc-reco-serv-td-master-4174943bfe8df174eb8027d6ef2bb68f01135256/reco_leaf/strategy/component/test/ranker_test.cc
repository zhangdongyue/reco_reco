#include <fstream>
#include <iostream>
#include <string>
#include "base/testing/gtest.h"
#include "reco/bizc/reco_index/mock_index_builder.h"
#include "reco/bizc/reco_index/news_index.h"
#include "base/file/scoped_temp_dir.h"
#include "base/time/time.h"
#include "base/common/sleep.h"
#include "base/random/pseudo_random.h"
#include "base/strings/string_number_conversions.h"
#include "serving_base/utility/time_helper.h"

#include "reco/serv/reco_leaf/strategy/component/ranker/news_ranker.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/jingpin_ranker.h"

namespace reco {
namespace leafserver {
// TODO(xielang): 所有需要 index 做 test 的目录是否可以用一个？用一个 flag 来
DEFINE_string(test_ranker_index_dir, "./data", "test candidates index dir");
class JingpinRankerTest: public testing::Test {
 protected:
  virtual void SetUp() {
    now_ = base::Time::Now();
    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(1);
      item.mutable_identity()->set_outer_id("item1");
      item.mutable_identity()->set_type(reco::kNews);
      item.set_is_valid(true);

      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("title1");
      item.set_content("content1");
      item.set_source("sina");
      item.add_category("社会");
      item.add_channel_id(reco::common::kHotChannelId);

      builder_.AddDoc(item);
    }

    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(2);
      item.mutable_identity()->set_outer_id("item2");
      item.mutable_identity()->set_type(reco::kNews);
      item.set_is_valid(true);

      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("title2");
      item.set_content("content2");
      item.set_source("sohu");
      item.add_category("社会");
      item.add_channel_id(reco::common::kHotChannelId);

      builder_.AddDoc(item);
    }

    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(3);
      item.mutable_identity()->set_outer_id("item3");
      item.mutable_identity()->set_type(reco::kNews);
      item.set_is_valid(true);

      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("title3");
      item.set_content("content3");
      item.set_source("sina");
      item.add_category("体育");
      item.add_channel_id(reco::common::kSportChannelId);

      builder_.AddDoc(item);
    }

    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(4);
      item.mutable_identity()->set_outer_id("item4");
      item.mutable_identity()->set_type(reco::kNews);
      item.set_is_valid(true);

      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("title4");
      item.set_content("content4");
      item.set_source("sohu");
      item.add_category("体育");
      item.add_channel_id(reco::common::kSportChannelId);

      builder_.AddDoc(item);
    }
    builder_.BuildIndex(FLAGS_test_ranker_index_dir,
                        "ads_index/api/data/static_dict.dat");
    news_index_ = builder_.GetNewsIndex();
    CHECK_NOTNULL(news_index_);
    BuildRecoRequest();
  }

  virtual void TearDown() {
    delete news_index_;
    delete index_;
  }

  void BuildRecoRequest() {
    reco::UserIdentity user;
    user.set_app_token("uc");
    user.set_outer_id("1");
    user.set_user_id(1L);

    RecommendRequest* request = new RecommendRequest();
    request->set_reco_id("1");
    request->set_app_token("uc");
    request->mutable_user()->CopyFrom(user);
    request->set_recommend_type(0);
    request->set_return_num(10);
    reco_request_.request = request;
    request = NULL;

    reco::UserInfo* user_info = new reco::UserInfo();
    reco_request_.user_info = user_info;
    user_info->mutable_identity()->CopyFrom(reco_request_.request->user());
    reco::ViewClickItem* click_item = user_info->add_shown_history();
    click_item->set_item_id(0);
    click_item->set_item_type(reco::kNews);
    user_info = NULL;

    reco_request_.user_feas = NULL;
    base::dense_hash_set<uint64>* shown_dict = new base::dense_hash_set<uint64>();
    reco_request_.shown_dict = shown_dict;
    shown_dict = NULL;

    reco_request_.category_distributes = NULL;

    reco_request_.is_update_req = false;
    reco_request_.is_today_req = false;
    reco_request_.req_news_date = base::Time::Now();
    reco_request_.current_time = base::Time::Now();
    reco_request_.current_timestamp = static_cast<uint64>(reco_request_.current_time.ToDoubleT() * 1000000);

    serving_base::TimeHelper::StringToTimestamp("2016-01-01 00:00:00", "%Y-%m-%d %H:%M:%S",
                                                reinterpret_cast<uint64*>(&(reco_request_.start_news_timestamp)));  // NOLINT
    // 因为在 一千年以后 世界早已没有我
    serving_base::TimeHelper::StringToTimestamp("3016-01-01 00:00:00", "%Y-%m-%d %H:%M:%S",
                                                reinterpret_cast<uint64*>(&(reco_request_.end_news_timestamp))); // NOLINT

    reco_request_.channel_id = reco::common::kHotChannelId;
  }

  std::vector<reco::RecoItem> items_;
  adsindexing::DynamicIndex* index_;
  const reco::NewsIndex* news_index_;
  base::Time now_;

  MockIndexBuilder builder_;

  RecoRequest reco_request_;
};

TEST_F(JingpinRankerTest, TestGetCandidatesByCategory) {
  std::vector<ItemInfo> candidates;
  std::vector<ItemInfo> reco_items;

  CandidatesExtractor extractor(news_index_);
  JingpinRanker ranker(news_index_);
  struct {
    std::string category_str;
    std::string candidates_str;
  } cases[] {
    {"社会", "1,2"},
    {"体育", "3,4"},
  };
  int n = ARRAYSIZE_UNSAFE(cases);
  std::vector<std::string> flds;

  for (int i = 0; i < n; ++i) {
    flds.clear();
    base::SplitString(cases[i].category_str, ",", &flds);
    ASSERT_GT(3u, flds.size());
    ASSERT_GT(flds.size(), 0u);
    reco::Category category;
    category.set_level(0);
    category.set_category(flds[0]);

    extractor.GetCandidatesByCategory(category, &reco_request_, &candidates, 10, NULL);
    ranker.Rank(flds[0], reco_request_, candidates, &reco_items);
    ASSERT_GT(reco_items.size(), 0u);
  }
}
}
}
