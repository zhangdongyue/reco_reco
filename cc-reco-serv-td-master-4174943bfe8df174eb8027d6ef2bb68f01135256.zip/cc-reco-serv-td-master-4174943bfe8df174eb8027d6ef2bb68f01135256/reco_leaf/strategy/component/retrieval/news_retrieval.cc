#include "reco/serv/reco_leaf/strategy/component/retrieval/news_retrieval.h"

#include <algorithm>
#include <utility>
#include <functional>

#include "reco/serv/reco_leaf/strategy/common/topn.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/common/item_level_define.h"
#include "serving_base/data_manager/data_manager.h"
#include "serving_base/utility/timer.h"

#include "base/time/timestamp.h"
#include "base/hash_function/term.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "base/random/pseudo_random.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/serv/reco_leaf/frame/inner/dynamic_dict_container.h"

namespace reco {
namespace leafserver {
DEFINE_bool(open_ir_strategy, false, "是否打开直接触发的策略分支");
DEFINE_int32(deep_user_click_threshold, 15, "deep user click threshold");
DEFINE_int32(deep_user_new_pr_threshold, 10, "new pr分数阈值, 大于阈值分的下发给深度用户");
DEFINE_int32(normal_user_new_pr_threshold, 20, "new pr分数阈值, 大于阈值分的全量下发");

const float NewsRetrieval::kMinCtrThres = 0.001;

NewsRetrieval::NewsRetrieval(const reco::NewsIndex* index) : news_index_(index) {
  GlobalData* global_data = LeafDataManager::GetGlobalData();
  channel_categories_ = &global_data->channel_categories;
}

NewsRetrieval::~NewsRetrieval() {
}

void NewsRetrieval::RetrieveInChannel(int64 channel_id,
                                      const RecoRequest* request,
                                      const std::vector<ItemInfo>& manual_items,
                                      const std::vector<ItemInfo>& candidates,
                                      std::vector<ItemInfo>* ir_results) {
  if (manual_items.empty() && candidates.empty()) return;

  // 直接插入运营结果
  for (auto idx = 0u; idx < manual_items.size(); ++idx) {
    ir_results->push_back(manual_items[idx]);
    ItemInfo& item_info = ir_results->back();
    item_info.reco_score = CalcRawRecoScore(item_info);
  }
  LOG_EVERY_N(INFO, 2000) << "retrival_channel_manual:" << channel_id << ", " << ir_results->size();

  // 如果没有指定类别，所有的候选都可以放入 ir 结果中
  auto channel_iter = channel_categories_->find(channel_id);
  if (channel_iter == channel_categories_->end()) {
    LOG_EVERY_N(INFO, 2000) << "can't find channel in dict:" << channel_id;
    for (auto idx = 0u; idx < candidates.size(); ++idx) {
      ir_results->push_back(candidates[idx]);
      ItemInfo& item_info = ir_results->back();
      item_info.reco_score = CalcRawRecoScore(item_info);
    }
    return;
  }

  // 从候选集中获取类别符合的文章，分类别触发
  std::vector<std::string> flds;
  std::unordered_set<std::string> dedup_categories;
  std::vector<ItemInfo> category_manual_items;
  std::vector<ItemInfo> category_items;
  category_items.reserve(candidates.size());
  const std::vector<std::pair<std::string, float> >& categories = channel_iter->second;
  for (size_t i = 0; i < categories.size(); ++i) {
    flds.clear();
    base::SplitString(categories[i].first, "-", &flds);
    if (flds.empty()) continue;
    // 获取该类别下的 item
    const std::string& category = flds[0];
    if (dedup_categories.find(category) != dedup_categories.end()) continue;
    dedup_categories.insert(category);
    category_items.clear();
    for (size_t j = 0; j < candidates.size(); ++j) {
      const ItemInfo& item_info = candidates[j];
      if (item_info.category == category) {
        category_items.push_back(item_info);
      }
    }
    // 按类别触发
    if (!category_items.empty()) {
      // NOTE(jianhuang) NewRetrievalInCategory 不能 clear ir_results
      RetrieveInCategory(category, request, category_manual_items, category_items, ir_results);
    }
  }
}

void NewsRetrieval::RetrieveInCategory(const std::string& category,
                                       const RecoRequest* request,
                                       const std::vector<ItemInfo>& manual_items,
                                       const std::vector<ItemInfo>& candidates,
                                       std::vector<ItemInfo>* ir_results) {
  if (manual_items.empty() && candidates.empty()) return;

  base::dense_hash_map<std::string, double> category_tag_map;
  category_tag_map.set_empty_key("");
  auto cate_tag_iter = request->user_feas->merged_fea.cate_tags.find(category);
  if (cate_tag_iter != request->user_feas->merged_fea.cate_tags.end()) {
    for (auto i = cate_tag_iter->second.begin(); i != cate_tag_iter->second.end(); ++i) {
      if (i->second >= 0.05) {
        if (i->first.find("label::") == 0) {
          category_tag_map.insert(std::make_pair(i->first.substr(7), i->second));
        } else if (i->first.find("label:") == 0) {
          category_tag_map.insert(std::make_pair(i->first.substr(6), i->second));
        }
      }
      VLOG(2) << "deep user:" << i->first << ", " << i->second;
    }
  }

  auto raw_cate_iter = request->user_feas->merged_fea.raw_l1_cates.find(category);
  UserDeepLevel user_deep_level = NewUser;
  if (raw_cate_iter != request->user_feas->merged_fea.raw_l1_cates.end()) {
    uint32 cate_index = 0;
    // 该类别在用户 profile 中的 index
    for (auto traversal_iter = request->user_feas->merged_fea.raw_l1_cates.begin();
         traversal_iter != request->user_feas->merged_fea.raw_l1_cates.end(); ++traversal_iter) {
      if (traversal_iter->second > raw_cate_iter->second) {
        ++cate_index;
      }
    }

    if(raw_cate_iter->second >= FLAGS_deep_user_click_threshold && cate_index <= 2) {
      user_deep_level = DeepUser;
    } else if (raw_cate_iter->second >= 1) {
      user_deep_level = NormalUser;
    }
  }

  // calc ir info
  for (size_t i = 0; i < manual_items.size(); ++i) {
    if (!category.empty() && manual_items[i].category != category) continue;
    ir_results->push_back(manual_items[i]);
    ItemInfo& item_info = ir_results->back();
    item_info.reco_score = CalcRawRecoScore(item_info);
    FillIrInfo(request, category, category_tag_map, user_deep_level, &item_info);
  }
  LOG_EVERY_N(INFO, 1000) << "retrival_category_manual: " << category << " , " << ir_results->size();

  for (size_t i = 0; i < candidates.size(); ++i) {
    ir_results->push_back(candidates[i]);
    ItemInfo& item_info = ir_results->back();
    item_info.reco_score = CalcRawRecoScore(item_info);
    FillIrInfo(request, category, category_tag_map, user_deep_level, &item_info);
  }
}

inline void NewsRetrieval::FillIrInfo(const RecoRequest* request,
                                      const std::string& category,
                                      const base::dense_hash_map<std::string, double>& category_tag_map,
                                      UserDeepLevel user_deep_level,
                                      ItemInfo* item) {
  if (!FLAGS_open_ir_strategy) return;
  auto const& subscript_words = request->user_feas->behavior_fea.subscript_words;
  auto const& subscript_sources = request->user_feas->behavior_fea.subscript_sources;
  // if (subscript_words.empty() && subscript_sources.empty()) return;

  // 是否需要去深入做 retr
  if (!ItemMeetIrCondition(*item)) return;
  // 订阅源
  CalcSubscriptSourceIrInfo(subscript_sources, item);
  // 订阅关键词
  CalcSubscriptTagIrInfo(subscript_words, item);
  // 精品
  CalcJingpinIrInfo(item);
  // 深度用户标签
  if (user_deep_level == DeepUser && category == "科技") {
    CalcDeepUserTagIrInfo(category_tag_map, item);
  }
 // 高Pr的下发
  if (category == "科技") {
    CalcHighPrIrInfo(item, user_deep_level);
  }
}

inline void NewsRetrieval::CalcJingpinIrInfo(ItemInfo* item) const {
  if (item->itemq < reco::kJingpinItemq) return;
  item->ir_type = reco::kJingpinIr;
  item->ir_word = item->category;
  item->ir_score = 0.4;
}

inline void NewsRetrieval::CalcSubscriptSourceIrInfo(
    const base::dense_hash_map<std::string, float>& subscript_sources,
    ItemInfo* item) const {
  std::string wemedia_person;
  if (!subscript_sources.empty()
      && item->is_source_wemedia
      && news_index_->GetWeMediaPersonByDocId(item->doc_id, &wemedia_person)
      && !wemedia_person.empty()) {
    auto const iter = subscript_sources.find(wemedia_person);
    if (iter != subscript_sources.end()) {
      item->ir_type = reco::kSubscriptSourceIr;
      item->ir_word = iter->first;
      item->ir_score = iter->second;
    }
  }
}

inline void NewsRetrieval::CalcSubscriptTagIrInfo(
    const base::dense_hash_map<std::string, float>& subscript_words,
    ItemInfo* item) const {
  if (subscript_words.empty()) return;
  std::vector<std::string> show_tags;
  //auto const tag_cate_dict = LeafDataManager::GetGlobalData()->reco_reason_tag_category.GetDict();
  auto dict = DM_GET_DICT(reco::dm::RecoReasonTagDict, DynamicDictContainer::kRecoReasonTagFile_);
  auto tag_cate_dict = &(dict->reco_reason_tag_category);
  if (news_index_->GetShowTagByDocId(item->doc_id, &show_tags)) {
    for (size_t idx = 0; idx != show_tags.size(); ++idx) {
      // 只取 top1 的 show tag
      if (idx != 0) break;
      const std::string& tag = show_tags.at(idx);
      // 是否在订阅集中
      auto const subscript_iter = subscript_words.find(tag);
      if (subscript_iter == subscript_words.end()
          || subscript_iter->second <= item->ir_score) continue;
      // tag 类别是否匹配
      auto const cate_iter = tag_cate_dict->find(tag);
      if (cate_iter == tag_cate_dict->end()
          || cate_iter->second.empty()
          || cate_iter->second.find(item->category) == cate_iter->second.end()) continue;
      // 填充
      item->ir_type = reco::kSubscriptWordIr;
      item->ir_word = tag;
      item->ir_score = subscript_iter->second;
    }
  }
  std::vector<std::string> event_tags;
  if (item->ir_word.empty()
      && news_index_->GetEventTagByDocId(item->doc_id, &event_tags)) {
    for (size_t idx = 0; idx != event_tags.size(); ++idx) {
      const std::string& tag = event_tags.at(idx);
      // 是否在订阅集中
      auto const subscript_iter = subscript_words.find(tag);
      if (subscript_iter == subscript_words.end()
          || subscript_iter->second <= item->ir_score) continue;
      // event tag 的匹配不依赖 tag-cate 词表
      // // tag 类别是否匹配
      // auto const cate_iter = tag_cate_dict->find(tag);
      // if (cate_iter == tag_cate_dict->end()
      //     || cate_iter->second.empty()
      //     || cate_iter->second.find(item->category) == cate_iter->second.end()) continue;
      // 填充
      item->ir_type = reco::kSubscriptEventIr;
      item->ir_word = tag;
      item->ir_score = subscript_iter->second;
      break;
    }
  }
}

void NewsRetrieval::CalcDeepUserTagIrInfo(
    const base::dense_hash_map<std::string, double>& category_tag_map,
    ItemInfo* item) const {
  if (item->ir_type != reco::kDefaultIrType) return;
  if (item->time_level != reco::kGoodTimeliness) return;
  if (item->is_source_wemedia) return;
  bool is_good_media = false;
  if ((item->is_source_wemedia && item->media_level >= reco::kGoodMedia)
      || (!item->is_source_wemedia && item->media_level >= reco::kNormalMedia)) is_good_media = true;
  if (!is_good_media) return;
  std::vector<std::string> show_tags;
  if (news_index_->GetShowTagByDocId(item->doc_id, &show_tags)) {
    for (size_t idx = 0; idx != show_tags.size(); ++idx) {
      // 只取 top3 的 show tag
      if (idx >= 3) break;
      const std::string& tag = show_tags.at(idx);
      auto const iter = category_tag_map.find(tag);
      if (iter == category_tag_map.end()) continue;
      // 填充
      item->ir_type = reco::kDeepUserTagIr;
      item->ir_word = tag;
      item->ir_score = iter->second;
      break;
    }
  }
  if (item->ir_type == reco::kDefaultIrType && item->strategy_type == reco::kManual) {
    item->ir_type = reco::kDeepUserManualIr;
    item->ir_score = 0.4;
  }
}

void NewsRetrieval::CalcHighPrIrInfo(ItemInfo* item, UserDeepLevel user_deep_level) const {
  if (item->new_pr >= FLAGS_normal_user_new_pr_threshold
      && user_deep_level >= NormalUser) {
    item->ir_type = reco::kHighPrIr;
    item->ir_score = float(item->new_pr) / 100.0;
  } else if (item->new_pr >= FLAGS_deep_user_new_pr_threshold
             && user_deep_level == DeepUser) {
    item->ir_type = reco::kDeepUserPrIr;
    item->ir_score = float(item->new_pr) / 100.0;
  }
}

void NewsRetrieval::ExtractIrDirectItems(const std::vector<ItemInfo>& ir_items,
                                         std::vector<ItemInfo>* direct_items,
                                         size_t max_return) {
  // 根据订阅的权重，要求直接触发的文章质量不能太差
  // TODO(jianhuang) 当前使用 ctr 作为文字质量的评判，后面升级考虑 itemq 和 媒体质量
  static const std::unordered_set<int> kDirectIrTypeSet = {
    reco::kSubscriptWordIr, reco::kSubscriptEventIr, kSubscriptSourceIr, kJingpinIr,
    reco::kDeepUserManualIr, reco::kDeepUserTagIr, reco::kDeepUserPrIr, reco::kHighPrIr,
  };
  static const int kDirectIrShowThres = 2000;
  std::vector<std::pair<float, size_t> > sort_vec;
  base::Time recent_day_time = base::Time::Now() - base::TimeDelta::FromHours(24);
  int64 recent_day_timestamp = recent_day_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  for (size_t idx = 0; idx < ir_items.size(); ++idx) {
    const ItemInfo& item = ir_items.at(idx);

    if (kDirectIrTypeSet.find(item.ir_type) == kDirectIrTypeSet.end())continue;

    float ir_score = item.ir_score;
    float score = ir_score * item.ctr;
    if (item.ir_type == kDeepUserManualIr
        || item.ir_type == kDeepUserTagIr) {
      score *= (1 + item.hot_level / 100.0);
    } else if (item.ir_type == reco::kHighPrIr) {
      score += 0.2;
      score *= (1 + item.ir_score);
    } else if (item.ir_type == reco::kDeepUserPrIr) {
      score *= (1 + item.ir_score);
    } else if (item.ir_type == kJingpinIr) {
      // 精品
      if (item.create_timestamp >= recent_day_timestamp
          || item.time_level == reco::kGoodTimeliness) {
        if (item.itemq == reco::kShenduItemq) {
          // 需要做一些控量：根据点击率
          float ctr_thresh = -0.1;
          if (item.show_num >= 1000000) {
            ctr_thresh = std::min(0.08, 0.03 + (item.show_num - 1000000) * 0.01 / 1000000);
          } else if (item.show_num >= 500000) {
            ctr_thresh = 0.02 + (item.show_num - 500000) * 0.01 / 500000;
          } else if (item.show_num >= 250000) {
            ctr_thresh = 0.01 + (item.show_num - 250000) * 0.01 / 250000;
          }
          if (item.ctr < ctr_thresh)  continue;
          // 深度优于精品
          score += 0.2;
        } else {
          if (item.ctr < 0.08)  continue;
        }
      } else if (item.time_level == reco::kMidTimeliness) {
        if (item.ctr < 0.12) continue;
        score *= 0.7;
      } else if (item.time_level == reco::kBadTimeliness) {
        if (item.ctr < 0.18) continue;
        score *= 0.3;
      }
    } else {
      // 订阅源和标签
      if (ir_score >= 0.9) {
        // 订阅分数很高，对时效性和 ctr 要求较低
        if (item.time_level == reco::kGoodTimeliness) {
          if (item.itemq >= reco::kJingpinItemq
              || item.show_num < kDirectIrShowThres) {
            // 精品一定要, 展现未充分的要
          } else if (item.ctr < 0.01) {
            // 展现充分但数据不好的不要
            continue;
          }
        } else if (item.time_level == reco::kMidTimeliness) {
          if (item.itemq < reco::kJingpinItemq
              && item.ctr < 0.04) continue;
          score *= 0.7;
        } else if (item.time_level == reco::kBadTimeliness) {
          if (item.itemq < reco::kJingpinItemq
              && item.ctr < 0.12) continue;
          score *= 0.3;
        }
        if (item.itemq >= reco::kJingpinItemq) score *= 1.5;
        // 加 1 是保证最近订阅的 tag 和 source，能够优先排出
        score += 1;

      } else if (ir_score >= 0.5) {
        if (item.time_level == reco::kGoodTimeliness) {
          if (item.itemq >= reco::kJingpinItemq
              || item.show_num < kDirectIrShowThres) {
            // 精品一定要, 展现未充分的要
          } else if (item.ctr < 0.02) {
            // 展现充分但数据不好的不要
            continue;
          }
        } else if (item.time_level == reco::kMidTimeliness) {
          if (item.itemq < reco::kJingpinItemq
              && item.ctr < 0.06) continue;
          score *= 0.7;
        } else {
          continue;
        }
        if (item.itemq >= reco::kJingpinItemq) score *= 1.5;
      } else {
        if (item.time_level == reco::kGoodTimeliness) {
          if (item.itemq >= reco::kJingpinItemq
              || item.show_num < kDirectIrShowThres) {
            // 精品一定要, 展现未充分的要
          } else if (item.ctr < 0.03) {
            // 展现充分但数据不好的不要
            continue;
          }
        } else if (item.time_level == reco::kMidTimeliness) {
          if (item.itemq < reco::kJingpinItemq
              && item.ctr < 0.08) continue;
          score *= 0.7;
        } else {
          continue;
        }
        if (item.itemq >= reco::kJingpinItemq) score *= 1.5;
      }
    }

    sort_vec.push_back(std::make_pair(score, idx));
  }

  if (sort_vec.empty()) return;
  std::sort(sort_vec.begin(), sort_vec.end(), std::greater<std::pair<float, size_t> >());

  // 同一 ir_type + ir_word 的 direct ir 条数不超过 1 条
  // 同一 ir_type 的 direct ir 条数不超过 2 条
  base::dense_hash_map<std::string, int> stat_dict;
  stat_dict.set_empty_key("");
  for (size_t idx = 0; idx < sort_vec.size(); ++idx) {
    if (direct_items->size() >= max_return) break;
    const ItemInfo& item = ir_items.at(sort_vec[idx].second);

    const std::string& str_irtype = base::IntToString(item.ir_type);
    auto type_iter = stat_dict.find(str_irtype);
    if (type_iter != stat_dict.end() && type_iter->second >= 2) continue;

    const std::string& type_word = str_irtype + "_" + item.ir_word;
    auto word_iter = stat_dict.find(type_word);
    if (word_iter != stat_dict.end() && word_iter->second >= 1) continue;

    direct_items->push_back(item);
    stat_dict.insert(std::make_pair(type_word, 1));
    if (type_iter == stat_dict.end()) {
      stat_dict.insert(std::make_pair(str_irtype, 1));
    } else {
      type_iter->second += 1;
    }
  }

  // 填充 strategy type
  for (size_t idx = 0; idx < direct_items->size(); ++idx) {
    ItemInfo& item = direct_items->at(idx);
    if (item.ir_type == reco::kSubscriptWordIr
        || item.ir_type == reco::kSubscriptEventIr) {
      item.strategy_type = reco::kSubscription;
    } else if (item.ir_type == reco::kSubscriptSourceIr) {
      item.strategy_type = reco::kSubscriptSource;
    } else if (item.ir_type == reco::kJingpinIr) {
      item.strategy_type = reco::kJingpin;
    } else if (item.ir_type == reco::kDeepUserTagIr) {
      item.strategy_type = reco::kDeepUserTag;
    } else if (item.ir_type == reco::kHighPrIr) {
      item.strategy_type = kNewPr;
    } else if (item.ir_type == reco::kDeepUserPrIr) {
      item.strategy_type = kNewPr;
    }
  }
}

}  // namespace reco_leaf
}
