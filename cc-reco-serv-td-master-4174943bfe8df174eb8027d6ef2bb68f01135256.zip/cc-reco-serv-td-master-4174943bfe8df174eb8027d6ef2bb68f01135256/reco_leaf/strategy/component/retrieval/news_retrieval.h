#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>
#include <utility>
#include <algorithm>

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/reco_index/item_info.h"
// #include "util/dtree/dtree.h"
#include "base/time/time.h"
#include "base/thread/blocking_var.h"

namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {
struct IrInfo {
  reco::IrType ir_type;
  std::string ir_word;
  float ir_score;
  std::vector<int32> ir_docs;
};

enum UserDeepLevel {
  NewUser = 0,
  NormalUser = 1,
  DeepUser = 2
};

class NewsRetrieval {
 public:
  explicit NewsRetrieval(const reco::NewsIndex* index);

  ~NewsRetrieval();

  void RetrieveInChannel(int64 channel_id,
                         const RecoRequest* request,
                         const std::vector<ItemInfo>& manual_items,
                         const std::vector<ItemInfo>& candidates,
                         std::vector<ItemInfo>* ir_results);

  void RetrieveInCategory(const std::string& category,
                          const RecoRequest* request,
                          const std::vector<ItemInfo>& manual_items,
                          const std::vector<ItemInfo>& candidates,
                          std::vector<ItemInfo>* ir_results);

  // 抽取 ir 直通车 item
  void ExtractIrDirectItems(const std::vector<ItemInfo>& ir_items,
                            std::vector<ItemInfo>* direct_items,
                            size_t max_return);

 private:
  int CalcRawRecoScore(const ItemInfo& item_info) const;
  void FillIrInfo(const RecoRequest* request,
                  const std::string& category,
                  const base::dense_hash_map<std::string, double>& category_tag_dict,
                  UserDeepLevel user_deep_level,
                  ItemInfo* item);
  void CalcSubscriptSourceIrInfo(const base::dense_hash_map<std::string, float>& subscript_sources,
                                 ItemInfo* item) const;
  void CalcSubscriptTagIrInfo(const base::dense_hash_map<std::string, float>& subscript_tags,
                              ItemInfo* item) const;
  void CalcJingpinIrInfo(ItemInfo* item) const;
  void CalcDeepUserTagIrInfo(const base::dense_hash_map<std::string, double>& category_tag_map,
                             ItemInfo* item) const;
  void CalcHighPrIrInfo(ItemInfo* item, UserDeepLevel user_deep_level) const;
  // 是否符合深入触发的条件
  bool ItemMeetIrCondition(const ItemInfo& item) const;

 private:
  typedef std::unordered_map<int64, std::vector<std::pair<std::string, float> > > ChannelCategoryMap;

  static const int kRecoScoreFactor = 1000000;
  static const int kMaxRetrItemNum = 20000;
  static const float kMinCtrThres;

  const ChannelCategoryMap* channel_categories_;

  const NewsIndex* news_index_;
};

inline int NewsRetrieval::CalcRawRecoScore(const ItemInfo& item_info) const {
  int reco_score = (item_info.ctr + kMinCtrThres) * kRecoScoreFactor;
  return std::min(kRecoScoreFactor - 1, reco_score);
}

inline bool NewsRetrieval::ItemMeetIrCondition(const ItemInfo& item) const {
  static const int kDirectIrShowThres = 2000;
  if (item.itemq >= reco::kJingpinItemq) {
    // 精品文章

  } else if (item.time_level == reco::kGoodTimeliness) {
    if (item.show_num >= kDirectIrShowThres && item.ctr < 0.01) return false;

  } else if (item.time_level == reco::kMidTimeliness) {
    if (item.show_num < kDirectIrShowThres || item.ctr < 0.05) return false;

  } else if (item.time_level == reco::kBadTimeliness) {
    if (item.show_num < kDirectIrShowThres || item.ctr < 0.1) return false;
  }

  if (item.item_type != reco::kNews
      && item.item_type != reco::kReading
      && item.item_type != reco::kPictureNews
      && item.item_type != reco::kPicture) return false;
  return true;
}
}
}

