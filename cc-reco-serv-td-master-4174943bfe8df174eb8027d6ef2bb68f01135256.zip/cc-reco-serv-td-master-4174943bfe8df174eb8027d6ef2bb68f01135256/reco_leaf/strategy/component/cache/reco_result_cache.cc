#include "reco/serv/reco_leaf/strategy/component/cache/reco_result_cache.h"

#include <algorithm>
#include <utility>
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

DEFINE_bool(news_reco_use_cache, false, "false 表示关闭缓存");
DEFINE_string(reco_cache_prefix, "LEAF_CACHE_TEST", "");

DEFINE_int64_counter(leaf, cache_forced_update_total, 0, "");

static std::string GetCacheKey(const int item_type, const uint64 user_id, const int64 channel_id,
                               const std::string& channel_tags,
                               const int life_stage = reco::kNoStage) {
  std::string cache_key;
  if (channel_tags.empty()) {
    // 老的缓存 key 不变
    cache_key = base::StringPrintf("%s_%d_%lu_%ld_%d",
                              FLAGS_reco_cache_prefix.c_str(), item_type, user_id, channel_id,
                              life_stage);
  } else {
    cache_key = base::StringPrintf("%s_%d_%lu_%ld_%d_%s",
                              FLAGS_reco_cache_prefix.c_str(), item_type, user_id, channel_id,
                              life_stage, channel_tags.c_str());
  }
  VLOG(1) << cache_key;
  return cache_key;
}

RecoResultCache::RecoResultCache(const reco::NewsIndex* index) {
  news_index_ = index;
}

RecoResultCache::~RecoResultCache() {
}

bool RecoResultCache::CanUseCache(const reco::leafserver::RecoRequest* reco_request) const {
  if (!FLAGS_news_reco_use_cache || FLAGS_cache_exp_seconds <= 0) {
    VLOG(1) << "don't use cache: flags close cache.";
    return false;
  }

  const reco::leafserver::RecommendRequest* request = reco_request->request;

  // Debug 请求不进行 cache
  if (request->reco_debug_param().enable_debug())
    return false;

  // 刷新请求及当天历史请求可以使用 cache
  bool filtered_by_date = false;
  if (request->has_news_date()) {
    base::Time req_news_date;
    if (!base::Time::FromStringInFormat(request->news_date().c_str(), "%Y-%m-%d", &req_news_date)) {
      filtered_by_date = true;
    } else {
      base::TimeDelta delta = reco_request->current_time - req_news_date;
      if (delta.InHours() > 24) {
        filtered_by_date = true;
      }
    }
  }

  if (filtered_by_date) {
    VLOG(1) << "don't use cache: filter by date:" << request->news_date();
    return false;
  }

  if (request->has_category()) {
    VLOG(1) << "don't use cache: has category";
    return false;
  }

  static const std::unordered_set<int64> kNotCacheChannels
      = {reco::common::kHotChannelId, reco::common::kLocalChannelId};

  if (request->has_channel_id() && kNotCacheChannels.find(request->channel_id()) != kNotCacheChannels.end()) {
    VLOG(1) << "don't use cache: is not chache chanenl, " << request->channel_id();
    return false;
  }

  if (request->has_query()) {
    VLOG(1) << "don't use cache: has query";
    return false;
  }

  if (request->get_user_error()) {
    VLOG(1) << "don't use cache: get user error";
    return false;
  }

  return true;
}

int64 RecoResultCache::GetUserFeatureTime(const UserInfo* user_info) const {
  int64 timestamp = 0;
  const int64 delta = 1 * base::Time::kMicrosecondsPerSecond;

  if (user_info->dislike_info_size() > 0) {
    const reco::user::ViewClickItem& item = user_info->dislike_info(user_info->dislike_info_size() - 1);
    timestamp = std::max(item.dislike_timestamp() - 1 * delta, timestamp);
  }

  const int factor = user_info->recent_click_size() > 20 ? 200 : 5;
  for (int i = user_info->recent_click_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& clicked_item = user_info->recent_click().Get(i);
    timestamp = std::max(clicked_item.click_timestamp() - delta * factor, timestamp);
    break;
  }

  std::string time_str;
  if (user_info->has_user_role()) {
    if (time_str.empty() || user_info->user_role().setting_time() > time_str) {
      time_str = user_info->user_role().setting_time();
    }
  }
  if (user_info->has_channel_info()) {
    if (time_str.empty() || user_info->channel_info().setting_time() > time_str) {
      time_str = user_info->channel_info().setting_time();
    }
  }
  if (user_info->has_subscription()) {
    for (int i = 0; i < user_info->subscription().setting_time_size(); ++i) {
      if (time_str.empty() || user_info->subscription().setting_time(i) > time_str) {
        time_str = user_info->subscription().setting_time(i);
      }
    }
  }

  if (!time_str.empty()) {
    base::Time time;
    if (base::Time::FromStringInFormat(time_str.c_str(), "%Y-%m-%d %H:%M:%S", &time)) {
      const int64 t = (time.ToDoubleT() - 2) * base::Time::kMicrosecondsPerSecond;
      timestamp = std::max(t, timestamp);
    }
  }

  return timestamp;
}

void RecoResultCache::GetCachedItems(const reco::leafserver::RecoRequest* reco_request,
                                     CachedNewsRecoData *cached_results) const {
  const reco::leafserver::RecommendRequest* request = reco_request->request;
  const UserInfo* user_info = reco_request->user_info;

  // 获取缓存数据
  const int64 channel_id = request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId;
  const int life_stage = request->has_life_stage() ? request->life_stage() : reco::kNoStage;
  const uint64 user_id = user_info->identity().user_id();
  std::string channel_tags;
  if (request->channel_tags_size() > 0) {
    for (int i = 0; i < request->channel_tags_size(); ++i) {
      if (!channel_tags.empty()) channel_tags.push_back(',');
      channel_tags += request->channel_tags(i);
    }
  }
  const std::string key = GetCacheKey(reco::kNews, user_id, channel_id, channel_tags, life_stage);

  std::string value;
  if (!LeafCache::GetCachedReco(key, &value) || value.empty()) return;

  CachedNewsRecoData reco_data;
  if (!reco_data.ParseFromString(value)) {
    LOG(WARNING) << "fail to parse string to reco cache, " << value;
    return;
  }

  // 上次缓存后有用户行为发生，缓存失效
  const int64 newest_user_fea_timestamp = GetUserFeatureTime(user_info);
  if (newest_user_fea_timestamp > reco_data.timestamp()) {
    COUNTERS_leaf__cache_forced_update_total.Increase(1);
    return;
  }

  cached_results->Clear();
  cached_results->Swap(&reco_data);
}


bool RecoResultCache::SetCachedItems(const reco::leafserver::RecoRequest* reco_request,
                                     const std::vector<ItemInfo>& reco_items,
                                     const std::vector<std::string>* hit_tags) const {
  const reco::leafserver::RecommendRequest* request = reco_request->request;
  const UserInfo* user_info = reco_request->user_info;
  const std::vector<std::pair<float, reco::Category> >* category_distributes =
      reco_request->category_distributes;

  const int64 channel_id = request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId;
  const int life_stage = request->has_life_stage() ? request->life_stage() : reco::kNoStage;
  std::string channel_tags;
  if (request->channel_tags_size() > 0) {
    for (int i = 0; i < request->channel_tags_size(); ++i) {
      if (!channel_tags.empty()) channel_tags.push_back(',');
      channel_tags += request->channel_tags(i);
    }
  }

  // build CachedNewsRecoData
  CachedNewsRecoData reco_data;
  reco_data.set_timestamp(reco_request->current_timestamp);

  if (channel_id == reco::common::kRecoChannelId) {
    for (int i = 0; i <(int) category_distributes->size(); ++i) {
      CategoryDistribution* distribution = reco_data.add_category_distribution();
      distribution->set_category((*category_distributes)[i].second.category());
      distribution->set_ratio((*category_distributes)[i].first);
    }
  }

  for (int i = 0; i < kMaxCacheItemNum && i < (int)reco_items.size(); ++i) {
    const ItemInfo& item = reco_items[i];
    CachedItemMisc* item_misc = reco_data.add_item_misc();
    item_misc->set_item_id(item.item_id);
    item_misc->set_category(item.category);
    item_misc->set_strategy_type(item.strategy_type);
    item_misc->set_lr_score(item.lr_score);
    item_misc->set_fm_score(item.fm_score);
    item_misc->set_reco_score(item.reco_score);
    if (hit_tags != NULL && i < (int)hit_tags->size()) {
      item_misc->set_hit_tag(hit_tags->at(i));
    }
  }

  // put to cache
  const uint64 user_id = user_info->identity().user_id();
  const std::string key = GetCacheKey(reco::kNews, user_id, channel_id, channel_tags, life_stage);
  std::string value;
  if (!reco_data.SerializeToString(&value)) {
    LOG(WARNING) << "fail to serialize reco cache to string.";
    return false;
  }

  if (!LeafCache::SetCachedReco(key, value)) {
    LOG(WARNING) << "fail to write reco to cache, " << key << ", " << value;
    return false;
  }

  return true;
}

bool RecoResultCache::GetCachedRecoBranchData(const std::string& key,
                                              CachedRecoBranchData* cache_data) const {
  std::string value;
  if (!LeafCache::GetCachedReco(key, &value)) {
    return false;
  }

  CachedRecoBranchData reco_data;
  if (!reco_data.ParseFromString(value)) {
    LOG(WARNING) << "fail to parse string to reco cache, " << value;
    return false;
  }

  cache_data->Clear();
  cache_data->Swap(&reco_data);

  return true;
}

bool RecoResultCache::SetCachedRecoBranchData(const std::string& key,
                                              const CachedRecoBranchData& cache_data) const {
  std::string value;
  if (!cache_data.SerializeToString(&value)) {
    LOG(WARNING) << "fail to serialize reco cache to string.";
    return false;
  }

  if (!LeafCache::SetCachedReco(key, value)) {
    LOG(WARNING) << "fail to write reco to cache, " << key << ", " << value;
    return false;
  }

  return true;
}

}  // namespace leafserver
}  // namespace reco

