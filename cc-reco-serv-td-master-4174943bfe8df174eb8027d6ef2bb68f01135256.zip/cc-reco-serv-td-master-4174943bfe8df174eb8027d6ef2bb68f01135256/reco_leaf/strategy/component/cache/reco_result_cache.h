#pragma once

#include <string>
#include <vector>
#include <utility>
#include <cmath>
#include <unordered_set>

#include "serving_base/data_manager/data_manager.h"
#include "reco/bizc/reco_index/item_info.h"
#include "base/time/time.h"
#include "reco/serv/reco_leaf/proto/leaf_data.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "base/testing/gtest_prod.h"

namespace adsindexing {
class Index;
}

namespace base {
class PseudoRandom;
}

namespace reco {
class NewsIndex;

namespace leafserver {
class RecommendRequest;
class RecoRequest;

class RecoResultCache {
 public:
  explicit RecoResultCache(const reco::NewsIndex* index);
  ~RecoResultCache();

  bool GetCachedRecoBranchData(const std::string& key, CachedRecoBranchData* cache_data) const;
  bool SetCachedRecoBranchData(const std::string& key, const CachedRecoBranchData& cache_data) const;

  void GetCachedItems(const reco::leafserver::RecoRequest* request,
                      CachedNewsRecoData *cached_results) const;

  // hit tags 标签订阅保存命中的标签
  // 对其他频道取 NULL 即可
  bool SetCachedItems(const reco::leafserver::RecoRequest* request,
                      const std::vector<ItemInfo>& reco_items,
                      const std::vector<std::string>* hit_tags = NULL) const;

  bool CanUseCache(const reco::leafserver::RecoRequest* reco_request) const;

 private:

  int64 GetUserFeatureTime(const reco::user::UserInfo* user_info) const;

 private:
  static const int kMaxCacheItemNum = 50;
  FRIEND_TEST(RecoResultCacheTest, cache);

  const reco::NewsIndex* news_index_;
};

}  // namespace leafserver
}  // namespace reco

