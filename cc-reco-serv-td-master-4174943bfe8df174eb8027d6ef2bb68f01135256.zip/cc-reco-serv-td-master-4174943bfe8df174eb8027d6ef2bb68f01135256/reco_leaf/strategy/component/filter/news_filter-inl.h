#pragma once

#include <unordered_map>
#include <unordered_set>
#include <string>
#include <algorithm>
#include <vector>

#include "base/time/time.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/region/region_dict.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/serv/reco_leaf/frame/inner/dynamic_dict_container.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"

namespace reco {
namespace leafserver {

DECLARE_bool(do_title_len_filter);
DECLARE_bool(filter_all_dirty_item);
DECLARE_bool(filter_all_bluffing_item);

DECLARE_int32(source_media_safehour_begin);
DECLARE_int32(source_media_safehour_end);

DECLARE_bool(video_extra_source_media);

inline bool NewsFilter::IsTitleLengthFiltered(const RecommendRequest* request, const ItemInfo& item) {
  if (!FLAGS_do_title_len_filter) return false;

  // request 中的过滤条件
  if (request->has_filter_criterion()) {
    // 只对机器下发的新闻进行过滤
    if (item.strategy_type == reco::kManual
        || item.strategy_type == reco::kBanner) {
      return false;
    }

    // title 长度限制
    int title_len = news_index_->GetTitleLengthByDocId(item.doc_id);
    if (request->filter_criterion().title_min_len() > 0 &&
        title_len < (int)request->filter_criterion().title_min_len()) {
      VLOG(1) << "filter by min title length: " << title_len;
      return true;
    }
    if (request->filter_criterion().title_max_len() > 0 &&
        title_len > (int)request->filter_criterion().title_max_len()) {
      VLOG(1) << "filter by max title length: " << title_len;
      return true;
    }
  }
  return false;
}

inline bool NewsFilter::IsQualityFiltered(const RecoRequest& request, const ItemInfo& item,
                                          reco::ContentAttr* content_attr) {
  // video 暂时不走 quality 逻辑
  if (item.item_type == reco::kPureVideo) return false;

  if (news_index_->IsManualByDocId(item.doc_id)
      || item.strategy_type == reco::kCrowdOper
      || item.strategy_type == reco::kWholeCrowdOper) return false;

  static const std::unordered_set<int64> kAllowDirtyChanenlSet
      = {reco::common::kPictureChannelId, reco::common::kGirlChannelId,
        reco::common::kAnecdoteChannelId, reco::common::kBoudoirChannelId};
  static const std::unordered_set<std::string> kAllowDirtyCategorySet
      = {reco::common::kBoudoirCategory};
  bool is_trival = true;

  if (news_index_->GetContentAttrByDocId(item.doc_id, content_attr, &is_trival) && !is_trival) {
    // 当前区分大城市过滤不同的低质等级
    // TODO(jianhuang) 实验全部过滤
    reco::ContentAttr::ContentAttrLevel level_thres
        = request.user_param_info.is_main_city ? reco::ContentAttr::kSuspect : reco::ContentAttr::kSureYes;
    if (content_attr->has_erro_title()
        && content_attr->erro_title() >= level_thres) {
      return true;
    }

    if (content_attr->has_advertorial()
        && content_attr->advertorial() >= level_thres) {
      return true;
    }

    if (content_attr->has_short_content()
        && content_attr->short_content() >= level_thres) {
      return true;
    }

    if (content_attr->has_dedup_paragraph()
        && content_attr->dedup_paragraph() >= level_thres) {
      return true;
    }

    // NOTE(jianhuang) 标题党先只影响一线城市 / 新用户 / 对标题党反感
    // TODO(jianhuang) 影响太大的化，放开限制，后续在后处理限制下发条数
    if ((FLAGS_filter_all_bluffing_item
         || request.user_param_info.do_bluffing_filter)
        && content_attr->has_bluffing_title()
        && content_attr->bluffing_title() >= reco::ContentAttr::kSuspect) {
      VLOG(1) << "filtered by bluffing title: " << item.item_id;
      return true;
    }
    // NOTE(jianhuang) 低俗不下发：大城市 / 新用户 / 对低俗反感
    if ((FLAGS_filter_all_dirty_item
         || request.user_param_info.do_dirty_filter)
        && content_attr->has_dirty()
        && content_attr->dirty() >= reco::ContentAttr::kSuspect
        && (kAllowDirtyChanenlSet.find(request.channel_id) == kAllowDirtyChanenlSet.end()
            && kAllowDirtyCategorySet.find(item.category) == kAllowDirtyCategorySet.end())) {
      return true;
    }
  }
  return false;
}

inline bool NewsFilter::IsStrictQualityFiltered(const ItemInfo& item) {
  bool is_trival = true;
  reco::ContentAttr content_attr;
  if (news_index_->GetContentAttrByDocId(item.doc_id, &content_attr, &is_trival) && !is_trival) {
    if (content_attr.has_erro_title() && content_attr.erro_title() != reco::ContentAttr::kSureNo) {
      return true;
    }
    if (content_attr.has_advertorial() && content_attr.advertorial() != reco::ContentAttr::kSureNo) {
      return true;
    }
    if (content_attr.has_short_content() && content_attr.short_content() != reco::ContentAttr::kSureNo) {
      return true;
    }
    if (content_attr.has_dedup_paragraph() && content_attr.dedup_paragraph() != reco::ContentAttr::kSureNo) {
      return true;
    }
    if (content_attr.has_dirty() && content_attr.dirty() != reco::ContentAttr::kSureNo) {
      return true;
    }
    if (content_attr.has_politics() && content_attr.politics() != reco::ContentAttr::kSureNo) {
      return true;
    }
    if (content_attr.has_bluffing_title() && content_attr.bluffing_title() != reco::ContentAttr::kSureNo) {
      return true;
    }
    if (content_attr.has_negative() && content_attr.negative() != reco::ContentAttr::kSureNo) {
      return true;
    }
  }
  return false;
}

inline bool NewsFilter::IsSensitiveFiltered(const RecoRequest& reco_request, const ItemInfo& item) {
  if (item.sensitive_type == reco::kNoSensitive) return false;
  if (item.sensitive_type == reco::kCopyrightSensitive) return true;
  if (item.sensitive_type == reco::kHighPoliticsSensitive) return true;
  if (item.sensitive_type == reco::kPoliticsSensitive) return true;
  return false;
}

inline bool NewsFilter::IsDislikeBannerFiltered(const UserFeature* user_feas,
                                                const ItemInfo& item_info) {
  if (user_feas->behavior_fea.dislike_items.empty()) {
    return false;
  }
  for (int idx = 0; idx < (int)user_feas->behavior_fea.dislike_items.size(); ++idx) {
    if (user_feas->behavior_fea.dislike_items.at(idx).item_id == item_info.item_id) return true;
  }
  return false;
}

inline void NewsFilter::GetItemSimFeas(uint64 item_id, std::unordered_map<std::string, float>* reco_feas) {
  if (item_id == 0)
    return;

  // 获取 item 的 keyword 特征，用于本次推荐的相似性计算
  reco::FeatureVector kw_feas;
  if (!news_index_->GetFeatureVectorByItemId(item_id, reco::common::kKeyword, &kw_feas)) {
    LOG_EVERY_N(INFO, 100) << "get feature fail, itemid:" << item_id;
    return;
  }

  for (int i = 0; i < kw_feas.feature_size(); ++i) {
    const reco::Feature& fea = kw_feas.feature(i);
    (*reco_feas)[fea.literal()] += fea.weight();
  }
}

inline bool NewsFilter::ItemIsValid(const ItemInfo& item, int64 curr_timestamp) {
  if (!news_index_->IsValidByDocId(item.doc_id)) {
    return false;
  }
  if (news_index_->IsExpiredByItemId(item.item_id, curr_timestamp)) {
    return false;
  }
  return true;
}

inline bool NewsFilter::IsRegionRestrictFiltered(const ItemInfo& item, int64 prov_id, int64 city_id) {
  // 不对运营新闻做地域限制
  if (item.strategy_type == reco::kManual ||
      item.strategy_type == reco::kBanner) return false;

  // 获取地域信息失败、高热新闻及 sim 个数较多也需要过滤，由地域限制精度保证。
  std::vector<int64> restrict_region_ids;
  if (!news_index_->GetRestrictRegionIdByDocId(item.doc_id, &restrict_region_ids) ||
      restrict_region_ids.empty()) {
    return false;
  }

  bool region_matched = false;
  for (size_t i = 0; i < restrict_region_ids.size(); ++i) {
    if (restrict_region_ids[i] == prov_id || restrict_region_ids[i] == city_id) {
      region_matched = true;
      break;
    }
  }
  if (!region_matched) {
    VLOG(1) << "filtered by region restrict: " << item.item_id << ", " << item.ctr << ", "
            << item.show_num << ", " << item.hot_level;
    return true;
  }
  return false;
}

inline bool NewsFilter::IsLocalChannelFiltered(const ItemInfo& item, int64 region_id) {
  static const std::unordered_set<int64> kMainCityRegionIds = {10, 20, 21, 755, 571};
  static const std::unordered_set<std::string> kLocalRejectCategory = {"未分类"};

  bool is_main_city = (kMainCityRegionIds.find(region_id) != kMainCityRegionIds.end());
  if (is_main_city) {
    // 未分类的数据较杂，先扔掉
    if (kLocalRejectCategory.find(item.category) != kLocalRejectCategory.end()) {
      VLOG(1) << "local channel filter, category reject in main city: " << item.item_id;
      return true;
    }

    // 天气类的时效性不超过 24 小时
    bool has_weather_tag = false;
    reco::FeatureVector fea_vec;
    if (news_index_->GetFeatureVectorByItemId(item.item_id, reco::common::kSemanticTag, &fea_vec)) {
      for (int i = 0; i < fea_vec.feature_size(); ++i) {
        const reco::Feature& fea = fea_vec.feature(i);
        auto &tag_with_label = fea.literal();
        std::string tag = tag_with_label;
        if (base::StartsWith(tag_with_label, "label2:", true)) {
          tag = tag_with_label.substr(7);
        }
        if (tag == "天气") {
          has_weather_tag = true;
          break;
        }
      }
    }
    if (has_weather_tag) {
      if (item.time_level < reco::kGoodTimeliness) {
        VLOG(1) << "local channel filter, weather timeout: " << item.item_id;
        return true;
      }
    }
  }
  return false;
}

/*
inline bool NewsFilter::IsFilteredCategory(const reco::dm::QudaoBlacklistDict* blacklist,
                                           int filter_qudao_index, const std::string& category) {
  return blacklist->IsFilteredCategory(filter_qudao_index, category);
}
*/

/*
inline bool NewsFilter::IsFilteredByCategory(int filter_qudao_index,
                                             const reco::dm::QudaoBlacklistDict* blacklist,
                                             const RecoRequest* request, const ItemInfo& item) {
  bool is_reco_channel = request->channel_id == reco::common::kRecoChannelId;
  if (!is_reco_channel && item.sub_category.empty()) {
    return false;
  }

  return blacklist->qudao_black_category_[filter_qudao_index].Find(item.category, item.sub_category);
}
*/

/*
inline bool NewsFilter::IsFilteredByItemtype(int filter_qudao_index,
                                             const reco::dm::QudaoBlacklistDict* blacklist,
                                             const ItemInfo& item) {
  // 对于专题要判断子文
  if (kSpecial == item.item_type) {
    std::unordered_set<uint64> preview_ids;
    if (news_index_->GetPreviewIdsByItemId(item.item_id, &preview_ids)) {
      for (auto preview_iter = preview_ids.begin(); preview_iter != preview_ids.end(); ++preview_iter) {
        ItemType sub_item_type;
        if (news_index_->GetItemTypeByItemId(*preview_iter, &sub_item_type)) {
          if (blacklist->qudao_black_itemtype_[filter_qudao_index][sub_item_type]) {
            return true;
          }
        }
      }
    }
  }
  return blacklist->qudao_black_itemtype_[filter_qudao_index][item.item_type];
}
*/

/*
inline bool NewsFilter::IsFilteredByItemDirty(int filter_qudao_index,
                                              const reco::dm::QudaoBlacklistDict* blacklist, int doc_id) {
  if (!blacklist->qudao_black_dirty_[filter_qudao_index]) {
    return false;
  }

  ContentAttr content_attr;
  bool is_trival = true;
  if (news_index_->GetContentAttrByDocId(doc_id, &content_attr, &is_trival) && !is_trival) {
    if (content_attr.has_dirty()
        && content_attr.dirty() >= reco::ContentAttr::kSuspect) {
      return true;
    }
  }

  return false;
}
*/

/*
inline bool NewsFilter::IsFilteredByItemTitleParty(int filter_qudao_index,
                                              const reco::dm::QudaoBlacklistDict* blacklist, int doc_id) {
  if (!blacklist->qudao_black_title_party_[filter_qudao_index]) {
    return false;
  }

  ContentAttr content_attr;
  bool is_trival = true;
  if (news_index_->GetContentAttrByDocId(doc_id, &content_attr, &is_trival) && !is_trival) {
    if (content_attr.has_bluffing_title()
        && content_attr.bluffing_title() >= reco::ContentAttr::kSuspect) {
      return true;
    }
  }

  return false;
}
*/

/*
inline bool NewsFilter::IsFilteredBySourceWeMedia(int filter_qudao_index,
                                    const reco::dm::QudaoBlacklistDict* blacklist, const ItemInfo& item) {
  if (!blacklist->qudao_black_wemedia_[filter_qudao_index]) {
    return false;
  }

  return item.is_source_wemedia;
}
*/

/*
inline bool NewsFilter::IsFilteredByBlackPattern(int filter_qudao_index,
                                                 const reco::dm::QudaoBlacklistDict* blacklist,
                                                 uint64 item_id) {
  auto pattern = blacklist->qudao_black_pattern_[filter_qudao_index];
  if (NULL == pattern) {
    return false;
  }

  std::string title;
  if (!news_index_->GetItemTitleByItemId(item_id, &title)) {
    return false;
  }

  extend::MatchResult result;
  return pattern->Match(title.c_str(), title.size(), &result);
}
*/

inline bool NewsFilter::ChooseSourceMediaFilter(const ItemInfo& item,
                                                const RecoRequest* request,
                                                const std::unordered_map<uint64_t,
                                                reco::filter::RiskMediaInfo>& source_media_map) {
  if (request == NULL) {
    return true;
  }
  if (item.orig_media_risk_type < 1) {
    return true;
  } else {
    {
      auto iter = source_media_map.find(item.source_media_sign);
      if (iter != source_media_map.end()) {
        if (iter->second.level == reco::filter::RiskMediaInfo::kLevelHostile
            || iter->second.level == reco::filter::RiskMediaInfo::kLevelForbiden) {
          return true;
        }
      }
    }
    {
      auto iter = source_media_map.find(item.orig_source_media_sign);
      if (iter != source_media_map.end()) {
        if (iter->second.level == reco::filter::RiskMediaInfo::kLevelHostile
            || iter->second.level == reco::filter::RiskMediaInfo::kLevelForbiden) {
          return true;
        }
      }
    }
  }
  return false;
}
inline bool NewsFilter::IsFilteredBySourceMedia(const reco::filter::RiskMediaDict* source_media,
                                                const RecoRequest* request,
                                                const ItemInfo& item) {
  auto& source_media_map = source_media->risk_media_map;

  if (IsEnableSourceMediaFilter(item)) {
    if (item.is_source_wemedia) {  //  不过滤来自 UC 的自媒体
      return false;
    }

    if (IsFilteredSourceMedia(request, item.source_media_sign, source_media_map, item)) {
      VLOG(2) << "source media filtered 1:\t" << item.item_id;

      return true;
    }

    if (IsFilteredSourceMedia(request, item.orig_source_media_sign, source_media_map, item)) {
      VLOG(2) << "source media filtered 2:\t" << item.item_id;

      return true;
    }
  }

  if (item.item_type == reco::kPureVideo) {
    if (item.source_media_sign == special_source_media_) {
      return IsFilteredSpecialSourceMedia(request, item.source_media_sign, source_media_map, item);
    }
  }

  return false;
}

inline bool NewsFilter::IsEnableSourceMediaFilter(const ItemInfo& item) {
  if (FLAGS_video_extra_source_media &&
      item.item_type == reco::kPureVideo) {
    if (news_index_->HasVideoStorageInfoByItemId(item.item_id) &&
        news_index_->GetVideoStorageInfoStatusByItemId(item.item_id) == 1) {
      return false;
    }
  }
  return true;
}

inline bool NewsFilter::IsFilteredSpecialSourceMedia(const RecoRequest* request,
                                                     uint64 source_media_sign,
                                                     const std::unordered_map<uint64_t,
                                                     reco::filter::RiskMediaInfo>& source_media_map,
                                                     const ItemInfo& item) {
  auto iter = source_media_map.find(source_media_sign);
  if (iter == source_media_map.end()) {
    return false;
  }
  if (!news_index_->HasVideoStorageInfoByItemId(item.item_id)) {
    VLOG(2)  << "special source media no storage info";
    return true;
  }
  if (news_index_->GetHasReviewedByItemId(item.item_id)) {
    return false;
  }
  // 过滤为止城市和禁止城市
  if (request->user_param_info.is_unknow_city
      || iter->second.cities.Find(request->user_param_info.city)) {
    VLOG(2) << "source media unknow city";
    return true;
  }
  // 过滤大城市的非忠诚用户
  if (!request->user_param_info.is_loyal
      && request->user_param_info.is_main_city) {
    VLOG(2)  << "source media loyal main city";
    return true;
  }
  // 过滤非忠诚的 ios 用户
  if (!request->user_param_info.is_loyal && request->user_param_info.is_ios) {
    VLOG(2)  << "source media loyal ios";
    return true;
  }
  // 只在内部渠道
  if (!request->user_param_info.is_uc_iflow_qudao) {
    VLOG(2)  << "source media uc_iflow qudao";
    return true;
  }

  return false;
}

inline bool NewsFilter::IsFilteredByOrigMediaRiskType(const RecoRequest* request,
                                                      const ItemInfo& item) {
  if (item.orig_media_risk_type > 0) {
    if (NULL == request) {
      return false;
    }
    // 过滤没有自存储地址或者没有去水印的视频
    if (FLAGS_video_extra_source_media &&
        item.item_type == reco::kPureVideo) {
      if (!news_index_->HasVideoStorageInfoByItemId(item.item_id) ||
          news_index_->GetVideoStorageInfoStatusByItemId(item.item_id) != 1) {
        return true;
      }
    }
    // 过滤没有无线保镖的
    if (!request->user_param_info.wsg_enc) {
      VLOG(2)  << "source media wsg_enc";
      return true;
    }
    // 过滤未知城市
    if (request->user_param_info.is_unknow_city) {
      VLOG(2) << "source media unknow city";
      return true;
    }
    // 过滤大城市的非忠诚用户
    if (!request->user_param_info.is_loyal
        && request->user_param_info.is_main_city) {
      VLOG(2)  << "source media loyal main city";
      return true;
    }
    // 过滤非忠诚的 ios 用户
    if (!request->user_param_info.is_loyal && request->user_param_info.is_ios) {
      VLOG(2)  << "source media loyal ios";
      return true;
    }
    // 只在内部渠道
    if (!request->user_param_info.is_uc_iflow_qudao) {
      VLOG(2)  << "source media uc_iflow qudao";
      return true;
    }
  } else {
    return false;
  }
  return false;
}

inline bool NewsFilter::IsFilteredSourceMedia(const RecoRequest* request,
                                              uint64 source_media_sign,
                                              const std::unordered_map<uint64_t,
                                              reco::filter::RiskMediaInfo>& source_media_map,
                                              const ItemInfo& item) {
  auto iter = source_media_map.find(source_media_sign);
  if (iter == source_media_map.end()) {
    return false;
  }

  if (iter->second.level == reco::filter::RiskMediaInfo::kLevelNoRisk) {
    return false;
  }

  //  对 card 做特殊处理，因为 card 的 requeset 没有带 UcBrowserUserParam
  if (NULL == request) {
    return true;  //  没有对应用户参数则过滤所有 level >= 1 的
  }

  if (iter->second.level == reco::filter::RiskMediaInfo::kLevelUnAuth) {
    /*
    // 过滤未知城市和禁止城市
    if (request->user_param_info.is_unknow_city
        || iter->second.cities.Find(request->user_param_info.city)) {
      VLOG(2)  << "source media unknow city safetime";
      return true;
    }
    // 过滤非忠诚的用户在大城市在非安全时间使用
    if (!request->user_param_info.is_loyal
        && request->user_param_info.is_main_city
        && !SourceMediaIsSafeTime()) {
      VLOG(2) << "source media loyal main city safetime ";
      return true;
    }
    */
    if (!request->user_param_info.is_inner_qudao) {
      VLOG(2)  << "source media inner qudao";
      return true;
    }
  } else if (iter->second.level == reco::filter::RiskMediaInfo::kLevelHostile) {
    // 过滤没有自存储地址或者没有去水印的视频
    if (FLAGS_video_extra_source_media &&
        item.item_type == reco::kPureVideo) {
      if (!news_index_->HasVideoStorageInfoByItemId(item.item_id) ||
          news_index_->GetVideoStorageInfoStatusByItemId(item.item_id) != 1) {
        return true;
      }
    }
    // 过滤没有无线保镖的
    if (!request->user_param_info.wsg_enc) {
      VLOG(2)  << "source media wsg_enc";
      return true;
    }
    // 过滤为止城市和禁止城市
    if (request->user_param_info.is_unknow_city
        || iter->second.cities.Find(request->user_param_info.city)) {
      VLOG(2) << "source media unknow city";
      return true;
    }
    // 过滤大城市的非忠诚用户
    if (!request->user_param_info.is_loyal
        && request->user_param_info.is_main_city) {
      VLOG(2)  << "source media loyal main city";
      return true;
    }
    // 过滤非忠诚的 ios 用户
    if (!request->user_param_info.is_loyal && request->user_param_info.is_ios) {
      VLOG(2)  << "source media loyal ios";
      return true;
    }
    // 只在内部渠道
    if (!request->user_param_info.is_uc_iflow_qudao) {
      VLOG(2)  << "source media uc_iflow qudao";
      return true;
    }
  } else if (iter->second.level == reco::filter::RiskMediaInfo::kLevelForbiden) {
      VLOG(2)  << "source media last level";
      return true;
  }

  return false;
}

/*
inline bool NewsFilter::IsFilteredBySource(int filter_qudao_index,
                                    const reco::dm::QudaoBlacklistDict* blacklist,
                                    const ItemInfo& item) {
  auto white_source = blacklist->qudao_white_source_[filter_qudao_index];
  if (NULL == white_source) {
    return false;
  }

  std::string source;
  if (news_index_->GetSourceByItemId(item.item_id, &source)) {
    if (white_source->Find(source)) {
      return false;
    }
  }
  std::string orign_source;
  if (news_index_->GetOrigSourceByItemId(item.item_id, &orign_source)) {
    if (white_source->Find(orign_source)) {
      return false;
    }
  }
  return true;
}
*/

inline bool NewsFilter::SourceMediaIsSafeTime() {
  base::Time now = base::Time::Now();
  base::Time::Exploded exploded;
  now.LocalExplode(&exploded);
  int safehour_begin = FLAGS_source_media_safehour_begin;
  int safehour_end = FLAGS_source_media_safehour_end;
  if (safehour_begin > safehour_end) {
    if (exploded.hour >= safehour_begin || exploded.hour <= safehour_end) {
      return true;
    }
  } else {
    if (exploded.hour >= safehour_begin && exploded.hour <= safehour_end) {
      return true;
    }
  }

  return false;
}

/*
inline bool NewsFilter::IsFilteredByBlacklist(int filter_qudao_index,
                                              const reco::dm::QudaoBlacklistDict* blacklist,
                                              const reco::dm::SourceMediaDict* source_media,
                                              const RecoRequest* request,
                                              const ItemInfo& item,
                                              FilteredType* filtered_type) {
  if (IsFilteredBySourceMedia(source_media, request, item)) {
    *filtered_type = kBlacklistFiltered;
    return true;
  }

  if (-1 == filter_qudao_index) {
    return false;
  }

  if (IsFilteredByCategory(filter_qudao_index, blacklist, request, item)) {
    *filtered_type = kCategoryBlacklistFiltered;
    return true;
  }

  if (IsFilteredByItemtype(filter_qudao_index, blacklist, item)) {
    *filtered_type = kItemtypeBlacklistFiltered;
    return true;
  }

  if (IsFilteredByItemDirty(filter_qudao_index, blacklist, item.doc_id)) {
    *filtered_type = kDirtyBlacklistFiltered;
    return true;
  }

  if (IsFilteredByItemTitleParty(filter_qudao_index, blacklist, item.doc_id)) {
    *filtered_type = kBlacklistFiltered;
    return true;
  }

  if (IsFilteredBySourceWeMedia(filter_qudao_index, blacklist, item)) {
    *filtered_type = kBlacklistFiltered;
    return true;
  }

  if (IsFilteredByBlackPattern(filter_qudao_index, blacklist, item.item_id)) {
    *filtered_type = kBlacklistFiltered;
    return true;
  }

  if (IsFilteredBySource(filter_qudao_index, blacklist, item)) {
    *filtered_type = kBlacklistFiltered;
    return true;
  }

  return false;
}
*/

/*
inline int NewsFilter::FilterQudaoIndex(const reco::dm::QudaoBlacklistDict* blacklist,
                                        const std::string& qudao) {
  return blacklist->FilterQudaoIndex(qudao);
}
*/

/*
inline boost::shared_ptr<const reco::dm::QudaoBlacklistDict> NewsFilter::GetBlackList() {
  auto dict = DM_GET_DICT(reco::dm::QudaoBlacklistDict, DynamicDictContainer::kQudaoBlacklistFile_);
  return dict;
}
*/

inline bool NewsFilter::ReviewedFileter(const RecoRequest* reco_request, const ItemInfo &item) {
  if (reco_request->reviewed_filter_hit && !news_index_->GetHasReviewedByDocId(item.doc_id)) {
    return true;
  }

  return false;
}


inline bool NewsFilter::IsFilteredByNotVideoStorage(const RecoRequest* request, const ItemInfo &item) {
  if (item.is_source_wemedia) {
    return false;
  }

  if (!request->request->has_only_storage_video()
      || !request->request->only_storage_video()) {
    return false;
  }

  int video_count = news_index_->GetVideoCountByItemId(item.item_id);
  if (0 == video_count) {
    return false;
  }

  if (1 == video_count && news_index_->HasVideoStorageInfoByItemId(item.item_id)) {
    return false;
  }

  return true;
}


inline bool NewsFilter::PolicyFilter(const ItemInfo &item) {
  if (news_index_->IsManualByDocId(item.doc_id))
    return false;

  // 负面新闻过滤 negative filter
  reco::ContentAttr content_attr;
  bool is_trival = false;
  if (item.item_type != reco::kPureVideo
      && news_index_->GetContentAttrByDocId(item.doc_id, &content_attr, &is_trival)
      && is_trival != true) {
    if (content_attr.has_negative() && content_attr.negative() != reco::ContentAttr::kSureNo) {
      return true;
    }
  }

  // 源的黑白名单过滤
  std::string source;
  auto black_source_dict = LeafDataManager::GetGlobalData()->common_filter->black_source_dict->GetDict();
  auto white_source_dict = LeafDataManager::GetGlobalData()->common_filter->white_source_dict->GetDict();
  if (!black_source_dict->empty() || !white_source_dict->empty()) {
    if (news_index_->GetSourceByDocId(item.doc_id, &source)) {
      // 黑名单，找到就过滤
      if (!black_source_dict->empty() && (black_source_dict->find(source) != black_source_dict->end())) {
        return true;
      }

      // 白名单，不在就过滤
      if (!white_source_dict->empty() && (white_source_dict->find(source) == white_source_dict->end())) {
        return true;
      }
    }
  }

  // 政治类文章之下发指定源，白名单，如果指定源列表是空，就不做处理
  auto politics_source_dict =
      LeafDataManager::GetGlobalData()->common_filter->politics_source_dict->GetDict();
  if (!politics_source_dict->empty()) {
    reco::ContentAttr content_attr;
    bool is_trival = false;
    if (news_index_->GetContentAttrByDocId(item.doc_id, &content_attr, &is_trival) && is_trival != true) {
      if (content_attr.politics() != reco::ContentAttr::kSureNo
          && news_index_->GetSourceByDocId(item.doc_id, &source)
          && politics_source_dict->find(source) == politics_source_dict->end()) {
        return true;
      }
    }
  }

  return false;
}
}  // namespace leafserver
}  // namespace reco
