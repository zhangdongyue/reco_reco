#pragma once

#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "base/container/dense_hash_set.h"
#include "base/testing/gtest_prod.h"
#include "base/time/time.h"

#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/reco/offline/item_dict_manager.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
//#include "reco/serv/reco_leaf/strategy/component/filter/filter_dict.h"
//#include "reco/serv/reco_leaf/strategy/component/filter/dn_filter.h"
#include "reco/serv/reco_leaf/frame/inner/dynamic_dict_container.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/filter_rule.pb.h"
#include "reco/bizc/reco_index/item_info.h"

namespace reco {
namespace leafserver {

class NewsFilter {
 public:
  /////////////////////// 初始化
  static bool InitNewsFilter(const reco::NewsIndex* news_index);

  ////////////////////// 过滤器
  // 基本过滤
  static bool IsGeneralFiltered(const RecoRequest* request,
                                const base::dense_hash_set<uint64>* shown_dict,
                                const ItemInfo& item,
                                reco::filter::FilterReason* filter_reason,
                                bool is_oper_item = false);
  // 是否合法的 item
  static bool ItemIsValid(const ItemInfo& item, int64 curr_timestamp);
  // 文章质量的过滤
  // static bool IsQualityFiltered(const ItemInfo& item);
  static bool IsQualityFiltered(const RecoRequest& request, const ItemInfo& item,
                                reco::ContentAttr* content_attr);
  static bool IsStrictQualityFiltered(const ItemInfo& item);
  // sensitive 过滤
  static bool IsSensitiveFiltered(const RecoRequest& request, const ItemInfo& item);
  // ucb 投放过滤
  static bool IsUCBDeliverFiltered(const RecoRequest* request,
                                   const std::unordered_set<std::string>* prefer_cates,
                                   const ItemInfo& item,
                                   const reco::UcBrowserDeliverSetting& ucb_setting,
                                   int filter_qudao_index,
                                   reco::filter::FilterReason* filter_reason);
  // 请求中的 region 是否 match 下发设置的 region
  static bool IsReqRegionMatchSettingRegion(const RecommendRequest* request,
                                            const reco::UcBrowserDeliverSetting& ucb_setting);
  // ucb dn 过滤
  /*
  static bool IsUCBDnFiltered(const std::string& user_dn,
                              const ItemInfo& item, const reco::UcBrowserDeliverSetting& ucb_setting);
  */
  // 过滤 dislike tag / dislike source
  static bool IsDislikeFiltered(const RecoRequest* reco_request, const ItemInfo& item_info);
  static bool IsDislikeBannerFiltered(const UserFeature* user_feas, const ItemInfo& item_info);

  // title 长度过滤
  static bool IsTitleLengthFiltered(const RecommendRequest* request, const ItemInfo& item);

  /////////////////// 同批次去重
  // 基本去重
  static bool IsDeduped(const ItemInfo& item, base::dense_hash_set<uint64>* item_dedup);
  // 多样性去重
  static void DiversityFilter(const RecommendRequest* request,
                              const reco::user::UserInfo* user_info, const UserFeature* user_feas,
                              const std::vector<ItemInfo>& items, const std::string& category,
                              int req_num, std::vector<ItemInfo>* remain_items);

  // 地域限制过滤
  static bool IsRegionRestrictFiltered(const ItemInfo& item, int64 prov_id, int64 city_id);

  // 本地频道过滤策略
  static bool IsLocalChannelFiltered(const ItemInfo& item, int64 region_id);

  /*
  static bool IsFilteredCategory(const reco::dm::QudaoBlacklistDict* blacklist,
                                 int filter_qudao_index, const std::string& category);

  static bool IsFilteredByCategory(int filter_qudao_index, const reco::dm::QudaoBlacklistDict* blacklist,
                                   const RecoRequest* request, const ItemInfo& item);

  static bool IsFilteredByItemtype(int filter_qudao_index, const reco::dm::QudaoBlacklistDict* blacklist,
                                   const ItemInfo& item);

  static bool IsFilteredByItemDirty(int filter_qudao_index,
                                    const reco::dm::QudaoBlacklistDict* blacklist, int doc_id);

  static bool IsFilteredByItemTitleParty(int filter_qudao_index,
                                    const reco::dm::QudaoBlacklistDict* blacklist, int doc_id);

  static bool IsFilteredBySourceWeMedia(int filter_qudao_index,
                                    const reco::dm::QudaoBlacklistDict* blacklist, const ItemInfo& item);

  static bool IsFilteredByBlackPattern(int filter_qudao_index,
                                  const reco::dm::QudaoBlacklistDict* blacklist, uint64 item_id);
  */

  static bool ChooseSourceMediaFilter(const ItemInfo& item,
                                      const RecoRequest* request,
                                      const std::unordered_map<uint64_t,
                                      reco::filter::RiskMediaInfo>& source_media_map);

  static bool IsFilteredBySourceMedia(const reco::filter::RiskMediaDict* source_media,
                                      const RecoRequest* request, const ItemInfo& item);

  static bool IsFilteredByOrigMediaRiskType(const RecoRequest* request, const ItemInfo& item);

  static bool IsEnableSourceMediaFilter(const ItemInfo& item);

  static bool IsFilteredSourceMedia(const RecoRequest* request,
                                    uint64 source_media_sign,
                                    const std::unordered_map<uint64_t,
                                    reco::filter::RiskMediaInfo>& source_media_map,
                                    const ItemInfo& item);

  static bool IsFilteredSpecialSourceMedia(const RecoRequest* request,
                                           uint64 source_media_sign,
                                           const std::unordered_map<uint64_t,
                                           reco::filter::RiskMediaInfo>& source_media_map,
                                           const ItemInfo& item);

  /*
     static bool IsFilteredBySource(int filter_qudao_index,
     const reco::dm::QudaoBlacklistDict* blacklist, const ItemInfo& item);
     */

  static bool SourceMediaIsSafeTime();

  /*
  static bool IsFilteredByBlacklist(int filter_qudao_index, const reco::dm::QudaoBlacklistDict* blacklist,
                                    const reco::dm::SourceMediaDict* source_media,
                                    const RecoRequest* request, const ItemInfo& item,
                                    FilteredType* filtered_type);
  */

  // static int FilterQudaoIndex(const reco::dm::QudaoBlacklistDict* blacklist, const std::string& qudao);

  // static boost::shared_ptr<const reco::dm::QudaoBlacklistDict> GetBlackList();

  // 源的黑白名单过滤 政治文章的源过滤
  static bool PolicyFilter(const ItemInfo &item);

  // 地域，时间，审核状态过滤
  static bool ReviewedFileter(const RecoRequest* reco_request, const ItemInfo& item);

  static bool IsFilteredByNotVideoStorage(const RecoRequest* request, const ItemInfo& item);

 private:
  NewsFilter() {}
  ~NewsFilter() {}
  static void GetSpecialPreviewSimItems(const ItemInfo& item_info, std::unordered_set<uint64>* sim_items);
  static void GetItemSimFeas(uint64 item_id, std::unordered_map<std::string, float>* reco_feas);
  static bool IsSimilarFea(const std::unordered_map<std::string, float>& fea1,
                           const std::unordered_map<std::string, float>& fea2);

  // ucb 投放过滤 —— ve 投放过滤
  static bool IsVeSettingDeliverFiltered(const RecoRequest* reco_request,
                                         const UcBrowserUserParam& user_param,
                                         const ItemInfo& item,
                                         const reco::UcBrowserDeliverSetting& ucb_setting);

 private:
  // static DnFilter* dn_filter_;
  static const reco::NewsIndex* news_index_;
  // static FilterDict* filter_dict_;
  // static boost::shared_ptr<const reco::dm::QudaoBlacklistDict> black_list_;
  static uint64 special_source_media_;

  FRIEND_TEST(NewsFilter, IsVeSettingDeliverFiltered_ios);
  FRIEND_TEST(NewsFilter, IsVeSettingDeliverFiltered_android);
};

}  // namespace leafserver
}  // namespace reco

#include "reco/serv/reco_leaf/strategy/component/filter/news_filter-inl.h"
