#include "base/strings/string_number_conversions.h"
// #include "reco/serv/reco_leaf/strategy/component/filter/filter_dict.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "base/hash_function/term.h"

namespace reco {
namespace leafserver {
// DEFINE_string(leaf_data_dir, ".", "");

void BuildTest(bool is_vertial, std::vector<ItemInfo>* ret_items,
               std::vector<int>* qudaos,
               std::vector<bool>* result,
               std::vector<int>* type);



class FilterDictTest : public testing::Test {
 public:
  virtual void SetUp() {
    // leafserver::GlobalData* global_data = new GlobalData();
    // serving_base::DataManangerConfig leaf_config;
    // leaf_config.controller_item_num = 1;
    // LeafDataManager::Initialize(leaf_config, global_data);
    NewsFilter::InitNewsFilter(NULL);
  }
};

void TestHelp(bool is_vertical) {
  RecoRequest request;
  request.channel_id = is_vertical?reco::common::kPictureChannelId:reco::common::kRecoChannelId;
  std::vector<ItemInfo> items;
  std::vector<int> qudaos;
  std::vector<bool> result;
  std::vector<int> type;
  BuildTest(is_vertical, &items, &qudaos, &result, &type);

  FilterDict::BlackList blacklist = NewsFilter::GetBlackList();
  for (size_t i = 0; i < items.size(); ++i) {
    switch (type[i]) {
      case 0:
        ASSERT_EQ(NewsFilter::IsFilteredByCategory(
                qudaos[i], blacklist, &request, items[i]), result[i]);
        break;
      case 1:
        // ASSERT_EQ(NewsFilter::IsFilteredByItemtype(
        //        qudaos[i], blacklist, items[i].item_type), result[i]);
        break;
      case 2:
        // ASSERT_EQ(NewsFilter::IsFilteredByItemDirty(
        //        qudaos[i], blacklist, items[i].doc_id), result[i]);
        break;
    }
  }
  printf("item size = %lu\n", items.size());
}

TEST_F(FilterDictTest, complex_reco) {
  size_t size = 9;
  auto black_list = NewsFilter::GetBlackList();

  printf("--- dirty dict ---\n");
  for (size_t i = 0; i < size; ++i) {
    printf("%d\n", (*black_list.black_dirty)[i]?1:0);
  }

  printf("---- category itemtype ---\n");
  for (size_t i = 0; i < size; ++i) {
    for (size_t j = 0; j < (*black_list.black_itemtype)[i].size(); ++j) {
      printf("%d,", (*black_list.black_itemtype)[i][j]?1:0);
    }
    printf("\n\n");
  }

  printf("---- title pattern ---\n");
  for (size_t i = 0; i < size; ++i) {
    auto pattern = (*black_list.black_pattern)[i];
    if (NULL == pattern) continue;

    extend::MatchResult result;
    /*printf("%d,", pattern->Match("恋", 3, &result)?1:0);
    printf("%d,", pattern->Match("ab", 3, &result)?1:0);
    printf("%d,", pattern->Match("abcd", 3, &result)?1:0);
    */
    std::string iPhone = "奇特的iPhone概念设计 大多数功能都消失了";
    std::string apple = "回头客及千禧一代成Apple Watch Series 2购买主力";
    printf("iPhone:%d,", pattern->Match(iPhone.c_str(), iPhone.size(), &result)?1:0);
    printf("apple:%d,", pattern->Match(apple.c_str(), apple.size(), &result)?1:0);

    printf("\n\n");
  }

  TestHelp(false);
}

TEST_F(FilterDictTest, vertical_reco) {
  TestHelp(true);
}

void BuildTest(bool is_vertical, std::vector<ItemInfo>* ret_items,
               std::vector<int>* qudaos,
               std::vector<bool>* result,
               std::vector<int>* type) {
  base::FilePath file = base::FilePath("qudao_blacklist.txt");
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file, &lines)) {
    LOG(ERROR) << "failed to read file";
    return;
  }

  int qudao = -1;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) continue;

    int line_len = lines[i].size();
    if (-1 == qudao && lines[i][line_len-1] != ')') {
      LOG(ERROR) << file.ToString() << " field error: " << i;
      continue;
    }

    if (')' == lines[i][line_len-1]) {
      std::string qudao_name = lines[i].substr(0, lines[i].size()-1);
      qudao = NewsFilter::FilterQudaoIndex(qudao_name);
      if (-1 == qudao) {
        LOG(ERROR) << file.ToString() << " field error: " << i;
      }
    } else {
      std::vector<std::string> tokens;
      base::SplitString(lines[i], ":", &tokens);
      if (tokens.size() != 2) continue;

      std::vector<std::string> sub_tokens;
      base::SplitString(tokens[1], ",", &sub_tokens);

      if ("category" == tokens[0]) {
        for (size_t j = 0; j < sub_tokens.size(); ++j) {
          ItemInfo item;
          std::string category = sub_tokens[j];

          size_t pos = category.find('-');
          if (std::string::npos == pos) {
            item.category = category;
            ret_items->push_back(item);
            qudaos->push_back(qudao);
            result->push_back(!is_vertical);
            type->push_back(0);

            item.sub_category="xxxabcde123";
            ret_items->push_back(item);
            qudaos->push_back(qudao);
            result->push_back(true);
            type->push_back(0);
          } else {
            item.category = category.substr(0, pos);
            ret_items->push_back(item);
            qudaos->push_back(qudao);
            result->push_back(false);
            type->push_back(0);

            item.sub_category = category.substr(pos+1);
            ret_items->push_back(item);
            qudaos->push_back(qudao);
            result->push_back(true);
            type->push_back(0);
          }
        }
      } else if ("itemtype" == tokens[0]) {
        for (size_t j = 0; j < sub_tokens.size(); ++j) {
          ItemInfo item;
          unsigned itemtype = 0;
          base::StringToUint(sub_tokens[j], &itemtype);
          item.item_type = (ItemType)itemtype;

          ret_items->push_back(item);
          qudaos->push_back(qudao);
          result->push_back(true);
          type->push_back(1);

          item.item_type = (ItemType)(itemtype+10);
          ret_items->push_back(item);
          qudaos->push_back(qudao);
          result->push_back(false);
          type->push_back(1);
        }
      } else if ("quality" == tokens[0]) {
        ItemInfo item;
        unsigned item_quality = 0;
        base::StringToUint(tokens[1], &item_quality);
        item.itemq = item_quality;

        ret_items->push_back(item);
        qudaos->push_back(qudao);
        result->push_back(true);
        type->push_back(2);

        item.itemq = item_quality + 1;
        ret_items->push_back(item);
        qudaos->push_back(qudao);
        result->push_back(true);
        type->push_back(2);

        item.itemq = item_quality - 1;
        ret_items->push_back(item);
        qudaos->push_back(qudao);
        result->push_back(true);
        type->push_back(2);
      } else if ("pattern" == tokens[0]) {
        //////
      }
    }
  }
}

TEST_F(FilterDictTest, source_media) {
  FilterDict::BlackList blacklist = NewsFilter::GetBlackList();
  auto& source_media_map = *blacklist.source_media_map.get();
  LOG(ERROR) << "source media num: " << source_media_map.size();
  for (auto iter = source_media_map.begin(); iter != source_media_map.end(); ++iter) {
    // LOG(ERROR) << "\t" << iter->first << "level: " << iter->second.level;
  }

  RecoRequest request;
  request.user_param_info.is_main_city = false;
  request.user_param_info.is_ios = false;
  request.user_param_info.wsg_enc = true;
  request.user_param_info.city = "北京";
  request.user_param_info.is_inner_qudao = true;
  ItemInfo item;
  std::string media = "搜狐网";
  item.source_media_sign = base::CalcTermSign(media.c_str(), media.size());
  // item.orig_source_media_sign = base::CalcTermSign("media1", 6);
  ASSERT_EQ(NewsFilter::IsFilteredBySourceMedia(blacklist, &request, item), false);
}
}
}
