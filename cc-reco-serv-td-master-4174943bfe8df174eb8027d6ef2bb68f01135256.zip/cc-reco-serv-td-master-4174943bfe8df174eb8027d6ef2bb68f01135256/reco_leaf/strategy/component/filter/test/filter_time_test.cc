#include <unordered_set>

#include "base/time/time.h"
#include "nlp/common/nlp_util.h"
#include "extend/multi_strings/multi_pattern_matcher.h"
// #include "reco/serv/reco_leaf/strategy/component/filter/trie.h"
// #include "reco/serv/reco_leaf/strategy/component/filter/filter_dict.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"

namespace reco {
namespace leafserver {

// DEFINE_string(leaf_data_dir, ".", "");

struct BKDRHash {
  template <typename T>
std::size_t operator()(const T& t) const {
  register size_t hash = 0;
  size_t sz = t.size();
  for (size_t i = 0; i < sz; ++i) {
    hash += t[i];
  }
  return hash;
}
};

class FilterTimeTest : public testing::Test {
 public:
  virtual void SetUp() {
    // leafserver::GlobalData* global_data = new GlobalData();
    // serving_base::DataManangerConfig leaf_config;
    // leaf_config.controller_item_num = 1;
    // LeafDataManager::Initialize(leaf_config, global_data);
    NewsFilter::InitNewsFilter(NULL);
  }
  RecoRequest request_;

  typedef std::unordered_map<std::string, std::unordered_set<std::string> > MapSetStr;
  typedef std::unordered_map<std::string, std::unordered_set<int> > MapSetInt;
  typedef boost::shared_ptr<const MapSetStr> StrDict;
  typedef boost::shared_ptr<const MapSetInt> IntDict;
};


TEST_F(FilterTimeTest, time_test) {
  std::unordered_set<int> set1;
  std::unordered_set<std::string, BKDRHash> set2;
  std::unordered_set<std::string> set3;

  std::string s1 = "1234567890";
  std::string s2 = "abcdefg";
  std::string s3 = s1+s2;

  base::Time beg = base::Time::Now();
  for (int i = 0; i < 10000; ++i) {
    set3.find(s3);
  }
  int64 delta = (base::Time::Now()-beg).InMicroseconds();
  LOG(ERROR) << "STL hash:\t" << delta;

  beg = base::Time::Now();
  for (int i = 0; i < 10000; ++i) {
    set2.find(s3);
  }
  delta = (base::Time::Now()-beg).InMicroseconds();
  LOG(ERROR) << "BKDR hash:\t" << delta;

  Trie trie;
  // trie.Insert("1234567890x");
  trie.Insert("1234567890-abcdefg");

  bool is_find = false;
  beg = base::Time::Now();
  for (int i = 0; i < 10000; ++i) {
    is_find = trie.Find(s1, s2);
  }
  delta = (base::Time::Now()-beg).InMicroseconds();
  LOG(ERROR) << "Trie hash:\t" << delta << "," << is_find;

  ItemInfo item;
  item.category = "1234567890";
  item.sub_category = "abcdefg";
  request_.channel_id = reco::common::kPictureChannelId;
  FilterDict::BlackList blacklist = NewsFilter::GetBlackList();

  beg = base::Time::Now();
  for (int i = 0; i < 10000; ++i) {
    is_find = NewsFilter::IsFilteredByCategory(0, blacklist, &request_, item);
    // filter_dict_.IsFilteredByItemtype(0, (ItemType)0);
  }
  delta = (base::Time::Now()-beg).InMicroseconds();
  LOG(ERROR) << "IsFilteredByCategory:\t" << delta << "," << is_find;

  std::vector<ItemInfo> item_array(5000);
  beg = base::Time::Now();
  std::vector<ItemInfo> item_copy;
  for (size_t i = 0; i < item_array.size(); ++i) {
    item_copy.push_back(item_array[i]);
  }
  delta = (base::Time::Now()-beg).InMicroseconds();
  LOG(ERROR) << "vector push:\t" << delta;
}


TEST_F(FilterTimeTest, dawgdic) {
  extend::MultiPatternMatcher url_matcher;
  url_matcher.AddPattern("fg");
  url_matcher.Build();
  extend::MatchResult result;

  base::Time beg = base::Time::Now();
  for (int i = 0; i < 10000; ++i) {
    url_matcher.Match("1234567890abcdefg", 17, &result);
  }
  int64 delta = (base::Time::Now()-beg).InMicroseconds();
  LOG(ERROR) << "matche test:\t" << delta;
}
}
}
