#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"

#include "base/testing/gtest.h"

namespace reco {
namespace leafserver {

// bool veLessEqualThan(const std::string& v21, const std::string& v2);
// bool veInSettingInterval(const std::string& ve, const reco::VeInterval& interval);
//
// TEST(NewsFilter, veLessEqualThan) {
//   ASSERT_TRUE(veLessEqualThan("1.1.1", "1.1.1"));
//   ASSERT_TRUE(veLessEqualThan("1.1.1", "1.1.2"));
//   ASSERT_TRUE(veLessEqualThan("1.1.1", "1.2.0"));
//   ASSERT_TRUE(veLessEqualThan("1.1.1", "2.0.0"));
//
//   ASSERT_TRUE(veLessEqualThan("1.1.1", "1.1.1.10"));
//   ASSERT_TRUE(veLessEqualThan("1.1", "1.1.1.10"));
//   ASSERT_TRUE(veLessEqualThan("0.1", "0.1.1.10"));
//   ASSERT_TRUE(veLessEqualThan("", "0.1.1.10"));
//   ASSERT_TRUE(veLessEqualThan("", ""));
//   ASSERT_TRUE(veLessEqualThan("1a.1a.1a", "1.1.1.10"));
//   ASSERT_TRUE(veLessEqualThan("0.1.1", "a.1.1.10"));
//
//   ASSERT_FALSE(veLessEqualThan("1.1.2", "1.1.1"));
//   ASSERT_FALSE(veLessEqualThan("1.2.1", "1.1.0"));
//   ASSERT_FALSE(veLessEqualThan("2.1.1", "1.0.0"));
// }
//
// TEST(NewsFilter, veInSettingInterval) {
//   reco::VeInterval i1;
//   i1.set_lower_bound("1.10.1");
//   i1.set_upper_bound("1.20.1");
//   ASSERT_FALSE(veInSettingInterval("0.21.2", i1));
//   ASSERT_FALSE(veInSettingInterval("1.9.2", i1));
//   ASSERT_TRUE(veInSettingInterval("1.10.1", i1));
//   ASSERT_TRUE(veInSettingInterval("1.11.0", i1));
//   ASSERT_TRUE(veInSettingInterval("1.20.0", i1));
//   ASSERT_TRUE(veInSettingInterval("1.20.1", i1));
//   ASSERT_FALSE(veInSettingInterval("1.20.2", i1));
//   ASSERT_FALSE(veInSettingInterval("1.21.2", i1));
//
//   reco::VeInterval i2;
//   i2.set_upper_bound("1.20.1");
//   ASSERT_TRUE(veInSettingInterval("0.21.2", i2));
//   ASSERT_TRUE(veInSettingInterval("1.9.2", i2));
//   ASSERT_TRUE(veInSettingInterval("1.10.1", i2));
//   ASSERT_TRUE(veInSettingInterval("1.11.0", i2));
//   ASSERT_TRUE(veInSettingInterval("1.20.0", i2));
//   ASSERT_TRUE(veInSettingInterval("1.20.1", i2));
//   ASSERT_FALSE(veInSettingInterval("1.20.2", i2));
//   ASSERT_FALSE(veInSettingInterval("1.21.2", i2));
//
//   reco::VeInterval i3;
//   i3.set_lower_bound("1.10.1");
//   ASSERT_FALSE(veInSettingInterval("0.21.2", i3));
//   ASSERT_FALSE(veInSettingInterval("1.9.2", i3));
//   ASSERT_TRUE(veInSettingInterval("1.10.1", i3));
//   ASSERT_TRUE(veInSettingInterval("1.11.0", i3));
//   ASSERT_TRUE(veInSettingInterval("1.20.0", i3));
//   ASSERT_TRUE(veInSettingInterval("1.20.1", i3));
//   ASSERT_TRUE(veInSettingInterval("1.20.2", i3));
//   ASSERT_TRUE(veInSettingInterval("1.21.2", i3));
//
//   reco::VeInterval i4;
//   ASSERT_TRUE(veInSettingInterval("0.21.2", i4));
//   ASSERT_TRUE(veInSettingInterval("1.9.2", i4));
//   ASSERT_TRUE(veInSettingInterval("1.10.1", i4));
//   ASSERT_TRUE(veInSettingInterval("1.11.0", i4));
//   ASSERT_TRUE(veInSettingInterval("1.20.0", i4));
//   ASSERT_TRUE(veInSettingInterval("1.20.1", i4));
//   ASSERT_TRUE(veInSettingInterval("1.20.2", i4));
//   ASSERT_TRUE(veInSettingInterval("1.21.2", i4));
// }

TEST(NewsFilter, IsVeSettingDeliverFiltered_ios) {
  RecoRequest reco_request;
  UcBrowserUserParam user_param;
  ItemInfo item;
  reco::UcBrowserDeliverSetting ucb_setting;

  // case1: 没有设置 ucb_setting，不进行过滤
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  ucb_setting.add_ios_ve("ios");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  ucb_setting.Clear();
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  ucb_setting.add_android_ve("android");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));

  // case2: 设置全量 anroid/ios ve，命中过滤
  ucb_setting.Clear();
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  RecommendRequest request;
  reco_request.request = &request;
  reco_request.user_param_info.is_ios = true;
  reco_request.user_param_info.is_android = false;
  ucb_setting.add_ios_ve("ios.1.1");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting))
      << "filtered by not set user_param ve";
  user_param.set_ve("ios.1.2");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting))
      << "filtered by not contain user_param.ve(ios.1.2)";
  user_param.set_ve("ios.1.1");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));

  // case3: 设置渠道 anroid/ios ve，命中过滤
  ucb_setting.Clear();
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  request.set_app_token("uc-iflow");
  reco_request.user_param_info.is_ios = true;
  reco_request.user_param_info.is_android = false;
  user_param.set_ve("ios.1.1");
  ucb_setting.add_ios_ve("ios.1.1");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  reco::VeSetting* ve_setting = ucb_setting.add_ve_setting();
  ve_setting->set_appname("uc-iflow");
  ve_setting->add_ios_ve("ios.1.2");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));

  // case4: 设置区间过滤
  ucb_setting.Clear();
  user_param.Clear();
  request.Clear();
  reco_request.user_param_info.is_ios = true;
  reco_request.user_param_info.is_android = false;
  user_param.set_ve("1.10.1.100");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  ucb_setting.mutable_ios_ve_interval()->set_lower_bound("1.10.2");
  ucb_setting.mutable_ios_ve_interval()->set_upper_bound("1.20.2");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  user_param.set_ve("1.10.2.100");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  user_param.set_ve("2.10.2.100");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));

  // case5: 设置渠道区间过滤
  ucb_setting.Clear();
  user_param.Clear();
  request.Clear();
  request.set_app_token("uc-iflow");
  reco_request.user_param_info.is_ios = true;
  reco_request.user_param_info.is_android = false;
  user_param.set_ve("1.10.1.100");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  ve_setting = ucb_setting.add_ve_setting();
  ve_setting->set_appname("uc-iflow");
  ve_setting->mutable_ios_ve_interval()->set_lower_bound("1.10.2");
  ve_setting->mutable_ios_ve_interval()->set_upper_bound("1.20.2");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  user_param.set_ve("1.10.2.100");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  user_param.set_ve("2.10.2.100");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
}

TEST(NewsFilter, IsVeSettingDeliverFiltered_android) {
  RecoRequest reco_request;
  UcBrowserUserParam user_param;
  ItemInfo item;
  reco::UcBrowserDeliverSetting ucb_setting;

  // case1: 没有设置 ucb_setting，不进行过滤
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  ucb_setting.add_ios_ve("ios");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  ucb_setting.Clear();
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  ucb_setting.add_android_ve("android");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));

  // case2: 设置全量 anroid/ios ve，命中过滤
  ucb_setting.Clear();
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  RecommendRequest request;
  reco_request.request = &request;
  reco_request.user_param_info.is_ios = false;
  reco_request.user_param_info.is_android = true;
  ucb_setting.add_android_ve("android.1.1");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting))
      << "filtered by not set user_param ve";
  user_param.set_ve("android.1.2");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting))
      << "filtered by not contain user_param.ve(android.1.2)";
  user_param.set_ve("android.1.1");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));

  // case3: 设置渠道 anroid/android ve，命中过滤
  ucb_setting.Clear();
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  request.set_app_token("uc-iflow");
  reco_request.user_param_info.is_android = true;
  user_param.set_ve("android.1.1");
  ucb_setting.add_android_ve("android.1.1");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  reco::VeSetting* ve_setting = ucb_setting.add_ve_setting();
  ve_setting->set_appname("uc-iflow");
  ve_setting->add_android_ve("android.1.2");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));

  // case4: 设置区间过滤
  ucb_setting.Clear();
  user_param.Clear();
  request.Clear();
  reco_request.user_param_info.is_ios = false;
  reco_request.user_param_info.is_android = true;
  user_param.set_ve("1.10.1.100");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  ucb_setting.mutable_android_ve_interval()->set_lower_bound("1.10.2");
  ucb_setting.mutable_android_ve_interval()->set_upper_bound("1.20.2");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  user_param.set_ve("1.10.2.100");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  user_param.set_ve("2.10.2.100");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));

  // case5: 设置渠道区间过滤
  ucb_setting.Clear();
  user_param.Clear();
  request.Clear();
  request.set_app_token("uc-iflow");
  reco_request.user_param_info.is_ios = false;
  reco_request.user_param_info.is_android = true;
  user_param.set_ve("1.10.1.100");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  ve_setting = ucb_setting.add_ve_setting();
  ve_setting->set_appname("uc-iflow");
  ve_setting->mutable_android_ve_interval()->set_lower_bound("1.10.2");
  ve_setting->mutable_android_ve_interval()->set_upper_bound("1.20.2");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  user_param.set_ve("1.10.2.100");
  EXPECT_FALSE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
  user_param.set_ve("2.10.2.100");
  EXPECT_TRUE(NewsFilter::IsVeSettingDeliverFiltered(&reco_request, user_param, item, ucb_setting));
}

}  // namespace leafserver
}  // namespace reco
