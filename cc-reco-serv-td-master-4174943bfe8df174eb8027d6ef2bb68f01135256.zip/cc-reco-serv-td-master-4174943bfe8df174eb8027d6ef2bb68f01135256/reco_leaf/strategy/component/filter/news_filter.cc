#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"

#include <unordered_map>
#include <unordered_set>
#include <string>
#include <algorithm>
#include <vector>

#include "reco/bizc/region/region_dict.h"
#include "reco/bizc/filter_dict/common_filter.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "extend/multi_strings/multi_strings_vldc.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

// DnFilter* NewsFilter::dn_filter_ = NULL;
// FilterDict* NewsFilter::filter_dict_ = NULL;
const reco::NewsIndex* NewsFilter::news_index_ = NULL;
uint64 NewsFilter::special_source_media_ = base::CalcTermSign("youtube", 7);
DEFINE_bool(do_title_len_filter, false, "");
DEFINE_bool(filter_all_dirty_item, false, "");
DEFINE_bool(filter_all_bluffing_item, false, "");

DEFINE_int32(source_media_safehour_begin, 22, "source media begin safe hour");
DEFINE_int32(source_media_safehour_end, 6, "source media end sage hour");

DEFINE_bool(video_extra_source_media, true, "video item use extra source media logic");

/*
static DnFilter* GetSingleton() {
  static reco::leafserver::DnFilter* filter = new reco::leafserver::DnFilter();
  return filter;
}
*/

/*
static FilterDict* GetFilterDictSingleton() {
  static FilterDict* filter_dict = new FilterDict();
  return filter_dict;
}
*/

static bool arrayContain(const ::google::protobuf::RepeatedPtrField<std::string>& array,
                         const std::string& elem) {
  for (int i = 0; i < array.size(); ++i) {
    if (array.Get(i) == elem) {
      return true;
    }
  }
  return false;
}

static bool veLessEqualThan(const std::string& ve1, const std::string& ve2) {
  std::vector<std::string> flds1;
  base::SplitString(ve1, ".", &flds1);
  std::vector<std::string> flds2;
  base::SplitString(ve2, ".", &flds2);
  size_t minLength = std::min(flds1.size(), flds2.size());
  for (size_t i = 0; i < minLength; i++) {
    int32 v1 = 0;
    base::StringToInt(flds1[i], &v1);
    int32 v2 = 0;
    base::StringToInt(flds2[i], &v2);
    if (v1 < v2) {
      return true;
    } else if (v1 > v2) {
      return false;
    }
  }
  return true;
}

static bool veInSettingInterval(const std::string& ve, const reco::VeInterval& interval) {
  if (interval.lower_bound() != "" && interval.upper_bound() != "") {
    return veLessEqualThan(interval.lower_bound(), ve) && veLessEqualThan(ve, interval.upper_bound());
  } else if (interval.lower_bound() != "") {
    return veLessEqualThan(interval.lower_bound(), ve);
  } else if (interval.upper_bound() != "") {
    return veLessEqualThan(ve, interval.upper_bound());
  } else {
    return true;
  }
}

static std::string normalizeVe(const std::string& ve) {
  static const char* kDftVe   = "其他";
  std::vector<std::string> flds;
  base::SplitString(ve, ".", &flds);
  if (flds.size() < 3u) {
    LOG(WARNING) << "unexpected ve, " << ve;
    return kDftVe;
  }
  return base::StringPrintf("%s.%s.%s", flds[0].c_str(), flds[1].c_str(), flds[2].c_str());
}

bool NewsFilter::InitNewsFilter(const reco::NewsIndex* news_index) {
  static const reco::NewsIndex* tmp_index = news_index;
  news_index_ = tmp_index;
  // dn_filter_ = GetSingleton();
  // filter_dict_ = GetFilterDictSingleton();
  return true;
}

bool NewsFilter::IsGeneralFiltered(const RecoRequest* reco_request,
                                   const base::dense_hash_set<uint64>* shown_dict,
                                   const ItemInfo& item,
                                   reco::filter::FilterReason* filter_reason,
                                   bool is_oper_item) {
  const RecommendRequest* request = reco_request->request;

  // NOTE(jianhuang) 简版内容不做这些过滤
  bool is_left_channel = request->has_channel_id() && request->channel_id() == reco::common::kLeftChannelId;
  if (is_left_channel) {
    return false;
  }

  // 已经经过 sim 的洗礼
  if (!news_index_->HasCheckedBySimServer(item.item_id)) {
    *filter_reason = reco::filter::kFilterBySimCheck;
    VLOG(3) << item.item_id << " has not checked by sim server.";
    return true;
  }
  // RULE: 推荐过的不出
  if (shown_dict->find(item.item_id) != shown_dict->end()) {
    *filter_reason = reco::filter::kFilterByShownHistory;
    VLOG(3) << item.item_id << " shown";
    return true;
  }
  if (item.item_type == reco::kWeMediaCard
      || RecoUtils::IsNormalSpecialItem(news_index_, item)) {
    std::unordered_set<uint64> preview_ids;
    if (!is_left_channel
        && news_index_->GetPreviewIdsByItemId(item.item_id, &preview_ids)
        && !preview_ids.empty()) {
      // 专题子文已经太多被看过，即不再出
      int mix_num = 0;
      for (auto iter = preview_ids.begin(); iter != preview_ids.end(); ++iter) {
        if (shown_dict->find(*iter) != shown_dict->end()) {
          ++mix_num;
        }
      }
      if (mix_num >= 4 || mix_num * 1.0 / preview_ids.size() >= 0.9) {
        *filter_reason = reco::filter::kFilterByShownSpecial;
        return true;
      }
    }
  } else if (!is_oper_item
             && (item.item_type == reco::kPicture || item.item_type == reco::kPictureNews)) {
    // 机器新闻，图集限制必须 3 张图以上
    int img_cnt = news_index_->GetImageCountByDocId(item.doc_id);
    if (img_cnt < 3) {
      *filter_reason = reco::filter::kFilterByPictureNum;
      VLOG(3) << item.item_id << " picture but img cnt: " << img_cnt;
      return true;
    }
  }

  // NOTE(jianhuang) 有些 app, 除视频频道之外的其他频道暂时不支持视频新闻
  // TODO(jianhuang) 其他 app 支持视频新闻时，去掉该过滤
  if (!is_oper_item
      && !reco::common::IsVideoChannel(request->channel_id())
      && request->app_token() != reco::common::kUCBIflowUser
      && request->app_token() != reco::common::kUCAppUser) {
    int video_cmt = news_index_->GetVideoCountByDocId(item.doc_id);
    if (video_cmt > 0) {
      *filter_reason = reco::filter::kFilterByVideoAppScope;
      VLOG(3) << item.item_id << " filter by video";
      return true;
    }
  }

  // title 长度过滤
  if (!is_oper_item && IsTitleLengthFiltered(request, item)) {
    *filter_reason = reco::filter::kTitleLenghFiltered;
    VLOG(3) << item.item_id << " filter by title length.";
    return true;
  }

  // 运营文章走自己的 dislike 过滤逻辑
  if (!is_oper_item && IsDislikeFiltered(reco_request, item)) {
    *filter_reason = reco::filter::kFilterByDislike;
    VLOG(3) << item.item_id << " filter dislike.";
    return true;
  }

  if (!is_oper_item && PolicyFilter(item)) {
    *filter_reason = reco::filter::kFilterByNegative;
    return true;
  }

  return false;
}

bool NewsFilter::IsReqRegionMatchSettingRegion(const RecommendRequest* request,
                                               const reco::UcBrowserDeliverSetting& ucb_setting) {
  if (!request->has_region_id()) return true;
  if (ucb_setting.city_size() == 0 && ucb_setting.province_size() == 0) return true;

  for (int i = 0; i < ucb_setting.city_size(); ++i) {
    const std::string& city_code
        = reco::common::RegionSearcher::instance().SearchRegionCode(ucb_setting.city(i));
    if (city_code == request->region_id()) {
      return true;
    }
  }

  if (ucb_setting.province_size() > 0) {
    std::string req_prov_code = request->region_id();
    if (!reco::common::RegionSearcher::instance().IsShengFenCode(request->region_id())) {
      req_prov_code
          = reco::common::RegionSearcher::instance().GetProvinceCodeByRegionCode(request->region_id());
    }
    for (int i = 0; i < ucb_setting.province_size(); ++i) {
      const std::string& province_code
          = reco::common::RegionSearcher::instance().SearchRegionCode(ucb_setting.province(i));
      if (province_code == req_prov_code) {
        return true;
      }
    }
  }

  return false;
}

bool NewsFilter::IsUCBDeliverFiltered(const RecoRequest* reco_request,
                                      const std::unordered_set<std::string>* prefer_cates,
                                      const ItemInfo& item,
                                      const reco::UcBrowserDeliverSetting& ucb_setting,
                                      int app_token_index,
                                      reco::filter::FilterReason* filter_reason) {
  const RecommendRequest* request = reco_request->request;
  // 用户请求不包含 uc_user_param 过滤
  if (!request->has_uc_user_param()) {
    if (ucb_setting.province_size() > 0
        || ucb_setting.city_size() > 0
        || ucb_setting.isp_size() > 0
        || ucb_setting.nt_size() > 0
        || ucb_setting.sv_size() > 0) {
      *filter_reason = reco::filter::kUcbNotHasUcUserParamFiltered;
      VLOG(1) << "filtered by missing user praram:" << item.item_id;
      return true;
    }
    return false;
  }
  const UcBrowserUserParam& user_param = request->uc_user_param();

  // appname 的过滤
  if (ucb_setting.appnames_size() > 0) {
    bool hit_apptoken = false;
    for (int i = 0; i < ucb_setting.appnames_size(); ++i) {
      if (ucb_setting.appnames(i) == request->app_token()) {
        hit_apptoken = true;
        break;
      }
    }
    if (!hit_apptoken) {
      *filter_reason = reco::filter::kUcbAppNameFiltered;
      VLOG(1) << "filtered by not hit app_token: " << item.item_id << ", " << request->app_token();
      return true;
    }
  }
  // 地域过滤
  // 如果请求参数中带有地域信息，使用该地域信息进行过滤
  // 否则，使用用户真实地理位置
  if (request->has_region_id() || !request->region_id().empty()) {
    if (!IsReqRegionMatchSettingRegion(request, ucb_setting)) {
      *filter_reason = reco::filter::kUcbRegionFiltered;
      VLOG(1) << "filtered by region not match: " << item.item_id;
      return true;
    }
  } else if (ucb_setting.province_size() > 0 || ucb_setting.city_size() > 0) {
    bool hit_region = false;
    if (ucb_setting.province_size() > 0) {
      if (user_param.has_province() && arrayContain(ucb_setting.province(), user_param.province())) {
        hit_region = true;
      }
    }
    if (!hit_region && ucb_setting.city_size() > 0) {
      if (user_param.has_city() && arrayContain(ucb_setting.city(), user_param.city())) {
        hit_region = true;
      }
    }
    if (!hit_region) {
      *filter_reason = reco::filter::kUcbProviceCityFiltered;
      VLOG(1) << "filtered by not hit region: " << item.item_id;
      return true;
    }
  }
  // VeSetting filter
  if (IsVeSettingDeliverFiltered(reco_request, user_param, item, ucb_setting)) {
    *filter_reason = reco::filter::kUcbVeFiltered;
    return true;
  }
  // sv 字段过滤
  if (ucb_setting.sv_size() > 0) {
    if (!user_param.has_sv()
        || !arrayContain(ucb_setting.sv(), user_param.sv())) {
      *filter_reason = reco::filter::kUcbSvFiltered;
      VLOG(1) << "filtered by not contain sv: " << item.item_id;
      return true;
    }
  }
  // isp 字段过滤
  if (ucb_setting.isp_size() > 0) {
    if (!user_param.has_isp()
        || !arrayContain(ucb_setting.isp(), user_param.isp())) {
      *filter_reason = reco::filter::kUcbIspFiltered;
      VLOG(1) << "filtered by not contain isp: " << item.item_id;
      return true;
    }
  }
  // nt 字段过滤
  if (ucb_setting.nt_size() > 0) {
    if (!user_param.has_nt()
        || !arrayContain(ucb_setting.nt(), user_param.nt())) {
      *filter_reason = reco::filter::kUcbNtFiltered;
      VLOG(1) << "filtered by not contain nt: " << item.item_id;
      return true;
    }
  }
  // tag 字段过滤
  if (ucb_setting.tag_size() > 0 && prefer_cates != NULL) {
    // if (user_feas == NULL) return true;
    bool hit_tag = false;
    for (int i = 0; i < ucb_setting.tag_size(); ++i) {
      if (prefer_cates->find(ucb_setting.tag(i)) != prefer_cates->end()) {
        hit_tag = true;
        break;
      }
    }
    if (!hit_tag) {
      *filter_reason = reco::filter::kUcbTagFiltered;
      VLOG(1) << "filtered by not hit tag: " << item.item_id;
      return true;
    }
  }

  // 小渠道自己下发的运营文章不过滤
  if (0 == ucb_setting.appnames_size()
      || "uc-iflow" == ucb_setting.appnames(0)
      || "ucnews-iflow" == ucb_setting.appnames(0) ) {
    if (app_token_index >= 0
        && app_token_index < (int)item.app_rule_mask.size()
        && item.app_rule_mask.test(app_token_index)) {
      *filter_reason = reco::filter::kFilterByAppRule;
      return true;
    }
    if (NewsFilter::IsFilteredByNotVideoStorage(reco_request, item)) {
      *filter_reason = reco::filter::kFilterByVideoStorage;
      return true;
    }
  }

  return false;
}

/*
bool NewsFilter::IsUCBDnFiltered(const std::string& user_dn, const ItemInfo& item,
                                 const reco::UcBrowserDeliverSetting& ucb_setting) {
  CHECK_NOTNULL(dn_filter_);
  if (ucb_setting.has_dn_file() && !ucb_setting.dn_file().empty()) {
    if (user_dn.empty() || !dn_filter_->HitDnFile(item.item_id, user_dn, ucb_setting.dn_file())) {
      LOG(INFO) << "item is filtered by dnfilter, " << item.item_id << ", user_dn: " << user_dn
                << ", dn_file: " << ucb_setting.dn_file();
      return true;
    }
  }
  return false;
}
*/

bool NewsFilter::IsDeduped(const ItemInfo& item, base::dense_hash_set<uint64>* item_dedup) {
  if (item.item_id == 0 || item.doc_id == 0) return true;
  if (item_dedup->find(item.item_id) != item_dedup->end()) {
    return true;
  }
  item_dedup->insert(item.item_id);
  // 插入相似 item
  const std::set<uint64>* sim_ids = news_index_->GetSimItemIds(item.item_id);
  if (sim_ids != NULL) {
    for (auto it = sim_ids->begin(); it != sim_ids->end(); ++it) {
      item_dedup->insert(*it);
    }
  }
  // 专题 preview 的文章插入到 dedup 队列
  if (RecoUtils::IsNormalSpecialItem(news_index_, item) || item.item_type == reco::kWeMediaCard) {
    std::unordered_set<uint64> preview_sim_items;
    GetSpecialPreviewSimItems(item, &preview_sim_items);
    for (auto it = preview_sim_items.begin(); it != preview_sim_items.end(); ++it) {
      // LOG(INFO) << "DEBUG, add sim preview, " << item.item_id << ", " << *it;
      item_dedup->insert(*it);
    }
  }
  return false;
}

void NewsFilter::DiversityFilter(const RecommendRequest* request,
                                 const UserInfo* user_info,
                                 const UserFeature* user_feas,
                                 const std::vector<ItemInfo>& items,
                                 const std::string& category,
                                 int req_num,
                                 std::vector<ItemInfo>* remain_items) {
  base::Time current_time = base::Time::Now();
  remain_items->clear();
  if (items.empty() || req_num <= 0) {
    return;
  }

  // 挑选需要参与多样性选择去重的历史展现
  std::unordered_set<uint64> click_ids;
  base::Time expire_time = current_time - base::TimeDelta::FromHours(6);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  for (int i = user_info->recent_click_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& clicked_item = user_info->recent_click().Get(i);
    if (clicked_item.click_timestamp() < expire_timestamp) break;
    click_ids.insert(clicked_item.item_id());
  }
  int kDedupHistoryShowNum = req_num * 2;
  if (!request->has_channel_id() && kDedupHistoryShowNum > 20) {
    kDedupHistoryShowNum = 20;
  }

  std::vector<std::unordered_map<std::string, float>> shown_item_feas;
  std::vector<reco::Category> categories;
  int64 filter_channel_id = request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId;
  for (int i = user_info->shown_history_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& show_item = user_info->shown_history(i);
    if (show_item.view_timestamp() < expire_timestamp
        || (int)shown_item_feas.size() >= kDedupHistoryShowNum) break;
    if (click_ids.find(show_item.item_id()) != click_ids.end()) continue;
    if (show_item.has_channel_id() && show_item.channel_id() != filter_channel_id) continue;

    ItemType item_type;
    if (!news_index_->GetItemTypeByItemId(show_item.item_id(), &item_type))
      item_type = reco::kNews;

    if (item_type == reco::kSpecial
        || item_type == reco::kWeMediaCard
        || item_type == reco::kHumor
        || item_type == reco::kPicture)
      continue;

    if (!category.empty()) {
      categories.clear();
      if (!news_index_->GetCategoriesByItemId(show_item.item_id(), &categories)
          || categories.empty()
          || categories[0].category() != category) {
        continue;
      }
    }

    click_ids.insert(show_item.item_id());
    shown_item_feas.push_back(std::unordered_map<std::string, float>());
    GetItemSimFeas(show_item.item_id(), &(shown_item_feas.back()));
  }

  // 多样性的挑选
  // 性能考虑，只要前 req_num * 2 来计算
  const int kMaxCompNum = std::min(req_num * 2, (int)items.size());
  std::vector<std::unordered_map<std::string, float>> item_feas_vec(kMaxCompNum);
  for (int i = 0; i < kMaxCompNum; ++i) {
    GetItemSimFeas(items[i].item_id, &(item_feas_vec[i]));
  }

  std::unordered_set<int> filter_idx_vec;
  std::string source;
  for (int i = 0; i < kMaxCompNum; ++i) {
    if ((int)remain_items->size() >= req_num) break;
    if (news_index_->IsManualByDocId(items[i].doc_id)) {
      remain_items->push_back(items[i]);
      continue;
    }
    if (item_feas_vec[i].empty()) {
      remain_items->push_back(items[i]);
      continue;
    }
    // 与 dislike item 的去重
    bool is_filtered = false;
    for (int j = 0; j < 20 && j < (int)user_feas->behavior_fea.dislike_items.size(); ++j) {
      auto const& dislike_feas = user_feas->behavior_fea.dislike_items.at(j).item_feas;
      if (IsSimilarFea(item_feas_vec[i], dislike_feas)) {
        is_filtered = true;
        break;
      }
    }
    if (is_filtered) {
      filter_idx_vec.insert(i);
      continue;
    }
    // 同一批次的去重
    int comp_num = 0;
    for (int j = i - 1; j >= 0; --j) {
      if (comp_num >= 20) break;
      if (filter_idx_vec.find(j) != filter_idx_vec.end()) continue;
      ++comp_num;
      if (IsSimilarFea(item_feas_vec[i], item_feas_vec[j])) {
        is_filtered = true;
        break;
      }
    }
    if (is_filtered) {
      filter_idx_vec.insert(i);
      continue;
    }
    // 与历史展现的去重
    for (int j = 0; j < (int)shown_item_feas.size(); ++j) {
      if (IsSimilarFea(item_feas_vec[i], shown_item_feas[j])) {
        is_filtered = true;
        break;
      }
    }
    if (is_filtered) {
      filter_idx_vec.insert(i);
      continue;
    }
    // 都没有被过滤，则直接加入返回集
    remain_items->push_back(items[i]);
  }

  for (int i = kMaxCompNum; i < (int)items.size(); ++i) {
    if ((int)remain_items->size() >= req_num) break;
    remain_items->push_back(items[i]);
  }

  for (int i = 0; i < kMaxCompNum; ++i) {
    if ((int)remain_items->size() >= req_num) break;
    if (filter_idx_vec.find(i) != filter_idx_vec.end()) {
      remain_items->push_back(items[i]);
    }
  }
}

bool NewsFilter::IsDislikeFiltered(const RecoRequest* reco_request, const ItemInfo& item_info) {
  const UserFeature* user_feas = reco_request->user_feas;

  // dislike subcategory
  static const std::unordered_set<int64> kFilterDislikeSubCateChannels
      = {reco::common::kRecoChannelId, reco::common::kSportChannelId,
        reco::common::kScienceChannelId, reco::common::kFinanceChannelId};
  auto const& ref_dislike_subcates = user_feas->behavior_fea.dislike_sub_cates;
  int64 cid = reco_request->channel_id;
  if (!ref_dislike_subcates.empty()
      && !item_info.sub_category.empty()
      && kFilterDislikeSubCateChannels.find(cid) != kFilterDislikeSubCateChannels.end()) {
    auto const iter = ref_dislike_subcates.find(item_info.sub_category);
    if (iter != ref_dislike_subcates.end() && iter->second >= 0.8) {
      return true;
    }
  }

  // dislike tag
  auto const& ref_dislike_tags = user_feas->behavior_fea.dislike_tags;
  if (!ref_dislike_tags.empty()) {
    reco::FeatureVector tag_feas;
    if (news_index_->GetFeatureVectorByItemId(item_info.item_id, reco::common::kTag, &tag_feas)) {
      std::vector<std::string> tag_flds;
      for (int i = 0; i < tag_feas.feature_size(); ++i) {
        const reco::Feature& fea = tag_feas.feature(i);
        tag_flds.clear();
        base::SplitString(fea.literal(), ":", &tag_flds);
        if (tag_flds.size() == 2u
            && ref_dislike_tags.find(tag_flds[1]) != ref_dislike_tags.end()) {
          return true;
        }
      }
    }
  }

  // dislike semantic tag
  auto const& ref_dislike_semantic_tags = user_feas->behavior_fea.dislike_semantic_tags;
  if (!ref_dislike_semantic_tags.empty()) {
    reco::FeatureVector tag_feas;
    if (news_index_->GetFeatureVectorByItemId(item_info.item_id, reco::common::kSemanticTag, &tag_feas)) {
      std::vector<std::string> tag_flds;
      for (int i = 0; i < tag_feas.feature_size(); ++i) {
        const reco::Feature& fea = tag_feas.feature(i);
        tag_flds.clear();
        base::SplitString(fea.literal(), ":", &tag_flds);
        if (tag_flds.size() == 2u
            && ref_dislike_semantic_tags.find(tag_flds[1]) != ref_dislike_semantic_tags.end()) {
          return true;
        }
      }
    }
  }

  // dislike item_type
  auto const& ref_dislike_item_types = user_feas->behavior_fea.dislike_item_types;
  if (!ref_dislike_item_types.empty()) {
    if (ref_dislike_item_types.find(item_info.item_type) != ref_dislike_item_types.end()) {
      return true;
    }
  }

  // dislike source
  auto const& ref_dislike_sources = user_feas->behavior_fea.dislike_sources;
  if (cid != reco::common::kHumorPicChannelId
      && cid != reco::common::kHumorWordTouTiaoChannelId
      && !ref_dislike_sources.empty()) {
    std::string source;
    if (news_index_->GetShowSourceByDocId(item_info.doc_id, &source)
        && !source.empty()) {
      if (ref_dislike_sources.find(source) != ref_dislike_sources.end()) {
        return true;
      }
    } else if (news_index_->GetOrigSourceByDocId(item_info.doc_id, &source)
               && !source.empty()) {
      if (ref_dislike_sources.find(source) != ref_dislike_sources.end()) {
        return true;
      }
    } else if (news_index_->GetSourceByDocId(item_info.doc_id, &source)
               && !source.empty()) {
      if (ref_dislike_sources.find(source) != ref_dislike_sources.end()) {
        return true;
      }
    }
  }

  return false;
}

void NewsFilter::GetSpecialPreviewSimItems(const ItemInfo& item_info,
                                           std::unordered_set<uint64>* sim_items) {
  sim_items->clear();
  if (!RecoUtils::IsNormalSpecialItem(news_index_, item_info)
      && item_info.item_type != reco::kWeMediaCard) return;
  std::unordered_set<uint64> preview_ids;
  if (!news_index_->GetPreviewIdsByItemId(item_info.item_id, &preview_ids)
      || preview_ids.empty()) {
    return;
  }
  for (auto preview_iter = preview_ids.begin(); preview_iter != preview_ids.end(); ++preview_iter) {
    uint64 id = *preview_iter;
    sim_items->insert(id);
    const std::set<uint64>* sim_ids = news_index_->GetSimItemIds(id);
    if (sim_ids != NULL) {
      for (auto it = sim_ids->begin(); it != sim_ids->end(); ++it) {
        sim_items->insert(*it);
      }
    }
  }
}

bool NewsFilter::IsSimilarFea(const std::unordered_map<std::string, float>& fea1,
                              const std::unordered_map<std::string, float>& fea2) {
  if (fea1.empty() || fea2.empty()) return false;

  float fea_wt1 = 0;
  float fea_wt2 = 0;
  for (auto iter1 = fea1.begin(); iter1 != fea1.end(); ++iter1) {
    fea_wt1 += iter1->second;
  }
  for (auto iter2 = fea2.begin(); iter2 != fea2.end(); ++iter2) {
    fea_wt2 += iter2->second;
  }

  if (fea_wt1 <= 0 || fea_wt2 <= 0) return true;

  float sim_wt1 = 0;
  float sim_wt2 = 0;
  for (auto iter1 = fea1.begin(); iter1 != fea1.end(); ++iter1) {
    auto iter2 = fea2.find(iter1->first);
    if (iter2 != fea2.end()) {
      sim_wt1 += iter1->second;
      sim_wt2 += iter2->second;
    }
  }
  const float kSimilarRatio = 0.75;
  if (sim_wt1 / fea_wt1 >= kSimilarRatio && sim_wt2 / fea_wt2 >= kSimilarRatio) {
    return true;
  }

  return false;
}

bool NewsFilter::IsVeSettingDeliverFiltered(const RecoRequest* reco_request,
                                            const UcBrowserUserParam& user_param,
                                            const ItemInfo& item,
                                            const reco::UcBrowserDeliverSetting& ucb_setting) {
  if (ucb_setting.ve_setting_size() > 0
      || ucb_setting.ios_ve_size() > 0 || ucb_setting.android_ve_size() > 0
      || ucb_setting.has_ios_ve_interval() || ucb_setting.has_android_ve_interval()) {
    if (!user_param.has_ve()) {
      VLOG(1) << "filtered by has no ve: " << item.item_id;
      return true;
    }
    const ::google::protobuf::RepeatedPtrField<std::string>* ios_ve = &ucb_setting.ios_ve();
    const ::google::protobuf::RepeatedPtrField<std::string>* android_ve = &ucb_setting.android_ve();
    const reco::VeInterval* ios_ve_interval = ucb_setting.has_ios_ve_interval()
                                              ? &ucb_setting.ios_ve_interval() : NULL;
    const reco::VeInterval* android_ve_interval = ucb_setting.has_android_ve_interval()
                                              ? &ucb_setting.android_ve_interval() : NULL;
    // 检查是否命中 appname
    for (int i = 0; i < ucb_setting.ve_setting_size(); i ++) {
      const reco::VeSetting& ve_setting = ucb_setting.ve_setting(i);
      if (ve_setting.appname() == reco_request->request->app_token()) {
        // 如果命中 appname ，取渠道的 ios_ve 和 android_ve
        ios_ve = &ve_setting.ios_ve();
        android_ve = &ve_setting.android_ve();
        ios_ve_interval = ve_setting.has_ios_ve_interval() ? &ve_setting.ios_ve_interval() : NULL;
        android_ve_interval = ve_setting.has_android_ve_interval() ? &ve_setting.android_ve_interval() : NULL;
        break;
      }
    }
    // 未命中 appname ，使用全量 ve 过滤设置过滤
    const std::string& nor_ve = normalizeVe(user_param.ve());
    if (reco_request->user_param_info.is_ios) {
      if (ios_ve->size() > 0) {
        if (!arrayContain(*ios_ve, nor_ve)) {
          VLOG(1) << "filtered by not contain ios enum ve: " << item.item_id;
          return true;
        }
      } else if (ios_ve_interval != NULL) {
        if (!veInSettingInterval(nor_ve, *ios_ve_interval)) {
          VLOG(1) << "filtered by not contain ios interval ve: " << item.item_id;
          return true;
        }
      }
    } else if (reco_request->user_param_info.is_android) {
      if (android_ve->size() > 0) {
        if (!arrayContain(*android_ve, nor_ve)) {
          VLOG(1) << "filtered by not contain android enum ve: " << item.item_id;
          return true;
        }
      } else if (android_ve_interval != NULL) {
        if (!veInSettingInterval(nor_ve, *android_ve_interval)) {
          VLOG(1) << "filtered by not contain android interval ve: " << item.item_id;
          return true;
        }
      }
    }
  }
  // 未设置 item 的 ucb 过滤规则，或者没有被过滤
  return false;
}
}  // namespace leafserver
}  // namespace reco
