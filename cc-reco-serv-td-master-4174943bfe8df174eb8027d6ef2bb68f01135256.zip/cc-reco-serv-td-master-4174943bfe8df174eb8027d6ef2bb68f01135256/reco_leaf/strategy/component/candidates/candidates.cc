#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"

#include <algorithm>
#include <unordered_map>
#include <utility>

#include "reco/bizc/common/index_strategy_define.h"
#include "reco/bizc/common/item_level_define.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/strategy/component/scorer/rough_predictor.h"
#include "reco/serv/reco_leaf/strategy/common/topn.h"
#include "reco/module/cdoc_convertor/breaking/breaking_recognition.h"
// #include "reco/serv/reco_leaf/strategy/component/filter/filter_dict.h"
#include "serving_base/data_manager/data_manager.h"

#include "serving_base/utility/timer.h"

#include "base/time/time.h"
#include "base/strings/string_printf.h"
#include "base/common/logging.h"

namespace reco {
namespace leafserver {
DEFINE_bool(do_ucb_quality_filter, true, "ucb 质量过滤");
DEFINE_bool(do_item_quality_dirty_filter, false, "item 质量低俗强制过滤");
DEFINE_bool(do_item_sensitive_filter, false, "item 质量过滤");
DEFINE_int32(new_rough_rank, 1, "");
DEFINE_bool(do_title_filter, false, "");
DEFINE_bool(do_video_filter, false, "");
DEFINE_bool(do_video_risk_check, false, "");
DEFINE_bool(filter_debug, false, "");
// DEFINE_bool(do_video_special_filter, false, "");

const float CandidatesExtractor::kIncompTimeLevelCtrTrhes = 0.03;

bool NewsItemSortFunc(const RoughScore& left, const RoughScore& right) {
  return left.score > right.score;
}

CandidatesExtractor::CandidatesExtractor(const reco::NewsIndex* index) : news_index_(index) {}

CandidatesExtractor::~CandidatesExtractor() { }

void CandidatesExtractor::GenReqBitForStreamFilter(const RecoRequest* request,
                                                   reco::filter::BitList* bitlist) {
  reco::filter::BitList& cur_bitlist = *bitlist;
  // process app
  auto app_name = reco::common::GetAppName(request->request->app_token());
  if (app_name == reco::common::kUcIflow) {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrAppValueUC);
    tmp_value <<= reco::filter::OriFilterStrategy::AppOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else if (app_name == reco::common::kUcToutiao) {
    reco::filter::BitList tmp_value((uint32)reco::filter::KAttrAppValueUCNews);
    tmp_value <<= reco::filter::OriFilterStrategy::AppOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else if (app_name == reco::common::kTuDouIflow || app_name == reco::common::kTuDouPCIflow) {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrAppValueTudou);
    tmp_value <<= reco::filter::OriFilterStrategy::AppOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else if (app_name == reco::common::kYouKuIflow || app_name == reco::common::kYouKuPCIflow ||
             app_name == reco::common::kYoukuOpenIflow || app_name == reco::common::kYoukuIkuIflow) {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrAppValueYouku);
    tmp_value <<= reco::filter::OriFilterStrategy::AppOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrAppValueOther);
    tmp_value <<= reco::filter::OriFilterStrategy::AppOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  }
  // process sub app
  // 目前没有识别 sub app 的逻辑, 默认都按主要子渠道赋值
  {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrSubAppValueMain);
    tmp_value <<= reco::filter::OriFilterStrategy::SubAppOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  }
  // process platform
  if (request->user_param_info.is_ios) {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrPlatformValueIOS);
    tmp_value <<= reco::filter::OriFilterStrategy::PlatformOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else if (request->user_param_info.is_android) {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrPlatformValueAndroid);
    tmp_value <<= reco::filter::OriFilterStrategy::PlatformOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrPlatformValueWeb);
    tmp_value <<= reco::filter::OriFilterStrategy::PlatformOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  }
  // process region
  auto other_main_city_dict = DM_GET_DICT(reco::dm::DictManager::UnorderedSetStr,
                                          DynamicDictContainer::kOtherMainCityFile_);
  if (request->user_param_info.city == "北京") {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrRegionValueBJ);
    tmp_value <<= reco::filter::OriFilterStrategy::RegionOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else if (request->user_param_info.city == "上海") {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrRegionValueSH);
    tmp_value <<= reco::filter::OriFilterStrategy::RegionOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else if (request->user_param_info.city == "广州") {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrRegionValueGZ);
    tmp_value <<= reco::filter::OriFilterStrategy::RegionOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else if (other_main_city_dict->size() > 0 &&
             other_main_city_dict->find(request->user_param_info.city) != other_main_city_dict->end()) {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrRegionValueOtherMain);
    tmp_value <<= reco::filter::OriFilterStrategy::RegionOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrRegionValueOther);
    tmp_value <<= reco::filter::OriFilterStrategy::RegionOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  }
  // process time
  // restrict time span 7:00 - 24:00
  base::Time::Exploded exploded;
  request->current_time.LocalExplode(&exploded);
  if (exploded.hour >= 7) {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrTimeRangeValueControl);
    tmp_value <<= reco::filter::OriFilterStrategy::TimeRangeOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrTimeRangeValueNotControl);
    tmp_value <<= reco::filter::OriFilterStrategy::TimeRangeOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  }
  // process channel
  if (request->channel_id == reco::common::kRecoChannelId) {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrChannelValueNews);
    tmp_value <<= reco::filter::OriFilterStrategy::ChannelOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else if (reco::common::IsVideoChannel(request->channel_id)) {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrChannelValueVideo);
    tmp_value <<= reco::filter::OriFilterStrategy::ChannelOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrChannelValueOther);
    tmp_value <<= reco::filter::OriFilterStrategy::ChannelOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  }
  // process new user
  if (request->user_param_info.is_new_user) {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrUserNewValueY);
    tmp_value <<= reco::filter::OriFilterStrategy::UserNewOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrUserNewValueN);
    tmp_value <<= reco::filter::OriFilterStrategy::UserNewOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  }
  // process ditry user
  if (request->user_feas->attr.dirty_level < kDirtyMid) {
    // 容忍度低, 非色情用户
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrUserDirtyValueN);
    tmp_value <<= reco::filter::OriFilterStrategy::UserDirtyOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrUserDirtyValueY);
    tmp_value <<= reco::filter::OriFilterStrategy::UserDirtyOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  }
  // process bluffing user
  if (request->user_feas->attr.bluffing_level < kBluffingMid) {
    // 容忍度低, 非标题党用户
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrUserTitlePartyN);
    tmp_value <<= reco::filter::OriFilterStrategy::UserTitlePartyOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  } else {
    reco::filter::BitList tmp_value((uint32)reco::filter::kAttrUserTitlePartyY);
    tmp_value <<= reco::filter::OriFilterStrategy::UserTitlePartyOffset;
    cur_bitlist = cur_bitlist | tmp_value;
  }
}

void CandidatesExtractor::FillFilterOptions(reco::filter::Options* filter_options,
                                            int32 candidate_type, const RecoRequest* request) {
  filter_options->Clear();
  // 规则清空
  filter_options->filter_subset = 0;
  filter_options->is_debug = FLAGS_filter_debug;

  filter_options->risk_media_dict
      = DM_GET_DICT(reco::filter::RiskMediaDict, reco::filter::DynamicDictContainer::kRiskMediaFile);
  filter_options->stream_filter = LeafDataManager::GetGlobalData()->stream_filter;

  // open risk media filter
  filter_options->filter_subset |= reco::filter::RiskMediaFilter;
  // open item filter
  filter_options->filter_subset |= reco::filter::ItemFilter;

  filter_options->do_video_filter = FLAGS_do_video_filter;
  filter_options->do_news_filter = true;
  filter_options->do_video_risk_check = FLAGS_do_video_risk_check;

  if (request != NULL) {
    // open user & session filter
    filter_options->filter_subset |= reco::filter::SessionFilter;
    filter_options->filter_subset |= reco::filter::AppTokenFilter;

    // 变量
    filter_options->shown_set = request->shown_dict;
    filter_options->user_feas = request->user_feas;
    filter_options->rule_chain = request->user_param_info.rule_chain;
    GenReqBitForStreamFilter(request, &filter_options->req_bit);
    filter_options->channel_id = request->channel_id;
    filter_options->province = request->user_param_info.province;
    filter_options->city = request->user_param_info.city;
    filter_options->app_token = request->request->app_token();
    auto app_token_bit_index = DM_GET_DICT(reco::filter::AppTokenBitIndex,
                                             reco::filter::DynamicDictContainer::kAppTokenBitIndexFile);
    if (app_token_bit_index.get() != NULL) {
      auto iter = app_token_bit_index->app_token_bit_index.find(filter_options->app_token);
      if (iter != app_token_bit_index->app_token_bit_index.end()) {
        filter_options->app_token_idx = iter->second;
      }
    }
    // title
    if (request->request->has_filter_criterion()) {
      if (request->request->filter_criterion().title_min_len() > 0) {
        filter_options->title_min_len = request->request->filter_criterion().title_min_len();
      }
      if (request->request->filter_criterion().title_max_len() > 0) {
        filter_options->title_max_len = request->request->filter_criterion().title_max_len();
      }
    }
    filter_options->today_access_cnt = request->today_access_cnt;
    // flags
    filter_options->is_main_city = request->user_param_info.is_main_city;
    filter_options->is_new_user = request->user_param_info.is_new_user;
    filter_options->is_wsg_enc = request->user_param_info.wsg_enc;
    filter_options->is_loyal = request->user_param_info.is_loyal;
    filter_options->is_ios = request->user_param_info.is_ios;
    filter_options->is_inner_app = request->user_param_info.is_inner_qudao;
    filter_options->is_uc_iflow_app = request->user_param_info.is_uc_iflow_qudao;

    // filter switch
    filter_options->do_apprule_filter = true;

    filter_options->do_sensitive_filter = FLAGS_do_item_sensitive_filter;
    filter_options->do_sim_check_filter = true;

    filter_options->do_user_show_history_filter = true;
    filter_options->do_title_filter = FLAGS_do_title_filter;
    filter_options->do_user_dislike_filter = true;
    if (FLAGS_do_item_quality_dirty_filter
        || request->user_param_info.do_dirty_filter) {
      filter_options->do_quality_dirty_filter = true;
    } else {
      filter_options->do_quality_dirty_filter = false;
    }
    filter_options->do_valid_in_app_filter = true;
    filter_options->do_rule_chain_filter = true;

    filter_options->do_stream_filter = true;
    filter_options->do_first_n_screen_filter = true;
    if (request->request->has_pcode()) {
      filter_options->pcode = request->request->pcode();
      filter_options->do_video_play_control_filter = true;
    }
  }

  if (candidate_type == kCandidateChannelId) {
    filter_options->do_local_channel_filter = true;
  }

  if (candidate_type == kCandidateCrowdOper) {
    filter_options->do_item_valid_filter = true;
  }

  if (candidate_type == kCandidatePornUser) {
    filter_options->do_sensitive_filter = false;
    filter_options->do_quality_dirty_filter = false;
  }
}

void CandidatesExtractor::FillFilterCount(FilterCount& filter_count,
                                          reco::filter::FilterReason& filterno) {
  ++filter_count.filtered_num;
  if (filterno == reco::filter::kFilterByAppRule ||
      filterno == reco::filter::kFilterByAppRuleMainCity) {
    ++filter_count.app_rule_filtered_num;
  } else if (filterno == reco::filter::kFilterByValidInApp) {
    ++filter_count.app_filtered_num;
  } else if (filterno == reco::filter::kFilterByDirty) {
    ++filter_count.dirty_filtered_num;
  } else if (filterno > 29 && filterno < 39) {
    ++filter_count.risk_media_filtered_num;
  } else if (filterno == reco::filter::kFilterBySensitive) {
    ++filter_count.sensitive_filtered_num;
  } else if (filterno == reco::filter::kFilterByRuleChain) {
    ++filter_count.rule_chain_filtered_num;
  } else if (filterno == reco::filter::kFilterByStreamFilter) {
    ++filter_count.stream_filtered_num;
  } else if (filterno == reco::filter::kFilterByFirstNScreen) {
    ++filter_count.first_n_filtered_num;
  }
}

void CandidatesExtractor::GetCandidatesByCityId(int64 city_id, const RecoRequest* request,
                                                std::vector<ItemInfo>* ret_items, int req_return) const {
  const int max_return = GetSysLevelRatio(request->user_param_info.is_inner_qudao) * req_return * 1.2;

  ret_items->clear();
  if (city_id <= 0) return;

  const std::vector<ItemInfo>* candidate_items = NULL;
  candidate_items = news_index_->GetDefaultReco(reco::common::kLocalChannelId, city_id, false);
  if (candidate_items == NULL) {
    return;
  }

  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidateCityId, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  for (int i = 0; i < (int)candidate_items->size(); ++i) {
    if ((int)ret_items->size() > max_return) {
      VLOG(1) << "reach max return num: " << city_id;
      break;
    }
    const ItemInfo& item = (*candidate_items)[i];
    VLOG(2) << "candidate item: " << city_id << ", " << item.item_id;

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      continue;
    }

    // 推荐频道不下发自媒体的 POI 新闻
    // if (request->channel_id == reco::common::kRecoChannelId
    //     && item.is_source_wemedia) {
    //   continue;
    // }
    ret_items->push_back((*candidate_items)[i]);
  }

  LOG(INFO) << "uid:" << request->request->user().user_id()
            << ", city_id:" << city_id
            << ", candidate:" << candidate_items->size()
            << ", " << filter_count.ToString()
            << ", remain:" << ret_items->size();
}

void CandidatesExtractor::GetCandidatesByPOI(int64 area_id, const RecoRequest* request,
                                             std::vector<ItemInfo>* ret_items, int req_return) const {
  const int max_return = GetSysLevelRatio(request->user_param_info.is_inner_qudao) * req_return * 1.2;

  ret_items->clear();

  const std::vector<ItemInfo>* candidate_items = NULL;
  candidate_items = news_index_->GetPOIDefaultReco(area_id);
  if (candidate_items == NULL) {
    return;
  }
  VLOG(1) << "get POI candidate from index: " << area_id << ", " << candidate_items->size();

  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidatePOI, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  for (int i = 0; i < (int)candidate_items->size(); ++i) {
    if ((int)ret_items->size() > max_return) {
      VLOG(1) << "reach max return num: " << area_id;
      break;
    }
    const ItemInfo& item = (*candidate_items)[i];
    VLOG(2) << "candidate item: " << area_id << ", " << item.item_id;

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      continue;
    }

    // 推荐频道不下发自媒体的 POI 新闻
    if (request->channel_id == reco::common::kRecoChannelId
        && item.is_source_wemedia) {
      continue;
    }

    ret_items->push_back((*candidate_items)[i]);
  }

  LOG(INFO) << "uid:" << request->request->user().user_id()
            << ", area_id:" << area_id
            << ", candidate:" << candidate_items->size()
            << ", " << filter_count.ToString()
            << ", remain:" << ret_items->size();
}

void CandidatesExtractor::GetLocalBreakingCandidatesByCityId(int64 city_id,
                                                             const RecoRequest* request,
                                                             std::vector<ItemInfo>* ret_items,
                                                             int req_return) const {
  //const int max_return = GetSysLevelRatio(request->user_param_info.is_inner_qudao) * req_return * 1.2;
  // TODO
  const int max_return = 1;
  serving_base::Timer timer;

  ret_items->clear();
  if (city_id <= 0) return;

  const std::vector<ItemInfo>* candidate_items = NULL;
  timer.Start();
  candidate_items = news_index_->GetLocalBreakingDefaultReco(city_id);
  VLOG(1) << "GetLocalBreakingDefaultReco cost " << timer.Stop();
  if (candidate_items == NULL) {
    VLOG(1) << "get local breaking default reco null " << city_id;
    return;
  }
  VLOG(1) << "get local breaking candidates size " << candidate_items->size();

  // 获取 item 对应突发事件属性词典
  const std::unordered_map<uint64, reco::LocalBreaking>* item_breaking_dict = NULL;
  item_breaking_dict = news_index_->GetItemBreakingDict();
  if (item_breaking_dict == NULL) {
    return;
  }

  // 解析突发事件，1按事件类型组织，2把未过期的高置信item作为候选
  std::unordered_map<int32, std::vector<uint64> > event_type_item_dict;
  // TODO: add variable
  int max_size = 30, curr_size = 0;
  TopN<ItemInfo> valid_items(max_size);
  for (size_t i = 0; i < candidate_items->size(); ++i) {
    uint64 item_id = (*candidate_items)[i].item_id;
    auto breaking_it = item_breaking_dict->find(item_id);
    if (breaking_it == item_breaking_dict->end()) {
      continue;
    }
    if (breaking_it->second.breaking_infos_size() == 0) {
      continue;
    }
    const reco::LocalBreakingInfo& breaking_info = breaking_it->second.breaking_infos(0);

    auto event_it = event_type_item_dict.find(breaking_info.event_type());
    std::vector<uint64>* item_ptr;
    if (event_it == event_type_item_dict.end()) {
      item_ptr = &(event_type_item_dict.insert(std::make_pair(
              breaking_info.event_type(), std::vector<uint64>())).first->second);
    } else {
      item_ptr = &(event_it->second);
    }
    item_ptr->push_back(item_id);

    if (curr_size >= max_size) {
      continue;
    }

    if (breaking_info.reliability() != reco::common::BreakingReliability::HIGH_CREDIBLE) {
      continue;
    }

    base::Time stop_time;
    base::Time::FromStringInSeconds(breaking_info.stop_time().c_str(), &stop_time);
    if (base::Time::Now() >= stop_time) {
      continue;
    }

    base::Time start_time;
    base::Time::FromStringInSeconds(breaking_info.start_time().c_str(), &start_time);
    valid_items.add((*candidate_items)[i], start_time.ToDoubleT());
    ++curr_size;
  }
  std::vector<ItemInfo> topn_items;
  valid_items.get_top_n(&topn_items);
  VLOG(1) << "valid items size, " << topn_items.size();
  if (topn_items.size() == 0) {
    return;
  }

  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidateLocalBreaking, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  // 正常走过滤流程，看能否有留下的
  std::vector<std::pair<ItemInfo, reco::filter::FilterReason> > recall_items;
  for (size_t i = 0; i < topn_items.size(); ++i) {
    if ((int)ret_items->size() >= max_return) {
      VLOG(1) << "reach max return num: " << city_id;
      break;
    }
    const ItemInfo& item = topn_items[i];
    VLOG(1) << "candidate item: " << city_id << ", " << item.item_id;

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      if (filterno == reco::filter::kFilterByShownHistory) {
        VLOG(1) << "filter item by shown history: " << item.item_id << " reason: " << filterno;
        recall_items.push_back(std::make_pair(item, filterno));
      } else {
        VLOG(1) << "filter item: " << item.item_id << " reason: " << filterno;
        FillFilterCount(filter_count, filterno);
      }
      continue;
    }
    ret_items->push_back(topn_items[i]);
  }
  VLOG(1) << "ret_items size " << ret_items->size()
          << "recall items size " << recall_items.size();

  // 都被滤掉了，对历史过滤掉的那部分做召回
  if (ret_items->size() == 0 && recall_items.size() > 0) {
    // 根据展现历史和点击历史生成item集合判重
    std::unordered_set<uint64> history_items;
    int64 min_time = base::GetTimestamp() - 3 * base::Time::kMicrosecondsPerDay;
    timer.Start();
    for (int i = request->user_info->shown_history_size() - 1; i >= 0; i--) {
      const reco::user::ViewClickItem& item = request->user_info->shown_history(i);
      // 只取72小时之内的展现item
      if (item.view_timestamp() < min_time) {
        break;
      }
      history_items.insert(item.item_id());
    }
    for (int i = request->user_info->recent_click_size() - 1; i >= 0; i--) {
      const reco::user::ViewClickItem& item = request->user_info->recent_click(i);
      if (item.click_timestamp() < min_time) {
        break;
      }
      history_items.insert(item.item_id());
    }
    VLOG(1) << "uid " << request->user_info->identity().user_id()
            << " shown history size " << request->user_info->shown_history_size()
            << " click history size " << request->user_info->recent_click_size()
            << " process history item time " << timer.Stop();

    VLOG(1) << "recent history_items size " << history_items.size();

    // 展现历史重复的，如果不是自身id重复的，再召回
    for (size_t i = 0; i < recall_items.size(); ++i) {
      if ((int)ret_items->size() >= max_return) {
        VLOG(1) << "reach max return num: " << city_id;
        break;
      }
      const ItemInfo& item = recall_items[i].first;
      bool found = false;
      auto breaking_it = item_breaking_dict->find(item.item_id);
      if (breaking_it == item_breaking_dict->end()) {
        continue;
      }
      int32 event_type = breaking_it->second.breaking_infos(0).event_type();

      // 根据待召回item的事件类型，取该类型下的所有item，判断这些item是否被用户看过
      auto event_it = event_type_item_dict.find(event_type);
      if (event_it != event_type_item_dict.end()) {
        for (size_t j = 0; j < event_it->second.size(); ++j) {
          uint64 event_item_id = event_it->second[j];
          if (history_items.find(event_item_id) != history_items.end()) {
            VLOG(1) << "history item found event! " << event_item_id;
            found = true;
            break;
          }
        }
      }

      if (!found) {
        // 没有看过item
        ret_items->push_back(item);
      } else {
        FillFilterCount(filter_count, recall_items[i].second);
        VLOG(1) << "already viewed event " << event_type;
      }
    }
  }

  LOG(INFO) << "uid:" << request->request->user().user_id()
            << ", city_id:" << city_id
            << ", candidate:" << candidate_items->size()
            << ", " << filter_count.ToString()
            << ", remain:" << ret_items->size();
}

void CandidatesExtractor::RoughRankByCategory(const reco::Category& category,
                                              const RecoRequest* request,
                                              std::vector<ItemInfo>* ret_items,
                                              int req_return,
                                              RecoDebugger* debugger) const {
  const int max_return = GetSysLevelRatio(request->user_param_info.is_inner_qudao) * req_return;

  ret_items->clear();

  const std::vector<ItemInfo>* candidate_items = NULL;
  candidate_items = news_index_->GetDefaultReco(category);
  if (candidate_items == NULL) {
    LOG(ERROR) << "news has no such category, category is: " << category.category();
    return;
  }
  VLOG(1) << "get candidate from index: " << category.category() << ", " << candidate_items->size();
  if (debugger != NULL)
    debugger->TraceCategoryIndexItems(*candidate_items);

  //int new_item_num = 0;
  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidateCategory, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  std::unordered_map<std::string, int> subcate_limit_map;
  static const std::unordered_set<std::string> kDoSubCates = { "科技", "财经", "体育" };
  bool do_subcate_limit = kDoSubCates.find(category.category()) != kDoSubCates.end();

  std::vector<RoughScore> candidate_vec;
  RoughScore score;
  for (int i = 0; i < (int)candidate_items->size(); ++i) {
    const ItemInfo& item = (*candidate_items)[i];
    if ((int)candidate_vec.size() > kMaxCandidateNum) {
      break;
    }

    if ((int)candidate_vec.size() > kMaxCandidateNum) {
      VLOG(2) << "reach max return num: " << category.category();
      break;
    }

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      if (debugger != NULL)
        debugger->SetItemFilterReason(item.item_id, filterno);
      continue;
    }

    if (do_subcate_limit && !item.sub_category.empty()) {
      auto it = subcate_limit_map.find(item.sub_category);
      if (it != subcate_limit_map.end()) {
        if (it->second >= max_return / 2) {
          continue;
        } else {
          it->second += 1;
        }
      } else {
        subcate_limit_map.insert(std::make_pair(item.sub_category, 1));
      }
    }

    score.index = i;
    score.score = -1.0;
    candidate_vec.push_back(score);
  }
  RoughPredictor rough_predictor(news_index_);
  rough_predictor.BatchCalcScore(*(request->user_info), &candidate_vec, candidate_items);

  std::sort(candidate_vec.begin(), candidate_vec.end(), NewsItemSortFunc);
  for (int i = 0; i < (int)candidate_vec.size(); ++i) {
    if ((int)ret_items->size() > max_return) {
      break;
    }
    int index = candidate_vec[i].index;
    ret_items->push_back((*candidate_items)[index]);
    VLOG(2) << "candicate itemid: " << (*candidate_items)[index].item_id
            << " candicate score: " << candidate_vec[i].score;
  }

  LOG(INFO) << "uid:" << request->request->user().user_id()
            << ", category:" << category.category()
            << ", candidate:" << candidate_items->size()
            << ", " << filter_count.ToString()
            << ", remain:" << ret_items->size();
}

void CandidatesExtractor::GetCandidatesByCategory(const reco::Category& category,
                                                  const RecoRequest* request,
                                                  std::vector<ItemInfo>* ret_items,
                                                  int req_return,
                                                  RecoDebugger* debugger) const {
  if (FLAGS_new_rough_rank == 1 && request->request->app_token() == reco::common::kUCBIflowUser) {
    RoughRankByCategory(category, request, ret_items, req_return, debugger);
    return;
  }

  ret_items->clear();
  const int max_return = GetSysLevelRatio(request->user_param_info.is_inner_qudao) * req_return;

  const std::vector<ItemInfo>* candidate_items = NULL;
  candidate_items = news_index_->GetDefaultReco(category);
  if (candidate_items == NULL) {
    LOG(ERROR) << "news has no such category, category is: " << category.category();
    return;
  }
  VLOG(1) << "get candidate from index: " << category.category() << ", " << candidate_items->size();
  if (debugger != NULL)
    debugger->TraceCategoryIndexItems(*candidate_items);

  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidateCategory, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  auto personal_item_dicts = request->personal_item_dicts;

  int new_item_num = 0;
  std::vector<int> uncertain_idx_vec;
  for (int i = 0; i < (int)candidate_items->size(); ++i) {
    if ((int)ret_items->size() > max_return) {
      VLOG(2) << "reach max return num: " << category.category();
      break;
    }
    const ItemInfo& item = (*candidate_items)[i];
    VLOG(2) << "candidate item: " << category.category() << ", " << item.item_id;

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      if (debugger != NULL)
        debugger->SetItemFilterReason(item.item_id, filterno);
      continue;
    }

    bool put_to_uncertain = false;
    if (request->is_today_req) {
      if (item.time_level == reco::kGoodTimeliness) {
        // ok item
      } else if (item.time_level == reco::kMidTimeliness) {
        if (item.show_num >= kIncompTimeLevelShowThres && item.ctr >= kIncompTimeLevelCtrTrhes) {
          // is ok item
        } else {
          put_to_uncertain = true;
        }
      } else {
        put_to_uncertain = true;
      }
    } else {
      int64 item_timestamp = news_index_->GetCreateTimestampByItemId(item.item_id);
      if (request->start_news_timestamp <= item_timestamp && item_timestamp < request->end_news_timestamp) {
        // is ok item
      } else {
        if (item.show_num >= kIncompTimeLevelShowThres && item.ctr >= kIncompTimeLevelCtrTrhes) {
          // is ok item
        } else {
          put_to_uncertain = true;
        }
      }
    }
    if (item.show_num < kNewItemShowLimit && new_item_num >= kNewItemCandidateLimit) {
      put_to_uncertain = true;
    }
    if (put_to_uncertain) {
      if (personal_item_dicts->find(item.item_id) == personal_item_dicts->end()) {
        ++filter_count.filtered_num;
        uncertain_idx_vec.push_back(i);
        continue;
      }
    }
    ret_items->push_back((*candidate_items)[i]);
    if (item.show_num < kNewItemShowLimit) {
      ++new_item_num;
    }
  }

  if (request->user_param_info.is_inner_qudao) {
    // 如果当天文章数不足，从 uncertain 列表中补充
    for (int i = 0; i < (int)uncertain_idx_vec.size(); ++i) {
      const uint32 min_num = kMinCandidateNum * GetSysLevelRatio(request->user_param_info.is_inner_qudao);
      if (ret_items->size() >= min_num)
        break;

      int idx = uncertain_idx_vec.at(i);
      ret_items->push_back((*candidate_items)[idx]);
      --filter_count.filtered_num;
    }
  }

  LOG(INFO) << "uid:" << request->request->user().user_id()
            << ", category:" << category.category()
            << ", candidate:" << candidate_items->size()
            << ", " << filter_count.ToString()
            << ", remain:" << ret_items->size();
}


inline void GetChannelCategories(int64 channel_id, std::unordered_set<std::string>* category_set) {
  category_set->clear();

  const std::unordered_map<int64, std::vector<std::pair<std::string, float> > >&
      channel_categories = LeafDataManager::GetGlobalData()->channel_categories;

  auto channel_iter = channel_categories.find(channel_id);
  if (channel_iter == channel_categories.end()) return;

  const std::vector<std::pair<std::string, float> >& categories = channel_iter->second;
  for (size_t k = 0; k < categories.size(); ++k) {
    category_set->insert(categories[k].first);
  }
}

void CandidatesExtractor::GetCandidatesByChannelId(int64 channel_id,
                                                   const RecoRequest* request,
                                                   std::vector<ItemInfo>* ret_items,
                                                   int req_return,
                                                   RecoDebugger* debugger,
                                                   bool only_video) const {
  ret_items->clear();
  int max_return = req_return;
  if (channel_id != reco::common::kHotChannelId) {
    int max_return = GetSysLevelRatio(request->user_param_info.is_inner_qudao) * req_return;
    if (channel_id == reco::common::kLocalChannelId) {
      max_return *= 1.2;
    }
  }
  max_return = std::max(max_return * 1.f,
                        kMinCandidateNum * GetSysLevelRatio(request->user_param_info.is_inner_qudao));

  // TODO(KouYan): 临时需求，视频支持运营配置的
  if (channel_id == reco::common::kVideoChannelId && request->reviewed_filter_hit) {
    return;
  }

  const std::vector<ItemInfo>* candidate_items = NULL;
  int64 region_id = -1;
  if (channel_id == reco::common::kLocalChannelId) {
    if (!request->request->has_region_id()) {
      LOG(ERROR) << "region_id not specified for local channel request";
      return;
    }
    if (!base::StringToInt64(request->request->region_id(), &region_id)) {
      LOG(ERROR) << "region_id illegal, convert from string to int64 fail: " << request->request->region_id();
      return;
    }
  }
  candidate_items = news_index_->GetDefaultReco(channel_id, region_id, only_video);
  if (candidate_items == NULL) {
    LOG_EVERY_N(INFO, 1000) << "no items, chanel_id:" << channel_id;
    return;
  }
  if (debugger != NULL)
    debugger->TraceCategoryIndexItems(*candidate_items);

  // 获取 channel 对应的 category，为空表示不限制
  std::unordered_set<std::string> category_set;
  GetChannelCategories(channel_id, &category_set);
  if (debugger != NULL)
    debugger->TraceVerticalChannelCatetory(category_set);

  // 用户过滤维度设置
  // auto personal_item_dicts = request->personal_item_dicts;

  std::vector<int> uncertain_idx_vec;
  int64 cate_filtered_num = 0;

  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidateChannelId, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  std::unordered_map<std::string, int> subcate_limit_map;
  static const std::unordered_set<int64> kSubCateLimitChannels = {
    reco::common::kSportChannelId, reco::common::kFinanceChannelId, reco::common::kScienceChannelId};
  bool do_subcate_limit
      = kSubCateLimitChannels.find(channel_id) != kSubCateLimitChannels.end();

  int new_item_num = 0;
  for (int i = 0; i < (int)candidate_items->size(); ++i) {
    const ItemInfo& item = (*candidate_items)[i];
    if ((int)ret_items->size() > max_return) {
      break;
    }
    // 热门频道刷新请求有额外过滤
    if (channel_id == reco::common::kHotChannelId) {
      if (item.item_type == reco::kPureVideo
          || item.hot_level < 10) {
        if (debugger != NULL)
          debugger->SetItemFilterReason(item.item_id, reco::filter::kFilterByHotChannelVideo);
        ++filter_count.filtered_num;
        continue;
      }
    }

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      if (debugger != NULL)
        debugger->SetItemFilterReason(item.item_id, filterno);
      continue;
    }

    // category 限制
    const std::string& nested_cate = item.category + "-" + item.sub_category;
    if (!category_set.empty()
        && category_set.find(item.category) == category_set.end()
        && category_set.find(nested_cate) == category_set.end()) {
      if (item.category == "未分类") {
        uncertain_idx_vec.push_back(i);
      }
      ++cate_filtered_num;
      if (debugger != NULL)
        debugger->SetItemFilterReason(item.item_id,
                                      reco::filter::kUserCategoryNotMatchFiltered);
      continue;
    }

    bool put_to_uncertain = false;
    if (item.show_num < kNewItemShowLimit && new_item_num >= kNewItemCandidateLimit) {
      put_to_uncertain = true;
    }
    if (do_subcate_limit && !item.sub_category.empty()) {
      auto it = subcate_limit_map.find(item.sub_category);
      if (it != subcate_limit_map.end()) {
        if (it->second >= max_return / 2) {
          put_to_uncertain = true;
        } else {
          it->second += 1;
        }
      } else {
        subcate_limit_map.insert(std::make_pair(item.sub_category, 1));
      }
    }
    if (put_to_uncertain) {
      uncertain_idx_vec.push_back(i);
      ++filter_count.filtered_num;
      continue;
    }
    if (item.show_num < kNewItemShowLimit) {
      ++new_item_num;
    }
    ret_items->push_back(item);
  }

  if (request->user_param_info.is_inner_qudao) {
    // 如果当天文章数不足，从 uncertain 列表中补充
    for (int i = 0; i < (int)uncertain_idx_vec.size(); ++i) {
      if ((int)ret_items->size() >= max_return) break;
      int idx = uncertain_idx_vec.at(i);
      ret_items->push_back((*candidate_items)[idx]);
      --filter_count.filtered_num;
    }
  }

  LOG(INFO) << "uid:" << request->request->user().user_id()
            << ", channel:" << channel_id
            << ", candidate:" << candidate_items->size()
            << ", " << filter_count.ToString()
            << ", remain:" << ret_items->size();
}

void CandidatesExtractor::GetCandidates(const RecoRequest* request,
                                        std::vector<ItemInfo>* ret_items,
                                        int req_return) const {
  const int max_return = GetSysLevelRatio(request->user_param_info.is_inner_qudao) * req_return;

  ret_items->clear();
  const std::vector<ItemInfo>* candidate_items = NULL;
  candidate_items = news_index_->GetDefaultReco();
  if (candidate_items == NULL) {
    LOG(ERROR) << "get default reco fail.";
    return;
  }

  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidate, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  for (int i = 0; i < (int)candidate_items->size(); ++i) {
    if ((int)ret_items->size() > max_return) break;
    const ItemInfo& item = (*candidate_items)[i];

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      continue;
    }

    if (request->is_update_req && item.time_level <= reco::kBadTimeliness) {
      ++filter_count.filtered_num;
      continue;
    }

    if (!request->is_update_req) {
      int64 item_timestamp = item.create_timestamp;
      if (request->start_news_timestamp <= item_timestamp && item_timestamp < request->end_news_timestamp) {
        // is ok item
      } else {
        ++filter_count.filtered_num;
        continue;
      }
    }

    ret_items->push_back((*candidate_items)[i]);
  }

  LOG(INFO) << "uid:" << request->request->user().user_id()
            << ", candidate:" << candidate_items->size()
            << ", " << filter_count.ToString()
            << ", remain:" << ret_items->size();
}


void CandidatesExtractor::GetUCBCandidates(const RecoRequest* request,
                                           std::vector<ItemInfo>* ret_items,
                                           int req_return) const {
  // NOTE(liufei): 这里暂时不用降级调整 req_return
  //   原因： 1) 运营文章队列并不长，而且已经有 flag 来进行截断，此处不是性能瓶颈
  //   原因： 2) 运营文章下发出现排序不稳定的 case 时很难排查
  ret_items->clear();

  const std::vector<ItemInfo>* default_items = news_index_->GetUCBDefaultReco();
  if (NULL == default_items) {
    return;
  }

  for (size_t i = 0 ; i < default_items->size(); ++i) {
    if ((int)ret_items->size() >= req_return) {
      break;
    }

    const ItemInfo& item = (*default_items)[i];
    ret_items->push_back(item);
  }
}

void CandidatesExtractor::GetHotCardCandidates(std::vector<ItemInfo>* ret_items, int max_return) const {
  max_return = GetSysLevelRatio(false) * max_return;
  ret_items->clear();

  const std::vector<ItemInfo>* default_items = news_index_->GetHotCardDefaultReco();
  if (NULL == default_items) {
    return;
  }

  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidateHotCard, NULL);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  for (size_t i = 0 ; i < default_items->size(); ++i) {
    if ((int)ret_items->size() >= max_return) {
      break;
    }

    const ItemInfo& item = (*default_items)[i];

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      continue;
    }

    ret_items->push_back(item);
  }
}

void CandidatesExtractor::GetDefaultCandidates(std::vector<ItemInfo> *ret_items, int max_return,
                                               const std::string& category, int64 channelid) const {
  max_return = GetSysLevelRatio() * max_return;
  ret_items->clear();

  const std::vector<ItemInfo>* default_items = NULL;
  if (!category.empty()) {
    reco::Category reco_category;
    reco_category.set_category(category);
    reco_category.set_level(0);
    default_items = news_index_->GetDefaultReco(reco_category);
  } else if (channelid != 0) {
     default_items = news_index_->GetDefaultReco(channelid, -1, false);
  } else {
    default_items = news_index_->GetDefaultReco();
  }
  if (NULL == default_items) {
    return;
  }

  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidateDefault, NULL);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  for (size_t i = 0 ; i < default_items->size(); ++i) {
    if ((int)ret_items->size() >= max_return) {
      break;
    }

    const ItemInfo& item = (*default_items)[i];

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      continue;
    }

    ret_items->push_back(item);
  }
}

void CandidatesExtractor::GetSubscriptCandidates(
    const RecoRequest* request,
    const base::dense_hash_map<std::string, float>& subscript_sources,
    const base::dense_hash_map<std::string, float>& subscript_tags,
    std::vector<ItemInfo>* ret_items, int max_return) const {
  if (subscript_sources.empty() && subscript_tags.empty()) return;

  const std::vector<ItemInfo>* candidate_items = NULL;
  candidate_items = news_index_->GetDefaultReco();
  if (candidate_items == NULL) {
    LOG(ERROR) << "get default reco fail.";
    return;
  }

  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidateSubscript, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  std::string wemedia;
  std::vector<std::string> show_tags;
  std::vector<std::string> event_tags;
  for (int i = 0; i < (int)candidate_items->size() && i < 150000; ++i) {
    if ((int)ret_items->size() > max_return) break;
    const ItemInfo& item = (*candidate_items)[i];
    if (item.time_level != reco::kGoodTimeliness) continue;
    if (item.itemq != reco::kJingpinItemq
        && (item.show_num < 2000
            || item.ctr < 0.05
            || item.itemq < reco::kNormalItemq)) continue;
    bool hit_subscript = false;
    if (!subscript_sources.empty()
        && item.is_source_wemedia
        && news_index_->GetWeMediaPersonByDocId(item.doc_id, &wemedia)
        && !wemedia.empty()
        && subscript_sources.find(wemedia) != subscript_sources.end()) {
      hit_subscript = true;
    }
    show_tags.clear();
    if (!hit_subscript
        && !subscript_tags.empty()
        && news_index_->GetShowTagByDocId(item.doc_id, &show_tags)
        && !show_tags.empty()) {
      for (size_t idx = 0; idx != show_tags.size(); ++idx) {
        const std::string& tag = show_tags.at(idx);
        if (subscript_tags.find(tag) != subscript_tags.end()) {
          hit_subscript = true;
          break;
        }
      }
    }
    event_tags.clear();
    if (!hit_subscript
        && !subscript_tags.empty()
        && news_index_->GetEventTagByDocId(item.doc_id, &event_tags)
        && !event_tags.empty()) {
      for (size_t idx = 0; idx != event_tags.size(); ++idx) {
        const std::string& tag = event_tags.at(idx);
        if (subscript_tags.find(tag) != subscript_tags.end()) {
          hit_subscript = true;
          break;
        }
      }
    }

    if (!hit_subscript) continue;

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      continue;
    }

    ret_items->push_back(item);
  }

  LOG(INFO) << "SubscriptCandidate, uid:" << request->request->user().user_id()
            << ", remain:" << ret_items->size();
}

void CandidatesExtractor::GetVerticalCandidates(reco::Category category, bool timely,
                                                std::vector<ItemInfo> *ret_items, int max_return) const {
  max_return = GetSysLevelRatio() * max_return;
  ret_items->clear();

  const std::vector<ItemInfo>* default_items = news_index_->GetDefaultReco(category, timely);
  if (NULL == default_items) {
    return;
  }

  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidateVertical, NULL);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  for (size_t i = 0 ; i < default_items->size(); ++i) {
    if ((int)ret_items->size() >= max_return) {
      break;
    }

    const ItemInfo& item = (*default_items)[i];

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      continue;
    }

    ret_items->push_back(item);
  }
}

float CandidatesExtractor::GetSysLevelRatio(bool is_inner_app_token) {
  /*
  float ratio = 1.f;

  switch (LeafDataManager::GetGlobalData()->sys_status) {
    case kSysFree:
      ratio = 1.2f;
      break;
    case kSysBusy:
      ratio = 0.7f;
      break;
    case kSysFull:
      ratio = 0.5f;
      break;
    case kSysDanger:
      ratio = 0.2f;
      break;
    case kSysCritical:
      ratio = 0.1f;
      break;
    default:
      ratio = 1.0f;
      break;
  }
  */

  float ratio = LeafDataManager::GetGlobalData()->GetSelectionRatio();
  if (!is_inner_app_token) {
    ratio /= 5;
  }

  return ratio;
}

void CandidatesExtractor::GetCrowdOperCandidates(const RecoRequest* request,
                                                 int64 now_timestamp,
                                                 int max_return,
                                                 StrategyType strategy,
                                                 std::vector<ItemInfo>* ret_items,
                                                 RecoDebugger* debugger) const {
  auto crowd_dict = (strategy == kCrowdOper ?
      DM_GET_DICT(reco::dm::CrowdOperDict, DynamicDictContainer::kCrowdOperExpFile_)
      : DM_GET_DICT(reco::dm::CrowdOperDict, DynamicDictContainer::kCrowdOperWholeFile_));
  if (crowd_dict == NULL) {
    LOG(INFO) << "crowd oper get dict fail: " << strategy;
    return;
  }
  auto item_meta_dict = &(crowd_dict->item_meta_dict_);
  auto iter = crowd_dict->crowd_oper_dict_.find(request->request->user().user_id());
  if (iter == crowd_dict->crowd_oper_dict_.end()) {
    VLOG(1) << request->request->user().user_id() << " not in crowd oper dict";
    return;
  }
  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidateCrowdOper, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;
  for (size_t i = 0; i < iter->second.item_ids.size(); ++i) {
    if ((int)ret_items->size() >= max_return) break;
    const uint64 item_id = iter->second.item_ids[i];
    ItemInfo item;
    if (!news_index_->GetItemInfoByItemId(item_id, &item, false)) {
      continue;
    }
    item.strategy_type = strategy;
    item.strategy_branch = reco::kCrowdOperBranch;
    auto item_meta_iter = item_meta_dict->find(item_id);
    if (item_meta_iter == item_meta_dict->end()
        || item_meta_iter->second.timeout < now_timestamp) {
      if (debugger != NULL) debugger->SetItemFilterReason(item.item_id,
                                                          reco::filter::kCrowdOperItemTimeOutFiltered);
      continue;
    }
    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      if (debugger != NULL)
        debugger->SetItemFilterReason(item.item_id, filterno);
      continue;
    }
    item.reco_ext_info = iter->second.deliver_task_id + "|" + item_meta_iter->second.crowd;
    ret_items->push_back(item);
  }
}

void CandidatesExtractor::GetCrowdOperCandidates(const RecoRequest* request,
                                                 std::vector<ItemInfo>* ret_items,
                                                 int max_return,
                                                 RecoDebugger* debugger) const {
  ret_items->clear();

  int64 now_timestamp = base::GetTimestamp() / 1000;  // mill seconds
  // 实验下发
  GetCrowdOperCandidates(request, now_timestamp, max_return, kCrowdOper, ret_items, debugger);
  const size_t exp_crowd_size = ret_items->size();
  // 全量下发
  GetCrowdOperCandidates(request, now_timestamp, max_return, kWholeCrowdOper, ret_items, debugger);
  const size_t whole_crowd_size = ret_items->size() - exp_crowd_size;
  LOG(INFO) << "get crowd oper items: " << ret_items->size()
            << " for uid: " << request->request->user().user_id()
            << ", exp_size: " << exp_crowd_size
            << ", whole_size: " << whole_crowd_size;
}

void CandidatesExtractor::GetGuaranteeDeliverCandidates(const RecoRequest* request,
                                                        const reco::Category& category,
                                                        std::vector<ItemInfo>* ret_items,
                                                        int max_return, RecoDebugger* debugger) const {
  ret_items->clear();
  const std::vector<ItemInfo>* candidates = news_index_->GetGuaranteeQuantityReco(category);
  if (candidates == NULL) return;

  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidateCrowdOper, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  reco::dm::MediaQuantityInfo mqi;
  int64 item_limit = 0;
  for (size_t i = 0; i < candidates->size(); ++i) {
    if ((int)ret_items->size() >= max_return) return;
    const ItemInfo& item = (*candidates)[i];
    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      if (debugger != NULL)
        debugger->SetItemFilterReason(item.item_id, filterno);
      continue;
    }
    // 滤掉已经足够下发的
    if (news_index_->GetItemQuantityInfo(reco::kQueueDoc, item, &mqi, &item_limit)
        && mqi.protect_capacity > mqi.deliever_num
        && item_limit > item.show_num) {
      int64 source_deliver_num = 0;
      int64 item_deliver_num = 0;
      MediaQuantityInfoIns::instance().LocalGuaranteeDeliver(item, &source_deliver_num, &item_deliver_num);
      if (source_deliver_num * FLAGS_media_quantity_deliver_machine_num >= mqi.protect_capacity
          || item_deliver_num * FLAGS_media_quantity_deliver_machine_num >= item_limit) {
        continue;
      }
      ret_items->push_back(item);
    }
  }
}

void CandidatesExtractor::GetPornItemCandidates(const RecoRequest* request,
                                                const std::string& type,
                                                std::vector<ItemInfo>* ret_items,
                                                int max_return, RecoDebugger* debugger) const {
  ret_items->clear();
  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, kCandidatePornUser, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;
  const std::vector<ItemInfo>* items = news_index_->GetMiningStrategyReco(reco::common::kLeafBeautyMine.enum_value);
  if (items == NULL) {
    LOG(INFO) << "mining strategy reco is null";
    return;
  }
  int invalid_count = 0;
  int video_filter = 0;
  int text_filter = 0;
  int pic_filter = 0;
  int normal_filter = 0;
  for (size_t i = 0; i < items->size(); ++i) {
    if ((int)ret_items->size() >= max_return) break;
    const ItemInfo item = (*items)[i];
    if (!NewsFilter::ItemIsValid(item, request->current_timestamp)) {
      if (debugger != NULL)
        debugger->SetItemFilterReason(item.item_id, reco::filter::kFilterByNotValid);
      ++invalid_count;
      continue;
    }
    if (type == "video" && item.item_type != reco::kPureVideo) {
      ++video_filter;
      continue;
    }
    if (type == "text" && item.item_type != reco::kNews && item.item_type != reco::kReading) {
      ++text_filter;
      continue;
    }
    if (type == "pic" && item.item_type != reco::kPicture && item.item_type != reco::kPictureNews) {
      ++pic_filter;
      continue;
    }
    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      if (debugger != NULL)
        debugger->SetItemFilterReason(item.item_id, filterno);
      ++normal_filter;
      continue;
    }
    ret_items->push_back(item);
    ret_items->back().strategy_type = reco::kPornUserDeliver;
  }
  LOG(INFO) << "get porn candidates size: " << ret_items->size()
            << " invalid:" << invalid_count
            << " text_filter:" << text_filter
            << " video_filter:" << video_filter
            << " pic_filter:" << pic_filter
            << " normal_filter:" << normal_filter
            << " " << filter_count.ToString();
}


void CandidatesExtractor::BasicRuleFilter(const RecoRequest* request,
                                          const int candidate_type,
                                          const std::vector<ItemInfo>& candidates,
                                          std::vector<ItemInfo> *ret_items) {
  reco::filter::Options filter_options;
  FillFilterOptions(&filter_options, candidate_type, request);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  FilterCount filter_count;

  for (auto i = 0u; i < candidates.size(); ++i) {
    const ItemInfo& item = candidates[i];

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item, &filter_options, &filterno)) {
      FillFilterCount(filter_count, filterno);
      continue;
    }

    ret_items->push_back(item);
  }

  LOG(INFO) << "uid:" << request->request->user().user_id()
            << ", type:" << candidate_type
            << ", candidate:" << candidates.size()
            << ", " << filter_count.ToString()
            << ", remain:" << ret_items->size();
}
}  // namespace leafserver
}  // namespace reco
