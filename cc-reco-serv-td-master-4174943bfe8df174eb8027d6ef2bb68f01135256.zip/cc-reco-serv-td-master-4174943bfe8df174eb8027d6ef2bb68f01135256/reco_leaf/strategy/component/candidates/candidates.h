#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>

#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
//#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/frame/inner/dynamic_dict_container.h"
#include "reco/serv/reco_leaf/strategy/reco/offline/item_dict_manager.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/filter_rule/online/filter_monster.h"
#include "base/time/time.h"

namespace reco {
class NewsIndex;

namespace leafserver {

DECLARE_bool(do_ucb_quality_filter);
DECLARE_bool(do_item_quality_filter);
DECLARE_bool(do_item_sensitive_filter);

enum CandidateType {
  kCandidateCityId = 1,
  kCandidatePOI = 2,
  kCandidateCategory = 3,
  kCandidateChannelId = 4,
  kCandidateSubscript = 5,
  kCandidateCrowdOper = 6,
  kCandidate = 7,
  kCandidateDefault = 8,
  kCandidateHotCard = 9,
  kCandidateVertical = 10,
  kCandidateLocalBreaking = 11,
  kCandidateGuaranteeDeliver = 12,
  kCandidateSession = 13,
  kCandidateProbe = 14,
  kCandidateQuery = 15,
  kCandidatePornUser = 16,
  kCandidateVideo = 17,
};

class CandidatesExtractor {
 public:
  struct FilterCount {
    FilterCount() : filtered_num(0), app_rule_filtered_num(0), app_filtered_num(0),
    dirty_filtered_num(0), risk_media_filtered_num(0),
    sensitive_filtered_num(0), rule_chain_filtered_num(0),
    stream_filtered_num(0), first_n_filtered_num(0) {}
    std::string ToString() {
      return "filtered_num:" + base::IntToString(filtered_num)
          + ", app_rule_filtered_num:" + base::IntToString(app_rule_filtered_num)
          + ", app_filtered_num:" + base::IntToString(app_filtered_num)
          + ", dirty_filtered_num:" + base::IntToString(dirty_filtered_num)
          + ", risk_media_filtered_num:" + base::IntToString(risk_media_filtered_num)
          + ", sensitive_filtered_num:" + base::IntToString(sensitive_filtered_num)
          + ", rule_chain_filtered_num" + base::IntToString(rule_chain_filtered_num)
          + ", stream_filtered_num:" + base::IntToString(stream_filtered_num)
          + ", first_n_filtered_num:" + base::IntToString(first_n_filtered_num);
    }

    int filtered_num;
    int app_rule_filtered_num;
    int app_filtered_num;
    int dirty_filtered_num;
    int risk_media_filtered_num;
    int sensitive_filtered_num;
    int rule_chain_filtered_num;
    int stream_filtered_num;
    int first_n_filtered_num;
  };

  explicit CandidatesExtractor(const reco::NewsIndex* index);

  ~CandidatesExtractor();

  // 给定 category，返回默认推荐结果
  void GetCandidatesByCategory(const reco::Category& category, const RecoRequest* request,
                               std::vector<ItemInfo>* ret_items, int max_return,
                               RecoDebugger* debugger) const;
  // 粗排模型
  void RoughRankByCategory(const reco::Category& category, const RecoRequest* request,
                               std::vector<ItemInfo>* ret_items, int max_return,
                               RecoDebugger* debugger) const;

  // 给定 channelId，返回默认推荐结果
  void GetCandidatesByChannelId(int64 channel_id, const RecoRequest* request,
                                std::vector<ItemInfo>* ret_items, int max_return,
                                RecoDebugger* debugger, bool only_video = false) const;

  // 默认推荐结果
  void GetCandidates(const RecoRequest* request,
                     std::vector<ItemInfo>* ret_items, int max_return) const;

  // 通过 POI 获取默认推荐结果
  void GetCandidatesByPOI(int64 area_id, const RecoRequest* request,
                          std::vector<ItemInfo>* ret_items, int max_return) const;

  // 通过 city_id 获取默认推荐结果
  void GetCandidatesByCityId(int64 city_id, const RecoRequest* request,
                             std::vector<ItemInfo> *ret_items, int max_return) const;

  // 通过 city_id 获取本地突发事件推荐结果
  void GetLocalBreakingCandidatesByCityId(int64 city_id, const RecoRequest* request,
                                          std::vector<ItemInfo> *ret_items, int max_return) const;

  // 精品推荐候选集
  void GetJingpinCandidates(const RecoRequest* request,
                            std::vector<ItemInfo> *ret_items, int max_return) const;
  // get manual candidates
  void GetUCBCandidates(const RecoRequest* request,
                        std::vector<ItemInfo>* ret_items, int max_return) const;

  // hot card
  void GetHotCardCandidates(std::vector<ItemInfo> *ret_items, int max_return) const;

  // hot
  void GetDefaultCandidates(std::vector<ItemInfo> *ret_items, int max_return,
                            const std::string& category, int64 channelid) const;

  // vertical
  void GetVerticalCandidates(reco::Category category, bool timely, std::vector<ItemInfo> *ret_items,
                             int max_return) const;

  void GetSubscriptCandidates(const RecoRequest* request,
                              const base::dense_hash_map<std::string, float>& subscript_sources,
                              const base::dense_hash_map<std::string, float>& subscript_tags,
                              std::vector<ItemInfo>* ret_items, int max_return) const;

  void GetCrowdOperCandidates(const RecoRequest* request, std::vector<ItemInfo>* ret_items,
                              int max_return, RecoDebugger* debugger) const;

  void GetGuaranteeDeliverCandidates(const RecoRequest* request,
                                     const reco::Category& category,
                                     std::vector<ItemInfo>* ret_items,
                                     int max_return, RecoDebugger* debugger) const;

  void GetPornItemCandidates(const RecoRequest* request,
                             const std::string& type,
                             std::vector<ItemInfo>* ret_items,
                             int max_return, RecoDebugger* debugger) const;

  void SubCateLimit(const RecoRequest* request,
                    int64 cid, const std::string& category, int total_limit,
                    std::unordered_map<std::string, int>* subcate_limit_map) const;

  // 根据传入的 item ，走一遍过滤逻辑，因为可能来自各种召回，基本的有效性过滤也要走
  void BasicRuleFilter(const RecoRequest* request,
                       const int candidate_type,
                       const std::vector<ItemInfo>& candidates,
                       std::vector<ItemInfo> *ret_items);

  static void FillFilterOptions(reco::filter::Options* filter_options,
                         int32 candidate_type, const RecoRequest* request = NULL);
  static void GenReqBitForStreamFilter(const RecoRequest* request, reco::filter::BitList* bitlist);
  static void FillFilterCount(FilterCount& filter_count, reco::filter::FilterReason& filterno);
 private:

  void GetCrowdOperCandidates(const RecoRequest* request,
                              int64 now_timestamp,
                              int max_return,
                              StrategyType strategy,
                              std::vector<ItemInfo>* ret_items,
                              RecoDebugger* debugger) const;
 private:
  const NewsIndex* news_index_;

  bool IsFilterByRuleChain(const RuleChain& user_rule, const ItemInfo& item_info) const {
    return FilterRule::IsFiltered(user_rule, item_info.source_rule_chain);
  }

  static float GetSysLevelRatio(bool is_inner_app_token = true);

 private:
  static const int kNewItemShowLimit = 500;
  static const int kNewItemCandidateLimit = 30;
  static const uint32 kMinCandidateNum = 500;
  static const int kIncompTimeLevelShowThres = 1000;
  static const int kMaxCandidateNum = 500;
  static const float  kIncompTimeLevelCtrTrhes;
};
}
}
