#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"

#include <vector>

#include "base/testing/gtest.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/serv/reco_leaf/strategy/reco/manual/manual_reco.h"

using std::vector;

namespace reco {
namespace leafserver {

TEST(RecoDebugger, Constructor) {
  reco::leafserver::RecommendRequest request;
  reco::leafserver::RecommendResponse response;

  // case 1
  reco::leafserver::RecoDebugger debugger(NULL, request, &response);
  EXPECT_FALSE(debugger.enable_debug_);
  EXPECT_EQ(0u, debugger.trace_item_ids_set_.size());

  // case 2
  request.mutable_reco_debug_param()->set_enable_debug(true);
  reco::leafserver::RecoDebugger debugger1(NULL, request, &response);
  EXPECT_TRUE(debugger1.enable_debug_);
  EXPECT_EQ(0u, debugger1.trace_item_ids_set_.size());

  // case 3
  request.mutable_reco_debug_param()->set_enable_debug(true);
  request.mutable_reco_debug_param()->add_trace_item_ids(123L);
  request.mutable_reco_debug_param()->add_trace_item_ids(124L);
  reco::leafserver::RecoDebugger debugger2(NULL, request, &response);
  EXPECT_TRUE(debugger2.enable_debug_);
  EXPECT_EQ(2u, debugger2.trace_item_ids_set_.size());
  ASSERT_TRUE(debugger2.trace_item_ids_set_.find(123L)
                != debugger2.trace_item_ids_set_.end());
  ASSERT_TRUE(debugger2.trace_item_ids_set_.find(124L)
                != debugger2.trace_item_ids_set_.end());
}

TEST(RecoDebugger, TraceManualItemFilterInfo) {
  reco::leafserver::RecommendRequest request;
  reco::leafserver::RecommendResponse response;
  request.mutable_reco_debug_param()->add_trace_item_ids(123L);
  reco::leafserver::RecoDebugger debugger(NULL, request, &response);
  vector<reco::ItemInfo> items;
  vector<ManualItemExtInfo> ext_infos;
  reco::ItemInfo item;
  item.item_id = 123L;
  items.push_back(item);
  ManualItemExtInfo ext_info;
  ext_info.SetIsFiltered(true, kTitleLenghFiltered);
  ext_infos.push_back(ext_info);
  debugger.TraceManualItemFilterInfo(items, ext_infos);
  EXPECT_TRUE(!response.has_reco_debug_info());

  request.mutable_reco_debug_param()->set_enable_debug(true);
  request.mutable_reco_debug_param()->add_trace_item_ids(123L);
  reco::leafserver::RecoDebugger debugger1(NULL, request, &response);
  EXPECT_TRUE(debugger1.enable_debug_);
  EXPECT_EQ(1u, debugger1.trace_item_ids_set_.size());
  ASSERT_TRUE(debugger1.trace_item_ids_set_.find(123L)
                != debugger1.trace_item_ids_set_.end());

  debugger1.TraceManualItemFilterInfo(items, ext_infos);
  ASSERT_TRUE(response.has_reco_debug_info());
  ASSERT_EQ(1, response.reco_debug_info().not_reco_reason().size());
  EXPECT_EQ(123uL, response.reco_debug_info().not_reco_reason(0).item_id());
  EXPECT_EQ(kTitleLenghFiltered,
            response.reco_debug_info().not_reco_reason(0).filtered_type());
}

}  // namespace leafserver
}  // namespace reco
