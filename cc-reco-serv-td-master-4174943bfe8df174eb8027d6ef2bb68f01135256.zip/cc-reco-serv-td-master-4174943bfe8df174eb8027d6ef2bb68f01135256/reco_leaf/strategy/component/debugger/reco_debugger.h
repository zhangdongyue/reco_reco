#pragma once

#include <set>
#include <string>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <vector>

#include "base/common/basic_types.h"  // DISALLOW...
#include "base/container/dense_hash_map.h"  // dense_hash_map
#include "base/container/dense_hash_set.h"  // dense_hash_set
#include "base/testing/gtest_prod.h"  // FRIEND_TEST
#include "base/thread/sync.h"  // Mutex
#include "reco/bizc/reco_index/item_info.h"  // ItemInfo
#include "reco/bizc/reco_index/news_index.h"  // NewsIndex
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/filter_rule.pb.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"  // UserFeature

namespace reco {
namespace leafserver {

struct ManualItemExtInfo;

class RecoDebugger {
 public:
  RecoDebugger(const reco::NewsIndex* news_index,
               const RecommendRequest& request, RecommendResponse* response);
  ~RecoDebugger();

  bool enable_debug() const;

  bool NotHasDebugFlag(const std::string& flag);

  void TraceManualItemFilterInfo(const std::vector<reco::ItemInfo>& items,
                                 const std::vector<ManualItemExtInfo>& ext_infos);
  void TraceManulItemDictAndLevelScore(const reco::ItemInfo& item,
                                       const ManualItemExtInfo& ext_info,
                                       unsigned level_score);

  // 如果需要跟踪的 item_id 可以重复展现时，将 item_id 从 shown_dict 中去除
  void TraceUserShownDict(base::dense_hash_set<uint64>* shown_dict);
  void TraceUserFeature(const UserFeature& user_feature);
  void TraceCategoryDistributes(const std::vector<std::pair<float, reco::Category> >&
                                category_distributes_);
  void TraceVerticalChannelCatetory(const std::unordered_set<std::string>& category_set);

  void TraceRsbReturnNum(const std::unordered_map<int, int>& rsb_return_num_map);

  void TraceManualTopImportanceItems(const std::vector<reco::ItemInfo>& items);
  void TraceManualSndImportanceItems(const std::vector<reco::ItemInfo>& items);
  void TraceManualCategoryWholeItems(const std::unordered_map<std::string,
                                     std::vector<ItemInfo> >& category_items);
  void TraceManualPersonalItems(const std::vector<reco::ItemInfo>& items);
  void TraceManualProbeItems(const std::vector<std::pair<std::string, reco::ItemInfo> >& items);


  void TraceHotRecoItems(const std::vector<reco::ItemInfo>& items);
  void TraceQueryRecoItems(const std::vector<reco::ItemInfo>& items);
  void TraceVedioRecoItems(const std::vector<reco::ItemInfo>& items);
  void TracePersonalRecoItems(const std::vector<reco::ItemInfo>& items);
  void TracePoiRecoItems(const std::vector<reco::ItemInfo>& items);

  void TraceFirstComplexMergeItems(const std::vector<reco::ItemInfo>& items);
  void TraceAdjustByRuleMergeItems(const std::vector<reco::ItemInfo>& items);

  void TracePersonalCategoryItems(
          const std::vector<std::pair<float, reco::Category> >& category_distributes,
          const std::vector<std::pair<float, std::vector<ItemInfo> > >& diversity_item_vec);
  void TraceCategoryIndexItems(const std::vector<reco::ItemInfo>& candidates);
  void TraceCategoryCandidateItems(const std::vector<reco::ItemInfo>& candidates);
  void TraceAfterCategoryRankItems(const std::vector<reco::ItemInfo>& items);
  void TraceAfterCategoryRerankItems(const std::vector<reco::ItemInfo>& items);
  void TraceAfterDiversityFilterItems(const std::vector<reco::ItemInfo>& items);
  void TraceAfterMergeBetweenCategoriesItems(const std::vector<reco::ItemInfo>& personal_items);
  void TraceAflterDoWemediaNumLimitItems(const std::vector<reco::ItemInfo>& personal_items);
  void TraceAflterLimitPersonalItems(const std::vector<reco::ItemInfo>& personal_items);

  // 这个函数是线程安全的
  void AddRankerProcessTag(uint64 item_id, const std::vector<int32>& process_tag);

  // 这个函数是线程安全的
  void SetItemFilterReason(uint64 item_id, reco::filter::FilterReason filter_reason);

  // 在每次请求之后调用 PostAnalysis 来进行一些更详细的分析
  //  1) 如果文章被相似文章过滤掉 (), 分析是被用户看过的哪个文章过滤掉的
  void PostAnalysis(const reco::user::UserInfo& user_info, const std::vector<reco::ItemInfo>& reco_items,
                    const std::vector<reco::ItemInfo>& personal_items);
  // 构造 20 条推荐结果
  void ConstructDebugResponse(const std::vector<reco::ItemInfo>& reco_items,
                              const std::vector<reco::ItemInfo>& personal_items);

  // 对于内部用户，记录推荐过程
  void CommitRecoProcess();

  static void ToProtoFeatureKeyValue(const std::map<std::string, double>& fea_key_value,
                                     google::protobuf::RepeatedPtrField<
                                       RecoDebugInfo::FeatureKeyValue>* info);
  static void ToProtoFeatureKeyValue(const std::unordered_map<std::string, float>& fea_key_value,
                                     google::protobuf::RepeatedPtrField<
                                       RecoDebugInfo::FeatureKeyValue>* info);
  static void ToProtoFeatureKeyValue(const base::dense_hash_map<std::string, float>& fea_key_value,
                                     google::protobuf::RepeatedPtrField<
                                       RecoDebugInfo::FeatureKeyValue>* info);
  static void ToProtoCategoryFeatureKeyValue(const FeaKeyValMap& name_key_value,
                                     google::protobuf::RepeatedPtrField<
                                       RecoDebugInfo::CategoryFeatureKeyValue>* info);

  static void ToProtoUserFeature(const UserFeature& user, RecoDebugInfo::UserFeature* info);
  static void ToProtoItemInfo(const reco::ItemInfo& item, RecoDebugInfo::ItemInfo* info);
  static void ToProtoItemInfoList(const std::vector<ItemInfo>& items,
                google::protobuf::RepeatedPtrField<RecoDebugInfo::ItemInfo>* infos);

  static void SetUpUserInfo(const RecommendRequest& request, reco::user::UserInfo* user_info);

 private:
  void CheckIfItemInIndex(const reco::NewsIndex* news_index, const RecommendRequest& request);

  void ConstructItemResponse(const reco::ItemInfo& item, uint32 rank_pos);

  struct DebugItemContext {
    bool is_manual;
    std::string category;
    int32 category_item_queue_rank_pos;
    reco::filter::FilterReason filter_reason;
    enum ItemQueueStatus {
      kUnknown = 0,
      kNotInQueue = 1,
      kInQueue = 2
    };
    ItemQueueStatus in_index_queue;
    ItemQueueStatus in_candidate_queue;
    ItemQueueStatus in_category_rank_queue;
    ItemQueueStatus in_category_rerank_queue;
    ItemQueueStatus in_category_diversity_queue;
    ItemQueueStatus in_merge_categories_queue;
    ItemQueueStatus in_after_wemedia_queue;
    ItemQueueStatus in_personal_item_queue;
    int32 personal_item_queue_rank_pos;
    DebugItemContext() {
      is_manual = false;
      category = "";
      category_item_queue_rank_pos = -1;
      filter_reason = reco::filter::kNoFiltered;
      in_index_queue = kUnknown;
      in_candidate_queue = kUnknown;
      in_category_rank_queue = kUnknown;
      in_category_rerank_queue = kUnknown;
      in_category_diversity_queue = kUnknown;
      in_merge_categories_queue = kUnknown;
      in_after_wemedia_queue = kUnknown;
      in_personal_item_queue = kUnknown;
      personal_item_queue_rank_pos = 0;
    }
  };

  thread::Mutex mutex_;
  bool inner_user_request_;
  bool enable_debug_;
  bool exclude_shown_filter_;
  std::map<uint64, DebugItemContext> trace_item_ids_set_;
  int32_t debug_level_;
  std::set<std::string> debug_flags_;

  // category click num
  std::map<std::string, int32> category_click_num_;

  std::set<std::string> user_category_set_;
  // item_id, proccess_tag
  std::map<uint64, std::vector<int32> > item_id_process_tag_;

  // debug result
  const reco::NewsIndex* news_index_;
  const RecommendRequest& request_;
  RecommendResponse* response_;

  FRIEND_TEST(RecoDebugger, Constructor);
  FRIEND_TEST(RecoDebugger, TraceManualItemFilterInfo);

  DISALLOW_COPY_AND_ASSIGN(RecoDebugger);
};

}  // namespace leafserver
}  // namespace reco
