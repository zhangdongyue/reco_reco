#pragma once

#include <vector>

#include "reco/bizc/proto/leaf_debug.pb.h"  // ProcessFlag
#include "reco/bizc/reco_index/item_info.h"  // ItemInfo
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"

namespace reco {
namespace leafserver {

class RankerDebugReason {
 public:
  RankerDebugReason(RecoDebugger* debugger, uint64 item_id, double last_score) {
    debugger_ = debugger;
    item_id_ = item_id;
    last_score_ = last_score;
  }

  void AddReasonFlagOnScoreChange(double tuned_score, RecoDebugInfo::ProcessFlag flag) {
    if (debugger_ == NULL || !debugger_->enable_debug())
      return;
    if (std::fabs(last_score_ - tuned_score) > 0.0001f * std::fabs(last_score_)) {
      if (last_score_ < tuned_score)
        process_tags_.push_back(flag);
      else
        process_tags_.push_back(-1 * flag);
    }
    last_score_ = tuned_score;
  }

  void CommitDebugReason() {
    if (debugger_ == NULL || !debugger_->enable_debug())
      return;
    debugger_->AddRankerProcessTag(item_id_, process_tags_);
  }

 private:
  RecoDebugger* debugger_;
  uint64 item_id_;
  double last_score_;
  std::vector<int32> process_tags_;
};

}  // namespace leafserver
}  // namespace reco
