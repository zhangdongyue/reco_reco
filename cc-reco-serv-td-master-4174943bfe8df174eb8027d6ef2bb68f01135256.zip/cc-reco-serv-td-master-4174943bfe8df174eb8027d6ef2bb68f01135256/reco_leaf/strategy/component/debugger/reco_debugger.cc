#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"

#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "base/common/logging.h"
#include "base/container/dense_hash_map.h"  // dense_hash_map
#include "base/thread/sync.h"  // AutoLock
#include "base/time/timestamp.h"  // GetTimestamp

#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "reco/serv/reco_leaf/strategy/reco/manual/manual_reco.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"

namespace reco {
namespace leafserver {
using reco::ItemInfo;
using reco::user::UserInfo;
using reco::user::ViewClickItem;

DEFINE_int32(reco_debug_exploit_threshold, 3, "reco debug exploit threshold");

RecoDebugger::RecoDebugger(const reco::NewsIndex* news_index,
                           const RecommendRequest& request,
                           RecommendResponse* response) : request_(request) {
  news_index_ = news_index;
  bool debug_request = request.has_reco_debug_param()
                       && request.reco_debug_param().has_enable_debug()
                       && request.reco_debug_param().enable_debug();
  bool inner_user_request = false;
  for (int i = 0; i < request.inner_user_flags_size(); ++i) {
    if (request.inner_user_flags(i) == 0) {
      inner_user_request = true;
      break;
    }
  }
  if (LeafDataManager::GetGlobalData()->IsInnerUserId(request.user().user_id())) {
    inner_user_request = true;
  }
  // 来自 Debug 平台的请求
  if (debug_request) {
    inner_user_request_ = false;
    enable_debug_ = true;
    response_ = response;
    for (int i = 0; i < request.reco_debug_param().trace_item_ids().size(); ++i) {
      trace_item_ids_set_[request.reco_debug_param().trace_item_ids(i)] = DebugItemContext();
    }
    // 检查需要 debug 的文章在索引中的状态
    CheckIfItemInIndex(news_index_, request);
    exclude_shown_filter_ = request.reco_debug_param().exclude_shown_filter();
    debug_level_ = request.reco_debug_param().debug_level();
    // init debug_flag_
    for (int i = 0; i < request.reco_debug_param().debug_flag().size(); ++i) {
      debug_flags_.insert(request.reco_debug_param().debug_flag(i));
    }
  } else if (inner_user_request) {
    // 来自内部用户的真实请求
    inner_user_request_ = true;
    enable_debug_ = true;
    exclude_shown_filter_ = false;
    debug_level_ = 0;
    response_ = response;
  } else {
    inner_user_request_ = false;
    enable_debug_ = false;
    exclude_shown_filter_ = false;
    debug_level_ = 0;
    response_ = NULL;
  }
}

RecoDebugger::~RecoDebugger() {
}

bool RecoDebugger::enable_debug() const {
  return enable_debug_;
}

void RecoDebugger::CheckIfItemInIndex(const reco::NewsIndex* news_index, const RecommendRequest& request) {
  base::Time curr_time = base::Time::Now();
  std::string str_curr_time;
  curr_time.ToStringInSeconds(&str_curr_time);
  for (int i = 0; i < request.reco_debug_param().trace_item_ids().size(); ++i) {
    const uint64 item_id = request.reco_debug_param().trace_item_ids(i);
    // 检查是否是有效文章
    if (!news_index->IsValidByItemId(item_id)) {
      trace_item_ids_set_[item_id].filter_reason = reco::filter::kFilterByNotValid;
      continue;
    }
    // 检查文章是否过期
    if (news_index->IsExpiredByItemId(item_id, base::GetTimestamp())) {
      trace_item_ids_set_[item_id].filter_reason = reco::filter::kFilterByExpired;
      continue;
    }
    // 只对运营文章检查发布状态和生效时间
    int32 doc_id;
    if (news_index->GetDocIdByItemId(item_id, &doc_id)) {
      UcBrowserDeliverSetting ucb_setting_proto;
      if (news_index->IsManualByDocId(doc_id)
          && news_index->GetUCBSettingByItemId(item_id, &ucb_setting_proto)) {
        // 未发布过滤
        if (ucb_setting_proto.has_is_published() && !ucb_setting_proto.is_published()) {
          trace_item_ids_set_[item_id].filter_reason = reco::filter::kNotPulishFiltered;
          continue;
        }
        // 不在生效时间内过滤
        if ((ucb_setting_proto.has_start_time() && ucb_setting_proto.start_time() > str_curr_time)
            || (ucb_setting_proto.has_end_time() && ucb_setting_proto.end_time() < str_curr_time)) {
          trace_item_ids_set_[item_id].filter_reason = reco::filter::kNotInDeliveryTimeFiltered;
          continue;
        }
      }
      // 运营文章
      if (news_index->IsManualByDocId(doc_id))
        trace_item_ids_set_[item_id].is_manual = true;
    }
    // 检查文章所在类目索引中的排名
    std::vector<reco::Category> categories;
    if (!news_index->GetCategoriesByItemId(item_id, &categories)
        || categories.size() <= 0) {
      trace_item_ids_set_[item_id].filter_reason = reco::filter::kNotHasCategoryFiltered;
      continue;
    }
    for (auto i = categories.begin(); i != categories.end(); ++i) {
      LOG(INFO) << item_id << ", level=" << i->level() << ", category=" << i->category();
    }
    trace_item_ids_set_[item_id].category = categories[0].category();
    const std::vector<ItemInfo>* index_list = news_index->GetDefaultReco(categories[0]);
    if (index_list == NULL) {
      continue;
    }
    int rank_pos = 0;
    for (auto i = index_list->begin(); i != index_list->end(); ++i) {
      if (item_id == i->item_id) {
        trace_item_ids_set_[item_id].category_item_queue_rank_pos = rank_pos;
        LOG(INFO) << "item_id=" << item_id << " in category=" << categories[0].category()
                  << " rank pos=" << rank_pos;
      }
      rank_pos++;
    }
  }
}

bool RecoDebugger::NotHasDebugFlag(const std::string& flag) {
  return debug_flags_.find(flag) == debug_flags_.end();
}

void RecoDebugger::TraceManualItemFilterInfo(const std::vector<ItemInfo>& items,
                                             const std::vector<ManualItemExtInfo>& ext_infos) {
  if (!enable_debug_ || !response_) return;
  CHECK_EQ(items.size(), ext_infos.size());
  for (size_t i = 0; i < items.size(); ++i) {
    const ItemInfo& item = items[i];
    const ManualItemExtInfo& ext_info = ext_infos[i];
    if (trace_item_ids_set_.find(item.item_id) == trace_item_ids_set_.end())
      continue;
    trace_item_ids_set_[item.item_id].filter_reason = ext_info.get_filter_reason();
  }
  if (debug_level_ < 3 && NotHasDebugFlag("manual_item_candidate")) return;
  RecoDebugInfo* debug_info = response_->mutable_reco_debug_info();
  for (size_t i = 0; i < items.size(); ++i) {
    const ItemInfo& item = items[i];
    const ManualItemExtInfo& ext_info = ext_infos[i];
    RecoDebugInfo::ManualItemExtInfo* debug_item_info = debug_info->add_manual_item_candidate();
    debug_item_info->mutable_item_info()->set_item_id(item.item_id);
    debug_item_info->mutable_item_info()->set_item_type(item.item_type);
    debug_item_info->set_filter_reason(ext_info.get_filter_reason());
    debug_item_info->set_sort_score(ext_info.sort_score);
  }
}

void RecoDebugger::TraceManulItemDictAndLevelScore(const reco::ItemInfo& item,
                                                   const ManualItemExtInfo& ext_info,
                                                   unsigned level_score) {
  if (!enable_debug_ || !response_) return;
  // search manual_score and sort_score
  RecoDebugInfo::ManualItemInfo* info = response_->mutable_reco_debug_info()->add_manual_item_info();
  info->set_item_id(item.item_id);
  info->set_sort_score(level_score);
  info->set_manual_score(0);

  auto iflow_item_sort_map = DM_GET_DICT(reco::dm::IflowItemSortDict,
                                         DynamicDictContainer::kIflowItemSortFile_);
  auto iter = iflow_item_sort_map->find(item.item_id);
  if (iter != iflow_item_sort_map->end()) {
    info->set_manual_score(iter->second);
  }
}

void RecoDebugger::TraceUserShownDict(base::dense_hash_set<uint64>* shown_dict) {
  if (!enable_debug_ || !response_) return;
  if (exclude_shown_filter_) {
    for (auto i = trace_item_ids_set_.begin(); i != trace_item_ids_set_.end(); ++i) {
      auto p = shown_dict->find(i->first);
      if (p != shown_dict->end()) {
        shown_dict->erase(p);
        LOG(INFO) << "exclude_shown_filter, item_id=" << i->first;
      }
    }
  }

  if (debug_level_ < 3 && NotHasDebugFlag("user_shown_dict")) return;
  for (auto i = shown_dict->begin(); i != shown_dict->end(); ++i) {
    response_->mutable_reco_debug_info()->add_shown_item_id(*i);
  }
}

void RecoDebugger::TraceUserFeature(const UserFeature& user_feature) {
  if (!enable_debug_ || !response_) return;
  RecoDebugInfo::UserFeature* info = response_->mutable_reco_debug_info()->mutable_user_feature();
  info->set_lt_influence(user_feature.merged_info.lt_influence);
  info->set_st_influence(user_feature.merged_info.st_influence);
  info->set_dmp_influence(user_feature.merged_info.dmp_influence);
  info->set_ali_influence(user_feature.merged_info.ali_influence);

  if (debug_level_ < 1 && NotHasDebugFlag("user_feature")) return;
  ToProtoUserFeature(user_feature, info);
}

void RecoDebugger::TraceCategoryDistributes(const std::vector<std::pair<float, reco::Category> >&
                                            category_distributes) {
  if (!enable_debug_ || !response_) return;
  for (auto i = category_distributes.begin(); i != category_distributes.end(); ++i) {
    RecoDebugInfo::FeatureKeyValue* fkv = response_->mutable_reco_debug_info()
                                                   ->add_category_distributes();
    fkv->set_key(i->second.category());
    fkv->set_value(i->first);
    user_category_set_.insert(i->second.category());
  }
}
void RecoDebugger::TraceVerticalChannelCatetory(const std::unordered_set<std::string>& category_set) {
  if (!enable_debug_ || !response_) return;
  for (auto i = category_set.begin(); i != category_set.end(); ++i) {
    response_->mutable_reco_debug_info()->add_vertical_channel_category(*i);
  }
}

void RecoDebugger::TraceRsbReturnNum(const std::unordered_map<int, int>& rsb_return_num_map) {
  if (!enable_debug_ || !response_) return;
  for (auto i = rsb_return_num_map.begin(); i != rsb_return_num_map.end(); ++i) {
    RecoDebugInfo::RsbNumber* rsb_num = response_->mutable_reco_debug_info()->add_rsb_number();
    rsb_num->set_reco_strategy_branch(i->first);
    rsb_num->set_return_number(i->second);
  }
}

void RecoDebugger::TraceManualTopImportanceItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  // trace top_importance_items
  if (debug_level_ < 2 && NotHasDebugFlag("top_importance_items")) return;
  ToProtoItemInfoList(items, response_->mutable_reco_debug_info()->mutable_manual_whole_items());
}

void RecoDebugger::TraceManualSndImportanceItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  // trace snd_importance_items
  if (debug_level_ < 2 && NotHasDebugFlag("snd_importance_items")) return;
  ToProtoItemInfoList(items, response_->mutable_reco_debug_info()->mutable_manual_whole_items());
}

void RecoDebugger::TraceManualCategoryWholeItems(const std::unordered_map<std::string,
                                                 std::vector<ItemInfo> >& category_items) {
  if (!enable_debug_ || !response_) return;
  if (debug_level_ < 2 && NotHasDebugFlag("manual_category_whole_items")) return;
  RecoDebugInfo* debug_info = response_->mutable_reco_debug_info();
  for (auto i = category_items.begin(); i != category_items.end(); ++i) {
    RecoDebugInfo::CategoryItemInfo* info = debug_info->add_manual_category_items();
    info->set_name(i->first);
    ToProtoItemInfoList(i->second, info->mutable_items());
  }
}

void RecoDebugger::TraceManualPersonalItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  if (debug_level_ < 2 && NotHasDebugFlag("manual_personal_items")) return;
  ToProtoItemInfoList(items, response_->mutable_reco_debug_info()->mutable_manual_personal_items());
}

void RecoDebugger::TraceManualProbeItems(const std::vector<std::pair<std::string, reco::ItemInfo> >& items) {
  if (!enable_debug_ || !response_) return;
  if (debug_level_ < 2 && NotHasDebugFlag("manual_probe_items")) return;
  RecoDebugInfo* debug_info = response_->mutable_reco_debug_info();
  for (auto i = items.begin(); i != items.end(); ++i) {
    RecoDebugInfo::ProbeItemInfo* info = debug_info->add_manual_probe_items();
    info->set_name(i->first);
    std::vector<ItemInfo> probe_items;
    probe_items.push_back(i->second);
    ToProtoItemInfoList(probe_items, info->mutable_items());
  }
}

void RecoDebugger::TraceHotRecoItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  if (debug_level_ < 2 && NotHasDebugFlag("hot_items")) return;
  ToProtoItemInfoList(items, response_->mutable_reco_debug_info()->mutable_hot_items());
}
void RecoDebugger::TraceQueryRecoItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  if (debug_level_ < 2 && NotHasDebugFlag("hot_items")) return;
  ToProtoItemInfoList(items, response_->mutable_reco_debug_info()->mutable_query_items());
}
void RecoDebugger::TraceVedioRecoItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  if (debug_level_ < 2 && NotHasDebugFlag("vedio_items")) return;
  ToProtoItemInfoList(items, response_->mutable_reco_debug_info()->mutable_vedio_items());
}
void RecoDebugger::TracePersonalRecoItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  if (debug_level_ < 2 && NotHasDebugFlag("personal_items")) return;
  ToProtoItemInfoList(items, response_->mutable_reco_debug_info()->mutable_personal_items());
}
void RecoDebugger::TracePoiRecoItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  if (debug_level_ < 2 && NotHasDebugFlag("poi_items")) return;
  ToProtoItemInfoList(items, response_->mutable_reco_debug_info()->mutable_poi_items());
}

void RecoDebugger::TraceFirstComplexMergeItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  if (debug_level_ < 3 && NotHasDebugFlag("first_complex_merge_items")) return;
  ToProtoItemInfoList(items, response_->mutable_reco_debug_info()
                        ->mutable_first_complex_merge_items());
}
void RecoDebugger::TraceAdjustByRuleMergeItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  if (debug_level_ < 3 && NotHasDebugFlag("adjust_by_rule_merge_items")) return;
  ToProtoItemInfoList(items, response_->mutable_reco_debug_info()
                        ->mutable_adjust_by_rule_merge_items());
}

void RecoDebugger::TracePersonalCategoryItems(
        const std::vector<std::pair<float, reco::Category> >& category_distributes,
        const std::vector<std::pair<float, std::vector<ItemInfo> > >& diversity_item_vec) {
  if (!enable_debug_ || !response_) return;
  if (debug_level_ < 3 && NotHasDebugFlag("personal_category_items")) return;
  RecoDebugInfo* debug_info = response_->mutable_reco_debug_info();
  for (size_t i = 0; i < category_distributes.size() && i < diversity_item_vec.size(); ++i) {
    RecoDebugInfo::CategoryItemInfo* info = debug_info->add_personal_category_items();
    info->set_name(category_distributes[i].second.category());
    ToProtoItemInfoList(diversity_item_vec[i].second, info->mutable_items());
  }
}

void RecoDebugger::TraceCategoryIndexItems(const std::vector<reco::ItemInfo>& candidates) {
  if (!enable_debug_ || !response_) return;
  for (auto i = candidates.begin(); i != candidates.end(); ++i) {
    if (trace_item_ids_set_.find(i->item_id) == trace_item_ids_set_.end())
      continue;
    thread::AutoLock lock(&mutex_);
    trace_item_ids_set_.find(i->item_id)->second.in_index_queue = DebugItemContext::kInQueue;
  }
}

void RecoDebugger::TraceCategoryCandidateItems(const std::vector<reco::ItemInfo>& candidates) {
  if (!enable_debug_ || !response_) return;
  for (auto i = candidates.begin(); i != candidates.end(); ++i) {
    if (trace_item_ids_set_.find(i->item_id) == trace_item_ids_set_.end())
      continue;
    thread::AutoLock lock(&mutex_);
    trace_item_ids_set_.find(i->item_id)->second.in_candidate_queue = DebugItemContext::kInQueue;
  }
}

void RecoDebugger::TraceAfterCategoryRankItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  for (auto i = items.begin(); i != items.end(); ++i) {
    if (trace_item_ids_set_.find(i->item_id) == trace_item_ids_set_.end())
      continue;
    thread::AutoLock lock(&mutex_);
    trace_item_ids_set_.find(i->item_id)->second.in_category_rank_queue = DebugItemContext::kInQueue;
  }
}

void RecoDebugger::TraceAfterCategoryRerankItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  for (auto i = items.begin(); i != items.end(); ++i) {
    if (trace_item_ids_set_.find(i->item_id) == trace_item_ids_set_.end())
      continue;
    thread::AutoLock lock(&mutex_);
    trace_item_ids_set_.find(i->item_id)->second.in_category_rerank_queue = DebugItemContext::kInQueue;
  }
}

void RecoDebugger::TraceAfterDiversityFilterItems(const std::vector<reco::ItemInfo>& items) {
  if (!enable_debug_ || !response_) return;
  for (auto i = items.begin(); i != items.end(); ++i) {
    if (trace_item_ids_set_.find(i->item_id) == trace_item_ids_set_.end())
      continue;
    thread::AutoLock lock(&mutex_);
    trace_item_ids_set_.find(i->item_id)->second.in_category_diversity_queue = DebugItemContext::kInQueue;
  }
}


void RecoDebugger::TraceAfterMergeBetweenCategoriesItems(const std::vector<reco::ItemInfo>& personal_items) {
  if (!enable_debug_ || !response_) return;
  for (auto i = personal_items.begin(); i != personal_items.end(); ++i) {
    if (trace_item_ids_set_.find(i->item_id) == trace_item_ids_set_.end())
      continue;
    thread::AutoLock lock(&mutex_);
    trace_item_ids_set_.find(i->item_id)->second.in_merge_categories_queue = DebugItemContext::kInQueue;
  }
}

void RecoDebugger::TraceAflterDoWemediaNumLimitItems(const std::vector<reco::ItemInfo>& personal_items) {
  if (!enable_debug_ || !response_) return;
  for (auto i = personal_items.begin(); i != personal_items.end(); ++i) {
    if (trace_item_ids_set_.find(i->item_id) == trace_item_ids_set_.end())
      continue;
    thread::AutoLock lock(&mutex_);
    trace_item_ids_set_.find(i->item_id)->second.in_after_wemedia_queue = DebugItemContext::kInQueue;
  }
}

void RecoDebugger::TraceAflterLimitPersonalItems(const std::vector<reco::ItemInfo>& personal_items) {
  if (!enable_debug_ || !response_) return;
  int32 pos = 1;
  for (auto i = personal_items.begin(); i != personal_items.end(); ++pos, ++i) {
    if (trace_item_ids_set_.find(i->item_id) == trace_item_ids_set_.end())
      continue;
    thread::AutoLock lock(&mutex_);
    trace_item_ids_set_.find(i->item_id)->second.in_personal_item_queue = DebugItemContext::kInQueue;
    trace_item_ids_set_.find(i->item_id)->second.personal_item_queue_rank_pos = pos;
  }
}

void RecoDebugger::AddRankerProcessTag(uint64 item_id, const std::vector<int32>& process_tag) {
  if (!enable_debug_ || !response_) return;
  thread::AutoLock lock(&mutex_);
  item_id_process_tag_[item_id] = process_tag;
}

void RecoDebugger::SetItemFilterReason(uint64 item_id, reco::filter::FilterReason filter_reason) {
  if (!enable_debug_ || !response_) return;
  auto it = trace_item_ids_set_.find(item_id);
  if (it == trace_item_ids_set_.end()) return;
  thread::AutoLock lock(&mutex_);
  if (it->second.filter_reason == reco::filter::kNoFiltered) {
    it->second.filter_reason = filter_reason;
  }
}

void RecoDebugger::PostAnalysis(const UserInfo& user_info,
                                const std::vector<reco::ItemInfo>& reco_items,
                                const std::vector<reco::ItemInfo>& personal_items) {
  if (!enable_debug_ || !response_) return;
  // 1) 扫描 DebugItemContext 检查文章在哪里过滤掉了
  std::set<uint64> reco_item_ids;
  for (auto it = reco_items.begin(); it != reco_items.end(); ++it)
    reco_item_ids.insert(it->item_id);
  for (auto it = personal_items.begin(); it != personal_items.end(); ++it)
    reco_item_ids.insert(it->item_id);

  for (auto it = trace_item_ids_set_.begin(); it != trace_item_ids_set_.end(); ++it) {
    if (reco_item_ids.find(it->first) != reco_item_ids.end()) {  // 在推荐结果中
      it->second.filter_reason = reco::filter::kNoFiltered;
      continue;
    }
    if (it->second.filter_reason != reco::filter::kNoFiltered)  // 已经确定了过滤原因
      continue;
    if (it->second.is_manual)  // 运营文章不进行下面的推理
      continue;
    if (it->second.in_index_queue != DebugItemContext::kInQueue
        && it->second.in_candidate_queue != DebugItemContext::kInQueue)
      it->second.filter_reason = reco::filter::kNotInIndex;
    else if (it->second.in_candidate_queue == DebugItemContext::kNotInQueue)
      it->second.filter_reason = reco::filter::kLowRankInIndexFiltered;
    else if (!it->second.in_category_rank_queue == DebugItemContext::kNotInQueue)
      it->second.filter_reason = reco::filter::kLowRankInIndexFiltered;
    else if (!it->second.in_category_rerank_queue == DebugItemContext::kNotInQueue)
      it->second.filter_reason = reco::filter::kLowRankInCategoryRerankFiltered;
    else if (!it->second.in_category_diversity_queue == DebugItemContext::kNotInQueue)
      it->second.filter_reason = reco::filter::kCategoryDiversityFiltered;
    else if (!it->second.in_merge_categories_queue == DebugItemContext::kNotInQueue)
      it->second.filter_reason = reco::filter::kLowRankMergeBetweenCategoriesFiltered;
    else if (!it->second.in_after_wemedia_queue == DebugItemContext::kNotInQueue)
      it->second.filter_reason = reco::filter::kWemediaNumLimitFiltered;
    else if (!it->second.in_personal_item_queue == DebugItemContext::kNotInQueue)
      it->second.filter_reason = reco::filter::kLowRankInPersonalFiltered;
    else
      it->second.filter_reason = reco::filter::kUnknownFiltered;
  }

  // 2) 统计用户类目点击的频次，用于给用户的兴趣推荐建立可能的推荐理由
  std::vector<reco::Category> category_list;
  for (int i = 0; i < user_info.recent_click_size(); ++i) {
    const ViewClickItem& item = user_info.recent_click(i);
    category_list.clear();
    if (!news_index_->GetCategoriesByItemId(item.item_id(), &category_list))
      continue;
    for (auto it = category_list.begin(); it != category_list.end(); it ++) {
      if (category_click_num_.find(it->category()) == category_click_num_.end())
        category_click_num_[it->category()] = 1;
      else
        category_click_num_[it->category()]++;
    }
  }

  // 3) 构造返回结果
  ConstructDebugResponse(reco_items, personal_items);

  // 4) 分析展现去重具体的原因
  RecoDebugInfo* debug_info = response_->mutable_reco_debug_info();
  for (int i = 0; i < debug_info->not_reco_reason_size(); ++i) {
    RecoDebugInfo::NotRecoReason* reason = debug_info->mutable_not_reco_reason(i);
    if (reason->has_filter_reason() &&
        (reason->filter_reason() != reco::filter::kFilterByShownHistory &&
         reason->filter_reason() != reco::filter::kFilterByShownSpecial))
      continue;
    const uint64 debug_item_id = reason->item_id();
    base::dense_hash_set<uint64> shown_dict;
    shown_dict.set_empty_key(NULL);
    for (int i = 0; i < user_info.shown_history_size(); ++i) {
      const ViewClickItem& item = user_info.shown_history(i);
      const uint64 item_id = item.item_id();
      // 命中展现过的文章
      if (item_id == debug_item_id) {
        reason->set_shown_item_id(item_id);
        reason->set_shown_filtered_type(RecoDebugInfo::NotRecoReason::kShown);
        break;
      }
      // 看过的专题，同时将专题的 preview 写入去重队列
      ItemType item_type;
      if (!news_index_->GetItemTypeByItemId(item_id, &item_type))
        item_type = reco::kNews;
      if (item_type == reco::kSpecial || item_type == reco::kWeMediaCard) {
        std::unordered_set<uint64> preview_ids;
        if (news_index_->GetPreviewIdsByItemId(item_id, &preview_ids)) {
          if (preview_ids.find(debug_item_id) != preview_ids.end()) {
            reason->set_shown_item_id(item_id);
            reason->set_shown_filtered_type(RecoDebugInfo::NotRecoReason::kSpecialPreviewShown);
            break;
          }
          for (auto iter = preview_ids.begin(); iter != preview_ids.end(); ++iter) {
            RecoUtils::AddSimItemToShownDict(news_index_, *iter, &shown_dict);
            if (shown_dict.find(debug_item_id) != shown_dict.end()) {
              reason->set_shown_item_id(item_id);
              reason->set_shown_filtered_type(RecoDebugInfo::NotRecoReason::kSpecialPreviewSimilarShown);
              break;
            }
          }
        }
      }
      // 命中展现过文章的相似文章
      RecoUtils::AddSimItemToShownDict(news_index_, item_id, &shown_dict);
      if (shown_dict.find(debug_item_id) != shown_dict.end()) {
        reason->set_shown_item_id(item_id);
        reason->set_shown_filtered_type(RecoDebugInfo::NotRecoReason::kSimilarToShown);
        break;
      }
    }
    if (reason->has_shown_item_id() && reason->has_shown_filtered_type()) continue;

    for (int i = 0; i < user_info.recent_click_size(); ++i) {
      const ViewClickItem& item = user_info.recent_click(i);
      const uint64 item_id = item.item_id();
      // 命中点击过的文章
      if (item_id == reason->item_id()) {
        reason->set_shown_item_id(item_id);
        reason->set_shown_filtered_type(RecoDebugInfo::NotRecoReason::kClick);
        break;
      }
      // 命中点击过文章的相似文章
      RecoUtils::AddSimItemToShownDict(news_index_, item_id, &shown_dict);
      if (shown_dict.find(debug_item_id) != shown_dict.end()) {
        reason->set_shown_item_id(item_id);
        reason->set_shown_filtered_type(RecoDebugInfo::NotRecoReason::kSimilarToClick);
        break;
      }
    }
  }
}

void RecoDebugger::ConstructDebugResponse(const std::vector<reco::ItemInfo>& reco_items,
                                          const std::vector<reco::ItemInfo>& personal_items) {
  if (!enable_debug_ || !response_) return;
  std::set<uint64> item_ids;
  // 推荐结果
  for (auto i = reco_items.begin(); i != reco_items.end(); ++i) {
    if (item_ids.find(i->item_id) != item_ids.end())
      continue;
    item_ids.insert(i->item_id);
    ConstructItemResponse(*i, item_ids.size());
  }
  // 结果不够 20 条，补充个性化文章
  auto i = personal_items.begin();
  for (; i != personal_items.end(); ++i) {
    if (item_ids.size() >= 20)
      break;
    if (item_ids.find(i->item_id) != item_ids.end())
      continue;
    item_ids.insert(i->item_id);
    ConstructItemResponse(*i, item_ids.size());
  }
  // 需要 debug 的文章在个性化队列中的位置
  uint32 rank_pos = item_ids.size() + 1;
  for (; i != personal_items.end(); ++i) {
    if (trace_item_ids_set_.find(i->item_id) != trace_item_ids_set_.end()
        && item_ids.find(i->item_id) == item_ids.end()) {
      item_ids.insert(i->item_id);
      ConstructItemResponse(*i, rank_pos);
      trace_item_ids_set_[i->item_id].filter_reason = reco::filter::kNoFiltered;
    }
    ++rank_pos;
  }
  // 构造 NotRecoReason
  RecoDebugInfo* debug_info = response_->mutable_reco_debug_info();
  for (auto it = trace_item_ids_set_.begin(); it != trace_item_ids_set_.end(); it ++) {
    // 用户兴趣与文章不匹配
    if (it->second.filter_reason == reco::filter::kNotInIndex
        && !it->second.category.empty()
        && user_category_set_.find(it->second.category) == user_category_set_.end())
      it->second.filter_reason = reco::filter::kUserCategoryNotMatchFiltered;
    if (it->second.filter_reason == reco::filter::kNoFiltered)
      continue;
    RecoDebugInfo::NotRecoReason* reason = debug_info->add_not_reco_reason();
    reason->set_item_id(it->first);
    reason->set_filter_reason(it->second.filter_reason);
    reason->set_category_queue_rank_pos(it->second.category_item_queue_rank_pos);
  }
}

void RecoDebugger::ConstructItemResponse(const reco::ItemInfo& item, uint32 rank_pos) {
  if (!enable_debug_ || !response_) return;
  RecoDebugInfo::RecoResultReason* reason = response_->mutable_reco_debug_info()
                                                     ->add_reco_result_reason();
  reason->set_rank_pos(rank_pos);
  RecoDebugInfo::ItemInfo* info = reason->mutable_item_info();
  ToProtoItemInfo(item, info);
  bool cf_match = false;
  auto i = item_id_process_tag_.find(item.item_id);
  if (i != item_id_process_tag_.end()) {
    for (auto j = i->second.begin(); j != i->second.end(); ++j) {
      info->add_process_flag(*j);
      if (RecoDebugInfo::kCollaboritiveFilterTuneFlag == *j
          || RecoDebugInfo::kCollaboritiveFilterTuneFlag == (*j) * -1)
        cf_match = true;
    }
  }
  // 重新定义 kExploit / kExplore 的含义
  if (item.strategy_type == reco::kExploit || item.strategy_type == reco::kExplore) {
    if (cf_match) {
      reason->set_strategy_type(reco::kExploit);
      reason->set_detail("命中协同过滤策略");
      return;
    }
    // kExploit: 命中用户兴趣
    if ((category_click_num_.find(item.sub_category) != category_click_num_.end()
          && category_click_num_[item.sub_category] > FLAGS_reco_debug_exploit_threshold)
        || (category_click_num_.find(item.category) != category_click_num_.end()
          && category_click_num_[item.category] > FLAGS_reco_debug_exploit_threshold)) {
      reason->set_strategy_type(reco::kExploit);
      reason->set_detail("命中用户兴趣");
      return;
    }
    // kExplore: 兴趣探索
    reason->set_strategy_type(reco::kExplore);
  } else {
    reason->set_strategy_type(item.strategy_type);
  }
}

void RecoDebugger::CommitRecoProcess() {
  if (!enable_debug_ || !inner_user_request_)
    return;
  if (LeafDataManager::GetGlobalData()->user_trace_producer == NULL)
    return;
  serving_base::Timer timer;
  timer.Start();
  TraceDebugInfo trace_debug_info;
  trace_debug_info.mutable_recommend_request()->CopyFrom(request_);
  response_->mutable_reco_debug_info()->Swap(trace_debug_info.mutable_reco_debug_info());
  trace_debug_info.mutable_recommend_response()->CopyFrom(*response_);
  trace_debug_info.set_timestamp(base::GetTimestamp());
  std::string message;
  trace_debug_info.SerializeToString(&message);
  bool r = LeafDataManager::GetGlobalData()->user_trace_producer
             ->Produce(message, base::Uint64ToString(request_.user().user_id()));
  LOG(INFO) << "user trace message size: " << message.size()
            << " , time consume: " << timer.Stop()
            << " , produce result: " << r;
}

void RecoDebugger::ToProtoFeatureKeyValue(const std::map<std::string, double>& fea_key_value,
                                          google::protobuf::RepeatedPtrField<
                                            RecoDebugInfo::FeatureKeyValue>* info) {
  for (auto i = fea_key_value.begin(); i != fea_key_value.end(); ++i) {
    RecoDebugInfo::FeatureKeyValue* fkv = info->Add();
    fkv->set_key(i->first);
    fkv->set_value(i->second);
  }
}

void RecoDebugger::ToProtoFeatureKeyValue(const std::unordered_map<std::string, float>& fea_key_value,
                                          google::protobuf::RepeatedPtrField<
                                            RecoDebugInfo::FeatureKeyValue>* info) {
  for (auto i = fea_key_value.begin(); i != fea_key_value.end(); ++i) {
    RecoDebugInfo::FeatureKeyValue* fkv = info->Add();
    fkv->set_key(i->first);
    fkv->set_value(i->second);
  }
}

void RecoDebugger::ToProtoFeatureKeyValue(const base::dense_hash_map<std::string, float>& fea_key_value,
                                          google::protobuf::RepeatedPtrField<
                                            RecoDebugInfo::FeatureKeyValue>* info) {
  for (auto i = fea_key_value.begin(); i != fea_key_value.end(); ++i) {
    RecoDebugInfo::FeatureKeyValue* fkv = info->Add();
    fkv->set_key(i->first);
    fkv->set_value(i->second);
  }
}

void RecoDebugger::ToProtoCategoryFeatureKeyValue(const FeaKeyValMap& name_key_value,
                                                  google::protobuf::RepeatedPtrField<
                                                    RecoDebugInfo::CategoryFeatureKeyValue>* info) {
  for (auto i = name_key_value.begin(); i != name_key_value.end(); ++i) {
    RecoDebugInfo::CategoryFeatureKeyValue* cfkv = info->Add();
    cfkv->set_name(i->first);
    ToProtoFeatureKeyValue(i->second, cfkv->mutable_feature());
  }
}

void RecoDebugger::ToProtoUserFeature(const UserFeature& user,
                                      RecoDebugInfo::UserFeature* info) {
  // info->set_debug_user(user.is_debug_user);
  info->set_debug_user(false);
  auto const& merged_fea = user.merged_fea;
  ToProtoFeatureKeyValue(merged_fea.l1_cates, info->mutable_l1_cates());
  ToProtoCategoryFeatureKeyValue(merged_fea.l2_cates, info->mutable_l2_cates());
  ToProtoCategoryFeatureKeyValue(merged_fea.cate_keywords, info->mutable_cate_keywords());
  ToProtoCategoryFeatureKeyValue(merged_fea.cate_tags, info->mutable_cate_keywords());
  ToProtoFeatureKeyValue(merged_fea.topics, info->mutable_topics());
  ToProtoFeatureKeyValue(merged_fea.raw_l1_cates, info->mutable_raw_l1_cates());
  for (auto it = user.behavior_fea.dislike_items.begin(); it != user.behavior_fea.dislike_items.end(); ++it) {
    info->add_dislike_item_ids(it->item_id);
  }
  ToProtoFeatureKeyValue(user.behavior_fea.dislike_tags, info->mutable_dislike_tags());
  ToProtoFeatureKeyValue(user.behavior_fea.dislike_sources, info->mutable_dislike_sources());
  ToProtoFeatureKeyValue(user.behavior_fea.dislike_cates, info->mutable_dislike_categories());
  ToProtoFeatureKeyValue(user.behavior_fea.subscript_words, info->mutable_subscript_words());
  ToProtoFeatureKeyValue(user.behavior_fea.subscript_sources, info->mutable_subscript_wemedias());
  info->set_lt_click_num(user.lt_fea.click_num);
  info->set_st_click_num(user.lt_fea.click_num);
  info->set_total_click_num(user.merged_info.total_click_num);
  info->set_video_click_ratio(user.merged_info.video_click_ratio);
  info->set_session_video_show_num(user.st_fea.session_video_show_num);
  info->set_session_video_click_num(user.st_fea.session_video_click_num);
  info->set_session_video_click_ratio(user.st_fea.session_video_click_ratio);
  info->set_total_video_click_num(user.merged_info.total_video_click_num);
  info->set_dirty_level(user.attr.dirty_level);
  info->set_prov_id(user.attr.prov_id);
  info->set_city_id(user.attr.city_id);
  for (auto i = user.attr.user_area_ids.begin(); i != user.attr.user_area_ids.end(); ++i) {
    info->add_user_area_ids(*i);
  }
  for (auto i = user.attr.user_district_ids.begin(); i != user.attr.user_district_ids.end(); ++i) {
    info->add_user_district_ids(*i);
  }
  for (auto it = user.merged_fea.confidence_l1_cates.begin();
       it != user.merged_fea.confidence_l1_cates.end(); ++it) {
    info->add_confidence_l1_cates(*it);
  }
  info->set_lt_influence(user.merged_info.lt_influence);
  info->set_st_influence(user.merged_info.st_influence);
  info->set_dmp_influence(user.merged_info.dmp_influence);
  info->set_ali_influence(user.merged_info.ali_influence);
}

void RecoDebugger::ToProtoItemInfo(const reco::ItemInfo& item, RecoDebugInfo::ItemInfo* info) {
  info->set_item_id(item.item_id);
  info->set_item_type(item.item_type);
  info->set_doc_id(item.doc_id);
  info->set_site_level(item.site_level);
  info->set_time_level(item.time_level);
  info->set_hot_level(item.hot_level);
  info->set_media_level(item.media_level);
  if (reco::leafserver::SensitivityLevel_IsValid(item.sensitive_type)) {
    info->set_sensitive_level((reco::leafserver::SensitivityLevel)(item.sensitive_type));
  }
  info->set_reco_score(item.reco_score);
  info->set_create_timestamp(item.create_timestamp);
  info->set_category(item.category);
  info->set_sub_category(item.sub_category);
  info->set_item_quality(item.itemq);
  info->set_spider_score(item.spider_score);
  info->set_lr_score(item.lr_score);
  info->set_fm_score(item.fm_score);
  info->set_ctr(item.ctr);
  info->set_shown_num(item.show_num);
  info->set_click_num(item.click_num);
  info->set_strategy_type(item.strategy_type);
  info->set_fac_machine_score(item.fac_machine_score);
  // info->set_orig_category(item.orig_category);
}

void RecoDebugger::ToProtoItemInfoList(const std::vector<ItemInfo>& items,
                       google::protobuf::RepeatedPtrField<RecoDebugInfo::ItemInfo>* infos) {
  for (size_t i = 0; i < items.size(); ++i) {
    ToProtoItemInfo(items[i], infos->Add());
  }
}

void RecoDebugger::SetUpUserInfo(const RecommendRequest& request, UserInfo* user_info) {
  // 对 Debug 请求，从展现和点击历史中去除需要跟踪的文章
  if (request.has_reco_debug_param() && !request.reco_debug_param().exclude_shown_filter()) {
    // 构建 debug_item_id 集合
    std::set<uint64> debug_item_ids;
    for (auto i = request.reco_debug_param().trace_item_ids().begin();
         i != request.reco_debug_param().trace_item_ids().end(); ++i)
      debug_item_ids.insert(*i);

    // 去掉已经展现过的 debug_item_id
    google::protobuf::RepeatedPtrField<ViewClickItem> new_shown_list;
    for (auto i = user_info->shown_history().begin(); i != user_info->shown_history().end(); ++i) {
      if (debug_item_ids.find(i->item_id()) != debug_item_ids.end()) {
        LOG(INFO) << "erase shown item_id: " << i->item_id();
        continue;
      }
      new_shown_list.Add()->CopyFrom(*i);
    }
    if (new_shown_list.size() != user_info->shown_history().size())
      user_info->mutable_shown_history()->Swap(&new_shown_list);

    // 去掉已经点击过的 debug_item_id
    google::protobuf::RepeatedPtrField<ViewClickItem> new_click_list;
    for (auto i = user_info->recent_click().begin(); i != user_info->recent_click().end(); ++i) {
      if (debug_item_ids.find(i->item_id()) != debug_item_ids.end()) {
        LOG(INFO) << "erase clicked item_id: " << i->item_id();
        continue;
      }
      new_click_list.Add()->CopyFrom(*i);
    }
    if (new_click_list.size() != user_info->recent_click().size())
      user_info->mutable_recent_click()->Swap(&new_click_list);
  }
}

}  // namespace leafserver
}  // namespace reco
