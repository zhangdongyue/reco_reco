#include "reco/serv/reco_leaf/strategy/probe/action/news_tag_to_video.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/type/query_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/reco/video/video_reco.h"

namespace reco {
namespace leafserver {

NewsTagToVideo::NewsTagToVideo() {
  video_reco_ = new VideoReco();
}

NewsTagToVideo::~NewsTagToVideo() {
  delete video_reco_;
}

bool NewsTagToVideo::GetProbeRecoByActionDetail(const RecoRequest* reco_request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item) {
  if (probe_info.probe_action != get_probe_action()) {
    return false;
  }
  if (probe_info.probe_detail.empty()) {
    return false;
  }

  video_reco_->GetVideoFromResponse(reco_request, result_num, reco_item);
  return !reco_item->empty();
}
} // namespace leaf
} // namespace reco
