#include "reco/serv/reco_leaf/strategy/probe/action/structured_search.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/type/query_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/search/structured_searcher.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

namespace reco {
namespace leafserver {

StructuredSearch::StructuredSearch() : search_config_("StrSea") {
  searcher_ = new StructuredSearcher(LeafDataManager::GetGlobalData()->news_index);

  search_config_.ir_num = 3000;
  search_config_.fr_num = 20;
  search_config_.rel_low_threshold = 0;
  search_config_.rel_high_threshold = 0;
  search_config_.ctr_low_threshold = 0;
  search_config_.ctr_high_threshold = 0;
  search_config_.show_threshold = 0;
  search_config_.title_rel_coef = 0.9f;
  search_config_.keyword_rel_coef = 0.1f;
  search_config_.timelevel_threshold = reco::kGoodTimeliness;
  search_config_.use_cache = true;
  search_config_.title_all_hit = true;

  search_config_.white_media_dict.insert("新浪网");
  search_config_.white_media_dict.insert("腾讯网");
  search_config_.white_media_dict.insert("网易");
}

StructuredSearch::~StructuredSearch() {
  delete searcher_;
}

bool StructuredSearch::GetProbeRecoByActionDetail(const RecoRequest* reco_request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item) {
  if (probe_info.probe_action != get_probe_action()) {
    return false;
  }
  if (probe_info.probe_detail.empty()) {
    return false;
  }

  search_config_.return_num = result_num;
  return searcher_->Search(reco_request, probe_info.probe_detail, search_config_, reco_item, NULL);
}

} // namespace leaf
} // namespace reco
