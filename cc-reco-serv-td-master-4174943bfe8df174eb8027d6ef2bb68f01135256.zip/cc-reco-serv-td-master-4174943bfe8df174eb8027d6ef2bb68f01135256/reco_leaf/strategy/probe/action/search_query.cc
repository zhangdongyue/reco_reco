#include "reco/serv/reco_leaf/strategy/probe/action/search_query.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/type/query_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/search/leaf_searcher.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

namespace reco {
namespace leafserver {

const char* SearchQuery::kTimeInsensitiveCategories[] = { "健康", "历史", "奇闻", "干货", "收藏", "教育",
  "旅游", "游戏", "科学探索", "美食", "职场", "育儿", "两性情感" };

// 小流量时 cache prefix 一定要重设，否则和线上 leaf cache 缓存结果冲突
SearchQuery::SearchQuery() : search_config_("SeaQry"),
    device_search_low_config_("DvLQry"),device_search_high_config_("DvHQry"),
    taobao_search_config_("TbQry") {
  searcher_ = new LeafSearcher(LeafDataManager::GetGlobalData()->news_index);

  // kafka producer
  producer_ = LeafDataManager::GetGlobalData()->query_probe_producer;

  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(kTimeInsensitiveCategories); ++i) {
    time_insensitive_categories_.insert(kTimeInsensitiveCategories[i]);
  }

  // default query search config
  search_config_.ir_num = 1000;
  search_config_.fr_num = 50;
  search_config_.rel_low_threshold = 0.7;
  search_config_.rel_high_threshold = 0.9;
  search_config_.ctr_low_threshold = 0.07;
  search_config_.ctr_high_threshold = 0.08;
  search_config_.show_threshold = 300;
  search_config_.title_rel_coef = 0.9f;
  search_config_.keyword_rel_coef = 0.1f;
  search_config_.timelevel_threshold = reco::kGoodTimeliness;
  search_config_.use_cache = true;

  // device search config
  device_search_low_config_.ir_num = 1000;
  device_search_low_config_.fr_num = 50;
  device_search_low_config_.ctr_low_threshold = 0.08;
  device_search_low_config_.ctr_high_threshold = 0.09;
  device_search_low_config_.rel_low_threshold = 0.8;
  device_search_low_config_.rel_high_threshold = 0.9;
  device_search_low_config_.show_threshold = 300;
  device_search_low_config_.title_rel_coef = 0.95f;
  device_search_low_config_.keyword_rel_coef = 0.05f;
  device_search_low_config_.timelevel_threshold = reco::kGoodTimeliness;
  device_search_low_config_.use_cache = true;

  device_search_high_config_.ir_num = 1000;
  device_search_high_config_.fr_num = 50;
  device_search_high_config_.ctr_low_threshold = 0.09;
  device_search_high_config_.ctr_high_threshold = 0.1;
  device_search_high_config_.rel_low_threshold = 0.8;
  device_search_high_config_.rel_high_threshold = 0.9;
  device_search_high_config_.show_threshold = 300;
  device_search_high_config_.title_rel_coef = 0.95f;
  device_search_high_config_.keyword_rel_coef = 0.05f;
  device_search_high_config_.timelevel_threshold = reco::kGoodTimeliness;
  device_search_high_config_.use_cache = true;

  // taobao query search config
  taobao_search_config_.ir_num = 1000;
  taobao_search_config_.fr_num = 100;
  taobao_search_config_.rel_low_threshold = 0.8;
  taobao_search_config_.rel_high_threshold = 0.9;
  taobao_search_config_.ctr_low_threshold = 0.08;
  taobao_search_config_.ctr_high_threshold = 0.09;
  taobao_search_config_.show_threshold = 300;
  taobao_search_config_.title_rel_coef = 0.95f;
  taobao_search_config_.keyword_rel_coef = 0.05f;
  taobao_search_config_.timelevel_threshold = reco::kGoodTimeliness;
  taobao_search_config_.use_cache = true;
}

SearchQuery::~SearchQuery() {
  delete searcher_;
}

bool SearchQuery::GetProbeRecoByActionDetail(const RecoRequest* reco_request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item) {
  if (probe_info.probe_action != get_probe_action()) {
    return false;
  }
  if (probe_info.probe_detail.empty()) {
    return false;
  }

  search_debug_info_.Reset();

  // 不同的 ProbeType 走不同的 leaf_search 配置版本
  if (probe_info.probe_type == reco::kQueryProbe) {
    // 搜索 query 探索
    search_config_.return_num = result_num;
    // 限定类目
    std::vector<std::string> flds;
    base::SplitString(probe_info.probe_detail, "\t", &flds);
    search_config_.timelevel_threshold = reco::kGoodTimeliness;
    search_config_.white_category_dict_l1.clear();
    for (int i = 1; i < (int)flds.size(); ++i) {
      if (!flds[i].empty()) {
        search_config_.white_category_dict_l1.insert(flds[i]);

        // 部分类目放松时效性要求，提高线上召回
        if (time_insensitive_categories_.find(flds[i]) != time_insensitive_categories_.end()) {
          search_config_.timelevel_threshold = reco::kMidTimeliness;
        }
      }
    }
    // TODO 非 wifi 环境下出视频结果用户的 ctr 很低，wifi 环境有视频偏好的用户可以尝试
    search_config_.white_item_type_dict.clear();
    search_config_.white_item_type_dict.insert(reco::kNews);
    search_config_.white_item_type_dict.insert(reco::kReading);
    search_config_.white_item_type_dict.insert(reco::kPicture);
    search_config_.white_item_type_dict.insert(reco::kSpecial);
    search_config_.skip_filter_source_dict.clear();
    search_config_.skip_filter_source_dict.insert("probe_query");

    bool ret = searcher_->Search(reco_request, flds[0], search_config_, reco_item, &search_debug_info_);
    // LOG(INFO) << "search query probe results: query=" << flds[0] << ", ret_num=" << reco_item->size();

    // write probe result to kafka
    if (producer_ != NULL) {
      reco::ProbeResult probe_result;
      probe_result.set_probe_type(reco::kQueryProbe);
      probe_result.set_probe_action(reco::kSearchQuery);
      probe_result.set_probe_detail(flds[0]);
      probe_result.set_return_num((uint64)reco_item->size());
      probe_result.set_ir_result_num(search_debug_info_.ir_result);
      probe_result.set_fr_result_num(search_debug_info_.fr_result);
      probe_result.set_probe_time(base::GetTimestamp() / base::Time::kMicrosecondsPerSecond);
      std::string kafka_msg;
      if (probe_result.SerializeToString(&kafka_msg)) {
        if (!producer_->Produce(kafka_msg)) {
          LOG(WARNING) << "failed to write probe result kafka";
        }
      }
    }
    return ret;
  } else if (probe_info.probe_type == reco::kDeviceProbe) {
    // 机型探索
    std::vector<std::string> flds;
    base::SplitString(probe_info.probe_detail, "\t", &flds);

    if (flds.size() > 1u && flds[1] == "0") {
      // 冷启动或对科技感兴趣用户
      device_search_low_config_.return_num = result_num;
      device_search_low_config_.white_item_type_dict.clear();
      device_search_low_config_.white_item_type_dict.insert(reco::kNews);
      device_search_low_config_.white_item_type_dict.insert(reco::kReading);
      device_search_low_config_.white_item_type_dict.insert(reco::kPicture);
      device_search_low_config_.white_item_type_dict.insert(reco::kSpecial);
      device_search_low_config_.skip_filter_source_dict.clear();
      device_search_low_config_.skip_filter_source_dict.insert("probe_query");
      bool ret = searcher_->Search(reco_request, flds[0], device_search_low_config_, reco_item, NULL);
      // LOG(INFO) << "device probe results: query=" << flds[0] << ", ret_num=" << reco_item->size();
      return ret;
    } else {
      // 对科技不感兴趣用户
      device_search_high_config_.return_num = result_num;
      device_search_low_config_.white_item_type_dict.clear();
      device_search_high_config_.white_item_type_dict.insert(reco::kNews);
      device_search_high_config_.white_item_type_dict.insert(reco::kReading);
      device_search_high_config_.white_item_type_dict.insert(reco::kPicture);
      device_search_high_config_.white_item_type_dict.insert(reco::kSpecial);
      device_search_high_config_.skip_filter_source_dict.clear();
      device_search_high_config_.skip_filter_source_dict.insert("probe_query");
      bool ret = searcher_->Search(reco_request, flds[0], device_search_high_config_, reco_item, NULL);
      // LOG(INFO) << "device probe results: query=" << flds[0] << ", ret_num=" << reco_item->size();
      return ret;
    }
  } else if (probe_info.probe_type == reco::kTaobaoQueryProbe) {
    // 淘宝 query 探索
    taobao_search_config_.return_num = result_num;

    // 限定类目
    std::vector<std::string> flds;
    base::SplitString(probe_info.probe_detail, "\t", &flds);
    taobao_search_config_.white_category_dict_l1.clear();
    for (int i = 1; i < (int)flds.size(); ++i) {
      if (!flds[i].empty()) {
        taobao_search_config_.white_category_dict_l1.insert(flds[i]);
      }
    }
    taobao_search_config_.white_item_type_dict.clear();
    taobao_search_config_.white_item_type_dict.insert(reco::kNews);
    taobao_search_config_.white_item_type_dict.insert(reco::kReading);
    taobao_search_config_.white_item_type_dict.insert(reco::kPicture);
    taobao_search_config_.white_item_type_dict.insert(reco::kSpecial);
    taobao_search_config_.skip_filter_source_dict.clear();
    taobao_search_config_.skip_filter_source_dict.insert("probe_query");
    VLOG(1) << "search taobao query: uid=" << reco_request->request->user().user_id()
            << ", orig_query=" << flds[0];

    bool ret = searcher_->Search(reco_request, flds[0], taobao_search_config_, reco_item, &search_debug_info_);
    // LOG(INFO) << "taobao query probe results: query=" << flds[0] << ", ret_num=" << reco_item->size();

    // write probe result to kafka
    if (producer_ != NULL) {
      reco::ProbeResult probe_result;
      probe_result.set_probe_type(reco::kTaobaoQueryProbe);
      probe_result.set_probe_action(reco::kSearchQuery);
      probe_result.set_probe_detail(flds[0]);
      probe_result.set_return_num((uint64)reco_item->size());
      probe_result.set_ir_result_num(search_debug_info_.ir_result);
      probe_result.set_fr_result_num(search_debug_info_.fr_result);
      probe_result.set_probe_time(base::GetTimestamp() / base::Time::kMicrosecondsPerSecond);
      std::string kafka_msg;
      if (probe_result.SerializeToString(&kafka_msg)) {
        if (!producer_->Produce(kafka_msg)) {
          LOG(WARNING) << "failed to write probe result kafka";
        }
      }
    }

    return ret;
  }

  return true;
}

} // namespace leaf
} // namespace reco
