#include "reco/serv/reco_leaf/strategy/probe/action/guess_tag.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/type/query_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/search/tag_searcher.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

namespace reco {
namespace leafserver {

GuessTag::GuessTag() : tag_searcher_config_("GuessTag") {
  tag_searcher_ = new TagSearcher(LeafDataManager::GetGlobalData()->news_index);

  tag_searcher_config_.ir_num = 1000;
  tag_searcher_config_.fr_num = 50;
  tag_searcher_config_.rel_low_threshold = 0.6;
  tag_searcher_config_.rel_high_threshold = 0.7;
  tag_searcher_config_.ctr_low_threshold = 0.11;
  tag_searcher_config_.ctr_high_threshold = 0.12;
  tag_searcher_config_.show_threshold = 300;

  tag_searcher_config_.title_rel_coef = 0.9f;
  tag_searcher_config_.keyword_rel_coef = 0.1f;

  tag_searcher_config_.timelevel_threshold = reco::kGoodTimeliness;
  tag_searcher_config_.use_cache = true;

  tag_searcher_config_.filter_region = true;
  tag_searcher_config_.in_show_tag = true;
  tag_searcher_config_.white_item_type_dict.insert(reco::kNews);
  tag_searcher_config_.white_item_type_dict.insert(reco::kReading);
  tag_searcher_config_.white_item_type_dict.insert(reco::kPicture);
  tag_searcher_config_.white_item_type_dict.insert(reco::kPictureNews);
}

GuessTag::~GuessTag() {
  delete tag_searcher_;
}

bool GuessTag::GetProbeRecoByActionDetail(const RecoRequest* reco_request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item) {
  if (probe_info.probe_action != get_probe_action()) {
    return false;
  }
  if (probe_info.probe_detail.empty()) {
    return false;
  }

  tag_searcher_config_.return_num = result_num;
  return tag_searcher_->Search(reco_request, probe_info.probe_detail,
                               tag_searcher_config_, reco_item, NULL);
}

} // namespace leaf
} // namespace reco
