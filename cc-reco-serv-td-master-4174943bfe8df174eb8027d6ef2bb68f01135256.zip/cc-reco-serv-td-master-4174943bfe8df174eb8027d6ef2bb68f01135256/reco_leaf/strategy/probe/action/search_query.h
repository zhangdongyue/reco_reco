#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/probe.pb.h"
#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"

namespace reco {
namespace leafserver {

class LeafSearcher;
class SearchQuery: public ProbeActionBase {
public:
  SearchQuery();
  virtual ~SearchQuery();

  virtual reco::ProbeAction get_probe_action() {
    return reco::kSearchQuery;
  }

  virtual bool GetProbeRecoByActionDetail(const RecoRequest* request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item);

private:
  void DoActionReco(const ProbeInfo& sttg_info, std::vector<ItemInfo>* rslt);
  LeafSearcher* searcher_;
  BaseSearcher::Config search_config_;
  BaseSearcher::Config device_search_low_config_;
  BaseSearcher::Config device_search_high_config_;
  BaseSearcher::Config taobao_search_config_;

  // debug info
  BaseSearcher::DebugInfo search_debug_info_;

  // 对部分类目，可以放松时效性要求
  static const char* kTimeInsensitiveCategories[];
  std::unordered_set<std::string> time_insensitive_categories_;

  // kafka
  reco::kafka::Producer* producer_;
};

} // namespace leaf
} // namespace reco
