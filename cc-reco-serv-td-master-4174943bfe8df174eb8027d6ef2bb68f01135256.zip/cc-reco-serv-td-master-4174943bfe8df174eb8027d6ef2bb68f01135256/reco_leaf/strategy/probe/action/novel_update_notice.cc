#include "reco/serv/reco_leaf/strategy/probe/action/novel_update_notice.h"
#include "reco/serv/reco_leaf/strategy/probe/type/novel_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/search/novel_notice_searcher.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "serving_base/utility/timer.h"

namespace reco {
namespace leafserver {

NovelUpdateNotice::NovelUpdateNotice() : searcher_config_("NovelUpdateNotice") {
  nn_searcher_ = new NovelNoticeSearcher(LeafDataManager::GetGlobalData()->news_index);
  searcher_config_.use_cache = true;
}

NovelUpdateNotice::~NovelUpdateNotice() {
  delete nn_searcher_;
}

bool NovelUpdateNotice::GetProbeRecoByActionDetail(const RecoRequest* reco_request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item) {
  if (probe_info.probe_action != get_probe_action()) {
    return false;
  }
  if (probe_info.probe_detail.empty()) {
    return false;
  }

  serving_base::Timer timer;
  timer.Start();
  searcher_config_.return_num = result_num;
  bool ret = nn_searcher_->Search(reco_request, probe_info.probe_detail,
                                  searcher_config_, reco_item, NULL);
  VLOG(1) << "uid=" << reco_request->user_info->identity().user_id()
          << ", nn_searcher cost time: " << timer.Stop();
  return ret;
}

} // namespace leaf
} // namespace reco
