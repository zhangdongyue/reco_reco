#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/probe.pb.h"
#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"
#include "reco/serv/reco_leaf/strategy/search/title_searcher.h"

namespace reco {
namespace leafserver {

class LeafSearcher;
class ViewTitle: public ProbeActionBase {
public:
  ViewTitle();
  virtual ~ViewTitle();

  virtual reco::ProbeAction get_probe_action() {
    return reco::kViewTitle;
  }

  virtual bool GetProbeRecoByActionDetail(const RecoRequest* request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item);

private:
  void DoActionReco(const ProbeInfo& sttg_info, std::vector<ItemInfo>* rslt);
  TitleSearcher* searcher_;
  BaseSearcher::Config search_config_;

  // debug info
  BaseSearcher::DebugInfo search_debug_info_;

  // kafka
  reco::kafka::Producer* producer_;
};

} // namespace leaf
} // namespace reco
