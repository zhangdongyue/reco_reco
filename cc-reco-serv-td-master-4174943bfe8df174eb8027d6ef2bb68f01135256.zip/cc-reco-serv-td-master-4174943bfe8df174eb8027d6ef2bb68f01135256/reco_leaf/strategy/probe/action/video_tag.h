#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace leafserver {
class VideoReco;

class VideoTag: public ProbeActionBase {
public:
  VideoTag();
  virtual ~VideoTag();

  virtual reco::ProbeAction get_probe_action() {
    return reco::kVideoTag;
  }

  virtual bool GetProbeRecoByActionDetail(const RecoRequest* request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item);

private:
  void DoActionReco(const ProbeInfo& sttg_info, std::vector<ItemInfo>* rslt);
  VideoReco* video_reco_;
};
} // namespace leaf
} // namespace reco
