#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace leafserver {

class LeafSearcher;
class ManualCtrl: public ProbeActionBase {
 public:
  ManualCtrl();
  virtual ~ManualCtrl();
  virtual reco::ProbeAction get_probe_action() {
    return reco::kManualCtrl;
  }

  virtual bool GetProbeRecoByActionDetail(const RecoRequest* request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item);
 private:
  const std::vector<std::pair<std::string, ItemInfo> >* probe_manual_items_;

};


} // namespace leaf
} // namespace reco
