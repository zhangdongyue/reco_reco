#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"

namespace reco {
namespace leafserver {

class StructuredSearcher;
class StructuredSearch: public ProbeActionBase {
public:
  StructuredSearch();
  virtual ~StructuredSearch();

  virtual reco::ProbeAction get_probe_action() {
    return reco::kStructuredSearch;
  }

  virtual bool GetProbeRecoByActionDetail(const RecoRequest* request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item);

private:
  StructuredSearcher* searcher_;
  BaseSearcher::Config search_config_;

};


} // namespace leaf
} // namespace reco
