#include "reco/serv/reco_leaf/strategy/probe/action/manual_ctrl.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/type/manual_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

namespace reco {
namespace leafserver {

ManualCtrl::ManualCtrl() {
}

ManualCtrl::~ManualCtrl() {
}

bool ManualCtrl::GetProbeRecoByActionDetail(const RecoRequest* reco_request,
                                            const reco::NewsIndex* news_index,
                                            const ProbeStrategyManager* probe_manager,
                                            const ProbeInfo& probe_info,
                                            int result_num,
                                            std::vector<reco::ItemInfo>* reco_item) {
  if (probe_info.probe_action != get_probe_action()) {
    return false;
  }
  if (probe_info.probe_detail.empty()) {
    return false;
  }

  if (probe_info.probe_type == reco::kManualProbe) {
    probe_manual_items_ = reco_request->probe_manual_items;
    for (auto iter = probe_manual_items_->begin();
         iter != probe_manual_items_->end() && (int)reco_item->size() < result_num;
         ++iter) {
      if (iter->first == probe_info.probe_detail) {
        reco_item->push_back(iter->second);
      }
    }
  }
  return true;
}

} // namespace leafserver
} // namespace reco
