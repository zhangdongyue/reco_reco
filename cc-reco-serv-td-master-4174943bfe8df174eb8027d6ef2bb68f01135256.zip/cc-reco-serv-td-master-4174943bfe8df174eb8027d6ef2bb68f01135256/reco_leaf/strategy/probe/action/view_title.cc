#include "reco/serv/reco_leaf/strategy/probe/action/view_title.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

namespace reco {
namespace leafserver {

// 小流量时 cache prefix 一定要重设，否则和线上 leaf cache 缓存结果冲突
ViewTitle::ViewTitle() : search_config_("SeaTit") {
  searcher_ = new TitleSearcher(LeafDataManager::GetGlobalData()->news_index);

  // kafka producer
  producer_ = LeafDataManager::GetGlobalData()->query_probe_producer;

  // default title search config
  // 注意: config 用法和 leaf_search 不一样, rel_low_threshold 和 rel_high_threshold
  // 用来限定相似度有效区间, ctr_low_threshold 用来控制 ctr 阈值
  search_config_.ir_num = 1000;
  search_config_.fr_num = 50;
  search_config_.rel_low_threshold = 0.5;
  search_config_.rel_high_threshold = 1.0;
  search_config_.ctr_low_threshold = 0.09;
  search_config_.ctr_high_threshold = 0.09;
  search_config_.show_threshold = 200;
  search_config_.title_rel_coef = 0.7f;
  search_config_.keyword_rel_coef = 0.3f;
  search_config_.timelevel_threshold = reco::kGoodTimeliness;
  search_config_.use_cache = true;
}

ViewTitle::~ViewTitle() {
  delete searcher_;
}

bool ViewTitle::GetProbeRecoByActionDetail(const RecoRequest* reco_request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item) {
  if (probe_info.probe_action != get_probe_action()) {
    return false;
  }
  if (probe_info.probe_detail.empty()) {
    return false;
  }

  search_debug_info_.Reset();

  if (probe_info.probe_type == reco::kUcbLogProbe) {
    search_config_.return_num = result_num;
    // 限定类目
    std::vector<std::string> flds;
    base::SplitString(probe_info.probe_detail, "\t", &flds);
    search_config_.white_category_dict_l1.clear();
    for (int i = 1; i < (int)flds.size(); ++i) {
      if (!flds[i].empty()) {
        search_config_.white_category_dict_l1.insert(flds[i]);
      }
    }
    search_config_.white_item_type_dict.clear();
    search_config_.white_item_type_dict.insert(reco::kNews);
    search_config_.white_item_type_dict.insert(reco::kReading);
    search_config_.white_item_type_dict.insert(reco::kPicture);
    search_config_.white_item_type_dict.insert(reco::kSpecial);
    search_config_.skip_filter_source_dict.clear();
    search_config_.skip_filter_source_dict.insert("probe_query");

    bool ret = searcher_->Search(reco_request, flds[0], search_config_, reco_item, &search_debug_info_);
    // LOG(INFO) << "ucb log probe results: query=" << flds[0] << ", ret_num=" << reco_item->size();

    // write probe result to kafka
    if (producer_ != NULL) {
      reco::ProbeResult probe_result;
      probe_result.set_probe_type(reco::kUcbLogProbe);
      probe_result.set_probe_action(reco::kViewTitle);
      probe_result.set_probe_detail(flds[0]);
      probe_result.set_return_num((uint64)reco_item->size());
      probe_result.set_ir_result_num(search_debug_info_.ir_result);
      probe_result.set_fr_result_num(search_debug_info_.fr_result);
      probe_result.set_probe_time(base::GetTimestamp() / base::Time::kMicrosecondsPerSecond);
      std::string kafka_msg;
      if (probe_result.SerializeToString(&kafka_msg)) {
        if (!producer_->Produce(kafka_msg)) {
          LOG(WARNING) << "failed to write probe result kafka";
        }
      }
    }
    return ret;
  }
  return true;
}

} // namespace leaf
} // namespace reco
