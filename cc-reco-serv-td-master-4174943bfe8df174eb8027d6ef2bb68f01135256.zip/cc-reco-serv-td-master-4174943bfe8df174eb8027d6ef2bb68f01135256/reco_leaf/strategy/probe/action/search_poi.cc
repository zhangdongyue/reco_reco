#include "reco/serv/reco_leaf/strategy/probe/action/search_poi.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/type/query_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/search/leaf_searcher.h"
#include "reco/serv/reco_leaf/strategy/search/tag_searcher.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

namespace reco {
namespace leafserver {

SearchPoi::SearchPoi() : leaf_searcher_config_("SeaPoi"), tag_searcher_config_("SeaPoi") {
  leaf_searcher_ = new LeafSearcher(LeafDataManager::GetGlobalData()->news_index);
  tag_searcher_ = new TagSearcher(LeafDataManager::GetGlobalData()->news_index);

  // 为校园推广来做的，不限制召回文章的点击率只要相关性
  leaf_searcher_config_.ir_num = 1000;
  leaf_searcher_config_.show_threshold = 0;
  leaf_searcher_config_.ctr_low_threshold = 0;
  leaf_searcher_config_.ctr_high_threshold = 0;
  leaf_searcher_config_.rel_low_threshold = 0.8;
  leaf_searcher_config_.rel_high_threshold = 0.8;
  leaf_searcher_config_.timelevel_threshold = reco::kBadTimeliness;

  tag_searcher_config_.ir_num = 1000;
  tag_searcher_config_.show_threshold = 0;
  tag_searcher_config_.ctr_low_threshold = 0;
  tag_searcher_config_.ctr_high_threshold = 0;
  tag_searcher_config_.rel_low_threshold = 0;
  tag_searcher_config_.rel_high_threshold = 0;
  tag_searcher_config_.timelevel_threshold = reco::kBadTimeliness;
}

SearchPoi::~SearchPoi() {
  delete leaf_searcher_;
  delete tag_searcher_;
}

bool SearchPoi::GetProbeRecoByActionDetail(const RecoRequest* reco_request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item) {
  if (probe_info.probe_action != get_probe_action()) {
    return false;
  }
  if (probe_info.probe_detail.empty()) {
    return false;
  }

  // 首先调用 search by tag
  tag_searcher_config_.return_num = result_num;
  if (tag_searcher_->Search(reco_request, probe_info.probe_detail,
                            tag_searcher_config_, reco_item, NULL)) {
    if ((int)reco_item->size() > result_num) {
      return true;
    }
  }

  std::vector<reco::ItemInfo> tmp_item;
  leaf_searcher_config_.return_num = result_num;
  if (leaf_searcher_->Search(reco_request, probe_info.probe_detail,
                             leaf_searcher_config_, &tmp_item, NULL)) {
    reco_item->insert(reco_item->end(), tmp_item.begin(), tmp_item.end());
  }
  return true;
}

} // namespace leaf
} // namespace reco
