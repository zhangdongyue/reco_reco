#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/strings/string_number_conversions.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_stat.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"

namespace reco {
namespace leafserver {

struct RecoRequest;
class ProbeStatManager;

// 探索策略进场退场框架实现
//
// <*名词解释*>
// ProbeStrategy 探索性质的策略。叫probe，不叫explore的原因，是explore已经在personal reco里被用了。
//               一个探索策略由 type 和 action 两部分组成（对应probe下面的两个子目录）。
// ProbeType 这个探索的类型，是策略的标识，比如基于 query 探索、探索用户是否愿意消费视频，等等
//           其核心，一是决定这个用户是否适合进行这个探索，二是决定具体的行为
// ProbeAction 实现了具体的推荐逻辑。比如 ProbeType 决定要给这个用户投放指定标签，
//             那么 ProbeAction 就是实现具体的标签搜索算法
// ProbeStat/ProbeQuota 这两个都是对应同一个数据结构，即 ProbeStrategy 投放后的统计指标。
//                      Quota 可以认为是统计指标里各个维度的阈值
//
// <*文件说明*>
// probe_base.h 声明了 type 和 action 的基类，定义了基本行为
// probe_stat.h 声明了统计的维度，并提供一些方法方便操作
// probe_stat_manager.h 负责维护各个策略的 ProbeStat 统计信息
// probe_manager.h 实现了进场退场的框架，包括：
//    调用 stat_manager 计算统计信息；调用各个 type 由他们提交action；调用各个action得到推荐结果，并更新配额
//
// <*实现你的策略*>
// 1. 在 type 和 action 目录里实现你的探索类型和行为类。参考已有的实现即可
// 2. ProbeStrategyManager 的构造函数里，提交你的类，注册到框架里
// 3. 如果需要自定义配额，修改 SetProbeQuota 函数，但注意不要太纵容自己让别人无出头之日
//
class ProbeStrategyManager {
public:
  ProbeStrategyManager(const reco::NewsIndex* news_index);

  ~ProbeStrategyManager();

  bool GetRecoResult(const NewsIndex* news_index,
                     const RecoRequest* reco_quest,
                     int result_num,
                     std::vector<ItemInfo>* reco_result);

  // 指定某个策略进行探索
  // 这个接口必须是在调用完上面 GetRecoResult 之后才能调用，因为有一些初始化工作依赖
  void GetRecoResult(const NewsIndex* news_index,
                     const reco::ProbeType& probe_type,
                     const RecoRequest* reco_quest,
                     int result_num,
                     std::vector<ItemInfo>* reco_result);

  // 供策略方调用，当策略方决定要采取一个行为时，调用此函数获得是否有配额能够执行。
  // 以便于当策略内部要执行多个行为时，选择有配额的行为提交，避免浪费
  // 注意：这个函数返回 true 的行为，在管理类中还可能被干掉。
  // 因为在管理类收集了多个子策略递交的行为之后
  // 在真正计算结果之前，还会根据本轮 chosen_probes 新增行为去动态调整配额
  bool ProbeCanTry(const ProbeInfo& probe_info) const;

  // 供策略方调用, 这个行为对当前请求是否有结果返回
  // 策略方在汇报某个行动时，问下框架这个行动是否有结果
  // 如果没有结果，就不要汇报上去了，避免无效的探索
  bool ProbeHasResult(const RecoRequest* request, const ProbeInfo& probe_info) const;

  // 测试按照当前的统计量 stat 和配额 quota，是否可以给予尝试机会
  // return false stat 超过 quota
  // return true stat 未超过 quota
  bool HasQuota(const ProbeStat& stat, const ProbeStat& quota) const;
  // 查询给定 item id 是否是探索策略出来的，
  // 如果是，返回 true 并返回相应策略信息；否则返回 false
  bool GetItemProbeInfo(uint64 item_id, ProbeInfo* probe_info) const {
    auto it = item_probe_info_.find(item_id);
    if (it == item_probe_info_.end()) return false;
    *probe_info = it->second;
    return true;
  }
private:
  // 获得不同策略的配额
  const ProbeStat& GetProbeTypeQuota(const reco::ProbeType type) const {
    auto it = probe_type_quota_.find(type);
    if (it == probe_type_quota_.end()) return default_quota_;
    return it->second;
  }
  const ProbeStat& GetProbeActionQuota(const reco::ProbeAction action) const {
    // 如果有个性化设置的就用个性化的
    auto jt = personal_probe_action_quota_.find(action);
    if (jt != personal_probe_action_quota_.end()) return jt->second;
    auto it = probe_action_quota_.find(action);
    if (it == probe_action_quota_.end()) return default_quota_;
    return it->second;
  }
  // 设置策略相关的配额
  void SetProbeQuota();
  // 个性化设置配额
  void SetQuotaPersonalized(const RecoRequest* reco_request);
  // 默认的配额，策略未自定义配额时，则使用默认
  void SetDefaultQuota();
  void SetNullResultCache(const RecoRequest* reco_request, const ProbeInfo& info);
private:
  const reco::NewsIndex* news_index_;
  // 每个策略最多的行为数
  static const int kMaxActionPerStrategy = 5;
  static const int kDefaultMaxResultNumPerStrategy = 1;
  std::map<reco::ProbeType, int> max_result_num_per_strategy_;
  // 外部传入
  const RecoRequest* reco_request_;
  // 存放策略类
  //std::map<reco::ProbeType, ProbeTypeBase*> strategy_types_;
  std::vector<ProbeTypeBase*> strategy_types_;
  // 存放执行类
  std::map<reco::ProbeAction, ProbeActionBase*> strategy_actions_;
  // 策略和执行相关的配额阈值
  // 在框架中，会统计当前的策略和执行的配额情况，和阈值进行比较，来决定是否继续
  // 非 default quota 才放到这些结构里来
  std::map<reco::ProbeType, ProbeStat> probe_type_quota_;
  // NOTE: action 的配额要注意下，不同的 detail 是独立有配额的，但是他们的阈值是一样的。
  // 举例说都是要猜测 tag，不论具体tag是啥，都是只能猜 3 次，但不同 tag 总猜测次数加和是大于 3 的
  std::map<reco::ProbeAction, ProbeStat> probe_action_quota_;
  // 有些策略需要根据不同用户设置不同 quota
  std::map<reco::ProbeAction, ProbeStat> personal_probe_action_quota_;
  // 存放在本轮计算中，被选中的策略行为，这会影响动态的配额计算
  std::vector<ProbeInfo> chosen_probes_;
  // 执行策略相关的统计
  ProbeStatManager* probe_stat_manager_;
  // 默认的配额，如果不需要自定义，使用该值即可
  ProbeStat default_quota_;
  // itemid -> probeinfo
  std::map<uint64, ProbeInfo> item_probe_info_;
  CandidatesExtractor* candidates_extor_;

  FRIEND_TEST(ProbeManagerTest, TestQuota);
};

} // namespace leaf
} // namespace reco
