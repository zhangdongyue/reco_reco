#include "reco/serv/reco_leaf/strategy/probe/probe_stat.h"

#include <unordered_set>
#include <stdlib.h>
#include <iostream>

#include "base/testing/gtest.h"

namespace reco {
namespace leafserver {
TEST(ProbeStatTest, TestConstructor) {
  ProbeStat stat;
  ASSERT_GT(stat.last_show_refresh_interval, 1000);
  ASSERT_GT(stat.last_show_minute_delta, 1000);
  ASSERT_EQ(stat.last_continuous_refresh_num, 0);
  ASSERT_EQ(stat.today_show_num, 0);
  ASSERT_EQ(stat.total_show_num, 0);

  ASSERT_GT(stat.last_click_refresh_interval, 1000);
  ASSERT_GT(stat.last_click_minute_delta, 1000);
  ASSERT_EQ(stat.today_click_num, 0);
  ASSERT_EQ(stat.total_click_num, 0);

  ASSERT_EQ(stat.today_ctr, 0.0f);
  ASSERT_EQ(stat.total_ctr, 0.0f);

  ASSERT_EQ(stat, ProbeStat::GetStatUnHappen());
}

TEST(ProbeStatTest, Incre) {
  ProbeStat stat;
  ProbeStat onePvStat = ProbeStat::GetStatByOnePv();
  ASSERT_FALSE(stat == onePvStat);
  ASSERT_EQ(stat.IncreByOnePv(), onePvStat);
  ASSERT_EQ(stat.IncreByOnePv(), onePvStat.IncreByOnePv());

  // 测试 last_continuous_refresh_num 在不同场景下的自增情况
  ProbeStat s1;
  // case 1: 上一刷间隔很久，连续刷新数清 0 后只记录此次
  s1.last_show_refresh_interval = 5;
  s1.last_continuous_refresh_num = 3;
  s1.IncreByOnePv();
  ASSERT_EQ(s1.last_show_refresh_interval, 0);
  ASSERT_EQ(s1.last_continuous_refresh_num, 1);

  ProbeStat s2;
  // case 2: 上一刷和这一刷形成连续刷新
  s2.last_show_refresh_interval = 1;
  s2.last_continuous_refresh_num = 3;
  s2.IncreByOnePv();
  ASSERT_EQ(s2.last_show_refresh_interval, 0);
  ASSERT_EQ(s2.last_continuous_refresh_num, 4);

  ProbeStat s3;
  // case 3: 刷新间隔都是 0 即本刷， 连续刷新次数不涨，一刷投放多次而已
  s3.last_show_refresh_interval = 0;
  s3.last_continuous_refresh_num = 3;
  s3.IncreByOnePv();
  ASSERT_EQ(s3.last_show_refresh_interval, 0);
  ASSERT_EQ(s3.last_continuous_refresh_num, 3);
}
}  // namespace leafserver
}  // namespace reco

