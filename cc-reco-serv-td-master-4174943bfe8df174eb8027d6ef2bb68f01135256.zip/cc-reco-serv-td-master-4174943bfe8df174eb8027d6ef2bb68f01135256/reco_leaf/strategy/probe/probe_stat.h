#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace leafserver {

// 全局统计信息
struct ProbeStat {
  static const int kLargeNum = 10000;
  // 假设当前刷展现了一条结果，返回对应的 stat 值
  inline static ProbeStat GetStatByOnePv();
  // 假设从未发生过，返回对应的 stat 值
  inline static ProbeStat GetStatUnHappen();

  // 上次投放刷新间隔 从 1 开始， 上一刷间隔就是 1
  int last_show_refresh_interval;
  // 上次投放分钟间隔
  int last_show_minute_delta;
  // 从上次投放刷新开始，连续多少刷投放，以刷新次数记，非展现量
  // 一刷投放了两条， continuous_refresh_num 仍为 1
  int last_continuous_refresh_num;
  // 当天投放次数
  int today_show_num;
  // 总投放次数
  int total_show_num;

  // 上次点击刷新间隔 从 1 开始， 上一刷间隔就是 1
  int last_click_refresh_interval;
  // 上次点击分钟间隔
  int last_click_minute_delta;
  // 当天点击次数
  int today_click_num;
  // 总点击次数
  int total_click_num;

  // 当天点击率
  float today_ctr;
  // 总点击率
  float total_ctr;

  ProbeStat() {
    ResetUnHappen();
  }

  // 假设从未发生过，返回对应的 stat 值
  // 此函数是 return *this
  inline ProbeStat& ResetUnHappen();
  // 在当前统计值上，增加一次刷新下的一条展现，统计变化后的值并返回
  // 此函数是 return *this
  inline ProbeStat& IncreByOnePv();
  // 比较函数
  inline bool operator==(const ProbeStat& other) const;
  // for debug
  inline std::string ToString() const;
};
} // namespace leaf
} // namespace reco

#include "reco/serv/reco_leaf/strategy/probe/probe_stat-inl.h"
