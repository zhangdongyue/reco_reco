#include <unordered_set>
#include <stdlib.h>
#include <iostream>

#include "base/testing/gtest.h"
#include "base/common/sleep.h"
#include "base/time/time.h"
#include "base/time/timestamp.h"

#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_stat_manager.h"

namespace reco {
namespace leafserver {
class ProbeManagerTest : public testing::Test {
public:
  void SetUp() {
    manager = new ProbeStrategyManager();
  }

  void TearDown() {
    delete manager;
  }

  ProbeStrategyManager* manager;
};

TEST_F(ProbeManagerTest, TestQuota) {
  UserInfo user_info;
  ProbeInfo probe_info;

  probe_info.probe_type = reco::kQueryProbe;
  probe_info.probe_action = reco::kSearchTag;
  probe_info.probe_detail = "xx";
  for (int i = 0; i < 10; ++i) {
    manager->probe_stat_manager_->Reset();
    manager->probe_stat_manager_->DoStat(&user_info);

    if (i < manager->default_quota_.last_continuous_refresh_num) {
      ASSERT_TRUE(manager->ProbeCanTry(probe_info));
    } else {
      ASSERT_FALSE(manager->ProbeCanTry(probe_info));
      break;
    }

    manager->probe_stat_manager_->IncreStatByChosenProbe(probe_info);
    if (i < (manager->default_quota_.last_continuous_refresh_num - 1)) {
      ASSERT_TRUE(manager->ProbeCanTry(probe_info)) << i
          << "\nquota: " << manager->default_quota_.ToString()
          << "\nstat: " << manager->probe_stat_manager_->GetProbeTypeStat(probe_info.probe_type).ToString();

    } else {
      ASSERT_FALSE(manager->ProbeCanTry(probe_info));
    }

    ViewClickItem* item;
    item = user_info.add_shown_history();
    item->set_item_id(i);
    item->set_probe_type(probe_info.probe_type);
    item->set_probe_action(probe_info.probe_action);
    item->set_probe_detail(probe_info.probe_detail);
    item->set_item_type(kNews);
    item->set_view_timestamp(base::GetTimestamp());
  }
}
}  // namespace leafserver
}  // namespace reco

