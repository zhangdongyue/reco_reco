#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_stat.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"

namespace reco {
namespace leafserver {

// 维护各个策略的统计指标的类
class ProbeStatManager {
 public:
  ProbeStatManager();
  ~ProbeStatManager();

  // 重置内部的统计量
  void Reset();
  // 执行统计
  void DoStat(const reco::user::UserInfo* user_info);
  // 查询类 api
  const ProbeStat& GetProbeTypeStat(const reco::ProbeType type) const {
    auto it = probe_type_stat_.find(type);
    if (it == probe_type_stat_.end()) return unhappen_stat_;
    return it->second;
  }
  const ProbeStat& GetProbeActionStat(const reco::ProbeAction action, const std::string& detail) const {
    auto it = probe_action_stat_.find(action);
    if (it == probe_action_stat_.end()) return unhappen_stat_;
    auto jt = it->second.find(detail);
    if (jt == it->second.end()) return unhappen_stat_;
    return jt->second;
  }
  // 策略框架选中一个探索以后，将信息提交过来，以当前探索会被执行为前提，更新统计信息
  void IncreStatByChosenProbe(const ProbeInfo& probe_info) {
    probe_type_stat_[probe_info.probe_type].IncreByOnePv();
    probe_action_stat_[probe_info.probe_action][probe_info.probe_detail].IncreByOnePv();
  }
 private:
  static const int kEarliestDays = 7;

  // 分析展现点击日志得到的相关 item 的信息
  struct ItemStat {
    uint64 item_id;
    // 刷新间隔从 1 开始， 上一刷间隔就是 1
    int refresh_interval;
    // 展现分钟间隔
    int show_minute_delta;
    // 点击分钟间隔
    int click_minute_delta;
    // 天级间隔
    int day_delta;
    // 是否是今天
    bool is_today;
    // 是否点击
    bool is_clicked;

    ItemStat() {
      item_id = 0;
      refresh_interval = ProbeStat::kLargeNum;
      show_minute_delta = ProbeStat::kLargeNum;
      click_minute_delta = ProbeStat::kLargeNum;
      day_delta = ProbeStat::kLargeNum;
      is_today = false;
      is_clicked = false;
    }
  };

 private:
  // 解析刷新间隔, 返回总刷新次数
  int ParseRefreshInterval(const reco::user::UserInfo* user_info, const int64 earliest_timestamp,
                           std::map<int64, int>* refresh_interval);
  // 展现日志的 ViewClickItem 转换成统计结构
  // 返回 false 的几种情况: 时间缺失或者错误，时间戳在 refresh_interval 里找不到
  // 此时丢弃该数据
  bool ViewClickItemToItemStat(const reco::user::ViewClickItem& item,
                               const std::map<int64, int>& refresh_interval,
                               ItemStat* item_stat);
  // 点击日志的 ViewClickItem 更新 item_stat 中点击相关字段
  void UpdateItemStatByClick(const reco::user::ViewClickItem& click_item, ItemStat* item_stat);
  // 计算全局统计信息
  void ItemStatToProbeStat(const std::vector<uint64>& item_list,
                           const std::map<uint64, ItemStat>& item_stat,
                           ProbeStat* probe_stat);
 private:
  FRIEND_TEST(ProbeStatManagerTest, Case1_ClassMembers);
  FRIEND_TEST(ProbeStatManagerTest, MemberFunctions);

  // 无限制的配额，保证各种条件下都能够有展现机会
  ProbeStat unhappen_stat_;
  // 刷新时间对应的刷新间隔 最近的 1 刷间隔是 1
  std::map<int64, int> refresh_interval_;
  // 当前时间
  base::Time now_time_;
  // 今天凌晨
  base::Time midnight_time_;
  // 解析用户历史时最长保留的时间
  int64 earliest_timestamp_;

  // item 信息表，不在这个结构里的 item 都忽略
  std::map<uint64, ItemStat> item_stat_info_;
  // proto type 相关的 item 列表
  std::map<reco::ProbeType, std::vector<uint64> > probe_type_items_;
  // proto action 相关的 item 列表
  std::map<reco::ProbeAction, std::map<std::string, std::vector<uint64> > > probe_action_items_;
  // 最终要返回统计值结构
  std::map<reco::ProbeType, ProbeStat> probe_type_stat_;
  std::map<reco::ProbeAction, std::map<std::string, ProbeStat> > probe_action_stat_;
};
} // namespace leaf
} // namespace reco
