#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "base/strings/string_printf.h"
namespace reco {
namespace leafserver {

ProbeStat ProbeStat::GetStatByOnePv() {
  ProbeStat stat;
  stat.last_show_refresh_interval = 0;
  stat.last_show_minute_delta = 0;
  stat.last_continuous_refresh_num = 1;
  stat.today_show_num = 1;
  stat.total_show_num = 1;
  stat.last_click_refresh_interval = kLargeNum;
  stat.last_click_minute_delta = kLargeNum;
  stat.today_click_num = 0;
  stat.total_click_num = 0;
  stat.today_ctr = 0;
  stat.total_ctr = 0;
  return stat;
}

ProbeStat ProbeStat::GetStatUnHappen() {
  ProbeStat stat;
  stat.last_show_refresh_interval = kLargeNum;
  stat.last_show_minute_delta = kLargeNum;
  stat.last_continuous_refresh_num = 0;
  stat.today_show_num = 0;
  stat.total_show_num = 0;
  stat.last_click_refresh_interval = kLargeNum;
  stat.last_click_minute_delta = kLargeNum;
  stat.today_click_num = 0;
  stat.total_click_num = 0;
  stat.today_ctr = 0;
  stat.total_ctr = 0;
  return stat;
}

ProbeStat& ProbeStat::IncreByOnePv() {
  if (this->last_show_refresh_interval == 1) {
    this->last_continuous_refresh_num++;
  } else if (this->last_show_refresh_interval > 1) {
    this->last_continuous_refresh_num = 1;
  }
  this->last_show_refresh_interval = 0;
  this->last_show_minute_delta = 0;
  this->today_show_num++;
  this->total_show_num++;

  if (this->today_show_num > 0) {
    this->today_ctr = std::min(1.0f, static_cast<float>(this->today_click_num) /
        static_cast<float>(this->today_show_num));
  }

  if (this->total_show_num > 0) {
    this->total_ctr = std::min(1.0f, static_cast<float>(this->total_click_num) /
        static_cast<float>(this->total_show_num));
  }

  return *this;
}

ProbeStat& ProbeStat::ResetUnHappen() {
  // 此策略没有发生过对应的取值
  last_show_refresh_interval = kLargeNum;
  last_show_minute_delta = kLargeNum;
  last_continuous_refresh_num = 0;
  today_show_num = 0;
  total_show_num = 0;

  last_click_refresh_interval = kLargeNum;
  last_click_minute_delta = kLargeNum;
  today_click_num = 0;
  total_click_num = 0;

  today_ctr = 0;
  total_ctr = 0;

  return *this;
}

bool ProbeStat::operator==(const ProbeStat& other) const {
  return this->last_show_refresh_interval == other.last_show_refresh_interval
      && this->last_show_minute_delta == other.last_show_minute_delta
      && this->last_continuous_refresh_num == other.last_continuous_refresh_num
      && this->today_show_num == other.today_show_num
      && this->total_show_num == other.total_show_num
      && this->last_click_refresh_interval == other.last_click_refresh_interval
      && this->last_click_minute_delta == other.last_click_minute_delta
      && this->today_click_num == other.today_click_num
      && this->total_click_num == other.total_click_num
      && this->today_ctr == other.today_ctr
      && this->total_ctr == other.total_ctr;
}

std::string ProbeStat::ToString() const {
  return base::StringPrintf("last_show_refresh_interval=%d,"
                            "last_show_minute_delta=%d,"
                            "last_continuous_refresh_num=%d,"
                            "today_show_num=%d,"
                            "total_show_num=%d,"
                            "last_click_refresh_interval=%d,"
                            "last_click_minute_delta=%d,"
                            "today_click_num=%d,"
                            "total_click_num=%d,"
                            "today_ctr=%.3f,"
                            "total_ctr=%.3f",
                            last_show_refresh_interval,
                            last_show_minute_delta,
                            last_continuous_refresh_num,
                            today_show_num,
                            total_show_num,
                            last_click_refresh_interval,
                            last_click_minute_delta,
                            today_click_num,
                            total_click_num,
                            today_ctr,
                            total_ctr);
}
// ProbeStat& operator+=(ProbeStat delta) {
//   ticks_ += delta.delta_;
//   return *this;
// }
// 
// ProbeStat operator+(ProbeStat delta) const {
//   return Time(us_ + delta.delta_);
// }
} // namespace leaf
} // namespace reco
