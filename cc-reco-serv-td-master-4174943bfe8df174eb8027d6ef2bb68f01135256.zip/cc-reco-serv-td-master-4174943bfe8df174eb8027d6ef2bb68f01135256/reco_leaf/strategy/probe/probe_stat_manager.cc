#include "reco/serv/reco_leaf/strategy/probe/probe_stat_manager.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace leafserver {

ProbeStatManager::ProbeStatManager() {
}

ProbeStatManager::~ProbeStatManager() {
}

void ProbeStatManager::Reset() {
  refresh_interval_.clear();

  now_time_ = base::Time::Now();
  midnight_time_ = now_time_.LocalMidnight();
  earliest_timestamp_ = now_time_.ToDoubleT() * base::Time::kMicrosecondsPerSecond
      - base::Time::kMicrosecondsPerDay * kEarliestDays;

  item_stat_info_.clear();
  probe_type_items_.clear();
  probe_action_items_.clear();

  probe_type_stat_.clear();
  probe_action_stat_.clear();
}

int ProbeStatManager::ParseRefreshInterval(const reco::user::UserInfo* user_info,
                                           const int64 earliest_timestamp,
                                           std::map<int64, int>* refresh_interval) {
  std::set<int64> reco_ts;
  for (int i = 0; i < user_info->shown_history_size(); i++) {
    const reco::user::ViewClickItem& item = user_info->shown_history(i);
    if (!item.has_view_timestamp()
        || item.view_timestamp() < earliest_timestamp) {
      continue;
    }
    reco_ts.insert(item.view_timestamp());
  }

  int total_refresh = reco_ts.size();
  for (auto it = reco_ts.begin(); it != reco_ts.end(); ++it) {
    // 最近的一刷间隔为 1
    refresh_interval->insert(std::make_pair(*it, total_refresh--));
  }

  return total_refresh;
}

bool ProbeStatManager::ViewClickItemToItemStat(const reco::user::ViewClickItem& item,
                                               const std::map<int64, int>& refresh_interval,
                                               ItemStat* item_stat) {
  if (!item.has_view_timestamp()) return false;
  base::Time item_time = base::Time::FromDoubleT(item.view_timestamp() / base::Time::kMicrosecondsPerSecond);
  if (item_time > now_time_) return false;

  item_stat->item_id = item.item_id();

  auto it = refresh_interval.find(item.view_timestamp());
  if (it == refresh_interval.end()) return false;
  item_stat->refresh_interval = it->second;

  base::TimeDelta delta = now_time_ - item_time;
  item_stat->show_minute_delta = delta.InMinutes();
  item_stat->click_minute_delta = delta.InMinutes();
  item_stat->day_delta = delta.InDays();
  item_stat->is_today = (item_time > midnight_time_);
  item_stat->is_clicked = false;

  return true;
}

void ProbeStatManager::UpdateItemStatByClick(const reco::user::ViewClickItem& item, ItemStat* item_stat) {
  if (item.has_click_timestamp()) {
    base::Time item_time =
        base::Time::FromDoubleT(item.click_timestamp() / base::Time::kMicrosecondsPerSecond);
    if (item_time <= now_time_) {
      base::TimeDelta delta = now_time_ - item_time;
      item_stat->click_minute_delta = delta.InMinutes();
    }
  }

  item_stat->is_clicked = true;
}

void ProbeStatManager::DoStat(const reco::user::UserInfo* user_info) {
  if (!user_info) return;

  ParseRefreshInterval(user_info, earliest_timestamp_, &refresh_interval_);

  for (int i = 0; i < user_info->shown_history_size(); i++) {
    const reco::user::ViewClickItem& item = user_info->shown_history(i);
    if (!item.has_probe_type()
        || !ProbeType_IsValid(item.probe_type())
        || item.probe_type() == reco::kNoProbeType) {
      VLOG(1) << "item has no or invalid probe type";
      continue;
    }

    if (!item.has_probe_action()
        || !ProbeAction_IsValid(item.probe_action())
        || item.probe_action() == reco::kNoProbeAction) {
      VLOG(1) << "item has no or invalid probe action";
      continue;
    }

    if (!item.has_view_timestamp()) {
      VLOG(1) << "item has no viewtimestamp";
      continue;
    }

    ItemStat item_stat;
    if (!ViewClickItemToItemStat(item, refresh_interval_, &item_stat)) {
      VLOG(1) << "convertor ViewClickItem to ItemStat failed";
      // 很久以前的展现数据，会在这步里被过滤
      continue;
    }

    item_stat_info_.insert(std::make_pair(item.item_id(), item_stat));

    // 这里没有排序，因为从统计 global stat 的角度而言，不需要排序，遍历一次就知道了
    probe_type_items_[static_cast<reco::ProbeType>(item.probe_type())].push_back(item.item_id());
    probe_action_items_[static_cast<reco::ProbeAction>(item.probe_action())][item.probe_detail()]
        .push_back(item.item_id());
  }

  for (int i = 0; i < user_info->recent_click_size(); i++) {
    const reco::user::ViewClickItem& item = user_info->recent_click(i);
    auto it = item_stat_info_.find(item.item_id());
    if (it == item_stat_info_.end()) continue;
    UpdateItemStatByClick(item, &(it->second));
  }

  for (auto it = probe_type_items_.begin(); it != probe_type_items_.end(); ++it) {
    ProbeStat probe_stat;
    ItemStatToProbeStat(it->second, item_stat_info_, &probe_stat);
    probe_type_stat_[it->first] = probe_stat;
  }

  for (auto it = probe_action_items_.begin(); it != probe_action_items_.end(); ++it) {
    for (auto jt = it->second.begin(); jt != it->second.end(); ++jt) {
      ProbeStat probe_stat;
      ItemStatToProbeStat(jt->second, item_stat_info_, &probe_stat);
      probe_action_stat_[it->first][jt->first] = probe_stat;
    }
  }
}

void ProbeStatManager::ItemStatToProbeStat(const std::vector<uint64>& item_list,
                                           const std::map<uint64, ItemStat>& item_stat,
                                           ProbeStat* probe_stat) {
  probe_stat->ResetUnHappen();

  std::set<int> refresh_interval_set;
  for (size_t i = 0; i < item_list.size(); ++i) {
    auto it = item_stat.find(item_list[i]);
    if (it == item_stat.end()) continue;
    const ItemStat& stat = it->second;
    refresh_interval_set.insert(stat.refresh_interval);
    probe_stat->last_show_refresh_interval = std::min(probe_stat->last_show_refresh_interval,
                                                      stat.refresh_interval);
    probe_stat->last_show_minute_delta = std::min(probe_stat->last_show_minute_delta,
                                                  stat.show_minute_delta);
    probe_stat->total_show_num++;
    if (stat.is_today) {
      probe_stat->today_show_num++;
    }

    if (stat.is_clicked) {
      probe_stat->last_click_refresh_interval = std::min(probe_stat->last_click_refresh_interval,
                                                         stat.refresh_interval);
      probe_stat->last_click_minute_delta = std::min(probe_stat->last_click_minute_delta,
                                                     stat.click_minute_delta);
      probe_stat->total_click_num++;
      if (stat.is_today) {
        probe_stat->today_click_num++;
      }
    }
  }

  probe_stat->last_continuous_refresh_num = 0;
  auto jt = refresh_interval_set.begin();
  for (auto it = refresh_interval_set.begin(); it != refresh_interval_set.end(); ++it) {
    int diff = 0;
    if (it != refresh_interval_set.begin()) {
      diff = *it - *jt;
      ++jt;
    }
    if (diff <= 1) {
      probe_stat->last_continuous_refresh_num++;
    } else {
      break;
    }
  }

  if (probe_stat->today_show_num > 0) {
    probe_stat->today_ctr = std::min(1.0f, static_cast<float>(probe_stat->today_click_num) /
                                     static_cast<float>(probe_stat->today_show_num));
  }

  if (probe_stat->total_show_num > 0) {
    probe_stat->total_ctr = std::min(1.0f, static_cast<float>(probe_stat->total_click_num) /
                                     static_cast<float>(probe_stat->total_show_num));
  }
}
} // namespace leaf
} // namespace reco
