#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace reco {
namespace leafserver {

struct RecoRequest;
class ProbeStrategyManager;

// 一个探索由 type、action、detail 三元组组成
struct ProbeInfo {
  reco::ProbeType probe_type;
  reco::ProbeAction probe_action;
  std::string probe_detail;

  ProbeInfo() {
    probe_type = reco::kNoProbeType;
    probe_action = reco::kNoProbeAction;
    probe_detail = "";
  }

  ~ProbeInfo() {
  }

  ProbeInfo(reco::ProbeType probe_type, reco::ProbeAction probe_action, const std::string& probe_detail) {
    this->probe_type = probe_type;
    this->probe_action = probe_action;
    this->probe_detail = probe_detail;
  }

  std::string ToString() const {
    return reco::ProbeType_Name(probe_type) + "-"
        + reco::ProbeAction_Name(probe_action) + "-"
        + probe_detail;
  }
};

// 策略的基类实现
class ProbeTypeBase {
 public:
  ProbeTypeBase() {}
  virtual ~ProbeTypeBase() {}

  // 汇报这个类所属的探索类型
  virtual reco::ProbeType get_probe_type() = 0;

  // 汇报对于这个用户的这个请求，准备做什么探索动作
  // probe_manager 管理类的指针，有时候需要通过管理类来获得一些全局信息，比如 quota
  // action_num 允许的最大 action 数量
  virtual bool CheckInProbeActionDetail(const RecoRequest* request,
                                        const ProbeStrategyManager* probe_manager,
                                        int action_num,
                                        std::vector<ProbeInfo>* strategy_action) = 0;
};

// 行为的基类实现
class ProbeActionBase {
 public:
  ProbeActionBase() {}
  virtual ~ProbeActionBase() {}

  // 汇报这个类所属的探索行动
  virtual reco::ProbeAction get_probe_action() = 0;

  // 获得探索的推荐结果
  // 框架传入的 result_num 可能会很小，1-2 左右，因此要求实现类自带缓存
  virtual bool GetProbeRecoByActionDetail(const RecoRequest* request,
                                          const reco::NewsIndex* news_index,
                                          const ProbeStrategyManager* probe_manager,
                                          const ProbeInfo& probe_info,
                                          int result_num,
                                          std::vector<reco::ItemInfo>* reco_item) = 0;
};
} // namespace leaf
} // namespace reco
