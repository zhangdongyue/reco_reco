#include <unordered_set>
#include <stdlib.h>
#include <iostream>

#include "base/testing/gtest.h"
#include "base/time/timestamp.h"
#include "base/time/time.h"
#include "base/random/pseudo_random.h"

#include "reco/serv/reco_leaf/strategy/probe/probe_stat_manager.h"

namespace reco {
namespace leafserver {
class ProbeStatManagerTest : public testing::Test {
public:
  void SetUp() {
    manager = new ProbeStatManager();
    InitUserInfoCase1();
  }

  void InitUserInfoCase1() {
    base::Time yestoday = base::Time::Now() - base::TimeDelta::FromDays(1);
    reco_1_timestamp = yestoday.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
    reco_2_timestamp = base::GetTimestamp();

    user_info_case1.mutable_identity();

    // show: 5 item:
    // reco 1: 3 item, 2 sttg item(type 0 action 0 cate1, type 0 action 1 tag1), 1 common item
    // reco 2: 2 item, 1 sttg item(type 0 action 1 tag2), 1 common item
    //
    ViewClickItem* item;
    // show item 1, reco_1
    item = user_info_case1.add_shown_history();
    item->set_item_id(1);
    item->set_probe_type(0);
    item->set_probe_action(0);
    item->set_probe_detail("tag1");
    item->set_item_type(kNews);
    item->set_view_timestamp(reco_1_timestamp);
    // show item 2, reco_1
    item = user_info_case1.add_shown_history();
    item->set_item_id(2);
    item->set_probe_type(0);
    item->set_probe_action(1);
    item->set_probe_detail("category1");
    item->set_item_type(kNews);
    item->set_view_timestamp(reco_1_timestamp);
    // show item 3, reco_1
    item = user_info_case1.add_shown_history();
    item->set_item_id(3);
    item->set_item_type(kNews);
    item->set_view_timestamp(reco_1_timestamp);
    // show item 4, reco_2
    item = user_info_case1.add_shown_history();
    item->set_item_id(4);
    item->set_probe_type(0);
    item->set_probe_action(0);
    item->set_probe_detail("tag2");
    item->set_item_type(kNews);
    item->set_view_timestamp(reco_2_timestamp);
    // show item 5, reco_2
    item = user_info_case1.add_shown_history();
    item->set_item_id(5);
    item->set_item_type(kNews);
    item->set_view_timestamp(reco_2_timestamp);

    // click: 3 item:
    // reco 1: 2 click, 1 sttg item(type 0 action 0 cate1), 1 common item
    // reco 2: 1 click, 1 sttg item(type 0 action 1 tag2)
    //
    // click item 1, reco_1
    item = user_info_case1.add_recent_click();
    item->set_item_id(1);
    item->set_click_timestamp(reco_2_timestamp);

    // click item 3, reco_1
    item = user_info_case1.add_recent_click();
    item->set_item_id(3);
    item->set_click_timestamp(reco_2_timestamp);

    // click item 4, reco_2
    item = user_info_case1.add_recent_click();
    item->set_item_id(4);
    item->set_click_timestamp(reco_2_timestamp);
  }

  void TearDown() {
    delete manager;
  }

  ProbeStatManager* manager;
  UserInfo user_info_case1;
  UserInfo user_info_case2;
  int64 reco_1_timestamp;
  int64 reco_2_timestamp;
};

TEST_F(ProbeStatManagerTest, MemberFunctions) {
  // 构造第几刷的 case， 测试连续刷新次数的计算
  struct {
    int refresh[8];
    int continuous_num;
  } cases [] = {
    {{1, 1, 2, 3, 4, 4, 4, 5}, 5},
    {{2, 8, 5, 2, 2, 8, 1, 5}, 2},
    {{8, 8, 1, 1, 1, 1, 1, 1}, 1},
    {{8, 7, 1, 1, 2, 3, 5, 6}, 3},
    {{5, 8, 6, 10, 11, 12, 20, 21}, 2},
  };
  int case_num = ARRAYSIZE_UNSAFE(cases);
  for (int i = 0; i < case_num; ++i) {
    int refresh_num = ARRAYSIZE_UNSAFE(cases[i].refresh);
    std::vector<uint64> item_list(refresh_num);
    std::map<uint64, ProbeStatManager::ItemStat> item_stat;
    for (int j = 0; j < refresh_num; ++j) {
      item_list[j] = j;
      ProbeStatManager::ItemStat& stat = item_stat[j];
      stat.item_id = j;
      stat.refresh_interval = cases[i].refresh[j];
      // stat.minute_delta = 0;
      // stat.day_delta = 0;
      // stat.is_today = true;
      // stat.is_clicked = true;
    }
    ProbeStat probe_stat;
    manager->ItemStatToProbeStat(item_list, item_stat, &probe_stat);
    ASSERT_EQ(probe_stat.last_continuous_refresh_num, cases[i].continuous_num);
  }
}

TEST_F(ProbeStatManagerTest, Case1_ClassMembers) {
  manager->Reset();
  manager->DoStat(&user_info_case1);

  // time is importance, so test it first
  std::string now_time_str;
  manager->now_time_.ToStringInSeconds(&now_time_str);
  std::string midnight_time_str;
  manager->midnight_time_.ToStringInSeconds(&midnight_time_str);
  ASSERT_STREQ(now_time_str.substr(0, 10).c_str(),
               midnight_time_str.substr(0, 10).c_str());
  ASSERT_TRUE(base::EndsWith(midnight_time_str, "00:00:00", true));

  // test refresh interval
  ASSERT_EQ(manager->refresh_interval_.size(), 2u);
  ASSERT_EQ(manager->refresh_interval_[reco_1_timestamp], 2);
  ASSERT_EQ(manager->refresh_interval_[reco_2_timestamp], 1); // reco_2 是最近的 1刷

  // test item stat
  // item 1 (type 0 action 0 tag1), reco_1, clicked
  // item 2 (type 0 action 1 category1), reco_1, not clicked
  // item 4 (type 0 action 0 tag2), reco_2, clicked
  ASSERT_EQ(manager->item_stat_info_.size(), 3u);
  ASSERT_EQ(manager->item_stat_info_[1].item_id, 1u);
  ASSERT_EQ(manager->item_stat_info_[1].refresh_interval, 2);
  ASSERT_EQ(manager->item_stat_info_[1].is_clicked, true);
  ASSERT_EQ(manager->item_stat_info_[1].is_today, false);
  ASSERT_EQ(manager->item_stat_info_[2].item_id, 2u);
  ASSERT_EQ(manager->item_stat_info_[2].refresh_interval, 2);
  ASSERT_EQ(manager->item_stat_info_[2].is_clicked, false);
  ASSERT_EQ(manager->item_stat_info_[2].is_today, false);
  ASSERT_EQ(manager->item_stat_info_[4].item_id, 4u);
  ASSERT_EQ(manager->item_stat_info_[4].refresh_interval, 1);
  ASSERT_EQ(manager->item_stat_info_[4].is_clicked, true);
  ASSERT_EQ(manager->item_stat_info_[4].is_today, true);

  ASSERT_STREQ(manager->GetProbeTypeStat(static_cast<reco::ProbeType>(0)).ToString().c_str(),
               "last_show_refresh_interval=1,last_show_minute_delta=0,last_continuous_refresh_num=2,"
               "today_show_num=1,total_show_num=3,last_click_refresh_interval=1,last_click_minute_delta=0,"
               "today_click_num=1,total_click_num=2,today_ctr=1.000,total_ctr=0.667");
  ASSERT_STREQ(manager->GetProbeActionStat(static_cast<reco::ProbeAction>(0), "tag1").ToString().c_str(),
               "last_show_refresh_interval=2,last_show_minute_delta=1440,last_continuous_refresh_num=1,"
               "today_show_num=0,total_show_num=1,last_click_refresh_interval=2,last_click_minute_delta=0,"
               "today_click_num=0,total_click_num=1,today_ctr=0.000,total_ctr=1.000");
  ASSERT_STREQ(manager->GetProbeActionStat(static_cast<reco::ProbeAction>(0), "tag2").ToString().c_str(),
               "last_show_refresh_interval=1,last_show_minute_delta=0,last_continuous_refresh_num=1,"
               "today_show_num=1,total_show_num=1,last_click_refresh_interval=1,last_click_minute_delta=0,"
               "today_click_num=1,total_click_num=1,today_ctr=1.000,total_ctr=1.000");
  ASSERT_STREQ(manager->GetProbeActionStat(static_cast<reco::ProbeAction>(1), "category1").ToString().c_str(),
               "last_show_refresh_interval=2,last_show_minute_delta=1440,last_continuous_refresh_num=1,"
               "today_show_num=0,total_show_num=1,last_click_refresh_interval=10000,last_click_minute_delta=10000,"  // NOLINT
               "today_click_num=0,total_click_num=0,today_ctr=0.000,total_ctr=0.000");
  // EXPECT_NEAR(val1, val2, abs_error)
  // EXPECT_FLOAT_EQ(val1, val2, abs_error)
  //  stat_info.DoStat(&user_info);
}

TEST_F(ProbeStatManagerTest, RandomData) {
  base::Time old_day = base::Time::Now() - base::TimeDelta::FromDays(10);
  base::Time now_day = base::Time::Now();
  int64 old_timestamp = old_day.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int64 now_timestamp = now_day.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int64 delta_timestamp = now_timestamp - old_timestamp;
  base::PseudoRandom random;
  for (int round = 0; round < 10; ++round) {
    // 跑 10 轮。每轮构造随机 case
    UserInfo user_info;

    // 展现 1000
    for (int i = 0; i < 1000; ++i) {
      ViewClickItem* item;
      // show item 1, reco_1
      item = user_info.add_shown_history();
      item->set_item_id(random.GetInt(0, 1000));
      item->set_probe_type(0);
      item->set_probe_action(0);
      item->set_probe_detail(random.GetString(1));
      item->set_item_type(kNews);
      item->set_view_timestamp(old_timestamp + random.GetUint64LT(delta_timestamp));
    }

    // 点击 1000
    for (int i = 0; i < 100; ++i) {
      ViewClickItem* item;
      item = user_info.add_recent_click();
      item->set_item_id(random.GetInt(0, 1000));
      item->set_click_timestamp(old_timestamp + random.GetUint64LT(delta_timestamp));
    }

    manager->Reset();
    manager->DoStat(&user_info);
    ASSERT_STRNE(manager->GetProbeTypeStat(static_cast<reco::ProbeType>(0)).ToString().c_str(),
                 ProbeStat::GetStatUnHappen().ToString().c_str());
  }
}

TEST(a, b) {
  UserInfo user;
  user.mutable_identity()->set_app_token("xx");
  user.mutable_identity()->set_user_id(1);
  for (int i = 0; i < 10000; ++i) {
    ViewClickItem* item;
    // show item 1, reco_1
    item = user.add_shown_history();
    item->set_item_id(1);
    item->set_item_type(kNews);
    item->set_view_timestamp(0);
    item->set_probe_type(0);
  }
  LOG(ERROR) << user.ByteSize();
}
}  // namespace leafserver
}  // namespace reco

