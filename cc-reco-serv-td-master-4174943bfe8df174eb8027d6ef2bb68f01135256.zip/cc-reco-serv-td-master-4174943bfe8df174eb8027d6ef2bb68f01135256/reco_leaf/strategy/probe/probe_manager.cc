#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_stat_manager.h"

#include "reco/serv/reco_leaf/strategy/probe/type/query_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/type/video_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/type/poi_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/type/device_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/type/taobao_query_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/type/earnings_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/type/tag_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/type/ucb_log_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/type/manual_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/type/novel_probe.h"

#include "reco/serv/reco_leaf/strategy/probe/action/search_query.h"
#include "reco/serv/reco_leaf/strategy/probe/action/search_poi.h"
#include "reco/serv/reco_leaf/strategy/probe/action/structured_search.h"
#include "reco/serv/reco_leaf/strategy/probe/action/guess_tag.h"
#include "reco/serv/reco_leaf/strategy/probe/action/view_title.h"
#include "reco/serv/reco_leaf/strategy/probe/action/manual_ctrl.h"
#include "reco/serv/reco_leaf/strategy/probe/action/video_tag.h"
#include "reco/serv/reco_leaf/strategy/probe/action/news_tag_to_video.h"
#include "reco/serv/reco_leaf/strategy/probe/action/novel_update_notice.h"

#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/reco_index/item_info.h"

namespace reco {
namespace leafserver {
DEFINE_bool(do_manual_probe, true, "运营卡片探索开关");
DEFINE_bool(do_novel_probe, true, "小说更新提醒探索开关");
DEFINE_bool(do_query_probe, true, "query探索开关");
DEFINE_bool(do_tag_probe, true, "标签探索开关");
DEFINE_bool(do_poi_probe, true, "poi探索开关");
DEFINE_bool(do_device_probe, true, "设备探索开关");
DEFINE_bool(do_taobao_query_probe, true, "淘宝query探索开关");
DEFINE_bool(do_video_probe, true, "视频探索开关");
DEFINE_bool(do_ucb_log_probe, true, "浏览历史探索开关");

ProbeStrategyManager::ProbeStrategyManager(const reco::NewsIndex* news_index) {
  news_index_ = news_index;

  probe_stat_manager_ = new ProbeStatManager();

  // 提交策略类
  // std::vector<ProbeTypeBase*> types;
  // 在 types 里 push back 即可

  // 原有的 map 结构会导致 probe_type 优先级失效,
  // 此处按 probe_type 的枚举值大小顺序添加进 vector, 效果和之前使用 map 一样
  // 如需调整优先级请自行操作
  if (FLAGS_do_manual_probe) strategy_types_.push_back(new ManualProbe());
  // if (FLAGS_do_novel_probe) strategy_types_.push_back(new NovelProbe());
  // if (FLAGS_do_query_probe) strategy_types_.push_back(new QueryProbe());
  if (FLAGS_do_tag_probe) strategy_types_.push_back(new TagProbe());
  if (FLAGS_do_poi_probe) strategy_types_.push_back(new PoiProbe());
  // strategy_types_.push_back(new EarningsProbe());
  if (FLAGS_do_taobao_query_probe) strategy_types_.push_back(new TaobaoQueryProbe());
  // if (FLAGS_do_video_probe) strategy_types_.push_back(new VideoProbe());
  if (FLAGS_do_ucb_log_probe) strategy_types_.push_back(new UcbLogProbe());
  if (FLAGS_do_device_probe) strategy_types_.push_back(new DeviceProbe());

  for (auto it = strategy_types_.begin(); it != strategy_types_.end(); ++it) {
    // 给每个策略设置默认的最大返回条数
    max_result_num_per_strategy_[(*it)->get_probe_type()] = kDefaultMaxResultNumPerStrategy;
  }
  // 设置某个策略单独的最大返回条数
  // 视频探索出两条
  max_result_num_per_strategy_[reco::kVideoProbe] = 2;

  // 提交行为类
  std::vector<ProbeActionBase*> actions;
  // 在 actions 里 push back 即可
  actions.push_back(new ManualCtrl());
  // actions.push_back(new VideoTag());
  // actions.push_back(new NewsTagToVideo());
  actions.push_back(new SearchPoi());
  actions.push_back(new SearchQuery());
  actions.push_back(new ViewTitle());
  // actions.push_back(new NovelUpdateNotice());
  // actions.push_back(new StructuredSearch());
  actions.push_back(new GuessTag());

  for (auto it = actions.begin(); it != actions.end(); ++it) {
    strategy_actions_[(*it)->get_probe_action()] = *it;
  }

  // 设置配额阈值
  SetProbeQuota();

  candidates_extor_ = new CandidatesExtractor(news_index_);
}

ProbeStrategyManager::~ProbeStrategyManager() {
  if (probe_stat_manager_) {
    delete probe_stat_manager_;
    probe_stat_manager_ = NULL;
  }

  for (auto it = strategy_types_.begin(); it != strategy_types_.end(); ++it) {
    delete *it;
  }

  for (auto it = strategy_actions_.begin(); it != strategy_actions_.end(); ++it) {
    delete it->second;
  }

  if (candidates_extor_) {
    delete candidates_extor_;
    candidates_extor_ = NULL;
  }
}

void ProbeStrategyManager::SetProbeQuota() {
  SetDefaultQuota();

  // 具体策略可以设置除 default quota 外自己的设置
  // probe_type_quota_.insert(std::make_pair(xx, xx));
  // probe_action_quota_.insert(std::make_pair(xx, xx));

  ProbeStat total_quota;
  ProbeStat single_quota;

  /*
  // 小说更新提醒 quota
  total_quota = default_quota_;
  total_quota.last_show_refresh_interval = 1000; // 刷新间隔失效
  //total_quota.last_show_refresh_interval = 0; // 刷新间隔失效
  total_quota.last_continuous_refresh_num = 10;
  total_quota.today_show_num = 5;
  total_quota.today_ctr = 0.2f;
  probe_type_quota_.insert(std::make_pair(reco::kNovelProbe, total_quota));
  single_quota = total_quota;
  probe_action_quota_.insert(std::make_pair(reco::kFollowNovel, single_quota));
  */

  /*
  // query 探索整体 quota
  total_quota = default_quota_;
  total_quota.last_show_refresh_interval = 2;
  total_quota.last_continuous_refresh_num = 2;
  total_quota.today_show_num = 30;
  total_quota.today_ctr = 0.16f;
  probe_type_quota_.insert(std::make_pair(reco::kQueryProbe, total_quota));
  probe_type_quota_.insert(std::make_pair(reco::kTaobaoQueryProbe, total_quota));

  // 单个 query 探索 quota
  single_quota = default_quota_;
  single_quota.last_show_refresh_interval = 5;
  // 尽量轮着出
  single_quota.last_continuous_refresh_num = 2;
  single_quota.today_show_num = 10;
  single_quota.today_ctr = 0.16f;
  probe_action_quota_.insert(std::make_pair(reco::kSearchQuery, single_quota));
  */

  // 机型探索 quota
  total_quota = default_quota_;
  total_quota.last_show_refresh_interval = 5;
  total_quota.last_continuous_refresh_num = 1;
  total_quota.today_show_num = 5;
  total_quota.today_ctr = 0.15f;
  probe_type_quota_.insert(std::make_pair(reco::kDeviceProbe, total_quota));

  // 铜矿日志探索整体 quota
  total_quota = default_quota_;
  total_quota.last_show_refresh_interval = 2;
  total_quota.last_continuous_refresh_num = 2;
  total_quota.today_show_num = 20;
  total_quota.today_ctr = 0.15f;
  probe_type_quota_.insert(std::make_pair(reco::kUcbLogProbe, total_quota));

  // 单个铜矿日志探索 quota
  single_quota = default_quota_;
  single_quota.last_show_refresh_interval = 5;
  single_quota.last_continuous_refresh_num = 2;
  single_quota.today_show_num = 10;
  single_quota.today_ctr = 0.15f;
  probe_action_quota_.insert(std::make_pair(reco::kViewTitle, single_quota));

  // 视频标签探索整体 quota
  ProbeStat video_tag_total_quota = default_quota_;
  video_tag_total_quota.last_show_minute_delta = 30;
  video_tag_total_quota.last_continuous_refresh_num = 10;
  video_tag_total_quota.today_show_num = 200;
  probe_type_quota_.insert(std::make_pair(reco::kVideoProbe, video_tag_total_quota));

  // 某个视频标签探索 quota
  ProbeStat video_tag_single_quota = default_quota_;
  video_tag_single_quota = default_quota_;
  video_tag_single_quota.last_show_minute_delta = 30;
  video_tag_single_quota.last_continuous_refresh_num = 10;
  video_tag_single_quota.today_ctr = 0.1f;
  video_tag_single_quota.today_show_num = 50;
  probe_action_quota_.insert(std::make_pair(reco::kVideoTag, video_tag_single_quota));

  // 临时为校园推广的 poi probe 设置一个较大的 quota
  ProbeStat quota = default_quota_;
  quota.last_continuous_refresh_num = 5;
  probe_type_quota_.insert(std::make_pair(reco::kPoiProbe, quota));

  // 财报每次都只能刷 1 屏
  quota = default_quota_;
  quota.last_continuous_refresh_num = 1;
  quota.today_ctr = 0.00f;
  probe_type_quota_.insert(std::make_pair(reco::kEarningsProbe, quota));

  // 标签探索每次刷新换 tag , 分别对 type action 探索设置 ctr
  ProbeStat tag_quota = default_quota_;
  tag_quota.last_continuous_refresh_num = 1;
  tag_quota.today_ctr = 0.49f;
  tag_quota.today_show_num = 2;
  tag_quota.last_show_refresh_interval = 12;
  probe_action_quota_.insert(std::make_pair(reco::kSearchTag, tag_quota));

  tag_quota.last_continuous_refresh_num = 2;
  tag_quota.today_ctr = 0.22f;
  tag_quota.today_show_num = 5;
  tag_quota.last_show_refresh_interval = 10;
  probe_type_quota_.insert(std::make_pair(reco::kTagProbe, tag_quota));

  // 运营人工非置顶控制
  ProbeStat manual_quota = default_quota_;
  manual_quota.today_ctr = -1;
  probe_type_quota_.insert(std::make_pair(reco::kManualProbe, manual_quota));

  manual_quota.last_continuous_refresh_num = 0;
  manual_quota.today_show_num = -1;
  manual_quota.today_ctr = 1.2f;
  // 设置的比较大是为了让此规则在 manual probe 中近似失效
  manual_quota.last_show_refresh_interval = 200;
  probe_action_quota_.insert(std::make_pair(reco::kManualCtrl, manual_quota));
}

void ProbeStrategyManager::SetQuotaPersonalized(const RecoRequest* reco_request) {
  // 非常重要，一定要清理，要不然可能是上个人的 quota
  personal_probe_action_quota_.clear();
  if (!reco_request || !reco_request->user_feas) return;
  // 对视频的 probe 个性化设置 quota
  if (reco_request->user_info && reco_request->user_info->has_profile() &&
      reco_request->user_info->profile().has_video_read_hour_feavec()) {
    base::Time now_time = base::Time::Now();
    base::Time::Exploded exploded;
    now_time.LocalExplode(&exploded);
    double total_weight = 0.0;
    std::map<std::string, double> hour_weight;
    auto &read_hour_feavec = reco_request->user_info->profile().video_read_hour_feavec();
    for (int i = 0; i < read_hour_feavec.feature_size(); ++i) {
      total_weight += read_hour_feavec.feature(i).weight();
      hour_weight[read_hour_feavec.feature(i).literal()] = read_hour_feavec.feature(i).weight();
    }
    double ctr_tune = 0.0;
    auto it = hour_weight.find(base::IntToString(exploded.hour));
    ProbeStat personal_video_tag_quota = probe_action_quota_[reco::kVideoTag];
    if (it != hour_weight.end() && total_weight > 0) {
      ctr_tune = it->second / total_weight;
    }
    personal_video_tag_quota.today_ctr *= (1.0 - ctr_tune);
    if (!(reco_request->user_param_info.is_wifi)) {
      personal_video_tag_quota.today_ctr *= 1.2;
    }
    personal_probe_action_quota_[reco::kVideoTag] = personal_video_tag_quota;
    VLOG(1) << "after today_ctr: " << personal_video_tag_quota.today_ctr;
  }
}

void ProbeStrategyManager::SetDefaultQuota() {
  // 给默认配额一些合理的设置。以下值不要随便改
  //
  // 最近展现间隔大于该值，说明是较早之前的投放，可以进行尝试
  default_quota_.last_show_refresh_interval = 5;
  default_quota_.last_show_minute_delta = 120;

  // 小于连续刷新次数，说明最近的一次投放还不至于产生刷屏的感觉，可以继续
  // 这个值会和 last_show_refresh_interval 一起配合控制
  // 因为一旦投放以后 last_show_refresh_interval 就会为 1
  // 需要通过这个值抑制持续投放
  default_quota_.last_continuous_refresh_num = 2;

  // 小于展现数，可以继续尝试
  default_quota_.today_show_num = 10;
  default_quota_.total_show_num = ProbeStat::kLargeNum;


  // 最近点击间隔小于该值，说明最近发生了正向反馈，可以继续
  default_quota_.last_click_refresh_interval = 3;
  default_quota_.last_click_minute_delta = 10;

  // 大于点击数，可以继续尝试
  default_quota_.today_click_num = 3;
  default_quota_.total_click_num = 10;

  // 大于 ctr，可以继续尝试
  default_quota_.today_ctr = 0.08f;
  default_quota_.total_ctr = 0.05f;
}

#define LT(x) (stat.x < quota.x)
#define GT(x) (stat.x > quota.x)
bool ProbeStrategyManager::HasQuota(const ProbeStat& stat, const ProbeStat& quota) const {
  // NOTE: 主要梳理一些一定能出/一定不能出的场景。中间地带分不清楚统一干掉即可
  // 不能作为排序比较函数
  if (GT(last_show_refresh_interval)) {
    VLOG(1) << ">last_show_refresh_interval return true";
    return true;
  }

  // 如果已经大于今天的展现数，通过 ctr 来判断是否再出该探索推荐
  if (LT(last_continuous_refresh_num) && LT(today_show_num)) {
    VLOG(1) << "<last_continuous_refresh_num && <today_show_num return true";
    return true;
  }

  if (GT(today_ctr)) {
    VLOG(1) << ">today_ctr return true";
    return true;
  }

  if ((stat.total_show_num < 2 || stat.total_click_num > 0)
      && stat.today_show_num < 1) {
    VLOG(1) << "total show num < 2, total_click_num > 0, today show num < 1";
    return true;
  }

  if (GT(last_continuous_refresh_num)
      && GT(last_click_refresh_interval)) {
    VLOG(1) << ">last_continuous_fresh_num && >last_click_refresh_interval return false";
    return false;
  }

  if (GT(today_show_num) && LT(today_ctr)) {
    VLOG(1) << ">today_show_num && <today_ctr return false";
    return false;
  }

  return false;
}

bool ProbeStrategyManager::ProbeCanTry(const ProbeInfo& probe_info) const {
  if (!HasQuota(probe_stat_manager_->GetProbeTypeStat(probe_info.probe_type),
                GetProbeTypeQuota(probe_info.probe_type))) {
    VLOG(1) << "type " << probe_info.probe_type << " has no quota";
    return false;
  }

  if (!HasQuota(probe_stat_manager_->GetProbeActionStat(probe_info.probe_action, probe_info.probe_detail),
                GetProbeActionQuota(probe_info.probe_action))) {
    VLOG(1) << "action " << probe_info.probe_action << "," << probe_info.probe_detail << " has no quota";
    return false;
  }
  return true;
}

static std::string NullResultKey(const RecoRequest* reco_request, const ProbeInfo& probe_info) {
  return "NullRes" + base::Uint64ToString(reco_request->user_info->identity().user_id())
      + probe_info.ToString();
}

bool ProbeStrategyManager::ProbeHasResult(const RecoRequest* reco_request,
                                          const ProbeInfo& probe_info) const {
  std::string result;
  if (!LeafCache::GetCachedReco(NullResultKey(reco_request, probe_info), &result)) {
    return true;
  } else {
    return false;
  }
}

void ProbeStrategyManager::SetNullResultCache(const RecoRequest* reco_request, const ProbeInfo& probe_info) {
  LeafCache::SetCachedReco(NullResultKey(reco_request, probe_info), "0");
}

void ProbeStrategyManager::GetRecoResult(const NewsIndex* news_index,
                                         const reco::ProbeType& probe_type,
                                         const RecoRequest* reco_request,
                                         int result_num,
                                         std::vector<ItemInfo>* reco_result) {
  std::string cost_detail;
  serving_base::Timer timer;
  timer.Start();

  reco_result->clear();

  int64 cur_timer_stop = timer.Stop();
  int64 last_timer_stop = cur_timer_stop;
  base::StringAppendF(&cost_detail, "init:%ld", cur_timer_stop);

  std::shared_ptr<ProbeTypeBase> strategy;

  if (probe_type == reco::kVideoProbe) {
    // 在函数最后有 delete
    strategy = std::make_shared<VideoProbe>();
  }

  // 收集不同策略想做的行为
  std::vector<ProbeInfo> all_actions;

  std::vector<ProbeInfo> actions;
  if (strategy) {
    strategy->CheckInProbeActionDetail(reco_request_, this, kMaxActionPerStrategy, &actions);
    if (!actions.empty()) {
      all_actions.insert(all_actions.end(), actions.begin(), actions.end());
      VLOG(1) << "uid=" << reco_request->user_info->identity().user_id()
              << ", probe type " << ProbeType_Name(strategy->get_probe_type())
              << " returns " << actions.size() << " actions";
    }
  }

  cur_timer_stop = timer.Stop();
  base::StringAppendF(&cost_detail, ",collect:%ld", cur_timer_stop - last_timer_stop);

  serving_base::Timer timer_action;
  std::vector<reco::ItemInfo> reco_item;
  for (size_t i = 0; i < all_actions.size(); ++i) {
    timer_action.Start();

    if ((int)reco_result->size() >= result_num) {
      break;
    }

    const ProbeInfo& info = all_actions[i];

    // 此时要重新判断下，因为会有 chosen probe 加入竞争
    if (!ProbeCanTry(info)) {
      VLOG(1) << "probe action " << reco::ProbeAction_Name(info.probe_action) << " can not try now";
      continue;
    }
    if (!ProbeHasResult(reco_request_, info)) {
      VLOG(1) << "probe action " << reco::ProbeAction_Name(info.probe_action) << " already has null resull";
      continue;
    }

    std::shared_ptr<ProbeActionBase> probe_action;
    if (info.probe_action == reco::kVideoTag) {
      probe_action = std::make_shared<VideoTag>();
    } else if (info.probe_action == reco::kNewsTagToVideo) {
      probe_action = std::make_shared<NewsTagToVideo>();
    }
    // 由于进场退场需要及时，此处从各个 action 获取的结果条数会控制得很少
    // 需要在 action 内部做好缓存
    if (!probe_action->GetProbeRecoByActionDetail(
            reco_request_, news_index, this, info, result_num, &reco_item)) {
      VLOG(1) << "probe action " << reco::ProbeAction_Name(info.probe_action) << " right now has null resull";
      // 记录对这个用户这个 probe 不会产生结果
      SetNullResultCache(reco_request_, info);
      continue;
    }
    // TODO : temp
    for (size_t j = 0; j < reco_item.size(); ++j) {
      if ((int)reco_result->size() >= result_num) {
        break;
      }
      if (NewsFilter::IsDislikeFiltered(reco_request_, reco_item[j])) {
        continue;
      }
      reco_result->push_back(reco_item[j]);
    }
    probe_stat_manager_->IncreStatByChosenProbe(info);

    for (size_t j = 0; j < reco_item.size(); ++j) {
      uint64 item_id = reco_item[j].item_id;
      if (item_probe_info_.find(item_id) != item_probe_info_.end()) {
        // 前面已经有策略推过了，应该算他们的
        continue;
      }
      item_probe_info_.insert(std::make_pair(item_id, info));
      VLOG(2) << "user " << reco_request->user_info->identity().user_id() << " "
              << info.ToString() << " returns " << reco_item[j].item_id
              << " , ctr=" << reco_item[j].ctr;
    }
    base::StringAppendF(&cost_detail, ",%s:%ld",
                        reco::ProbeAction_Name(info.probe_action).c_str(), timer_action.Stop());
  }

  for (size_t i = 0; i < reco_result->size(); ++i) {
    reco_result->at(i).strategy_type = reco::kProbe;
    reco_result->at(i).strategy_branch = reco::kProbeBranch;
  }

  LOG(INFO) << "uid:" << reco_request->user_info->identity().user_id()
            << ", probe:" << probe_type
            << ", cost:{" << cost_detail << "}"
            << ", cost:" << timer.Stop();
}

bool ProbeStrategyManager::GetRecoResult(const NewsIndex* news_index,
                                         const RecoRequest* reco_request,
                                         int result_num,
                                         std::vector<ItemInfo>* reco_result) {
  std::string cost_detail;
  serving_base::Timer timer;
  timer.Start();

  // 个性化设置 probe quota
  SetQuotaPersonalized(reco_request);
  reco_result->clear();
  if (strategy_types_.empty()) return true;

  reco_request_ = reco_request;
  const reco::user::UserInfo* user_info = reco_request_->user_info;

  // 首先统计用户的历史信息
  probe_stat_manager_->Reset();
  probe_stat_manager_->DoStat(user_info);

  // 清空选择的 probe，否则会影响配额计算
  chosen_probes_.clear();
  item_probe_info_.clear();

  int64 cur_timer_stop = timer.Stop();
  int64 last_timer_stop = cur_timer_stop;
  base::StringAppendF(&cost_detail, "init:%ld", cur_timer_stop);

  // 收集不同策略想做的行为
  std::vector<ProbeInfo> all_actions;
  for (auto it = strategy_types_.begin(); it != strategy_types_.end(); it++) {
    ProbeTypeBase* strategy = *it;

    std::vector<ProbeInfo> actions;
    if (!strategy->CheckInProbeActionDetail(reco_request_, this, kMaxActionPerStrategy, &actions)) {
      continue;
    }
    // TODO 不同策略提交的行为，计算优先级
    // 目前是在构造函数里在 strategy_types_ 中先占坑的策略提交的行为优先级更高
    // 还算比较合理，如果你认为你的策略靠谱，就往前放，你的策略投放以后，
    // 如果用户买单，你就可以继续投放；否则就被退场机制干掉，轮到别人上
    if (!actions.empty()) {
      all_actions.insert(all_actions.end(), actions.begin(), actions.end());
      VLOG(1) << "uid=" << reco_request->user_info->identity().user_id()
              << ", probe type " << ProbeType_Name(strategy->get_probe_type())
              << " returns " << actions.size() << " actions";
    }
  }

  std::map<reco::ProbeType, int> result_num_per_strategy;
  for (auto it = strategy_types_.begin(); it != strategy_types_.end(); ++it) {
    result_num_per_strategy[(*it)->get_probe_type()] = 0;
  }

  cur_timer_stop = timer.Stop();
  base::StringAppendF(&cost_detail, ",collect:%ld", cur_timer_stop - last_timer_stop);

  for (size_t i = 0; i < all_actions.size(); ++i) {
    serving_base::Timer timer_action;
    timer_action.Start();

    if ((int)reco_result->size() >= result_num) {
      break;
    }

    const ProbeInfo& info = all_actions[i];
    auto it = strategy_actions_.find(info.probe_action);
    if (it == strategy_actions_.end()) {
      VLOG(1) << "probe action " << reco::ProbeAction_Name(info.probe_action)
              << " not register ";
      continue;
    }

    int max_result_num = max_result_num_per_strategy_[info.probe_type];
    if (max_result_num <= result_num_per_strategy[info.probe_type]) {
      continue;
    }

    // 此时要重新判断下，因为会有 chosen probe 加入竞争
    if (!ProbeCanTry(info)) {
      VLOG(1) << "probe action " << reco::ProbeAction_Name(info.probe_action) << " can not try now";
      continue;
    }
    if (!ProbeHasResult(reco_request_, info)) {
      VLOG(1) << "probe action " << reco::ProbeAction_Name(info.probe_action) << " already has null resull";
      continue;
    }

    std::vector<reco::ItemInfo> reco_item;
    ProbeActionBase* probe_action = it->second;
    // 由于进场退场需要及时，此处从各个 action 获取的结果条数会控制得很少
    // 需要在 action 内部做好缓存
    if (!probe_action->GetProbeRecoByActionDetail(
            reco_request_, news_index, this, info, max_result_num, &reco_item)) {
      VLOG(1) << "probe action " << reco::ProbeAction_Name(info.probe_action) << " right now has null resull";
      // 记录对这个用户这个 probe 不会产生结果
      SetNullResultCache(reco_request_, info);
      continue;
    }

    // TODO : temp
    for (size_t j = 0; j < reco_item.size(); ++j) {
      if (result_num_per_strategy[info.probe_type] >= max_result_num) {
        break;
      }
      reco_result->push_back(reco_item[j]);
      ++result_num_per_strategy[info.probe_type];
    }
    chosen_probes_.push_back(info);
    probe_stat_manager_->IncreStatByChosenProbe(info);

    for (size_t j = 0; j < reco_item.size(); ++j) {
      uint64 item_id = reco_item[j].item_id;
      if (item_probe_info_.find(item_id) != item_probe_info_.end()) {
        // 前面已经有策略推过了，应该算他们的
        continue;
      }
      item_probe_info_.insert(std::make_pair(item_id, info));
      VLOG(2) << "user " << reco_request->user_info->identity().user_id() << " "
              << info.ToString() << " returns " << reco_item[j].item_id
              << " , ctr=" << reco_item[j].ctr;
    }
    base::StringAppendF(&cost_detail, ",%s:%ld",
                        reco::ProbeAction_Name(info.probe_action).c_str(), timer_action.Stop());
  }

  // filter
  std::vector<ItemInfo> candidates(*reco_result);
  reco_result->clear();
  candidates_extor_->BasicRuleFilter(reco_request, kCandidateProbe, candidates, reco_result);

  for (size_t i = 0; i < reco_result->size(); ++i) {
    reco_result->at(i).strategy_type = reco::kProbe;
    reco_result->at(i).strategy_branch = reco::kProbeBranch;
  }

  LOG(INFO) << "uid:" << reco_request->user_info->identity().user_id()
            << ", all_actions_size:" << all_actions.size()
            << ", ret_num:" << reco_result->size() 
            << ", cost:{" << cost_detail << "}"
            << ", cost:" << timer.Stop();
  return true;
}
} // namespace leaf
} // namespace reco
