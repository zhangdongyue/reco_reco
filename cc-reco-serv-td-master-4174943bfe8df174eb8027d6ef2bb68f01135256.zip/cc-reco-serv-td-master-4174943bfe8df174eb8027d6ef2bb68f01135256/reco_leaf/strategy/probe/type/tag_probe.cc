#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/base/common/topn_heap.h"
#include "reco/base/common/topn_priority_queue.h"
#include "base/time/time.h"

#include "reco/serv/reco_leaf/strategy/probe/type/tag_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/serv/reco_leaf/frame/inner/dynamic_dict_container.h"

namespace reco {
namespace leafserver {

TagProbe::TagProbe() {
  news_index_ = LeafDataManager::GetGlobalData()->news_index;
}

TagProbe::~TagProbe() {
}

void TagProbe::GetCachedActions(const std::string& cache_key,
                                std::vector<std::string>* cached_actions,
                                bool* has_cached) {
  CHECK(cached_actions && has_cached);
  cached_actions->clear();
  std::string cache_value;
  if (!LeafCache::GetCachedReco(cache_key, &cache_value)) {
    VLOG(1) << cache_key << " cache missed";
    *has_cached = false;
    return;
  }

  *has_cached = true;
  base::SplitString(cache_value, "|", cached_actions);
  VLOG(1) << cache_key << " return " << cached_actions->size() << " results";
}

void TagProbe::ChooseActionFromTagFea(const RecoRequest* reco_request,
                                      std::vector<std::string>* sorted_tags) {
  const auto& user_info = reco_request->user_info;
  const auto& user_feas = reco_request->user_feas;
  if (user_info == NULL || user_feas == NULL) {
    VLOG(1) << "reco user info/fea null.";
    return;
  }

  if (!user_info->has_profile()) {
    VLOG(1) << "reco user info profile null.";
    return;
  }

  if (!user_info->profile().has_tag_feavec()) {
    VLOG(1) << "reco user tag fea null.";
    return;
  }

  std::string user_id = base::Uint64ToString(user_info->identity().user_id());
  std::string cache_key;
  bool has_cached;
  cache_key = "TagProbeAction" + user_id;
  GetCachedActions(cache_key, sorted_tags, &has_cached);
  if (has_cached) return;

  const auto& subscript_words = user_feas->behavior_fea.subscript_words;
  const auto& tag_feavec = user_info->profile().tag_feavec();
  //const auto& subscript_dict = LeafDataManager::GetGlobalData()->reco_reason_tag_category.GetDict();
  auto ss_dict = DM_GET_DICT(reco::dm::RecoReasonTagDict, DynamicDictContainer::kRecoReasonTagFile_);
  auto subscript_dict = &(ss_dict->reco_reason_tag_category);

  std::vector<std::pair<std::string, double> > sorted_tag_feas;
  std::unordered_set<std::string> tag_feas;
  std::vector<std::string> fields;

  // 由于 action_num 有限，只用 top tag fea 对应的关联标签
  // tag 特征只选取订阅词
  static const int kTopTagNum = 10;
  TopNPriorityQueue<std::string> tag_topn(kTopTagNum);

  for (int i = 0; i < tag_feavec.feature_size(); ++i) {
    const std::string& literal = tag_feavec.feature(i).literal();
    double weight = tag_feavec.feature(i).weight();
    VLOG(1) << "tag fea:" << literal << "," << weight;
    fields.clear();
    base::SplitString(literal, ":", &fields);
    if (fields.size() < 2u) {
      continue;
    }
    std::string& tag = fields[1];
    tag_feas.insert(tag);
    // 过滤掉 tag 权重较低的
    if (weight < 5.0f) {
      continue;
    }
    if (subscript_dict->find(tag) != subscript_dict->end()) {
      tag_topn.add(tag, weight);
      VLOG(1) << "tag fea is subscript:" << tag << "," << weight;
    } else {
      continue;
    }
  }
  sorted_tag_feas.clear();
  tag_topn.get_top_n_ordered(&sorted_tag_feas);

  // 归一化
  double total_weight = 0;
  for (auto it = sorted_tag_feas.begin(); it != sorted_tag_feas.end(); ++it) {
    total_weight += it->second;
  }
  if (total_weight < 1e-5) {
    total_weight = 1;
  }
  for (auto it = sorted_tag_feas.begin(); it != sorted_tag_feas.end(); ++it) {
    it->second /= total_weight;
  }

  // 使用每个 tag 对应的 top3 关联标签
  static const int kTopRelevenceTagNum = 3;
  std::unordered_map<std::string, double> relevence_tags;
  //auto tag_relevence_twoway_dict =
  //    LeafDataManager::GetGlobalData()->subscript_tag_relevence_twoway.GetDict();
  auto dict = DM_GET_DICT(reco::dm::SubscriptTagRelevenceDict,
                          DynamicDictContainer::kSubscriptTagRelevenceFile_);
  auto tag_relevence_twoway_dict = &(dict->subscript_tag_relevence_twoway);
  // top tag fea 对应的关联标签
  for (auto it = sorted_tag_feas.begin(); it != sorted_tag_feas.end(); ++it) {
    std::string& subscript_tag = it->first;

    auto it_rel = tag_relevence_twoway_dict->find(subscript_tag);
    if (it_rel != tag_relevence_twoway_dict->end()) {
      for (size_t i = 0; i < it_rel->second.size() && (int)i < kTopRelevenceTagNum; ++i) {
        const std::string& rel_tag = it_rel->second[i];
        // 过滤掉已订阅的和画像中存在的 tag
        if (subscript_words.find(rel_tag) != subscript_words.end()
            || tag_feas.find(rel_tag) != tag_feas.end()) {
          continue;
        }

        auto it_m = relevence_tags.find(rel_tag);
        if (it_m != relevence_tags.end()) {
          it_m->second += it->second;
        } else {
          relevence_tags.insert(make_pair(rel_tag, it->second));
        }
      }
    }
  }
  // 订阅标签对应的关联标签
  for (auto it = subscript_words.begin(); it != subscript_words.end(); ++it) {
    const std::string& subscript_tag = it->first;
    auto it_rel = tag_relevence_twoway_dict->find(subscript_tag);
    if (it_rel != tag_relevence_twoway_dict->end()) {
      for (size_t i = 0; i < it_rel->second.size() && (int)i < kTopRelevenceTagNum; ++i) {
        const std::string& rel_tag = it_rel->second[i];
        // 过滤掉已订阅的和画像中存在的 tag
        if (subscript_words.find(rel_tag) != subscript_words.end()
            || tag_feas.find(rel_tag) != tag_feas.end()) {
          continue;
        }

        auto it_m = relevence_tags.find(it_rel->second[i]);
        if (it_m != relevence_tags.end()) {
          it_m->second += 1.0;
        } else {
          relevence_tags.insert(make_pair(it_rel->second[i], 1.0));
        }
      }
    }
  }

  // 选取候选关联标签
  static const int kCandidateRelevenceTagNum = 10;
  TopNPriorityQueue<std::string> relevence_tag_topn(kCandidateRelevenceTagNum);
  for (auto it = relevence_tags.begin(); it != relevence_tags.end(); ++it) {
    relevence_tag_topn.add(it->first, it->second);
  }
  sorted_tags->clear();
  relevence_tag_topn.get_top_n_ordered(sorted_tags);
  LeafCache::SetCachedReco(cache_key, base::JoinStrings(*sorted_tags, "|"));
}

bool TagProbe::CheckInProbeActionDetail(const RecoRequest* reco_request,
                                        const ProbeStrategyManager* probe_manager,
                                        int action_num,
                                        std::vector<ProbeInfo>* strategy_action) {
  if (reco_request->channel_id != reco::common::kRecoChannelId) {
    return true;
  }

  strategy_action->clear();

  std::vector<std::string> sorted_tags;
  ChooseActionFromTagFea(reco_request, &sorted_tags);

  for (auto it = sorted_tags.begin(); it != sorted_tags.end(); ++it) {
    const std::string& tag = *it;
    if (tag.empty()) continue;
    ProbeInfo probe(reco::kTagProbe, reco::kSearchTag, tag);
    if (probe_manager->ProbeCanTry(probe)
        && probe_manager->ProbeHasResult(reco_request, probe)) {
      strategy_action->push_back(probe);
      VLOG(1) << "tag probe action " << probe.ToString();
      if ((int)strategy_action->size() >= action_num) {
        break;
      }
    }
  }
  return true;
}
} // namespace leaf
} // namespace reco
