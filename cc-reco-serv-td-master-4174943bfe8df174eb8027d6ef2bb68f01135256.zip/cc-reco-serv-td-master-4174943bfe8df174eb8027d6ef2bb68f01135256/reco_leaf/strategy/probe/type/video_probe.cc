#include <map>
#include <string>
#include <vector>
#include <algorithm>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "base/time/timestamp.h"
#include "reco/serv/reco_leaf/strategy/user_feature/base/user_fea_extract_util.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/reco_leaf/strategy/probe/type/video_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/reco/video/video_reco.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

namespace reco {
namespace leafserver {

VideoProbe::VideoProbe() {
}

VideoProbe::~VideoProbe() {
}

bool VideoProbe::CheckInProbeActionDetail(const RecoRequest* reco_request,
                                          const ProbeStrategyManager* probe_manager,
                                          int action_num,
                                          std::vector<ProbeInfo>* strategy_action) {
  if (!reco_request->can_deliver_video) {
    return false;
  }

  auto user_feas = reco_request->user_feas;
  if (!user_feas) {
    return false;
  }
  strategy_action->clear();
  ProbeInfo probe(reco::kVideoProbe, reco::kVideoTag, "video_tag");
  if (probe_manager->ProbeCanTry(probe)
      && probe_manager->ProbeHasResult(reco_request, probe)) {
    strategy_action->push_back(probe);
  }
  if ((int)strategy_action->size() > action_num) {
    strategy_action->resize(action_num);
  }
  return !strategy_action->empty();
}
} // namespace leaf
} // namespace reco
