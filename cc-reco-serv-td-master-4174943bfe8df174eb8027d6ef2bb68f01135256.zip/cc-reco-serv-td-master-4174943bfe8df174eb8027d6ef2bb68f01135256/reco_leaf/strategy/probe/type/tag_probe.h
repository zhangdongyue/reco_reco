#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace leafserver {

class TagProbe: public ProbeTypeBase {
public:
  TagProbe();

  virtual ~TagProbe();

  virtual reco::ProbeType get_probe_type() {
    return reco::kTagProbe;
  }

  virtual bool CheckInProbeActionDetail(const RecoRequest* request,
                                        const ProbeStrategyManager* probe_manager,
                                        int action_num,
                                        std::vector<ProbeInfo>* strategy_action);
private:
  // 从缓存中获取 action
  void GetCachedActions(const std::string& cache_key,
                        std::vector<std::string>* cached_actions,
                        bool* has_cached);

  // 基于用户画像及订阅数据选择 action
  void ChooseActionFromTagFea(const RecoRequest* reco_request,
                              std::vector<std::string>* sorted_tags);
private:
  const NewsIndex* news_index_;
};
} // namespace leaf
} // namespace reco
