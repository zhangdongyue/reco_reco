#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/type/taobao_query_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "nlp/common/nlp_util.h"
#include "base/strings/utf_char_iterator.h"

namespace reco {
namespace leafserver {

// 淘宝 query 必须能映射到下列喜刷刷类目才能下发
const char* TaobaoQueryProbe::kIflowCategories[] = { "科技", "体育", "健康", "娱乐", "房产", "收藏",
  "教育", "旅游", "时尚", "汽车", "游戏", "美食", "育儿", "财经" };

// 暂时尝试下发的频道: 推荐，科技，健康，房地产，家居，文玩，育儿，时尚，汽车，游戏
const int64 TaobaoQueryProbe::kIflowChannels[] = { reco::common::kRecoChannelId,
  reco::common::kScienceChannelId, reco::common::kHealthChannelId, reco::common::kEstateChannelId,
  reco::common::kHouseHoldChannelId, reco::common::kWenWanChannelId, reco::common::kParentingChannelId,
  reco::common::kFationChannelId, reco::common::kAutoChannelId, reco::common::kGameChannelId};

TaobaoQueryProbe::TaobaoQueryProbe() {
  for(size_t i = 0; i < ARRAYSIZE_UNSAFE(kIflowCategories); ++i) {
    iflow_categories_.insert(kIflowCategories[i]);
  }
  for(size_t i = 0; i < ARRAYSIZE_UNSAFE(kIflowChannels); ++i) {
    iflow_channels_.insert(kIflowChannels[i]);
  }

  channel_categories_.clear();
  const std::unordered_map<int64, CategoryDistributes>* ch_cate_map =
      &LeafDataManager::GetGlobalData()->channel_categories;
  for (auto it = ch_cate_map->begin(); it != ch_cate_map->end(); ++it) {
    for (int i = 0; i < (int)it->second.size(); ++i) {
      channel_categories_[it->first].insert((it->second)[i].first);
      VLOG(1) << "TaobaoQueryProbe: add channel category, channel_id=" << it->first
          << ", category=" << (it->second)[i].first;
    }
  }
}

TaobaoQueryProbe::~TaobaoQueryProbe() {
}

bool TaobaoQueryProbe::CheckInProbeActionDetail(const RecoRequest* reco_request,
                                          const ProbeStrategyManager* probe_manager,
                                          int action_num,
                                          std::vector<ProbeInfo>* strategy_action) {
  auto user_info_ = reco_request->user_info;
  if (user_info_ == NULL) {
    LOG(WARNING) << "input to query reco is error";
    return false;
  }

  strategy_action->clear();

  // 推荐频道不限定 query 类目
  // 垂直频道限制 query 长度，降低 query 分类错误带来 badcase 的风险
  if (iflow_channels_.find(reco_request->channel_id) == iflow_channels_.end()) {
    return true;
  }

  // 淘宝 query 时效性要求可稍微放开
  static int expire_hours = 72;
  std::unordered_map<int, double> query_weights;
  int64 now_timestamp = base::GetTimestamp();
  int64 earliest_timestamp = now_timestamp - expire_hours * base::Time::kMicrosecondsPerHour;
  // 用户可能会对 query 进行重新搜索，需要进行 query 去重
  // TODO 去重策略需要升级
  std::unordered_set<std::string> query_dedup;
  for (int i = 0; i < user_info_->taobao_query_history_size(); ++i) {
    const reco::user::QueryInfo& query_info = user_info_->taobao_query_history(i);
    if (!query_info.has_query()) {
      continue;
    }

    // 按搜索时间过滤
    int64 query_timestamp = (query_info.has_search_time() ? query_info.search_time() : 0)
        * base::Time::kMicrosecondsPerSecond;
    if (query_timestamp < earliest_timestamp) {
      continue;
    }

    // 丢弃类目无法对齐的 query
    if (query_info.category_size() < 1) {
      continue;
    }

    std::string query = nlp::util::NormalizeLine(query_info.query());
    // 过短的 query 忽略
    int query_size;
    if (!base::GetUTF8CharNum(query, &query_size) || query_size < 2) {
      continue;
    }

    // 类目过滤
    const std::string& cate_str = query_info.category(0);
    std::vector<std::string> cate_vec;
    base::SplitString(cate_str, "----", &cate_vec);
    if (iflow_categories_.find(cate_vec[0]) == iflow_categories_.end()) {
      continue;
    }

    // 时尚和科技类很多短而泛的 query 先根据长度滤掉
    if ((cate_vec[0] == "时尚" || cate_vec[0] == "科技") && query_size < 4 ) {
      continue;
    }

    // 垂直频道限定类目
    if (reco_request->channel_id != reco::common::kRecoChannelId) {
      if (!matchChannelCategory(reco_request->channel_id, cate_vec) || query_size < 4) {
        continue;
      }
    }

    if (query_dedup.find(query) != query_dedup.end()) {
      continue;
    }
    query_dedup.insert(query);

    // 搜索时要限定类目
    ProbeInfo probe(reco::kTaobaoQueryProbe, reco::kSearchQuery, query + "\t" + cate_vec[0]);
    if (probe_manager->ProbeCanTry(probe)
        && probe_manager->ProbeHasResult(reco_request, probe)) {
      strategy_action->push_back(probe);
      if ((int)strategy_action->size() >= action_num) {
        break;
      }
    }
  }

  return true;

}

bool TaobaoQueryProbe::matchChannelCategory(const int64 channel_id,
                                            const std::vector<std::string>& query_categories) {
  if (query_categories.empty()) {
    return false;
  }
  auto it = channel_categories_.find(channel_id);
  if (it == channel_categories_.end()) {
    return false;
  }
  const std::set<std::string>& cate_set = it->second;
  // 先按一级类目判断
  if (cate_set.find(query_categories[0]) != cate_set.end()) {
    return true;
  }
  // 再按二级类目判断
  if (query_categories.size() < 2u) {
    return false;
  } else {
    return cate_set.find(query_categories[0] + "-" + query_categories[1]) != cate_set.end();
  }
}

} // namespace leaf
} // namespace reco
