#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/type/device_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "nlp/common/nlp_util.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/serv/reco_leaf/frame/inner/dynamic_dict_container.h"

namespace reco {
namespace leafserver {

DeviceProbe::DeviceProbe() {
}

DeviceProbe::~DeviceProbe() {
}

bool DeviceProbe::CheckInProbeActionDetail(const RecoRequest* reco_request,
                                          const ProbeStrategyManager* probe_manager,
                                          int action_num,
                                          std::vector<ProbeInfo>* strategy_action) {
  // 跳过不带机型参数的请求
  if (reco_request->request == NULL || !reco_request->request->has_uc_user_param()
      || !reco_request->request->uc_user_param().has_mi()) {
    return true;
  }

  auto user_info_ = reco_request->user_info;
  if (user_info_ == NULL) {
    LOG(WARNING) << "input to device reco is error";
    return false;
  }

  uint64 user_id = reco_request->request->user().user_id();
  strategy_action->clear();
 
  // 限制在推荐、科技、互联网、数码频道
  if (reco_request->channel_id != reco::common::kRecoChannelId
      && reco_request->channel_id != reco::common::kInternetChannelId
      && reco_request->channel_id != reco::common::kScienceChannelId
      && reco_request->channel_id != reco::common::kDigitalChannelId) {
    return true;
  }

  // 不同类别的用户采用不同的探索策略
  // 1. 冷启动用户: 较高 ctr 阈值
  // 2. profile 中包含科技类目的非冷启动用户: 较高 ctr 阈值
  // 3. profile 中不包含科技类目的非冷启动用户: 极高的 ctr 阈值
  bool is_new_user = false;
  bool has_tech_profile = false;
  const UserFeature* user_fea = reco_request->user_feas;
  if (user_fea == NULL || user_fea->lt_fea.click_num + user_fea->st_fea.st_click_num <= 10) {
    is_new_user = true;
  }
  if (user_info_->has_profile() && user_info_->profile().has_category_feavec()) {
    const reco::CategoryFeatureVector& category_feavec = user_info_->profile().category_feavec();
    for (int i = 0; i < category_feavec.feature_size(); ++i) {
      const reco::CategoryFeature& cate_fea = category_feavec.feature(i);
      if (cate_fea.literal().category() == "科技") {
        if (cate_fea.weight() >= 10.0) has_tech_profile = true;
        break;
      }
    }
  }

  // 不包含科技类兴趣的非冷启动用户实验效果不好，先关掉
  if (!is_new_user && !has_tech_profile) {
    return true;
  }

  // 获取机型触发关键词
  std::string device_model = nlp::util::NormalizeLine(reco_request->request->uc_user_param().mi());
  if (device_model.empty()) {
    VLOG(1) << "skip DeviceProbe::CheckInProbeActionDetail: empty mi"
        << ", user_id=" << user_id;
    return true;
  }

  auto device_info_dict = DM_GET_DICT(reco::dm::DeviceInfoDict, DynamicDictContainer::kDeviceInfoFile_);
  auto it = device_info_dict->device_info_dict_.find(device_model);
  if (it == device_info_dict->device_info_dict_.end()) {
    VLOG(1) << "skip DeviceProbe::CheckInProbeActionDetail:"
        << " user_id=" << user_id
        << ", device_model=" << device_model;
    return true;
  }
  const reco::dm::DeviceInfo& device_info = it->second;
  // 尝试用机型的名称搜索
  // TODO: 用机型对应的 tag 触发
  std::unordered_set<std::string> device_model_queries;
  if (!device_info.name.empty()) {
    device_model_queries.insert(device_info.name);
  }

  for (auto it = device_model_queries.begin(); it != device_model_queries.end(); ++it) {
    // 将是用户类别标识拼接到 query 后面, action 中根据该标识使用不同的 search config
    ProbeInfo probe(reco::kDeviceProbe, reco::kSearchQuery,
                    *it + "\t" + (is_new_user || has_tech_profile ? "0" : "1"));
    if (probe_manager->ProbeCanTry(probe)
        && probe_manager->ProbeHasResult(reco_request, probe)) {
      strategy_action->push_back(probe);
      VLOG(1) << "add ProbeInfo:"
          << " user_id=" << user_id
          << ", probe=" << probe.ToString();
      if ((int)strategy_action->size() >= action_num) {
        break;
      }
    }
  }

  return true;
}
} // namespace leaf
} // namespace reco
