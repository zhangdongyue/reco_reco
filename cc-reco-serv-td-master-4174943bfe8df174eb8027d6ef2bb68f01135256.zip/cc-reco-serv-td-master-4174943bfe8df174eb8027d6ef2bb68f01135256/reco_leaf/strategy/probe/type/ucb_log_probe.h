#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace leafserver {

class UcbLogProbe: public ProbeTypeBase {
public:
  UcbLogProbe();
  virtual ~UcbLogProbe();

  virtual reco::ProbeType get_probe_type() {
    return reco::kUcbLogProbe;
  }

  virtual bool CheckInProbeActionDetail(const RecoRequest* request,
                                        const ProbeStrategyManager* probe_manager,
                                        int action_num,
                                        std::vector<ProbeInfo>* strategy_action);
private:
  static const char* kDefaultIflowCategories[];
  std::unordered_set<std::string> default_iflow_categories_;
  //const std::unordered_map<std::string, int>* title_black_list_;
};


} // namespace leaf
} // namespace reco
