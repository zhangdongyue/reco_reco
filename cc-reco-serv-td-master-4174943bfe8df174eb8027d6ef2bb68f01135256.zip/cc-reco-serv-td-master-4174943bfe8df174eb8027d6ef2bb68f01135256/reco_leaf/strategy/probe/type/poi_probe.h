#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace leafserver {

class PoiProbe: public ProbeTypeBase {
public:
  PoiProbe();
  virtual ~PoiProbe();

  virtual reco::ProbeType get_probe_type() {
    return reco::kPoiProbe;
  }

  virtual bool CheckInProbeActionDetail(const RecoRequest* request,
                                        const ProbeStrategyManager* probe_manager,
                                        int action_num,
                                        std::vector<ProbeInfo>* strategy_action);
private:
};


} // namespace leaf
} // namespace reco
