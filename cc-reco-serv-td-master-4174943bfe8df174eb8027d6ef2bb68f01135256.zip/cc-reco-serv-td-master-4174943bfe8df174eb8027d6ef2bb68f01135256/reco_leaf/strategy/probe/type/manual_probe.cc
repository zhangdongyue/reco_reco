#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/type/manual_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace reco {
namespace leafserver {

ManualProbe::ManualProbe() {
}

ManualProbe::~ManualProbe() {
}

bool ManualProbe::CheckInProbeActionDetail(const RecoRequest* reco_request,
                                           const ProbeStrategyManager* probe_manager,
                                           int action_num,
                                           std::vector<ProbeInfo>* strategy_action) {

  auto user_info_ = reco_request->user_info;
  probe_manual_items_ = reco_request->probe_manual_items;
  if (user_info_ == NULL
      || probe_manual_items_ == NULL) {
    LOG(WARNING) << "the user_info input to manual probe is empty or candidates empty";
  }

  strategy_action->clear();

  // 填充展现  
  base::Time now_time = base::Time::Now();
  int64 earliest_timestamp = now_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond
      - base::Time::kMicrosecondsPerDay * 7;
  std::unordered_set<uint64> history_ids;
  for (int i = user_info_->shown_history_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& item = user_info_->shown_history(i);
    if (!item.has_view_timestamp()) continue;
    if (item.view_timestamp() < earliest_timestamp) break;
    history_ids.insert(item.item_id());
  }

  // cards 按照输入的顺序，由外层计算过
  std::unordered_set<std::string> card_dedup;
  bool card_alive = false;
  for (auto iter = probe_manual_items_->begin();
       iter != probe_manual_items_->end();
       ++iter) {
    // 展现历史去重
    if (history_ids.find(iter->second.item_id) != history_ids.end()) continue;

    card_alive = false;
    const std::string& card = iter->first;
    if (card_dedup.find(card) == card_dedup.end()) {
      card_alive = true;
      card_dedup.insert(card);
    }
    if (!card_alive) continue;
    ProbeInfo probe(reco::kManualProbe, reco::kManualCtrl, card);
    if (probe_manager->ProbeCanTry(probe)
        && probe_manager->ProbeHasResult(reco_request, probe)) {
      strategy_action->push_back(probe);
      if ((int)strategy_action->size() >= action_num) {
        break;
      }
    }
  }

  return true;
}

} // namespace leafserver
} // namespace reco
