#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace leafserver {

class EarningsProbe: public ProbeTypeBase {
public:
  EarningsProbe();
  virtual ~EarningsProbe();

  virtual reco::ProbeType get_probe_type() {
    return reco::kEarningsProbe;
  }

  virtual bool CheckInProbeActionDetail(const RecoRequest* request,
                                        const ProbeStrategyManager* probe_manager,
                                        int action_num,
                                        std::vector<ProbeInfo>* strategy_action);
private:
  static const char* kCompanyNames[];
  std::vector<std::string> company_names_;
  std::vector<std::string> ss_and_words_;
  std::vector<std::string> ss_or_words_;
  std::vector<std::string> ss_not_words_;
};


} // namespace leaf
} // namespace reco
