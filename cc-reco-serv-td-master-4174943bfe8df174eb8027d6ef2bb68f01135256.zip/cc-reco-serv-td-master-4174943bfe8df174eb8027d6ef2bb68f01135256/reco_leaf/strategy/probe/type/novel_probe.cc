#include "reco/serv/reco_leaf/strategy/probe/type/novel_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "nlp/common/nlp_util.h"
#include "reco/serv/dict_server/api/dict_server_api.h"
#include "serving_base/utility/timer.h"

namespace reco {
namespace leafserver {

NovelProbe::NovelProbe() {
}

NovelProbe::~NovelProbe() {
}

bool NovelProbe::CheckInProbeActionDetail(const RecoRequest* reco_request,
                                          const ProbeStrategyManager* probe_manager,
                                          int action_num,
                                          std::vector<ProbeInfo>* strategy_action) {
  strategy_action->clear();
  serving_base::Timer timer;
  timer.Start();
  const reco::user::UserInfo* user_info = reco_request->user_info;
  if (user_info == NULL) {
    LOG(WARNING) << "input to novel reco is error";
    return false;
  }
  const uint64 user_id = user_info->identity().user_id();

  // 只对 uc 浏览器左屏生效
  if (reco_request->request->refresh_type() != 2 ||
      reco_request->channel_id != reco::common::kRecoChannelId ||
      "uc-iflow" != reco_request->request->app_token()) {
    return true;
  }

  // 一个用户作为一个整体探索条件, 配额控制到用户粒度, 而非单本小说粒度
  std::string full_user_id = base::StringPrintf("%s-%lu", reco_request->request->app_token().c_str(), user_id);
  ProbeInfo probe(reco::kNovelProbe, reco::kFollowNovel, full_user_id);
  if (probe_manager->ProbeCanTry(probe) && probe_manager->ProbeHasResult(reco_request, probe)) {
    VLOG(1) << "add probe action: " << probe.probe_detail << ", uid=" << user_id;
    if ((int)strategy_action->size() < action_num) {
      strategy_action->push_back(probe);
    }
  }
  VLOG(1) << "uid=" << user_id << ", get probe action cost time: " << timer.Stop();
  return true;
}
} // namespace leaf
} // namespace reco
