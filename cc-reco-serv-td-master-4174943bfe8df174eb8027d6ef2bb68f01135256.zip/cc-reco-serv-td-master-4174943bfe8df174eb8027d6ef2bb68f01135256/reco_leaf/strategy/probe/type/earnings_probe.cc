#include "reco/serv/reco_leaf/strategy/probe/type/earnings_probe.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/common/topn.h"
#include "reco/serv/reco_leaf/strategy/search/structured_searcher.h"

namespace reco {
namespace leafserver {

const char* EarningsProbe::kCompanyNames[] = { "百度", "苹果",
  "阿里巴巴", "谷歌", "微博", "腾讯", "网易", "新浪", "facebook", "微软"};

EarningsProbe::EarningsProbe() {
  for(size_t i = 0; i < ARRAYSIZE_UNSAFE(kCompanyNames); ++i) {
    company_names_.push_back(kCompanyNames[i]);
  }

  ss_and_words_.push_back("财报");

  ss_or_words_.push_back("发布");
  ss_or_words_.push_back("公布");
}

EarningsProbe::~EarningsProbe() {
}

bool EarningsProbe::CheckInProbeActionDetail(const RecoRequest* reco_request,
                                             const ProbeStrategyManager* probe_manager,
                                             int action_num,
                                             std::vector<ProbeInfo>* strategy_action) {
  if (reco_request->channel_id != reco::common::kRecoChannelId
      && reco_request->channel_id != reco::common::kFinanceChannelId
      && reco_request->channel_id != reco::common::kScienceChannelId
      && reco_request->channel_id != reco::common::kInternetChannelId) {
    return true;
  }

  const auto user_info_ = reco_request->user_info;
  const UserCategoryDistributes* distributes = reco_request->category_distributes;
  if (user_info_ == NULL) {
    LOG(WARNING) << "input to query reco is error";
    return false;
  }

  bool can_probe = false;
  if (reco_request->channel_id == reco::common::kScienceChannelId ||
      reco_request->channel_id == reco::common::kInternetChannelId) {
    can_probe = true;
  } else {
    // 根据兴趣
    int num = 0;
    if (distributes == NULL || distributes->size() < 3u) {
      // 兴趣不充分
      return true;
    } else if (distributes->size() > 10u) {
      num = 3;
    } else {
      num = 1;
    }

    TopN<int> topn(num);
    for (size_t i = 0; i < distributes->size(); ++i) {
      topn.add(i, distributes->at(i).first);
    }

    std::vector<int> topn_list;
    topn.get_top_n(&topn_list);

    for (size_t i = 0; i < topn_list.size(); ++i) {
      // 检查 top 的兴趣是否是 科技 或 互联网
      const reco::Category& cate = distributes->at(topn_list[i]).second;
      if ((cate.level() == 0 && cate.category() == "科技")
          || (cate.level() == 1 && cate.category() == "互联网")) {
        can_probe = true;
        break;
      }
    }
  }

  for (size_t i = 0; i < company_names_.size(); ++i) {
    ss_and_words_.push_back(company_names_[i]);
    ProbeInfo probe(reco::kEarningsProbe, reco::kStructuredSearch,
                    StructuredSearcher::ToQuery(ss_and_words_, ss_or_words_, ss_not_words_));
    ss_and_words_.pop_back();
    if (probe_manager->ProbeCanTry(probe)
        && probe_manager->ProbeHasResult(reco_request, probe)) {
      strategy_action->push_back(probe);
      if ((int)strategy_action->size() >= action_num) {
        break;
      }
    }
  }

  return true;
}
} // namespace leaf
} // namespace reco
