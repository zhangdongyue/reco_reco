#include "reco/serv/reco_leaf/strategy/probe/type/poi_probe.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace reco {
namespace leafserver {

PoiProbe::PoiProbe() {
}

PoiProbe::~PoiProbe() {
}

bool PoiProbe::CheckInProbeActionDetail(const RecoRequest* reco_request,
                                          const ProbeStrategyManager* probe_manager,
                                          int action_num,
                                          std::vector<ProbeInfo>* strategy_action) {
  if (reco_request->channel_id != reco::common::kRecoChannelId
      && reco_request->channel_id != reco::common::kEducationChannelId ) {
    return true;
  }

  // 这个策略目前用来做学校推广。没有学校信息直接返回
  if (!reco_request->request->has_school()
      || reco_request->request->school().empty()) {
    return true;
  }

  strategy_action->clear();
  ProbeInfo probe(reco::kPoiProbe, reco::kSearchPoi, reco_request->request->school());
  if (probe_manager->ProbeCanTry(probe)
      && probe_manager->ProbeHasResult(reco_request, probe)) {
    strategy_action->push_back(probe);
  }
  return true;
}
} // namespace leaf
} // namespace reco
