#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/type/query_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "nlp/common/nlp_util.h"

namespace reco {
namespace leafserver {

const char* QueryProbe::kDefaultIflowCategories[] = { "科技", "体育", "健康", "军事", "历史", "国际",
  "奇闻", "娱乐", "干货", "房产", "收藏", "教育", "旅游", "时尚", "星座", "汽车", "游戏", "社会", "科学探索",
  "美食", "职场", "育儿", "财经", "两性情感", "国内", };

QueryProbe::QueryProbe() {
  for(size_t i = 0; i < ARRAYSIZE_UNSAFE(kDefaultIflowCategories); ++i) {
    default_iflow_categories_.insert(kDefaultIflowCategories[i]);
  }
  query_black_list_ = &LeafDataManager::GetGlobalData()->query_black_list_dict;
}

QueryProbe::~QueryProbe() {
}

bool QueryProbe::CheckInProbeActionDetail(const RecoRequest* reco_request,
                                          const ProbeStrategyManager* probe_manager,
                                          int action_num,
                                          std::vector<ProbeInfo>* strategy_action) {
  if (reco_request->channel_id != reco::common::kRecoChannelId) {
    return true;
  }

  // 只对这三个渠道进行该策略
  if ("uc-iflow" != reco_request->request->app_token()
      && "ucnews-iflow" != reco_request->request->app_token()
      && "webapp" != reco_request->request->app_token()) {
    return true;
  }

  auto user_info_ = reco_request->user_info;

  if (user_info_ == NULL) {
    LOG(WARNING) << "input to query reco is error";
    return false;
  }

  strategy_action->clear();

  static int expire_hours = 48;
  std::unordered_map<int, double> query_weights;
  int64 now_timestamp = base::GetTimestamp();
  int64 earliest_timestamp = now_timestamp - expire_hours * base::Time::kMicrosecondsPerHour;
  // 用户可能会对 query 进行改写然后搜索，这种情况不需要多次尝试
  // 这种情况有一个特点， query 的核心词不变，而核心词一般会被提取成 tag
  std::unordered_set<std::string> tag_dedup;
  std::unordered_set<std::string> query_dedup;
  for (int i = 0; i < user_info_->query_history_size(); ++i) {
    const reco::user::QueryInfo& query_info = user_info_->query_history(i);
    if (!query_info.has_query()) {
      continue;
    }
    const std::string& query = query_info.query();
    if (query.find("天气") != std::string::npos
        || query.find("限行") != std::string::npos
        || query.find("百度") != std::string::npos) {
      continue;
    }
    // 按搜索时间过滤
    int64 query_timestamp = (query_info.has_search_time() ? query_info.search_time() : 0)
        * base::Time::kMicrosecondsPerSecond;
    if (query_timestamp < earliest_timestamp) continue;

    // query 对应的类别
    // 丢弃类目无法对齐的 query
    if (query_info.category_size() < 1) continue;
    
    // 一级类目过滤
    const std::string& l1_cate_str = query_info.category(0);
    if (default_iflow_categories_.find(l1_cate_str) == default_iflow_categories_.end()) continue;

    // query 黑名单
    std::string normalized_query = nlp::util::NormalizeLine(query);
    auto it = query_black_list_->find(normalized_query);
    if (it != query_black_list_->end() && it->second == 0) {
      VLOG(1) << "skip query: " << query;
      continue;
    }

    // 标签去重
    bool tag_duplicate = false;
    for (int j = 0; j < query_info.tags_size(); ++j) {
      const std::string& tag = query_info.tags(j);
      if (tag_dedup.find(tag) != tag_dedup.end()) {
        tag_duplicate = true;
        break;
      } else {
        // 下面的逻辑，当前的 query 一定会被选中或不选中，所以这里就可以开始加入去重集合了
        tag_dedup.insert(tag);
      }
    }
    // 如果 query 没有 tag， 则上面的去重逻辑就会失效，所以还需要补充一个 query 本身的去重
    bool query_duplicate = query_dedup.find(normalized_query) != query_dedup.end();
    query_dedup.insert(normalized_query);

    if (tag_duplicate || query_duplicate) continue;

    // TODO: 剔除掉已经在 profile 里置信的标签
    ProbeInfo probe(reco::kQueryProbe, reco::kSearchQuery, query_info.query() + "\t" + l1_cate_str);
    if (probe_manager->ProbeCanTry(probe)
        && probe_manager->ProbeHasResult(reco_request, probe)) {
      VLOG(1) << "add search query: " << probe.probe_detail
              << ", uid=" << user_info_->identity().user_id();
      strategy_action->push_back(probe);
      if ((int)strategy_action->size() >= action_num) {
        break;
      }
    }
  }

  return true;
}
} // namespace leaf
} // namespace reco
