#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/probe/type/ucb_log_probe.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "nlp/common/nlp_util.h"

namespace reco {
namespace leafserver {

const char* UcbLogProbe::kDefaultIflowCategories[] = { "科技", "体育", "健康", "军事", "历史", "国际",
  "奇闻", "娱乐", "干货", "房产", "收藏", "教育", "旅游", "时尚", "星座", "汽车", "游戏", "社会", "科学探索",
  "美食", "职场", "育儿", "财经", "两性情感", "国内", };

UcbLogProbe::UcbLogProbe() {
  for(size_t i = 0; i < ARRAYSIZE_UNSAFE(kDefaultIflowCategories); ++i) {
    default_iflow_categories_.insert(kDefaultIflowCategories[i]);
  }
  // title_black_list_ = &LeafDataManager::GetGlobalData()->query_black_list_dict;
}

UcbLogProbe::~UcbLogProbe() {
}

bool UcbLogProbe::CheckInProbeActionDetail(const RecoRequest* reco_request,
                                          const ProbeStrategyManager* probe_manager,
                                          int action_num,
                                          std::vector<ProbeInfo>* strategy_action) {
  if (reco_request->channel_id != reco::common::kRecoChannelId) {
    return true;
  }

  // 只对这三个渠道进行该策略
  if ("uc-iflow" != reco_request->request->app_token()
      && "ucnews-iflow" != reco_request->request->app_token()
      && "webapp" != reco_request->request->app_token()) {
    return true;
  }

  auto user_info_ = reco_request->user_info;

  if (user_info_ == NULL) {
    LOG(WARNING) << "input to query reco is error";
    return false;
  }

  strategy_action->clear();

  static int expire_hours = 48;
  int64 now_timestamp = base::GetTimestamp();
  int64 earliest_timestamp = now_timestamp - expire_hours * base::Time::kMicrosecondsPerHour;
  // 铜矿日志去重
  std::unordered_set<std::string> tag_dedup;
  std::unordered_set<std::string> title_dedup;

  for (int i = 0; i < user_info_->ucb_log_history_size(); ++i) {
    const reco::user::UcbLogInfo& ucb_log_info = user_info_->ucb_log_history(i);
    if (!ucb_log_info.has_title() || !ucb_log_info.has_view_time()) {
      continue;
    }
    const std::string& title = ucb_log_info.title();
    /*
    if (title.find("天气") != std::string::npos
        || title.find("限行") != std::string::npos
        || title.find("百度") != std::string::npos) {
      continue;
    }
    */

    // 按浏览时间过滤
    int64 ucb_log_timestamp = (ucb_log_info.has_view_time() ? ucb_log_info.view_time() : 0)
        * base::Time::kMicrosecondsPerSecond;
    if (ucb_log_timestamp < earliest_timestamp) continue;

    // title 对应的类别
    // 丢弃类目无法对齐的铜矿日志
    if (ucb_log_info.category_size() < 1) continue;

    // 一级类目过滤
    const std::string& l1_cate_str = ucb_log_info.category(0);
    if (default_iflow_categories_.find(l1_cate_str) == default_iflow_categories_.end()) continue;

    // title 黑名单
    std::string normalized_title = nlp::util::NormalizeLine(title);
    /*
    auto it = title_black_list_->find(normalized_title);
    if (it != title_black_list_->end() && it->second == 0) {
      VLOG(1) << "skip query: " << query;
      continue;
    }
    */

    // 标签去重
    bool tag_duplicate = false;
    for (int j = 0; j < ucb_log_info.tags_size(); ++j) {
      const std::string& tag = ucb_log_info.tags(j);
      if (tag_dedup.find(tag) != tag_dedup.end()) {
        tag_duplicate = true;
        break;
      } else {
        tag_dedup.insert(tag);
      }
    }
    // 如果 title 没有 tag， 则上面的去重逻辑就会失效，所以还需要补充一个 title 本身的去重
    bool title_duplicate = title_dedup.find(normalized_title) != title_dedup.end();
    title_dedup.insert(normalized_title);

    if (tag_duplicate || title_duplicate) continue;

    // TODO: 剔除掉已经在 profile 里置信的标签
    ProbeInfo probe(reco::kUcbLogProbe, reco::kViewTitle, normalized_title + "\t" + l1_cate_str);
    if (probe_manager->ProbeCanTry(probe)
        && probe_manager->ProbeHasResult(reco_request, probe)) {
      VLOG(1) << "add ucb log: " << probe.probe_detail
              << ", uid=" << user_info_->identity().user_id();
      strategy_action->push_back(probe);
      if ((int)strategy_action->size() >= action_num) {
        break;
      }
    }
  }

  return true;
}
} // namespace leaf
} // namespace reco
