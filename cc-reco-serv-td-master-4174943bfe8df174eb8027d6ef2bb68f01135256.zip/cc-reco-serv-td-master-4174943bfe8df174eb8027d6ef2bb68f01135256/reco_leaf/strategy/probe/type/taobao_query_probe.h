#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>
#include <set>

#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace leafserver {

class TaobaoQueryProbe: public ProbeTypeBase {
public:
  TaobaoQueryProbe();
  virtual ~TaobaoQueryProbe();

  virtual reco::ProbeType get_probe_type() {
    return reco::kTaobaoQueryProbe;
  }

  virtual bool CheckInProbeActionDetail(const RecoRequest* request,
                                        const ProbeStrategyManager* probe_manager,
                                        int action_num,
                                        std::vector<ProbeInfo>* strategy_action);

private:
  // 根据 query 的类目判断是否允许在频道下发
  bool matchChannelCategory(const int64 channel_id,
                            const std::vector<std::string>& query_categories);

  // 允许进行探索的类目
  static const char* kIflowCategories[];
  std::unordered_set<std::string> iflow_categories_;

  // 允许下发的频道
  static const int64 kIflowChannels[];
  std::unordered_set<int64> iflow_channels_;

  // 各频道允许下发的类别
  std::unordered_map<int64, std::set<std::string> > channel_categories_;
};

} // namespace leaf
} // namespace reco
