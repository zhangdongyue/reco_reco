#include "reco/serv/reco_leaf/strategy/reason_explain.h"

#include <algorithm>
#include <queue>

#include "base/time/timestamp.h"
#include "base/time/time.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/serv/reco_leaf/frame/inner/dynamic_dict_container.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;
using reco::user::ViewClickItem;

DEFINE_bool(reco_reason_unlimited_quota, false, "如果为 true 不限制理由投放");
DEFINE_int32(reco_reason_global_minute_delta, 30, "全局（所有理由）的展现分钟间隔");
DEFINE_int32(reco_reason_global_refresh_delta, 10, "全局（所有理由）的展现刷新间隔");
DEFINE_int32(reco_reason_type_minute_delta, 360, "理由类型的展现分钟间隔");
DEFINE_int32(reco_reason_type_refresh_delta, 0, "理由类型的展现刷新间隔");
DEFINE_int32(reco_core_reason_minute_delta, 2880, "理由词展现分钟间隔");
DEFINE_int32(reco_core_reason_refresh_delta, 0, "理由词展现刷新间隔");
DEFINE_int32(user_potential_reason_cache_seconds, 21600, "用户潜在理由计算结果缓存时长");

const std::unordered_set<int> ReasonExplain::kNewsItemTypeSet = {
  reco::kNews, reco::kReading, reco::kPicture, reco::kPictureNews,
};

ReasonExplain::ReasonExplain() {
  global_data_ = LeafDataManager::GetGlobalData();
  news_index_ = global_data_->news_index;
}

ReasonExplain::~ReasonExplain() {
}

// 返回推荐理由的频道
static bool return_reco_reason(int64 channel_id) {
  return channel_id == reco::common::kRecoChannelId
      || channel_id == reco::common::kEntertainmentChannelId
      || channel_id == reco::common::kSportChannelId
      || channel_id == reco::common::kFinanceChannelId
      || channel_id == reco::common::kInternetChannelId
      || channel_id == reco::common::kScienceChannelId
      || channel_id == reco::common::kSocialChannelId
      || channel_id == reco::common::kAutoChannelId
      || channel_id == reco::common::kMilitaryChannelId
      || channel_id == reco::common::kInternationalChannelId;
}

bool ReasonExplain::PrepareToExplain(const RecommendRequest* request,
                                     const UserInfo* user_info, const UserFeature* user_feature) {
  user_info_ = user_info;
  user_feature_ = user_feature;
  user_id_ = user_info_->identity().user_id();
  channel_id_ = request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId;
  potential_tags_.clear();
  candidate_tags_.clear();
  last_reason_type_delta_.clear();
  last_core_reason_delta_.clear();
  last_delta_ = std::make_pair(0, 0);

  bool deliver_reco_reason = return_reco_reason(channel_id_);
  if (!deliver_reco_reason) {
    VLOG(1) << channel_id_ << " do not show reco reason";
    return false;
  }

  current_timestamp_ = base::GetTimestamp();

  // 收集针对这个用户可能的所有推荐理由
  if (!CollectPotentialReasons()) {
    VLOG(1) << "no potential tag collected";
    // return false;
  }

  // 收集理由的统计信息
  ParseReasonShownHistory();

  // 根据已订阅、不喜欢、quota 等维度筛选符合条件的理由
  if (!ChooseCandidateReasons()) {
    VLOG(1) << "no candidate tag available";
    // return false;
  }

  return true;
}

bool ReasonExplain::CollectPotentialReasons() {
  potential_tags_.clear();
  std::string cache_key = base::Uint64ToString(user_id_) + "-CachedRecoReason";
  std::string cache_value;
  if (LeafCache::GetCachedReco(cache_key, &cache_value)) {
    if (cache_value.empty()) {
      VLOG(1) << "cached reco reason is empty, user: " << user_id_;
      return false;
    }
    WrappedCachedRecoReason wrapped_reason;
    if (wrapped_reason.ParseFromString(cache_value)) {
      for (int i = 0; i < wrapped_reason.reco_reason_size(); ++i) {
        TagMetaInfo meta = TagMetaInfo::FromCachedRecoReason(wrapped_reason.reco_reason(i));
        if (meta.sum_weight < 0 || meta.type_bits.count() == 0) {
          VLOG(1) << "invalid cached reco reason" << wrapped_reason.reco_reason(i).Utf8DebugString();
          continue;
        }
        potential_tags_.insert(std::make_pair(meta.tag, meta));
      }
      VLOG(1) << "read cached reco reason for user: " << user_id_
              << ", tag size: " << potential_tags_.size();
      return !potential_tags_.empty();
    } else {
      VLOG(1) << "failed to parse cached reco reason" << cache_value;
    }
  }

  // 获取最近点击里的高频标签
  GetRecentClickTags();

  // 获取画像里的高频标签
  GetProfileTags();

  // 抽取画像和订阅词
  std::map<std::string, float> tag_weight;
  for (auto it = potential_tags_.begin(); it != potential_tags_.end(); ++it) {
    if (!it->second.type_bits.test(RecoReason::kProfileExploit)) {
      continue;
    }
    float weight = it->second.type_weights[RecoReason::kProfileExploit];
    tag_weight[it->first] = weight;
  }
  const auto& subscript_words = user_feature_->behavior_fea.subscript_words;
  for (auto it = subscript_words.begin(); it != subscript_words.end(); ++it) {
    tag_weight[it->first] = 1.0f;
  }
  // 根据画像或者订阅词，获取关联标签, 要记录是根据哪个词关联来的
  GetExploreTags(tag_weight);

  cache_value.clear();
  // 不管 potential tag 是否为空，都要缓存。 为空也要缓存避免为新用户浪费计算资源
  if (!potential_tags_.empty()) {
    WrappedCachedRecoReason wrapped_reason;
    for (auto it = potential_tags_.begin(); it != potential_tags_.end(); ++it) {
      it->second.ToCachedRecoReason(wrapped_reason.add_reco_reason());
    }
    if (!wrapped_reason.SerializeToString(&cache_value)) {
      LOG(WARNING) << "serialize string failed";
      cache_value.clear();
    }
  }
  if (!LeafCache::SetCachedReco(cache_key, cache_value, FLAGS_user_potential_reason_cache_seconds)) {
    LOG(WARNING) << "add to leaf cache failed";
  } else {
    VLOG(1) << "add to leaf cache for user: " << user_id_
            << ", potential tag size: " << potential_tags_.size()
            << ", cached: " << cache_value;
  }
  return !potential_tags_.empty();
}

void ReasonExplain::GetRecentClickTags() {
  VLOG(1) << "user recent click: " << user_id_ << ", " << user_info_->recent_click_size();

  //auto tag_dict = global_data_->reco_reason_tag_category.GetDict();
  auto dict = DM_GET_DICT(reco::dm::RecoReasonTagDict, DynamicDictContainer::kRecoReasonTagFile_);
  auto tag_dict = &(dict->reco_reason_tag_category);
  int64 earliest_timestamp = current_timestamp_ - kMaxClickHourDelta * base::Time::kMicrosecondsPerHour;
  std::map<std::string, int> tag_click_cnt;
  base::dense_hash_set<uint64> uniq_ids;
  uniq_ids.set_empty_key(0);
  int total_click = 0;
  std::vector<std::string> show_tags;
  std::vector<std::string> categories;
  for (int i = user_info_->recent_click_size() - 1; i >= 0; --i) {
    if (total_click++ > kMaxRecentClick) {
      VLOG(1) << total_click << " > " << kMaxRecentClick;
      break;
    }

    const ViewClickItem& clicked_item = user_info_->recent_click().Get(i);
    // 点击发生时间过于久远, 丢弃. 按时间有序, 可以 break
    if (clicked_item.click_timestamp() < earliest_timestamp) {
      VLOG(1) << clicked_item.click_timestamp() << " < " << earliest_timestamp;
      break;
    }

    const uint64 item_id = clicked_item.item_id();
    if (uniq_ids.find(item_id) != uniq_ids.end()) continue;
    uniq_ids.insert(item_id);

    ItemType item_type = reco::kNews;
    if (!news_index_->GetItemTypeByItemId(item_id, &item_type)) {
      VLOG(1) << item_id << " can't get item type";
      continue;
    }

    if (kNewsItemTypeSet.find(item_type) == kNewsItemTypeSet.end()) {
      VLOG(1) << item_id << ", " << item_type << " is skipped";
      continue;
    }

    show_tags.clear();
    if (!news_index_->GetShowTagByItemId(item_id, &show_tags)
        || show_tags.empty()) {
      VLOG(1) << item_id << " has empty show tags";
      continue;
    }

    categories.clear();
    if (!news_index_->GetCategoriesByItemId(item_id, &categories)
        || categories.empty() || categories[0] == "未分类") {
      VLOG(1) << item_id << " has empty category";
      continue;
    }

    for (size_t i = 0; i < show_tags.size(); ++i) {
      const std::string& tag = show_tags[i];
      auto it = tag_dict->find(tag);
      if (it == tag_dict->end()) {
        VLOG(1)  << tag << " of item " << item_id << " is not subscript tag";
        continue;
      }
      if (it->second.find(categories[0]) == it->second.end()) {
        VLOG(1)  << tag << " of item " << item_id << " category " << categories[0] << " not match";
        continue;
      }
      tag_click_cnt[tag] += 1;
    }
  }

  for (auto it = tag_click_cnt.begin(); it != tag_click_cnt.end(); ++it) {
    const std::string& tag = it->first;
    const int& click_cnt = it->second;
    if (it->second < kMinTagClickCntToBeRecoReason) {
      VLOG(1)  << tag << " click cnt " << click_cnt << " < " << kMinTagClickCntToBeRecoReason;
      continue;
    }

    float weight = std::min((float)click_cnt / 10.0f, 1.0f);
    const TagMetaInfo& meta = AddToPotentialTag(RecoReason::kSessionClick, it->first, "", weight, it->second);
    VLOG(1) << "add to potential tag: " << meta.ToString();
  }
}

void ReasonExplain::GetProfileTags() {
  //auto tag_dict = global_data_->reco_reason_tag_category.GetDict();
  auto dict = DM_GET_DICT(reco::dm::RecoReasonTagDict, DynamicDictContainer::kRecoReasonTagFile_);
  auto tag_dict = &(dict->reco_reason_tag_category);
  float max_weight = 0;
  std::map<std::string, float> tag_weight;
  std::vector<std::string> flds;

  // 特征抽取
  const FeatureVector& fea_vec = user_info_->profile().tag_feavec();
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const reco::Feature& fea = fea_vec.feature(i);
    if (fea.weight() <= 1e-6) continue;
    if (!fea.has_category()) {
      VLOG(1) << "tag feature has no category, " << fea.Utf8DebugString();
      continue;
    }
    const std::string& category = fea.category();
    const std::string& orig_tag = fea.literal();
    std::string tag;
    flds.clear();
    base::SplitString(orig_tag, ":", &flds);
    if (flds.size() > 1u) {
      tag = flds[1];
    } else {
      tag = orig_tag;
    }
    float weight = fea.weight();
    auto it = tag_dict->find(tag);
    if (it == tag_dict->end()) {
      VLOG(1)  << tag << " of user " << user_id_ << " is not subscript tag";
      continue;
    }
    if (it->second.find(category) == it->second.end()) {
      VLOG(1)  << tag << " of user " << user_id_ << " category " << category << " not match";
      continue;
    }

    auto jt = tag_weight.find(tag);
    if (jt == tag_weight.end()) {
      jt = tag_weight.insert(std::make_pair(tag, weight)).first;
    } else {
      jt->second += weight;
    }
    max_weight = std::max(jt->second, max_weight);
  }

  if (max_weight < 1e-6) {
    max_weight = 1;
  }

  for (auto it = tag_weight.begin(); it != tag_weight.end(); ++it) {
    const std::string& tag = it->first;
    const float& w = it->second;
    if (it->second < kMinTagWeightToBeRecoReason) {
      VLOG(1)  << tag << " profile weight " << w << " < " << kMinTagWeightToBeRecoReason;
      continue;
    }
    float weight = std::min(w / max_weight, 1.0f);
    const TagMetaInfo& meta = AddToPotentialTag(RecoReason::kProfileExploit, it->first, "", weight);
    VLOG(1) << "add to potential tag: " << meta.ToString();
  }
}

// 根据画像或者订阅词，获取关联标签
// 要记录是根据哪个词关联来的
void ReasonExplain::GetExploreTags(const std::map<std::string, float>& tag_weight) {
  // tag -> (refer tag, weight)
  std::map<std::string, std::pair<std::string, float> > explore_tag_weight;
  //auto related_dict = global_data_->subscript_tag_relevence_merged.GetDict();
  auto dict = DM_GET_DICT(reco::dm::SubscriptTagRelevenceDict,
                          DynamicDictContainer::kSubscriptTagRelevenceFile_);
  auto related_dict = &(dict->subscript_tag_relevence_merged);
  float max_weight = 0.0f;
  for (auto it = tag_weight.begin(); it != tag_weight.end(); ++it) {
    const std::string& tag = it->first;
    const float& weight = it->second;
    auto jt = related_dict->find(tag);
    if (jt == related_dict->end()) {
      continue;
    }
    const auto& vec = jt->second;
    float w = weight;
    for (size_t i = 0; i < vec.size(); ++i) {
      auto& tw = explore_tag_weight[vec[i]];
      if (tw.second < w) {
        tw.first = tag;
      }
      tw.second += w;
      max_weight = std::max(max_weight, tw.second);
      w *= 0.9;
    }
  }

  if (max_weight < 1e-6) {
    max_weight = 1;
  }

  for (auto it = explore_tag_weight.begin(); it != explore_tag_weight.end(); ++it) {
    const std::string& tag = it->first;
    const std::string& refer_tag = it->second.first;
    const float& w = it->second.second;
    if (w < kMinTagWeightToBeRecoReason) {
      VLOG(1)  << tag << " explore weight " << w << " < " << kMinTagWeightToBeRecoReason;
      continue;
    }
    float weight = std::min(w / max_weight, 1.0f);
    const TagMetaInfo& meta = AddToPotentialTag(RecoReason::kInterestExplore, tag, refer_tag, weight);
    VLOG(1) << "add to potential tag: " << meta.ToString();
  }
}

bool ReasonExplain::ChooseCandidateReasons() {
  candidate_tags_.clear();
  const auto& dislike_tags = user_feature_->behavior_fea.dislike_tags;
  const auto& dislike_semantic_tags = user_feature_->behavior_fea.dislike_semantic_tags;
  const auto& subscript_words = user_feature_->behavior_fea.subscript_words;
  for (auto it = potential_tags_.begin(); it != potential_tags_.end(); ++it) {
    const std::string& tag = it->first;

    if (!HasQuota(tag)) {
      VLOG(1) << "tag has no quota: " << tag;
      continue;
    }

    // 检查是不是在不喜欢理由里
    if (dislike_tags.find(tag) != dislike_tags.end()
        || dislike_semantic_tags.find(tag) != dislike_semantic_tags.end()) {
      VLOG(1) << "tag match dislike tag: " << tag;
      continue;
    }

    // 检查是否已经订阅
    if (subscript_words.find(tag) != subscript_words.end()) {
      VLOG(1) << "tag has been subscripted: " <<  tag;
      continue;
    }

    const TagMetaInfo& meta = it->second;
    bool type_no_quota = true;
    for (auto jt = meta.type_weights.begin(); jt != meta.type_weights.end(); ++jt) {
      if (HasQuota(jt->first)) {
        type_no_quota = false;
        break;
      }
    }
    if (type_no_quota) {
      VLOG(1) << meta.ToString() << " all types no quota";
      continue;
    }

    candidate_tags_.insert(std::make_pair(tag, meta));
    VLOG(1) << "add to candidate tags: " << tag << ", " << meta.ToString();
  }
  return !candidate_tags_.empty();
}

void ReasonExplain::ParseReasonShownHistory() {
  last_reason_type_delta_.clear();
  last_core_reason_delta_.clear();
  last_delta_ = std::make_pair(100000, 100000);

  int64 earliest_timestamp = current_timestamp_ - kMaxShowHourDelta * base::Time::kMicrosecondsPerHour;
  int total_show = 0;
  int refresh_no = 0;
  base::dense_hash_set<int64> uniq_recoid;
  uniq_recoid.set_empty_key(0);
  for (int i = user_info_->shown_history_size() - 1; i >= 0; --i) {
    if (total_show++ > kMaxRecentShow) {
      break;
    }

    const ViewClickItem& item = user_info_->shown_history(i);
    if (item.view_timestamp() < earliest_timestamp) {
      break;
    }

    if (uniq_recoid.find(item.view_timestamp()) == uniq_recoid.end()) {
      // min refresh_no is 1
      uniq_recoid.insert(item.view_timestamp());
      ++refresh_no;
    }

    if (!item.has_reco_reason_type()
        || !RecoReason::ReasonType_IsValid(item.reco_reason_type())
        || item.reco_reason_type() == RecoReason::kNoRecoReason) {
      VLOG(1) << "item has no or invalid reco reason type";
      continue;
    }

    int minute_delta = (current_timestamp_ - item.view_timestamp()) / base::Time::kMicrosecondsPerMinute;
    int refresh_delta = refresh_no;
    last_delta_.first = std::min(minute_delta, last_delta_.first);
    last_delta_.second = std::min(refresh_delta, last_delta_.second);

    UpdateDelta(item.reco_reason_type(), minute_delta, refresh_delta,
                &last_reason_type_delta_);
    if (item.has_reco_core_reason() && !item.reco_core_reason().empty()) {
      UpdateDelta(item.reco_core_reason(), minute_delta, refresh_delta,
                  &last_core_reason_delta_);
    }
  }
}

bool ReasonExplain::SetEventRecoReason(
    const std::vector<ItemInfo>& item_infos,
    std::vector<std::pair<int, RecoReason>>* reason_vec) {
  for (size_t idx = 0; idx < item_infos.size(); ++idx) {
    const ItemInfo& item_info = item_infos[idx];
    if (item_info.strategy_type == reco::kQueryReco) continue;
    uint64 item_id = item_info.item_id;

    // 加入事件标签
    std::vector<std::string> event_tags;
    std::vector<reco::EventTagInfo> event_vec;
    news_index_->GetEventTagInfoByDocId(item_info.doc_id, &event_vec);
    for (auto it_eti = event_vec.begin(); it_eti != event_vec.end(); ++it_eti) {
      LOG(INFO) << "event, " << item_info.item_id
                << ", " << it_eti->event_item_id() << ", " << it_eti->event_tag_name();
      uint64 event_item_id = it_eti->event_item_id();
      if (news_index_->IsValidByItemId(event_item_id)) {
        event_tags.push_back(it_eti->event_tag_name());
      }
    }
    if (event_tags.empty()) {
      VLOG(1) << "can't find event tag for item: " << item_id;
      continue;
    }
    const std::string& event_tag = event_tags[0];
    RecoReason reason;
    int reason_type = 1;
    if (item_info.strategy_type == reco::kManual) {
      ChooseReason(item_id, RecoReason::kOperItemReq,
                   TagMetaInfo(RecoReason::kOperItemReq, event_tag),
                   reason_type, &(reason));
      VLOG(1) << "succ to return manual event tag: " << item_id << " tag: " << event_tag;
      reason_vec->push_back(std::make_pair(idx, reason));
    } else {
      ChooseReason(item_id, RecoReason::kInterestExplore,
                   TagMetaInfo(RecoReason::kInterestExplore, event_tag),
                   reason_type, &(reason));
      VLOG(1) << "succ to return machine event tag: " << item_id << " tag: " << event_tag;
      reason_vec->push_back(std::make_pair(idx, reason));
    }
  }

  return true;
}

bool ReasonExplain::SetBeautyChannelReason(const std::vector<ItemInfo>& items,
                                           std::pair<int, RecoReason>* chosen_one) {
  for (size_t i = 0; i < items.size(); ++i) {
    const ItemInfo& item = items[i];
    if (item.strategy_type == kPornUserDeliver) {
      chosen_one->first = i;
      chosen_one->second.set_reason_type(RecoReason::kBeautyChannelGuide);
      chosen_one->second.set_core_reason("美女");
      chosen_one->second.set_core_reason_type(2);
      return true;
    }
  }
  return false;
}

bool ReasonExplain::SetRecoReason(const std::vector<ItemInfo>& item_infos,
                                  const std::vector<ProbeInfo>& probe_infos,
                                  std::pair<int, RecoReason>* chosen_one) {
  //auto dict = global_data_->reco_reason_tag_category.GetDict();
  auto tag_dict = DM_GET_DICT(reco::dm::RecoReasonTagDict, DynamicDictContainer::kRecoReasonTagFile_);
  auto dict = &(tag_dict->reco_reason_tag_category);
  const auto& dislike_tags = user_feature_->behavior_fea.dislike_tags;
  const auto& dislike_semantic_tags = user_feature_->behavior_fea.dislike_semantic_tags;
  const auto& subscript_words = user_feature_->behavior_fea.subscript_words;

  struct Choice {
    int idx;
    RecoReason::ReasonType chosen_type;
    int reason_type;
    float total_weight;
    TagMetaInfo tag_meta;
    Choice() {
      idx = -1;
      chosen_type = RecoReason::kNoRecoReason;
      total_weight = 0;
      reason_type = 0;
    }
  };

  Choice best_choice;
  for (size_t idx = 0; idx < item_infos.size(); ++idx) {
    const ItemInfo& item_info = item_infos[idx];
    const ProbeInfo& probe_info = probe_infos[idx];
    uint64 item_id = item_info.item_id;

    if (kNewsItemTypeSet.find(item_info.item_type) == kNewsItemTypeSet.end()) {
      VLOG(1) << "not set reason for type: " << item_info.item_type;
      continue;
    }

    // 自媒体不加引导标签
    std::string wemedia_person;
    if (news_index_->GetWeMediaPersonByDocId(item_info.doc_id, &wemedia_person)) {
      VLOG(1) << "wemedia item filtered: " << item_id;
      continue;
    }

    if (item_info.strategy_type != reco::kExploit &&
        item_info.strategy_type != reco::kExplore &&
        item_info.strategy_type != reco::kManual &&
        item_info.strategy_type != reco::kProbe) {
      VLOG(1) << item_id << " filtered by strategy type: " << item_info.strategy_type;
      continue;
    }

    // 更改策略，只是用标题核心标签作为理由
    // 标题核心标签是出现在标题中的 show tag
    // 加入事件标签
    std::vector<std::string> target_tags;
    news_index_->GetTitleCoreTagsByItemId(item_id, &target_tags);
    if (target_tags.empty()) {
      VLOG(1) << "can't find core tag for item: " << item_id;
      continue;
    }

    for (size_t i = 0; i < target_tags.size(); ++i) {
      const std::string& target_tag = target_tags[i];
      int reason_type = 0;
      auto iter = dict->find(target_tag);
      if (iter != dict->end()) {
        auto &cates = iter->second;
        if (cates.find(item_info.category) == cates.end()) {
          VLOG(1) << "can't tag catogry not match: " << item_id << " category: " << item_info.category;
          continue;
        }
      } else {
        VLOG(1) << "target tag not in subscription tag dict: " << item_id << " tag: " << target_tag;
        continue;
      }

      if (!HasQuota(target_tag)) {
        VLOG(1) << "target tag has no quota: " << item_id << " tag: " << target_tag;
        continue;
      }

      if (HasQuota(RecoReason::kSearchQuery)) {
        if (item_info.strategy_type == reco::kProbe
            && probe_info.probe_type == reco::kQueryProbe
            && probe_info.probe_detail.find(target_tag) != std::string::npos) {
          // 因为这个策略是独立插入的，所以要再走一遍检查逻辑
          if (subscript_words.find(target_tag) != subscript_words.end()
              || dislike_tags.find(target_tag) != dislike_tags.end()
              || dislike_semantic_tags.find(target_tag) != dislike_semantic_tags.end()) {
            VLOG(1) << "target tag subscribed or disliked: " << item_id << " tag: " << target_tag;
            continue;
          } else {
            // 基于用户最近搜索历史推荐
            chosen_one->first = idx;
            ChooseReason(item_id, RecoReason::kSearchQuery,
                         TagMetaInfo(RecoReason::kSearchQuery, target_tag),
                         reason_type,
                         &(chosen_one->second));
            // 这个策略命中立即返回，不参与全局 pk
            return true;
          }
        }

        // 其他的推荐理由必须在该用户的理由候选里
        auto it = candidate_tags_.find(target_tag);
        if (it == candidate_tags_.end()) {
          VLOG(1) << "target tag not in user candidate: " << item_id << " tag: " << target_tag;
          continue;
        }

        const TagMetaInfo& tag_meta = it->second;
        float sum_weight = 0;
        std::pair<RecoReason::ReasonType, float> best_type = std::make_pair(RecoReason::kNoRecoReason, 0);
        for (auto it = tag_meta.type_weights.begin(); it != tag_meta.type_weights.end(); ++it) {
          if (HasQuota(it->first)) {
            sum_weight += it->second;
            if (it->second > best_type.second) {
              best_type.first = it->first;
              best_type.second = it->second;
            }
          }
        }
        if (sum_weight > best_choice.total_weight) {
          best_choice.idx = idx;
          best_choice.chosen_type = best_type.first;
          best_choice.total_weight = sum_weight;
          best_choice.tag_meta = tag_meta;
          best_choice.reason_type = reason_type;
        }
      }
    }
  }

  if (best_choice.idx == -1) {
    return false;
  } else {
    chosen_one->first = best_choice.idx;
    ChooseReason(item_infos[best_choice.idx].item_id, best_choice.chosen_type,
                 best_choice.tag_meta, best_choice.reason_type, &chosen_one->second);
    return true;
  }
}

void ReasonExplain::ChooseReason(uint64 item_id, RecoReason::ReasonType chosen_type,
                                 const TagMetaInfo& tag_meta, int reason_type,
                                 RecoReason* reco_reason) {
  // 文案直接透传给前端，iflow不进行处理，因此这里要转化为规范化形式
  //auto tag_mapping_dict = global_data_->reco_reason_tag_mapping.GetDict();
  auto dict = DM_GET_DICT(reco::dm::RecoReasonTagDict, DynamicDictContainer::kRecoReasonTagFile_);
  auto tag_mapping_dict = &(dict->reco_reason_tag_mapping);
  std::string mapping_tag = tag_meta.tag;
  auto it_mapping = tag_mapping_dict->find(tag_meta.tag);
  if (it_mapping != tag_mapping_dict->end()) {
    mapping_tag = it_mapping->second;
  }

  reco_reason->set_reason_type(chosen_type);
  reco_reason->set_core_reason(mapping_tag);
  std::string reason_text;
  switch (chosen_type) {
    case RecoReason::kProfileExploit:
      reason_text = base::StringPrintf("关注 #%s# 推荐更多相关内容", mapping_tag.c_str());
      break;
    case RecoReason::kInterestExplore:
      reason_text = base::StringPrintf("猜你喜欢 #%s# 相关内容", mapping_tag.c_str());
      break;
    case RecoReason::kSessionClick:
      reason_text = base::StringPrintf("根据阅读历史推荐 #%s# ", mapping_tag.c_str());
      break;
    case RecoReason::kSearchQuery:
      reason_text = base::StringPrintf("猜你喜欢 #%s# 相关内容", mapping_tag.c_str());
      break;
    default:
      reason_text = base::StringPrintf("推荐您订阅 #%s# ", mapping_tag.c_str());
      break;
  }
  reco_reason->set_reason_text(reason_text);
  reco_reason->set_core_reason_type(reason_type);
  // 看下影响面，先用 INFO 日志
  LOG(INFO) << "set reco reason : item_id:" << item_id
            << ", user:" << user_id_
            << ", tag:" << mapping_tag
            << ", type:" << RecoReason::ReasonType_Name(chosen_type);
}

bool ReasonExplain::HasQuota(const std::string& tag) {
  if (FLAGS_reco_reason_unlimited_quota) {
    return true;
  }

  // 全局控制策略：标签的订阅率较低时，不展现引导卡片
  static const uint32_t kSubscribedShowNum = 1000;
  static const double kSubscribedCtr = 0.006;
  auto subscribed_dict = LeafDataManager::GetGlobalData()->subscribed_show_click_dict_;
  auto it_sub = subscribed_dict.find(tag);
  if (it_sub != subscribed_dict.end()
      && it_sub->second.first >= kSubscribedShowNum && it_sub->second.second < kSubscribedCtr) {
    VLOG(1) << "cancel reco reason for low ctr ! tag:" << tag << ", user:" << user_id_
            << ", show:" << it_sub->second.first << ", ctr:" << it_sub->second.second;
    return false;
  }

  // 全局控制
  if (last_delta_.first < FLAGS_reco_reason_global_minute_delta
      || last_delta_.second < FLAGS_reco_reason_global_refresh_delta) {
    return false;
  }
  // pair: minute delta, refresh delta
  auto it = last_core_reason_delta_.find(tag);
  if (it == last_core_reason_delta_.end()) {
    return true;
  }
  if (it->second.first < FLAGS_reco_core_reason_minute_delta
      || it->second.second < FLAGS_reco_core_reason_refresh_delta) {
    return false;
  }
  return true;
}

bool ReasonExplain::HasQuota(RecoReason::ReasonType type) {
  if (FLAGS_reco_reason_unlimited_quota) {
    return true;
  }

  // 全局控制
  if (last_delta_.first < FLAGS_reco_reason_global_minute_delta
      || last_delta_.second < FLAGS_reco_reason_global_refresh_delta) {
    return false;
  }
  // pair: minute delta, refresh delta
  auto it = last_reason_type_delta_.find(type);
  if (it == last_reason_type_delta_.end()) {
    return true;
  }
  if (it->second.first < FLAGS_reco_reason_type_minute_delta
      || it->second.second < FLAGS_reco_reason_type_refresh_delta) {
    return false;
  }
  return true;
}

}  // namespace leafserver
}  // namespace reco
