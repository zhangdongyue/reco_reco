#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>

#include "serving_base/expiry_map/expiry_map.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/serv/reco_leaf/proto/leaf_data.pb.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"

namespace reco {
class NewsIndex;
class UserInfo;

namespace leafserver {
struct GlobalData;
class UserFeature;

// 设置推荐理由的流程
// if (PrepareToExplain(user_info, user_feature)) {
//    bool set = SetRecoReason(all_items, all_probes, reco_reason);
//    if (set) {
//      copy reco_reason
//    }
//  }
// }
class ReasonExplain {
 public:
  ReasonExplain();
  ~ReasonExplain();

  // 根据用户的信息，收集可能的推荐理由，并根据最近这些理由的展示情况，决定这次给出理由的候选集
  // 调用以下函数： CollectPotentialReasons, ParseReasonShownHistory, ChooseCandidateReasons
  // 返回: 如果当前请求不适合返回理由，或者用户没有合适理由，或者内部出错, return false
  bool PrepareToExplain(const RecommendRequest* request,
                        const reco::user::UserInfo* user_info,
                        const UserFeature* user_feature);

  // 事件标签设置
  bool SetEventRecoReason(const std::vector<ItemInfo>& item_infos,
                          std::vector<std::pair<int, RecoReason>>* reason_vec);

  // 传入所有要推荐的 item， 选择一个最好的打上理由
  bool SetRecoReason(const std::vector<ItemInfo>& item_infos,
                     const std::vector<ProbeInfo>& probe_infos,
                     std::pair<int, RecoReason>* chosen_one);

  bool SetBeautyChannelReason(const std::vector<ItemInfo>& items,
                              std::pair<int, RecoReason>* chosen_one);
 private:
  // 集中管理收集每个 tag 可能的理由及权重
  struct TagMetaInfo {
    static const int kMaxBit = 64;
    std::string tag; // 本推荐理由的核心标签
    std::string refer_tag; // 关联标签，比如核心标签是由哪个标签算出来的
    int click_cnt;  // 点击次数
    float sum_weight;  // 总权重。由分类型的权重累计而来
    std::bitset<kMaxBit> type_bits;  // 该标签可以关联到哪些理由类型
    std::map<RecoReason::ReasonType, float> type_weights;  // 每个理由类型权重, 每个权重已归一化到 [0, 1]

    TagMetaInfo() {
      click_cnt = 0;
      sum_weight = 0;
      type_bits.reset();
    }

    TagMetaInfo(RecoReason::ReasonType type, const std::string& t) {
      click_cnt = 0;
      sum_weight = 0;
      type_bits.set(type);
      tag = t;
    }

    std::string ToString() const {
      return base::StringPrintf("tag[%s], refer_tag[%s], click[%d], weight[%.3f], bits[%lu]",
                                tag.c_str(), refer_tag.c_str(), click_cnt, sum_weight, type_bits.count());
    }

    void ToCachedRecoReason(CachedRecoReason* reason) const {
      reason->set_tag(tag);
      if (!refer_tag.empty()) reason->set_refer_tag(refer_tag);
      if (click_cnt > 0) reason->set_click_cnt(click_cnt);
      if (sum_weight > 0) reason->set_sum_weight(sum_weight);
      for (auto it = type_weights.begin(); it != type_weights.end(); ++it) {
        reason->add_reason_type(it->first);
        reason->add_type_weight(it->second);
      }
    }

    static TagMetaInfo FromCachedRecoReason(const CachedRecoReason& reason) {
      TagMetaInfo meta;
      meta.tag = reason.tag();
      if (reason.has_refer_tag()) meta.refer_tag = reason.refer_tag();
      if (reason.has_click_cnt()) meta.click_cnt = reason.click_cnt();
      if (reason.has_sum_weight()) meta.sum_weight = reason.sum_weight();
      for (int i = 0; i < reason.reason_type_size(); ++i) {
        if (RecoReason::ReasonType_IsValid(reason.reason_type(i))
            && reason.reason_type(i) < kMaxBit) {
          meta.type_bits.set(reason.reason_type(i));
          meta.type_weights.insert(
              std::make_pair(static_cast<RecoReason::ReasonType>(reason.reason_type(i)),
                             reason.type_weight(i)));
        }
      }
      return meta;
    }

    // 调用该方法，给用户的这个标签增加一个推荐的理由
    void AddTypeWeight(RecoReason::ReasonType reason_type, float w, int cnt) {
      CHECK(reason_type < 64);
      if (!type_bits.test(reason_type)) {
        type_bits.set(reason_type);
        sum_weight += w;
        type_weights[reason_type] = w;
      }
      if (cnt > click_cnt) {
        click_cnt = cnt;
      }
    }

    // 排序方法，后续如果要取标签 topN 时会用上。目前没有，因为全部是判断过阈值
    bool operator > (const TagMetaInfo& rhs) const {
      if (this->sum_weight > rhs.sum_weight) {
        return true;
      } else if (this->sum_weight < rhs.sum_weight) {
        return false;
      }

      if (this->click_cnt > rhs.click_cnt) {
        return true;
      } else if (this->click_cnt < rhs.click_cnt) {
        return false;
      }

      if (this->type_bits.count() > rhs.type_bits.count()) {
        return true;
      } else if (this->type_bits.count() < rhs.type_bits.count()) {
        return false;
      }

      return this->tag < rhs.tag;
    }
  };

  // 通过此方法增加一个用户的潜在 tag 和 理由类型
  const TagMetaInfo& AddToPotentialTag(RecoReason::ReasonType type, const std::string& tag,
                                       const std::string& refer_tag, float weight, int click_cnt=0) {
    auto& meta = potential_tags_[tag];
    meta.AddTypeWeight(type, weight, click_cnt);
    meta.tag = tag;
    meta.refer_tag = refer_tag;
    return meta;
  }

  // 用于在选择理由以后，做一些设置和打日志的工作
  void ChooseReason(uint64 item_id, RecoReason::ReasonType chosen_type,
                    const TagMetaInfo& tag_meta, int reason_type, RecoReason* reco_reason);

  // quota 判断
  bool HasQuota(const std::string& tag);
  bool HasQuota(RecoReason::ReasonType type);

  // 收集针对这个用户可能的所有推荐理由
  bool CollectPotentialReasons();

  // 解析展现历史，获得各推荐理由的展现统计值
  void ParseReasonShownHistory();

  // 剔除不适合展现的理由，形成此次推荐的理由候选
  // 不适合展现的原因包括已订阅、不喜欢、quota 不足等
  bool ChooseCandidateReasons();

  // 获取最近点击里的高频标签
  void GetRecentClickTags();

  // 获取画像里的高频标签
  void GetProfileTags();

  // 根据画像或者订阅词，获取关联标签
  // 要记录是根据哪个词关联来的
  void GetExploreTags(const std::map<std::string, float>& tag_weight);

  template <class T>
  void UpdateDelta(const T& key, int minute_delta, int refresh_delta,
                   std::map<T, std::pair<int, int> >* last_delta) {
    auto it = last_delta->find(key);
    if (it == last_delta->end()) {
      it = last_delta->insert(std::make_pair(key, std::make_pair(0, 0))).first;
    }
    auto& pr = it->second;
    if (pr.first == 0 || minute_delta < pr.first ) {
      pr.first = minute_delta;
    }

    if (pr.second == 0 || refresh_delta < pr.second) {
      pr.second = refresh_delta;
    }
  }

 private:
  // 解析点击行为的截断阈值
  static const int kMaxRecentClick = 200;
  static const int kMaxClickHourDelta = 72;
  // 解析展现行为的截断阈值
  static const int kMaxRecentShow = 2000;
  static const int kMaxShowHourDelta = 48;
  // 成为候选标签的阈值。 目前 weight 是调权后的点击，所以这两个阈值基本都是点击次数
  static const int kMinTagClickCntToBeRecoReason = 3;
  static const int kMinTagWeightToBeRecoReason = 3;

  static const std::unordered_set<int> kNewsItemTypeSet;

  const GlobalData* global_data_;
  const reco::NewsIndex* news_index_;

  const reco::user::UserInfo* user_info_;
  const UserFeature* user_feature_;
  // 这些 id 主要用来输出日志
  uint64 user_id_;
  uint64 channel_id_;

  int64 current_timestamp_;

  // pair: minute delta, refresh delta
  std::map<int, std::pair<int, int> > last_reason_type_delta_;
  std::map<std::string, std::pair<int, int> > last_core_reason_delta_;
  std::pair<int, int> last_delta_;

  // potential tags 是适合这个用户的所有标签
  std::map<std::string, TagMetaInfo> potential_tags_;
  // candidate tags 过滤了不适合此次展现的标签, 是 potential tags 的子集
  std::map<std::string, TagMetaInfo> candidate_tags_;
};
}  // namespace leafserver
}  // namespace reco
