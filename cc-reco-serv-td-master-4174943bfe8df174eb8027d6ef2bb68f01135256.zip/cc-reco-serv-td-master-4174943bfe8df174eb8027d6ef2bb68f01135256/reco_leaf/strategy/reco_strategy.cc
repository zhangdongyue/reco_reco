#include "reco/serv/reco_leaf/strategy/reco_strategy.h"

#include <algorithm>

#include "base/random/pseudo_random.h"
#include "base/time/timestamp.h"
#include "base/container/dense_hash_set.h"
#include "base/strings/string_util.h"
#include "serving_base/data_manager/data_manager.h"

#include "reco/bizc/news_map/strategy/update_news_map.h"
#include "reco/bizc/reco_index/media_quantity_assurance.h"

#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "reco/serv/reco_leaf/strategy/common/topn.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

#include "reco/serv/reco_leaf/strategy/user_feature/user_fea_extractor.h"
#include "reco/serv/reco_leaf/strategy/user_feature/category_selector.h"
#include "reco/serv/reco_leaf/strategy/user_feature/rsb_selector.h"

#include "reco/serv/reco_leaf/strategy/reco/crowd_oper/crowd_oper_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/hot/hot_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/manual/manual_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/search/search_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/jingpin/jingpin_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/personal/personal_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/porn_item/porn_item_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/interest/interest_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/personal/poi_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/session/session_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/push_relate/push_relate.h"
#include "reco/serv/reco_leaf/strategy/reco/wemedia/wemedia_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/im_card/im_card_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/scene_card/scene_card_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/hot_card/hot_card_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/goods/goods_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/picture/picture_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/third_party/third_party_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/uc/uc_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/breaking/local_breaking_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/guarantee_deliver/guarantee_deliver_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/channel_video/channel_video_reco.h"

#include "reco/serv/reco_leaf/strategy/reco/query/query_reco.h"

#include "reco/serv/reco_leaf/strategy/component/ranker/hot_ranker.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_manager.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

DEFINE_int32(max_pure_video_num_per_screen, 2, "每屏保留的视频数量");
DEFINE_int32(max_special_num_per_screen, 1, "每屏保留的专题数");
DEFINE_bool(video_distribute_reco_channel, false, "视频是否下发推荐频道");
DEFINE_bool(video_distribute_vertical_channel, false, "视频是否下发垂直频道");
DEFINE_double(video_ctr_to_news_ctr_gap, 0.03, "视频ctr和文本ctr允许的ctr差距");
DEFINE_bool(open_push_item_insert_strategy, false, "是否打开 push item 直接插入的策略");
DEFINE_bool(open_priori_item_insert_strategy, false, "是否打开 优先 item 直接插入的策略");
DEFINE_int32(low_quality_deliver_limit_num, -1, "一屏 低俗条数限制，-1 表示不限制");
DEFINE_bool(poi_distribute_reco_channel, false, "基于 POI 的新闻推荐是否下发推荐频道");
DEFINE_bool(poi_distribute_local_channel, false, "基于 POI 的新闻推荐是否下发到本地频道");
DEFINE_bool(breaking_distribute_reco_channel, false, "本地突发新闻推荐是否下发到推荐频道");
DEFINE_bool(major_city_skip_left_sceen_strategy, false, "大城市跳过左屏策略");
DEFINE_double(poi_item_ctr_gap, -0.02, "");
DEFINE_int32(guarantee_quantity_insert_start_pos, 1, "保量插入的个性化队列的起始位置");
DEFINE_int32(guarantee_quantity_insert_end_pos, 10, "保量插入的个性化队列的结束位置");
DEFINE_int64(guarantee_quantity_media_ratio, 200000, "媒体级别下发速率控制");
DEFINE_int64(guarantee_quantity_item_ratio, 100000, "文章级别下发速率控制");
DEFINE_double(guarantee_quantity_deliver_rate, 1.0f, "保量文章下发概率");
DEFINE_bool(guarantee_quantity_post_recall, true, "尽量召回保量的候选");
DEFINE_int32(recent_query_time_limit, 60, "最近x分钟内搜索的结果必出item");
DEFINE_int32(query_return_item_num, 100, "query 请求返还的最大条数");

DECLARE_string(tag_prefix);
DECLARE_bool(do_third_party_reco);
DECLARE_bool(do_uc_sid_reco);

DEFINE_int64_counter(strategy, random_reco_num, 0, "命中随机推荐的数量");

DEFINE_int64_counter(strategy, recommend_manual_reco_count, 0, "推荐运营处理count");
DEFINE_int64_counter(strategy, recommend_manual_reco_time, 0, "推荐运营处理时延");
DEFINE_int64_counter(strategy, verticle_manual_reco_count, 0, "垂直频道运营处理count");
DEFINE_int64_counter(strategy, verticle_manual_reco_time, 0, "垂直频道运营处理时延");
DEFINE_int64_counter(strategy, jingpin_manual_reco_count, 0, "精品推荐运营处理count");
DEFINE_int64_counter(strategy, jingpin_manual_reco_time, 0, "精品推荐运营处理时延");

// const std::unordered_set<std::string> RecoStrategy::force_suppress_keywords_ =
//     std::unordered_set<std::string>({"徐晓冬", "陈羽凡", "胡海峰"});
const std::unordered_set<std::string> RecoStrategy::force_suppress_keywords_ =
    std::unordered_set<std::string>();

RecoStrategy::RecoStrategy(const reco::NewsIndex* index) : news_index_(index) {
  NewsFilter::InitNewsFilter(news_index_);

  // important!!
  shown_dict_.set_empty_key(NULL);
  item_dedup_.set_empty_key(NULL);
  source_dedup_.set_empty_key("");

  interest_reco_ = new InterestReco(news_index_);
  personal_reco_ = new PersonalReco(news_index_);
  jingpin_reco_ = new JingpinReco(news_index_);
  manual_reco_ = new ManualReco(news_index_);
  search_reco_ = new SearchReco(news_index_);
  hot_reco_ = new HotReco(news_index_);
  query_reco_ = new QueryReco(news_index_);
  hot_ranker_ = new HotRanker(news_index_);
  wemedia_reco_ = new WeMediaReco();
  imcard_reco_ = new ImCardReco();
  scene_reco_ = new SceneCardReco();
  hot_card_reco_ = new HotCardReco();
  poi_reco_ = new POIReco(news_index_);
  session_reco_ = new SessionReco(news_index_);
  goods_reco_ = new GoodsReco(news_index_);
  pic_reco_ = new PictureReco(news_index_);
  third_party_reco_ = new ThirdPartyReco(news_index_);
  crowd_oper_reco_ = new CrowdOperReco(news_index_);
  uc_sid_reco_ = new UcReco(news_index_);
  local_breaking_reco_ = new LocalBreakingReco(news_index_);
  gd_reco_ = new GuaranteeDeliverReco(news_index_);
  push_relate_reco_ = new PushRelateReco(news_index_);
  porn_item_reco_ = new PornItemReco(news_index_);
  channel_video_reco_ = new ChannelVideoReco(news_index_);

  user_fea_extractor_ = new UserFeaExtractor(news_index_);
  category_selector_ = new CategorySelector(news_index_);
  rsb_selector_ = new RsbSelector();
  random_ = new base::PseudoRandom(base::GetTimestamp());

  reco_request_.personal_item_dicts = personal_reco_->GetPersonalItemDicts();

  probe_strategy_manager_ = new ProbeStrategyManager(news_index_);
  candidate_extractor_ = new CandidatesExtractor(news_index_);
}

RecoStrategy::~RecoStrategy() {
  delete personal_reco_;
  delete jingpin_reco_;
  delete interest_reco_;
  delete manual_reco_;
  delete search_reco_;
  delete hot_reco_;
  delete query_reco_;
  delete hot_ranker_;
  delete wemedia_reco_;
  delete imcard_reco_;
  delete scene_reco_;
  delete hot_card_reco_;
  delete poi_reco_;
  delete goods_reco_;
  delete pic_reco_;
  delete session_reco_;
  delete crowd_oper_reco_;
  delete user_fea_extractor_;
  delete category_selector_;
  delete rsb_selector_;
  delete random_;
  delete probe_strategy_manager_;
  delete candidate_extractor_;
  delete third_party_reco_;
  delete uc_sid_reco_;
  delete local_breaking_reco_;
  delete gd_reco_;
  delete push_relate_reco_;
}

bool RecoStrategy::GetItemProbeInfo(uint64 item_id, ProbeInfo* probe_info) const {
  return probe_strategy_manager_->GetItemProbeInfo(item_id, probe_info);
}

void RecoStrategy::GetComplexQueryNews(RecoRequest* reco_request,
                                       std::vector<ItemInfo>* items,
                                       int32 max_return) {
  items->clear();
  query_reco_->GetComplexQueryNews(reco_request, items, max_return);
}

bool RecoStrategy::ComplexChannelRecommend(const UserInfo* user_info,
                                           RecommendRequest* request,
                                           std::vector<ItemInfo>* reco_items,
                                           RecoContext* reco_context,
                                           thread::Thread* video_thread) {
  serving_base::Timer timer;
  LOG(INFO) << "ComplexChannel request:"
            << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  // 构建推荐 request
  timer.Start();
  Prepare(user_info, request, reco_context);
  reco_context->cost_trace()->pps = timer.Stop();
  // 请求 query - item 推荐
  thread::Thread query_thread;
  query_items_.clear();
  query_thread.Start(::NewCallback(this, &RecoStrategy::GetComplexQueryNews, &reco_request_,
                                   &query_items_, FLAGS_query_return_item_num));
  if (RandomReco(reco_request_, reco_items)) {
    request->set_is_random_reco(true);
    if (video_thread)
      video_thread->Join();
    query_thread.Join();
    return true;
  }

  // manual reco
  timer.Start();
  manual_data_.Clear();
  manual_reco_->GetManualItems(&reco_request_, &manual_data_, reco_context->debugger());
  reco_context->cost_trace()->mans = timer.Stop();
  COUNTERS_strategy__recommend_manual_reco_count.Increase(1);
  COUNTERS_strategy__recommend_manual_reco_time.Increase(reco_context->cost_trace()->mans/1000);

  // session reco
  timer.Start();
  session_items_.clear();
  session_reco_->DoSessionReco(&reco_request_, reco_context, &session_items_);
  reco_context->cost_trace()->ses = timer.Stop();

  // push relate strategy
  timer.Start();
  push_relate_items_.clear();
  push_relate_reco_->DoPushRelateReco(&reco_request_, &push_relate_items_);
  reco_context->cost_trace()->rels = timer.Stop();

  // hot reco
  timer.Start();
  hot_items_.clear();
  hot_reco_->GetComplexHotNews(&reco_request_, &hot_items_, kTopNSize);
  hot_ranker_->RankForComplex(&reco_request_, &hot_items_, kTopNSize);
  reco_context->debugger()->TraceHotRecoItems(hot_items_);
  ForceSuppressItem(reco_request_, &hot_items_);
  reco_context->cost_trace()->hrs = timer.Stop();

  // hot video reco
  if (FLAGS_video_distribute_reco_channel) {
    timer.Start();
    video_items_.clear();
    hot_reco_->GetComplexHotVideos(&reco_request_, &video_items_, kTopNSize);
    reco_context->debugger()->TraceVedioRecoItems(video_items_);
    ForceSuppressItem(reco_request_, &video_items_);
    reco_context->cost_trace()->hvrs = timer.Stop();
  }
  // third party reco
  trd_prt_items_.clear();
  if (FLAGS_do_third_party_reco) {
    timer.Start();
    auto iter = rsb_itemnum_map_.find(kThirdPartyRecoRSB);
    int tp_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
    if (tp_num > 0) {
      third_party_reco_->DoThirdPartyReco(&reco_request_, tp_num * 2, &trd_prt_items_, reco_context);
    } else {
      VLOG(1) << "skip third party reco, tp_num=" << tp_num;
    }
    reco_context->cost_trace()->tprs = timer.Stop();
  }

  // uc sid reco
  uc_sid_items_.clear();
  if (FLAGS_do_uc_sid_reco) {
    timer.Start();
    auto iter = rsb_itemnum_map_.find(kUcSidRecoRSB);
    int uc_sid_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
    if (uc_sid_num > 0) {
      uc_sid_reco_->DoReco(&reco_request_, &uc_sid_items_, reco_context);
    } else {
      VLOG(1) << "skip uc sid reco, uc_sid_num=" << uc_sid_num;
    }
    reco_context->cost_trace()->ucsids = timer.Stop();
  }

  // personal reco
  timer.Start();
  personal_items_.clear();
  interest_reco_->DoInterestReco(&reco_request_, &manual_data_, &personal_items_, reco_context);
  reco_context->debugger()->TracePersonalRecoItems(personal_items_);

  // crowd reco
  int32 co_insert_pos = -1;
  crowd_oper_items_.clear();
  crowd_oper_reco_->GetCrowdOperItems(reco_request_, &crowd_oper_items_,
                                      &co_insert_pos, reco_context->debugger());
  if (crowd_oper_items_.size() >= 1 && co_insert_pos >= 0) {
    personal_items_.insert(personal_items_.begin() + co_insert_pos, crowd_oper_items_[0]);
  }
  ForceSuppressItem(reco_request_, &personal_items_);
  reco_context->cost_trace()->prs = timer.Stop();

  porn_items_.clear();
  porn_item_reco_->GetPornItems(reco_request_, &porn_items_, reco_context->debugger());

  // guarantee deliver strategy
  timer.Start();
  gd_items_.clear();
  if (!GuaranteeQuantity(&personal_items_)) {  // 保量策略 1
    if (random_->GetDouble() < FLAGS_text_guarantee_deliver_ratio) {  // 保量策略 2
      gd_reco_->GetGuaranteeDeliverItems(reco_request_, &gd_items_, reco_context->debugger());
    }
  }
  reco_context->cost_trace()->gds = timer.Stop();

  // poi reco
  poi_items_.clear();
  item_poi_tags_.clear();
  if (FLAGS_poi_distribute_reco_channel) {
    timer.Start();
    auto iter = rsb_itemnum_map_.find(kLocalRSB);
    int local_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
    if (local_num > 0) {
      static const double kPOIItemCtrGap = -0.02;
      double poi_ctr_thr = GetTopNItemsAvgCtr(personal_items_, 3) + kPOIItemCtrGap;
      poi_reco_->DoPoiReco(&reco_request_, &poi_items_, &item_poi_tags_, poi_ctr_thr, kTopNSize);
      reco_context->debugger()->TracePoiRecoItems(poi_items_);
    }
    ForceSuppressItem(reco_request_, &poi_items_);
    reco_context->cost_trace()->poirs = timer.Stop();
  }

  // probe reco
  timer.Start();
  probe_items_.clear();
  if (video_thread)
    video_thread->Join();

  // TODO 动态调整
  reco_request_.probe_manual_items = &manual_data_.probe_manual_items;
  probe_strategy_manager_->GetRecoResult(news_index_, &reco_request_, 3, &probe_items_);

  probe_video_items_.clear();
  probe_strategy_manager_->GetRecoResult(news_index_, reco::kVideoProbe,
                                         &reco_request_, 2, &probe_video_items_);

  // 视频的 probe 单独拎出来
  std::vector<ItemInfo> other_probe_items;
  probe_novel_items_.clear();
  for (size_t i = 0; i < probe_items_.size(); ++i) {
    ProbeInfo probe_info;
    if (GetItemProbeInfo(probe_items_[i].item_id, &probe_info)) {
      if (probe_info.probe_type == reco::kVideoProbe) {
        probe_video_items_.push_back(probe_items_[i]);
      } else if (probe_info.probe_type == reco::kNovelProbe) {
        probe_novel_items_.push_back(probe_items_[i]);
      } else {
        other_probe_items.push_back(probe_items_[i]);
      }
    }
  }
  probe_items_.swap(other_probe_items);
  reco_context->cost_trace()->pbs = timer.Stop();

  // local breaking reco
  local_breaking_items_.clear();
  if (FLAGS_breaking_distribute_reco_channel) {
    timer.Start();
    local_breaking_reco_->GetLocalBreakingItems(reco_request_, &local_breaking_items_, &item_poi_tags_);
    reco_context->cost_trace()->lbs = timer.Stop();
  }
  // query reco
  timer.Start();
  query_thread.Join();
  reco_context->debugger()->TraceQueryRecoItems(query_items_);
  reco_context->cost_trace()->qrs = timer.Stop();

  // merge
  timer.Start();
  ComplexChannelMerge(reco_items, reco_context->debugger());
  EnforceInsertQueue(reco_items);
  reco_context->cost_trace()->mrs = timer.Stop();

  // Debug 分析
  reco_context->debugger()->PostAnalysis(*user_info, *reco_items, personal_items_);

  return true;
}

bool RecoStrategy::VerticleChannelRecommend(const UserInfo* user_info,
                                            RecommendRequest* request,
                                            std::vector<ItemInfo>* reco_items,
                                            RecoContext* context) {
  serving_base::Timer timer;
  LOG(INFO) << "VerticleChannel request:"
            << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  // 构建推荐 request
  timer.Start();
  Prepare(user_info, request, context);
  context->cost_trace()->pps = timer.Stop();

  // 防刷和 uid0 策略
  if (RandomReco(reco_request_, reco_items)) {
    request->set_is_random_reco(true);
    return true;
  }

  // manual reco
  timer.Start();
  manual_data_.Clear();
  manual_reco_->GetManualItems(&reco_request_, &manual_data_, context->debugger());
  context->cost_trace()->mans = timer.Stop();
  COUNTERS_strategy__verticle_manual_reco_count.Increase(1);
  COUNTERS_strategy__verticle_manual_reco_time.Increase(context->cost_trace()->mans/1000);

  // personal reco
  timer.Start();
  personal_items_.clear();
  if (reco_request_.channel_id == reco::common::kPictureChannelId) {
    pic_reco_->DoPicChannelReco(&reco_request_, &manual_data_, &personal_items_, context);
  } else if (reco_request_.channel_id == reco::common::kShoppingId) {
    goods_reco_->DoGoodsChannelReco(&reco_request_, &manual_data_, &personal_items_, context);
  } else if (reco_request_.channel_id == reco::common::kHotChannelId) {
    hot_reco_->DoHotChannelReco(&reco_request_, &manual_data_, &personal_items_, context);
  } else {
    // personal_reco_->DoPersonalReco(&reco_request_, &manual_data_, &personal_items_, context);
    interest_reco_->DoInterestReco(&reco_request_, &manual_data_, &personal_items_, context);
  }
  context->debugger()->TracePersonalRecoItems(personal_items_);
  context->cost_trace()->prs = timer.Stop();

  // guarantee deliver reco
  timer.Start();
  gd_items_.clear();
  if (reco_request_.channel_id != reco::common::kPictureChannelId
      && reco_request_.channel_id != reco::common::kShoppingId
      && !GuaranteeQuantity(&personal_items_)) {
    if (random_->GetDouble() < FLAGS_text_guarantee_deliver_ratio) {
      gd_reco_->GetGuaranteeDeliverItems(reco_request_, &gd_items_, context->debugger());
    }
  }
  context->cost_trace()->gds = timer.Stop();

  // get hot
  hot_items_.clear();
  if (reco_request_.channel_id != reco::common::kHotChannelId) {
    // TODO(jianhuang) 这块逻辑移到 hot reco 里
    hot_ranker_->RankForVertical(&reco_request_, &hot_items_, kTopNSize, context);
    for (size_t i = 0; i < hot_items_.size(); ++i) {
      hot_items_[i].strategy_branch = kManualBranch;
    }
    context->debugger()->TraceHotRecoItems(hot_items_);
  }

  // hot video reco
  if (FLAGS_video_distribute_vertical_channel) {
    timer.Start();
    video_items_.clear();
    auto iter = rsb_itemnum_map_.find(kVideoRSB);
    int video_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
    if (video_num > 0) {
      double video_ctr_thr = GetTopNItemsAvgCtr(personal_items_, 3) + FLAGS_video_ctr_to_news_ctr_gap;
      hot_reco_->GetVerticleHotVideos(&reco_request_, reco_request_.channel_id,
                                      &video_items_, kTopNSize, video_ctr_thr);
    }
    context->debugger()->TraceVedioRecoItems(video_items_);
    context->cost_trace()->hvrs = timer.Stop();
  }

  // poi reco
  poi_items_.clear();
  item_poi_tags_.clear();
  if (POIDeliverLocalChannel()) {
    timer.Start();
    if (!personal_items_.empty()) {
      static const double kPOIItemCtrGap = FLAGS_poi_item_ctr_gap;
      double poi_ctr_thr = GetTopNItemsAvgCtr(personal_items_, 3) + kPOIItemCtrGap;
      poi_reco_->DoPoiReco(&reco_request_, &poi_items_, &item_poi_tags_, poi_ctr_thr, kTopNSize, false);
      context->debugger()->TracePoiRecoItems(poi_items_);
    }
    context->cost_trace()->poirs = timer.Stop();
  }

  // probe reco
  timer.Start();
  probe_items_.clear();
  // TODO 动态调整
  reco_request_.probe_manual_items = &manual_data_.probe_manual_items;
  probe_strategy_manager_->GetRecoResult(news_index_, &reco_request_, 1, &probe_items_);
  context->cost_trace()->pbs = timer.Stop();

  // merge
  timer.Start();
  VerticleChannelMerge(reco_items, context->debugger());
  EnforceInsertQueue(reco_items);
  SpecialRankInVideoChannel(reco_items);
  context->cost_trace()->mrs = timer.Stop();

  // Debug 分析
  context->debugger()->PostAnalysis(*user_info, *reco_items, personal_items_);

  return true;
}

bool RecoStrategy::DoJingpinRecommend(const UserInfo* user_info,
                                      RecommendRequest* request,
                                      std::vector<ItemInfo>* reco_items,
                                      RecoContext* context) {
  serving_base::Timer timer;
  LOG(INFO) << "VerticleChannel request:"
            << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  // 构建推荐 request
  timer.Start();
  Prepare(user_info, request, context);
  context->cost_trace()->pps = timer.Stop();

  // 防刷和 uid0 策略
  if (RandomReco(reco_request_, reco_items)) {
    request->set_is_random_reco(true);
    return true;
  }

  // manual reco
  timer.Start();
  manual_data_.Clear();
  manual_reco_->GetManualItems(&reco_request_, &manual_data_, context->debugger());
  context->cost_trace()->mans = timer.Stop();
  COUNTERS_strategy__jingpin_manual_reco_count.Increase(1);
  COUNTERS_strategy__jingpin_manual_reco_time.Increase(context->cost_trace()->mans/1000);

  // personal reco
  timer.Start();
  personal_items_.clear();
  jingpin_reco_->GetJingpinItems(reco_request_, &personal_items_, context->debugger());
  context->debugger()->TracePersonalRecoItems(personal_items_);
  context->cost_trace()->prs = timer.Stop();

  // merge
  timer.Start();
  hot_items_.clear();
  probe_items_.clear();
  video_items_.clear();
  poi_items_.clear();
  VerticleChannelMerge(reco_items, context->debugger());
  context->cost_trace()->mrs = timer.Stop();

  // Debug 分析
  context->debugger()->PostAnalysis(*user_info, *reco_items, personal_items_);

  return true;
}

bool RecoStrategy::DoBeautyRecommend(const UserInfo* user_info,
                                     RecommendRequest* request,
                                     std::vector<ItemInfo>* reco_items,
                                     RecoContext* context) {
  serving_base::Timer timer;
  LOG(INFO) << "BeautyChannel request:"
            << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  // 构建推荐 request
  timer.Start();
  Prepare(user_info, request, context);
  context->cost_trace()->pps = timer.Stop();

  // 防刷和 uid0 策略
  if (RandomReco(reco_request_, reco_items)) {
    request->set_is_random_reco(true);
    return true;
  }

  // manual reco
  timer.Start();
  manual_data_.Clear();
  manual_reco_->GetManualItems(&reco_request_, &manual_data_, context->debugger());
  context->cost_trace()->mans = timer.Stop();
  COUNTERS_strategy__jingpin_manual_reco_count.Increase(1);
  COUNTERS_strategy__jingpin_manual_reco_time.Increase(context->cost_trace()->mans/1000);

  // personal reco
  timer.Start();
  personal_items_.clear();
  interest_reco_->DoInterestReco(&reco_request_, &manual_data_, &personal_items_, context);
  context->debugger()->TracePersonalRecoItems(personal_items_);
  context->cost_trace()->prs = timer.Stop();

  // merge
  timer.Start();
  hot_items_.clear();
  probe_items_.clear();
  video_items_.clear();
  // TODO: add beauty video reco xxx
  channel_video_reco_->GetChannelVideoItems(reco_request_, &video_items_, context->debugger());

  poi_items_.clear();
  VerticleChannelMerge(reco_items, context->debugger());
  context->cost_trace()->mrs = timer.Stop();

  // Debug 分析
  context->debugger()->PostAnalysis(*user_info, *reco_items, personal_items_);

  return true;
}

void RecoStrategy::SpecialRankInVideoChannel(std::vector<ItemInfo>* reco_items) {
  // 对于视频频道自动刷新的请求，前三条强制出机器视频
  VLOG(1) << "refresh_type: " << reco_request_.refresh_type;
  if (reco_request_.refresh_type == 1 &&
      reco::common::IsVideoChannel(reco_request_.channel_id)) {
    std::set<size_t> inserted_index;
    for (size_t i = 0; i < reco_items->size(); ++i) {
      if (reco_items->at(i).strategy_type != reco::kManual) {
        inserted_index.insert(i);
      }
      if (inserted_index.size() >= 3) {
        break;
      }
    }
    std::vector<ItemInfo> items;
    items.reserve(reco_items->size());
    for (auto it = inserted_index.begin(); it != inserted_index.end(); ++it) {
      VLOG(1) << "insert machine: " << reco_items->at(*it).item_id;
      items.push_back(reco_items->at(*it));
    }
    for (size_t i = 0; i < reco_items->size(); ++i) {
      if (inserted_index.find(i) != inserted_index.end()) {
        continue;
      }
      items.push_back(reco_items->at(i));
    }
    reco_items->swap(items);
  }
}

bool RecoStrategy::POIDeliverLocalChannel() {
  if (!FLAGS_poi_distribute_local_channel) return false;

  // 本地频道
  if (reco_request_.channel_id != reco::common::kLocalChannelId ||
      !reco_request_.request->has_region_id()) {
    VLOG(2) << "request not local channel";
    return false;
  }

  if (user_feas_.attr.user_district_ids.empty()) {
    VLOG(2) << "user district set empty";
    return false;
  }

  int64 adcode;
  std::string str_adcode = reco::common::RegionSearcher::instance().SearchRegionCodeCorrespondAdcode(
      reco_request_.request->region_id());
  if (!base::StringToInt64(str_adcode, &adcode)) {
    VLOG(2) << "convert to adcode fail";
    return false;
  }

  // 只对部分的城市开放
  if (!reco::news_map::UpdateNewsMap::IsNewsMapCity(adcode)) {
    VLOG(2) << "not match news map: " << adcode;
    return false;
  }

  // 本地频道的 region_id 必须与用户参数中的经纬度匹配
  bool matched = false;
  for (auto it = user_feas_.attr.user_district_ids.begin();
       it != user_feas_.attr.user_district_ids.end(); ++it) {
    if (((*it) / 100 * 100) == adcode || ((*it) / 10000 * 10000) == adcode) {
      matched = true;
      break;
    }
  }
  if (!matched) {
    VLOG(2) << "region_id and user coord not match";
    return false;
  }
  return true;
}

bool RecoStrategy::DoSubscriptionReco(const UserInfo* user_info,
                                      const RecommendRequest* request,
                                      std::vector<ItemInfo>* reco_items,
                                      std::vector<std::string>* hit_tags,
                                      RecoContext* context) {
  LOG(INFO) << "SubscriptChannel Receive reco request, "
            << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  serving_base::Timer timer;

  timer.Start();
  Prepare(user_info, request, context);
  context->cost_trace()->pps = timer.Stop();

  timer.Start();
  reco_items->clear();
  hit_tags->clear();
  bool ret = search_reco_->RecoInSubscriptChannel(&reco_request_, reco_items, hit_tags);
  context->cost_trace()->srs = timer.Stop();

  return ret;
}

void RecoStrategy::BuildUserShownDict(const UserInfo* user_info,
                                      const RecommendRequest* request) {
  // 标签主页频道，目前对不同的标签主页也统一去重。因为不同标签主页下发的内容重复度应该
  // 是很低的，目前这种做法不会有什么问题
  const bool is_channel_dedup = request->has_channel_id()
      && (request->channel_id() == reco::common::kSubscriptionChannelId
          || request->channel_id() == reco::common::kIos10PluginCustomerContentChannelId
          || request->channel_id() == reco::common::kHotChannelId
          || request->channel_id() == reco::common::kTagMainpageChannelId);

  // 建立用户历史展现，用于去重
  RecoUtils::BuildUserShownDict(news_index_, request, user_info, &shown_dict_, false, is_channel_dedup);

  return;
}

void RecoStrategy::BuildUserFeature(const UserInfo* user_info,
                                    const RecommendRequest* request) {
  // 抽取用户特征
  user_feas_.Reset(user_info);
  user_fea_extractor_->ExtractUserFeature(request, user_info, &user_feas_);
  return;
}

void RecoStrategy::Prepare(const UserInfo* user_info,
                           const RecommendRequest* request,
                           RecoContext* context) {
  /*
  size_t concurrent_num = 1;
  switch (LeafDataManager::GetGlobalData()->sys_status) {
    case kSysFree:
    case kSysNormal:
      concurrent_num = 2;
      break;
  }
  */

  thread::ThreadPool pool(2);
  pool.AddTask(::NewCallback(this, &RecoStrategy::BuildUserShownDict, user_info, request));
  pool.AddTask(::NewCallback(this, &RecoStrategy::BuildUserFeature, user_info, request));
  pool.JoinAll();
  context->debugger()->TraceUserShownDict(&shown_dict_);
  context->debugger()->TraceUserFeature(user_feas_);

  // 类别展现概率
  serving_base::Timer timer;
  timer.Start();
  category_distributes_.clear();
  category_selector_->SelectFirstCategory(request, user_info, &user_feas_, &category_distributes_);
  context->debugger()->TraceCategoryDistributes(category_distributes_);

  // 构建 reco request
  reco_request_.Reset(request, user_info, &user_feas_, &shown_dict_, &category_distributes_);
  reco_request_.can_deliver_video = CanDeliverVideo();

  // 计算各个策略分支的展现概率
  rsb_itemnum_map_.clear();
  rsb_selector_->CalcRSBReturnNumMap(request, user_info, &user_feas_, &rsb_itemnum_map_);
  context->debugger()->TraceRsbReturnNum(rsb_itemnum_map_);
  context->cost_trace()->rsbs = timer.Stop();

  // access frequency calc
  AccessFreqCalc(*user_info, &reco_request_);
}

void RecoStrategy::AccessFreqCalc(const UserInfo &user_info, RecoRequest *reco_request) {
  if (user_info.identity().user_id() == 0 || user_info.shown_history_size() == 0) {
    return;
  }

  int64 last_timestamp = 0;
  for (auto i = user_info.shown_history_size() - 1; i >= 0; --i) {
    const int64 timestamp = user_info.shown_history(i).view_timestamp();
    if (timestamp != last_timestamp) {
      last_timestamp = timestamp;
      const base::Time view_time = base::Time::FromDoubleT((double)last_timestamp / 1e6);
      const base::Time now_time = base::Time::Now();
      const base::TimeDelta delta = now_time - view_time;

      if (delta.InDays() > 0) {
        break;
      }

      // 记录 1,5,15分钟的访问频率
      if (delta.InMinutes() < 1) {
        ++(reco_request->access_frequency[0]);
      } else if (delta.InMinutes() < 5) {
        ++(reco_request->access_frequency[1]);
      } else if (delta.InMinutes() < 15) {
        ++(reco_request->access_frequency[2]);
      }

      // 统计当天的频率
      base::Time::Exploded now_exploded;
      now_time.LocalExplode(&now_exploded);
      base::Time::Exploded view_exploded;
      view_time.LocalExplode(&view_exploded);
      if (view_exploded.day_of_month == now_exploded.day_of_month) {
        ++(reco_request->today_access_cnt);
      }
    }
  }

  reco_request->access_frequency[1] += reco_request->access_frequency[0];
  reco_request->access_frequency[2] += reco_request->access_frequency[1];

  LOG(INFO) << "uid:" << user_info.identity().user_id()
            << ", today req cnt:" << reco_request->today_access_cnt
            << ", frequency:[" << reco_request->access_frequency[0]
            << "," << reco_request->access_frequency[1]
            << "," << reco_request->access_frequency[2] << "]";
  return;
}

void RecoStrategy::VerticleChannelMerge(std::vector<ItemInfo>* merged_items, RecoDebugger* debugger) {
  merged_items->clear();
  item_dedup_.clear();
  source_dedup_.clear();
  context_insert_pos_.clear();
  for (int i = 0; i < kContextRecoNum; ++i) {
    context_insert_infos_[i].Clear();
  }
  int banner_num = 0;

  // add manual
  const std::vector<ItemInfo>& top_importance_items = manual_data_.top_importance_items;
  

  int top_importance_num = 0;
  // 一级要闻
  for (size_t i = 0; i < top_importance_items.size(); ++i) {
    const ItemInfo& item = top_importance_items[i];
    // 事件专题卡片
    if (manual_data_.auto_event_card.IsAutoEventCard(item.item_id)) {
      reco::ItemInfo may_decay_item = item;
      if (manual_data_.auto_event_card.CanAssembleCard(&item_dedup_, &may_decay_item)) {
        ++top_importance_num;
        merged_items->push_back(may_decay_item);
      } else {
        debugger->SetItemFilterReason(item.item_id, reco::filter::kNotHasEnoughCandidateFiltered);
      }
      continue;
    }
    // 普通新闻
    reco::filter::FilterReason filter_reason;
    if (CanAddToResultSet(item, &filter_reason)) {
      if (item.strategy_type == reco::kBanner) {
        // banner 不计入运营下发中
        ++banner_num;
      } else {
        ++top_importance_num;
      }
      merged_items->push_back(item);
    } else {
      debugger->SetItemFilterReason(item.item_id, filter_reason);
    }
  }

  // 实际返回的是 请求条数 + banner 的条数
  int total_return_num = reco_request_.request->return_num() + banner_num;
  auto iter = rsb_itemnum_map_.find(kManualRSB);
  int manual_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  int personal_num = total_return_num - manual_num;
  if (static_cast<int>(personal_items_.size()) < personal_num) {
    personal_num = personal_items_.size();
    manual_num = total_return_num - personal_num;
  }

  manual_num -= top_importance_num;
  // 二级要闻
  const std::vector<ItemInfo>& snd_importance_items = manual_data_.snd_importance_items;
  for (size_t i = 0; i < snd_importance_items.size(); ++i) {
    if (manual_num <= 0) break;
    // 事件专题卡片
    const ItemInfo& item = snd_importance_items[i];
    if (manual_data_.auto_event_card.IsAutoEventCard(item.item_id)) {
      reco::ItemInfo may_decay_item = item;
      if (manual_data_.auto_event_card.CanAssembleCard(&item_dedup_, &may_decay_item)) {
        merged_items->push_back(may_decay_item);
        --manual_num;
      } else {
        debugger->SetItemFilterReason(item.item_id, reco::filter::kNotHasEnoughCandidateFiltered);
      }
      continue;
    }
    // 普通新闻
    reco::filter::FilterReason filter_reason;
    if (CanAddToResultSet(item, &filter_reason)) {
      if (item.strategy_type == reco::kBanner) {
        // banner 不计入运营下发中
        ++banner_num;
      } else {
        --manual_num;
      }
      merged_items->push_back(item);
    } else {
      debugger->SetItemFilterReason(item.item_id, filter_reason);
    }
  }

  // add hot
  int max_hot_num = 3;
  int add_hot_num = 0;
  if (hot_ranker_->GetChannelPrevReqHours(reco_request_.user_info, reco_request_.current_time,
                                          reco_request_.channel_id) < 8) {
    max_hot_num = 1;
  }
  for (size_t i = 0; i < hot_items_.size(); ++i) {
    if (add_hot_num >= max_hot_num) break;
    const ItemInfo& item = hot_items_[i];
    reco::filter::FilterReason filter_reason;
    if (CanAddToResultSet(item, &filter_reason)) {
      ++add_hot_num;
      merged_items->push_back(item);
    } else {
      debugger->SetItemFilterReason(item.item_id, filter_reason);
    }
  }

  // add probe based reco items
  iter = rsb_itemnum_map_.find(kProbeRSB);
  int probe_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  for (size_t i = 0; i < probe_items_.size(); ++i) {
    if (probe_num <= 0) break;
    const ItemInfo& item = probe_items_[i];
    reco::filter::FilterReason filter_reason;
    if (CanAddToResultSet(item, &filter_reason)) {
      merged_items->push_back(item);
      --probe_num;
      LOG(INFO) << "add probe item: uid=" << user_feas_.user_info->identity().user_id()
                << ", item_id=" << item.item_id;
    } else {
      debugger->SetItemFilterReason(item.item_id, filter_reason);
    }
  }
  // add video
  iter = rsb_itemnum_map_.find(kVideoRSB);
  int video_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  video_num = std::min(video_num, FLAGS_max_pure_video_num_per_screen);
  video_num = std::min(video_num, (int)video_items_.size());
  if (video_num > 0) {
    ContextRecoInsertInfo &video_insert_info = context_insert_infos_[kVideoContextReco];
    video_insert_info.context_items = &video_items_;
    video_insert_info.context_insert_num = video_num;

    // 机器占比超过 50% 时下发视频
    if ((float)manual_num / total_return_num <= 0.5 && personal_num > 0) {
      double video_rate = (float)video_num / personal_num;
      int inserted_num = 0;
      for (int i = 0; i <= personal_num && inserted_num < video_num; ++i) {
        double random_rate = random_->GetDouble();
        // 按命中视频概率插入 [0, video_rate)
        if (random_rate < video_rate) {
          context_insert_pos_.insert(std::make_pair(i, kVideoContextReco));
          inserted_num++;
          VLOG(1) << "insert video context reco: " << i;
        }
      }
    }
  }

  // add poi items
  if (!poi_items_.empty()) {
    // 随机下发 2 到 3 条
    int poi_num = (random_->GetDouble()) < 0.5 ? 2 : 3;
    poi_num = std::min((int)poi_items_.size(), poi_num);

    ContextRecoInsertInfo &poi_insert_info = context_insert_infos_[kPOIContextReco];
    poi_insert_info.context_items = &poi_items_;
    poi_insert_info.context_insert_num = poi_num;
    int last_pos = 0;
    for (int i = 0; i < poi_num; ++i) {
      // 与上一条插入的位置间隔三条以内
      int pos = random_->GetInt(last_pos, last_pos + 3);
      while (true) {
        if (context_insert_pos_.find(pos) != context_insert_pos_.end()) {
          ++pos;
          continue;
        }
        context_insert_pos_.insert(std::make_pair(pos, kPOIContextReco));
        VLOG(1) << "insert poi context reco: " << pos;
        break;
      }
      last_pos = pos + 1;
    }
  }

  // 在最后的位置上插入保量的结果
  if (gd_items_.size() > 0 && total_return_num >= (int32)merged_items->size() + 1) {
    ContextRecoInsertInfo &gd_insert_info = context_insert_infos_[kGuaranteeContextReco];
    gd_insert_info.context_items = &gd_items_;
    gd_insert_info.context_insert_num = 1;
    context_insert_pos_.insert(std::make_pair(total_return_num - (int32)merged_items->size() - 1,
                                              kGuaranteeContextReco));
    VLOG(1) << "insert gd items: " << total_return_num - (int32)merged_items->size() - 1;
  }

  InsertContextRecoToPersonalReco(merged_items, total_return_num);
  debugger->TraceFirstComplexMergeItems(*merged_items);

  if (RecoUtils::IsSpecialOperChannel(reco_request_.channel_id)) {
    // do nothing
  } else if (!reco::common::IsVideoChannel(reco_request_.channel_id)) {
    AdjustByRulesInVerticleChannel(merged_items);
  } else {
    // TODO(jianhuang) video rule
  }
  debugger->TraceAdjustByRuleMergeItems(*merged_items);

  // 截断
  if ((int)merged_items->size() > total_return_num) {
    merged_items->resize(total_return_num);
  }
}

void RecoStrategy::ComplexChannelMerge(std::vector<ItemInfo>* merged_items,
                                       RecoDebugger* debugger) {
  merged_items->clear();
  item_dedup_.clear();
  source_dedup_.clear();
  context_insert_pos_.clear();
  for (int i = 0; i < kContextRecoNum; ++i) {
    context_insert_infos_[i].Clear();
  }

  // add banner
  int banner_num = 0;
  const std::vector<ItemInfo>& top_importance_items = manual_data_.top_importance_items;
  for (size_t i = 0; i < top_importance_items.size(); ++i) {
    const ItemInfo& item = top_importance_items[i];
    if (item.strategy_type != reco::kBanner) break;
    // 事件专题卡片
    if (manual_data_.auto_event_card.IsAutoEventCard(item.item_id)) {
      reco::ItemInfo may_decay_item = item;
      if (manual_data_.auto_event_card.CanAssembleCard(&item_dedup_, &may_decay_item)) {
        ++banner_num;
        merged_items->push_back(may_decay_item);
      } else {
        debugger->SetItemFilterReason(item.item_id, reco::filter::kNotHasEnoughCandidateFiltered);
      }
      continue;
    }
    // 普通新闻
    reco::filter::FilterReason filter_reason;
    if (CanAddToResultSet(item, &filter_reason)) {
      ++banner_num;
      merged_items->push_back(item);
    } else {
      debugger->SetItemFilterReason(item.item_id, filter_reason);
    }
  }

  // 一级要闻
  int top_importance_num = 0;
  for (size_t i = 0; i < top_importance_items.size(); ++i) {
    const ItemInfo& item = top_importance_items[i];
    if (item.strategy_type == reco::kBanner) {
      debugger->SetItemFilterReason(item.item_id, reco::filter::kHitLeftFiltered);
      continue;
    }
    reco::filter::FilterReason filter_reason;
    if (RecoUtils::IsAutoAssembleCardItem(news_index_, item)) {
      if (manual_data_.morning_evening_auto_card.IsAssembleCard(item.item_id)) {
        // 尝试自动生成卡片
        if (manual_data_.morning_evening_auto_card.CanAssembleCard(&item_dedup_, &filter_reason)) {
          ++top_importance_num;
          merged_items->push_back(item);
        } else {
          debugger->SetItemFilterReason(item.item_id, filter_reason);
        }
      }
      continue;
    } else if (manual_data_.auto_event_card.IsAutoEventCard(item.item_id)) {
      reco::ItemInfo may_decay_item = item;
      if (manual_data_.auto_event_card.CanAssembleCard(&item_dedup_, &may_decay_item)) {
        ++top_importance_num;
        merged_items->push_back(may_decay_item);
      } else {
        debugger->SetItemFilterReason(item.item_id, reco::filter::kNotHasEnoughCandidateFiltered);
      }
      continue;
    }
    if (CanAddToResultSet(item, &filter_reason)) {
      ++top_importance_num;
      merged_items->push_back(item);
    } else {
      debugger->SetItemFilterReason(item.item_id, filter_reason);
    }
  }

  // add whole
  // 左屏情况不出全量运营文章
  int manual_num = 0;
  if (reco_request_.request->refresh_type() != 2
      || (FLAGS_major_city_skip_left_sceen_strategy && reco_request_.user_param_info.is_main_city)) {
    auto iter = rsb_itemnum_map_.find(kManualRSB);
    manual_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  }

  manual_num -= top_importance_num;
  // 二级要闻
  const std::vector<ItemInfo>& snd_importance_items = manual_data_.snd_importance_items;
  for (size_t i = 0; i < snd_importance_items.size(); ++i) {
    if (manual_num <= 0) break;
    const ItemInfo& item = snd_importance_items[i];
    if (item.strategy_type == reco::kBanner) {
      debugger->SetItemFilterReason(item.item_id, reco::filter::kHitLeftFiltered);
      continue;
    }
    if (manual_data_.auto_event_card.IsAutoEventCard(item.item_id)) {
      reco::ItemInfo may_decay_item = item;
      if (manual_data_.auto_event_card.CanAssembleCard(&item_dedup_, &may_decay_item)) {
        ++top_importance_num;
        merged_items->push_back(may_decay_item);
      } else {
        debugger->SetItemFilterReason(item.item_id, reco::filter::kNotHasEnoughCandidateFiltered);
      }
      continue;
    }
    reco::filter::FilterReason filter_reason;
    if (CanAddToResultSet(item, &filter_reason)) {
      --manual_num;
      merged_items->push_back(item);
    } else {
      debugger->SetItemFilterReason(item.item_id, filter_reason);
    }
  }

  int porn_num = 1;
  // 左屏强插：小说更新提醒，色情结果
  if (reco_request_.request->refresh_type() == 2) {
    if (!probe_novel_items_.empty()) {
      const ItemInfo& item = probe_novel_items_[0];
      reco::filter::FilterReason filter_reason;
      ProbeInfo probe_info;
      if (CanAddToResultSet(item, &filter_reason)) {
        merged_items->push_back(item);
        VLOG(1) << "add novel notice: uid=" << user_feas_.user_info->identity().user_id()
                << ", item_id=" << item.item_id
                << ", reco_strategy=" << item.strategy_type
                << ", index=" << merged_items->size();
      } else {
        debugger->SetItemFilterReason(item.item_id, filter_reason);
        VLOG(1) << "can not add to result set: uid=" << user_feas_.user_info->identity().user_id()
                << ", item_id=" << item.item_id;
      }
    }
    if (!porn_items_.empty()) {
      const ItemInfo& item = porn_items_[0];
      reco::filter::FilterReason filter_reason;
      ProbeInfo probe_info;
      if (CanAddToResultSet(item, &filter_reason)) {
        merged_items->push_back(item);
        --porn_num;
        VLOG(1) << "add porn reco: uid=" << user_feas_.user_info->identity().user_id()
                << ", item_id=" << item.item_id
                << ", reco_strategy=" << item.strategy_type
                << ", index=" << merged_items->size();
      } else {
        debugger->SetItemFilterReason(item.item_id, filter_reason);
        VLOG(1) << "can not add to result set: uid=" << user_feas_.user_info->identity().user_id()
                << ", item_id=" << item.item_id;
      }
    }
  }

  // 实际返回的是 请求条数 + banner 的条数
  const int total_return_num = reco_request_.request->return_num() + banner_num;

  // UC SID 推荐结果
  auto iter = rsb_itemnum_map_.find(kUcSidRecoRSB);
  int uc_sid_reco_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  for (size_t i = 0; i < uc_sid_items_.size(); ++i) {
    if (uc_sid_reco_num <= 0) break;
    const ItemInfo& item = uc_sid_items_[i];
    reco::filter::FilterReason filter_reason;
    if (CanAddToResultSet(item, &filter_reason)) {
      --uc_sid_reco_num;
      merged_items->push_back(item);
      VLOG(1) << "add uc sid reco result: item_id=" << item.item_id;
    } else {
      debugger->SetItemFilterReason(item.item_id, filter_reason);
    }
  }

  //add session reco result
  if (!session_items_.empty()) {
    std::stringstream log_str;
    int added = 0;
    int filtered = 0;
    for (size_t i = 0; i < session_items_.size(); ++i) {
      const ItemInfo& item = session_items_[i];
      reco::filter::FilterReason filter_reason;
      if (CanAddToResultSet(item, &filter_reason)) {
        merged_items->push_back(item);
        added += 1;
        log_str << "add item:" << item.item_id << ",";
      } else {
        filtered += 1;
        log_str << "filter item: f-" << filter_reason << "-" <<  item.item_id << ",";
      }
    }
    VLOG(1) << "user[" << reco_request_.user_info->identity().user_id()
              << "], session reco merge: <added: " << added << " filtered: "
              << filtered << ">"  << log_str.str();
  }

  // 第三方推荐结果
  iter = rsb_itemnum_map_.find(kThirdPartyRecoRSB);
  int tp_reco_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  for (size_t i = 0; i < trd_prt_items_.size(); ++i) {
    if (tp_reco_num <= 0) break;
    const ItemInfo& item = trd_prt_items_[i];
    reco::filter::FilterReason filter_reason;
    if (CanAddToResultSet(item, &filter_reason)) {
      --tp_reco_num;
      merged_items->push_back(item);
      VLOG(1) << "add tp reco result: item_id=" << item.item_id;
    } else {
      debugger->SetItemFilterReason(item.item_id, filter_reason);
    }
  }
  // add query
  iter = rsb_itemnum_map_.find(kQueryRecoRSB);
  int32 query_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  std::unordered_map<std::string, int32> query_push_times;
  if (query_num != 0) {
    for (size_t i = 0; i < query_items_.size(); ++i) {
      if (query_num <= 0) break;
      const ItemInfo& item = query_items_[i];
      auto query_times_iter = query_push_times.find(item.ir_word);
      if (query_times_iter != query_push_times.end() && query_times_iter->second >= 1) continue;
      reco::filter::FilterReason filter_reason;
      if (QueryRecoCanAddToResultSet(item, &filter_reason)) {
        --query_num;
        merged_items->push_back(item);
        query_push_times.insert(std::make_pair(item.ir_word, 1));
      } else {
        debugger->SetItemFilterReason(item.item_id, filter_reason);
      }
    }
  } else {
    // 对于半小时内的搜索 必定出一条结果
    query_num = 1;
    const base::Time now_time = base::Time::Now();
    for (size_t i = 0; i < query_items_.size(); ++i) {
      if (query_num <= 0) break;
      const ItemInfo& item = query_items_[i];
      base::Time query_time = base::Time::FromDoubleT(double(item.query_time) / 1e6);
      const base::TimeDelta delta = now_time - query_time;
      if (delta.InMinutes() > FLAGS_recent_query_time_limit) continue;
      auto query_times_iter = query_push_times.find(item.ir_word);
      if (query_times_iter != query_push_times.end() && query_times_iter->second >= 1) continue;
      reco::filter::FilterReason filter_reason;
      if (QueryRecoCanAddToResultSet(item, &filter_reason)) {
        --query_num;
        merged_items->push_back(item);
        query_push_times.insert(std::make_pair(item.ir_word, 1));
      } else {
        debugger->SetItemFilterReason(item.item_id, filter_reason);
      }
    }
  }
  // add hot
  iter = rsb_itemnum_map_.find(kHotRSB);
  int hot_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  for (size_t i = 0; i < hot_items_.size(); ++i) {
    if (hot_num <= 0) break;
    const ItemInfo& item = hot_items_[i];
    reco::filter::FilterReason filter_reason;
    if (CanAddToResultSet(item, &filter_reason)) {
      --hot_num;
      merged_items->push_back(item);
    } else {
      debugger->SetItemFilterReason(item.item_id, filter_reason);
    }
  }

  // add probe based reco items
  iter = rsb_itemnum_map_.find(kProbeRSB);
  int probe_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  for (size_t i = 0; i < probe_items_.size(); ++i) {
    if (probe_num <= 0) break;
    const ItemInfo& item = probe_items_[i];
    reco::filter::FilterReason filter_reason;
    if (CanAddToResultSet(item, &filter_reason)) {
      merged_items->push_back(item);
      --probe_num;
      VLOG(1) << "add probe item: uid=" << user_feas_.user_info->identity().user_id()
              << ", item_id=" << item.item_id;
    } else {
      debugger->SetItemFilterReason(item.item_id, filter_reason);
    }
  }

  // add probe video
  iter = rsb_itemnum_map_.find(kProbeVideoRSB);
  int probe_video_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  probe_video_num = std::min(probe_video_num, FLAGS_max_pure_video_num_per_screen);
  probe_video_num = std::min(probe_video_num, (int)probe_video_items_.size());
  if (probe_video_num > 0) {
    ContextRecoInsertInfo &video_insert_info = context_insert_infos_[kVideoContextReco];
    video_insert_info.context_items = &probe_video_items_;
    video_insert_info.context_insert_num = probe_video_num;

    std::vector<int> insert_index = {1, 3};
    for (int i = 0; i < probe_video_num; ++i) {
      const ItemInfo& item = probe_video_items_[i];
      VLOG(1) << user_feas_.user_info->identity().user_id() << " probe video candidate: " << item.item_id;
      if (i < (int)insert_index.size()) {
        context_insert_pos_.insert(std::make_pair(insert_index[i], kVideoContextReco));
        VLOG(1) << user_feas_.user_info->identity().user_id()
                << " insert probe video context reco: " << insert_index[i];
      }
    }
  }

  // add humor
  iter = rsb_itemnum_map_.find(kHumorRSB);
  int humor_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  auto manual_humor_iter = manual_data_.category_whole_items.find(reco::common::kHumorCategory);
  if (humor_num > 0 && manual_humor_iter != manual_data_.category_whole_items.end()) {
    const std::vector<ItemInfo>& humor_whole_items = manual_humor_iter->second;
    for (size_t i = 0; i < humor_whole_items.size(); ++i) {
      if (humor_num <= 0) break;
      const ItemInfo& item = humor_whole_items[i];
      reco::filter::FilterReason filter_reason;
      if (CanAddToResultSet(item, &filter_reason)) {
        --humor_num;
        merged_items->push_back(item);
      } else {
        debugger->SetItemFilterReason(item.item_id, filter_reason);
      }
    }
  }

  // add poi items
  iter = rsb_itemnum_map_.find(kLocalRSB);
  int local_num = iter != rsb_itemnum_map_.end() ? iter->second : 0;
  int poi_num = std::min((int)poi_items_.size(), local_num);
  if (poi_num > 0) {
    double prob = poi_items_[0].ctr * 10;
    if (random_->GetDouble() < prob) {
      poi_num = std::min(poi_num, 1);
      ContextRecoInsertInfo &poi_insert_info = context_insert_infos_[kPOIContextReco];
      poi_insert_info.context_items = &poi_items_;
      poi_insert_info.context_insert_num = poi_num;
      int pos = 0;
      if (merged_items->size() < 3) {
        pos = random_->GetDouble() < 0.5 ? 3 : 4;
      }
      context_insert_pos_.insert(std::make_pair(pos, kPOIContextReco));
      VLOG(1) << "insert poi item: " << pos << ", " << merged_items->size() << ", " << poi_items_.size();
    }
  }

  // // add porn item
  // for (size_t i = 0; i < porn_items_.size(); ++i) {
  //   if (porn_num <= 0) break;
  //   const ItemInfo& item = porn_items_[i];
  //   VLOG(1) << "try add porn item: " << item.item_id;
  //   reco::filter::FilterReason filter_reason;
  //   if (CanAddToResultSet(item, &filter_reason)) {
  //     --porn_num;
  //     merged_items->push_back(item);
  //     VLOG(1) << "porn item added " << item.item_id;
  //   } else {
  //     VLOG(1) << "porn item cannot add " << filter_reason;
  //     debugger->SetItemFilterReason(item.item_id, filter_reason);
  //   }
  // }

  // add local breaking, replace poi item if exists
  if (local_breaking_items_.size() > 0) {
    ContextRecoInsertInfo& poi_insert_info = context_insert_infos_[kPOIContextReco];
    bool poi_ok = false;
    if (poi_insert_info.context_items != NULL && poi_insert_info.context_insert_num > 0) {
      poi_ok = true;
    }
    poi_insert_info.context_items = &local_breaking_items_;
    poi_insert_info.context_insert_num = 1;
    if (!poi_ok) {
      int pos = 0;
      if (merged_items->size() < 3) {
        pos = random_->GetDouble() < 0.5 ? 3 : 4;
      }
      context_insert_pos_.insert(std::make_pair(pos, kPOIContextReco));
      VLOG(1) << "insert local breaking item: " << pos << ", " << merged_items->size() << ", " << local_breaking_items_.size();
    }
  }

  // 在最后的位置上插入保量的结果
  if (gd_items_.size() > 0 && total_return_num >= (int32)merged_items->size() + 1) {
    ContextRecoInsertInfo &gd_insert_info = context_insert_infos_[kGuaranteeContextReco];
    gd_insert_info.context_items = &gd_items_;
    gd_insert_info.context_insert_num = 1;
    context_insert_pos_.insert(std::make_pair((total_return_num - (int32)merged_items->size() - 1),
                                              kGuaranteeContextReco));
    VLOG(1) << "insert gd items: " << (total_return_num - (int32)merged_items->size() - 1);
  }

  // add personal items
  InsertContextRecoToPersonalReco(merged_items, total_return_num);
  debugger->TraceFirstComplexMergeItems(*merged_items);

  // 业务规则
  AdjustByRulesInComplexChannel(merged_items);
  debugger->TraceAdjustByRuleMergeItems(*merged_items);

  // 截断
  if ((int)merged_items->size() > total_return_num) {
    merged_items->resize(total_return_num);
  }
}

void RecoStrategy::InsertContextRecoToPersonalReco(std::vector<ItemInfo>* merged_items,
                                                   int total_return_num) {
  int context_count = 0;
  int personal_count = 0;
  int rank = -1;
  while (personal_count < (int)personal_items_.size()
         || context_count < (int)context_insert_pos_.size()) {
    ++rank;
    bool put_item = false;

    // 插入场景化推荐内容
    auto context_iter = context_insert_pos_.find(rank);
    if (context_iter != context_insert_pos_.end()) {
      ++context_count;
      auto &context_reco_insert_info = context_insert_infos_[context_iter->second];
      const ItemInfo *context_item = NULL;
      if (context_reco_insert_info.context_insert_num > 0) {
        while ((context_item = context_reco_insert_info.GetNext()) != NULL) {
          reco::filter::FilterReason filter_reason;
          if (CanAddToResultSet(*context_item, &filter_reason)) {
            --context_reco_insert_info.context_insert_num;
            merged_items->push_back(*context_item);
            put_item = true;
            VLOG(1) << "insert context item: " << context_item->item_id
                    << ", " << rank << ", " << merged_items->size();
            break;
          } else {
            VLOG(1) << "filtered context item: " << context_item->item_id << " reason: " << filter_reason;
          }
        }
      }
    }
    if (put_item) continue;

    // add personal items
    while (personal_count < (int)personal_items_.size()) {
      const ItemInfo& item = personal_items_[personal_count++];
      reco::filter::FilterReason filter_reason;
      if (CanAddToResultSet(item, &filter_reason)) {
        merged_items->push_back(item);
        put_item = true;
        VLOG(1) << "insert person item: " << item.item_id
                << ", " << rank << ", " << merged_items->size();
        break;
      }
    }
  }
}

void RecoStrategy::AdjustByRulesInComplexChannel(std::vector<ItemInfo>* reco_items) {
  if (reco_items->size() <= 2u) {
    return;
  }
  // 频道导流样式的下发规则:
  // 1. 不在第一条下发.
  // 2. 不和专题组合卡片连续下发（必须隔开）。
  bool is_special = RecoUtils::IsSpecialItem(news_index_, reco_items->at(0));
  if (is_special) {
    bool is_channel_daoliu = RecoUtils::IsChannelDaoliuItem(news_index_, reco_items->at(1));
    if (is_channel_daoliu) {
      std::swap(reco_items->at(1), reco_items->at(2));
    }
  } else {
    bool is_channel_daoliu = RecoUtils::IsChannelDaoliuItem(news_index_, reco_items->at(0));
    if (is_channel_daoliu) {
      std::swap(reco_items->at(0), reco_items->at(1));
    }
  }
  // TODO(Jianhuang) 条数的限制可以统一，避免多次拷贝
  // 限制专题条数
  SpecialNumLimitRule(reco_items);
  // 限制视频条数
  VideoNumLimitRule(reco_items);
  // 低俗条数限制
  LowQualityNumLimitRule(reco_items);
  // 视频不连续出现
  ContinuousVideoLimitRule(reco_items);
  // 根据刷新类型调整排序
  AdjustRankByRefreshType(reco_items);
}


void RecoStrategy::AdjustRankByRefreshType(std::vector<ItemInfo>* reco_items) {
  if (reco_request_.request->refresh_type() != 2 || reco_items->size() <= 3u) return;

  if (FLAGS_major_city_skip_left_sceen_strategy && reco_request_.user_param_info.is_main_city) return;

  // 置顶的位置雷打不动
  size_t start_rerank_pos = reco_items->size();
  for (size_t idx = 0; idx < reco_items->size(); ++idx) {
    const ItemInfo& item = reco_items->at(idx);
    if (item.strategy_type == reco::kBanner) continue;
    if (item.strategy_type == reco::kManual && reco_request_.user_param_info.is_main_city) continue;
    if (item.strategy_type == reco::kPornUserDeliver) continue;
    start_rerank_pos = idx;
    break;
  }

  // 第一条是多图并且是用户最感兴趣的类别
  std::string first_category;
  if (category_distributes_.size() >= 1u) {
    first_category = category_distributes_[0].second.category();
  }
  for (size_t idx = start_rerank_pos; idx < 15 + start_rerank_pos && idx < reco_items->size(); ++idx) {
    const ItemInfo& item = reco_items->at(idx);
    int32 image_num = news_index_->GetImageCountByItemId(item.item_id);
    if (image_num >= 3 && image_num < 255
        && first_category == item.category
        && item.strategy_type != reco::kManual) {
      if (idx != start_rerank_pos) {
        std::swap(reco_items->at(start_rerank_pos), reco_items->at(idx));
      }
      break;
    }
  }

  // 前三条分别三个用户最感兴趣的类别
  for (size_t i = 0; i < 3u && i < category_distributes_.size(); ++i) {
    const size_t idx = start_rerank_pos + i;
    if (idx >= reco_items->size()) break;
    const ItemInfo& org_item = reco_items->at(idx);
    if (org_item.category == category_distributes_[i].second.category()
        && org_item.strategy_type != reco::kManual) continue;
    for (size_t jdx = idx + 1; jdx < reco_items->size(); ++jdx) {
      const ItemInfo& new_item = reco_items->at(jdx);
      if (new_item.category == category_distributes_[i].second.category()
          && new_item.strategy_type != reco::kManual) {
        std::swap(reco_items->at(idx), reco_items->at(jdx));
        break;
      }
    }
  }
}

void RecoStrategy::AdjustByRulesInVerticleChannel(std::vector<ItemInfo>* items) {
  // 限制专题条数
  SpecialNumLimitRule(items);
  // 限制视频条数
  VideoNumLimitRule(items);
  // 视频不连续出现
  ContinuousVideoLimitRule(items);
}

void RecoStrategy::LowQualityNumLimitRule(std::vector<ItemInfo>* items) {
  if (FLAGS_low_quality_deliver_limit_num < 0
      || items->size() <= reco_request_.request->return_num()) return;

  // 色情用户, 放开限制
  const UserFeature* user_feas = reco_request_.user_feas;
  if (user_feas->attr.dirty_level == kDirtyVeryHigh
      || user_feas->attr.dirty_level == kDirtyHigh) return;

  // 晚上时间, 放开限制
  base::Time::Exploded exploded;
  reco_request_.current_time.LocalExplode(&exploded);
  if (exploded.hour <= 5 || exploded.hour >= 21)  return;

  // 规则限制
  std::vector<ItemInfo> swap_item_vec;
  std::vector<size_t> filter_idx_vec;
  int low_quality_count = 0;
  reco::ContentAttr content_attr;
  for (size_t i = 0u; i < items->size(); ++i) {
    const ItemInfo& item = items->at(i);
    bool is_low_quality = IsLowQualityItem(item, &content_attr);
    if (is_low_quality) {
      if (low_quality_count >= FLAGS_low_quality_deliver_limit_num) {
        filter_idx_vec.push_back(i);
        continue;
      }
      ++low_quality_count;
    }
    swap_item_vec.push_back(item);
  }
  // 加到末尾
  for (size_t idx = 0; idx < filter_idx_vec.size(); ++idx) {
    if (swap_item_vec.size() >= 2 * reco_request_.request->return_num()) break;
    swap_item_vec.push_back(items->at(filter_idx_vec[idx]));
  }

  items->swap(swap_item_vec);
}

void RecoStrategy::ContinuousVideoLimitRule(std::vector<ItemInfo>* items) {
  // 视频不连续出现
  for (size_t idx = 1; idx < items->size(); ++idx) {
    const ItemInfo& item = items->at(idx);
    const ItemInfo& prev_item = items->at(idx - 1);
    if (item.item_type != reco::kPureVideo
        || prev_item.item_type != reco::kPureVideo) {
      continue;
    }
    for (size_t jdx = idx + 1; jdx < items->size(); ++jdx) {
      const ItemInfo& swap_item = items->at(jdx);
      if (swap_item.item_type != reco::kPureVideo) {
        std::swap(items->at(idx), items->at(jdx));
        break;
      }
    }
  }
}

void RecoStrategy::VideoNumLimitRule(std::vector<ItemInfo>* items) {
  if (items->size() <= reco_request_.request->return_num()) return;

  std::vector<ItemInfo> swap_item_vec;
  std::vector<size_t> filter_idx_vec;
  int acc_video_count = 0;
  for (size_t i = 0u; i < items->size(); ++i) {
    const ItemInfo& item = items->at(i);
    int video_count = RecoUtils::GetPureVideoNum(news_index_, item) > 0 ? 1 : 0;
    if (video_count > 0
        && item.strategy_type != reco::kBanner
        && acc_video_count + video_count > FLAGS_max_pure_video_num_per_screen) {
      filter_idx_vec.push_back(i);
      continue;
    }
    swap_item_vec.push_back(item);
    acc_video_count += video_count;
  }
  // 加到末尾
  for (size_t idx = 0; idx < filter_idx_vec.size(); ++idx) {
    if (swap_item_vec.size() >= 2 * reco_request_.request->return_num()) break;
    swap_item_vec.push_back(items->at(filter_idx_vec[idx]));
  }
  items->swap(swap_item_vec);
}

void RecoStrategy::SpecialNumLimitRule(std::vector<ItemInfo>* reco_items) {
  if (reco::common::IsAudioChannel(reco_request_.channel_id)) return;
  if (reco_items->size() <= reco_request_.request->return_num()) return;
  std::vector<ItemInfo> swap_item_vec;
  int acc_special_count = 0;
  for (size_t i = 0; i < reco_items->size(); ++i) {
    const ItemInfo& item = reco_items->at(i);
    bool is_special = (RecoUtils::IsSpecialItem(news_index_, item)
                       || RecoUtils::IsBigPicStyleItem(news_index_, item));
    if (is_special
        && item.strategy_type != reco::kBanner
        && acc_special_count >= FLAGS_max_special_num_per_screen) continue;
    swap_item_vec.push_back(item);
    if (is_special) {
      acc_special_count += 1;
    }
  }
  // 放到结果集合
  reco_items->swap(swap_item_vec);
}

inline bool RecoStrategy::IsLowQualityItem(const ItemInfo& item, reco::ContentAttr* content_attr) const {
  // NOTE(jianhuang) 两性情感暂时不算 dirty, 如果能出就是该用户特有的属性
  if (item.category == reco::common::kBoudoirCategory) return false;

  bool is_trival = true;
  if (news_index_->GetContentAttrByDocId(item.doc_id, content_attr, &is_trival) && !is_trival) {
    // if (content_attr->has_bluffing_title()
    //     && content_attr->bluffing_title() >= reco::ContentAttr::kSuspect) {
    //   return true;
    // }
    if (content_attr->has_dirty()
        && content_attr->dirty() >= reco::ContentAttr::kSuspect) {
      return true;
    }
  }

  return false;
}

double RecoStrategy::GetTopNItemsAvgCtr(const std::vector<ItemInfo> &items, int n) {
  n = std::min(int(items.size()), n);
  if (n == 0) {
    return 0;
  }
  double ctr = 0.0;
  for (int i = 0; i < n ; ++i) {
    ctr += items[i].ctr;
  }
  return ctr / n;
}

bool RecoStrategy::QueryRecoCanAddToResultSet(const ItemInfo& item, reco::filter::FilterReason* filter_reason) {
  if (NewsFilter::IsDeduped(item, &item_dedup_)) {
    *filter_reason = reco::filter::kIsDedupFiltered;
    return false;
  }
  return true;
}

bool RecoStrategy::CanAddToResultSet(const ItemInfo& item, reco::filter::FilterReason* filter_reason) {
  if (!NewsFilter::ItemIsValid(item, reco_request_.current_timestamp)) {
    *filter_reason = reco::filter::kFilterByNotValid;
    return false;
  }
  if (NewsFilter::IsDeduped(item, &item_dedup_)) {
    *filter_reason = reco::filter::kIsDedupFiltered;
    return false;
  }

  if ((reco_request_.channel_id == reco::common::kRecoChannelId
       || reco_request_.channel_id == reco::common::kPictureChannelId)
      && NewsFilter::IsRegionRestrictFiltered(item, user_feas_.attr.prov_id, user_feas_.attr.city_id)) {
    *filter_reason = reco::filter::kRegionRestrictFiltered;
    return false;
  }

  static const std::unordered_set<int64> kSourceLimitChannels = {
    reco::common::kSportChannelId,reco::common::kFinanceChannelId,reco::common::kScienceChannelId,
    reco::common::kInternetChannelId,reco::common::kSocialChannelId,reco::common::kRecoChannelId,
    reco::common::kEntertainmentChannelId,
  };
  if (item.is_source_wemedia) {
    std::string show_source;
    if (kSourceLimitChannels.find(reco_request_.channel_id) != kSourceLimitChannels.end()
        && !news_index_->IsManualByDocId(item.doc_id)
        && news_index_->GetShowSourceByDocId(item.doc_id, &show_source)
        && !show_source.empty()
        && source_dedup_.find(show_source) != source_dedup_.end()) {
      *filter_reason = reco::filter::kSourceDedupFiltered;
      return false;
    }

    if (!show_source.empty()) {
      source_dedup_.insert(show_source);
    }
  }

  return true;
}

bool RecoStrategy::WeMediaRecommend(const UserInfo* user_info,
                                    const bool get_user_error,
                                    const WeMediaRecommendRequest *request,
                                    WeMediaRecommendResponse *response) {
  shown_dict_.clear();
  category_distributes_.clear();

  if (!get_user_error) {
    RecommendRequest reco_req;
    reco_req.set_reco_id(request->reco_id());
    reco_req.set_app_token(user_info->identity().app_token());
    reco_req.mutable_user()->CopyFrom(user_info->identity());
    reco_req.set_recommend_type(0);
    reco_req.set_return_num(request->return_num());
    reco_req.set_channel_id(request->channel_id());

    RecoUtils::BuildUserShownDict(news_index_, &reco_req, user_info, &shown_dict_, false);

    // 抽取用户特征
    user_feas_.Reset(user_info);
    user_fea_extractor_->ExtractUserFeature(&reco_req, user_info, &user_feas_);

    // 类别展现概率
    category_selector_->SelectFirstCategory(&reco_req, user_info, &user_feas_, &category_distributes_);
  }

  std::vector<WeMediaRecoResult> result;
  if (wemedia_reco_->GetWeMediaReco(user_info, request, shown_dict_, category_distributes_, &result)) {
    for (auto i = 0u; i < result.size() && i < request->return_num(); ++i) {
      response->add_result()->CopyFrom(result[i]);
    }
    return true;
  }

  return false;
}


bool RecoStrategy::ImCardRecommend(const UserInfo* user_info,
                                   const bool get_user_error,
                                   const ImCardRecoRequest *request,
                                   ImCardRecoResponse *response,
                                   CostTrace *cost_trace) {
  serving_base::Timer timer;

  LOG(INFO) << "Im card Receive reco request, "
            << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  timer.Start();

  RecommendRequest reco_req;
  reco_req.set_reco_id(request->reco_id());
  reco_req.set_app_token(request->app_token());
  reco_req.mutable_user()->CopyFrom(user_info->identity());
  reco_req.set_return_num(request->return_num());
  RecoUtils::BuildUserShownDict(news_index_, &reco_req, user_info, &shown_dict_, false);

  // 抽取用户特征
  user_feas_.Reset(user_info);
  user_fea_extractor_->ExtractUserFeature(&reco_req, user_info, &user_feas_);

  // 类别展现概率
  category_selector_->SelectFirstCategory(&reco_req, user_info, &user_feas_, &category_distributes_);

  reco_request_.Reset(&reco_req, user_info, &user_feas_, &shown_dict_, &category_distributes_);

  cost_trace->pps = timer.Stop();

  timer.Start();

  std::vector<ItemInfo> results;
  std::vector<ItemInfo> default_items;
  std::vector<ItemInfo> humor_items;
  if (!imcard_reco_->GetImCardReco(user_info, &reco_request_, &user_feas_, &category_distributes_,
                                   &shown_dict_, get_user_error, &default_items, &humor_items, cost_trace)) {
    LOG(WARNING) << "get im_card reco subitem error";
    // 即使失败也要保证正确填充required 字段
    response->set_success(true);
    response->mutable_user_info()->CopyFrom(*user_info);
    return false;
  } else {
    cost_trace->ss = timer.Stop();
    timer.Start();
    MergeImCardResults(default_items, humor_items, request->return_num(), &results);

    cost_trace->mrs = timer.Stop();

    timer.Start();
    uint64 im_item_id = reco::leafserver::ImCardReco::ComputeImcardItemId();
    ImRecoResult * im_result = response->mutable_im_result();
    RecoResult * im_item = im_result->mutable_im_item();
    im_item->set_item_id(im_item_id);
    im_item->set_outer_id(base::Uint64ToString(im_item_id));
    im_item->set_parent_id(im_item_id);
    im_item->set_item_type(reco::kIMCard);
    im_item->set_reco_id(request->reco_id());
    im_result->set_card_type(request->card_type());
    for (int i = 0; i <(int)results.size(); ++i) {
      RecoResult * sub_item = im_result->add_sub_items();
      sub_item->set_item_id(results[i].item_id);
      sub_item->set_outer_id(base::Uint64ToString(results[i].item_id));
      sub_item->set_parent_id(results[i].item_id);
      sub_item->set_item_type(results[i].item_type);
      sub_item->set_reco_id(request->reco_id());
    }
    response->set_success(true);
    response->mutable_user_info()->CopyFrom(*user_info);
    cost_trace->outs = timer.Stop();
  }
  return true;
}


void RecoStrategy::MergeImCardResults(const std::vector<ItemInfo> & default_vec,
                                      const std::vector<ItemInfo> & humor_vec,
                                      const int return_num,
                                      std::vector<ItemInfo> * result_items) {
  item_dedup_.clear();
  source_dedup_.clear();
  result_items->clear();
  if (default_vec.empty() && humor_vec.empty()) return;
  std::unordered_set<std::string> key_word_set;
  int default_count = 0;
  int humor_count = 0;
  while (default_count < (int)default_vec.size() || humor_count < (int)humor_vec.size()) {
    if ((int)result_items->size() >= return_num) break;
    if ((((int)result_items->size() == 5) || ((int)result_items->size() == 11))
       && humor_count < (int)humor_vec.size()) {
      while (humor_count < (int)humor_vec.size()) {
        reco::filter::FilterReason filter_reason;
        if (CanAddToResultSet(humor_vec[humor_count], &filter_reason)
            && imcard_reco_->KeyWordDedup(humor_vec[humor_count].item_id, &key_word_set)) {
          result_items->push_back(humor_vec[humor_count]);
          humor_count++;
          break;
        }
        humor_count++;
      }
    } else if (default_count < (int)default_vec.size()) {
      while (default_count < (int)default_vec.size()) {
        reco::filter::FilterReason filter_reason;
        if (CanAddToResultSet(default_vec[default_count], &filter_reason)
            && imcard_reco_->KeyWordDedup(default_vec[default_count].item_id, &key_word_set)) {
          result_items->push_back(default_vec[default_count]);
          default_count++;
          break;
        }
        default_count++;
      }
    } else {
      break;
    }
  }
}

void RecoStrategy::GetImResult(const RecommendRequest * request,
                               const UserInfo * user_info,
                               std::vector<ImRecoResult> * im_items) {
    im_items->clear();
    if (!imcard_reco_->IfQualifyForImCard(user_info)) return;

    uint64 im_item_id = ImCardReco::ComputeImcardItemId();
    ImRecoResult im_result;
    RecoResult * im_item = im_result.mutable_im_item();
    im_item->set_item_id(im_item_id);
    im_item->set_outer_id(base::Uint64ToString(im_item_id));
    im_item->set_parent_id(im_item_id);
    im_item->set_item_type(reco::kIMCard);
    im_item->set_reco_id(request->reco_id());
    ImCardType im_card_type = ImCardReco::GetImCardType();
    im_result.set_card_type(im_card_type);
    im_items->push_back(im_result);
}

bool RecoStrategy::GetItemPOITag(uint64 item_id, POITag *poi_tag) {
  auto iter = item_poi_tags_.find(item_id);
  if (iter == item_poi_tags_.end()) return false;
  poi_tag->CopyFrom(iter->second);
  return true;
}

bool RecoStrategy::SceneCardRecommend(const UserInfo* user_info,
                                      const bool get_user_error,
                                      const SceneCardRecoRequest *request,
                                      SceneCardRecoResponse *response,
                                      CostTrace *cost_trace) {
  serving_base::Timer timer;
  LOG(INFO) << "scene card Receive reco request, "
            << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  timer.Start();
  // 此次是否吐场景化卡片
  if (!scene_reco_->IfQualifyForSceneCard(request, user_info)) {
    response->set_success(true);
    // response->mutable_user_info()->CopyFrom(*user_info);
    return true;
  }

  // 构建 show_dict
  RecommendRequest reco_req;
  reco_req.set_reco_id(request->reco_id());
  reco_req.set_app_token(request->app_token());
  reco_req.mutable_user()->CopyFrom(user_info->identity());
  reco_req.set_return_num(request->return_num());
  RecoUtils::BuildUserShownDict(news_index_, &reco_req, user_info, &shown_dict_, false);
  // 抽取用户特征
  user_feas_.Reset(user_info);
  user_fea_extractor_->ExtractUserFeature(&reco_req, user_info, &user_feas_);
  // 类别展现概率
  category_selector_->SelectFirstCategory(&reco_req, user_info, &user_feas_, &category_distributes_);
  cost_trace->pps = timer.Stop();

  // 获取场景推荐列表
  timer.Start();
  SceneRecoResult scene_result;
  if (!scene_reco_->GetSceneCardReco(user_info, request, &user_feas_, &shown_dict_,
                                     &category_distributes_, &scene_result, cost_trace)) {
    LOG(WARNING) << "get scene_card reco subitem error";
    response->set_success(true);
    cost_trace->outs = timer.Stop();
    return false;
  }

  response->set_success(true);
  response->mutable_scene_result()->CopyFrom(scene_result);
  cost_trace->outs = timer.Stop();
  return true;
}

void RecoStrategy::EnforceInsertQueue(std::vector<ItemInfo>* reco_items) {
  if (reco_items->empty()) return;

  std::vector<uint64> wait_items;
  if (FLAGS_open_push_item_insert_strategy && reco_request_.request->has_pushed_item()) {
    wait_items.push_back(reco_request_.request->pushed_item());
  }

  if (wait_items.empty()) return;

  for (size_t idx = 0; idx < wait_items.size(); ++idx) {
    VLOG(2) << "enforce candidate item, " << wait_items[idx];
  }

  // 同一屏的 dedup
  base::dense_hash_set<uint64> dedup_ids;
  dedup_ids.set_empty_key(0);
  for (size_t idx = 0; idx < reco_items->size(); ++idx) {
    const ItemInfo& item = reco_items->at(idx);
    NewsFilter::IsDeduped(item, &dedup_ids);
  }
  // 文章插入到 banner 后面
  std::vector<ItemInfo> swap_items;
  int split_pos = 0;
  for (size_t i = 0; i < reco_items->size(); ++i) {
    const reco::ItemInfo& item = reco_items->at(i);
    if (item.strategy_type != reco::kBanner
        && item.strategy_type != reco::kProbe) {
      split_pos = i;
      break;
    }
  }
  if (split_pos > 0) {
    swap_items.insert(swap_items.end(), reco_items->begin(), reco_items->begin() + split_pos);
  }
  int add_num = 0;
  ItemInfo item_info;
  for (size_t idx = 0; idx < wait_items.size(); ++idx) {
    if (add_num >= 2) break;
    uint64 item_id = wait_items[idx];
    // if (history_ids.find(item_id) != history_ids.end()) {
    //   VLOG(2) << "enforce item show filter, " << item_id;
    //   continue;
    // }
    if (!news_index_->GetItemInfoByItemId(item_id, &item_info, false)) {
      VLOG(2) << "enforce item get fail, " << item_id;
      continue;
    }
    if (!NewsFilter::IsDeduped(item_info, &dedup_ids)) {
      item_info.strategy_type = kExplore;
      item_info.strategy_branch = reco::kEnforceBranch;
      VLOG(2) << "add one enforce item, " << item_id;
      swap_items.push_back(item_info);
      ++add_num;
    }
  }
  for (size_t idx = 0; idx < push_relate_items_.size() && idx < 2; ++idx) {
    const ItemInfo& push_relate_item = push_relate_items_[idx];
    if (!NewsFilter::IsDeduped(push_relate_item, &dedup_ids)) {
      swap_items.push_back(push_relate_item);
    }
  }
  if (split_pos < (int)reco_items->size()) {
    swap_items.insert(swap_items.end(), reco_items->begin() + split_pos, reco_items->end());
  }

  reco_items->swap(swap_items);
}

bool RecoStrategy::GuaranteeQuantity(std::vector<ItemInfo>* reco_items) {
  std::set<std::string> cate_dedup;
  // 在 head 15 有保量的结果，就不进行保量的调整。
  reco::dm::MediaQuantityInfo mqi;
  int64 item_limit = 0;
  size_t i = 0;
  for (; i < reco_items->size() && i < (size_t)FLAGS_guarantee_quantity_insert_end_pos; ++i) {
    const reco::ItemInfo& item = reco_items->at(i);
    cate_dedup.insert(item.category);
    if (news_index_->GetItemQuantityInfo(reco::kQueueDoc, item, &mqi, &item_limit)
        && mqi.protect_capacity > mqi.deliever_num
        && item_limit > item.show_num) {
      VLOG(1) << "already has guarantee item";
      return false;;
    }
  }
  VLOG(1) << "interest queue size: " << reco_items->size()
          << ", head 15 have " << cate_dedup.size() << " cates";
  std::vector<size_t> candidate_pos;
  for (; i < reco_items->size(); ++i) {
    const reco::ItemInfo& item = reco_items->at(i);
    if (news_index_->GetItemQuantityInfo(reco::kQueueDoc, item, &mqi, &item_limit)) {
      VLOG(1) << item.item_id <<  " is guarantee item " << mqi.protect_capacity
              << " " << mqi.deliever_num << " " << item_limit << " " << item.show_num;
      int64 source_deliver_num = 0;
      int64 item_deliver_num = 0;
      MediaQuantityInfoIns::instance().LocalGuaranteeDeliver(item, &source_deliver_num, &item_deliver_num);
      if (source_deliver_num * FLAGS_media_quantity_deliver_machine_num >= mqi.protect_capacity
          || item_deliver_num * FLAGS_media_quantity_deliver_machine_num >= item_limit) {
        continue;
      }
      if (mqi.protect_capacity > mqi.deliever_num && item_limit > item.show_num) {
        candidate_pos.push_back(i);
        bool cond1 = (random_->GetDouble() < FLAGS_guarantee_quantity_deliver_rate);
        bool cond2 = ((mqi.protect_capacity - mqi.deliever_num) * 1.0
                      / std::max(FLAGS_guarantee_quantity_media_ratio, mqi.protect_capacity)
                      > random_->GetDouble());
        bool cond3 = ((item_limit - item.show_num) * 1.0
                      / std::max(FLAGS_guarantee_quantity_item_ratio, item_limit)
                      > random_->GetDouble());
        VLOG(1) << item.item_id << " guarantee cond " << cond1 << " " << cond2 << " " << cond3;
        if (cond1 && cond2 && cond3) {
          break;
        }
      }
    }
  }
  if (i == reco_items->size()) {
    VLOG(1) << "does not select guarantee item, candidates: " << candidate_pos.size()
            << " , all: " << reco_items->size();
    if (FLAGS_guarantee_quantity_post_recall && candidate_pos.size() > 0) {
      i = candidate_pos[random_->GetInt(0, candidate_pos.size() - 1)];
    } else {
      return false;
    }
  }
  LOG(INFO) << "select guarantee item pos " << i << " after " << candidate_pos.size() << " candidates";
  size_t gd_item_pos = i;
  if (!news_index_->GetItemQuantityInfo(reco::kQueueDoc, (*reco_items)[gd_item_pos], &mqi, &item_limit)) {
    return false;
  }
  if (mqi.protect_type == reco::dm::kMediaDocManual) {
    (*reco_items)[gd_item_pos].strategy_type = reco::kOperGuarantee;
  } else  if (mqi.protect_type == reco::dm::kMediaDocBeginner) {
    (*reco_items)[gd_item_pos].strategy_type = reco::kNewMediaGuarantee;
  } else {
    LOG(INFO) << "guarantee item's protect type error: " << (*reco_items)[gd_item_pos].item_id
              << " " << mqi.protect_type;
    (*reco_items)[gd_item_pos].strategy_type = reco::kOperGuarantee;
  }
  (*reco_items)[gd_item_pos].strategy_branch = reco::kGuaranteeDeliverSwapBranch;
  // 插到前 15 个中与之是相同类别的位置
  bool is_guarantee = false;
  for (size_t j = (size_t)FLAGS_guarantee_quantity_insert_start_pos;
       j < reco_items->size() && j < (size_t)FLAGS_guarantee_quantity_insert_end_pos; ++j) {
    if ((*reco_items)[j].category == (*reco_items)[gd_item_pos].category) {
      LOG(INFO) << "guarantee item: " << (*reco_items)[i].item_id << " from " << gd_item_pos << " to " << j;
      ItemInfo insert_item = (*reco_items)[gd_item_pos];
      size_t pos = gd_item_pos;
      for (size_t k = gd_item_pos - 1; k >= j; --k) {
        if ((*reco_items)[k].category == insert_item.category) {
          (*reco_items)[pos] = (*reco_items)[k];
          pos = k;
        }
      }
      (*reco_items)[j] = insert_item;
      is_guarantee = true;
      return true;
    }
  }
  return false;
}

bool RecoStrategy::HotCardRecommend(const UserInfo* user_info,
                                    const bool get_user_error,
                                    const HotCardRecommendRequest *request,
                                    HotCardRecommendResponse *response,
                                    CostTrace *cost_trace) {
  serving_base::Timer timer;
  LOG(INFO) << "Hot card Receive reco request, "
            << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);
  timer.Start();
  // 构建 show_dict
  RecommendRequest reco_req;
  reco_req.set_reco_id(request->reco_id());
  reco_req.mutable_user()->CopyFrom(user_info->identity());
  RecoUtils::BuildUserShownDict(news_index_, &reco_req, user_info, &shown_dict_, false);
  // 抽取用户特征
  user_feas_.Reset(user_info);
  user_fea_extractor_->ExtractUserFeature(&reco_req, user_info, &user_feas_);
  // 类别展现概率
  category_selector_->SelectFirstCategory(&reco_req, user_info, &user_feas_, &category_distributes_);
  cost_trace->pps = timer.Stop();

  uint64 hot_card_item_id = hot_card_reco_->ComputeHotCardItemId();

  // 获取推荐列表
  timer.Start();
  std::vector<ItemInfo> hot_event_result;
  if (!hot_card_reco_->GetHotCardReco(user_info, request, &user_feas_, &shown_dict_,
                                     &category_distributes_, &hot_event_result, cost_trace)) {
    LOG(WARNING) << "get hot card reco subitem error";
    response->set_success(true);
    response->set_item_id(hot_card_item_id);
    response->set_reco_id(request->reco_id());
    cost_trace->outs = timer.Stop();
    return true;
  }

  item_dedup_.clear();
  source_dedup_.clear();

  const uint32 cut = request->has_return_num() ? request->return_num() : 2u;
  if (hot_event_result.size() < cut) {
    // LOG(INFO) << "get hot card result num lower than cut, result_size:" << hot_event_result.size()
    //           << ", cut num:" << cut;
    response->set_success(true);
    response->set_item_id(hot_card_item_id);
    response->set_reco_id(request->reco_id());
    cost_trace->outs = timer.Stop();
    return true;
  }
  uint32 count = 0;
  std::string hot_card_reco_list_str;
  for (auto iter = hot_event_result.begin();
       iter != hot_event_result.end();
       ++iter) {
    if (count >= cut) break;
    reco::filter::FilterReason filter_reason;
    if (!CanAddToResultSet(*iter, &filter_reason)) continue;
    count++;
    HotCardRecoResult *hot_event_candidate = response->add_result();
    hot_card_reco_list_str += base::StringPrintf("%lu, ", iter->item_id);
    std::string title;
    news_index_->GetItemTitleByItemId(iter->item_id, &title);
    hot_event_candidate->set_hot_event(title);
    hot_event_candidate->set_title(title);
    hot_event_candidate->set_category(iter->category);
    hot_event_candidate->set_item_id(iter->item_id);
  }
  LOG(INFO) << "hot event reco result: " << hot_card_reco_list_str;
  response->set_success(true);
  response->set_item_id(hot_card_item_id);
  response->set_reco_id(request->reco_id());
  cost_trace->outs = timer.Stop();
  return true;
}

bool RecoStrategy::ForceSuppressItem(const RecoRequest &reco_request, std::vector<ItemInfo> *items) {
  if (force_suppress_keywords_.empty()) {
    return true;
  }

  // 一天的前三次次推荐不出王宝强相关文章
  if (reco_request.today_access_cnt >= 5) {
    return true;
  }

  std::vector<ItemInfo> raw_items(*items);
  items->clear();
  for (auto i = 0u; i < raw_items.size(); ++i) {
    const int64 item_id = raw_items[i].item_id;
    bool find = false;

    // keyword
    reco::FeatureVector fevtag;
    if (news_index_->GetFeatureVectorByItemId(item_id, reco::common::kKeyword, &fevtag)) {
      for (int j = 0; j < fevtag.feature_size() && !find; ++j) {
        const std::string& keyword = fevtag.feature(j).literal();
        if (force_suppress_keywords_.find(keyword) != force_suppress_keywords_.end()) {
          find = true;
        }
      }
    }
    if (find) continue;

    // tag
    fevtag.Clear();
    if (news_index_->GetFeatureVectorByItemId(item_id, reco::common::kTag, &fevtag)) {
      for (int j = 0; j < fevtag.feature_size() && !find; ++j) {
        std::string tag = fevtag.feature(j).literal();
        if (tag.substr(0, FLAGS_tag_prefix.length()) == FLAGS_tag_prefix) {
          tag = tag.substr(FLAGS_tag_prefix.length(), tag.length() - FLAGS_tag_prefix.length());
        }
        if (force_suppress_keywords_.find(tag) != force_suppress_keywords_.end()) {
          find = true;
        }
      }
    }
    if (find) continue;

    items->push_back(raw_items[i]);
  }

  if (raw_items.size() != items->size()) {
    LOG(INFO) << "uid:" << reco_request.user_info->identity().user_id()
              << ",ori:" << raw_items.size() << ", des:" << items->size();
  }

  return true;
}

bool RecoStrategy::RandomReco(const RecoRequest& reco_request, std::vector<ItemInfo>* reco_item) {
  const static double ratio = 0.6;
  if (reco_request.user_info->identity().user_id() == 0
      || reco_request_.access_frequency[0] > 1 * 60 * ratio
      || reco_request_.access_frequency[1] > 5 * 60 * (ratio - 0.1)
      || reco_request_.access_frequency[2] > 15 * 60 * (ratio - 0.2)) {
    if (reco_request.user_info->identity().user_id() != 0) {
      LOG(INFO) << "uid:" << reco_request.user_info->identity().user_id() << ", hit random reco strategy";
    }
  } else {
    return false;
  }

  COUNTERS_strategy__random_reco_num.Increase(1);
  static const size_t kMaxNum = 600;
  if (reco_request.channel_id == reco::common::kRecoChannelId) {
    candidate_extractor_->GetCandidates(&reco_request, reco_item, kMaxNum);
  } else {
    candidate_extractor_->GetCandidatesByChannelId(reco_request.channel_id,
                                                   &reco_request,
                                                   reco_item,
                                                   kMaxNum,
                                                   NULL);
  }

  return true;
}

bool RecoStrategy::CanDeliverVideo() const {
  // 非推荐频道不受限制
  if (reco_request_.channel_id != common::kRecoChannelId) return true;
  if (reco_request_.user_feas->behavior_fea.dislike_video_level == kDislikeVideoVeryHigh) {
    VLOG(1) << "kDislikeVideoVeryHigh";
    return false;
  }
  return true;
  /*
  // wifi 下可以下发视频
  if (reco_request_.user_param_info.is_wifi) return true;
  // 视频的深度用户可以下发视频
  if (reco_request_.user_info &&
      reco_request_.user_info->has_profile() &&
      reco_request_.user_info->profile().has_video_network_feavec()) {
    double net_weight = 0;
    auto &video_network_feavec = reco_request_.user_info->profile().video_network_feavec();
    for (int i = 0; i < video_network_feavec.feature_size(); ++i) {
      auto &feature = video_network_feavec.feature(i);
      if (feature.literal() == "1") {
        net_weight = feature.weight();
        break;
      }
    }
    static const double kNetWeightThr = 50;
    if (net_weight > kNetWeightThr) return true;
    double ratio = net_weight / kNetWeightThr;
    if (random_->GetDouble() < ratio) return true;
  }
  return false;
  */
}

bool RecoStrategy::CheckIsShownByItemId(uint64 item_id) const {
  if (shown_dict_.find(item_id) != shown_dict_.end()
      || !news_index_->HasCheckedBySimServer(item_id)) {
    return true;
  }
  return false;
}

void RecoStrategy::TryGetAssembleCardInfo(const ItemInfo& item, RecoResult* result) const {
  if (manual_data_.morning_evening_auto_card.IsAssembleCard(item.item_id)) {
    result->set_card_assemble_type(1);
    const std::vector<ItemInfo>& sub_items = manual_data_.morning_evening_auto_card.sub_items();
    for (size_t i = 0; i < sub_items.size(); ++i) {
      result->add_sub_item_id(sub_items[i].item_id);
    }
  } else if (manual_data_.auto_event_card.IsAutoEventCard(item.item_id)) {
    result->set_card_assemble_type(2);
    const std::vector<ItemInfo>& sub_items = manual_data_.auto_event_card.sub_items();
    for (size_t i = 0; i < sub_items.size(); ++i) {
      result->add_sub_item_id(sub_items[i].item_id);
    }
  }
}

}  // namespace leafserver
}  // namespace reco
