#include "reco/serv/reco_leaf/strategy/rank_hooker.h"

#include <algorithm>
#include <queue>

#include "reco/serv/reco_leaf/strategy/common/profile_type.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "reco/serv/reco_leaf/strategy/reco_strategy.h"
#include "reco/serv/reco_leaf/strategy/reason_explain.h"
#include "reco/serv/reco_leaf/strategy/probe/probe_base.h"
#include "reco/bizc/common/item_level_define.h"
#include "reco/bizc/news_map/strategy/news_map_strategy.h"
#include "reco/bizc/reco_index/media_quantity_assurance.h"
#include "reco/bizc/reco_index/news_index.h"

#include "serving_base/utility/timer.h"
#include "serving_base/data_manager/data_manager.h"
#include "nlp/common/nlp_util.h"
#include "base/common/logging.h"
#include "base/random/pseudo_random.h"
#include "extend/multi_strings/multi_strings_vldc.h"
#include "base/random/pseudo_random.h"

namespace reco {
DECLARE_bool(open_time_axis_switch);

namespace leafserver {
using reco::user::UserInfo;

DEFINE_bool(print_return_item, true, "if print return item");
DEFINE_bool(do_return_num_modify_exp, false, "if do return num modify");
DEFINE_bool(do_im_card_switch, true, "if do im card reco");
DEFINE_bool(do_scene_card_switch, false, "if do scene card reco");
DEFINE_bool(do_hot_card_switch, true, "if do hot card reco");
DEFINE_int32(time_axis_deliver_screen_gap, 1, "时间轴多屏下发的间隔");
DEFINE_bool(set_reco_reason, false, "是否下发推荐理由");
DEFINE_bool(only_return_reviewed_video_show_tag, true, "是否只返回审核过的视频 show_tag");
DEFINE_bool(return_video_show_tag_switch, false, "是否返回视频 show_tag 的开关");
DEFINE_bool(debug_yc_bl, false, "是否 debug yc bl 的开关");

serving_base::ExpiryMap<std::string, uint32>* RankHooker::time_axis_shown_dict_ =
    new serving_base::ExpiryMap<std::string, uint32>(60 * 15);
RankHooker::RankHooker() {
  global_data_ = LeafDataManager::GetGlobalData();
  news_index_ = global_data_->news_index;
  reco_strategy_ = new RecoStrategy(news_index_);
  reason_explain_ = new ReasonExplain();
  random_ = new base::PseudoRandom(base::GetTimestamp());
}

RankHooker::~RankHooker() {
  delete random_;
  delete reason_explain_;
  delete reco_strategy_;
}

bool RankHooker::Recommend(const RecommendRequest& org_request,
                           RecommendResponse* response,
                           const UserInfo& user_info,
                           const bool get_user_error,
                           CostTrace *cost_trace,
                           thread::Thread* video_thread) {
  serving_base::Timer timer;
  timer.Start();

  reco_items_.clear();
  hit_tags_.clear();
  im_items_.clear();
  has_more_ = false;

  // 获取用户信息失败的情况下，会随机出结果
  // 此时传入的 user_info 除了 userIdentity 有值，其他字段都是空的(等同与新用户）
  // 需要请求比较多的结果，然后做随机, 而且不能做缓存
  RecommendRequest alter_request(org_request);
  alter_request.set_is_random_reco(false);
  const int64 channel_id =
      alter_request.has_channel_id() ? alter_request.channel_id() : reco::common::kRecoChannelId;

  if (get_user_error) {
    alter_request.set_return_num(500);
    alter_request.set_get_user_error(true);
  } else if (FLAGS_do_return_num_modify_exp) {
    // 请求条数调整的实验
    if (channel_id == reco::common::kRecoChannelId) {
      int return_num = alter_request.return_num();
      if (alter_request.has_news_date()) {
        return_num = std::min((int)alter_request.return_num(), 15);
      } else {
        return_num = std::max(1, std::min(static_cast<int>(alter_request.return_num() * 0.8), 15));
      }
      alter_request.set_return_num(return_num);
    }
  }
  cost_trace->ins = timer.Stop();
  timer.Start();

  RecoDebugger debugger(news_index_, org_request, response);
  RecoContext reco_context(cost_trace, &debugger);

  // 请求推荐结果
  if (channel_id == reco::common::kRecoChannelId) {
    // 推荐频道请求
    if (!reco_strategy_->ComplexChannelRecommend(&user_info, &alter_request, &reco_items_, &reco_context,
                                                 video_thread)) {
      return false;
    }
    has_more_ = true;

    // im_card switch
    if (FLAGS_do_im_card_switch) {
      reco_strategy_->GetImResult(&alter_request, &user_info, &im_items_);
    }
  } else if (channel_id == reco::common::kSubscriptionChannelId
             || channel_id == reco::common::kTagMainpageChannelId) {
    // 订阅频道, 标签页请求
    if (!reco_strategy_->DoSubscriptionReco(&user_info, &alter_request,
                                            &reco_items_, &hit_tags_, &reco_context)) {
      return false;
    }
    has_more_ = (reco_items_.size() >= org_request.return_num());
  } else if (channel_id == reco::common::kJingpinChannelId) {
    // 精品频道请求
    if (!reco_strategy_->DoJingpinRecommend(&user_info, &alter_request,
                                            &reco_items_, &reco_context)) {
      return false;
    }
    has_more_ = (reco_items_.size() >= org_request.return_num());
  } else if (channel_id == reco::common::kSexyBeautyChannelId) {
    if (!reco_strategy_->DoBeautyRecommend(&user_info, &alter_request,
                                           &reco_items_, &reco_context)) {
      return false;
    }
    has_more_ = (reco_items_.size() >= org_request.return_num());
  } else {
    // 其他垂直频道
    if (!alter_request.has_reco_alg()
        || alter_request.reco_alg() == reco::leafserver::kRecoAlg) {
      // 推荐请求
      if (!reco_strategy_->VerticleChannelRecommend(&user_info, &alter_request,
                                                    &reco_items_, &reco_context)) {
        return false;
      }
      has_more_ = (reco_items_.size() >= org_request.return_num());
    } else {
      // NOTE(jianhuang) 频道的非推荐请求暂无实现
      return false;
    }
  }

  cost_trace->ss = timer.Stop();
  timer.Start();

  // 如果获取用户信息失败，则从返回的结果集合中随机抽取一些结果返回
  if (get_user_error || alter_request.is_random_reco()) {
    base::PseudoRandom random(base::GetTimestamp());
    int cut = std::min((int)org_request.return_num(), (int)reco_items_.size());
    for (int i = 0; i < cut; ++i) {
      if ((int)reco_items_.size()-1 > i+1) {
        int j = random_->GetInt(i + 1, (int)reco_items_.size() - 1);
        std::swap(reco_items_.at(i), reco_items_.at(j));
      }
    }
    reco_items_.resize(cut);
  }

  // 构建返回的 response
  if (!ConstructRecoResponse(org_request, user_info, response, &reco_context)) {
    LOG(ERROR) << "fail in construct reco response.";
    return false;
  }
  // 对于内部用户请求记录推荐过程
  debugger.CommitRecoProcess();

  cost_trace->outs = timer.Stop();

  return true;
}

bool RankHooker::ConstructRecoResponse(const RecommendRequest& request,
                                       const UserInfo& user_info,
                                       RecommendResponse* response,
                                       RecoContext* reco_context) {
  // 构建返回的 response
  response->set_has_more(has_more_);
  const int64 channel_id = request.has_channel_id() ? request.channel_id() : reco::common::kRecoChannelId;
  ProfileTypeDetect profile_type_detector(user_info);
  reco::ProfileType profile_type;
  reco::DmpProfileType dmp_profile_type;
  std::string snd_category_str;
  std::vector<std::string> title_unigrams;
  std::vector<reco::Category> categories;
  std::unordered_set<uint64> timeaxis_dedups;
  bool fill_hit_query = (reco_items_.size() == hit_tags_.size());

  // 是否展示视频标签
  bool deliver_video_tag = false;
  if (FLAGS_return_video_show_tag_switch && common::IsVideoChannel(channel_id)) {
    // auto &inner_user_ids = global_data_->inner_user_ids;
    // if (inner_user_ids.find(user_info.identity().user_id()) != inner_user_ids.end()) {
    deliver_video_tag = true;
    // }
  }

  std::vector<ProbeInfo> probe_infos(reco_items_.size());
  for (int i = 0; i < (int)reco_items_.size(); ++i) {
    ProbeInfo probe_info;
    if (reco_strategy_->GetItemProbeInfo(reco_items_[i].item_id, &probe_info)) {
      probe_infos[i] = probe_info;
    }
  }

  // 是否含有事件标签
  std::string event_tag = "";
  if (channel_id == reco::common::kTagMainpageChannelId
      && request.channel_tags_size() == request.channel_tags_type_size()) {
    for (int i = 0; i < request.channel_tags_type_size(); ++i) {
      if (request.channel_tags_type(i) == 1) {
        event_tag = request.channel_tags(i);
      }
    }
  }

  for (int i = 0; i < (int)reco_items_.size(); ++i) {
    if (response->result_size() >= (int)request.return_num() + 1) break;

    const ItemInfo& item = reco_items_[i];
    // NOTE(jianhuang) 返回前再检测一遍 sim check，避免 badcase
    if (item.strategy_type != reco::kBanner && item.strategy_type != reco::kManual
        && item.strategy_type != reco::kQueryReco
        && !news_index_->HasCheckedBySimServer(item.item_id)) {
      LOG(WARNING) << "item has not check by sim, uid:" << user_info.identity().user_id()
                   << ", recoid:" << request.reco_id() << ", itemid:" << item.item_id;
      continue;
    }
    // NOTE(jianhuang) 这里暂时不考虑按量下发的情况
    // if (IsFilteredByUCBIssueLimit(item)) continue;
    // 设置必要的字段
    uint64 item_id = reco_items_[i].item_id;
    int32 doc_id = reco_items_[i].doc_id;
    reco::leafserver::RecoResult result;
    result.set_item_id(item_id);
    result.set_outer_id(base::Uint64ToString(item_id));
    result.set_reco_id(request.reco_id());
    result.set_parent_id(news_index_->GetParentId(item_id));
    int64 timestamp = news_index_->GetCreateTimestampByItemId(item_id);
    result.set_create_timestamp(timestamp);
    if (reco_items_[i].strategy_type == reco::kOperGuarantee
        || reco_items_[i].strategy_type == reco::kNewMediaGuarantee) {
      MediaQuantityInfoIns::instance().IncGuaranteeDeliver(reco_items_[i]);
    }
    if (reco_items_[i].item_type == reco::kSpecial) {
      reco_strategy_->TryGetAssembleCardInfo(item, &result);
    }
    if ((request.has_only_id() && request.only_id())
        || (request.has_only_count() && request.only_count())) {
      response->add_result()->CopyFrom(result);
      continue;
    }

    if (fill_hit_query) {
      result.set_hit_tag(hit_tags_[i]);
    }

    // 设置探索信息
    const ProbeInfo& probe_info = probe_infos[i];
    if (probe_info.probe_type != reco::kNoProbeType) {
      result.set_probe_type(probe_info.probe_type);
      result.set_probe_action(probe_info.probe_action);
      result.set_probe_detail(probe_info.probe_detail);
      result.set_strategy_type(reco::kProbe);
    }

    title_unigrams.clear();
    if (item.strategy_type != reco::kQueryReco) {
      if (!news_index_->GetAreaUnigramsByDocId(doc_id, adsindexing::kTitleArea, &title_unigrams)) { }
    }
    result.set_title(base::JoinStrings(title_unigrams, ""));
    result.set_strategy_type(item.strategy_type);
    result.set_strategy_branch(item.strategy_branch);
    result.set_reco_ext_info(item.reco_ext_info);
    SetItemSubscript(request, item, &result);
    if (i == 0 && !event_tag.empty()) {
      SetTimeAxisLatestNewsInfo(user_info, item, event_tag, &result);
    }
    categories.clear();
    snd_category_str.clear();
    if (!news_index_->GetCategoriesByItemId(item_id, &categories)) {
      LOG(ERROR) << "failed to get title id" << item_id;
    }
    for (int j = 0; j < (int)categories.size(); ++j) {
      result.add_category(categories[j].category());
      if (categories[j].level() == 1) {
        snd_category_str = categories[j].category();
      }
    }
    profile_type_detector.DetectProfileType(item.category, snd_category_str,
                                            &profile_type, &dmp_profile_type);
    result.set_profile_type(profile_type);
    result.set_dmp_profile_type(dmp_profile_type);

    reco::ItemType item_type;
    if (item.strategy_type != reco::kQueryReco
        && news_index_->GetItemTypeByDocId(doc_id, &item_type)) {
      result.set_item_type(item_type);
    }
    if (timestamp > 0) {
      base::Time time = base::Time::FromDoubleT(timestamp / base::Time::kMicrosecondsPerSecond);
      time.ToStringInSeconds(result.mutable_create_time());
    }

    result.set_lr_score(item.lr_score);
    result.set_fm_score(item.fm_score);
    result.set_fac_machine_score(item.fac_machine_score);
    result.set_reco_score(item.reco_score);
    result.set_show_num(item.show_num);
    result.set_click_num(item.click_num);
    result.set_itemq(item.itemq);

    if (item.item_type == reco::kPureVideo) {
      if (deliver_video_tag) SetVideoShowTag(item, &result);
    }
    // 设置 ItemQuality 信息
    ItemQualityInfo item_quality_info;
    if (item.new_pr > 0) item_quality_info.set_new_pr(item.new_pr);
    item_quality_info.set_media_level(item.media_level);
    item_quality_info.set_itemq(item.itemq);
    if (item.hot_level > 0) item_quality_info.set_hot_level(item.hot_level);
    int32 orgi_itemq = -1;
    if (news_index_->GetOrgiItemQByItemId(item.item_id, &orgi_itemq)) {
      item_quality_info.set_new_itemq(orgi_itemq);
    }
    item_quality_info.SerializeToString(result.mutable_item_quality_info());
    response->add_result()->CopyFrom(result);
  }

  if ((request.has_only_id() && request.only_id())
      || (request.has_only_count() && request.only_count())
      || reco_items_.empty()) {
  } else {
    reason_explain_->PrepareToExplain(&request, &user_info,
                                      &(reco_strategy_->GetUserFeature()));

    std::vector<std::pair<int, RecoReason>> event_reasons;
    if (reason_explain_->SetEventRecoReason(reco_items_, &event_reasons)) {
      for (size_t k = 0; k < event_reasons.size(); ++k) {
        int idx = event_reasons[k].first;
        const RecoReason& reason = event_reasons[k].second;
        if (idx >= 0 && idx < response->result_size()) {
          response->mutable_result(idx)->mutable_reco_reason()->CopyFrom(reason);
          VLOG(1) << idx << " add event reco reason, " << reason.Utf8DebugString();
        }
      }
    }

    std::pair<int, RecoReason> chosen_one;
    if (reason_explain_->SetRecoReason(reco_items_, probe_infos, &chosen_one)) {
      int idx = chosen_one.first;
      if (idx >= 0 && idx < response->result_size()) {
        response->mutable_result(idx)->mutable_reco_reason()->CopyFrom(chosen_one.second);
        VLOG(1) << idx << " add reco reason, " << chosen_one.second.Utf8DebugString();
      }
    }

    std::pair<int, RecoReason> beauty_reason;
    if (reason_explain_->SetBeautyChannelReason(reco_items_, &beauty_reason)) {
      int idx = beauty_reason.first;
      if (idx >= 0 && idx < response->result_size()) {
        response->mutable_result(idx)->mutable_reco_reason()->CopyFrom(beauty_reason.second);
        VLOG(1) << idx << " add reco reason, " << beauty_reason.second.Utf8DebugString();
      }
    }
  }

  // add im card results
  for (int i = 0; i < (int)im_items_.size(); ++i) {
    response->add_im_result()->CopyFrom(im_items_[i]);
  }

  if (base::LowerCaseEquals(request.app_token(), "uc-iflow")) {
    // ReplaceYcItem(response);
    // ReplaceOriginItem(response);
  }

  if (FLAGS_print_return_item) {
    std::string debug_info = base::StringPrintf("uid:%lu,recoid:%s",
                                                request.user().user_id(), request.reco_id().c_str());
    std::unordered_set<uint64> duplicate_items;
    for (int i = 0; i < response->result_size(); ++i) {
      const reco::leafserver::RecoResult& result = response->result(i);
      if (duplicate_items.find(result.item_id()) != duplicate_items.end()) {
        LOG(WARNING) << "duplicate items, " << result.reco_id() << ", "<< result.item_id();
      } else {
        duplicate_items.insert(result.item_id());
      }
      std::string category = "";
      if (result.category_size() > 0) category = result.category(0);
      std::string strategy_type = StrategyType_Name(result.strategy_type());

      std::string strategy_branch = RecoStrategyBranch_Name(reco::kUnknownBranch);
      if (result.has_strategy_branch() && RecoStrategyBranch_IsValid(result.has_strategy_branch())) {
        strategy_branch = RecoStrategyBranch_Name(
            static_cast<reco::RecoStrategyBranch>(result.strategy_branch()));
      }
      if (result.has_time_axis_info() && result.time_axis_info().has_id()) {
        strategy_type += " timeaxis: " + base::Uint64ToString(result.time_axis_info().id());
      }
      if (result.item_type() == reco::kSpecial
          && result.has_card_assemble_type() && result.card_assemble_type() == 1) {
        debug_info += base::StringPrintf(", %lu(%s %d %s %s)-(1)-", result.item_id(), category.c_str(),
                                         (int)result.item_type(), strategy_type.c_str(),
                                         strategy_branch.c_str());
        std::string sub_item_ids;
        for (int i = 0; i< result.sub_item_id_size(); ++i) {
          sub_item_ids += base::StringPrintf("%lu ", result.sub_item_id(i));
        }
        debug_info += base::StringPrintf("(%s)", sub_item_ids.c_str());
      } else {
        debug_info += base::StringPrintf(", %lu(%s %d %s %s)", result.item_id(), category.c_str(),
                                         (int)result.item_type(), strategy_type.c_str(),
                                         strategy_branch.c_str());
      }
    }
    LOG(INFO) << "return results, " << debug_info;

    if (response->has_reco_debug_info())
      LOG(INFO) << "return debug info, "
                << nlp::util::NormalizeLine(response->reco_debug_info().Utf8DebugString());
  }

  return true;
}

/*
void RankHooker::ReplaceYcItem(RecommendResponse* response) {
  std::vector<int> pos_list;
  std::vector<std::string> keys;
  std::vector<std::string> values;
  std::vector<int> rets;
  for (int i = 0; i < response->result_size(); ++i) {
    reco::leafserver::RecoResult* result = response->mutable_result(i);
    if (result->strategy_type() == reco::kBanner || result->strategy_type() == reco::kManual) continue;
    uint64 yc_item_id = 0;
    uint64 item_id = result->item_id();
    if (news_index_->GetYCInfoByItemId(item_id, &yc_item_id)) {
      LOG_IF(INFO, FLAGS_debug_yc_bl) << "[ycdebug] get yc cache succ, item_id : "
                                      << item_id << "yc_item_id : " << yc_item_id;
      if (yc_item_id != 0 && yc_item_id != item_id) {
        if (reco_strategy_->CheckIsShownByItemId(yc_item_id)) {
          LOG_IF(INFO, FLAGS_debug_yc_bl) << "[ycdebug] not replace due to yc_item_id : "
                                          << yc_item_id << " in show histroy";
        } else {
          result->set_yc_replaced_id(item_id);
          result->set_item_id(yc_item_id);
          LOG_IF(INFO, FLAGS_debug_yc_bl) << "[ycdebug] yc item replaced, item_id : "
                                          << item_id << ", yc_item_id : " << yc_item_id;
        }
      }
    }
  }
}

void RankHooker::ReplaceOriginItem(RecommendResponse* response) {
  std::vector<int> pos_list;
  std::vector<std::string> keys;
  std::vector<std::string> values;
  std::vector<int> rets;
  for (int i = 0; i < response->result_size(); ++i) {
    reco::leafserver::RecoResult* result = response->mutable_result(i);
    if (result->strategy_type() == reco::kBanner || result->strategy_type() == reco::kManual) continue;
    if (result->has_yc_replaced_id()) {
      LOG_IF(INFO, FLAGS_debug_yc_bl) << "[ycdebug] yc item replaced, not process bl replace";
      continue;
    }
    uint64 orig_item_id = 0;
    uint64 item_id = result->item_id();

    if (news_index_->GetOriginInfoByItemId(item_id, &orig_item_id)) {
      LOG_IF(INFO, FLAGS_debug_yc_bl) << "[ycdebug] orig item get succ, item_id : "
                                      << item_id << " orig_item_id : "
                                      << orig_item_id;
      if (orig_item_id != 0) {
        if (reco_strategy_->CheckIsShownByItemId(orig_item_id)) {
          LOG_IF(INFO, FLAGS_debug_yc_bl) << "[ycdebug] not replace due to orig_item_id : "
                                          << orig_item_id << " in show histroy";
        } else {
          result->set_orig_item_id(item_id);
          result->set_item_id(orig_item_id);
          LOG_IF(INFO, FLAGS_debug_yc_bl) << "[ycdebug] orig item replaced, item_id : "
                                          << item_id << ", orig_item_id : " << orig_item_id;
        }
      }
    }
  }
}
*/

void RankHooker::SetItemSubscript(const RecommendRequest &request,
                                  const ItemInfo &item,
                                  reco::leafserver::RecoResult *result) {
  if (item.strategy_type == reco::kQueryReco) return;
  // 推送文章角标
  if (request.has_pushed_item() && item.item_id == request.pushed_item()) {
    result->mutable_subscript()->set_type(reco::kPushItemSubscript);
    return;
  }

  // 订阅源角标
  if (item.strategy_type == reco::kSubscriptSource) {
    result->mutable_subscript()->set_type(reco::kWeMediaSubscript);
    return;
  }

  // 添加视频角标
  if (request.has_channel_id() &&
      !reco::common::IsVideoChannel(request.channel_id())) {
    if (item.item_type == reco::kPureVideo) {
      result->mutable_subscript()->set_type(reco::kVideoSubscript);
      result->mutable_subscript()->set_desc("视频");
      return;
    }
  }

  const UserFeature& user_fea = reco_strategy_->GetUserFeature();
  const auto& subscript_words = user_fea.behavior_fea.subscript_words;
  // 热 和 荐 的角标
  if (item.strategy_type == reco::kHot) {
    result->set_is_hot(true);
    result->mutable_subscript()->set_type(reco::kHotSubscript);
    return;
  } else if (item.strategy_type == reco::kExploit) {
    result->set_is_reco(true);
    result->mutable_subscript()->set_type(reco::kRecoSubscript);
    return;
  } else if (item.strategy_type == reco::kSubscription) {
    // 已订阅标签露出角标策略
    if (!result->has_hit_tag()) {
      result->set_hit_tag(item.ir_word);
      if (item.ir_type == reco::kSubscriptEventIr) {
        result->set_hit_tag_type(1);
      } else {
        result->set_hit_tag_type(0);
      }
      VLOG(1) << "set hit tag reco reason phase ! " << item.item_id << ", " << item.ir_word;
    }
  } else if (!result->has_hit_tag() && !subscript_words.empty()) {
    std::vector<std::string> show_tags;
    news_index_->GetTitleCoreTagsByItemId(item.item_id, &show_tags);
    std::string hit_tag;
    for (size_t i = 0; i < show_tags.size(); ++i) {
      if (subscript_words.find(show_tags[i]) != subscript_words.end()) {
        hit_tag = show_tags[i];
        break;
      }
    }
    if (!hit_tag.empty()) {
      result->set_hit_tag(hit_tag);
      result->set_hit_tag_type(0);
    } else {
      std::vector<std::string> event_tags;
      news_index_->GetEventTagByDocId(item.doc_id, &event_tags);
      for (size_t i = 0; i < event_tags.size(); ++i) {
        if (subscript_words.find(event_tags[i]) != subscript_words.end()) {
          hit_tag = event_tags[i];
          break;
        }
      }
      if (!hit_tag.empty()) {
        result->set_hit_tag(hit_tag);
        result->set_hit_tag_type(1);
      }
    }
  }

  // 在本地频道，添加 poi 角标 或者 本地热门自动角标
  if (request.has_channel_id() && request.channel_id() == reco::common::kLocalChannelId &&
      request.has_region_id()) {
    if (item.strategy_type != reco::kManual && item.strategy_type != reco::kBanner) {
      // 对基于位置触发的内容打上 POI 标签
      POITag poi_tag;
      if (reco_strategy_->GetItemPOITag(item.item_id, &poi_tag) &&
          poi_tag.has_literal() && !poi_tag.literal().empty()) {
        result->mutable_poi_tag()->CopyFrom(poi_tag);
        VLOG(1) << "poi tag: " << item.item_id << ", "
                << nlp::util::NormalizeLine(poi_tag.Utf8DebugString());
        return;
      }

      // 对于位置不匹配的内容打上 POI 标签
      reco::GaoDePOI gaode_poi;
      if (news_index_->GetGaoDePOIByDocId(item.doc_id, &gaode_poi) &&
          gaode_poi.quxian_poiinfos_size() > 0) {
        auto &poi_info = gaode_poi.quxian_poiinfos(0);
        int64 poi_id;
        if (base::StringToInt64(poi_info.adcode(), &poi_id) && !poi_info.name().empty() &&
            news_map::UpdateNewsMap::IsNewsMapCity(poi_id)) {
          poi_tag.Clear();
          poi_tag.set_id(poi_id);
          poi_tag.set_literal(poi_info.name());
          poi_tag.set_poi_tag_type(POITag::kDistrictPOITag);
          result->mutable_poi_tag()->CopyFrom(poi_tag);
          VLOG(1) << "poi tag: " << item.item_id << ", "
                  << nlp::util::NormalizeLine(poi_tag.Utf8DebugString());
          return;
        }
      }

      if ((item.hot_level >= reco::item_level::kHotScoreThres
           || item.spider_score >= 20)) {
        auto &city_id_name_map = global_data_->city_id_name_map;
        auto &region_id =  request.region_id();
        auto city_iter = city_id_name_map.find(region_id);
        if (city_iter != city_id_name_map.end()) {
          std::string literal = city_iter->second + "热门";
          result->mutable_subscript()->set_type(reco::kRegionHotSubscript);
          result->mutable_subscript()->set_desc(literal);
          return;
        }
      }
    }
  }

  // 对推荐频道，添加 poi 角标
  if (item.strategy_type == reco::kGeo &&
      (!request.has_channel_id() || request.channel_id() == reco::common::kRecoChannelId)) {
    POITag poi_tag;
    if (reco_strategy_->GetItemPOITag(item.item_id, &poi_tag) &&
        poi_tag.has_literal() && !poi_tag.literal().empty()) {
      result->mutable_subscript()->set_type(reco::kRegionHotSubscript);
      result->mutable_subscript()->set_desc(poi_tag.literal());
      return;
    }
  }

  // 设置我的学校角标  TODO(zhengying) 临时需求
  if (request.has_school()) {
    if (result->has_probe_type() && result->probe_type() == reco::kPoiProbe) {
      result->mutable_subscript()->set_type(reco::KSchoolSubscript);
      result->mutable_subscript()->set_desc("我的学校");
      return;
    }
  }
}

bool RankHooker::WeMediaRecommend(const WeMediaRecommendRequest &request,
                                  const UserInfo& user_info,
                                  WeMediaRecommendResponse *response,
                                  bool get_user_error) {
  WeMediaRecommendRequest alter_request(request);
  return reco_strategy_->WeMediaRecommend(&user_info, get_user_error, &alter_request, response);
}

bool RankHooker::ImCardRecommend(const UserInfo& user_info,
                                 bool get_user_error,
                                 const ImCardRecoRequest &request,
                                 ImCardRecoResponse *response,
                                 CostTrace *cost_trace) {
  serving_base::Timer timer;
  timer.Start();

  // im card switch
  if (!FLAGS_do_im_card_switch) {
    response->set_success(true);
    return true;
  }

  ImCardRecoRequest alter_request(request);
  cost_trace->ins = timer.Stop();

  return reco_strategy_->ImCardRecommend(&user_info, get_user_error, &alter_request, response, cost_trace);
}

bool RankHooker::GetNewsMap(const NewsMapRequest* request, NewsMapResponse* response) {
  reco::news_map::NewsMapProc::instance().GetNewsMap(request, response);
  return response->success();
}

bool RankHooker::SceneCardRecommend(const UserInfo& user_info,
                                    bool get_user_error,
                                    const SceneCardRecoRequest &request,
                                    SceneCardRecoResponse *response,
                                    CostTrace *cost_trace) {
  serving_base::Timer timer;
  timer.Start();

  // scene card switch
  if (!FLAGS_do_scene_card_switch) {
    response->set_success(true);
    return true;
  }

  SceneCardRecoRequest alter_request(request);
  cost_trace->ins = timer.Stop();

  return reco_strategy_->SceneCardRecommend(&user_info, get_user_error, &alter_request, response, cost_trace);
}

bool RankHooker::HotCardRecommend(const UserInfo& user_info,
                                  bool get_user_error,
                                  const HotCardRecommendRequest &request,
                                  HotCardRecommendResponse *response,
                                  CostTrace *cost_trace) {
  serving_base::Timer timer;
  timer.Start();

  // hot card switch
  if (!FLAGS_do_hot_card_switch) {
    response->set_success(true);
    response->set_reco_id(request.reco_id());
    response->set_item_id(0);
    return true;
  }

  HotCardRecommendRequest alter_request(request);
  cost_trace->ins = timer.Stop();
  return reco_strategy_->HotCardRecommend(&user_info, get_user_error, &alter_request, response, cost_trace);
}

void RankHooker::SetTimeAxisInfo(const UserInfo &user_info,
                                 const ItemInfo &item,
                                 std::unordered_set<uint64> *dedups,
                                 reco::leafserver::RecoResult *result) {
  if (!FLAGS_open_time_axis_switch) return;
  // 一屏下发的时间轴不超过 3 条
  if (dedups->size() >= 3u) return;

  reco::time_axis::TimeAxisInfo info;
  if (!news_index_->GetItemTimeAxisInfoByItemId(item.item_id, &info)) {
    return;
  }
  // 一屏不能出现多个相同的时间轴
  if (dedups->find(info.id()) != dedups->end()) {
    return;
  }

  // 多屏不能连续出
  std::string key = base::StringPrintf("%lu-%lu", user_info.identity().user_id(), info.id());
  auto val = time_axis_shown_dict_->Find(key);
  uint32 screen_count = val ? (*val) : 0;
  time_axis_shown_dict_->Add(key, screen_count + 1);
  if (FLAGS_time_axis_deliver_screen_gap > 0) {
    if (screen_count % FLAGS_time_axis_deliver_screen_gap != 0) {
      return;
    }
  }
  result->mutable_time_axis_info()->CopyFrom(info);
  dedups->insert(info.id());
}

void RankHooker::SetTimeAxisLatestNewsInfo(const UserInfo &user_info,
                                           const ItemInfo &item,
                                           const std::string &event_tag,
                                           reco::leafserver::RecoResult *result) {
  if (!FLAGS_open_time_axis_switch) return;

  reco::time_axis::TimeAxisInfo info;
  uint64 latest_item_id = 0;
  if (!news_index_->GetLatestNewsByEventName(event_tag, &latest_item_id, &info)
      || latest_item_id != item.item_id) {
    return;
  }

  // 多屏不能连续出
  // std::string key = base::StringPrintf("%lu-%lu", user_info.identity().user_id(), info.id());
  // auto val = time_axis_shown_dict_->Find(key);
  // uint32 screen_count = val ? (*val) : 0;
  // time_axis_shown_dict_->Add(key, screen_count + 1);
  // if (FLAGS_time_axis_deliver_screen_gap > 0) {
  //   if (screen_count % FLAGS_time_axis_deliver_screen_gap != 0) {
  //    return;
  //  }
  //}
  result->mutable_time_axis_info()->CopyFrom(info);
  VLOG(1) << "set time axis info for item_id:" << item.item_id;
}

void RankHooker::SetVideoShowTag(const ItemInfo &item, reco::leafserver::RecoResult *result) {
  if (item.strategy_type == reco::kQueryReco) return;
  if (FLAGS_only_return_reviewed_video_show_tag) {
    if (!news_index_->GetHasReviewedByDocId(item.doc_id) && item.strategy_type != reco::kManual) {
      return;
    }
  }
  std::vector<std::string> show_tags;
  if (!news_index_->GetShowTagByDocId(item.doc_id, &show_tags)) {
    return;
  }
  static const int kMaxShowTagNum = 4;
  int tag_num = std::min(kMaxShowTagNum, (int)show_tags.size());
  for (int i = 0; i < tag_num; ++i) {
    VideoShowTag* video_show_tag = result->add_video_show_tag();
    video_show_tag->set_real_tag(show_tags[i]);
    VLOG(1) << "set video_show_tag: " << item.item_id << ", " << show_tags[i];
  }
}

}  // namespace leafserver
}  // namespace reco
