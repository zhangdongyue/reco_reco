#include "reco/serv/reco_leaf/strategy/external_api/external_api.h"

#include <unordered_set>

#include "base/time/time.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"

#include "nlp/common/nlp_util.h"

#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"

#include "reco/bizc/proto/ha3_item.pb.h"
#include "reco/bizc/reco_index/media_quantity_assurance.h"

namespace reco {
namespace leafserver {

ExternalApi::ExternalApi() {
  news_index_ = LeafDataManager::GetGlobalData()->news_index;
  candidates_extractor_ = new CandidatesExtractor(news_index_);
  CHECK_NOTNULL(news_index_);
}

ExternalApi::~ExternalApi() {
  delete candidates_extractor_;
}

bool ExternalApi::GetHotNews(const GetHotNewsRequest& request,
                             GetHotNewsResponse* response) {
  // 功能点：频道下按文章的创建时间过滤
  base::Time start_time;
  base::Time end_time;
  if (!base::Time::FromStringInFormat(request.start_time().c_str(), "%Y-%m-%d %H:%M:%S", &start_time)
      || !base::Time::FromStringInFormat(request.end_time().c_str(), "%Y-%m-%d %H:%M:%S", &end_time)) {
    LOG(ERROR) << "request starttime/endtime format error. "
               << nlp::util::NormalizeLine(request.Utf8DebugString());
    return false;
  }
  int64 start_timestamp = start_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int64 end_timestamp = end_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  // 功能点：按照类目或者频道查询
  bool contain_image = false;
  std::unordered_set<uint64> item_dedup;
  std::vector<int64> channels;
  std::vector<ItemInfo> hot_items;
  std::vector<ItemInfo> candidates;
  if (request.has_category() && !request.category().empty()) {
    candidates_extractor_->GetDefaultCandidates(&candidates, kCandidatesCutoff, request.category(), 0);
  } else if (request.has_channel_id() && request.channel_id() != 0) {
    candidates_extractor_->GetDefaultCandidates(&candidates, kCandidatesCutoff, "", request.channel_id());
  } else {
    candidates_extractor_->GetDefaultCandidates(&candidates, kCandidatesCutoff, "", 0);
  }
  const std::vector<ItemInfo>* candidate_items = &candidates;
  // 功能点：无效文章过滤、无图文章过滤
  for (size_t i = 0; i < candidate_items->size(); ++i) {
    if (contain_image && (int)hot_items.size() >= request.max_return_num()) break;
    const ItemInfo& item_info = candidate_items->at(i);
    if (!news_index_->IsValidByItemId(item_info.item_id)) {
      VLOG(3) << item_info.item_id << " invalid";
      continue;
    }

    if (item_dedup.find(item_info.item_id) != item_dedup.end()) continue;

    int64 timestamp = news_index_->GetCreateTimestampByItemId(item_info.item_id);
    if (!(start_timestamp <= timestamp && timestamp < end_timestamp)) continue;

    int image_num = news_index_->GetImageCountByItemId(item_info.item_id);
    if (image_num == 0 && (int)hot_items.size() >= request.max_return_num()) continue;

    if (image_num > 0) contain_image = true;

    item_dedup.insert(item_info.item_id);
    const std::set<uint64>* sim_ids = news_index_->GetSimItemIds(item_info.item_id);
    if (sim_ids != NULL) {
      for (auto it = sim_ids->begin(); it != sim_ids->end(); ++it) {
        item_dedup.insert(*it);
      }
    }

    hot_items.push_back(item_info);
  }

  // 功能点：补全文章信息
  std::vector<std::string> title_unigrams;
  std::vector<reco::Category> categories;
  std::string str_time;
  for (size_t i = 0; i < hot_items.size(); ++i) {
    const ItemInfo& item_info = hot_items[i];
    reco::leafserver::HotNewsInfo result;

    result.set_item_id(item_info.item_id);
    result.set_hot_score(item_info.hot_level);
    //
    categories.clear();
    news_index_->GetCategoriesByItemId(item_info.item_id, &categories);
    for (size_t j = 0; j < categories.size(); ++j) {
      result.add_item_category(categories[j].category());
    }
    // title
    title_unigrams.clear();
    if (!news_index_->GetAreaUnigramsByDocId(item_info.doc_id, adsindexing::kTitleArea, &title_unigrams)) {
      LOG(ERROR) << "failed to get title id" << item_info.item_id;
    }
    result.set_item_title(base::JoinStrings(title_unigrams, ""));
    // channel
    channels.clear();
    news_index_->GetChannelsByDocId(item_info.doc_id, &channels);
    for (size_t j = 0; j < channels.size(); ++j) {
      result.add_item_channel(channels[j]);
    }
    // item time
    int64 timestamp = news_index_->GetCreateTimestampByItemId(item_info.item_id);
    base::Time item_time = base::Time::FromDoubleT(timestamp / base::Time::kMicrosecondsPerSecond);
    str_time.clear();
    item_time.ToStringInSeconds(&str_time);
    result.set_item_time(str_time);
    int image_num = news_index_->GetImageCountByItemId(item_info.item_id);
    result.set_has_image(image_num > 0);

    response->add_hot_news()->CopyFrom(result);
  }

  return true;
}

bool ExternalApi::VerticalRecommend(const VerticalRequest& request,
                                    VerticalResponse* response) {
  std::vector<std::string> categories;
  for (int i = 0; i < request.category_size(); ++i) {
    categories.push_back(request.category(i));
  }
  if (categories.empty()) {
    return false;
  }
  reco::Category category;
  news_index_->ConvertToCategoryProto(categories, request.category_size()-1, &category);

  std::vector<ItemInfo> candidates;
  if (request.sort_method() == reco::kHotSort) {
    candidates_extractor_->GetVerticalCandidates(category, false, &candidates, kCandidatesCutoff);
  } else if (request.sort_method() == reco::kTimeSort) {
    candidates_extractor_->GetVerticalCandidates(category, true, &candidates, kCandidatesCutoff);
  }
  const std::vector<ItemInfo>* item_list = &candidates;

  std::unordered_set<uint64> item_dedup;
  std::vector<std::string> title_unigrams;
  int type_filter_num = 0;
  for (int i = 0; i < (int)item_list->size(); ++i) {
    if (response->result_size() > (int)request.return_num()) {
      break;
    }

    const ItemInfo& item_info = item_list->at(i);
    if (!news_index_->IsValidByItemId(item_info.item_id)) {
      VLOG(3) << item_info.item_id << " invalid";
      ++type_filter_num;
      continue;
    }
    // 功能点：文章类型过滤
    if ((request.item_type() == reco::kPicture && item_info.item_type != reco::kPicture)
        || (request.item_type() == reco::kHumor && item_info.item_type != reco::kHumor)) {
      ++type_filter_num;
      continue;
    }
    if (item_dedup.find(item_info.item_id) != item_dedup.end()) continue;

    item_dedup.insert(item_info.item_id);
    const std::set<uint64>* sim_ids = news_index_->GetSimItemIds(item_info.item_id);
    if (sim_ids != NULL) {
      for (auto it = sim_ids->begin(); it != sim_ids->end(); ++it) {
        item_dedup.insert(*it);
      }
    }

    RecoResult* result = response->add_result();
    result->set_item_id(item_info.item_id);
    result->set_outer_id("");
    if (request.only_id()) {
      continue;
    }
    // title
    title_unigrams.clear();
    news_index_->GetAreaUnigramsByDocId(item_info.doc_id, adsindexing::kTitleArea, &title_unigrams);
    result->set_title(base::JoinStrings(title_unigrams, ""));
    int64 timestamp = news_index_->GetCreateTimestampByItemId(item_info.item_id);
    result->set_create_timestamp(timestamp);
    if (timestamp > 0) {
      base::Time time = base::Time::FromDoubleT(timestamp / base::Time::kMicrosecondsPerSecond);
      time.ToStringInSeconds(result->mutable_create_time());
    }
  }
  LOG(INFO) << base::StringPrintf("reqest num[%d], filtered[%d], response num[%d]",
                                  request.return_num(), type_filter_num, response->result_size());
  return true;
}

bool ExternalApi::GetIndexStatus(const GetIndexStatusRequest& request,
                                 GetIndexStatusResponse* response) {
  response->set_success(true);
  const IndexType index_type = request.index_type();

  if (index_type == kAllIndex || index_type == kAppIndex) {
    NewsQueueToProto(kAppIndex, "app_index",
                     * (news_index_->sort_item_->app_index_.GetDict()),
                     response->add_index_queue_status());
  }
  if (index_type == kAllIndex || index_type == kUcbIndex) {
    NewsQueueToProto(kUcbIndex, "ucb_index",
                     * (news_index_->sort_item_->ucb_index_.GetDict()),
                     response->add_index_queue_status());
  }
  if (index_type == kAllIndex || index_type == kHotCardIndex) {
    NewsQueueToProto(kHotCardIndex, "hot_card_index",
                     * (news_index_->sort_item_->hot_card_index_.GetDict()),
                     response->add_index_queue_status());
  }
  if (index_type == kAllIndex || index_type == kJingpinIndex) {
    NewsQueueToProto(kJingpinIndex, "jingpin_index",
                     * (news_index_->sort_item_->jingpin_index_.GetDict()),
                     response->add_index_queue_status());
  }
  if (index_type == kAllIndex || index_type == kCategoryIndex) {
    const auto category_map = news_index_->sort_item_->category_index_.GetDict();
    if (request.has_literal() && category_map != NULL) {
      for (auto i = category_map->begin(); i != category_map->end(); ++i) {
        if (i->first.ToString() == request.literal()) {
          NewsQueueToProto(index_type, i->first.ToString(), i->second,
                           response->add_index_queue_status());
        }
      }
    } else {
      CategoryMapQueueToProto(kCategoryIndex,
                              * (news_index_->sort_item_->category_index_.GetDict()),
                              response);
    }
  }
  if (index_type == kAllIndex || index_type == kVideoCategoryIndex) {
    CategoryMapQueueToProto(kVideoCategoryIndex,
                            * (news_index_->sort_item_->video_category_index_.GetDict()),
                            response);
  }
  if (index_type == kAllIndex || index_type == kChannelIndex) {
    int64 channel_id;
    const auto channel_map = news_index_->sort_item_->channel_index_.GetDict();
    if (request.has_literal()
        && base::StringToInt64(request.literal(), &channel_id)
        && channel_map != NULL
        && channel_map->find(channel_id) != channel_map->end()) {
      NewsQueueToProto(kChannelIndex, request.literal(),
                       channel_map->find(channel_id)->second,
                       response->add_index_queue_status());
    } else {
      ChannelMapQueueToProto(kChannelIndex, *channel_map, response);
    }
  }
  if (index_type == kAllIndex || index_type == kVideoChannelIndex) {
    ChannelMapQueueToProto(kVideoChannelIndex,
                           * (news_index_->sort_item_->channel_video_index_.GetDict()),
                           response);
  }
  if (index_type == kAllIndex || index_type == kRegionIndex) {
    ChannelMapQueueToProto(kRegionIndex,
                           * (news_index_->sort_item_->region_index_.GetDict()),
                           response);
  }
  if (index_type == kAllIndex || index_type == kPoiIndex) {
    ChannelMapQueueToProto(kPoiIndex,
                           * (news_index_->sort_item_->poi_index_.GetDict()),
                           response);
  }
  return true;
}

bool ExternalApi::GetIndexQueue(const GetIndexQueueRequest& request,
                                GetIndexQueueResponse* response) {
  const std::vector<reco::ItemInfo>* queue = NULL;
  std::vector<reco::ItemInfo> tmp_item_list;
  if (request.index_type() == kAppIndex) {
    queue = news_index_->GetDefaultReco();
  } else if (request.index_type() == kUcbIndex) {
    queue = news_index_->GetUCBDefaultReco();
  } else if (request.index_type() == kCategoryIndex) {
    reco::Category category;
    category.set_level(0);
    category.set_category(request.literal());
    queue = news_index_->GetDefaultReco(category);
  } else if (request.index_type() == kChannelIndex) {
    int64 channel_id;
    if (base::StringToInt64(request.literal(), &channel_id)) {
      queue = news_index_->GetDefaultReco(channel_id, -1, false);
    } else {
      response->set_err_message(base::StringPrintf("error channel_id: %s", request.literal().c_str()));
      LOG(INFO) << response->err_message();
      return false;
    }
  } else if (request.index_type() == kVideoCategoryIndex) {
    reco::Category category;
    category.set_level(0);
    category.set_category(request.literal());
    queue = news_index_->GetVideoDefaultReco(category);
  } else if (request.index_type() == kVideoChannelIndex) {
    int64 channel_id;
    if (base::StringToInt64(request.literal(), &channel_id)) {
      queue = news_index_->GetVideoDefaultReco(channel_id, false);
    } else {
      response->set_err_message("parse channel_id error: " + request.literal());
      LOG(INFO) << response->err_message();
      return false;
    }
  } else if (request.index_type() == kHotCardIndex) {
    queue = news_index_->GetHotCardDefaultReco();
  } else if (request.index_type() == kJingpinIndex) {
    queue = news_index_->GetJingpinDefaultReco();
  } else if (request.index_type() == kRegionIndex) {
    int64 region_id;
    if (base::StringToInt64(request.literal(), &region_id)) {
      queue = news_index_->GetLocalDefaultReco(region_id);
    } else {
      response->set_err_message("parse region_id error: " + request.literal());
      LOG(INFO) << response->err_message();
      return false;
    }
  } else if (request.index_type() == kPoiIndex) {
    int64 poi_id;
    if (base::StringToInt64(request.literal(), &poi_id)) {
      queue = news_index_->GetPOIDefaultReco(poi_id);
    } else {
      response->set_err_message("parse poi_id error: " + request.literal());
      LOG(INFO) << response->err_message();
      return false;
    }
  } else if (request.index_type() == kEventTagDocListIndex) {
    std::vector<int32> doc_id_list;
    news_index_->GetDocsByEventTag(request.literal(), &doc_id_list, 10 * request.return_num());
    for (size_t i = 0; i < doc_id_list.size(); ++i) {
      reco::ItemInfo item_info;
      if (news_index_->GetItemInfoByDocId(doc_id_list[i], &item_info, false)) {
        tmp_item_list.push_back(item_info);
      }
    }
    queue = &tmp_item_list;
  }
  if (queue == NULL) {
    response->set_err_message("not find index queue: " + request.literal());
    LOG(WARNING) << response->err_message();
    return false;
  }
  std::map<std::string, int32> tag_count;
  int32 rank_pos = -1;
  int32 total_item_num = 0;
  for (auto i = queue->begin(); i != queue->end(); ++i) {
    // 创建时间过滤
    base::Time start_time, end_time;
    if (request.has_start_time()
        && base::Time::FromStringInFormat(request.start_time().c_str(), "%Y-%m-%d %H:%M:%S", &start_time)
        && request.has_end_time()
        && base::Time::FromStringInFormat(request.end_time().c_str(), "%Y-%m-%d %H:%M:%S", &end_time)) {
      int64 start_timestamp = start_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
      int64 end_timestamp = end_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
      int64 timestamp = news_index_->GetCreateTimestampByItemId(i->item_id);
      if (!(start_timestamp <= timestamp && timestamp < end_timestamp)) continue;
    }
    // ItemType 过滤
    if (request.has_item_type() && request.item_type() != i->item_type)
      continue;
    // SiteLevel 过滤
    if (request.has_site_level() && request.site_level() != i->site_level)
      continue;
    // TimeLevel 过滤
    if (request.has_time_level() && request.time_level() != i->time_level)
      continue;
    // SensitiveLevel 过滤
    if (request.has_sensitive_level() && (int32)request.sensitive_level() != i->sensitive_type)
      continue;
    // itemq 过滤
    if (request.has_quality_level() && (int32)request.quality_level() != i->itemq)
      continue;
    // 源过滤
    if (request.has_source()) {
      std::string source;
      news_index_->GetSourceByItemId(i->item_id, &source);
      if (source != request.source())
        continue;
    }
    // 无效文章过滤
    if (request.filter_invalid() && !news_index_->IsValidByItemId(i->item_id))
      continue;
    // 过期文章过滤
    if (request.filter_expiry() && news_index_->IsExpiredByItemId(i->item_id, base::GetTimestamp()))
      continue;
    if (request.has_item_id() && request.item_id() != i->item_id)
      continue;

    // start_num 和 return_num 过滤
    ++rank_pos;
    ++total_item_num;
    if (rank_pos >= request.start_num() && rank_pos <= request.start_num() + request.return_num()) {
      RecoDebugInfo::ItemInfo* item_info = response->add_item_info();
      RecoDebugger::ToProtoItemInfo(*i, item_info);
      if (request.virgin_rank_pos())
        response->add_virgin_rank_pos(i - queue->begin());
      item_info->set_spider_score(i->new_pr);
      item_info->set_reco_score(i->media_level);

      static const int kMaxTagReturn = 5;
      reco::FeatureVector fea_vec;
      if (news_index_->GetFeatureVectorByItemId(i->item_id, reco::common::kTag, &fea_vec)) {
        for (int idx = 0; idx < fea_vec.feature_size() && idx < kMaxTagReturn; ++idx) {
          ++tag_count[fea_vec.feature(idx).literal()];
        }
      }

      if (request.only_id())
        continue;
      std::vector<std::string> title_unigrams;
      if (news_index_->GetAreaUnigramsByDocId(i->doc_id, adsindexing::kTitleArea, &title_unigrams)) {
        item_info->set_item_title(base::JoinStrings(title_unigrams, ""));
      }
      news_index_->GetSourceByItemId(i->item_id, item_info->mutable_source());
      news_index_->GetOrigSourceByItemId(i->item_id, item_info->mutable_orig_source());
      news_index_->GetShowSourceByItemId(i->item_id, item_info->mutable_show_source());
    }
  }
  response->set_total_item_info(total_item_num);
  LOG(INFO) << "tag_distirbute:  all_tag_num , " << tag_count.size();
  return true;
}

bool ExternalApi::GetIndexQueueUnsort(const GetIndexQueueUnsortRequest& request,
                                GetIndexQueueUnsortResponse* response) {
  response->set_success(false);
  std::vector<int32> doc_id_list;
  std::string err_msg = "";
  if (request.has_item_id()) {
    int doc_id;
    if(news_index_->GetDocIdByItemId(request.item_id(), &doc_id)) {
      doc_id_list.push_back(doc_id);
    } else {
      response->set_success(true);
      response->set_total_num(0);
      return true;
    }
  } else if (request.index_type() == kCategoryIndex) {
    news_index_->GetDocsByCategory(request.literal(), 0, &doc_id_list, 0);
  } else if (request.index_type() == kAppToken) {
    news_index_->GetDocsByAppToken(request.literal(),  &doc_id_list);
  } else if (request.index_type() == kChannelIndex) {
    int64 channel_id;
    if (base::StringToInt64(request.literal(), &channel_id)) {
      news_index_->GetDocsByChannelId(channel_id, &doc_id_list);
    } else {
      err_msg="channel_id error:"+request.literal();
      response->set_err_message(err_msg);
      LOG(ERROR) << err_msg;
      return false;
    }
  }
  int32 return_num = 0;
  int32 pos = 0;
  uint64 item_id;
  for(size_t i = 0; i < doc_id_list.size(); i++) {
    int32 doc_id = doc_id_list[i];
    if (!news_index_->GetItemIdByDocId(doc_id, &item_id)) {
      continue;
    }

    if (!news_index_->IsValidByDocId(doc_id)) {
      continue;
    }

    if (request.has_item_id() && item_id != request.item_id()) {
      continue;
    }

    if (pos >= request.start_num() && pos < request.start_num() + request.return_num()) {
      response->add_item_id(item_id);

      if (request.need_attr()) {
        reco::ItemInfoHa3* item_info = response->add_item_info();
        news_index_->GetItemInfoHa3ByDocId(doc_id, item_info);
      }
      return_num++;
    }

    pos++;
  }

  response->set_success(true);
  response->set_start_num(request.start_num());
  response->set_total_num(doc_id_list.size());
  return true;
}

void ExternalApi::NewsQueueToProto(IndexType index_type,
                                   const std::string& literal,
                                   const reco::SortItem::NewsQueue& queue,
                                   IndexQueueStatus* queue_status) {
  LOG(INFO) << IndexType_Name(index_type) << ", " << literal;
  queue_status->set_index_type(index_type);
  queue_status->set_literal(literal);
  queue_status->set_index_size(queue.GetIndex()->size());
  queue_status->set_today_news_num(queue.today_news_num);
  auto index = queue.GetIndex();
  if (index == NULL)
    return;
  const int64 now = base::GetTimestamp();
  int32 invalid_count = 0;
  int32 expiry_count = 0;
  std::map<reco::ItemType, int32> item_type_count;
  std::map<reco::SiteLevel, int32> site_level_count;
  std::map<reco::TimeLevel, int32> time_level_count;
  std::map<int32, int32> sensitive_count;
  std::map<int32, int32> quality_count;
  for (auto i = index->begin(); i != index->end(); ++i) {
    if (!news_index_->IsValidByItemId(i->item_id))
      ++invalid_count;
    if (news_index_->IsExpiredByItemId(i->item_id, now))
      ++expiry_count;

    ++item_type_count[i->item_type];
    ++site_level_count[i->site_level];
    ++time_level_count[i->time_level];
    ++sensitive_count[i->sensitive_type];
    ++quality_count[i->itemq];
  }
  queue_status->set_invalid_num(invalid_count);
  queue_status->set_expiry_num(expiry_count);
  for (auto i = item_type_count.begin(); i != item_type_count.end(); ++i) {
    auto item_type_num = queue_status->add_item_type_distribute();
    item_type_num->set_item_type(i->first);
    item_type_num->set_num(i->second);
  }
  for (auto i = site_level_count.begin(); i != site_level_count.end(); ++i) {
    auto site_level_num = queue_status->add_site_level_distribute();
    site_level_num->set_site_level(i->first);
    site_level_num->set_num(i->second);
  }
  for (auto i = time_level_count.begin(); i != time_level_count.end(); ++i) {
    auto time_level_num = queue_status->add_time_level_distribute();
    time_level_num->set_time_level(i->first);
    time_level_num->set_num(i->second);
  }
  for (auto i = sensitive_count.begin(); i != sensitive_count.end(); ++i) {
    if (SensitivityLevel_IsValid(i->first)) {
      auto sensitive_num = queue_status->add_sensitive_level_distribute();
      sensitive_num->set_sensitive_type((SensitivityLevel)(i->first));
      sensitive_num->set_num(i->second);
    }
  }
  for (auto i = quality_count.begin(); i != quality_count.end(); ++i) {
    if (QualityLevel_IsValid(i->first)) {
      auto quality_num = queue_status->add_quality_level_distribute();
      quality_num->set_quality_type((QualityLevel)(i->first));
      quality_num->set_num(i->second);
    }
  }
}

void ExternalApi::CategoryMapQueueToProto(IndexType index_type,
                                          const CategoryMap& category_map,
                                          GetIndexStatusResponse* response) {
  LOG(INFO) << IndexType_Name(index_type) << " category map size: " << category_map.size();
  for (auto i = category_map.begin(); i != category_map.end(); ++i) {
    NewsQueueToProto(index_type, i->first.ToString(), i->second,
                     response->add_index_queue_status());
  }
}

void ExternalApi::ChannelMapQueueToProto(IndexType index_type,
                                         const ChannelMap& channel_map,
                                         GetIndexStatusResponse* response) {
  LOG(INFO) << IndexType_Name(index_type) << " channel map size: " << channel_map.size();
  for (auto i = channel_map.begin(); i != channel_map.end(); ++i) {
    NewsQueueToProto(index_type, base::Int64ToString(i->first), i->second,
                     response->add_index_queue_status());
  }
}

bool ExternalApi::GetIndexItemInfo(const GetIndexItemInfoRequest& request,
                                   GetIndexItemInfoResponse* response) {
  const uint64 item_id = request.item_id();
  response->set_item_id(item_id);

  reco::ItemInfo item_info;
  if (!news_index_->GetItemInfoByItemId(item_id, &item_info, false)) {
    response->set_err_message("can't get item info.");
    LOG(INFO) << response->err_message() << item_id;
    return false;
  }

  news_index_->GetProducerByDocId(item_info.doc_id, response->mutable_app_token());
  news_index_->GetSourceByItemId(item_id, response->mutable_source());
  int32 orig_media_risk_type = -1;
  news_index_->GetOrigMediaRiskTypeByItemId(item_id, &orig_media_risk_type);
  response->set_orig_media_risk_type(orig_media_risk_type);
  news_index_->GetOrigSourceByItemId(item_id, response->mutable_orig_source());
  news_index_->GetShowSourceByItemId(item_id, response->mutable_show_source());

  news_index_->GetItemTitleByItemId(item_id, response->mutable_title());
  news_index_->GetItemBidwordByItemId(item_id, response->mutable_bidword());
  news_index_->GetItemContentByItemId(item_id, response->mutable_content());
  news_index_->GetItemQualityAttrByItemId(item_id, response->mutable_quality_attr());
  response->add_category(item_info.category);
  if (!item_info.sub_category.empty()) response->add_category(item_info.sub_category);
  reco::FeatureVector fea_vec;
  static const int kMaxKeywordReturn = 6;
  if (news_index_->GetFeatureVectorByItemId(item_id, reco::common::kKeyword, &fea_vec)) {
    for (int idx = 0; idx < fea_vec.feature_size(); ++idx) {
      if (response->keyword_size() >= kMaxKeywordReturn) break;
      const reco::Feature& fea = fea_vec.feature(idx);
      response->add_keyword(fea.literal());
    }
  }
  static const int kMaxTagReturn = 3;
  if (news_index_->GetFeatureVectorByItemId(item_id, reco::common::kTag, &fea_vec)) {
    for (int idx = 0; idx < fea_vec.feature_size(); ++idx) {
      if (response->tag_size() >= kMaxTagReturn) break;
      const reco::Feature& fea = fea_vec.feature(idx);
      response->add_tag(fea.literal());
    }
  }
  if (news_index_->GetFeatureVectorByItemId(item_id, reco::common::kSemanticTag, &fea_vec)) {
    for (int idx = 0; idx < fea_vec.feature_size(); ++idx) {
      if (response->tag_size() >= kMaxTagReturn) break;
      const reco::Feature& fea = fea_vec.feature(idx);
      response->add_semantic_tag(fea.literal());
    }
  }

  response->set_doc_mask(news_index_->GetDocMaskByItemId(item_id));

  bool is_trival;
  news_index_->GetContentAttrByItemId(item_id, response->mutable_content_attr(), &is_trival);
  news_index_->GetGaoDePOIByItemId(item_id, response->mutable_poi());
  news_index_->GetUCBSettingByItemId(item_id, response->mutable_uc_browser_deliver_setting());
  response->set_sim_checked(news_index_->HasCheckedBySimServer(item_id));
  response->set_parent_id(news_index_->GetParentId(item_id));
  const std::set<uint64>* sims = news_index_->GetSimItemIds(item_id);
  if (sims != NULL) {
    for (auto it = sims->begin(); it != sims->end(); ++it) {
      response->add_sim_id(*it);
    }
  }
  int32 doc_id = 0;
  if (news_index_->GetDocIdByItemId(item_id, &doc_id)) {
    response->set_style_type(news_index_->GetUCBStyleTypeByDocId(doc_id));
    std::vector<int64> channel_ids;
    if (!news_index_->GetChannelsByDocId(doc_id, &channel_ids)) {
      for (size_t i = 0; i < channel_ids.size(); i ++) {
        response->add_channel_ids(channel_ids[i]);
      }
    }
  }

  response->set_is_valid(news_index_->IsValidByItemId(item_id));
  response->set_is_expired(news_index_->IsExpiredByItemId(item_id, base::GetTimestamp()));
  int64 timestamp = news_index_->GetCrawlTimestampByItemId(item_id) / base::Time::kMicrosecondsPerSecond;
  base::Time::FromDoubleT(timestamp).ToStringInSeconds(response->mutable_crawl_time());
  timestamp = news_index_->GetCreateTimestampByItemId(item_id) / base::Time::kMicrosecondsPerSecond;
  base::Time::FromDoubleT(timestamp).ToStringInSeconds(response->mutable_publish_time());

  response->set_show_num(item_info.show_num);
  response->set_click_num(item_info.click_num);
  float ctr = 0;
  if (item_info.show_num > 0) ctr = (float)item_info.click_num / item_info.show_num;
  response->set_ctr(ctr);
  response->set_hot_score(item_info.hot_level);
  response->set_time_level(item_info.time_level);
  response->set_site_level(item_info.site_level);
  response->set_item_quality(item_info.itemq);
  response->set_sensitive_type(item_info.sensitive_type);
  response->set_media_level(item_info.media_level);
  response->set_is_yuanchuang(news_index_->IsYuanchuangDocId(item_info.doc_id));

  response->set_content_length(news_index_->GetContentLengthByDocId(item_info.doc_id));
  response->set_paragraph_num(news_index_->GetParagraphNumByDocId(item_info.doc_id));
  response->set_video_num(news_index_->GetVideoCountByDocId(item_info.doc_id));
  response->set_image_num(news_index_->GetImageCountByDocId(item_info.doc_id));

  // 如果没在类目索引中，与它相似的哪篇文章在索引中
  reco::Category rc;
  rc.set_level(0);
  rc.set_category(item_info.category);
  const std::vector<reco::ItemInfo>* index_queue = news_index_->GetDefaultReco(rc);
  if (index_queue != NULL) {
    bool in_index = false;
    int32 index_pos = 0;
    for (auto i = index_queue->begin(); i != index_queue->end(); ++i) {
      if (i->item_id == item_info.item_id) {
        response->set_category_index_pos(index_pos);
        in_index = true;
      }
      ++index_pos;
    }
    if (!in_index && sims != NULL) {
      std::set<uint64> sim_item_ids;
      sim_item_ids.insert(sims->begin(), sims->end());
      index_pos = 0;
      for (auto i = index_queue->begin(); i != index_queue->end(); ++i) {
        if (sim_item_ids.find(i->item_id) != sim_item_ids.end()) {
          response->set_dedup_item_id(i->item_id);
          response->set_dedup_item_index_pos(index_pos);
        }
        ++index_pos;
      }
    }
  }

  reco::ItemGroupInfo group;
  if (news_index_->GetGroupInfoByDocId(item_info.doc_id, &group)) {
    response->mutable_group_info()->CopyFrom(group);
  }
  reco::dm::MediaQuantityInfo mqi;
  int64 item_limit = 0;
  if (news_index_->GetItemQuantityInfo(reco::kQueueDoc, item_info, &mqi, &item_limit)) {
    response->set_item_protect_limit(item_limit);
    response->set_protect_type(mqi.protect_type);
    response->set_media_protect_capacity(mqi.protect_capacity);
    response->set_media_deliver_num(mqi.deliever_num);
    response->set_guarantee_deliver_num(mqi.assurance_deliever_num);
    int64 source_deliver_num = 0L;
    int64 item_deliver_num = 0L;
    MediaQuantityInfoIns::instance().LocalGuaranteeDeliver(item_info,
                                                           &source_deliver_num, &item_deliver_num);
    response->set_local_media_deliver_num(source_deliver_num);
    response->set_local_item_deliver_num(item_deliver_num);
  }

  response->set_success(true);
  return true;
}

}  // namespace leafserver
}  // namespace reco
