#include "reco/serv/reco_leaf/strategy/external_api/tag_reco.h"

#include <algorithm>

#include "base/time/timestamp.h"
#include "base/random/pseudo_random.h"
#include "nlp/common/nlp_util.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/serv/reco_leaf/frame/inner/dynamic_dict_container.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

TagReco::TagReco() {
  global_data_ = LeafDataManager::GetGlobalData();
  req_tag_count_ = 12;
}

TagReco::~TagReco() {
}

bool TagReco::TagRecommend(const TagRecommendRequest &request,
                           const UserInfo& user_info,
                           TagRecommendResponse *response,
                           bool get_user_error) {
  if (get_user_error) {
    response->set_err_message("get_user_error");
    return false;
  }

  //auto related_dict = global_data_->subscript_tag_relevence_merged.GetDict();
  auto dict = DM_GET_DICT(reco::dm::SubscriptTagRelevenceDict,
                          DynamicDictContainer::kSubscriptTagRelevenceFile_);
  auto related_dict = &(dict->subscript_tag_relevence_merged);
  user_id_ = user_info.identity().user_id();

  req_tag_count_ = 12;
  if (request.has_req_count() && request.req_count() > 0) {
    req_tag_count_ = request.req_count();
  }

  // 获取订阅词
  std::set<std::string> subscribed_tags;
  ParseSubscriptWords(user_info, &subscribed_tags);

  // 标签 --> 标签, 搜索页关联标签
  response->clear_reco_tags();
  if (request.request_type() == reco::leafserver::TagRecommendRequest::kTag) {
    if (!request.has_base_tag() || request.base_tag().empty()) {
      response->set_err_message("type is kTag but no base_tag!");
      return false;
    }
    std::string base_tag = nlp::util::NormalizeLine(request.base_tag());
    auto it = related_dict->find(base_tag);
    if (it != related_dict->end() && !(it->second.empty())) {
      uint32 result_count = 0;
      for (auto it_rel = it->second.begin(); it_rel != it->second.end(); ++it_rel) {
        if (subscribed_tags.find(*it_rel) == subscribed_tags.end()) {
          *(response->add_reco_tags()) = *it_rel;
          ++result_count;
          if (result_count == req_tag_count_) break;
        }
      }
      return true;
    }
    return true;
  // 用户(已订阅标签+画像标签) --> 标签, 我的频道管理页标签推荐
  } else if (request.request_type() == reco::leafserver::TagRecommendRequest::kUser) {
    // 提取画像词
    std::set<std::string> profile_tags;
    ExtractProfileTags(user_info, &profile_tags);

    // 计算画像词和订阅词的关联标签
    std::set<std::string> related_tags;
    ClacRelatedTags(profile_tags, subscribed_tags, &related_tags);
    ClacRelatedTags(subscribed_tags, subscribed_tags, &related_tags);

    // 增加热点标签, 跟已经订阅标签去重
    auto hot_tags = global_data_->hot_tags_.GetDict();
    std::set<std::string> hot_tags_dedup;
    for (auto it_hot = hot_tags->begin(); it_hot != hot_tags->end(); ++it_hot) {
      const std::string &word = nlp::util::NormalizeLine(*it_hot);
      if (subscribed_tags.find(word) == subscribed_tags.end()) {
        hot_tags_dedup.insert(word);
      }
    }
    std::vector<std::string> all_tags(related_tags.size() + hot_tags_dedup.size());
    auto it = std::set_union(related_tags.begin(), related_tags.end(),
                             hot_tags_dedup.begin(), hot_tags_dedup.end(),
                             all_tags.begin());
    all_tags.resize(it - all_tags.begin());
    base::PseudoRandom pr(base::GetTimestamp());
    std::random_shuffle(all_tags.begin(), all_tags.end(), pr);

    VLOG(1) << "all_tags size:" << all_tags.size() << ", related:" << related_tags.size()
            << ", hot_tags:" << hot_tags->size() << ", hot_tags_dedup:" << hot_tags_dedup.size();

    for (int i = 0; i < (int)all_tags.size() && i < (int)req_tag_count_; ++i) {
      *(response->add_reco_tags()) = all_tags[i];
    }
    return true;
  }
  response->set_err_message("type is invalid !");
  return false;
}

void TagReco::ClacRelatedTags(const std::set<std::string> &tags,
                              const std::set<std::string> &subscribed_tags,
                              std::set<std::string> *related_tags) {
  //auto related_dict = global_data_->subscript_tag_relevence_merged.GetDict();
  auto dict = DM_GET_DICT(reco::dm::SubscriptTagRelevenceDict,
                          DynamicDictContainer::kSubscriptTagRelevenceFile_);
  auto related_dict = &(dict->subscript_tag_relevence_merged);

  for (auto it_tag = tags.begin(); it_tag != tags.end(); ++it_tag) {
    auto it = related_dict->find(*it_tag);
    if (it == related_dict->end() || it->second.empty()) continue;
    for (auto it_rel = it->second.begin(); it_rel != it->second.end(); ++it_rel) {
      if (subscribed_tags.find(*it_rel) == subscribed_tags.end()) {
        related_tags->insert(*it_rel);
        VLOG(1) << "raw_tag:" << *it_tag << ", related tag: " << *it_rel << ", user_id:" << user_id_;
      }
    }
  }
}

void TagReco::ParseSubscriptWords(const UserInfo& user_info,
                                  std::set<std::string> *subscribed_tags) {
  if (!user_info.has_subscription()
      || user_info.subscription().subscription_size() == 0) {
    return;
  }

  const reco::user::Subscription& subscription = user_info.subscription();
  VLOG(1) << "user_id:" << user_id_ << ", subscription_info:" << subscription.Utf8DebugString();
  for (int i = 0; i < subscription.subscription_size(); ++i) {
    const std::string &word = nlp::util::NormalizeLine(subscription.subscription(i));
    if (subscribed_tags->find(word) == subscribed_tags->end()) {
      subscribed_tags->insert(word);
    }
  }
  VLOG(1) << "subscribed tag size:" << subscribed_tags->size();
}

void TagReco::ExtractProfileTags(const UserInfo& user_info,
                                 std::set<std::string> *profile_tags) {
  const static double kMinWeight = 4.0;

  if (!user_info.has_profile()) return;

  const reco::user::Profile& profile = user_info.profile();
  if (!profile.has_tag_feavec()) return;

  std::unordered_map<std::string, double> merged_feature;

  // 不同类别下，同一个标签的权重原则上是不可比较的，这里权重相加有两个考虑：
  // 1. 不同类别下，出现相同标签的情况比较少
  // 2. 为了去重考虑
  const FeatureVector& fea_vec = profile.tag_feavec();
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const reco::Feature& fea = fea_vec.feature(i);
    if (fea.weight() <= 1e-6) continue;
    if (!fea.has_category()) {
      VLOG(1) << "tag feature has no category, " << fea.Utf8DebugString();
      continue;
    }
    if (fea.has_item_type() && fea.item_type() == reco::kNews) {
      auto it = merged_feature.find(fea.literal());
      if (it == merged_feature.end()) {
        merged_feature.insert(std::make_pair(fea.literal(), fea.weight()));
      } else {
        it->second += fea.weight();
      }
    }
  }

  std::vector<std::string> fields;
  for (auto it = merged_feature.begin(); it != merged_feature.end(); ++it) {
    if (it->second < kMinWeight) {
      VLOG(1) << "filter profile tag:" << it->first << ", weight:" << it->second << ", user_id:" << user_id_;
      continue;
    }
    fields.clear();
    base::SplitString(it->first, ":", &fields);
    if (fields.size() < 2u) {
      continue;
    }
    const std::string &tag = nlp::util::NormalizeLine(fields[1]);
    profile_tags->insert(tag);
    VLOG(1) << "passed profile tag:" << tag << ", weight:" << it->second << ", user_id:" << user_id_;
  }
}
}  // namespace leafserver
}  // namespace reco
