#pragma once

#include <string>
#include <set>

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_fea_extractor.h"

namespace reco {

namespace leafserver {
struct GlobalData;

class TagReco {
 public:
  TagReco();
  ~TagReco();

  bool TagRecommend(const TagRecommendRequest &request,
                    const reco::user::UserInfo& user_info,
                    TagRecommendResponse *response,
                    bool get_user_error);
 private:
  // 解析订阅词
  void ParseSubscriptWords(const reco::user::UserInfo& user_info,
                           std::set<std::string> *subscribed_tags);
  // 提取画像中的标签词
  void ExtractProfileTags(const reco::user::UserInfo& user_info,
                          std::set<std::string> *profile_tags);
  // 计算一个集合的关联标签
  void ClacRelatedTags(const std::set<std::string> &tags,
                       const std::set<std::string> &subscribed_tags,
                       std::set<std::string> *related_tags);

  uint64 user_id_;
  uint32 req_tag_count_;

  const GlobalData* global_data_;
};

}  // namespace leafserver
}  // namespace reco
