#pragma once

#include <string>
#include <vector>
#include <unordered_map>

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/reco_index/sort_item.h"

namespace reco {
class NewsIndex;

namespace leafserver {
class CandidatesExtractor;

class ExternalApi {
  typedef std::unordered_map<reco::common::WrappedCategory,
          reco::SortItem::NewsQueue,
          reco::common::CategoryHash> CategoryMap;
  typedef std::unordered_map<int64, reco::SortItem::NewsQueue> ChannelMap;

 public:
  ExternalApi();
  ~ExternalApi();

  // TODO(liufei): need to refine the function
  bool GetHotNews(const GetHotNewsRequest& request,
                  GetHotNewsResponse* response);

  // TODO(liufei): need to refine the function
  bool VerticalRecommend(const VerticalRequest& request,
                         VerticalResponse* response);

  bool GetIndexStatus(const GetIndexStatusRequest& request,
                      GetIndexStatusResponse* response);

  bool GetIndexQueue(const GetIndexQueueRequest& request,
                     GetIndexQueueResponse* response);

  bool GetIndexQueueUnsort(const GetIndexQueueUnsortRequest& request,
                     GetIndexQueueUnsortResponse* response);

  bool GetIndexItemInfo(const GetIndexItemInfoRequest& request,
                        GetIndexItemInfoResponse* response);

  void NewsQueueToProto(IndexType index_type,
                        const std::string& literal,
                        const reco::SortItem::NewsQueue& queue,
                        IndexQueueStatus* queue_status);

  void CategoryMapQueueToProto(IndexType index_type,
                               const CategoryMap& category_map,
                               GetIndexStatusResponse* response);

  void ChannelMapQueueToProto(IndexType index_type,
                              const ChannelMap& channel_map,
                              GetIndexStatusResponse* response);

 private:
  static const int kCandidatesCutoff = 6000;
  const reco::NewsIndex* news_index_;
  CandidatesExtractor* candidates_extractor_;
};

}  // namespace leafserver
}  // namespace reco
