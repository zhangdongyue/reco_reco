#pragma once

#include <string>
#include <vector>
#include <cmath>
#include <unordered_map>

#include "base/time/time.h"
#include "base/thread/blocking_var.h"
#include "base/testing/gtest_prod.h"

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/common/wrapped_category.h"
#include "reco/bizc/reco_index/item_info.h"

namespace reco {
namespace leafserver {

class ProfileTypeDetect {
 public:
  explicit ProfileTypeDetect(const reco::user::UserInfo& user_info) : user_info_(user_info) {
    Init();
  }
  ~ProfileTypeDetect() {}

  // item info to decide profile type
  void DetectProfileType(const reco::ItemInfo& item_info,
                         reco::ProfileType* profile_type, reco::DmpProfileType* dmp_profile_type) {
    DetectProfileType(item_info.category, item_info.sub_category, profile_type, dmp_profile_type);
  }

  // category and sub category, if has no sub category,  using ""
  void DetectProfileType(const std::string& category, const std::string& sub_category,
                         reco::ProfileType* profile_type, reco::DmpProfileType* dmp_profile_type);

  static void ConvertToCategoryProto(const std::vector<std::string>& categories, int level,
                                     reco::Category* category) {
    category->Clear();
    if (level >= (int)categories.size() || level < 0) {
      LOG(ERROR) << "error level: " << level;
      return;
    }

    category->set_level(level);
    category->set_category(categories[level]);
    for (int i = 0; i < level; ++i) {
      category->add_parents(categories[i]);
    }
  }

  int profile_confidence() const {
    return profile_confidence_;
  }

  float profile_weight() const {
    return total_profile_weight_;
  }

  float dmp_profile_weight() const {
    return total_dmp_profile_weight_;
  }

  static void DetectProfileConfidenceWeight(const reco::user::Profile& profile,
                                            int* confidence, double* weight);
 private:
  FRIEND_TEST(ProfileTypeTest, init);
  FRIEND_TEST(ProfileTypeTest, detect);

  void Init();

  const reco::user::UserInfo& user_info_;
  std::unordered_map<reco::common::WrappedCategory, double, reco::common::CategoryHash> profile_category_;
  std::unordered_map<reco::common::WrappedCategory, double, reco::common::CategoryHash> dmp_profile_category_;

  int profile_confidence_;
  double total_profile_weight_;

  int dmp_profile_confidence_;
  double total_dmp_profile_weight_;
};

}  // namespace
}  // namespace
