#include "reco/serv/reco_leaf/strategy/common/context_manager.h"
#include "base/time/time.h"
using serving_base::ExpiryMap;

namespace reco {
namespace leafserver {

DEFINE_double(working_day_short_video_score_boost, -0.4, "工作日对短视频减权");
DEFINE_double(weekend_short_video_score_boost, -0.4, "工作日对短视频减权");

ExpiryMap<std::string, double>*
    ContextManager::double_config_cache_ = new ExpiryMap<std::string, double>(5 * 60);

double ContextManager::ShortVideoScoreBoost() {
  double value;
  base::Time current_time = base::Time::Now();
  base::Time::Exploded exploded;
  current_time.LocalExplode(&exploded);
  // 周末的参数
  if (exploded.day_of_week == 0 or exploded.day_of_week == 6) {
    value = FLAGS_weekend_short_video_score_boost;
  } else {
    value = FLAGS_working_day_short_video_score_boost;
  }
  LOG(INFO) << "now short_video_score_boost: " << value;
  return value;
}

double ContextManager::GetConfig(const std::string& key) {
  double value;
  // 如果缓存里有就直接获取缓存中的
  if (GetConfigFromCache(key, &value)) {
    return value;
  }
  if (key == "short_video_score_boost") {
    value = ShortVideoScoreBoost();
  }
  // TODO(zhuzekun) 这里可以写其他配置
  // 写回缓存
  SetConfigToCache(key, value);
  return value;
}

bool ContextManager::GetConfigFromCache(const std::string& key, double* value) {
  return (double_config_cache_ && double_config_cache_->FindSilently(key, value));
}

void ContextManager::SetConfigToCache(const std::string& key, const double value) {
  if (double_config_cache_) {
     double_config_cache_->Add(key, value);
  }
}
}
}
