#include "reco/serv/reco_leaf/strategy/common/profile_type.h"

#include <algorithm>

#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/bizc/reco_index/news_index.h"

namespace reco {
namespace leafserver {
using reco::user::Profile;

void ProfileTypeDetect::DetectProfileConfidenceWeight(const Profile& profile,
                                                      int* confidence, double* weight) {
  *confidence = -1;
  *weight = 0;
  if (!profile.has_category_feavec()) {
    return;
  }

  for (int i = 0; i < profile.category_feavec().feature_size(); ++i) {
    auto& cate = profile.category_feavec().feature(i);
    if (cate.literal().level() == 0) {
      *weight += cate.weight();
    }
  }

  if (*weight > 100) {
    *confidence = 2;
  } else if (*weight > 30) {
    *confidence = 1;
  } else {
    *confidence = 0;
  }
}

void ProfileTypeDetect::Init() {
  profile_confidence_ = -1;
  total_profile_weight_ = 0;
  if (user_info_.has_profile()) {
    const Profile& profile = user_info_.profile();

    if (profile.has_category_feavec()) {
      double l1_sum_weight = 0;
      for (int i = 0; i < profile.category_feavec().feature_size(); ++i) {
        auto& cate = profile.category_feavec().feature(i);
        if (cate.literal().level() == 0) {
          l1_sum_weight += cate.weight();
        }
      }
      if (l1_sum_weight < 1e-8) {
        l1_sum_weight = 1.0;
      }

      for (int i = 0; i < profile.category_feavec().feature_size(); ++i) {
        reco::common::WrappedCategory cate(profile.category_feavec().feature(i).literal());
        if (cate.level() != 0) {
          continue;
        }
        profile_category_[cate] = profile.category_feavec().feature(i).weight() / l1_sum_weight;
      }
      total_profile_weight_ = l1_sum_weight;

      if (l1_sum_weight > 100) {
        profile_confidence_ = 2;
      } else if (l1_sum_weight > 30) {
        profile_confidence_ = 1;
      } else {
        profile_confidence_ = 0;
      }
    }
  }

  dmp_profile_confidence_ = -1;
  total_dmp_profile_weight_ = 0;
  if (user_info_.has_dmp_profile()) {
    const reco::user::DmpProfile& profile = user_info_.dmp_profile();
    if (profile.has_category_feavec()) {
      double sum_weight = 0;
      for (int i = 0; i < profile.category_feavec().feature_size(); ++i) {
        sum_weight += profile.category_feavec().feature(i).weight();
      }
      if (sum_weight < 1e-8) {
        sum_weight = 1.0;
      }

      for (int i = 0; i < profile.category_feavec().feature_size(); ++i) {
        reco::common::WrappedCategory cate(profile.category_feavec().feature(i).literal());
        dmp_profile_category_[cate] = profile.category_feavec().feature(i).weight() / sum_weight;
      }
      total_dmp_profile_weight_ = sum_weight;

      if (!profile.has_confidence()) {
        dmp_profile_confidence_ = 0;
      } else if (profile.confidence() > 0.95) {
        dmp_profile_confidence_ = 2;
      } else if (profile.confidence() > 0.75) {
        dmp_profile_confidence_ = 1;
      } else {
        dmp_profile_confidence_ = 0;
      }
    }
  }
}

void ProfileTypeDetect::DetectProfileType(const std::string& category,
                                          const std::string& sub_category,
                                          reco::ProfileType* profile_type,
                                          reco::DmpProfileType* dmp_profile_type) {
  *profile_type = reco::kNoProfileType;
  *dmp_profile_type = reco::kNoDmpProfileType;

  std::vector<std::string> flds;
  if (category.empty()) return;
  flds.push_back(category);
  // 先不做二级类别
  // if (!sub_category.empty()) {
  //   flds.push_back(sub_category);
  // }

  Category cate;
  ConvertToCategoryProto(flds, flds.size() - 1, &cate);
  reco::common::WrappedCategory wrapped_cate(cate);

  int profile_match = 0;
  auto it = profile_category_.find(wrapped_cate);
  if (it != profile_category_.end()) {
    double pv = it->second * total_profile_weight_;
    if (it->second > 0.3 || pv > 50) {
      profile_match = 2;
    } else if (it->second > 0.1 || pv > 20) {
      profile_match = 1;
    } else {
      profile_match = 0;
    }
  } else {
    profile_match = 0;
  }

  int dmp_profile_match = 0;
  it = dmp_profile_category_.find(wrapped_cate);
  if (it != dmp_profile_category_.end()) {
    double pv = it->second * total_dmp_profile_weight_;
    if (it->second > 0.3 || pv > 50) {
      dmp_profile_match = 2;
    } else if (it->second > 0.1 || pv > 20) {
      dmp_profile_match = 1;
    } else {
      dmp_profile_match = 0;
    }
  } else {
    dmp_profile_match = 0;
  }

  // LOG(ERROR) << profile_confidence_;
  // LOG(ERROR) << profile_match;
  // LOG(ERROR) << dmp_profile_confidence_;
  // LOG(ERROR) << dmp_profile_match;
  if (profile_confidence_ == 2) {
    if (profile_match == 2) {
      *profile_type = kHighProfileHighMatch;
    } else if (profile_match == 1) {
      *profile_type = kHighProfileMidMatch;
    } else if (profile_match == 0) {
      *profile_type = kHighProfileLowMatch;
    }
  } else if (profile_confidence_ == 1) {
    if (profile_match == 2) {
      *profile_type = kMidProfileHighMatch;
    } else if (profile_match == 1) {
      *profile_type = kMidProfileMidMatch;
    } else if (profile_match == 0) {
      *profile_type = kMidProfileLowMatch;
    }
  } else if (profile_confidence_ == 0) {
    if (profile_match == 2) {
      *profile_type = kLowProfileHighMatch;
    } else if (profile_match == 1) {
      *profile_type = kLowProfileMidMatch;
    } else if (profile_match == 0) {
      *profile_type = kLowProfileLowMatch;
    }
  }

  if (dmp_profile_confidence_ == 2) {
    if (dmp_profile_match == 2) {
      *dmp_profile_type = kHighDmpProfileHighMatch;
    } else if (dmp_profile_match == 1) {
      *dmp_profile_type = kHighDmpProfileMidMatch;
    } else if (dmp_profile_match == 0) {
      *dmp_profile_type = kHighDmpProfileLowMatch;
    }
  } else if (dmp_profile_confidence_ == 1) {
    if (dmp_profile_match == 2) {
      *dmp_profile_type = kMidDmpProfileHighMatch;
    } else if (dmp_profile_match == 1) {
      *dmp_profile_type = kMidDmpProfileMidMatch;
    } else if (dmp_profile_match == 0) {
      *dmp_profile_type = kMidDmpProfileLowMatch;
    }
  } else if (dmp_profile_confidence_ == 0) {
    if (dmp_profile_match == 2) {
      *dmp_profile_type = kLowDmpProfileHighMatch;
    } else if (dmp_profile_match == 1) {
      *dmp_profile_type = kLowDmpProfileMidMatch;
    } else if (dmp_profile_match == 0) {
      *dmp_profile_type = kLowDmpProfileLowMatch;
    }
  }
  // int dmp_profile_confidence_;
}
}  // namespace leafserver
}  // namespace reco
