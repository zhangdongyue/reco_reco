#pragma once

#include <vector>

#include "base/container/dense_hash_set.h"
#include "base/testing/gtest_prod.h"
#include "reco/bizc/proto/leaf_debug.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/proto/filter_rule.pb.h"

namespace reco {
namespace leafserver {

enum CandidateSourceType {
  TOP_IMPORTANCE_BIG_STYLE = 1,
  TOP_IMPORTANCE_NORMAL = 2,
  SND_CATE_IMPORTANCE = 3,
  SND_REGION = 4,
  CATEGORY_WHOLE = 5,
  OTHER_VERTICAL_CHANNEL = 6,
};

struct AssembleCardCandidateExtInfo {
  CandidateSourceType source_type;
  size_t candidate_idx;
  AssembleCardCandidateExtInfo(CandidateSourceType st, size_t idx) {
    source_type = st;
    candidate_idx = idx;
  }
};

class AutoAssembleCard {
 public:
  AutoAssembleCard();
  virtual ~AutoAssembleCard();

  void Clear();
  void SetCardId(uint64 item_id_);
  bool IsAssembleCard(uint64 item_id) const;

  void AddCandidate(const ItemInfo& candidate, CandidateSourceType source_type);
  void SortCandidates();
  bool HasBigStyleCandidateItem();
  bool CanAssembleCard(base::dense_hash_set<uint64>* item_dedup,
                       reco::filter::FilterReason* filter_reason);

  bool is_valid() const {
    return is_valid_;
  }
  uint64 item_id() const {
    return item_id_;
  }
  const std::vector<ItemInfo>& candidates() const {
    return candidates_;
  }
  const std::vector<ItemInfo>& sub_items() const {
    return sub_items_;
  }

 private:
  bool is_valid_;
  bool has_big_style_candidate_item_;
  uint64 item_id_;
  std::vector<ItemInfo> sub_items_;

  std::vector<ItemInfo> candidates_;
  std::vector<AssembleCardCandidateExtInfo> candidate_exts_;
  FRIEND_TEST(AutoAssembleCard, Sort);
};
}  // namespace leafserver
}  // namespace reco
