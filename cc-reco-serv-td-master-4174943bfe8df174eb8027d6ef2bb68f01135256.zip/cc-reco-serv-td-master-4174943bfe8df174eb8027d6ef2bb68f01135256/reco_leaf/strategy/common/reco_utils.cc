#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"

#include "base/random/pseudo_random.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;
using reco::user::ViewClickItem;
using reco::user::FollowWeMediaInfo;

DEFINE_bool(set_reco_channel_to_special_banner, true, "推荐频道是否设置为特殊置顶");
DEFINE_uint64(assemble_card_test_item_id, 14587598157881059851ul, "测试使用");
DEFINE_uint64(auto_event_card_test_item_id, 10386679204918097070ul, "测试使用");

bool RecoUtils::IsSpecialItem(const reco::NewsIndex* news_index, const ItemInfo& item) {
  int32 style_type = news_index->GetUCBStyleTypeByDocId(item.doc_id);
  // 专题及其它特性文章
  if (item.item_type == reco::kSpecial
      && style_type != 38) {
    return true;
  }

  // 样式 11 / 12 / 39 展现形式跟专题一样，下发时跟专题做一样的控制
  if (style_type == 11 || style_type == 12 || style_type == 39 || style_type == 58) {
    return true;
  }

  return false;
}

bool RecoUtils::IsChannelDaoliuItem(const reco::NewsIndex* news_index, const ItemInfo& item) {
  int32 style_type = news_index->GetUCBStyleTypeByDocId(item.doc_id);
  return style_type == 29;
}

bool RecoUtils::IsBigPicStyleItem(const reco::NewsIndex* news_index,
                                  const ItemInfo& item) {
  int32 style_type = news_index->GetUCBStyleTypeByDocId(item.doc_id);
  static const std::unordered_set<int> kBigPicStyleSet = {3, 6, 10, 11, 12, 27, 56};
  return (kBigPicStyleSet.find(style_type) != kBigPicStyleSet.end());
}

void RecoUtils::BuildUserShownDict(const reco::NewsIndex* news_index,
                                   const RecommendRequest* request,
                                   const UserInfo* user_info,
                                   base::dense_hash_set<uint64>* shown_dict,
                                   const bool filter_wemedia,
                                   const bool only_same_channel) {
  shown_dict->clear();
  int64 req_channel_id = request->has_channel_id() ? request->channel_id() : 0l;

  // 问啊频道的请求，相似文章不作为已展现过的文章
  bool add_sim_to_shown_dict
      = !(request->has_channel_id() && request->channel_id() == reco::common::kOperChannelId);

  ///////////// 展现的文章及相似文章进入去重列表
  std::unordered_set<uint64> preview_ids;
  for (int i = 0; i < user_info->shown_history_size(); ++i) {
    const ViewClickItem& item = user_info->shown_history(i);
    const uint64 item_id = item.item_id();
    if (only_same_channel &&
        (!item.has_channel_id() || item.channel_id() != req_channel_id)) {
      continue;
    }

    // 本身要不要加入去重列表
    if (!request->has_reco_alg() || request->reco_alg() == reco::leafserver::kRecoAlg) {
      // 推荐算法中的请求都要去重
      shown_dict->insert(item_id);
    } else if (request->has_channel_id()
               && item.has_channel_id()
               && request->channel_id() != item.channel_id()) {
      // 非推荐算法的频道请求，如果在其他频道出现过，也要做去重
      shown_dict->insert(item_id);
    }

    // 将相似 item 加入去重列表
    if (add_sim_to_shown_dict) {
      AddSimItemToShownDict(news_index, item_id, shown_dict);
    }

    ItemType item_type;
    if (!news_index->GetItemTypeByItemId(item_id, &item_type))
      item_type = reco::kNews;
    // 看过的专题，同时将专题的 preview 写入去重队列
    if (RecoUtils::IsNormalSpecialItem(news_index, item_type, item_id)
        || item_type == reco::kWeMediaCard) {
      preview_ids.clear();
      if (!news_index->GetPreviewIdsByItemId(item_id, &preview_ids)) continue;
      for (auto iter = preview_ids.begin(); iter != preview_ids.end(); ++iter) {
        shown_dict->insert(*iter);
        if (add_sim_to_shown_dict) {
          AddSimItemToShownDict(news_index, *iter, shown_dict);
        }
      }
    }
  }

  ///////////// click 过的 item 也写到去重队列
  for (int i = 0; i < user_info->recent_click_size(); ++i) {
    const ViewClickItem& item = user_info->recent_click(i);
    const uint64 item_id = item.item_id();
    ItemType item_type;
    if (!news_index->GetItemTypeByItemId(item_id, &item_type))
      item_type = reco::kNews;

    if (item_type != reco::kSpecial && item_type != reco::kWeMediaCard) {
      shown_dict->insert(item_id);
      if (add_sim_to_shown_dict) {
        AddSimItemToShownDict(news_index, item_id, shown_dict);
      }
    }
  }

  ////////// 关注过的自媒体文章直接进入去重列表
  if (filter_wemedia && user_info->has_wemedia_info()) {
    auto wemedia_dict = news_index->GetWeMediaItemsDict();
    const FollowWeMediaInfo& follow_infos = user_info->wemedia_info();
    for (int idx = 0; idx < follow_infos.wemedia_name_size(); ++idx) {
      const std::string& name = follow_infos.wemedia_name(idx);
      auto iter = wemedia_dict->find(name);
      if (iter == wemedia_dict->end()) continue;
      const std::unordered_set<uint64>& items = iter->second;
      for (auto item_iter = items.begin(); item_iter != items.end(); ++item_iter) {
        shown_dict->insert(*item_iter);
      }
    }
  }
}

void RecoUtils::AddSimItemToShownDict(const reco::NewsIndex* news_index, uint64 item_id,
                                      base::dense_hash_set<uint64>* shown_dict) {
  const std::set<uint64>* sim_ids = news_index->GetSimItemIds(item_id);
  if (sim_ids == NULL) return;
  for (auto it = sim_ids->begin(); it != sim_ids->end(); ++it) {
    shown_dict->insert(*it);
  }
}

int RecoUtils::IsSameDay(const base::Time& left, const base::Time& right) {
  base::Time::Exploded exploded;
  left.LocalExplode(&exploded);
  int left_day = exploded.day_of_month;
  right.LocalExplode(&exploded);
  int right_day = exploded.day_of_month;
  return (left_day == right_day);
}

int RecoUtils::GetHourSpanNum(const base::Time &time_a, const base::Time &time_b, int span_hours) {
  base::Time a_time = time_a;
  base::Time b_time = time_b;
  if (a_time >= b_time) return 0;
  int hours_interval = (time_b - time_a).InHours();
  return hours_interval / span_hours;
}

int RecoUtils::GetPureVideoNum(const reco::NewsIndex* news_index,
                               const ItemInfo& item) {
  if (item.item_type == reco::kPureVideo) return 1;

  int video_count = 0;
  if (item.item_type == reco::kSpecial
      || item.item_type == reco::kWeMediaCard) {
    std::unordered_set<uint64> preview_ids;
    if (news_index->GetPreviewIdsByItemId(item.item_id, &preview_ids)) {
      reco::ItemType sub_item_type;
      for (auto iter = preview_ids.begin(); iter != preview_ids.end(); ++iter) {
        if (!news_index->GetItemTypeByItemId(*iter, &sub_item_type)) {
          continue;
        }
        if (sub_item_type == reco::kPureVideo) {
          ++video_count;
        }
      }
    }
  }
  return video_count;
}

// TODO(liufei): 以下三个词表函数，需要整理成配置文件，和运营平台对于频道的管理进行对接。
// 目前还没有想好怎么打通这条链路，后续将其独立出来，暂时还以代码的形式进行维护。
bool RecoUtils::IsSpecialOperChannel(int64 channel_id) {
  if (reco::common::IsAudioChannel(channel_id)) return true;

  static const std::unordered_set<int64> kSpecialOperChannels = {
    reco::common::kOperChannelId,
    reco::common::kEuropeanCupChannelId,
    reco::common::kBusinessChannelId,
    reco::common::kOlympicChannelId,
    reco::common::kIos10PluginCustomerContentChannelId
  };
  return kSpecialOperChannels.find(channel_id) != kSpecialOperChannels.end();
}

bool RecoUtils::IsSpecialBannerChannel(int64 channel_id) {
  if (channel_id == reco::common::kRecoChannelId && FLAGS_set_reco_channel_to_special_banner)
    return true;
  if (IsSpecialOperChannel(channel_id)) return true;
  static const std::unordered_set<int64> kSpecialOperChannels = {
    reco::common::kOperChannelId,
    reco::common::kEuropeanCupChannelId,
    reco::common::kBusinessChannelId,
    reco::common::kFinanceChannelId,
    reco::common::kAutoChannelId,
    reco::common::kScienceChannelId,
    reco::common::kOlympicChannelId,
    reco::common::kEntertainmentChannelId,
    reco::common::kSportChannelId,
    reco::common::kIos10PluginCustomerContentChannelId,
    reco::common::kHotChannelId,
    reco::common::kSocialChannelId,
    reco::common::kHumorPicChannelId,
    reco::common::kMilitaryChannelId,
    reco::common::kHistoryChannelId,
    reco::common::kGanhuoChannelId,
    reco::common::kBoudoirChannelId,
    reco::common::kNBAChannelId,
    reco::common::kInternationalChannelId,
    reco::common::kHumorWordChannelId,
    reco::common::kStockChannelId,
    reco::common::kCBAChannelId,
    reco::common::kAnecdoteChannelId,
    reco::common::kInternetChannelId,
    reco::common::kDigitalChannelId,
    reco::common::kHealthChannelId,
    reco::common::kEstateChannelId,
    reco::common::kHouseHoldChannelId,
    reco::common::kMovieChannelId,
    reco::common::kAnimationChannelId,
    reco::common::kConstellationChannelId,
    reco::common::kTravelChannelId,
    reco::common::kFoodChannelId,
    reco::common::kFitnessChannelId,
    reco::common::kBeautyChannelId,
    reco::common::kFationChannelId,
    reco::common::kGameChannelId,
    reco::common::kWenWanChannelId,
    reco::common::kEducationChannelId,
    reco::common::kStudyAbroadChannelId,
    reco::common::kParentingChannelId,
    reco::common::kChineseFootballChannelId,
    reco::common::kPictureChannelId,
    reco::common::kShoppingId,
    reco::common::kI18nFootballChannelId
  };
  return kSpecialOperChannels.find(channel_id) != kSpecialOperChannels.end();
}

bool RecoUtils::IsStandaloneChannel(int64 channel_id) {
  static const std::unordered_set<int64> kStandaloneChannels = {
    reco::common::kLeftChannelId,
    reco::common::kOperChannelId,
    reco::common::kIos10PluginCustomerContentChannelId,
    reco::common::kDiaryChannelId,
  };
  return kStandaloneChannels.find(channel_id) != kStandaloneChannels.end();
}

reco::common::AppNames RecoUtils::GetAppName(const std::string& app) {
  if (base::LowerCaseEquals(app, "ucnews-iflow")) {
    return reco::common::kUcToutiao;
  } else if (base::LowerCaseEquals(app, "huawei-iflow")) {
    return reco::common::kHuawei;
  } else if (base::LowerCaseEquals(app, "samsung-iflow")) {
    return reco::common::kSamsung;
  } else if (base::LowerCaseEquals(app, "meizunews-iflow")) {
    return reco::common::kMeizu;
  }
  return reco::common::kUcIflow;
}

bool RecoUtils::IsMajorCity(int64 city_id) {
  static const std::unordered_set<int64> kMajorCitySet = {10, 20, 21, 755, 571};
  return (kMajorCitySet.find(city_id) != kMajorCitySet.end());
}

bool RecoUtils::IsPoliticalCity(const std::string& prov, const std::string& city) {
  static const std::unordered_set<std::string> kPoliticalSet
      = {"北京", "天津", "上海", "广州", "杭州", "深圳", "河北"};
  return (kPoliticalSet.find(prov) != kPoliticalSet.end() || kPoliticalSet.find(city) != kPoliticalSet.end());
}

int32 RecoUtils::GetCardAssembleType(const reco::NewsIndex* news_index, uint64 item_id) {
  reco::UcBrowserDeliverSetting ucb_setting;
  if (news_index->GetUCBSettingByItemId(item_id, &ucb_setting)) {
    return ucb_setting.card_assemble_type();
  }
  return 0;
}

bool RecoUtils::IsAutoAssembleCardItem(const reco::NewsIndex* news_index, const ItemInfo& item) {
  if (item.item_id == FLAGS_assemble_card_test_item_id) {
    return true;
  }
  if (item.item_type == reco::kSpecial && GetCardAssembleType(news_index, item.item_id) == 1) {
    return true;
  }
  return false;
}

bool RecoUtils::IsNormalSpecialItem(const reco::NewsIndex* news_index, const ItemInfo& item) {
  return IsNormalSpecialItem(news_index, item.item_type, item.item_id);
}

bool RecoUtils::IsNormalSpecialItem(const reco::NewsIndex* news_index,
                                    ItemType item_type, uint64 item_id) {
  if (item_type == reco::kSpecial && GetCardAssembleType(news_index, item_id) == 0) {
    return true;
  }
  return false;
}

int RecoUtils::RecentRefresh(const reco::user::UserInfo* user_info, int minutes) {
  base::Time end_time = base::Time::Now() - base::TimeDelta::FromMinutes(minutes);
  int64 end_timestamp = end_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int64 last_view_time = 0;
  int refresh_count = 0;
  for (int i = user_info->shown_history_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& show_item = user_info->shown_history(i);
    if (show_item.view_timestamp() < end_timestamp) break;
    if (show_item.view_timestamp() == last_view_time) continue;
    last_view_time = show_item.view_timestamp();
    ++refresh_count;
  }
  return refresh_count;
}

bool RecoUtils::IsAutoEventCardItem(const reco::NewsIndex* news_index, const ItemInfo& item) {
  if (item.item_id == FLAGS_auto_event_card_test_item_id) {
    return true;
  }
  if (item.item_type == reco::kSpecial && GetCardAssembleType(news_index, item.item_id) == 2) {
    return true;
  }
  return false;

}
}  // namespace leafserver
}  // namespace reco
