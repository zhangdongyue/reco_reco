#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>

#include "base/time/time.h"
#include "base/container/dense_hash_set.h"

#include "reco/serv/reco_leaf/strategy/common/reco_strategy_branch.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/user.pb.h"

namespace reco {
namespace leafserver {

class RecoUtils {
 public:
  // 是否大城市
  static bool IsMajorCity(int64 city_id);

  static bool IsPoliticalCity(const std::string& prov, const std::string& city);

  static bool IsSpecialItem(const reco::NewsIndex* news_index,
                            const ItemInfo& item);

  static bool IsChannelDaoliuItem(const reco::NewsIndex* news_index,
                                  const ItemInfo& item);

  static bool IsBigPicStyleItem(const reco::NewsIndex* news_index,
                                const ItemInfo& item);

  static int GetPureVideoNum(const reco::NewsIndex* news_index,
                             const ItemInfo& item);

  static int IsSameDay(const base::Time& left, const base::Time& right);

  // 特殊运营频道，主要以运营新闻为主，运营文章出完再出机器
  static bool IsSpecialOperChannel(int64 channel_id);

  // 特殊 banner 频道，banner 不设限制，运营决定顺序
  static bool IsSpecialBannerChannel(int64 channel_id);

  // 独立频道：频道内容不下发到其他频道
  static bool IsStandaloneChannel(int64 channel_id);

  static reco::common::AppNames GetAppName(const std::string& app);

  // 获取时间的间隔
  static int GetHourSpanNum(const base::Time &time_a, const base::Time &time_b, int span_hours);


  static int RecentRefresh(const reco::user::UserInfo* user_info, int minutes);

  // only_same_channel: 只记录本频道的展现记录
  static void BuildUserShownDict(const reco::NewsIndex* news_index,
                                 const RecommendRequest* request,
                                 const reco::user::UserInfo* user_info,
                                 base::dense_hash_set<uint64>* shown_dict,
                                 const bool filter_wemedia = false,
                                 const bool only_same_channel = false);

  static void AddSimItemToShownDict(const reco::NewsIndex* news_index,
                                    uint64 item_id,
                                    base::dense_hash_set<uint64>* shown_dict);

  static int32 GetCardAssembleType(const reco::NewsIndex* news_index, uint64 item_id);
  // 是否自动组装卡片类型
  static bool IsAutoAssembleCardItem(const reco::NewsIndex* news_index, const ItemInfo& item);
  // 是否是普通的专题卡片
  static bool IsNormalSpecialItem(const reco::NewsIndex* news_index, const ItemInfo& item);
  static bool IsNormalSpecialItem(const reco::NewsIndex* news_index,
                                  ItemType item_type, uint64 item_id);
  static bool IsAutoEventCardItem(const reco::NewsIndex* news_index, const ItemInfo& item);
 private:
  RecoUtils();
  ~RecoUtils();
};
}
}
