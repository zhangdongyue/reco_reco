#pragma once

#include <string>
#include <vector>
#include <cmath>
#include <map>

#include "base/common/basic_types.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/common/wrapped_category.h"


namespace reco {
namespace leafserver {

void AddFeature(const reco::Feature& fea, double weight,
                std::map<std::string, double>* merged_feature);

void AddFeature(const reco::CategoryFeature& category_fea, double weight,
                std::map<std::string, double>* merged_feature);

void AddFeature(const reco::FeatureVector& feature_vector, double weight,
                std::map<std::string, double>* merged_feature);

void AddFeature(const std::map<uint64, double>& fea, double weight,
                std::map<uint64, double>* merged_feature);

template <class T>
void NormalizeFeature(std::map<T, double>* feature);


template <class T>
double CalcNorm2(const std::map<T, double>& feature);

template <class T>
double CalcSim(const std::map<T, double>& user_fea, double user_fea_norm2,
               const std::map<T, double>& item_fea, double item_fea_norm2);
}
}

#include "reco/serv/reco_leaf/strategy/common/feature_api-inl.h"
