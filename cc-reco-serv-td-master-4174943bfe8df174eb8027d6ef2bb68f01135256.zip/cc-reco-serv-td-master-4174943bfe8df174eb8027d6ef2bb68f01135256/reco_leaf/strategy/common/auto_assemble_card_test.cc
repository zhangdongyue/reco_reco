#include "reco/serv/reco_leaf/strategy/common/auto_assemble_card.h"

#include <stdlib.h>

#include <string>

#include "base/testing/gtest.h"

namespace reco {
namespace leafserver {

TEST(AutoAssembleCard, Sort) {
  AutoAssembleCard card;
  EXPECT_FALSE(card.is_valid());
  card.SetCardId(123UL);
  EXPECT_TRUE(card.is_valid());
  EXPECT_EQ(123UL, card.item_id());

  for (int i = 0; i < 40; ++i) {
    unsigned int r = 0;
    rand_r(&r);
    r = r % 4 + 1;
    ItemInfo item;
    item.item_id = (i + 1) * 1000 + r;
    card.AddCandidate(item, (CandidateSourceType)(r));
  }
  EXPECT_EQ(40u, card.candidates().size());
  card.SortCandidates();
  for (size_t i = 0; i < card.candidate_exts_.size(); ++i) {
    const ItemInfo& item = card.candidates()[card.candidate_exts_[i].candidate_idx];
    std::cout << "card-candidate: " << item.item_id << std::endl;
  }
  for (size_t i = 1u; i < card.candidate_exts_.size(); ++i) {
    const ItemInfo& item0 = card.candidates()[card.candidate_exts_[i - 1].candidate_idx];
    const ItemInfo& item1 = card.candidates()[card.candidate_exts_[i].candidate_idx];
    int level0 = item0.item_id % 1000;
    int level1 = item1.item_id % 1000;
    EXPECT_LE(level0, level1);
    if (level0 == level1) {
      EXPECT_LT(item0.item_id / 1000, item1.item_id / 1000);
    }
  }
}

}  // namespace leafserver
}  // namespace reco
