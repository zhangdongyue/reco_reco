#pragma once

#include <string>

namespace reco {
namespace leafserver {

enum RecoStrategyBranch {
  kManualRSB = 0,
  kHotRSB = 1,
  kPersonalRSB = 10,
  kVideoRSB = 20,
  kHumorRSB = 30,
  kLocalRSB = 40,
  kProbeRSB = 50,
  kProbeVideoRSB = 60,
  kThirdPartyRecoRSB = 80,
  kQueryRecoRSB = 90,
  kOtherRSB = 100,
  kUcSidRecoRSB = 110,
};

}  // namespace leafserver
}  // namespace reco
