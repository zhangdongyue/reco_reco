#pragma once

#include <algorithm>
#include <map>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/auto_assemble_card.h"
#include "reco/serv/reco_leaf/strategy/common/auto_event_card.h"

namespace reco {
namespace leafserver {

struct ManualRecoData {
  // 全量一级要闻 与 banner 新闻
  std::vector<ItemInfo> top_importance_items;
  // 全量二级要闻
  std::vector<ItemInfo> snd_importance_items;

  // 类别下的全量运营下发文章
  std::unordered_map<std::string, std::vector<ItemInfo>> category_whole_items;
  // 垂直频道的个性化运营下发文章
  std::vector<ItemInfo> personal_items;
  // 构造 probe 策略运营候选，与上面三种运营文章互斥存在
  std::vector<std::pair<std::string, ItemInfo> > probe_manual_items;

  // probe 策略最后存活的结果
  // std::vector<ItemInfo> probe_alive_items;

  AutoAssembleCard morning_evening_auto_card;
  AutoEventCard auto_event_card;

  void Clear() {
    top_importance_items.clear();
    snd_importance_items.clear();
    category_whole_items.clear();
    personal_items.clear();
    probe_manual_items.clear();
    morning_evening_auto_card.Clear();
    auto_event_card.Clear();
  }
};
}
}
