#include "reco/serv/reco_leaf/strategy/common/topn.h"

#include <stdlib.h>

#include <string>

#include "base/testing/gtest.h"

TEST(TopN, get_top_n) {
  TopN<int> st(10);
  for (int i = 0; i < 100; ++i) {
    int kav = rand() % 10000;
    st.add(kav, kav);
  }
  std::vector<int> v;
  st.get_top_n(&v);
  EXPECT_EQ(10u, v.size());
  for (size_t i = 1; i < v.size(); ++i) {
    EXPECT_GE(v[i - 1], v[i]);
  }
}
