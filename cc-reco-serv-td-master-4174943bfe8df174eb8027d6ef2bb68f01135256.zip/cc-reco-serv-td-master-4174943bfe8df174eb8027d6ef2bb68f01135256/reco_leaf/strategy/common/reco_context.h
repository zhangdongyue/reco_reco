
#pragma once

#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"

namespace reco {
namespace leafserver {

class CostTrace;

class RecoContext {
 public:
  explicit RecoContext(CostTrace* cost_trace,
                       RecoDebugger* debugger) {
    cost_trace_ = cost_trace;
    debugger_ = debugger;
  }
  ~RecoContext() {}

  CostTrace* cost_trace() const {
    return cost_trace_;
  }

  RecoDebugger* debugger() const {
    return debugger_;
  }

 private:
  CostTrace* cost_trace_;
  RecoDebugger* debugger_;
};


}  // namespace leafserver
}  // namespace reco
