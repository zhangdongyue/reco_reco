#include "reco/serv/reco_leaf/strategy/common/auto_event_card.h"

#include "base/testing/gtest.h"

namespace reco {
namespace leafserver {


}  // namespace leafserver
}  // namespace reco
