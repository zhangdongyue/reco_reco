#pragma once

#include <cmath>
#include <map>
#include <string>

#include "base/common/basic_types.h"
#include "reco/bizc/common/wrapped_category.h"

namespace reco {
namespace leafserver {

inline void AddFeature(const reco::Feature& fea, double weight,
                std::map<std::string, double>* merged_feature) {
  auto it = merged_feature->find(fea.literal());
  if (it == merged_feature->end()) {
    it = merged_feature->insert(std::make_pair(fea.literal(), fea.weight())).first;
    it->second = fea.weight() * weight;
  } else {
    double orig_weight = it->second;
    it->second = fea.weight() * weight + orig_weight;
  }
}

inline void AddFeature(const reco::CategoryFeature& category_fea, double weight,
                std::map<std::string, double>* merged_feature) {
  std::string fea_key = reco::common::WrappedCategory(category_fea.literal()).ToString();
  auto it = merged_feature->find(fea_key);
  if (it == merged_feature->end()) {
    it = merged_feature->insert(std::make_pair(fea_key, category_fea.weight())).first;
    it->second = category_fea.weight() * weight;
  } else {
    double orig_weight = it->second;
    it->second = category_fea.weight() * weight + orig_weight;
  }
}

inline void AddFeature(const reco::FeatureVector& feature_vector, double weight,
                std::map<std::string, double>* merged_feature) {
  for (int i = 0; i < feature_vector.feature_size(); ++i) {
    const reco::Feature& fea = feature_vector.feature().Get(i);
    AddFeature(fea, weight, merged_feature);
  }
}

inline void AddFeature(const std::map<uint64, double>& fea, double weight,
                std::map<uint64, double>* merged_feature) {
  for (auto jt = fea.begin(); jt != fea.end(); ++jt) {
    auto it = merged_feature->find(jt->first);
    if (it == merged_feature->end()) {
      it = merged_feature->insert(std::make_pair(jt->first, jt->second)).first;
      it->second = jt->second * weight;
    } else {
      double orig_weight = it->second;
      it->second = jt->second * weight + orig_weight;
    }
  }
}

template <class T>
inline void NormalizeFeature(std::map<T, double>* feature) {
  if (feature->empty()) return;
  double sum_weight = 0;
  for (auto it = feature->begin(); it != feature->end(); ++it) {
    sum_weight += it->second;
  }
  if (sum_weight < 1e-9) return;
  for (auto it = feature->begin(); it != feature->end(); ++it) {
    it->second = it->second/sum_weight;
  }
}

template <class T>
inline double CalcNorm2(const std::map<T, double>& feature) {
  double norm = 0;
  for (auto it = feature.begin(); it != feature.end(); ++it) {
    norm += it->second * it->second;
  }
  return sqrt(norm);
}

template <class T>
inline double CalcSim(const std::map<T, double>& user_fea, double user_fea_norm2,
               const std::map<T, double>& item_fea, double item_fea_norm2) {
  if (user_fea_norm2 < 1e-7 || item_fea_norm2 < 1e-7) return 0;
  auto it_user = user_fea.begin();
  auto it_item = item_fea.begin();

  double hit_weight = 0;
  while (it_user != user_fea.end() && it_item != item_fea.end()) {
    if (it_item->first < it_user->first) {
      it_item++;
    } else if (it_item->first > it_user->first) {
      it_user++;
    } else {
      hit_weight += it_user->second * it_item->second;  // add weight to each feature
      it_user++;
      it_item++;
    }
  }
  return hit_weight/user_fea_norm2/item_fea_norm2;
}
}
}
