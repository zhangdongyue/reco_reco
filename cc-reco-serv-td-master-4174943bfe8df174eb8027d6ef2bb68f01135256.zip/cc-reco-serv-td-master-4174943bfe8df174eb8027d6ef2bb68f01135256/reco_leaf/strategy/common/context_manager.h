#pragma once
#include <string>
#include "serving_base/expiry_map/expiry_map.h"

namespace reco {
namespace leafserver {
class ContextManager {
 public:
  ContextManager();
  ~ContextManager();

 public:
  /////////// 在不同场景下（时间、人群）各种参数配置是不一样的 这个类对外提供统一的接口 ///////////
  static double GetConfig(const std::string& key);

  // 如果需要有 request 上下文，可以再加接口
  // static double GetConfig(const reco::RecoRequest& reco_request, const std::string& key);

 private:
  static bool GetConfigFromCache(const std::string& key, double* value);
  static void SetConfigToCache(const std::string& key, const double value);

  // 短视频调权的参数
  static double ShortVideoScoreBoost();

 private:
  // double 类型配置的缓存
  static serving_base::ExpiryMap<std::string, double>* double_config_cache_;
};
}
}
