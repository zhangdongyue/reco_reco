#include <fstream>
#include <iostream>
#include <string>
#include "base/testing/gtest.h"
#include "reco/serv/reco_leaf/strategy/common/profile_type.h"
#include "base/file/scoped_temp_dir.h"
#include "base/time/time.h"
#include "base/common/sleep.h"
#include "base/random/pseudo_random.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;
using reco::user::Profile;

class ProfileTypeTest : public ::testing::Test {
 public:
  virtual void SetUp() {
    std::vector<std::string> flds;
    // profile
    Profile profile;
    auto cate = profile.mutable_category_feavec()->add_feature();
    flds.clear();
    flds.push_back("体育");
    ProfileTypeDetect::ConvertToCategoryProto(flds, flds.size() - 1, cate->mutable_literal());
    cate->set_weight(40);
    LOG(ERROR) << cate->literal().category();

    cate = profile.mutable_category_feavec()->add_feature();
    flds.clear();
    flds.push_back("体育");
    flds.push_back("nba");
    ProfileTypeDetect::ConvertToCategoryProto(flds, flds.size() - 1, cate->mutable_literal());
    cate->set_weight(10);

    cate = profile.mutable_category_feavec()->add_feature();
    flds.clear();
    flds.push_back("社会");
    ProfileTypeDetect::ConvertToCategoryProto(flds, flds.size() - 1, cate->mutable_literal());
    cate->set_weight(15);

    cate = profile.mutable_category_feavec()->add_feature();
    flds.clear();
    flds.push_back("国内");
    ProfileTypeDetect::ConvertToCategoryProto(flds, flds.size() - 1, cate->mutable_literal());
    cate->set_weight(10);

    cate = profile.mutable_category_feavec()->add_feature();
    flds.clear();
    flds.push_back("财经");
    ProfileTypeDetect::ConvertToCategoryProto(flds, flds.size() - 1, cate->mutable_literal());
    cate->set_weight(35);

    user_info.mutable_profile()->CopyFrom(profile);

    // DMP profile
    reco::user::DmpProfile dmp_profile;
    dmp_profile.set_confidence(0.99);
    cate = dmp_profile.mutable_category_feavec()->add_feature();
    flds.clear();
    flds.push_back("体育");
    ProfileTypeDetect::ConvertToCategoryProto(flds, flds.size() - 1, cate->mutable_literal());
    cate->set_weight(0.4);

    cate = dmp_profile.mutable_category_feavec()->add_feature();
    flds.clear();
    flds.push_back("社会");
    ProfileTypeDetect::ConvertToCategoryProto(flds, flds.size() - 1, cate->mutable_literal());
    cate->set_weight(0.15);

    cate = dmp_profile.mutable_category_feavec()->add_feature();
    flds.clear();
    flds.push_back("国内");
    ProfileTypeDetect::ConvertToCategoryProto(flds, flds.size() - 1, cate->mutable_literal());
    cate->set_weight(0.05);

    cate = dmp_profile.mutable_category_feavec()->add_feature();
    flds.clear();
    flds.push_back("游戏");
    ProfileTypeDetect::ConvertToCategoryProto(flds, flds.size() - 1, cate->mutable_literal());
    cate->set_weight(0.4);

    user_info.mutable_dmp_profile()->CopyFrom(dmp_profile);
  }

  virtual void TearDown() {}
  UserInfo user_info;
};

TEST_F(ProfileTypeTest, init) {
  ProfileTypeDetect type(user_info);
  ASSERT_EQ(type.profile_confidence_, 1);
  ASSERT_EQ(type.dmp_profile_confidence_, 2);
  ASSERT_EQ(type.profile_category_.size(), 4u);
  ASSERT_EQ(type.dmp_profile_category_.size(), 4u);
}

TEST_F(ProfileTypeTest, detect) {
  struct {
    const char* category;
    const char* sub_category;
    reco::ProfileType profile_type;
    reco::DmpProfileType dmp_profile_type;
  } cases[] = {
    {"体育", "", reco::kMidProfileHighMatch, reco::kHighDmpProfileHighMatch},
    {"体育", "nba", reco::kMidProfileHighMatch, reco::kHighDmpProfileHighMatch},
    {"社会", "", reco::kMidProfileMidMatch, reco::kHighDmpProfileMidMatch},
    {"国内", "", reco::kMidProfileLowMatch, reco::kHighDmpProfileLowMatch},
    {"财经", "", reco::kMidProfileHighMatch, reco::kHighDmpProfileLowMatch},
    {"游戏", "", reco::kMidProfileLowMatch, reco::kHighDmpProfileHighMatch},
  };
  ProfileTypeDetect type(user_info);
  for (int32 i = 0; i < (int32)ARRAYSIZE_UNSAFE(cases); ++i) {
    reco::ProfileType profile_type;
    reco::DmpProfileType dmp_profile_type;
    type.DetectProfileType(cases[i].category,
                           cases[i].sub_category,
                           &profile_type,
                           &dmp_profile_type);
    ASSERT_EQ(cases[i].profile_type, profile_type) << i;
    // ASSERT_EQ(cases[i].dmp_profile_type, dmp_profile_type);
  }
}

}  // namespace leafserver
}  // namespace reco
