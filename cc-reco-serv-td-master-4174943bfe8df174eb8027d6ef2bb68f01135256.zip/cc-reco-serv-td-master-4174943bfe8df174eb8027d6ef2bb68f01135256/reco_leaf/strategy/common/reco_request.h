#pragma once

#include <string>
#include <cstring>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/base/common/topn_heap.h"

#include "base/time/time.h"
#include "base/container/dense_hash_set.h"

namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {

DECLARE_int32(debug_loyal_user);
DECLARE_bool(check_loyal_user);

struct ItemDictData;
typedef std::vector<std::pair<float, reco::Category>> UserCategoryDistributes;

struct UserParamInfo {
  std::string app_token;
  std::string province;
  std::string city;
  bool is_ios;
  bool is_android;
  bool wsg_enc;   // 是否无线保镖加密
  bool is_unknow_city;
  bool is_main_city;
  bool is_new_user;
  bool is_wifi;
  bool do_dirty_filter;
  bool do_bluffing_filter;
  RuleChain rule_chain;
  bool is_uc_iflow_qudao;
  bool is_inner_qudao;
  bool is_loyal;
  void Reset() {
    app_token.clear();
    province.clear();
    city.clear();
    is_ios = false;
    is_android = false;
    wsg_enc = false;
    is_unknow_city = false;
    is_main_city = false;
    is_new_user = false;
    is_wifi = false;
    do_dirty_filter = false;
    do_bluffing_filter = false;
    rule_chain.reset();
    is_uc_iflow_qudao = false;
    is_inner_qudao = false;
    is_loyal = false;
  }
  void Print() {
    // LOG(INFO) << "user param info, ios:" << is_ios
    VLOG(1)   << "user param info, ios:" << is_ios
              << ", android:" << is_android
              << ", main_city:" << is_main_city
              << ", province:" << province
              << ", city:" << city
              << ", app:" << app_token
              << ", bitmap: " << rule_chain.to_string();
  }
};

// news reco 通用 request 封装
//
struct RecoRequest {
  inline bool Reset(const RecommendRequest* request,
                    const reco::user::UserInfo* user_info,
                    const UserFeature* user_feas,
                    const base::dense_hash_set<uint64>* shown_dict,
                    const UserCategoryDistributes* distributes);

  const RecommendRequest* request;
  const reco::user::UserInfo* user_info;
  const UserFeature* user_feas;
  const base::dense_hash_set<uint64>* shown_dict;
  const UserCategoryDistributes* category_distributes;
  const std::vector<std::pair<std::string, ItemInfo> >* probe_manual_items;
  std::unordered_set<std::string> prefer_categories;

  bool  is_update_req;
  bool  is_today_req;
  base::Time req_news_date;
  base::Time current_time;
  int64 current_timestamp;
  int64 start_news_timestamp;
  int64 end_news_timestamp;
  int64 channel_id;

  const std::unordered_map<uint64, ItemDictData>* personal_item_dicts;
  UserParamInfo user_param_info;

  // 今天的访问次数
  int today_access_cnt;
  // 过去 1,5,15 分钟的访问次数
  int access_frequency[3];

  int refresh_type;
  bool reviewed_filter_hit;

  // 非视频频道是否可下发视频
  bool can_deliver_video;

  bool is_high_quality_user;

  RecoRequest() : request(NULL), user_info(NULL), user_feas(NULL), shown_dict(NULL),
    category_distributes(NULL), is_update_req(false), is_today_req(false),
    current_timestamp(0), start_news_timestamp(0), end_news_timestamp(0),
    channel_id(0), today_access_cnt(0), access_frequency({0, 0, 0}),
    refresh_type(0), reviewed_filter_hit(false), can_deliver_video(false), is_high_quality_user(false) {}
};

bool RecoRequest::Reset(const RecommendRequest* p_request,
                        const reco::user::UserInfo* p_user_info,
                        const UserFeature* p_user_feas,
                        const base::dense_hash_set<uint64>* p_shown_dict,
                        const UserCategoryDistributes* distributes) {
  request = p_request;
  user_info = p_user_info;
  user_feas = p_user_feas;
  shown_dict = p_shown_dict;
  category_distributes = distributes;
  prefer_categories.clear();
  // 用户感兴趣的类别 top 3
  TopNHeap<std::string> category_topn(3);
  const auto& ref_l1_cates = user_feas->merged_fea.l1_cates;
  for (auto iter = ref_l1_cates.begin(); iter != ref_l1_cates.end(); ++iter) {
    category_topn.add(iter->first, iter->second);
  }
  std::vector<std::pair<std::string, double> > category_vec;
  category_topn.get_top_n_unordered(&category_vec);
  for (auto i = 0u; i < category_vec.size(); ++i) {
    // 占比和量都必须满足
    if (category_vec[i].second < 0.2) continue;
    if (category_vec[i].second * user_feas->merged_info.total_click_num < 10) continue;
    prefer_categories.insert(category_vec[i].first);
  }

  current_time = base::Time::Now();
  current_timestamp = current_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  is_update_req = false;
  is_today_req = false;
  start_news_timestamp = -1;
  end_news_timestamp = -1;

  refresh_type = request->refresh_type();

  if (!request->has_news_date()) {
    is_update_req = true;
    is_today_req = true;
  } else {
    if (!base::Time::FromStringInFormat(request->news_date().c_str(), "%Y-%m-%d", &req_news_date)) {
      // NOTE（jianhuang) 传送的 news_date 格式错误的话，直接当作当天的刷新请求
      LOG(ERROR) << "invalid request, news_date format error, " << request->Utf8DebugString();
      is_update_req = true;
      is_today_req = true;
    } else {
      if (req_news_date <= current_time
          && current_time <= req_news_date + base::TimeDelta::FromDays(1)) {
        is_today_req = true;
      }
      start_news_timestamp = req_news_date.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
      base::Time end_time = req_news_date + base::TimeDelta::FromDays(1);
      if (end_time > current_time) {
        end_time = current_time;
      }
      end_news_timestamp = end_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
    }
  }

  channel_id = (request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId);

  user_param_info.Reset();
  user_param_info.app_token = request->app_token();
  user_param_info.is_new_user = (request->has_is_new_user() ? request->is_new_user() : false);
  if (request->has_uc_user_param()) {
    const UcBrowserUserParam& user_param = request->uc_user_param();
    user_param_info.is_ios = (user_param.has_fr()
                              && (base::LowerCaseEquals(user_param.fr(), "ios")
                                  || base::LowerCaseEquals(user_param.fr(), "iphone")
                                  || base::LowerCaseEquals(user_param.fr(), "ipad")));

    user_param_info.is_android = (user_param.has_fr()
                                  && base::LowerCaseEquals(user_param.fr(), "android"));

    user_param_info.wsg_enc = user_param.has_wsg_enc() && user_param.wsg_enc();

    if (user_param.has_province()) {
      user_param_info.province = user_param.province();
    }
    if (user_param.has_city()) {
      user_param_info.city = user_param.city();
    } else {
      user_param_info.is_unknow_city = true;
    }
    if (user_param.has_nt()) {
      user_param_info.is_wifi = (user_param.nt() == "2");
    } else {
      user_param_info.is_wifi = true;
    }

    // 是否是忠实用户
    if (FLAGS_check_loyal_user && user_info
        && user_info->has_profile() && user_info->profile().has_is_loyal_user()) {
      user_param_info.is_loyal = user_info->profile().is_loyal_user();
    }

    // TODO(KouYan): Test
    if (FLAGS_debug_loyal_user == 1)
      user_param_info.is_loyal = true;
    else if (FLAGS_debug_loyal_user == 2)
      user_param_info.is_loyal = false;

    // user_param_info.is_main_city
    //    = reco::common::RegionDict::IsMainCityByName(user_param_info.province, user_param_info.city);
    auto main_city_dict = LeafDataManager::GetGlobalData()->common_filter->main_city_dict->GetDict();
    if (main_city_dict) {
      if (main_city_dict->find(user_param_info.province) != main_city_dict->end()
          || main_city_dict->find(user_param_info.city) != main_city_dict->end()) {
        user_param_info.is_main_city = true;
      }
    }

    FilterRule::SetUserChain(user_param_info.is_ios, user_param_info.is_android,
                             user_param_info.is_main_city, request->app_token(),
                             &user_param_info.rule_chain);
  }

  user_param_info.do_dirty_filter = (user_param_info.is_main_city
                                     || user_param_info.is_new_user
                                     || user_feas->attr.dirty_level == kDirtyVeryLow
                                     || user_feas->attr.dirty_level == kDirtyLow);

  user_param_info.do_bluffing_filter = (user_param_info.is_main_city
                                        || user_param_info.is_new_user
                                        || user_feas->attr.bluffing_level == kBluffingVeryLow
                                        || user_feas->attr.bluffing_level == kBluffingLow);

  user_param_info.is_uc_iflow_qudao= reco::common::kUCBIflowUser == request->app_token();
  static std::set<std::string> kInnerQudao = { 
    reco::common::kUCBIflowUser,
    reco::common::kUCAppUser,
    reco::common::kTuDouAppUser,
    reco::common::kTuDouPCAppUser,
    reco::common::kYouKuAppUser,
    reco::common::kWebAppUser,
    reco::common::kUCVideoAppUser,
    reco::common::kYunOSAppUser,
    reco::common::kUCLiteAppUser,
    reco::common::kSsrdAnAppUser,
    reco::common::kUCMiniAppUser,
    reco::common::kYunOsBrwAppUser,
    reco::common::kOppoIflowAppUser,
  };

  user_param_info.is_inner_qudao = (kInnerQudao.find(request->app_token()) != kInnerQudao.end());
  user_param_info.Print();

  today_access_cnt = 0;
  std::memset(access_frequency, 0, sizeof(access_frequency));

  // reviewed filter
  reviewed_filter_hit = false;
  auto reviewed_city_dict = LeafDataManager::GetGlobalData()->common_filter->reviewed_filter_city->GetDict();
  if (!reviewed_city_dict->empty()) {
    if (user_param_info.city.empty()
        || reviewed_city_dict->find(user_param_info.province) != reviewed_city_dict->end()
        || reviewed_city_dict->find(user_param_info.city) != reviewed_city_dict->end()) {
      reviewed_filter_hit = true;
    }
  }

  can_deliver_video = false;

  is_high_quality_user = false;
  for (int idx = 0; idx < user_info->user_group_info().user_groups_size(); ++idx) {
    const std::string& group_name = user_info->user_group_info().user_groups(idx).group_name();
    // “高端人群”这个标示被治民之前的实验占住了，so
    if (group_name == "通用高端人群") {
      is_high_quality_user = true;
      break;
    }
  }
  if (is_high_quality_user) LOG(INFO) << "is_high_quality_user : "
                                      << user_info->identity().user_id();

  return true;
}
}
}

