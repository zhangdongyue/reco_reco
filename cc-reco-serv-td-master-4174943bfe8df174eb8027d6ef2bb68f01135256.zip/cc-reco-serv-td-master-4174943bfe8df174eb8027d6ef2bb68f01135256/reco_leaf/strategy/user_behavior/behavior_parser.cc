#include "reco/serv/reco_leaf/strategy/user_behavior/behavior_parser.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace leafserver {

BehaviorParser::BehaviorParser() {
}

BehaviorParser::~BehaviorParser() {
}

void BehaviorParser::Reset() {
  now_time_ = base::Time::Now();
  now_timestamp_ = base::GetTimestamp();
  midnight_time_ = now_time_.LocalMidnight();
  earliest_timestamp_ = now_time_.ToDoubleT() * base::Time::kMicrosecondsPerSecond
      - base::Time::kMicrosecondsPerDay * kEarliestDays;

  ts_item_stat_.clear();
  category_stat_.clear();
  sub_category_stat_.clear();
  tag_stat_.clear();

  stat_pool_.clear();
  stat_pool_.reserve(kBehaviorPoolMaxSize);
}

void BehaviorParser::Parse(const reco::user::UserInfo* user_info, reco::NewsIndex* news_index) {
  static const int64 kSessionGapMicroseconds = base::Time::kMicrosecondsPerMinute * kSessionGapMinutes;

  if (!user_info) return;

  std::set<uint64> click_set;
  for (int i = 0; i < user_info->recent_click_size() && i < kMaxTraverse; ++i) {
    click_set.insert(user_info->recent_click(i).item_id());
  }

  for (int i = 0; i < user_info->shown_history_size() && i < kMaxTraverse; ++i) {
    const reco::user::ViewClickItem& item = user_info->shown_history(i);
    if (item.has_scene_type() && item.scene_type() != 0) continue;
    if (!item.has_view_timestamp() || item.view_timestamp() < earliest_timestamp_) {
      continue;
    }
    base::Time item_time =
        base::Time::FromDoubleT(item.view_timestamp() / base::Time::kMicrosecondsPerSecond);

    // 设置一些基础的信息
    auto it = ts_item_stat_.insert(std::make_pair(item.view_timestamp(), ItemStat()));
    ItemStat& item_stat = it->second;
    item_stat.item_id = item.item_id();
    base::TimeDelta delta = now_time_ - item_time;
    item_stat.minute_delta = delta.InMinutes();
    item_stat.day_delta = delta.InDays();
    item_stat.is_today = (item_time > midnight_time_);
    item_stat.is_clicked = click_set.find(item.item_id()) != click_set.end();
  }

  int refresh_idx = 0;
  int session_idx = 0;
  // 从最大时间戳开始
  int64 last_ts = now_timestamp_;
  // 找到各种统计区间的时间窗口 [begin, end]
  std::map<TimeWindow, std::pair<int64, int64> > boundaries;
  boundaries[kCurrentSession] = std::make_pair(kInt64Max, 0);
  boundaries[kLastSession] = std::make_pair(kInt64Max, 0);
  boundaries[kToday] = std::make_pair(kInt64Max, 0);
  boundaries[kLastThreeDays] = std::make_pair(kInt64Max, 0);
  boundaries[kTotal] = std::make_pair(kInt64Max, 0);

  std::map<TimeWindow, std::pair<int, std::set<int64> > > show_refresh_cnts;
  show_refresh_cnts[kCurrentSession] = std::make_pair(0, std::set<int64>());
  show_refresh_cnts[kLastSession] = std::make_pair(0, std::set<int64>());
  show_refresh_cnts[kToday] = std::make_pair(0, std::set<int64>());
  show_refresh_cnts[kLastThreeDays] = std::make_pair(0, std::set<int64>());
  show_refresh_cnts[kTotal] = std::make_pair(0, std::set<int64>());
  // ts_item_stat 是大到小
  for (auto it = ts_item_stat_.begin(); it != ts_item_stat_.end(); ++it) {
    const int64& ts = it->first;
    ItemStat& stat = it->second;

    if (ts != last_ts) {
      if (last_ts - ts > kSessionGapMicroseconds) {
        ++session_idx; // session 从 0 开始， 为 0 表示当前 session 没有中断
      }
      ++refresh_idx;  // refresh 从 1 开始
    }
    stat.refresh_idx = refresh_idx;
    stat.session_idx = session_idx;

    if (session_idx == 0) {
      boundaries[kCurrentSession].first = std::min(boundaries[kCurrentSession].first, ts);
      boundaries[kCurrentSession].second = std::max(boundaries[kCurrentSession].second, ts);
      show_refresh_cnts[kCurrentSession].first++;
      show_refresh_cnts[kCurrentSession].second.insert(ts);
    }

    if (session_idx == 1) {
      boundaries[kLastSession].first = std::min(boundaries[kLastSession].first, ts);
      boundaries[kLastSession].second = std::max(boundaries[kLastSession].second, ts);
      show_refresh_cnts[kLastSession].first++;
      show_refresh_cnts[kLastSession].second.insert(ts);
    }

    if (stat.is_today) {
      boundaries[kToday].first = std::min(boundaries[kToday].first, ts);
      boundaries[kToday].second = std::max(boundaries[kToday].second, ts);
      show_refresh_cnts[kToday].first++;
      show_refresh_cnts[kToday].second.insert(ts);
    }

    if (stat.day_delta < 3) {
      boundaries[kLastThreeDays].first = std::min(boundaries[kLastThreeDays].first, ts);
      boundaries[kLastThreeDays].second = std::max(boundaries[kLastThreeDays].second, ts);
      show_refresh_cnts[kLastThreeDays].first++;
      show_refresh_cnts[kLastThreeDays].second.insert(ts);
    }

    boundaries[kTotal].first = std::min(boundaries[kTotal].first, ts);
    boundaries[kTotal].second = std::max(boundaries[kTotal].second, ts);
    show_refresh_cnts[kTotal].first++;
    show_refresh_cnts[kTotal].second.insert(ts);

    last_ts = ts;
  }

  std::vector<std::string> categories;
  std::vector<std::string> core_tags;
  for (auto it_item = ts_item_stat_.begin(); it_item != ts_item_stat_.end(); ++it_item) {
    const ItemStat& stat = it_item->second;
    const int64& ts = it_item->first;
    const uint64& item_id = stat.item_id;
    categories.clear();
    if (!news_index->GetCategoriesByItemId(item_id, &categories)
        || categories.empty() || categories[0] == "未分类") {
      VLOG(1) << item_id << " has empty category";
      continue;
    }

    core_tags.clear();
    if (!news_index->GetTitleCoreTagsByItemId(item_id, &core_tags) || core_tags.empty()) {
      VLOG(1) << "can't find core tag for item: " << item_id;
    }

    for (auto it_boundary = boundaries.begin(); it_boundary != boundaries.end(); ++it_boundary) {
      TimeWindow window = it_boundary->first;
      const std::pair<int64, int64>& boundary = it_boundary->second;
      if (ts < boundary.first || ts > boundary.second) {
        continue;
      }
      
      CollectItem(categories[0], window, &stat, &category_stat_);
      if (categories.size() > 1u) {
        CollectItem(categories[1], window, &stat, &sub_category_stat_);
      }
      for (size_t i = 0; i < core_tags.size(); ++i) {
        CollectItem(core_tags[i], window, &stat, &tag_stat_);
      }
    }
  }

  CalcStatistics(show_refresh_cnts, &category_stat_);
  CalcStatistics(show_refresh_cnts, &sub_category_stat_);
  CalcStatistics(show_refresh_cnts, &tag_stat_);
}

void BehaviorParser::CollectItem(const std::string& text, TimeWindow window, const ItemStat* item_stat,
           std::map<std::string, std::map<TimeWindow, BehaviorStatistics*> >* behavivor_stat) {
  auto it = behavivor_stat->find(text);
  if (it == behavivor_stat->end()) {
    it = behavivor_stat->insert(
        std::make_pair(text, std::map<TimeWindow, BehaviorStatistics*>())).first;
  }
  std::map<TimeWindow, BehaviorStatistics*>& window_statistics = it->second;
  auto jt = window_statistics.find(window);
  if (jt == window_statistics.end()) {
    // pool 已经用光了，不再分配
    if (int(stat_pool_.size()) >= kBehaviorPoolMaxSize) return;
    stat_pool_.push_back(BehaviorStatistics());
    jt = it->second.insert(std::make_pair(window, &(stat_pool_.back()))).first;
  }
  jt->second->CollectItem(item_stat);
}

void BehaviorParser::CalcStatistics(const std::map<TimeWindow, std::pair<int, std::set<int64> > >& show_refresh_cnts,  // NOLINT
                                    std::map<std::string, std::map<TimeWindow, BehaviorStatistics*> >* behavior_stat) {  // NOLINT
  for (auto it = behavior_stat->begin(); it != behavior_stat->end(); ++it) {
    std::map<TimeWindow, BehaviorStatistics*>& window_behavior = it->second;
    for (auto jt = window_behavior.begin(); jt != window_behavior.end(); ++jt) {
      TimeWindow window = jt->first;
      BehaviorStatistics* behavior = jt->second;
      if (behavior != NULL) {
        auto kt = show_refresh_cnts.find(window);
        if (kt != show_refresh_cnts.end()) {
          behavior->CalcStatistics(kt->second.first, kt->second.second.size());
        }
      }
    }
  }
}
} // namespace leaf
} // namespace reco
