#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "base/common/basic_types.h"
#include "base/testing/gtest_prod.h"

namespace reco {
namespace leafserver {

// 时间窗的定义
enum TimeWindow {
  // [0, kSessionGapMinutes] 10分钟内
  kCurrentSession = 0,
  // 上一个 session
  kLastSession = 1,
  // 今天之内 0点到现在
  kToday = 2,
  // 三天之内
  kLastThreeDays = 3,
  // 所有数据
  kTotal = 255,
};

// 分析展现点击日志得到的相关 item 的信息
struct ItemStat {
  uint64 item_id;
  // 刷新间隔从 1 开始， 上一刷间隔就是 1
  int refresh_idx;
  // session 序号, 从 0 开始， 为 0 表示当前 session 没有中断
  int session_idx;
  // 展现分钟间隔
  int minute_delta;
  // 展现天级间隔
  int day_delta;
  // 是否是今天
  bool is_today;
  // 是否点击
  bool is_clicked;

  ItemStat() {
    item_id = 0;
    refresh_idx = 0;
    session_idx = 0;
    minute_delta = 0;
    day_delta = 0;
    is_today = false;
    is_clicked = false;
  }
};

// 给定统计的时间区间，我们计算出每个区间内的指标
class BehaviorStatistics {
 public:
  BehaviorStatistics();
  ~BehaviorStatistics();

  void reset() {
    total_show_num_ = 0;
    total_refresh_num_ = 0;

    show_num_ = 0;
    refresh_num_ = 0;
    click_num_ = 0;

    min_refresh_interval_ = kInt32Max;
    min_minute_interval_ = kInt32Max;
    recent_continuous_show_num_ = 0;
    recent_continuous_refresh_num_ = 0;

    show_since_last_click_ = 0;

    item_stats_.clear();
    refresh_show_num_.clear();
  }

  // is_concerned: 为 false 是做分母的
  // 这个区间内的所有 item 都要通过此接口提交
  void CollectItem(const ItemStat* stat) {
    item_stats_.push_back(stat);
    refresh_show_num_[stat->refresh_idx]++;
  }

  void CalcStatistics(int total_show, int total_refresh);

  std::string ToString() const;
  // 各种 getter 函数

  // 当前区间内，展现填充率. 即该维度展现 / 区间总展现
  float show_fill_ratio() const {
    return safe_div(show_num_, total_show_num_);
  }

  // 当前区间内，刷新填充率. 即该维度刷新 / 区间总刷新
  float refresh_fill_ratio() const {
    return safe_div(refresh_num_, total_refresh_num_);
  }

  float ctr() const {
    return safe_div(click_num_, show_num_);
  }

  // 当前区间内，最近一次展现该维度 item 的刷新间隔， 最小为 1 即上一刷
  int min_refresh_interval() const {
    return min_refresh_interval_;
  }

  // 当前区间内，最近一次展现该维度 item 的分钟间隔， 最小为 0
  int min_minute_interval() const {
    return min_minute_interval_;
  }

  // 当前区间内，距离现在最近的一次连续展现的展现条数
  // 连续展现指在连续刷中出现的次数
  int recent_continuous_show_num() const {
    return recent_continuous_show_num_;
  }

  // 当前区间内，距离现在最近的一次连续刷新的刷新数
  int recent_continuous_refresh_num() const {
    return recent_continuous_refresh_num_;
  }

  // 当前区间内，距离最近一次点击后，又展现了多少条
  int show_since_last_click() const {
    return show_since_last_click_;
  }
 private:
  FRIEND_TEST(BehaviorStatisticsTest, stat);

  float safe_div(float numerator, float dominator) const {
    return dominator < 1e-6 ? 0 : numerator / dominator;
  }
  int total_show_num_;  // 区间内总 item 展现
  int total_refresh_num_;  // 区间内总刷新数

  int show_num_;  // 展现次数
  int refresh_num_; // 刷新次数
  int click_num_; // 点击次数

  // 上次投放刷新间隔 从 1 开始， 上一刷间隔就是 1
  int min_refresh_interval_;
  // 上次投放分钟间隔
  int min_minute_interval_;
  // 从上次投放刷新开始，连续展现量
  // 只要连续刷出现，不需要位次上挨着，就认为是连续展现，
  // 而且累加本刷内的展现条数
  int recent_continuous_show_num_;
  int recent_continuous_refresh_num_;

  // 距离最近一次点击又展现了多少次
  int show_since_last_click_;

  std::vector<const ItemStat*> item_stats_;
  // refresh idx -> show num in this refresh
  std::map<int, int> refresh_show_num_;
};
} // namespace leaf
} // namespace reco

