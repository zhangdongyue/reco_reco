#include "reco/serv/reco_leaf/strategy/user_behavior/behavior_stat.h"

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace leafserver {

BehaviorStatistics::BehaviorStatistics() {
  reset();
}

BehaviorStatistics::~BehaviorStatistics() {
}

std::string BehaviorStatistics::ToString() const {
return base::StringPrintf("total_show_num=%d,"
                          "total_refresh_num=%d,"
                          "show_num=%d,"
                          "refresh_num=%d,"
                          "click_num=%d,"
                          "min_refresh_interval=%d,"
                          "min_minute_interval=%d,"
                          "recent_continuous_show_num=%d,"
                          "recent_continuous_refresh_num=%d,"
                          "show_since_last_click=%d",
                          total_show_num_,
                          total_refresh_num_,
                          show_num_,
                          refresh_num_,
                          click_num_,
                          min_refresh_interval_,
                          min_minute_interval_,
                          recent_continuous_show_num_,
                          recent_continuous_refresh_num_,
                          show_since_last_click_);
}

void BehaviorStatistics::CalcStatistics(int total_show, int total_refresh) {
  total_refresh_num_ = total_refresh;
  total_show_num_ = total_show;

  refresh_num_ = refresh_show_num_.size();
  show_num_ = item_stats_.size();

  click_num_ = 0;
  int min_click_refresh = kInt32Max;
  for (size_t i = 0; i < item_stats_.size(); ++i) {
    const ItemStat& stat = *(item_stats_[i]);
    min_refresh_interval_ = std::min(min_refresh_interval_, stat.refresh_idx);
    min_minute_interval_ = std::min(min_minute_interval_, stat.minute_delta);

    if (stat.is_clicked) {
      ++click_num_;
      min_click_refresh = std::min(min_click_refresh, stat.refresh_idx);
    }
  }

  recent_continuous_refresh_num_ = 0;
  recent_continuous_show_num_ = 0;
  auto jt = refresh_show_num_.begin();
  for (auto it = refresh_show_num_.begin(); it != refresh_show_num_.end(); ++it) {
    if (it == refresh_show_num_.begin()) {
      recent_continuous_refresh_num_ = 1;
      recent_continuous_show_num_ = it->second;
      continue;
    }
    int diff = it->first - jt->first;
    if (diff <= 1) {
      recent_continuous_refresh_num_++;
      recent_continuous_show_num_ += it->second;
    } else {
      break;
    }
    ++jt;
  }

  show_since_last_click_ = 0;
  for (auto it = refresh_show_num_.begin(); it != refresh_show_num_.end(); ++it) {
    if (it->first < min_click_refresh) {
      show_since_last_click_ += it->second;
    } else {
      break;
    }
  }
}
} // namespace leaf
} // namespace reco
