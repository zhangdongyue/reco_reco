#pragma once

#include <map>
#include <set>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/serv/reco_leaf/strategy/user_behavior/behavior_stat.h"
#include "base/time/time.h"

namespace reco {
class NewsIndex;
namespace leafserver {

// 维护各个维度的统计指标的类
class BehaviorParser {
 public:
  BehaviorParser();
  ~BehaviorParser();

  // 重置内部的统计量
  void Reset();
  // 执行统计
  void Parse(const reco::user::UserInfo* user_info, reco::NewsIndex* news_index);

  // 查询类 api
  // 查询指定类别，指定时间窗的统计数据 TimeWindow 的定义见 behavior_stat.h
  const BehaviorStatistics* GetCategoryStat(const std::string& category, TimeWindow window) const {
    return get_stat(category, window, category_stat_);
  }

  // 查询指定二级类别，指定时间窗的统计数据 
  const BehaviorStatistics* GetSubCategoryStat(const std::string& sub_category, TimeWindow window) const {
    return get_stat(sub_category, window, sub_category_stat_);
  }

  // 查询指定标签，指定时间窗的统计数据 这里的标签是在 NewsIndex::GetTitleCoreTags 得到的核心标签
  const BehaviorStatistics* GetTagStat(const std::string& tag, TimeWindow window) const {
    return get_stat(tag, window, tag_stat_);
  }

 private:
  // 回溯用户历史的最早解析的时间
  static const int kEarliestDays = 30;
  // 时间差为多少就认为是一个新的 session.  注意当前用户展现记录输入以后，有可能仍然处在一个 session 里
  // 即展现历史中最近的时间戳跟当前时间差距小于 kSessionGapMinutes
  static const int kSessionGapMinutes = 10;
  // 最多统计这个人的多少维度的行为 内部会维护一个池子，避免内存重复分配
  static const int kBehaviorPoolMaxSize = 1000;
  // 遍历 show 和 click 的最大遍历条数
  static const int kMaxTraverse = 5000;

  const BehaviorStatistics* get_stat(
      const std::string& text, TimeWindow window,
      const std::map<std::string, std::map<TimeWindow, BehaviorStatistics*> >& stat_map) const {
    auto it = stat_map.find(text);
    if (it == stat_map.end()) {
      return NULL;
    }
    auto jt = it->second.find(window);
    if (jt == it->second.end()) {
      return NULL;
    }
    return jt->second;
  }

  // 收集指定维度的 item 刷新展现点击信息
  void CollectItem(const std::string& text, TimeWindow window, const ItemStat* item_stat,
                   std::map<std::string, std::map<TimeWindow, BehaviorStatistics*> >* behavivor_stat);

  // 计算指定维度的统计量
  void CalcStatistics(const std::map<TimeWindow, std::pair<int, std::set<int64> > >& show_fresh_cnts,
                      std::map<std::string, std::map<TimeWindow, BehaviorStatistics*> >* behavivor_stat);
 private:
  // 当前时间
  base::Time now_time_;
  int64 now_timestamp_;
  // 今天凌晨
  base::Time midnight_time_;
  // 解析用户历史时最长保留的时间
  int64 earliest_timestamp_;

  // 刷新时间对应的 item 记录
  std::multimap<int64, ItemStat, std::greater<int64>> ts_item_stat_;
  // category -> time window -> stat
  std::map<std::string, std::map<TimeWindow, BehaviorStatistics*> > category_stat_;
  // sub category -> time window -> stat
  std::map<std::string, std::map<TimeWindow, BehaviorStatistics*> > sub_category_stat_;
  // tag -> time window -> stat
  std::map<std::string, std::map<TimeWindow, BehaviorStatistics*> > tag_stat_;

  // 行为的数据都从这个数组中分配，超过数组限额的行为就不统计了
  std::vector<BehaviorStatistics> stat_pool_;
};
} // namespace leaf
} // namespace reco
