#include "reco/serv/reco_leaf/strategy/user_behavior/behavior_stat.h"

#include <unordered_set>
#include <stdlib.h>
#include <iostream>

#include "base/testing/gtest.h"

namespace reco {
namespace leafserver {

TEST(BehaviorStatisticsTest, stat) {
  // 构造第几刷的 case， 测试连续刷新次数的计算
  static const int kShow = 8;
  // total show, total refresh 随便拍的
  static const int kTotalShow = 20;
  static const int kTotalRefresh = 15;
  struct {
    int refresh_idx[kShow];
    int minute_delta[kShow];
    bool is_clicked[kShow];
    int members[8];
  } cases [] = {
    {
      {1, 1, 2, 3, 4, 4, 4, 5},
      {5, 5, 6, 7, 7, 7, 8, 8},
      {true, false, true, false, false, false, true, false},
      {kShow, 5, 3, 1, 5, 8, 5, 0},
    },
    {
      {1, 1, 2, 5, 5, 6, 8, 8},
      {5, 5, 6, 7, 7, 7, 8, 8},
      {false, false, true, false, false, false, true, false},
      {kShow, 5, 2, 1, 5, 3, 2, 2},
    },
    {
      {2, 2, 2, 4, 5, 5, 8, 8},
      {5, 5, 6, 7, 7, 7, 8, 8},
      {false, false, false, false, false, true, false, false},
      {kShow, 4, 1, 2, 5, 3, 1, 4},
    },
  };
  int case_num = ARRAYSIZE_UNSAFE(cases);
  std::vector<ItemStat> stats;
  BehaviorStatistics behavior_stat;
  for (int i = 0; i < case_num; ++i) {
    stats.resize(kShow);
    behavior_stat.reset();
    for (int j = 0; j < kShow; ++j) {
      ItemStat& stat = stats[j];
      stat.item_id = j;
      stat.session_idx = 1;
      stat.day_delta = 1;
      stat.is_today = true;
      stat.refresh_idx = cases[i].refresh_idx[j];
      stat.minute_delta = cases[i].minute_delta[j];
      stat.is_clicked = cases[i].is_clicked[j];

      behavior_stat.CollectItem(&stat);
    }
    behavior_stat.CalcStatistics(kTotalShow, kTotalRefresh);
    ASSERT_EQ(behavior_stat.total_show_num_, kTotalShow);
    ASSERT_EQ(behavior_stat.total_refresh_num_, kTotalRefresh);

    EXPECT_EQ(behavior_stat.show_num_, cases[i].members[0]);
    EXPECT_EQ(behavior_stat.refresh_num_, cases[i].members[1]);
    EXPECT_EQ(behavior_stat.click_num_, cases[i].members[2]);
    EXPECT_EQ(behavior_stat.min_refresh_interval_, cases[i].members[3]);
    EXPECT_EQ(behavior_stat.min_minute_interval_, cases[i].members[4]);
    EXPECT_EQ(behavior_stat.recent_continuous_show_num_, cases[i].members[5]);
    EXPECT_EQ(behavior_stat.recent_continuous_refresh_num_, cases[i].members[6]);
    EXPECT_EQ(behavior_stat.show_since_last_click_, cases[i].members[7]);
  }
}

}  // namespace leafserver
}  // namespace reco

