#include <unordered_set>
#include <stdlib.h>
#include <iostream>

#include "base/testing/gtest.h"
#include "base/time/timestamp.h"
#include "base/time/time.h"
#include "base/random/pseudo_random.h"
#include "reco/bizc/reco_index/mock_index_builder.h"
#include "reco/bizc/reco_index/news_index.h"

#include "reco/serv/reco_leaf/strategy/user_behavior/behavior_parser.h"

namespace reco {
namespace leafserver {
class BehaviorParserTest : public testing::Test {
public:
  void SetUp() {
    BuildIndex();
    InitUserInfoCase1();
  }

  void BuildIndex() {
    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(1);
      item.mutable_identity()->set_outer_id("item1");
      item.mutable_identity()->set_type(reco::kNews);
      item.set_is_valid(true);

      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("tag1");
      item.set_content("content1");
      item.set_source("sina");
      item.add_category("社会");
      item.add_channel_id(reco::common::kHotChannelId);

      item.mutable_raw_item()->add_show_tag("tag1");

      builder_.AddDoc(item);
    }

    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(2);
      item.mutable_identity()->set_outer_id("item2");
      item.mutable_identity()->set_type(reco::kNews);
      item.set_is_valid(true);

      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("tag2");
      item.set_content("content2");
      item.set_source("sohu");
      item.add_category("社会");
      item.add_channel_id(reco::common::kHotChannelId);

      item.mutable_raw_item()->add_show_tag("tag2");

      builder_.AddDoc(item);
    }

    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(3);
      item.mutable_identity()->set_outer_id("item3");
      item.mutable_identity()->set_type(reco::kNews);
      item.set_is_valid(true);

      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("tag2");
      item.set_content("content3");
      item.set_source("sina");
      item.add_category("体育");
      item.add_channel_id(reco::common::kSportChannelId);

      item.mutable_raw_item()->add_show_tag("tag2");

      builder_.AddDoc(item);
    }

    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(4);
      item.mutable_identity()->set_outer_id("item4");
      item.mutable_identity()->set_type(reco::kNews);
      item.set_is_valid(true);

      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("tag1");
      item.set_content("content4");
      item.set_source("sohu");
      item.add_category("体育");
      item.add_category("NBA");
      item.add_channel_id(reco::common::kSportChannelId);

      item.mutable_raw_item()->add_show_tag("tag1");

      builder_.AddDoc(item);
    }

    {
      reco::RecoItem item;
      item.mutable_identity()->set_app_token("app");
      item.mutable_identity()->set_item_id(5);
      item.mutable_identity()->set_outer_id("item5");
      item.mutable_identity()->set_type(reco::kNews);
      item.set_is_valid(true);

      now_.ToStringInSeconds(item.mutable_create_time());
      item.set_title("tag1");
      item.set_content("content5");
      item.set_source("sohu");
      item.add_category("体育");
      item.add_category("NBA");
      item.add_channel_id(reco::common::kSportChannelId);

      item.mutable_raw_item()->add_show_tag("tag1");

      builder_.AddDoc(item);
    }
    builder_.BuildIndex("/tmp",
                        "ads_index/api/data/static_dict.dat");

    news_index_ = const_cast<reco::NewsIndex*>(builder_.GetNewsIndex());
    CHECK_NOTNULL(news_index_);
    LOG(INFO) << base::StringPrintf("init news index finished!");
  }

  void InitUserInfoCase1() {
    int64 now_ts = base::GetTimestamp();
    int64 last_session_ts = now_ts - base::Time::kMicrosecondsPerHour;
    int64 yestoday_ts = now_ts - base::Time::kMicrosecondsPerDay;
    int64 last_week_ts = now_ts - 7 * base::Time::kMicrosecondsPerDay;

    // user_info_case1.mutable_identity();

    // show: 5 item:
    ViewClickItem* item;
    // show item 1, now
    item = user_info_case1_.add_shown_history();
    item->set_item_id(1);
    item->set_item_type(kNews);
    item->set_view_timestamp(now_ts);
    // show item 2, now
    item = user_info_case1_.add_shown_history();
    item->set_item_id(2);
    item->set_item_type(kNews);
    item->set_view_timestamp(now_ts);
    // show item 3, last session
    item = user_info_case1_.add_shown_history();
    item->set_item_id(3);
    item->set_item_type(kNews);
    item->set_view_timestamp(last_session_ts);
    // show item 4, yestoday
    item = user_info_case1_.add_shown_history();
    item->set_item_id(4);
    item->set_item_type(kNews);
    item->set_view_timestamp(yestoday_ts);
    // show item 5, last week
    item = user_info_case1_.add_shown_history();
    item->set_item_id(5);
    item->set_item_type(kNews);
    item->set_view_timestamp(last_week_ts);

    // click: 3 item:
    // reco 1: 2 click, 1 sttg item(type 0 action 0 cate1), 1 common item
    // reco 2: 1 click, 1 sttg item(type 0 action 1 tag2)
    //
    // click item 1, reco_1
    item = user_info_case1_.add_recent_click();
    item->set_item_id(1);
    item->set_click_timestamp(now_ts);

    // click item 3, reco_1
    item = user_info_case1_.add_recent_click();
    item->set_item_id(3);
    item->set_click_timestamp(now_ts);

    // click item 4, reco_2
    item = user_info_case1_.add_recent_click();
    item->set_item_id(4);
    item->set_click_timestamp(now_ts);
  }

  void TearDown() {
  }

  UserInfo user_info_case1_;
  UserInfo user_info_case2_;

  std::vector<reco::RecoItem> items_;
  reco::NewsIndex* news_index_;
  base::Time now_;

  MockIndexBuilder builder_;
};

TEST_F(BehaviorParserTest, parse) {
  BehaviorParser parser;
  parser.Reset();
  parser.Parse(&user_info_case1_, news_index_);

  // curr,item1,社会,tag1,clicked curr,item2,社会,tag2
  const BehaviorStatistics* stat;
  stat = parser.GetCategoryStat("社会", kCurrentSession);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=2,total_refresh_num=1,show_num=2,refresh_num=1,click_num=1,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=2,recent_continuous_refresh_num=1,show_since_last_click=0");

  stat = parser.GetTagStat("tag1", kCurrentSession);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=2,total_refresh_num=1,show_num=1,refresh_num=1,click_num=1,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=1,recent_continuous_refresh_num=1,show_since_last_click=0");
  stat = parser.GetTagStat("tag2", kCurrentSession);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=2,total_refresh_num=1,show_num=1,refresh_num=1,click_num=0,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=1,recent_continuous_refresh_num=1,show_since_last_click=1");
  EXPECT_TRUE(NULL == parser.GetCategoryStat("体育", kCurrentSession));
  EXPECT_TRUE(NULL == parser.GetSubCategoryStat("NBA", kCurrentSession));

  // last,item3,体育,tag2,clicked
  stat = parser.GetCategoryStat("体育", kLastSession);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=1,total_refresh_num=1,show_num=1,refresh_num=1,click_num=1,"
               "min_refresh_interval=2,min_minute_interval=60,"
               "recent_continuous_show_num=1,recent_continuous_refresh_num=1,show_since_last_click=0");
  stat = parser.GetTagStat("tag2", kLastSession);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=1,total_refresh_num=1,show_num=1,refresh_num=1,click_num=1,"
               "min_refresh_interval=2,min_minute_interval=60,"
               "recent_continuous_show_num=1,recent_continuous_refresh_num=1,show_since_last_click=0");
  EXPECT_TRUE(NULL == parser.GetCategoryStat("社会", kLastSession));
  EXPECT_TRUE(NULL == parser.GetSubCategoryStat("NBA", kLastSession));
  EXPECT_TRUE(NULL == parser.GetTagStat("tag1", kLastSession));

  // curr,item1,社会,tag1,clicked curr,item2,社会,tag2 last,item3,体育,tag2,clicked
  stat = parser.GetCategoryStat("体育", kToday);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=3,total_refresh_num=2,show_num=1,refresh_num=1,click_num=1,"
               "min_refresh_interval=2,min_minute_interval=60,"
               "recent_continuous_show_num=1,recent_continuous_refresh_num=1,show_since_last_click=0");
  stat = parser.GetCategoryStat("社会", kToday);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=3,total_refresh_num=2,show_num=2,refresh_num=1,click_num=1,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=2,recent_continuous_refresh_num=1,show_since_last_click=0");
  stat = parser.GetTagStat("tag1", kToday);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=3,total_refresh_num=2,show_num=1,refresh_num=1,click_num=1,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=1,recent_continuous_refresh_num=1,show_since_last_click=0");
  stat = parser.GetTagStat("tag2", kToday);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=3,total_refresh_num=2,show_num=2,refresh_num=2,click_num=1,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=2,recent_continuous_refresh_num=2,show_since_last_click=1");
  EXPECT_TRUE(NULL == parser.GetSubCategoryStat("NBA", kLastSession));

  // curr,item1,社会,tag1,clicked curr,item2,社会,tag2 last,item3,体育,tag2,clicked
  // yestoday,item4,体育NBA,tag1,clicked
  stat = parser.GetCategoryStat("体育", kLastThreeDays);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=4,total_refresh_num=3,show_num=2,refresh_num=2,click_num=2,"
               "min_refresh_interval=2,min_minute_interval=60,"
               "recent_continuous_show_num=2,recent_continuous_refresh_num=2,show_since_last_click=0");
  stat = parser.GetSubCategoryStat("NBA", kLastThreeDays);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=4,total_refresh_num=3,show_num=1,refresh_num=1,click_num=1,"
               "min_refresh_interval=3,min_minute_interval=1440,"
               "recent_continuous_show_num=1,recent_continuous_refresh_num=1,show_since_last_click=0");
  stat = parser.GetTagStat("tag1", kLastThreeDays);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=4,total_refresh_num=3,show_num=2,refresh_num=2,click_num=2,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=1,recent_continuous_refresh_num=1,show_since_last_click=0");
  stat = parser.GetCategoryStat("社会", kLastThreeDays);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=4,total_refresh_num=3,show_num=2,refresh_num=1,click_num=1,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=2,recent_continuous_refresh_num=1,show_since_last_click=0");
  stat = parser.GetTagStat("tag2", kLastThreeDays);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=4,total_refresh_num=3,show_num=2,refresh_num=2,click_num=1,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=2,recent_continuous_refresh_num=2,show_since_last_click=1");

  // curr,item1,社会,tag1,clicked curr,item2,社会,tag2 last,item3,体育,tag2,clicked
  // yestoday,item4,体育NBA,tag1,clicked lastweek,item5,体育NBA,tag1
  stat = parser.GetCategoryStat("体育", kTotal);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=5,total_refresh_num=4,show_num=3,refresh_num=3,click_num=2,"
               "min_refresh_interval=2,min_minute_interval=60,"
               "recent_continuous_show_num=3,recent_continuous_refresh_num=3,show_since_last_click=0");
  stat = parser.GetCategoryStat("社会", kTotal);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=5,total_refresh_num=4,show_num=2,refresh_num=1,click_num=1,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=2,recent_continuous_refresh_num=1,show_since_last_click=0");
  stat = parser.GetSubCategoryStat("NBA", kTotal);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=5,total_refresh_num=4,show_num=2,refresh_num=2,click_num=1,"
               "min_refresh_interval=3,min_minute_interval=1440,"
               "recent_continuous_show_num=2,recent_continuous_refresh_num=2,show_since_last_click=0");
  stat = parser.GetTagStat("tag1", kTotal);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=5,total_refresh_num=4,show_num=3,refresh_num=3,click_num=2,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=1,recent_continuous_refresh_num=1,show_since_last_click=0");
  stat = parser.GetTagStat("tag2", kTotal);
  EXPECT_STREQ(stat->ToString().c_str(),
               "total_show_num=5,total_refresh_num=4,show_num=2,refresh_num=2,click_num=1,"
               "min_refresh_interval=1,min_minute_interval=0,"
               "recent_continuous_show_num=2,recent_continuous_refresh_num=2,show_since_last_click=1");
}

TEST_F(BehaviorParserTest, RandomData) {
  BehaviorParser parser;

  base::Time old_day = base::Time::Now() - base::TimeDelta::FromDays(10);
  base::Time now_day = base::Time::Now();
  int64 old_timestamp = old_day.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int64 now_timestamp = now_day.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int64 delta_timestamp = now_timestamp - old_timestamp;
  base::PseudoRandom random;
  for (int round = 0; round < 10; ++round) {
    // 跑 10 轮。每轮构造随机 case
    UserInfo user_info;

    // 展现 1000
    for (int i = 0; i < 1000; ++i) {
      ViewClickItem* item;
      // show item 1, reco_1
      item = user_info.add_shown_history();
      item->set_item_id(random.GetInt(1, 5));
      item->set_item_type(kNews);
      item->set_view_timestamp(old_timestamp + random.GetUint64LT(delta_timestamp));
    }

    // 点击 1000
    for (int i = 0; i < 100; ++i) {
      ViewClickItem* item;
      item = user_info.add_recent_click();
      item->set_item_id(random.GetInt(1, 5));
      item->set_click_timestamp(old_timestamp + random.GetUint64LT(delta_timestamp));
    }

    parser.Reset();
    parser.Parse(&user_info_case1_, news_index_);
  }
}

}  // namespace leafserver
}  // namespace reco

