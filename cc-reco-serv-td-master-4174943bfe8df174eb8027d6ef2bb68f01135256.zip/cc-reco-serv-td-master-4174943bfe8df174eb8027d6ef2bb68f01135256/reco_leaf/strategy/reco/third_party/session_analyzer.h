#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "base/time/time.h"

namespace reco {
namespace leafserver {

// session 分析中间结果
struct SessionStatMidResult {
  int show_num;
  int click_num;
  int dislike_num;

  SessionStatMidResult() {
    show_num = 0;
    click_num = 0;
    dislike_num = 0;
  }

  ~SessionStatMidResult() {
  }

  std::string ToString() {
    return base::StringPrintf("%d,%d,%d", show_num, click_num, dislike_num);
  }
};

struct CategoryTuneResult {
  std::string category;
  int quota;
  double weight;

  CategoryTuneResult() {
    quota = 0;
    weight = 0;
  }

  ~CategoryTuneResult() {}

  bool operator > (const CategoryTuneResult& rhs) const {
    if (this->quota > rhs.quota) {
      return true;
    } else if (this->quota < rhs.quota) {
      return false;
    }

    if (this->weight > rhs.weight) {
      return true;
    } else if (this->weight < rhs.weight) {
      return false;
    }

    return this->category > rhs.category;
  }

  bool operator < (const CategoryTuneResult& rhs) const {
    return !(*this > rhs);
  }
};

} // namespace leafserver
} // namespace reco
