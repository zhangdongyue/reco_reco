#pragma once

#include <string>
#include <vector>
#include <unordered_set>

#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/reco/interest/interest_common.h"
#include "reco/ml/model/lr_model.h"
#include "reco/ml/feature/extractor/feature_extractor.h"
#include "reco/serv/reco_leaf/strategy/reco/third_party/session_analyzer.h"

namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {

// 基于第三方数据的推荐模块，用于纯新用户(无历史行为)和新用户(历史行为次数未达到阈值)
// 的内容推荐
// 推荐依据：
// 1.外部画像
// 2.行为session (考虑结合MBA算法)
// 3.probe
// 4.冷启动LR
// 5.特殊内容
class ThirdPartyReco {
 public:
  explicit ThirdPartyReco(const reco::NewsIndex* index);
  ~ThirdPartyReco();

  // 基于第三方数据推荐接口
  void DoThirdPartyReco(const RecoRequest* request,
                        int req_num,
                        std::vector<ItemInfo>* reco_items,
                        RecoContext* context);

 private:
  // 推荐频道
  void DoComplexChannelReco(std::vector<ItemInfo>* reco_items,
                            int req_num,
                            RecoContext* context);

  // TODO 垂直频道
  void DoVerticalChannelReco(std::vector<ItemInfo>* reco_items,
                             int req_num,
                             RecoContext* context);

  // 类别选择
  void CategorySelect(const RecoRequest* request,
                      std::vector<std::pair<double, reco::Category> >* select_categories,
                      RecoContext* context);

  // 冷启动类别 LR 预测
  void CategoryLrPredict(const reco::user::UserInfo* user_info,
                         std::vector<std::pair<double, reco::Category> >* pred_categories);

  // 类别进退场
  void TuneCategoryRank(std::vector<std::pair<double, reco::Category> >* cate_distribute);

  // 类别推荐(并行)
  void MultiCategoryReco(const std::vector<std::pair<double, reco::Category> >& category_distributes,
                         std::map<std::string, std::vector<ItemInfo> >& cate_items_vec,
                         RecoContext* context);

  // 类别内推荐
  void CategoryReco(const reco::Category* category,
                    std::vector<ItemInfo>* cate_items,
                    RecoContext* context);

  // 并行计算每个 item 的 LR 预测结果并进行 item 排序
  void MultiItemRank(const reco::user::UserInfo* user_info,
                     const std::vector<ItemInfo>& candidates,
                     std::vector<std::pair<double, ItemInfo> >* predict_ret,
                     RecoContext* context);

  // 冷启动 item (类别, tag, topic) 预测
  void ItemLrPredict(const reco::user::UserInfo* user_info,
                     const std::vector<ItemInfo>* item_vec,
                     std::vector<std::pair<double, ItemInfo> >* thread_items);

  // 推荐频道结果合并
  void MergeComplexChannelRecoResults(
         std::map<std::string, std::vector<ItemInfo> >& cate_items_vec,
         const std::vector<std::pair<double, reco::Category> >* category_distribute,
         std::vector<ItemInfo>* ret_items,
         int req_num,
         RecoContext* context);

  // 确定计算线程数
  // int DecideCategoryRecoThread();
  // int DecideItemPredictThread();
  // int DecideItemPredictCandidateSize();

  std::string ConvertCategoryVectorToString(
                const std::vector<std::pair<double, reco::Category> >& categories);

  bool GetL1Category(const uint64 item_id, std::string* category);

  // 获取缓存
  void GetCachedCategories(const std::string& cache_key,
                           int64 now_timestamp,
                           std::vector<std::pair<double, reco::Category> >* category_distribute);

  void GetCachedItems(const std::string& cache_key,
                      int64 now_timestamp,
                      std::vector<ItemInfo>* cached_items);

  // show history 去重
  void UserDedup(const RecoRequest* reco_request, std::vector<ItemInfo>* item_list,
                 int64* filtered_num);

 private:
  static const int kNewsNumPerScreen;
  static const int kMaxNumPerCate;
 
  const reco::NewsIndex* news_index_;
  const RecoRequest* reco_request_;
  const reco::user::UserInfo* user_info_;

  base::PseudoRandom* random_;
  serving_base::Timer timer_;

  CandidatesExtractor* candidates_extractor_;
 
  // 各类目下的推荐结果
  std::map<std::string, std::vector<ItemInfo> > cate_items_vec_;

  // 特殊途径推荐结果

  // 类目列表
  static const char* kDefaultIflowCategories[];
  std::unordered_set<std::string> default_iflow_categories_;

  // item type 列表
  std::set<int> allowed_item_types_;

  std::vector<std::string> tokens_;
};

}
}

