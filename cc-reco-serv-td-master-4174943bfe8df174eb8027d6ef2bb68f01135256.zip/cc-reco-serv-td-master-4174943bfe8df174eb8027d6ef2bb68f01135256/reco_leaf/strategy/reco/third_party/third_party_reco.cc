#include "reco/serv/reco_leaf/strategy/reco/third_party/third_party_reco.h"

#include <algorithm>

#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/common/item_level_define.h"
#include "reco/serv/reco_leaf/strategy/reco/interest/interest_common.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"

namespace reco {
namespace leafserver {

DEFINE_double(min_tp_cate_lr_hit_fea_num, 1, "第三方数据预测 category LR 模型命中特征个数阈值");
DEFINE_double(min_tp_item_lr_hit_fea_num, 1, "第三方数据预测 category LR 模型命中特征个数阈值");
DEFINE_double(min_tp_cate_lr_score, 0, "第三方数据预测 category LR 模型得分阈值");
DEFINE_double(min_tp_item_lr_score, 0, "第三方数据预测 item LR 模型得分阈值");
DEFINE_int32(max_tp_cate_num, 10, "第三方数据预测的类目个数阈值");
DEFINE_int32(tp_cate_topn, 4, "每次推荐最多选用的类目个数");
DEFINE_int32(max_tp_item_candidate_num, 4000, "每个类目召回的 item 数");
DEFINE_int32(max_tp_item_rank_num, 400, "每个类目进行排序预测的 item 数");
DEFINE_int32(max_tp_reco_item_num, 100, "每个类目推荐的结果数");
DEFINE_double(tp_item_rank_good_timeliness_boost, 0.2, "高时效性 item 加权系数");
DEFINE_double(tp_item_rank_lr_boost, 0, "个性化 lr 得分加权系数");
DEFINE_bool(do_tp_category_probe, false, "是否做类目进退场");
DEFINE_bool(do_tp_item_lr_predict, false, "是否根据第三方数据做 item ctr 预估");

const char* ThirdPartyReco::kDefaultIflowCategories[] = { "科技", "体育", "健康", "军事",
  "历史", "国际", "奇闻", "娱乐", "干货", "房产", "收藏", "教育", "旅游", "时尚", "星座",
  "汽车", "游戏", "社会", "美食", "职场", "育儿", "财经", "两性情感", "国内"};

const int ThirdPartyReco::kNewsNumPerScreen = 8;
const int ThirdPartyReco::kMaxNumPerCate = 2;

ThirdPartyReco::ThirdPartyReco(const reco::NewsIndex* index) : news_index_(index) {
  random_ = new base::PseudoRandom(base::GetTimestamp());
  candidates_extractor_ = new CandidatesExtractor(news_index_);

  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(kDefaultIflowCategories); ++i) {
    default_iflow_categories_.insert(kDefaultIflowCategories[i]);
  }

  // item types
  allowed_item_types_.insert(reco::kNews);
  allowed_item_types_.insert(reco::kReading);
  allowed_item_types_.insert(reco::kPicture);
  allowed_item_types_.insert(reco::kSpecial);
}

ThirdPartyReco::~ThirdPartyReco() {
  delete random_;
  delete candidates_extractor_;
}

void ThirdPartyReco::DoThirdPartyReco(const RecoRequest* request,
                                      int req_num,
                                      std::vector<ItemInfo>* reco_items,
                                      RecoContext* context) {
  reco_request_ = request;
  user_info_ = reco_request_->user_info;

  if (request->channel_id == reco::common::kRecoChannelId) {
    DoComplexChannelReco(reco_items, req_num, context);
  } else {
    // 暂时仅对推荐频道生效
    // DoVerticalChannelReco(reco_items, req_num, context);
  }
}

// 大体上遵循类别选择 - 类别内推荐 - 类别间合并3大步骤
// 后续如果有新的方法直接出推荐结果也可以不用遵循该步骤
void ThirdPartyReco::DoComplexChannelReco(std::vector<ItemInfo>* reco_items,
                                          int req_num,
                                          RecoContext* context) {
  uint64 user_id = user_info_->identity().user_id();

  // categories selected
  VLOG(1) << "do CategorySelect, uid=" << user_id;
  std::vector<std::pair<double, reco::Category> > category_distributes;
  CategorySelect(reco_request_, &category_distributes, context);
  if (category_distributes.empty()) {
    VLOG(1) << "no third party category selected, uid=" << user_id;
    return;
  }

  // category reco
  VLOG(1) << "do MultiCategoryReco, uid=" << user_id;
  cate_items_vec_.clear();
  MultiCategoryReco(category_distributes, cate_items_vec_, context);

  // 特殊途径产生的推荐结果
  // TODO

  // merge results
  VLOG(1) << "do MergeComplexChannelRecoResults, uid=" << user_id;
  MergeComplexChannelRecoResults(cate_items_vec_, &category_distributes, reco_items, req_num, context);

  // debug trace
  // TODO

  for (int i = 0; i < (int)reco_items->size(); ++i) {
    ItemInfo &item = reco_items->at(i);
    item.strategy_type = reco::kThirdPartyItem;
    item.strategy_branch = reco::kThirdPartyRecoBranch;
    VLOG(1) << "tp reco result: uid=" << user_id << ", item_id=" << reco_items->at(i).item_id;
  }
}

void ThirdPartyReco::DoVerticalChannelReco(
       std::vector<ItemInfo>* reco_items,
       int req_num,
       RecoContext* context) {
}

// 类别选择相关的逻辑，如基于外渠画像的LR模型，基于用户行为的类别探索，都可封装在这里
// 内部实现类目进退场机制
void ThirdPartyReco::CategorySelect(
       const RecoRequest* request,
       std::vector<std::pair<double, reco::Category> >* select_categories,
       RecoContext* context) {
  uint64 user_id = user_info_->identity().user_id();
  select_categories->clear();

  // LR 预测的感兴趣类别
  std::vector<std::pair<double, reco::Category> > tp_categories;

  // note 使用缓存, 不然有性能风险
  std::string cache_key = base::StringPrintf("%s_%lu", "TpCateCnd", user_id);
  int64 now_timestamp = base::GetTimestamp();
  GetCachedCategories(cache_key, now_timestamp, &tp_categories);
  if (!tp_categories.empty()) {
    // 命中缓存
    VLOG(1) << "match TpCateCnd cache, key=" << cache_key
            << ", size=" << tp_categories.size();
  } else {
    // 调用模型进行预测
    CategoryLrPredict(request->user_info, &tp_categories);
    // 写缓存
    std::vector<std::string> cache_str_list;
    for (size_t i = 0; i < tp_categories.size(); ++i) {
      cache_str_list.push_back(base::StringPrintf("%s,%f",
        tp_categories[i].second.category().c_str(), (float)tp_categories[i].first));
    }
    LeafCache::SetCachedReco(cache_key, base::JoinStrings(cache_str_list, ","), 600);
    VLOG(2) << "SetCachedReco, key=" << cache_key << ", value=" << base::JoinStrings(cache_str_list, ",");
  }
  VLOG(1) << "predict tp categories, uid=" << user_id
          << ", categories=" << ConvertCategoryVectorToString(tp_categories);

  // 类目进退场
  if (FLAGS_do_tp_category_probe) {
    TuneCategoryRank(&tp_categories);
    VLOG(1) << "retuned tp categories, uid=" << user_id
            << ", categories=" << ConvertCategoryVectorToString(tp_categories);
  }

  // 取 top 类目
  for (auto it = tp_categories.begin(); it != tp_categories.end(); ++it) {
    if ((int)select_categories->size() >= FLAGS_tp_cate_topn) break;
    select_categories->push_back(*it);
  }

  LOG(INFO) << "select tp categories, uid=" << user_id
            << ", categories=" << ConvertCategoryVectorToString(*select_categories);
}

// 使用冷启动 LR 模型预测用户感兴趣类别
void ThirdPartyReco::CategoryLrPredict(
       const reco::user::UserInfo* user_info,
       std::vector<std::pair<double, reco::Category> >* pred_categories) {
  if (pred_categories == NULL) return;
  pred_categories->clear();
  if (user_info == NULL) return;

  // 获取模型数据 (暂时从 global data 加载)
  // reco::ml::DenseHashLRModel* model = LeafDataManager::GetGlobalData()->tp_item_lr_model_;
  // if (model == NULL) return;

  auto lr_model_dict = DM_GET_DICT(reco::dm::LrModel, DynamicDictContainer::kThirdPartyCategoryLrModelFile_);
  const reco::ml::DenseHashLRModel* model = &lr_model_dict->lr_model_;
  if (model == NULL) return;

  // 抽取特征
  reco::ml::BaseFeatureExtractor* extractor = new reco::ml::ThirdPartyDataCategoryFeatureExtractor();
  extractor->SetupFeatureLayout();
  extractor->ResetUser(*user_info);

  std::vector<std::string> literal_fea_vec;
  std::vector<std::pair<double, std::string> > lr_scores;
  double sum_weight;
  int hits;
  double ctr;
  std::vector<std::string> hit_features;
  for (auto iter = default_iflow_categories_.begin(); iter != default_iflow_categories_.end(); ++iter) {
    const std::string& category = *iter;
    if (category.empty()) continue;

    // 构造虚拟 item
    reco::RecoItem item;
    item.mutable_identity()->set_item_id(100);
    item.add_category(category);

    literal_fea_vec.clear();
    extractor->ExtractUserItemFeature(item, &literal_fea_vec);
    if (literal_fea_vec.size() <= 1 + FLAGS_min_tp_cate_lr_hit_fea_num) continue;

    // predict
    hit_features.clear();
    model->Predict(literal_fea_vec, &sum_weight, &hits, &ctr, &hit_features);

    // 卡 lr score
    if (ctr >= FLAGS_min_tp_cate_lr_score) {
      lr_scores.push_back(std::make_pair(ctr, category));
    }
  }
  delete extractor;

  // sort and get topN categories
  std::sort(lr_scores.begin(), lr_scores.end(), std::greater<std::pair<double, std::string> >());
  for (size_t idx = 0; idx < lr_scores.size() && (int)idx < FLAGS_max_tp_cate_num; ++idx) {
    reco::Category cat;
    cat.set_category(lr_scores[idx].second);
    cat.set_level(0);
    pred_categories->push_back(std::make_pair(lr_scores[idx].first, cat));
  }
}

// 类别进退场调节：对多次展现不点击的类目进行退场，对点击的类目进行提权
// 基本思路：
// 1) 每个待探索类目初始时分配相同的 quota (可用探索次数)
// 2) 选取下发类目时, 若 quota 不足, 则本轮不下发该类目; 将有 quota 的类目按 LR 模型预测得分降序排列后取 top
//    作为本轮的下发类目
// 3) 一屏投放结束时, 若类目被点击, 则该类目 quota 增大, 若展现不点击, 则 quota 减小, 若用户 dislike,
//    则 quota 大幅减小
// 4) 若类目已间隔很久没有下发，则分配一个很小的 quota 进行一次尝试
void ThirdPartyReco::TuneCategoryRank(
       std::vector<std::pair<double, reco::Category> >* cate_distribute) {
  uint64 user_id = user_info_->identity().user_id();

  // quota 设置
  int default_quota = 3;
  int click_delta = 2;
  int no_click_delta = -1;
  int max_quota = 5;

  // 各类目的下发 quota
  std::map<std::string, int> cate_quota;

  // 分配初始 quota
  for (int i = 0; i < (int)cate_distribute->size(); ++i) {
    cate_quota[cate_distribute->at(i).second.category()] = default_quota;
  }

  // 分析 show 和 click 历史, 统计 quota 消耗情况
  // 分析最近 n 个 pv
  int64 session_time_range = 5 * 24;
  int64 session_pv_range = 10;
  int64 earlist_time = base::GetTimestamp() - session_time_range * base::Time::kMicrosecondsPerHour;
  const reco::user::UserInfo *user_info = user_info_;

  std::set<uint64> clicked_items;
  for (int i = user_info->recent_click_size() -1; i >= 0; i--) {
    const reco::user::ViewClickItem &item = user_info->recent_click(i);
    if (item.click_timestamp() < earlist_time) {
      break;
    }
  }

  // 先定位到show history 的开始位置，然后再逆序遍历， 方便后续处理
  int64 last_show_timestamp = 0;
  int pv = 0;
  int idx;
  for (idx = user_info->shown_history_size() - 1; idx >= 0; idx--) {
    const reco::user::ViewClickItem &item = user_info->shown_history(idx);
    if (!item.has_view_timestamp()) {
      continue;
    }
    if (item.view_timestamp() < earlist_time) {
      break;
    }
    if (item.view_timestamp() != last_show_timestamp) {
      last_show_timestamp = item.view_timestamp();
      pv++;
    }
    if (pv > session_pv_range) {
      break;
    }
  }
  idx++;
  VLOG(1) << "uid=" << user_id << ", session_start_idx=" << idx
          << ", show_size=" << user_info->shown_history_size();

  // session stat results
  std::vector<std::pair<int, std::map<std::string, SessionStatMidResult> > > session_results;
  std::vector<std::string> categories;
  pv = 0;
  last_show_timestamp = 0;
  std::map<std::string, SessionStatMidResult> ret;
  if (idx < 0) idx = 0;
  for (; idx < user_info->shown_history_size(); idx++) {
    const reco::user::ViewClickItem &item = user_info->shown_history(idx);

    // 以 pv 为粒度统计 quota 消耗
    if (!item.has_view_timestamp()) continue;
    if (item.view_timestamp() != last_show_timestamp) {
      last_show_timestamp = item.view_timestamp();
      pv++;

      if (!ret.empty()) {
        session_results.push_back(std::make_pair(pv, ret));
      }
      ret.clear();
    }

    // 仅分析本策略分支下发记录
    VLOG(2) << "show history: uid=" << user_id << ", item_id=" << item.item_id()
            << ", strategy_branch=" << item.strategy_branch() << ", timestamp=" << item.view_timestamp();
    if (!item.has_strategy_branch() || item.strategy_branch() != reco::kThirdPartyRecoBranch) {
      continue;
    }

    categories.clear();
    if (!news_index_->GetCategoriesByItemId(item.item_id(), &categories)
        || categories.empty() || categories[0].empty()) {
      VLOG(1) << "failed to get categories for item " << item.item_id();
      continue;
    }

    SessionStatMidResult &mid = ret[categories[0]];
    mid.show_num++;
    if (clicked_items.find(item.item_id()) != clicked_items.end()) {
      mid.click_num++;
    }
  }
  if (!ret.empty()) {
    session_results.push_back(std::make_pair(pv, ret));
  }

  // 计算当前可用 quota
  for (int i = 0; i < (int)session_results.size(); i++) {
    std::map<std::string, SessionStatMidResult> &cate_mid_ret = session_results[i].second;
    for (auto it = cate_mid_ret.begin(); it != cate_mid_ret.end(); ++it) {
      std::string category = it->first;
      SessionStatMidResult &mid = it->second;
      VLOG(2) << "uid=" << user_id << ", pv=" << session_results[i].first
              << ", category=" << category << ", SessionStatMidResult=" << mid.ToString();
      if (cate_quota.find(category) == cate_quota.end()) {
        continue;
      }
      if (mid.click_num > 0) {
        cate_quota[category] = std::min(max_quota, cate_quota[category] + click_delta);
      } else if (mid.show_num > 0) {
        cate_quota[category] = std::max(0, cate_quota[category] + no_click_delta);
      } else {
        // TODO  dislike, 间隔很久未下发
      }
    }
  }

  // 排序: 先按 quota 排序，后按 LR 得分排序
  std::vector<CategoryTuneResult> tune_results;
  for (int i = 0; i < (int)cate_distribute->size(); ++i) {
    CategoryTuneResult tune_ret;
    tune_ret.category = cate_distribute->at(i).second.category();
    tune_ret.weight = cate_distribute->at(i).first;
    tune_ret.quota = cate_quota[cate_distribute->at(i).second.category()];
    tune_results.push_back(tune_ret);
  }
  std::sort(tune_results.begin(), tune_results.end(), std::greater<CategoryTuneResult>());

  cate_distribute->clear();
  for (int i = 0; i < (int)tune_results.size(); ++i) {
    if (tune_results[i].quota < 1) {
      break;
    }
    reco::Category category;
    category.set_category(tune_results[i].category);
    category.set_level(0);
    cate_distribute->push_back(std::make_pair(tune_results[i].weight, category));
  }
}

// 并行计算每个类目下的推荐结果
void ThirdPartyReco::MultiCategoryReco(
    const std::vector<std::pair<double, reco::Category> >& category_distributes,
    std::map<std::string, std::vector<ItemInfo> >& cate_items_vec,
    RecoContext* context) {
  // int concurrent_num = DecideCategoryRecoThread();
  int concurrent_num = LeafDataManager::GetGlobalData()->GetParallelNum();
  if (!reco_request_->user_param_info.is_inner_qudao) {
    concurrent_num = std::max(concurrent_num, 3);
  }
  thread::ThreadPool pool(concurrent_num);
  for (size_t i = 0; i < category_distributes.size(); ++i) {
    const reco::Category* category = &category_distributes.at(i).second;
    if (!category->has_category() || category->category().empty()) continue;
    std::vector<ItemInfo>* cate_items = &cate_items_vec[category->category()];
    VLOG(1) << "add CategoryReco job, uid=" << user_info_->identity().user_id() 
            << ", category=" << category->category()
            << ", ratio=" << category_distributes.at(i).first;
    pool.AddTask(::NewCallback(this, &ThirdPartyReco::CategoryReco,
                               category, cate_items, context));
  }
  pool.JoinAll();
}

// 内部不能有全局变量的写操作，否则多线程会 core
void ThirdPartyReco::CategoryReco(const reco::Category* category,
                                  std::vector<ItemInfo>* cate_items,
                                  RecoContext* context) {
  uint64 user_id = user_info_->identity().user_id();
  RecoDebugger* debugger = context->debugger();

  // note 使用缓存, 不然有性能风险
  std::string cache_key = base::StringPrintf("%s_%lu_%s", "TpCateItemCnd", user_id, category->category().c_str());
  int64 now_timestamp = base::GetTimestamp();
  GetCachedItems(cache_key, now_timestamp, cate_items);
  if (!cate_items->empty()) {
    // 命中缓存，去重后直接返回
    VLOG(1) << "match TpCateItemCnd cache, key=" << cache_key
            << ", size=" << cate_items->size();
    int64 dedup_num = 0;
    UserDedup(reco_request_, cate_items, &dedup_num);
    for (size_t i = 0; i < cate_items->size(); ++i) {
      cate_items->at(i).reco_ext_info = category->category();
    }
    VLOG(1) << "user dedup: uid=" << user_id << ", category=" << category->category()
            << ", left=" << cate_items->size() << ", deduped=" << dedup_num;
    return;
  }

  // 获取候选集
  std::vector<ItemInfo> candidate_items;
  candidates_extractor_->GetCandidatesByCategory(*category, reco_request_, &candidate_items,
                                                  FLAGS_max_tp_item_candidate_num, debugger);

  // filter
  int p = 0;
  for (size_t i = 0; i < candidate_items.size(); i++) {
    if (p >= FLAGS_max_tp_item_rank_num) {
      break;
    }

    ItemInfo &item = candidate_items[i];

    // 过滤 item type
    if (allowed_item_types_.find(item.item_type) == allowed_item_types_.end()) {
      continue;
    }

    // 卡时效性和后验 ctr, 只出该类目下最新最优的 item
    if (item.time_level == reco::kBadTimeliness
        || item.show_num < 2000 || item.ctr < 0.1) {
      continue;
    }
    candidate_items[p++] = candidate_items[i];
  }
  candidate_items.resize(p);
  VLOG(1) << "uid=" << user_id << ", category=" << category->category()
          << ", candidate_size=" << p;

  // rank candidates (LR)
  std::vector<std::pair<double, ItemInfo> > rank_items;
  MultiItemRank(user_info_, candidate_items, &rank_items, context);
  std::stringstream log_str;
  log_str << "top 20 tp item: uid=" << user_id << ", category=" << category->category() << ": ";
  for (size_t i = 0; i < rank_items.size() && i < 20; ++i) {
    log_str << rank_items[i].second.item_id << ":" << rank_items[i].first << ",";
  }
  VLOG(1) << log_str.str();

  std::vector<std::string> cache_str_list;
  base::dense_hash_set<uint64> item_dedup;
  item_dedup.set_empty_key(NULL);
  for (size_t i = 0; i < rank_items.size(); ++i) {
    if ((int)cate_items->size() >= FLAGS_max_tp_reco_item_num) break;
    if (rank_items[i].first < FLAGS_min_tp_item_lr_score) break;
    ItemInfo& item = rank_items[i].second;
    item.lr_score = (float)rank_items[i].first;
    if (!NewsFilter::IsDeduped(item, &item_dedup)) {
      cate_items->push_back(item);
      cache_str_list.push_back(base::StringPrintf("%lu,%f", item.item_id, item.lr_score));
      VLOG(2) << "category item ranked: uid=" << user_id << "category=" << category->category()
              << ", item_id=" << item.item_id << ", ctr=" << item.ctr
              << ", itemq=" << item.itemq << ", score=" << rank_items[i].first;
    }
  }

  // 写缓存
  LeafCache::SetCachedReco(cache_key, base::JoinStrings(cache_str_list, ","), 600);
  VLOG(2) << "SetCachedReco, key=" << cache_key << ", value=" << base::JoinStrings(cache_str_list, ",");

  int64 dedup_num = 0;
  UserDedup(reco_request_, cate_items, &dedup_num);
  for (size_t i = 0; i < cate_items->size(); ++i) {
    cate_items->at(i).reco_ext_info = category->category();
  }
  VLOG(1) << "user dedup: uid=" << user_id << ", category=" << category->category()
          << ", left=" << cate_items->size() << ", deduped=" << dedup_num;
}

// 并行计算每个 item 的 LR 预测结果
void ThirdPartyReco::MultiItemRank(
       const reco::user::UserInfo* user_info,
       const std::vector<ItemInfo>& candidates,
       std::vector<std::pair<double, ItemInfo> >* predict_ret,
       RecoContext* context) {
  uint64 user_id = user_info->identity().user_id();
  predict_ret->clear();

  if (!FLAGS_do_tp_item_lr_predict) {
    // 跳过 item lr 模型, 直接以后验ctr作为排序依据
    for (size_t i = 0; i < candidates.size(); ++i) {
      const ItemInfo &item = candidates[i];
      double reco_score = item.ctr;
      if (item.time_level == reco::kGoodTimeliness) {
        reco_score *= (1 + FLAGS_tp_item_rank_good_timeliness_boost);
      }
      predict_ret->push_back(std::make_pair(reco_score, item));
    }
  } else {
    // TODO
    return;

    /*
    // 走 item lr 模型预测 ctr
    int concurrent_num = DecideItemPredictThread();
    thread::ThreadPool pool(concurrent_num);

    // 每个线程一批预测 20 条 
    int thread_batch_size = 20;
    std::vector<ItemInfo> item_batch;
    std::vector<std::vector<ItemInfo> > item_batches;
    for (size_t i = 0; i < candidates.size(); ++i) {
      if ((int)item_batch.size() >= thread_batch_size) {
        item_batches.push_back(item_batch);
        item_batch.clear();
      }
      item_batch.push_back(candidates[i]);
    }
    if (item_batch.size() > 0u) {
      item_batches.push_back(item_batch);
    }

    // 各线程的预测结果
    std::map<int, std::vector<std::pair<double, ItemInfo> > > thread_ret_map;
    for (size_t i = 0; i < item_batches.size(); ++i) {
      const std::vector<ItemInfo>* item_vec = &item_batches[i];
      std::vector<std::pair<double, ItemInfo> >* thread_items = &thread_ret_map[i];
      VLOG(1) << "add tp item predict job, uid=" << user_id
              << ", item_size=" << item_vec->size() << ", thread=" << i;
      pool.AddTask(::NewCallback(this, &ThirdPartyReco::ItemLrPredict,
                                 user_info, item_vec, thread_items));
    }
    pool.JoinAll();

    // 排序, 考虑 lr_socre, 后验ctr, 时效性 
    VLOG(1) << "merge third party item lr results, uid=" << user_id;
    for (auto it = thread_ret_map.begin(); it != thread_ret_map.end(); ++it) {
      const std::vector<std::pair<double, ItemInfo> >& thread_ret = it->second;
      for (size_t i = 0; i < thread_ret.size(); ++i) {
        const double lr_score = thread_ret[i].first;
        const ItemInfo& item = thread_ret[i].second;
        double reco_score = item.ctr * std::pow(lr_score, (1 + FLAGS_tp_item_rank_lr_boost));
        if (item.time_level == reco::kGoodTimeliness) {
          reco_score *= (1 + FLAGS_tp_item_rank_good_timeliness_boost);
        }
        predict_ret->push_back(std::make_pair(reco_score, item));
      }
    }
    */
  }

  // sort
  VLOG(1) << "sort third party item lr results, uid=" << user_id << ", ret_size=" << predict_ret->size();
  std::sort(predict_ret->begin(), predict_ret->end(), std::greater<std::pair<double, ItemInfo> >());
}

// 冷启动 item (类别, tag, topic) 预测
// 输入: 基础属性 + 地域 + sm Profile + query history + ucb + taobao
void ThirdPartyReco::ItemLrPredict(const reco::user::UserInfo* user_info,
                                   const std::vector<ItemInfo>* item_vec,
                                   std::vector<std::pair<double, ItemInfo> >* thread_items) {
  if (thread_items == NULL) return;
  thread_items->clear();
  if (user_info == NULL) return;
  uint64 user_id = user_info->identity().user_id();
  if (item_vec == NULL) return;

  // 获取模型数据 (暂时从 global data 加载)
  //reco::ml::DenseHashLRModel* model = LeafDataManager::GetGlobalData()->tp_item_lr_model_;
  //if (model == NULL) return;

  auto lr_model_dict = DM_GET_DICT(reco::dm::LrModel, DynamicDictContainer::kThirdPartyItemLrModelFile_);
  const reco::ml::DenseHashLRModel* model = &lr_model_dict->lr_model_;
  if (model == NULL) return;

  // 抽取特征
  reco::ml::BaseFeatureExtractor* extractor = new reco::ml::ThirdPartyDataItemFeatureExtractor();
  extractor->SetupFeatureLayout();
  extractor->ResetUser(*user_info);

  std::vector<std::string> literal_fea_vec;
  std::vector<std::pair<double, std::string> > lr_scores;
  double sum_weight;
  int hits;
  double ctr;
  std::vector<std::string> hit_features;

  std::vector<std::string> categories;
  std::vector<std::string> tags;
  for (size_t i = 0; i < item_vec->size(); ++i) {
    const ItemInfo& item_info = item_vec->at(i);

    // 获取 item 信息
    uint64 item_id = item_info.item_id;
    categories.clear();
    if (!news_index_->GetCategoriesByItemId(item_id, &categories)) {
      LOG(WARNING) << "failed to get categories for item " << item_id;
      continue;
    }
    tags.clear();
    if (!news_index_->GetShowTagByItemId(item_id, &tags)) {
      LOG(WARNING) << "failed to get tags for item " << item_id;
      continue;
    }

    // item info 转化成 RecoItem
    reco::RecoItem item;
    item.mutable_identity()->set_item_id(item_id);
    for (size_t k = 0; k < categories.size(); ++k) {
      item.add_category(categories[k]);
    }
    reco::FeatureVector tag_fea_vec;
    tag_fea_vec.set_norm(1);
    for (size_t k = 0; k < tags.size(); ++k) {
      reco::Feature* fea = tag_fea_vec.add_feature();
      fea->set_literal(tags[k]);
      fea->set_weight(1);
    }
    item.mutable_tag()->CopyFrom(tag_fea_vec);

    // extract lr features
    literal_fea_vec.clear();
    extractor->ExtractUserItemFeature(item, &literal_fea_vec);
    if (literal_fea_vec.size() <= 1 + FLAGS_min_tp_item_lr_hit_fea_num) {
      VLOG(1) << "uid=" << user_id << ", item_id=" << item_id
              << ", lr_fea_num=" << literal_fea_vec.size() << ", skipped";
      continue;
    }

    // predict
    hit_features.clear();
    model->Predict(literal_fea_vec, &sum_weight, &hits, &ctr, &hit_features);
    VLOG(2) << "uid=" << user_id << ", item_id=" << item_id << ", lr_ctr=" << ctr
            << ", lr_fea=" << base::JoinStrings(literal_fea_vec, ",");

    thread_items->push_back(std::make_pair(ctr, item_vec->at(i)));
  }

  delete extractor;
}

void ThirdPartyReco::MergeComplexChannelRecoResults(
       std::map<std::string, std::vector<ItemInfo> >& cate_items_vec,
       const std::vector<std::pair<double, reco::Category> >* category_distribute,
       std::vector<ItemInfo>* ret_items,
       int req_num,
       RecoContext* context) {
  uint64 user_id = user_info_->identity().user_id();

  ret_items->clear();
  if (cate_items_vec_.empty() || req_num <= 0) {
    return;
  }

  // 1. 插入特殊途径产生的类别冷启动结果
  // TODO

  // 2. 插入各类目下的推荐结果
  double acc_weight = 0;
  for (size_t i = 0; i < category_distribute->size(); ++i) {
    acc_weight += category_distribute->at(i).first;
  }
  int cate_req_num = std::min(int(req_num - ret_items->size()), kNewsNumPerScreen);
  if (acc_weight < 1e-4 || cate_req_num <= 0) {
    return;
  }

  // 计算本批次推荐每个类别的下发数
  int acc_num = 0;
  std::vector<int> num_vec;
  num_vec.resize(cate_items_vec_.size());
  VLOG(1) << "num_vec.size = " << num_vec.size();
  for (size_t i = 0; i < category_distribute->size(); ++i) {
    std::string category = category_distribute->at(i).second.category();
    auto it = cate_items_vec.find(category);
    if (it == cate_items_vec.end()) {
      VLOG(2) << "no reco items for category " << category;
      num_vec[i] = 0;
      continue;
    }
    const std::vector<ItemInfo>& div_items = it->second;
    VLOG(1) << "uid=" << user_id << ", category=" << category
            << ", item_size=" << div_items.size() << ", category_ratio=" << category_distribute->at(i).first;

    if (div_items.empty()) continue;
    double ratio = (category_distribute->at(i).first / acc_weight) * cate_req_num;
    int num = (int)ratio;
    if (num >= (int)kMaxNumPerCate) {
      num = kMaxNumPerCate;
    } else if (random_->GetDouble() <= ratio - num) {
      ++num;
    }
    num_vec[i] = std::min(static_cast<int>(div_items.size()), num);
    acc_num += num_vec[i];

    VLOG(1) << "uid=" << user_id << ", category=" << category << ", cate_num=" << num_vec[i];
  }

  // 依次插入每个类目的结果
  for (int i = 0; i < (int)num_vec.size(); ++i) {
    if (num_vec[i] == 0) continue;
    const std::string category = category_distribute->at(i).second.category();
    const std::vector<ItemInfo> items = cate_items_vec[category];
    for (int j = 0; j < (int)num_vec[i] && j < (int)items.size(); ++j) {
      ret_items->push_back(items[j]);
    }
  }
}

// 根据系统负荷情况确定计算线程数
/*
int ThirdPartyReco::DecideCategoryRecoThread() {
  size_t concurrent_num = 1;
  switch (LeafDataManager::GetGlobalData()->sys_status) {
    case kSysFree:
    case kSysNormal:
      concurrent_num = 6;
      break;
    case kSysFull:
    case kSysBusy:
      concurrent_num = 3;
      break;
    case kSysDanger:
      concurrent_num = 2;
      break;
    default:
      break;
  }

  return concurrent_num;
}
*/

/*
int ThirdPartyReco::DecideItemPredictThread() {
  size_t concurrent_num = 1;
  switch (LeafDataManager::GetGlobalData()->sys_status) {
    case kSysFree:
    case kSysNormal:
      concurrent_num = 6;
      break;
    case kSysFull:
    case kSysBusy:
      concurrent_num = 3;
      break;
    case kSysDanger:
      concurrent_num = 2;
      break;
    default:
      break;
  }

  return concurrent_num;
}
*/

/*
int ThirdPartyReco::DecideItemPredictCandidateSize() {
  size_t candidate_num = 400;
  switch (LeafDataManager::GetGlobalData()->sys_status) {
    case kSysFree:
    case kSysNormal:
      candidate_num = 2000;
      break;
    case kSysFull:
    case kSysBusy:
      candidate_num = 1200;
      break;
    case kSysDanger:
      candidate_num = 600;
      break;
    default:
      break;
  }

  return candidate_num;
}
*/

std::string ThirdPartyReco::ConvertCategoryVectorToString(
    const std::vector<std::pair<double, reco::Category> >& categories){
  std::stringstream ss;
  for (auto it = categories.begin(); it != categories.end(); ++it) {
    ss << it->second.category() << ":" << it->first << ",";
  }
  return ss.str();
}

bool ThirdPartyReco::GetL1Category(const uint64 item_id, std::string* category) {
  tokens_.clear();
  category->clear();
  if (!news_index_->GetCategoriesByItemId(item_id, &tokens_)
      || tokens_.size() == 0u || tokens_[0].empty()) {
    return false;
  } else {
    category->assign(tokens_[0]);
    return true;
  }
}

void ThirdPartyReco::GetCachedCategories(
       const std::string& cache_key, int64 now_timestamp,
       std::vector<std::pair<double, reco::Category> >* category_distribute) {
  category_distribute->clear();
  // visit cache first
  std::string cache_value;
  if (!LeafCache::GetCachedReco(cache_key, &cache_value)) {
    VLOG(1) << cache_key << " cache missed";
    return;
  }
  std::vector<std::string> flds;
  base::SplitString(cache_value, ",", &flds);
  VLOG(1) << cache_key << " return " << flds.size() / 2 << " results";
  for (size_t i = 0; i + 1 < flds.size(); i += 2) {
    double lr_score;
    if (!base::StringToDouble(flds[i+1], &lr_score)) {
      continue;
    }
    reco::Category category;
    category.set_level(0);
    category.set_category(flds[i]);
    category_distribute->push_back(std::make_pair(lr_score, category));
    VLOG(1) << cache_key << " add " << category.category();
  }
}

void ThirdPartyReco::GetCachedItems(
       const std::string& cache_key, int64 now_timestamp,
       std::vector<ItemInfo>* cached_items) {
  cached_items->clear();
  // visit cache first
  std::string cache_value;
  if (!LeafCache::GetCachedReco(cache_key, &cache_value)) {
    VLOG(1) << cache_key << " cache missed";
    return;
  }
  std::vector<std::string> flds;
  base::SplitString(cache_value, ",", &flds);
  VLOG(1) << cache_key << " return " << flds.size() / 2 << " results";
  for (size_t i = 0; i + 1 < flds.size(); i += 2) {
    uint64 item_id;
    double lr_score;
    if (!base::StringToUint64(flds[i], &item_id)) {
      continue;
    }
    if (!base::StringToDouble(flds[i+1], &lr_score)) {
      continue;
    }
    reco::ItemInfo item;
    // 只需要重新判断 valid 即可
    if (!news_index_->GetItemInfoByItemId(item_id, &item, false)
        || !NewsFilter::ItemIsValid(item, now_timestamp)) {
      continue;
    }
    item.lr_score = (float)lr_score;

    cached_items->push_back(item);
    VLOG(2) << cache_key << " add " << item_id;
  }
}

void ThirdPartyReco::UserDedup(
       const RecoRequest* reco_request,
       std::vector<ItemInfo>* item_list,
       int64* filtered_num) {
  *filtered_num = 0;
  size_t idx = 0;
  for (size_t i = 0; i < item_list->size(); ++i) {
    uint64 item_id = (*item_list)[i].item_id;
    reco::filter::FilterReason filter_reason;
    if (NewsFilter::IsGeneralFiltered(reco_request, reco_request->shown_dict,
                                      (*item_list)[i], &filter_reason, false)) {
      ++(*filtered_num);
      VLOG(1) << item_id << " user dedup";
      continue;
    }
    if (idx != i) {
      (*item_list)[idx] = (*item_list)[i];
    }
    ++idx;
  }
  item_list->resize(idx);
}

}  // namespace reco_leaf
}
