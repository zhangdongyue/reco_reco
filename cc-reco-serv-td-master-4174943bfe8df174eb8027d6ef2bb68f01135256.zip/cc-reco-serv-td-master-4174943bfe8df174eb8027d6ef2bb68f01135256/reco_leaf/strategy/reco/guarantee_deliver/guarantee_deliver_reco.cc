#include "reco/serv/reco_leaf/strategy/reco/guarantee_deliver/guarantee_deliver_reco.h"

#include <string>
#include <utility>
#include <vector>

#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/reco_index/item_info.h"

namespace reco {
class NewsIndex;

namespace leafserver {

DEFINE_int32(guanrantee_deliver_max_candidate_num, 200, "");

GuaranteeDeliverReco::GuaranteeDeliverReco(const reco::NewsIndex* index) {
  news_index_ = index;
  candidates_extrator_ = new CandidatesExtractor(index);
  random_ = new base::PseudoRandom(base::GetTimestamp());
}

GuaranteeDeliverReco::~GuaranteeDeliverReco() {
  delete random_;
  delete candidates_extrator_;
}

void GuaranteeDeliverReco::GetGuaranteeDeliverItems(const RecoRequest& request,
                                                  std::vector<ItemInfo>* ret_items,
                                                  RecoDebugger* debugger) {
  serving_base::Timer timer;
  timer.Start();
  ret_items->clear();
  if (request.category_distributes->size() <= 0) return;
  std::vector<reco::Category> categories;
  if (request.channel_id == reco::common::kRecoChannelId) {
    for (size_t i = 0; i < request.category_distributes->size(); ++i) {
      categories.push_back(request.category_distributes->at(i).second);
    }
  } else {
    auto iter = LeafDataManager::GetGlobalData()->channel_categories.find(request.channel_id);
    if (iter == LeafDataManager::GetGlobalData()->channel_categories.end()) return;
    const std::vector<std::pair<std::string, float> >& multi_cates = iter->second;
    if (categories.size() <= 0) return;
    reco::Category category;
    category.set_level(0);
    category.set_category(multi_cates[0].first.substr(0, multi_cates[0].first.find('-')));
    categories.push_back(category);
  }
  std::vector<ItemInfo> candidates;
  std::vector<ItemInfo> cand_items;
  for (size_t i = 0; i < categories.size(); ++i) {
    candidates_extrator_->GetGuaranteeDeliverCandidates(&request, categories[i], &cand_items,
                                                        FLAGS_guanrantee_deliver_max_candidate_num, debugger);
    candidates.insert(candidates.end(), cand_items.begin(), cand_items.end());
  }

  if (candidates.size() <= 0) return;
  // 随机选一个
  size_t pos = random_->GetInt(0, candidates.size()- 1);
  ret_items->push_back(candidates[pos]);
  reco::dm::MediaQuantityInfo mqi;
  int64 item_limit = 0;
  if (news_index_->GetItemQuantityInfo(reco::kQueueDoc, ret_items->back(), &mqi, &item_limit)) {
    if (mqi.protect_type == reco::dm::kMediaDocManual) {
      ret_items->back().strategy_type = reco::kOperGuarantee;
    } else  if (mqi.protect_type == reco::dm::kMediaDocBeginner) {
      ret_items->back().strategy_type = reco::kNewMediaGuarantee;
    }
    ret_items->back().strategy_branch = reco::kGuaranteeDeliverInsertBranch;
  }
  VLOG(1) << "gd select candidates: " << ret_items->back().category
            << " " << candidates.size() << " " << pos
            << " " << ret_items->back().item_id << " "<< ret_items->back().strategy_type
            << " cid:" << request.channel_id
            << " time:" << timer.Stop();
}
}  // leafserver
}  // reco
