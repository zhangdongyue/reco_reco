#pragma once
#include <vector>

#include "base/random/pseudo_random.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

namespace reco {
class NewsIndex;

namespace leafserver {
class RecoRequest;

class GuaranteeDeliverReco {
 public:
  explicit GuaranteeDeliverReco(const reco::NewsIndex* index);

  ~GuaranteeDeliverReco();

  void GetGuaranteeDeliverItems(const RecoRequest& request,
                               std::vector<ItemInfo>* reco_items,
                               RecoDebugger* debugger);
 private:
  const NewsIndex* news_index_;
  CandidatesExtractor* candidates_extrator_;
  base::PseudoRandom* random_;
};
}  // namespace leafserver
}  // namespace reco

