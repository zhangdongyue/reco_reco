#include "reco/serv/reco_leaf/strategy/reco/query/query_reco.h"

#include <algorithm>

#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/common/item_level_define.h"

namespace reco {
namespace leafserver {

DEFINE_string(query_reco_machine_list, "11.140.18.231", "query推荐rpc ip");
DEFINE_int32(query_reco_per_timeout, 50 , "单个超时时间");
DEFINE_int32(query_reco_max_retry_times, 0, "重试次数");
DEFINE_int32(query_reco_total_timeout, 50, "总的超时时间");
DEFINE_int32(show_click_list_days_limit, 90, "截断x天内的show click数据");

void QueryRecoRpcComplete(thread::BlockingVar<bool>* rpc_complete) {
  rpc_complete->TryPut(true);
}

QueryReco::QueryReco(const reco::NewsIndex* index) : news_index_(index) {
  // item_dedup_.set_empty_key(NULL);
  // rpc设置
  serving_base::CommunicateConfig config("");
  config.file_name = FLAGS_query_reco_machine_list;
  config.timeout = FLAGS_query_reco_per_timeout;
  config.max_retry_times = FLAGS_query_reco_max_retry_times;
  config.enable_heart_beat = false;
  config.total_timeout = FLAGS_query_reco_total_timeout;
  config.enable_child_reload = false;
  qeury_reco_communicator_ = new QueryRecoCommunicator(config, &reco::queryreco::RecommendService::recommend);
  CHECK_NOTNULL(qeury_reco_communicator_);
  query_reco_rpc_conf_ = new QueryRecoCommunicator::RequestConfig();
  CHECK_NOTNULL(query_reco_rpc_conf_);
  query_reco_rpc_conf_->method = QueryRecoCommunicator::Random;
  query_reco_rpc_conf_->timeout = config.timeout;
  query_reco_rpc_conf_->total_timeout = config.total_timeout;
  query_reco_rpc_conf_->retry_times = config.max_retry_times;
  // rank
  query_ranker_ = new QueryRanker(news_index_);
  // risk_filter
  risk_media_rule_ = new reco::filter::RiskMediaRule();
}

QueryReco::~QueryReco() {
  if (qeury_reco_communicator_) {
    delete qeury_reco_communicator_;
    qeury_reco_communicator_ = NULL;
  }
  if (query_reco_rpc_conf_) {
    delete query_reco_rpc_conf_;
    query_reco_rpc_conf_ = NULL;
  }
  if (query_ranker_) {
    delete query_ranker_;
    query_ranker_ = NULL;
  }
}

void QueryReco::ConvertorViewClickItem(const reco::user::ViewClickItem& view_click_item,
                                       reco::queryreco::HistoryItem* history_item) const {
  history_item->set_item_id(view_click_item.item_id());
  history_item->set_item_type(view_click_item.item_type());
  history_item->set_click_timestamp(view_click_item.click_timestamp());
  history_item->set_view_timestamp(view_click_item.view_timestamp());
  history_item->set_view_duration(view_click_item.view_duration());
  history_item->set_strategy_branch(view_click_item.strategy_branch());
  history_item->set_reco_ext_info(view_click_item.reco_ext_info());
}

std::string QueryReco::CodeString(const std::string& orgi_string) const {
  return base::StringReplace(orgi_string, "\"", "\\\"", true);
}

std::string QueryReco::CreateExtInfo(const reco::queryreco::RecoResult& reco_result,
                                     int32 strategy_type) const {
  std::string json_res = "";
  return CodeString(reco_result.ext_info());
}

void QueryReco::GetComplexQueryNews(const RecoRequest* reco_request,
                                    std::vector<ItemInfo>* items, int max_return) const {
  serving_base::Timer timer;
  reco::queryreco::RecommendRequest request;
  // 构建请求
  const reco::leafserver::RecommendRequest* leaf_request = reco_request->request;
  const reco::user::UserInfo* user_info = reco_request->user_info;
  request.set_reco_id(leaf_request->reco_id());
  request.mutable_user()->CopyFrom(user_info->identity());
  request.set_return_num(max_return);
  base::Time current_time = base::Time::Now();
  for (int32 i = user_info->recent_click_size() - 1; i >= 0; --i) {
    base::Time show_time = base::Time::FromDoubleT(user_info->recent_click(i).click_timestamp());
    if ((current_time - show_time).InDays() > FLAGS_show_click_list_days_limit) break;
    reco::queryreco::HistoryItem* history_item = request.add_recent_click();
    ConvertorViewClickItem(user_info->recent_click(i), history_item);
  }
  for (int32 i = user_info->shown_history_size() - 1; i >= 0; --i) {
    base::Time show_time = base::Time::FromDoubleT(user_info->shown_history(i).view_timestamp());
    if ((current_time - show_time).InDays() > FLAGS_show_click_list_days_limit) break;
    reco::queryreco::HistoryItem* history_item = request.add_shown_history();
    ConvertorViewClickItem(user_info->shown_history(i), history_item);
  }
  // 场景化请求
  reco::queryreco::RequestParam request_param;
  request_param.set_request_type(reco::queryreco::kSceneReco);
  request.mutable_request_param()->CopyFrom(request_param);
  timer.Start();

  // rpc
  QueryRecoCommunicator::ResponseCollection resp_collect;
  thread::BlockingVar<bool> rpc_complete;
  qeury_reco_communicator_->RemoteCall(request,
                                       *query_reco_rpc_conf_,
                                       &resp_collect,
                                       NewCallback(&QueryRecoRpcComplete, &rpc_complete));
  rpc_complete.Take();
  LOG(INFO) << "query reco rpc time: " << timer.Stop() << ", user_id: " << user_info->identity().user_id();
  if (!resp_collect.success) {
    LOG(INFO) << "Query Reco Missing, user_id: " << user_info->identity().user_id();
    return;
  }
  // filter options
  reco::filter::Options filter_options;
  int32 candidate_type = kCandidateQuery;
  FillFilterOptions(&filter_options, candidate_type, reco_request);

  for (auto i = 0u; i < resp_collect.responses->size(); ++i) {
    if (resp_collect.responses->at(i)) {
      if (!resp_collect.responses->at(i)->success()) continue;
      const reco::queryreco::RecommendResponse* response = resp_collect.responses->at(i);
      int32 strategy_type = 0;
      if (response->has_strategy_type()) {
        strategy_type = response->strategy_type();
      }
      int32 filter_num = 0;
      for (int32 j = 0; j < response->result_size(); ++j) {
        ItemInfo item_info;
        const reco::queryreco::RecoResult& reco_result = response->result(j);
        if (!news_index_->GetItemInfoByItemId(reco_result.item_id(), &item_info, false)) {
          item_info.item_id = reco_result.item_id();
          item_info.doc_id = 1;
          item_info.item_type = reco_result.item_type();
          item_info.create_timestamp = reco_result.create_timestamp();
          if (reco_result.category_size() > 0) {
            item_info.category = reco_result.category(0);
          }
          if (reco_result.category_size() > 1) {
            item_info.sub_category = reco_result.category(1);
          }
          if (reco_result.has_show_num()) item_info.show_num = reco_result.show_num();
          if (reco_result.has_click_num()) item_info.click_num = reco_result.click_num();
          if (reco_result.click_num() > reco_result.show_num()) {
            LOG(INFO) << "item: " << item_info.item_id << "\t"
                      << "show_num: " << item_info.show_num << "\t"
                      << "click_num: " << item_info.click_num;
          }
        }
        item_info.strategy_branch = reco::kQueryRecoBranch;
        item_info.strategy_type = reco::kQueryReco;
        item_info.reco_ext_info = reco_result.ext_info();
        item_info.ir_word = reco_result.query();
        item_info.query_time = reco_result.query_time() * 1e3;
        item_info.source_media_sign = base::CalcTermSign(reco_result.source_media().c_str(),
                                                         reco_result.source_media().size());
        item_info.orig_source_media_sign = base::CalcTermSign(reco_result.orig_source_media().c_str(),
                                                              reco_result.orig_source_media().size());
        // filter
        reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
        if (Filter(reco_request, filter_options, item_info, reco_result, &filterno)) {
          LOG(INFO) << "item filter, item_id:" << item_info.item_id << ", reason:" << filterno;
          ++filter_num;
          continue;
        }
        items->push_back(item_info);
      }
      LOG(INFO) << "query reco rpc response size: " << response->result_size()
                << ", user_id:" << user_info->identity().user_id()
                << ", filter_num:" << filter_num
                << ", remain_num:" << items->size();
    }
  }
  query_ranker_->Rank(reco_request, items);
  if (items->size() == 0) {
    LOG(INFO) << "Query Reco Missing, user_id: " << user_info->identity().user_id();
  } else {
    LOG(INFO) << "Query Reco Success, user_id: " << user_info->identity().user_id();
  }
}

bool QueryReco::Filter(const RecoRequest* reco_request,const reco::filter::Options& options,
                       const ItemInfo& item,
                       const reco::queryreco::RecoResult& reco_result,
                       reco::filter::FilterReason* filterno) const {
  const FeatureVector& tag = reco_result.tag();
  const std::string& source = reco_result.source();
  // 推荐频道过滤历史和两性情感
  if (reco_request->channel_id == reco::common::kRecoChannelId) {
    if (item.category == "历史" || item.category == "两性情感") {
      *filterno = reco::filter::kChannelFiltered;
      return true;
    }
  }

  if (risk_media_rule_->Filter(options, item, filterno)) return true;
  if (DisLikeFilter(options, item, tag, source, filterno)) return true;
  if (SourceEnhanceFilter(options, item,source, filterno)) return true;
  return false;
}

void QueryReco::FillFilterOptions(reco::filter::Options* filter_options,
                                  int32 candidate_type, const RecoRequest* request) const {
  filter_options->Clear();
  // 规则清空
  filter_options->filter_subset = 0;
  filter_options->is_debug = false;

  filter_options->risk_media_dict
      = DM_GET_DICT(reco::filter::RiskMediaDict, reco::filter::DynamicDictContainer::kRiskMediaFile);
  filter_options->stream_filter = LeafDataManager::GetGlobalData()->stream_filter;

  // open risk media filter
  filter_options->filter_subset |= reco::filter::RiskMediaFilter;
  // open item filter
  filter_options->filter_subset |= reco::filter::ItemFilter;

  filter_options->do_video_filter = false;
  filter_options->do_news_filter = true;
  filter_options->do_video_risk_check = false;

  if (request != NULL) {
    // open user & session filter
    filter_options->filter_subset |= reco::filter::SessionFilter;
    filter_options->filter_subset |= reco::filter::AppTokenFilter;

    // 变量
    filter_options->shown_set = request->shown_dict;
    filter_options->user_feas = request->user_feas;
    filter_options->rule_chain = request->user_param_info.rule_chain;
    // GenReqBitForStreamFilter(request, &filter_options->req_bit);
    filter_options->channel_id = request->channel_id;
    filter_options->province = request->user_param_info.province;
    filter_options->city = request->user_param_info.city;
    filter_options->app_token = request->request->app_token();
    auto app_token_bit_index = DM_GET_DICT(reco::filter::AppTokenBitIndex,
                                             reco::filter::DynamicDictContainer::kAppTokenBitIndexFile);
    if (app_token_bit_index.get() != NULL) {
      auto iter = app_token_bit_index->app_token_bit_index.find(filter_options->app_token);
      if (iter != app_token_bit_index->app_token_bit_index.end()) {
        filter_options->app_token_idx = iter->second;
      }
    }
    // title
    if (request->request->has_filter_criterion()) {
      if (request->request->filter_criterion().title_min_len() > 0) {
        filter_options->title_min_len = request->request->filter_criterion().title_min_len();
      }
      if (request->request->filter_criterion().title_max_len() > 0) {
        filter_options->title_max_len = request->request->filter_criterion().title_max_len();
      }
    }
    filter_options->today_access_cnt = request->today_access_cnt;
    // flags
    filter_options->is_main_city = request->user_param_info.is_main_city;
    filter_options->is_new_user = request->user_param_info.is_new_user;
    filter_options->is_wsg_enc = request->user_param_info.wsg_enc;
    filter_options->is_loyal = request->user_param_info.is_loyal;
    filter_options->is_ios = request->user_param_info.is_ios;
    filter_options->is_inner_app = request->user_param_info.is_inner_qudao;
    filter_options->is_uc_iflow_app = request->user_param_info.is_uc_iflow_qudao;

    // filter switch
    filter_options->do_apprule_filter = true;

    filter_options->do_sensitive_filter = false;
    filter_options->do_sim_check_filter = true;

    filter_options->do_user_show_history_filter = true;
    filter_options->do_title_filter = false;
    filter_options->do_user_dislike_filter = true;
    filter_options->do_quality_dirty_filter = false;
    filter_options->do_valid_in_app_filter = true;
    filter_options->do_rule_chain_filter = true;

    filter_options->do_stream_filter = true;
    filter_options->do_first_n_screen_filter = true;
  }

  if (candidate_type == kCandidateChannelId) {
    filter_options->do_local_channel_filter = true;
  }

  if (candidate_type == kCandidateCrowdOper) {
    filter_options->do_item_valid_filter = true;
  }
}

}  // namespace reco_leaf
}
