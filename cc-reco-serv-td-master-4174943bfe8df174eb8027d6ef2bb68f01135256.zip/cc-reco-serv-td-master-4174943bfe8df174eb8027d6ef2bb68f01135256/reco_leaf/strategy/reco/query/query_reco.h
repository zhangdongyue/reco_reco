#pragma once

#include <string>
#include <vector>
#include <unordered_set>

#include "serving_base/rpc_communicator/remote_caller.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/query_ranker.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/proto/query_reco_server.pb.h"
#include "reco/bizc/filter_rule/online/component/risk_media_rule.h"

namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {
// Query推荐类：
// 1. 推荐频道的item吐出

typedef serving_base::RemoteCaller<reco::queryreco::RecommendService::Stub,
        reco::queryreco::RecommendRequest,
        reco::queryreco::RecommendResponse> QueryRecoCommunicator;

class QueryReco {
 public:
  explicit QueryReco(const reco::NewsIndex* index);
  ~QueryReco();

  // 根据query推荐的推荐接口
  // 推荐频道的热点文章推荐接口
  void GetComplexQueryNews(const RecoRequest* reco_request,
                           std::vector<ItemInfo>* items, int max_return) const;
 private:
  void ConvertorViewClickItem(const reco::user::ViewClickItem& view_click_item,
                              reco::queryreco::HistoryItem* history_item) const;
  std::string CreateExtInfo(const reco::queryreco::RecoResult& reco_result,
                            int32 strategy_type) const;
  std::string CodeString(const std::string& orgi_string) const;
  bool Filter(const RecoRequest* reco_request,
              const reco::filter::Options& options, const ItemInfo& item,
              const reco::queryreco::RecoResult& reco_result,
              reco::filter::FilterReason* filterno) const;
  void FillFilterOptions(reco::filter::Options* filter_options,
                         int32 candidate_type, const RecoRequest* request) const;
  bool DisLikeFilter(const reco::filter::Options& options, const ItemInfo& item,
                     const FeatureVector& tag, const std::string& source,
                     reco::filter::FilterReason* filterno) const;
  bool SourceEnhanceFilter(const reco::filter::Options& options, const ItemInfo& item,
                           const std::string& source,
                           reco::filter::FilterReason* filterno) const;
 private:
  QueryRecoCommunicator* qeury_reco_communicator_;
  QueryRecoCommunicator::RequestConfig* query_reco_rpc_conf_;
  const NewsIndex* news_index_;
  serving_base::Timer timer_;
  QueryRanker* query_ranker_;
  reco::filter::RiskMediaRule* risk_media_rule_;
};
// inline
inline bool QueryReco::DisLikeFilter(const reco::filter::Options& options, const ItemInfo& item,
                                     const FeatureVector& tag, const std::string& source,
                                     reco::filter::FilterReason* filterno) const {
  if (options.is_manual_reco) {
    return false;
  }

  if (options.user_feas == NULL) {
    return false;
  }
  // dislike subcategory
  static const std::unordered_set<int64> kFilterDislikeSubCateChannels
      = {::reco::common::kRecoChannelId, ::reco::common::kSportChannelId,
        ::reco::common::kScienceChannelId, ::reco::common::kFinanceChannelId};
  auto const& ref_dislike_subcates = options.user_feas->behavior_fea.dislike_sub_cates;
  int64 cid = options.channel_id;
  if (!ref_dislike_subcates.empty()
      && !item.sub_category.empty()
      && kFilterDislikeSubCateChannels.find(cid) != kFilterDislikeSubCateChannels.end()) {
    auto const iter = ref_dislike_subcates.find(item.sub_category);
    if (iter != ref_dislike_subcates.end() && iter->second >= 0.8) {
      *filterno = reco::filter::kFilterByDislike;
      return true;
    }
  }

  // dislike tag
  auto const& ref_dislike_tags = options.user_feas->behavior_fea.dislike_tags;
  if (!ref_dislike_tags.empty()) {
    std::vector<std::string> tag_flds;
    for (int i = 0; i < tag.feature_size(); ++i) {
      const ::reco::Feature& fea = tag.feature(i);
      tag_flds.clear();
      base::SplitString(fea.literal(), ":", &tag_flds);
      if (tag_flds.size() == 2u
          && ref_dislike_tags.find(tag_flds[1]) != ref_dislike_tags.end()) {
        *filterno = reco::filter::kFilterByDislike;
        return true;
      }
    }
  }

  // dislike source
  auto const& ref_dislike_sources = options.user_feas->behavior_fea.dislike_sources;
  if (cid != ::reco::common::kHumorPicChannelId
      && cid != ::reco::common::kHumorWordTouTiaoChannelId
      && !ref_dislike_sources.empty()) {
    if (ref_dislike_sources.find(source) != ref_dislike_sources.end()) {
      *filterno = reco::filter::kFilterByDislike;
      return true;
    }
  }

  return false;
}

inline bool QueryReco::SourceEnhanceFilter(const reco::filter::Options& options, const ItemInfo& item,
                                           const std::string& source,
                                           reco::filter::FilterReason* filterno) const {
  if (options.black_source == NULL) {
    return false;
  }
  if (options.is_unknown_city ||
      options.is_main_city) {
    if (options.is_ios) {
      if (options.black_source->Find(source)) {
        *filterno = reco::filter::kFilterByVideoSourceEnhanced;
        return true;
      }
    }
  }
  return false;
}


}
}

