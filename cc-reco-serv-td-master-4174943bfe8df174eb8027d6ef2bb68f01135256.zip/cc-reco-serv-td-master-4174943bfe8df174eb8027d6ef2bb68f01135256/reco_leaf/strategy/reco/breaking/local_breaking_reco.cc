#include "reco/serv/reco_leaf/strategy/reco/breaking/local_breaking_reco.h"

#include <string>
#include <vector>

#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/reco_index/item_info.h"

namespace reco {
class NewsIndex;

namespace leafserver {

LocalBreakingReco::LocalBreakingReco(const reco::NewsIndex* index) {
  news_index_ = index;
  candidates_extrator_ = new CandidatesExtractor(index);
}

LocalBreakingReco::~LocalBreakingReco() {
  delete candidates_extrator_;
}

void LocalBreakingReco::GetLocalBreakingItems(const RecoRequest& request,
                                  std::vector<ItemInfo>* ret_items,
                                  std::unordered_map<uint64, POITag>* item_poi_tags) {
  // item_poi_tags是跟POI分支共享的，所以这里不能clear
  ret_items->clear();
  candidates_extrator_->GetLocalBreakingCandidatesByCityId(
      request.user_feas->attr.city_id, &request, ret_items, 100);

  const std::string& city = request.request->uc_user_param().city();

  POITag poi_tag;
  poi_tag.set_id(request.user_feas->attr.city_id);
  poi_tag.set_poi_tag_type(POITag::kCityPOITag);
  poi_tag.set_literal(city + "本地");

  for (size_t i = 0; i < ret_items->size(); ++i) {
    ret_items->at(i).strategy_type = reco::kLocalBreakingEvent;
    ret_items->at(i).strategy_branch = reco::kLocalBreakingBranch;

    if (item_poi_tags->find(ret_items->at(i).item_id) == item_poi_tags->end()) {
      item_poi_tags->insert(std::make_pair(ret_items->at(i).item_id, poi_tag));
    }
  }
}

}  // leafserver
}  // reco
