#pragma once
#include <vector>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

namespace reco {
class NewsIndex;

namespace leafserver {
class RecoRequest;

class LocalBreakingReco {
 public:
  explicit LocalBreakingReco(const reco::NewsIndex* index);

  ~LocalBreakingReco();

  void GetLocalBreakingItems(const RecoRequest& request,
                             std::vector<ItemInfo>* reco_items,
                             std::unordered_map<uint64, POITag>* item_poi_tags);
 private:
  const NewsIndex* news_index_;
  CandidatesExtractor* candidates_extrator_;
};
}  // namespace leafserver
}  // namespace reco

