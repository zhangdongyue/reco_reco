#include "reco/serv/reco_leaf/strategy/reco/scene_card/scene_card_reco.h"

#include <algorithm>
#include <string>
#include <vector>
#include "base/strings/string_number_conversions.h"
#include "base/hash_function/city.h"
#include "base/strings/utf_char_iterator.h"
#include "nlp/common/nlp_util.h"

#include "serving_base/data_manager/data_manager.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/index_dict_manager.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;
using reco::user::ViewClickItem;

DEFINE_double(scene_card_deliver_pb, 1, "scene_card deliver probability");
DEFINE_bool(open_scene_card_debug_mode, false, "if open scene card debug mode");

const float SceneCardReco::kMinCtrThres = 0.001;

SceneCardReco::SceneCardReco() {
  news_index_ = LeafDataManager::GetGlobalData()->news_index;
  candidates_extractor_ = new CandidatesExtractor(news_index_);
  random_ = new base::PseudoRandom(base::GetTimestamp());
  item_dedup_.set_empty_key(NULL);
  reco_request_.personal_item_dicts = &personal_dict;
  category_channel_map_ = IndexDictManager::GetInstance()->GetCategoryChannelMap();
}

SceneCardReco::~SceneCardReco() {
  delete candidates_extractor_;
  delete random_;
}

bool SceneCardReco::GetSceneCardReco(
    const UserInfo* user_info,
    const SceneCardRecoRequest* request,
    const UserFeature * user_fea,
    const base::dense_hash_set<uint64>* show_dict,
    const std::vector<std::pair<float, reco::Category> >* category_distributes,
    SceneRecoResult* scene_result,
    CostTrace * cost_trace) {
  // 初始化
  user_fea_ = user_fea;
  user_info_ = user_info;
  card_request_ = request;
  shown_dict_ = show_dict;
  category_distributes_ = category_distributes;
  item_dedup_.clear();

  // 构建请求参数
  ConstructRecoRequest();

  // 计算场景子文
  std::vector<ItemInfo> sub_items;
  switch (card_request_->card_type()) {
    case kReadTimeSceneCard:
      ReadTimeSceneReco(&sub_items);
      break;
    case kMidNightSceneCard:
      MidNightSceneReco(&sub_items);
      break;
    case kWorkWaySceneCard:
      WorkWaySceneReco(&sub_items);
      break;
    case kWorkRestSceneCard:
      WorkRestSceneReco(&sub_items);
      break;
    case kMidDaySceneCard:
      MidDaySceneReco(&sub_items);
      break;
    default:
      DftSceneReco(&sub_items);
      break;
  }
  if (sub_items.size() < 2u) {
    LOG(WARNING) << "not meet items for scene reco, " << request->card_type();
    return false;
  }

  // DEBUG
  if (FLAGS_open_scene_card_debug_mode) {
    for (int i = 0; i <(int)sub_items.size(); ++i) {
      const ItemInfo& item = sub_items[i];
      std::string title;
      news_index_->GetItemTitleByDocId(item.doc_id, &title);
      LOG(INFO) << "DEBUG_RETURN, card_type:" << card_request_->card_type()
                << ", pos:" << i
                << ", itemid:" << item.item_id
                << ", timelevel:" << item.time_level
                << ", category:" << item.category
                << ", title:"<< title;
    }
  }

  // 计算 scene item
  uint64 scene_item_id = ComputeSceneCardItemId(request->card_type());
  RecoResult* scene_item = scene_result->mutable_scene_item();
  scene_item->set_item_id(scene_item_id);
  scene_item->set_outer_id(base::Uint64ToString(scene_item_id));
  scene_item->set_parent_id(scene_item_id);
  scene_item->set_item_type(reco::kSceneCard);
  scene_item->set_reco_id(request->reco_id());
  scene_result->set_card_type(request->card_type());

  for (int i = 0; i <(int)sub_items.size(); ++i) {
    if (scene_result->sub_items_size() >= (int)request->return_num()) break;
    const ItemInfo& item = sub_items.at(i);
    RecoResult * scene_sub_item = scene_result->add_sub_items();
    scene_sub_item->set_item_id(item.item_id);
    scene_sub_item->set_outer_id(base::Uint64ToString(item.item_id));
    scene_sub_item->set_parent_id(item.item_id);
    scene_sub_item->set_item_type(item.item_type);
    scene_sub_item->set_reco_id(request->reco_id());
  }
  LOG(INFO) << "return scene items, uid:" << user_info_->identity().user_id()
            << ", reco_id:" << request->reco_id()
            << ", " << nlp::util::NormalizeLine(scene_result->Utf8DebugString());

  return true;
}

bool SceneCardReco::IfQualifyForSceneCard(const SceneCardRecoRequest* request,
                                          const UserInfo* user_info) const {
  if (FLAGS_open_scene_card_debug_mode) return true;

  if (!(random_->GetDouble() < FLAGS_scene_card_deliver_pb)) return false;

  // 计算 item id
  SceneCardType scene_card_type = request->card_type();
  uint64 item_id = ComputeSceneCardItemId(scene_card_type);
  // 最近三天展现几条此种类型卡片
  base::Time current_time = base::Time::Now();
  base::Time expire_time = current_time - base::TimeDelta::FromHours(3 * 24);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int view_imcard_count = 0;
  for (int i = user_info->shown_history_size() - 1; i >= 0; --i) {
    const ViewClickItem& show_item = user_info->shown_history(i);
    if ((show_item.view_timestamp() < expire_timestamp)
        || view_imcard_count >= 3) break;
    if (show_item.item_id() == item_id) { 
      ++view_imcard_count;
    }
  }
  if (view_imcard_count < 3) return true;
  // 最近三次展示没有点击，就不下发
  for (int i = user_info->recent_click_size() -1; i >= 0; --i) {
    const ViewClickItem& click_item = user_info->recent_click(i);
    if (click_item.view_timestamp() < expire_timestamp) break;
    if (click_item.item_id() == item_id) return true;
  }

  return false;
}

bool SceneCardReco::ReadTimeSceneReco(std::vector<ItemInfo>* ret_items) {
  ret_items->clear();

  // 候选集 及 排序
  // 深度阅读只选择精品文章
  SetRequestChannel(reco::common::kJingpinChannelId);
  std::vector<ItemInfo> jingpin_items;
  candidates_extractor_->GetCandidatesByChannelId(reco::common::kJingpinChannelId, &reco_request_,
                                                  &jingpin_items, kCandidatesCutoff, NULL);
  float personal_power = CalcPersonalPower(user_fea_);
  for (size_t idx = 0; idx < jingpin_items.size(); ++idx) {
    ItemInfo& item = jingpin_items.at(idx);
    if (IsItemQualityFilter(item, kReadTimeSceneCard)) continue;
    if (IsItemImageFilter(item, kReadTimeSceneCard)) continue;
    float interest_score = CalcInterstScore(item, user_fea_, personal_power);
    float timelevel_boost = CalcTimeLevelScore(item);
    float reco_score = (item.ctr + kMinCtrThres) * interest_score * timelevel_boost;
    reco_score = std::min(1.0f, reco_score);
    item.reco_score = reco_score * kRecoScoreFactor;
  }
  std::sort(jingpin_items.begin(), jingpin_items.end(), std::greater<ItemInfo>());

  // 结果选取
  std::vector<const std::vector<ItemInfo>* > multi_item_matrix;
  multi_item_matrix.push_back(&jingpin_items);
  MultiResultMerge(multi_item_matrix, ret_items, card_request_->return_num() * 5);

  // 类别控制
  DoCategoryDiversity(ret_items, 3, card_request_->return_num());

  return true;
}

bool SceneCardReco::MidNightSceneReco(std::vector<ItemInfo>* ret_items) {
  ret_items->clear();

  // 两性 item
  SetRequestChannel(reco::common::kBoudoirChannelId);
  std::vector<ItemInfo> boudoir_items;
  candidates_extractor_->GetCandidatesByChannelId(reco::common::kBoudoirChannelId, &reco_request_,
                                                  &boudoir_items, kCandidatesCutoff, NULL);
  for (size_t idx = 0; idx < boudoir_items.size(); ++idx) {
    ItemInfo& item = boudoir_items.at(idx);
    if (IsItemQualityFilter(item, kMidNightSceneCard)) continue;
    if (IsItemImageFilter(item, kMidNightSceneCard)) continue;
    float timelevel_boost = CalcTimeLevelScore(item);
    float reco_score = (item.ctr + kMinCtrThres) * timelevel_boost;
    reco_score = std::min(1.0f, reco_score);
    item.reco_score = reco_score * kRecoScoreFactor;
  }
  std::sort(boudoir_items.begin(), boudoir_items.end(), std::greater<ItemInfo>());

  // 其他适合午夜出的 item
  std::vector<std::vector<ItemInfo>> item_matrix;
  std::vector<int64> channels;
  GetMidNightChannelIds(&channels);
  if (!channels.empty()) {
    item_matrix.resize(channels.size());
  }
  for (size_t idx = 0; idx < channels.size(); ++idx) {
    std::vector<ItemInfo>& items = item_matrix[idx];
    SetRequestChannel(channels[idx]);
    candidates_extractor_->GetCandidatesByChannelId(channels[idx], &reco_request_,
                                                    &items, kCandidatesCutoff, NULL);
    for (size_t jdx = 0; jdx < items.size(); ++jdx) {
      ItemInfo& item = items.at(jdx);
      if (IsItemQualityFilter(item, kMidNightSceneCard)) continue;
      if (IsItemImageFilter(item, kMidNightSceneCard)) continue;
      float timelevel_boost = CalcTimeLevelScore(item);
      float reco_score = (item.ctr + kMinCtrThres) * timelevel_boost;
      reco_score = std::min(1.0f, reco_score);
      item.reco_score = reco_score * kRecoScoreFactor;
    }
    std::sort(items.begin(), items.end(), std::greater<ItemInfo>());
  }
  // 合并
  std::vector<const std::vector<ItemInfo>* > multi_item_matrix;
  multi_item_matrix.push_back(&boudoir_items);
  for (size_t idx = 0; idx < item_matrix.size(); ++idx) {
    multi_item_matrix.push_back(&item_matrix[idx]);
  }
  MultiResultMerge(multi_item_matrix, ret_items, card_request_->return_num());

  return true;
}

bool SceneCardReco::WorkWaySceneReco(std::vector<ItemInfo>* ret_items) {
  ret_items->clear();

  // 热点文章
  SetRequestChannel(reco::common::kHotChannelId);
  std::vector<ItemInfo> hot_items;
  candidates_extractor_->GetCandidatesByChannelId(reco::common::kHotChannelId, &reco_request_,
                                                  &hot_items, kCandidatesCutoff, NULL);
  float personal_power = CalcPersonalPower(user_fea_);
  for (size_t idx = 0; idx < hot_items.size(); ++idx) {
    ItemInfo& item = hot_items.at(idx);
    if (IsItemQualityFilter(item, kMidNightSceneCard)) continue;
    if (IsItemImageFilter(item, kMidNightSceneCard)) continue;
    float interest_score = CalcInterstScore(item, user_fea_, personal_power / 2.0);
    float timelevel_boost = CalcTimeLevelScore(item);
    float reco_score = (item.ctr + kMinCtrThres) * (item.hot_level / 100.0 + kMinCtrThres)
        * timelevel_boost * interest_score;
    reco_score = std::min(1.0f, reco_score);
    item.reco_score = reco_score * kRecoScoreFactor;
  }
  std::sort(hot_items.begin(), hot_items.end(), std::greater<ItemInfo>());

  // 精品
  // 只要喜欢类别的精品
  std::unordered_set<std::string> remain_categories;
  GetUserPreferCategorySet(&remain_categories);
  std::vector<ItemInfo> jingpin_items;
  if (!remain_categories.empty()) {
    SetRequestChannel(reco::common::kJingpinChannelId);
    candidates_extractor_->GetCandidatesByChannelId(reco::common::kJingpinChannelId, &reco_request_,
                                                    &jingpin_items, kCandidatesCutoff, NULL);
    personal_power = CalcPersonalPower(user_fea_);
    for (size_t idx = 0; idx < jingpin_items.size(); ++idx) {
      ItemInfo& item = jingpin_items.at(idx);
      if (remain_categories.find(item.category) == remain_categories.end()) continue;
      if (IsItemQualityFilter(item, kReadTimeSceneCard)) continue;
      if (IsItemImageFilter(item, kReadTimeSceneCard)) continue;
      float interest_score = CalcInterstScore(item, user_fea_, personal_power);
      float timelevel_boost = CalcTimeLevelScore(item);
      float reco_score = (item.ctr + kMinCtrThres) * interest_score * timelevel_boost;
      reco_score = std::min(1.0f, reco_score);
      item.reco_score = reco_score * kRecoScoreFactor;
    }
    std::sort(jingpin_items.begin(), jingpin_items.end(), std::greater<ItemInfo>());
  }

  // 合并
  std::vector<const std::vector<ItemInfo>* > multi_item_matrix;
  multi_item_matrix.push_back(&hot_items);
  multi_item_matrix.push_back(&jingpin_items);
  MultiResultMerge(multi_item_matrix, ret_items, card_request_->return_num());

  return true;
}

bool SceneCardReco::MidDaySceneReco(std::vector<ItemInfo>* ret_items) {
  ret_items->clear();

  // 娱乐
  SetRequestChannel(reco::common::kHotChannelId);
  std::vector<ItemInfo> yule_items;
  candidates_extractor_->GetCandidatesByChannelId(reco::common::kEntertainmentChannelId, &reco_request_,
                                                  &yule_items, kCandidatesCutoff, NULL);
  for (size_t idx = 0; idx < yule_items.size(); ++idx) {
    ItemInfo& item = yule_items.at(idx);
    if (IsItemQualityFilter(item, kReadTimeSceneCard)) continue;
    if (IsItemImageFilter(item, kReadTimeSceneCard)) continue;
    float timelevel_boost = CalcTimeLevelScore(item);
    float reco_score = (item.ctr + kMinCtrThres) * timelevel_boost;
    reco_score = std::min(1.0f, reco_score);
    item.reco_score = reco_score * kRecoScoreFactor;
  }
  std::sort(yule_items.begin(), yule_items.end(), std::greater<ItemInfo>());

  // 其他适合午间出的 item
  std::vector<std::vector<ItemInfo>> item_matrix;
  std::vector<int64> channels;
  GetMidDayChannelIds(&channels);
  if (!channels.empty()) {
    item_matrix.resize(channels.size());
  }
  for (size_t idx = 0; idx < channels.size(); ++idx) {
    std::vector<ItemInfo>& items = item_matrix[idx];
    SetRequestChannel(channels[idx]);
    candidates_extractor_->GetCandidatesByChannelId(channels[idx], &reco_request_,
                                                    &items, kCandidatesCutoff, NULL);
    for (size_t jdx = 0; jdx < items.size(); ++jdx) {
      ItemInfo& item = items.at(jdx);
      if (IsItemQualityFilter(item, kMidNightSceneCard)) continue;
      if (IsItemImageFilter(item, kMidNightSceneCard)) continue;
      float timelevel_boost = CalcTimeLevelScore(item);
      float reco_score = (item.ctr + kMinCtrThres) * timelevel_boost;
      reco_score = std::min(1.0f, reco_score);
      item.reco_score = reco_score * kRecoScoreFactor;
    }
    std::sort(items.begin(), items.end(), std::greater<ItemInfo>());
  }
  // 合并
  std::vector<const std::vector<ItemInfo>* > multi_item_matrix;
  multi_item_matrix.push_back(&yule_items);
  for (size_t idx = 0; idx < item_matrix.size(); ++idx) {
    multi_item_matrix.push_back(&item_matrix[idx]);
  }
  MultiResultMerge(multi_item_matrix, ret_items, card_request_->return_num());

  return true;
}

bool SceneCardReco::WorkRestSceneReco(std::vector<ItemInfo>* ret_items) {
  ret_items->clear();

  return MidDaySceneReco(ret_items);
}

bool SceneCardReco::DftSceneReco(std::vector<ItemInfo>* ret_items) {
  return true;
}

uint64 SceneCardReco::ComputeSceneCardItemId(SceneCardType card_type) const {
  const std::string& str = base::StringPrintf("itemtype:%d\tscene_card_type:%d",
                                              reco::kSceneCard, card_type);
  uint64 item_id = base::CityHash64(str.c_str(), str.size());
  return item_id;
}

bool SceneCardReco::CanAddToResultSet(const ItemInfo& item) {
  if (!NewsFilter::ItemIsValid(item, reco_request_.current_timestamp)) return false;
  if (NewsFilter::IsDeduped(item, &item_dedup_)) return false;
  return true;
}


inline float SceneCardReco::CalcPersonalPower(const UserFeature* user_fea) const {
  float total_click = user_fea->merged_info.total_click_num;
  float power = 0;
  if (total_click >= 50) {
    power = 3;
  } else if (total_click >= 30) {
    power = 2 + (total_click - 30) * 0.05;
  } else if (total_click >= 10) {
    power = 1 + (total_click - 10) * 0.05;
  } else {
    power = total_click / 10.0;
  }
  return power;
}

inline float SceneCardReco::CalcInterstScore(const ItemInfo& item,
                                             const UserFeature* user_fea, float power) const {
  float l1_boost = 1;
  float l2_boost = 1;
  const auto& ref_l1_cates = user_fea->merged_fea.l1_cates;
  const auto& ref_l2_cates = user_fea->merged_fea.l2_cates;
  const auto l1_iter = ref_l1_cates.find(item.category);
  bool need_l2 = false;
  if (l1_iter != ref_l1_cates.end()) {
    l1_boost = std::pow((1+ l1_iter->second), power);
    need_l2 = l1_iter->second >= 0.3;
  }
  if (need_l2 && !item.sub_category.empty()) {
    const auto iter = ref_l2_cates.find(item.category);
    if (iter != ref_l2_cates.end()) {
      const FeaKeyVal& l2_cates = iter->second;
      const auto l2_iter = l2_cates.find(item.sub_category);
      if (l2_iter != l2_cates.end()) {
        l2_boost = 1 + l2_iter->second;
      }
    }
  }
  return l1_boost * l2_boost;
}

inline float SceneCardReco::CalcTimeLevelScore(const ItemInfo& item) const {
  float boost = 1;
  if (item.time_level <= reco::kBadTimeliness) {
    boost = 0.1;
  } else if (item.time_level <= reco::kMidTimeliness) {
    boost = 0.2;
  }
  return boost;
}

inline void SceneCardReco::ConstructRecoRequest() {
  common_request_.set_reco_id(card_request_->reco_id());
  common_request_.set_app_token(card_request_->app_token());
  common_request_.mutable_user()->CopyFrom(user_info_->identity());
  common_request_.set_return_num(card_request_->return_num());
  common_request_.set_channel_id(reco::common::kRecoChannelId);

  reco_request_.Reset(&common_request_, user_info_, user_fea_, shown_dict_, category_distributes_);
}

inline void SceneCardReco::SetRequestChannel(int64 channel_id) {
  common_request_.set_channel_id(reco::common::kRecoChannelId);
  reco_request_.channel_id = channel_id;
}

void SceneCardReco::MultiResultMerge(const std::vector<const std::vector<ItemInfo>* >& multi_items,
                                     std::vector<ItemInfo>* ret_items, int ret_num) {
  ret_items->clear();
  if (multi_items.empty()) return;
  // 多路 merge
  // pos_vec 记录 multi_items 待取的下标
  std::vector<size_t> pos_vec(multi_items.size(), 0);
  while (1) {
    if ((int)ret_items->size() >= ret_num) break;
    // 是否全部取完
    bool take_over = true;
    for (size_t idx = 0; idx < pos_vec.size(); ++idx) {
      size_t pos = pos_vec.at(idx);
      if (pos < multi_items[idx]->size()) {
        take_over = false;
        break;
      }
    }
    if (take_over) break;
    // 按照顺序交叉加入各条队列的结果
    for (size_t idx = 0; idx < pos_vec.size(); ++idx) {
      int add_item = 0;
      while (pos_vec[idx] < multi_items[idx]->size()) {
        const ItemInfo& item= multi_items[idx]->at(pos_vec[idx]);
        ++pos_vec[idx];
        if (CanAddToResultSet(item)) {
          ret_items->push_back(item);
          ++add_item;
        }
        // 暂定最多两条排在一起
        if (add_item >= 2) break;
      }
    }
  }

  if ((int)ret_items->size() > ret_num) {
    ret_items->resize(ret_num);
  }
}

void SceneCardReco::DoCategoryDiversity(std::vector<ItemInfo>* ret_items,
                                        int max_category_item, int max_ret) {
  std::vector<ItemInfo> swap_items;
  std::vector<size_t> filter_idx_vec;
  base::dense_hash_map<std::string, int> category_num_map;
  category_num_map.set_empty_key("");
  for (size_t idx = 0; idx < ret_items->size(); ++idx) {
    if ((int)swap_items.size() >= max_ret) break;
    const ItemInfo& item = ret_items->at(idx);
    const std::string& category = item.category;
    auto iter = category_num_map.find(category);
    if (iter != category_num_map.end()) {
      if (iter->second >= max_category_item) {
        filter_idx_vec.push_back(idx);
        continue;
      }
      ++iter->second;
    } else {
      category_num_map.insert(std::make_pair(category, 1));
    }
    swap_items.push_back(item);
  }
  for (size_t idx = 0; idx < filter_idx_vec.size(); ++idx) {
    if ((int)swap_items.size() >= max_ret) break;
    size_t pos = filter_idx_vec[idx];
    const ItemInfo& item = ret_items->at(pos);
    swap_items.push_back(item);
  }

  ret_items->swap(swap_items);
}

inline bool SceneCardReco::IsItemQualityFilter(const ItemInfo& item, SceneCardType card_type) const {
  // 数据表现
  std::string wemedia;
  if (!news_index_->GetWeMediaPersonByDocId(item.doc_id, &wemedia)) {
    wemedia.clear();
  }
  const int kShowThres = wemedia.empty() ? 2000 : 60000;
  const float kCtrThres = 0.02;
  if (item.show_num < kShowThres || item.ctr < kCtrThres) return true;

  // title 长度
  std::string title;
  if (!news_index_->GetItemTitleByDocId(item.doc_id, &title)) {
    return true;
  }
  int char_num = 0;
  if (!base::GetUTF8CharNum(title, &char_num) || char_num < 13) {
    return true;
  }

  // 低质识别
  bool is_trival = true;
  reco::ContentAttr attr;
  if (!news_index_->GetContentAttrByDocId(item.doc_id, &attr, &is_trival) || is_trival) {
    return false;
  }
  // 文不对题
  if (attr.has_erro_title() && attr.erro_title() >= reco::ContentAttr::kSuspect) {
    return true;
  }
  // 广告
  if (attr.has_advertorial() && attr.advertorial() >= reco::ContentAttr::kSuspect) {
    return true;
  }
  // 空短
  if (attr.has_short_content() && attr.short_content() >= reco::ContentAttr::kSuspect) {
    return true;
  }
  // 堆砌
  if (attr.has_dedup_paragraph() && attr.dedup_paragraph() >= reco::ContentAttr::kSuspect) {
    return true;
  }
  // 标题党
  if (attr.has_bluffing_title() && attr.bluffing_title() >= reco::ContentAttr::kSuspect) {
    return true;
  }
  // 低俗
  if (card_type != kMidNightSceneCard
      && attr.has_dirty() && attr.dirty() >= reco::ContentAttr::kSuspect) {
    return true;
  }
  return false;
}

inline bool SceneCardReco::IsItemImageFilter(const ItemInfo& item, SceneCardType card_type) const {
  if (card_type == kWorkRestSceneCard) return false;
  int image_count = news_index_->GetImageCountByDocId(item.doc_id);
  if (image_count <= 0 || image_count >= 250) {
    return true;
  }
  return false;
}

inline std::string SceneCardReco::GetUserGender(const UserInfo& user) const {
  if (!user.has_ali_profile()) return "U";
  const reco::user::AliProfile& ali_profile = user.ali_profile();
  if (!ali_profile.has_gp_gender()) return "U";
  return ali_profile.gp_gender();
}

void SceneCardReco::GetMidDayChannelIds(std::vector<int64>* channels) const {
  channels->clear();

  std::vector<std::string> prefer_categories;
  GetUserPreferCategoryVec(&prefer_categories);
  for (size_t idx = 0; idx != prefer_categories.size(); ++idx) {
    if (category_channel_map_ == NULL) break;
    const std::string& category = prefer_categories[idx];
    if (category == "娱乐") continue;
    const auto iter = category_channel_map_->find(category);
    if (iter != category_channel_map_->end()) {
      channels->push_back(iter->second);
    }
  }

  if (!channels->empty()) return;

  const std::string& gender = GetUserGender(*user_info_);
  if (gender == "M") {
    // 汽车
    channels->push_back(323644874);
    // 体育
    channels->push_back(923258246);
    // 财经
    channels->push_back(26325229);
    // 军事
    channels->push_back(1105405272);

  } else if (gender == "F") {
    // 星座
    channels->push_back(26325229);
    // 时尚
    channels->push_back(1213442674);
    // 干货
    channels->push_back(reco::common::kGanhuoChannelId);

  } else if (gender == "U") {
    // 干货
    channels->push_back(reco::common::kGanhuoChannelId);
    // 汽车
    channels->push_back(323644874);
    // 星座
    channels->push_back(26325229);
  }
}

void SceneCardReco::GetMidNightChannelIds(std::vector<int64>* channels) const {
  channels->clear();

  const std::string& gender = GetUserGender(*user_info_);
  if (gender == "M") {
    // 男生是美女图片
    channels->push_back(reco::common::kGirlChannelId);
  } else if (gender == "F") {
    // 女生是星座和娱乐
    channels->push_back(179223212);
    channels->push_back(10008);
  } else if (gender == "U") {
    // 未知, 根据 profile 合适的类别
    std::unordered_set<std::string> prefer_categories;
    GetUserPreferCategorySet(&prefer_categories);
    if (prefer_categories.find("美女写真") != prefer_categories.end()) {
      channels->push_back(reco::common::kGirlChannelId);
    }
    if (prefer_categories.find("娱乐") != prefer_categories.end()) {
      channels->push_back(179223212);
    }
    if (prefer_categories.find("星座") != prefer_categories.end()) {
      channels->push_back(10008);
    }
    if (prefer_categories.find("历史") != prefer_categories.end()) {
      channels->push_back(701104723);
    }
    if (prefer_categories.find("军事") != prefer_categories.end()) {
      channels->push_back(1105405272);
    }
    if (channels->empty()) {
      channels->push_back(reco::common::kGirlChannelId);
      // 星座和娱乐
      channels->push_back(10008);
      channels->push_back(179223212);
    }
  }
}

void SceneCardReco::GetUserPreferCategoryVec(std::vector<std::string>* prefer_categories) const {
  prefer_categories->clear();
  if (user_fea_->lt_fea.click_num < 20) return;

  std::vector<std::pair<float, std::string> > tmp_vec;
  const auto& ref_l1_cates = user_fea_->merged_fea.l1_cates;
  for (auto iter = ref_l1_cates.begin(); iter != ref_l1_cates.end(); ++iter) {
    tmp_vec.push_back(std::make_pair(iter->second, iter->first));
  }
  std::sort(tmp_vec.begin(), tmp_vec.end(), std::greater<std::pair<float, std::string> >());
  for (size_t idx = 0; idx < 3 && idx < tmp_vec.size(); ++idx) {
    if (tmp_vec.at(idx).first < 0.1) break;
    prefer_categories->push_back(tmp_vec.at(idx).second);
  }
}

void SceneCardReco::GetUserPreferCategorySet(std::unordered_set<std::string>* prefer_categories) const {
  prefer_categories->clear();

  std::vector<std::string> vec;
  GetUserPreferCategoryVec(&vec);

  prefer_categories->insert(vec.begin(), vec.end());
}

}  // namespace reco_leaf
}
