#pragma once

#include <string>
#include <vector>
#include "base/random/pseudo_random.h"
#include "base/time/time.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"
namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {
class SceneCardReco {
 public:
  explicit SceneCardReco();
  ~SceneCardReco();

  // 1. 判断此次 推荐频道页的请求 是否返回 scene card
  bool IfQualifyForSceneCard(const SceneCardRecoRequest *request,
                             const reco::user::UserInfo* user_info) const;

  // 2. 返回 SceneCard 的结果
  bool GetSceneCardReco(const reco::user::UserInfo* user_info,
                        const SceneCardRecoRequest* request,
                        const UserFeature* user_fea,
                        const base::dense_hash_set<uint64>* show_dict,
                        const std::vector<std::pair<float, reco::Category> >* category_distributes,
                        SceneRecoResult* scene_result,
                        CostTrace * cost_trace);

 private:
  uint64 ComputeSceneCardItemId(SceneCardType card_type) const;
  bool ReadTimeSceneReco(std::vector<ItemInfo>* ret_items);
  bool MidNightSceneReco(std::vector<ItemInfo>* ret_items);
  bool WorkWaySceneReco(std::vector<ItemInfo>* ret_items);
  bool WorkRestSceneReco(std::vector<ItemInfo>* ret_items);
  bool MidDaySceneReco(std::vector<ItemInfo>* ret_items);
  bool DftSceneReco(std::vector<ItemInfo>* ret_items);
  bool CanAddToResultSet(const ItemInfo& item);
  void ConstructRecoRequest();
  void SetRequestChannel(int64 channel_id);
  float CalcPersonalPower(const UserFeature* user_fea) const;
  float CalcInterstScore(const ItemInfo& item, const UserFeature* user_fea, float power) const;
  float CalcTimeLevelScore(const ItemInfo& item) const;
  void MultiResultMerge(const std::vector<const std::vector<ItemInfo>* >& multi_items,
                        std::vector<ItemInfo>* ret_items, int max_ret);
  void DoCategoryDiversity(std::vector<ItemInfo>* ret_items, int max_category_item, int max_ret);
  bool IsItemQualityFilter(const ItemInfo& item, SceneCardType card_type) const;
  bool IsItemImageFilter(const ItemInfo& item, SceneCardType card_type) const;
  void GetMidNightChannelIds(std::vector<int64>* channels) const;
  void GetMidDayChannelIds(std::vector<int64>* channels) const;
  // M : F : U
  std::string  GetUserGender(const reco::user::UserInfo& user) const;
  void GetUserPreferCategorySet(std::unordered_set<std::string>* prefer_categories) const;
  void GetUserPreferCategoryVec(std::vector<std::string>* prefer_categories) const;

 private:
  static const int kRecoScoreFactor = 1000000;
  static const int kCandidatesCutoff = 2000;
  static const float kMinCtrThres;

  const UserFeature* user_fea_;
  const reco::user::UserInfo* user_info_;
  const SceneCardRecoRequest* card_request_;
  const base::dense_hash_set<uint64>* shown_dict_;
  const std::vector<std::pair<float, reco::Category> >* category_distributes_;
  RecoRequest reco_request_;
  RecommendRequest common_request_;

  base::dense_hash_set<uint64> item_dedup_;

  std::unordered_map<uint64, ItemDictData> personal_dict;

  const base::dense_hash_map<std::string, int64>* category_channel_map_;

  const NewsIndex* news_index_;
  CandidatesExtractor* candidates_extractor_;
  base::PseudoRandom* random_;
};


}
}

