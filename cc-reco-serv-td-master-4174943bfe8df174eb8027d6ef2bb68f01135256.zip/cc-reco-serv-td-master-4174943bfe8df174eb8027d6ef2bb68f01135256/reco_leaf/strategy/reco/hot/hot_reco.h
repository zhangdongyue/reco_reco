#pragma once

#include <string>
#include <vector>
#include <unordered_set>

#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/hot_ranker.h"
#include "reco/bizc/reco_index/item_info.h"

namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {
// 热点推荐类：
// 1. 热点频道下发策略；
// 2. 推荐频道热点的吐出
// 3. 指定垂直频道的热点的吐出
// 4. 指定类别的热点的吐出
// 5. 推荐频道热点视频的吐出(待遗弃)
// 6. 垂直频道热点视频的吐出(待遗弃)
//
// NOTE(Jianhuang) 暂时放在一个 class 里面，待策略复杂后再行拆解
//
class HotReco {
 public:
  explicit HotReco(const reco::NewsIndex* index);
  ~HotReco();

  // 热点频道的推荐接口
  // TODO(jianhuang) 待实现
  void DoHotChannelReco(const RecoRequest* reco_request, const ManualRecoData* manual_data,
                        std::vector<ItemInfo>* hot_items, RecoContext* context);

  // 综合频道的热点文章推荐接口
  void GetComplexHotNews(const RecoRequest* reco_request,
                         std::vector<ItemInfo>* hot_items, int max_return) const;

  // 垂直频道的热点文章推荐接口
  // TODO(Jianhuang) 待实现
  void GetVerticleHotNews(const RecoRequest* reco_request, int64 cid,
                          std::vector<ItemInfo>* hot_items, int max_return) const {}

  // 指定类别的热点文章推荐接口
  // TODO(Jianhuang) 待实现
  void GetCategoryHotNews(const RecoRequest* reco_request, const std::string& category,
                          std::vector<ItemInfo>* hot_items, int max_return) const {}

  // 综合频道的热点视频推荐接口
  void GetComplexHotVideos(const RecoRequest* reco_request,
                           std::vector<ItemInfo> *ret_items, int max_return) const;

  // 垂直频道的热点视频推荐接口
  void GetVerticleHotVideos(const RecoRequest* reco_request, int64 cid,
                           std::vector<ItemInfo> *ret_items, int max_return, float ctr_thr) const;

 private:
  static const uint32 kTopN = 500;
  static const std::unordered_set<std::string> kEnableHotVideoCategories;
  static const std::unordered_set<std::string> kEnableHotNewsCategories;
  static const std::unordered_set<int64> kEnableHotVideoChannels;
  static const std::unordered_set<int64> kDisableHotNewsChannels;

  const NewsIndex* news_index_;

  HotRanker* hot_ranker_;
  CandidatesExtractor* candidates_extractor_;

  serving_base::Timer timer_;
  base::dense_hash_set<uint64> item_dedup_;
};

}
}

