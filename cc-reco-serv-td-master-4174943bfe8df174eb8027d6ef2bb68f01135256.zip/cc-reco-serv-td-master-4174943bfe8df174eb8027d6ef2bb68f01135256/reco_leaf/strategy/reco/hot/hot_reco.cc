#include "reco/serv/reco_leaf/strategy/reco/hot/hot_reco.h"

#include <algorithm>

#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/common/item_level_define.h"

namespace reco {
namespace leafserver {

static std::unordered_set<int64> getEnableHotVideoChannels() {
  std::unordered_set<int64> channels = {
    reco::common::kSportChannelId,
    reco::common::kEntertainmentChannelId,
    reco::common::kMilitaryChannelId,
  };
  return channels;
}
static std::unordered_set<int64> getDisableHotNewsChannels() {
  // TODO(jiawei or jianhuang) 填充不适合出 hot news 的 channels
  std::unordered_set<int64> channels = {};
  return channels;
}
const std::unordered_set<std::string> HotReco::kEnableHotVideoCategories = {
  "娱乐", "体育", "军事",
};
const std::unordered_set<std::string> HotReco::kEnableHotNewsCategories = {
  "娱乐", "体育", "社会", "财经", "科技", "汽车", "军事", "国际", "时尚", "游戏", "房产", "教育",
};
const std::unordered_set<int64> HotReco::kEnableHotVideoChannels = getEnableHotVideoChannels();
const std::unordered_set<int64> HotReco::kDisableHotNewsChannels = getDisableHotNewsChannels();


HotReco::HotReco(const reco::NewsIndex* index) : news_index_(index) {
  candidates_extractor_ = new CandidatesExtractor(news_index_);
  hot_ranker_ = new HotRanker(news_index_);
  item_dedup_.set_empty_key(NULL);
}

HotReco::~HotReco() {
  delete candidates_extractor_;
  delete hot_ranker_;
}

void HotReco::DoHotChannelReco(const RecoRequest* reco_request, const ManualRecoData* manual_data,
                               std::vector<ItemInfo>* hot_items, RecoContext* context) {
  if (reco_request->channel_id != reco::common::kHotChannelId) return;

  // std::string recoid = reco_request->request->reco_id();
  // uint64 uid = reco_request->user_info->identity().user_id();

  item_dedup_.clear();

  // 获取候选集
  timer_.Start();
  static const int kMaxHotCandidateNum = 20000;
  std::vector<ItemInfo> candidate_items;
  candidates_extractor_->GetCandidatesByChannelId(reco_request->channel_id, reco_request, &candidate_items,
                                                  kMaxHotCandidateNum, context->debugger());
  context->debugger()->TraceCategoryCandidateItems(candidate_items);

  // 跳过触发，直接进入排序环节
  std::vector<ItemInfo>& rank_items = candidate_items;
  hot_ranker_->Rank(reco_request, &rank_items);
  context->debugger()->TraceAfterCategoryRankItems(rank_items);

  // 插入运营结果
  std::vector<ItemInfo> merged_items;
  for (size_t i = 0; i < manual_data->personal_items.size(); ++i) {
    if (merged_items.size() >= kTopN) break;
    const ItemInfo& item = manual_data->personal_items.at(i);
    if (!NewsFilter::IsDeduped(item, &item_dedup_)) {
      merged_items.push_back(item);
    }
  }
  // 插入机器结果
  for (size_t i = 0; i < rank_items.size(); ++i) {
    if (merged_items.size() >= kTopN) break;
    const ItemInfo& item = rank_items.at(i);
    if (!NewsFilter::IsDeduped(item, &item_dedup_)) {
      merged_items.push_back(item);
    }
  }

  // 同一屏去重
  int remain_size = std::min((int)rank_items.size(), 150);
  NewsFilter::DiversityFilter(reco_request->request, reco_request->user_info,
                              reco_request->user_feas, merged_items, "",
                              remain_size, hot_items);

  context->debugger()->TraceAfterDiversityFilterItems(*hot_items);
  context->cost_trace()->rks = timer_.Stop();
}

void HotReco::GetComplexHotNews(const RecoRequest* reco_request,
                                std::vector<ItemInfo>* hot_items, int max_return) const {
  hot_items->clear();
  std::vector<ItemInfo> candidate_items;
  candidates_extractor_->GetCandidatesByChannelId(reco::common::kHotChannelId, reco_request,
                                                  &candidate_items, kTopN, NULL);
  for (int i = 0; i < (int)candidate_items.size(); ++i) {
    const ItemInfo& item = candidate_items[i];
    if ((int)hot_items->size() >= max_return) break;
    if (item.hot_level < reco::item_level::kMidHotScoreThres) continue;
    hot_items->push_back(item);
  }

  // LOG(INFO) << "get top hot news candidate num, " << hot_items->size();
}

void HotReco::GetComplexHotVideos(const RecoRequest* reco_request,
                                  std::vector<ItemInfo> *ret_items, int max_return) const {
  ret_items->clear();

  // candidates from index
  const std::vector<ItemInfo>* candidate_items = NULL;
  candidate_items = news_index_->GetDefaultReco(reco::common::kRecoChannelId, -1, true);
  if (candidate_items == NULL) {
    LOG(ERROR) << "news has no such channel, chanel id is: " << reco::common::kRecoChannelId;
    return;
  }

  const UserFeature* user_feas = reco_request->user_feas;
  const auto& confidence_l1_cates = user_feas->merged_fea.confidence_l1_cates;
  int ctr_filter_count = 0;
  int general_filter_count = 0;
  int personal_filter_count = 0;
  int other_filter_count = 0;

  // get top hot items
  for (int i = 0; i < (int)candidate_items->size(); ++i) {
    const ItemInfo& item = (*candidate_items)[i];
    VLOG(1) << "item_id: " << item.item_id << " time_level: " << item.time_level;
    if ((int)ret_items->size() >= max_return) {
      VLOG(1) << "ret_items size > max_return";
      break;
    }
    static const float kVideoCtrThr = 0.08;
    if (item.ctr < kVideoCtrThr) {
      ++ctr_filter_count;
      continue;
    }
    reco::filter::FilterReason filter_reason;
    if (NewsFilter::IsGeneralFiltered(reco_request, reco_request->shown_dict,
                                      item, &filter_reason)) {
      ++general_filter_count;
      continue;
    }

    if (kEnableHotVideoCategories.find(item.category) != kEnableHotVideoCategories.end()) {
      if (confidence_l1_cates.find(item.category) == confidence_l1_cates.end()) {
        ++personal_filter_count;
        continue;
      }
      ret_items->push_back(item);
      continue;
    }
    ++other_filter_count;
  }
  std::sort(ret_items->begin(), ret_items->end(), std::greater<ItemInfo>());
  LOG(INFO) << base::StringPrintf("get top hot video success. [return: %lu]"
                                  "[filter: ctr %d, general %d, personal %d, other %d]", ret_items->size(),
                                  ctr_filter_count, general_filter_count, personal_filter_count,
                                  other_filter_count);
}


void HotReco::GetVerticleHotVideos(const RecoRequest* reco_request, int64 cid,
                                   std::vector<ItemInfo> *ret_items, int max_return, float ctr_thr) const {
  // 必须在这几个频道内，才出机器视频
  if (kEnableHotVideoChannels.find(cid) == kEnableHotVideoChannels.end()) {
    return;
  }

  // candidates from index
  std::vector<ItemInfo> candidate_items;
  bool only_video = true;
  candidates_extractor_->GetCandidatesByChannelId(cid, reco_request,
                                                  &candidate_items, max_return, NULL, only_video);
  VLOG(1) << "get raw top hot video candidate num: " << candidate_items.size();

  // get top hot items
  for (size_t i = 0; i < candidate_items.size(); ++i) {
    const ItemInfo& item = candidate_items[i];
    if ((int)ret_items->size() >= max_return) {
      break;
    }
    if (item.ctr <= ctr_thr) {
      VLOG(1) << "filtered by kVideoCtrThr " << item.ctr << "\t" << item.item_id;
      continue;
    }
    // NOTE(苏老板让这么做的)  自媒体视频不在垂直频道出
    if (item.is_source_wemedia) {
      continue;
    }
    ret_items->push_back(item);
  }
  std::sort(ret_items->begin(), ret_items->end(), std::greater<ItemInfo>());
  LOG(INFO) << "get top hot video candidate num: " << ret_items->size();
}

}  // namespace reco_leaf
}
