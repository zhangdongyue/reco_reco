#include "reco/serv/reco_leaf/strategy/reco/video/video_reco.h"
#include <utility>
#include <algorithm>
#include <unordered_map>

#include "base/time/time.h"
#include "base/time/timestamp.h"

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/strategy/user_feature/base/user_fea_extract_util.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"

namespace reco {
namespace leafserver {
DEFINE_int64_counter(recommend, has_video_result, 0, "");

VideoReco::VideoReco() {
  news_index_ = LeafDataManager::GetGlobalData()->news_index;
  candidates_extor_ = new CandidatesExtractor(news_index_);
}

VideoReco::~VideoReco() {
  if (candidates_extor_) {
    delete candidates_extor_;
    candidates_extor_ = NULL;
  }
}

void VideoReco::GetVideoFromResponse(const RecoRequest* request,
                                     int return_num,
                                     std::vector<ItemInfo>* video_items) {
  video_items->clear();
  DataFromVideoServerResponse video_response;

  if (!GetVideoResponseFromCache(*(request->request), &video_response) ||
      !ParseVideoFromVideoResponse(request, video_response, video_items)) {
    return;
  }

  int64 filtered_num = 0;
  UserDedup(request, video_items, &filtered_num);

  ReRank(video_items, return_num);

  LOG(INFO) << "get from cache:" << request->request->user().user_id()
            << " " << video_items->size()
            << " filtered: " << filtered_num;
  if (video_items->size() > 0) {
    COUNTERS_recommend__has_video_result.Increase(1);
  }
  return;
}

std::string VideoReco::GenVideoCacheKey(const RecommendRequest& request) {
  const int64 channel_id = request.has_channel_id() ? request.channel_id() : reco::common::kRecoChannelId;
  return base::StringPrintf("DATA_FROM_VIDEO_%lu_%ld", request.user().user_id(), channel_id);
}

void VideoReco::SetVideoResponseToCache(const RecommendRequest& request,
                                        const DataFromVideoServerResponse& video_response) {
  const std::string key = GenVideoCacheKey(request);
  std::string value;
  if (!video_response.SerializeToString(&value)) {
    LOG(WARNING) << "serialize to string fail!";
    return;
  }
  if (!LeafCache::SetCachedReco(key, value)) {
    LOG(WARNING) << "set data_from_video to cache fail!";
    return;
  }
}

bool VideoReco::GetVideoResponseFromCache(const RecommendRequest& request,
                                          DataFromVideoServerResponse* video_response) {
  video_response->Clear();
  const std::string key = GenVideoCacheKey(request);
  std::string value;
  if (!LeafCache::GetCachedReco(key, &value)) {
    VLOG(1) << "get from cache fail! " << key;
    return false;
  }
  if (!video_response->ParseFromString(value)) {
    LOG(INFO) << "parse_from_string fail!";
    return false;
  }
  return video_response->items_size() > 0;
}

bool VideoReco::ParseVideoFromVideoResponse(const RecoRequest* request,
                                            const DataFromVideoServerResponse& video_response,
                                            std::vector<ItemInfo>* video_items) {
  if (!video_response.success()) {
    return false;
  }

  const int64 now_timestamp = base::GetTimestamp();

  for (int i = 0; i < video_response.items_size(); ++i) {
    auto item = video_response.items(i);
    ItemInfo item_info;
    if (!news_index_->GetItemInfoByItemId(item.item_id(), &item_info, true)) {
      continue;
    }

    if (!NewsFilter::ItemIsValid(item_info, now_timestamp)) {
      continue;
    }

    if (!news_index_->GetItemInfoByDocId(item_info.doc_id, &item_info, false)) {
      continue;
    }
    video_items->push_back(item_info);
  }
  std::vector<ItemInfo> after_filtered_items;
  candidates_extor_->BasicRuleFilter(request, kCandidateVideo, *video_items, &after_filtered_items);
  video_items->swap(after_filtered_items);
  std::sort(video_items->begin(), video_items->end(), std::greater<ItemInfo>());

  return !video_items->empty();
}

void VideoReco::UserDedup(const RecoRequest* reco_request,
                          std::vector<ItemInfo>* item_list, int64* filtered_num) {
  *filtered_num = 0;
  size_t idx = 0;
  for (size_t i = 0; i < item_list->size(); ++i) {
    uint64 item_id = (*item_list)[i].item_id;
    reco::filter::FilterReason filter_reason;
    if (NewsFilter::IsGeneralFiltered(reco_request, reco_request->shown_dict,
                                      (*item_list)[i], &filter_reason, false)) {
      ++(*filtered_num);
      VLOG(1) << item_id << " user dedup";
      continue;
    }
    if (idx != i) {
      (*item_list)[idx] = (*item_list)[i];
    }
    ++idx;
  }
  item_list->resize(idx);
  // 过滤掉没有点过的 tag 的视频, 以及负反馈的视频
  std::set<std::string> no_clicked_tags;
  CollectNoClickedTag(reco_request, &no_clicked_tags);
  auto &dislike_tags = reco_request->user_feas->behavior_fea.dislike_tags;
  std::vector<ItemInfo> ret_items;
  for (size_t i = 0; i < item_list->size(); ++i) {
    reco::FeatureVector feature_vec;
    if (news_index_->GetVideoTagFeatureVectorByItemId(item_list->at(i).item_id, &feature_vec)) {
      bool need_filtered = false;
      for (int j = 0; j < feature_vec.feature_size(); ++j) {
        auto &tag = feature_vec.feature(j).literal();
        if (no_clicked_tags.find(tag) != no_clicked_tags.end() ||
            dislike_tags.find(tag) != dislike_tags.end()) {
          need_filtered = true;
          break;
        }
      }
      if (!need_filtered) {
        ret_items.push_back(item_list->at(i));
      } else {
        ++(*filtered_num);
      }
    }
  }
  item_list->swap(ret_items);
}

void VideoReco::CollectNoClickedTag(const RecoRequest* reco_request, std::set<std::string>* no_clicked_tags) {
  auto user_info = reco_request->user_info;
  std::unordered_map<std::string, int> shown_tags;
  int64 session_expire_timestamp =
      (base::Time::Now() - base::TimeDelta::FromHours(1)).ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int64 first_show_timestamp = 0;
  for (int i = user_info->shown_history_size() - 1;
       i >= 0 && i >= user_info->shown_history_size() - 30; --i) {
    const reco::user::ViewClickItem& show_item = user_info->shown_history(i);
    if (show_item.view_timestamp() < session_expire_timestamp) break;
    first_show_timestamp = show_item.view_timestamp();

    reco::ItemType item_type;
    if (news_index_->GetItemTypeByItemId(show_item.item_id(), &item_type)
        && item_type == reco::kPureVideo
        && show_item.has_channel_id()
        && !reco::common::IsVideoChannel(show_item.channel_id())) {
      reco::FeatureVector feature_vec;
      if (news_index_->GetVideoTagFeatureVectorByItemId(show_item.item_id(), &feature_vec)) {
        for (int j = 0; j < feature_vec.feature_size(); ++j) {
          ++shown_tags[feature_vec.feature(j).literal()];
          // LOG(INFO) << "shown tag: " << feature_vec.feature(j).literal();
        }
      }
    }
  }
  std::set<std::string> clicked_tags;
  int clicked_video_num = 0;
  for (int i = user_info->recent_click_size() - 1; i >= user_info->recent_click_size() - 50 && i >= 0; --i) {
    if (clicked_video_num >= 5) {
      break;
    }
    const reco::user::ViewClickItem& clicked_item = user_info->recent_click().Get(i);
    // 点击发生时间过于久远, 丢弃. 按时间有序, 可以 break
    if (clicked_item.click_timestamp() < session_expire_timestamp) break;
    if (clicked_item.click_timestamp() < first_show_timestamp) break;
    reco::ItemType item_type;
    if (news_index_->GetItemTypeByItemId(clicked_item.item_id(), &item_type)
        && item_type == reco::kPureVideo
        && clicked_item.has_channel_id()
        && !reco::common::IsVideoChannel(clicked_item.channel_id())) {
      reco::FeatureVector feature_vec;
      if (news_index_->GetVideoTagFeatureVectorByItemId(clicked_item.item_id(), &feature_vec)) {
        for (int j = 0; j < feature_vec.feature_size(); ++j) {
          clicked_tags.insert(feature_vec.feature(j).literal());
          VLOG(1) << "click tag: " << feature_vec.feature(j).literal();
        }
        ++clicked_video_num;
      }
    }
  }
  for (auto it = shown_tags.begin(); it != shown_tags.end(); ++it) {
    if (it->second < 3) continue;
    if (clicked_tags.find(it->first) == clicked_tags.end()) {
      no_clicked_tags->insert(it->first);
      VLOG(1) << "show > 3 and no click tag: " << it->first;
    }
  }
}

bool VideoReco::HasSameTag(const ItemInfo& item_a, const ItemInfo& item_b) {
  std::set<std::string> a_tags;
  reco::FeatureVector feature_vec;
  if (news_index_->GetFeatureVectorByItemId(item_a.item_id, reco::common::kTag, &feature_vec)) {
    for (int i = 0; i < feature_vec.feature_size(); ++i) {
      a_tags.insert(feature_vec.feature(i).literal());
    }
  }
  feature_vec.Clear();
  if (news_index_->GetFeatureVectorByItemId(item_b.item_id, reco::common::kTag, &feature_vec)) {
    for (int i = 0; i < feature_vec.feature_size(); ++i) {
      if (a_tags.find(feature_vec.feature(i).literal()) != a_tags.end()) {
        return true;
      }
    }
  }
  return false;
}

void VideoReco::ReRank(std::vector<ItemInfo>* items, int return_num) {
  for (size_t idx = 1; idx < items->size(); ++idx) {
    // that's enough
    if (int(idx) >= return_num) {
      break;
    }
    const ItemInfo& item = items->at(idx);
    const ItemInfo& prev_item = items->at(idx - 1);
    if (!HasSameTag(item, prev_item)) continue;
    for (size_t jdx = idx + 1; jdx < items->size(); ++jdx) {
      const ItemInfo& swap_item = items->at(jdx);
      if (!HasSameTag(swap_item, prev_item)) {
        std::swap(items->at(idx), items->at(jdx));
        break;
      }
    }
  }
  if (int(items->size()) >= return_num) {
    items->resize(return_num);
  }
}
}
}
