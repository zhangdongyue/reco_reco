#pragma once
#include <utility>
#include <string>
#include <vector>
#include <unordered_set>

#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace reco {
class NewsIndex;
namespace leafserver {
class CandidatesExtractor;
// leaf 中所有 video 结果都从 video_server 中拿, 对外使用都是从 cache 中取
class VideoReco {
 public:
  explicit VideoReco();
  ~VideoReco();
  void GetVideoFromResponse(const RecoRequest* request,
                            int return_num,
                            std::vector<ItemInfo>* video_items);

  static void SetVideoResponseToCache(const RecommendRequest& request,
                                      const DataFromVideoServerResponse& video_response);

  static bool GetVideoResponseFromCache(const reco::leafserver::RecommendRequest& request,
                                        DataFromVideoServerResponse* video_response);

 private:
  static std::string GenVideoCacheKey(const RecommendRequest& request);

  bool ParseVideoFromVideoResponse(const RecoRequest* request,
                                   const DataFromVideoServerResponse& video_response,
                                   std::vector<ItemInfo>* video_items);

  void UserDedup(const RecoRequest* reco_request,
                 std::vector<ItemInfo>* item_list, int64* filtered_num);

  bool HasSameTag(const ItemInfo& item_a, const ItemInfo& item_b);

  void ReRank(std::vector<ItemInfo>* items, int return_num);

  void CollectNoClickedTag(const RecoRequest* reco_request, std::set<std::string>* no_clicked_tags);

 private:
  const NewsIndex* news_index_;
  CandidatesExtractor* candidates_extor_;
};
}
}
