#include "reco/serv/reco_leaf/strategy/reco/personal/poi_reco.h"

#include "base/strings/string_number_conversions.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/poi/city_area_hash_dict.h"

namespace reco {
namespace leafserver {

const std::unordered_set<std::string> POIReco::kPOIRecoFreeCategoties = {"美食", "旅游"};
const std::unordered_set<std::string> POIReco::kPOIRecoLimitCategoties = {
  "国内", "社会", "房产", "旅游", "教育", "美食", "历史"};

DEFINE_bool(open_poi_filter, true, "是否开启 poi 过滤");
DEFINE_bool(poi_prov_level, true, "是否开启 poi province");
DEFINE_double(poi_min_ctr, 0.09, "");
DEFINE_double(poi_prov_min_ctr, 0.1, "");

POIReco::POIReco(const reco::NewsIndex* index) : news_index_(index) {
  candidates_extractor_ = new CandidatesExtractor(index);
}

POIReco::~POIReco() {
  delete candidates_extractor_;
}

bool ParseCorrd(const std::string &str, double *latitude, double *longitude) {
  size_t pos = str.find(",");
  if (pos == std::string::npos) return false;
  if (!base::StringToDouble(str.substr(0, pos), latitude) ||
      !base::StringToDouble(str.substr(pos + 1), longitude)) {
    return false;
  }
  return true;
}

bool POIItemSortFunc(const ItemInfo& left, const ItemInfo& right) {
  if (left.ctr != right.ctr) return left.ctr > right.ctr;
  if (left.hot_level != right.hot_level) return left.hot_level > right.hot_level;
  if (left.time_level != right.time_level) return left.time_level > right.time_level;
  // if (left.item_quality != right.item_quality) return left.item_quality > right.item_quality;
  if (left.site_level != right.site_level) return left.site_level > right.site_level;
  if (left.create_timestamp != right.create_timestamp) return left.create_timestamp > right.create_timestamp;
  return left.doc_id < right.doc_id;
}

bool POIReco::POIItemFilter(const ItemInfo &item, double ctr_thr) {
  if (!FLAGS_open_poi_filter) return false;
  static const int kShowThr = 200;
  static const double kCtrThr = 0.05;
  ctr_thr = std::max(kCtrThr, ctr_thr);
  if (item.hot_level <= 3 && (item.show_num < kShowThr || item.ctr < ctr_thr)) {
    VLOG(1) << "poi item filter by low ctr: " << item.item_id;
    return true;
  }

  if (kPOIRecoLimitCategoties.find(item.category) != kPOIRecoLimitCategoties.end()) {
    if (item.category == "社会" || item.category == "国内") {
      if (item.time_level == reco::kGoodTimeliness) {
        return false;
      }
    } else {
      if (item.time_level == reco::kMidTimeliness && item.ctr >= ctr_thr) {
        return false;
      }
      if (item.time_level == reco::kGoodTimeliness) {
        return false;
      }
    }
  }
  return true;
}

bool POIReco::POIItemMatchProvince(const ItemInfo& item, int64 province_id) {
  // 判断item的地域是否匹配省份id
  std::vector<int64> region_ids;
  if (!news_index_->GetRegionIdByDocId(item.doc_id, &region_ids) ||
      region_ids.empty()) {
    return false;
  }

  for (size_t i = 0; i < region_ids.size(); ++i) {
    if (region_ids[i] == province_id) {
      return true;
    }
  }
  return false;
}

std::string POIReco::GetPOITagSuffix(const ItemInfo& item) {
  // 根据item分类+热度, 返回不同标签
  static const std::string kPOITagSuffixHot = "热门";
  static const std::string kPOITagSuffixLocal = "本地";

  if (item.category == "国内" || item.category == "社会") {
    if (item.hot_level > 3) {
      return kPOITagSuffixHot;
    } else {
      return kPOITagSuffixLocal;
    }
  } else {
    return item.category;
  }
}

void POIReco::DoPoiReco(const RecoRequest* reco_request,
                        std::vector<ItemInfo>* poi_items,
                        std::unordered_map<uint64, POITag> *item_poi_tags,
                        double ctr_thr, int max_return, bool city_level) {
  poi_items->clear();
  item_poi_tags->clear();

  const auto &user_area_ids = reco_request->user_feas->attr.user_area_ids;
  const auto &user_district_ids = reco_request->user_feas->attr.user_district_ids;
  if (user_area_ids.empty() && user_district_ids.empty()) {
    VLOG(1) << "user area and district ids empty";
    return;
  }

  std::vector<ItemInfo> candidates;
  std::unordered_set<uint64> dedups;
  // 基于商圈
  for (auto iter = user_area_ids.begin(); iter != user_area_ids.end(); ++iter) {
    candidates.clear();
    candidates_extractor_->GetCandidatesByPOI(*iter, reco_request, &candidates, kMaxPOICandidateNum);
    reco::poi::AreaBaseInfo area_base_info;
    if (!reco::poi::CityAreaHashSearcher::instance().GetAreaBaseInfoByAreaID(*iter, &area_base_info)) {
      continue;
    }
    POITag poi_tag;
    poi_tag.set_id(*iter);
    poi_tag.set_literal(area_base_info.area_name);
    poi_tag.set_poi_tag_type(POITag::kShangQuanPOITag);
    for (size_t i = 0; i < candidates.size(); ++i) {
      if (item_poi_tags->find(candidates[i].item_id) == item_poi_tags->end()) {
        item_poi_tags->insert(std::make_pair(candidates[i].item_id, poi_tag));
      }
      if (POIItemFilter(candidates[i], ctr_thr)) {
        VLOG(1) << "poi item filter: " << candidates[i].item_id;
        continue;
      }
      if (dedups.find(candidates[i].item_id) != dedups.end()) {
        VLOG(1) << "poi item filter by dedup: " << candidates[i].item_id;
        continue;
      }
      if ((int)poi_items->size() > max_return) {
        break;
      }
      candidates[i].strategy_type = reco::kGeo;
      poi_items->push_back(candidates[i]);
      dedups.insert(candidates[i].item_id);
      VLOG(1) << "get poi item candidate by user area: " << candidates[i].item_id;
    }
  }

  // 基于区县
  for (auto iter = user_district_ids.begin(); iter != user_district_ids.end(); ++iter) {
    candidates.clear();
    candidates_extractor_->GetCandidatesByPOI(*iter, reco_request, &candidates, kMaxPOICandidateNum);
    std::string admin_name;
    if (!reco::poi::CityAreaHashSearcher::instance().GetAdminNameByID(*iter, &admin_name)) {
      continue;
    }
    POITag poi_tag;
    poi_tag.set_id(*iter);
    poi_tag.set_literal(admin_name);
    poi_tag.set_poi_tag_type(POITag::kDistrictPOITag);
    for (size_t i = 0; i < candidates.size(); ++i) {
      if (item_poi_tags->find(candidates[i].item_id) == item_poi_tags->end()) {
        item_poi_tags->insert(std::make_pair(candidates[i].item_id, poi_tag));
      }
      if (POIItemFilter(candidates[i], ctr_thr)) {
        VLOG(1) << "poi item filter: " << candidates[i].item_id;
        continue;
      }
      if (dedups.find(candidates[i].item_id) != dedups.end()) {
        VLOG(1) << "poi item filter by dedup: " << candidates[i].item_id;
        continue;
      }
      if ((int)poi_items->size() > max_return) {
        break;
      }
      candidates[i].strategy_type = reco::kGeo;
      poi_items->push_back(candidates[i]);
      dedups.insert(candidates[i].item_id);
      VLOG(1) << "get poi item candidate by user district: " << candidates[i].item_id;
    }
  }

  if (city_level) {
    // 基于城市
    candidates.clear();
    // 市队列里有省，候选集翻倍
    candidates_extractor_->GetCandidatesByCityId(reco_request->user_feas->attr.city_id,
                                                 reco_request, &candidates, kMaxPOICandidateNum*2);
    const std::string &city = reco_request->request->uc_user_param().city();
    const std::string &province = reco_request->request->uc_user_param().province();
    POITag poi_tag;
    for (size_t i = 0; i < candidates.size(); ++i) {
      if ((int)poi_items->size() > max_return) {
        break;
      }
      if (dedups.find(candidates[i].item_id) != dedups.end()) {
        VLOG(1) << "poi item filter by dedup: " << candidates[i].item_id;
        continue;
      }
      if (candidates[i].show_num < 500 || candidates[i].ctr < FLAGS_poi_min_ctr) {
        VLOG(1) << "show or ctr filter: " << candidates[i].item_id;
        continue;
      }
      if (POIItemFilter(candidates[i], ctr_thr)) {
        VLOG(1) << "poi item filter: " << candidates[i].item_id;
        continue;
      }
      // 市的队列里可能有省的文章，再过滤一下
      bool match_prov = POIItemMatchProvince(candidates[i], reco_request->user_feas->attr.prov_id);
      if (match_prov) {
        if (!FLAGS_poi_prov_level || candidates[i].ctr < FLAGS_poi_prov_min_ctr) {
          VLOG(1) << "poi item province ctr filter: " << candidates[i].item_id;
          continue;
        }
      }

      candidates[i].strategy_type = reco::kGeo;
      poi_items->push_back(candidates[i]);
      dedups.insert(candidates[i].item_id);

      std::string poi_tag_suffix = GetPOITagSuffix(candidates[i]);
      if (!match_prov) {
        poi_tag.set_id(reco_request->user_feas->attr.city_id);
        poi_tag.set_poi_tag_type(POITag::kCityPOITag);
        poi_tag.set_literal(city + poi_tag_suffix);
      } else {
        poi_tag.set_id(reco_request->user_feas->attr.prov_id);
        poi_tag.set_poi_tag_type(POITag::kProvPOITag);
        poi_tag.set_literal(province + poi_tag_suffix);
      }

      if (item_poi_tags->find(candidates[i].item_id) == item_poi_tags->end()) {
        item_poi_tags->insert(std::make_pair(candidates[i].item_id, poi_tag));
      }
      VLOG(1) << "get poi item candidate by city_id: " << candidates[i].item_id;
    }
  }

  std::sort(poi_items->begin(), poi_items->end(), POIItemSortFunc);
  MarkRecoBranch(poi_items);
  VLOG(1) << "get poi reco candidates: " << reco_request->user_info->identity().user_id()
          << ", " << poi_items->size();
}

void POIReco::MarkRecoBranch(std::vector<ItemInfo>* items) {
  for (size_t i = 0; i < items->size(); ++i) {
    items->at(i).strategy_branch = reco::kPoiBranch;
  }
}

}
}
