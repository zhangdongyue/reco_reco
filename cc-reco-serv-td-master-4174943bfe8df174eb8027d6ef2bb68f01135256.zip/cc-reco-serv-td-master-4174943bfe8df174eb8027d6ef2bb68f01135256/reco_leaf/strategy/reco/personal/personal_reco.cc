#include "reco/serv/reco_leaf/strategy/reco/personal/personal_reco.h"

#include <utility>
#include <algorithm>
#include <unordered_map>

#include "boost/unordered_map.hpp"

#include "serving_base/data_manager/data_manager.h"
#include "net/rpc_util/rpc_group.h"
#include "base/time/timestamp.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_tokenize.h"
#include "base/strings/string_printf.h"
#include "base/common/logging.h"
#include "base/math/discrete.h"

#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/common/item_level_define.h"
#include "reco/base/common/topn_heap.h"
// #include "reco/serv/reco_leaf/strategy/reco/offline/cf_item_dict.h"
#include "reco/serv/reco_leaf/frame/global_conf.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"


using std::vector;
using std::pair;
using std::unordered_map;

namespace reco {
class NewsIndex;
namespace leafserver {

DEFINE_int32(personal_candidate_cutoff, 7000, "个性化推荐候选条数");
DEFINE_int32(manual_cate_whole_item_min_num, 1, "类别下必须出的 item 数");
DEFINE_double(manual_cate_whole_item_ratio, 0.3, "类别下全量 item 的占比");
DEFINE_double(app_reco_icon_threshold, 0.25, "app展现\"荐\"图标的阈值");
DEFINE_double(app_hot_icon_threshold,  1.9, "app展现\"热\"图标的阈值");
DEFINE_double(science_snd_cate_max_weight,  0.5, "科技二级类别最大阈值");
DEFINE_double(internet_snd_cate_num_boost,  0.5, "互联网展示数量加权");
DEFINE_bool(open_personal_reco_switch, true, "false 表示关闭个性化");
DEFINE_bool(open_cf_tuning_switch, false, "是否开启 cf tuning 策略");
DEFINE_int32(wemedia_deliver_num_limit, -1, "一屏 wemedia 的条数限制, 负数表示不限制");
//DEFINE_int64_counter(leaf, cache_hit_total, 0, "");
DEFINE_bool(open_direct_ir_switch, false, "");

PersonalReco::PersonalReco(const reco::NewsIndex* news_index) : news_index_(news_index) {
  candidates_extractor_ = new CandidatesExtractor(news_index);
  reco_cache_ = new RecoResultCache(news_index);
  retrieval_ = new NewsRetrieval(news_index);
  ranker_ = new NewsRanker(news_index);
  hot_ranker_ = new HotRanker(news_index);
  pic_ranker_ = new PicRanker(news_index);
  shopping_ranker_ = new ShoppingRanker(news_index);
  random_ = new base::PseudoRandom(base::GetTimestamp());
  do_personal_reco_ = FLAGS_open_personal_reco_switch;
  // item_dict_manager_ = new ItemDictManager();
  // item_dict_manager_->AddDict(new CFItemDict());
}

PersonalReco::~PersonalReco() {
  delete candidates_extractor_;
  delete reco_cache_;
  delete retrieval_;
  delete ranker_;
  delete hot_ranker_;
  delete pic_ranker_;
  delete shopping_ranker_;
  delete random_;
  // delete item_dict_manager_;
}

void PersonalReco::DoPersonalReco(const RecoRequest* request,
                                  const ManualRecoData* manual_data,
                                  std::vector<ItemInfo>* personal_items,
                                  RecoContext* context) {
  personal_item_dicts_.clear();
  manual_data_ = manual_data;
  reco_request_ = request;

  do_personal_reco_ = FLAGS_open_personal_reco_switch && (GlobalConf::GetServiceLevel() == kNormalService);

  if (request->channel_id == reco::common::kRecoChannelId) {
    DoComplexChannelReco(personal_items, context);
  } else if (request->channel_id == reco::common::kHotChannelId) {
    DoHotChannelReco(personal_items, context);
  } else {
    DoVerticleChannelReco(personal_items, context);
  }
}

void PersonalReco::DoHotChannelReco(std::vector<ItemInfo>* personal_items, RecoContext* context) {
  personal_items->clear();
  // const uint32 req_num = reco_request_->request->return_num();
  // 候选集和的获取
  timer_.Start();
  std::vector<ItemInfo> candidate_items;
  candidates_extractor_->GetCandidatesByChannelId(reco_request_->channel_id, reco_request_, &candidate_items,
                                                  FLAGS_personal_candidate_cutoff, context->debugger());
  context->debugger()->TraceCategoryCandidateItems(candidate_items);

  std::vector<ItemInfo> ir_items;
  // 直接插入运营结果
  for (auto idx = 0u; idx < manual_data_->personal_items.size(); ++idx) {
    ir_items.push_back(manual_data_->personal_items[idx]);
  }
  // insert candidate
  for (auto idx = 0u; idx < candidate_items.size(); ++idx) {
    ir_items.push_back(candidate_items[idx]);
  }

  std::vector<ItemInfo> &rank_items = ir_items;
  // HotChannel 分值计算
  hot_ranker_->Rank(reco_request_, &rank_items);
  context->debugger()->TraceAfterCategoryRankItems(rank_items);

  // 同一屏去重
  int remain_size = std::min((int)rank_items.size(), (int)kMaxCacheItemNum * 3 + 5);
  NewsFilter::DiversityFilter(reco_request_->request, reco_request_->user_info,
                              reco_request_->user_feas, rank_items, "",
                              remain_size, personal_items);
  context->debugger()->TraceAfterDiversityFilterItems(*personal_items);

  // 截断
  if (personal_items->size() > kTopNSize) {
    personal_items->resize(kTopNSize);
  }
  context->cost_trace()->rks = timer_.Stop();
  context->debugger()->TraceAflterLimitPersonalItems(*personal_items);

  // 打上推荐标签
  timer_.Start();
  MarkAppIcon(personal_items);
  context->cost_trace()->mcs = timer_.Stop();
}


void PersonalReco::DoVerticleChannelReco(std::vector<ItemInfo>* personal_items, RecoContext* context) {
  const uint32 req_num = reco_request_->request->return_num();

  // 尝试从 cache 中获取
  timer_.Start();
  const bool use_cache = reco_cache_->CanUseCache(reco_request_);
  if (use_cache) {
    personal_items->clear();
    GetVerticalCachedItems(personal_items, req_num);
    context->cost_trace()->ccs = timer_.Stop();

    if (personal_items->size() >= req_num * 1.2) {
      LOG(INFO) << "verticle channel use cache, " << reco_request_->request->user().user_id()
                << ", " << reco_request_->request->reco_id();
      //COUNTERS_leaf__cache_hit_total.Increase(1);
      return;
    }
  }
  context->cost_trace()->ccs = timer_.Stop();

  personal_items->clear();

  // 生成 CF dict
  timer_.Start();
  /*
  if (do_personal_reco_ && FLAGS_open_cf_tuning_switch) {
    if (!item_dict_manager_->FillData(*reco_request_, &personal_item_dicts_)) {
      LOG(ERROR) << base::StringPrintf("get personal item dict failed! [recoid: %s][user id: %lu]",
                                       reco_request_->request->reco_id().c_str(),
                                       reco_request_->request->user().user_id());
      ranker_->SetPersonalItemDicts(NULL);
    } else {
      ranker_->SetPersonalItemDicts(&personal_item_dicts_);
    }
  }
  */
  context->cost_trace()->cfs = timer_.Stop();

  // 候选集合的获取
  timer_.Start();
  std::vector<ItemInfo> candidate_items;
  candidates_extractor_->GetCandidatesByChannelId(reco_request_->channel_id, reco_request_,
                                                  &candidate_items, FLAGS_personal_candidate_cutoff,
                                                  context->debugger());
  context->debugger()->TraceCategoryCandidateItems(candidate_items);
  // SetUserFeature();
  // ranker_->SetUserFeature(&this->proc_feature_);

  // SetUGM();
  // ranker_->SetUGM(&ugm_model_, &remain_prefix_);

  SetUserFeature();
  // SetUGM();
  // ranker_->SetEnv(&this->proc_feature_, &ugm_model_, &remain_prefix_);
  ranker_->SetEnv(&this->proc_feature_);

  // 触发 item
  std::vector<ItemInfo> ir_items;
  // 排序 item
  std::vector<ItemInfo> rank_items;
  // 触发直通车
  std::vector<ItemInfo> direct_ir_items;

  if (do_personal_reco_) {
    // 触发集合的获取
    retrieval_->RetrieveInChannel(reco_request_->channel_id, reco_request_,
                                  manual_data_->personal_items, candidate_items,
                                  &ir_items);
    // 触发直通车
    const int kMaxDirectIrNum = std::max(2, int(req_num / 4.0 + 0.5));
    retrieval_->ExtractIrDirectItems(ir_items, &direct_ir_items, kMaxDirectIrNum);
    // 排序结果的获取
    ranker_->Rank("", reco_request_, ir_items, &rank_items, context->debugger());

    // 图片频道单独处理逻辑
    if (reco_request_->channel_id == reco::common::kPictureChannelId) {
      pic_ranker_->Rank(reco_request_, &rank_items);
    }

    if (reco_request_->channel_id == reco::common::kShoppingId) {
      shopping_ranker_->Rank(reco_request_, &rank_items);
    }
  }

  context->debugger()->TraceAfterCategoryRankItems(rank_items);

  // 重排序
  std::vector<ItemInfo> mid_items;
  MergeAndReRankInCategory("", direct_ir_items, rank_items, candidate_items, &mid_items);
  context->debugger()->TraceAfterCategoryRerankItems(mid_items);
  context->cost_trace()->rks = timer_.Stop();

  // 多样性处理
  timer_.Start();
  if (reco_request_->channel_id == reco::common::kHumorWordChannelId
      || reco_request_->channel_id == reco::common::kLeftChannelId) {
    personal_items->assign(mid_items.begin(), mid_items.end());
  } else {
    int remain_size = std::min((int)mid_items.size(), (int)kMaxCacheItemNum * 2 + 5);
    NewsFilter::DiversityFilter(reco_request_->request, reco_request_->user_info,
                                reco_request_->user_feas, mid_items, "",
                                remain_size, personal_items);
  }
  context->debugger()->TraceAfterDiversityFilterItems(*personal_items);

  // 自媒体条数限制
  DoWemediaNumLimit(personal_items);
  context->debugger()->TraceAflterDoWemediaNumLimitItems(*personal_items);

  // 填充结果集合
  if (personal_items->size() > kTopNSize) {
    personal_items->resize(kTopNSize);
  }
  context->debugger()->TraceAflterLimitPersonalItems(*personal_items);

  // 打上推荐标签
  MarkAppIcon(personal_items);
  context->cost_trace()->mcs = timer_.Stop();

  // 写缓存
  if (use_cache && !personal_items->empty()) {
    reco_cache_->SetCachedItems(reco_request_, *personal_items);
  }
}

void PersonalReco::DoComplexChannelReco(std::vector<ItemInfo>* personal_items, RecoContext* context) {
  const uint32 req_num = reco_request_->request->return_num();

  // 尝试从 cache 中获取
  timer_.Start();
  const bool use_cache = reco_cache_->CanUseCache(reco_request_);
  if (use_cache) {
    personal_items->clear();
    GetComplexCachedItems(personal_items, req_num);
    context->cost_trace()->ccs = timer_.Stop();

    if (personal_items->size() >= req_num * 2) {
      LOG(INFO) << "complex channel use cache, " << reco_request_->request->user().user_id()
                << ", " << reco_request_->request->reco_id();
      //COUNTERS_leaf__cache_hit_total.Increase(1);
      return;
    }
  }
  context->cost_trace()->ccs = timer_.Stop();

  personal_items->clear();

  // SetUserFeature();
  // ranker_->SetUserFeature(&this->proc_feature_);

  // SetUGM();
  // ranker_->SetUGM(&ugm_model_, &remain_prefix_);


  SetUserFeature();
  // SetUGM();
  // ranker_->SetEnv(&this->proc_feature_, &ugm_model_, &remain_prefix_);
  ranker_->SetEnv(&this->proc_feature_);

  // 生成 CF dict
  timer_.Start();
  /*
  if (do_personal_reco_ && FLAGS_open_cf_tuning_switch) {
    if (!item_dict_manager_->FillData(*reco_request_, &personal_item_dicts_)) {
      LOG(ERROR) << base::StringPrintf("get personal item dict failed! [recoid: %s][user id: %lu]",
                                       reco_request_->request->reco_id().c_str(),
                                       reco_request_->request->user().user_id());
      ranker_->SetPersonalItemDicts(NULL);
    } else {
      ranker_->SetPersonalItemDicts(&personal_item_dicts_);
    }
  }
  */
  context->cost_trace()->cfs = timer_.Stop();

  // calc prefer categories
  CalcPreferCategories();

  // 触发直通车
  std::vector<ItemInfo> global_ir_items;
  if (FLAGS_open_direct_ir_switch) {
    CalcGlobalDirectIrItems(&global_ir_items);
  }

  // 分类别获取推荐结果
  timer_.Start();
  auto category_distributes = reco_request_->category_distributes;
  diversity_items_vec_.clear();
  diversity_items_vec_.resize(category_distributes->size());
  CategoryDistributeReco(category_distributes, &diversity_items_vec_, context->debugger());
  context->debugger()->TracePersonalCategoryItems(*category_distributes, diversity_items_vec_);
  context->cost_trace()->rks = timer_.Stop();

  // 多 category 融合及展现控制
  timer_.Start();
  MergeBetweenCategories(diversity_items_vec_, personal_items, req_num);
  context->debugger()->TraceAfterMergeBetweenCategoriesItems(*personal_items);

  // 自媒体条数限制
  DoWemediaNumLimit(personal_items);
  context->debugger()->TraceAflterDoWemediaNumLimitItems(*personal_items);

  // 填充到结果集合
  if (personal_items->size() > kTopNSize) {
    personal_items->resize(kTopNSize);
  }
  context->debugger()->TraceAflterLimitPersonalItems(*personal_items);

  // 打上推荐标签
  MarkAppIcon(personal_items);
  context->cost_trace()->mcs = timer_.Stop();

  // 写缓存
  if (use_cache && !personal_items->empty()) {
    reco_cache_->SetCachedItems(reco_request_, *personal_items);
  }
}

void PersonalReco::CategoryDistributeReco(const vector<pair<float, reco::Category>> *category_distributes,
                                          vector<pair<float, vector<ItemInfo> > > *diversity_items_vec,
                                          RecoDebugger* debugger) {
  int concurrent_num = LeafDataManager::GetGlobalData()->GetParallelNum();
  if (!reco_request_->user_param_info.is_inner_qudao) {
    concurrent_num = std::max(concurrent_num, 3);
  }
  thread::ThreadPool pool(concurrent_num);
  int diversity_idx = 0;
  for (auto i = 0u; i < category_distributes->size(); ++i) {
    const reco::Category& category = category_distributes->at(i).second;
    if (category.category() == reco::common::kHotNewsCategory
        || category.category() == reco::common::kVideoCategory)
      continue;

    pool.AddTask(::NewCallback(this, &PersonalReco::CategoryReco,
                               category, category_distributes->at(i).first,
                               diversity_idx, diversity_items_vec, debugger));
    ++diversity_idx;
  }

  pool.JoinAll();

  return;
}

void PersonalReco::CategoryReco(const reco::Category category,
                                const float category_ratio,
                                const int diversity_idx,
                                vector<pair<float, vector<ItemInfo> > > *diversity_items_vec,
                                RecoDebugger* debugger) {
  // result containter
  std::pair<float, std::vector<ItemInfo> > info;
  info.first = category_ratio;
  std::vector<ItemInfo> &diversity_items = info.second;

  std::vector<ItemInfo> candidate_items;
  candidates_extractor_->GetCandidatesByCategory(category, reco_request_, &candidate_items,
                                                 FLAGS_personal_candidate_cutoff, debugger);
  debugger->TraceCategoryCandidateItems(candidate_items);

  std::vector<ItemInfo> ir_items;
  std::vector<ItemInfo> rank_items;
  std::vector<ItemInfo> direct_ir_items;
  if (do_personal_reco_) {
    // 触发：人工个性化部分候选 + 机器候选
    retrieval_->RetrieveInCategory(category.category(), reco_request_,
                                   manual_data_->personal_items, candidate_items,
                                   &ir_items);
    // 触发直通车
    retrieval_->ExtractIrDirectItems(ir_items, &direct_ir_items, 2);
    // 排序结果的获取
    ranker_->Rank(category.category(), reco_request_, ir_items, &rank_items, debugger);
  }
  debugger->TraceAfterCategoryRankItems(rank_items);

  // 重排序
  std::vector<ItemInfo> mid_items;
  MergeAndReRankInCategory(category.category(), direct_ir_items, rank_items, candidate_items, &mid_items);
  debugger->TraceAfterCategoryRerankItems(mid_items);

  // 同一类别内的多样性处理
  const int remain_num = std::min(static_cast<int>(mid_items.size()),
                                  static_cast<int>(kMaxCacheItemNum * category_ratio * 2) + 3);

  NewsFilter::DiversityFilter(reco_request_->request, reco_request_->user_info,
                              reco_request_->user_feas, mid_items,
                              category.category(), remain_num, &diversity_items);
  if (diversity_items.size() > kTopNSize) {
    diversity_items.resize(kTopNSize);
  }
  debugger->TraceAfterDiversityFilterItems(diversity_items);

  {
    thread::AutoLock lock(&mutex_);
    (*diversity_items_vec)[diversity_idx] = info;
  }

  return;
}

void PersonalReco::GetCandidates(const std::vector<std::pair<float, reco::Category>> *category_distributes,
                                 unordered_map<std::string, std::vector<ItemInfo>> *candidate_map) {
  thread::ThreadPool pool(2);

  for (auto i = 0u; i < category_distributes->size(); ++i) {
    const reco::Category& category = category_distributes->at(i).second;
    if (category.category() == reco::common::kHotNewsCategory
        || category.category() == reco::common::kVideoCategory) continue;

    pool.AddTask(::NewCallback(this, &PersonalReco::GetCategoryCandidates,
                               category, reco_request_, candidate_map));
  }

  pool.JoinAll();

  return;
}

void PersonalReco::GetCategoryCandidates(const reco::Category category,
                                         const RecoRequest* request,
                                         unordered_map<std::string, std::vector<ItemInfo>> *candidate_map) {
  std::vector<ItemInfo> items;
  candidates_extractor_->GetCandidatesByCategory(category, reco_request_, &items,
                                                 FLAGS_personal_candidate_cutoff, NULL);

  thread::AutoLock lock(&mutex_);
  (*candidate_map)[category.category()] = items;

  return;
}

void PersonalReco::MergeAndReRankInCategory(const std::string& category,
                                            const std::vector<ItemInfo> &direct_ir_items,
                                            const std::vector<ItemInfo> &rank_items,
                                            const std::vector<ItemInfo> &candidate_items,
                                            std::vector<ItemInfo>* ret_items) {
  ret_items->clear();

  /////////// 是否做二级类别重排序
  bool snd_cate_rerank = IfReRankBySndCategory(category, reco_request_->channel_id);
  std::vector<ItemInfo> mid_items;
  std::vector<ItemInfo>* select_items = &mid_items;
  if (!snd_cate_rerank) {
    select_items = ret_items;
  }

  /////////// merge 结果
  // 触发直通车最优先
  base::dense_hash_set<uint64> item_dedup;
  item_dedup.set_empty_key(NULL);
  for (size_t idx = 0; idx < direct_ir_items.size(); ++idx) {
    const ItemInfo& item = direct_ir_items.at(idx);
    if (!NewsFilter::IsDeduped(item, &item_dedup)) {
      select_items->push_back(item);
    }
  }

  // 类别内的全量下发
  const std::vector<ItemInfo>* whole_items = NULL;
  if (prefer_categories_.find(category) != prefer_categories_.end()) {
    auto whole_iter = manual_data_->category_whole_items.find(category);
    if (whole_iter != manual_data_->category_whole_items.end()) {
      whole_items = &(whole_iter->second);
    }
  }

  // 全量文章 和 个性化文章交互下发
  size_t personal_idx = 0, whole_idx = 0;
  if (whole_items != NULL && !whole_items->empty()) {
    int whole_acc_num = 0;
    while (personal_idx < rank_items.size() && whole_idx < whole_items->size()) {
      if (select_items->size() >= kTopNSize) break;
      // 判断此次选择全量还是个性化
      bool select_manual = true;
      bool top_select_manual = true;   // 是否强制头部选择
      if (whole_acc_num >= FLAGS_manual_cate_whole_item_min_num) {
        select_manual = (random_->GetDouble() < FLAGS_manual_cate_whole_item_ratio);
        top_select_manual = false;
      }
      // 如果选择人工, 则插入一条人工
      while (select_manual && whole_idx < whole_items->size()) {
        auto& item = whole_items->at(whole_idx);
        ++whole_idx;
        if (!NewsFilter::IsDeduped(item, &item_dedup)) {
          ++whole_acc_num;
          select_items->push_back(item);
          break;
        }
      }
      // 如果是强制选择人工，或者此次判断选择个性化, 则插入一条个性化
      while ((top_select_manual || !select_manual)
             && personal_idx < rank_items.size()) {
        auto& item = rank_items.at(personal_idx);
        ++personal_idx;
        if (!NewsFilter::IsDeduped(item, &item_dedup)) {
          select_items->push_back(item);
          break;
        }
      }
    }
    while (whole_idx < whole_items->size()) {
      if (select_items->size() >= kTopNSize) break;
      auto& item = whole_items->at(whole_idx);
      if (!NewsFilter::IsDeduped(item, &item_dedup)) {
        select_items->push_back(item);
      }
      ++whole_idx;
    }
  }
  // 不够继续插入 个性化队列
  while (personal_idx < rank_items.size()) {
    if (select_items->size() >= kTopNSize) break;
    auto& item = rank_items.at(personal_idx);
    if (!NewsFilter::IsDeduped(item, &item_dedup)) {
      select_items->push_back(item);
    }
    ++personal_idx;
  }
  // 不够数，插入默认队列
  std::size_t candidate_idx = 0;
  while (candidate_idx < candidate_items.size()) {
    if (select_items->size() >= kTopNSize) break;
    auto& item = candidate_items[candidate_idx];
    if (!NewsFilter::IsDeduped(item, &item_dedup)) {
      select_items->push_back(item);
    }
    candidate_idx++;
  }

  // 二级类别多样性处理
  if (snd_cate_rerank && !mid_items.empty()) {
    ReRankBySndCategory(category, reco_request_->channel_id, mid_items, ret_items);
  }
}

void PersonalReco::DoWemediaNumLimit(std::vector<ItemInfo>* ret_items) {
  if (FLAGS_wemedia_deliver_num_limit < 0) return;

  std::vector<ItemInfo> swap_items;
  std::vector<int> filter_idx_vec;
  int add_wemedia = 0;
  std::string wemedia_person;
  for (int i = 0; i < (int)ret_items->size(); ++i) {
    const ItemInfo& item = ret_items->at(i);
    if (item.strategy_type != reco::kManual
        && news_index_->GetWeMediaPersonByDocId(item.doc_id, &wemedia_person)) {
      if (add_wemedia >= FLAGS_wemedia_deliver_num_limit) {
        filter_idx_vec.push_back(i);
        continue;
      }
      add_wemedia += 1;
    }
    swap_items.push_back(item);
  }
  for (int i = 0; i < (int)filter_idx_vec.size(); ++i) {
    if (swap_items.size() >= kTopNSize) break;
    int pos = filter_idx_vec[i];
    swap_items.push_back(ret_items->at(pos));
  }

  ret_items->swap(swap_items);
}

void PersonalReco::MergeBetweenCategories(
    const vector<pair<float, vector<ItemInfo> > >& diversity_items_vec,
    vector<ItemInfo>* ret_items,
    int req_num) {
  // 各个类别的概率分布
  float acc_weight = 0;
  for (int i = 0; i < (int)diversity_items_vec.size(); ++i) {
    acc_weight += diversity_items_vec.at(i).first;
  }
  if (acc_weight < 1e-4) {
    for (int i = 0; i < (int)diversity_items_vec.size(); ++i) {
      const std::vector<ItemInfo>& div_items = diversity_items_vec.at(i).second;
      for (int k = 0; k < (int)div_items.size(); ++k) {
        ret_items->push_back(div_items[k]);
      }
    }
    return;
  }

  // 计算本批次推荐每个类别的下发数
  const uint32 kMaxNumPerCate = 3;
  uint32 acc_num = 0;
  std::vector<uint32> num_vec;
  num_vec.resize(diversity_items_vec.size());
  for (int i = 0; i < (int)diversity_items_vec.size(); ++i) {
    const std::vector<ItemInfo>& div_items = diversity_items_vec.at(i).second;
    if (div_items.empty()) continue;

    float ratio = (diversity_items_vec.at(i).first / acc_weight) * kNewsNumPerScreen;
    int num = (int)ratio;
    if (num >= (int)kMaxNumPerCate) {
      num = kMaxNumPerCate;
    } else if (random_->GetDouble() <= ratio - num) {
      ++num;
    }
    if (num == 0
        && (div_items[0].strategy_type == reco::kSubscription
            || div_items[0].strategy_type == reco::kSubscriptSource)) {
      num = 1;
    }
    num_vec[i] = std::min(static_cast<int>(div_items.size()), num);
    acc_num += num_vec[i];
  }

  if (acc_num < kNewsNumPerScreen) {
    for (int i = 0; i < (int)num_vec.size(); ++i) {
      if (acc_num >= kNewsNumPerScreen) break;
      if (num_vec[i] < kMaxNumPerCate
          && num_vec[i] < diversity_items_vec[i].second.size()) {
        num_vec[i] += 1;
        acc_num += 1;
      }
    }

    if (acc_num < kNewsNumPerScreen
        && !num_vec.empty()
        && num_vec[0] < diversity_items_vec[0].second.size()) {
      num_vec[0] += std::min(kNewsNumPerScreen - acc_num,
                             (uint32)diversity_items_vec[0].second.size() - num_vec[0]);
    }
  }

  static const float kCateWtBoostPow = 1;
  std::vector<std::pair<float, SortData> > sort_vec;
  for (int idx = 0; idx < (int)diversity_items_vec.size(); ++idx) {
    const std::vector<ItemInfo>& div_items = diversity_items_vec.at(idx).second;
    float weight = diversity_items_vec.at(idx).first;
    float last_reco_score = 0;
    SortData sort_data;
    for (int jdx = div_items.size() - 1; jdx >= 0; --jdx) {
      const ItemInfo& item = div_items.at(jdx);
      float reco_score = std::max(last_reco_score + 1, (float)item.reco_score);
      last_reco_score = reco_score;
      reco_score *= std::pow((1 + weight), kCateWtBoostPow);
      sort_data.fst_idx = idx;
      sort_data.snd_idx = jdx;
      sort_data.used = false;
      sort_vec.push_back(std::make_pair(reco_score, sort_data));
    }
  }

  std::sort(sort_vec.begin(), sort_vec.end(), std::greater<std::pair<float, SortData>>());

  const int kProcessScreenNum = std::min((size_t)15, sort_vec.size() / kNewsNumPerScreen);
  for (int i = 0; i < kProcessScreenNum; ++i) {
    std::vector<uint32> put_vec(num_vec.size(), 0);
    for (size_t j = 0; j < sort_vec.size(); ++j) {
      SortData& sort_data = sort_vec[j].second;
      if (sort_data.used) continue;
      int fst_idx = sort_data.fst_idx;
      int snd_idx = sort_data.snd_idx;
      if (put_vec[fst_idx] < num_vec[fst_idx]) {
        ++put_vec[fst_idx];
        sort_data.used = true;
        ret_items->push_back(diversity_items_vec.at(fst_idx).second.at(snd_idx));
      }
    }
  }
  for (size_t j = 0; j < sort_vec.size(); ++j) {
    SortData& sort_data = sort_vec[j].second;
    if (sort_data.used) continue;
    int fst_idx = sort_data.fst_idx;
    int snd_idx = sort_data.snd_idx;
    sort_data.used = true;
    ret_items->push_back(diversity_items_vec.at(fst_idx).second.at(snd_idx));
  }

}

void PersonalReco::MergeBetweenCategoriesOld(
    const vector<pair<float, vector<ItemInfo> > >& diversity_items_vec,
    vector<ItemInfo>* ret_items,
    int req_num) {
  // 各个类别的概率分布
  float acc_weight = 0;
  for (int i = 0; i < (int)diversity_items_vec.size(); ++i) {
    acc_weight += diversity_items_vec.at(i).first;
  }

  if (acc_weight < 1e-4) {
    for (int i = 0; i < (int)diversity_items_vec.size(); ++i) {
      const std::vector<ItemInfo>& div_items = diversity_items_vec.at(i).second;
      for (int k = 0; k < (int)div_items.size(); ++k) {
        ret_items->push_back(div_items[k]);
      }
    }
    return;
  }

  // 计算本批次推荐每个类别的下发数
  int acc_num = 0;
  std::vector<int> num_vec;
  num_vec.resize(diversity_items_vec.size());
  for (int i = 0; i < (int)diversity_items_vec.size(); ++i) {
    const std::vector<ItemInfo>& div_items = diversity_items_vec.at(i).second;
    if (div_items.empty()) continue;

    float ratio = (diversity_items_vec.at(i).first / acc_weight) * req_num;
    int num = (int)ratio;
    if (random_->GetDouble() <= ratio - num) {
      ++num;
    }
    if (num == 0
        && (div_items[0].strategy_type == reco::kSubscription
            || div_items[0].strategy_type == reco::kSubscriptSource)) {
      num = 1;
    }
    num_vec[i] = std::min(static_cast<int>(div_items.size()), num);
    acc_num += num_vec[i];
  }

  if (acc_num < req_num) {
    for (int i = 0; i < (int)num_vec.size(); ++i) {
      if (acc_num >= req_num) break;
      if (num_vec[i] < req_num * 0.4
          && num_vec[i] < (int)diversity_items_vec[i].second.size()) {
        num_vec[i] += 1;
        acc_num += 1;
      }
    }

    if (!num_vec.empty() && acc_num < req_num
        && num_vec[0] < (int)diversity_items_vec[0].second.size()) {
      num_vec[0] += std::min(req_num - acc_num,
                             (int)diversity_items_vec[0].second.size() - num_vec[0]);
    }
  }

  // 第一屏根据确定好的文章条数进行展现
  // 控制相同类别的文章不要有很多条连续一起出现，至少隔一个类别
  std::vector<int> put_vec(num_vec.size(), 0);
  for (int idx = 0; idx < (int)diversity_items_vec.size(); ++idx) {
    const std::vector<ItemInfo>& div_items = diversity_items_vec.at(idx).second;
    int num = num_vec[idx];
    if (num >= 9) {
      num = static_cast<int>(num / 3.0 + 0.5);
    } else if (num >= 5) {
      num = static_cast<int>(num / 2.0 + 0.5);
    }

    for (int k = 0; k < num && k < (int)div_items.size(); ++k) {
      ret_items->push_back(div_items[k]);
    }
    put_vec[idx] = num;

    // 把之前类别没有展现完的拿出来，继续展现
    for (int last_idx = 0; last_idx < idx; ++last_idx) {
      if (num_vec[last_idx] <= put_vec[last_idx]) continue;
      num = num_vec[last_idx] - put_vec[last_idx];
      if (num >= 5) {
        num = (int)(num / 2.0 + 0.5);
      }

      const std::vector<ItemInfo>& last_div_items = diversity_items_vec.at(last_idx).second;
      for (int k = put_vec[last_idx]; k < put_vec[last_idx] + num && k < (int)last_div_items.size(); ++k) {
        ret_items->push_back(last_div_items[k]);
      }
      put_vec[last_idx] = put_vec[last_idx] + num;
    }
  }

  // 缓存的数据尽量根据 num_vec 均匀点, 保证缓存截断时不会只留下前面类别
  static const int kCacheScreenNum = 8;
  for (int screen = 1; screen < kCacheScreenNum; ++screen) {
    for (int div_idx = 0; div_idx < (int)diversity_items_vec.size(); ++div_idx) {
      const std::vector<ItemInfo>& div_items = diversity_items_vec.at(div_idx).second;
      int start_pos = num_vec[div_idx] * screen;
      int end_pos = num_vec[div_idx] * (screen + 1);
      for (int item_idx = start_pos; item_idx < end_pos && item_idx < (int)div_items.size(); ++item_idx) {
        ret_items->push_back(div_items[item_idx]);
      }
    }
  }

  for (int i = 0; i < (int)diversity_items_vec.size(); ++i) {
    const std::vector<ItemInfo>& div_items = diversity_items_vec.at(i).second;
    for (int k = num_vec[i] * kCacheScreenNum; k < (int)div_items.size(); ++k) {
      ret_items->push_back(div_items[k]);
    }
  }
}

inline bool PersonalReco::IfReRankBySndCategory(const std::string& category,
                                                int64 channel_id) const {
  static std::unordered_set<std::string> kDoSndRankCategories
      = {reco::common::kSportCategory,
        reco::common::kFinanceCategory,
        reco::common::kScienceCategory};

  static std::unordered_set<int64> kDoSndRankChannelIds
      = {reco::common::kSportChannelId,
        reco::common::kFinanceChannelId,
        reco::common::kScienceChannelId};

  return ((!category.empty()
           && kDoSndRankCategories.find(category) != kDoSndRankCategories.end())
          ||
          (channel_id != reco::common::kRecoChannelId
           && kDoSndRankChannelIds.find(channel_id) != kDoSndRankChannelIds.end()));
}

void PersonalReco::ReRankBySndCategory(const std::string& p_category, int64 channel_id,
                                       const std::vector<ItemInfo>& org_items,
                                       std::vector<ItemInfo>* merged_items) {
  if (org_items.empty()) return;

  // 计算二级类别的权重
  std::string category;
  if (!p_category.empty()) {
    category = p_category;
  } else if (channel_id == reco::common::kSportChannelId) {
    category = reco::common::kSportCategory;
  } else if (channel_id == reco::common::kFinanceChannelId) {
    category = reco::common::kFinanceCategory;
  } else if (channel_id == reco::common::kScienceChannelId) {
    category = reco::common::kScienceCategory;
    // ReRankSndCategoryForScienceChannel(channel_id, category, org_items, merged_items);
    // return;
  } else {
    merged_items->insert(merged_items->end(), org_items.begin(), org_items.end());
    return;
  }

  // 获取本次请求，该类别/频道下发量大小
  int news_per_screen = kNewsNumPerScreen;
  if (channel_id == reco::common::kRecoChannelId) {
    news_per_screen = 0;
    for (int i = 0; i < (int)reco_request_->category_distributes->size(); ++i) {
      if (category != reco_request_->category_distributes->at(i).second.category()) continue;
      float float_num = reco_request_->category_distributes->at(i).first * kNewsNumPerScreen;
      news_per_screen = (int)float_num;
      if (random_->GetDouble() < float_num - news_per_screen) {
        news_per_screen += 1;
      }
      break;
    }
  }

  // 如果用户没有点击行为，且需要返回条数很小的情况，则直接返回整体数据
  double cate_click = 0;
  const auto& ref_l1_cates = reco_request_->user_feas->merged_fea.l1_cates;
  auto l1_iter = ref_l1_cates.find(category);
  if (l1_iter == ref_l1_cates.end() || news_per_screen == 0) {
    if (news_per_screen < 3) {
      merged_items->insert(merged_items->end(), org_items.begin(), org_items.end());
      return;
    }
  } else {
    cate_click = l1_iter->second * reco_request_->user_feas->merged_info.total_click_num;
  }

  // calc explore ratio
  float total_explore_ratio = 1;
  if (cate_click >= 45) {
    total_explore_ratio = 0.1;
  } else if (cate_click >= 25) {
    total_explore_ratio = 0.1 + (45 - cate_click) * 0.0025;
  } else if (cate_click >= 15) {
    total_explore_ratio = 0.15 + (25 - cate_click) * 0.005;
  } else if (cate_click >= 5) {
    total_explore_ratio = 0.2 + (15 - cate_click) * 0.01;
  } else if (cate_click >= 1) {
    total_explore_ratio = 0.3 + (5 - cate_click) * 0.03;
  }
  if (channel_id != reco::common::kRecoChannelId) {
    // 非推荐频道的 explore 因素可以更强点
    total_explore_ratio *= 1.5;
  }
  total_explore_ratio = std::min(1.0f, total_explore_ratio);

  // 根据在二级类目上的点击情况，计算各个二级类别分配的条数
  const FeaKeyVal* user_l2_cates = NULL;
  const auto& ref_l2_cates = reco_request_->user_feas->merged_fea.l2_cates;
  auto l2_iter = ref_l2_cates.find(category);
  if (l2_iter != ref_l2_cates.end() && !l2_iter->second.empty()) {
    user_l2_cates = &l2_iter->second;
  }

  FeaKeyVal l2_num_map;
  float sum_weight = 0;
  for (int i = 0; i < (int)org_items.size(); ++i) {
    const std::string& sub_cate = org_items[i].sub_category;
    const std::string& standard_sub_cate = GetStandardSubCate(category, sub_cate);

    float weight = 0;
    if (user_l2_cates != NULL) {
      const auto iter = user_l2_cates->find(sub_cate);
      weight = (iter != user_l2_cates->end()) ? iter->second : 0;
    }

    l2_num_map[standard_sub_cate] += weight;
    sum_weight += weight;
  }
  if (l2_num_map.empty()) {
    merged_items->insert(merged_items->end(), org_items.begin(), org_items.end());
    return;
  }
  if (sum_weight > 1e-3) {
    // 归一化
    for (auto iter = l2_num_map.begin(); iter != l2_num_map.end(); ++iter) {
      iter->second /= sum_weight;
    }
  }
  // explore 因子
  float explore_ratio = total_explore_ratio / l2_num_map.size();
  for (auto iter = l2_num_map.begin(); iter != l2_num_map.end(); ++iter) {
    iter->second = (1 - total_explore_ratio) * iter->second + explore_ratio;
    iter->second *= news_per_screen;
    int num = (int)iter->second;
    if (random_->GetDouble() < iter->second - num) num++;
    iter->second = num;
  }

  // 控制二级类别的下发
  std::vector<bool> used_idx_vec(org_items.size(), false);
  int sloop_times = std::min(20, (int)org_items.size() / news_per_screen);
  for (int sloop_idx = 0; sloop_idx < sloop_times; ++sloop_idx) {
    FeaKeyVal subcate_num_map = l2_num_map;  // 临时变量，不是引用
    for (int item_idx = 0; item_idx < (int)org_items.size(); ++item_idx) {
      if (used_idx_vec[item_idx] == true) continue;
      const ItemInfo& org_item = org_items[item_idx];
      const std::string& standard_sub_cate = GetStandardSubCate(category, org_item.sub_category);
      auto iter = subcate_num_map.find(standard_sub_cate);
      if (iter != subcate_num_map.end() && iter->second > 0) {
        merged_items->push_back(org_item);
        used_idx_vec[item_idx] = true;
        iter->second -= 1;
        continue;
      }
    }
  }
  for (int item_idx = 0; item_idx < (int)org_items.size(); ++item_idx) {
    if (used_idx_vec[item_idx] == true) continue;
    merged_items->push_back(org_items[item_idx]);
  }
}

// 标志 icon, 热 or 荐
void PersonalReco::MarkAppIcon(std::vector<ItemInfo>* reco_items) const {
  for (int i = 0; i < (int)reco_items->size(); ++i) {
    ItemInfo& item = (*reco_items)[i];
    if (item.strategy_type != reco::kNoStrategy) {
      continue;
    }
    if ((!reco_request_->is_update_req
         || item.time_level == reco::kGoodTimeliness)
        && item.hot_level >= reco::item_level::kMidHotScoreThres) {
      item.strategy_type = reco::kHot;
    } else if (item.reco_score >= FLAGS_app_reco_icon_threshold * kRecoScoreFactor) {
      item.strategy_type = reco::kExploit;
    } else {
      item.strategy_type = reco::kExplore;
    }
  }
}

// 综合频道的 cache
void PersonalReco::GetComplexCachedItems(std::vector<ItemInfo>* cached_items, int req_num) {
  CachedNewsRecoData reco_data;
  reco_cache_->GetCachedItems(reco_request_, &reco_data);
  if (reco_data.category_distribution_size() <= 0) {
    // LOG(INFO) << "get reco cache fail.";
    return;
  }

  if ((int)reco_data.item_misc_size() < req_num * 1.5) {
    return;
  }

  ItemInfo item;
  for (int i = 0; i < reco_data.item_misc_size(); ++i) {
    const CachedItemMisc& item_misc = reco_data.item_misc(i);
    reco::filter::FilterReason filter_reason;
    if (!news_index_->GetItemInfoByItemId(item_misc.item_id(), &item, false)
        || NewsFilter::IsGeneralFiltered(reco_request_, reco_request_->shown_dict,
                                         item, &filter_reason)
        || NewsFilter::IsRegionRestrictFiltered(item, reco_request_->user_feas->attr.prov_id,
                                                reco_request_->user_feas->attr.city_id)) {
      continue;
    }

    int strategy_type = item_misc.strategy_type();
    if (reco::StrategyType_IsValid(strategy_type)) {
      item.strategy_type = reco::StrategyType(strategy_type);
    } else {
      item.strategy_type = reco::kNoStrategy;
    }

    item.lr_score = item_misc.lr_score();
    item.fm_score = item_misc.fm_score();
    item.reco_score = item_misc.reco_score();
    cached_items->push_back(item);
  }

  if ((int)cached_items->size() < req_num) {
    cached_items->clear();
    return;
  }

  bool fail_cache = false;
  diversity_items_vec_.clear();
  diversity_items_vec_.resize(reco_data.category_distribution_size());
  for (int i = 0; i < reco_data.category_distribution_size(); ++i) {
    const CategoryDistribution& distribution = reco_data.category_distribution(i);
    std::pair<float, std::vector<ItemInfo> >& info = diversity_items_vec_[i];
    info.first = distribution.ratio();
    std::vector<ItemInfo>& diversity_items = info.second;
    for (int j = 0; j < (int)cached_items->size(); ++j) {
      const ItemInfo& reco_item = cached_items->at(j);
      if (reco_item.category != distribution.category()) continue;
      diversity_items.push_back(reco_item);
    }
    // 特定类别的文章太少的话，就不用 cache 结果了
    if (diversity_items.size() < info.first * kNewsNumPerScreen - 1) {
      fail_cache = true;
      break;
    }
  }

  if (fail_cache) {
    cached_items->clear();
    return;
  }

  cached_items->clear();
  MergeBetweenCategories(diversity_items_vec_, cached_items, req_num);
}

// 垂直频道的 cache
void PersonalReco::GetVerticalCachedItems(std::vector<ItemInfo>* cached_items,
                                          int req_num) {
  cached_items->clear();

  CachedNewsRecoData reco_data;
  reco_cache_->GetCachedItems(reco_request_, &reco_data);
  if ((int)reco_data.item_misc_size() < req_num * 1.5) {
    return;
  }

  ItemInfo item;
  for (int i = 0; i < reco_data.item_misc_size(); ++i) {
    const CachedItemMisc& item_misc = reco_data.item_misc(i);
    reco::filter::FilterReason filter_reason;
    if (!news_index_->GetItemInfoByItemId(item_misc.item_id(), &item, false)
        || NewsFilter::IsGeneralFiltered(reco_request_, reco_request_->shown_dict,
                                         item, &filter_reason)) {
      continue;
    }

    int strategy_type = item_misc.strategy_type();
    if (reco::StrategyType_IsValid(strategy_type)) {
      item.strategy_type = reco::StrategyType(strategy_type);
    } else {
      item.strategy_type = reco::kNoStrategy;
    }

    item.lr_score = item_misc.lr_score();
    item.fm_score = item_misc.fm_score();
    item.reco_score = item_misc.reco_score();
    cached_items->push_back(item);
  }
  if ((int)cached_items->size() < req_num) {
    cached_items->clear();
  }
}

void PersonalReco::CalcPreferCategories() {
  prefer_categories_.clear();

  // 用户感兴趣的类别 top 3
  TopNHeap<std::string> category_topn(3);
  auto user_feas = reco_request_->user_feas;
  const auto& ref_l1_cates = user_feas->merged_fea.l1_cates;
  for (auto iter = ref_l1_cates.begin(); iter != ref_l1_cates.end(); ++iter) {
    category_topn.add(iter->first, iter->second);
  }

  std::vector<std::pair<std::string, double> > category_vec;
  category_topn.get_top_n_unordered(&category_vec);

  for (auto i = 0u; i < category_vec.size(); ++i) {
    // 占比和量都必须满足
    if (category_vec[i].second < 0.2) continue;
    if (category_vec[i].second * user_feas->merged_info.total_click_num < 10) continue;
    prefer_categories_.insert(category_vec[i].first);
  }
}

void PersonalReco::CalcGlobalDirectIrItems(std::vector<ItemInfo>* direct_ir_items) {
  direct_ir_items->clear();

  const auto& profile_subscript_sources = reco_request_->user_feas->behavior_fea.subscript_sources;
  const auto& profile_subscript_tags = reco_request_->user_feas->behavior_fea.subscript_words;
  if (profile_subscript_sources.empty() && profile_subscript_tags.empty()) return;

  const auto* subscript_sources = &profile_subscript_sources;
  const auto* subscript_tags = &profile_subscript_tags;

  int session_pv = reco_request_->user_feas->st_fea.session_pv;
  base::dense_hash_map<std::string, float> mid_subscript_sources;
  base::dense_hash_map<std::string, float> mid_subscript_tags;
  mid_subscript_sources.set_empty_key("");
  mid_subscript_tags.set_empty_key("");

  uint32 direct_ir_num = reco_request_->request->return_num() >= 10 ? 3 : 2;
  if (session_pv > 3) {
    // 本次 session 已经刷了 3 次，则只选择高权重的订阅源和订阅标签
    // 订阅源
    for (auto it = profile_subscript_sources.begin(); it != profile_subscript_sources.end(); ++it) {
      if (it->second < 0.9) continue;
      mid_subscript_sources.insert(*it);
    }
    subscript_sources = &mid_subscript_sources;

    // 订阅标签
    for (auto it = profile_subscript_tags.begin(); it != profile_subscript_tags.end(); ++it) {
      if (it->second < 0.9) continue;
      mid_subscript_tags.insert(*it);
    }
    subscript_tags = &mid_subscript_tags;

    direct_ir_num = 2;
  }

  if (subscript_sources->empty() && subscript_tags->empty()) return;

  // 根据订阅数据返回候选集
  std::vector<ItemInfo> candidates;
  static const int kMaxSubscriptCandidateItem = 200;
  candidates_extractor_->GetSubscriptCandidates(reco_request_, *subscript_sources, *subscript_tags,
                                                &candidates, kMaxSubscriptCandidateItem);

  // 触发
  std::vector<ItemInfo> ir_items;
  retrieval_->RetrieveInCategory("", reco_request_, std::vector<ItemInfo>(), candidates, &ir_items);

  // 触发直通车
  retrieval_->ExtractIrDirectItems(ir_items, direct_ir_items, direct_ir_num);

  LOG(INFO) << "global direct ir, session_pv:" << session_pv
            << ", req_num:" << direct_ir_num
            << ", ret_num:" << direct_ir_items->size();
}

std::string PersonalReco::GetStandardSubCate(const std::string& cate, const std::string& sub_cate) {
  static const std::unordered_set<std::string> kSportMajorSubCates = {"cba", "nba", "国内足球", "国际足球"};
  static const std::unordered_set<std::string> kFinanceMajorSubCates = {"经济民生", "股票"};
  static const std::unordered_set<std::string> kTechMajorSubCates = {"手机", "互联网"};
  static const std::string kDftSubCate = "other";
  if (sub_cate.empty()) return kDftSubCate;
  const std::unordered_set<std::string>* major_subcates = NULL;
  if (cate == "体育") {
    major_subcates = &kSportMajorSubCates;
  } else if (cate == "财经") {
    major_subcates = &kFinanceMajorSubCates;
  } else if (cate == "科技") {
    major_subcates = &kTechMajorSubCates;
  } else {
    return kDftSubCate;
  }
  const auto iter = major_subcates->find(sub_cate);
  if (iter != major_subcates->end()) {
    return *iter;
  }
  return kDftSubCate;
}

}  // namespace leafserver
}  // namespace reco

