#pragma once
#include <utility>
#include <string>
#include <vector>
#include <unordered_set>

#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

#include "reco/serv/reco_leaf/proto/leaf_data.pb.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/news_ranker.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/hot_ranker.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/pic_ranker.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/shopping_ranker.h"
#include "reco/serv/reco_leaf/strategy/component/retrieval/news_retrieval.h"
#include "reco/serv/reco_leaf/strategy/component/cache/reco_result_cache.h"
#include "reco/serv/reco_leaf/strategy/reco/offline/item_dict_manager.h"

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"

#include "reco/bizc/proto/user.pb.h"
#include "base/time/time.h"

namespace reco {
class NewsIndex;

namespace leafserver {
class ItemDictManager;

class PersonalReco {
 public:
  explicit PersonalReco(const reco::NewsIndex* news_index);
  ~PersonalReco();

  void DoPersonalReco(const RecoRequest* request,
                      const ManualRecoData* manual_data,
                      std::vector<ItemInfo>* personal_items,
                      RecoContext* context);

  const std::unordered_map<uint64, ItemDictData> *GetPersonalItemDicts() {
    return &personal_item_dicts_;
  }

 private:
  ///////////////////////////////////////// 三类推荐：推荐频道 / 热点频道 / 普通垂直频道
  // 垂直频道推荐算法
  void DoVerticleChannelReco(std::vector<ItemInfo>* personal_items, RecoContext* context);
  // 综合频道(推荐频道)推荐算法
  void DoComplexChannelReco(std::vector<ItemInfo>* personal_items, RecoContext* context);
  // 热点频道推荐算法
  void DoHotChannelReco(std::vector<ItemInfo>* personal_items, RecoContext* context);

  ///////////////////////////////////////////////// 融合算法，类别间 / 类别内
  // 所有类别之间的融合策略
  void MergeBetweenCategoriesOld(const std::vector<std::pair<float, std::vector<ItemInfo> > >& div_items_vec,
                              std::vector<ItemInfo>* ret_items, int req_num);
  void MergeBetweenCategories(const std::vector<std::pair<float, std::vector<ItemInfo> > >& div_items_vec,
                                 std::vector<ItemInfo>* ret_items, int req_num);
  // category 或 channel 内部的 merge / rerank
  void MergeAndReRankInCategory(const std::string& category,
                                const std::vector<ItemInfo> &direct_ir_items,
                                const std::vector<ItemInfo> &rank_items,
                                const std::vector<ItemInfo> &candidate_items,
                                std::vector<ItemInfo>* ret_items);

  ////////////////////////////////////////////////////////////// 类别内的重排
  // 是否进行二级类别重排序
  bool IfReRankBySndCategory(const std::string& category, int64 channel_id) const;
  // rerank
  void ReRankBySndCategory(const std::string& category, int64 channel_id,
                           const std::vector<ItemInfo>& org_items,
                           std::vector<ItemInfo>* ret_items);

  /////////////////////////////////////////////////////////////// cache
  // 综合频道的 cache
  void GetComplexCachedItems(std::vector<ItemInfo>* personal_items, int req_num);
  // 垂直频道的 cache
  void GetVerticalCachedItems(std::vector<ItemInfo>* personal_items, int req_num);

  ////////////////////////////////////////////////////////////// 推荐流程相关
  // 根据用户类别分布，获取用户在这些类别中的候选列表（多线程）
  void GetCandidates(const std::vector<std::pair<float, reco::Category>> *category_distributes,
                     std::unordered_map<std::string, std::vector<ItemInfo>> *candidate_map);
  // 给定类别，获取对应的候选集合
  void GetCategoryCandidates(const reco::Category category, const RecoRequest* req,
                             std::unordered_map<std::string, std::vector<ItemInfo>> *candidate_map);
  // 每个类别的推荐
  void CategoryDistributeReco(const std::vector<std::pair<float, reco::Category>> *category_distributes,
                              std::vector<std::pair<float, std::vector<ItemInfo> > > *diversity_items_vec,
                              RecoDebugger* debugger);
  // 类别内推荐
  void CategoryReco(const reco::Category category,
                    const float category_ratio,
                    const int diversity_idx,
                    std::vector<std::pair<float, std::vector<ItemInfo> > > *diversity_items_vec,
                    RecoDebugger* debugger);
// 推进频道全局直接触发 item
  void CalcGlobalDirectIrItems(std::vector<ItemInfo>* ir_items);

  //////////////////////////////////////////////////////////// 限制及多样化
  // 自媒体条数限制
  void DoWemediaNumLimit(std::vector<ItemInfo>* ret_items);

  /////////////// 内部变量的赋值重置
  // user feature 重置
  void SetUserFeature();
  // user group model 重置
  // void SetUGM();

  // 计算用户喜好类别
  void CalcPreferCategories();
  // 获取二级类别别名
  std::string GetStandardSubCate(const std::string& cate, const std::string& sub_cate);
  // 打标签：运营 / 热门 / exploit / explore
  void MarkAppIcon(std::vector<ItemInfo>* reco_items) const;

 private:
  static const uint32 kTopNSize = 300;
  static const uint32 kNewsNumPerScreen = 8;
  static const uint32 kMaxCacheItemNum = 50;
  static const int kRecoScoreFactor = 1000000;

  const reco::NewsIndex* news_index_;
  const RecoRequest* reco_request_;

  const ManualRecoData* manual_data_;

  bool do_personal_reco_;

  std::unordered_set<std::string> prefer_categories_;

  std::vector<std::pair<float, std::vector<ItemInfo> > > diversity_items_vec_;

  CandidatesExtractor* candidates_extractor_;
  RecoResultCache* reco_cache_;
  NewsRetrieval* retrieval_;
  NewsRanker* ranker_;
  HotRanker* hot_ranker_;
  PicRanker* pic_ranker_;
  ShoppingRanker* shopping_ranker_;


  base::PseudoRandom* random_;
  serving_base::Timer timer_;
  mutable thread::Mutex mutex_;

  reco::reco_model::UserFeature proc_feature_;
  // std::vector<base::dense_hash_map<uint64, reco::reco_model::ModelNode>*> ugm_model_;
  // std::vector<std::pair<std::string, float>> remain_prefix_;

  // item dicts
  std::unordered_map<uint64, ItemDictData> personal_item_dicts_;
  ItemDictManager* item_dict_manager_;
};

inline void PersonalReco::SetUserFeature() {
  // 重置 procfeature
  proc_feature_.ResetUserFeature();

  std::string province, city, fr, net;
  if (reco_request_->request->has_uc_user_param()) {
    if (reco_request_->request->uc_user_param().has_province()) {
      province = reco_request_->request->uc_user_param().province();
    }
    if (reco_request_->request->uc_user_param().has_city()) {
      city = reco_request_->request->uc_user_param().city();
    }

    if (reco_request_->request->uc_user_param().has_fr()) {
      fr = reco_request_->request->uc_user_param().fr();
    }

    if (reco_request_->request->uc_user_param().has_nt()) {
      net = reco_request_->request->uc_user_param().nt();
    }
  }
  proc_feature_.user_id = reco_request_->user_info->identity().user_id();
  proc_feature_.province = province;
  proc_feature_.city = city;
  proc_feature_.fr = fr;
  proc_feature_.net = net;
  proc_feature_.reco_timestamp = reco_request_->current_timestamp;

  proc_feature_.SetUserFeature(*reco_request_->user_info);
}

/*
inline void PersonalReco::SetUGM() {
  ugm_model_.clear();
  remain_prefix_.clear();
  reco::reco_model::RecoModelProc::Instance()->GetUserGroupModel(proc_feature_.ugp_key_vals,
                                                                 &ugm_model_, &remain_prefix_);
}
*/

struct SortData {
  int fst_idx;
  int snd_idx;
  bool used;
  SortData() : fst_idx(0), snd_idx(0), used(false) {}

  bool operator > (const SortData& rhs) const {
    if (this->fst_idx < rhs.fst_idx) {
      return true;
    } else if (this->fst_idx > rhs.fst_idx) {
      return false;
    }
    if (this->snd_idx < rhs.snd_idx) {
      return true;
    } else if (this->snd_idx > rhs.snd_idx) {
      return false;
    }
    return true;
  }

  bool operator < (const SortData& rhs) const {
    return !(*this > rhs);
  }
};

}  // namespace leafserver
}  // namespace reco

