#pragma once
#include <unordered_set>
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"

namespace reco {
class NewsIndex;

namespace leafserver {
class POIReco {
 public:
  explicit POIReco(const reco::NewsIndex* index);
  ~POIReco();

  void DoPoiReco(const RecoRequest* reco_request,
                 std::vector<ItemInfo>* poi_items,
                 std::unordered_map<uint64, POITag> *item_poi_tags,
                 double ctr_thr, int max_return, bool city_level = true);

 private:
  bool POIItemFilter(const ItemInfo &item, double ctr_thr);
  void MarkRecoBranch(std::vector<ItemInfo>* items);

  std::string GetPOITagSuffix(const ItemInfo& item);
  bool POIItemMatchProvince(const ItemInfo& item, int64 province_id);

 private:
  static const int kMaxPOICandidateNum = 200;
  static const std::unordered_set<std::string> kPOIRecoFreeCategoties;
  static const std::unordered_set<std::string> kPOIRecoLimitCategoties;

  const NewsIndex* news_index_;
  CandidatesExtractor* candidates_extractor_;

};
}
}
