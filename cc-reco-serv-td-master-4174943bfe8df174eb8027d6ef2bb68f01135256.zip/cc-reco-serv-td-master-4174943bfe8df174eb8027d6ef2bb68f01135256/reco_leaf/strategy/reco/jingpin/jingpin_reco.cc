#include "reco/serv/reco_leaf/strategy/reco/jingpin/jingpin_reco.h"
#include <string>
#include <vector>

#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/jingpin_ranker.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/reco_index/item_info.h"

namespace reco {
class NewsIndex;

namespace leafserver {

JingpinReco::JingpinReco(const reco::NewsIndex* index) {
  news_index_ = index;
  jingpin_ranker_ = new JingpinRanker(news_index_);
}

JingpinReco::~JingpinReco() {
  delete jingpin_ranker_;
}

void JingpinReco::GetJingpinItems(const RecoRequest& request,
                                  std::vector<ItemInfo>* ret_items,
                                  RecoDebugger* debugger) {
  ret_items->clear();
  // 1) get default reco as candidates
  const std::vector<ItemInfo>* candidates = news_index_->GetJingpinDefaultReco();
  ir_results_.clear();
  if (ir_results_.capacity() < candidates->size()) {
    ir_results_.reserve(candidates->size());
  }
  // 2) general filter
  for (size_t i = 0; i < candidates->size(); ++i) {
    reco::filter::FilterReason filter_reason;
    if (NewsFilter::IsGeneralFiltered(&request, request.shown_dict,
                                      (*candidates)[i], &filter_reason)) {
      if (debugger != NULL) {
        debugger->SetItemFilterReason((*candidates)[i].item_id, filter_reason);
      }
      continue;
    }
    ir_results_.push_back((*candidates)[i]);
  }
  // 3) rank
  jingpin_ranker_->Rank("", request, ir_results_, ret_items);
  // 4) strategy

  LOG(INFO) << "get jingping items: " << ret_items->size();
}

}
}
