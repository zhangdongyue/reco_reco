#pragma once
#include <vector>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

namespace reco {
class NewsIndex;

namespace leafserver {
class RecoRequest;
class JingpinRanker;
class JingpinReco {
 public:
  explicit JingpinReco(const reco::NewsIndex* index);

  ~JingpinReco();

  void GetJingpinItems(const RecoRequest& request,
                       std::vector<ItemInfo>* reco_items,
                       RecoDebugger* debugger);
 private:
  const NewsIndex* news_index_;
  std::vector<ItemInfo> ir_results_;
  JingpinRanker* jingpin_ranker_;
};
}
}

