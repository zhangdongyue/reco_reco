#pragma once

#include <string>
#include <vector>
#include <unordered_set>

#include "reco/serv/reco_leaf/strategy/reco/offline/item_dict_manager.h"
#include "reco/serv/reco_model/frame/user_feature.h"
#include "reco/serv/reco_model/frame/user_group_model.h"

namespace reco {
namespace leafserver {

// 模型相关的设置，从总控往 ranker 里面传
//
struct RankModelEnv{
  std::unordered_map<uint64, ItemDictData> cf_item_dicts;

  reco::reco_model::UserFeature proc_feature;
  std::vector<base::dense_hash_map<uint64, reco::reco_model::ModelNode>*> ugm_model;
  std::vector<std::pair<std::string, float>> remain_prefix;
};

// 用于多队列排序
// TODO(jianhuang) 这个数据结构及命名可以优化下
//
struct SortMidData {
  int fst_idx;
  int snd_idx;
  bool used;
  SortMidData() : fst_idx(0), snd_idx(0), used(false) {}

  bool operator > (const SortMidData& rhs) const {
    if (this->fst_idx < rhs.fst_idx) {
      return true;
    } else if (this->fst_idx > rhs.fst_idx) {
      return false;
    }
    if (this->snd_idx < rhs.snd_idx) {
      return true;
    } else if (this->snd_idx > rhs.snd_idx) {
      return false;
    }
    return true;
  }

  bool operator < (const SortMidData& rhs) const {
    return !(*this > rhs);
  }
};

}  // namespace leafserver
}  // namespace reco

