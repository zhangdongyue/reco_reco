#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/proto/leaf_data.pb.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/reco/interest/interest_common.h"

namespace reco {
namespace leafserver {
class CandidatesExtractor;
class NewsRetrieval;
class NewsRanker;

// 类别推荐请求使用的参赛列表
// 作为一个结构体的原因是考虑后续存在扩展的可能
//
struct CateRecoAlgParam {
  // 最大返回条数，-1 表示不限制，由算法自行决定返回几条
  int max_ret;

  CateRecoAlgParam() : max_ret(-1) {
  }
};

// 类别内 推荐策略分支 基类
//
class CateRecoAlgBase {
 public:
  CateRecoAlgBase() {}

  virtual ~CateRecoAlgBase() {}

  // 给定 category，返回对应策略分支的推荐结果
  virtual bool DoRecoInCategory(const RecoRequest* reco_request,
                                const ManualRecoData* manual_data,
                                const reco::Category& category,
                                const CateRecoAlgParam& alg_param,
                                std::vector<ItemInfo>* ret_items,
                                RecoDebugger* debugger) = 0;

  // 给定 cid，返回对应策略分支的推荐结果
  virtual bool DoRecoInChannel(const RecoRequest* reco_request,
                               const ManualRecoData* manual_data,
                               int64 cid,
                               const CateRecoAlgParam& alg_param,
                               std::vector<ItemInfo>* ret_items,
                               RecoDebugger* debugger)  = 0;

  // 获取策略分支类型
  virtual reco::RecoStrategyBranch strategy_branch() const = 0;

  // 设置排序模型环境
  virtual void SetRankModelEnv(const RankModelEnv& model_env) = 0;

};

} // namespace leaf
} // namespace reco
