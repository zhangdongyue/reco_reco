#include "reco/serv/reco_leaf/strategy/reco/interest/interest_reco.h"
#include <algorithm>

// #include "reco/serv/reco_leaf/strategy/reco/offline/cf_item_dict.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"

namespace reco {
namespace leafserver {
// DEFINE_bool(open_cf_tune_switch, false, "是否开启 cf tuning 策略");

const int InterestReco::kTopNSize = 200;
const int InterestReco::kNewsNumPerScreen = 8;

InterestReco::InterestReco(const reco::NewsIndex* index) {
  news_index_ = index;
  random_ = new base::PseudoRandom(base::GetTimestamp());
  cate_reco_ = new CateRecoManager();
  subscript_reco_ = new SubscriptRecoManager();
  // item_dict_manager_ = new ItemDictManager();
  // item_dict_manager_->AddDict(new CFItemDict());
}

InterestReco::~InterestReco() {
  delete random_;
  delete cate_reco_;
  delete subscript_reco_;
  // delete item_dict_manager_;
}

void InterestReco::DoInterestReco(const RecoRequest* request,
                                  const ManualRecoData* manual_data,
                                  std::vector<ItemInfo>* reco_items,
                                  RecoContext* context) {
  reco_request_ = request;
  manual_data_ = manual_data;
  SetRankModelEnv();

  if (request->channel_id == reco::common::kRecoChannelId) {
    DoComplexChannelReco(reco_items, context);
  } else {
    DoVerticleChannelReco(reco_items, context);
  }
}

void InterestReco::DoComplexChannelReco(std::vector<ItemInfo>* reco_items, RecoContext* context) {
  int req_num = reco_request_->request->return_num();

  // subscript reco items
  timer_.Start();
  subscript_reco_items_.clear();
  subscript_reco_->DoSubscriptReco(reco_request_, manual_data_, &subscript_reco_items_, 3);
  context->cost_trace()->ccs = timer_.Stop();

  // category reco items
  timer_.Start();
  const auto category_distributes = reco_request_->category_distributes;
  cate_items_vec_.clear();
  cate_items_vec_.resize(category_distributes->size());
  MultiCategoryReco(*category_distributes, &cate_items_vec_, context);
  context->debugger()->TracePersonalCategoryItems(*category_distributes, cate_items_vec_);
  context->cost_trace()->rks = timer_.Stop();

  timer_.Start();
  MergeComplexReco(reco_items, req_num, context);
  context->cost_trace()->mcs = timer_.Stop();
}

void InterestReco::DoVerticleChannelReco(std::vector<ItemInfo>* reco_items, RecoContext* context) {
  timer_.Start();
  channel_reco_items_.clear();
  cate_reco_->DoRecoInChannel(reco_request_, manual_data_, reco_request_->channel_id,
                              &channel_reco_items_, context);
  reco_items->insert(reco_items->end(), channel_reco_items_.begin(), channel_reco_items_.end());
  context->cost_trace()->rks = timer_.Stop();
}

void InterestReco::MergeComplexReco(std::vector<ItemInfo>* ret_items, int req_num,
                                    RecoContext* context) {
  ret_items->clear();

  /////////// 1. 订阅推荐
  // 订阅直接全插入，由订阅推荐模块决定此次出几条订阅相关的文章
  for (size_t i = 0; i < subscript_reco_items_.size(); ++i) {
    ret_items->push_back(subscript_reco_items_.at(i));
  }

  /////////// 2. 类别推荐
  // 各个类别的概率分布
  float acc_weight = 0;
  for (int i = 0; i < (int)cate_items_vec_.size(); ++i) {
    acc_weight += cate_items_vec_.at(i).first;
  }
  int cate_req_num = std::min(int(req_num - ret_items->size()), kNewsNumPerScreen);
  if (acc_weight < 1e-4 || cate_req_num <= 0) {
    for (int i = 0; i < (int)cate_items_vec_.size(); ++i) {
      const std::vector<ItemInfo>& items = cate_items_vec_.at(i).second;
      for (int k = 0; k < (int)items.size(); ++k) {
        ret_items->push_back(items[k]);
      }
    }
    return;
  }
  // 计算本批次推荐每个类别的下发数
  const uint32 kMaxNumPerCate = 3;
  int acc_num = 0;
  std::vector<uint32> num_vec;
  num_vec.resize(cate_items_vec_.size());
  for (int i = 0; i < (int)cate_items_vec_.size(); ++i) {
    const std::vector<ItemInfo>& div_items = cate_items_vec_.at(i).second;
    if (div_items.empty()) continue;
    float ratio = (cate_items_vec_.at(i).first / acc_weight) * cate_req_num;
    int num = (int)ratio;
    if (num >= (int)kMaxNumPerCate) {
      num = kMaxNumPerCate;
    } else if (random_->GetDouble() <= ratio - num) {
      ++num;
    }
    num_vec[i] = std::min(static_cast<int>(div_items.size()), num);
    acc_num += num_vec[i];
  }
  if (acc_num < cate_req_num) {
    for (int i = 0; i < (int)num_vec.size(); ++i) {
      if (acc_num >= cate_req_num) break;
      const std::vector<ItemInfo>& items = cate_items_vec_[i].second;
      if (num_vec[i] < kMaxNumPerCate && num_vec[i] < items.size()) {
        num_vec[i] += 1;
        acc_num += 1;
      }
    }
    if (acc_num < cate_req_num
        && !num_vec.empty()
        && num_vec[0] < cate_items_vec_[0].second.size()) {
      num_vec[0] += std::min(cate_req_num - acc_num, int(cate_items_vec_[0].second.size() - num_vec[0]));
    }
  }

  static const float kCateWtBoostPow = 1;
  std::vector<std::pair<float, SortMidData> > sort_vec;
  for (int idx = 0; idx < (int)cate_items_vec_.size(); ++idx) {
    const std::vector<ItemInfo>& div_items = cate_items_vec_.at(idx).second;
    float weight = cate_items_vec_.at(idx).first;
    float last_reco_score = 0;
    SortMidData sort_data;
    for (int jdx = div_items.size() - 1; jdx >= 0; --jdx) {
      const ItemInfo& item = div_items.at(jdx);
      float reco_score = std::max(last_reco_score + 1, (float)item.reco_score);
      last_reco_score = reco_score;
      reco_score *= std::pow((1 + weight), kCateWtBoostPow);
      sort_data.fst_idx = idx;
      sort_data.snd_idx = jdx;
      sort_data.used = false;
      sort_vec.push_back(std::make_pair(reco_score, sort_data));
    }
  }

  std::sort(sort_vec.begin(), sort_vec.end(), std::greater<std::pair<float, SortMidData>>());

  const int kProcessScreenNum = std::min((size_t)15, sort_vec.size() / cate_req_num);
  for (int i = 0; i < kProcessScreenNum; ++i) {
    std::vector<uint32> put_vec(num_vec.size(), 0);
    for (size_t j = 0; j < sort_vec.size(); ++j) {
      SortMidData& sort_data = sort_vec[j].second;
      if (sort_data.used) continue;
      int fst_idx = sort_data.fst_idx;
      int snd_idx = sort_data.snd_idx;
      if (put_vec[fst_idx] < num_vec[fst_idx]) {
        ++put_vec[fst_idx];
        sort_data.used = true;
        ret_items->push_back(cate_items_vec_.at(fst_idx).second.at(snd_idx));
      }
    }
  }
  for (size_t j = 0; j < sort_vec.size(); ++j) {
    SortMidData& sort_data = sort_vec[j].second;
    if (sort_data.used) continue;
    int fst_idx = sort_data.fst_idx;
    int snd_idx = sort_data.snd_idx;
    sort_data.used = true;
    ret_items->push_back(cate_items_vec_.at(fst_idx).second.at(snd_idx));
  }
}

void InterestReco::MultiCategoryReco(
    const std::vector<std::pair<float, reco::Category>>& category_distributes,
    std::vector<std::pair<float, std::vector<ItemInfo> > >* cate_items_vec,
    RecoContext* context) {

  int thread_num = LeafDataManager::GetGlobalData()->GetParallelNum();
  if (!reco_request_->user_param_info.is_inner_qudao) {
    thread_num = std::max(thread_num, 3);
  }

  thread::ThreadPool pool(thread_num);
  int cate_idx = 0;
  for (auto i = 0u; i < category_distributes.size(); ++i) {
    const reco::Category& category = category_distributes.at(i).second;
    if (category.category() == reco::common::kHotNewsCategory
        || category.category() == reco::common::kVideoCategory)
      continue;

    pool.AddTask(::NewCallback(this, &InterestReco::CategoryReco,
                               category, category_distributes.at(i).first,
                               &cate_items_vec->at(cate_idx), context));
    ++cate_idx;

    if (!reco_request_->user_param_info.is_inner_qudao
        && LeafDataManager::GetGlobalData()->GetSysLevel() > kSysBusy
        && cate_idx > thread_num) {
      break;
    }
  }

  pool.JoinAll();
  // context->cost_trace()->crt = concurrent_num;
}

void InterestReco::CategoryReco(const reco::Category category, const float category_ratio,
                                std::pair<float, std::vector<ItemInfo> >* cate_items,
                                RecoContext* context) {
  cate_items->first = category_ratio;
  std::vector<ItemInfo>& reco_items = cate_items->second;
  cate_reco_->DoRecoInCategory(reco_request_, manual_data_, category, &reco_items, context, category_ratio);
}

void InterestReco::SetRankModelEnv() {
  // 1. set user feature
  // 重置 procfeature
  reco::reco_model::UserFeature& proc_feature = model_env_.proc_feature;
  proc_feature.ResetUserFeature();
  std::string province, city, fr, net;
  if (reco_request_->request->has_uc_user_param()) {
    if (reco_request_->request->uc_user_param().has_province()) {
      province = reco_request_->request->uc_user_param().province();
    }
    if (reco_request_->request->uc_user_param().has_city()) {
      city = reco_request_->request->uc_user_param().city();
    }
    if (reco_request_->request->uc_user_param().has_fr()) {
      fr = reco_request_->request->uc_user_param().fr();
    }
    if (reco_request_->request->uc_user_param().has_nt()) {
      net = reco_request_->request->uc_user_param().nt();
    }
  }
  proc_feature.user_id = reco_request_->user_info->identity().user_id();
  proc_feature.province = province;
  proc_feature.city = city;
  proc_feature.fr = fr;
  proc_feature.net = net;
  proc_feature.reco_timestamp = reco_request_->current_timestamp;
  proc_feature.SetUserFeature(*reco_request_->user_info);

  // 2. set ugm model
  model_env_.ugm_model.clear();
  model_env_.remain_prefix.clear();
  /*
  reco::reco_model::RecoModelProc::Instance()->GetUserGroupModel(
      proc_feature.ugp_key_vals, &model_env_.ugm_model, &model_env_.remain_prefix);
  */

  // 3. set item cf dict
  model_env_.cf_item_dicts.clear();
  /*
  if (FLAGS_open_cf_tune_switch) {
    if (!item_dict_manager_->FillData(*reco_request_, &model_env_.cf_item_dicts)) {
      LOG(ERROR) << base::StringPrintf("get personal item dict failed! [recoid: %s][user id: %lu]",
                                       reco_request_->request->reco_id().c_str(),
                                       reco_request_->request->user().user_id());
    }
  }
  */

  cate_reco_->SetRankModelEnv(model_env_);
}

}  // namespace leafserver
}  // namespace reco
