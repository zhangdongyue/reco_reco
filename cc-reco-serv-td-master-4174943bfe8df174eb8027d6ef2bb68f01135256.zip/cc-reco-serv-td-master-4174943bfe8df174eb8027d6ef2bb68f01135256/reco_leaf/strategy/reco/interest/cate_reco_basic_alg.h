#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/serv/reco_leaf/proto/leaf_data.pb.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/component/retrieval/news_retrieval.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/news_ranker.h"
#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/reco/interest/cate_reco_alg_base.h"

namespace reco {
namespace leafserver {

// 类别内 推荐策略分支 基类
// NOTE(all) must multi thread safe
//
class CateRecoBasicAlg: public CateRecoAlgBase {
 public:
  CateRecoBasicAlg();

  virtual ~CateRecoBasicAlg();

  // 给定 category，返回对应策略分支的推荐结果
  virtual bool DoRecoInCategory(const RecoRequest* reco_request,
                                const ManualRecoData* manual_data,
                                const reco::Category& category,
                                const CateRecoAlgParam& alg_param,
                                std::vector<ItemInfo>* ret_items,
                                RecoDebugger* debugger);

  // 给定 cid，返回对应策略分支的推荐结果
  virtual bool DoRecoInChannel(const RecoRequest* reco_request,
                               const ManualRecoData* manual_data,
                               int64 cid,
                               const CateRecoAlgParam& alg_param,
                               std::vector<ItemInfo>* ret_items,
                               RecoDebugger* debugger);

  // 获取策略分支类型
  virtual reco::RecoStrategyBranch strategy_branch() const {
    return reco::kCateBasicBranch;
  }

  // 设置排序模型环境
  virtual void SetRankModelEnv(const RankModelEnv& model_env) {
    // ranker_->SetEnv(&model_env.proc_feature, &model_env.ugm_model, &model_env.remain_prefix);
    ranker_->SetEnv(&model_env.proc_feature);
    ranker_->SetPersonalItemDicts(&model_env.cf_item_dicts);
  }

 private:
  void FillRecoBranch(std::vector<ItemInfo>* items) const;

 private:
  const reco::NewsIndex* news_index_;

  static const int kTopN;

  CandidatesExtractor* candidate_extractor_;
  NewsRetrieval* retrieval_;
  NewsRanker* ranker_;
};

inline void CateRecoBasicAlg::FillRecoBranch(std::vector<ItemInfo>* items) const {
  for (size_t i = 0; i < items->size(); ++i) {
    items->at(i).strategy_branch = strategy_branch();
  }
}
} // namespace leaf
} // namespace reco
