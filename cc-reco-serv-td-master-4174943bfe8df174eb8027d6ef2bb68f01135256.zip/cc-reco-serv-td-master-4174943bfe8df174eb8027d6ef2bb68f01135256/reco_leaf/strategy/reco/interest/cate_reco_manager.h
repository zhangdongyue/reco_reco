#pragma once
#include <utility>
#include <string>
#include <vector>
#include <unordered_set>

#include "reco/serv/reco_leaf/strategy/reco/interest/cate_reco_alg_base.h"
#include "reco/serv/reco_leaf/strategy/reco/interest/interest_common.h"
#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/component/cache/reco_result_cache.h"

namespace reco {
namespace leafserver {

struct CateRecoData {
  std::vector<ItemInfo> head_items;
  std::vector<ItemInfo> basic_items;
  void Reset() {
    head_items.clear();
    basic_items.clear();
  }
};

// 类别 / 频道 基于兴趣点推荐 管理类
// TODO(jianhuang) 这块的代码海比较乱，需要整理和继续拆分
//
class CateRecoManager {
 public:
  CateRecoManager();
  ~CateRecoManager();

  // 类别内推荐
  bool DoRecoInCategory(const RecoRequest* reco_request, const ManualRecoData* manual_data,
                        const reco::Category& category, std::vector<ItemInfo>* items, RecoContext* context,
                        float cate_ratio);

  // 频道内推荐
  bool DoRecoInChannel(const RecoRequest* reco_request, const ManualRecoData* manual_data,
                       int64 cid, std::vector<ItemInfo>* items, RecoContext* context);

  void SetRankModelEnv(const RankModelEnv& model_env) {
    basic_reco_->SetRankModelEnv(model_env);
  }

 private:
  void MergeAndRerank(const RecoRequest* reco_request,
                      const std::string& category, int64 cid,
                      const CateRecoData& reco_data,
                      std::vector<ItemInfo>* ret_items);
  // 是否进行二级类别重排序
  bool IfReRankBySndCategory(const std::string& category, int64 channel_id) const;
  // rerank
  void ReRankBySndCategory(const RecoRequest* reco_request,
                           const std::string& category, int64 channel_id,
                           const std::vector<ItemInfo>& org_items,
                           std::vector<ItemInfo>* ret_items);
  void SportSndCategoryRerank(const RecoRequest* reco_request,
                              const std::string& category, int64 channel_id,
                              const std::vector<ItemInfo>& org_items,
                              std::vector<ItemInfo>* ret_items);
  // 获取二级类别别名
  std::string GetStandardSubCate(const std::string& cate, const std::string& sub_cate);
  void SubCateContinueLimit(const std::string& cate,
                            std::unordered_map<std::string, float>* cate_continue_items) const;

  void FillRecoStrategyType(const RecoRequest* reco_request, std::vector<ItemInfo>* reco_items) const;

  // cache 相关
  // TODO(jianhuang) cache 的代码 移到同一类里面
  bool GetRecoDataFromCache(const RecoRequest* reco_request,
                            const std::string& category, int64 cid,
                            CateRecoData* reco_data) const;
  bool SetRecoDataToCache(const RecoRequest* reco_request,
                          const std::string& category, int64 cid,
                          const CateRecoData& reco_data) const;
  bool CanUseCache(const RecoRequest* reco_request, const std::string& category, int64 cid) const;
  std::string GenCacheKey(const RecoRequest* reco_request,
                          const std::string& category, int64 cid) const;
  void ConvertToCacheData(const RecoRequest* reco_request, const CateRecoData& reco_data,
                          CachedRecoBranchData* cache_data) const;
  void ParseFromCacheData(const RecoRequest* reco_request, const CachedRecoBranchData& cache_data,
                          CateRecoData* reco_data) const;
  void ItemInfoToItemMisc(const ItemInfo& item_info, CachedItemMisc* item_misc) const;
  void ItemMiscToItemInfo(const CachedItemMisc& item_misc, ItemInfo* item_info) const;

 private:
  static const int kRecoScoreFactor;
  static const uint32 kNewsNumPerScreen;
  static const uint32 kBasicReqNum;
  static const uint32 kHeadReqNum;
  static const uint32 kTopNSize;

  const reco::NewsIndex* news_index_;
  const RecoRequest* reco_request_;

  CateRecoAlgBase* basic_reco_;
  CateRecoAlgBase* head_reco_;

  RecoResultCache* reco_cache_;

  base::PseudoRandom* random_;
};

}  // namespace leafserver
}  // namespace reco

