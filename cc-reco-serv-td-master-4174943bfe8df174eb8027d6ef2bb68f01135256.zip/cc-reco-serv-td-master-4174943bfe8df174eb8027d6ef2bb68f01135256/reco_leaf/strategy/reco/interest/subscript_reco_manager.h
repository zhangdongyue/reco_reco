#pragma once
#include <utility>
#include <string>
#include <vector>
#include <unordered_set>

#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/component/retrieval/news_retrieval.h"
#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"

namespace reco {
namespace leafserver {
// 基于用户订阅的推荐
//
// TODO(jianhuang) 综合考虑用户历史订阅推荐，优化订阅 item 的推荐算法
// TODO(jianhuang) 支持按类别进行订阅推荐
//
class SubscriptRecoManager {
 public:
  SubscriptRecoManager();
  ~SubscriptRecoManager();

  // 获取订阅推荐列表
  void DoSubscriptReco(const RecoRequest* request, const ManualRecoData* manual_data,
                       std::vector<ItemInfo>* reco_items, int max_ret);

  // 获取策略分支类型
  reco::RecoStrategyBranch strategy_branch() const {
    return reco::kSubscriptBranch;
  }

 private:
  void FillRecoBranch(std::vector<ItemInfo>* items) const;

 private:
  const reco::NewsIndex* news_index_;
  const RecoRequest* reco_request_;

  CandidatesExtractor* candidate_extractor_;
  NewsRetrieval* retrieval_;
};

inline void SubscriptRecoManager::FillRecoBranch(std::vector<ItemInfo>* items) const {
  for (size_t i = 0; i < items->size(); ++i) {
    items->at(i).strategy_branch = strategy_branch();
  }
}

}  // namespace leafserver
}  // namespace reco

