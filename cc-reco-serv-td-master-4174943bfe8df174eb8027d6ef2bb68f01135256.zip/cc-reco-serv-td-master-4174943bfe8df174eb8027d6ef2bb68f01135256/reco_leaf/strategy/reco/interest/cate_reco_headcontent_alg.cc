#include "reco/serv/reco_leaf/strategy/reco/interest/cate_reco_headcontent_alg.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/component/retrieval/news_retrieval.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/news_ranker.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/frame/global_conf.h"

namespace reco {
namespace leafserver {
const int CateRecoHeadContentAlg::kTopN = 2;

CateRecoHeadContentAlg::CateRecoHeadContentAlg() {
  news_index_ = LeafDataManager::GetGlobalData()->news_index;
}

CateRecoHeadContentAlg::~CateRecoHeadContentAlg() {}

bool CateRecoHeadContentAlg::DoRecoInCategory(const RecoRequest* reco_request,
                                              const ManualRecoData* manual_data,
                                              const reco::Category& category,
                                              const CateRecoAlgParam& alg_param,
                                              std::vector<ItemInfo>* ret_items,
                                              RecoDebugger* debugger) {
  ret_items->clear();
  int max_ret = alg_param.max_ret > 0 ? alg_param.max_ret : kTopN;

  // 当前只用了分类别的运营文章作为头部内容
  base::dense_hash_set<uint64> item_dedup;
  item_dedup.set_empty_key(0);
  const auto& prefer_categories = reco_request->prefer_categories;
  if (prefer_categories.find(category.category()) != prefer_categories.end()) {
    const auto whole_iter = manual_data->category_whole_items.find(category.category());
    if (whole_iter != manual_data->category_whole_items.end()) {
      const std::vector<ItemInfo>& whole_items = whole_iter->second;
      for (size_t i = 0; i < whole_items.size(); ++i) {
        if (int(ret_items->size()) >= max_ret) break;
        const ItemInfo& item = whole_items.at(i);
        if (!NewsFilter::IsDeduped(item, &item_dedup)) {
          ret_items->push_back(item);
        }
      }
    }
  }

  // 填充策略分支
  FillRecoBranch(ret_items);

  return true;
}

bool CateRecoHeadContentAlg::DoRecoInChannel(const RecoRequest* reco_request,
                                             const ManualRecoData* manual_data,
                                             int64 cid,
                                             const CateRecoAlgParam& alg_param,
                                             std::vector<ItemInfo>* ret_items,
                                             RecoDebugger* debugger) {
  ret_items->clear();
  return true;
}

} // namespace leaf
} // namespace reco
