#include "reco/serv/reco_leaf/strategy/reco/interest/subscript_reco_manager.h"

#include <utility>
#include <algorithm>

namespace reco {
namespace leafserver {

SubscriptRecoManager::SubscriptRecoManager() {
  news_index_ = LeafDataManager::GetGlobalData()->news_index;
  candidate_extractor_ = new CandidatesExtractor(news_index_);
  retrieval_ = new NewsRetrieval(news_index_);
}

SubscriptRecoManager::~SubscriptRecoManager() {
  delete candidate_extractor_;
  delete retrieval_;
}

void SubscriptRecoManager::DoSubscriptReco(const RecoRequest* reco_request, const ManualRecoData* manual_data,
                                           std::vector<ItemInfo>* reco_items, int max_ret) {
  reco_request_ = reco_request;

  reco_items->clear();

  // 用户订阅信息
  const auto& profile_subscript_sources = reco_request_->user_feas->behavior_fea.subscript_sources;
  const auto& profile_subscript_tags = reco_request_->user_feas->behavior_fea.subscript_words;
  if (profile_subscript_sources.empty() && profile_subscript_tags.empty()) return;

  const auto* subscript_sources = &profile_subscript_sources;
  const auto* subscript_tags = &profile_subscript_tags;

  int session_pv = reco_request_->user_feas->st_fea.session_pv;
  base::dense_hash_map<std::string, float> mid_subscript_sources;
  base::dense_hash_map<std::string, float> mid_subscript_tags;
  mid_subscript_sources.set_empty_key("");
  mid_subscript_tags.set_empty_key("");

  uint32 direct_ir_num = reco_request_->request->return_num() >= 10 ? 3 : 2;
  if (session_pv > 3) {
    // 本次 session 已经刷了 3 次，则只选择高权重的订阅源和订阅标签
    // 订阅源
    for (auto it = profile_subscript_sources.begin(); it != profile_subscript_sources.end(); ++it) {
      if (it->second < 0.9) continue;
      mid_subscript_sources.insert(*it);
    }
    subscript_sources = &mid_subscript_sources;

    // 订阅标签
    for (auto it = profile_subscript_tags.begin(); it != profile_subscript_tags.end(); ++it) {
      if (it->second < 0.9) continue;
      mid_subscript_tags.insert(*it);
    }
    subscript_tags = &mid_subscript_tags;

    direct_ir_num = 2;
  }

  if (subscript_sources->empty() && subscript_tags->empty()) return;

  // 根据订阅数据返回候选集
  std::vector<ItemInfo> candidates;
  static const int kMaxSubscriptCandidateItem = 200;
  candidate_extractor_->GetSubscriptCandidates(reco_request_, *subscript_sources, *subscript_tags,
                                                &candidates, kMaxSubscriptCandidateItem);

  // 触发
  std::vector<ItemInfo> ir_items;
  retrieval_->RetrieveInCategory("", reco_request_, std::vector<ItemInfo>(), candidates, &ir_items);

  // 触发直通车
  retrieval_->ExtractIrDirectItems(ir_items, reco_items, direct_ir_num);

  if (int(reco_items->size()) > max_ret) {
    reco_items->resize(max_ret);
  }

  // 填充策略分支
  FillRecoBranch(reco_items);
}

}  // namespace leafserver
}  // namespace reco
