#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/serv/reco_leaf/strategy/reco/interest/cate_reco_alg_base.h"
#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/proto/leaf_data.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/proto/common.pb.h"

namespace reco {
namespace leafserver {

// 头部内容推荐策略分支
// NOTE(all) must multi thread safe
// TODO(jianhuang && xudong)
// 1. 用户喜好类别考虑
// 2. 类别下的全量运营文章
// 3. 二级类别考虑？
// 4. 多种来源的头部内容 及 混合排序
//
class CateRecoHeadContentAlg: public CateRecoAlgBase {
 public:
  CateRecoHeadContentAlg();

  virtual ~CateRecoHeadContentAlg();

  // 给定 category，返回对应策略分支的推荐结果
  virtual bool DoRecoInCategory(const RecoRequest* reco_request,
                                const ManualRecoData* manual_data,
                                const reco::Category& category,
                                const CateRecoAlgParam& alg_param,
                                std::vector<ItemInfo>* ret_items,
                                RecoDebugger* debugger);

  // 给定 cid，返回对应策略分支的推荐结果
  virtual bool DoRecoInChannel(const RecoRequest* reco_request,
                               const ManualRecoData* manual_data,
                               int64 cid,
                               const CateRecoAlgParam& alg_param,
                               std::vector<ItemInfo>* ret_items,
                               RecoDebugger* debugger);

  // 获取策略分支类型
  virtual reco::RecoStrategyBranch strategy_branch() const {
    return reco::kCateHeadContentBranch;
  }

  // 设置排序模型环境
  // 头部内容推荐逻辑暂时不需要设置模型信息
  virtual void SetRankModelEnv(const RankModelEnv& model_env) {}

 private:
  void FillRecoBranch(std::vector<ItemInfo>* items) const;

 private:
  static const int kTopN;
  const reco::NewsIndex* news_index_;

};

inline void CateRecoHeadContentAlg::FillRecoBranch(std::vector<ItemInfo>* items) const {
  for (size_t i = 0; i < items->size(); ++i) {
    items->at(i).strategy_branch = strategy_branch();
  }
}

} // namespace leaf
} // namespace reco
