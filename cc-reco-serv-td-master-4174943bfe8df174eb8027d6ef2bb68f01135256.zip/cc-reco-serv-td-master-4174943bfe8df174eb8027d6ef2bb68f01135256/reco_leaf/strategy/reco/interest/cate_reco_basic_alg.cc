#include "reco/serv/reco_leaf/strategy/reco/interest/cate_reco_basic_alg.h"
#include "reco/serv/reco_leaf/frame/global_conf.h"

namespace reco {
namespace leafserver {

DEFINE_int32(basic_cate_candidate_cutoff, 5000, "basic cate candidate cutoff");

const int CateRecoBasicAlg::kTopN = 300;

CateRecoBasicAlg::CateRecoBasicAlg() {
  news_index_ = LeafDataManager::GetGlobalData()->news_index;
  candidate_extractor_ = new CandidatesExtractor(news_index_);
  retrieval_ = new NewsRetrieval(news_index_);
  ranker_ = new NewsRanker(news_index_);
}

CateRecoBasicAlg::~CateRecoBasicAlg() {
  delete ranker_;
  delete retrieval_;
  delete candidate_extractor_;
}

bool CateRecoBasicAlg::DoRecoInCategory(const RecoRequest* reco_request,
                                        const ManualRecoData* manual_data,
                                        const reco::Category& category,
                                        const CateRecoAlgParam& alg_param,
                                        std::vector<ItemInfo>* ret_items,
                                        RecoDebugger* debugger) {
  ret_items->clear();
  const int max_ret = alg_param.max_ret > 0 ? alg_param.max_ret : kTopN;

  // candidate
  std::vector<ItemInfo> candidate_items;
  candidate_extractor_->GetCandidatesByCategory(category, reco_request, &candidate_items,
                                                FLAGS_basic_cate_candidate_cutoff, debugger);
  debugger->TraceCategoryCandidateItems(candidate_items);

  // retrieval and rank
  std::vector<ItemInfo> ir_items;
  std::vector<ItemInfo> rank_items;
  std::vector<ItemInfo> direct_ir_items;
  bool do_personal_reco = (GlobalConf::GetServiceLevel() == kNormalService);
  if (do_personal_reco) {
    // 触发：人工个性化部分候选 + 机器候选
    retrieval_->RetrieveInCategory(category.category(), reco_request,
                                   manual_data->personal_items, candidate_items, &ir_items);
    // 触发直通车
    retrieval_->ExtractIrDirectItems(ir_items, &direct_ir_items, 2);
    // 排序结果的获取
    ranker_->Rank(category.category(), reco_request, ir_items, &rank_items, debugger);
  }
  debugger->TraceAfterCategoryRankItems(rank_items);

  // fill ret vec
  // NOTE(jianhuang) 此处不 dedup，放在外面统一 dedup
  ret_items->insert(ret_items->begin(), direct_ir_items.begin(), direct_ir_items.end());
  int rank_insert_size = max_ret - ret_items->size();
  if (rank_insert_size > 0 && rank_items.size() > 0) {
    rank_insert_size = std::min((int)rank_items.size(), rank_insert_size);
    ret_items->insert(ret_items->end(), rank_items.begin(), rank_items.begin() + rank_insert_size);
  }

  FillRecoBranch(ret_items);

  return true;
}

bool CateRecoBasicAlg::DoRecoInChannel(const RecoRequest* reco_request,
                                       const ManualRecoData* manual_data,
                                       int64 cid,
                                       const CateRecoAlgParam& alg_param,
                                       std::vector<ItemInfo>* ret_items,
                                       RecoDebugger* debugger) {
  ret_items->clear();
  int max_ret = alg_param.max_ret > 0 ? alg_param.max_ret : kTopN;

  // 获取候选集
  std::vector<ItemInfo> candidate_items;
  candidate_extractor_->GetCandidatesByChannelId(reco_request->channel_id, reco_request,
                                                 &candidate_items, FLAGS_basic_cate_candidate_cutoff,
                                                 debugger);
  debugger->TraceCategoryCandidateItems(candidate_items);

  // 触发 item
  std::vector<ItemInfo> ir_items;
  // 排序 item
  std::vector<ItemInfo> rank_items;
  // 触发直通车
  std::vector<ItemInfo> direct_ir_items;

  const uint32 req_num = reco_request->request->return_num();
  bool do_personal_reco = (GlobalConf::GetServiceLevel() == kNormalService);
  if (do_personal_reco) {
    // 触发集合的获取
    retrieval_->RetrieveInChannel(cid, reco_request, manual_data->personal_items, candidate_items, &ir_items);
    // 触发直通车
    const int kMaxDirectIrNum = std::max(2, int(req_num / 4.0 + 0.5));
    retrieval_->ExtractIrDirectItems(ir_items, &direct_ir_items, kMaxDirectIrNum);
    // 排序结果的获取
    ranker_->Rank("", reco_request, ir_items, &rank_items, debugger);
  }
  debugger->TraceAfterCategoryRankItems(rank_items);

  // fill ret vec
  // NOTE(jianhuang) 此处不 dedup，放在外面统一 dedup
  ret_items->insert(ret_items->begin(), direct_ir_items.begin(), direct_ir_items.end());
  int rank_insert_size = max_ret - ret_items->size();
  if (rank_insert_size > 0 && rank_items.size() > 0) {
    rank_insert_size = std::min((int)rank_items.size(), rank_insert_size);
    ret_items->insert(ret_items->end(), rank_items.begin(), rank_items.begin() + rank_insert_size);
  }

  FillRecoBranch(ret_items);

  return true;
}

} // namespace leaf
} // namespace reco
