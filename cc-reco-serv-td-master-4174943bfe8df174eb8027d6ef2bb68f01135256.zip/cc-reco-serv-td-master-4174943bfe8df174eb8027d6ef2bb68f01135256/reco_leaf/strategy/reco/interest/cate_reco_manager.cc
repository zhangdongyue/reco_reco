#include "reco/serv/reco_leaf/strategy/reco/interest/cate_reco_manager.h"

#include <utility>
#include <algorithm>

#include "reco/serv/reco_leaf/strategy/reco/interest/cate_reco_basic_alg.h"
#include "reco/serv/reco_leaf/strategy/reco/interest/cate_reco_headcontent_alg.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/common/item_level_define.h"

namespace reco {
namespace leafserver {
DEFINE_bool(open_cate_reco_cache_switch, true, "if open cate reco cache.");
DEFINE_double(exploit_reco_score_threshold, 2, "app展现\"荐\"图标的阈值");

const int CateRecoManager::kRecoScoreFactor = 1000000;
const uint32 CateRecoManager::kNewsNumPerScreen = 8;
const uint32 CateRecoManager::kBasicReqNum = 1000;
const uint32 CateRecoManager::kHeadReqNum = 20;
const uint32 CateRecoManager::kTopNSize = 300;

CateRecoManager::CateRecoManager() {
  news_index_ = LeafDataManager::GetGlobalData()->news_index;
  basic_reco_ = new CateRecoBasicAlg();
  head_reco_ = new CateRecoHeadContentAlg();
  random_ = new base::PseudoRandom(base::GetTimestamp());
  reco_cache_ = new RecoResultCache(news_index_);
}

CateRecoManager::~CateRecoManager() {
  delete basic_reco_;
  delete head_reco_;
  delete random_;
  delete reco_cache_;
}

bool CateRecoManager::DoRecoInCategory(const RecoRequest* reco_request,
                                       const ManualRecoData* manual_data,
                                       const reco::Category& category,
                                       std::vector<ItemInfo>* ret_items,
                                       RecoContext* context,
                                       float cate_ratio) {
  serving_base::Timer timer;
  timer.Start();
  reco_request_ = reco_request;

  bool use_cache = true;
  CateRecoData reco_data;
  if (!GetRecoDataFromCache(reco_request, category.category(), 0, &reco_data)) {
    use_cache = false;
    reco_data.Reset();
  }

  CateRecoAlgParam alg_param;
  if (reco_data.head_items.empty()) {
    // use_cache = false;
    alg_param.max_ret = kHeadReqNum;
    head_reco_->DoRecoInCategory(reco_request, manual_data, category,
                                 alg_param, &reco_data.head_items, context->debugger());
  }
  context->cost_trace()->hrict = timer.Interval();

  const float cate_req_num = cate_ratio * reco_request->request->return_num();
  if (reco_data.basic_items.size() < cate_req_num * 2 || reco_data.basic_items.size() < 3) {
    use_cache = false;
    reco_data.basic_items.clear();
    alg_param.max_ret = kBasicReqNum;
    basic_reco_->DoRecoInCategory(reco_request, manual_data, category,
                                  alg_param, &reco_data.basic_items, context->debugger());
  } else {
    LOG(INFO) << "use cache:" << reco_request->request->user().user_id()
              << ", recoid:" << reco_request->request->reco_id()
              << ", app:" << reco_request->request->app_token()
              << ", category:" << category.category()
              << ", num:" << reco_data.basic_items.size();
  }
  context->cost_trace()->brict = timer.Interval();

  std::vector<ItemInfo> mid_items;
  MergeAndRerank(reco_request, category.category(), 0, reco_data, &mid_items);
  FillRecoStrategyType(reco_request, &mid_items);

  // 同一类别内的在线多样性处理
  const int remain_num = std::min((int)mid_items.size(), int(cate_req_num * 30 +3));
  NewsFilter::DiversityFilter(reco_request->request, reco_request->user_info,
                              reco_request->user_feas, mid_items,
                              category.category(), remain_num, ret_items);
  if (ret_items->size() > kTopNSize) {
    ret_items->resize(kTopNSize);
  }

  if (!use_cache) { 
    // NOTE(jianhuang) 这里 swap 的原因在于 mid item 经过二级类别 rerank
    // TODO(jianhuang) 特定类别的二级类别 rerank 使用二级类别展平的方式进行
    reco_data.basic_items.swap(mid_items);
    int cache_item_num = std::max(int(cate_req_num * 30 + 1), 10);
    if ((int)reco_data.basic_items.size() > cache_item_num) {
      reco_data.basic_items.resize(cache_item_num);
    }
    if (!SetRecoDataToCache(reco_request, category.category(), 0, reco_data)) {
      LOG(WARNING) << "set cache fail.";
    }
  }

  context->cost_trace()->rict = timer.Stop();

  return true;
}

bool CateRecoManager::DoRecoInChannel(const RecoRequest* reco_request,
                                      const ManualRecoData* manual_data,
                                      int64 cid,
                                      std::vector<ItemInfo>* ret_items,
                                      RecoContext* context) {
  ret_items->clear();
  reco_request_ = reco_request;

  bool use_cache = true;
  CateRecoData reco_data;
  if (!GetRecoDataFromCache(reco_request, "", cid, &reco_data)) {
    use_cache = false;
    reco_data.Reset();
  }
  CateRecoAlgParam alg_param;
  const uint32 req_num = reco_request->request->return_num();
  if (reco_data.basic_items.size() < req_num * 2) {
    use_cache = false;
    reco_data.basic_items.clear();
    alg_param.max_ret = kBasicReqNum;
    basic_reco_->DoRecoInChannel(reco_request, manual_data, reco_request->channel_id,
                                 alg_param, &reco_data.basic_items, context->debugger());
  } else {
    LOG(INFO) << "channel reco use cache, " << reco_request->request->user().user_id()
              << ", recoid: " << reco_request->request->reco_id()
              << ", cid: " << cid
              << ", reco_data: " << reco_data.basic_items.size();
  }

  std::vector<ItemInfo> mid_items;
  MergeAndRerank(reco_request, "", reco_request->channel_id, reco_data, &mid_items);
  FillRecoStrategyType(reco_request, &mid_items);

  if (reco_request->channel_id == reco::common::kHumorWordChannelId
      || reco_request->channel_id == reco::common::kLeftChannelId) {
    ret_items->assign(mid_items.begin(), mid_items.end());
  } else {
    int remain_size = std::min((int)mid_items.size(), 100);
    NewsFilter::DiversityFilter(reco_request->request, reco_request->user_info,
                                reco_request->user_feas, mid_items, "",
                                remain_size, ret_items);
  }
  if (ret_items->size() > kTopNSize) {
    ret_items->resize(kTopNSize);
  }

  if (!use_cache) { 
    // NOTE(jianhuang) 这里 swap 的原因在于 mid item 经过二级类别 rerank
    // TODO(jianhuang) 特定类别的二级类别 rerank 使用二级类别展平的方式进行
    reco_data.basic_items.swap(mid_items);
    if (!SetRecoDataToCache(reco_request, "", cid, reco_data)) {
      LOG(WARNING) << "set cache fail.";
    }
  }

  return true;
}

void CateRecoManager::MergeAndRerank(const RecoRequest* reco_request,
                                     const std::string& category, int64 cid,
                                     const CateRecoData& reco_data,
                                     std::vector<ItemInfo>* ret_items) {
  // NOTE(jianhuang) 按照老方式进行 merge，尽量保持第一版本线上无 diff
  // TODO(jianhuang) 考虑 session / 历史 show 的数据，调整 merge 的算法
  ret_items->clear();

  std::vector<ItemInfo>* select_items = ret_items;
  std::vector<ItemInfo> mid_items;
  bool snd_cate_rerank = IfReRankBySndCategory(category, cid);
  if (snd_cate_rerank) {
    select_items = &mid_items;
  }

  const std::vector<ItemInfo>* head_items = &reco_data.head_items;
  const std::vector<ItemInfo>* basic_items = &reco_data.basic_items;

  static const float kHeadRatio = 0.3;
  static const int kHeadMinNum = 1;
  base::dense_hash_set<uint64> item_dedup;
  item_dedup.set_empty_key(NULL);
  size_t basic_idx = 0, head_idx = 0;
  int head_insert_num = 0;
  while (basic_idx < basic_items->size() && head_idx < head_items->size()) {
    if (select_items->size() >= kTopNSize) break;
    bool select_head = true;
    bool top_select_head = true;
    if (head_insert_num >= kHeadMinNum) {
      select_head = (random_->GetDouble() < kHeadRatio);
      top_select_head = false;
    }
    // 如果选择 head, 则插入一条 head
    while (select_head && head_idx < head_items->size()) {
      const ItemInfo& item = head_items->at(head_idx);
      ++head_idx;
      if (!NewsFilter::IsDeduped(item, &item_dedup)) {
        ++head_insert_num;
        select_items->push_back(item);
        break;
      }
    }
    // 如果是强制选择 head，或者此次判断选择 basic, 则插入一条 basic
    while ((top_select_head || !select_head)
           && basic_idx < basic_items->size()) {
      const ItemInfo& item = basic_items->at(basic_idx);
      ++basic_idx;
      if (!NewsFilter::IsDeduped(item, &item_dedup)) {
        select_items->push_back(item);
        break;
      }
    }
  }
  // 不够继续插入 basic 队列
  while (basic_idx < basic_items->size()) {
    if (select_items->size() >= kTopNSize) break;
    const ItemInfo& item = basic_items->at(basic_idx);
    if (!NewsFilter::IsDeduped(item, &item_dedup)) {
      select_items->push_back(item);
    }
    ++basic_idx;
  }

  // 二级类别多样性处理
  if (snd_cate_rerank && !mid_items.empty()) {
    ReRankBySndCategory(reco_request, category, cid, mid_items, ret_items);
  }
}

bool CateRecoManager::IfReRankBySndCategory(const std::string& category, int64 channel_id) const {
  static std::unordered_set<std::string> kDoSndRankCategories = {
    reco::common::kSportCategory,
    reco::common::kFinanceCategory,
    reco::common::kScienceCategory
  };

  static std::unordered_set<int64> kDoSndRankChannelIds = {
    reco::common::kSportChannelId,
    reco::common::kFinanceChannelId,
    reco::common::kScienceChannelId
  };

  if (!category.empty()) {
    return (kDoSndRankCategories.find(category) != kDoSndRankCategories.end());

  } else if (channel_id != reco::common::kRecoChannelId) {
    return (kDoSndRankChannelIds.find(channel_id) != kDoSndRankChannelIds.end());
  }

  return false;
}

void CateRecoManager::ReRankBySndCategory(const RecoRequest* reco_request,
                                          const std::string& param_cate, int64 channel_id,
                                          const std::vector<ItemInfo>& org_items,
                                          std::vector<ItemInfo>* merged_items) {
  if (org_items.empty()) return;

  // 计算二级类别的权重
  std::string category;
  if (!param_cate.empty()) {
    category = param_cate;
  } else if (channel_id == reco::common::kSportChannelId) {
    category = reco::common::kSportCategory;
  } else if (channel_id == reco::common::kFinanceChannelId) {
    category = reco::common::kFinanceCategory;
  } else if (channel_id == reco::common::kScienceChannelId) {
    category = reco::common::kScienceCategory;
  } else {
    merged_items->insert(merged_items->end(), org_items.begin(), org_items.end());
    return;
  }

  // // 体育类别走单独的 rerank
  // if (category == reco::common::kSportCategory) {
  //   return SportSndCategoryRerank(reco_request, param_cate, channel_id,
  //                                 org_items, merged_items);
  // }

  std::unordered_map<std::string, float> subcate_continue_items;
  SubCateContinueLimit(category, &subcate_continue_items);

  std::vector<bool> mark_vec(org_items.size(), false);
  for (size_t i = 0; i < org_items.size() && i < 150; ++i) {
    int select_idx = -1;
    for (size_t  j = 0; j < org_items.size(); ++j) {
      if (mark_vec[j]) continue;
      if (select_idx < 0) select_idx = j;
      const ItemInfo& item = org_items.at(j);
      if (item.sub_category.empty()) {
        select_idx = j;
        break;
      }
      bool can_add = false;
      auto it = subcate_continue_items.find(item.sub_category);
      float continue_limit = it != subcate_continue_items.end() ? it->second : 3;
      if (channel_id == 100) {
        continue_limit = std::max(1.0f, continue_limit);
      }
      if (continue_limit < 0.1) {
        can_add = false;

      } else if (continue_limit >= 1) {
         // > 1, 间隔足够多的不同二级类别即可以出
        int start_pos = std::max(0, (int)merged_items->size() - (int)continue_limit);
        for (size_t k = start_pos; k < merged_items->size(); ++k) {
          const ItemInfo& comp_item = merged_items->at(k);
          if (comp_item.sub_category != item.sub_category) {
            can_add = true;
            break;
          }
        }
      } else {
        // < 1，多条才能出一条
        int comp_size = 1 / continue_limit;
        if ((int)merged_items->size() >= comp_size) {
          // 只要有一条相同二级类别就不出
          can_add = true;
          int start_pos = std::max(0, (int)merged_items->size() - comp_size);
          for (size_t k = start_pos; k < merged_items->size(); ++k) {
            const ItemInfo& comp_item = merged_items->at(k);
            if (comp_item.sub_category == item.sub_category) {
              can_add = false;
              break;
            }
          }
        }
      }
      if (can_add) {
        select_idx = j;
        break;
      }
    }
    if (select_idx != -1) {
      merged_items->push_back(org_items[select_idx]);
      mark_vec[select_idx] = true;
    }
  }

  for (size_t i = 0; i < org_items.size(); ++i) {
    if (!mark_vec[i]) {
      merged_items->push_back(org_items[i]);
    }
  }
}

void CateRecoManager::SportSndCategoryRerank(const RecoRequest* reco_request,
                                             const std::string& param_cate,
                                             int64 channel_id,
                                             const std::vector<ItemInfo>& org_items,
                                             std::vector<ItemInfo>* merged_items) {
  if (org_items.empty()) return;

  // 计算二级类别的权重
  std::string category;
  if (!param_cate.empty()) {
    category = param_cate;
  } else if (channel_id == reco::common::kSportChannelId) {
    category = reco::common::kSportCategory;
  } else if (channel_id == reco::common::kFinanceChannelId) {
    category = reco::common::kFinanceCategory;
  } else if (channel_id == reco::common::kScienceChannelId) {
    category = reco::common::kScienceCategory;
  } else {
    merged_items->insert(merged_items->end(), org_items.begin(), org_items.end());
    return;
  }

  // 获取本次请求，该类别/频道下发量大小
  int news_per_screen = kNewsNumPerScreen;
  if (channel_id == reco::common::kRecoChannelId) {
    news_per_screen = 0;
    for (int i = 0; i < (int)reco_request->category_distributes->size(); ++i) {
      if (category != reco_request->category_distributes->at(i).second.category()) continue;
      float float_num = reco_request->category_distributes->at(i).first * kNewsNumPerScreen;
      news_per_screen = (int)float_num;
      if (random_->GetDouble() < float_num - news_per_screen) {
        news_per_screen += 1;
      }
      break;
    }
  }

  // 如果用户没有点击行为，且需要返回条数很小的情况，则直接返回整体数据
  double cate_click = 0;
  const auto& ref_l1_cates = reco_request->user_feas->merged_fea.l1_cates;
  auto l1_iter = ref_l1_cates.find(category);
  if (l1_iter == ref_l1_cates.end() || news_per_screen == 0) {
    if (news_per_screen < 3) {
      merged_items->insert(merged_items->end(), org_items.begin(), org_items.end());
      return;
    }
  } else {
    cate_click = l1_iter->second * reco_request->user_feas->merged_info.total_click_num;
  }

  // calc explore ratio
  float total_explore_ratio = 1;
  if (cate_click >= 45) {
    total_explore_ratio = 0.1;
  } else if (cate_click >= 25) {
    total_explore_ratio = 0.1 + (45 - cate_click) * 0.0025;
  } else if (cate_click >= 15) {
    total_explore_ratio = 0.15 + (25 - cate_click) * 0.005;
  } else if (cate_click >= 5) {
    total_explore_ratio = 0.2 + (15 - cate_click) * 0.01;
  } else if (cate_click >= 1) {
    total_explore_ratio = 0.3 + (5 - cate_click) * 0.03;
  }
  if (channel_id != reco::common::kRecoChannelId) {
    // 非推荐频道的 explore 因素可以更强点
    total_explore_ratio *= 1.5;
  }
  total_explore_ratio = std::min(1.0f, total_explore_ratio);

  // 根据在二级类目上的点击情况，计算各个二级类别分配的条数
  const FeaKeyVal* user_l2_cates = NULL;
  const auto& ref_l2_cates = reco_request->user_feas->merged_fea.l2_cates;
  auto l2_iter = ref_l2_cates.find(category);
  if (l2_iter != ref_l2_cates.end() && !l2_iter->second.empty()) {
    user_l2_cates = &l2_iter->second;
  }

  FeaKeyVal l2_num_map;
  float sum_weight = 0;
  for (int i = 0; i < (int)org_items.size(); ++i) {
    const std::string& sub_cate = org_items[i].sub_category;
    const std::string& standard_sub_cate = GetStandardSubCate(category, sub_cate);

    float weight = 0;
    if (user_l2_cates != NULL) {
      const auto iter = user_l2_cates->find(sub_cate);
      weight = (iter != user_l2_cates->end()) ? iter->second : 0;
    }

    l2_num_map[standard_sub_cate] += weight;
    sum_weight += weight;
  }
  if (l2_num_map.empty()) {
    merged_items->insert(merged_items->end(), org_items.begin(), org_items.end());
    return;
  }
  if (sum_weight > 1e-3) {
    // 归一化
    for (auto iter = l2_num_map.begin(); iter != l2_num_map.end(); ++iter) {
      iter->second /= sum_weight;
    }
  }
  // explore 因子
  float explore_ratio = total_explore_ratio / l2_num_map.size();
  for (auto iter = l2_num_map.begin(); iter != l2_num_map.end(); ++iter) {
    iter->second = (1 - total_explore_ratio) * iter->second + explore_ratio;
    iter->second *= news_per_screen;
    int num = (int)iter->second;
    if (random_->GetDouble() < iter->second - num) num++;
    iter->second = num;
  }

  // 控制二级类别的下发
  std::vector<bool> used_idx_vec(org_items.size(), false);
  int sloop_times = std::min(20, (int)org_items.size() / news_per_screen);
  for (int sloop_idx = 0; sloop_idx < sloop_times; ++sloop_idx) {
    FeaKeyVal subcate_num_map = l2_num_map;  // 临时变量，不是引用
    for (int item_idx = 0; item_idx < (int)org_items.size(); ++item_idx) {
      if (used_idx_vec[item_idx] == true) continue;
      const ItemInfo& org_item = org_items[item_idx];
      const std::string& standard_sub_cate = GetStandardSubCate(category, org_item.sub_category);
      auto iter = subcate_num_map.find(standard_sub_cate);
      if (iter != subcate_num_map.end() && iter->second > 0) {
        merged_items->push_back(org_item);
        used_idx_vec[item_idx] = true;
        iter->second -= 1;
        continue;
      }
    }
  }
  for (int item_idx = 0; item_idx < (int)org_items.size(); ++item_idx) {
    if (used_idx_vec[item_idx] == true) continue;
    merged_items->push_back(org_items[item_idx]);
  }
}


void CateRecoManager::SubCateContinueLimit(
    const std::string& cate,
    std::unordered_map<std::string, float>* subcate_continue_items) const {

  if (cate.empty()) return;

  // 如果用户没有点击行为，且需要返回条数很小的情况，则直接返回整体数据
  float cate_click = 0;
  const auto& user_cates = reco_request_->user_feas->merged_fea.l1_cates;
  auto cate_iter = user_cates.find(cate);
  if (cate_iter != user_cates.end()) {
  } else {
    cate_click = cate_iter->second * reco_request_->user_feas->merged_info.total_click_num;
  }

  const auto& sub_cate_matrix = reco_request_->user_feas->merged_fea.l2_cates;
  const auto matrix_iter = sub_cate_matrix.find(cate);
  const FeaKeyVal* sub_cates = NULL;
  if (matrix_iter != sub_cate_matrix.end()) {
    sub_cates = &matrix_iter->second;
  }
  if (cate == "科技") {
    std::string subcate = "手机";
    if (sub_cates == NULL) {
      subcate_continue_items->insert(std::make_pair(subcate, 0.5));
      return;
    }
    auto sub_it = sub_cates->find(subcate);
    if (sub_it == sub_cates->end()) {
      subcate_continue_items->insert(std::make_pair(subcate, 0.5));
      return;
    }
    if (sub_it->second >= 0.7 && cate_click >= 10) {
      subcate_continue_items->insert(std::make_pair(subcate, 2));
    } else if (sub_it->second >= 0.5 && cate_click >= 10) {
      subcate_continue_items->insert(std::make_pair(subcate, 1));
    } else {
      subcate_continue_items->insert(std::make_pair(subcate, 0.5));
    }
    return;
  }
  if (cate == "财经") {
    std::string subcate = "股票";
    if (sub_cates == NULL) {
      subcate_continue_items->insert(std::make_pair(subcate, 0.5));
      return;
    }
    auto sub_it = sub_cates->find(subcate);
    if (sub_it == sub_cates->end()) {
      subcate_continue_items->insert(std::make_pair(subcate, 0.5));
      return;
    }
    if (sub_it->second >= 0.7 && cate_click >= 10) {
      subcate_continue_items->insert(std::make_pair(subcate, 2));
    } else if (sub_it->second >= 0.5 && cate_click >= 10) {
      subcate_continue_items->insert(std::make_pair(subcate, 1));
    } else {
      subcate_continue_items->insert(std::make_pair(subcate, 0.5));
    }
    return;
  }
}

std::string CateRecoManager::GetStandardSubCate(const std::string& cate, const std::string& sub_cate) {
  static const std::unordered_set<std::string> kSportMajorSubCates = {"cba", "nba", "国内足球", "国际足球"};
  static const std::unordered_set<std::string> kFinanceMajorSubCates = {"经济民生", "股票"};
  static const std::unordered_set<std::string> kTechMajorSubCates = {"手机", "互联网"};
  static const std::string kDftSubCate = "other";
  if (sub_cate.empty()) return kDftSubCate;
  const std::unordered_set<std::string>* major_subcates = NULL;
  if (cate == "体育") {
    major_subcates = &kSportMajorSubCates;
  } else if (cate == "财经") {
    major_subcates = &kFinanceMajorSubCates;
  } else if (cate == "科技") {
    major_subcates = &kTechMajorSubCates;
  } else {
    return kDftSubCate;
  }
  const auto iter = major_subcates->find(sub_cate);
  if (iter != major_subcates->end()) {
    return *iter;
  }
  return kDftSubCate;
}

bool CateRecoManager::GetRecoDataFromCache(const RecoRequest* reco_request,
                                           const std::string& category, int64 cid,
                                           CateRecoData* reco_data) const {
  if (!FLAGS_open_cate_reco_cache_switch) return false;
  if (!CanUseCache(reco_request, category, cid)) return false;
  std::string cache_key = GenCacheKey(reco_request, category, cid);
  CachedRecoBranchData cache_data;
  if (!reco_cache_->GetCachedRecoBranchData(cache_key, &cache_data)) {
    return false;
  }
  ParseFromCacheData(reco_request, cache_data, reco_data);

  return true;
}

bool CateRecoManager::SetRecoDataToCache(const RecoRequest* reco_request,
                                         const std::string& category, int64 cid,
                                         const CateRecoData& reco_data) const {
  if (!FLAGS_open_cate_reco_cache_switch) return true;
  if (!CanUseCache(reco_request, category, cid)) return true;
  std::string cache_key = GenCacheKey(reco_request, category, cid);

  CachedRecoBranchData cache_data;
  ConvertToCacheData(reco_request, reco_data, &cache_data);
  LOG(INFO) << "set cache:" << cache_key
            << ", recoid:" << reco_request->request->reco_id()
            << ", num:" << cache_data.item_misc_size();
  if (!reco_cache_->SetCachedRecoBranchData(cache_key, cache_data)) {
    return false;
  }
  return true;
}

std::string CateRecoManager::GenCacheKey(const RecoRequest* reco_request,
                                         const std::string& category, int64 cid) const {
  uint64 uid = reco_request->user_info->identity().user_id();
  std::string key;
  if (!category.empty()) {
    key = base::StringPrintf("%lu_%s_%s", uid, "CATE", category.c_str());
  } else {
    key = base::StringPrintf("%lu_%s_%lu", uid, "CID", cid);
  }
  return key;
}

void CateRecoManager::ItemInfoToItemMisc(const ItemInfo& item, CachedItemMisc* item_misc) const {
  item_misc->set_item_id(item.item_id);
  item_misc->set_category(item.category);
  item_misc->set_strategy_type(item.strategy_type);
  item_misc->set_lr_score(item.lr_score);
  item_misc->set_fm_score(item.fm_score);
  item_misc->set_reco_score(item.reco_score);
  item_misc->set_reco_branch(item.strategy_branch);
}

void CateRecoManager::ItemMiscToItemInfo(const CachedItemMisc& item_misc, ItemInfo* item_info) const {
  int strategy_type = item_misc.strategy_type();
  if (reco::StrategyType_IsValid(strategy_type)) {
    item_info->strategy_type = reco::StrategyType(strategy_type);
  } else {
    item_info->strategy_type = reco::kNoStrategy;
  }

  int strategy_branch = item_misc.reco_branch();
  if (reco::RecoStrategyBranch_IsValid(strategy_branch)) {
    item_info->strategy_branch = reco::RecoStrategyBranch(strategy_branch);
  } else {
    item_info->strategy_branch = reco::kUnknownBranch;
  }

  item_info->lr_score = item_misc.lr_score();
  item_info->fm_score = item_misc.fm_score();
  item_info->reco_score = item_misc.reco_score();
}

void CateRecoManager::ConvertToCacheData(const RecoRequest* reco_request,
                                         const CateRecoData& reco_data,
                                         CachedRecoBranchData* cache_data) const {
  // 头部内容暂时不填充 cache
  // TODO(jianhuang) 由策略分支返回是否填充 cache
  static size_t kMaxCachedHeadItem = 0;
  cache_data->set_timestamp(reco_request->current_timestamp);
  const std::vector<ItemInfo>& head_items = reco_data.head_items;
  for (size_t idx = 0; idx < head_items.size() && idx < kMaxCachedHeadItem; ++idx) {
    CachedItemMisc* item_misc = cache_data->add_item_misc();
    ItemInfoToItemMisc(head_items[idx], item_misc);
  }
  // 基础 item 填充 cache
  static const size_t kMaxCachedBasicItem = 100;
  const std::vector<ItemInfo>& basic_items = reco_data.basic_items;
  for (size_t idx = 0; idx < basic_items.size() && idx < kMaxCachedBasicItem; ++idx) {
    CachedItemMisc* item_misc = cache_data->add_item_misc();
    ItemInfoToItemMisc(basic_items[idx], item_misc);
  }
}

void CateRecoManager::ParseFromCacheData(const RecoRequest* request,
                                         const CachedRecoBranchData& cache_data,
                                         CateRecoData* reco_data) const {
  ItemInfo item;
  reco::filter::FilterReason filter_reason;
  for (int idx = 0; idx < cache_data.item_misc_size(); ++idx) {
    const CachedItemMisc& item_misc = cache_data.item_misc(idx);
    if (!news_index_->GetItemInfoByItemId(item_misc.item_id(), &item, false)
        || NewsFilter::IsGeneralFiltered(request, request->shown_dict, item, &filter_reason)
        || NewsFilter::IsRegionRestrictFiltered(item, request->user_feas->attr.prov_id,
                                                request->user_feas->attr.city_id)) {
      continue;
    }
    ItemMiscToItemInfo(item_misc, &item);
    if (item.strategy_branch == reco::kCateBasicBranch) {
      reco_data->basic_items.push_back(item);
    } else if (item.strategy_branch == reco::kCateHeadContentBranch) {
      reco_data->head_items.push_back(item);
    }
  }
}

void CateRecoManager::FillRecoStrategyType(const RecoRequest* reco_request,
                                           std::vector<ItemInfo>* reco_items) const {
  for (size_t i = 0; i < reco_items->size(); ++i) {
    ItemInfo& item = (*reco_items)[i];
    if (item.strategy_type != reco::kNoStrategy) {
      continue;
    }
    if ((!reco_request->is_update_req
         || item.time_level == reco::kGoodTimeliness)
        && item.hot_level >= reco::item_level::kMidHotScoreThres) {
      item.strategy_type = reco::kHot;
    } else if (item.reco_score >= FLAGS_exploit_reco_score_threshold * kRecoScoreFactor) {
      item.strategy_type = reco::kExploit;
    } else {
      item.strategy_type = reco::kExplore;
    }
  }
}

bool CateRecoManager::CanUseCache(const RecoRequest* reco_request,
                                  const std::string& category, int64 cid) const {
  if (!category.empty()) return true;
  if (cid == 100 || cid == 0) return true;
  static const std::unordered_set<int64> kNotCacheChannels
      = {reco::common::kHotChannelId, reco::common::kLocalChannelId};
  if (kNotCacheChannels.find(cid) != kNotCacheChannels.end()) return false;
  return true;
}

}  // namespace leafserver
}  // namespace reco
