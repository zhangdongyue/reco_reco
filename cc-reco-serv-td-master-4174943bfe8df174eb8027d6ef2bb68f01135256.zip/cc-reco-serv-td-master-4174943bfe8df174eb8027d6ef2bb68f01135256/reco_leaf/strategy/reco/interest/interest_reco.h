#pragma once

#include "reco/serv/reco_leaf/strategy/reco/interest/interest_common.h"
#include "reco/serv/reco_leaf/strategy/reco/interest/cate_reco_manager.h"
#include "reco/serv/reco_leaf/strategy/reco/interest/subscript_reco_manager.h"

namespace reco {
namespace leafserver {

// 基于用户的兴趣点推荐
// 从以下兴趣点去推荐：
// 1. 用户订阅相关；
// 2. 用户类别喜好
//
class InterestReco {
 public:
  InterestReco(const reco::NewsIndex* index);
  ~InterestReco();

  // 接口，各个兴趣点汇总到推荐结果集返回
  void DoInterestReco(const RecoRequest* request,
                      const ManualRecoData* manual_data,
                      std::vector<ItemInfo>* reco_items,
                      RecoContext* context);

 private:
  // 垂直频道推荐算法
  void DoVerticleChannelReco(std::vector<ItemInfo>* reco_items, RecoContext* context);
  // 综合频道(推荐频道)推荐算法
  void DoComplexChannelReco(std::vector<ItemInfo>* reco_items, RecoContext* context);

  // TODO(jianhuang) 以下几个类别兴趣点推荐的函数 / 参数现在有点凌乱, 可以优化
  //  几个线程并行计算类别推荐
  int DecideCategoryRecoThread();
  // 特定类别的推荐结果
  void CategoryReco(const reco::Category category, const float category_ratio,
                    std::pair<float, std::vector<ItemInfo> >* cate_items, RecoContext* context);
  // 分类别推荐
  void MultiCategoryReco(const std::vector<std::pair<float, reco::Category>>& category_distributes,
                         std::vector<std::pair<float, std::vector<ItemInfo> > >* diversity_items_vec,
                         RecoContext* context);
  // 推荐频道的推荐结果合并
  void MergeComplexReco(std::vector<ItemInfo>* ret_items, int req_num, RecoContext* context);
  // 设置模型环境
  void SetRankModelEnv();

 private:
  static const int kTopNSize;
  static const int kNewsNumPerScreen;

  const reco::NewsIndex* news_index_;
  const RecoRequest* reco_request_;
  const ManualRecoData* manual_data_;

  // ItemDictManager* item_dict_manager_;
  SubscriptRecoManager* subscript_reco_;
  base::PseudoRandom* random_;
  CateRecoManager* cate_reco_;
  serving_base::Timer timer_;

  std::vector<ItemInfo> subscript_reco_items_;
  std::vector<ItemInfo> channel_reco_items_;
  std::vector<std::pair<float, std::vector<ItemInfo> > > cate_items_vec_;

  RankModelEnv model_env_;
};

}  // namespace leafserver
}  // namespace reco

