#include "reco/serv/reco_leaf/strategy/reco/channel_video/channel_video_reco.h"

#include <string>
#include <vector>

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace reco {
class NewsIndex;

namespace leafserver {

ChannelVideoReco::ChannelVideoReco(const reco::NewsIndex* index) {
  news_index_ = index;
}

ChannelVideoReco::~ChannelVideoReco() {
}

void ChannelVideoReco::GetChannelVideoItems(const RecoRequest& request,
                                            std::vector<ItemInfo>* ret_items,
                                            RecoDebugger* debugger) {
  ret_items->clear();
  int64 channel_id = request.channel_id;
  if (request.channel_id == reco::common::kSexyBeautyChannelId) {
    channel_id = reco::common::kHotGirlChannelId;
  }
  // 1) get default reco as candidates
  const std::vector<ItemInfo>* candidates = news_index_->GetVideoDefaultReco(channel_id);
  if (candidates == NULL) {
    LOG(INFO) << "cannot get video reco index: " << channel_id << " " << request.channel_id;
    return;
  }
  // 2) general filter
  for (size_t i = 0; i < candidates->size(); ++i) {
    const ItemInfo& item = (*candidates)[i];
    if (item.show_num < 1000 || item.ctr < 0.05) {
      continue;
    }
    reco::filter::FilterReason filter_reason;
    if (NewsFilter::IsGeneralFiltered(&request, request.shown_dict, item, &filter_reason)) {
      if (debugger != NULL) {
        debugger->SetItemFilterReason(item.item_id, filter_reason);
      }
      continue;
    }
    ret_items->push_back(item);
  }

  LOG(INFO) << "get channel video items: " << ret_items->size();
}

}
}
