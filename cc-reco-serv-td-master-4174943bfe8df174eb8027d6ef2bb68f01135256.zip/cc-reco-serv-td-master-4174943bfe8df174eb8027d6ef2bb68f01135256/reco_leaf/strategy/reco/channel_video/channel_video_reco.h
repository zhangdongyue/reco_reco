#pragma once
#include <vector>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

namespace reco {
class NewsIndex;

namespace leafserver {
class RecoRequest;

class ChannelVideoReco {
 public:
  explicit ChannelVideoReco(const reco::NewsIndex* index);

  ~ChannelVideoReco();

  void GetChannelVideoItems(const RecoRequest& request,
                            std::vector<ItemInfo>* reco_items,
                            RecoDebugger* debugger);
 private:
  const NewsIndex* news_index_;
};
}
}

