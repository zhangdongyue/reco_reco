#include "reco/serv/reco_leaf/strategy/reco/hot_card/hot_card_reco.h"

#include <algorithm>
#include <string>
#include <vector>
#include <utility>
#include "base/strings/string_number_conversions.h"
#include "base/hash_function/city.h"

#include "serving_base/data_manager/data_manager.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"

namespace reco {
namespace leafserver {
DEFINE_double(hot_card_deliver_pb, 0.65, "Hot_card deliver probability");
DEFINE_bool(open_hot_card_debug_mode, false, "if open hot card debug mode");
DEFINE_bool(if_open_hot_card_reco, true, "open hot card reco switch");

const float HotCardReco::kMinCtrThres = 0.001;

HotCardReco::HotCardReco() {
  news_index_ = LeafDataManager::GetGlobalData()->news_index;
  candidates_extractor_ = new CandidatesExtractor(news_index_);
  random_ = new base::PseudoRandom(base::GetTimestamp());
  item_dedup_.set_empty_key(NULL);
  reco_request_.personal_item_dicts = &personal_dict;
}

HotCardReco::~HotCardReco() {
  delete candidates_extractor_;
  delete random_;
}

bool HotCardReco::CompareHotEvent(const std::pair<ItemInfo, double>& a,
                                  const std::pair<ItemInfo, double>& b) {
  return a.second > b.second;
}

bool HotCardReco::GetHotCardReco(
    const reco::user::UserInfo* user_info,
    const HotCardRecommendRequest* request,
    const UserFeature * user_fea,
    const base::dense_hash_set<uint64>* shown_dict,
    const std::vector<std::pair<float, reco::Category> >* category_distributes,
    std::vector<ItemInfo> *hot_event_result,
    CostTrace * cost_trace) {

  if (!FLAGS_if_open_hot_card_reco || !(random_->GetDouble() < FLAGS_hot_card_deliver_pb)) {
    hot_event_result->clear();
    return true;
  }

  // sort table from yunying
  boost::shared_ptr<const reco::dm::IflowItemSortDict> iflow_item_sort_map =
    DM_GET_DICT(reco::dm::IflowItemSortDict, DynamicDictContainer::kIflowItemSortFile_);

  std::vector<ItemInfo> candidates;
  candidates_extractor_->GetHotCardCandidates(&candidates, kCandidatesCutoff);
  const std::vector<ItemInfo> *candidate_items = &candidates;

  std::vector<std::pair<ItemInfo, double> > sort_res_vec;
  for (auto iter = candidate_items->begin();
       (iter != candidate_items->end()); ++iter) {
    if (!FLAGS_open_hot_card_debug_mode) {
      if (shown_dict->find(iter->item_id) != shown_dict->end()) continue;
    }
    double hot_boost = 0.5;
    double time_boost = 0.3;
    double cate_boost = 0.2;

    // hot score
    double hot_score = 10;
    auto hot_iter = iflow_item_sort_map->find(iter->item_id);
    if (hot_iter != iflow_item_sort_map->end()) {
      hot_score = static_cast<double>(hot_iter->second);
    }
    hot_score = pow(hot_score, hot_boost);

    // time score
    const base::Time& current_time = base::Time::Now();
    const base::Time& create_time = base::Time::FromDoubleT((double)iter->create_timestamp / 1e6);
    int hours_span = RecoUtils::GetHourSpanNum(create_time, current_time, 6);
    double time_score = std::max(0, (50 - hours_span * 5)) * 0.8;
    if (iter->time_level == reco::kGoodTimeliness) {
      time_score += iter->time_level * 50 * 0.2;
    } else if (iter->time_level == reco::kMidTimeliness) {
      time_score += iter->time_level * 40 * 0.2;
    } else if (iter->time_level == reco::kBadTimeliness) {
      time_score += iter->time_level * 10 * 0.2;
    }
    time_score = pow(time_score, time_boost);

    // cate score
    const auto& ref_l1_cates = user_fea->merged_fea.l1_cates;
    int l1_cate_num = (int)(ref_l1_cates.size());
    double cate_score = 0.3;
    double l1_cate = 0;
    if (l1_cate_num > 0) {
      auto cate_iter = ref_l1_cates.find(iter->category);
      if (cate_iter != ref_l1_cates.end()) {
         l1_cate = cate_iter->second;
      }
    }
    cate_score = pow(cate_score + l1_cate, cate_boost);

    double score = time_score * hot_score * cate_score;
    sort_res_vec.push_back(std::make_pair(*iter, score));
  }

  sort(sort_res_vec.begin(), sort_res_vec.end(), CompareHotEvent);

  for (auto res_iter = sort_res_vec.begin(); res_iter!= sort_res_vec.end(); ++res_iter) {
    hot_event_result->push_back(res_iter->first);
  }
  return true;
}

uint64 HotCardReco::ComputeHotCardItemId() const {
  const std::string& str = base::StringPrintf("itemtypeHot_card_type");
  uint64 item_id = base::CityHash64(str.c_str(), str.size());
  return item_id;
}
}  // namespace reco_leaf
}
