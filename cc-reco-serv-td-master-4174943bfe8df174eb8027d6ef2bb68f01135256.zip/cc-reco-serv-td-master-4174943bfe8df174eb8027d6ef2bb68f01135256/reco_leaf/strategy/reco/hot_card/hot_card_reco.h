#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <utility>
#include "base/random/pseudo_random.h"
#include "base/time/time.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/reco/offline/item_dict_manager.h"

namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {
class CandidatesExtractor;
class CostTrace;

class HotCardReco {
 public:
  explicit HotCardReco();
  ~HotCardReco();

  // 1. 判断此次 推荐频道页的请求 是否返回 Hot card
//  bool IfQualifyForHotCard(const HotCardRecommendRequest *request,
//                             const reco::UserInfo* user_info) const;

  // 2. 返回 HotCard 的结果
  bool GetHotCardReco(const reco::user::UserInfo* user_info,
                        const HotCardRecommendRequest* request,
                        const UserFeature* user_fea,
                        const base::dense_hash_set<uint64>* show_dict,
                        const std::vector<std::pair<float, reco::Category> >* category_distributes,
                        std::vector<ItemInfo>* hot_event_result,
                        CostTrace * cost_trace);

  static bool CompareHotEvent(const std::pair<ItemInfo, double>& a, const std::pair<ItemInfo, double>& b);

  uint64 ComputeHotCardItemId() const;

 private:
  static const int kRecoScoreFactor = 1000000;
  static const int kCandidatesCutoff = 6000;
  static const float kMinCtrThres;

  const UserFeature* user_fea_;
  const reco::user::UserInfo* user_info_;
  const HotCardRecommendRequest* card_request_;
  const base::dense_hash_set<uint64>* shown_dict_;
  const std::vector<std::pair<float, reco::Category> >* category_distributes_;
  RecoRequest reco_request_;

  base::dense_hash_set<uint64> item_dedup_;

  std::unordered_map<uint64, ItemDictData> personal_dict;

  const NewsIndex* news_index_;
  CandidatesExtractor* candidates_extractor_;
  base::PseudoRandom* random_;
};
}
}

