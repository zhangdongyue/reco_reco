#include "reco/serv/reco_leaf/strategy/reco/goods/goods_reco.h"

#include <algorithm>

#include "reco/serv/reco_leaf/frame/leaf_controller.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/reco_index/news_index.h"

namespace reco {
namespace leafserver {

GoodsReco::GoodsReco(const reco::NewsIndex* index) : news_index_(index) {
  candidates_extractor_ = new CandidatesExtractor(news_index_);
  goods_ranker_ = new ShoppingRanker(index);
  item_dedup_.set_empty_key(NULL);
}

GoodsReco::~GoodsReco() {
  delete candidates_extractor_;
  delete goods_ranker_;
}

void GoodsReco::DoGoodsChannelReco(const RecoRequest* reco_request, const ManualRecoData* manual_data,
                                   std::vector<ItemInfo>* goods_items, RecoContext* context) {
  if (reco_request->channel_id != reco::common::kShoppingId) return;

  item_dedup_.clear();

  // 获取候选集
  timer_.Start();
  std::vector<ItemInfo> machine_items;
  static const int kMaxGoodsCandidateNum = 5000;
  candidates_extractor_->GetCandidatesByChannelId(reco_request->channel_id, reco_request,
                                                  &machine_items, kMaxGoodsCandidateNum, context->debugger());
  context->debugger()->TraceCategoryCandidateItems(machine_items);

  // 调用 shop_ranker
  goods_ranker_->Rank(reco_request, &machine_items);
  context->debugger()->TraceAfterCategoryRankItems(machine_items);

  // 插入运营结果
  for (size_t i = 0; i < manual_data->personal_items.size(); ++i) {
    if (goods_items->size() >= kTopN) break;
    const ItemInfo& item = manual_data->personal_items.at(i);
    if (!NewsFilter::IsDeduped(item, &item_dedup_)) {
      goods_items->push_back(item);
    }
  }
  // 插入机器结果
  for (size_t i = 0; i < machine_items.size(); ++i) {
    if (goods_items->size() >= kTopN) break;
    const ItemInfo& item = machine_items.at(i);
    if (!NewsFilter::IsDeduped(item, &item_dedup_)) {
      goods_items->push_back(item);
    }
  }

  context->cost_trace()->rks = timer_.Stop();
}

}  // namespace reco_leaf
}
