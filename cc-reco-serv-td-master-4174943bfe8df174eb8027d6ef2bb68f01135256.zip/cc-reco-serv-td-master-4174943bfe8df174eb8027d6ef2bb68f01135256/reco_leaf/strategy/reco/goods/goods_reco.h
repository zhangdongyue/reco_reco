#pragma once

#include <string>
#include <vector>
#include <unordered_set>

#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/component/ranker/shopping_ranker.h"
#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/bizc/reco_index/item_info.h"

namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {

// 购物推荐类：
// 1. 商品频道下发策略；
//
class GoodsReco {
 public:
  explicit GoodsReco(const reco::NewsIndex* index);
  ~GoodsReco();

  // 购物频道的推荐接口
  // NOTE(Jianhuang) // 当前 goods 推荐算法比较简单:
  // 1. 获取候选集，并按默认排序进入 rank 阶段
  // 2. rank 阶段也只是处理了多样性
  // TODO(jiawei & jianhuang) 优化下发策略，提升效果
  void DoGoodsChannelReco(const RecoRequest* reco_request, const ManualRecoData* manual_data,
                          std::vector<ItemInfo>* hot_items, RecoContext* context);

 private:
  static const uint32 kTopN = 500;
  const NewsIndex* news_index_;

  CandidatesExtractor* candidates_extractor_;
  ShoppingRanker* goods_ranker_;

  serving_base::Timer timer_;
  base::dense_hash_set<uint64> item_dedup_;
};

}
}

