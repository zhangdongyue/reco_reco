#include "reco/serv/reco_leaf/strategy/reco/im_card/im_card_reco.h"

#include <algorithm>
#include <string>
#include <vector>
#include "base/strings/string_number_conversions.h"
#include "base/hash_function/city.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "serving_base/data_manager/data_manager.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

DEFINE_double(im_card_deliver_pb, 0.75, "im_card deliver probability");
DEFINE_bool(if_im_card_open_timeless, true, "open time less for im card");
DEFINE_bool(if_open_im_card_debug_mode, false, "open time less for im card");

ImCardReco::ImCardReco() {
  news_index_ = LeafDataManager::GetGlobalData()->news_index;
  candidates_extractor_ = new CandidatesExtractor(news_index_);
  random_ = new base::PseudoRandom(base::GetTimestamp());
}

ImCardReco::~ImCardReco() {
  delete candidates_extractor_;
  delete random_;
}

uint64 ImCardReco::ComputeImcardItemId() {
  uint64 item_id = 0;
  std::string IntToString(int value);
  int item_type = reco::kIMCard;
  ImCardType im_card_type = GetImCardType();
  std::string item_id_str = base::StringPrintf("itemtype:%d\tim_card_type:%d", item_type, im_card_type);
  item_id = base::CityHash64(item_id_str.c_str(), item_id_str.size());
  return item_id;
}



bool ImCardReco::IfQualifyForImCard(const UserInfo* user_info) {
  if (FLAGS_if_open_im_card_debug_mode) return true;
  //  NOTE(wangjiawei, online revome)
  //  return true;
  if (!(random_->GetDouble() < FLAGS_im_card_deliver_pb)) return false;
  ImCardType im_card_type = GetImCardType();
  if (im_card_type == reco::leafserver::kDftImCard) {
    return false;
  }

  uint64 item_id = ComputeImcardItemId();
  if (item_id == 0) {
    LOG(WARNING) << "generate the imcard item_id error.";
  }

  base::Time current_time = base::Time::Now();
  base::Time expire_time = current_time - base::TimeDelta::FromHours(3 * 24);

  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int view_imcard_count = 0;
  if (user_info->shown_history_size() > 1) {
    for (int i = user_info->shown_history_size() - 1; i>=0; --i) {
      const reco::user::ViewClickItem& show_item = user_info->shown_history(i);
      if ((show_item.view_timestamp() < expire_timestamp) || (view_imcard_count >= 3)) break;
      if (show_item.item_id() == item_id) {
        // 同一时间段只下发一次
        if (IfSameDuaration(show_item.view_timestamp())) {
          return false;
        }
        ++view_imcard_count;
      }
    }

    // 最近三次展示没有点击，就不下发
    if (view_imcard_count >=3) {
      if (user_info->recent_click_size() > 1) {
        for (int i = user_info->recent_click_size() -1; i>=0; --i) {
          const reco::user::ViewClickItem& click_item = user_info->recent_click(i);
          if (click_item.view_timestamp() < expire_timestamp) break;
          if (click_item.item_id() == item_id) return true;
        }
        return false;
      }
    }
  }
  return true;
}


void ImCardReco::CalcScore(const std::vector<std::pair<float, reco::Category> >* category_distributes,
                           std::vector<ItemInfo> * default_candidate_items) {
  std::unordered_map<std::string, float> category_map;
  for (auto iter = category_distributes->begin(); iter != category_distributes->end(); ++iter) {
    category_map.insert(std::make_pair(iter->second.category(), iter->first));
  }
  for(auto item_iter = default_candidate_items->begin(); item_iter != default_candidate_items->end(); ++item_iter) {
    if (FLAGS_if_im_card_open_timeless) {
      if (item_iter->time_level != kGoodTimeliness) continue;
    }
    auto cate_iter = category_map.find(item_iter->category);
    if (cate_iter != category_map.end()) {
      double cate_score = cate_iter->second;
      item_iter->reco_score = (int)std::min((double)(kRecoScoreFactor - 1) , cate_score * item_iter->ctr * kRecoScoreFactor);
    }
  }
}

ImCardType ImCardReco::GetImCardType() {
  base::Time current_time = base::Time::Now();
  base::Time::Exploded exploded;
  current_time.LocalExplode(&exploded);
  int h = exploded.hour;
  if ((h >= 8) && (h < 13)) {
    return reco::leafserver::kMorningImCard;
  } else if ((h >= 13) && (h < 18)) {
    return reco::leafserver::kMidDayImCard;
  } else if ((h >= 18) && (h < 24)) {
    return reco::leafserver::kNightImCard;
  }

  return reco::leafserver::kDftImCard;
}

ImCardType ImCardReco::GetImCardType(const base::Time &time) {
  base::Time::Exploded exploded;
  time.LocalExplode(&exploded);
  int h = exploded.hour;
  if ((h >= 8) && (h < 13)) {
    return reco::leafserver::kMorningImCard;
  } else if ((h >= 13) && (h < 18)) {
    return reco::leafserver::kMidDayImCard;
  } else if ((h >= 18) && (h < 24)) {
    return reco::leafserver::kNightImCard;
  }

  return reco::leafserver::kDftImCard;
}


bool ImCardReco::IfSameDuaration(int64 view_timestamp) {
  base::Time current_time = base::Time::Now();
  base::Time view_time = base::Time::FromDoubleT(view_timestamp / base::Time::kMicrosecondsPerSecond);

  base::Time::Exploded cur_exploded;
  base::Time::Exploded view_exploded;
  
  current_time.LocalExplode(&cur_exploded);
  view_time.LocalExplode(&view_exploded);

  if (cur_exploded.day_of_month != view_exploded.day_of_month) return false;

  ImCardType now_duration = GetImCardType();
  ImCardType view_duration = GetImCardType(view_time);

  if (view_duration == now_duration) return true;
  return false;
}

void ImCardReco::AddItemVecAndFilter(const std::vector<ItemInfo> *src_vec,
                             std::vector<ItemInfo> *des_vec) {
    // for low quality filter
    reco::ContentAttr content_attr;

    auto dict = DM_GET_DICT(reco::filter::RiskMediaDict, reco::filter::DynamicDictContainer::kRiskMediaFile);

    if (!src_vec || !des_vec || ((int)src_vec->size() == 0)) return;
    for (auto iter = src_vec->begin(); (iter != src_vec->end()) && ((int)des_vec->size() < kCandidatesCut) ; ++iter) {
      if (reco_request_
          && NewsFilter::IsQualityFiltered(*reco_request_, *iter, &content_attr)) continue;

      if (NewsFilter::ChooseSourceMediaFilter(*iter, reco_request_, dict.get()->risk_media_map)) {
        if (reco_request_
            && NewsFilter::IsFilteredBySourceMedia(dict.get(), reco_request_, *iter)) continue;
      } else {
        if (reco_request_
            && NewsFilter::IsFilteredByOrigMediaRiskType(reco_request_, *iter)) continue;
      }
      if (show_dict_
          && (show_dict_->find(iter->item_id) != show_dict_->end())) continue;
      des_vec->push_back(*iter);
    }
}

bool ImCardReco::KeyWordDedup(const uint64 item_id, std::unordered_set<std::string> *keyword_set) {
  reco::FeatureVector key_word;
  news_index_->GetFeatureVectorByItemId(item_id, reco::common::kKeyword, &key_word);
  for (int i = 0; i < key_word.feature_size(); ++i) {
    const std::string &key = key_word.feature(i).literal();
    if (keyword_set->count(key) > 0) {
      return false;
    } else {
      keyword_set->insert(key);
    }
  }
  return true;
}

bool ImCardReco::GetImCardReco(const UserInfo* user_info,
                               const RecoRequest * request,
                               const UserFeature * user_fea,
                               const std::vector<std::pair<float, reco::Category> >* category_distributes,
                               const base::dense_hash_set<uint64>* show_dict,
                               const bool get_user_error,
                               std::vector<ItemInfo> * default_candidate_items,
                               std::vector<ItemInfo> * humor_candidate_items,
                               CostTrace * cost_trace) {
  ImCardType card_type = GetImCardType();
  switch (card_type) {
    case reco::leafserver::kMorningImCard:
      return GetImCardDefaultReco(user_info,
                                  request,
                                  user_fea,
                                  category_distributes,
                                  show_dict,
                                  get_user_error,
                                  default_candidate_items,
                                  humor_candidate_items,
                                  cost_trace);
    case reco::leafserver::kMidDayImCard:
      return GetImCardDefaultReco(user_info,
                                  request,
                                  user_fea,
                                  category_distributes,
                                  show_dict,
                                  get_user_error,
                                  default_candidate_items,
                                  humor_candidate_items,
                                  cost_trace);

    case reco::leafserver::kNightImCard:
      return GetImCardDefaultReco(user_info,
                                  request,
                                  user_fea,
                                  category_distributes,
                                  show_dict,
                                  get_user_error,
                                  default_candidate_items,
                                  humor_candidate_items,
                                  cost_trace);

    default:
      return GetImCardDefaultReco(user_info,
                                  request,
                                  user_fea,
                                  category_distributes,
                                  show_dict,
                                  get_user_error,
                                  default_candidate_items,
                                  humor_candidate_items,
                                  cost_trace);
  }
  return true;
}



bool ImCardReco::GetImCardDefaultReco(const UserInfo* user_info,
                                      const RecoRequest * request,
                                      const UserFeature * user_fea,
                                      const std::vector<std::pair<float, reco::Category> >* category_distributes,
                                      const base::dense_hash_set<uint64>* show_dict,
                                      const bool get_user_error,
                                      std::vector<ItemInfo> * default_candidate_items,
                                      std::vector<ItemInfo> * humor_candidate_items,
                                      CostTrace * cost_trace) {
  serving_base::Timer timer;
  timer.Start();

  reco_request_ = request;
  show_dict_ = show_dict;
  default_candidate_items->clear();
  humor_candidate_items->clear();
  const std::vector<ItemInfo> *jingpin_candidate_items = news_index_->GetJingpinDefaultReco();
  const std::vector<ItemInfo> *candidate_items = news_index_->GetDefaultReco();
  LOG(INFO) << "imcard jingpin candidates size: "<< jingpin_candidate_items->size();
  LOG(INFO) << "imcard default candidates size: "<< candidate_items->size();


  if (!jingpin_candidate_items) {
    LOG(WARNING) << "Get the jingpin reco results error from index when im card reco";
    if (!candidate_items) {
      LOG(WARNING) << "Get the default reco results error from index when im card reco";
      return false;
    } else {
      AddItemVecAndFilter(candidate_items, default_candidate_items);
    }
  } else {
    AddItemVecAndFilter(jingpin_candidate_items, default_candidate_items);
    if (((int)jingpin_candidate_items->size() < 100) && candidate_items) {
      AddItemVecAndFilter(candidate_items, default_candidate_items);
    }
  }

  if (category_distributes->empty() || get_user_error) {
    auto iter = default_candidate_items->begin();
    for(; iter != default_candidate_items->end(); ++iter) {
      if (FLAGS_if_im_card_open_timeless) {
        if (iter->time_level != kGoodTimeliness) continue;
      }
      iter->reco_score = (int)std::min((double)(kRecoScoreFactor - 1) , (double)iter->ctr * kRecoScoreFactor);
    }
  } else {
    CalcScore(category_distributes, default_candidate_items);
  }

  //  NOTE(jiawei) 因为客户端格式的问题(GIF, 图片, 视频等)，这里暂时不召回幽默频道的新闻。
  //  candidates_extractor_->GetCandidatesByChannelId(reco::common::kHumorPicChannelId, reco_request_, humor_candidate_items, 1000);
  std::sort(default_candidate_items->begin(), default_candidate_items->end(), std::greater<ItemInfo>());
  cost_trace->ims = timer.Stop();

  return true;
}

}  // namespace reco_leaf
}
