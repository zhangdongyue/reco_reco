#pragma once

#include <string>
#include <vector>
#include "base/random/pseudo_random.h"
#include "base/time/time.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"
namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {
class ImCardReco {
 public:
  explicit ImCardReco();
  ~ImCardReco();

  // 两个接口
  // 1. 判断此次 推荐频道页的请求 是否返回 im card
  // 2. 返回 ImCard 的结果

  bool IfQualifyForImCard(const reco::user::UserInfo* user_info);

  static ImCardType GetImCardType();
  static ImCardType GetImCardType(const base::Time & time);
  bool IfSameDuaration(int64 view_timestamp);
  bool GetImCardReco(const reco::user::UserInfo* user_info,
                     const RecoRequest * request,
                     const UserFeature * user_fea,
                     const std::vector<std::pair<float, reco::Category> >* category_distributes,
                     const base::dense_hash_set<uint64>* show_dict,
                     const bool get_user_error,
                     std::vector<ItemInfo> * default_items,
                     std::vector<ItemInfo> * humor_items,
                     CostTrace * cost_trace);

  bool GetImCardDefaultReco(const reco::user::UserInfo* user_info,
                            const RecoRequest * request,
                            const UserFeature * user_fea,
                            const std::vector<std::pair<float, reco::Category> >* category_distributes,
                            const base::dense_hash_set<uint64>* show_dict,
                            const bool get_user_error,
                            std::vector<ItemInfo> * default_items,
                            std::vector<ItemInfo> * humor_items,
                            CostTrace * cost_trace);


  static uint64 ComputeImcardItemId();
  void AddItemVecAndFilter(const std::vector<ItemInfo> *src_vec, std::vector<ItemInfo> *des_vec);
  void CalcScore(const std::vector<std::pair<float, reco::Category> >* category_distributes,
                 std::vector<ItemInfo> * default_candidate_items);
  bool KeyWordDedup(const uint64 item_id, std::unordered_set<std::string> *keyword_set);
 private:
  const NewsIndex* news_index_;
  CandidatesExtractor* candidates_extractor_;
  const base::dense_hash_set<uint64>* show_dict_;
  base::PseudoRandom* random_;
  const RecoRequest * reco_request_;
  static const int kRecoScoreFactor = 1000000;
  static const int kCandidatesCut = 5000;
};
}
}

