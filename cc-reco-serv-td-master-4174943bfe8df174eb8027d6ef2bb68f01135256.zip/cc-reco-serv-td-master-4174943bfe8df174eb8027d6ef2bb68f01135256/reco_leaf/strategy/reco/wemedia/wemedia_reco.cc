#include "reco/serv/reco_leaf/strategy/reco/wemedia/wemedia_reco.h"

#include <string>
#include <vector>
#include <queue>

#include "serving_base/data_manager/data_manager.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

const int WeMediaReco::kCandidateCutOff = 8000;
WeMediaReco::WeMediaReco()
    : index_(LeafDataManager::GetGlobalData()->news_index),
    reco_count_(0),
    total_us_(0),
    get_candidate_us_(0),
    rank_us_(0) {
}

WeMediaReco::~WeMediaReco() {
}


bool WeMediaReco::GetWeMediaReco(const UserInfo* user_info,
                                 const WeMediaRecommendRequest *req,
                                 const base::dense_hash_set<uint64> &shown_dict,
                                 const std::vector<std::pair<float, reco::Category>> &distributes,
                                 std::vector<WeMediaRecoResult> *results) {
  base::Time beg_time = base::Time::Now();
  std::unordered_map<std::string,float> wemedias;
  GetCandidateWeMedias(user_info, req, distributes, &wemedias);
  if (wemedias.empty()) {
    return true;
  }

  Filter(user_info, &wemedias);

  base::Time t2 = base::Time::Now();
  Rank(user_info, shown_dict, wemedias, results, req->return_num());
  FillResult(user_info, results);

  std::string logstr = "wemedia reco:\n";
  for (auto iter = results->begin(); iter != results->end(); ++iter) {
    VLOG(2) << "wemediang reco ret: " << iter->Utf8DebugString();
  }

  return true;
}

void WeMediaReco::GetCandidateWeMedias(const UserInfo* user_info,
                                       const WeMediaRecommendRequest *req,
                                       const std::vector<std::pair<float, reco::Category>> &distributes,
                                       std::unordered_map<std::string,float>* wemedias) {
  const int64 channel_id = req->has_channel_id() ? req->channel_id() : reco::common::kRecoChannelId;
  if (channel_id == reco::common::kRecoChannelId) {
    // 推荐频道
    if (distributes.empty()) {
      if (!cache_.Get(wemedias)) {
        const std::vector<ItemInfo>* candidate_items = index_->GetDefaultReco();
        if (candidate_items != NULL) {
          std::unordered_map<std::string,float> temp;
          GetWeMediaFromItems(*candidate_items, 1.0f, &temp);
          cache_.Set(temp);
          for (auto iter = temp.begin(); iter != temp.end(); ++iter) {
            (*wemedias)[iter->first] = iter->second;
          }
        }
      }
    } else {
      for (auto it = distributes.begin(); it != distributes.end(); ++it) {
        std::string category = it->second.category();
        for (int i = 0; i < it->second.parents_size(); ++i) {
          category += "-" + it->second.parents(i);
        }
        if (!cache_.Get(category, wemedias)) {
          const float score = it->first;
          const std::vector<ItemInfo>* candidate_items = index_->GetDefaultReco(it->second);
          if (candidate_items != NULL) {
            std::unordered_map<std::string,float> temp;
            GetWeMediaFromItems(*candidate_items, score, &temp);
            cache_.Set(category, temp);
            for (auto iter = temp.begin(); iter != temp.end(); ++iter) {
              (*wemedias)[iter->first] = iter->second;
            }
          }
        }
      }
    }
  } else {
    // 垂直频道
    if (!cache_.Get(wemedias)) {
      const std::vector<ItemInfo>* candidate_items = index_->GetDefaultReco(channel_id, -1, false);
      if (candidate_items != NULL) {
        std::unordered_map<std::string,float> temp;
        GetWeMediaFromItems(*candidate_items, 1.0f, &temp);
        cache_.Set(channel_id, temp);
        for (auto iter = temp.begin(); iter != temp.end(); ++iter) {
          (*wemedias)[iter->first] = iter->second;
        }
      }
    }
  }

  std::unordered_map<std::string,float> click_wemedias;
  GetWeMediaFromClicks(user_info, 5.0, &click_wemedias);
  for (auto iter = click_wemedias.begin(); iter != click_wemedias.end(); ++iter) {
    auto it_find = wemedias->find(iter->first);
    if (wemedias->end() == it_find) {
      (*wemedias)[iter->first] = iter->second;
    } else {
      it_find->second *= iter->second;
    }
  }
}

void WeMediaReco::Filter(const UserInfo* user_info,
                         std::unordered_map<std::string,float>* wemedias) {
  base::dense_hash_set<std::string> followed_wemedia;
  followed_wemedia.set_empty_key("");
  for (auto i = 0; i < user_info->wemedia_info().info_size(); ++i) {
    followed_wemedia.insert(user_info->wemedia_info().info(i).wemedia_name());
  }

  const int64 cur_stamp = base::GetTimestamp();
  std::unordered_map<std::string, int> today_reco_history;
  std::unordered_map<std::string, int> month_reco_history;

  for (auto i = 0; i < user_info->wemedia_item_history_size(); ++i) {
    const reco::user::WeMediaRecoItem &item = user_info->wemedia_item_history(i);

    if (cur_stamp - item.event_timestamp() < base::Time::kMicrosecondsPerDay)
      today_reco_history[item.wemedia_name()] = 1;

    if (cur_stamp - item.event_timestamp() < 30 * base::Time::kMicrosecondsPerDay) {
      auto it_find = month_reco_history.find(item.wemedia_name());
      if (it_find != month_reco_history.end()) {
        it_find->second += 1;
      } else {
        month_reco_history[item.wemedia_name()] = 1;
      }
    }
  }

  for (auto media_it = wemedias->begin(); media_it != wemedias->end();) {
    const std::string &wemedia_name = media_it->first;

    // 过滤关注过的
    if (followed_wemedia.find(wemedia_name) != followed_wemedia.end()) {
      media_it = wemedias->erase(media_it);
      continue;
    }

    if (today_reco_history.find(wemedia_name) != today_reco_history.end()) {
      media_it = wemedias->erase(media_it);
      continue;
    }

    auto it = month_reco_history.find(wemedia_name);
    if (it != month_reco_history.end() && it->second >= 5) {
      media_it = wemedias->erase(media_it);
      continue;
    }
    ++media_it;
  }
}

struct WeMediaScore {
  float score;
  std::string name;

  bool operator > (const WeMediaScore& rhs) const {
    return score > rhs.score;
  }
};

void WeMediaReco::Rank(const UserInfo* user_info,
                       const base::dense_hash_set<uint64> &shown_dict,
                       const std::unordered_map<std::string,float>& wemedias,
                       std::vector<WeMediaRecoResult>* results,
                       uint32 return_num) {
  std::priority_queue<WeMediaScore, std::vector<WeMediaScore>, std::greater<WeMediaScore>> wemedia_scores;
  for (auto iter = wemedias.begin(); iter != wemedias.end(); ++iter) {
    if (wemedia_scores.size() < return_num || wemedia_scores.top().score < iter->second) {
      WeMediaScore wemedia = { iter->second, iter->first };
      wemedia_scores.push(wemedia);
    }

    if (wemedia_scores.size() > return_num) {
      wemedia_scores.pop();
    }
  }

  auto wemedia_map = index_->GetWeMediaItemsDict();
  while (!wemedia_scores.empty()) {
    WeMediaScore score = wemedia_scores.top();
    wemedia_scores.pop();
    WeMediaRecoResult result;
    result.set_wemedia_name(score.name);

    auto iter_dict = wemedia_map->find(score.name);
    if (wemedia_map->end() == iter_dict) {
      continue;
    }
    auto& item_ids = iter_dict->second;
    uint64 item_id = 0, item_create_time = 0;
    for (auto ids_iter = item_ids.begin(); ids_iter != item_ids.end(); ++ids_iter) {
      if (shown_dict.find(*ids_iter) != shown_dict.end()) continue;

      uint64 create_time = index_->GetCreateTimestampByItemId(*ids_iter);
      if (create_time > item_create_time) {
        create_time = item_create_time;
        item_id = *ids_iter;
      }
    }

    result.add_item_ids(item_id);
    results->push_back(result);
  }
}

void WeMediaReco::GetWeMediaFromItems(const std::vector<ItemInfo>& items,
                                      float score,
                                      std::unordered_map<std::string,float>* wemedias) {
  /*
  float ratio = 1.0f;
  switch (LeafDataManager::GetGlobalData()->sys_status) {
    case kSysFree:
      ratio = 1.5f;
      break;
    case kSysBusy:
      ratio = 0.8f;
      break;
    case kSysFull:
      ratio = 0.6f;
      break;
    case kSysDanger:
      ratio = 0.4f;
      break;
    case kSysCritical:
      ratio = 0.2f;
      break;
  }
  */

  const float ratio = LeafDataManager::GetGlobalData()->GetSelectionRatio();
  const int cutoff = std::min(kCandidateCutOff, (int)(items.size()*ratio));
  for (auto iter = items.begin(); iter != items.end() && iter-items.begin() <= cutoff; ++iter) {
    std::string wemedia_name;
    if (index_->GetWeMediaPersonByItemId(iter->item_id, &wemedia_name)) {
      auto it_find = wemedias->find(wemedia_name);
      if (wemedias->end() == it_find) {
        (*wemedias)[wemedia_name] = score;
      } else {
        it_find->second += score;
      }
    }
  }
}

void WeMediaReco::GetWeMediaFromClicks(const UserInfo* user_info,
                                       float score,
                                       std::unordered_map<std::string,float>* wemedias) {
  for (auto i = 0; i < user_info->recent_click_size() && i < (int)kCandidateCutOff; ++i) {
    const uint64 click_id = user_info->recent_click(i).item_id();
    std::string wemedia_name;
    if (index_->GetWeMediaPersonByItemId(click_id, &wemedia_name)) {
      auto it_find = wemedias->find(wemedia_name);
      if (wemedias->end() == it_find) {
        (*wemedias)[wemedia_name] = score;
      } else {
        it_find->second += score;
      }
    }
  }
}

void WeMediaReco::FillResult(const UserInfo* user_info,
                std::vector<WeMediaRecoResult> *results) {
  auto wemedia_map = index_->GetWeMediaItemsDict();
  for (auto iter = results->begin(); iter != results->end(); ++iter) {
    const std::string &wemedia_name = iter->wemedia_name();
    auto wemedia_it = wemedia_map->find(wemedia_name);
    if (wemedia_it == wemedia_map->end())
      continue;

    const std::unordered_set<uint64> &item_ids = wemedia_it->second;
    uint32 clicked_cnt = 0;
    for (auto i = 0; i < user_info->recent_click_size(); ++i) {
      const uint64 click_id = user_info->recent_click(i).item_id();
      if (item_ids.find(click_id) != item_ids.end())
        clicked_cnt++;
    }
    iter->set_read_num(clicked_cnt);

    if (0 == iter->item_ids_size()) continue;
    uint64 item_id = iter->item_ids(0);
    if (item_id != 0) {
      std::string title;
      if (index_->GetItemTitleByItemId(item_id, &title)) {
        iter->set_title(title);
      }

      ItemInfo item_info;
      if (index_->GetItemInfoByItemId(item_id, &item_info, false)) {
        iter->set_category(item_info.category);
      }
    }
  }
}
}
}
