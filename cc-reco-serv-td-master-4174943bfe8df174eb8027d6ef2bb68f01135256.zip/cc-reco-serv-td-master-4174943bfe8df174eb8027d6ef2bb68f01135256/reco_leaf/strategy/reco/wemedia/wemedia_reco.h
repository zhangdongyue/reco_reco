#pragma once
#include <vector>
#include <unordered_map>

#include "base/container/dense_hash_set.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/reco_index/news_index.h"

namespace reco {
class NewsIndex;

class WeMediaCache {
 public:
  struct CacheNode {
    base::Time create_time;
    std::unordered_map<std::string, float> wemedia_scores;
  };

  void Set(const std::unordered_map<std::string, float>& wemedia_scores) {
    default_category_cache_ = { base::Time::Now(), wemedia_scores };
  }

  void Set(std::string category, const std::unordered_map<std::string, float>& wemedia_scores) {
    category_cache_[category] = { base::Time::Now(), wemedia_scores };
  }

  void Set(int64 channelid, const std::unordered_map<std::string, float>& wemedia_scores) {
    channel_cache_[channelid] = { base::Time::Now(), wemedia_scores };
  }

  bool Get(std::unordered_map<std::string, float>* wemedia_scores) {
    if ((base::Time::Now()-default_category_cache_.create_time).InSeconds() > expire_time_sec_) {
      return false;
    }

    for (auto iter = default_category_cache_.wemedia_scores.begin();
         iter != default_category_cache_.wemedia_scores.end(); ++iter) {
      (*wemedia_scores)[iter->first] = iter->second;
    }
    //*wemedia_scores = default_category_cache_.wemedia_scores;
    return true;
  }

  bool Get(std::string category, std::unordered_map<std::string, float>* wemedia_scores) {
    auto it_find = category_cache_.find(category);
    if (category_cache_.end() == it_find) {
      return false;
    }

    if ((base::Time::Now()-it_find->second.create_time).InSeconds() > expire_time_sec_) {
      return false;
    }

    for (auto iter = it_find->second.wemedia_scores.begin();
         iter != it_find->second.wemedia_scores.end(); ++iter) {
      (*wemedia_scores)[iter->first] = iter->second;
    }
    //*wemedia_scores = it_find->second.wemedia_scores;
    return true;
  }

  bool Get(int64 channelid, std::unordered_map<std::string, float>* wemedia_scores) {
    auto it_find = channel_cache_.find(channelid);
    if (channel_cache_.end() == it_find) {
      return false;
    }

    if ((base::Time::Now()-it_find->second.create_time).InSeconds() > expire_time_sec_) {
      return false;
    }

    for (auto iter = it_find->second.wemedia_scores.begin();
         iter != it_find->second.wemedia_scores.end(); ++iter) {
      (*wemedia_scores)[iter->first] = iter->second;
    }
    //*wemedia_scores = it_find->second.wemedia_scores;
    return true;
  }

 private:
    std::unordered_map<std::string, CacheNode> category_cache_;
    std::unordered_map<int64, CacheNode> channel_cache_;
    CacheNode default_category_cache_;
    static const int expire_time_sec_ = 600;
};


namespace leafserver {
class WeMediaReco {
 public:
  explicit WeMediaReco();

  ~WeMediaReco();

  bool GetWeMediaReco(const reco::user::UserInfo* user_info,
                      const WeMediaRecommendRequest *req,
                      const base::dense_hash_set<uint64> &shown_dict,
                      const std::vector<std::pair<float, reco::Category>> &distributes,
                      std::vector<WeMediaRecoResult> *results);

 private:
  void GetCandidateWeMedias(const reco::user::UserInfo* user_info,
                            const WeMediaRecommendRequest *req,
                            const std::vector<std::pair<float, reco::Category>> &distributes,
                            std::unordered_map<std::string,float>* wemedias);

  void Filter(const reco::user::UserInfo* user_info,
              std::unordered_map<std::string,float>* wemedias);

  void Rank(const reco::user::UserInfo* user_info,
            const base::dense_hash_set<uint64> &shown_dict,
            const std::unordered_map<std::string,float>& wemedias,
            std::vector<WeMediaRecoResult>* results,
            uint32 return_num);

  void GetWeMediaFromItems(const std::vector<ItemInfo>& items,
                           float score,
                           std::unordered_map<std::string,float>* wemedias);

  void GetWeMediaFromClicks(const reco::user::UserInfo* user_info,
                            float score,
                            std::unordered_map<std::string,float>* wemedias);

  void FillResult(const reco::user::UserInfo* user_info,
                  std::vector<WeMediaRecoResult> *results);


 private:
  static const int kCandidateCutOff;
  const NewsIndex* index_;
  WeMediaCache cache_;

  atomic_int reco_count_;
  atomic_long total_us_;
  atomic_long get_candidate_us_;
  atomic_long rank_us_;
};
}
}

