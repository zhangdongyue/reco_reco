#include "reco/serv/reco_leaf/strategy/reco/porn_item/porn_item_reco.h"

#include <string>
#include <vector>

#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/reco_index/item_info.h"

namespace reco {
class NewsIndex;

namespace leafserver {

DEFINE_double(porn_item_new_user_click_threshold, 20.0f, "porn_item_new_user_click_threshold");
DEFINE_bool(porn_beauty_strategy, true, "porn beauty strategy");

PornItemReco::PornItemReco(const reco::NewsIndex* index) {
  news_index_ = index;
  candidates_extrator_ = new CandidatesExtractor(index);
}

PornItemReco::~PornItemReco() {
  delete candidates_extrator_;
}

void PornItemReco::Reset() {
}

void PornItemReco::GetPornItems(const RecoRequest& request,
                                std::vector<ItemInfo>* ret_items,
                                RecoDebugger* debugger) {
  Reset();
  base::Time current_time = base::Time::Now();
  base::Time::Exploded exploded;
  current_time.LocalExplode(&exploded);
  if (FLAGS_porn_beauty_strategy && 6 <= exploded.hour && exploded.hour < 20) {
    return;
  }

  bool is_porn_user = false;
  for (int idx = 0; idx < request.user_info->user_group_info().user_groups_size(); ++idx) {
    const std::string& group_name = request.user_info->user_group_info().user_groups(idx).group_name();
    if (group_name == "色情人群") {
      is_porn_user = true;
    }
  }
  VLOG(1) << "is_porn_user:" << is_porn_user
          << " has_ali_profile:" << request.user_info->has_ali_profile()
          << " click_num:" << request.user_feas->merged_info.total_click_num;
  if (request.user_feas->merged_info.total_click_num > (float)FLAGS_porn_item_new_user_click_threshold) {
    return;
  }
  const std::string type = "pic";
  candidates_extrator_->GetPornItemCandidates(&request, type, ret_items, 10, debugger);
  LOG(INFO) << "get porn result: " << ret_items->size() << " " << type;
}

}  // leafserver
}
