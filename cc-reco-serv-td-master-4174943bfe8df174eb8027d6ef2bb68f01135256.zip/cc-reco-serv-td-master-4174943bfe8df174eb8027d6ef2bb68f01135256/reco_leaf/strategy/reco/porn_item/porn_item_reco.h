#pragma once
#include <vector>

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

namespace reco {
class NewsIndex;

namespace leafserver {
class RecoRequest;

class PornItemReco {
 public:
  explicit PornItemReco(const reco::NewsIndex* index);

  ~PornItemReco();

  void GetPornItems(const RecoRequest& request,
                    std::vector<ItemInfo>* reco_items,
                    RecoDebugger* debugger);
 private:
  void Reset();

  const NewsIndex* news_index_;
  CandidatesExtractor* candidates_extrator_;
};

}  // namespace leafserver
}  // namespace reco

