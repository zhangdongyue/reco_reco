#pragma once

#include "reco/serv/reco_leaf/strategy/reco/manual/manual_reco.h"

namespace reco {
namespace leafserver {
inline bool ManualReco::IsProbeCandidate(const ItemInfo& item, std::string* card) const {
  card->clear();
  if (item.strategy_type == reco::kBanner) return false;
  std::string title;
  if (!news_index_->GetItemTitleByItemId(item.item_id, &title)) return false;
  std::string editor_name;
  editor_name = news_index_->GetUCBEditorNameByDocId(item.doc_id);
  for (size_t i = 0; i < manual_card_prefixes_.size(); ++i) {
    if (title.find(manual_card_prefixes_[i]) != std::string::npos) {
      *card = manual_card_prefixes_[i];
      return true;
    }
    if (editor_name.find(manual_card_prefixes_[i]) != std::string::npos) {
      *card = manual_card_prefixes_[i];
      return true;
    }
  }
  return false;
}

inline bool ManualReco::IsChannelDaoliuItem(const ItemInfo& item) const {
  int32 style_type = news_index_->GetUCBStyleTypeByDocId(item.doc_id);
  return style_type == 29;
}


inline bool ManualReco::IsNewsBanner(int style_type) const {
  static std::unordered_set<int> news_banner_set = {1,2,3,4,5,6,7,8,10,11,12,14,20,21,22,23,27,29,31}; // NOLINT
  return (news_banner_set.find(style_type) != news_banner_set.end());
}

inline bool ManualReco::IsEntranceBanner(int style_type) const {
  static std::unordered_set<int> entrance_banner_set = {13, 15, 16, 17, 18, 32, 47};
  return (entrance_banner_set.find(style_type) != entrance_banner_set.end());
}

inline bool ManualReco::IsDaoliuBanner(int style_type) const {
  static std::unordered_set<int> entrance_banner_set = {33, 48};
  return (entrance_banner_set.find(style_type) != entrance_banner_set.end());
}

inline bool ManualReco::IsFilteredByBannerTimes(
    uint64 item_id, const reco::UcBrowserDeliverSetting& ucb_setting) const {
  if (!ucb_setting.has_banner_times() || ucb_setting.banner_times() <= 0) {
    return false;
  }

  int banner_times = ucb_setting.banner_times();
  int show_times = 0;
  for (int i = reco_request_->user_info->shown_history_size() - 1; i >= 0; --i) {
    if (show_times >= banner_times) {
      break;
    }
    const reco::user::ViewClickItem& show_item = reco_request_->user_info->shown_history(i);
    if (show_item.item_id() == item_id) {
      ++show_times;
    }
  }

  return (show_times >= banner_times);
}

inline bool ManualReco::IsSpecialItem(const ItemInfo& item) const {
  int32 style_type = news_index_->GetUCBStyleTypeByDocId(item.doc_id);
  // 专题及其它特性文章
  if (item.item_type == reco::kSpecial
      || item.item_type == reco::kStarCard
      || item.item_type == reco::kSportLiveCard
      || item.item_type == reco::kTopicCard
      || item.item_type == reco::kWeMediaCard) {
    if (style_type != 38) {
      return true;
    }
  }

  // 样式 11 和 样式 12 展现形式跟专题一样，下发时跟专题做一样的控制
  // 样式 68 为头条有声卡片，和专题卡片做相同的控制
  if (style_type == 11 || style_type == 12 || style_type == 68) {
    return true;
  }

  return false;
}

inline bool ManualReco::IsAssembleBigPicStyle(const ItemInfo& item) const {
  int32 style_type = news_index_->GetUCBStyleTypeByDocId(item.doc_id);
  return (style_type == 3);
}

inline bool ManualReco::IsRegionDeliverItem(const ItemInfo& item) const {
  reco::UcBrowserDeliverSetting ucb_setting;
  if (news_index_->GetUCBSettingByItemId(item.item_id, &ucb_setting)
      && (ucb_setting.province_size() > 0 || ucb_setting.city_size() > 0)) {
    return true;
  }
  return false;
}

inline bool ManualReco::IsAssembleSubItemStyleType(const ItemInfo& item) const {
  int32 style_type = news_index_->GetUCBStyleTypeByDocId(item.doc_id);
  return IsAssembleSubItemStyleType(style_type);
}

inline bool ManualReco::IsAssembleSubItemStyleType(int32 style_type) const {
  static std::unordered_set<int> sub_item_style_type = {1, 2, 3, 4, 5, 6, 20, 27};
  return (sub_item_style_type.find(style_type) != sub_item_style_type.end());
}


}
}
