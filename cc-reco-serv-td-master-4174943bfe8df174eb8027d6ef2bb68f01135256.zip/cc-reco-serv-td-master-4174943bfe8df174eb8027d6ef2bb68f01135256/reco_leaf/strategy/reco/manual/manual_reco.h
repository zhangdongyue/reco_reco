#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/filter_rule.pb.h"
#include "reco/bizc/reco_index/item_info.h"

#include "base/time/time.h"

namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {

struct ManualItemExtInfo;

class ManualReco {
 public:
  explicit ManualReco(const reco::NewsIndex* index);

  ~ManualReco();

  // 抽取运营文章
  void GetManualItems(const RecoRequest* reco_request,
                      ManualRecoData* manual_reco_data,
                      RecoDebugger* debugger);

 private:
  // 抽取运营文章信息
  void ExtractManualItemExtInfo(int64 channel_id,
                                const std::vector<ItemInfo>& items,
                                std::vector<ManualItemExtInfo>* ext_infos);
  // 获取运营全量下发文章
  // 包括一级要闻 二级要闻
  // banner 包含在一级要闻队列中
  void ExtractManualWholeItems(int64 channel_id,
                               const std::vector<ItemInfo>& candidate_items,
                               const std::vector<ManualItemExtInfo>& item_ext_vec,
                               ManualRecoData* manual_reco_data,
                               RecoDebugger* debugger) const;

  // 获取运营分类全量下发文章
  void ExtractManualCategoryWholeItems(int64 channel_id,
                                       const std::vector<ItemInfo>& candidate_items,
                                       const std::vector<ManualItemExtInfo>& item_ext_vec,
                                       ManualRecoData* manual_reco_data) const;

  // 获取运营个性化下发文章
  void ExtractManualPersonalItems(int64 channel_id,
                                  const std::vector<ItemInfo>& candidate_items,
                                  const std::vector<ManualItemExtInfo>& item_ext_vec,
                                  ManualRecoData* manual_reco_data) const;

  // 抽取早晚头条自动卡片及其候选子文
  void ExtractCardAssembleCandidates(const RecoRequest* reco_request,
                                     const std::vector<ItemInfo>& candidate_items,
                                     const std::vector<ManualItemExtInfo>& item_ext_vec,
                                     ManualRecoData* manual_reco_data);
  // 抽取事件专题卡片及其子文
  void ExtractEventCardCandidates(const RecoRequest* reco_request,
                                  ManualRecoData* manual_reco_data);

  bool CardCandidateFilter(const ItemInfo& item);

 private:
  // 是否进入 probe 候选
  bool IsProbeCandidate(const ItemInfo& item, std::string* card) const;
  // 是否频道导流的文章
  bool IsChannelDaoliuItem(const ItemInfo& item) const;
  // 置顶是否已经达到展现次数
  bool IsFilteredByBannerTimes(uint64 item_id,
                               const reco::UcBrowserDeliverSetting& ucb_setting) const;
  // 新闻类置顶
  bool IsNewsBanner(int style_type) const;
  // 入口类置顶
  bool IsEntranceBanner(int style_type) const;
  // 特色样式的文章
  bool IsSpecialItem(const ItemInfo& item) const;
  // 导流类置顶
  bool IsDaoliuBanner(int style_type) const;
  // 是否是按地域下发的新闻
  bool IsRegionDeliverItem(const ItemInfo& item) const;
  // 是否是头条卡片子文大图样式
  bool IsAssembleBigPicStyle(const ItemInfo& item) const;
  // 是否是头条卡片可组卡子文的样式
  bool IsAssembleSubItemStyleType(const ItemInfo& item) const;
  bool IsAssembleSubItemStyleType(int32 style_type) const;
  bool GetCachedItemExts(uint64 uid, int64 cid,
                         std::vector<ManualItemExtInfo>* cached_ext_vec,
                         base::dense_hash_map<uint64, int>* item_ext_map) const;

 private:
  const NewsIndex* news_index_;

  const RecoRequest* reco_request_;

  CandidatesExtractor* candidates_extrator_;

  std::vector<std::string> manual_card_prefixes_;
  std::unordered_set<std::string> auto_card_candidate_cates_;

  std::vector<ManualItemExtInfo> item_ext_vec_;
  base::Time current_time_;
  // std::vector<ManualItemExtInfo> cached_item_ext_vec_;
  // base::dense_hash_map<uint64, int> cached_item_ext_map_;

  // static serving_base::ExpiryMap<uint64, std::vector<ManualItemExtInfo> >* manual_ext_cache_;
};

struct ManualItemExtInfo {
 public:
  bool is_filtered;
  reco::filter::FilterReason filter_reason;

  uint64 item_id;
  bool is_special;  // 是否是专题

  bool hit_channel;  // 是否命中频道
  bool hit_video_channel;  // 是否命中视频频道
  bool hit_standalone_channel;  // 是否是独立频道：内容不下发到其他频道

  std::string probe_card;   // 探索卡片，为空表示不是

  bool is_banner;  // 是否是置顶
  bool is_news_banner;  // 是否是新闻置顶
  bool is_entrance_banner;  // 是否是入口置顶
  bool is_daoliu_banner;  // 是否是导流置顶
  bool is_rotation_banner;  // 是否是轮播置顶
  int importance;  // 1 一级要闻, 2 二级要闻
  std::string appname_priority; // 渠道优先级，小渠道为appname, 全渠道本字段为空

  int32 style_type;
  reco::UcBrowserOperSrcArea oper_area;
  std::unordered_set<std::string> deliver_tags;

  int sort_score;

  ManualItemExtInfo() { Reset(); }

  bool get_is_filtered() const { return is_filtered; }
  reco::filter::FilterReason get_filter_reason() const { return filter_reason; }

  void SetIsFiltered(bool is_filter, reco::filter::FilterReason filter_rsn) {
    is_filtered = is_filter;
    filter_reason = filter_rsn;
  }

  void Reset() {
    is_filtered = false;
    filter_reason = reco::filter::kNoFiltered;
    is_special = false;
    hit_channel = false;
    hit_video_channel = false;
    hit_standalone_channel = false;
    is_banner = false;
    is_news_banner = false;
    is_entrance_banner = false;
    is_daoliu_banner = false;
    is_rotation_banner = false;
    style_type = 0;
    oper_area = reco::kWholeDeliver;
    deliver_tags.clear();
    sort_score = -1;
    importance = 2;
    appname_priority.clear();
    probe_card.clear();
  }
};
}
}

