#include "reco/serv/reco_leaf/strategy/reco/manual/manual_reco.h"
#include "reco/serv/reco_leaf/strategy/reco/manual/manual_reco-inl.h"

#include <algorithm>
#include <unordered_map>
#include <utility>
#include <limits>
#include <functional>

#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/common/item_level_define.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "serving_base/data_manager/data_manager.h"
#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "reco/serv/reco_leaf/strategy/common/topn.h"
#include "reco/base/dict_manager/dict_manager.h"

#include "serving_base/utility/timer.h"

#include "base/time/time.h"
#include "base/strings/string_printf.h"
#include "base/common/logging.h"
#include "net/counter/export.h"

namespace reco {
namespace leafserver {

DECLARE_uint64(assemble_card_test_item_id);
DEFINE_bool(manual_reco_test_env, false, "if open manual reco cache");
DEFINE_bool(open_manual_reco_cache, false, "if open manual reco cache");
DEFINE_int32(auto_card_time_threshold_in_hour, 24, "auto card time threshold in hour");
DEFINE_int32(manual_candidate_cutoff, 7000, "manual candidate cutoff");

ManualReco::ManualReco(const reco::NewsIndex* index) : news_index_(index) {
  const char* ManualCardPrefixes[] = { "早间头条", "午间头条", "晚间头条", "早间段子",
    "晚间段子", "今日要闻", "UC早头条", "不服来辩",
    "人物汇", "一语惊人", "小贱日报", "今日星播报",
    "影视荟", "每日神评论", "周一精选", "周二精选",
    "周三精选", "周四精选", "周五精选", };
  for(size_t i = 0; i < ARRAYSIZE_UNSAFE(ManualCardPrefixes); ++i) {
    manual_card_prefixes_.push_back(ManualCardPrefixes[i]);
  }
  auto_card_candidate_cates_ = std::unordered_set<std::string>({"娱乐", "军事", "财经",
    "科技", "汽车", "国内", "体育", "社会", "国际", "房产", "教育", "时尚", "生活服务"});

  candidates_extrator_ = new CandidatesExtractor(index);
}

ManualReco::~ManualReco() {
  delete candidates_extrator_;
  // delete manual_ext_cache_;
}

void ManualReco::GetManualItems(const RecoRequest* reco_request,
                                ManualRecoData* manual_reco_data,
                                RecoDebugger* debugger) {
  reco_request_ = reco_request;
  manual_reco_data->Clear();
  current_time_ = base::Time::Now();

  // 候选集
  std::vector<ItemInfo> candidates;
  candidates_extrator_->GetUCBCandidates(reco_request, &candidates, FLAGS_manual_candidate_cutoff);
  const std::vector<ItemInfo>* candidate_items = &candidates;
  if (candidate_items == NULL || candidate_items->empty()) {
    return;
  }
  LOG_EVERY_N(INFO, 1000) << "manual items count: " << candidate_items->size();

  // 填充 manualExtInfo
  item_ext_vec_.clear();
  ExtractManualItemExtInfo(reco_request->channel_id, *candidate_items, &item_ext_vec_);
  CHECK_EQ(item_ext_vec_.size(), candidate_items->size());
  debugger->TraceManualItemFilterInfo(*candidate_items, item_ext_vec_);

  // 抽取全量下发文章, 包括一级要闻与二级要闻
  // 置顶新闻放在一级要闻队列前列
  ExtractManualWholeItems(reco_request->channel_id,
                          *candidate_items, item_ext_vec_,
                          manual_reco_data,
                          debugger);

  // 抽取类别全量下发文章
  ExtractManualCategoryWholeItems(reco_request->channel_id,
                                  *candidate_items, item_ext_vec_,
                                  manual_reco_data);

  // 抽取个性化下发文章
  ExtractManualPersonalItems(reco_request->channel_id,
                             *candidate_items,
                             item_ext_vec_,
                             manual_reco_data);

  // 抽取自动组装卡片及候选
  ExtractCardAssembleCandidates(reco_request,
                                *candidate_items,
                                item_ext_vec_,
                                manual_reco_data);

  // 抽取自动组装事件引导卡片
  ExtractEventCardCandidates(reco_request, manual_reco_data);

  debugger->TraceManualTopImportanceItems(manual_reco_data->top_importance_items);
  debugger->TraceManualSndImportanceItems(manual_reco_data->snd_importance_items);
  debugger->TraceManualCategoryWholeItems(manual_reco_data->category_whole_items);
  debugger->TraceManualPersonalItems(manual_reco_data->personal_items);
}

void ManualReco::ExtractManualItemExtInfo(int64 channel_id,
                                          const std::vector<ItemInfo>& candidate_items,
                                          std::vector<ManualItemExtInfo>* item_ext_vec) {
  item_ext_vec->clear();

  // 排序表
  boost::shared_ptr<const reco::dm::IflowItemSortDict> iflow_item_sort_map =
    DM_GET_DICT(reco::dm::IflowItemSortDict, DynamicDictContainer::kIflowItemSortFile_);

  const reco::common::AppNames app_name = RecoUtils::GetAppName(reco_request_->request->app_token());
  std::vector<std::string> flds;
  std::vector<int64> channel_ids;
  std::string user_dn = "";
  if (reco_request_->request->has_uc_user_param()
      && reco_request_->request->uc_user_param().has_dn()) {
    user_dn = reco_request_->request->uc_user_param().dn();
  }

  auto app_token_bit_index = DM_GET_DICT(reco::filter::AppTokenBitIndex,
                                         reco::filter::DynamicDictContainer::kAppTokenBitIndexFile);
  int app_token_idx = -1;
  if (app_token_bit_index.get() != NULL) {
    auto iter = app_token_bit_index->app_token_bit_index.find(reco_request_->request->app_token());
    if (iter != app_token_bit_index->app_token_bit_index.end()) {
      app_token_idx = iter->second;
    }
  }

  reco::filter::FilterReason filter_reason = reco::filter::kGlobalAndDnUcbFiltered;

  item_ext_vec->resize(candidate_items.size());

  int remain_item_num = 0;
  const auto ucb_setting_dict = news_index_->GetUcbSettingDict();
  for (size_t i = 0; i < item_ext_vec->size(); ++i) {
    const ItemInfo& item = candidate_items[i];
    ManualItemExtInfo& ext_info = (*item_ext_vec)[i];
    ext_info.item_id = item.item_id;
    if (remain_item_num >= 1500) {
      ext_info.is_filtered = true;
      ext_info.filter_reason = reco::filter::kUnknownFiltered;
      continue;
    }
    //////////////////////// 时间过滤
    if (!reco_request_->is_update_req) {
      int64 item_timestamp = item.create_timestamp;
      if (!(reco_request_->start_news_timestamp <= item_timestamp
            && item_timestamp < reco_request_->end_news_timestamp)) {
        ext_info.SetIsFiltered(true, reco::filter::kTimeFiltered);
        VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(reco::filter::kTimeFiltered)
                << " : " << item.item_id;
        continue;
      }
    }
    // app name 过滤
    if (!news_index_->IsValidInAppByItemId(item.item_id, app_name)) {
      ext_info.SetIsFiltered(true, reco::filter::kAppNameFiltered);
      VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(reco::filter::kAppNameFiltered)
              << " : " << item.item_id;
      continue;
    }
    // 视频和视频专题只在 wifi 用户和视频深度用户下发
    if (!reco_request_->can_deliver_video) {
      bool video_filter = false;
      if (item.item_type == reco::kPureVideo) {
        video_filter = true;
      } else if (item.item_type == reco::kSpecial) {
        std::unordered_set<uint64> preview_ids;
        if (news_index_->GetPreviewIdsByItemId(item.item_id, &preview_ids)) {
          video_filter = true;
          reco::ItemType item_type;
          for (auto item_iter = preview_ids.begin(); item_iter != preview_ids.end(); ++item_iter) {
            if (!news_index_->GetItemTypeByItemId(*item_iter, &item_type) ||
                item_type != reco::kPureVideo) {
              video_filter = false;
              break;
            }
          }
        }
      }
      if (video_filter) {
        ext_info.SetIsFiltered(true, reco::filter::kVideoIllegalNetFiltered);
        VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(reco::filter::kVideoIllegalNetFiltered)
                << " : " << item.item_id;
        continue;
      }
    }
    /////////////////////////  频道限制
    channel_ids.clear();
    if (!news_index_->GetChannelsByDocId(item.doc_id, &channel_ids)) {
      ext_info.SetIsFiltered(true, reco::filter::kChannelFiltered);
      VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(reco::filter::kChannelFiltered)
              << " : " << item.item_id;
      continue;
    }
    for (int j = 0; j < (int)channel_ids.size(); ++j) {
      if (channel_ids[j] == channel_id) {
        ext_info.hit_channel = true;
        break;
      } else if (reco::common::IsVideoChannel(channel_ids[j])) {
        ext_info.hit_video_channel = true;
      } else if (RecoUtils::IsStandaloneChannel(channel_ids[j])) {
        ext_info.hit_standalone_channel = true;
      }
    }
    if (!ext_info.hit_channel) {
      if (ext_info.hit_video_channel) {
        ext_info.SetIsFiltered(true, reco::filter::kHitVideoChannelFiltered);
        VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(reco::filter::kHitVideoChannelFiltered)
                << " : " << item.item_id;
        continue;
      }
      // 独立频道文章不被其他频道引用
      if (ext_info.hit_standalone_channel) {
        ext_info.SetIsFiltered(true, reco::filter::kHitStandaloneFiltered);
        VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(reco::filter::kHitStandaloneFiltered)
                << " : " << item.item_id;
        continue;
      }
      // stype = 20 的文章只在本频道下发
      if (ext_info.style_type == 20) {
        ext_info.SetIsFiltered(true, reco::filter::kHitStandaloneFiltered);
        VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(reco::filter::kHitStandaloneFiltered)
                << " : " << item.item_id;
        continue;
      }
      if (IsChannelDaoliuItem(item)) {
        ext_info.SetIsFiltered(true, reco::filter::kDaoliuFiltered);
        VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(reco::filter::kDaoliuFiltered)
                << " : " << item.item_id;
        continue;
      }
    }
    /////////////////////////////// 投放设置
    const auto ucb_iter = ucb_setting_dict->find(item.item_id);
    if (ucb_iter == ucb_setting_dict->end()) {
      LOG(WARNING) << "item has not ucb setting, " << item.item_id;
      ext_info.SetIsFiltered(true, reco::filter::kCannotGetUcbSettingFiltered);
      continue;
    }
    const reco::UcBrowserDeliverSetting& ucb_setting = ucb_iter->second;
    // 商业化软文不抽取到其他频道
    if (ucb_setting.oper_item_type() == 1 && !ext_info.hit_channel) {
      ext_info.SetIsFiltered(true, reco::filter::kFilterByCommerceNotHitChannel);
      VLOG(2) << "filtered by "
              << reco::filter::FilterReason_Name(reco::filter::kFilterByCommerceNotHitChannel)
              << " : " << item.item_id;
      continue;
    }
    // global & dn ucb filter
    if (NewsFilter::IsUCBDeliverFiltered(reco_request_,
                                         NULL,
                                         item,
                                         ucb_setting,
                                         app_token_idx,
                                         &filter_reason)) {
      //   || NewsFilter::IsUCBDnFiltered(user_dn, item, ucb_setting)) {
      ext_info.SetIsFiltered(true, filter_reason);
      VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(filter_reason) << " : " << item.item_id;
      continue;
    }
    // 样式类型
    ext_info.style_type = news_index_->GetUCBStyleTypeByDocId(item.doc_id);
    // 投放区域
    ext_info.oper_area =
            ucb_setting.has_oper_src_area() ? ucb_setting.oper_src_area() : reco::kWholeDeliver;
    // tag 设置
    ext_info.deliver_tags.clear();
    for (int k = 0; k < ucb_setting.tag_size(); ++k) {
      flds.clear();
      base::SplitString(ucb_setting.tag(k), "`", &flds);
      if (!flds[0].empty()) {
        ext_info.deliver_tags.insert(flds[0]);
      }
    }

    // importance
    if (ucb_setting.has_importance() && ucb_setting.importance() > 0) {
      ext_info.importance = ucb_setting.importance();
    }

    // appnames_priority
    if (ucb_setting.appnames_priority_size() > 0) {
      ext_info.appname_priority = ucb_setting.appnames_priority(0);
    }

    // banner
    if (ucb_setting.has_is_banner() && ucb_setting.is_banner()) {
      ext_info.is_banner = true;
      ext_info.is_news_banner = IsNewsBanner(ext_info.style_type);
      ext_info.is_entrance_banner = IsEntranceBanner(ext_info.style_type);
      ext_info.is_daoliu_banner = IsDaoliuBanner(ext_info.style_type);
      if (ucb_setting.has_banner_type() && ucb_setting.banner_type() == 1) {
        ext_info.is_rotation_banner = true;
      }
    }

    // 规则过滤
    if (ext_info.is_banner) {  // 置顶文章规则过滤
      if (!reco_request_->is_update_req   // 只在更新出
          || !ext_info.hit_channel   // 只在命中的频道出
          || !ext_info.deliver_tags.empty()   // 只全量下发
          || IsFilteredByBannerTimes(item.item_id, ucb_setting)  // 置顶次数过滤
          || NewsFilter::IsDislikeBannerFiltered(reco_request_->user_feas, item)) {  // 置顶不喜欢过滤
        ext_info.SetIsFiltered(true, reco::filter::kBannerItemFiltered);
        VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(reco::filter::kBannerItemFiltered)
                << " : " << item.item_id;
        continue;
      }
    } else {
      // 非置顶需要经过 GeneralFilter 过滤
      reco::filter::FilterReason filter_reason;
      if (NewsFilter::IsGeneralFiltered(reco_request_, reco_request_->shown_dict,
                                        item, &filter_reason, true)) {
        ext_info.SetIsFiltered(true, filter_reason);
        VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(filter_reason) << " : " << item.item_id;
        continue;
      }
      // dislike 的过滤
      if (channel_id != reco::common::kLeftChannelId
          && NewsFilter::IsDislikeFiltered(reco_request_, item)) {
        ext_info.SetIsFiltered(true, reco::filter::kFilterByDislike);
        VLOG(2) << "filtered by " << reco::filter::FilterReason_Name(reco::filter::kFilterByDislike)
                << " : " << item.item_id;
        continue;
      }
      // 专题的特殊规则
      ext_info.is_special = IsSpecialItem(item);
      if (ext_info.is_special) {
        // 专题样式只要全量发布
        if (ext_info.oper_area != reco::kWholeDeliver)  {
          ext_info.SetIsFiltered(true, reco::filter::kSpecialNotWholeDeliverFiltered);
          VLOG(2) << "filtered by "
                  << reco::filter::FilterReason_Name(reco::filter::kSpecialNotWholeDeliverFiltered)
                  << " : " << item.item_id;
          continue;
        }
        // 专题只在命中频道出
        if (item.item_type == reco::kSpecial && !ext_info.hit_channel)  {
          ext_info.SetIsFiltered(true, reco::filter::kSpecialNotHitChannelFiltered);
          VLOG(2) << "filtered by " <<
              reco::filter::FilterReason_Name(reco::filter::kSpecialNotHitChannelFiltered)
                  << " : " << item.item_id;
          continue;
        }
      }
    }
    if (!IsProbeCandidate(item, &ext_info.probe_card)) {
      ext_info.probe_card.clear();
    }
    // 排序信息
    auto sort_iter = iflow_item_sort_map->find(item.item_id);
    if (sort_iter != iflow_item_sort_map->end()) {
      ext_info.sort_score = sort_iter->second;
      // 小渠道优先于全渠道
      // 注意: uc-iflow 渠道特殊, uc-iflow 与全渠道下发的新闻，appname_priority 字段都为空，
      // 这样实现是为了实现 uc-iflow 渠道上与全渠道同等级别调整排序
      if (ext_info.appname_priority != "") {
        ext_info.sort_score += std::numeric_limits<unsigned>::max() / 100;
      } else if (ucb_setting.appnames_size() > 0) {
        ext_info.sort_score += std::numeric_limits<unsigned>::max() / 150;
      }
      if (ext_info.importance == 1) {
        // 确保一级要闻的 sort score 大于二级要闻，避免被过滤
        ext_info.sort_score += std::numeric_limits<unsigned>::max() / 50;
      }
    }
    if (!ext_info.is_filtered) ++remain_item_num;
  }
}

void ManualReco::ExtractManualWholeItems(
    int64 channel_id,
    const std::vector<ItemInfo>& candidate_items,
    const std::vector<ManualItemExtInfo>& item_ext_vec,
    ManualRecoData* manual_reco_data,
    RecoDebugger* debugger) const {

  std::vector<ItemInfo>* top_importance_items = &manual_reco_data->top_importance_items;
  std::vector<ItemInfo>* snd_importance_items = &manual_reco_data->snd_importance_items;
  auto probe_manual_items = &manual_reco_data->probe_manual_items;

  // 获取全量下发的文章
  std::vector<std::pair<int, int> > sort_items;
  for (int i = 0; i < (int)candidate_items.size(); ++i) {
    const ManualItemExtInfo& ext_info = item_ext_vec.at(i);
    if (ext_info.get_is_filtered()) {
      VLOG(2) << "manual candidate filtered: " << candidate_items[i].item_id;
      continue;
    }
    if (!ext_info.hit_channel) {
      VLOG(2) << "manual candidate not hit channel: " << candidate_items[i].item_id;
      continue;
    }
    if (ext_info.oper_area != reco::kWholeDeliver || !ext_info.deliver_tags.empty()) {
      VLOG(2) << "manual candidate not whole deliver: " << candidate_items[i].item_id;
      continue;
    }
    unsigned level = 0;
    if (ext_info.is_banner) {
      int sort_score = ext_info.sort_score > 0 ? ext_info.sort_score : 0;
      if (RecoUtils::IsSpecialBannerChannel(channel_id)) {
        // 特殊频道不管置顶类型，完全按照后台排序
        level = std::numeric_limits<unsigned>::max() / 2 + sort_score;
      } else if (ext_info.is_daoliu_banner) {
        level = std::numeric_limits<unsigned>::max() / 2 + sort_score;
      } else if (ext_info.is_entrance_banner) {
        // level = std::numeric_limits<unsigned>::max() - 100;
        level = std::numeric_limits<unsigned>::max() / 4 + sort_score;
      } else if (ext_info.is_news_banner) {
        // level = std::numeric_limits<unsigned>::max() - 200;
        level = std::numeric_limits<unsigned>::max() / 5 + sort_score;
      } else {
        level = std::numeric_limits<unsigned>::max() / 5 + sort_score;
      }
    } else {
      if (!FLAGS_manual_reco_test_env && ext_info.sort_score < 0) {
        VLOG(2) << "manual candidate not found sort score: " << candidate_items[i].item_id;
        continue;
      }
      level = ext_info.sort_score;
    }
    sort_items.push_back(std::make_pair(level, i));
    VLOG(2) << "manual candidate: " << candidate_items[i].item_id;
  }

  std::sort(sort_items.begin(), sort_items.end(), std::greater<std::pair<unsigned, int> >());

  // 填充结果集合
  bool has_entrance_banner = false;
  bool has_news_banner = false;
  bool has_daoliu_banner = false;
  int32 rotation_insert_index = -1;
  std::vector<ItemInfo> rotation_banners;
  bool has_special = false;
  for (int i = 0; i < (int)sort_items.size(); ++i) {
    const int idx = sort_items[i].second;
    const ItemInfo& tmp_item = candidate_items.at(idx);
    const ManualItemExtInfo& ext_info = item_ext_vec.at(idx);
    const unsigned level_score = sort_items[i].first;
    if (!RecoUtils::IsSpecialBannerChannel(channel_id)) {
      // 各种 banner 只保留一条
      if (ext_info.is_news_banner && has_news_banner) {
        debugger->SetItemFilterReason(tmp_item.item_id, reco::filter::kStrategyAlreadyHasNewsBanner);
        continue;
      }
      if (ext_info.is_entrance_banner && has_entrance_banner) {
        debugger->SetItemFilterReason(tmp_item.item_id, reco::filter::kStrategyAlreadyHasEntranceBanner);
        continue;
      }
      if (ext_info.is_daoliu_banner && has_daoliu_banner) {
        debugger->SetItemFilterReason(tmp_item.item_id, reco::filter::kStrategyAlreadyHasDaoliuBanner);
        continue;
      }
    }
    // 专题只保留一条
    if (!RecoUtils::IsSpecialOperChannel(channel_id) && ext_info.is_special && has_special) {
      debugger->SetItemFilterReason(tmp_item.item_id, reco::filter::kStrategyAlreadyHasSpecial);
      continue;
    }
    debugger->TraceManulItemDictAndLevelScore(tmp_item, ext_info, level_score);

    // 非 banner 的专题
    if (!ext_info.is_banner && ext_info.is_special) has_special = true;
    if (ext_info.is_news_banner) has_news_banner = true;
    if (ext_info.is_entrance_banner) has_entrance_banner = true;
    if (ext_info.is_daoliu_banner) has_daoliu_banner = true;
    // 放入结果集合
    // 设置 strategy_type
    // 填充要闻队列, 一级要闻与 banner 填充到一级要闻队列
    if (ext_info.is_banner || ext_info.importance == 1
        || tmp_item.item_id == FLAGS_assemble_card_test_item_id) {
      // 轮播置顶，插入一个进行占位
      if (ext_info.is_rotation_banner) {
        rotation_banners.push_back(tmp_item);
        if (rotation_insert_index >= 0) {
          continue;
        } else {
          rotation_insert_index = top_importance_items->size();
        }
      }
      top_importance_items->push_back(tmp_item);
      ItemInfo& item = top_importance_items->back();
      if (ext_info.is_banner) {
        item.strategy_type = reco::kBanner;
      } else {
        item.strategy_type = reco::kManual;
      }
      item.strategy_branch = reco::kManualBranch;
    } else if (!ext_info.probe_card.empty()) {
      // 探索卡片交给探索分支去优化
      probe_manual_items->push_back(std::make_pair(ext_info.probe_card, tmp_item));
      ItemInfo& item = probe_manual_items->back().second;
      item.strategy_type = reco::kManual;
      item.strategy_branch = reco::kManualBranch;
    } else {
      snd_importance_items->push_back(tmp_item);
      ItemInfo& item = snd_importance_items->back();
      item.strategy_type = reco::kManual;
      item.strategy_branch = reco::kManualBranch;
    }
    VLOG(2) << "get manual whole deliver item: " << tmp_item.item_id;
  }
  if (rotation_banners.size() > 1u
      && rotation_insert_index < (int)top_importance_items->size()) {  // 存在多个轮播置顶
    std::string key = base::StringPrintf("RB-%lu-%ld", reco_request_->user_info->identity().user_id(),
                                         channel_id);
    std::string value;
    int32 req_num = 0;
    if (LeafCache::GetCachedReco(key, &value)) {
      if (base::StringToInt(value, &req_num) && req_num >= 0) {
        req_num = req_num % rotation_banners.size();
      } else {
        req_num = 0;
      }
    }
    std::swap(rotation_banners[req_num], (*top_importance_items)[rotation_insert_index]);
    (*top_importance_items)[rotation_insert_index].strategy_type = reco::kBanner;
    LeafCache::SetCachedReco(key, base::IntToString(req_num + 1));
    LOG(INFO) << key << " rotation_banner num: " << rotation_banners.size()
              << ", choose: " << req_num;
  }
  VLOG(1) << "off_check_top_importance_size:" << top_importance_items->size();
  VLOG(1) << "off_check_snd_importance_size:" << snd_importance_items->size();
}

void ManualReco::ExtractManualCategoryWholeItems(
    int64 channel_id,
    const std::vector<ItemInfo>& candidate_items,
    const std::vector<ManualItemExtInfo>& item_ext_vec,
    ManualRecoData* manual_reco_data) const {

  auto category_items = &manual_reco_data->category_whole_items;
  auto probe_manual_items = &manual_reco_data->probe_manual_items;
  // category_items->clear();
  // 非推荐频道不需要该结果集合
  if (channel_id != reco::common::kRecoChannelId) return;

  // 获取类别内全量下发的文章
  unsigned level = 0;
  std::unordered_map<std::string, std::vector<std::pair<int, int> > > sort_items_map;
  std::unordered_set<std::string> deliver_categories;
  for (int i = 0; i < (int)candidate_items.size(); ++i) {
    const ItemInfo& item = candidate_items.at(i);
    const ManualItemExtInfo& ext_info = item_ext_vec.at(i);
    if (ext_info.get_is_filtered()) continue;
    if (ext_info.sort_score < 0) continue;

    deliver_categories.clear();
    if (ext_info.hit_channel) {
      // 推荐频道指定维度的全量下发
      if (ext_info.oper_area != reco::kWholeDeliver) continue;
      if (ext_info.deliver_tags.empty()) continue;
      deliver_categories.insert(item.category);
      for (auto iter = ext_info.deliver_tags.begin(); iter != ext_info.deliver_tags.end(); ++iter) {
        deliver_categories.insert(*iter);
      }

      // 命中频道的加权
      level = ext_info.sort_score + std::numeric_limits<unsigned>::max() / 1000;
      // 专题样式的加权
      if (ext_info.is_special) {
        level += std::numeric_limits<unsigned>::max() / 500;
      }
    } else {
      // 垂直频道运营新闻抽取规则原来只要非专题的卡片
      // 目前调整为都不抽取
      // 原来的代码逻辑暂留
      // NOTE(jianhuang) 不抽取垂直频道的运营文章到推荐频道
      // // 不要 banner
      // if (ext_info.is_banner) continue;
      // // 垂直频道不指定维度的文章
      // if (ext_info.oper_area != reco::kWholeDeliver || !ext_info.deliver_tags.empty()) continue;
      // // 只要非专题的卡片
      // if (!ext_info.is_special || item.item_type == reco::kSpecial) continue;
      // // 加入结果集合
      // deliver_categories.insert(item.category);
      // level = ext_info.sort_score;
      // // 专题样式得加权
      // if (ext_info.is_special) {
      //   level += std::numeric_limits<unsigned>::max() / 500;
      // }
    }
    for (auto iter = deliver_categories.begin(); iter != deliver_categories.end(); ++iter) {
      const std::string& category = *iter;
      auto sort_iter = sort_items_map.find(category);
      if (sort_iter == sort_items_map.end()) {
        sort_iter =
            sort_items_map.insert(std::make_pair(category, std::vector<std::pair<int, int> >())).first;
      }
      sort_iter->second.push_back(std::make_pair(level, i));
    }
  }

  // 分类别填充结果集
  bool do_special_limit = !reco::common::IsAudioChannel(channel_id);
  for (auto sort_iter = sort_items_map.begin(); sort_iter != sort_items_map.end(); ++sort_iter) {
    const std::string& category = sort_iter->first;
    std::vector<std::pair<int, int> >& sort_items = sort_iter->second;
    if (sort_items.empty()) continue;
    std::sort(sort_items.begin(), sort_items.end(), std::greater<std::pair<unsigned, int> >());

    auto ret_iter = category_items->insert(std::make_pair(category, std::vector<ItemInfo>())).first;
    std::vector<ItemInfo>& ret_items = ret_iter->second;
    bool has_special = false;
    for (int i = 0; i < (int)sort_items.size(); ++i) {
      int idx = sort_items[i].second;
      const ItemInfo& tmp_item = candidate_items.at(idx);
      const ManualItemExtInfo& ext_info = item_ext_vec.at(idx);
      // 只保留一条专题
      if (do_special_limit && ext_info.is_special && has_special) continue;
      if (!ext_info.probe_card.empty()) {
        // 探索卡片交给探索分支去优化
        probe_manual_items->push_back(std::make_pair(ext_info.probe_card, tmp_item));
        ItemInfo& item = probe_manual_items->back().second;
        item.strategy_type = reco::kManual;
        item.strategy_branch = reco::kManualBranch;
      } else {
        ret_items.push_back(tmp_item);
        if (ext_info.is_special) has_special = true;
        ItemInfo& item = ret_items.back();
        // 类别替换
        if (item.category != category) {
          item.category = category;
          item.sub_category.clear();
        }
        item.strategy_type = reco::kManual;
        item.strategy_branch = reco::kManualBranch;
      }
    }
  }
  VLOG(1) << "off_check_category_items_size:" << category_items->size();
}

void ManualReco::ExtractManualPersonalItems(
    int64 channel_id,
    const std::vector<ItemInfo>& candidate_items,
    const std::vector<ManualItemExtInfo>& item_ext_vec,
    ManualRecoData* manual_reco_data) const {

  std::vector<ItemInfo>* ret_items = &manual_reco_data->personal_items;
  ret_items->clear();

  // 获取类别内全量下发的文章
  for (int i = 0; i < (int)candidate_items.size(); ++i) {
    const ItemInfo& item = candidate_items.at(i);
    const ManualItemExtInfo& ext_info = item_ext_vec.at(i);
    if (ext_info.get_is_filtered()) continue;
    // 专题和置顶不要
    if (ext_info.is_banner) continue;
    if (ext_info.is_special) continue;
    // 频道互相抽取
    if (ext_info.hit_channel) {
      // 命中频道，可以抽取 
    } else if (channel_id == reco::common::kRecoChannelId) {
      // 推荐频道，对于其他频道只抽取以下几种 item_type 的文章
      if (item.item_type != reco::kNews
          && item.item_type != reco::kReading
          && item.item_type != reco::kPureVideo
          && item.item_type != reco::kPictureNews) continue;
    } else {
      // 垂直频道，不抽取其他频道的文章
      continue;
    }
    // 加入结果集合
    ret_items->push_back(item);
    ItemInfo& ret_item = ret_items->back();
    ret_item.strategy_type = reco::kManual;
  }
  VLOG(1) << "off_check_personal_items_size:" << ret_items->size();
}

void ManualReco::ExtractCardAssembleCandidates(const RecoRequest* reco_request,
                                               const std::vector<ItemInfo>& candidate_items,
                                               const std::vector<ManualItemExtInfo>& item_ext_vec,
                                               ManualRecoData* manual_reco_data) {
  // 推荐频道早晚头条卡片自动组装
  if (reco_request->channel_id != reco::common::kRecoChannelId) return;

  // 1. 是否有需要组装的卡片及一级要闻
  AutoAssembleCard* auto_card = &(manual_reco_data->morning_evening_auto_card);
  auto_card->Clear();
  VLOG(1) << "for card, top_importance_item size: " << manual_reco_data->top_importance_items.size();
  for (size_t i = 0; i < manual_reco_data->top_importance_items.size(); ++i) {
    const ItemInfo& item_info = manual_reco_data->top_importance_items[i];
    VLOG(1) << "top_importance_item detail: " << item_info.item_id;
    if (RecoUtils::IsAutoAssembleCardItem(news_index_, item_info)) {
      if (!auto_card->is_valid()) {
        auto_card->SetCardId(item_info.item_id);
        VLOG(1) << "card auto itemid: " << item_info.item_id;
      }
    } else {
      if (CardCandidateFilter(item_info)) continue;
      if (auto_card->is_valid()) {
        if (IsAssembleBigPicStyle(item_info)) {
          // 大图一级要闻
          auto_card->AddCandidate(item_info, TOP_IMPORTANCE_BIG_STYLE);
        } else if (auto_card->HasBigStyleCandidateItem()) {
          // 大图子文之下的一级候选要闻
          auto_card->AddCandidate(item_info, TOP_IMPORTANCE_NORMAL);
        }
      }
    }
  }
  // 2. 校验是否有大图一级要闻，否则无法组成卡片
  if (!auto_card->is_valid()) {
    VLOG(1) << "card has NOT auto build card";
    return;
  }
  if (!auto_card->HasBigStyleCandidateItem()) {
    VLOG(1) << "card not has importance1 item, CANNOT build card";
    return;
  }

  // 3. 获取用户 top3 兴趣类别
  TopN<std::string> top_prefer_categories(3);
  for (size_t i = 0; i < reco_request->category_distributes->size(); ++i) {
    const auto& weight_cate = (*reco_request->category_distributes)[i];
    top_prefer_categories.add(weight_cate.second.category(), weight_cate.first);
    VLOG(1) << "card intrest category: " << weight_cate.second.category() << " " << weight_cate.first;
  }
  std::vector<std::string> category_vec;
  top_prefer_categories.get_top_n(&category_vec);
  VLOG(1) << "card interest category: " << base::JoinStrings(category_vec, ",");

  // 4. top3 兴趣类别里的二级要闻
  VLOG(1) << "for card, snd_importance_item size: " << manual_reco_data->snd_importance_items.size();
  for (size_t i = 0; i < manual_reco_data->snd_importance_items.size(); ++i) {
    const ItemInfo& item_info = manual_reco_data->snd_importance_items[i];
    if (CardCandidateFilter(item_info)) continue;
    if (std::find(category_vec.begin(), category_vec.end(), item_info.category) != category_vec.end()) {
      auto_card->AddCandidate(item_info, SND_CATE_IMPORTANCE);
    } else if (IsRegionDeliverItem(item_info)) {
      auto_card->AddCandidate(item_info, SND_REGION);
    }
  }
  VLOG(1) << "for card, manual candidate size, after whole deliver: " << auto_card->candidates().size();
  for (size_t i = 0; i < category_vec.size(); ++i) {
    auto iter = manual_reco_data->category_whole_items.find(category_vec[i]);
    if (iter != manual_reco_data->category_whole_items.end()) {
      for (size_t j = 0; j < iter->second.size(); ++j) {
        if (CardCandidateFilter(iter->second[j])) continue;
        auto_card->AddCandidate(iter->second[j], CATEGORY_WHOLE);
      }
    }
  }
  VLOG(1) << "for card, manual candidate size: after cate whole deliver: " << auto_card->candidates().size();

  // 5. 抽取其他频道下全量下，用户 top3 兴趣类别里的全量下发文章
  for (size_t i = 0; i < candidate_items.size(); ++i) {
    const ItemInfo& item = candidate_items.at(i);
    const ManualItemExtInfo& ext_info = item_ext_vec.at(i);
    if (ext_info.get_is_filtered()) continue;
    if (ext_info.hit_channel) continue;
    if (ext_info.is_banner) continue;
    if (ext_info.is_special) continue;
    if (ext_info.oper_area != reco::kWholeDeliver) continue;
    if (CardCandidateFilter(item)) continue;
    if (std::find(category_vec.begin(), category_vec.end(), item.category) == category_vec.end()) continue;
    auto_card->AddCandidate(item, OTHER_VERTICAL_CHANNEL);
    VLOG(1) << "card add candidate: " << item.item_id << " " << "other vertical channel";
  }

  // 6. sort candidates of auto card's candidate item
  auto_card->SortCandidates();
}

void ManualReco::ExtractEventCardCandidates(const RecoRequest* reco_request,
                                            ManualRecoData* manual_reco_data) {
  AutoEventCard* event_card = &(manual_reco_data->auto_event_card);
  event_card->Clear();
  // 1. 找到事件专题卡片
  for (size_t i = 0; i < manual_reco_data->top_importance_items.size(); ++i) {
    const ItemInfo& item_info = manual_reco_data->top_importance_items[i];
    if (RecoUtils::IsAutoEventCardItem(news_index_, item_info)) {
      event_card->SetItemId(news_index_, item_info.item_id);
      break;
    }
  }
  if (!event_card->is_valid()) {
    for (size_t i = 0; i < manual_reco_data->snd_importance_items.size(); ++i) {
      const ItemInfo& item_info = manual_reco_data->snd_importance_items[i];
      if (RecoUtils::IsAutoEventCardItem(news_index_, item_info)) {
        event_card->SetItemId(news_index_, item_info.item_id);
        break;
      }
    }
  }
  // 2. 抽取事件专题卡片的子文
  if (!event_card->is_valid()) return;
  event_card->ExtractCandidates(news_index_, reco_request);
}

bool ManualReco::CardCandidateFilter(const ItemInfo& item) {
  // item_type 过滤
  if (item.item_type != reco::kNews
      && item.item_type != reco::kReading
      && item.item_type != reco::kPicture
      && item.item_type != reco::kPureVideo
      && item.item_type != reco::kPictureNews) return true;
  // 子文样式过滤
  if (!IsAssembleSubItemStyleType(item)) return true;
  // 发布时间大于 24 小时的过滤
  base::Time time_thres = current_time_
      - base::TimeDelta::FromHours(FLAGS_auto_card_time_threshold_in_hour);
  int64 thres_timestamp = time_thres.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  if (item.create_timestamp < thres_timestamp) return true;
  // 时效性分类过滤
  if (auto_card_candidate_cates_.find(item.category) == auto_card_candidate_cates_.end()) return true;
  const auto ucb_setting_dict = news_index_->GetUcbSettingDict();
  const auto ucb_iter = ucb_setting_dict->find(item.item_id);
  if (ucb_iter == ucb_setting_dict->end()) return true;
  const reco::UcBrowserDeliverSetting& ucb_setting = ucb_iter->second;
  // 过滤运营中的软文广告、敏感文章
  if (ucb_setting.oper_item_type() != 0) return true;
  // 非喜刷刷渠道只选全渠道的文章作为备选
  if (reco_request_->request->app_token() != reco::common::kUCBIflowUser
      && ucb_setting.appnames_size() > 0) return true;
  return false;
}

}  // namespace leafserver
}  // namespace reco

