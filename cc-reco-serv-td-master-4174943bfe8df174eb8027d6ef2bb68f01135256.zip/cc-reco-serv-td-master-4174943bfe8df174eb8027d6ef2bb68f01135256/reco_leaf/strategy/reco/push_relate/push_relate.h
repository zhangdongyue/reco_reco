#pragma once

#include <vector>

#include "reco/serv/reco_leaf/strategy/reco/session/w2v_item_reco.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"

namespace reco {
class NewsIndex;

namespace leafserver {
class RecoRequest;

class PushRelateReco {
 public:
  explicit PushRelateReco(const reco::NewsIndex* index);
  
  ~PushRelateReco();

  void DoPushRelateReco(const RecoRequest* request, std::vector<ItemInfo>* reco_items);

 private:
  const NewsIndex* news_index_;
  W2VItemReco* w2v_item_reco_;
  CandidatesExtractor* candidates_extor_;
};
}
}
