#include "reco/serv/reco_leaf/strategy/reco/push_relate/push_relate.h"
#include "serving_base/utility/timer.h"

namespace reco {
class NewsIndex;

namespace leafserver {

PushRelateReco::PushRelateReco(const reco::NewsIndex* index) {
  news_index_ = index;
  w2v_item_reco_ = new W2VItemReco(news_index_);
  candidates_extor_ = new CandidatesExtractor(news_index_);
}

PushRelateReco::~PushRelateReco() {
  if (w2v_item_reco_) {
    delete w2v_item_reco_;
    w2v_item_reco_ = NULL;
  }

  if (candidates_extor_) {
    delete candidates_extor_;
    candidates_extor_ = NULL;
  }
}

void PushRelateReco::DoPushRelateReco(const RecoRequest* request, std::vector<ItemInfo>* ret_items) {
  if (!request->request->has_pushed_item()) {
    VLOG(1) << "no pushed item";
    return;
  }

  int num_req = 0;
  const UserFeature *user_feas = request->user_feas;
  double num_click = user_feas->lt_fea.click_num + user_feas->st_fea.st_click_num;

  // w2v strategy
  if (num_click <= 5) {
    num_req = 2;
  } else {
    num_req = 1;
  }

  const uint64 pushed_item_id = request->request->pushed_item();
  reco::RelateItemRecoResult rel_items;
  if (!w2v_item_reco_->GetRelateItems(pushed_item_id, &rel_items)) {
    VLOG(1) << "GetRelateItems null, " << pushed_item_id;
    return;
  }

  int64 start_time = base::GetTimestamp();
  if (start_time - rel_items.last_update_timestamp() * base::Time::kMicrosecondsPerSecond >= 6 * base::Time::kMicrosecondsPerHour) {
    VLOG(1) << "last_update too late, " << pushed_item_id;
    return;
  }

  std::vector<std::pair<double, uint64>> w2v_scores;
  for (int i = 0; i < rel_items.relate_item_size(); ++i) {
    uint64 rel_item_id = rel_items.relate_item(i).item_id();
    double score = rel_items.relate_item(i).score();
    if (score < 0.6) {
      VLOG(1) << "pushed item is: " << pushed_item_id << ", skip " << rel_item_id << ", score " << score;
      continue;
    }
    w2v_scores.push_back(std::make_pair(score, rel_item_id));
    VLOG(1) << "add item " << rel_item_id << " to result";
  }

  if (w2v_scores.empty()) {
    VLOG(1) << "empty result";
    return;
  }

  std::sort(w2v_scores.begin(), w2v_scores.end(), std::greater<std::pair<double, uint64> >());
  std::vector<std::pair<double, ItemInfo> > score_items;
  const size_t kMaxResult = 200;
  for (size_t i = 0; i < w2v_scores.size() && i < kMaxResult; ++i) {
    ItemInfo item;
    if (!news_index_->GetItemInfoByItemId(w2v_scores[i].second, &item, false)) {
      VLOG(1) << "invalid item " << w2v_scores[i].second;
      continue;
    }

    if (news_index_->IsManualByDocId(item.doc_id)) {
      VLOG(1) << "item is manual " << w2v_scores[i].second;
      continue;
    }

    if (item.item_type != reco::kNews &&
        item.item_type != reco::kReading &&
        item.item_type != reco::kPicture &&
        item.item_type != reco::kPictureNews) {
      VLOG(1) << "invalid item type " << w2v_scores[i].second<< ", " << item.item_type;
      continue;
    }

    if ((item.time_level == reco::kBadTimeliness) || item.ctr < 0.1 || item.show_num < 50000) {
      VLOG(1) << "filtered item " << w2v_scores[i].second<< ", " << item.time_level << ", " << item.ctr << ", " << item.show_num;
      continue;
    }
    /*
    if (!NewsFilter::ItemIsValid(item, request->current_timestamp)) {
      VLOG(1) << "invalid item by ItemIsValid" << w2v_scores[i].second;
      continue;
    }

    reco::filter::FilterReason filter_reason;
    if (NewsFilter::IsGeneralFiltered(request, request->shown_dict, item, &filter_reason, false)) {
      VLOG(1) << "general filtered item " << w2v_scores[i].second << " reason is " << filter_reason;
      continue;
    }
    */

    double score = w2v_scores[i].first;
    if (item.time_level == reco::kMidTimeliness) {
      score *= 0.7;
    }
    int itemq = item.itemq <= 0 ? 0: std::max(-2, std::min(item.itemq - 3, 4));
    score *= item.ctr * std::pow(1.2, itemq);
    score_items.push_back(std::make_pair(score, item));
  }

  std::sort(score_items.begin(), score_items.end(), std::greater<std::pair<double, ItemInfo> >());

  // int num_return = std::min((int)score_items.size(), num_req);

  std::vector<ItemInfo> candidates;
  for (auto i = 0u; i < score_items.size(); ++i) {
    ItemInfo& item = score_items[i].second;
    item.strategy_type = reco::kPushRelate;
    item.strategy_branch = reco::kPushRelateBranch;
    item.reco_ext_info = base::Uint64ToString(pushed_item_id);
    candidates.push_back(item);
  }
 
  // filter
  candidates_extor_->BasicRuleFilter(request, kCandidateSession, candidates, ret_items);

  if (static_cast<int>(ret_items->size()) > num_req) {
    ret_items->resize(num_req);
  }

  for (auto i = 0u; i < ret_items->size(); ++i) {
    VLOG(1) << "final add item " << ret_items->at(i).item_id << " pushed_item_id is " << pushed_item_id;
  }

  LOG(INFO) << "user:" << request->user_info->identity().user_id()
            << ", profile weight: " << num_click
            << ", req num:" << num_req
            << ", rec items:" << ret_items->size();
}
}
}
