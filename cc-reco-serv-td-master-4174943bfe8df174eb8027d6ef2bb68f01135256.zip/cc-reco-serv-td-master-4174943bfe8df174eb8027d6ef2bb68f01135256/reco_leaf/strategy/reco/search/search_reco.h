#pragma once

#include <vector>
#include <unordered_set>
#include <string>

#include "base/container/dense_hash_set.h"
#include "base/thread/blocking_queue.h"
#include "base/math/discrete.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"

namespace reco {
class NewsIndex;
namespace leafserver {
class RecoResultCache;
class TagSearcher;

class SearchReco {
 public:
  explicit SearchReco(const reco::NewsIndex* news_index);
  ~SearchReco();

  // 我的频道, 标签主页
  bool RecoInSubscriptChannel(const RecoRequest* reco_request,
                              std::vector<ItemInfo>* reco_items,
                              std::vector<std::string>* hit_tags);

 private:
  // 订阅搜索特殊的缓存处理
  void GetCachedItems(int req_num,
                      std::vector<ItemInfo>* cached_items,
                      std::vector<std::string>* hit_tags);

  // 分析展现历史，决定下面要计算的标签及权重
  bool ParseSubcriptTagWeight(const base::dense_hash_map<std::string, float>& subscript_words,
                              std::vector<std::pair<std::string, double>>* sorted_tags);

  void DoSearch(const std::vector<std::string>& tags, int result_num,
              std::unordered_map<std::string, std::vector<ItemInfo>>* result_map);

  void DoSearchInternal(int thread_no, thread::BlockingQueue<std::string>* tag_queue,
                        std::unordered_map<std::string, std::vector<ItemInfo>>* result_map);

 private:
  static const int kIncrCalcNum = 60;   // 增量计算多少条 
  static const int kUniqTagNumPerCalc = 10;  // 每次计算多少个 uniq tag
  static const int kMaxConCurrentNum = 6;

  // 以下都是从外部传入
  const NewsIndex* news_index_;
  const RecoRequest* reco_request_;
  const reco::leafserver::RecommendRequest* request_;
  const reco::user::UserInfo* user_info_;
  const UserFeature* user_feas_;
  const base::dense_hash_set<uint64>* shown_dict_;

  RecoResultCache* reco_cache_;
  std::vector<TagSearcher*> tag_searchers_;
  BaseSearcher::Config search_config_;
};

}  // namespace leafserver
}  // namespace reco
