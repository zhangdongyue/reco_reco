#include "reco/serv/reco_leaf/strategy/reco/search/search_reco.h"

#include <string>
#include <algorithm>
#include <unordered_map>
#include <functional>
#include "reco/serv/reco_leaf/strategy/search/tag_searcher.h"
#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/strategy/component/cache/reco_result_cache.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "serving_base/data_manager/data_manager.h"
#include "reco/bizc/reco_index/news_index.h"

#include "reco/base/common/topn_heap.h"
#include "reco/base/common/topn_priority_queue.h"
#include "serving_base/utility/timer.h"
#include "nlp/common/nlp_util.h"
#include "base/time/time.h"

namespace reco {
namespace leafserver {

SearchReco::SearchReco(const reco::NewsIndex* news_index) : search_config_("SearchReco") {
  news_index_ = news_index;
  reco_cache_ = new RecoResultCache(news_index);
  for (int i = 0; i < kMaxConCurrentNum; ++i) {
    tag_searchers_.push_back(new TagSearcher(news_index_));
  }

  search_config_.return_num = 40;
  search_config_.ir_num = 1000;
  search_config_.fr_num = 100;
  search_config_.rel_low_threshold = 0;
  search_config_.rel_high_threshold = 0;
  search_config_.ctr_low_threshold = 0;
  search_config_.ctr_high_threshold = 0;
  search_config_.show_threshold = 0;
  search_config_.title_rel_coef = 0.9f;
  search_config_.keyword_rel_coef = 0.1f;
  search_config_.timelevel_threshold = reco::kBadTimeliness;
  search_config_.use_cache = true;
  search_config_.title_all_hit = false;
  search_config_.filter_region = true;
  search_config_.filter_manual = false;
  search_config_.white_item_type_dict.insert(reco::kNews);
  search_config_.white_item_type_dict.insert(reco::kReading);
  search_config_.white_item_type_dict.insert(reco::kPicture);
  search_config_.white_item_type_dict.insert(reco::kPictureNews);
  search_config_.white_item_type_dict.insert(reco::kPureVideo);
}

SearchReco::~SearchReco() {
  delete reco_cache_;
  for (size_t i = 0; i < tag_searchers_.size(); ++i) {
    delete tag_searchers_[i];
  }
}

bool SearchReco::ParseSubcriptTagWeight(const base::dense_hash_map<std::string, float>& subscript_words,
                                        std::vector<std::pair<std::string, double>>* sorted_tags) {
  static const int64 kSessionTime = 6 * base::Time::kMicrosecondsPerHour;

  // 根据订阅时间，决定订阅词的权重
  // TODO(xxx): 根据用户画像里每个词的权重，再调整下
  int64 now_timestamp = base::GetTimestamp();

  // 根据展现记录，计算每个标签词的出现比例
  uint64 deadline = now_timestamp - kSessionTime;
  std::unordered_map<std::string, int> tag_show_cnt;
  int show_in_session = 0;
  for (int i = user_info_->shown_history_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& view_item = user_info_->shown_history(i);
    uint64 view_timestamp = view_item.has_view_timestamp() ? view_item.view_timestamp() : now_timestamp;
    if (!view_item.has_channel_id()
        || view_item.channel_id() != reco::common::kSubscriptionChannelId) {
      continue;
    }
    if (view_timestamp < deadline) {
      // 根据展现时间有序，可以 break
      break;
    }
    if (!view_item.has_hit_tag() || view_item.hit_tag().empty()) {
      VLOG(1) << "show item do not has hit tag";
      continue;
    }

    ++show_in_session;
    tag_show_cnt[nlp::util::NormalizeLine(view_item.hit_tag())] += 1;
  }

  // 决定要出哪些 tag 各出多少条
  // 思路：算上session time里已经展现的和这次要计算的，作为总quota，总quota按照权重进行分配，
  // 按照缺失程度决定计算哪些tag的
  int total_num = show_in_session + kIncrCalcNum;
  TopNPriorityQueue<std::string> tag_topn(kUniqTagNumPerCalc);
  float sum_weight = 0;
  for (auto it = subscript_words.begin(); it != subscript_words.end(); ++it) {
    sum_weight += it->second;
  }
  if (sum_weight < 1e-5) sum_weight = 1;
  for (auto it = subscript_words.begin(); it != subscript_words.end(); ++it) {
    const std::string& tag = it->first;
    int quota = total_num * it->second / sum_weight;
    auto jt = tag_show_cnt.find(tag);
    int show = (jt == tag_show_cnt.end()) ? 0 : jt->second;
    double weight = std::max(1, quota - show);
    tag_topn.add(tag, weight);
    VLOG(1) << tag
        << ", subscript weight: " << it->second / sum_weight
        << ", quota show excluded: " << quota
        << ", show cnt: " << show
        << ", weight show included: " << weight;
  }

  sorted_tags->clear();
  tag_topn.get_top_n_ordered(sorted_tags);

  // 最后再归一化一下， 分摊这些quota
  float total_weight = 0;
  for (auto it = sorted_tags->begin(); it != sorted_tags->end(); ++it) {
    total_weight += it->second;
  }
  if (total_weight < 1e-5) {
    total_weight = 1;
  }
  for (auto it = sorted_tags->begin(); it != sorted_tags->end(); ++it) {
    it->second /= total_weight;
  }

  return true;
}

void SearchReco::GetCachedItems(int req_num,
                                std::vector<ItemInfo>* cached_items,
                                std::vector<std::string>* hit_tags) {
  int64 now_time = base::GetTimestamp();

  cached_items->clear();
  hit_tags->clear();

  CachedNewsRecoData reco_data;
  reco_cache_->GetCachedItems(reco_request_, &reco_data);
  ItemInfo item;
  for (int i = 0; i < reco_data.item_misc_size(); ++i) {
    if ((int)cached_items->size() >= req_num) {
      break;
    }
    const CachedItemMisc& item_misc = reco_data.item_misc(i);
    reco::filter::FilterReason filter_reason;
    if (!news_index_->GetItemInfoByItemId(item_misc.item_id(), &item, false)
        || !NewsFilter::ItemIsValid(item, now_time)
        || NewsFilter::IsGeneralFiltered(reco_request_, reco_request_->shown_dict,
                                         item, &filter_reason)) {
      continue;
    }

    if (request_->has_channel_id() && request_->channel_id() == reco::common::kSubscriptionChannelId) {
      // 要求缓存的内容标签是用户的订阅词， 避免用户删除标签后仍然从缓存中读到结果
      if (!item_misc.has_hit_tag()
          || user_feas_->behavior_fea.subscript_words.find(item_misc.hit_tag())
          == user_feas_->behavior_fea.subscript_words.end()) {
        continue;
      }
    }

    int strategy_type = item_misc.strategy_type();
    if (strategy_type <= reco::kBanner) {
      item.strategy_type = reco::StrategyType(strategy_type);
    } else {
      item.strategy_type = reco::kNoStrategy;
    }

    item.lr_score = item_misc.lr_score();
    item.fm_score = item_misc.fm_score();
    cached_items->push_back(item);
    if (item_misc.has_hit_tag()) {
      hit_tags->push_back(item_misc.hit_tag());
    } else {
      hit_tags->push_back("");
    }
  }

  VLOG(1) << "get from cache " << reco_data.item_misc_size()
          << ", after filter remains " << cached_items->size()
          << ", req num " << req_num;
  if ((int)cached_items->size() < req_num) {
    cached_items->clear();
    hit_tags->clear();
  }
}

bool SearchReco::RecoInSubscriptChannel(const RecoRequest* reco_request,
                                        std::vector<ItemInfo>* reco_items,
                                        std::vector<std::string>* hit_tags) {
  const uint32 req_num = reco_request->request->return_num();

  reco_request_ = reco_request;
  user_info_ = reco_request->user_info;
  request_ = reco_request->request;
  shown_dict_ = reco_request->shown_dict;
  user_feas_ = reco_request->user_feas;

  const bool use_cache = reco_cache_->CanUseCache(reco_request);
  if (use_cache) {
    reco_items->clear();
    hit_tags->clear();
    GetCachedItems(req_num, reco_items, hit_tags);

    if (reco_items->size() >= req_num) {
      VLOG(1) << "use cached results";
      return true;
    } else {
      VLOG(1) << "cache result not meet, recalc";
    }
  } else {
    VLOG(1) << "do not use cache";
  }

  if (user_feas_ == NULL || shown_dict_ == NULL || user_info_ == NULL) {
    LOG(WARNING) << "input to subscript reco is error";
    return false;
  }

  reco_items->clear();
  hit_tags->clear();
  if (!request_->has_channel_id()
      || (request_->channel_id() != reco::common::kSubscriptionChannelId
          && request_->channel_id() != reco::common::kTagMainpageChannelId)) {
    LOG(WARNING) << "request channel is not tag mainpage nor subscript channel.";
    return false;
  }

  std::vector<std::pair<std::string, double> > sorted_tags;
  if (request_->channel_id() == reco::common::kSubscriptionChannelId) {
    ParseSubcriptTagWeight(user_feas_->behavior_fea.subscript_words, &sorted_tags);
  } else if (request_->channel_id() == reco::common::kTagMainpageChannelId) {
    double w =  1.0 / static_cast<double>(request_->channel_tags_size());
    for (int i = 0; i < request_->channel_tags_size(); ++i) {
      const std::string& tag = request_->channel_tags(i);
      sorted_tags.push_back(std::make_pair(nlp::util::NormalizeLine(tag), w));
    }
  } else {
    LOG(WARNING) << "request format is invalid";
    return false;
  }

  std::vector<std::string> tags_to_search;
  tags_to_search.reserve(sorted_tags.size());
  std::unordered_map<std::string, int> tags_cnt;
  int max_result_num = -1;
  for (int i = 0; i < (int)sorted_tags.size(); ++i) {
    const std::string& tag = sorted_tags[i].first;
    // 按理说不可能，但这里还是检查下
    if (tags_cnt.find(tag) != tags_cnt.end()) {
      LOG(WARNING) << "duplicate tag: " << tag;
      continue;
    }
    tags_to_search.push_back(tag);

    int result_num = kIncrCalcNum * sorted_tags[i].second;
    if (result_num == 0) result_num = 1;
    max_result_num = std::max(result_num, max_result_num);
    tags_cnt.insert(std::make_pair(tag, result_num));
    VLOG(1) << "search " << result_num << " results for tag " << tag;
  }

  std::unordered_map<std::string, std::vector<ItemInfo>> tag_result_map;
  if (max_result_num > 0) {
    DoSearch(tags_to_search, max_result_num, &tag_result_map);
  }

  static const int kContinuousNumPerTag = 3;  // 每个标签最多连续出多少条
  // 每个标签连续出 kContinuousNumPerTag 条内容
  // section 由不同 tag 的连续 kContinuousNumPerTag 组成
  int section_num = (max_result_num % kContinuousNumPerTag == 0) ?
      max_result_num/kContinuousNumPerTag : max_result_num/kContinuousNumPerTag + 1;
  int section_size = kContinuousNumPerTag * sorted_tags.size();

  // vector of pair <tag, item_id>
  std::vector<std::pair<std::string, ItemInfo>> merged_results(section_num * section_size,
                                                               std::make_pair("", ItemInfo()));
  for (int idx_tag = 0; idx_tag < (int)sorted_tags.size(); ++idx_tag) {
    // alread sorted by tag importance
    const std::string& tag = sorted_tags[idx_tag].first;
    auto it = tag_result_map.find(tag);
    if (it == tag_result_map.end()) {
      continue;
    }
    std::vector<ItemInfo>& vec = it->second;
    if (vec.empty()) {
      continue;
    }
    int result_num = tags_cnt[tag];
    if ((int)vec.size() > result_num) {
      vec.resize(result_num);
    }
    auto it_vec = vec.begin();
    VLOG(1) << "tag " << tag << " get " << vec.size() << " results";

    // 把这个 tag 的结果直接放到 merged_results 对应位置上
    for (int idx_section = 0; idx_section < section_num; ++idx_section) {
      if (it_vec == vec.end()) {
        // 这个 tag 所有结果已经放完了
        break;
      }
      int idx_in_section = idx_tag * kContinuousNumPerTag;
      int idx_in_global = idx_section * section_size + idx_in_section;
      for (int i = 0; i < kContinuousNumPerTag; ++i) {
        if (it_vec == vec.end()) {
          break;
        }
        merged_results[idx_in_global] = std::make_pair(tag, *it_vec);
        ++it_vec;
        ++idx_in_global;
      }
    }
  }

  // shrink 掉中间空的位置
  int index = 0;
  for (int i = 0; i < (int)merged_results.size(); ++i) {
    if (merged_results[i].second.item_id != 0) {
      if (i != index) {
        std::swap(merged_results[index], merged_results[i]);
      }
      ++index;
    }
  }
  merged_results.resize(index);
  VLOG(1) << "merged total results " << merged_results.size();

  base::dense_hash_set<uint64> item_dedup;
  item_dedup.set_empty_key(0);
  for (int i = 0; i < (int)merged_results.size(); ++i) {
    reco::ItemInfo& item_info = merged_results[i].second;
    item_info.reco_score = 0;
    if (!NewsFilter::IsDeduped(item_info, &item_dedup)) {
      reco_items->push_back(item_info);
      hit_tags->push_back(merged_results[i].first);
    } else {
      VLOG(1) << "filtered, title len or deduped " << item_info.item_id;
      continue;
    }
  }

  if (use_cache && !reco_items->empty()) {
    reco_cache_->SetCachedItems(reco_request, *reco_items, hit_tags);
    VLOG(1) << "cached results " << reco_items->size();
  } else {
    VLOG(1) << "do not use cache or result is empty";
  }

  if (reco_items->size() > req_num) {
    reco_items->resize(req_num);
    hit_tags->resize(req_num);
  }

  VLOG(1) << "return results " << reco_items->size() << ", req num " << req_num;
  return true;
}

void SearchReco::DoSearchInternal(int thread_no,
                                  thread::BlockingQueue<std::string>* tag_queue,
                                  std::unordered_map<std::string, std::vector<ItemInfo>>* result_map) {

  TagSearcher* searcher = tag_searchers_[thread_no];
  while (!tag_queue->Empty()) {
    // tag, return num
    std::string tag;
    if (1 != tag_queue->TryTake(&tag)) {
      continue;
    }

    auto it = result_map->find(tag);
    if (it == result_map->end()) {
      LOG(ERROR) << "internal error";
      continue;
    }

    searcher->Search(reco_request_, tag, search_config_, &(it->second), NULL);
    VLOG(1) << tag << " return num " << it->second.size();
  }
}

void SearchReco::DoSearch(const std::vector<std::string>& tags, int result_num,
                          std::unordered_map<std::string, std::vector<ItemInfo>>* result_map) {
  search_config_.return_num = result_num;
  thread::BlockingQueue<std::string> tag_queue;
  result_map->clear();
  for (size_t i = 0; i < tags.size(); ++i) {
    if (result_map->find(tags[i]) != result_map->end()) {
      continue;
    }
    tag_queue.Put(tags[i]);
    result_map->insert(std::make_pair(tags[i], std::vector<ItemInfo>()));
  }

  /*
  int concurrent_num = 1;
  switch (LeafDataManager::GetGlobalData()->sys_status) {
    case kSysFree:
      concurrent_num = kMaxConCurrentNum;
      break;
    case kSysNormal:
      concurrent_num = kMaxConCurrentNum/2;
      break;
    default:
      break;
  }
  */

  int concurrent_num = kMaxConCurrentNum/2;
  if (concurrent_num > tag_queue.Size()) {
    concurrent_num = tag_queue.Size();
  }

  if (concurrent_num > 1) {
    thread::ThreadPool pool(concurrent_num);
    for (int i = 0; i < concurrent_num; ++i) {
      pool.AddTask(::NewCallback(this, &SearchReco::DoSearchInternal, i, &tag_queue, result_map));
    }
    pool.JoinAll();
  } else {
    DoSearchInternal(0, &tag_queue, result_map);
  }

  return;
}
}  // namespace leafserver
}  // namespace reco
