#include "base/testing/gtest.h"

#include "reco/serv/reco_leaf/strategy/reco/offline/item_dict_manager.h"
#include "reco/serv/reco_leaf/strategy/reco/offline/base_item_dict.h"
#include "reco/serv/reco_leaf/strategy/reco/offline/jingpin_item_dict.h"

namespace reco {
namespace leafserver {

class ItemDictTest : public testing::Test {
 public:
  virtual void SetUp() {
  }

  virtual void TearDown() {
  }

 private:
};

TEST_F(ItemDictTest, ItemDictManager) {
  ItemDictManager dict_manager;
  const size_t dict_num = 4;
  for (auto i = 0u; i < dict_num; ++i) {
    dict_manager.AddDict(new BaseItemDict());
  }

  ASSERT_EQ(dict_num, dict_manager.DictNum());
  dict_manager.ClearDict();
  ASSERT_EQ(0u, dict_manager.DictNum());
}

TEST_F(ItemDictTest, BaseItemDict) {
  ItemDictManager dict_manager;
  BaseItemDict dict;
  dict_manager.AddDict(&dict);

  RecoRequest req;
  std::unordered_map<uint64, ItemDictData> item_map;
  ASSERT_TRUE(!dict_manager.FillData(req, &item_map));
}

TEST_F(ItemDictTest, JingpinItemDict) {
  ItemDictManager dict_manager;
  JingpinItemDict dict;
  dict_manager.AddDict(&dict);

  RecoRequest req;
  std::unordered_map<uint64, ItemDictData> item_map;
  // ASSERT_TRUE(!dict_manager.FillData(req, &item_map));
}
}
}
