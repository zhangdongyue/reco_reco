#include "reco/serv/reco_leaf/strategy/reco/offline/jingpin_item_dict.h"

#include <unordered_map>
#include <string>
#include <vector>
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace leafserver {

inline std::string GetJingpinKey(const std::string& app_name, const uint64 user_id) {
  return base::StringPrintf("jp_%s-%lu", app_name.c_str(), user_id);
}

bool JingpinItemDict::FillData(const RecoRequest &request, std::unordered_map<uint64, uint32> *item_map) {
  static const uint32 kMaxIRNum = 4096;
  // 获取缓存数据
  const uint64 user_id = request.user_info->identity().user_id();
  const std::string& app_name = request.request->app_token();
  const std::string& key = GetJingpinKey(app_name, user_id);

  std::string value;
  // TODO(xielang): 直接从 redis 拿 ?, score 能否也写进去 ?
  if (!LeafCache::GetCachedReco(key, &value)) return false;

  std::vector<std::string> flds;
  base::SplitString(value, ",", &flds);

  if (flds.size() > kMaxIRNum) {
    LOG(ERROR) << base::StringPrintf("too many jingpin item for current user, userkey=%s, itemnum=%lu",
                                     key.c_str(), flds.size());
    flds.resize(kMaxIRNum);
  }

  for (size_t i = 0; i < flds.size(); ++i) {
    uint64 item_id = 0;
    if (!base::StringToUint64(flds[i], &item_id)) {
      continue;
    }

    // TODO(xielang): 分数是否让 zhimin 写入 ?
    uint32 score = (kMaxIRNum - i);
    auto it_pair = item_map->insert(std::make_pair(item_id, score << 16));
    if (!it_pair.second) {
      LOG(ERROR) << base::StringPrintf("dedup item: item_id=%lu, current score=%u, drop score=%u",
                                       item_id, it_pair.first->second, score);
    }
  }
  return true;
}
}
}
