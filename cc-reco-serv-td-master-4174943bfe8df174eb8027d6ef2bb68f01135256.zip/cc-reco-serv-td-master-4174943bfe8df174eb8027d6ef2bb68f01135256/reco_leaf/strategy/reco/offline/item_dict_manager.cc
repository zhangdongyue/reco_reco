#include "reco/serv/reco_leaf/strategy/reco/offline/item_dict_manager.h"

#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/reco/offline/base_item_dict.h"

namespace reco {
namespace leafserver {

DEFINE_int32(item_dict_max_size, 10000, "max classify item dict size");

ItemDictManager::ItemDictManager() {
  CHECK(kMaxItemDictType < kDictTypeMaxNum) << "item dict type > dict array size";
}

bool ItemDictManager::AddDict(BaseItemDict *dict) {
  if (dict) {
    thread::WriterAutoLock lock(&rw_mutex_);
    dict_set_.insert(dict);
    return true;
  }

  return false;
}

bool ItemDictManager::ClearDict(void) {
  thread::WriterAutoLock lock(&rw_mutex_);
  for (std::unordered_set<BaseItemDict*>::iterator it = dict_set_.begin(); it != dict_set_.end(); ++it) {
    delete (*it);
  }
  dict_set_.clear();
  return true;
}

size_t ItemDictManager::DictNum(void) {
  thread::ReaderAutoLock lock(&rw_mutex_);
  return dict_set_.size();
}

bool ItemDictManager::FillData(const RecoRequest &request,
                               std::unordered_map<uint64, ItemDictData> *entire_item_map) {
  bool ret = true;
  std::unordered_map<uint64, uint32> single_item_map;
  thread::ReaderAutoLock lock(&rw_mutex_);

  for (auto dict_it = dict_set_.begin(); dict_it != dict_set_.end(); ++dict_it) {
    BaseItemDict *dict = *dict_it;
    if (!dict) {
      LOG(ERROR) << "dict is null, check!";
      ret = false;
      continue;
    }

    const ItemDictType dict_type = dict->GetType();

    // check dict type
    if (dict_type <= kInvalidDict || dict_type >= kMaxItemDictType) {
      LOG(ERROR) << "dict type error, type:" << dict_type;
      ret = false;
      continue;
    }

    // fill dict data
    single_item_map.clear();
    if (dict->FillData(request, &single_item_map)) {
      if (single_item_map.size() > (size_t)FLAGS_item_dict_max_size) {
        LOG(WARNING) << "dict num too large, size:" << single_item_map.size() << ", type:" << dict_type;
        continue;
      }

      // update dict data to item map
      for (auto item_it = single_item_map.begin(); item_it != single_item_map.end(); ++item_it) {
        const uint64 &item_id = item_it->first;
        const uint32 &value = item_it->second;

        auto search = entire_item_map->find(item_id);
        if (search == entire_item_map->end()) {
          ItemDictData item_data;
          item_data.data[dict_type] = value;
          (*entire_item_map)[item_id] = item_data;
        } else {
          ItemDictData &item_data = search->second;
          item_data.data[dict_type] = value;
        }
      }
    } else {
      LOG(ERROR) << "fill item dict data error, dict type is:" << dict_type;
      ret = false;
    }
  }

  // del invalid data
  if (request.user_info) {
    const base::dense_hash_set<uint64> *shown_items = request.shown_dict;
    for (auto it = entire_item_map->begin(); it != entire_item_map->end();) {
      if (shown_items->find(it->first) != shown_items->end()) {
        VLOG(1) << "erased by shown items: " << it->first;
        it = entire_item_map->erase(it);
      } else {
        ++it;
      }
    }
  }

  // LOG(INFO) << "item map dict size: " << entire_item_map->size();
  return ret;
}
}
}
