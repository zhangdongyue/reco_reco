#pragma once

#include <unordered_map>

#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace reco {
namespace leafserver {

enum ItemDictType {
  kInvalidDict = -1,
  kCFDict = 0,
  kJingPinDict = 1,
  kMaxItemDictType
};

// item 字典基类，所有字典模型都要继承这个基类，才能加载到整个流程中
class BaseItemDict {
 public:
  BaseItemDict() {}

  virtual ~BaseItemDict() {}

  // 每个具体 dict 需要重载这个接口，来返回自己的类型
  virtual ItemDictType GetType() { return kInvalidDict; }

  virtual bool FillData(const RecoRequest &request, std::unordered_map<uint64, uint32> *item_map) {
    return true;
  }

 private:
  DISALLOW_COPY_AND_ASSIGN(BaseItemDict);
};
}
}
