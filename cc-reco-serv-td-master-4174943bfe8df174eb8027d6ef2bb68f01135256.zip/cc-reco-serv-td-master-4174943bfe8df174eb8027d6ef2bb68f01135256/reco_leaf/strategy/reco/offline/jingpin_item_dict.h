#pragma once
#include <unordered_map>
#include "reco/serv/reco_leaf/strategy/reco/offline/base_item_dict.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace reco {
namespace leafserver {

// item 字典基类，所有字典模型都要继承这个基类，才能加载到整个流程中
class JingpinItemDict: public BaseItemDict {
 public:
  JingpinItemDict() {}

  ~JingpinItemDict() {}

  ItemDictType GetType() { return kJingPinDict; }

  bool FillData(const RecoRequest &request, std::unordered_map<uint64, uint32> *item_map);

 private:
  DISALLOW_COPY_AND_ASSIGN(JingpinItemDict);
};
}
}
