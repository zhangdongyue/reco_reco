#pragma once

#include <cstring>
#include <unordered_set>
#include <unordered_map>

#include "base/thread/rw_mutex.h"
#include "reco/base/common/singleton.h"

namespace reco {
namespace leafserver {
struct RecoRequest;
class BaseItemDict;

const int kDictTypeMaxNum = 5;
struct ItemDictData {
  // 每个 data, 高 16 位是 score, 低 16 位是 weight
  uint32 data[kDictTypeMaxNum];

  ItemDictData() {
    std::memset(data, 0, sizeof(data));
  }
};

class ItemDictManager {
 public:
  ItemDictManager();

  ~ItemDictManager() {}

  // 初始化运行时要使用的 item dict, 运行时不要调用逐个接口，避免多线程冲突
  bool AddDict(BaseItemDict *dict);

  bool ClearDict(void);

  size_t DictNum(void);

  // 每次请求，逐个字典调用，填充 item map 数据, 最后会用 user_info 对展示过的 item 进行过滤
  bool FillData(const RecoRequest &request, std::unordered_map<uint64, ItemDictData> *entire_item_map);

 private:
  std::unordered_set<BaseItemDict*> dict_set_;

  mutable thread::RWMutex rw_mutex_;

  DISALLOW_COPY_AND_ASSIGN(ItemDictManager);
};

// typedef reco::common::singleton_default<ItemDictManager> ItemDictMgr;
}
}
