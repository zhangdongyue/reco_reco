#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/reco/session/w2v_item_reco.h"
#include "base/time/time.h"

namespace reco {
namespace leafserver {
// session 分析结果
//struct SessionAnalysisResult {
//  // 下次刷新要出的 item 及权重, 由下游自行根据权重决定是否实际下发
//  std::vector<ItemInfo> reco_items;
//  // 类目权重
//  std::vector<std::pair<float, reco::Category>> category_distributes;
//};

//
class SessionReco {
 public:
  explicit SessionReco(const reco::NewsIndex* index);
  ~SessionReco();

  // 对外接口
  void DoSessionReco(const RecoRequest *request, RecoContext *ctx, std::vector<ItemInfo> *reco_items);

 private:
  const NewsIndex* news_index_;
  W2VItemReco* w2v_item_reco_;
  CandidatesExtractor* candidates_extor_;
};
} // namespace leafserver
} // namespace reco
