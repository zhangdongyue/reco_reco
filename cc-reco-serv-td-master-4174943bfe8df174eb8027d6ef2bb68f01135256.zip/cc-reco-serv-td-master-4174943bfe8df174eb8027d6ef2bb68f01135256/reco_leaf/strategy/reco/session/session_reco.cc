#include "reco/serv/reco_leaf/strategy/reco/session/session_reco.h"

namespace reco {
namespace leafserver {

SessionReco::SessionReco(const reco::NewsIndex *index) {
  news_index_ = index;
  w2v_item_reco_ = new W2VItemReco(news_index_);
  candidates_extor_ = new CandidatesExtractor(news_index_);
}

SessionReco::~SessionReco() {
  if (w2v_item_reco_) {
    delete w2v_item_reco_;
    w2v_item_reco_ = NULL;
  }

  if (candidates_extor_) {
    delete candidates_extor_;
    candidates_extor_ = NULL;
  }
}

void SessionReco::DoSessionReco(const RecoRequest *request,
                                RecoContext *ctx,
                                std::vector<ItemInfo> *reco_items) {
  int num_req = 0;
  const UserFeature *user_feas = request->user_feas;
  double num_click = user_feas->lt_fea.click_num + user_feas->st_fea.st_click_num;

  // w2v strategy
  if (num_click <= 5) {
    num_req = 3;
  } else if (num_click <= 10) {
    num_req = 2;
  } else {
    num_req = 1;
  }

  int count = num_req;
  std::vector<ItemInfo> candidates;

  if (count > 0) {
    w2v_item_reco_->DoReco(request, ctx, num_req * 2, &candidates);
  }

  // filter
  std::vector<ItemInfo> filter_candidates;
  candidates_extor_->BasicRuleFilter(request, kCandidateSession, candidates, &filter_candidates);

  for (int i = 0; i < static_cast<int>(filter_candidates.size()) && i < num_req; ++i) {
    ItemInfo &item = filter_candidates[i];
    reco_items->push_back(item);
  }

  LOG(INFO) << "user:" << request->user_info->identity().user_id()
            << ", profile weight: " << num_click
            << ", req num:" << num_req
            << ", rec items:" << std::min(num_req, (int)filter_candidates.size());
}
}
}
