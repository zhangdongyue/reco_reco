#include "reco/serv/reco_leaf/strategy/reco/session/w2v_item_reco.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/dict_server/api/dict_server_api.h"
#include "serving_base/utility/timer.h"

namespace reco {
namespace leafserver {

DEFINE_int32(w2v_top_n_clicks, 40, "get similar candidates from top n clicks");
DEFINE_int32(w2v_window_in_hours, 72, "window in hours for click");
DEFINE_int32(w2v_top_n_candidates, 120, "top n candidates from w2v dict");

const std::unordered_set<int> W2VItemReco::allowed_item_types = {
  reco::kNews, reco::kReading, reco::kPicture, reco::kPictureNews};

W2VItemReco::W2VItemReco(const reco::NewsIndex *index) {
  news_index_ = index;
}

W2VItemReco::~W2VItemReco() {
}

void W2VItemReco::DoReco(const RecoRequest *request, RecoContext *ctx, int num_req,
                         std::vector<ItemInfo> *reco_items) {
  serving_base::Timer timer;

  request_ = request;
  int64 start_time = base::GetTimestamp();
  // 候选集触发
  // 根据用户最近的点击，来召回相似的item
  std::unordered_map<uint64, double> candidates;
  std::unordered_map<uint64, std::pair<uint64, double>> items_map;
  std::unordered_set<uint64> invalid_clicks;

  int64 min_click_ts = request->current_timestamp
      - FLAGS_w2v_window_in_hours * base::Time::kMicrosecondsPerHour;
  const reco::user::UserInfo *user_info = request->user_info;
  uint user_id = request->user_info->identity().user_id();

  int condition = std::max(0, user_info->recent_click_size() - FLAGS_w2v_top_n_clicks);
  timer.Start();
  FilterClicks(request, &invalid_clicks);
  VLOG(1) << "uid=" << user_id << ", FilterClicks cost time: " << timer.Stop();

  timer.Start();
  for (int i = user_info->recent_click_size() - 1; i >= condition; --i) {
    const reco::user::ViewClickItem &item = user_info->recent_click(i);
    if (item.click_timestamp() < min_click_ts) {
      break;
    }

    // item type 过滤
    if (allowed_item_types.find(item.item_type()) == allowed_item_types.end()) {
      VLOG(1) << item.item_id() << " filtered by item type";
      continue;
    }

    // 已经出过但是没点的item对应的click退场
    if (invalid_clicks.find(item.item_id()) != invalid_clicks.end()) {
      VLOG(1) << item.item_id() << " invalid click";
      continue;
    }

    reco::RelateItemRecoResult rel_items;
    if (GetRelateItems(item.item_id(), &rel_items)
        && start_time - rel_items.last_update_timestamp() * base::Time::kMicrosecondsPerSecond
        < 6 * base::Time::kMicrosecondsPerHour) {
      for (int j = 0; j < rel_items.relate_item_size(); ++j) {
        uint64 rel_item_id = rel_items.relate_item(j).item_id();
        double score = rel_items.relate_item(j).score();
        if (score > candidates[rel_item_id]) {
          candidates[rel_item_id] = score;
          items_map[rel_item_id] = std::make_pair(item.item_id(), score);
        }
      }
    }
  }
  VLOG(1) << "uid=" << user_id << ", Ir cost time: " << timer.Stop();

  // 排序
  timer.Start();
  if (candidates.empty()) {
    int64 end_time = base::GetTimestamp();
    VLOG(1) << "user[" << request->user_info->identity().user_id() << "]"
              << " no reco item,"
              << " time elapsed:" << float(end_time - start_time) / 1000 << "ms";
    return;
  }

  std::vector<std::pair<double, uint64>> w2v_scores;
  for (auto iter = candidates.begin(); iter != candidates.end(); iter++) {
    if (iter->second < 0.6) continue;
    w2v_scores.push_back(std::make_pair(iter->second, iter->first));
  }
  std::sort(w2v_scores.begin(), w2v_scores.end(), std::greater<std::pair<double, uint64 >>());
  std::vector<std::pair<double, ItemInfo>> score_items;
  for (int i = 0; i < (int) w2v_scores.size() && i < FLAGS_w2v_top_n_candidates; ++i) {
    ItemInfo item;
    if (!news_index_->GetItemInfoByItemId(w2v_scores[i].second, &item, false)) {
      VLOG(1) << w2v_scores[i].second << " no iteminfo filtered";
      continue;
    }
    // 过滤运营文章，因为运营文章的时效性不好控制
    if (news_index_->IsManualByDocId(item.doc_id)) {
     VLOG(1) << item.item_id << " producer filtered";
     continue;
    }
    // item type 过滤
    if (allowed_item_types.find(item.item_type) == allowed_item_types.end()) {
     VLOG(1) << item.item_id << " item type filtered";
     continue;
    }
    // 过滤时效性不好、ctr低、下发量低的文章
    if ((item.time_level == reco::kBadTimeliness) || item.ctr < 0.1 || item.show_num < 50000) {
      VLOG(1) << item.item_id << " low quality filtered";
      continue;
    }
    // 根据item的有效性来进行过滤
    if (!NewsFilter::ItemIsValid(item, request->current_timestamp)) {
      VLOG(1) << item.item_id << " invalid item ts filtered";
      continue;
    }
    // 根据展现历史来进行过滤
    reco::filter::FilterReason filter_reason;
    if (NewsFilter::IsGeneralFiltered(request, request->shown_dict, item, &filter_reason, false)) {
      VLOG(1) << item.item_id << " general filtered";
      continue;
    }

    double score = w2v_scores[i].first;
    if (item.time_level == reco::kMidTimeliness) {
      score *= 0.7;
    }
    int itemq = item.itemq <= 0 ? 0 : std::max(-2, std::min(item.itemq - 3, 4));
    score *= item.ctr * std::pow(1.2, itemq);
    score_items.push_back(std::make_pair(score, item));
  }

  std::sort(score_items.begin(), score_items.end(), std::greater<std::pair<double, ItemInfo >>());

  int num_return = std::min((int) score_items.size(), num_req);

  for (int i = 0; i < num_return; ++i) {
    ItemInfo &item = score_items[i].second;
    item.strategy_type = reco::kSession;
    item.strategy_branch = reco::kSessionW2VBranch;
    // 记录item是通过哪次click召回的，用于click退场
    item.reco_ext_info = base::Uint64ToString(items_map[item.item_id].first);
    reco_items->push_back(item);
    VLOG(1) << "user[" << request->user_info->identity().user_id() << "]"
            << item.item_id << ",<" << items_map[item.item_id].first << ","
            << items_map[item.item_id].second << ">";
  }
  VLOG(1) << "uid=" << user_id << ", Rank cost time: " << timer.Stop();

  int64 end_time = base::GetTimestamp();
  VLOG(1) << "user[" << request->user_info->identity().user_id() << "]"
          << " reco item size:" << num_return << ","
          << " time elapsed:" << float(end_time - start_time) / 1000 << "ms";
}

void W2VItemReco::FilterClicks(const RecoRequest *request, std::unordered_set<uint64> *invalid_clicks) {
  invalid_clicks->clear();

  int64 min_history_ts = request->current_timestamp
      - FLAGS_w2v_window_in_hours * base::Time::kMicrosecondsPerHour;
  const reco::user::UserInfo *user_info = request->user_info;
  std::unordered_map<uint64, std::string> ext_infos;
  std::unordered_set<std::string> unclick_ext_infos;
  for (int i = user_info->shown_history_size() - 1; i >= 0; i--) {
    const reco::user::ViewClickItem &item = user_info->shown_history(i);
    if (item.view_timestamp() < min_history_ts) {
      break;
    }
    if (item.strategy_branch() == reco::kSessionW2VBranch
        && item.has_reco_ext_info()
        && !item.reco_ext_info().empty()) {
      ext_infos[item.item_id()] = item.reco_ext_info();
      unclick_ext_infos.insert(item.reco_ext_info());
    }
  }
  for (int i = user_info->recent_click_size() - 1; i >= 0; i--) {
    const reco::user::ViewClickItem &item = user_info->recent_click(i);
    if (item.click_timestamp() < min_history_ts) {
      break;
    }
    // 只要相似的item有过一次点击，则认为该click是valid
    if (ext_infos.find(item.item_id()) != ext_infos.end()) {
      unclick_ext_infos.erase(ext_infos[item.item_id()]);
    }
  }

  for (auto it = unclick_ext_infos.cbegin(); it != unclick_ext_infos.cend(); ++it) {
    uint64 item_id;
    if (!base::StringToUint64(*it, &item_id)) continue;
    invalid_clicks->insert(item_id);
  }
}

bool W2VItemReco::GetRelateItems(const uint64 orig_item_id, reco::RelateItemRecoResult *reco_ret) {
  std::string proto_str;
  LeafDataManager::GetGlobalData()->GetW2vRecoResult(orig_item_id, &proto_str);
  if (proto_str.empty()) {
    VLOG(1) << "w2v reco result is empty, item_id=" << orig_item_id;
    return false;
  }
  if (!reco_ret->ParseFromString(proto_str)) {
    LOG(WARNING) << "failed to parse RelateItemRecoResult proto: " << proto_str;
    return false;
  }

  return true;
}
}
}
