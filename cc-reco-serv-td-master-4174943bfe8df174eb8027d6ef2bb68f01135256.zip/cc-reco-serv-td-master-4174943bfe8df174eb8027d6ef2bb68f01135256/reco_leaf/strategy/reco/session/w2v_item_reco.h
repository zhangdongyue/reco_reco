#pragma once

#include <string>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "base/common/gflags.h"
#include "base/time/time.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/component/debugger/reco_debugger.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/reco_index/item_info.h"

namespace reco {
namespace leafserver {

class W2VItemReco {
 public:
  explicit W2VItemReco(const reco::NewsIndex *index);

  ~W2VItemReco();

  // 对外接口
  void DoReco(const RecoRequest *request, RecoContext *ctx, int num_req, std::vector<ItemInfo> *reco_items);

  // 获取 item 的 w2v 推荐结果
  bool GetRelateItems(const uint64 orig_item_id, reco::RelateItemRecoResult *reco_ret);
 private:
  // 过滤掉那些已经出过item但是没有点击的click
  void FilterClicks(const RecoRequest *request, std::unordered_set<uint64> *invalid_clicks);

  const NewsIndex *news_index_;
  const RecoRequest *request_;

  static const std::unordered_set<int> allowed_item_types;
};

} // namespace leafserver
} // namespace reco
