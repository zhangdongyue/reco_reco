#pragma once
#include <vector>

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

namespace reco {
class NewsIndex;

namespace leafserver {
class RecoRequest;

class CrowdOperReco {
 public:
  explicit CrowdOperReco(const reco::NewsIndex* index);

  ~CrowdOperReco();

  void GetCrowdOperItems(const RecoRequest& request,
                         std::vector<ItemInfo>* reco_items,
                         int32* co_insert_pos,
                         RecoDebugger* debugger);
 private:
  void Reset();
  void ExtractRequestFeature(const reco::user::UserInfo& user_info, const UserFeature& user_feas);
  void ChooseInsertPos(const RecoRequest& request,
                       std::vector<ItemInfo>* reco_items,
                       int32* co_insert_pos);

  int32 session_request_num_;
  bool crowd_oper_shown_;
  bool crowd_oper_click_;
  bool is_new_user_;

  const NewsIndex* news_index_;
  CandidatesExtractor* candidates_extrator_;
};

}  // namespace leafserver
}  // namespace reco

