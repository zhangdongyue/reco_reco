#include "reco/serv/reco_leaf/strategy/reco/crowd_oper/crowd_oper_reco.h"

#include <string>
#include <vector>

#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/reco_index/item_info.h"

namespace reco {
class NewsIndex;

namespace leafserver {

CrowdOperReco::CrowdOperReco(const reco::NewsIndex* index) {
  news_index_ = index;
  candidates_extrator_ = new CandidatesExtractor(index);
}

CrowdOperReco::~CrowdOperReco() {
  delete candidates_extrator_;
}

void CrowdOperReco::Reset() {
  session_request_num_ = 0;
  crowd_oper_shown_ = false;
  crowd_oper_click_ = false;
  is_new_user_ = false;
}

void CrowdOperReco::ExtractRequestFeature(const reco::user::UserInfo& user_info,
                                          const UserFeature& user_feas) {
  base::Time expire_time = base::Time::Now() - base::TimeDelta::FromHours(24);
  int64 since_tm = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int64 last_timestamp = -1;
  session_request_num_ = 0;
  crowd_oper_shown_ = false;
  VLOG(1) << "xx since_tm: " << since_tm;
  std::set<uint64> co_item_set;
  for (int i = user_info.shown_history_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& show_item = user_info.shown_history(i);
    if (show_item.view_timestamp() < since_tm) break;
    if (!show_item.has_channel_id()
        || show_item.channel_id() != reco::common::kRecoChannelId) continue;
    if (show_item.strategy_branch() == reco::kCrowdOperBranch
        && show_item.view_timestamp() != last_timestamp) {
      last_timestamp = show_item.view_timestamp();
      ++session_request_num_;
      crowd_oper_shown_ = true;
      co_item_set.insert(show_item.item_id());
      VLOG(1) << "xx show: " << base::StringReplace(show_item.Utf8DebugString(), "\n", " ", true);
    }
  }

  crowd_oper_click_ = false;
  for (int i = user_info.recent_click_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& clicked_item = user_info.recent_click().Get(i);
    VLOG(1) << "xx click: " << base::StringReplace(clicked_item.Utf8DebugString(), "\n", " ", true);
    if (clicked_item.click_timestamp() < since_tm) break;
    if (co_item_set.find(clicked_item.item_id()) != co_item_set.end()) {
      crowd_oper_click_ = true;
    }
  }

  is_new_user_ = user_feas.merged_info.total_click_num < 20 ? true : false;
}

void CrowdOperReco::ChooseInsertPos(const RecoRequest& request,
                                    std::vector<ItemInfo>* ret_items,
                                    int32* co_insert_pos) {
  if (is_new_user_) {  // C
    if (session_request_num_ == 0) {
      (*co_insert_pos) = 3;
    } else if (crowd_oper_shown_ && crowd_oper_click_) {
      (*co_insert_pos) = 0;
    } else if (session_request_num_ >= 4) {
      (*co_insert_pos) = -1;  // 不出运营文章
    } else {
      (*co_insert_pos) = 7;
    }
    for (size_t i = 0; i < ret_items->size(); ++i) {
      ret_items->at(i).reco_ext_info += "|C";
    }
    LOG(INFO) << "xx " << session_request_num_ << " " << crowd_oper_shown_ << " " << crowd_oper_click_
              << " " << is_new_user_ << " " << (*co_insert_pos);
    return;
  }
  for (size_t i = 0; i < ret_items->size(); ++i) {
    ItemInfo& item = (*ret_items)[i];
    int32 interest_pos = -1;
    for (size_t j = 0; j < request.category_distributes->size(); ++j) {
      if (item.category == request.category_distributes->at(j).second.category()) {
        interest_pos = (int32)j;
        break;
      }
    }
    if (interest_pos <= 0) {  // B
      if (session_request_num_ == 0) {
        (*co_insert_pos) = 7;
      } else if (crowd_oper_shown_ && crowd_oper_click_) {
        (*co_insert_pos) = 0;
      } else if (session_request_num_ % 3 == 0) {
        (*co_insert_pos) = 7;
      } else if (!crowd_oper_click_ && session_request_num_ > 3) {
        (*co_insert_pos) = -1;
      } else {
        (*co_insert_pos) = 7;
      }
      item.reco_ext_info += "|B";
    } else {  // A
      if (session_request_num_ == 0) {
        (*co_insert_pos) = interest_pos;
      } else if (crowd_oper_shown_ && crowd_oper_click_) {
        (*co_insert_pos) = 0;
      } else if (!crowd_oper_click_ && session_request_num_ > 3) {
        (*co_insert_pos) = -1;
      } else {
        (*co_insert_pos) = 7;
      }
      item.reco_ext_info += "|A";
    }
    break;
  }
  LOG(INFO) << "xx " << session_request_num_ << " " << crowd_oper_shown_ << " " << crowd_oper_click_
            << " " << is_new_user_ << " " << (*co_insert_pos);
}

void CrowdOperReco::GetCrowdOperItems(const RecoRequest& request,
                                      std::vector<ItemInfo>* ret_items,
                                      int32* co_insert_pos,
                                      RecoDebugger* debugger) {
  ret_items->clear();
  candidates_extrator_->GetCrowdOperCandidates(&request, ret_items, 10, debugger);
  if (ret_items->size() <= 0) return;

  Reset();
  ExtractRequestFeature(*(request.user_info), *(request.user_feas));
  ChooseInsertPos(request, ret_items, co_insert_pos);
}

}  // leafserver
}  // reco
