#pragma once

#include <string>
#include <vector>
#include <unordered_set>

#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/reco/interest/interest_common.h"
#include "reco/serv/reco_leaf/strategy/search/tag_searcher.h"
#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"
#include "reco/serv/reco_leaf/strategy/reco/third_party/session_analyzer.h"

namespace adsindexing {
class Index;
}

namespace reco {
class NewsIndex;

namespace leafserver {

// 基于 uc 大投放反馈的 sid 信息的推荐模块，用于冷启动
class UcReco {
 public:
  explicit UcReco(const reco::NewsIndex* index);
  ~UcReco();

  // 基于 uc sid 数据推荐接口
  void DoReco(const RecoRequest* request,
              std::vector<ItemInfo>* reco_items,
              RecoContext* context);

 private:
  // 推荐频道
  void DoComplexChannelReco(std::vector<ItemInfo>* reco_items, RecoContext* context);

  // TODO 垂直频道
  void DoVerticalChannelReco(std::vector<ItemInfo>* reco_items, RecoContext* context);

  // 解析 UC SID 信息
  void ParseUcSidInfo(const RecoRequest* request, reco::dm::UcSidInfo* ret_sid_info);

  // 统计 SID 的下发 quota
  void StatRecoQuota(const std::vector<reco::dm::UcSidInfo>& sid_info_list,
                     std::map<std::string, int>& quota_map);

  // 推荐
  void RecoByUcSid(const reco::dm::UcSidInfo& sid_info,
                   std::vector<ItemInfo>* reco_items,
                   RecoContext* context);

  // 获取缓存
  void GetCachedItems(const std::string& cache_key, int64 now_timestamp,
                      std::vector<ItemInfo>* cached_items);

  // show history 去重
  void UserDedup(const RecoRequest* reco_request, std::vector<ItemInfo>* item_list,
                 int64* filtered_num);

 private:
  static const int kTopNSize = 100;

  const reco::NewsIndex* news_index_;
  const RecoRequest* reco_request_;

  serving_base::Timer timer_;

  // TagSearcher 内部支持按 tag 或 category 触发
  // 为保证覆盖率, tag 触发结果不足时使用 category 触发结果补齐
  // 两种触发使用不同的 searcher config 设置
  TagSearcher* tag_searcher_;
  BaseSearcher::Config tag_searcher_config_;
  BaseSearcher::Config cate_searcher_config_;
};

}
}

