#include "reco/serv/reco_leaf/strategy/reco/uc/uc_reco.h"

#include <algorithm>

#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/frame/leaf_controller.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/common/item_level_define.h"
#include "reco/serv/reco_leaf/strategy/reco/interest/interest_common.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/reco_leaf/strategy/search/tag_searcher.h"
#include "base/strings/string_split.h"

namespace reco {
namespace leafserver {

UcReco::UcReco(const reco::NewsIndex* index) :
    news_index_(index), tag_searcher_config_("UcSidTag"), cate_searcher_config_("UcSidCate") {

  tag_searcher_ = new TagSearcher(news_index_);

  // tag searcher 配置
  // SID 推荐优先保证覆盖率, 所以 tag searcher config 限制条件较松
  tag_searcher_config_.ir_num = 2000;
  tag_searcher_config_.fr_num = 500;
  tag_searcher_config_.rel_low_threshold = 0.4;
  tag_searcher_config_.rel_high_threshold = 0.7;
  tag_searcher_config_.ctr_low_threshold = 0.03;
  tag_searcher_config_.ctr_high_threshold = 0.05;
  tag_searcher_config_.show_threshold = 200;

  tag_searcher_config_.title_rel_coef = 0.5f;
  tag_searcher_config_.keyword_rel_coef = 0.3f;

  tag_searcher_config_.timelevel_threshold = reco::kMidTimeliness;
  tag_searcher_config_.use_cache = false;  //外层使用 cache

  tag_searcher_config_.filter_region = true;
  tag_searcher_config_.in_show_tag = false;
  tag_searcher_config_.do_user_dedup = false; // tag_searcher 内部不做去重

  tag_searcher_config_.white_item_type_dict.insert(reco::kNews);
  tag_searcher_config_.white_item_type_dict.insert(reco::kReading);
  tag_searcher_config_.white_item_type_dict.insert(reco::kPicture);
  tag_searcher_config_.white_item_type_dict.insert(reco::kPictureNews);

  tag_searcher_config_.retr_stem_vec.push_back(reco::kTagIr);

  // category searcher 配置
  // 一级类目基本不存在召回问题, 所以过滤条件可以卡严一点
  cate_searcher_config_.ir_num = 2000;
  cate_searcher_config_.fr_num = 500;
  cate_searcher_config_.rel_low_threshold = 0.0;
  cate_searcher_config_.rel_high_threshold = 0.7;
  cate_searcher_config_.ctr_low_threshold = 0.03;
  cate_searcher_config_.ctr_high_threshold = 0.08;
  cate_searcher_config_.show_threshold = 1000;

  cate_searcher_config_.title_rel_coef = 0.0f;
  cate_searcher_config_.keyword_rel_coef = 0.0f;

  cate_searcher_config_.timelevel_threshold = reco::kMidTimeliness;
  cate_searcher_config_.use_cache = false;  //外层使用 cache

  cate_searcher_config_.filter_region = true;
  cate_searcher_config_.in_show_tag = false;
  cate_searcher_config_.do_user_dedup = false; // tag_searcher 内部不做去重

  cate_searcher_config_.white_item_type_dict.insert(reco::kNews);
  cate_searcher_config_.white_item_type_dict.insert(reco::kReading);
  cate_searcher_config_.white_item_type_dict.insert(reco::kPicture);
  cate_searcher_config_.white_item_type_dict.insert(reco::kPictureNews);

  cate_searcher_config_.retr_stem_vec.push_back(reco::kL1CategoryIr);
}

UcReco::~UcReco() {
  delete tag_searcher_;
}

void UcReco::DoReco(const RecoRequest* request,
                    std::vector<ItemInfo>* reco_items,
                    RecoContext* context) {
  reco_items->clear();
  reco_request_ = request;
  VLOG(1) << request->request->Utf8DebugString();

  if (request->channel_id == reco::common::kRecoChannelId) {
    DoComplexChannelReco(reco_items, context);
  } else {
    // 暂时仅对推荐频道生效
    // DoVerticalChannelReco(reco_items, context);
  }
}

void UcReco::DoComplexChannelReco(std::vector<ItemInfo>* reco_items, RecoContext* context) {
  uint64 user_id = reco_request_->user_info->identity().user_id();

  // 从 request 中解析出 uc sid 对应的信息, 获取用于触发的 category 和 keyword
  reco::dm::UcSidInfo sid_info;
  ParseUcSidInfo(reco_request_, &sid_info);
  if (sid_info.sid.empty() || sid_info.category.empty() || sid_info.keyword.empty()) {
    VLOG(1) << "invalid sid info: " << sid_info.ToString();
    return;
  }
  LOG(INFO) << "do uc sid reco, uid=" << user_id << ", sid_info=" << sid_info.ToString();

  // 推荐
  RecoByUcSid(sid_info, reco_items, context);
  for (int i = 0; i < (int)reco_items->size(); ++i) {
    ItemInfo &item = reco_items->at(i);
    // strategy_type 和 strategy_branch 触发时已设定
    item.reco_ext_info = base::StringPrintf("%s,%s,%s", sid_info.sid.c_str(),
                                            sid_info.category.c_str(), sid_info.keyword.c_str());
    VLOG(1) << "uc sid reco result: uid=" << user_id
            << ", item_id=" << reco_items->at(i).item_id;
  }
  LOG(INFO) << "uc sid reco ret, uid=" << user_id << ", ret_size=" << reco_items->size();
}

void UcReco::DoVerticalChannelReco(std::vector<ItemInfo>* reco_items, RecoContext* context) {

}

void UcReco::ParseUcSidInfo(const RecoRequest* request, reco::dm::UcSidInfo* ret_sid_info) {
  // 优先使用 last_sid 触发, 若 last_sid 为空或配额耗尽, 则使用 init_sid
  const RecommendRequest* recommend_request = request->request;
  LOG(INFO) << "parse uc sid info, uid=" << request->user_info->identity().user_id()
            << ", latest_sid=" << recommend_request->latest_sid()
            << ", init_sid=" << recommend_request->init_sid();

  auto sid_dict = DM_GET_DICT(reco::dm::UcSidDict, DynamicDictContainer::kUcSidFile_);

  std::vector<reco::dm::UcSidInfo> sid_info_list;
  std::set<std::string> sid_set;
  if (recommend_request->has_latest_sid() && !recommend_request->latest_sid().empty()) {
    VLOG(1) << "latest id:" << recommend_request->latest_sid();
    auto it = sid_dict->uc_sid_dict_.find(recommend_request->latest_sid());
    if (it != sid_dict->uc_sid_dict_.end()
        && it->second.biz == "信息流-图文") {
      sid_info_list.push_back(it->second);
      sid_set.insert(it->second.sid);
    }
  }
  if (recommend_request->has_init_sid() && !recommend_request->init_sid().empty()
      && sid_set.find(recommend_request->init_sid()) == sid_set.end()) {
    VLOG(1) << "init id:" << recommend_request->init_sid();
    auto it = sid_dict->uc_sid_dict_.find(recommend_request->init_sid());
    if (it != sid_dict->uc_sid_dict_.end()
        && it->second.biz == "信息流-图文") {
      sid_info_list.push_back(it->second);
      sid_set.insert(it->second.sid);
    }
  }

  if (sid_info_list.empty()) {
    VLOG(1) << "sid_info_list is empty";
    return;
  }

  // 统计 quota, 判断是否退场
  std::map<std::string, int> sid_quota;
  StatRecoQuota(sid_info_list, sid_quota);

  for (size_t i = 0; i < sid_info_list.size(); ++i) {
    reco::dm::UcSidInfo sid_info = sid_info_list[i];
    auto it = sid_quota.find(sid_info.sid);
    if (it != sid_quota.end() && it->second > 0) {
      ret_sid_info->sid = sid_info.sid;
      ret_sid_info->biz = sid_info.biz;
      ret_sid_info->category = sid_info.category;
      ret_sid_info->keyword = sid_info.keyword;
      VLOG(1) << "return sid:" << ret_sid_info->ToString() << ", quota=" << it->second;
      break;
    } else {
      VLOG(1) << "uid=" << request->user_info->identity().user_id()
              << " had no quota for sid: " << sid_info.ToString();
    }
  }
}

// 判断 SID 是否有下发 quota
void UcReco::StatRecoQuota(const std::vector<reco::dm::UcSidInfo>& sid_info_list,
                           std::map<std::string, int>& quota_map) {
  // quota 设置
  int default_quota = 3;
  int click_delta = 2;
  int no_click_delta = -1;
  int max_quota = 6;

  // 设置初始 quota
  quota_map.clear();
  for (size_t i = 0; i < sid_info_list.size(); ++i) {
    quota_map[sid_info_list[i].sid] = default_quota;
  }

  // 分析 show 和 click 历史, 统计 quota 消耗情况
  // 分析一周内最近 20 个 pv
  int64 session_time_range = 7 * 24;
  int64 session_pv_range = 20;
  int64 earlist_time = base::GetTimestamp() - session_time_range * base::Time::kMicrosecondsPerHour;
  const reco::user::UserInfo *user_info = reco_request_->user_info;

  std::set<uint64> clicked_items;
  for (int i = user_info->recent_click_size() -1; i >= 0; i--) {
    const reco::user::ViewClickItem &item = user_info->recent_click(i);
    if (item.click_timestamp() < earlist_time) {
      break;
    }
    if (item.view_duration() >= 3) {
      clicked_items.insert(item.item_id());
    }
  }

  // 先定位到show history 的开始位置，然后再逆序遍历， 方便后续处理
  int64 last_show_timestamp = 0;
  int pv = 0;
  int idx;
  for (idx = user_info->shown_history_size() - 1; idx >= 0; idx--) {
    const reco::user::ViewClickItem &item = user_info->shown_history(idx);
    if (!item.has_view_timestamp()) {
      continue;
    }
    if (item.view_timestamp() < earlist_time) {
      break;
    }
    if (item.view_timestamp() != last_show_timestamp) {
      last_show_timestamp = item.view_timestamp();
      pv++;
    }
    if (pv > session_pv_range) {
      break;
    }
  }
  idx++;
  VLOG(1) << "uid=" << user_info->identity().user_id()
          << ", session_start_idx=" << idx << ", show_size=" << user_info->shown_history_size();

  // session stat results
  std::vector<std::pair<int, std::map<std::string, SessionStatMidResult> > > session_results;
  std::vector<std::string> tokens;
  pv = 0;
  last_show_timestamp = 0;
  std::map<std::string, SessionStatMidResult> ret;
  if (idx < 0) idx = 0;
  for (; idx < user_info->shown_history_size(); idx++) {
    const reco::user::ViewClickItem &item = user_info->shown_history(idx);

    // 以 pv 为粒度统计 quota 消耗
    if (!item.has_view_timestamp()) continue;
    if (item.view_timestamp() != last_show_timestamp) {
      last_show_timestamp = item.view_timestamp();
      pv++;

      if (!ret.empty()) {
        session_results.push_back(std::make_pair(pv, ret));
      }
      ret.clear();
    }

    // 仅分析本策略分支下发记录
    VLOG(2) << "show history: uid=" << user_info->identity().user_id()
            << ", item_id=" << item.item_id()
            << ", strategy_branch=" << item.strategy_branch();
    if (!item.has_strategy_branch() || item.strategy_branch() != reco::kUcSidBranch) {
      continue;
    }

    // 解析 reco_ext_info, 获取触发的 SID
    if (!item.has_reco_ext_info()) continue;
    tokens.clear();
    base::SplitString(item.reco_ext_info(), ",", &tokens);
    if (tokens[0].empty()) continue;

    SessionStatMidResult &mid = ret[tokens[0]];
    mid.show_num++;
    if (clicked_items.find(item.item_id()) != clicked_items.end()) {
      mid.click_num++;
    }
  }
  if (!ret.empty()) {
    session_results.push_back(std::make_pair(pv, ret));
  }

  // 计算当前可用 quota
  for (size_t i = 0; i < session_results.size(); i++) {
    std::map<std::string, SessionStatMidResult> &sid_mid_ret = session_results[i].second;
    for (auto it = sid_mid_ret.begin(); it != sid_mid_ret.end(); ++it) {
      std::string sid = it->first;
      SessionStatMidResult &mid = it->second;
      VLOG(1) << "uid=" << user_info->identity().user_id()
              << ", pv=" << session_results[i].first << ", sid=" << sid
              << ", SessionStatMidResult=" << mid.ToString();
      if (quota_map.find(sid) == quota_map.end()) {
        continue;
      }
      if (mid.click_num > 0) {
        quota_map[sid] = std::min(max_quota, quota_map[sid] + click_delta);
      } else if (mid.show_num > 0) {
        quota_map[sid] = std::max(0, quota_map[sid] + no_click_delta);
      } else {
        // TODO  dislike, 间隔很久未下发
      }
    }
  }
}

// 推荐
void UcReco::RecoByUcSid(const reco::dm::UcSidInfo& sid_info,
                         std::vector<ItemInfo>* reco_items,
                         RecoContext* context) {

  // note 使用缓存, 不然有性能风险
  std::string cache_key = "SidRecoItem_" + sid_info.sid;
  int64 now_timestamp = base::GetTimestamp();
  GetCachedItems(cache_key, now_timestamp, reco_items);
  if (!reco_items->empty()) {
    // 命中缓存，去重后直接返回
    VLOG(1) << "match cache, sid=" << sid_info.sid
            << ", size=" << reco_items->size();
    int64 dedup_num = 0;
    UserDedup(reco_request_, reco_items, &dedup_num);
    VLOG(1) << "user dedup: uid=" << reco_request_->user_info->identity().user_id()
            << ", sid=" << sid_info.sid
            << ", left=" << reco_items->size() << ", deduped=" << dedup_num;
    return;
  }

  // 获取候选集
  std::vector<std::string> cache_str_list;
  base::dense_hash_set<uint64> item_dedup;
  item_dedup.set_empty_key(NULL);
  std::vector<ItemInfo> candidate_items;
  
  // 先使用 tag 进行触发
  tag_searcher_config_.return_num = kTopNSize * 2;
  tag_searcher_config_.white_category_dict_l1.clear();
  tag_searcher_config_.white_category_dict_l1.insert(sid_info.category);
  tag_searcher_->Search(reco_request_, sid_info.keyword, tag_searcher_config_, &candidate_items, NULL);
  for (size_t i = 0; i < candidate_items.size(); ++i) {
    if ((int)reco_items->size() >= kTopNSize) break;
    ItemInfo item = candidate_items[i];
    if (!NewsFilter::IsDeduped(item, &item_dedup)) {
      item.strategy_type = reco::kUcSidKw;
      item.strategy_branch = reco::kUcSidBranch;
      reco_items->push_back(item);
      cache_str_list.push_back(base::StringPrintf("%lu,%d", item.item_id, item.strategy_type));
      VLOG(1) << "sid tag item ranked: sid=" << sid_info.sid
              << ", item_id=" << item.item_id << ", ctr=" << item.ctr;
    }
  }

  // 若 tag 触发不足, 则使用 category 触发结果补足
  if ((int)reco_items->size() < kTopNSize) {
    cate_searcher_config_.return_num = kTopNSize * 2;
    cate_searcher_config_.white_category_dict_l1.clear();
    cate_searcher_config_.white_category_dict_l1.insert(sid_info.category);
    candidate_items.clear();
    tag_searcher_->Search(reco_request_, sid_info.category, cate_searcher_config_, &candidate_items, NULL);
    for (size_t i = 0; i < candidate_items.size(); ++i) {
      if ((int)reco_items->size() >= kTopNSize) break;
      ItemInfo item = candidate_items[i];
      if (!NewsFilter::IsDeduped(item, &item_dedup)) {
        item.strategy_type = reco::kUcSidCate;
        item.strategy_branch = reco::kUcSidBranch;
        reco_items->push_back(item);
        cache_str_list.push_back(base::StringPrintf("%lu,%d", item.item_id, item.strategy_type));
        VLOG(1) << "sid cate item ranked: sid=" << sid_info.sid
                << ", item_id=" << item.item_id << ", ctr=" << item.ctr;
      }
    }
  }

  // 写缓存
  LeafCache::SetCachedReco(cache_key, base::JoinStrings(cache_str_list, ","), 600);

  int64 dedup_num = 0;
  UserDedup(reco_request_, reco_items, &dedup_num);
  VLOG(1) << "user dedup: uid=" << reco_request_->user_info->identity().user_id()
          << ", sid=" << sid_info.sid
          << ", left=" << reco_items->size() << ", deduped=" << dedup_num;
}

void UcReco::GetCachedItems(const std::string& cache_key, int64 now_timestamp,
                                  std::vector<ItemInfo>* cached_items) {
  cached_items->clear();
  // visit cache first
  std::string cache_value;
  if (!LeafCache::GetCachedReco(cache_key, &cache_value)) {
    VLOG(1) << cache_key << " cache missed";
    return;
  }
  std::vector<std::string> flds;
  base::SplitString(cache_value, ",", &flds);
  VLOG(1) << cache_key << " return " << flds.size() / 2 << " results";
  for (size_t i = 0; (i + 1) < flds.size(); i += 2) {
    uint64 item_id;
    int strategy_type;
    if (!base::StringToUint64(flds[i], &item_id)) {
      continue;
    }
    if (!base::StringToInt(flds[i+1], &strategy_type)) {
      continue;
    }
    reco::ItemInfo item;
    // 只需要重新判断 valid 即可
    if (!news_index_->GetItemInfoByItemId(item_id, &item, true)
        || !NewsFilter::ItemIsValid(item, now_timestamp)) {
      continue;
    }
    item.strategy_branch = reco::kUcSidBranch;
    if (strategy_type == reco::kUcSidKw) {
      item.strategy_type = reco::kUcSidKw;
    } else if (strategy_type == reco::kUcSidCate) {
      item.strategy_type = reco::kUcSidCate;
    }
    cached_items->push_back(item);
    VLOG(1) << cache_key << " add " << item_id;
  }
}

void UcReco::UserDedup(const RecoRequest* reco_request,
                               std::vector<ItemInfo>* item_list,
                               int64* filtered_num) {
  *filtered_num = 0;
  size_t idx = 0;
  for (size_t i = 0; i < item_list->size(); ++i) {
    uint64 item_id = (*item_list)[i].item_id;
    reco::filter::FilterReason filter_reason;
    if (NewsFilter::IsGeneralFiltered(reco_request, reco_request->shown_dict,
                                      (*item_list)[i], &filter_reason, false)) {
      ++(*filtered_num);
      VLOG(1) << item_id << " user dedup";
      continue;
    }
    if (idx != i) {
      (*item_list)[idx] = (*item_list)[i];
    }
    ++idx;
  }
  item_list->resize(idx);
}

}  // namespace reco_leaf
}
