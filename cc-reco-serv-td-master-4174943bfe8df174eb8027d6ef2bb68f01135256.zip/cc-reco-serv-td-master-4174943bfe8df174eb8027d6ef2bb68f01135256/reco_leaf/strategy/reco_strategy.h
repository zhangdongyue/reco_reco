#pragma once

#include <algorithm>
#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <utility>

#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/container/dense_hash_set.h"

#include "reco/serv/reco_leaf/strategy/common/manual_reco_data.h"
#include "reco/serv/reco_leaf/strategy/common/reco_context.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/common/reco_strategy_branch.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

#include "reco/bizc/proto/filter_rule.pb.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/reco_index/item_info.h"

namespace base {
class PseudoRandom;
}

namespace reco {
namespace leafserver {
class HotReco;
class ManualReco;
class SearchReco;
class JingpinReco;
class PersonalReco;
class InterestReco;
class POIReco;
class SessionReco;
class WeMediaReco;
class ImCardReco;
class SceneCardReco;
class HotCardReco;
class PictureReco;
class GoodsReco;
class ThirdPartyReco;
class CrowdOperReco;
class PornItemReco;
class UcReco;
class LocalBreakingReco;
class GuaranteeDeliverReco;
class PushRelateReco;
class ChannelVideoReco;
class QueryReco;

class UserFeaExtractor;
class CategorySelector;
class RsbSelector;

class HotRanker;
class ProbeStrategyManager;
class ProbeInfo;

class RecoStrategy {
 public:
  explicit RecoStrategy(const reco::NewsIndex* index);
  ~RecoStrategy();

  // 推荐 / 综合频道的推荐策略接口
  bool ComplexChannelRecommend(const reco::user::UserInfo* user_info,
                               RecommendRequest* request,
                               std::vector<ItemInfo>* reco_items,
                               RecoContext* reco_context, thread::Thread* video_thread);

  // 普通垂直频道的推荐策略接口
  bool VerticleChannelRecommend(const reco::user::UserInfo* user_info,
                                RecommendRequest* request,
                                std::vector<ItemInfo>* reco_items,
                                RecoContext* reco_context);

  // 精品垂直频道的推荐策略接口
  bool DoJingpinRecommend(const reco::user::UserInfo* user_info,
                          RecommendRequest* request,
                          std::vector<ItemInfo>* reco_items,
                          RecoContext* reco_context);

  // 订阅频道的推荐策略策略接口
  bool DoSubscriptionReco(const reco::user::UserInfo* user_info,
                          const RecommendRequest* request,
                          std::vector<ItemInfo>* reco_items,
                          std::vector<std::string>* hit_tags,
                          RecoContext* context);

  // 自媒体推荐
  bool WeMediaRecommend(const reco::user::UserInfo* user_info,
                        const bool get_user_error,
                        const WeMediaRecommendRequest *req,
                        WeMediaRecommendResponse *resp);

  // im card
  // just return if deliver im card or not, no sub items.
  void GetImResult(const RecommendRequest *request,
                   const reco::user::UserInfo *user_info,
                   std::vector<ImRecoResult> * im_results);

  // im card reco, return the sub items results.
  bool ImCardRecommend(const reco::user::UserInfo* user_info,
                       const bool get_user_error,
                       const ImCardRecoRequest *request,
                       ImCardRecoResponse *response,
                       CostTrace *cost_trace);

  void MergeImCardResults(const std::vector<ItemInfo> & default_vec,
                          const std::vector<ItemInfo> & humor_vec,
                          const int return_num,
                          std::vector<ItemInfo> * result_vec);

  bool GetItemPOITag(uint64 item_id, POITag *poi_tag);

  // scene card
  bool SceneCardRecommend(const reco::user::UserInfo * user_info,
                          const bool get_user_error,
                          const SceneCardRecoRequest *request,
                          SceneCardRecoResponse *response,
                          CostTrace *cost_trace);
  // hot card
  bool HotCardRecommend(const reco::user::UserInfo * user_info,
                        const bool get_user_error,
                        const HotCardRecommendRequest *request,
                        HotCardRecommendResponse *response,
                        CostTrace *cost_trace);

  // 精品垂直频道的推荐策略接口
  bool DoBeautyRecommend(const reco::user::UserInfo* user_info,
                         RecommendRequest* request,
                         std::vector<ItemInfo>* reco_items,
                         RecoContext* reco_context);

  const UserFeature& GetUserFeature() {
    return user_feas_;
  }

  // 查询给定 item id 是否是探索策略出来的，
  // 如果是，返回 true 并返回相应策略信息；否则返回 false
  bool GetItemProbeInfo(uint64 item_id, ProbeInfo* probe_info) const;

  // 判断一个 item 是否在用户展现历史里
  bool CheckIsShownByItemId(uint64 item_id) const;

  void TryGetAssembleCardInfo(const ItemInfo& item, RecoResult* result) const;

 private:
  void VerticleChannelMerge(std::vector<ItemInfo>* merged_items, RecoDebugger* debugger);

  void ComplexChannelMerge(std::vector<ItemInfo>* merged_items,
                           RecoDebugger* debugger);

  void AdjustByRulesInComplexChannel(std::vector<ItemInfo>* items);

  void AdjustByRulesInVerticleChannel(std::vector<ItemInfo>* items);

  void SpecialRankInVideoChannel(std::vector<ItemInfo>* reco_items);

  void ContinuousVideoLimitRule(std::vector<ItemInfo>* items);
  void SpecialNumLimitRule(std::vector<ItemInfo>* items);
  void VideoNumLimitRule(std::vector<ItemInfo>* items);
  void LowQualityNumLimitRule(std::vector<ItemInfo>* items);
  bool IsLowQualityItem(const ItemInfo& item, reco::ContentAttr* content_attr) const;

  void Prepare(const reco::user::UserInfo* user_info,
               const RecommendRequest* request,
               RecoContext* context);

  bool CanAddToResultSet(const ItemInfo& item, reco::filter::FilterReason*);
  bool QueryRecoCanAddToResultSet(const ItemInfo& item, reco::filter::FilterReason*);

  double GetTopNItemsAvgCtr(const std::vector<ItemInfo> &items, int n);

  void InsertContextRecoToPersonalReco(std::vector<ItemInfo>* merged_items, int total_return_num);

  // 构建用户展示历史
  void BuildUserShownDict(const reco::user::UserInfo* user_info, const RecommendRequest* request);

  // 抽取用户特征
  void BuildUserFeature(const reco::user::UserInfo* user_info, const RecommendRequest* request);

  // 是否在本地频道下发基于 POI 的内容
  bool POIDeliverLocalChannel();

  void EnforceInsertQueue(std::vector<ItemInfo>* reco_items);

  // 保量策略
  bool GuaranteeQuantity(std::vector<ItemInfo>* reco_items);

  // 根据限制条件强制过滤掉本次结果，为了性能考虑，后过滤
  bool ForceSuppressItem(const RecoRequest& reco_request, std::vector<ItemInfo>* items);

  // 用户访问频率的统计
  void AccessFreqCalc(const reco::user::UserInfo& user_info, RecoRequest* reco_request);

  // 随机推荐策略
  bool RandomReco(const RecoRequest& reco_request, std::vector<ItemInfo>* reco_item);
  // 根据刷新类型调整排序
  void AdjustRankByRefreshType(std::vector<ItemInfo>* reco_items);

  // 非视频频道是否可以下发视频
  bool CanDeliverVideo() const;

  void GetComplexQueryNews(RecoRequest* reco_request,
                           std::vector<ItemInfo>* items,
                           int32 max_return);
 private:
  static const uint32 kTopNSize = 200;
  static const std::unordered_set<std::string> force_suppress_keywords_;
  const reco::NewsIndex* news_index_;

  RecoRequest reco_request_;
  UserFeature user_feas_;

  base::dense_hash_set<uint64> item_dedup_;
  base::dense_hash_set<std::string> source_dedup_;
  base::dense_hash_set<uint64> shown_dict_;
  std::vector<std::pair<float, reco::Category> > category_distributes_;
  std::unordered_map<int, int> rsb_itemnum_map_;

  ManualRecoData manual_data_;
  std::vector<ItemInfo> hot_items_;
  std::vector<ItemInfo> query_items_;
  std::vector<ItemInfo> video_items_;
  std::vector<ItemInfo> personal_items_;
  // TODO(jianhuang)
  std::vector<ItemInfo> subscript_items_;
   // session 分析结果
  std::vector<ItemInfo> session_items_;
  // 热门本地新闻
  std::vector<ItemInfo> local_items_;
  std::vector<ItemInfo> poi_items_;
  std::unordered_map<uint64, POITag> item_poi_tags_;

  // 第三方数据预测结果
  std::vector<ItemInfo> trd_prt_items_;

  std::vector<ItemInfo> probe_items_;
  std::vector<ItemInfo> probe_video_items_;
  // exp: 小说更新提醒
  std::vector<ItemInfo> probe_novel_items_;
  std::vector<ItemInfo> crowd_oper_items_;

  std::vector<ItemInfo> uc_sid_items_;
  std::vector<ItemInfo> local_breaking_items_;
  std::vector<ItemInfo> gd_items_;
  std::vector<ItemInfo> porn_items_;

  std::vector<ItemInfo> push_relate_items_;

  InterestReco* interest_reco_;
  PersonalReco* personal_reco_;
  JingpinReco* jingpin_reco_;
  ManualReco* manual_reco_;
  SearchReco* search_reco_;
  HotReco* hot_reco_;
  QueryReco* query_reco_;
  GoodsReco* goods_reco_;
  PictureReco* pic_reco_;
  HotRanker* hot_ranker_;
  WeMediaReco *wemedia_reco_;
  ImCardReco *imcard_reco_;
  SceneCardReco *scene_reco_;
  HotCardReco *hot_card_reco_;
  SessionReco* session_reco_;
  POIReco *poi_reco_;
  ThirdPartyReco *third_party_reco_;
  CrowdOperReco* crowd_oper_reco_;
  PornItemReco* porn_item_reco_;
  UcReco* uc_sid_reco_;
  LocalBreakingReco* local_breaking_reco_;
  GuaranteeDeliverReco* gd_reco_;
  PushRelateReco* push_relate_reco_;
  ChannelVideoReco* channel_video_reco_;

  UserFeaExtractor* user_fea_extractor_;
  CategorySelector* category_selector_;
  RsbSelector* rsb_selector_;
  base::PseudoRandom* random_;

  ProbeStrategyManager* probe_strategy_manager_;
  CandidatesExtractor* candidate_extractor_;

 private:
  // 场景化推荐数据都放在这里
  struct ContextRecoInsertInfo {
    void Clear() {
      context_items = NULL;
      context_index = 0;
      context_insert_num = 0;
    }
    const ItemInfo* GetNext() {
      return (context_index >= (int)context_items->size()) ? NULL : &(context_items->at(context_index++));
    }

    const std::vector<ItemInfo> *context_items;
    int context_index;
    int context_insert_num;
  };

  enum ContextRecoType {
    kVideoContextReco = 0,
    kPOIContextReco = 1,
    kGuaranteeContextReco = 2,
  };

  static const int kContextRecoNum = 3;
  ContextRecoInsertInfo context_insert_infos_[kContextRecoNum];
  std::unordered_map<int, ContextRecoType> context_insert_pos_;
};
}
}
