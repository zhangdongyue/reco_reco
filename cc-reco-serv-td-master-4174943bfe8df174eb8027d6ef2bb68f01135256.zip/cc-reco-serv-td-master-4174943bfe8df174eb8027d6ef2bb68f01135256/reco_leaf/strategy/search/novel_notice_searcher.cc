#include "reco/serv/reco_leaf/strategy/search/novel_notice_searcher.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/proto/common.pb.h"
#include "nlp/common/nlp_util.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/common/topn.h"
#include "nlp/common/nlp_util.h"
#include "serving_base/utility/timer.h"
#include "reco/serv/dict_server/api/dict_server_api.h"

namespace reco {
namespace leafserver {

NovelNoticeSearcher::NovelNoticeSearcher(const reco::NewsIndex* news_index) : BaseSearcher(news_index, "NvS") {
}

NovelNoticeSearcher::~NovelNoticeSearcher() {
}

bool NovelNoticeSearcher::Search(const RecoRequest* reco_request,
                         const std::string& query,
                         const Config& config,
                         std::vector<ItemInfo>* item_list,
                         DebugInfo* debug_info) {
  item_list->clear();
  if (query.empty()) {
    VLOG(1) << "novel list is empty";
    return false;
  }

  query_ = query;
  config_ = &config;
  debug_info_.Reset();
  now_timestamp_ = base::GetTimestamp();
  reco_request_ = reco_request;
  user_info_ = reco_request->user_info;
  const uint64 user_id = reco_request->user_info->identity().user_id();

  serving_base::Timer timer;
  timer.Start();

  std::string cache_key;
  if (config_->use_cache) {
    cache_key = GetSearchCacheKey(query_);
    std::string cache_value;
    if (LeafCache::GetCachedReco(cache_key, &cache_value)) {
      // 命中缓存, 直接解析返回
      // 缓存结果为空也直接返回, 说明用户无小说列表, 或用户关注的小说暂无更新
      if (cache_value.empty()) {
        VLOG(1) << "empyt cache results, user_id=" << user_id;
        return true;
      }

      std::vector<std::string> flds;
      base::SplitString(cache_value, ",", &flds);
      VLOG(1) << cache_key << " return " << flds.size() << " results";
      for (size_t i = 0; i < flds.size(); ++i) {
        uint64 item_id;
        if (!base::StringToUint64(flds[i], &item_id)) {
          continue;
        }
        reco::ItemInfo item;
        // 只需要重新判断 valid 即可
        if (!news_index_->GetItemInfoByItemId(item_id, &item, true)
            || !NewsFilter::ItemIsValid(item, now_timestamp_)) {
          continue;
        }

        item_list->push_back(item);
        VLOG(1) << cache_key << " add " << item_id;
      }

      // 去重
      UserDedup(reco_request_, item_list, &(debug_info_.user_dedup));
      if ((int)item_list->size() >= config_->return_num) {
        item_list->resize(config_->return_num);
      }

       VLOG(1) << query_ << " use cache result, size: " << item_list->size();
       VLOG(1) << "uid=" << user_id << ", matched cache, search cost time: " << timer.Stop();
       return true;
    }
  }
  VLOG(1) << query_ << " do search";

  // 开始真正进行一次检索
  if (!Retrieve(item_list)) {
    VLOG(1) << "retrieve failed for: " << query_;
    return false;
  }
  VLOG(1) << "uid=" << user_id << ", Ir cost time: " << timer.Stop();

  debug_info_.ir_result = item_list->size();

  ItemDedup(item_list, &(debug_info_.item_dedup));
  debug_info_.fr_result = item_list->size();

  UserDedup(reco_request_, item_list, &(debug_info_.user_dedup));
  if (config_->use_cache) {
    std::vector<std::string> cache_str_list;
    for (size_t i = 0; i < item_list->size(); ++i) {
      cache_str_list.push_back(base::Uint64ToString((*item_list)[i].item_id));
    }
    LeafCache::SetCachedReco(cache_key, base::JoinStrings(cache_str_list, ","));
  }

  if ((int)item_list->size() > config_->return_num) {
    item_list->resize(config_->return_num);
  }

  if (debug_info != NULL) {
    *debug_info = debug_info_;
  }

  VLOG(1) << base::StringPrintf("query [%s], result size [%lu], debug info [%s]",
                                  query_.c_str(), item_list->size(),
                                  debug_info_.ToString().c_str());

  return true;
}

// 从 dict server 获取用户追小说信息
void NovelNoticeSearcher::GetFollowingNovleList(const reco::user::UserInfo* user_info,
                                                std::vector<std::string>* novel_id_list) {
  static int expire_hours = 24 * 7;
  static int max_novel_num = 20;

  novel_id_list->clear();
  serving_base::Timer timer;
  timer.Start();

  const uint64 user_id = user_info_->identity().user_id();
  std::string user_novel_info;
  std::string key = base::StringPrintf("%s-%lu", user_info_->identity().app_token().c_str(), user_id);
  bool read_ret =
      reco::dictserver::DictServerAPIIns::instance().GetData("UserNovel", key, "0", &user_novel_info);
  VLOG(1) << "uid=" << user_id << ", dict server cost time: " << timer.Stop();

  if (!read_ret || user_novel_info.empty()) {
    VLOG(1) << "failed to get user novel info from dict server: key=" << key;
    return;
  }
  VLOG(1) << "succ to get user novel info from dict server: key=" << key;
  reco::user::FollowNovelInfo follow_novel_info;
  if (!follow_novel_info.ParseFromString(user_novel_info)) {
    LOG(WARNING) << "failed to parse FollowNovelInfo proto";
    return;
  }
  VLOG(1) << "uid=" << user_id
          << ", follow novel info:" << nlp::util::NormalizeLine(follow_novel_info.Utf8DebugString());

  // 剔除不置信的数据并控制小说条数
  timer.Start();
  int64 now_timestamp = base::GetTimestamp();
  int64 earliest_timestamp = now_timestamp - expire_hours * base::Time::kMicrosecondsPerHour;
  for (int i = 0; i < follow_novel_info.novel_list_size(); ++i) {
    if ((int)novel_id_list->size() >= max_novel_num) break;
    reco::user::NovelInfo novel = follow_novel_info.novel_list(i);
    // 注意 proto 中读到的是 unix 时间戳
    if (novel.last_update_time() * base::Time::kMicrosecondsPerSecond >= earliest_timestamp
        && !novel.novel_id().empty()) {
      novel_id_list->push_back(novel.novel_id());
    }
  }
}

bool NovelNoticeSearcher::Retrieve(std::vector<ItemInfo>* ir_results) {
  static const int expire_hours = 48; // 小说更新消息有效期
  static const uint64 max_ir_num = 10;

  // 获取用户在追的小说列表
  std::vector<std::string> novel_id_vec;
  std::set<std::string> novel_id_set;
  GetFollowingNovleList(user_info_, &novel_id_vec);
  for (int i = 0; i < (int)novel_id_vec.size(); ++i) {
    novel_id_set.insert(novel_id_vec[i]);
  }

  // 获取每部小说的更新消息
  std::map<std::string, ItemInfo> notice_map; // 每篇小说的最新更新消息
  int64 now_timestamp = base::GetTimestamp();
  int64 earliest_timestamp = now_timestamp - expire_hours * base::Time::kMicrosecondsPerHour;
  std::vector<int32> doc_id_list;

  for (auto iter = novel_id_set.begin(); iter != novel_id_set.end(); ++iter) {
    const std::string novel_id = *iter;
    doc_id_list.clear();
    news_index_->GetDocsByNovelId(novel_id, &doc_id_list, max_ir_num);
    VLOG(1) << "novel_id=" << novel_id << ", doc_num=" << doc_id_list.size();

    for (int i = 0; i < (int)doc_id_list.size(); ++i) {
      int32 doc_id = doc_id_list[i];
      ItemInfo item_info;
      if (!news_index_->GetItemInfoByDocId(doc_id, &item_info, false)) {
        VLOG(2) << "failed to get item info: doc_id=" << doc_id;
        continue;
      }
      /*
      std::string title;
      news_index_->GetItemTitleByItemId(item_info.item_id, &title);
      VLOG(2) << "retrieve novel notice: item_id=" << item_info.item_id
              << ", title=" << title
              << ", createTime=" << news_index_->GetCreateTimestampByItemId(item_info.item_id);
      */

      // 判断更新时间是否过期
      //int64 doc_timestamp = news_index_->GetCreateTimestampByDocId(doc_id);
      int64 doc_timestamp = news_index_->GetNovelUpdateTimestampByDocId(doc_id);
      if (doc_timestamp < earliest_timestamp) {
        VLOG(2) << "novel notic filtered by timestamp: novel_timestamp=" << doc_timestamp
                << ", earliest_timestamp=" << earliest_timestamp;
        continue;
      }

      if (notice_map.find(novel_id) == notice_map.end()
          || doc_timestamp > notice_map[novel_id].create_timestamp) {
        notice_map[novel_id] = item_info;
      } else {
        continue;
      }
    }
  }

  ir_results->clear();
  for (auto it = notice_map.begin(); it !=  notice_map.end(); ++it) {
    const ItemInfo item_info = it->second;
    if (!IrCommonFilter(item_info, now_timestamp_)) {
      VLOG(2) << "filtered by IrCommonFilter: doc_id=" << item_info.doc_id
              << ", item_id=" << item_info.item_id;
      continue;
    }

    ir_results->push_back(item_info);
    VLOG(1) << " ir retrieved " << item_info.item_id;
  }

  // 不同小说的更新提醒消息统一按更新时间降序排列, 优先推最新的更新消息
  std::sort(ir_results->begin(), ir_results->end(), NovelNoticeCompare);

  return true;
}

bool NovelNoticeCompare(const ItemInfo& item1, const ItemInfo& item2) {
  return item1.create_timestamp > item2.create_timestamp;
}

}  // namespace leafserver
}  // namespace reco
