#pragma once
#include <vector>
#include <utility>
#include <string>
#include "base/common/base.h"

namespace reco {
namespace leafserver {

// 传入 token 序列 和 window 大小(包含 term 的 个数)
// 输出每个 unigram term 和 bigram term 在其出现最多的 window 中的出现次数
//
// 注意 window_size 必须大于 0
void GetTermMatchedNum(const std::vector<std::string> tokens,
                       int window_size,
                       std::vector<int> *unigram_result,
                       std::vector<int> *bigram_result);

// 传入 query 所有 terms 和一段文本的 tokens
// 计算 query 的 bigram term 和 skipped bigram term 在文本中命中了多少次
// 这个两个值作为计算相关性的两个特征
// 计算方法:
// 1. 对于 query 中相邻的两个 term, 如果它们组成的 bigram term 在文本中出现, bigram_hits 加 1
//    否则, 如果他们组成的 skipped bigram 在文本中出现, skipped_bigram_hits 加 1
//    注: 如过两对相邻的 term 相同, 这里只计算一次
// 2. 对于 query 中相隔的两个 term, 如果他们组成的 skipped bigram 在文本中出现, skipped_bigram_hits 加 1
//    注: 如果两对相隔的 term 相同, 这里只计算一次
void GetQueryTermMatchedNum(const std::vector<std::string> query_terms,
                            const std::vector<std::string> tokens,
                            int *bigram_hits, int *skipped_bigram_hits);

// 同上, 只不过这里不用 String 而是使用 Id
void GetQueryTermMatchedNum(const std::vector<int64> query_terms,
                            const std::vector<int64> tokens,
                            int *bigram_hits, int *skipped_bigram_hits);

void FindMaxCommonSequence(const std::vector<int64> &query,
                           const std::vector<int64> &window,
                           std::vector<int> *query_term_id,
                           std::vector<int> *output);
}  // namespace searchserver
}  // namespace reco
