#include "reco/serv/reco_leaf/strategy/search/title_searcher.h"

#include <vector>
#include <string>
#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/bizc/proto/reco_nlp_server.pb.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/proto/common.pb.h"
#include "nlp/common/nlp_util.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/topn.h"
#include "reco/serv/reco_leaf/frame/connection_manager.h"
#include "nlp/common/nlp_util.h"
#include "ads_index/api/public.h"
#include "query/dnf/dnf_util.h"
#include "query/dnf/dnf_retrieval.h"
#include "query/parser_util/parser_util.h"
#include "extend/multi_strings/multi_pattern_matcher.h"

namespace reco {
namespace leafserver {

TitleSearcher::TitleSearcher(const reco::NewsIndex* news_index) : BaseSearcher(news_index, "TitS") {
  dnf_retrieval_ = new queries::DNFRetrieval(index_);
  nlp_service_ = new reco::nlpserver::NLPService::Stub(ConnectionManagerIns::instance().GetNlpServerGroup());
}

TitleSearcher::~TitleSearcher() {
  delete dnf_retrieval_;
  delete nlp_service_;
}

bool TitleSearcher::Search(const RecoRequest* reco_request,
                          const std::string& orig_query,
                          const Config& config,
                          std::vector<ItemInfo>* item_list,
                          DebugInfo* debug_info) {
  item_list->clear();
  query_ = nlp::util::NormalizeLine(orig_query);
  if (query_.empty()) {
    VLOG(1) << "normalized query is empty";
    return false;
  }

  config_ = &config;
  debug_info_.Reset();
  now_timestamp_ = base::GetTimestamp();
  reco_request_ = reco_request;
  need_user_dedup_ = false;

  std::string cache_key;
  if (config_->use_cache) {
    cache_key = GetSearchCacheKey(query_);
    GetCachedItems(cache_key, now_timestamp_, item_list);
    if (!item_list->empty()) {  // 从缓存中取到数据了
      UserDedup(reco_request_, item_list, &(debug_info_.user_dedup));
      if ((int)item_list->size() >= config_->return_num) {
        VLOG(1) << query_ << " use cache result, size: " << item_list->size();
        item_list->resize(config_->return_num);
        return true;
      } else {
        // 这个用户可能看过很多相关的内容，需要在检索过程中先做排重，否则可能结果不足
        need_user_dedup_ = true;
        item_list->clear();
      }
    } else {
      need_user_dedup_ = false;
      item_list->clear();
    }
  }
  VLOG(1) << query_ << " do search, need user dedup " << need_user_dedup_;

  // 开始真正进行一次检索
  queries::QueryTree dnf_tree;
  if (!ParseQuery(&dnf_tree)) {
    VLOG(1) << "parse query failed for: " << query_;
    return false;
  }

  std::vector<std::pair<queries::ARCollector::Result, ItemInfo>> ir_results;
  if (!Retrieve(dnf_tree, &ir_results)) {
    VLOG(1) << "retrieve failed for: " << query_;
    return false;
  }
  debug_info_.ir_result = ir_results.size();

  Rank(dnf_tree, ir_results, item_list);
  ItemDedup(item_list, &(debug_info_.item_dedup));
  debug_info_.fr_result = item_list->size();

  // need user dedup 时结果在触发阶段是预先做用户去重的
  if (config_->use_cache && !need_user_dedup_) {
    std::vector<std::string> cache_str_list;
    for (size_t i = 0; i < item_list->size(); ++i) {
      cache_str_list.push_back(base::Uint64ToString((*item_list)[i].item_id));
    }
    LeafCache::SetCachedReco(cache_key, base::JoinStrings(cache_str_list, ","));
  }

  UserDedup(reco_request_, item_list, &(debug_info_.user_dedup));
  if ((int)item_list->size() > config_->return_num) {
    item_list->resize(config_->return_num);
  }

  if (debug_info != NULL) {
    *debug_info = debug_info_;
  }

  VLOG(1) << base::StringPrintf("query [%s], result size [%lu], debug info [%s]",
                                  query_.c_str(), item_list->size(),
                                  debug_info_.ToString().c_str());

  return true;
}

bool TitleSearcher::ParseQuery(queries::QueryTree* dnf_tree) {
  reco::nlpserver::ParseQueryRequest nlp_request;
  reco::nlpserver::ParseQueryResponse nlp_response;
  nlp_request.set_query(query_);
  net::rpc::RpcClientController controller;
  nlp_service_->ParseQuery(&controller, &nlp_request, &nlp_response, NULL);
  controller.Wait();
  if (controller.status() != stumy::RpcController::kOk || !nlp_response.success()) {
    LOG(WARNING) << "IFlow query analyze failed." << controller.error_text();
    return false;
  }

  queries::QueryTree query_tree;
  if (nlp_response.tree().empty() || !query_tree.FromString(nlp_response.tree())) {
    LOG(WARNING) << "query empty or parse query tree failed." << query_;
    return false;
  }

  if (query_tree.root() != NULL) {
    queries::QueryTreeNode* dnf_root = queries::BuildDNF(query_tree.root(), 40);
    if (NULL == dnf_root) {
      std::string dump;
      query_tree.ToString(&dump);
      LOG(WARNING) << "failed to convert dnf: " << dump;
      return false;
    }
    dnf_tree->set_root(dnf_root);
  } else {
    return false;
  }

  return true;
}

bool TitleSearcher::Retrieve(const queries::QueryTree& dnf_tree,
                            std::vector<std::pair<queries::ARCollector::Result, ItemInfo>>* ir_results) {

  ir_results->clear();

  queries::ARCollector ar_collector;
  ar_collector.Initialize(config_->ir_num);

  queries::DNFRetrieval::RetrievalConfig config;
  config.ar_collector = &ar_collector;

  if (!dnf_retrieval_->ParseQuery(dnf_tree.root(), &config)) {
    LOG(ERROR) << "parse tree failed";
    return false;
  }

  dnf_retrieval_->Retrieval();

  std::vector<queries::ARCollector::Result> ar_results;
  ar_collector.GetFRResults(&ar_results);

  ir_results->reserve(ar_results.size());
  for (int i = 0; i < (int)ar_results.size(); ++i) {
    int doc_id = ar_results[i].doc_local_id;
    reco::ItemInfo item_info;
    if (!news_index_->GetItemInfoByDocId(doc_id, &item_info, false)) {
      continue;
    }
    if (!IrCommonFilter(item_info, now_timestamp_)) {
      continue;
    }

    uint64 item_id = item_info.item_id;
    reco::filter::FilterReason filter_reason;
    if (need_user_dedup_
        && NewsFilter::IsGeneralFiltered(reco_request_, reco_request_->shown_dict,
                                        item_info, &filter_reason, false)) {
      ++debug_info_.ir_user_dedup_filtered;
      VLOG(1) << item_id << " ir user dedup filtered";
      continue;
    }

    ir_results->push_back(std::make_pair(ar_results[i], item_info));
    VLOG(1) << item_id << " ir retrieved";
  }
  return true;
}

void TitleSearcher::Rank(const queries::QueryTree &ranking_tree,    // dnf tree
                        const std::vector<std::pair<queries::ARCollector::Result, ItemInfo>>& fr_candidates,
                        std::vector<ItemInfo>* ranked_results) {
  query_infos_.clear();
  for (auto node = ranking_tree.root()->first_child();
       node != NULL; node = node->next_sibling()) {
    QueryInfo query_info;
    query_infos_.push_back(query_info);
    query_infos_.back().FillQueryInfo(node, index_);
  }

  if (query_infos_.empty()) return;
  int orig_query_show_len = query_infos_[0].total_show_len;

  TopN<int> topn(config_->fr_num * 1.2);

  // NOTE: ir 的结果，文档时间较新的会排在前面，而 topn 插入时，
  // 如果每个文档的分都一样，会把先插入的剔除掉，因此这里要对 ir 的结果从后往前计算 topn
  DocInfo doc_info;
  for (int i = (int)fr_candidates.size() - 1; i >=0; --i) {
    int doc_id = fr_candidates[i].first.doc_local_id;
    const reco::ItemInfo& item_info = fr_candidates[i].second;
    uint64 item_id = item_info.item_id;

    if (!FrCommonFilter(item_info)) {
      continue;
    }

    debug_info_.max_ctr = std::max(item_info.ctr, debug_info_.max_ctr);
    if (item_info.ctr < config_->ctr_low_threshold
        || item_info.show_num < config_->show_threshold) {
      ++debug_info_.fr_ctr_filtered;
      VLOG(1) << item_id << " fr ctr filtered";
      continue;
    }
    // 计算相关性
    doc_info.Clear();
    doc_info.FillDocInfo(doc_id, index_);

    float max_score = 0;
    int best_query_id = fr_candidates[i].first.best_query;
    for (size_t j = 0; j < query_infos_.size(); ++j) {
      if (best_query_id != -1 && best_query_id >= 0 && best_query_id < (int)query_infos_.size()) {
        // best query 合法， 则只计算原始query和best query
        if (j != 0 && (int)j != best_query_id) {
          continue;
        }
      }
      bool title_all_hit;
      float score = CalcFinalRelScore(item_id, config_->title_rel_coef, config_->keyword_rel_coef,
                                      query_infos_[j], doc_info, &title_all_hit);

      int rewrite_query_show_len = query_infos_[j].total_show_len;
      if (j > 0) {
        double rws = queries::RTreeGetRewriteProb(ranking_tree.root(), j);
        float len_discount = std::min(1.0f, ((float)rewrite_query_show_len/(float)orig_query_show_len));
        rws *= len_discount;
        score *= rws;
        VLOG(1) << rewrite_query_show_len << ", " << orig_query_show_len
                << ", rewrited: " << rws << ", " << score;
      }
      if (score > max_score) {
        max_score = score;
      }
    }

    debug_info_.max_rel = std::max(max_score, debug_info_.max_rel);
    VLOG(1) << "query=" << query_  << ", item_id=" << item_id
            << ", title=" << doc_info.title_info.literal
            << ", rel=" << max_score << ", ctr=" << item_info.ctr;

    if (max_score < config_->rel_low_threshold || max_score > config_->rel_high_threshold) {
      // 相关性过低或过高，直接 pass
      ++debug_info_.fr_rel_filtered;
      VLOG(1) << item_id << " fr rel filtered";
      continue;
    } else if (item_info.ctr < config_->ctr_low_threshold) {
      // 相关性一般，要求 ctr 高
      ++debug_info_.fr_ctr_filtered;
      VLOG(1) << item_id << " fr ctr filtered";
      continue;
    } else {
      // 相关性和 ctr 均满足要求的 item
    }

    topn.add(i, max_score);
    VLOG(1) << item_id << " topn added, "
            << base::StringPrintf("ctr[%.3f] rel[%.3f]", item_info.ctr, max_score);
  }

  std::vector<std::pair<int, double>> candidates;
  topn.get_top_n(&candidates);

  ranked_results->clear();
  for (int i = 0; i < (int)candidates.size(); ++i) {
    int idx = candidates[i].first;
    ranked_results->push_back(fr_candidates[idx].second);
  }

  std::sort(ranked_results->begin(), ranked_results->end(), std::greater<ItemInfo>());
}

}  // namespace leafserver
}  // namespace reco
