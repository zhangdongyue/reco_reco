#include "reco/serv/reco_leaf/strategy/search/searcher_define.h"

#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <functional>

#include "base/common/gflags.h"
#include "base/common/counters.h"
#include "base/hash_function/term.h"
#include "base/hash_function/url.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/scoped_ptr.h"
#include "base/strings/utf_char_iterator.h"
#include "base/math/discrete.h"
#include "web/url/gurl.h"
#include "web/url/url.h"
#include "reco/serv/reco_leaf/strategy/search/match_function.h"
#include "query/tree/query_tree.h"
// #include "query/parser_util/parser_util.h"
#include "query/parser_util/parser_attr.h"
#include "ads_index/api/public.h"
// #include "reco/bizc/reco_index/news_index.h"
// #include "reco/serv/reco_leaf/strategy/common/topn.h"
#include "reco/bizc/sim_info/sim_info.h"

namespace reco {
namespace leafserver {

void QueryInfo::FillQueryInfo(const queries::QueryTreeNode* dnf_node,
                              const adsindexing::Index* index) {
  Clear();

  std::stack<const queries::QueryTreeNode*> traverse;
  traverse.push(dnf_node);

  auto &term_elems = this->term_elems;
  auto &term_dict = this->term_dict;
  auto &total_show_len = this->total_show_len;
  auto &total_weight = this->total_weight;
  auto &literal = this->literal;

  int show_offset = 0;
  while (!traverse.empty()) {
    const queries::QueryTreeNode* node = traverse.top();
    traverse.pop();

    if (node->type() == queries::QueryTreeNode::kLeaf) {
      // 剩下的节点, 有可能是 IsOrig 或 IsSubs/IsCorrect, 都作为 query, 计算打分
      // 遇到叶子节点,记录相关信息
      term_elems.push_back(TermElem());
      TermElem& elem = term_elems.back();

      elem.literal = node->literal();
      literal += elem.literal;
      elem.id = index->IDFromTerm(elem.literal.data(), elem.literal.size(),
                                   adsindexing::TermType::kUnigramTerm);

      float value = 0.0;
      if (node->GetAttrF(queries::core_attr::kGlobalImp, &value)) {
        elem.weight = value;
      } else {
        elem.weight = 0;
      }
      total_weight += elem.weight;

      int show_len = 0;
      if (base::GetUTF8TextWidth(elem.literal, &show_len)) {
        elem.show_len = show_len;
      } else {
        elem.show_len = 0;
      }
      total_show_len += elem.show_len;

      elem.show_offset = show_offset;
      show_offset += show_len;

      // 对 term 做去重
      // 仅对合法的 term 处理 (elem id > = 0)
      if (elem.id >= 0) {
        int cur_term_idx = term_elems.size()-1;
        if (elem.id >= 0 && term_dict.find(elem.id) == term_dict.end()) {
          term_dict[elem.id] = cur_term_idx;
        } else {  // 遇到重复的 term, 判断哪个更重要
          int prev_term_idx = term_dict[elem.id];
          DCHECK_LT(prev_term_idx, (int)term_elems.size());
          // 当前的 term 的 importance 比之前的大
          if (elem.weight > term_elems[prev_term_idx].weight) {
            term_dict[elem.id] = cur_term_idx;
          }
        }
      }
    }

    // 继续遍历
    for (const queries::QueryTreeNode* child = node->last_child();
         child != NULL;
         child = child->prev_sibling()) {
      traverse.push(child);
    }
  }
}

bool DocInfo::FillDocInfo(int doc_id, const adsindexing::Index* index) {
  Clear();

  scoped_ptr<adsindexing::HitIterator> hit_iterator(index->NewHitIterator(doc_id));
  if (hit_iterator.get() == NULL) {
    return false;
  }

  this->doc_id = doc_id;
  this->title_info.area_type = AreaInfo::kTitleArea;
  this->keyword_info.area_type = AreaInfo::kKeywordArea;
  this->source_info.area_type = AreaInfo::kSourceArea;
  this->category_info.area_type = AreaInfo::kCategoryArea;
  this->content_info.area_type = AreaInfo::kContentArea;

  const std::vector<adsindexing::HitIterator::DocArea>& areas = hit_iterator->GetAllDocArea();
  for (size_t area_id = 0; area_id < areas.size(); ++area_id) {
    AreaInfo* area_info = NULL;
    if (areas[area_id].type == adsindexing::kTitleArea) {
      area_info = &(this->title_info);
    } else if (areas[area_id].type == adsindexing::kBidWordArea) {
      area_info = &(this->keyword_info);
    } else if (areas[area_id].type == adsindexing::kContentArea) {
      area_info = &(this->content_info);
    } else if (areas[area_id].type == adsindexing::kAnchorArea) {
      area_info = &(this->source_info);
    } else if (areas[area_id].type == adsindexing::kQueryArea) {
      area_info = &(this->category_info);
    }
    if (area_info == NULL) continue;

    auto& term_elems = area_info->term_elems;
    auto& term_dict = area_info->term_dict;
    float& total_weight = area_info->total_weight;
    int&  total_show_len = area_info->total_show_len;
    std::string& literal = area_info->literal;

    int show_offset = 0;
    for (int pos = areas[area_id].begin; pos < areas[area_id].end; ++pos) {
      if (!hit_iterator->MoveToPosition(pos)) {
        LOG(ERROR) << "move error";
        continue;
      }

      int64 term_id = hit_iterator->UnigramId();
      term_elems.push_back(TermElem(term_id));
      TermElem& elem = term_elems.back();

      adsindexing::HitIterator::TermDocFeature feature;
      if (!hit_iterator->GetTermDocFeature(&feature)) {
        elem.weight = 0.01;
        elem.show_len = 2;
      } else {
        reco::sim_item::SimTermInfo term_info;
        reco::sim_item::SimTermInfo::UnPackSimTermInfo(feature.data, feature.size, &term_info);
        elem.weight = term_info.imp;
        elem.show_len = term_info.show_len;
      }
      elem.show_offset = show_offset;
      show_offset += elem.show_len;
      total_weight += elem.weight;
      total_show_len += elem.show_len;

      // NOTE: for debug
      index->TermFromID(elem.id, adsindexing::TermType::kUnigramTerm, &(elem.literal));
      literal += elem.literal;

      int cur_term_idx = term_elems.size()-1;
      if (term_dict.find(term_id) == term_dict.end()) {
        term_dict[term_id] = cur_term_idx;
      } else {  // 遇到重复的 term, 判断哪个更重要
        int prev_term_idx = term_dict[term_id];
        DCHECK_LT(prev_term_idx, (int)term_elems.size());
        // 当前的 term 的 importance 比之前的大
        if (elem.weight > term_elems[prev_term_idx].weight) {
          term_dict[term_id] = cur_term_idx;
        }
      }
    }
  }
  return true;
}

void RelevantFeature::ExtractFeature(const QueryInfo& query_info, const AreaInfo& area_info) {
  this->Clear();

  this->query_term_num = query_info.term_elems.size();
  this->query_show_len = query_info.total_show_len;
  this->area_show_len = area_info.total_show_len;
  this->query_weight = query_info.total_weight;
  this->area_weight = area_info.total_weight;

  int& match_show_len = this->match_show_len;

  int& match_query_offset = this->match_query_offset;
  float& match_query_weight = this->match_query_weight;

  int& match_area_offset = this->match_area_offset;
  float& match_area_weight = this->match_area_weight;

  for (size_t i = 0; i < query_info.term_elems.size(); ++i) {
    const TermElem& query_elem = query_info.term_elems[i];
    if (query_elem.id < 0) continue;

    auto it = area_info.term_dict.find(query_elem.id);
    if (it == area_info.term_dict.end()) continue;

    DCHECK(it->second >= 0 && it->second < (int)area_info.term_elems.size());
    const TermElem& area_elem = area_info.term_elems[it->second];
    match_show_len += query_elem.show_len;
    match_query_weight += query_elem.weight;
    match_area_weight += area_elem.weight;

    if (query_elem.show_offset != kTrivialValue && query_elem.show_offset < match_query_offset) {
      match_query_offset = query_elem.show_offset;
    }
    if (area_elem.show_offset != kTrivialValue && area_elem.show_offset < match_area_offset) {
      match_area_offset = area_elem.show_offset;
    }
  }

  int& lcs_hit_show_len = this->lcs_hit_show_len;

  int& lcs_query_window_show_len = this->lcs_query_window_show_len;
  float& lcs_query_window_weight = this->lcs_query_window_weight;
  float& lcs_query_hit_weight = this->lcs_query_hit_weight;

  int& lcs_area_window_show_len = this->lcs_area_window_show_len;
  float& lcs_area_window_weight = this->lcs_area_window_weight;
  float& lcs_area_hit_weight = this->lcs_area_hit_weight;

  std::vector<int> query_window;
  std::vector<int> area_window;

  std::vector<int64> query_term_ids(query_info.term_elems.size());
  for (size_t i = 0; i < query_term_ids.size(); ++i) {
    query_term_ids[i] = query_info.term_elems[i].id;
  }
  std::vector<int64> area_term_ids(area_info.term_elems.size());
  for (size_t i = 0; i < area_term_ids.size(); ++i) {
    area_term_ids[i] = area_info.term_elems[i].id;
  }

  // 最长公共子串相关
  // winow 保存的是 section 中匹配 query 的 term 的在 section 的位置
  FindMaxCommonSequence(query_term_ids, area_term_ids,
                        &query_window, &area_window);


  if (!area_window.empty() && !query_window.empty()) {
    for (size_t i = 1; i < query_window.size(); ++i) {
      int begin = query_window[i-1];
      int end = query_window[i];
      DCHECK_LT(begin, end);

      lcs_hit_show_len += query_info.term_elems[begin].show_len;

      lcs_query_hit_weight += query_info.term_elems[begin].weight;

      lcs_query_window_show_len += query_info.term_elems[begin].show_len;
      lcs_query_window_weight += query_info.term_elems[begin].weight;

      for (int term_idx = begin + 1; term_idx < end; ++term_idx) {
        lcs_query_window_show_len += query_info.term_elems[term_idx].show_len;
        lcs_query_window_weight += query_info.term_elems[term_idx].weight;
      }
    }
    lcs_hit_show_len += query_info.term_elems[query_window.back()].show_len;
    lcs_query_hit_weight += query_info.term_elems[query_window.back()].weight;
    lcs_query_window_show_len += query_info.term_elems[query_window.back()].show_len;
    lcs_query_window_weight += query_info.term_elems[query_window.back()].weight;

    for (size_t i = 1; i < area_window.size(); ++i) {
      int begin = area_window[i-1];
      int end = area_window[i];
      DCHECK_LT(begin, end);

      lcs_area_hit_weight += area_info.term_elems[begin].weight;

      lcs_area_window_show_len += area_info.term_elems[begin].show_len;
      lcs_area_window_weight += area_info.term_elems[begin].weight;

      for (int term_idx = begin + 1; term_idx < end; ++term_idx) {
        lcs_area_window_show_len += area_info.term_elems[term_idx].show_len;
        lcs_area_window_weight += area_info.term_elems[term_idx].weight;
      }
    }
    lcs_area_hit_weight += area_info.term_elems[area_window.back()].weight;
    lcs_area_window_show_len += area_info.term_elems[area_window.back()].show_len;
    lcs_area_window_weight += area_info.term_elems[area_window.back()].weight;
  }

  // Bigram/ Skip Bigram 匹配相关特征
  int& bigram_hits = this->bigram_hits;
  int& skip_bigram_hits = this->skip_bigram_hits;
  GetQueryTermMatchedNum(query_term_ids, area_term_ids,
                                  &bigram_hits, &skip_bigram_hits);
}

}  // namespace searchserver
}  // namespace reco
