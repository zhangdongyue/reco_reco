#pragma once
#include <vector>
#include <unordered_map>
#include <map>
#include <set>
#include <string>

#include "base/common/basic_types.h"
#include "base/time/time.h"
#include "reco/bizc/reco_index/item_info.h"
#include "query/tree/query_tree.h"
#include "query/dnf/dnf_retrieval.h"
#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace  adsindexing {
class Index;
}

namespace queries {
class DNFRetrieval;
}

namespace reco {

class NewsIndex;

namespace leafserver {
class TagSearcher : public BaseSearcher {
 public:
  TagSearcher(const reco::NewsIndex* news_index);
  ~TagSearcher();

  // tag 检索。 这里的 tag 可以是类别和标签
  // 内部处理时优先做类别检索，再做标签检索，直到满足条数
  bool Search(const RecoRequest* reco_request,
              const std::string& tag,
              const Config& config,
              std::vector<ItemInfo>* item_list,
              DebugInfo* debug_info);

 private:
  void SetTagInfo(const RecoRequest* reco_request, const std::string& tag);
  bool Retrieve(std::vector<ItemInfo>* ir_results);
  void Rank(std::vector<ItemInfo>& fr_candidates,
            std::vector<ItemInfo>* ranked_results);
  bool CheckDeliverTime(const uint64& item_id);

  // 每次请求相关的参数
  int64 now_timestamp_;  // 当前的时间戳
  const RecoRequest* reco_request_;  // 请求相关的信息
  bool need_user_dedup_;  // 是否需要在检索时做用户去重
  std::string query_;
  // 0:普通标签, 1:事件标签
  int tag_type_;
  // 时间轴的最新进展, 非 0 表示有最新进展
  uint64 latest_item_id_;
  bool use_cache_;
  std::set<uint64> manual_items_;
};
}  // leafserver
}  // reco
