#pragma once

#include <string>
#include <vector>
#include <utility>
#include <unordered_map>

#include "base/common/base.h"
#include "base/strings/string_printf.h"

namespace  adsindexing {
class Index;
}

namespace queries {
class QueryTree;
class QueryTreeNode;
}

namespace reco {
namespace leafserver {

// 当赋予该值时,表示取值没有意义,无需输出该特征
static const int kTrivialValue = -1;
static const int kMaxQueryTermNum = 100;
static const int kMaxOffset = 1000;

struct TermElem {
  TermElem() {
    Clear();
  }

  explicit TermElem(uint64 unigram_id) {
    weight = 0;
    show_offset = 0;
    show_len = 0;
    //ids.resize(ungram_id, 1);
    id = unigram_id;
  }

  void Clear() {
    literal.clear();
    weight = 0;
    show_offset = 0;
    show_len = 0;
    //ids.clear();
    id = -1;
  }

  std::string ToString() {
    return base::StringPrintf("[term=%s,weight=%.3f,offset=%d,len=%d]",
                       literal.c_str(), weight, show_offset, show_len);
  }

  std::string literal;   // 字面
  double weight;      // 重要性
  int   show_offset;  // 显示 偏移
  int   show_len;     // 显示 宽度
  int64 id;
};

// Query 相关信息的总管
// Query 级别和 term 级别的信息都由该结构体管理
struct QueryInfo {
  QueryInfo() {
    Clear();
  }

  void Clear() {
    literal.clear();
    term_elems.clear();
    term_dict.clear();
    total_weight = 0;
    total_show_len = 0;
  }

  std::string ToString() {
    std::string str = base::StringPrintf("literal=%s,weight=%.3f,len=%d",
                                         literal.c_str(), total_weight, total_show_len);
    for (size_t i = 0; i < term_elems.size(); ++i) {
      if (!str.empty()) {
        str += " ";
      }
      str += term_elems[i].ToString();
    }
    for (auto it = term_dict.begin(); it != term_dict.end(); ++it) {
      if (!str.empty()) {
        str += " ";
      }
      str += base::StringPrintf("[%ld:%d]", it->first, it->second);
    }
    return str;
  }

  void FillQueryInfo(const queries::QueryTreeNode* dnf_node,
                     const adsindexing::Index* index);

  std::string literal;
  std::vector<TermElem> term_elems;
  std::unordered_map<int64, int> term_dict;
  float total_weight;
  int  total_show_len;
};

struct AreaInfo {
  enum AreaType {
    kTitleArea = 0,
    kKeywordArea = 1,
    kSourceArea = 2,
    kCategoryArea = 3,
    kContentArea = 4,
    kNoArea = 255
  };

  void Clear() {
    area_type = kNoArea;
    literal.clear();

    total_weight = 0;
    total_show_len = 0;

    term_elems.clear();
    term_dict.clear();
  }

  std::string ToString() {
    std::string str;
    switch (area_type) {
      case kTitleArea:
        str = "[title] ";
        break;
      case kKeywordArea:
        str = "[keyword] ";
        break;
      case kCategoryArea:
        str = "[category] ";
        break;
      case kSourceArea:
        str = "[source] ";
        break;
      case kContentArea:
        str = "[content] ";
        break;
      default:
        break;
    }

    str += base::StringPrintf("weight=%.3f,len=%d", total_weight, total_show_len);
    for (size_t i = 0; i < term_elems.size(); ++i) {
      if (!str.empty()) {
        str += " ";
      }
      str += term_elems[i].ToString();
    }
    for (auto it = term_dict.begin(); it != term_dict.end(); ++it) {
      if (!str.empty()) {
        str += " ";
      }
      str += base::StringPrintf("[%ld:%d]", it->first, it->second);
    }
    return str;
  }

  AreaType area_type;
  std::string literal;
  float total_weight;
  int  total_show_len;
  std::unordered_map<int64, int> term_dict;
  std::vector<TermElem> term_elems;
};

struct DocInfo {
  DocInfo() {
    Clear();
  }

  void Clear() {
    doc_id = -1;
    title_info.Clear();
    keyword_info.Clear();
    source_info.Clear();
    category_info.Clear();
    content_info.Clear();
  }

  std::string ToString() {
    return title_info.ToString() + " " + keyword_info.ToString() + " " + source_info.ToString()
        + " " + category_info.ToString() + " " + content_info.ToString();
  }

  bool FillDocInfo(int doc_id, const adsindexing::Index* index);

  // term id in indexing
  int32 doc_id;
  AreaInfo title_info;
  AreaInfo keyword_info;
  AreaInfo source_info;
  AreaInfo category_info;
  AreaInfo content_info;

};

struct RelevantFeature {
  RelevantFeature() {
    Clear();
  }

  void Clear() {
    query_term_num = 0;
    query_show_len = 0;
    area_show_len = 0;
    query_weight = 0;
    area_weight = 0;

    match_show_len = 0;
    match_query_offset = kMaxOffset;
    match_query_weight = 0;
    match_area_offset = kMaxOffset;
    match_area_weight = 0;
    lcs_hit_show_len = 0;
    lcs_query_window_show_len = 0;
    lcs_query_window_weight = 0;
    lcs_query_hit_weight = 0;
    lcs_area_window_show_len = 0;
    lcs_area_window_weight = 0;
    lcs_area_hit_weight = 0;
    bigram_hits = 0;
    skip_bigram_hits = 0;
  }

  std::string ToString() {
    std::string str;
    str += base::StringPrintf("Qlen=%d", query_show_len);
    str += base::StringPrintf(" Alen=%d", area_show_len);
    str += base::StringPrintf(" Qwt=%.3f", query_weight);
    str += base::StringPrintf(" Awt=%.3f", area_weight);

    str += base::StringPrintf(" mlen=%d", match_show_len);
    str += base::StringPrintf(" mQoff=%d", match_query_offset);
    str += base::StringPrintf(" mQwt=%.3f", match_query_weight);

    str += base::StringPrintf(" mAoff=%d", match_area_offset);
    str += base::StringPrintf(" mAwt=%.3f", match_area_weight);

    str += base::StringPrintf(" hitlen=%d", lcs_hit_show_len);

    str += base::StringPrintf(" winQlen=%d", lcs_query_window_show_len);
    str += base::StringPrintf(" winQwt=%.3f", lcs_query_window_weight);
    str += base::StringPrintf(" hitQwt=%.3f", lcs_query_hit_weight);

    str += base::StringPrintf(" winAlen=%d", lcs_area_window_show_len);
    str += base::StringPrintf(" winAwt=%.3f", lcs_area_window_weight);
    str += base::StringPrintf(" hitAwt=%.3f", lcs_area_hit_weight);

    str += base::StringPrintf(" bigramhit=%d", bigram_hits);
    str += base::StringPrintf(" sbigramhit=%d", skip_bigram_hits);
    return str;
  }

  int query_term_num;
  int query_show_len;
  int area_show_len;
  float query_weight;
  float area_weight;

  int match_show_len;

  int match_query_offset;
  float match_query_weight;

  int match_area_offset;
  float match_area_weight;

  // 子序列窗口中命中的长度
  int lcs_hit_show_len;

  // 整个子序列窗口的长度
  int lcs_query_window_show_len;
  float lcs_query_window_weight;
  float lcs_query_hit_weight;

  int lcs_area_window_show_len;
  float lcs_area_window_weight;
  float lcs_area_hit_weight;

  int bigram_hits;
  int skip_bigram_hits;

  void ExtractFeature(const QueryInfo& query_info, const AreaInfo& area_info);

};

struct RelevantEvaluation {
  float score;
  // 完全包含 query
  bool contain_query;
  // 覆盖所有 query term
  bool cover_all_query_terms;

  RelevantEvaluation() : score(0.0f), contain_query(false), cover_all_query_terms(false) {}
};

}  // namespace leafserver
}  // namespace reco
