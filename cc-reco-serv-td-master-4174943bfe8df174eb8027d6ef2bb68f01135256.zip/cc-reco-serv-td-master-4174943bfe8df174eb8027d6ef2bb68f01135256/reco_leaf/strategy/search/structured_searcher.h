#pragma once
#include <vector>
#include <unordered_map>
#include <map>
#include <string>

#include "base/common/basic_types.h"
#include "base/strings/string_split.h"
#include "base/time/time.h"
#include "reco/bizc/reco_index/item_info.h"
#include "query/tree/query_tree.h"
#include "query/dnf/dnf_retrieval.h"
#include "reco/serv/reco_leaf/strategy/search/searcher_define.h"
#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace reco {

class NewsIndex;

namespace leafserver {

class StructuredSearcher : public BaseSearcher {
 public:
  StructuredSearcher(const reco::NewsIndex* news_index);
  ~StructuredSearcher();

  bool Search(const RecoRequest* reco_request,
              const std::string& composed_query,
              const Config& config,
              std::vector<ItemInfo>* item_list,
              DebugInfo* debug_info) {
    std::vector<std::string> and_words;
    std::vector<std::string> or_words;
    std::vector<std::string> not_words;

    ParseStructuredQuery(composed_query, &and_words, &or_words, &not_words);
    return Search(reco_request, and_words, or_words, not_words, config, item_list, debug_info);
  }

  bool Search(const RecoRequest* reco_request,
              const std::vector<std::string>& and_words,
              const std::vector<std::string>& or_words,
              const std::vector<std::string>& not_words,
              const Config& config,
              std::vector<ItemInfo>* item_list,
              DebugInfo* debug_info);

  static std::string ToQuery(const std::vector<std::string>& and_words,
                             const std::vector<std::string>& or_words,
                             const std::vector<std::string>& not_words) {
    return base::JoinStrings(and_words, ",") + " "
        + base::JoinStrings(or_words, ",") + " "
        + base::JoinStrings(not_words, ",");
  }

  static void ParseStructuredQuery(const std::string& composed_query,
                            std::vector<std::string>* and_words,
                            std::vector<std::string>* or_words,
                            std::vector<std::string>* not_words) {
    and_words->clear();
    or_words->clear();
    not_words->clear();

    std::vector<std::string> flds;
    base::SplitString(composed_query, " ", &flds);

    std::vector<std::string> subs;
    if (flds.size() > 0 && !flds[0].empty()) {
      subs.clear();
      base::SplitString(flds[0], ",", &subs);
      and_words->insert(and_words->end(), subs.begin(), subs.end());
    }

    if (flds.size() > 1 && !flds[1].empty()) {
      subs.clear();
      base::SplitString(flds[1], ",", &subs);
      or_words->insert(or_words->end(), subs.begin(), subs.end());
    }

    if (flds.size() > 2 && !flds[2].empty()) {
      subs.clear();
      base::SplitString(flds[2], ",", &subs);
      not_words->insert(not_words->end(), subs.begin(), subs.end());
    }
  }

 private:
  adsindexing::DocIterator* GetDocIter(const std::string &literal, adsindexing::TermType type);

  bool ParseQuery(const std::vector<std::string>& and_words,
                  const std::vector<std::string>& or_words,
                  const std::vector<std::string>& not_words,
                  queries::QueryTree* include_dnf_tree,
                  queries::QueryTree* exclude_dnf_tree);

  bool SearchDoc(const queries::QueryTree& include_tree,
                 const queries::QueryTree& exclude_tree,
                 bool is_dnf_tree,
                 std::vector<int>* local_doc_ids);

  bool Retrieve(const queries::QueryTree& dnf_include_tree,
                const queries::QueryTree& dnf_exclude_tree,
                std::vector<ItemInfo>* ir_results);
  void RetrieveDocId(const queries::QueryTree& dnf_tree, std::set<int32>* docid_set);
  void Rank(const queries::QueryTree &ranking_tree,
            const std::vector<ItemInfo>& fr_candidates,
            std::vector<ItemInfo>* ranked_results);

 private:
  std::map<std::pair<std::string, adsindexing::TermType>, adsindexing::DocIterator*> terms_map_;
  std::set<int32> include_docid_set_;
  std::set<int32> exclude_docid_set_;

  std::unordered_set<uint64> item_dedup_;
  reco::nlpserver::NLPService::Stub* nlp_service_;
  const NewsIndex* news_index_;
  const adsindexing::Index* index_;

  // 每次请求相关的参数 
  std::vector<QueryInfo> query_infos_;
  int64 now_timestamp_;  // 当前的时间戳
  const RecoRequest* reco_request_;  // 请求相关的信息
  bool need_user_dedup_;  // 是否需要在检索时做用户去重
  std::string query_;
};
}  // namespace leafserver
}  // namespace reco
