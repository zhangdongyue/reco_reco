#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"

#include <vector>
#include <string>
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/proto/common.pb.h"
#include "nlp/common/nlp_util.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/item_info.h"
// #include "reco/serv/reco_leaf/strategy/common/topn.h"
// #include "nlp/common/nlp_util.h"
// #include "ads_index/api/public.h"
// #include "query/dnf/dnf_util.h"
// #include "query/dnf/dnf_retrieval.h"
// #include "query/parser_util/parser_util.h"
// #include "extend/multi_strings/multi_pattern_matcher.h"

namespace reco {
namespace leafserver {

BaseSearcher::BaseSearcher(const reco::NewsIndex* news_index, const char* searcher_name) {
  news_index_ = news_index;
  index_ = news_index_->GetAdsIndex();
  searcher_name_ = searcher_name;
}

BaseSearcher::~BaseSearcher() {
}

#define div(num, dominator) \
    (dominator > 0 ? float(num)/float(dominator) : 0)

RelevantEvaluation BaseSearcher::CalcAreaRelScore(const AreaInfo::AreaType& area_type,
                                                  const RelevantFeature& feature) {
  RelevantEvaluation eva;
  // query 完全包含
  if (feature.query_show_len == feature.lcs_query_window_show_len
      && feature.lcs_query_window_show_len == feature.lcs_hit_show_len
      && feature.lcs_area_window_show_len == feature.lcs_hit_show_len) {
    eva.contain_query = true;
  }

  if (feature.query_show_len == feature.match_show_len) {
    eva.cover_all_query_terms = true;
  }

  // 完全没有命中
  if (feature.match_show_len == 0) return eva;

  float match_q_ratio = div(feature.match_show_len, feature.query_show_len);
  // float match_a_ratio = div(feature.match_show_len, feature.area_show_len);
  float lcs_cover_q_show_ratio = div(feature.lcs_query_window_show_len, feature.query_show_len)
      * div(feature.lcs_hit_show_len, feature.lcs_query_window_show_len);
  float lcs_cover_q_weight_ratio = div(feature.lcs_query_window_weight, feature.query_weight) 
      * div(feature.lcs_query_hit_weight, feature.lcs_query_window_weight);
  // float lcs_cover_a_show_ratio = div(feature.lcs_area_window_show_len, feature.area_show_len)
  // * div(feature.lcs_hit_show_len, feature.lcs_area_window_show_len);
  // float lcs_cover_a_weight_ratio = div(feature.lcs_area_window_weight, feature.area_weight)
  // * div(feature.lcs_area_hit_weight, feature.lcs_area_window_weight);

  float total_score = (match_q_ratio + lcs_cover_q_show_ratio + lcs_cover_q_weight_ratio) / 3.0;
  // + lcs_cover_a_show_ratio + lcs_cover_a_weight_ratio;

  total_score += feature.bigram_hits * 0.1f;
  total_score += feature.skip_bigram_hits * 0.1f;

  eva.score = std::min(total_score, 1.0f);

  return eva;
}

float BaseSearcher::CalcFinalRelScore(uint64 item_id, float title_coef, float keyword_coef,
                                      const QueryInfo& query_info, const DocInfo& doc_info,
                                      bool* title_all_hit) {
  RelevantFeature feature;

  // bool short_query = false;
  // if (query_info.term_elems.size() <= 3u || query_info.total_show_len <= 8) {
  //   short_query = true;
  // }

  feature.Clear();
  feature.ExtractFeature(query_info, doc_info.title_info);
  RelevantEvaluation title_eva = CalcAreaRelScore(AreaInfo::kTitleArea, feature);
  VLOG(1) << item_id << ", " << query_info.literal << " vs title " << doc_info.title_info.literal
          << ", score: " << title_eva.score << ", feature: " << feature.ToString();

  feature.Clear();
  feature.ExtractFeature(query_info, doc_info.keyword_info);
  RelevantEvaluation keyword_eva = CalcAreaRelScore(AreaInfo::kKeywordArea, feature);
  VLOG(1) << item_id << ", " << query_info.literal << " vs keyword " << doc_info.keyword_info.literal
          << ", score: " << keyword_eva.score << ", feature: " << feature.ToString();

  float boost = 0;
  if (title_eva.contain_query) {
    boost += 2.0f;
  } else if (query_info.term_elems.size() > 1
             && title_eva.cover_all_query_terms) {
    boost += 1;
  }
  *title_all_hit = title_eva.cover_all_query_terms;

  float final_score = title_coef * title_eva.score + keyword_coef * keyword_eva.score + boost;

  VLOG(1) << item_id << ", " << query_info.literal << "->"
          << doc_info.doc_id << ":" << doc_info.title_info.literal
          << base::StringPrintf("[%.3f,%.3f,%.3f,%.3f]",
                                title_eva.score, keyword_eva.score, boost, final_score);
  return final_score;
}

void BaseSearcher::GetCachedItems(const std::string& cache_key, int64 now_timestamp,
                                  std::vector<ItemInfo>* cached_items) {
  cached_items->clear();
  // visit cache first
  std::string cache_value;
  if (!LeafCache::GetCachedReco(cache_key, &cache_value)) {
    VLOG(1) << cache_key << " cache missed";
    return;
  }
  std::vector<std::string> flds;
  base::SplitString(cache_value, ",", &flds);
  VLOG(1) << cache_key << " return " << flds.size() << " results";
  for (size_t i = 0; i < flds.size(); ++i) {
    uint64 item_id;
    if (!base::StringToUint64(flds[i], &item_id)) {
      continue;
    }
    reco::ItemInfo item;
    // 只需要重新判断 valid 即可
    if (!news_index_->GetItemInfoByItemId(item_id, &item, true)
        || !NewsFilter::ItemIsValid(item, now_timestamp)) {
      continue;
    }

    cached_items->push_back(item);
    VLOG(1) << cache_key << " add " << item_id;
  }
}

void BaseSearcher::UserDedup(const RecoRequest* reco_request,
                             std::vector<ItemInfo>* item_list, int64* filtered_num) {
  *filtered_num = 0;
  size_t idx = 0;
  for (size_t i = 0; i < item_list->size(); ++i) {
    uint64 item_id = (*item_list)[i].item_id;
    reco::filter::FilterReason filter_reason;
    if (NewsFilter::IsGeneralFiltered(reco_request, reco_request->shown_dict,
                                      (*item_list)[i], &filter_reason, false)) {
      ++(*filtered_num);
      VLOG(1) << item_id << " user dedup";
      continue;
    }
    if (idx != i) {
      (*item_list)[idx] = (*item_list)[i];
    }
    ++idx;
  }
  item_list->resize(idx);
}

void BaseSearcher::ItemDedup(std::vector<ItemInfo>* item_list, int64* filtered_num) {
  *filtered_num = 0;
  base::dense_hash_set<uint64> item_dedup;
  item_dedup.set_empty_key(0);
  size_t idx = 0;
  for (size_t i = 0; i < item_list->size(); ++i) {
    uint64 item_id = (*item_list)[i].item_id;
    if (NewsFilter::IsDeduped((*item_list)[i], &item_dedup)) {
      ++(*filtered_num);
      VLOG(1) << item_id << " item dedup";
      continue;
    }

    if (idx != i) {
      (*item_list)[idx] = (*item_list)[i];
    }
    ++idx;
  }
  item_list->resize(idx);
}

bool BaseSearcher::GetSubCategoryByDocId(reco::ItemInfo &item_info) {
  std::vector<std::string> categories;
  if (!news_index_->GetCategoriesByDocId(item_info.doc_id, &categories) || categories.empty()) {
    return false;
  }
  if (categories.size() > 1u) {
    item_info.sub_category = categories[1];
  }
  return true;
}

void BaseSearcher::GetItemInfoForNItems(std::vector<ItemInfo> &candidate_item_list,
                                 std::vector<ItemInfo>* dest_item_list, int return_num) {
  for (size_t i = 0; i < candidate_item_list.size(); ++i) {
    if (!news_index_->GetItemInfoByDocId(candidate_item_list[i].doc_id, &(candidate_item_list[i]), false)) {
      continue;
    }
    dest_item_list->push_back(candidate_item_list[i]);
    if ((int)dest_item_list->size() >= return_num) {
      break;
    }
  }
}

void BaseSearcher::ItemDedup(std::vector<ItemInfo>* item_list, const std::set<uint64>& except_items,
    int64* filtered_num) {
  *filtered_num = 0;
  base::dense_hash_set<uint64> item_dedup;
  item_dedup.set_empty_key(0);
  size_t idx = 0;
  for (size_t i = 0; i < item_list->size(); ++i) {
    uint64 item_id = (*item_list)[i].item_id;
    if (except_items.find(item_id) == except_items.end()
        && NewsFilter::IsDeduped((*item_list)[i], &item_dedup)) {
      ++(*filtered_num);
      VLOG(1) << item_id << " item dedup";
      continue;
    }

    if (idx != i) {
      (*item_list)[idx] = (*item_list)[i];
    }
    ++idx;
  }
  item_list->resize(idx);
}

}  // namespace leafserver
}  // namespace reco
