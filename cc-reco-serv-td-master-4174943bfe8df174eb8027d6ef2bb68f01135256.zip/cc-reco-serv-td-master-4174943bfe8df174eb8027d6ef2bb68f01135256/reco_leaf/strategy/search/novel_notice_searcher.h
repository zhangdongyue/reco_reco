#pragma once
#include <vector>
#include <unordered_map>
#include <map>
#include <string>

#include "base/common/basic_types.h"
#include "base/time/time.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace  adsindexing {
class Index;
}

namespace reco {

class NewsIndex;

namespace leafserver {
class NovelNoticeSearcher : public BaseSearcher {
 public:
  NovelNoticeSearcher(const reco::NewsIndex* news_index);
  ~NovelNoticeSearcher();

  bool Search(const RecoRequest* reco_request,
              const std::string& query,
              const Config& config,
              std::vector<ItemInfo>* item_list,
              DebugInfo* debug_info);

 private:
  bool Retrieve(std::vector<ItemInfo>* ir_results);
  void GetFollowingNovleList(const reco::user::UserInfo* user_info,
                             std::vector<std::string>* novel_id_list);

  // 每次请求相关的参数
  int64 now_timestamp_;  // 当前的时间戳
  const RecoRequest* reco_request_;  // 请求相关的信息
  const reco::user::UserInfo* user_info_;
  // bool ir_need_user_dedup_;  // 是否需要在检索时做用户去重
  std::string query_;
};

bool NovelNoticeCompare(const ItemInfo& item1, const ItemInfo& item2);

}  // leafserver
}  // reco
