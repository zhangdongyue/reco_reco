#pragma once
#include <vector>
#include <unordered_map>
#include <map>
#include <string>

#include "base/common/basic_types.h"
#include "base/time/time.h"
#include "reco/bizc/reco_index/item_info.h"
#include "query/tree/query_tree.h"
#include "query/dnf/dnf_retrieval.h"
#include "reco/serv/reco_leaf/strategy/search/searcher_define.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/proto/reco_nlp_server.pb.h"

namespace  adsindexing {
class Index;
}

namespace queries {
class DNFRetrieval;
}

namespace reco {

class NewsIndex;

namespace leafserver {
class BaseSearcher {
 public:
  // 各个派生类要指定不同的 searcher_name 用于缓存的 key 避免缓存冲突
  BaseSearcher(const reco::NewsIndex* news_index, const char* searcher_name);
  ~BaseSearcher();

  // 搜索参数
  struct Config {
    int return_num;  // 返回条数
    int ir_num;  // 触发环节返回的文档数
    int fr_num;  // 进入精排队列的条数（要大于返回条数）

    // 决定相关性得分的系数 最终得分是 kTitleCoff * title_score + kKeywordCoff * keyword_score + boost;
    // boost 是对文本区域包含 query 关系的强提权
    float title_rel_coef;  // 标题相关性系数
    float keyword_rel_coef;  // 关键词或标签相关性系数

    // 相关性和 ctr 双重调节，判断条件
    // show > show_threshold
    // && ((rel > rel_low && ctr > ctr_high)
    //     || (rel > rel_high && ctr > ctr_low))
    float rel_low_threshold;  // 低相关性阈值
    float rel_high_threshold;  // 高相关性阈值
    float ctr_low_threshold;  // 低 ctr 阈值
    float ctr_high_threshold;  // 高 ctr 阈值

    int show_threshold; // 展现次数阈值

    bool title_all_hit;  // 标题全部命中出现
    bool filter_unreviewed;  // 必须经过审核
    bool filter_region;  // 过滤地区新闻
    bool filter_manual;  // 过略人工新闻
    bool in_show_tag;  // 必须出现在 show tag 里
    bool do_user_dedup; // 是否根据用户展现历史做去重, 默认为 true
    std::vector<reco::IrType> retr_stem_vec;   // 定义触发的来源，如果为空，走默认触发源

    reco::TimeLevel timelevel_threshold;  // timelevel 要 >= 此值

    bool use_cache;
    // 不同的调用方，自定义缓存的前缀，避免不同的应用搜索同一个 query 时结果互相覆盖
    // NOTE: 必须定义
    std::string cache_prefix;

    std::set<std::string> white_media_dict;  // 媒体白名单
    std::set<std::string> white_category_dict_l1;  // 一级类别白名单
    std::set<std::string> white_category_dict_l2;  // 二级类别白名单
    std::set<int> white_item_type_dict;  // item type 白名单
    std::set<std::string> skip_filter_source_dict; // 对一些来源的 item 进行过滤条件豁免

    // 强制要求调用方指定他们缓存的前缀，避免不同的搜索条件使用同一份缓存
    Config(const char* prefix) {
      cache_prefix = prefix;

      return_num = 20;
      ir_num = 5000;
      fr_num = 50;
      rel_low_threshold = 0.7;
      rel_high_threshold = 0.9;
      ctr_low_threshold = 0.06;
      ctr_high_threshold = 0.07;
      show_threshold = 300;

      title_rel_coef = 0.9f;
      keyword_rel_coef = 0.1f;

      timelevel_threshold = reco::kGoodTimeliness;
      use_cache = true;

      title_all_hit = false;
      filter_unreviewed = false;
      filter_region = true;
      filter_manual = true;
      in_show_tag = false;
      do_user_dedup = true;
    }
  };

  // 搜索结果调试
  struct DebugInfo {
    int64 ir_valid_filtered;
    int64 ir_itemtype_filtered;
    int64 ir_review_filtered;
    int64 ir_region_filtered;
    int64 ir_manual_filtered;
    int64 ir_user_dedup_filtered;
    int64 ir_strict_quality_filtered;
    int64 ir_policy_filtered;
    int64 ir_result;
    int64 fr_ctr_filtered;
    int64 fr_timelevel_filtered;
    int64 fr_rel_filtered;
    int64 fr_title_hit_filtered;
    int64 fr_media_filtered;
    int64 fr_category_filtered;
    int64 fr_showtag_filtered;
    int64 fr_result;
    int64 user_dedup;
    int64 item_dedup;
    float max_ctr;
    float max_timelevel;
    float max_rel;

    DebugInfo() {
      Reset();
    }

    void Reset() {
      ir_valid_filtered = 0;
      ir_itemtype_filtered = 0;
      ir_review_filtered = 0;
      ir_region_filtered = 0;
      ir_user_dedup_filtered = 0;
      ir_strict_quality_filtered = 0;
      ir_policy_filtered = 0;
      ir_result = 0;
      fr_ctr_filtered = 0;
      fr_timelevel_filtered = 0;
      fr_rel_filtered = 0;
      fr_title_hit_filtered = 0;
      fr_media_filtered = 0;
      fr_category_filtered = 0;
      fr_showtag_filtered = 0;
      fr_result = 0;
      user_dedup = 0;
      item_dedup = 0;
      max_ctr = -1;
      max_timelevel = -1;
      max_rel = -1;
    }

    std::string ToString() {
      return base::StringPrintf("IrValFil[%ld],IrRegFil[%ld],IrReviewFil[%ld],"
                                "IrUsrFil[%ld],IrPolicy[%ld],IrStrictFil[%ld], IrRes[%ld],"
                                "FrCtrFil[%ld],FrTimeFil[%ld],FrRelFil[%ld],FrTtlFil[%ld],"
                                "FrMedFil[%ld],FrRes[%ld],"
                                "ItemDedup[%ld],UserDedup[%ld],"
                                "MaxCtr[%.3f],MaxTl[%.3f],MaxRel[%.3f]",
                                ir_valid_filtered, ir_region_filtered, ir_review_filtered,
                                ir_user_dedup_filtered, ir_policy_filtered, ir_strict_quality_filtered,
                                ir_result, fr_ctr_filtered, fr_timelevel_filtered, fr_rel_filtered,
                                fr_title_hit_filtered, fr_media_filtered, fr_result,
                                item_dedup, user_dedup,
                                max_ctr, max_timelevel, max_rel);

    }
  };

 protected:
  /*
  float GetSysLevelRatio() {
    float ratio = 1.0f;

    switch (LeafDataManager::GetGlobalData()->sys_status) {
      case kSysBusy:
        ratio = 0.7f;
        break;
      case kSysFull:
        ratio = 0.5f;
        break;
      case kSysDanger:
        ratio = 0.2f;
        break;
      case kSysCritical:
        ratio = 0.1f;
        break;
      default:
        ratio = 1.0f;
        break;
    }

    return ratio;
  }
  */

  bool GetSubCategoryByDocId(ItemInfo &item_info);

  void GetItemInfoForNItems(std::vector<ItemInfo> &candidate_item_list,
                           std::vector<ItemInfo>* dest_item_list, int return_num);

  void GetCachedItems(const std::string& cache_key, int64 now_timestamp, std::vector<ItemInfo>* cached_items);

  // 计算相关性
  // 正常情况返回 0-1 之间的数。 如果包含query，直接加到 3
  float CalcFinalRelScore(uint64 item_id, float title_coef, float keyword_coef,
                          const QueryInfo& query_info, const DocInfo& doc_info, bool* title_all_hit);

  RelevantEvaluation CalcAreaRelScore(const AreaInfo::AreaType& area_type,
                                      const RelevantFeature& feature);

  void UserDedup(const RecoRequest* reco_request, std::vector<ItemInfo>* item_list, int64* filtered_num);

  void ItemDedup(std::vector<ItemInfo>* item_list, int64* filtered_num);
  // except_items 中的 item 不过滤，主要是对运营新闻不去重
  void ItemDedup(std::vector<ItemInfo>* item_list, const std::set<uint64>& except_items, int64* filtered_num);

  std::string GetSearchCacheKey(const std::string& query) {
    CHECK(!searcher_name_.empty());
    CHECK(!config_->cache_prefix.empty());
    return searcher_name_ + config_->cache_prefix + query;
  }

  // 进行以下过滤：valid, regio, manual, reviewed
  inline bool IrCommonFilter(const ItemInfo& item_info, int64 now_timestamp);

  // 进行以下过滤：timelevel
  inline bool ItemLevelFilter(const ItemInfo& item_info);
  // 进行以下过滤：media dict, category dict
  inline bool FrCommonFilter(const ItemInfo& item_info);

  std::string searcher_name_;  // 派生类要在构造函数中给这个变量赋值

  const NewsIndex* news_index_;
  const adsindexing::Index* index_;

  const Config* config_;
  DebugInfo debug_info_;

  // 过滤函数中使用的临时变量
  std::vector<int64> region_ids_;
  std::string producer_;
  std::vector<std::string> categories_;
};

bool BaseSearcher::IrCommonFilter(const ItemInfo& item_info, int64 now_timestamp) {
  int32 doc_id = item_info.doc_id;
  uint64 item_id = item_info.item_id;

  if (!NewsFilter::ItemIsValid(item_info, now_timestamp)) {
    ++debug_info_.ir_valid_filtered;
    VLOG(1) << item_id << " valid filtered";
    return false;
  }

  if (!config_->white_item_type_dict.empty()
      && config_->white_item_type_dict.find(item_info.item_type) == config_->white_item_type_dict.end()) {
    ++debug_info_.ir_itemtype_filtered;
    VLOG(1) << item_id << " item type filtered";
    return false;
  }

  if(config_->filter_unreviewed
     && !news_index_->GetHasReviewedByDocId(doc_id)) {
    ++debug_info_.ir_review_filtered;
    VLOG(1) << item_id << " unreview filtered";
    return false;
  }

  // 过滤非机器新闻
  if (config_->filter_manual
      && news_index_->IsManualByDocId(doc_id)) {
    VLOG(1) << "filter special news ! item_id:" << item_id;
    ++debug_info_.ir_manual_filtered;
    return false;
  }

  if (config_->filter_region) {
    region_ids_.clear();
    news_index_->GetRegionIdByDocId(doc_id, &region_ids_);
    if (!region_ids_.empty()) {
      ++debug_info_.ir_region_filtered;
      VLOG(1) << item_id << " ir region filtered";
      return false;
    }

    region_ids_.clear();
    news_index_->GetRestrictRegionIdByDocId(doc_id, &region_ids_);
    if (!region_ids_.empty()) {
      ++debug_info_.ir_region_filtered;
      VLOG(1) << item_id << " ir region filtered";
      return false;
    }
  }

  if (NewsFilter::IsStrictQualityFiltered(item_info)) {
    ++debug_info_.ir_strict_quality_filtered;
    VLOG(1) << item_id << " strict quality filtered";
    return false;
  }

  if (NewsFilter::PolicyFilter(item_info)) {
    ++debug_info_.ir_policy_filtered;
    VLOG(1) << item_id << " policy filtered";
    return false;
  }

  return true;
}


bool BaseSearcher::ItemLevelFilter(const ItemInfo& item_info) {
  debug_info_.max_timelevel = std::max((float)item_info.time_level, debug_info_.max_timelevel);
  if (item_info.time_level < config_->timelevel_threshold) {
    ++debug_info_.fr_timelevel_filtered;
    VLOG(1) << item_info.item_id << " fr timelevel filtered";
    return false;
  }
  return true;
}

bool BaseSearcher::FrCommonFilter(const ItemInfo& item_info) {
  int32 doc_id = item_info.doc_id;
  uint64 item_id = item_info.item_id;

  if (!config_->white_media_dict.empty()) {
    std::string media;
    if (!news_index_->GetOrigSourceMediaByItemId(item_id, &media)
        || config_->white_media_dict.find(media) == config_->white_media_dict.end()) {
      ++debug_info_.fr_media_filtered;
      VLOG(1) << item_id << " fr media filtered";
      return false;
    }
  }

  if (!config_->white_category_dict_l1.empty() || !config_->white_category_dict_l2.empty()) {
    categories_.clear();
    if (!news_index_->GetCategoriesByDocId(doc_id, &categories_) || categories_.empty()) {
      ++debug_info_.fr_category_filtered;
      return false;
    }
    if (!config_->white_category_dict_l1.empty()
        && config_->white_category_dict_l1.find(categories_[0]) == config_->white_category_dict_l1.end()) {
      ++debug_info_.fr_category_filtered;
      return false;
    }

    if (!config_->white_category_dict_l2.empty()
        && (categories_.size() <= 1u ||
            config_->white_category_dict_l2.find(categories_[1]) == config_->white_category_dict_l2.end())) {
      ++debug_info_.fr_category_filtered;
      return false;
    }
  }
  return true;
}
}  // leafserver
}  // reco

