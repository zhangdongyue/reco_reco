#include "reco/serv/reco_leaf/strategy/search/tag_searcher.h"

#include <vector>
#include <string>
#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/reco_leaf/strategy/component/candidates/candidates.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/filter_rule/online/filter_monster.h"
#include "reco/bizc/proto/reco_nlp_server.pb.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/proto/common.pb.h"
#include "nlp/common/nlp_util.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/topn.h"
#include "nlp/common/nlp_util.h"
#include "ads_index/api/public.h"
#include "query/dnf/dnf_util.h"
#include "query/dnf/dnf_retrieval.h"
#include "query/parser_util/parser_util.h"
#include "extend/multi_strings/multi_pattern_matcher.h"

namespace reco {
namespace leafserver {

DEFINE_double(tag_search_video_type_discount, 0.2, "事件标签页和订阅标签页视频新闻降权");

TagSearcher::TagSearcher(const reco::NewsIndex* news_index) : BaseSearcher(news_index, "TS") {
}

TagSearcher::~TagSearcher() {
}

void TagSearcher::SetTagInfo(const RecoRequest* reco_request, const std::string& tag) {
  // 0: 普通标签请求, 1: 事件标签请求
  tag_type_ = 0;
  latest_item_id_ = 0;
  const reco::leafserver::RecommendRequest* request = reco_request->request;
  if (request->channel_id() == reco::common::kTagMainpageChannelId
      && request->channel_tags_size() == request->channel_tags_type_size()) {
    for (int i = 0; i < request->channel_tags_size(); ++i) {
      if (request->channel_tags(i) != tag) continue;
      tag_type_ = request->channel_tags_type(i);
      VLOG(1) << "request tag:" << tag << ", type:" << request->channel_tags_type(i);

      // 时间轴和事件标签的名字是一致的，所以此处直接用标签名字查找时间轴信息
      reco::time_axis::TimeAxisInfo time_axis_info;
      if (!news_index_->GetLatestNewsByEventName(tag, &latest_item_id_, &time_axis_info)) {
        VLOG(1) << "event tag has not time axis ! tag:" << tag;
      } else {
        VLOG(1) << "event tag has time axis ! tag:" << tag << "first resut:" << latest_item_id_;
      }
      break;
    }
  }
}

bool TagSearcher::Search(const RecoRequest* reco_request,
                         const std::string& tag,
                         const Config& config,
                         std::vector<ItemInfo>* item_list,
                         DebugInfo* debug_info) {
  item_list->clear();
  manual_items_.clear();
  if (tag.empty()) {
    VLOG(1) << "normalized query is empty";
    return false;
  }

  query_ = tag;
  config_ = &config;
  debug_info_.Reset();
  now_timestamp_ = base::GetTimestamp();
  reco_request_ = reco_request;
  need_user_dedup_ = false;
  SetTagInfo(reco_request, tag);
  // 为了展现时间轴卡片，有时间轴结果时，暂不使用缓存
  use_cache_ = config_->use_cache;
  if (tag_type_ == 1 && latest_item_id_ != 0) {
    LOG(INFO) << "cancel using cache for time_axis !";
    use_cache_ = false;
  }

  std::string cache_key;
  if (use_cache_) {
    cache_key = GetSearchCacheKey(query_);
    GetCachedItems(cache_key, now_timestamp_, item_list);
    if (!item_list->empty()) {  // 从缓存中取到数据了
      if(config_->do_user_dedup) {
        UserDedup(reco_request_, item_list, &(debug_info_.user_dedup));
      }
      if ((int)item_list->size() >= config_->return_num) {
        VLOG(1) << query_ << " use cache result, size: " << item_list->size();
        item_list->resize(config_->return_num);
        return true;
      } else {
        // 这个用户可能看过很多相关的内容，需要在检索过程中先做排重，否则可能结果不足
        need_user_dedup_ = true;
        item_list->clear();
      }
    } else {
      need_user_dedup_ = false;
      item_list->clear();
    }
  }
  VLOG(1) << query_ << " do search, need user dedup " << need_user_dedup_;

  std::vector<ItemInfo> candidate_item_list;
  // 开始真正进行一次检索
  std::vector<ItemInfo> ir_results;
  if (!Retrieve(&ir_results)) {
    VLOG(1) << "retrieve failed for: " << query_;
    return false;
  }
  debug_info_.ir_result = ir_results.size();

  Rank(ir_results, &candidate_item_list);

  ItemDedup(&candidate_item_list, manual_items_, &(debug_info_.item_dedup));
  debug_info_.fr_result = candidate_item_list.size();

  // need user dedup 时结果在触发阶段是预先做用户去重的
  if (use_cache_ && !need_user_dedup_) {
    std::vector<std::string> cache_str_list;
    for (size_t i = 0; i < candidate_item_list.size(); ++i) {
      cache_str_list.push_back(base::Uint64ToString(candidate_item_list[i].item_id));
    }
    LeafCache::SetCachedReco(cache_key, base::JoinStrings(cache_str_list, ","));
  }

  if(config_->do_user_dedup) {
    UserDedup(reco_request_, &candidate_item_list, &(debug_info_.user_dedup));
  }

  GetItemInfoForNItems(candidate_item_list, item_list, config_->return_num);

  if (debug_info != NULL) {
    *debug_info = debug_info_;
  }
  VLOG(1) << base::StringPrintf("query [%s], result size [%lu], debug info [%s]",
                                  query_.c_str(), item_list->size(),
                                  debug_info_.ToString().c_str());

  return true;
}

bool TagSearcher::Retrieve(std::vector<ItemInfo>* ir_results) {
  static const uint64 kMaxTraverse = 6000;
  // const uint64 real_max_num = uint64(kMaxTraverse * GetSysLevelRatio());
  uint64 real_max_num = uint64(kMaxTraverse * LeafDataManager::GetGlobalData()->GetSelectionRatio());
  if (!reco_request_->user_param_info.is_inner_qudao) {
    real_max_num /= 5;
  }

  // std::vector<int32> doc_id_list;
  std::vector<std::pair<int32, reco::IrType>> doc_id_list;
  std::vector<int32> tmp_id;

  if (!config_->retr_stem_vec.empty()) {
    for (size_t i = 0; i < config_->retr_stem_vec.size(); ++i) {
      if (doc_id_list.size() >= real_max_num) break;
      reco::IrType retr_stem = config_->retr_stem_vec.at(i);
      switch (retr_stem) {
        case kTagIr:
          if (doc_id_list.size() < kMaxTraverse) {
            tmp_id.clear();
            news_index_->GetDocsByTag(query_, &tmp_id, kMaxTraverse - doc_id_list.size());
            for (size_t j = 0; j < tmp_id.size(); ++j) {
              doc_id_list.push_back(std::make_pair(tmp_id[j], retr_stem));
            }
            // doc_id_list.insert(doc_id_list.end(), tmp_id.begin(), tmp_id.end());
          }
          break;
        case kSubscriptWordIr:
          if (doc_id_list.size() < real_max_num) {
            tmp_id.clear();
            news_index_->GetDocsByShowTag(query_, &tmp_id, real_max_num - doc_id_list.size());
            for (size_t j = 0; j < tmp_id.size(); ++j) {
              doc_id_list.push_back(std::make_pair(tmp_id[j], retr_stem));
            }
            // doc_id_list.insert(doc_id_list.end(), tmp_id.begin(), tmp_id.end());
          }
          break;
        case kSubscriptEventIr:
          if (doc_id_list.size() < real_max_num) {
            tmp_id.clear();
            news_index_->GetDocsByEventTag(query_, &tmp_id, real_max_num - doc_id_list.size());
            for (size_t j = 0; j < tmp_id.size(); ++j) {
              doc_id_list.push_back(std::make_pair(tmp_id[j], retr_stem));
            }
            // doc_id_list.insert(doc_id_list.end(), tmp_id.begin(), tmp_id.end());
          }
          break;
        case kSubscriptSourceIr:
          if (doc_id_list.size() < real_max_num) {
            tmp_id.clear();
            news_index_->GetDocsBySource(query_, &tmp_id, real_max_num - doc_id_list.size());
            for (size_t j = 0; j < tmp_id.size(); ++j) {
              doc_id_list.push_back(std::make_pair(tmp_id[j], retr_stem));
            }
            // doc_id_list.insert(doc_id_list.end(), tmp_id.begin(), tmp_id.end());
          }
          break;
        case kL1CategoryIr:
          if (doc_id_list.size() < kMaxTraverse) {
            tmp_id.clear();
            news_index_->GetDocsByCategory(query_, 0, &tmp_id, kMaxTraverse - doc_id_list.size());
            for (size_t j = 0; j < tmp_id.size(); ++j) {
              doc_id_list.push_back(std::make_pair(tmp_id[j], retr_stem));
            }
            // doc_id_list.insert(doc_id_list.end(), tmp_id.begin(), tmp_id.end());
          }
          break;
        case kSubscriptSubCateIr:
          if (doc_id_list.size() < real_max_num) {
            tmp_id.clear();
            news_index_->GetDocsByCategory(query_, 1, &tmp_id, real_max_num - doc_id_list.size());
            for (size_t j = 0; j < tmp_id.size(); ++j) {
              doc_id_list.push_back(std::make_pair(tmp_id[j], retr_stem));
            }
            // doc_id_list.insert(doc_id_list.end(), tmp_id.begin(), tmp_id.end());
          }
          break;
        default:
          break;
      }
    }
  } else {

    if (doc_id_list.size() < real_max_num) {
      tmp_id.clear();
      news_index_->GetDocsByCategory(query_, 0, &tmp_id, real_max_num - doc_id_list.size());
      // doc_id_list.insert(doc_id_list.end(), tmp_id.begin(), tmp_id.end());
      for (size_t j = 0; j < tmp_id.size(); ++j) {
        doc_id_list.push_back(std::make_pair(tmp_id[j], kDefaultIrType));
      }
    }

    if (doc_id_list.size() < real_max_num) {
      tmp_id.clear();
      news_index_->GetDocsByCategory(query_, 1, &tmp_id, real_max_num - doc_id_list.size());
      // doc_id_list.insert(doc_id_list.end(), tmp_id.begin(), tmp_id.end());
      for (size_t j = 0; j < tmp_id.size(); ++j) {
        doc_id_list.push_back(std::make_pair(tmp_id[j], kDefaultIrType));
      }
    }

    if (doc_id_list.size() < real_max_num) {
      tmp_id.clear();
      if (tag_type_ == 1) {
        news_index_->GetDocsByEventTag(query_, &tmp_id, real_max_num - doc_id_list.size());
      } else {
        news_index_->GetDocsByTag(query_, &tmp_id, real_max_num - doc_id_list.size());
      }
      // doc_id_list.insert(doc_id_list.end(), tmp_id.begin(), tmp_id.end());
      for (size_t j = 0; j < tmp_id.size(); ++j) {
        doc_id_list.push_back(std::make_pair(tmp_id[j], kDefaultIrType));
      }
    }
  }
  VLOG(1) << "after tag, doc_list_size:" << doc_id_list.size();

  ir_results->clear();

  // 插入时间轴最新进展
  if (tag_type_ == 1 && latest_item_id_ != 0) {
    ItemInfo item_info;
    if (!news_index_->GetItemInfoByItemId(latest_item_id_, &item_info, false)) {
      VLOG(1) << "time axis miss item_info ! item_id:" << latest_item_id_;
    } else {
      ir_results->push_back(item_info);
      VLOG(1) << "time axis latest_news ! item_id:" << latest_item_id_;
    }
  }

  VLOG(1) << "first shown size:" << reco_request_->shown_dict->size();

  reco::filter::Options filter_options;
  CandidatesExtractor::FillFilterOptions(&filter_options, kCandidateCategory, reco_request_);
  reco::filter::FilterReason filterno = reco::filter::kNoFiltered;
  CandidatesExtractor::FilterCount filter_count;

  std::vector<int64> region_id;
  std::string producer;
  for (int i = 0; i < (int)doc_id_list.size(); ++i) {
    if ((int)ir_results->size() > config_->ir_num) {
      break;
    }
    int doc_id = doc_id_list[i].first;
    reco::ItemInfo item_info;
    if (!news_index_->GetItemInfoByDocId(doc_id, &item_info, true)) {
      continue;
    }

    if (!IrCommonFilter(item_info, now_timestamp_)) {
      VLOG(1) << "ir common filter ! item_id:" << item_info.item_id;
      continue;
    }
    item_info.ir_type = doc_id_list[i].second;

    if (!FrCommonFilter(item_info)) {
      continue;
    }

    if (!GetSubCategoryByDocId(item_info)) {
      continue;
    }

    if (LeafDataManager::GetGlobalData()->filter_monster->Filter(item_info, &filter_options, &filterno)) {
      CandidatesExtractor::FillFilterCount(filter_count, filterno);
      continue;
    }

    uint64 item_id = item_info.item_id;
    reco::filter::FilterReason filter_reason;
    if (need_user_dedup_
        && NewsFilter::IsGeneralFiltered(reco_request_,
                                         reco_request_->shown_dict,
                                         item_info, &filter_reason, false)) {
      ++debug_info_.ir_user_dedup_filtered;
      VLOG(1) << item_id << " ir user dedup filtered";
      continue;
    }
    if (!CheckDeliverTime(item_id)) {
      VLOG(1) << "check deliver settings fail ! item_id:" << item_id;
      continue;
    }

    ir_results->push_back(item_info);
    VLOG(1) << item_id << " ir retrieved";
  }
  VLOG(1) << "ir_results list:" << ir_results->size();
  return true;
}

void TagSearcher::Rank(std::vector<ItemInfo>& fr_candidates,
                       std::vector<ItemInfo>* ranked_results) {
  TopN<int> topn(config_->fr_num * 1.2);
  std::vector<std::string> show_tags;

  // NOTE: ir 的结果，文档时间较新的会排在前面，而 topn 插入时，
  // 如果每个文档的分都一样，会把先插入的剔除掉，因此这里要对 ir 的结果从后往前计算 topn
  DocInfo doc_info;
  for (int i = (int)fr_candidates.size() - 1; i >=0; --i) {
    if (!news_index_->GetMetaInfo(fr_candidates[i].item_id, &(fr_candidates[i]))) {
      continue;
    }
    const reco::ItemInfo& item_info = fr_candidates[i];
    uint64 item_id = item_info.item_id;
    int32 doc_id = item_info.doc_id;

    if (!ItemLevelFilter(item_info)) {
      continue;
    }

    debug_info_.max_ctr = std::max(item_info.ctr, debug_info_.max_ctr);
    if (item_info.ctr < config_->ctr_low_threshold
        || item_info.show_num < config_->show_threshold) {
      ++debug_info_.fr_ctr_filtered;
      VLOG(1) << item_id << " fr ctr filtered";
      continue;
    }

    float boost = 0;
    if (config_->retr_stem_vec.empty()) {
      bool hit_showtag = false;
      bool get_tag_ret = false;
      show_tags.clear();
      if (tag_type_ == 1) {
        get_tag_ret = news_index_->GetEventTagByDocId(doc_id, &show_tags);
      } else {
        get_tag_ret = news_index_->GetShowTagByDocId(doc_id, &show_tags);
      }
      if (get_tag_ret && !show_tags.empty()) {
        auto it = std::find(show_tags.begin(), show_tags.end(), query_);
        if (it != show_tags.end()) {
          hit_showtag = true;
        }
      }
      if (config_->in_show_tag && !hit_showtag) {
        ++debug_info_.fr_showtag_filtered;
        VLOG(1) << item_id << " show tag filtered";
        continue;
      }

      if (hit_showtag) {
        VLOG(1) << item_id << " show tag boosted";
        boost += 2;
      }
    }
    if (item_info.time_level == reco::kGoodTimeliness) {
      VLOG(1) << item_id << " timelevel boosted";
      boost += 1;
    }
    if (item_info.item_type == reco::kPureVideo) {
      boost = std::min(1.0f, boost);
    }
    float ctr_discount = 1.0f;
    if (item_info.is_source_wemedia) {
      ctr_discount = 0.7f;
    } else if (item_info.item_type == reco::kPureVideo) {
      ctr_discount = FLAGS_tag_search_video_type_discount;  // 0.5f;
    }
    const int LEVEL1_BOOST = 20;
    const int LEVEL2_BOOST = 15;
    if (tag_type_ == 1 && item_id == latest_item_id_) {
      topn.add(i, LEVEL1_BOOST);
    } else if (news_index_->IsManualByDocId(doc_id)) {
      topn.add(i, LEVEL2_BOOST + item_info.ctr * ctr_discount);
      manual_items_.insert(item_id);
      VLOG(1) << "manual news boost ! item_id:" << item_id;
    } else {
      topn.add(i, boost + item_info.ctr * ctr_discount);
    }
    VLOG(1) << item_id << " topn added, "
            << item_info.item_type << " " << item_info.time_level << " " << boost
            << base::StringPrintf(" ctr[%.3f]", item_info.ctr);
  }

  std::vector<std::pair<int, double>> candidates;
  topn.get_top_n(&candidates);

  ranked_results->clear();
  for (int i = 0; i < (int)candidates.size(); ++i) {
    int idx = candidates[i].first;
    ranked_results->push_back(fr_candidates[idx]);
  }

  // topn 已经按照是否命中  show tag 和 ctr 来排序了
  // 不需要重新 sort
  // std::sort(ranked_results->begin(), ranked_results->end(), std::greater<ItemInfo>());
}

bool TagSearcher::CheckDeliverTime(const uint64& item_id) {
  base::Time curr_time = base::Time::Now();
  std::string str_curr_time;
  curr_time.ToStringInSeconds(&str_curr_time);

  // 检查是否是有效文章
  if (!news_index_->IsValidByItemId(item_id)) {
    VLOG(1) << "invalid item:" << item_id;
    return false;
  }
  // 检查文章是否过期
  if (news_index_->IsExpiredByItemId(item_id, base::GetTimestamp())) {
    VLOG(1) << "expire item:" << item_id;
    return false;
  }
  // 只对运营文章检查发布状态和生效时间
  UcBrowserDeliverSetting ucb_setting_proto;
  if (news_index_->GetUCBSettingByItemId(item_id, &ucb_setting_proto)) {
    // 未发布过滤
    if (ucb_setting_proto.has_is_published() && !ucb_setting_proto.is_published()) {
      VLOG(1) << "unpublished item:" << item_id;
      return false;
    }
    // 不在生效时间内过滤
    if ((ucb_setting_proto.has_start_time() && ucb_setting_proto.start_time() > str_curr_time)
        || (ucb_setting_proto.has_end_time() && ucb_setting_proto.end_time() < str_curr_time)) {
      VLOG(1) << "invalid deliver time item:" << item_id;
      return false;
    }
  }
  return true;
}

}  // namespace leafserver
}  // namespace reco
