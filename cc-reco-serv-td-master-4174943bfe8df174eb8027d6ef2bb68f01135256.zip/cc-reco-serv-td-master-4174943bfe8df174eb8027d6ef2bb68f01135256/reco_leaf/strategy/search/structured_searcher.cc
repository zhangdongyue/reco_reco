#include "reco/serv/reco_leaf/strategy/search/structured_searcher.h"

#include <vector>
#include <string>
#include "reco/serv/reco_leaf/common/leaf_cache.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/bizc/proto/reco_nlp_server.pb.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/proto/common.pb.h"
#include "nlp/common/nlp_util.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/reco_leaf/strategy/common/topn.h"
#include "reco/serv/reco_leaf/frame/connection_manager.h"
#include "nlp/common/nlp_util.h"
#include "ads_index/api/public.h"
#include "query/dnf/dnf_util.h"
#include "query/dnf/dnf_retrieval.h"
#include "query/parser_util/parser_util.h"
#include "extend/multi_strings/multi_pattern_matcher.h"

namespace reco {
namespace leafserver {

StructuredSearcher::StructuredSearcher(const reco::NewsIndex* news_index) : BaseSearcher(news_index, "SS") {
  nlp_service_ = new reco::nlpserver::NLPService::Stub(ConnectionManagerIns::instance().GetNlpServerGroup());
}

StructuredSearcher::~StructuredSearcher() {
  delete nlp_service_;
}

bool StructuredSearcher::Search(const RecoRequest* reco_request,
                                const std::vector<std::string>& and_words,
                                const std::vector<std::string>& or_words,
                                const std::vector<std::string>& not_words,
                                const Config& config,
                                std::vector<ItemInfo>* item_list,
                                DebugInfo* debug_info) {
  config_ = &config;
  debug_info_.Reset();
  now_timestamp_ = base::GetTimestamp();
  reco_request_ = reco_request;
  need_user_dedup_ = false;

  query_ = ToQuery(and_words, or_words, not_words);

  std::string cache_key;
  if (config_->use_cache) {
    cache_key = GetSearchCacheKey(query_);
    GetCachedItems(cache_key, now_timestamp_, item_list);
    if (!item_list->empty()) {  // 从缓存中取到数据了
      UserDedup(reco_request_, item_list, &(debug_info_.user_dedup));
      if ((int)item_list->size() >= config_->return_num) {
        VLOG(1) << query_ << " use cache result, size: " << item_list->size();
        item_list->resize(config_->return_num);
        return true;
      } else {
        // 这个用户可能看过很多相关的内容，需要在检索过程中先做排重，否则可能结果不足
        need_user_dedup_ = true;
        item_list->clear();
      }
    } else {
      need_user_dedup_ = false;
      item_list->clear();
    }
  }
  VLOG(1) << query_ << " do search, need user dedup " << need_user_dedup_;

  // 开始真正进行一次检索
  queries::QueryTree include_dnf_tree;
  queries::QueryTree exclude_dnf_tree;
  ParseQuery(and_words, or_words, not_words, &include_dnf_tree, &exclude_dnf_tree);

  std::vector<ItemInfo> ir_results;
  if (!Retrieve(include_dnf_tree, exclude_dnf_tree, &ir_results)) {
    return false;
  }
  debug_info_.ir_result = ir_results.size();

  Rank(include_dnf_tree, ir_results, item_list);
  ItemDedup(item_list, &(debug_info_.item_dedup));
  debug_info_.fr_result = item_list->size();

  // need user dedup 时结果在触发阶段是预先做用户去重的
  if (config_->use_cache && !need_user_dedup_) {
    std::vector<std::string> cache_str_list;
    for (size_t i = 0; i < item_list->size(); ++i) {
      cache_str_list.push_back(base::Uint64ToString((*item_list)[i].item_id));
    }
    LeafCache::SetCachedReco(cache_key, base::JoinStrings(cache_str_list, ","));
  }

  UserDedup(reco_request_, item_list, &(debug_info_.user_dedup));
  if ((int)item_list->size() > config_->return_num) {
    item_list->resize(config_->return_num);
  }

  if (debug_info != NULL) {
    *debug_info = debug_info_;
  }

  VLOG(1) << base::StringPrintf("query [%s], result size [%lu], debug info [%s]",
                                query_.c_str(), item_list->size(),
                                debug_info_.ToString().c_str());

  return true;
}

bool StructuredSearcher::ParseQuery(const std::vector<std::string>& and_words,
                                    const std::vector<std::string>& or_words,
                                    const std::vector<std::string>& not_words,
                                    queries::QueryTree* include_dnf_tree,
                                    queries::QueryTree* exclude_dnf_tree) {
  reco::nlpserver::StructuredQueryRequest nlp_request;
  reco::nlpserver::StructuredQueryResponse nlp_response;

  for (size_t i = 0; i < and_words.size(); ++i) {
    nlp_request.add_and_words(and_words[i]);
  }

  for (size_t i = 0; i < or_words.size(); ++i) {
    nlp_request.add_or_words(or_words[i]);
  }

  for (size_t i = 0; i < not_words.size(); ++i) {
    nlp_request.add_not_words(not_words[i]);
  }

  net::rpc::RpcClientController controller;
  nlp_service_->structuredQueryAnalyze(&controller, &nlp_request, &nlp_response, NULL);
  controller.Wait();

  if (controller.status() != stumy::RpcController::kOk
      || !nlp_response.success()) {
    LOG(WARNING) << "structured query analyze failed";
    return false;
  }

  queries::QueryTree include_tree;
  if (nlp_response.has_include_tree()) {
    if (!include_tree.FromString(nlp_response.include_tree())) {
      LOG(WARNING) << "parse include tree failed: " << nlp_response.include_tree();
      return false;
    }
    if (include_tree.root() != NULL) {
      queries::QueryTreeNode* dnf_root = queries::BuildDNF(include_tree.root(), 40);
      if (NULL == dnf_root) {
        std::string dump;
        include_tree.ToString(&dump);
        LOG(WARNING) << "failed to convert dnf: " << dump;
        return false;
      }
      include_dnf_tree->set_root(dnf_root);
    } else {
      return false;
    }
  }

  queries::QueryTree exclude_tree;
  if (nlp_response.has_exclude_tree()) {
    if (!exclude_tree.FromString(nlp_response.exclude_tree())) {
      LOG(ERROR) << "parse include tree failed: " << nlp_response.exclude_tree();
      return false;
    }
    if (exclude_tree.root() != NULL) {
      queries::QueryTreeNode* dnf_root = queries::BuildDNF(exclude_tree.root(), 40);
      if (NULL == dnf_root) {
        std::string dump;
        exclude_tree.ToString(&dump);
        LOG(WARNING) << "failed to convert dnf: " << dump;
        return false;
      }
      exclude_dnf_tree->set_root(dnf_root);
    } else {
      return false;
    }
  }

  std::string dump_include, dump_exclude;
  include_tree.ToString(&dump_include);
  exclude_tree.ToString(&dump_exclude);
  VLOG(1) << "query trees: include " << dump_include << ", exclude: " << dump_exclude;
  return true;
}

bool StructuredSearcher::Retrieve(const queries::QueryTree& dnf_include_tree,
                                  const queries::QueryTree& dnf_exclude_tree,
                                  std::vector<ItemInfo>* ir_results) {
  ir_results->clear();

  for (auto it = terms_map_.begin(); it != terms_map_.end(); ++it) {
    if (it->second != NULL) {
      delete it->second;
    }
  }
  terms_map_.clear();

  include_docid_set_.clear();
  RetrieveDocId(dnf_include_tree, &include_docid_set_);

  exclude_docid_set_.clear();
  RetrieveDocId(dnf_exclude_tree, &exclude_docid_set_);

  // docid 从小到大排序的，新文档已经在前面了
  std::vector<int64> region_id;
  std::string producer;
  for (auto it = include_docid_set_.begin(); it != include_docid_set_.end(); ++it) {
    if ((int)ir_results->size() >= config_->ir_num) {
      break;
    }

    int32 doc_id = *it;

    if (exclude_docid_set_.find(doc_id) != exclude_docid_set_.end()) {
      continue;
    }

    reco::ItemInfo item_info;
    if (!news_index_->GetItemInfoByDocId(doc_id, &item_info, false)) {
      continue;
    }
    if (!IrCommonFilter(item_info, now_timestamp_)) {
      continue;
    }

    uint64 item_id = item_info.item_id;
    reco::filter::FilterReason filter_reason;
    if (need_user_dedup_
        && NewsFilter::IsGeneralFiltered(reco_request_,
                                         reco_request_->shown_dict,
                                         item_info, &filter_reason, false)) {
      ++debug_info_.ir_user_dedup_filtered;
      VLOG(1) << item_id << " ir user dedup filtered";
      continue;
    }

    ir_results->push_back(item_info);
  }

  return true;
}

adsindexing::DocIterator* StructuredSearcher::GetDocIter(const std::string &literal,
                                                         adsindexing::TermType type) {
  auto pr = std::make_pair(literal, type);
  auto it = terms_map_.find(pr);
  if (it != terms_map_.end()) return it->second;

  auto doc_it = index_->NewDocIterator(literal, type);
  // term->size = (term->doc_it == NULL)? 0 : term->doc_it->GetSize();

  terms_map_[pr] = doc_it;
  return doc_it;
}

void StructuredSearcher::RetrieveDocId(const queries::QueryTree& dnf_tree,
                                       std::set<int32>* docid_set) {
  const queries::QueryTreeNode* root = dnf_tree.root();
  if (root == NULL) return;

  std::vector<std::pair<int, adsindexing::DocIterator *> > doc_its;
  std::vector<int> merge_results;
  for (auto query_root = root->first_child();
       query_root != NULL; query_root = query_root->next_sibling()) {
    // for each query
    doc_its.clear();
    merge_results.clear();
    for (auto phrase = query_root->first_child(); phrase != NULL; phrase = phrase->next_sibling()) {
      if (phrase->type() == queries::QueryTreeNode::kLeaf) {
        // DLOG(INFO) << phrase->literal();
        auto it = GetDocIter(phrase->literal(), adsindexing::kUnigramTerm);
        if (it != NULL) {
          it->Reset();
          doc_its.push_back(std::make_pair(it->GetSize(), it));
        }
      } else {
        // TODO: phrase 检索现在是通过 bigram 命中来近似
        // 极端情况下，有可能bigram命中但不是连续命中
        // 后续考虑解决
        for (auto leaf = phrase->first_child(); leaf != NULL; leaf = leaf->next_sibling()) {
          // query parse 保证 phrase 下不会只有一个节点
          if (leaf == phrase->first_child()) continue;
          CHECK_NOTNULL(leaf->prev_sibling());
          std::string literal = leaf->prev_sibling()->literal() + "\t" + leaf->literal();
          // DLOG(INFO) << literal;
          auto it = GetDocIter(literal, adsindexing::kBigramTerm);
          if (it != NULL) {
            it->Reset();
            doc_its.push_back(std::make_pair(it->GetSize(), it));
          }
        }
      }
    }

    if (doc_its.empty()) continue;

    // 多路合并
    int ir_seek = 0;
    std::sort(doc_its.begin(), doc_its.end());
    auto first_it = doc_its[0].second;
    merge_results.clear();
    for (; !first_it->Done() && (int)merge_results.size() < config_->ir_num; first_it->Next()) {
      merge_results.push_back(first_it->GetDocLocalId());
    }
    // DLOG(INFO) << merge_results.size();
    for (int i = 1; i < (int)doc_its.size(); ++i) {
      auto merge_it = doc_its[i].second;
      int total_remain = 0;
      for (int result_id = 0; result_id < (int)merge_results.size(); ++result_id) {
        if (merge_it->Seek(merge_results[result_id])) {
          merge_results[total_remain++] = merge_results[result_id];
        }
      }
      ir_seek += merge_results.size();
      if (ir_seek > config_->ir_num) {
        break;
      }
      merge_results.resize(total_remain);
    }
    for (int i = 0; i < (int)merge_results.size(); ++i) {
      docid_set->insert(merge_results[i]);
    }
  }
}

void StructuredSearcher::Rank(const queries::QueryTree &ranking_tree,    // dnf tree
                              const std::vector<ItemInfo>& fr_candidates,
                              std::vector<ItemInfo>* ranked_results) {
  query_infos_.clear();
  for (auto node = ranking_tree.root()->first_child();
       node != NULL; node = node->next_sibling()) {
    QueryInfo query_info;
    query_infos_.push_back(query_info);
    query_infos_.back().FillQueryInfo(node, index_);
  }

  if (query_infos_.empty()) return;

  TopN<int> topn(config_->fr_num * 1.2);

  // NOTE: ir 的结果，文档时间较新的会排在前面，而 topn 插入时，
  // 如果每个文档的分都一样，会把先插入的剔除掉，因此这里要对 ir 的结果从后往前计算 topn
  DocInfo doc_info;
  for (int i = (int)fr_candidates.size() - 1; i >=0; --i) {
    const reco::ItemInfo& item_info = fr_candidates[i];
    uint64 item_id = item_info.item_id;
    int doc_id = item_info.doc_id;

    if (!FrCommonFilter(item_info)) {
      continue;
    }

    debug_info_.max_ctr = std::max(item_info.ctr, debug_info_.max_ctr);
    if (item_info.ctr < config_->ctr_low_threshold
        || item_info.show_num < config_->show_threshold) {
      ++debug_info_.fr_ctr_filtered;
      VLOG(1) << item_id << " fr ctr filtered";
      continue;
    }

    // 计算相关性
    doc_info.Clear();
    doc_info.FillDocInfo(doc_id, index_);

    float max_score = 0;
    bool title_all_hit = false;
    for (size_t j = 0; j < query_infos_.size(); ++j) {
      bool hit = false;
      float score = CalcFinalRelScore(item_id, config_->title_rel_coef, config_->keyword_rel_coef,
                                      query_infos_[j], doc_info, &hit);
      if (score > max_score) {
        max_score = score;
      }
      if (hit) {
        title_all_hit = true;
      }
    }

    if (config_->title_all_hit && !title_all_hit) {
      ++debug_info_.fr_title_hit_filtered;
      VLOG(1) << item_id << " fr title hit filtered";
      continue;
    }

    debug_info_.max_rel = std::max(max_score, debug_info_.max_rel);
    if (max_score < config_->rel_low_threshold) {
      // 相关性低于最低门限，直接 pass
      ++debug_info_.fr_rel_filtered;
      VLOG(1) << item_id << " fr rel filtered";
      continue;
    } else if (max_score < config_->rel_high_threshold) {
      // 相关性一般，要求 ctr 高
      if (item_info.ctr < config_->ctr_high_threshold) {
        ++debug_info_.fr_ctr_filtered;
        VLOG(1) << item_id << " fr ctr filtered";
        continue;
      }
    } else {
      // 相关性高，放低 ctr 要求 此时是以 low ctr 阈值过来的
    }

    topn.add(i, max_score);
    VLOG(1) << item_id << " topn added, "
            << base::StringPrintf("ctr[%.3f] rel[%.3f]", item_info.ctr, max_score);
  }

  std::vector<std::pair<int, double>> candidates;
  topn.get_top_n(&candidates);

  ranked_results->clear();
  for (int i = 0; i < (int)candidates.size(); ++i) {
    int idx = candidates[i].first;
    ranked_results->push_back(fr_candidates[idx]);
  }

  std::sort(ranked_results->begin(), ranked_results->end(), std::greater<ItemInfo>());
}
}  // namespace leafserver
}  // namespace reco
