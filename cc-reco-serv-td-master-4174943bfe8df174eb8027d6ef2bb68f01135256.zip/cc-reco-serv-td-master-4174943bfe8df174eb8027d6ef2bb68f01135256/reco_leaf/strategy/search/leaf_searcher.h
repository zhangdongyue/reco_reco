#pragma once
#include <vector>
#include <unordered_map>
#include <map>
#include <string>

#include "base/common/basic_types.h"
#include "base/time/time.h"
#include "reco/bizc/reco_index/item_info.h"
#include "query/tree/query_tree.h"
#include "query/dnf/dnf_retrieval.h"
#include "reco/serv/reco_leaf/strategy/search/base_searcher.h"
#include "reco/serv/reco_leaf/strategy/common/reco_request.h"

namespace  adsindexing {
class Index;
}

namespace queries {
class DNFRetrieval;
}

namespace reco {

class NewsIndex;

namespace leafserver {
class LeafSearcher : public BaseSearcher {
 public:
  LeafSearcher(const reco::NewsIndex* news_index);
  ~LeafSearcher();

  // NOTE return_num 最多是 kFrReturnNum
  bool Search(const RecoRequest* reco_request,
              const std::string& orig_query,
              const Config& config,
              std::vector<ItemInfo>* item_list,
              DebugInfo* debug_info);

 private:
  bool ParseQuery(queries::QueryTree* dnf_tree);
  bool Retrieve(const queries::QueryTree& dnf_tree,
                std::vector<std::pair<queries::ARCollector::Result, ItemInfo>>* ir_results);
  void Rank(const queries::QueryTree &ranking_tree,
            std::vector<std::pair<queries::ARCollector::Result, ItemInfo>>& fr_candidates,
            std::vector<ItemInfo>* ranked_results);
  // 直接从 index 获取 query 抓取结果
  bool GetQueryCrawlResults(std::vector<ItemInfo>* item_list, int max_return_num);

  ::queries::DNFRetrieval *dnf_retrieval_;
  reco::nlpserver::NLPService::Stub* nlp_service_;

  // 每次请求相关的参数
  std::vector<QueryInfo> query_infos_;
  int64 now_timestamp_;  // 当前的时间戳
  const RecoRequest* reco_request_;  // 请求相关的信息
  bool need_user_dedup_;  // 是否需要在检索时做用户去重
  std::string query_;
};
}  // leafserver
}  // reco
