#include "reco/serv/reco_leaf/strategy/search/match_function.h"

#include <algorithm>
#include <map>
#include <unordered_map>
#include "base/container/dense_hash_map.h"

namespace reco {
namespace leafserver {

void GetTermMatchedNum(const std::vector<std::string> tokens,
                       int window_size,
                       std::vector<int> *unigram_result,
                       std::vector<int> *bigram_result) {
  unigram_result->resize(tokens.size(), 0);
  if (tokens.size()) {
    bigram_result->resize(tokens.size()-1, 0);
  } else {
    bigram_result->clear();
  }

  std::map<std::string, int> bigram_matched_num;
  std::map<std::string, int> unigram_match_num;
  std::map<std::string, int> max_unigram_matched_num;
  std::map<std::string, int> max_bigram_matched_num;
  int window_end = 0;
  for (int i = 0; i < (int)tokens.size(); ++i) {
    while (window_end < i+window_size && window_end < (int)tokens.size()) {
      const std::string &term = tokens[window_end];
      max_unigram_matched_num[term] = std::max(max_unigram_matched_num[term], ++unigram_match_num[term]);
      if (window_end > 0 && window_size > 1) {
        std::string bigram = tokens[window_end-1]+"\t"+tokens[window_end];
        max_bigram_matched_num[bigram] = std::max(max_bigram_matched_num[bigram],
                                                  ++bigram_matched_num[bigram]);
      }
      ++window_end;
    }
    // move out of the window
    --unigram_match_num[tokens[i]];
    if (i < (int)tokens.size() - 1 && window_size > 1) {
      --bigram_matched_num[tokens[i]+"\t"+tokens[i+1]];
    }
  }
  for (int i = 0; i < (int)tokens.size(); ++i) {
    unigram_result->at(i) = max_unigram_matched_num[tokens[i]];
    if (i < (int)tokens.size() - 1) {
      bigram_result->at(i) = max_bigram_matched_num[tokens[i]+"\t"+tokens[i+1]];
    }
  }
}

void GetQueryTermMatchedNum(const std::vector<std::string> query_terms,
                            const std::vector<std::string> tokens,
                            int *bigram_hits, int *skipped_bigram_hits) {
  int hit_bigram = 1;
  int hit_skiped_bigram = 2;
  *bigram_hits = 0;
  *skipped_bigram_hits = 0;
  std::map<std::string, int> bigrams;
  std::map<std::string, int> skipped_bigrams;
  for (int i = 0; i < (int)query_terms.size(); ++i) {
    if (i > 0) {
      bigrams[query_terms[i-1]+"\t"+query_terms[i]] = 0;
    }
    if (i > 1) {
      skipped_bigrams[query_terms[i-2]+"\t"+query_terms[i]] = 0;
    }
  }

  for (int i = 0; i < (int)tokens.size(); ++i) {
    if (i > 0) {
      std::string literal = tokens[i-1]+"\t"+tokens[i];
      if (bigrams.count(literal) != 0) {
        bigrams[literal] |= hit_bigram;
      }
    }
    if (i > 1) {
      std::string literal = tokens[i-2]+"\t"+tokens[i];
      if (bigrams.count(literal) != 0) {
        bigrams[literal] |= hit_skiped_bigram;
      }
      if (skipped_bigrams.count(literal) != 0) {
        skipped_bigrams[literal] |= hit_skiped_bigram;
      }
    }
  }

  for (auto it = bigrams.begin(); it != bigrams.end(); ++it) {
    if (it->second & hit_bigram) {
      (*bigram_hits)++;
    } else if (it->second & hit_skiped_bigram) {
      (*skipped_bigram_hits)++;
    }
  }
  for (auto it = skipped_bigrams.begin(); it != skipped_bigrams.end(); ++it) {
    if (it->second & hit_skiped_bigram) {
      (*skipped_bigram_hits)++;
    }
  }
}

struct BigramId {
  BigramId(int64 left, int64 right) {
    first_term = left;
    second_term = right;
  }
  bool operator <(const BigramId &obj) const {
    if (first_term < obj.first_term) {
      return true;
    }
    if (first_term > obj.first_term) {
      return false;
    }
    if (second_term < obj.second_term) {
      return true;
    }
    return false;
  }
  bool operator ==(const BigramId &obj) const {
    if (first_term == obj.first_term && second_term == obj.second_term) {
      return true;
    } else {
      return false;
    }
  }
  int64 first_term;
  int64 second_term;
};

inline static int128 Int128FromInt64Pair(int64 num1, int64 num2) {
  return (static_cast<int128>(num1) << 64) | num2;
}

inline static void Int64PairFromInt128(const int128& num, int64* num1, int64* num2) {
  *num1 = static_cast<int64>(num >> 64);
  *num2 = static_cast<int64>(num & ((static_cast<int128>(1) << 64) -1));
}

struct int128_hash {
  size_t operator() (const int128& num) const {
    int64 num1;
    int64 num2;
    Int64PairFromInt128(num, &num1, &num2);
    return (num1 & 0xF0F0F0F0F0F0F0F0Lu) | (num2 & 0xF0F0F0F0F0F0F0FLu);
  }
};

void GetQueryTermMatchedNum(const std::vector<int64> query_terms,
                            const std::vector<int64> tokens,
                            int *bigram_hits, int *skipped_bigram_hits) {
  int hit_bigram = 1;
  int hit_skiped_bigram = 2;
  *bigram_hits = 0;
  *skipped_bigram_hits = 0;
  base::dense_hash_map<int128, int, int128_hash> bigrams;
  bigrams.set_empty_key(-1);
  base::dense_hash_map<int128, int, int128_hash> skipped_bigrams;
  skipped_bigrams.set_empty_key(-1);
  for (int i = 0; i < (int)query_terms.size(); ++i) {
    if (query_terms[i] < 0) continue;
    if (i > 0) {
      if (query_terms[i-1] >= 0) {
        bigrams[Int128FromInt64Pair(query_terms[i-1], query_terms[i])] = 0;
      }
    }
    if (i > 1) {
      if (query_terms[i-2] >= 0) {
        skipped_bigrams[Int128FromInt64Pair(query_terms[i-2], query_terms[i])] = 0;
      }
    }
  }

  for (int i = 0; i < (int)tokens.size(); ++i) {
    if (tokens[i] < 0) continue;
    if (i > 0 && tokens[i-1] >= 0) {
      int128 literal = Int128FromInt64Pair(tokens[i-1], tokens[i]);
      if (bigrams.count(literal) != 0) {
        bigrams[literal] |= hit_bigram;
      }
    }
    if (i > 1 && tokens[i-2] >= 0) {
      int128 literal = Int128FromInt64Pair(tokens[i-2], tokens[i]);
      if (bigrams.count(literal) != 0) {
        bigrams[literal] |= hit_skiped_bigram;
      }
      if (skipped_bigrams.count(literal) != 0) {
        skipped_bigrams[literal] |= hit_skiped_bigram;
      }
    }
  }

  for (auto it = bigrams.begin(); it != bigrams.end(); ++it) {
    if (it->second & hit_bigram) {
      (*bigram_hits)++;
    } else if (it->second & hit_skiped_bigram) {
      (*skipped_bigram_hits)++;
    }
  }
  for (auto it = skipped_bigrams.begin(); it != skipped_bigrams.end(); ++it) {
    if (it->second & hit_skiped_bigram) {
      (*skipped_bigram_hits)++;
    }
  }
}

void FindMaxCommonSequence(const std::vector<int64> &query,
                           const std::vector<int64> &window,
                           std::vector<int> *query_term_id,
                           std::vector<int> *output) {
  CHECK_NOTNULL(output);
  output->clear();

  // get max common sequence
  std::vector<std::vector<int>> max_len;
  // add stop word in window
  int global_max_len = -1;
  int global_max_x = -1;
  int global_max_y = -1;
  for (int i = 0; i <= (int)query.size(); ++i) {
    max_len.push_back(std::vector<int>());
    for (int j = 0; j <= (int) window.size(); ++j) {
      if (i == 0 || j == 0) {
        max_len.back().push_back(0);
        continue;
      }
      // 如果非零  表示是一个中断位
      if (window[j - 1] < 0) {
        max_len.back().push_back(0);
        continue;
      }
      if (query[i-1] == window[j-1] && query[i-1] >= 0) {
        max_len.back().push_back(max_len[i-1][j-1]+1);
      } else {
        max_len.back().push_back(std::max(max_len[i-1][j], max_len[i][j-1]));
      }
      int current_value = max_len.back().back();
      // 同样取值保留靠后的, 为了与之前实现一致
      // 因此这里用 >= 而非 >
      if (current_value >= global_max_len) {
        global_max_len = current_value;
        global_max_x = i;
        global_max_y = j;
      }
    }
  }
  if (global_max_len < 0) {
    // 没有一个命中 直接退出
    return;
  }
  // get sequence id
  int x = global_max_x;
  int y = global_max_y;
  if (query_term_id != NULL) {
    query_term_id->clear();
  }
  while (max_len[x][y] > 0) {
    if (query[x-1] == window[y-1]) {
      output->push_back(y-1);
      if (query_term_id != NULL) {
        query_term_id->push_back(x-1);
      }
      x--;
      y--;
    } else {
      if (max_len[x-1][y] > max_len[x][y-1]) {
        x--;
      } else {
        y--;
      }
    }
  }
  // reverse
  for (size_t i = 0; i < output->size() / 2; ++i) {
    std::swap((*output)[i], (*output)[output->size()-1-i]);
  }
  if (query_term_id != NULL) {
    for (size_t i = 0; i < query_term_id->size() / 2; ++i) {
      std::swap((*query_term_id)[i], (*query_term_id)[query_term_id->size()-1-i]);
    }
  }
}

}  // namespace searchserver
}  // namespace reco
