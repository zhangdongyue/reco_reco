#include "reco/serv/reco_leaf/strategy/user_feature/category_selector.h"

#include <string>
#include <unordered_map>
#include <vector>

#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "serving_base/data_manager/data_manager.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

DECLARE_string(category_cf_dict_file);
DEFINE_double(category_cf_weight, 0, "category_cf_weight");
DEFINE_double(max_category_limit, 1.2, "the max category limit");
DEFINE_double(cate_select_min_st_click, 2.0, "min click of st");
DEFINE_int32(cate_select_min_st_num, 6, "cate select min st num");
DEFINE_int32(cate_select_min_lt_num, 6, "cate select min lt num");
DEFINE_bool(filter_girl_pic, true, "filter girl pic");

const char* CategorySelector::kDefaultIflowCategories[] = { "科技", "体育", "健康", "军事", "历史", "国际",
  "奇闻", "娱乐", "干货", "房产", "收藏", "教育", "旅游", "时尚", "星座", "汽车", "游戏", "社会", "科学探索",
  "美食", "职场", "育儿", "财经", "两性情感", "国内", };

const std::unordered_set<std::string> CategorySelector::social_categories_ = {"社会", "国内", "国际"};
// 北上广深杭
const std::unordered_set<int64> CategorySelector::big_citys_ = {10, 20, 21, 755, 571,};

const std::unordered_set<std::string> CategorySelector::big_city_add_weight_categories_
    = {"财经", "科技", "国内", "职场"};

const std::unordered_set<std::string> CategorySelector::big_city_sub_weight_categories_
    = {"两性", "奇闻", "社会", "游戏"};

const float CategorySelector::kMaxCategoryShowRatio = 0.5;
const int   CategorySelector::kMaxCategoryPerRequest = 6;

CategorySelector::CategorySelector(const reco::NewsIndex* news_index) {
  news_index_ = news_index;
  global_data_ = LeafDataManager::GetGlobalData();
  random_ = new base::PseudoRandom(base::GetTimestamp());
  iflow_categories_ = &LeafDataManager::GetGlobalData()->qudao_categories_dict;
  for(size_t i = 0; i < ARRAYSIZE_UNSAFE(kDefaultIflowCategories); ++i) {
    default_iflow_categories_.insert(kDefaultIflowCategories[i]);
  }
}

CategorySelector::~CategorySelector() {
  delete random_;
}

void CategorySelector::GetCandidateRawCategory(const RecommendRequest* request,
                                               const UserInfo* user_info,
                                               const UserFeature* user_fea,
                                               std::vector<reco::Category>* raw_categories) {
  // if filter girl pic
  base::Time current_time = base::Time::Now();
  bool filter_girl_pic = false;
  base::Time::Exploded exploded;
  current_time.LocalExplode(&exploded);
  if ((6 <= exploded.hour && exploded.hour < 22)
      || big_citys_.find(user_fea->attr.city_id) != big_citys_.end()) {
    filter_girl_pic = true;
  }
  // NOTE(jianhuang) 大城市 / 新用户 暂时不下发两性情感文章
  // TODO(jianhuang）后续根据时间 / 用户 profile 进行控制
  bool filter_sex_item = false;
  if ((request->has_is_new_user() && request->is_new_user())
      || big_citys_.find(user_fea->attr.city_id) != big_citys_.end()) {
    filter_sex_item = true;
  }

  std::vector<reco::Category> all_categories;
  news_index_->GetCategories(0, &all_categories);

  const std::unordered_set<std::string>* p_categories = NULL;
  std::unordered_map<std::string, std::unordered_set<std::string> >::iterator iflow_iter;
  iflow_iter = iflow_categories_->find(request->app_token());
  if (iflow_iter != iflow_categories_->end()) {
    p_categories = &(iflow_iter->second);
  } else {
    p_categories = &default_iflow_categories_;
    VLOG(1) << "use the default categories. app_token:" << request->app_token();
  }

  for (int i = 0; i < (int)all_categories.size(); ++i) {
    const std::string& category = all_categories[i].category();
    if (p_categories->find(category) == p_categories->end()) continue;
    if (FLAGS_filter_girl_pic && filter_girl_pic && category == reco::common::kGirlCategory) continue;
    if (filter_sex_item && category == reco::common::kBoudoirCategory) continue;
    raw_categories->push_back(all_categories[i]);
  }
}

void CategorySelector::CategoryCfTuner(base::dense_hash_map<std::string,
                                       std::pair<int, float> >* category_counter) {
  base::dense_hash_map<std::string, float> score;
  score.set_empty_key("");
  // Init Score
  for (auto c_counter_iter = category_counter->begin();
       c_counter_iter != category_counter->end(); ++c_counter_iter) {
    score[c_counter_iter->first] = 0.0;
  }
  for (auto c_counter_iter = category_counter->begin();
       c_counter_iter != category_counter->end(); ++c_counter_iter) {
    if (c_counter_iter->second.second == 0)
      continue;
    auto cf_dict_iter = global_data_->category_cf_dict.find(c_counter_iter->first);
    if (cf_dict_iter == global_data_->category_cf_dict.end())
      continue;
    const std::unordered_map<std::string, float>& category_cf_per = cf_dict_iter->second;
    for (auto cf_iter = category_cf_per.begin(); cf_iter != category_cf_per.end(); ++cf_iter) {
      auto partner_iter = category_counter->find(cf_iter->first);
      if (partner_iter == category_counter->end())
        continue;
      // 保持cf加权后 AB类别的分值比率不变
      float inc_ratio = partner_iter->second.second / c_counter_iter->second.second;
      score[cf_iter->first] += c_counter_iter->second.second * cf_iter->second * inc_ratio;
      score[c_counter_iter->first] += c_counter_iter->second.second * cf_iter->second;
    }
  }
  for (auto c_counter_iter = category_counter->begin();
       c_counter_iter != category_counter->end(); ++c_counter_iter) {
    auto score_iter = score.find(c_counter_iter->first);
    if (score_iter != score.end()) {
      c_counter_iter->second.second += score_iter->second * FLAGS_category_cf_weight;
    }
  }
}

void CategorySelector::CategoryFromRole(const RecommendRequest* request,
                                        const UserInfo* user_info, const UserFeature* user_fea,
                                        std::unordered_map<std::string, float>* category_score_map) {
  category_score_map->clear();

  if (!user_info->has_user_role() || user_info->user_role().user_image_size() == 0) return;

  // 用户角色选择
  const reco::user::UserRole& user_role = user_info->user_role();
  base::Time set_time;
  if (!base::Time::FromStringInFormat(user_role.user_image_setting_time().c_str(),
                                      "%Y-%m-%d %H:%M:%S", &set_time)) {
    LOG(WARNING) << "user role settime format error, " << user_role.user_image_setting_time();
    return;
  }
  // 太久之前选择的丢弃掉
  base::TimeDelta delta = base::Time::Now() - set_time;
  int day_interval  = delta.InDays();
  int hour_interval = delta.InHours();
  const int kDiscardDay = 90;
  if (hour_interval < 0 || day_interval >= kDiscardDay) {
    return;
  }
  const int kExpiredDay = 30;
  if (user_fea->lt_fea.click_num >= 30 && day_interval >= kExpiredDay) {
    return;
  }
  // 设定角色后已经有多少次展现了
  int64 set_timestamp = set_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int shown_num_after_set = 0;
  for (int i = user_info->shown_history_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& show_item = user_info->shown_history(i);
    if (show_item.view_timestamp() < set_timestamp) break;
    if (show_item.has_channel_id() && show_item.channel_id() == 100) {
      ++shown_num_after_set;
    }
  }
  const int kMaxShownAfterSet = 2000;
  if (shown_num_after_set >= kMaxShownAfterSet) {
    return;
  }
  // 根据用户画像丰富程度，决定角色选择的使用程度
  float ratio = 0;
  if (user_fea->lt_fea.click_num >= 40) {
    ratio = 0.4;
  } else if (user_fea->lt_fea.click_num >= 20) {
    ratio = 0.45;
  } else if (user_fea->lt_fea.click_num >= 10) {
    ratio = 0.5;
  } else if (user_fea->lt_fea.click_num >= 5) {
    ratio = 0.55;
  } else if (user_fea->lt_fea.click_num > 0) {
    ratio = 0.6;
  } else {
    ratio = 0.7;
  }
  float time_infl_discount = 1;
  if (hour_interval >= 24) {
    time_infl_discount = std::pow((kDiscardDay - day_interval) * 1.0 / kDiscardDay, 2);
  }
  float req_infl_discount = std::pow(0.9, shown_num_after_set * 1.0 / 100);
  float influence = ratio * std::min(time_infl_discount, req_infl_discount);
  if (influence < 1e-5) return;
  // 根据角色推荐哪些类别
  const auto l1_cates = user_fea->merged_fea.l1_cates;
  std::unordered_map<std::string, float> tmp_category_map;
  const auto role_category_map = &LeafDataManager::GetGlobalData()->user_role_categories;
  for (int i = 0; i < user_role.user_image_size(); ++i) {
    const std::string& role = user_role.user_image(i);
    auto iter = role_category_map->find(role);
    if (iter == role_category_map->end()) {
      LOG(WARNING) << "role not in role cateogry map. " << role;
      continue;
    }
    const std::vector<std::pair<std::string, float> >& category_vec = iter->second;
    for (size_t jdx = 0; jdx < category_vec.size(); ++jdx) {
      const std::string& category = category_vec[jdx].first;
      auto l1_iter = l1_cates.find(category);
      if (l1_iter != l1_cates.end() && l1_iter->second >= 0.15) {
        continue;
      }
      float weight = category_vec[jdx].second;
      double random_ratio = 0.01 + random_->GetDouble();
      tmp_category_map[category] += weight * random_ratio;
    }
  }
  if (tmp_category_map.empty()) return;

  std::vector<std::pair<float, std::string> > tmp_vec;
  for (auto iter = tmp_category_map.begin(); iter != tmp_category_map.end(); ++iter) {
    tmp_vec.push_back(std::make_pair(iter->second, iter->first));
  }
  std::sort(tmp_vec.begin(), tmp_vec.end(), std::greater<std::pair<float, std::string> >());

  // 决定此批次下发使用哪些角色涉及的类别
  float ratio_per_category = request->return_num() < 10 ? 0.15 : 0.1;
  ratio_per_category = std::max(ratio_per_category,
                                std::min(influence / tmp_vec.size(), ratio_per_category * 2));
  for (size_t idx = 0; idx < tmp_vec.size(); ++idx) {
    if (influence < 1e-5) break;
    const std::string& category = tmp_vec[idx].second;
    category_score_map->insert(std::make_pair(category, ratio_per_category));
    influence -= ratio_per_category;
  }
}

bool CategorySelector::SelectFirstCategory(
    const RecommendRequest* request,
    const UserInfo* user_info, const UserFeature* user_fea,
    std::vector<std::pair<float, reco::Category> >* param_category_distributes) {

  param_category_distributes->clear();
  std::vector<std::pair<float, reco::Category> >& category_distributes = *param_category_distributes;

  std::vector<reco::Category> raw_categories;
  GetCandidateRawCategory(request, user_info, user_fea, &raw_categories);
  if (raw_categories.empty()) {
    LOG(WARNING) << "empty raw category candidate, " << request->Utf8DebugString();
    return false;
  }

  std::vector<std::string> categories;
  for (int i = 0; i < (int)raw_categories.size(); ++i) {
    categories.push_back(reco::common::WrappedCategory(raw_categories[i]).ToString());
  }

  base::dense_hash_map<std::string, std::pair<int, float> > category_counter;
  category_counter.set_empty_key("");
  for (int i = 0; i < (int)categories.size(); ++i) {
    if (!categories[i].empty()) {
      category_counter[categories[i]] = std::make_pair(i, 0);
    }
  }

  // role category
  const static std::unordered_map<std::string, float> kVerticleCateBoostDict = {
    {"财经", 1.5f},
    {"科技", 1.5f},
    {"育儿", 1.5f},
    {"美食", 1.2f},
    {"游戏", 1.5f},
    {"汽车", 1.5f},
    {"星座", 1.5f},
    {"房产", 1.5f},
    {"历史", 1.2f},
    {"军事", 1.2f},
    {"体育", 1.5f},
  };
  std::unordered_map<std::string, float> role_category_map;
  CategoryFromRole(request, user_info, user_fea, &role_category_map);
  float acc_weight = 0;
  float acc_role_wt = 0;
  for (auto iter = category_counter.begin(); iter != category_counter.end(); ++iter) {
    float l1_wt = 0;
    const auto l1_iter = user_fea->merged_fea.l1_cates.find(iter->first);
    if (l1_iter != user_fea->merged_fea.l1_cates.end()) {
      l1_wt = l1_iter->second;
    }
    const auto role_iter = role_category_map.find(iter->first);
    float role_wt = 0;
    if (role_iter != role_category_map.end()) {
      role_wt = role_iter->second;
    }
    acc_role_wt += role_wt;
    auto boost_iter = kVerticleCateBoostDict.find(iter->first);
    float boost = boost_iter != kVerticleCateBoostDict.end() ? boost_iter->second : 1;
    iter->second.second += (l1_wt + role_wt) * boost;
    acc_weight += iter->second.second;
  }
 
  if (acc_weight == 0) {
    float ratio = 1.0 / (int)category_counter.size();
    for (auto iter = category_counter.begin(); iter != category_counter.end(); ++iter) {
      iter->second.second = ratio;
    }
    acc_weight = 1;
  }
  // level1 上的归一
  for (auto it = category_counter.begin(); it != category_counter.end(); ++it) {
    it->second.second /= acc_weight;
  }

  // 社会 / 国内 / 国际调权因子
  float social_tune_ratio = 0.8;
  float social_total = 0;
  for (auto iter = category_counter.begin(); iter != category_counter.end(); ++iter) {
    if (social_categories_.find(iter->first) != social_categories_.end()) {
      social_total += iter->second.second;
    }
  }
  if (social_total >= 0.5) {
    social_tune_ratio *= 0.5 / social_total;
  }

  // NOTE(jianhuang) 为了开发用户新的兴趣点, 应该给用户未点击的 tag 一些小概率出现的机会
  // 如果用户的点击量已经较大, 则概率机会小点; 否则概率机会大点
  int category_num = (int)category_counter.size();
  if (category_num > kMaxCategoryPerRequest) {
    category_num = kMaxCategoryPerRequest;
  }
  float kExploreRatio = CalcExploreRatio(user_info, user_fea);
  kExploreRatio -= acc_role_wt;
  kExploreRatio = std::max(0.1f, kExploreRatio);
  const float kExploreWeight = kExploreRatio / category_num;
  acc_weight = 0;
  for (auto it = category_counter.begin(); it != category_counter.end(); ++it) {
    // exploit / explore / random
    float random_weight = CalcRandomFactor(request, user_fea, it->first);
    float ajust_weight = it->second.second * (1 - kExploreRatio) + kExploreWeight + random_weight;
    if (social_categories_.find(it->first) != social_categories_.end()) {
      ajust_weight *= social_tune_ratio;
    }
    it->second.second = std::min(0.4f, ajust_weight);
    auto dislike_iter = user_fea->behavior_fea.dislike_cates.find(it->first);
    if (dislike_iter != user_fea->behavior_fea.dislike_cates.end()) {
      it->second.second = std::max(0.00001f, it->second.second * (1 - dislike_iter->second));
    }

    // 大城市调权
    it->second.second = it->second.second * CalcBigCityFactor(user_fea, it->first);
    acc_weight += it->second.second;
  }
  if (acc_weight < 1e-7) {
    acc_weight = 1;
  }

  for (auto it = category_counter.begin(); it != category_counter.end(); ++it) {
    it->second.second /= acc_weight;
  }

  // cf tuner
  if (FLAGS_category_cf_dict_file != "") {
    CategoryCfTuner(&category_counter);
  }

  // 按照 category 权重排序
  int idx = 0;
  std::vector<std::pair<float, int> > tmp_sort(category_counter.size());
  for (auto it = category_counter.begin(); it != category_counter.end(); ++it) {
    tmp_sort[idx] = std::make_pair(it->second.second, it->second.first);
    ++idx;
  }
  std::sort(tmp_sort.begin(), tmp_sort.end(), std::greater<std::pair<float, int> >());

  // 最终的 category 分布结果
  // NOTE(jianhuang)
  // 不需要每次请求都计算所有的 category 的推荐列表。当然需要保证用户喜欢的 category 一定能得到展现
  category_distributes.clear();
  std::unordered_set<int> select_set;
  acc_weight = 0;

  std::map<std::string, int32> cate_flags;
  // 优先选择用户近期有点击的类别
  for (int i = 0; i < (int)tmp_sort.size(); ++i) {
    if (select_set.size() >= kMaxCategoryPerRequest * FLAGS_max_category_limit)
      break;
    auto iter = user_fea->st_fea.raw_l1_cates.find(categories[tmp_sort[i].second]);
    if (iter == user_fea->st_fea.raw_l1_cates.end() || iter->second < FLAGS_cate_select_min_st_click)
      continue;
    if (select_set.find(i) == select_set.end()) {
      select_set.insert(i);
      acc_weight += tmp_sort[i].first;
      cate_flags[raw_categories[tmp_sort[i].second].category()] = 1;
    }
  }
  if ((int)select_set.size() < FLAGS_cate_select_min_st_num) {
    // 然后选择用户 lt 有点击的类别
    for (int i = 0; i < (int)tmp_sort.size(); ++i) {
      if (select_set.size() >= kMaxCategoryPerRequest * FLAGS_max_category_limit)
        break;
      if (user_fea->merged_fea.l1_cates.find(categories[tmp_sort[i].second])
          == user_fea->merged_fea.l1_cates.end())
        continue;
      if (select_set.find(i) == select_set.end()) {
        select_set.insert(i);
        acc_weight += tmp_sort[i].first;
        cate_flags[raw_categories[tmp_sort[i].second].category()] = 2;
      }
    }
    if ((int)select_set.size() < FLAGS_cate_select_min_lt_num) {
      // 最后按照分数来选择
      for (int i = 0; i < (int)tmp_sort.size(); ++i) {
        if (select_set.size() >= kMaxCategoryPerRequest * FLAGS_max_category_limit)
          break;
        if (select_set.find(i) == select_set.end()
            && random_->GetDouble() <= tmp_sort[i].first * 10) {
          select_set.insert(i);
          acc_weight += tmp_sort[i].first;
          cate_flags[raw_categories[tmp_sort[i].second].category()] = 3;
        }
      }
      for (int i = 0; i < (int)tmp_sort.size(); ++i) {
        // 如果 category 足够多，至少取 kMaxCategoryPerRequest 个 category
        if ((int)select_set.size() >= kMaxCategoryPerRequest) {
          break;
        }
        if (select_set.find(i) == select_set.end()) {
          select_set.insert(i);
          acc_weight += tmp_sort[i].first;
          cate_flags[raw_categories[tmp_sort[i].second].category()] = 3;
        }
      }
    }
  }
  if (acc_weight < 1e-6) acc_weight = 1;

  for (int i = 0; i < (int)tmp_sort.size(); ++i) {
    if (select_set.find(i) != select_set.end()) {
      category_distributes.push_back(std::make_pair(tmp_sort[i].first / acc_weight,
                                                     raw_categories[tmp_sort[i].second]));
    }
  }

  // 控制一个类别最多展现占整体的比例, max_categroy_show_ratio
  if (category_distributes.size() >= 4u) {
    float max_show_ratio = std::max(0.5f, kMaxCategoryShowRatio);
    int end_idx = static_cast<int> (0.99 / max_show_ratio);
    for (int i = 0; i < end_idx && i < (int)category_distributes.size(); ++i) {
      if (category_distributes[i].first <= max_show_ratio) break;
      float smooth_ratio =
          (category_distributes[i].first - max_show_ratio) / (category_distributes.size() - i - 1);
      category_distributes[i].first = max_show_ratio;
      for (size_t j = i + 1; j < category_distributes.size(); ++j) {
        category_distributes[j].first += smooth_ratio;
      }
    }
  }

  // debug 信息
  std::string debug_str;
  for (size_t i = 0; i < category_distributes.size(); ++i) {
    const reco::Category& category = category_distributes.at(i).second;
    float weight = category_distributes.at(i).first;
    debug_str.append(base::StringPrintf("%s[%.3f-%d],", category.category().c_str(),
                                        weight, cate_flags[category.category()]));
  }
  LOG(INFO) << "uid:" << user_info->identity().user_id()
            << ", category distribute: " << debug_str
            << " explore ratio: " << kExploreRatio
            << ", cate size: " << category_distributes.size();

  return true;
}

int CategorySelector::CalcCategoryClickNum(const UserFeature* user_fea,
                                           const std::string& category) const {
  auto iter = user_fea->lt_fea.raw_l1_cates.find(category);
  if (iter == user_fea->lt_fea.raw_l1_cates.end()) {
    return 0;
  }
  return iter->second;
}

float CategorySelector::CalcExploreRatio(const UserInfo* user_info,
                                         const UserFeature* user_fea) const {
  int recent_click_num = static_cast<int> (user_fea->merged_info.total_click_num);
  // 使用分段函数实现该效果
  float kExploreRatio = 0;
  if (recent_click_num >= 60) {
    kExploreRatio = 0.2;
  } else if (recent_click_num >= 20) {
    kExploreRatio = 0.2 + (60 - recent_click_num) * 0.005;
  } else if (recent_click_num >= 10) {
    kExploreRatio = 0.4 + (20 - recent_click_num) * 0.01;
  } else if (recent_click_num >= 5) {
    kExploreRatio = 0.5 + (10 - recent_click_num) * 0.02;
  } else if (recent_click_num >= 2) {
    kExploreRatio = 0.6 + (5 - recent_click_num) * 0.04;
  } else if (recent_click_num >= 1) {
    kExploreRatio = 0.8;
  } else {  // 0.9
    kExploreRatio = 0.9;
  }
  int recent_refresh = RecoUtils::RecentRefresh(user_info, 2 * 60);
  if (recent_refresh < 5) {
    kExploreRatio *= std::pow(0.9, (5 - recent_refresh));
  }
  VLOG(2) << "[explore_ratio], uid:" << user_info->identity().user_id()
          << ", click_cnt:" << recent_click_num << ", recent_refresh: " << recent_refresh
          << ", explore ratio:" << kExploreRatio;
  return kExploreRatio;
}

// 加入不影响大局的随机因子，使得小类都有轮流展现的机会
float CategorySelector::CalcRandomFactor(const RecommendRequest* request, const UserFeature* user_fea,
                                         const std::string& category) const {
  // 不喜欢的类别不给于随机因子
  if (user_fea->behavior_fea.dislike_cates.find(category) != user_fea->behavior_fea.dislike_cates.end()) {
    return 0;
  }

  // 根据类别来确定随机因子的比例
  float random_ratio;
  if (IsBigCityNewUser(user_fea, category)) {
    if (big_city_add_weight_categories_.find(category) != big_city_add_weight_categories_.end()) {
      random_ratio = 0.03;
    } else if (big_city_sub_weight_categories_.find(category) != big_city_sub_weight_categories_.end()) {
      random_ratio = 0;
    } else {
      random_ratio = 0.015;
    }
  } else {
    if (big_city_add_weight_categories_.find(category) != big_city_add_weight_categories_.end()) {
      random_ratio = 0.02;
    } else if (big_city_sub_weight_categories_.find(category) != big_city_sub_weight_categories_.end()) {
      random_ratio = 0.005;
    } else {
      random_ratio = 0.01;
    }
  }
  float random_weight = random_ratio * random_->GetDouble();

  // 努比亚 渠道多出一些科技
  // if (request->app_token() == "nubiabro-iflow"
  //     && user_fea->merged_info.total_click_num < 10
  //     && category == "科技") {
  //   random_weight = std::max(0.2f, random_weight);
  // }
  if (user_fea->merged_info.total_click_num < 10) {
    if (request->app_token() == "nubiaggcs-iflow" && category == "社会") {
      // 努比亚测试 渠道多出一些社会
      random_weight = std::max(0.2f, random_weight);
    } else if (request->app_token() == "yunosls1-iflow" && category == "国内") {
      // 云 os 多出国内
      random_weight = std::max(0.2f, random_weight);
    } else if (request->app_token() == "meizubrw-iflow" && category == "国内") {
      // 魅族浏览器渠道多出国内
      random_weight = std::max(0.2f, random_weight);
    }
  }
  if (request->app_token() == "yunosls1-iflow" && category == "国内") {
    random_weight = std::max(0.2f, random_weight);
  }
  // 根据外渠配置规则调权
  bool succ;
  float boost_weight;
  AppTokenCategoryTuner(request, category, &succ, &boost_weight);
  if (succ) {
    random_weight = std::min(0.2f, boost_weight);
  }

  return random_weight;
}

// 是否是大城市新用户
bool CategorySelector::IsBigCityNewUser(const UserFeature* user_fea, const std::string &category) const {

  bool is_big_city_new_user = false;
  int recent_click_num = static_cast<int> (user_fea->merged_info.total_click_num);
  if ((big_citys_.find(user_fea->attr.city_id) != big_citys_.end())
      && (recent_click_num < 20)) {
    is_big_city_new_user = true;
  }
  return is_big_city_new_user;
}

// 大城市调权因子 
float CategorySelector::CalcBigCityFactor(const UserFeature* user_fea, const std::string& category) const {
  float boost = 1;
  if (!IsBigCityNewUser(user_fea, category)) {
    return boost;
  }

  if (big_city_add_weight_categories_.find(category) != big_city_add_weight_categories_.end()) {
    boost = 1.2;
  } else if (big_city_sub_weight_categories_.find(category) != big_city_sub_weight_categories_.end()) {
    boost = 0.8;
  }

  return boost;
}

// 根据app token调整类别权重
void CategorySelector::AppTokenCategoryTuner(const RecommendRequest* request,
                                             const std::string& category,
                                             bool* succ,
                                             float* boost_weight) const {
  auto dict = DM_GET_DICT(reco::dm::AppTokenCateBoostDict,
                                               DynamicDictContainer::kAppTokenCateBoostFile_).get();
  auto app_token_cate_boost_dict = dict->app_token_cate_boost_dict_;
  const std::string& key = request->app_token() + "\t" + category;
  auto iter = app_token_cate_boost_dict.find(key);
  if (iter == app_token_cate_boost_dict.end()) {
    *succ = false;
    return;
  }

  float weight = iter->second;
  *boost_weight = weight;
  *succ = true;
  return;
}

}
}
