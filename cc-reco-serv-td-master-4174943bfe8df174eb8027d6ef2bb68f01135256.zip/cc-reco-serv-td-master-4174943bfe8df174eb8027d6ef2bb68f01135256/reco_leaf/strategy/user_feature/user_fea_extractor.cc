#include "reco/serv/reco_leaf/strategy/user_feature/user_fea_extractor.h"

#include <algorithm>
#include <utility>

#include "reco/serv/reco_leaf/strategy/user_feature/extractor/user_fea_merger.h"
#include "reco/serv/reco_leaf/strategy/user_feature/extractor/lt_fea_extractor.h"
#include "reco/serv/reco_leaf/strategy/user_feature/extractor/lt_imfa_fea_extractor.h"
#include "reco/serv/reco_leaf/strategy/user_feature/extractor/dmp_fea_extractor.h"
#include "reco/serv/reco_leaf/strategy/user_feature/extractor/ali_fea_extractor.h"
#include "reco/serv/reco_leaf/strategy/user_feature/extractor/st_fea_extractor.h"
#include "reco/serv/reco_leaf/strategy/user_feature/extractor/attribute_extractor.h"
#include "reco/serv/reco_leaf/strategy/user_feature/extractor/behavior_fea_extractor.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

UserFeaExtractor::UserFeaExtractor(const reco::NewsIndex* index) : news_index_(index) {
  attr_extractor_ = new AttributeExtractor(index);
  lt_fea_extractor_ = new LtFeaExtractor(index);
  lt_imfa_fea_extractor_ = new LtImfaFeaExtractor(index);
  dmp_fea_extractor_ = new DmpFeaExtractor(index);
  ali_fea_extractor_ = new AliFeaExtractor(index);
  st_fea_extractor_ = new StFeaExtractor(index);
  behavior_fea_extractor_ = new BehaviorFeaExtractor(index);
  user_fea_merger_ = new UserFeaMerger();
}

UserFeaExtractor::~UserFeaExtractor() {
  delete attr_extractor_;
  delete lt_fea_extractor_;
  delete lt_imfa_fea_extractor_;
  delete dmp_fea_extractor_;
  delete ali_fea_extractor_;
  delete st_fea_extractor_;
  delete behavior_fea_extractor_;
  delete user_fea_merger_;
}

void UserFeaExtractor::ExtractUserFeature(const RecommendRequest* request,
                                          const UserInfo* user_info,
                                          UserFeature* user_fea) {
  ResetEnv(request, user_info);
  user_fea->Reset(user_info);
  // 获取初始的特征信息
  ExtractRawFea(request, user_info, user_fea);
  // user feature merge
  user_fea_merger_->Merge(*user_info, user_fea);
}

void UserFeaExtractor::ExtractRawFea(const RecommendRequest* request,
                                     const UserInfo* user_info,
                                     UserFeature* user_fea) {
  // 长期兴趣抽取
  lt_fea_extractor_->ExtractFeature(*user_info, &user_fea->lt_fea);
  // imei profile 兴趣
  lt_imfa_fea_extractor_->ExtractFeature(*user_info, &user_fea->lt_imfa_fea);
  // session 兴趣抽取
  st_fea_extractor_->ExtractFeature(*user_info, &user_fea->st_fea);
  // dmp 兴趣抽取
  //dmp_fea_extractor_->ExtractFeature(*user_info, &user_fea->dmp_fea);
  // ali 兴趣抽取
  ali_fea_extractor_->ExtractFeature(*user_info, &user_fea->ali_fea);
  // 用户行为特征抽取
  behavior_fea_extractor_->ExtractFeature(*user_info, *request, &user_fea->behavior_fea);
  // 用户属性特征抽取
  attr_extractor_->ExtractFeature(*user_info, *request, &user_fea->attr);
}

inline void UserFeaExtractor::ResetEnv(const RecommendRequest* request,
                                       const UserInfo* user_info) {
  request_ = request;
  user_info_ = user_info;
  current_time_ = base::Time::Now();
}

}  // namespace leafserver
}  // namespace reco

