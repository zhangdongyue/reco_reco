#include "reco/serv/reco_leaf/strategy/user_feature/user_cate_selector.h"

#include <string>
#include <unordered_map>
#include <vector>

#include "reco/serv/reco_leaf/strategy/user_feature/base/category_constrain.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "serving_base/data_manager/data_manager.h"
#include "reco/serv/reco_leaf/strategy/component/filter/news_filter.h"
#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"

namespace reco {
namespace leafserver {
DECLARE_string(category_cf_dict_file);
DEFINE_double(category_cf_weight, 0, "category_cf_weight");
DEFINE_double(max_category_limit, 1.2, "the max category limit");

CategoryVoter::CategoryVoter(const reco::NewsIndex* news_index) {
  news_index_ = news_index;
  random_ = new base::PseudoRandom(base::GetTimestamp());
}

CategoryVoter::~CategoryVoter() {
  delete random_;
}

bool CategoryVoter::SelectCates(const RecommendRequest* request,
                                   const reco::user::UserInfo* user_info,
                                   const UserFeature* user_fea,
                                   CateDistributeVec* cate_distributes) {
  cate_distributes->clear();
  request_ = request;
  user_fea_ = user_fea;
  user_info_ = user_info;

  // 获取候选的 category
  std::unordered_set<std::string> candidate_cates;
  GetCandidateCates(&candidate_cates);
  if (candidate_cates.empty()) {
    LOG(WARNING) << "empty raw category candidate, " << request->Utf8DebugString();
    return false;
  }
 
  // TODO(jianhuang) 各种策略分支往类别汇集器中添加权重
  // std::unordered_map<std::string, float> cate_collectors;

  return true;
}

void CategoryVoter::GetCandidateCates(std::unordered_set<std::string>* candidate_cates) const {
  // qudao 对应可下发的类别
  const std::unordered_set<std::string>* qudao_cates = GetQudaoCates();
  CHECK_NOTNULL(qudao_cates);

  // 从索引获取所有一级类别
  std::vector<reco::Category> all_l1_cates;
  news_index_->GetCategories(0, &all_l1_cates);

  // 获取需要过滤的类别
  std::unordered_set<std::string> filtered_cates;
  GetFilteredCates(&filtered_cates);

//  auto app_token_dict = DM_GET_DICT(reco::apptokenrule::AppTokenRuleDict,
//                                    reco::apptokenrule::AppTokenRuleLoader::kAppTokenRuleFile).get();
//  auto app_token_index = app_token_dict->GetAppTokenIdx(request_->app_token());

  // 获取得到所有候选的一级类别
  for (int i = 0; i < (int)all_l1_cates.size(); ++i) {
    const std::string& category = all_l1_cates[i].category();
    if (qudao_cates->find(category) == qudao_cates->end()
        || filtered_cates.find(category) != filtered_cates.end()) continue;

    // 离线覆盖
//    if (app_token_index != -1
//        && reco::apptokenrule::AppRuleImpl::IsFilteredCategory(app_token_index, app_token_dict, category))
//        continue;
    candidate_cates->insert(category);
  }

  // NOTE(jianhuang) 都被过滤了，强行补充 filtered_cates 的类别
  if (candidate_cates->empty()) {
    for (auto iter = filtered_cates.begin(); iter != filtered_cates.end(); ++iter) {
      if (candidate_cates->size() >= 2u) break;
      candidate_cates->insert(*iter);
    }
  }
}

const std::unordered_set<std::string>* CategoryVoter::GetQudaoCates() const {
  const std::unordered_set<std::string>* candidate_cates = &CategoryConstrain::kIflowDftCates;
  const auto& qudao_cates = LeafDataManager::GetGlobalData()->qudao_categories_dict;
  const auto iter = qudao_cates.find(request_->app_token());
  if (iter != qudao_cates.end()) {
    candidate_cates = &(iter->second);
  }
  return candidate_cates;
}

void CategoryVoter::GetFilteredCates(std::unordered_set<std::string>* filter_cates) const {
  // 非深夜不出美女图片文章
  base::Time current_time = base::Time::Now();
  base::Time::Exploded exploded;
  current_time.LocalExplode(&exploded);
  if (6 <= exploded.hour && exploded.hour < 22) {
    filter_cates->insert(reco::common::kGirlCategory);
  }

  // NOTE(jianhuang) 大城市 / 新用户 暂时不下发两性情感文章
  // TODO(jianhuang）后续根据时间 / 用户 profile 进行控制
  if ((request_->has_is_new_user()
       && request_->is_new_user())
      || RecoUtils::IsMajorCity(user_fea_->attr.city_id)) {
    filter_cates->insert(reco::common::kBoudoirCategory);
  }

  // dislike category
  const BehaviorFeaDict& dislike_cates = user_fea_->behavior_fea.dislike_cates;
  for (auto iter = dislike_cates.begin(); iter != dislike_cates.end(); ++iter) {
    if (iter->second >= 0.8) {
      filter_cates->insert(iter->first);
    }
  }
}

}
}
