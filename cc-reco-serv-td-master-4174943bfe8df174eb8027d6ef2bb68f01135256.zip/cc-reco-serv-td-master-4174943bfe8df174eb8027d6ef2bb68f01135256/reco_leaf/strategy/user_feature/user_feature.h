#pragma once

#include <string>

#include "reco/serv/reco_leaf/strategy/user_feature/base/user_fea_define.h"
#include "reco/bizc/proto/user.pb.h"
#include "base/common/basic_types.h"

namespace reco {
namespace leafserver {

// 用户特征汇总类
// 各维特征的定义见 base/user_fea_define.h
//
struct UserFeature {
  // 初始 user info 信息
  const reco::user::UserInfo* user_info;
  // 用户基本属性
  UserAttribute attr;
  // 用户长期兴趣
  UserLongTermFeature lt_fea;
  // imei 长期兴趣
  UserLongTermFeature lt_imfa_fea;
  // 用户 session 兴趣
  UserShortTermFeature st_fea;
  // 用户 dmp 兴趣
  UserDmpFeature dmp_fea;
  // 用户 ali 兴趣
  UserAliFeature ali_fea;
  // 用户行为特征
  UserBehaviorFeature behavior_fea;
  // merege 的统计信息
  UserMergedInfo merged_info;
  // merege 的用户特征
  UserMergedFeature merged_fea;

  UserFeature() : user_info(NULL) {}

  void Reset(const reco::user::UserInfo* user) {
    user_info = user;
    attr.Reset();
    lt_fea.Reset();
    lt_imfa_fea.Reset();
    st_fea.Reset();
    dmp_fea.Reset();
    ali_fea.Reset();
    behavior_fea.Reset();
    merged_info.Reset();
    merged_fea.Reset();
  }
};

}
}
