#pragma once

#include <map>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>

#include "reco/bizc/proto/user.pb.h"
#include "base/container/dense_hash_map.h"
#include "base/common/basic_types.h"

namespace reco {
namespace leafserver {
// 该文件定义用户各维度兴趣

// 用户对低俗的容忍程度
enum UserDirtyLevel {
  // 极度反感
  kDirtyVeryLow = 0,
  // 反感
  kDirtyLow = 1,
  // 容忍
  kDirtyMid = 2,
  // 喜欢
  kDirtyHigh = 3,
  // 极度喜欢
  kDirtyVeryHigh = 4,
  // 未知
  kDirtyUnknown = 10,
};

enum UserBluffingLevel {
  // 极度反感
  kBluffingVeryLow = 0,
  // 反感
  kBluffingLow = 1,
  // 容忍
  kBluffingMid = 2,
  // 喜欢
  kBluffingHigh = 3,
  // 极度喜欢
  kBluffingVeryHigh = 4,
  // 未知
  kBluffingUnknown = 10,
};

// 用户对视频的厌恶程度
enum UserDislikeVideoLevel {
  // 极度反感
  kDislikeVideoVeryHigh = 0,
  // 反感
  kDislikeVideoHigh = 1,
  // 容忍
  kDislikeVideoLow = 2,
  // 不反感
  kNeverDislikeVideo = 10,
};

typedef std::map<std::string, double> FeaKeyVal;
typedef std::unordered_map<std::string, FeaKeyVal> FeaKeyValMap;
// typedef std::unordered_map<std::string, float> BehaviorFeaDict;
typedef base::dense_hash_map<std::string, float> BehaviorFeaDict;
typedef std::map<reco::ItemType, float> BehaviorItemTypeDict;

typedef FeaKeyVal UserFeaDict;
typedef FeaKeyValMap NestedUserFeaDict;
typedef UserFeaDict CateFeaDict;
typedef UserFeaDict TagFeaDict;
typedef UserFeaDict KeywordFeaDict;
typedef UserFeaDict TopicFeaDict;
typedef UserFeaDict SourceFeaDict;
typedef NestedUserFeaDict SubCateFeaDict;
typedef NestedUserFeaDict CateTagFeaDict;
typedef NestedUserFeaDict CateKeywordFeaDict;

// 用户长期兴趣特征
// 长期兴趣主要来源于 user profile
struct UserLongTermFeature {
  // 类别喜好
  CateFeaDict l1_cates;
  SubCateFeaDict l2_cates;
  CateFeaDict raw_l1_cates;
  std::unordered_set<std::string> confidence_l1_cates;
  // 词粒度喜好
  CateTagFeaDict cate_tags;
  CateKeywordFeaDict cate_keywords;
  TopicFeaDict topics;
  // 源喜好
  SourceFeaDict sources;
  // video 喜好信息
  CateFeaDict video_l1_cates;
  // video tag 喜好信息
  TagFeaDict video_tags;

  // 统计信息
  float click_num;
  float video_click_num;

  // method
  UserLongTermFeature() : click_num(0), video_click_num(0) {}
  void Reset() {
    click_num = 0;
    video_click_num = 0;
    l1_cates.clear();
    l2_cates.clear();
    raw_l1_cates.clear();
    confidence_l1_cates.clear();
    cate_tags.clear();
    cate_keywords.clear();
    topics.clear();
    sources.clear();
    video_l1_cates.clear();
    video_tags.clear();
  }
};
// 特征合并的信息跟长期兴趣一致
typedef UserLongTermFeature UserMergedFeature;

struct UserShortTermFeature {
  // 类别喜好
  CateFeaDict l1_cates;
  SubCateFeaDict l2_cates;
  CateFeaDict raw_l1_cates;
  // 词喜好
  CateTagFeaDict cate_tags;
  CateKeywordFeaDict cate_keywords;
  TopicFeaDict topics;

  // 最近点击 itemid 及 距离当前的分钟数
  std::vector<std::pair<uint64, int> > recent_clicks;

  // video 喜好
  CateFeaDict video_l1_cates;
  TagFeaDict video_tags;

  // short term 统计信息
  float st_click_num;
  float st_video_click_num;
  // session 统计信息
  float session_click_num;
  float session_video_click_num;
  float session_video_show_num;
  float session_video_click_ratio;
  float session_show_num;
  float session_pv;

  // method
  UserShortTermFeature() {
    Reset();
  }
  void Reset() {
    l1_cates.clear();
    l2_cates.clear();
    raw_l1_cates.clear();
    video_l1_cates.clear();
    video_tags.clear();
    cate_tags.clear();
    cate_keywords.clear();
    topics.clear();
    recent_clicks.clear();
    st_click_num = 0;
    st_video_click_num = 0;
    session_click_num = 0;
    session_video_show_num = 0;
    session_video_click_num = 0;
    session_video_click_ratio = 0;
    session_pv = 0;
  }
};

// dmp 数据：
// 这边主要是浏览器 dmp 数据
struct UserDmpFeature {
  CateFeaDict l1_cates;
  SubCateFeaDict l2_cates;
  TopicFeaDict topics;
  CateKeywordFeaDict cate_keywords;

  float click_num;

  UserDmpFeature() : click_num(0) {}
  void Reset() {
    click_num = 0;
    l1_cates.clear();
    l2_cates.clear();
    topics.clear();
    cate_keywords.clear();
  }
};

// ali profile 数据
// 根据 ali profile 数据分析的兴趣喜好
struct UserAliFeature {
  CateFeaDict l1_cates;

  UserAliFeature() {}
  void Reset() {
    l1_cates.clear();
  }
};

// 用户行为特征，包括:
// 1. 订阅关键词
// 2. 点击不喜欢
// 3. 订阅媒体号
// 4. 进入频道
// 5. 展现不点击 TODO(jianhuang)
// 6. 频道选择 TODO(jianhuang)
struct DislikeItemInfo {
  uint64 item_id;
  std::string category;
  std::unordered_map<std::string, float> item_feas;
};
// 用户短期兴趣特征
// 短期兴趣主要来源于最近点击
struct CateStats {
  int show;
  int click;
  float ctr;
  int show_since_last_click;
  CateStats() : show(0), click(0), ctr(0), show_since_last_click(0) {
  }
};
struct UserBehaviorFeature {
  // 不喜欢相关信息
  std::vector<DislikeItemInfo> dislike_items;
  BehaviorFeaDict dislike_cates;
  BehaviorFeaDict dislike_sub_cates;
  BehaviorFeaDict dislike_sources;
  BehaviorFeaDict dislike_tags;
  BehaviorFeaDict dislike_semantic_tags;
  BehaviorItemTypeDict dislike_item_types;
  // 订阅关键词
  BehaviorFeaDict subscript_words;
  int64 last_subscript_word_time;
  // 订阅源
  BehaviorFeaDict subscript_sources;
  int64 last_subscript_source_time;
  // 订阅频道
  BehaviorFeaDict subscript_channel_cates;
  // 进入频道
  BehaviorFeaDict enter_channel_cates;
  // 不喜欢视频等级
  UserDislikeVideoLevel dislike_video_level;
  //
  CateFeaDict role_l1_cates;
  SubCateFeaDict role_l2_cates;
  base::Time role_set_time;
  // 存储每个类别各类数据表现
  base::dense_hash_map<std::string, CateStats> cate_stats;

  UserBehaviorFeature() : last_subscript_word_time(0), last_subscript_source_time(0) {
    dislike_cates.set_empty_key("");
    dislike_sub_cates.set_empty_key("");
    dislike_sources.set_empty_key("");
    dislike_tags.set_empty_key("");
    dislike_semantic_tags.set_empty_key("");
    enter_channel_cates.set_empty_key("");
    subscript_channel_cates.set_empty_key("");
    subscript_words.set_empty_key("");
    subscript_sources.set_empty_key("");
    cate_stats.set_empty_key("");
    dislike_video_level = kNeverDislikeVideo;
  }
  void Reset() {
    dislike_items.clear();
    dislike_cates.clear();
    dislike_sub_cates.clear();
    dislike_sources.clear();
    dislike_tags.clear();
    dislike_semantic_tags.clear();
    dislike_item_types.clear();
    enter_channel_cates.clear();
    subscript_channel_cates.clear();
    subscript_words.clear();
    subscript_sources.clear();
    role_l1_cates.clear();
    role_l2_cates.clear();
    cate_stats.clear();
    last_subscript_word_time = 0;
    last_subscript_source_time = 0;
    dislike_video_level = kNeverDislikeVideo;
  }
};

// 用户的一些基本属性
// TODO(jianhuang) 年龄 / 性别 等
//
struct UserAttribute {
  // 地域信息
  int64 prov_id;
  int64 city_id;
  // 商圈 ID
  std::unordered_set<int64> user_area_ids;
  // 区县 ID
  std::unordered_set<int64> user_district_ids;
  // 低俗等级
  UserDirtyLevel dirty_level;
  // 标题党等级
  UserBluffingLevel bluffing_level;
  // 是否是视频用户
  bool is_video_user;

  UserAttribute() : prov_id(0), city_id(0), dirty_level(kDirtyMid) {}

  void Reset() {
    prov_id = 0;
    city_id = 0;
    dirty_level = kDirtyMid;
    user_area_ids.clear();
    user_district_ids.clear();
    is_video_user = false;
  }
};

// 汇总统计信息
//
struct UserMergedInfo {
  float lt_influence;
  float lt_imfa_influence;
  float st_influence;
  float video_lt_influence;
  float video_st_influence;
  float dmp_influence;
  float ali_influence;
  float role_influence;
  float total_click_num;
  float total_video_click_num;
  float video_click_ratio;

  UserMergedInfo() {
    Reset();
  }
  void Reset() {
    lt_influence = 0;
    lt_imfa_influence = 0;
    st_influence = 0;
    video_lt_influence = 0;
    video_st_influence = 0;
    dmp_influence = 0;
    ali_influence = 0;
    role_influence = 0;
    total_click_num = 0;
    total_video_click_num = 0;
    video_click_ratio = 0;
  }
};

}
}
