#include "reco/serv/reco_leaf/strategy/user_feature/base/user_fea_extract_util.h"

#include "reco/serv/reco_leaf/strategy/common/feature_api-inl.h"

namespace reco {
namespace leafserver {

void UserFeaExtractUtil::NormalizeUserFea(UserFeaType* fea_vec) {
  AdjustBadFea(fea_vec);
  NormalizeFeature(fea_vec);
}

void UserFeaExtractUtil::NormalizeUserFeaMap(UserFeaMap* fea_map) {
  for (auto iter = fea_map->begin(); iter != fea_map->end(); ++iter) {
    NormalizeUserFea(&iter->second);
  }
}

void UserFeaExtractUtil::SelectUserFea(UserFeaType* fea_vec, size_t limit_size) {
  if (fea_vec->size() <= limit_size) return;

  std::vector<std::pair<double, std::string> > sort_vec(fea_vec->size());
  int idx = 0;
  for (auto iter = fea_vec->begin(); iter != fea_vec->end(); ++iter) {
    sort_vec[idx].first = iter->second;
    sort_vec[idx].second = iter->first;
    ++idx;
  }
  std::sort(sort_vec.begin(), sort_vec.end(), std::greater<std::pair<double, std::string> >());
  fea_vec->clear();
  for (size_t i = 0; i < limit_size; ++i) {
    fea_vec->insert(std::make_pair(sort_vec[i].second, sort_vec[i].first));
  }
}

void UserFeaExtractUtil::ConvertUserFeaToVector(const UserFeaType& fea_vec,
                                                std::vector<std::pair<double, std::string> >* sort_vec) {
  int idx = 0;
  sort_vec->resize(fea_vec.size());
  for (auto iter = fea_vec.begin(); iter != fea_vec.end(); ++iter) {
    sort_vec->at(idx).first = iter->second;
    sort_vec->at(idx).second = iter->first;
    ++idx;
  }
  std::sort(sort_vec->begin(), sort_vec->end(), std::greater<std::pair<double, std::string> >());
}

void UserFeaExtractUtil::AdjustBadFea(UserFeaType* fea) {
  static const double kMinWt = 1e-6;
  for (auto iter = fea->begin(); iter != fea->end(); ++iter) {
    if (iter->second <= kMinWt) {
      iter->second = kMinWt;
    }
  }
}

int UserFeaExtractUtil::CountShowSinceTime(const reco::user::UserInfo& user_info,
                                           const base::Time& start_time) {
  int count = 0;
  int64 start_timestamp = start_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  for (int i = user_info.shown_history_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& show_item = user_info.shown_history(i);
    if (show_item.view_timestamp() < start_timestamp) break;
    ++count;
  }
  return count;
}

}  // namespace leafserver
}  // namespace reco
