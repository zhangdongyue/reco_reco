#include "reco/serv/reco_leaf/strategy/user_feature/base/category_constrain.h"

#include "base/common/basic_types.h"

namespace reco {
namespace leafserver {
const std::unordered_set<std::string> CategoryConstrain::kDoL1Cates = {
  "科技", "体育", "健康", "军事", "历史", "国际", "奇闻", "娱乐", "干货", "房产",
  "摄影", "收藏", "教育", "旅游", "时尚", "星座", "汽车", "游戏", "社会", "科学探索",
  "美女写真", "美食", "职场", "育儿", "萌宠", "论坛", "财经", "两性情感", "国内", "幽默",};

const std::unordered_set<std::string> CategoryConstrain::kDoL2Cates = { "科技", "体育", "财经", "房产"};

const std::unordered_set<std::string> CategoryConstrain::kSocialCates = {"社会", "国内", "国际", };

const std::unordered_set<std::string> CategoryConstrain::kIflowDftCates = {
  "科技", "体育", "健康", "军事", "历史", "国际", "奇闻", "娱乐", "干货", "房产",
  "收藏", "教育", "旅游", "时尚", "星座", "汽车", "游戏", "社会", "科学探索",
  "美食", "职场", "育儿", "财经", "两性情感", "国内", };

const std::unordered_set<std::string> CategoryConstrain::kMajorCityIncCates = {
  "财经", "科技", "国内", "职场",};

const std::unordered_set<std::string> CategoryConstrain::kMajorCityDecrCates = {
  "两性", "奇闻", "社会", "游戏", };

bool CategoryConstrain::IfDoLevel1Category(const std::string& category) {
  return kDoL1Cates.find(category) != kDoL1Cates.end();
}

bool CategoryConstrain::IfDoLevel2Category(const std::string& category) {
  return kDoL2Cates.find(category) != kDoL2Cates.end();
}

}  // namespace leafserver
}  // namespace reco
