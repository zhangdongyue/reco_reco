#pragma once

#include <string>
#include <unordered_set>

#include "reco/base/common/singleton.h"

namespace reco {
namespace leafserver {

// 类别限制类
//
class CategoryConstrain {
 public:
  // 是否需要一级类别的特征分析
  static bool IfDoLevel1Category(const std::string& category);
  // 是否需要二级类别的特征分析
  static bool IfDoLevel2Category(const std::string& category);

 public:
  // 需要一级类别特征分析的类别集合
  static const std::unordered_set<std::string> kDoL1Cates;
  // 需要二级类别特征分析的类别集合
  static const std::unordered_set<std::string> kDoL2Cates;
  // 社会属性的类别
  static const std::unordered_set<std::string> kSocialCates;
  // uc iflow 默认可推荐的类别
  static const std::unordered_set<std::string> kIflowDftCates;
  // 大城市加强的类别
  static const std::unordered_set<std::string> kMajorCityIncCates;
  // 大城市削弱的类别
  static const std::unordered_set<std::string> kMajorCityDecrCates;

 private:
  CategoryConstrain();
  ~CategoryConstrain();
};

}  // namespace leafserver
}  // namespace reco
