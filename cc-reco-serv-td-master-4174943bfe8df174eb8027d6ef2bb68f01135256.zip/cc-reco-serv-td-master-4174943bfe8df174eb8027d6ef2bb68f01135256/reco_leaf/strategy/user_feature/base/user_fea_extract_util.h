#pragma once

#include <map>
#include <string>
#include <unordered_map>

#include "reco/bizc/proto/user.pb.h"
#include "base/time/time.h"

namespace reco {
namespace leafserver {

typedef std::map<std::string, double> UserFeaType;
typedef std::unordered_map<std::string, UserFeaType> UserFeaMap;

class UserFeaExtractUtil {
 public:
  // 特征归一化
  static void NormalizeUserFea(UserFeaType* fea_vec);

  // 多维特征归一化
  static void NormalizeUserFeaMap(UserFeaMap* fea_map);

  // 特征抽取：按照权重高低，选取 top limit_size
  static void SelectUserFea(UserFeaType* fea_vec, size_t limit_size);

  // 转换成 vector
  static void ConvertUserFeaToVector(const UserFeaType& fea_vec,
                                     std::vector<std::pair<double, std::string> >* sort_vec);

  // 计算从某个时间开始用户获取的文章条数
  static int CountShowSinceTime(const reco::user::UserInfo& user_info, const base::Time& start_time);

 private:
  static void AdjustBadFea(UserFeaType* fea_vec);

 private:
  UserFeaExtractUtil() {}
  ~UserFeaExtractUtil() {}
};

}  // namespace leafserver
}  // namespace reco
