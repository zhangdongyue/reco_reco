#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>

#include "reco/serv/reco_leaf/strategy/common/reco_strategy_branch.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/user.pb.h"

#include "base/time/time.h"

namespace reco {
namespace leafserver {

typedef std::unordered_map<int, int> RSBReturnNumMap;

class RsbSelector {
 public:
  RsbSelector() {}
  ~RsbSelector() {}

  void CalcRSBReturnNumMap(const RecommendRequest* request,
                           const reco::user::UserInfo* user_info,
                           const UserFeature* user_feas,
                           RSBReturnNumMap* rsb_return_map) const;

 private:
  float CalcManualAssignRatio(const RecommendRequest* request,
                              const reco::user::UserInfo* user_info,
                              const UserFeature* user_feas) const;

  float CalcThirdPartyRecoAssignRatio(const RecommendRequest* request,
                              const reco::user::UserInfo* user_info,
                              const UserFeature* user_feas) const;

  float CalcHotAssignRatio(const RecommendRequest* request,
                           const reco::user::UserInfo* user_info,
                           const UserFeature* user_feas) const;

  float CalcQueryRecoAssignRatio(const RecommendRequest* request,
                                 const reco::user::UserInfo* user_info,
                                 const UserFeature* user_feas) const;

  float CalcVideoAssignRatio(const RecommendRequest* request,
                             const reco::user::UserInfo* user_info,
                             const UserFeature* user_feas) const;

  float CalcLocalHotAssignRatio(const RecommendRequest* request,
                                const reco::user::UserInfo* user_info,
                                const UserFeature* user_feas) const;

  double CalcVideoRecoProbability(const UserFeature* user_fea) const;

  float CalcUcSidRecoAssignRatio(const RecommendRequest* request,
                                 const reco::user::UserInfo* user_info,
                                 const UserFeature* user_feas) const;

  bool IfUserHasHumorAttr(const RecommendRequest* request,
                          const reco::user::UserInfo* user_info,
                          const UserFeature* user_feas) const;

  bool IfDoManualReco(const RecommendRequest* reco_request) const;
  int32 QueryRecoTuner(int32 query_reco_assign_num,
                       const RecommendRequest* request,
                       const reco::user::UserInfo* user_info,
                       const UserFeature* user_feas) const;
 private:
  static const int kTopN = 200;
};
}
}
