#pragma once

#include <unordered_set>
#include <string>
#include <vector>

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "base/random/pseudo_random.h"
#include "base/container/dense_hash_map.h"
#include "base/container/dense_hash_set.h"

namespace reco {
class NewsIndex;

namespace leafserver {
struct GlobalData;

typedef std::vector<std::pair<float, std::string>> CateDistributeVec;

// 类别选择类
// TODO（jianhuang) finish it, and replace CategorySelector
//
class CategoryVoter {
 public:
  explicit CategoryVoter(const reco::NewsIndex* news_index);
  ~CategoryVoter();

  bool SelectCates(const RecommendRequest* request,
                   const reco::user::UserInfo* user_info,
                   const UserFeature* user_fea,
                   CateDistributeVec* cate_distributes);

 private:
  void GetCandidateCates(std::unordered_set<std::string>* candidate_cates) const;
  void GetFilteredCates(std::unordered_set<std::string>* filter_cates) const;
  const std::unordered_set<std::string>* GetQudaoCates() const;

  void VoteFromLtFea(std::unordered_map<std::string, float>* cates) const;
  void VoteFromStFea(std::unordered_map<std::string, float>* cates) const;
  void VoteFromAliFea(std::unordered_map<std::string, float>* cates) const;
  void VoteFromBehaviorFea(std::unordered_map<std::string, float>* cates) const;
  void AgainstFromDislike(std::unordered_map<std::string, float>* cates);

  // void CollectChannelChange(std::unordered_map<std::string, float>* cate_collectors) const;
  // void CollectChannelEnter(std::unordered_map<std::string, float>* cate_collectors) const;

 private:
  const NewsIndex* news_index_;

  const RecommendRequest* request_;
  const reco::user::UserInfo* user_info_;
  const UserFeature* user_fea_;

  base::PseudoRandom* random_;

};

}
}
