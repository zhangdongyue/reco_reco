#pragma once

#include <unordered_set>
#include <string>
#include <vector>

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "base/random/pseudo_random.h"
#include "base/container/dense_hash_map.h"

namespace reco {
class NewsIndex;
namespace leafserver {
struct GlobalData;

class CategorySelector {
 public:
  explicit CategorySelector(const reco::NewsIndex* news_index);
  ~CategorySelector();

  bool SelectFirstCategory(const RecommendRequest* request,
                           const reco::user::UserInfo* user_info,
                           const UserFeature* user_fea,
                           std::vector<std::pair<float, reco::Category> >* category_distributes);

  int CalcCategoryClickNum(const UserFeature* user_fea, const std::string& category) const;

 private:
  void GetCandidateRawCategory(const RecommendRequest* request,
                               const reco::user::UserInfo* user_info,
                               const UserFeature* user_fea,
                               std::vector<reco::Category>* raw_category);
  float CalcExploreRatio(const reco::user::UserInfo* user_info, const UserFeature* user_fea) const;
  float CalcRandomFactor(const RecommendRequest* request, const UserFeature* user_fea,
                         const std::string& category) const;

  float CalcBigCityFactor(const UserFeature* user_fea, const std::string& category) const;

  bool IsBigCityNewUser(const UserFeature* user_fea, const std::string& category) const;
  void CategoryCfTuner(base::dense_hash_map<std::string, std::pair<int, float> >* category);
  void CategoryFromRole(const RecommendRequest* request,
                        const reco::user::UserInfo* user_info, const UserFeature* user_fea,
                        std::unordered_map<std::string, float>* category_score_map);
  void AppTokenCategoryTuner(const RecommendRequest* request,
                             const std::string& category,
                             bool* succ,
                             float* boost_weight) const;

 private:
  // 一个类别在一次请求中占比限制
  static const float kMaxCategoryShowRatio;
  // 一次请求最多使用多少个类别
  static const int   kMaxCategoryPerRequest;
  static const std::unordered_set<std::string> social_categories_;

  static const std::unordered_set<std::string> big_city_add_weight_categories_;
  static const std::unordered_set<std::string> big_city_sub_weight_categories_;
  static const std::unordered_set<int64> big_citys_;

  // 渠道类别配置词表
  std::unordered_map<std::string, std::unordered_set<std::string> >* iflow_categories_;
  // 默认渠道类别配置词表
  static const char* kDefaultIflowCategories[];
  std::unordered_set<std::string> default_iflow_categories_;

  const NewsIndex* news_index_;

  base::PseudoRandom* random_;
  GlobalData* global_data_;
};
}
}
