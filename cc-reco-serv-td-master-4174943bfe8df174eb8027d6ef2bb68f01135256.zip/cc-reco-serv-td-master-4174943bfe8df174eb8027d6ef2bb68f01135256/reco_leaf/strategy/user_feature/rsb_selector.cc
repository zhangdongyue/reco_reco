#include "reco/serv/reco_leaf/strategy/user_feature/rsb_selector.h"

#include <algorithm>

#include "reco/serv/reco_leaf/strategy/common/reco_utils.h"
#include "base/random/pseudo_random.h"

namespace reco {
namespace leafserver {

DEFINE_bool(zzd_use_ucb_oper_items, false, "zzd 是否使用ucb的运营新闻");
DEFINE_bool(webapp_use_ucb_oper_items, false, "webapp 是否使用ucb的运营新闻");
DEFINE_bool(do_third_party_reco, false, "是否使用第三方推荐结果");
DEFINE_int32(max_manual_item_per_screen, 4, "每屏最多返回多少运营 item");

DEFINE_double(local_distribute_ratio, 0.15, "本地热门新闻下发推荐频道比率");
DEFINE_double(video_distribute_ratio_boost, 9, "视频点击占比加权boost值");
DEFINE_double(max_video_distibute_ratio_in_reco_channel, 0, "推荐频道视频下发占比最大权重");
DEFINE_double(max_video_distibute_ratio_in_verticle_channel, 0, "垂直频道视频下发占比最大权重");
DEFINE_double(reco_video_probability_boost, 2.0, "推荐视频的概率开关");
DEFINE_double(hot_channel_mamual_assign_ratio, 0.5, "热门频道人工先出比例");
DEFINE_bool(do_uc_sid_reco, false, "是否使用 uc sid 推荐结果");

void RsbSelector::CalcRSBReturnNumMap(const RecommendRequest* request,
                                      const reco::user::UserInfo* user_info,
                                      const UserFeature* user_feas,
                                      RSBReturnNumMap* rsb_return_map) const {
  rsb_return_map->clear();

  const int64 channel_id =
      request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId;
  const int request_return_num = request->return_num();

  bool turnoff_random = request->has_reco_debug_param() ?
      request->reco_debug_param().turnoff_random() : false;
  base::PseudoRandom random_generator(base::GetTimestamp());

  float ratio_discount = 1.0;
  float manual_assign_ratio = CalcManualAssignRatio(request, user_info, user_feas);
  manual_assign_ratio *= ratio_discount;
  ratio_discount -= manual_assign_ratio;

  float sid_reco_assign_ratio = CalcUcSidRecoAssignRatio(request, user_info, user_feas);
  sid_reco_assign_ratio *= ratio_discount;
  ratio_discount -= sid_reco_assign_ratio;

  float tp_reco_assign_ratio = CalcThirdPartyRecoAssignRatio(request, user_info, user_feas);
  tp_reco_assign_ratio *= ratio_discount;
  ratio_discount -= tp_reco_assign_ratio;

  float hot_assign_ratio = CalcHotAssignRatio(request, user_info, user_feas);
  hot_assign_ratio *= ratio_discount;
  ratio_discount -= hot_assign_ratio;

  float query_reco_assign_ratio = CalcQueryRecoAssignRatio(request, user_info, user_feas);
  query_reco_assign_ratio *= ratio_discount;
  ratio_discount -= query_reco_assign_ratio;

  float video_assign_ratio = CalcVideoAssignRatio(request, user_info, user_feas);
  video_assign_ratio *= ratio_discount;
  ratio_discount -= video_assign_ratio;

  float local_hot_assign_ratio = CalcLocalHotAssignRatio(request, user_info, user_feas);
  local_hot_assign_ratio *= ratio_discount;
  ratio_discount -= local_hot_assign_ratio;

  int manual_assign_num = 0;
  if (manual_assign_ratio > 1e-4) {
    manual_assign_ratio *= request_return_num;
    manual_assign_num = (int) manual_assign_ratio;
    if (turnoff_random || random_generator.GetDouble() < manual_assign_ratio - manual_assign_num) {
      manual_assign_num += 1;
    }
    manual_assign_num = manual_assign_num >= 1 ? manual_assign_num : 1;
    // 不是全运营文章，做下条数限制
    if (manual_assign_ratio < 0.99) {
      manual_assign_num = std::min(FLAGS_max_manual_item_per_screen, manual_assign_num);
    }
  }

  int sid_reco_assign_num = 0;
  if (sid_reco_assign_ratio > 1e-4) {
    sid_reco_assign_ratio *= request_return_num;
    sid_reco_assign_num = (int) sid_reco_assign_ratio;
    if (turnoff_random || random_generator.GetDouble() < sid_reco_assign_ratio - sid_reco_assign_num) {
      sid_reco_assign_num += 1;
    }
    sid_reco_assign_num = sid_reco_assign_num <= 3 ? sid_reco_assign_num : 3;
  }

  int tp_reco_assign_num = 0;
  if (tp_reco_assign_ratio > 1e-4) {
    tp_reco_assign_ratio *= request_return_num;
    tp_reco_assign_num = (int) tp_reco_assign_ratio;
    if (turnoff_random || random_generator.GetDouble() < tp_reco_assign_ratio - tp_reco_assign_num) {
      tp_reco_assign_num += 1;
    }
    sid_reco_assign_num = sid_reco_assign_num <= 4 ? sid_reco_assign_num : 4;
  }
  int32 query_reco_assign_num = 0;
  if (query_reco_assign_ratio > 1e-4) {
    query_reco_assign_ratio *= request_return_num;
    query_reco_assign_num = (int32) query_reco_assign_ratio;
    if (turnoff_random || random_generator.GetDouble() < query_reco_assign_ratio - query_reco_assign_num) {
      query_reco_assign_num += 1;
    }
  }
  query_reco_assign_num = QueryRecoTuner(query_reco_assign_num, request, user_info, user_feas);

  int hot_assign_num = 0;
  if (hot_assign_ratio > 1e-4) {
    hot_assign_ratio *= request_return_num;
    hot_assign_num = (int) hot_assign_ratio;
    if (turnoff_random || random_generator.GetDouble() < hot_assign_ratio - hot_assign_num) {
      hot_assign_num += 1;
    }
  }

  int probe_assign_num = 1;
  int probe_video_assign_num = 2;

  int local_assign_num = 0;
  // 多条热门新闻的话，本地热门占一条
  if (hot_assign_num > 1) {
    local_assign_num += 1;
    hot_assign_num -= 1;
  } else {
    if (local_hot_assign_ratio > 1e-4) {
      local_hot_assign_ratio *= request_return_num;
      local_assign_num = (int)local_hot_assign_ratio;
      if (turnoff_random || random_generator.GetDouble() < local_hot_assign_ratio - local_assign_num) {
        local_assign_num += 1;
      }
    }
  }
  local_assign_num = std::min(1, local_assign_num);

  int video_assign_num = 0;
  if (video_assign_ratio > 1e-4) {
    video_assign_ratio *= request_return_num;
    video_assign_num = (int) video_assign_ratio;
    if (turnoff_random || random_generator.GetDouble() < video_assign_ratio - video_assign_num) {
      video_assign_num += 1;
    }
  }
  if (channel_id == reco::common::kSexyBeautyChannelId) {
    video_assign_num = std::max(video_assign_num, 2);
  }

  int humor_assign_num = 0;
  if (channel_id == reco::common::kRecoChannelId
      && request_return_num >= 10
      && IfUserHasHumorAttr(request, user_info, user_feas)) {
    humor_assign_num = 1;
  }

  int personal_assign_num = kTopN;
  rsb_return_map->insert(std::make_pair(kThirdPartyRecoRSB, tp_reco_assign_num));
  rsb_return_map->insert(std::make_pair(kHotRSB, hot_assign_num));
  rsb_return_map->insert(std::make_pair(kVideoRSB, video_assign_num));
  rsb_return_map->insert(std::make_pair(kProbeVideoRSB, probe_video_assign_num));
  rsb_return_map->insert(std::make_pair(kManualRSB,  manual_assign_num));
  rsb_return_map->insert(std::make_pair(kHumorRSB,  humor_assign_num));
  rsb_return_map->insert(std::make_pair(kPersonalRSB, personal_assign_num));
  rsb_return_map->insert(std::make_pair(kLocalRSB, local_assign_num));
  rsb_return_map->insert(std::make_pair(kProbeRSB, probe_assign_num));
  rsb_return_map->insert(std::make_pair(kUcSidRecoRSB, sid_reco_assign_num));
  rsb_return_map->insert(std::make_pair(kQueryRecoRSB, query_reco_assign_num));
  LOG(INFO) << "strategy branch, uid: " << user_info->identity().user_id()
            << ", total:" << request_return_num << ", third_party:" << tp_reco_assign_num
            << ", manual:" << manual_assign_num << ", hot:" << hot_assign_num
            << ", video:" << video_assign_num << ", humor:" << humor_assign_num
            << ", personal:" << personal_assign_num << ", local:" << local_assign_num
            << ", query:" << probe_assign_num << ", probe_video:" << probe_video_assign_num
            << ", query reco:" << query_reco_assign_num << ", uc_sid:" << sid_reco_assign_num;
}

float RsbSelector::CalcThirdPartyRecoAssignRatio(const RecommendRequest* request,
                                         const reco::user::UserInfo* user_info,
                                         const UserFeature* user_fea) const {
  if (!FLAGS_do_third_party_reco) {
    LOG(INFO) << "do_third_party_reco switch off";
    return 0;
  }
  int64 channel_id = request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId;
  if (channel_id != reco::common::kRecoChannelId) {
    LOG_EVERY_N(INFO, 100) << "invalid channel_id: " << request->channel_id();
    return 0;
  }

  float total_click_num = user_fea->merged_info.total_click_num;
  float assign_ratio;

  // 依据画像稀疏程度决定第三方推荐结果的比例
  if (total_click_num >= 10) {
    assign_ratio = 0;
  } else if (total_click_num >= 8) {
    assign_ratio = 0.1;
  } else if (total_click_num >= 6) {
    assign_ratio = 0.2;
  } else if (total_click_num >= 4) {
    assign_ratio = 0.3;
  } else {
    assign_ratio = 0.4;
  }
  LOG(INFO) << "uid=" << user_info->identity().user_id()
          << ", total_click_num=" << total_click_num
          << ", assign_ratio=" << assign_ratio;
  return assign_ratio;
}


float RsbSelector::CalcManualAssignRatio(const RecommendRequest* request,
                                         const reco::user::UserInfo* user_info,
                                         const UserFeature* user_fea) const {
  // 根据配置项确定是否下发运营全量文章
  if (!IfDoManualReco(request)) return 0;

  int64 channel_id =
      request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId;

  float total_click_num = user_fea->merged_info.total_click_num;
  float total_video_click_num = user_fea->merged_info.total_video_click_num;

  float manual_assign_ratio = 0.4;
  // if (channel_id == reco::common::kOperChannelId
  if (RecoUtils::IsSpecialOperChannel(channel_id)) {
    // 运营特色文章先出完人工文章
    manual_assign_ratio = 1;
  } else if (channel_id == reco::common::kHotChannelId) {
    // 热门频道
    manual_assign_ratio = FLAGS_hot_channel_mamual_assign_ratio;
  } else if (channel_id == reco::common::kRecoChannelId) {
    // 推荐频道依据总点击量决定下发几条全量
    if (total_click_num >= 25) {
      manual_assign_ratio = 0.1;

    } else if (total_click_num >= 10) {
      manual_assign_ratio = 0.2;

    } else if (total_click_num >= 5) {
      manual_assign_ratio = 0.3;

    } else if (total_click_num >= 2) {
      manual_assign_ratio = 0.4;
    }
  } else if (channel_id == reco::common::kVideoChannelId) {
    if (total_video_click_num >= 25) {
      manual_assign_ratio = 0.1;

    } else if (total_video_click_num >= 10) {
      manual_assign_ratio = 0.2;

    } else if (total_video_click_num >= 5) {
      manual_assign_ratio = 0.3;

    } else if (total_video_click_num >= 2) {
      manual_assign_ratio = 0.4;
    }
  } else {
    // 垂直频道
  }

  return manual_assign_ratio;
}

float RsbSelector::CalcVideoAssignRatio(const RecommendRequest* request,
                                        const reco::user::UserInfo* user_info,
                                        const UserFeature* user_fea) const {
  float video_assign_ratio = 0;
  // 只有当网络环境是 wifi 的情况下，才出视频
  if (!request->has_uc_user_param()) return video_assign_ratio;
  auto uc_user_param = request->uc_user_param();
  if (!uc_user_param.has_nt() || uc_user_param.nt() != "2") return video_assign_ratio;

  int64 channel_id =
      request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId;

  double reco_probability = CalcVideoRecoProbability(user_fea);
  // 按上面算得概率，决定是否推荐视频
  base::PseudoRandom random_generator(base::GetTimestamp());
  bool turnoff_random = request->has_reco_debug_param() ?
      request->reco_debug_param().turnoff_random() : false;
  if (turnoff_random || random_generator.GetDouble() < reco_probability) {
    // 根据用户历史的视频点击比例来调整概率
    float max_video_assign_ratio = (channel_id == reco::common::kRecoChannelId) ?
        FLAGS_max_video_distibute_ratio_in_reco_channel : FLAGS_max_video_distibute_ratio_in_verticle_channel;
    video_assign_ratio = user_fea->merged_info.video_click_ratio * (1 + FLAGS_video_distribute_ratio_boost);
    video_assign_ratio = std::min(video_assign_ratio, max_video_assign_ratio);
  }

  VLOG(1) << "calc video distribute ratio: " << user_fea->user_info->identity().user_id() << ", "
          << user_fea->merged_info.video_click_ratio << ", "
          << user_fea->st_fea.session_video_show_num << ", "
          << user_fea->st_fea.session_video_click_num << ", "
          << reco_probability << ", "
          << video_assign_ratio;
  return video_assign_ratio;
}

double RsbSelector::CalcVideoRecoProbability(const UserFeature* user_fea) const {
  // 继续给用户推荐视频的概率, 如果用户视频点击过低，就按0.1来算，不能一条都不出
  double reco_probability = FLAGS_reco_video_probability_boost *
      std::max(user_fea->merged_info.video_click_ratio, 0.1f);
  if (user_fea->st_fea.session_video_show_num <= 3) {  // 不管什么用户, 前三次必出视频
    return 1.0;
  }

  static const double kSessionVideoCtrThr = 0.08;
  double session_video_ctr
      = user_fea->st_fea.session_video_click_num / user_fea->st_fea.session_video_show_num;
  // 给 10 次出视频的机会，如果出了 10 次后 session 视频点击率太低，就大大降低出视频几率
  if (user_fea->st_fea.session_video_show_num >= 10) {
    if (session_video_ctr < kSessionVideoCtrThr) {
      reco_probability *= 0;
    } else {
      reco_probability *= session_video_ctr;
    }
  }
  return reco_probability;
}

float RsbSelector::CalcQueryRecoAssignRatio(const RecommendRequest* request,
                                            const reco::user::UserInfo* user_info,
                                            const UserFeature* user_fea) const {
  int64 channel_id =
      request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId;

  if (channel_id != reco::common::kRecoChannelId) {
    return 0;
  }

  bool is_recent_user = true;
  if (user_fea->merged_info.total_click_num >= 5) {
    is_recent_user = false;
  }

  float query_reco_assign_ratio = 0.1;
  // 根据用户的show_item 24小时内最多出2次
  int32 query_show_num = 0;
  base::Time current_time = base::Time::Now();
  for (int32 i = user_info->shown_history_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& show_item = user_info->shown_history(i);
    base::Time show_time = base::Time::FromDoubleT(double(show_item.view_timestamp()) / 1e6);
    if ((current_time - show_time).InHours() > 24) break;
    if (show_item.strategy_branch() == reco::kQueryRecoBranch) ++query_show_num;
  }
  LOG(INFO) << "user_id:" << user_info->identity().user_id() << ", query show num in one day:" << query_show_num;
  int one_day_limit = 2;
  if (is_recent_user) one_day_limit = 6;
  if (query_show_num > one_day_limit) return 0;

  if (is_recent_user) query_reco_assign_ratio += 0.1;

  return query_reco_assign_ratio;
}


float RsbSelector::CalcHotAssignRatio(const RecommendRequest* request,
                                      const reco::user::UserInfo* user_info,
                                      const UserFeature* user_fea) const {
  int64 channel_id =
      request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId;

  if (channel_id != reco::common::kRecoChannelId) {
    return 0;
  }

  bool is_recent_user = true;
  if (user_fea->merged_info.total_click_num >= 5) {
    is_recent_user = false;
  }

  bool today_first_request = false;

  base::Time current_time = base::Time::Now();
  base::Time::Exploded exploded;
  current_time.LocalExplode(&exploded);
  int hour = exploded.hour;
  if (user_info->shown_history_size() > 0) {
    exploded.hour = 6;
    exploded.minute = 0;
    exploded.second = 0;
    exploded.millisecond = 0;
    base::Time exceed_time = base::Time::FromLocalExploded(exploded);
    int64 t = exceed_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
    const reco::user::ViewClickItem& show_item = user_info->shown_history(user_info->shown_history_size() - 1);
    if (show_item.view_timestamp() < t) {
      today_first_request = true;
    }
  }

  float hot_assign_ratio = 0;
  if (0 <= hour && hour < 6) {
    hot_assign_ratio = 0.03;
    today_first_request = false;
  } else if (6 <= hour && hour < 8) {
    hot_assign_ratio = 0.05;
  } else if (8 <= hour && hour < 12) {
    hot_assign_ratio = 0.075;
  } else if (12 <= hour && hour < 18) {
    hot_assign_ratio = 0.05;
  } else if (18 <= hour && hour < 22) {
    hot_assign_ratio = 0.04;
  } else {
    hot_assign_ratio = 0.03;
    today_first_request = false;
  }

  if (is_recent_user) hot_assign_ratio += 0.025;
  if (today_first_request) hot_assign_ratio += 0.05;

  if (hot_assign_ratio > 0.2) hot_assign_ratio = 0.2;

  return hot_assign_ratio;
}

float RsbSelector::CalcLocalHotAssignRatio(const RecommendRequest* request,
                                           const reco::user::UserInfo* user_info,
                                           const UserFeature* user_feas) const {
  const auto& l1_cates = user_feas->merged_fea.l1_cates;
  double max_prob = 0;
  for (auto iter = l1_cates.begin(); iter != l1_cates.end(); ++iter) {
    if (iter->second >= 0.1 && iter->second * user_feas->merged_info.total_click_num >= 5) {
      max_prob = std::max(max_prob, iter->second);
    }
  }
  double local_assign_ratio = (1 - max_prob) * FLAGS_local_distribute_ratio;
  VLOG(1) << "calc local hot assign ratio: " << max_prob << ", " << local_assign_ratio;
  return local_assign_ratio;
}

bool RsbSelector::IfDoManualReco(const RecommendRequest* request) const {
  if (request->app_token() == reco::common::kNewZZDAppUser) {
    return FLAGS_zzd_use_ucb_oper_items;

  } else if (request->app_token() == reco::common::kWebAppUser) {
    return FLAGS_webapp_use_ucb_oper_items;
  }

  if (request->uc_user_param().has_filter_ucbop_item()
      && request->uc_user_param().filter_ucbop_item() == true) return false;

  return true;
}

float RsbSelector::CalcUcSidRecoAssignRatio(const RecommendRequest* request,
                                            const reco::user::UserInfo* user_info,
                                            const UserFeature* user_fea) const {
  if (!FLAGS_do_uc_sid_reco) {
    LOG(INFO) << "do_uc_sid_reco switch off";
    return 0;
  }

  float total_click_num = user_fea->merged_info.total_click_num;
  float assign_ratio;

  // 依据画像稀疏程度决定 sid 推荐结果的比例
  if (total_click_num >= 8) {
    assign_ratio = 0;
  } else if (total_click_num >= 6) {
    assign_ratio = 0.1;
  } else if (total_click_num >= 4) {
    assign_ratio = 0.2;
  } else if (total_click_num >= 2) {
    assign_ratio = 0.25;
  } else {
    assign_ratio = 0.3;
  }
  LOG(INFO) << "uid=" << user_info->identity().user_id()
          << ", total_click_num=" << total_click_num
          << ", assign_ratio=" << assign_ratio;
  return assign_ratio;
}

bool RsbSelector::IfUserHasHumorAttr(const RecommendRequest* request,
                                     const reco::user::UserInfo* user_info,
                                     const UserFeature* user_feas) const {
  // 足够多的 humor 点击，该用户具有 humor 属性
  const auto& l1_cates = user_feas->merged_fea.l1_cates;
  auto l1_iter = l1_cates.find(reco::common::kHumorCategory);
  if (l1_iter != l1_cates.end() && l1_iter->second >= 3.0) {
    return true;
  }

  // 进入足够多次幽默频道, 该用户具有 humor 属性
  int humor_shown = 0;
  for (int i = user_info->shown_history_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& show_item = user_info->shown_history(i);
    if (!show_item.has_channel_id()) continue;
    if (show_item.channel_id() == reco::common::kHumorWordChannelId
        || show_item.channel_id() == reco::common::kHumorPicChannelId) {
      ++humor_shown;
    }
  }
  if (humor_shown >= 30) return true;

  // 没有 humor 属性
  return false;
}

int32 RsbSelector::QueryRecoTuner(int32 query_reco_assign_num,
                                  const RecommendRequest* reco_request,
                                  const reco::user::UserInfo* user_info,
                                  const UserFeature* user_feas) const {
  int32 new_query_reco_assign_num = query_reco_assign_num;
  if (new_query_reco_assign_num >= 2) return new_query_reco_assign_num;
  // 左屏刷新的多出一条
  if (reco_request->refresh_type() == 2) {
    new_query_reco_assign_num += 1;
  }
  // 新用户 低活用户 多出一条
  bool is_low_active_user = false;
  if (reco_request->has_is_new_user() && reco_request->is_new_user()) is_low_active_user = true;
  if (user_feas->merged_info.total_click_num <= 10) is_low_active_user = true;
  if (is_low_active_user) new_query_reco_assign_num += 1;
  return std::min(new_query_reco_assign_num, 2);
}

}
}
