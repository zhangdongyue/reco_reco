#pragma once

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/user.pb.h"

namespace reco {
class NewsIndex;

namespace leafserver {

// 长期兴趣抽取类
// 1. category 偏好
// 2. topic 偏好
// 3. tag 偏好
// 4. keyword 偏好
// 4. video category 偏好
//
class LtFeaExtractor {
 public:
  explicit LtFeaExtractor(const reco::NewsIndex* index) : news_index_(index) {}
  ~LtFeaExtractor() {}

  void ExtractFeature(const reco::user::UserInfo& user_info,
                      UserLongTermFeature* lt_fea);

 private:
  void ExtractCateFea(const reco::CategoryFeatureVector& fea_vec,
                      const reco::FeatureVector& channel_fea_vec,
                      UserLongTermFeature* lt_fea) const;
  void ExtractKeywordFea(const FeatureVector& fea_vec, UserLongTermFeature* lt_fea) const;
  void ExtractTagFea(const FeatureVector& fea_vec, UserLongTermFeature* lt_fea) const;
  void ExtractVideoTagFea(const FeatureVector& fea_vec, UserLongTermFeature* lt_fea) const;
  void ExtractTopicFea(const FeatureVector& fea_vec, UserLongTermFeature* lt_fea) const;
  void ExtractVideoCateFea(const reco::CategoryFeatureVector& fea_vec, UserLongTermFeature* lt_fea) const;

 private:
  const reco::NewsIndex* news_index_;
  const reco::user::UserInfo* user_info_;
};

}  // namespace leafserver
}  // namespace reco
