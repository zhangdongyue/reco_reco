#include "reco/serv/reco_leaf/strategy/user_feature/extractor/lt_fea_extractor.h"

#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/common/feature_api-inl.h"
#include "reco/serv/reco_leaf/strategy/user_feature/base/category_constrain.h"
#include "reco/serv/reco_leaf/frame/global_data.h"

namespace reco {
namespace leafserver {
using reco::user::Profile;

void LtFeaExtractor::ExtractFeature(const reco::user::UserInfo& user_info,
                                    UserLongTermFeature* lt_fea) {
  lt_fea->Reset();
  if (!user_info.has_profile()) return;

  user_info_ = &user_info;

  const Profile& profile = user_info.profile();
  if (profile.has_category_feavec()) {
    ExtractCateFea(profile.category_feavec(), profile.refresh_channel_feavec(), lt_fea);
  }

  if (profile.has_keyword_feavec()) {
    ExtractKeywordFea(profile.keyword_feavec(), lt_fea);
  }

  if (profile.has_tag_feavec()) {
    ExtractTagFea(profile.tag_feavec(), lt_fea);
  }

  if (profile.has_topic_feavec()) {
    ExtractTopicFea(profile.topic_feavec(), lt_fea);
  }

  if (profile.has_video_category_feavec()) {
    ExtractVideoCateFea(profile.video_category_feavec(), lt_fea);
  }

  // video tag fea
  if (profile.has_video_tag_without_cat_feavec()) {
    ExtractVideoTagFea(profile.video_tag_without_cat_feavec(), lt_fea);
  }
}

void LtFeaExtractor::ExtractCateFea(const reco::CategoryFeatureVector& fea_vec,
                                    const reco::FeatureVector& channel_fea_vec,
                                    UserLongTermFeature* lt_fea) const {
  const std::unordered_map<int64, std::vector<std::pair<std::string, float> > >&
      channel_categories = LeafDataManager::GetGlobalData()->channel_categories;
  std::unordered_map<std::string, float> refresh_category_map;
  int64 cid = 0;
  for (int i = 0; i < channel_fea_vec.feature_size(); ++i) {
    const reco::Feature& fea = channel_fea_vec.feature(i);
    if (!base::StringToInt64(fea.literal(), &cid)) {
      continue;
    }
    const auto iter = channel_categories.find(cid);
    if (iter == channel_categories.end() || iter->second.empty()) continue;
    const std::string& cate = iter->second.at(0).first;
    if (cate.empty() || !fea.has_confidence()) continue;
    // NOTE(jianhuang) weight 为经过处理的权重，confidence 直接为用户进入频道的次数
    refresh_category_map[cate] += fea.confidence();
  }
  /////
  uint64 uid = user_info_->identity().user_id();
  for (auto iter = refresh_category_map.begin(); iter != refresh_category_map.end(); ++iter) {
    VLOG(2) << "[refresh_category], " << uid << ", " <<  iter->first << ", " << iter->second;
  }
  ///// 一级类别特征
  reco::CategoryFeature adjust_cate_fea;
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const reco::CategoryFeature& cate_fea = fea_vec.feature(i);
    if (cate_fea.literal().level() != 0) continue;
    if (cate_fea.weight() <= 1e-6) continue;
    if (!CategoryConstrain::IfDoLevel1Category(cate_fea.literal().category())) continue;
    // AddFeature(cate_fea, 1.0, &lt_fea->l1_cates);
    // add raw l1 category
    AddFeature(cate_fea, 1.0, &lt_fea->raw_l1_cates);
    lt_fea->click_num += cate_fea.weight();
    // add l1 category
    const auto iter = refresh_category_map.find(cate_fea.literal().category());
    // float refresh_wt = std::min(100.0f, iter != refresh_category_map.end() ? iter->second : 0.0f);
    float refresh_wt = 0;
    float refresh_boost = std::min(5.0, std::pow(1.2, refresh_wt));
    float ctr_boost = 1;
    if (cate_fea.has_user_ctr() && cate_fea.weight() >= 3) {
      ctr_boost = std::pow(1 + cate_fea.user_ctr(), 2);
    }
    float adjust_wt = (cate_fea.weight() + refresh_wt) * ctr_boost * refresh_boost;
    VLOG(2) << base::StringPrintf("[fea_adjust], uid:%lu, cate:%s, org_wt:%.3f, refresh_wt:%.3f,"
                                  " refresh_boost:%.3f, ctr_boost:%.3f, adjust_wt:%.3f",
                                  uid, cate_fea.literal().category().c_str(), cate_fea.weight(),
                                  refresh_wt, refresh_boost, ctr_boost, adjust_wt);
    adjust_cate_fea.CopyFrom(cate_fea);
    adjust_cate_fea.set_weight(adjust_wt);
    AddFeature(adjust_cate_fea, 1.0, &lt_fea->l1_cates);
  }
  // // 记录一些初始数字，后面 merge 时使用
  // for (auto iter = lt_fea->l1_cates.begin(); iter != lt_fea->l1_cates.end(); ++iter) {
  //   lt_fea->raw_l1_cates.insert(std::make_pair(iter->first, iter->second));
  //   lt_fea->click_num += iter->second;
  // }
  // 特征归一化
  NormalizeFeature(&lt_fea->l1_cates);

  ///// 二级类别特征
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const reco::CategoryFeature& cate_fea = fea_vec.feature(i);
    const reco::Category& category = cate_fea.literal();
    if (category.level() != 1) continue;
    if (cate_fea.weight() <= 1e-6) continue;
    if (!CategoryConstrain::IfDoLevel2Category(category.parents(0))) continue;
    reco::Feature fea;
    fea.set_item_type(reco::kNews);
    fea.set_literal(category.category());
    fea.set_weight(cate_fea.weight());
    CateFeaDict& l2_feas = lt_fea->l2_cates[category.parents(0)];
    AddFeature(fea, 1.0, &l2_feas);
  }
  // 归一化
  for (auto iter = lt_fea->l2_cates.begin(); iter != lt_fea->l2_cates.end(); ++iter) {
    CateFeaDict& fea = iter->second;
    NormalizeFeature(&fea);
  }
}

void LtFeaExtractor::ExtractKeywordFea(const FeatureVector& fea_vec,
                                       UserLongTermFeature* lt_fea) const {
  // 特征抽取
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const reco::Feature& fea = fea_vec.feature(i);
    if (!fea.has_category()) {
      LOG(WARNING) << "keyword feature has no category, " << fea.Utf8DebugString();
      continue;
    }
    if (fea.weight() <= 1e-6) continue;
    if (!CategoryConstrain::IfDoLevel1Category(fea.category())) continue;
    KeywordFeaDict& keywords = lt_fea->cate_keywords[fea.category()];
    if (fea.has_item_type() && fea.item_type() == reco::kNews) {
      AddFeature(fea, 1.0, &keywords);
    }
  }
  // 归一化
  for (auto iter = lt_fea->cate_keywords.begin(); iter != lt_fea->cate_keywords.end(); ++iter) {
    KeywordFeaDict& fea = iter->second;
    NormalizeFeature(&fea);
  }
}

void LtFeaExtractor::ExtractVideoTagFea(const FeatureVector& fea_vec, UserLongTermFeature* lt_fea) const {
  TagFeaDict& video_tags = lt_fea->video_tags;
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const reco::Feature& fea = fea_vec.feature(i);
    if (fea.weight() <= 1e-6) continue;
    VLOG(1) << "add long term video_tag:" << fea.Utf8DebugString();
    AddFeature(fea, 1.0, &video_tags);
  }
  // 归一化
  NormalizeFeature(&video_tags);
}

void LtFeaExtractor::ExtractTagFea(const FeatureVector& fea_vec,
                                   UserLongTermFeature* lt_fea) const {
  // 特征抽取
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const reco::Feature& fea = fea_vec.feature(i);
    if (fea.weight() <= 1e-6) continue;
    if (!fea.has_category()) {
      LOG(WARNING) << "tag feature has no category, " << fea.Utf8DebugString();
      continue;
    }
    if (!CategoryConstrain::IfDoLevel1Category(fea.category())) continue;
    TagFeaDict& tags = lt_fea->cate_tags[fea.category()];
    if (fea.has_item_type() && fea.item_type() == reco::kNews) {
      AddFeature(fea, 1.0, &tags);
    }
  }
  // 归一化
  for (auto iter = lt_fea->cate_tags.begin(); iter != lt_fea->cate_tags.end(); ++iter) {
    KeywordFeaDict& fea = iter->second;
    NormalizeFeature(&fea);
  }
}

void LtFeaExtractor::ExtractTopicFea(const FeatureVector& fea_vec,
                                     UserLongTermFeature* lt_fea) const {
  // 特征抽取
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const reco::Feature& fea = fea_vec.feature(i);
    if (fea.weight() <= 1e-6) continue;
    if (fea.has_item_type() && fea.item_type() == reco::kNews) {
      AddFeature(fea, 1.0, &lt_fea->topics);
    }
  }
  // 归一化
  NormalizeFeature(&lt_fea->topics);
}

void LtFeaExtractor::ExtractVideoCateFea(const reco::CategoryFeatureVector& fea_vec,
                                         UserLongTermFeature* lt_fea) const {
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const reco::CategoryFeature &cat_fea = fea_vec.feature(i);
    if (cat_fea.literal().level() != 0) continue;
    if (cat_fea.weight() <= 1e-6) continue;
    AddFeature(cat_fea, 1.0, &lt_fea->video_l1_cates);
  }
  for (auto iter = lt_fea->video_l1_cates.begin(); iter != lt_fea->video_l1_cates.end(); ++iter) {
    lt_fea->video_click_num += iter->second;
  }
  // TODO(jianhuang) 原逻辑没进行 normalize，再确认下
}

}  // namespace leafserver
}  // namespace reco
