#pragma once

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/user.pb.h"

namespace reco {
class NewsIndex;

namespace leafserver {

// imei 长期兴趣抽取类
// copy 自lt_fea_extractor
// 1. category 偏好
// 2. topic 偏好
// 3. tag 偏好
// 4. keyword 偏好
class LtImfaFeaExtractor {
 public:
  explicit LtImfaFeaExtractor(const reco::NewsIndex* index) : news_index_(index) {}
  ~LtImfaFeaExtractor() {}

  void ExtractFeature(const reco::user::UserInfo& user_info,
                      UserLongTermFeature* lt_fea);

 private:
  void ExtractCateFea(const reco::CategoryFeatureVector& fea_vec,
                      UserLongTermFeature* lt_fea) const;
  void ExtractKeywordFea(const FeatureVector& fea_vec, UserLongTermFeature* lt_fea) const;
  void ExtractTagFea(const FeatureVector& fea_vec, UserLongTermFeature* lt_fea) const;
  void ExtractTopicFea(const FeatureVector& fea_vec, UserLongTermFeature* lt_fea) const;

 private:
  const reco::NewsIndex* news_index_;
  const reco::user::UserInfo* user_info_;
};

}  // namespace leafserver
}  // namespace reco
