#pragma once

#include "base/time/time.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

namespace reco {
class NewsIndex;

namespace leafserver {
// 用户特征融合,
// 这个版本为了和之前保持一致, 后续可能不需有这个类
//
class UserFeaMerger {
 public:
  UserFeaMerger() {}
  ~UserFeaMerger() {}

  void Merge(const reco::user::UserInfo& user_info, UserFeature* user_fea);

 private:
  void CalcInfluence(UserFeature* user_fea);
  void MergeFeature(UserFeature* user_fea);
  void AdjustByCategoryPopRatio(UserFeature* user_fea);

  void MergeFeaDict(const UserFeaDict& feas, UserFeaDict* ret_feas, float influence) const;

  void MergeNestedFeaDict(const NestedUserFeaDict& fea_map,
                          NestedUserFeaDict* ret_feas, float influence) const;

  double CalcDmpClickDiscount() const;

  float CalcRoleWeight(const UserFeature* user_fea) const;

  void PrintCateFea(const std::string& prefix, const UserFeaDict& feas) const;

 private:
  const reco::user::UserInfo* user_info_;
  base::Time current_time_;

  static const int kRoleClick = 10;

};
}  // namespace leafserver
}  // namespace reco
