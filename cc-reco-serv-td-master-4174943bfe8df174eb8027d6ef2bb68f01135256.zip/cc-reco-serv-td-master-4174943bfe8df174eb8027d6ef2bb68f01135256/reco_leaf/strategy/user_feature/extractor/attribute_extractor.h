#pragma once

#include <string>

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "base/container/dense_hash_map.h"

namespace reco {
class NewsIndex;

namespace leafserver {

// 用户基本属性获取:
// 1. 用户 poi / area 信息
// 2. TODO(jianhuang) 用户 年龄 / 职业 / 性别 等基本属性
//
class AttributeExtractor {
 public:
  explicit AttributeExtractor(const reco::NewsIndex* index) : news_index_(index) {}
  ~AttributeExtractor() {};

  void ExtractFeature(const reco::user::UserInfo& user_info,
                      const RecommendRequest& request,
                      UserAttribute* attr);

 private:
  // 地域相关信息
  void ParseUserAreaInfo(const reco::user::UserInfo& user_info,
                         const RecommendRequest& request,
                         UserAttribute* behavior_fea);

  bool ParseRegionId(const reco::user::UserInfo& user_info, const RecommendRequest& request,
                     int64 *prov_id, int64 *city_id);

  bool ParseUserPOI(const reco::user::UserInfo& user_info, const RecommendRequest& request,
                   std::unordered_set<int64> *user_area_ids, std::unordered_set<int64> *user_district_ids);
  bool ParseCoord(const std::string& coord, double* latitude, double* longitude) const;

  // 用户低俗忍受程度
  void ParseUserDirtyLevel(const reco::user::UserInfo& user_info,
                           const RecommendRequest& request,
                           UserAttribute* behavior_fea);

  // 用户标题党忍受程度
  void ParseUserBluffingLevel(const reco::user::UserInfo& user_info,
                              const RecommendRequest& request,
                              UserAttribute* behavior_fea);

  bool IsVideoUser(const reco::user::UserInfo& user_info);

 private:
  const reco::NewsIndex* news_index_;
};

}  // namespace leafserver
}  // namespace reco
