#include "reco/serv/reco_leaf/strategy/user_feature/extractor/behavior_fea_extractor.h"

#include <algorithm>

#include "reco/serv/reco_leaf/strategy/user_feature/base/category_constrain.h"
#include "reco/serv/reco_leaf/strategy/user_feature/base/user_fea_extract_util.h"
#include "reco/serv/reco_leaf/strategy/user_feature/base/category_constrain.h"
#include "reco/serv/reco_leaf/strategy/common/feature_api-inl.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/bizc/reco_index/news_index.h"
#include "base/container/dense_hash_set.h"
#include "nlp/common/nlp_util.h"
#include "base/time/time.h"

DEFINE_int64_counter(user_feature, success_get_item_category_num, 0, "max response time, unit: ms");
DEFINE_int64_counter(user_feature, fail_get_item_category_num, 0, "success num");

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

void BehaviorFeaExtractor::ExtractFeature(const UserInfo& user_info,
                                          const RecommendRequest& request,
                                          UserBehaviorFeature* behavior_fea) {
  behavior_fea->Reset();
 
  user_info_ = &user_info;
  request_ = &request;
  current_time_ = base::Time::Now();

  // 订阅关键词行为
  ParseSubscriptWords(user_info, behavior_fea);

  // 订阅源行为
  ParseSubscriptSources(user_info, behavior_fea);

  // 不喜欢行为
  ParseDislikeFea(user_info, behavior_fea);

  // 用户角色选择行为
  ParseUserRole(user_info, behavior_fea);

  // 进入频道行为
  ParseChannelEnterInfo(user_info, behavior_fea);

  // 频道选择
  ParseChannelChange(user_info, behavior_fea);

  // 类别下展现、点击 ctr
  CalcCateStats(user_info, behavior_fea);
}

void BehaviorFeaExtractor::ParseUserRole(const UserInfo& user_info,
                                         UserBehaviorFeature* behavior_fea) {
  if (!user_info.has_user_role()) return;

  // 用户角色选择
  const reco::user::UserRole& user_role = user_info.user_role();

  if (user_role.categories_size() > 0) {
    if (!base::Time::FromStringInFormat(user_role.setting_time().c_str(),
                                        "%Y-%m-%d %H:%M:%S", &behavior_fea->role_set_time)) {
      LOG(WARNING) << "user role settime format error, " << user_role.setting_time();
      return;
    }

    for (int i = 0; i < user_role.categories_size(); ++i) {
      const reco::Category& role_category = user_role.categories(i).literal();
      float weight =  user_role.categories(i).weight();

      if (role_category.level() == 0) {
        const std::string& l1_cate = role_category.category();
        if (!CategoryConstrain::IfDoLevel1Category(l1_cate)) continue;
        behavior_fea->role_l1_cates[l1_cate] += weight;

      } else if (role_category.level() == 1) {
        const std::string& l1_cate = role_category.parents(0);
        if (!CategoryConstrain::IfDoLevel2Category(l1_cate)) continue;
        FeaKeyVal& l2_cates = behavior_fea->role_l2_cates[l1_cate];
        const std::string& l2_cate = role_category.category();
        l2_cates[l2_cate] += weight;
      }
    }
  } else if (user_role.user_image_size() > 0) {
    if (!base::Time::FromStringInFormat(user_role.user_image_setting_time().c_str(),
                                        "%Y-%m-%d %H:%M:%S", &behavior_fea->role_set_time)) {
      LOG(WARNING) << "user role settime format error, " << user_role.user_image_setting_time();
      return;
    }
    const auto role_category_map = &LeafDataManager::GetGlobalData()->user_role_categories;
    for (int i = 0; i < user_role.user_image_size(); ++i) {
      const std::string& role = user_role.user_image(i);
      auto iter = role_category_map->find(role);
      if (iter == role_category_map->end()) {
        LOG(WARNING) << "role not in role cateogry map. " << role;
        continue;
      }
      const std::vector<std::pair<std::string, float> >& category_vec = iter->second;
      for (size_t jdx = 0; jdx < category_vec.size(); ++jdx) {
        const std::string& category = category_vec[jdx].first;
        float weight = category_vec[jdx].second;
        behavior_fea->role_l1_cates[category] += weight;
      }
    }
  }

  // normalize l1
  NormalizeFeature(&behavior_fea->role_l1_cates);
  // normalize l2
  for (auto iter = behavior_fea->role_l2_cates.begin();
       iter != behavior_fea->role_l2_cates.end(); ++iter) {
    CateFeaDict& fea = iter->second;
    NormalizeFeature(&fea);
  }
}

void BehaviorFeaExtractor::ParseChannelChange(const UserInfo& user_info,
                                              UserBehaviorFeature* behavior_fea) {
  if (!user_info.has_channel_info()) return;

  const auto& channel_category_map = LeafDataManager::GetGlobalData()->channel_categories;

  base::Time set_time;
  const reco::user::ChannelInfo& channel_info = user_info.channel_info();
  if (!base::Time::FromStringInSeconds(channel_info.setting_time().c_str(), &set_time)) {
    LOG(WARNING) << "parse channel info setting time fail, " << channel_info.Utf8DebugString();
    return;
  }
  base::TimeDelta delta = current_time_ - set_time;
  if (delta.InHours() < 0 || delta.InHours() >= 24 * 7) {
    return;
  }
  // 加入新加的 channel 对应的分类
  float time_ratio = 1;
  base::dense_hash_set<uint64> old_channels;
  old_channels.set_empty_key(0);
  for (int idx = 0; idx < channel_info.old_channel_list_size(); ++idx) {
    old_channels.insert(channel_info.old_channel_list(idx));
  }
  std::vector<std::string> flds;
  for (int idx = 0; idx < channel_info.new_channel_list_size(); ++idx) {
    int64 cid = channel_info.new_channel_list(idx);
    if (old_channels.find(cid) != old_channels.end()) continue;

    auto channel_it = channel_category_map.find(cid);
    if (channel_it == channel_category_map.end()) continue;

    for (size_t jdx = 0; jdx != channel_it->second.size(); ++jdx) {
      const std::string& related_cate = channel_it->second.at(jdx).first;
      float weight = channel_it->second.at(jdx).second;
      if (related_cate.empty()) continue;
      flds.clear();
      base::SplitString(related_cate, "-", &flds);
      if (flds.size() >= 1 && !flds[0].empty()) {
        behavior_fea->subscript_channel_cates[flds[0]] += weight * time_ratio;
      }
      if (flds.size() >= 2 && !flds[1].empty()) {
        behavior_fea->subscript_channel_cates[flds[1]] += weight * time_ratio;
      }
    }
  }
}

void BehaviorFeaExtractor::ParseChannelEnterInfo(const UserInfo& user_info,
                                                 UserBehaviorFeature* behavior_fea) {
  if (user_info.shown_history_size() <= 0) return;

  const auto& channel_category_map = LeafDataManager::GetGlobalData()->channel_categories;

  // 获取用户在分频道的请求数
  base::Time expire_time = current_time_ - base::TimeDelta::FromHours(15 * 24);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  for (int i = user_info.shown_history_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& show_item = user_info.shown_history(i);
    if (show_item.view_timestamp() < expire_timestamp) break;
    if (!show_item.has_channel_id()
        || show_item.channel_id() == reco::common::kRecoChannelId) continue;
    // 是否存在于 channel_category 的列表中
    auto channel_it = channel_category_map.find(show_item.channel_id());
    if (channel_it == channel_category_map.end()) continue;
    for (size_t jdx = 0; jdx != channel_it->second.size(); ++jdx) {
      const std::string& str_category = channel_it->second.at(jdx).first;
      float weight = channel_it->second.at(jdx).second;
      if (str_category.empty()) continue;
      behavior_fea->enter_channel_cates[str_category] += weight;
    }
  }

  // 模拟计算刷屏数
  for (auto it = behavior_fea->enter_channel_cates.begin();
       it != behavior_fea->enter_channel_cates.end(); ++it) {
    float screen_num = std::max(1.0f, it->second / kItemNumPerScreen);
    if (screen_num < 3) continue;
    it->second = screen_num;
  }
}

void BehaviorFeaExtractor::ParseDislikeFea(const UserInfo& user_info,
                                           UserBehaviorFeature* behavior_fea) {
  if (user_info.dislike_info_size() == 0
      && !user_info.has_dislike_profile()) return;

  // 根据 dislike profile 来解析 dislike fea
  ParseDislikeProfile(user_info, behavior_fea);

  // 根据 dislike info 来解析 dislike fea
  ParseDislikeInfo(user_info, behavior_fea);
}

void BehaviorFeaExtractor::ParseSubscriptWords(const UserInfo& user_info,
                                               UserBehaviorFeature* behavior_fea) {
  if (!user_info.has_subscription()
      || user_info.subscription().subscription_size() == 0) {
    return;
  }

  float sum_weight = 0;
  const reco::user::Subscription& subscription = user_info.subscription();
  int max_size = subscription.subscription_size();
  if (max_size > kMaxSubscriptWords) {
    max_size = kMaxSubscriptWords;
  }
  for (int i = 1; i <= max_size; ++i) {
    // 订阅时间是否有问题
    int idx = subscription.subscription_size() - i;
    if (idx >= subscription.setting_time_size()) {
      LOG(WARNING) << "subscription time and word not matching";
      break;
    }
    // 相同的订阅词只记录最近一次订阅
    std::string word = nlp::util::NormalizeLine(subscription.subscription(idx));
    if (behavior_fea->subscript_words.find(word) != behavior_fea->subscript_words.end()) continue;
    // 订阅时间解析失败
    base::Time set_time;
    if (!base::Time::FromStringInSeconds(subscription.setting_time(idx).c_str(), &set_time)) {
      LOG(WARNING) << "subscription setting time format error, " << subscription.setting_time(idx);
      continue;
    }
    // 根据订阅时间，给予不同的权重
    int show_since_set = UserFeaExtractUtil::CountShowSinceTime(user_info, set_time);
    base::TimeDelta delta = current_time_ - set_time;
    float weight = 0.3;
    if (delta.InMinutes() < 30
        || (delta.InDays() < 7 && show_since_set < 30)) {
      weight = 1;
    } else if (delta.InHours() <= 24) {
      weight = 0.7;
    } else if (delta.InDays() <= 7) {
      weight = 0.5;
    } else if (delta.InDays() <= 15) {
      weight = 0.4;
    }
    behavior_fea->subscript_words.insert(std::make_pair(word, weight));
    sum_weight += weight;

    int64 subscript_time = int64(set_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond);
    if (subscript_time > behavior_fea->last_subscript_word_time) {
      behavior_fea->last_subscript_word_time = subscript_time;
    }
  }
}

void BehaviorFeaExtractor::ParseSubscriptSources(const UserInfo& user_info,
                                                 UserBehaviorFeature* behavior_fea) {
  if (!user_info.has_wemedia_info()) return;

  const reco::user::FollowWeMediaInfo& follow_infos = user_info.wemedia_info();
  for (int idx = 0; idx < follow_infos.info_size(); ++idx) {
    const reco::user::WeMediaInfo& info = follow_infos.info(idx);
    // 根据订阅时间，给予不同的权重
    base::Time set_time = base::Time::FromDoubleT(info.follow_timestamp() / 1e6);
    int show_since_set = UserFeaExtractUtil::CountShowSinceTime(user_info, set_time);
    base::TimeDelta delta = current_time_ - set_time;
    float weight = 0.3;
    if (delta.InMinutes() < 30
        || (delta.InDays() < 7 && show_since_set < 30)) {
      weight = 1;
    } else if (delta.InHours() <= 24) {
      weight = 0.7;
    } else if (delta.InDays() <= 7) {
      weight = 0.5;
    } else if (delta.InDays() <= 15) {
      weight = 0.4;
    }

    behavior_fea->subscript_sources.insert(std::make_pair(info.wemedia_name(), weight));
  }
}

void BehaviorFeaExtractor::ParseDislikeProfile(const UserInfo& user_info,
                                               UserBehaviorFeature* behavior_fea) {
  if (!user_info.has_dislike_profile()) return;
  VLOG(1) << "dislike debug : " << user_info.identity().user_id()
          << base::StringReplace(user_info.dislike_profile().Utf8DebugString(), "\n", " ", true);

  const auto& channel_name = LeafDataManager::GetGlobalData()->channel_name;
  const auto iter = channel_name.find(request_->channel_id());
  const std::string channel_tag = iter != channel_name.end() ? iter->second : "";
  float kInfluenceRatio = 1;
  const int kCategoryExpiredDay = 90;
  const int kTagExpiredDay = 365;
  const int kSourceExpiredDay = 365;
  const int kVideoExpiredDay = 7;
  const int kItemTypeExpiredDay = 365;
  const reco::user::DislikeProfile& dislike_profile = user_info.dislike_profile();
  int dislike_video_num = 0;
  for (int i = 0; i < dislike_profile.manual_reasons_size(); ++i) {
    const reco::user::DislikeReason& dislike_reason = dislike_profile.manual_reasons(i);

    base::Time set_time = base::Time::FromDoubleT((double)dislike_reason.timestamp() / 1e6);
    base::TimeDelta delta = current_time_ - set_time;
    int day_interval  = delta.InDays();
    if (day_interval < 0) continue;

    if (dislike_reason.type() == reco::user::kDislikeCategory) {
      if (day_interval >= kCategoryExpiredDay) continue;
      // calc influence
      if (day_interval > 3) {
        kInfluenceRatio = (kCategoryExpiredDay - day_interval) * 1.0 / kCategoryExpiredDay;
      }
      // dislike category
      auto dislike_iter = behavior_fea->dislike_cates.find(dislike_reason.text());
      if (dislike_iter == behavior_fea->dislike_cates.end()) {
        behavior_fea->dislike_cates.insert(std::make_pair(dislike_reason.text(), kInfluenceRatio));
      } else {
        dislike_iter->second = std::min(1.0f, dislike_iter->second + kInfluenceRatio);
      }
    } else if (dislike_reason.type() == reco::user::kDislikeSubCategory) {
      // dislike sub category
      if (day_interval >= kCategoryExpiredDay) continue;
      // calc influence
      if (day_interval > 3) {
        kInfluenceRatio = (kCategoryExpiredDay - day_interval) * 1.0 / kCategoryExpiredDay;
      }
      // insert
      auto dislike_iter = behavior_fea->dislike_sub_cates.find(dislike_reason.text());
      if (dislike_iter == behavior_fea->dislike_sub_cates.end()) {
        behavior_fea->dislike_sub_cates.insert(std::make_pair(dislike_reason.text(), kInfluenceRatio));
      } else {
        dislike_iter->second = std::min(1.0f, dislike_iter->second + kInfluenceRatio);
      }
    } else if (dislike_reason.type() == reco::user::kDislikeTag) {
      // dislike tag
      if (day_interval >= kTagExpiredDay) continue;
      if (dislike_reason.text() != channel_tag) {
        behavior_fea->dislike_tags.insert(std::make_pair(dislike_reason.text(), kInfluenceRatio));
      }
    } else if (dislike_reason.type() == reco::user::kDislikeSource) {
      // dislike source
      if (day_interval >= kSourceExpiredDay) continue;
      behavior_fea->dislike_sources.insert(std::make_pair(dislike_reason.text(), kInfluenceRatio));
    } else if (dislike_reason.type() == reco::user::kDislikeVideo) {
      if (day_interval >= kVideoExpiredDay) continue;
      int cnt = 1;
      if (dislike_reason.has_cnt()) {
        cnt = dislike_reason.cnt();
      }
      if (delta.InHours() < 2) {
        dislike_video_num += 3 * cnt;
      } else {
        dislike_video_num += cnt;
      }
      VLOG(1) << "dislike video";
    } else if (dislike_reason.type() == reco::user::kDislikeSemanticTag) {
      // dislike semantic tag
      if (day_interval >= kTagExpiredDay) continue;
      if (dislike_reason.text() != channel_tag) {
        behavior_fea->dislike_semantic_tags.insert(std::make_pair(dislike_reason.text(), kInfluenceRatio));
        VLOG(1) << user_info.identity().user_id() << " dislike semantic tag: " << dislike_reason.text();
      }
    } else if (dislike_reason.type() == reco::user::kDislikeItemType) {
      // dislike item_type
      if (day_interval >= kItemTypeExpiredDay) continue;
      int32 item_type = 0;
      if (base::StringToInt(dislike_reason.text(), &item_type)
          && reco::ItemType_IsValid(item_type) && item_type != 255)
      behavior_fea->dislike_item_types.insert(std::make_pair(static_cast<reco::ItemType>(item_type),
                                                             kInfluenceRatio));
    }
  }
  if (dislike_video_num >= 5) {
    behavior_fea->dislike_video_level = kDislikeVideoVeryHigh;
  } else if (dislike_video_num >= 3) {
    behavior_fea->dislike_video_level = kDislikeVideoHigh;
  } else if (dislike_video_num >= 1) {
    behavior_fea->dislike_video_level = kDislikeVideoLow;
  }
  VLOG(1) << behavior_fea->dislike_video_level;
}

void BehaviorFeaExtractor::ParseDislikeInfo(const UserInfo& user_info,
                                            UserBehaviorFeature* behavior_fea) {
  // // 用户没有明确表达不喜欢的具体原因，
  // // 1. 不出与不喜欢对应 item 特征重合度较高的 item
  // // 2. 对涉及的特征都做弱降权

  if (user_info.dislike_info_size() <= 0) return;

  const int kExpiredDay = 30;
  base::Time expire_time = current_time_ - base::TimeDelta::FromHours(kExpiredDay * 24);
  int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;

  reco::FeatureVector kw_feas;
  std::vector<reco::Category> categories;
  base::dense_hash_set<uint64> uniq_items;
  uniq_items.set_empty_key(0);
  for (int i = user_info.dislike_info_size() - 1; i >= 0; --i) {
    if ((int)behavior_fea->dislike_items.size() >= kMaxDislikeItems) break;

    const reco::user::ViewClickItem& dislike_item = user_info.dislike_info(i);
    if (!dislike_item.has_dislike_timestamp()) continue;
    if (dislike_item.dislike_timestamp() < expire_timestamp) break;
    // 相同的 id 只插入一次
    if (uniq_items.find(dislike_item.item_id()) != uniq_items.end()) continue;
    uniq_items.insert(dislike_item.item_id());
    // 需要有 category
    categories.clear();
    if (!news_index_->GetCategoriesByItemId(dislike_item.item_id(), &categories)
        || categories.empty()) {
      continue;
    }
    // 放入不喜欢列表
    behavior_fea->dislike_items.push_back(DislikeItemInfo());
    DislikeItemInfo& dislike_item_info = behavior_fea->dislike_items.back();
    dislike_item_info.item_id = dislike_item.item_id();
    dislike_item_info.category = categories[0].category();
    // 抽取不喜欢 item 对应的信息，作为不喜欢的特征列表
    if (!CategoryConstrain::IfDoLevel1Category(dislike_item_info.category)) continue;
    std::unordered_map<std::string, float>& item_feas = dislike_item_info.item_feas;
    kw_feas.clear_feature();
    if (news_index_->GetFeatureVectorByItemId(dislike_item.item_id(),
                                              reco::common::kKeyword, &kw_feas)) {
      for (int j = 0; j < kw_feas.feature_size(); ++j) {
        const reco::Feature& fea = kw_feas.feature(j);
        item_feas[fea.literal()] += fea.weight();
      }
    }
  }

  // TODO(jianhuang) 根据不喜欢 item，猜测不喜欢的是 category / tag / source
}

void BehaviorFeaExtractor::CalcCateStats(const UserInfo& user_info,
                                         UserBehaviorFeature* behavior_fea) {
  // category recent data

  // click set
  base::dense_hash_set<uint64> click_set;
  click_set.set_empty_key(0);
  base::Time since_time = current_time_ - base::TimeDelta::FromHours(168);
  int64 since_tm = since_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  for (int i = user_info.recent_click_size() - 1; i >= 0; --i) {
    const reco::user::ViewClickItem& clicked_item = user_info.recent_click().Get(i);
    if (clicked_item.click_timestamp() < since_tm) break;
    const uint64 item_id = clicked_item.item_id();
    click_set.insert(item_id);
  }
  //
  base::dense_hash_set<std::string> finish_cates;
  finish_cates.set_empty_key("");
  std::vector<reco::Category> category_list;
  for (int i = user_info.shown_history_size() - 1;
       i >= 0 && i >= user_info.shown_history_size() - 2000; --i) {
    const reco::user::ViewClickItem& show_item = user_info.shown_history(i);
    if (show_item.view_timestamp() < since_tm) break;
    if (show_item.channel_id() != reco::common::kRecoChannelId) continue;
    uint64 itemid = show_item.item_id();
    category_list.clear();
    std::string cate;
    if (news_index_->GetCategoriesByItemId(itemid, &category_list) && !category_list.empty()) {
      cate = category_list.at(0).category();
    } else {
      COUNTERS_user_feature__fail_get_item_category_num.Increase(1);
      continue;
    }
    COUNTERS_user_feature__success_get_item_category_num.Increase(1);
    behavior_fea->cate_stats[cate].show += 1;
    bool is_click = click_set.find(itemid) != click_set.end();
    if (is_click) {
      behavior_fea->cate_stats[cate].click += 1;
    }
    if (finish_cates.find(cate) == finish_cates.end()) {
      if (is_click) {
        finish_cates.insert(cate);
      } else {
        behavior_fea->cate_stats[cate].show_since_last_click += 1;
      }
    }
  }
}
}  // namespace leafserver
}  // namespace reco
