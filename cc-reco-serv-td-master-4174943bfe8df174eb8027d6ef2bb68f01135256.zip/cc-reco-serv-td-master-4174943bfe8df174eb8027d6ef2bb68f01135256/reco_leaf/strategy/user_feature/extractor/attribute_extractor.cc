#include "reco/serv/reco_leaf/strategy/user_feature/extractor/attribute_extractor.h"

#include <algorithm>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_util.h"
#include "reco/bizc/region/region_dict.h"
#include "reco/bizc/poi/city_area_hash_dict.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

void AttributeExtractor::ExtractFeature(const UserInfo& user_info,
                                        const RecommendRequest& request,
                                        UserAttribute* attr_fea) {
  // 用户地域信息
  ParseUserAreaInfo(user_info, request, attr_fea);
  // 用户低俗等级
  ParseUserDirtyLevel(user_info, request, attr_fea);
  attr_fea->is_video_user = IsVideoUser(user_info);
}

void AttributeExtractor::ParseUserAreaInfo(const UserInfo& user_info,
                                           const RecommendRequest& request,
                                           UserAttribute* attr_fea) {
  // region 信息
  ParseRegionId(user_info, request, &attr_fea->prov_id, &attr_fea->city_id);
  // poi 信息
  ParseUserPOI(user_info, request, &attr_fea->user_area_ids, &attr_fea->user_district_ids);
}

void AttributeExtractor::ParseUserDirtyLevel(const UserInfo& user_info,
                                             const RecommendRequest& request,
                                             UserAttribute* attr_fea) {
  if (!user_info.has_profile()
      || !user_info.profile().has_dirty_fea()) {
    attr_fea->dirty_level = kDirtyMid;
    return;
  }

  attr_fea->dirty_level = kDirtyMid;

  const reco::Feature& dirty_fea = user_info.profile().dirty_fea();
  if (base::LowerCaseEquals(dirty_fea.literal(), "VL")) {
    attr_fea->dirty_level = kDirtyVeryLow;

  } else if (base::LowerCaseEquals(dirty_fea.literal(), "L")) {
    attr_fea->dirty_level = kDirtyLow;

  } else if (base::LowerCaseEquals(dirty_fea.literal(), "H")) {
    attr_fea->dirty_level = kDirtyHigh;

  } else if (base::LowerCaseEquals(dirty_fea.literal(), "VH")) {
    attr_fea->dirty_level = kDirtyVeryHigh;
  }
}

void AttributeExtractor::ParseUserBluffingLevel(const UserInfo& user_info,
                                                const RecommendRequest& request,
                                                UserAttribute* attr_fea) {
  if (!user_info.has_profile()
      || !user_info.profile().has_bluffing_title_fea()) {
    attr_fea->bluffing_level = kBluffingMid;
    return;
  }

  attr_fea->bluffing_level = kBluffingMid;

  const reco::Feature& bluffing_title_fea = user_info.profile().bluffing_title_fea();
  if (base::LowerCaseEquals(bluffing_title_fea.literal(), "VL")) {
    attr_fea->bluffing_level = kBluffingVeryLow;

  } else if (base::LowerCaseEquals(bluffing_title_fea.literal(), "L")) {
    attr_fea->bluffing_level = kBluffingLow;

  } else if (base::LowerCaseEquals(bluffing_title_fea.literal(), "H")) {
    attr_fea->bluffing_level = kBluffingHigh;

  } else if (base::LowerCaseEquals(bluffing_title_fea.literal(), "VH")) {
    attr_fea->bluffing_level = kBluffingVeryHigh;
  }
}

bool AttributeExtractor::IsVideoUser(const UserInfo& user_info) {
  double video_weight = 0.0;
  if (user_info.has_profile() && user_info.profile().has_resource_type_feavec()) {
    for (int i = 0; i < user_info.profile().resource_type_feavec().feature_size(); ++i) {
      auto &fea = user_info.profile().resource_type_feavec().feature(i);
      if (fea.literal() == "视频") {
        video_weight = fea.weight();
        break;
      }
    }
  }
  return video_weight >= 5.0;
}

inline bool AttributeExtractor::ParseCoord(const std::string& coord,
                                           double *latitude, double *longitude) const {
  size_t pos = coord.find(",");
  if (pos == std::string::npos) return false;
  if (!base::StringToDouble(coord.substr(0, pos), latitude)
      || !base::StringToDouble(coord.substr(pos + 1), longitude)) return false;
  return true;
}

bool AttributeExtractor::ParseRegionId(const UserInfo& user_info,
                                       const RecommendRequest& request,
                                       int64 *prov_id, int64 *city_id) {
  *prov_id = 0;
  *city_id = 0;

  if (!request.has_uc_user_param()) {
    return false;
  }

  const auto& prov = request.uc_user_param().province();
  const auto& city = request.uc_user_param().city();
  if (prov.empty() && city.empty()) {
    VLOG(1) << "uc_user_param has no provice or city info";
    return false;
  }
  if (!city.empty()) {
    const std::string& str_city_id = reco::common::RegionSearcher::instance().SearchRegionCode(city);
    if (str_city_id.empty()) {
      return false;
    }
    if (!base::StringToInt64(str_city_id, city_id)) {
      LOG(WARNING) << "city id to int64 fail:" << str_city_id;
      return false;
    }
  }
  if (!prov.empty()) {
    const std::string& str_prov_id = reco::common::RegionSearcher::instance().SearchRegionCode(prov);
    if (!base::StringToInt64(str_prov_id, prov_id)) {
      LOG(WARNING) << "convert province id to int64 fail: " << str_prov_id;
      return false;
    }
  }

  VLOG(1) << "get region_id from uc user parameter [" << *prov_id << ", " << *city_id << "]";
  return true;
}

bool AttributeExtractor::ParseUserPOI(const UserInfo& user_info,
                                      const RecommendRequest& request,
                                      std::unordered_set<int64> *user_area_ids,
                                      std::unordered_set<int64> *user_district_ids) {
  user_area_ids->clear();
  user_district_ids->clear();

  int64 cur_city_id = -1;
  reco::poi::AreaInfo area_info;

  // 用户当前所在位置的信息
  if (request.has_uc_user_param()
      && request.uc_user_param().has_latitude()
      && request.uc_user_param().has_longitude()) {
    double latitude = request.uc_user_param().latitude();
    double longitude = request.uc_user_param().longitude();
    if (reco::poi::CityAreaHashSearcher::instance().GetAreaInfoByCoord( latitude, longitude, &area_info)) {
      cur_city_id = poi::CityAreaHashSearcher::instance().GetCityIDByDistrictID(area_info.district_id);
      user_district_ids->insert(area_info.district_id);
      if (area_info.area_id > 0) {
        user_area_ids->insert(area_info.area_id);
      }
      VLOG(1) << "user current position [" << latitude << ", " << longitude << "] ["
              << area_info.province << "." << area_info.city << "."
              << area_info.district << "." << area_info.area << "] ["
              << area_info.district_id << ", " << area_info.area_id << "]";
    } else {
      VLOG(1) << "get area info by corrd fail: " << latitude << ", " << longitude;
    }
  }

  // 加入用户画像的位置
  double latitude, longitude;
  if (user_info.has_ali_profile()) {
    const auto &ali_profile = user_info.ali_profile();
    if (ali_profile.has_amp_home_yx()
        && ParseCoord(ali_profile.amp_home_yx(), &latitude, &longitude)
        && poi::CityAreaHashSearcher::instance().GetAreaInfoByCoord(latitude, longitude, &area_info)
        && poi::CityAreaHashSearcher::instance().GetCityIDByDistrictID(area_info.district_id) == cur_city_id) {
      user_district_ids->insert(area_info.district_id);
      if (area_info.area_id > 0) {
        user_area_ids->insert(area_info.area_id);
      }
      VLOG(1) << "user home position [" << latitude << ", " << longitude << "] ["
              << area_info.province << "." << area_info.city << "."
              << area_info.district << "." << area_info.area << "] ["
              << area_info.district_id << ", " << area_info.area_id << "]";
    }
    // if (ali_profile.has_amp_company_yx()
    //     && ParseCoord(ali_profile.amp_company_yx(), &latitude, &longitude)
    //     && reco::poi::CityAreaHashSearcher::instance().GetAreaInfoByCoord(latitude, longitude, &area_info)
    //     && reco::poi::CityAreaHashDict::GetCityIDByDistrictID(area_info.district_id) == cur_city_id) {
    //   user_district_ids->insert(area_info.district_id);
    //   if (area_info.area_id > 0) {
    //     user_area_ids->insert(area_info.area_id);
    //   }
    //   VLOG(1) << "user company position [" << latitude << ", " << longitude << "] ["
    //           << area_info.province << "." << area_info.city << "."
    //           << area_info.district << "." << area_info.area << "] ["
    //           << area_info.district_id << ", " << area_info.area_id << "]";
    // }
  }

  return true;
}

}  // namespace leafserver
}  // namespace reco
