#include "reco/serv/reco_leaf/strategy/user_feature/extractor/st_fea_extractor.h"

#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/common/feature_api-inl.h"
#include "reco/serv/reco_leaf/strategy/user_feature/base/category_constrain.h"
#include "base/container/dense_hash_set.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

DEFINE_int32(recent_click_expire_hours, 24, "");
DEFINE_int32(session_click_expire_hours, 1, "");

void StFeaExtractor::ExtractFeature(const UserInfo& user_info,
                                         UserShortTermFeature* st_fea) {
  st_fea->Reset();
  current_time_ = base::Time::Now();
  // recent click time
  earliest_click_time_ = current_time_ - base::TimeDelta::FromHours(FLAGS_recent_click_expire_hours);
  // session click time
  session_click_time_ = current_time_ - base::TimeDelta::FromHours(FLAGS_session_click_expire_hours);

  ExtractClickFea(user_info, st_fea);

  ExtractShownFea(user_info, st_fea);
}

void StFeaExtractor::ExtractShownFea(const UserInfo& user_info,
                                          UserShortTermFeature* st_fea) const {
  // session fea
  // TODO(Jianhuang) 当前 session 的切割直接用时间卡，不准，需要优化
  int64 session_expire_timestamp = session_click_time_.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  st_fea->session_video_show_num = 0;
  st_fea->session_show_num = 0;
  st_fea->session_pv = 0;
  int64 last_timestamp = 0;
  for (int i = user_info.shown_history_size() - 1;
       i >= 0 && i >= user_info.shown_history_size() - 500; --i) {
    const reco::user::ViewClickItem& show_item = user_info.shown_history(i);
    if (show_item.view_timestamp() < session_expire_timestamp) break;

    // session show and pv
    st_fea->session_show_num += 1;
    if (show_item.view_timestamp() != last_timestamp) {
      st_fea->session_pv += 1;
      last_timestamp = show_item.view_timestamp();
    }

    // 视频一二级频道的视频展现不算到 session 里
    reco::ItemType item_type;
    if (news_index_->GetItemTypeByItemId(show_item.item_id(), &item_type)
        && item_type == reco::kPureVideo
        && show_item.has_channel_id()
        && !reco::common::IsVideoChannel(show_item.channel_id())) {
      st_fea->session_video_show_num += 1;
    }
  }
}


void StFeaExtractor::ExtractClickFea(const UserInfo& user_info,
                                     UserShortTermFeature* st_fea) const {

  static const std::unordered_set<int> kNewsItemTypeSet = {
    reco::kNews, reco::kReading, reco::kPicture, reco::kPictureNews,
  };

  int64 earliest_click_timestamp = earliest_click_time_.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  int64 session_click_timestamp = session_click_time_.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  double click_weight = 0.0;
  double click_idx_boost = 1;
  base::dense_hash_set<uint64> uniq_ids;
  uniq_ids.set_empty_key(0);
  std::vector<reco::Category> category_list;

  for (int i = user_info.recent_click_size() - 1; i >= 0; --i) {
    if (st_fea->st_click_num >= 100) break;
    const reco::user::ViewClickItem& clicked_item = user_info.recent_click().Get(i);
    // 点击发生时间过于久远, 丢弃. 按时间有序, 可以 break
    if (clicked_item.click_timestamp() < earliest_click_timestamp) break;
    // probe item 不计入 recent click
    if (clicked_item.has_probe_type() &&
        clicked_item.probe_type() != reco::kNoProbeType &&
        clicked_item.probe_type() != reco::kVideoProbe) continue;
    // 多次点击只算一次
    const uint64 item_id = clicked_item.item_id();
    if (uniq_ids.find(item_id) != uniq_ids.end()) continue;
    uniq_ids.insert(item_id);
    // item type
    ItemType item_type = reco::kNews;
    if (!news_index_->GetItemTypeByItemId(clicked_item.item_id(), &item_type)) {
      continue;
    }
    if (item_type != reco::kPureVideo
        && kNewsItemTypeSet.find(item_type) == kNewsItemTypeSet.end()) {
      continue;
    }
    // category
    category_list.clear();
    if (!news_index_->GetCategoriesByItemId(item_id, &category_list)
        || category_list.empty()) continue;

    // 权重逐渐降低
    click_weight = click_idx_boost;
    click_idx_boost *= 0.9;

    // video click
    bool is_session_click = (clicked_item.click_timestamp() >= session_click_timestamp);
    if (item_type == reco::kPureVideo) {
      st_fea->st_video_click_num += 1;
      if (is_session_click) {
        st_fea->session_video_click_num += 1;
      }
      AddVideoClick(clicked_item, category_list, click_weight, st_fea);
    } else {
      // NOTE(jianhuang) video 不进入文本特征
      st_fea->st_click_num += 1;
      if (is_session_click) {
        st_fea->session_click_num += 1;
      }
      AddNewsClick(clicked_item, category_list, click_weight, st_fea);
    }
  }

  if (st_fea->session_click_num > 0) {
    // NOTE(jianhuang) video 不进入文本特征, 索引计算 ratio 分母需要二者相加
    st_fea->session_video_click_ratio
        = st_fea->session_video_click_num / (st_fea->session_click_num + st_fea->session_video_click_num);
  }

  // 归一化
  NormalizeFeature(&st_fea->l1_cates);
  NormalizeFeature(&st_fea->topics);
  NormalizeFeature(&st_fea->video_tags);
  for (auto iter = st_fea->l2_cates.begin(); iter != st_fea->l2_cates.end(); ++iter) {
    CateFeaDict& fea = iter->second;
    NormalizeFeature(&fea);
  }
  for (auto iter = st_fea->cate_keywords.begin(); iter != st_fea->cate_keywords.end(); ++iter) {
    KeywordFeaDict& fea = iter->second;
    NormalizeFeature(&fea);
  }
  for (auto iter = st_fea->cate_tags.begin(); iter != st_fea->cate_tags.end(); ++iter) {
    TagFeaDict& fea = iter->second;
    NormalizeFeature(&fea);
  }
}

inline void StFeaExtractor::AddNewsClick(const reco::user::ViewClickItem& clicked_item,
                                         const std::vector<reco::Category>& category_list,
                                         double click_weight, UserShortTermFeature* st_fea) const {
  // recent click
  if (clicked_item.view_duration() >= 15) {
    base::Time view_time
        = base::Time::FromDoubleT(clicked_item.view_timestamp() / base::Time::kMicrosecondsPerSecond);
    int minute = (current_time_ - view_time).InMinutes();
    base::TimeDelta delta;
    if (minute > 0) {
      st_fea->recent_clicks.push_back(std::make_pair(clicked_item.item_id(), minute));
    }
  }

  // extract feature
  if (category_list.empty()) return;

  const reco::Category& l1_cate = category_list.at(0);

  if (!CategoryConstrain::IfDoLevel1Category(l1_cate.category()))  return;

  // 一级类别
  {
    reco::CategoryFeature fea;
    fea.set_item_type(reco::kNews);
    fea.mutable_literal()->CopyFrom(l1_cate);
    fea.set_weight(1);
    AddFeature(fea, click_weight, &st_fea->l1_cates);
    st_fea->raw_l1_cates[fea.literal().category()] += 1;
  }

  // 二级类别
  if (category_list.size() > 1
      && (CategoryConstrain::IfDoLevel2Category(l1_cate.category()))) {
    const reco::Category& l2_cate = category_list[1];
    reco::Feature fea;
    fea.set_item_type(reco::kNews);
    fea.set_literal(l2_cate.category());
    fea.set_weight(1);
    CateFeaDict& l2_feas = st_fea->l2_cates[l1_cate.category()];
    AddFeature(fea, click_weight, &l2_feas);
  }

  // 抽取 topic 特征
  uint64 item_id = clicked_item.item_id();
  reco::FeatureVector feature_vec;
  if (news_index_->GetFeatureVectorByItemId(item_id, reco::common::kTopic, &feature_vec)) {
    AddFeature(feature_vec, click_weight, &st_fea->topics);
  }
  // 抽取 keyword 特征
  if (news_index_->GetFeatureVectorByItemId(item_id, reco::common::kKeyword, &feature_vec)) {
    KeywordFeaDict& keywords = st_fea->cate_keywords[l1_cate.category()];
    AddFeature(feature_vec, click_weight, &keywords);
  }
  // 抽取 tag 特征
  if (news_index_->GetFeatureVectorByItemId(item_id, reco::common::kTag, &feature_vec)) {
    TagFeaDict& tags = st_fea->cate_tags[l1_cate.category()];
    AddFeature(feature_vec, click_weight, &tags);
  }
}

inline void StFeaExtractor::AddVideoClick(const reco::user::ViewClickItem& clicked_item,
                                          const std::vector<reco::Category>& category_list,
                                          double click_weight, UserShortTermFeature* st_fea) const {
  int video_length = news_index_->GetTotalVideoLengthByItemId(clicked_item.item_id());
  VLOG(1) << "recent click:" << clicked_item.item_id() << "\t" << video_length;
  if (video_length <= 0) {
    return;
  }
  double weight = clicked_item.view_duration() * 1.0 / video_length;
  weight = std::min(1.0, weight);
  TagFeaDict& video_tags = st_fea->video_tags;
  reco::FeatureVector feature_vec;
  if (news_index_->GetVideoTagFeatureVectorByItemId(clicked_item.item_id(), &feature_vec)) {
    for (int i = 0; i < feature_vec.feature_size(); ++i) {
      const reco::Feature& fea = feature_vec.feature(i);
      if (fea.weight() <= 1e-6) continue;
      AddFeature(fea, weight * click_weight, &video_tags);
      VLOG(1) << "add video tag from st: " << fea.literal() << " " << weight * click_weight;
    }
  }
  // NOTE(jianhuang) do nothing
  // TODO(jianhuang) check it
  //
  // // NOTE: 视频类的特征提取不受分类的限制
  // const reco::Category& l1_cate = category_list[0];
  // reco::CategoryFeature fea;
  // fea.set_item_type(reco::kPureVideo);
  // fea.mutable_literal()->CopyFrom(l1_cate);
  // fea.set_weight(1);
  // AddFeature(fea, click_weight, &st_fea->video_l1_cates);
}

}  // namespace leafserver
}  // namespace reco

