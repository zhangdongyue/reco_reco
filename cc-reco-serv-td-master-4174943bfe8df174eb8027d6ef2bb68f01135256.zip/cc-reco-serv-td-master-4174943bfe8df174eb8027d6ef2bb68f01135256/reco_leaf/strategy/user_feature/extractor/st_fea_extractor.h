#pragma once

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "base/time/time.h"

namespace reco {
class NewsIndex;

namespace leafserver {

// session 兴趣抽取
//
class StFeaExtractor {
 public:
  explicit StFeaExtractor(const reco::NewsIndex* index) : news_index_(index) {}
  ~StFeaExtractor() {}

  void ExtractFeature(const reco::user::UserInfo& user_info,
                      UserShortTermFeature* st_fea);

 private:
  void ExtractClickFea(const reco::user::UserInfo& user_info, UserShortTermFeature* st_fea) const;
  void ExtractShownFea(const reco::user::UserInfo& user_info, UserShortTermFeature* st_fea) const;

  void AddVideoClick(const reco::user::ViewClickItem& clicked_item,
                     const std::vector<reco::Category>& category_list,
                     double click_weight, UserShortTermFeature* st_fea) const;
  void AddNewsClick(const reco::user::ViewClickItem& clicked_item,
                    const std::vector<reco::Category>& category_list,
                    double click_weight, UserShortTermFeature* st_fea) const;

 private:
  const reco::NewsIndex* news_index_;
  base::Time current_time_;
  base::Time earliest_click_time_;
  base::Time session_click_time_;
};

}  // namespace leafserver
}  // namespace reco
