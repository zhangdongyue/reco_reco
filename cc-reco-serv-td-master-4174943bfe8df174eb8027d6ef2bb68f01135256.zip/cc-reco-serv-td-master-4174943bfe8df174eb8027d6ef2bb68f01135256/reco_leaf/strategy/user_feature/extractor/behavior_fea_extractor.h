#pragma once

#include <string>

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/user.pb.h"
#include "base/container/dense_hash_map.h"

namespace reco {
class NewsIndex;

namespace leafserver {

// 用户行为数据抽取：
// 1. 订阅词
// 2. 订阅自媒体
// 3. 用户角色
// 4. 进入频道
// 5. 选择频道
// 6. 不喜欢行为
//
class BehaviorFeaExtractor {
 public:
  explicit BehaviorFeaExtractor(const reco::NewsIndex* index) : news_index_(index) {}
  ~BehaviorFeaExtractor() {};

  void ExtractFeature(const reco::user::UserInfo& user_info,
                      const RecommendRequest& request,
                      UserBehaviorFeature* behavior_fea);

 private:
  // 订阅相关行为
  void ParseSubscriptWords(const reco::user::UserInfo& user_info, UserBehaviorFeature* behavior_fea);

  void ParseSubscriptSources(const reco::user::UserInfo& user_info, UserBehaviorFeature* behavior_fea);

  // 不喜欢相关行为
  void ParseDislikeFea(const reco::user::UserInfo& user_info, UserBehaviorFeature* behavior_fea);
  void ParseDislikeProfile(const reco::user::UserInfo& user_info, UserBehaviorFeature* behavior_fea);
  void ParseDislikeInfo(const reco::user::UserInfo& user_info, UserBehaviorFeature* behavior_fea);

  // 用户角色选择
  void ParseUserRole(const reco::user::UserInfo& user_info, UserBehaviorFeature* behavior_fea);

  // 进入频道相关行为
  void ParseChannelEnterInfo(const reco::user::UserInfo& user_info, UserBehaviorFeature* behavior_fea);
  // 频道选择
  void ParseChannelChange(const reco::user::UserInfo& user_info, UserBehaviorFeature* behavior_fea);

  // 统计类别上行为数据
  void CalcCateStats(const reco::user::UserInfo& user_info, UserBehaviorFeature* behavior_fea);
 private:
  static const int kMaxSubscriptWords = 100;
  static const int kMaxDislikeItems = 100;
  static const int kItemNumPerScreen = 10;

  const reco::NewsIndex* news_index_;
  const reco::user::UserInfo* user_info_;
  const RecommendRequest* request_;

  base::Time current_time_;
};

}  // namespace leafserver
}  // namespace reco
