#pragma once

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

#include "reco/bizc/proto/common.pb.h"
#include "reco/bizc/proto/user.pb.h"

namespace reco {
class NewsIndex;

namespace leafserver {
// dmp 数据抽取:
// 1. 浏览数据 -> 类别偏好
// 2. 浏览数据 -> topic 偏好
// 3. 浏览数据 -> tag 偏好
//
class DmpFeaExtractor {
 public:
  explicit DmpFeaExtractor(const reco::NewsIndex* index) : news_index_(index) {}
  ~DmpFeaExtractor() {};

  void ExtractFeature(const reco::user::UserInfo& user_info,
                      UserDmpFeature* dmp_fea);

 private:
  void ExtractCateFea(const reco::CategoryFeatureVector& fea_vec, UserDmpFeature* dmp_fea) const;

  void ExtractKeywordFea(const FeatureVector& fea_vec, UserDmpFeature* dmp_fea) const;

  void ExtractTopicFea(const FeatureVector& fea_vec, UserDmpFeature* dmp_fea) const;

 private:
  const reco::NewsIndex* news_index_;
};

}  // namespace leafserver
}  // namespace reco
