#pragma once

#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"
#include "reco/bizc/proto/user.pb.h"

namespace reco {
class NewsIndex;

namespace leafserver {

// 阿里特征抽取：
// 1. 根据 ali profile，从冷启动模型中获取用户偏好的类别信息
// 2. 根据 ali profile，抽取用户基本属性：性别 / 年龄 等
//
class AliFeaExtractor {
 public:
  explicit AliFeaExtractor(const reco::NewsIndex* index) : news_index_(index) {}
  ~AliFeaExtractor() {};

  void ExtractFeature(const reco::user::UserInfo& user_info,
                      UserAliFeature* ali_fea);

 private:
  void PredictCateFea(const reco::user::UserInfo& user_info, UserAliFeature* ali_fea) const;
  void ParseUserBasicAliInfo(const reco::user::UserInfo& user_info, UserAliFeature* ali_fea) const;

 private:
  const reco::NewsIndex* news_index_;
};

}  // namespace leafserver
}  // namespace reco
