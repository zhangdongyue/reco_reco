#include "reco/serv/reco_leaf/strategy/user_feature/extractor/user_fea_merger.h"

#include <algorithm>
#include <string>

#include "reco/serv/reco_leaf/strategy/user_feature/base/user_fea_extract_util.h"
#include "reco/serv/reco_leaf/strategy/user_feature/base/category_constrain.h"
#include "reco/serv/reco_leaf/strategy/common/feature_api-inl.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

DEFINE_double(dmp_click_discount, 0.2, "");
DEFINE_int32(dmp_max_click_used, 20, "");
DEFINE_int32(user_profile_sparse_threshold, 0, "");

void UserFeaMerger::Merge(const UserInfo& user_info, UserFeature* user_fea) {
  user_info_ = &user_info;
  current_time_ = base::Time::Now();
  // calc influence
  CalcInfluence(user_fea);
  // merge feature
  MergeFeature(user_fea);
}

void UserFeaMerger::MergeFeature(UserFeature* user_fea) {
  const auto& lt = user_fea->lt_fea;
  const auto& lt_imfa = user_fea->lt_imfa_fea;
  const auto& st = user_fea->st_fea;
  const auto& dmp = user_fea->dmp_fea;
  const auto& ali = user_fea->ali_fea;
  const auto& behavior = user_fea->behavior_fea;
  auto& merged_info = user_fea->merged_info;
  auto& merged_fea = user_fea->merged_fea;
  // l1 raw
  MergeFeaDict(lt.raw_l1_cates, &merged_fea.raw_l1_cates, 1);
  MergeFeaDict(lt_imfa.raw_l1_cates, &merged_fea.raw_l1_cates, 1);
  MergeFeaDict(st.raw_l1_cates, &merged_fea.raw_l1_cates, 1);
  // PrintCateFea("RawAfterSt", merged_fea.raw_l1_cates);
  MergeFeaDict(behavior.role_l1_cates, &merged_fea.raw_l1_cates, merged_info.role_influence * kRoleClick);
  // PrintCateFea("RawAfterBehavior", merged_fea.raw_l1_cates);
  // l1 category merged
  MergeFeaDict(lt.l1_cates, &merged_fea.l1_cates, merged_info.lt_influence);
  MergeFeaDict(lt_imfa.l1_cates, &merged_fea.l1_cates, merged_info.lt_imfa_influence);
  MergeFeaDict(st.l1_cates, &merged_fea.l1_cates, merged_info.st_influence);
  MergeFeaDict(dmp.l1_cates, &merged_fea.l1_cates, merged_info.dmp_influence);
  MergeFeaDict(ali.l1_cates, &merged_fea.l1_cates, merged_info.ali_influence);
  // PrintCateFea("AfterAli", merged_fea.l1_cates);
  MergeFeaDict(behavior.role_l1_cates, &merged_fea.l1_cates, merged_info.role_influence);
  // PrintCateFea("AfterBehavior", merged_fea.l1_cates);
  AdjustByCategoryPopRatio(user_fea);
  // PrintCateFea("AfterAdjustByCategoryPop", merged_fea.l1_cates);
  UserFeaExtractUtil::NormalizeUserFea(&merged_fea.l1_cates);
  // topic merged
  MergeFeaDict(lt.topics, &merged_fea.topics, merged_info.lt_influence);
  MergeFeaDict(lt_imfa.topics, &merged_fea.topics, merged_info.lt_imfa_influence);
  MergeFeaDict(st.topics, &merged_fea.topics, merged_info.st_influence);
  MergeFeaDict(dmp.topics, &merged_fea.topics, merged_info.dmp_influence);
  UserFeaExtractUtil::NormalizeUserFea(&merged_fea.topics);
  // video tags
  MergeFeaDict(lt.video_tags, &merged_fea.video_tags, merged_info.video_lt_influence);
  MergeFeaDict(st.video_tags, &merged_fea.video_tags, merged_info.video_st_influence);
  UserFeaExtractUtil::NormalizeUserFea(&merged_fea.video_tags);
  // l2 category merged
  MergeNestedFeaDict(lt.l2_cates, &merged_fea.l2_cates, merged_info.lt_influence);
  MergeNestedFeaDict(lt_imfa.l2_cates, &merged_fea.l2_cates, merged_info.lt_imfa_influence);
  MergeNestedFeaDict(st.l2_cates, &merged_fea.l2_cates, merged_info.st_influence);
  MergeNestedFeaDict(dmp.l2_cates, &merged_fea.l2_cates, merged_info.dmp_influence);
  MergeNestedFeaDict(behavior.role_l2_cates, &merged_fea.l2_cates, merged_info.role_influence);
  for (auto iter = merged_fea.l2_cates.begin(); iter != merged_fea.l2_cates.end(); ++iter) {
    UserFeaDict& feas = iter->second;
    UserFeaExtractUtil::NormalizeUserFea(&feas);
  }
  // keyowrd merged
  MergeNestedFeaDict(lt.cate_keywords, &merged_fea.cate_keywords, merged_info.lt_influence);
  MergeNestedFeaDict(lt_imfa.cate_keywords, &merged_fea.cate_keywords, merged_info.lt_imfa_influence);
  MergeNestedFeaDict(st.cate_keywords, &merged_fea.cate_keywords, merged_info.st_influence);
  MergeNestedFeaDict(dmp.cate_keywords, &merged_fea.cate_keywords, merged_info.dmp_influence);
  for (auto iter = merged_fea.cate_keywords.begin(); iter != merged_fea.cate_keywords.end(); ++iter) {
    UserFeaDict& feas = iter->second;
    UserFeaExtractUtil::NormalizeUserFea(&feas);
  }
  // tag fea
  MergeNestedFeaDict(lt.cate_tags, &merged_fea.cate_tags, merged_info.lt_influence);
  MergeNestedFeaDict(lt_imfa.cate_tags, &merged_fea.cate_tags, merged_info.lt_imfa_influence);
  MergeNestedFeaDict(st.cate_tags, &merged_fea.cate_tags, merged_info.st_influence);
  for (auto iter = merged_fea.cate_tags.begin(); iter != merged_fea.cate_tags.end(); ++iter) {
    UserFeaDict& feas = iter->second;
    UserFeaExtractUtil::NormalizeUserFea(&feas);
  }
  // confidence l1 category
  if (merged_info.total_click_num >= 20) {
    for (auto iter = merged_fea.l1_cates.begin(); iter != merged_fea.l1_cates.end(); ++iter) {
      if (iter->second >= 0.1 && iter->second * merged_info.total_click_num >= 5) {
        merged_fea.confidence_l1_cates.insert(iter->first);
      }
    }
  }
}

void UserFeaMerger::AdjustByCategoryPopRatio(UserFeature* user_fea) {
  std::unordered_map<std::string, double> pv_ratio;
  const auto& cate_stats = user_fea->behavior_fea.cate_stats;
  int sum_pv = 0;
  for (auto i = cate_stats.begin(); i != cate_stats.end(); ++i) {
    sum_pv += i->second.show;
  }
  if (sum_pv > 10) {
    for (auto i = cate_stats.begin(); i != cate_stats.end(); ++i) {
      pv_ratio[i->first] = i->second.show * 100.0 / sum_pv;
    }
  }

  auto& merged_fea = user_fea->merged_fea;
  for (auto i = merged_fea.l1_cates.begin(); i != merged_fea.l1_cates.end(); ++i) {
    auto iter = pv_ratio.find(i->first);
    if (iter != pv_ratio.end()) {
      i->second /= iter->second;
    }
  }
}

void UserFeaMerger::MergeFeaDict(const UserFeaDict& feas,
                                 UserFeaDict* merged_feas, float influence) const {
  if (influence <= 1e-6) return;
  for (auto iter = feas.begin(); iter != feas.end(); ++iter) {
    (*merged_feas)[iter->first] += iter->second * influence;
  }
}

void UserFeaMerger::MergeNestedFeaDict(const NestedUserFeaDict& fea_map,
                                       NestedUserFeaDict* merged_fea_map, float influence) const {
  if (influence <= 1e-6) return;
  for (auto iter = fea_map.begin(); iter != fea_map.end(); ++iter) {
    const std::string& category = iter->first;
    if (!CategoryConstrain::IfDoLevel1Category(category)) continue;
    const UserFeaDict& feas = iter->second;
    UserFeaDict& merged_feas = (*merged_fea_map)[category];
    MergeFeaDict(feas, &merged_feas, influence);
  }
}

void UserFeaMerger::CalcInfluence(UserFeature* user_fea) {
  UserMergedInfo& merge_info = user_fea->merged_info;
  const UserLongTermFeature& lt = user_fea->lt_fea;
  const UserShortTermFeature&  st = user_fea->st_fea;

  float adjust_dmp_click_num = 0;
  float adjust_ali_click_num = 0;
  merge_info.total_click_num = lt.click_num + st.st_click_num;
  merge_info.total_video_click_num = lt.video_click_num + st.st_video_click_num;
  // profile 稀疏用户使用 ali feature 补齐
  if (FLAGS_user_profile_sparse_threshold > 0
      && merge_info.total_click_num <= FLAGS_user_profile_sparse_threshold
      && user_fea->ali_fea.l1_cates.size() > 0) {
    merge_info.ali_influence = (FLAGS_user_profile_sparse_threshold -
                                merge_info.total_click_num) / FLAGS_user_profile_sparse_threshold;
    // 阿里画像折合成 2 条 click
    adjust_ali_click_num = 2;
  } else {
    // 若无 ali profile 则使用 dmp profile
    adjust_dmp_click_num =
        std::min((double)FLAGS_dmp_max_click_used, user_fea->dmp_fea.click_num * CalcDmpClickDiscount());
    if (adjust_dmp_click_num > 0) {
      merge_info.dmp_influence = adjust_dmp_click_num / (merge_info.total_click_num + adjust_dmp_click_num);
    }
    double max_dmp_influence = 0.2;
    if (merge_info.total_click_num < 10) {
      max_dmp_influence = 0.2 + (10 - merge_info.total_click_num) * 0.5 / 10;
    }
    merge_info.dmp_influence = std::min((double)merge_info.dmp_influence, max_dmp_influence);
  }

  // imei 画像
  const UserLongTermFeature& lt_imfa = user_fea->lt_imfa_fea;
  // TODO: 这里做一个简单的判断，只有当 imei 画像比长期画像更丰富时, 才用 imei 画像加权补充
  float adjust_lt_imfa_click_num = 0;
  if (merge_info.total_click_num < 5) {
    adjust_lt_imfa_click_num = std::max(0.0f, lt_imfa.click_num - lt.click_num);
    if (adjust_lt_imfa_click_num > 1e-3) {
      merge_info.total_click_num = lt.click_num + st.st_click_num + adjust_lt_imfa_click_num;
      merge_info.lt_imfa_influence = adjust_lt_imfa_click_num / merge_info.total_click_num;
      merge_info.lt_imfa_influence = std::min(1.0f, merge_info.lt_imfa_influence);
    }
  }

  if (merge_info.total_click_num >= 1) {
    if (st.st_click_num >= (lt.click_num + adjust_lt_imfa_click_num) * 0.5) {
      merge_info.st_influence = st.st_click_num * 1.5 / (st.st_click_num * 1.5 + lt.click_num + adjust_lt_imfa_click_num);
    } else {
      float lt_tmp = std::min(lt.click_num + adjust_lt_imfa_click_num, 400.0f);
      float st_tmp = std::min(st.st_click_num, 100.0f);
      merge_info.st_influence = st_tmp * 20 / (lt_tmp + st_tmp * 20 + 200);
      merge_info.st_influence = std::min(0.6f, merge_info.st_influence);
    }
    merge_info.lt_influence = std::max(0.0f, 1 - merge_info.st_influence - merge_info.lt_imfa_influence);
    float discount = 1 - merge_info.dmp_influence - merge_info.ali_influence;
    merge_info.lt_influence *= discount;
    merge_info.st_influence *= discount;
    merge_info.lt_imfa_influence *= discount;
  }

  if (merge_info.total_video_click_num >= 1) {
    if (st.st_video_click_num >= lt.video_click_num * 0.5) {
      merge_info.video_st_influence = st.st_video_click_num * 1.5 /
          (st.st_video_click_num * 1.5 + lt.video_click_num);
    } else {
      float lt_tmp = std::min(lt.click_num * 1.0, 400.0);
      float st_tmp = std::min(st.st_click_num * 1.0, 100.0);
      merge_info.video_st_influence = st_tmp * 20 / (lt_tmp + st_tmp * 20 + 200);
      merge_info.video_st_influence = std::min(0.6f, merge_info.video_st_influence);
    }
    merge_info.video_lt_influence = 1 - merge_info.video_st_influence;
  }

  merge_info.role_influence = CalcRoleWeight(user_fea);
  LOG(INFO) << "user_id:"  <<user_info_->identity().user_id()
            << ", lt_influenct:" << merge_info.lt_influence
            << ", lt_imfa_influenct:" << merge_info.lt_imfa_influence
            << ", st_influenct:" << merge_info.st_influence
            << ", video_lt_influenct:" << merge_info.video_lt_influence
            << ", video_st_influenct:" << merge_info.video_st_influence
            << ", dmp_influence:" << merge_info.dmp_influence
            << ", ali_influence:"<< merge_info.ali_influence
            << ", role_influence:"<< merge_info.role_influence
            << ", lt_click:" << lt.click_num
            << ", st_click:" << st.st_click_num
            << ", lt_imfa_click:" << lt_imfa.click_num
            << ", dmp_click:" << adjust_dmp_click_num
            << ", ali_click:" << adjust_ali_click_num;
  merge_info.total_click_num = lt.click_num + st.st_click_num + adjust_ali_click_num
      + merge_info.role_influence * kRoleClick + std::min(3.0f, adjust_dmp_click_num)
      + adjust_lt_imfa_click_num;
  merge_info.video_click_ratio = 0;
  if (lt.click_num > 0) {
    merge_info.video_click_ratio += lt.video_click_num / lt.click_num * merge_info.lt_influence;
  }
  if (st.st_click_num > 0) {
    merge_info.video_click_ratio += st.st_video_click_num / st.st_click_num * merge_info.st_influence;
  }
  if (merge_info.lt_influence + merge_info.st_influence < 1e-6) {
    merge_info.video_click_ratio = 0;
  } else {
    merge_info.video_click_ratio /= (merge_info.lt_influence + merge_info.st_influence);
  }
}

double UserFeaMerger::CalcDmpClickDiscount() const {
  if (!user_info_->has_dmp_profile()
      || !user_info_->dmp_profile().has_last_update_time()) {
    return FLAGS_dmp_click_discount;
  }

  base::Time update_time = base::Time::FromDoubleT(user_info_->dmp_profile().last_update_time() / 1e6);
  int day_num = (current_time_ - update_time).InDays();

  double dmp_click_discount = FLAGS_dmp_click_discount;
  if (day_num > 0) {
    dmp_click_discount *= 1 - 0.02 * day_num;
  }

  return dmp_click_discount > 1e-6 ? dmp_click_discount : 0;
}

float UserFeaMerger::CalcRoleWeight(const UserFeature* user_fea) const {
  const UserBehaviorFeature& behavior_fea = user_fea->behavior_fea;
  if (behavior_fea.role_l1_cates.empty()) return 0;

  base::TimeDelta delta = base::Time::Now() - behavior_fea.role_set_time;
  int day_interval  = delta.InDays();
  int hour_interval = delta.InHours();
  const int kDiscardDay = 90;
  if (hour_interval < 0 || day_interval >= kDiscardDay) return 0;

  float ratio = 0;
  if (user_fea->lt_fea.click_num >= 40) {
    ratio = 0.4;
  } else if (user_fea->lt_fea.click_num >= 20) {
    ratio = 0.45;
  } else if (user_fea->lt_fea.click_num >= 10) {
    ratio = 0.5;
  } else if (user_fea->lt_fea.click_num >= 5) {
    ratio = 0.55;
  } else if (user_fea->lt_fea.click_num > 0) {
    ratio = 0.6;
  } else {
    ratio = 0.7;
  }

  static const int kMaxShownAfterSet = 2000;
  int show_after_set = UserFeaExtractUtil::CountShowSinceTime(*user_info_, behavior_fea.role_set_time);
  if (show_after_set >= kMaxShownAfterSet) return 0;

  float time_infl_discount = 1;
  if (hour_interval >= 24) {
    time_infl_discount = std::pow((kDiscardDay - day_interval) * 1.0 / kDiscardDay, 2);
  }
  float req_infl_discount = std::pow(0.9, show_after_set * 1.0 / 100);
  float weight = ratio * std::min(time_infl_discount, req_infl_discount);

  return weight;
}

void UserFeaMerger::PrintCateFea(const std::string& prefix, const UserFeaDict& feas) const {
  for (auto iter = feas.begin(); iter != feas.end(); ++iter) {
    LOG(INFO) << "DEBUG, " << prefix << ", " << iter->first << ", " << iter->second;
  }
}

}  // namespace leafserver
}  // namespace reco
