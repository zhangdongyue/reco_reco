#include "reco/serv/reco_leaf/strategy/user_feature/extractor/ali_fea_extractor.h"

#include <string>
#include <unordered_set>
#include <vector>

#include "reco/serv/reco_leaf/strategy/user_feature/base/category_constrain.h"
#include "reco/serv/reco_model/frame/reco_model_predict.h"
#include "reco/serv/reco_model/frame/reco_model_extract_fealib.h"
#include "reco/serv/reco_leaf/strategy/common/feature_api-inl.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

void AliFeaExtractor::ExtractFeature(const UserInfo& user_info,
                                     UserAliFeature* ali_fea) {
  ali_fea->Reset();

  PredictCateFea(user_info, ali_fea);

  ParseUserBasicAliInfo(user_info, ali_fea);
}

void AliFeaExtractor::ParseUserBasicAliInfo(const UserInfo& user_info,
                                            UserAliFeature* ali_fea) const {
  // TODO(jianhuang) 把用户性别年龄等基本信息透传出来
}

void AliFeaExtractor::PredictCateFea(const UserInfo& user_info,
                                     UserAliFeature* ali_fea) const {
  uint64 user_id = user_info.identity().user_id();
  std::stringstream log_str;
  log_str << "uid=" << user_id << ", utdid=" << user_info.identity().utdid();
  log_str << ", has_ali_profile=" << (user_info.has_ali_profile() ? "true" : "false");
  if (user_info.has_ali_profile()) {
    reco::user::AliProfile profile = user_info.ali_profile();
    log_str << ", update_time=" << (profile.has_last_update_time() ?  profile.last_update_time() : 0)
            << ", gender=" << (profile.has_gp_gender() ? profile.gp_gender() : "")
            << ", age=" << (profile.has_gp_age() ?  profile.gp_age() : 0);
  }
  VLOG(1) << log_str.str();

  reco::reco_model::RecoModelThread reco_model_thread;
  reco::reco_model::RecoResult reco_result;
  reco::reco_model::GenerateUserAliFeaCombItemFea fea_generator;
  
  // 获取模型数据
  // reco_result.model = reco::reco_model::RecoModelProc::Instance()->GetActiveColdStartModel();
  // reco_result.weight = reco::reco_model::RecoModelProc::Instance()->GetActiveColdStartWeight();
  return;

  if (reco_result.model == NULL || reco_result.weight == NULL) {
    VLOG(1) << "active model is null";
    return;
  }
  
  // 抽取 user ali fea
  reco::reco_model::UserFeature user_feature;
  user_feature.ResetUserFeature();
  user_feature.user_id = user_id;
  user_feature.SetUserFeature(user_info);
  
  std::vector<std::pair<double, std::string> > lr_scores;
  for (auto iter = CategoryConstrain::kDoL1Cates.begin();
       iter != CategoryConstrain::kDoL1Cates.end(); ++iter) {
    // 抽取 item fea, 仅设置 category 信息
    const std::string& category = *iter;
  
    reco::reco_model::ItemFeature item_feature;
    item_feature.ResetItemFeature();
    item_feature.item_id = 100u;
    item_feature.category.push_back(category);
  
    reco::reco_model::RecoFeature reco_fea;
    reco::reco_model::LrFeature lr_features;
    reco_fea.user_feature = &user_feature;
    reco_fea.item_feature = &item_feature;
    fea_generator.ExtractFea(&reco_fea, &lr_features, NULL);

    if (lr_features.literal_fea.size() < 1) {
      LOG(INFO) << "uid=" << user_id << ", ali_literal_fea=" << lr_features.literal_fea.size();
      continue;
    }

    // reco_result.Clear();
    reco_result.LightlyClear();
    reco_model_thread.Predict(lr_features.literal_fea, &reco_result);
    reco_result.CalcScore();
    lr_scores.push_back(std::make_pair(reco_result.score, category));
  }
  
  // sort and get topN categories
  std::sort(lr_scores.begin(), lr_scores.end(), std::greater<std::pair<double, std::string> >());
  
  for (int idx = 0; idx < 5 && idx < (int)lr_scores.size(); ++idx) {
    reco::Category cat;
    cat.set_category(lr_scores[idx].second);
    cat.set_level(0);
    reco::CategoryFeature cat_fea;
    cat_fea.set_weight(lr_scores[idx].first);
    cat_fea.mutable_literal()->CopyFrom(cat);
    AddFeature(cat_fea, 1, &ali_fea->l1_cates);
  }
}

}  // namespace leafserver
}  // namespace reco

