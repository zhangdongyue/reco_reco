#include "reco/serv/reco_leaf/strategy/user_feature/extractor/dmp_fea_extractor.h"

#include <string>

#include "reco/serv/reco_leaf/strategy/user_feature/base/user_fea_extract_util.h"
#include "reco/serv/reco_leaf/strategy/user_feature/base/category_constrain.h"
#include "reco/serv/reco_leaf/frame/global_data.h"
#include "reco/serv/reco_leaf/strategy/common/feature_api-inl.h"
#include "reco/serv/reco_leaf/frame/inner/dmp_category_mapping.h"

namespace reco {
namespace leafserver {
DEFINE_int32(dmp_category_num, 5, "");
DEFINE_int32(dmp_keyword_num, 8, "");
DEFINE_int32(dmp_topic_num, 5, "");

void DmpFeaExtractor::ExtractFeature(const reco::user::UserInfo& user_info,
                                     UserDmpFeature* dmp_fea) {
  dmp_fea->Reset();

  //    || !user_info.dmp_profile().has_last_update_time()) return;
  if (user_info.has_sm_profile()
      && user_info.sm_profile().has_category_feavec()) {
    const auto& dmp_profile = user_info.sm_profile();

    if (dmp_profile.has_category_feavec()) {
      ExtractCateFea(dmp_profile.category_feavec(), dmp_fea);
    }

    if (dmp_profile.has_keyword_feavec()) {
      ExtractKeywordFea(dmp_profile.keyword_feavec(), dmp_fea);
    }
  }

  if (user_info.has_query_profile()
      && user_info.query_profile().has_category_feavec()) {
    const auto& dmp_profile = user_info.query_profile();

    if (dmp_profile.has_category_feavec()) {
      ExtractCateFea(dmp_profile.category_feavec(), dmp_fea);
    }

    if (dmp_profile.has_keyword_feavec()) {
      ExtractKeywordFea(dmp_profile.keyword_feavec(), dmp_fea);
    }
  }
}

void DmpFeaExtractor::ExtractCateFea(const reco::CategoryFeatureVector& fea_vec,
                                     UserDmpFeature* user_fea) const {
  // 类别特征抽取
  // TODO(jianhuang) 分拆一二级别特征，使得更清晰
  const auto category_mapping = LeafDataManager::GetGlobalData()->dmp_category_mapping;
  reco::CategoryFeature reco_fea;
  std::string l1_str;
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const reco::CategoryFeature& dmp_fea = fea_vec.feature(i);
    const reco::Category& dmp_category = dmp_fea.literal();
    l1_str = dmp_category.level() == 0 ? dmp_category.category() : dmp_category.parents(0);
    if (CategoryConstrain::IfDoLevel1Category(l1_str)) {
      reco_fea.CopyFrom(dmp_fea);
    } else if (!category_mapping->ConvertToRecoCategory(dmp_fea, &reco_fea)) {
      continue;
    }
    if (reco_fea.weight() < 1e-6) continue;
    const reco::Category& reco_category = reco_fea.literal();
    l1_str = reco_category.level() == 0 ? reco_category.category() : reco_category.parents(0);
    if (!CategoryConstrain::IfDoLevel1Category(l1_str)) continue;
    if (reco_category.level() == 0) {
      AddFeature(reco_fea, 1.0, &user_fea->l1_cates);
    } else if (reco_category.level() == 1
               && CategoryConstrain::IfDoLevel2Category(l1_str)) {
      reco::Feature fea;
      fea.set_item_type(reco::kNews);
      fea.set_literal(reco_category.category());
      fea.set_weight(reco_fea.weight());
      CateFeaDict& l2_feas = user_fea->l2_cates[l1_str];
      AddFeature(fea, 1.0, &l2_feas);
    }
  }

  // 一级类别特征选择和归一化
  UserFeaExtractUtil::SelectUserFea(&user_fea->l1_cates, FLAGS_dmp_category_num);
  user_fea->click_num = 0;
  for (auto iter = user_fea->l1_cates.begin(); iter != user_fea->l1_cates.end(); ++iter) {
    user_fea->click_num += iter->second;
  }
  UserFeaExtractUtil::NormalizeUserFea(&user_fea->l1_cates);

  // 二级类别特征选择和归一化
  for (auto iter = user_fea->l2_cates.begin(); iter != user_fea->l2_cates.end(); ++iter) {
    CateFeaDict& l2_cates = iter->second;
    UserFeaExtractUtil::SelectUserFea(&l2_cates, FLAGS_dmp_category_num);
    UserFeaExtractUtil::NormalizeUserFea(&l2_cates);
  }
}

void DmpFeaExtractor::ExtractKeywordFea(const FeatureVector& fea_vec,
                                        UserDmpFeature* dmp_fea) const {
  const auto category_mapping = LeafDataManager::GetGlobalData()->dmp_category_mapping;

  // 特征抽取
  std::string l1_str;
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    const auto& fea = fea_vec.feature(i);
    if (!fea.has_item_type()
        || fea.item_type() != reco::kNews
        || !fea.has_category()
        || fea.weight() < 1e-6) continue;
    if (CategoryConstrain::IfDoLevel1Category(fea.category())) {
      l1_str = fea.category();
    } else if (!category_mapping->ConvertToRecoCategoryLiteral(fea.category(), &l1_str)) {
      continue;
    }
    if (dmp_fea->l1_cates.find(l1_str) == dmp_fea->l1_cates.end()) continue;
    auto &keywords = dmp_fea->cate_keywords[l1_str];
    AddFeature(fea, 1.0, &keywords);
  }

  // 特征选择及归一化
  for (auto iter = dmp_fea->cate_keywords.begin(); iter != dmp_fea->cate_keywords.end(); ++iter) {
    auto& keywords = iter->second;
    UserFeaExtractUtil::SelectUserFea(&keywords, FLAGS_dmp_keyword_num);
    UserFeaExtractUtil::NormalizeUserFea(&keywords);
  }
}

void DmpFeaExtractor::ExtractTopicFea(const FeatureVector& fea_vec,
                                      UserDmpFeature* dmp_fea) const {
  for (int i = 0; i < fea_vec.feature_size(); ++i) {
    auto &fea = fea_vec.feature(i);
    if (!fea.has_item_type()
        || fea.item_type() != reco::kNews
        || fea.weight() < 1e-6) continue;
    AddFeature(fea, 1.0, &dmp_fea->topics);
  }
  UserFeaExtractUtil::SelectUserFea(&dmp_fea->topics, FLAGS_dmp_topic_num);
  UserFeaExtractUtil::NormalizeUserFea(&dmp_fea->topics);
}

}  // namespace leafserver
}  // namespace reco

