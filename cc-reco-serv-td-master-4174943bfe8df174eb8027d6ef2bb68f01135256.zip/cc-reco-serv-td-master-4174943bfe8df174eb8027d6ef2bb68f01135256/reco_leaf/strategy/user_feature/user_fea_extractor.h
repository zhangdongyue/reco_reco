#pragma once

#include <string>

#include "reco/bizc/proto/user.pb.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/reco_index/news_index.h"
#include "reco/serv/reco_leaf/strategy/user_feature/user_feature.h"

namespace reco {
class NewsIndex;

namespace leafserver {
class UserFeaMerger;
class LtFeaExtractor;
class LtImfaFeaExtractor;
class DmpFeaExtractor;
class AliFeaExtractor;
class AttributeExtractor;
class StFeaExtractor;
class BehaviorFeaExtractor;

// 用户特征抽取接口类, 负责:
// 1. 长期兴趣抽取
// 2. dmp 兴趣抽取
// 3. ali 兴趣抽取
// 4. 短期 / session 兴趣抽取
// 5. 行为数据抽取
// 6. 基本属性抽取
// 7. 属性融合 (old)
//
class UserFeaExtractor {
 public:
  explicit UserFeaExtractor(const reco::NewsIndex* index);
  ~UserFeaExtractor();

  // 用户特征抽取
  void ExtractUserFeature(const RecommendRequest* request,
                          const reco::user::UserInfo* user_info,
                          UserFeature* user_fea);

 private:
  void ResetEnv(const RecommendRequest* request,
                const reco::user::UserInfo* user_info);

  void ExtractRawFea(const RecommendRequest* request,
                     const reco::user::UserInfo* user_info,
                     UserFeature* user_fea);

 private:
  const NewsIndex* news_index_;
  const reco::user::UserInfo* user_info_;
  const RecommendRequest* request_;

  // 各类兴趣单独成抽取类
  LtFeaExtractor* lt_fea_extractor_;
  LtImfaFeaExtractor* lt_imfa_fea_extractor_;
  DmpFeaExtractor* dmp_fea_extractor_;
  AliFeaExtractor* ali_fea_extractor_;
  AttributeExtractor* attr_extractor_;
  StFeaExtractor* st_fea_extractor_;
  BehaviorFeaExtractor* behavior_fea_extractor_;
  UserFeaMerger* user_fea_merger_;

  base::Time current_time_;
};

}   // end namespace reco
}   // end namespace leafserver
