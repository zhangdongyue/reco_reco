#pragma once

#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_set>
#include <unordered_map>

#include "serving_base/expiry_map/expiry_map.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/reco_index/item_info.h"

namespace base {
class PseudoRandom;
}

namespace reco {
class NewsIndex;

namespace leafserver {
struct GlobalData;
class RecoStrategy;
class RecoContext;
class CostTrace;
class ReasonExplain;

class RankHooker {
 public:
  RankHooker();
  ~RankHooker();

  bool Recommend(const RecommendRequest& org_request,
                 RecommendResponse* response,
                 const reco::user::UserInfo& user_info,
                 const bool get_user_error,
                 CostTrace *cost_trace, thread::Thread* video_thread);

  bool WeMediaRecommend(const WeMediaRecommendRequest &request,
                        const reco::user::UserInfo& user_info,
                        WeMediaRecommendResponse *response,
                        bool get_user_error);

  bool ImCardRecommend(const reco::user::UserInfo& user_info,
                       bool get_user_error,
                       const ImCardRecoRequest &request,
                       ImCardRecoResponse *response,
                       CostTrace *cost_trace);

  bool GetNewsMap(const NewsMapRequest* request, NewsMapResponse *response);

  bool SceneCardRecommend(const reco::user::UserInfo& user_info,
                          bool get_user_error,
                          const SceneCardRecoRequest &request,
                          SceneCardRecoResponse *response,
                          CostTrace *cost_trace);

  bool HotCardRecommend(const reco::user::UserInfo& user_info,
                        bool get_user_error,
                        const HotCardRecommendRequest &request,
                        HotCardRecommendResponse *response,
                        CostTrace *cost_trace);

  bool GetIndexStatus(const GetIndexStatusRequest& request,
                      GetIndexStatusResponse* response);

  bool GetIndexQueue(const GetIndexQueueRequest& request,
                     GetIndexQueueResponse* response);

  bool TagRecommend(const TagRecommendRequest &request,
                    TagRecommendResponse *response);
 private:
  // 构建返回 response
  bool ConstructRecoResponse(const RecommendRequest& request,
                             const reco::user::UserInfo& user_info,
                             RecommendResponse* response,
                             RecoContext* reco_context);

  /*
  // 替换请求结果中的保量 item
  void ReplaceOriginItem(RecommendResponse* response);

  // 替换请求结果中的原创 item
  void ReplaceYcItem(RecommendResponse* response);
  */

  // 设置新闻角标
  void SetItemSubscript(const RecommendRequest &request,
                        const ItemInfo &item,
                        reco::leafserver::RecoResult *result);

  // 设置时间轴信息
  void SetTimeAxisInfo(const reco::user::UserInfo &user_info,
                       const ItemInfo &item,
                       std::unordered_set<uint64> *dedups,
                       reco::leafserver::RecoResult *result);

  // 设置时间轴最新进展信息
  void SetTimeAxisLatestNewsInfo(const reco::user::UserInfo &user_info,
                                 const ItemInfo &item,
                                 const std::string &event_tag,
                                 reco::leafserver::RecoResult *result);

  // 设置视频展示标签
  void SetVideoShowTag(const ItemInfo &item, reco::leafserver::RecoResult *result);

 private:
  const GlobalData* global_data_;
  const reco::NewsIndex* news_index_;

  std::vector<ItemInfo> reco_items_;
  std::vector<ImRecoResult> im_items_;
  std::vector<SceneRecoResult> scene_items_;
  std::vector<std::string> hit_tags_;
  bool has_more_;

  RecoStrategy* reco_strategy_;
  ReasonExplain* reason_explain_;

  base::PseudoRandom* random_;

  // 时间轴的展现历史
  static serving_base::ExpiryMap<std::string, uint32> *time_axis_shown_dict_;
};
}
}
