#!/bin/bash

start_time=`date -d "-5 min" +"%H:%M:%S"`
end_time=`date  +"%H:%M:%S"`
echo -n -e  "start from $start_time\t"

id_file=/serving/doc_sync/ids.txt

tail -10000 /serving/doc_server/log/doc_server.ERROR \
| grep "can't find item in oldb" | awk -F' ' '{print $2"."$11}' \
| awk -F'.' '{ if ($1 > "'$start_time'" && $1 <= "'$end_time'") print $3 }' | uniq > $id_file 

tail -10000 /serving/doc_server/log/doc_server.WARNING \
| grep "can't find item from oldb" | awk -F' ' '{print $2"."$12}' \
| awk -F'.' '{ if ($1 > "'$start_time'" && $1 <= "'$end_time'") print $3 }' | uniq >> $id_file 

if [ `wc -l $id_file|awk -F' ' '{print $1}'` -eq 0 ]
then
	echo "empty"
else
	echo ""
	/serving/doc_sync/doc_client_syncdata --log_dir=/serving/doc_sync/log --deadline=10 --id_file=$id_file
fi

echo
