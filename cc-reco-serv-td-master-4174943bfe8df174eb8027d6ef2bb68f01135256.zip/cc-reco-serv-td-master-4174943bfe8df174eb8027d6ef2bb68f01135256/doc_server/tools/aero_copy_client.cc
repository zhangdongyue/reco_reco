#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/base/aerospike_c/api/client.h"

DEFINE_string(aero_from_ips, "127.0.0.1:3000", "");
DEFINE_string(doc_from_aero_ns, "test", "test");
DEFINE_string(doc_from_aero_set, "doc_server", "doc server aero field name");

DEFINE_string(aero_to_ips, "127.0.0.1:3000", "");
DEFINE_string(doc_to_aero_ns, "test", "test");
DEFINE_string(doc_to_aero_set, "doc_server", "doc server aero field name");

DEFINE_string(item_id_file, "item_ids", "");

class AeroClient {
 public:
  AeroClient(std::string ips, std::string ns, std::string aero_set)
      : aero_client_(ips),
      aero_ns_(ns),
      aero_set_(aero_set) {}

  bool ReadAero(const std::string& key, std::string* value) {
    std::vector<std::string> bins;
    bins.push_back(kAeroColumn);
    std::vector<std::string> values;
    int retry_cnt = kAeroRetryCnt;
    while (retry_cnt-- > 0) {
      if (aero_client_.GetData(key, bins, &values, aero_ns_, aero_set_)
          && !values.empty() && !values[0].empty()) {
        break;
      }
    }

    if (retry_cnt < 0) {
      LOG(INFO) << "no such value, key: " << key << ", table: " << aero_set_;
      return false;
    }

    *value = values[0];
    LOG(INFO) << "read succ:" << key;
    return true;
  }

  bool WriteAero(const std::string& key, const std::string& value) {
    int retry_cnt = kAeroRetryCnt;
    while (retry_cnt-- > 0) {
      if (aero_client_.SetData(key, kAeroColumn, value, aero_ns_, aero_set_)) {
        LOG(INFO) << "write succ:" << key;
        return true;
      }
    }
    return false;
  }

 private:
  static const int kAeroRetryCnt = 3;
  static const char* kAeroColumn;
  reco::aero::Client aero_client_;
  std::string aero_ns_;
  std::string aero_set_;
};

const char* AeroClient::kAeroColumn = "data";

void SyncData(std::string* item_id, AeroClient* client_from, AeroClient* client_to) {
  std::string value;
  if (!client_from->ReadAero(*item_id, &value)) {
    LOG(ERROR) << "read aero failed:" << *item_id;
    return;
  }

  if (!client_to->WriteAero(*item_id, value)) {
    LOG(ERROR) << "write aero failed:" << *item_id;
    return;
  }

  return;
}


int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "aero copy");

  AeroClient client_from(FLAGS_aero_from_ips, FLAGS_doc_from_aero_ns, FLAGS_doc_from_aero_set);
  AeroClient client_to(FLAGS_aero_to_ips, FLAGS_doc_to_aero_ns, FLAGS_doc_to_aero_set);

  ::thread::ThreadPool *work_thread_pool = new thread::ThreadPool(10);

  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines)) {
    LOG(ERROR) << "read file err: " << FLAGS_item_id_file;
    return false;
  }
  LOG(INFO) << "item id num:" << lines.size();

  uint64 item_id = 0;
  for (auto i = 0u; i < lines.size(); ++i) {
    if (!base::StringToUint64(lines[i], &item_id)) continue;

    work_thread_pool->AddTask(NewCallback(&SyncData, &(lines[i]), &client_from, &client_to));
  }

  work_thread_pool->JoinAll();

  return 0;
}
