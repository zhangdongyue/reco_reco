#include <fstream>

#include "net/rpc/rpc.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "net/rpc_util/rpc_group.h"
#include "base/strings/string_split.h"
#include "reco/bizc/proto/reco_doc_server.pb.h"
#include "base/strings/string_number_conversions.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/base/hbase_c/api/hbase_client_pool.h"
#include "reco/bizc/proto/reco_convertor_server.pb.h"
#include "base/thread/blocking_queue.h"


DEFINE_string(id_file, "ids.txt", "item id list file");
DEFINE_string(dst_ips, "11.180.85.44", "sync data to:");
DEFINE_int32(port, 20013, "search server port");
DEFINE_int32(deadline, 10, "dead line");

DECLARE_string(hbase_thrift_ips);
DECLARE_int32(hbase_pool_size);
DEFINE_string(hbase_reco_item_table, "tb_reco_item", "hbase reco item table");

DEFINE_string(convertor_server_ip, "11.251.203.75,11.251.203.226,11.251.204.31", "server ip");
DEFINE_int32(convertor_server_port, 20021, "server port");
DEFINE_bool(convert_reco_item, false, "if true, use convertor to renew reco item");


thread::BlockingQueue<std::string> id_queue;
thread::BlockingQueue<std::string> cdoc_string_queue;
thread::BlockingQueue<reco::RecoItem> item_queue;
reco::convertor::ConvertorService::Stub* rpc_stub;

atomic_int update_cnt(0);
std::ofstream succeed_ids("succeed_ids.txt");

void GetFromHBase(std::vector<std::string>& item_ids) {
  if (item_ids.empty()) {
    return;
  }

  std::map<std::string, std::map<std::string, std::string> > row_map;
  int retry = 0;
  while (retry++ < 3) {
    reco::hbase::HBaseAutoCli cli = reco::hbase::HBaseAutoCli(10);
    reco::hbase::HBaseCli* client = cli.Get();
    if (client != NULL && client->BatchGetByKeys(FLAGS_hbase_reco_item_table, item_ids, &row_map)) {
      break;
    }
  }
  if (3 == retry) {
    LOG(ERROR) << "retry err";
    return;
  }

  for (auto iter = row_map.begin(); iter != row_map.end(); ++iter) {
    auto iter_data = iter->second.find("data:proto");
    if (iter_data != iter->second.end()) {
      cdoc_string_queue.Put(iter_data->second);
    }
  }
}

void GetRecoItems() {
  static const size_t batch_count = 200;
  std::vector<std::string> ids_to_get;

  while (true) {
    std::string item_id;
    if (!id_queue.Take(&item_id)) break;

    ids_to_get.push_back(item_id);
    if (ids_to_get.size() < batch_count) {
      continue;
    }
    GetFromHBase(ids_to_get);
    ids_to_get.clear();
  }
  GetFromHBase(ids_to_get);
}

void Convert(reco::RecoItem& item) {
  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(120);
  std::string cdoc_string;

  if (FLAGS_convert_reco_item) {
    reco::convertor::ConvertRawItemRequest request;
    reco::convertor::ConvertRawItemResponse response;
    request.mutable_raw_item()->CopyFrom(item.raw_item());
    request.set_convert_to_cdoc(true);
    rpc_stub->convertRawItem(&rpc, &request, &response, NULL);
    rpc.Wait();

    if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
      LOG(ERROR) << "convert raw item failed" << response.err_msg();
      return;
    } else {
      item_queue.Put(response.reco_item());
    }
  } else {
    reco::convertor::ConvertRecoItemRequest request;
    reco::convertor::ConvertRecoItemResponse response;
    request.mutable_reco_item()->CopyFrom(item);
    rpc_stub->convertRecoItem(&rpc, &request, &response, NULL);
    rpc.Wait();

    if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
      LOG(ERROR) << "convert raw item failed" << response.err_msg();
      return;
    } else {
      //item_queue.Put(response.reco_item());
    }
  }
}

void ConvertThread() {
  while (true) {
    std::string cdoc_string;
    if (!cdoc_string_queue.Take(&cdoc_string)) break;

    reco::RecoItem item;
    if (!item.ParseFromString(cdoc_string)) {
      LOG(ERROR) << "parse from string err";
      continue;
    }
    Convert(item);
  }
}

reco::convertor::ConvertorService::Stub* CreateConvertorStub() {
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = 3;
  options.timeout = 3000;
  std::vector<std::string> flds;
  base::SplitString(FLAGS_convertor_server_ip, ",", &flds);
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], FLAGS_convertor_server_port, 3000);
    options.servers.push_back(si);
  }
  net::rpc::RpcGroup* rpc_group = new net::rpc::RpcGroup(options);
  CHECK(rpc_group->Connect());
  return new reco::convertor::ConvertorService::Stub(rpc_group);
}

void UpdateRecoItem(const std::vector<reco::RecoItem>& items) {
  net::rpc::RpcClientChannel channel(FLAGS_dst_ips.c_str(), FLAGS_port);
  CHECK(channel.Connect());
  reco::docserver::RecoDocService::Stub stub(&channel);

  reco::docserver::UpdateDBRecoItemRequest request;
  reco::docserver::UpdateDBRecoItemResponse response;
  for (auto iter = items.begin(); iter != items.end(); ++iter) {
    *request.add_item() = *iter;
  }

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(FLAGS_deadline);
  stub.UpdateDBRecoItem(&rpc, &request, &response, NULL);
  rpc.Wait();

  if (rpc.status() != net::rpc::RpcClientController::kOk) {
    LOG(ERROR) << "UpdateDBRecoItem failed, rpc status: " << rpc.status();
  } else {
    for (int i = 0; i < response.success_size(); ++i) {
      if ( response.success(i)) {
        succeed_ids << items[i].identity().item_id() << "\n";
        ++update_cnt;
      }
    }
  }
}

void UpdateItemThread() {
  static const size_t batch_count = 200;
  std::vector<reco::RecoItem> items;
  while (true) {
    reco::RecoItem item;
    if (!item_queue.Take(&item)) break;

    items.push_back(item);
    if (items.size() < batch_count) {
      continue;
    }

    UpdateRecoItem(items);
    items.clear();
  }
  UpdateRecoItem(items);
}

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "doc client ");
  reco::hbase::HBasePoolIns::instance().Init();
  reco::hbase::HBaseAutoCli cli = reco::hbase::HBaseAutoCli(10);
  cli.Get();


  auto item_file = base::FilePath(FLAGS_id_file);
  std::vector<std::string> id_lines;
  if (!base::file_util::ReadFileToLines(item_file, &id_lines)) {
    LOG(WARNING) << "failed to read: " << item_file.ToString();
    return 0;
  }
  for (size_t i = 0; i < id_lines.size(); ++i) {
    id_queue.Put(id_lines[i]);
  }
  id_queue.Close();

  static const int get_pool_size = 10;
  thread::ThreadPool get_pool(get_pool_size);
  for (int i = 0; i < get_pool_size; ++i) {
    get_pool.AddTask(::NewCallback(GetRecoItems));
  }

  rpc_stub = CreateConvertorStub();
  static const int convert_pool_size = 10;
  thread::ThreadPool convert_pool(convert_pool_size);
  for (int i = 0; i < convert_pool_size; ++i) {
    convert_pool.AddTask(::NewCallback(ConvertThread));
  }

  static const int update_pool_size = 10;
  thread::ThreadPool update_pool(update_pool_size);
  for (int i = 0; i < update_pool_size; ++i) {
    update_pool.AddTask(::NewCallback(UpdateItemThread));
  }

  get_pool.JoinAll();
  cdoc_string_queue.Close();
  convert_pool.JoinAll();
  item_queue.Close();
  update_pool.JoinAll();
  succeed_ids.close();

  LOG(ERROR) << "update succeed: " << update_cnt;

  return 0;
}
