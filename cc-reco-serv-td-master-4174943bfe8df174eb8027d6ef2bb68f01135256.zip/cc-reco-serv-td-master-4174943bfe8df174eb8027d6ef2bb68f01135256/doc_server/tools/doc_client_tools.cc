#include <iostream>
#include <fstream>
#include <cstdlib>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/reco_doc_server.pb.h"
#include "reco/bizc/proto/item.pb.h"

using std::endl;

DEFINE_string(request_type, "", "type: slap_test|mq_start_time|compare");

// slap_test
DEFINE_string(doc_server_ip, "127.0.0.1", "doc server ip");
DEFINE_int32(doc_server_port, 20013, "doc server port");
DEFINE_int32(thread_num, 1, "slap_test thread num");
DEFINE_string(reco_id_dict, "item_id.dict", "item id dict");
DEFINE_string(slap_quit_signal_file, "slap_quit.signal", "slap quit signal file");

// mq set start timestamp
DEFINE_string(message_queue_socket, "10.3.5.73:1999", "raw item message queue ip:port");
DEFINE_string(reco_item_queue_name, "reco::zhengying::reco_item", "reco item message queue name");
DEFINE_string(mq_reader_name, "reco_doc_server", "mq reader name");
DEFINE_string(reader_dir_name, "./data/doc_server_reader", "reader dir");
DEFINE_int32(mq_timestamp, 0, "mq set start stamp");

// compare
DEFINE_string(ip1, "127.0.0.1", "doc server ip");
DEFINE_int32(port1, 20013, "doc server port");
DEFINE_string(ip2, "127.0.0.1", "doc server ip");
DEFINE_int32(port2, 20013, "doc server port");
DEFINE_string(item_id_file, "", "item id list");


std::vector<std::string> g_file_lines;
bool g_slap_quit = false;

void SetMqStartTime() {
  message_queue::MessageQueueOptions options(FLAGS_message_queue_socket);
  options.data_dir_ = FLAGS_reader_dir_name;
  message_queue::MessageClientInterface *mq_client = NULL;
  mq_client = message_queue::NewClient(options);
  CHECK_NOTNULL(mq_client);

  // get cur stamp
  message_queue::Fetcher *fetcher = mq_client->GetFetcher(FLAGS_reco_item_queue_name,
                                                          FLAGS_mq_reader_name,
                                                          message_queue::kExclusiveFetch);
  CHECK_NOTNULL(fetcher);

  std::string serialized_item;
  std::string ack_id;
  if (fetcher->PopNeedACK(100, &serialized_item, &ack_id) == message_queue::kPopSuccess) {
    LOG(INFO) << "pop msg ok";
  } else {
    LOG(INFO) << "pop msg failure.";
  }
  LOG(INFO) << "pop msg ack id is: " << ack_id;

  int t = 0;
  if (fetcher->GetCurrentTimet(&t)) {
    LOG(INFO) << "cur time is: " << t;
  } else {
    LOG(WARNING) << "GetCurrentTimet error.";
  }

  if (FLAGS_mq_timestamp == 0) {
    LOG(WARNING) << "set mq time stamp is 0?";
    return;
  }

  // set
  mq_client->SetStartTimet(FLAGS_reco_item_queue_name, FLAGS_mq_reader_name, FLAGS_mq_timestamp);

  if (fetcher->PopNeedACK(100, &serialized_item, &ack_id) == message_queue::kPopSuccess) {
    LOG(INFO) << "pop msg ok";
  } else {
    LOG(INFO) << "pop msg failure.";
  }
  LOG(INFO) << "pop msg ack id is: " << ack_id;

  // check
  if (fetcher->GetCurrentTimet(&t)) {
    LOG(INFO) << "cur time is: " << t;
  } else {
    LOG(WARNING) << "GetCurrentTimet error.";
  }

  return;
}


void GetItemInfo() {
  LOG(INFO) << "begin GetItemInfo()";
  net::rpc::RpcClientChannel channel(FLAGS_doc_server_ip.c_str(), FLAGS_doc_server_port);
  CHECK(channel.Connect(1000));
  reco::docserver::RecoDocService::Stub stub(&channel);
  reco::docserver::ItemDocRequest request;
  reco::docserver::ItemDocResponse response;

  uint64 id =0;
  uint32 seedp = 0;
  srand(base::Time::Now().ToTimeT());

  while (!g_slap_quit) {
    request.Clear();
    response.Clear();

    seedp++;
    const int line_num = rand_r(&seedp) % g_file_lines.size();
    base::StringToUint64(g_file_lines[line_num], &id);
    request.add_item_id(id);

    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(200);
    stub.GetItemDocInfo(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk) {
      LOG(INFO) << "rpc resp failure.";
      continue;
    }

    if (!response.success()) {
      LOG(WARNING) << "get item failure. id is: " << id;
    } else {
      LOG(INFO) << "get item ok, id is: " << id;
      // std::cout << "raw_item, request: " << request.Utf8DebugString()
      //           << "\n response: " << response.Utf8DebugString() << std::endl;
    }
  }
}


void SlapTest() {
  LOG(INFO) << "begin SlapTest";
  if (!base::file_util::ReadFileToLines(FLAGS_reco_id_dict, &g_file_lines)) {
    LOG(WARNING) << "load reco id file error!";
    return;
  }

  thread::Thread *work_thread = new thread::Thread[FLAGS_thread_num];
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    work_thread[i].Start(NewCallback(GetItemInfo));
    base::SleepForMilliseconds(100);
  }

  while (!base::file_util::PathExists(FLAGS_slap_quit_signal_file)) {
    base::SleepForSeconds(1);
  }

  g_slap_quit = true;
  base::SleepForSeconds(1);
  base::file_util::Delete(FLAGS_slap_quit_signal_file, false);

  for (int i = 0; i < FLAGS_thread_num; ++i) {
    work_thread[i].Join();
  }

  delete[] work_thread;
  work_thread = NULL;
  return;
}


void Compare() {
  net::rpc::RpcClientChannel channel_1(FLAGS_ip1.c_str(), FLAGS_port1);
  CHECK(channel_1.Connect(1000));
  reco::docserver::RecoDocService::Stub stub_1(&channel_1);
  reco::docserver::RecoItemRequest request_1;
  reco::docserver::RecoItemResponse response_1;

  net::rpc::RpcClientChannel channel_2(FLAGS_ip2.c_str(), FLAGS_port2);
  CHECK(channel_2.Connect(1000));
  reco::docserver::RecoDocService::Stub stub_2(&channel_2);
  reco::docserver::RecoItemRequest request_2;
  reco::docserver::RecoItemResponse response_2;

  std::ofstream file_1 ("ip1.result");
  std::ofstream file_2 ("ip2.result");

  std::vector<std::string> file_lines;
  if (!base::file_util::ReadFileToLines(FLAGS_item_id_file, &file_lines)) {
    LOG(ERROR) << "load item id dict error: " << FLAGS_item_id_file;
    return;
  }

  for (size_t i = 0; i < file_lines.size(); i++) {
    uint find_cnt = 0;
    request_1.Clear();
    response_1.Clear();
    request_2.Clear();
    response_2.Clear();

    uint64 id = 0;
    base::StringToUint64(file_lines[i], &id);
    request_1.add_item_id(id);
    request_2.add_item_id(id);

    net::rpc::RpcClientController rpc_1;
    rpc_1.SetDeadline(200);

    stub_1.GetRecoItemInfo(&rpc_1, &request_1, &response_1, NULL);
    rpc_1.Wait();
    if (rpc_1.status() != net::rpc::RpcClientController::kOk
        || !response_1.success()) {
      LOG(INFO) << "get ip1 reco item failure, id is: " << id;
    } else {
      LOG(INFO) << "get ip1 reco item succ, id is: " << id;
      find_cnt++;
    }

    net::rpc::RpcClientController rpc_2;
    rpc_2.SetDeadline(200);
    stub_2.GetRecoItemInfo(&rpc_2, &request_2, &response_2, NULL);
    rpc_2.Wait();
    if (rpc_2.status() != net::rpc::RpcClientController::kOk
        || !response_2.success()) {
      LOG(INFO) << "get ip2 reco item failure, id is: " << id;
    } else {
      LOG(INFO) << "get ip2 reco item succ, id is: " << id;
      find_cnt++;
    }

    if (response_1.success() && response_2.success()) {
      std::string value_1;
      response_1.SerializeToString(&value_1);
      std::string value_2;
      response_2.SerializeToString(&value_2);
      if (value_1 == value_2) {
        LOG(INFO) << "suc, equal: id: " << id;
        continue;
      }
    }

    if (find_cnt == 0) {
        LOG(INFO) << "suc, but not exist. equal: id: " << id;
    } else {
      LOG(INFO) << "don't equal: id: " << id;
      file_1 << "don't equal: id: " << id << endl;;
      file_1 << "ip 1, result is: " << response_1.Utf8DebugString() << endl << endl;
      file_2 << "don't equal: id: " << id << endl;;
      file_2 << "ip 2, result is: " << response_2.Utf8DebugString() << endl << endl;
    }
  }

  file_1.close();
  file_2.close();
}


int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "doc client set mq start time and slap_test!");

  if (FLAGS_request_type == "mq_start_time") {
    SetMqStartTime();
  } else if (FLAGS_request_type == "slap_test") {
    SlapTest();
  } else if (FLAGS_request_type == "compare") {
    Compare();
  } else {
    LOG(INFO) << "request_type invalid, type is: " << FLAGS_request_type;
  }

  return 0;
}

