#include "net/rpc/rpc.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "net/rpc_util/rpc_group.h"
#include "base/strings/string_split.h"
#include "reco/bizc/proto/reco_doc_server.pb.h"
#include "base/strings/string_number_conversions.h"


DEFINE_string(id_file, "ids.txt", "item id list file");
DEFINE_string(src_ips, "11.251.203.139,11.251.203.165,11.251.203.195", "sync data from:");
DEFINE_string(dst_ips, "11.180.85.44", "sync data to:");
DEFINE_int32(port, 20013, "search server port");
DEFINE_int32(deadline, 10, "dead line");

reco::docserver::RecoDocService::Stub* CreateStub(std::string strips) {
  std::vector<std::string> ips;
  base::SplitString(strips, ",", &ips);
  int retry_times = 2;
  int timeout = 60;

  net::rpc::RpcGroup::Options options;
  options.max_retry_times = retry_times;
  options.timeout = timeout;

  for (size_t i = 0; i < ips.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(ips[i], FLAGS_port, timeout);
    options.servers.push_back(si);
  }

  auto group = new net::rpc::RpcGroup(options);
  CHECK(group->Connect());
  return new reco::docserver::RecoDocService::Stub(group);
}

bool GetRecoItem(uint64 item_id, reco::docserver::RecoDocService::Stub* stub, reco::RecoItem* item) {
    reco::docserver::RecoItemRequest request;
    reco::docserver::RecoItemResponse response;
    net::rpc::RpcClientController rpc_ctrl;
    request.set_clear_raw_item(false);
    request.add_item_id(item_id);

    stub->GetRecoItemInfo(&rpc_ctrl, &request, &response, NULL);
    rpc_ctrl.Wait();

    if (rpc_ctrl.status() != net::rpc::RpcClientController::kOk
        || !response.success()
        || 0 == response.item_size()) {
      LOG(ERROR) << "request doc info failed. ";
      return false;
    }
    *item = response.item(0);
    return true;
}

void WriteRecoItem(reco::docserver::RecoDocService::Stub* stub_, const reco::RecoItem& item) {
    net::rpc::RpcClientChannel channel(FLAGS_dst_ips.c_str(), FLAGS_port);
    CHECK(channel.Connect());
    reco::docserver::RecoDocService::Stub stub(&channel);

    reco::docserver::UpdateDBRecoItemRequest request;
    reco::docserver::UpdateDBRecoItemResponse response;
    *request.add_item() = item;
    CHECK(channel.Connect());

    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(FLAGS_deadline);
    stub.UpdateDBRecoItem(&rpc, &request, &response, NULL);
    rpc.Wait();

    if (rpc.status() != net::rpc::RpcClientController::kOk) {
      LOG(ERROR) << "UpdateDBRecoItem failed, rpc status: " << rpc.status();
    } else {
      LOG(ERROR) << item.identity().item_id() << "\tsucced";
    }
    /*
    reco::docserver::UpdateDBRecoItemRequest request;
    reco::docserver::UpdateDBRecoItemResponse response;

    net::rpc::RpcClientController rpc_ctrl;
    *request.add_item() = item;
    stub->UpdateDBRecoItem(&rpc_ctrl, &request, &response, NULL);
    rpc_ctrl.Wait();

    if (rpc_ctrl.status() != net::rpc::RpcClientController::kOk) {
      LOG(ERROR) << "UpdateDBRecoItem failed: " << item.identity().item_id()
                 << ", controller status code:" << rpc_ctrl.status();
    } else {
      LOG(INFO) << "add item: " << item.identity().item_id() << "\tsucced!";
    }
    */
}


int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "doc client ");

  auto item_file = base::FilePath(FLAGS_id_file);
  std::vector<std::string> id_lines;
  if (!base::file_util::ReadFileToLines(item_file, &id_lines)) {
    LOG(WARNING) << "failed to read: " << item_file.ToString();
    return 0;
  }

  reco::docserver::RecoDocService::Stub* src_stub = CreateStub(FLAGS_src_ips);
  reco::docserver::RecoDocService::Stub* dst_stub = CreateStub(FLAGS_dst_ips);

  for (size_t i = 0; i < id_lines.size(); ++i) {
    uint64 item_id = 0;
    if (!base::StringToUint64(id_lines[i], &item_id)) {
      LOG(ERROR) << "item id convertion error: " << item_id;
      continue;
    }
    reco::RecoItem item;
    if (GetRecoItem(item_id, src_stub, &item)) {
      WriteRecoItem(dst_stub, item);
    }
  }
  return 0;
}
