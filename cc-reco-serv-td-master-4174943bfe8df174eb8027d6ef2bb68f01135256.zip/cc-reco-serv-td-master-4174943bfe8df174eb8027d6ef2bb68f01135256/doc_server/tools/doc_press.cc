#include <iostream>
#include <fstream>

#include "net/rpc/rpc.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/time/timestamp.h"
#include "base/file/file_util.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_split.h"
#include "base/thread/blocking_queue.h"
#include "base/strings/string_printf.h"
#include "serving_base/utility/time_helper.h"
#include "base/strings/string_number_conversions.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/reco_doc_server.pb.h"

DEFINE_string(doc_server_ip, "127.0.0.1", "doc server ip");
DEFINE_int32(doc_server_port, 20013, "doc server port");
DEFINE_string(request_type, "reco", "reco or orig_reco");
DEFINE_uint64(item_id, 0, "");
DEFINE_string(item_id_file, "", "the item id file");
DEFINE_int32(thread_num, 20, "doc press thread num");
DEFINE_int32(qps, 100, "doc press qps");


namespace reco {
namespace docserver {
class DocClient {
 public:
  bool GetRecoItem(RecoDocService::Stub* stub,
                   uint64 item_id,
                   reco::RecoItem* reco_item = NULL,
                   bool is_print_response = false) {
    reco::docserver::ItemDocRequest request;
    reco::docserver::ItemDocResponse response;
    request.add_item_id(item_id);
    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(5);
    stub->GetItemDocInfo(&rpc, &request, &response, NULL);
    rpc.Wait();

    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "rpc: [GetItemDocInfo] failed. ";
      return false;
    }

    if (reco_item != NULL) {
      reco_item->CopyFrom(response.reco_item(0));
    }

    /*
    std::string value1, value2;
    response.reco_item(0).SerializeToString(&value1);
    response.item(0).SerializeToString(&value2);
    LOG(ERROR) << "size: " << value1.size() << " " << value2.size();
    */

    if (is_print_response) {
      LOG(ERROR) << "[GetItemDocInfo] request: " << request.Utf8DebugString()
                 << "\n response: " << response.Utf8DebugString();
    }
    return true;
  }

  bool GetOrigRecoItem(RecoDocService::Stub* stub,
                   uint64 item_id,
                   reco::RecoItem* reco_item = NULL,
                   bool is_print_response = false) {
    reco::docserver::RecoItemRequest request;
    reco::docserver::RecoItemResponse response;
    request.add_item_id(item_id);
    request.set_clear_raw_item(false);
    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(5);
    stub->GetRecoItemInfo(&rpc, &request, &response, NULL);
    rpc.Wait();

    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "rpc: [GetItemDocInfo] failed. ";
      return false;
    }

    if (reco_item != NULL) {
      reco_item->CopyFrom(response.item(0));
    }

    if (is_print_response) {
      LOG(ERROR) << "[GetRecoItemInfo] request: " << request.Utf8DebugString()
                 << "\n response: " << response.Utf8DebugString();
    }
    return true;
  }

  void TestByItemID(uint64 item_id) {
    auto stub = GetDocStub(FLAGS_doc_server_ip, FLAGS_doc_server_port);
    if ("reco" == FLAGS_request_type) {
      GetRecoItem(stub.second, item_id, NULL, true);
    } else if ("orig_reco" == FLAGS_request_type) {
      GetOrigRecoItem(stub.second, item_id, NULL, true);
    }
    delete stub.first;
    delete stub.second;
  }

  struct PressRet {
    bool is_ok;
    int64 cost_us;
  };

  void TestByItemIDList(const std::vector<uint64>* item_ids,
                        int qps,
                        thread::BlockingQueue<PressRet>* ret_queue) {
    int64 start_us = base::GetTimestamp();
    int delta_us = 1e6 / qps;
    auto stub = GetDocStub(FLAGS_doc_server_ip, FLAGS_doc_server_port);
    for (auto iter = item_ids->begin(); iter != item_ids->end(); ++iter) {
      int64 every_start_us = base::GetTimestamp();
      bool is_ok  = false;
      if ("reco" == FLAGS_request_type) {
        is_ok = GetRecoItem(stub.second, *iter);
      } else if ("orig_reco" == FLAGS_request_type) {
        is_ok = GetOrigRecoItem(stub.second, *iter);
      }
      PressRet press_ret = { is_ok, base::GetTimestamp() - every_start_us };
      ret_queue->Put(press_ret);

      int left_us = delta_us * (iter - item_ids->begin()) - (base::GetTimestamp()- start_us);
      if (left_us > 1000) {
        base::SleepForMilliseconds(left_us/1000);
      }
    }
    delete stub.first;
    delete stub.second;
  }

  void Press(int thread_num, int qps, const std::vector<uint64>& item_ids) {
    thread::BlockingQueue<PressRet> ret_queue;
    thread::ThreadPool pool(FLAGS_thread_num);
    for (int i = 0; i < FLAGS_thread_num; ++i) {
      pool.AddTask(::NewCallback(this, &DocClient::TestByItemIDList, &item_ids, qps, &ret_queue));
    }
    thread::Thread ret_process_thread;
    ret_process_thread.Start(NewCallback(this, &DocClient::PressRetProcess, &ret_queue, thread_num*qps));
    pool.JoinAll();
    ret_queue.Close();
    ret_process_thread.Join();
  }

  void PressRetProcess(thread::BlockingQueue<PressRet>* ret_queue, int qps) {
    PressRet press_ret;
    int index = 0;
    int64 count = 0, fail_count = 0, cost_us = 0;
    int64 total_count = 0, total_fail_count = 0, total_cost_us = 0;
    int64 start_us = base::GetTimestamp();
    int64 every_start_us = start_us;
    while (ret_queue->Take(&press_ret)) {
      ++count;
      ++total_count;
      if (!press_ret.is_ok) {
        ++fail_count;
        ++total_fail_count;
      }
      cost_us += press_ret.cost_us;
      total_cost_us += press_ret.cost_us;
      if (count >= qps) {
        LOG(ERROR) << "[" << index++ << "]\t"
                   << "count: " << count
                   << ", fail count: " << fail_count
                   << ", qps: " << int(count*1e6/(base::GetTimestamp()-every_start_us))
                   << ", avg response: " << cost_us/count;
        count = 0;
        fail_count = 0;
        cost_us = 0;
        every_start_us = base::GetTimestamp();
      }
    }
    LOG(ERROR) << "total count: " << total_count
               << ", fail count: " << total_fail_count
               << ", qps: " << int(total_count*1e6/(base::GetTimestamp()-start_us))
               << ", avg response: " << total_cost_us/total_count;
  }

 private:
  std::pair<net::rpc::RpcClientChannel*,RecoDocService::Stub*> GetDocStub(std::string ip, int port) {
      auto channel = new net::rpc::RpcClientChannel(ip, port);
      CHECK(channel->Connect());
      return std::make_pair(channel, new RecoDocService::Stub(channel));
    }
};
}
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "sim item client");
  reco::docserver::DocClient doc_client;
  if (FLAGS_item_id != 0) {
    doc_client.TestByItemID(FLAGS_item_id);
    return 0;
  } else if (!FLAGS_item_id_file.empty()) {
    std::vector<std::string> lines;
    if (!base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines)) {
      LOG(ERROR) << "read file failed: " << FLAGS_item_id_file;
      return 0;
    }
    std::vector<uint64> item_ids;
    for (auto iter = lines.begin(); iter != lines.end(); ++iter) {
      uint64 item_id = 0;
      if (!base::StringToUint64(*iter, &item_id)) continue;
      item_ids.push_back(item_id);
    }
    if (FLAGS_thread_num <= 0 || FLAGS_qps <= 0) {
      LOG(ERROR) << "thread num or qps wrong";
      return 0;
    }
    doc_client.Press(FLAGS_thread_num, FLAGS_qps, item_ids);
  } else {
    std::string line;
    uint64 item_id;
    while (std::cin >> line) {
      if (!base::StringToUint64(line, &item_id)) {
        LOG(ERROR) << "StringToUint64 fail, line: " << line;
        return 0;
      } else {
        doc_client.TestByItemID(item_id);
      }
    }
  }
  return 0;
}
