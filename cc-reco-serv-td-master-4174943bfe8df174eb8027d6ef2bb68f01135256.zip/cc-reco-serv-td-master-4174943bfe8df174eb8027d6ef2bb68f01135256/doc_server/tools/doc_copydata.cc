#include <fstream>
#include <cstdatomic>

#include "reco/bizc/proto/item.pb.h"
#include "base/thread/sync.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/file/file_util.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"
#include "base/thread/blocking_queue.h"
#include "base/strings/string_printf.h"
#include "reco/base/aerospike_c/api/client.h"
#include "storage/oldb/client/db_client.h"
#include "serving_base/mysql_util/db_conn_manager.h"


/*
DEFINE_string(db_schema, "test_reco", "dbname");
DEFINE_string(db_host, "11.251.206.209", "");
DEFINE_string(db_user, "test", "");
DEFINE_string(db_passwd, "chuheridangwu", "");
*/

DEFINE_string(db_schema, "reco", "dbname");
DEFINE_string(db_host, "tcp://11.251.204.223:3307", "");
DEFINE_string(db_user, "recodev", "");
DEFINE_string(db_passwd, "tkDn19DHeVZkNA", "");

DEFINE_string(oldb_sockets, "11.251.180.201:2800;11.251.180.208:2800;11.251.180.212:2800", "");
//DEFINE_string(oldb_field, "doc_server_test", "");
DEFINE_string(oldb_field, "doc_server_online", "");

DEFINE_string(doc_aero_ns, "test", "test");
DEFINE_string(doc_aero_set, "doc_server", "");
DEFINE_string(test_id, "", "");

DEFINE_string(aero_sockets, "11.251.177.90:3000,11.251.177.91:3000,11.251.177.92:3000,11.251.177.93:3000,11.251.177.94:3000", "");
DEFINE_int32(batch_count, 500000, "");
DEFINE_int32(thread_num, 100, "");
DEFINE_int32(limit_cnt, 0, "");
DEFINE_int32(limit_qps, 2000, "");


static const char* kOldbColumn = "data";


class CopyData {
 public:
  CopyData()
    : oldb_client_(NULL),
    aero_client_(new reco::aero::Client(FLAGS_aero_sockets)),
    read_cnt_(1),
    write_err_cnt_(0),
    check_cnt_(0),
    check_err_cnt_(0),
    ofs_id_("id"),
    ofs_write_err_id_("write_err_id"),
    ofs_check_err_id_("check_err_id"),
    stop_read_(false),
    stop_check_(false),
    beg_time_(base::Time::Now()),
    data_size_(0)
{
  oldb2::DBOptions options(FLAGS_oldb_sockets);
  options.data_dir = "/dev/shm/doc_server_oldb";
  oldb_client_ = new oldb2::DBClient(options);
}

~CopyData() {
  if (oldb_client_ != NULL) {
    delete oldb_client_;
  }
  if (aero_client_ != NULL) {
    delete aero_client_;
  }
  ofs_id_.close();
  ofs_write_err_id_.close();
  ofs_check_err_id_.close();
}

void GetIDsByDate() {
  serving_base::mysql_util::DbConnManager::Option option;
  option.host = FLAGS_db_host;
  option.schema = FLAGS_db_schema;
  option.user = FLAGS_db_user;
  option.passwd = FLAGS_db_passwd;
  serving_base::mysql_util::DbConnManager* db_manager = new serving_base::mysql_util::DbConnManager(option);
  CHECK(db_manager->CheckConnection());

  base::Time beg_time = base::Time::Now() + base::TimeDelta::FromDays(1);
  base::Time::Exploded beg_exp;
  beg_time.LocalExplode(&beg_exp);

  int id_count = 0;
  int i = 0;
  while (true) {
    base::Time::Exploded end_exp = beg_exp;
    beg_time = base::Time::Now() - base::TimeDelta::FromDays(i);
    beg_time.LocalExplode(&beg_exp);
    if (beg_exp.year == 2015 && beg_exp.month < 8) break;

    std::string sql_str = base::StringPrintf("select item_id from tb_item_info "
                                             "where is_valid=true and create_time>='%d-%02d-%02d' "
                                             "and create_time<'%d-%02d-%02d'",
                                             beg_exp.year, beg_exp.month, beg_exp.day_of_month,
                                             end_exp.year, end_exp.month, end_exp.day_of_month);

    sql::ResultSet* dataset = db_manager->ExecuteQuery(sql_str);

    int id_count_day = 0;
    while (dataset->next()) {
      std::string item_id = dataset->getString("item_id");
      id_queue_.Put(item_id);
      ++id_count_day;
    }

    id_count += id_count_day;
    LOG(ERROR) << "day : " << -i << " : " << id_count_day << " / " << id_count;
    ++i;

    if (FLAGS_limit_cnt != 0 && id_count > FLAGS_limit_cnt) break;
  }
}

bool ReadOldb(std::string key, std::string* value) {
  oldb2::GetOptions opt(FLAGS_oldb_field, false);
  opt.set_retry(3);
  opt.set_retry_interval(50);
  opt.AddColumn(kOldbColumn);
  oldb2::Values values;
  oldb2::Status status = oldb_client_->Get(10000, opt, key, &values);
  if (status.ok()) {
    oldb2::Value *v = NULL;
    if (values.GetString(kOldbColumn, &v)) {
      *value = v->value().as_string();
      return true;
    } else {
      //LOG(ERROR) << "no such value, key: " << item_id;
    }
  } else {
    LOG(ERROR) << "Get fail, status:" << status.ToString();
  }
  return false;
}

void ReadOldbThread() {
  while (true) {
    std::string item_id;
    if (!id_queue_.Take(&item_id)) break;

    std::string value;
    if (ReadOldb(item_id, &value)) {
      data_size_ += value.size();
      SaveIDToFile(item_id);
      if (!WriteAero(item_id, value)) {
        LOG(ERROR) << "aero set data failed! id: " << item_id << " : " << value.size();
        SaveWriteErrorID(item_id);
      } else {
        // 去后缀为 0 的记录检查
        if ('0' == item_id[item_id.size()-1]) {
          check_id_queue_.Put(item_id);
        }
      }
      // 限速
      auto cost_time = (base::Time::Now()-beg_time_).InSeconds();
      int t = read_cnt_/FLAGS_limit_qps;
      if (cost_time < t) {
      //if (read_cnt_/cost_time > FLAGS_limit_qps) {
        base::SleepForMilliseconds((t-cost_time)*1000/FLAGS_thread_num);
      }
    } else {
      ++lost_cnt_;
    }
  }
}

bool WriteAero(std::string key, std::string value) {
  int retry_count = 0;
  while (retry_count < 3) {
    if (aero_client_->SetData(key, "data", value,
                              FLAGS_doc_aero_ns, FLAGS_doc_aero_set)) {
      break;
    }
    ++retry_count;
  }
  return retry_count != 3;
}

void SaveIDToFile(std::string id) {
  thread::AutoLock lock(&mutex_);
  ofs_id_ << ":" << id << "\n";
  ++read_cnt_;
}

void SaveWriteErrorID(std::string id) {
  thread::AutoLock lock(&mutex_);
  ofs_write_err_id_ << id << "\n";
  ++write_err_cnt_;
}

void SaveCheckErrorID(std::string id) {
  thread::AutoLock lock(&mutex_);
  ofs_check_err_id_ << id << "\n";
  ++check_err_cnt_;
}

void CheckAeroThread() {
  while (true) {
    std::string item_id;
    if (!check_id_queue_.Take(&item_id)) break;

    ++check_cnt_;
    std::string oldb_value;
    if (!ReadOldb(item_id, &oldb_value)) {
      LOG(ERROR) << "check read oldb err: " << item_id;
      SaveCheckErrorID(item_id);
      ++check_err_cnt_;
      continue;
    }

    std::vector<std::string> bins;
    bins.push_back("data");
    std::vector<std::string> aero_values;
    int read_try_cnt = 0;
    while (read_try_cnt < 3) {
      if (aero_client_->GetData(item_id, bins,
                                &aero_values, FLAGS_doc_aero_ns,FLAGS_doc_aero_set)
          && !aero_values.empty() && !aero_values[0].empty()) {
        break;
      }
    }
    if (3 == read_try_cnt) {
      LOG(ERROR) << "miss: " << item_id;
      SaveCheckErrorID(item_id);
      continue;
    }

    if (oldb_value != aero_values[0]) {
      LOG(ERROR) << "check err: " << item_id  << "size: " << oldb_value.size() << " : " << aero_values[0].size();
      SaveCheckErrorID(item_id);
    }
  }
}

bool ReadAero(std::string item_id, std::string* value) {
    std::vector<std::string> bins;
    bins.push_back("data");
    std::vector<std::string> aero_values;
    if (!aero_client_->GetData(item_id, bins,
                               &aero_values, FLAGS_doc_aero_ns,FLAGS_doc_aero_set)
        || aero_values.empty() || aero_values[0].empty()) {
      return false;
    }
    *value = aero_values[0];
    return true;
}

void PrintThread() {
  while (!stop_read_) {
    auto cost_time = (base::Time::Now()-beg_time_).InSeconds();
    LOG(ERROR) << read_cnt_ << " : " << lost_cnt_ << " : " << write_err_cnt_ << " : "
               << read_cnt_/cost_time << " : " << data_size_/read_cnt_;
    base::SleepForSeconds(5);
  }

  while (!stop_check_) {
    LOG(ERROR) << check_cnt_ << " : " << check_err_cnt_;
    base::SleepForSeconds(5);
  }
}

void Run() {
  static const int read_pool_size = FLAGS_thread_num;
  thread::ThreadPool read_pool(read_pool_size);
  for (int i = 0; i < read_pool_size; ++i) {
    read_pool.AddTask(::NewCallback(this, &CopyData::ReadOldbThread));
  }

  thread::Thread print_thread;
  print_thread.Start(::NewCallback(this, &CopyData::PrintThread));

  GetIDsByDate();
  id_queue_.Close();

  read_pool.JoinAll();
  LOG(ERROR) << "get value: " << read_cnt_-write_err_cnt_;

  RunCheck();
}

void RunCheck() {
  stop_read_ = true;
  check_id_queue_.Close();

  static const int check_pool_size = FLAGS_thread_num;
  thread::ThreadPool check_pool(check_pool_size);
  for (int i = 0; i < check_pool_size; ++i) {
    check_pool.AddTask(::NewCallback(this, &CopyData::CheckAeroThread));
  }
  check_pool.JoinAll();
  stop_check_= true;
  LOG(ERROR) << "check_err_cnt: " << check_err_cnt_;
}


private:
thread::Mutex mutex_;
thread::BlockingQueue<std::string> id_queue_;
thread::BlockingQueue<std::string> check_id_queue_;
oldb2::DBClient* oldb_client_;
reco::aero::Client* aero_client_;

atomic_int read_cnt_;
atomic_int lost_cnt_;
atomic_int write_err_cnt_;
atomic_int check_cnt_;
atomic_int check_err_cnt_;

std::ofstream ofs_id_;
std::ofstream ofs_write_err_id_;
std::ofstream ofs_check_err_id_;

bool stop_read_;
bool stop_check_;

base::Time beg_time_;
atomic_long data_size_;
};

void test();

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "doc copy data");
  LOG(ERROR) << "begin";

  //test();return -1;

  CopyData cpdata;
  cpdata.Run();

  LOG(ERROR) << "end";
}

void test() {
  CopyData cpdata;
  std::string item_id = FLAGS_test_id;//"12266810055310123184";
  std::string value;
  if (!cpdata.ReadOldb(item_id, &value)) {
    LOG(ERROR) << "read oldb failed";
    return;
  }
  LOG(ERROR) << "read oldb size: " << value.size();

  if (!cpdata.WriteAero(item_id, value)) {
    LOG(ERROR) << "write aero failed: " << value.size();
    return;
  }

  if (!cpdata.ReadAero(item_id, &value)) {
    LOG(ERROR) << "ReadAero failed";
    return;
  }
  LOG(ERROR) << "read aero size: " << value.size();

  reco::RecoItem item;
  if (!item.ParseFromString(value)) {
    LOG(ERROR) << "parse error";
  }
}
