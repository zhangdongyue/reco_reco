#include "reco/serv/doc_server/handler/data_manager.h"
#include "reco/base/kafka_c/api_cc/producer.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
namespace reco {
namespace doc {
DEFINE_string(item_kafka_brokers, "127.0.0.1", "doc item kafka brkoer");
DEFINE_string(log_kafka_brokers, "127.0.0.1:9092", "elk kafka broker");
DEFINE_string(item_kafka_topic, "test_reco_item", "doc read item kafka_topic");
DEFINE_string(item_kafka_group_id, "doc_server_group_test", "doc server group id for kafka topic");

DEFINE_string(elk_kafka_topic, "test_elk_msg_log", "elk kafka_topic");

DEFINE_string(item_update_topic, "test_item_update_topic", "item update kafka_topic");
DEFINE_int32(item_update_topic_partition, 32, "item update partition number");

DEFINE_string(item_update_group_id, "test_image_update_group_id", "image update group id for kafka topic");
DEFINE_string(item_refresh_group_id, "test_item_refresh_group_id", "item refresh group id for kafka topic");

DECLARE_bool(is_readonly);

DataManager::DataManager(int work_thread_num)
    :doc_storage(NULL),
    system_counter(NULL),
    op_num(0),
    max_response_time(0),
    item_consumer(NULL),
    log_elk_producer(NULL),
    item_update_producer(NULL),
    image_update_consumer(NULL),
    item_refresh_consumer(NULL) {}

DataManager::~DataManager() {
  if (item_consumer != NULL) {
    delete item_consumer;
    item_consumer = NULL;
  }

  if (log_elk_producer != NULL) {
    delete log_elk_producer;
    log_elk_producer = NULL;
  }

  if (item_update_producer != NULL) {
    delete item_update_producer;
    item_update_producer = NULL;
  }

  if (image_update_consumer != NULL) {
    delete image_update_consumer;
    image_update_consumer = NULL;
  }

  if (item_refresh_consumer != NULL) {
    delete item_refresh_consumer;
    item_refresh_consumer = NULL;
  }

  if (doc_storage != NULL) {
    delete doc_storage;
    doc_storage = NULL;
  }

  if (system_counter != NULL) {
    delete system_counter;
    system_counter = NULL;
  }
}

void DataManager::Init() {
  doc_storage = new DocStorage();
  system_counter = new SystemCounter();
  reco::doc::ItemHandler::Initialize();
  if (!FLAGS_is_readonly) {
    InitKafka();
  }
}

void DataManager::Stop() {
  reco::doc::ItemHandler::Destructor();
}

void DataManager::InitKafka() {
  // item consumer
  {
    reco::kafka::ConsumerOptions options;
    options.topic = FLAGS_item_kafka_topic;
    options.type = reco::kafka::kConsumerExclusive;
    options.group_id = FLAGS_item_kafka_group_id;
    item_consumer = new reco::kafka::Consumer(FLAGS_item_kafka_brokers, options);
    CHECK_NOTNULL(item_consumer);
  }

  // elk producer
  log_elk_producer = new reco::kafka::Producer(FLAGS_log_kafka_brokers, FLAGS_elk_kafka_topic);
  CHECK_NOTNULL(log_elk_producer);

  // item update producer
  item_update_producer = new reco::kafka::Producer(FLAGS_log_kafka_brokers, FLAGS_item_update_topic);
  CHECK_NOTNULL(item_update_producer);

  // image update consumer
  {
    reco::kafka::ConsumerOptions options;
    options.topic = FLAGS_item_update_topic;
    options.type = reco::kafka::kConsumerExclusive;
    options.group_id = FLAGS_item_update_group_id;
    image_update_consumer = new reco::kafka::Consumer(FLAGS_log_kafka_brokers, options);
    CHECK_NOTNULL(image_update_consumer);
  }

  // item refresh consumer
  {
    reco::kafka::ConsumerOptions options;
    options.topic = FLAGS_item_update_topic;
    options.type = reco::kafka::kConsumerMirror;
    options.group_id = FLAGS_item_refresh_group_id;
    options.partition_num = FLAGS_item_update_topic_partition;
    options.start_timestamp = base::GetTimestamp() / 1e6 - 15 * 60;  // 往前 10 分钟
    item_refresh_consumer = new reco::kafka::Consumer(FLAGS_log_kafka_brokers, options);
    CHECK_NOTNULL(item_refresh_consumer);
  }
}
}
}
