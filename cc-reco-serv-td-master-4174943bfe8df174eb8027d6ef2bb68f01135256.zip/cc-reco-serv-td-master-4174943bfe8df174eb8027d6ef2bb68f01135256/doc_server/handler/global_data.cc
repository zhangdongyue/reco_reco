#include "reco/serv/doc_server/handler/global_data.h"

#include "reco/serv/doc_server/handler/doc_sync_mgr.h"
#include "reco/serv/doc_server/handler/data_manager.h"

DECLARE_int32(work_thread_num);

namespace reco {
namespace doc {
DEFINE_bool(is_readonly, false, "doc userd for readonly");

void GlobalData::Init() {
  LOG(INFO) << "init";

  work_thread_pool = new thread::ThreadPool(FLAGS_work_thread_num);
  CHECK_NOTNULL(work_thread_pool);
  thread_pool_enable = true;
  LOG(INFO) << "thread pool create.";

  reco::doc::DataMgr::instance().Init();

  if (!reco::doc::FLAGS_is_readonly) {
    doc_sync_mgr.Start();
  }
}

void GlobalData::Stop() {
  LOG(INFO) << "stop";

  if (!reco::doc::FLAGS_is_readonly) {
    doc_sync_mgr.Stop();
  }

  reco::doc::DataMgr::instance().Stop();

  if (work_thread_pool) {
    StopThreads();
  }
}

bool GlobalData::IsThreadPoolEnabled() {
  return (work_thread_pool != NULL) && thread_pool_enable;
}

// 与本结构体的析构过程线程不安全，不能并行
void GlobalData::StopThreads() {
  LOG(INFO) << "stop threads";

  if (work_thread_pool) {
    thread_pool_enable = false;
    work_thread_pool->StopAll();
    delete work_thread_pool;
    work_thread_pool = NULL;
    LOG(INFO) << "stopped";
    ::google::FlushLogFiles(::google::INFO);
  }
}
} // namespace doc
} // namespace reco
