#pragma once

#include <string>
#include <vector>
#include <utility>

#include "base/common/slice.h"
#include "base/common/logging.h"
#include "base/strings/string_util.h"
#include "extend/static_dict/darts_clone/darts_clone.h"
#include "extend/static_dict/dawg/dictionary.h"

namespace reco {
namespace doc {

// ===========================================================
// 将一段 UTF8 编码的文本 (可以是多行或单行), 归一化成单行文本
//
// 归一化操作按如下顺序执行：
//
// 3. \t\r\n 0x00A0 全角空格 替换成空格
// 4. 删除不可见字符, 包括 [0x00, 0x19] 和 0xFF 0xFEFF
// 5. 连续空格只保留一个
// 6. 去除行首和行尾的空格
// ===========================================================
//
// 1. NormalizeLineCopy(): 归一化的结果, 覆写到结果字符串中
// 2. NormalizeLineAppend(): 归一化的结果，Append 到结果字符串中
// 3. NormalizeLineInPlaceS(): 归一化结果原地修改字符串
// 4. NormalizeLineInPlaceC(): 归一化结果原地修改字符数组, 返回归一化后字符串长度.
// 5. NormalizeLine(): 简单封装，便于将处理好的字符串作为参数传递
//
// NOTE: 如果待原地修改的字符串是 string, 请使用 NormalizedLineInPlaceS(), 不要通过 string::c_str()
// 调用 NormalizeLineInPlaceC(), 否则可能踩到 string 的 Copy-On-Write 坑.
// (详情见 base/strings/string_util.h 的 WriteIntoString())
//
// NOTE
// NormalizeLineInPlaceC 的参数使用 null-terminated char* 和 len, len 不包括结尾的 \0
// 返回处理后字符串的长度，该长度小于等于原始长度。如果小于原始长度，末尾会添加 \0
//
void NormalizeLineCopy(const base::Slice& str, std::string* normalized);
void NormalizeLineAppend(const base::Slice& str, std::string* normalized);
void NormalizeLineInPlaceS(std::string* str);
int  NormalizeLineInPlaceC(char* data, int len);
inline std::string NormalizeLine(const base::Slice& str) {
  std::string normalized;
  NormalizeLineCopy(str, &normalized);
  return normalized;
}


// ===========================================================
// 将一段 UTF8 编码的文本（可以是多行或单行），归一化成多行文本
//
// 归一化操作按如下顺序执行：
//
// 1. 对传入字符串按 \n 分割文本
// 2. 对分割后的每段文本，调用 NormalizeLine
// 3. 如果调用结果返回的字符串不为空，将结果添加到输出变量中;
//    如果原始的本段文本是以 \n 结尾，添加 \n 到输出变量中
// ===========================================================
//
// 1. NormalizeMultiLinesCopy(): 归一化的结果, 覆写到结果字符串中
// 2. NormalizeMultiLinesInPlaceS(): 原地替换。
// 3. NormalizeMultiLinesInPlaceC()：原地替换。
// 4: NormalizeMultiLines(): 简单封装，便于将处理好的字符串作为参数传递
//
// NOTE: 如果待原地修改的字符串是 string, 请使用 NormalizeMultiLinesInPlaceS(), 不要通过 string::c_str()
// 调用 NormalizeMultiLinesInPlaceC(), 否则可能踩到 string 的 Copy-On-Write 坑.
// (详情见 base/strings/string_util.h 的 WriteIntoString())
//
// NOTE:
// NormalizeMultiLinesInPlaceC 的参数使用 null-terminated char* 和 len, len 不包括结尾的 \0
// 返回处理后字符串的长度，该长度小于等于原始长度。如果小于原始长度，末尾会添加 \0
//
void NormalizeMultiLinesCopy(const base::Slice& str, std::string* normalized);
void NormalizeMultiLinesInPlaceS(std::string* str);
int  NormalizeMultiLinesInPlaceC(char* data, int len);

inline std::string NormalizeMultiLines(const base::Slice& str) {
  std::string normalized;
  NormalizeMultiLinesCopy(str, &normalized);
  return normalized;
}

// 将文本截断成固定宽度. 如果原始字符串的宽度大于 threshold_width, 则将其截断成宽度为 truncated_width 的文本
// 当前判断宽度的方法很简单: 中文算 2 个宽度, ascii 码算一个
void TruncateByWidth(const std::string& orig_str, int truncated_width,
                     int threshold_width, std::string* out_str);
}  // namespace doc
}  // namespace reco

