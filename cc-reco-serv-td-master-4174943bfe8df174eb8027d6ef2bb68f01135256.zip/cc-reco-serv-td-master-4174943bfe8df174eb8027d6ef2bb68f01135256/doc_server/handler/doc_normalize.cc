#include "reco/serv/doc_server/handler/doc_normalize.h"

#include <set>
#include <vector>
#include <list>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <utility>

#include "nlp/common/term_container.h"
#include "base/common/logging.h"
#include "base/common/basic_types.h"
#include "base/strings/utf_char_iterator.h"
#include "base/strings/string_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/utf_string_conversion_utils.h"
#include "base/strings/internal/icu/icu_utf.h"
#include "extend/multi_strings/multi_pattern_matcher.h"

namespace reco {
namespace doc {
// internal 名字空间的函数不要使用
namespace internal {

inline void ToSpace(int32* code_point) {
  int32& ch = *code_point;
  // 全角空格 替换成空格
  if (ch == '\t' || ch == '\r' || ch == '\n' || ch == 0x00A0 || ch == 160 || ch == 12288) {
    ch = ' ';
  }
}

inline bool is_invisible(const int32& code_point) {
  static const std::unordered_set<int> kRemainCodeSet = {1, 2, 3, 4, 5, 6};
  // TODO(zhengying): utf8 invisible chars
  // ascii 码的前 32 个字符。其中的 \r\n\t 已经被换成空格,
  // \1\2 是图片占位符，\3\4 分别为超链接 / 投票占位符, 不能去掉
  if ((code_point < 32 && kRemainCodeSet.find(code_point) == kRemainCodeSet.end())
      || code_point == 127  // DEL
      || code_point == 0xFEFF)  // NOT a utf8 char
  { // NOLINT
    return true;
  } else {
    return false;
  }
}

}  // namespace internal


void NormalizeLineAppend(const base::Slice& orig_slice, std::string* normalized) {
  DCHECK_NOTNULL(orig_slice.data());
  if (orig_slice.size() == 0) {
    return;
  }

  base::UTF8CharIterator it(orig_slice.data(), orig_slice.size());
  int32 last_ch = 0;
  bool meet_not_empty = false;
  int effective_size = normalized->length();
  while (!it.end()) {
    int32 ch = it.get();
    it.Advance();
    // \r \n \t 替换成空格
    internal::ToSpace(&ch);
    // 删除不可见字符
    if (internal::is_invisible(ch)) {
      continue;
    }
    // 寻找第一个非空白字符
    if (!meet_not_empty && ch != ' ') {
      meet_not_empty = true;
    }
    if (!meet_not_empty) {
      continue;
    }
    // 连续空格只保留一个
    if (ch == ' ' && last_ch == ' ') {
      continue;
    } else {
      last_ch = ch;
      base::WriteUnicodeCharacter(ch, normalized);
      if (ch != ' ') {
        effective_size = normalized->length();
      }
      continue;
    }
  }

  normalized->resize(effective_size);
  return;
}

int NormalizeLineInPlaceC(char* data, int orig_len) {
  DCHECK_NOTNULL(data);
  if (orig_len == 0) {
    return 0;
  }

  base::UTF8CharIterator it(data, orig_len);
  int32 last_ch = 0;
  bool meet_not_empty = false;
  size_t offset = 0;
  int effective_size = 0;
  while (!it.end()) {
    int32 ch = it.get();
    it.Advance();
    // \r \n \t 替换成空格
    internal::ToSpace(&ch);
    // 删除不可见字符
    if (internal::is_invisible(ch)) {
      continue;
    }
    // 寻找第一个非空白字符
    if (!meet_not_empty && ch != ' ') {
      meet_not_empty = true;
    }
    if (!meet_not_empty) {
      continue;
    }
    // 连续空格只保留一个
    if (ch == ' ' && last_ch == ' ') {
      continue;
    } else {
      last_ch = ch;
      CBU8_APPEND_UNSAFE(data, offset, ch);
      CHECK_LE((int)offset, it.array_pos());
      if (ch != ' ') {
        effective_size = offset;
      }
      continue;
    }
  }

  DCHECK_LE(effective_size, orig_len);
  if (effective_size < orig_len) {
    data[effective_size] = '\0';
  }
  return effective_size;
}

void NormalizeLineCopy(const base::Slice& orig_slice, std::string* normalized) {
  normalized->clear();
  // 确保 string::append 的时候没有内存的 relocate
  normalized->reserve(orig_slice.size());
  NormalizeLineAppend(orig_slice, normalized);
}

void NormalizeLineInPlaceS(std::string* in_out_string) {
  DCHECK_NOTNULL(in_out_string->data());
  if (in_out_string->size() == 0) {
    return;
  }
  // 通知 string 对象，要对其改写，强制令其 copy on write
  base::WriteIntoString(in_out_string, in_out_string->size());
  int new_size = NormalizeLineInPlaceC(&(*in_out_string)[0], in_out_string->size());
  in_out_string->resize(new_size);
  return;
}

void NormalizeMultiLinesCopy(const base::Slice& orig_slice, std::string* normalized) {
  DCHECK_NOTNULL(orig_slice.data());
  normalized->clear();
  if (orig_slice.size() == 0) {
    return;
  }

  normalized->reserve(orig_slice.size());
  std::vector<size_t> newline_pos;
  size_t pos = 0;
  while ((pos = orig_slice.find('\n', pos)) != base::Slice::npos) {
    // newline_pos 里保存 \n 位置的下一位
    newline_pos.push_back(++pos);
  }
  // 如果最后一个不是 \n ，将字符串的结尾也放到 newline_pos 中
  if (newline_pos.size() == 0 || newline_pos.back() != orig_slice.size()) {
    newline_pos.push_back(orig_slice.size());
  }

  size_t start = 0;
  for (int i = 0; i < (int)newline_pos.size(); ++i) {
    // 考察区间 [start, end)
    size_t end = newline_pos[i];
    int old_size = normalized->size();

    NormalizeLineAppend(base::Slice(orig_slice.data() + start, end - start),
                            normalized);

    if ((int)normalized->size() > old_size &&  // 本区间经 normalize 处理后有字符串
        orig_slice[end - 1] == '\n') {         // 本区间处理前的最后一个字符（end-1）是 \n
      // 增加 \n 到结果字符串中
      // 之前是有 \n 的, 在 NormalizeLineInPlace 中被过滤。
      normalized->append(1, '\n');
    }
    start = end;
  }
  return;
}

int NormalizeMultiLinesInPlaceC(char* data, int orig_len) {
  DCHECK_NOTNULL(data);
  if (orig_len == 0) {
    return 0;
  }

  std::vector<size_t> newline_pos;
  size_t pos = 0;
  const base::Slice orig_slice(data, orig_len);
  while ((pos = orig_slice.find('\n', pos)) != base::Slice::npos) {
    // newline_pos 里保存 \n 位置的下一位
    newline_pos.push_back(++pos);
  }
  // 如果最后一个不是 \n ，将字符串的结尾也放到 newline_pos 中
  if (newline_pos.size() == 0 || newline_pos.back() != orig_slice.size()) {
    newline_pos.push_back(orig_slice.size());
  }

  size_t start = 0;
  int total_length = 0;
  for (int i = 0; i < (int)newline_pos.size(); ++i) {
    // 考察区间 [start, end)
    size_t end = newline_pos[i];
    bool end_with_newline = data[end - 1] == '\n';

    char* line_start = data + start;
    int   new_size   = NormalizeLineInPlaceC(line_start, end - start);

    // 本区间经 normalize 处理后非空, 且处理前的最后一个字符（end-1）是 \n
    if (new_size > 0 && end_with_newline) {
      // 满足以上条件，增加 \n 到结果字符串中
      // 之前 line 中是有 \n 的, 在 NormalizeLineInPlace 中被过滤。
      // 此处重新加入 \n ， line 所在的 [start, end) 有富余空间容纳
      line_start[new_size++] = '\n';
    }
    if (new_size > 0) {
      memmove(data + total_length, line_start, new_size);
      total_length += new_size;
    }
    start = end;
  }
  DCHECK_LE(total_length, orig_len);
  if (total_length < orig_len) {
    data[total_length] = '\0';
  }
  return total_length;
}

void NormalizeMultiLinesInPlaceS(std::string* in_out_string) {
  DCHECK_NOTNULL(in_out_string->data());
  if (in_out_string->size() == 0) {
    return;
  }
  // 通知 string 对象，要对其改写，强制令其 copy on write
  base::WriteIntoString(in_out_string, in_out_string->size());
  int new_size = NormalizeMultiLinesInPlaceC(&(*in_out_string)[0], in_out_string->size());
  in_out_string->resize(new_size);
  return;
}
}
}  // namespace nlp
