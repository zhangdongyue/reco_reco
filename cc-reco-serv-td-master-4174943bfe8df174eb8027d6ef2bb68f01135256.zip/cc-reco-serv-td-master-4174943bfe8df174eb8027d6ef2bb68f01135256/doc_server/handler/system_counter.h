#pragma once

#include <queue>
#include <vector>
#include <algorithm>

#include "base/thread/sync.h"
#include "base/common/gflags.h"


namespace reco {
namespace doc {
enum SysStatus {
  kSysFree = 1,
  kSysNormal = 2,
  kSysBusy = 3,
  kSysFull = 4,
};


class SystemCounter {
 public:
  explicit SystemCounter(int total_count = 1000);
  void AddTimeUs(int time);
  SysStatus GetDegree();

 private:
  std::vector<int> degrees_;
  const int total_count_limit_;
  int total_response_microsecond_;
  std::queue<int> time_queue_;
  mutable thread::Mutex access_mutex_;
};
}
}
