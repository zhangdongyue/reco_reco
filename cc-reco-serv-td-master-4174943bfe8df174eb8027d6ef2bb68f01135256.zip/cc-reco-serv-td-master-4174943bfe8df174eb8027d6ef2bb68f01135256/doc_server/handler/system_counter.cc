#include "reco/serv/doc_server/handler/system_counter.h"

namespace reco {
namespace doc {
DEFINE_int64_counter(doc, system_status, 0, "system status");
DEFINE_int32(system_counter_first_degree_millisecond, 20, "first degree");


SystemCounter::SystemCounter(int total_count)
    : total_count_limit_(total_count),
    total_response_microsecond_(0) {
      for (int i = 0; i < total_count_limit_; ++i) {
        time_queue_.push(0);
      }

      int first_degree_microsecond =
          FLAGS_system_counter_first_degree_millisecond * 1000 * total_count_limit_;
      degrees_ = { first_degree_microsecond,
        first_degree_microsecond * 2,
        first_degree_microsecond * 4 };
    }

void SystemCounter::AddTimeUs(int time) {
  thread::AutoLock lock_access(&access_mutex_);
  total_response_microsecond_ += time - time_queue_.front();
  time_queue_.push(time);
  time_queue_.pop();
}

SysStatus SystemCounter::GetDegree() {
  thread::AutoLock lock_access(&access_mutex_);
  SysStatus status = (SysStatus)(std::upper_bound(degrees_.begin(), degrees_.end(),
                                                  total_response_microsecond_) - degrees_.begin());
  COUNTERS_doc__system_status.Reset(status);
  return status;
}
}
}
