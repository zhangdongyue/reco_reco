#pragma once

#include <string>
#include <utility>
#include <vector>

#include "reco/bizc/proto/item.pb.h"
#include "base/testing/gtest_prod.h"
#include "base/container/lru_cache.h"
#include "base/random/pseudo_random.h"
#include "reco/base/aerospike_c/api/client.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/base/common/singleton.h"


namespace reco {
namespace doc {
class DocStorage {
 public:
  DocStorage();
  ~DocStorage();

  bool GetRecoItemFromDB(uint64 item_id, RecoItem* reco_item);
  /*
   * return 0 : succeed
   * return 1 : Serialize error
   * return 2 : Write areo error
   */
  int SaveRecoItemToDB(const RecoItem& reco_item);

  bool GetRecoItemFromCache(uint64 item_id, RecoItem* reco_item);

  bool SaveRecoItemToCache(const RecoItem& reco_item);

  void ClearLocalCache(uint64 item_id);

 private:
  bool ClearCacheData(const uint64 item_id);

  bool ReadAero(const std::string& key, std::string* value);

  bool WriteAero(const std::string& key, const std::string& value);

 private:
  static const char* kAeroColumn;
  static const int kAeroRetryCnt = 3;

  std::vector<base::LRUCache<uint64, std::pair<std::string, int64>>*> reco_cache_;
  reco::redis::RedisCli redis_;
  reco::aero::Client aero_client_;

  FRIEND_TEST(DocServerTest, doc_storage);
};
}
}
