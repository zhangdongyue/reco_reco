#include "reco/serv/doc_server/handler/doc_sync_mgr.h"

#include <string>
#include <vector>

#include "base/common/gflags.h"
#include "base/common/closure.h"
#include "base/strings/string_split.h"
#include "extend/json/jansson/jansson.h"
#include "reco/bizc/common/appname_define.h"
#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/base/kafka_c/api_cc/producer.h"
#include "base/strings/string_number_conversions.h"

//#include "reco/bizc/proto/item_keeper.pb.h"
#include "reco/bizc/proto/elk_item_msg.pb.h"
#include "reco/serv/doc_server/handler/item_handler.h"
#include "reco/serv/doc_server/handler/data_manager.h"


namespace reco {
namespace doc {
DEFINE_int32(update_thread_num, 2, "update thread num");
DEFINE_int32(refresh_thread_num, 2, "refresh thread num");
DEFINE_int32(check_pic_min, 120, "check missing pic minutes");
DEFINE_bool(write_feedback, false, "write feedback flag, include item-keeper, refresh cache, missing pic");
DEFINE_int32(kafka_msg_size_limit, 1024 * 1024, "kafka消息大小限制");
/*
DEFINE_string(item_keeper_ips, "127.0.0.1:2222,127.0.0.1:22312", "");
DEFINE_int32(item_keeper_retry_times, 2, "rpc retry times");
DEFINE_int32(item_keeper_timeout, 2000, "ms");
*/

DEFINE_int64_counter(add_doc, parse_error_num, 0, "解析失败的 doc 总数");
DEFINE_int64_counter(add_doc, success_num, 0, "成功入库 doc 总数");
DEFINE_int64_counter(add_doc, discard_doc_num, 0, "由于缺图丢弃的文档数");
DEFINE_int64_counter(add_doc, lack_image_num, 0, "当前取不到图片的 doc 数量");
DEFINE_int64_counter(doc, refresh_cache_num, 0, "");
DEFINE_int64_counter(doc, produce_refresh_num, 0, "");
DEFINE_int64_counter(doc, block_add_item_size, 0, "");


DocSyncMgr::DocSyncMgr()
    : thread_stop_(false),
    update_thread_pool_(FLAGS_update_thread_num),
    refresh_thread_(FLAGS_refresh_thread_num) {
  if (FLAGS_write_feedback) {
    // CHECK(SetupConnItemKeeper());
  }

  item_kafka_offset_ = new serving_base::ExpiryMap<uint64, int64>(30 * 60);
}

DocSyncMgr::~DocSyncMgr() {
  if (item_kafka_offset_) {
    delete item_kafka_offset_;
    item_kafka_offset_ = NULL;
  }
}

void DocSyncMgr::Start() {
  for (int i = 0; i < FLAGS_update_thread_num; ++i) {
    update_thread_pool_.AddTask(NewCallback(this, &DocSyncMgr::LoopAdd));
  }

  for (auto i = 0; i < FLAGS_refresh_thread_num; ++i) {
    refresh_thread_.AddTask(NewCallback(this, &DocSyncMgr::LoopRefresh));
  }

  miss_image_update_thread_.Start(NewCallback(this, &DocSyncMgr::LoopMissImageUpdate));
  sync_to_cache_thread_.Start(NewCallback(this, &DocSyncMgr::LoopSyncToCache));
}

void DocSyncMgr::Stop() {
  thread_stop_ = true;
  update_thread_pool_.JoinAll();
  refresh_thread_.JoinAll();
  miss_image_update_thread_.Join();
  sync_to_cache_thread_.Join();
}

void DocSyncMgr::LoopAdd() {
  auto item_consumer = reco::doc::DataMgr::instance().item_consumer;

  while (!thread_stop_) {
    reco::kafka::Message msg;
    if (!item_consumer->Consume(&msg)) {
      base::SleepForSeconds(1);
      continue;
    }

    if (msg.content.size() > static_cast<size_t>(FLAGS_kafka_msg_size_limit)) {
      LOG(ERROR) << "kafka message size more than limit"
                 << ", item id: " << msg.key
                 << ", stamp: " << msg.timestamp_ms
                 << ", size: " << msg.content.size();
      continue;
    }

    LOG(INFO) << "add, prt:" << msg.partition << ", off:" << msg.offset
              << ", key:" << msg.key << ", stamp:" << msg.timestamp_ms;

    reco::RecoItem reco_item;
    if (!reco_item.ParseFromString(msg.content)) {
      LOG(ERROR) << "failed to parse:" << msg.content;
      COUNTERS_add_doc__parse_error_num.Increase(1);
      continue;
    }

    if (reco_item.has_raw_item()) {
      reco_item.clear_raw_item();
    }

    /*
    if (reco_item.image_size() != reco_item.raw_item().image_size()) {
      LOG(ERROR) << "reco raw image size not equal:" << reco_item.identity().item_id()
                 << ":" << reco_item.image_size() << ":" << reco_item.raw_item().image_size();
    }
    */

    // 这里传过来的图片信息是爬虫抓取原图的，不是图床的，需要强制校验图片信息
    UpdateImageInfo(&reco_item, true);

    AddDocUntilSucc(reco_item, true, msg.offset);

    COUNTERS_add_doc__success_num.Increase(1);

    LOG(INFO) << "add succ:" << reco_item.identity().item_id();
  }
}

void DocSyncMgr::LoopMissImageUpdate() {
  auto consumer = reco::doc::DataMgr::instance().image_update_consumer;

  while (!thread_stop_) {
    reco::kafka::Message kafka_msg;
    if (!consumer->Consume(&kafka_msg)) {
      base::SleepForSeconds(1);
      continue;
    }

    UpdateItemMsg update_msg;
    if (!update_msg.ParseFromString(kafka_msg.content)) {
      LOG(ERROR) << "parse pb fail:" << kafka_msg.content;
      continue;
    }

    // 队列被复用，只处理各自对应 type
    if (update_msg.type() != kMissingPic) continue;

    LOG(INFO) << "miss, prt:" << kafka_msg.partition << ", off:" << kafka_msg.offset
              << ", key:" << kafka_msg.key << ", stamp:" << kafka_msg.timestamp_ms;
    COUNTERS_add_doc__lack_image_num.Increase(1);

    const uint64 item_id = update_msg.item_id();
    LOG(INFO) << "retry to update image:" << item_id;

    if (base::GetTimestamp() - update_msg.create_stamp_us() > (FLAGS_check_pic_min * 60 * 1e6)) {
      LOG(ERROR) << "fail to get image from tuchuang too long:" << item_id;
      COUNTERS_add_doc__discard_doc_num.Increase(1);
      if (FLAGS_write_feedback) {
       // WriteFeedbackToItemKeeper(item_id, false, false);
      }
      continue;
    }

    reco::RecoItem reco_item;
    auto& doc_storage = reco::doc::DataMgr::instance().doc_storage;
    if (!doc_storage->GetRecoItemFromDB(item_id, &reco_item)) {
      LOG(WARNING) << "can't find item db:" << item_id;
    } else if (ItemHandler::UpdateRecoItemImageInfo(&reco_item)) {
      LOG(INFO) << "re update image from tuchuang succ:" << item_id;
      AddDocUntilSucc(reco_item, false, -1);
      if (FLAGS_write_feedback) {
        // 注意，不能再次发给 reco item 队列，只让 item-keeper 更新 cdoc 队列
        // WriteFeedbackToItemKeeper(item_id, false, true);
      }
      continue;
    }

    AddMissImageQueue(update_msg);
  }
}

void DocSyncMgr::LoopRefresh() {
  auto consumer = reco::doc::DataMgr::instance().item_refresh_consumer;

  while (!thread_stop_) {
    reco::kafka::Message kafka_msg;
    if (!consumer->Consume(&kafka_msg)) {
      base::SleepForSeconds(2);
      continue;
    }

    UpdateItemMsg refresh_data;
    if (!refresh_data.ParseFromString(kafka_msg.content)) {
      LOG(ERROR) << "parse pb fail:" << kafka_msg.content;
      continue;
    }

    // 队列被复用，只处理各自对应 type
    if (refresh_data.type() != kRefreshCache) continue;

    reco::doc::DataMgr::instance().doc_storage->ClearLocalCache(refresh_data.item_id());
    COUNTERS_doc__refresh_cache_num.Increase(1);
    LOG(INFO) << "refresh, item_id:" << refresh_data.item_id()
              << ", prt:" << kafka_msg.partition << ", offset:" << kafka_msg.offset
              << ", key:" << kafka_msg.key << ", stamp:" << kafka_msg.timestamp_ms;
  }
}

void DocSyncMgr::LoopSyncToCache() {
  auto& doc_storage = reco::doc::DataMgr::instance().doc_storage;

  while (!thread_stop_) {
    uint64 item_id = 0;
    if (reco::doc::DataMgr::instance().sync_to_cache_queue.TryTake(&item_id) != 1) {
      base::SleepForSeconds(1);
      continue;
    }

    RecoItem reco_item;
    if(ItemHandler::GetUpdatedRecoItem(item_id, &reco_item)) {
      reco_item.clear_raw_item();
      doc_storage->SaveRecoItemToCache(reco_item);
    } else {
      LOG(WARNING) << "can't get update reco item: " << item_id;
    }
  }
}

bool DocSyncMgr::NeedUpdate(uint64 item_id, bool use_kafka_offset, int64 kafka_offset) {
  if (!use_kafka_offset) {
    return true;
  }

  int64 last_offset = 0;
  if (item_kafka_offset_->Find(item_id, &last_offset) && last_offset >= kafka_offset) {
    return false;
  }

  item_kafka_offset_->Add(item_id, kafka_offset);
  return true;
  /*
  auto iter = item_kafka_offset_.find(item_id);
  if (iter != item_kafka_offset_.end() && iter->second > kafka_offset) {
    return false;
  }

  item_kafka_offset_[item_id] = kafka_offset;
  return true;
  */
}

void DocSyncMgr::UpdateImageInfo(RecoItem* reco_item, bool force_check_img) {
  if (reco_item->identity().type() != reco::kSpecial) {
    if (!ItemHandler::UpdateRecoItemImageInfo(reco_item, force_check_img)) {
      LOG(INFO) << "first time update item image fail, itemid:" << reco_item->identity().item_id();

      if (reco_item->has_is_valid() && !reco_item->is_valid()) {
        LOG(INFO) << "don't add image queue, item valid is false:" << reco_item->identity().item_id();
      } else {
        LOG(INFO) << "add image queue, reco itemid:" << reco_item->identity().item_id();

        AddMissImageQueue(reco_item->identity().item_id());

        if (FLAGS_write_feedback) {
          // 注意，不能再次发给 reco item 队列，只让 item-keeper 更新 cdoc 队列
          // WriteFeedbackToItemKeeper(item->identity().item_id(), false, true);
        }
      }
    }
  }
}

bool DocSyncMgr::AddDoc(const RecoItem& reco_item, bool use_kafka_offset, int64 kafka_offset) {
  if (!reco_item.identity().has_item_id()) {
    LOG(ERROR) << "item has no item_id" << reco_item.Utf8DebugString();
    return true;
  }

  const uint64 item_id = reco_item.identity().item_id();
  LOG(INFO) << "prepare to add item id:" << item_id;

  //  check
  if (!reco_item.IsInitialized()) {
    LOG(ERROR) << "pb initialized fail, item:" << reco_item.identity().item_id()
               << ", info:" << reco_item.InitializationErrorString();
    return true;
  }

  RecoItemInvalidReason invalid_reason = kNoReasonForInvalid;

  // RawItem raw_item(reco_item.raw_item());
  // bool is_update_ok = ItemHandler::UpdateRawItem(reco_item, &raw_item, &invalid_reason);

  // 这里为了减小锁的粒度，在流程上提前了 Update 这个耗时的过程
  RecoItem reco_item_cache(reco_item);
  const bool is_reco_update_ok = ItemHandler::UpdateRecoItem(&reco_item_cache, &invalid_reason);

  thread::AutoLock lock(&add_doc_mutex_);
  if (!NeedUpdate(item_id, use_kafka_offset, kafka_offset)) {
    LOG(INFO) << "add doc don't need update, item:" << item_id;
    return true;
  }

  auto& doc_storage = reco::doc::DataMgr::instance().doc_storage;
  // save to aero
  int ret = doc_storage->SaveRecoItemToDB(reco_item);
  if (1 == ret) {  // 序列化失败，不重试
    LOG(INFO) << "save to db error, itemid:" << item_id;
    return true;
  }

  // fill cache
  if (is_reco_update_ok) {
    reco_item_cache.clear_raw_item();
    doc_storage->SaveRecoItemToCache(reco_item_cache);
  } else {
    LOG(WARNING) << "handle reco item fail, item:" << item_id;
  }

  if (ret != 0) {  // 数据库写入失败，需要重试
    return false;
  }

  // track to elk
  if (!reco_item.is_valid()) {
    TrackRecoItem(reco_item, kNotDeliver);
  } else {
    TrackRecoItem(reco_item, kDeliverIt);
    if (!reco_item_cache.is_valid()) {
      TrackRecoItem(reco_item, invalid_reason);
    }
  }

  // 判断是否需要通知所有 doc 更新本地 cache， 必须先持久化才能放入队列, 需要用原始的 reco item
  AddToRefreshQueue(item_id);

  return true;
}

void DocSyncMgr::AddDocUntilSucc(const reco::RecoItem& reco_item,
                                 bool use_kafka_offset,
                                 int64 kafka_offset) {
  /*
  RecoItem reco_item_copy(reco_item);

  // update timestamp
  if (reco_item_copy.has_raw_item()) {
    reco_item_copy.mutable_raw_item()->set_update_timestamp(base::GetTimestamp());
  }
  */

  int cnt = 10;
  while (--cnt > 0) {
    if (AddDoc(reco_item, use_kafka_offset, kafka_offset)) {
      return;
    }
    
    base::SleepForSeconds(2);
  }

  LOG(ERROR) << "attemp to add doc fail, item:" << reco_item.Utf8DebugString();
}

void DocSyncMgr::AddMissImageQueue(uint64 item_id) {
  UpdateItemMsg msg;
  msg.set_item_id(item_id);
  msg.set_type(kMissingPic);
  msg.set_create_stamp_us(base::GetTimestamp());
  AddMissImageQueue(msg);
}

void DocSyncMgr::AddMissImageQueue(const UpdateItemMsg& msg) {
  auto producer = reco::doc::DataMgr::instance().item_update_producer;
  std::string pb_msg;
  if (msg.SerializeToString(&pb_msg) && !pb_msg.empty()) {
    producer->Produce(pb_msg, base::Uint64ToString(msg.item_id()));
    COUNTERS_doc__produce_refresh_num.Increase(1);
  } else {
    LOG(ERROR) << "add missing image mq fail:" << msg.item_id();
  }
}

void DocSyncMgr::TrackRecoItem(const reco::RecoItem& reco_item, RecoItemInvalidReason reason) {
  const std::string str_item_id = base::Uint64ToString(reco_item.identity().item_id());

  reco::ProtoELKItemMsg elk_msg;
  elk_msg.set_item_service(reco::DOC_SERVER);
  elk_msg.set_start_tm_ms(base::GetTimestamp() / 1000);
  elk_msg.set_item_id(str_item_id);
  auto data_change = elk_msg.add_data_changes();
  data_change->set_attr_name("is_valid");

  json_t* json_msg = json_object();
  switch (reason) {
    case kDeliverIt:
      elk_msg.set_task("receive");
      elk_msg.set_op_type(reco::RECEIVE);
      data_change->set_new_value("true");
    case kNotDeliver:
      elk_msg.set_task("receive");
      elk_msg.set_op_type(reco::RECEIVE);
      data_change->set_new_value("false");
      break;
    case kImageMissing:
      elk_msg.set_task("update");
      elk_msg.set_op_type(reco::UPDATE);
      data_change->set_new_value("false");
      if (json_object_set(json_msg, "reason", json_string("图片缺失")) != 0) {
        LOG(ERROR) << "json_object_set() failed.";
      }
      break;
    case kPlaceholderErr:
      elk_msg.set_task("update");
      elk_msg.set_op_type(reco::UPDATE);
      data_change->set_new_value("false");
      if (json_object_set(json_msg, "reason", json_string("占位符错误")) != 0) {
        LOG(ERROR) << "json_object_set() failed.";
      }
      break;
    default:
      json_delete(json_msg);
      return;
  }

  if (kDeliverIt == reason || kNotDeliver == reason) {
    auto expire_time_change = elk_msg.add_data_changes();
    expire_time_change->set_attr_name("expire_time");
    if (reco_item.has_expire_time()) {
      expire_time_change->set_new_value(reco_item.expire_time());
    } else {
      expire_time_change->set_new_value("NULL");
    }
  }

  if (reason != kDeliverIt && reason != kNotDeliver) {
    char* str_msg = json_dumps(json_msg, 0);
    if (str_msg != NULL) {
      elk_msg.set_msg(str_msg);
      free(str_msg);
    } else {
      LOG(ERROR) << "json_dumps() failed.";
    }
  }

  json_delete(json_msg);

  std::string value;
  auto log_elk_producer = reco::doc::DataMgr::instance().log_elk_producer;
  if (elk_msg.SerializeToString(&value)) {
    if (!log_elk_producer->Produce(value, str_item_id)) {
      LOG(ERROR) << "elk kafka Produce failed";
    }
  } else {
    LOG(ERROR) << "elk msg SerializeToString falied";
  }
}

bool DocSyncMgr::AddToRefreshQueue(uint64 item_id) {
  UpdateItemMsg refresh_data;
  refresh_data.set_item_id(item_id);
  refresh_data.set_type(kRefreshCache);

  // TODO(KYAN): 可以和 AddMissImageQueue 合并
  std::string value;
  if (!refresh_data.SerializeToString(&value)) {
    return false;
  }

  auto producer = reco::doc::DataMgr::instance().item_update_producer;
  bool ret = producer->Produce(value, base::Uint64ToString(item_id));
  COUNTERS_doc__produce_refresh_num.Increase(1);
  LOG(INFO) << "push to refresh, item_id:" << item_id << ", ret:" << ret;
  return ret;
}

/*
bool DocSyncMgr::SetupConnItemKeeper() {
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = FLAGS_item_keeper_retry_times;
  options.timeout = FLAGS_item_keeper_timeout;

  std::vector<std::string> ips;
  base::SplitString(FLAGS_item_keeper_ips, ",", &ips);
  for (auto i = 0u; i < ips.size(); ++i) {
    std::vector<std::string> ip_port;
    base::SplitString(ips[i], ":", &ip_port);

    unsigned int port = 0;
    if (!base::StringToUint(ip_port[1], &port)) {
      LOG(ERROR) << "ip port err:" << ips[i];
      continue;
    }

    net::rpc::RpcGroup::ServerInfo si(ip_port[0], port, FLAGS_item_keeper_timeout);
    options.servers.push_back(si);
  }

  if (options.servers.empty()) {
    LOG(ERROR) << "server options empty.";
    return false;
  }

  item_keeper_rpc_group_ = new net::rpc::RpcGroup(options);
  CHECK(item_keeper_rpc_group_->Connect());
  return true;
}

bool DocSyncMgr::WriteFeedbackToItemKeeper(const uint64 item_id,
                                             const bool is_valid,
                                             const bool exclude_reco_mq) {
  reco::itemkeeper::UpdateItemRequest request;
  reco::itemkeeper::UpdateItemFieldResponse response;
  request.mutable_service_identity()->set_service_name("doc_server");
  request.set_item_id(item_id);

  reco::RecoItem reco_item;
  reco_item.set_is_valid(is_valid);
  reco_item.SerializePartialToString(request.mutable_reco_item_bytes());

  if (exclude_reco_mq) {
    request.add_exclude_storages(reco::itemkeeper::kRecoItemQueue);
    }

  reco::itemkeeper::ItemKeeper::Stub stub(item_keeper_rpc_group_);
  net::rpc::RpcClientController rpc;
  stub.updateItemFields(&rpc, &request, &response, NULL);
  rpc.SetTimeout(FLAGS_item_keeper_timeout);
  rpc.Wait();

  bool ret = true;
  if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
    ret = false;
  }

  LOG(INFO) << "send item keeper. ret:" << ret
            << ", item_id:" << item_id
            << ", resp:" << response.Utf8DebugString();

  return ret;
}
*/
}
}
