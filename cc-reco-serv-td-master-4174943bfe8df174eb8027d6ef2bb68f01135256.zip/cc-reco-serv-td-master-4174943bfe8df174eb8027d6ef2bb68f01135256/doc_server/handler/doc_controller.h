#pragma once

#include "base/random/pseudo_random.h"
#include "reco/bizc/proto/reco_doc_server.pb.h"

#include "reco/serv/doc_server/handler/doc_storage.h"
#include "reco/serv/doc_server/handler/item_handler.h"


namespace reco {
namespace doc {
enum GetDocType {
  kGetDocNoDrop = 0,
  kGetDocRealTime,
  kGetDocNoRealTime
};

class DocController {
 public:
  DocController() {}

  void GetItemDocInfo(const ItemDocRequest *request, ItemDocResponse *response);

  void GetRecoItemInfo(const RecoItemRequest *request, RecoItemResponse *response);

  void GetSimItemImageList(const SimItemImageRequest *request, SimItemImageResponse *response);

  void UpdateRawItemDocInfo(const UpdateRawItemDocRequest *request, UpdateRawItemDocResponse *response);

  void UpdateDBRecoItem(const UpdateDBRecoItemRequest *request, UpdateDBRecoItemResponse *response);

 private:
  bool IsDropReadDB(GetDocType get_doc_type);

 private:
  base::PseudoRandom random_;
};
}
}
