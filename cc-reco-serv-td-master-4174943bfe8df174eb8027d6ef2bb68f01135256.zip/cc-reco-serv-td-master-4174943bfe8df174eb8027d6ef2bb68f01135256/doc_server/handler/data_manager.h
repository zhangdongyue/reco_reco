#pragma once

#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"

#include "reco/serv/doc_server/handler/doc_storage.h"
#include "reco/serv/doc_server/handler/doc_controller.h"
#include "reco/serv/doc_server/handler/system_counter.h"


namespace reco {
namespace kafka {
class Consumer;
class Producer;
}

namespace doc {
class DataManager {
 public:
  DataManager()  {}

  explicit DataManager(int work_thread_num);

  ~DataManager();
  
  void Init(void);

  void Stop(void);

  thread::ThreadPool* data_manager_pool;
  DocStorage* doc_storage;
  SystemCounter* system_counter;
  
  thread::BlockingQueue<uint64> sync_to_cache_queue;
  std::atomic<int32> op_num;
  std::atomic<int64> max_response_time;

  // kafka
  reco::kafka::Consumer* item_consumer;
  reco::kafka::Producer* log_elk_producer;
  reco::kafka::Producer* item_update_producer;
  reco::kafka::Consumer* image_update_consumer;
  reco::kafka::Consumer* item_refresh_consumer;

 private:
  void InitKafka();

  DISALLOW_COPY_AND_ASSIGN(DataManager);
};

typedef reco::common::singleton_default<DataManager> DataMgr;
}
}
