#include "reco/serv/doc_server/handler/item_handler.h"

#include <string>
#include <vector>
#include <algorithm>

#include "base/common/sleep.h"
#include "nlp/common/nlp_util.h"
#include "extend/regexp/re3/re3.h"
#include "base/hash_function/city.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "extend/json/jansson/jansson.h"
#include "base/strings/string_number_conversions.h"
#include "reco/serv/doc_server/handler/doc_normalize.h"
#include "reco/serv/doc_server/handler/data_manager.h"
#include "reco/serv/doc_server/handler/doc_storage.h"

namespace reco {
namespace doc {
DEFINE_string(image_server_url_prefix, "10.3.5.73:22200", "image server url prefix");
DEFINE_int32(emoticon_size_thres, 40, "表情图大小阈值");
DEFINE_string(image_meta_server_url_prefix, "10.3.5.73:22200", "image server meta url prefix");

// http connection
DEFINE_int32(http_connect_timeout, 50, "http connect timeout");
DEFINE_int32(http_read_timeout, 100, "http read timeout");

const char* ItemHandler::kGIFCompressShow = "gif";
const char* ItemHandler::kJPGCompressShow = "jpg";
serving_base::HttpCommunicator* ItemHandler::image_reader_ = NULL;

void ItemHandler::Initialize() {
  serving_base::HttpCommunicator::Config image_config;
  image_config.connect_timeout_in_ms = FLAGS_http_connect_timeout;
  image_config.retry_times = 1;
  image_config.transfer_timeout_in_ms = FLAGS_http_read_timeout;
  image_reader_ = new serving_base::HttpCommunicator(image_config);
}

void ItemHandler::Destructor() {
  if (image_reader_ != NULL) {
    delete image_reader_;
    image_reader_ = NULL;
  }
}

/*
bool ItemHandler::UpdateRawItem(const RecoItem& reco_item,
                                RawItem* raw_item,
                                RawItemInvalidReason*
                                invalid_reason) {
  if (!UpdateRawItem(raw_item, invalid_reason)) {
    return false;
  }

  // 使用 reco item 的类别，代替 raw item 的类别，类别属性以 reco item 为准，
  // 类别有更新的话，也只会更新到 reco item 一级，不会去改 raw item 的类别
  if (reco_item.category_size() > 0) {
    raw_item->clear_category();
    for (int i = 0; i < reco_item.category_size(); ++i) {
      raw_item->add_category(reco_item.category(i));
    }
  }
  if (!raw_item->IsInitialized()) {
    LOG(ERROR) << "pb initialized fail, item:" << reco_item.identity().item_id()
               << ", info:" << raw_item->InitializationErrorString();
    return false;
  }
  return true;
}
*/

bool ItemHandler::UpdateRecoItem(RecoItem* reco_item, RecoItemInvalidReason* invalid_reason) {
  const uint64 item_id = reco_item->identity().item_id();
  LOG(INFO) << "update item:" << item_id;

  // thumbnail
  std::vector<reco::NewsImage*> thumbnails;
  auto pb_thumbnails = reco_item->mutable_thumbnail();
  for (int i = 0; i < pb_thumbnails->size(); ++i) {
    thumbnails.push_back(pb_thumbnails->Mutable(i));
  }
  UpdateImagesUrl(reco_item, &thumbnails, invalid_reason);

  // specail item 只替换缩略图
  if (IsSpecialItem(reco_item->identity().type())) {
    VLOG(1) << "special item doesn't update content." << item_id;
    return true;
  }

  std::vector<reco::NewsImage*> video_images;
  for (int i = 0; i < reco_item->video_meta_settings_size(); ++i) {
    auto video_setting = reco_item->mutable_video_meta_settings(i);
    if (video_setting->has_image_meta()) {
      video_images.push_back(video_setting->mutable_image_meta());
    }
  }
  UpdateImagesUrl(reco_item, &video_images, invalid_reason);

  const reco::ItemType item_type = reco_item->identity().type();
  const bool is_atlas = (item_type == reco::kPicture
                         || (item_type == reco::kPictureNews && reco_item->content().empty())
                         || item_type == reco::kThemeVideo);

  std::string content;
  if (item_type == reco::kPureVideo) {
    // NOTE(jianhuang) 纯视频，正文部分加一个视频占位符号
    *reco_item->mutable_content() = "<!--{video:0}-->";
    reco_item->mutable_image()->Clear();
  } else if (is_atlas) {
    // NOTE(jianhuang) 图集由于不放置占位符号，只更新图片, 不进行占位符的替换
    std::vector<reco::NewsImage*> images;
    auto pb_images = reco_item->mutable_image();
    for (int i = 0; i < pb_images->size(); ++i) {
      images.push_back(pb_images->Mutable(i));
    }
    UpdateImagesUrl(reco_item, &images, invalid_reason);

    std::vector<reco::NewsImage> image_list;
    for (auto iter = images.begin(); iter != images.end(); ++iter) {
      if (IsImageValid(**iter)) {
        image_list.push_back(**iter);
      }
    }
    reco_item->mutable_image()->Clear();
    for (int i = 0; i < (int)image_list.size(); ++i) {
      reco_item->add_image()->CopyFrom(image_list[i]);
    }
  } else {
    UpdateContent(reco_item->identity().item_id(), reco_item->content(), reco_item->mutable_content());
    ReplacePlaceholder(reco_item, invalid_reason);
  }

  // 幽默频道特殊处理
  if (reco_item->identity().type() == reco::kHumor) {
    if (!ResetHumorItem(reco_item)) {
      return false;
    }
  }

  if (!reco_item->IsInitialized()) {
    LOG(ERROR) << "pb initialized fail, item:" << reco_item->identity().item_id()
               << ", info:" << reco_item->InitializationErrorString();
    return false;
  }

  return true;
}

/*
bool ItemHandler::UpdateRawItem(RawItem* raw_item,
                                RawItemInvalidReason* invalid_reason) {
  LOG(INFO) << "update raw item content, " << raw_item->identity().item_id();

  // thumbnail
  std::vector<reco::NewsImage*> thumbnails;
  auto pb_thumbnails = raw_item->mutable_thumbnail();
  for (int i = 0; i < pb_thumbnails->size(); ++i) {
    thumbnails.push_back(pb_thumbnails->Mutable(i));
  }
  UpdateImagesUrl(raw_item, &thumbnails, invalid_reason);

  // specail item 只替换缩略图
  if (IsSpecialItem(raw_item->identity().type())) {
    LOG(INFO) << "special item doesn't update content." << raw_item->identity().item_id();
    return true;
  }

  std::vector<reco::NewsImage*> video_images;
  for (int i = 0; i < raw_item->video_meta_settings_size(); ++i) {
    auto video_setting = raw_item->mutable_video_meta_settings(i);
    if (video_setting->has_image_meta()) {
      video_images.push_back(video_setting->mutable_image_meta());
    }
  }
  UpdateImagesUrl(raw_item, &video_images, invalid_reason);

  reco::ItemType item_type = raw_item->identity().type();
  bool is_atlas = (item_type == reco::kPicture
                   || (item_type == reco::kPictureNews && raw_item->content().empty()));
  std::string content;
  if (item_type == reco::kPureVideo) {
    // NOTE(jianhuang) 纯视频，正文部分加一个视频占位符号
    *raw_item->mutable_content() = "<!--{video:0}-->";
    raw_item->mutable_image()->Clear();
  } else if (is_atlas) {
    // NOTE(jianhuang) 图集由于不放置占位符号，只更新图片, 不进行占位符的替换
    std::vector<reco::NewsImage*> images;
    auto pb_images = raw_item->mutable_image();
    for (int i = 0; i < pb_images->size(); ++i) {
      images.push_back(pb_images->Mutable(i));
    }
    UpdateImagesUrl(raw_item, &images, invalid_reason);
    std::vector<reco::NewsImage> image_list;
    for (auto iter = images.begin(); iter != images.end(); ++iter) {
      if (IsImageValid(**iter)) {
        image_list.push_back(**iter);
      }
    }
    raw_item->mutable_image()->Clear();
    for (int i = 0; i < (int)image_list.size(); ++i) {
      raw_item->add_image()->CopyFrom(image_list[i]);
    }
  } else {
    UpdateContent(raw_item->identity().item_id(), raw_item->content(), raw_item->mutable_content());
    ReplacePlaceholder(raw_item, invalid_reason);
  }

  // 幽默频道特殊处理
  if (raw_item->identity().type() == reco::kHumor) {
    if (!ResetHumorItem(raw_item)) {
      return false;
    }
  }

  return true;
}
*/

/*
bool ItemHandler::UpdateRawItemImageInfo(reco::RawItem* raw_item) {
  CHECK_NOTNULL(raw_item);
  bool succ = true;
  for (int i = 0; i < raw_item->image_size(); ++i) {
    reco::NewsImage* image = raw_item->mutable_image(i);
    if (!UpdateSingleImageInfo(image)) {
      succ = false;
    }
  }
  for (int i = 0; i < raw_item->thumbnail_size(); ++i) {
    reco::NewsImage* image = raw_item->mutable_thumbnail(i);
    if (!UpdateSingleImageInfo(image)) {
      succ = false;
    }
  }
  for (int i = 0; i < raw_item->video_meta_settings_size(); ++i) {
    reco::VideoMetaSetting* setting = raw_item->mutable_video_meta_settings(i);
    if (!setting->has_image_meta()) continue;
    reco::NewsImage* image = setting->mutable_image_meta();
    if (!UpdateSingleImageInfo(image)) {
      succ = false;
    }
  }
  return succ;
}
*/

bool ItemHandler::UpdateRecoItemImageInfo(reco::RecoItem* reco_item, bool force_check_img) {
  CHECK_NOTNULL(reco_item);

  bool succ = true;
  for (int i = 0; i < reco_item->image_size(); ++i) {
    reco::NewsImage* image = reco_item->mutable_image(i);
    if (!UpdateSingleImageInfo(image, force_check_img)) {
      succ = false;
    }
  }
  for (int i = 0; i < reco_item->thumbnail_size(); ++i) {
    reco::NewsImage* image = reco_item->mutable_thumbnail(i);
    if (!UpdateSingleImageInfo(image, force_check_img)) {
      succ = false;
    }
  }
  for (int i = 0; i < reco_item->video_meta_settings_size(); ++i) {
    reco::VideoMetaSetting* setting = reco_item->mutable_video_meta_settings(i);
    if (!setting->has_image_meta())
      continue;

    reco::NewsImage* image = setting->mutable_image_meta();
    if (!UpdateSingleImageInfo(image, force_check_img)) {
      succ = false;
    }
  }

  /*
  // 同步raw信息的， 可以删除掉，不需要返回raw信息了
  if (succ && reco_item->has_raw_item()) {
    if (reco_item->image_size() != reco_item->raw_item().image_size()) {
      LOG(ERROR) << "reco raw image size not equal:" << reco_item->identity().item_id()
                 << ":" << reco_item->image_size() << ":" << reco_item->raw_item().image_size();
      return false;
    }
    if (reco_item->thumbnail_size() != reco_item->raw_item().thumbnail_size()) {
      LOG(ERROR) << "reco raw image size not equal" << reco_item->identity().item_id();
      return false;
    }
    if (reco_item->video_meta_settings_size() != reco_item->raw_item().video_meta_settings_size()) {
      LOG(ERROR) << "reco raw image size not equal" << reco_item->identity().item_id();
      return false;
    }
    for (int i = 0; i < reco_item->image_size(); ++i) {
      auto image = reco_item->mutable_raw_item()->mutable_image(i);
      image->set_width(reco_item->image(i).width());
      image->set_height(reco_item->image(i).height());
      image->set_type(reco_item->image(i).type());
    }
    for (int i = 0; i < reco_item->thumbnail_size(); ++i) {
      auto image = reco_item->mutable_raw_item()->mutable_thumbnail(i);
      image->set_width(reco_item->thumbnail(i).width());
      image->set_height(reco_item->thumbnail(i).height());
      image->set_type(reco_item->thumbnail(i).type());
    }
    for (int i = 0; i < reco_item->video_meta_settings_size(); ++i) {
      auto setting = reco_item->mutable_raw_item()->mutable_video_meta_settings(i);
      if (!setting->has_image_meta()) continue;
      auto image = setting->mutable_image_meta();
      if (!reco_item->video_meta_settings(i).has_image_meta()) continue;
      auto& reco_image = reco_item->video_meta_settings(i).image_meta();
      image->set_width(reco_image.width());
      image->set_height(reco_image.height());
      image->set_type(reco_image.type());
    }
  }
  */

  return succ;
}

bool ItemHandler::IsImageValid(const reco::NewsImage& image) {
  return (image.has_width() && image.width() > 0 && image.has_height() && image.height() > 0);
}

bool ItemHandler::IsEmoticon(const reco::NewsImage& image) {
  if (image.has_width() && image.width() <= FLAGS_emoticon_size_thres) return true;
  if (image.has_height() && image.height() <= FLAGS_emoticon_size_thres) return true;
  return false;
}

/*
void ItemHandler::UpdateImagesUrl(reco::RawItem* raw_item,
                                  std::vector<reco::NewsImage*>* images,
                                  RawItemInvalidReason* invalid_reason) {
  for (auto iter = images->begin(); iter != images->end(); ++iter) {
    auto image = *iter;
    uint64 url_sign = base::CityHash64(image->url().c_str(), image->url().size());
    std::string image_type = (image->has_type()? ("." + image->type()) : "");
    image->set_url(base::StringPrintf("%s%lu%s?id=0",
                                      FLAGS_image_server_url_prefix.c_str(),
                                      url_sign, image_type.c_str()));

    if (raw_item->is_valid() && !IsImageValid(*image)) {
      raw_item->set_is_valid(false);
      LOG(WARNING) << "invalid video image filter, item id: " << raw_item->identity().item_id()
                   << ", url:" << nlp::util::NormalizeLine(image->Utf8DebugString());
      if (invalid_reason != NULL) {
        *invalid_reason = kImageMissing;
      }
    }
  }
}
*/

bool ItemHandler::IsSpecialItem(reco::ItemType item_type) {
  return (item_type == reco::kSpecial
          || item_type == reco::kStarCard
          || item_type == reco::kConstellation
          || item_type == reco::kSiteNav
          || item_type == reco::kSportLiveCard
          || item_type == reco::kWeMediaCard
          || item_type == reco::kHotCard
          || item_type == reco::kMicroNewsCard
          || item_type == reco::kIMCard
          || item_type == reco::kHotCard
          || item_type == reco::kSceneCard
          || item_type == reco::kRankList
          || item_type == reco::kStockIndexCard
          || item_type == reco::kTopicCard);
}

void ItemHandler::UpdateContent(uint64 item_id, std::string orign_content, std::string* ret_content) {
  // 0. 表格处理, 将表格之间的 '\n' 替换为空格
  std::size_t st_pos = orign_content.find("<table>");
  while (st_pos != std::string::npos) {
    std::size_t ed_pos = orign_content.find("</table>", st_pos);
    if (ed_pos == std::string::npos) {
      break;
    }
    // find \n in st_pos, ed_pos
    st_pos = orign_content.find('\n', st_pos);
    while (st_pos != std::string::npos && st_pos < ed_pos) {
      // only replace with space, do not delete it, or the outer while will loop
      orign_content.replace(st_pos, 1, 1, ' ');
      st_pos = orign_content.find('\n', st_pos);
    }

    // no \n in <table></table>
    st_pos = orign_content.find("<table>", ed_pos);
  }
  ret_content->clear();
  // 1. \1\n 转换成 \1
  orign_content = base::StringReplace(orign_content, "\1\n", "\1", true);
  // 2. \n 转换成 <p> </p>
  std::vector<std::string> flds;
  base::SplitString(orign_content, "\n", &flds);
  for (size_t i = 0; i < flds.size(); ++i) {
    if (flds[i].empty()) {
      continue;
    }
    NormalizeMultiLinesInPlaceS(&(flds[i]));
    std::size_t pos = flds[i].find("<table>");
    if (pos == std::string::npos) {
      if (flds[i].empty()
          || flds[i] == "\1"
          || flds[i] == "\2"
          || flds[i] == "\3"
          || flds[i] == "\4") {
        ret_content->append(flds[i]);
      } else {
        ret_content->append("<p>");
        ret_content->append(flds[i]);
        ret_content->append("</p>");
      }
    } else {
      // find first <table> and last </table>
      // there should not be \n within <table>
      std::size_t st = flds[i].find("<table>");
      std::size_t ed = flds[i].rfind("</table>");
      if (st != std::string::npos && ed != std::string::npos) {
        ed += strlen("</table>");
        std::string part = flds[i].substr(0, st);
        if (!part.empty()) {
          ret_content->append("<p>");
          ret_content->append(part);
          ret_content->append("</p>");
        }
        part = flds[i].substr(st, ed - st);
        if (!part.empty()) {
          ret_content->append("<p>");
          ret_content->append(part);
          ret_content->append("</p>");
        }
        part = flds[i].substr(ed);
        if (!part.empty()) {
          ret_content->append("<p>");
          ret_content->append(part);
          ret_content->append("</p>");
        }
      } else {
        // table should be matched, something wrong, discard this part
        LOG(ERROR) << "table not matched: " << item_id;
      }
    }
  }
}

/*
bool ItemHandler::ResetHumorItem(reco::RawItem* raw_item) {
  if (raw_item->identity().type() != reco::kHumor) return true;

  std::string real_content = raw_item->content();
  extend::re3::Re3::GlobalReplace(&real_content, "<[[:ascii:]]+>", " ");
  real_content = nlp::util::NormalizeLine(real_content);
  if (raw_item->image_size() == 1) {
  } else if (!real_content.empty() && raw_item->image_size() == 0) {
    LOG(INFO) << "humor item, filter title, " << raw_item->identity().item_id();
    raw_item->mutable_title()->clear();
  } else if (real_content.empty() && raw_item->image_size() == 0) {
    LOG(INFO) << "humor item, invalid, " << raw_item->identity().item_id();
    return false;
  }
  return true;
}
*/

/*
void ItemHandler::ReplacePlaceholder(reco::RawItem* raw_item,
                                     RawItemInvalidReason* invalid_reason) {
  bool is_err = false;
  std::string content = raw_item->content();
  // 图片处理
  if (!ReplaceImagePlaceholder(raw_item, &content)) {
    is_err = true;
  }
  // 视频处理
  if (!ReplaceVideoPlaceholder(*raw_item, &content)) {
    is_err = true;
  }
  if (!ReplaceCharacterPlaceholder(*raw_item, &content)) {
    is_err = true;
  }
  // 超链接处理
  if (!ReplaceHyperLinkPlaceholder(*raw_item, &content)) {
    is_err = true;
  }
  // 超链接处理
  if (!ReplaceVotePlaceholder(*raw_item, &content)) {
    is_err = true;
  }
  if (!ReplaceAudioPlaceholder(*raw_item, &content)) {
    is_err = true;
  }
  *raw_item->mutable_content() = content;

  if (raw_item->is_valid() && is_err) {
    raw_item->set_is_valid(false);
    if (invalid_reason != NULL) {
      *invalid_reason = kPlaceholderErr;
    }
  }
}
*/

/*
bool ItemHandler::ReplaceImagePlaceholder(reco::RawItem* raw_item, std::string* content) {
  if (raw_item->image_size() == 0) return true;

  std::vector<reco::NewsImage> image_list;
  std::vector<std::string> flds;
  base::SplitString(*content, "\1", &flds);
  bool is_item_valid = true;
  content->clear();
  if ((int)flds.size() <= raw_item->image_size()) {
    LOG(WARNING) << "item id: " << raw_item->identity().item_id()
                 << "图片占位符不足, 占位符数: " << flds.size() - 1
                 << ", 图片数: " << raw_item->image_size();
  }
  int max_pic_num = std::min((int)flds.size() - 1, raw_item->image_size());
  int count = 0;
  for (int i = 0; i < max_pic_num; ++i) {
    auto& image = raw_item->image(i);
    content->append(flds[i]);
    bool is_image_valid = IsImageValid(image);
    if (count < kMaxPicNum && is_image_valid) {
      uint64 url_sign = base::CityHash64(image.url().c_str(), image.url().size());
      std::string image_type = (image.has_type()? ("." + image.type()) : "");
      if (IsEmoticon(image)) {
        content->append(base::StringPrintf("<img src=\"%s%lu%s?id=0\" width=%d height=%d >",
                                           FLAGS_image_server_url_prefix.c_str(), url_sign,
                                           image_type.c_str(), image.width(), image.height()));
      } else {
        content->append(base::StringPrintf("<!--{img:%d}-->", count));
        image_list.push_back(image);
        image_list.back().set_url(base::StringPrintf("%s%lu%s?id=0",
                                                     FLAGS_image_server_url_prefix.c_str(), url_sign,
                                                     image_type.c_str()));
        ++count;
      }
    }
    // 图片不合法时，设置整个 item 不合法
    if (!is_image_valid) {
      LOG(WARNING) << "invalid image filter, item id: " << raw_item->identity().item_id()
                   << "url:" << nlp::util::NormalizeLine(image.Utf8DebugString());
      is_item_valid = false;
    }
  }
  for (int i = max_pic_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }
  // 图片转换成图床地址
  raw_item->mutable_image()->Clear();
  for (int i = 0; i < (int)image_list.size(); ++i) {
    raw_item->add_image()->CopyFrom(image_list[i]);
  }
  return is_item_valid;
}
*/

/*
bool ItemHandler::ReplaceVideoPlaceholder(const reco::RawItem& raw_item, std::string* content) {
  if (raw_item.video_meta_settings_size() == 0) return true;

  std::vector<std::string> flds;
  base::SplitString(*content, "\2", &flds);
  content->clear();
  if ((int)flds.size() <= raw_item.video_meta_settings_size()) {
    LOG(WARNING) << "item id: " << raw_item.identity().item_id()
                 << "视频占位符不足, 占位符数: " << flds.size() - 1
                 << ", 视频数: " << raw_item.video_meta_settings_size();
  }
  int max_video_num = std::min((int)flds.size() - 1, raw_item.video_meta_settings_size());
  int count = 0;
  for (int i = 0; i < max_video_num; ++i) {
    content->append(flds[i]);
    content->append(base::StringPrintf("<!--{video:%d}-->", count));
    ++count;
  }
  for (int i = max_video_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }
  return true;
}
*/

/*
bool ItemHandler::ReplaceCharacterPlaceholder(const reco::RawItem& item, std::string* content) {
  if (item.content_ext_character_size() == 0) return true;
  std::vector<std::string> flds;
  base::SplitString(*content, "\6", &flds);
  content->clear();
  if ((int)flds.size() <= item.content_ext_character_size()) {
    LOG(WARNING) << "item id: " << item.identity().item_id()
                 << "人物卡片占位符不足, 占位符数: " << flds.size() - 1
                 << ", 视频数: " << item.content_ext_character_size();
  }
  int max_character_num = std::min((int)flds.size() - 1, item.content_ext_character_size());
  int count = 0;
  for (int i = 0; i < max_character_num; ++i) {
    content->append(flds[i]);
    content->append(base::StringPrintf("<!--{character:%d}-->", count));
    ++count;
  }
  for (int i = max_character_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }

  return true;
}
*/

/*
bool ItemHandler::ReplaceHyperLinkPlaceholder(const reco::RawItem& item, std::string* content) {
  if (item.content_ext_hyperlink_size() == 0) return true;
  std::vector<std::string> flds;
  base::SplitString(*content, "\3", &flds);
  content->clear();
  if ((int)flds.size() <= item.content_ext_hyperlink_size()) {
    LOG(WARNING) << "item id: " << item.identity().item_id()
                 << "超链接占位符不足, 占位符数: " << flds.size() - 1
                 << ", 超链接数: " << item.content_ext_hyperlink_size();
  }
  int max_hyperlink_num = std::min((int)flds.size() - 1, item.content_ext_hyperlink_size());
  int count = 0;
  for (int i = 0; i < max_hyperlink_num; ++i) {
    content->append(flds[i]);
    content->append(base::StringPrintf("<!--{hyperlink:%d}-->", count));
    ++count;
  }
  for (int i = max_hyperlink_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }
  return true;
}
*/

/*
bool ItemHandler::ReplaceVotePlaceholder(const reco::RawItem& item, std::string* content) {
  if (item.content_ext_vote_size() == 0) return true;
  std::vector<std::string> flds;
  base::SplitString(*content, "\4", &flds);
  content->clear();
  if ((int)flds.size() <= item.content_ext_vote_size()) {
    LOG(WARNING) << "item id: " << item.identity().item_id()
                 << "投票占位符不足, 占位符数: " << flds.size() - 1
                 << ", 投票数: " << item.content_ext_vote_size();
  }
  int max_vote_num = std::min((int)flds.size() - 1, item.content_ext_vote_size());
  int count = 0;
  for (int i = 0; i < max_vote_num; ++i) {
    content->append(flds[i]);
    content->append(base::StringPrintf("<!--{vote:%d}-->", count));
    ++count;
  }
  for (int i = max_vote_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }
  return true;
}
*/

/*
bool ItemHandler::ReplaceAudioPlaceholder(const reco::RawItem& item, std::string* content) {
  if (item.audio_meta_settings_size() == 0) return true;
  std::vector<std::string> flds;
  base::SplitString(*content, "\5", &flds);
  content->clear();
  if ((int)flds.size() <= item.audio_meta_settings_size()) {
    LOG(WARNING) << "item id: " << item.identity().item_id()
                 << "超链接占位符不足, 占位符数: " << flds.size() - 1
                 << ", 超链接数: " << item.audio_meta_settings_size();
  }
  int max_audio_num = std::min((int)flds.size() - 1, item.audio_meta_settings_size());
  int count = 0;
  for (int i = 0; i < max_audio_num; ++i) {
    content->append(flds[i]);
    content->append(base::StringPrintf("<!--{audio:%d}-->", count));
    ++count;
  }
  for (int i = max_audio_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }
  return true;
}
*/

void ItemHandler::UpdateImagesUrl(reco::RecoItem* reco_item,
                                  std::vector<reco::NewsImage*>* images,
                                  RecoItemInvalidReason* invalid_reason) {
  for (auto iter = images->begin(); iter != images->end(); ++iter) {
    auto image = *iter;
    const uint64 url_sign = base::CityHash64(image->url().c_str(), image->url().size());
    std::string image_type = (image->has_type()? ("." + image->type()) : "");
    image->set_url(base::StringPrintf("%s%lu%s?id=0",
                                      FLAGS_image_server_url_prefix.c_str(),
                                      url_sign, image_type.c_str()));

    if (reco_item->is_valid() && !IsImageValid(*image)) {
      reco_item->set_is_valid(false);
      LOG(WARNING) << "invalid video image filter, item id: " << reco_item->identity().item_id()
                   << ", url:" << nlp::util::NormalizeLine(image->Utf8DebugString());
      if (invalid_reason) {
        *invalid_reason = kImageMissing;
      }
    }
  }
}

void ItemHandler::ReplacePlaceholder(reco::RecoItem* reco_item, RecoItemInvalidReason* invalid_reason) {
  bool is_err = false;
  std::string content = reco_item->content();
  // 图片处理
  if (!ReplaceImagePlaceholder(reco_item, &content)) {
    is_err = true;
  }
  // 视频处理
  if (!ReplaceVideoPlaceholder(*reco_item, &content)) {
    is_err = true;
  }
  if (!ReplaceCharacterPlaceholder(*reco_item, &content)) {
    is_err = true;
  }
  // 超链接处理
  if (!ReplaceHyperLinkPlaceholder(*reco_item, &content)) {
    is_err = true;
  }
  // 超链接处理
  if (!ReplaceVotePlaceholder(*reco_item, &content)) {
    is_err = true;
  }
  if (!ReplaceAudioPlaceholder(*reco_item, &content)) {
    is_err = true;
  }
  *reco_item->mutable_content() = content;

  if (reco_item->is_valid() && is_err) {
    reco_item->set_is_valid(false);
    if (invalid_reason != NULL) {
      *invalid_reason = kPlaceholderErr;
    }
  }
}

bool ItemHandler::ReplaceImagePlaceholder(reco::RecoItem* reco_item, std::string* content) {
  if (reco_item->image_size() == 0) return true;

  std::vector<reco::NewsImage> image_list;
  std::vector<std::string> flds;
  base::SplitString(*content, "\1", &flds);
  bool is_item_valid = true;
  content->clear();
  if ((int)flds.size() <= reco_item->image_size()) {
    LOG(WARNING) << "item id: " << reco_item->identity().item_id()
                 << "图片占位符不足, 占位符数: " << flds.size() - 1
                 << ", 图片数: " << reco_item->image_size();
  }
  int max_pic_num = std::min((int)flds.size() - 1, reco_item->image_size());
  int count = 0;
  for (int i = 0; i < max_pic_num; ++i) {
    auto& image = reco_item->image(i);
    content->append(flds[i]);
    bool is_image_valid = IsImageValid(image);
    if (count < kMaxPicNum && is_image_valid) {
      uint64 url_sign = base::CityHash64(image.url().c_str(), image.url().size());
      std::string image_type = (image.has_type()? ("." + image.type()) : "");
      if (IsEmoticon(image)) {
        content->append(base::StringPrintf("<img src=\"%s%lu%s?id=0\" width=%d height=%d >",
                                           FLAGS_image_server_url_prefix.c_str(), url_sign,
                                           image_type.c_str(), image.width(), image.height()));
      } else {
        content->append(base::StringPrintf("<!--{img:%d}-->", count));
        image_list.push_back(image);
        image_list.back().set_url(base::StringPrintf("%s%lu%s?id=0",
                                                     FLAGS_image_server_url_prefix.c_str(), url_sign,
                                                     image_type.c_str()));
        ++count;
      }
    }

    // 图片不合法时，设置整个 item 不合法
    if (!is_image_valid) {
      LOG(WARNING) << "invalid image filter, item id: " << reco_item->identity().item_id()
                   << "url:" << nlp::util::NormalizeLine(image.Utf8DebugString());
      is_item_valid = false;
    }
  }

  for (int i = max_pic_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }

  // 图片转换成图床地址
  reco_item->mutable_image()->Clear();
  for (int i = 0; i < (int)image_list.size(); ++i) {
    reco_item->add_image()->CopyFrom(image_list[i]);
  }

  return is_item_valid;
}

bool ItemHandler::ReplaceVideoPlaceholder(const reco::RecoItem& reco_item, std::string* content) {
  if (reco_item.video_meta_settings_size() == 0) return true;

  std::vector<std::string> flds;
  base::SplitString(*content, "\2", &flds);
  content->clear();

  if ((int)flds.size() <= reco_item.video_meta_settings_size()) {
    LOG(WARNING) << "item id: " << reco_item.identity().item_id()
                 << "视频占位符不足, 占位符数: " << flds.size() - 1
                 << ", 视频数: " << reco_item.video_meta_settings_size();
  }

  int max_video_num = std::min((int)flds.size() - 1, reco_item.video_meta_settings_size());
  int count = 0;

  for (int i = 0; i < max_video_num; ++i) {
    content->append(flds[i]);
    content->append(base::StringPrintf("<!--{video:%d}-->", count));
    ++count;
  }

  for (int i = max_video_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }

  return true;
}

bool ItemHandler::ReplaceCharacterPlaceholder(const reco::RecoItem& reco_item, std::string* content) {
  if (reco_item.content_ext_character_size() == 0) return true;

  std::vector<std::string> flds;
  base::SplitString(*content, "\6", &flds);
  content->clear();

  if ((int)flds.size() <= reco_item.content_ext_character_size()) {
    LOG(WARNING) << "item id: " << reco_item.identity().item_id()
                 << "人物卡片占位符不足, 占位符数: " << flds.size() - 1
                 << ", 视频数: " << reco_item.content_ext_character_size();
  }

  int max_character_num = std::min((int)flds.size() - 1, reco_item.content_ext_character_size());
  int count = 0;

  for (int i = 0; i < max_character_num; ++i) {
    content->append(flds[i]);
    content->append(base::StringPrintf("<!--{character:%d}-->", count));
    ++count;
  }

  for (int i = max_character_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }

  return true;
}

bool ItemHandler::ReplaceHyperLinkPlaceholder(const reco::RecoItem& reco_item, std::string* content) {
  if (reco_item.content_ext_hyperlink_size() == 0) return true;

  std::vector<std::string> flds;
  base::SplitString(*content, "\3", &flds);
  content->clear();

  if ((int)flds.size() <= reco_item.content_ext_hyperlink_size()) {
    LOG(WARNING) << "item id: " << reco_item.identity().item_id()
                 << "超链接占位符不足, 占位符数: " << flds.size() - 1
                 << ", 超链接数: " << reco_item.content_ext_hyperlink_size();
  }

  int max_hyperlink_num = std::min((int)flds.size() - 1, reco_item.content_ext_hyperlink_size());
  int count = 0;

  for (int i = 0; i < max_hyperlink_num; ++i) {
    content->append(flds[i]);
    content->append(base::StringPrintf("<!--{hyperlink:%d}-->", count));
    ++count;
  }

  for (int i = max_hyperlink_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }

  return true;
}

bool ItemHandler::ReplaceVotePlaceholder(const reco::RecoItem& reco_item, std::string* content) {
  if (reco_item.content_ext_vote_size() == 0) return true;
  std::vector<std::string> flds;
  base::SplitString(*content, "\4", &flds);
  content->clear();

  if ((int)flds.size() <= reco_item.content_ext_vote_size()) {
    LOG(WARNING) << "item id: " << reco_item.identity().item_id()
                 << "投票占位符不足, 占位符数: " << flds.size() - 1
                 << ", 投票数: " << reco_item.content_ext_vote_size();
  }

  int max_vote_num = std::min((int)flds.size() - 1, reco_item.content_ext_vote_size());
  int count = 0;

  for (int i = 0; i < max_vote_num; ++i) {
    content->append(flds[i]);
    content->append(base::StringPrintf("<!--{vote:%d}-->", count));
    ++count;
  }

  for (int i = max_vote_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }

  return true;
}

bool ItemHandler::ReplaceAudioPlaceholder(const reco::RecoItem& reco_item, std::string* content) {
  if (reco_item.audio_meta_settings_size() == 0) return true;

  std::vector<std::string> flds;
  base::SplitString(*content, "\5", &flds);
  content->clear();

  if ((int)flds.size() <= reco_item.audio_meta_settings_size()) {
    LOG(WARNING) << "item id: " << reco_item.identity().item_id()
                 << "超链接占位符不足, 占位符数: " << flds.size() - 1
                 << ", 超链接数: " << reco_item.audio_meta_settings_size();
  }

  int max_audio_num = std::min((int)flds.size() - 1, reco_item.audio_meta_settings_size());
  int count = 0;

  for (int i = 0; i < max_audio_num; ++i) {
    content->append(flds[i]);
    content->append(base::StringPrintf("<!--{audio:%d}-->", count));
    ++count;
  }

  for (int i = max_audio_num; i < (int)flds.size(); ++i) {
    content->append(flds[i]);
  }

  return true;
}

bool ItemHandler::ResetHumorItem(reco::RecoItem* reco_item) {
  if (reco_item->identity().type() != reco::kHumor) return true;

  std::string real_content = reco_item->content();
  extend::re3::Re3::GlobalReplace(&real_content, "<[[:ascii:]]+>", " ");
  real_content = nlp::util::NormalizeLine(real_content);

  if (reco_item->image_size() == 1) {
  } else if (!real_content.empty() && reco_item->image_size() == 0) {
    LOG(INFO) << "humor item, filter title, " << reco_item->identity().item_id();
    reco_item->mutable_title()->clear();
  } else if (real_content.empty() && reco_item->image_size() == 0) {
    LOG(INFO) << "humor item, invalid, " << reco_item->identity().item_id() << ":" << reco_item->content()
              << ":" << reco_item->content().size();
    return false;
  }

  return true;
}

bool ItemHandler::GetImageMeta(const reco::NewsImage& image, std::string* meta) {
  meta->clear();

  net::WebClient::Request* request = new net::WebClient::Request();
  net::WebClient::Response* response = new net::WebClient::Response();
  response->http_body = "";
  uint64 url_sign = base::CityHash64(image.url().c_str(), image.url().size());
  request->url = base::StringPrintf("%s?query=meta&id=%lu",
                                    FLAGS_image_meta_server_url_prefix.c_str(), url_sign);
  LOG(INFO) << "ori img url:" << image.url() << ", meta url:" << request->url;

  bool finish = false;
  Closure *done = NewCallback(&SingleHttpDone, request, response, &finish);
  image_reader_->AcquireHttpResult(*request, response, done);

  int loop_num = 0;
  while (!finish) {
    ++loop_num;
    base::SleepForMilliseconds(10);
    if (loop_num % 1000 == 0) {
      LOG(ERROR) << "image server doesn't response, url: " << request->url << ", loop times: " << loop_num;
    }
  }

  bool succ = false;
  if (!response->success) {
    LOG(WARNING) << "http get request fail, url: " << request->url;
  } else if (response->http_response_code != 200) {
    LOG(WARNING) << "can't find such image in image server, url: " << request->url
                 << ", response code: " << response->http_response_code
                 << ", response body:" << response->http_body;
  } else {
    *meta = response->http_body;
    succ = true;
  }

  delete request;
  delete response;

  return succ;
}


void ItemHandler::SingleHttpDone(net::WebClient::Request *request,
                                 net::WebClient::Response *response,
                                 bool* done) {
  *done = true;
}

bool ItemHandler::ParseImageMetaJson(const std::string& meta_json, wolong::image_base::ImageMeta* meta) {
  CHECK_NOTNULL(meta);
  json_error_t json_error;
  json_t *json = json_loads(meta_json.c_str(), &json_error);
  if (json == NULL) {
    LOG(WARNING) << "Failed to load line: " << json_error.line;
    return false;
  }
  // parse url sign
  json_t *para = json_object_get(json, "id");
  if (para == NULL || para->type != JSON_STRING) {
    LOG(WARNING) << "meta json object has no id, json: " << meta_json;
    return false;
  }
  uint64 id = 0u;
  if (!base::StringToUint64(json_string_value(para), &id)) {
    LOG(WARNING) << "parse image url sign fail, json: " << meta_json;
    return false;
  }
  meta->set_image_url_sign(id);
  // parse width
  para = json_object_get(json, "width");
  if (para == NULL || para->type != JSON_INTEGER) {
    LOG(WARNING) << "meta json object has no width, json: " << meta_json;
    return false;
  }
  meta->set_width(json_integer_value(para));
  // parse height
  para = json_object_get(json, "height");
  if (para == NULL || para->type != JSON_INTEGER) {
    LOG(WARNING) << "meta json object has no height, json: " << meta_json;
    return false;
  }
  meta->set_height(json_integer_value(para));
  // parse type
  para = json_object_get(json, "type");
  if (para != NULL && para->type == JSON_STRING) {
    std::string image_type = json_string_value(para);
    if (image_type == kGIFCompressShow) {
      meta->set_content_type(kGIFCompress);
    } else {
      meta->set_content_type(kJPGCompress);
    }
  } else {
    meta->set_content_type(kJPGCompress);
  }

  // parse timestamp
  // NOTE(jianhuang) no need, just skip
  meta->set_timestamp(0);

  json_decref(json);

  return true;
}

bool ItemHandler::UpdateSingleImageInfo(NewsImage* image, bool force_check_img) {
  bool succ = true;
  if (!image->has_title()) {
    image->set_title("");
  }
  if (!image->has_desc()) {
    image->set_desc("");
  }

  if (force_check_img || !IsImageValid(*image)) {
    int retry_times = kOfflineImageRequestRetryTimes;
    std::string meta;
    while (!GetImageMeta(*image, &meta)) {
      if (--retry_times <= 0)
        break;
      base::SleepForMilliseconds(kImageRequestMilliSeconds);
    }

    wolong::image_base::ImageMeta image_meta;
    if (!ParseImageMetaJson(meta, &image_meta)) {
      succ = false;
      LOG(WARNING) << "parse image meta fail, meta: " << meta << ", url: " << image->url();
      image->set_width(0);
      image->set_height(0);
    } else if (image_meta.has_is_disable() && image_meta.is_disable()) {
      succ = false;
      LOG(WARNING) << "image is disable, meta " << meta << ", url: "  << image->url();
      image->set_width(0);
      image->set_height(0);
    } else {
      image->set_width(image_meta.width());
      image->set_height(image_meta.height());
      if (image_meta.has_content_type() && image_meta.content_type() == kGIFCompress) {
        image->set_type(kGIFCompressShow);
      } else {
        image->set_type(kJPGCompressShow);
      }
    }
  }

  return succ;
}

bool ItemHandler::GetUpdatedRecoItem(uint64 item_id, reco::RecoItem* reco_item) {
  if (!reco::doc::DataMgr::instance().doc_storage->GetRecoItemFromDB(item_id, reco_item)) {
    return false;
  }
  if (!UpdateRecoItem(reco_item, NULL)) {
    return false;
  }

  return true;
  //  return ItemHandler::UpdateRawItem(*reco_item, reco_item->mutable_raw_item(), NULL);
}
}
}
