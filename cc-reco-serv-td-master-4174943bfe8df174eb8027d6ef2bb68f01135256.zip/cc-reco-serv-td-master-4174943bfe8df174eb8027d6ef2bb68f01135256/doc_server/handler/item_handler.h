#pragma once

#include <string>
#include <vector>

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/image_base.pb.h"
#include "serving_base/http_communicator/http_communicator.h"


namespace reco {
namespace doc {
enum RecoItemInvalidReason {
  kNoReasonForInvalid,
  kDeliverIt,
  kNotDeliver,
  kImageMissing,
  kPlaceholderErr
};

enum ImageCompressType {
  kJPGCompress = 0,
  kGIFCompress = 1,
  kMP4 = 100
};


class ItemHandler {
 public:
  static void Initialize();

  static void Destructor();
  // 每次获取文档实时更新
  /*
  static bool UpdateRawItem(const RecoItem& reco_item,
                            RawItem* raw_item,
                            RawItemInvalidReason* invalid_reason);
  */

  static bool UpdateRecoItem(RecoItem* reco_item, RecoItemInvalidReason* invalid_reason);

  // static bool UpdateRawItem(RawItem* raw_item, RawItemInvalidReason* invalid_reason);
  // 入库时的更新
  static bool UpdateRawItemImageInfo(reco::RawItem* raw_item);

  static bool UpdateRecoItemImageInfo(reco::RecoItem* reco_item, bool force_check_img = false);

  static bool IsImageValid(const reco::NewsImage& image);

  static bool IsEmoticon(const reco::NewsImage& iamge);

  static bool GetUpdatedRecoItem(uint64 item_id, reco::RecoItem* reco_item);

 private:
  // for UpdateRawItem
  /*
  static void UpdateImagesUrl(reco::RawItem* raw_item,
                           std::vector<reco::NewsImage*>* images,
                           RawItemInvalidReason* invalid_reason);
  */

  static bool IsSpecialItem(reco::ItemType item_type);

  static void UpdateContent(uint64 item_id, std::string orign_content, std::string* ret_content);

  /*
  static bool ResetHumorItem(reco::RawItem* raw_item);
  static void ReplacePlaceholder(reco::RawItem* raw_item, RawItemInvalidReason* invalid_reason);
  static bool ReplaceImagePlaceholder(reco::RawItem* item, std::string* content);
  static bool ReplaceVideoPlaceholder(const reco::RawItem& raw_item, std::string* content);
  static bool ReplaceCharacterPlaceholder(const reco::RawItem& item, std::string* content);
  static bool ReplaceHyperLinkPlaceholder(const reco::RawItem& item, std::string* content);
  static bool ReplaceVotePlaceholder(const reco::RawItem& item, std::string* content);
  static bool ReplaceAudioPlaceholder(const reco::RawItem& item, std::string* content);
  */

  // for update reco item
  static void UpdateImagesUrl(reco::RecoItem* reco_item,
                           std::vector<reco::NewsImage*>* images,
                           RecoItemInvalidReason* invalid_reason);

  static void ReplacePlaceholder(reco::RecoItem* reco_item, RecoItemInvalidReason* invalid_reason);

  static bool ReplaceImagePlaceholder(reco::RecoItem* reco_item, std::string* content);

  static bool ReplaceVideoPlaceholder(const reco::RecoItem& reco_item, std::string* content);

  static bool ReplaceCharacterPlaceholder(const reco::RecoItem& reco_item, std::string* content);

  static bool ReplaceHyperLinkPlaceholder(const reco::RecoItem& reco_item, std::string* content);

  static bool ReplaceVotePlaceholder(const reco::RecoItem& item, std::string* content);

  static bool ReplaceAudioPlaceholder(const reco::RecoItem& reco_item, std::string* content);


  static bool ResetHumorItem(reco::RecoItem* reco_item);

  // for UpdateImageInfo
  static bool GetImageMeta(const reco::NewsImage& image, std::string* meta);

  static void SingleHttpDone(net::WebClient::Request *request,
                             net::WebClient::Response *response,
                             bool* done);

  static bool ParseImageMetaJson(const std::string& meta_json, wolong::image_base::ImageMeta* meta);

  static bool UpdateSingleImageInfo(NewsImage* image, bool force_check_img = false);

 private:
  static const int kMaxPicNum = 200;
  // 图片请求重试等待时间
  static const int kImageRequestMilliSeconds = 5;
  // 离线图片请求重试次数
  static const int kOfflineImageRequestRetryTimes = 5;
  // 两种图片类型
  static const char* kGIFCompressShow;
  static const char* kJPGCompressShow;

  static serving_base::HttpCommunicator* image_reader_;
};
}
}
