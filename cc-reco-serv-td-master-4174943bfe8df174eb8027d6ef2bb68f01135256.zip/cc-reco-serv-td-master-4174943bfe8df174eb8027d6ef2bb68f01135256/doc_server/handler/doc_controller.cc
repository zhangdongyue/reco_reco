#include "reco/serv/doc_server/handler/doc_controller.h"

#include "nlp/common/nlp_util.h"
#include "reco/serv/doc_server/handler/global_data.h"
#include "reco/serv/doc_server/handler/item_handler.h"
#include "reco/bizc/proto/doc.pb.h"
#include "reco/serv/doc_server/handler/data_manager.h"

namespace reco {
namespace doc {
DEFINE_int64_counter(doc, redis_hit_num, 0, "");
DEFINE_int64_counter(get_doc, request_item_num, 0, "请求 doc 总数");
DEFINE_int64_counter(get_doc, error_item_num, 0, "取不到 doc 总数");

DECLARE_bool(is_readonly);

void DocController::GetItemDocInfo(const ItemDocRequest *request, ItemDocResponse *response) {
  bool success = true;
  int error_num = 0;
  GetDocType get_doc_type = kGetDocNoDrop;

  if (request->item_id_size() > 1) {
    get_doc_type = kGetDocRealTime;
  }

  for (int i = 0; i < request->item_id_size(); ++i) {
    const uint64 item_id = request->item_id(i);

    // last_reco_item 已提前加入列表，如果获取失败需通过 response->mutable_reco_item()->RemoveLast(); 移除
    auto last_reco_item = response->add_reco_item();

    if (reco::doc::DataMgr::instance().doc_storage->GetRecoItemFromCache(item_id, last_reco_item)) {
      COUNTERS_doc__redis_hit_num.Increase(1);
    } else if (IsDropReadDB(get_doc_type)) {
      response->mutable_reco_item()->RemoveLast();
      if (!FLAGS_is_readonly) {
        reco::doc::DataMgr::instance().sync_to_cache_queue.Put(item_id);
      }
      ++error_num;
      success = false;
    } else if (ItemHandler::GetUpdatedRecoItem(item_id, last_reco_item)) {
      if (!FLAGS_is_readonly) {
        last_reco_item->clear_raw_item();
        reco::doc::DataMgr::instance().doc_storage->SaveRecoItemToCache(*last_reco_item);
      }
    } else {
      last_reco_item->Clear();
      response->mutable_reco_item()->RemoveLast();
      ++error_num;
      success = false;
      LOG(WARNING) << "get reco item fail:" << item_id;
    }
  }

  response->set_success(success);
  COUNTERS_get_doc__request_item_num.Increase(request->item_id_size());
  COUNTERS_get_doc__error_item_num.Increase(error_num);
}

void DocController::GetRecoItemInfo(const RecoItemRequest *request, RecoItemResponse *response) {
  bool success = true;
  for (int i = 0; i < request->item_id_size(); ++i) {
    RecoItem reco_item;
    if (reco::doc::DataMgr::instance().doc_storage->GetRecoItemFromDB(request->item_id(i), &reco_item)) {
      // VLOG(3) << reco_item.raw_item().Utf8DebugString();
      if (request->clear_raw_item()) {
        reco_item.clear_raw_item();
      }
      response->add_item()->CopyFrom(reco_item);
    } else {
      success = false;
    }
  }
  response->set_success(success);

  if (success) {
    LOG(INFO) << "get succ, return doc num: " << response->item_size();
  } else {
    LOG(WARNING) << "get fail, request: " << nlp::util::NormalizeLine(request->Utf8DebugString())
                 << ", response: " << nlp::util::NormalizeLine(response->Utf8DebugString());
  }
}

void DocController::GetSimItemImageList(const SimItemImageRequest *request, SimItemImageResponse *response) {
  LOG(ERROR) << "call discard rpc";
  response->Clear();
  return;

  /*
  for (int i = 0; i < request->item_id_size(); ++i) {
    if (response->image_size() >= request->image_return_num()) break;

    reco::RecoItem reco_item;
    if (!reco::doc::DataMgr::instance().doc_storage->GetRecoItemFromDB(request->item_id(i), &reco_item)) continue;

    ItemHandler::UpdateRawItemImageInfo(reco_item.mutable_raw_item());
    const reco::RawItem& raw_item = reco_item.raw_item();
    for (int j = 0; j < raw_item.image_size(); ++j) {
      if (response->image_size() >= request->image_return_num()) break;

      if (!ItemHandler::IsImageValid(raw_item.image(j))
          || ItemHandler::IsEmoticon(raw_item.image(j))) continue;

      response->add_image()->CopyFrom(raw_item.image(j));
    }
  }

  LOG(INFO) << "GetSimItemImageList succ, return image num: " << response->image_size();
  */
}

void DocController::UpdateRawItemDocInfo(const UpdateRawItemDocRequest *request,
                                         UpdateRawItemDocResponse *response) {
  LOG(ERROR) << "call discard rpc";

  auto raw_item = response->mutable_item();
  raw_item->CopyFrom(request->item());
  //  ItemHandler::UpdateRawItemImageInfo(raw_item);
  //  ItemHandler::UpdateRawItem(raw_item, NULL);
  response->set_success(true);

  //  VLOG(2) << "return item: " << response->item().Utf8DebugString();
}

void DocController::UpdateDBRecoItem(const UpdateDBRecoItemRequest *request,
                                     UpdateDBRecoItemResponse *response) {
  LOG(ERROR) << "call discard rpc";
  response->Clear();
  return;
}

bool DocController::IsDropReadDB(GetDocType get_doc_type) {
  if (kGetDocNoDrop == get_doc_type) {
    return false;
  }

  auto system_counter = reco::doc::DataMgr::instance().system_counter;
  switch (system_counter->GetDegree()) {
    case kSysFree:
      return false;
    case kSysNormal:
      return random_.GetInt(0, 99) < 10;
    case kSysBusy:
      return random_.GetInt(0, 99) < 50;
    case kSysFull:
      return random_.GetInt(0, 99) < 80;
  }
  return false;
}
}
}
