#pragma once

//#include <atomic>
#include <unordered_set>
#include <unordered_map>

#include "base/thread/thread.h"
#include "base/thread/thread_pool.h"
#include "base/testing/gtest_prod.h"
#include "serving_base/expiry_map/expiry_map.h"

#include "serving_base/expiry_map/expiry_map.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/reco_doc_server.pb.h"
#include "reco/serv/doc_server/handler/item_handler.h"


namespace reco {
namespace doc {
class DocSyncMgr {
 public:
  DocSyncMgr();
  ~DocSyncMgr();
  void Start();
  void Stop();

  // 负责从队列中获取 reco item 数据，填充到正排中
  void LoopAdd();

  void LoopMissImageUpdate();

  // 强制刷新本地 cache
  void LoopRefresh();

  void LoopSyncToCache();

 private:
  //  LoopUpdate 多线程同步
  bool NeedUpdate(uint64 item_id, bool use_kafka_offset, int64 kafka_offset);
  
  // 更新 reco_item 并且写入数据库
  void UpdateImageInfo(RecoItem* reco_item, bool force_check_img = false);

  // 添加一条 reco item 数据, 返回 true 表示不需要在处理，返回 false 表示可以重试
  bool AddDoc(const RecoItem& reco_item, bool use_kafka_offset, int64 kafka_offset);

  // 添加一条 raw item 数据，直到成功才返回
  void AddDocUntilSucc(const RecoItem& reco_item, bool use_kafka_offset, int64 kafka_offset);

  // 添加到缺图检查队列
  void AddMissImageQueue(uint64 item_id);

  void AddMissImageQueue(const UpdateItemMsg& msg);

  // 记录 doc 信息到 elk
  void TrackRecoItem(const reco::RecoItem& reco_item, RecoItemInvalidReason reason);

  // clear local cache
  bool AddToRefreshQueue(uint64 item_id);

/*  // item keeper
  bool SetupConnItemKeeper();
  bool WriteFeedbackToItemKeeper(const uint64 item_id,
                                 const bool is_valid,
                                 const bool exclude_reco_mq);
*/
 private:
  std::atomic_bool thread_stop_;
  thread::ThreadPool update_thread_pool_;
  thread::ThreadPool refresh_thread_;
  thread::Thread miss_image_update_thread_;
  thread::Thread sync_to_cache_thread_;

  // register update
  mutable thread::Mutex register_mutex_;
  // std::unordered_set<uint64> register_set_;

  mutable thread::Mutex add_doc_mutex_;
  serving_base::ExpiryMap<uint64, int64>* item_kafka_offset_;
  // mem leak
  // std::unordered_map<uint64, int64> item_kafka_offset_;

  FRIEND_TEST(DocServerTest, sync_mgr);
};
}
}
