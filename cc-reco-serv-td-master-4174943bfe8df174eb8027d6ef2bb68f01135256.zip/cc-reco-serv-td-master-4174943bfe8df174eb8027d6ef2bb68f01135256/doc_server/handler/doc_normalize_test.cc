#include "reco/serv/doc_server/handler/doc_normalize.h"

#include <set>

#include "base/file/dir_reader_posix.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_util.h"
#include "base/strings/utf_codepage_conversions.h"
#include "base/random/pseudo_random.h"
#include "base/common/logging.h"
#include "base/testing/gtest.h"

#include "extend/multi_strings/multi_pattern_matcher.h"
#include "extend/static_dict/dawg/dictionary.h"
#include "extend/static_dict/dawg/dawg-builder.h"
#include "extend/static_dict/dawg/dictionary-builder.h"

namespace reco {

namespace doc {

TEST(NormalizeLine, OneLineAPIs) {
  struct Cases {
    const char* orig_text;
    const char* normalized;
  } cases[] = {
    {" \t\n \r \1 \3 AB１２３４５６　ａｂｃ \t \r \2", "\1 AB１２３４５６ ａｂｃ \2"},
    {"新华网上海８月１２日电（记者有之炘）今年以来", "新华网上海８月１２日电（记者有之炘）今年以来"},
    // 边界条件
    {"   ", ""},
    {" \t\n \r \1 \3 \t \r \2", "\1 \2"},
    {" \t\n \r \3 \t \r", ""},
    {"    巴萨在     瓜迪奥拉强调", "巴萨在 瓜迪奥拉强调"},  // 0x00A0 的空格
    {"  全本【加入书签】上一页返回目录下一页返回介绍页推荐本书我的藏书阁    看书小技巧:直接点键盘上的左右",
     "全本【加入书签】上一页返回目录下一页返回介绍页推荐本书我的藏书阁 看书小技巧:直接点键盘上的左右"}, // 160 的空格 // NOLINT
  };

  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(cases); ++i) {
    // 将 cases 中的内容 copy 出来 （否则下面的 api 会改写常量所在的内存空间
    std::string str1 = cases[i].orig_text;
    NormalizeLineInPlaceS(&str1);
    std::string str2 = NormalizeLine(cases[i].orig_text);
    EXPECT_EQ(str1, std::string(cases[i].normalized)) << str1;
    EXPECT_EQ(str2, std::string(cases[i].normalized));
  }
}

TEST(NormalizeLine, OneLineAppend) {
  struct Cases {
    const char* orig_text;
    const char* normalized;
  } cases[] = {
    {"AB１２３４５６　ａｂｃ", "AB１２３４５６ ａｂｃ"},
    {"AB１２３４５６　\n \r \tａ\tｂ\r\nｃ", "AB１２３４５６ ａ ｂ ｃ"},
    {"AB１２有一段中文５６　\n \r \tａ 看看是\tｂ\r啥样子\n\tｃ",
      "AB１２有一段中文５６ ａ 看看是 ｂ 啥样子 ｃ"},
    {"AB１２ \1 \n \r \tａ ", "AB１２ \1 ａ"},
    // 首尾空字符
    {"  AB１２３４５６　ａｂｃ ", "AB１２３４５６ ａｂｃ"},
    {" \t\n \r \1 \3 AB１２３４５６　ａｂｃ \t \r \2", "\1 AB１２３４５６ ａｂｃ \2"},
    // 边界条件
    {"   ", ""},
    {" \t\n \r \1 \3 \t \r \2", "\1 \2"},
    {" \t\n \r \3 \t \r ", ""},
  };
  std::string final;
  std::string ground_truth;
  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(cases); ++i) {
    std::string str1 = cases[i].orig_text;
    NormalizeLineAppend(str1, &final);
    ground_truth += std::string(cases[i].normalized);
  }
  ASSERT_EQ(final, ground_truth);
}

TEST(NormalizeLine, MultiLinesAPIs) {
  struct Cases {
    const char* orig_text;
    const char* normalized;
  } cases[] = {
    {"AB１２３４５６　\n \r \tａ\tｂ\r\nｃ", "AB１２３４５６\nａ ｂ\nｃ"},
    {"AB１２有一段中文５６　\n \r \tａ 看看是\tｂ\r啥样子\n\tｃ",
      "AB１２有一段中文５６\nａ 看看是 ｂ 啥样子\nｃ"},
    {"AB１２ \1 \n \r \tａ \n", "AB１２ \1\nａ\n"},
    // 对单行文本的兼容性
    {"AB１２３４５６　ａｂｃ", "AB１２３４５６ ａｂｃ"},
    {"abcd", "abcd"},
    {"abcd\n", "abcd\n"},
    // 去除空行
    {"\nabcd\n", "abcd\n"},
    // 边界条件
    {"   ", ""},
    {" \t\n \r \1 \3 \t \n \2", "\1\n\2"},
    {" \t\n \r \3 \t \r ", ""},
    {"\n \n\n\n \r\t", ""}
  };
  for (size_t i = 0; i < ARRAYSIZE_UNSAFE(cases); ++i) {
    std::string str1 = cases[i].orig_text;
    NormalizeMultiLinesInPlaceS(&str1);
    std::string str2 = NormalizeMultiLines(cases[i].orig_text);
    EXPECT_EQ(str1, std::string(cases[i].normalized));
    EXPECT_EQ(str2, std::string(cases[i].normalized));
  }
}

TEST(NormalizeLine, RandomData) {
  base::PseudoRandom random;
  std::string line;
  for (int i = 0; i < 100000; ++i) {
    line += char(random.GetInt(1, 256)); // NOLINT
  }
  NormalizeLine(line);
  NormalizeMultiLines(line);
}

TEST(NormalizeLine, NullEnd) {
  std::string line = "abcdefg";
  line[3] = 0;
  std::string line2 = line;
  // 对于字符串中有 \0 的情况， NormalizeLine 的行为，取决于 NormalizeLine
  // 的参数 Slice 的构造方式 如果是以 string 构造的，由于传入的 size 是包涵 \0
  // 所在的那段内存的， \0 会作为不可见字符被 NormalizeLine 过滤 如果是以 const
  // char* 构造的，由于传入的 size 不包括 \0 ， \0 会作为处理的结束符
  ASSERT_EQ(NormalizeLine(line), "abcefg");
  ASSERT_EQ(NormalizeLine(line2.c_str()), "abc");
}

TEST(NormalizeLine, Invisible) {
  std::string line = "\x16\x16\x16\x16\x16\x16\x16\x16\x16\x16";
  ASSERT_TRUE(NormalizeLine(line).empty());
}

}  // namespace util
}  // namespace nlp
