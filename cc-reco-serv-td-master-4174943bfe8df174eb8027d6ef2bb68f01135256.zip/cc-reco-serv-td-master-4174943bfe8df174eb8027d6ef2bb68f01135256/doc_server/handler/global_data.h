#pragma once

#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "reco/serv/doc_server/handler/doc_sync_mgr.h"

DECLARE_int32(work_thread_num);
namespace reco {
namespace doc {
struct GlobalData {
  ::thread::ThreadPool *work_thread_pool;
  std::atomic_bool thread_pool_enable;
  reco::doc::DocSyncMgr doc_sync_mgr;

  GlobalData() : work_thread_pool(NULL), thread_pool_enable(false) {}

  ~GlobalData() {}

  void Init();

  void Stop();

  bool IsThreadPoolEnabled();

  void StopThreads();
};

} // namespace doc
} // namespace reco
