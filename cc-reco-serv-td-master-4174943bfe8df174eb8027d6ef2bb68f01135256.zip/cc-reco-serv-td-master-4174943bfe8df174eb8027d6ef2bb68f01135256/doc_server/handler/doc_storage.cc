#include "reco/serv/doc_server/handler/doc_storage.h"

#include <utility>
#include <string>
#include <vector>

#include "serving_base/utility/timer.h"
#include "reco/bizc/proto/reco_doc_server.pb.h"
#include "base/strings/string_number_conversions.h"
#include "reco/serv/doc_server/handler/item_handler.h"

#define SYNC_ITEM(name) \
    if (reco_item->raw_item().has_##name()) reco_item->set_##name(reco_item->raw_item().name());

#define SYNC_ITEM2(name) \
    if (reco_item->raw_item().has_##name()) \
reco_item->mutable_##name()->CopyFrom(reco_item->raw_item().name());

#define SYNC_ITEM_REP(name) \
    reco_item->mutable_##name()->CopyFrom(reco_item->raw_item().name());

namespace reco {
namespace doc {
DEFINE_bool(enable_cache, false, "if use cache");
DEFINE_int32(cache_max_key_num, 500000, "");
DEFINE_int32(cache_expire_seconds, 600, "cache expire seconds");
DEFINE_int32(cache_slice_num, 20, "");
DEFINE_string(redis_key_prefix, "doc_reco_", "reco key's prefix in redis");

DEFINE_string(aero_ips, "127.0.0.1:3000", "");
DEFINE_string(doc_aero_ns, "test", "test");
DEFINE_string(doc_aero_set, "doc_server", "doc server aero field name");

DEFINE_int64_counter(doc, aero_op_num, 0, "");
DEFINE_int64_counter(doc, local_cache_hit_num, 0, "");
DEFINE_int64_counter(doc, local_cache_total, 0, "");

const char* DocStorage::kAeroColumn = "data";

DocStorage::DocStorage() : redis_(reco::redis::FLAGS_redis_pool_ips), aero_client_(FLAGS_aero_ips) {
  reco_cache_.resize(FLAGS_cache_slice_num, NULL);
  if (FLAGS_enable_cache) {
    for (auto i = 0u; i < reco_cache_.size(); ++i) {
      reco_cache_[i] = new base::LRUCache<uint64, std::pair<std::string, int64>>(FLAGS_cache_max_key_num / FLAGS_cache_slice_num, true); // NOLINT
    }
  }
}

DocStorage::~DocStorage() {
  for (auto i = 0u; i < reco_cache_.size(); ++i) {
    if (reco_cache_[i]) {
      delete reco_cache_[i];
      reco_cache_[i] = NULL;
    }
  }

  reco_cache_.clear();
}

bool DocStorage::GetRecoItemFromDB(uint64 item_id, reco::RecoItem* reco_item) {
  std::string value;
  if (!ReadAero(base::Uint64ToString(item_id), &value)) {
    LOG(WARNING) << "can't find item from aero, item: " << item_id;
    return false;
  }

  if (!reco_item->ParseFromString(value)) {
    LOG(ERROR) << "parse reco item error, item: "
               << item_id << ", info:" << reco_item->InitializationErrorString();
    return false;
  }

  if (reco_item->has_raw_item()) {
    SYNC_ITEM(is_valid);
    SYNC_ITEM(original_url);
    SYNC_ITEM(oper_url);
    SYNC_ITEM(source);
    SYNC_ITEM(orig_source);
    SYNC_ITEM(attribute);
    SYNC_ITEM(original_id);
    SYNC_ITEM(title);
    SYNC_ITEM(content);
    SYNC_ITEM(is_webview);
    SYNC_ITEM(is_daoliu);
    SYNC_ITEM(summary);
    SYNC_ITEM_REP(image);
    SYNC_ITEM(sub_title);
    SYNC_ITEM(expire_time);
    SYNC_ITEM(create_time);
    SYNC_ITEM(publish_time);
    SYNC_ITEM(spider_region);
    SYNC_ITEM2(gaode_poi);
    SYNC_ITEM(priority);
    SYNC_ITEM_REP(category);
    // SYNC_ITEM(is_category_manual);
    SYNC_ITEM_REP(channel_id);
    SYNC_ITEM_REP(priority_info);
    SYNC_ITEM(simhash);
    SYNC_ITEM_REP(paragraph_simhash);
    SYNC_ITEM(is_clickable_url);
    SYNC_ITEM(source_media);
    SYNC_ITEM(orig_source_media);
    SYNC_ITEM(source_media_type);
    SYNC_ITEM(orig_source_media_type);
    SYNC_ITEM(parent_url);
    SYNC_ITEM_REP(thumbnail);
    SYNC_ITEM_REP(show_tag);
    SYNC_ITEM_REP(query_tag);
    SYNC_ITEM_REP(spider_tags);
    SYNC_ITEM(enter_desc);
    SYNC_ITEM2(uc_browser_deliver_setting);
    SYNC_ITEM2(uc_browser_display_setting);
    SYNC_ITEM_REP(video_meta_settings);
    SYNC_ITEM_REP(content_ext_hyperlink);
    SYNC_ITEM_REP(content_ext_vote);
    SYNC_ITEM_REP(content_ext_character);
    SYNC_ITEM(third_party_url);
    SYNC_ITEM(show_source);
    SYNC_ITEM(hit_forbidden);
    SYNC_ITEM(has_reviewed);
    SYNC_ITEM_REP(appname_filters);
    SYNC_ITEM(filtered_app_names);
    SYNC_ITEM2(quality_attr);
    SYNC_ITEM2(content_attr);
    SYNC_ITEM2(video_attr);
    SYNC_ITEM(dao_liu_url_is_ok);
    SYNC_ITEM(show_impression_url);
    SYNC_ITEM(predict_article_bytes);
    SYNC_ITEM(has_merged);
    SYNC_ITEM2(tag);
    SYNC_ITEM_REP(audio_meta_settings);
    SYNC_ITEM(job_uuid);
    SYNC_ITEM2(time_axis_results);
    SYNC_ITEM2(video_storage_info);
    SYNC_ITEM2(question_info);
    SYNC_ITEM(video_outer_link_status);
    SYNC_ITEM(sensitive_word);
    SYNC_ITEM(query);
    SYNC_ITEM(parent_id);
  }

  return true;
}

int DocStorage::SaveRecoItemToDB(const RecoItem& reco_item) {
  std::string value;
  if (!reco_item.SerializeToString(&value)) {
    LOG(ERROR) << "pb serialize fail, item:" << reco_item.identity().item_id()
               << ", info:" << reco_item.InitializationErrorString();
    return 1;
  }

  if (!WriteAero(base::Uint64ToString(reco_item.identity().item_id()), value)) {
    LOG(ERROR) << "Write to aero db fail. itemid:" << reco_item.identity().item_id();
    return 2;
  }

  return 0;
}

bool DocStorage::GetRecoItemFromCache(uint64 item_id, RecoItem* reco_item) {
  // 1: local cache
  const int64 cur_timestamp = base::GetTimestamp();
  const uint32 cache_idx = item_id % reco_cache_.size();
  std::pair<std::string, int64> cache_value;

  if (reco_cache_[cache_idx] && reco_cache_[cache_idx]->Get(item_id, &cache_value)) {
    if (cur_timestamp - cache_value.second <= FLAGS_cache_expire_seconds * 1e6) {
      COUNTERS_doc__local_cache_hit_num.Increase(1);
      return reco_item->ParseFromString(cache_value.first);
    }
  }

  // 2: redis cache
  std::string value;
  const std::string redis_key = FLAGS_redis_key_prefix + base::Uint64ToString(item_id);
  if (0 == redis_.Get(redis_key, &value)) {
    // write local cache
    if (reco_cache_[cache_idx]) {
      reco_cache_[cache_idx]->Add(item_id, std::make_pair(value, cur_timestamp));
      COUNTERS_doc__local_cache_total.Reset(reco_cache_[cache_idx]->size() * FLAGS_cache_slice_num);
    }

    return reco_item->ParseFromString(value);
  }

  LOG(WARNING) << "get reco cache fail, id:" << item_id;
  return false;
}

bool DocStorage::SaveRecoItemToCache(const RecoItem& reco_item) {
  std::string value;
  if (!reco_item.SerializeToString(&value)) {
    LOG(WARNING) << "parse reco item fail.";
    return false;
  }

  auto item_id = reco_item.identity().item_id();
  const uint32 cache_idx = item_id % reco_cache_.size();

  // 1: local cache
  if (reco_cache_[cache_idx]) {
    reco_cache_[cache_idx]->Add(item_id, std::make_pair(value, base::GetTimestamp()));
  }

  // 2: redis cache
  const std::string redis_key = FLAGS_redis_key_prefix + base::Uint64ToString(item_id);
  if (!redis_.SetEx(redis_key, value)) {
    LOG(WARNING) << "set redis reco data error, key is:" << redis_key;
    return false;
  }

  return true;
}

void DocStorage::ClearLocalCache(uint64 item_id) {
  const uint32 cache_idx = item_id % reco_cache_.size();
  if (reco_cache_[cache_idx]) {
    reco_cache_[cache_idx]->Remove(item_id);
  }
}

bool DocStorage::ClearCacheData(const uint64 item_id) {
  // 1: local cache
  ClearLocalCache(item_id);

  // 2: redis cache
  const std::string redis_reco_key = FLAGS_redis_key_prefix + base::Uint64ToString(item_id);
  if (!redis_.Del(redis_reco_key)) {
    LOG(WARNING) << "del reco key fail, key:" << redis_reco_key;
    return false;
  }

  return true;
}

bool DocStorage::ReadAero(const std::string& key, std::string* value) {
  std::vector<std::string> bins;
  bins.push_back(kAeroColumn);

  std::vector<std::string> values;
  int retry_cnt = kAeroRetryCnt;
  while (retry_cnt-- > 0) {
    if (aero_client_.GetData(key, bins, &values, FLAGS_doc_aero_ns, FLAGS_doc_aero_set)
        && !values.empty() && !values[0].empty()) {
      break;
    }
  }

  if (retry_cnt < 0) {
    DLOG(INFO) << "no such value, key: " << key << ", table: " << FLAGS_doc_aero_set;
    return false;
  }

  *value = values[0];
  return true;
}

bool DocStorage::WriteAero(const std::string& key, const std::string& value) {
  int retry_cnt = kAeroRetryCnt;
  while (retry_cnt-- > 0) {
    if (aero_client_.SetData(key, kAeroColumn, value, FLAGS_doc_aero_ns, FLAGS_doc_aero_set)) {
      return true;
    }
  }
  return false;
}
}
}
