#include <iostream>
#include <fstream>

#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/file/file_util.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "serving_base/utility/time_helper.h"

#include "client_pool/ArpcClientPool.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto_arpc/reco_doc_server.pb.h"

DEFINE_string(doc_server_ip, "127.0.0.1", "doc server ip");
DEFINE_int32(doc_server_port, 20013, "doc server port");
DEFINE_string(request_type, "updated_reco_item", "updated_reco_item, DB_reco_item or all");
DEFINE_string(cmp_doc_server_ip, "127.0.0.1", "compare doc server ip");
DEFINE_bool(is_compare, false, "is compare");
DEFINE_uint64(item_id, 0, "");
DEFINE_string(item_id_file, "", "the item id file");

using namespace arpc_client_pool::client_pool;

bool GetUpdateRecoItemInfo(uint64 id, reco::RecoItem* reco_item = NULL, bool is_compare_ip = false) {
  std::string ip = is_compare_ip?FLAGS_cmp_doc_server_ip:FLAGS_doc_server_ip;

  PoolParams params;
  params.clientCount = 10;
  params.connectTimeout = 200;

  std::set<StubInfo> stub_info;
  stub_info.insert(StubInfo(ip, FLAGS_doc_server_port));

  ArpcClientPool<reco::docserver::RecoDocService_Stub> conn_pool;
  if (!conn_pool.init(params, stub_info)) {
    LOG(FATAL) << "conn pool fail:" << FLAGS_doc_server_ip;
  }

  reco::doc::ItemDocRequest req;
  reco::doc::ItemDocResponse resp;
  req.add_item_id(id);

  auto stub_ptr = conn_pool.get();
  arpc::ANetRPCController cntler;
  stub_ptr->stub()->GetItemDocInfo(&cntler, &req, &resp, NULL);
  int err_code = cntler.GetErrorCode();
  if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
    LOG(ERROR) << "rpc fail:" << err_code;
    return false;
  }

  if (!FLAGS_is_compare) {
    LOG(ERROR) << "updated reco_item, request: " << req.Utf8DebugString()
               << "\n response: " << resp.Utf8DebugString();
  }
  if (reco_item != NULL) {
    reco_item->CopyFrom(resp.reco_item(0));
  }
  return true;
}

bool GetDBRecoItemInfo(uint64 id, reco::RecoItem* reco_item = NULL, bool is_compare_ip = false) {
  std::string ip = is_compare_ip?FLAGS_cmp_doc_server_ip:FLAGS_doc_server_ip;

  PoolParams params;
  params.clientCount = 10;
  params.connectTimeout = 200;

  std::set<StubInfo> stub_info;
  stub_info.insert(StubInfo(ip, FLAGS_doc_server_port));
  ArpcClientPool<reco::docserver::RecoDocService_Stub> conn_pool;
  if (!conn_pool.init(params, stub_info)) {
    LOG(FATAL) << "conn pool fail:" << FLAGS_doc_server_ip;
  }

  reco::doc::RecoItemRequest req;
  reco::doc::RecoItemResponse resp;
  req.add_item_id(id);
  req.set_clear_raw_item(false);

  auto stub_ptr = conn_pool.get();
  arpc::ANetRPCController cntler;
  stub_ptr->stub()->GetRecoItemInfo(&cntler, &req, &resp, NULL);
  int err_code = cntler.GetErrorCode();
  if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
    LOG(ERROR) << "request DB reco item info failed. ";
    return false;
  }

  if (!FLAGS_is_compare) {
    LOG(ERROR) << "DB reco_item, request: " << req.Utf8DebugString()
               << "\n response: " << resp.Utf8DebugString();
  }
  if (reco_item != NULL) {
    reco_item->CopyFrom(resp.item(0));
  }
  return true;
}
/*
void UpdateDBRecoItemTest(uint64 id) {
  reco::RecoItem item;
  bool is_reco_item_ok = false;
  {
    net::rpc::RpcClientChannel channel(FLAGS_doc_server_ip.c_str(), FLAGS_doc_server_port);
    CHECK(channel.Connect());
    reco::docserver::RecoDocService::Stub stub(&channel);

    reco::docserver::RecoItemRequest request;
    reco::docserver::RecoItemResponse response;
    request.add_item_id(id);
    request.set_clear_raw_item(false);

    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(5);
    stub.GetRecoItemInfo(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << "request doc info failed. ";
    }
    else {
      item = response.item(0);
      is_reco_item_ok = true;
    }
  }

  if (is_reco_item_ok) {
    net::rpc::RpcClientChannel channel(FLAGS_doc_server_ip.c_str(), FLAGS_doc_server_port);
    CHECK(channel.Connect());
    reco::docserver::RecoDocService::Stub stub(&channel);

    reco::docserver::UpdateDBRecoItemRequest request;
    reco::docserver::UpdateDBRecoItemResponse response;
    *request.add_item() = item;
    CHECK(channel.Connect());

    net::rpc::RpcClientController rpc;
    rpc.SetDeadline(5);
    stub.UpdateDBRecoItem(&rpc, &request, &response, NULL);
    rpc.Wait();
    LOG(ERROR) << "test UpdateDBRecoItem";

    if (rpc.status() != net::rpc::RpcClientController::kOk) {
      LOG(ERROR) << "UpdateDBRecoItem failed, rpc status: " << rpc.status();
    } else {
      LOG(ERROR) << "UpdateDBRecoItem success";
    }
  }
}
*/
bool TestRpc(uint64 item_id) {
  if (FLAGS_request_type == "updated_reco_item") {
    reco::RecoItem reco_item;
    bool bret = GetUpdateRecoItemInfo(item_id, &reco_item);
    if (FLAGS_is_compare && bret) {
      reco::RecoItem cmp_reco_item;
      bret = GetUpdateRecoItemInfo(item_id, &cmp_reco_item, true);
      if (!bret) {
        LOG(ERROR) << "compare updated reco item failed, miss: " << item_id;
      } else {
        //  reco_item proto 中已注释掉 update_timestamp
        //  cmp_reco_item.set_update_timestamp(reco_item.update_timestamp());
        std::string str1 = reco_item.Utf8DebugString();
        std::string str2 = cmp_reco_item.Utf8DebugString();
        if (str1 != str2) {
          LOG(ERROR) << "compare updated reco item failed: " << item_id;
          std::string str_item_id = base::Uint64ToString(item_id);
          std::ofstream ofs(str_item_id);
          ofs << str1;
          ofs.close();
          std::ofstream ofs_cmp(str_item_id + "_cmp");
          ofs_cmp << str2;
          ofs_cmp.close();
        } else {
          LOG(ERROR) << "compare updated reco item succ: " << item_id;
        }
      }
    }
    return bret;
  } else if (FLAGS_request_type == "DB_reco_item") {
    reco::RecoItem reco_item;
    bool bret = GetDBRecoItemInfo(item_id, &reco_item);
    if (FLAGS_is_compare && bret) {
      reco::RecoItem cmp_reco_item;
      bret = GetDBRecoItemInfo(item_id, &cmp_reco_item, true);
      if (!bret) {
        LOG(ERROR) << "compare DB reco item failed, miss: " << item_id;
      } else {
        std::string str1 = reco_item.Utf8DebugString();
        std::string str2 = cmp_reco_item.Utf8DebugString();

        if (str1 != str2) {
          LOG(ERROR) << "compare DB reco item failed: " << item_id;
          std::string str_item_id = base::Uint64ToString(item_id);
          std::ofstream ofs(str_item_id);
          ofs << str1;
          ofs.close();
          std::ofstream ofs_cmp(str_item_id + "_cmp");
          ofs_cmp << str2;
          ofs_cmp.close();
        } else {
          LOG(ERROR) << "compare DB reco item succ: " << item_id;
        }
      }
    }
    return bret;
  } else if (FLAGS_request_type == "all") {
    if (!GetUpdateRecoItemInfo(item_id)||!GetDBRecoItemInfo(item_id)) {
      return false;
    }
    //  UpdateDBRecoItemTest(item_id);
  } else {
    LOG(ERROR) << "request type error";
    return false;
  }
  ::google::FlushLogFiles(::google::INFO);
  return true;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "sim item client");

  if (FLAGS_item_id != 0) {
    TestRpc(FLAGS_item_id);
  } else if (!FLAGS_item_id_file.empty()) {
    int total_cnt = 0, fail_cnt = 0;
    std::vector<std::string> lines;
    if (base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines)) {
      for (auto iter = lines.begin(); iter != lines.end(); ++iter) {
        uint64 item_id = 0;
        if (!base::StringToUint64(*iter, &item_id)) continue;
        ++total_cnt;
        if (!TestRpc(item_id)) {
          ++fail_cnt;
        }
      }
      LOG(ERROR) << "total: " << total_cnt << ", failed: " << fail_cnt;
    }
  } else {
    std::string line;
    uint64 id;
    while (std::cin >> line) {
      if (!base::StringToUint64(line, &id)) {
        LOG(ERROR) << "StringToUint64 fail, line: " << line;
        return 0;
      } else {
        TestRpc(id);
      }
    }
  }
  return 0;
}
