#pragma once

#include "base/thread/sync.h"
#include "reco/bizc/proto/reco_doc_server.pb.h"

#include "base/thread/blocking_queue.h"

namespace reco {
namespace docserver {

class DocService_Stub;

enum ReqType {
  kInvalidReq = 0,
  kGetItemDocReq,
  kGetRecoItemReq,
  kGetSimItemImageReq,
  kUpdateRawReq,
  kUpdateDBRecoReq,
};

struct StWorkParam {
  const ::google::protobuf::Message* request;
  ::google::protobuf::Message* response;
  ::Closure* done;
  int64 time_stamp;
  ReqType type;

  StWorkParam() {
    request = NULL;
    response = NULL;
    done = NULL;
    time_stamp = 0;
    type = kInvalidReq;
  }

  StWorkParam(const ::google::protobuf::Message *req, ::google::protobuf::Message *resp,
              ::Closure *closure_done, const int64 stamp, const ReqType req_type) {
    request = req;
    response = resp;
    done = closure_done;
    time_stamp = stamp;
    type = req_type;
  }
};

class DocImpl : public RecoDocService {
 public:
  DocImpl();

  explicit DocImpl(const int thread_num);

  ~DocImpl();

  // 给定 item id list， 获取所有 item 对待应的 doc 信息
  //
  // NOTE(jianhuang), 原则上所有数据都能获取正确结果
  // 1. 如果所有 item 都能正确地取到数据，则会依序返回结果
  // 2. 如果任何一条数据有错误，response 返回错误, 但成功的 item 的 doc 信息仍然会填充到 response
  virtual void GetItemDocInfo(stumy::RpcController* controller,
                              const reco::doc::ItemDocRequest *request,
                              reco::doc::ItemDocResponse *response,
                              Closure *done);

  // 给定 item id list, 获取 item 对应的 reco item 信息
  // 1. 如果所有 item 都能正确地取到数据，则会依序返回结果
  // 2. 如果任何一条数据有错误，response 返回错误, 但成功的 item 的 doc 信息仍然会填充到 response
  virtual void GetRecoItemInfo(stumy::RpcController* controller,
                               const reco::doc::RecoItemRequest *request,
                               reco::doc::RecoItemResponse *response,
                               Closure *done);

  // 给定一批 item_id， 从中获取指定数量的图片, 不足时则返回所有照片
  virtual void GetSimItemImageList(stumy::RpcController* controller,
                                   const reco::doc::SimItemImageRequest *request,
                                   reco::doc::SimItemImageResponse *response,
                                   Closure *done);

  // 给定 raw item，更新相关的 doc 信息，主要是正文内容和图片的调整
  virtual void UpdateRawItemDocInfo(stumy::RpcController* controller,
                                    const reco::doc::UpdateRawItemDocRequest *request,
                                    reco::doc::UpdateRawItemDocResponse *response,
                                    Closure *done);

  // 更新 db 中的 reco item 信息，如果不存在，则添加
  virtual void UpdateDBRecoItem(stumy::RpcController* controller,
                                const reco::doc::UpdateDBRecoItemRequest *request,
                                reco::doc::UpdateDBRecoItemResponse *response,
                                Closure *done);

 private:
  // 实际请求处理逻辑
  void Process(StWorkParam param);
  void GetItemDocInfo(const int64 stamp,
                      const reco::doc::ItemDocRequest *request,
                      reco::doc::ItemDocResponse *response,
                      Closure *done);

  // 给定 item id list, 获取 item 对应的 reco item 信息
  // 1. 如果所有 item 都能正确地取到数据，则会依序返回结果
  // 2. 如果任何一条数据有错误，response 返回错误, 但成功的 item 的 doc 信息仍然会填充到 response
  void GetRecoItemInfo(const int64 stamp,
                       const reco::doc::RecoItemRequest *request,
                       reco::doc::RecoItemResponse *response,
                       Closure *done);

  // 给定一批 item_id， 从中获取指定数量的图片, 不足时则返回所有照片
  void GetSimItemImageList(const int64 stamp,
                           const reco::doc::SimItemImageRequest *request,
                           reco::doc::SimItemImageResponse *response,
                           Closure *done);

  // 给定 raw item，更新相关的 doc 信息，主要是正文内容和图片的调整
  void UpdateRawItemDocInfo(const int64 stamp,
                            const reco::doc::UpdateRawItemDocRequest *request,
                            reco::doc::UpdateRawItemDocResponse *response,
                            Closure *done);

  // 更新 db 中的 reco item 信息，如果不存在，则添加
  void UpdateDBRecoItem(const int64 stamp,
                        const reco::doc::UpdateDBRecoItemRequest *request,
                        reco::doc::UpdateDBRecoItemResponse *response,
                        Closure *done);

  void UpdateStatus(const int64 stamp);

 private:
  thread::BlockingQueue<reco::docserver::DocService_Stub*> stub_queue_;
  thread::Mutex mutex_;
};
}  // namespace docserver
}  // namespace reco
