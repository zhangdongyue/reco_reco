#pragma once

#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "serving_base/data_manager/data_manager.h"

#include "reco/serv/doc_server/handler/doc_controller.h"
#include "reco/serv/doc_server/handler/global_data.h"

// |GlobalData| 管理所有的静态数据资源, 在策略部分可以被直接使用
namespace serving_base {
template<typename Controller, typename GlobalData>
class DataManager;
}

namespace reco {
namespace docserver {

// forward declare
struct GlobalData;
typedef serving_base::DataManager<reco::doc::DocController, reco::doc::GlobalData> DocDataManager;

}  // namespace docserver
}  // namespcae reco
