#include "base/common/base.h"
#include "base/common/gflags.h"
#include "net/counter/export.h"
#include "serving_base/utility/signal.h"
#include "serving_base/data_manager/server_frame.h"

#include "reco/serv/doc_server/frame/global_manager.h"
#include "reco/serv/doc_server/frame/doc_service_impl.h"
#include "reco/serv/doc_server/handler/global_data.h"

DEFINE_int32(port, 20013, "the listening port on which the serving application listens");
DEFINE_int32(work_thread_num, 10, "work thread num");
DEFINE_int32(rpc_thread_num, 2, "rpc thread num");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "doc server");
  net::counter::HttpCounterExport();

  reco::doc::GlobalData global_data;
  serving_base::DataManangerConfig config;
  config.controller_item_num = FLAGS_work_thread_num;
  reco::docserver::DocDataManager::Initialize(config, &global_data);
  reco::docserver::DocDataManager::GetGlobalData()->Init();

  reco::docserver::DocImpl doc_service;
  serving_base::ServerFrameConfig server_frame_config;
  server_frame_config.rpc_threads_num = FLAGS_rpc_thread_num;
  server_frame_config.rpc_server_port = FLAGS_port;
  server_frame_config.service = &doc_service;
  server_frame_config.dict_manager = reco::docserver::DocDataManager::GetDictManager();
  serving_base::ServerFrame server_frame(server_frame_config);
  server_frame.Start();
  LOG(INFO)<< "doc server start";

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();

  // stop
  LOG(INFO) << "stopping server...";
  ::google::FlushLogFiles(::google::INFO);

  // 先停掉异步线程池，再停服务框架，防停服 core
  reco::docserver::DocDataManager::GetGlobalData()->StopThreads();
  LOG(INFO) << "rpc threads stop";
  ::google::FlushLogFiles(::google::INFO);

  server_frame.Stop();
  LOG(INFO) << "frame stop";
  ::google::FlushLogFiles(::google::INFO);
  base::SleepForSeconds(1);

  reco::docserver::DocDataManager::GetGlobalData()->Stop();
  reco::docserver::DocDataManager::Release();
  LOG(INFO) << "DocDataMananger release";

  LOG(INFO)<< "doc server safe quit";

  return 0;
}
