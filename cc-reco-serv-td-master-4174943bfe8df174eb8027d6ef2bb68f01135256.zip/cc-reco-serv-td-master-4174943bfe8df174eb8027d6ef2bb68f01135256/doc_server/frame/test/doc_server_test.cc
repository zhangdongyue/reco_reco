#include "reco/serv/doc_server/frame/test/doc_server_test.h"


namespace reco {
namespace doc {
DEFINE_bool(is_press_test, false, "doc userd for press_test");
DEFINE_string(item_id_file, "", "the item id file");


void DocServerTest::SetUpTestCase() {
  global_data_ = new reco::doc::GlobalData(10);
  ASSERT_NE(global_data_, static_cast<GlobalData*> NULL);

  serving_base::DataManangerConfig config;
  config.controller_item_num = 10;
  reco::docserver::DocDataManager::Initialize(config, global_data_);

  ASSERT_TRUE(InitTestItemIDs());
  doc_controller_ = new DocController();
  ASSERT_NE(doc_controller_, static_cast<DocController*> NULL);

  doc_sync_mgr_ = new DocSyncMgr();
  ASSERT_NE(doc_sync_mgr_, static_cast<DocSyncMgr*> NULL);
}

void DocServerTest::TearDownTestCase() {
  // delete global_data_;
  delete doc_controller_;
  // delete doc_sync_mgr_;
}

bool DocServerTest::InitTestItemIDs() {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines))
    return false;

  for (auto iter = lines.begin(); iter != lines.end(); ++iter) {
    uint64 item_id = 0;
    if (!base::StringToUint64(*iter, &item_id)) continue;
    item_ids_.push_back(item_id);
  }
  return true;
}

reco::doc::GlobalData* DocServerTest::global_data_ = NULL;
reco::doc::DocController* DocServerTest::doc_controller_ = NULL;
reco::doc::DocSyncMgr* DocServerTest::doc_sync_mgr_ = NULL;
std::vector<uint64> DocServerTest::item_ids_;


TEST_F(DocServerTest, system_counter) {
  reco::doc::SystemCounter sys_counter;
  for (int i = 0; i < 1000; ++i) {
    sys_counter.AddTimeUs(i*1000);
    /*auto degree = */sys_counter.GetDegree();
  }
}

TEST_F(DocServerTest, rpc) {
  for (auto iter = item_ids_.begin(); iter != item_ids_.end(); ++iter) {
    reco::doc::ItemDocRequest request;
    reco::doc::ItemDocResponse response;
    request.add_item_id(*iter);
    doc_controller_->GetItemDocInfo(&request, &response);
    ASSERT_EQ(response.reco_item_size(), 1);
  }
}
/*
TEST_F(DocServerTest, doc_storage) {
  auto& doc_storage = global_data_->doc_storage;
  RecoItem reco_item;
  for (auto iter = item_ids_.begin(); iter != item_ids_.end(); ++iter) {
    ASSERT_TRUE(doc_storage.GetRecoItemFromDB(*iter, &reco_item));
    doc_storage.ClearCacheData(*iter);
    doc_storage.SaveRecoItemToCache(reco_item);
    ASSERT_TRUE(doc_storage.GetRecoItemFromCache(*iter, &reco_item));
    ASSERT_EQ(doc_storage.SaveRecoItemToDB(reco_item), 0);
  }
}

TEST_F(DocServerTest, sync_mgr) {
  auto& doc_storage = global_data_->doc_storage;
  RecoItem reco_item;
  for (auto iter = item_ids_.begin(); iter != item_ids_.end(); ++iter) {
    ASSERT_TRUE(doc_storage.GetRecoItemFromDB(*iter, &reco_item));
    doc_sync_mgr_->UpdateImageInfo(&reco_item);
    doc_sync_mgr_->NeedUpdate(*iter, true, 10000);
    doc_sync_mgr_->NeedUpdate(*iter, false, 10000);
    doc_sync_mgr_->AddToRefreshQueue(*iter);
    doc_sync_mgr_->AddDocUntilSucc(reco_item, false, 0);
    doc_sync_mgr_->AddDocUntilSucc(reco_item, true, 10000);
  }
}
*/
}
}
