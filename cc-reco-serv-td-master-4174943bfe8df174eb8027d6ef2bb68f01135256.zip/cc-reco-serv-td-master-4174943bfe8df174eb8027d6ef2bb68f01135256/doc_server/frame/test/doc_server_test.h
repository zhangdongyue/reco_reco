#pragma once


#include <vector>
#include <string>

#include "base/file/file_util.h"
#include "base/strings/string_number_conversions.h"

#include "reco/serv/doc_server/handler/global_data.h"
#include "reco/serv/doc_server/frame/global_manager.h"
#include "reco/serv/doc_server/handler/doc_sync_mgr.h"
#include "reco/serv/doc_server/handler/system_counter.h"
#include "reco/serv/doc_server/handler/doc_controller.h"

namespace reco {
namespace doc {
class DocServerTest : public testing::Test {
 public:

  static void SetUpTestCase();

  static void TearDownTestCase();

  static bool InitTestItemIDs();

 protected:

  static reco::doc::GlobalData* global_data_;

  static reco::doc::DocController* doc_controller_;

  static reco::doc::DocSyncMgr* doc_sync_mgr_;

  static std::vector<uint64> item_ids_;
};
}
}
