#include "reco/serv/doc_server/frame/doc_service_impl.h"

#include <string>

#include "base/time/timestamp.h"
#include "nlp/common/nlp_util.h"
#include "base/strings/string_number_conversions.h"

#include "reco/serv/doc_server/frame/global_manager.h"
#include "reco/serv/doc_server/handler/global_data.h"
#include "reco/serv/doc_server/handler/data_manager.h"

#define POST_DOC_RPC_TASK(rpc_name, request, response, done) \
    thread::AutoLock lock(&mutex_); \
DocDataManager::GetGlobalData()->work_thread_pool.AddTask(NewCallback(this, \
&DocImpl::rpc_name, base::GetTimestamp(), request, response, done));

#define CALL_DOC_CONTROLLER(rpc_name) \
    ScopedClosure scoped_closure(done); \
COUNTERS_doc__cur_thread_busy.Increase(1);\
VLOG(2) << #rpc_name << " request: " << nlp::util::NormalizeLine(request->Utf8DebugString()); \
if (base::GetTimestamp() - stamp > FLAGS_max_block_time * 1000) { \
  LOG(ERROR) << "server overload, do not process req."; \
  COUNTERS_get_doc__overload_req_total.Increase(1); \
  COUNTERS_doc__cur_thread_busy.Decrease(1);\
  return; \
} \
auto doc_controller = DocDataManager::GetControllerItem();  \
CHECK_NOTNULL(doc_controller);  \
doc_controller->rpc_name(request, response); \
DocDataManager::ReleaseControllerItem(doc_controller); \
COUNTERS_doc__cur_thread_busy.Decrease(1);


namespace reco {
namespace docserver {
DEFINE_int32(max_block_time, 200, "ms");

DEFINE_int64_counter(get_doc, total_request, 0, "总请求数");
DEFINE_int64_counter(get_doc, max_response_time, 0, "max response time, unit: ms");
DEFINE_int64_counter(get_doc, total_response_time, 0,
                                          "total response time, to calculate ave res time"", unit: ms");
DEFINE_int64_counter(get_doc, overload_req_total, 0, "在队列中等待超时的请求数量");
DEFINE_int64_counter(doc, cur_thread_busy, 0, "");

DocImpl::DocImpl(int thread_num) {
}
DocImpl::DocImpl() {
}

DocImpl::~DocImpl() {
}

void DocImpl::GetRecoItemInfo(stumy::RpcController* controller,
                                     const reco::doc::RecoItemRequest *request,
                                     reco::doc::RecoItemResponse *response,
                                     Closure *done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kGetRecoItemReq);
  thread::AutoLock lock(&mutex_);
  if (DocDataManager::GetGlobalData()->IsThreadPoolEnabled())
    DocDataManager::GetGlobalData()->work_thread_pool->AddTask(NewCallback(this, &DocImpl::Process, param));
}

void DocImpl::GetSimItemImageList(stumy::RpcController* controller,
                                         const reco::doc::SimItemImageRequest *request,
                                         reco::doc::SimItemImageResponse *response,
                                         Closure *done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kGetSimItemImageReq);
  thread::AutoLock lock(&mutex_);
  if (DocDataManager::GetGlobalData()->IsThreadPoolEnabled())
    DocDataManager::GetGlobalData()->work_thread_pool->AddTask(NewCallback(this, &DocImpl::Process, param));
}

void DocImpl::GetItemDocInfo(stumy::RpcController* controller,
                                    const reco::doc::ItemDocRequest *request,
                                    reco::doc::ItemDocResponse *response,
                                    Closure *done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kGetItemDocReq);
  thread::AutoLock lock(&mutex_);
  if (DocDataManager::GetGlobalData()->IsThreadPoolEnabled())
    DocDataManager::GetGlobalData()->work_thread_pool->AddTask(NewCallback(this, &DocImpl::Process, param));
}

void DocImpl::UpdateRawItemDocInfo(stumy::RpcController* controller,
                                          const reco::doc::UpdateRawItemDocRequest *request,
                                          reco::doc::UpdateRawItemDocResponse *response,
                                          Closure *done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kUpdateRawReq);
  thread::AutoLock lock(&mutex_);
  if (DocDataManager::GetGlobalData()->IsThreadPoolEnabled())
    DocDataManager::GetGlobalData()->work_thread_pool->AddTask(NewCallback(this, &DocImpl::Process, param));
}

void DocImpl::UpdateDBRecoItem(stumy::RpcController* controller,
                                      const reco::doc::UpdateDBRecoItemRequest *request,
                                      reco::doc::UpdateDBRecoItemResponse *response,
                                      Closure *done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kUpdateDBRecoReq);
  thread::AutoLock lock(&mutex_);
  if (DocDataManager::GetGlobalData()->IsThreadPoolEnabled())
    DocDataManager::GetGlobalData()->work_thread_pool->AddTask(NewCallback(this, &DocImpl::Process, param));
}

void DocImpl::GetItemDocInfo(const int64 stamp,
                                    const reco::doc::ItemDocRequest *request,
                                    reco::doc::ItemDocResponse *response,
                                    Closure *done) {
  std::string log_items = "req:";
  for (auto i = 0; i < request->item_id_size(); ++i) {
    log_items += base::Uint64ToString(request->item_id(i)) + ",";
  }

  response->set_success(false);
  CALL_DOC_CONTROLLER(GetItemDocInfo);

  UpdateStatus(stamp);

  log_items += " resp:";
  for (auto i = 0; i < response->reco_item_size(); ++i) {
    log_items += base::Uint64ToString(response->reco_item(i).identity().item_id()) + ",";
  }

  if (response->success()) {
    LOG(INFO) << "get succ. " << log_items << " cost:" << base::GetTimestamp() - stamp;
  } else {
    LOG(WARNING) << "get fail. " << log_items << " cost:" << base::GetTimestamp() - stamp;
  }
}

void DocImpl::GetRecoItemInfo(const int64 stamp,
                                     const reco::doc::RecoItemRequest *request,
                                     reco::doc::RecoItemResponse *response,
                                     Closure *done) {
  response->set_success(false);
  CALL_DOC_CONTROLLER(GetRecoItemInfo);
  UpdateStatus(stamp);
}

void DocImpl::GetSimItemImageList(const int64 stamp,
                                         const reco::doc::SimItemImageRequest *request,
                                         reco::doc::SimItemImageResponse *response,
                                         Closure *done) {
  CALL_DOC_CONTROLLER(GetSimItemImageList);
  UpdateStatus(stamp);
}

void DocImpl::UpdateRawItemDocInfo(const int64 stamp,
                                          const reco::doc::UpdateRawItemDocRequest *request,
                                          reco::doc::UpdateRawItemDocResponse *response,
                                          Closure *done) {
  response->set_success(false);
  CALL_DOC_CONTROLLER(UpdateRawItemDocInfo);
  UpdateStatus(stamp);
}

void DocImpl::UpdateDBRecoItem(const int64 stamp,
                                      const reco::doc::UpdateDBRecoItemRequest *request,
                                      reco::doc::UpdateDBRecoItemResponse *response,
                                      Closure *done) {
  CALL_DOC_CONTROLLER(UpdateDBRecoItem);
  UpdateStatus(stamp);
}

void DocImpl::UpdateStatus(const int64 stamp) {
  int64 cost_us = base::GetTimestamp() - stamp;
  auto& op_num = reco::doc::DataMgr::instance().op_num;
  ++op_num;
  auto& max_response_time = reco::doc::DataMgr::instance().max_response_time;
  if (op_num % 2000 == 0) {
    op_num = 0;
    max_response_time = cost_us;
  } else if (cost_us > max_response_time) {
      max_response_time = cost_us;
  }
  reco::doc::DataMgr::instance().system_counter->AddTimeUs((int)cost_us);
  COUNTERS_get_doc__max_response_time.Reset(max_response_time/1000);
  COUNTERS_get_doc__total_response_time.Increase(cost_us/1000);
  COUNTERS_get_doc__total_request.Increase(1);
}

void DocImpl::Process(StWorkParam param) {
  switch (param.type) {
    case kGetItemDocReq:
      GetItemDocInfo(param.time_stamp,
                     static_cast<const reco::doc::ItemDocRequest*>(param.request),
                     static_cast<reco::doc::ItemDocResponse*>(param.response),
                     param.done);
      break;
    case kGetRecoItemReq:
      GetRecoItemInfo(param.time_stamp,
                      static_cast<const reco::doc::RecoItemRequest*>(param.request),
                      static_cast<reco::doc::RecoItemResponse*>(param.response),
                      param.done);
      break;
    case kGetSimItemImageReq:
      GetSimItemImageList(param.time_stamp,
                          static_cast<const reco::doc::SimItemImageRequest*>(param.request),
                          static_cast<reco::doc::SimItemImageResponse*>(param.response),
                          param.done);
      break;
    case kUpdateRawReq:
      UpdateRawItemDocInfo(param.time_stamp,
                           static_cast<const reco::doc::UpdateRawItemDocRequest*>(param.request),
                           static_cast<reco::doc::UpdateRawItemDocResponse*>(param.response),
                           param.done);
      break;
    case kUpdateDBRecoReq:
      UpdateDBRecoItem(param.time_stamp,
                       static_cast<const reco::doc::UpdateDBRecoItemRequest*>(param.request),
                       static_cast<reco::doc::UpdateDBRecoItemResponse*>(param.response),
                       param.done);
      break;
    default:
      LOG(ERROR) << "invalid req type: " << param.type;
      break;
  }
}
}  // namespace docserver
}  // namespace reco
