#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_number_conversions.h"
#include "net/counter/export.h"
#include "serving_base/utility/signal.h"
#include "arpc/RPCInterface.h"
#include "arpc/ANetRPCServer.h"
#include "arpc/CommonMacros.h"

#include "reco/bizc/proto_arpc/reco_doc_server.pb.h"
#include "reco/serv/doc_server/frame_arpc/global_manager.h"
#include "reco/serv/doc_server/handler/global_data.h"
#include "reco/serv/doc_server/handler/doc_sync_mgr.h"
#include "reco/serv/doc_server/frame_arpc/doc_service_impl.h"
#include "reco/serv/doc_server/handler/data_manager.h"

DEFINE_int32(port, 20013, "the listening port on which the serving application listens");
DEFINE_int32(work_thread_num, 10, "work thread num");
DEFINE_int32(rpc_thread_num, 2, "rpc thread num");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "doc server");
  net::counter::HttpCounterExport();

  // init data
  reco::docserver::GlobalDataMgr::instance().Init();

  // start server
  arpc::ANetRPCServer rpcServer(NULL, FLAGS_rpc_thread_num, FLAGS_work_thread_num * 5);
  rpcServer.StartPrivateTransport();

  rpcServer.RegisterService(new arpc::reco::docserver::DocImpl);
  std::string spec = "tcp:0.0.0.0:" + base::IntToString(FLAGS_port);
  LOG(INFO) << "listen:" << spec;
  if (!rpcServer.Listen(spec)) {
    LOG(ERROR) << "listen fail:" << spec;
    return -1;
  }
  LOG(INFO) << "start server succ.";

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();

  // close server
  rpcServer.Close();
  rpcServer.StopPrivateTransport();
  LOG(INFO) << "stop server succ.";

  reco::docserver::GlobalDataMgr::instance().Stop();
  ::google::FlushLogFiles(::google::INFO);
  return 0;
}
