#pragma once

#include "string"

#include "arpc/CommonMacros.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/sync.h"
#include "nlp/common/nlp_util.h"

#include "reco/bizc/proto_arpc/reco_doc_server.pb.h"

namespace reco {
namespace doc {
class DocController;
}
}

ARPC_BEGIN_NAMESPACE(arpc);

namespace reco {
namespace docserver {

enum ReqType {
  kInvalidReq = 0,
  kGetItemDocReq,
  kGetRecoItemReq,
  kGetSimItemImageReq,
  kUpdateRawReq,
  kUpdateDBRecoReq,
};

struct StWorkParam {
  ::google::protobuf::RpcController* controller;
  const ::google::protobuf::Message* request;
  ::google::protobuf::Message* response;
  ::google::protobuf::Closure* done;
  int64 time_stamp;
  ReqType type;
  ::reco::doc::DocController* doc_controller;

  StWorkParam() {
    Clear();
  }

  void Clear() {
    controller = nullptr;
    request = nullptr;
    response = nullptr;
    done = nullptr;
    time_stamp = 0;
    type = kInvalidReq;
    doc_controller = nullptr;
  }

  StWorkParam(::google::protobuf::RpcController* ctr,
              const ::google::protobuf::Message *req,
              ::google::protobuf::Message *resp,
              ::google::protobuf::Closure *closure_done,
              const int64 stamp,
              const ReqType req_type) {
    controller = ctr;
    request = req;
    response = resp;
    done = closure_done;
    time_stamp = stamp;
    type = req_type;
  }
};

class DocImpl : public ::reco::docserver::RecoDocService {
 public:
  DocImpl();

  ~DocImpl();

  // 给定 item id list， 获取所有 item 对待应的 doc 信息
  //
  // NOTE(jianhuang), 原则上所有数据都能获取正确结果
  // 1. 如果所有 item 都能正确地取到数据，则会依序返回结果
  // 2. 如果任何一条数据有错误，response 返回错误, 但成功的 item 的 doc 信息仍然会填充到 response
  virtual void GetItemDocInfo(::google::protobuf::RpcController* controller,
                              const ::reco::doc::ItemDocRequest *request,
                              ::reco::doc::ItemDocResponse *response,
                              ::google::protobuf::Closure *done);

  // 给定 item id list, 获取 item 对应的 ::reco item 信息
  // 1. 如果所有 item 都能正确地取到数据，则会依序返回结果
  // 2. 如果任何一条数据有错误，response 返回错误, 但成功的 item 的 doc 信息仍然会填充到 response
  virtual void GetRecoItemInfo(::google::protobuf::RpcController* controller,
                               const ::reco::doc::RecoItemRequest *request,
                               ::reco::doc::RecoItemResponse *response,
                               ::google::protobuf::Closure *done);

  // 给定一批 item_id， 从中获取指定数量的图片, 不足时则返回所有照片
  virtual void GetSimItemImageList(::google::protobuf::RpcController* controller,
                                   const ::reco::doc::SimItemImageRequest *request,
                                   ::reco::doc::SimItemImageResponse *response,
                                   ::google::protobuf::Closure *done);

  // 给定 raw item，更新相关的 doc 信息，主要是正文内容和图片的调整
  virtual void UpdateRawItemDocInfo(::google::protobuf::RpcController* controller,
                                    const ::reco::doc::UpdateRawItemDocRequest *request,
                                    ::reco::doc::UpdateRawItemDocResponse *response,
                                    ::google::protobuf::Closure *done);

  // 更新 db 中的 ::reco item 信息，如果不存在，则添加
  virtual void UpdateDBRecoItem(::google::protobuf::RpcController* controller,
                                const ::reco::doc::UpdateDBRecoItemRequest *request,
                                ::reco::doc::UpdateDBRecoItemResponse *response,
                                ::google::protobuf::Closure *done);

 private:
  void Process(const int thread_idx);

  void GetItemDocInfo(StWorkParam param, std::string *details = NULL);

  // 给定 item id list, 获取 item 对应的 ::reco item 信息
  // 1. 如果所有 item 都能正确地取到数据，则会依序返回结果
  // 2. 如果任何一条数据有错误，response 返回错误, 但成功的 item 的 doc 信息仍然会填充到 response
  void GetRecoItemInfo(StWorkParam param, std::string *details = NULL);

  // 给定一批 item_id， 从中获取指定数量的图片, 不足时则返回所有照片
  void GetSimItemImageList(StWorkParam param, std::string *details = NULL);

  // 给定 raw item，更新相关的 doc 信息，主要是正文内容和图片的调整
  void UpdateRawItemDocInfo(StWorkParam param, std::string *details = NULL);
  // 更新 db 中的 ::reco item 信息，如果不存在，则添加
  void UpdateDBRecoItem(StWorkParam param, std::string *details = NULL);

  void UpdateStatus(const int64 stamp);

 private:
  ::thread::BlockingQueue<StWorkParam> request_queue_;
  std::atomic<bool> is_run_;
};

}  // namespace docserver
}  // namespcae reco

ARPC_END_NAMESPACE(arpc);
