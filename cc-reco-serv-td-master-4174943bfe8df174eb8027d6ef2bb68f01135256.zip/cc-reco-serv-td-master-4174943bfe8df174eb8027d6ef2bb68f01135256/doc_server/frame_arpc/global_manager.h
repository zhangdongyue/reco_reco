#pragma once

#include "reco/base/common/singleton.h"
#include "reco/serv/doc_server/handler/global_data.h"

namespace reco {
namespace docserver {

typedef reco::common::singleton_default<reco::doc::GlobalData> GlobalDataMgr;

}  //  namespace docserver
}  //  namespcae reco
