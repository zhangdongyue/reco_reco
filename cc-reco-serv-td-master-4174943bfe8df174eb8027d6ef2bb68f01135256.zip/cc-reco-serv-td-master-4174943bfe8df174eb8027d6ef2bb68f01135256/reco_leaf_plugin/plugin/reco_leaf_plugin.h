#pragma once

#include "athena/container_worker/PluginWorker.h"
#include "base/common/base.h"

#include "reco/serv/reco_leaf_plugin/frame/leaf_impl.h"
#include "reco/base/dict_manager/reload_service_type.pb.h"

namespace athena {
namespace container_worker {

const std::string METHOD_RECOMMEND = "recommend";
const std::string METHOD_WEMEDIA_RECOMMEND = "wemedia_recommend";
const std::string METHOD_GET_INDEX_ITEM_INFO = "get_index_item_info";
const std::string METHOD_GET_INDEX_QUEUE = "get_index_queue";
const std::string METHOD_GET_INDEX_QUEUE_UNSORT = "get_index_queue_unsort";
const std::string METHOD_RELOAD_FILE = "reload_file";
const std::string METHOD_TAG_RECOMMEND = "tag_recommend";
const std::string METHOD_VERTICAL_RECOMMEND = "vertical_recommend";
const std::string METHOD_GET_NEWS_MAP= "get_news_map";

class AutoRef {
 public:
  explicit AutoRef(anet::Connection* con) {
    con_ = con;
    con_->addRef();
  }

  ~AutoRef() {
    con_->subRef();
  }

 private:
  anet::Connection* con_;
  DISALLOW_COPY_AND_ASSIGN(AutoRef);
};

//post data: method=xxx&args=xxx
struct LeafQuery{
  std::string service;
  std::string method;
  std::string args;
};

#define PLUGIN_DELETE_VAR(type, var) \
 type* p = reinterpret_cast<type*>(var);\
 delete p;\
 var = NULL;

class RecoData{
public:
  std::string query;
  LeafQuery leaf_query;
  anet::Connection* connection;
  bool isKeepAlive;
  char* request;
  char* response;
  int http_code;
  std::string result;
  uint64 start_time;

  RecoData(const std::string& ori_query,
      anet::Connection *con,
        bool KeepAlive):request(NULL), response(NULL){
    query = ori_query;
    connection = con;
    connection->addRef();
    isKeepAlive = KeepAlive;
  }

  ~RecoData(){
    connection->subRef();

    if (request != NULL) {
      if (leaf_query.method == METHOD_RECOMMEND) {
        PLUGIN_DELETE_VAR(reco::leafserver::RecommendRequest, request);
      } else if (leaf_query.method == METHOD_WEMEDIA_RECOMMEND) {
        PLUGIN_DELETE_VAR(reco::leafserver::WeMediaRecommendRequest, request);
      } else if (leaf_query.method == METHOD_TAG_RECOMMEND) {
        PLUGIN_DELETE_VAR(reco::leafserver::TagRecommendRequest, request);
      } else if (leaf_query.method == METHOD_VERTICAL_RECOMMEND) {
        PLUGIN_DELETE_VAR(reco::leafserver::VerticalRequest, request);
      } else if (leaf_query.method == METHOD_GET_NEWS_MAP) {
        PLUGIN_DELETE_VAR(reco::leafserver::NewsMapRequest, request);
      } else if (leaf_query.method == METHOD_GET_INDEX_ITEM_INFO) {
        PLUGIN_DELETE_VAR(reco::leafserver::GetIndexItemInfoRequest, request);
      } else if (leaf_query.method == METHOD_GET_INDEX_QUEUE) {
        PLUGIN_DELETE_VAR(reco::leafserver::GetIndexQueueRequest, request);
      } else if (leaf_query.method == METHOD_GET_INDEX_QUEUE_UNSORT) {
        PLUGIN_DELETE_VAR(reco::leafserver::GetIndexQueueUnsortRequest, request);
      } else if (leaf_query.method == METHOD_RELOAD_FILE) {
        PLUGIN_DELETE_VAR(reco::dm::ReloadFileRequest, request);
      } else {
        LOG(WARNING) << "request memory main leak, method=" <<  leaf_query.method;
      }
    }

    if (response != NULL) {
      if (leaf_query.method == METHOD_RECOMMEND) {
        PLUGIN_DELETE_VAR(reco::leafserver::RecommendResponse, response);
      } else if (leaf_query.method == METHOD_WEMEDIA_RECOMMEND) {
        PLUGIN_DELETE_VAR(reco::leafserver::WeMediaRecommendResponse, response);
      } else if (leaf_query.method == METHOD_TAG_RECOMMEND) {
        PLUGIN_DELETE_VAR(reco::leafserver::TagRecommendResponse, response);
      } else if (leaf_query.method == METHOD_VERTICAL_RECOMMEND) {
        PLUGIN_DELETE_VAR(reco::leafserver::VerticalResponse, response);
      } else if (leaf_query.method == METHOD_GET_NEWS_MAP) {
        PLUGIN_DELETE_VAR(reco::leafserver::NewsMapResponse, response);
      } else if (leaf_query.method == METHOD_GET_INDEX_ITEM_INFO) {
        PLUGIN_DELETE_VAR(reco::leafserver::GetIndexItemInfoResponseHa3, response);
      } else if (leaf_query.method == METHOD_GET_INDEX_QUEUE) {
        PLUGIN_DELETE_VAR(reco::leafserver::GetIndexQueueResponse, response);
      } else if (leaf_query.method == METHOD_GET_INDEX_QUEUE_UNSORT) {
        PLUGIN_DELETE_VAR(reco::leafserver::GetIndexQueueUnsortResponse, response);
      } else if (leaf_query.method == METHOD_RELOAD_FILE) {
        PLUGIN_DELETE_VAR(reco::dm::ReloadFileResponse, response);
      } else {
        LOG(WARNING) << "response memory main leak, method=" <<  leaf_query.method;
      }
    }
  }
private:
  DISALLOW_COPY_AND_ASSIGN(RecoData);
};

class XssPluginWorker : public PluginWorker {
 public:
  XssPluginWorker();
  virtual ~XssPluginWorker();

  bool init(const std::string& workDir, const std::string& configDir);

  bool process(const std::string& query, anet::Connection *connection, bool isKeepAlive);

  void stop();

  size_t getLoad();

 private:
  bool InnerInit();

  bool InnerStop();

  bool ParseQuery(const std::string& query, LeafQuery *q);
  void PostProcessCallback(char* resdata);

  bool SendReply(RecoData* reco_data);

  bool IsInited() {
    return inited_;
  }

  bool PrepareConfig(const std::string& ori_filepath, const std::string& new_filepath);
 private:
  std::atomic<bool> inited_;
  reco::leafserver::LeafImpl* leaf_impl_;
  std::string work_dir_;
  std::string config_dir_;
};
}
}
