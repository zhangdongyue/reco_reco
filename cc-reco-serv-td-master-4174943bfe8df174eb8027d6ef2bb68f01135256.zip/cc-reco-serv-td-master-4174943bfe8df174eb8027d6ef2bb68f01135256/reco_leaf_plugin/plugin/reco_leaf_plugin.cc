#include "reco/serv/reco_leaf_plugin/plugin/reco_leaf_plugin.h"

#include <iostream>
#include <map>
#include <vector>
#include <unistd.h>

#include "autil/StringTokenizer.h"
#include "autil/legacy/json.h"
#include "autil/legacy/jsonizable.h"
#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/time/timestamp.h"
#include "base/common/sleep.h"
#include "base/thread/thread.h"
#include "base/encoding/base64.h"
#include "base/file/file_util.h"
#include "base/strings/string_util.h"
#include "net/counter/export.h"
#include "serving_base/utility/signal.h"
#include "serving_base/utility/system_util.h"

#include "reco/bizc/news_map/strategy_ha3/news_map_strategy.h"
#include "reco/bizc/poi/city_area_hash_dict.h"
#include "reco/bizc/proto/leaf.pb.h"
#include "reco/serv/dict_server/api_arpc/dict_server_api.h"
#include "reco/serv/reco_leaf_plugin/common/define_flags.h"
#include "reco/serv/reco_leaf_plugin/frame/leaf_impl.h"
#include "reco/serv/reco_leaf_plugin/frame/global_data.h"
#include "reco/serv/reco_leaf_plugin/frame/leaf_controller.h"
//#include "reco/serv/reco_leaf_plugin/strategy/reco/offline/cf_item_dict.h"
#include "reco/serv/reco_leaf_plugin/strategy/rank_hooker.h"
#include "reco/serv/reco_model/frame_ha3/reco_model_predict.h"
#include "reco/serv/reco_leaf_plugin/common/leaf_cache.h"
#include "reco/base/common/uri_process.h"
#include "reco/base/dict_manager/dict_manager.h"
#include "reco/base/dict_manager/reload_service_type.pb.h"
#include "reco/base/http_communicator/http_client/http_client.h"
#include "reco/ml/model_server/api_arpc/model_server_api.h"

DECLARE_bool(open_model_server_wd);

using namespace reco::leafserver;

DEFINE_int64_counter(leaf, plugin_process_time, 0, "total process time of recommend");
DEFINE_int64_counter(leaf, plugin_process_count, 0, "total process count of recommend");

const char *kServerName = "leaf_server";

namespace athena {
namespace container_worker {
XssPluginWorker::XssPluginWorker() :inited_(false) {
  std::cout << "XssPluginWorker construct." << std::endl;
}

XssPluginWorker::~XssPluginWorker() {
  std::cout << "XssPluginWorker destruct." << endl;
}

bool XssPluginWorker::PrepareConfig(const std::string& ori_filepath, const std::string& new_filepath) {
  std::string old_str;
  std::string new_str;
  if (!base::file_util::ReadFileToString(ori_filepath, &old_str)) {
    std::cout << "read file error:" << ori_filepath << std::endl;
    return false;
  }

  base::FastStringReplace(old_str, "__RUNTIME_CONFIG_DIR__", config_dir_, true, &new_str);
  std::cout << "replace confdir [__RUNTIME_CONFIG_DIR__] to [" << config_dir_ << "]" << std::endl;

  if (!base::file_util::WriteFile(new_filepath, new_str.c_str(), new_str.size())) {
    std::cout << "write file error:" << new_filepath << std::endl;
    return false;
  }

  return true;
}

bool XssPluginWorker::init(const std::string& workDir, const std::string& configDir) {
  if (inited_) {
    return true;
  }

  work_dir_ = workDir;
  config_dir_ = configDir;

  std::cout << "work dir:" << workDir << std::endl;
  std::cout << "config dir:" << configDir << std::endl;
  char* pwd = get_current_dir_name();
  std::cout << "pwd:" << pwd << std::endl;
  free(pwd);
  pwd = nullptr;

  string cluster = "null";
  std::vector<std::string> elems;
  base::SplitString(serving_base::GetHostName(), ".", &elems);
  if (elems.size() > 1) {
    cluster = elems[elems.size() - 1];
  }

  const std::string ori_config_path = configDir + "/server_static.flags." + cluster;
  const std::string config_path = configDir + "/.server_static.flags." + cluster + ".runtime";
  const std::string ori_config = "--flagfile=" + ori_config_path;
  const std::string config = "--flagfile=" + config_path;

  if (!PrepareConfig(ori_config_path, config_path)) {
    std::cout << "prepare config file error:" << ori_config_path << std::endl;
    return false;
  }

  std::cout << "config file:" << config_path << std::endl;

  const char* p[2];
  p[0] = &kServerName[0];
  p[1] = config.c_str();
  char** argv = const_cast<char**>(&p[0]);
  int argc = 2;
  base::InitApp(&argc, &argv, "reco leaf plugin");
  std::cout << "InitApp done, opt:" << config_path << std::endl;

  return InnerInit();
}

size_t XssPluginWorker::getLoad() {
  return 0;
}

#define PLUGIN_PREPROCESS(req_type, res_type) \
  req_type* request = new req_type();\
  res_type* response = new res_type();\
  reco_data->request = reinterpret_cast<char*>(request);\
  reco_data->response = reinterpret_cast<char*>(response);\
  if (!request->ParseFromString(q->args)) {\
    err_msg="invalid query of req_type";\
    LOG(ERROR) << "ParseFromString fail:" << q->args;\
    break;\
  }\
  VLOG(1) << "Request in plugin:" << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);\
  Closure* done = ::NewCallback(this, &XssPluginWorker::PostProcessCallback, reinterpret_cast<char*>(reco_data));


bool XssPluginWorker::process(const std::string& query,
  anet::Connection *connection,
  bool isKeepAlive) {
  if (connection == NULL) {
    LOG(ERROR) << "connection is NULL, query=" << query;
    return false;
  }

  const int64 start_time = base::GetTimestamp();
  RecoData* reco_data = new RecoData(query, connection, isKeepAlive);
  reco_data->start_time = start_time;

  VLOG(1) << "process start, query=" << reco_data->query;

  std::string err_msg;
  while (1) {
    LeafQuery* q = &(reco_data->leaf_query);
    if (!ParseQuery(query, q)) {
      err_msg="invalid query";
      LOG(ERROR) << "ParseQuery fail, q=" << query;
      break;
    }

    if (q->method == METHOD_RECOMMEND) {
      PLUGIN_PREPROCESS(reco::leafserver::RecommendRequest, reco::leafserver::RecommendResponse);
      leaf_impl_->recommend(request, response, done);
    } else if (q->method == METHOD_WEMEDIA_RECOMMEND) {
      PLUGIN_PREPROCESS(reco::leafserver::WeMediaRecommendRequest, reco::leafserver::WeMediaRecommendResponse);
      leaf_impl_->wemediaRecommend(request, response, done);
    } else if (q->method == METHOD_TAG_RECOMMEND) {
      PLUGIN_PREPROCESS(reco::leafserver::TagRecommendRequest, reco::leafserver::TagRecommendResponse);
      leaf_impl_->tagRecommend(request, response, done);
    } else if (q->method == METHOD_VERTICAL_RECOMMEND) {
      PLUGIN_PREPROCESS(reco::leafserver::VerticalRequest, reco::leafserver::VerticalResponse);
      leaf_impl_->verticalRecommend(request, response, done);
    } else if (q->method == METHOD_GET_NEWS_MAP) {
      PLUGIN_PREPROCESS(reco::leafserver::NewsMapRequest, reco::leafserver::NewsMapResponse);
      leaf_impl_->getNewsMap(request, response, done);
    } else if (q->method == METHOD_GET_INDEX_ITEM_INFO) {
      PLUGIN_PREPROCESS(reco::leafserver::GetIndexItemInfoRequest, reco::leafserver::GetIndexItemInfoResponseHa3);
      leaf_impl_->getIndexItemInfo(request, response, done);
    } else if (q->method == METHOD_GET_INDEX_QUEUE) {
      PLUGIN_PREPROCESS(reco::leafserver::GetIndexQueueRequest, reco::leafserver::GetIndexQueueResponse);
      leaf_impl_->getIndexQueue(request, response, done);
    } else if (q->method == METHOD_GET_INDEX_QUEUE_UNSORT) {
      PLUGIN_PREPROCESS(reco::leafserver::GetIndexQueueUnsortRequest, reco::leafserver::GetIndexQueueUnsortResponse);
      leaf_impl_->getIndexQueueUnsort(request, response, done);
    } else if (q->method == METHOD_RELOAD_FILE) {
      PLUGIN_PREPROCESS(reco::dm::ReloadFileRequest, reco::dm::ReloadFileResponse);
      reco::leafserver::LeafDataManager::instance().work_thread_pool
        ->AddTask(NewCallback(&(reco::dm::DictManagerSingleton::instance()),
            &reco::dm::DictManager::ReloadDict, request, response, done));
    } else {
      err_msg="invalid query, unsupported method =" + q->method;
      LOG(ERROR) << err_msg;
      break;
    }

    return true;
  }

  reco_data->http_code = 404;
  reco_data->result= err_msg;
  if (!SendReply(reco_data)) {
    LOG(ERROR) << "SendReply fail, q=" << query;
    return false;
  }

  return true;
}

#define PLUGIN_POST_PRECESS(res_type) \
  res_type* response = reinterpret_cast<res_type*>(reco_data->response);\
  CHECK(response->SerializeToString(&(reco_data->result)));

void XssPluginWorker::PostProcessCallback(char* data) {
  RecoData* reco_data = reinterpret_cast<RecoData*>(data);

  if (reco_data->leaf_query.method == METHOD_RECOMMEND) {
    PLUGIN_POST_PRECESS(reco::leafserver::RecommendResponse);
  } else if (reco_data->leaf_query.method == METHOD_WEMEDIA_RECOMMEND) {
    PLUGIN_POST_PRECESS(reco::leafserver::WeMediaRecommendResponse);
  } else if (reco_data->leaf_query.method == METHOD_TAG_RECOMMEND) {
    PLUGIN_POST_PRECESS(reco::leafserver::TagRecommendResponse);
  } else if (reco_data->leaf_query.method == METHOD_VERTICAL_RECOMMEND) {
    PLUGIN_POST_PRECESS(reco::leafserver::VerticalResponse);
  } else if (reco_data->leaf_query.method == METHOD_GET_NEWS_MAP) {
    PLUGIN_POST_PRECESS(reco::leafserver::NewsMapResponse);
  } else if (reco_data->leaf_query.method == METHOD_GET_INDEX_ITEM_INFO) {
    PLUGIN_POST_PRECESS(reco::leafserver::GetIndexItemInfoResponseHa3);
  } else if (reco_data->leaf_query.method == METHOD_GET_INDEX_QUEUE) {
    PLUGIN_POST_PRECESS(reco::leafserver::GetIndexQueueResponse);
  } else if (reco_data->leaf_query.method == METHOD_GET_INDEX_QUEUE_UNSORT) {
    PLUGIN_POST_PRECESS(reco::leafserver::GetIndexQueueUnsortResponse);
  } else if (reco_data->leaf_query.method == METHOD_RELOAD_FILE) {
    PLUGIN_POST_PRECESS(reco::dm::ReloadFileResponse);
  }

  reco_data->http_code = 200;
  SendReply(reco_data);
}

void XssPluginWorker::stop() {
  LOG(ERROR) << "XssPluginWorker begin stop..";
  InnerStop();
  base::SleepForSeconds(3);
  LOG(ERROR) << "XssPluginWorker stopped";
}

// ----------------------------------------------------------------------------
void LoadLRModel() {
  LOG(INFO) << "begin to load lr batch model.";
  CHECK(reco::reco_model::RecoModelProc::Instance()->Initialize()) << "reco model init failed";
  LOG(INFO) << "succ to load lr batch model!";
}

void LoadPOIData() {
  LOG(INFO) << "begin to load poi data. dir=" << reco::leafserver::FLAGS_reco_leaf_data_dir;
  CHECK(reco::poi::CityAreaHashSearcher::instance().Load(reco::leafserver::FLAGS_reco_leaf_data_dir));
}

bool XssPluginWorker::InnerStop() {
  LOG(ERROR) << "stop leaf_impl_..";
  if (leaf_impl_ != NULL) {
    delete leaf_impl_;
  }

  LOG(ERROR) << "stop NewsMapProc..";
  reco::news_map::NewsMapProc::instance().Stop();

  LOG(ERROR) << "delete leaf cache..";
  reco::leafserver::LeafCache::Release();

  LOG(INFO) << "stop model server api..";
  if (::FLAGS_open_model_server_wd) {
    reco::model_server::ModelServerAPIIns::instance().Stop();
  }

  LOG(INFO) << "stop dict server api..";
  reco::dictserver::DictServerAPIIns::instance().Stop();

  LOG(ERROR) << "stop global data..";
  reco::leafserver::LeafDataManager::instance().Release();

  return true;
}

bool XssPluginWorker::InnerInit() {
  LOG(INFO) << "dict server init..";
  reco::dictserver::DictServerAPIIns::instance().Init();
  LOG(INFO) << "dict server init done";

  net::counter::HttpCounterExport();

  // lr 加载模型
//  thread::Thread load_lr_model_thread;
//  load_lr_model_thread.Start(NewCallback(&LoadLRModel));

  // 加载 poi 数据
  thread::Thread load_poi_data_thread;
  load_poi_data_thread.Start(NewCallback(&LoadPOIData));
  load_poi_data_thread.Join();

  // model server api
  if (::FLAGS_open_model_server_wd) {
    reco::model_server::ModelServerAPIIns::instance().Init();
  }

  // global data
  CHECK(reco::leafserver::LeafDataManager::instance().Init(FLAGS_work_thread_num));
  LOG(INFO) << "LeafDataManager init finish";

  reco::leafserver::LeafCache::SetRedisCli(reco::leafserver::LeafDataManager::instance().redis);

  // 新闻地图加载
  reco::news_map::NewsMapProc::instance().Start(reco::leafserver::LeafDataManager::instance().news_index);

  LOG(INFO) << "async thread start succ.";
  leaf_impl_ = new reco::leafserver::LeafImpl();

  reco::http_communicator::HttpClient& http_client = reco::http_communicator::HttpClientIns::instance();
  http_client.Init();
  http_client.Start();
  LOG(INFO) << "http client start succ.";

  LOG(INFO) << "leaf plugin start";

  inited_ = true;

  return true;
}

bool XssPluginWorker::SendReply(RecoData* reco_data) {
  std::string base64_res;
  if(!base::Base64Encode(reco_data->result, &base64_res)) {
    LOG(ERROR) << "Base64Encode fail:" << reco_data->result;
    delete reco_data;
    return false;
  }

  anet::HTTPPacket *reply = new anet::HTTPPacket;
  reply->setBody(base64_res.c_str(), base64_res.length());
  reply->setKeepAlive(reco_data->isKeepAlive);
  reply->setPacketType(anet::HTTPPacket::PT_RESPONSE);
  reply->setStatusCode(reco_data->http_code);

  if (!reco_data->isKeepAlive) {
    reco_data->connection->setWriteFinishClose(true);
  }

  COUNTERS_leaf__plugin_process_count.Increase(1);
  if (!reco_data->connection->postPacket(reply)) {
    // IMPORTANT!
    const int64 stop_time = base::GetTimestamp();
    const int64 spent_time = (stop_time - reco_data->start_time)/ 1000;
    COUNTERS_leaf__plugin_process_time.Increase(spent_time);
    reply->free();
    LOG(ERROR) << "pret=-1 ts=" << spent_time << " query=" << reco_data->query;
    delete reco_data;
    return false;
  }

  const uint64 stop_time = base::GetTimestamp();
  const int64 spent_time = (stop_time - reco_data->start_time)/ 1000;
  COUNTERS_leaf__plugin_process_time.Increase(spent_time);
  VLOG(1) << "pret=1 ts=" << spent_time << " bodylen=" << base64_res.length() << " query=" << reco_data->query;

  delete reco_data;
  return true;
}

/**
 *    query格式示例：
 *        service=reaco_leaf&method=xxx&args=xxx
 *
 */
bool XssPluginWorker::ParseQuery(const std::string& query, LeafQuery* q) {
  const std::string KEYVALUE_SEPARATOR = "&";
  const std::string KEYVALUE_PAIR_SEPARATOR = "=";
  const std::string KNAME_SERVICE= "service";
  const std::string KNAME_METHOD= "method";
  const std::string KNAME_ARGS= "args";

  std::map<std::string, std::string> kv_map;

  autil::StringTokenizer tokenizer(query, KEYVALUE_SEPARATOR,
                                   autil::StringTokenizer::TOKEN_IGNORE_EMPTY | autil::StringTokenizer::TOKEN_TRIM);
  for (autil::StringTokenizer::Iterator iter = tokenizer.begin();
       iter != tokenizer.end(); ++iter) {
    autil::StringTokenizer kvit(*iter, KEYVALUE_PAIR_SEPARATOR,
                                autil::StringTokenizer::TOKEN_TRIM);
    if (kvit.getNumTokens() == 0) {
      continue;
    } else if (kvit.getNumTokens() == 1) {
      kv_map[kvit[0]] = "true";
    } else if (kvit.getNumTokens() == 2) {
      kv_map[kvit[0]] = kvit[1];
    } else if (kvit.getNumTokens() > 2) {
      LOG(ERROR) << "arg value not encoded:" << kvit[0];
      return false;
    }
  }

  if (kv_map.find(KNAME_METHOD) == kv_map.end()) {
    LOG(ERROR) << "invalid query, " << KNAME_METHOD << " not exist";
    return false;
  } else {
    if (kv_map[KNAME_METHOD] == "") {
      LOG(ERROR) << "invalid query, " << KNAME_METHOD << " empty";
      return false;
    } else  {
      q->method= kv_map[KNAME_METHOD];
    }
  }

  if (kv_map.find(KNAME_ARGS) == kv_map.end()) {
    LOG(ERROR) << "invalid query, " << KNAME_ARGS << " not exist";
    return false;
  } else {
    if (kv_map[KNAME_ARGS] == "") {
      LOG(ERROR) << "invalid query, " << KNAME_ARGS << " empty";
      return false;
    } else  {
      std::string str;
      if(!reco::common::DecodeUrlComponent(kv_map[KNAME_ARGS].c_str(), &str)) {
        LOG(ERROR) << "DecodeUrlComponent fail, invalid args: " << kv_map[KNAME_ARGS];
        return false;
      }
      if(!base::Base64Decode(str, &(q->args))) {
        LOG(ERROR) << "Base64Decode fail : " << str;
        return false;
      }
    }
  }

  return true;
}

extern "C"
PluginWorker* createInstance() {
  return new XssPluginWorker;
}

extern "C"
void destroyInstance(PluginWorker* worker) {
  delete worker;
}
}
}
