#include "reco/serv/reco_leaf_plugin/plugin/reco_leaf_plugin.h"

int main() {
  athena::container_worker::XssPluginWorker worker;
  worker.stop();

  return 0;
}
