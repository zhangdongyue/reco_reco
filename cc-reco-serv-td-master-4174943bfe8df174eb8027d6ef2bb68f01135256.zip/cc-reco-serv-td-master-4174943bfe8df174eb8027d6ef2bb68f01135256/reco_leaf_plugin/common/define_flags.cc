#include "reco/serv/reco_leaf_plugin/common/define_flags.h"

namespace reco {
DEFINE_string(log_kafka_brokers, "127.0.0.1:9092", "elk kafka broker");
DEFINE_string(target_server, "", "news index target server");

namespace leafserver {
DEFINE_int32(work_thread_num, 10, "work thread num");
DEFINE_bool(load_fac_machine_model, false, "是否加载fac machine模型");
//DEFINE_double(mid_timelevel_boost, -0.2, "");
//DEFINE_double(low_timelevel_boost, -0.4, "");
}
}
