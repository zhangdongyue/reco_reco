#include "reco/serv/reco_leaf_plugin/common/leaf_cache.h"

#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/thread/blocking_var.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

using std::string;
using reco::ExpiryMap;

namespace reco {
namespace leafserver {
DEFINE_int32(cache_exp_seconds, 0, "cache exp time in seconds, 0 is close cache");
DEFINE_int32(leaf_cache_block_num, 10000, "cache_block_num");
DEFINE_int32(cache_expire_thread_num, 2, "cache exp thread num");
DEFINE_bool(cache_only_in_memory, false, "cache exp time in seconds, 0 is close cache");

// DEFINE_int64_counter(leaf, cache_req_total, 0, "");
DEFINE_int64_counter(leaf, cache_hit_total, 0, "");
// DEFINE_int64_counter(leaf, cache_set_total, 0, "");

const int LeafCache::kItemIssuedExpireSnds = 3 * 24 * 60 * 60;
ExpiryMap<string, string>* LeafCache::cache_ = new ExpiryMap<string, string>(10 * 60, FLAGS_leaf_cache_block_num, FLAGS_cache_expire_thread_num );
reco::redis::RedisCli * LeafCache::redis_ = NULL;

inline std::string ConstructItemIssuedKey(uint64 item_id) {
  return base::StringPrintf("LEAF_ItemIssuedCnt_%lu", item_id);
}

bool LeafCache::SetCachedReco(const std::string& key, const std::string& value, int cache_exp_seconds) {
  // COUNTERS_leaf__cache_set_total.Increase(1);

  if (cache_) {
    cache_->Add(key, value);
  }

  if (!FLAGS_cache_only_in_memory) {
    if (!redis_->SetEx(key, value, cache_exp_seconds)) {
      LOG(WARNING) << "set reco cache to redis_ fail. ";
      return false;
    }
  }

  return true;
}

bool LeafCache::SetCachedReco(const std::string& key, const std::string& value) {
  return SetCachedReco(key, value, FLAGS_cache_exp_seconds);
}

bool LeafCache::GetCachedReco(const std::string& key, std::string* value) {
  // COUNTERS_leaf__cache_req_total.Increase(1);
  value->clear();

  bool hit_cache = false;
  if (cache_ && cache_->FindSilently(key, value)) {
    COUNTERS_leaf__cache_hit_total.Increase(1);
    hit_cache = true;
    // do nothing
  } else if (!FLAGS_cache_only_in_memory) {
    value->clear();
    if (redis_->Get(key, value) == 0) {
      hit_cache = true;
      if (cache_) {
        cache_->Add(key, *value);
      }
    }
    // if (redis->Get(key, value) == 0) {
    //   if (value->empty())
    //     return false;

    //   if (cache_) {
    //     cache_->Add(key, *value);
    //   }
    // } else {
    //   return false;
    // }
  }

  return hit_cache;
  // return (!value->empty());
}

bool LeafCache::GetItemIssuedCnt(uint64 item_id, int64* cnt) {
  const std::string& key = ConstructItemIssuedKey(item_id);
  std::string value;
  int ret = redis_->Get(key, &value);
  if (ret == -1) {
    return false;
  } else if (ret == 1) {
    *cnt = 0;
    return true;
  }

  if (value.empty() || !base::StringToInt64(value, cnt)) {
    LOG(ERROR) << "item issued cnt field error, value:" << value;
    return false;
  }

  return true;
}

bool LeafCache::IncItemIssuedCnt(uint64 item_id, int64 times) {
  if (FLAGS_cache_exp_seconds <= 0) {
    LOG(WARNING) << "cache close!.";
    return false;
  }

  const std::string& key = ConstructItemIssuedKey(item_id);
  if (!redis_->IncrBy(key, times)) {
    LOG(ERROR) << "incr item issued cnt fail, key:" << key;
    return false;
  }

  redis_->Expire(key, kItemIssuedExpireSnds);
  return true;
}
}  // namespace leafserver
}  // namespace reco
