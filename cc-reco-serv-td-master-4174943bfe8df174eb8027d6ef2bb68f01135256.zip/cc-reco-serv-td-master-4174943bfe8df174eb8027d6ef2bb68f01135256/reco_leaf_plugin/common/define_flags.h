#pragma once

#include "base/common/gflags.h"

namespace reco {
DECLARE_string(log_kafka_brokers);
DECLARE_string(target_server);

namespace leafserver {
// outer
DECLARE_int32(dict_reload_port);
DECLARE_bool(fm_score_on);
DECLARE_string(reco_leaf_data_dir);
// inner
DECLARE_int32(work_thread_num);
DECLARE_bool(load_fac_machine_model);
DECLARE_double(mid_timelevel_boost);
DECLARE_double(low_timelevel_boost);
}
}
