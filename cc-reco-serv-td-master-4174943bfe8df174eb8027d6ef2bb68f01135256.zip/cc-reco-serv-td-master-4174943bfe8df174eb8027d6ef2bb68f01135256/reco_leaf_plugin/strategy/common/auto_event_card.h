#pragma once

#include <vector>

#include "base/container/dense_hash_set.h"

#include "reco/bizc/reco_index_ha3/item_info.h"
#include "reco/bizc/reco_index_ha3/news_index_ha3.h"
#include "reco/serv/reco_leaf_plugin/strategy/common/reco_request.h"

namespace reco {
namespace leafserver {

class AutoEventCard {
 public:
  AutoEventCard();
  virtual ~AutoEventCard();

  void Clear();
  void SetItemId(reco::NewsIndex* news_index, uint64 item_id);
  bool IsAutoEventCard(uint64 item_id) const;
  void ExtractCandidates(reco::NewsIndex* news_index,
                         const RecoRequest* reco_request);
  bool CanAssembleCard(base::dense_hash_set<uint64>* item_dedup,
                       reco::ItemInfo* item_info);

  bool is_valid() const;
  uint64 item_id() const;
  const std::vector<ItemInfo>& sub_items() const;

 private:
  bool is_valid_;
  uint64 item_id_;
  std::vector<ItemInfo> sub_items_;

  std::set<uint64> prio_sub_item_ids_;

  std::vector<ItemInfo> candidates_;
  std::vector<int32> candidate_style_types_;
};

}  // namespace leafserver
}  // namespace reco
