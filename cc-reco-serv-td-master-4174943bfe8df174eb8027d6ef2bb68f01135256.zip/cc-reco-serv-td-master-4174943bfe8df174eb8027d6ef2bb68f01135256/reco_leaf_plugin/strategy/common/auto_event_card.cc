#include "reco/serv/reco_leaf_plugin/strategy/common/auto_event_card.h"

#include "reco/serv/reco_leaf_plugin/strategy/common/reco_request.h"
#include "reco/serv/reco_leaf_plugin/strategy/component/filter/news_filter.h"

namespace reco {
namespace leafserver {

namespace {
bool EventCardCandidateCompare(const ItemInfo& a, const ItemInfo& b) {
  return a.create_timestamp > b.create_timestamp;
}
}

AutoEventCard::AutoEventCard() {
  Clear();
}

AutoEventCard::~AutoEventCard() {
}

void AutoEventCard::Clear() {
  is_valid_ = false;
  item_id_ = 0u;
  sub_items_.clear();
  prio_sub_item_ids_.clear();
  candidates_.clear();
  candidate_style_types_.clear();
}

void AutoEventCard::SetItemId(reco::NewsIndex* news_index, uint64 item_id) {
  is_valid_ = true;
  item_id_ = item_id;
  VLOG(1) << "auto event card item_id " << item_id_;

  reco::UcBrowserDeliverSettingPtr ucb_setting_ptr;
  if (news_index->GetUCBSettingByItemId(item_id, &ucb_setting_ptr)) {
    const reco::UcBrowserDeliverSetting& ucb_setting = *(ucb_setting_ptr.get());
    for (int i = 0; i < ucb_setting.prio_sub_item_ids_size(); ++i) {
      prio_sub_item_ids_.insert(ucb_setting.prio_sub_item_ids(i));
      VLOG(1) << "auto event card prio_sub_item_id: " << ucb_setting.prio_sub_item_ids(i);
    }
  }
}

bool AutoEventCard::is_valid() const {
  return is_valid_;
}

bool AutoEventCard::IsAutoEventCard(uint64 item_id) const {
  return is_valid_ && item_id_ == item_id;
}

const std::vector<ItemInfo>& AutoEventCard::sub_items() const {
  return sub_items_;
}

void AutoEventCard::ExtractCandidates(reco::NewsIndex* news_index,
                                      const RecoRequest* reco_request) {
  if (!is_valid_) return;
  candidates_.clear();
  candidate_style_types_.clear();
  std::unordered_set<uint64> contain_ids;
  if (!news_index->GetContainIdsByItemId(item_id_, &contain_ids)) {
    VLOG(1) << "auto event card does NOT contain sub item ids";
    return;
  }
  VLOG(1) << "auto event card of " << item_id_ << " contains " << contain_ids.size() << " sub items";
  for (auto iter = contain_ids.begin(); iter != contain_ids.end(); ++iter) {
    reco::filter::FilterReason filter_reason;
    reco::ItemInfo item_info;
    if (news_index->GetItemInfoByItemId(*iter, &item_info, false)
        && !NewsFilter::IsGeneralFiltered(reco_request, reco_request->shown_dict,
                                          item_info, &filter_reason, true)) {
      item_info.strategy_type = reco::kManual;
      candidates_.push_back(item_info);
    } else {
      VLOG(1) << "auto event sub item " << *iter << " filtered by " << filter_reason;
    }
  }
  std::sort(candidates_.begin(), candidates_.end(), EventCardCandidateCompare);
  for (size_t i = 0; i < candidates_.size(); ++i) {
    candidate_style_types_.push_back(
        news_index->GetUCBStyleTypeByItemId(candidates_[i].item_id));
    VLOG(1) << "auto event card candidate: " << i << ", " << candidates_[i].item_id
            << ", " << candidates_[i].create_timestamp;
  }
  VLOG(1) << "auto event card candidate size: " << candidates_.size();
}

bool AutoEventCard::CanAssembleCard(base::dense_hash_set<uint64>* item_dedup,
                                    reco::ItemInfo* result_item) {
  base::dense_hash_set<uint64> local_dedup;
  local_dedup.set_empty_key(0);
  local_dedup.insert(item_dedup->begin(), item_dedup->end());
  // 1. 选择头图样式作为第一篇新闻
  for (size_t i = 0; i < candidates_.size(); ++i) {
    const ItemInfo& item_info = candidates_[i];
    const int32 style_type = candidate_style_types_[i];
    if (style_type == 10 && !NewsFilter::IsDeduped(item_info, &local_dedup)) {
      sub_items_.push_back(item_info);
      VLOG(1) << "event card sub item " << item_info.item_id << " is style_type=10";
      break;
    }
  }
  uint32_t max_sub_item_num = sub_items_.empty() ? 2u : 3u;
  VLOG(1) << "try to assemble event card: " << candidates_.size()
          << ", max sub item num: " << max_sub_item_num;
  // 2. 选运营指定下发的文章
  for (size_t i = 0; i < candidates_.size(); ++i) {
    if (sub_items_.size() >= max_sub_item_num) break;
    const ItemInfo& item_info = candidates_[i];
    if (prio_sub_item_ids_.find(item_info.item_id) != prio_sub_item_ids_.end()
        && !NewsFilter::IsDeduped(item_info, &local_dedup)) {
      sub_items_.push_back(item_info);
      VLOG(1) << "event card sub item " << item_info.item_id << " is prio";
    }
  }
  // 3. 选择剩余的子文
  for (size_t i = 0; i < candidates_.size(); ++i) {
    if (sub_items_.size() >= max_sub_item_num) break;
    const ItemInfo& item_info = candidates_[i];
    if (!NewsFilter::IsDeduped(item_info, &local_dedup)) {
      sub_items_.push_back(item_info);
    }
  }
  // 4. 如果只有一篇子文，退化成单条结果
  if (sub_items_.empty()) {
    VLOG(1) << "event card item " << result_item->item_id << " has no available sub items";
    return false;
  }
  if (sub_items_.size() == 1u) {
    // 退化成单条结果时需要有事件引导标签
    (*result_item) = sub_items_[0];
    VLOG(1) << "event card item changed to 1 item: " << sub_items_[0].item_id;
  }
  // 5. 加入去重列表
  for (size_t i = 0; i < sub_items_.size(); ++i) {
    bool r = NewsFilter::IsDeduped(sub_items_[i], item_dedup);
    VLOG(1) << "event card succ candidate: " << sub_items_[i].item_id
            << " " << sub_items_[i].category << " r:" << r;
  }

  return true;
}

}  // namespace leafserver
}  // namespace reco
