#include "reco/serv/reco_leaf_plugin/strategy/common/auto_assemble_card.h"

#include <set>
#include <string>

#include "reco/serv/reco_leaf_plugin/strategy/component/filter/news_filter.h"

namespace reco {
namespace leafserver {

DEFINE_bool(shutdown_auto_card_big_style, false, "是否关闭首条子文必须是大图的逻辑");

namespace {
bool AssembleCardCandidateExtInfoCompare(const AssembleCardCandidateExtInfo& a,
                                         const AssembleCardCandidateExtInfo& b) {
  if (a.source_type == b.source_type)
    return a.candidate_idx < b.candidate_idx;
  return a.source_type < b.source_type;
}
}

AutoAssembleCard::AutoAssembleCard() {
  Clear();
}

AutoAssembleCard::~AutoAssembleCard() {
}

void AutoAssembleCard::SetCardId(uint64 item_id) {
  item_id_ = item_id;
  is_valid_ = true;
  has_big_style_candidate_item_ = false;
}

bool AutoAssembleCard::IsAssembleCard(uint64 item_id) const {
  if (is_valid_ && item_id_ == item_id)
    return true;
  return false;
}

void AutoAssembleCard::Clear() {
  is_valid_ = false;
  has_big_style_candidate_item_ = false;
  item_id_ = 0u;
  sub_items_.clear();
  candidates_.clear();
  candidate_exts_.clear();
}

void AutoAssembleCard::AddCandidate(const ItemInfo& candidate, CandidateSourceType source_type) {
  VLOG(1) << "card candidate : " << candidate.item_id << " " << source_type << " " << candidate.category;
  candidate_exts_.push_back(AssembleCardCandidateExtInfo(source_type, candidates_.size()));
  candidates_.push_back(candidate);
  if (source_type == TOP_IMPORTANCE_BIG_STYLE) {
    has_big_style_candidate_item_ = true;
  }
}

void AutoAssembleCard::SortCandidates() {
  std::stable_sort(candidate_exts_.begin(), candidate_exts_.end(), AssembleCardCandidateExtInfoCompare);
  if (VLOG_IS_ON(1)) {
    for (size_t i = 0; i < candidate_exts_.size(); ++i) {
      const AssembleCardCandidateExtInfo& ext = candidate_exts_[i];
      const ItemInfo& info = candidates_[ext.candidate_idx];
      VLOG(1) << "card candidate sort: " << info.item_id << " " << ext.source_type << " " << info.category;
    }
  }
}

bool AutoAssembleCard::HasBigStyleCandidateItem() {
  if (FLAGS_shutdown_auto_card_big_style) return true;
  return has_big_style_candidate_item_;
}

bool AutoAssembleCard::CanAssembleCard(base::dense_hash_set<uint64>* item_dedup,
                                       reco::filter::FilterReason* filter_reason) {
  if (!HasBigStyleCandidateItem()) {
    (*filter_reason) = reco::filter::kNotHasBigStyleCandidateItemFiltered;
    VLOG(1) << "card has not big style candidate item, CANNOT build card";
    return false;
  }
  if (!is_valid_ || candidates_.size() < 3u) {
    VLOG(1) << "card candidates are less than 3, CANNOT build card";
    (*filter_reason) = reco::filter::kNotHasEnoughCandidateFiltered;
    return false;
  }
  base::dense_hash_set<uint64> local_dedup;
  local_dedup.set_empty_key(0);
  local_dedup.insert(item_dedup->begin(), item_dedup->end());
  std::set<std::string> dedup_cates;
  VLOG(1) << "card candidate_ext size: " << candidate_exts_.size() << " " << sub_items_.size();
  for (size_t i = 0; i < candidate_exts_.size(); ++i) {
    if (sub_items_.size() >= 3u) break;
    const AssembleCardCandidateExtInfo& ext = candidate_exts_[i];
    const ItemInfo& item = candidates_[ext.candidate_idx];
    if (ext.source_type == TOP_IMPORTANCE_BIG_STYLE
        || ext.source_type == TOP_IMPORTANCE_NORMAL
        || dedup_cates.find(item.category) == dedup_cates.end()) {
      if (!NewsFilter::IsDeduped(item, &local_dedup)) {
        if (!FLAGS_shutdown_auto_card_big_style
            && sub_items_.empty() && ext.source_type != TOP_IMPORTANCE_BIG_STYLE) {
          // 首条子文不是大图形式
          (*filter_reason) = reco::filter::kFirstSubItemIsNotsBigStyleFiltered;
          return false;
        }
        VLOG(1) << "card sub item: " << item.item_id << " " << item.category;
        sub_items_.push_back(item);
        dedup_cates.insert(item.category);
      }
    }
  }
  if (sub_items_.size() >= 3u) {
    for (size_t i = 0; i < sub_items_.size(); ++i) {
      bool r = NewsFilter::IsDeduped(sub_items_[i], item_dedup);
      VLOG(1) << "card succ candidate: " << sub_items_[i].item_id
              << " " << sub_items_[i].category << " r:" << r;
    }
    return true;
  }
  VLOG(1) << "card filtered candidates are less than 3, CANNOT build card";
  return false;
}

}  // namespace leafserver
}  // namespace reco
