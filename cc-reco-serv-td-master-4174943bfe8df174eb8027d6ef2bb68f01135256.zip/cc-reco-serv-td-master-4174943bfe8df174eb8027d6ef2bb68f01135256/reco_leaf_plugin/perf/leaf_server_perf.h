#pragma once

#include <vector>
#include <string>
#include <unordered_map>

#include "base/common/closure.h"
#include "base/thread/thread_pool.h"
#include "base/thread/thread.h"
#include "base/file/file_util.h"

#include "extend/web_server/web_server.h"
#include "extend/web_server/http_util.h"
#include "extend/web_server/service_handler.h"

#include "serving/recommending/proto/item_info.pb.h"
#include "serving/recommending/proto/recommending.pb.h"
#include "serving/recommending/reco_leaf_plugin/strategy/meta_manager.h"
#include "rpc/stumy/service.h"

namespace reco_leaf {
class MetaManager;
}

struct SimulateRequest {
  recommending::RecommendRequest reco_request;
  std::vector<recommending::ClickUpdateRequest> click_requests;
};

class LeafServerPerf {
 public:
  LeafServerPerf();
  
  ~LeafServerPerf();

  void Start();

  void Launch();

  void Stop();

 private:
  // void Handle(const std::vector<recommending::RecommendRequest>& requests,
  void Handle(const std::vector<SimulateRequest>& sim_requests,
              int id);

  bool HandleRecommendRequest(const recommending::RecommendRequest* request,
                              recommending::RecommendResponse* response);

  bool HandleClickRequest(const recommending::ClickUpdateRequest* request,
                          recommending::ClickUpdateResponse* response);

  void GenSimulateRequests(const base::FilePath& show_log_file,
                           const base::FilePath& click_log_file,
                           std::vector<SimulateRequest>* sim_requests);

  void TuneSleepTime();

  void Show();

  // UserProfile 的更新使用crontab
  // void UpdateUserProfileLoop();

 private:
  std::string leaf_ip_;
  const int   leaf_port_;
  // std::string user_ip_;
  // const int   user_port_;
  std::string click_ip_;
  const int   click_port_;

  thread::ThreadPool pool_;

  stumy::RpcChannel click_channel_;
  stumy::RpcChannel leaf_channel_;

  recommending::RecommendService::Stub* leaf_service_;
  recommending::ClickService::Stub* click_service_;

  double per_thread_qps_;
  int32 num_requests_;
  int32 num_threads_;
  atomic_int num_working_threads_;
  int32 sleep_interval_;  // in milli-seconds
  atomic_int num_request_sent_;
  int64 global_end_timestamp_;
  int64 global_start_timestamp_;

  std::vector<float> round_secs_;
  std::vector<bool> response_ok_;
  static const int large_int_ = 0x7fffffff;
};
