#pragma once
#include "base/common/basic_types.h"
#include "base/strings/string_number_conversions.h"
#include "reco/serv/reco_leaf_plugin/perf/request_pool.h"
#include "reco/serv/reco_leaf_plugin/perf/user_pool.h"
#include "reco/serv/reco_leaf_plugin/perf/define.h"
#include "reco/bizc/proto/leaf.pb.h"
#include "serving_base/utility/timer.h"
#include "base/time/timestamp.h"
#include "base/common/sleep.h"


namespace reco {


class WeMediaPressWorker {
 private:
  atomic_bool running_;
  UserPool* user_pool_;
  int qps_;
  int64 total_request_;

  thread::BlockingQueue<std::string>* item_queue_;
  thread::BlockingQueue<ResponseDumpInfo*>* response_queue_;
  thread::BlockingQueue<std::pair<leafserver::WeMediaRecommendRequest*,
      leafserver::WeMediaRecommendResponse*>>* reco_queue_;
  int queue_buff_size_;

 public:
  bool running() {
    return running_;
  }

  WeMediaPressWorker(UserPool* user_pool,
                     thread::BlockingQueue<ResponseDumpInfo*>* response_queue,
                     thread::BlockingQueue<std::pair<leafserver::WeMediaRecommendRequest*,
                     leafserver::WeMediaRecommendResponse*>>* reco_queue) {
    running_ = true;
    user_pool_ = user_pool;
    qps_ = FLAGS_qps;
    total_request_ = FLAGS_total_request;
    queue_buff_size_ = qps_ * 1000;

    response_queue_ = response_queue;
    reco_queue_ = reco_queue;
  }

  void run(int thread_id) {
    running_ = true;
    float coeff = qps_ / 1000.0;
    float p_gain = coeff * FLAGS_time_slice;
    if (p_gain < FLAGS_min_num_in_slice) {
      p_gain = FLAGS_min_num_in_slice;
    }
    int time_slice = (int) (p_gain / coeff);  // in ms
    int grain_num = (int) p_gain;  // num in slice

    LOG(INFO) << "Thread " << thread_id << " start.";

    int64 very_start = base::GetTimestamp() / 1000;
    int64 send_num = 0;
    int64 start = 0;
    int64 tick = -1;
    int total_send = 0;
    int total_err = 0;

    net::rpc::RpcClientChannel channel(FLAGS_leaf_server_ip, FLAGS_leaf_server_port);
    CHECK(channel.Connect());
    leafserver::RecommendService::Stub stub(&channel);

    while (running_) {
      if (send_num >= grain_num) {
        tick = base::GetTimestamp() / 1000;
        int64 time_consume = tick - start;
        if (time_consume <= time_slice) {
          base::SleepForMilliseconds(time_slice - time_consume);
        }
        send_num = 0;
        start = base::GetTimestamp() / 1000;
      }

      ResponseDumpInfo* dump_info = new ResponseDumpInfo();
      dump_info->send_timestamp = base::GetTimestamp() / 1000;

      net::rpc::RpcClientController rpc;
      leafserver::WeMediaRecommendRequest* request = new leafserver::WeMediaRecommendRequest();
      ConstructRequestFromUserPool(*dump_info, request);

      leafserver::WeMediaRecommendResponse* response = new leafserver::WeMediaRecommendResponse();
      stub.wemediaRecommend(&rpc, request, response, NULL);
      rpc.Wait();

      dump_info->response_timestamp = base::GetTimestamp() / 1000;
      dump_info->body_size = response->ByteSize();
      if (rpc.status() != net::rpc::RpcClientController::kOk || !response->success()) {
        LOG(ERROR) << "erro in request for reco result: "
                   << rpc.error_text() << " " << response->success();
      } else if (response->result_size() < 1) {
        LOG(ERROR) << "get empty reco result";
      } else {
        dump_info->status = 200;
        reco_queue_->Put(std::make_pair(request, response));
        if (response_queue_->Size() > queue_buff_size_) {
          LOG(INFO) << "response queue is full, sleep for 10 ms";
          base::SleepForMilliseconds(10);
        }
      }

      // should alway be success to add
      response_queue_->Put(dump_info);

      ++total_send;
      ++send_num;
      if (total_send > total_request_) {
        running_ = false;
        break;
      }
    }

    long final_end = base::GetTimestamp();

    LOG(INFO) << base::StringPrintf("Thread %d end, total send: %d total err: %d, total consume: %ld ms",
                                    thread_id, total_send, total_err, (final_end - very_start) / 1000);
  }

  void ConstructRequestFromUserPool(const ResponseDumpInfo& dump_info,
                                    leafserver::WeMediaRecommendRequest* request) {
    const UserIdentity& user = user_pool_->get_user();
    std::string reco_id_str = user.outer_id() + " req in " + base::Int64ToString(dump_info.send_timestamp);
    request->set_reco_id(reco_id_str);
    request->mutable_user()->CopyFrom(user);
    request->set_return_num(3);
    if (FLAGS_channel_id > 0) {
      request->set_channel_id(FLAGS_channel_id);
    }
  }
};
}
