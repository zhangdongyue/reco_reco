#include "reco/serv/reco_leaf_plugin/frame/connection_manager.h"
#include "reco/serv/reco_leaf_plugin/frame/config.h"
#include "reco/serv/user_server/frame/user_impl.h"

#include "base/testing/gtest.h"
#include "base/common/logging.h"

// XXX(pengdan): 跑 testcase 的前提:
// redis server 在 10.3.5.70:/home/pengdan/pd 开启
TEST(LeafServer, TestConnectionManager) {
  typedef std::vector<reco::leafserver::ServerInfo> ServerCluster;
  std::string yaml_config_file = "reco/serv/reco_leaf_plugin/frame/testdata/user_machine_test.list";

  const std::string redis_server_ip = "10.3.5.70";
  const int redis_server_port = 6379;
  const int rpc_server_port1 = 12590;
  const int rpc_server_port2 = 12591;

  // 0, 在本机开启两个 user server
  redis::Client *redis_client1 = new redis::Client(redis_server_ip, redis_server_port);
  redis::Client *redis_client2 = new redis::Client(redis_server_ip, redis_server_port);
  CHECK(redis_client1->Connect() && redis_client2->Connect())
      << "redis connect fatal, ip: " << redis_server_ip
      << ", port: " << redis_server_port;
  LOG(INFO) << "Redis(1,2) connect success!";
  reco::userserver::UserImpl user_impl1(redis_client1);
  reco::userserver::UserImpl user_impl2(redis_client2);
  net::rpc::RpcServer::Options option1, option2;
  option1.port = rpc_server_port1;
  option1.server_thread_num = 4;
  option2.port = rpc_server_port2;
  option2.server_thread_num = 4;
  net::rpc::RpcServer user_server1(option1);
  net::rpc::RpcServer user_server2(option2);
  user_server1.ExportService(&user_impl1);
  user_server2.ExportService(&user_impl2);
  CHECK(user_server1.Start()) << "Failed to start server1";
  CHECK(user_server2.Start()) << "Failed to start server2";

  // 1, test ConnectionManager
  {
    reco::leafserver::FLAGS_user_machine_cfg_path = yaml_config_file;
    EXPECT_TRUE(reco::leafserver::ConfigManager::LoadConfig());
    EXPECT_TRUE(reco::leafserver::ConnectionManager::InitConnection());
    std::vector<reco::userserver::UserService::Stub *> user_service;
    EXPECT_TRUE(reco::leafserver::ConnectionManager::GetUserServiceCluster("query1", &user_service));
    EXPECT_EQ(user_service.size(), 2U);
    {
      // 测试心跳, 验证 channel 可用
      net::rpc::RpcClientController rpc;
      reco::HeartBeatRequest request;
      reco::HeartBeatResponse response;
      request.set_hello(true);
      user_service[0]->heartBeat(&rpc, &request, &response, NULL);
      rpc.Wait();
      EXPECT_TRUE(response.success());

      net::rpc::RpcClientController rpc2;
      reco::HeartBeatRequest request2;
      reco::HeartBeatResponse response2;
      request2.set_hello(true);
      user_service[1]->heartBeat(&rpc2, &request2, &response2, NULL);
      rpc2.Wait();
      EXPECT_TRUE(response2.success());
    }
  }
}
