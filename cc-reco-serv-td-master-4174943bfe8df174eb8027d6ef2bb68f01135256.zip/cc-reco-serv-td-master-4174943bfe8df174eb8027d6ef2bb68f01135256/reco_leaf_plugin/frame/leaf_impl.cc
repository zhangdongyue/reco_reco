#include "reco/serv/reco_leaf_plugin/frame/leaf_impl.h"

#include "reco/base/common/atomic.h"
#include <set>
#include <string>
#include <vector>

#include "base/common/logging.h"
#include "base/common/gflags.h"
#include "base/common/vlog_is_on.h"
#include "base/file/file_path.h"
#include "nlp/common/nlp_util.h"

#include "reco/serv/reco_leaf_plugin/frame/leaf_controller.h"
#include "reco/serv/reco_leaf_plugin/frame/global_data.h"
#include "reco/serv/reco_leaf_plugin/frame/global_conf.h"

#include "reco/serv/reco_model/frame_ha3/reco_model_predict.h"
#include "reco/bizc/reco_index_ha3/news_index_ha3.h"

DEFINE_int32(max_block_time, 100, "timeout per req block waiting, ms, 1倍的时间降级，3倍的时间直接返回");
DEFINE_int32(max_resp_cost_ms, 600, "最大响应时间，超过这个值可以认为请求失败");

DEFINE_int64_counter(recommend, total_request, 0, "");
DEFINE_int64_counter(recommend, total_response_time, 0, "total response time, unit: ms");
DEFINE_int64_counter(recommend, max_response_time, 0, "max response time, unit: ms");

DEFINE_int64_counter(leaf, server_overload_total, 0, "");
DEFINE_int64_counter(leaf, server_demote_total, 0, "");
// interface request count
DEFINE_int64_counter(leaf, recommend_request_count, 0, "request count of recommend");
DEFINE_int64_counter(leaf, recommend_response_time, 0, "response time of recommend");
DEFINE_int64_counter(leaf, recommend_wait_time, 0, "response wait time of recommend");
DEFINE_int64_counter(leaf, recommend_timeout_cnt, 0, "");
DEFINE_int64_counter(leaf, reloadDict_request_count, 0, "request count of reloadDict");
DEFINE_int64_counter(leaf, reloadDict_response_time, 0, "response time of reloadDict");
DEFINE_int64_counter(leaf, checkIndex_request_count, 0, "request count of checkIndex");
DEFINE_int64_counter(leaf, checkIndex_response_time, 0, "response time of checkIndex");
DEFINE_int64_counter(leaf, getHotNews_request_count, 0, "request count of getHotNews");
DEFINE_int64_counter(leaf, getHotNews_response_time, 0, "response time of getHotNews");
DEFINE_int64_counter(leaf, verticalRecommend_request_count, 0, "request count of verticalRecommend");
DEFINE_int64_counter(leaf, verticalRecommend_response_time, 0, "response time of verticalRecommend");
DEFINE_int64_counter(leaf, getModelVersion_request_count, 0, "request count of getModelVersion");
DEFINE_int64_counter(leaf, getModelVersion_response_time, 0, "response time of getModelVersion");
DEFINE_int64_counter(leaf, setModelVersion_request_count, 0, "request count of setModelVersion");
DEFINE_int64_counter(leaf, setModelVersion_response_time, 0, "response time of setModelVersion");
DEFINE_int64_counter(leaf, reloadLeafConf_request_count, 0, "request count of reloadLeafConf");
DEFINE_int64_counter(leaf, reloadLeafConf_response_time, 0, "response time of reloadLeafConf");
DEFINE_int64_counter(leaf, wemediaRecommend_request_count, 0, "request count of wemediaRecommend");
DEFINE_int64_counter(leaf, wemediaRecommend_response_time, 0, "response time of wemediaRecommend");
DEFINE_int64_counter(leaf, getIndexItemInfo_request_count, 0, "request count of getIndexItemInfo");
DEFINE_int64_counter(leaf, getIndexItemInfo_response_time, 0, "response time of getIndexItemInfo");
DEFINE_int64_counter(leaf, imCardRecommend_request_count, 0, "request count of imCardRecommend");
DEFINE_int64_counter(leaf, imCardRecommend_response_time, 0, "response time of imCardRecommend");
DEFINE_int64_counter(leaf, sceneCardRecommend_request_count, 0, "request count of sceneCardRecommend");
DEFINE_int64_counter(leaf, sceneCardRecommend_response_time, 0, "response time of sceneCardRecommend");
DEFINE_int64_counter(leaf, getNewsMap_request_count, 0, "request count of getNewsMap");
DEFINE_int64_counter(leaf, getNewsMap_response_time, 0, "response time of getNewsMap");
DEFINE_int64_counter(leaf, getIndexStatus_request_count, 0, "request count of getIndexStatus");
DEFINE_int64_counter(leaf, getIndexStatus_response_time, 0, "response time of  getIndexStatus");
DEFINE_int64_counter(leaf, getIndexQueue_request_count, 0, "request count of getIndexQueue");
DEFINE_int64_counter(leaf, getIndexQueue_response_time, 0, "response time of getIndexQueue");
DEFINE_int64_counter(leaf, getIndexQueueUnsort_request_count, 0, "request count of getIndexQueueUnsort");
DEFINE_int64_counter(leaf, getIndexQueueUnsort_response_time, 0, "response time of getIndexQueueUnsort");
DEFINE_int64_counter(leaf, tagRecommend_request_count, 0, "request count of tagRecommend");
DEFINE_int64_counter(leaf, tagRecommend_response_time, 0, "response time of tagRecommend");
DEFINE_int64_counter(leaf, setCommandLineOption_request_count, 0, "request count of tagRecommend");
DEFINE_int64_counter(leaf, setCommandLineOption_response_time, 0, "response time of tagRecommend");

namespace reco {
namespace leafserver {
DEFINE_string(reco_leaf_data_dir, "./data", "the root dir for data");

LeafImpl::LeafImpl() {
  hostname_ = serving_base::GetHostName();
  LOG(INFO) << hostname_;
}

LeafImpl::~LeafImpl() {
}

void LeafImpl::recommend(const RecommendRequest* request,
                         RecommendResponse* response,
                         Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kRecommendReq);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}

void LeafImpl::recommend(const int64 timestamp,
                         const RecommendRequest* request,
                         RecommendResponse* response,
                         Closure* done) {
  COUNTERS_recommend__total_request.Increase(1);
  COUNTERS_leaf__recommend_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->set_success(false);
  response->set_hostname(hostname_);
  response->mutable_user_info()->mutable_identity()->CopyFrom(request->user());

  if (request->return_num() == 0) {
    LOG(ERROR) << "req num is 0:" << nlp::util::NormalizeLine(request->Utf8DebugString());
    return;
  }

  // timeout
  bool is_demote = false;
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  COUNTERS_leaf__recommend_response_time.Increase(waiting_us / 1000);
  if (waiting_us > FLAGS_max_block_time * 3 * 1000) {
    COUNTERS_leaf__server_overload_total.Increase(1);
    LOG(ERROR) << "server overload, do not process req.";
    return;
  } else if (waiting_us > FLAGS_max_block_time * 1 * 1000) {
    is_demote = true;
    COUNTERS_leaf__server_demote_total.Increase(1);
    LOG(WARNING) << "server demote.";
  }
  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  std::string err_message;
  if (!recommend_controller) {
    err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  recommend_controller->Recommend(is_demote, request, response);
  DLOG(ERROR) << "Step into Recommend3";

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  const int64 cost_us = timer.Stop();
  COUNTERS_recommend__total_response_time.Increase(cost_us / 1000);
  COUNTERS_leaf__recommend_response_time.Increase(cost_us / 1000);
  if (cost_us + waiting_us > FLAGS_max_resp_cost_ms * 1000) {
    COUNTERS_leaf__recommend_timeout_cnt.Increase(1);
  }

  return;
}

void LeafImpl::getHotNews(const GetHotNewsRequest* request,
                          GetHotNewsResponse* response,
                          Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kGetHotNewsReq);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}

void LeafImpl::getHotNews(const int64 timestamp,
                          const GetHotNewsRequest* request,
                          GetHotNewsResponse* response,
                          Closure* done) {
  COUNTERS_recommend__total_request.Increase(1);
  COUNTERS_leaf__getHotNews_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->set_success(false);

  // timeout
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  COUNTERS_leaf__getHotNews_response_time.Increase(waiting_us / 1000);
  if (waiting_us > FLAGS_max_block_time * 2 * 1000) {
    LOG(ERROR) << "server overload, do not process req.";
    COUNTERS_leaf__server_overload_total.Increase(1);
    return;
  }

  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  std::string err_message;
  if (!recommend_controller) {
    err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  if (recommend_controller->GetHotNews(request, response)) {
    response->set_success(true);
  }

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  COUNTERS_recommend__total_response_time.Increase(timer.Stop() / 1000);
  COUNTERS_leaf__getHotNews_response_time.Increase(timer.Stop() / 1000);
}

void LeafImpl::verticalRecommend(const VerticalRequest* request,
                                 VerticalResponse* response,
                                 Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kVerticalRecommend);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}

void LeafImpl::verticalRecommend(const int64 timestamp,
                                 const VerticalRequest* request,
                                 VerticalResponse* response,
                                 Closure* done) {
  COUNTERS_recommend__total_request.Increase(1);
  COUNTERS_leaf__verticalRecommend_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->set_success(false);

  // timeout
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  COUNTERS_leaf__verticalRecommend_response_time.Increase(waiting_us / 1000);
  if (waiting_us > FLAGS_max_block_time * 2 * 1000) {
    LOG(ERROR) << "server overload, do not process req.";
    COUNTERS_leaf__server_overload_total.Increase(1);
    return;
  }

  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  std::string err_message;
  if (!recommend_controller) {
    err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  if (recommend_controller->VerticalRecommend(request, response)) {
    response->set_success(true);
  }

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  COUNTERS_recommend__total_response_time.Increase(timer.Stop() / 1000);
  COUNTERS_leaf__verticalRecommend_response_time.Increase(timer.Stop() / 1000);
}

void LeafImpl::reloadLeafConf(const ReloadLeafConfRequest* request,
                              ReloadLeafConfResponse* response,
                              Closure* done) {
  COUNTERS_leaf__reloadLeafConf_request_count.Increase(1);
  ScopedClosure scoped_closure(done);
  response->set_success(false);

  if (!GlobalConf::ReloadConf(request->conf_field(), request->conf_value())) {
    std::string err_message = "fail to relaod conf, request: "
        + nlp::util::NormalizeLine(request->Utf8DebugString());
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  response->set_success(true);
}

void LeafImpl::getModelVersion(const ModelVerRequest* request,
                               ModelVerResponse* response,
                               Closure* done) {
  COUNTERS_leaf__getModelVersion_request_count.Increase(1);
  ScopedClosure scoped_closure(done);
  response->set_success(false);

  std::string err_message;
  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  if (!recommend_controller) {
    err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  if (recommend_controller->GetModelVersion(request, response)) {
    response->set_success(true);
  }

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  return;
}

void LeafImpl::setModelVersion(const ModelVerRequest* request,
                               ModelVerResponse* response,
                               Closure* done) {
  COUNTERS_leaf__setModelVersion_request_count.Increase(1);
  ScopedClosure scoped_closure(done);
  response->set_success(false);

  std::string err_message;
  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  if (!recommend_controller) {
    err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  if (recommend_controller->SetModelVersion(request, response)) {
    response->set_success(true);
  }

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  return;
}

void LeafImpl::wemediaRecommend(const reco::leafserver::WeMediaRecommendRequest* request,
                                reco::leafserver::WeMediaRecommendResponse* response,
                                Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kWemediaRecommend);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}

void LeafImpl::wemediaRecommend(const int64 timestamp,
                                const reco::leafserver::WeMediaRecommendRequest* request,
                                reco::leafserver::WeMediaRecommendResponse* response,
                                Closure* done) {
  COUNTERS_recommend__total_request.Increase(1);
  COUNTERS_leaf__wemediaRecommend_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->Clear();
  response->set_success(false);
  response->mutable_user_info()->mutable_identity()->CopyFrom(request->user());
  response->set_reco_id(request->reco_id());

  // timeout
  bool is_demote = false;
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  COUNTERS_leaf__wemediaRecommend_response_time.Increase(waiting_us / 1000);
  if (waiting_us > FLAGS_max_block_time * 3 * 1000) {
    LOG(ERROR) << "server overload, do not process req.";
    COUNTERS_leaf__server_overload_total.Increase(1);
    return;
  } else if (waiting_us > FLAGS_max_block_time * 1 * 1000) {
    is_demote = true;
    COUNTERS_leaf__server_demote_total.Increase(1);
    LOG(WARNING) << "server demote.";
  }
  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  if (!recommend_controller) {
    std::string err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  if (recommend_controller->WeMediaRecommend(is_demote, request, response)) {
    response->set_success(true);
  }

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  COUNTERS_recommend__total_response_time.Increase(timer.Stop() / 1000);
  COUNTERS_leaf__wemediaRecommend_response_time.Increase(timer.Stop() / 1000);
  return;
}

void LeafImpl::imCardRecommend(const reco::leafserver::ImCardRecoRequest* request,
                               reco::leafserver::ImCardRecoResponse* response,
                               Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kImCardRecommend);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}

void LeafImpl::imCardRecommend(const int64 timestamp,
                               const reco::leafserver::ImCardRecoRequest* request,
                               reco::leafserver::ImCardRecoResponse* response,
                               Closure* done) {
  COUNTERS_recommend__total_request.Increase(1);
  COUNTERS_leaf__imCardRecommend_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->Clear();
  response->set_success(false);
  response->mutable_user_info()->mutable_identity()->CopyFrom(request->user());

  // timeout
  bool is_demote = false;
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  COUNTERS_leaf__imCardRecommend_response_time.Increase(waiting_us / 1000);
  if (waiting_us > FLAGS_max_block_time * 3 * 1000) {
    LOG(ERROR) << "server overload, do not process req.";
    COUNTERS_leaf__server_overload_total.Increase(1);
    return;
  } else if (waiting_us > FLAGS_max_block_time * 1 * 1000) {
    is_demote = true;
    COUNTERS_leaf__server_demote_total.Increase(1);
    LOG(WARNING) << "server demote.";
  }
  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  if (!recommend_controller) {
    std::string err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  if (recommend_controller->ImCardRecommend(is_demote, request, response)) {
    response->set_success(true);
  }

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  COUNTERS_recommend__total_response_time.Increase(timer.Stop() / 1000);
  COUNTERS_leaf__imCardRecommend_response_time.Increase(timer.Stop() / 1000);
  return;
}

void LeafImpl::sceneCardRecommend(const reco::leafserver::SceneCardRecoRequest* request,
                                  reco::leafserver::SceneCardRecoResponse* response,
                                  Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kSceneCardRecommend);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}

void LeafImpl::sceneCardRecommend(const int64 timestamp,
                                  const reco::leafserver::SceneCardRecoRequest* request,
                                  reco::leafserver::SceneCardRecoResponse* response,
                                  Closure* done) {
  COUNTERS_recommend__total_request.Increase(1);
  COUNTERS_leaf__sceneCardRecommend_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->Clear();
  response->set_success(false);
  response->mutable_user_info()->mutable_identity()->CopyFrom(request->user());

  // timeout
  bool is_demote = false;
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  COUNTERS_leaf__sceneCardRecommend_response_time.Increase(waiting_us / 1000);
  if (waiting_us > FLAGS_max_block_time * 3 * 1000) {
    LOG(ERROR) << "server overload, do not process req.";
    COUNTERS_leaf__server_overload_total.Increase(1);
    return;
  } else if (waiting_us > FLAGS_max_block_time * 1 * 1000) {
    is_demote = true;
    COUNTERS_leaf__server_demote_total.Increase(1);
    LOG(WARNING) << "server demote.";
  }

  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  if (!recommend_controller) {
    std::string err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  if (recommend_controller->SceneCardRecommend(is_demote, request, response)) {
    response->set_success(true);
  }

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  COUNTERS_recommend__total_response_time.Increase(timer.Stop() / 1000);
  COUNTERS_leaf__sceneCardRecommend_response_time.Increase(timer.Stop() / 1000);

  return;
}

void LeafImpl::hotCardRecommend(const reco::leafserver::HotCardRecommendRequest* request,
                                reco::leafserver::HotCardRecommendResponse* response,
                                Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kHotCardRecommend);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}

void LeafImpl::hotCardRecommend(const int64 timestamp,
                                const reco::leafserver::HotCardRecommendRequest* request,
                                reco::leafserver::HotCardRecommendResponse* response,
                                Closure* done) {
  COUNTERS_recommend__total_request.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->Clear();
  response->set_success(false);
  response->set_reco_id(request->reco_id());
  response->set_item_id(0);
//  response->mutable_user_info()->mutable_identity()->CopyFrom(request->user());

  // timeout
  bool is_demote = false;
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  if (waiting_us > FLAGS_max_block_time * 3 * 1000) {
    LOG(ERROR) << "server overload, do not process req.";
    COUNTERS_leaf__server_overload_total.Increase(1);
    return;
  } else if (waiting_us > FLAGS_max_block_time * 1 * 1000) {
    is_demote = true;
    COUNTERS_leaf__server_demote_total.Increase(1);
    LOG(WARNING) << "server demote.";
  }

  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  if (!recommend_controller) {
    std::string err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  if (recommend_controller->HotCardRecommend(is_demote, request, response)) {
    response->set_success(true);
  }

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  COUNTERS_recommend__total_response_time.Increase(timer.Stop() / 1000);
  return;
}

void LeafImpl::Process(StWorkParam param) {
  static std::atomic<int64> max_time{0};
  static std::atomic<int64> last_reset_time{0};
  serving_base::Timer timer;
  timer.Start();
  switch (param.type) {
    case kRecommendReq:
      recommend(param.time_stamp,
                static_cast<const RecommendRequest*>(param.request),
                static_cast<RecommendResponse*>(param.response),
                param.done);
      break;
    case kGetHotNewsReq:
      getHotNews(param.time_stamp,
                 static_cast<const GetHotNewsRequest*>(param.request),
                 static_cast<GetHotNewsResponse*>(param.response),
                 param.done);
      break;
    case kVerticalRecommend:
      verticalRecommend(param.time_stamp,
                        static_cast<const VerticalRequest*>(param.request),
                        static_cast<VerticalResponse*>(param.response),
                        param.done);
      break;
    case kWemediaRecommend:
      wemediaRecommend(param.time_stamp,
                       static_cast<const WeMediaRecommendRequest*>(param.request),
                       static_cast<WeMediaRecommendResponse*>(param.response),
                       param.done);
      break;
    case kImCardRecommend:
      imCardRecommend(param.time_stamp,
                      static_cast<const ImCardRecoRequest*>(param.request),
                      static_cast<ImCardRecoResponse*>(param.response),
                      param.done);
      break;
    case kNewsMapRecommend:
      getNewsMap(param.time_stamp,
                 static_cast<const NewsMapRequest*>(param.request),
                 static_cast<NewsMapResponse*>(param.response),
                 param.done);
      break;
    case kSceneCardRecommend:
      sceneCardRecommend(param.time_stamp,
                         static_cast<const SceneCardRecoRequest*>(param.request),
                         static_cast<SceneCardRecoResponse*>(param.response),
                         param.done);
      break;
    case kHotCardRecommend:
      hotCardRecommend(param.time_stamp,
                       static_cast<const HotCardRecommendRequest*>(param.request),
                       static_cast<HotCardRecommendResponse*>(param.response),
                       param.done);
      break;
    case kTagRecommend:
      tagRecommend(param.time_stamp,
                   static_cast<const TagRecommendRequest*>(param.request),
                   static_cast<TagRecommendResponse*>(param.response),
                   param.done);
      break;
    case kGetIndexItemInfo:
      getIndexItemInfo(param.time_stamp,
                       static_cast<const GetIndexItemInfoRequest*>(param.request),
                       static_cast<GetIndexItemInfoResponseHa3*>(param.response),
                       param.done);
      break;
    case kGetIndexQueue:
      getIndexQueue(param.time_stamp,
                    static_cast<const GetIndexQueueRequest*>(param.request),
                    static_cast<GetIndexQueueResponse*>(param.response),
                    param.done);
      break;
    case kGetIndexQueueUnsort:
      getIndexQueueUnsort(param.time_stamp,
                          static_cast<const GetIndexQueueUnsortRequest*>(param.request),
                          static_cast<GetIndexQueueUnsortResponse*>(param.response),
                          param.done);
      break;
    default:
      LOG(ERROR) << "invalid req type: " << param.type;
      break;
  }
  const int64 cost_us = timer.Stop();
  const int64 now_time = base::GetTimestamp();
  if (now_time - last_reset_time >= 1000000) {
    max_time = cost_us;
    last_reset_time = now_time;
    COUNTERS_recommend__max_response_time.Reset(max_time / 1000);
  } else if (cost_us > max_time) {
    max_time = cost_us;
    COUNTERS_recommend__max_response_time.Reset(max_time / 1000);
  }
  return;
}

void LeafImpl::getNewsMap(const reco::leafserver::NewsMapRequest* request,
                          reco::leafserver::NewsMapResponse* response,
                          Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kNewsMapRecommend);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}

void LeafImpl::getNewsMap(const int64 timestamp,
                          const reco::leafserver::NewsMapRequest* request,
                          reco::leafserver::NewsMapResponse* response,
                          Closure* done) {
  COUNTERS_recommend__total_request.Increase(1);
  COUNTERS_leaf__getNewsMap_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->set_success(false);
  response->set_reco_id(request->reco_id());

  // timeout
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  COUNTERS_leaf__getNewsMap_response_time.Increase(waiting_us / 1000);
  if (waiting_us > FLAGS_max_block_time * 2 * 1000) {
    LOG(ERROR) << "server overload, do not process req.";
    COUNTERS_leaf__server_overload_total.Increase(1);
    return;
  }

  std::string err_message;
  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  if (!recommend_controller) {
    err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  recommend_controller->GetNewsMap(request, response);
  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);

  COUNTERS_recommend__total_response_time.Increase(timer.Stop() / 1000);
  COUNTERS_leaf__getNewsMap_response_time.Increase(timer.Stop() / 1000);
}

void LeafImpl::tagRecommend(const reco::leafserver::TagRecommendRequest* request,
                            reco::leafserver::TagRecommendResponse* response,
                            Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kTagRecommend);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}

void LeafImpl::tagRecommend(const int64 timestamp,
                            const reco::leafserver::TagRecommendRequest* request,
                            reco::leafserver::TagRecommendResponse* response,
                            Closure* done) {
  COUNTERS_recommend__total_request.Increase(1);
  COUNTERS_leaf__tagRecommend_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->set_success(false);

  // timeout
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  COUNTERS_leaf__tagRecommend_response_time.Increase(waiting_us / 1000);
  if (waiting_us > FLAGS_max_block_time * 2 * 1000) {
    LOG(ERROR) << "server overload, do not process req.";
    COUNTERS_leaf__server_overload_total.Increase(1);
    return;
  }

  std::string err_message;
  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  if (!recommend_controller) {
    err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  recommend_controller->TagRecommend(*request, response);

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  COUNTERS_recommend__total_response_time.Increase(timer.Stop() / 1000);
  COUNTERS_leaf__tagRecommend_response_time.Increase(timer.Stop() / 1000);
}

void LeafImpl::getIndexItemInfo(const GetIndexItemInfoRequest* request,
                                GetIndexItemInfoResponseHa3* response,
                                Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kGetIndexItemInfo);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}


void LeafImpl::getIndexItemInfo(const int64 timestamp,
                                const GetIndexItemInfoRequest* request,
                                GetIndexItemInfoResponseHa3* response,
                                Closure* done) {
  COUNTERS_leaf__getIndexItemInfo_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->set_success(false);
  response->set_item_id(0);

  // timeout
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  COUNTERS_leaf__getIndexItemInfo_response_time.Increase(waiting_us / 1000);

  std::string err_message;
  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  if (!recommend_controller) {
    err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  if (recommend_controller->GetIndexItemInfo(*request, response)) {
    response->set_success(true);
  }

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  COUNTERS_leaf__getIndexItemInfo_response_time.Increase(timer.Stop() / 1000);
}

void LeafImpl::getIndexQueue(const GetIndexQueueRequest* request,
                             GetIndexQueueResponse* response,
                             Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kGetIndexQueue);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}

void LeafImpl::getIndexQueue(const int64 timestamp,
                             const GetIndexQueueRequest* request,
                             GetIndexQueueResponse* response,
                             Closure* done) {
  COUNTERS_recommend__total_request.Increase(1);
  COUNTERS_leaf__getIndexQueue_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->set_success(false);

  // timeout
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  COUNTERS_leaf__getIndexQueue_response_time.Increase(waiting_us / 1000);
  if (waiting_us > FLAGS_max_block_time * 2 * 1000) {
    LOG(ERROR) << "server overload, do not process req.";
    COUNTERS_leaf__server_overload_total.Increase(1);
    return;
  }

  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  std::string err_message;
  if (recommend_controller == NULL) {
    err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  if (recommend_controller->GetIndexQueue(*request, response)) {
    response->set_success(true);
  }

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  COUNTERS_recommend__total_response_time.Increase(timer.Stop() / 1000);
  COUNTERS_leaf__getIndexQueue_response_time.Increase(timer.Stop() / 1000);
}

void LeafImpl::getIndexQueueUnsort(const GetIndexQueueUnsortRequest* request,
                                   GetIndexQueueUnsortResponse* response,
                                   Closure* done) {
  StWorkParam param(request, response, done, base::GetTimestamp(), kGetIndexQueueUnsort);
  thread::AutoLock lock(&mutex_);
  if (LeafDataManager::instance().work_thread_pool)
    LeafDataManager::instance().work_thread_pool->AddTask(NewCallback(this, &LeafImpl::Process, param));
}

void LeafImpl::getIndexQueueUnsort(const int64 timestamp,
                                   const GetIndexQueueUnsortRequest* request,
                                   GetIndexQueueUnsortResponse* response,
                                   Closure* done) {
  COUNTERS_recommend__total_request.Increase(1);
  COUNTERS_leaf__getIndexQueueUnsort_request_count.Increase(1);
  serving_base::Timer timer;
  timer.Start();

  ScopedClosure scoped_closure(done);
  response->set_success(false);

  // timeout
  const int64 waiting_us = base::GetTimestamp() - timestamp;
  COUNTERS_recommend__total_response_time.Increase(waiting_us / 1000);
  COUNTERS_leaf__getIndexQueueUnsort_response_time.Increase(waiting_us / 1000);
  if (waiting_us > FLAGS_max_block_time * 2 * 1000) {
    LOG(ERROR) << "server overload, do not process req.";
    COUNTERS_leaf__server_overload_total.Increase(1);
    return;
  }

  LeafController* recommend_controller = LeafDataManager::instance().GetControllerItem();
  std::string err_message;
  if (recommend_controller == NULL) {
    err_message = "Leaf server busy[recommend_controller=NULL], try argin later";
    LOG(ERROR) << err_message;
    response->set_err_message(err_message);
    return;
  }

  if (recommend_controller->GetIndexQueueUnsort(*request, response)) {
    response->set_success(true);
  }

  LeafDataManager::instance().ReleaseControllerItem(recommend_controller);
  COUNTERS_recommend__total_response_time.Increase(timer.Stop() / 1000);
  COUNTERS_leaf__getIndexQueueUnsort_response_time.Increase(timer.Stop() / 1000);
}

}  // end of namespace leafserver
}  // end of namespace reco
