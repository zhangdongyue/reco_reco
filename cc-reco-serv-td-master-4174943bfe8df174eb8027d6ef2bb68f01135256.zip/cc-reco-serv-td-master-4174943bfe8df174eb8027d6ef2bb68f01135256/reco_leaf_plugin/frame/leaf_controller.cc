#include "reco/serv/reco_leaf_plugin/frame/leaf_controller.h"

#include <string>
#include <vector>

#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/scoped_ptr.h"
#include "base/common/callback.h"
#include "base/thread/thread.h"
#include "base/thread/sync.h"
#include "base/random/pseudo_random.h"

#include "nlp/common/nlp_util.h"
#include "net/counter/export.h"
#include "query/tree/query_tree.h"
#include "query/tree/tree_util.h"
#include "reco/bizc/common/channel_define.h"

#include "reco/serv/reco_leaf_plugin/frame/inner/video_communicator.h"
#include "reco/serv/reco_leaf_plugin/frame/global_data.h"
#include "reco/serv/reco_leaf_plugin/frame/global_conf.h"
#include "reco/serv/reco_leaf_plugin/strategy/component/debugger/reco_debugger.h"
#include "reco/serv/reco_leaf_plugin/strategy/common/reco_utils.h"
//#include "reco/serv/reco_leaf_plugin/strategy/component/scorer/model_inner/model_buffer_manager.h"
//#include "reco/serv/reco_leaf_plugin/strategy/component/scorer/fm_inner/fm_buffer_manager.h"
#include "reco/serv/reco_leaf_plugin/strategy/external_api/external_api.h"
#include "reco/serv/reco_leaf_plugin/strategy/external_api/tag_reco.h"
#include "reco/serv/reco_leaf_plugin/strategy/rank_hooker.h"
#include "reco/serv/reco_leaf_plugin/strategy/common/profile_type.h"

DEFINE_int64_counter(recommend, success_response_num, 0, "success num");
DEFINE_int64_counter(recommend, reco_error_num, 0, "recommend error num");
DEFINE_int64_counter(recommend, channel_null_response_num, 0, "推荐频道无数据的请求数");
DEFINE_int64_counter(recommend, strategy_time, 0, "strategy time, unit: us");
DEFINE_int64_counter(recommend, null_response_num, 0, "所有请求无数据的数量");
DEFINE_int64_counter(recommend, has_video_candidates_num, 0, "所有请求有视频候选集的数量");
DEFINE_int64_counter(recommend, reco_channel_num, 0, "所有请求有视频候选集的数量");
DEFINE_int64_counter(recommend, reco_result_num, 0, "reco result time");
DEFINE_int64_counter(http, send_video_http_req_fail_count, 0, "发送视频请求失败数量");
DEFINE_int64_counter(http, send_video_http_req_succ_count, 0, "发送视频请求成功数量");
DEFINE_int64_counter(http, send_video_http_req_total_count, 0, "发送视频请求总数量");

using std::string;
using std::vector;

namespace reco {
namespace leafserver {

DEFINE_int32(video_server_return_num, 5, "video server return num");
DEFINE_int32(video_server_percent_analyze_cycle, 10, "video server req timeout analyze cycle second");
DEFINE_int32(video_server_req_timeout_ms, 200, "video server request timeout ms");

using reco::user::UserInfo;

DECLARE_bool(use_user_cache);

LeafController::LeafController() {
  ranker_ = new RankHooker();
  external_api_ = new ExternalApi();

  global_data_ = &LeafDataManager::instance();
  CHECK(global_data_);

  tag_reco_ = new TagReco();
}

LeafController::~LeafController() {
  delete external_api_;
  delete ranker_;
  delete tag_reco_;
}

void LeafController::SetUserInfoToResponse(const RecommendRequest *request,
                                           const UserInfo& orig_user_info, RecommendResponse *response) {
  UserInfo user_info;
  user_info.mutable_identity()->CopyFrom(orig_user_info.identity());
  for (int i = 0; i < request->user_field_type_size(); ++i) {
    switch (request->user_field_type(i)) {
      case reco::user::kUserRole:
        if (orig_user_info.has_user_role()) {
          user_info.mutable_user_role()->CopyFrom(orig_user_info.user_role());
        }
        break;
      case reco::user::kChannelInfo:
        if (orig_user_info.has_channel_info()) {
          user_info.mutable_channel_info()->CopyFrom(orig_user_info.channel_info());
        }
        break;
      case reco::user::kProfile:
        if (orig_user_info.has_profile()) {
          user_info.mutable_profile()->CopyFrom(orig_user_info.profile());
        }
        break;
      case reco::user::kDmpProfile:
        if (orig_user_info.has_dmp_profile()) {
          user_info.mutable_dmp_profile()->CopyFrom(orig_user_info.dmp_profile());
        }
        break;
      case reco::user::kExploreProfile:
        if (orig_user_info.has_explore_profile()) {
          user_info.mutable_explore_profile()->CopyFrom(orig_user_info.explore_profile());
        }
        break;
      case reco::user::kSubscription:
        if (orig_user_info.has_subscription()) {
          user_info.mutable_subscription()->CopyFrom(orig_user_info.subscription());
        }
        break;
      case reco::user::kAppInfo:
        if (orig_user_info.has_app_info()) {
          user_info.mutable_app_info()->CopyFrom(orig_user_info.app_info());
        }
        break;
      case reco::user::kDislikeProfile:
        if (orig_user_info.has_dislike_profile()) {
          user_info.mutable_dislike_profile()->CopyFrom(orig_user_info.dislike_profile());
        }
        break;
      case reco::user::kDislikeInfo:
        if (orig_user_info.dislike_info_size() > 0) {
          user_info.mutable_dislike_info()->CopyFrom(orig_user_info.dislike_info());
        }
        break;
      case reco::user::kRecentClick:
        if (orig_user_info.recent_click_size() > 0) {
          user_info.mutable_recent_click()->CopyFrom(orig_user_info.recent_click());
        }
        break;
      case reco::user::kShownHistory:
        if (orig_user_info.shown_history_size() > 0) {
          user_info.mutable_shown_history()->CopyFrom(orig_user_info.shown_history());
        }
        break;
      case reco::user::kSpecialShownHistory:
        if (orig_user_info.special_shown_history_size() > 0) {
          user_info.mutable_special_shown_history()->CopyFrom(orig_user_info.special_shown_history());
        }
        break;
      case reco::user::kWeMedia:
        if (orig_user_info.has_wemedia_info()) {
          user_info.mutable_wemedia_info()->CopyFrom(orig_user_info.wemedia_info());
        }
        break;
      default:
        break;
    }
  }

  ProfileTypeDetect detector(orig_user_info);
  float profile_weight = detector.profile_weight();
  response->set_profile_weight(static_cast<int>(profile_weight));

  if (user_info.IsInitialized()) {
    response->mutable_user_info()->Swap(&user_info);
  } else {
    LOG(ERROR) << "user info not initialized";
  }
}

void LeafController::GetUserInfo(const bool is_demote,
                                 const RecommendRequest* request,
                                 UserInfo* user_info,
                                 RecommendResponse *response,
                                 bool* user_valid) {
  timer_.Start();
  cost_trace_ = {};
  serving_base::Timer user_timer;
  user_timer.Start();
  user_info->Clear();
  user_info->mutable_identity()->CopyFrom(request->user());

  *user_valid = true;
  if (is_demote) {
    *user_valid = false;
  } else {
    *user_valid = global_data_->user_comm->GetUserInfo(user_info, response->mutable_err_message());
  }
  RecoDebugger::SetUpUserInfo(*request, user_info);
  cost_trace_.us = user_timer.Stop();
}

void LeafController::LeafRecommend(const bool user_valid,
                                   UserInfo* user_info,
                                   const RecommendRequest *request,
                                   RecommendResponse *response,
                                   reco::http_communicator::HttpCommunicator* comm) {
  // init response
  response->set_success(false);


  // 即使请求失败，也要保证 required 字段被正确设置
  if (!ranker_->Recommend(*request, response, *user_info, !user_valid, &cost_trace_, comm)) {
    COUNTERS_recommend__reco_error_num.Increase(1);
    LOG(ERROR) << "recommend failed, user id: " << request->user().user_id();
  } else {
    response->set_success(true);
  }

  user_info->mutable_identity()->CopyFrom(request->user());
  SetUserInfoToResponse(request, *user_info, response);

  const int64 channel_id = request->has_channel_id() ? request->channel_id() : 100l;
  const bool debug_request = request->has_reco_debug_param() ?
                             request->reco_debug_param().enable_debug() : false;

  if (FLAGS_use_user_cache && user_valid && !debug_request) {
    vector<uint64> item_ids;
    for (auto i = 0; i < response->result_size(); ++i) {
      item_ids.push_back(response->result(i).item_id());
      for (auto j = 0; j < response->result(i).sub_item_id_size(); ++j) {
        item_ids.push_back(response->result(i).sub_item_id(j));
      }
    }
    for (auto i = 0; i < response->im_result_size(); ++i) {
      const RecoResult &im_item = response->im_result(i).im_item();
      if (im_item.has_item_type() && im_item.item_type() == reco::kIMCard) {
        item_ids.push_back(im_item.item_id());
      }
    }
    global_data_->user_comm->UpdateUserCache(channel_id, item_ids, response->result(), user_info);
  }

  // success
  if (response->success()) {
    COUNTERS_recommend__success_response_num.Increase(1);
    if (channel_id == 100 && response->result_size() == 0) {
      COUNTERS_recommend__channel_null_response_num.Increase(1);
    }
  }

  const double total_time = timer_.Stop();
  cost_trace_.ts = total_time;

  /*
  if (user_info->identity().user_id() != 0) {
    LeafDataManager::instance().SysCounter(total_time);
  }
  */

  if (response && response->has_hostname() && !video_hostname_.empty()) {
    response->set_hostname(response->hostname() + "," +video_hostname_);
  }

  const string cost_str = cost_trace_.ToString();
  COUNTERS_recommend__strategy_time.Increase(cost_trace_.ss);
  COUNTERS_recommend__reco_result_num.Increase(response->result_size());

  LOG(INFO) << "Reco ret=" << response->success()
            << " uid=" << request->user().user_id()
            << " recoid=" << request->reco_id()
            << " app_token=" << request->app_token()
            << " reco_type=" << request->recommend_type()
            << " channel_id=" << channel_id
            << " req_num=" << request->return_num()
            << " query=" << request->query()
            << " resp_num=" << response->result_size()
            << " hostname=" << response->hostname()
            << " cost=" << cost_str;
}

bool LeafController::Recommend(const bool is_demote,
                               const RecommendRequest *request,
                               RecommendResponse *response) {
  RecommendRequest tmp_request = *request;
  const int64 channel_id = request->has_channel_id() ? request->channel_id() : reco::common::kRecoChannelId;
  video_hostname_.clear();

  bool user_valid;
  UserInfo user_info;
  GetUserInfo(is_demote, request, &user_info, response, &user_valid);

  bool send_http_request = false;

  if (channel_id == reco::common::kRecoChannelId && request->user().user_id() != 0) {
    COUNTERS_recommend__reco_channel_num.Increase(1);
    if (RecoUtils::IsInnerQudao(request->app_token())) {
      // DataFromVideoServerResponse video_resp;
      int percent = CalcCallVideoPercent();
      base::PseudoRandom random(base::GetTimestamp());
      int random_percent = random.GetInt(0, 100);
      if (random_percent <= percent) {
        send_http_request = true;
        reco::http_communicator::HttpClient& http_client = reco::http_communicator::HttpClientIns::instance();
        reco::http_communicator::HttpCommunicator* comm = http_client.GetCommunicator();
        bool req_succ = global_data_->video_comm->SentHttpVideoRequest(user_info, comm,
                                                                       FLAGS_video_server_return_num,
                                                                       FLAGS_video_server_req_timeout_ms,
                                                                       &tmp_request);
        COUNTERS_http__send_video_http_req_total_count.Increase(1);
        // 发送请求失败, 立即释放
        if (!req_succ) {
          if (comm == NULL) {
            LOG(ERROR) << "get comm fail, comm is null";
          } else {
            http_client.ReleaseCommunicator(comm);
            comm = NULL;
          }
          COUNTERS_http__send_video_http_req_fail_count.Increase(1);
          LOG(ERROR) << "send http req fail. reco_id : " << request->reco_id()
                     << " user_id : " << request->user().user_id();
        } else {
          COUNTERS_http__send_video_http_req_succ_count.Increase(1);
          LOG(INFO) << "send http req succ. reco_id : " << request->reco_id()
                    << " user_id : " << request->user().user_id();
        }
        LeafRecommend(user_valid, &user_info, request, response, comm);
        // 发送请求成功, 处理完毕后再释放, 判断 NULL, 避免重复释放.
        if (comm != NULL) {
          http_client.ReleaseCommunicator(comm);
          comm = NULL;
        }
      }
    }
  }

  if (!send_http_request) {
    LeafRecommend(user_valid, &user_info, request, response, NULL);
  }

  return response->success();
}

bool LeafController::GetHotNews(const GetHotNewsRequest* request, GetHotNewsResponse* response) {
  timer_.Start();

  if (!external_api_->GetHotNews(*request, response)) {
    LOG(ERROR) << "get hot news failed, request: " << request->Utf8DebugString();
    response->set_success(false);
  } else {
    response->set_success(true);
  }

  const double total_time = timer_.Stop();
  if (response->success()) {
    // success
    LOG(INFO) << "GetHotNews success! request=" << nlp::util::NormalizeLine(request->Utf8DebugString())
              << " item num in response=" << response->hot_news_size()
              << " total_time=" << total_time;
  } else {
    // error
    LOG(ERROR) << "GetHotNews error! request=" << nlp::util::NormalizeLine(request->Utf8DebugString())
               << " total_time=" << total_time;
  }

  return true;
}

bool LeafController::VerticalRecommend(const VerticalRequest *request,
                                       VerticalResponse *response) {
  timer_.Start();
  response->set_success(false);
  // double total_time = timer_.Stop();
  if (!external_api_->VerticalRecommend(*request, response)) {
    LOG(ERROR) << "get vertical reco failed, request: " << request->Utf8DebugString();
    response->set_success(false);
  } else {
    response->set_success(true);
  }

  const double total_time = timer_.Stop();
  if (response->success()) {
    // success
    LOG(INFO) << "GetVerticalReco success! request=" << nlp::util::NormalizeLine(request->Utf8DebugString())
              << " item num in response=" << response->result_size()
              << " total_time=" << total_time;
  } else {
    // error
    LOG(ERROR) << "GetVerticalReco error! request=" << nlp::util::NormalizeLine(request->Utf8DebugString())
               << " total_time=" << total_time;
  }

  return response->success();
}

bool LeafController::GetModelVersion(const ModelVerRequest *request,
                                     ModelVerResponse *response) {
  /*
     switch (request->model_type()) {
     case MFMatrix:
     response->set_version(ModelBufMgr::instance().GetVersionMf());
     break;
     case FacMachineMatrix:
     response->set_version(FacMachineBufMgr::instance().GetVersion());
     break;
     default:
     LOG(ERROR) << "GetModelVersion model_type is error: " << request->model_type();
     }
     */

  return true;
}

bool LeafController::SetModelVersion(const ModelVerRequest *request,
                                     ModelVerResponse *response) {
  response->set_version(request->version());

  /*
     switch (request->model_type()) {
     case MFMatrix:
     ModelBufMgr::instance().NeedExchangeMatrixBufMf(request->version());
     break;
     case FacMachineMatrix:
     FacMachineBufMgr::instance().NeedExchangeMatrixBuf(request->version());
     break;
     default:
     LOG(ERROR) << "SetModelVersion model_type is error: " << request->model_type();
     }
     */

  return true;
}

bool LeafController::WeMediaRecommend(const bool is_demote,
                                      const WeMediaRecommendRequest *request,
                                      WeMediaRecommendResponse *response) {
  timer_.Start();
  const int64 channel_id = request->has_channel_id() ? request->channel_id() : 100l;

  // user info
  UserInfo user_info;
  user_info.mutable_identity()->CopyFrom(request->user());
  bool user_valid = true;
  if (is_demote) {
    user_valid = false;
  } else {
    user_valid = global_data_->user_comm->GetUserInfo(&user_info, response->mutable_err_message());
  }

  const bool ret = ranker_->WeMediaRecommend(*request, user_info, response, !user_valid);
  if (ret)
    COUNTERS_recommend__success_response_num.Increase(1);

  // counter
  const double total_time = timer_.Stop();

  std::vector<std::string> result;
  for (auto i = 0; i < response->result_size(); ++i) {
    result.push_back(response->result(i).wemedia_name());
  }

  /*
  if (FLAGS_use_user_cache && user_valid) {
    global_data_->user_comm->ClearUserCache(&user_info);
  }
  */

  LOG(INFO) << "wemedia reco. ret=" << ret
            << " reco=" << base::JoinStrings(result, "|")
            << " reco_id=" << request->reco_id()
            << " uid=" << request->user().user_id()
            << " channel_id=" << channel_id
            << " req_n=" << request->return_num()
            << " resp_n=" << response->result_size()
            << " cost=" << total_time;

  return ret;
}


bool LeafController::SceneCardRecommend(const bool is_demote,
                                        const SceneCardRecoRequest *request,
                                        SceneCardRecoResponse *response) {
  timer_.Start();
  cost_trace_ = {};

  // user info
  UserInfo user_info;
  user_info.mutable_identity()->CopyFrom(request->user());

  serving_base::Timer user_timer;
  user_timer.Start();
  bool user_valid = true;
  if (is_demote) {
    user_valid = false;
  } else {
    user_valid = global_data_->user_comm->GetUserInfo(&user_info, response->mutable_err_message());
  }

  cost_trace_.us = user_timer.Stop();
  const bool ret = ranker_->SceneCardRecommend(user_info, !user_valid, *request, response, &cost_trace_);
  if (ret)
    COUNTERS_recommend__success_response_num.Increase(1);

  if (user_valid && response->has_scene_result()) {
    vector<uint64> item_ids;
    item_ids.push_back(response->scene_result().scene_item().item_id());
    for (auto i = 0; i < response->scene_result().sub_items_size(); ++i) {
      item_ids.push_back(response->scene_result().sub_items(i).item_id());
    }
    global_data_->user_comm->UpdateUserCache(100, item_ids,
                                             google::protobuf::RepeatedPtrField<reco::leafserver::RecoResult>(), // NOLINT
                                             &user_info);
  }

  // counter
  const double total_time = timer_.Stop();
  //LeafDataManager::instance().SysCounter(total_time);
  cost_trace_.ts = total_time;

  const string cost_str = cost_trace_.ToString();

  const int ret_num = response->has_scene_result() ? response->scene_result().sub_items_size() : 0;
  LOG(INFO) << "scene card reco. ret=" << ret
            << " reco_id=" << request->reco_id()
            << " uid=" << request->user().user_id()
            << " req_n=" << request->return_num()
            << " resp_sub_n=" << ret_num
            << " cost=" << cost_str;

  return ret;
}

bool LeafController::ImCardRecommend(const bool is_demote,
                                     const ImCardRecoRequest *request,
                                     ImCardRecoResponse *response) {
  timer_.Start();
  cost_trace_ = {};

  // user info
  UserInfo user_info;
  user_info.mutable_identity()->CopyFrom(request->user());

  serving_base::Timer user_timer;
  user_timer.Start();
  bool user_valid = true;
  if (is_demote) {
    user_valid = false;
  } else {
    user_valid = global_data_->user_comm->GetUserInfo(&user_info, response->mutable_err_message());
  }

  cost_trace_.us = user_timer.Stop();
  const bool ret = ranker_->ImCardRecommend(user_info, !user_valid, *request, response, &cost_trace_);
  if (ret)
    COUNTERS_recommend__success_response_num.Increase(1);

  if (user_valid && response->has_im_result()) {
    vector<uint64> item_ids;
    for (auto i = 0; i < response->im_result().sub_items_size(); ++i) {
      item_ids.push_back(response->im_result().sub_items(i).item_id());
    }
    global_data_->user_comm->UpdateUserCache(100, item_ids,
                                             google::protobuf::RepeatedPtrField<reco::leafserver::RecoResult>(), // NOLINT
                                             &user_info);
  }

  // counter
  const double total_time = timer_.Stop();
  //LeafDataManager::instance().SysCounter(total_time);
  cost_trace_.ts = total_time;

  const string cost_str = cost_trace_.ToString();

  LOG(INFO) << "imcard reco. ret=" << ret
            << " reco_id=" << request->reco_id()
            << " uid=" << request->user().user_id()
            << " req_n=" << request->return_num()
            << " cost=" << cost_str;

  return ret;
}

bool LeafController::HotCardRecommend(const bool is_demote,
                                      const HotCardRecommendRequest *request,
                                      HotCardRecommendResponse *response) {
  timer_.Start();
  cost_trace_ = {};

  // user info
  UserInfo user_info;
  user_info.mutable_identity()->CopyFrom(request->user());

  serving_base::Timer user_timer;
  user_timer.Start();
  bool user_valid = true;
  if (is_demote) {
    user_valid = false;
  } else {
    user_valid = global_data_->user_comm->GetUserInfo(&user_info, response->mutable_err_message());
  }

  cost_trace_.us = user_timer.Stop();
  const bool ret = ranker_->HotCardRecommend(user_info, !user_valid, *request, response, &cost_trace_);
  if (ret)
    COUNTERS_recommend__success_response_num.Increase(1);

  if (user_valid && response->has_item_id()) {
    vector<uint64> item_ids;
    item_ids.push_back(response->item_id());
    for (auto i = 0; i < response->result_size(); ++i) {
      item_ids.push_back(response->result(i).item_id());
    }
    global_data_->user_comm->UpdateUserCache(100, item_ids,
                                             google::protobuf::RepeatedPtrField<reco::leafserver::RecoResult>(), // NOLINT
                                             &user_info);
  }

  // counter
  const double total_time = timer_.Stop();
  //LeafDataManager::instance().SysCounter(total_time);
  cost_trace_.ts = total_time;

  const string cost_str = cost_trace_.ToString();

  LOG(INFO) << "hotcard reco. ret=" << ret
            << " reco_id=" << request->reco_id()
            << " uid=" << request->user().user_id()
//            << " req_n=" << request->return_num()
            << " cost=" << cost_str;

  return ret;
}

bool LeafController::GetNewsMap(const NewsMapRequest *request, NewsMapResponse *response) {
  timer_.Start();

  if (!ranker_->GetNewsMap(request, response)) {
    response->set_success(false);
  } else {
    response->set_success(true);
  }

  LOG(INFO) << "GetNewsMap success! ret: " << response->success()
            << ", request:" << nlp::util::NormalizeLine(request->Utf8DebugString())
            << ", total_time:" << timer_.Stop();

  return true;
}

bool LeafController::GetIndexItemInfo(const GetIndexItemInfoRequest& request,
                                      GetIndexItemInfoResponseHa3* response) {
  timer_.Start();
  if (!external_api_->GetIndexItemInfo(request, response)) {
    response->set_success(false);
  } else {
    response->set_success(true);
  }
  LOG(INFO) << "GetIndexItemInfo success! ret: " << response->success()
            << ", request:" << nlp::util::NormalizeLine(request.Utf8DebugString())
            << ", total_time:" << timer_.Stop();
  return true;
}

bool LeafController::GetIndexQueue(const GetIndexQueueRequest& request,
                                   GetIndexQueueResponse* response) {
  timer_.Start();
  if (!external_api_->GetIndexQueue(request, response)) {
    response->set_success(false);
  } else {
    response->set_success(true);
  }
  LOG(INFO) << "GetIndexQueue success! ret: " << response->success()
            << ", request:" << nlp::util::NormalizeLine(request.Utf8DebugString())
            << ", total_time:" << timer_.Stop();
  return true;
}

bool LeafController::GetIndexQueueUnsort(const GetIndexQueueUnsortRequest& request,
                                         GetIndexQueueUnsortResponse* response) {
  timer_.Start();
  if (!external_api_->GetIndexQueueUnsort(request, response)) {
    response->set_success(false);
  } else {
    response->set_success(true);
  }
  LOG(INFO) << "GetIndexQueueUnsort success! ret: " << response->success()
            << ", request:" << nlp::util::NormalizeLine(request.Utf8DebugString())
            << ", total_time:" << timer_.Stop();
  return true;
}

void LeafController::VideoRecommend(UserInfo* user_info, RecommendRequest* request, DataFromVideoServerResponse* video_response) {
  const uint64 user_id = request->user().user_id();
  if (user_id == 0) {
    VLOG(1) << "user_id is 0";
    return;
  }

  bool ret;
  if (global_data_->video_result_null_cache->FindSilently(user_id, &ret)) {
    VLOG(1) << "user_id hit null cache";
    return;
  }

  serving_base::Timer timer;
  timer.Start();
  std::string msg;
  global_data_->video_comm->GetVideoResults(*user_info, request, video_response, &ret, &msg);
  LOG(INFO) << "uid:" << user_id << ", get result, cost:"
            << timer.Stop()
            <<" size: " << video_response->items_size();
  if (video_response->items_size() > 0) {
    COUNTERS_recommend__has_video_candidates_num.Increase(1);
  }

  if (video_response->success()) {
    if (video_response->items_size() == 0) {
      global_data_->video_result_null_cache->Add(request->user().user_id(), true);
    }

    if (video_response->has_hostname()) {
      video_hostname_ = video_response->hostname();
    }
  } else {
    VLOG(1) << "GetVideoResults not success";
  }

  return;
}

bool LeafController::TagRecommend(const TagRecommendRequest &request,
                                  TagRecommendResponse *response) {
  timer_.Start();

  // user info
  UserInfo user_info;
  user_info.mutable_identity()->CopyFrom(request.user());
  bool user_valid = global_data_->user_comm->GetUserInfo(&user_info, response->mutable_err_message());

  if (!tag_reco_->TagRecommend(request, user_info, response, !user_valid)) {
    response->set_success(false);
  } else {
    response->set_success(true);
  }

  LOG(INFO) << "TagRecommend end! ret: " << response->success()
            << ", request:" << nlp::util::NormalizeLine(request.Utf8DebugString())
            << ", total_time:" << timer_.Stop()
            << ", response: " << nlp::util::NormalizeLine(response->Utf8DebugString());

  return true;
}

int LeafController::CalcCallVideoPercent() {
  int64 time_stamp = base::GetTimestamp();
  int64 last_timestamp = global_data_->last_time_stamp.load();
  if (last_timestamp == 0) {
    global_data_->last_time_stamp.store(time_stamp);
    return global_data_->leaf_call_video_permit_percent.load();
  }
  if (time_stamp - last_timestamp > FLAGS_video_server_percent_analyze_cycle * 1000000) {
    global_data_->last_time_stamp.store(time_stamp);
    int64 timeout = global_data_->leaf_call_video_total_timeout.load();
    global_data_->leaf_call_video_total_timeout.store(0);
    int64 count = global_data_->leaf_call_video_total_count.load();
    global_data_->leaf_call_video_total_count.store(0);
    if (count == 0) {
      return global_data_->leaf_call_video_permit_percent.load();
    }
    int avg_timeout = timeout / count;
    int percent = 100;
    if (avg_timeout > 100 && avg_timeout  <= 120) {
      percent = 80;
    } else if (avg_timeout > 120 && avg_timeout  <= 140) {
      percent = 50;
    } else if (avg_timeout > 140 && avg_timeout  <= 160) {
      percent = 30;
    } else if (avg_timeout > 160 && avg_timeout  <= 180) {
      percent = 20;
    } else if (avg_timeout > 180 && avg_timeout  <= 200) {
      percent = 10;
    } else if (avg_timeout > 200) {
      percent = 5;
    }
    global_data_->leaf_call_video_permit_percent.store(percent);
    return percent;
  }
  return global_data_->leaf_call_video_permit_percent.load();
}
}  // namespace leafserver
}  // namespace reco
