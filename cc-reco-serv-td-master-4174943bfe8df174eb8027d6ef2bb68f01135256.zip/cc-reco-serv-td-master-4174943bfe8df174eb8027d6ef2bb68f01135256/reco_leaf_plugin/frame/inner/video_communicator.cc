#include <unordered_set>
#include "base/time/time.h"
#include "reco/serv/reco_leaf_plugin/frame/inner/video_communicator.h"
#include "reco/serv/reco_leaf_plugin/frame/global_data.h"
#include "reco/serv/reco_leaf_plugin/common/leaf_cache.h"
#include "reco/serv/reco_leaf_plugin/strategy/reco/video/video_reco.h"
#include "reco/serv/dict_server/api_arpc/dict_server_api.h"
#include "reco/serv/reco_leaf_plugin/proto/leaf_data.pb.h"
#include "reco/serv/reco_leaf_plugin/strategy/component/filter/news_filter.h"

namespace reco {
namespace leafserver {
using reco::user::UserInfo;

DEFINE_int32(video_get_pk_timeout_ms, 60, "visit proxy server get video item  timeout");
/*
DEFINE_string(video_server_machine_list, "test_video.yaml", "video server config file");
DEFINE_int32(video_server_timeout_per_communicate, 150, "video server time out, ms");
DEFINE_int32(video_server_total_timeout, 290, "video server total timeout");
DEFINE_int32(video_server_retry_times, 1, "video server retry num");
DEFINE_int32(video_results_timeout, 60, "visit dict server get video result timeout");
*/

DEFINE_string(video_cache_prefix, "VIDEO_CALC_CACHE", "");

DEFINE_int64_counter(recommend, get_video_error_num, 0, "get video result error num");
DEFINE_int64_counter(recommend, get_video_from_cache_num, 0, "get video result from cache num");
DEFINE_int64_counter(recommend, get_video_from_server_num, 0, "get video result from server num");
DEFINE_int64_counter(recommend, get_video_req_cost, 0, "");

serving_base::ExpiryMap<std::string, std::string>* VideoComm::cache_ =
    new serving_base::ExpiryMap<std::string, std::string>(10 * 60);

VideoComm::VideoComm(reco::NewsIndex* news_index) {
  news_index_ = news_index;
}

VideoComm::~VideoComm() {
}
bool VideoComm::GetVideoCandidateCache(const std::string& key, std::string* value) {
  value->clear();
  if (cache_ && cache_->FindSilently(key, value)) {
    VLOG(1) << "get video_response from local cache_" << key;
    return true;
  } else {
    if (reco::dictserver::DictServerAPIIns::instance().GetData("VideoAsyncTask", key, "", value, true)) {
      if (cache_)
        cache_->Add(key, *value);
      return true;
    } else {
      VLOG(1) << "get video_response from dict server fail" << key;
      return false;
    }
  }
  return false;
}

void VideoComm::GetVideoResults(const UserInfo& user_info,
                                const reco::leafserver::RecommendRequest* request,
                                reco::leafserver::DataFromVideoServerResponse* video_response,
                                bool* ret,
                                std::string* err_msg) {
  *ret = true;
  // 先从缓存取
  if (VideoReco::GetVideoResponseFromCache(*request, video_response)) {
    VLOG(1) << "get video_response from VideoReco cache " << request->user().user_id();
    COUNTERS_recommend__get_video_from_cache_num.Increase(1);
    video_response->set_success(true);
    return;
  }

  const uint64 user_id = request->user().user_id();
  std::string key;
  key = base::StringPrintf("%s_%lu", FLAGS_video_cache_prefix.c_str(), user_id);
  bool get_cache_success = false;
  CachedNewsRecoData cached_results;
  do {
    std::string value;
    if (!GetVideoCandidateCache(key, &value)) {
      LOG(WARNING) << "get video candidate fail:" << key;
      break;
    }

    if (value.empty()) {
      break;
    }

    if (!cached_results.ParseFromString(value)) {
      LOG(WARNING) << "fail to parse string:" << value;
      break;
    }
    get_cache_success = true;
  } while (false);

  if (!get_cache_success) {
    LOG(WARNING) << "get video result fail.";
    video_response->Clear();
    video_response->set_success(true);
    return;
  }

  VLOG(1) << "get video candidate from cache_ num:" << cached_results.item_misc_size();
  base::dense_hash_set<uint64> item_dedup;
  item_dedup.set_empty_key(0);

  std::unordered_set<uint64> ids;
  for (int i = 0; i < cached_results.item_misc_size(); ++i) {
    const CachedItemMisc& item_misc = cached_results.item_misc(i);
    ids.insert(item_misc.item_id());
  }

  if(!news_index_->GetItemInfoFullAsync(&ids)) {
    LOG(ERROR) << "get GetItemInfoFull error, reco_id:" << request->reco_id();
    video_response->Clear();
    video_response->set_success(true);
    return;
  }

  int filtnum_by_iteminfo = 0;
  for (int i = 0; i < cached_results.item_misc_size(); ++i) {
    const CachedItemMisc& item_misc = cached_results.item_misc(i);
    ItemInfo item;
    item.item_id = item_misc.item_id();
    item.category = item_misc.category();

    ItemType item_type;
    if (!news_index_->GetItemTypeByItemId(item_misc.item_id(), &item_type)) {
      continue;
    }
    // 暂时只要纯视频
    if (item_type != reco::kPureVideo) {
      continue;
    }

    if (!news_index_->GetItemInfoByItemId(item_misc.item_id(), &item, false)) {
      VLOG(1) << "filt by ItemInfo " << item.item_id;
      filtnum_by_iteminfo ++;
      continue;
    }

    base::Time current_time = base::Time::Now();
    int64 current_timestamp = current_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
    if (!NewsFilter::ItemIsValid(item, current_timestamp)) {
      VLOG(1) << "filt by IsValid " << item.item_id;
      continue;
    }

    if (NewsFilter::IsDeduped(item, &item_dedup)) {
      VLOG(1) << "filt by Dedupe " << item.item_id;
      continue;
    }
    std::string title;
    if (!news_index_->GetItemTitleByItemId(item.item_id, &title)) {
      VLOG(1) << "filt by GetTitle " << item.item_id;
      continue;
    }

    auto result = video_response->add_items();
    result->set_title(title);
    result->set_strategy_type(reco::kVideo);
    result->set_item_id(item.item_id);
    if (item_misc.has_reco_score()) {
      result->set_reco_score(item_misc.reco_score());
    }
    result->set_outer_id(base::Uint64ToString(item.item_id));
    int64 timestamp = news_index_->GetCreateTimestampByItemId(item.item_id);
    result->set_create_timestamp(timestamp);
    result->set_parent_id(news_index_->GetParentId(item.item_id));
    result->set_reco_id(request->reco_id());
    result->set_item_type(item.item_type);
    std::vector<reco::Category> categories;
    if (news_index_->GetCategoriesByItemId(item.item_id, &categories)) {
      for (int j = 0; j < (int)categories.size(); ++j) {
        result->add_category(categories[j].category());
      }
    }
    reco::FeatureVector tag_fea;
    if (news_index_->GetVideoTagFeatureVectorByItemId(item.item_id, &tag_fea)) {
      for (int j = 0; j < tag_fea.feature_size(); ++j) {
        result->add_tags(tag_fea.feature(j).literal());
      }
    }
  }

  if (!cached_results.shunt_tag().empty()) {
    video_response->add_shunt_tags(cached_results.shunt_tag());
  }

  VLOG(1) << "video response num:" << video_response->items_size();
  video_response->set_success(true);

  if(filtnum_by_iteminfo < 0.2*cached_results.item_misc_size()) {
    VideoReco::SetVideoResponseToCache(*request, *video_response);
  }
}

bool VideoComm::SentHttpVideoRequest(const reco::user::UserInfo& user_info,
                                     reco::http_communicator::HttpCommunicator* comm,
                                     int return_num,
                                     int req_timeout,
                                     const reco::leafserver::RecommendRequest* request) {
  if (comm == NULL || request == NULL) {
    LOG(ERROR) << "comm or request is null";
    return false;
  }
  if (comm->GetHttpConnection() == NULL || comm->GetHttpConnection()->IsClosed()) {
    LOG(ERROR) << "conn is null or conn closed.";
    return false;
  }
  std::string request_id = base::StringPrintf("%s_%lu", request->reco_id().c_str(),
                                              request->user().user_id());
  std::string uri = base::StringPrintf("%s%lu", "/video_server/leaf_request?uid=", request->user().user_id());

  reco::leafserver::DataFromVideoServerRequest video_request;
  video_request.mutable_user()->CopyFrom(request->user());
  video_request.set_return_num(return_num);
  video_request.set_reco_id(request->reco_id());
  video_request.set_strategy_type(0);
  video_request.mutable_uc_user_param()->CopyFrom(request->uc_user_param());
  if (request->has_channel_id()) {
    video_request.set_channel_id(request->channel_id());
  } else {
    video_request.set_channel_id(reco::common::kRecoChannelId);
  }
  video_request.mutable_shunt_tags()->CopyFrom(request->shunt_tags());
  video_request.mutable_user_info()->CopyFrom(user_info);
  int64 time_stamp = base::GetTimestamp();
  video_request.set_time_stamp(time_stamp);

  std::string body;
  if (!video_request.SerializeToString(&body)) {
    LOG(ERROR) << "serialize request to body fail";
    return false;
  }
  /*
  std::string zip_body;
  if (GzCompress(body.c_str(), body.size(), &zip_body)) {
    body = zip_body;
  }
  */
  COUNTERS_recommend__get_video_from_server_num.Increase(1);
  if (!comm->AsyncSendHttpRequest(request_id, uri, body, req_timeout)) {
    LOG(ERROR) << "AsyncSendHttpRequest fail. request_id : " << request_id;
    return false;
  }
  return true;
}

bool VideoComm::GetHttpVideoResponse(reco::http_communicator::HttpCommunicator* comm,
                                     reco::leafserver::RecoRequest* reco_request,
                                     std::vector<ItemInfo>* reco_items, std::vector<std::string>* shunt_tags) {
  if (comm == NULL || reco_items == NULL) {
    LOG(ERROR) << "comm or reco_items null";
    return false;
  }
  std::string responseContent;
  if (!comm->GetHttpResponseContent(&responseContent)) {
    LOG(ERROR) << "get http response fail.";
    return false;
  }
  if (responseContent.empty()) {
    LOG(ERROR) << "responseContent empty";
    return false;
  }
  reco::leafserver::DataFromVideoServerResponse response;
  if (!response.ParseFromString(responseContent)) {
    LOG(ERROR) << "parse responseContent fail";
    return false;
  }
  if (!response.success()) {
    LOG(ERROR) << "response not success";
    return false;
  }
  VideoResponseToResults(&response, reco_request, reco_items);
  shunt_tags->clear();
  for (int i = 0; i < response.shunt_tags_size(); ++i) {
    shunt_tags->push_back(response.shunt_tags(i));
  }
  return true;
}

void VideoComm::VideoResponseToResults(reco::leafserver::DataFromVideoServerResponse* response,
                                       reco::leafserver::RecoRequest* reco_request,
                                       std::vector<ItemInfo>* reco_items) {
  if (response == NULL || reco_items == NULL) {
    return;
  }
  const int64 now_timestamp = base::GetTimestamp();

  for (int i = 0; i < response->items_size(); ++i) {
    auto item = response->items(i);
    ItemInfo item_info;
    if (!news_index_->GetItemInfoByItemId(item.item_id(), &item_info, true)) {
      continue;
    }

    if (!NewsFilter::ItemIsValid(item_info, now_timestamp)) {
      continue;
    }
    
    if (NewsFilter::IsDislikeFiltered(reco_request, item_info)) {
      continue;
    }

    if (!news_index_->GetItemInfoByItemId(item_info.item_id, &item_info, false)) {
      continue;
    }
    // 从 result response 里面获取 strategy_type strategy_branch
    if (item.has_strategy_type()) {
      item_info.strategy_type = item.strategy_type();
    }
    if (item.has_strategy_branch()) {
      item_info.strategy_branch = (reco::RecoStrategyBranch)item.strategy_branch();
    }
    reco_items->push_back(item_info);
  }

  std::sort(reco_items->begin(), reco_items->end(), std::greater<ItemInfo>());
}
}
}
