#include "reco/serv/reco_leaf_plugin/frame/inner/dynamic_dict_container.h"
#include "base/hash_function/term.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "nlp/common/nlp_util.h"
#include "serving_base/utility/timer.h"

namespace reco {
namespace dm {

DEFINE_int32(dict_erase_batch_num, 2000, "erase batch num");
DEFINE_int32(dict_erase_interval_ms, 10, "erase interval ms");
DEFINE_int32(dict_erase_delay_seconds, 3, "erase delay seconds");

#define DM_LOAD_DICT(var) reco::dm::DictManagerSingleton::instance().ReloadByDictName(#var)
DEFINE_int64(max_crowd_oper_file_size, 4L * 1024 * 1024 * 1024, "max crowd oper file size");

void LoadRecoReasonTagDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<RecoReasonTagDict>* dynamic_dict =
      reinterpret_cast<DynamicDict<RecoReasonTagDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<RecoReasonTagDict> new_dict(new RecoReasonTagDict());

  // 处理逻辑
  std::unordered_map<std::string, std::string> * tag_mapping = &(new_dict->reco_reason_tag_mapping);
  std::unordered_map<std::string, std::unordered_set<std::string> > * tag_category =
      &(new_dict->reco_reason_tag_category);

  std::vector<std::string> fields;
  int64 count = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    fields.clear();
    base::SplitString(lines[i], "\t", &fields);
    if (fields.size() < 2u) continue;
    std::string tag = nlp::util::NormalizeLine(fields[0]);
    auto &category = fields[1];

    (*tag_mapping)[tag] = fields[0];

    std::unordered_set<std::string> *cates;
    auto iter = tag_category->find(tag);
    if (iter == tag_category->end()) {
      cates = &(tag_category->insert(
          std::make_pair(tag, std::unordered_set<std::string>())).first->second);
    } else {
      cates = &(iter->second);
    }
    cates->insert(category);
    ++count;
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

void LoadSubscriptTagRelevenceDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<SubscriptTagRelevenceDict>* dynamic_dict =
      reinterpret_cast<DynamicDict<SubscriptTagRelevenceDict>* >(dict_address);
  // 新 dict
  boost::shared_ptr<SubscriptTagRelevenceDict> new_dict(new SubscriptTagRelevenceDict());

  // 处理逻辑
  std::unordered_map<std::string, std::vector<std::string> > * oneway_dict =
      &(new_dict->subscript_tag_relevence_oneway);
  std::unordered_map<std::string, std::vector<std::string> > * twoway_dict =
      &(new_dict->subscript_tag_relevence_twoway);
  std::unordered_map<std::string, std::vector<std::string> > * merged_dict =
      &(new_dict->subscript_tag_relevence_merged);

  std::vector<std::string> fields, oneway_list, twoway_list;
  int64 count = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    fields.clear();
    oneway_list.clear();
    twoway_list.clear();
    base::SplitString(lines[i], "\t", &fields);
    if (fields.size() < 3u) continue;
    std::string tag = nlp::util::NormalizeLine(fields[0]);
    if (!fields[1].empty()) {
      base::SplitString(nlp::util::NormalizeLine(fields[1]), "|", &twoway_list);
      twoway_dict->insert(make_pair(tag, twoway_list));
    }
    if (!fields[2].empty()) {
      base::SplitString(nlp::util::NormalizeLine(fields[2]), "|", &oneway_list);
      oneway_dict->insert(make_pair(tag, oneway_list));
    }

    // 每个标签的关联标签通常较少，所以此处用 vector 遍历
    std::vector<std::string> merged_vec;
    for (auto it_two = twoway_list.begin(); it_two != twoway_list.end(); ++it_two) {
      bool found = false;
      for (auto it_merged = merged_vec.begin(); it_merged != merged_vec.end(); ++it_merged) {
        if (*it_two == *it_merged) {
          found = true;
        }
      }
      if (!found) {
        merged_vec.push_back(*it_two);
      }
    }
    for (auto it_one = oneway_list.begin(); it_one != oneway_list.end(); ++it_one) {
      bool found = false;
      for (auto it_merged = merged_vec.begin(); it_merged != merged_vec.end(); ++it_merged) {
        if (*it_one == *it_merged) {
          found = true;
        }
      }
      if (!found) {
        merged_vec.push_back(*it_one);
      }
    }
    if (!merged_vec.empty()) {
      merged_dict->insert(make_pair(tag, merged_vec));
    }
    ++count;
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

void LoadSourceMediaDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<SourceMediaDict>* dynamic_dict =
      reinterpret_cast<DynamicDict<SourceMediaDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<SourceMediaDict> new_dict(new SourceMediaDict());

  // 处理逻辑
  int64 count = 0;
  auto& source_media = new_dict->source_media_map_;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }

    std::vector<std::string> tokens;
    base::SplitString(lines[i], ":", &tokens);
    if (tokens.size() < 2) continue;

    std::vector<std::string> sub_tokens;
    base::SplitString(tokens[1], ",", &sub_tokens);

    uint64 source_media_sign = base::CalcTermSign(tokens[0].c_str(), tokens[0].size());
    unsigned level = 0;
    if (!base::StringToUint(sub_tokens[0], &level)) {
      LOG(ERROR) << path.value() << " level field error: " << lines[i];
      continue;
    }
    source_media[source_media_sign].level = (SourceMediaInfo::Level)level;
    for (size_t j = 1; j < sub_tokens.size(); ++j) {
      source_media[source_media_sign].cities.Insert(sub_tokens[j]);
    }
    ++count;
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

void LoadAppTokenCateBoostDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  base::PlatformFileInfo file_info;
  if (!base::file_util::GetFileInfo(path, &file_info)) {
    LOG(ERROR) << "get file info error: " << path.value();
    *suc = false;
    return;
  }

  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<AppTokenCateBoostDict>* dynamic_dict =
    reinterpret_cast<DynamicDict<AppTokenCateBoostDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<AppTokenCateBoostDict> new_dict(new AppTokenCateBoostDict());

  // 解析文件
  int64 count = 0;
  auto& app_token_cate_boost_dict = new_dict->app_token_cate_boost_dict_;
  std::vector<std::string> flds;
  double val;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2u) {
      LOG(ERROR) << "parse line fail: " << lines[i];
      continue;
    }

    const std::string& key = flds[0] + "\t" + flds[1];

    if (flds.size() < 3u || !base::StringToDouble(flds[2], &val)) {
      val = 0.2f;
    }
    app_token_cate_boost_dict.insert(std::make_pair(key, val));
    ++count;
  }

  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
  LOG(INFO) << "load app token cate boost dict succ: " << path.ToString()
            << ", num=" << *cnt;
}

void LoadCrowdOperDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  serving_base::Timer timer;
  timer.Start();
  // 检查文件状态
  base::PlatformFileInfo file_info;
  if (!base::file_util::GetFileInfo(path, &file_info)) {
    LOG(ERROR) << "get file info error: " << path.value();
    *suc = false;
    return;
  }
  if (file_info.is_directory) {
    LOG(ERROR) << "file is directory: " << path.value();
    *suc = false;
    return;
  }
  if (file_info.size >= FLAGS_max_crowd_oper_file_size) {
    LOG(ERROR) << "file size exceeds 4G: " << path.value();
    *suc = false;
    return;
  }
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 解析数据
  // TODO(liufei, feiliu): parse new format of file
  LOG(INFO) << "load crowd oper dict start: " << path.ToString();
  boost::shared_ptr<CrowdOperDict> new_dict(new CrowdOperDict());
  new_dict->path = path.value();
  auto& item_meta_dict = new_dict->item_meta_dict_;
  //item_meta_dict.set_empty_key(0);
  auto& crowd_oper_dict = new_dict->crowd_oper_dict_;
  //crowd_oper_dict.set_empty_key(0);
  int64 count = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens[0] == "ITEM") {
      if (tokens.size() < 4) continue;
      uint64_t item_id;
      int64_t time_out;
      if (base::StringToUint64(tokens[1], &item_id)
          && base::StringToInt64(tokens[3], &time_out)) {
        CrowdOperDict::ItemMeta item_meta;
        item_meta.timeout = time_out;
        item_meta.crowd = tokens[2];
        item_meta_dict.insert(std::make_pair(item_id, item_meta));
      }
    } else {
      if (tokens.size() < 3) continue;
      uint64 user_id;
      if (!base::StringToUint64(tokens[1], &user_id)) continue;
      CrowdOperItemInfo coii;
      coii.deliver_task_id = tokens[0];
      for (size_t j = 2; j < tokens.size(); ++j) {
        uint64 item_id;
        if (!tokens[j].empty() && base::StringToUint64(tokens[j], &item_id)) {
          coii.item_ids.push_back(item_id);
        }
      }
      if (coii.item_ids.size() > 0) {
        crowd_oper_dict.insert(std::make_pair(user_id, coii));
        ++count;
      }
    }
  }

  DynamicDict<CrowdOperDict>* dynamic_dict =
      reinterpret_cast<DynamicDict<CrowdOperDict>* >(dict_address);
  dynamic_dict->Swap(new_dict);

  static CrowdOperDictCleaner cleaner; 
  cleaner.Add(new_dict);

  *suc = true;
  *cnt = count;
  LOG(INFO) << "load crowd oper dict succ: " << path.ToString()
            << ", item_num" << item_meta_dict.size() << ", num=" << *cnt
            << ", time_consume: " << timer.Stop();
}

void LoadRoughModel(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 检查文件状态
  base::PlatformFileInfo file_info;
  if (!base::file_util::GetFileInfo(path, &file_info)) {
    LOG(ERROR) << "get file info error: " << path.value();
    *suc = false;
    return;
  }
  if (file_info.is_directory) {
    LOG(ERROR) << "file is directory: " << path.value();
    *suc = false;
    return;
  }
  if (file_info.size >= FLAGS_max_crowd_oper_file_size) {
    LOG(ERROR) << "file size exceeds 4G: " << path.value();
    *suc = false;
    return;
  }
  // 解析数据
  boost::shared_ptr<RoughModel> new_dict(new RoughModel());
  auto& xgboost_model = new_dict->xgboost_model_;
  // 创建 Stream 对象，GBTree 对象
  reco::xgboost::Stream* p_fin = reco::xgboost::Stream::Create(path.value().c_str(), "r");
  // Load 模型头部声明
  std::string header;
  header.resize(4);
  CHECK_EQ(p_fin->Read(&header[0], 4), 4u);
  // Load 模型参数
  p_fin->Read(&xgboost_model.model_param, sizeof(reco::xgboost::XParam));
  // 构建归一化对象
  std::string obj_name;
  p_fin->Read(&obj_name);
  xgboost_model.p_obj = reco::xgboost::CreateObjFunction(obj_name.c_str());
  std::string tmp = base::IntToString(xgboost_model.model_param.num_class);
  xgboost_model.p_obj->SetParam("num_class", tmp.c_str());
  // 构建 gbm 对象，Load 模型
  std::string gbm_name;
  p_fin->Read(&gbm_name);
  xgboost_model.p_gbm = new reco::xgboost::GBTree();
  // xgboost_model.p_gbm->LoadCateMap(p_fin);
  xgboost_model.p_gbm->LoadModel(p_fin, false);

  DynamicDict<RoughModel>* dynamic_dict =
      reinterpret_cast<DynamicDict<RoughModel>* >(dict_address);
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = 1;
  LOG(INFO) << "load rough model succ: " << path.ToString();
}

void LoadHotModel(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 检查文件状态
  base::PlatformFileInfo file_info;
  if (!base::file_util::GetFileInfo(path, &file_info)) {
    LOG(ERROR) << "get file info error: " << path.value();
    *suc = false;
    return;
  }
  if (file_info.is_directory) {
    LOG(ERROR) << "file is directory: " << path.value();
    *suc = false;
    return;
  }
  if (file_info.size >= FLAGS_max_crowd_oper_file_size) {
    LOG(ERROR) << "file size exceeds 4G: " << path.value();
    *suc = false;
    return;
  }
  // 解析数据
  boost::shared_ptr<HotModel> new_dict(new HotModel());
  auto& xgboost_model = new_dict->xgboost_model_;
  // 创建 Stream 对象，GBTree 对象
  reco::xgboost::Stream* p_fin = reco::xgboost::Stream::Create(path.value().c_str(), "r");
  // Load 模型头部声明
  std::string header;
  header.resize(4);
  CHECK_EQ(p_fin->Read(&header[0], 4), 4u);
  // Load 模型参数
  p_fin->Read(&xgboost_model.model_param, sizeof(reco::xgboost::XParam));
  // 构建归一化对象
  std::string obj_name;
  p_fin->Read(&obj_name);
  xgboost_model.p_obj = reco::xgboost::CreateObjFunction(obj_name.c_str());
  std::string tmp = base::IntToString(xgboost_model.model_param.num_class);
  xgboost_model.p_obj->SetParam("num_class", tmp.c_str());
  // 构建 gbm 对象，Load 模型
  std::string gbm_name;
  p_fin->Read(&gbm_name);
  xgboost_model.p_gbm = new reco::xgboost::GBTree();
  // xgboost_model.p_gbm->LoadCateMap(p_fin);
  xgboost_model.p_gbm->LoadModel(p_fin, false);

  DynamicDict<HotModel>* dynamic_dict =
      reinterpret_cast<DynamicDict<HotModel>* >(dict_address);
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = 1;
  delete p_fin;
  LOG(INFO) << "load Hot model succ: " << path.ToString();
}

void LoadHotCateClickRatio(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 检查文件状态
  base::PlatformFileInfo file_info;
  if (!base::file_util::GetFileInfo(path, &file_info)) {
    LOG(ERROR) << "get file info error: " << path.value();
    *suc = false;
    return;
  }
  if (file_info.is_directory) {
    LOG(ERROR) << "file is directory: " << path.value();
    *suc = false;
    return;
  }
  if (file_info.size >= FLAGS_max_crowd_oper_file_size) {
    LOG(ERROR) << "file size exceeds 4G: " << path.value();
    *suc = false;
    return;
  }
  // 解析数据
  boost::shared_ptr<HotCateClickRatio> new_dict(new HotCateClickRatio());
  auto& cate_clik_ratio = new_dict->cate_clik_ratio_;
  cate_clik_ratio.set_empty_key("");
  int64 count = 0;

  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }

  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }

    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() != 2) continue;
    double clickratio;
    if (base::StringToDouble(tokens[1], &clickratio)) {
      cate_clik_ratio.insert(std::make_pair(tokens[0], (float)clickratio));
    }
  }

  DynamicDict<HotCateClickRatio>* dynamic_dict =
      reinterpret_cast<DynamicDict<HotCateClickRatio>* >(dict_address);
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
  LOG(INFO) << "load Hot cate click ratio dict succ: " << path.ToString()
            << ", item_num" << cate_clik_ratio.size() << ", num=" << *cnt;
}


void LoadCateClickRatio(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 检查文件状态
  base::PlatformFileInfo file_info;
  if (!base::file_util::GetFileInfo(path, &file_info)) {
    LOG(ERROR) << "get file info error: " << path.value();
    *suc = false;
    return;
  }
  if (file_info.is_directory) {
    LOG(ERROR) << "file is directory: " << path.value();
    *suc = false;
    return;
  }
  if (file_info.size >= FLAGS_max_crowd_oper_file_size) {
    LOG(ERROR) << "file size exceeds 4G: " << path.value();
    *suc = false;
    return;
  }
  // 解析数据
  boost::shared_ptr<CateClickRatio> new_dict(new CateClickRatio());
  auto& cate_clik_ratio = new_dict->cate_clik_ratio_;
  cate_clik_ratio.set_empty_key("");
  int64 count = 0;

  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }

  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }

    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() != 2) continue;
    double clickratio;
    if (base::StringToDouble(tokens[1], &clickratio)) {
      cate_clik_ratio.insert(std::make_pair(tokens[0], (float)clickratio));
    }
  }

  DynamicDict<CateClickRatio>* dynamic_dict =
      reinterpret_cast<DynamicDict<CateClickRatio>* >(dict_address);
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
  LOG(INFO) << "load cate click ratio dict succ: " << path.ToString()
            << ", item_num" << cate_clik_ratio.size() << ", num=" << *cnt;
}
void LoadUcSidDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<UcSidDict>* dynamic_dict =
      reinterpret_cast<DynamicDict<UcSidDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<UcSidDict> new_dict(new UcSidDict());

  // 处理逻辑
  int64 count = 0;
  auto& sid_dict = new_dict->uc_sid_dict_;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }

    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() != 4u || tokens[0].empty()) {
      LOG(ERROR) << "invalid uc sid input line: " << lines[i]
                 << ", size=" << tokens.size();
      continue;
    }

    UcSidInfo sid_info;
    sid_info.sid = tokens[0];
    sid_info.biz = tokens[1];
    sid_info.category = tokens[2];
    sid_info.keyword = tokens[3];
    sid_dict[sid_info.sid] = sid_info;

    ++count;
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
  LOG(INFO) << "load uc sid dict succ: " << path.ToString()
            << ", num=" << *cnt;
}

void LoadDeviceInfoDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<DeviceInfoDict>* dynamic_dict =
      reinterpret_cast<DynamicDict<DeviceInfoDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<DeviceInfoDict> new_dict(new DeviceInfoDict());

  // 处理逻辑
  int64 count = 0;
  auto& device_dict = new_dict->device_info_dict_;
  std::vector<std::string> tokens;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }

    tokens.clear();
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() != 4u || tokens[0].empty()) {
      LOG(ERROR) << "invalid device info input line: " << lines[i]
                 << ", size=" << tokens.size();
      continue;
    }

    DeviceInfo device_info;
    device_info.brand = tokens[1];
    device_info.name = tokens[2];
    device_info.tag = tokens[3];
    device_dict[nlp::util::NormalizeLine(tokens[0])] = device_info;

    ++count;
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
  LOG(INFO) << "load device info dict succ: " << path.ToString()
            << ", num=" << *cnt;
}


void LoadIflowItemSortDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  int64 load_timestamp = base::GetTimestamp();

  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<IflowItemSortDict>* dynamic_dict =
    reinterpret_cast<DynamicDict<IflowItemSortDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<IflowItemSortDict> new_dict(new IflowItemSortDict());

  // 处理逻辑
  int64 count = 0;
  auto& iflow_item_sort = *new_dict;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }

    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() < 2u) continue;

    uint64 item_id;
    int level;
    if (base::StringToUint64(tokens[0], &item_id)
        && base::StringToInt(tokens[1], &level)) {
      iflow_item_sort[item_id] = level;
      VLOG(1) << "iflow sort, item id:" << item_id
              << ", level:" << level
              << ", timestamp:" << load_timestamp;
    }
    ++count;
  }
  LOG(INFO) << "iflow sort load num:" << count
            << ", timestamp:" << load_timestamp;

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

void LoadLrModel(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<LrModel>* dynamic_dict =
      reinterpret_cast<DynamicDict<LrModel>* >(dict_address);

  // 新 dict
  boost::shared_ptr<LrModel> new_dict(new LrModel());

  // 处理逻辑
  int64 count = 0;
  auto& lr_model = new_dict->lr_model_;
  if (lr_model.LoadText(path)) {
    LOG(INFO) << "succ to load lr model from " << path.ToString();
  } else {
    LOG(ERROR) << "failed to load lr model from " << path.ToString();
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;

  LOG(INFO) << "load lr model succ: " << path.ToString();
}

}  // namespace dm

namespace leafserver {
const char* DynamicDictContainer::kOtherMainCityFile_ = "other_main_city.txt";
const char* DynamicDictContainer::kRecoReasonTagFile_ = "reco_reason_tag_cat.txt";
const char* DynamicDictContainer::kSubscriptTagRelevenceFile_ = "subscript_tag_relevence.txt";
const char* DynamicDictContainer::kRoughModelFile_ = "roughrankmodel";
const char* DynamicDictContainer::kHotModelFile_ = "hotrankmodel";
const char* DynamicDictContainer::kCateClickRatioFile_ = "cateclickratio.txt";
const char* DynamicDictContainer::kHotCateClickRatioFile_ = "hotcateclickratio.txt";
const char* DynamicDictContainer::kAppTokenCateBoostFile_ = "app_token_cate_boost.txt";
const char* DynamicDictContainer::kUcSidFile_ = "uc_sid.txt";
const char* DynamicDictContainer::kDeviceInfoFile_ = "device_info_dict.txt";
const char* DynamicDictContainer::kCrowdOperExpFile_ = "crowd_oper_exp.txt";
const char* DynamicDictContainer::kCrowdOperWholeFile_ = "crowd_oper_whole.txt";
const char* DynamicDictContainer::kIflowItemSortFile_ = "iflow_item_sort_dict.txt";
const char* DynamicDictContainer::kThirdPartyCategoryLrModelFile_ = "tp_cate_lr_model.txt";
const char* DynamicDictContainer::kThirdPartyItemLrModelFile_ = "tp_item_lr_model.txt";

void DynamicDictContainer::RegisterAllDict() {
  DM_REGISTER_COMMON_DICT(UnorderedSetStr, DynamicDictContainer::kOtherMainCityFile_);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::RecoReasonTagDict,
                            DynamicDictContainer::kRecoReasonTagFile_,
                            reco::dm::LoadRecoReasonTagDict);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::SubscriptTagRelevenceDict,
                            DynamicDictContainer::kSubscriptTagRelevenceFile_,
                            reco::dm::LoadSubscriptTagRelevenceDict);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::RoughModel,
                            DynamicDictContainer::kRoughModelFile_,
                            reco::dm::LoadRoughModel);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::HotModel,
                            DynamicDictContainer::kHotModelFile_,
                            reco::dm::LoadHotModel);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::CateClickRatio,
                            DynamicDictContainer::kCateClickRatioFile_,
                            reco::dm::LoadCateClickRatio);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::HotCateClickRatio,
                            DynamicDictContainer::kHotCateClickRatioFile_,
                            reco::dm::LoadHotCateClickRatio);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::CrowdOperDict,
                            DynamicDictContainer::kCrowdOperExpFile_,
                            reco::dm::LoadCrowdOperDict);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::CrowdOperDict,
                            DynamicDictContainer::kCrowdOperWholeFile_,
                            reco::dm::LoadCrowdOperDict);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::AppTokenCateBoostDict,
                            DynamicDictContainer::kAppTokenCateBoostFile_,
                            reco::dm::LoadAppTokenCateBoostDict);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::UcSidDict,
                            DynamicDictContainer::kUcSidFile_,
                            reco::dm::LoadUcSidDict);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::DeviceInfoDict,
                            DynamicDictContainer::kDeviceInfoFile_,
                            reco::dm::LoadDeviceInfoDict);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::IflowItemSortDict,
                            DynamicDictContainer::kIflowItemSortFile_,
                            reco::dm::LoadIflowItemSortDict);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::LrModel,
                            DynamicDictContainer::kThirdPartyCategoryLrModelFile_,
                            reco::dm::LoadLrModel);
}

void DynamicDictContainer::LoadAllDict() {
  DM_LOAD_DICT(DynamicDictContainer::kOtherMainCityFile_);
  DM_LOAD_DICT(DynamicDictContainer::kRecoReasonTagFile_);
  DM_LOAD_DICT(DynamicDictContainer::kSubscriptTagRelevenceFile_);
  DM_LOAD_DICT(DynamicDictContainer::kRoughModelFile_);
  DM_LOAD_DICT(DynamicDictContainer::kHotModelFile_);
  DM_LOAD_DICT(DynamicDictContainer::kCateClickRatioFile_);
  DM_LOAD_DICT(DynamicDictContainer::kHotCateClickRatioFile_);
  DM_LOAD_DICT(DynamicDictContainer::kCrowdOperExpFile_);
  DM_LOAD_DICT(DynamicDictContainer::kCrowdOperWholeFile_);
  DM_LOAD_DICT(DynamicDictContainer::kAppTokenCateBoostFile_);
  DM_LOAD_DICT(DynamicDictContainer::kUcSidFile_);
  DM_LOAD_DICT(DynamicDictContainer::kIflowItemSortFile_);
  DM_LOAD_DICT(DynamicDictContainer::kDeviceInfoFile_);
  DM_LOAD_DICT(DynamicDictContainer::kThirdPartyCategoryLrModelFile_);
}

}
}
