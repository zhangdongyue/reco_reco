#pragma once

#include <string>
#include <vector>

#include "serving_base/expiry_map/expiry_map.h"
#include "reco/base/http_communicator/http_client/http_client.h"
#include "reco/bizc/proto/leaf.pb.h"
#include "reco/bizc/reco_index_ha3/item_info.h"

namespace reco {
class NewsIndex;
namespace leafserver {
class RecoRequest;
struct GlobalData;

class VideoComm {
 public:
  explicit VideoComm(reco::NewsIndex* news_index);
  ~VideoComm();

  void GetVideoResults(const reco::user::UserInfo& user_info,
                       const reco::leafserver::RecommendRequest* request,
                       reco::leafserver::DataFromVideoServerResponse* video_response,
                       bool* ret, std::string* err_msg);

  bool SentHttpVideoRequest(const reco::user::UserInfo& user_info,
                            reco::http_communicator::HttpCommunicator* comm,
                            int return_num,
                            int req_timeout,
                            const reco::leafserver::RecommendRequest* request);

  bool GetHttpVideoResponse(reco::http_communicator::HttpCommunicator* comm,
                            reco::leafserver::RecoRequest* reco_request,
                            std::vector<ItemInfo>* reco_items,
                            std::vector<std::string>* shunt_tags);

 private:
  bool GetVideoCandidateCache(const std::string& key, std::string* value);

  void VideoResponseToResults(reco::leafserver::DataFromVideoServerResponse* response,
                              reco::leafserver::RecoRequest* reco_request,
                              std::vector<ItemInfo>* reco_items);
 private:
  GlobalData *global_data_;
  reco::NewsIndex* news_index_;
  static serving_base::ExpiryMap<std::string, std::string>* cache_;
};
}
}

