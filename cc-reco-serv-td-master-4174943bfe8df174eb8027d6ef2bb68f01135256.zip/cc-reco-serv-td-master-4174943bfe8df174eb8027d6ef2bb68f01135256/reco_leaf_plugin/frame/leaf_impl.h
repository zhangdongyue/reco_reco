#pragma once

#include <string>
#include "base/common/basic_types.h"
#include "base/common/callback.h"
#include "base/thread/thread.h"
#include "base/thread/sync.h"
#include "reco/bizc/proto/leaf.pb.h"
#include "serving_base/utility/system_util.h"
#include "reco/serv/reco_leaf_plugin/frame/leaf_controller.h"
#include <memory>
#include <boost/shared_ptr.hpp>

namespace reco {
namespace leafserver{

enum ReqType {
  kInvalidReq = 0,
  kRecommendReq,
  kGetHotNewsReq,
  kVerticalRecommend,
  kWemediaRecommend,
  kImCardRecommend,
  kNewsMapRecommend,
  kSceneCardRecommend,
  kHotCardRecommend,
  kTagRecommend,
  kGetIndexItemInfo,
  kGetIndexQueue,
  kGetIndexQueueUnsort,
};

struct StWorkParam {
  const ::google::protobuf::Message* request;
  ::google::protobuf::Message* response;
  ::Closure* done;
  int64 time_stamp;
  ReqType type;

  StWorkParam() : request(NULL), response(NULL), done(NULL), time_stamp(0), type(kInvalidReq) {}

  StWorkParam(const ::google::protobuf::Message *req, ::google::protobuf::Message *resp,
              ::Closure *closure_done, const int64 stamp, const ReqType req_type) {
    request = req;
    response = resp;
    done = closure_done;
    time_stamp = stamp;
    type = req_type;
  }
};

typedef  boost::shared_ptr<reco::leafserver::LeafController> LeafControllerPtr;

class LeafImpl {
 public:
  LeafImpl();
  ~LeafImpl();

  void reloadLeafConf(const ReloadLeafConfRequest* request,
    ReloadLeafConfResponse* response, Closure* done);

  void getModelVersion(const ModelVerRequest* request,
    ModelVerResponse* response, Closure* done);

  void setModelVersion(const ModelVerRequest* request,
    ModelVerResponse* response, Closure* done);

  void recommend(const RecommendRequest* request,
                 RecommendResponse* response,
                 Closure* done);

  void getHotNews(const GetHotNewsRequest* request,
                  GetHotNewsResponse* response,
                  Closure* done);

  void verticalRecommend(const VerticalRequest* request,
                         VerticalResponse* response,
                         Closure* done);

  void wemediaRecommend(const reco::leafserver::WeMediaRecommendRequest* request,
                        reco::leafserver::WeMediaRecommendResponse* response,
                        Closure* done);

  void imCardRecommend(const reco::leafserver::ImCardRecoRequest* request,
                       reco::leafserver::ImCardRecoResponse* response,
                       Closure* done);

  void getNewsMap(const reco::leafserver::NewsMapRequest* request,
                  reco::leafserver::NewsMapResponse* response,
                  Closure* done);

  void sceneCardRecommend(const reco::leafserver::SceneCardRecoRequest* request,
                          reco::leafserver::SceneCardRecoResponse* response,
                          Closure* done);

  void hotCardRecommend(const reco::leafserver::HotCardRecommendRequest* request,
                        reco::leafserver::HotCardRecommendResponse* response,
                        Closure* done);

  void tagRecommend(const reco::leafserver::TagRecommendRequest* request,
                    reco::leafserver::TagRecommendResponse* response,
                    Closure* done);

  void getIndexItemInfo(const GetIndexItemInfoRequest* request,
                        GetIndexItemInfoResponseHa3* response,
                        Closure* done);

  void getIndexQueue(const GetIndexQueueRequest* request,
                     GetIndexQueueResponse* response,
                     Closure* done);

  void getIndexQueueUnsort(const GetIndexQueueUnsortRequest* request,
                           GetIndexQueueUnsortResponse* response,
                           Closure* done);
private:
  void Process(StWorkParam param); 
  void recommend(const int64 timestamp,
                 const RecommendRequest* request,
                 RecommendResponse* response,
                 Closure* done);

  void getHotNews(const int64 timestamp,
                  const GetHotNewsRequest* request,
                  GetHotNewsResponse* response,
                  Closure* done);

  void verticalRecommend(const int64 timestamp,
                         const VerticalRequest* request,
                         VerticalResponse* response,
                         Closure* done);

  void wemediaRecommend(const int64 timestamp,
                        const reco::leafserver::WeMediaRecommendRequest* request,
                        reco::leafserver::WeMediaRecommendResponse* response,
                        Closure* done);

  void imCardRecommend(const int64 timestamp,
                       const reco::leafserver::ImCardRecoRequest* request,
                       reco::leafserver::ImCardRecoResponse* response,
                       Closure* done);

  void getNewsMap(const int64 timestamp,
                  const reco::leafserver::NewsMapRequest* request,
                  reco::leafserver::NewsMapResponse* response,
                  Closure* done);

  void sceneCardRecommend(const int64 timestamp,
                          const reco::leafserver::SceneCardRecoRequest* request,
                          reco::leafserver::SceneCardRecoResponse* response,
                          Closure* done);

  void hotCardRecommend(const int64 timestamp,
                          const reco::leafserver::HotCardRecommendRequest* request,
                          reco::leafserver::HotCardRecommendResponse* response,
                          Closure* done);

  void tagRecommend(const int64 timestamp,
                    const reco::leafserver::TagRecommendRequest* request,
                    reco::leafserver::TagRecommendResponse* response,
                    Closure* done);

  void getIndexItemInfo(const int64 timestamp,
                        const GetIndexItemInfoRequest* request,
                        GetIndexItemInfoResponseHa3* response,
                        Closure* done);

  void getIndexQueue(const int64 timestamp,
                     const GetIndexQueueRequest* request,
                     GetIndexQueueResponse* response,
                     Closure* done);

  void getIndexQueueUnsort(const int64 timestamp,
                           const GetIndexQueueUnsortRequest* request,
                           GetIndexQueueUnsortResponse* response,
                           Closure* done);
 private:
  std::string hostname_;
  thread::Mutex mutex_;
};
}  // namespace leafserver
}  // namespace reco
