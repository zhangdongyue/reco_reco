//
// Created by allen.fw on 2017/9/1.
//

#include "reco/serv/reco_filter/frame/filter_rule_controller.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/filter_rule/offline/global_filter.h"
#include "reco/bizc/filter_rule/offline/strategy_filter.h"
#include "reco/bizc/filter_rule/offline/app_token_filter.h"
#include "serving_base/utility/timer.h"

namespace reco {
namespace filterserver {

DEFINE_int64_counter(filter_server, global_handle_time, 0, "");
DEFINE_int64_counter(filter_server, global_handle_count, 0, "");
DEFINE_int64_counter(filter_server, global_filter_count, 0, "");
DEFINE_int64_counter(filter_server, strategy_handle_count, 0, "");
DEFINE_int64_counter(filter_server, strategy_handle_time, 0, "");
DEFINE_int64_counter(filter_server, app_token_handle_count, 0, "");
DEFINE_int64_counter(filter_server, app_token_handle_time, 0, "");

FilterRuleController::FilterRuleController() {
  common_filter_ = std::make_shared<reco::filter::GlobalFilter>();
  strategy_filter_ = std::make_shared<reco::filter::StrategyFilter>();
  app_token_filter_ = std::make_shared<reco::filter::AppTokenFilter>();
}

FilterRuleController::~FilterRuleController() {
}

void FilterRuleController::UpdateRecoItem(reco::RecoItem* reco_item) {
  uint64 item_id = reco_item->identity().item_id();
  serving_base::Timer timer;
  int64 cost_us = 0;
  timer.Start();

  COUNTERS_filter_server__global_handle_count.Increase(1);
  bool ret = common_filter_->FilterRule(reco_item);
  cost_us = timer.Interval();
  LOG(INFO) << "global filter cost: " << cost_us << ", item id: " << item_id;
  COUNTERS_filter_server__global_handle_time.Increase(cost_us);
  if (ret) {
    COUNTERS_filter_server__global_filter_count.Increase(1);
    return;
  }

  strategy_filter_->FilterRule(reco_item);
  cost_us = timer.Interval();
  COUNTERS_filter_server__strategy_handle_count.Increase(1);
  COUNTERS_filter_server__strategy_handle_time.Increase(cost_us);
  LOG(INFO) << "strategy filter cost: " << timer.Interval() << ", item id: " << item_id;

  app_token_filter_->FilterRule(reco_item);
  cost_us = timer.Interval();
  COUNTERS_filter_server__app_token_handle_count.Increase(1);
  COUNTERS_filter_server__app_token_handle_time.Increase(cost_us);
  LOG(INFO) << "app token filter cost: " << cost_us << ", item id: " << item_id;

  return;
}
}
}
