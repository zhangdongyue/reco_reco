//
// Created by allen.fw on 2017/9/1.
//

#include <google/protobuf/descriptor.h>
#include <set>
#include "reco/serv/reco_filter/frame/filter_rule_impl.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/serv/reco_filter/frame/filter_rule_controller.h"
#include "serving_base/utility/timer.h"
#include "reco/serv/reco_filter/frame/global_data.h"

namespace reco {
namespace filterserver {

const std::vector<std::string> kListeningFields = {
  "identity", "title", "source", "orig_source", "category", "content", "summary",
  "content_attr",  "source_media", "orig_source_media", "video_storage_info",
  "video_meta_settings", "image", "risk_info", "normalized_title", "offline_filter_rule",
  "publish_platform"
};

const std::vector<std::string> kUpdateFields = {"offline_filter_rule"};

DEFINE_int64_counter(filter_server, update_item_request_count, 0, "");
DEFINE_int64_counter(filter_server, update_item_response_time, 0, "");
DEFINE_int64_counter(filter_server, max_response_time, 0, "max response time, unit: us");
DEFINE_int64_counter(filter_server, cur_thread_busy, 0, "");
DEFINE_int64_counter(filter_server, overload_req_total, 0, "在队列中等待超时的请求数量");
DEFINE_int32(max_block_time, 400, "ms");
DEFINE_int32(max_counter_update_s, 1, "每隔 max_counter_update_s 秒统计一次最大时间");

using reco::itemhandler::GetHandlerContextRequest;
using reco::itemhandler::ItemHandlerContext;
using reco::itemhandler::ItemHandlerRequest;
using reco::itemhandler::ItemHandlerResponse;

FilterRuleImpl::FilterRuleImpl() {
  reco::RecoItem reco_item;  // for field valid only
  const google::protobuf::Descriptor* descriptor = reco_item.GetDescriptor();
  CHECK_NOTNULL(descriptor);

  std::set<std::string> dedup;
  for (size_t i = 0; i < kListeningFields.size(); ++i) {
    const std::string& field = kListeningFields[i];
    if (dedup.find(field) != dedup.end()) {
      continue;
    }
    CHECK_NOTNULL(descriptor->FindFieldByLowercaseName(field));
    *(listening_fields_.Add()) = field;
    dedup.insert(field);
    LOG(INFO) << "I will listen change of field [" << field << "]";
  }

  dedup.clear();
  for (size_t i = 0; i < kUpdateFields.size(); ++i) {
    const std::string& field = kUpdateFields[i];
    if (dedup.find(field) != dedup.end()) {
      continue;
    }
    CHECK_NOTNULL(descriptor->FindFieldByLowercaseName(field));
    *(update_fields_.Add()) = field;
    dedup.insert(field);
    LOG(INFO) << "I will update field [" << field << "]";
  }
}

FilterRuleImpl::~FilterRuleImpl() {
}

void FilterRuleImpl::registerFields(stumy::RpcController* controller,
                                    const GetHandlerContextRequest* request,
                                    ItemHandlerContext* response,
                                    Closure* done) {
  ScopedClosure scoped_done(done);
  response->mutable_listening_fields()->CopyFrom(listening_fields_);
  response->mutable_update_fields()->CopyFrom(update_fields_);
}

void FilterRuleImpl::updateItem(stumy::RpcController* controller,
                                const reco::itemhandler::ItemHandlerRequest* request,
                                reco::itemhandler::ItemHandlerResponse* response,
                                Closure* done) {
  LOG(INFO) << "get item id: " << request->reco_item().identity().item_id();
  StWorkParam param(request, response, done, base::GetTimestamp(), kUpdateItem);
  thread::AutoLock lock(&mutex_);
  if (FilterDataManager::GetGlobalData()->work_thread_pool)
    FilterDataManager::GetGlobalData()->work_thread_pool->AddTask(NewCallback(this, &FilterRuleImpl::Process, param));  // NOLINT
  return;
}

void FilterRuleImpl::Process(StWorkParam param) {
  COUNTERS_filter_server__cur_thread_busy.Increase(1);
  serving_base::Timer timer;
  timer.Start();
  switch (param.type) {
    case kUpdateItem:
      updateItem(param.time_stamp,
                 static_cast<const ItemHandlerRequest*>(param.request),
                 static_cast<ItemHandlerResponse*>(param.response),
                 param.done);
      break;
    default:
      LOG(ERROR) << "invalid req type: " << param.type;
      break;
  }

  int64 now_timestamp = base::GetTimestamp();
  int64 cost_us = now_timestamp - param.time_stamp;
  static std::atomic<int64> next_max_timestamp(0);
  static std::atomic<int64> max_response_time(0);
  if (now_timestamp > next_max_timestamp || cost_us > max_response_time) {
    max_response_time = cost_us;
    COUNTERS_filter_server__max_response_time.Reset(max_response_time);
  }

  if (now_timestamp > next_max_timestamp) {
    next_max_timestamp = now_timestamp + FLAGS_max_counter_update_s * 1000 * 1000;
  }

  COUNTERS_filter_server__cur_thread_busy.Decrease(1);
  return;
}

void FilterRuleImpl::updateItem(const int64 timestamp,
                                const reco::itemhandler::ItemHandlerRequest* request,
                                reco::itemhandler::ItemHandlerResponse* response,
                                Closure* done) {
  ScopedClosure scoped_done(done);
  response->set_success(false);
  response->mutable_reco_item()->CopyFrom(request->reco_item());
  response->mutable_reco_item()->clear_offline_filter_rule();
  response->mutable_reco_item()->mutable_offline_filter_rule()->set_is_filter(true);

  do {
    if (base::GetTimestamp() - timestamp > FLAGS_max_block_time * 1000) {
      LOG(ERROR) << "server overload, do not process req. item_id: "
                 << request->reco_item().identity().item_id();
      COUNTERS_filter_server__overload_req_total.Increase(1);
      break;
    }

    FilterRuleController *filter_rule_controller = FilterDataManager::GetControllerItem();
    if (filter_rule_controller == NULL) {
      LOG(WARNING) << "failed to get filter worker, id:" << response->reco_item().identity().item_id();
      break;
    }

    filter_rule_controller->UpdateRecoItem(response->mutable_reco_item());
    FilterDataManager::ReleaseControllerItem(filter_rule_controller);
    response->set_success(true);
  } while (false);

  int64 cost_ms = base::GetTimestamp() - timestamp;
  COUNTERS_filter_server__update_item_request_count.Increase(1);
  COUNTERS_filter_server__update_item_response_time.Increase(cost_ms);

  LOG(INFO) << "done filter item, ret:" << response->success()
            << ", id:" << response->reco_item().identity().item_id()
            << ", ts:" << cost_ms
            << ", offline_filter_rule:" << response->reco_item().offline_filter_rule().Utf8DebugString();

  return;
}
}
}
