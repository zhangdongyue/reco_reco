//
// Created by allen.fw on 2017/9/1.
//

#include "reco/serv/reco_filter/frame/global_data.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"

namespace reco {
namespace filterserver {

GlobalData::GlobalData() : work_thread_pool(NULL) {
}

GlobalData::~GlobalData() {
  if (work_thread_pool) {
    work_thread_pool->JoinAll();
    delete work_thread_pool;
    work_thread_pool = NULL;
  }
}

bool GlobalData::InitGlobalData(int work_thread_num) {
  work_thread_pool = new thread::ThreadPool(work_thread_num);
  CHECK_NOTNULL(work_thread_pool);

  reco::filter::DynamicDictContainer::RegisterAndLoadOfflineDict();

  return true;
}
}
}
