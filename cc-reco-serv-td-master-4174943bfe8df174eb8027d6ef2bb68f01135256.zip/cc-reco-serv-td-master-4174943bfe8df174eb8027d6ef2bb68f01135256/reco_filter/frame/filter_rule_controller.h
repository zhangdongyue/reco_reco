//
// Created by allen.fw on 2017/9/1.
//

#pragma once

#include <memory>

namespace reco {
class RecoItem;

namespace filter {
class GlobalFilter;
class StrategyFilter;
class AppTokenFilter;
}

namespace filterserver {

class FilterRuleController {
 public:
  FilterRuleController();
  ~FilterRuleController();

  void UpdateRecoItem(reco::RecoItem* reco_item);

 private:
  std::shared_ptr<reco::filter::GlobalFilter> common_filter_;
  std::shared_ptr<reco::filter::StrategyFilter> strategy_filter_;
  std::shared_ptr<reco::filter::AppTokenFilter> app_token_filter_;
};
}
}
