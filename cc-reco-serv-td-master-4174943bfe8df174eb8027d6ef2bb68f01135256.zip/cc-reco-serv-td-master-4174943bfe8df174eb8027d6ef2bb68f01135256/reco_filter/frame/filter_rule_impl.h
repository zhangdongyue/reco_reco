//
// Created by allen.fw on 2017/9/1.
//

#pragma once

#include <string>
#include <vector>

#include "base/common/basic_types.h"
#include "base/thread/blocking_queue.h"
#include "net/rpc/rpc.h"

#include "reco/bizc/proto/item_handler.pb.h"

namespace reco {
namespace filterserver {
class FilterRuleController;

enum ReqType {
  kInvalidReq = 0,
  kUpdateItem,
};

struct StWorkParam {
  const ::google::protobuf::Message* request;
  ::google::protobuf::Message* response;
  ::Closure* done;
  int64 time_stamp;
  ReqType type;

  StWorkParam() {
    request = NULL;
    response = NULL;
    done = NULL;
    time_stamp = 0;
    type = kInvalidReq;
  }

  StWorkParam(const ::google::protobuf::Message *req, ::google::protobuf::Message *resp,
              ::Closure *closure_done, const int64 stamp, const ReqType req_type) {
    request = req;
    response = resp;
    done = closure_done;
    time_stamp = stamp;
    type = req_type;
  }
};

class FilterRuleImpl : public reco::itemhandler::ItemHandler {
 public:
  explicit FilterRuleImpl();
  virtual ~FilterRuleImpl();

  virtual void registerFields(stumy::RpcController* controller,
                            const reco::itemhandler::GetHandlerContextRequest* request,
                            reco::itemhandler::ItemHandlerContext* response,
                            Closure* done);

  virtual void updateItem(stumy::RpcController* controller,
                            const reco::itemhandler::ItemHandlerRequest* request,
                            reco::itemhandler::ItemHandlerResponse* response,
                            Closure* done);

 private:
  // 实际请求处理逻辑
  void Process(StWorkParam param);

  void updateItem(const int64 timestamp,
                  const reco::itemhandler::ItemHandlerRequest* request,
                  reco::itemhandler::ItemHandlerResponse* response,
                  Closure* done);

 private:
  google::protobuf::RepeatedPtrField<std::string> listening_fields_;
  google::protobuf::RepeatedPtrField<std::string> update_fields_;
  thread::Mutex mutex_;
  std::atomic<int64> max_timestamp_;
};
}
}
