//
// Created by allen.fw on 2017/9/1.
//

#pragma once

#include "reco/base/common/singleton.h"
#include "serving_base/data_manager/data_manager.h"

namespace reco {
namespace filterserver {

class FilterRuleController;

struct GlobalData {
  GlobalData();
  ~GlobalData();

  bool InitGlobalData(int work_thread_num);

  ::thread::ThreadPool* work_thread_pool;
};

typedef serving_base::DataManager<FilterRuleController, GlobalData> FilterDataManager;
}
}
