#include <string>
#include <vector>

#include "reco/bizc/proto/item.pb.h"
#include "reco/base/dict_manager/reload_service_impl.h"
#include "reco/serv/reco_filter/frame/global_data.h"
#include "reco/serv/reco_filter/frame/filter_rule_impl.h"
#include "reco/serv/reco_filter/frame/filter_rule_controller.h"

#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "net/rpc/rpc.h"

#include "serving_base/utility/signal.h"
#include "net/counter/export.h"
#include "serving_base/utility/timer.h"

// 这个可执行程序完成 1 个功能：
// 对 reco item 提供线下过滤服务

namespace reco {
DEFINE_string(target_server, "filter_server", "only for dynamic_dict_container compile");
namespace filterserver {
DEFINE_int32(port, 8080, "the listening port on which the serving application listens");
DEFINE_int32(thread_num, 16, "rpc thread num");
}
}

int main(int argc, char* argv[]) {
  base::InitApp(&argc, &argv, "filter server server");
  serving_base::SignalCatcher::Initialize();

  net::counter::HttpCounterExport();

  serving_base::Timer timer;
  timer.Start();

  reco::filterserver::GlobalData global_data;
  CHECK(global_data.InitGlobalData(reco::filterserver::FLAGS_thread_num));
  LOG(INFO) << "init filter server global data time:" << timer.Interval();

  serving_base::DataManangerConfig config;
  config.controller_item_num = reco::filterserver::FLAGS_thread_num;
  reco::filterserver::FilterDataManager::Initialize(config, &global_data);

  LOG(INFO) << "init filter data manager time:" << timer.Interval();

  reco::filterserver::FilterRuleImpl filter_rule_service;
  reco::dm::ReloadServiceImpl reload_service;

  net::rpc::RpcServer::Options opt;
  opt.port = reco::filterserver::FLAGS_port;
  opt.server_thread_num = 2;
  opt.pump_thread_num = 2;
  net::rpc::RpcServer *server = new net::rpc::RpcServer(opt);

  CHECK(server->ExportService(&filter_rule_service));
  CHECK(server->ExportService(&reload_service));

  server->Start();
  LOG(INFO) << "filter server start, total start time:" << timer.Stop();
  ::google::FlushLogFiles(::google::INFO);

  // 初始化, 捕捉 kill 信号
  serving_base::SignalCatcher::WaitForSignal();

  server->Stop();
  delete server;

  LOG(INFO) << "filter server safe stop.";
  ::google::FlushLogFiles(::google::INFO);

  return 0;
}
