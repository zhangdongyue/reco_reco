#include <iostream>
#include <string>

#include "base/thread/blocking_queue.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/proto/item_handler.pb.h"
#include "reco/bizc/common/channel_define.h"
#include "net/rpc_util/rpc_group.h"
#include "reco/bizc/proto/item_keeper.pb.h"
#include "base/common/logging.h"
#include "base/file/file_util.h"

DEFINE_string(item_keeper_server_ip, "11.251.177.91", "item keeper ip");
DEFINE_int32(item_keeper_server_port, 20066, "server port");
DEFINE_string(item_id_file, "", "item id file");
DEFINE_int32(thread_num, 10, "thread num");

using reco::itemkeeper::UpdateItemRequest;
using reco::itemkeeper::UpdateItemFieldResponse;

static net::rpc::RpcGroup* SetupConnection(const std::string& ips, int port,
                                           int timeout, int retry) {
  std::vector<std::string> flds;
  base::SplitString(ips, ",", &flds);
  net::rpc::RpcGroup::Options options;
  options.max_retry_times = retry;
  options.timeout = timeout;
  for (int i = 0; i < (int)flds.size(); ++i) {
    net::rpc::RpcGroup::ServerInfo si(flds[i], port, timeout);
    options.servers.push_back(si);
  }

  auto group = new net::rpc::RpcGroup(options);
  CHECK(group->Connect());
  return group;
}

void GetItemIdsFromFile(const std::string& item_id_file, std::vector<std::vector<uint64> >* item_ids) {
  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(item_id_file, &lines);
  CHECK(!lines.empty());

  std::vector<uint64> ids;
  for (int i =0; i < (int)lines.size(); ++i) {
    base::TrimTrailingWhitespaces(&(lines[i]));
    uint64 id = 0;
    if (!base::StringToUint64(lines[i], &id)) {
      continue;
    }
    ids.emplace_back(id);
  }

  for (size_t i = 0; i < ids.size(); ++i) {
    (*item_ids)[i % FLAGS_thread_num].emplace_back(ids[i]);
  }

  return;
}

void UpdateItemKeeperFields(reco::itemkeeper::ItemKeeper::Stub* stub,
                            std::vector<uint64>* item_ids) {
  UpdateItemRequest request;
  request.mutable_service_identity()->set_service_name("filter_update_fields");
  request.add_exclude_storages(reco::itemkeeper::kCdocQueue);
  request.add_exclude_storages(reco::itemkeeper::kRecoItemQueue);


  UpdateItemFieldResponse response;

  reco::RecoItem reco_item;
  reco_item.mutable_offline_filter_rule()->mutable_app_token_rule_bits()->set_app_token_bits(-1);
  if (!reco_item.SerializePartialToString(request.mutable_reco_item_bytes())) {
    LOG(ERROR) << "reco_item SerializePartialToString fail";
    return;
  }

  for (size_t i = 0; i < item_ids->size(); ++i) {
    const uint64 item_id = (*item_ids)[i];

    response.Clear();
    request.set_item_id(item_id);

    net::rpc::RpcClientController rpc;
    stub->updateItemFields(&rpc, &request, &response, NULL);
    rpc.Wait();
    if (rpc.status() != net::rpc::RpcClientController::kOk
        || !response.success()) {
      LOG(ERROR) << base::StringPrintf("update reco item failed. response error_message[%s], "
                                               "rpc status[%d], item_id[%lu]",
                                       response.err_message().c_str(), rpc.status(), item_id);
      continue;
    }
    LOG(INFO) << "succ update item_id: " << item_id;
  }

  return;
}

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "leaf client");

  net::rpc::RpcGroup* item_keeper_rpc_group;
  item_keeper_rpc_group = SetupConnection(FLAGS_item_keeper_server_ip,
                                           FLAGS_item_keeper_server_port,
                                           10000, 3);
  reco::itemkeeper::ItemKeeper::Stub* item_keeper_stub;
  item_keeper_stub = new reco::itemkeeper::ItemKeeper::Stub(item_keeper_rpc_group);

  CHECK(!FLAGS_item_id_file.empty());
  std::vector<std::vector<uint64> > item_ids(FLAGS_thread_num);
  GetItemIdsFromFile(FLAGS_item_id_file, &item_ids);

  thread::ThreadPool handle_pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    handle_pool.AddTask(NewCallback(UpdateItemKeeperFields, item_keeper_stub, &item_ids[i]));
  }
  handle_pool.JoinAll();

  return 0;
}


