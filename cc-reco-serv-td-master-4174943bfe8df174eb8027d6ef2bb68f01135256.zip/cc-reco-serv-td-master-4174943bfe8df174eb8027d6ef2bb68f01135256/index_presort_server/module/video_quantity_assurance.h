#pragma once
#include <atomic>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <utility>

#include "reco/bizc/reco_index/filter_rule.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/reco_index/file_monitor.h"
#include "reco/bizc/proto/index_aux_data.pb.h"
#include "base/common/basic_types.h"
#include "base/container/dense_hash_map.h"
#include "reco/base/common/singleton.h"
#include "reco/base/dict_manager/dict_manager.h"

namespace base {
class FilePath;
}

namespace reco {

enum QuantityAssuranceType {
  kGeneral = 1,
  kOversea = 2,
};

class VideoQuantityAssurance {
 public:
  VideoQuantityAssurance();

  ~VideoQuantityAssurance();

  bool IsGeneralSource(const std::string& source);

  bool IsOverseaSource(const std::string& source);

  void Init();

 private:
  boost::shared_ptr<const std::unordered_map<std::string, int> > GetQuantityAssuranceSource() {
    return DM_GET_DICT(reco::dm::DictManager::UnorderedMapStrInt, kQuantityAssuranceFile_);
  }

 private:
  static const char* kQuantityAssuranceFile_;
};

typedef reco::common::singleton_default<VideoQuantityAssurance> VideoQuantityAssuranceIns;
}
