#include "reco/serv/index_presort_server/module/video_stat_info_updator.h"
#include "base/strings/string_number_conversions.h"
#include "serving_base/utility/timer.h"

namespace reco {

DECLARE_string(target_server);

DEFINE_int32(update_video_stat_interval_second, -1,
             "video stat 更新线程运行的时间间隔(秒), 设为 -1 不运行此线程");
DEFINE_string(key_prefix, "VideoStatInfo-", "video stat info prefix key");
DEFINE_int32(get_stat_thread_num, 20, "获取视频统计信息的线程数量");

VideoStatInfoUpdator::VideoStatInfoUpdator(const NewsIndex* news_index) {
  redis_ = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);
  news_index_ = news_index;
}

VideoStatInfoUpdator::~VideoStatInfoUpdator() {
  update_video_stat_thread_stop_ = true;
  if (FLAGS_update_video_stat_interval_second > -1) {
    update_video_stat_thread_.Join();
  }
  if (redis_) {
    delete redis_;
    redis_ = NULL;
  }
}

void VideoStatInfoUpdator::Start() {
  if (FLAGS_target_server != "video_server") return;
  if (FLAGS_update_video_stat_interval_second > -1) {
    // CHECK(redis_->GetPool()->IsRun());

    update_video_stat_thread_.Start(NewCallback(this, &VideoStatInfoUpdator::UpdateVideoStatInfoThread));
    LOG(INFO) << "update meta thread started.";

  } else {
    LOG(INFO) << "just start a dummy VideoStatInfoUpdator";
  }
}

bool VideoStatInfoUpdator::GetVideoStatInfo(uint64 item_id, VideoStatInfo* info) const {
  if (info == NULL) {
    return false;
  }
  auto dict = item_video_stat_info_.GetDict();
  auto it = dict->find(item_id);
  if (it != dict->end()) {
    info->view_count = it->second.view_count;
    info->view_ratio = it->second.view_ratio;
    info->total_view_time = it->second.total_view_time;
    return true;
  }
  return false;
}

void VideoStatInfoUpdator::UpdateVideoStatInfoThread() {
  update_video_stat_thread_stop_ = false;
  while (!update_video_stat_thread_stop_) {
    if (!item_video_stat_info_.CanSwitch()) {
      LOG(INFO) << "video stat dict not ready to switch";
      base::SleepForSeconds(10);
      continue;
    }

    LOG(INFO) << "video stat update thread begins to run";

    UpdateVideoStatInfo();

    LOG(INFO) << "video stat update thread end running";

    base::SleepForSeconds(FLAGS_update_video_stat_interval_second);
  }
}

void VideoStatInfoUpdator::UpdateVideoStatInfo() {
  int64 index_doc_num = news_index_->GetDocNum();
  if (index_doc_num <= 0) {
    LOG(INFO) << "news index has null item";
    return;
  }

  auto dict = item_video_stat_info_.GetInactiveDict();
  dict->clear();

  int64 err_num = 0, invalid_num = 0, succ_num = 0;
  int64 total_doc_num = 0, total_req_num = 0;
  thread::ThreadPool get_stat_thread_pool(FLAGS_get_stat_thread_num);
  std::unordered_set<uint64> dedup_set;
  for (int doc_id = news_index_->MinDocLocalId(); doc_id < news_index_->MaxDocLocalId(); ++doc_id) {
    ++total_doc_num;
    if (!news_index_->IsValidByDocId(doc_id)) {
      ++invalid_num;
      continue;
    }
    reco::ItemType item_type;
    if (!news_index_->GetItemTypeByDocId(doc_id, &item_type)) {
      LOG(WARNING) << "failed to get item type from doc id: " << doc_id;
      ++err_num;
      continue;
    }
    // 过滤非纯视频的内容
    if (item_type != reco::kPureVideo) continue;
    uint64 item_id;
    if (!news_index_->GetItemIdByDocId(doc_id, &item_id)) {
      LOG(WARNING) << "failed to get item id from doc id: " << doc_id;
      ++err_num;
      continue;
    }
    if (dedup_set.find(item_id) != dedup_set.end()) {
      continue;
    }
    dedup_set.insert(item_id);

    ++total_req_num;
    get_stat_thread_pool.AddTask(NewCallback(this, &VideoStatInfoUpdator::GetVideoStat,
                                             item_id, dict, &err_num, &succ_num));
  }

  get_stat_thread_pool.JoinAll();
  LOG(INFO) << base::StringPrintf("update video stat info succ, total_doc_num[%ld], total_req_num[%ld], "
                                  "invalid_num[%ld], err_num[%ld], succ_num[%ld]", total_doc_num,
                                  total_req_num, invalid_num, err_num, succ_num);

  item_video_stat_info_.SwitchDict();

  return;
}

void VideoStatInfoUpdator::GetVideoStat(const uint64 item_id,
                                        std::unordered_map<uint64, VideoStatInfo>* infos,
                                        int64 *err_num, int64 *succ_num) {
  std::string key = gen_redis_key(item_id);
  std::unordered_map<std::string, std::string> field_values;
  if (!redis_->HGetAll(key, &field_values) || field_values.empty()) {
    thread::AutoLock lock(&update_stat_mutex_);
    ++(*err_num);
    return;
  }

  thread::AutoLock lock(&update_stat_mutex_);
  auto iter = infos->insert(std::make_pair(item_id, VideoStatInfo()));
  ParseVideoStat(field_values, &(iter.first->second));
  ++(*succ_num);
}

std::string VideoStatInfoUpdator::gen_redis_key(const uint64 item_id) {
  std::string key;
  base::StringAppendF(&key, "%s%lu", FLAGS_key_prefix.c_str(), item_id);

  return key;
}

void VideoStatInfoUpdator::ParseVideoStat(const std::unordered_map<std::string, std::string>& field_values,
                                          VideoStatInfo* info) {
  double value = 0.0;
  auto iter = field_values.find("ViewCount");
  if (iter != field_values.end()) {
    if (base::StringToDouble(iter->second, &value)) {
      info->view_count = value;
    }
  }

  iter = field_values.find("ViewRatio");
  if (iter != field_values.end()) {
    if (base::StringToDouble(iter->second, &value)) {
      info->view_ratio = value;
    }
  }

  iter = field_values.find("TotalViewtime");
  if (iter != field_values.end()) {
    if (base::StringToDouble(iter->second, &value)) {
      info->total_view_time = value;
    }
  }
}

}  // namespace reco
