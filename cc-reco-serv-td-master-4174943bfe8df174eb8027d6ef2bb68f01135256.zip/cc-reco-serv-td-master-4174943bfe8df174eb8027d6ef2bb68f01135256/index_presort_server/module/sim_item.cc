#include "reco/bizc/reco_index/sim_item.h"
#include "reco/bizc/sim_lib/sim_lib.h"

namespace reco {
DEFINE_bool(skip_incr_sim_update, false, "");

SimItem::SimItem() {
  sim_lib_ = new reco::sim_lib::SimLib(FLAGS_skip_incr_sim_update);
}

SimItem::~SimItem() {
  if (sim_lib_) {
    delete sim_lib_;
    sim_lib_ = NULL;
  }
}

void SimItem::Start() {
  sim_lib_->Start();
}

void SimItem::Stop() {
  sim_lib_->Stop();
}

const std::set<uint64>* SimItem::GetSimItemIds(uint64 item_id) const {
  return sim_lib_->getSimIdsByItemid(item_id);
}
/*
bool SimItem::GetSimItemIds(uint64 item_id, std::vector<uint64>* sim_ids) const {
  if (sim_ids == NULL) {
    return false;
  }
  if (sim_lib_->getSimIdsByItemid(item_id, sim_ids)) {
    return true;
  }
  return false;
}
*/
bool SimItem::GetSimElems(uint64 item_id, std::vector<reco::sim_lib::SimElem>* sim_elems) const {
  if (sim_elems == NULL) {
    return false;
  }
  if (sim_lib_->getSimElemsByItemid(item_id, sim_elems)) {
    return true;
  }
  return false;
}

uint64 SimItem::GetParent(uint64 item_id) const {
  return sim_lib_->getSimParentByItemid(item_id);
}

bool SimItem::HasCheckedBySimServer(uint64 item_id) const {
  return sim_lib_->HasSimInfo(item_id);
}
}
