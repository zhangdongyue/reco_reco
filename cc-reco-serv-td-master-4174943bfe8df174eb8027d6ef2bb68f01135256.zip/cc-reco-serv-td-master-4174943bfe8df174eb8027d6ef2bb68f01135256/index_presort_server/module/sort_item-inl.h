#pragma once
#include <atomic>
#include <algorithm>
#include <cmath>
#include <string>
#include <queue>
#include <vector>
#include <unordered_map>
#include <unordered_set>

#include "reco/base/dict_manager/dict_manager.h"
#include "reco/bizc/common/wrapped_category.h"
#include "reco/bizc/common/channel_define.h"
#include "reco/bizc/reco_index/item_info.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/thread/sync.h"

namespace reco {

inline const std::vector<ItemInfo>* SortItem::GetTermReco(const std::string& term) const {
  auto queue = term_queue_.GetDict();
  if (queue->find(term) == queue->end()) {
    LOG(ERROR) << "term reco not found. term:" << term << " current queue size:" << queue->size();
    return NULL;
  }
  return &queue->at(term);
}

inline const std::vector<ItemInfo>* SortItem::GetDefaultReco() const {
  return app_index_.GetDict()->GetIndex();
}

inline const std::unordered_map<std::string, std::unordered_set<uint64>>* SortItem::GetWeMediaItemsDict() const {  // NOLINT
  return wemedia_items_dict_.GetDict();
}

inline const std::vector<ItemInfo>* SortItem::GetUCBDefaultReco() const {
  return ucb_index_.GetDict()->GetIndex();
}

inline const std::vector<ItemInfo>* SortItem::GetHotCardDefaultReco() const {
  return hot_card_index_.GetDict()->GetIndex();
}

inline const std::vector<ItemInfo>* SortItem::GetJingpinDefaultReco() const {
  return jingpin_index_.GetDict()->GetIndex();
}

// inline const std::vector<ItemInfo>* SortItem::GetHotVideoDefaultReco() const {
//   return hot_video_index_.GetDict()->GetIndex();
// }

inline const std::vector<ItemInfo>* SortItem::GetSubjectDefaultReco() const {
  return subject_index_.GetDict()->GetIndex();
}

inline bool SortItem::GetItemIdByYoukuVideoId(uint64 youku_video_id, uint64 *item_id) const {
  auto dict = youku_video_id_dict_.GetDict();
  auto iter = dict->find(youku_video_id);
  if (iter == dict->end()) {
    return false;
  }
  *item_id = iter->second;
  return true;
}

inline bool SortItem::GetSubjectIdByItemId(uint64 item_id, uint64 *subject_id) const {
  auto dict = item_to_subject_dict_.GetDict();
  auto iter = dict->find(item_id);
  if (iter == dict->end()) {
    return false;
  }
  *subject_id = iter->second;
  return true;
}

inline const reco::FeatureVector* SortItem::GetSubjectVideoTagFeatureByItemId(uint64 item_id) const {
  auto dict = subject_video_tag_feature_dict_.GetDict();
  auto iter = dict->find(item_id);
  if (iter == dict->end()) {
    return NULL;
  }
  return &(iter->second);
}

inline const std::vector<ItemInfo>* SortItem::GetDefaultReco(const reco::Category& category, bool timely) const {  // NOLINT
  auto dict = category_index_.GetDict();
  auto jt = dict->find(reco::common::WrappedCategory(category));
  if (jt == dict->end()) {
    LOG(ERROR) << "not found in index, category: " << category.Utf8DebugString();
    return NULL;
  } else {
    if (!timely) {
      return jt->second.GetIndex();
    } else {
      return jt->second.GetTimelyIndex();
    }
  }
}

inline const std::vector<ItemInfo>* SortItem::GetGuaranteeQuantityReco(const reco::Category& category) const {  // NOLINT
  auto dict = media_quantity_index_.GetDict();
  auto jt = dict->find(reco::common::WrappedCategory(category));
  if (jt == dict->end()) {
    LOG(INFO) << "not found in quantity index, category: " << category.Utf8DebugString();
    return NULL;
  } else {
    return jt->second.GetIndex();
  }
}

inline const std::vector<ItemInfo>* SortItem::GetVideoGuaranteeQuantityReco(const reco::Category& category) const {  // NOLINT
  auto dict = video_media_quantity_index_.GetDict();
  auto jt = dict->find(reco::common::WrappedCategory(category));
  if (jt == dict->end()) {
    VLOG(1) << "not found in quantity index, category: " << category.Utf8DebugString();
    return NULL;
  } else {
    return jt->second.GetIndex();
  }
}

inline bool SortItem::ContainInCategoryQueue(const reco::Category& category, int32 doc_id) const {
  auto dict = category_index_.GetDict();
  auto jt = dict->find(reco::common::WrappedCategory(category));
  if (jt == dict->end()) return false;
  return jt->second.Contain(doc_id);
}

inline const std::vector<ItemInfo>* SortItem::GetLocalDefaultReco(int64 region_id) const {
  auto dict = region_index_.GetDict();
  auto jt = dict->find(region_id);
  if (jt == dict->end()) {
    LOG(ERROR) << "region_id not found in region_index, region_id: " << region_id;
    return NULL;
  } else {
    return jt->second.GetIndex();
  }
}

inline const std::vector<ItemInfo>* SortItem::GetPOIDefaultReco(int64 area_id) const {
  auto dict = poi_index_.GetDict();
  auto jt = dict->find(area_id);
  if (jt == dict->end()) {
    LOG(ERROR) << "hash not found in poi_index, hash: " << area_id
               << " current poi_index size:" << dict->size();
    return NULL;
  } else {
    return jt->second.GetIndex();
  }
}

inline const std::vector<ItemInfo>* SortItem::GetLocalBreakingDefaultReco(int64 region_id) const {
  auto dict = local_breaking_index_.GetDict();
  auto jt = dict->find(region_id);
  if (jt == dict->end()) {
    LOG(ERROR) << "hash not found in local_breaking_index, hash: " << region_id
               << "current local_breaking_index size:" << dict->size();
    return NULL;
  } else {
    return jt->second.GetIndex();
  }
}

inline const std::vector<ItemInfo>* SortItem::GetDefaultReco(int64 channel_id, int64 region_id) const {
  if (IsVideoChannel(channel_id)) {
    return GetVideoDefaultReco(channel_id);
  }
  if (channel_id == reco::common::kJingpinChannelId) {
    return GetJingpinDefaultReco();
  }
  if (channel_id == reco::common::kLocalChannelId) {
    return GetLocalDefaultReco(region_id);
  }
  auto dict = channel_index_.GetDict();
  auto jt = dict->find(channel_id);
  if (jt == dict->end()) {
    LOG(INFO) << "not found in index, channel_id: " << channel_id;
    return NULL;
  } else {
    return jt->second.GetIndex();
  }
}

inline const std::vector<ItemInfo>* SortItem::GetVideoDefaultReco(const int64 channel_id,
                                                                  bool explore,
                                                                  bool is_fully_shown) const {
  auto dict = channel_video_index_.GetDict();
  if (explore) dict = channel_video_explore_index_.GetDict();
  if (is_fully_shown) dict = channel_video_fully_shown_index_.GetDict();

  auto jt = dict->find(channel_id);
  if (jt == dict->end()) {
    LOG(ERROR) << "not found in channel_video_index, channel_id: " << channel_id;
    return NULL;
  } else {
    return jt->second.GetIndex();
  }
}

inline const std::vector<dm::UgcSeedInfo>* SortItem::GetUgcSeedsByTag(const std::string& tag) const {
  const UgcSeedMap* dict = ugc_video_tag_index_.GetDict();
  auto jt = dict->find(tag);
  if (jt == dict->end()) {
    VLOG(2) << "not found in ugc_video_tag_index_, tag_name: " << tag;
    return NULL;
  } else {
    return &(jt->second);
  }
}

inline const std::vector<dm::UgcSeedInfo>* SortItem::GetUgcSeedsByL1Cate(const std::string& l1_cate) const {
  auto dict = ugc_video_l1_cate_index_.GetDict();
  auto jt = dict->find(l1_cate);
  if (jt == dict->end()) {
    VLOG(2) << "not found in ugc_video_l1_cate_index_, l1_cate: " << l1_cate;
    return NULL;
  } else {
    return &(jt->second);
  }
}

inline const std::vector<dm::UgcSeedInfo>* SortItem::GetUgcSeedsByL2Cate(const std::string& l2_cate) const {
  auto dict = ugc_video_l2_cate_index_.GetDict();
  auto jt = dict->find(l2_cate);
  if (jt == dict->end()) {
    VLOG(2) << "not found in ugc_video_l2_cate_index_, l2_cate: " << l2_cate;
    return NULL;
  } else {
    return &(jt->second);
  }
}

inline const std::vector<dm::UgcSeedInfo>* SortItem::GetUgcSeedsByCareer(const std::string& career) const {
  auto dict = ugc_video_career_index_.GetDict();
  auto jt = dict->find(career);
  if (jt == dict->end()) {
    VLOG(2) << "not found in ugc_video_career_index_, career: " << career;
    return NULL;
  } else {
    return &(jt->second);
  }
}

inline const dm::UgcSeedInfo* SortItem::GetUgcSeedInfoBySeedName(const std::string& seed_name) const {
  auto dict = ugc_seed_info_index_.GetDict();
  auto jt = dict->find(seed_name);
  if (jt == dict->end()) {
    VLOG(2) << "not found in ugc_seed_info_index__, seed_name: " << seed_name;
    return NULL;
  } else {
    return &jt->second;
  }
}


inline const std::vector<ItemInfo>* SortItem::GetItemsByYoukuShowId(const std::string& youku_show_id) const {
  auto dict = youku_show_video_index_.GetDict();
  auto jt = dict->find(youku_show_id);
  if (jt == dict->end()) {
    LOG(ERROR) << "not found in youku_show_video_index_, show_id: " << youku_show_id;
    return NULL;
  } else {
    return &(jt->second);
  }
}

inline void SortItem::GetVideoCategories(int level, std::vector<reco::Category>* categories) const {
  categories->clear();
  auto dict = video_category_index_.GetDict();
  for (auto jt = dict->begin(); jt != dict->end(); ++jt) {
    const reco::Category& category = jt->first.ToCategory();
    if (category.level() != level) {
      continue;
    }
    categories->push_back(category);
  }
}

inline void SortItem::GetCategories(int level, std::vector<reco::Category>* categories) const {
  categories->clear();
  auto dict = category_index_.GetDict();
  for (auto jt = dict->begin(); jt != dict->end(); ++jt) {
    const reco::Category& category = jt->first.ToCategory();
    if (category.level() != level) {
      continue;
    }
    categories->push_back(category);
  }
}

inline const std::vector<ItemInfo>* SortItem::GetVideoDefaultReco(const reco::Category& category) const {
  auto dict = video_category_index_.GetDict();
  auto jt = dict->find(reco::common::WrappedCategory(category));
  if (jt == dict->end()) {
    LOG(ERROR) << "not found in index, category: " << category.Utf8DebugString();
    return NULL;
  } else {
    return jt->second.GetIndex();
  }
}

inline bool SortItem::GetItemTimeAxisInfoByItemId(uint64 item_id,
                                                  time_axis::TimeAxisInfo *timeaxis_info) const {
  auto dict = timeaxis_dict_.GetDict();
  auto jt = dict->find(item_id);
  if (jt == dict->end()) return false;
  timeaxis_info->CopyFrom(jt->second);
  return true;
}

inline bool SortItem::GetLatestNewsByEventName(const std::string& event_name, uint64* latest_item_id,
                                               time_axis::TimeAxisInfo* timeaxis_info) const {
  auto dict = timeaxis_latest_news_dict_.GetDict();
  auto jt = dict->find(event_name);
  if (jt == dict->end()) return false;
  *latest_item_id = jt->second.first;
  timeaxis_info->CopyFrom(jt->second.second);
  return true;
}

inline int SortItem::CalcIndexScore(const ItemInfo& item, bool use_predict_ctr, int* miss) const {
  if (item.item_type == reco::kPureVideo) {
    int index_score = (item.ctr + 0.001) * 1000;
    return index_score;
  }

  int ret = 0;
  if (use_predict_ctr) {
    ret = item.predict_ctr;
  }
  if (ret == -1) {
    *miss += 1;
    VLOG(2) << "itemid: " << item.item_id << " predict_ctr: " << ret;
  }
  if (ret == -1 || !use_predict_ctr) {
    int index_score = (item.ctr + 0.001) * 1000;
    // 对于科技类 new_pr 有分的保证召回
    if (item.new_pr != 0 && item.category == "科技") {
      index_score = std::min(1000, index_score + 250);
    }
    if (item.time_level == reco::kMidTimeliness) {
      index_score *= 0.6;
    } else if (item.time_level == reco::kBadTimeliness) {
      index_score *= 0.3;
    }

    ret = index_score;
  }
  return ret;
}

inline const std::vector<ItemInfo>* SortItem::GetMiningStrategyReco(int32 strategy) const {
  auto iter = mining_strategy_item_.find(strategy);
  if (iter != mining_strategy_item_.end()) {
    return &(iter->second);
  }
  return NULL;
}
}  // namespace reco
