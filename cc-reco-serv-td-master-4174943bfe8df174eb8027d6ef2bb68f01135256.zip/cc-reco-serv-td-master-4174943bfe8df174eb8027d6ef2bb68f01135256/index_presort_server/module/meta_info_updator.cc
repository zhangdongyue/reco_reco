#include "reco/serv/index_presort_server/module/meta_info_updator.h"
#include "reco/serv/index_presort_server/module/meta_info_algo.h"
#include "reco/serv/index_presort_server/module/media_quantity_assurance.h"
#include "base/common/basic_types.h"
#include "base/file/memory_mapped_file.h"
#include "base/encoding/line_escape.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/file/file_stream.h"
#include "base/thread/thread.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "serving_base/utility/timer.h"
#include "serving_base/utility/time_helper.h"

#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/bizc/common/item_level_define.h"
#include "reco/bizc/proto/index_aux_data.pb.h"
#include "reco/bizc/reco_index/sim_item.h"
// #include "reco/bizc/reco_index/origin_info_updator.h"
#include "reco/bizc/common/appname_define.h"
#include "base/hash_function/term.h"

// kafka
DEFINE_string(meta_kafka_topic, "meta_info_test", "");
DEFINE_string(meta_kafka_group_id, "meta_update_test", "");
DEFINE_int32(meta_kafka_partition, 10, "");
DEFINE_int32(meta_kafka_data_version, -1, "");

DEFINE_bool(use_meta_data, true, "");
DEFINE_string(meta_dump_file, "meta_dump_file", "");

DEFINE_double(duration_tuning_rate, 0.2, "");
DEFINE_int32(manual_oper_item_incr_show, 5000, "good wemedia item show incr num.");
DEFINE_double(manual_oper_default_ctr, 0.15, "wemedia incr stats's ctr.");
DEFINE_int32(coper_media_item_incr_show, 0, "coper media item show incr num.");
DEFINE_double(coper_media_item_default_ctr, 0.1, "coper media incr stats's ctr.");

DEFINE_bool(item_ctr_debug, false, "");
DEFINE_bool(is_video_index, false, "whether is for video index");
DEFINE_double(pctr_weight, 1.0, "");
DEFINE_double(hot_monitor_rate, 0.5, "");

DEFINE_double(tudou_producer_boost, 1.5, "");
DEFINE_double(basic_ctr_score, 0.03, "");
DEFINE_double(quantity_assurance_general_boost, 1.2, "");
DEFINE_double(quantity_assurance_oversea_boost, 1.2, "");
DEFINE_int32(quantity_assurance_show_thr, 5000, "保量阈值");

DEFINE_string(new_itemq_field_name, "NewItemq", "");

DEFINE_double_counter(reco_index, itemq_lack_ratio, 0, "预估的 item ctr 的缺失比例");
DEFINE_double_counter(reco_index, meta_error_ratio, 0, "meta redis 查询错误的比例");
DEFINE_double_counter(reco_index, meta_lack_ratio, 0, "meta redis 查询错误的比例");
DEFINE_int64_counter(reco_index, meta_update_cnt, 0, "");

// in meta_info_algo.cc
DECLARE_double(wemedia_default_ctr);
DECLARE_double(source_ctr_influence_ratio);
DECLARE_string(index_dir);

namespace reco {
DECLARE_string(log_kafka_brokers);
DEFINE_string(target_server, "", "");
DEFINE_int32(video_confidence_show_num, 5000, "视频展现充分的阈值");

MetaInfoUpdator::MetaInfoUpdator(const NewsIndex* news_index, const reco::SimItem* sim_item) {
                                 // const reco::OriginInfoUpdator* orig_item) {
  item_meta_info_ = new base::dense_hash_map<uint64, MetaInfo>();
  item_meta_info_->set_empty_key(0u);

  // redis_ = new reco::redis::RedisCli(reco::redis::FLAGS_redis_pool_ips);
  news_index_ = news_index;
  sim_item_ = sim_item;
  update_meta_thread_stop_ = false;
  meta_req_cnt_ = 1;
  meta_missing_cnt_ = 1;
  // orig_item_ = orig_item;
  meta_msg_start_sec_ = 0;

  if (FLAGS_target_server == "video_server") {
    VideoQuantityAssuranceIns::instance().Init();
  }
}

MetaInfoUpdator::~MetaInfoUpdator() {
  update_meta_thread_stop_ = true;
  update_meta_thread_.Join();

  /*
  if (redis_) {
    delete redis_;
    redis_ = NULL;
  }
  */
}

void MetaInfoUpdator::ParseMeta(const uint64 item_id,
                                const std::unordered_map<std::string, std::string>& field_values,
                                MetaInfo* meta) {
  int value = 0;
  auto iter = field_values.find(reco::item_level::kTimeLevelField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->time_level = reco::TimeLevel(value);
    }
  }

  iter = field_values.find(reco::item_level::kSiteLevelField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->site_level = reco::SiteLevel(value);
    }
  }

  iter = field_values.find(reco::item_level::kHotLevelField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      value = std::min(reco::item_level::kManualHotScoreThres, value);
      meta->hot_level = value;
    }
  }

  iter = field_values.find(reco::item_level::kPRScoreField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->pr_level = value;
    }
  }

  iter = field_values.find(reco::item_level::kStatItemqField);
  if (iter != field_values.end()
      && base::StringToInt(iter->second, &value)
      && reco::kBadItemq <= value
      && value < reco::kBoundaryItemq) {
    meta->item_quality = value;
  } else {
    meta->item_quality = reco::kNormalItemq;
  }
  ItemQualityAttr quality_attr;
  if (meta->item_quality < reco::kJingpinItemq
      && news_index_->GetItemQualityAttrByItemId(item_id, &quality_attr)) {
    if (quality_attr.manual_jingpin_level() > 0) {
      meta->item_quality = reco::kJingpinItemq;
    }
  }

  iter = field_values.find(reco::item_level::kSensitiveTypeField);
  if (iter != field_values.end()) {
    if (base::StringToInt(iter->second, &value)) {
      meta->sensitive_type = reco::SensitiveType(value);
    }
  }

  // iter = field_values.find(reco::item_level::kShowCountField);
  iter = field_values.find(reco::item_level::kShowField);
  if (iter != field_values.end()) {
    if (!base::StringToUint64(iter->second, &meta->show_count)) {
      meta->show_count = 0;
    }
  }

  // iter = field_values.find(reco::item_level::kClickCountField);
  iter = field_values.find(reco::item_level::kClickField);
  if (iter != field_values.end()) {
    if (!base::StringToUint64(iter->second, &meta->click_count)) {
      meta->click_count = 0;
    }
  }

  iter = field_values.find(reco::item_level::kDurationField);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &meta->duration)) {
      meta->duration = 70;
    }
  }

  // iter = field_values.find(reco::item_level::kClickCountField);
  iter = field_values.find("new_pr");
  if (iter != field_values.end()) {
    int32 new_pr = 0;
    if (base::StringToInt(iter->second, &new_pr)) {
      meta->new_pr = new_pr;
    } else {
      meta->new_pr = 0;
    }
  }

  iter = field_values.find(reco::item_level::kSpiderScoreField);
  if (iter != field_values.end()) {
    double spider_score = 0;
    base::StringToDouble(iter->second, &spider_score);
    meta->spider_score = (float)spider_score;
  } else {
    int spider_comment = 0;
    iter = field_values.find(reco::item_level::kSpiderCommentCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_comment);
    }
    int spider_up = 0;
    iter = field_values.find(reco::item_level::kSpiderUpCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_up);
    }
    int spider_down = 0;
    iter = field_values.find(reco::item_level::kSpiderDownCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_down);
    }
    int spider_read_count = 0;
    iter = field_values.find(reco::item_level::kSpiderReadCountField);
    if (iter != field_values.end()) {
      base::StringToInt(iter->second, &spider_read_count);
    }
    meta->spider_score = static_cast<float>(spider_comment) * 2 + static_cast<float>(spider_up) * 1.5
        + static_cast<float>(spider_down) * 0.5 + static_cast<float>(spider_read_count);
  }

  iter = field_values.find(reco::item_level::kCtrqField);
  if (iter != field_values.end()) {
    double p_ctr = 0.0;
    if (base::StringToDouble(iter->second, &p_ctr)) {
      meta->p_ctr = p_ctr;
    } else {
      meta->p_ctr = 0.0;
    }
  }

  iter = field_values.find(FLAGS_new_itemq_field_name);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &meta->new_itemq)) {
      meta->new_itemq = -1;
    }
  }

  // predict_ctr
  iter = field_values.find(reco::item_level::kPredictCtr);
  if (iter != field_values.end()) {
    if (!base::StringToInt(iter->second, &meta->predict_ctr)) {
      meta->predict_ctr = -1;
    }
  }
}

/*
void MetaInfoUpdator::GetMeta(const uint64 item_id,
                              base::dense_hash_map<uint64, MetaInfo>* item_metas,
                              int64* err_num,
                              int64* not_exist_num) {
  std::string key;
  base::StringAppendF(&key, "%s%lu", reco::item_level::kItemRedisKeyPrefix, item_id);

  std::unordered_map<std::string, std::string> field_values;
  if (!redis_->HGetAll(key, &field_values)) {
    thread::AutoLock lock(&update_meta_mutex_);
    ++(*err_num);
    return;
  }

  if (field_values.empty()) {
    thread::AutoLock lock(&update_meta_mutex_);
    ++(*not_exist_num);
    return;
  }

  thread::AutoLock lock(&update_meta_mutex_);
  auto iter = item_metas->insert(std::make_pair(item_id, MetaInfo()));
  ParseMeta(item_id, field_values, &(iter.first->second));
  return;
}
*/

/*
void MetaInfoUpdator::LoadMetaFromFile() {
  LOG(INFO) << "loading meta from file.";

  base::FilePath meta_file(FLAGS_index_dir + meta_dump_file_);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(meta_file, &lines) || lines.size() < 1) {
    LOG(ERROR) << "load meta dump file failed.";
    if (FLAGS_need_start_from_file) {
      CHECK(false);
    } else {
      return;
    }
  }

  uint64 ts;
  if (serving_base::TimeHelper::StringToTimestamp(lines[0], "%Y-%m-%d %H:%M:%S", &ts)) {
    meta_timestamp_sec_ = (int64)ts / 1e6;
  }
  else {
    meta_timestamp_sec_ = base::GetTimestamp() / 1e6;
    LOG(ERROR) << "failed to get meta file timestamp.";
  }

  int valid_line_num = 0;
  for (const auto& elem : lines) {
    // item_id:field_values
    std::vector<std::string> id_fields;
    base::SplitString(elem, ":", &id_fields);
    if (id_fields.size() < 2) continue;
    uint64 item_id;
    if (!base::StringToUint64(id_fields[0], &item_id)) continue;

    // field_val1,field_val2,...
    std::vector<std::string> kv_pairs;
    base::SplitString(id_fields[1], ",", &kv_pairs);
    if (kv_pairs.size() == 0) continue;

    // k|v
    std::unordered_map<std::string, std::string> field_values;
    for (const auto& kv : kv_pairs) {
      std::vector<std::string> kv_field;
      base::SplitString(kv, "|", &kv_field);
      if (kv_field.size() < 2) continue;
      field_values[kv_field[0]] = kv_field[1];
    }
    if (field_values.size() == 0) continue;

    valid_line_num++;
    thread::AutoLock lock(&update_meta_mutex_);
    MetaInfo* meta_info = &(*item_meta_info_)[item_id];
    ParseMeta(item_id, field_values, meta_info);
  }

  LOG(INFO) << "meta file line num:" << lines.size()
            << " valid line num:" << valid_line_num
            << " meta info size:" << item_meta_info_->size();
}
*/

namespace {
// NOTE(liufei): 一下特征处理的代码基本是实验性质，支持快速调整特征
// ctr 相关 feature 处理

// 取特征簇下最精准的特征值
/*
float SquashFeatureValue(const std::unordered_map<std::string, float>& feature_model,
                         const std::vector<std::string>& features,
                         std::string* feature) {
  for (auto i = features.begin(); i != features.end(); ++i) {
    auto iter = feature_model.find(*i);
    if (iter != feature_model.end()) {
      *feature = iter->first;
      return iter->second;
    }
  }
  return 0.0f;
}
*/
}  // namespace

void MetaInfoUpdator::FillCtrAttr() {
  serving_base::Timer timer;
  timer.Start();

  base::Time expire_time = base::Time::Now() - base::TimeDelta::FromDays(30);
  const int64 expire_timestamp = expire_time.ToDoubleT() * base::Time::kMicrosecondsPerSecond;
  category_duration_stats_.clear();
  std::vector<ItemInfo> items;
  for (int docid = news_index_->MinDocLocalId(); docid < news_index_->MaxDocLocalId(); ++docid) {
    if (!news_index_->IsValidByDocId(docid)) {
      continue;
    }
    ItemInfo item;
    if (!news_index_->GetItemInfoByDocId(docid, &item, false)) {
      continue;
    }

    // category duration stats
    if (item.duration > 0
        && item.category != "") {
      auto iter = category_duration_stats_.find(item.category);
      if (iter != category_duration_stats_.end()) {
        iter->second.first += item.duration;
        iter->second.second += 1;
      } else {
        category_duration_stats_.insert(std::make_pair(item.category,
                                                           std::make_pair(item.duration, 1)));
      }
    }

    items.push_back(item);
  }
  // 保存每个 itemid 详细 iteminfo 的位置
  // 缓存每个 item 初始的统计数据
  std::unordered_map<uint64, size_t> item_pos_map;
  std::vector<std::pair<int, int> > cached_stats_vec(items.size());
  for (size_t idx = 0; idx < items.size(); ++idx) {
    const ItemInfo& item = items[idx];
    item_pos_map.insert(std::make_pair(item.item_id, idx));
    cached_stats_vec[idx].first = item.show_num;
    cached_stats_vec[idx].second = item.click_num;
  }

  DefaultCtrCalculator default_ctr_cal(news_index_);
  default_ctr_cal.Train(items);

  // 每个 item:
  // 1. 如果后验数据充足，使用后验数据计算 ctr；
  // 2. 否则，综合考虑对应 类别/源 的平均 ctr
  // TODO(jianhuang) 更好的预估 item 的 ctr
  // item 最终的 show 和 ctr 缓存
  std::string source_media;
  std::string source;
  WemediaBooster wemedia_booster(news_index_);
  for (size_t idx = 0; idx < items.size(); ++idx) {
    ItemInfo& item_info = items[idx];
    // 自媒体的优质源和原创给予基础展现条数
    int incr_show = 0;
    int incr_click = 0;
    if (wemedia_booster.WemediaBoost(item_info, &incr_show, &incr_click)) {
      // nothing else todo
    } else if (FLAGS_manual_oper_item_incr_show > 0
               && news_index_->IsManualByDocId(item_info.doc_id)) {
      incr_show = FLAGS_manual_oper_item_incr_show;
      incr_click = incr_show * FLAGS_manual_oper_default_ctr;
    } else if (item_info.site_level >= reco::kTopQualitySite
               && FLAGS_coper_media_item_incr_show > 0) {
      bool coper_media = false;
      if (news_index_->GetSourceMediaByDocId(item_info.doc_id, &source_media)
          && source_media == "南方都市") {
        coper_media = true;
      } else if (news_index_->GetSourceByDocId(item_info.doc_id, &source)
                 && source.find("南方都市") != std::string::npos) {
        coper_media = true;
      }
      if (coper_media) {
        incr_show = FLAGS_coper_media_item_incr_show;
        incr_click = incr_show * FLAGS_coper_media_item_default_ctr;
      }
    }
    // 特别老的 item 直接计算并返回
    // item 单独的展现量足够，则直接使用 item 自身的统计数据，并返回
    float show = item_info.show_num + incr_show;
    float click = item_info.click_num + incr_click;
    static const float kConfidenceShowNum = 1000;
    if (item_info.create_timestamp < expire_timestamp
        || show >= kConfidenceShowNum) {
      if (show >= 100) {
        item_info.ctr = std::min(click / show, 1.0f);
      }
      wemedia_booster.QuantityControl(&item_info);
      continue;
    }

    // 使用 sim item 的统计数据
    const std::set<uint64>* sim_items = NULL;
    const float kSimItemStatBoost = 0.5;
    if (sim_item_) {
      sim_items = sim_item_->GetSimItemIds(item_info.item_id);
    }
    if (item_info.item_type != kPureVideo && sim_items != NULL) {
      for (auto it = sim_items->begin(); it != sim_items->end(); ++it) {
        auto pos_iter = item_pos_map.find(*it);
        if (pos_iter == item_pos_map.end()) continue;
        size_t pos = pos_iter->second;
        const std::pair<int, int>& stat_data = cached_stats_vec[pos];
        if (stat_data.first < 5) continue;
        // sim 的数据做适当的降权
        show += stat_data.first * kSimItemStatBoost;
        click += stat_data.second * kSimItemStatBoost;
      }
    }

    /////// 更新 item info 中的 show_num
    item_info.show_num = (int)show;
    item_info.click_num = (int)click;

    /////// 更新 ctr
    // 数据足够直接返回
    float item_ctr = 0;
    if (show >= kConfidenceShowNum) {
      item_ctr = std::min(click / show, 1.0f);
      item_info.ctr = item_ctr;
      continue;
    }

    auto it = item_meta_info_->find(item_info.item_id);
    MetaInfo meta;
    if (it != item_meta_info_->end()) {
      meta = it->second;
    }
    static const int kPctrShowLimit = 1000;
    if (meta.p_ctr > 1e-4 && item_info.show_num < kPctrShowLimit) {
      float real_ctr = 0;
      float real_ctr_ratio = 0;
      if (item_info.show_num > 10) {
        real_ctr = item_info.click_num * 1.0 / item_info.show_num;
        real_ctr_ratio = std::pow(item_info.show_num * 1.0 / kPctrShowLimit, 0.5);
      }
      item_info.ctr = real_ctr * real_ctr_ratio + meta.p_ctr * (1 - real_ctr_ratio);
      VLOG(2) << "meta_ctr: " << item_info.item_id << ", " << item_info.ctr << ", " << meta.p_ctr;
    } else {
      item_info.ctr = default_ctr_cal.Predict(item_info);
    }
  }
  LOG(INFO) << "fill ctr attr, item num: " << items.size() << ", time: " << timer.Stop() << " us";

  // 离散化到 500 区间
  auto item_ctr_dict = item_ctr_dict_.GetInactiveDict();
  item_ctr_dict->clear();
  auto item_duration_dict = item_duration_dict_.GetInactiveDict();
  item_duration_dict->clear();
  for (size_t idx = 0; idx < items.size(); ++idx) {
    ItemInfo& item_info = items[idx];
    if (item_info.show_num > 1000) {
      // duration tuning score
      int category_avg_duration = 70;
      auto category_iter = category_duration_stats_.find(item_info.category);
      if (category_iter != category_duration_stats_.end()) {
        category_avg_duration = category_iter->second.first / category_iter->second.second;
      }
      item_info.duration_score = std::pow(item_info.duration * 1.0f / category_avg_duration,
                                          FLAGS_duration_tuning_rate);
      item_duration_dict->insert(std::make_pair(item_info.item_id, item_info.duration_score));
    }

    item_info.ctr = (static_cast<int>(item_info.ctr * 500)) / 500.0;
    // NOTE(Jianhuang) 暂时注释掉，上全量看是否对点击率有影响
    if (item_info.item_type != reco::kPureVideo) {
      item_ctr_dict->insert(std::make_pair(item_info.item_id, item_info.ctr));
    }
  }
  item_ctr_dict_.SwitchDict();
  item_duration_dict_.SwitchDict();
}

void MetaInfoUpdator::CtrBooster(ItemInfo* item_info) {
  if (!item_info) return;
  if (FLAGS_tudou_producer_boost > 0.0) {
    std::string producer;
    if (news_index_->GetProducerByDocId(item_info->doc_id, &producer)
        && (base::LowerCaseEquals(producer, reco::common::kTuDouProducer)
            || base::LowerCaseEquals(producer, "cp_wemedia_youtu"))
        && news_index_->HasVideoStorageInfoByDocId(item_info->doc_id)) {
      reco::ItemQualityAttr item_quality_attr;
      if (news_index_->GetItemQualityAttrByItemId(item_info->item_id, &item_quality_attr)
          && item_quality_attr.manual_jingpin_level() == 3) {
        item_info->ctr *= FLAGS_tudou_producer_boost;
        VLOG(2) << "ctr boost for tudou producer: " << item_info->item_id;
      }
    }
  }

  std::string source;
  if (!news_index_->GetSourceByItemId(item_info->item_id, &source)) {
    return;
  }

  if (FLAGS_quantity_assurance_general_boost > 0.0
      && FLAGS_quantity_assurance_show_thr > item_info->show_num
      && VideoQuantityAssuranceIns::instance().IsGeneralSource(source)) {
    double ctr_before = item_info->ctr;
    if (ctr_before < 0.02) {
      item_info->ctr = static_cast<float>(FLAGS_basic_ctr_score);
    }
    item_info->ctr *= FLAGS_quantity_assurance_general_boost;
    VLOG(2) << "general source quantity boost: " << item_info->item_id
            << " ctr before: " << ctr_before << " after: " << item_info->ctr;
  }

  if (FLAGS_quantity_assurance_oversea_boost > 0.0
      && FLAGS_quantity_assurance_show_thr > (item_info->show_num * 2)
      && VideoQuantityAssuranceIns::instance().IsOverseaSource(source)) {
    if (item_info->ctr < 0.02) {
      item_info->ctr = static_cast<float>(FLAGS_basic_ctr_score);
    }
    item_info->ctr *= FLAGS_quantity_assurance_oversea_boost;
    VLOG(2) << "oversea source quantity boost: " << item_info->item_id;
  }
}

void MetaInfoUpdator::FillVideoCtrAttr() {
  const int64 now_timestamp = base::GetTimestamp();
  std::vector<ItemInfo> items;
  for (int docid = news_index_->MinDocLocalId(); docid < news_index_->MaxDocLocalId(); ++docid) {
    if (!news_index_->IsValidByDocId(docid)) {
      continue;
    }
    if (news_index_->IsExpiredByDocId(docid, now_timestamp)) {
      continue;
    }
    ItemInfo item;
    if (!news_index_->GetItemInfoByDocId(docid, &item, false)) {
      continue;
    }
    if (item.item_type != reco::kPureVideo) {
      continue;
    }
    items.push_back(item);
  }

  serving_base::Timer timer;
  timer.Start();

  std::vector<std::pair<double, int> > itemq_ctr_count;
  itemq_ctr_count.resize(101, std::make_pair(0.0, 0));
  std::vector<std::pair<int, int> > insuf_items;

  uint64 confidence_item_num = 0;
  uint64 ctr_predict_num = 0;
  uint64 ctr_predict_miss = 0;

  for (size_t idx = 0; idx < items.size(); ++idx) {
    ItemInfo& item_info = items[idx];
    double show_num = static_cast<double>(item_info.show_num);
    double click_num = static_cast<double>(item_info.click_num);

    auto it = item_meta_info_->find(item_info.item_id);
    int new_itemq = -1;
    if (it != item_meta_info_->end()) {
      new_itemq = it->second.new_itemq;
      ++ctr_predict_num;
    } else {
      ++ctr_predict_miss;
      VLOG(2) << "miss ctr predict item: " << item_info.item_id;
    }

    if (show_num >= FLAGS_video_confidence_show_num) {
      item_info.ctr = show_num > 0 ? std::min(click_num / show_num, 1.0) : 0;
      ++confidence_item_num;

      if (new_itemq >= 0 && new_itemq <= 100) {
        itemq_ctr_count[new_itemq].first += item_info.ctr;
        itemq_ctr_count[new_itemq].second += 1;
      }
    } else {
      if (new_itemq >= 0 && new_itemq <= 100) {
        insuf_items.push_back(std::make_pair(idx, new_itemq));
      } else {
        // 对展现不充分且无预估值的 item 进行强降权
        if (show_num > 0) {
          double real_ctr = click_num / show_num;
          real_ctr = std::min(std::max(real_ctr, 0.0), 1.0);
          double real_ctr_discount = std::pow(show_num / FLAGS_video_confidence_show_num, 0.5);
          item_info.ctr = real_ctr * real_ctr_discount;
        } else {
          item_info.ctr = 0;
        }
      }
    }
  }

  std::vector<double> itemq_ctr;
  itemq_ctr.resize(itemq_ctr_count.size(), -1);
  for (size_t i = 0; i < itemq_ctr_count.size(); ++i) {
    double ctr_count = itemq_ctr_count[i].first;
    int item_count = itemq_ctr_count[i].second;
    int idx = i;
    while (item_count < 50) {
      if (--idx < 0) break;
      ctr_count += itemq_ctr_count[idx].first;
      item_count += itemq_ctr_count[idx].second;
    }

    if (item_count > 0) {
      itemq_ctr[i] = ctr_count / item_count;
      itemq_ctr[i] = std::min(std::max(itemq_ctr[i], 0.0), 1.0);
    }

    // LOG(INFO) << "itemq to ctr mapping: " << i << "->" << itemq_ctr[i];
  }

  for (size_t i = 0; i < insuf_items.size(); ++i) {
    int idx = insuf_items[i].first;
    int new_itemq = insuf_items[i].second;
    double predict_ctr = itemq_ctr[new_itemq];
    if (predict_ctr < 0) continue;

    ItemInfo& item_info = items[idx];
    double real_ctr = 0;
    double real_ctr_ratio = 0;
    if (item_info.show_num > 0) {
      real_ctr = item_info.click_num * 1.0 / item_info.show_num;
      real_ctr = std::min(std::max(real_ctr, 0.0), 1.0);
      real_ctr_ratio = std::pow(item_info.show_num * 1.0 / FLAGS_video_confidence_show_num, 0.5);
    }
    item_info.ctr = real_ctr * real_ctr_ratio + predict_ctr * (1 - real_ctr_ratio);

    VLOG(2) << base::StringPrintf("ctr predict item(%lu, ctr: %f)(show: %d, click: %d, ctr: %f)"
                                  "(itemq: %d, pctr: %f, ratio: %f)",
                                  item_info.item_id, item_info.ctr,
                                  item_info.show_num, item_info.click_num, real_ctr,
                                  new_itemq, predict_ctr, real_ctr_ratio);
  }

  COUNTERS_reco_index__itemq_lack_ratio.Reset(static_cast<double>(ctr_predict_miss) /
                                              static_cast<double>(ctr_predict_miss + ctr_predict_num + 1));
  LOG(INFO) << base::StringPrintf("fill ctr attr, item num: %lu, confidence item num: %lu, "
                                  "ctr predict item num: %lu, ctr predict miss num: %lu, cost time: %lu",
                                  items.size() , confidence_item_num,
                                  ctr_predict_num, ctr_predict_miss,
                                  timer.Stop());

  // 离散化到 500 区间
  auto item_ctr_dict = item_ctr_dict_.GetInactiveDict();
  item_ctr_dict->clear();
  for (size_t idx = 0; idx < items.size(); ++idx) {
    ItemInfo& item_info = items[idx];
    item_info.ctr = (static_cast<int>(item_info.ctr * 500)) / 500.0;
    item_ctr_dict->insert(std::make_pair(item_info.item_id, item_info.ctr));
  }
  item_ctr_dict_.SwitchDict();
}

void MetaInfoUpdator::Start(const base::FilePath& dir) {
  if (FLAGS_use_meta_data) {
    LOG(INFO) << "begin to update meta.";
    // CHECK(redis_->GetPool()->IsRun());

    // 先主动调用一次更新
    // UpdateMeta();
    LoadMetaData();

    if (FLAGS_target_server == "video_server") {
      FillVideoCtrAttr();
    } else if (FLAGS_target_server == "search_server") {
      // search server 不需要 ctr 信息
    } else {
      FillCtrAttr();
    }

    // first_run_ = false;
    update_meta_thread_.Start(NewCallback(this, &MetaInfoUpdator::UpdateMetaThread));
    LOG(INFO) << "update meta thread started.";
  } else {
    LOG(INFO) << "just a dummy meta info updator.";
  }

  LOG(INFO) << "end to update meta.";
}

bool MetaInfoUpdator::LoadMetaData() {
  const base::FilePath base_dir(FLAGS_index_dir);
  const base::FilePath meta_file_path = base_dir.Append(FLAGS_meta_dump_file);
  if (base::file_util::PathExists(meta_file_path)) {
    LOG(INFO) << "begin to load meta file:" << meta_file_path.value();
    std::vector<std::string> lines;
    base::file_util::ReadFileToLines(meta_file_path, &lines);
    if (lines.size() < 1e4) {
      LOG(FATAL) << "meta data too small:" << lines.size();
      return false;
    } else if (lines.size() < 1e5) {
      LOG(ERROR) << "meta data too small:" << lines.size();
    }

    const std::string start_time = lines[0];
    uint64 timestamp = 0;
    if (serving_base::TimeHelper::StringToTimestamp(lines[0], "%Y-%m-%d %H:%M:%S", &timestamp)) {
      meta_msg_start_sec_ = timestamp / 1e6;
    }

    std::unordered_map<std::string, std::string> field_values;
    std::vector<std::string> item_data;
    std::vector<std::string> meta_data;
    std::vector<std::string> key_val;
    MetaInfo meta;
    uint64 item_id = 0;
    for (auto i = 2u; i < lines.size(); ++i) {
      field_values.clear();
      item_data.clear();
      meta_data.clear();

      // item_id:k|v,k|v...
      base::SplitString(lines[i], ":", &item_data);
      if (item_data.size() < 2 || !base::StringToUint64(item_data[0], &item_id)) {
        LOG(ERROR) << "item id error:" << lines[i];
        continue;
      }

      meta_data_dump_[item_data[0]] = item_data[1];

      base::SplitString(item_data[1], ",", &meta_data);
      for (auto j = 0u; j < meta_data.size(); ++j) {
        key_val.clear();
        base::SplitString(meta_data[j], "|", &key_val);
        if (key_val.size() == 2) {
          field_values[key_val[0]] = key_val[1];
        }
      }

      meta.Clear();
      ParseMeta(item_id, field_values, &meta);
      (*item_meta_info_)[item_id] = meta;
    }
    LOG(INFO) << "end to load meta file:" << item_meta_info_->size();
  } else {
    LOG(FATAL) << "meta file not fount:" << meta_file_path.value();
    return false;
  }

  return true;
}

void MetaInfoUpdator::UpdateMetaThread() {
  LOG(INFO) << "meta update thread begins to run";

  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_meta_kafka_topic;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = FLAGS_meta_kafka_group_id;
  options.partition_num = FLAGS_meta_kafka_partition;
  options.start_timestamp = meta_msg_start_sec_ - 30*60;  // -60 min
  meta_consumer_ = new reco::kafka::Consumer(FLAGS_log_kafka_brokers, options);
  CHECK_NOTNULL(meta_consumer_);

  LOG(INFO) << "msg begin stamp is:" << options.start_timestamp;

  reco::kafka::Message msg;
  reco::MetaUpdateInfo meta_msg;
  std::unordered_map<std::string, std::string> field_values;
  MetaInfo meta;
  uint64 update_cnt = 0;
  uint64 item_id = 0;
  int64 last_fill_stamp = 0;
  int64 backup_stamp = base::GetTimestamp();

  while (!update_meta_thread_stop_) {
    const int64 cur_stamp = base::GetTimestamp();
    if (cur_stamp - last_fill_stamp > 2 * 60 * 1e6) {  // 2 min update
      LOG(INFO) << "update ctr attr begin";
      if (FLAGS_target_server == "video_server") {
        FillVideoCtrAttr();
      } else {
        FillCtrAttr();
        // 启动时候不做替换, 下次更新 meta 信息的时候才做替换
        // UpdateMetaByoriginInfo();
        // UpdateMetaByYc();
      }
      last_fill_stamp = base::GetTimestamp();
      LOG(INFO) << "update ctr attr end";
    }

    msg.Clear();
    if (!meta_consumer_->Consume(&msg)) {
      base::SleepForSeconds(1);
      continue;
    }

    VLOG(2) << "meta, prt:" << msg.partition << ", off:" << msg.offset
            << ", key:" << msg.key << ", time:" << msg.timestamp_ms;

    meta_msg.Clear();
    if (!meta_msg.ParseFromString(msg.content)) {
      LOG(ERROR) << "parse msg error, key:" << msg.key;
      continue;
    }

    if (meta_msg.has_media_info()) {
      MediaQuantityInfoIns::instance().UpdateQuantityMetaInfo(meta_msg.media_info());

      uint64 source_sign = base::CalcTermSign(meta_msg.media_info().source().c_str(),
                                              meta_msg.media_info().source().size());
      thread::AutoLock lock(&media_mutex_);
      media_source_info_[source_sign] = meta_msg.media_info();
      continue;
    }

    if (meta_msg.version() != FLAGS_meta_kafka_data_version) {
      LOG_EVERY_N(INFO, 10000) << "meta message version error:" << meta_msg.version();
      continue;
    }

    COUNTERS_reco_index__meta_update_cnt.Increase(1);
    item_id = 0;
    if (!base::StringToUint64(meta_msg.item_id(), &item_id)) {
      LOG(ERROR) << "item id error:" << meta_msg.item_id();
      continue;
    }

    field_values.clear();
    BackupMsg(meta_msg);

    if (meta_msg.fields_size() > 0) {
      for (auto i = 0; i < meta_msg.fields_size(); ++i) {
        field_values[meta_msg.fields(i).key()] = meta_msg.fields(i).val();
        /*
        if (meta_msg.fields(i).key() == reco::item_level::kShowField) {
          VLOG(2) << "item update:" << item_id << "," << meta_msg.fields(i).val();
        }
        */
      }

      if (!field_values.empty()) {
        meta.Clear();
        ParseMeta(item_id, field_values, &meta);
        (*item_meta_info_)[item_id] = meta;
      }
    }

    if (++update_cnt % 2000 == 0) {
      COUNTERS_reco_index__meta_lack_ratio.Reset(meta_missing_cnt_ * 1.0 / meta_req_cnt_);
    }

    if (cur_stamp - backup_stamp > 20 * 60 * 1e6) {
      backup_stamp = cur_stamp;
      DumpBackupMeta();
    }
  }

  LOG(INFO) << "meta update thread end running";
}

void MetaInfoUpdator::BackupMsg(const reco::MetaUpdateInfo &meta_msg) {
  if (meta_msg.fields_size() <= 0) {
    return;
  }

  std::string value;
  for (auto i = 0; i < meta_msg.fields_size(); ++i) {
    value += meta_msg.fields(i).key() + "|" + meta_msg.fields(i).val() + ",";
  }

  meta_data_dump_[meta_msg.item_id()] = value;

  return;
}

void MetaInfoUpdator::DumpBackupMeta() {
  LOG(INFO) << "begin to backup meta data";

  const base::FilePath base_dir(FLAGS_index_dir);
  const base::FilePath meta_file_path = base_dir.Append(FLAGS_meta_dump_file);
  const base::FilePath meta_file_path_new = base_dir.Append(FLAGS_meta_dump_file + ".new");

  base::FileStream fs;
  if (fs.Open(meta_file_path_new, base::PLATFORM_FILE_OPEN_ALWAYS | base::PLATFORM_FILE_WRITE) != base::OK) {
    LOG(ERROR) << "open file err:" << meta_file_path_new.value();
    return;
  }

  // date time
  std::string date;
  if (!serving_base::TimeHelper::TimestampToString(
          base::GetTimestamp(), serving_base::TimeHelper::kSecond, &date)) {
    LOG(ERROR) << "time to string err.";
    fs.Close();
    return;
  };

  int64 len = 0;
  date += "\n";
  len = fs.WriteUntilComplete(const_cast<char*>(date.data()), static_cast<int64>(date.size()));

  std::string line;
  for (auto it = meta_data_dump_.begin(); it != meta_data_dump_.end(); ++it) {
    line = it->first + ":" + it->second + "\n";
    len = fs.WriteUntilComplete(const_cast<char*>(line.data()), static_cast<int64>(line.size()));
  }

  fs.Close();

  if (base::file_util::Move(meta_file_path_new, meta_file_path)) {
    LOG(INFO) << "backup meta data succ:" << meta_data_dump_.size();
  } else {
    LOG(ERROR) << "backup meta data fail:" << meta_file_path_new.value();
  }

  return;
}

/*
void MetaInfoUpdator::UpdateMetaByYc() {
  if (orig_item_ == NULL) return;

  uint64 yc_meta_replaced_num = 0;

  auto item_ctr_info = const_cast<std::unordered_map<uint64, float>*>(item_ctr_dict_.GetDict());
  for (auto meta_it = item_meta_info_->begin(); meta_it != item_meta_info_->end(); ++meta_it) {
    uint64 item_id = meta_it->first;
    uint64 replace_item_id;
    if (orig_item_->GetYCInfo(item_id, &replace_item_id)) {
    } else if (orig_item_->GetOriginInfo(item_id, &replace_item_id)) {
    } else {
      continue;
    }

    if (item_id == replace_item_id) continue;

    // 决定是否替换 meta 数据
    auto const replace_meta_it = item_meta_info_->find(replace_item_id);
    if (replace_meta_it == item_meta_info_->end()
        || replace_meta_it->second.show_count < meta_it->second.show_count
        || replace_meta_it->second.show_count < 1000) continue;
    auto ctr_it = item_ctr_info->find(item_id);
    auto replace_ctr_it = item_ctr_info->find(replace_item_id);
    if (ctr_it == item_ctr_info->end()
        || replace_ctr_it == item_ctr_info->end()) continue;

    // 同时替换 ctr 和 meta
    meta_it->second = replace_meta_it->second;
    ctr_it->second = replace_ctr_it->second;
    ++yc_meta_replaced_num;
  }

  LOG(INFO) << "Meta update by Yc: " << yc_meta_replaced_num << " items ";
}

void MetaInfoUpdator::UpdateMetaByoriginInfo() {
  int yc_meta_replaced_num = 0;
  int orig_meta_replaced_num = 0;
  int yc_ctr_replaced_num = 0;
  int orig_ctr_replaced_num = 0;
  for (auto it = item_meta_info_->begin();it != item_meta_info_->end(); ++it) {
    uint64 yc_item_id;
    bool findyc = false;
    if (orig_item_ && orig_item_->GetYCInfo(it->first, &yc_item_id)) {
      auto iter = item_meta_info_->find(yc_item_id);
      if (iter != item_meta_info_->end()) {
        it->second = iter->second;
        VLOG(1) << "YC meta info replaced, item_id:" << it->first << ", yc_item_id:" << yc_item_id;
        findyc = true;
        ++yc_meta_replaced_num;
      }
    }
    if (!findyc) {
      uint64 orig_item_id;
      if (orig_item_ && orig_item_->GetOriginInfo(it->first, &orig_item_id)) {
        auto iter = item_meta_info_->find(orig_item_id);
        if (iter != item_meta_info_->end()) {
          it->second = iter->second;
          VLOG(1) << "orig meta info replaced, item_id:" << it->first << ", orig_item_id:" << orig_item_id;
          ++orig_meta_replaced_num;
        }
      }
    }
  }
  auto item_ctr_info = const_cast<std::unordered_map<uint64, float>*>(item_ctr_dict_.GetDict());
  for (auto it = item_ctr_info->begin();it != item_ctr_info->end(); ++it) {
    uint64 yc_item_id;
    bool findyc = false;
    if (orig_item_ && orig_item_->GetYCInfo(it->first, &yc_item_id)) {
      auto iter = item_ctr_info->find(yc_item_id);
      if (iter != item_ctr_info->end()) {
        it->second = iter->second;
        VLOG(1) << "YC ctr info replaced, item_id : " << it->first
            << " yc_item_id : " << yc_item_id;
        findyc = true;
        ++yc_ctr_replaced_num;
      }
    }
    if (!findyc) {
      uint64 orig_item_id;
      if (orig_item_ && orig_item_->GetOriginInfo(it->first, &orig_item_id)) {
        auto iter = item_ctr_info->find(orig_item_id);
        if (iter != item_ctr_info->end()) {
          it->second = iter->second;
          VLOG(1) << "orig ctr info replaced, item_id : " << it->first
              << " orig_item_id : " << orig_item_id;
          ++orig_ctr_replaced_num;
        }
      }
    }
  }
  LOG(INFO) << "YC meta replaced : " << yc_meta_replaced_num << " items "
            << "orig meta replaced : " << orig_meta_replaced_num << " items "
            << "YC ctr replaced : " << yc_ctr_replaced_num << " items "
            << "orig ctr replaced : " << orig_ctr_replaced_num << " items ";
}
*/

bool MetaInfoUpdator::GetItemInfoByDocId(int32 doc_id, ItemInfo* item_info) {
  if (!news_index_->GetItemIdByDocId(doc_id, &(item_info->item_id))) {
    return false;
  }
  if (!news_index_->GetItemTypeByDocId(doc_id, &(item_info->item_type))) {
    return false;
  }
  item_info->doc_id = doc_id;

  if (!GetMetaInfo(item_info->item_id, item_info)) {
    return false;
  }

  std::vector<std::string> categories;
  if (!news_index_->GetCategoriesByDocId(doc_id, &categories) || categories.empty()) {
    return false;
  }
  item_info->category = categories[0];
  if (categories.size() > 1u) {
    item_info->sub_category = categories[1];
  }
  item_info->create_timestamp = news_index_->GetCreateTimestampByDocId(doc_id);

  std::string source_media;
  if (!news_index_->GetSourceMediaByDocId(doc_id, &source_media)) {
  }
  item_info->source_media_sign = base::CalcTermSign(source_media.c_str(), source_media.size());
  std::string orig_source_media;
  if (!news_index_->GetOrigSourceMediaByDocId(doc_id, &orig_source_media)) {
  }
  item_info->orig_source_media_sign = base::CalcTermSign(orig_source_media.c_str(), orig_source_media.size());

  return true;
}
int32 MetaInfoUpdator::GetNewPr(uint64 item_id, const MetaInfo& meta) const {
  if (meta.new_pr == 0) {
    return 0;
  } else {
    // 过滤 24 小时外的内容
    int64 tm = base::GetTimestamp();
    int64 create_timestamp = news_index_->GetCreateTimestampByItemId(item_id);
    if (tm - create_timestamp > base::Time::kMicrosecondsPerDay) {
      return 0;
    } else {
      std::vector<std::string> categories;
      if (news_index_->GetCategoriesByItemId(item_id, &categories)
          && categories.size() > 0) {
        const std::string super_level_key = categories[0] + "-3";
        const std::string good_level_key = categories[0] + "-2";
        int32 super_level_num = news_index_->GetCateMediaLevelNum(super_level_key);
        int32 good_level_num = news_index_->GetCateMediaLevelNum(good_level_key);
        int32 base_score = super_level_num * 3 + good_level_num * 1;
        if (base_score <= 20) {
          return 0;
        } else {
          float new_pr_score = static_cast<float>(meta.new_pr) / static_cast<float>(base_score);
          return std::min(100, static_cast<int>(new_pr_score * 100));
        }
      } else {
        return 0;
      }
    }
  }
}

}  // namespace reco
