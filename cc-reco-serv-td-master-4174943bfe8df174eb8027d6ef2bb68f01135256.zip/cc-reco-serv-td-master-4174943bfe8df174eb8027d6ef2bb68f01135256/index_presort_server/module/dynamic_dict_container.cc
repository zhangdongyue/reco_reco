#include <algorithm>
#include <fstream>
#include "reco/serv/index_presort_server/module/dynamic_dict_container.h"
#include "reco/serv/index_presort_server/module/channel_itemtype_dict.h"
#include "reco/serv/index_presort_server/module/media_quantity_assurance.h"
#include "third_party/yaml-cpp/include/yaml-cpp/yaml.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/encoding/line_escape.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/memory_mapped_file.h"
#include "nlp/common/nlp_util.h"

namespace reco {

DEFINE_int64(server_request_num_per_day, 600000000L, "服务器每天的刷新量");
DEFINE_double(text_guarantee_deliver_ratio_max, 0.35, "保量最大比例");
DEFINE_double(text_guarantee_deliver_ratio, 0.1, "文本保量下发比例");
DECLARE_string(target_server);

namespace dm {

#define DM_LOAD_DICT(var) reco::dm::DictManagerSingleton::instance().ReloadByDictName(#var)
const char* kDeletedSuffix = "_DELETE";

void LoadChannelItemtypeDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }
  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<ChannelItemtypeDict>* dynamic_dict =
      reinterpret_cast<DynamicDict<ChannelItemtypeDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<ChannelItemtypeDict> new_dict(new ChannelItemtypeDict());

  // 处理逻辑
  auto& white_itemtype_channel = new_dict->white_itemtype_channel_map_;
  auto& black_itemtype_channel = new_dict->black_itemtype_channel_map_;

  int64 count = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }

    std::vector<std::string> tokens;
    base::SplitString(lines[i], ":", &tokens);
    if (tokens.size() != 3) {
      continue;
    }

    std::vector<std::string> sub_tokens;
    base::SplitString(tokens[2], ",", &sub_tokens);

    int64 channelid = 0;
    if (!base::StringToInt64(tokens[0], &channelid)) {
      LOG(ERROR) << path.value() << " channelid field error: " << lines[i];
      continue;
    }
    ++count;

    bool is_white = tokens[1] == "white";
    for (size_t j = 0; j < sub_tokens.size(); ++j) {
      unsigned itemtype = 0;
      if (!base::StringToUint(sub_tokens[j], &itemtype)) {
        LOG(ERROR) << path.value() << " itemtype field error: " << lines[i];
        continue;
      }
      is_white ? white_itemtype_channel[channelid].push_back(itemtype) :
         black_itemtype_channel[channelid].push_back(itemtype);
    }
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
  *cnt = count;
}

void LoadChannelItemRuleGalleryDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  std::ifstream fin(path.value().c_str());
  YAML::Parser parser(fin);
  YAML::Node doc;
  try {
    parser.GetNextDocument(doc);
  } catch(YAML::ParserException & e) {
    LOG(WARNING) << "Yaml file " << path.value() << " load failed: " << e.what();
    *suc = false;
    return;
  }

  if (doc.Type() != YAML::NodeType::Sequence) {
    LOG(WARNING) << "Yaml node format error: not Sequence";
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<ChannelItemRuleGalleryDict>* dynamic_dict =
      reinterpret_cast<DynamicDict<ChannelItemRuleGalleryDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<ChannelItemRuleGalleryDict> new_dict(new ChannelItemRuleGalleryDict());

  // 处理逻辑
  for (auto i = 0u; i < doc.size(); i++) {
    try {
      RuleType rule_type;
      int64 rule_id;
      if (!reco::ChannelItemtypeDict::ParseRuleTypeFromYAML(doc[i], &rule_type, &rule_id)) {
        continue;
      }
      ChannelRule channel_rule;
      FilterRule filter_rule;
      switch (rule_type) {
        case reco::kLeafChannelRule:
          channel_rule.channel_id = rule_id;
          if (reco::ChannelItemtypeDict::ParseRuleFromYAML(doc[i], &channel_rule,
              &new_dict->leaf_channel_engine.channel_rule_index_permit,
              &new_dict->leaf_channel_engine.channel_rule_index_forbid,
              &new_dict->leaf_channel_engine.manual_channels,
              &new_dict->leaf_channel_engine.channel_subordinates_map)) {
            if (new_dict->leaf_channel_engine.channel_rule_map.find(rule_id)
                != new_dict->leaf_channel_engine.channel_rule_map.end()) {
              LOG(WARNING) << "leaf channel rule conflict at:" << rule_id;
              continue;
            }
            new_dict->leaf_channel_engine.channel_rule_map[rule_id] = channel_rule;
            LOG(INFO) << "leaf channel loaded success at:" << rule_id;
            ++(*cnt);
          }
          break;
        case reco::kVideoChannelRule:
          channel_rule.channel_id = rule_id;
          if (reco::ChannelItemtypeDict::ParseRuleFromYAML(doc[i], &channel_rule,
              &new_dict->video_channel_engine.channel_rule_index_permit,
              &new_dict->video_channel_engine.channel_rule_index_forbid,
              &new_dict->video_channel_engine.manual_channels,
              &new_dict->video_channel_engine.channel_subordinates_map)) {
            if (new_dict->video_channel_engine.channel_rule_map.find(rule_id)
                != new_dict->video_channel_engine.channel_rule_map.end()) {
              LOG(WARNING) << "video channel rule conflict at:" << rule_id;
              continue;
            }
            new_dict->video_channel_engine.channel_rule_map[rule_id] = channel_rule;
            LOG(INFO) << "video channel loaded success at:" << rule_id;
            ++(*cnt);
          }
          break;
        case reco::kLeafExtendChannelRule:
          channel_rule.channel_id = rule_id;
          if (reco::ChannelItemtypeDict::ParseRuleFromYAML(doc[i], &channel_rule,
              &new_dict->leaf_extend_channel_engine.channel_rule_index_permit,
              &new_dict->leaf_extend_channel_engine.channel_rule_index_forbid,
              &new_dict->leaf_extend_channel_engine.manual_channels,
              &new_dict->leaf_extend_channel_engine.channel_subordinates_map)) {
            if (new_dict->leaf_extend_channel_engine.channel_rule_map.find(rule_id)
                != new_dict->leaf_extend_channel_engine.channel_rule_map.end()) {
              LOG(WARNING) << "leaf extend channel rule conflict at:" << rule_id;
              continue;
            }
            new_dict->leaf_extend_channel_engine.channel_rule_map[rule_id] = channel_rule;
            LOG(INFO) << "leaf extend channel loaded success at:" << rule_id;
            ++(*cnt);
          }
          break;
        case reco::kFilterRule:
          filter_rule.filter_id = rule_id;
          if (reco::ChannelItemtypeDict::ParseFilterFromYAML(doc[i], &filter_rule)) {
            new_dict->filter_rules.push_back(filter_rule);
            LOG(INFO) << "filter loaded success at:" << rule_id;
            ++(*cnt);
          }
          break;
        default:
          break;
      }
    } catch(YAML::ParserException & e) {
      LOG(WARNING) << "Yaml Parsing failed: " << e.what();
    }
  }

  // swap dict
  dynamic_dict->Swap(new_dict);
  *suc = true;
}

void LoadMediaQuantityInfoDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  std::ifstream fin(path.value().c_str());
  YAML::Parser parser(fin);
  YAML::Node doc;
  try {
    parser.GetNextDocument(doc);
  } catch(YAML::ParserException & e) {
    LOG(WARNING) << "Yaml file " << path.value() << " load failed: " << e.what();
    *suc = false;
    return;
  }

  if (doc.Type() != YAML::NodeType::Sequence) {
    LOG(WARNING) << "Yaml node format error: not Sequence";
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<MediaQuantityInfoDict>* dynamic_dict =
    reinterpret_cast<DynamicDict<MediaQuantityInfoDict>* >(dict_address);

  // 新 dict
  boost::shared_ptr<MediaQuantityInfoDict> p_new_dict(new MediaQuantityInfoDict());
  auto & new_dict = *p_new_dict;

  int64 count = 0;
  int64 quantity = 0L;
  // 处理逻辑
  for (auto i = 0u; i < doc.size(); i++) {
    try {
      MediaQuantityInfo media_quantity_info;
      if (reco::MediaQuantityInfoDict::ParseFromYAML(doc[i], &media_quantity_info)) {
        if (new_dict.find(media_quantity_info.source_sign) == new_dict.end()) {
          new_dict.insert(std::make_pair(media_quantity_info.source_sign,
                                         std::unordered_map<int64, MediaQuantityInfo>()));
        }
        new_dict[media_quantity_info.source_sign][media_quantity_info.protect_type] = media_quantity_info;
        if (media_quantity_info.protect_type == reco::dm::kMediaDocManual
            || media_quantity_info.protect_type == reco::dm::kMediaDocBeginner) {
          quantity += media_quantity_info.protect_capacity;
        }
        ++count;
      }
    } catch(YAML::ParserException & e) {
      LOG(WARNING) << "Yaml Parsing failed: " << e.what();
    }
  }

  // swap dict
  dynamic_dict->Swap(p_new_dict);
  *suc = true;
  *cnt = count;
  FLAGS_text_guarantee_deliver_ratio = std::min(FLAGS_text_guarantee_deliver_ratio_max,
                                                quantity * 1.0 / FLAGS_server_request_num_per_day);
  LOG(INFO) << "suc load media_quantity file. media conf num" << count
            << ", text quantity: " << quantity
            << ", text gd percent: " << FLAGS_text_guarantee_deliver_ratio;
}

void LoadUgcSeedInfoDict(base::FilePath path, void* dict_address, bool* suc, int64* cnt) {
  // 读文件
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(path, &lines)) {
    LOG(ERROR) << "read file error:" << path.value();
    *suc = false;
    return;
  }

  // 从 dict 地址拿到 dict 类型指针
  DynamicDict<UgcSeedInfoDict>* dynamic_dict =
    reinterpret_cast<DynamicDict<UgcSeedInfoDict>* >(dict_address);
  // 新 dict
  boost::shared_ptr<UgcSeedInfoDict> p_new_dict(new UgcSeedInfoDict());
  auto & new_dict = *p_new_dict;

  int64 count = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (lines[i].empty()) {
      continue;
    }

    base::TrimWhitespaces(&lines[i]);
    std::vector<std::string> tokens;
    base::SplitString(lines[i], "\t", &tokens);
    if (tokens.size() < 17) continue;
    std::string source = tokens[1];
    std::string seed_name = tokens[2];

    // extract l1_category & l2_category
    std::vector<std::string> categorys;
    const std::string category_prefix("manual:");
    std::size_t pos = tokens[3].find(category_prefix);
    std::string category_str = tokens[3];
    if (pos != std::string::npos) {
      std::string category_str = tokens[3].substr(pos + category_prefix.size());
    }
    base::SplitString(category_str, ",", &categorys);  // 生活服务,知识讲解
    std::string l1_category = "";
    std::string l2_category = "";
    if (categorys.size() > 0) {
      l1_category = categorys[0];
      if (categorys.size() > 1) l2_category = categorys[0] + "_" + categorys[1];
    }

    std::vector<std::string>  tags_tmp;
    std::unordered_set<std::string>  tags;
    base::SplitString(tokens[4], ",", &tags_tmp);
    for (auto it = tags_tmp.begin() ; it != tags_tmp.end(); ++it) {
      tags.insert(*it);
    }
    std::string career = tokens[5];
    int gender = 0;
    if (!tokens[6].empty() &&  tokens[6] != "NULL" && !base::StringToInt(tokens[6], &gender)) {
      LOG(ERROR) << path.value() << " gender " << lines[i];
      continue;
    }

    std::string location = tokens[8];
    int fans = 0;
    if (!base::StringToInt(tokens[9], &fans)) {
      LOG(ERROR) << path.value() << " fans " << lines[i];
      continue;
    }
    int attention = 0;
    if (!base::StringToInt(tokens[10], &attention)) {
      LOG(ERROR) << path.value() << " attention " << lines[i];
      continue;
    }
    int up_cnt = 0;
    if (!base::StringToInt(tokens[11], &up_cnt)) {
      LOG(ERROR) << path.value() << " up_cnt " << lines[i];
      continue;
    }
    int article = 0;
    if (!base::StringToInt(tokens[12], &article)) {
      LOG(ERROR) << path.value() << " article " << lines[i];
      continue;
    }
    int firepower = 0;
    if (!base::StringToInt(tokens[13], &firepower)) {
      LOG(ERROR) << path.value() << " firepower " << lines[i];
      continue;
    }
    int live_cnt = 0;
    if (!base::StringToInt(tokens[14], &live_cnt)) {
      LOG(ERROR) << path.value() << " live_cnt  " << lines[i];
      continue;
    }

    UgcSeedInfo seed_info;
    seed_info.source = source;
    seed_info.seed_name = seed_name;
    seed_info.l1_category = l1_category;
    seed_info.l2_category = l2_category;
    seed_info.tags = tags;
    seed_info.career = career;
    seed_info.gender = gender;
    seed_info.location = location;
    seed_info.fans = fans;
    seed_info.attention = attention;
    seed_info.up_cnt = up_cnt;
    seed_info.article = article;
    seed_info.firepower = firepower;
    seed_info.live_cnt = live_cnt;

    /*
    new_dict[seed_name] = new UgcSeedInfo(source, seed_name,l1_category,
                                            l2_category, tags, career, gender,
                                            location, fans, attention, up_cnt,
                                            article, firepower, live_cnt, 0l, 0l);
    */
    new_dict[seed_name] = seed_info;
    ++count;
  }

  // swap dict
  dynamic_dict->Swap(p_new_dict);
  *suc = true;
  *cnt = count;
}
}  // namespace dm

const char* DynamicDictContainer::kChannelItemRuleFile_   = "channel_itemrule.yml";
const char* DynamicDictContainer::kMediaQuantityInfoFile_ = "media_quantity_rule.yaml";
const char* DynamicDictContainer::kUgcSeedInfoFile_ = "ugc_seed_info.txt";


void DynamicDictContainer::RegisterAndLoadAllDict() {
  DM_REGISTER_CUSTOMER_DICT(reco::dm::ChannelItemRuleGalleryDict,
                            reco::DynamicDictContainer::kChannelItemRuleFile_,
                            reco::dm::LoadChannelItemRuleGalleryDict);
  DM_LOAD_DICT(reco::DynamicDictContainer::kChannelItemRuleFile_);
  DM_REGISTER_CUSTOMER_DICT(reco::dm::MediaQuantityInfoDict,
                            reco::DynamicDictContainer::kMediaQuantityInfoFile_,
                            reco::dm::LoadMediaQuantityInfoDict);
  DM_LOAD_DICT(reco::DynamicDictContainer::kMediaQuantityInfoFile_);
  if (FLAGS_target_server == "video_server") {
    DM_REGISTER_CUSTOMER_DICT(reco::dm::UgcSeedInfoDict,
        reco::DynamicDictContainer::kUgcSeedInfoFile_,
        reco::dm::LoadUgcSeedInfoDict);
    DM_LOAD_DICT(reco::DynamicDictContainer::kUgcSeedInfoFile_);
  }
}
}
