#pragma once
#include <vector>
#include <unordered_map>
#include <string>

#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "base/common/basic_types.h"
#include "base/thread/thread.h"
#include "reco/serv/index_presort_server/frame/index_wrapper.h"

DECLARE_int32(update_video_stat_interval_second);

namespace reco {
class NewsIndex;

struct VideoStatInfo {
  VideoStatInfo() {
    view_count = 0.0;
    view_ratio = 0.0;
    total_view_time = 0.0;
  }
  ~VideoStatInfo() {}

  // 播放次数
  double view_count;

  // 播放比例
  double view_ratio;

  // 总播放时长
  double total_view_time;

  std::string to_string() {
    return base::StringPrintf("view_count : %lf, view_ratio : %lf, total_view_time : %lf",
                              view_count, view_ratio, total_view_time);
  }
};
// 内部独立线程更新新闻的 video_stat_info 信息 （可以关闭此线程）
class VideoStatInfoUpdator {
 public:
  explicit VideoStatInfoUpdator(const NewsIndex* news_index);
  ~VideoStatInfoUpdator();

  void Start();

  bool GetVideoStatInfo(uint64 item_id, VideoStatInfo* info) const;

 private:
  void UpdateVideoStatInfoThread();
  void UpdateVideoStatInfo();

  void GetVideoStat(const uint64 item_id, std::unordered_map<uint64, VideoStatInfo>* infos,
                    int64 *err_num, int64 *succ_num);
  void ParseVideoStat(const std::unordered_map<std::string, std::string>& field_values, VideoStatInfo* info);

  std::string gen_redis_key(const uint64 item_id);

  thread::Mutex update_stat_mutex_;
  thread::Thread update_video_stat_thread_;
  std::atomic_bool update_video_stat_thread_stop_;

  DynamicDict<std::unordered_map<uint64, VideoStatInfo> > item_video_stat_info_;

  const NewsIndex* news_index_;
  reco::redis::RedisCli *redis_;
};

}  // namespace reco
