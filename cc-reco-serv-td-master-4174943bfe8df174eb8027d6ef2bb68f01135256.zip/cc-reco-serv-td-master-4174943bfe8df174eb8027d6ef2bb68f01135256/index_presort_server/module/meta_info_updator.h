#pragma once

#include <atomic>
#include <utility>
#include <vector>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>

#include "base/container/dense_hash_map.h"
#include "base/file/file_path.h"
#include "base/testing/gtest.h"
#include "base/thread/sync.h"
#include "base/thread/thread.h"
#include "base/thread/thread_pool.h"
#include "serving_base/expiry_map/expiry_map.h"

// #include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/serv/index_presort_server/module/video_quantity_assurance.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/proto/meta_update.pb.h"

namespace reco {
namespace kafka {
class Consumer;
}

class NewsIndex;
class SimItem;
// class OriginInfoUpdator;
class IndexDictManager;

// 内部独立线程更新新闻的 meta 信息 （可以关闭此线程）
class MetaInfoUpdator {
 public:
  // sim_item 为 null 则不做相似新闻 ctr 的映射
  MetaInfoUpdator(const NewsIndex* news_index, const reco::SimItem* sim_item);
                  // const reco::OriginInfoUpdator* orig_item);
  ~MetaInfoUpdator();

  // TODO(jianhuang) 后续提供 批量接口, BatchGetMetaInfos
  bool GetMetaInfo(uint64 item_id, ItemInfo *item) const;

  void Start(const base::FilePath& dir);

  std::unordered_map<uint64, MediaSourceInfo> GetMediaMeta() const {
    thread::AutoLock lock(&media_mutex_);
    return media_source_info_;
  }

 private:
  // std::atomic_bool first_run_;
  // static const char* kMetaInfoFile;

  struct MetaInfo {
    MetaInfo() {
      Clear();
    }

    void Clear() {
      hot_level  = 0;
      pr_level   = 0;
      item_quality = reco::kNormalItemq;
      spider_score = 0;
      site_level = reco::kMidQualitySite;
      time_level = reco::kBadTimeliness;
      sensitive_type = reco::kNoSensitive;
      show_count = 0;
      click_count = 0;
      duration = 70;
      new_pr = 0;
      p_ctr = -1;
      new_itemq = -1;
      predict_ctr = -1;
    }

    // 热门得分
    int hot_level;
    // PR 得分
    int pr_level;
    // 质量度
    int item_quality;
    // 爬虫抓取的数据计算的得分, 根据爬虫抓取的外站数据辅助排序
    float spider_score;
    // 站点等级
    reco::SiteLevel site_level;
    // 时效性等级
    reco::TimeLevel time_level;
    // 敏感类型
    reco::SensitiveType sensitive_type;
    // 展现数
    uint64 show_count;
    // 点击数
    uint64 click_count;
    // 平均阅读时长
    int duration;
    // new pr
    int new_pr;
    // 预估的 ctrq
    float p_ctr;
    // 预估的 itemq
    int new_itemq;
    // 预估的 ctr
    int predict_ctr;
  };

  // update item meta from redis
  void UpdateMetaThread();
  // void UpdateMeta();
  void UpdateMetaByoriginInfo();
  void UpdateMetaByYc();
  void FillCtrAttr();
  void CtrBooster(ItemInfo* item_info);
  void FillVideoCtrAttr();
  // 跟 news index 里的类似 但是用了本类内部的 meta 字典
  bool GetItemInfoByDocId(int32 doc_id, ItemInfo* item_info);
  /*
  void GetMeta(const uint64 item_id, base::dense_hash_map<uint64, MetaInfo>* item_metas,
               int64* err_num, int64* not_exist_num);
  */

  void ParseMeta(const uint64 item_id,
                 const std::unordered_map<std::string, std::string>& field_values,
                 MetaInfo* meta);

  bool LoadMetaData();

  void BackupMsg(const reco::MetaUpdateInfo &meta_msg);

  void DumpBackupMeta();

  // new_pr 得分归一化处理
  int32 GetNewPr(uint64 item_id, const MetaInfo& meta) const;
  // update meta item thread
  thread::Thread update_meta_thread_;
  std::atomic_bool update_meta_thread_stop_;
  thread::Mutex update_meta_mutex_;

  // DynamicDict<std::unordered_map<uint64, MetaInfo>>  item_meta_info_;
  base::dense_hash_map<uint64, MetaInfo> *item_meta_info_;
  std::unordered_map<std::string, std::string> meta_data_dump_;

  std::unordered_map<std::string, std::pair<int, int> > category_duration_stats_;
  DynamicDict<std::unordered_map<uint64, float>> item_ctr_dict_;
  DynamicDict<std::unordered_map<uint64, float>> item_duration_dict_;
  const NewsIndex* news_index_;
  const SimItem* sim_item_;
  // const OriginInfoUpdator* orig_item_;
  // reco::redis::RedisCli *redis_;
  reco::kafka::Consumer* meta_consumer_;
  // serving_base::ExpiryMap<uint64, bool> *missing_meta_items_;
  int64 meta_msg_start_sec_;

  mutable thread::Mutex media_mutex_;
  std::unordered_map<uint64, MediaSourceInfo> media_source_info_;

  mutable std::atomic<uint64> meta_req_cnt_;
  mutable std::atomic<uint64> meta_missing_cnt_;

  FRIEND_TEST(MetaInfoUpdatorTest, LoadFromFile);
  friend class MetaInfoUpdatorTest;
};

inline bool MetaInfoUpdator::GetMetaInfo(uint64 item_id, ItemInfo *item) const {
  meta_req_cnt_++;
  MetaInfo meta;

  auto it = item_meta_info_->find(item_id);
  if (it != item_meta_info_->end()) {
    meta = it->second;
    item->meta_valid = true;
  } else {
    meta_missing_cnt_++;
    item->meta_valid = false;
  }

  item->site_level = meta.site_level;
  item->time_level = meta.time_level;
  item->hot_level = meta.hot_level;
  item->sensitive_type = meta.sensitive_type;
  item->itemq = meta.item_quality;
  item->spider_score = meta.spider_score;
  item->show_num = meta.show_count;
  item->click_num = meta.click_count;
  item->duration = meta.duration;
  item->new_pr = GetNewPr(item_id, meta);
  item->new_itemq = meta.new_itemq;
  item->predict_ctr = meta.predict_ctr;
  auto ctr_dict = item_ctr_dict_.GetDict();
  auto jt = ctr_dict->find(item_id);
  if (jt != ctr_dict->end()) {
    item->ctr = jt->second;
  } else {
    item->ctr = (item->show_num == 0) ? 0 : (float)item->click_num / (float)item->show_num;
  }
  item->ctr = std::min(std::max(0.0f, item->ctr), 1.0f);

  auto duration_dict = item_duration_dict_.GetDict();
  auto duration_it = duration_dict->find(item_id);
  if (duration_it != duration_dict->end()) {
    item->duration_score = duration_it->second;
  }
  return true;
}
}  // namespace reco
