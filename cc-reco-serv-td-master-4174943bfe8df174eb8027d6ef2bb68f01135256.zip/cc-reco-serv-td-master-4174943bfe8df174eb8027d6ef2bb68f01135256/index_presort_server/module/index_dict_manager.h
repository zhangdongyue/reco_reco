#pragma once

#include <string>
#include <unordered_set>
#include <unordered_map>
#include <vector>

#include "reco/bizc/proto/common.pb.h"
#include "base/common/base.h"
#include "base/container/dense_hash_map.h"
#include "base/file/file_util.h"

namespace reco {

// 索引词表统一管理类
//
class IndexDictManager {
 public:
  struct WemediaMeta {
    WemediaMeta() {
      low_quality_ratio = 0.0f;
      normal_show_num = 0;
      normal_click_num = 0;
      normal_ctr = 0.0f;
      suspect_show_num = 0;
      suspect_click_num = 0;
      suspect_ctr = 0.0f;
      low_show_num = 0;
      low_click_num = 0;
      low_ctr = 0.0f;
    }

    double low_quality_ratio;
    int32 normal_show_num;
    int32 normal_click_num;
    double normal_ctr;
    int32 suspect_show_num;
    int32 suspect_click_num;
    double suspect_ctr;
    int32 low_show_num;
    int32 low_click_num;
    double low_ctr;
  };
  static const IndexDictManager* GetInstance();

  // 类别 - 频道映射表
  const base::dense_hash_map<std::string, int64>* GetCategoryChannelMap() const {
    return &category_channel_map_;
  }

  const std::unordered_map<std::string, int>* GetDizhiTagMap() const {
    return &dizhi_tag_map_;
  }

  const std::unordered_map<std::string, int>* GetDizhiCategoryMap() const {
    return &dizhi_category_map_;
  }

  // 类别-机构媒体 质量等级
  const base::dense_hash_map<std::string, reco::MediaLevel>* GetCategoryMediaLevelMap() const {
    return &cate_media_level_map_;
  }

  const base::dense_hash_map<std::string, int32>* GetCateMediaLevelNumMap() const {
    return &cate_media_level_num_map_;
  }
  const base::dense_hash_map<std::string, std::unordered_set<std::string> >* GetExtendCategoryMap() const {
    return &extend_category_map_;
  }

  const base::dense_hash_map<uint64, std::vector<std::string> >* GetExtendItemCategoryMap() const {
    return &extend_itemid_category_map_;
  }

  const base::dense_hash_map<std::string, WemediaMeta>* GetWemediaMetaMap() const {
    return &wemedia_meta_map_;
  }

  const base::dense_hash_map<int32, std::vector<uint64> >* GetMiningStrategyItem() const {
    return &mining_strategy_item_;
  }

 private:
  IndexDictManager();
  ~IndexDictManager();

  void LoadCategoryChannelMap(const base::FilePath& base_dir);
  void LoadCategoryMediaLevelMap(const base::FilePath& map_file);
  void LoadOldCategoryMediaLevelMap(const base::FilePath& map_file);
  void LoadWemediaMetaMap(const base::FilePath& map_file);
  void LoadExtendCategoryMap(const base::FilePath& base_dir);
  void LoadExtendItemidCategoryFile(const base::FilePath& base_dir);
  void LoadDizhiTag(const base::FilePath& base_dir);
  void LoadMiningStrategyItem(const base::FilePath& base_dir);

 private:
  static const char* kCategoryChannelMapFile;
  static const char* kCategoryMediaLevelFile;
  static const char* kCategoryMediaQualityFile;
  static const char* kExtendCategoryMapFile;
  static const char* kExtendItemidCategoryFile;
  static const char* kWemediaNewbeeFile;
  static const char* kWemediaMetaFile;
  static const char* kDizhiTagFile;
  static const char* kMiningStrategyItemFile;

  // category to channel 映射表
  base::dense_hash_map<std::string, int64> category_channel_map_;

  // 低质源词表
  std::unordered_map<std::string, int> dizhi_tag_map_;
  std::unordered_map<std::string, int> dizhi_category_map_;

  // category - media 质量等级
  base::dense_hash_map<std::string, reco::MediaLevel> cate_media_level_map_;
  // category 下各个级别的媒体数量 category-reco::item_level::MediaLevel
  base::dense_hash_map<std::string, int32> cate_media_level_num_map_;

  // extend category dict
  base::dense_hash_map<std::string, std::unordered_set<std::string> > extend_category_map_;

  // extend itemid category dict
  base::dense_hash_map<uint64, std::vector<std::string> > extend_itemid_category_map_;

  base::dense_hash_map<std::string, WemediaMeta> wemedia_meta_map_;

  base::dense_hash_map<int32, std::vector<uint64> > mining_strategy_item_;
};
}  // end of namespace reco
