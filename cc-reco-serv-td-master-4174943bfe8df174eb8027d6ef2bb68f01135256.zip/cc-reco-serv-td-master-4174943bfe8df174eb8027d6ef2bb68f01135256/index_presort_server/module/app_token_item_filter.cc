//
// Created by allen.fw on 2017/8/30.
//

#include <math.h>
#include <unordered_map>
#include <vector>
#include "reco/bizc/common/appname_define.h"
#include "reco/serv/index_presort_server/module/app_token_item_filter.h"
#include "base/strings/utf_char_iterator.h"
#include "base/hash_function/term.h"
#include "reco/bizc/filter_rule/common/dynamic_dict_container.h"
#include "extend/json/jansson/jansson.h"
#include "base/strings/string_util.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/index_presort_server/frame/index_wrapper.h"
#include "reco/base/common/uri_process.h"

namespace reco {
namespace filter {

using reco::ItemInfo;

const std::string SOURCE_WEMEDIA_PREFIX = "cp_wemedia_uc_";
const int kAppTokenBit = 2;
bool AppTokenItemFilter::FilterRule(const ItemInfo& item,
                                    std::shared_ptr<boost::dynamic_bitset<uint8>> app_rule_mask) {
  auto app_token_dict = DM_GET_DICT(AppTokenFilterDict,
                                    reco::filter::DynamicDictContainer::kAppTokenFilterFile);
  if (app_token_dict == NULL) {
    LOG(INFO) << "app_token_dict is null, item_id: " << item.item_id;
    return false;
  }
  auto& app_token_index_map = app_token_dict->app_token_index_map;

  auto app_token_bit_index_dict = DM_GET_DICT(AppTokenBitIndex,
                                              reco::filter::DynamicDictContainer::kAppTokenBitIndexFile);
  if (app_token_bit_index_dict == NULL) {
    LOG(INFO) << "app_token_bit_index_dict is null, item_id: " << item.item_id;
    return false;
  }
  auto& app_token_bit_index = app_token_bit_index_dict->app_token_bit_index;

  bool is_has_app_filter = false;
  app_rule_mask->resize(kAppTokenBit * GetMaxAppIndex(app_token_bit_index), false);
  bool is_manual_item = news_index_->IsManualByItemId(item.item_id);

  for (std::unordered_map<std::string, int>::const_iterator it = app_token_index_map.begin();
       it != app_token_index_map.end(); ++it) {
    const std::string& app_name = it->first;
    int app_index = it->second;
    if (app_index < 0 || app_index >= static_cast<int>(app_token_index_map.size())) {
      LOG_EVERY_N(ERROR, 10000) << "app token [" << it->first << "] index [" << app_index << "] is beyond";
      continue;
    }

    std::unordered_map<std::string, int>::const_iterator index_it = app_token_bit_index.find(app_name);
    if (index_it == app_token_bit_index.end()) {
      LOG_EVERY_N(ERROR, 10000) << "app token [" << app_name << "] is not in app_token_bit_index";
      continue;
    }
    int bit_index = index_it->second;
    if (bit_index < 0 || bit_index >= static_cast<int>(app_rule_mask->size())) {
      LOG_EVERY_N(ERROR, 10000) << "app token [" << it->first << "] bit_index ["
                                << bit_index << "] is beyond";
      continue;
    }

    bool is_filtered = false;
    if (is_manual_item) {
      is_filtered = AppTokenRuleFilterUCB(app_index, app_token_dict.get(), item);
    } else {
      is_filtered = AppTokenRuleFilter(app_index, app_token_dict.get(),  item);
    }

    if (is_filtered) {
      app_rule_mask->set(kAppTokenBit * bit_index, 1);
      is_has_app_filter = true;
    } else if (MainCityBadItemFIlter(app_index, app_token_dict.get(), item)) {
      app_rule_mask->set(kAppTokenBit * bit_index + 1, 1);
      is_has_app_filter = true;
    }
  }

  return is_has_app_filter;
}

int AppTokenItemFilter::GetAppTokenBit() {
  return kAppTokenBit;
}

int AppTokenItemFilter::GetMaxAppIndex(const std::unordered_map<std::string, int>& app_token_bit_index) {
  int max_app_idx = 0;
  for (std::unordered_map<std::string, int>::const_iterator it = app_token_bit_index.begin();
       it != app_token_bit_index.end(); ++it) {
    if (it->second > max_app_idx) {
      max_app_idx = it->second;
    }
  }

  return max_app_idx;
}

bool AppTokenItemFilter::AppTokenRuleFilter(const int app_token_idx,
                                             const AppTokenFilterDict* app_token_dict,
                                             const ItemInfo& item) {
  if (app_token_idx < 0) {
    return false;
  }

  if (CategoryFilterByTrie(app_token_idx, app_token_dict, item)) {
    return true;
  }

  if (ItemTypeFilterByWhiteDict(app_token_idx, app_token_dict, item)) {
    return true;
  }

  if (ItemDirtyFilter(app_token_idx, app_token_dict, item)) {
    return true;
  }

  if (ItemBluffingFilter(app_token_idx, app_token_dict, item)) {
    return true;
  }

  if (SourceWemediaFilter(app_token_idx, app_token_dict, item)) {
    return true;
  }

  if (TitleFilterByBlackPattern(app_token_idx, app_token_dict, item)) {
    return true;
  }

  if (SourceFilterByWhiteDict(app_token_idx, app_token_dict, item)) {
    return true;
  }

  // 自媒体 level 过滤，注意这里会跟 "wemedia" 这个规则 (SourceWemediaFilter) 有交集
  // 我们取最严格的：被哪个命中都会被过滤掉
  if (WemediaLevelFilter(app_token_idx, app_token_dict, item)) {
    return true;
  }

  // 自媒体黑名单，注意前面有个白名单(SourceFilterByWhiteDict)，我们挨个规则过滤
  if (SourceFilterByBlackDict(app_token_idx, app_token_dict, item)) {
    return true;
  }

  if (VideoLengthFilter(app_token_idx, app_token_dict, item)) {
    return true;
  }

  if (ProducerWemediaYoutuFilter(app_token_idx, app_token_dict, item)) {
    return true;
  }

  return false;
}

bool AppTokenItemFilter::CategoryFilterByTrie(const int app_token_idx,
                                                 const AppTokenFilterDict* app_token_dict,
                                                 const ItemInfo& item) {
  auto category_dict = app_token_dict->app_token_black_category[app_token_idx];
  if (category_dict == NULL) {
    return false;
  }

  if (category_dict->Find(item.category, item.sub_category)) {
    VLOG(1) << "app [" << app_token_idx << "] filter by category in black category, item_id: "
                            << item.item_id;
    return true;
  }

  return false;
}

bool AppTokenItemFilter::ItemTypeFilterByWhiteDict(const int app_token_idx,
                                                   const AppTokenFilterDict* app_token_dict,
                                                   const ItemInfo& item) {
  if (app_token_dict->app_token_white_item_type[app_token_idx] == NULL) {
    return false;
  }

  auto const& item_type_dict = *(app_token_dict->app_token_white_item_type[app_token_idx]);

  // 对于专题要判断子文
  if (kSpecial == item.item_type) {
    std::unordered_set<uint64> preview_ids;
    if (news_index_->GetPreviewIdsByItemId(item.item_id, &preview_ids)) {
      for (auto preview_iter = preview_ids.begin(); preview_iter != preview_ids.end(); ++preview_iter) {
        ItemType sub_item_type;
        if (news_index_->GetItemTypeByItemId(*preview_iter, &sub_item_type)) {
          if (item_type_dict[sub_item_type]) {
            return false;
          }
        }
      }
    }
  }

  if (app_token_dict->app_token_white_item_type[app_token_idx]->test(item.item_type)) {
    return false;
  }

  // 默认是过滤
  return true;
}

bool AppTokenItemFilter::ItemDirtyFilter(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                                  const ItemInfo& item) {
  if (!app_token_dict->app_token_filter_dirty[app_token_idx]) {
    return false;
  }

  ContentAttr content_attr;
  bool is_trival = true;
  if (news_index_->GetContentAttrByDocId(item.doc_id, &content_attr, &is_trival) && !is_trival) {
    if (content_attr.has_dirty() && content_attr.dirty() >= reco::ContentAttr::kSuspect) {
      VLOG(1) << "app [" << app_token_idx << "] filter by dirty, item_id: " << item.item_id;
      return true;
    }
  }

  return false;
}

bool AppTokenItemFilter::ItemBluffingFilter(const int app_token_idx,
                                                     const AppTokenFilterDict* app_token_dict,
                                                     const ItemInfo& item) {
  if (!app_token_dict->app_token_filter_bluffing_title[app_token_idx]) {
    return false;
  }

  ContentAttr content_attr;
  bool is_trival = true;
  if (news_index_->GetContentAttrByDocId(item.doc_id, &content_attr, &is_trival) && !is_trival) {
    if (content_attr.has_bluffing_title() && content_attr.bluffing_title() >= reco::ContentAttr::kSuspect) {
      VLOG(1) << "app [" << app_token_idx << "] filter by bluffing_title, item_id: " << item.item_id;
      return true;
    }
  }

  return false;
}

bool AppTokenItemFilter::SourceWemediaFilter(const int app_token_idx,
                                                      const AppTokenFilterDict* app_token_dict,
                                                      const ItemInfo& item) {
  if (!app_token_dict->app_token_filter_wemedia[app_token_idx]) {
    return false;
  }

  if (item.is_source_wemedia) {
    VLOG(1) << "app [" << app_token_idx << "] filter by wemedia, item_id: " << item.item_id;
    return true;
  }

  return false;
}

bool AppTokenItemFilter::TitleFilterByBlackPattern(const int app_token_idx,
                                                     const AppTokenFilterDict* app_token_dict,
                                                     const ItemInfo& item) {
  auto pattern = app_token_dict->app_token_title_match[app_token_idx];
  if (NULL == pattern) {
    VLOG(1) << "pattern is null";
    return false;
  }

  std::string title;
  if (!news_index_->GetItemTitleByDocId(item.doc_id, &title)) {
    return false;
  }

  extend::MatchResult result;
  if (pattern->Match(title.c_str(), title.size(), &result)) {
    VLOG(1) << "app [" << app_token_idx << "] filter by black pattern, item_id: " << item.item_id;
    return true;
  }

  return false;
}


bool AppTokenItemFilter::SourceFilterByWhiteDict(const int app_token_idx,
                                               const AppTokenFilterDict* app_token_dict,
                                               const ItemInfo& item) {
  auto white_source = app_token_dict->app_token_white_source[app_token_idx];
  if (white_source == NULL) {
    VLOG(1) << "pass:" << item.item_id;
    return false;
  }

  std::string source;
  if (!news_index_->GetSourceByDocId(item.doc_id, &source)) {
    VLOG(1) << "app [" << app_token_idx << "] filter by no source when check white dict";
    return true;
  }
  if (!white_source->Find(source)) {
    VLOG(1) << "app [" << app_token_idx << "] filter by source not in white dict, item_id: "
              << item.item_id;
    return true;
  }

  std::string orig_source;
  if (!news_index_->GetOrigSourceByDocId(item.doc_id, &orig_source)) {
    VLOG(1) << "app [" << app_token_idx << "] filter by no orig source when check white dict";
    return true;
  }

  if (!white_source->Find(orig_source)) {
    VLOG(1) << "app [" << app_token_idx << "] filter by orig source not in white dict, "
              << "item_id: " << item.item_id;
    return false;
  }

  VLOG(1) << "pass:" << item.item_id;
  return true;
}

bool AppTokenItemFilter::SourceFilterByBlackDict(const int app_token_idx,
                                                           const AppTokenFilterDict* app_token_dict,
                                                           const ItemInfo& item) {
  auto black_source = app_token_dict->app_token_black_source[app_token_idx];
  if (black_source == NULL) {
    return false;
  }

  std::string source;
  if (news_index_->GetSourceByDocId(item.doc_id, &source) && black_source->Find(source)) {
    VLOG(1) << "app [" << app_token_idx << "] filter by source in black dict, item_id: " << item.item_id;
    return true;
  }

  if (news_index_->GetOrigSourceByDocId(item.doc_id, &source) && black_source->Find(source)) {
    VLOG(1) << "app [" << app_token_idx << "] filter by orig source in black dict, item_id: " << item.item_id;
    return true;
  }

  return false;
}

bool AppTokenItemFilter::WemediaLevelFilter(const int app_token_idx,
                                                     const AppTokenFilterDict* app_token_dict,
                                                     const ItemInfo& item) {
  if (!item.is_source_wemedia) {
    return false;
  }

  auto min_media_level = app_token_dict->app_token_min_media_level[app_token_idx];
  if (item.media_level < min_media_level) {
    VLOG(1) << "app [" << app_token_idx << "] filter by wemedia level, item_id: " << item.item_id;
    return true;
  }

  return false;
}

bool AppTokenItemFilter::VideoLengthFilter(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                              const ItemInfo& item) {
  if (item.item_type != reco::kPureVideo) {
    return false;
  }

  if (!app_token_dict->app_token_video_length[app_token_idx].is_lenght_filter) {
    return false;
  }

  const int32 length_thr = item.is_source_wemedia
                           ? app_token_dict->app_token_video_length[app_token_idx].wemedia_max_len * 60
                           : app_token_dict->app_token_video_length[app_token_idx].common_max_len * 60;
  if (length_thr <= 0) {
    return false;
  }

  int32 video_length = news_index_->GetTotalVideoLengthByDocId(item.doc_id);
  VLOG(1) << "video length: " << video_length;

  if (video_length <= 0 || video_length > length_thr) {
    VLOG(1) << "app [" << app_token_idx << "] filter by video len [" << video_length
                << "] max len [" << length_thr << "], item_id: " << item.item_id;
    return true;
  }

  return false;
}

bool AppTokenItemFilter::ProducerWemediaYoutuFilter(const int app_token_idx,
                                                       const AppTokenFilterDict* app_token_dict,
                                                       const ItemInfo& item) {
  if (item.item_type != reco::kPureVideo) {
    return false;
  }

  if (!app_token_dict->app_token_filter_wemedia_youtu[app_token_idx]) {
    return false;
  }

  std::string producer;
  if (!news_index_->GetProducerByDocId(item.doc_id, &producer)) {
    return false;
  }
  if (base::LowerCaseEquals(producer, reco::common::kTuDouProducer)
        || base::LowerCaseEquals(producer, "cp_wemedia_youtu")
        || base::LowerCaseEquals(producer, "tudou-iflow")) {
    VLOG(1) << "app [" << app_token_idx << "] filter by wemedia youtu, item_id: " << item.item_id;
    return true;
  }

  return false;
}

bool AppTokenItemFilter::AppTokenRuleFilterUCB(const int app_token_idx,
                                                const AppTokenFilterDict* app_token_dict,
                                                const ItemInfo& item) {
  if (app_token_idx < 0) {
    return false;
  }

  if (app_token_dict == NULL) {
    return false;
  }

  if (TitleFilterByBlackPattern(app_token_idx, app_token_dict, item)) {
    return true;
  }

  if (SourceFilterByWhiteDict(app_token_idx, app_token_dict, item)) {
    return true;
  }

  return false;
}

bool AppTokenItemFilter::MainCityBadItemFIlter(const int app_token_idx,
                                              const AppTokenFilterDict* app_token_dict,
                                              const reco::ItemInfo& item) {
  if (app_token_dict == NULL || app_token_idx == -1) {
    return false;
  }
  if (!app_token_dict->app_token_filter_main_city[app_token_idx]) {
    return false;
  }

  ContentAttr content_attr;
  bool is_trival = true;
  if (news_index_->GetContentAttrByDocId(item.doc_id, &content_attr, &is_trival) && !is_trival) {
    if (content_attr.has_dirty() && content_attr.dirty() >= reco::ContentAttr::kSuspect) {
      VLOG(1) << "app [" << app_token_idx << "] main city filter by bluffing_title, item_id: "
                << item.item_id;
      return true;
    }

    if (content_attr.has_bluffing_title() && content_attr.bluffing_title() >= reco::ContentAttr::kSuspect) {
      VLOG(1) << "app [" << app_token_idx << "] main city filter by bluffing_title, item_id: "
                << item.item_id;
      return true;
    }
  }

  return false;
}
}
}
