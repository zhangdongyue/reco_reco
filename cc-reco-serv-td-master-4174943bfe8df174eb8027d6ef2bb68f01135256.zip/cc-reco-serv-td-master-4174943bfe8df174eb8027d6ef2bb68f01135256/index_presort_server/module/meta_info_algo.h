#pragma once

#include <string>
#include <unordered_map>
#include <vector>

#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/index_presort_server/frame/index_wrapper.h"

namespace reco {

class WemediaBooster {
 public:
  explicit WemediaBooster(const NewsIndex* news_index);
  ~WemediaBooster();

  bool WemediaBoost(const ItemInfo& item_info, int32* incr_show, int32* incr_click);
  void QuantityControl(ItemInfo* item_info);
 private:
  const NewsIndex* news_index_;
};

class DefaultCtrCalculator {
 public:
  explicit DefaultCtrCalculator(const NewsIndex* news_index);
  ~DefaultCtrCalculator();

  void Train(const std::vector<reco::ItemInfo>& items);

  float Predict(const reco::ItemInfo& item_info);

  // 取特征簇下最精准的特征值
  float SquashFeatureValue(const std::unordered_map<std::string, float>& feature_model,
                           const std::vector<std::string>& features,
                           std::string* feature);
 private:
  const NewsIndex* news_index_;

  std::unordered_map<std::string, float> feature_ctr_map_;
};

}  // namespace reco
