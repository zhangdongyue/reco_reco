//
// Created by allen.fw on 2017/8/30.
//

#pragma once

#include <boost/dynamic_bitset.hpp>
#include <memory>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <vector>

#include "reco/base/dict_manager/dict_manager.h"
#include "reco/bizc/proto/item.pb.h"

namespace reco {
class NewsIndex;
class ItemInfo;

namespace filter {
class AppTokenFilterDict;
class CateMediaLevelMap;

class AppTokenItemFilter {
 public:
  explicit AppTokenItemFilter(const NewsIndex* news_index) : news_index_(news_index) {}
  ~AppTokenItemFilter() {}

  bool FilterRule(const ItemInfo& reco_item, std::shared_ptr<boost::dynamic_bitset<uint8>> app_rule_mask);
  int GetAppTokenBit();

 private:
  int GetMaxAppIndex(const std::unordered_map<std::string, int>& app_token_bit_index);

  bool AppTokenRuleFilter(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                          const ItemInfo& item);

  bool AppTokenRuleFilterUCB(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                             const ItemInfo& item);

  bool CategoryFilterByTrie(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                   const ItemInfo& item);

  bool ItemTypeFilterByWhiteDict(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                 const ItemInfo& item);

  bool ItemDirtyFilter(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                             const ItemInfo& item);

  bool ItemBluffingFilter(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                const ItemInfo& item);

  bool SourceWemediaFilter(const int app_token_idx,
                                 const AppTokenFilterDict* app_token_dict,
                                 const ItemInfo& item);

  bool TitleFilterByBlackPattern(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                       const ItemInfo& item);

  bool SourceFilterByWhiteDict(const int app_token_idx,
                          const AppTokenFilterDict* app_token_dict,
                          const ItemInfo& item);

  bool WemediaLevelFilter(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                          const ItemInfo& item);

  bool SourceFilterByBlackDict(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                          const ItemInfo& item);

  bool VideoLengthFilter(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                         const ItemInfo& item);

  bool ProducerWemediaYoutuFilter(const int app_token_idx, const AppTokenFilterDict* app_token_dict,
                                  const ItemInfo& item);

  bool MainCityBadItemFIlter(const int app_token_idx,
                                   const AppTokenFilterDict* app_token_dict,
                                   const reco::ItemInfo& item);

 private:
  const NewsIndex* news_index_;
};
}
}
