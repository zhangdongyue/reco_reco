#include "reco/serv/index_presort_server/module/source_manager.h"
#include "reco/bizc/proto/index_aux_data.pb.h"
#include "base/common/basic_types.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/encoding/line_escape.h"
#include "base/common/closure.h"
#include "base/strings/string_number_conversions.h"
#include "base/file/memory_mapped_file.h"
#include "nlp/common/nlp_util.h"

namespace reco {
// const char* SourceManager::kRuleFile = "source_rule.data";
const char* kDeletedSuffix = "_DELETE";

SourceManager::SourceManager() {
  const_cast<base::dense_hash_map<std::string, RuleChain>* >(source_rule_chain_.GetDict())->set_empty_key("");
  source_rule_chain_.GetInactiveDict()->set_empty_key("");

  const_cast<base::dense_hash_map<std::string, std::string>* >(source_show_name_.GetDict())
      ->set_empty_key("");
  source_show_name_.GetInactiveDict()->set_empty_key("");
}

SourceManager::~SourceManager() {
}

// int SourceManager::LoadRuleFile(const base::FilePath& dir) {
//   int total = 0;
//   base::FilePath path = dir.Append(kRuleFile);
//   if (base::file_util::PathExists(path)) {
//     std::vector<std::string> lines;
//     base::file_util::ReadFileToLines(path, &lines);
//     std::vector<std::string> flds;
//     for (size_t i = 0; i < lines.size(); ++i) {
//       flds.clear();
//       base::SplitString(lines[i], "\t", &flds);
//       CHECK_EQ(flds.size(), 4u);
//       const std::string& source = flds[0];
//       if (source.empty()) continue;
//
//       // "UC相关,头条相关"   // NOLINT
//       // UC相关，头条相关    // NOLINT
//       // 头条相关
//       const std::string& apps = flds[1];
//       //
//       // IOS
//       // IOS，Android
//       const std::string& frs = flds[2];
//       // 都是一线城市
//       std::vector<FilterRule> rules;
//       bool ios = (frs == "IOS");
//       if (apps.find("UC相关") != std::string::npos) {    // NOLINT
//         reco::index_data::SourceBlockRule rule;
//         rule.set_app_name("uc-iflow");
//         rule.set_block_main_city(true);
//         if (ios) {
//           rule.set_os("ios");
//         }
//         rules.push_back(FilterRule::GenerateRule(rule));
//       }
//       if (apps.find("头条相关") != std::string::npos) {
//         reco::index_data::SourceBlockRule rule;
//         rule.set_app_name("ucnews-iflow");
//         rule.set_block_main_city(true);
//         if (ios) {
//           rule.set_os("ios");
//         }
//         rules.push_back(FilterRule::GenerateRule(rule));
//       }
//       RuleChain chain;
//       FilterRule::SetFilterRuleChain(rules, &chain);
//       if (chain.any()) ++total;
//       source_rule_chain_[source] = chain;
//       VLOG(1) << "source: " << source << ", chain: " << chain.to_string();
//     }
//   }
//   return total;
// }

void SourceManager::CanSwitch() {
  while (!source_infos_.CanSwitch()) {
    LOG(INFO) << "source info can't swith, sleep";
    base::SleepForSeconds(10);
  }

  while (!normalized_wemedia_authors_.CanSwitch()) {
    LOG(INFO) << "wemedia author can't swith, sleep";
    base::SleepForSeconds(10);
  }

  while (!source_rule_chain_.CanSwitch()) {
    LOG(INFO) << "rule chain can't swith, sleep";
    base::SleepForSeconds(10);
  }

  while (!source_show_name_.CanSwitch()) {
    LOG(INFO) << "show name can't swith, sleep";
    base::SleepForSeconds(10);
  }
}

void SourceManager::SwitchDict() {
  source_infos_.SwitchDict();
  normalized_wemedia_authors_.SwitchDict();
  source_rule_chain_.SwitchDict();
  source_show_name_.SwitchDict();
}

void SourceManager::LoadFile() {
  const base::FilePath& path = file_path_;
  int64 total_rule_source = 0;  // 有黑名单规则的站点个数
  // NOTE: for expr
  // total_rule_source += LoadRuleFile(dir);

  CanSwitch();

  auto source_infos_dict = source_infos_.GetInactiveDict();
  source_infos_dict->clear();
  auto normalized_wemedia_authors_dict = normalized_wemedia_authors_.GetInactiveDict();
  normalized_wemedia_authors_dict->clear();
  auto source_rule_chain_dict = source_rule_chain_.GetInactiveDict();
  source_rule_chain_dict->clear();
  auto source_show_name_dict = source_show_name_.GetInactiveDict();
  source_show_name_dict->clear();

  if (base::file_util::PathExists(path)) {
    std::string line;
    // load sim data
    std::string unes_line;
    reco::index_data::SourceInfo source_info;

    base::file_util::MemoryMappedFile file;
    CHECK(file.Initialize(path.value()));

    auto data = file.data();
    auto data_end = data + file.size();

    int record_num = 0;
    while (data < data_end) {
      ++record_num;
      int size = *reinterpret_cast<const int *>(data);
      data += sizeof(int);
      if (!source_info.ParseFromArray(data, size)) {
        data += size;
        LOG(WARNING) << "parse from array fail.";
        continue;
      }
      data += size;

      if (source_info.source().empty()) continue;
      // filter deleted source
      if (source_info.source().find(kDeletedSuffix) != std::string::npos) continue;

      source_infos_dict->push_back(source_info);

      VLOG(1) << source_info.source() << " " << source_info.show_source()
              << source_info.is_wemedia() << " " << source_info.publish_state();
      if (!source_info.show_source().empty()) {
        source_show_name_dict->insert(std::make_pair(source_info.source(), source_info.show_source()));
      } else {
        source_show_name_dict->insert(std::make_pair(source_info.source(), source_info.source()));
      }

      if (source_info.is_wemedia()) {
        // 建立自媒体人查询
        std::string author = nlp::util::NormalizeLine(source_info.show_source());
        if (!author.empty()) {
          normalized_wemedia_authors_dict->push_back(std::make_pair(author, source_infos_dict->back()));
        }
      }

      // 建立种子的过滤条件
      RuleChain chain;
      SetFilterRuleChain(source_info, source_info.is_wemedia(), &chain);
      (*source_rule_chain_dict)[source_info.source()] = chain;
      VLOG(1) << "source: " << source_info.source() << ", chain: " << chain.to_string();
      if (chain.any()) ++total_rule_source;
    }

    LOG(INFO) << "after loading source_info.";
  } else {
    LOG(ERROR) << "un exist path: " << path.value();
  }

  LOG(INFO) << "load total " << source_infos_dict->size() << " sources"
      << ", total " << normalized_wemedia_authors_dict->size() << " wemedia authors"
      << ", total " << total_rule_source << " sources with blocking rules";

  SwitchDict();

  return;
}

std::vector<reco::index_data::SourceInfo> SourceManager::SearchWemediaAuthor(const std::string& query,
                                                                             bool filter_unpub) const {
  std::vector<reco::index_data::SourceInfo> ret;
  auto dict_authors = normalized_wemedia_authors_.GetDict();

  std::string nor_qry = nlp::util::NormalizeLine(query);
  for (auto it = dict_authors->begin(); it != dict_authors->end(); ++it) {
    if (it->first.find(nor_qry) != std::string::npos) {
      if (filter_unpub && it->second.publish_state() != 0) {
        continue;
      }
      ret.push_back(it->second);
    }
  }

  return ret;
}

void SourceManager::SetFilterRuleChain(const reco::index_data::SourceInfo& source,
                                       bool is_wemedia, RuleChain* chain) {
  chain->reset();
  std::vector<FilterRule> rules;
  if (is_wemedia) {
    // 华为渠道过滤自媒体
    int app_bit = FilterRule::GetAppNameBitPos("huawei-iflow");
    rules.push_back(FilterRule::AppNameFilterRule(app_bit));
  }

  if (rules.empty() && source.rules_size() == 0) {
    return;
  }

  for (int i = 0; i < source.rules_size(); ++i) {
    rules.push_back(FilterRule::GenerateRule(source.rules(i)));
  }
  FilterRule::SetFilterRuleChain(rules, chain);

  return;
}
}
