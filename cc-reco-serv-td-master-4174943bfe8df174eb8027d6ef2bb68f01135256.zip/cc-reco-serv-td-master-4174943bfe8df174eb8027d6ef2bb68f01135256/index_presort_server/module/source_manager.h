#pragma once
#include <atomic>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <utility>

#include "reco/bizc/reco_index/filter_rule.h"
#include "reco/bizc/reco_index/dynamic_dict.h"
#include "reco/bizc/reco_index/file_monitor.h"
#include "reco/bizc/proto/index_aux_data.pb.h"
#include "base/common/basic_types.h"
#include "base/container/dense_hash_map.h"

namespace base {
class FilePath;
}

namespace reco {
class SourceManager : public FileMonitor {
 public:
  explicit SourceManager();
  virtual ~SourceManager();

  // override
  virtual void LoadFile();

  // filter_unpub 过滤未发布的种子
  std::vector<reco::index_data::SourceInfo> SearchWemediaAuthor(const std::string& query,
                                                                bool filter_unpub) const;

  bool GetSourceRuleChain(const std::string& source,
                          RuleChain* rule_chain) const {
    rule_chain->reset();
    auto dict = source_rule_chain_.GetDict();
    auto it = dict->find(source);
    if (it != dict->end()) {
      *rule_chain = it->second;
      return true;
    } else {
      return false;
    }
  }

  std::string GetShowSource(const std::string& source) const {
    auto dict = source_show_name_.GetDict();
    auto it = dict->find(source);
    if (it != dict->end()) {
      return it->second;
    } else {
      return source;
    }
  }

 private:
  // static const char* kRuleFile;  // for expr
  // int LoadRuleFile(const base::FilePath& path);

  void SetFilterRuleChain(const reco::index_data::SourceInfo& source,
                          bool is_wemedia, RuleChain* rule);

  void CanSwitch();
  void SwitchDict();
  // 全量 source info
  DynamicDict<std::vector<reco::index_data::SourceInfo> > source_infos_;
  // 归一化的自媒体人名字及其源信息
  DynamicDict<std::vector<std::pair<std::string, index_data::SourceInfo> > > normalized_wemedia_authors_;
  // source name 屏蔽规则
  DynamicDict<base::dense_hash_map<std::string, RuleChain> > source_rule_chain_;
  // source name -> source show name
  DynamicDict<base::dense_hash_map<std::string, std::string> > source_show_name_;
};
}
