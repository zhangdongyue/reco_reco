#include "reco/serv/index_presort_server/module/index_dict_manager.h"
#include "reco/bizc/common/index_strategy_define.h"

#include "base/file/file_path.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/time/time.h"

DECLARE_string(data_dir);
DECLARE_string(index_dir);

namespace reco {

const char* IndexDictManager::kCategoryChannelMapFile  = "category_channel_map.txt";
const char* IndexDictManager::kCategoryMediaLevelFile  = "media_level.txt";
const char* IndexDictManager::kCategoryMediaQualityFile  = "media_quality.txt";
const char* IndexDictManager::kExtendCategoryMapFile = "extend_category_map.txt";
const char* IndexDictManager::kExtendItemidCategoryFile = "item_category.txt";
const char* IndexDictManager::kWemediaNewbeeFile = "wemedia_createtime.txt";
const char* IndexDictManager::kWemediaMetaFile = "wemedia_meta.txt";
const char* IndexDictManager::kDizhiTagFile = "dizhi_tag.txt";
const char* IndexDictManager::kMiningStrategyItemFile = "index_item_strategy";

const IndexDictManager* IndexDictManager::GetInstance() {
  static const IndexDictManager manager;
  return &manager;
}

IndexDictManager::IndexDictManager() {
  category_channel_map_.set_empty_key("");
  cate_media_level_map_.set_empty_key("");
  cate_media_level_num_map_.set_empty_key("");
  extend_category_map_.set_empty_key("");
  extend_itemid_category_map_.set_empty_key(0);
  wemedia_meta_map_.set_empty_key("");
  mining_strategy_item_.set_empty_key(0);

  if (FLAGS_data_dir.empty()) return;
  base::FilePath base_dir(FLAGS_data_dir);

  LoadCategoryChannelMap(base_dir);
  LoadExtendCategoryMap(base_dir);
  LoadDizhiTag(base_dir);

  if (FLAGS_index_dir.empty()) return;
  base::FilePath index_path = base::FilePath(FLAGS_index_dir);
  LoadExtendItemidCategoryFile(index_path);
  base::FilePath category_media_file = index_path.Append(kCategoryMediaLevelFile);
  LoadCategoryMediaLevelMap(category_media_file);
  base::FilePath old_category_media_file = index_path.Append(kCategoryMediaQualityFile);
  LoadOldCategoryMediaLevelMap(old_category_media_file);
  base::FilePath wemedia_meta_file = index_path.Append(kWemediaMetaFile);
  LoadWemediaMetaMap(wemedia_meta_file);
  base::FilePath ming_strategy_item_file = index_path.Append(kMiningStrategyItemFile);
  LoadMiningStrategyItem(ming_strategy_item_file);
}

IndexDictManager::~IndexDictManager() {
}

void IndexDictManager::LoadCategoryMediaLevelMap(const base::FilePath& map_file) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(map_file, &lines)) {
    LOG(WARNING) << "Read cate media level dict fail, "
                 << map_file.ToString();
    return;
  }

  int val;
  reco::MediaLevel level;
  std::vector<std::string> flds;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    flds.clear();
    base::SplitString(lines[idx], "\t", &flds);
    if (flds.size() < 3u || !base::StringToInt(flds[2], &val)) {
      LOG(ERROR) << "parse field fail, " << lines[idx];
      continue;
    }

    // key = cate "\t" media
    const std::string& key = flds[0] + "\t" + flds[1];
    // val
    level = reco::MediaLevel(val);
    // insert
    auto iter = cate_media_level_map_.find(key);
    if (iter != cate_media_level_map_.end()) {
      if (level > iter->second) {
        iter->second = level;
      }
    } else {
      cate_media_level_map_.insert(std::make_pair(key, level));
    }
  }
  LOG(INFO) << "succ to load cate_media level, total record: "
            << cate_media_level_map_.size();
}

void IndexDictManager::LoadOldCategoryMediaLevelMap(const base::FilePath& map_file) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(map_file, &lines)) {
    LOG(WARNING) << "Read cate media level dict fail, "
                 << map_file.ToString();
    return;
  }
  int32 val;
  std::vector<std::string> flds;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    flds.clear();
    base::SplitString(lines[idx], "\t", &flds);
    if (flds.size() < 3u || !base::StringToInt(flds[2], &val)) {
      LOG(ERROR) << "parse field fail, " << lines[idx];
      continue;
    }
    // insert
    const std::string& cate_media_num_key = flds[0] + "-" + flds[2];
    auto cate_media_num_iter = cate_media_level_num_map_.find(cate_media_num_key);
    if (cate_media_num_iter == cate_media_level_num_map_.end()) {
      cate_media_num_iter = cate_media_level_num_map_.insert(std::make_pair(cate_media_num_key, 0)).first;
    }
    ++cate_media_num_iter->second;
  }
  LOG(INFO) << "succ to load index cate_media level, total record: "
            << cate_media_level_num_map_.size();
}

void IndexDictManager::LoadWemediaMetaMap(const base::FilePath& map_file) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(map_file, &lines)) {
    LOG(WARNING) << "Read wemedia meta dict fail, "
                 << map_file.ToString();
    return;
  }

  std::vector<std::string> flds;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    flds.clear();
    base::SplitString(lines[idx], "\t", &flds);
    WemediaMeta meta;
    if (flds.size() < 11u
        || !base::StringToDouble(flds[1], &meta.low_quality_ratio)
        || !base::StringToInt(flds[2], &meta.normal_show_num)
        || !base::StringToInt(flds[3], &meta.normal_click_num)
        || !base::StringToDouble(flds[4], &meta.normal_ctr)
        || !base::StringToInt(flds[5], &meta.suspect_show_num)
        || !base::StringToInt(flds[6], &meta.suspect_click_num)
        || !base::StringToDouble(flds[7], &meta.suspect_ctr)
        || !base::StringToInt(flds[8], &meta.low_show_num)
        || !base::StringToInt(flds[9], &meta.low_click_num)
        || !base::StringToDouble(flds[10], &meta.low_ctr)) {
      LOG(ERROR) << "parse field fail, " << lines[idx];
      continue;
    }
    // key = wemedia
    const std::string& key = flds[0];
    // insert
    wemedia_meta_map_.insert(std::make_pair(key, meta));
  }

  LOG(INFO) << "succ to load wemedia meta, total record: "
            << wemedia_meta_map_.size();
}

void IndexDictManager::LoadCategoryChannelMap(const base::FilePath& base_dir) {
  category_channel_map_.clear();

  base::FilePath map_file = base_dir.Append(kCategoryChannelMapFile);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(map_file, &lines)) {
    LOG(WARNING) << "Read category channel dict fail, "
                 << map_file.ToString();
    return;
  }

  int64 cid;
  std::vector<std::string> flds;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    flds.clear();
    base::SplitString(lines[idx], "\t", &flds);
    if (flds.size() < 2u ||
        !base::StringToInt64(flds[1], &cid)) {
      LOG(ERROR) << "parse field fail: " << lines[idx];
      continue;
    }
    const std::string& cate = flds[0];
    category_channel_map_.insert(std::make_pair(cate, cid));
  }

  LOG(INFO) << "succ to load category_channel dict, total record: "
            << category_channel_map_.size();
}

void IndexDictManager::LoadExtendCategoryMap(const base::FilePath& base_dir) {
  extend_category_map_.clear();

  base::FilePath map_file = base_dir.Append(kExtendCategoryMapFile);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(map_file, &lines)) {
    LOG(WARNING) << "Read extend category dict fail, "
                 << map_file.ToString();
    return;
  }

  std::vector<std::string> flds;
  for (size_t i = 0; i < lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);
    if (flds.size() < 2) {
      LOG(ERROR) << "err line: " << lines[i];
      continue;
    }
    auto it_pair = extend_category_map_.insert(std::make_pair(flds[0], std::unordered_set<std::string>()));
    if (!it_pair.second) {
      LOG(ERROR) << "dup line: " << lines[i];
      continue;
    }

    for (size_t j = 1; j < flds.size(); ++j) {
      it_pair.first->second.insert(flds[j]);
    }
  }

  LOG(INFO) << "succ to load extend category dict, total record: "
            << extend_category_map_.size();
}

void IndexDictManager::LoadDizhiTag(const base::FilePath& base_dir) {
  dizhi_tag_map_.clear();
  dizhi_category_map_.clear();

  base::FilePath map_file = base_dir.Append(kDizhiTagFile);
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(map_file, &lines)) {
    LOG(WARNING) << "Read dizhi tag dict fail, "
                 << map_file.ToString();
    return;
  }

  std::vector<std::string> flds;
  std::vector<std::string> key_value_vec;
  for (size_t idx = 0; idx < lines.size(); ++idx) {
    flds.clear();
    base::SplitString(lines[idx], "\t", &flds);
    if (flds.size() < 1u) {
      LOG(ERROR) << "parse field fail: " << lines[idx];
      continue;
    }
    key_value_vec.clear();
    base::SplitString(flds[0], "#", &key_value_vec);
    if (key_value_vec.size() < 2u) continue;
    if (key_value_vec[0] == "TAG") {
      dizhi_tag_map_.insert(std::make_pair(key_value_vec[1], 1));
    } else if (key_value_vec[0] == "CATE") {
      dizhi_category_map_.insert(std::make_pair(key_value_vec[1], 1));
    }
  }

  LOG(INFO) << "succ to load dizhi tag dict, total record: "
            << dizhi_tag_map_.size();
}

void IndexDictManager::LoadMiningStrategyItem(const base::FilePath& map_file) {
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(map_file, &lines)) {
    LOG(WARNING) << "Read mining strategy item dict fail, "
                 << map_file.ToString();
    return;
  }
  std::vector<std::string> fields;
  int32 counter = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    fields.clear();
    base::SplitString(lines[i], "\t", &fields);
    if (fields.size() < 2u) continue;
    uint64 itemid;
    int32 strategy;
    if (!base::StringToUint64(fields[0], &itemid)
        || !base::StringToInt(fields[1], &strategy)) {
      continue;
    }
    if (strategy != reco::common::kLeafBeautyMine.enum_value) {
      continue;  // 目前只要美女挖掘的结果
    }
    mining_strategy_item_[strategy].push_back(itemid);
    ++counter;
  }

  LOG(INFO) << "succ to mining strategy item total record: " << counter;
}



void IndexDictManager::LoadExtendItemidCategoryFile(const base::FilePath& base_dir) {
  // presort用不上
  return;
  if (!base::file_util::PathExists(base_dir)) return;
  base::FilePath file_path = base_dir.Append(kExtendItemidCategoryFile);
  if (!base::file_util::PathExists(file_path)) return;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines) || lines.empty()) {
    LOG(WARNING) << "Read item category file error, " << file_path.ToString();
    return;
  }
  std::vector<std::string> fields;
  std::vector<std::string> categories;
  for (size_t i = 0; i < lines.size(); ++i) {
    fields.clear();
    base::SplitString(lines[i], "\t", &fields);
    if (fields.size() < 2u) continue;
    uint64 itemid;
    if (!base::StringToUint64(fields[0], &itemid) || fields[1].empty()) {
      continue;
    }
    categories.clear();
    for (size_t j = 1; j < fields.size(); ++j) {
      if (!fields[j].empty()) {
        categories.push_back(fields[j]);
      }
    }
    if (categories.size() > 0) {
      extend_itemid_category_map_[itemid] = categories;
    }
  }
  LOG(INFO) << "succ to load extend item category file: " << extend_itemid_category_map_.size();
}

}  // namespace reco
