#pragma once
#include "base/common/basic_types.h"

struct ResponseDumpInfo {
  ResponseDumpInfo(): status(-1), body_size(0) {}
  int status;
  int64 send_timestamp;
  int64 response_timestamp;
  uint64 body_size;
};
