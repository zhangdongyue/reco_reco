#include <string>
#include <vector>
#include "base/common/base.h"
#include "base/time/timestamp.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "reco/serv/index_presort_server/perf/define.h"

DEFINE_string(latency_bins, "50,100,300,500,700,1000,5000", "bins in ms, seperated by comma");
DEFINE_int32(print_interval, 1000, "max interval in ms");

namespace reco {
class PressResponser {
 private:
  atomic_bool running_;
  int total_response_;

  thread::BlockingQueue<ResponseDumpInfo*>* response_queue_;

 public:
  PressResponser(thread::BlockingQueue<ResponseDumpInfo*>* response_queue): response_queue_(response_queue) {}
  ~PressResponser() {}

  void run() {
    running_ = true;
    total_response_ = 0;
    // 相应qps，平均响应时间，最长响应时间
    double qps_in_slice = 0;
    double latency_in_slice = 0;
    double latency_avg_in_slice = 0;
    double max_latency_in_slice = 0;
    int64 latency_total = 0;
    double max_latency_total = 0;
    // 高耗时间分布
    std::vector<int> bins;
    CHECK(GenBins(FLAGS_latency_bins, &bins));
    std::vector<int> to_bins_slice(bins.size(), 0);
    std::vector<int> to_bins_total(bins.size(), 0);

    // 成功率
    int succ_in_slice = 0;
    int err_in_slice = 0;
    int succ_total = 0;
    int err_total = 0;

    int max_interval = FLAGS_print_interval;
    int64 slice_start_ts = base::GetTimestamp() / 1000;
    int64 slice_end_ts = slice_start_ts;
    long slice_bytes = 0;
    int slice_sample_num = 0;
    bool from_begin = true;

    int64 very_start = base::GetTimestamp();

    ResponseDumpInfo* dumpinfo = NULL;
    while (running_) {
      slice_end_ts = base::GetTimestamp() / 1000;
      int succ = -1;
      if (dumpinfo == NULL) {
        succ = response_queue_->TimedTake(5, &dumpinfo);
      }

      if (succ == 1 && dumpinfo != NULL) {
        ++slice_sample_num;
        ++total_response_;
        // 平均响应时间和最大响应时间
        int64 latency = dumpinfo->response_timestamp - dumpinfo->send_timestamp;  // ms
        latency_in_slice += latency;
        latency_total += latency;
        if (latency > max_latency_in_slice) {
          max_latency_in_slice = latency;
        }
        // 前500个数据不计入总的统计结果
        if (latency > max_latency_total && total_response_ >= 500) {
          max_latency_total = latency;
        }

        // 耗时分布
        for (int i = 0; i < (int)bins.size(); ++i) {
          if (latency < bins[i]) {
            ++to_bins_slice[i];
            // 前500个不计入总的统计结果
            if (total_response_ >= 500) {
              ++to_bins_total[i];
            }
            break;
          }
        }
        // 成功率
        if (dumpinfo->status == 200) {
          ++succ_in_slice;
          ++succ_total;
          slice_bytes += dumpinfo->body_size;
        } else {
          ++err_in_slice;
          ++err_total;
        }
        delete dumpinfo;
        dumpinfo = NULL;
      }

      // 超过一定时间则打印一次结果
      if (slice_end_ts - slice_start_ts > max_interval) {
        double time_second = (slice_end_ts - slice_start_ts) / 1000.0;
        qps_in_slice = slice_sample_num / time_second;
        double transfer_in_slice = slice_bytes / time_second / 1000000.0;
        latency_avg_in_slice = latency_in_slice / slice_sample_num;
        std::string out_str =
            base::StringPrintf(
                "succ total:%d, succ:%d, fail:%d, qps:%.2f, net:%.2fMBps, avg_latency:%.2f ms, max_latency:%.2f ms, latn_hist:[",
                succ_total, succ_in_slice, err_in_slice, qps_in_slice, transfer_in_slice,
                latency_avg_in_slice, max_latency_in_slice);
        for (int i = 0; i < (int)bins.size(); ++i) {
          out_str += base::StringPrintf("%dms:%d, ", bins[i], to_bins_slice[i]);
        }
        out_str += "]";
        cout << out_str << endl;
        ::google::FlushLogFiles(::google::INFO);

        from_begin = true;
      }

      if (from_begin) {
        slice_start_ts = base::GetTimestamp() / 1000;
        slice_sample_num = 0;
        max_latency_in_slice = -1;
        latency_in_slice = 0;
        succ_in_slice = 0;
        err_in_slice = 0;
        slice_bytes = 0;
        for (int i = 0; i < (int)to_bins_slice.size(); ++i) {
          to_bins_slice[i] = 0;
        }
        from_begin = false;
      }
    }
    {
      int64 final_end = base::GetTimestamp();
      double time_second = (final_end - very_start) / 1000000.0;
      double qps_total = total_response_ / time_second;
      double latency_avg = (double)latency_total / total_response_;
      std::string out_str = base::StringPrintf(
              "final succ:%d, fail:%d, qps:%.2f, avg_latency:%.2f ms, max_latency:%.2f ms latn_hist:[",
              succ_total, err_total, qps_total, latency_avg, max_latency_total);
      for (int i = 0; i < (int)bins.size(); ++i) {
        out_str += base::StringPrintf("%d ms:%d, ", bins[i], to_bins_total[i]);
      }
      out_str += "]";
      cout << out_str << endl;
      ::google::FlushLogFiles(::google::INFO);
    }
    cout << "qps calc thread ends" << endl;
  }

  void stop() {
    running_ = false;
  }


  bool GenBins(const std::string& s, std::vector<int>* bins) {
    CHECK_NOTNULL(bins);
    std::vector<std::string> flds;
    base::SplitString(s, ",", &flds);
    if (flds.size() == 0) return false;

    for (int i = 0; i < (int)flds.size(); ++i) {
      bins->push_back(base::ParseIntOrDie(flds[i]));
    }
    return true;
  }
};
}
