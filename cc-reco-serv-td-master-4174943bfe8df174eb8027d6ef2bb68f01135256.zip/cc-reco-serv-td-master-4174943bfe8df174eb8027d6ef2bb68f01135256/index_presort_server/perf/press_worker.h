#pragma once
#include <google/protobuf/stubs/common.h>
#include <iostream>
#include <iomanip>
#include <string>
#include <set>
#include <atomic>
#include "arpc/CommonMacros.h"
#include "arpc/RPCInterface.h"
#include "arpc/ANetRPCChannelManager.h"
#include "arpc/ANetRPCChannel.h"
#include "arpc/ANetRPCController.h"
#include "client_pool/ArpcClientPool.h"
#include "reco/bizc/proto_arpc/index_presort_server.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/thread/thread.h"
#include "base/thread/blocking_queue.h"
#include "base/common/basic_types.h"
#include "base/strings/string_number_conversions.h"
#include "reco/serv/index_presort_server/perf/define.h"
#include "serving_base/utility/timer.h"
#include "base/time/timestamp.h"

using namespace google::protobuf;
using namespace std;
using namespace arpc;
using namespace arpc_client_pool::client_pool;
using namespace reco::presort;
using namespace base;
using namespace reco;
using ::Closure;

DEFINE_int32(total_req_per_thread, 1e3, "");
DEFINE_int32(qps, 1e6, "");
DEFINE_int32(time_slice, 1000, "time slice in ms");
DEFINE_int32(min_num_in_slice, 1, "min num sample in slice");
DEFINE_int32(timeout, 1e3, "ms");
DEFINE_int32(result_num, 1e3, "");
DEFINE_int32(api, 0, "0-query ha3, 1-test query");
DECLARE_int32(thread_num);

namespace reco {
class PressWorker {
 private:
  atomic_bool running_;
  int qps_;
  int64 total_request_;

  thread::BlockingQueue<int64>* query_queue_;
  thread::BlockingQueue<ResponseDumpInfo*>* response_queue_;
  ArpcClientPool<PresortService_Stub>* conn_pool_;

 public:
  bool running() {
    return running_;
  }

  PressWorker(thread::BlockingQueue<int64>* query_queue,
              thread::BlockingQueue<ResponseDumpInfo*>* response_queue,
              ArpcClientPool<PresortService_Stub>* conn_pool) {
    running_ = true;
    qps_ = FLAGS_qps;
    total_request_ = FLAGS_total_req_per_thread;
    response_queue_ = response_queue;
    query_queue_ = query_queue;
    conn_pool_ = conn_pool;
  }

  void run(int thread_id) {
    running_ = true;
    float coeff = qps_ / 1000.0;
    float p_gain = coeff * FLAGS_time_slice;
    if (p_gain < FLAGS_min_num_in_slice) {
      p_gain = FLAGS_min_num_in_slice;
    }
    int time_slice = (int) (p_gain / coeff);  // in ms
    int grain_num = (int) p_gain;  // num in slice

    cout << "Thread " << thread_id << " start." << endl;

    int64 very_start = base::GetTimestamp();
    int64 send_num = 0;
    int64 start = 0;
    int64 tick = -1;
    bool from_begin = true;
    int total_send = 0;
    int total_err = 0;

    while (running_) {
      if (send_num >= grain_num) {
        tick = base::GetTimestamp() / 1000;
        int64 time_consume = tick - start;
        if (time_consume <= time_slice) {
          base::SleepForMilliseconds(time_slice - time_consume);
        }
        from_begin = true;
        send_num = 0;
      }

      if (from_begin) {
        start = base::GetTimestamp() / 1000;
        from_begin = false;
      }

      int64 channel_id = query_queue_->Take();
      int result_size = 0;
      int body_size = 0;
      auto stub_ptr = conn_pool_->get();
      ANetRPCController cntler;
      cntler.SetExpireTime(FLAGS_timeout);

      std::string query = StringPrintf("special_index:CN_%ld", channel_id);
      ResponseDumpInfo* dumpInfo = new ResponseDumpInfo();
      dumpInfo->send_timestamp = base::GetTimestamp() / 1000;

      if (FLAGS_api == 0) {
        QueryHa3Request req;
        QueryHa3Response resp;
        req.set_query_clause(query);
        req.set_result_num(FLAGS_result_num);

        stub_ptr->stub()->QueryHa3(&cntler, &req, &resp, NULL);
        result_size = resp.item_info_size();
        body_size = resp.ByteSize();
      } else {
        GetDefaultRecoRequest req;
        GetDefaultRecoResponse resp;
        req.set_result_num(FLAGS_result_num);
        req.set_reco_type(kTestReco);
        req.set_clause(query); 

        stub_ptr->stub()->GetDefaultReco(&cntler, &req, &resp, NULL);
        result_size = resp.item_info_size();
        body_size = resp.ByteSize();
      }

      int err_code = cntler.GetErrorCode();
      if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
        cout << "thread:" << thread_id << " channel_id:" << channel_id << " rpc failed, msg:" << cntler.ErrorText() << endl;
        dumpInfo->status = -1;
      } else {
        dumpInfo->status = 200;
        dumpInfo->body_size = body_size;
      }
      dumpInfo->response_timestamp = base::GetTimestamp() / 1000;
      response_queue_->Put(dumpInfo);

      if (result_size >= FLAGS_result_num) {
        query_queue_->Put(channel_id);
      } else if (query_queue_->Size() <= FLAGS_thread_num) {
        query_queue_->Put(channel_id);
      } else {
        ;
      }
      ++total_send;
      ++send_num;
      if (total_send >= total_request_) {
        running_ = false;
        break;
      }
    }

    int64 final_end = base::GetTimestamp();
    int64 total_ms = (final_end - very_start) / 1000;

    cout << base::StringPrintf("Thread %d end, total send: %d total err: %d, total consume: %ld ms, qps:%.2f",
                               thread_id, total_send, total_err, total_ms, (double)total_send / (total_ms/1000)) << endl;
  }
};
}
