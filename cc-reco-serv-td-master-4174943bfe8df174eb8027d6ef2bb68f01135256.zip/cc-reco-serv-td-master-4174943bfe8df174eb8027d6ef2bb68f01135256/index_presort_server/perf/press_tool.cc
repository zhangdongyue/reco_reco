#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/thread/thread_pool.h"
#include "base/thread/blocking_queue.h"
#include "base/file/file_util.h"
#include "reco/serv/index_presort_server/perf/press_worker.h"
#include "reco/serv/index_presort_server/perf/press_responser.h"
#include "reco/serv/index_presort_server/perf/define.h"
#include "base/common/sleep.h"

DEFINE_string(ips, "127.0.0.1", "");
DEFINE_int32(port, 20022, "");
DEFINE_int32(thread_num, 10, "");

int main(int argc, char** argv) {
  base::InitApp(&argc, &argv, "presort server press client.");

  std::vector<std::string> ips_vec;
  base::SplitString(FLAGS_ips, ",", &ips_vec);
  if (ips_vec.size() == 0) {
    cout << "invalid ha3 ips." << endl;
    return -1;
  }
  cout << "ip size:" << ips_vec.size() << endl;

  PoolParams params;
  params.clientCount = FLAGS_thread_num * 2 * (int)ips_vec.size();

  std::set<StubInfo> stub_info;
  for (const auto& ip : ips_vec) {
    if (ip.size() < 8) continue;
    stub_info.insert(StubInfo(ip, FLAGS_port));
  }

  ArpcClientPool<PresortService_Stub> conn_pool;
  if (!conn_pool.init(params, stub_info)) {
    cout << "conn pool init failed." << endl;
    return -1;
  }

  // get channels as test data
  auto stub_ptr = conn_pool.get();
  ANetRPCController cntler;
  GetChnAndCateRequest req;
  GetChnAndCateResponse resp;

  cntler.SetExpireTime(FLAGS_timeout);
  req.set_return_channel(true);
  req.set_return_category(true);
  stub_ptr->stub()->GetChannelAndCategory(&cntler, &req, &resp, NULL);

  int err_code = cntler.GetErrorCode();
  if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
    cout << "rpc error." << endl;
    cout << "err code:" << err_code << " err msg:" << cntler.ErrorText() << endl;
    return -1;
  }
  stub_ptr.reset();
  cout << "fetched channel size:" << resp.channels_size() << endl;

  thread::BlockingQueue<int64> query_queue;
  for (int j = 0; j < FLAGS_thread_num; j++) {
    for (int i = 0; i < resp.channels_size(); i++) {
      query_queue.Put(resp.channels(i));
    }
  }
  cout << "gen queue size:" << query_queue.Size() << endl;

  thread::BlockingQueue<ResponseDumpInfo*> response_queue;
  PressResponser responser(&response_queue);
  std::vector<PressWorker*> workers;

  thread::ThreadPool pool(FLAGS_thread_num + 1);
  for (int i = 0; i < FLAGS_thread_num; ++i) {
    workers.push_back(new PressWorker(&query_queue, &response_queue, &conn_pool));
    pool.AddTask(::NewCallback<PressWorker, int>(workers.back(), &PressWorker::run, i));
  }
  pool.AddTask(::NewCallback<PressResponser>(&responser, &PressResponser::run));

  int total_workers = FLAGS_thread_num;
  while (total_workers > 0) {
    base::SleepForMilliseconds(200);
    total_workers = 0;
    for (int i = 0; i < (int)workers.size(); ++i) {
      if (workers[i]->running()) {
        ++total_workers;
      }
    }
  }
  response_queue.Close();
  query_queue.Close();
  responser.stop();

  pool.JoinAll();

  return 0;
}
