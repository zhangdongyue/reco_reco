#include <google/protobuf/stubs/common.h>
#include <iostream>
#include <iomanip>
#include <string>
#include <set>
#include <atomic>
#include "arpc/CommonMacros.h"
#include "arpc/RPCInterface.h"
#include "arpc/ANetRPCChannelManager.h"
#include "arpc/ANetRPCChannel.h"
#include "arpc/ANetRPCController.h"
#include "client_pool/ArpcClientPool.h"
#include "reco/bizc/proto_arpc/index_presort_server.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/thread/thread.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/time/timestamp.h"

using namespace google::protobuf;
using namespace std;
using namespace arpc;
using namespace arpc_client_pool::client_pool;
using namespace reco::presort;
using namespace base;
using namespace reco;
using ::Closure;

DEFINE_string(ips, "127.0.0.1", "");
DEFINE_int32(port, 20022, "");
DEFINE_int32(api, 0, "0-ha3 press");
DEFINE_int32(thread_num, 10, "");
DEFINE_int32(total_req, 100000, "");
DEFINE_int32(timeout, 100000, "ms");
DEFINE_int32(result_num, 1e6, "");

atomic_int g_succ_num;
atomic_int g_fail_num;
atomic_int g_total_req;
atomic_int g_total_rslt_size;
atomic_long g_rpc_time_usage;
atomic_ulong g_byte_size;

void ServerRpc(int i, ArpcClientPool<PresortService_Stub>* conn_pool,
               thread::BlockingQueue<int64>* channel_que);
void QpsCalc();


int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "presort server press client.");

  std::vector<std::string> ips_vec;
  base::SplitString(FLAGS_ips, ",", &ips_vec);
  if (ips_vec.size() == 0) {
    cout << "invalid ha3 ips." << endl;
    return -1;
  }

  PoolParams params;
  params.clientCount = FLAGS_thread_num * (int)ips_vec.size();

  std::set<StubInfo> stub_info;
  for (const auto& ip : ips_vec) {
    stub_info.insert(StubInfo(ip, FLAGS_port));
  }

  ArpcClientPool<PresortService_Stub> conn_pool;
  if (!conn_pool.init(params, stub_info)) {
    cout << "conn pool init failed." << endl;
    return -1;
  }

  // get channels as test data
  auto stub_ptr = conn_pool.get();
  ANetRPCController cntler;
  GetChnAndCateRequest req;
  GetChnAndCateResponse resp;

  req.set_return_channel(true);
  req.set_return_category(true);
  stub_ptr->stub()->GetChannelAndCategory(&cntler, &req, &resp, NULL);

  int err_code = cntler.GetErrorCode();
  if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
    cout << "rpc error." << endl;
    return -1;
  }
  cout << "fetched channel size:" << resp.channels_size() << endl;

  thread::BlockingQueue<int64> channel_que;
  for (int j = 0; j < FLAGS_thread_num; j++) {
    for (int i = 0; i < resp.channels_size(); i++) {
      channel_que.Put(resp.channels(i));
    }
  }
  cout << "gen queue size:" << channel_que.Size() << endl;

  g_total_req = 0;

  thread::ThreadPool thread_pool(FLAGS_thread_num);
  for (int i = 0; i < FLAGS_thread_num; i++) {
    thread_pool.AddTask(::NewCallback(&ServerRpc, i, &conn_pool, &channel_que));
  }

  thread::Thread qps_thread;
  qps_thread.Start(::NewCallback(&QpsCalc));

  thread_pool.JoinAll();
  qps_thread.Join();

  return 0;
}

void QpsCalc() {
  g_succ_num = 0;
  g_fail_num = 0;
  int64 start_ts = base::GetTimestamp();
  const int interval_s = 2;

  int last_succ_num = 0, last_fail_num = 0, now_succ_num = 0, now_fail_num = 0, last_rslt_size = 0;
  int last_time_usage = 0;
  uint64 last_byte_size = 0;
  while (g_total_req < FLAGS_total_req) {
    last_succ_num = now_succ_num;
    last_fail_num = now_fail_num;
    last_rslt_size = g_total_rslt_size;
    last_time_usage = g_rpc_time_usage;
    last_byte_size = g_byte_size;
    base::SleepForSeconds(interval_s);

    now_succ_num = g_succ_num;
    now_fail_num = g_fail_num;
    cout << "succ num:" << now_succ_num << " delta:" << now_succ_num - last_succ_num
         << " qps:" << (now_succ_num - last_succ_num) / interval_s
         << " fail num:" << now_fail_num << " delta:" << now_fail_num - last_fail_num
         << " qps:" << (now_fail_num - last_fail_num) / interval_s
         << " rslt size delta:" << g_total_rslt_size - last_rslt_size
         << " byte size MB/s:" << (g_byte_size - last_byte_size) / 1048576.0 / interval_s
         << " avg rpc time ms:" << (g_rpc_time_usage - last_time_usage) / (now_succ_num - last_succ_num + 1) << endl;
  }

  int64 time_delta_s = (base::GetTimestamp() - start_ts) / 1e6;
  cout << "total succ num:" << g_succ_num << " qps:" << g_succ_num / time_delta_s
       << " total fail num:" << g_fail_num << " qps:" << g_fail_num / time_delta_s
       << " total qps:" << (g_succ_num + g_fail_num) / time_delta_s
       << " total rslt size:" << g_total_rslt_size << " qps:" << g_total_rslt_size / time_delta_s
       << " byte size MB/s:" << g_byte_size / 1048576.0 / time_delta_s 
       << " total rpc avg time ms:" << g_rpc_time_usage / g_succ_num;
}

void ServerRpc(int i, ArpcClientPool<PresortService_Stub>* conn_pool,
               thread::BlockingQueue<int64>* channel_que) {
  while (g_total_req < FLAGS_total_req) {
    int64 channel_id = channel_que->Take();
    std::string query = StringPrintf("special_index:CN_%ld", channel_id);

    auto stub_ptr = conn_pool->get();
    ANetRPCController cntler;
    QueryHa3Request req;
    QueryHa3Response resp;

    cntler.SetExpireTime(FLAGS_timeout);
    req.set_query_clause(query);
    req.set_result_num(FLAGS_result_num);

    int64 start_ts = base::GetTimestamp();
    stub_ptr->stub()->QueryHa3(&cntler, &req, &resp, NULL);

    int err_code = cntler.GetErrorCode();
    if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
      cout << "thread:" << i << " chn:" << channel_id << " rpc failed, msg:" << cntler.ErrorText() << endl;
      g_fail_num++;
    } else {
      int64 tu = (base::GetTimestamp() - start_ts) / 1e3;
      g_rpc_time_usage += tu;
      g_succ_num++;
      g_total_rslt_size += resp.item_info_size();
      g_byte_size += resp.ByteSize();
    }
    if (resp.item_info_size() >= FLAGS_result_num) {
      channel_que->Put(channel_id);
    } else if (channel_que->Size() <= FLAGS_thread_num) {
      channel_que->Put(channel_id);
    } else {
      ;
    }

    g_total_req++;
  }
}

