#include <google/protobuf/stubs/common.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "arpc/CommonMacros.h"
#include "arpc/RPCInterface.h"
#include "arpc/ANetRPCChannelManager.h"
#include "arpc/ANetRPCChannel.h"
#include "arpc/ANetRPCController.h"
#include "reco/bizc/proto_arpc/index_presort_server.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/base.h"
#include "base/common/gflags.h"

using namespace google::protobuf;
using namespace std;
using namespace arpc;
using namespace reco::presort;
using namespace reco::presort;
using namespace base;
using namespace reco;

DEFINE_string(ip, "127.0.0.1", "");
DEFINE_int32(port, 20022, "");

DEFINE_int32(reco_type, 255, "");
DEFINE_string(query, "special_index:A_uc_br_op", "");
DEFINE_string(output_filepath, "output", "output");
DEFINE_int32(result_num, 10, "");
DEFINE_int32(need_attr, 0, "");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "presort server client.");

  ANetRPCChannelManager rpcChannelManager;
  rpcChannelManager.StartPrivateTransport();
  string spec = StringPrintf("tcp:%s:%d", FLAGS_ip.c_str(), FLAGS_port);
  RPCChannel *pChannel = rpcChannelManager.OpenChannel(spec.c_str());
  if (pChannel == NULL) {
    cerr << "open channel on " << spec << " failed" << endl;
    return -1;
  }

  PresortService::Stub stub(pChannel, Service::STUB_OWNS_CHANNEL);
  GetDefaultRecoRequest req;
  GetDefaultRecoResponse resp;

  req.set_reco_type(static_cast<RecoType>(FLAGS_reco_type));
  req.set_result_num(FLAGS_result_num);
  if (FLAGS_reco_type == kTestReco) {
    req.set_clause(FLAGS_query);
  } else if (FLAGS_reco_type == kCategoryReco || FLAGS_reco_type == kVideoCategoryReco) {
    Category* cate = req.mutable_category();
    cate->set_level(0);
    cate->set_category(FLAGS_query);
  } else if (FLAGS_reco_type == kChannelReco || FLAGS_reco_type == kVideoChannelReco) {
    int64 channel_id; 
    if (StringToInt64(string(FLAGS_query), &channel_id)){
      req.set_channel_id(channel_id);
    } else {
      cerr << "channel_id error" << endl;
    }
  }

  cout << "req complete:" << req.IsInitialized() << endl;
  cout << "req:" << req.Utf8DebugString() << endl;

  RPCController* cntler = new ANetRPCController;
  stub.GetDefaultReco(cntler, &req, &resp, NULL);

  if (cntler->Failed()) {
    cerr << cntler->ErrorText() << endl;
  }

  //cout << resp.Utf8DebugString() << endl;
  ofstream   ofresult;
  ofresult.open(FLAGS_output_filepath, ios::out);
  for ( int i=0; i < resp.item_info_size(); i++) {
    const PbItemInfo& item = resp.item_info(i);
    auto item_id = item.item_id();
    ofresult << "no="<< i << ",item_id=" << item_id << endl;
  }
}
