#include <google/protobuf/stubs/common.h>
#include <iostream>
#include <iomanip>
#include <string>
#include "arpc/CommonMacros.h"
#include "arpc/RPCInterface.h"
#include "arpc/ANetRPCChannelManager.h"
#include "arpc/ANetRPCChannel.h"
#include "arpc/ANetRPCController.h"
#include "reco/bizc/proto_arpc/index_presort_server.pb.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/time/timestamp.h"

using namespace google::protobuf;
using namespace std;
using namespace arpc;
using namespace reco::presort;
using namespace base;
using namespace reco;

DEFINE_string(ip, "127.0.0.1", "");
DEFINE_int32(port, 20022, "");
DEFINE_int32(api, 0, "0-reco, 1-query, 2-get channel, 3-debug");
DEFINE_bool(comp_mode, false, "");
DEFINE_bool(only_id, false, "");
DEFINE_int32(reco_type, 255, "");
DEFINE_string(category, "", "");
DEFINE_int64(channel_id, 0, "");
DEFINE_int64(region_id, 0, "");
DEFINE_string(clause, "", "");
DEFINE_string(term, "", "");
DEFINE_int32(result_num, 10, "");
DEFINE_uint64(item_id, 0, "");
DEFINE_int32(debug_type, 0, "");
DEFINE_int32(dict_type, 0, "");
DEFINE_int32(time_out, 3000, "");
DEFINE_int32(mining_sttg, 100, "");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "presort server client.");

  ANetRPCChannelManager rpcChannelManager;
  rpcChannelManager.StartPrivateTransport();
  string spec = StringPrintf("tcp:%s:%d", FLAGS_ip.c_str(), FLAGS_port);
  RPCChannel *pChannel = rpcChannelManager.OpenChannel(spec.c_str());
  if (pChannel == NULL) {
    cout << "open channel on " << spec << " failed" << endl;
    return -1;
  }

  PresortService::Stub stub(pChannel, Service::STUB_OWNS_CHANNEL);
  ANetRPCController cntler;
  cntler.SetExpireTime(FLAGS_time_out);
  if (FLAGS_api == 0) {
    GetDefaultRecoRequest req;
    GetDefaultRecoResponse resp;

    req.set_reco_type(static_cast<RecoType>(FLAGS_reco_type));
    Category* cate = req.mutable_category();
    cate->set_level(0);
    cate->set_category(FLAGS_category);
    req.set_channel_id(FLAGS_channel_id);
    req.set_region_id(FLAGS_region_id);
    req.set_result_num(FLAGS_result_num);
    req.set_clause(FLAGS_clause);
    req.set_term(FLAGS_term);
    req.set_only_id(FLAGS_only_id);
    req.set_mining_strategy(FLAGS_mining_sttg);

    if (!FLAGS_comp_mode) {
      cout << "req complete:" << req.IsInitialized() << endl;
      cout << "req:" << req.Utf8DebugString() << endl;
    }

    stub.GetDefaultReco(&cntler, &req, &resp, NULL);
    if (FLAGS_comp_mode) {
      for (int i = 0; i < resp.item_info_size(); i++) {
        cout << "no=" << i << " item_id=" << resp.item_info(i).item_id()
                           << " index_score=" << resp.item_info(i).index_score()
                           << " time_level=" << resp.item_info(i).meta_info().time_level()
                           << " ctr=" << resp.item_info(i).meta_info().ctr()
                           << " predict_ctr=" << resp.item_info(i).meta_info().predict_ctr()
                           << " itemq=" << resp.item_info(i).meta_info().item_quality()
                           << " hot_level=" << resp.item_info(i).meta_info().hot_level()
                           << " site_level=" << resp.item_info(i).meta_info().site_level()
                           << " create_ts=" << resp.item_info(i).create_timestamp()
                           << std::endl;
      }
    } else {
      cout << "resp:\n" << resp.Utf8DebugString() << endl;
      cout << "result size:" << resp.item_info_size() << endl;
    }
  } else if (FLAGS_api == 1) {
    QueryHa3Request req;
    QueryHa3Response resp;

    req.set_query_clause(FLAGS_clause);
    req.set_result_num(FLAGS_result_num);
    cout << "req complete:" << req.IsInitialized() << endl;
    cout << "req:" << req.Utf8DebugString() << endl;

    int64 start_ts = base::GetTimestamp();
    stub.QueryHa3(&cntler, &req, &resp, NULL);
    cout << "rpc time usage us:" << base::GetTimestamp() - start_ts << "\n" << "resp:\n" << resp.Utf8DebugString() << endl;
  } else if (FLAGS_api == 2) {
    GetChnAndCateRequest req;
    GetChnAndCateResponse resp;

    req.set_return_channel(true);
    req.set_return_category(true);
    req.set_return_term(true);
    cout << "req complete:" << req.IsInitialized() << endl;
    cout << "req:" << req.Utf8DebugString() << endl;

    stub.GetChannelAndCategory(&cntler, &req, &resp, NULL);
    cout << "resp:\n" << resp.Utf8DebugString() << endl;
    cout << "channel size:" << resp.channels_size() << " category size:" << resp.categories_size()
         << " term size:" << resp.terms_size() << endl;
  } else if (FLAGS_api == 3) {
    DebugRequest req;
    DebugResponse resp;

    req.set_debug_type((DebugType)FLAGS_debug_type);
    req.set_item_id(FLAGS_item_id);
    cout << "req complete:" << req.IsInitialized() << endl;
    cout << "req:" << req.Utf8DebugString() << endl;

    stub.Debug(&cntler, &req, &resp, NULL);
    cout << "resp:\n" << resp.Utf8DebugString() << endl;
  } else if (FLAGS_api == 4) {
    GetDictsRequest req;
    GetDictsResponse resp;

    req.set_dict_type((DictType)FLAGS_dict_type);
    cout << "req complete:" << req.IsInitialized() << endl;
    cout << "req:" << req.Utf8DebugString() << endl;

    stub.GetDicts(&cntler, &req, &resp, NULL);
    cout << "resp:\n" << resp.Utf8DebugString() << endl;
  }
  else {
    ;
  }

  if (cntler.Failed()) {
    cout << "rpc failed. msg:" << cntler.ErrorText() << endl;
  }
}
