#include <tuple>
#include "reco/serv/index_presort_server/frame/ha3_client.h"
#include "base/strings/string_split.h"
#include "base/thread/thread_pool.h"
#include "base/common/closure.h"

DEFINE_string(ha3_query_format, "&&cluster=xss_reco&&config=no_summary:yes,format:protobuf,proto_format_option:pb_matchdoc_format,timeout:1000,", "");
DEFINE_string(ha3_profile_format, "&&rank=rank_profile:RangeFilterProfile", "");
DEFINE_int32(ha3_cc_num_per_request, 10, "max concurrent num for one request");
DEFINE_int32(ha3_max_id_num_per_query, 5e5, "");
DEFINE_int32(ha3_max_rslt_num_per_query, 5000, "");
DEFINE_int32(ha3_conn_num_per_ip, 128, "");
DEFINE_int32(request_timeout, 1000, "ms");
DEFINE_int32(renew_thd, 600, "sec");
DEFINE_bool(force_renew, false, "fetch item info from ha3, regardless of cache");

DEFINE_int64_counter(ha3client, ha3_query_req, 0, "");
DEFINE_int64_counter(ha3client, ha3_query_time, 0, "");
DEFINE_int64_counter(ha3client, ha3_rpc_req, 0, "");
DEFINE_int64_counter(ha3client, ha3_rpc_req_fail, 0, "");
DEFINE_int64_counter(ha3client, ha3_rpc_time, 0, "");
DEFINE_int64_counter(ha3client, ha3_query_rslt_num, 0, "");
DEFINE_int64_counter(ha3client, ha3_query_need_upd_num, 0, "");

namespace reco {

Ha3Client::Ha3Client(const std::string& ha3ips, int ha3port, NewsIndex* news_index): connected_(false) {
  std::vector<std::string> ips;
  base::SplitString(ha3ips, ",", &ips);
  if (ips.size() == 0) {
    LOG(ERROR) << "invalid ha3 ips.";
    return;
  }
  LOG(INFO) << "ha3 client ip num:" << ips.size();

  PoolParams params;
  params.clientCount = FLAGS_ha3_conn_num_per_ip * (int)ips.size();

  std::set<StubInfo> stub_info;
  for (const auto& ip : ips) {
    if (ip.size() < strlen("0.0.0.0")) continue;
    stub_info.insert(StubInfo(ip, ha3port));
  }

  if (!conn_pool_.init(params, stub_info)) return;
  connected_ = true;

  std::string attr_clause = base::JoinStrings(HA3_ATTR, ",");
  attr_clause = "attribute=" + attr_clause;
  ha3_query_prefix_ = attr_clause + FLAGS_ha3_query_format;

  attr_clause = base::JoinStrings(HA3_BASIC_ATTR, ",");
  attr_clause = "attribute=" + attr_clause;
  ha3_basic_prefix_ = attr_clause + FLAGS_ha3_query_format;

  news_index_ = news_index;
}

Ha3Client::~Ha3Client() {
  connected_ = false;
}

bool Ha3Client::Ha3Rpc(const std::string& query_clause, ha3::PBResult* pb_rslt, bool only_basic) {
  auto stub_ptr = conn_pool_.get();
  if (!stub_ptr) {
    LOG(ERROR) << "get ha3 connection failed.";
    return false;
  }
  ANetRPCController cntler;
  ha3::QrsRequest req;
  ha3::QrsResponse resp;

  std::string query;
  if (only_basic) {
    query = ha3_basic_prefix_ + query_clause;
  } else {
    query = ha3_query_prefix_ + query_clause;
  }
  req.set_assembly_query(query);
  cntler.SetExpireTime(FLAGS_request_timeout);
  VLOG(1) << "ha3 query:" << query;

  int64 start_ts = base::GetTimestamp();
  stub_ptr->stub()->search(&cntler, &req, &resp, NULL);
  int64 tu = base::GetTimestamp() - start_ts;
  VLOG(1) << "Ha3Rpc time us:" << tu;
  COUNTERS_ha3client__ha3_rpc_time.Increase(tu);
  COUNTERS_ha3client__ha3_rpc_req.Increase(1);

  int err_code = cntler.GetErrorCode();
  if (cntler.Failed() || err_code != arpc::ARPC_ERROR_NONE) {
    LOG(ERROR) << "rpc failed. msg:" << cntler.ErrorText();
    stub_ptr->setErrorCode(err_code);
    COUNTERS_ha3client__ha3_rpc_req_fail.Increase(1);
    return false;
  }

  if (!resp.has_assembly_result() || resp.assembly_result().size() == 0) {
    LOG(ERROR) << "query ha3 failed. null result.";
    return false;
  }

  if (!pb_rslt->ParseFromString(resp.assembly_result())) {
    LOG(ERROR) << "pb result parse failed.";
    return false;
  }

  if (!pb_rslt->has_matchdocs()) {
    LOG(ERROR) << "pb result has no match docs. result content:" << pb_rslt->Utf8DebugString();
    return false;
  }

  return true;
}

bool Ha3Client::QueryHa3(const std::string& query_clause, const Ha3Option& option,
                         std::vector<ItemInfo>* result) {
  int64 start_ts = base::GetTimestamp();
  std::vector<std::pair<uint64, float> > rslt_item_ids;
  if (!DoHa3Query(query_clause, option, &rslt_item_ids)) return false;

  GetItemInfo(rslt_item_ids, result, option.only_basic);

  int64 tu = (base::GetTimestamp() - start_ts) / 1e3;
  COUNTERS_ha3client__ha3_query_time.Increase(tu);
  COUNTERS_ha3client__ha3_query_req.Increase(1);
  LOG(INFO) << "QueryHa3 reco query:" << query_clause.substr(0, 512) << " item id size:" << rslt_item_ids.size()
            << " result size:" << result->size() << " total time ms:" << tu;
  return true;
}

bool Ha3Client::QueryHa3(const std::string& query_clause, const Ha3Option& option,
                         std::vector<std::shared_ptr<ItemInfoIndex> >* result) {
  int64 start_ts = base::GetTimestamp();
  std::vector<std::pair<uint64, float> > rslt_item_ids;
  if (!DoHa3Query(query_clause, option, &rslt_item_ids)) return false;

  GetItemInfoIndex(rslt_item_ids, result);

  int64 tu = (base::GetTimestamp() - start_ts) / 1e3;
  COUNTERS_ha3client__ha3_query_time.Increase(tu);
  COUNTERS_ha3client__ha3_query_req.Increase(1);
  LOG(INFO) << "QueryHa3 query:" << query_clause.substr(0, 512) << " item id size:" << rslt_item_ids.size()
            << " result size:" << result->size() << " total time ms:" << tu;
  return true;
}

bool Ha3Client::DoHa3Query(const std::string& query_clause, const Ha3Option& option,
                           std::vector<std::pair<uint64, float>>* rslt_item_ids) {
  if (!connected_) return false;
  int64 start_ts = base::GetTimestamp();

  // NOTE: ARPC底层传输数据超过256M会导致链接断开，因此需要使用变动更新的方式

  // step 1: 获取查询的结果item id和改动时间戳，然后挑出需要更新的item id
  std::vector<uint64> need_upd_items;
  if (!GetNeedUpdateItemPks(query_clause, option.result_num, rslt_item_ids, &need_upd_items)) return false;

  // step 2: 获取需要更新的item的全部正排信息,为避免超时及提升效率，采用分段并发执行，
  int need_upd_num = (int)need_upd_items.size();
  if (need_upd_num == 0 || option.only_id) return true;
  COUNTERS_ha3client__ha3_query_rslt_num.Increase(rslt_item_ids->size());
  COUNTERS_ha3client__ha3_query_need_upd_num.Increase(need_upd_num);

  // 更新数量小于阈值，则不使用线程池更新，减少损耗
  std::string ha3_config = StringPrintf("start:0,hit:%d&&", option.result_num);
  if (need_upd_num <= FLAGS_ha3_max_rslt_num_per_query) {
    int start = 0;
    std::string pk_query = StringPrintf("query=pk:'%lu'", need_upd_items[start++]);
    for (int i = start; i < need_upd_num; i++) {
      pk_query += StringPrintf(" OR pk:'%lu'", need_upd_items[i]);
    }
    std::string query = ha3_config + pk_query;
    QueryHa3ThreadFunc(query);
  } else {
    int queried_num = 0;
    thread::ThreadPool thread_pool(FLAGS_ha3_cc_num_per_request);
    while ( queried_num < need_upd_num) {
      int start = queried_num;
      int end = std::min(queried_num + FLAGS_ha3_max_rslt_num_per_query, need_upd_num);

      std::string pk_query = StringPrintf("query=pk:'%lu'", need_upd_items[start++]);
      for (int i = start; i < end; i++) {
        pk_query += StringPrintf(" OR pk:'%lu'", need_upd_items[i]);
      }
      std::string query = ha3_config + pk_query;

      thread_pool.AddTask(::NewCallback(this, &Ha3Client::QueryHa3ThreadFunc, query));
      queried_num = end;
    }
    thread_pool.JoinAll();
  }

  LOG(INFO) << "DoHa3Query query:" << query_clause.substr(0, 512)
            << " get iteminfo time usage ms:" << (base::GetTimestamp() - start_ts) / 1e3;
  return true;
}

bool Ha3Client::GetNeedUpdateItemPks(const std::string& query_clause,
                                     int result_num,
                                     std::vector<std::pair<uint64, float> >* all_items,
                                     std::vector<uint64>* need_upd_items) {
  int64 start_ts = base::GetTimestamp();

  // 为提升可拓展性，id拉取也分段进行
  int query_times = result_num / FLAGS_ha3_max_id_num_per_query;
  if (result_num % FLAGS_ha3_max_id_num_per_query != 0) {
    query_times++;
  }
  std::vector<ha3::PBResult> pb_rslts(query_times);

  // 线程池消耗较大，只请求一次的时候不使用线程池
  if (query_times == 1) {
    // 短查询按时间排序
    std::string ha3_config = StringPrintf("start:0,hit:%d&&sort=-CREATE_TIMESTAMP&&", result_num);
    std::string query = ha3_config + query_clause;
    GetIdThreadFunc(query, &pb_rslts[0]);
  } else {
    int start_pos = 0;
    thread::ThreadPool thread_pool(FLAGS_ha3_cc_num_per_request);
    for (int i = 0; i < query_times; i++) {
      int hit_num = std::min(FLAGS_ha3_max_id_num_per_query, result_num - start_pos);

      // 硬编码，第一次请求使用老格式，以获取正确的候选文档数量
      std::string query;
      if (i == 0) {
        std::string ha3_config = StringPrintf("start:0,hit:%d&&", hit_num);
        query = ha3_config + query_clause;
      } else {
        std::string ha3_config = StringPrintf("start:0,hit:%d&&kvpairs=offset:%d,length:%d&&", hit_num, start_pos, hit_num);
        query = ha3_config + query_clause + FLAGS_ha3_profile_format;
      }

      thread_pool.AddTask(::NewCallback(this, &Ha3Client::GetIdThreadFunc, query, &pb_rslts[i]));
      start_pos += FLAGS_ha3_max_id_num_per_query;
    }
    thread_pool.JoinAll();
  }

  LOG(INFO) << "GetNeedUpdateItemPks query:" << query_clause.substr(0, 512)
            << " rpc time usage(ms):" << (base::GetTimestamp() - start_ts) / 1e3;

  // extract values
  uint32 ha3_candidate_size = 0;
  std::vector<std::tuple<uint64, float, uint64> > id_ts;
  id_ts.reserve(result_num);

  for (int idx = 0; idx < query_times; idx++) {
    if (!pb_rslts[idx].has_matchdocs()) continue;

    const ha3::PBMatchDocs& pb_docs = pb_rslts[idx].matchdocs();
    if (pb_docs.has_totalmatchdocs() && pb_docs.totalmatchdocs() > ha3_candidate_size){
      ha3_candidate_size = pb_docs.totalmatchdocs();
    }

    unordered_map<std::string, const google::protobuf::RepeatedField<int64>* > int_values;
    const google::protobuf::RepeatedField<double>* sort_values;

    for (int i = 0; i < pb_docs.int64attrvalues_size(); i++) {
      const ha3::PBInt64Attribute* attr = &pb_docs.int64attrvalues(i);
      int_values[attr->key()] = &attr->int64value();
    }
    sort_values = &(pb_docs.sortvalues().sortvalues());

    // inspect
    for(const auto& elem : int_values) {
      if (elem.second->size() != (int)pb_docs.nummatchdocs()) {
        LOG(ERROR) << "GetNeedUpdateItemPks error, int values size not equivalent.";
        return false;
      }
    }

    // get item id and update time
    for (uint32 i = 0; i < pb_docs.nummatchdocs(); i++) {
      uint64 item_id = static_cast<uint64>(int_values.at("ITEM_ID")->Get(i));
      uint64 update_ts = static_cast<uint64>(int_values.at("HA3_UPDATE_TIMESTAMP")->Get(i));
      float sort_value = static_cast<float>(sort_values->Get(i));
      id_ts.push_back(std::make_tuple(item_id, sort_value, update_ts));
    }
  }

  all_items->reserve(id_ts.size());
  need_upd_items->reserve(id_ts.size());
  for (const auto& tup : id_ts) {
    uint64 item_id = std::get<0>(tup);
    float sort_value = std::get<1>(tup);
    uint64 ha3_update_ts = std::get<2>(tup);

    all_items->push_back(std::make_pair(item_id, sort_value));

    if (FLAGS_force_renew) {
      need_upd_items->push_back(item_id);
    } else {
      uint64 update_ts = 0;
      int64 expire_remain = 0;
      if (!news_index_->GetHa3UpdateTsByItemId(item_id, &update_ts, &expire_remain)
          || ha3_update_ts > update_ts
          || expire_remain < FLAGS_renew_thd * 1e6) {
        need_upd_items->push_back(item_id);
      }
    }
  }

  LOG(INFO) << "GetNeedUpdateItemPks query:" << query_clause.substr(0, 512)
            << " total time usage ms:" << (base::GetTimestamp() - start_ts) / 1e3
            << " ha3 candidate size:" << ha3_candidate_size
            << " ha3 result size:" << id_ts.size()
            << " all item size:" << all_items->size()
            << " need update item size:" << need_upd_items->size();

  return true;
}

void Ha3Client::GetIdThreadFunc(std::string query_clause, ha3::PBResult* pb_rslt) {
  int64 start_ts = base::GetTimestamp();
  if (!Ha3Rpc(query_clause, pb_rslt, true)) {
    LOG(ERROR) << "GetIdThreadFunc rpc failed. clause:" << query_clause.substr(0, 512);
    return;
  }

  VLOG(1) << "GetIdThreadFunc query:" << query_clause
          << " ha3 result size:" << pb_rslt->matchdocs().nummatchdocs()
          << " time ms:" << (base::GetTimestamp() - start_ts) / 1e3;
}

void Ha3Client::QueryHa3ThreadFunc(std::string query_clause) {
  ha3::PBResult pb_rslt;
  if (!Ha3Rpc(query_clause, &pb_rslt, false)) {
    LOG(ERROR) << "QueryHa3ThreadFunc rpc failed. clause:" << query_clause;
    return;
  }

  std::vector<uint64> saved_item_ids;
  ParseHa3ResultAndSave(pb_rslt.matchdocs(), &saved_item_ids);

  VLOG(1) << "QueryHa3ThreadFunc ha3 candidates size:" << pb_rslt.matchdocs().totalmatchdocs()
          << " ha3 result size:" << pb_rslt.matchdocs().nummatchdocs()
          << " parsed result size:" << saved_item_ids.size();
}

bool Ha3Client::ParseHa3ResultAndSave(const ha3::PBMatchDocs& pb_docs, std::vector<uint64>* saved_item_ids) {
  unordered_map<std::string, const google::protobuf::RepeatedField<int64>* > int_values;
  unordered_map<std::string, const google::protobuf::RepeatedField<double>* > float_values;
  unordered_map<std::string, const google::protobuf::RepeatedPtrField<std::string>* > string_values;

  // extract values by attribute type;
  for (int i = 0; i < pb_docs.int64attrvalues_size(); i++) {
    const ha3::PBInt64Attribute* attr = &pb_docs.int64attrvalues(i);
    int_values[attr->key()] = &attr->int64value();
  }
  for (int i = 0; i < pb_docs.doubleattrvalues_size(); i++) {
    const ha3::PBDoubleAttribute* attr = &pb_docs.doubleattrvalues(i);
    float_values[attr->key()] = &attr->doublevalue();
  }
  for (int i = 0; i < pb_docs.bytesattrvalues_size(); i++) {
    const ha3::PBBytesAttribute* attr = &pb_docs.bytesattrvalues(i);
    string_values[attr->key()] = &attr->bytesvalue();
  }

  // inspect
  for(const auto& elem : int_values) {
    if (elem.second->size() != (int)pb_docs.nummatchdocs()) {
      LOG(ERROR) << "Ha3PbResult2ItemInfo error, int values size not equivalent.";
      return false;
    }
  }
  for(const auto& elem : float_values) {
    if (elem.second->size() != (int)pb_docs.nummatchdocs()) {
      LOG(ERROR) << "Ha3PbResult2ItemInfo error, float values size not equivalent.";
      return false;
    }
  }
  for(const auto& elem : string_values) {
    if (elem.second->size() != (int)pb_docs.nummatchdocs()) {
      LOG(ERROR) << "Ha3PbResult2ItemInfo error, string values size not equivalent."
                 << " key:" << elem.first
                 << " ha3result size:" << pb_docs.nummatchdocs()
                 << " field size:" << elem.second->size();
      return false;
    }
  }

  std::vector<uint64> item_ids;
  item_ids.reserve(pb_docs.nummatchdocs());
  for (int i = 0; i < (int)pb_docs.nummatchdocs(); i++) {
    item_ids.push_back(static_cast<uint64>(int_values.at("ITEM_ID")->Get(i)));
  }

  // save item info to index cache
  for (size_t i = 0; i < item_ids.size(); i++) {
    ItemInfoIndex* item = new ItemInfoIndex();
    item->item_id = item_ids[i];
    item->keyword_norm = static_cast<float>(float_values.at("KEYWORD_NORM")->Get(i));
    item->plsa_topic_norm = static_cast<float>(float_values.at("PLSA_TOPIC_NORM")->Get(i));
    item->semantic_tag_norm = static_cast<float>(float_values.at("SEMANTIC_TAG_NORM")->Get(i));
    item->tag_norm = static_cast<float>(float_values.at("TAG_NORM")->Get(i));
    item->topic_norm = static_cast<float>(float_values.at("TOPIC_NORM")->Get(i));
    item->video_black_edge_ratio = static_cast<float>(float_values.at("VIDEO_BLACK_EDGE_RATIO")->Get(i));
    item->wordvec_norm = static_cast<float>(float_values.at("WORDVEC_NORM")->Get(i));
    item->content_attr = static_cast<int>(int_values.at("CONTENT_ATTR")->Get(i));
    item->content_length = static_cast<int>(int_values.at("CONTENT_LENGTH")->Get(i));
    item->crawl_timestamp = static_cast<uint64>(int_values.at("CRAWL_TIMESTAMP")->Get(i));
    item->create_timestamp = static_cast<uint64>(int_values.at("CREATE_TIMESTAMP")->Get(i));
    item->docmask = static_cast<int>(int_values.at("DocMask")->Get(i));
    item->expire_timestamp = int_values.at("EXPIRE_TIMESTAMP")->Get(i);
    item->has_video_storage_info = static_cast<int>(int_values.at("HAS_VIDEO_STORAGE_INFO")->Get(i));
    item->image_count = static_cast<int>(int_values.at("IMAGE_COUNT")->Get(i));
    item->item_has_reviewed = static_cast<int>(int_values.at("ITEM_HAS_REVIEWED")->Get(i));
    item->item_is_yuanchuang = static_cast<int>(int_values.at("ITEM_IS_YUANCHUANG")->Get(i));
    item->item_type = static_cast<int>(int_values.at("ITEM_TYPE")->Get(i));
    item->jingpin_score = static_cast<int>(int_values.at("JINGPIN_SCORE")->Get(i));
    item->novel_update_time = static_cast<int>(int_values.at("NOVEL_UPDATE_TIME")->Get(i));
    item->paragraph_num = static_cast<int>(int_values.at("PARAGRAPH_NUM")->Get(i));
    item->popularity = static_cast<int>(int_values.at("POPULARITY")->Get(i));
    item->posterior_item_q = static_cast<int>(int_values.at("POSTERIOR_ITEM_Q")->Get(i));
    item->publish_time = static_cast<int>(int_values.at("PUBLISH_TIME")->Get(i));
    item->term_feature_version = static_cast<int>(int_values.at("TERM_FEATURE_VERSION")->Get(i));
    item->title_length = static_cast<int>(int_values.at("TITLE_LENGTH")->Get(i));
    item->ucbr_style_type = static_cast<int>(int_values.at("UCBR_STYLE_TYPE")->Get(i));
    item->video_count = static_cast<int>(int_values.at("VIDEO_COUNT")->Get(i));
    item->video_length = static_cast<int>(int_values.at("VIDEO_LENGTH")->Get(i));
    item->video_quality_level = static_cast<int>(int_values.at("VIDEO_QUALITY_LEVEL")->Get(i));
    item->video_storage_info_status = static_cast<int>(int_values.at("VIDEO_STORAGE_INFO_STATUS")->Get(i));
    item->video_vulgar_level = static_cast<int>(int_values.at("VIDEO_VULGAR_LEVEL")->Get(i));
    item->app_token = string_values.at("APP_TOKEN")->Get(i);
    item->image_hash = string_values.at("IMAGE_HASH")->Get(i);
    item->item_subscripts = string_values.at("ITEM_SUBSCRIPTS")->Get(i);
    item->keyword_feature_list = string_values.at("KEYWORD_FEATURE_LIST")->Get(i);
    item->keyword_list = string_values.at("KEYWORD_LIST")->Get(i);
    item->novel_id = string_values.at("NOVEL_ID")->Get(i);
    item->orig_source_media = string_values.at("ORIG_SOURCE_MEDIA")->Get(i);
    item->orig_source = string_values.at("ORIG_SOURCE")->Get(i);
    item->outer_id = string_values.at("OUTER_ID")->Get(i);
    item->paragraph_hash = string_values.at("PARAGRAPH_HASH")->Get(i);
    item->plsa_topic_feature_list = string_values.at("PLSA_TOPIC_FEATURE_LIST")->Get(i);
    item->plsa_topic_list = string_values.at("PLSA_TOPIC_LIST")->Get(i);
    item->raw_summary = string_values.at("RAW_SUMMARY")->Get(i);
    item->region_from_title = string_values.at("REGION_FROM_TITLE")->Get(i);
    item->region_restrict = string_values.at("REGION_RESTRICT")->Get(i);
    item->region = string_values.at("REGION")->Get(i);
    item->semantic_tag_feature_list = string_values.at("SEMANTIC_TAG_FEATURE_LIST")->Get(i);
    item->semantic_tag_list = string_values.at("SEMANTIC_TAG_LIST")->Get(i);
    item->sim_feature = string_values.at("SIM_FEATURE")->Get(i);
    item->sim_hash = string_values.at("SIM_HASH")->Get(i);
    item->source_media = string_values.at("SOURCE_MEDIA")->Get(i);
    item->source = string_values.at("SOURCE")->Get(i);
    item->tag_feature_list = string_values.at("TAG_FEATURE_LIST")->Get(i);
    item->tag_list = string_values.at("TAG_LIST")->Get(i);
    item->term_feature_bytes = static_cast<int>(int_values.at("TERM_FEATURE_BYTES")->Get(i));
    item->topic_feature_list = string_values.at("TOPIC_FEATURE_LIST")->Get(i);
    item->topic_list = string_values.at("TOPIC_LIST")->Get(i);
    item->ucb_editor_name = string_values.at("UCB_EDITOR_NAME")->Get(i);
    item->wemedia_person = string_values.at("WEMEDIA_PERSON")->Get(i);
    item->wordvec_feature_list = string_values.at("WORDVEC_FEATURE_LIST")->Get(i);
    item->wordvec_list = string_values.at("WORDVEC_LIST")->Get(i);
    item->youku_video_id = string_values.at("YOUKU_VIDEO_ID")->Get(i);
    item->priority = string_values.at("PRIORITY")->Get(i);
    item->special_contain_item_list = string_values.at("SPECIAL_CONTAIN_ITEM_LIST")->Get(i);
    item->special_prevew_item_list = string_values.at("SPECIAL_PREVEW_ITEM_LIST")->Get(i);
    item->video_poster_problem_info = string_values.at("VIDEO_POSTER_PROBLEM_INFO")->Get(i);
    item->category = string_values.at("CATEGORY")->Get(i);
    item->channel = string_values.at("CHANNEL")->Get(i);
    item->item_event_tag = string_values.at("ITEM_EVENT_TAG")->Get(i);
    item->item_show_tag = string_values.at("ITEM_SHOW_TAG")->Get(i);
    item->gaode_poi = string_values.at("GAODE_POI")->Get(i);
    item->item_quality_attr = string_values.at("ITEM_QUALITY_ATTR")->Get(i);
    item->time_axis_results = string_values.at("TIME_AXIS_RESULTS")->Get(i);
    item->ucbr_deliver = string_values.at("UCBR_DELIVER")->Get(i);
    item->category_candidates = string_values.at("CATEGORY_CANDIDATES")->Get(i);
    item->title = string_values.at("TITLE")->Get(i);
    item->anchor = string_values.at("ANCHOR")->Get(i);
    item->query = string_values.at("QUERY")->Get(i);
    item->bid_word = string_values.at("BID_WORD")->Get(i);
    item->content = string_values.at("CONTENT")->Get(i);
    item->orig_media_risk_type = static_cast<int>(int_values.at("ORIG_MEDIA_RISK_TYPE")->Get(i));
    item->manual_news = static_cast<int>(int_values.at("MANUAL_NEWS")->Get(i));
    item->youku_audit_status = string_values.at("YOUKU_AUDIT_STATUS")->Get(i);
    item->ha3_update_timestamp = static_cast<uint64>(int_values.at("HA3_UPDATE_TIMESTAMP")->Get(i));
    item->item_event_tag_info = string_values.at("ITEM_EVENT_TAG_INFO")->Get(i);
    item->video_play_control = string_values.at("VIDEO_PLAY_CONTROL")->Get(i);
    item->youku_show_id = string_values.at("YOUKU_SHOW_ID")->Get(i);
    item->subject_sub_items = string_values.at("SUBJECT_SUB_ITEMS")->Get(i);
    item->group_info = string_values.at("GROUP_INFO")->Get(i);
    item->local_breaking = string_values.at("LOCAL_BREAKING")->Get(i);
    item->title_lda_topic_list = string_values.at("TITLE_LDA_TOPIC_LIST")->Get(i);
    item->title_lda_topic_feature_list = string_values.at("TITLE_LDA_TOPIC_FEATURE_LIST")->Get(i);
    item->title_lda_topic_norm = static_cast<float>(float_values.at("TITLE_LDA_TOPIC_NORM")->Get(i));
    item->first_nscreen_filter = static_cast<int>(int_values.at("FIRST_NSCREEN_FILTER")->Get(i));
    item->app_token_bits = static_cast<int>(int_values.at("APP_TOKEN_BITS")->Get(i));
    item->app_token_rule_bits = string_values.at("APP_TOKEN_RULE_BITS")->Get(i);
    item->video_poster_clarity = static_cast<float>(float_values.at("VIDEO_POSTER_CLARITY")->Get(i));
    item->video_width = static_cast<int>(int_values.at("VIDEO_WIDTH")->Get(i));
    item->video_height = static_cast<int>(int_values.at("VIDEO_HEIGHT")->Get(i));
    item->video_colors = static_cast<int>(int_values.at("VIDEO_COLORS")->Get(i));

    news_index_->WriteItemInfoIndex(item);
  }

  // collect new channel and category
  CollectChannel(string_values.at("CHANNEL"));
  CollectCategory(string_values.at("CATEGORY"));
  CollectTerm(string_values.at("ITEM_SHOW_TAG"));

  saved_item_ids->swap(item_ids);
  return true;
}

void Ha3Client::GetItemInfo(const std::vector<std::pair<uint64, float> >& item_ids,
                            std::vector<ItemInfo>* result, bool only_basic) {
  result->clear();
  result->reserve(item_ids.size());

  for (const auto& pair : item_ids) {
    ItemInfo item_info;
    if (news_index_->GetItemInfoByItemId(pair.first, &item_info, only_basic)) {
      item_info.ha3_sort_value = pair.second;
      result->push_back(item_info);
    }
  }
}

void Ha3Client::GetItemInfoIndex(const std::vector<std::pair<uint64, float> >& item_ids,
                                 std::vector<std::shared_ptr<ItemInfoIndex> >* result) {
  result->clear();
  result->reserve(item_ids.size());

  for (const auto& pair : item_ids) {
    auto item = news_index_->GetItemInfoIndexByItemId(pair.first);
    if (item) {
      result->push_back(item);
    }
  }
}

void Ha3Client::CollectChannel(const google::protobuf::RepeatedPtrField<std::string>* channels) {
  for (int i = 0; i < channels->size(); i++) {
    if (channels->Get(i).empty()) continue;

    std::vector<std::string> flds;
    base::SplitString(channels->Get(i), "\t", &flds);
    int64 channel_id;
    for (int j = 0; j < (int)flds.size(); ++j) {
      if (!base::StringToInt64(flds[j], &channel_id)) {
        LOG(ERROR) << "CollectChannel error channel id: " << flds[j];
        continue;
      }
      channel_collection_.insert(channel_id);
    }
  }
}

void Ha3Client::CollectCategory(const google::protobuf::RepeatedPtrField<std::string>* categories) {
  for (int i = 0; i < categories->size(); i++) {
    if (categories->Get(i).empty()) continue;

    std::vector<std::string> cate_fields;
    base::SplitString(categories->Get(i), "\t", &cate_fields);
    for (size_t j = 0; j < cate_fields.size(); j++) {
      reco::Category category;
      news_index_->ConvertToCategoryProto(cate_fields, j, &category);
      category_collection_.insert(common::WrappedCategory(category));
    }
  }
}

void Ha3Client::CollectTerm(const google::protobuf::RepeatedPtrField<std::string>* terms) {
  for (int i = 0; i < terms->size(); i++) {
    if (terms->Get(i).empty()) continue;

    std::vector<std::string> term_fields;
    base::SplitString(terms->Get(i), "|", &term_fields);
    for (const auto& elem : term_fields) {
      if (elem.empty()) continue;
      std::string term = common::GetTagPayloadTerm(elem);
      thread::AutoLock auto_lock(&collection_lock_);
      term_collection_.insert(term);
    }
  }
}

}  // namespace
