#include "reco/serv/index_presort_server/frame/global_data.h"
#include "reco/bizc/common/item_level_define.h"
#include "base/common/closure.h"
#include "reco/bizc/poi/city_area_hash_dict.h"
#include "serving_base/utility/timer.h"
#include "reco/bizc/region/region_dict.h"

DEFINE_string(index_dir, "../dynamic_index/", "");
DEFINE_string(data_dir, "../data", "");

DEFINE_string(ha3_clusterA_ips, "", "split by ,");
DEFINE_string(ha3_clusterB_ips, "", "split by ,");
DEFINE_int32(ha3port, 8827, "");

DEFINE_int32(cache_expire_time, 600, "sec");
DEFINE_int32(cache_block_num, 1000, "");
DEFINE_string(init_categories, "", "only level 0 category");

namespace reco {
DECLARE_bool(use_app_token_item_filter);
namespace presort {

const std::string kSourceFile = "source_info.data";
const std::string kRegionDictFile = "city_code.txt";

GlobalData::GlobalData() {
}

void GlobalData::Init() {
  serving_base::Timer tm;
  tm.Start();

  reco::dm::DictManagerSingleton::instance().LoadAllDicts();
  DynamicDictContainer::RegisterAndLoadAllDict();
  CHECK(reco::poi::CityAreaHashSearcher::instance().Load(FLAGS_data_dir));

  index_wrapper_ = new reco::NewsIndex(FLAGS_cache_expire_time, FLAGS_cache_block_num);
  ha3_client_ = new Ha3Client(FLAGS_ha3_clusterA_ips + "," + FLAGS_ha3_clusterB_ips,
                              FLAGS_ha3port, index_wrapper_);
  index_wrapper_->SetHa3Client(ha3_client_);

  sim_item_ = new reco::SimItem();
  meta_updator_ = new reco::MetaInfoUpdator(index_wrapper_, sim_item_);
  source_manager_ = new SourceManager();
  video_stat_info_updator_ = new VideoStatInfoUpdator(index_wrapper_);

  std::vector<std::string> init_categories;
  base::SplitString(FLAGS_init_categories, ",", &init_categories);
  for (const auto& cate : init_categories) {
    category_pool_.insert(common::WrappedCategory(cate));
  }
  LOG(INFO) << "GlobalData new obj time us:" << tm.Interval();

  base::FilePath index_dir(FLAGS_index_dir);
  thread::Thread load_meta_thread;
  load_meta_thread.Start(NewCallback<MetaInfoUpdator, const base::FilePath&>
                                    (meta_updator_, &MetaInfoUpdator::Start, index_dir));
  sim_item_->Start();
  load_meta_thread.Join();
  index_wrapper_->SetMetaInfoUpdator(meta_updator_);
  LOG(INFO) << "GlobalData load sim&meta time us:" << tm.Interval();

  if (FLAGS_use_app_token_item_filter) {
    app_token_filter_map_ = std::make_shared<ExpiryMap<uint64, AppTokenFilterSt>>(
            FLAGS_cache_expire_time, FLAGS_cache_block_num);
  }
  // 等meta和sim信息加载完毕之后再初始化sort item模块
  sort_item_ = new SortItem(index_wrapper_, sim_item_, source_manager_, ha3_client_);
  sort_item_->BuildMiningStrategyItemDict();

  collect_task_thread_.Start(NewCallback(this, &GlobalData::CollectTasksThreadFunc));

  // 一些不需要立刻用到数据用异步加载，以提升端口打开速度
  init_thread_.Start(NewCallback(this, &GlobalData::InitThreadFunc));
}

void GlobalData::InitThreadFunc() {
  int64 ts = base::GetTimestamp();
  LOG(INFO) << "GlobalData init thread start";

  base::FilePath base_dir(FLAGS_data_dir);
  base::FilePath region_map_file = base_dir.Append(kRegionDictFile);
  CHECK(reco::common::RegionSearcher::instance().Load(region_map_file.ToString()));

  video_stat_info_updator_->Start();
  source_manager_->StartMonitorFile(base::FilePath(FLAGS_index_dir).Append(kSourceFile));

  LOG(INFO) << "GlobalData init thread end, time usage:" << base::GetTimestamp() - ts;
}

GlobalData::~GlobalData() {
  closing_ = true;
  init_thread_.Join();
  collect_task_thread_.Join();

  delete index_wrapper_;
  delete ha3_client_;
  delete sim_item_;
  delete meta_updator_;
  delete sort_item_;
  delete video_stat_info_updator_;
}

void GlobalData::CollectTasks(const GetDefaultRecoRequest* request) {
  CollectSt clt(request->reco_type());

  if (clt.reco_type == kCategoryReco || clt.reco_type == kVideoCategoryReco) {
    // clt.category = common::WrappedCategory(request->category()).ToString();
    return;
  } else if (clt.reco_type == kChannelReco || clt.reco_type == kVideoChannelReco) {
    // clt.channel_id = request->channel_id();
    return;
  } else if (clt.reco_type == kTermReco) {
    clt.term = request->term();
  } else {
    return;
  }
  collect_req_que_.Put(clt);
}

void GlobalData::CollectTasksThreadFunc() {
  while (!closing_) {
    auto clt = collect_req_que_.Take();

    if (clt.reco_type == kCategoryReco || clt.reco_type == kVideoCategoryReco) {
      thread::AutoLock pool_lock(&pool_mutex_);
      category_pool_.insert(common::WrappedCategory(clt.category));
    } else if (clt.reco_type == kChannelReco || clt.reco_type == kVideoChannelReco) {
      thread::AutoLock pool_lock(&pool_mutex_);
      channel_pool_.insert(clt.channel_id);
    } else if (clt.reco_type == kTermReco) {
      thread::AutoLock pool_lock(&term_mutex_);
      term_pool_.insert(clt.term);
    } else {
      ;
    }
  }
}

void GlobalData::UpdateCateAndChnPool() {
  auto channel_cl = ha3_client_->GetChannelCollection();
  auto category_cl = ha3_client_->GetCategoryCollection();
  auto term_cl = ha3_client_->GetTermCollection();

  LOG(INFO) << "channel collection current size:" << channel_cl.size();
  LOG(INFO) << "category collection current size:" << category_cl.size();
  LOG(INFO) << "term collection current size:" << term_cl.size();

  thread::AutoLock pool_lock(&pool_mutex_);
  thread::AutoLock term_lock(&term_mutex_);
  channel_pool_.insert(channel_cl.begin(), channel_cl.end());
  category_pool_.insert(category_cl.begin(), category_cl.end());
  term_pool_.insert(term_cl.begin(), term_cl.end());
}

}  // namespace
}  // namespace
