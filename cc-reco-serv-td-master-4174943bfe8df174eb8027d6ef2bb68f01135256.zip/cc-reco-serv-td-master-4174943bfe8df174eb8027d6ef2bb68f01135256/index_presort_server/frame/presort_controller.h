#pragma once

#include "reco/bizc/proto_arpc/index_presort_server.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/serv/index_presort_server/frame/ha3_client.h"

namespace reco {
namespace presort {

// declare
class GlobalData;

class PresortController {
 public:
  PresortController();
  ~PresortController();

  static void ItemInfo2Pb(const ItemInfo& item_info, PbItemInfo* pb_item);
  static void ItemInfoIndex2Pb(const ItemInfoIndex& item_info_index, PbItemInfoIndex* pb_item);

  bool ProcessRecoRequest(const GetDefaultRecoRequest* request, GetDefaultRecoResponse* response);
  bool QueryHa3(const QueryHa3Request* request, QueryHa3Response* response);
  bool GetChannelAndCategory(const GetChnAndCateRequest* request, GetChnAndCateResponse* response);
  bool GetWeMediaItemsDict(const GetWemediaDictRequest* request, GetWemediaDictResponse* response);
  bool GetLatestNews(const GetLatestNewsRequest* request, GetLatestNewsResponse* response);

 private:
  bool GenRecoResponse(const std::vector<ItemInfo>* item_vec,
                       const GetDefaultRecoRequest* request, GetDefaultRecoResponse* response);
  bool GenQueryResponse(const std::vector<std::shared_ptr<ItemInfoIndex> >& item_vec,
                        QueryHa3Response* response);
  static void BitsetToString(std::shared_ptr<boost::dynamic_bitset<uint8>> app_rule_mask,
                      std::string* value);

  Ha3Client* ha3_client_;
};


}  // namespace
}  // namespace
