#pragma once
#include <atomic>
#include <unordered_map>
#include <algorithm>
#include <utility>
#include <functional>

#include "base/thread/thread.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/time/timestamp.h"
#include "base/thread/rw_mutex.h"

namespace reco {

// unorderde_map的封装,增加读写锁和分块管理
template<class K, class V, class Hash = std::hash<K> >
class ExpiryMap {
 public:
  ExpiryMap(int32 expire_in_seconds = 0, int cache_block_num = 1) {
    cache_block_num_ = cache_block_num;

    mutexes_.reserve(cache_block_num_);
    maps_.reserve(cache_block_num_);
    for (int i = 0; i < cache_block_num_; i++) {
      mutexes_.push_back(std::make_shared<thread::RWMutex>());
      maps_.push_back(std::unordered_map<K, V>());
    }
  }

  ~ExpiryMap() {
  }

  bool FindSilently(K key, V* val = NULL) const {
    int block_id = CalcBlockId(key);
    thread::ReaderAutoLock lock(mutexes_[block_id].get());
    auto it = maps_[block_id].find(key);
    if (it == maps_[block_id].end()) return false;
    if (val) {
      *val = it->second;
    }
    return true;
  }

  void Add(const K& key, const V& val) {
    int block_id = CalcBlockId(key);
    thread::WriterAutoLock lock(mutexes_[block_id].get());
    maps_[block_id][key] = val;
  }

  void Add(const K& key, const V&& val) {
    int block_id = CalcBlockId(key);
    thread::WriterAutoLock lock(mutexes_[block_id].get());
    maps_[block_id][key] = val;
  }

  void BatchAdd(const std::vector<K>& keys, const std::vector<V>& vals) {

  }

  int64 Size() const {
    int64 sz = 0;
    for (const auto& elem : maps_){
      sz += elem.size();
    }
    return sz;
  }

 private:
  inline int CalcBlockId(K key) const {
    static Hash gen_hash;
    return gen_hash(key) % cache_block_num_;
  }

 private:
  int cache_block_num_;
  mutable std::vector<std::shared_ptr<thread::RWMutex> > mutexes_;
  std::vector<std::unordered_map<K, V> > maps_;
};

}  // namespace
