#pragma once

#include "reco/bizc/proto_arpc/index_presort_server.pb.h"
#include "serving_base/utility/system_util.h"
#include "base/thread/blocking_queue.h"
#include "reco/serv/index_presort_server/frame/presort_controller.h"
#include "reco/base/request_manager/request_manager_7u.h"

namespace reco {
namespace presort {

class PresortImpl : public PresortService {
 public:
  PresortImpl();
  virtual ~PresortImpl();

  virtual void GetDefaultReco(::google::protobuf::RpcController* controller,
                              const GetDefaultRecoRequest* request,
                              GetDefaultRecoResponse* response,
                              ::google::protobuf::Closure* done);
  void GetDefaultReco_(const GetDefaultRecoRequest* request,
                       GetDefaultRecoResponse* response,
                       ::google::protobuf::Closure* done);

  virtual void QueryHa3(::google::protobuf::RpcController* controller,
                        const QueryHa3Request* request,
                        QueryHa3Response* response,
                        ::google::protobuf::Closure* done);
  void QueryHa3_(const QueryHa3Request* request,
                 QueryHa3Response* response,
                 ::google::protobuf::Closure* done);

  virtual void GetChannelAndCategory(::google::protobuf::RpcController* controller,
                                     const GetChnAndCateRequest* request,
                                     GetChnAndCateResponse* response,
                                     ::google::protobuf::Closure* done);
  virtual void GetWeMediaItemsDict(::google::protobuf::RpcController* controller,
                                     const GetWemediaDictRequest* request,
                                     GetWemediaDictResponse* response,
                                     ::google::protobuf::Closure* done);
  virtual void GetLatestNews(::google::protobuf::RpcController* controller,
                                     const GetLatestNewsRequest* request,
                                     GetLatestNewsResponse* response,
                                     ::google::protobuf::Closure* done);
  virtual void GetDicts(::google::protobuf::RpcController* controller,
                        const GetDictsRequest* request,
                        GetDictsResponse* response,
                        ::google::protobuf::Closure* done);

  virtual void Debug(::google::protobuf::RpcController* controller,
                     const DebugRequest* request,
                     DebugResponse* response,
                     ::google::protobuf::Closure* done);

 private:
  std::shared_ptr<reco::common::RequestManager> req_manager_;
  thread::BlockingQueue<std::shared_ptr<PresortController> > controller_pool_;
};

}  // namespace presort
}  // namespace reco
