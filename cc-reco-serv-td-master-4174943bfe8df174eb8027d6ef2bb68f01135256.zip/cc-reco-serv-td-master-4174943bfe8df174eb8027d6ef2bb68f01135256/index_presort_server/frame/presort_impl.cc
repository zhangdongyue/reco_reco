#include "reco/base/common/auto_closure.h"
#include "reco/serv/index_presort_server/frame/presort_impl.h"
#include "reco/serv/index_presort_server/frame/global_data.h"
#include "base/common/logging.h"
#include "base/file/file_path.h"
#include "base/time/time.h"
#include "base/strings/string_util.h"

DEFINE_int32(worker_num, 128, "");
DEFINE_int64(request_time_out_ms, 2000, "");

DECLARE_uint64(debug_item_id);

DEFINE_int64_counter(presort, api_get_reco_req, 0, "");
DEFINE_int64_counter(presort, api_query_ha3_req, 0, "");
DEFINE_int64_counter(presort, api_query_ha3_succ, 0, "");
DEFINE_int64_counter(presort, api_query_ha3_time, 0, "");
DEFINE_int64_counter(presort, closure_run, 0, "");
DEFINE_int64_counter(presort, closure_runtime, 0, "");

namespace reco {
namespace presort {

PresortImpl::PresortImpl() {
  for (int i = 0; i < FLAGS_worker_num; i++) {
    controller_pool_.Put(std::make_shared<PresortController>());
  }

  req_manager_ = std::make_shared<reco::common::RequestManager>(FLAGS_worker_num, FLAGS_request_time_out_ms);

  // 高频请求接口加入队列管理
  req_manager_->RegisterReqFuncMap(new reco::common::ReqFuncMap<PresortImpl,
                                   GetDefaultRecoRequest,
                                   GetDefaultRecoResponse>(this, &PresortImpl::GetDefaultReco_));
  req_manager_->RegisterReqFuncMap(new reco::common::ReqFuncMap<PresortImpl,
                                   QueryHa3Request,
                                   QueryHa3Response>(this, &PresortImpl::QueryHa3_));
}

PresortImpl::~PresortImpl() {
}

void PresortImpl::GetDefaultReco(::google::protobuf::RpcController* controller,
                                 const GetDefaultRecoRequest* request,
                                 GetDefaultRecoResponse* response,
                                 ::google::protobuf::Closure* done) {
  req_manager_->AddReqTask(request, response, done);
}

void PresortImpl::GetDefaultReco_(const GetDefaultRecoRequest* request,
                                  GetDefaultRecoResponse* response,
                                  ::google::protobuf::Closure* done) {
  COUNTERS_presort__api_get_reco_req.Increase(1);
  AutoClosure auto_c(done);
  response->set_success(false);

  std::string req_str = base::StringReplace(request->Utf8DebugString(), "\n", " ", true).substr(0, 512);
  LOG(INFO) << "processing request:" << req_str;

  GlobalData::Instance().CollectTasks(request);

  auto cntler = controller_pool_.Take();
  if (!cntler) {
    LOG(ERROR) << "not enough controller!";
    return;
  }

  bool ret = cntler->ProcessRecoRequest(request, response);
  if (ret) {
    response->set_success(true);
  } else {
    LOG(ERROR) << "GetDefaultReco failed. req:" << req_str;
  }
  controller_pool_.Put(cntler);
}

void PresortImpl::QueryHa3(::google::protobuf::RpcController* controller,
                           const QueryHa3Request* request,
                           QueryHa3Response* response,
                           ::google::protobuf::Closure* done) {
  req_manager_->AddReqTask(request, response, done);
}

void PresortImpl::QueryHa3_(const QueryHa3Request* request,
                            QueryHa3Response* response,
                            ::google::protobuf::Closure* done) {
  COUNTERS_presort__api_query_ha3_req.Increase(1);
  int64 start_ts = base::GetTimestamp();
  AutoClosure auto_c(done);
  response->set_success(false);

  LOG(INFO) << "processing request:" << base::StringReplace(request->Utf8DebugString(), "\n", " ", true).substr(0, 512);

  auto cntler = controller_pool_.Take();
  if (!cntler) {
    LOG(ERROR) << "not enough controller!";
    return;
  }

  bool ret = cntler->QueryHa3(request, response);
  if (ret) {
    response->set_success(true);
    int64 tu = (base::GetTimestamp() - start_ts) / 1e3;
    LOG(INFO) << "QueryHa3 proc success, total time usage ms:" << tu;
    COUNTERS_presort__api_query_ha3_time.Increase(tu);
    COUNTERS_presort__api_query_ha3_succ.Increase(1);
  }
  controller_pool_.Put(cntler);
}

void PresortImpl::GetChannelAndCategory(::google::protobuf::RpcController* controller,
                                        const GetChnAndCateRequest* request,
                                        GetChnAndCateResponse* response,
                                        ::google::protobuf::Closure* done) {
  AutoClosure auto_c(done);
  response->set_success(false);

  LOG(INFO) << "processing request:" << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  auto cntler = controller_pool_.Take();
  if (!cntler) {
    LOG(ERROR) << "not enough controller!";
    return;
  }

  bool ret = cntler->GetChannelAndCategory(request, response);
  if (ret) {
    response->set_success(true);
  }
  controller_pool_.Put(cntler);
}

void PresortImpl::GetWeMediaItemsDict(::google::protobuf::RpcController* controller,
                                      const GetWemediaDictRequest* request,
                                      GetWemediaDictResponse* response,
                                      ::google::protobuf::Closure* done) {
  AutoClosure auto_c(done);
  response->set_success(false);

  LOG(INFO) << "processing request:" << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  auto cntler = controller_pool_.Take();
  if (!cntler) {
    LOG(ERROR) << "not enough controller!";
    return;
  }

  bool ret = cntler->GetWeMediaItemsDict(request, response);
  if (ret) {
    response->set_success(true);
  }
  controller_pool_.Put(cntler);
}

void PresortImpl::GetLatestNews(::google::protobuf::RpcController* controller,
                                const GetLatestNewsRequest* request,
                                GetLatestNewsResponse* response,
                                ::google::protobuf::Closure* done) {
  AutoClosure auto_c(done);
  response->set_success(false);

  LOG(INFO) << "processing request:" << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  auto cntler = controller_pool_.Take();
  if (!cntler) {
    LOG(ERROR) << "not enough controller!";
    return;
  }

  bool ret = cntler->GetLatestNews(request, response);
  if (ret) {
    response->set_success(true);
  }
  controller_pool_.Put(cntler);
}

void PresortImpl::GetDicts(::google::protobuf::RpcController* controller,
                           const GetDictsRequest* request,
                           GetDictsResponse* response,
                           ::google::protobuf::Closure* done) {
  AutoClosure auto_c(done);
  LOG(INFO) << "processing request:" << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  const auto& sort_item = GlobalData::Instance().GetSortItem();
  switch (request->dict_type()) {
    //case kSubjectDict: {
    //  auto dict = sort_item.GetDefaultSubject();
    //  LOG(INFO) << "subject dict size:" << dict->size();
    //  for (const auto& id : *dict) {
    //    response->add_ids(id);
    //  }
    //  break;
    //}
    case kYoukuIdDict: {
      auto dict = sort_item.GetYoukuVideoIdDict();
      LOG(INFO) << "youku video id dict size:" << dict->size();
      for (const auto& pair : *dict) {
        response->add_ids(pair.second);
      }
      break;
    }
    case kItemBreakingDict: {
      auto dict = sort_item.GetItemBreakingDict();
      LOG(INFO) << "breaking dict size:" << dict->size();
      for (const auto& pair : *dict) {
        auto elem = response->add_breaking_pairs();
        elem->set_key(pair.first);
        elem->mutable_val()->CopyFrom(pair.second);
      }
      break;
    }
    case kVideoItemIdDict: {
      auto ha3_client = GlobalData::Instance().GetHa3Client();
      std::vector<std::shared_ptr<ItemInfoIndex> > result;
      if (!ha3_client->QueryAllVideoItem(4e6, &result)) break;

      LOG(INFO) << "all video id dict size:" << result.size();
      for (const auto& ptr : result) {
        response->add_ids(ptr->item_id);
      }
      break;
    }
    case kMediaQuantityMetaDict: {
      const auto media_meta_dict = GlobalData::Instance().GetMetaUpdator()->GetMediaMeta();

      LOG(INFO) << "media quantity meta dict size:" << media_meta_dict.size();
      for (const auto& pair : media_meta_dict) {
        auto media_info = response->add_media_infos();
        media_info->CopyFrom(pair.second);
      }
      break;
    }
    default:
      break;
  }
}

void PresortImpl::Debug(::google::protobuf::RpcController* controller, const DebugRequest* request,
                        DebugResponse* response, ::google::protobuf::Closure* done) {
  AutoClosure auto_c(done);
  LOG(INFO) << "receive debug request:" << request->Utf8DebugString();

  auto index = GlobalData::Instance().GetIndex();
  response->set_success(false);

  switch (request->debug_type()) {
    case kItemInfoDebug: {
      LOG(INFO) << "running kItemInfoDebug.";
      ItemInfo item_info;
      if (!index->GetItemInfoByItemId(request->item_id(), &item_info, false)) return;
      PresortController::ItemInfo2Pb(item_info, response->mutable_item_info());
      PresortController::ItemInfoIndex2Pb(*index->GetItemInfoIndexByItemId(request->item_id()),
                                          response->mutable_item_info_index());

      std::unordered_set<uint64> yanchuang_items;
      GlobalData::Instance().GetYuanchuangItems(&yanchuang_items);
      if (yanchuang_items.find(request->item_id()) != yanchuang_items.end()) {
        response->set_in_yuanchuang(true);
      }

      break;
    }
    case kSetDebugItemId: {
      LOG(INFO) << "DEBUG settting debug item id:" << request->item_id();
      FLAGS_debug_item_id = request->item_id();

      // feature debug
      int32 doc_id;
      index->GetDocIdByItemId(request->item_id(), &doc_id);
      std::map<std::string, double> feature;
      double norm;
      index->GetFeatureMapByDocId(doc_id, reco::common::kTag, &feature, &norm);
      for (const auto& pair : feature) {
        LOG(INFO) << "DEBUG feature map key:" << pair.first << " value:" << pair.second;
      }
      break;
    }
    default:
      ;
  }

  LOG(INFO) << "debug request process success.";
  response->set_success(true);
}


} // end of namespace presort
} // end of namespace reco
