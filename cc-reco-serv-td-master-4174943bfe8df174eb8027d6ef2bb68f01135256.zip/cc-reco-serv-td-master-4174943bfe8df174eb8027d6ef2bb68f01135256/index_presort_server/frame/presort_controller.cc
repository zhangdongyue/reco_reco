#include <math.h>
#include "reco/serv/index_presort_server/frame/presort_controller.h"
#include "reco/serv/index_presort_server/frame/global_data.h"
#include "reco/serv/index_presort_server/module/sort_item-inl.h"
#include "reco/base/common/uri_process.h"

DEFINE_int64_counter(presort, reco_customize_req, 0, "");
DEFINE_int64_counter(presort, reco_customize_time, 0, "");
DEFINE_int64_counter(presort, reco_cate_req, 0, "");
DEFINE_int64_counter(presort, reco_cate_time, 0, "");
DEFINE_int64_counter(presort, reco_vd_cate_req, 0, "");
DEFINE_int64_counter(presort, reco_chn_req, 0, "");
DEFINE_int64_counter(presort, reco_chn_time, 0, "");
DEFINE_int64_counter(presort, reco_vd_chn_req, 0, "");
DEFINE_int64_counter(presort, reco_term_req, 0, "");
DEFINE_int64_counter(presort, reco_term_time, 0, "");
DEFINE_int64_counter(presort, reco_term_hit_cache, 0, "");

DEFINE_int64_counter(presort, get_chn_cate_req, 0, "");
DEFINE_int64_counter(presort, get_wm_dict_req, 0, "");
DEFINE_int64_counter(presort, get_lt_news_req, 0, "");

DEFINE_int64_counter(presort, gen_query_resp_num, 0, "");
DEFINE_int64_counter(presort, gen_query_resp_time, 0, "");
DEFINE_int64_counter(presort, gen_reco_resp_num, 0, "");
DEFINE_int64_counter(presort, gen_reco_resp_time, 0, "");

namespace reco {
namespace presort {

PresortController::PresortController() {
  ha3_client_ = GlobalData::Instance().GetHa3Client();
}

PresortController::~PresortController() {

}

bool PresortController::ProcessRecoRequest(const GetDefaultRecoRequest* request,
                                       GetDefaultRecoResponse* response) {
  int64 start_ts = base::GetTimestamp();
  const SortItem& sort_item = GlobalData::Instance().GetSortItem();

  switch (request->reco_type()) {
    case kTestReco: {
      COUNTERS_presort__reco_customize_req.Increase(1);
      std::vector<ItemInfo> result;
      Ha3Option option;
      option.result_num = request->result_num();
      option.only_id = request->only_id();
      option.only_basic = true;
      ha3_client_->Query(request->clause(), option, &result);
      bool ret = GenRecoResponse(&result, request, response);
      COUNTERS_presort__reco_customize_time.Increase((base::GetTimestamp() - start_ts) / 1e3);
      return ret;
    }
    case kDefault: {
      auto item_vec = sort_item.GetDefaultReco();
      return GenRecoResponse(item_vec, request, response);
    }
    case kCategoryReco: {
      COUNTERS_presort__reco_cate_req.Increase(1);
      auto item_vec = sort_item.GetDefaultReco(request->category(),  request->timely());
      bool ret = GenRecoResponse(item_vec, request, response);
      COUNTERS_presort__reco_cate_time.Increase((base::GetTimestamp() - start_ts) / 1e3);
      return ret;
    }
    case kChannelReco: {
      COUNTERS_presort__reco_chn_req.Increase(1);
      auto item_vec = sort_item.GetDefaultReco(request->channel_id(), request->region_id());
      bool ret = GenRecoResponse(item_vec, request, response);
      COUNTERS_presort__reco_chn_time.Increase((base::GetTimestamp() - start_ts) / 1e3);
      return ret;
    }
    case kVideoCategoryReco: {
      COUNTERS_presort__reco_vd_cate_req.Increase(1);
      auto item_vec = sort_item.GetVideoDefaultReco(request->category());
      return GenRecoResponse(item_vec, request, response);
    }
    case kVideoChannelReco: {
      COUNTERS_presort__reco_vd_chn_req.Increase(1);
      auto item_vec = sort_item.GetVideoDefaultReco(request->channel_id(),
                                                    request->explore(),
                                                    request->fullyshown());
      return GenRecoResponse(item_vec, request, response);
    }
    case kPOIReco: {
      auto item_vec = sort_item.GetPOIDefaultReco(request->area_id());
      return GenRecoResponse(item_vec, request, response);
    }
    case kUCBReco: {
      auto item_vec = sort_item.GetUCBDefaultReco();
      return GenRecoResponse(item_vec, request, response);
    }
    case kQuantityReco: {
      auto item_vec = sort_item.GetGuaranteeQuantityReco(request->category());
      return GenRecoResponse(item_vec, request, response);
    }
    case kVideoQuantityReco: {
      auto item_vec = sort_item.GetVideoGuaranteeQuantityReco(request->category());
      return GenRecoResponse(item_vec, request, response);
    }
    case kLocalBreakingReco: {
      auto item_vec = sort_item.GetLocalBreakingDefaultReco(request->region_id());
      return GenRecoResponse(item_vec, request, response);
    }
    case kSubjectReco: {
      auto item_vec = sort_item.GetSubjectDefaultReco();
      return GenRecoResponse(item_vec, request, response);
    }
    case kTermReco: {
      COUNTERS_presort__reco_term_req.Increase(1);
      auto item_vec = sort_item.GetTermReco(request->term());
      if (item_vec) {
        COUNTERS_presort__reco_term_hit_cache.Increase(1);
        return GenRecoResponse(item_vec, request, response);
      }
      // 穿透
      std::vector<ItemInfo> result;
      Ha3Option option;
      option.result_num = request->result_num();
      option.only_id = request->only_id();
      option.only_basic = true;
      ha3_client_->QueryTerm(request->term(), option, &result);
      bool ret = GenRecoResponse(&result, request, response);
      COUNTERS_presort__reco_term_time.Increase((base::GetTimestamp() - start_ts) / 1e3);
      return ret;
    }
    case kMiningSttgReco: {
      auto item_vec = sort_item.GetMiningStrategyReco(request->mining_strategy());
      return GenRecoResponse(item_vec, request, response);
    }
    default:
      break;
  }

  return false;
}

bool PresortController::GenRecoResponse(const std::vector<ItemInfo>* item_vec,
                                        const GetDefaultRecoRequest* request,
                                        GetDefaultRecoResponse* response) {
  if (!item_vec) return false;
  LOG(INFO) << "reco vector size:" << item_vec->size() << ", request result num:" << request->result_num();

  const NewsIndex* news_index = GlobalData::Instance().GetIndex();
  for (const auto& item : *item_vec) {
    if (response->item_info_size() >= request->result_num()) break;

    auto item_info_index = news_index->GetItemInfoIndexByItemId(item.item_id);
    if (!item_info_index) {
      // LOG(ERROR) << "not found item index:" << item.item_id;
      continue;
    }

    auto pb_item = response->add_item_info();
    pb_item->set_sort_value(item.ha3_sort_value);
    if (request->only_id()) {
      pb_item->set_item_id(item.item_id);
      pb_item->set_ha3_update_timestamp(item_info_index->ha3_update_timestamp);
    } else {
      pb_item->set_index_score(item.index_score);  // DEBUG
      ItemInfoIndex2Pb(*item_info_index.get(), pb_item);
    }
  }

  return true;
}

bool PresortController::QueryHa3(const QueryHa3Request* request, QueryHa3Response* response) {
  std::vector<std::shared_ptr<ItemInfoIndex> > result;
  Ha3Option option;
  option.result_num = request->result_num();
  ha3_client_->Query(request->query_clause(), option, &result);
  return GenQueryResponse(result, response);
}

bool PresortController::GenQueryResponse(const std::vector<std::shared_ptr<ItemInfoIndex> >& item_vec,
                                         QueryHa3Response* response) {
  int64 start_ts = base::GetTimestamp();
  LOG(INFO) << "query result size:" << item_vec.size();

  for (const auto& item : item_vec) {
    auto pb_item = response->add_item_info();
    ItemInfoIndex2Pb(*item.get(), pb_item);
  }

  int64 tu = base::GetTimestamp() - start_ts;
  LOG(INFO) << "GenQueryResponse time usage us:" << tu;
  COUNTERS_presort__gen_query_resp_time.Increase(tu);
  COUNTERS_presort__gen_query_resp_num.Increase(1);
  return true;
}

void PresortController::ItemInfo2Pb(const ItemInfo& item_info, PbItemInfo* pb_item) {
  pb_item->set_item_id(item_info.item_id);
  pb_item->set_item_type(item_info.item_type);
  pb_item->set_doc_id(item_info.doc_id);
  pb_item->set_site_level(item_info.site_level);
  pb_item->set_media_level(item_info.media_level);
  pb_item->set_time_level(item_info.time_level);
  pb_item->set_hot_level(item_info.hot_level);
  pb_item->set_sensitive_type(item_info.sensitive_type);
  pb_item->set_reco_score(item_info.reco_score);
  pb_item->set_create_timestamp(item_info.create_timestamp);
  pb_item->set_category(item_info.category);
  pb_item->set_sub_category(item_info.sub_category);
  pb_item->set_itemq(item_info.itemq);
  pb_item->set_spider_score(item_info.spider_score);
  pb_item->set_lr_score(item_info.lr_score);
  pb_item->set_fm_score(item_info.fm_score);
  pb_item->set_fac_machine_score(item_info.fac_machine_score);
  pb_item->set_meta_valid(item_info.meta_valid);
  pb_item->set_ctr(item_info.ctr);
  pb_item->set_show_num(item_info.show_num);
  pb_item->set_click_num(item_info.click_num);
  pb_item->set_duration(item_info.duration);
  pb_item->set_duration_score(item_info.duration_score);
  pb_item->set_new_pr(item_info.new_pr);
  pb_item->set_new_itemq(item_info.new_itemq);
  pb_item->set_strategy_type(item_info.strategy_type);
  pb_item->set_strategy_branch(item_info.strategy_branch);
  pb_item->set_source_rule_chain(item_info.source_rule_chain.to_string());
  pb_item->set_source_media_sign(item_info.source_media_sign);
  pb_item->set_orig_source_media_sign(item_info.orig_source_media_sign);
  pb_item->set_is_source_wemedia(item_info.is_source_wemedia);
  pb_item->set_ir_type(item_info.ir_type);
  pb_item->set_ir_word(item_info.ir_word);
  pb_item->set_ir_score(item_info.ir_score);
  pb_item->set_index_score(item_info.index_score);
  pb_item->set_predict_ctr(item_info.predict_ctr);
  //pb_item->set_app_rule_mask(item_info.app_rule_mask);
}

void PresortController::ItemInfoIndex2Pb(const ItemInfoIndex& item_info_index, PbItemInfoIndex* pb_item) {
  pb_item->set_keyword_norm(item_info_index.keyword_norm);
  pb_item->set_plsa_topic_norm(item_info_index.plsa_topic_norm);
  pb_item->set_semantic_tag_norm(item_info_index.semantic_tag_norm);
  pb_item->set_tag_norm(item_info_index.tag_norm);
  pb_item->set_topic_norm(item_info_index.topic_norm);
  pb_item->set_video_black_edge_ratio(item_info_index.video_black_edge_ratio);
  pb_item->set_wordvec_norm(item_info_index.wordvec_norm);
  pb_item->set_content_attr(item_info_index.content_attr);
  pb_item->set_content_length(item_info_index.content_length);
  pb_item->set_crawl_timestamp(item_info_index.crawl_timestamp);
  pb_item->set_create_timestamp(item_info_index.create_timestamp);
  pb_item->set_docmask(item_info_index.docmask);
  pb_item->set_expire_timestamp(item_info_index.expire_timestamp);
  pb_item->set_has_video_storage_info(item_info_index.has_video_storage_info);
  pb_item->set_image_count(item_info_index.image_count);
  pb_item->set_item_has_reviewed(item_info_index.item_has_reviewed);
  pb_item->set_item_is_yuanchuang(item_info_index.item_is_yuanchuang);
  pb_item->set_item_type(item_info_index.item_type);
  pb_item->set_jingpin_score(item_info_index.jingpin_score);
  pb_item->set_novel_update_time(item_info_index.novel_update_time);
  pb_item->set_paragraph_num(item_info_index.paragraph_num);
  pb_item->set_popularity(item_info_index.popularity);
  pb_item->set_posterior_item_q(item_info_index.posterior_item_q);
  pb_item->set_publish_time(item_info_index.publish_time);
  pb_item->set_term_feature_version(item_info_index.term_feature_version);
  pb_item->set_title_length(item_info_index.title_length);
  pb_item->set_ucbr_style_type(item_info_index.ucbr_style_type);
  pb_item->set_video_count(item_info_index.video_count);
  pb_item->set_video_length(item_info_index.video_length);
  pb_item->set_video_quality_level(item_info_index.video_quality_level);
  pb_item->set_video_storage_info_status(item_info_index.video_storage_info_status);
  pb_item->set_video_vulgar_level(item_info_index.video_vulgar_level);
  pb_item->set_app_token(item_info_index.app_token);
  pb_item->set_image_hash(item_info_index.image_hash);
  pb_item->set_item_subscripts(item_info_index.item_subscripts);
  pb_item->set_keyword_feature_list(item_info_index.keyword_feature_list);
  pb_item->set_keyword_list(item_info_index.keyword_list);
  pb_item->set_novel_id(item_info_index.novel_id);
  pb_item->set_orig_source_media(item_info_index.orig_source_media);
  pb_item->set_orig_source(item_info_index.orig_source);
  pb_item->set_outer_id(item_info_index.outer_id);
  pb_item->set_paragraph_hash(item_info_index.paragraph_hash);
  pb_item->set_plsa_topic_feature_list(item_info_index.plsa_topic_feature_list);
  pb_item->set_plsa_topic_list(item_info_index.plsa_topic_list);
  pb_item->set_raw_summary(item_info_index.raw_summary);
  pb_item->set_region_from_title(item_info_index.region_from_title);
  pb_item->set_region_restrict(item_info_index.region_restrict);
  pb_item->set_region(item_info_index.region);
  pb_item->set_semantic_tag_feature_list(item_info_index.semantic_tag_feature_list);
  pb_item->set_semantic_tag_list(item_info_index.semantic_tag_list);
  pb_item->set_sim_feature(item_info_index.sim_feature);
  pb_item->set_sim_hash(item_info_index.sim_hash);
  pb_item->set_source_media(item_info_index.source_media);
  pb_item->set_source(item_info_index.source);
  pb_item->set_tag_feature_list(item_info_index.tag_feature_list);
  pb_item->set_tag_list(item_info_index.tag_list);
  pb_item->set_term_feature_bytes(item_info_index.term_feature_bytes);
  pb_item->set_topic_feature_list(item_info_index.topic_feature_list);
  pb_item->set_topic_list(item_info_index.topic_list);
  pb_item->set_ucb_editor_name(item_info_index.ucb_editor_name);
  pb_item->set_wemedia_person(item_info_index.wemedia_person);
  pb_item->set_wordvec_feature_list(item_info_index.wordvec_feature_list);
  pb_item->set_wordvec_list(item_info_index.wordvec_list);
  pb_item->set_youku_video_id(item_info_index.youku_video_id);
  pb_item->set_priority(item_info_index.priority);
  pb_item->set_special_contain_item_list(item_info_index.special_contain_item_list);
  pb_item->set_special_prevew_item_list(item_info_index.special_prevew_item_list);
  pb_item->set_video_poster_problem_info(item_info_index.video_poster_problem_info);
  pb_item->set_category(item_info_index.category);
  pb_item->set_channel(item_info_index.channel);
  pb_item->set_item_event_tag(item_info_index.item_event_tag);
  pb_item->set_item_show_tag(item_info_index.item_show_tag);
  pb_item->set_gaode_poi(item_info_index.gaode_poi);
  pb_item->set_item_quality_attr(item_info_index.item_quality_attr);
  pb_item->set_time_axis_results(item_info_index.time_axis_results);
  pb_item->set_ucbr_deliver(item_info_index.ucbr_deliver);
  pb_item->set_category_candidates(item_info_index.category_candidates);
  pb_item->set_title(item_info_index.title);
  pb_item->set_anchor(item_info_index.anchor);
  pb_item->set_query(item_info_index.query);
  pb_item->set_bid_word(item_info_index.bid_word);
  pb_item->set_content(item_info_index.content);
  pb_item->set_item_id(item_info_index.item_id);
  pb_item->set_orig_media_risk_type(item_info_index.orig_media_risk_type);
  pb_item->set_manual_news(item_info_index.manual_news);
  pb_item->set_youku_audit_status(item_info_index.youku_audit_status);
  pb_item->set_item_event_tag_info(item_info_index.item_event_tag_info);
  pb_item->set_video_play_control(item_info_index.video_play_control);
  pb_item->set_youku_show_id(item_info_index.youku_show_id);
  pb_item->set_subject_sub_items(item_info_index.subject_sub_items);
  pb_item->set_sort_value(item_info_index.sort_value);
  pb_item->set_group_info(item_info_index.group_info);
  pb_item->set_local_breaking(item_info_index.local_breaking);
  pb_item->set_title_lda_topic_list(item_info_index.title_lda_topic_list);
  pb_item->set_title_lda_topic_feature_list(item_info_index.title_lda_topic_feature_list);
  pb_item->set_title_lda_topic_norm(item_info_index.title_lda_topic_norm);
  pb_item->set_first_nscreen_filter(item_info_index.first_nscreen_filter);
  pb_item->set_video_poster_clarity(item_info_index.video_poster_clarity);
  pb_item->set_video_width(item_info_index.video_width);
  pb_item->set_video_height(item_info_index.video_height);
  pb_item->set_video_colors(item_info_index.video_colors);

  std::shared_ptr<const ExpiryMap<uint64, AppTokenFilterSt>> app_token_filter_map
          = GlobalData::Instance().GetAppTokenFilterMap();
  AppTokenFilterSt app_token_filter_st;
  if (app_token_filter_map->FindSilently(item_info_index.item_id, &app_token_filter_st)) {
    pb_item->set_app_token_bits(app_token_filter_st.bits);
    std::string value;
    BitsetToString(app_token_filter_st.rule_bits, &value);
    pb_item->set_app_token_rule_bits(reco::common::EncodeUrlComponent(value));
  }

  const MetaInfoUpdator* meta_updator = GlobalData::Instance().GetMetaUpdator();
  ItemInfo meta;
  if (meta_updator->GetMetaInfo(item_info_index.item_id, &meta)) {
    PbMetaInfo* meta_info = pb_item->mutable_meta_info();
    meta_info->set_hot_level(meta.hot_level);
    meta_info->set_item_quality(meta.itemq);
    meta_info->set_spider_score(meta.spider_score);
    meta_info->set_site_level(static_cast<int>(meta.site_level));
    meta_info->set_time_level(static_cast<int>(meta.time_level));
    meta_info->set_sensitive_type(static_cast<int>(meta.sensitive_type));
    meta_info->set_show_count(meta.show_num);
    meta_info->set_click_count(meta.click_num);
    meta_info->set_duration(meta.duration);
    meta_info->set_new_pr(meta.new_pr);
    meta_info->set_new_itemq(meta.new_itemq);
    meta_info->set_ctr(meta.ctr);
    meta_info->set_duration_score(meta.duration_score);
    meta_info->set_predict_ctr(meta.predict_ctr);
  }

  const SimItem* sim_item = GlobalData::Instance().GetSimItem();
  std::vector<reco::sim_lib::SimElem> sim_elems;
  if (sim_item->GetSimElems(item_info_index.item_id, &sim_elems)) {
    PbSimInfo* sim_info = pb_item->mutable_sim_info();
    for (const auto& elem : sim_elems) {
      auto sim_elem = sim_info->add_sim_elems();
      sim_elem->set_level(elem.get_level());
      sim_elem->set_score(elem.get_score());
      sim_elem->set_sim_id(elem.get_sim_id());
    }

    sim_info->set_has_checked(sim_item->HasCheckedBySimServer(item_info_index.item_id));
    sim_info->set_parent_id(sim_item->GetParent(item_info_index.item_id));
  }

  const SortItem& sort_item = GlobalData::Instance().GetSortItem();
  time_axis::TimeAxisInfo time_axis_info;
  if (sort_item.GetItemTimeAxisInfoByItemId(item_info_index.item_id, &time_axis_info)) {
    pb_item->mutable_time_axis_info()->CopyFrom(time_axis_info);
  }

  pb_item->set_wilson_ctr(sort_item.GetWilsonCtr(item_info_index.item_id));
}

const int APP_TOKEN_CHAR_BIT = 8;
void PresortController::BitsetToString(std::shared_ptr<boost::dynamic_bitset<uint8>> app_rule_mask,
                                    std::string* value) {
  if (app_rule_mask->size() <= 0) {
    return;
  }
  uint32 num = ceil(app_rule_mask->size() / 8.0);
  boost::dynamic_bitset<uint8>::block_type* blocks = new boost::dynamic_bitset<uint8>::block_type[num];
  boost::to_block_range(*app_rule_mask, blocks);
  for (size_t i = 0; i < num; ++i) {
    value->push_back(blocks[i]);
  }
  delete[] blocks;

  return;
}

bool PresortController::GetChannelAndCategory(const GetChnAndCateRequest* request,
                                              GetChnAndCateResponse* response) {
  COUNTERS_presort__get_chn_cate_req.Increase(1);
  if (request->return_category()) {
    auto category_pool = GlobalData::Instance().GetCategoryPool();
    for (const auto& elem : category_pool) {
      response->add_categories(elem.ToString());
    }
  }

  if (request->return_channel()) {
    auto channel_pool = GlobalData::Instance().GetChannelPool();
    for (const auto& elem : channel_pool) {
      response->add_channels(elem);
    }
  }

  if (request->return_term()) {
    auto term_pool = GlobalData::Instance().GetTermPool();
    for (const auto& elem : term_pool) {
      response->add_terms(elem);
    }
  }

  return true;
}

bool PresortController::GetWeMediaItemsDict(const GetWemediaDictRequest* request,
                                            GetWemediaDictResponse* response) {
  COUNTERS_presort__get_wm_dict_req.Increase(1);
  auto wm_dict = GlobalData::Instance().GetSortItem().GetWeMediaItemsDict();
  for (const auto& pair : *wm_dict) {
    WemediaItemDict* dict = response->add_dicts();
    dict->set_wemedia_name(pair.first);
    for(const auto& item_id : pair.second) {
      dict->add_item_ids(item_id);
    }
  }

  return true;
}

bool PresortController::GetLatestNews(const GetLatestNewsRequest* request,
                                      GetLatestNewsResponse* response) {
  COUNTERS_presort__get_lt_news_req.Increase(1);
  uint64 latest_item_id;
  time_axis::TimeAxisInfo timeaxis_info;
  if (GlobalData::Instance().GetSortItem().GetLatestNewsByEventName(request->event_name(),
                                                                    &latest_item_id,
                                                                    response->mutable_timeaxis_info())) {
    response->set_latest_item_id(latest_item_id);
    return true;
  } else {
    return false;
  }
}

}  // namespace
}  // namespace
