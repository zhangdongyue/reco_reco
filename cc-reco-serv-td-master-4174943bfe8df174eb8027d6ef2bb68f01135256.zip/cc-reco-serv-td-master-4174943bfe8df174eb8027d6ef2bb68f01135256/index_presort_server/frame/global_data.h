#pragma once

#include <string>
#include <deque>
#include <vector>
#include <unordered_map>
#include <set>

#include "base/common/logging.h"
#include "base/thread/blocking_var.h"
#include "base/thread/blocking_queue.h"
#include "base/common/basic_types.h"
#include "reco/bizc/proto_arpc/index_presort_server.pb.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"
#include "reco/base/dict_manager/dynamic_dict.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_util.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/common/wrapped_category.h"
#include "reco/bizc/proto/common.pb.h"
#include "base/common/logging.h"
#include "reco/serv/index_presort_server/module/sim_item.h"
#include "reco/serv/index_presort_server/module/meta_info_updator.h"
#include "reco/serv/index_presort_server/module/source_manager.h"
#include "reco/serv/index_presort_server/module/sort_item.h"
#include "reco/serv/index_presort_server/module/video_stat_info_updator.h"
#include "reco/serv/index_presort_server/frame/index_wrapper.h"
#include "reco/serv/index_presort_server/frame/ha3_client.h"
#include "reco/base/expiry_map/multi_expiry_map.h"

namespace reco {
namespace presort {

struct CollectSt {
  CollectSt(RecoType reco_t = kDefault): reco_type(reco_t) {}
  RecoType reco_type;
  int64 channel_id;
  std::string category;
  std::string term;
};

struct AppTokenFilterSt {
  int bits{-1};
  std::shared_ptr<boost::dynamic_bitset<uint8>> rule_bits;

  AppTokenFilterSt() {}
  AppTokenFilterSt(int b, std::shared_ptr<boost::dynamic_bitset<uint8>> r) : bits(b), rule_bits(r) {}
};

class GlobalData {
 public:
  GlobalData();
  ~GlobalData();

  void Init();
  void InitThreadFunc();

  static GlobalData& Instance() {
    static GlobalData obj;
    return obj;
  }

  Ha3Client* GetHa3Client() {
    return ha3_client_;
  }

  // return a copy of the pool
  CategorySet GetCategoryPool() {
    thread::AutoLock pool_lock(&pool_mutex_);
    return category_pool_;
  }

  std::unordered_set<int64> GetChannelPool() {
    thread::AutoLock pool_lock(&pool_mutex_);
    return channel_pool_;
  }

  std::unordered_set<std::string> GetTermPool() {
    thread::AutoLock pool_lock(&term_mutex_);
    return term_pool_;
  }

  const SortItem& GetSortItem() const {
    return *sort_item_;
  }

  const NewsIndex* GetIndex() const {
    return index_wrapper_;
  }

  const SimItem* GetSimItem() const {
    return sim_item_;
  }

  const MetaInfoUpdator* GetMetaUpdator() const {
    return meta_updator_;
  }

  void GetYuanchuangItems(std::unordered_set<uint64>* yanchuang_items) const {
    sim_item_->GetYuanChuangItems(yanchuang_items);
  }

  void CollectTasks(const GetDefaultRecoRequest* request);
  void UpdateCateAndChnPool();

  std::shared_ptr<ExpiryMap<uint64, AppTokenFilterSt>> GetAppTokenFilterMap() {
    return app_token_filter_map_;
  };

 private:
  void CollectTasksThreadFunc();

  thread::Thread collect_task_thread_;
  thread::Thread init_thread_;
  bool closing_;
  thread::BlockingQueue<CollectSt> collect_req_que_;
  thread::Mutex pool_mutex_;
  std::unordered_set<int64> channel_pool_;
  CategorySet category_pool_;
  thread::Mutex term_mutex_; // term数量比较多，不能共用一个锁
  std::unordered_set<std::string> term_pool_;

  NewsIndex* index_wrapper_;
  Ha3Client* ha3_client_;

  SimItem* sim_item_;
  MetaInfoUpdator* meta_updator_;
  SourceManager* source_manager_;
  SortItem* sort_item_;
  VideoStatInfoUpdator* video_stat_info_updator_;

  std::shared_ptr<reco::ExpiryMap<uint64, AppTokenFilterSt>> app_token_filter_map_;
};


}  // end of namespace
}  // end of namespace
