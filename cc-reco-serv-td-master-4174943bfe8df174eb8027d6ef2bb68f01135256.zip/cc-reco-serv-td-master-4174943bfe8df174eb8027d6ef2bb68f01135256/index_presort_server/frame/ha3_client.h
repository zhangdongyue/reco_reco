#pragma once

#include <google/protobuf/stubs/common.h>
#include <iostream>
#include <iomanip>
#include <string>
#include "arpc/CommonMacros.h"
#include "arpc/RPCInterface.h"
#include "arpc/ANetRPCChannelManager.h"
#include "arpc/ANetRPCChannel.h"
#include "arpc/ANetRPCController.h"
#include "client_pool/ArpcClientPool.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "reco/bizc/proto_arpc/ha3_qrs_service.pb.h"
#include "reco/bizc/proto/ha3_result.pb.h"
#include "reco/bizc/reco_index/item_info.h"
#include "reco/bizc/common/wrapped_category.h"
#include "reco/bizc/common/channel_define.h"
#include "reco/serv/index_presort_server/frame/ha3_attr_define.h"
#include "reco/serv/index_presort_server/frame/index_wrapper.h"


using namespace arpc;
using namespace arpc_client_pool::client_pool;

DECLARE_string(ha3_query_format);

namespace reco {

typedef std::unordered_set<common::WrappedCategory, common::CategoryHash> CategorySet;

struct Ha3Option {
  Ha3Option(int default_result_num = 0) {
    memset(this, 0, sizeof(Ha3Option));
    result_num = default_result_num;
  }

  int result_num;
  bool only_basic;
  bool only_id;
};

class Ha3Client {
 public:
  Ha3Client(const std::string& ha3ips, int ha3port, NewsIndex* news_index = NULL);
  ~Ha3Client();

 public:
  // return a copy of collection
  std::unordered_set<int64> GetChannelCollection() {
    thread::AutoLock auto_lock(&collection_lock_);
    return channel_collection_;
  }

  CategorySet GetCategoryCollection() {
    thread::AutoLock auto_lock(&collection_lock_);
    return category_collection_;
  }

  std::unordered_set<std::string> GetTermCollection() {
    thread::AutoLock auto_lock(&collection_lock_);
    return term_collection_;
  }

  // 返回结果为ItemInfoIndex的接口
  bool Query(const std::string& query_clause, const Ha3Option& option,
             std::vector<std::shared_ptr<ItemInfoIndex> >* result) {
    std::string query = StringPrintf("query=%s", query_clause.c_str());
    return QueryHa3(query, option, result);
  }

  // 返回结果为ItemInfo的接口，后续会全部改成返回ItemInfoIndex
  bool Query(const std::string& query_clause, const Ha3Option& option, std::vector<ItemInfo>* result) {
    std::string query = StringPrintf("query=%s", query_clause.c_str());
    return QueryHa3(query, option, result);
  }

  bool QueryAllItem(int result_num, std::vector<ItemInfo>* result) {
    static const std::string query = "query=special_index:ALL_ITEM";
    return QueryHa3(query, Ha3Option(result_num), result);
  }

  bool QueryAllOperItem(int result_num, std::vector<ItemInfo>* result) {
    static const std::string query = "query=special_index:ALL_ITEM&&filter=MANUAL_NEWS>0";
    return QueryHa3(query, Ha3Option(result_num), result);
  }

  bool QueryTerm(const std::string& term, const Ha3Option& option, std::vector<ItemInfo>* result) {
    std::string query = StringPrintf("query=special_index:\"%s\"", term.c_str());
    return QueryHa3(query, option, result);
  }

  bool QueryCategory(const Category& category, int result_num, std::vector<ItemInfo>* result) {
    std::string term = common::GetCategoryPayloadTerm(category.category(), category.level());
    std::string query = StringPrintf("query=special_index:%s", term.c_str());
    return QueryHa3(query, Ha3Option(result_num), result);
  }

  bool QueryVideoCategory(const Category& category, int result_num, std::vector<ItemInfo>* result) {
    std::string term = common::GetCategoryPayloadTerm(category.category(), category.level());
    std::string query = StringPrintf("query=special_index:%s AND special_index:I_30", term.c_str());
    return QueryHa3(query, Ha3Option(result_num), result);
  }

  bool QueryJingpin(int result_num, std::vector<ItemInfo>* result) {
    std::string query = StringPrintf("query=special_index:JINGPIN");
    return QueryHa3(query, Ha3Option(result_num), result);
  }

  bool QueryHumor(int result_num, std::vector<ItemInfo>* result) {
    std::string query = StringPrintf("query=special_index:I_3");
    return QueryHa3(query, Ha3Option(result_num), result);
  }

  bool QuerySpecial(int result_num, std::vector<ItemInfo>* result) {
    std::string query = StringPrintf("query=special_index:I_100");
    return QueryHa3(query, Ha3Option(result_num), result);
  }

  bool QueryChannel(int64 channel_id, int result_num, std::vector<ItemInfo>* result) {
    std::string query = StringPrintf("query=special_index:CN_%ld", channel_id);
    return QueryHa3(query, Ha3Option(result_num), result);
  }

  bool QueryVideoChannel(int64 channel_id, int result_num, std::vector<ItemInfo>* result) {
    std::string query = StringPrintf("query=special_index:CN_%ld AND special_index:I_30 ANDNOT special_index:CN_200", channel_id);
    return QueryHa3(query, Ha3Option(result_num), result);
  }

  bool QueryAllVideoItem(int result_num, std::vector<std::shared_ptr<ItemInfoIndex> >* result) {
    std::string query = "query=special_index:I_30";
    Ha3Option option(result_num);
    option.only_id = true;
    return QueryHa3(query, option, result);
  }

 private:
  bool QueryHa3(const std::string& query_clause, const Ha3Option& option, std::vector<ItemInfo>* result);
  bool QueryHa3(const std::string& query_clause, const Ha3Option& option,
                std::vector<std::shared_ptr<ItemInfoIndex> >* result);

  bool DoHa3Query(const std::string& query_clause, const Ha3Option& option,
                  std::vector<std::pair<uint64, float> >* rslt_item_ids);
  bool Ha3Rpc(const std::string& query_clause, ha3::PBResult* pb_rslt, bool only_basic);
  bool GetNeedUpdateItemPks(const std::string& query_clause,
                            int result_num,
                            std::vector<std::pair<uint64, float>>* all_items,
                            std::vector<uint64>* need_upd_items);
  void GetIdThreadFunc(std::string query_clause, ha3::PBResult* pb_rslt);
  void QueryHa3ThreadFunc(std::string query_clause);
  bool ParseHa3ResultAndSave(const ha3::PBMatchDocs& pb_docs, std::vector<uint64>* saved_item_ids);
  void GetItemInfo(const std::vector<std::pair<uint64, float> >& item_ids,
                   std::vector<ItemInfo>* result, bool only_basic = false);
  void GetItemInfoIndex(const std::vector<std::pair<uint64, float> >& item_ids,
                        std::vector<std::shared_ptr<ItemInfoIndex> >* result);

  void CollectChannel(const google::protobuf::RepeatedPtrField<std::string>* channels);
  void CollectCategory(const google::protobuf::RepeatedPtrField<std::string>* categories);
  void CollectTerm(const google::protobuf::RepeatedPtrField<std::string>* terms);

 private:
  bool connected_;
  ArpcClientPool<ha3::QrsService_Stub> conn_pool_;

  thread::Mutex collection_lock_;
  std::unordered_set<int64> channel_collection_;
  CategorySet category_collection_;
  std::unordered_set<std::string> term_collection_;

  std::string ha3_basic_prefix_;
  std::string ha3_query_prefix_;

  NewsIndex* news_index_;
};

}
