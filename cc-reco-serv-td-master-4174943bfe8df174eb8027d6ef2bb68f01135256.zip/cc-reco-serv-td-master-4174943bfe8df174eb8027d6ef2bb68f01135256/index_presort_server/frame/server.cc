#include "arpc/RPCInterface.h"
#include "arpc/ANetRPCServer.h"
#include "base/common/base.h"
#include "base/thread/thread.h"
#include "base/file/file_path.h"
#include "base/strings/string_printf.h"
#include "serving_base/utility/timer.h"
#include "serving_base/utility/signal.h"
#include "reco/serv/index_presort_server/frame/presort_impl.h"
#include "reco/serv/index_presort_server/frame/presort_controller.h"
#include "reco/serv/index_presort_server/frame/global_data.h"
#include "net/counter/export.h"
#include "reco/base/reload_service/reload_service_impl.h"

using namespace arpc;

DEFINE_string(server_ip, "0.0.0.0", "");
DEFINE_int32(port, 20022, "the port on which the serving application listens");
DEFINE_int32(thread_num, 40, "thread num");
DECLARE_int32(heart_beat_port);
DECLARE_string(data_dir);
DEFINE_int32(reload_port, 30022, "");
DEFINE_int32(queue_size, 10000, "request queue length");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "the intermediate node of serving");
  net::counter::HttpCounterExport();

  serving_base::Timer timer;
  timer.Start();

  // connect to ha3

  LOG(INFO) << "server starting...";

  // global data
  reco::presort::GlobalData::Instance().Init();
  LOG(INFO) << "Init global data time: " << timer.Interval();

  auto transport = new anet::Transport(FLAGS_thread_num);
  ANetRPCServer main_server(transport, FLAGS_thread_num, FLAGS_queue_size);
  main_server.StartPrivateTransport();
  transport->start();
  main_server.RegisterService(new reco::presort::PresortImpl());
  bool ret = main_server.Listen(StringPrintf("tcp:%s:%d", FLAGS_server_ip.c_str(), FLAGS_port));
  if (!ret) return -1;

  ANetRPCServer reload_server;
  reload_server.StartPrivateTransport();
  reload_server.RegisterService(new reco::dm::ReloadServiceImpl());
  ret = reload_server.Listen(StringPrintf("tcp:%s:%d", FLAGS_server_ip.c_str(), FLAGS_reload_port));
  if (!ret) return -1;

  std::cout << "server started. time usage: " << timer.Stop() << std::endl;
  LOG(INFO) << "server started.";

  serving_base::SignalCatcher::Initialize();
  serving_base::SignalCatcher::WaitForSignal();
  main_server.Close();
  main_server.StopPrivateTransport();
  LOG(INFO) << "server stopped";

  std::cout << "server safe quit" << std::endl;
  return 0;
}
