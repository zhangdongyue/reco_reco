#pragma once
#include <atomic>
#include <functional>
#include "reco/bizc/reco_index/item_info.h"
#include "base/thread/sync.h"
#include "base/thread/rw_mutex.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "reco/bizc/proto/item.pb.h"
#include "reco/bizc/common/attr_bit_proc.h"
#include "base/common/logging.h"
#include "reco/base/common/uri_process.h"
#include "base/hash_function/term.h"
#include "reco/base/dict_manager/dynamic_dict.h"
#include "reco/serv/index_presort_server/module/index_dict_manager.h"
#include "reco/serv/index_presort_server/module/meta_info_updator.h"
//#include "reco/serv/index_presort_server/frame/safe_unordered_map.h"
#include "reco/base/expiry_map/multi_expiry_map.h"
#include "reco/bizc/common/appname_define.h"

#define GetParsedStringAttr(doc_id, attr_name, result) \
  auto index_ptr = GetItemInfoIndexByDocId(doc_id); \
  if (!index_ptr) return false; \
  if (index_ptr->attr_name.empty()) return false; \
  std::string attr; \
  if (!common::DecodeUrlComponent(index_ptr->attr_name.c_str(), &attr)) return false; \
  return result->ParseFromString(attr);

enum DocMaskFlags {
  // NOTE(lintao): 这个为索引保留标志位, 表示该文档在索引中相当于不存在, 用于倒排遍历时的过滤
  // 1. 表示该文档被其他相同 key 的文档覆盖, DocLocalIDFromKeySign 不会找到该文档的 local id
  // 2. 动态索引中, 表示对该文档的删除操作, 即覆盖之前 key 相同的文档, 且把自己标记为无效状态
  kDocMaskInvalid = 0x01,
};

namespace reco {
namespace time_axis {
class TimeAxisResults;
}

namespace common {
std::string GetFeaturePayloadTerm(const std::string& literal, FeatureType type);
std::string GetCategoryPayloadTerm(const std::string& literal, int level);
std::string GetTagPayloadTerm(const std::string& tag);
std::string GetItemTypePayloadTerm(int32 type);
}

class VideoStatInfo;
class Ha3Client;



struct ItemInfoIndex {
  int doc_id;

  float keyword_norm;
  float plsa_topic_norm;
  float semantic_tag_norm;
  float tag_norm;
  float topic_norm;
  float video_black_edge_ratio;
  float wordvec_norm;
  int32 content_attr;
  int32 content_length;
  uint64 crawl_timestamp;
  uint64 create_timestamp;
  int32 docmask;
  int64 expire_timestamp;
  int32 has_video_storage_info;
  int32 image_count;
  int32 item_has_reviewed;
  int32 item_is_yuanchuang;
  int32 item_type;
  int32 jingpin_score;
  int32 novel_update_time;
  int32 paragraph_num;
  int32 popularity;
  int32 posterior_item_q;
  int32 publish_time;
  int32 term_feature_version;
  int32 title_length;
  int32 ucbr_style_type;
  int32 video_count;
  int32 video_length;
  int32 video_quality_level;
  int32 video_storage_info_status;
  int32 video_vulgar_level;
  std::string app_token;
  std::string image_hash;
  std::string item_subscripts;
  std::string keyword_feature_list;
  std::string keyword_list;
  std::string novel_id;
  std::string orig_source_media;
  std::string orig_source;
  std::string outer_id;
  std::string paragraph_hash;
  std::string plsa_topic_feature_list;
  std::string plsa_topic_list;
  std::string raw_summary;
  std::string region_from_title;
  std::string region_restrict;
  std::string region;
  std::string semantic_tag_feature_list;
  std::string semantic_tag_list;
  std::string sim_feature;
  std::string sim_hash;
  std::string source_media;
  std::string source;
  std::string tag_feature_list;
  std::string tag_list;
  int32 term_feature_bytes;
  std::string term_payload;
  std::string topic_feature_list;
  std::string topic_list;
  std::string ucb_editor_name;
  std::string wemedia_person;
  std::string wordvec_feature_list;
  std::string wordvec_list;
  std::string youku_video_id;
  std::string priority;
  std::string special_contain_item_list;
  std::string special_prevew_item_list;
  std::string video_poster_problem_info;
  std::string category;
  std::string channel;
  std::string item_event_tag;
  std::string item_show_tag;
  std::string gaode_poi;
  std::string item_quality_attr;
  std::string time_axis_results;
  std::string ucbr_deliver;
  std::string category_candidates;
  std::string title;
  std::string anchor;
  std::string query;
  std::string bid_word;
  std::string content;
  std::string term_special;
  uint64 item_id;
  int32 orig_media_risk_type;
  int32 manual_news;
  std::string youku_audit_status;
  std::string item_event_tag_info;
  std::string video_play_control;
  std::string youku_show_id;
  std::string subject_sub_items;
  std::string group_info;
  std::string local_breaking;
  float title_lda_topic_norm;
  std::string title_lda_topic_list;
  std::string title_lda_topic_feature_list;
  int32 first_nscreen_filter;
  int32 app_token_bits;
  std::string app_token_rule_bits;
  float video_poster_clarity;
  int32 video_width;
  int32 video_height;
  int32 video_colors;

  // HA3 控制字段
  uint64 ha3_update_timestamp;
  float sort_value;
};

/*
class MapHandler : public ElemHandler<int32, std::shared_ptr<ItemInfoIndex> > {
 public:
  virtual void HandleElem(const int32& k, std::shared_ptr<ItemInfoIndex>& v) {
    //LOG(INFO) << "HandleElem k:" << k << " use_count:" << v.use_count();
  }
};
*/

class NewsIndex {
public:
  NewsIndex(int cache_expire_time = 6400, int cache_block_num = 1000) {
    max_doc_local_id_ = INT32_MAX;
    min_doc_local_id_ = INT32_MAX;
    dict_manager_ = IndexDictManager::GetInstance();
    meta_info_updator_ = NULL;
    ts_in_future_ = base::GetTimestamp() + base::Time::kMicrosecondsPerDay * 365 * 1000;

    item_info_index_ = std::make_shared<
                         ExpiryMap<int32, std::shared_ptr<ItemInfoIndex> > >(cache_expire_time, cache_block_num);
    local_id_map_ = std::make_shared<ExpiryMap<uint64, int32> >(cache_expire_time, cache_block_num);
  }

  ~NewsIndex() {
  }

  void SetMetaInfoUpdator(MetaInfoUpdator* meta_info_updator) {
    meta_info_updator_ = meta_info_updator;
  }

  void SetHa3Client(Ha3Client* ha3_client) {
    ha3_client_ = ha3_client;
  }

  int32 MinDocLocalId() const {
    return min_doc_local_id_;
  }

  int32 MaxDocLocalId() const {
    return max_doc_local_id_;
  }

  int32 GetDocNum() const {
    return max_doc_local_id_ - min_doc_local_id_;
  }

  inline bool GetDocIdByItemId(uint64 item_id, int32* doc_id) const {
    if (!local_id_map_->FindSilently(item_id, doc_id)) return false;
    return true;
  }

  inline bool GetItemIdByDocId(int32 doc_id, uint64* item_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    *item_id = index_ptr->item_id;
    return true;
  }

  inline bool GetItemInfoByDocId(int32 doc_id, ItemInfo* item_info, bool only_basic) const {
    if (!GetItemIdByDocId(doc_id, &(item_info->item_id))) return false;
    if (!GetItemTypeByDocId(doc_id, &(item_info->item_type))) return false;
    item_info->doc_id = doc_id;
    if (only_basic) return true;

    if (meta_info_updator_) {
      meta_info_updator_->GetMetaInfo(item_info->item_id, item_info);
    }

    std::vector<std::string> categories;
    if (GetCategoriesByDocId(doc_id, &categories) || !categories.empty()) {
      item_info->category = categories[0];
      if (categories.size() > 1u) {
        item_info->sub_category = categories[1];
      }
    }

    item_info->create_timestamp = GetCreateTimestampByDocId(doc_id);

    std::string source_media;
    GetSourceMediaByDocId(doc_id, &source_media);
    item_info->source_media_sign = base::CalcTermSign(source_media.c_str(), source_media.size());

    std::string orig_source_media;
    GetOrigSourceMediaByDocId(doc_id, &orig_source_media);
    item_info->orig_source_media_sign = base::CalcTermSign(orig_source_media.c_str(), orig_source_media.size());

    std::string source;
    static const char* wemedia_source = "cp_wemedia_uc_";
    static const size_t wemedia_size = strlen(wemedia_source);
    if (GetSourceByDocId(doc_id, &source)
        && source.size() >= wemedia_size
        && strncmp(source.c_str(), wemedia_source, wemedia_size) == 0) {
      item_info->is_source_wemedia = true;
    }

    item_info->source_sign = base::CalcTermSign(source.c_str(), source.size());

    // calc media level
    if (item_info->is_source_wemedia) {
    item_info->media_level = reco::kNormalMedia;
    } else {
      item_info->media_level = reco::kLowMedia;
    }
    // 机构媒体：用 类别 + "\t" + 名称 做 key 进行查找
    auto const cate_media_level_map = dict_manager_->GetCategoryMediaLevelMap();
    const std::string used_media = (!orig_source_media.empty()) ? orig_source_media : source_media;
    const std::string cate_media = item_info->category + "\t" + used_media;
    auto level_iter = cate_media_level_map->find(cate_media);
    if (level_iter == cate_media_level_map->end()) {
      level_iter = cate_media_level_map->find("全部\t" + used_media);
    }
    if (level_iter != cate_media_level_map->end()) {
      item_info->media_level = level_iter->second;
    }

    return true;
  }

  inline bool GetItemInfoByItemId(uint64 item_id, ItemInfo* item_info, bool only_basic) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return GetItemInfoByDocId(doc_id, item_info, only_basic);
  }

  void ConvertToCategoryProto(const std::vector<std::string>& categories,
                              int level, reco::Category* category) const {
    category->Clear();
    if (level >= (int)categories.size() || level < 0) {
      LOG(ERROR) << "error level: " << level;
      return;
    }
    category->set_level(level);
    category->set_category(categories[level]);
    for (int i = 0; i < level; ++i) {
      category->add_parents(categories[i]);
    }
  }

  inline bool GetItemQualityAttrByDocId(int32 doc_id, ItemQualityAttr* quality_attr) const {
    GetParsedStringAttr(doc_id, item_quality_attr, quality_attr);
  }

  inline bool GetItemQualityAttrByItemId(uint64 item_id, ItemQualityAttr* quality_attr) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return GetItemQualityAttrByDocId(doc_id, quality_attr);
  }

  inline bool IsValidByDocId(int32 doc_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;

    if (index_ptr->docmask & kDocMaskInvalid) return false;
    if (index_ptr->docmask & reco::common::kDocFilterServer) return false;

    return true;
  }

  inline bool IsValidByItemId(uint64 item_id) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return IsValidByDocId(doc_id);
  }

  inline bool IsExpiredByDocId(int32 doc_id, int64 now_timestamp) const {
    return now_timestamp >= GetExpireTimestampByDocId(doc_id);
  }

  inline bool IsExpiredByItemId(uint64 item_id, int64 now_timestamp) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return true;
    return IsExpiredByDocId(doc_id, now_timestamp);
  }

  int64 GetExpireTimestampByDocId(int32 doc_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return ts_in_future_;

    /*if (!(index_ptr->doc_mask & common::kDocMaskTimeWhiteList)) {
      return ts_in_future_;
    }*/

    return index_ptr->expire_timestamp;
  }

  int64 GetCrawlTimestampByDocId(int32 doc_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return 0;
    return index_ptr->crawl_timestamp;
  }

  int64 GetCreateTimestampByDocId(int32 doc_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return 0;
    return index_ptr->create_timestamp;
  }

  int64 GetCreateTimestampByItemId(uint64 item_id) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return 0;
    return GetCreateTimestampByDocId(doc_id);
  }

  inline bool GetProducerByDocId(int32 doc_id, std::string* producer) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    *producer = index_ptr->app_token;
    return true;
  }

  inline bool GetProducerByItemId(uint64 item_id, std::string* producer) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return GetProducerByDocId(doc_id, producer);
  }

  inline bool GetSourceMediaByDocId(int32 doc_id, std::string* source_media) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    *source_media = index_ptr->source_media;
    return true;
  }

  inline bool GetSourceMediaByItemId(uint64 item_id, std::string* source_media) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return GetSourceMediaByDocId(doc_id, source_media);
  }

  inline bool GetSourceByDocId(int32 doc_id, std::string* source) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    *source = index_ptr->source;
    return true;
  }

  inline bool GetSourceByItemId(uint64 item_id, std::string* source) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return GetSourceByDocId(doc_id, source);
  }

  inline bool HasVideoStorageInfoByDocId(int32 doc_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    return index_ptr->has_video_storage_info;
  }

  inline bool GetWeMediaPersonByDocId(int32 doc_id, std::string* wemedia_person) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    *wemedia_person = index_ptr->wemedia_person;
    if (wemedia_person->empty()) return false;
    return true;
  }

  inline bool GetItemTypeByDocId(int32 doc_id, reco::ItemType* item_type) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    int64 attr = index_ptr->item_type;

    if (reco::ItemType_IsValid(attr) && attr != 255) {
      *item_type = static_cast<reco::ItemType>(attr);
      return true;
    }
    return false;
  }

  inline bool GetItemTypeByItemId(uint64 item_id, reco::ItemType* item_type) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return GetItemTypeByDocId(doc_id, item_type);
  }

  inline bool GetCategoriesByDocId(int32 doc_id, std::vector<std::string>* categories) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    base::SplitString(index_ptr->category, "\t", categories);
    return true;
  }

  inline bool GetCategoriesByItemId(uint64 item_id, std::vector<std::string>* categories) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return GetCategoriesByDocId(doc_id, categories);
  }

  inline bool GetCategoriesByItemId(uint64 item_id, std::vector<reco::Category>* categories) const {
    std::vector<std::string> str_categories;
    if (!GetCategoriesByItemId(item_id, &str_categories)) return false;

    categories->resize(str_categories.size());
    for (int i = 0; i < (int)str_categories.size(); ++i) {
      ConvertToCategoryProto(str_categories, i, &(categories->at(i)));
    }
    return true;
  }

  int32 GetCateMediaLevelNum(const std::string& cate_level) const {
    const base::dense_hash_map<std::string, int32>* media_level_dict = dict_manager_->GetCateMediaLevelNumMap();
    auto iter = media_level_dict->find(cate_level);
    if (iter == media_level_dict->end()) return 0;
    return iter->second;
  }

  inline bool GetOrigSourceMediaByDocId(int32 doc_id, std::string* orig_source_media) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    *orig_source_media = index_ptr->orig_source_media;
    return true;
  }

  inline bool GetWemediaMeta(const std::string& source, IndexDictManager::WemediaMeta* meta) const {
    auto newbee_dict = dict_manager_->GetWemediaMetaMap()->find(source);
    if (newbee_dict == dict_manager_->GetWemediaMetaMap()->end())
      return false;
    (*meta) = newbee_dict->second;
    return true;
  }

  inline bool GetContentAttrByDocId(int32 doc_id, ContentAttr* content_attr, bool* is_trival) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    common::UnPackContentAttr(index_ptr->content_attr, content_attr);
    *is_trival = (index_ptr->content_attr == 0);
    return true;
  }

  inline bool IsYuanchuangDocId(int32 doc_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return true;
    return index_ptr->item_is_yuanchuang;
  }

  inline bool GetUCBSettingByItemId(uint64 item_id, UcBrowserDeliverSetting* ucb_setting) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    GetParsedStringAttr(doc_id, ucbr_deliver, ucb_setting);
  }

  inline bool GetVideoStatInfoByItemId(uint64 item_id, VideoStatInfo* info) const {
    return false;
  }

  inline bool GetChannelsByItemId(uint64 item_id, std::vector<int64>* channel_ids) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return GetChannelsByDocId(doc_id, channel_ids);
  }

  inline bool GetChannelsByDocId(int32 doc_id, std::vector<int64>* channel_ids) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    std::string channel = index_ptr->channel;
    if (channel.empty()) return false;

    channel_ids->clear();
    std::vector<std::string> flds;
    base::SplitString(channel, "\t", &flds);
    int64 id;
    for (int i = 0; i < (int)flds.size(); ++i) {
      if (!base::StringToInt64(flds[i], &id)) {
        LOG(ERROR) << "err channel id: " << flds[i];
        continue;
      }
      channel_ids->push_back(id);
    }
    return !channel_ids->empty();
  }

  int32 GetImageCountByDocId(int32 doc_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;

    return index_ptr->image_count;
  }

  int32 GetImageCountByItemId(uint64 item_id) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return GetImageCountByDocId(doc_id);
  }

  inline bool GetItemContentByItemId(uint64 item_id, std::string* content) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;

    *content = index_ptr->content;
    return true;
  }

  inline bool GetMultiCategoriesByItemId(uint64 item_id, MultiCategory* multi_category) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    GetParsedStringAttr(doc_id, category_candidates, multi_category);
  }

  int32 GetTotalVideoLengthByDocId(int32 doc_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    return index_ptr->video_length;
  }

  int32 GetUCBStyleTypeByDocId(int32 doc_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    return index_ptr->ucbr_style_type;
  }

  inline bool GetRestrictRegionIdByDocId(int32 doc_id, std::vector<int64> *restrict_region_ids) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    std::string restrict_region = index_ptr->region_restrict;
    if (restrict_region.empty()) return false;

    restrict_region_ids->clear();
    std::vector<std::string> fields;
    base::SplitString(restrict_region, ";", &fields);
    int64 region_id;
    for (size_t i = 0; i < fields.size(); ++i) {
      if (base::StringToInt64(fields[i], &region_id)) {
        restrict_region_ids->push_back(region_id);
      }
    }
    return true;
  }

  inline bool GetItemTitleByDocId(int32 doc_id, std::string* title) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    *title = index_ptr->title;
    return true;
  }

  inline bool GetItemTitleByItemId(uint64 item_id, std::string* title) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return GetItemTitleByDocId(doc_id, title);
  }

  inline bool GetTimeAxisResultsByDocId(int32 doc_id, time_axis::TimeAxisResults *time_axis_results) const {
    GetParsedStringAttr(doc_id, time_axis_results, time_axis_results);
  }

  int32 GetJingpinScoreByDocId(int32 doc_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    return index_ptr->jingpin_score;
  }

  inline bool GetPreviewIdsByItemId(uint64 item_id, std::unordered_set<uint64>* preview_ids) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    preview_ids->clear();
    std::string preview_str = index_ptr->special_prevew_item_list;
    std::vector<std::string> id_list;
    base::SplitString(preview_str, ",", &id_list);
    uint64 id;
    for (int i = 0; i < (int)id_list.size(); ++i) {
      if (base::StringToUint64(id_list[i], &id)) {
        preview_ids->insert(id);
      }
    }
    return true;
  }

  VideoAttr::VideoVulgarLevel GetVideoVulgarLevelByDocId(int32 doc_id) const {
    VideoAttr::VideoVulgarLevel vv_level = VideoAttr_VideoVulgarLevel_kNotVulgar;
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return vv_level;
    return (VideoAttr::VideoVulgarLevel)index_ptr->video_vulgar_level;
  }

  VideoAttr::VideoQualityLevel GetVideoQualityLevelByDocId(int32 doc_id) const {
    VideoAttr::VideoQualityLevel vq_level = VideoAttr_VideoQualityLevel_kNormal;
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return vq_level;
    return (VideoAttr::VideoQualityLevel)index_ptr->video_quality_level;
  }

  inline bool GetGaoDePOIByDocId(int32 doc_id, GaoDePOI* gaode_poi) const {
    GetParsedStringAttr(doc_id, gaode_poi, gaode_poi);
  }

  inline bool GetRegionIdByDocId(int32 doc_id, std::vector<int64>* region_ids) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    std::string ret_region = index_ptr->region;
    if (ret_region.empty()) return false;
    region_ids->clear();
    std::vector<std::string> fields;
    base::SplitString(ret_region, ";", &fields);
    int64 region_id;
    for (size_t i = 0; i < fields.size(); ++i) {
      if (base::StringToInt64(fields[i], &region_id)) {
        region_ids->push_back(region_id);
      }
    }
    return true;
  }

  inline bool GetYoukuVideoIdByDocId(int32 doc_id, uint64* youku_video_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    std::string value = index_ptr->youku_video_id;
    if (value.empty()) return false;
    return base::StringToUint64(value, youku_video_id);
  }

  inline bool GetOrigSourceByDocId(int32 doc_id, std::string* orig_source) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    *orig_source = index_ptr->orig_source;
    return true;
  }

  inline bool GetFeatureValueByDocId(int32 doc_id, reco::common::FeatureType type, double* norm_val,
                                     std::vector<std::string>* key_vals,
                                     std::vector<float>* weight_vals) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;

    std::string keys;
    std::string feature_list;
    float norm = 0;
    switch (type) {
      case common::kKeyword:
        keys = index_ptr->keyword_list;
        norm = index_ptr->keyword_norm;
        feature_list = index_ptr->keyword_feature_list;
        break;
      case common::kTopic:
        keys = index_ptr->topic_list;
        norm = index_ptr->topic_norm;
        feature_list = index_ptr->topic_feature_list;
        break;
      case common::kPlsaTopic:
        keys = index_ptr->plsa_topic_list;
        norm = index_ptr->plsa_topic_norm;
        feature_list = index_ptr->plsa_topic_feature_list;
        break;
      case common::kWordvec:
        keys = index_ptr->wordvec_list;
        norm = index_ptr->wordvec_norm;
        feature_list = index_ptr->wordvec_feature_list;
        break;
      case common::kTag:
        keys = index_ptr->tag_list;
        norm = index_ptr->tag_norm;
        feature_list = index_ptr->tag_feature_list;
        break;
      case common::kSemanticTag:
        keys = index_ptr->semantic_tag_list;
        norm = index_ptr->semantic_tag_norm;
        feature_list = index_ptr->semantic_tag_feature_list;
        break;
      default:
        return false;
    }
    if (keys == "" || norm < 1e-7) {
      return false;
    }

    std::vector<std::string> key_list;
    base::SplitString(keys, "\t", &key_list);
    std::vector<std::string> weight_list;
    base::SplitString(feature_list, "\t", &weight_list);

    std::vector<float> weights;
    for (const auto& elem : weight_list) {
      double we = 0;
      if (!base::StringToDouble(elem, &we)) {
        LOG(ERROR) << "invalid weight value.";
        continue;
      }
      weights.push_back(we);
    }
    if (weights.size() != key_list.size()) {
      std::vector<float>(key_list.size(), 0).swap(weights);
    }

    *norm_val = norm;
    key_vals->swap(key_list);
    weight_vals->swap(weights);
    return true;
  }

  inline bool GetFeatureMapByDocId(int32 doc_id, reco::common::FeatureType type,
                                   std::map<std::string, double>* feature,
                                   double* norm2) const {
    std::vector<std::string> key_list;
    std::vector<float> weights;
    if (!GetFeatureValueByDocId(doc_id, type, norm2, &key_list, &weights)) return false;

    feature->clear();
    for (int i = 0; i < (int)key_list.size(); ++i) {
      feature->insert(std::make_pair(key_list[i], weights[i]));
    }
    return true;
  }

  inline bool GetFeatureVectorByItemId(uint64 item_id, common::FeatureType type,
                                       FeatureVector* feature) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;

    std::vector<std::string> key_list;
    std::vector<float> weights;
    double norm;
    if (!GetFeatureValueByDocId(doc_id, type, &norm, &key_list, &weights)) return false;

    feature->Clear();
    for (int i = 0; i < (int)key_list.size(); ++i) {
      auto fea = feature->add_feature();
      fea->set_literal(key_list[i]);
      fea->set_weight(weights[i]);
    }
    feature->set_norm(norm);
    return true;
  }

  inline bool IsManualByDocId(int32 doc_id) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    int64 manual = index_ptr->manual_news;
    if (manual > 0) {
      return true;
    }
    return false;
  }

  inline bool IsManualByItemId(uint64 item_id) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return IsManualByDocId(doc_id);
  }

  inline bool GetHa3UpdateTsByItemId(uint64 item_id, uint64* update_ts, int64* expire_remain = NULL) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    return GetHa3UpdateTsByDocId(doc_id, update_ts, expire_remain);
  }

  inline bool GetHa3UpdateTsByDocId(int32 doc_id, uint64* update_ts, int64* expire_remain = NULL) const {
    auto index_ptr = GetItemInfoIndexByDocId(doc_id, expire_remain);
    if (!index_ptr) return false;
    *update_ts = index_ptr->ha3_update_timestamp;
    return true;
  }

  inline bool GetOrgiItemQByItemId(uint64 item_id, int32* orgi_itemq) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;

    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    *orgi_itemq = index_ptr->posterior_item_q;
    return true;
  }

  inline bool GetYoukuShowIDByItemId(uint64 item_id, std::string* youku_show_id) const {
    if (youku_show_id == NULL) return false;
    /*youku_show_id->clear();
    *youku_show_id = index_->GetStringAttr(kYoukuShowIDSign, doc_id, "");
    if (youku_show_id->empty()) {
      return false;
    }*/
    return false;
  }

  inline bool GetGroupInfoByDocId(int32 doc_id, ItemGroupInfo* group_info) const {
    GetParsedStringAttr(doc_id, group_info, group_info);
  }

  inline bool GetLocalBreakingByDocId(int32 doc_id, reco::LocalBreaking* local_breaking) const {
    GetParsedStringAttr(doc_id, local_breaking, local_breaking);
  }

  inline bool HasVideoStorageInfoByItemId(uint64 item_id) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;

    auto index_ptr = GetItemInfoIndexByDocId(doc_id);
    if (!index_ptr) return false;
    return index_ptr->has_video_storage_info;
  }

  inline bool GetSubjectSubItemByItemId(uint64 item_id, reco::SubjectSubItems* subject_sub_items) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return false;
    GetParsedStringAttr(doc_id, subject_sub_items, subject_sub_items);
  }

  inline bool GetVideoTagFeatureVectorByItemId(uint64 item_id, reco::FeatureVector* feature) const {
    reco::FeatureVector raw_feature;
    if (!GetFeatureVectorByItemId(item_id, reco::common::kTag, &raw_feature)) return false;
    ParseVideoTagFeatureVector(item_id, raw_feature, feature);
    return true;
  }

  void ParseVideoTagFeatureVector(uint64 item_id,
                                  const reco::FeatureVector& raw_feature,
                                  reco::FeatureVector *real_feature) const {
    real_feature->Clear();
    bool manual_checked = false;
    for (int i = 0; i < raw_feature.feature_size(); ++i) {
      const std::string &raw_tag = raw_feature.feature(i).literal();
      std::vector<std::string> tokens;
      base::SplitString(raw_tag, ":", &tokens);
      if (tokens.size() > 1 && tokens[0] == "manual") {
        manual_checked = true;
        break;
      }
    }
    for (int i = 0; i < raw_feature.feature_size(); ++i) {
      const std::string &raw_tag = raw_feature.feature(i).literal();
      std::vector<std::string> tokens;
      base::SplitString(raw_tag, ":", &tokens);
      std::string real_tag = "";
      if (tokens.size() <= 1) {
        // 没有前缀的直接认为是正确的 tag
        real_tag = tokens[0];
      } else if (!manual_checked && (tokens[0] == "label" || tokens[0] == "manual")) {
        real_tag = tokens[1];
      } else if (manual_checked && tokens[0] == "manual") {
        real_tag = tokens[1];
      }
      if (!real_tag.empty()) {
        auto fea = real_feature->add_feature();
        fea->CopyFrom(raw_feature.feature(i));
        fea->set_literal(real_tag);
      }
    }
  }

public:
  void GetDocsByKeywordOrTag(const std::string& word, std::vector<int32>* doc_id_list) const;
  void GetDocsByItemType(int32 item_type, std::vector<int32>* doc_id_list) const;

public:
  // write index  api
  void WriteItemInfoIndex(ItemInfoIndex* new_index) {
    uint64 item_id = new_index->item_id;

    int32 local_id;
    if (!local_id_map_->Find(item_id, &local_id)) {
      local_id = --min_doc_local_id_;
      local_id_map_->Add(item_id, local_id);
    }

    //static MapHandler mh_;
    new_index->doc_id = local_id;
    item_info_index_->Add(local_id, std::shared_ptr<ItemInfoIndex>(new_index));
  }

  std::shared_ptr<ItemInfoIndex> GetItemInfoIndexByDocId(int32 doc_id, int64* expire_remain = NULL) const {
    std::shared_ptr<ItemInfoIndex> index_ptr;
    if (!item_info_index_->FindSilently(doc_id, &index_ptr, expire_remain, EM_REMAIN_TIME)) return NULL;
    return index_ptr;
  }

  std::shared_ptr<ItemInfoIndex> GetItemInfoIndexByItemId(uint64 item_id) const {
    int32 doc_id;
    if (!GetDocIdByItemId(item_id, &doc_id)) return NULL;
    std::shared_ptr<ItemInfoIndex> index_ptr;
    if (!item_info_index_->FindSilently(doc_id, &index_ptr)) return NULL;
    return index_ptr;
  }

  std::string CacheSizeStr() const {
    return StringPrintf("id map size:%ld, index map size:%ld", local_id_map_->Size(), item_info_index_->Size());
  }

  int64 IndexCacheSize() const {
    return item_info_index_->Size();
  }

 private:
  int64 ts_in_future_;

  // index cache
  std::shared_ptr<ExpiryMap<int32, std::shared_ptr<ItemInfoIndex> > > item_info_index_;

  // 暂时保留doc id以保存兼容性，后续会去掉doc id的机制
  int32 max_doc_local_id_;
  std::atomic_int min_doc_local_id_;
  std::shared_ptr<ExpiryMap<uint64, int32> > local_id_map_;

  const IndexDictManager* dict_manager_;
  MetaInfoUpdator* meta_info_updator_;
  Ha3Client* ha3_client_;
};

}

