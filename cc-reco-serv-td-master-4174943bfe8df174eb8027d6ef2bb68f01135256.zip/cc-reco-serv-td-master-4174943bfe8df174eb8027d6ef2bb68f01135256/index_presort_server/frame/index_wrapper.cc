#include "reco/serv/index_presort_server/frame/index_wrapper.h"
#include "reco/serv/index_presort_server/frame/ha3_client.h"

namespace reco {

namespace common {

std::string GetFeaturePayloadTerm(const std::string& literal, FeatureType type) {
  switch (type) {
    case kKeyword:
      return "K_" + literal;
    case kTopic:
      return "P_" + literal;
    case kWordvec:
      return "W_" + literal;
    case kTag:
      return "T_" + literal;
    case kPlsaTopic:
      return "PT_" + literal;
    case kSemanticTag:
      return "ST_" + literal;
    default:
      return "";
  }
}

std::string GetCategoryPayloadTerm(const std::string& literal, int level) {
  return "C_" + base::IntToString(level) + "_" + literal;
}

std::string GetTagPayloadTerm(const std::string& tag) {
  return "T_label:" + tag;
}

std::string GetItemTypePayloadTerm(int32 type) {
  return "I_" + base::IntToString(type);
}

} // namespace common


void NewsIndex::GetDocsByKeywordOrTag(const std::string& word, std::vector<int32>* doc_id_list) const {
  std::string tterm;
  std::string kterm;
  if (base::StartsWith(word, "label:", true)) {
    tterm = common::GetFeaturePayloadTerm(word, common::kTag);
  } else {
    tterm = common::GetFeaturePayloadTerm("label:" + word, common::kTag);
  }
  kterm = common::GetFeaturePayloadTerm(word, common::kKeyword);

  std::string query = "special_index:\"" + tterm + "\" OR special_index:" + kterm;
  Ha3Option option(3e6);
  option.only_id = true;
  std::vector<std::shared_ptr<ItemInfoIndex> > result;
  if (ha3_client_->Query(query, option, &result)) {
    doc_id_list->clear();

    for (const auto& item : result) {
      doc_id_list->push_back(item->doc_id);
    }
  }
}

void NewsIndex::GetDocsByItemType(int32 item_type, std::vector<int32>* doc_id_list) const {
  std::string iterm = common::GetItemTypePayloadTerm(item_type);

  std::string query = "special_index:" + iterm;
  Ha3Option option(3e6);
  option.only_id = true;
  std::vector<std::shared_ptr<ItemInfoIndex> > result;
  if (ha3_client_->Query(query, option, &result)) {
    doc_id_list->clear();

    for (const auto& item : result) {
      doc_id_list->push_back(item->doc_id);
    }
  }
}

} // namespace reco
