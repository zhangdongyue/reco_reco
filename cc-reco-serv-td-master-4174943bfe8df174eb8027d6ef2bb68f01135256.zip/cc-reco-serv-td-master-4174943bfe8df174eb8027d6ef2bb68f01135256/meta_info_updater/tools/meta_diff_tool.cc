#include <iostream>
#include <string>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/time/timestamp.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "base/hash_function/term.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

#include "reco/bizc/proto/reco_leaf_server.pb.h"
#include "reco/bizc/proto/item.pb.h"

DEFINE_string(a_leaf, "127.0.0.1:20001", "leaf server ip");
DEFINE_string(b_leaf, "127.0.0.2:20001", "leaf server ip");
DEFINE_string(meta_redis, "127.0.0.1:6379", "");

DEFINE_string(item_id_file, "", "uint64 item id");

void GetMetaInfo(reco::leafserver::RecommendService::Stub *stub,
                 const uint64 item_id,
                 reco::leafserver::GetIndexItemInfoResponse *resp) {
  resp->Clear();

  reco::leafserver::GetIndexItemInfoRequest request;
  request.set_item_id(item_id);
  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(200);
  stub->getIndexItemInfo(&rpc, &request, resp, NULL);
  rpc.Wait();
  if (rpc.status() != net::rpc::RpcClientController::kOk) {
    LOG(ERROR) << "request fail: " << rpc.error_text();
  } else if (!resp->success()) {
    LOG(ERROR) << "get resp fail:" << resp->Utf8DebugString();
  }

  return;
}

void CompareMeta(const uint64 item_id,
                 reco::leafserver::GetIndexItemInfoResponse a_resp,
                 reco::leafserver::GetIndexItemInfoResponse b_resp,
                 reco::redis::RedisCli *redis) {
  if (a_resp.show_num() != b_resp.show_num()
      || a_resp.click_num() != b_resp.click_num()
      || a_resp.ctr() != b_resp.ctr()
      || a_resp.hot_score() != b_resp.hot_score()
      || a_resp.time_level() != b_resp.time_level()
      || a_resp.site_level() != b_resp.site_level()
      || a_resp.item_quality() != b_resp.item_quality()
      || a_resp.sensitive_type() != b_resp.sensitive_type()
      || a_resp.media_level() != b_resp.media_level()) {
    LOG(INFO) << "item_id meta diff. a info:" << a_resp.Utf8DebugString()
              << ", b info:" << b_resp.Utf8DebugString();

    // redis
    std::unordered_map<std::string, std::string> field_values;
    if (redis->HGetAll("ItemLevel-" + base::Uint64ToString(item_id), &field_values)) {
      for (auto it = field_values.begin(); it != field_values.end(); ++it) {
        LOG(INFO) << "item_id meta diff, redis info," << " key:" << it->first << ", val:" << it->second;
      }
    } else {
      LOG(ERROR) << "get redis fail:" << item_id;
    }
  } else {
    LOG(INFO) << "item_id meta same:" << item_id;
  }
  return;
}


int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "meta diff client");

  std::vector<std::string> elems;
  int port = 0;
  base::SplitString(FLAGS_a_leaf, ":", &elems);
  base::StringToInt(elems[1], &port);
  net::rpc::RpcClientChannel a_channel(elems[0].c_str(), port);
  CHECK(a_channel.Connect());
  reco::leafserver::RecommendService::Stub a_stub(&a_channel);

  elems.clear();
  base::SplitString(FLAGS_b_leaf, ":", &elems);
  base::StringToInt(elems[1], &port);
  net::rpc::RpcClientChannel b_channel(elems[0].c_str(), port);
  CHECK(b_channel.Connect());
  reco::leafserver::RecommendService::Stub b_stub(&b_channel);

  reco::redis::RedisCli *redis = new reco::redis::RedisCli(FLAGS_meta_redis, 10, 10000);

  std::vector<std::string> lines;
  base::file_util::ReadFileToLines(FLAGS_item_id_file, &lines);
  uint64 item_id = 0;
  reco::leafserver::GetIndexItemInfoResponse a_resp;
  reco::leafserver::GetIndexItemInfoResponse b_resp;

  for (auto i = 0u; i < lines.size(); ++i) {
    if (!base::StringToUint64(lines[i], &item_id)) {
      LOG(WARNING) << "parse item id fail:" << lines[i];
      continue;
    }

    GetMetaInfo(&a_stub, item_id, &a_resp);
    GetMetaInfo(&b_stub, item_id, &b_resp);

    CompareMeta(item_id, a_resp, b_resp, redis);
  }


  return 0;
}
