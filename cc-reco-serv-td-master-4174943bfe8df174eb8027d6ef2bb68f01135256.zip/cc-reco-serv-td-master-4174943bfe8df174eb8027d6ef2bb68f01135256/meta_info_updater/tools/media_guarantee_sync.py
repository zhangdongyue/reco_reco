#!/usr/bin/env python
# -*- coding: utf-8 -*-

import datetime
import json

import happybase
from kafka import KafkaProducer

connection = happybase.Connection('11.251.181.42', port=9091)
connection.open()

# kafka
kafka_brokers = '11.251.176.1:9092,11.251.176.2:9092,11.251.176.3:9092,11.251.176.5:9092,11.251.176.8:9092,11.251.176.9:9092,11.251.176.21:9092,11.251.176.49:9092,11.251.176.51:9092,11.251.176.54:9092'
producer = KafkaProducer(bootstrap_servers=kafka_brokers, retries=3)


table = connection.table('tb_guarantee_stats')
date_row = datetime.datetime.now().strftime("%Y%m%d")
row = table.row(date_row, columns=[b'data:split', b'data:source'])
split = row[b'data:split']
source_list = row[b'data:source'].strip().split(',')
for source in source_list:
    row = table.row(source)
    print row
    data = json.loads(row[b'data:stats'])
    print source
    print data[1]['total_pv']
    print data[1]['guarantee_pv']
    meta_info = reco.proto.meta_update_pb2.MetaUpdateInfo()
    meta_info.version = 1
    meta_info.item_id = 0
    meta_info.media_info.source = source.split(split)[0]
    meta_info.media_info.today_total_pv = data[1]['total_pv']
    meta_info.media_info.today_guarantee_pv = data[1]['guarantee_pv']
    pb_msg = meta_info.SerializeToString()
    print '%s:%u:%u' % (source, data[1]['total_pv'], data[1]['guarantee_pv'])
    break
