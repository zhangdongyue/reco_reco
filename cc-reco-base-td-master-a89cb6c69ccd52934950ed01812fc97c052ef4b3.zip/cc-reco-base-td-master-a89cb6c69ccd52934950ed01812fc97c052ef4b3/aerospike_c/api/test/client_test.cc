#include "reco/base/aerospike_c/api/client.h"

#include <boost/shared_ptr.hpp>
#include <iostream>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

using boost::shared_ptr;
using std::string;
using std::vector;

DEFINE_string(aero_ips, "127.0.0.1:3000", "");

const char *bin = "test_bin";
const char *str_key = "abc123_str";
const char *str_val = "succ_val";
const char *list_key = "abc123_list";

class AeroClientTest: public testing::Test {
 protected:
  void SetUp() {}

  void TearDown() {}
};


TEST_F(AeroClientTest, GetSetData) {
  shared_ptr<reco::aero::Client> aero_cli(new reco::aero::Client(FLAGS_aero_ips));
  // reco::aero::Client aero_cli->FLAGS_aero_ips);

  // set
  ASSERT_TRUE(aero_cli->SetData(str_key, bin, str_val));
  ASSERT_TRUE(aero_cli->SetData(str_key, "bin-1", bin));

  // get
  vector<string> bins, values;
  bins.push_back(bin);
  bins.push_back("bin-1");
  ASSERT_TRUE(aero_cli->GetData(str_key, bins, &values));
  ASSERT_EQ(2u, values.size());
  ASSERT_EQ(str_val, values[0]);
  ASSERT_EQ(bin, values[1]);

  // del
  values.clear();
  ASSERT_TRUE(aero_cli->DelKey(str_key));
  ASSERT_TRUE(aero_cli->GetData(str_key, bins, &values));
  ASSERT_EQ(2u, values.size());
  ASSERT_EQ(string(), values[0]);
  ASSERT_EQ(string(), values[1]);
}


TEST_F(AeroClientTest, GetSetList) {
  shared_ptr<reco::aero::Client> aero_cli(new reco::aero::Client(FLAGS_aero_ips));
  ASSERT_TRUE(aero_cli->DelKey(list_key));

  // add
  vector<string> values, read_vals;
  for (auto i = 10; i < 20; ++i) {
    values.push_back(base::IntToString(i));
  }
  ASSERT_TRUE(aero_cli->AddListData(list_key, bin, values));

  // get
  vector<int64> extras;
  ASSERT_TRUE(aero_cli->GetListData(list_key, bin, &read_vals, &extras));
  ASSERT_EQ(10u, read_vals.size());
  for (auto i = 10; i < 20; ++i) {
    ASSERT_EQ(base::IntToString(i), read_vals[i-10]);
  }

  // update
  int64 extra = extras[0];
  string new_value = "111";
  ASSERT_TRUE(aero_cli->UpdateListData(list_key, bin, new_value, extra));
  extras.clear();
  ASSERT_TRUE(aero_cli->GetListData(list_key, bin, &read_vals, &extras));
  ASSERT_EQ(10u, read_vals.size());
  ASSERT_EQ(new_value, read_vals[0]);

  // del single elem
  ASSERT_TRUE(aero_cli->DelListData(list_key, bin, read_vals[0], extras[0]));
  ASSERT_TRUE(aero_cli->GetListData(list_key, bin, &read_vals, &extras));
  ASSERT_EQ(9u, read_vals.size());
  for (auto i = 11; i < 20; ++i) {
    ASSERT_EQ(base::IntToString(i), read_vals[i-11]);
  }

  // clear list data
  ASSERT_TRUE(aero_cli->ClearList(list_key, bin));
  ASSERT_TRUE(aero_cli->GetListData(list_key, bin, &read_vals, &extras));
  ASSERT_EQ(0u, read_vals.size());

  // del key
  ASSERT_TRUE(aero_cli->DelKey(list_key));
  ASSERT_TRUE(aero_cli->GetListData(list_key, bin, &read_vals));
  ASSERT_EQ(0u, read_vals.size());
}
