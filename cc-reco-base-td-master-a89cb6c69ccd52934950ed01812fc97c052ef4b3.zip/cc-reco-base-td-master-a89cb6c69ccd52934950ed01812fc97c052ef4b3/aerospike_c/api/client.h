#pragma once

#include <string>
#include <vector>

#include "base/common/gflags.h"
#include "base/thread/sync.h"
#include "base/time/timestamp.h"
#include "reco/base/common/singleton.h"
#include "aerospike/aerospike.h"

namespace reco {
namespace aero {
DECLARE_string(aero_ns);
DECLARE_string(aero_set);
DECLARE_int32(aero_write_timeout_ms);

// class Client;

// aerospike clint singleton
// use for example:
//    using reco::aerospike::AeroCli;
//    AeroCli::instance().Execute();
// typedef reco::common::singleton_default<Client> AeroCli;

class Client {
 public:
  explicit Client(const std::string &ips);
  ~Client() { Close(); }

  void Close();

  // 获取数据。 aerospike bin 类似于列名称
  bool GetData(const std::string &key, const std::vector<std::string> &bins, std::vector<std::string> *values,
               const std::string &ns_name = FLAGS_aero_ns, const std::string &set_name = FLAGS_aero_set);

  // 设置数据
  bool SetData(const std::string &key, const std::string &bin, const std::string &value,
               const std::string &ns_name = FLAGS_aero_ns, const std::string &set_name = FLAGS_aero_set);

  // 添加 list 类型数据，因为 aero 存储 list 需要指定 key 用于 list 的排序,
  // 现在是使用时间戳 ns，对于传入的数据，可以设置一个额外的偏移量 extra，
  // 避免同一时间传入的数据时间戳一样，导致插入失败
  bool AddListData(const std::string &key, const std::string &bin,
                   const std::string &value, const int64 val_key = base::GetTimestamp(),
                   const std::string &ns_name = FLAGS_aero_ns, const std::string &set_name = FLAGS_aero_set,
                   const int timeout = FLAGS_aero_write_timeout_ms);

  bool AddListData(const std::string &key,
                   const std::string &bin,
                   const std::vector<std::string> &values,
                   const std::vector<int64> &val_keys = std::vector<int64>(),
                   const std::string &ns_name = FLAGS_aero_ns,
                   const std::string &set_name = FLAGS_aero_set,
                   const int timeout = FLAGS_aero_write_timeout_ms);

  bool UpdateListData(const std::string &key, const std::string &bin,
                      const std::string &value, const int64 val_key,
                      const std::string &ns_name = FLAGS_aero_ns,
                      const std::string &set_name = FLAGS_aero_set,
                      const int timeout = FLAGS_aero_write_timeout_ms);

  // 获取 list 类型的数据，可选的获取时间戳，用于删除该数据时使用
  bool GetListData(const std::string &key, const std::string &bin,
                   std::vector<std::string> *values, std::vector<int64> *extra = NULL,
                   const std::string &ns_name = FLAGS_aero_ns, const std::string &set_name = FLAGS_aero_set);

  bool DelListData(const std::string &key, const std::string &bin,
                   const std::string &value, const int64 extra,
                   const std::string &ns_name = FLAGS_aero_ns, const std::string &set_name = FLAGS_aero_set);

  // 删除 list 类型的 bin
  bool ClearList(const std::string &key, const std::string &bin,
                 const std::string &ns_name = FLAGS_aero_ns,
                 const std::string &set_name = FLAGS_aero_set);

  // 删除指定的 key
  bool DelKey(const std::string &key,
              const std::string &ns_name = FLAGS_aero_ns,
              const std::string &set_name = FLAGS_aero_set);

 private:
  Client() {}

 private:
  std::string cluster_ips_;
  aerospike as_;

  DISALLOW_COPY_AND_ASSIGN(Client);
};
}
}
