#include "reco/base/aerospike_c/api/client.h"

#include <algorithm>
#include <ctime>
#include <map>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "serving_base/utility/timer.h"

#include "aerospike/aerospike_key.h"
#include "aerospike/aerospike_llist.h"
#include "aerospike/as_arraylist.h"
#include "aerospike/as_hashmap.h"
#include "aerospike/as_stringmap.h"

namespace reco {
namespace aero {

using std::string;
using std::vector;
using std::map;

DEFINE_string(aero_ns, "test", "default as_namespace name");
DEFINE_string(aero_set, "test", "default as_set name");

DEFINE_int32(aero_read_timeout_ms, 200, "");
DEFINE_int32(aero_write_timeout_ms, 400, "");
DEFINE_int32(aero_connect_retry, 3, "");
DEFINE_int32(aero_tender_interval, 500, "Polling interval in milliseconds for cluster tender");
DEFINE_int32(aero_thread_pool_size, 16, "");

DEFINE_int64_counter(aerospike, aero_query_total, 0, "");
DEFINE_double_counter(aerospike, aero_query_cost, 0, "");

DEFINE_int64_counter(aerospike, aero_get, 0, "");
DEFINE_int64_counter(aerospike, aero_put, 0, "");
DEFINE_int64_counter(aerospike, aero_llist_add, 0, "");
DEFINE_int64_counter(aerospike, aero_llist_update, 0, "");
DEFINE_int64_counter(aerospike, aero_llist_add_all, 0, "");
DEFINE_int64_counter(aerospike, aero_llist_scan, 0, "");
DEFINE_int64_counter(aerospike, aero_llist_destroy, 0, "");
DEFINE_int64_counter(aerospike, aero_llist_remove, 0, "");
DEFINE_int64_counter(aerospike, aero_remove, 0, "");

DEFINE_int64_counter(aerospike, aero_fail_get, 0, "");
DEFINE_int64_counter(aerospike, aero_fail_put, 0, "");
DEFINE_int64_counter(aerospike, aero_fail_llist_add, 0, "");
DEFINE_int64_counter(aerospike, aero_fail_llist_update, 0, "");
DEFINE_int64_counter(aerospike, aero_fail_llist_add_all, 0, "");
DEFINE_int64_counter(aerospike, aero_fail_llist_scan, 0, "");
DEFINE_int64_counter(aerospike, aero_fail_llist_destroy, 0, "");
DEFINE_int64_counter(aerospike, aero_fail_llist_remove, 0, "");
DEFINE_int64_counter(aerospike, aero_fail_remove, 0, "");

const char *kAeroListMapK = "key";
const char *kAeroListMapV = "value";

Client::Client(const std::string &ips) {
  cluster_ips_ = ips;

  as_config config;
  as_config_init(&config);
  config.tender_interval = FLAGS_aero_tender_interval;
  config.thread_pool_size = FLAGS_aero_thread_pool_size;

  as_policies* p = &config.policies;
  p->read.timeout = FLAGS_aero_read_timeout_ms;
  p->write.timeout = FLAGS_aero_write_timeout_ms;
  p->apply.timeout = FLAGS_aero_write_timeout_ms;

  vector<string> ips_vec;
  base::SplitString(ips, ",", &ips_vec);
  CHECK(ips_vec.size());

  std::srand(std::time(0));
  std::random_shuffle(ips_vec.begin(), ips_vec.end());
  const string new_nodes = base::JoinStrings(ips_vec, ",");
  LOG(INFO) << "aero connect nodes:" << new_nodes;

  for (auto it = ips_vec.begin(); it != ips_vec.end(); ++it) {
    vector<string> ip_port;
    base::SplitString(*it, ":", &ip_port);
    CHECK_EQ(ip_port.size(), 2u);

    uint32 port = 0;
    if (base::StringToUint(ip_port[1], &port)) {
      as_config_add_host(&config, ip_port[0].c_str(), port);
    } else {
      LOG(WARNING) << "aero port to uint error:" << ip_port[1];
      continue;
    }
  }

  as_error err;
  aerospike_init(&as_, &config);
  int32 retry = FLAGS_aero_connect_retry;
  while (retry-- > 0) {
    if (aerospike_connect(&as_, &err) == AEROSPIKE_OK) {
      LOG(INFO) << "aero connect nodes succ:" << ips;
      break;
    } else {
      base::SleepForSeconds(3);
      LOG(ERROR) << base::StringPrintf("aerospike_connect() returned %d - %s", err.code, err.message);
    }
  }
  if (retry <= 0) {
    aerospike_destroy(&as_);
    LOG(FATAL) << base::StringPrintf("aerospike_connect() returned %d - %s", err.code, err.message);
    return;
  }
  ::google::FlushLogFiles(::google::INFO);
  return;
}


void Client::Close(void) {
  LOG(INFO) << "close client:" << cluster_ips_;
  as_error err;
  aerospike_close(&as_, &err);
  aerospike_destroy(&as_);
}


bool Client::GetData(const string &key, const vector<string> &bins, vector<string> *values,
                     const string &ns_name, const string &set_name) {
  CHECK_NOTNULL(values);
  values->clear();
  values->resize(bins.size());

  if (key.empty()) return true;

  COUNTERS_aerospike__aero_query_total.Increase(1);
  COUNTERS_aerospike__aero_get.Increase(1);
  bool ret = true;
  as_key as_key;
  as_key_init(&as_key, ns_name.c_str(), set_name.c_str(), key.c_str());

  as_record *rec = NULL;
  as_error err;
  serving_base::Timer timer;
  timer.Start();

  int ret_num = 0;
  const as_status rc = aerospike_key_get(&as_, &err, NULL, &as_key, &rec);
  if (rc == AEROSPIKE_OK) {
    if (as_record_numbins(rec) != 0) {
      for (auto i = 0u; i < bins.size(); ++i) {
        const as_bytes *v = as_record_get_bytes(rec, bins[i].c_str());
        if (v) {
          values->at(i) = string(reinterpret_cast<char *>(as_bytes_get(v)), as_bytes_size(v));
          ret_num++;
        }
      }
    }
    ret = true;
  } else if (rc == AEROSPIKE_ERR_RECORD_NOT_FOUND) {
    ret = true;
  } else {
    COUNTERS_aerospike__aero_fail_get.Increase(1);
    LOG(WARNING) << base::StringPrintf("aerospike_key_get() returned %d - %s, key:%s",
                                       err.code, err.message, key.c_str());
    ret = false;
  }
  COUNTERS_aerospike__aero_query_cost.Increase(timer.Stop());
  DLOG(INFO) << "aero get data, key:" << key << ", ret num:" << ret_num;

  as_record_destroy(rec);
  as_key_destroy(&as_key);
  return ret;
}


bool Client::SetData(const string &key, const string &bin, const string &value,
                     const string &ns_name, const string &set_name) {
  if (key.empty()) return true;

  COUNTERS_aerospike__aero_query_total.Increase(1);
  COUNTERS_aerospike__aero_put.Increase(1);
  bool ret = true;
  as_key as_key;
  as_key_init(&as_key, ns_name.c_str(), set_name.c_str(), key.c_str());

  as_record rec;
  as_record_inita(&rec, 1);

  serving_base::Timer timer;
  timer.Start();
  as_error err;

  if (as_record_set_raw(&rec, bin.c_str(), reinterpret_cast<const uint8_t *>(value.c_str()), value.size())) {
    const as_status rc = aerospike_key_put(&as_, &err, NULL, &as_key, &rec);
    if (rc == AEROSPIKE_OK) {
      ret = true;
    } else {
      COUNTERS_aerospike__aero_fail_put.Increase(1);
      LOG(WARNING) << base::StringPrintf("aerospike_key_put() returned %d - %s", err.code, err.message);
      ret = false;
    }
  } else {
    COUNTERS_aerospike__aero_fail_put.Increase(1);
    LOG(WARNING) << "set record error! key:" << key << ", bin:" << bin;
    ret = false;
  }
  COUNTERS_aerospike__aero_query_cost.Increase(timer.Stop());

  as_record_destroy(&rec);
  as_key_destroy(&as_key);
  return ret;
}


bool Client::AddListData(const string &key, const string &bin, const string &value, const int64 val_key,
                         const string &ns_name, const string &set_name, const int timeout) {
  if (key.empty()) return true;

  COUNTERS_aerospike__aero_query_total.Increase(1);
  COUNTERS_aerospike__aero_llist_add.Increase(1);
  bool ret = true;

  as_key as_key;
  as_key_init(&as_key, ns_name.c_str(), set_name.c_str(), key.c_str());

  as_ldt llist;
  if (!as_ldt_init(&llist, bin.c_str(), AS_LDT_LLIST, NULL)) {
    LOG(WARNING) << "unable to initialize ldt";
    as_ldt_destroy(&llist);
    as_key_destroy(&as_key);
    return false;
  }

  as_policy_apply policy;
  as_policy_apply_init(&policy);
  policy.timeout = timeout;

  as_bytes bytes;
  as_bytes_init_wrap(&bytes, (uint8_t*)value.c_str(), value.size(), false);

  as_hashmap map;
  as_hashmap_init(&map, 2);
  as_stringmap_set_int64((as_map *) &map, kAeroListMapK, val_key);
  as_stringmap_set_bytes((as_map *) &map, kAeroListMapV, &bytes);

  serving_base::Timer timer;
  timer.Start();
  as_error err;
  const as_status rc = aerospike_llist_add(&as_, &err, &policy, &as_key, &llist, (as_val *) &map);
  if (rc == AEROSPIKE_OK) {
    ret = true;
  } else {
    COUNTERS_aerospike__aero_fail_llist_add.Increase(1);
    LOG(WARNING) << base::StringPrintf("aerospike_llist_add() returned %d - %s, key:%s, bin:%s, val_key:%ld",
                                     err.code, err.message, key.c_str(), bin.c_str(), val_key);
    ret = false;
  }
  COUNTERS_aerospike__aero_query_cost.Increase(timer.Stop());

  as_bytes_destroy(&bytes);
  as_hashmap_destroy(&map);
  as_ldt_destroy(&llist);
  as_key_destroy(&as_key);

  return ret;
}


bool Client::UpdateListData(const string &key, const string &bin, const string &value, const int64 val_key,
                         const string &ns_name, const string &set_name, const int timeout) {
  if (key.empty()) return true;

  COUNTERS_aerospike__aero_query_total.Increase(1);
  COUNTERS_aerospike__aero_llist_update.Increase(1);
  bool ret = true;

  as_key as_key;
  as_key_init(&as_key, ns_name.c_str(), set_name.c_str(), key.c_str());

  as_ldt llist;
  if (!as_ldt_init(&llist, bin.c_str(), AS_LDT_LLIST, NULL)) {
    LOG(WARNING) << "unable to initialize ldt";
    as_ldt_destroy(&llist);
    as_key_destroy(&as_key);
    return false;
  }

  as_policy_apply policy;
  as_policy_apply_init(&policy);
  policy.timeout = timeout;

  as_bytes bytes;
  as_bytes_init_wrap(&bytes, (uint8_t*)value.c_str(), value.size(), false);

  as_hashmap map;
  as_hashmap_init(&map, 2);
  as_stringmap_set_int64((as_map *) &map, kAeroListMapK, val_key);
  as_stringmap_set_bytes((as_map *) &map, kAeroListMapV, &bytes);

  serving_base::Timer timer;
  timer.Start();
  as_error err;
  const as_status rc = aerospike_llist_update(&as_, &err, &policy, &as_key, &llist, (as_val *) &map);
  if (rc == AEROSPIKE_OK) {
    ret = true;
  } else {
    COUNTERS_aerospike__aero_fail_llist_update.Increase(1);
    LOG(WARNING) << base::StringPrintf("aerospike_llist_update() return %d - %s, key:%s, bin:%s, val_key:%ld",
                                       err.code, err.message, key.c_str(), bin.c_str(), val_key);
    ret = false;
  }
  COUNTERS_aerospike__aero_query_cost.Increase(timer.Stop());

  as_bytes_destroy(&bytes);
  as_hashmap_destroy(&map);
  as_ldt_destroy(&llist);
  as_key_destroy(&as_key);

  return ret;
}


bool Client::AddListData(const string &key, const string &bin, const vector<string> &values,
                         const vector<int64> &val_keys, const string &ns_name, const string &set_name,
                         const int timeout) {
  if (key.empty()) return true;
  if (values.empty()) return true;

  COUNTERS_aerospike__aero_query_total.Increase(1);
  COUNTERS_aerospike__aero_llist_add_all.Increase(1);
  bool ret = true;

  as_key as_key;
  as_key_init(&as_key, ns_name.c_str(), set_name.c_str(), key.c_str());

  as_ldt llist;
  if (!as_ldt_init(&llist, bin.c_str(), AS_LDT_LLIST, NULL)) {
    LOG(WARNING) << "unable to initialize ldt";
    as_ldt_destroy(&llist);
    as_key_destroy(&as_key);
    return false;
  }

  const int64 tick_key_default = base::GetTimestamp();
  const bool use_default = val_keys.size() == values.size() ? false : true;

  as_bytes *bytes = new as_bytes[values.size()];
  as_hashmap *map = new as_hashmap[values.size()];

  as_arraylist vals;
  as_arraylist_inita(&vals, values.size());
  for (auto i = 0u; i < values.size(); ++i) {
    as_bytes_init_wrap(&bytes[i], (uint8_t*)values[i].c_str(), values[i].size(), false);

    // value key
    const int64 tick_key = use_default ? (tick_key_default + i) : val_keys[i];
    as_hashmap_init(&map[i], 2);
    as_stringmap_set_int64((as_map *) &map[i], kAeroListMapK, tick_key);
    as_stringmap_set_bytes((as_map *) &map[i], kAeroListMapV, &bytes[i]);

    as_arraylist_append_map(&vals, (as_map *) &map[i]);
  }

  as_policy_apply policy;
  as_policy_apply_init(&policy);
  policy.timeout = timeout;

  serving_base::Timer timer;
  timer.Start();
  as_error err;
  const as_status rc = aerospike_llist_add_all(&as_, &err, &policy, &as_key, &llist, (as_list *)&vals);
  if (rc == AEROSPIKE_OK) {
    ret = true;
  } else {
    COUNTERS_aerospike__aero_fail_llist_add_all.Increase(1);
    LOG(WARNING) << base::StringPrintf("aerospike_llist_add_all() returned %d - %s, key:%s, bin:%s",
                                     err.code, err.message, key.c_str(), bin.c_str());
    ret = false;
  }
  COUNTERS_aerospike__aero_query_cost.Increase(timer.Stop());

  as_arraylist_destroy(&vals);
  as_ldt_destroy(&llist);
  as_key_destroy(&as_key);

  if (bytes) {
    delete[] bytes;
    bytes = NULL;
  }

  if (map) {
    delete[] map;
    map = NULL;
  }

  return ret;
}


bool Client::GetListData(const string &key, const string &bin, vector<string> *values, vector<int64> *extra,
                         const string &ns_name, const string &set_name) {
  CHECK_NOTNULL(values);
  values->clear();

  COUNTERS_aerospike__aero_query_total.Increase(1);
  COUNTERS_aerospike__aero_llist_scan.Increase(1);
  bool ret = true;
  as_key as_key;
  as_key_init(&as_key, ns_name.c_str(), set_name.c_str(), key.c_str());

  as_ldt *llist = as_ldt_new(bin.c_str(), AS_LDT_LLIST, NULL);
  // if (!as_ldt_init(&llist, bin.c_str(), AS_LDT_LLIST, NULL)) {
  if (!llist) {
    LOG(WARNING) << "unable to initialize ldt, bin:" << bin;
    as_ldt_destroy(llist);
    as_key_destroy(&as_key);
    return false;
  }

  serving_base::Timer timer;
  timer.Start();
  as_error err;
  as_list* p_list = NULL;
  const as_status rc = aerospike_llist_scan(&as_, &err, NULL, &as_key, llist, &p_list);
  if (rc == AEROSPIKE_OK) {
    if (p_list) {
      if (p_list->_.type != AS_LIST) {
        LOG(WARNING) << "return type is not list, type:" << p_list->_.type;
        as_ldt_destroy(llist);
        as_key_destroy(&as_key);
        return false;
      }

      const uint32_t returned_size = as_list_size(p_list);
      for (auto i = 0u; i < returned_size; ++i) {
        const as_map *map = as_list_get_map(p_list, i);
        if (extra) {
          as_string map_key;
          as_string_init(&map_key, const_cast<char *>(kAeroListMapK), false);
          const as_integer *v = as_integer_fromval(as_map_get(map, (as_val *)&map_key));
          extra->push_back(as_integer_toint(v));
          as_string_destroy(&map_key);
        }

        as_string map_key;
        as_string_init(&map_key, const_cast<char *>(kAeroListMapV), false);

        const as_bytes *v = as_bytes_fromval(as_map_get(map, (as_val *)&map_key));
        values->push_back(string(reinterpret_cast<char *>(as_bytes_get(v)), as_bytes_size(v)));
        as_string_destroy(&map_key);
      }
    }
    ret = true;
  } else if (rc == AEROSPIKE_ERR_RECORD_NOT_FOUND) {
    ret = true;
  } else {
    const string err_msg = err.message;
    if (err_msg.find("LDT-Bin Does Not Exist") != string::npos) {
      ret = true;
    } else {
      COUNTERS_aerospike__aero_fail_llist_scan.Increase(1);
      LOG(WARNING) << base::StringPrintf("aerospike_llist_scan() returned %d - %s, key:%s, bin:%s",
                                       err.code, err.message, key.c_str(), bin.c_str());
      ret = false;
    }
  }
  COUNTERS_aerospike__aero_query_cost.Increase(timer.Stop());
  DLOG(INFO) << "aero get list, key:" << key << ", bin:" << bin << ", ret num:" << values->size();

  as_list_destroy(p_list);
  as_ldt_destroy(llist);
  as_key_destroy(&as_key);

  return ret;
}


bool Client::ClearList(const string &key, const string &bin, const string &ns_name, const string &set_name) {
  COUNTERS_aerospike__aero_query_total.Increase(1);
  COUNTERS_aerospike__aero_llist_destroy.Increase(1);
  bool ret = true;
  as_key as_key;
  as_key_init(&as_key, ns_name.c_str(), set_name.c_str(), key.c_str());

  serving_base::Timer timer;
  timer.Start();

  as_ldt llist;
  if (as_ldt_init(&llist, bin.c_str(), AS_LDT_LLIST, NULL)) {
    as_error err;
    const as_status rc = aerospike_llist_destroy(&as_, &err, NULL, &as_key, &llist);
    if (rc == AEROSPIKE_OK) {
      ret = true;
    } else if (rc == AEROSPIKE_ERR_RECORD_NOT_FOUND) {
      ret = true;
    } else {
      COUNTERS_aerospike__aero_fail_llist_destroy.Increase(1);
      ret = false;
      LOG(WARNING) << base::StringPrintf("aerospike_llist_destroy() returned %d - %s, key:%s, bin:%s",
                                       err.code, err.message, key.c_str(), bin.c_str());
    }
  } else {
    ret = false;
    LOG(WARNING) << "unable to initialize ldt";
  }
  COUNTERS_aerospike__aero_query_cost.Increase(timer.Stop());

  as_ldt_destroy(&llist);
  as_key_destroy(&as_key);

  DLOG(INFO) << "del list ret:" << ret << ", key:" << key << ", bin:" << bin;
  return ret;
}


bool Client::DelListData(const string &key, const string &bin, const string &value, const int64 extra,
                         const string &ns_name, const string &set_name) {
  if (key.empty()) return true;

  COUNTERS_aerospike__aero_query_total.Increase(1);
  COUNTERS_aerospike__aero_llist_remove.Increase(1);
  bool ret = true;

  as_key as_key;
  as_key_init(&as_key, ns_name.c_str(), set_name.c_str(), key.c_str());

  as_ldt llist;
  if (!as_ldt_init(&llist, bin.c_str(), AS_LDT_LLIST, NULL)) {
    LOG(WARNING) << "unable to initialize ldt";
    as_ldt_destroy(&llist);
    as_key_destroy(&as_key);
    return false;
  }

  as_bytes bytes;
  as_bytes_init_wrap(&bytes, (uint8_t*)value.c_str(), value.size(), false);

  as_hashmap map;
  as_hashmap_init(&map, 2);
  as_stringmap_set_int64((as_map *) &map, kAeroListMapK, extra);
  as_stringmap_set_bytes((as_map *) &map, kAeroListMapV, &bytes);

  serving_base::Timer timer;
  timer.Start();
  as_error err;
  if (aerospike_llist_remove(&as_, &err, NULL, &as_key, &llist, (as_val *) &map) != AEROSPIKE_OK) {
    COUNTERS_aerospike__aero_fail_llist_remove.Increase(1);
    LOG(WARNING) << base::StringPrintf("aerospike_llist_remove() returned %d - %s, key:%s, bin:%s",
                                     err.code, err.message, key.c_str(), bin.c_str());
    ret = false;
  }
  COUNTERS_aerospike__aero_query_cost.Increase(timer.Stop());

  as_bytes_destroy(&bytes);
  as_hashmap_destroy(&map);
  as_ldt_destroy(&llist);
  as_key_destroy(&as_key);

  DLOG(INFO) << "del list data succ. key:" << key << ", bin:" << bin << ", extra:" << extra;
  return ret;
}


bool Client::DelKey(const string &key, const string &ns_name, const string &set_name) {
  COUNTERS_aerospike__aero_query_total.Increase(1);
  COUNTERS_aerospike__aero_remove.Increase(1);
  as_key as_key;
  as_key_init(&as_key, ns_name.c_str(), set_name.c_str(), key.c_str());

  serving_base::Timer timer;
  timer.Start();

  as_error err;
  const as_status rc = aerospike_key_remove(&as_, &err, NULL, &as_key);
  bool ret = true;
  if (rc == AEROSPIKE_OK) {
    ret = true;
  } else if (rc == AEROSPIKE_ERR_RECORD_NOT_FOUND) {
    ret = true;
  } else {
    COUNTERS_aerospike__aero_fail_remove.Increase(1);
    ret = false;
    LOG(WARNING) << base::StringPrintf("aerospike_key_remove() returned %d - %s, key:%s",
                                       err.code, err.message, key.c_str());
  }

  COUNTERS_aerospike__aero_query_cost.Increase(timer.Stop());
  as_key_destroy(&as_key);

  DLOG(INFO) << "del key ret:" << ret << ", key:" << key;
  return ret;
}
}
}
