#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "serving_base/utility/timer.h"
#include "reco/base/aerospike_c/api/client.h"

using boost::shared_ptr;
using std::string;
using std::vector;

shared_ptr<reco::aero::Client> g_aero_cli;

const string key = "app-iflow-1999999999999";
const string str_bin = "test-bin-";
const string str_val = "test-val-";
const string list_bin = "list-bin-";
const string list_val = "list-val-";

DEFINE_string(aero_ips, "127.0.0.1:3000", "");
DEFINE_string(key, "", "");
DEFINE_string(bin, "", "");
DEFINE_string(type, "get", "get or del");

void SetData(const int mark) {
  string idx = base::IntToString(mark);
  bool ret = g_aero_cli->SetData(key, str_bin + idx, str_val + idx);
  LOG(INFO) << "set data:" << ret
            << ", key:" << key
            << ", bin:" << str_bin + idx
            << ", val:" << str_val + idx;
  return;
}


void GetData(const int mark) {
  string idx = base::IntToString(mark);
  vector<string> bins;
  bins.push_back(str_bin + idx);
  vector<string> values;

  bool ret = g_aero_cli->GetData(key, bins, &values);
  LOG(INFO) << "get data ret:" << ret;

  for (auto i = 0u; i < bins.size(); ++i) {
    LOG(INFO) << "val is key:" << key
              << ", bin:" << bins[i]
              << ", val:" << values[i];
  }
  return;
}


void SetListData(const int mark) {
  string idx = base::IntToString(mark);
  vector<string> values;
  for (auto i = 0; i < 10; ++i) {
    string value = list_val + idx + "==" + base::IntToString(i);
    g_aero_cli->AddListData(key, list_bin + idx, value);
    LOG(INFO) << "add list data, key:" << key
              << ", bin:" << list_bin + idx
              << ", val:" << value;
  }

  return;
}


void GetListData(string key, string bin) {
  vector<string> values;
  vector<int64> extras;
  if (g_aero_cli->GetListData(key, bin, &values, &extras)) {
    for (auto i = 0u; i < values.size(); ++i) {
      LOG(INFO) << "get list data, valus size:" << values.size()
                << ", idx:" << i
                << ", key:" << key
                << ", bin:" << bin
                << ", val:" << values[i]
                << ", extra:" << extras[i];
    }
  } else {
    LOG(ERROR) << "get list data err.";
  }

  return;
}


int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "aeroapike example");
  g_aero_cli = shared_ptr<reco::aero::Client>(new reco::aero::Client(FLAGS_aero_ips));

  if (FLAGS_type == "get") {
    GetListData(FLAGS_key, FLAGS_bin);
  }

  if (FLAGS_type == "del") {
    g_aero_cli->DelKey(FLAGS_key);
  }

  return 0;
}

