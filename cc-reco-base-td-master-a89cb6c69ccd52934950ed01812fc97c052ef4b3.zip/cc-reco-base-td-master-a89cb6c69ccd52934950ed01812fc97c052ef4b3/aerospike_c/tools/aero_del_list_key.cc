#include <string>
#include <vector>
#include <boost/shared_ptr.hpp>

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_util.h"
#include "base/file/file_util.h"
#include "serving_base/utility/timer.h"
#include "reco/base/aerospike_c/api/client.h"

using boost::shared_ptr;
using std::string;
using std::vector;

shared_ptr<reco::aero::Client> g_aero_temp_cli;
shared_ptr<reco::aero::Client> g_aero_cli;

DEFINE_string(aero_temp_ips, "127.0.0.1:3000", "");
DEFINE_string(aero_durable_list_ips, "127.0.0.1:3000", "");
DEFINE_string(aero_temp_ns, "", "");
DEFINE_string(aero_durable_list_ns, "", "");
DEFINE_string(aero_temp_set, "data", "");
DEFINE_string(aero_durable_list_set, "data", "");
DEFINE_string(keys_file, "keys.txt", "");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "aeroapike example");

  g_aero_temp_cli = shared_ptr<reco::aero::Client>(new reco::aero::Client(FLAGS_aero_temp_ips));
  g_aero_cli = shared_ptr<reco::aero::Client>(new reco::aero::Client(FLAGS_aero_durable_list_ips));

  vector<string> lines;
  if (!base::file_util::ReadFileToLines(FLAGS_keys_file, &lines)) {
    LOG(ERROR) << "read file fail:" << FLAGS_keys_file;
    return 1;
  }

  string key;
  for (auto i = 0u; i < lines.size(); ++i) {
    key = lines[i];
    base::TrimWhitespaces(&key);
    if (!key.empty()) {
      g_aero_temp_cli->DelKey(key, FLAGS_aero_temp_ns, FLAGS_aero_temp_set);
      g_aero_cli->DelKey(key, FLAGS_aero_durable_list_ns, FLAGS_aero_durable_list_set);
      LOG(INFO) << "del list key:" << key;
    }
  }

  return 0;
}

