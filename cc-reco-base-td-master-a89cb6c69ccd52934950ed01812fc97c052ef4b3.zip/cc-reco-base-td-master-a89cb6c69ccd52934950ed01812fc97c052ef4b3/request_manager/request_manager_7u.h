#pragma once
#include <string>
#include <typeinfo>
#include <unordered_map>
#include <memory>
#include <google/protobuf/message.h>

#include "base/common/basic_types.h"
#include "base/file/file_path.h"
#include "base/thread/blocking_var.h"
#include "base/thread/sync.h"
#include "base/thread/thread_pool.h"
#include "base/time/timestamp.h"

// 请求队列管理模块的c++11版
// 由于没有reco/base库权限，先放在这个目录下

namespace reco {
namespace common {

struct StReqParam {
  const ::google::protobuf::Message* request;
  ::google::protobuf::Message* response;
  ::google::protobuf::Closure* done;
  int64 time_stamp;

  StReqParam() {
    request = NULL;
    response = NULL;
    done = NULL;
    time_stamp = 0;
  }

  StReqParam(const ::google::protobuf::Message *req, ::google::protobuf::Message *resp,
             ::google::protobuf::Closure *closure_done, const int64 stamp) {
    request = req;
    response = resp;
    done = closure_done;
    time_stamp = stamp;
  }
};


class ReqFuncMapBase {
 public:
  std::string req_type_;

  std::string GetReqType() {
    return req_type_;
  }

  virtual void Run(StReqParam& param) {}
  virtual ~ReqFuncMapBase() {}
};


template<class SERVER, class REQ, class RESP>
class ReqFuncMap: public ReqFuncMapBase {
 public:
  virtual ~ReqFuncMap() {}

  typedef void (SERVER::*Func) (const REQ* req, RESP* resp, ::google::protobuf::Closure* done);

  ReqFuncMap(SERVER* obj, Func funcptr) {
    req_type_ = typeid(REQ).name();
    funcptr_ = funcptr;
    obj_ = obj;
  }

  virtual void Run(StReqParam& param) {
    const REQ* req = static_cast<const REQ*>(param.request);
    RESP* resp = static_cast<RESP*>(param.response);
    (obj_->*funcptr_)(req, resp, param.done);
  }

 private:
  SERVER* obj_;
  Func funcptr_;
};


class RequestManager {
 public:
  RequestManager() {}
  RequestManager(int thread_num, int64 timeout_ms) {
    Init(thread_num, timeout_ms);
  }
  void Init(int thread_num, int64 timeout_ms);

  // 请求类型->处理函数的映射应该在初始化时就注册好，所以本函数非线程安全
  void RegisterReqFuncMap(ReqFuncMapBase* ins);

  void AddReqTask(const ::google::protobuf::Message *req, ::google::protobuf::Message *resp,
                  ::google::protobuf::Closure *closure_done);

  void Process(StReqParam param);

 private:
  std::unordered_map<std::string, std::unique_ptr<ReqFuncMapBase> > req_func_map_;
  std::shared_ptr<thread::ThreadPool> thread_pool_;
  thread::Mutex mutex_;
  int64 timeout_ms_;
};

}  // namespace common
}  // namespace reco
