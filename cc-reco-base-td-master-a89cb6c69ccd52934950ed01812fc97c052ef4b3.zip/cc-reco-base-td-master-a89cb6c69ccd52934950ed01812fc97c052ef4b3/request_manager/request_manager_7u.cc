#include "reco/base/request_manager/request_manager_7u.h"
#include "base/common/logging.h"
#include "base/common/closure.h"

DEFINE_int64_counter(req_manager, req_manager_proc_num, 0, "");
DEFINE_int64_counter(req_manager, req_manager_avg_wait_time, 0, "");
DEFINE_int64_counter(req_manager, req_manager_overload_num, 0, "");

namespace reco {
namespace common {

void RequestManager::Init(int thread_num, int64 timeout_ms) {
  thread_pool_ = std::make_shared<thread::ThreadPool>(thread_num);
  timeout_ms_ = timeout_ms;
}

void RequestManager::RegisterReqFuncMap(ReqFuncMapBase* ins) {
  req_func_map_[ins->GetReqType()] = std::unique_ptr<ReqFuncMapBase>(ins);
  LOG(INFO) << "register req func map, req type:" << ins->GetReqType();
}

void RequestManager::AddReqTask(const ::google::protobuf::Message *req, ::google::protobuf::Message *resp,
                                ::google::protobuf::Closure *closure_done) {
  StReqParam param(req, resp, closure_done, base::GetTimestamp());
  thread::AutoLock lock(&mutex_);
  thread_pool_->AddTask(NewCallback(this, &RequestManager::Process, param));
}

void RequestManager::Process(StReqParam param) {
  int64 time_delta = base::GetTimestamp() - param.time_stamp;
  COUNTERS_req_manager__req_manager_proc_num.Increase(1);
  COUNTERS_req_manager__req_manager_avg_wait_time.Increase(time_delta);
  if (time_delta > timeout_ms_ * 1000) {
    LOG(ERROR) << "server overload! wait time:" << time_delta << " us";
    COUNTERS_req_manager__req_manager_overload_num.Increase(1);
    return;
  }

  const std::string req_type = typeid(*param.request).name();
  if (req_func_map_.find(req_type) == req_func_map_.end()) {
    LOG(ERROR) << "invalid request type! req type:" << req_type;
    return;
  }

  req_func_map_.at(req_type)->Run(param);
}

}  // namespace common
}  // namespace reco
