#pragma once
#include <cygnet/cygnet.h>
#include <deque>
#include <vector>
#include <string>

#include "base/thread/sync.h"
#include "base/thread/thread.h"
#include "base/common/logging.h"

namespace reco {
namespace http_communicator {

class HttpCommunicator;

class HttpConnectionPool {
 public:
  HttpConnectionPool() : stop_(false) {}
  ~HttpConnectionPool() {}
  bool Init(int connection_num);
  bool Connect();
  void CloseAllAndDestroy();
  size_t GetAvailableConnSize() {
    return comm_queue_.size();
  }
  HttpCommunicator* GetConnectionFromPool();
  HttpCommunicator* AddNewCommunicator();
  void ReleaseConnectionToPool(HttpCommunicator* comm);
  void DestroyConnAndReconnect(HttpCommunicator* comm);
 private:
  cygnet::HttpTransport* http_transport_;
  std::string GetConnectionAddr();
  int thread_num_;
  int connection_num_;
  int connect_timeout_;
  std::deque<HttpCommunicator*> comm_queue_;
  std::vector<HttpCommunicator*> all_connections_;
  thread::Mutex mutex_;
  bool stop_;
};
}
}
