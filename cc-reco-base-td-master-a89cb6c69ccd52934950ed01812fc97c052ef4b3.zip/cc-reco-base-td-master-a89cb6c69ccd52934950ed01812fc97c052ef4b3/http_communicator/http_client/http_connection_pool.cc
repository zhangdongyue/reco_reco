#include "reco/base/http_communicator/http_client/http_connection_pool.h"
#include "reco/base/http_communicator/http_client/http_communicator.h"
#include "reco/base/vipserver/api/vipserver_manager.h"
#include "base/random/pseudo_random.h"
#include "base/strings/string_split.h"
#include "base/time/timestamp.h"

DEFINE_int32(http_connection_thread_num, 2, "http connection thread num");
DEFINE_int32(http_connect_timeout, 30000, "http connect timeout");
DEFINE_string(http_connection_addr, "127.0.0.1:80", "http connection addr");
DEFINE_bool(http_connection_addr_vipserver, false, "connection addr vipserver");
DEFINE_bool(http_short_connection, false, "connection short connect");

namespace reco {
namespace http_communicator {

bool HttpConnectionPool::Init(int connection_num) {
  connection_num_ = connection_num;
  cygnet::HttpTransport::Config transport_config;
  transport_config._threadNum = FLAGS_http_connection_thread_num;
  transport_config._maxBody = cygnet::MAX_HTTP_BODY_NO_LIMIT;
  http_transport_ = new cygnet::HttpTransport(false);

  if (!http_transport_->Init(transport_config)) {
    LOG(ERROR) << "init http transport failed";
    return false;
  }
  LOG(INFO) << "HttpConnectionPool Init succ.";
  return true;
}

bool HttpConnectionPool::Connect() {
  if (http_transport_ != NULL) {
    if (!http_transport_->Start()) {
      LOG(ERROR) << "start http transport failed";
      return false;
    }
    LOG(INFO) << "http transport started.";
    int connect_timeout = FLAGS_http_connect_timeout;
    for (int i = 0; i < connection_num_; ++i) {
      std::string addr = GetConnectionAddr();
      cygnet::HttpClientConnection* conn =
          http_transport_->CreateConnection(addr, "", connect_timeout);
      if (conn == NULL) {
        LOG(ERROR) << "create connection failed";
        return false;
      }
      HttpCommunicator* comm = new HttpCommunicator();
      comm->SetHttpConnection(conn);
      comm_queue_.push_back(comm);
      all_connections_.push_back(comm);
    }
  } else {
    LOG(ERROR) << "start http transport failed";
    return false;
  }
  if ((int)comm_queue_.size() == connection_num_) {
    LOG(INFO) << "HttpConnectionPool connect succ.";
    google::FlushLogFiles(0);
    return true;
  } else {
    LOG(ERROR) << "connection not enough";
    return false;
  }
}

HttpCommunicator* HttpConnectionPool::AddNewCommunicator() {
  HttpCommunicator* comm = new HttpCommunicator();
  std::string addr = GetConnectionAddr();
  int connect_timeout = FLAGS_http_connect_timeout;
  cygnet::HttpClientConnection* conn =
      http_transport_->CreateConnection(addr, "", connect_timeout);
  if (conn != NULL) {
    comm->SetHttpConnection(conn);
    thread::AutoLock lock(&mutex_);
    all_connections_.push_back(comm);
    return comm;
  } else {
    delete comm;
    return NULL;
  }
}

void HttpConnectionPool::CloseAllAndDestroy() {
  stop_ = true;
  comm_queue_.clear();
  if (http_transport_ != NULL) {
    http_transport_->Stop();
    http_transport_->Destroy();
    delete http_transport_;
    http_transport_ = NULL;
  }
  thread::AutoLock lock(&mutex_);
  for (size_t i = 0; i < all_connections_.size(); ++i) {
    HttpCommunicator* comm = all_connections_.at(i);
    if (comm != NULL) {
      cygnet::HttpClientConnection* conn = comm->GetHttpConnection();
      if (conn != NULL) {
        conn->Destroy();
      }
      delete comm;
    }
  }
  all_connections_.clear();
  LOG(INFO) << "CloseAllAndDestroy http connection finished.";
}

HttpCommunicator* HttpConnectionPool::GetConnectionFromPool() {
  if (stop_) {
    return NULL;
  }
  if (comm_queue_.size() > 0) {
    thread::AutoLock lock(&mutex_);
    HttpCommunicator* comm = comm_queue_.front();
    comm_queue_.pop_front();
    return comm;
  }
  LOG(INFO) << "Not available connection.";
  return NULL;
}

void HttpConnectionPool::DestroyConnAndReconnect(HttpCommunicator* comm) {
  if (comm == NULL) {
    return;
  }
  int connect_timeout = FLAGS_http_connect_timeout;
  std::string addr = GetConnectionAddr();
  cygnet::HttpClientConnection* conn = comm->GetHttpConnection();
  if (conn != NULL) {
    conn->Destroy();
  }
  cygnet::HttpClientConnection* new_conn =
      http_transport_->CreateConnection(addr, "", connect_timeout);
  comm->SetHttpConnection(new_conn);
}

void HttpConnectionPool::ReleaseConnectionToPool(HttpCommunicator* comm) {
  if (comm == NULL || stop_) {
    return;
  } else {
    if (!FLAGS_http_short_connection) {
      thread::AutoLock lock(&mutex_);
      comm_queue_.push_back(comm);
    } else {
      cygnet::HttpClientConnection* conn = comm->GetHttpConnection();
      if (conn != NULL) {
        if (!conn->IsClosed()) {
          conn->Close();
        }
        conn->Destroy();
      }
      std::string addr = GetConnectionAddr();
      int connect_timeout = FLAGS_http_connect_timeout;
      cygnet::HttpClientConnection* new_conn =
          http_transport_->CreateConnection(addr, "", connect_timeout);
      comm->SetHttpConnection(new_conn);
      thread::AutoLock lock(&mutex_);
      comm_queue_.push_back(comm);
    }
  }
}

std::string HttpConnectionPool::GetConnectionAddr() {
  if (FLAGS_http_connection_addr_vipserver) {
    if (!FLAGS_http_connection_addr.empty()) {
      std::string ip_list;
      if (reco::vipserver::VSClientMgrIns::instance().GetAllValidIpPortStr(FLAGS_http_connection_addr,
                                                                           5000,
                                                                           &ip_list)) {
        std::vector<std::string> ip_vec;
        base::SplitString(ip_list, ",", &ip_vec);
        if (ip_vec.size() > 0) {
          base::PseudoRandom random(base::GetTimestamp());
          uint64 ips_pos = random.GetUint64LT(ip_vec.size());
          ips_pos = (ips_pos + 1) % ip_vec.size();
          std::vector<std::string> field_vec;
          base::SplitString(ip_vec[ips_pos], ":", &field_vec);
          if (field_vec.size() > 1) {
            std::string addr = field_vec[0] + ":" + field_vec[1];
            LOG(INFO) << "GetConnectionAddr : " << addr;
            return addr;
          }
        }
      }
    }
  } else {
    return FLAGS_http_connection_addr;
  }
  LOG(ERROR) << "GetConnectionAddr fail";
  return std::string("");
}
}
}
