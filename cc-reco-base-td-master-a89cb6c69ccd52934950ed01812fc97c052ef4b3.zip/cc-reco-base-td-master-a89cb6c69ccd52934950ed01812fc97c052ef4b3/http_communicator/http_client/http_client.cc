#include "reco/base/http_communicator/http_client/http_client.h"

namespace reco {
namespace http_communicator {

DEFINE_int32(http_connection_num, 50, "http connection num");

void HttpClient::Init() {
  if (conn_pool_ == NULL) {
    conn_pool_ = new HttpConnectionPool();
  }
  conn_pool_->Init(FLAGS_http_connection_num);
  LOG(INFO) << "HttpClient Init finished.";
}

void HttpClient::Start() {
  if (!started_) {
    conn_pool_->Connect();
    started_ = true;
    LOG(INFO) << "HttpClient started.";
  }
}

void HttpClient::Stop() {
  if (started_) {
    conn_pool_->CloseAllAndDestroy();
    started_ = false;
    LOG(INFO) << "HttpClient stoped.";
  }
}

HttpCommunicator* HttpClient::GetCommunicator() {
  if (conn_pool_ == NULL) {
    return NULL;
  }
  HttpCommunicator* comm;
  comm = conn_pool_->GetConnectionFromPool();
  if (comm != NULL) {
    cygnet::HttpClientConnection* conn = comm->GetHttpConnection();
    if (conn != NULL) {
      if (conn->IsClosed()) {
        conn_pool_->DestroyConnAndReconnect(comm);
      }
    }
    return comm;
  } else {
    HttpCommunicator* new_comm = conn_pool_->AddNewCommunicator();
    return new_comm;
  }
}

void HttpClient::ReleaseCommunicator(HttpCommunicator* comm) {
  if (conn_pool_ == NULL) {
    return;
  }
  if (comm != NULL) {
    cygnet::HttpClientConnection* conn = comm->GetHttpConnection();
    if (conn != NULL) {
      if (conn->IsClosed()) {
        conn_pool_->DestroyConnAndReconnect(comm);
      }
    }
    conn_pool_->ReleaseConnectionToPool(comm);
  }
}
}
}
