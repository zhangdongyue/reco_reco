#pragma once
#include <cygnet/cygnet.h>
#include <string>
#include "serving_base/utility/timer.h"
#include "base/thread/sync.h"
#include "base/time/time.h"
#include "base/common/logging.h"

namespace reco {
namespace http_communicator {

class TimedPacketHandler : public cygnet::HttpPacketHandler {
 public:
  TimedPacketHandler() : mPacket(NULL), stop_(false) {}

  ~TimedPacketHandler() {
    if (mPacket != NULL) {
      mPacket->Free();
      mPacket = NULL;
    }
  }

 public:
  void StartTimer() {
    timer_.Start();
  }
  void SetTimeout(int timeout) {
    timeout_ms_ = timeout;
  }
  bool Wait(cygnet::Packet** packet);

  void Reset() {
    thread::AutoLock lock(&mMutex);
    // 若 mPacket 非空, 则说明上次的结果包超时被丢弃, 释放上次结果包的资源
    if (mPacket != NULL) {
      mPacket->Free();
      mPacket = NULL;
    }
  }

  void Stop() {
    stop_ = true;
  }

  void SetResponseTime(int res_time) {
    response_time_ = res_time;
  }

  int GetResponseTime() {
    return response_time_;
  }

 private:
  virtual bool OnPacket(cygnet::HttpConnection& conn, cygnet::Packet& packet);
  bool CheckTimeout() {
    if (timer_.Stop() < timeout_ms_ * base::Time::kMicrosecondsPerMillisecond) {
      return false;
    } else {
      return true;
    }
  }

 private:
  mutable thread::Mutex mMutex;
  serving_base::Timer timer_;
  int timeout_ms_;
  int response_time_;
  cygnet::Packet* mPacket;
  bool stop_;
};

class HttpCommunicator {
 public:
  HttpCommunicator() : conn_(NULL), serial_number_(0) {
    handler_ = new TimedPacketHandler();
  }
  ~HttpCommunicator() {
    if (handler_ != NULL) {
      handler_->Stop();
      delete handler_;
      handler_ = NULL;
    }
  }
  // timeout 单位为毫秒
  bool AsyncSendHttpRequest(std::string request_id,
                            std::string uri,
                            std::string body,
                            int req_timeout);
  bool GetHttpResponseContent(std::string* responseContent);
  int GetResponseTime();
  void SetHttpConnection(cygnet::HttpClientConnection* conn) {
    if (conn != NULL) {
      conn_ = conn;
    }
  }
  cygnet::HttpClientConnection* GetHttpConnection() {
    return conn_;
  }
  TimedPacketHandler* GetHandler() {
    return handler_;
  }

  uint32_t GetSerialNumber() {
    return serial_number_;
  }

  void IncreaseSerialNumber() {
    ++serial_number_;
  }
 private:
  cygnet::HttpClientConnection* conn_;
  TimedPacketHandler* handler_;
  std::string request_id_;
  uint32_t serial_number_;
};
}
}
