#pragma once
#include <cygnet/cygnet.h>
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "reco/base/http_communicator/http_client/http_communicator.h"
#include "reco/base/http_communicator/http_client/http_connection_pool.h"
#include "base/thread/blocking_var.h"
#include "reco/base/common/singleton.h"

namespace reco {
namespace http_communicator {

class HttpClient {
 public:
  HttpClient() : conn_pool_(NULL), started_(false) {}
  ~HttpClient() {
    if (conn_pool_ != NULL) {
      delete conn_pool_;
    }
  }
  void Init();
  void Start();
  void Stop();
  HttpCommunicator* GetCommunicator();
  void ReleaseCommunicator(HttpCommunicator* comm);
 private:
  HttpConnectionPool* conn_pool_;
  bool started_;
};

typedef reco::common::singleton_default<HttpClient> HttpClientIns;
}
}
