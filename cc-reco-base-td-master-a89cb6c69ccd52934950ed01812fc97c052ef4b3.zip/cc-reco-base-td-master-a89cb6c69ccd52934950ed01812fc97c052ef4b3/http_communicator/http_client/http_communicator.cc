#include <string>
#include <vector>
#include "reco/base/http_communicator/http_client/http_communicator.h"

namespace reco {
namespace http_communicator {

bool TimedPacketHandler::Wait(cygnet::Packet** packet) {
  if (packet == NULL) {
    return false;
  }
  while (!CheckTimeout() && mPacket == NULL && !stop_) {
  }
  if (stop_) {
    return false;
  }
  if (mPacket != NULL) {
    thread::AutoLock lock(&mMutex);
    *packet = mPacket;
    mPacket = NULL;
    return true;
  }
  return false;
}

bool TimedPacketHandler::OnPacket(cygnet::HttpConnection& conn, cygnet::Packet& packet) {
  thread::AutoLock lock(&mMutex);
  mPacket = &packet;
  response_time_ = timer_.Stop() / 1000;
  return true;
}

bool HttpCommunicator::AsyncSendHttpRequest(std::string request_id,
                                            std::string uri,
                                            std::string body,
                                            int req_timeout) {
  request_id_ = request_id;
  cygnet::HttpRequestPacket* requestPacket = cygnet::HttpPacketFactory::CreateRequest();
  requestPacket->SetVersion(cygnet::HV_10);
  requestPacket->SetMethod(cygnet::HM_GET);
  requestPacket->SetUri(uri);
  requestPacket->AppendBody(body.c_str(), body.size());
  handler_->Reset();
  handler_->SetTimeout(req_timeout);
  handler_->StartTimer();
  handler_->SetResponseTime(req_timeout);
  if (!conn_->AsyncRequest(*requestPacket, req_timeout, *handler_)) {
    LOG(ERROR) << "request packet failed, request_id : " << request_id_;
    requestPacket->Free();
    return false;
  }
  return true;
}

bool HttpCommunicator::GetHttpResponseContent(std::string* responseContent) {
  if (responseContent == NULL) {
    return false;
  }
  cygnet::Packet* packet = NULL;
  if (handler_->Wait(&packet)) {
    if (!packet->IsCmdPacket()) {
      cygnet::HttpResponsePacket* responsePacket =
          dynamic_cast<cygnet::HttpResponsePacket*>(packet);
      if (responsePacket != NULL) {
        if (responsePacket->GetStatusCode() != 200) {
          LOG(ERROR) << "response status != 200, request_id : " << request_id_;
          return false;
        }
        const std::vector<char>& msg = responsePacket->GetBody();
        responseContent->insert(responseContent->begin(),
                                msg.begin(), msg.end());
        responsePacket->Free();
        return true;
      }
    } else {
      cygnet::CmdPacket* cmdPacket = dynamic_cast<cygnet::CmdPacket*>(packet);
      if (cmdPacket == NULL) {
        LOG(ERROR) << "cmdPacket is null";
      }
      int type = cmdPacket->GetType();
      LOG(ERROR) << "recv cmd packet, request_id : " << request_id_ << " type : " << type;
      packet->Free();
    }
  } else {
    LOG(ERROR) << "response timeout, request_id : " << request_id_;
  }
  return false;
}
int HttpCommunicator::GetResponseTime() {
  return handler_->GetResponseTime();
}
}
}
