#include "reco/base/http_communicator/http_server/http_server.h"

namespace reco {
namespace http_communicator {

void ProcessPacket::OnProcessComplete(std::string reco_id) {
  if (request_packet_ != NULL) {
    request_packet_->Free();
  }
  SendResponse(reco_id);
}

void ProcessPacket::SendResponse(std::string reco_id) {
  if (server_conn_ == NULL || response_packet_ == NULL) {
    LOG(ERROR) << "connection or response packge null. reco_id : " << reco_id;
    return;
  }
  if (server_conn_->IsClosed()) {
    LOG(ERROR) << "connection closed, not send response. reco_id : " << reco_id;
    response_packet_->Free();
    server_conn_->Destroy();
    LOG(ERROR) << "connection destroy after all response replied. reco_id : " << reco_id;
    return;
  }
  if (!server_conn_->Reply(*response_packet_)) {
    LOG(ERROR) << "send packet failed reco_id : " << reco_id;
    response_packet_->Free();
  } else {
    LOG(INFO) << "send response package succ. reco_id : " << reco_id;
  }
}

bool ServerHttpPacketHandler::OnPacket(cygnet::HttpConnection& conn, cygnet::Packet& packet) {
  cygnet::HttpServerConnection* serverConn =
      dynamic_cast<cygnet::HttpServerConnection*>(&conn);
  if (serverConn == NULL) {
    LOG(ERROR) << "connection is null";
    return false;
  }

  if (packet.IsCmdPacket()) {
    cygnet::CmdPacket* cmdPacket = dynamic_cast<cygnet::CmdPacket*>(&packet);
    if (cmdPacket == NULL) {
      LOG(ERROR) << "cmdPacket is null";
      return false;
    }
    int type = cmdPacket->GetType();
    switch (type) {
      case cygnet::CmdPacket::CT_CONNECTION_CLOSED:
        LOG(ERROR) << "connection closed";
        break;
      case cygnet::CmdPacket::CT_CONNECT_ERROR:
        LOG(ERROR) << "connect error";
        break;
      case cygnet::CmdPacket::CT_CONNECT_TIMEOUT:
        LOG(ERROR) << "connect timeout";
        break;
      case cygnet::CmdPacket::CT_HTTP_KEEPALIVE_TIMEOUT:
        LOG(ERROR) << "http keepalive timeout";
        break;
      case cygnet::CmdPacket::CT_HTTP_IDLE_TIMEOUT:
        LOG(ERROR) << "http idle timeout";
        break;
      default:
        LOG(ERROR) << "connection error : " << type;
        break;
    }
    if (serverConn->IsAllResponseReplied()) {
      serverConn->Destroy();
      LOG(ERROR) << "connection destroy due to cmdpacket received.";
    } else {
      serverConn->Close();
      LOG(ERROR) << "connection closed due to cmdpacket received.";
    }
    packet.Free();
    return false;
  }

  cygnet::HttpRequestPacket* requestPacket =
      dynamic_cast<cygnet::HttpRequestPacket*>(&packet);
  if (requestPacket == NULL) {
    LOG(ERROR) << "request Packet is null";
    return false;
  }
  ProcessPacketPtr process_packet(new ProcessPacket());
  process_packet->request_packet_ = requestPacket;
  cygnet::HttpResponsePacket* responsePacket = cygnet::HttpPacketFactory::CreateResponse();
  process_packet->response_packet_ = responsePacket;
  process_packet->server_conn_ = serverConn;
  process_queue_->Put(process_packet);
  return true;
}

bool HttpServer::Init(const std::string& spec, int threadCount,
                      int keepalive, int idle, bool isolateAcceptorThread, int backlog) {
  // cygnet::Logger::SetLogger(http_server_logger_);
  cygnet::HttpTransport::Config transportConfig;
  transportConfig._threadNum = threadCount;
  transportConfig._isolateAcceptorThread = isolateAcceptorThread;
  transportConfig._maxBody = cygnet::MAX_HTTP_BODY_NO_LIMIT;
  if (!http_transport_->Init(transportConfig)) {
    LOG(ERROR) << "transport init failed";
    return false;
  }
  http_acceptor_ = http_transport_->CreateAcceptor();
  if (http_acceptor_ == NULL) {
    LOG(ERROR) << "create acceptor failed";
    return false;
  }
  cygnet::TcpListenSocket* socket = cygnet::SocketFactory::CreateTcpListenSocket(spec);
  if (socket == NULL) {
    LOG(ERROR) << "create socket failed";
    return false;
  }
  if (!socket->SetNonBlocking(true) || !socket->SetCloseExec(true)) {
    LOG(ERROR) << "set non-blocking or close-exec failed";
    return false;
  }
  if (!socket->Listen(backlog)) {
    LOG(ERROR) << "listen socket failed";
    return false;
  }
  http_acceptor_->SetListenSocket(*socket);

  cygnet::HttpAcceptor::Config acceptorConfig;
  acceptorConfig._httpPacketHandler = pack_handler_;
  acceptorConfig._keepAliveTimeout = keepalive;
  acceptorConfig._idleTimeout = idle;
  acceptorConfig._maxBody = cygnet::MAX_HTTP_BODY_NO_LIMIT;

  if (!http_acceptor_->Start(acceptorConfig)) {
    LOG(ERROR) << "start acceptor failed";
    return false;
  }

  LOG(INFO) << "HttpServer Init Succ.";
  return true;
}

void HttpServer::Run() {
  http_transport_->Start();
  LOG(INFO) << "HttpServer Started.";
}

bool HttpServer::Stop() {
  stop_ = true;
  process_queue_.Close();
  if (http_acceptor_ != NULL) {
    http_acceptor_->Stop();
  }
  return http_transport_->Stop();
}

bool HttpServer::GetProcessPacket(ProcessPacketPtr* process_packet) {
  if (stop_) {
    return false;
  }
  if (!process_queue_.Closed() || !process_queue_.Empty()) {
    if (process_queue_.Empty()) {
      return false;
    }
    ProcessPacketPtr packet;
    int status = process_queue_.TimedTake(10, &packet);
    if (status == -1) return false;
    if (status == 0) return false;

    if (status != 1) {
      return false;
    }
    *process_packet = packet;
    return true;
  }
  return false;
}
}
}
