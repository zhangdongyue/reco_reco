#pragma once
#include <cygnet/cygnet.h>
#include <boost/shared_ptr.hpp>
#include <string>
#include "base/common/logging.h"
#include "base/strings/string_printf.h"
#include "reco/base/common/singleton.h"
#include "base/thread/blocking_queue.h"

namespace reco {
namespace http_communicator {

class HttpServerLogger : public cygnet::Logger {
 public:
  virtual void Log(Level level, const char* file, int line, const char* fmt, ...) {
    va_list argp;
    va_start(argp, fmt);
    LOG(INFO) << "[cygent_server] level : " << level
        << " file : " << file
        << " line : " << line
        << " msg : " << base::StringPrintV(fmt, argp);
    va_end(argp);
  }
};

class ProcessPacket {
 public:
  ProcessPacket() {}
  ~ProcessPacket() {}
  // callback, 处理完成之后回调该函数来发送 response
  void OnProcessComplete(std::string reco_id);
  void SendResponse(std::string reco_id);
  cygnet::HttpRequestPacket* request_packet_;
  cygnet::HttpServerConnection* server_conn_;
  cygnet::HttpResponsePacket* response_packet_;
};

typedef boost::shared_ptr<ProcessPacket> ProcessPacketPtr;

class ServerHttpPacketHandler : public cygnet::HttpPacketHandler {
 public:
  ServerHttpPacketHandler() {}
  virtual ~ServerHttpPacketHandler() {}
  void SetProcessQueue(thread::BlockingQueue<ProcessPacketPtr>* process_queue) {
    if (process_queue != NULL) {
      process_queue_ = process_queue;
    }
  }
 private:
  virtual bool OnPacket(cygnet::HttpConnection& conn, cygnet::Packet& packet);
  thread::BlockingQueue<ProcessPacketPtr>* process_queue_;
};

class HttpServer {
 public:
  HttpServer() : pack_handler_(NULL), stop_(false) {
    pack_handler_ = new ServerHttpPacketHandler();
    pack_handler_->SetProcessQueue(&process_queue_);
    http_transport_ = new cygnet::HttpTransport(false);
  }
  ~HttpServer() {
    if (http_acceptor_ != NULL) {
      http_acceptor_->Destroy();
    }
    if (http_transport_ != NULL) {
      http_transport_->Destroy();
      delete http_transport_;
      http_transport_ = NULL;
    }
    if (pack_handler_ != NULL) {
      delete pack_handler_;
      pack_handler_ = NULL;
    }
  }
  // backlog 监听端口号
  bool Init(const std::string& spec, int threadCount,
            int keepalive = cygnet::INFINITE_TIMEOUT,
            int idle = cygnet::INFINITE_TIMEOUT,
            bool isolateAcceptorThread = true,
            int backlog = 0);
  void Run();
  bool Stop();
  bool GetProcessPacket(ProcessPacketPtr* process_packet);
  bool Stoped() {
    return stop_;
  }
  // public:
  //  HttpServerLogger http_server_logger_;
 private:
  cygnet::HttpTransport* http_transport_;
  cygnet::HttpAcceptor* http_acceptor_;
  ServerHttpPacketHandler* pack_handler_;
  thread::BlockingQueue<ProcessPacketPtr> process_queue_;
  bool stop_;
};

typedef reco::common::singleton_default<HttpServer> HttpServerIns;
}
}
