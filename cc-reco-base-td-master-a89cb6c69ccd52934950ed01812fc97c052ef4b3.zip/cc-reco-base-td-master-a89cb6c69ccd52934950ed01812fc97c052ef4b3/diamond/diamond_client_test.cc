#include <iostream>
#include <string.h>
#include <sys/time.h>
#include "diamond/Diamond.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/testing/gtest.h"
#include "reco/base/diamond/diamond_client.h"

using namespace std;
using namespace middleware::diamond;
using reco::diamondclient::DiamondClient;

const string data_id = "shenma.xss.auto_test";
const string group= "dev.offline";

reco::diamondclient::ValueMap default_value = {
  {"dynamic_param_1", 111},
  {"dynamic_param_2", 0.888},
  {"dynamic_param_3", "ssss"}
};


class DiamondClientTest: public ::testing::Test {
 public:
  virtual void SetUp() {
    DiamondClient::SetDefaultValue(default_value);
    DiamondClient::AddMasterListener(data_id, group);
  }

  virtual void TearDown() {
    cout << "stopping....." << endl;
    DiamondClient::Shutdown();
    cout << "removing....." << endl;
    Diamond::remove(data_id, group);
  }
};

TEST_F(DiamondClientTest, AutoTest) {
  // 测试初始值
  ASSERT_EQ(DiamondClient::IntValue("dynamic_param_1"), 111);
  ASSERT_EQ(DiamondClient::FloatValue("dynamic_param_2"), 0.888);
  ASSERT_EQ(DiamondClient::StrValue("dynamic_param_3"), "ssss");

  // 测试正确发布
  string new_config = "{\"dynamic_param_1\":222, \"dynamic_param_2\":0.999, \"dynamic_param_3\":\"tttt\"}";
  Diamond::publishSingle(data_id, group, new_config);

  sleep(1);
  ASSERT_EQ(DiamondClient::IntValue("dynamic_param_1"), 222);
  ASSERT_EQ(DiamondClient::FloatValue("dynamic_param_2"), 0.999);
  ASSERT_EQ(DiamondClient::StrValue("dynamic_param_3"), "tttt");

  // 测试错误发布：缺少参数。预期此次发布被抛弃,动态参数不变，会打印一条错误日志
  new_config = "{\"dynamic_param_1\":333, \"dynamic_param_2\":0.777}";
  Diamond::publishSingle(data_id, group, new_config);

  sleep(1);
  ASSERT_EQ(DiamondClient::IntValue("dynamic_param_1"), 222);
  ASSERT_EQ(DiamondClient::FloatValue("dynamic_param_2"), 0.999);
  ASSERT_EQ(DiamondClient::StrValue("dynamic_param_3"), "tttt");

  // 测试错误发布：某个参数类型跟注册的默认参数不一样。预期此次发布被抛弃，动态参数不变
  // 因为类型错误的参数被略过，导致缺少参数，会打印一条错误日志
  new_config = "{\"dynamic_param_1\":333, \"dynamic_param_2\":0.777, \"dynamic_param_3\":888888}";
  Diamond::publishSingle(data_id, group, new_config);

  sleep(1);
  ASSERT_EQ(DiamondClient::IntValue("dynamic_param_1"), 222);
  ASSERT_EQ(DiamondClient::FloatValue("dynamic_param_2"), 0.999);
  ASSERT_EQ(DiamondClient::StrValue("dynamic_param_3"), "tttt");

  // 测试正确发布：多了参数。预期此次发布成功,多的参数被忽略
  new_config = "{\"dynamic_param_1\":333, \"dynamic_param_2\":0.777, \"dynamic_param_3\":\"oooo\", \"dynamic_param_4\":888888}";
  Diamond::publishSingle(data_id, group, new_config);

  sleep(1);
  ASSERT_EQ(DiamondClient::IntValue("dynamic_param_1"), 333);
  ASSERT_EQ(DiamondClient::FloatValue("dynamic_param_2"), 0.777);
  ASSERT_EQ(DiamondClient::StrValue("dynamic_param_3"), "oooo");
}
