#include "reco/base/diamond/diamond_client.h"

namespace reco {
namespace diamondclient {

const std::string DiamondClient::kMasterListener = "master";
const std::string DiamondClient::kSlaveListener = "slave";
bool DiamondClient::has_master_ = false;
bool DiamondClient::has_slave_ = false;
thread::Mutex DiamondClient::op_mutex_;
thread::Mutex DiamondClient::val_mutex_;
ValueMap DiamondClient::diamond_value_;
ValueMap DiamondClient::default_value;
ConfigInfo DiamondClient::master_config_;
ConfigInfo DiamondClient::slave_config_;

}
}
