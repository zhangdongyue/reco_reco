#include <iostream>
#include <unordered_map>
#include <string.h>
#include <sys/time.h>
#include "diamond/Diamond.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/thread/sync.h"
#include "extend/json/jansson/jansson.h"

namespace reco {
namespace diamondclient {

using middleware::diamond::Diamond;

struct ItgValue {
  enum ValueType {
    EN_INT = 0,
    EN_FLOAT,
    EN_STR
  };

  ValueType val_type;
  int int_val;
  double float_val;
  std::string str_val;

  ItgValue(int i = 0): val_type(EN_INT), int_val(i), float_val(0), str_val("") {}
  ItgValue(double d): val_type(EN_FLOAT), int_val(0), float_val(d), str_val("") {}
  ItgValue(const char* p): val_type(EN_STR), int_val(0), float_val(0), str_val(p) {}
  ItgValue(const std::string& s): val_type(EN_STR), int_val(0), float_val(0), str_val(s) {}

  ItgValue& operator= (const ItgValue& rhs) {
    val_type = rhs.val_type;
    int_val = rhs.int_val;
    float_val = rhs.float_val;
    str_val = rhs.str_val;
    return *this;
  }
};

struct ConfigInfo {
  middleware::diamond::ManagerListener* listener;
  std::string data_id;
  std::string group;
};

typedef std::unordered_map<std::string, ItgValue> ValueMap;

class DiamondClient {
 public:
  class MockListener: public middleware::diamond::ManagerListener {
   public:
    MockListener(const std::string& name): lsn_name_(name) {}

    // 继承来的纯虚函数，在这里用不上
    void getExecutor() {
      return;
    }

    void receiveConfigInfo(std::string& config_info) {
      LOG(INFO) << "listener:" << lsn_name_ << " received update." << " config info:\n" << config_info;
      ParseJsonConfig(lsn_name_, config_info);
    }

   private:
    std::string lsn_name_;
  };

  // 需要安全退出时要先调用这个API
  static void Shutdown() {
    if (has_master_) Diamond::removeListener(master_config_.data_id, master_config_.group, master_config_.listener);
    if (has_slave_) Diamond::removeListener(slave_config_.data_id, slave_config_.group, slave_config_.listener);
    has_master_ = false;
    has_slave_ = false;
    Diamond::shutdown();
  }

  // 切换diamond服务顶级域名的API，只有张北机房等受到管制的机房才需要设置
  static bool SetGlobalJMENV(const std::string& jmenv = "jmenv.tbsite.net", int port = 8080) {
    if (!Diamond::SetGlobalJMENV(jmenv.c_str(), port)) {
      LOG(ERROR) << "set jmenv failed.";
      return false;
    }
    return true;
  }

  static void SetDefaultValue(const ValueMap& val_map) {
    thread::AutoLock auto_lock(&op_mutex_);
    default_value = val_map;
    diamond_value_ = default_value;
  }

  static void AddMasterListener(const std::string& data_id, const std::string& group, const std::string& log_path = "./") {
    thread::AutoLock auto_lock(&op_mutex_);
    if (has_master_) return;

    // diamond的配置缓存目录和日志目录
    Diamond::SetCachePath(log_path.c_str());
    Diamond::SetLogPath(log_path.c_str());

    MockListener* plistener = new MockListener(kMasterListener);
    Diamond::addListener(data_id, group, plistener);

    has_master_ = true;
    master_config_.listener = plistener;
    master_config_.data_id = data_id;
    master_config_.group = group;

    LOG(INFO) << "master listener added.";
  }

  static bool AddSlaveListener(const std::string& data_id, const std::string& group) {
    thread::AutoLock auto_lock(&op_mutex_);
    if (has_slave_) return false;
    if (!has_master_) {
      LOG(FATAL) << "master listener not exists.";
      return false;
    }

    MockListener* plistener = new MockListener(kSlaveListener);
    Diamond::addListener(data_id, group, plistener);

    has_slave_ = true;
    slave_config_.listener = plistener;
    slave_config_.data_id = data_id;
    slave_config_.group = group;
    LOG(INFO) << "slave listener added.";
    return true;
  }

  static void ParseJsonConfig(const std::string& lsn_name, const std::string& config_info) {
    json_error_t json_error;
    json_t *json_item = json_loads(config_info.c_str(), &json_error);
    if (NULL == json_item) {
      LOG(ERROR) << "Invalid json config.";
      return;
    }

    if (!json_is_object(json_item)) {
      json_decref(json_item);
      LOG(ERROR) << "Invalid json config format.";
      return;
    }

    thread::AutoLock auto_lock(&val_mutex_);

    ValueMap new_val;
    for (void *it = json_object_iter(json_item); it != NULL; it = json_object_iter_next(json_item, it)) {
      std::string key = json_object_iter_key(it);
      json_t* val = json_object_iter_value(it);

      auto it = default_value.find(key);
      if (it == default_value.end()) continue;

      ItgValue::ValueType vtype = it->second.val_type;
      switch (vtype) {
        case ItgValue::EN_INT: {
          if (val->type != JSON_INTEGER) {
            LOG(ERROR) << "param type error. param:" << key << ", expect:INT, actual enum:" << val->type;
            break;
          }
          new_val[key] = ItgValue(json_integer_value(val));
          break;
        }
        case ItgValue::EN_FLOAT: {
          if (val->type != JSON_REAL) {
            LOG(ERROR) << "param type error. param:" << key << ", expect:FLOAT, actual enum:" << val->type;
            break;
          }
          new_val[key] = ItgValue(json_real_value(val));
          break;
        }
        case ItgValue::EN_STR: {
          if (val->type != JSON_STRING) {
            LOG(ERROR) << "param type error. param:" << key << ", expect:STRING, actual enum:" << val->type;
            break;
          }
          new_val[key] = ItgValue(json_string_value(val));
          break;
        }
        default:
          break;
      }
    }

    if (lsn_name == kMasterListener && new_val.size() != default_value.size()) {
      LOG(ERROR) << "master config parameter amount error."
                 << " new size:" << new_val.size()
                 << " default size:" << default_value.size();
    } else if (lsn_name == kSlaveListener) {
      for (auto it = new_val.begin(); it != new_val.end(); it++) {
        diamond_value_[it->first] = it->second;
      }
      LOG(INFO) << "slave config updated.";
    }
    else {
      diamond_value_.swap(new_val);
      LOG(INFO) << "master config updated.";
    }
  }

  static int IntValue(const std::string& value_id) {
    auto it = diamond_value_.find(value_id);
    if (it == diamond_value_.end() || it->second.val_type != ItgValue::EN_INT) {
      LOG(FATAL) << "get int value failed. value id not exists or type error.";
      return 0;
    }
    return it->second.int_val;
  }

  static double FloatValue(const std::string& value_id) {
    auto it = diamond_value_.find(value_id);
    if (it == diamond_value_.end() || it->second.val_type != ItgValue::EN_FLOAT) {
      LOG(FATAL) << "get float value failed. value id not exists or type error.";
      return 0;
    }
    return it->second.float_val;
  }

  static std::string StrValue(const std::string& value_id) {
    auto it = diamond_value_.find(value_id);
    if (it == diamond_value_.end() || it->second.val_type != ItgValue::EN_STR) {
      LOG(FATAL) << "get str value failed. value id not exists or type error.";
      return 0;
    }
    return it->second.str_val;
  }

 public:
  static ValueMap default_value;
  static const std::string kMasterListener;
  static const std::string kSlaveListener;

 private:
  static thread::Mutex op_mutex_;
  static bool has_master_;
  static bool has_slave_;
  static ConfigInfo master_config_;
  static ConfigInfo slave_config_;
  static thread::Mutex val_mutex_;
  static ValueMap diamond_value_;
};

} // namespace
} // namespace
