#include <iostream>
#include <sys/time.h>
#include "diamond/Diamond.h"

using namespace std;
using namespace middleware::diamond;

int main(int argc, char* argv[]) {
  if (argc < 4) {
    cout << "too less arg. usage:\n  ./this data_id group content";
    return -1;
  }

  string data_id = argv[1];
  string group = argv[2];
  string content = argv[3];
  Diamond::publishSingle(data_id, group, content);
  return 0;
}
