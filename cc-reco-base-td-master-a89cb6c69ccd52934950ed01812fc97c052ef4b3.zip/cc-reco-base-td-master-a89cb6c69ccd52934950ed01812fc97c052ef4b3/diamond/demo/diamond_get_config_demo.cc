#include <iostream>
#include <sys/time.h>
#include "diamond/Diamond.h"

using namespace std;
using namespace middleware::diamond;

int main(int argc, char* argv[]) {
  if (argc < 3) {
    cout << "too less arg. usage:\n  ./this data_id group [jmenv]";
    return -1;
  }

  string data_id = argv[1];
  string group = argv[2];
  if (argc > 3) {
    Diamond::SetGlobalJMENV(argv[3]);
  }


  while (true) {
    string content;
    Diamond::getConfig(data_id, group, 1000, content);
    cout << "get config:" << content << endl;
    sleep(2);
  }

  return 0;
}
