#include <iostream>
#include <string.h>
#include <sys/time.h>
#include "diamond/Diamond.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"

using namespace std;
using namespace middleware::diamond;

const string data_id = "shenma.xss.test";
const string group= "offline";


DEFINE_int32(test_int_flag, -1, "");
DEFINE_string(test_string_flag, "xxx", "");

class MockListener :public ManagerListener
{
public:
  MockListener(const string & name) {
    name_ = name;
  }

  void  getExecutor() {
    return ;
  }

  void receiveConfigInfo(string& config_info) {
    cout << "user listener callback, config info: " << config_info << endl;

    vector<string> opts;
    base::SplitString(config_info, " ", &opts);


    int argc = (int)opts.size();
    char** argv = new char*[argc + 1];

    const char* tmp = "this";
    argv[0] = new char[strlen(tmp) + 1];
    strcpy(argv[0], tmp);
    argc++;

    for(size_t i = 0; i < opts.size(); i++) {
      argv[i + 1] = new char[opts[i].size() + 1];
      strcpy(argv[i + 1], opts[i].c_str());
      cout << "copied:" << opts[i] << endl;
    }

    google::ParseCommandLineFlags(&argc, &argv, false);
  }

private:
  string name_;
};


int main(int argc, char* argv[]) {
  cout << "main:" << argv[0] << endl;

  Diamond::SetLogPath("/tmp/");
  MockListener *plistener1 = new MockListener("user listener");
  Diamond::addListener(data_id, group, plistener1);

  while (true) {
    sleep(5);
    cout << "int:" << FLAGS_test_int_flag << " string:" << FLAGS_test_string_flag << endl;
  }
  return 0;
}
