#include <iostream>
#include <sys/time.h>
#include "reco/base/diamond/diamond_client.h"

using namespace std;
using reco::diamondclient::DiamondClient;

const string data_id = "shenma.xss.test";
const string group= "offline";

reco::diamondclient::ValueMap default_value = {
  {"dynamic_param_1", 111},
  {"dynamic_param_2", 0.888},
  {"dynamic_param_3", "ssss"}
};

int main() {
  DiamondClient::SetDefaultValue(default_value);
  DiamondClient::AddMasterListener(data_id, group);

  while (true) {
    sleep(2);
    cout << DiamondClient::IntValue("dynamic_param_1") << endl;
    cout << DiamondClient::FloatValue("dynamic_param_2") << endl;
    cout << DiamondClient::StrValue("dynamic_param_3") << endl;
  }

  return 0;
}
