#include "reco/base/common/util.h"

#include <set>
#include <unordered_map>

#include "reco/base/common/oss_hash.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/hash_function/term.h"

namespace reco {
namespace common {

int32 hammingDistance(int64 hash1, int64 hash2) {
  int64 i = hash1 ^ hash2;
  i = i - ((i >> 1) & 0x5555555555555555L);
  i = (i & 0x3333333333333333L) + ((i >> 2) & 0x3333333333333333L);
  i = (i + (i >> 4)) & 0x0f0f0f0f0f0f0f0fL;
  i = i + (i >> 8);
  i = i + (i >> 16);
  i = i + (i >> 32);
  return (int32) i & 0x7f;
}

uint64 calcUserId(std::string app_name, std::string user_key) {
  std::string tmp = base::Uint64ToString(OssHash::hashString64(user_key.c_str()));

  std::string str = app_name + tmp;
  return base::CalcTermSign(str.c_str(), str.size());
}

}  // namespace common
}  // namespace reco
