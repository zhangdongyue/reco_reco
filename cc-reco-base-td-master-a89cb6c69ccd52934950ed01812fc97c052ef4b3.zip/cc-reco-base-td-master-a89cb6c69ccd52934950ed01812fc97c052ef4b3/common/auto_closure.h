#include <google/protobuf/stubs/common.h>

class AutoClosure {
 public:
  explicit AutoClosure(::google::protobuf::Closure* c): c_(c) {}

  ~AutoClosure() {
    c_->Run();
  }

 private:
  ::google::protobuf::Closure* c_;
};
