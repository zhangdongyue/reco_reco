#include <string.h>
#include <string>

#include "base/common/logging.h"
#include "base/testing/gtest.h"

#include "base/common/basic_types.h"
#include "base/common/scoped_ptr.h"
#include "reco/base/common/oss_hash.h"
#include "base/hash_function/term.h"
#include "base/strings/string_number_conversions.h"

TEST(OssHash, Case) {
  std::string tmpId = base::Uint64ToString(reco::common::OssHash::hashString64("VPAUtAXYXeoDAJpoCjQKpt58"));

  std::string str = "uc-iflow" + tmpId;
  uint64 user_id = base::CalcTermSign(str.c_str(), str.size());
  EXPECT_EQ(user_id, 14365590837987178039ul);
}

TEST(OssHash, Cases) {
  static struct {
    const char* url;
    uint64 item_id;
  } cases[] = {
    {"http://sports.china.com.cn/live/2014-06/03/content_26937801.htm", 10916353414330073386ul},
    {"http://news.sina.com.cn/c/2014-05-26/180130234985.shtml",         14597100657028380959ul},
    {"http://news.ifeng.com/a/20140604/40574847_0.shtml",               1800594178117336913ul},
    {"http://dzh.mop.com/whbm/20140531/0/zSlzg5I2d1266fF7.shtml",       1898119483491143506ul},
    {"http://news.cnr.cn/native/gd/201405/t20140527_515585270.shtml",   18145458723429741923ul},
    {"http://bbs.news.163.com/bbs/mil/419887498.html",                  17127979948938321805ul},
    {"http://www.jfdaily.com/caijing/new/201405/t20140530_397793.html", 13926299575923934598ul},
    {"http://finance.ifeng.com/a/20140603/12462321_0.shtml",            10776255485956017517ul},
  };
  for (int i = 0; i < (int)ARRAYSIZE_UNSAFE(cases); ++i) {
    EXPECT_EQ(reco::common::OssHash::hashString64(cases[i].url), cases[i].item_id);
  }
}

