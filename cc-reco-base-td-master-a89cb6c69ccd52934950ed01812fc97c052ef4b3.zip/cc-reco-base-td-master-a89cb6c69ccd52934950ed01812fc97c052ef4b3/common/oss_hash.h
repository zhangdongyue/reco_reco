#pragma once

#include "base/common/basic_types.h"

namespace reco {
namespace common {

class OssHash {
 public:
  OssHash();
  ~OssHash();

 public:
  static uint32 hashString(const char *str, uint32_t dwHashType);
  static uint32 hashString(const char *str, size_t size, uint32_t dwHashType);
  static uint64 hashString64(const char *str);
  static uint64 hashNumber64(int32_t number);

 public:
  // deprecated hash function, for it not produces hash value unifromly
  static uint64_t hashString64Deprecated(const char *str, uint32_t dwHashType);
};
}
}  // namespace reco
