#pragma once

#include<string>

namespace reco {
  namespace common {

    // encode的输入可以包含\0
    std::string EncodeUrlComponent(const std::string &url);
    bool DecodeUrlComponent(const char *src, std::string *result);
    void FastEncodeUrlComponent(const std::string & url, std::string *result);
  }
}
