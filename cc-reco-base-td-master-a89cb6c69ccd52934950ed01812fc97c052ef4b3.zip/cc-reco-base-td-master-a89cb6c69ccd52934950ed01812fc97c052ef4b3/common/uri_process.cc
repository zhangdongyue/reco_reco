#include "reco/base/common/uri_process.h"
#include "base/common/logging.h"

namespace reco {
namespace common {

static void char2hex(unsigned char c, std::string *result) {
  char dig1 = (c & 0xF0) >> 4;
  char dig2 = (c & 0x0F);

  if ( 0<= dig1 && dig1 <= 9) dig1 += '0';
  if (10<= dig1 && dig1 <=15) dig1 += 'A' - 10;

  if ( 0<= dig2 && dig2 <= 9) dig2 += '0';
  if (10<= dig2 && dig2 <=15) dig2 += 'A' - 10;

  result->push_back(dig1);
  result->push_back(dig2);
}

void FastEncodeUrlComponent(const std::string & url, std::string *result) {
  for (size_t i = 0; i != url.length(); ++i) {
    if ((48 <= url[i] && url[i] <= 57) ||  // 0-9
        (65 <= url[i] && url[i] <= 90) ||  // abc...xyz
        (97 <= url[i] && url[i] <= 122) ||  // ABC...XYZ
        (url[i] == '~' || url[i] == '!' ||
         url[i] == '*' || url[i] == '(' ||
         url[i] == ')' || url[i] == '\'')
       ) {
      result->push_back(url[i]);
    } else {
      result->push_back('%');
      char2hex(url[i], result);
    }

  }
}

std::string EncodeUrlComponent(const std::string &url) {
  std::string result;
  FastEncodeUrlComponent(url, &result);
  return result;
}

static bool ConvertHexPairToChar(const char *src, char *c) {
  if (src == NULL) return false;

  unsigned char v = 0;
  for (int i = 0; i < 2; ++i) {
    unsigned char digit = src[i];
    if (digit >= '0' && digit <= '9') {
      digit -= '0';
    } else if (digit >= 'A' && digit <= 'F') {
      digit += 10;
      digit -= 'A';
    } else if (digit >= 'a' && digit
               <= 'f') {
      digit += 10;
      digit -= 'a';
    } else {
      return false;
    }

    v |= (digit << (4*(1-i)));
  }

  *c = v;
  return true;
}

bool DecodeUrlComponent(const char *src, std::string *result) {
  result->clear();
  for (int i = 0; src[i] != 0; ++i) {
    if (src[i] == '%') {
      char c;
      if (!ConvertHexPairToChar(src + i + 1, &c)) {
        VLOG(3) << "Failed to decode url component: " << src;
        return false;
      }
      (*result) += (c);
      i += 2;
    } else if (src[i] == '+') {
      (*result) += ' ';
    } else {
      (*result) += src[i];
    }
  }

  return true;
}
}
}
