#include "reco/base/common/topn.h"
#include "reco/base/common/topn_heap.h"

#include <algorithm>
#include <string>
#include <vector>

#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/common/scoped_ptr.h"
#include "base/hash_function/term.h"
#include "base/strings/string_number_conversions.h"
#include "base/testing/gtest.h"
#include "serving_base/utility/timer.h"

using std::string;
using std::vector;
using std::pair;
using std::make_pair;

DEFINE_int32(input_size, 100, "");
DEFINE_int32(topn_size, 100, "");

void PrintVectorHead(const vector<pair<uint64, double>> &data, const size_t size = 10) {
  string print_str;
  for (auto i = 0u; i < size && i < data.size(); ++i) {
    print_str += "key=" + base::UintToString(data[i].first) +
                 ", val=" + base::DoubleToString(data[i].second) + "; ";
  }
  // LOG(INFO) << "vec head is:" << print_str;
}


void Benchmarks(const vector<pair<uint64, double>> &data) {
  serving_base::Timer timer;

  // 1. priority_queue test
  vector<pair<uint64, double>> result;
  timer.Start();
  TopN<uint64> topn(FLAGS_topn_size);
  for (auto i = 0; i < FLAGS_input_size; ++i) {
    topn.add(data[i].first, data[i].second);
  }

  topn.get_top_n(&result);
  LOG(INFO) << "\tpriority_queue cost:" << timer.Stop() / 1000.0 << "ms";
  PrintVectorHead(result);

  // 2. make_heap tset
  vector<pair<uint64, double>> result_heap;
  timer.Start();
  TopNHeap<uint64> topn_heap(FLAGS_topn_size);
  for (auto i = 0; i < FLAGS_input_size; ++i) {
    topn_heap.add(data[i].first, data[i].second);
  }

  topn_heap.get_top_n_unordered(&result_heap);
  LOG(INFO) << "\tstd::make_heap cost:" << timer.Stop() / 1000.0 << "ms";
  PrintVectorHead(result_heap);

  std::sort(result.begin(), result.end());
  std::sort(result_heap.begin(), result_heap.end());

  for (auto i = 0u; i < result.size(); ++i) {
    ASSERT_EQ(result[i].first, result_heap[i].first);
    ASSERT_EQ(static_cast<int>(result[i].second * 1000), static_cast<int>(result_heap[i].second * 1000));
  }
}

TEST(TopN, topn_test) {
  // init
  vector<pair<uint64, double>> data;
  for (auto i = 0; i < FLAGS_input_size; ++i) {
    data.push_back(make_pair(i, i*1.1));
  }

  // order
  LOG(INFO) << "\torder vector:";
  PrintVectorHead(data);
  Benchmarks(data);

  // reverse
  LOG(INFO) << "\treverse vector:";
  std::reverse(data.begin(), data.end());
  PrintVectorHead(data);
  Benchmarks(data);

  // random
  LOG(INFO) << "\trandom vector:";
  std::random_shuffle(data.begin(), data.end());
  PrintVectorHead(data);
  Benchmarks(data);
}
