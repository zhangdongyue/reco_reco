#pragma once

#include <string>
#include <vector>

#include "base/common/base.h"
#include "base/common/logging.h"

namespace reco {
namespace common {
// Returns an integer that indicates bits' similarity of two 64-bit integers
int32 hammingDistance(int64 hash1, int64 hash2);

// app_name: uc-iflow, webapp;
// user_key: 用来标识用户的 key
uint64 calcUserId(std::string app_name, std::string user_key);
}
}
