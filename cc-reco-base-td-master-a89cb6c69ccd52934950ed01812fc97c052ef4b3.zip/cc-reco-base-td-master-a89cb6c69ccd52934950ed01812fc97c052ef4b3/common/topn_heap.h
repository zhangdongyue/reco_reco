#pragma once
#include <unistd.h>
#include <algorithm>
#include <functional>
#include <queue>
#include <vector>
#include <utility>

#include "base/common/basic_types.h"

template<class T>
class TopNHeap {
 public:
  explicit TopNHeap(uint32 heap_size) : kHeapSize(heap_size) {}
  ~TopNHeap() {}

  void add(const T elem, double score) {
    topn_.push_back(std::make_pair(score, elem));

    if (topn_.size() == kHeapSize) {
      std::make_heap(topn_.begin(), topn_.end(), std::greater<std::pair<double, T> >());
    } else {
      if (topn_.size() > kHeapSize) {
        std::push_heap(topn_.begin(), topn_.end(), std::greater<std::pair<double, T> >());
        std::pop_heap(topn_.begin(), topn_.end(), std::greater<std::pair<double, T> >());
        topn_.pop_back();
      }
    }
  }

  // 返回 topn （topn 内部不是排序的)
  void get_top_n_unordered(std::vector<std::pair<T, double> >* list) {
    list->clear();
    for (auto it = topn_.begin(); it != topn_.end(); ++it) {
      list->push_back(std::make_pair(it->second, it->first));
    }
  }

 private:
  std::vector<std::pair<double, T>> topn_;
  const uint32 kHeapSize;
};

