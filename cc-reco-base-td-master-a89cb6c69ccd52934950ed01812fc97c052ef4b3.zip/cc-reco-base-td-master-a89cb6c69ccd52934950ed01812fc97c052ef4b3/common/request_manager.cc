#include "reco/base/common/request_manager.h"

DEFINE_int64_counter(req_manager, req_manager_overload_num, 0, "");

namespace reco {
namespace common {

RequestManager::RequestManager() {
  thread_pool_ = NULL;
}

void RequestManager::Init(int thread_num, int64 timeout_ms) {
  thread_pool_ = new thread::ThreadPool(thread_num);
  timeout_ms_ = timeout_ms;
}

void RequestManager::RegisterReqFuncMap(ReqFuncMapBase* ins) {
  req_func_map_[ins->GetReqType()] = ins;
  LOG(INFO) << "register req func map, req type:" << ins->GetReqType();
}

void RequestManager::AddReqTask(const ::google::protobuf::Message *req, ::google::protobuf::Message *resp,
                                Closure *closure_done) {
  StReqParam param(req, resp, closure_done, base::GetTimestamp());
  thread::AutoLock lock(&mutex_);
  thread_pool_->AddTask(NewCallback(this, &RequestManager::Process, param));
}

void RequestManager::Process(StReqParam param) {
  int64 time_delta = base::GetTimestamp() - param.time_stamp;
  if (time_delta > timeout_ms_ * 1000) {
    LOG(ERROR) << "server overload! wait time:" << time_delta << " us";
    COUNTERS_req_manager__req_manager_overload_num.Increase(1);
    return;
  }

  const std::string req_type = typeid(*param.request).name();
  auto it = req_func_map_.begin();
  for (; it != req_func_map_.end(); it++) {
    if (req_type == it->first) {
      it->second->Run(param);
      break;
    }
  }

  if (it == req_func_map_.end()) {
    LOG(ERROR) << "invalid request type! req type:" << req_type;
  }
}

}  // namespace common
}  // namespace reco
