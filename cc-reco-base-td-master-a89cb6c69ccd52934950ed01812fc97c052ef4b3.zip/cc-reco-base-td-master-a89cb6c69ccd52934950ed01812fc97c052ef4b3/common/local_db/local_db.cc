#include "reco/base/common/local_db/local_db.h"

#include "base/common/logging.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/hash_function/city.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "third_party/leveldb/db.h"
#include "third_party/leveldb/filter_policy.h"
#include "third_party/leveldb/options.h"

using std::string;
using std::vector;

namespace reco {
namespace common {
DEFINE_int32(leveldb_write_buf_size, 64, "unit: M");

LocalDB::LocalDB(const std::string &paths, const int partition_num) {
  vector<string> path_vec;
  vector<base::FilePath> file_paths;
  base::SplitString(paths, ",", &path_vec);
  for (auto i = 0u; i < path_vec.size(); ++i) {
    base::file_util::CreateDirectory(path_vec[i]);
    file_paths.push_back(base::FilePath(path_vec[i]));
  }

  db_ = new leveldb::DB*[partition_num];
  partition_num_ = partition_num;

  leveldb::Options options;
  options.filter_policy = leveldb::NewBloomFilterPolicy(10);
  options.create_if_missing = true;
  options.block_size = 256*1024;
  options.block_restart_interval = 64;
  options.write_buffer_size = FLAGS_leveldb_write_buf_size*1024*1024;
  options.compression = leveldb::kSnappyCompression;
  // options.compression = leveldb::kNoCompression;

  for (auto i = 0; i < partition_num_; ++i) {
    const string path = file_paths[i % file_paths.size()].Append(base::IntToString(i)).ToString();
    LOG(INFO) << "open db path:" << path;
    leveldb::Status status = leveldb::DB::Open(options, path, &db_[i]);
    CHECK(status.ok()) << status.ToString();;
  }
}

LocalDB::~LocalDB() {
  for (auto i = 0; i < partition_num_; ++i) {
    delete db_[i];
    db_[i] = NULL;
  }

  delete [] db_;
  db_ = NULL;
}

bool LocalDB::Get(const std::string& k, std::string* v) {
  leveldb::ReadOptions options;
  options.fill_cache = false;
  const int idx = base::CityHash64(k.c_str(), k.size()) % partition_num_;
  leveldb::Status s = db_[idx]->Get(options, k, v);
  if (s.ok()) {
    return true;
  } else {
    v->clear();
    LOG(WARNING) << "get fail. key:" << k << ", err:" << s.ToString();
    return false;
  }

  return false;
}

bool LocalDB::Put(const std::string& k, const std::string& v) {
  leveldb::WriteOptions options;
  const int idx = base::CityHash64(k.c_str(), k.size()) % partition_num_;
  leveldb::Status s = db_[idx]->Put(options, k, v);
  if (s.ok()) {
    return true;
  } else {
    LOG(INFO) << "put fail. key:" << k << ", err:" << s.ToString();
    return false;
  }

  return false;
}
}
}
