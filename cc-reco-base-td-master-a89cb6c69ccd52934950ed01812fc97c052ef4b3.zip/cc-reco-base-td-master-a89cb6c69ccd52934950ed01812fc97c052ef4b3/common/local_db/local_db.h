#pragma once

#include <string>


namespace leveldb {
class DB;
}

namespace reco {
namespace common {
class LocalDB {
 public:
  // folder_path 支持多块盘的处理，使用逗号分隔，具体分组会自动从第一个盘上开始
  explicit LocalDB(const std::string &folder_paths, const int partition_num);

  ~LocalDB();

  bool Get(const std::string& k, std::string* v);

  bool Put(const std::string& k, const std::string& v);

 private:
  leveldb::DB** db_;
  int partition_num_;
};
}
}
