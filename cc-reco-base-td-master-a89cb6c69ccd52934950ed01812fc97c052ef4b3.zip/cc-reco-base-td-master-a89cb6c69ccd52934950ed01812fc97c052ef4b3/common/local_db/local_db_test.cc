#include "reco/base/common/local_db/local_db.h"

#include <string>

#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/common/closure.h"
#include "base/random/pseudo_random.h"
#include "base/testing/gtest.h"
#include "base/thread/thread_pool.h"
#include "base/time/timestamp.h"
#include "base/strings/string_number_conversions.h"
#include "serving_base/utility/timer.h"

using std::string;

namespace reco {
namespace common {
DEFINE_string(db_path, ".build", "");
DEFINE_int32(partition_num, 10, "");
DEFINE_int32(press_thread_cnt, 2, "");
DEFINE_int32(press_cnt, 100, "");
DEFINE_int32(press_val_size, 100, "");

class LocalDBTest: public testing::Test {
 protected:
  void SetUp() {}
  void TearDown() {}
};

TEST_F(LocalDBTest, CreateDB) {
  LocalDB db(FLAGS_db_path, 5);
}

TEST_F(LocalDBTest, GetPut) {
  LocalDB db(FLAGS_db_path, 5);

  const string k = "key-1";
  const string v = "value-1";

  ASSERT_TRUE(db.Put(k, v));

  string read;
  ASSERT_TRUE(db.Get(k, &read));
  ASSERT_EQ(v, read);
}

void WriteData(LocalDB* db, string key, string* val) {
  db->Put(key, *val);
}

void ReadData(LocalDB* db, string key) {
  string val;
  db->Get(key, &val);
}

TEST_F(LocalDBTest, OrderPress) {
  LocalDB db(FLAGS_db_path, FLAGS_partition_num);
  char* buf = new char[FLAGS_press_val_size];
  string value(buf, FLAGS_press_val_size);

  thread::ThreadPool put_pool(FLAGS_press_thread_cnt);
  serving_base::Timer timer;
  timer.Start();
  for (auto i = 0; i < FLAGS_press_cnt; ++i) {
    put_pool.AddTask(::NewCallback(WriteData, &db, base::IntToString(i), &value));
  }
  put_pool.JoinAll();
  LOG(INFO) << "order put press, cnt:" << FLAGS_press_cnt
            << ", val size:" << FLAGS_press_val_size
            << ", cost:" << timer.Stop() / 1000.f;


  thread::ThreadPool get_pool(FLAGS_press_thread_cnt);
  timer.Start();
  for (auto i = 0; i < FLAGS_press_cnt; ++i) {
    get_pool.AddTask(::NewCallback(ReadData, &db, base::IntToString(i)));
  }
  get_pool.JoinAll();
  LOG(INFO) << "order get press, cnt:" << FLAGS_press_cnt
            << ", val size:" << FLAGS_press_val_size
            << ", cost:" << timer.Stop() / 1000.f;
}

TEST_F(LocalDBTest, RandomPress) {
  LocalDB db(FLAGS_db_path, FLAGS_partition_num);
  string ori_value;
  base::PseudoRandom random;
  for (auto i = 0; i < FLAGS_press_val_size; ++i) {
    random.Reset(base::GetTimestamp());
    ori_value += base::Uint64ToString(random.GetUint64());
  }

  thread::ThreadPool put_pool(FLAGS_press_thread_cnt);
  serving_base::Timer timer;
  string val;

  timer.Start();
  for (auto i = 0; i < FLAGS_press_cnt; ++i) {
    random.Reset(base::GetTimestamp());
    val.assign(ori_value.begin() + random.GetInt(0, FLAGS_press_val_size-2), ori_value.end());
    put_pool.AddTask(::NewCallback(WriteData,
                                   &db,
                                   base::IntToString(random.GetUint64() % FLAGS_press_cnt),
                                   &val));
  }
  put_pool.JoinAll();
  LOG(INFO) << "random put press, cnt:" << FLAGS_press_cnt
            << ", val size:" << FLAGS_press_val_size
            << ", cost:" << timer.Stop() / 1000.f;


  thread::ThreadPool get_pool(FLAGS_press_thread_cnt);
  timer.Start();
  for (auto i = 0; i < FLAGS_press_cnt; ++i) {
    random.Reset(base::GetTimestamp());
    get_pool.AddTask(::NewCallback(ReadData,
                                   &db,
                                   base::IntToString(random.GetUint64() % FLAGS_press_cnt)));
  }
  get_pool.JoinAll();
  LOG(INFO) << "random get press, cnt:" << FLAGS_press_cnt
            << ", val size:" << FLAGS_press_val_size
            << ", cost:" << timer.Stop() / 1000.f;
}
}
}

