#pragma once
#if __cplusplus < 201103L
  #include <cstdatomic>
#else
  #include <atomic>
#endif
