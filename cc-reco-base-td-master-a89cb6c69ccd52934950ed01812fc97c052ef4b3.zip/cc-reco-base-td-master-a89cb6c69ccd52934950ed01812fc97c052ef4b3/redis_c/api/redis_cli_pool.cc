#include "reco/base/redis_c/api/redis_cli_pool.h"

#include <vector>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/hash_function/city.h"
#include "base/random/pseudo_random.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "reco/base/common/singleton.h"

using std::string;
using std::vector;
using std::unordered_set;
using std::unordered_map;

namespace reco {
namespace redis {
// redis pool
DEFINE_string(redis_pool_ips, "127.0.0.1:6379:127.0.0.1:6380", "");
DEFINE_int32(redis_pool_size, 5, "connect pool total size");
DEFINE_int32(redis_rw_timeout_ms, 50, "ms");

// redis cli
DEFINE_int32(redis_retry_count, 2, "set value retry count.");
DEFINE_int32(redis_expire_seconds, 1*24*60*60, "redis expire time, second, default is 1 day.");
DEFINE_uint64(redis_batch_push_size, 10, "");


DEFINE_int64_counter(redis, redis_error_num, 0, "");

DEFINE_int64_counter(redis, redis_expire_num, 0, "");
DEFINE_int64_counter(redis, redis_expire_cost, 0, "");
DEFINE_int64_counter(redis, redis_del_num, 0, "");
DEFINE_int64_counter(redis, redis_del_cost, 0, "");
DEFINE_int64_counter(redis, redis_exist_num, 0, "");
DEFINE_int64_counter(redis, redis_exist_cost, 0, "");
DEFINE_int64_counter(redis, redis_ttl_num, 0, "");
DEFINE_int64_counter(redis, redis_ttl_cost, 0, "");
DEFINE_int64_counter(redis, redis_incrby_num, 0, "");
DEFINE_int64_counter(redis, redis_incrby_cost, 0, "");
DEFINE_int64_counter(redis, redis_get_num, 0, "");
DEFINE_int64_counter(redis, redis_get_cost, 0, "");
DEFINE_int64_counter(redis, redis_mget_num, 0, "");
DEFINE_int64_counter(redis, redis_mget_cost, 0, "");
DEFINE_int64_counter(redis, redis_setex_num, 0, "");
DEFINE_int64_counter(redis, redis_setex_cost, 0, "");
DEFINE_int64_counter(redis, redis_llen_num, 0, "");
DEFINE_int64_counter(redis, redis_llen_cost, 0, "");
DEFINE_int64_counter(redis, redis_lrange_num, 0, "");
DEFINE_int64_counter(redis, redis_lrange_cost, 0, "");
DEFINE_int64_counter(redis, redis_lpop_num, 0, "");
DEFINE_int64_counter(redis, redis_lpop_cost, 0, "");
DEFINE_int64_counter(redis, redis_lpush_num, 0, "");
DEFINE_int64_counter(redis, redis_lpush_cost, 0, "");
DEFINE_int64_counter(redis, redis_rpush_num, 0, "");
DEFINE_int64_counter(redis, redis_rpush_cost, 0, "");
DEFINE_int64_counter(redis, redis_hset_num, 0, "");
DEFINE_int64_counter(redis, redis_hset_cost, 0, "");
DEFINE_int64_counter(redis, redis_hgetall_num, 0, "");
DEFINE_int64_counter(redis, redis_hgetall_cost, 0, "");
DEFINE_int64_counter(redis, redis_zadd_num, 0, "");
DEFINE_int64_counter(redis, redis_zadd_cost, 0, "");
DEFINE_int64_counter(redis, redis_zrange_num, 0, "");
DEFINE_int64_counter(redis, redis_zrange_cost, 0, "");
DEFINE_int64_counter(redis, redis_zcard_num, 0, "");
DEFINE_int64_counter(redis, redis_zcard_cost, 0, "");
DEFINE_int64_counter(redis, redis_zrevrange_num, 0, "");
DEFINE_int64_counter(redis, redis_zrevrange_cost, 0, "");
DEFINE_int64_counter(redis, redis_getcli_num, 0, "");
DEFINE_int64_counter(redis, redis_getcli_cost, 0, "");
DEFINE_int64_counter(redis, redis_ping_num, 0, "");
DEFINE_int64_counter(redis, redis_ping_cost, 0, "");

DEFINE_int64_counter(redis, redis_lib_expire_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_expire_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_del_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_del_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_exist_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_exist_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_ttl_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_ttl_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_incrby_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_incrby_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_get_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_get_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_mget_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_mget_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_setex_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_setex_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_llen_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_llen_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_lrange_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_lrange_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_lpop_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_lpop_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_lpush_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_lpush_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_rpush_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_rpush_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_hset_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_hset_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_hgetall_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_hgetall_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_zadd_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_zadd_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_zrange_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_zrange_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_zcard_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_zcard_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_zrevrange_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_zrevrange_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_ping_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_ping_cost, 0, "");

RedisCli::~RedisCli() {
  LOG(INFO) << "redis cli release.";

  if (cli_pool_) {
    delete cli_pool_;
    cli_pool_ = NULL;
  }
}


bool RedisCli::CheckReply(const CliInfo *cli, const string &key, const int &expect_type) {
  if (!cli->reply) {
    LOG(WARNING) << "redis reply is null.";
    return false;
  }

  if (cli->ctx->err != 0) {
    LOG(WARNING) << "redis op fail, msg:" << cli->ctx->err;
    return false;
  }

  if (cli->reply->type == REDIS_REPLY_ERROR) {
    LOG(WARNING) << "redis reply error, key:" << key
                 << ", flags:" << cli->ctx->flags
                 << ", msg:" << string(cli->reply->str, cli->reply->len);
    cli->ctx->err = REDIS_ERR_OTHER;
    return false;
  }

  if (cli->reply->type != expect_type) {
    LOG(WARNING) << "redis return val type error, key:" << key << ", type:" << cli->reply->type;
    cli->ctx->err = REDIS_ERR_OTHER;
    return false;
  }

  return true;
}

bool RedisCli::CheckReplyNil(const CliInfo *cli) {
  if (cli->reply != NULL && cli->ctx->err == 0 && cli->reply->type == REDIS_REPLY_NIL) {
    return true;
  }
  return false;
}

bool RedisCli::Ping(void) {
  PerfTracer perf_tracer(&COUNTERS_redis__redis_ping_num,
                         &COUNTERS_redis__redis_ping_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_ping_num,
                                 &COUNTERS_redis__redis_lib_ping_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "PING"));
    }


    if (!CheckReply(cli, "", REDIS_REPLY_STATUS)) {
      continue;
    }

    return true;
  }

  LOG(ERROR) << "ping error.";
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}

bool RedisCli::Expire(const std::string &key, const int ttl) {
  if (key.empty()) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_expire_num,
                         &COUNTERS_redis__redis_expire_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_expire_num,
                                 &COUNTERS_redis__redis_lib_expire_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "EXPIRE %s %d", key.c_str(), ttl));
    }


    if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
      continue;
    }

    return true;
  }

  LOG(ERROR) << "set expire error, key:" << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}


bool RedisCli::Del(const std::string &key) {
  if (key.empty()) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_del_num,
                         &COUNTERS_redis__redis_del_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_del_num,
                                 &COUNTERS_redis__redis_lib_del_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "DEL %s", key.c_str()));
    }

    if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
      continue;
    }

    return true;
  }

  LOG(ERROR) << "redis error.";
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}


bool RedisCli::IncrBy(const std::string &key, const int64 cnt, int64 *val) {
  if (key.empty() || cnt == 0) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_incrby_num,
                         &COUNTERS_redis__redis_incrby_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_incrby_num,
                                 &COUNTERS_redis__redis_lib_incrby_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "INCRBY %s %d", key.c_str(), cnt));
    }


    if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
      continue;
    }

    if (val) {
      *val = cli->reply->integer;
    }

    return true;
  }

  LOG(ERROR) << "redis incr error, key:" << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}


int RedisCli::Get(const std::string &key, std::string *value) {
  CHECK_NOTNULL(value);
  value->clear();
  if (key.empty()) return 0;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_get_num,
                         &COUNTERS_redis__redis_get_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_get_num,
                                 &COUNTERS_redis__redis_lib_get_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "Get %s", key.c_str()));
    }


    if (CheckReplyNil(cli)) {
      return 1;
    }
    if (!CheckReply(cli, key, REDIS_REPLY_STRING)) {
      continue;
    }

    value->assign(string(cli->reply->str, cli->reply->len));
    return 0;
  }

  LOG(ERROR) << "redis get error, key:" << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return -1;
}

  // 底层调用 MGet
void RedisCli::MGetWithStep(int step_size, const std::vector<std::string> &keys,
                            std::vector<std::string> *values,
                            std::vector<int> *ret_codes) {
  CHECK_NOTNULL(values);
  CHECK_NOTNULL(ret_codes);

  values->clear();
  ret_codes->clear();
  values->reserve(keys.size());
  ret_codes->reserve(keys.size());

  std::vector<std::string> k, v;
  std::vector<int> r;
  k.reserve(step_size);
  v.reserve(step_size);
  r.reserve(step_size);
  for (int begin = 0; begin < (int)keys.size(); begin += step_size) {
    int end = begin + step_size;
    if (end >= (int)keys.size()) {
      end = keys.size();
    }
    k.assign(keys.begin() + begin, keys.begin() + end);
    v.clear();
    r.clear();
    MGet(k, &v, &r);
    values->insert(values->end(), v.begin(), v.end());
    ret_codes->insert(ret_codes->end(), r.begin(), r.end());
  }
}

int RedisCli::MGet(const vector<string> &keys, vector<std::string> *values, vector<int> *ret_codes) {
  CHECK_NOTNULL(values);
  if (keys.empty()) return 0;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_mget_num,
                         &COUNTERS_redis__redis_mget_cost,
                         FLAGS_redis_perf_trace);
  values->clear();
  values->resize(keys.size());

  if (ret_codes) {
    ret_codes->assign(keys.size(), -1);
  }

  // NOTICE: More than one key need add "mget" together
  const std::string key_str = "mget " + base::JoinStrings(keys, " ");

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_mget_num,
                                 &COUNTERS_redis__redis_lib_mget_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, key_str.c_str()));
    }


    if (!CheckReply(cli, key_str, REDIS_REPLY_ARRAY)) {
      continue;
    }

    int ret = 0;
    for (auto i = 0u; i < cli->reply->elements && i < keys.size(); ++i) {
      if (cli->reply->element[i]->type == REDIS_REPLY_NIL) {
        ret = 1;
        if (ret_codes) {
          ret_codes->at(i) = 1;
        }
      } else {
        values->at(i).assign(cli->reply->element[i]->str, cli->reply->element[i]->len);
        if (ret_codes) {
          ret_codes->at(i) = 0;
        }
      }
    }
    return ret;
  }

  LOG(ERROR) << "redis mget error, key:" << key_str;
  COUNTERS_redis__redis_error_num.Increase(1);
  return -1;
}


bool RedisCli::SetEx(const string &key, const string &value, const int ttl) {
  if (key.empty()) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_setex_num,
                         &COUNTERS_redis__redis_setex_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_setex_num,
                                 &COUNTERS_redis__redis_lib_setex_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "SETEX %s %d %b",
                                            key.c_str(), ttl, value.c_str(), value.size()));
    }


    if (!CheckReply(cli, key, REDIS_REPLY_STATUS)) {
      continue;
    }

    return true;
  }

  LOG(ERROR) << "set redis data error, key:" << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}


bool RedisCli::LLen(const string &key, int *len) {
  *len = 0;
  if (key.empty()) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_llen_num,
                         &COUNTERS_redis__redis_llen_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_llen_num,
                                 &COUNTERS_redis__redis_lib_llen_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "LLEN  %s", key.c_str()));
    }
    if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
      continue;
    }

    *len = cli->reply->integer;
    return true;
  }

  LOG(ERROR) << "llen redis data error, key:" << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}

bool RedisCli::LRange(const std::string &key, std::vector<std::string> *values, int begin, int end) {
  CHECK_NOTNULL(values);
  values->clear();
  if (key.empty()) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_lrange_num,
                         &COUNTERS_redis__redis_lrange_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_lrange_num,
                                 &COUNTERS_redis__redis_lib_lrange_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(
                     redisCommand(cli->ctx, "LRANGE %s %d %d", key.c_str(), begin, end));
    }
    if (!CheckReply(cli, key, REDIS_REPLY_ARRAY)) {
      continue;
    }

    values->clear();
    for (auto i = 0u; i < cli->reply->elements; ++i) {
      values->push_back(string(cli->reply->element[i]->str, cli->reply->element[i]->len));
    }

    return true;
  }

  LOG(ERROR) << "redis op error, key: " << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}


int RedisCli::LPop(const std::string &key) {
  if (key.empty()) return 0;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_lpop_num,
                         &COUNTERS_redis__redis_lpop_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_lpop_num,
                                 &COUNTERS_redis__redis_lib_lpop_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "LPOP %s", key.c_str()));
    }


    if (CheckReplyNil(cli)) {
      return 1;
    }
    if (!CheckReply(cli, key, REDIS_REPLY_STRING)) {
      continue;
    }

    return 0;
  }

  LOG(ERROR) << "redis pop list error, key:" << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return -1;
}


bool RedisCli::LPush(const std::string &key, const string &value, int *max_len) {
  if (key.empty()) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_lpush_num,
                         &COUNTERS_redis__redis_lpush_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_lpush_num,
                                 &COUNTERS_redis__redis_lib_lpush_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "LPUSH %s %b",
                                            key.c_str(), value.c_str(),
                                            value.size()));
    }
    if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
      continue;
    }

    if (max_len) {
      *max_len = cli->reply->integer;
    }

    return true;
  }

  COUNTERS_redis__redis_error_num.Increase(1);
  LOG(ERROR) << "redis add list error, key:" << key;
  return false;
}


bool RedisCli::LPush(const string &key, const vector<string> &values, int *max_len) {
  if (key.empty() || values.empty()) return true;

  PerfTracer perf_tracer(&COUNTERS_redis__redis_lpush_num,
                         &COUNTERS_redis__redis_lpush_cost,
                         FLAGS_redis_perf_trace);
  bool ret = false;
  const char** argv;
  size_t* argvlen;

  vector<string> insert_val;
  int num = 0;
  for (auto begin = 0u; begin < values.size();) {
    if (begin + FLAGS_redis_batch_push_size < values.size()) {
      num = FLAGS_redis_batch_push_size;
    } else {
      num = values.size() - begin;
    }
    DLOG(INFO) << "push from:" << begin << ", num:" << num;

    argv = new const char* [num + 2];
    argvlen = new size_t[num + 2];
    argv[0] = "LPUSH";
    argvlen[0] = strlen(argv[0]);

    argv[1] = key.data();
    argvlen[1] = key.size();

    for (auto i = 0; i < num; ++i) {
      argv[i + 2] = values[begin + i].data();
      argvlen[i + 2] = values[begin + i].size();
    }

    ret = false;
    int retry_count = retry_num_;
    while (retry_count-- >= 0) {
      RedisAutoCli auto_cli(cli_pool_->Res());
      CliInfo *cli = auto_cli.Get();
      if (!cli->ctx) {
        ret = false;
        continue;
      }

      {
        PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_lpush_num,
                                   &COUNTERS_redis__redis_lib_lpush_cost,
                                   FLAGS_redis_lib_perf_trace);

        cli->reply = static_cast<redisReply*>(redisCommandArgv(cli->ctx, num + 2, argv, argvlen));
      }

      if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
        LOG(WARNING) << "reply err, key:" << key << ", val size:" << num;
        ret = false;
        continue;
      }

      if (max_len) {
        *max_len = cli->reply->integer;
      }

      ret = true;
      break;
    }  // end while

    delete [] argv;
    delete [] argvlen;
    begin += num;
  }  // end for

  COUNTERS_redis__redis_error_num.Increase(1);
  if (!ret)
    LOG(ERROR) << "redis add list error, key:" << key;

  return ret;
}


bool RedisCli::RPush(const std::string &key, const string &value, int *max_len) {
  if (key.empty()) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_rpush_num,
                         &COUNTERS_redis__redis_rpush_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_rpush_num,
                                 &COUNTERS_redis__redis_lib_rpush_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "RPUSH %s %b",
                                            key.c_str(), value.c_str(),
                                            value.size()));
    }

    if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
      continue;
    }

    if (max_len) {
      *max_len = cli->reply->integer;
    }

    return true;
  }

  LOG(ERROR) << "redis add list error, key:" << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}


bool RedisCli::RPush(const std::string &key, const std::vector<std::string> &values, int *max_len) {
  if (key.empty() || values.empty()) return true;

  PerfTracer perf_tracer(&COUNTERS_redis__redis_rpush_num,
                         &COUNTERS_redis__redis_rpush_cost,
                         FLAGS_redis_perf_trace);
  bool ret = false;
  const char** argv;
  size_t* argvlen;

  vector<string> insert_val;
  int num = 0;
  for (auto begin = 0u; begin < values.size();) {
    if (begin + FLAGS_redis_batch_push_size < values.size()) {
      num = FLAGS_redis_batch_push_size;
    } else {
      num = values.size() - begin;
    }
    DLOG(INFO) << "push from:" << begin << ", num:" << num;

    argv = new const char* [num + 2];
    argvlen = new size_t[num + 2];
    argv[0] = "RPUSH";
    argvlen[0] = strlen(argv[0]);

    argv[1] = key.data();
    argvlen[1] = key.size();

    for (auto i = 0; i < num; ++i) {
      argv[i + 2] = values[begin + i].data();
      argvlen[i + 2] = values[begin + i].size();
    }

    ret = false;
    int retry_count = retry_num_;
    while (retry_count-- >= 0) {
      RedisAutoCli auto_cli(cli_pool_->Res());
      CliInfo *cli = auto_cli.Get();
      if (!cli->ctx) {
        ret = false;
        continue;
      }

      {
        PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_rpush_num,
                                   &COUNTERS_redis__redis_lib_rpush_cost,
                                   FLAGS_redis_lib_perf_trace);

        cli->reply = static_cast<redisReply*>(redisCommandArgv(cli->ctx, num + 2, argv, argvlen));
      }

      if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
        LOG(WARNING) << "reply err, key:" << key << ", val size:" << num;
        ret = false;
        continue;
      }

      if (max_len) {
        *max_len = cli->reply->integer;
      }

      ret = true;
      break;
    }  // end while

    delete [] argv;
    delete [] argvlen;
    begin += num;
  }  // end for

  COUNTERS_redis__redis_error_num.Increase(1);
  if (!ret)
    LOG(ERROR) << "redis add list error, key:" << key;

  return ret;
}


int RedisCli::Exist(const std::string &key) {
  if (key.empty()) return 0;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_exist_num,
                         &COUNTERS_redis__redis_exist_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_exist_num,
                                 &COUNTERS_redis__redis_lib_exist_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "EXISTS %s", key.c_str()));
    }

    if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
      continue;
    }

    if (cli->reply->integer == 1) {
      return 0;
    } else {
      return 1;
    }
  }

  LOG(ERROR) << "exists redis key error: " << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return -1;
}

int RedisCli::TTL(const std::string &key) {
  if (key.empty()) return -2;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_ttl_num,
                         &COUNTERS_redis__redis_ttl_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_ttl_num,
                                 &COUNTERS_redis__redis_lib_ttl_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "TTL %s", key.c_str()));
    }

    if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
      continue;
    }

    if (cli->reply->integer >= -2) {
      return cli->reply->integer;
    }
    break;
  }

  LOG(ERROR) << "ttl redis key error: " << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return -3;
}


bool RedisCli::HSet(const std::string &key, const std::string &field, const std::string &value) {
  if (key.empty() || field.empty()) return false;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_hset_num,
                         &COUNTERS_redis__redis_hset_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_hset_num,
                                 &COUNTERS_redis__redis_lib_hset_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "HSET %s %s %b",
                                            key.c_str(), field.c_str(),
                                            value.c_str(), value.size()));
    }

    if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
      continue;
    }

    return true;
  }

  LOG(ERROR) << "redis hset error, key:" << key << ", field:" << field;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}


bool RedisCli::HGetAll(const std::string &key, std::unordered_map<std::string, std::string> *field_values) {
  CHECK_NOTNULL(field_values);
  field_values->clear();

  if (key.empty()) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_hgetall_num,
                         &COUNTERS_redis__redis_hgetall_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_hgetall_num,
                                 &COUNTERS_redis__redis_lib_hgetall_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "HGETALL %s", key.c_str()));
    }

    if (CheckReplyNil(cli)) {
      return true;
    }
    if (!CheckReply(cli, key, REDIS_REPLY_ARRAY)) {
      continue;
    }

    field_values->clear();

    if (cli->reply->elements < 2) {
      return true;
    }
    if (cli->reply->elements % 2 != 0) {
      LOG(ERROR) << "zrange err, key:" << key;
      return false;
    }

    for (auto i = 0u; i < cli->reply->elements - 1; i += 2) {
      string field(cli->reply->element[i]->str, cli->reply->element[i]->len);
      string value(cli->reply->element[i+1]->str, cli->reply->element[i+1]->len);
      field_values->insert(std::make_pair(field, value));
    }
    return true;
  }

  LOG(ERROR) << "get redis all field error, key: " << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}


bool RedisCli::ZRange(const string &key, const int64 start_idx, const int64 end_idx,
                      vector<string> *members, vector<double> *scores) {
  CHECK_NOTNULL(members);
  members->clear();
  CHECK_NOTNULL(scores);
  scores->clear();

  if (key.empty()) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_zrange_num,
                         &COUNTERS_redis__redis_zrange_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_zrange_num,
                                 &COUNTERS_redis__redis_lib_zrange_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "ZRANGE %s %ld %ld WITHSCORES",
                                            key.c_str(), start_idx, end_idx));
    }
    if (!CheckReply(cli, key, REDIS_REPLY_ARRAY)) {
      continue;
    }

    members->clear();
    scores->clear();

    if (cli->reply->elements % 2 != 0) {
      LOG(ERROR) << "zrange value err, key:" << key;
      return false;
    }

    for (auto i = 0u; cli->reply->elements > 0 && i < cli->reply->elements - 1; i += 2) {
      string member(cli->reply->element[i]->str, cli->reply->element[i]->len);
      string score_s(cli->reply->element[i+1]->str, cli->reply->element[i+1]->len);
      double score = 0.0;
      if (!base::StringToDouble(score_s, &score)) {
        LOG(ERROR) << "StringToDouble err:" << score_s;
        continue;
      }

      members->push_back(member);
      scores->push_back(score);
    }

    return true;
  }

  LOG(ERROR) << "redis zrange error, key: " << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}


bool RedisCli::ZAdd(const std::string &key, const std::string &member, const double score) {
  if (key.empty() || member.empty()) return false;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_zadd_num,
                         &COUNTERS_redis__redis_zadd_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    const std::string str_score = base::DoubleToString(score);
    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_zadd_num,
                                 &COUNTERS_redis__redis_lib_zadd_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "ZADD %s %s %s", key.c_str(),
                                            str_score.c_str(), member.c_str()));
    }
    if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
      continue;
    }

    return true;
  }

  LOG(ERROR) << "redis zadd error, key:" << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}


bool RedisCli::ZCard(const std::string &key, int *number) {
  *number = 0;
  if (key.empty()) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_zcard_num,
                         &COUNTERS_redis__redis_zcard_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_zcard_num,
                                 &COUNTERS_redis__redis_lib_zcard_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "ZCARD %s", key.c_str()));
    }
    if (!CheckReply(cli, key, REDIS_REPLY_INTEGER)) {
      continue;
    }

    *number = cli->reply->integer;
    return true;
  }

  LOG(ERROR) << "llen redis data error, key:" << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}


bool RedisCli::ZRevRange(const string &key, const int64 start_idx, const int64 end_idx,
                         vector<string> *members, vector<double> *scores) {
  CHECK_NOTNULL(members);
  members->clear();
  CHECK_NOTNULL(scores);
  scores->clear();

  if (key.empty()) return true;
  PerfTracer perf_tracer(&COUNTERS_redis__redis_zrevrange_num,
                         &COUNTERS_redis__redis_zrevrange_cost,
                         FLAGS_redis_perf_trace);

  int retry_count = retry_num_;
  while (retry_count-- >= 0) {
    RedisAutoCli auto_cli(cli_pool_->Res());
    CliInfo *cli = auto_cli.Get();
    if (!cli->ctx) continue;

    {
      PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_zrevrange_num,
                                 &COUNTERS_redis__redis_lib_zrevrange_cost,
                                 FLAGS_redis_lib_perf_trace);
      cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, "ZREVRANGE %s %ld %ld WITHSCORES",
                                            key.c_str(), start_idx, end_idx));
    }
    if (!CheckReply(cli, key, REDIS_REPLY_ARRAY)) {
      continue;
    }

    members->clear();
    scores->clear();

    if (cli->reply->elements % 2 != 0) {
      LOG(ERROR) << "zrange value err, key:" << key;
      return false;
    }

    for (auto i = 0u; cli->reply->elements > 0 && i < cli->reply->elements - 1; i += 2) {
      string member(cli->reply->element[i]->str, cli->reply->element[i]->len);
      string score_s(cli->reply->element[i+1]->str, cli->reply->element[i+1]->len);
      double score = 0.0;
      if (!base::StringToDouble(score_s, &score)) {
        LOG(ERROR) << "StringToDouble err:" << score_s;
        continue;
      }

      members->push_back(member);
      scores->push_back(score);
    }

    return true;
  }

  LOG(ERROR) << "redis revzrange error, key: " << key;
  COUNTERS_redis__redis_error_num.Increase(1);
  return false;
}
}  // namespace hbase
}  // namespace reco
