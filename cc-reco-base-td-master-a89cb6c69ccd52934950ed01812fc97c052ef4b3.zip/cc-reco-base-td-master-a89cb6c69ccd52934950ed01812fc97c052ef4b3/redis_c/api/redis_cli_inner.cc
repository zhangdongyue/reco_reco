#include "reco/base/redis_c/api/redis_cli_inner.h"

#include <vector>

// #include "boost/make_shared.hpp"

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/hash_function/city.h"
#include "base/random/pseudo_random.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

#include "reco/base/vipserver/api/vipserver_manager.h"

using std::string;
using std::vector;

namespace reco {
namespace redis {
// DEFINE_double(redis_pool_alive_rate, 0.8, "least alive handler rate of redis cluster");

// redis perf counters
DEFINE_bool(redis_perf_trace, false, "performance trace counter switch");
DEFINE_bool(redis_lib_perf_trace, false, "hiredis lib performance trace counter switch");

DEFINE_int64_counter(redis, redis_op_num, 0, "");
DEFINE_int64_counter(redis, redis_op_cost, 0, "");
DEFINE_int64_counter(redis, redis_connect_num, 0, "");
DEFINE_int64_counter(redis, redis_lib_connect_num, 0, "");
DEFINE_int64_counter(redis, redis_connect_cost, 0, "");
DEFINE_int64_counter(redis, redis_lib_connect_cost, 0, "");

ConnectionRes::ConnectionRes() {
  // thread::AutoLock lock(&res_mutex_);
  VLOG(1) << "this:" << this;
}

ConnectionRes::~ConnectionRes() {
  thread::AutoLock lock(&res_mutex_);

  LOG(INFO) << "release connect res:" << this
            << ", available_size:" << available_.size()
            << ", disconnect_size:" << disconnect_.size();

  ReleaseConnect(&available_);
  ReleaseConnect(&disconnect_);

  available_.clear();
  disconnect_.clear();
}

void ConnectionRes::ReleaseConnect(std::unordered_set<CliInfo> *connect_set) {
  for (auto iter = connect_set->begin(); iter != connect_set->end(); ++iter) {
    LOG(INFO) << "Destructor redis cli:" << iter->ctx;
    redisFree(iter->ctx);
  }
}

void ConnectionRes::Push(CliInfo* cli) {
  VLOG(1) << "res:" << this << ", ip_info:" << cli->ip_info << ", ctx:" << cli->ctx;

  if (cli->ip_sign == 0 && cli->ip_info.empty()) {
    LOG(ERROR) << "push illegal cli, ctx:" << cli->ctx
               << ", ip_info:" << cli->ip_info
               << ", ip_sign:" << cli->ip_sign;
    return;
  }

  if (cli->reply) {
    freeReplyObject(cli->reply);
    cli->reply = NULL;
  }

  VLOG(1) << "push before, res:"<< this
          << ", ctx:" << cli->ctx
          << ", availabl_:" << available_.size()
          << ", disconnect_:" << disconnect_.size();

  thread::AutoLock lock(&res_mutex_);
  if (!cli->ctx || cli->ctx->err != REDIS_OK) {
    disconnect_.insert(*cli);
    if (cli->ctx) {
      LOG(WARNING) << "redis op error, err_no:" << cli->ctx->err << ", err_msg:" << cli->ctx->errstr;
    }
  } else {
    available_.insert(*cli);
  }

  VLOG(1) << "push after, res:"<< this
          << ", ctx:" << cli->ctx
          << ", availabl_:" << available_.size()
          << ", disconnect_:" << disconnect_.size();
}

bool ConnectionRes::Pop(CliInfo* cli) {
  VLOG(1) << "res:" << this << ", cli:" << cli->ctx;
  cli->Clear();
  base::PseudoRandom random(base::GetTimestamp());

  thread::AutoLock lock(&res_mutex_);
  if (available_.empty()) {
    return false;
  }

  auto it = available_.begin();
  std::advance(it, random.GetUint64LT(available_.size()));
  *cli = *it;
  available_.erase(*cli);
  VLOG(1) << "res:" << this << ", cli:" << cli->ctx;

  return true;
}

bool ConnectionRes::PopErr(CliInfo* cli) {
  VLOG(1) << "res:" << this << ", cli:" << cli->ctx;

  cli->Clear();
  base::PseudoRandom random(base::GetTimestamp());

  thread::AutoLock lock(&res_mutex_);
  if (disconnect_.empty()) {
    return false;
  }

  auto it = disconnect_.begin();
  std::advance(it, random.GetUint64LT(disconnect_.size()));
  *cli = *it;
  disconnect_.erase(*cli);
  return true;
}

RedisCliPool::RedisCliPool(const string &redis_ips,
                           const int32 pool_size,
                           const int32 rw_timeout,
                           const bool is_vipserver_domain) {
  LOG(INFO) << "redis cli pool init.";

  rw_timeout_ = rw_timeout;
  pool_size_ = pool_size;
  conn_res_ = boost::shared_ptr<ConnectionRes>(new ConnectionRes);

  if (is_vipserver_domain) {
    LOG(INFO) << "redis pool use vipserver:" << vipserver_domain_;
    vipserver_domain_ = redis_ips;
    run_ = false;
    ConnectCheckLoop(); // 主动调用一次
  } else {
    LOG(INFO) << "redis pool use iplist:" << redis_ips;
    cur_ip_list_ = redis_ips;
    vipserver_domain_.clear();
    last_ip_list_.clear();

    BuildConnRes(cur_ip_list_, pool_size_, conn_res_);
  }

  run_ = true;
  connect_check_thread_.Start(::NewCallback(this, &RedisCliPool::ConnectCheckLoop));
}

void RedisCliPool::BuildConnRes(const std::string& ip_list,
                                const int32 pool_size,
                                boost::shared_ptr<ConnectionRes> conn_res) {
  vector<string> ips_vec;
  base::SplitString(ip_list, ",", &ips_vec);
  CHECK(ips_vec.size());

  base::PseudoRandom random(base::GetTimestamp());
  uint64 ips_pos = random.GetUint64LT(ips_vec.size());

  for (auto cli_num = 0; cli_num < pool_size; ++cli_num) {
    ips_pos = (ips_pos + 1) % ips_vec.size();
    const string &ip_str = ips_vec[ips_pos];
    if (ip_str.empty()) {
      LOG(ERROR) << "redis ip str is empty.";
      continue;
    }

    string ip;
    int port = 0;
    if (!ParseIpPort(ip_str, &ip, &port)) {
      continue;
    }

    CliInfo cli_info;
    if (Connect(ip_str, &cli_info, rw_timeout_, 1)) {
      conn_res->Push(&cli_info);
      LOG(INFO) << "available_, ip:" << ip_str << ", ctx:" << cli_info.ctx;
    } else {
      conn_res->Push(&cli_info);
      LOG(INFO) << "disconnect_, ip:" << ip_str << ", ctx" << cli_info.ctx;
    }
  }

  return;
}

bool RedisCliPool::Connect(const std::string& ip_str, CliInfo *cli_info, int32 rw_timeout, uint64 retry) {
  CHECK_NOTNULL(cli_info);
  PerfTracer perf_tracer(&COUNTERS_redis__redis_connect_num,
                         &COUNTERS_redis__redis_connect_cost,
                         FLAGS_redis_perf_trace);
  string ip;
  int port = 0;
  if (!ParseIpPort(ip_str, &ip, &port)) {
    LOG(FATAL) << "redis ip_str wrong configured:" << ip_str;
  }

  cli_info->ip_info = ip_str;
  cli_info->ip_sign = base::CityHash64(ip_str.c_str(), ip_str.size());

  if (cli_info->ctx) {
    // 已有句柄，直接重连
    if (redisReconnect(cli_info->ctx) == REDIS_OK) {
      LOG(INFO) << "redis reconnect succ:" << ip_str
                << ", handler:" << cli_info->ctx;
      return true;
    }
  } else {
    // 空句柄，新建连接
    for (auto i = 0u; i <= retry; ++i) {
      cli_info->ctx = Connect(ip, port, rw_timeout);
      if (cli_info->ctx) {
        break;
      } else {
        base::SleepForSeconds(1);
      }
    }

    if (cli_info->ctx != NULL) {
      LOG(INFO) << "redis connect succ:" << ip_str << ", handler:" << cli_info->ctx;
      return true;
    }
  }

  return false;
}

redisContext* RedisCliPool::Connect(const std::string &ip, const int port, const int32 timeout) {
  PerfTracer lib_perf_tracer(&COUNTERS_redis__redis_lib_connect_num,
                             &COUNTERS_redis__redis_lib_connect_cost,
                             FLAGS_redis_lib_perf_trace);

  struct timeval connect_timeout = { 5, 500000 };  // 1.5 seconds
  redisContext *c = redisConnectWithTimeout(ip.c_str(), port, connect_timeout);
  if (c == NULL || c->err) {
    if (c) {
      LOG(ERROR) << "connect redis error, msg:" << c->errstr
                 << ", ip:" << ip << ", port:" << port;
      redisFree(c);
    } else {
      LOG(ERROR) << "connect redis error, can't allocate redis context, ip:" << ip << ", port:" << port;
    }

    return NULL;
  }

  const time_t sec = timeout / 1000;
  const suseconds_t usec = timeout * 1000 - sec * 1e6;
  struct timeval rw_timeout = {sec, usec};
  DLOG(INFO) << "redis timeout, sec:" << sec << ", suseconds:" << usec;
  if (redisSetTimeout(c, rw_timeout) != REDIS_OK) {
    LOG(ERROR) << "set timeout fail, ctx:"<< c << ", timeout:" << timeout;
  }

  redisEnableKeepAlive(c);
  LOG(INFO) << "redis cli connect succ, ip:" << ip << ", port:" << port << ", cli:" << c;

  return c;
}

bool RedisCliPool::ParseIpPort(const std::string & ip_str, std::string *ip, int *port) {
  vector<string> ip_port;
  base::SplitString(ip_str, ":", &ip_port);
  if (ip_port.size() < 2u) {
    return false;
  }

  *ip = ip_port[0];
  *port = 0;
  return base::StringToInt(ip_port[1], port);
}

RedisCliPool::~RedisCliPool() {
  LOG(INFO) << "redis cli pool release.";

  run_ = false;
  connect_check_thread_.Join();

  thread::AutoLock lock(&mutex_);
  conn_res_.reset();
}

void RedisCliPool::ConnectCheckLoop() {
  LOG(INFO) << "RedisCliPool check loop run.";
  static std::string last_ip_list;

  do {
    // 监听 vipserver
    if (!vipserver_domain_.empty()) {
      last_ip_list_ = cur_ip_list_;
      if (reco::vipserver::VSClientMgrIns::instance().GetAllValidIpPortStr(vipserver_domain_,
                                                                           5000,
                                                                           &cur_ip_list_)) {
        if (last_ip_list_ != cur_ip_list_ && !cur_ip_list_.empty()) {
          boost::shared_ptr<ConnectionRes> new_conn_res(new ConnectionRes);
          BuildConnRes(cur_ip_list_, pool_size_, new_conn_res);

          thread::AutoLock lock(&mutex_);
          conn_res_ = new_conn_res;
          LOG(INFO) << "new redis ip list:" << cur_ip_list_ << ", this:" << conn_res_;
        }
      }
    }

    // 重连上次失败的 redis 句柄
    CliInfo cli;
    {
      thread::AutoLock lock(&mutex_);
      conn_res_->PopErr(&cli);
    }

    if (!cli.ip_info.empty()) {
      VLOG(1) << "pop err, ip_info" << cli.ip_info << ", ctx:" << cli.ctx;
      Connect(cli.ip_info, &cli, rw_timeout_, 0);
      {
        thread::AutoLock lock(&mutex_);
        conn_res_->Push(&cli);
      }
    } else {
      base::SleepForMilliseconds(50);
    }
  } while (run_);

  LOG(INFO) << "RedisCliPool check loop stop.";
}


RedisAutoCli::RedisAutoCli(boost::shared_ptr<ConnectionRes> conn_res) {
  timer_.Start();
  res_ptr_ = conn_res;

  if (res_ptr_->Pop(&cli_info_)) {
    return;
  } else {
    cli_info_.Clear();
  }
}


RedisAutoCli::~RedisAutoCli() {
  if (cli_info_.ctx) {
    res_ptr_->Push(&cli_info_);
  }

  res_ptr_.reset();
  COUNTERS_redis__redis_op_num.Increase(1);
  COUNTERS_redis__redis_op_cost.Increase(timer_.Stop());
}
}  // namespace redis
}  // namespace reco
