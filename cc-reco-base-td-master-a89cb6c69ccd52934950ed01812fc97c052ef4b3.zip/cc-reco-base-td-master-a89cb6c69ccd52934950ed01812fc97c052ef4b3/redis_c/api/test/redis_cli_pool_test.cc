#include "reco/base/redis_c/api/redis_cli_pool.h"

#include <iostream>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

#include "reco/base/vipserver/api/vipserver_manager.h"

using reco::redis::RedisCli;
using reco::redis::RedisAutoCli;
using reco::redis::CliInfo;
using std::string;
using std::vector;
using std::unordered_map;

namespace reco {
namespace redis {
DECLARE_string(redis_pool_ips);
DEFINE_int32(redis_push_num, 10000, "");
DEFINE_int32(connect_sleep, 0, "");
DEFINE_int32(stability_num, 10, "");

const char *key = "test_key";

class RedisCliPoolTest : public testing::Test {
 protected:
  void SetUp() {
    reco::vipserver::VSClientMgrIns::instance().Init();
    redis = new RedisCli(reco::redis::FLAGS_redis_pool_ips,
                         FLAGS_redis_pool_size,
                         10,
                         1,
                         true);
  }

  void TearDown() {
    if (redis) {
      delete redis;
      redis = NULL;
    }
  }

  RedisCli *redis;
};


TEST_F(RedisCliPoolTest, Connect) {
  LOG(INFO) << "test connect begin";

  std::string good_address = "127.0.0.1:6500";
  std::string bad_address = "127.0.0.1 6500";
  std::string ip;
  int port;
  ASSERT_FALSE(redis->GetPool()->ParseIpPort(bad_address, &ip, &port));
  ASSERT_TRUE(redis->GetPool()->ParseIpPort(good_address, &ip, &port));
  ASSERT_EQ(ip, "127.0.0.1");
  ASSERT_EQ(port, 6500);

  if (true) {
    RedisAutoCli cli_1(redis->GetPool()->Res());
    RedisAutoCli cli_2(redis->GetPool()->Res());

    ASSERT_TRUE(cli_1.Get()->ctx != NULL);
    ASSERT_TRUE(cli_2.Get()->ctx != NULL);

    ASSERT_EQ(redisReconnect(cli_2.Get()->ctx), 0);

    CliInfo *cli_info = cli_1.Get();
    for (auto i = 0u; i < 3u; ++i) {
      cli_info->ctx = NULL;
      ASSERT_TRUE(redis->GetPool()->Connect(cli_info->ip_info, cli_info, 10, i));
    }
  }

  /*
  int i = 10;
  while (i-- > 0) {
    base::SleepForSeconds(1);
    LOG(INFO) << "waiting...";
  }
  */

  base::SleepForSeconds(FLAGS_connect_sleep);
  LOG(INFO) << "test connect end";
}

TEST_F(RedisCliPoolTest, Mget) {
  RedisAutoCli auto_cli(redis->GetPool()->Res());
  CliInfo *cli = auto_cli.Get();
  ASSERT_TRUE(cli->ctx != NULL);

  std::vector<std::string> keys;
  keys.push_back("aa");
  keys.push_back("bb");
  keys.push_back("cc");
  keys.push_back("dd");

  std::vector<std::string> values;
  values.resize(keys.size());

  int ret = -1;
  const std::string key_str = "mget " + base::JoinStrings(keys, " ");
  cli->reply = static_cast<redisReply*>(redisCommand(cli->ctx, key_str.c_str()));
  if (cli->reply == NULL || cli->ctx->err != 0) {
    ret = -1;
    return;
  }

  if (cli->reply->type != REDIS_REPLY_ARRAY) {
    LOG(WARNING) << "redis return val type error, type:" << cli->reply->type;
  }

  LOG(INFO) << "ret elems size:" << cli->reply->elements;
  for (auto i = 0u; i < cli->reply->elements; ++i) {
    if (cli->reply->element[i]->type == REDIS_REPLY_NIL) {
      ret = 1;
      LOG(WARNING) << "key not exist:" << keys[i];
    } else {
      values.at(i).assign(cli->reply->element[i]->str, cli->reply->element[i]->len);
      LOG(INFO) << "index: " << i << ", values: " << values.at(i);
    }
  }

  return;
}


TEST_F(RedisCliPoolTest, Del) {
  redis->SetEx(key, "111");
  ASSERT_EQ(redis->Exist(key), 0);

  ASSERT_TRUE(redis->Del(key));
  ASSERT_EQ(redis->Exist(key), 1);
  ASSERT_TRUE(redis->Del(key));
}


TEST_F(RedisCliPoolTest, Expire) {
  redis->SetEx(key, "111");
  ASSERT_EQ(redis->Exist(key), 0);

  redis->Expire(key, 2);
  base::SleepForSeconds(3);
  ASSERT_EQ(redis->Exist(key), 1);
}

TEST_F(RedisCliPoolTest, TTL) {
  redis->SetEx(key, "111", 100);
  ASSERT_LE(redis->TTL(key), 100);
  ASSERT_GE(redis->TTL(key), 99);

  redis->Expire(key, 2);
  base::SleepForSeconds(3);
  ASSERT_EQ(redis->TTL(key), -2);
}

TEST_F(RedisCliPoolTest, Ping) {
  ASSERT_TRUE(redis->Ping());
}


TEST_F(RedisCliPoolTest, IncrBy) {
  redis->SetEx(key, "1");
  ASSERT_EQ(redis->Exist(key), 0);

  ASSERT_TRUE(redis->IncrBy(key));
  string val;
  redis->Get(key, &val);
  ASSERT_EQ(val, "2");

  ASSERT_TRUE(redis->IncrBy(key, 10));
  val.clear();
  redis->Get(key, &val);
  ASSERT_EQ(val, "12");
}


TEST_F(RedisCliPoolTest, Get) {
  redis->SetEx(key, "111");
  ASSERT_EQ(redis->Exist(key), 0);

  string val;
  ASSERT_EQ(redis->Get(key, &val), 0);
  ASSERT_EQ(val, "111");

  ASSERT_TRUE(redis->Del(key));
  ASSERT_EQ(redis->Get(key, &val), 1);
}


TEST_F(RedisCliPoolTest, MGet) {
  const char *key1 = "11";
  const char *key2 = "22";
  const char *key3 = "33";
  redis->SetEx(key1, "111");
  redis->SetEx(key2, "222");
  redis->SetEx(key3, string());

  std::vector<string> keys;
  keys.push_back(key1);
  keys.push_back(key2);
  keys.push_back(key3);

  std::vector<string> values;
  ASSERT_EQ(redis->MGet(keys, &values), 0);
  ASSERT_EQ(values[0], "111");
  ASSERT_EQ(values[1], "222");
  ASSERT_EQ(values[2], "");

  keys.push_back("test_123");
  std::vector<int> ret_codes;
  ASSERT_EQ(redis->MGet(keys, &values, &ret_codes), 1);
  ASSERT_EQ(ret_codes[2], 0);
  ASSERT_EQ(values[3], "");
  ASSERT_EQ(ret_codes[3], 1);
}


TEST_F(RedisCliPoolTest, SetEx) {
  redis->SetEx(key, "111", 2);
  ASSERT_EQ(redis->Exist(key), 0);

  base::SleepForSeconds(3);
  ASSERT_EQ(redis->Exist(key), 1);
}


TEST_F(RedisCliPoolTest, LPush) {
  ASSERT_TRUE(redis->Del(key));

  vector<string> values;
  ASSERT_EQ(redis->LRange(key, &values, 0, -1), true);

  values.clear();
  const int max = FLAGS_redis_push_num;

  serving_base::Timer timer;
  timer.Start();
  for (auto i = 0; i < max; ++i) {
    ASSERT_EQ(redis->LPush(key, base::IntToString(i)), true);
  }
  LOG(ERROR) << "lpush cost:" << timer.Stop();

  values.clear();
  ASSERT_EQ(redis->LRange(key, &values, 0, -1), true);
  for (auto i = 0; i < max; ++i) {
    ASSERT_EQ(values[i], base::IntToString(max - 1 - i));
  }
}

TEST_F(RedisCliPoolTest, LPush_vec) {
  ASSERT_TRUE(redis->Del(key));

  vector<string> values;
  ASSERT_EQ(redis->LRange(key, &values, 0, -1), true);

  values.clear();
  const int max = FLAGS_redis_push_num;
  for (auto i = 0; i < max; ++i) {
    values.push_back(base::IntToString(i));
  }

  serving_base::Timer timer;
  timer.Start();
  ASSERT_EQ(redis->LPush(key, vector<string>(values.rbegin(), values.rend())), true);
  LOG(ERROR) << "lpush vec cost:" << timer.Stop();

  values.clear();
  ASSERT_EQ(redis->LRange(key, &values, 0, -1), true);
  for (auto i = 0; i < max; ++i) {
    ASSERT_EQ(values[i], base::IntToString(i));
  }
}

TEST_F(RedisCliPoolTest, RPush) {
  ASSERT_TRUE(redis->Del(key));
  ASSERT_EQ(redis->Exist(key), 1);

  vector<string> values;
  const int max = FLAGS_redis_push_num;
  int len = 0;
  for (auto i = 0; i < max; ++i) {
    ASSERT_EQ(redis->RPush(key, base::IntToString(i), &len), true);
  }

  values.clear();
  ASSERT_EQ(redis->LRange(key, &values, 0, -1), true);
  for (auto i = 0; i < max; ++i) {
    ASSERT_EQ(values[i], base::IntToString(i));
  }
}

TEST_F(RedisCliPoolTest, RPush_vec) {
  ASSERT_TRUE(redis->Del(key));

  vector<string> values;
  ASSERT_EQ(redis->LRange(key, &values, 0, -1), true);

  values.clear();
  const int max = FLAGS_redis_push_num;
  for (auto i = 0; i < max; ++i) {
    values.push_back(base::IntToString(i));
  }

  serving_base::Timer timer;
  timer.Start();
  ASSERT_EQ(redis->RPush(key, values), true);
  LOG(ERROR) << "rpush vec cost:" << timer.Stop();

  values.clear();
  ASSERT_EQ(redis->LRange(key, &values, 0, -1), true);
  for (auto i = 0; i < max; ++i) {
    ASSERT_EQ(values[i], base::IntToString(i));
  }
}


TEST_F(RedisCliPoolTest, LPop) {
  ASSERT_TRUE(redis->Del(key));
  ASSERT_EQ(redis->Exist(key), 1);

  // key not exist
  ASSERT_EQ(redis->LPop(key), 1);

  vector<string> values;
  for (auto i = 0; i < 10; ++i) {
    ASSERT_EQ(redis->RPush(key, base::IntToString(i)), true);
  }

  for (auto i = 0; i < 5; ++i) {
    ASSERT_EQ(redis->LPop(key), 0);
  }

  values.clear();
  ASSERT_EQ(redis->LRange(key, &values, 0, -1), true);
  ASSERT_EQ(values.size(), 5u);
  for (auto i = 0; i < 5; ++i) {
    ASSERT_EQ(values[i], base::IntToString(5 + i));
  }
}


TEST_F(RedisCliPoolTest, HGetAll) {
  ASSERT_TRUE(redis->Del(key));
  ASSERT_EQ(redis->Exist(key), 1);

  unordered_map<string, string> field_vals;
  ASSERT_TRUE(redis->HGetAll(key, &field_vals));
  ASSERT_EQ(field_vals.size(), 0u);

  const string field1 = "field1";
  const string field2 = "field2";
  const string val1 = "Hello";
  const string val2 = "World";

  ASSERT_TRUE(redis->HSet(key, field1, val1));
  ASSERT_TRUE(redis->HSet(key, field2, val2));

  ASSERT_TRUE(redis->HGetAll(key, &field_vals));
  ASSERT_EQ(field_vals[field1], val1);
  ASSERT_EQ(field_vals[field2], val2);
}


TEST_F(RedisCliPoolTest, LLEN) {
  LOG(INFO) << "begin test llen";
  ASSERT_TRUE(redis->Del(key));
  ASSERT_EQ(redis->Exist(key), 1);

  redis->SetEx(key, "xxx", 1000);

  int len = 0;
  LOG(INFO) << "llen a string type begin.";
  ASSERT_FALSE(redis->LLen(key, &len));
  LOG(INFO) << "llen a string type over.";
  ASSERT_TRUE(redis->Del(key));

  vector<string> values;
  for (auto i = 0; i < 10; ++i) {
    ASSERT_EQ(redis->RPush(key, base::IntToString(i), &len), true);
  }
  values.clear();

  int read_len = 0;
  ASSERT_TRUE(redis->LLen(key, &read_len));
  ASSERT_EQ(len, read_len);

  LOG(INFO) << "end test llen";
}


TEST_F(RedisCliPoolTest, ZRange) {
  ASSERT_TRUE(redis->Del(key));
  ASSERT_EQ(redis->Exist(key), 1);

  vector<string> members;
  vector<double> scores;
  ASSERT_TRUE(redis->ZRange(key, 0, -1, &members, &scores));
  ASSERT_EQ(members.size(), 0u);

  bool ret = redis->ZRange(key, 0, -1, &members, &scores);
  DLOG(INFO) << "zrange not exist key, ret:" << ret;

  const string field1 = "field1";
  const string field2 = "field2";
  const double val1 = 1.0;
  const double val2 = 0.2;

  ASSERT_TRUE(redis->ZAdd(key, field1, val1));
  ASSERT_TRUE(redis->ZAdd(key, field2, val2));

  ASSERT_TRUE(redis->ZRange(key, 0, -1, &members, &scores));
  ASSERT_EQ(members[0], field2);
  ASSERT_EQ(scores[0], val2);
  ASSERT_EQ(members[1], field1);
  ASSERT_EQ(scores[1], val1);
}

TEST_F(RedisCliPoolTest, ZRevRange) {
  ASSERT_TRUE(redis->Del(key));
  ASSERT_EQ(redis->Exist(key), 1);

  vector<string> members;
  vector<double> scores;
  ASSERT_TRUE(redis->ZRevRange(key, 0, -1, &members, &scores));
  ASSERT_EQ(members.size(), 0u);

  bool ret = redis->ZRevRange(key, 0, -1, &members, &scores);
  DLOG(INFO) << "zrange not exist key, ret:" << ret;

  const string field1 = "field1";
  const string field2 = "field2";
  const double val1 = 1.0;
  const double val2 = 0.2;

  ASSERT_TRUE(redis->ZAdd(key, field1, val1));
  ASSERT_TRUE(redis->ZAdd(key, field2, val2));

  ASSERT_TRUE(redis->ZRevRange(key, 0, -1, &members, &scores));
  ASSERT_EQ(members[0], field1);
  ASSERT_EQ(scores[0], val1);
  ASSERT_EQ(members[1], field2);
  ASSERT_EQ(scores[1], val2);
}


TEST_F(RedisCliPoolTest, ZCard) {
  ASSERT_TRUE(redis->Del(key));
  ASSERT_EQ(redis->Exist(key), 1);

  int number = 0;
  ASSERT_TRUE(redis->ZCard(key, &number));

  bool ret = redis->ZCard(key, &number);
  DLOG(INFO) << "zcard not exist key, ret:" << ret;

  const string field1 = "field1";
  const string field2 = "field2";
  const double val1 = 1.0;
  const double val2 = 0.2;

  ASSERT_TRUE(redis->ZAdd(key, field1, val1));
  ASSERT_TRUE(redis->ZAdd(key, field2, val2));

  ASSERT_TRUE(redis->ZCard(key, &number));
  ASSERT_EQ(number, 2);
}

TEST_F(RedisCliPoolTest, Stablity) {
  std::string value;
  for (auto i = 0; i < FLAGS_stability_num; ++i) {
    if (redis->SetEx(base::IntToString(i), base::IntToString(i))) {
      ASSERT_EQ(redis->Get(base::IntToString(i), &value), 0);
    } else {
    base::SleepForSeconds(1);
    }
  }
}
}
}
