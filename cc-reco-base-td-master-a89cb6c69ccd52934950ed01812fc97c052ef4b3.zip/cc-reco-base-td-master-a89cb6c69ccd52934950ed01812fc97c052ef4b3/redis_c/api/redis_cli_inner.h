#pragma once

#include <string>
#include <unordered_set>

#include "boost/shared_ptr.hpp"

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/testing/gtest.h"
#include "base/thread/sync.h"
#include "base/thread/thread.h"
#include "serving_base/utility/timer.h"
#include "third_party/hiredis/hiredis.h"


namespace reco {
namespace redis {
DECLARE_string(redis_pool_ips);  // 准备废弃

class RedisCliPool;

class PerfTracer {
 public:
  explicit PerfTracer(::google::Int64Counter* p_num_counter,
                      ::google::Int64Counter* p_cost_counter,
                      bool enable = false) {
    p_num_counter_ = NULL;
    p_cost_counter_ = NULL;
    enable_ = enable;

    if (enable && p_num_counter != NULL && p_cost_counter != NULL) {
      timer_.Start();
      p_num_counter_ = p_num_counter;
      p_cost_counter_ = p_cost_counter;
      p_num_counter_->Increase(1);
    }
  }

  ~PerfTracer() {
    if (enable_ && p_num_counter_ != NULL && p_cost_counter_ != NULL) {
      p_cost_counter_->Increase(timer_.Stop());
    }
  }

 private:
  serving_base::Timer timer_;
  ::google::Int64Counter* p_num_counter_;
  ::google::Int64Counter* p_cost_counter_;
  bool enable_;

  DISALLOW_COPY_AND_ASSIGN(PerfTracer);
};

struct CliInfo {
  redisContext *ctx;
  redisReply *reply;
  std::string ip_info;
  uint64 ip_sign;

  CliInfo() {
    Clear();
  }

  void Clear() {
    ctx = NULL;
    reply = NULL;
    ip_info.clear();
    ip_sign = 0;
  }

  bool operator== (const CliInfo &cli_info) const {
    if (cli_info.ctx == this->ctx && cli_info.ip_sign == this->ip_sign) {
      return true;
    }
    return false;
  }
};
}
}

namespace std {
template<>
struct hash<reco::redis::CliInfo> {
  typedef reco::redis::CliInfo argument_type;
  typedef std::size_t result_type;

  result_type operator() (argument_type const& s) const {
    return reinterpret_cast<result_type>(s.ctx);
  }
};
}

namespace reco {
namespace redis {
class ConnectionRes {
 public:
  ConnectionRes();

  ~ConnectionRes();

  // 添加到资源池中, 自动判断资源状态
  void Push(CliInfo* cli);

  // 得到一个可用资源
  bool Pop(CliInfo* cli);

  // 得到一个有问题的链接, 用于重连
  bool PopErr(CliInfo* cli);

 private:
  void ReleaseConnect(std::unordered_set<CliInfo> *connect_set);

 private:
  mutable thread::Mutex res_mutex_;
  std::unordered_set<CliInfo> available_;
  std::unordered_set<CliInfo> disconnect_;
};

class RedisAutoCli {
 public:
  explicit RedisAutoCli(boost::shared_ptr<ConnectionRes> conn_res);

  ~RedisAutoCli();

  inline CliInfo* Get() {
    return &cli_info_;
  }

 private:
  CliInfo cli_info_;
  boost::shared_ptr<ConnectionRes> res_ptr_;
  serving_base::Timer timer_;

  DISALLOW_COPY_AND_ASSIGN(RedisAutoCli);
};

class RedisCliPool {
 public:
  explicit RedisCliPool(const std::string &redis_ips,
                        const int32 pool_size,
                        const int32 rw_timeout,
                        const bool is_vipserver_domain);

  ~RedisCliPool();
  
  boost::shared_ptr<ConnectionRes> Res(void) {
    thread::AutoLock lock(&mutex_);
    return conn_res_;
  }
  
 private:
  void BuildConnRes(const std::string& ip_list,
                    const int32 pool_size,
                    boost::shared_ptr<ConnectionRes> conn_res);

  redisContext* Connect(const std::string &ip, const int port, const int rw_timeout);

  bool ParseIpPort(const std::string & ip_str, std::string *ip, int *port);

  void ConnectCheckLoop(void);

  bool Connect(const std::string & ip_str, CliInfo *cli_info, int32 rw_timeout, uint64 retry = 1);

 private:
  int32 rw_timeout_;
  int32 pool_size_;
  thread::Thread connect_check_thread_;

  mutable thread::Mutex mutex_;
  std::atomic_bool run_;
  std::string vipserver_domain_;
  std::string cur_ip_list_;
  std::string last_ip_list_;
  boost::shared_ptr<ConnectionRes> conn_res_;

  FRIEND_TEST(RedisCliPoolTest, Connect);
  FRIEND_TEST(RedisCliPoolTest, ParseIpPort);

  DISALLOW_COPY_AND_ASSIGN(RedisCliPool);
};
}
}
