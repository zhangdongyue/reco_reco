#pragma once

#include <string>
#include <unordered_map>
#include <vector>

#include "reco/base/redis_c/api/redis_cli_inner.h"

namespace reco {
namespace redis {
DECLARE_string(redis_pool_ips);  // 准备废弃
DECLARE_int32(redis_pool_size);  // 准备废弃
DECLARE_int32(redis_rw_timeout_ms);
DECLARE_int32(redis_retry_count);
DECLARE_int32(redis_expire_seconds);
DECLARE_bool(redis_perf_trace);
DECLARE_bool(redis_lib_perf_trace);

// 具体操作使用: redo::redis::RedisCliIns::instance().xxx();
// typedef reco::common::singleton_default<RedisCliPool> RedisCliPoolIns;
// typedef reco::common::singleton_default<RedisCli> RedisCliIns;

class RedisCli {
 public:
  RedisCli() : cli_pool_(NULL), retry_num_(0) {}

  explicit RedisCli(const std::string &redis_ips,
                    const int32 pool_size = FLAGS_redis_pool_size,
                    const int32 rw_timeout = FLAGS_redis_rw_timeout_ms,
                    const int32 retry_num = FLAGS_redis_retry_count,
                    const bool is_vipserver_domain = false) {
    LOG(INFO) << "redis cli init.";
    cli_pool_ = new RedisCliPool(redis_ips, pool_size, rw_timeout, is_vipserver_domain);
    CHECK_NOTNULL(cli_pool_);

    retry_num_ = retry_num;
  }

  ~RedisCli();

  RedisCliPool* GetPool() {
    return cli_pool_;
  }

  // true: succ
  // false: fail
  bool Ping(void);

  // true: succ
  // false: fail
  bool Expire(const std::string &key, const int life_in_seconds = FLAGS_redis_expire_seconds);

  // true: succ
  // false: fail
  bool Del(const std::string &key);

  // key 存在返回 0,
  // key 不存在返回 1,
  // 其他错误返回 -1
  int Exist(const std::string &key);

  // key 不存在返回-2,
  // key 存在但是没有设置剩余生存时间, 返回 -1,
  // 否则以秒为单位返回 key 的剩余生存时间
  // 其他错误返回 -3
  int TTL(const std::string &key);

  // true: succ
  // false: fail
  bool IncrBy(const std::string &key, const int64 cnt = 1, int64 *val = NULL);

  // return 0 if success
  // return 1 if keys 中有 key 不存在，对应位置的 value 会设置为 empty
  // return -1 for other errors
  int Get(const std::string &key, std::string *value);

  // return 0 if success
  // return 1 if keys 中有 key 不存在，对应位置的 value 会设置为 empty
  // return -1 for other errors
  // ret_codes: 0 表示成功，1 表示 key 不存在，-1 表示出错
  int MGet(const std::vector<std::string> &keys,
           std::vector<std::string> *values,
           std::vector<int> *ret_codes = NULL);

  // 底层调用 MGet
  // values, ret_codes must not be NULL
  void MGetWithStep(int step_size, const std::vector<std::string> &keys,
                    std::vector<std::string> *values,
                    std::vector<int> *ret_codes);

  // true: succ
  // false: fail
  bool SetEx(const std::string &key, const std::string &value, const int ttl = FLAGS_redis_expire_seconds);

  // 返回 list 长度
  // true: succ
  // false: fail
  bool LLen(const std::string &key, int *len);

  // true: succ
  // false: fail
  bool LRange(const std::string &key, std::vector<std::string> *values,
              const int begin = 0, const int end = -1);

  // return 0 if success
  // return 1 if the |key| dosen't exist
  // return -1 for other errors
  int LPop(const std::string &key);

  // true: succ
  // false: fail
  // 注意，参数 values 在 redis server 里面依然是对每个元素顺序执行 lpush 操作
  // 例如: [0 1 2] 逐个执行 lpush 后，在 redis list 的顺序是： [2 1 0]
  bool LPush(const std::string &key, const std::string &value, int *max_len = NULL);
  bool LPush(const std::string &key, const std::vector<std::string> &values, int *max_len = NULL);

  // true: succ
  // false: fail
  bool RPush(const std::string &key, const std::string &value, int *max_len = NULL);
  bool RPush(const std::string &key, const std::vector<std::string> &values, int *max_len = NULL);

  // true: succ
  // false: fail
  bool HSet(const std::string &key, const std::string &field, const std::string &value);

  // true: succ
  // false: fail
  bool HGetAll(const std::string &key, std::unordered_map<std::string, std::string> *field_values);

  // true: succ
  // false: fail
  bool ZAdd(const std::string &key, const std::string &member, const double score);

  // key 不存在时，返回 true, 数量是 0, 无法判断是空的 set 还是 key 不存在，需要单独判断 key 是否存在
  // true: succ
  // false: fail
  bool ZRange(const std::string &key, const int64 start_idx, const int64 end_idx,
              std::vector<std::string>* members, std::vector<double>* scores);

  // key 不存在时，返回 true, 数量是 0, 无法判断是空的 set 还是 key 不存在，需要单独判断 key 是否存在
  // true: succ
  // false: fail
  bool ZCard(const std::string &key, int *number);

  // key 不存在时，返回 true, 数量是 0, 无法判断是空的 set 还是 key 不存在，需要单独判断 key 是否存在
  // true: succ
  // false: fail
  bool ZRevRange(const std::string &key, const int64 start_idx, const int64 end_idx,
                std::vector<std::string>* members, std::vector<double>* scores);

 private:
  // 检测返回数据，并判断返回值的类型是否是期望值, 只对单一返回值类型有效
  // 如果可以返回 nil 和 int ，请单独实现
  bool CheckReply(const CliInfo *cli, const std::string &key, const int &expect_type);

  inline bool CheckReplyNil(const CliInfo *cli);

 private:
  RedisCliPool *cli_pool_;
  int retry_num_;

  DISALLOW_COPY_AND_ASSIGN(RedisCli);
};

}  // namespace redis
}  // namespace reco
