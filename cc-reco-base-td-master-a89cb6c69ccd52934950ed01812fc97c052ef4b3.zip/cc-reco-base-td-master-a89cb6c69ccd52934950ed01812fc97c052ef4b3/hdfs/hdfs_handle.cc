#include "reco/base/hdfs/hdfs_handle.h"
#include <stdlib.h>
#include <vector>
#include <string>
#include "base/common/logging.h"
#include "base/strings/string_split.h"
#include "base/process/process_util.h"
#include "base/process/command_line.h"

namespace hdfs {

namespace internal {

std::string parse_hdfs_error(int err_code) {
  std::string err_message = "[HDFS] ";
  switch (err_code) {
    case EINTERNAL: {
      err_message += "java environment error";
      break;
    }
    case EBADF: {
      err_message += "bad pointer";
      break;
    }
    case EACCES: {
      err_message += "access deny";
      break;
    }
    case EDQUOT: {
      err_message += "exceed quota";
      break;
    }
    case ENOENT: {
      err_message += "file not found";
      break;
    }
    case ENOTSUP: {
      err_message += "not supported operation";
      break;
    }
    case ENOMEM: {
      err_message += "insufficient memory";
      break;
    }
    case EINVAL: {
      err_message += "invalid parameter";
      break;
    }
    default: {
      err_message += "unspecified reason";
    }
  }
  return err_message;
}
}  // namespace

HDFSHandle::HDFSHandle(const char* host, int port)
  : hdfs_handle_(NULL), port_(port) {
  if (host) {
    host_ = host;
  } else {
    host_ = "";
  }
}

HDFSHandle::~HDFSHandle() {
  if (hdfs_handle_ != NULL) Disconnect();
}

bool HDFSHandle::Connect() {
  // if connected, disconnect it
  if (hdfs_handle_ != NULL) Disconnect();
  // now, we can connect to hadoop
  errno = 0;

  if (host_.size() > 0) {
    // hdfs_handle_ = hdfsConnectNewInstance(host_.c_str(), port_);
    hdfs_handle_ = hdfsConnect(host_.c_str(), port_);
  } else {
    // hdfs_handle_ = hdfsConnectNewInstance(NULL, 0);
    hdfs_handle_ = hdfsConnect(NULL, 0);
  }

  return hdfs_handle_ != NULL;
}

bool HDFSHandle::Disconnect() {
  if (hdfs_handle_ == NULL) return true;
  errno = 0;
  int ret = hdfsDisconnect(hdfs_handle_);
  if (ret == 0) {
    hdfs_handle_ = NULL;
    return true;
  } else {
    LOG(ERROR) << internal::parse_hdfs_error(errno);
    return false;
  }
  return true;
}

}  // namespace
