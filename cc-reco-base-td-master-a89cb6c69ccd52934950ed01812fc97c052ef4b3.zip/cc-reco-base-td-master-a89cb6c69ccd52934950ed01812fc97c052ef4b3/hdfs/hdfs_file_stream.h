#pragma once
#include <string>

#include "base/common/basic_types.h"
#include "reco/base/hdfs/hdfs.h"
#include "reco/base/hdfs/hdfs_handle.h"

namespace hdfs {
// NOTICE: 关于 hdfs 文件读写的重试
// HDFSFileStream 的读写带有重试，
// 重试会关闭 hdfs 句柄并重连 hadoop，每次重连之间
// 调用线程将被挂起|retry_interval_|
//
// HDFSFileStream in(host, port);
// in.set_retry_times(kMaxRetryTimes);
// in.set_retry_interval(kSleepingSeconds);
// while (in.Read(buf, required_length) > 0) {
//   DoSomething(buf);
// }
//
// class for read/write hdfs files
class HDFSFileStream {
 public:
  HDFSFileStream(const char *host, int port);

  virtual ~HDFSFileStream();

  // set retry times for read/write
  // retry 是指失败后的重试，不包括第一次执行
  // the retry in this class is controled by this function,
  // not FLAGS_retry_time in hdfs_file_util.h
  void set_retry_times(int retry_times) {
    retry_ = retry_times;
  }

  void set_retry_interval(int seconds) {
    retry_interval_ = seconds;
  }

  // Open a hdfs file, open_flags can ONLY be:
  // O_RDONLY, read only
  // O_WRONLY, write only
  // O_WRONLY|O_APPEND, append
  // Return true if opened.
  bool Open(const char* path, int open_flags) WARN_UNUSED_RESULT;

  // Close a hdfs file. return true on success
  bool Close();

  // Read data from the current stream position.
  // Up to buf_len bytes will be copied into buf until reach EOF.
  // Before read, a file should be opened first
  // Returns the number of bytes copied, or -1 if failed.
  // the return number may be less than buf_len, 0 if EOF reached
  //
  // NOTICE: 在以 O_RDONLY 打开一个文件时，只能使用 Read 和 ReadLine 中的一种进行读取。
  // 在一次文件打开中二者不能交替使用（库会打 FATAL 以防止你这么干）。
  // 但是在不同的文件打开中可以使用不同的 api，比如你可以用 Read 来读 a 文件，用 ReadLine 读 b 文件
  //
  // NOTICE: this api is with retrys (default 0, use set_retry_time() to change it).
  // NOTE(all): The thread will hang up for |retry_interval_| seconds between two retries.
  // The default |retry_interval_| is 0.
  int32 Read(char* buf, int buf_len) WARN_UNUSED_RESULT;

  // Read a line from hdfs file.
  // Line ends with '\r\n', '\n',
  // but the trailing \n will not be stored in *line
  // Before read, a file should be opened first
  // return true if read some data,
  // false if nothing is read or error happens
  //
  // NOTICE: if false returned, you can further use Eof() api to distiguish
  // between EOF encountered and error encountered
  //
  // NOTICE: 在以 O_RDONLY 打开一个文件时，只能使用 Read 和 ReadLine 中的一种进行读取。
  // 在一次文件打开中二者不能交替使用（库会打 FATAL 以防止你这么干）。
  // 但是在不同的文件打开中可以使用不同的 api ，比如你可以用 Read 来读 a 文件，用 ReadLine 读 b 文件
  //
  // NOTICE: this api is with retrys (default 0, use set_retry_time() to change it).
  //
  bool ReadLine(std::string *line) WARN_UNUSED_RESULT;

  // Write data at the current stream position, with retrys (default 0).
  // Up to buf_len bytes will be written from buf.
  // Before wrote, a file should be opened first
  // Returns the number of bytes written, or -1 if failed.
  //
  // NOTICE: this api is with retrys (default 0, use set_retry_time() to change it).
  // NOTE(all): The thread will hang up for |retry_interval_| seconds between two retries.
  // The default |retry_interval_| is 0.
  int32 Write(const char* buf, int buf_len) WARN_UNUSED_RESULT;

  // Forces out writing to hdfs
  bool Flush();

  bool Eof() {
    return eof_;
  };
 protected:
  const char* host() const { return host_; }
  int32 port() const { return port_; }
  virtual HDFSHandle* CreateHdfsHandle();
 private:
  // internal read implement
  int32 InternalRead(char* buf, int buf_len);

  const char *host_;
  int port_;
  HDFSHandle *handle_;
  hdfsFile file_;
  std::string path_;
  int retry_;
  int retry_interval_;
  std::string readline_buf_;
  bool eof_;

  enum ReadMode {
    kModeNull = 0,
    kModeRead,
    kModeReadLine,
  };
  ReadMode read_mode_;

  DISALLOW_COPY_AND_ASSIGN(HDFSFileStream);
};

}  // namespace hadoop

