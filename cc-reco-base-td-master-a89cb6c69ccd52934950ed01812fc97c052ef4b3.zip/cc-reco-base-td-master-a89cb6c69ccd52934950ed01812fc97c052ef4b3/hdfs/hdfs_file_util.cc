#include "reco/base/hdfs/hdfs_file_util.h"
#include "reco/base/hdfs/hdfs_file_stream.h"
#include <vector>
#include "base/common/logging.h"
#include "base/file/file_util.h"
#include "base/common/sleep.h"

namespace hdfs {

// the macro is used only within this file, will be undefined

#define HADOOP_RETRY \
      if (retry < FLAGS_hdfs_retry_time) { \
        base::SleepForSeconds(FLAGS_hdfs_retry_sleep_second); \
        CHECK(hadoop_handle.Connect()); \
        continue; \
      } else {  \
        break; \
      }


DEFINE_int32(hdfs_retry_time, 3, "retry times for hadoop operation");
DEFINE_int32(hdfs_retry_sleep_second, 3, "sleep second between retries");

DEFINE_string(hadoop_namenode_ip, "", "hadoop host");
DEFINE_int32(hadoop_namenode_port, 8022, "hadoop port");

bool HDFSExists(const char* hdfs_path) {
  HDFSHandle hadoop_handle(FLAGS_hadoop_namenode_ip.c_str(), FLAGS_hadoop_namenode_port);
  CHECK(hadoop_handle.Connect());
  int retry = 0;
  int rt = 0;
  do {
    errno = 0;
    // the old api returns 0 if path exists
    // < 0 if not exists or encounter error, can't distinguish the two
    // the new api returns 1 if path not exists, <0 when error
    hdfsFS hadoop_fs = hadoop_handle.get_handle();
    CHECK_NOTNULL(hadoop_fs);
    rt = hdfsExists(hadoop_fs, hdfs_path);
    if (rt < 0) {
      HADOOP_RETRY;
    } else if (rt == 0) {
      return true;
    } else if (rt == 1) {
      return false;
    }
  } while (retry++ < FLAGS_hdfs_retry_time);
  return false;
}
 
bool HDFSRmr(const char* hdfs_path) {
  HDFSHandle hadoop_handle(FLAGS_hadoop_namenode_ip.c_str(), FLAGS_hadoop_namenode_port);
  CHECK(hadoop_handle.Connect());
  int retry = 0;
  int rt = 0;
  do {
    errno = 0;
    // the api returns 0 if path exists
    // < 0 if not exists or encounter error, can't distinguish the two
    hdfsFS hadoop_fs = hadoop_handle.get_handle();
    CHECK_NOTNULL(hadoop_fs);
    rt = hdfsDelete(hadoop_fs, hdfs_path);
    if (rt == -1) {
      HADOOP_RETRY;
    } else {
      return true;
    }
  } while (retry++ < FLAGS_hdfs_retry_time);
  LOG(ERROR) << internal::parse_hdfs_error(errno);
  return false;
}

bool HDFSMkdir(const char* hdfs_path) {
  HDFSHandle hadoop_handle(FLAGS_hadoop_namenode_ip.c_str(), FLAGS_hadoop_namenode_port);
  CHECK(hadoop_handle.Connect());
  int retry = 0;
  int rt = 0;
  do {
    errno = 0;
    // the api returns 0 if path exists
    // < 0 if not exists or encounter error, can't distinguish the two
    hdfsFS hadoop_fs = hadoop_handle.get_handle();
    CHECK_NOTNULL(hadoop_fs);
    rt = hdfsCreateDirectory(hadoop_fs, hdfs_path);
    if (rt == -1) {
      HADOOP_RETRY;
    } else {
      return true;
    }
  } while (retry++ < FLAGS_hdfs_retry_time);
  LOG(ERROR) << internal::parse_hdfs_error(errno);
  return false;
}

int HDFSForceGet(const char* src_hdfs_path, const char* dest_local_path) {
  if (base::file_util::PathExists(base::FilePath(dest_local_path))) {
    if (!base::file_util::Delete(base::FilePath(dest_local_path), true)) {
      LOG(ERROR) << "can't delete dest path" << dest_local_path;
      return kCannotDel;
    }
  }
  return HDFSGet(src_hdfs_path, dest_local_path);
}

int HDFSGet(const char* src_hdfs_path, const char* dest_local_path) {
  // test if source path exists
  if (!HDFSExists(src_hdfs_path)) {
    LOG(ERROR) << "source path not exists: " << src_hdfs_path;
    return kSrcNotExists;
  }
  // test if dest path exists
  if (base::file_util::PathExists(base::FilePath(dest_local_path))) {
    // dest exists, can't overwrite it (use Force* interfaces instead)
    LOG(ERROR) << "dest path exists: " << dest_local_path;
    return kDstExists;
  }

  HDFSHandle hadoop_handle(FLAGS_hadoop_namenode_ip.c_str(), FLAGS_hadoop_namenode_port);
  CHECK(hadoop_handle.Connect());
  // construct a local file system handle
  HDFSHandle local_handle(NULL, 0);
  CHECK(local_handle.Connect());
  int retry = 0;
  int rt = 0;
  do {
    errno = 0;

    hdfsFS hadoop_fs = hadoop_handle.get_handle();
    hdfsFS local_fs = local_handle.get_handle();
    CHECK_NOTNULL(hadoop_fs);
    CHECK_NOTNULL(local_fs);

    rt = hdfsCopy(hadoop_fs, src_hdfs_path, local_fs, dest_local_path);
    if (rt == -1) {
      HADOOP_RETRY;
    } else {
      return 0;
    }
  } while (retry++ < FLAGS_hdfs_retry_time);
  LOG(ERROR) << internal::parse_hdfs_error(errno);
  return kActionFailed;  // if succ, return during the do-while loop
}

int HDFSForcePut(const char* src_local_path, const char* dest_hdfs_path) {
  if (HDFSExists(dest_hdfs_path)) {
    if (!HDFSRmr(dest_hdfs_path)) {
      LOG(ERROR) << "can't delete dest path: " << dest_hdfs_path;
      return kCannotDel;
    }
  }
  return HDFSPut(src_local_path, dest_hdfs_path);
}

int HDFSPut(const char* src_local_path, const char* dest_hdfs_path) {
  // test if source path exists
  if (!base::file_util::PathExists(base::FilePath(src_local_path))) {
    LOG(ERROR) << "source path not exists: " << src_local_path;
    return kSrcNotExists;
  }
  // test if dest path exists
  if (HDFSExists(dest_hdfs_path)) {
    LOG(ERROR) << "dest path exists: " << dest_hdfs_path;
    return kDstExists;
  }

  int retry = 0;
  int rt = 0;
  HDFSHandle hadoop_handle(FLAGS_hadoop_namenode_ip.c_str(), FLAGS_hadoop_namenode_port);
  CHECK(hadoop_handle.Connect());
  // construct a local file system handle
  HDFSHandle local_handle(NULL, 0);
  CHECK(local_handle.Connect());
  do {
    errno = 0;
    hdfsFS hadoop_fs = hadoop_handle.get_handle();
    hdfsFS local_fs = local_handle.get_handle();
    CHECK_NOTNULL(hadoop_fs);
    CHECK_NOTNULL(local_fs);

    rt = hdfsCopy(local_fs, src_local_path, hadoop_fs, dest_hdfs_path);
    if (rt == -1) {
      HADOOP_RETRY;
    } else {
      return 0;
    }
  } while (retry++ < FLAGS_hdfs_retry_time);
  LOG(ERROR) << internal::parse_hdfs_error(errno);
  return kActionFailed;
}

bool HDFSChown(const char* path, const char *owner, const char *group) {
  HDFSHandle hadoop_handle(FLAGS_hadoop_namenode_ip.c_str(), FLAGS_hadoop_namenode_port);
  CHECK(hadoop_handle.Connect());
  int retry = 0;
  int rt = 0;
  do {
    errno = 0;
    // the api returns 0 if path exists
    // < 0 if not exists or encounter error, can't distinguish the two
    hdfsFS hadoop_fs = hadoop_handle.get_handle();
    CHECK_NOTNULL(hadoop_fs);
    rt = hdfsChown(hadoop_fs, path, owner, group);
    if (rt == -1) {
      HADOOP_RETRY;
    } else {
      return true;
    }
  } while (retry++ < FLAGS_hdfs_retry_time);
  LOG(ERROR) << internal::parse_hdfs_error(errno);
  return false;
}

bool HDFSChmod(const char* path, int16_t mode) {
  HDFSHandle hadoop_handle(FLAGS_hadoop_namenode_ip.c_str(), FLAGS_hadoop_namenode_port);
  CHECK(hadoop_handle.Connect());
  int retry = 0;
  int rt = 0;
  do {
    errno = 0;
    // the api returns 0 if path exists
    // < 0 if not exists or encounter error, can't distinguish the two
    hdfsFS hadoop_fs = hadoop_handle.get_handle();
    CHECK_NOTNULL(hadoop_fs);
    rt = hdfsChmod(hadoop_fs, path, mode);
    if (rt == -1) {
      HADOOP_RETRY;
    } else {
      return true;
    }
  } while (retry++ < FLAGS_hdfs_retry_time);
  LOG(ERROR) << internal::parse_hdfs_error(errno);
  return false;
}

bool HDFSSetReplication(const char* path, int16_t replication) {
  HDFSHandle hadoop_handle(FLAGS_hadoop_namenode_ip.c_str(), FLAGS_hadoop_namenode_port);
  CHECK(hadoop_handle.Connect());
  int retry = 0;
  int rt = 0;
  do {
    errno = 0;
    // the api returns 0 if path exists
    // < 0 if not exists or encounter error, can't distinguish the two
    hdfsFS hadoop_fs = hadoop_handle.get_handle();
    CHECK_NOTNULL(hadoop_fs);
    rt = hdfsSetReplication(hadoop_fs, path, replication);
    if (rt == -1) {
      HADOOP_RETRY;
    } else {
      return true;
    }
  } while (retry++ < FLAGS_hdfs_retry_time);
  LOG(ERROR) << internal::parse_hdfs_error(errno);
  return false;
}

int HDFSIsDirectory(const char* path, const char* hdfs_ip, int hdfs_port) {
  HDFSHandle hadoop_handle(hdfs_ip, hdfs_port);
  if (!hadoop_handle.Connect()) {
    LOG(ERROR) << "connect to hadoop fail: " << hdfs_ip << ":" << hdfs_port;
    return -1;
  }
  int retry = 0;
  do {
    errno = 0;
    // the api returns 0 if path exists
    // < 0 if not exists or encounter error, can't distinguish the two
    hdfsFS hadoop_fs = hadoop_handle.get_handle();
    CHECK_NOTNULL(hadoop_fs);
    hdfsFileInfo* info = hdfsGetPathInfo(hadoop_fs, path);
    if (info == NULL) {
      if (retry < FLAGS_hdfs_retry_time) {
        base::SleepForSeconds(FLAGS_hdfs_retry_sleep_second);
        if (!hadoop_handle.Connect()) {
          LOG(ERROR) << "connect to hadoop fail: " << hdfs_ip << ":" << hdfs_port;
          return -1;
        }
        continue;
      } else {
        break;
      }
    } else {
      int type = 0;
      if (info->mKind == 'F') {
        type = 0;
      } else {
        type = 1;
      }
      hdfsFreeFileInfo(info, 1);
      return type;
    }
  } while (retry++ < FLAGS_hdfs_retry_time);
  LOG(ERROR) << internal::parse_hdfs_error(errno);
  return -1;
}

bool HDFSGetPathInfo(const char* path, HDFSPathInfo*  const info) {
  HDFSHandle hadoop_handle(FLAGS_hadoop_namenode_ip.c_str(), FLAGS_hadoop_namenode_port);
  CHECK(hadoop_handle.Connect());
  int retry = 0;
  do {
    errno = 0;
    // the api returns 0 if path exists
    // < 0 if not exists or encounter error, can't distinguish the two
    hdfsFS hadoop_fs = hadoop_handle.get_handle();
    CHECK_NOTNULL(hadoop_fs);
    hdfsFileInfo* p = hdfsGetPathInfo(hadoop_fs, path);
    if (p == NULL) {
      HADOOP_RETRY;
    } else {
      if (p->mKind == 'F') {
        info->type = kFile;
      } else {
        info->type = kDirectory;
      }
      info->name = p->mName;
      info->size_in_bytes = p->mSize;
      info->replications = p->mReplication;
      hdfsFreeFileInfo(p, 1);
      return true;
    }
  } while (retry++ < FLAGS_hdfs_retry_time);
  LOG(ERROR) << internal::parse_hdfs_error(errno);
  return false;
}

bool HDFSListDirectory(const char* path, std::vector<HDFSPathInfo>* const infos,
                       const char* hdfs_ip, int hdfs_port) {
  HDFSHandle hadoop_handle(hdfs_ip, hdfs_port);
  if (!hadoop_handle.Connect()) {
    LOG(ERROR) << "connect to hadoop fail: " << hdfs_ip << ":" << hdfs_port;
    return false;
  }
  int retry = 0;
  do {
    errno = 0;
    // the api returns 0 if path exists
    // < 0 if not exists or encounter error, can't distinguish the two
    hdfsFS hadoop_fs = hadoop_handle.get_handle();
    CHECK_NOTNULL(hadoop_fs);
    int num_entry;
    hdfsFileInfo* entries = hdfsListDirectory(hadoop_fs, path, &num_entry);
    if (entries == NULL) {
      if (retry < FLAGS_hdfs_retry_time) {
        base::SleepForSeconds(FLAGS_hdfs_retry_sleep_second);
        if (!hadoop_handle.Connect()) {
          LOG(ERROR) << "connect to hadoop fail: " << hdfs_ip << ":" << hdfs_port;
          return false;
        }
        continue;
      } else {
        break;
      }
    } else {
      infos->resize(num_entry);
      for (int i = 0; i < num_entry; ++i) {
        HDFSPathInfo& info = (*infos)[i];
        hdfsFileInfo* p = entries + i;
        if (p->mKind == 'F') {
          info.type = kFile;
        } else {
          info.type = kDirectory;
        }
        info.name = p->mName;
        info.size_in_bytes = p->mSize;
        info.replications = p->mReplication;
      }
      hdfsFreeFileInfo(entries, num_entry);
      return true;
    }
  } while (retry++ < FLAGS_hdfs_retry_time);
  LOG(ERROR) << internal::parse_hdfs_error(errno);
  return false;
}

bool GetHdfsLastestPath(const std::string& hdfs_dir, std::string *lastest_path,
                       const char* hdfs_ip, int hdfs_port) {
  lastest_path->clear();
  std::vector<HDFSPathInfo> hdfs_paths;
  if (!HDFSListDirectory(hdfs_dir.c_str(), &hdfs_paths, hdfs_ip, hdfs_port)) {
    LOG(ERROR) << "hdfs list dir fail [" << hdfs_dir << "]";
    return false;
  }
  if (hdfs_paths.empty()) {
    LOG(ERROR) << "hdfs dir empty [" << hdfs_dir << "]";
    return false;
  }
  std::vector<std::string> paths;
  for (int i = 0; i < (int)hdfs_paths.size(); ++i) {
    paths.push_back(hdfs_paths[i].name);
  }
  std::sort(paths.begin(), paths.end(), std::greater<std::string>());
  for (int i = 0; i < (int)paths.size(); ++i) {
    std::string done_file = paths[i] + "/done";
    if (HDFSExists(done_file.c_str())) {
      *lastest_path = paths[i];
      break;
    }
  }
  if (lastest_path->empty()) {
    LOG(ERROR) << "lastest update path empty, " << hdfs_dir;
    return false;
  }
  LOG(INFO) << "get lastest path [" << *lastest_path << "]";
  return true;
}

bool ReadHdfsFile(const std::string &hdfs_path, std::vector<std::string>* lines) {
  lines->clear();
  HDFSFileStream hdfs_in(FLAGS_hadoop_namenode_ip.c_str(), FLAGS_hadoop_namenode_port);
  if (!hdfs_in.Open(hdfs_path.c_str(), O_RDONLY)) {
    LOG(ERROR) << "read hdfs file fail [" << hdfs_path << "]";
    return false;
  }
  std::string line;
  while (hdfs_in.ReadLine(&line)) {
    lines->push_back(line);
  }

  LOG(INFO) << "read [" << ", " << lines->size()  << "] line from " << hdfs_path;
  return true;
}
}  // namespace
