#include "reco/base/hdfs/hdfs_file_stream.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "reco/base/hdfs/hdfs.h"
#include "reco/base/hdfs/hdfs_handle.h"

namespace hdfs {

HDFSFileStream::HDFSFileStream(const char *host, int port) : host_(host), port_(port),
    file_(NULL), retry_(0), retry_interval_(0), eof_(true) {
      handle_ = CreateHdfsHandle();
      if (!handle_->Connect()) {
        LOG(ERROR) << "HDFS connect failed";
      }
    }

HDFSFileStream::~HDFSFileStream() {
  delete handle_;
}

HDFSHandle* HDFSFileStream::CreateHdfsHandle() {
  return new HDFSHandle(host_, port_);
}

bool HDFSFileStream::Open(const char* path, int open_flags) {
  DCHECK_NOTNULL(path);

  hdfsFS fs_handle = handle_->get_handle();
  if (NULL == fs_handle) {
    LOG(ERROR) << "HDFS not connect!";
    return false;
  }

  if (file_ != NULL) {
    LOG(ERROR) << "already opened a file, close it first";
    return false;
  }

  path_ = path;
  errno = 0;
  file_ = hdfsOpenFile(fs_handle, path, open_flags, 0, 0, 0);
  if (file_ == NULL) {
    LOG(ERROR) << internal::parse_hdfs_error(errno);
    return false;
  }

  // reset class status virable
  read_mode_ = kModeNull;
  readline_buf_.clear();
  eof_ = false;

  return true;
}

bool HDFSFileStream::Close() {
  hdfsFS fs_handle = handle_->get_handle();
  if (NULL == fs_handle) {
    LOG(ERROR) << "HDFS not connect!";
    return false;
  }

  if (file_ != NULL) {
    errno = 0;
    int ret = hdfsCloseFile(fs_handle, file_);
    if (ret == 0) {
      file_ = NULL;
      return true;
    } else {
      file_ = NULL;
      LOG(ERROR) << "close file failed: " << path_
                 << "reason: " << internal::parse_hdfs_error(errno);
      return false;
    }
  }
  eof_ = true;
  return true;
}

int32 HDFSFileStream::InternalRead(char* buf, int buf_len) {
  int try_time = 0;
  int to_read = buf_len;
  int bytes_total = 0;
  while (!eof_ && bytes_total < buf_len) {
    errno = 0;
    int bytes_read = hdfsRead(handle_->get_handle(), file_, buf, to_read);
    if (bytes_read == -1) {
      // error encountered, retry
      LOG(ERROR) << "read " << path_ << " failed, already retry "
                 << try_time << " times";
      if (try_time < retry_) {
        // NOTE: once failed, we close the hdfs handle and reconnect to the host,
        // instead of simply retrying reading operation.
        // The reconnection will happen in |retry_interval_| Seconds.
        handle_->Disconnect();
        while (!handle_->Connect() && try_time++ < retry_) {
          base::SleepForSeconds(retry_interval_);
        }
        continue;
      } else {
        // max retry reached, fail it even have some succ read-in
        LOG(ERROR) << internal::parse_hdfs_error(errno);
        return -1;
      }
    } else if (bytes_read == 0) {  // reach EOF
      eof_ = true;
      return bytes_total;
    }
    bytes_total += bytes_read;
    buf += bytes_read;
    to_read -= bytes_read;
  }
  return bytes_total;
}

int32 HDFSFileStream::Read(char* buf, int buf_len) {
  DCHECK_NOTNULL(buf);

  CHECK_NOTNULL(file_);
  hdfsFS fs_handle = handle_->get_handle();
  if (NULL == fs_handle) {
    LOG(ERROR) << "HDFS not connect!";
    return 0;
  }
  CHECK_NE(read_mode_, kModeReadLine) << "Can only chose ONE api: Read or ReadLine";
  read_mode_ = kModeRead;
  return InternalRead(buf, buf_len);
}

bool HDFSFileStream::ReadLine(std::string *line) {
  DCHECK_NOTNULL(line);
  hdfsFS fs_handle = handle_->get_handle();
  if (NULL == fs_handle) {
    LOG(ERROR) << "HDFS not connect!";
    return false;
  }
  CHECK_NOTNULL(file_);
  CHECK_NE(read_mode_, kModeRead) << "Can only chose ONE api: Read or ReadLine";
  read_mode_ = kModeReadLine;
  int buf_size = 256;
  std::string buf;
  buf.resize(static_cast<int>(buf_size)+1);
  line->clear();
  bool got_line = false;
  do {
    if (readline_buf_.size() == 0) {
      int bytes_read = InternalRead(&buf[0], buf_size);
      if (bytes_read <= 0) break;
      readline_buf_.append(buf, 0, bytes_read);
    }
    int i = 0;
    for (; i < static_cast<int>(readline_buf_.size()) && !got_line; ++i) {
      if (readline_buf_[i] == '\n') {
        got_line = true;
      } else {
        line->push_back(readline_buf_[i]);
      }
    }
    readline_buf_.erase(0, i);
    if (got_line) break;
  } while (true);
  // got_line is true means definitely encounter a \n
  // but not vice verse, for example when reaching EOF.
  // line->size() > 0 will cover this situation
  return got_line || line->size() > 0;
}

int32_t HDFSFileStream::Write(const char* buf, int buf_len) {
  CHECK_NOTNULL(file_);
  hdfsFS fs_handle = handle_->get_handle();
  if (NULL == fs_handle) {
    LOG(ERROR) << "HDFS not connect!";
    return 0;
  }

  errno = 0;
  int try_time = 0;
  int to_write = buf_len;
  int bytes_total = 0;
  do {
    errno = 0;
    int bytes_write = hdfsWrite(fs_handle, file_, buf, buf_len);
    if (bytes_write == -1) {
      // error encountered, retry
      LOG(ERROR) << "write " << path_ << " failed, already retry "
                 << try_time << " times";
      if (try_time++ < retry_) {
        continue;
      } else {
        // max retry reached, fail it even have some succ write-out
        LOG(ERROR) << internal::parse_hdfs_error(errno);
        return -1;
      }
    }
    bytes_total += bytes_write;
    buf += bytes_write;
    to_write -= bytes_write;
  } while (bytes_total < buf_len);
  return bytes_total;
}

bool HDFSFileStream::Flush() {
  CHECK_NOTNULL(file_);
  hdfsFS fs_handle = handle_->get_handle();
  if (NULL == fs_handle) {
    LOG(ERROR) << "HDFS not connect!";
    return false;
  }

  errno = 0;
  if (0 == hdfsFlush(fs_handle, file_)) {
    return true;
  } else {
    LOG(ERROR) << internal::parse_hdfs_error(errno);
    return false;
  }
}


}  // namespace

