#pragma once
#include "reco/base/hdfs/hdfs.h"

#if __cplusplus < 201103L
#include <cstdatomic>
#else
#include <atomic>
#endif // C++11

#include <string>
#include "base/common/base.h"
#include "base/common/gflags.h"

namespace hdfs {

namespace internal {
// convert errno set by hdfs lib into a string
std::string parse_hdfs_error(int err_code);
}  // namespace

// class to handle Hadoop connection
// and provide handler to hadoop file system (hdfs)
// NOTICE:
// the handler will be renewed in APIs,
// so it can not be shared between threads
class HDFSHandle {
 public:
  HDFSHandle();
  HDFSHandle(const char* host, int port);
  virtual ~HDFSHandle();

  // connect to a hadoop file system.
  // before your operations on a hdfs, your should connect to it first.
  // after a connection to certain hdfs is built, you can change it to other hdfs
  // by calling this function again, and the connection to the original one is closed.
  // NOTICE: you should have a hadoop client installed,
  // and add the path of hadoop bin file to your system PATH
  // the method will call cmd "hadoop classpath" to get CLASSPATH and set it as environment viriable
  virtual bool Connect() WARN_UNUSED_RESULT;

  bool Disconnect();

  hdfsFS get_handle() const {
    return hdfs_handle_;
  };

 protected:
  hdfsFS hdfs_handle_;
  std::string host_;
  int port_;
 private:
  DISALLOW_COPY_AND_ASSIGN(HDFSHandle);
};

}  // namespace
