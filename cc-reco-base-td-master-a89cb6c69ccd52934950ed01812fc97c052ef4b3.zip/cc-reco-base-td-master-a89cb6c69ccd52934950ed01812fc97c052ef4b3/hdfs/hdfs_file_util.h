#pragma once
#include "reco/base/hdfs/hdfs_handle.h"
#include <string>
#include <vector>
#include "base/common/gflags.h"

namespace hdfs {

// error code
enum HDFSFileUtilError {
  kActionFailed = -1,
  kSrcNotExists = -2,
  kDstExists = -3,
  kCannotDel = -4
};

enum HDFSPathType {
  kFile = 0,
  kDirectory = 1
};

struct HDFSPathInfo {
  HDFSPathType type;
  std::string name;  // full path name, including hdfs://hostname/....
  uint32 size_in_bytes;
  uint16 replications;
};

DECLARE_int32(hdfs_retry_time);
DECLARE_int32(hdfs_retry_sleep_second);

DECLARE_string(hadoop_namenode_ip);
DECLARE_int32(hadoop_namenode_port);

// test if a hdfs path exists, with retrys (default 3),
// return true if exists
bool HDFSExists(const char* hdfs_path) WARN_UNUSED_RESULT;

// implement of hadoop fs -rmr, with retrys (default 3).
// return true if succ. path could be dir of file (hadoop fs -rmr)
// NOTICE: it will not check whether the path exists
bool HDFSRmr(const char* hdfs_path) WARN_UNUSED_RESULT;

// implement of hadoop fs -mkdir, with retrys (default 3).
// return true if succ.
// NOTICE: it will not check whether the path exists
bool HDFSMkdir(const char* hdfs_path) WARN_UNUSED_RESULT;

// implement of "hadoop fs get", with retrys (default 3)
// return 0 if success, otherwise return
// -1, if hadoop copy failed
// -2, if source not exists
// -3, if dest exists (this function do not overwrite it, use Force* instead)
int HDFSGet(const char* src_hdfs_path, const char* dest_local_path) WARN_UNUSED_RESULT;

// similar to HDFSGet, but delete the dest first if it already exists
// so it won't return -3, instead return -4 if delete failed
// if dest is a dir, the whole dir is removed, so be careful!
int HDFSForceGet(const char* src_hdfs_path, const char* dest_local_path) WARN_UNUSED_RESULT;

// implement of "hadoop fs put", with retrys (default 3)
// return 0 if success, otherwise return
// -1, if hadoop copy failed
// -2, if source not exists
// -3, if dest exists (this function do not overwrite it, use Force* instead)
int HDFSPut(const char* src_local_path, const char* dest_hdfs_path) WARN_UNUSED_RESULT;

// similar to HDFSPut, but delete the dest if it already exists
// so it won't return -3, instead return -4 if delete failed
int HDFSForcePut(const char* src_local_path, const char* dest_hdfs_path) WARN_UNUSED_RESULT;

// NOTICE: this can only be done if you are hdfs adminstrator
// implement of "hadoop fs chown", with retrys (default 3)
// owner this is a string in Hadoop land. Set to null or "" if only setting group
// group  this is a string in Hadoop land. Set to null or "" if only setting user
bool HDFSChown(const char* path, const char *owner, const char *group) WARN_UNUSED_RESULT;

// implement of "hadoop fs chmod", with retrys (default 3)
// mode the bitmask to set it to
// 建议用八进制表示 mode. for example, 0606 means -rw----rw-
// 测试结果显示，有时设置文件的 x 属性会失败
bool HDFSChmod(const char* path, int16_t mode) WARN_UNUSED_RESULT;

// set replication of a path, with retrys (default 3)
bool HDFSSetReplication(const char* path, int16_t replication) WARN_UNUSED_RESULT;
// given a hdfs path, judge wheather it is a directory or a file
// return 0 if it is a file, 1 if it is a directory
// return -1 if error happens
int HDFSIsDirectory(const char* path, const char* hdfs_ip, int hdfs_port) WARN_UNUSED_RESULT;

// bool HDFSGetPathInfo(const char* path, HDFSPathInfo* const info);

bool HDFSListDirectory(const char* path, std::vector<HDFSPathInfo>* const infos,
                       const char* hdfs_ip, int hdfs_port);

// 指定文件夹，获取里面最新的文件
bool GetHdfsLastestPath(const std::string& hdfs_dir, std::string *lastest_path,
                       const char* hdfs_ip, int hdfs_port);

bool ReadHdfsFile(const std::string& hdfs_path, std::vector<std::string>* lines);
}  // namespace
