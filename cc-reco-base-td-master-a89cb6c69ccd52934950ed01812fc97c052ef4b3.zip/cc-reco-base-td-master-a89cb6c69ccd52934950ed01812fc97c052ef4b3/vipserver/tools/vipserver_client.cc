#include "reco/base/vipserver/api/vipserver_manager.h"

#include <string>

#include "vipserver/option.h"
#include "vipserver/vipclient.h"
#include "vipserver/vipclient_helper.hpp"

#include "base/common/logging.h"

using reco::vipserver::VSClientMgrIns;

DEFINE_string(query_domain, "test.net", "");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "vipserver client");

  bool ret = false;

  ret = VSClientMgrIns::instance().Init();

  // query
  std::string ip_info;
  if (VSClientMgrIns::instance().GetAllIpDebugStr(FLAGS_query_domain,
                                                  5000,
                                                  &ip_info)) {
    LOG(ERROR) << "query vipserver all ip succ, domain:" << FLAGS_query_domain
               << ", ip info:" << ip_info;
  } else {
    LOG(ERROR) << "query vipserver fail:" << FLAGS_query_domain;
  }

  if (VSClientMgrIns::instance().GetAllValidIpDebugStr(FLAGS_query_domain,
                                                       5000,
                                                       &ip_info)) {
    LOG(ERROR) << "query vipserver all valid ip succ, domain:" << FLAGS_query_domain
               << ", ip info:" << ip_info;
  } else {
    LOG(ERROR) << "query vipserver fail:" << FLAGS_query_domain;
  }

  ret = VSClientMgrIns::instance().Destroy();

  return 0;
}
