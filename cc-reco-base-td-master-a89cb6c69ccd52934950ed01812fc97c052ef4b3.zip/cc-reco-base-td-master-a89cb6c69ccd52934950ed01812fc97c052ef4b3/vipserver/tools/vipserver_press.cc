#include "reco/base/vipserver/api/vipserver_manager.h"

#include <string>

#include "vipserver/option.h"
#include "vipserver/vipclient.h"
#include "vipserver/vipclient_helper.hpp"

#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "serving_base/utility/timer.h"

using reco::vipserver::VSClientMgrIns;

DEFINE_string(query_domain, "test.net", "");
DEFINE_int32(req_num, 10, "");
DEFINE_int32(sleep_ms, 0, "");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "vipserver client");

  bool ret = false;

  ret = VSClientMgrIns::instance().Init();

  // query
  std::string ip_port_list;
  std::string last_str;
  serving_base::Timer timer;
  timer.Start();
  for (auto i = 0; i < FLAGS_req_num; ++i) {
    VSClientMgrIns::instance().GetAllValidIpPortStr(FLAGS_query_domain, 10000, &ip_port_list);
    if (last_str != ip_port_list) {
      last_str = ip_port_list;
      LOG(ERROR) << "new ip port:" << ip_port_list;
    }

    if (FLAGS_sleep_ms > 0) {
      base::SleepForMilliseconds(FLAGS_sleep_ms);
    }
  }

  LOG(ERROR) << "req domain:" << FLAGS_query_domain
             << ", repeat num:" << FLAGS_req_num
             << ", cost_ms:" << timer.Stop() / 1000;

  ret = VSClientMgrIns::instance().Destroy();

  return 0;
}
