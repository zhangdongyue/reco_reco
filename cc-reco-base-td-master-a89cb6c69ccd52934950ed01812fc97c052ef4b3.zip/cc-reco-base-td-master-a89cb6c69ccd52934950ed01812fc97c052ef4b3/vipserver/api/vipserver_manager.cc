#include "reco/base/vipserver/api/vipserver_manager.h"

#include "vipserver/option.h"
#include "vipserver/vipclient.h"
#include "vipserver/vipclient_helper.hpp"

#include "base/common/logging.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"

namespace reco {
namespace vipserver {
DEFINE_string(vsclient_vip_domain, "jmenv.tbsite.net", "vipserver 的域名，非特殊情况为 jmenv.tbsite.net");
DEFINE_string(vsclient_appname, "AppName", "设置用户的应用名(可选)");
DEFINE_string(vsclient_log_path, "./", "");
DEFINE_string(vsclient_cache_path, "./", "");

VipClientManager::VipClientManager() : init_(false) {
}

bool VipClientManager::Init(const std::string& vip_domain,
                            const std::string& vip_appname,
                            const std::string& vip_cache_path,
                            const std::string& vip_log_path) {
  thread::AutoLock lock(&mutex_);
  if (init_) {
    LOG(ERROR) << "init repeated call.";
    return false;
  }
  init_ = true;

  middleware::vipclient::VipClientApi::CreateApi();
  
  // options
  middleware::vipclient::Option option;
  option.set_app_name(vip_appname.c_str());
  option.set_max_log_size(1024*1024*1024);
  option.set_log_path(vip_log_path.c_str());
  option.set_cache_path(vip_cache_path.c_str());
  option.set_failover_path(vip_cache_path.c_str());

  // init
  if (!middleware::vipclient::VipClientApi::Init(vip_domain.c_str(), option)) {
    LOG(ERROR) << "init failed top domain:" << vip_domain
               << ", errno:" << middleware::vipclient::VipClientApi::Errno()
               << ", errstr:" << middleware::vipclient::VipClientApi::Errstr();
    middleware::vipclient::VipClientApi::DestoryApi();
    LOG(FATAL) << "init vipserver env error.";
    return false;
  }

  LOG(INFO) << "init vipserver manager succ:" << vip_domain;
  return true;
}

bool VipClientManager::Destroy() {
  thread::AutoLock lock(&mutex_);
  if (init_) {
    init_ = false;
    middleware::vipclient::VipClientApi::UnInit();
    middleware::vipclient::VipClientApi::DestoryApi();
    LOG(INFO) << "stop vipserver manager succ.";
    return true;
  } else {
    LOG(ERROR) << "stop vipserver manager before init.";
  }

  return false;
}

bool VipClientManager::GetAllIp(const std::string& query_domain,
                                const int32 timeout_ms,
                                middleware::vipclient::IPHostArray *hosts) {
  CHECK(init_);
  if (middleware::vipclient::VipClientApi::QueryAllIp(query_domain.c_str(), hosts, timeout_ms)) {
    return true;
  } else {
    LOG(ERROR) << "get ip failed domain:" << query_domain
               << ", errno:" << middleware::vipclient::VipClientApi::Errno()
               << ", errstr:" << middleware::vipclient::VipClientApi::Errstr();
    return false;
  }

  return false;
}

bool VipClientManager::GetAllIpDebugStr(const std::string& query_domain,
                                        const int32 timeout_ms,
                                        std::string* ip_info) {
  middleware::vipclient::IPHostArray hosts;
  if (GetAllIp(query_domain, timeout_ms, &hosts)) {
    *ip_info = middleware::vipclient::helper::ToString(hosts);
    return true;
  }

  return false;
}

bool VipClientManager::GetAllValidIp(const std::string& query_domain,
                                     const int32 timeout_ms,
                                     middleware::vipclient::IPHostArray *hosts) {
  CHECK(init_);
  if (middleware::vipclient::VipClientApi::QueryAllValidIp(query_domain.c_str(), hosts, timeout_ms)) {
    return true;
  } else {
    LOG(ERROR) << "get ip failed domain:" << query_domain
               << ", errno:" << middleware::vipclient::VipClientApi::Errno()
               << ", errstr:" << middleware::vipclient::VipClientApi::Errstr();
    return false;
  }

  return false;
}

bool VipClientManager::GetAllValidIpPortStr(const std::string& query_domain,
                                            const int32 timeout_ms,
                                            std::string* ip_port_str) {
  middleware::vipclient::IPHostArray hosts;
  if (GetAllValidIp(query_domain, timeout_ms, &hosts)) {
    std::vector<std::string> host_str_list;
    for (auto i = 0u; i < hosts.size(); ++i) {
      const middleware::vipclient::IPHost& iphost = hosts.get(i);
      host_str_list.push_back(base::StringPrintf("%s:%d:%d", iphost.ip(), iphost.port(), iphost.weight()));
    }

    std::sort(host_str_list.begin(), host_str_list.end());

    *ip_port_str = base::JoinStrings(host_str_list, ",");

    return true;
  }

  return false;
}

bool VipClientManager::GetAllValidIpDebugStr(const std::string& query_domain,
                                             const int32 timeout_ms,
                                             std::string* ip_info) {
  middleware::vipclient::IPHostArray hosts;
  if (GetAllValidIp(query_domain, timeout_ms, &hosts)) {
    *ip_info = middleware::vipclient::helper::ToString(hosts);
    return true;
  }

  return false;
}
}
}
