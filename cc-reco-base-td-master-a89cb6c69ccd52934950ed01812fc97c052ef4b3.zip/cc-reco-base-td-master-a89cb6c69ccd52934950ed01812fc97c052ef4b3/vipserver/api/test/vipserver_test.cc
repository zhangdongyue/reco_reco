#include "reco/base/vipserver/api/vipserver_manager.h"

#include <string>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"

namespace reco {
namespace vipserver {
class VipServerTest : public testing::Test {
 protected:
  void SetUp() {
    VSClientMgrIns::instance().Init();
  }

  void TearDown() {
    VSClientMgrIns::instance().Destroy();
  }
};

TEST_F(VipServerTest, Init) {
  std::string ip_info;
  const std::string test_domain = "yidong.xss.codis-version.alibaba-inc.vipserver";
  ASSERT_TRUE(VSClientMgrIns::instance().GetAllIpDebugStr(test_domain,
                                                          5000,
                                                          &ip_info));
  LOG(INFO) << "vipserver is:" << test_domain
      << ", ip info:" << ip_info;
}
}
}
