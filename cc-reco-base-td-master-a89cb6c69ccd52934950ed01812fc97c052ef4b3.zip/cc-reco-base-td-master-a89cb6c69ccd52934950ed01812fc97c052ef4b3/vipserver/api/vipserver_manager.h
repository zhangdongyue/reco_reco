#pragma once

#include <string>

#include "vipserver/iphost.h"

#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/thread/thread.h"
#include "base/thread/sync.h"
#include "reco/base/common/singleton.h"

namespace reco {
namespace vipserver {
DECLARE_string(vsclient_vip_domain);
DECLARE_string(vsclient_appname);
DECLARE_string(vsclient_log_path);
DECLARE_string(vsclient_cache_path);

class VipClientManager {
 public:
  VipClientManager();

  ~VipClientManager() {
    Destroy();
  }

  bool Destroy();

  // 默认都不需要修改值，只需要在全局 flags 文件里面设置默认路径就可以了
  bool Init(const std::string& vip_domain = FLAGS_vsclient_vip_domain,
            const std::string& vip_appname = FLAGS_vsclient_appname,
            const std::string& vip_cache_path = FLAGS_vsclient_cache_path,
            const std::string& vip_log_path = FLAGS_vsclient_log_path);

  // 得到所有 IP
  bool GetAllIp(const std::string& query_domain,
                const int32 timeout_ms,
                middleware::vipclient::IPHostArray *hosts);

  // ip list debug 信息，用于调试和客户端工具
  bool GetAllIpDebugStr(const std::string& query_domain,
                        const int32 timeout_ms,
                        std::string* ip_list);

  // 返回所有有效的 ip 列表
  bool GetAllValidIp(const std::string& query_domain,
                     const int32 timeout_ms,
                     middleware::vipclient::IPHostArray *hosts);

  // 返回 ip port weight: 127.0.0.1:8080:1,127.0.0.1:8090:2
  bool GetAllValidIpPortStr(const std::string& query_domain,
                            const int32 timeout_ms,
                            std::string* ip_port_str);

  bool GetAllValidIpDebugStr(const std::string& query_domain,
                             const int32 timeout_ms,
                             std::string* ip_list);
 private:
  std::atomic_bool init_;
  mutable thread::Mutex mutex_;
};

// 具体操作使用: reco::vipserver::VSClientMgrIns::instance().xxx();
typedef reco::common::singleton_default<VipClientManager> VSClientMgrIns;
}
}
