#include <boost/shared_ptr.hpp>
#include <cstdatomic>
#include <unordered_map>
#include <vector>

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/file/file_util.h"
#include "base/common/logging.h"
#include "base/thread/thread_pool.h"
#include "base/strings/string_split.h"
#include "base/random/pseudo_random.h"

#include "reco/base/dict_manager/common_dict_loader.h"
#include "reco/base/dict_manager/internal/template_dict_loader.h"
#include "reco/base/dict_manager/dynamic_dict.h"
#include "reco/base/dict_manager/dict_manager.h"

namespace reco {
namespace dm {

class CommonLoaderTest: public ::testing::Test {
 protected:
  base::FilePath WriteLinesToTempFile(const std::vector<std::string>& lines) {
    base::FilePath path;
    CHECK(base::file_util::CreateTemporaryFileInDir("/tmp", &path));
    std::string str = base::JoinStrings(lines, "\n");
    CHECK(base::file_util::WriteFile(path, str.c_str(), str.size()));

    return path;
  }

  virtual void SetUp() {
    std::vector<std::string> lines;

    // create pure key cases
    lines.push_back("ab");
    lines.push_back("Ab");
    lines.push_back("1");
    lines.push_back("1.0");
    lines.push_back("9999999999999");
    key_file_ = WriteLinesToTempFile(lines);

    // create key value cases
    lines.clear();
    lines.push_back("ab\t1");
    lines.push_back("Ab\t2");
    lines.push_back("1\t3");
    lines.push_back("1.0\t4");
    lines.push_back("9999999999999\t5");
    key_value_file_ = WriteLinesToTempFile(lines);

    // create key container cases
    lines.clear();
    lines.push_back("ab\t1`1`5");
    lines.push_back("Ab\t2`3`4");
    lines.push_back("1\t3`5`6");
    lines.push_back("1.0\t4`7`8");
    lines.push_back("9999999999999\t5`9`1");
    key_container_file_ = WriteLinesToTempFile(lines);
  }

  virtual void TearDown() {
    CHECK(base::file_util::Delete(key_file_, false));
    CHECK(base::file_util::Delete(key_value_file_, false));
    CHECK(base::file_util::Delete(key_container_file_, false));
  }

  // 纯 key 文件
  base::FilePath key_file_;
  // key-value 文件， TAB 分割两列
  base::FilePath key_value_file_;
  // key-container 文件， TAB 分割两列, 第二列又用 ` 分割子序列
  base::FilePath key_container_file_;
};

TEST_F(CommonLoaderTest, ParseString) {
  using namespace internal;  // NOLINT
  {
    int v;
    ASSERT_FALSE(parse_string<int>("a", &v));
    ASSERT_TRUE(parse_string<int>("1", &v));
    ASSERT_EQ(v, 1);
    ASSERT_FALSE(parse_string<int>("1.0", &v));
    ASSERT_FALSE(parse_string<int>("999999999999999", &v));
  }
  {
    int64 v;
    ASSERT_FALSE(parse_string<int64>("a", &v));
    ASSERT_TRUE(parse_string<int64>("1", &v));
    ASSERT_EQ(v, 1);
    ASSERT_FALSE(parse_string<int64>("1.0", &v));
    ASSERT_TRUE(parse_string<int64>("999999999999999", &v));
    ASSERT_EQ(v, 999999999999999);
  }
  {
    uint32 v;
    ASSERT_FALSE(parse_string<uint32>("a", &v));
    ASSERT_TRUE(parse_string<uint32>("1", &v));
    ASSERT_EQ(v, 1u);
    ASSERT_FALSE(parse_string<uint32>("1.0", &v));
    ASSERT_FALSE(parse_string<uint32>("999999999999999", &v));
  }
  {
    uint64 v;
    ASSERT_FALSE(parse_string<uint64>("a", &v));
    ASSERT_TRUE(parse_string<uint64>("1", &v));
    ASSERT_EQ(v, 1u);
    ASSERT_FALSE(parse_string<uint64>("1.0", &v));
    ASSERT_TRUE(parse_string<uint64>("999999999999999", &v));
    ASSERT_EQ(v, 999999999999999ul);
  }
  {
    double v;
    ASSERT_FALSE(parse_string<double>("a", &v));
    ASSERT_TRUE(parse_string<double>("1", &v));
    ASSERT_EQ(v, 1);
    ASSERT_TRUE(parse_string<double>("1.0", &v));
    ASSERT_EQ(v, 1);
    ASSERT_TRUE(parse_string<double>("999999999999999", &v));
    ASSERT_EQ(v, 999999999999999);
  }
  {
    std::string v;
    ASSERT_TRUE(parse_string<std::string>("a", &v));
    ASSERT_EQ(v, "a");
    ASSERT_TRUE(parse_string<std::string>("1", &v));
    ASSERT_EQ(v, "1");
    ASSERT_TRUE(parse_string<std::string>("1.0", &v));
    ASSERT_EQ(v, "1.0");
    ASSERT_TRUE(parse_string<std::string>("999999999999999", &v));
    ASSERT_EQ(v, "999999999999999");
  }
}

TEST_F(CommonLoaderTest, StrStrLoader) {
  // unordered map
  {
    DynamicDict<DictManager::UnorderedMapStrStr> dict;
    bool suc;
    int64 cnt;

    UnorderedMapStrStrLoader(key_value_file_, &dict, &suc, &cnt);
    ASSERT_TRUE(suc);
    ASSERT_EQ(cnt, 5l);
    auto p = dict.GetDict();
    ASSERT_EQ(p->find("ab")->second, "1");
    ASSERT_EQ(p->find("Ab")->second, "2");
    ASSERT_EQ(p->find("1")->second, "3");
    ASSERT_EQ(p->find("1.0")->second, "4");
    ASSERT_EQ(p->find("9999999999999")->second, "5");

    UnorderedMapStrStrNormalizedLoader(key_value_file_, &dict, &suc, &cnt);
    ASSERT_TRUE(suc);
    ASSERT_EQ(cnt, 4l);
    p = dict.GetDict();
    ASSERT_EQ(p->find("ab")->second, "2");
    ASSERT_EQ(p->find("1")->second, "3");
    ASSERT_EQ(p->find("1.0")->second, "4");
    ASSERT_EQ(p->find("9999999999999")->second, "5");
  }

  // map
  {
    DynamicDict<DictManager::MapStrStr> dict;
    bool suc;
    int64 cnt;

    MapStrStrLoader(key_value_file_, &dict, &suc, &cnt);
    ASSERT_TRUE(suc);
    ASSERT_EQ(cnt, 5l);
    auto p = dict.GetDict();
    ASSERT_EQ(p->find("ab")->second, "1");
    ASSERT_EQ(p->find("Ab")->second, "2");
    ASSERT_EQ(p->find("1")->second, "3");
    ASSERT_EQ(p->find("1.0")->second, "4");
    ASSERT_EQ(p->find("9999999999999")->second, "5");

    MapStrStrNormalizedLoader(key_value_file_, &dict, &suc, &cnt);
    ASSERT_TRUE(suc);
    ASSERT_EQ(cnt, 4l);
    p = dict.GetDict();
    ASSERT_EQ(p->find("ab")->second, "2");
    ASSERT_EQ(p->find("1")->second, "3");
    ASSERT_EQ(p->find("1.0")->second, "4");
    ASSERT_EQ(p->find("9999999999999")->second, "5");
  }
}

TEST_F(CommonLoaderTest, StrDoubleLoader) {
  DynamicDict<DictManager::UnorderedMapStrDouble> dict;
  bool suc;
  int64 cnt;

  UnorderedMapStrDoubleLoader(key_value_file_, &dict, &suc, &cnt);
  ASSERT_TRUE(suc);
  ASSERT_EQ(cnt, 5l);
  auto p = dict.GetDict();
  ASSERT_EQ(p->find("ab")->second, 1);
  ASSERT_EQ(p->find("Ab")->second, 2);
  ASSERT_EQ(p->find("1")->second, 3);
  ASSERT_EQ(p->find("1.0")->second, 4);
  ASSERT_EQ(p->find("9999999999999")->second, 5);

  UnorderedMapStrDoubleNormalizedLoader(key_value_file_, &dict, &suc, &cnt);
  ASSERT_TRUE(suc);
  ASSERT_EQ(cnt, 4l);
  p = dict.GetDict();
  ASSERT_EQ(p->find("ab")->second, 2);
  ASSERT_EQ(p->find("1")->second, 3);
  ASSERT_EQ(p->find("1.0")->second, 4);
  ASSERT_EQ(p->find("9999999999999")->second, 5);
}

TEST_F(CommonLoaderTest, StrIntLoader) {
  DynamicDict<DictManager::MapStrInt> dict;
  bool suc;
  int64 cnt;

  MapStrIntLoader(key_value_file_, &dict, &suc, &cnt);
  ASSERT_TRUE(suc);
  ASSERT_EQ(cnt, 5l);
  auto p = dict.GetDict();
  ASSERT_EQ(p->find("ab")->second, 1);
  ASSERT_EQ(p->find("Ab")->second, 2);
  ASSERT_EQ(p->find("1")->second, 3);
  ASSERT_EQ(p->find("1.0")->second, 4);
  ASSERT_EQ(p->find("9999999999999")->second, 5);

  MapStrIntNormalizedLoader(key_value_file_, &dict, &suc, &cnt);
  ASSERT_TRUE(suc);
  ASSERT_EQ(cnt, 4l);
  p = dict.GetDict();
  ASSERT_EQ(p->find("ab")->second, 2);
  ASSERT_EQ(p->find("1")->second, 3);
  ASSERT_EQ(p->find("1.0")->second, 4);
  ASSERT_EQ(p->find("9999999999999")->second, 5);
}

TEST_F(CommonLoaderTest, StrLoader) {
  {
    DynamicDict<DictManager::UnorderedSetStr> dict;
    bool suc;
    int64 cnt;

    UnorderedSetStrLoader(key_file_, &dict, &suc, &cnt);
    ASSERT_TRUE(suc);
    ASSERT_EQ(cnt, 5l);
    auto p = dict.GetDict();
    ASSERT_EQ(p->count("ab"), 1u);
    ASSERT_EQ(p->count("Ab"), 1u);
    ASSERT_EQ(p->count("1"), 1u);
    ASSERT_EQ(p->count("1.0"), 1u);
    ASSERT_EQ(p->count("9999999999999"), 1u);

    UnorderedSetStrNormalizedLoader(key_file_, &dict, &suc, &cnt);
    ASSERT_TRUE(suc);
    ASSERT_EQ(cnt, 4l);
    p = dict.GetDict();
    ASSERT_EQ(p->count("ab"), 1u);
    ASSERT_EQ(p->count("Ab"), 0u);
    ASSERT_EQ(p->count("1"), 1u);
    ASSERT_EQ(p->count("1.0"), 1u);
    ASSERT_EQ(p->count("9999999999999"), 1u);
  }
  {
    DynamicDict<DictManager::SetStr> dict;
    bool suc;
    int64 cnt;

    SetStrLoader(key_file_, &dict, &suc, &cnt);
    ASSERT_TRUE(suc);
    ASSERT_EQ(cnt, 5l);
    auto p = dict.GetDict();
    ASSERT_EQ(p->count("ab"), 1u);
    ASSERT_EQ(p->count("Ab"), 1u);
    ASSERT_EQ(p->count("1"), 1u);
    ASSERT_EQ(p->count("1.0"), 1u);
    ASSERT_EQ(p->count("9999999999999"), 1u);

    SetStrNormalizedLoader(key_file_, &dict, &suc, &cnt);
    ASSERT_TRUE(suc);
    ASSERT_EQ(cnt, 4l);
    p = dict.GetDict();
    ASSERT_EQ(p->count("ab"), 1u);
    ASSERT_EQ(p->count("Ab"), 0u);
    ASSERT_EQ(p->count("1"), 1u);
    ASSERT_EQ(p->count("1.0"), 1u);
    ASSERT_EQ(p->count("9999999999999"), 1u);
  }
}

TEST_F(CommonLoaderTest, MapStrVectorStrLoader) {
  DynamicDict<DictManager::UnorderedMapStrVectorStr> dict;
  bool suc;
  int64 cnt;

  UnorderedMapStrVectorStrLoader(key_container_file_, &dict, &suc, &cnt);
  ASSERT_TRUE(suc);
  ASSERT_EQ(cnt, 5l);
  auto p = dict.GetDict();
  ASSERT_EQ(base::JoinStrings(p->find("ab")->second, "`"), "1`1`5");
  ASSERT_EQ(base::JoinStrings(p->find("Ab")->second, "`"), "2`3`4");
  ASSERT_EQ(base::JoinStrings(p->find("1")->second, "`"), "3`5`6");
  ASSERT_EQ(base::JoinStrings(p->find("1.0")->second, "`"), "4`7`8");
  ASSERT_EQ(base::JoinStrings(p->find("9999999999999")->second, "`"), "5`9`1");

  UnorderedMapStrVectorStrNormalizedLoader(key_container_file_, &dict, &suc, &cnt);
  ASSERT_TRUE(suc);
  ASSERT_EQ(cnt, 4l);
  p = dict.GetDict();
  ASSERT_EQ(base::JoinStrings(p->find("ab")->second, "`"), "1`1`5`2`3`4");
  ASSERT_EQ(base::JoinStrings(p->find("1")->second, "`"), "3`5`6");
  ASSERT_EQ(base::JoinStrings(p->find("1.0")->second, "`"), "4`7`8");
  ASSERT_EQ(base::JoinStrings(p->find("9999999999999")->second, "`"), "5`9`1");
}

TEST_F(CommonLoaderTest, MapStrSetStrLoader) {
  DynamicDict<DictManager::UnorderedMapStrUnorderedSetStr> dict;
  bool suc;
  int64 cnt;

  UnorderedMapStrUnorderedSetStrLoader(key_container_file_, &dict, &suc, &cnt);
  ASSERT_TRUE(suc);
  ASSERT_EQ(cnt, 5l);
  auto p = dict.GetDict();
  ASSERT_EQ(p->find("ab")->second.count("1"), 1u);
  ASSERT_EQ(p->find("ab")->second.count("5"), 1u);
  ASSERT_EQ(p->find("Ab")->second.count("2"), 1u);
  ASSERT_EQ(p->find("Ab")->second.count("3"), 1u);
  ASSERT_EQ(p->find("Ab")->second.count("4"), 1u);
  ASSERT_EQ(p->find("1")->second.count("3"), 1u);
  ASSERT_EQ(p->find("1")->second.count("5"), 1u);
  ASSERT_EQ(p->find("1")->second.count("6"), 1u);
  ASSERT_EQ(p->find("1.0")->second.count("4"), 1u);
  ASSERT_EQ(p->find("1.0")->second.count("7"), 1u);
  ASSERT_EQ(p->find("1.0")->second.count("8"), 1u);
  ASSERT_EQ(p->find("9999999999999")->second.count("5"), 1u);
  ASSERT_EQ(p->find("9999999999999")->second.count("9"), 1u);
  ASSERT_EQ(p->find("9999999999999")->second.count("1"), 1u);

  UnorderedMapStrUnorderedSetStrNormalizedLoader(key_container_file_, &dict, &suc, &cnt);
  ASSERT_TRUE(suc);
  ASSERT_EQ(cnt, 4l);
  p = dict.GetDict();
  ASSERT_EQ(p->find("ab")->second.count("1"), 1u);
  ASSERT_EQ(p->find("ab")->second.count("2"), 1u);
  ASSERT_EQ(p->find("ab")->second.count("3"), 1u);
  ASSERT_EQ(p->find("ab")->second.count("4"), 1u);
  ASSERT_EQ(p->find("ab")->second.count("5"), 1u);
  ASSERT_EQ(p->find("1")->second.count("3"), 1u);
  ASSERT_EQ(p->find("1")->second.count("5"), 1u);
  ASSERT_EQ(p->find("1")->second.count("6"), 1u);
  ASSERT_EQ(p->find("1.0")->second.count("4"), 1u);
  ASSERT_EQ(p->find("1.0")->second.count("7"), 1u);
  ASSERT_EQ(p->find("1.0")->second.count("8"), 1u);
  ASSERT_EQ(p->find("9999999999999")->second.count("5"), 1u);
  ASSERT_EQ(p->find("9999999999999")->second.count("9"), 1u);
  ASSERT_EQ(p->find("9999999999999")->second.count("1"), 1u);
}
}  // namespace
}  // namespace

