#include <boost/shared_ptr.hpp>
#include <cstdatomic>
#include <unordered_map>
#include <vector>
#include <string>
#include <algorithm>

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/common/logging.h"
#include "base/thread/thread_pool.h"
#include "base/random/pseudo_random.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"

#include "reco/base/dict_manager/dynamic_dict.h"

namespace reco {
namespace dm {

typedef std::unordered_map<int, double> Map;

class ItemIdLevelDict {
 public:
  ItemIdLevelDict() {}
  virtual ~ItemIdLevelDict() {}
  virtual bool ParseFromString(const char* data, int64 size) {
    kv_.clear();
    std::string str(data, size);
    std::vector<std::string> lines;
    std::vector<std::string> flds;
    base::SplitString(str, "\n", &lines);
    for (size_t i = 0; i < lines.size(); ++i) {
      flds.clear();
      base::SplitString(lines[i], "\t", &flds);
      if (flds.size() != 2u) continue;
      uint64 item_id;
      int level;
      if (base::StringToUint64(flds[0], &item_id)
          && base::StringToInt(flds[1], &level)) {
        kv_[item_id] = level;
      }
    }
    return true;
  }

  virtual bool SerializeToString(std::string* data) {
    data->clear();
    for (auto it = kv_.begin(); it != kv_.end(); ++it) {
      data->append(base::Uint64ToString(it->first) + "\t"
                   + base::Int64ToString(it->second) + "\n");
    }
    return true;
  }

  const std::unordered_map<uint64, int>* getDict() const {
    return &kv_;
  }

 private:
  std::unordered_map<uint64, int> kv_;
};

reco::dm::DynamicDict<ItemIdLevelDict> sort_dict;

const std::unordered_map<uint64, int>* GetSortDict() {
  const std::unordered_map<uint64, int>* ptr_dict = sort_dict.GetDict()->getDict();

  if (ptr_dict == NULL) {
    LOG(ERROR) << "iflow item sort dict does not exist.";
    return NULL;
  }

  return ptr_dict;
}

static void write_thread() {
  base::PseudoRandom random;

  for (int i = 0; i < 1000; ++i) {
    int lines = 10000;
    std::string content;
    content.reserve(lines * 100);
    for (int i = 0; i < lines; ++i) {
      if (!content.empty()) content.append("\n");
      uint64 id = random.GetUint64LT(1000000);
      content.append(base::StringPrintf("%ld\t1", id));
    }

    boost::shared_ptr<ItemIdLevelDict> shared_pt(new ItemIdLevelDict);
    shared_pt->ParseFromString(content.c_str(), content.size());
    sort_dict.Swap(shared_pt);
    LOG_EVERY_N(INFO, 10) << "dict reload";
  }
}

static void read_thread_safe() {
  base::PseudoRandom random;

  for (int i = 0; i < 100000; ++i) {
    // const std::unordered_map<uint64, int>* map = GetSortDict();
    auto ptr = sort_dict.GetDict();
    uint64 id = random.GetUint64LT(1000000);
    auto it = ptr->getDict()->find(id);
    if (it != ptr->getDict()->end()) {
      LOG(INFO) << it->first;
    }
  }
}

TEST(DynamicDict, Multithreads) {
  thread::ThreadPool pool(11);
  for (int i = 0; i < 10; ++i) {
    // pool.AddTask(::NewCallback(read_thread));  // core dump
    pool.AddTask(::NewCallback(read_thread_safe));
  }
  pool.AddTask(::NewCallback(write_thread));

  pool.JoinAll();
}

typedef std::unordered_map<int, double> Map;

struct MyObj {
  MyObj(): a_(0), b_(0) {}
  explicit MyObj(int a): a_(a), b_(0) {}
  explicit MyObj(int& a, int* b): a_(a), b_(*b) {}  // NOLINT
  MyObj(int a, int b): a_(a), b_(b) {}
  MyObj(int* a): a_(*a), b_(0) {}  // NOLINT
  MyObj(const MyObj& r) {
    a_ = r.a_;
    b_ = r.b_;
    ++copy_;
  }
  int a(void) const { return a_; }
  int b(void) const { return b_; }
  static int copy(void) { return copy_; }
  int a_;
  int b_;
  static std::atomic<int> copy_;
};
std::atomic<int> MyObj::copy_(0);
TEST(DynamicDict, CreateObject) {
  // 调用无参构造
  DynamicDict<MyObj> mobj1;
  ASSERT_EQ(mobj1.GetDict()->a(), 0);
  ASSERT_EQ(mobj1.GetDict()->b(), 0);

  // 调用单参数非模板构造函数, 传入 shared_ptr
  boost::shared_ptr<MyObj> mo(new MyObj(20, 30));
  DynamicDict<MyObj> mobj6(mo);
  ASSERT_EQ(mobj6.GetDict()->a(), 20);
  ASSERT_EQ(mobj6.GetDict()->b(), 30);
}

TEST(DynamicDict, use_count) {
  DynamicDict<Map> dynm_data;

  // 内部持有
  ASSERT_EQ(dynm_data.use_count(), 1);

  // 增加临时对象
  ASSERT_EQ(dynm_data.GetDict().use_count(), 1+1);
  // 析构一个临时对象, 增加一个临时对象, count 不变
  ASSERT_EQ(dynm_data.GetDict().use_count(), 2);

  // 之前所有临时对象析构, 增加 pt1, count == 2
  boost::shared_ptr<const Map> pt1 = dynm_data.GetDict();
  ASSERT_EQ(pt1.use_count(), 2);

  // 增加 pt2, count == 3
  boost::shared_ptr<const Map> pt2 = dynm_data.GetDict();
  ASSERT_EQ(pt1.use_count(), 2+1);
  ASSERT_EQ(pt2.use_count(), 2+1);

  // 指针拷贝
  boost::shared_ptr<const Map> pt3 = pt2;
  ASSERT_EQ(pt1.use_count(), 3+1);
  ASSERT_EQ(pt2.use_count(), pt1.use_count());
  ASSERT_EQ(pt3.use_count(), pt1.use_count());

  // 内部对象更新, 计数重新开始, 两个 Map 同时存在
  {
    boost::shared_ptr<Map> cp(new Map);
    dynm_data.Swap(cp);
  }
  ASSERT_EQ(dynm_data.use_count(), 1);
  boost::shared_ptr<const Map> pt4 = dynm_data.GetDict();
  ASSERT_EQ(dynm_data.use_count(), 1+1);
  ASSERT_EQ(pt4.use_count(), 2);

  // 内部对象更新不影响已经被拥有的对象, 但是原来内部对象已经被析构
  ASSERT_EQ(pt1.use_count(), 4-1);
  ASSERT_EQ(pt2.use_count(), pt1.use_count());
  ASSERT_EQ(pt3.use_count(), pt1.use_count());

  // 再对内部对象更新, 计数重新开始, 但是不影响之前所有对象, 三个 Map 同时存在
  {
    boost::shared_ptr<Map> cp(new Map);
    dynm_data.Swap(cp);
  }
  ASSERT_EQ(dynm_data.use_count(), 1);
  ASSERT_EQ(pt1.use_count(), 3);
  ASSERT_EQ(pt2.use_count(), pt1.use_count());
  ASSERT_EQ(pt3.use_count(), pt1.use_count());
  ASSERT_EQ(pt4.use_count(), 2-1);

  // 老指针再赋值, 加加减减
  pt1 = pt4;
  ASSERT_EQ(pt4.use_count(), 1+1);
  ASSERT_EQ(pt1.use_count(), pt4.use_count());
  ASSERT_EQ(pt2.use_count(), 3-1);
  ASSERT_EQ(pt3.use_count(), pt2.use_count());
}

void user_thread(const DynamicDict<Map>* dynm_data, const std::vector<int>* keys, const Map* map) {
  base::PseudoRandom random;

  bool begin_found = false;
  int cnt_not_found = 0;
  boost::shared_ptr<const Map> data = dynm_data->GetDict();
  for (int i = 0; i < (int)keys->size(); ++i) {
    if (i % 100 == 0) {
      // 等一等主线程, 避免所有数据都读完了, 但是新数据还没有加载上来.
      if (!begin_found && random.GetDouble() > 0.8) base::SleepForMilliseconds(1);
      data = dynm_data->GetDict();
    }

    int key = (*keys)[i];
    CHECK(map->find(key) != map->end());

    auto found = data->find(key);
    if (found != data->end()) {
      begin_found = true;
      CHECK_EQ(found->second, map->find(key)->second);
    } else {
      CHECK(!begin_found) << i;
      ++cnt_not_found;
    }
  }
  LOG(ERROR) << "cnt not found " << cnt_not_found
             << ", total=" << keys->size();
}

TEST(DynamicDict, Multithreads2) {
  base::PseudoRandom random;
  Map cp;
  for (int i = 0; i < 200000; ++i) {
    cp[random.GetInt(0, 10000000)] = random.GetDouble();
  }
  std::vector<int> keys;
  keys.reserve(cp.size());
  for (auto it = cp.begin(); it != cp.end(); ++it) {
    keys.push_back(it->first);
  }

  DynamicDict<Map> dynm_data;

  thread::ThreadPool pool(2);
  for (int i = 0; i < 2; ++i) {
    pool.AddTask(::NewCallback(user_thread,
                               reinterpret_cast<const DynamicDict<Map>*>(&dynm_data),
                               reinterpret_cast<const std::vector<int>*>(&keys),
                               reinterpret_cast<const std::unordered_map<int, double>*>(&cp)));
  }

  // 工作线程运行中途, 主线程修改 dynamic data
  boost::shared_ptr<Map> shared_cp(new Map(cp));
  dynm_data.Swap(shared_cp);

  pool.JoinAll();
}
}  // namespace
}  // namespace
