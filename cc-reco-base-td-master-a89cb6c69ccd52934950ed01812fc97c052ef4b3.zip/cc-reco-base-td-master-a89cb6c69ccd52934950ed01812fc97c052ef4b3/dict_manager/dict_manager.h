#pragma once
#include <string>
#include <set>
#include <map>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include "base/common/basic_types.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/common/closure.h"
#include "base/thread/blocking_var.h"
#include "base/thread/sync.h"
#include "reco/base/common/singleton.h"
#include "reco/base/dict_manager/dynamic_dict.h"
#include "reco/base/dict_manager/common_dict_loader.h"
#include "reco/base/dict_manager/reload_service_type.pb.h"

namespace reco {
namespace dm {

// file_path: 词典路径
// dict_address： 这里虽然是 void* 但需要在函数内部强制转换成 DyanmicDict<T> 类型
// suc：词典是否加载成功通过这个变量返回
// cnt：词典加载的总条目数通过这个变量返回
// 框架在调用该函数后会统一打印日志是否加载成功，加载了多少条
// NOTE:更多样例移步 reco/dict_manager/common_dict_loader.h
typedef void (*DictLoader)(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// 词典管理类。负责词典的注册，加载，重载
// ** 设计要点 **
// 》词典类型由调用方决定，框架不管. 这样将词典定义的灵活性完全交给用户
// 》在 Register Get UnRegiter 等场景都需要提供模版类型，
//   因为为了做到通用性，框架内部都是通过 void* 管理动态词典的指针，在实际使用中，
//   分配资源、读取、释放资源都需要知道内存大小，需要用户侧给出词典类型
// 》词典加载对用户透明，通过包成 closure 这样闭包从而回避了模版指定的问题
//   这样才能做到自动加载
// 》词典加载函数有统一的入参要求，并在 common_dict_loader.h 里提供丰富的选择支持常用类型
//   传人的 void* 其实是 DynamicDict 的地址
//
//
// NOTE: ** 使用步骤 **
// 1. 给你的词典取一个比较别致的名字 dict name。 名字是框架用来管理字典的 key。
//    如果名字跟别人冲突了，会引发 CHECK
// 2. 给出你的词典的本地路径 file path。这个路径可以是相对路径，框架内部会统一转换成绝对路径
//    注意这个路径也不能跟别人冲突，否则会引发 CHECK
//    但这个路径一旦提交以后，你就可以不管了，后面你都是通过 dict name 维护字典
//    后续文件路径是词典分发平台重载词典的 key
// 3. 挑选或者自己写一个字典加载函数 loader
// 4. 注册字典调用 DictManagerSingleton::instance().RegisterDict<T>(dict_name, file_path, loader)
//    注意 DictManger 是全局单例
// 5. 需要手工调用 Reload 函数或者 LoadAllDict 函数加载一次词典
// 6. 通过 GetDict 函数取用字典
// 7. 程序退出前，记得调用 UnRegisterDict 方法做资源释放
// NOTE: 对于常用的词典类型，请移步本文下方使用预置的 #define 宏进行词典注册
class DictManager {
 public:
  // 这里将常用的词典进行 typedef。其实我不建议大家直接使用这个 typedef 这对于阅读代码的人来说需要一层转换。
  // 虽然这里的名字已然比较规范
  //
  // 但这里必须定义的原因在于:
  // 很多 #define 场景下是无脑以逗号分割的，不 typedef 成一个整体的话模版类会从中间切开
  // NOTE: 这里的 typedef 与对应的预置 loader 名字是匹配的，这样才方便文末的宏发挥作用
  // 比如词典是 SetStr, 那么对应 Loader 名字就是
  //   SetStrLoader  SetStrNormalizedLoader
  typedef std::unordered_map<std::string, std::string> UnorderedMapStrStr;
  typedef std::unordered_map<std::string, double> UnorderedMapStrDouble;
  typedef std::map<std::string, std::string> MapStrStr;
  typedef std::map<std::string, int> MapStrInt;
  typedef std::set<std::string> SetStr;
  typedef std::unordered_set<std::string> UnorderedSetStr;
  typedef std::unordered_set<uint64> UnorderedSetUint64;
  typedef std::unordered_map<std::string, std::vector<std::string> > UnorderedMapStrVectorStr;
  typedef std::unordered_map<std::string, std::unordered_set<std::string> > UnorderedMapStrUnorderedSetStr;
  typedef std::unordered_map<uint64, double> UnorderedMapUint64Double;
  typedef std::unordered_map<std::string, int> UnorderedMapStrInt;
  typedef std::unordered_map<uint64, uint64> UnorderedMapUint64Uint64;

  DictManager() {}
  ~DictManager() {}

  // 词典注册。 不能重复注册
  template <class T>
  void RegisterDict(const std::string& dict_name, const base::FilePath& path, DictLoader loader) {
    thread::WriterAutoLock lock(&mutex_);

    CHECK(dict_map_.find(dict_name) == dict_map_.end())
        << "dict name already registered: " << dict_name;

    // 转换成绝对路径
    base::FilePath file_path(path);
    CHECK(base::file_util::AbsolutePath(&file_path));
    CHECK(path_name_map_.find(file_path.ToString()) == path_name_map_.end())
        << "file path already registered" << path.ToString();

    LOG(INFO) << "register dict " << dict_name << " to path " << file_path.ToString();

    DictInfo info;
    info.dict_name = dict_name;
    info.file_path = file_path;
    info.mutex = new thread::Mutex();
    info.dynamic_dict = new DynamicDict<T>();
    info.suc = new bool;
    info.cnt = new int64;
    info.closure = ::NewPermanentCallback(loader, file_path, info.dynamic_dict, info.suc, info.cnt);

    dict_map_.insert(std::make_pair(dict_name, info));
    path_name_map_[file_path.ToString()] = dict_name;
  }

  // 取消注册。 取消后的词典可以被再次注册
  template <class T>
  void UnRegisterDict(const std::string& dict_name) {
    thread::WriterAutoLock lock(&mutex_);
    auto it = dict_map_.find(dict_name);
    if (it == dict_map_.end()) {
      LOG(WARNING) << "dict name not found: " << dict_name;
      return;
    }

    DictInfo& info = it->second;
    auto jt = path_name_map_.find(info.file_path.ToString());
    if (jt != path_name_map_.end()) {
      path_name_map_.erase(jt);
    } else {
      LOG(WARNING) << "dict name's file path not registered: " << info.file_path.ToString();
    }

    delete info.mutex;
    delete info.closure;
    delete reinterpret_cast<DynamicDict<T>* >(info.dynamic_dict);
    delete info.suc;
    delete info.cnt;
    dict_map_.erase(it);
  }

  // 加载所有词典
  bool LoadAllDicts() {
    bool ret = true;
    for (auto it = dict_map_.begin(); it != dict_map_.end(); ++it) {
      ret = ReloadByDictName(it->first) && ret;  // 顺序不能反！
    }
    return ret;
  }

  void ReloadDict(reco::dm::ReloadFileRequest* request,
    reco::dm::ReloadFileResponse* response, Closure* cls) {
    LOG(INFO) << "http reload start: " << request->file_name();
    ScopedClosure scoped_closure(cls);
    bool ret = ReloadByAbsolutePath(request->file_name());
    int code = ret ? 0 : 1;
    response->set_err_code(code);
    LOG(INFO) << "http reload end: " << request->file_name();
  }

  // 根据词典名称重载词典
  bool ReloadByDictName(const std::string& dict_name) {
    auto it = dict_map_.find(dict_name);
    if (it == dict_map_.end()) {
      LOG(ERROR) << "dict name not found: " << dict_name;
      return false;
    }

    DictInfo& info = it->second;
    thread::AutoLock lock(info.mutex);

    info.closure->Run();
    if (!(*info.suc)) {
      LOG(ERROR) << "failed to load: " << info.file_path.ToString();
      return false;
    } else {
      LOG(INFO) << "reload succ: " << info.file_path.ToString()
          << ", total cnt: " << *(info.cnt);
    }

    return true;
  }

  // 根据词典路径重载词典
  bool ReloadByAbsolutePath(const std::string& file_path) {
    auto it = path_name_map_.find(file_path);
    if (it == path_name_map_.end()) {
      LOG(ERROR) << "file path not found: " << file_path;
      return false;
    }

    return ReloadByDictName(it->second);
  }

  // 获得词典
  template <class T>
  boost::shared_ptr<const T> GetDict(const std::string& dict_name) {
    thread::ReaderAutoLock lock(&mutex_);
    auto it = dict_map_.find(dict_name);
    if (it == dict_map_.end()) {
      LOG(ERROR) << "dict name not found: " << dict_name;
      return boost::shared_ptr<const T>();
    }
    DynamicDict<T>* dynamic_dict = reinterpret_cast<DynamicDict<T>*>(it->second.dynamic_dict);
    return dynamic_dict->GetDict();
  }

 private:
  // 因为 DictInfo 可能在容器里拷贝，主要的成员必须是指针，避免拷贝时地址变化
  struct DictInfo {
    std::string dict_name;
    base::FilePath file_path;
    Closure* closure;
    thread::Mutex* mutex;
    void* dynamic_dict;
    bool* suc;
    int64* cnt;
  };
  std::unordered_map<std::string, std::string> path_name_map_;
  std::unordered_map<std::string, DictInfo> dict_map_;
  thread::RWMutex mutex_;
};

typedef reco::common::singleton_default<DictManager> DictManagerSingleton;

// 以下的宏给使用 DictManager 中预置的几种字典的用户带来了极致的方便，但需要遵守以下公约：
// 1. 词典的父目录是 FLAGS_dict_manager_root_dir
// 2. 词典的文件名（可以包含子目录名）由某个变量（一般是类静态常量指定）
// 3. 使用 REGISTER_COMMON 宏的，词典类型是 DictManager 中 typedef 的几种，
//    且加载函数是 common_dict_loader.h 里关于该类型有／无 Normalized 的两种版本
// 4. 注意 DM_REGISTER_COMMON_DICT 和 DM_REGISTER_COMMON_NORMALIZED_DICT 宏的定义
//    限定了词典和 loader 定义在 reco::dm 名字空间
//
// 效果举例:
// 假设 FLAGS_dict_manager_root = "../data"
// 你在你的类里定义
// const char* kYourDictFile = "dict.txt"
// 那么调用 DM_REGISTER_COMMON_DICT(SetStr, kYourDictFile) 后，你注册函数的参数是
// dict_name = "kYourDictFile"
// file_path = "../data/dict.txt"
// loader = SetStrLoader

DECLARE_string(dict_manager_root_dir);

#define DM_REGISTER_COMMON_DICT(T, var) \
  reco::dm::DictManagerSingleton::instance().RegisterDict<reco::dm::DictManager::T>(\
  #var, base::FilePath(reco::dm::FLAGS_dict_manager_root_dir).Append(var), reco::dm::T##Loader)

#define DM_REGISTER_COMMON_NORMALIZED_DICT(T, var) \
  reco::dm::DictManagerSingleton::instance().RegisterDict<reco::dm::DictManager::T>(\
  #var, base::FilePath(reco::dm::FLAGS_dict_manager_root_dir).Append(var), reco::dm::T##NormalizedLoader)

#define DM_REGISTER_CUSTOMER_DICT(T, var, loader) \
  reco::dm::DictManagerSingleton::instance().RegisterDict<T>(\
  #var, base::FilePath(reco::dm::FLAGS_dict_manager_root_dir).Append(var), loader)

#define DM_GET_DICT(T, var) reco::dm::DictManagerSingleton::instance().GetDict<const T>(#var)
}  // namespace dm
}  // namespace reco
