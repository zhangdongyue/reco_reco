#include <boost/shared_ptr.hpp>
#include <cstdatomic>
#include <unordered_map>
#include <vector>

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/common/logging.h"
#include "base/thread/thread_pool.h"
#include "base/random/pseudo_random.h"

#include "reco/base/dict_manager/dict_manager.h"
#include "reco/base/dict_manager/common_dict_loader.h"

namespace reco {
namespace dm {

#define REGISTER(T, NUM)  \
  DictManagerSingleton::instance().RegisterDict<T>( \
      g_dicts[NUM].dict_name, g_dicts[NUM].file_path, g_dicts[NUM].dict_loader)

#define RELOAD(NUM) DictManagerSingleton::instance().ReloadByDictName(g_dicts[NUM].dict_name)

#define UNREGISTER(T, NUM) DictManagerSingleton::instance().UnRegisterDict<T>(g_dicts[NUM].dict_name)

#define GETDICT(T, NUM) DictManagerSingleton::instance().GetDict<T>(g_dicts[NUM].dict_name)

typedef std::unordered_map<std::string, std::string> UnorderedMapStrStr;
typedef std::map<std::string, std::string> MapStrStr;
typedef std::map<std::string, int> MapStrInt;
typedef std::set<std::string> SetStr;

struct DictMeta {
  const char* dict_name;
  const char* file_path;
  DictLoader dict_loader;
} g_dicts[] = {
  {"UnorderedMapStrStr", "reco/dict_manager/test_case/str_str.txt", UnorderedMapStrStrLoader},
  {"UnorderedMapStrStr", "reco/dict_manager/test_case/str_str.txt", UnorderedMapStrStrNormalizedLoader},

  {"MapStrStr", "reco/dict_manager/test_case/str_str.txt", MapStrStrLoader},
  {"MapStrStr", "reco/dict_manager/test_case/str_str.txt", MapStrStrNormalizedLoader},

  {"MapStrInt", "reco/dict_manager/test_case/str_int.txt", MapStrIntLoader},
  {"MapStrInt", "reco/dict_manager/test_case/str_int.txt", MapStrIntNormalizedLoader},

  {"MapStrStr", "reco/dict_manager/test_case/str.txt", SetStrLoader},
  {"MapStrStr", "reco/dict_manager/test_case/str.txt", SetStrNormalizedLoader},
};

TEST(DictManagerTest, Api) {
  REGISTER(UnorderedMapStrStr, 0);
  ASSERT_TRUE(RELOAD(0));
  ASSERT_EQ(GETDICT(UnorderedMapStrStr, 0)->find("a")->second, "b");
  ASSERT_EQ(GETDICT(UnorderedMapStrStr, 0)->find("A")->second, "E");
  ASSERT_EQ(GETDICT(UnorderedMapStrStr, 0)->find("c")->second, "d");
  UNREGISTER(UnorderedMapStrStr, 0);

  REGISTER(UnorderedMapStrStr, 1);
  ASSERT_TRUE(RELOAD(1));
  ASSERT_EQ(GETDICT(UnorderedMapStrStr, 1)->find("a")->second, "e");
  ASSERT_EQ(GETDICT(UnorderedMapStrStr, 1)->find("c")->second, "d");
  UNREGISTER(UnorderedMapStrStr, 1);

  REGISTER(MapStrStr, 2);
  ASSERT_TRUE(RELOAD(2));
  ASSERT_EQ(GETDICT(MapStrStr, 2)->find("a")->second, "b");
  ASSERT_EQ(GETDICT(MapStrStr, 2)->find("A")->second, "E");
  ASSERT_EQ(GETDICT(MapStrStr, 2)->find("c")->second, "d");
  UNREGISTER(MapStrStr, 2);

  REGISTER(MapStrStr, 3);
  ASSERT_TRUE(RELOAD(3));
  ASSERT_EQ(GETDICT(MapStrStr, 3)->find("a")->second, "e");
  ASSERT_EQ(GETDICT(MapStrStr, 3)->find("c")->second, "d");
  UNREGISTER(MapStrStr, 3);

  REGISTER(MapStrInt, 4);
  ASSERT_TRUE(RELOAD(4));
  ASSERT_EQ(GETDICT(MapStrInt, 4)->find("a")->second, 1);
  ASSERT_EQ(GETDICT(MapStrInt, 4)->find("B")->second, 2);
  ASSERT_EQ(GETDICT(MapStrInt, 4)->find("c")->second, 3);
  UNREGISTER(MapStrInt, 4);

  REGISTER(MapStrInt, 5);
  ASSERT_TRUE(RELOAD(5));
  ASSERT_EQ(GETDICT(MapStrInt, 5)->find("a")->second, 1);
  ASSERT_EQ(GETDICT(MapStrInt, 5)->find("b")->second, 2);
  ASSERT_EQ(GETDICT(MapStrInt, 5)->find("c")->second, 3);
  UNREGISTER(MapStrInt, 5);

  REGISTER(SetStr, 6);
  ASSERT_TRUE(RELOAD(6));
  ASSERT_EQ(GETDICT(SetStr, 6)->count("a"), 1u);
  ASSERT_EQ(GETDICT(SetStr, 6)->count("B"), 1u);
  UNREGISTER(SetStr, 6);

  REGISTER(SetStr, 7);
  ASSERT_TRUE(RELOAD(7));
  ASSERT_EQ(GETDICT(SetStr, 7)->count("a"), 1u);
  ASSERT_EQ(GETDICT(SetStr, 7)->count("b"), 1u);
  ASSERT_EQ(GETDICT(SetStr, 7)->count("B"), 0u);
  UNREGISTER(SetStr, 7);
}

static void read_thread() {
  base::PseudoRandom random;

  for (int i = 0; i < 100000; ++i) {
    {
      auto ptr = GETDICT(UnorderedMapStrStr, 0);
      uint64 id = random.GetUint64LT(1000000);
      auto it = ptr->find(base::Uint64ToString(id));
      if (it != ptr->end()) {
        LOG(INFO) << it->first;
      }
      LOG(INFO) << ptr.use_count();
    }
    {
      auto ptr = GETDICT(MapStrInt, 5);
      uint64 id = random.GetUint64LT(1000000);
      auto it = ptr->find(base::Uint64ToString(id));
      if (it != ptr->end()) {
        LOG(INFO) << it->first;
      }
      LOG(INFO) << ptr.use_count();
    }
    {
      auto ptr = GETDICT(SetStr, 6);
      uint64 id = random.GetUint64LT(1000000);
      auto it = ptr->find(base::Uint64ToString(id));
      if (it != ptr->end()) {
        LOG(INFO) << *it;
      }
      LOG(INFO) << ptr.use_count();
    }
  }
}

static void reload_thread() {
  base::PseudoRandom random;

  for (int i = 0; i < 1000; ++i) {
    CHECK(RELOAD(0));
    CHECK(RELOAD(5));
    CHECK(RELOAD(6));

    LOG_EVERY_N(INFO, 100) << "dict reload";
  }
}

TEST(DictManagerTest, Multithreads) {
  REGISTER(UnorderedMapStrStr, 0);
  REGISTER(MapStrInt, 5);
  REGISTER(SetStr, 6);

  DictManagerSingleton::instance().LoadAllDicts();

  thread::ThreadPool pool(20);
  for (int i = 0; i < 10; ++i) {
    pool.AddTask(::NewCallback(read_thread));
  }
  for (int i = 0; i < 10; ++i) {
    pool.AddTask(::NewCallback(reload_thread));
  }

  pool.JoinAll();

  UNREGISTER(UnorderedMapStrStr, 0);
  UNREGISTER(MapStrInt, 5);
  UNREGISTER(SetStr, 6);
}

}  // namespace
}  // namespace

