#pragma once

#include "reco/base/dict_manager/reload_service.pb.h"
#include "reco/base/common/request_manager.h"
#include "base/strings/string_util.h"

namespace reco {
namespace dm {

class ReloadServiceImpl: public ReloadService {
 public:
  ReloadServiceImpl();
  ~ReloadServiceImpl();

  virtual void ReloadFile(stumy::RpcController* controller, const ReloadFileRequest* request,
                          ReloadFileResponse* response, Closure* done);
  virtual void ReloadFile_(const ReloadFileRequest* request,
                           ReloadFileResponse* response, Closure* done);
 private:
  reco::common::RequestManager req_manager_;

  DISALLOW_COPY_AND_ASSIGN(ReloadServiceImpl);
};

}  // namespace
}  // namespace
