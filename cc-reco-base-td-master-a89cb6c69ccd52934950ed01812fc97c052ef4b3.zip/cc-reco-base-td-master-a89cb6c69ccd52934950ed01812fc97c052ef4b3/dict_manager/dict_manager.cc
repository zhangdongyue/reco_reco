#include "reco/base/dict_manager/dict_manager.h"

namespace reco {
namespace dm {
DEFINE_string(dict_manager_root_dir, "../data", "root dir for dict files");
}  // namespace dm
}
