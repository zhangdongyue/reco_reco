#pragma once
#include <boost/shared_ptr.hpp>

#include "base/common/basic_types.h"
#include "base/thread/sync.h"
#include "base/thread/rw_mutex.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace dm {

/******  动态词典定义   ********/
template <class Dict>
class DynamicDict {
 public:
  // template constructors
  DynamicDict() : dict_(new Dict) {}
  explicit DynamicDict(boost::shared_ptr<Dict>& dict) : dict_(dict) {}  // NOLINT

  ~DynamicDict() {}
 public:
  boost::shared_ptr<const Dict> GetDict(void) const;

  boost::shared_ptr<Dict> GetMutableDict(void);

  void Swap(boost::shared_ptr<Dict>& dict);

  int32 use_count(void) const;
 private:
  boost::shared_ptr<Dict> dict_;
  mutable thread::RWMutex access_mutex_;
  DISALLOW_COPY_AND_ASSIGN(DynamicDict<Dict>);
};

template<class Dict>
void DynamicDict<Dict>::Swap(boost::shared_ptr<Dict>& dict) {
  thread::WriterAutoLock lock_access(&access_mutex_);
  dict_.swap(dict);
}

template<class Dict>
boost::shared_ptr<const Dict> DynamicDict<Dict>::GetDict(void) const {
  thread::ReaderAutoLock lock_access(&access_mutex_);
  return dict_;
}

template<class Dict>
boost::shared_ptr<Dict> DynamicDict<Dict>::GetMutableDict(void) {
  thread::ReaderAutoLock lock_access(&access_mutex_);
  return dict_;
}

template<class Dict>
int32 DynamicDict<Dict>::use_count(void) const {
  thread::ReaderAutoLock lock_access(&access_mutex_);
  return dict_.use_count();
}
}  // namespace
}  // namespace
