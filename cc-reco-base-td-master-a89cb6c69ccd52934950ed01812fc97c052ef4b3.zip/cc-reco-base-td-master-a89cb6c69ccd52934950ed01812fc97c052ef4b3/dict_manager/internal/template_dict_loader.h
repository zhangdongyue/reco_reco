#pragma once
#include <type_traits>
#include <boost/shared_ptr.hpp>
#include <vector>
#include <string>
#include <unordered_map>
#include <sstream>
#include <map>
#include <set>
#include "base/common/basic_types.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"
#include "base/file/file_path.h"
#include "nlp/common/nlp_util.h"
#include "reco/base/dict_manager/dynamic_dict.h"

namespace reco {
namespace dm {
namespace internal {

// 解析 str_val 为任意 POD / string 类型
template <class T>
bool parse_string(const std::string& str_val, T* val) {  // NOLINT
  bool ret = true;
  if (std::is_same<int, T>::value) {
    int v;
    ret = base::StringToInt(str_val, &v);
    *val = v;
  } else if (std::is_same<int64, T>::value) {
    int64 v;
    ret = base::StringToInt64(str_val, &v);
    *val = v;
  } else if (std::is_same<uint32, T>::value) {
    uint32 v;
    ret = base::StringToUint(str_val, &v);
    *val = v;
  } else if (std::is_same<uint64, T>::value) {
    uint64 v;
    ret = base::StringToUint64(str_val, &v);
    *val = v;
  } else if (std::is_same<float, T>::value) {
    double v;
    ret = base::StringToDouble(str_val, &v);
    *val = v;
  } else if (std::is_same<double, T>::value) {
    double v;
    ret = base::StringToDouble(str_val, &v);
    *val = v;
  } else if (std::is_same<std::string, T>::value) {
    // 编译器不支持 string 跟 数值类型的转化，所以这边必须用 sstream
    // 上面的数值类型不使用 sstream，因为没有合法性检查
    std::stringstream sstream(str_val);
    // bug fix: sstream >> *val will break when encounter space
    // sstream.unsetf(std::ios::skipws);
    bool first = true;
    while (!sstream.eof()) {
      T v;
      sstream >> v;
      if (!first) {
      *val = *val + ' ' + v;
      } else {
        *val = *val + v;
      }
      first = false;
    }
  } else {
    LOG(ERROR) << "unknow type";
    ret = false;
  }
  return ret;
}

// 基本 key-value 容器的加载. 目前 T 主要是 unordered_map 和 map
// dense hash 等要在外部额外调用 set empty key 等 api
template<class T, class K, class V>
void LoadKeyValueDict(base::FilePath file_path, bool normalize, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines, flds;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "failed to open file: " << file_path.ToString();
    return;
  }

  T* dict = new T();
  for (int i = 0; i < (int)lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);

    if (flds.size() < 2 || flds[0].empty() || flds[1].empty()) {
      LOG(WARNING) << "error format line: " << lines[i];
      continue;
    }

    if (flds[0][0] == '#') {
      continue;  // jump line that start with '#'
    }

    if (normalize) {
      nlp::util::NormalizeLineInPlaceS(&flds[0]);
      nlp::util::NormalizeLineInPlaceS(&flds[1]);
    }

    K key;
    V val;
    if (!parse_string(flds[0], &key) || !parse_string(flds[1], &val)) {
      LOG(WARNING) << "failed parse line: " << lines[i];
      continue;
    }
    (*dict)[key] = val;
  }
  boost::shared_ptr<T> ptr(dict);
  DynamicDict<T>* dynamic_dict = reinterpret_cast<DynamicDict<T>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

// 基本纯 key 容器的加载. 目前 T 主要是 unordered_set 和 set
// dense hash 等要在外部额外调用 set empty key 等 api
template<class T, class K>
void LoadKeyDict(base::FilePath file_path, bool normalize, void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "failed to open file: " << file_path.ToString();
    return;
  }

  T* dict = new T();
  for (int i = 0; i < (int)lines.size(); ++i) {
    if (lines[i].empty()) {
      LOG(WARNING) << "error format line: " << lines[i];
      continue;
    }

    if (lines[i][0] == '#') {
      continue;  // jump line that start with '#'
    }

    if (normalize) {
      nlp::util::NormalizeLineInPlaceS(&lines[i]);
    }

    K key;
    if (!parse_string(lines[i], &key)) {
      LOG(WARNING) << "failed parse line: " << lines[i];
      continue;
    }
    dict->insert(key);
  }
  boost::shared_ptr<T> ptr(dict);
  DynamicDict<T>* dynamic_dict = reinterpret_cast<DynamicDict<T>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

// key-Value 容器的加载. 其中 Value 部分是 vector<V>
// dense hash 等要在外部额外调用 set empty key 等 api
template<class T, class K, class V>
void LoadKeyVectorValueDict(base::FilePath file_path, bool normalize,
                            void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines, flds, subs;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "failed to open file: " << file_path.ToString();
    return;
  }

  T* dict = new T();
  for (size_t i = 0; i < lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);

    if (flds.size() < 2 || flds[0].empty() || flds[1].empty()) {
      LOG(WARNING) << "error format line: " << lines[i];
      continue;
    }

    if (flds[0][0] == '#') {
      continue;  // jump line that start with '#'
    }

    if (normalize) {
      nlp::util::NormalizeLineInPlaceS(&flds[0]);
    }

    K key;
    if (!parse_string(flds[0], &key)) {
      LOG(WARNING) << "failed parse line: " << lines[i];
      continue;
    }

    subs.clear();
    base::SplitString(flds[1], "`", &subs);
    for (size_t j = 0; j < subs.size(); ++j) {
      if (normalize) {
        nlp::util::NormalizeLineInPlaceS(&subs[j]);
      }
      V val;
      if (!parse_string(subs[j], &val)) {
        LOG(WARNING) << "failed parse line: " << lines[i];
        continue;
      }
      (*dict)[key].push_back(val);
    }
  }
  boost::shared_ptr<T> ptr(dict);
  DynamicDict<T>* dynamic_dict = reinterpret_cast<DynamicDict<T>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}

// key-Value 容器的加载. 其中 Value 部分是 unordered_set<V>/set<V>
// dense hash 等要在外部额外调用 set empty key 等 api
template<class T, class K, class V>
void LoadKeySetValueDict(base::FilePath file_path, bool normalize,
                         void* dict_address, bool* suc, int64* cnt) {
  *suc = false;
  *cnt = 0;
  std::vector<std::string> lines, flds, subs;
  if (!base::file_util::ReadFileToLines(file_path, &lines)) {
    LOG(ERROR) << "failed to open file: " << file_path.ToString();
    return;
  }

  T* dict = new T();
  for (size_t i = 0; i < lines.size(); ++i) {
    flds.clear();
    base::SplitString(lines[i], "\t", &flds);

    if (flds.size() < 2 || flds[0].empty() || flds[1].empty()) {
      LOG(WARNING) << "error format line: " << lines[i];
      continue;
    }

    if (flds[0][0] == '#') {
      continue;  // jump line that start with '#'
    }

    if (normalize) {
      nlp::util::NormalizeLineInPlaceS(&flds[0]);
    }

    K key;
    if (!parse_string(flds[0], &key)) {
      LOG(WARNING) << "failed parse line: " << lines[i];
      continue;
    }

    subs.clear();
    base::SplitString(flds[1], "`", &subs);
    for (size_t j = 0; j < subs.size(); ++j) {
      if (normalize) {
        nlp::util::NormalizeLineInPlaceS(&subs[j]);
      }
      V val;
      if (!parse_string(subs[j], &val)) {
        LOG(WARNING) << "failed parse line: " << lines[i];
        continue;
      }
      (*dict)[key].insert(val);
    }
  }
  boost::shared_ptr<T> ptr(dict);
  DynamicDict<T>* dynamic_dict = reinterpret_cast<DynamicDict<T>* >(dict_address);
  dynamic_dict->Swap(ptr);
  *suc = true;
  *cnt = dict->size();
  return;
}
}  // namespace internal
}  // namespace dict_manager
}  // namespace reco
