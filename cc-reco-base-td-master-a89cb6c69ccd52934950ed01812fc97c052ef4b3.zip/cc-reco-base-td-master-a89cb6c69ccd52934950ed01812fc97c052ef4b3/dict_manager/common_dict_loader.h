#pragma once
#include <type_traits>
#include <boost/shared_ptr.hpp>
#include <vector>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <map>
#include <set>
#include <sstream>
#include "base/common/basic_types.h"
#include "base/file/file_path.h"

namespace reco {
namespace dm {

// unordered_map<string, string>
void UnorderedMapStrStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// unordered_map<string, string> normalized
void UnorderedMapStrStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// unordered_map<string, double>
void UnorderedMapStrDoubleLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// unordered_map<string, double> normalized
void UnorderedMapStrDoubleNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);  // NOLINT

// map<string, string>
void MapStrStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// map<string, string> normalized
void MapStrStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// map<string, int>
void MapStrIntLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// map<string, int> normalized
void MapStrIntNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// unordered_set<string>
void UnorderedSetStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// unordered_set<string> normalized
void UnorderedSetStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// unordered_set<uint64>
void UnorderedSetUint64Loader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// unordered_set<uint64> normalized
void UnorderedSetUint64NormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// set<string>
void SetStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

// set<string> normalized
void SetStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

void UnorderedMapStrVectorStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

void UnorderedMapStrVectorStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);  // NOLINT

void UnorderedMapStrUnorderedSetStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);  // NOLINT

void UnorderedMapStrUnorderedSetStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);  // NOLINT

void UnorderedMapUint64DoubleLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

void UnorderedMapUint64DoubleNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);  // NOLINT

void UnorderedMapStrIntLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

void UnorderedMapStrIntNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

void UnorderedMapUint64Uint64Loader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);

void UnorderedMapUint64Uint64NormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt);  // NOLINT
}  // namespace dm
}  // namespace reco
