#include "reco/base/dict_manager/reload_service.pb.h"
#include <iostream>  // NOLINT
#include <fstream>  // NOLINT
#include "base/common/gflags.h"
#include "base/common/gflags_completions.h"
#include "base/time/timestamp.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"
#include "net/rpc/rpc.h"

DEFINE_string(query, "", "");
DEFINE_string(ip, "127.0.0.1", "");
DEFINE_int32(port, 30008, "");
DEFINE_string(reload_path, "", "");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "NLP RPC client.");

  net::rpc::RpcClientChannel channel(FLAGS_ip.c_str(), FLAGS_port);
  CHECK(channel.Connect());
  reco::dm::ReloadService::Stub service(&channel);

  reco::dm::ReloadFileRequest request;
  reco::dm::ReloadFileResponse response;
  request.set_file_name(FLAGS_reload_path);

  net::rpc::RpcClientController rpc;
  service.ReloadFile(&rpc, &request, &response, NULL);
  rpc.Wait();

  std::cout << rpc.error_text();
  std::cout << response.Utf8DebugString() << std::endl;
  return 0;
}

