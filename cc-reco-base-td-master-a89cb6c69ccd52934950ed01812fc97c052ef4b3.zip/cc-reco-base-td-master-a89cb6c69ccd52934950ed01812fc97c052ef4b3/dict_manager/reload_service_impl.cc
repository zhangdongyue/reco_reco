#include <string>
#include "reco/base/dict_manager/reload_service_impl.h"
#include "base/strings/string_util.h"
#include "reco/base/dict_manager/dict_manager.h"

namespace reco {
namespace dm {

DEFINE_int32(dict_reload_thread_num, 1, "");
DEFINE_int32(dict_reload_timeout_ms, 20000, "ms, dict reload may take long time");

ReloadServiceImpl::ReloadServiceImpl() {
  req_manager_.Init(FLAGS_dict_reload_thread_num, FLAGS_dict_reload_timeout_ms);

  req_manager_.RegisterReqFuncMap(new reco::common::ReqFuncMap<ReloadServiceImpl,
                                   ReloadFileRequest,
                                   ReloadFileResponse>(this, &ReloadServiceImpl::ReloadFile_));
}

ReloadServiceImpl::~ReloadServiceImpl() {
}

void ReloadServiceImpl::ReloadFile(stumy::RpcController* controller, const ReloadFileRequest* request,
                                   ReloadFileResponse* response, Closure* done) {
  req_manager_.AddReqTask(request, response, done);
}

void ReloadServiceImpl::ReloadFile_(const ReloadFileRequest* request,
                                    ReloadFileResponse* response, Closure* done) {
  ScopedClosure scoped_closure(done);
  LOG(INFO) << "ReloadFile req: " << base::StringReplace(request->Utf8DebugString(), "\n", " ", true);

  std::string err_msg;
  bool ret = reco::dm::DictManagerSingleton::instance().ReloadByAbsolutePath(request->file_name());
  LOG(INFO) << "reload end. result:" << ret << " err_msg:" << err_msg;
  // 0为成功,其他值为错误码
  int code = ret ? 0 : 1;
  response->set_err_code(code);
}

}  // namespace
}  // namespace
