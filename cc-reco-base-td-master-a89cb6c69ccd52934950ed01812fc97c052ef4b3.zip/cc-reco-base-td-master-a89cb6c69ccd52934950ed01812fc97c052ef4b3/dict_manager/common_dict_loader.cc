#include "reco/base/dict_manager/common_dict_loader.h"
#include "reco/base/dict_manager/internal/template_dict_loader.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/file/file_util.h"

namespace reco {
namespace dm {
// unordered_map<string, string>
void UnorderedMapStrStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyValueDict<std::unordered_map<std::string, std::string>, std::string, std::string>(
      file_path, false, dict_address, suc, cnt);
}

// unordered_map<string, string> normalized
void UnorderedMapStrStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyValueDict<std::unordered_map<std::string, std::string>, std::string, std::string>(
      file_path, true, dict_address, suc, cnt);
}

// unordered_map<string, double>
void UnorderedMapStrDoubleLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyValueDict<std::unordered_map<std::string, double>, std::string, double>(
      file_path, false, dict_address, suc, cnt);
}

// unordered_map<string, double> normalized
void UnorderedMapStrDoubleNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) { // NOLINT
  internal::LoadKeyValueDict<std::unordered_map<std::string, double>, std::string, double>(
      file_path, true, dict_address, suc, cnt);
}

// map<string, string>
void MapStrStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyValueDict<std::map<std::string, std::string>, std::string, std::string>(
      file_path, false, dict_address, suc, cnt);
}

// map<string, string> normalized
void MapStrStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyValueDict<std::map<std::string, std::string>, std::string, std::string>(
      file_path, true, dict_address, suc, cnt);
}

// map<string, int>
void MapStrIntLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyValueDict<std::map<std::string, int>, std::string, int>(
      file_path, false, dict_address, suc, cnt);
}

// map<string, int> normalized
void MapStrIntNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyValueDict<std::map<std::string, int>, std::string, int>(
      file_path, true, dict_address, suc, cnt);
}

// unordered_set<string>
void UnorderedSetStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyDict<std::unordered_set<std::string>, std::string>(
      file_path, false, dict_address, suc, cnt);
}

// unordered_set<string> normalized
void UnorderedSetStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyDict<std::unordered_set<std::string>, std::string>(
      file_path, true, dict_address, suc, cnt);
}

// unordered_set<uint64>
void UnorderedSetUint64Loader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyDict<std::unordered_set<uint64>, uint64>(
      file_path, false, dict_address, suc, cnt);
}

// unordered_set<uint64> normalized
void UnorderedSetUint64NormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyDict<std::unordered_set<uint64>, uint64>(
      file_path, true, dict_address, suc, cnt);
}

// set<string>
void SetStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyDict<std::set<std::string>, std::string>(
      file_path, false, dict_address, suc, cnt);
}

// set<string> normalized
void SetStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyDict<std::set<std::string>, std::string>(
      file_path, true, dict_address, suc, cnt);
}

void UnorderedMapStrVectorStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyVectorValueDict<std::unordered_map<std::string, std::vector<std::string> >, std::string, std::string>(  // NOLINT
      file_path, false, dict_address, suc, cnt);
}

void UnorderedMapStrVectorStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {  // NOLINT
  internal::LoadKeyVectorValueDict<std::unordered_map<std::string, std::vector<std::string> >, std::string, std::string>(  // NOLINT
      file_path, true, dict_address, suc, cnt);
}

void UnorderedMapStrUnorderedSetStrLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {  // NOLINT
  internal::LoadKeySetValueDict<std::unordered_map<std::string, std::unordered_set<std::string> >, std::string, std::string>(  // NOLINT
      file_path, false, dict_address, suc, cnt);
}

void UnorderedMapStrUnorderedSetStrNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {  // NOLINT
  internal::LoadKeySetValueDict<std::unordered_map<std::string, std::unordered_set<std::string> >, std::string, std::string>(  // NOLINT
      file_path, true, dict_address, suc, cnt);
}

void UnorderedMapUint64DoubleLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyValueDict<std::unordered_map<uint64, double>, uint64, double>(
      file_path, false, dict_address, suc, cnt);
}

void UnorderedMapUint64DoubleNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {  // NOLINT
  internal::LoadKeyValueDict<std::unordered_map<uint64, double>, uint64, double>(
      file_path, true, dict_address, suc, cnt);
}

void UnorderedMapStrIntLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyValueDict<std::unordered_map<std::string, int>, std::string, int>(
      file_path, false, dict_address, suc, cnt);
}

void UnorderedMapStrIntNormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyValueDict<std::unordered_map<std::string, int>, std::string, int>(
      file_path, true, dict_address, suc, cnt);
}

void UnorderedMapUint64Uint64Loader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {
  internal::LoadKeyValueDict<std::unordered_map<uint64, uint64>, uint64, uint64>(
      file_path, false, dict_address, suc, cnt);
}

void UnorderedMapUint64Uint64NormalizedLoader(base::FilePath file_path, void* dict_address, bool* suc, int64* cnt) {  // NOLINT
  internal::LoadKeyValueDict<std::unordered_map<uint64, uint64>, uint64, uint64>(
      file_path, true, dict_address, suc, cnt);
}
}
}
