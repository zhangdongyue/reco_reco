#pragma once
#include <boost/shared_ptr.hpp>
#include <unordered_map>
#include <unordered_set>

#include "base/common/basic_types.h"
#include "base/thread/sync.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"

#include "third_party/zookeeper/include/zookeeper.h"
#include "reco/base/zkconfig/dynamic_dict.h"

namespace reco {
namespace zkconfig {

/******  基础词典定义   ********/

// 需要管理的词典，都需要基于 Dict 派生
// 定义自己的词典 private 变量， 并且重载其中的 ParseFromString，SerializeToString 方法
// 解析和序列化操作的参数是一个字符串。这个字符串有可能是配置项的值，
// 也有可能是格式化的数据
class Dict {
 public:
  explicit Dict() {}
  virtual ~Dict() {}
  virtual bool ParseFromString(const char* data, int64 size) { return true;} ;
  virtual bool SerializeToString(std::string* data) { return true;} ;
};

// StringDict 实际上是用来存 String 类型的配置项
class StringDict : public Dict {
 public:
  StringDict() {};
  explicit StringDict(const std::string& data) { data_ = data; }
  virtual ~StringDict() {}
  virtual bool ParseFromString(const char* data, int64 size) {
    data_.assign(data, size);
    return true;
  }
  virtual bool SerializeToString(std::string* data) {
    *data = data_;
    return true;
  }

  std::string GetData() const { return data_; }
 private:
  std::string data_;
};

// StringVectorDict 实际上是用来存 children 类型的配置项
class StringVectorDict : public Dict {
 public:
  StringVectorDict() {};
  explicit StringVectorDict(const std::string& data) {
    ParseFromString(data.c_str(), data.size());
  }
  virtual ~StringVectorDict() {}
  virtual bool ParseFromString(const char* data, int64 size) {
    data_.clear();
    base::SplitString(std::string(data, size), "\t", &data_);
    return true;
  }
  virtual bool SerializeToString(std::string* data) {
    *data = base::JoinStrings(data_, "\t");
    return true;
  }

  const std::vector<std::string>& GetData() const { return data_; }
 private:
  std::vector<std::string> data_;
};

class KeyValueDict : public Dict {
 public:
  KeyValueDict() {};
  virtual ~KeyValueDict() {}
  virtual bool ParseFromString(const char* data, int64 size) {
    kv_.clear();
    std::string str(data, size);
    std::vector<std::string> lines;
    std::vector<std::string> flds;
    base::SplitString(str, "\n", &lines);
    for (size_t i = 0; i < lines.size(); ++i) {
      flds.clear();
      base::SplitString(lines[i], "\t", &flds);
      if (flds.size() != 2u) continue;
      kv_[flds[0]] = flds[1];
    }
    return true;
  }

  virtual bool SerializeToString(std::string* data) {
    data->clear();
    for (auto it = kv_.begin(); it != kv_.end(); ++it) {
      data->append(it->first + "\t" + it->second + "\n");
    }
    return true;
  }

  std::string get(const std::string& key) const {
    auto it = kv_.find(key);
    if (it != kv_.end()) {
      return it->second;
    } else {
      return "";
    }
  }

  void set(const std::string& key, const std::string& val) {
    kv_[key] = val;
  }

  const std::unordered_map<std::string, std::string>* getDict() const {
    return &kv_;
  }

 private:
  std::unordered_map<std::string, std::string> kv_;
};

class KeyDict : public Dict {
 public:
  KeyDict() {};
  virtual ~KeyDict() {}
  virtual bool ParseFromString(const char* data, int64 size) {
    k_.clear();
    std::string str(data, size);
    std::vector<std::string> lines;
    base::SplitString(str, "\n", &lines);
    for (size_t i = 0; i < lines.size(); ++i) {
      k_.insert(lines[i]);
    }
    return true;
  }

  virtual bool SerializeToString(std::string* data) {
    data->clear();
    for (auto it = k_.begin(); it != k_.end(); ++it) {
      data->append(*it + "\n");
    }
    return true;
  }

  bool contains(const std::string& key) const {
    return k_.find(key) != k_.end();
  }

  void insert(const std::string& key) {
    k_.insert(key);
  }

 private:
  std::unordered_set<std::string> k_;
};
}  // namespace
}  // namespace
