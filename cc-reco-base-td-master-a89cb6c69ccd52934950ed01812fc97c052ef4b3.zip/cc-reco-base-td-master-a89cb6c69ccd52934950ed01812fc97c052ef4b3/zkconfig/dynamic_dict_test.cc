#include <boost/shared_ptr.hpp>
#include <cstdatomic>
#include <unordered_map>
#include <vector>

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/common/logging.h"
#include "base/thread/thread_pool.h"
#include "base/random/pseudo_random.h"
#include "base/strings/string_printf.h"

#include "reco/base/zkconfig/dynamic_dict.h"
#include "reco/base/zkconfig/basic_dicts.h"

namespace reco {
namespace zkconfig {

typedef std::unordered_map<int, double> Map;

class ItemIdLevelDict : public Dict {
 public:
  ItemIdLevelDict() {};
  virtual ~ItemIdLevelDict() {};
  virtual bool ParseFromString(const char* data, int64 size) {
    kv_.clear();
    std::string str(data, size);
    std::vector<std::string> lines;
    std::vector<std::string> flds;
    base::SplitString(str, "\n", &lines);
    for (size_t i = 0; i < lines.size(); ++i) {
      flds.clear();
      base::SplitString(lines[i], "\t", &flds);
      if (flds.size() != 2u) continue;
      uint64 item_id;
      int level;
      if (base::StringToUint64(flds[0], &item_id)
          && base::StringToInt(flds[1], &level)) {
        kv_[item_id] = level;
      }
    }
    return true;
  }

  virtual bool SerializeToString(std::string* data) {
    data->clear();
    for (auto it = kv_.begin(); it != kv_.end(); ++it) {
      data->append(base::Uint64ToString(it->first) + "\t"
                   + base::Int64ToString(it->second) + "\n");
    }
    return true;
  }

  const std::unordered_map<uint64, int>* getDict() const {
    return &kv_;
  }

 private:
  std::unordered_map<uint64, int> kv_;
};

reco::zkconfig::DynamicDict<reco::zkconfig::ItemIdLevelDict> sort_dict;

const std::unordered_map<uint64, int>* GetSortDict() {
  const std::unordered_map<uint64, int>* ptr_dict = sort_dict.GetDict()->getDict();

  if (ptr_dict == NULL) {
    LOG(ERROR) << "iflow item sort dict does not exist.";
    return NULL;
  }

  return ptr_dict;
}

void write_thread() {
  base::PseudoRandom random;

  for (int i = 0; i < 1000; ++i) {
    int lines = 10000;
    std::string content;
    content.reserve(lines * 100);
    for (int i = 0; i < lines; ++i) {
      if (!content.empty()) content.append("\n");
      uint64 id = random.GetUint64LT(1000000);
      content.append(base::StringPrintf("%ld\t1", id));
    }

    boost::shared_ptr<ItemIdLevelDict> shared_pt(new ItemIdLevelDict);
    shared_pt->ParseFromString(content.c_str(), content.size());
    sort_dict.Swap(shared_pt);
    LOG_EVERY_N(INFO, 10) << "dict reload";
  }
}

void read_thread() {
  base::PseudoRandom random;

  for (int i = 0; i < 100000; ++i) {
    const std::unordered_map<uint64, int>* map = GetSortDict();
    uint64 id = random.GetUint64LT(1000000);
    auto it = map->find(id);
    if (it != map->end()) {
      LOG_EVERY_N(INFO, 100000) << it->first;  // no use, just cheet compile
    }
  }
}

void read_thread_safe() {
  base::PseudoRandom random;

  for (int i = 0; i < 100000; ++i) {
    // const std::unordered_map<uint64, int>* map = GetSortDict();
    auto ptr = sort_dict.GetDict();
    uint64 id = random.GetUint64LT(1000000);
    auto it = ptr->getDict()->find(id);
    if (it != ptr->getDict()->end()) {
      LOG_EVERY_N(INFO, 100000) << it->first;  // no use, just cheet compile
    }
  }
}

TEST(DynamicDict, Multithreads) {
  thread::ThreadPool pool(11);
  for (int i = 0; i < 10; ++i) {
    // pool.AddTask(::NewCallback(read_thread));  // core dump
    pool.AddTask(::NewCallback(read_thread_safe));
  }
  pool.AddTask(::NewCallback(write_thread));

  pool.JoinAll();
}

}  // namespace
}  // namespace
