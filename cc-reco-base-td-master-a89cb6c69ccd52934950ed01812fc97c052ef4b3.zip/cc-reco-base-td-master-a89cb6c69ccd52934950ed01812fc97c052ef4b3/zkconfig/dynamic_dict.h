#pragma once
#include <boost/shared_ptr.hpp>

#include "base/common/basic_types.h"
#include "base/thread/sync.h"
#include "base/strings/string_number_conversions.h"

#include "reco/base/zkconfig/basic_dicts.h"

namespace reco {
namespace zkconfig {

/******  动态词典定义   ********/
template <class Dict>
class DynamicDict {
 public:
  // template constructors
  DynamicDict() : dict_(new Dict) {}

  template<typename Arg1>
  explicit DynamicDict(Arg1& arg1);

  ~DynamicDict() {}
 public:
  boost::shared_ptr<const Dict> GetDict(void) const;

  boost::shared_ptr<Dict> GetMutableDict(void);

  void Swap(boost::shared_ptr<Dict>& dict);

  int32 use_count(void) const;
 private:
  boost::shared_ptr<Dict> dict_;
  mutable thread::Mutex access_mutex_;
  DISALLOW_COPY_AND_ASSIGN(DynamicDict<Dict>);
};

template<class Dict>
void DynamicDict<Dict>::Swap(boost::shared_ptr<Dict>& dict) {
  thread::AutoLock lock_access(&access_mutex_);
  dict_.swap(dict);
}

template<class Dict>
boost::shared_ptr<const Dict> DynamicDict<Dict>::GetDict(void) const {
  thread::AutoLock lock_access(&access_mutex_);
  return dict_;
}

template<class Dict>
boost::shared_ptr<Dict> DynamicDict<Dict>::GetMutableDict(void) {
  thread::AutoLock lock_access(&access_mutex_);
  return dict_;
}

template<class Dict>
int32 DynamicDict<Dict>::use_count(void) const {
  thread::AutoLock lock_access(&access_mutex_);
  return dict_.use_count();
}

template<typename Dict>
template<typename Arg1>
DynamicDict<Dict>::DynamicDict(Arg1& arg1)
  : dict_(new Dict(arg1)) {
  }

}  // namespace
}  // namespace
