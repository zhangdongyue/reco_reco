#include "reco/base/zkconfig/cloud_setting.h"

#include "reco/base/zkconfig/conf_dispatcher.h"
#include "reco/base/zkconfig/children_dispatcher.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "serving_base/utility/system_util.h"

namespace reco {
namespace zkconfig {

DEFINE_int32(zk_recv_timeout, 30000, "");

CloudSetting::CloudSetting(const char* zk_sockets, const char* zk_root,
                               const char* hdfs_ip, int hdfs_port) {
  watch_ctx_ = new WatchContext(zk_sockets);
  zk_root_ = zk_root;
  hdfs_host_ = hdfs_ip;
  hdfs_port_ = hdfs_port;

  zookeeper_init(zk_sockets, WatchContext::watcher,
                 FLAGS_zk_recv_timeout, 0, watch_ctx_, 0);
  while (watch_ctx_->get_zhandle() == NULL) {
    LOG(INFO) << "waiting for zookeeper connection, sleep, ip:" << zk_sockets << ", root:" << zk_root;
    base::SleepForSeconds(1);
  }
}

CloudSetting::CloudSetting(const char* zk_sockets, const char* zk_root) {
  watch_ctx_ = new WatchContext(zk_sockets);
  zk_root_ = zk_root;
  hdfs_host_ = "";
  hdfs_port_ = 0;

  zookeeper_init(zk_sockets, WatchContext::watcher,
                 FLAGS_zk_recv_timeout, 0, watch_ctx_, 0);
  while (watch_ctx_->get_zhandle() == NULL) {
    LOG(INFO) << "waiting for zookeeper connection, sleep 1s";
    base::SleepForSeconds(1);
  }
}

CloudSetting::~CloudSetting() {
  delete watch_ctx_;

  // conf map's memory should be free
  for (auto it = setting_map_.begin(); it != setting_map_.end(); ++it) {
    SettingInfo& info = it->second;
    switch (info.type) {
      case 0:
      case 1:
      case 2:
        delete (DynamicDict<StringDict>*)info.dict;
        break;
      case 4:
        delete (DynamicDict<StringVectorDict>*)info.dict;
        break;
      default:
        break;
    }
    delete info.dispatcher;
  }
}

void CloudSetting::AddConfMonitor(const char* conf_name, int type) {
  std::string conf(conf_name);
  std::string zk_node = zk_root_ + "/" + conf;
  LOG(INFO) << "add for node: " << zk_node;

  CHECK(setting_map_.find(conf) == setting_map_.end()) << "already monitor this conf: " << conf_name;
  CHECK(type >= 0 && type <=2) << "invalid type: " << type;

  char buf[1024];
  int buf_len=1024;
  CHECK(ZOK == zoo_get(watch_ctx_->get_zhandle(), zk_node.c_str(), 0, buf, &buf_len, NULL));

  SettingInfo info;
  info.type = type;
  info.dict = new DynamicDict<StringDict>();
  info.dispatcher = new ConfDispatcher(zk_node.c_str(),
                                       reinterpret_cast<DynamicDict<StringDict>*>(info.dict));

  setting_map_[conf] = info;
  watch_ctx_->AddDispatcher(info.dispatcher);

  // construct an event, use dispatcher to load the data
  Event evt;
  evt.path = zk_node;
  evt.type = ZOO_CHANGED_EVENT;
  info.dispatcher->DispatchEvent(evt);

  // CHECK(ZOK == zoo_wget(watch_ctx_->get_zhandle(), zk_node.c_str(),
  //                      WatchContext::watcher, watch_ctx_, buf, &buf_len, NULL));
}

bool CloudSetting::GetConf(const char* conf_name, std::string* s, int64* i, double* d) {
  std::string conf(conf_name);
  auto it = setting_map_.find(conf);
  if (it == setting_map_.end()) return false;

  const SettingInfo& info = it->second;
  std::string val = reinterpret_cast<DynamicDict<StringDict>*>(info.dict)->GetDict()->GetData();
  switch (info.type) {
    case 0:
      *s = val;
      return true;
    case 1:
      return base::StringToInt64(val, i);
    case 2:
      return base::StringToDouble(val, d);
    case 3:
    default:
      LOG(ERROR) << "unknow type: " << info.type;
      return false;
  }
}

void CloudSetting::MonitorChildrenChange(const char* parent_name) {
  std::string parent(parent_name);
  std::string zk_node = zk_root_ + "/" + parent;
  LOG(INFO) << "add for node: " << zk_node;

  CHECK(setting_map_.find(parent) == setting_map_.end()) << "already monitor this conf: " << parent;

  CHECK(ZOK == zoo_exists(watch_ctx_->get_zhandle(), zk_node.c_str(), 0, NULL));

  SettingInfo info;
  info.type = 4;
  info.dict = new DynamicDict<StringVectorDict>();
  info.dispatcher = new ChildrenDispatcher(zk_node.c_str(),
                                       reinterpret_cast<DynamicDict<StringVectorDict>*>(info.dict));

  setting_map_[parent_name] = info;
  watch_ctx_->AddDispatcher(info.dispatcher);

  // construct an event, use dispatcher to load the data
  Event evt;
  evt.path = zk_node;
  evt.type = ZOO_CHANGED_EVENT;
  info.dispatcher->DispatchEvent(evt);
}


bool CloudSetting::RegisterAndMonitorChildrenChange(const char* parent_name, const char* child_name,
                                                    const int retry) {
  std::string parent(parent_name);
  const std::string zk_node = zk_root_ + "/" + parent;

  int op_cnt = 0;
  bool op_ret = false;
  while (op_cnt++ < retry) {
    if (ZOK != zoo_exists(watch_ctx_->get_zhandle(), zk_node.c_str(), 0, NULL)) {
      LOG(INFO) << "not exist " << zk_node << ", will create it";
      if (ZOK != zoo_create(watch_ctx_->get_zhandle(), zk_node.c_str(), "", 0,
                            &ZOO_OPEN_ACL_UNSAFE, 0, 0, 0)) {
        LOG(ERROR) << "fail to create path " << zk_node;
        base::SleepForSeconds(2);
        continue;
      }
      base::SleepForSeconds(2);
    }

    const std::string child_path = zk_node + "/" + child_name;
    if (ZOK != zoo_create(watch_ctx_->get_zhandle(), child_path.c_str(), "", 0,
                          &ZOO_OPEN_ACL_UNSAFE, ZOO_EPHEMERAL, 0, 0)) {
      LOG(ERROR) << "fail to create path " << child_path;
      base::SleepForSeconds(2);
      continue;
    }

    op_ret = true;
    break;
  }

  if (op_ret) {
    MonitorChildrenChange(parent_name);
    LOG(INFO) << "Register succ.";
    return true;
  } else {
    LOG(ERROR) << "Register fail.";
    return false;
  }

  return true;
}

bool CloudSetting::RegisterAndMonitorChildrenChange(const char* parent_name, const int retry) {
  std::string host = serving_base::GetHostName();
  return RegisterAndMonitorChildrenChange(parent_name, host.c_str(), retry);
}


void CloudSetting::GetChildren(const char* parent_name, std::vector<std::string>* children) {
  children->clear();
  auto it = setting_map_.find(parent_name);
  if (it == setting_map_.end()) return;

  const SettingInfo& info = it->second;
  auto dict = reinterpret_cast<DynamicDict<StringVectorDict>*>(info.dict);
  children->assign(dict->GetDict()->GetData().begin(), dict->GetDict()->GetData().end());
}

int CloudSetting::GetChildrenNum(const char* parent_name) {
  auto it = setting_map_.find(parent_name);
  if (it == setting_map_.end()) return 0;
  const SettingInfo& info = it->second;
  auto dict = reinterpret_cast<DynamicDict<StringVectorDict>*>(info.dict);
  return dict->GetDict()->GetData().size();
}

void CloudSetting::GetChildrenNumAndIndex(const char* parent_name, int* children_num, int* index) {
  std::string host = serving_base::GetHostName();
  GetChildrenNumAndIndex(parent_name, host.c_str(), children_num, index);
}

void CloudSetting::GetChildrenNumAndIndex(const char* parent_name, const char* child_name,
                                           int* children_num, int* index) {
  std::vector<std::string> children;
  GetChildren(parent_name, &children);
  *children_num = children.size();
  std::sort(children.begin(), children.end());
  auto it = std::find(children.begin(), children.end(), child_name);
  if (it == children.end()) {
    *index = -1;
  } else {
    *index = it - children.begin();
  }
}
}  // namespace
}  // namespace
