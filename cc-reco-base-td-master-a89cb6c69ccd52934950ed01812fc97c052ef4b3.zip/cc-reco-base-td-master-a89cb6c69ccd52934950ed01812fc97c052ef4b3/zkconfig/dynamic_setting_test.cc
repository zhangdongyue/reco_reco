#include <boost/shared_ptr.hpp>
#include <unordered_map>
#include <vector>
#include <map>

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/common/logging.h"
#include "base/thread/thread_pool.h"
#include "base/random/pseudo_random.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"
#include "base/hdfs/hdfs_file_util.h"
#include "base/hdfs/hdfs_file_stream.h"
#include "base/hdfs/hdfs_handle.h"
#include "base/file/scoped_temp_dir.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"

#include "reco/zkconfig/dynamic_setting.h"
#include "reco/zkconfig/dynamic_dict.h"
#include "reco/zkconfig/basic_dicts.h"
#include "reco/zkconfig/watch_context.h"

namespace reco {
namespace zkconfig {

// DEFINE_string(zk_hosts, "10.3.5.55:2181", "zookeeper hosts");
// DEFINE_string(zk_path_root, "/test", "root");
// 
// DEFINE_string(hdfs_host, "10.3.5.72", "hdfs ip");
// DEFINE_int32(hdfs_port, 9000, "hdfs port");
DECLARE_string(zk_hosts);
DECLARE_string(zk_path_root);

DECLARE_string(hdfs_host);
DECLARE_int32(hdfs_port);

static std::string get_conf_name(std::string prefix, int type) {
  return prefix + base::IntToString(type);
}

static std::string get_node_name(std::string prefix, int type) {
  return FLAGS_zk_path_root + "/" + get_conf_name(prefix, type);
}

static thread::Mutex g_mutex;
static  std::string put_dict_to_hdfs(std::string key, std::string value) {
  thread::AutoLock lock(&g_mutex);
  KeyValueDict dict;
  dict.set(key, value);
  std::string data;
  dict.SerializeToString(&data);
  // generate a hdfs temp dir
  base::FilePath hdfs_temp_dir;
  base::ScopedTempDir tmp;
  CHECK(tmp.CreateUniqueTempDir());
  base::FilePath root(std::string("/tmp/"));
  hdfs_temp_dir = root.Append(tmp.path().BaseName());
  if (!hadoop::HDFSMkdir(hdfs_temp_dir.ToString().c_str())) {
    LOG(ERROR) << "failed to create hdfs dir";
    return "";
  }

  base::FilePath hdfs_file_path = hdfs_temp_dir.AppendASCII("a");
  hadoop::HDFSFileStream file(FLAGS_hdfs_host.c_str(), FLAGS_hdfs_port);
  if (!file.Open(hdfs_file_path.ToString().c_str(), O_WRONLY)) {
    LOG(ERROR) << "open hdfs file failed";
    return "";
  }

  if (file.Write(data.c_str(), data.size()) != (int)data.size()) {
    LOG(ERROR) << "write hdfs file failed";
    return "";
  }

  if (!file.Flush()) {
    LOG(ERROR) << "write hdfs file failed";
    return "";
  }

  if (!file.Close()) {
    LOG(ERROR) << "write hdfs file failed";
    return "";
  }

  return hdfs_file_path.ToString();
}

class DynamicSettingTest : public testing::Test {
 public:
  virtual void SetUp() {
    setting = new DynamicSetting(FLAGS_zk_hosts.c_str(),
                                 FLAGS_zk_path_root.c_str(),
                                 FLAGS_hdfs_host.c_str(),
                                 FLAGS_hdfs_port);

    zh = setting->watch_ctx_->get_zhandle();

    char path[512];
    int ret = zoo_create(zh, FLAGS_zk_path_root.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
    CHECK(ret == ZOK || ret == ZNODEEXISTS);

    LOG(INFO) << "start up";
  }

  virtual void TearDown() {
    delete setting;
    LOG(INFO) << "tear down";
  }

  base::PseudoRandom random;
  DynamicSetting* setting;
  zhandle_t* zh;
};

TEST_F(DynamicSettingTest, SingleThread) {
  std::map<std::string, DynamicDict<KeyValueDict>*> dict_map;
  std::vector<std::string> conf_prefix;
  for (int i = 0; i < 10; ++i) {
    std::string prefix = "setting_" + base::IntToString(i);
    conf_prefix.push_back(prefix);
    std::string zk_node;
    std::string conf_name;

    // set string conf value
    std::string s = random.GetString(10);
    zk_node = get_node_name(prefix, 0);
    conf_name = get_conf_name(prefix, 0);

    char path[512];
    int ret = zoo_create(zh, zk_node.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
    CHECK(ret == ZOK || ret == ZNODEEXISTS);

    ret = zoo_set(zh, zk_node.c_str(), s.c_str(), s.size(), -1);
    ASSERT_EQ(ZOK, ret) << zerror(ret);
    setting->MonitorStringConfChange(conf_name.c_str());
    std::string ts;
    ASSERT_TRUE(setting->GetStringConf(conf_name.c_str(), &ts));
    ASSERT_EQ(ts, s);

    // set int64 conf value
    int64 l = random.GetInt(1, 10000);
    s = base::Int64ToString(l);
    zk_node = get_node_name(prefix, 1);
    conf_name = get_conf_name(prefix, 1);

    ret = zoo_create(zh, zk_node.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
    CHECK(ret == ZOK || ret == ZNODEEXISTS);

    ret = zoo_set(zh, zk_node.c_str(), s.c_str(), s.size(), -1);
    ASSERT_EQ(ZOK, ret) << zerror(ret);
    setting->MonitorInt64ConfChange(conf_name.c_str());
    int64 tl;
    ASSERT_TRUE(setting->GetInt64Conf(conf_name.c_str(), &tl));
    ASSERT_EQ(tl, l);

    // set double conf value
    double d = random.GetDouble();
    s = base::DoubleToString(d);
    zk_node = get_node_name(prefix, 2);
    conf_name = get_conf_name(prefix, 2);

    ret = zoo_create(zh, zk_node.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
    CHECK(ret == ZOK || ret == ZNODEEXISTS);

    ret = zoo_set(zh, zk_node.c_str(), s.c_str(), s.size(), -1);
    ASSERT_EQ(ZOK, ret) << zerror(ret);
    setting->MonitorDoubleConfChange(conf_name.c_str());
    double td;
    ASSERT_TRUE(setting->GetDoubleConf(conf_name.c_str(), &td));
    ASSERT_EQ(td, d);

    // set dict
    std::string key = base::IntToString(random.GetInt(1, 10000));
    std::string value = base::IntToString(random.GetInt(1, 100000));
    s = put_dict_to_hdfs(key, value);
    zk_node = get_node_name(prefix, 3);
    conf_name = get_conf_name(prefix, 3);
    DynamicDict<KeyValueDict>* dic = new DynamicDict<KeyValueDict>();
    dict_map[conf_name] = dic;

    ret = zoo_create(zh, zk_node.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
    CHECK(ret == ZOK || ret == ZNODEEXISTS);

    ret = zoo_set(zh, zk_node.c_str(), s.c_str(), s.size(), -1);
    ASSERT_EQ(ZOK, ret) << zerror(ret);
    setting->MonitorDictChange<KeyValueDict>(conf_name.c_str(), dic);
    ASSERT_EQ(dic->GetDict()->get(key), value);
  }

  for (auto it = dict_map.begin(); it != dict_map.end(); ++it) {
    delete it->second;
  }
}

static void set_zk_thread(int thread_id, zhandle_t* zh,
                          DynamicSetting* setting,
                          DynamicDict<KeyValueDict>* dic) {
  base::PseudoRandom random;
  int ret;

  std::string prefix = "setting_" + base::IntToString(thread_id);
  std::string zk_node;
  std::string conf_name;

  LOG(INFO) << "thread: " << thread_id << " starts";

  for (int loop = 0; loop < 5; ++loop) {
    // // set string conf value
    std::string s = base::IntToString(random.GetInt(1, 10000));
    zk_node = get_node_name(prefix, 0);
    conf_name = get_conf_name(prefix, 0);

    ret = zoo_set(zh, zk_node.c_str(), s.c_str(), s.size(), -1);
    CHECK(ZOK == ret) << zerror(ret);
    std::string ts;
    while (ts != s) {
      CHECK(setting->GetStringConf(conf_name.c_str(), &ts));
      if (ts == s) break;
      base::SleepForMilliseconds(10);
      LOG_EVERY_N(INFO, 1000) << base::StringPrintf("tid[%d], node[%s], conf[%s], get[%s]",
                                                   thread_id, zk_node.c_str(), s.c_str(), ts.c_str());
    }
    EXPECT_EQ(ts, s);

    // set int64 conf value
    int64 l = random.GetInt(1, 10000);
    s = base::Int64ToString(l);
    zk_node = get_node_name(prefix, 1);
    conf_name = get_conf_name(prefix, 1);

    ret = zoo_set(zh, zk_node.c_str(), s.c_str(), s.size(), -1);
    CHECK(ZOK == ret) << zerror(ret);
    int64 tl;
    while (tl != l) {
      CHECK(setting->GetInt64Conf(conf_name.c_str(), &tl));
      base::SleepForMilliseconds(10);
      LOG_EVERY_N(INFO, 1000) << base::StringPrintf("tid[%d], node[%s], conf[%ld], get[%ld]",
                                                   thread_id, zk_node.c_str(), l, tl);
    }
    EXPECT_EQ(tl, l);

    // set double conf value
    double d = int(random.GetDouble() * 10000) / 10000.0;
    s = base::DoubleToString(d);
    zk_node = get_node_name(prefix, 2);
    conf_name = get_conf_name(prefix, 2);

    ret = zoo_set(zh, zk_node.c_str(), s.c_str(), s.size(), -1);
    CHECK(ZOK == ret) << zerror(ret);
    double td;
    while (td != d) {
      CHECK(setting->GetDoubleConf(conf_name.c_str(), &td));
      base::SleepForMilliseconds(10);
      LOG_EVERY_N(INFO, 1000) << base::StringPrintf("tid[%d], node[%s], conf[%f]",
                                                   thread_id, zk_node.c_str(), d);
    }
    EXPECT_EQ(td, d);

    // set dict
    std::string key = base::IntToString(random.GetInt(1, 10000));
    std::string value = base::IntToString(random.GetInt(1, 100000));
    // hdfs may be error, skip the test
    s = put_dict_to_hdfs(key, value);
    if (s.empty()) continue;
    zk_node = get_node_name(prefix, 3);
    conf_name = get_conf_name(prefix, 3);

    ret = zoo_set(zh, zk_node.c_str(), s.c_str(), s.size(), -1);
    CHECK(ZOK == ret) << zerror(ret);
    int total = 0;
    while (dic->GetDict()->get(key) != value) {
      base::SleepForMilliseconds(10);
      ++total;
      if (total > 1000) break;
    }
    EXPECT_EQ(dic->GetDict()->get(key), value);
  }

  LOG(INFO) << "thread: " << thread_id << " finished";
}

TEST_F(DynamicSettingTest, MultiThread) {
  int thread_num = 3;
  std::map<std::string, DynamicDict<KeyValueDict>*> dict_map;

  thread::ThreadPool pool(thread_num);
  for (int i = 0; i < thread_num; ++i) {
    char path[512];

    std::string prefix = "setting_" + base::IntToString(i);
    std::string zk_node;
    std::string conf_name;

    zk_node = get_node_name(prefix, 0);
    conf_name = get_conf_name(prefix, 0);
    int ret = zoo_create(zh, zk_node.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
    CHECK(ret == ZOK || ret == ZNODEEXISTS);
    setting->MonitorStringConfChange(conf_name.c_str());

    zk_node = get_node_name(prefix, 1);
    conf_name = get_conf_name(prefix, 1);
    ret = zoo_create(zh, zk_node.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
    CHECK(ret == ZOK || ret == ZNODEEXISTS);
    setting->MonitorInt64ConfChange(conf_name.c_str());

    zk_node = get_node_name(prefix, 2);
    conf_name = get_conf_name(prefix, 2);
    ret = zoo_create(zh, zk_node.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
    CHECK(ret == ZOK || ret == ZNODEEXISTS);
    setting->MonitorDoubleConfChange(conf_name.c_str());

    zk_node = get_node_name(prefix, 3);
    conf_name = get_conf_name(prefix, 3);
    DynamicDict<KeyValueDict>* dic = new DynamicDict<KeyValueDict>();
    dict_map[conf_name] = dic;

    ret = zoo_create(zh, zk_node.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
    CHECK(ret == ZOK || ret == ZNODEEXISTS);
    setting->MonitorDictChange<KeyValueDict>(conf_name.c_str(), dic);

    pool.AddTask(::NewCallback(set_zk_thread, i, zh, setting, dic));
  }

  pool.JoinAll();
  for (auto it = dict_map.begin(); it != dict_map.end(); ++it) {
    delete it->second;
  }
}

}  // namespace
}  // namespace
