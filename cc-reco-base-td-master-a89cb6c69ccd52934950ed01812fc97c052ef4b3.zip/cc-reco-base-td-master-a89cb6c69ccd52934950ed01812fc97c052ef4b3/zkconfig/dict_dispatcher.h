#pragma once
#include <boost/shared_ptr.hpp>
#include <list>

#include "base/common/basic_types.h"
#include "base/thread/sync.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "reco/base/zkconfig/dynamic_dict.h"
#include "reco/base/zkconfig/watch_context.h"

#include "third_party/zookeeper/include/zookeeper.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/strings/string_util.h"
#include "reco/base/hdfs/hdfs_file_stream.h"
#include "reco/base/hdfs/hdfs_file_util.h"

namespace reco {
namespace zkconfig {

template <class Dict>
class DictDispatcher : public EventDispatcher {
 public:
  DictDispatcher(const char* node, DynamicDict<Dict>* dict,
                 const char* hdfs_host, int hdfs_port) ;
  virtual ~DictDispatcher() {};
  virtual void DispatchEvent(Event evt);

 private:
  std::string node_;
  const char* hdfs_host_;
  int hdfs_port_;

  DynamicDict<Dict>* dict_;
};

template <class Dict>
DictDispatcher<Dict>::DictDispatcher(const char* zk_node_path, DynamicDict<Dict>* dict,
                          const char* hdfs_host, int hdfs_port) {
  node_ = zk_node_path;
  dict_ = dict;
  hdfs_host_ = hdfs_host;
  hdfs_port_ = hdfs_port;
}

template <class Dict>
void DictDispatcher<Dict>::DispatchEvent(Event evt) {
  // LOG(INFO) << evt.path << ":" << evt.type;
  if (!base::LowerCaseEquals(evt.path, node_.c_str())) {
    // VLOG(1) << "skip this path: " << evt.path << ":" << node_;
    return;
  }

  WatchContext* ctx = (WatchContext*) get_context();
  CHECK_NOTNULL(ctx);
  char buf[10240];
  int buf_len = 10240;
  if (ZOK == zoo_wget(ctx->get_zhandle(), node_.c_str(), WatchContext::watcher, ctx, buf, &buf_len, NULL)) {
    if (buf_len == -1 || buf_len >= 10240) {
      LOG(ERROR) << "read data error";
      return;
    }
    buf[buf_len] ='\0';
    LOG(INFO) << "read node value: " << buf;

    std::vector<std::string> hdfs_paths;
    int dir_type = hdfs::HDFSIsDirectory(buf, hdfs_host_, hdfs_port_);
    if (dir_type == 0) {
      LOG(INFO) << "hdfs path is a file: " << buf;
      hdfs_paths.push_back(buf);
    } else if (dir_type == 1) {
      LOG(INFO) << "hdfs path is a dir: " << buf;
      std::vector<hdfs::HDFSPathInfo> dir_infos;
      if (!hdfs::HDFSListDirectory(buf, &dir_infos, hdfs_host_, hdfs_port_)) {
        LOG(ERROR) << "list hdfs dir fail: " << buf;
        return;
      }
      for (int i = 0; i < (int)dir_infos.size(); ++i) {
        if (dir_infos[i].type == hdfs::kFile && dir_infos[i].size_in_bytes > 0) {
          hdfs_paths.push_back(dir_infos[i].name);
        }
      }
    } else {
      LOG(ERROR) << "hdfs path error: " << buf;
      return;
    }

    std::string content_read;
    hdfs::HDFSFileStream file(hdfs_host_, hdfs_port_);
    for (int i = 0; i < (int)hdfs_paths.size(); ++i) {
      if (!file.Open(hdfs_paths[i].c_str(), O_RDONLY)) {
        LOG(ERROR) << "failed to open hdfs file: " << hdfs_paths[i];
        return;
      }

      int readed = 0;
      while ((readed = file.Read(buf, 10240)) > 0) {
        content_read.append(buf, readed);
      }

      file.Close();
      LOG(INFO) << "read hdfs file success: " << hdfs_paths[i];
    }
    LOG(INFO) << "read hdfs dict file done, totol size: " << content_read.size();

    boost::shared_ptr<Dict> shared_pt(new Dict);
    shared_pt->ParseFromString(content_read.c_str(), content_read.size());
    dict_->Swap(shared_pt);
  } else {
    LOG(ERROR) << "failed to get zk: " << evt.path;
  }

  return;
}

}  // namespace
}  // namespace
