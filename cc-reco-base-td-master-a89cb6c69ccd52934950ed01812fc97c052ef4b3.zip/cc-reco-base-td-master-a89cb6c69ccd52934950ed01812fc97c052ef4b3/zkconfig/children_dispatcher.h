#pragma once
#include <boost/shared_ptr.hpp>
#include <list>

#include "base/common/basic_types.h"
#include "base/thread/sync.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "reco/base/zkconfig/dynamic_dict.h"
#include "reco/base/zkconfig/watch_context.h"

#include "third_party/zookeeper/include/zookeeper.h"

namespace reco {
namespace zkconfig {

class ChildrenDispatcher : public EventDispatcher {
 public:
  explicit ChildrenDispatcher(const char* path, DynamicDict<StringVectorDict>* dict) {
    path_ = path;
    dict_ = dict;
  }

  virtual ~ChildrenDispatcher() {
  }

  virtual void DispatchEvent(Event evt);

 private:
  std::string path_;
  DynamicDict<StringVectorDict>* dict_;
};

void ChildrenDispatcher::DispatchEvent(Event evt) {
  //LOG(INFO) << evt.path << ":" << evt.type;
  if (!base::LowerCaseEquals(evt.path, path_.c_str())) {
    //LOG(INFO) << "skip this path: " << evt.path << " .vs. " << path_;
    return;
  }

  WatchContext* ctx = (WatchContext*) get_context();
  if (ctx == NULL) {
    LOG(ERROR) << "zk ctx is null";
    return;
  }

  String_vector strings;
  if (ZOK == zoo_wget_children(ctx->get_zhandle(), path_.c_str(), WatchContext::watcher,
                               ctx, &strings)) {
    boost::shared_ptr<StringVectorDict> shared_pt(new StringVectorDict());
    std::string buf;
    for (int i = 0; i < strings.count; ++i) {
      if (!buf.empty()) buf.append("\t");
      buf += strings.data[i];
    }
    shared_pt->ParseFromString(buf.c_str(), buf.size());
    dict_->Swap(shared_pt);
    deallocate_String_vector(&strings);
  } else {
    LOG(ERROR) << "failed to get zk: " << evt.path;
  }

  return;
}

}  // namespace
}  // namespace
