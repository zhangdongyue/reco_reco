#pragma once
#include <boost/shared_ptr.hpp>
#include <unordered_map>

#include "base/common/basic_types.h"
#include "base/testing/gtest_prod.h"
#include "base/thread/sync.h"
#include "base/strings/string_number_conversions.h"
#include "third_party/zookeeper/include/zookeeper.h"

#include "reco/base/zkconfig/basic_dicts.h"
#include "reco/base/zkconfig/dynamic_dict.h"
#include "reco/base/zkconfig/watch_context.h"
#include "reco/base/zkconfig/dict_dispatcher.h"
#include "reco/base/zkconfig/conf_dispatcher.h"

namespace reco {
namespace zkconfig {

/**
 * 动态配置和词典管理
 *
 * 使用方法：
    setting = new CloudSetting(FLAGS_zk_hosts.c_str(),
                                 FLAGS_zk_path_root.c_str(),
                                 FLAGS_hdfs_host.c_str(),
                                 FLAGS_hdfs_port);
    // 监听配置
    setting->MonitorStringConfChange(conf_name.c_str());
    setting->MonitorInt64ConfChange(conf_name.c_str());
    setting->MonitorDoubleConfChange(conf_name.c_str());

    // 监听词典
    CloudDict<KeyValueDict>* dic = new CloudDict<KeyValueDict>();
    setting->MonitorDictChange<KeyValueDict>(conf_name.c_str(), dic);

    // 监听子列表
    // 只监听子列表变化
    setting->MonitorChildrenChange(zk_parent_path);
    // 把自己加入子列表(以hostname)，并监听列表变化
    setting->RegisterAndMonitorChildrenChange(zk_parent_path);

NOTE:

1. 内部会维护一个配置名到配置设置的映射，
   由于此映射在 server 的典型应用场景都是只读的，因此未加锁。
   需要调用方保证在 CloudSetting 构造后就调用 MonitorXXXChange 方法
   在运行过程中不应该再调用 MonitorXXXChange 方法
2. 自定义字典需要基于 Dict 派生 "reco/zkconfig/basic_dicts.h"
   该文件定义了三种基础 Dict： StringDict, KeyValueDict, KeyDict
 
 *
 *
 *
 */

class CloudSetting {
 public:
  // zk_sockets: zookeeper 地址, 如 "10.3.5.55:2181"
  // zk_root: zookeeper 配置根路径, 如 "/leaf_server",需要事先建好
  // hdfs_ip, hdfs_port: hadoop fs 地址，内网是 10.3.5.72, 9000
  CloudSetting(const char* zk_sockets, const char* zk_root, const char* hdfs_ip, int hdfs_port);

  // 不用到 词典 功能时，使用此构造函数
  CloudSetting(const char* zk_sockets, const char* zk_root);
  ~CloudSetting();

  /**
   * 监听配置变化。 支持三种配置类型. 
   * 内部会维持一个配置名到具体值的映射，该映射多线程不安全
   */
  void MonitorStringConfChange(const char* conf_name) {
    AddConfMonitor(conf_name, 0);
  }
  void MonitorInt64ConfChange(const char* conf_name) {
    AddConfMonitor(conf_name, 1);
  }
  void MonitorDoubleConfChange(const char* conf_name) {
    AddConfMonitor(conf_name, 2);
  }

  /** 监听词典变化
   *
   * 动态词典由外部传入，类里面会对词典进行修改
   * 对于词典， 没有 Get 方法，外部直接调用 DynamicDict 相关 api 获取词典内容
   *
   */
  template <class T>
  void MonitorDictChange(const char* dict_name, DynamicDict<T>* dict) {
    AddDictMonitor<T>(dict_name, dict);
  }

  bool GetStringConf(const char* conf_name, std::string* conf ) WARN_UNUSED_RESULT {
    return GetConf(conf_name, conf, NULL, NULL);
  }

  bool GetInt64Conf(const char* conf_name, int64* conf) WARN_UNUSED_RESULT {
    return GetConf(conf_name, NULL, conf, NULL);
  };

  bool GetDoubleConf(const char* conf_name, double* conf) WARN_UNUSED_RESULT {
    return GetConf(conf_name, NULL, NULL, conf);
  }

  /** 监听子列表
   *
   *  可以仅监听子列表变化，也可以将自己（以hostname）加入子列表，并监听
   *  被监听的子列表的父节点，存在 zookeeper 上的 zk_root 下面，没有则建立一个
   * */
  // 只监听子列表变化
  void MonitorChildrenChange(const char* parent_name);

  // 把自己加入子列表(以hostname)，并监听列表变化
  bool RegisterAndMonitorChildrenChange(const char* parent_name, const int retry = 1);

  // 把自己加入子列表，并监听列表变化
  bool RegisterAndMonitorChildrenChange(const char* parent_name, const char* child_name, const int retry = 1);

  // 获取儿子节点列表
  void GetChildren(const char* parent_name, std::vector<std::string>* children);
  int GetChildrenNum(const char* parent_name);
  // 返回总的子节点个数，和本机在列表中的位置（如果不在列表中，返回 -1)
  void GetChildrenNumAndIndex(const char* parent_name, int* children_num, int* index);
  void GetChildrenNumAndIndex(const char* parent_name, const char* child_name, int* children_num, int* index);

 private:
  friend class CloudSettingTest;
  struct SettingInfo {
    // type: 0 - string,  1 - int64,  2 - double, 3 - dict, 4 - children
    int type;
    void* dict;
    EventDispatcher* dispatcher;
  };

  void AddConfMonitor(const char* conf_name, int type);

  template <class T>
  void AddDictMonitor(const char* conf_name, DynamicDict<T>* dict);

  bool GetConf(const char* conf_name, std::string* str, int64* i, double* d);

  WatchContext* watch_ctx_;

  //thread::Mutext mutex_;

  std::unordered_map<std::string, SettingInfo> setting_map_;

  std::string zk_root_;
  std::string hdfs_host_;
  int hdfs_port_;
  DISALLOW_COPY_AND_ASSIGN(CloudSetting);
};

template <class T>
void CloudSetting::AddDictMonitor(const char* conf_name, DynamicDict<T>* dict) {
  std::string conf(conf_name);
  std::string zk_node = zk_root_ + "/" + conf;

  CHECK(setting_map_.find(conf) == setting_map_.end()) << "already monitor this conf: " << conf_name;

  char buf[1024];
  int buf_len=1024;
  CHECK(ZOK == zoo_wget(watch_ctx_->get_zhandle(), zk_node.c_str(),
                        WatchContext::watcher, watch_ctx_, buf, &buf_len, NULL));

  SettingInfo info;
  info.type = 3;
  info.dict = dict;
  info.dispatcher = new DictDispatcher<T>(zk_node.c_str(),
                                          reinterpret_cast<DynamicDict<T>*>(info.dict),
                                          hdfs_host_.c_str(), hdfs_port_);
  
  setting_map_[conf] = info;
  watch_ctx_->AddDispatcher(info.dispatcher);

  // construct an event, use dispatcher to load the data
  Event evt;
  evt.path = zk_node;
  evt.type = ZOO_CHANGED_EVENT;
  info.dispatcher->DispatchEvent(evt);
}

}  // namespace
}  // namespace
