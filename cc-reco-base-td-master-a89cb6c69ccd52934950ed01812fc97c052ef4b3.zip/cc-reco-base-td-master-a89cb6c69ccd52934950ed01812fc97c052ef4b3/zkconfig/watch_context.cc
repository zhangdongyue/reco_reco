#include "reco/base/zkconfig/watch_context.h"

#include "reco/base/zkconfig/watch_context.h"
#include "reco/base/zkconfig/dynamic_dict.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"

namespace reco {
namespace zkconfig {

void WatchContext::watcher(zhandle_t *zzh, int type, int state, const char *path, void* context) {

  if (path && strlen(path) > 0) {
    LOG(INFO) << "Watcher type=" << type << " state = " << state << " for path: " << path;
  } else {
    LOG(INFO) << "Watcher type=" << type << " state = " << state;
  }

  // 出现过 context 为 NULL 的情况
  if (context == NULL) {
    LOG(ERROR) << "zk ctx is null";
    return;
  }

  WatchContext *ctx = (WatchContext*) context;
  if (state == ZOO_CONNECTED_STATE) {
    ctx->connected_ = true;
  } else {
    ctx->connected_ = false;
  }

  if (type != ZOO_SESSION_EVENT) {
    Event evt;
    evt.path = path;
    evt.type = type;
    LOG(INFO) << evt.path << ":" << evt.type;
    ctx->PutEvent(evt);
  } else {
    if (state == ZOO_CONNECTED_STATE) {
      LOG(INFO) << "zookeeper connected!";
      ctx->zh_ = zzh;
    } else if (state == ZOO_AUTH_FAILED_STATE) {
      LOG(INFO) << "Authentication failure. Shutting down...";
      zookeeper_close(zzh);
      ctx->zh_ = NULL;
    } else if (state == ZOO_EXPIRED_SESSION_STATE) {
      LOG(INFO) << "Session expired. Shutting down...";
      zookeeper_close(zzh);
      ctx->zh_ = NULL;
      zookeeper_init(ctx->hosts_, watcher, 30000, 0, ctx, 0);
    } else {
      LOG(INFO) << "session state: " << state;
    }
  }
}


WatchContext::WatchContext(const char* hosts) {
  connected_ = false;
  hosts_ = hosts;
  zh_ = NULL;
  events_ = new thread::BlockingQueue<Event>();

  thread_.Start(::NewCallback(this, &WatchContext::DispatchEventLoop));
}

WatchContext::WatchContext(const char* hosts,
                           std::list<EventDispatcher*> dispatchers) {
  connected_ = false;
  hosts_ = hosts;
  zh_ = NULL;
  events_ = new thread::BlockingQueue<Event>();

  dispatchers_ = dispatchers;
  for (auto it = dispatchers_.begin(); it != dispatchers_.end(); ++it) {
    AddDispatcher(*it);
  }

  thread_.Start(::NewCallback(this, &WatchContext::DispatchEventLoop));
}

WatchContext::~WatchContext() {
  events_->Close();
  thread_.Join();

  // wait for event to finish
  while (!events_->Empty()) {
    base::SleepForSeconds(1);
  }

  if (zh_ != NULL) {
    zookeeper_close(zh_);
    zh_ = NULL;
  }

  delete events_;
}

void WatchContext::AddDispatcher(EventDispatcher* dispatcher) {
  CHECK_NOTNULL(dispatcher);
  dispatcher->set_context(this);

  thread::AutoLock lock(&mutex_);
  dispatchers_.push_back(dispatcher);
}

void WatchContext::RemoveDispatcher(EventDispatcher* dispatcher) {
  CHECK_NOTNULL(dispatcher);
  thread::AutoLock lock(&mutex_);
  auto it = std::remove(dispatchers_.begin(), dispatchers_.end(), dispatcher);
  dispatchers_.erase(it, dispatchers_.end());
  dispatcher->set_context(NULL);
}

void WatchContext::DispatchEventLoop() {
  while (!events_->Closed() || !events_->Empty()) {
    Event evt;
    if (!events_->Take(&evt)) {
      continue;
    }

    LOG(INFO) << "dispatch loop catch an event, queue remains " << events_->Size() << " events";

    // during dispatchers doing there work, the list should not be changed
    thread::AutoLock lock(&mutex_);
    for (auto it = dispatchers_.begin(); it != dispatchers_.end(); ++it) {
      if (*it == NULL) {
        LOG(ERROR) << "dispatcher is null";
        continue;
      }

      (*it)->DispatchEvent(evt);
    }
  }

  LOG(INFO) << "watch loop finished";
}

}  // namespace
}  // namespace
