#include <boost/shared_ptr.hpp>
#include <unordered_map>
#include <vector>

#include "base/common/basic_types.h"
#include "base/common/closure.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/time/time.h"
#include "base/time/timestamp.h"
#include "base/common/logging.h"
#include "base/thread/thread_pool.h"
#include "base/random/pseudo_random.h"
#include "base/strings/string_split.h"
#include "base/file/scoped_temp_dir.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"

#include "reco/base/hdfs/hdfs_file_util.h"
#include "reco/base/hdfs/hdfs_file_stream.h"
#include "reco/base/hdfs/hdfs_handle.h"
#include "reco/base/zkconfig/watch_context.h"
#include "reco/base/zkconfig/dynamic_dict.h"
#include "reco/base/zkconfig/conf_dispatcher.h"
#include "reco/base/zkconfig/dict_dispatcher.h"

namespace reco {
namespace zkconfig {

DEFINE_string(zk_hosts, "100.85.69.55:2181", "zookeeper hosts");
DEFINE_string(zk_path_root, "/test", "root");

DEFINE_string(hdfs_host, "100.85.69.72", "hdfs ip");
DEFINE_int32(hdfs_port, 9000, "hdfs port");

void test_data_completion(int rc, const char *value, int value_len,
                     const struct Stat *stat, const void *data) {
}

void test_stat_completion(int rc, const struct Stat *stat,
        const void *data) {
}

class WatchContextTest : public testing::Test {
 public:
  virtual void SetUp() {
    context = new WatchContext(FLAGS_zk_hosts.c_str());

    // start zk connects and add watcher
    zookeeper_init(FLAGS_zk_hosts.c_str(), WatchContext::watcher, 30000, 0, context, 0);

    // wait for zk connected
    while (context->get_zhandle() == NULL) {
      base::SleepForSeconds(1);
    }

    // use the handle to do some prepare work, do not close zh in this, context will do
    zh = context->get_zhandle();

    // create root node
    int ret = zoo_exists(zh, FLAGS_zk_path_root.c_str(), 0, NULL);
    if (ZOK == ret) {
      LOG(INFO) << "test path root exists: " << FLAGS_zk_path_root;
    } else if (ZNONODE == ret) {
      LOG(INFO) << "test path root not exists: " << FLAGS_zk_path_root << ", create one";
      char path[512];
      ret = zoo_create(zh, FLAGS_zk_path_root.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
      CHECK_EQ(ret, ZOK) << ret;
    } else {
      CHECK(false) << ret;
    }

    LOG(INFO) << "start up";
  }

  virtual void TearDown() {
    delete context;
    LOG(INFO) << "tear down";
  }

  base::PseudoRandom random;
  WatchContext* context;
  zhandle_t* zh;
};

TEST_F(WatchContextTest, SingleConfSingleThread) {
  DynamicDict<StringDict> dict;
  std::string node = FLAGS_zk_path_root + "/test1";

  ConfDispatcher conf_dispatcher(node.c_str(), &dict);
  context->AddDispatcher(&conf_dispatcher);

  char path[512];
  // create test node
  int ret = zoo_create(zh, node.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
  ASSERT_TRUE(ret == ZOK || ret == ZNODEEXISTS);

  // register watcher to this node
  zoo_awget(zh, node.c_str(), WatchContext::watcher, context, test_data_completion, NULL);

  // change value once
  std::string value = base::IntToString(random.GetInt(0, 10000000));
  zoo_aset(zh, node.c_str(), value.c_str(), value.size(), -1, test_stat_completion, NULL);
  base::SleepForSeconds(3);
  ASSERT_STREQ(dict.GetDict()->GetData().c_str(), value.c_str());

  // change again
  value = base::IntToString(random.GetInt(0, 10000000));
  zoo_aset(zh, node.c_str(), value.c_str(), value.size(), -1, test_stat_completion, NULL);
  base::SleepForSeconds(3);
  ASSERT_STREQ(dict.GetDict()->GetData().c_str(), value.c_str());

  // clean
  ret = zoo_delete(zh, node.c_str(), -1);
  ASSERT_TRUE(ret == ZOK);

  context->RemoveDispatcher(&conf_dispatcher);
}

static void set_zk_thread(int thread_id, int thread_num,
                   zhandle_t* zh, std::string* node, std::vector<int>* values) {
  LOG(INFO) << "thread runs, id: " << thread_id;
  for (size_t i = thread_id; i < values->size(); i += thread_num) {
    std::string value = base::IntToString(values->at(i));
    //    zoo_aset(zh, node->c_str(), value.c_str(), value.size(), -1, test_stat_completion, NULL);
    zoo_set(zh, node->c_str(), value.c_str(), value.size(), -1);
    LOG_EVERY_N(INFO, 50) << "thread " << thread_id << " set path " << *node << " to " << value;
  }
}

TEST_F(WatchContextTest, SingleConfMultiThread) {
  DynamicDict<StringDict> dict;
  std::string node = FLAGS_zk_path_root + "/test2";

  ConfDispatcher conf_dispatcher(node.c_str(), &dict);
  context->AddDispatcher(&conf_dispatcher);

  char path[512];
  // create test node
  int ret = zoo_create(zh, node.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
  ASSERT_TRUE(ret == ZOK || ret == ZNODEEXISTS);

  // watch the node
  zoo_awget(zh, node.c_str(), WatchContext::watcher, context, test_data_completion, NULL);

  base::PseudoRandom random(base::GetTimestamp());
  std::vector<int> values(2000);
  for (size_t i = 0; i < values.size(); ++i) {
    values[i] = random.GetInt(0, 10000000);
  }

  int thread_num = 10;
  thread::ThreadPool pool(thread_num);
  for (int i = 0; i < thread_num; ++i) {
    pool.AddTask(::NewCallback(set_zk_thread, i, thread_num, zh, &node, &values));
  }

  // in main thread, just read the dict values, check if it is in reasonable range
  std::set<int> unique_value;
  for (size_t i = 0; i < values.size(); ++i) {
    std::string str = dict.GetDict()->GetData();
    if (str.empty()) {
      LOG(INFO) << "value not set, sleep for 1s";
      base::SleepForSeconds(1);
      continue;
    }
    int val = base::ParseInt32OrDie(str);
    ASSERT_TRUE(val >= 0 && val < 10000000);
    unique_value.insert(val);
    base::SleepForMilliseconds(10);
  }

  pool.JoinAll();

  LOG(INFO) << "found dict value changes: " << unique_value.size();
  ASSERT_GT(unique_value.size(), 1u);

  context->RemoveDispatcher(&conf_dispatcher);
}

class TestDict : public Dict {
 public:
  TestDict() {};
  virtual ~TestDict() {}
  virtual bool ParseFromString(const char* data, int64 size) {
    kv_.clear();
    std::string str(data, size);
    std::vector<std::string> lines;
    std::vector<std::string> flds;
    base::SplitString(str, "\n", &lines);
    for (size_t i = 0; i < lines.size(); ++i) {
      flds.clear();
      base::SplitString(lines[i], "\t", &flds);
      if (flds.size() != 2u) continue;
      kv_[flds[0]] = flds[1];
    }
    return true;
  }

  virtual bool SerializeToString(std::string* data) {
    data->clear();
    for (auto it = kv_.begin(); it != kv_.end(); ++it) {
      data->append(it->first + "\t" + it->second + "\n");
    }
    return true;
  }

  std::string get(const std::string& key) const {
    auto it = kv_.find(key);
    if (it != kv_.end()) {
      return it->second;
    } else {
      return "";
    }
  }

  void set(const std::string& key, const std::string& val) {
    kv_[key] = val;
  }

 private:
  std::unordered_map<std::string, std::string> kv_;
};


TEST_F(WatchContextTest, LoadDict) {
  DynamicDict<TestDict> dict;
  std::string node = FLAGS_zk_path_root + "/test3";

  DictDispatcher<TestDict> dict_dispatcher(node.c_str(), &dict, FLAGS_hdfs_host.c_str(), FLAGS_hdfs_port);
  context->AddDispatcher(&dict_dispatcher);

  TestDict orig_dict;
  orig_dict.set("1", "2");
  std::string data;
  orig_dict.SerializeToString(&data);

  // generate a hdfs temp dir
  base::FilePath hdfs_temp_dir;
  base::ScopedTempDir tmp;
  CHECK(tmp.CreateUniqueTempDir());
  base::FilePath root(std::string("/tmp/"));
  hdfs_temp_dir = root.Append(tmp.path().BaseName());
  CHECK(hdfs::HDFSMkdir(hdfs_temp_dir.ToString().c_str()));
  base::FilePath hdfs_file_path = hdfs_temp_dir.AppendASCII("a");
  {
    hdfs::HDFSFileStream file(FLAGS_hdfs_host.c_str(), FLAGS_hdfs_port);
    ASSERT_TRUE(file.Open(hdfs_file_path.ToString().c_str(), O_WRONLY));
    ASSERT_EQ(file.Write(data.c_str(), data.size()), (int)data.size());
    ASSERT_TRUE(file.Flush());
    ASSERT_TRUE(file.Close());
  }

  char path[512];
  // create test node
  int ret = zoo_create(zh, node.c_str(), NULL, 0, &ZOO_OPEN_ACL_UNSAFE, 0, path, 512);
  ASSERT_TRUE(ret == ZOK || ret == ZNODEEXISTS);

  // register watcher to this node
  // zoo_awget(zh, node.c_str(), WatchContext::watcher, context, test_data_completion, NULL);
  char buf[1024];
  int buf_len=1024;
  ASSERT_TRUE(ZOK == zoo_wget(zh, node.c_str(), WatchContext::watcher, context, buf, &buf_len, NULL));

  // set zk node to the file path
  std::string value = hdfs_file_path.ToString();
  zoo_set(zh, node.c_str(), value.c_str(), value.size(), -1);
  base::SleepForSeconds(5);
  ASSERT_STREQ(dict.GetDict()->get("1").c_str(), "2");

  // change dict value
  orig_dict.set("1", "3");
  orig_dict.set("2", "1");
  data.clear();
  orig_dict.SerializeToString(&data);

  // write new data to the hdfs file
  {
    hdfs::HDFSFileStream file(FLAGS_hdfs_host.c_str(), FLAGS_hdfs_port);
    ASSERT_TRUE(file.Open(hdfs_file_path.ToString().c_str(), O_WRONLY));
    ASSERT_EQ(file.Write(data.c_str(), data.size()), (int)data.size());
    ASSERT_TRUE(file.Flush());
    ASSERT_TRUE(file.Close());
  }

  // again, set zk node to the file path to trigger the dict reload
  zoo_set(zh, node.c_str(), value.c_str(), value.size(), -1);
  base::SleepForSeconds(5);
  ASSERT_STREQ(dict.GetDict()->get("1").c_str(), "3");
  ASSERT_STREQ(dict.GetDict()->get("2").c_str(), "1");

  // clean
  ret = zoo_delete(zh, node.c_str(), -1);
  ASSERT_TRUE(ret == ZOK);

  context->RemoveDispatcher(&dict_dispatcher);

  ASSERT_TRUE(hdfs::HDFSRmr(hdfs_file_path.ToString().c_str()));
}

}  // namespace
}  // namespace
