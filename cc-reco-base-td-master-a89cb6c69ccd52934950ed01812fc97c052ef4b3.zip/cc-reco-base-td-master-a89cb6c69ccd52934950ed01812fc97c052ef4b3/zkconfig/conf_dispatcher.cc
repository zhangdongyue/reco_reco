#include "reco/base/zkconfig/conf_dispatcher.h"
#include "reco/base/zkconfig/watch_context.h"

#include "reco/base/zkconfig/watch_context.h"
#include "base/common/gflags.h"
#include "base/common/logging.h"
#include "base/strings/string_util.h"

namespace reco {
namespace zkconfig {

void ConfDispatcher::data_completion(int rc, const char *value, int value_len,
                     const struct Stat *stat, const void *data) {
  if (rc != 0) {
    LOG(ERROR) << zerror(rc);
    return;
  } else {
    LOG(INFO) << "get data value: " << value;
  }

  if (data != NULL) {
    DynamicDict<StringDict>* dict = static_cast<DynamicDict<StringDict>*>((void*)data);
    boost::shared_ptr<StringDict> shared_pt(new StringDict());
    shared_pt->ParseFromString(value, value_len);
    dict->Swap(shared_pt);
  }
}

ConfDispatcher::ConfDispatcher(const char* path, DynamicDict<StringDict>* dict) {
  path_ = path;
  dict_ = dict;
}

ConfDispatcher::~ConfDispatcher() {
}

void ConfDispatcher::DispatchEvent(Event evt) {
  // LOG(INFO) << evt.path << ":" << evt.type;
  if (!base::LowerCaseEquals(evt.path, path_.c_str())) {
    // LOG(INFO) << "skip this path: " << evt.path << " .vs. " << path_;
    return;
  }

  WatchContext* ctx = (WatchContext*) get_context();
  if (ctx == NULL) {
    LOG(ERROR) << "zk ctx is null";
    return;
  }

  char buf[1024];
  int buf_len = 1024;
  if (ZOK == zoo_wget(ctx->get_zhandle(), path_.c_str(), WatchContext::watcher, ctx, buf, &buf_len, NULL)) {
    if (buf_len == -1 || buf_len >= 10240) {
      LOG(ERROR) << "read data error";
    } else {
      buf[buf_len] ='\0';
      LOG(INFO) << "read: " << buf;
      boost::shared_ptr<StringDict> shared_pt(new StringDict());
      shared_pt->ParseFromString(buf, buf_len);
      dict_->Swap(shared_pt);
    }
  } else {
    LOG(ERROR) << "failed to get zk: " << evt.path;
  }
  // zoo_awget(ctx->get_zhandle(), path_, WatchContext::watcher, ctx, ConfDispatcher::data_completion, dict_);

  return;
}

}  // namespace
}  // namespace
