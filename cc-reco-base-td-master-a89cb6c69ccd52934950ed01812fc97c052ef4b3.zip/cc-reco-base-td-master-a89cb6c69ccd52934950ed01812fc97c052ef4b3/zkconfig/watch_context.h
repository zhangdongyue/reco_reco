#pragma once
#include <boost/shared_ptr.hpp>
#include <list>

#include "base/common/basic_types.h"
#include "base/thread/sync.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"

#include "third_party/zookeeper/include/zookeeper.h"

namespace reco {
namespace zkconfig {

/**
 * zk 事件定义
 */
struct Event {
  // zk 路径
  std::string path;
  // 事件类型，具体见 zk 定义
  int type;
};

/**
 * 事件处理类，虚基类；
 * 实际的处理逻辑需要基于此类派生，并重载 DispatchEvent 方法
 *
 */
class EventDispatcher {
 public:
  explicit EventDispatcher() : ctx_(NULL) {};
  virtual ~EventDispatcher() {};
  virtual void DispatchEvent(Event evt) = 0;

  void set_context(void* ctx) { ctx_ = ctx; };
  void* get_context() { return ctx_; }
 private:
  void* ctx_;
};

/**
 * 处理 type = ZOO_SESSION_EVENT 事件
 * 并通过外部传入的 Dispatcher 处理其他类型事件
 * 事件是在单独的线程中按到达时间顺序处理的
 *
 */
class WatchContext {
 public:
  explicit WatchContext(const char* hosts);
  WatchContext(const char* hosts, std::list<EventDispatcher*> dispatchers);
  ~WatchContext();

  void AddDispatcher(EventDispatcher* dispatcher);
  void RemoveDispatcher(EventDispatcher* dispatcher);

  void DispatchEventLoop();

  void PutEvent(Event evt) {
    CHECK_NOTNULL(events_);
    events_->Put(evt);
  }

  zhandle_t* get_zhandle() {
    return zh_;
  }

  static void watcher(zhandle_t *zzh, int type, int state, const char *path, void* context);

 private:
  friend void watcher(zhandle_t *zzh, int type, int state, const char *path, void* context);

  // dispatcher list
  std::list<EventDispatcher*> dispatchers_;

  bool connected_;

  // zk hosts
  const char* hosts_;

  // event blocking queue
  thread::BlockingQueue<Event>* events_;

  // zk handle
  zhandle_t *zh_;

  // thread for loop dispatchs
  thread::Thread thread_;

  // mutex for some lock
  thread::Mutex mutex_;
};

}  // namespace
}  // namespace
