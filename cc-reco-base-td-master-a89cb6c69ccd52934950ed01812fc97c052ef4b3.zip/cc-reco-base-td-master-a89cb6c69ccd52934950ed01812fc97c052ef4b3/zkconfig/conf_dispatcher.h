#pragma once
#include <boost/shared_ptr.hpp>
#include <list>

#include "base/common/basic_types.h"
#include "base/thread/sync.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "reco/base/zkconfig/dynamic_dict.h"
#include "reco/base/zkconfig/watch_context.h"

#include "third_party/zookeeper/include/zookeeper.h"

namespace reco {
namespace zkconfig {

class ConfDispatcher : public EventDispatcher {
 public:
  explicit ConfDispatcher(const char* path, DynamicDict<StringDict>* dict) ;
  virtual ~ConfDispatcher();
  virtual void DispatchEvent(Event evt);

  static void data_completion(int rc, const char *value, int value_len,
                              const struct Stat *stat, const void *data);

 private:
  std::string path_;
  DynamicDict<StringDict>* dict_;
};

}  // namespace
}  // namespace
