#pragma once

#include <iostream>
#include <map>
#include <string>
#include <vector>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "reco/base/hbase_c/internal/THBaseService.h"

namespace apache {
namespace thrift {

class TException;

namespace transport {
  class TSocket;
  class TTransport;
  class TTransportException;
}
namespace protocol {
  class TProtocol;
}
}

namespace hadoop {
namespace hbase {
namespace thrift2 {
  class THBaseServiceClient;
  class TPut;
  class TGet;
  class TDelete;
  class TResult;
  class TColumnValue;
}
}
}
}

namespace reco {
namespace hbase {

typedef std::vector<std::string> StrVec;
typedef std::map<std::string, std::string> StrMap;
typedef std::map<std::string, std::map<std::string, std::string>> RowMap;

class HBaseCli {
 public:
  HBaseCli(const std::string &server, const std::string &port);
  ~HBaseCli();

  // Open a new connect with hbase server
  bool Connect();

  // Close current connectionship with hbase server
  bool Disconnect();

  // Re-connect a new connect with hbase server
  bool Reconnect();

  // Returns current connect status
  bool Isconnect() const { return transport_->isOpen(); }

  // Returns true if data indexed by parameter table and row correctly returned from hbase
  bool GetByKey(const std::string &table, const std::string &row, StrMap *str_map);

  // Returns true if data indexed by parameter table and rows correctly returned from hbase
  bool BatchGetByKeys(const std::string &table, const StrVec &rows, RowMap *row_map);

  // Returns true if given fields not null and correctly inserted into hbase
  bool Insert(const std::string &table, const std::string &row,
              const std::string &family, const std::string &qualifier, const std::string &value);

  // Returns true if multi-rows data represented by rows be correctly organized and inserted into hbase
  bool BatchInsert(const std::string &table, const RowMap &rows);

  // Returns true if data indexed by row be removed correctly from hbase
  bool DelByKey(const std::string &table, const std::string &row);

  // Returns true if muiti-rows data represented by rows be correctly organized and removed from hbase
  bool BatchDelByKeys(const std::string &table, const StrVec &rows);
 private:
  boost::shared_ptr<apache::thrift::transport::TTransport> socket_;
  boost::shared_ptr<apache::thrift::transport::TTransport> transport_;
  boost::shared_ptr<apache::thrift::protocol::TProtocol> protocol_;
  apache::hadoop::hbase::thrift2::THBaseServiceClient client_;
  // bool is_connected_;

  typedef std::vector<apache::hadoop::hbase::thrift2::TGet> GetVec;
  typedef std::vector<apache::hadoop::hbase::thrift2::TPut> PutVec;
  typedef std::vector<apache::hadoop::hbase::thrift2::TColumnValue> ColValVec;
  typedef std::vector<apache::hadoop::hbase::thrift2::TResult> ResVec;
  typedef std::vector<apache::hadoop::hbase::thrift2::TDelete> DelVec;
};
}  // namespace hbase
}  // namespace reco
