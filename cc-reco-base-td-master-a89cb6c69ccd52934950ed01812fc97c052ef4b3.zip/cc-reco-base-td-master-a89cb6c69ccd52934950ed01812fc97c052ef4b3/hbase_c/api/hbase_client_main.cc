#include <iostream>

#include "base/common/base.h"
#include "reco/base/hbase_c/api/hbase_client.h"

DEFINE_string(hbase_id, "10.3.5.72", "host of hbase server");
DEFINE_string(hbase_port, "9090", "port of hbase thrift2 service");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "");

  reco::hbase::HBaseCli client(FLAGS_hbase_id, FLAGS_hbase_port);
  bool result = client.Connect();

  std::string table = "tb_test_query_log";
  // put

  if (!result) {
    std::cout << "connect failed!" << std::endl;
  }
  std::cout << "connect success!" << std::endl;

  std::cout << "put start..." << std::endl;
  result = client.Insert(table, "056", "data", "name", "test123456");
  if (!result) {
    std::cout << "put failed!" << std::endl;
    return 1;
  }
  std::cout << "put success!" << std::endl;

  std::cout << "putMultiple start..." << std::endl;
  reco::hbase::RowMap rowMap;
  reco::hbase::StrMap strMap;
  strMap.insert(std::make_pair("data:name", "test1"));
  strMap.insert(std::make_pair("data:passwd", "test2"));
  strMap.insert(std::make_pair("data:alias", "test3"));
  reco::hbase::StrMap strMap1;
  strMap1.insert(std::make_pair("data:name", "test1"));
  strMap1.insert(std::make_pair("data:passwd", "test2"));
  strMap1.insert(std::make_pair("data:alias", "test3"));
  reco::hbase::StrMap strMap2;
  strMap2.insert(std::make_pair("data:name", "test1"));
  strMap2.insert(std::make_pair("data:passwd", "test2"));
  strMap2.insert(std::make_pair("data:alias", "test3"));
  reco::hbase::StrMap strMap3;
  strMap3.insert(std::make_pair("data:name", "test1"));
  strMap3.insert(std::make_pair("data:passwd", "test2"));
  strMap3.insert(std::make_pair("data:alias", "test3"));
  reco::hbase::StrMap strMap4;
  strMap4.insert(std::make_pair("data:name", "test1"));
  strMap4.insert(std::make_pair("data:passwd", "test2"));
  strMap4.insert(std::make_pair("data:alias", "test3"));
  rowMap.insert(std::make_pair("031", strMap));
  rowMap.insert(std::make_pair("032", strMap1));
  rowMap.insert(std::make_pair("033", strMap2));
  rowMap.insert(std::make_pair("034", strMap3));
  rowMap.insert(std::make_pair("035", strMap4));

  result = client.BatchInsert(table, rowMap);
  if (!result) {
    std::cout << "putMultiple failed!" << std::endl;
    return 1;
  }
  std::cout << "putMulti success!" << std::endl;

  // get
  std::cout << "get start..." << std::endl;
  reco::hbase::StrMap strMapGet;
  result = client.GetByKey(table, "019", &strMapGet);
  if (!result) {
    std::cout << "get failed!" << std::endl;
    return 1;
  }
  for (reco::hbase::StrMap::const_iterator it = strMapGet.begin(); it != strMapGet.end(); it++) {
    std::cout << "column=" << it->first << " value=" << it->second << std::endl;
  }
  std::cout << "get success!" << std::endl;


  // getMultiple
  std::cout << "getMultiple start..." << std::endl;
  rowMap.clear();
  reco::hbase::StrVec strVec;
  strVec.push_back("0222");
  strVec.push_back("001");
  strVec.push_back("002");
  strVec.push_back("003");
  strVec.push_back("004");
  strVec.push_back("005");
  strVec.push_back("006");
  strVec.push_back("007");
  strVec.push_back("008");
  strVec.push_back("009");
  strVec.push_back("010");
  strVec.push_back("011");
  strVec.push_back("012");
  strVec.push_back("013");
  strVec.push_back("014");
  result = client.BatchGetByKeys(table, strVec, &rowMap);
  if (!result) {
    std::cout << "getMultiple failed!" << std::endl;
    return 1;
  }
  for (reco::hbase::RowMap::const_iterator it = rowMap.begin(); it != rowMap.end(); it++) {
    std::string row = it->first;
    reco::hbase::StrMap strMap = it->second;
    for (reco::hbase::StrMap::const_iterator iter = strMap.begin(); iter != strMap.end(); iter++) {
      std::cout << "row=" << row << " column=" << iter->first << " value=" << iter->second << std::endl;
    }
  }
  std::cout << "getMultiple success!" << std::endl;

  // delete
  std::cout << "delete start..." << std::endl;
  result = client.DelByKey(table, "004");

  if (!result) {
    std::cout << "delete failed!" << std::endl;
    return 1;
  }
  std::cout << "delete success!" << std::endl;

  // deleteMultiple
  std::cout << "deleteMultiple start..." << std::endl;
  reco::hbase::StrVec strVec2;
  strVec2.push_back("010");
  strVec2.push_back("011");
  strVec2.push_back("012");
  strVec2.push_back("013");
  strVec2.push_back("014");
  result = client.BatchDelByKeys(table, strVec2);
  if (!result) {
    std::cout << "deleteMultiple failed!" << std::endl;
    return 1;
  }
  std::cout << "deleteMultiple success!" << std::endl;

  return 0;
}
