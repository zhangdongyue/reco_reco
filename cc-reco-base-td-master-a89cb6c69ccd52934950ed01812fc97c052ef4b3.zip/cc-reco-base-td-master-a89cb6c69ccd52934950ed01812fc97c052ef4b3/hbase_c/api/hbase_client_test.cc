#include <iostream>
#include "hbase_client.h"

#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "base/common/base.h"

DEFINE_string(hbase_id, "10.3.5.70","host of hbase server");
DEFINE_string(hbase_port, "9090", "port of hbase thrift2 service");

class HBaseTest : public testing::Test
{
 protected:
  void SetUp() {
    client_ = new reco::hbase::HBaseCli(FLAGS_hbase_id, FLAGS_hbase_port);
    table_ = "tb_test";
  }
  void TearDown() {
    delete client_;
  }
  reco::hbase::HBaseCli *client_;
  std::string table_;
};


TEST_F(HBaseTest, Connect) {
  ASSERT_TRUE(client_->Connect());
}

TEST_F(HBaseTest, Put) {
  ASSERT_TRUE(client_->Connect());
  ASSERT_TRUE(client_->Insert(table_, "0201", "data", "name", "test"));
  ASSERT_TRUE(client_->Insert(table_, "0201", "data", "name", "test"));
  ASSERT_TRUE(client_->Insert(table_, "0203", "data", "name", "test"));
  ASSERT_TRUE(client_->Insert(table_, "0204", "data", "name", "test"));
  ASSERT_TRUE(client_->Insert(table_, "0205", "data", "name", "test"));
}

TEST_F(HBaseTest, PutMultiple) {
  ASSERT_TRUE(client_->Connect());
  reco::hbase::RowMap rowMap;
  reco::hbase::StrMap strMap;
  strMap.insert(std::make_pair("data:name", "test1"));
  strMap.insert(std::make_pair("data:passwd", "test2"));
  strMap.insert(std::make_pair("data:alias", "test3"));
  reco::hbase::StrMap strMap1;
  strMap1.insert(std::make_pair("data:name", "test1"));
  strMap1.insert(std::make_pair("data:passwd", "test2"));
  strMap1.insert(std::make_pair("data:alias", "test3"));
  reco::hbase::StrMap strMap2;
  strMap2.insert(std::make_pair("data:name", "test1"));
  strMap2.insert(std::make_pair("data:passwd", "test2"));
  strMap2.insert(std::make_pair("data:alias", "test3"));
  reco::hbase::StrMap strMap3;
  strMap3.insert(std::make_pair("data:name", "test1"));
  strMap3.insert(std::make_pair("data:passwd", "test2"));
  strMap3.insert(std::make_pair("data:alias", "test3"));
  reco::hbase::StrMap strMap4;
  strMap4.insert(std::make_pair("data:name", "test1"));
  strMap4.insert(std::make_pair("data:passwd", "test2"));
  strMap4.insert(std::make_pair("data:alias", "test3"));
  reco::hbase::StrMap strMap5;
  strMap5.insert(std::make_pair("data:name", "test1"));
  strMap5.insert(std::make_pair("data:passwd", "test2"));
  strMap5.insert(std::make_pair("data:alias", "test3"));
  rowMap.insert(std::make_pair("051", strMap));
  rowMap.insert(std::make_pair("052", strMap1));
  rowMap.insert(std::make_pair("053", strMap2));
  rowMap.insert(std::make_pair("054", strMap3));
  rowMap.insert(std::make_pair("055", strMap4));
  rowMap.insert(std::make_pair("056", strMap5));

  ASSERT_TRUE(client_->BatchInsert(table_, rowMap));

  for(reco::hbase::StrMap::const_iterator it = strMap.begin(); it != strMap.end(); it++) {
    std::cout << "column=" << it->first << " value=" << it->second << std::endl;
  }
}

TEST_F(HBaseTest, Get) {
  ASSERT_TRUE(client_->Connect());
  reco::hbase::StrMap strMap;
  ASSERT_TRUE(client_->GetByKey(table_, "0201", &strMap));
  for(reco::hbase::StrMap::const_iterator it = strMap.begin(); it != strMap.end(); it++) {
    std::cout << "column=" << it->first << " value=" << it->second << std::endl;
  }
}

TEST_F(HBaseTest, GetMultiple) {
  ASSERT_TRUE(client_->Connect());
  reco::hbase::RowMap rowMap;
  reco::hbase::StrVec strVec;
  strVec.push_back("0222");
  strVec.push_back("001");
  strVec.push_back("002");
  strVec.push_back("003");
  strVec.push_back("004");
  strVec.push_back("005");
  strVec.push_back("006");
  strVec.push_back("007");
  strVec.push_back("008");
  strVec.push_back("009");
  strVec.push_back("010");
  strVec.push_back("011");
  strVec.push_back("012");
  strVec.push_back("013");
  strVec.push_back("014");
  ASSERT_TRUE(client_->BatchGetByKeys(table_, strVec, &rowMap));

  for(reco::hbase::RowMap::const_iterator it = rowMap.begin(); it != rowMap.end(); it++) {
    std::string row = it->first;
    reco::hbase::StrMap strMap = it->second;
    for(reco::hbase::StrMap::const_iterator iter = strMap.begin(); iter != strMap.end(); iter++) {
      std::cout << "row=" << row << " column=" << iter->first << " value=" << iter->second << std::endl;
    }
  }
}

TEST_F(HBaseTest, Delete) {
  ASSERT_TRUE(client_->Connect());
  ASSERT_TRUE(client_->DelByKey(table_, "051"));
  ASSERT_TRUE(client_->DelByKey(table_, "052"));
}

TEST_F(HBaseTest, DeleteMultiple) {
  ASSERT_TRUE(client_->Connect());
  reco::hbase::StrVec strVec;
  strVec.push_back("0201");
  strVec.push_back("053");
  strVec.push_back("001");
  strVec.push_back("002");
  strVec.push_back("003");
  ASSERT_TRUE(client_->BatchDelByKeys(table_, strVec));
}

