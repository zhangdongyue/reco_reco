#include "reco/base/hbase_c/api/hbase_client.h"

#include <utility>

#include "boost/lexical_cast.hpp"
#include "third_party/thrift/protocol/TBinaryProtocol.h"
#include "third_party/thrift/transport/TSocket.h"
#include "third_party/thrift/transport/TTransportUtils.h"

namespace reco {
namespace hbase {
HBaseCli::HBaseCli(const std::string &server, const std::string &port)
    :socket_(new apache::thrift::transport::TSocket(server, boost::lexical_cast<int>(port))),
    transport_(new apache::thrift::transport::TBufferedTransport(socket_)),
    protocol_(new apache::thrift::protocol::TBinaryProtocol(transport_)),
    client_(protocol_) {
}

HBaseCli::~HBaseCli() {

}

bool HBaseCli::Connect() {
  try {
    transport_->open();
    return true;
  } catch (const apache::thrift::TException &e) {
    LOG(ERROR) << "connection exception:" << e.what();
    return false;
  }
}

bool HBaseCli::Disconnect() {
  try {
    transport_->close();
    return true;
  } catch (const apache::thrift::TException &e) {
    LOG(ERROR) << "connection exception:" <<e.what();
    return false;
  }
}

bool HBaseCli::Reconnect() {
  bool flag = Disconnect();
  flag = flag & Connect();
  return flag;
}

bool HBaseCli::GetByKey(const std::string &table, const std::string &row, StrMap *str_map) {
  if (!Isconnect()) {
    LOG(WARNING) << "lost connection";
    return false;
  }
  apache::hadoop::hbase::thrift2::TResult result;
  apache::hadoop::hbase::thrift2::TGet get;
  get.row = row;
  try {
    client_.get(result, table, get);
    ColValVec col_val_vec = result.columnValues;
    for(int i = 0; i < (int)col_val_vec.size(); i++) {
      apache::hadoop::hbase::thrift2::TColumnValue cv = col_val_vec[i];
      str_map->insert(std::make_pair(cv.family + ":" + cv.qualifier, cv.value));
    }
    return true;
  } catch (const apache::thrift::TException &tte) {
    LOG(ERROR) << "connection exception" << tte.what();
    return false;
  }
}

bool HBaseCli::BatchGetByKeys(const std::string &table, const StrVec &rows, RowMap *row_map) {
  if (!Isconnect()) {
    LOG(WARNING) << "lost connection";
    return false;
  }
  ResVec results;
  GetVec gets;
  for(int i = 0; i < (int)rows.size(); i++) {
    apache::hadoop::hbase::thrift2::TGet get;
    get.row = rows[i];
    gets.push_back(get);
  }
  try {
    client_.getMultiple(results, table, gets);
    for(int i = 0; i < (int)results.size(); i++) {
      ColValVec &col_val_vec = results[i].columnValues;
      StrMap str_map;
      for(int j = 0; j < (int)col_val_vec.size(); j++) {
        std::string key = col_val_vec[j].family + ":" + col_val_vec[j].qualifier;
        str_map.insert(std::make_pair(key, col_val_vec[j].value));
      }
      row_map->insert(std::make_pair(results[i].row, str_map));
    }
    return true;
  } catch (const apache::thrift::TException &tte) {
    LOG(ERROR) << "connection exception:" << tte.what();
    return false;
  }
}

bool HBaseCli::Insert(const std::string &table,
                      const std::string &row,
                      const std::string &family,
                      const std::string &qualifier,
                      const std::string &value) {
  if (!Isconnect()) {
    LOG(WARNING) << "lost connection";
    return false;
  }
  apache::hadoop::hbase::thrift2::TPut put;
  ColValVec col_val_vec;
  col_val_vec.push_back(apache::hadoop::hbase::thrift2::TColumnValue());
  col_val_vec.back().family = family;
  col_val_vec.back().qualifier = qualifier;
  col_val_vec.back().value = value;
  put.row = row;
  put.columnValues = col_val_vec;
  try {
    client_.put(table, put);
    return true;
  } catch (const apache::thrift::TException &tte) {
    LOG(ERROR) << "connection exception:" << tte.what();
    return false;
  }
}

bool HBaseCli::BatchInsert(const std::string &table, const RowMap &rows) {
  if(!Isconnect()) {
    LOG(WARNING) << "lost connection";
    return false;
  }
  PutVec puts;
  for(RowMap::const_iterator it = rows.begin(); it != rows.end(); it++) {
    apache::hadoop::hbase::thrift2::TPut put;
    ColValVec col_val_vec;
    std::string row = it->first;
    StrMap str_map = it->second;
    for(StrMap::const_iterator iter = str_map.begin(); iter != str_map.end(); iter++) {
      col_val_vec.push_back(apache::hadoop::hbase::thrift2::TColumnValue());
      std::string fq = iter->first;
      size_t idx = fq.find_first_of(":");
      if(idx == 0 || idx >= fq.size()) {
        return false;
      }
      col_val_vec.back().family = fq.substr(0, idx);
      col_val_vec.back().qualifier = fq.substr(idx + 1);
      col_val_vec.back().value = iter->second;
    }
    put.row = row;
    put.columnValues = col_val_vec;
    puts.push_back(put);
  }
  try {
    client_.putMultiple(table, puts);
    return true;
  } catch (const apache::thrift::TException &tte) {
    LOG(ERROR) << "connection exception:" << tte.what();
    return false;
  }
}

bool HBaseCli::DelByKey(const std::string &table, const std::string &row) {
  if (!Isconnect()) {
    LOG(WARNING) << "lost connection";
    return false;
  }
  apache::hadoop::hbase::thrift2::TDelete delete_single;
  delete_single.row = row;
  try {
    client_.deleteSingle(table, delete_single);
    return true;
  } catch (const apache::thrift::TException &tte) {
    LOG(ERROR) << "connection exception:" << tte.what();
    return false;
  }
}

bool HBaseCli::BatchDelByKeys(const std::string &table, const StrVec &rows) {
  if (!Isconnect()) {
    LOG(WARNING) << "lost connection";
    return false;
  }
  DelVec deletes;
  for(int i = 0; i < (int)rows.size(); i++) {
    apache::hadoop::hbase::thrift2::TDelete delete_single;
    delete_single.row = rows[i];
    deletes.push_back(delete_single);
  }
  DelVec results;
  try {
    client_.deleteMultiple(results, table, deletes);
    return true;
  } catch (const apache::thrift::TException &tte) {
    LOG(ERROR) << "connection exception:" << tte.what();
    return false;
  }
}
} // namespace hbase
} // namespace reco
