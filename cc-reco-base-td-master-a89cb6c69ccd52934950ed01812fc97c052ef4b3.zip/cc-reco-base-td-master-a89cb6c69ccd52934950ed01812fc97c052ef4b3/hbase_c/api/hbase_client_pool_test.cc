#include "reco/base/hbase_c/api/hbase_client_pool.h"

#include <iostream>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"


using reco::hbase::HBasePoolIns;
using reco::hbase::HBaseAutoCli;

class HBasePoolTest : public testing::Test
{
 protected:
  void SetUp() {
    HBasePoolIns::instance().Init();
  }
  void TearDown() {
  }
};


TEST_F(HBasePoolTest, Connect) {
  if (true) {
    HBaseAutoCli cli_1 = HBaseAutoCli(10);
    HBaseAutoCli cli_2 = HBaseAutoCli(10);

    ASSERT_TRUE(cli_1.Get() != NULL);
    ASSERT_TRUE(cli_2.Get() != NULL);

    ASSERT_TRUE(cli_2.Get()->Disconnect());
    ASSERT_TRUE(cli_1.Get()->Isconnect());
    ASSERT_TRUE(!cli_2.Get()->Isconnect());

    cli_1.Get()->Disconnect();
  }

  int i = 30;
  while (i-- > 0) {
    base::SleepForSeconds(2);
    LOG(INFO) << "waiting...";
  }
}
