#pragma once

#include <string>
#include <unordered_set>
#include <unordered_map>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/thread/sync.h"
#include "base/thread/thread.h"
#include "base/time/time.h"
#include "serving_base/utility/timer.h"
#include "reco/base/common/singleton.h"
#include "reco/base/hbase_c/api/hbase_client.h"


namespace reco {
namespace hbase {

class HBaseCli;
class HBaseConnectPool;

typedef reco::common::singleton_default<HBaseConnectPool> HBasePoolIns;

struct CliInfo {
  HBaseCli* cli;
  std::string ip;
  std::string port;
  CliInfo() : cli(NULL) {
  }

  bool operator== (const CliInfo &cli_info) const {
    if (cli_info.cli == this->cli && cli_info.ip == this->ip && cli_info.port == this->port) {
      return true;
    } else {
      return false;
    }
  }
};
}
}


namespace std {
template<>
struct hash<reco::hbase::CliInfo> {
  typedef reco::hbase::CliInfo argument_type;
  typedef std::size_t result_type;

  result_type operator()(argument_type const& s) const {
    return reinterpret_cast<result_type>(s.cli);
  }
};
}


namespace reco {
namespace hbase {

class HBaseConnectPool {
 public:
  HBaseConnectPool() : cond_var_(&mutex_), init_(false) {}

  ~HBaseConnectPool();

  void Init(void);

  bool is_inited() {
    return init_;
  }

  CliInfo GetCli(void);

  CliInfo GetCli(int milliseconds);

  void Release(const CliInfo &cli_info);

 private:
  void Stop(void);

  void HeartBeatGetLoop(void);

  void HeartBeatCheckLoop(void);

 private:
  mutable thread::Mutex mutex_;
  mutable thread::CondVar cond_var_;
  std::atomic_bool init_;

  std::unordered_set<CliInfo> occupied_;
  std::unordered_set<CliInfo> available_;
  std::unordered_set<CliInfo> disconnect_;

  thread::Thread heartbeat_get_thread_;
  thread::Thread heartbeat_check_thread_;
  std::unordered_map<CliInfo, base::Time> heartbeat_cnet_;

  DISALLOW_COPY_AND_ASSIGN(HBaseConnectPool);
};


class HBaseAutoCli {
 public:
  explicit HBaseAutoCli(int32 take_ms) {
    timer_.Start();
    cli_info_ = HBasePoolIns::instance().GetCli(take_ms);
  }

  ~HBaseAutoCli() {
    if (cli_info_.ip.empty() || cli_info_.cli == NULL) {
      return;
    } else {
      HBasePoolIns::instance().Release(cli_info_);
      DLOG(INFO) << "use hbase cli time:" << timer_.Stop();
    }   
  }

  HBaseCli* Get() {
    return cli_info_.cli;
  }

 private:
  CliInfo cli_info_;
  serving_base::Timer timer_;
};
}  // namespace hbase
}  // namespace reco
