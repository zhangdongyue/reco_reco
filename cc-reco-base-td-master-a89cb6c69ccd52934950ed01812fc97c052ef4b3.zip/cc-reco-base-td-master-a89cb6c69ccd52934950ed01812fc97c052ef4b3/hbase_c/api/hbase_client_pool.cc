#include "reco/base/hbase_c/api/hbase_client_pool.h"

#include <vector>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/random/pseudo_random.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"
#include "reco/base/common/singleton.h"
#include "reco/base/hbase_c/api/hbase_client.h"

using std::string;
using std::vector;
using std::unordered_set;

namespace reco {
namespace hbase {

DEFINE_string(hbase_thrift_ips, "100.81.1.68:49090,100.81.2.180:49090,100.81.4.141:49090",
              "hbase thrift ip port list");
DEFINE_int32(hbase_pool_size, 2, "total connect num");

DEFINE_string(hbase_heartbeat_table, "heartbeat", "");
DEFINE_string(hbase_heartbeat_row, "heartbeat", "");
DEFINE_int32(hbase_heartbeat_delta, 400, "ms");

HBaseConnectPool::~HBaseConnectPool() {
  Stop();
}

void HBaseConnectPool::Stop(void) {
  if (init_) {
    init_ = false;
    heartbeat_get_thread_.Join();
    heartbeat_check_thread_.Join();

    for (auto iter = occupied_.begin(); iter != occupied_.end(); ++iter) {
      auto cli = iter->cli;
      if (cli) {
        LOG(INFO) << "Destructor hbase cli:" << cli;
        delete cli;
        cli = NULL;
      }
    }

    for (auto iter = available_.begin(); iter != available_.end(); ++iter) {
      auto cli = iter->cli;
      if (cli) {
        LOG(INFO) << "Destructor hbase cli:" << cli;
        delete cli;
        cli = NULL;
      }
    }

    for (auto iter = disconnect_.begin(); iter != disconnect_.end(); ++iter) {
      auto cli = iter->cli;
      if (cli) {
        LOG(INFO) << "Destructor hbase cli:" << cli;
        delete cli;
        cli = NULL;
      }
    }

    for (auto iter = heartbeat_cnet_.begin(); iter != heartbeat_cnet_.end(); ++iter) {
      auto cli = iter->first.cli;
      if (cli) {
        LOG(INFO) << "Destructor hbase cli:" << cli;
        delete cli;
        cli = NULL;
      }
    }

    heartbeat_cnet_.clear();
    occupied_.clear();
    available_.clear();
    disconnect_.clear();
  }
}


void HBaseConnectPool::Init() {
  thread::AutoLock lock(&mutex_);

  if (init_) {
    LOG(WARNING) << "Has been initialed!";
    return;
  }
  init_ = true;

  // parse ip:port
  vector<string> ips_vec;
  base::SplitString(FLAGS_hbase_thrift_ips, ",", &ips_vec);
  CHECK(ips_vec.size());

  base::PseudoRandom random(base::GetTimestamp());
  int ips_pos = random.GetUint64LT(ips_vec.size());
  unordered_set<string> heartbeat_set;

  for (auto cli_num = 0; cli_num < FLAGS_hbase_pool_size; ++cli_num) {
    ips_pos = (ips_pos + 1) % ips_vec.size();
    const string &ip_str = ips_vec[ips_pos];

    if (ip_str.empty()) {
      LOG(ERROR) << "hbase ip str is empty.";
      continue;
    }

    vector<string> ip_port;
    base::SplitString(ip_str, ":", &ip_port);
    CHECK_EQ(ip_port.size(), 2u);

    // add to heartbeat map
    if (heartbeat_set.find(ip_str) == heartbeat_set.end()) {
      heartbeat_set.insert(ip_str);

      CliInfo cli_info;
      HBaseCli *client = new HBaseCli(ip_port[0], ip_port[1]);
      CHECK_NOTNULL(client);
      client->Connect();
      cli_info.cli = client;
      cli_info.ip = ip_port[0];
      cli_info.port = ip_port[1];
      heartbeat_cnet_[cli_info] = base::Time::Now() + base::TimeDelta::FromSeconds(10);
      LOG(INFO) << "cli heartbeat connect thrift, ip:" << ip_port[0]
                << ", port:" << ip_port[1]
                << ", cli:" << cli_info.cli;
    }

    CliInfo cli_info;
    HBaseCli *client = new HBaseCli(ip_port[0], ip_port[1]);
    CHECK_NOTNULL(client);

    cli_info.cli = client;
    cli_info.ip = ip_port[0];
    cli_info.port = ip_port[1];

    if (client->Connect()) {
      available_.insert(cli_info);
      LOG(INFO) << "cli connect succ, thrift, ip:"
                << ip_port[0] << ", port:" << ip_port[1] << ", cli:" << client;
    } else {
      disconnect_.insert(cli_info);
      LOG(INFO) << "cli connect fail, thrift, ip:"
                << ip_port[0] << ", port:" << ip_port[1] << ", cli:" << client;
    }
  }

  CHECK(available_.size());

  heartbeat_get_thread_.Start(::NewCallback(this, &HBaseConnectPool::HeartBeatGetLoop));
  heartbeat_check_thread_.Start(::NewCallback(this, &HBaseConnectPool::HeartBeatCheckLoop));
  return;
}


CliInfo HBaseConnectPool::GetCli(int milliseconds) {
  if (milliseconds < 0) {
    return GetCli();
  }

  thread::AutoLock lock(&mutex_);
  while (available_.empty()) {
    if (!cond_var_.TimedWait(&milliseconds)) {
      return CliInfo();
    }
  }

  auto it = available_.begin();
  auto val = *it;
  available_.erase(val);
  occupied_.insert(val);
  return val;
}


CliInfo HBaseConnectPool::GetCli(void) {
  thread::AutoLock lock(&mutex_);
  if (available_.empty()) {
    LOG(WARNING) << "No connections available.";
    return CliInfo();
  }

  auto it = available_.begin();
  auto val = *it;
  available_.erase(val);
  occupied_.insert(val);
  return val;
}


void HBaseConnectPool::Release(const CliInfo &cli_info) {
  if (!cli_info.cli) {
    return;
  }

  thread::AutoLock lock(&mutex_);
  occupied_.erase(cli_info);

  if (cli_info.cli->Isconnect()) {
    available_.insert(cli_info);
    cond_var_.Signal();
  } else {
    disconnect_.insert(cli_info);
    LOG(INFO) << "hbase cli disconnect:" << cli_info.cli;
  }

  return;
}


void HBaseConnectPool::HeartBeatGetLoop() {
  LOG(INFO) << "HBaseConnectPool HeartBeatLoop run.";

  while (init_) {
    base::SleepForMilliseconds(100);

    // check heartbeat list
    for (auto it = heartbeat_cnet_.begin(); it != heartbeat_cnet_.end(); ++it) {
      const CliInfo &heartbeat_info = it->first;

      // get heartbeat data
      StrMap str_map;
      if (heartbeat_info.cli->GetByKey(FLAGS_hbase_heartbeat_table, FLAGS_hbase_heartbeat_row, &str_map)) {
        it->second = base::Time::Now();
        LOG_EVERY_N(INFO, 2000) << "hearbeat: hbase connect ok, ip:" << heartbeat_info.ip
                                << ", port:" << heartbeat_info.port;
      } else {
        LOG_EVERY_N(ERROR, 100) << "hearbeat: hbase connect error, ip:" << heartbeat_info.ip
                     << ", port:" << heartbeat_info.port
                     << ", cli:" << heartbeat_info.cli;
      }
    }
  }  // end while init_

  return;
}


void HBaseConnectPool::HeartBeatCheckLoop() {
  LOG(INFO) << "HBaseConnectPool HeartBeat check loop run.";

  while (init_) {
    base::SleepForMilliseconds(200);

    // check disconnect
    if (true) {
      thread::AutoLock lock(&mutex_);
      for (auto it = disconnect_.begin(); it != disconnect_.end(); ++it) {
        const CliInfo dis_info = *it;
        if (dis_info.cli->Reconnect()) {
          disconnect_.erase(dis_info);
          available_.insert(dis_info);
          cond_var_.Signal();
          LOG_EVERY_N(INFO, 10) << "reconnect cli ok:" << dis_info.cli;
          break;
        }
      }
    }

    for (auto it = heartbeat_cnet_.begin(); it != heartbeat_cnet_.end(); ++it) {
      // disconnect
      if (base::Time::Now() - it->second <= base::TimeDelta::FromMilliseconds(FLAGS_hbase_heartbeat_delta)) {
        continue;
      }

      CliInfo heartbeat_info = it->first;
      heartbeat_info.cli->Reconnect();
      LOG(ERROR) << "heartbeat disconnect, ip:" << heartbeat_info.ip << ", port:" << heartbeat_info.port;

      thread::AutoLock lock(&mutex_);

      bool find_match = true;
      while (find_match) {
        find_match = false;
        for (auto it = available_.begin(); it != available_.end(); ++it) {
          auto test_info = *it;
          if (test_info.ip == heartbeat_info.ip && test_info.port == heartbeat_info.port) {
            available_.erase(test_info);
            disconnect_.insert(test_info);
            find_match = true;
            LOG(INFO) << "hbase cli disconnect:" << test_info.cli;
            break;
          }
        }  // end for available_
      }  // end while find_match
    }  // end for heartbeat_cnet_
  }  // end while init_
}
}  // namespace hbase
}  // namespace reco
