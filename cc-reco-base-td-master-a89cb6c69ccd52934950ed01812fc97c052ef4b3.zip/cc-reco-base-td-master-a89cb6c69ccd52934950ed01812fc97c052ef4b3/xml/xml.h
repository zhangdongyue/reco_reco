#pragma once

#include <map>
#include <set>
#include <string>
#include <vector>

#include "util/xml/xml.h"

namespace reco {
namespace xml {
bool GetXmlContext(const std::string &file_path, util::xml::XMLContext* context);

bool GetXPathString(const std::string& path, util::xml::XMLContext* context, std::string* value);
bool GetXPathString(const std::string& path, util::xml::Element* ele, std::string* str);

bool GetXPathInt64(const std::string& path, util::xml::XMLContext* context,  int64* value);
bool GetXPathInt64(const std::string& path, util::xml::Element* ele, int64* value);

bool GetXPathInt32(const std::string& path, util::xml::XMLContext* context, int32* value);
bool GetXPathInt32(const std::string& path, util::xml::Element* ele, int32* value);

bool GetXPathDouble(const std::string& path, util::xml::XMLContext* context, double* value);
bool GetXPathDouble(const std::string& path, util::xml::Element* ele, double* value);

bool GetXPathBool(const std::string& path, util::xml::XMLContext* context, bool* value);
bool GetXPathBool(const std::string& path, util::xml::Element* ele, bool* value);

bool GetXPathArrayString(const std::string& path, util::xml::XMLContext* context, std::vector<std::string>* strs);  // NOLINT
}
}  // namespace reco

