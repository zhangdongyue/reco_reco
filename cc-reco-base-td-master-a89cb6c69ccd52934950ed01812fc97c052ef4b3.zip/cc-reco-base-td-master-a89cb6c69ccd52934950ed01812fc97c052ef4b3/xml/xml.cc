#include "reco/base/xml/xml.h"

#include "base/common/base.h"
#include "base/common/logging.h"

#include "base/file/file_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "base/strings/string_number_conversions.h"

#include "util/xml/xml.h"

namespace reco {
namespace xml {

bool GetXmlContext(const std::string &file_path, util::xml::XMLContext* context) {
  if (file_path.empty()) {
    LOG(ERROR) << "Empty service file! file:" << file_path;
    return false;
  }

  std::string content;
  if (!base::file_util::ReadFileToString(file_path, &content)) {
    LOG(ERROR) << "Read service file error! file:" << file_path;
    return false;
  }

  util::xml::XMLParser parser;
  if (!parser.Parse(content, context)) {
    LOG(ERROR) << "Parse xml context error! content:" << content;
    return false;
  }
  return true;
}

bool GetXPathString(const std::string& path, util::xml::XMLContext* context, std::string *str) {
  util::xml::XPathContext xpathcontext;
  util::xml::XPath xpath(path);
  context->execute(xpath, &xpathcontext);
  const std::vector<util::xml::Node*>& res = xpathcontext.GetResult();
  if (res.size() == 0) {
    LOG(INFO) << "no \"" << path << "\" specified.";
    return false;
  } else if (res.size() > 1) {
    LOG(INFO) << "multiple \"" << path << "\" specified.";
    return false;
  }
  if (res[0]->type() != util::xml::Node::kElementNode) {
    LOG(INFO) << "Multi \"" << path << "\" specified.";
    return false;
  }

  util::xml::Element* ele = res[0]->ToElement();
  return ele->GetText(str);
}

bool GetXPathString(const std::string& path, util::xml::Element* pele, std::string* str) {
  util::xml::XPathContext xpathcontext;
  util::xml::XPath xpath(path);
  pele->execute(xpath, &xpathcontext);
  const std::vector<util::xml::Node*>& res = xpathcontext.GetResult();
  if (res.size() == 0) {
    VLOG(5) << "no \"" << path << "\" specified.";
    return false;
  } else if (res.size() > 1) {
    LOG(INFO) << "multiple \"" << path << "\" specified.";
    return false;
  }
  if (res[0]->type() != util::xml::Node::kElementNode) {
    LOG(INFO) << "Multi \"" << path << "\" specified.";
    return false;
  }

  util::xml::Element* ele = res[0]->ToElement();
  return ele->GetText(str);
}


bool GetXPathDouble(const std::string& path, util::xml::XMLContext* context, double *value) {
  std::string str;
  if (!GetXPathString(path, context, &str)) return false;
  if (!base::StringToDouble(str, value)) return false;
  return true;
}

bool GetXPathDouble(const std::string& path, util::xml::Element* ele, double* value) {
  std::string str;
  if (!GetXPathString(path, ele, &str)) return false;
  if (!base::StringToDouble(str, value)) return false;
  return true;
}

bool GetXPathInt32(const std::string& path, util::xml::Element* ele, int32* value) {
  std::string str;
  if (!GetXPathString(path, ele, &str)) return false;
  if (!base::StringToInt(str, value)) return false;
  return true;
}

bool GetXPathInt32(const std::string& path, util::xml::XMLContext* context, int32 *value) {
  std::string str;
  if (!GetXPathString(path, context, &str)) return false;
  if (!base::StringToInt(str, value)) return false;
  return true;
}

bool GetXPathInt64(const std::string& path, util::xml::XMLContext* context, int64 *value) {
  std::string str;
  if (!GetXPathString(path, context, &str)) return false;
  if (!base::StringToInt64(str, value)) return false;
  return true;
}

bool GetXPathInt64(const std::string& path, util::xml::Element* ele, int64 *value) {
  std::string str;
  if (!GetXPathString(path, ele, &str)) return false;
  if (!base::StringToInt64(str, value)) return false;
  return true;
}

bool GetXPathBool(const std::string& path, util::xml::XMLContext* context, bool *value) {
  std::string str;
  if (!GetXPathString(path, context, &str)) return false;
  base::LowerString(&str);
  if (str == "true") {
    *value = true;
  } else if (str == "false") {
    *value = false;
  } else {
    *value = false;
    return false;
  }
  return true;
}

bool GetXPathBool(const std::string& path,  util::xml::Element* ele, bool *value) {
  std::string str;
  if (!GetXPathString(path, ele, &str)) return false;
  base::LowerString(&str);
  if (str == "true") {
    *value = true;
  } else if (str == "false") {
    *value = false;
  } else {
    *value = false;
    return false;
  }
  return true;
}

bool GetXPathArrayString(const std::string& path, util::xml::XMLContext* context,
                         std::vector<std::string>* strs) {
  util::xml::XPathContext xpathcontext;
  util::xml::XPath xpath(path);
  context->execute(xpath, &xpathcontext);
  const std::vector<util::xml::Node*>& res = xpathcontext.GetResult();
  if (res.size() == 0) {
    LOG(INFO) << "no \"" << path << "\" specified.";
    return false;
  }

  strs->resize(res.size(), "");
  for (size_t i = 0; i < res.size(); ++i) {
    if (res[i]->type() != util::xml::Node::kElementNode) {
      LOG(INFO) << "Multi \"" << path << "\" specified.";
      continue;
    }
    util::xml::Element* ele = res[i]->ToElement();
    if (!ele->GetText(&(strs->at(i)))) {
      LOG(ERROR) << "get text failed for : " << i;
      continue;
    }
  }
  return true;
}
}
}
