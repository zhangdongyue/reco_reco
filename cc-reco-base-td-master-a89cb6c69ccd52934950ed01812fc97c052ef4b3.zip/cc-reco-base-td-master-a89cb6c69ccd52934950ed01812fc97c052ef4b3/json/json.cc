#include "reco/base/json/json.h"

#include <string>
#include <vector>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"

#include "extend/json/jansson/jansson.h"

namespace reco {
namespace json {

std::string GetFieldValue(json_t* json, const std::string &name) {
  auto field_value = json_object_get(json, name.c_str());
  if (json_is_string(field_value)) {
    return json_string_value(field_value);
  } else if (json_is_integer(field_value)) {
    return base::Int64ToString(json_integer_value(field_value));
  } else if (json_is_real(field_value)) {
    return base::DoubleToString(json_real_value(field_value));
  }
  return "";
}

bool GetStringFieldValue(json_t* json, const std::string &name, std::string *value) {
  auto field_value = json_object_get(json, name.c_str());
  if (json_is_string(field_value)) {
    value->assign(json_string_value(field_value));
    return true;
  }
  return false;
}

bool GetInt64FieldValue(json_t* json, const std::string &name, int64 *value) {
  auto field_value = json_object_get(json, name.c_str());
  if (json_is_integer(field_value)) {
    *value = json_integer_value(field_value);
    return true;
  }
  return false;
}

bool GetDoubleFieldValue(json_t* json, const std::string &name, double *value) {
  auto field_value = json_object_get(json, name.c_str());
  if (json_is_real(field_value)) {
    *value = json_real_value(field_value);
    return true;
  }
  return false;
}

bool ParseTFServingResult(const std::string& json_str, std::vector<double>* probs) {
  json_error_t json_error;
  json_t* json = json_loads(json_str.c_str(), &json_error);
  if (json == NULL) {
    LOG(ERROR) << "Failed to parse json in response line: " << json_error.line;
    return false;
  }

  json_t* j_prob = json_object_get(json, "prob");
  if (j_prob == NULL) {
    LOG(ERROR) << "Failed to parse prob in json line: " << json_error.line;
    return false;
  }
  json_t* j_shape = json_object_get(j_prob, "shape");
  int prob_num = 0;
  int label_num = 0;
  {
    int size = json_array_size(j_shape);
    if (size == 1) {
      prob_num = json_integer_value(json_array_get(j_shape, 0));
      label_num = 1;
    } else if (size == 2) {
      prob_num = json_integer_value(json_array_get(j_shape, 0));
      label_num = json_integer_value(json_array_get(j_shape, 1));
    } else {
      LOG(ERROR) << "Failed to parse shape in json line: " << json_error.line;
      return false;
    }
  }
  probs->reserve(probs->size() + prob_num);

  json_t* j_content = json_object_get(j_prob, "content");
  int size = json_array_size(j_content);
  if (size <= 0) {
    LOG(ERROR) << "Failed to parse predict values in json line: " << json_error.line;
    return false;
  }

  int index = label_num - 1;
  for (int i = 0; i < prob_num; ++i, index += label_num) {
    probs->push_back(json_real_value(json_array_get(j_content, index)));
  }
  json_decref(json);

  return true;
}
}
}
