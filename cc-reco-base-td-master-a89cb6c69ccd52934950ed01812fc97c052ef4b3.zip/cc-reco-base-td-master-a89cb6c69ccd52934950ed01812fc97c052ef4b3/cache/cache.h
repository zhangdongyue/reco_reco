#pragma once
#include <string>

#include "base/common/basic_types.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "reco/base/redis_c/api/redis_cli_pool.h"

namespace reco {
namespace common {
class Cache {
public:
  // redis_ip_pool可以为NULL,此时仅使用本地缓存
  explicit Cache(const uint32 expire_sec, const std::string& redis_ip_pool, const uint32 redis_expire_sec);

  ~Cache();

  bool Get(const std::string& key, std::string* value) const;

  bool Set(const std::string& key, const std::string& value);

  void Del(const std::string& key);

private:
  uint32 redis_expire_sec_;
  serving_base::ExpiryMap<std::string, std::string>* cache_;
  reco::redis::RedisCli* redis_cli_;
};
}  // namespace common
}  // namespace reco
