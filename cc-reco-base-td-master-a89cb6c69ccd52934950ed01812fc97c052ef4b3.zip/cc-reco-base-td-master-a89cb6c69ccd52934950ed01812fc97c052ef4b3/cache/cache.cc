#include "reco/base/cache/cache.h"

#include "base/common/logging.h"

using std::string;
using serving_base::ExpiryMap;

namespace reco {
namespace common {
Cache::Cache(const uint32 expire_sec, const string& redis_ips, const uint32 redis_expire_sec) {
  redis_expire_sec_ = redis_expire_sec;
  cache_ = new ExpiryMap<string, string>(expire_sec);
  CHECK_NOTNULL(cache_);

  if (!redis_ips.empty()) {
    redis_cli_ = new reco::redis::RedisCli(redis_ips);
  } else {
    redis_cli_ = NULL;
  }
}

Cache::~Cache() {
  if (cache_) delete cache_;
  if (redis_cli_) delete redis_cli_;
}

bool Cache::Set(const std::string& key, const std::string& value) {
  cache_->Add(key, value);

  if (redis_cli_) {
    if(!redis_cli_->SetEx(key, value, redis_expire_sec_)) {
      return false;
    }
  }

  return true;
}

bool Cache::Get(const std::string& key, std::string* value) const {
  value->clear();

  if (cache_->FindSilently(key, value)) {
    return true;
  }

  if (redis_cli_ && redis_cli_->Get(key, value) == 0) {
    cache_->Add(key, *value);
    return true;
  }

  return false;
}

void Cache::Del(const std::string& key) {
  // expirymap通过设置空值来模拟删除
  cache_->Add(key, "");
  if (redis_cli_)
    redis_cli_->Del(key);
}
}  // namespace common
}  // namespace reco
