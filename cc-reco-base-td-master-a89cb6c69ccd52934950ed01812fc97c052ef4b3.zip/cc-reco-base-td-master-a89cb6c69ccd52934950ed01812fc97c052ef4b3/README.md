1. 仓库定位和主要模块介绍
==========================================

本仓库用于维护业务无关的基础模块，
比如第三方中间件的 client， 团队大牛开发的效率工具等等
与业务相关的基础代码请移步 cc-reco-bizc 提交

本仓库的两个原则
a. 不依赖 cc-reco-X 的其他模块
b. 只依赖 cc-pub 仓库中的 base third-party net 等基础模块

目前已有模块如下
├── aerospike_c 
    第三方存储 aerospike 的 client
├── cache
    通用的缓存模块，有内存和 redis 两层
├── common
    一些零碎的工具库，如 topN，singleton 等
├── dict_manager
    动态词典(shared ptr 实现) 及词典重载框架
├── hbase_c
    第三方存储 hbase 的 client，调用底层的 thrift 库
├── hdfs
    提供了对 hdfs 文件及目录进行操作工具
├── kafka_c
    第三方消息队列 kafka 的 client
├── redis_c
    第三方存储 redis 的 client
└── zkconfig
    基于 zookeeper 实现的自动配置重载；基于 zk + hdfs 实现的自动词表重载


2. 仓库本地配置
==========================================

首先需要 git clone git@gitlab.alibaba-inc.com:sm-xss/cc-pub.git
cc-pub 仓库提供了编译环境和基础库。请认真阅读 cc-pub 的 README

git clone git@gitlab.alibaba-inc.com:sm-xss/cc-reco-base.git
会得到 cc-reco-base 目录

在 cc-pub 下面新建一个 reco 文件夹 （reco 目录会被 cc-pub 这个仓库忽略）
然后通过符号链接或者 mv 的方式，把 cc-reco-base 仓库放到 reco 子目录下
最终目录结构如下

cc-pub
 ├──reco
     ├──base  -> cc-reco-base
