#include "reco/base/kafka_c/api/topic_consumer.h"
#include "reco/base/kafka_c/api/topic_producer.h"

#include <unordered_map>

#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "base/common/base.h"
#include "serving_base/utility/time_helper.h"
#include "base/common/sleep.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/random/pseudo_random.h"
#include "base/time/timestamp.h"

namespace reco {
namespace kafka {

class TopicTest : public testing::Test {
 public:
  virtual void SetUp() {
    brokers_ = "100.85.69.55:9092,100.85.69.70:9092";
    topic_name_ = "rdkafka_test";
    total_partition_ = 32;
  }

  virtual void TearDown() {}

  std::string brokers_;
  std::string topic_name_;
  int total_partition_;
};

TEST_F(TopicTest, PushAndFetch) {
  TopicConsumer consumer(brokers_, topic_name_, total_partition_);
  consumer.SetOffsetToEnd();
  // 等待内部线程执行读取任务，把 reach par end的错误给pass过去
  base::SleepForSeconds(3);

  TopicProducer producer(brokers_, topic_name_, total_partition_);
  int num_per_par = 1000;
  base::PseudoRandom rand(base::GetTimestamp());
  std::vector<std::vector<std::string>> push_data(total_partition_);
  std::unordered_map<std::string, int> data2par;
  for (int i = 0; i < total_partition_; ++i) {
    // push_data[i].resize(num_per_par);
    for (int j = 0; j < num_per_par; ++j) {
      std::string data = base::Uint64ToString(rand.GetUint64());
      while (data2par.count(data) > 0) {
        data = base::Uint64ToString(rand.GetUint64());
      }
      ASSERT_TRUE(producer.Push(i, data));
      data2par[data] = i;
      push_data[i].push_back(data);
    }
  }

  std::string data;
  std::vector<std::vector<std::string>> fetch_data(total_partition_);
  // 读取队列
  while (consumer.Fetch(&data, 1000)) {
    ASSERT_TRUE(data2par.count(data) > 0);
    int par = data2par[data];
    fetch_data[par].push_back(data);
  }

  // 验证读取的总量与写入的一致
  // 且每个 partition 内顺序与写入的一致
  for (size_t i = 0; i < fetch_data.size(); ++i) {
    ASSERT_EQ(fetch_data[i].size(), push_data[i].size());
    for (size_t j = 0; j < fetch_data[i].size(); ++j) {
      ASSERT_STREQ(fetch_data[i][j].c_str(), push_data[i][j].c_str());
    }
  }
}

// TEST_F(TopicTest, OffsetTail) {
//   PartitionProducer producer;
//   ASSERT_TRUE(producer.Connect(brokers_, topic_name_, 0));
//   ASSERT_TRUE(producer.Push("0"));
// 
//   PartitionConsumer consumer;
//   ASSERT_TRUE(consumer.Connect(brokers_, topic_name_, 0));
//   ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_TAIL(1)));
//   std::string data;
//   int64 offset;
//   ASSERT_TRUE(consumer.Fetch(1000, &data, &offset));
//   ASSERT_STREQ(data.c_str(), "0");
// }
// 
// TEST_F(TopicTest, ModifyOffset) {
//   PartitionProducer producer;
//   ASSERT_TRUE(producer.Connect(brokers_, topic_name_, 0));
//   base::PseudoRandom rand(base::GetTimestamp());
//   std::string data_list;
//   for (int i = 0; i < 10; ++i) {
//     std::string data = base::Uint64ToString(rand.GetUint64());
//     EXPECT_TRUE(producer.Push(data));
//     if (!data_list.empty()) {
//       data_list.append(",");
//     }
//     data_list.append(data);
//   }
//   std::string push_data_list = data_list;
// 
//   // NOTE: (坑) 需要等 prdoucer 写完以后，再去构造 conumser，这样 TAIL 才准确
//   // 如果跟 producer 一同构造，tail的位置不包含 producer 添加的这些条
//   PartitionConsumer consumer;
//   ASSERT_TRUE(consumer.Connect(brokers_, topic_name_, 0));
//   ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_TAIL(10)));
//   std::map<std::string, int64> offset_map;
//   data_list.clear();
//   for (int i = 0; i < 10; ++i) {
//     std::string data;
//     int64 offset;
//     EXPECT_TRUE(consumer.Fetch(1000, &data, &offset));
//     offset_map[data] = offset;
//     if (!data_list.empty()) {
//       data_list.append(",");
//     }
//     data_list.append(data);
//   }
//   ASSERT_STREQ(push_data_list.c_str(), data_list.c_str());
// 
//   for (auto it = offset_map.begin(); it != offset_map.end(); ++it) {
//     ASSERT_TRUE(consumer.ResetOffset(it->second));
//     std::string data;
//     int64 offset;
//     EXPECT_TRUE(consumer.Fetch(1000, &data, &offset));
//     EXPECT_STREQ(it->first.c_str(), data.c_str())
//         << it->first << ":" << it->second << " vs " << data << ":" << offset;
//   }
// }
// 
// TEST_F(TopicTest, ModifyStoreFile) {
//   PartitionProducer producer;
//   ASSERT_TRUE(producer.Connect(brokers_, topic_name_, 0));
//   base::PseudoRandom rand(base::GetTimestamp());
//   std::string data_list;
//   for (int i = 0; i < 10; ++i) {
//     std::string data = base::Uint64ToString(rand.GetUint64());
//     EXPECT_TRUE(producer.Push(data));
//     if (!data_list.empty()) {
//       data_list.append(",");
//     }
//     data_list.append(data);
//   }
//   std::string push_data_list = data_list;
// 
//   // NOTE: (坑) 需要等 prdoucer 写完以后，再去构造 conumser，这样 TAIL 才准确
//   // 如果跟 producer 一同构造，tail的位置不包含 producer 添加的这些条
//   PartitionConsumer consumer;
//   ASSERT_TRUE(consumer.Connect(brokers_, topic_name_, 0));
//   ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_TAIL(10)));
//   std::map<std::string, int64> offset_map;
//   data_list.clear();
//   for (int i = 0; i < 10; ++i) {
//     std::string data;
//     int64 offset;
//     EXPECT_TRUE(consumer.Fetch(1000, &data, &offset));
//     offset_map[data] = offset;
//     if (!data_list.empty()) {
//       data_list.append(",");
//     }
//     data_list.append(data);
//   }
//   ASSERT_STREQ(push_data_list.c_str(), data_list.c_str());
// 
//   base::FilePath file(base::StringPrintf("%s-%d.offset", topic_name_.c_str(), 0));;
//   for (auto it = offset_map.begin(); it != offset_map.end(); ++it) {
//     // 调用 Reset，迫使内部 stop consumer，这样offset会被主动写入到文件中
//     ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_BEGINNING));
//     // 此时再更新文件，保证文件只被本单测写入
//     // NOTE: (坑) 文件方式的 offset 是上一次地址， 直接设置的offset是本次读取地址
//     std::string offset_str = base::Int64ToString(it->second - 1);
//     // LOG(INFO) << offset_str;
//     base::file_util::WriteFile(file, offset_str.c_str(), offset_str.size());
//     ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_STORED));
//     std::string data;
//     int64 offset;
//     EXPECT_TRUE(consumer.Fetch(1000, &data, &offset));
//     EXPECT_STREQ(it->first.c_str(), data.c_str());
//     LOG(INFO) << it->first << ":" << it->second << " vs " << data << ":" << offset;
//     // std::string s;
//     // base::file_util::ReadFileToString(file, &s);
//     // LOG(INFO) << s;
//   }
// }

}  // namespace kafka
}  // namespace reco

