#pragma once

#include <string>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/thread/internal/synchronization/lock.h"
#include "third_party/librdkafka/include/rdkafka.h"

namespace reco {
namespace kafka {

// set to "" to close, other value can be: all,generic,broker,topic,metadata,producer,queue,msg,protocol
// generally if debug, can set to topic
DECLARE_string(kafak_debug);

// Maximum transmit message size, default 4MB
DECLARE_uint64(message_max_bytes);

/**
 * 虚基类，提供连接管理功能
 * */
class BaseClient {
 public:
  BaseClient();

  virtual ~BaseClient();

  /**
   * 连接 kafka 具体 topic 中的一个 partition
   brokers: ip1:port1,ip2:port2, kafka地址
   topic_name: kafka topic name
   partition_id which partition to connect
   *
   * */
  bool Connect(const std::string &brokers,
               const std::string &topic_name,
               const int32 partition_id);

  static void AddToErrRKAddr(rd_kafka_t *&p);

 protected:

  bool Reconnect(void);

  // 不同的 client 需要重载此函数，在连接/重连时实现自己的配置设置
  virtual bool InitConf(void) {
    return true;
  }
  
  // comuser 和 producer 重载此函数表明身份
  virtual bool IsProducer(void) {
    return true;
  }

  // 创建连接实例
  bool CreateIns(void);

  // 销毁连接实例
  void DestoryIns(void);

  static void RemoveRKAddr(rd_kafka_t *&p);

  static bool NeedReconnect(rd_kafka_t *&p);

 protected:
  static base::Lock lock_;
  static std::unordered_set<rd_kafka_t*> err_rk_addrs_;

  char *errstr_;

  std::string broker_list_;
  std::string topic_name_;
  int32 partition_id_;

  rd_kafka_t *rk_;
  rd_kafka_conf_t *rk_conf_;
  rd_kafka_topic_t *rk_topic_;
  rd_kafka_topic_conf_t *rk_topic_conf_;

  DISALLOW_COPY_AND_ASSIGN(BaseClient);
};

}  // namespace kafka
}  // namespace reco

