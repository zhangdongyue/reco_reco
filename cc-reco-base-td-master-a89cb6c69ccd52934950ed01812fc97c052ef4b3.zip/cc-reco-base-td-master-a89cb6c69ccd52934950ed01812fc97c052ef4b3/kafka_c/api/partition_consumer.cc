#include "reco/base/kafka_c/api/partition_consumer.h"

#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "reco/base/kafka_c/api/util.h"

using std::string;

namespace reco {
namespace kafka {

// Globla conf
DEFINE_string(client_id, "rdkafka", "Client identifier.");
DEFINE_uint64(receive_message_max_bytes, 100000000, "Maximum receive message size.");
DEFINE_uint64(metadata_request_timeout_ms, 60000, "Non-topic request timeout in milliseconds.");
DEFINE_uint64(topic_metadata_refresh_interval_ms, 10000, "Topic metadata refresh interval in milliseconds");
DEFINE_uint64(topic_metadata_refresh_fast_cnt, 10, "");
DEFINE_uint64(topic_metadata_refresh_fast_interval_ms, 250, "");
DEFINE_string(topic_metadata_refresh_sparse, "false", "Sparse metadata requests");
DEFINE_uint64(socket_timeout_ms, 60000, "Timeout for network requests.");
DEFINE_uint64(socket_send_buffer_bytes, 0, "Broker socket send buffer size. System default is used if 0.");
DEFINE_uint64(socket_receive_buffer_bytes, 0,
              "Broker socket receive buffer size. System default is used if 0.");
DEFINE_string(socket_keepalive_enable, "true", "Enable TCP keep-alives");
DEFINE_uint64(socket_max_fails, 5, "Disconnect from broker when this number of send failures ");
DEFINE_uint64(broker_address_ttl, 300000, "How long to cache the broker address resolving results.");
DEFINE_uint64(statistics_interval_ms, 0, "librdkafka statistics emit interval.");
DEFINE_uint64(log_level, 6, "Logging level, 7-debug");
DEFINE_uint64(queued_min_messages, 100000, "Minimum number of messages per topic+partition");
DEFINE_uint64(queued_max_messages_kbytes, 1000000, "Maximum number of kilobytes per topic+partition");
DEFINE_uint64(fetch_wait_max_ms, 500, "Maximum time the broker may wait to fill the response.");
DEFINE_uint64(fetch_message_max_bytes, 1048576, "Maximum number of bytes per topic+partition.");
DEFINE_uint64(fetch_min_bytes, 1, "Minimum number of bytes the broker responds");
DEFINE_uint64(fetch_error_backoff_ms, 500, "How long to postpone the next fetch request");

// Topic conf
DEFINE_string(auto_commit_enable, "true", "If true, periodically commit offset of the last message");
DEFINE_uint64(auto_commit_interval_ms, 60000, "The frequency in milliseconds that the consumer offsets");
DEFINE_string(offset_store_path, ".", "Path to local file for storing offsets.");
DEFINE_uint64(offset_store_sync_interval_ms, 500, "fsync() interval for the offset file, in milliseconds. \
              Use -1 to disable syncing");
DEFINE_string(offset_store_method, "file", "\"file\"-local file store; \"broker\"-broker commit store");

const int kErrStrLen = 512;

bool PartitionConsumer::InitConf() {
  bool ret = true;

  if (rk_conf_) {
    rd_kafka_conf_destroy(rk_conf_);
    rk_conf_ = NULL;
  }

  rk_conf_ = rd_kafka_conf_new();
  if (rk_conf_ == NULL) {
    LOG(ERROR) << "new conf failed";
    return false;
  }

  if (rk_topic_conf_) {
    rd_kafka_topic_conf_destroy(rk_topic_conf_);
    rk_topic_conf_ = NULL;
  }

  rk_topic_conf_ = rd_kafka_topic_conf_new();
  if (rk_topic_conf_ == NULL) {
    LOG(ERROR) << "new topic conf failed";
  }

  // Set Kafka Conf
  if (!FLAGS_kafak_debug.empty()) {
    ret = ret | SetConfParam(rk_conf_, "debug", FLAGS_kafak_debug);
  }

  ret = ret | SetConfParam(rk_conf_, "client.id", FLAGS_client_id);
  ret = ret | SetConfParam(rk_conf_, "message.max.bytes", base::Uint64ToString(FLAGS_message_max_bytes));
  ret = ret | SetConfParam(rk_conf_, "receive.message.max.bytes",
                           base::Uint64ToString(FLAGS_receive_message_max_bytes));
  ret = ret | SetConfParam(rk_conf_, "metadata.request.timeout.ms",
                           base::Uint64ToString(FLAGS_metadata_request_timeout_ms));
  ret = ret | SetConfParam(rk_conf_, "topic.metadata.refresh.interval.ms",
                           base::Uint64ToString(FLAGS_topic_metadata_refresh_interval_ms));
  ret = ret | SetConfParam(rk_conf_, "topic.metadata.refresh.fast.cnt",
                           base::Uint64ToString(FLAGS_topic_metadata_refresh_fast_cnt));
  ret = ret | SetConfParam(rk_conf_, "topic.metadata.refresh.fast.interval.ms",
                           base::Uint64ToString(FLAGS_topic_metadata_refresh_fast_interval_ms));
  ret = ret | SetConfParam(rk_conf_, "topic.metadata.refresh.sparse",
                           FLAGS_topic_metadata_refresh_sparse);
  ret = ret | SetConfParam(rk_conf_, "socket.timeout.ms",
                           base::Uint64ToString(FLAGS_socket_timeout_ms));
  ret = ret | SetConfParam(rk_conf_, "socket.send.buffer.bytes",
                           base::Uint64ToString(FLAGS_socket_send_buffer_bytes));
  ret = ret | SetConfParam(rk_conf_, "socket.receive.buffer.bytes",
                           base::Uint64ToString(FLAGS_socket_receive_buffer_bytes));
  ret = ret | SetConfParam(rk_conf_, "socket.keepalive.enable",
                           FLAGS_socket_keepalive_enable);
  ret = ret | SetConfParam(rk_conf_, "socket.max.fails",
                           base::Uint64ToString(FLAGS_socket_max_fails));
  ret = ret | SetConfParam(rk_conf_, "broker.address.ttl",
                           base::Uint64ToString(FLAGS_broker_address_ttl));
  ret = ret | SetConfParam(rk_conf_, "statistics.interval.ms",
                           base::Uint64ToString(FLAGS_statistics_interval_ms));
  ret = ret | SetConfParam(rk_conf_, "log_level",
                           base::Uint64ToString(FLAGS_log_level));
  ret = ret | SetConfParam(rk_conf_, "queued.min.messages",
                           base::Uint64ToString(FLAGS_queued_min_messages));
  ret = ret | SetConfParam(rk_conf_, "queued.max.messages.kbytes",
                           base::Uint64ToString(FLAGS_queued_max_messages_kbytes));
  ret = ret | SetConfParam(rk_conf_, "fetch.wait.max.ms",
                           base::Uint64ToString(FLAGS_fetch_wait_max_ms));
  ret = ret | SetConfParam(rk_conf_, "fetch.message.max.bytes",
                           base::Uint64ToString(FLAGS_fetch_message_max_bytes));
  ret = ret | SetConfParam(rk_conf_, "fetch.min.bytes",
                           base::Uint64ToString(FLAGS_fetch_min_bytes));
  ret = ret | SetConfParam(rk_conf_, "fetch.error.backoff.ms",
                           base::Uint64ToString(FLAGS_fetch_error_backoff_ms));

  // Set Topic Conf
  ret = ret | SetTopicConfParam(rk_topic_conf_, "auto.commit.enable", FLAGS_auto_commit_enable);
  ret = ret | SetTopicConfParam(rk_topic_conf_, "auto.commit.interval.ms",
                                base::Uint64ToString(FLAGS_auto_commit_interval_ms));
  ret = ret | SetTopicConfParam(rk_topic_conf_, "offset.store.path", FLAGS_offset_store_path);
  ret = ret | SetTopicConfParam(rk_topic_conf_, "offset.store.sync.interval.ms",
                                base::Uint64ToString(FLAGS_offset_store_sync_interval_ms));
  ret = ret | SetTopicConfParam(rk_topic_conf_, "offset.store.method", FLAGS_offset_store_method);

  // dump conf
  if (!FLAGS_kafak_debug.empty() && ret) {
    DumpConf(rk_conf_);
    DumpTopicConf(rk_topic_conf_);
  }

  return ret;
}

bool PartitionConsumer::ResetOffset(const int64 offset) {
  if (rk_topic_ == NULL) {
    LOG(ERROR) << "topic is null";
    return false;
  }

  if (consumer_started_) {
    // 需要先 stop， 重新设置 offset 才有效果, 否则还是继续原来的读取
    if (rd_kafka_consume_stop(rk_topic_, partition_id_) == -1) {
      LOG(WARNING) << "Failed to stop consuming. " << rd_kafka_err2str(rd_kafka_errno2err(errno));
      return false;
    }
  }

   // rd_kafka_consume_start()` must not be called multiple times for the same
   // topic and partition without stopping consumption first with
   // rd_kafka_consume_stop()`.
  if (rd_kafka_consume_start(rk_topic_, partition_id_, offset) == -1) {
    LOG(ERROR) << "Failed to start consuming. " << rd_kafka_err2str(rd_kafka_errno2err(errno));
    return false;
  }
  consumer_started_ = true;

  // LOG(INFO) << "start consume, topic name is: " << topic_name_
  //           << ", partition is: " << partition_id_
  //           << ", offset is: " << offset;
  return true;
}

bool PartitionConsumer::Fetch(const uint32_t timeout_ms, string *msg, int64 *offset) {
  bool ret = true;

  if (!consumer_started_) {
    return false;
  }

  rd_kafka_message_t *rkmessage = NULL;
  rkmessage = rd_kafka_consume(rk_topic_, partition_id_, timeout_ms);
  if (!rkmessage) {
    ret = false;
    rd_kafka_poll(rk_, 100);

    if (NeedReconnect(rk_)) {
      base::SleepForMilliseconds(100);
      Reconnect();
      return false;
    }

    // timeout
    VLOG(1) << "kafka name is: " << rd_kafka_name(rk_)
              << ", topic name is: " << topic_name_
              << ", fetch msg timeout.";
    return false;
  }

  // check err
  if (rkmessage->err) {
    ret = false;
    if (rkmessage->err == RD_KAFKA_RESP_ERR__PARTITION_EOF) {
      DLOG(INFO) << "PartitionConsumer reached end of topic: " << rd_kafka_topic_name(rkmessage->rkt)
          << ", partition is: " << rkmessage->partition
          << ", offset is: " << rkmessage->offset;
      base::SleepForMilliseconds(timeout_ms);
    } else {
      LOG(ERROR) << "Consume error for topic: " << rd_kafka_topic_name(rkmessage->rkt)
          << ", partition is: " << rkmessage->partition
          << ", offset is: " << rkmessage->offset;
    }
  }

  if (ret) {
    if (offset) {
      *offset = rkmessage->offset;
    }

    if (msg) {
      if (rkmessage->len) {
        *msg = string(reinterpret_cast<char*>(rkmessage->payload), rkmessage->len);
      } else {
        msg->clear();
      }
    }
  }

  rd_kafka_message_destroy(rkmessage);
  return ret;
}

}  // namespace kafka
}  // namespace reco

