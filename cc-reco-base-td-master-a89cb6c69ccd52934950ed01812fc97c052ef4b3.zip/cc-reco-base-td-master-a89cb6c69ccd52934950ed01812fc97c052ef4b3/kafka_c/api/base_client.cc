#include "reco/base/kafka_c/api/base_client.h"

#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"

namespace reco {
namespace kafka {

DEFINE_string(kafak_debug, "", "debug info: all,generic,broker,topic,metadata,producer,queue,msg,protocol");
DEFINE_uint64(message_max_bytes, 4000000,
              "Maximum transmit message size.");

const int kErrStrLen = 512;

base::Lock BaseClient::lock_;
std::unordered_set<rd_kafka_t*> BaseClient::err_rk_addrs_;

static void error_cb(rd_kafka_t *rk, int err, const char *reason, void *opaque) {
  LOG(ERROR) << "kafka error, kafka name is:" << rd_kafka_name(rk)
             << ", err is: " << err
             << ", reason is: " << reason;
  BaseClient::AddToErrRKAddr(rk);
  return;
}

static void logger(const rd_kafka_t *rk, int level, const char *fac, const char *buf) {
  LOG(INFO) << "# RDKAFKA-" << level << "-" << fac
            << ", kafka_name is: " << rd_kafka_name(rk)
            << "msg is : " << buf;
  return;
}

BaseClient::BaseClient() {
  errstr_ = new char[kErrStrLen];
  memset(errstr_, 0, kErrStrLen);

  partition_id_ = -1;

  rk_ = NULL;
  rk_conf_ = NULL;
  rk_topic_ = NULL;
  rk_topic_conf_ = NULL;
}

BaseClient::~BaseClient() {
  if (rk_conf_) {
    rd_kafka_conf_destroy(rk_conf_);
    rk_conf_ = NULL;
  }

  if (rk_topic_conf_) {
    rd_kafka_topic_conf_destroy(rk_topic_conf_);
    rk_topic_conf_ = NULL;
  }

  DestoryIns();

  if (errstr_) {
    delete [] errstr_;
    errstr_ = NULL;
  }
}

bool BaseClient::NeedReconnect(rd_kafka_t *&p) {
  base::AutoLock auto_lock(lock_);
  if (err_rk_addrs_.find(p) != err_rk_addrs_.end()) {
    return true;
  }

  return false;
}

void BaseClient::RemoveRKAddr(rd_kafka_t *&p) {
  base::AutoLock auto_lock(lock_);
  err_rk_addrs_.erase(p);
}

void BaseClient::AddToErrRKAddr(rd_kafka_t *&p) {
  base::AutoLock auto_lock(lock_);
  err_rk_addrs_.insert(p);
}

bool BaseClient::Connect(const std::string &brokers,
                         const std::string &topic_name,
                         const int32 partition_id) {
  bool ret = true;

  if (brokers.empty()) {
    LOG(ERROR) << "broker list is null.";
    return false;
  }
  broker_list_ = brokers;

  if (topic_name.empty()) {
    LOG(ERROR) << "topic name is null.";
    return false;
  }
  topic_name_ = topic_name;

  partition_id_ = partition_id;

  LOG(INFO) << "connect kafka, brokers is: " << brokers
            << ", topic_name is: " << topic_name
            << ", partition is: " << partition_id;

  ret = Reconnect();

  return ret;
}

bool BaseClient::Reconnect() {
  DestoryIns();

  while (!CreateIns()) {
    DestoryIns();
    LOG(WARNING) << "connect broker error, broker list is: " << broker_list_
                 << ", reconnect...";
    base::SleepForMilliseconds(1000);
  }

  return true;
}

bool BaseClient::CreateIns() {
  // init conf
  if (!InitConf()) {
    LOG(ERROR) << "init conf error!";
    return false;
  }

  // set erro cb
  rd_kafka_conf_set_error_cb(rk_conf_, error_cb);

  // Create Kafka handle
  // warning: the internal implementation free(kafka_conf_)
  if (IsProducer()) {
    rk_ = rd_kafka_new(RD_KAFKA_PRODUCER, rk_conf_, errstr_, kErrStrLen);
  } else {
    rk_ = rd_kafka_new(RD_KAFKA_CONSUMER, rk_conf_, errstr_, kErrStrLen);
  }

  // Set logger
  // rd_kafka_set_logger(rk_, logger);
  rd_kafka_conf_set_log_cb(rk_conf_, logger);

  if (!rk_) {
    LOG(ERROR) << "Failed to create kafka client, msg is:" << errstr_;
    return false;
  } else {
    rk_conf_ = NULL;
  }

  // Add brokers
  if (rd_kafka_brokers_add(rk_, broker_list_.c_str()) == 0) {
    LOG(ERROR) << "No valid brokers specified, brokers: " << broker_list_;
    return false;
  }

  // Create topic
  // warning: the internal implementation free(topic_conf_)
  rk_topic_ = rd_kafka_topic_new(rk_, topic_name_.c_str(), rk_topic_conf_);
  if (!rk_topic_) {
    LOG(ERROR) << "Failed to create new topic";
    return false;
  } else {
    rk_topic_conf_ = NULL;
  }

  return true;
}

void BaseClient::DestoryIns() {
  LOG(INFO) << "Disconnect, topic_name is: " << topic_name_;

  if (rk_) {
    while (rd_kafka_outq_len(rk_) > 0) {
      rd_kafka_poll(rk_, 50);
      LOG_EVERY_N(INFO, 1000) << "wait for kafka poll";
    }
  }

  if (rk_topic_ && !IsProducer()) {
    rd_kafka_consume_stop(rk_topic_, partition_id_);
  }

  // Destroy topic
  if (rk_topic_) {
    rd_kafka_topic_destroy(rk_topic_);
    rk_topic_ = NULL;
  }

  // Destroy handle
  if (rk_) {
    RemoveRKAddr(rk_);
    rd_kafka_destroy(rk_);
    rk_ = NULL;
  }

  rd_kafka_wait_destroyed(2000);

  return;
}

}  // namespace kafka
}  // namespace reco


