#pragma once

#include <string>
// #include <boost/noncopyable.hpp>
#include <unordered_map>

#include "third_party/librdkafka/include/rdkafka.h"
#include "reco/base/kafka_c/api/base_client.h"
#include "base/testing/gtest_prod.h"

namespace reco {
namespace kafka {

/**
 * 生产 topic 的一个 partition
 * 非多线程安全
 *
 * 使用时，要先调用基类的
 * bool Connect(const std::string &brokers,
 *              const std::string &topic_name,
 *              const int32 partition_id);
 *
 * */
class PartitionProducer : public BaseClient {
 public:
  PartitionProducer() {}
  virtual ~PartitionProducer() {};

  // 推送消息
  bool Push(const std::string &data);

 private:
  FRIEND_TEST(KafkaTest, Reconnect);

  virtual bool InitConf(void);
  virtual bool IsProducer(void) {
    return true;
  }
};

}  // namespace kafak
}  // namespace reco

