#pragma once

#include <string>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/thread/internal/synchronization/lock.h"
#include "third_party/librdkafka/include/rdkafka.h"
#include "reco/base/kafka_c/api/base_client.h"
#include "base/testing/gtest_prod.h"

namespace reco {
namespace kafka {

// 设置本地存储 offset 文件的目录
DECLARE_string(offset_store_path);

/**
 * 消费 topic 的一个 partition
 * 非多线程安全
 *
 * 使用时，要先调用基类的
 * bool Connect(const std::string &brokers,
 *              const std::string &topic_name,
 *              const int32 partition_id);
 *
 * */
class PartitionConsumer : public BaseClient {
 public:
  PartitionConsumer() {
    consumer_started_ = false;
  }
  virtual ~PartitionConsumer() {};


  /**
   * 本函数巨坑，要小心
   *
   * toppar: topic partition
   *
   * offset 取值有以下几种
   * RD_KAFKA_OFFSET_BEGINNING (取值为-2) : 从 toppar 开头读取
   * RD_KAFKA_OFFSET_END (取值为-1): 从 toppar 尾部读取，要有新数据来才能读到
   *    且第一次读取的时候会因为达到队尾而失败(即使马上有人推)
   * RD_KAFKA_OFFSET_TAIL(cnt) : 这是一个宏。表示从最尾部的第 cnt 个开始读
   * RD_KAFKA_OFFSET_STORED : 从 store 文件里记录的offset开始读取，offset要求
   *    是 unsgined long型。 解析失败或文件读取失败会从 toppar 尾部来读。
   *    offset 文件会保存在 FLAGS_offset_store_path/${topic}-${partition}.offset
   *    实际读取的内容会是记录的 offset+1 (区别于下面一种方式)
   * other value (>=0) : 直接指定某个位置开始读
   *
   * 内部会把 consumer stop， 再 start
   * 
   * ResetOffset 和 fetch 不要在不同线程调用
   *
   * */
  bool ResetOffset(const int64 offset);

  // 获取消息并移动读取的offset，返回消息 msg 和消费后的 offset
  // msg: if not NULL return msg
  // offset: if not NULL return offset of the msg
  bool Fetch(const uint32 timeout_ms, std::string *msg = NULL, int64 *offset = NULL);

 private:
  FRIEND_TEST(KafkaTest, Reconnect);

  virtual bool InitConf(void);
  virtual bool IsProducer(void) {
    return false;
  }

  DISALLOW_COPY_AND_ASSIGN(PartitionConsumer);

  bool consumer_started_;
};

}  // namespace kafka
}  // namespace reco

