#include "reco/base/kafka_c/api/partition_producer.h"
#include "reco/base/kafka_c/api/util.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"

namespace reco {
namespace kafka {

DEFINE_uint64(queue_buffering_max_messages, 100000,
              "Maximum number of messages allowed on the producer queue.");
DEFINE_uint64(queue_buffering_max_ms, 1000,
              "Maximum time, in milliseconds, for buffering data on the producer queue.");
DEFINE_uint64(message_send_max_retries, 2,
              "How many times to retry sending a failing MessageSet. Note: retrying may cause reordering.");
DEFINE_uint64(retry_backoff_ms, 2,
              "The backoff time in milliseconds before retrying a message send.");
DEFINE_string(compression_codec, "snappy",
              "Compression codec to use for compressing message sets: none, gzip or snappy.");
DEFINE_uint64(batch_num_messages, 1000,
              "Maximum number of messages batched in one MessageSet.");

bool PartitionProducer::InitConf() {
  bool ret = true;

  if (rk_conf_) {
    rd_kafka_conf_destroy(rk_conf_);
    rk_conf_ = NULL;
  }

  rk_conf_ = rd_kafka_conf_new();
  if (rk_conf_ == NULL) {
    LOG(ERROR) << "new conf failed";
    return false;
  }

  if (rk_topic_conf_) {
    rd_kafka_topic_conf_destroy(rk_topic_conf_);
    rk_topic_conf_ = NULL;
  }

  rk_topic_conf_ = rd_kafka_topic_conf_new();
  if (rk_topic_conf_ == NULL) {
    LOG(ERROR) << "new topic conf failed";
  }

  rd_kafka_conf_set_dr_cb(rk_conf_, delivery_cb);

  // Set Kafka Conf
  if (!FLAGS_kafak_debug.empty()) {
    ret = ret | SetConfParam(rk_conf_, "debug", FLAGS_kafak_debug);
  }

  ret = ret | SetConfParam(rk_conf_, "message.max.bytes",
                           base::Uint64ToString(FLAGS_message_max_bytes));
  ret = ret | SetConfParam(rk_conf_, "queue.buffering.max.messages",
                           base::Uint64ToString(FLAGS_queue_buffering_max_messages));
  ret = ret | SetConfParam(rk_conf_, "queue.buffering.max.ms",
                           base::Uint64ToString(FLAGS_queue_buffering_max_ms));
  ret = ret | SetConfParam(rk_conf_, "message.send.max.retries",
                           base::Uint64ToString(FLAGS_message_send_max_retries));
  ret = ret | SetConfParam(rk_conf_, "retry.backoff.ms",
                           base::Uint64ToString(FLAGS_retry_backoff_ms));
  ret = ret | SetConfParam(rk_conf_, "compression.codec",
                           FLAGS_compression_codec);
  ret = ret | SetConfParam(rk_conf_, "batch.num.messages",
                           base::Uint64ToString(FLAGS_batch_num_messages));

  // Set Topic Conf

  // dump conf
  if (!FLAGS_kafak_debug.empty() && ret) {
    DumpConf(rk_conf_);
    DumpTopicConf(rk_topic_conf_);
  }

  return ret;
}


bool PartitionProducer::Push(const std::string &data) {
  bool ret = true;

  if (rd_kafka_produce(rk_topic_, partition_id_,
                       RD_KAFKA_MSG_F_COPY,
                       const_cast<char*>(data.c_str()), data.size(),
                       NULL, 0, NULL) == -1) {
    LOG(WARNING) << base::StringPrintf("# Failed to produce to topic %s partition %d: %s",
                                       rd_kafka_topic_name(rk_topic_), partition_id_,
                 rd_kafka_err2str(rd_kafka_errno2err(errno)));
    ret = false;
  }

  VLOG(1) << base::StringPrintf("send kafka data, partition=[%d], data size=[%lu]",
                                   partition_id_, data.size());

  /* Poll to handle delivery reports */
  rd_kafka_poll(rk_, 0);

  return ret;
}

}  // namespace kafka
}  // namespace reco

