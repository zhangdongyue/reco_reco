#include "reco/base/kafka_c/api/util.h"

#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "base/common/logging.h"

namespace reco {
namespace kafka {

bool SetConfParam(rd_kafka_conf_t *rk_conf, const std::string &name, const std::string &value) {
  char err[512];
  if (rd_kafka_conf_set(rk_conf, name.c_str(), value.c_str(), err, 512) != RD_KAFKA_CONF_OK) {
    LOG(ERROR) << "set conf param error, param name is: " << name
               << ", value is: " << value << ", msg is: " << err;
    return false;
  }

  return true;
}

void DumpConf(rd_kafka_conf_t *rk_conf) {
  const char **arr;
  size_t cnt;
  arr = rd_kafka_conf_dump(rk_conf, &cnt);
  for (size_t i = 0; i < cnt; i+=2) {
    LOG(INFO) << "# " << arr[i] << " = " << arr[i+1];
  }
  ::google::FlushLogFiles(::google::INFO);

  rd_kafka_conf_dump_free(arr, cnt);
}

bool SetTopicConfParam(rd_kafka_topic_conf_t *topic_conf, const std::string &name, const std::string &value) {
  char err[512];
  if (rd_kafka_topic_conf_set(topic_conf, name.c_str(), value.c_str(),
                              err, 512) != RD_KAFKA_CONF_OK) {
    LOG(ERROR) << "set topic conf param error, param name is: " << name
               << ", value is: " << value << ", msg is: " << err;
    return false;
  }

  return true;
}

void DumpTopicConf(rd_kafka_topic_conf_t *rk_topic_conf) {
  const char **arr;
  size_t cnt;
  arr = rd_kafka_topic_conf_dump(rk_topic_conf, &cnt);
  for (size_t i = 0; i < cnt; i+=2) {
    LOG(INFO) << "# " << arr[i] << " = " << arr[i+1];
  }
  ::google::FlushLogFiles(::google::INFO);
  rd_kafka_conf_dump_free(arr, cnt);
}

void logger_cb(const rd_kafka_t *rk, int level, const char *fac, const char *buf) {
  LOG(INFO) << "# RDKAFKA-" << level << "-" << fac
            << ", kafka_name is: " << rd_kafka_name(rk)
            << "msg is : " << buf;
  return;
}

void delivery_cb(rd_kafka_t *rk,
                 void *payload, size_t len, rd_kafka_resp_err_t error_code,
                 void *opaque, void *msg_opaque) {
  if (error_code) {
    LOG(WARNING) << "# Message delivery failed:" << rd_kafka_err2str(error_code);
  }

  return;
}

}  // namespace kafka
}  // namespace reco

