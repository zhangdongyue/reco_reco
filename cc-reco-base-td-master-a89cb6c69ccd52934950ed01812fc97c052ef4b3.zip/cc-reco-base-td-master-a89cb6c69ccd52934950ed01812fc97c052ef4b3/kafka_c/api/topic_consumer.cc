#include "reco/base/kafka_c/api/topic_consumer.h"

#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "reco/base/kafka_c/api/partition_consumer.h"
#include "base/common/closure.h"

namespace reco {
namespace kafka {

DEFINE_uint64(partition_buffered_msgs, 10, "每个 partition 预读缓存的消息数");

TopicConsumer::TopicConsumer(const std::string &brokers,
                             const std::string &topic_name,
                             const int32 total_partition) {
  total_partition_ = total_partition;
  is_running_ = true;
  partition_consumers_ = new PartitionConsumer[total_partition];
  mutexes_ = new thread::Mutex[total_partition];
  thread_pool_ = new thread::ThreadPool(total_partition);
  for (int i = 0; i < total_partition; ++i) {
    CHECK(partition_consumers_[i].Connect(brokers, topic_name, i));
    thread_pool_->AddTask(::NewCallback(this, &TopicConsumer::PartitionWorker, i));
  }
}

TopicConsumer::~TopicConsumer() {
  is_running_ = false;

  thread_pool_->JoinAll();
  delete thread_pool_;
  delete [] partition_consumers_;
  delete [] mutexes_;
}

void TopicConsumer::PartitionWorker(int partition_id) {
  PartitionConsumer& pc = partition_consumers_[partition_id];
  int buffer_size = total_partition_ * FLAGS_partition_buffered_msgs;
  while (is_running_) {
    if (buffer_.Size() > buffer_size) {
      base::SleepForMilliseconds(100);
      // LOG(INFO) << "buffer full";
      continue;
    }

    thread::AutoLock(mutexes_ + partition_id);
    std::string message;
    int64 offset;
    if (pc.Fetch(100, &message, &offset)) {
      buffer_.Put(message);
      // LOG(INFO) << "fetch: " << message;
    } else {
      base::SleepForMilliseconds(10);
      // LOG(INFO) << "nothing";
    }
  }
}

bool TopicConsumer::Fetch(std::string* message, int64 timeout_ms) {
  message->clear();
  if (timeout_ms == 0) {
    int ret = buffer_.TryTake(message);
    return ret == 1;
  } else if (timeout_ms == -1) {
    *message = buffer_.Take();
    return true;
  } else {
    int ret = buffer_.TimedTake(timeout_ms, message);
    return ret == 1;
  }
}

void TopicConsumer::SetOffsetToBeginning() {
  for (int i = 0; i < total_partition_; ++i) {
    thread::AutoLock(mutexes_+i);
    partition_consumers_[i].ResetOffset(RD_KAFKA_OFFSET_BEGINNING);
  }
}

void TopicConsumer::SetOffsetToEnd() {
  for (int i = 0; i < total_partition_; ++i) {
    thread::AutoLock(mutexes_+i);
    partition_consumers_[i].ResetOffset(RD_KAFKA_OFFSET_END);
  }
}

void TopicConsumer::SetOffsetToStored() {
  for (int i = 0; i < total_partition_; ++i) {
    thread::AutoLock(mutexes_+i);
    partition_consumers_[i].ResetOffset(RD_KAFKA_OFFSET_STORED);
  }
}

void TopicConsumer::SetOffsetToTailN(int n) {
  for (int i = 0; i < total_partition_; ++i) {
    thread::AutoLock(mutexes_+i);
    partition_consumers_[i].ResetOffset(RD_KAFKA_OFFSET_TAIL(n));
  }
}

}  // namespace kafka
}  // namespace reco

