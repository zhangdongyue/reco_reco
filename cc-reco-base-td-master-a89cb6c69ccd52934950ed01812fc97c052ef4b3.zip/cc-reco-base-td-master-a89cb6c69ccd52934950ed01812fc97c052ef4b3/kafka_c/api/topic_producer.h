#pragma once

#include <string>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/thread/internal/synchronization/lock.h"
#include "third_party/librdkafka/include/rdkafka.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"
#include "base/thread/blocking_queue.h"
#include "base/testing/gtest_prod.h"

namespace reco {
namespace kafka {

class PartitionProducer;

/**
 *
 * 写 topic 的所有 partition
 *
 * 调用示例：
 *  TopicProducer producer("127.0.0.1:9092", "topic", 32);
 *  producer.Push(0, "data");
 *
 *  非多线程安全
 *
 * */
class TopicProducer {
 public:
  // brokers: ip1:port1,ip2:port2, kafka地址
  // topic_name: kafka topic name
  // total_partition: 该 topic 拥有的partition数目
  TopicProducer(const std::string &brokers,
                const std::string &topic_name,
                const int32 total_partition);

  ~TopicProducer();

  /**
   * partiton key: 用来决定数据落到哪个partition, kafka 保证一个 partition 内的数据有序
   * 一般一个 item， 一个用户的数据要落到一个 partition 保证读取的顺序是写入顺序
   * */
  bool Push(uint64 partition_key, const std::string& message);

 private:
  PartitionProducer* partition_producers_;
  int32 total_partition_;

  DISALLOW_COPY_AND_ASSIGN(TopicProducer);
};

}  // namespace kafka
}  // namespace reco

