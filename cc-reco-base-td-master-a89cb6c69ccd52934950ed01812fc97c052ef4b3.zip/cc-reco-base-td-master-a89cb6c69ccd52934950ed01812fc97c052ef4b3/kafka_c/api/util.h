#pragma once

#include <string>
// #include <boost/noncopyable.hpp>
#include <unordered_map>
#include "third_party/librdkafka/include/rdkafka.h"

namespace reco {
namespace kafka {

bool SetConfParam(rd_kafka_conf_t *rk_conf, const std::string &name, const std::string &value);
void DumpConf(rd_kafka_conf_t *rk_conf);

bool SetTopicConfParam(rd_kafka_topic_conf_t *rk_topic_conf,
                       const std::string &name, const std::string &value);
void DumpTopicConf(rd_kafka_topic_conf_t *rk_topic_conf);

void logger_cb(rd_kafka_t *rk, int level, const char *fac, const char *buf);
void delivery_cb(rd_kafka_t *rk,
                 void *payload, size_t len, rd_kafka_resp_err_t error_code,
                 void *opaque, void *msg_opaque);

}  // namespace kafka
}  // namespace reco
