#include "reco/base/kafka_c/api/topic_producer.h"

#include "base/common/sleep.h"
#include "base/strings/string_number_conversions.h"
#include "reco/base/kafka_c/api/partition_producer.h"
#include "base/common/closure.h"

namespace reco {
namespace kafka {

TopicProducer::TopicProducer(const std::string &brokers,
                             const std::string &topic_name,
                             const int32 total_partition) {
  total_partition_ = total_partition;
  partition_producers_ = new PartitionProducer[total_partition];
  for (int i = 0; i < total_partition; ++i) {
    CHECK(partition_producers_[i].Connect(brokers, topic_name, i));
  }
}

TopicProducer::~TopicProducer() {
  delete [] partition_producers_;
}

bool TopicProducer::Push(uint64 partition_key, const std::string& message) {
  int partition_id = partition_key % total_partition_;
  return partition_producers_[partition_id].Push(message);
}

}  // namespace kafka
}  // namespace reco

