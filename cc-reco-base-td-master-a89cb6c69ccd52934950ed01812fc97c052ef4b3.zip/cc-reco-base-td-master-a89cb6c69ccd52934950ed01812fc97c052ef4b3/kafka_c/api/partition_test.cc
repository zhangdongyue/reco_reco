#include "reco/base/kafka_c/api/partition_consumer.h"
#include "reco/base/kafka_c/api/partition_producer.h"

#include <map>

#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "base/common/base.h"
#include "serving_base/utility/time_helper.h"
#include "base/common/sleep.h"
#include "base/file/file_path.h"
#include "base/file/file_util.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_number_conversions.h"
#include "base/random/pseudo_random.h"
#include "base/time/timestamp.h"

namespace reco {
namespace kafka {

class KafkaTest : public testing::Test {
 public:
  virtual void SetUp() {
    brokers_ = "100.85.69.55:9092,100.85.69.70:9092";
    topic_name_ = "rdkafka_test";
    total_partition_ = 32;
  }

  virtual void TearDown() {}

  std::string brokers_;
  std::string topic_name_;
  int total_partition_;
};


TEST_F(KafkaTest, Reconnect) {
  for (int i = 0; i < 5; ++i) {
    PartitionConsumer consumer;
    ASSERT_TRUE(consumer.Connect(brokers_, topic_name_, i));
    for (int j = 0; j < 3; ++j) {
      ASSERT_TRUE(consumer.Reconnect());
    }

    PartitionProducer producer;
    ASSERT_TRUE(producer.Connect(brokers_, topic_name_, i));
    for (int j = 0; j < 3; ++j) {
      ASSERT_TRUE(producer.Reconnect());
    }
  }
}

TEST_F(KafkaTest, Store) {
  PartitionProducer producer;
  PartitionConsumer consumer;
  ASSERT_TRUE(producer.Connect(brokers_, topic_name_, 1));
  ASSERT_TRUE(consumer.Connect(brokers_, topic_name_, 1));
  ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_STORED));
  consumer.Fetch(1000, NULL, NULL);

  for (int i = 0; i < 10; ++i) {
    EXPECT_TRUE(producer.Push("0"));
  }

  for (int i = 0; i< 10; ++i) {
    std::string data;
    int64 offset;
    EXPECT_TRUE(consumer.Fetch(1000, &data, &offset)) << i;
    EXPECT_STREQ(data.c_str(), "0") << i;
  }
}

TEST_F(KafkaTest, OffsetTail) {
  base::PseudoRandom rand(base::GetTimestamp());
  std::string push_data = base::Uint64ToString(rand.GetUint64());

  PartitionProducer producer;
  ASSERT_TRUE(producer.Connect(brokers_, topic_name_, 0));
  ASSERT_TRUE(producer.Push(push_data));

  PartitionConsumer consumer;
  ASSERT_TRUE(consumer.Connect(brokers_, topic_name_, 0));
  ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_TAIL(1)));
  std::string data;
  int64 offset;
  ASSERT_TRUE(consumer.Fetch(1000, &data, &offset));
  ASSERT_STREQ(data.c_str(), push_data.c_str());
}

TEST_F(KafkaTest, OffsetEnd) {
  base::PseudoRandom rand(base::GetTimestamp());
  std::string push_data = base::Uint64ToString(rand.GetUint64());

  PartitionConsumer consumer;
  ASSERT_TRUE(consumer.Connect(brokers_, topic_name_, 0));
  ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_END));
  // NOTE： (坑) 马上读取一次，避免首次读取时候的失败
  consumer.Fetch(1000, NULL, NULL);

  PartitionProducer producer;
  ASSERT_TRUE(producer.Connect(brokers_, topic_name_, 0));
  ASSERT_TRUE(producer.Push(push_data));

  base::SleepForSeconds(3);
  std::string data;
  int64 offset;
  ASSERT_TRUE(consumer.Fetch(1000, &data, &offset));
  ASSERT_STREQ(data.c_str(), push_data.c_str());
}

TEST_F(KafkaTest, ModifyOffset) {
  PartitionProducer producer;
  ASSERT_TRUE(producer.Connect(brokers_, topic_name_, 0));
  base::PseudoRandom rand(base::GetTimestamp());
  std::string data_list;
  for (int i = 0; i < 10; ++i) {
    std::string data = base::Uint64ToString(rand.GetUint64());
    EXPECT_TRUE(producer.Push(data));
    if (!data_list.empty()) {
      data_list.append(",");
    }
    data_list.append(data);
  }
  std::string push_data_list = data_list;

  // NOTE: (坑) 需要等 prdoucer 写完以后，再去构造 conumser，这样 TAIL 才准确
  // 如果跟 producer 一同构造，tail的位置不包含 producer 添加的这些条
  PartitionConsumer consumer;
  ASSERT_TRUE(consumer.Connect(brokers_, topic_name_, 0));
  ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_TAIL(10)));
  std::map<std::string, int64> offset_map;
  data_list.clear();
  for (int i = 0; i < 10; ++i) {
    std::string data;
    int64 offset;
    EXPECT_TRUE(consumer.Fetch(1000, &data, &offset));
    offset_map[data] = offset;
    if (!data_list.empty()) {
      data_list.append(",");
    }
    data_list.append(data);
  }
  ASSERT_STREQ(push_data_list.c_str(), data_list.c_str());

  for (auto it = offset_map.begin(); it != offset_map.end(); ++it) {
    ASSERT_TRUE(consumer.ResetOffset(it->second));
    std::string data;
    int64 offset;
    EXPECT_TRUE(consumer.Fetch(1000, &data, &offset));
    EXPECT_STREQ(it->first.c_str(), data.c_str())
        << it->first << ":" << it->second << " vs " << data << ":" << offset;
  }
}

TEST_F(KafkaTest, ModifyStoreFile) {
  PartitionProducer producer;
  ASSERT_TRUE(producer.Connect(brokers_, topic_name_, 0));
  base::PseudoRandom rand(base::GetTimestamp());
  std::string data_list;
  for (int i = 0; i < 10; ++i) {
    std::string data = base::Uint64ToString(rand.GetUint64());
    EXPECT_TRUE(producer.Push(data));
    if (!data_list.empty()) {
      data_list.append(",");
    }
    data_list.append(data);
  }
  std::string push_data_list = data_list;

  // NOTE: (坑) 需要等 prdoucer 写完以后，再去构造 conumser，这样 TAIL 才准确
  // 如果跟 producer 一同构造，tail的位置不包含 producer 添加的这些条
  PartitionConsumer consumer;
  ASSERT_TRUE(consumer.Connect(brokers_, topic_name_, 0));
  ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_TAIL(10)));
  std::map<std::string, int64> offset_map;
  data_list.clear();
  for (int i = 0; i < 10; ++i) {
    std::string data;
    int64 offset;
    EXPECT_TRUE(consumer.Fetch(1000, &data, &offset));
    offset_map[data] = offset;
    if (!data_list.empty()) {
      data_list.append(",");
    }
    data_list.append(data);
  }
  ASSERT_STREQ(push_data_list.c_str(), data_list.c_str());

  base::FilePath file(base::StringPrintf("%s-%d.offset", topic_name_.c_str(), 0));;
  for (auto it = offset_map.begin(); it != offset_map.end(); ++it) {
    // 调用 Reset，迫使内部 stop consumer，这样offset会被主动写入到文件中
    ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_BEGINNING));
    // 此时再更新文件，保证文件只被本单测写入
    // NOTE: (坑) 文件方式的 offset 是上一次地址， 直接设置的offset是本次读取地址
    std::string offset_str = base::Int64ToString(it->second - 1);
    // LOG(INFO) << offset_str;
    base::file_util::WriteFile(file, offset_str.c_str(), offset_str.size());
    ASSERT_TRUE(consumer.ResetOffset(RD_KAFKA_OFFSET_STORED));
    std::string data;
    int64 offset;
    EXPECT_TRUE(consumer.Fetch(1000, &data, &offset));
    EXPECT_STREQ(it->first.c_str(), data.c_str());
    LOG(INFO) << it->first << ":" << it->second << " vs " << data << ":" << offset;
    // std::string s;
    // base::file_util::ReadFileToString(file, &s);
    // LOG(INFO) << s;
  }
}

}  // namespace kafka
}  // namespace reco

