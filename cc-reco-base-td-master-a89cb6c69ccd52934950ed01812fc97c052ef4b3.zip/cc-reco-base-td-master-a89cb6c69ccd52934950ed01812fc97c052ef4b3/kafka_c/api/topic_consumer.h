#pragma once

#include <string>
#include <iostream>
#include <unordered_set>

#include "base/common/base.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/thread/internal/synchronization/lock.h"
#include "third_party/librdkafka/include/rdkafka.h"
#include "base/thread/thread_pool.h"
#include "base/thread/sync.h"
#include "base/thread/blocking_queue.h"
#include "base/testing/gtest_prod.h"

namespace reco {
namespace kafka {

class PartitionConsumer;

// default 10, 每个 partition 预读缓存的消息数
DECLARE_uint64(partition_buffered_msgs);

// NOTE: 暂未支持这两个
enum ConsumerModel {
  // In a queue, a pool of consumers may read from a server and each message goes to one of them;
  kQueuing,
  // In publish-subscribe the message is broadcast to all consumers
  kPublishSubscribe,
};

/**
 *
 * 读 topic 的所有 partition
 *
 * 内部会开启线程同时读多个 partition，并保存在内部的 buffer 里
 * 读取时可以保证同一个 partition 里的内容是按照写入的顺序被读出的
 *
 * 调用示例：
 *  TopicConsumer consumer("127.0.0.1:9092", "topic", 32);
 *  consumer.SetOffsetToStored();
 *  std::string data;
 *  consumer.Fetch(&data, 100);
 *
 *  非多线程安全
 *
 * */
class TopicConsumer {
 public:
  // brokers: ip1:port1,ip2:port2, kafka地址
  // topic_name: kafka topic name
  // total_partition: 该 topic 拥有的partition数目
  TopicConsumer(const std::string &brokers,
                const std::string &topic_name,
                const int32 total_partition);

  ~TopicConsumer();

  // NOTE: 需要调用以下三个函数之一， 才会启动读取
  // 从队列头部开始读取
  void SetOffsetToBeginning();
  // 从队列尾部开始读取（此时有新数据才会读到）
  void SetOffsetToEnd();
  // 从本机存储的 offset 文件开始读取。文件不存在或错误，会从队列尾部读
  void SetOffsetToStored();
  // 从队列尾部的 n 条数据开始读取
  void SetOffsetToTailN(int n);

  // timeout_ms: 0: no wait;  -1: wait forever
  // 成功读取 return true
  //
  // 这个类内部会起多个线程预读每个 toppar，
  // 预读条数由 FLAGS_partition_buffered_msgs 控制
  // 读取后会放 blocking queue。
  //
  // 这里的 fetch 其实是直接从 queue 里取
  //
  bool Fetch(std::string* message, int64 timeout_ms = 0);

 private:
  void PartitionWorker(int32 partiton_id);

  PartitionConsumer* partition_consumers_;
  thread::ThreadPool* thread_pool_;
  thread::Mutex* mutexes_;
  thread::BlockingQueue<std::string> buffer_;
  atomic<bool> is_running_;
  int32 total_partition_;

  DISALLOW_COPY_AND_ASSIGN(TopicConsumer);
};

}  // namespace kafka
}  // namespace reco

