#include "reco/base/kafka_c/api_cc/config.h"

#include <list>

#include "storage/base/process_util.h"

namespace reco {
namespace kafka {
DEFINE_bool(dump_conf, false, "");
DEFINE_bool(debug_kafka, false, "");
DEFINE_string(auto_offset_reset, "largest", "largest or smallest");
DEFINE_string(kafka_max_msg_size, "5242880", "");
DEFINE_string(kafka_compression_codec, "none", "none, gzip, snappy, lz4");

using std::string;

SimpleRebalanceCb GlobalConf::rebalance_cb_;
SimpleEventCb GlobalConf::event_cb_;
SimplePartitionerCb GlobalConf::partition_cb_;
SimpleDeliveryReportCb GlobalConf::delevery_cb_;

GlobalConf::GlobalConf(const std::string &brokers, const ConsumerOptions options) {
  brokers_ = brokers;
  consumer_options_ = options;
  errstr_.clear();

  conf_ = RdKafka::Conf::create(RdKafka::Conf::CONF_GLOBAL);
  tconf_ = RdKafka::Conf::create(RdKafka::Conf::CONF_TOPIC);

  CHECK(InitCommonConf()) << "init common conf fail.";
  CHECK(InitConsumerConf()) << "init consumer conf fail.";

  if (conf_->set("default_topic_conf", tconf_, errstr_) != RdKafka::Conf::CONF_OK) {
    CHECK(false) << "set conf error:" << errstr_;
  }

  DumpConf();
}

GlobalConf::GlobalConf(const std::string &brokers) {
  brokers_ = brokers;
  errstr_.clear();

  conf_ = RdKafka::Conf::create(RdKafka::Conf::CONF_GLOBAL);
  tconf_ = RdKafka::Conf::create(RdKafka::Conf::CONF_TOPIC);

  CHECK(InitCommonConf()) << "init common conf fail.";
  CHECK(InitProducerConf()) << "init producer conf fail.";

  DumpConf();
}

GlobalConf::~GlobalConf() {
  if (tconf_) {
    delete tconf_;
    tconf_ = NULL;
  }

  if (conf_) {
    delete conf_;
    conf_ = NULL;
  }
}

void GlobalConf::DumpConf() {
  if (!FLAGS_dump_conf)
    return;

  string msg;
  std::list<std::string> *dump;

  // global conf
  dump = conf_->dump();
  for (auto it = dump->begin(); it != dump->end(); ) {
    msg = *it + "=";
    ++it;
    msg += *it + " ";
    ++it;
    LOG(INFO) << "global conf:" << msg;
  }

  dump = tconf_->dump();
  for (auto it = dump->begin(); it != dump->end(); ) {
    msg = *it + "=";
    ++it;
    msg += *it + ".";
    ++it;
    LOG(INFO) << "topic conf:" << msg;
  }
}

bool GlobalConf::InitCommonConf() {
  errstr_.clear();
  if (conf_->set("metadata.broker.list", brokers_, errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  const string local_ip = base::GetLocalIP();
  if (conf_->set("client.id", local_ip, errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("group.id", consumer_options_.group_id, errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  // 5M
  if (conf_->set("message.max.bytes", FLAGS_kafka_max_msg_size, errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("receive.message.max.bytes", "500000000", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("log.thread.name", "true", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("event_cb", &GlobalConf::event_cb_, errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("api.version.request", "true", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("socket.keepalive.enable", "true", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("broker.address.ttl", "5000", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("fetch.wait.max.ms", "5000", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("compression.codec", FLAGS_kafka_compression_codec, errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (FLAGS_debug_kafka) {
    if (conf_->set("debug", "all", errstr_) != RdKafka::Conf::CONF_OK) {
      LOG(ERROR) << "set conf error:" << errstr_;
      return false;
    }
  }

  if (conf_->set("heartbeat.interval.ms", "2000", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  return true;
}

bool GlobalConf::InitConsumerConf() {
  errstr_.clear();

  /*
  if (conf_->set("session.timeout.ms", "2000", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }
  */

  if (conf_->set("enable.auto.commit", "true", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (tconf_->set("enable.auto.commit", "true", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (tconf_->set("auto.commit.interval.ms", "5000", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("enable.auto.offset.store", "true", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  // TODO(KouYan):
  if (conf_->set("queued.min.messages", "1", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("queued.max.messages.kbytes", "200000", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  // 5M
  if (conf_->set("fetch.message.max.bytes", "10485760", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("rebalance_cb", &GlobalConf::rebalance_cb_, errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("offset.store.method", "broker", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (tconf_->set("offset.store.method", "broker", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (tconf_->set("auto.offset.reset", FLAGS_auto_offset_reset, errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (tconf_->set("offset.store.sync.interval.ms", "2000", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  return true;
}

bool GlobalConf::InitProducerConf() {
  errstr_.clear();

  if (tconf_->set("partitioner_cb", &GlobalConf::partition_cb_, errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (tconf_->set("produce.offset.report", "true", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("dr_cb", &GlobalConf::delevery_cb_, errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("delivery.report.only.error", "false", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("message.send.max.retries", "20", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("retry.backoff.ms", "2000", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("batch.num.messages", "1000", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  if (conf_->set("queue.buffering.max.messages", "1000000", errstr_) != RdKafka::Conf::CONF_OK) {
    LOG(ERROR) << "set conf error:" << errstr_;
    return false;
  }

  return true;
}
}
}
