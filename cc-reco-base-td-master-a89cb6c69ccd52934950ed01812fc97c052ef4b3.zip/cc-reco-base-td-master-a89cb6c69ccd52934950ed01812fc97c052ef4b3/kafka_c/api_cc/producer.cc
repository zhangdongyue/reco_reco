#include "reco/base/kafka_c/api_cc/producer.h"

#include "base/strings/string_number_conversions.h"
#include "reco/base/kafka_c/api_cc/config.h"

using std::string;

namespace reco {
namespace kafka {

DEFINE_int64_counter(kafka, produce_outq_len, 0, "");
DEFINE_int64_counter(kafka, produce_op_num, 0, "");

Producer::Producer(const std::string &brokers, const std::string &topic)
  : producer_(NULL), topic_(NULL), need_reconnect_(true), stop_heartbeat_thread_(false) {
  brokers_ = brokers;
  topic_name_ = topic;

  CHECK(Connect()) << "connect brokers fail:" << brokers;

  retry_connect_thread_.Start(::NewCallback(this, &Producer::Reconnect));
}

bool Producer::Connect() {
  if (producer_) {
    producer_->poll(2000);
    delete producer_;
    producer_ = NULL;
  }

  if (topic_) {
    delete topic_;
    topic_ = NULL;
  }

  base::SleepForSeconds(1);
  string errstr;
  GlobalConf conf(brokers_);

  producer_ = RdKafka::Producer::create(conf.GetConf(), errstr);
  if (!producer_) {
    base::SleepForSeconds(1);
    LOG(ERROR) << "create producer fail. msg:" << errstr;
    return false;
  }
  LOG(INFO) << "create producer succ:" << producer_->name();

  errstr.clear();
  topic_ = RdKafka::Topic::create(producer_, topic_name_, conf.GetTConf(), errstr);
  if (!topic_) {
    base::SleepForSeconds(1);
    LOG(ERROR) << "create topic fail:" << errstr;
    return false;
  }

  LOG(INFO) << "create topic succ:" << topic_->name();
  need_reconnect_ = false;
  return true;
}

void Producer::Reconnect() {
  while (!stop_heartbeat_thread_) {
      if (need_reconnect_) {
        LOG(WARNING) << "retry reconnect!";
        Connect();
      }
    base::SleepForSeconds(1);
  }

  return;
}

Producer::~Producer() {
  stop_heartbeat_thread_ = true;
  retry_connect_thread_.Join();

  need_reconnect_ = false;

  if (producer_) {
    producer_->poll(1000);
    base::SleepForSeconds(1);
  }

  if (topic_) {
    delete topic_;
    topic_ = NULL;
  }

  if (producer_) {
    delete producer_;
    producer_ = NULL;
  }

  /*
   * Wait for RdKafka to decommission.
   * This is not strictly needed (when check outq_len() above), but
   * allows RdKafka to clean up all its resources before the application
   * exits so that memory profilers such as valgrind wont complain about
   * memory leaks.
   */
  // RdKafka::wait_destroyed(5000);
}

bool Producer::Produce(const std::string &msg, const std::string &key, const int partition_idx) {
  if (need_reconnect_) {
    LOG_EVERY_N(ERROR, 100) << "connect producer error.";
    return false;
  }

  RdKafka::ErrorCode err = producer_->produce(topic_,
                                              partition_idx,
                                              RdKafka::Producer::RK_MSG_COPY,
                                              const_cast<char*>(msg.c_str()),
                                              msg.size(),
                                              &key,
                                              NULL);

  if (err == RdKafka::ERR_NO_ERROR) {
    COUNTERS_kafka__produce_op_num.Increase(1);
    VLOG(2) << "succ, msg_len:" << msg.size();
    producer_->poll(0);

    // TODO(KouYan):
    // LOG_EVERY_N(INFO, 10) << "the number of events served:" << base::IntToString(producer_->poll(100));
    COUNTERS_kafka__produce_outq_len.Reset(producer_->outq_len());
  } else {
    LOG(ERROR) << "fail, err:" << err
               << ", info:" << RdKafka::err2str(err)
               << ", topic:" << topic_->name()
               << ", key:" << key;
    need_reconnect_ = true;
    return false;
  }

  return true;
}
}
}
