#include "reco/base/kafka_c/api_cc/consumer.h"

#include <vector>

#include "base/common/closure.h"
#include "base/time/timestamp.h"
#include "base/strings/string_util.h"
#include "base/thread/thread_pool.h"
#include "storage/base/process_util.h"

#include "reco/base/kafka_c/api_cc/config.h"

namespace reco {
namespace kafka {

DEFINE_int32(consumer_timeout, 10000, "");
DEFINE_int32(consumer_sleep_ms, 1000, "");

DEFINE_int64_counter(kafka, consume_op_num, 0, "");

using std::string;
using std::vector;
using serving_base::ExpiryMap;

const char *kSeekGroupIDSuffix = "_location";
ExpiryMap<string, int64>* Consumer::group_partitions_ = new ExpiryMap<string, int64>(10 * 60);

Consumer::Consumer(const std::string &brokers, const ConsumerOptions options) {
  stop_consume_ = false;
  brokers_ = brokers;
  options_ = options;

  bool ret = true;
  switch (options_.type) {
    case kConsumerMirror:
      ret = InitMirrorConsumer();
      break;
    case kConsumerExclusive:
      ret = InitExclusiveConsumer();
      break;
    default:
      LOG(FATAL) << "invalid type:" << options_.type;
      break;
  }

  if (!ret) {
    LOG(FATAL) << "init fail.";
  }

  LOG(INFO) << "succ. group_id:" << options_.group_id
            << ", topic:" << options_.topic
            << ", type:" << options_.type
            << ", start_time:" << options_.start_timestamp;

  return;
}

bool Consumer::InitMirrorConsumer() {
  // 镜像消费，需要修改 group id
  if (options_.type == kConsumerMirror) {
    char buf[200] = "";
    getcwd(buf, sizeof(buf));
    string cwd;
    base::FastStringReplace(buf, "/", "_", true, &cwd);
    options_.group_id += base::StringPrintf("__%s_%s__%s",
                                            base::GetLocalIP().c_str(),
                                            cwd.c_str(),
                                            base::GetProcessName().c_str());
    LOG(INFO) << "new group id:" << options_.group_id;
  }

  string errstr;
  GlobalConf conf(brokers_, options_);
  consumer_ = RdKafka::KafkaConsumer::create(conf.GetConf(), errstr);
  if (!consumer_) {
    LOG(FATAL) << "create fail:" << errstr;
    return false;
  }

  LOG(INFO) << "create consumer:" << consumer_->name() << ", topic:" << options_.topic
            << ", start time:" << options_.start_timestamp;

  vector<int64> partition_offset(options_.partition_num, RD_KAFKA_OFFSET_STORED);
  if (options_.start_timestamp >= 0) {
    thread::ThreadPool pool(std::max(2, options_.partition_num / 2));
    for (auto i = 0; i < options_.partition_num; ++i) {
      bool ret = true;
      pool.AddTask(::NewCallback(this, &Consumer::GetOffsetFromTimestamp,
                                 i, options_.start_timestamp, &partition_offset[i], &ret));
    }
    pool.JoinAll();
  }

  std::vector<RdKafka::TopicPartition*> partitions;
  for (auto i = 0; i < options_.partition_num; ++i) {
    RdKafka::TopicPartition *partition = RdKafka::TopicPartition::create(options_.topic, i);
    partition->set_offset(partition_offset[i]);
    partitions.push_back(partition);
  }

  RdKafka::ErrorCode err = consumer_->assign(partitions);
  if (err != RdKafka::ERR_NO_ERROR) {
    LOG(FATAL) << "failed to subscribe:" << options_.topic << ", err:" << err
               << ", msg:" << RdKafka::err2str(err);
    return false;
  }

  return true;
}

bool Consumer::InitExclusiveConsumer() {
  string errstr;
  GlobalConf conf(brokers_, options_);
  consumer_ = RdKafka::KafkaConsumer::create(conf.GetConf(), errstr);
  if (!consumer_) {
    LOG(FATAL) << "create fail:" << errstr;
    return false;
  }

  LOG(INFO) << "kafka consumer:" << consumer_->name() << ", topic:" << options_.topic;

  std::vector<std::string> topics;
  topics.push_back(options_.topic);
  RdKafka::ErrorCode err = consumer_->subscribe(topics);
  if (err != RdKafka::ERR_NO_ERROR) {
    LOG(FATAL) << "failed to subscribe:" << options_.topic << ", err:" << err
               << ", msg:" << RdKafka::err2str(err);
    return false;
  }

  return true;
}

Consumer::~Consumer() {
  if (consumer_) {
    switch (options_.type) {
      case kConsumerMirror:
        consumer_->unassign();
        break;
      case kConsumerExclusive:
        consumer_->commitSync();
        consumer_->unsubscribe();
        break;
      default:
        break;
    }

    base::SleepForSeconds(2);
    consumer_->close();
    delete consumer_;
  }

  RdKafka::wait_destroyed(5000);
}

bool Consumer::Consume(Message *msg, int64 timeout_ms) {
  if (stop_consume_) {
    LOG(INFO) << "consumer waiting offset reset.";
    if (timeout_ms > 0)
      base::SleepForMilliseconds(timeout_ms);
    else
      base::SleepForSeconds(1);
    return false;
  }

  bool ret = false;
  RdKafka::Message *inner_msg = consumer_->consume(timeout_ms);
  if (!inner_msg) {
    LOG(ERROR) << "inner_msg is null;";
    return ret;
  }

  VLOG(2) << "succ, msg:" << PrintMsg(inner_msg);

  msg->offset = inner_msg->offset();
  msg->errcode = inner_msg->err();
  msg->partition = inner_msg->partition();
  msg->topic = inner_msg->topic_name();

  const string debug = base::StringPrintf("RBI partition:%d, offset:%jd, err:%d",
                                          msg->partition, msg->offset, msg->errcode);
  DLOG(INFO) << debug;
  // LOG_EVERY_N(INFO, 1000) << debug;

  if (inner_msg->err() == RdKafka::ERR_NO_ERROR) {
    COUNTERS_kafka__consume_op_num.Increase(1);
    if (inner_msg->len() > 0) {
      msg->content = string(static_cast<char*>(inner_msg->payload()), inner_msg->len());
    }

    if (inner_msg->key_len() > 0) {
      msg->key = *(inner_msg->key());
    }

    msg->timestamp_ms = inner_msg->timestamp().timestamp;
    ret = true;
  } else {
    LOG_EVERY_N(INFO, 100) << "fail, info:" << debug << ", msg:" << inner_msg->errstr();
    ret = false;
    base::SleepForMilliseconds(FLAGS_consumer_sleep_ms);
    // 主动提交 offset
    consumer_->commitAsync();
  }

  delete inner_msg;

  return ret;
}

std::string Consumer::PrintMsg(const Message &msg) {
  return base::StringPrintf("MSG, topic:%s, partition:%d, key:%s, offset:%jd, timestamp:%jd, errcode:%d, msg:[%s]", // NOLINT
                            msg.topic.c_str(), msg.partition, msg.key.c_str(), msg.offset,
                            msg.timestamp_ms, msg.errcode, msg.content.c_str());
}

std::string Consumer::PrintMsg(const RdKafka::Message *msg) {
  string key;
  if (msg->key_len() > 0) {
    key = *(msg->key());
  }
  string content;
  if (msg->len() > 0) {
    content = string(static_cast<char*>(msg->payload()), msg->len()).c_str();
  }

  return base::StringPrintf("KAFKA-MSG, topic:%s, partition:%d, key:%s, offset:%jd, timestamp:%jd, errcode:%d, msg[%s]", // NOLINT
                            msg->topic_name().c_str(),
                            msg->partition(),
                            key.c_str(),
                            msg->offset(),
                            msg->timestamp().timestamp,
                            msg->err(),
                            content.c_str());
}

bool Consumer::ResetTopicStartTime(int64 timestamp) {
  stop_consume_ = true;
  bool ret = true;
  switch (options_.type) {
    case kConsumerMirror:
      ret = ResetTopicStartTimeMirror(timestamp);
      break;
    case kConsumerExclusive:
      ret = ResetTopicStartTimeGroup(timestamp);
      break;
    default:
      ret = false;
      LOG(ERROR) << "invalid type:" << options_.type;
      break;
  }

  LOG(INFO) << "reset topic time, group_id:" << options_.group_id
            << ", topic:" << options_.topic
            << ", timestamp:" << timestamp
            << ", ret:" << ret;
  stop_consume_ = false;
  return ret;
}

bool Consumer::ResetTopicStartTimeMirror(const int64 timestamp) {
  if (timestamp < 0) {
    LOG(INFO) << "time is invalid:" << timestamp;
    return false;
  }

  consumer_->unassign();

  vector<int64> partition_offset(options_.partition_num, RD_KAFKA_OFFSET_STORED);
  for (auto i = 0; i < options_.partition_num; ++i) {
    int64 offset = 0;
    bool ret = true;
    GetOffsetFromTimestamp(i, timestamp, &offset, &ret);
    if (ret) {
      partition_offset[i] = offset;
    }
  }

  std::vector<RdKafka::TopicPartition*> partitions;
  for (auto i = 0; i < options_.partition_num; ++i) {
    RdKafka::TopicPartition *partition = RdKafka::TopicPartition::create(options_.topic, i);
    partition->set_offset(partition_offset[i]);
    partitions.push_back(partition);
  }

  RdKafka::ErrorCode err = consumer_->assign(partitions);
  if (err != RdKafka::ERR_NO_ERROR) {
    LOG(FATAL) << "failed to subscribe:" << options_.topic << ", err:" << err
               << ", msg:" << RdKafka::err2str(err);
    return false;
  }

  LOG(INFO) << "reset topic time succ, topic:" << options_.topic << ", timestamp:" << timestamp;
  return true;
}

bool Consumer::ResetTopicStartTimeGroup(const int64 timestamp) {
  LOG(INFO) << "reset topic:" << options_.topic << ", timestamp is:" << timestamp;

  if (timestamp < 0) {
    LOG(INFO) << "time is invalid:" << timestamp;
    return false;
  }

  consumer_->unsubscribe();

  for (auto i = 0; i < options_.partition_num; ++i) {
    int64 offset = -1;
    bool ret = true;
    GetOffsetFromTimestamp(i, timestamp, &offset, &ret);
    if (!ret) {
      offset = -1;
    }
    SetGroupPartitionOffset(consumer_, options_.topic, i, offset);
  }

  std::vector<std::string> topics;
  topics.push_back(options_.topic);
  RdKafka::ErrorCode err = consumer_->subscribe(topics);
  if (err != RdKafka::ERR_NO_ERROR) {
    LOG(ERROR) << "failed to subscribe:" << options_.topic << ", err:" << err
               << ", msg:" << RdKafka::err2str(err);
    return false;
  }

  return true;
}

void Consumer::GetOffsetFromTimestamp(int partition_idx, int64 req_timestamp, int64 *offset, bool *ret) {
  req_timestamp *= 1000;  // kafka 的时间戳是 ms

  int64 begin_offset = -1;
  int64 latest_offset = -1;

  if (!QueryWatermarkOffsets(partition_idx, &begin_offset, &latest_offset)) {
    LOG(ERROR) << "get partition_idx:" << partition_idx << " low and high fail.";
    *ret = false;
    return;
  }

  LOG(INFO) << "partition:" << partition_idx
            << ", begin offset:" << begin_offset
            << ", latest offset:" << latest_offset;
  latest_offset = latest_offset - 1;

  while (begin_offset < latest_offset) {
    const int64 mid_offset = begin_offset + (latest_offset - begin_offset) / 2;
    const int64 mid_timestamp = GetOffsetTimestamp(partition_idx, mid_offset);
    VLOG(2) << "mid offset:" << mid_offset << ", timestamp:" << mid_timestamp << ", req:" << req_timestamp;

    if (mid_timestamp >= req_timestamp) {
      latest_offset = mid_offset - 1;
    } else {
      begin_offset = mid_offset + 1;
    }
  }

  *offset = begin_offset;
  LOG(INFO) << "offset-timestamp, topic:" << options_.topic
            << ", partition:" << partition_idx
            << ", req timestamp:" << req_timestamp
            << ", new offset:" << *offset;

  *ret = true;
  return;
}

bool Consumer::QueryWatermarkOffsets(const int partition_idx, int64_t *low, int64_t *high) {
  bool ret = true;
  ret = GetBeginningOffset(partition_idx, low);
  ret = ret && GetLatestOffset(partition_idx, high);
  if (!ret) {
    LOG(ERROR) << "GetBeginningOffset or GetLatestOffset fail.";
    return false;
  }

  return true;

  /*
  这个函数，只能获取当前索引文件的起始大小，不是整个 partition 的
  RdKafka::ErrorCode err = consumer_->query_watermark_offsets(options_.topic, partition_idx,
                                                              low, high, FLAGS_consumer_timeout);
  if (err != RdKafka::ERR_NO_ERROR) {
    LOG(ERROR) << "fail, err:" << err << ", info:" << RdKafka::err2str(err);
    return false;
  }

  return true;
  */
}

bool Consumer::GetBeginningOffset(const int partition_idx, int64 *offset) {
  return GetOffset(partition_idx, RdKafka::Topic::OFFSET_BEGINNING, offset);
}

bool Consumer::GetLatestOffset(const int partition_idx, int64 *offset) {
  return GetOffset(partition_idx, RdKafka::Topic::OFFSET_END, offset);
}

bool Consumer::GetOffset(const int partition_idx, const int64 pos, int64 *offset) {
  ConsumerOptions options = options_;
  options.group_id += kSeekGroupIDSuffix;
  GlobalConf conf(brokers_, options);

  string errstr;
  RdKafka::Consumer *consumer = RdKafka::Consumer::create(conf.GetConf(), errstr);
  RdKafka::Topic *topic = RdKafka::Topic::create(consumer, options_.topic, conf.GetTConf(), errstr);

  RdKafka::ErrorCode resp = consumer->start(topic, partition_idx, pos);
  if (resp != RdKafka::ERR_NO_ERROR) {
    LOG(ERROR) << "failed to start:" << RdKafka::err2str(resp);
    return false;
  }

  RdKafka::Message *msg = consumer->consume(topic, partition_idx, FLAGS_consumer_timeout);
  DLOG(INFO) << PrintMsg(msg);

  if (msg && (msg->err() == RdKafka::ERR_NO_ERROR
              || msg->err() == RdKafka::ERR__PARTITION_EOF)) {
    *offset = msg->offset();
  } else {
    if (msg) {
      LOG(ERROR) << "msg error, err code:" << msg->err() << ", info:" << msg->errstr();
    } else {
      LOG(ERROR) << "msg is null.";
    }
    delete msg;
    return false;
  }
  delete msg;

  consumer->stop(topic, partition_idx);
  delete topic;
  delete consumer;

  return true;
}

int64 Consumer::GetOffsetTimestamp(const int partition_idx, const int64 offset) {
  int64 timestamp = -1;
  if (offset < 0) {
    return timestamp;
  }

  ConsumerOptions options = options_;
  options.group_id += kSeekGroupIDSuffix;
  GlobalConf conf(brokers_, options);

  string errstr;
  RdKafka::Consumer *consumer = RdKafka::Consumer::create(conf.GetConf(), errstr);
  RdKafka::Topic *topic = RdKafka::Topic::create(consumer, options_.topic, conf.GetTConf(), errstr);
  if (!topic) {
    LOG(ERROR) << "create topic error:" << errstr;
    return -1;
  }

  RdKafka::ErrorCode resp = consumer->start(topic, partition_idx, offset);
  if (resp != RdKafka::ERR_NO_ERROR) {
    LOG(INFO) << "failed to start consumer:" << RdKafka::err2str(resp);
    return -1;
  }

  RdKafka::Message *msg = consumer->consume(topic, partition_idx, FLAGS_consumer_timeout);
  // DLOG(INFO) << PrintMsg(msg);

  if (msg && (msg->err() == RdKafka::ERR_NO_ERROR || msg->err() == RdKafka::ERR__PARTITION_EOF)) {
    timestamp = msg->timestamp().timestamp;
  } else {
    timestamp = -1;
  }
  delete msg;

  consumer->stop(topic, partition_idx);
  delete topic;
  delete consumer;

  return timestamp;
}

/*
bool Consumer::ResetConsumerOffset(const int partition_idx, const int64 offset) {
  string errstr;
  consumer_->unassign();
  consumer_->unsubscribe();

  RdKafka::TopicPartition *partition = RdKafka::TopicPartition::create(options_.topic, partition_idx);
  if (!partition) {
    LOG(ERROR) << "create TopicPartition fail.";
    return false;
  }

  partition->set_offset(offset);
  DLOG(INFO) << "TopicPartition, topic:" << partition->topic()
             << ", partition:" << partition->partition()
             << ", offset:" << partition->offset()
             << ", err:" << partition->err();

  std::vector<RdKafka::TopicPartition*> partitions;
  partitions.push_back(partition);

  RdKafka::ErrorCode err = consumer_->assign(partitions);
  if (err != RdKafka::ERR_NO_ERROR) {
    LOG(ERROR) << "Failed to partitions:" << options_.topic
               << ", partition:" << partition_idx
               << ", err:" << RdKafka::err2str(err);
    return false;
  }

  const string log_str = base::StringPrintf("offset store, topic:%s, partition:%d, offset:%jd, ",
                                            options_.topic.c_str(), partition_idx, offset);
  int cnt = 3;
  while (cnt--) {
    RdKafka::Message *inner_msg = consumer_->consume(FLAGS_consumer_timeout);
    DLOG(INFO) << PrintMsg(inner_msg);
    if (inner_msg->err() == RdKafka::ERR_NO_ERROR) {
      err = consumer_->commitSync(partitions);
      delete inner_msg;
      if (err != RdKafka::ERR_NO_ERROR) {
        LOG(ERROR) << "Failed to commitSync:" << options_.topic
                   << ", partition:" << partition_idx
                   << ", err:" << RdKafka::err2str(err);
        return false;
      }
      base::SleepForSeconds(1);
      return true;
    } else {
      LOG(ERROR) << log_str << "ret fail. msg errcode:" << inner_msg->err() << ", msg:" << inner_msg->errstr();
      delete inner_msg;
      return false;
    }
  }

  // delete inner_msg;
  delete partition;

  base::SleepForSeconds(10);
  LOG(INFO) << log_str << "ret succ";
  return true;
}
*/

int64 Consumer::GetGroupPartitionOffset(const RdKafka::KafkaConsumer *consumer,
                                        const std::string &topic,
                                        const int partition_idx) {
  const std::string key = GenKey(consumer, topic, partition_idx);
  int64 offset = -1;
  if (group_partitions_->FindSilently(key, &offset)) {
  } else {
    offset = -1;
  }

  DLOG(INFO) << "get group, key:" << key << ", offset:" << offset;
  return offset;
}

void Consumer::SetGroupPartitionOffset(const RdKafka::KafkaConsumer *consumer,
                                       const std::string &topic,
                                       const int partition_idx,
                                       const int64 offset) {
  const std::string key = GenKey(consumer, topic, partition_idx);
  group_partitions_->Add(key, offset);

  DLOG(INFO) << "set group, key:" << key << ", offset:" << offset;
  return;
}
}
}
