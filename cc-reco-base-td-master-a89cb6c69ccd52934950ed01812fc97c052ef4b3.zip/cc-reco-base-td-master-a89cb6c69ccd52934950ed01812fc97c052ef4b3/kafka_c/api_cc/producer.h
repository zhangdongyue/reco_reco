#pragma once

#include <string>

#include "reco/base/kafka_c/api_cc/common.h"

namespace reco {
namespace kafka {

/*
 * 生产者，如果指定partition id，就按指定提交消息
 * 如果没有指定，就会调用默认的hash函数计算partition id提交
 */
class Producer {
 public:
  // 对外接口函数
  // brokers: 127.0.0.1:9092,127.0.0.1:9093
  explicit Producer(const std::string &brokers, const std::string &topic);

  bool Produce(const std::string &msg,
               const std::string &key = std::string(),
               const int partition = RdKafka::Topic::PARTITION_UA);

  ~Producer();

 private:
  bool Connect();

  // 循环尝试重新连接，直到连接成功
  void Reconnect();

 private:
  RdKafka::Producer *producer_;
  RdKafka::Topic *topic_;
  std::string brokers_;
  std::string topic_name_;

  std::atomic<bool> need_reconnect_;
  std::atomic<bool> stop_heartbeat_thread_;

  thread::Thread retry_connect_thread_;

  DISALLOW_COPY_AND_ASSIGN(Producer);
};
}
}
