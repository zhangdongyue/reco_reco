#pragma once

#include <string>

#include "reco/base/kafka_c/api_cc/common.h"

namespace reco {
namespace kafka {

DECLARE_int32(consumer_timeout);

/*
 * Consumer支持两种方式：
 *  1. 支持镜像消费，也就是重复消费，服务启动只支持从指定时间点开始消费，如果没有设置,
 *     从上次保存的位置继续消费
 *  2. 支持互斥消费，也就是group模式消费，服务启动只支持从上次保存的位置继续消费
 *
 * 以上两种，如果需要修改消费的起点，都需要使用工具在线修改，输入为需要重置的时间戳（秒）
 *
 * 实现上，这是两种实现方式，镜像消费直接使用固定分配的方式,
 * 互斥消费使用订阅的方式，具体分配由broker回调产生，初始化和重置消费时间点都是两种方式。
 *
 * 配套工具: 
 *  1. 查询指定区间的消息数量和对应的offset
 *  2. 通过rpc调用在线修改消费的起始时间点
 */
class Consumer {
 public:
  // 对外接口函数
  // brokers: 127.0.0.1:9092,127.0.0.1:9093
  explicit Consumer(const std::string &brokers, const ConsumerOptions options);

  // 循环消费
  bool Consume(Message *msg, int64 timeout_ms = FLAGS_consumer_timeout);

  // 只能工具调用，设置 topic 的起始消费时间, timestamp 单位是秒
  bool ResetTopicStartTime(const int64 timestamp);

 public:
  // 各种功能函数
  ~Consumer();

  // msg 信息打印，debug 使用
  static std::string PrintMsg(const Message &msg);

  // msg 信息打印，debug 使用
  static std::string PrintMsg(const RdKafka::Message *msg);

  // 读互斥消费时 partitions 指定的 offset
  // 全局一份字典，分钟级别有效, 用于再 broker 重新分配 partition 时候读取
  static int64 GetGroupPartitionOffset(const RdKafka::KafkaConsumer *consumer,
                                       const std::string &topic,
                                       const int partition_idx);

  // 写互斥消费时 partitions 指定的 offset
  // 全局一份字典，分钟级别有效, RPC 调用实际修改的是全局配置
  // 本地 seek 好位置，待重新加入组获的分配时候读取
  static void SetGroupPartitionOffset(const RdKafka::KafkaConsumer *consumer,
                                      const std::string &topic,
                                      const int partition_idx,
                                      const int64 offset);

  // timestamp 单位是秒
  void GetOffsetFromTimestamp(int partition_idx, int64 timestamp, int64 *offset, bool *ret);

  bool QueryWatermarkOffsets(const int partition_idx, int64_t *low, int64_t *high);

 private:
  bool InitMirrorConsumer();

  bool InitExclusiveConsumer();

  bool ResetTopicStartTimeMirror(const int64 timestamp);

  bool ResetTopicStartTimeGroup(const int64 timestamp);

  bool GetBeginningOffset(const int partition_idx, int64 *offset);

  bool GetLatestOffset(const int partition_idx, int64 *offset);

  bool GetOffset(const int partition_idx, const int64 pos, int64 *offset);

  int64 GetOffsetTimestamp(const int partition_idx, const int64 offset);

  static std::string GenKey(const RdKafka::KafkaConsumer *consumer,
                            const std::string &topic,
                            const int partition_idx) {
    return base::StringPrintf("%p-%s-%d", consumer, topic.c_str(), partition_idx);
  }

 private:
  RdKafka::KafkaConsumer *consumer_;
  std::string brokers_;
  ConsumerOptions options_;
  std::atomic<bool> stop_consume_;

  static serving_base::ExpiryMap<std::string, int64>* group_partitions_;

  DISALLOW_COPY_AND_ASSIGN(Consumer);
};
}
}
