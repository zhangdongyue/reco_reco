#pragma once

#include <string>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/strings/string_printf.h"
#include "serving_base/expiry_map/expiry_map.h"
#include "third_party/librdkafka/src-cpp/rdkafkacpp.h"
#include "third_party/librdkafka/include/rdkafka.h"

namespace reco {
namespace kafka {

enum ConsumerType {
  kTypeNone,
  kConsumerMirror,  // 镜像重复消费, 对于镜像消费，group 名称会自动添加 ip 地址
  kConsumerExclusive,  // 同组互斥消费
};

struct ConsumerOptions {
  std::string topic;
  std::string group_id;
  int partition_num;  //  topic 的 partition 总数
  int64 start_timestamp;  // 起始消费的时间戳，单位是秒, 如果没有设置，默认最新开始读取
  ConsumerType type;

  ConsumerOptions() : topic(""),
                      group_id(""),
                      partition_num(0),
                      start_timestamp(-1),
                      type(kConsumerMirror) {}
};

struct Message {
  std::string topic;
  std::string content;
  std::string key;
  int64 timestamp_ms;  // 单位 ms
  int partition;
  int64 offset;
  int errcode;

  Message() {
    Clear();
  }

  void Clear() {
    topic.clear();
    content.clear();
    key.clear();
    timestamp_ms = 0;
    partition = -1;
    offset = 0;
    errcode = RdKafka::ERR_NO_ERROR;
  }
};

/*
static void logger(const rd_kafka_t *rk, int level, const char *fac, const char *buf) {
  LOG(INFO) << "# RDKAFKA-" << level << "-" << fac
            << ", kafka_name is: " << rd_kafka_name(rk)
            << "msg is : " << buf;
  return;
}
*/
}
}
