#include "reco/base/kafka_c/api_cc/consumer.h"
#include "reco/base/kafka_c/api_cc/producer.h"

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/sleep.h"
#include "base/testing/gtest.h"
#include "base/strings/string_split.h"
#include "base/strings/string_number_conversions.h"

using std::string;
using std::vector;
using std::unordered_map;

namespace reco {
namespace kafka {
}
}

DEFINE_string(brokers, "127.0.0.1:9092", "broker list");
DEFINE_string(topic, "test", "topic name");
DEFINE_int32(partition_num, 9, "partition");

class KafkaTest : public testing::Test {
 protected:
  void SetUp() {}

  void TearDown() {}
};


TEST_F(KafkaTest, EntireApi) {
  const int kMaxMsg = 10;
  const int64 cur_timestamp = base::GetTimestamp() / 1e6 - 10;

  // 写入 10 个
  reco::kafka::Producer producer(FLAGS_brokers, FLAGS_topic);
  for (auto i = 0; i < kMaxMsg; ++i) {
    ASSERT_TRUE(producer.Produce(base::IntToString(i * 10), base::IntToString(i * 10)));
  }

  // base::SleepForSeconds(5);

  // 读出 10 个
  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_topic;
  options.partition_num = FLAGS_partition_num;
  options.type = reco::kafka::kConsumerMirror;
  options.group_id = "unit_test_group_id";
  options.start_timestamp = cur_timestamp;

  reco::kafka::Message msg;
  reco::kafka::Consumer consumer(FLAGS_brokers, options);
  // ASSERT_TRUE(consumer.Consume(&msg));
  for (auto i = 0; i < kMaxMsg; ++i) {
    ASSERT_TRUE(consumer.Consume(&msg));
    LOG(INFO) << "read msg:" << msg.content << ", time:" << msg.timestamp_ms << ", offset:" << msg.offset;
    ASSERT_EQ(msg.content, base::IntToString(i * 10));
  }

  // 重置时间窗口，再次读出 10 个
  consumer.ResetTopicStartTime(cur_timestamp);
  // ASSERT_TRUE(consumer.Consume(&msg));
  for (auto i = 0; i < kMaxMsg; ++i) {
    ASSERT_TRUE(consumer.Consume(&msg));
    ASSERT_EQ(msg.content, base::IntToString(i * 10));
  }
}

