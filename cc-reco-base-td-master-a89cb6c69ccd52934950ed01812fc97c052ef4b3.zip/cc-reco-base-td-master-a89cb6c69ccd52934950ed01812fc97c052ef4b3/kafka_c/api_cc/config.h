#pragma once

#include <string>
#include <vector>

#include "base/hash_function/city.h"
#include "base/time/timestamp.h"

#include "reco/base/kafka_c/api_cc/common.h"
#include "reco/base/kafka_c/api_cc/consumer.h"

namespace reco {
namespace kafka {
class SimpleRebalanceCb : public RdKafka::RebalanceCb {
 private:
  static void part_list_print(const std::vector<RdKafka::TopicPartition*> &partitions) {
    std::string msg;
    for (size_t i = 0 ; i < partitions.size() ; i++) {
      msg += base::StringPrintf(", topic:%s, prt:%d, offset:%jd, ",
                                partitions[i]->topic().c_str(),
                                partitions[i]->partition(),
                                partitions[i]->offset());
    }
    LOG(INFO) << "part print:" << msg;
  }

 public:
  void rebalance_cb(RdKafka::KafkaConsumer *consumer,
                    RdKafka::ErrorCode err,
                    std::vector<RdKafka::TopicPartition*> &partitions) {
    LOG(INFO) << "RebalanceCb:" << RdKafka::err2str(err) << ", partition size:" << partitions.size();

    part_list_print(partitions);

    if (err == RdKafka::ERR__ASSIGN_PARTITIONS) {
      for (auto i = 0u; i< partitions.size(); ++i) {
        int64 offset = Consumer::GetGroupPartitionOffset(consumer,
                                                         partitions[i]->topic(),
                                                         partitions[i]->partition());
        if (offset < 0) {
          offset = RdKafka::Topic::OFFSET_STORED;
        }
        partitions[i]->set_offset(offset);
      }
      part_list_print(partitions);

      consumer->assign(partitions);
    } else {
      consumer->unassign();
    }
  }
};

class SimpleEventCb : public RdKafka::EventCb {
 public:
  void event_cb(RdKafka::Event &event) { // NOLINT
    switch (event.type()) {
      case RdKafka::Event::EVENT_ERROR:
        LOG(ERROR) << "error:" << RdKafka::err2str(event.err());
        if (event.err() == RdKafka::ERR__ALL_BROKERS_DOWN)
        break;
      case RdKafka::Event::EVENT_STATS:
        LOG(INFO) << "stats:" << event.str();
        break;
      case RdKafka::Event::EVENT_LOG:
        LOG(INFO) << base::StringPrintf("LOG-%i-%s:%s",
                                        event.severity(), event.fac().c_str(), event.str().c_str());
        break;
      case RdKafka::Event::EVENT_THROTTLE:
        LOG(INFO) << "THROTTLED: " << event.throttle_time()
                  << "ms by " << event.broker_name()
                  << " id " << (int)event.broker_id();
        break;
      default:
        LOG(INFO) << "EVENT " << event.type() << "(" << RdKafka::err2str(event.err()) << "):" << event.str();
        break;
    }
  }
};

/* Use of this partitioner is pretty pointless since no key is provided
 * in the produce() call.
 */
class SimplePartitionerCb : public RdKafka::PartitionerCb {
 public:
  int32_t partitioner_cb(const RdKafka::Topic *topic, const std::string *key,
                         int32_t partition_cnt, void *msg_opaque) {
    DLOG(INFO) << "partition_cnt:" << partition_cnt << ", key:" << *key;

    if (key && key->size() > 0) {
      return base::CityHash64(key->c_str(), key->size()) % partition_cnt;
    }

    return base::GetTimestamp() % partition_cnt;
  }
};

class SimpleDeliveryReportCb : public RdKafka::DeliveryReportCb {
 public:
  void dr_cb(RdKafka::Message &message) { // NOLINT
    std::string key;
    if (message.key() && message.key_len() > 0) {
      key = *(message.key());
    }

    if (message.err() != RdKafka::ERR_NO_ERROR) {
      LOG(ERROR) << "msg delivery fail, key:" << key
                 << ", err:" << message.err()
                 << ", errstr:" << message.errstr()
                 << ", info:" << RdKafka::err2str(message.err());
    }


    VLOG(1) << "msg delivery, topic:" << message.topic_name()
            << ", prt:" << message.partition()
            << ", offset:" << message.offset()
            << ", key:" << key
            << ", msg_len:" << message.len();
  }
};


class GlobalConf {
 public:
  // 创建 consumer 用 conf
  explicit GlobalConf(const std::string &brokers, const ConsumerOptions options);

  // 创建 producer 用 conf
  explicit GlobalConf(const std::string &brokers);

  GlobalConf() : conf_(NULL), tconf_(NULL) {}

  ~GlobalConf();

  inline RdKafka::Conf* GetConf() {
    return conf_;
  }

  inline RdKafka::Conf* GetTConf() {
    return tconf_;
  }

 private:
  bool InitCommonConf();

  bool InitConsumerConf();

  bool InitProducerConf();

  void DumpConf();

 private:
  RdKafka::Conf *conf_;
  RdKafka::Conf *tconf_;
  std::string errstr_;

  std::string brokers_;
  ConsumerOptions consumer_options_;

  static SimpleRebalanceCb rebalance_cb_;
  static SimpleEventCb event_cb_;
  static SimplePartitionerCb partition_cb_;
  static SimpleDeliveryReportCb delevery_cb_;
};
}
}
