#include <iostream>
#include <vector>

#include "base/common/base.h"
#include "base/common/logging.h"
#include "base/common/base.h"
#include "base/testing/gtest.h"
#include "base/strings/string_number_conversions.h"
#include "serving_base/utility/timer.h"

#include "reco/base/kafka_c/api_cc/producer.h"

using std::string;
using std::vector;
using reco::kafka::Producer;

DEFINE_string(brokers, "100.84.125.78:9092", "broker list");
DEFINE_string(topic, "test", "topic name");
DEFINE_int32(partition_num, 9, "partition");
DEFINE_int32(number, 20, "");
DEFINE_int32(sleep_ms, 0, "");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "kafka cc test");

  reco::kafka::Producer producer(FLAGS_brokers, FLAGS_topic);

  vector<string> send_data;
  for (auto i = 0; i < 100; ++i) {
    string data;
    for (auto j = 0; j < 1024*10; ++j) {
      data += base::IntToString(base::GetTimestamp() % 10);
    }
    send_data.push_back(data);
  }

  serving_base::Timer timer;
  timer.Start();
  int cnt = FLAGS_number;
  while (cnt--) {
    if (!producer.Produce(send_data[cnt % send_data.size()], base::IntToString(cnt))) {
      LOG(WARNING) << "send msg error!";
      base::SleepForSeconds(1);
    }
    base::SleepForMilliseconds(FLAGS_sleep_ms);
  }
  LOG(INFO) << "cost:" << timer.Stop();

  return 0;
}
