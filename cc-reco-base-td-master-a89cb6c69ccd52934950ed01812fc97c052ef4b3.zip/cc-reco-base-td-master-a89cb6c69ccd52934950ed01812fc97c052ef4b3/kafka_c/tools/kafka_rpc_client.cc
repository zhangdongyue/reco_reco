#include <iostream>
#include <unordered_map>

#include "base/strings/string_number_conversions.h"
#include "base/strings/string_printf.h"
#include "base/strings/string_split.h"
#include "base/common/base.h"
#include "base/common/sleep.h"
#include "base/common/scoped_ptr.h"
#include "base/thread/blocking_queue.h"
#include "base/thread/thread_pool.h"
#include "net/rpc/rpc.h"
#include "serving_base/utility/time_helper.h"

#include "reco/base/kafka_c/api/kafka.pb.h"

DEFINE_string(server_ip, "127.0.0.1", "server ip");
DEFINE_int32(server_port, 20002, "server port");
DEFINE_int64(new_timestamp, 0, "second");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "kafka rpc client");

  reco::kafka::ResetOffsetRequest request;
  reco::kafka::ResetOffsetResponse response;

  net::rpc::RpcClientChannel channel(FLAGS_server_ip.c_str(), FLAGS_server_port);
  CHECK(channel.Connect());
  reco::kafka::KafkaService::Stub stub(&channel);

  request.set_timestamp(FLAGS_new_timestamp);

  net::rpc::RpcClientController rpc;
  rpc.SetDeadline(1000);
  // rpc.SetTimeout(1000);
  stub.resetOffset(&rpc, &request, &response, NULL);
  rpc.Wait();

  if (rpc.status() != net::rpc::RpcClientController::kOk || !response.success()) {
    LOG(ERROR) << "request info failed.";
  }
  LOG(INFO) << response.Utf8DebugString();

  return 0;
}

