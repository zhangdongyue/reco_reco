#include <iostream>

#include "base/common/base.h"
#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "base/common/base.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/utility/timer.h"

#include "reco/base/kafka_c/api_cc/consumer.h"

using std::string;
using reco::kafka::Consumer;

DEFINE_string(brokers, "127.0.0.1:9092", "broker list");
DEFINE_string(topic, "test", "topic name");
DEFINE_int32(partition_num, 9, "partition");
DEFINE_string(group_id, "test", "");
DEFINE_int32(start_time, -1, "");
DEFINE_int32(number, 100, "");
DEFINE_bool(is_mirror, true, "");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "kafka cc test");

  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_topic;
  options.partition_num = FLAGS_partition_num;
  if (FLAGS_is_mirror) {
    options.type = reco::kafka::kConsumerMirror;
  } else {
    options.type = reco::kafka::kConsumerExclusive;
  }
  options.group_id = FLAGS_group_id;
  options.start_timestamp = FLAGS_start_time;

  reco::kafka::Message msg;
  reco::kafka::Consumer consumer(FLAGS_brokers, options);
  serving_base::Timer timer;
  timer.Start();

  int cnt = FLAGS_number;
  while (cnt--) {
    if (consumer.Consume(&msg)) {
      LOG(INFO) << Consumer::PrintMsg(msg);
    } else {
      LOG(INFO) << "consumer error.";
      base::SleepForSeconds(1);
    }
  }
  LOG(INFO) << "cost:" << timer.Stop();

  return 0;
}
