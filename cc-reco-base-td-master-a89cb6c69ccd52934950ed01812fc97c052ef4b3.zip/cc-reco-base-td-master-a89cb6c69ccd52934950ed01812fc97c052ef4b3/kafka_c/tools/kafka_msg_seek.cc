#include <iostream>

#include "base/common/base.h"
#include "base/testing/gtest.h"
#include "base/common/logging.h"
#include "base/common/base.h"
#include "serving_base/utility/time_helper.h"
#include "serving_base/utility/timer.h"

#include "reco/base/kafka_c/api_cc/consumer.h"

using std::string;
using reco::kafka::Consumer;

DEFINE_string(brokers, "127.0.0.1:9092", "broker list");
DEFINE_string(topic, "test", "topic name");
DEFINE_int32(partition_num, 9, "partition");
DEFINE_int32(start_time, 0, "");
DEFINE_int32(end_time, 2147483647, "如果没有设置，默认是当前时间，单位是秒");
DEFINE_int32(seek_time, 2147483647, "如果没有设置，默认是当前时间，单位是秒");

int main(int argc, char *argv[]) {
  base::InitApp(&argc, &argv, "kafka msg seek");

  reco::kafka::ConsumerOptions options;
  options.topic = FLAGS_topic;
  options.partition_num = FLAGS_partition_num;
  // options.start_timestamp = FLAGS_start_time;
  options.group_id = "11111111";

  reco::kafka::Consumer consumer(FLAGS_brokers, options);

  // vector<int64> backward_cnt(FLAGS_partition_num, 0);
  int64 backward_total_cnt = 0;

  for (auto i = 0; i < FLAGS_partition_num; ++i) {
    int64 begin_offset = 0;
    int64 latest_offset = 0;
    if (!consumer.QueryWatermarkOffsets(i, &begin_offset, &latest_offset)) {
      continue;
    }

    string msg = base::StringPrintf("topic:%s, partitions:%d, begin offset:%jd, latest offset:%jd, msg number:%jd",
                                    FLAGS_topic.c_str(), i, begin_offset, latest_offset, latest_offset - begin_offset);

    int64 seek_begin_offset = 0;
    bool ret = true;
    if (FLAGS_start_time > 0) {
      consumer.GetOffsetFromTimestamp(i, FLAGS_start_time, &seek_begin_offset, &ret);
      if (!ret) seek_begin_offset = begin_offset;
    }

    int64 seek_end_offset = 0;
    if (FLAGS_end_time > 0) {
      consumer.GetOffsetFromTimestamp(i, FLAGS_end_time, &seek_end_offset, &ret);
      if (!ret) seek_end_offset = latest_offset;
    }

    int64 seek_offset = 0;
    if (FLAGS_seek_time > 0)
      consumer.GetOffsetFromTimestamp(i, FLAGS_seek_time, &seek_offset, &ret);

    msg += base::StringPrintf(" || seek offset:%jd, forward dis:%jd, backward dis:%jd",
                              seek_offset, seek_offset - seek_begin_offset, seek_end_offset - seek_offset);
    LOG(ERROR) << msg;
    backward_total_cnt += seek_end_offset - seek_offset;
  }

  LOG(ERROR) << "seek offset, topic:" << FLAGS_topic
             << ", seek time:" << FLAGS_seek_time
             << ", total backward msg cnt:" << backward_total_cnt;

  return 0;
}
