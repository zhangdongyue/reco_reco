#include <iostream>
#include <fstream>
#include <google/protobuf/stubs/common.h>
#include "arpc/CommonMacros.h"
#include "arpc/RPCInterface.h"
#include "arpc/ANetRPCChannelManager.h"
#include "arpc/ANetRPCChannel.h"
#include "arpc/ANetRPCController.h"
#include "reco/base/reload_service/reload_service_7u.pb.h"
#include "base/common/base.h"
#include "base/common/gflags.h"
#include "base/time/timestamp.h"
#include "base/strings/string_util.h"
#include "base/strings/string_split.h"
#include "base/strings/string_printf.h"

using namespace google::protobuf;
using namespace std;
using namespace arpc;
using namespace reco;
using namespace reco::dm;

DEFINE_string(query, "", "");
DEFINE_string(ip, "127.0.0.1", "");
DEFINE_int32(port, 30008, "");
DEFINE_int32(time_out, 10000, "ms");
DEFINE_string(reload_path, "", "");

int main(int argc, char **argv) {
  base::InitApp(&argc, &argv, "NLP RPC client.");

  ANetRPCChannelManager rpcChannelManager;
  rpcChannelManager.StartPrivateTransport();
  string spec = StringPrintf("tcp:%s:%d", FLAGS_ip.c_str(), FLAGS_port);
  RPCChannel *pChannel = rpcChannelManager.OpenChannel(spec.c_str());
  if (pChannel == NULL) {
    cout << "open channel on " << spec << " failed" << endl;
    return -1;
  }

  ArpcReloadService::Stub stub(pChannel, Service::STUB_OWNS_CHANNEL);
  ANetRPCController cntler;
  cntler.SetExpireTime(FLAGS_time_out);

  ReloadFileRequest req;
  ReloadFileResponse resp;
  req.set_file_name(FLAGS_reload_path);

  stub.ReloadFile(&cntler, &req, &resp, NULL);

  cout << resp.Utf8DebugString() << endl;
  return 0;
}

