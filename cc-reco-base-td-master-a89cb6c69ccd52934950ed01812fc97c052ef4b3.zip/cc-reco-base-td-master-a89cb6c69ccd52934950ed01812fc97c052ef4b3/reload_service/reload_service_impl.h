#pragma once

#include "reco/base/reload_service/reload_service_7u.pb.h"
#include "reco/base/request_manager/request_manager_7u.h"
#include "base/strings/string_util.h"

namespace reco {
namespace dm {

class ReloadServiceImpl: public ArpcReloadService {
 public:
  ReloadServiceImpl();
  ~ReloadServiceImpl();

  virtual void ReloadFile(::google::protobuf::RpcController* controller, const ReloadFileRequest* request,
                          ReloadFileResponse* response, ::google::protobuf::Closure* done);
  virtual void ReloadFile_(const ReloadFileRequest* request,
                           ReloadFileResponse* response, ::google::protobuf::Closure* done);
 private:
  reco::common::RequestManager req_manager_;

  DISALLOW_COPY_AND_ASSIGN(ReloadServiceImpl);
};

}  // namespace
}  // namespace
