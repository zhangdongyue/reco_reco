#pragma once
#include <atomic>
#include <unordered_map>
#include <algorithm>
#include <queue>
#include <deque>
#include <utility>
#include <functional>
#include <memory>

#include "base/thread/thread.h"
#include "base/thread/sync.h"
#include "base/common/sleep.h"
#include "base/common/closure.h"
#include "base/common/basic_types.h"
#include "base/common/logging.h"
#include "base/time/timestamp.h"
#include "base/thread/rw_mutex.h"

namespace reco {

template<class K, class V>
class ElemHandler {
 public:
  virtual ~ElemHandler() {}
  virtual void HandleElem(const K& k, V& v) = 0;
};

template<class K, class V>
class DefaultHandler: public ElemHandler<K, V> {
 public:
  // do nothing
  virtual void HandleElem(const K& k, V& v) {}
};

// 结合ExpiryMap的FindSilently函数使用，获取元素的时间信息
enum EMTsType {
  EM_UPDATE_TS = 0,  // 上次更新时间点
  EM_REMAIN_TIME,    // 距离超时的时间
  EM_EXPIRE_TS,      // 超时的时间点
};

// Thread-safe map with expiration
// Map elements without any visit will expire in |expire_in_seconds|.
//
// Define |EraseHandler| to deal with the expired to-be-erased KEY & VALUE.
// Define |OldValHandler| to deal with the to-be-replaced VALUE.
template<class K, class V, class Hash = std::hash<K>, class Pred = std::equal_to<K>>
class ExpiryMap {
  static DefaultHandler<K, V> default_handler;
 public:
  ExpiryMap() : ExpiryMap(60) {}
  explicit ExpiryMap(int32 expire_in_seconds, int32 cache_block_num = 1, int32 exp_thread_num = 1,
                     ElemHandler<K, V>* erase_handler = &default_handler);
  ~ExpiryMap();
 public:
  // Find whether |key| in Map, return the pointer to the corresponding value.
  // Return NULL if |key| not in Map.
  // NOTE(huangboxiang): Expiration updated.
  const V* Find(const K& key) const;
  V* Find(const K& key);
  bool Find(const K& key, V* v) const;
    
  // Find whether |key| in Map, return true if in Map, false otherwise.
  // Nothing change to expiration.
  bool FindSilently(const K& key, V* v) const;
  bool FindSilently(const K& key, V* v, int64* ts, EMTsType ts_type = EM_UPDATE_TS) const;

  // NOTE(huangboxiang): Be very careful to copy if you have pointer value type.
  void CopyFrom(const ExpiryMap<K, V, Hash, Pred>& e);

  // Impractical under multi-threads circumstances.
  bool Empty(void) const;
  int64 Size(void) const;
  int64 expire(void) const;

  // Add <key, value> to map.
  // IF key has already been in map, old val will be taken care using handle
  // of |old_val|, before being replaced by the new |value|.
  void Add(const K& key, const V& value,
           ElemHandler<K, V>* old_val_handler = &default_handler);

  // If found key, do nothing, otherwise, add value to map.
  // If found key, return pointer to the value, otherwise, return NULL.
  V* IfNotFoundThenAdd(const K& key, const V& value);

  // dump data to unordered map
  void DumpData(std::unordered_map<K, V>* target);

  void Clear();

 private:
  class MapElem;
  class QueueElem;
  typedef std::deque<QueueElem> TimeQueue;
  typedef std::unordered_map<K, MapElem, Hash, Pred> Map;

  void DeleteExpired(int start, int end);
  void UpdateTimestamp(const MapElem& me, const K& key) const;  // lock from outside
  void Erase(typename Map::iterator it);
  static int64 now(void) { return ::base::GetTimestamp(); }
  static int64 del_point(int64 expire_us) { return now() + expire_us; }
  static int64 calc_interval(int64 seconds);

  inline int CalcBlockId(K key) const {
    static Hash gen_hash;
    return gen_hash(key) % cache_block_num_;
  }

 private:
  std::atomic<bool> done_;
  int64 interval_;  // scan interval in milli-seconds
  int64 expire_us_;  // expire in micro-seconds

  int cache_block_num_;
  mutable std::vector<std::shared_ptr<thread::RWMutex> > mutex_;
  std::vector<Map> map_;

  thread::Mutex erase_mtx;
  std::vector<std::shared_ptr<thread::Thread> > timer_thread_vec_;
  mutable std::vector<TimeQueue> time_queue_;
  ElemHandler<K, V>* erase_handler_;

  class QueueElem {
    int64 ts_;
    K key_;
   public:
    QueueElem(int64 expire_us, const K& k)
        : ts_(del_point(expire_us)), key_(k) {}
    bool IsAfter(int64 tp) const { return ts_ > tp; }
    const K& key() const { return key_; }
    int64 ts() const { return ts_; }
  };

  class MapElem {
   public:
    V v;
    void update_ts(int64 expire_us) const { ts_ = del_point(expire_us); }
    MapElem(const V& arg1, int64 expire_us): v(arg1), ts_(del_point(expire_us)) {}
    int64 ts() const { return ts_; }
    bool IsAfter(int64 tp) const { return ts_ > tp; }
   private:
    mutable int64 ts_;
  };
  DISALLOW_COPY_AND_ASSIGN(ExpiryMap);
};

template<class K, class V, class Hash, class Pred>
DefaultHandler<K, V> ExpiryMap<K, V, Hash, Pred>::default_handler;

template<class K, class V, class Hash, class Pred>
ExpiryMap<K, V, Hash, Pred>::ExpiryMap(int32 expire_in_seconds, int32 cache_block_num,
                                       int32 exp_thread_num, ElemHandler<K, V>* erase_handler)
  : done_(false),
    interval_(calc_interval(expire_in_seconds)),
    expire_us_(((int64)expire_in_seconds)*1e6),
    cache_block_num_(cache_block_num) {
      erase_handler_ = erase_handler;
      for (int i = 0; i < cache_block_num_; i++){
        mutex_.push_back(std::make_shared<thread::RWMutex>());
        map_.push_back(Map());
        time_queue_.push_back(TimeQueue());
      }

      if (exp_thread_num > 10) {
        exp_thread_num = 10;
      } else if (cache_block_num_ < exp_thread_num) {
        exp_thread_num = 1;
      } else {
        exp_thread_num = 1;
      }
      int offset = 0;
      int partion_size = cache_block_num_ / exp_thread_num + 1;
      for (int i = 0; i < exp_thread_num; i++){
        int start = offset;
        int end = std::min(offset + partion_size, cache_block_num_);
        timer_thread_vec_.push_back(std::make_shared<thread::Thread>());
        timer_thread_vec_.back()->Start(::NewCallback(this, &ExpiryMap<K, V, Hash, Pred>::DeleteExpired,
                                                      start, end));
        offset += partion_size;
        if (offset >= cache_block_num_) break;
      }
    }

template<class K, class V, class Hash, class Pred>
ExpiryMap<K, V, Hash, Pred>::~ExpiryMap() {
  done_.store(true);
  for (const auto& elem : timer_thread_vec_) {
    elem->Join();
  }

  // 清理资源
  Clear();
}

template<class K, class V, class Hash, class Pred>
void ExpiryMap<K, V, Hash, Pred>::DeleteExpired(int start, int end) {
  while (!done_) {
    int64 now = this->now();
    for (int i = start; i < end; i++) {
      while (!time_queue_[i].empty() && !done_) {
        bool erased = false;
        {
          // 加锁下移，为防止堵塞太久
          thread::WriterAutoLock lock(mutex_[i].get());

          const QueueElem& e = time_queue_[i].front();
          if (e.IsAfter(now)) break;

          auto it = map_[i].find(e.key());
          if (it != map_[i].end()) {
            if (it->second.IsAfter(now)) {
              // map elem has been updated/visited
            } else {
              // map elem expire
              Erase(it);
              erased = true;
            }
          }
          time_queue_[i].pop_front();
        }

        if (erased) base::SleepForMilliseconds(1);
      }
    }

    int64 sleep_total = 0;
    while (!done_) {
      if (sleep_total >= interval_) break;
      base::SleepForMilliseconds(5e3);
      sleep_total += 5e3;
    }
  }
}

template<class K, class V, class Hash, class Pred>
int64 ExpiryMap<K, V, Hash, Pred>::calc_interval(int64 seconds) {
  int64 interval = seconds * 1000 / 5;
  return interval;
}

// Lock from outside
template<class K, class V, class Hash, class Pred>
void ExpiryMap<K, V, Hash, Pred>::UpdateTimestamp(const MapElem& me, const K& key) const {
  me.update_ts(expire_us_);
  int block_id = CalcBlockId(key);
  time_queue_[block_id].push_back(QueueElem(expire_us_, key));
}

template<class K, class V, class Hash, class Pred>
void ExpiryMap<K, V, Hash, Pred>::Erase(typename Map::iterator it) {
  erase_handler_->HandleElem(it->first, it->second.v);
  int block_id = CalcBlockId(it->first);
  map_[block_id].erase(it);
}

template<class K, class V, class Hash, class Pred>
bool ExpiryMap<K, V, Hash, Pred>::Find(const K& key, V* v) const {
  int block_id = CalcBlockId(key);
  thread::WriterAutoLock lock(mutex_[block_id].get());
  auto it = map_[block_id].find(key);
  if (it == map_[block_id].end()) return false;
  if (v) {
    *v = it->second.v;
  }
  UpdateTimestamp(it->second, key);
  return true;
}

template<class K, class V, class Hash, class Pred>
bool ExpiryMap<K, V, Hash, Pred>::FindSilently(const K& key, V* v) const {
  int block_id = CalcBlockId(key);
  thread::ReaderAutoLock lock(mutex_[block_id].get());
  auto it = map_[block_id].find(key);
  if (it == map_[block_id].end()) return false;
  if (v) {
    *v = it->second.v;
  }
  return true;
}
template<class K, class V, class Hash, class Pred>
bool ExpiryMap<K, V, Hash, Pred>::FindSilently(const K& key, V* v, int64* ts, EMTsType ts_type) const {
  int block_id = CalcBlockId(key);
  thread::ReaderAutoLock lock(mutex_[block_id].get());
  auto it = map_[block_id].find(key);
  if (it == map_[block_id].end()) return false;
  if (v) {
    *v = it->second.v;
  }
  if (ts) {
    switch(ts_type) {
      case EM_UPDATE_TS:
        *ts = it->second.ts() - expire_us_;
        break;
      case EM_REMAIN_TIME:
        *ts = it->second.ts() - base::GetTimestamp();
        break;
      case EM_EXPIRE_TS:
        *ts = it->second.ts();
        break;
      default:
        ;
    }
  }
  return true;
}

template<class K, class V, class Hash, class Pred>
const V* ExpiryMap<K, V, Hash, Pred>::Find(const K& key) const {
  int block_id = CalcBlockId(key);
  thread::WriterAutoLock lock(mutex_[block_id].get());
  auto it = map_[block_id].find(key);
  if (it == map_[block_id].end()) return NULL;
  UpdateTimestamp(it->second, key);
  return &it->second.v;
}

template<class K, class V, class Hash, class Pred>
V* ExpiryMap<K, V, Hash, Pred>::Find(const K& key) {
  int block_id = CalcBlockId(key);
  thread::WriterAutoLock lock(mutex_[block_id].get());
  auto it = map_[block_id].find(key);
  if (it == map_[block_id].end()) return NULL;
  UpdateTimestamp(it->second, key);
  return &it->second.v;
}

template<class K, class V, class Hash, class Pred>
V* ExpiryMap<K, V, Hash, Pred>::IfNotFoundThenAdd(const K& key, const V& value) {
  int block_id = CalcBlockId(key);
  thread::WriterAutoLock lock(mutex_[block_id].get());
  auto it = map_[block_id].find(key);
  if (it == map_[block_id].end()) {
    map_[block_id].insert(std::pair<K, MapElem>(key, MapElem(value, expire_us_)));
    time_queue_[block_id].push_back(QueueElem(expire_us_, key));
    return NULL;
  }
  UpdateTimestamp(it->second, key);
  return &it->second.v;
}

template<class K, class V, class Hash, class Pred>
void ExpiryMap<K, V, Hash, Pred>::Add(const K& key, const V& value,
                                      ElemHandler<K, V>* old_val_handler) {
  int block_id = CalcBlockId(key);
  thread::WriterAutoLock lock(mutex_[block_id].get());
  auto it = map_[block_id].find(key);
  if (it == map_[block_id].end()) {
    map_[block_id].insert(std::pair<K, MapElem>(key, MapElem(value, expire_us_)));
    time_queue_[block_id].push_back(QueueElem(expire_us_, key));
  } else {
    old_val_handler->HandleElem(it->first, it->second.v);
    it->second.v = value;
    UpdateTimestamp(it->second, key);
  }
  return;
}

template<class K, class V, class Hash, class Pred>
void ExpiryMap<K, V, Hash, Pred>::Clear() {
  for (int i = 0; i < cache_block_num_; i++){
    TimeQueue tmp_heap;
    tmp_heap.swap(time_queue_[i]);

    thread::WriterAutoLock lock(mutex_[i].get());
    // erase resources using erase-handler
    auto it = map_[i].begin();
    for (; it != map_[i].end();) {
      auto to_erase = it++;
      Erase(to_erase);
    }
    Map tmp_map;
    tmp_map.swap(map_[i]);
  }
}

template<class K, class V, class Hash, class Pred>
bool ExpiryMap<K, V, Hash, Pred>::Empty() const {
  bool ept = true;
  for (const auto& elem : map_){
    if (!elem.empty()) {
      ept = false;
      break;
    }
  }
  return ept;
}

template<class K, class V, class Hash, class Pred>
int64 ExpiryMap<K, V, Hash, Pred>::Size() const {
  int64 sz = 0;
  for (const auto& elem : map_){
    sz += elem.size();
  }
  return sz;
}

template<class K, class V, class Hash, class Pred>
int64 ExpiryMap<K, V, Hash, Pred>::expire(void) const {
  return expire_us_;
}

template<class K, class V, class Hash, class Pred>
void ExpiryMap<K, V, Hash, Pred>::CopyFrom(const ExpiryMap<K, V, Hash, Pred>& e) {
  // fast clear, without calling erase handler
  done_.store(true);
  for (const auto& elem : timer_thread_vec_) {
    elem->Join();
  }
  done_.store(false);
  timer_thread_vec_.clear();
  mutex_.clear();
  map_.clear();
  time_queue_.clear();

  expire_us_ = e.expire_us_;
  interval_ = e.interval_;
  cache_block_num_ = e.cache_block_num_;
  erase_handler_ = e.erase_handler_;

  for (int i = 0; i < cache_block_num_; i++) {
    mutex_.push_back(std::make_shared<thread::RWMutex>());
    time_queue_.push_back(TimeQueue());

    thread::WriterAutoLock lock(e.mutex_[i].get());
    // 为了效率起见，没有copy TimeQueue，因此copy过来的元素不会被淘汰
    map_.push_back(e.map_[i]);
  }

  int exp_thread_num = e.timer_thread_vec_.size();
  int offset = 0;
  int partion_size = cache_block_num_ / exp_thread_num + 1;
  for (int i = 0; i < exp_thread_num; i++) {
    int start = offset;
    int end = std::min(offset + partion_size, cache_block_num_);
    timer_thread_vec_.push_back(std::make_shared<thread::Thread>());
    timer_thread_vec_.back()->Start(::NewCallback(this, &ExpiryMap<K, V, Hash, Pred>::DeleteExpired,
                                                  start, end));
    offset += partion_size;
    if (offset >= cache_block_num_) break;
  }
}

template<class K, class V, class Hash, class Pred>
void ExpiryMap<K, V, Hash, Pred>::DumpData(std::unordered_map<K, V>* target) {
  std::unordered_map<K, V>().swap(*target);
  target->reserve(Size() * 1.2);

  for (int i = 0; i < cache_block_num_; i++) {
    thread::WriterAutoLock lock(mutex_[i].get());
    for (auto it = map_[i].begin(); it != map_[i].end(); it ++) {
      target->insert(std::pair<K,V>(it->first, it->second.v));
    }
  }
}

}  // namespace
