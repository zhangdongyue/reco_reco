#-*-encoding:UTF-8-*-
import tensorflow as tf
from utils import tfrecord
from preprocessing import inception_preprocessing as pp

def read_inception_tfrecords(
    sess,
    path,
    batch_size,
    is_training,
    bottleneck_dim=2048,
    max_seq_len=15,
    buckets_num=15):
  dataset = tf.data.TFRecordDataset(path)
  dataset = dataset.map(tfrecord.parse_inception_example)
  dataset = dataset.map(lambda itemid,label,seq:(
    itemid,label,tf.reshape(seq,[-1,bottleneck_dim])))
  # Get seq length
  dataset = dataset.map(lambda itemid,label,seq:(
    itemid,label,tf.minimum(tf.shape(seq)[0],max_seq_len),seq))

  def _key_func(unused1,unused2,length,unused3):
    bucket_width = (max_seq_len + buckets_num -1) // buckets_num
    bucket_id = length // bucket_width
    return tf.to_int64(tf.minimum(bucket_id,buckets_num))

  def _reduce_func(key,data):
    return data.padded_batch(
        batch_size,
        padded_shapes=(
          tf.TensorShape([]),# itemid
          tf.TensorShape([]),# label
          tf.TensorShape([]),# seq length
          tf.TensorShape([None,bottleneck_dim])),# inception seq  
        padding_values=(
          '',
          tf.constant(0,tf.int64),
          0,
          0.0))
  print("dataset batch size is:{}".format(batch_size))
  dataset = dataset.apply(tf.contrib.data.group_by_window(
    key_func=_key_func,
    reduce_func=_reduce_func,
    window_size=batch_size))

  if is_training:
    dataset = dataset.repeat().prefetch(10)
  iterator = dataset.make_initializable_iterator()
  sess.run(iterator.initializer)
  return iterator

def read_frame_tfrecords(
    sess,
    path,
    batch_size,
    is_training,
    is_blending=False):
  print('raw frame input path is:{}'.format(path))
  dataset = tf.data.TFRecordDataset(path)
  dataset = dataset.map(tfrecord.parse_frame_example)

  if is_blending:
    dataset = dataset.map(lambda itemid,label,l2,snapshot,frames:(
      itemid,label,snapshot,frames,blend_snapshot_and_frames(snapshot,frames)))
  else:
    dataset = dataset.map(lambda itemid,label,l2,snapshot,frames:(
      itemid,label,snapshot,frames,blend_snapshot_and_frames(None,frames)))

  print("dataset batch size is:{}".format(batch_size))
  if batch_size > 1:
    dataset = dataset.map(lambda itemid,label,snapshot,frames,blend:(
      itemid,label,snapshot,blend))
    dataset = dataset.batch(batch_size)
  else:
    dataset = dataset.map(lambda itemid,label,snapshot,frames,blend:(
      itemid,label,snapshot,frames))

  if is_training:
    dataset = dataset.repeat().prefetch(10)

  iterator = dataset.make_initializable_iterator()
  sess.run(iterator.initializer)
  return iterator


def preprocess(binary,width,height,is_training):
  if is_training:
    print('preprocess for training.')
    return process_for_train(binary,width,height)
  else:
    print('preprocess for infering.')
    return process_for_eval(binary,width,height)


def process_for_eval(binary,width,height):
  image = tf.image.decode_jpeg(binary)
  if image.dtype != tf.float32:
    image = tf.image.convert_image_dtype(image, dtype=tf.float32)
  image = resize_image(image,width,height)
  image = tf.subtract(image, 0.5)
  image = tf.multiply(image, 2.0)
  return image

def process_for_train(binary,width,height):
  image = tf.image.decode_jpeg(binary)
  if image.dtype != tf.float32:
    image = tf.image.convert_image_dtype(image, dtype=tf.float32)
  image = resize_image(image,width,height)
  image = tf.image.random_flip_left_right(image)
  image = tf.image.random_brightness(image, max_delta=32. / 255.)
  image = tf.image.random_saturation(image, lower=0.5, upper=1.5)
  image = tf.subtract(image, 0.5)
  image = tf.multiply(image, 2.0)
  return image

def resize_image(image,width,height):
  image = tf.expand_dims(image, 0)
  image = tf.image.resize_bilinear(image, [height, width],align_corners=False)
  image = tf.squeeze(image, [0])
  image = tf.reshape(image,[299,299,3])
  return image

def blend_snapshot_and_frames(snapshot,frames):
  if snapshot is not None:
    snapshot = tf.expand_dims(snapshot,[0])
    image = tf.concat([snapshot,frames],0)
  else:
    image = frames
  image = tf.random_shuffle(image,0)
  image = tf.slice(image,[0],[1])
  image = tf.squeeze(image,[0])
  return image
