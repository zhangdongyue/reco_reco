#-*-coding:UTF-8-*-
import tensorflow as tf

def build_rnn_decoder(
    rnn_input,
    seq_len,
    layers,
    cell_type,
    use_dropout=True,
    scope='Decoder',
    reuse=False):
  with tf.variable_scope(scope,reuse=reuse) as scope:
    if len(layers) == 1:
      multi_cells = build_rnn_cells(layers[0],cell_type=cell_type,use_dropout=use_dropout)
    else:
      cells = [build_rnn_cells(num,cell_type=cell_type,use_dropout=use_dropout) for num in layers]
      multi_cells = tf.contrib.rnn.MultiRNNCell(cells)

    encode_outputs,encode_states = tf.nn.dynamic_rnn(
        multi_cells,
        rnn_input,
        dtype=tf.float32,
        sequence_length=seq_len,
        scope=scope)
  return encode_outputs,encode_states

def build_rnn_cells(unit,cell_type='gru',use_dropout=True):
  if cell_type == 'gru':
    cell = tf.nn.rnn_cell.GRUCell(unit,kernel_initializer=tf.orthogonal_initializer())
  else:
    cell = tf.nn.rnn_cell.LSTMCell(unit,initializer=tf.orthogonal_initializer())
  if use_dropout:
    cell = tf.nn.rnn_cell.DropoutWrapper(cell,output_keep_prob=0.7)
  return cell
