#-*-coding:UTF-8-*-
import tensorflow as tf

def create_inception_example(itemid,labels,frames):
  example = tf.train.SequenceExample(
      context=tf.train.Features(feature={
        'itemid':tf.train.Feature(
          bytes_list=tf.train.BytesList(value=[itemid])),
        'labels':tf.train.Feature(
          int64_list=tf.train.Int64List(value=[labels]))
        }),
      feature_lists=tf.train.FeatureLists(feature_list={
          'frames':tf.train.FeatureList(feature=[
            tf.train.Feature(
              float_list=tf.train.FloatList(value=frame)) for frame in frames])
        }))
  return example

def parse_inception_example(example):
  context={
      "itemid":tf.FixedLenFeature([],tf.string),
      "labels":tf.FixedLenFeature([],tf.int64)
      }
  feature_lists={
      "frames":tf.VarLenFeature(tf.float32)
      }
  ctx,flist = tf.parse_single_sequence_example(
      example,context_features=context,sequence_features=feature_lists)
  return ctx['itemid'],ctx['labels'],flist['frames'].values

def create_frame_example(self,itemid,l1_category,l2_category,snapshot,frames):
  example = tf.train.SequenceExample(
      context=tf.train.Features(feature={
        'itemid':tf.train.Feature(
          bytes_list=tf.train.BytesList(value=[itemid.encode('UTF-8')])),
        'l1_category':tf.train.Feature(
          bytes_list=tf.train.BytesList(value=[l1_category.encode('UTF-8')])),
        'l2_category':tf.train.Feature(
          bytes_list=tf.train.BytesList(value=[l2_category.encode('UTF-8')])),
        'snapshot':tf.train.Feature(
          bytes_list=tf.train.BytesList(value=[snapshot]))
        }),
      feature_lists=tf.train.FeatureLists(feature_list={
          'frames':tf.train.FeatureList(
            feature=[tf.train.Feature(bytes_list=tf.train.BytesList(value=[frame])) for frame in frames])
        }))
  return example

def parse_frame_example(example):
  context={
      "itemid":tf.FixedLenFeature([],tf.string),
      "l1_category":tf.FixedLenFeature([],tf.string),
      "l2_category":tf.FixedLenFeature([],tf.string),
      "snapshot":tf.FixedLenFeature([],tf.string)
      }
  feature_lists={
      "frames":tf.VarLenFeature(tf.string)
      }
  ctx,flist = tf.parse_single_sequence_example(
      example,context_features=context,sequence_features=feature_lists)
  return ctx['itemid'],ctx['l1_category'],ctx['l2_category'],ctx['snapshot'],flist['frames'].values
