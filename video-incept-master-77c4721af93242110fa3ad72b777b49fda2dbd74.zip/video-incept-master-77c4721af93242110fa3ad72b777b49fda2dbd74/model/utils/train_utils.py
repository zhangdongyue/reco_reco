#-*-coding:UTF-8-*-
import tensorflow as tf

slim = tf.contrib.slim

def create_learning_rate(
    learning_rate,
    decay_step=100,
    decay_rate=0.97,
    scope='LearningRate'):
  """
  Create a decay learning rate.
  """
  with tf.variable_scope(scope):
    global_step = tf.Variable(0,trainable=False,dtype=tf.int32)
    rate = tf.train.exponential_decay(
        learning_rate,
        global_step,
        decay_step,
        decay_rate,
        staircase=True)
  return global_step,rate


def restore_variables(exclusions=None,scope=None,splitter=","):
  """
  Get dict of variables to restore which is not start with exclusions.
  """
  # Restore model for fine tuning
  variables_to_restore = []
  excludes = []
  if exclusions is not None:
    excludes = [scope.strip() for scope in exclusions.split(splitter) if scope!='']
  print(scope)
  if scope is not None:
    all_variables = tf.get_collection(tf.GraphKeys.MODEL_VARIABLES,scope=scope)
  else:
    all_variables = tf.get_collection(tf.GraphKeys.MODEL_VARIABLES)

  for var in all_variables:
    excluded = False
    for exclude in excludes:
      if var.op.name.startswith(exclude):
        excluded = True
        break
    if not excluded:
      print('resotre variable:{}'.format(var.op.name))
      variables_to_restore.append(var)
  return variables_to_restore


def retrain_variables(inclusions,splitter=","):
  """
  Get dict of retrain variables.
  """
  # Variables to retrain
  print('retrain inclusions is:{}'.format(inclusions))
  variables_to_train = []
  includes = [scope.strip() for scope in inclusions.split(splitter) if scope!='']
  for var in slim.get_model_variables():
    included = False
    for inclusion in includes:
      if var.op.name.startswith(inclusion):
        included = True
        break
    if included:
      print('train variable:{}'.format(var.op.name))
      variables_to_train.append(var)
  return variables_to_train

