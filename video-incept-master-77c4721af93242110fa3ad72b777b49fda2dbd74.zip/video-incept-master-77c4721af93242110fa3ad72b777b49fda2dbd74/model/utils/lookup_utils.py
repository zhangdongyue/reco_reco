import tensorflow as tf

def lookup_table(sess,labels,splitter=",",scope="LookupTable"):
  label_list = labels.split(splitter)
  label_size = len(label_list)
  print('label size is:{}'.format(label_size))
  with tf.variable_scope(scope,reuse=True):
    labels_mapping = tf.constant(label_list)
    labels_lookup_table = tf.contrib.lookup.index_table_from_tensor(
        mapping=labels_mapping,
        num_oov_buckets=0,
        default_value=-1)
    labels_index_table = tf.contrib.lookup.index_to_string_table_from_tensor(
        mapping=labels_mapping)
    sess.run(tf.tables_initializer())
  return label_size,labels_lookup_table,labels_index_table
