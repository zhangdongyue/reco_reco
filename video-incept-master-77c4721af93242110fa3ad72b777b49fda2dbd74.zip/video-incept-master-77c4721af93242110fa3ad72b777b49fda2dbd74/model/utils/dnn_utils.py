# -*-coding:UTF-8-*-
import tensorflow as tf

def batch_norm_layer(inputs,
                     num_outputs,
                     is_training,
                     reuse=False,
                     scope='BatchNorm'):
  layer = tf.contrib.layers.fully_connected(
    inputs=inputs,
    num_outputs=num_outputs,
    activation_fn=None,
    reuse=reuse,
    scope=scope)
  bn = tf.contrib.layers.batch_norm(
    layer,
    decay=0.999,
    center=True,
    scale=True,
    is_training=is_training,
    reuse=reuse,
    scope=scope,
    variables_collections=None,
    updates_collections=None)
  activ = tf.nn.relu(bn)
  return activ

def build_dnn(
    inputs,
    layers,
    is_training,
    reuse=False,
    scope='DNN'):
  with tf.variable_scope(scope,reuse=reuse):
    layer_inputs = inputs
    for i,layer_width in enumerate(layers):
      scope = 'batch_norm_layer_{0}'.format(i)
      layer_inputs = batch_norm_layer(
          layer_inputs,
          layer_width,
          is_training=is_training,
          reuse=reuse,
          scope=scope)
  return layer_inputs

def build_softmax(
    inputs,
    input_width,
    label_num,
    scope="Softmax",
    reuse=False):
  print("{} input width is {}".format(scope,input_width))
  with tf.variable_scope(scope,reuse=reuse):
    weight = tf.get_variable('Weight',[input_width,label_num])
    bias = tf.get_variable('Bias',[label_num])
  logits = tf.matmul(inputs,weight) + bias
  return logits
