# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
import sys
from nets import nets_factory

import image_incept
from utils import frame_utils
from utils import lookup_utils
from utils import train_utils

dint = tf.flags.DEFINE_integer
dbool = tf.flags.DEFINE_boolean
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dint('batch_size',128,'')
dint('max_steps',30000,'')
dint('decay_step',100,'')
dfloat('learning_rate',0.0003,'')
dfloat('decay_rate',0.99,'')
dstring('label_set','体育,健身,动物,女生自拍,情景短剧,技能展示,搞笑,旅游,时尚,极限运动,汽车,生活服务,男生自拍,美食,舞蹈,萌娃,音乐,生活自拍','')
flags = tf.flags.FLAGS
image_flags = image_incept.FLAGS

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    # Create label lookup table
    label_size,lookup_table,index_table = lookup_utils.lookup_table(sess,image_flags.label_set)
    # Get the input frames iterator
    iterator = frame_utils.read_frame_tfrecords(
        sess,image_flags.incept_eval_data,image_flags.batch_size,is_training=False)
    itemid,label,snapshot,blend = iterator.get_next()

    # Create image inception model
    model = image_incept.ImageInceptModel(image_flags,graph,sess)
    endpoint = model.build_graph(snapshot,label_size,is_training=False)

    # Get the output logits
    logits = endpoint['Logits']
    labels = lookup_table.lookup(label)

    # Build the evaluation operation
    top = tf.argmax(logits,1)
    correct_prediction = tf.equal(top, labels)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    sess.run(tf.global_variables_initializer())
    model.restore()
    sys.stdout.flush()

    step = 0
    accu = 0
    count = 0
    try:
      while True:
        res = sess.run([accuracy,labels])
        step += 1
        c = res[1].shape[0]
        accu += res[0] * c
        count += c
        print('{}:{:.4f}'.format(count,accu / count),sep='',end=' ',flush=True)
    except Exception as e:
      print('\nstep:{},accuracy:{:.4f},accuracy_sum:{}'.format(step,accu / count, accu))
