#-*-coding:UTF-8-*-
import tensorflow as tf
from utils import rnn_utils
from utils import dnn_utils
from utils import train_utils

dint = tf.flags.DEFINE_integer
dbool = tf.flags.DEFINE_boolean
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string

dint('bottleneck_width',2048,'')
dint('max_seq_len',10,'')
dint('buckets_num',10,'')
dstring('train_path','/home/wangfei01/data/incept/inception_v3/train.tfrecords','')
dstring('eval_path','/home/wangfei01/data/incept/inception_v3/test.tfrecords','')
dstring('pretrain_model_path','/home/wangfei01/checkpoint/video-incept-gru/pretrain/model.ckpt','')
dstring('retrain_model_path','/home/wangfei01/checkpoint/video-incept-gru/retrain/model.ckpt','')
dstring('pretrain_model_version','20000','')
dstring('rnn_layers','1024,512','')
dstring('dnn_layers','1024,512','')
dstring('graph_def_path','/home/wangfei01/checkpoint/video-incept-gru/graph_def','')
dstring('graph_def_version','1','')

FLAGS = tf.flags.FLAGS

class BasePoolModel(object):
  def __init__(self,flags,graph,sess,model_scope):
    self.flags = flags
    self.graph = graph
    self.sess = sess
    self.model_scope = model_scope

  def restore(self):
    flags = self.flags
    variables_to_restore = train_utils.restore_variables(None,self.model_scope)
    saver = tf.train.Saver(variables_to_restore)
    model_path = "{}-{}".format(
        flags.pretrain_model_path,flags.pretrain_model_version)
    print('restore model {}'.format(model_path))
    saver.restore(self.sess,model_path)

  def save(self,step):
    flags = self.flags
    saver = tf.train.Saver()
    model_path = flags.retrain_model_path
    saver.save(self.sess,model_path,step)
    print('save model to {}-{}'.format(model_path,step))

class GruPoolModel(BasePoolModel):
  def __init__(self,flags,graph,sess):
    super().__init__(flags,graph,sess,'GruPooling')

  def pooling(self,seq,seq_length,label_size,is_training):
    flags = self.flags
    with tf.variable_scope(self.model_scope):
      endpoint = {}
      # Build RNN net
      layer_list = [int(layer) for layer in flags.rnn_layers.split(",")]
      rnn_outputs,rnn_states = rnn_utils.build_rnn_decoder(
          seq,
          seq_length,
          layer_list,
          use_dropout=is_training,
          cell_type='gru',
          scope='Decoder')
      rnn_final_output = rnn_states[-1]
      endpoint['Pooling'] = rnn_final_output
      logits = dnn_utils.build_softmax(rnn_final_output,layer_list[-1],label_size)
      endpoint['Logits'] = logits
    return endpoint

class AvgPoolModel(BasePoolModel):
  def __init__(self,flags,graph,sess):
    super().__init__(flags,graph,sess,'AvgPooling')

  def pooling(self,seq,seq_length,label_size,is_training):
    flags = self.flags
    with tf.variable_scope(self.model_scope):
      endpoint = {}
      # build dnn net
      inputs = tf.reduce_mean(seq,axis=1)
      layer_list = [int(layer) for layer in flags.dnn_layers.split(",")]
      dnn_output = dnn_utils.build_dnn(inputs,layer_list,is_training)
      endpoint['Pooling'] = dnn_output
      logits = dnn_utils.build_softmax(dnn_output,layer_list[-1],label_size)
      endpoint['Logits'] = logits
    return endpoint

class SnapshotPoolModel(BasePoolModel):
  def __init__(self,flags,graph,sess):
    super().__init__(flags,graph,sess,'SnapshotPooling')

  def pooling(self,seq,seq_length,label_size,is_training):
    flags = self.flags
    with tf.variable_scope(self.model_scope):
      endpoint = {}
      # build dnn net
      inputs = tf.squeeze(tf.slice(seq,[0,0,0],[-1,1,-1]),axis=[1])
      print(inputs)
      layer_list = [int(layer) for layer in flags.dnn_layers.split(",")]
      dnn_output = dnn_utils.build_dnn(inputs,layer_list,is_training)
      endpoint['Pooling'] = dnn_output
      logits = dnn_utils.build_softmax(dnn_output,layer_list[-1],label_size)
      endpoint['Logits'] = logits
    return endpoint
