# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
from utils import inputs
import inception
from nets import nets_factory
from preprocessing import inception_preprocessing as pp

slim = tf.contrib.slim

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dbool = tf.flags.DEFINE_bool
dint('image_width',299,'')
dint('image_height',299,'')
dint('batch_size',128,'')
dstring('model_name','inception_resnet_v2','')
dstring('checkpoint_path','/home/wangfei01/git/video-incept/inception/checkpoint/retrain','')
dstring('retrain_path','/home/wangfei01/git/video-incept/inception/checkpoint/retrain','')
dstring('train_path','/home/wangfei01/data/raw/fp-train.tfrecords','')
dstring('label_set','体育,健身,动物,女生自拍,情景短剧,技能展示,搞笑,旅游,时尚,极限运动,汽车,生活服务,男生自拍,美食,舞蹈,萌娃,音乐,生活自拍','')
dint('decay_step',10,'')
dint('max_steps',2000,'')
dfloat('learning_rate',0.006,'')
dfloat('decay_rate',0.997,'')
dfloat('batch_norm_decay',0.99,'')
dstring('restore_exclude_scopes','InceptionResnetV2/AuxLogits,InceptionResnetV2/Logits','')
dstring('train_include_scopes','InceptionResnetV2/Logits,InceptionResnetV2/Conv2d_7b_1x1,InceptionResnetV2/AuxLogits','')
dstring('probe_scope','Conv2d_1a_3x3/BatchNorm/moving_mean','')
dstring('model_scope','InceptionResnetV2','')
dstring('pretrain_version',2000,'')
dbool('is_training',True,'')
flags = tf.flags.FLAGS

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    iterator = inputs.read_image_tfrecords(
        flags.train_path,
        flags.batch_size,
        flags.image_width,
        flags.image_height)
    sess.run(iterator.initializer)
    itemid,l1_category,l2_category,snapshot,frames = iterator.get_next()

    model = inception.BaseModel(flags,graph,sess,frames,l1_category)
    bottleneck = tf.squeeze(endpoint['PreLogits'],[1,2])

    variables_to_train = train.retrain_variables(flags.train_include_scopes)

    learning_rate = train.create_learning_rate(
        learning_rate=flags.learning_rate,
        decay_step = flags.decay_step,
        decay_rate = flags.decay_rate)
    # Build the optimizer
    mean_loss = tf.reduce_mean(
        tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labels,logits=logits))
    optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)

    update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
    with tf.control_dependencies(update_ops):
      train_op = optimizer.minimize(mean_loss,var_list=variables_to_train)

    # Build the evaluation operation
    top = tf.argmax(logits,1)
    correct_prediction = tf.equal(top, labels)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

    with tf.variable_scope(flags.model_scope,reuse=True):
      probe = tf.get_variable(flags.probe_scope)
    saver_retrain = tf.train.Saver()
    step = 0
    loss = 0
    sess.run(tf.global_variables_initializer())
    while step < flags.max_steps:
      res = sess.run([train_op,learning_rate,mean_loss,probe],feed_dict={global_step:step})
      step += 1
      loss += res[2]
      print('{}:{:.4f}'.format(step,res[3][1]), sep='', end=' ', flush=True)
      if step % 50 == 0:
        acc = 0.0
        count = 0
        while count < 10:
          result = sess.run(accuracy)
          acc += result
          count += 1
        print('\nstep:{},learning rate:{:.4f},loss:{:.4f},accuracy:{:.4f},count:{}'.\
            format(step,res[1],loss,acc / count,count))
        loss = 0
        retrain_path = '{}/{}/{}.ckpt'.format(flags.retrain_path,flags.model_name,flags.model_name)
        saver_retrain.save(sess,retrain_path,step)
        print('save model to {}-{}\n'.format(retrain_path,step))

