# -*-coding:UTF-8-*-
import tensorflow as tf
import video_incept
import sys
from utils import frame_utils
from utils import lookup_utils
from utils import train_utils
from utils import dnn_utils

video_flags = video_incept.FLAGS

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    # Create label lookup table
    label_size,lookup_table,index_table = lookup_utils.lookup_table(sess,video_flags.label_set)
    # Create video inception model
    model = video_incept.AvgPoolModel(video_flags,graph,sess)
    iterator = frame_utils.read_inception_tfrecords(
        sess,video_flags.eval_path,video_flags.batch_size,is_training=False)
    itemid,labels,seq_len,seq = iterator.get_next()
    endpoint = model.pooling(seq,seq_len,label_size,is_training=False)
    logits = endpoint['Logits']
    # Build the evaluation operation
    top = tf.argmax(logits,1)
    correct_prediction = tf.equal(top, labels)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    model.restore()
    step = 0
    acc = 0.0
    count = 0
    while True:
      res = sess.run([accuracy,top])
      num = res[1].shape[0]
      acc += res[0] * num
      count += num
      if step % 1000 == 0:
        print('count:{},accuracy:{:.5f}'.format(count, acc / count))
        sys.stdout.flush()
