model_name='infer_image_incept'
pid=$(ps aux | grep ${model_name}|grep python|awk '{print $2}')
if [ -n ${pid} ];then
  kill -9 ${pid}
fi
log="log/${model_name}-train.log"
nohup python "../${model_name}.py" \
  --model_name='inception_v3' \
  --model_scope='InceptionV3' \
  --probe_scope='Conv2d_1a_3x3/BatchNorm/moving_mean' \
  --incept_infer_data='/home/wangfei01/data/raw/fp-train.tfrecords' \
  --incept_infer_file_name='train' \
  --train_include_scopes='' \
  --restore_exclude_scopes='' \
  --pretrain_version='r1600' \
  > ${log} &
tail -f ${log}
