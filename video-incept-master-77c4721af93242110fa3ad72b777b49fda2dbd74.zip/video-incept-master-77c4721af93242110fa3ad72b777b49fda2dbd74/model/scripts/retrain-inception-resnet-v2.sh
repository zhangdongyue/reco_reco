model='retrain_image_incept'
pid=$(ps aux | grep ${model}|grep python|awk '{print $2}')
if [ -n ${pid} ]
then
  kill -9 ${pid}
fi
#ps aux | grep inception|grep v3|awk '{print $2}'|xargs kill -9
log='log/retrain-inception-resnet-v2.log'
nohup python "../${model}.py" \
  --model_name='inception_resnet_v2' \
  --model_scope='InceptionResnetV2' \
  --probe_scope='Conv2d_1a_3x3/BatchNorm/moving_mean' \
  --train_include_scopes='InceptionResnetV2/Logits,InceptionResnetV2/AuxLogits,InceptionResnetV2/Block8,InceptionResnetV2/Conv2d_7b_1x1' \
  --restore_exclude_scopes='' \
  --pretrain_version='1000' \
  --batch_norm_decay='0.999' \
  --learning_rate='0.0001' \
  > ${log} &
tail -f ${log}
  #--restore_exclude_scopes='InceptionResnetV2/Logits,InceptionResnetV2/AuxLogits' \
