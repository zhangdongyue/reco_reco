model_name='export_concat'
pid=$(ps aux | grep ${model_name}|grep python|awk '{print $2}')
if [ -n ${pid} ];then
  kill -9 ${pid}
fi
log="log/${model_name}.log"
nohup python "../${model_name}.py" \
  --batch_size='10' \
  --model_name='inception_v3' \
  --model_scope='InceptionV3' \
  --probe_scope='Conv2d_1a_3x3/BatchNorm/moving_mean' \
  --train_include_scopes='' \
  --restore_exclude_scopes='' \
  --pretrain_version='r1600' \
  --batch_norm_decay='0.99' \
  --pretrain_model_version="2200" \
  --eval_path='/home/wangfei01/data/incept/inception_v3/test.tfrecords' \
  --pretrain_model_path='/home/wangfei01/checkpoint/video-incept-gru/pretrain/model.ckpt' \
  --retrain_model_path='/home/wangfei01/checkpoint/video-incept-gru/retrain/model.ckpt' \
  --graph_def_version='2' \
  > ${log} &
tail -f ${log}
