model_name='train_avg_video_label'
pid=$(ps aux |grep ${model_name}|grep python|awk '{print $2}')
echo ${pid}
if [ -n ${pid} ];then
  kill -9 ${pid}
fi
log_file="log/${model_name}.log"
nohup python "../${model_name}.py" \
  --learning_rate='0.0001' \
  --max_steps='10000' \
  --pretrain_model_path='/home/wangfei01/checkpoint/video-incept-avg/pretrain/model.ckpt' \
  --retrain_model_path='/home/wangfei01/checkpoint/video-incept-avg/retrain/model.ckpt' \
  > ${log_file} 2>&1 &
tail -f ${log_file}
