model_name='eval_image_incept'
pid=$(ps aux | grep ${model_name}|grep python|awk '{print $2}')
if [ -n ${pid} ];then
  kill -9 ${pid}
fi
log="log/${model_name}_restnet_v2.log"
nohup python "../${model_name}.py" \
  --batch_size='256' \
  --model_name='inception_resnet_v2' \
  --model_scope='InceptionResnetV2' \
  --probe_scope='Conv2d_1a_3x3/BatchNorm/moving_mean' \
  --train_include_scopes='' \
  --restore_exclude_scopes='' \
  --pretrain_version='1000' \
  --batch_norm_decay='0.99' \
  > ${log} &
tail -f ${log}
