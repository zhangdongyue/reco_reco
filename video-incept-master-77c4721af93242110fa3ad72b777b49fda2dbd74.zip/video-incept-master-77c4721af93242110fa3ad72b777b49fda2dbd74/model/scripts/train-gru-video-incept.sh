model_name='train_gru_video_label'
pid=$(ps aux |grep ${model_name}|grep python|awk '{print $2}')
echo ${pid}
if [ -n ${pid} ];then
  kill -9 ${pid}
fi
log_file="log/${model_name}.log"
nohup python "../${model_name}.py" \
  --batch_size=128 \
  --pretrain_model_path='/home/wangfei01/checkpoint/video-incept-gru/pretrain/model.ckpt' \
  --retrain_model_path='/home/wangfei01/checkpoint/video-incept-gru/retrain/model.ckpt' \
  > ${log_file} 2>&1 &
tail -f ${log_file}
