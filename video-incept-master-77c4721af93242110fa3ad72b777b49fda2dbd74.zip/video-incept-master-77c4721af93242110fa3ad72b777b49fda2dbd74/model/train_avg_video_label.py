# -*-coding:UTF-8-*-
import tensorflow as tf
import video_incept
import sys
from utils import frame_utils
from utils import lookup_utils
from utils import train_utils
from utils import dnn_utils

flags = video_incept.FLAGS

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    # Create label lookup table
    label_size,lookup_table,index_table = lookup_utils.lookup_table(sess,flags.label_set)
    global_step,learning_rate = train_utils.create_learning_rate(
        learning_rate=flags.learning_rate,
        decay_step = flags.decay_step,
        decay_rate = flags.decay_rate)

    pool_model = video_incept.AvgPoolModel(flags,graph,sess)
    iterator = frame_utils.read_inception_tfrecords(
        sess,flags.train_path,flags.batch_size,is_training=True)
    itemid,labels,seq_len,seq = iterator.get_next()
    pool_endpoint = pool_model.pooling(seq,seq_len,label_size,is_training=True)
    logits = pool_endpoint['Logits']
    # Build the evaluation operation
    top = tf.argmax(logits,1)
    correct_prediction = tf.equal(top, labels)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

    # Build the optimizer
    cross_entropy = tf.reduce_mean(
        tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labels,logits=logits))
    optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)
    update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
    with tf.control_dependencies(update_ops):
      gvs = optimizer.compute_gradients(cross_entropy)
      capped_gvs = [(tf.clip_by_value(grad, -0.1, 0.1), var) for grad, var in gvs]
      train_ops = optimizer.apply_gradients(capped_gvs)
    sess.run(tf.global_variables_initializer())
    #pool_model.restore()
    sys.stdout.flush()

    step = 0
    while step < flags.max_steps:
      res = sess.run([train_ops,learning_rate],feed_dict={global_step:step})
      step += 1
      if step % 100 == 0:
        acc = 0.0
        count = 0
        while count < 50:
          result = sess.run(accuracy)
          acc += result
          count += 1
        print('learning_rate:{:.8f},step:{},accuracy:{:.5f}'.format(res[1],step, acc / count))
        sys.stdout.flush()
        if step % 1000 == 0:
          pool_model.save(step)
