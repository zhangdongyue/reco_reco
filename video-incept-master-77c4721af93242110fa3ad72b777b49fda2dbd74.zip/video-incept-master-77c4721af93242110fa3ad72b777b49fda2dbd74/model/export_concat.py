# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
import sys
import shutil
from nets import nets_factory

import image_incept
import video_incept
from utils import frame_utils
from utils import lookup_utils
from utils import train_utils

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dbool = tf.flags.DEFINE_bool

dint('batch_size',128,'')
dint('max_steps',30000,'')
dint('decay_step',100,'')
dfloat('learning_rate',0.00003,'')
dfloat('decay_rate',0.99,'')
dstring('label_set','体育,健身,动物,女生自拍,情景短剧,技能展示,搞笑,旅游,时尚,极限运动,汽车,生活服务,男生自拍,美食,舞蹈,萌娃,音乐,生活自拍','')

image_flags = image_incept.FLAGS
video_flags = video_incept.FLAGS

flags = tf.flags.FLAGS

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    # Create label lookup table
    label_size,lookup_table,index_table = lookup_utils.lookup_table(
        sess,flags.label_set)
    # Get the input frames iterator
    iterator = frame_utils.read_frame_tfrecords(
        sess,image_flags.incept_eval_data,1,is_training=False)
    itemid,label,snapshot,frames = iterator.get_next()

    # Create image inception model
    image_model = image_incept.ImageInceptModel(image_flags,graph,sess)
    image_endpoint = image_model.build_graph(frames,label_size,is_training=False)

    # Get the bottleneck layer
    bottleneck = tf.expand_dims(tf.squeeze(image_endpoint['PreLogits'],[1,2]),0)
    labels = lookup_table.lookup(label)
    image_model.restore()

    # Create video inception model
    seq_len = tf.shape(frames)
    video_model = video_incept.GruPoolModel(video_flags,graph,sess)
    video_endpoint = video_model.pooling(bottleneck,seq_len,label_size,is_training=False)
    logits = video_endpoint['Logits']

    # Build the evaluation operation
    predictions = tf.nn.softmax(logits)
    values,indices = tf.nn.top_k(predictions,5)
    literal_top = index_table.lookup(tf.cast(indices,tf.int64))
    video_model.restore()

    sys.stdout.flush()

    graph_def_path = os.path.join(video_flags.graph_def_path,video_flags.graph_def_version)
    print('graph def path is:{}'.format(graph_def_path))
    if os.path.exists(graph_def_path):
      shutil.rmtree(graph_def_path)
      print('rm file: {}'.format(graph_def_path))
    builder = tf.saved_model.builder.SavedModelBuilder(graph_def_path)
    input_frames = tf.saved_model.utils.build_tensor_info(frames)
    output_labels = tf.saved_model.utils.build_tensor_info(literal_top)
    output_scores = tf.saved_model.utils.build_tensor_info(values)

    signature=(
        tf.saved_model.signature_def_utils.build_signature_def(
          inputs={'input_frames':input_frames},
          outputs={'output_label':output_labels, 'output_score':output_scores},
          method_name=tf.saved_model.signature_constants.PREDICT_METHOD_NAME
          )
        )
    init_op = tf.group(tf.tables_initializer(),name='tables_init_op')
    builder.add_meta_graph_and_variables(
         sess,
         [tf.saved_model.tag_constants.SERVING],
         signature_def_map={'label_signature':signature},
         legacy_init_op=init_op
        )
    builder.save()
    print('save graph def:{}'.format(graph_def_path))
