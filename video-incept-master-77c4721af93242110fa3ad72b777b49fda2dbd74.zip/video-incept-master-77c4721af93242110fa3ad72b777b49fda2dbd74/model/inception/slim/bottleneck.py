# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
from nets import nets_factory

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dint('image_width',299,'')
dint('image_height',299,'')
dstring('inception_tfrecords','/home/wangfei01/data/ffmpeg/test-i3.tfrecords','')
dstring('model_name','inception_v3','')
dstring('checkpoint_path','/home/wangfei01/git/video-incept/inception/checkpoint/inception_v3_finetune.ckpt-350','')
dstring('input_path','/home/wangfei01/data/ffmpeg/test.tfrecords','')

flags = tf.flags.FLAGS


class Bottleneck(object):
  def __init__(self,params,graph,sess):
    self.params = params
    self.graph = graph
    self.sess = sess

  def read_image_tfrecords(self):
    params = self.params
    width = params.image_width
    height = params.image_height
    image_info = tf.stack([width,height])

    path = params.input_path
    dataset = tf.data.TFRecordDataset(path)
    # parse example tfrecords
    def _parse_example(ex):
      features={
        "vdo_id":tf.FixedLenFeature([],tf.string),
        "label":tf.FixedLenFeature([],tf.string),
        "idst":tf.FixedLenFeature([],tf.string),
        "image_data":tf.VarLenFeature(tf.string)}
      image_info = tf.parse_single_example(ex,features)
      return image_info['vdo_id'],image_info['label'],image_info['idst'],image_info['image_data'].values

    dataset = dataset.map(_parse_example)
    dataset = dataset.map(lambda vdo_id,label,idst,image_datas:(
      vdo_id,label,idst,tf.map_fn(lambda x:tf.image.decode_jpeg(x,channels=3),image_datas,dtype=tf.uint8)))
    # resize image
    def _resize_image(image):
      resize_image = tf.image.resize_bilinear(image,image_info)
      print(resize_image)
      reshape_image = tf.reshape(resize_image,[-1,width,height,3])
      return tf.cast(reshape_image,tf.float32)

    dataset = dataset.map(lambda vdo_id,label,idst,image:(
      vdo_id,label,tf.string_to_number(tf.string_split([idst],',').values),_resize_image(image)))
    #dataset = dataset.batch(params.batch_size)
    iterator = dataset.make_initializable_iterator()
    self.sess.run(iterator.initializer)
    return iterator.get_next()

  def create_example(self,res):
    example = tf.train.SequenceExample(
        context=tf.train.Features(feature={
          'vdo_id':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[res[0]])),
          'label':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[res[1]])),
          'idst':tf.train.Feature(
            float_list=tf.train.FloatList(value=res[2]))
          }),
        feature_lists=tf.train.FeatureLists(feature_list={
            'frame_seq':tf.train.FeatureList(feature=[
              tf.train.Feature(
                float_list=tf.train.FloatList(value=frame)) for frame in res[3]])
          })
        )
    return example


if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)

  tf.reset_default_graph()
  with graph.as_default():
    bottleneck = Bottleneck(flags,graph,sess)
    vdo_id,label,idst,image = bottleneck.read_image_tfrecords()

    network_fn = nets_factory.get_network_fn(
        flags.model_name,
        num_classes=None,
        is_training=False)
    bottleneck_tensor,endpoint = network_fn(image)
    image_emb = tf.squeeze(bottleneck_tensor,[1,2])
    saver = tf.train.Saver()
    saver.restore(sess,flags.checkpoint_path)
    step = 0
    if os.path.exists(flags.inception_tfrecords):
      os.remove(flags.inception_tfrecords)
      print('rm file: {}'.format(flags.inception_tfrecords))
    writer = tf.python_io.TFRecordWriter(flags.inception_tfrecords)
    while True:
      start = time.time()
      res = sess.run([vdo_id,label,idst,image_emb])
      example = bottleneck.create_example(res)
      writer.write(example.SerializeToString())
      step += 1
      print('item count %d, spend %d ms' % (step,(time.time() - start)*1000))
