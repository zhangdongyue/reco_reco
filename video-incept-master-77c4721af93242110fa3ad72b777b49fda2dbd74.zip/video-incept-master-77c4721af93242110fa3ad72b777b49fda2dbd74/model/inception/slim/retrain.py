# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
from nets import nets_factory

slim = tf.contrib.slim

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dint('image_width',299,'')
dint('image_height',299,'')
dint('batch_size',128,'')
dstring('model_name','inception_v3','')
dstring('checkpoint_path','/home/wangfei01/git/video-incept/inception/checkpoint/inception_v3_finetune.ckpt-400','')
dstring('retrain_path','/home/wangfei01/git/video-incept/inception/checkpoint/inception_v3_finetune.ckpt','')
dstring('train_path','/home/wangfei01/data/ffmpeg/train.tfrecords','')
dstring('test_path','/home/wangfei01/data/ffmpeg/test.tfrecords','')
#dstring('label_set','体育,健身,动物,女生自拍,情景短剧,技能展示,搞笑,教育知识,旅游,时尚,极限运动,汽车,游戏,生活服务,男生自拍,美食,舞蹈,萌娃,音乐,生活自拍','')
dstring('label_set','体育,健身,动物,女生自拍,情景短剧,技能展示,搞笑,旅游,时尚,极限运动,汽车,生活服务,男生自拍,美食,舞蹈,萌娃,音乐,生活自拍','')
dint('decay_step',10,'')
dint('max_steps',1000,'')
dfloat('learning_rate',0.0001,'')
dfloat('decay_rate',0.97,'')
#dstring('restore_exclude_scopes','InceptionV3/AuxLogits,InceptionV3/Logits','')
dstring('restore_exclude_scopes',None,'')
dstring('train_include_scopes','InceptionV3/Logits,InceptionV3/AuxLogits,InceptionV3/Mixed_7c','')
flags = tf.flags.FLAGS


class Bottleneck(object):
  def __init__(self,flags,graph,sess):
    self.flags = flags
    self.graph = graph
    self.sess = sess
    with graph.as_default():
      # Initialize the lookup and index table
      self.label_mapping = self.label_mapping()
      self.label_lookup_table = tf.contrib.lookup.index_table_from_tensor(
          mapping=self.label_mapping,
          num_oov_buckets=0,
          default_value=-1)
      self.index_lookup_table = tf.contrib.lookup.index_to_string_table_from_tensor(
          mapping=self.label_mapping)
      self.sess.run(tf.tables_initializer())

  def label_mapping(self):
    params = self.flags
    label_list = params.label_set.split(',')
    self.label_num = len(label_list)
    print('label size is:{0}'.format(self.label_num))
    labels_mapping = tf.constant(label_list)
    return labels_mapping

  def read_image_tfrecords(self,path,batch_size,is_training=True):
    params = self.flags
    width = params.image_width
    height = params.image_height
    image_info = tf.stack([width,height])

    dataset = tf.data.TFRecordDataset(path)
    # parse example tfrecords
    def _parse_example(ex):
      features={
        "vdo_id":tf.FixedLenFeature([],tf.string),
        "label":tf.FixedLenFeature([],tf.string),
        "idst":tf.FixedLenFeature([],tf.string),
        "image_data":tf.VarLenFeature(tf.string)}
      image_info = tf.parse_single_example(ex,features)
      return image_info['vdo_id'],image_info['label'],image_info['idst'],image_info['image_data'].values

    dataset = dataset.map(_parse_example)
    dataset = dataset.map(lambda vdo_id,label,idst,image_datas:(
      vdo_id,label,idst,tf.map_fn(lambda x:tf.image.decode_jpeg(x,channels=3),image_datas,dtype=tf.uint8)))
    # resize image
    def _resize_image(image):
      resize_image = tf.image.resize_bilinear(image,image_info)
      reshape_image = tf.reshape(resize_image,[-1,width,height,3])
      return tf.cast(reshape_image,tf.float32)

    dataset = dataset.map(lambda vdo_id,label,idst,image:(
      vdo_id,label,tf.string_to_number(tf.string_split([idst],',').values),_resize_image(image)))
    table = self.label_lookup_table
    dataset = dataset.map(lambda vdo_id,label,idst,image:(
      vdo_id,table.lookup(label),idst,tf.slice(tf.random_shuffle(image),[0,0,0,0],[1,-1,-1,-1])))

    dataset = dataset.batch(batch_size).repeat().prefetch(10)
    iterator = dataset.make_initializable_iterator()
    self.sess.run(iterator.initializer)
    return iterator.get_next()

  def create_example(self,res):
    example = tf.train.SequenceExample(
        context=tf.train.Features(feature={
          'vdo_id':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[res[0]])),
          'label':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[res[1]])),
          'idst':tf.train.Feature(
            float_list=tf.train.FloatList(value=res[2]))
          }),
        feature_lists=tf.train.FeatureLists(feature_list={
            'frame_seq':tf.train.FeatureList(feature=[
              tf.train.Feature(
                float_list=tf.train.FloatList(value=frame)) for frame in res[3]])
          })
        )
    return example

def build_learning_rate():
  global_step = tf.Variable(0,trainable=False)
  learning_rate = tf.train.exponential_decay(
      self.flags.learning_rate,
      self.global_step,
      self.flags.decay_step,
      self.flags.decay_rate,
      staircase=True)
  return learning_rate

def freeze_or_train_variables():
  # Restore model for fine tuning
  exclusions = []
  variables_to_restore = []
  variables_to_train = []
  if flags.restore_exclude_scopes:
    exclusions = [scope.strip() for scope in flags.restore_exclude_scopes.split(',')]
  for var in slim.get_model_variables():
    excluded = False
    for exclusion in exclusions:
      if var.op.name.startswith(exclusion):
        excluded = True
        break
    if not excluded:
      #print('resotre variable:{0}'.format(var.op.name))
      variables_to_restore.append(var)

  includes = []
  if flags.train_include_scopes:
    includes = [scope.strip() for scope in flags.train_include_scopes.split(',')]
  print(includes)
  for var in slim.get_model_variables():
    included = False
    for inclusion in includes:
      if var.op.name.startswith(inclusion):
        included = True
        break
    if included:
      #print('train variable:{0}'.format(var.op.name))
      variables_to_train.append(var)
  return variables_to_restore,variables_to_train

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    bottleneck = Bottleneck(flags,graph,sess)
    vdo_id,labels,idst,image = bottleneck.read_image_tfrecords(flags.train_path,flags.batch_size)
    num_classes = bottleneck.label_num
    network_fn = nets_factory.get_network_fn(
        flags.model_name,
        num_classes=num_classes,
        is_training=True)
    image = tf.squeeze(image,[1])
    logits,endpoint = network_fn(image)
    variables_to_restore,variables_to_train = freeze_or_train_variables()

    saver = tf.train.Saver(variables_to_restore)
    # Create decay learning rate
    #global_step = tf.Variable(0,trainable=False)
    #learning_rate = tf.train.exponential_decay(
    #    flags.learning_rate,
    #    global_step,
    #    flags.decay_step,
    #    flags.decay_rate,
    #    staircase=True)
    # Build the optimizer
    mean_loss = tf.reduce_mean(
        tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labels,logits=logits))
    optimizer = tf.train.AdamOptimizer(learning_rate=flags.learning_rate)

    update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
    with tf.control_dependencies(update_ops):
      train_op = optimizer.minimize(mean_loss,var_list=variables_to_train)
    #train_op = optimizer.minimize(cross_entropy,var_list=variables_to_train)
    #train_op = slim.learning.create_train_op(mean_loss, optimizer)

    # Build the evaluation operation
    top = tf.argmax(logits,1)
    correct_prediction = tf.equal(top, labels)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

    with tf.variable_scope('InceptionV3',reuse=True):
      probe = tf.get_variable('Conv2d_1a_3x3/BatchNorm/moving_mean')
    saver_retrain = tf.train.Saver()
    step = 0
    loss = 0
    sess.run(tf.global_variables_initializer())
    saver.restore(sess,flags.checkpoint_path)
    while step < flags.max_steps:
      #res = sess.run([train_op,learning_rate,cross_entropy,probe],feed_dict={global_step:step})
      res = sess.run([train_op,mean_loss,probe])
      step += 1
      loss += res[1]
      print('{}:{:.4f}'.format(step,res[2][1]), sep='', end=' ', flush=True)
      if step % 50 == 0:
        acc = 0.0
        count = 0
        while count < 10:
          result = sess.run(accuracy)
          acc += result
          count += 1
        print('\nstep:{},loss:{},accuracy:{},count:{}'.format(step,loss,acc / count,count))
        loss = 0
        saver_retrain.save(sess,flags.retrain_path,step)
