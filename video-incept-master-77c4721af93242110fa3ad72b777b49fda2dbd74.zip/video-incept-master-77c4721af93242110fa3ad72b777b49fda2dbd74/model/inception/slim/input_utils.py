#-*-encoding:UTF-8-*-
import tensorflow as tf
from preprocessing import inception_preprocessing as pp

def read_image_tfrecords(
    path,
    width=299,
    height=299,
    is_blending=False,
    is_training=True):
  dataset = tf.data.TFRecordDataset(path)
  dataset = dataset.map(parse_example)
  if is_training:
    process_method = process_for_train
  else:
    process_method = process_for_eval

  dataset = dataset.map(lambda itemid,l1,l2,snapshot,frames:(
    itemid,
    l1,
    process_method(snapshot,width,height),
    tf.map_fn(lambda x:process_method(x,width,height),frames,dtype=tf.float32)
    ))

  if is_blending:
    dataset = dataset.map(lambda itemid,label,snapshot,frames:(
      itemid,label,snapshot,frames,blend_snapshot_and_frames(snapshot,frames)))
  else:
    dataset = dataset.map(lambda itemid,label,snapshot,frames:(
      itemid,label,snapshot,frames,blend_snapshot_and_frames(None,frames)))
  return dataset


def process_for_eval(binary,width,height):
  image = tf.image.decode_jpeg(binary)
  if image.dtype != tf.float32:
    image = tf.image.convert_image_dtype(image, dtype=tf.float32)
  image = resize_image(image,width,height)
  image = tf.subtract(image, 0.5)
  image = tf.multiply(image, 2.0)
  return image

def process_for_train(binary,width,height):
  image = tf.image.decode_jpeg(binary)
  if image.dtype != tf.float32:
    image = tf.image.convert_image_dtype(image, dtype=tf.float32)
  image = resize_image(image,width,height)
  image = tf.image.random_flip_left_right(image)
  image = tf.image.random_brightness(image, max_delta=32. / 255.)
  image = tf.image.random_saturation(image, lower=0.5, upper=1.5)
  image = tf.subtract(image, 0.5)
  image = tf.multiply(image, 2.0)
  return image

def resize_image(image,width,height):
  image = tf.expand_dims(image, 0)
  image = tf.image.resize_bilinear(image, [height, width],align_corners=False)
  image = tf.squeeze(image, [0])
  image = tf.reshape(image,[299,299,3])
  return image

def parse_example(example):
  context={
      "itemid":tf.FixedLenFeature([],tf.string),
      "l1_category":tf.FixedLenFeature([],tf.string),
      "l2_category":tf.FixedLenFeature([],tf.string),
      "snapshot":tf.FixedLenFeature([],tf.string)
      }
  feature_lists={
      "frames":tf.VarLenFeature(tf.string)
      }
  ctx,flist = tf.parse_single_sequence_example(
      example,context_features=context,sequence_features=feature_lists)
  return ctx['itemid'],ctx['l1_category'],ctx['l2_category'],ctx['snapshot'],flist['frames'].values


def blend_snapshot_and_frames(snapshot,frames):
  if snapshot is not None:
    snapshot=tf.expand_dims(snapshot,[0])
    image = tf.concat([snapshot,frames],0)
  else:
    image = frames
  image = tf.random_shuffle(image,0)
  image = tf.slice(image,[0,0,0,0],[1,-1,-1,-1])
  image = tf.squeeze(image,[0])
  return image
