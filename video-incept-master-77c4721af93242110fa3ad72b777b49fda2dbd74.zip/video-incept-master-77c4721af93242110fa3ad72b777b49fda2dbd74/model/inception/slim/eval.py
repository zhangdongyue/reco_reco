# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
from nets import nets_factory

slim = tf.contrib.slim

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dbool = tf.flags.DEFINE_boolean
dint('image_width',299,'')
dint('image_height',299,'')
dint('batch_size',256,'')
dint('step',100,'')
dstring('model_name','inception_v3','')
dstring('checkpoint_path','/home/wangfei01/git/video-incept/inception/checkpoint/inception_v3_finetune.ckpt','')
dstring('eval_path','/home/wangfei01/data/ffmpeg/test.tfrecords','')
dstring('label_set','体育,健身,动物,女生自拍,情景短剧,技能展示,搞笑,教育知识,旅游,时尚,极限运动,汽车,游戏,生活服务,男生自拍,美食,舞蹈,萌娃,音乐,生活自拍','')
dstring('restore_exclude_scopes','','')
#dstring('restore_exclude_scopes','InceptionV3/AuxLogits,InceptionV3/Logits','')
dstring('train_include_scopes','InceptionV3/Logits,InceptionV3/Mixed_7c','')
dbool('is_training',False,'')
flags = tf.flags.FLAGS


class Bottleneck(object):
  def __init__(self,flags,graph,sess):
    self.flags = flags
    self.graph = graph
    self.sess = sess
    with graph.as_default():
      # Initialize the lookup and index table
      self.label_mapping = self.label_mapping()
      self.label_lookup_table = tf.contrib.lookup.index_table_from_tensor(
          mapping=self.label_mapping,
          num_oov_buckets=1,
          default_value=0)
      self.index_lookup_table = tf.contrib.lookup.index_to_string_table_from_tensor(
          mapping=self.label_mapping)
      self.sess.run(tf.tables_initializer())

  def label_mapping(self):
    params = self.flags
    label_list = params.label_set.split(',')
    self.label_num = len(label_list) + 1
    #print('label size is:{0}'.format(self.label_num))
    labels_mapping = tf.constant(label_list)
    return labels_mapping

  def read_image_tfrecords(self,path,batch_size,is_training=True):
    params = self.flags
    width = params.image_width
    height = params.image_height
    image_info = tf.stack([width,height])

    dataset = tf.data.TFRecordDataset(path)
    # parse example tfrecords
    def _parse_example(ex):
      features={
        "vdo_id":tf.FixedLenFeature([],tf.string),
        "label":tf.FixedLenFeature([],tf.string),
        "idst":tf.FixedLenFeature([],tf.string),
        "image_data":tf.VarLenFeature(tf.string)}
      image_info = tf.parse_single_example(ex,features)
      return image_info['vdo_id'],image_info['label'],image_info['idst'],image_info['image_data'].values

    dataset = dataset.map(_parse_example)
    dataset = dataset.map(lambda vdo_id,label,idst,image_datas:(
      vdo_id,label,idst,tf.map_fn(lambda x:tf.image.decode_jpeg(x,channels=3),image_datas,dtype=tf.uint8)))
    # resize image
    def _resize_image(image):
      resize_image = tf.image.resize_bilinear(image,image_info)
      reshape_image = tf.reshape(resize_image,[-1,width,height,3])
      return tf.cast(reshape_image,tf.float32)

    dataset = dataset.map(lambda vdo_id,label,idst,image:(
      vdo_id,label,tf.string_to_number(tf.string_split([idst],',').values),_resize_image(image)))
    table = self.label_lookup_table
    dataset = dataset.map(lambda vdo_id,label,idst,image:(
      vdo_id,table.lookup(label),idst,tf.slice(image,[0,0,0,0],[1,-1,-1,-1])))

    dataset = dataset.batch(batch_size)
    iterator = dataset.make_initializable_iterator()
    self.sess.run(iterator.initializer)
    return iterator.get_next()

  def create_example(self,res):
    example = tf.train.SequenceExample(
        context=tf.train.Features(feature={
          'vdo_id':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[res[0]])),
          'label':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[res[1]])),
          'idst':tf.train.Feature(
            float_list=tf.train.FloatList(value=res[2]))
          }),
        feature_lists=tf.train.FeatureLists(feature_list={
            'frame_seq':tf.train.FeatureList(feature=[
              tf.train.Feature(
                float_list=tf.train.FloatList(value=frame)) for frame in res[3]])
          })
        )
    return example

def build_learning_rate():
  global_step = tf.Variable(0,trainable=False)
  learning_rate = tf.train.exponential_decay(
      self.flags.learning_rate,
      self.global_step,
      self.flags.decay_step,
      self.flags.decay_rate,
      staircase=True)
  return learning_rate

def freeze_or_train_variables():
  # Restore model for fine tuning
  exclusions = []
  variables_to_restore = []
  variables_to_train = []
  if flags.restore_exclude_scopes:
    exclusions = [scope.strip() for scope in flags.restore_exclude_scopes.split(',')]
  for var in slim.get_model_variables():
    excluded = False
    for exclusion in exclusions:
      if var.op.name.startswith(exclusion):
        excluded = True
        break
    if not excluded:
      print('resotre variable:{0}'.format(var.op.name))
      variables_to_restore.append(var)

  includes = []
  if flags.train_include_scopes:
    includes = [scope.strip() for scope in flags.train_include_scopes.split(',')]
  print(includes)
  for var in slim.get_model_variables():
    included = False
    for inclusion in includes:
      if var.op.name.startswith(inclusion):
        included = True
        break
    if included:
      print('train variable:{0}'.format(var.op.name))
      variables_to_train.append(var)
  return variables_to_restore,variables_to_train

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    bottleneck = Bottleneck(flags,graph,sess)
    vdo_id,labels,idst,image = bottleneck.read_image_tfrecords(flags.eval_path,flags.batch_size)
    num_classes = bottleneck.label_num
    network_fn = nets_factory.get_network_fn(
        flags.model_name,
        num_classes=num_classes,
        is_training=flags.is_training)
    image = tf.squeeze(image,[1])
    logits,endpoint = network_fn(image)

    # Build the evaluation operation
    top = tf.argmax(logits,1)
    correct_prediction = tf.equal(top, labels)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

    step = 0
    accu = 0
    count = 0
    sess.run(tf.global_variables_initializer())
    saver = tf.train.Saver()
    checkpoint = '{}-{}'.format(flags.checkpoint_path,flags.step)
    saver.restore(sess,checkpoint)
    try:
      while True:
        res = sess.run([accuracy,labels])
        step += 1
        c = res[1].shape[0]
        accu += res[0] * c
        count += c
        print('{}:{:.4f}'.format(c,res[0]),sep='',end=' ',flush=True)
    except Exception as e:
      print('\nstep:{},accuracy:{:.4f},accuracy_sum:{}'.format(step,accu / count, accu))

