#-*-coding:UTF-8-*-
import tensorflow as tf

def build_learning_rate(
    learning_rate,
    decay_step=100,
    decay_rate=0.97,
    scope='learning_rate'):
  with tf.variable_scope(scope):
    global_step = tf.Variable(0,trainable=False)
    rate = tf.train.exponential_decay(
        learning_rate,
        global_step,
        decay_step,
        decay_rate,
        staircase=True)
  return rate
