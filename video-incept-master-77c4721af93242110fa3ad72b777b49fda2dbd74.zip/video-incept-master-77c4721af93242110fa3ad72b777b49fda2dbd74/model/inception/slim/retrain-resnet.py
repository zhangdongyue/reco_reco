# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
from utils import dataset as ds
from nets import nets_factory
from preprocessing import inception_preprocessing as pp

slim = tf.contrib.slim

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dint('image_width',299,'')
dint('image_height',299,'')
dint('batch_size',128,'')
dstring('model_name','inception_resnet_v2','')
dstring('checkpoint_path','/home/wangfei01/git/video-incept/inception/checkpoint','')
dstring('retrain_path','/home/wangfei01/git/video-incept/inception/checkpoint/retrain','')
dstring('train_path','/home/wangfei01/data/raw/fp-train.tfrecords','')
dstring('label_set','体育,健身,动物,女生自拍,情景短剧,技能展示,搞笑,旅游,时尚,极限运动,汽车,生活服务,男生自拍,美食,舞蹈,萌娃,音乐,生活自拍','')
dint('decay_step',20,'')
dint('max_steps',2000,'')
dfloat('learning_rate',0.03,'')
dfloat('decay_rate',0.997,'')
dfloat('batch_norm_decay',0.999,'')
dstring('restore_exclude_scopes','InceptionResnetV2/AuxLogits,InceptionResnetV2/Logits','')
dstring('train_include_scopes','InceptionResnetV2/Logits,InceptionResnetV2/Conv2d_7b_1x1,InceptionResnetV2/AuxLogits','')
dstring('probe_scope','Conv2d_1a_3x3/BatchNorm/moving_mean','')
dstring('model_scope','InceptionResnetV2','')
#dstring('restore_exclude_scopes',None,'')
#dstring('train_include_scopes','InceptionResnetV2/Logits,InceptionResnetV2/AuxLogits','')
flags = tf.flags.FLAGS


class Bottleneck(object):
  def __init__(self,flags,graph,sess):
    self.flags = flags
    self.graph = graph
    self.sess = sess
    with graph.as_default():
      # Initialize the lookup and index table
      self.label_mapping = self.label_mapping()
      self.label_lookup_table = tf.contrib.lookup.index_table_from_tensor(
          mapping=self.label_mapping,
          num_oov_buckets=0,
          default_value=-1)
      self.index_lookup_table = tf.contrib.lookup.index_to_string_table_from_tensor(
          mapping=self.label_mapping)
      self.sess.run(tf.tables_initializer())

  def label_mapping(self):
    params = self.flags
    label_list = params.label_set.split(',')
    self.label_num = len(label_list)
    print('label size is:{0}'.format(self.label_num))
    labels_mapping = tf.constant(label_list)
    return labels_mapping

  def read_image_tfrecords(self,path,batch_size,is_training=True):
    params = self.flags
    width = params.image_width
    height = params.image_height
    dataset = ds.read_image_tfrecords(
        path,
        width=width,
        height=height,
        is_training=is_training,
        is_blending=True)
    table = self.label_lookup_table
    dataset = dataset.map(
        lambda itemid,label,snapshot,sample:(itemid,table.lookup(label),sample))
    dataset = dataset.batch(batch_size).repeat().prefetch(10)
    iterator = dataset.make_initializable_iterator()
    self.sess.run(iterator.initializer)
    return iterator.get_next()

def build_learning_rate():
  global_step = tf.Variable(0,trainable=False)
  learning_rate = tf.train.exponential_decay(
      self.flags.learning_rate,
      self.global_step,
      self.flags.decay_step,
      self.flags.decay_rate,
      staircase=True)
  return learning_rate

def freeze_or_train_variables():
  # Restore model for fine tuning
  exclusions = []
  variables_to_restore = []
  variables_to_train = []
  if flags.restore_exclude_scopes:
    exclusions = [scope.strip() for scope in flags.restore_exclude_scopes.split(',')]
  for var in slim.get_model_variables():
    excluded = False
    for exclusion in exclusions:
      if var.op.name.startswith(exclusion):
        excluded = True
        break
    if not excluded:
      #print('resotre variable:{0}'.format(var.op.name))
      variables_to_restore.append(var)

  includes = []
  if flags.train_include_scopes:
    includes = [scope.strip() for scope in flags.train_include_scopes.split(',')]
  print(includes)
  for var in slim.get_model_variables():
    included = False
    for inclusion in includes:
      if var.op.name.startswith(inclusion):
        included = True
        break
    if included:
      #print('train variable:{0}'.format(var.op.name))
      variables_to_train.append(var)
  return variables_to_restore,variables_to_train

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    bottleneck = Bottleneck(flags,graph,sess)
    itemid,labels,image = bottleneck.read_image_tfrecords(flags.train_path,flags.batch_size)
    num_classes = bottleneck.label_num
    network_fn = nets_factory.get_network_fn(
        flags.model_name,
        num_classes=num_classes,
        batch_norm_decay=flags.batch_norm_decay,
        is_training=True)
    logits,endpoint = network_fn(image)
    variables_to_restore,variables_to_train = freeze_or_train_variables()

    saver = tf.train.Saver(variables_to_restore)
    # Create decay learning rate
    global_step = tf.Variable(0,trainable=False)
    learning_rate = tf.train.exponential_decay(
        flags.learning_rate,
        global_step,
        flags.decay_step,
        flags.decay_rate,
        staircase=True)
    # Build the optimizer
    mean_loss = tf.reduce_mean(
        tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labels,logits=logits))
    optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)

    update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
    with tf.control_dependencies(update_ops):
      train_op = optimizer.minimize(mean_loss,var_list=variables_to_train)

    # Build the evaluation operation
    top = tf.argmax(logits,1)
    correct_prediction = tf.equal(top, labels)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

    with tf.variable_scope(flags.model_scope,reuse=True):
      probe = tf.get_variable(flags.probe_scope)
    saver_retrain = tf.train.Saver()
    step = 0
    loss = 0
    sess.run(tf.global_variables_initializer())
    checkpoint_path = '{}/{}.ckpt'.format(flags.checkpoint_path,flags.model_name)
    saver.restore(sess,checkpoint_path)
    while step < flags.max_steps:
      res = sess.run([train_op,learning_rate,mean_loss,probe],feed_dict={global_step:step})
      step += 1
      loss += res[2]
      print('{}:{:.4f}'.format(step,res[3][1]), sep='', end=' ', flush=True)
      if step % 100 == 0:
        acc = 0.0
        count = 0
        while count < 10:
          result = sess.run(accuracy)
          acc += result
          count += 1
        print('\nstep:{},learning rate:{:.4f},loss:{:.4f},accuracy:{:.4f},count:{}'.\
            format(step,res[1],loss,acc / count,count))
        loss = 0
        retrain_path = '{}/{}/{}.ckpt'.format(flags.retrain_path,flags.model_name,flags.model_name)
        saver_retrain.save(sess,retrain_path,step)
        print('save model to {}-{}\n'.format(retrain_path,step))
