python bottleneck.py \
    --inception_tfrecords='/home/wangfei01/data/ffmpeg/inception_v4_test.tfrecords' \
    --model_name='inception_v4' \
    --checkpoint_path='/home/wangfei01/git/video-incept/inception/checkpoint/inception_v4.ckpt' \
    --input_path='/home/wangfei01/data/ffmpeg/test.tfrecords'
