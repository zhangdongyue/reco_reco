# -*-UTF-8-*-
import tensorflow as tf
from preprocessing import inception_preprocessing as pre

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dstring('tfrecord_path','/home/wangfei01/data/raw/fp-test.tfrecords','')
dstring('summary_path','/home/wangfei01/summary/','')

flags = tf.flags.FLAGS

if __name__ == '__main__':
  tf.reset_default_graph()
  dataset = tf.data.TFRecordDataset(flags.tfrecord_path)
  # parse example tfrecords
  def _parse_example(example):
    context={
        "itemid":tf.FixedLenFeature([],tf.string),
        "l1_category":tf.FixedLenFeature([],tf.string),
        "l2_category":tf.FixedLenFeature([],tf.string),
        "snapshot":tf.FixedLenFeature([],tf.string)
        }
    feature_lists={
        "frames":tf.VarLenFeature(tf.string)
        }
    ctx,flist = tf.parse_single_sequence_example(
        example,context_features=context,sequence_features=feature_lists)
    return ctx['itemid'],ctx['l1_category'],ctx['l2_category'],ctx['snapshot'],flist['frames'].values
  dataset = dataset.map(_parse_example)
  #dataset = dataset.filter(lambda itemid,l1,l2,snapshot,frames:tf.size(frames)>0)
  #dataset = dataset.map(lambda itemid,l1,l2,snapshot,frames:tf.image.decode_jpeg(snapshot))
  def _parse_frames(frames):
    result = tf.map_fn(lambda image:tf.image.decode_jpeg(image,channels=3),frames,dtype=tf.uint8)
    return result
  dataset = dataset.map(lambda itemid,l1,l2,snapshot,frames:(tf.image.decode_jpeg(snapshot),_parse_frames(frames)))
  dataset = dataset.map(lambda snapshot,frames:(snapshot,pre.preprocess_for_eval(snapshot,299,299)))
  dataset = dataset.shuffle(100)
  #dataset = dataset.map(lambda snapshot,distort:(snapshot,tf.image.random_saturation(distort, lower=0.5, upper=1.5)))
  dataset = dataset.batch(1)
  iterator = dataset.make_initializable_iterator()
  snapshot,distort = iterator.get_next()
  #snapshot = tf.expand_dims(snapshot,0)
  #image = tf.expand_dims(image,0)
  #with tf.Session() as sess:
  #  sess.run(iterator.initializer)
  #  step=0
  #  while step < 10:
  #    print(sess.run(data))
  #    step+=1
  #print(data)
  #data = tf.reduce_mean(data)
  #shape=tf.shape(data)
  #width = tf.maximum(tf.shape(data)[1],tf.shape(data)[1])
  #snapshot = tf.expand_dims(data[0],0)
  tf.summary.image('snapshot',snapshot)
  tf.summary.image('distort',distort)
  #data = tf.image.resize_image_with_crop_or_pad(data,width,width)
  #data = tf.image.adjust_brightness(data,0.5)
  #image = tf.image.resize_nearest_neighbor(data,[299,299])
  #tf.summary.image('snapshot-resize',image)
  merged = tf.summary.merge_all()
  with tf.Session() as sess:
    image_writer = tf.summary.FileWriter(flags.summary_path,sess.graph)
    sess.run(iterator.initializer)
    step = 0
    while step < 10:
      res,summary = sess.run([tf.shape(snapshot),merged])
      image_writer.add_summary(summary,step)
      step += 1
      print(res)
