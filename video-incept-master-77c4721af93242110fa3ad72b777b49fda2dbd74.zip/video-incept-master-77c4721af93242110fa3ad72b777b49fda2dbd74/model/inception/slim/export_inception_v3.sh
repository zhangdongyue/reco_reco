#!/bin/bash
python export_inference_graph.py \
  --alsologtostderr \
  --model_name=inception_v3 \
  --output_file=/home/wangfei01/git/incept_v3/graph_def/inception_v3_inf_graph.pb
