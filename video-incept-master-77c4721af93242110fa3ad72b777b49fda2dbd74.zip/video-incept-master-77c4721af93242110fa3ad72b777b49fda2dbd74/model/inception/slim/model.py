# -*-coding=UTF-8-*-
import tensorflow as tf
import abc

class Model(object):
  def __init__(self,FLAGS,graph,sess):
    self.params = FLAGS
    self.graph = graph
    self.sess = sess
    with graph.as_default():
      self.label_lookup_table = self.label_lookup_table()
      sess.run(tf.tables_initializer())

  def build_batch_norm(self,
                       scope,
                       inputs,
                       num_outputs,
                       is_training=True,
                       reuse=False):
    layer = tf.contrib.layers.fully_connected(
      inputs=inputs,
      num_outputs=num_outputs,
      activation_fn=None,
      reuse=reuse,
      scope=scope)
    bn = tf.contrib.layers.batch_norm(
      layer,
      decay=0.999,
      center=True,
      scale=True,
      is_training=is_training,
      reuse=reuse,
      scope=scope,
      variables_collections=['batch_norm_variables_collection'],
      updates_collections=None)
    activ = tf.nn.elu(bn)
    return activ

  @abc.abstractmethod
  def build_inputs(self,path,is_training=True):
    pass

  def label_lookup_table(self):
    params = self.params
    label_list = params.label_set.split(',')
    self.label_num = len(label_list)
    self.labels_mapping = tf.constant(label_list)
    table = tf.contrib.lookup.index_table_from_tensor(
      mapping=self.labels_mapping,
      num_oov_buckets=1,
      default_value=0)
    return table


  def build_graph(self,inputs,labels,is_training=True,reuse=False):
    sess = self.sess
    params = self.params
    label_num = self.label_num
    num_layers = [int(layer) for layer in params.layers.split(',')]
    for i,layer in enumerate(num_layers):
      inputs = self.build_batch_norm('batch_norm_%d' % i,
        inputs,layer,is_training=is_training,reuse=reuse)
    with tf.variable_scope('softmax',reuse=reuse):
      weight = tf.get_variable('weight',[num_layers[-1],label_num])
      bias = tf.get_variable('bias',[label_num])
    logits = tf.matmul(inputs,weight) + bias
    return logits,labels

  def train(self):
    params = self.params
    with self.graph.as_default():
      logits,labels = self.train_graph
      cross_entropy = tf.reduce_mean(
        tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labels,logits=logits))
      optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)\
        .minimize(cross_entropy)
    return optimizer

  def test(self):
    params = self.params
    with self.graph.as_default():
      logits,labels = self.test_graph
      predictions = tf.nn.softmax(logits)
      top = tf.argmax(logits, 1,output_type=tf.int32)
      correct_prediction = tf.equal(top, labels)
      accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    return accuracy,top

  @abc.abstractmethod
  def run(self):
    pass

  def save(self):
    params = self.params
    self.saver.save(self.sess,params.model_path)

class TrainModel(Model):
  def __init__(self,flags,graph,sess):
    super().__init__(flags,graph,sess)
    with self.graph.as_default():
      self.global_step = tf.Variable(0,trainable=False)
      self.learning_rate = tf.train.exponential_decay(self.params.learning_rate,
        self.global_step,self.params.decay_step,self.params.decay_rate,staircase=True)

      self.label_lookup_table = self.label_lookup_table()
      sess.run(tf.tables_initializer())
      self.train_inputs = self.build_inputs(self.params.train_data_path)
      self.train_graph = self.build_graph(self.train_inputs[0],self.train_inputs[1])
      self.optimizer = self.train()

      self.test_inputs = self.build_inputs(self.params.test_data_path,is_training=False)
      self.test_graph = self.build_graph(self.test_inputs[0],
        self.test_inputs[1],is_training=False,reuse=True)
      self.accuracy = self.test()

      self.saver = tf.train.Saver()

  def build_inputs(self,path,is_training=True):
    params = self.params
    input_width = params.input_width
    buffer_size = params.dataset_prefetch_size
    table = self.label_lookup_table
    dataset = tf.data.TextLineDataset(path).prefetch(buffer_size)
    dataset = dataset.map(
      lambda line:(tf.string_split([line],delimiter='\t').values[6],
      tf.string_split([line],delimiter='\t').values[3])).prefetch(buffer_size)
    dataset = dataset.map(
      lambda features,label:(tf.reshape(tf.string_split([features],',').values,[input_width]),
      table.lookup(label)))
    dataset = dataset.map(
      lambda features,label:(tf.string_to_number(features),
      tf.cast(label,tf.int32))).prefetch(buffer_size)
    if is_training:
      dataset = dataset.batch(params.batch_size).repeat().prefetch(buffer_size)
    else:
      dataset = dataset.batch(params.batch_size).repeat(1).prefetch(buffer_size)
    iterator = dataset.make_initializable_iterator()
    next_value = iterator.get_next()
    self.sess.run(iterator.initializer)
    return next_value

  def run(self):
    params = self.params
    with self.graph.as_default():
      sess = self.sess
      sess.run(tf.global_variables_initializer())
      step = 0
      while step < params.max_steps:
        res = sess.run([self.optimizer,self.learning_rate],feed_dict={self.global_step:step})
        step += 1
        if step % 10 == 0:
          self.test_inputs = self.build_inputs(self.params.test_data_path,is_training=False)
          self.test_graph = self.build_graph(self.test_inputs[0],
            self.test_inputs[1],is_training=False,reuse=True)
          self.accuracy,self.predictions = self.test()
          acc = 0.0
          count = 0
          try:
            while True:
              result = sess.run(self.accuracy)
              acc += result
              count += 1
          except Exception as e:
            print('learning_rate:%f,step:%d,loss:%f' % (res[1],step, acc / count))
      self.saver.save(sess,params.model_path)
      print('save model to %s' % (params.model_path))

class TestModel(Model):
  def __init__(self,flags,graph,sess):
    super().__init__(flags,graph,sess)
    with self.graph.as_default():
      self.global_step = tf.Variable(0,trainable=False)
      self.label_mapping=self.label_mapping()
      self.label_lookup_table = tf.contrib.lookup.index_table_from_tensor(
        mapping=self.label_mapping,
        num_oov_buckets=1,
        default_value=0)
      self.index_lookup_table = tf.contrib.lookup.index_to_string_table_from_tensor(
        mapping=self.label_mapping
      )
      self.inputs = self.build_inputs(
        self.params.test_data_path,
        is_training=False)
      self.graph_def = self.build_graph(
        self.inputs[0],
        self.inputs[1],
        is_training=False)
      self.saver = tf.train.Saver()

  def label_mapping(self):
    params = self.params
    label_list = params.label_set.split(',')
    self.label_num = len(label_list)
    labels_mapping = tf.constant(label_list)
    return labels_mapping

  def build_inputs(self,path,is_training=True):
    params = self.params
    input_width = params.input_width
    buffer_size = params.dataset_prefetch_size
    table = self.label_lookup_table
    dataset = tf.data.TextLineDataset(path).prefetch(buffer_size)
    dataset = dataset.map(
      lambda line:(tf.string_split([line],delimiter='\t').values[6],
      tf.string_split([line],delimiter='\t').values[3],
      tf.string_split([line],delimiter='\t').values[5])).prefetch(buffer_size)
    dataset = dataset.map(
      lambda features,label,url:(
      tf.reshape(tf.string_split([features],',').values,[input_width]),
      table.lookup(label),
      url))
    dataset = dataset.map(
      lambda features,label,url:(
      tf.string_to_number(features),
      tf.cast(label,tf.int32),
      url)).prefetch(buffer_size)
    dataset = dataset.batch(params.batch_size).repeat(1).prefetch(buffer_size)
    iterator = dataset.make_initializable_iterator()
    next_value = iterator.get_next()
    self.sess.run(iterator.initializer)
    return next_value

  def run(self):
    params = self.params
    tf.reset_default_graph()
    with self.graph.as_default():
      sess = self.sess
      params = self.params
      logits,labels = self.graph_def
      predictions = tf.nn.softmax(logits)
      top = tf.argmax(logits, 1,output_type=tf.int32)
      correct_prediction = tf.equal(top, labels)
      accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
      values,indices = tf.nn.top_k(predictions,2)

      top_indice_1,top_indice_2 = tf.split(self.index_lookup_table.lookup(tf.cast(indices,tf.int64)),[1,1],1)
      top_value_1,top_value_2 = tf.split(tf.as_string(values),[1,1],1)

      output = tf.string_join([self.inputs[2],
      self.index_lookup_table.lookup(
        tf.cast(labels,tf.int64)),
        tf.reshape(top_indice_1,[-1]),
        tf.reshape(top_value_1,[-1]),
        tf.reshape(top_indice_2,[-1]),
        tf.reshape(top_value_2,[-1])],
        separator='\t')
      sess.run(tf.tables_initializer())

      self.saver.restore(sess,params.model_path)
      acc = 0.0
      count = 0
      sample = 0
      try:
        while True:
          result = sess.run([accuracy,output])
          acc += result[0]
          count += 1
          sample += len(result[1].tolist())
          with tf.gfile.GFile(params.predict_path,'wb') as f:
            for str_byte in result[1].tolist():
              f.write(str_byte)
              f.write(b'\n')
      except Exception as e:
        print('accuracy:%f, count:%d' % (acc / count, sample))
