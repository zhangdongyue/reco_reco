nohup python retrain-inception.py \
  --model_name='inception_v3' \
  --model_scope='InceptionV3' \
  --probe_scope='Conv2d_1a_3x3/BatchNorm/moving_mean' \
  --train_include_scopes='InceptionV3/Logits,InceptionV3/AuxLogits,InceptionV3/Mixed_7c' \
  --restore_exclude_scopes='InceptionV3/AuxLogits,InceptionV3/Logits' \
  --batch_norm_decay='0.99' \
  > inception-v3.log &
tail -f inception-v3.log
