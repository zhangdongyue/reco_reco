# -*-coding:UTF-8-*-
import tensorflow as tf
import model

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dint('batch_size',64,'')
dint('dataset_prefetch_size',128,'')
dint('max_steps',1000,'')
dint('input_width',1024,'')
dint('decay_step',10,'')
dfloat('learning_rate',0.0003,'')
dfloat('decay_rate',0.96,'')
dstring('train_data_path','/home/wangfei01/git/video-label/train.txt','')
dstring('test_data_path','/home/wangfei01/git/video-label/test.child.txt','')
dstring('model_path','/home/wangfei01/git/video-label/model/dnn','')
dstring('predict_path','/home/wangfei01/git/video-label/data/','')
dstring('label_set',
'其他,体育,健身,动物,女生自拍,情景短剧,技能展示,搞笑,教育知识,旅游,时尚,极限运动,汽车,游戏,生活服务,男生自拍,美食,舞蹈,萌娃,音乐,生活自拍',
'')
dstring('layers','1024,512,128','')
FLAGS = tf.flags.FLAGS

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  model = model.TestModel(FLAGS,graph,sess)
  model.run()
