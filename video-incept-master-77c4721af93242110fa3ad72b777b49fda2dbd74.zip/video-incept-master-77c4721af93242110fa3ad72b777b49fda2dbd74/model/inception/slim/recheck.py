# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
from nets import nets_factory

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dint('image_width',299,'')
dint('image_height',299,'')
dint('batch_size',1,'')
dstring('inception_path','/home/wangfei01/data/ffmpeg/inception.txt','')
dstring('data_dir','/home/wangfei01/data/ffmpeg/','')
dstring('inception_tfrecords','/home/wangfei01/data/ffmpeg/inception.tfrecords','')
dstring('model_name','inception_v3','')
dstring('checkpoint_path','/home/wangfei01/git/video-incept/incept_v3/checkpoint/inception_v3.ckpt','')
dstring('train_tfrecords_path','/home/wangfei01/data/ffmpeg/train.tfrecords','')
dstring('bottleneck_tensor','pool_3/_reshape:0','')
dstring('resize_input_tensor','Mul:0','')
dstring('model_path','/tmp/imagenet/classify_image_graph_def.pb','')

flags = tf.flags.FLAGS


class Bottleneck(object):
  def __init__(self,params,graph,sess):
    self.params = params
    self.graph = graph
    self.sess = sess

  def read_image_tfrecords(self):
    params = self.params
    width = params.image_width
    height = params.image_height
    image_info = tf.stack([width,height])

    path = params.train_tfrecords_path
    dataset = tf.data.TFRecordDataset(path)
    # parse example tfrecords
    def _parse_example(ex):
      features={
        "vdo_id":tf.FixedLenFeature([],tf.string),
        "label":tf.FixedLenFeature([],tf.string),
        "idst":tf.FixedLenFeature([],tf.string),
        "image_data":tf.VarLenFeature(tf.string)}
      image_info = tf.parse_single_example(ex,features)
      return image_info['vdo_id'],image_info['label'],image_info['idst'],image_info['image_data'].values

    dataset = dataset.map(_parse_example)
    dataset = dataset.map(lambda vdo_id,label,idst,image_datas:(
      vdo_id,label,idst,tf.map_fn(lambda x:tf.image.decode_jpeg(x,channels=3),image_datas,dtype=tf.uint8)))
    # resize image
    def _resize_image(image):
      resize_image = tf.image.resize_bilinear(image,image_info)
      print(resize_image)
      reshape_image = tf.reshape(resize_image,[-1,width,height,3])
      return tf.cast(reshape_image,tf.float32)

    dataset = dataset.map(lambda vdo_id,label,idst,image:(
      vdo_id,label,tf.string_to_number(tf.string_split([idst],',').values),_resize_image(image)))
    #dataset = dataset.batch(params.batch_size)
    iterator = dataset.make_initializable_iterator()
    self.sess.run(iterator.initializer)
    return iterator.get_next()

  def create_example(self,res):
    example = tf.train.SequenceExample(
        context=tf.train.Features(feature={
          'vdo_id':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[res[0]])),
          'label':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[res[1]])),
          'idst':tf.train.Feature(
            float_list=tf.train.FloatList(value=res[2]))
          }),
        feature_lists=tf.train.FeatureLists(feature_list={
            'frame_seq':tf.train.FeatureList(feature=[
              tf.train.Feature(
                float_list=tf.train.FloatList(value=frame)) for frame in res[3]])
          })
        )
    return example

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)

  tf.reset_default_graph()
  with graph.as_default():
    bottleneck = Bottleneck(flags,graph,sess)
    vdo_id,label,idst,image = bottleneck.read_image_tfrecords()
    encode_image = tf.map_fn(lambda x:tf.image.encode_jpeg(x),tf.cast(image,tf.uint8),dtype=tf.string)

    network_fn = nets_factory.get_network_fn(
        flags.model_name,
        num_classes=None,
        is_training=False)
    bottleneck_tensor,_ = network_fn(image)
    print(bottleneck_tensor)
    image_emb = tf.squeeze(bottleneck_tensor,[1,2])
    saver = tf.train.Saver()
    saver.restore(sess,flags.checkpoint_path)
    step = 0
    while step<=10:
      start = time.time()
      res = sess.run([vdo_id,label,encode_image])
      for i,img in enumerate(res[2]):
        path = os.path.join(flags.data_dir,'{0}-{1}-{2}.jpeg'.format(res[0].decode('UTF-8'),res[1].decode('UTF-8'),i))
        print(path)
        with open(path,'wb') as file:
          file.write(img)
      step += 1
      print('item count %d, spend %d ms' % (step,(time.time() - start)*1000))
