# -*-coding:UTF-8-*-
import tensorflow as tf
import video_incept
import sys
from utils import frame_utils
from utils import lookup_utils
from utils import train_utils
from utils import dnn_utils

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dbool = tf.flags.DEFINE_bool
dint('batch_size',128,'')
dint('max_steps',30000,'')
dint('decay_step',100,'')
dfloat('learning_rate',0.00003,'')
dfloat('decay_rate',0.99,'')
dstring('label_set','体育,健身,动物,女生自拍,情景短剧,技能展示,搞笑,旅游,时尚,极限运动,汽车,生活服务,男生自拍,美食,舞蹈,萌娃,音乐,生活自拍','')

video_flags = video_incept.FLAGS
flags = tf.flags.FLAGS

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    # Create label lookup table
    label_size,lookup_table,index_table = lookup_utils.lookup_table(sess,flags.label_set)
    # Create video inception model
    model = video_incept.GruPoolModel(video_flags,graph,sess)
    iterator = frame_utils.read_inception_tfrecords(
        sess,video_flags.eval_path,video_flags.batch_size,is_training=False)
    itemid,labels,seq_len,seq = iterator.get_next()
    endpoint = model.pooling(seq,seq_len,label_size,is_training=False)
    logits = endpoint['Logits']
    # Build the evaluation operation
    top = tf.argmax(logits,1)
    correct_prediction = tf.equal(top, labels)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    model.restore()
    step = 0
    acc = 0.0
    count = 0
    try:
      while True:
        res = sess.run([accuracy,top])
        num = res[1].shape[0]
        acc += res[0] * num
        count += num
        if step % 1000 == 0:
          print('count:{},accuracy:{:.5f}'.format(count, acc / count))
          sys.stdout.flush()
    except Exception as e:
      print(e)
