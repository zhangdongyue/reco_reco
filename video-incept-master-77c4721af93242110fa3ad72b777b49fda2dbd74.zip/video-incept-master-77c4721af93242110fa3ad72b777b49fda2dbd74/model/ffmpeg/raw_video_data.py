# -*-coding:UTF-8-*-
import subprocess
import argparse
import time
import tensorflow as tf
import urllib
import os

class Ffmpeg(object):
  def __init__(self,params):
    self.params=params

  def extract_frames(self,url,vdo_id):
    print('video url is:{}'.format(url))
    path = '%s/%s' % (params.ffmpeg_tmp_path,vdo_id)
    command = 'rm -rf %s' % (path)
    res = subprocess.call(command,shell=True)
    if res == 0:
      command = 'mkdir -p %s' % (path)
      res = subprocess.call(command,shell=True)
    if res == 0:
      command = "ffmpeg -i {} -f image2 -vf fps=fps=1/3 {}/{}%d.jpg > /dev/null 2>&1".format(url,path,params.pic_prefix)
      res = subprocess.call(command,shell=True)
    frames = self.read_image_dir(path)
    return frames


  def read_image_dir(self,path):
    length = len(os.listdir(path))
    def _read_image(path):
      with open(path,'rb') as image_file:
        return image_file.read()
    result = []
    for i in range(1,length+1):
      image_path = os.path.join(path,'{0}{1}.jpg'.format(params.pic_prefix,i))
      result.append(_read_image(image_path))
    return result

  def read_image_url(self,image_url):
    print('image url is:{}'.format(image_url))
    response = urllib.request.urlopen(image_url)
    return response.read()

  def video2tfrecord(self,itemid,l1_category,l2_category,snapshot_url,video_url):
    snapshot = self.read_image_url(snapshot_url)
    frames = self.extract_frames(video_url,itemid)
    return snapshot,frames

  def create_tfrecord(self,itemid,l1_category,l2_category,snapshot,frames):
    print(len(frames))
    example = tf.train.SequenceExample(
        context=tf.train.Features(feature={
          'itemid':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[itemid.encode('UTF-8')])),
          'l1_category':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[l1_category.encode('UTF-8')])),
          'l2_category':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[l2_category.encode('UTF-8')])),
          'snapshot':tf.train.Feature(
            bytes_list=tf.train.BytesList(value=[snapshot]))
          }),
        feature_lists=tf.train.FeatureLists(feature_list={
            'frames':tf.train.FeatureList(
              feature=[tf.train.Feature(bytes_list=tf.train.BytesList(value=[frame])) for frame in frames])
          }))
    return example


if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  parser.add_argument('--ffmpeg_tmp_path',
      type=str,
      default='/home/wangfei01/data/ffmpeg/tmp',
      help='ffmpeg tmp path')
  parser.add_argument('--pic_prefix',
      type=str,
      default='frame-',
      help='pic prefix')
  parser.add_argument('--video_info_path',
      type=str,
      default='/home/wangfei01/data/raw/fp-test.txt',
      help='video info path')
  parser.add_argument('--tfrecord_path',
      type=str,
      default='/home/wangfei01/data/raw/test.tfrecords',
      help='video info path')
  params = parser.parse_args()
  ffmpeg = Ffmpeg(params)
  index = 0
  command = 'rm -f %s' % (params.tfrecord_path)
  res = subprocess.call(command,shell=True)
  if res == 0:
    print('rm file {0}'.format(params.tfrecord_path))
  writer = tf.python_io.TFRecordWriter(params.tfrecord_path)
  with open(params.video_info_path,'r') as read_file:
    for line in read_file:
      try:
        beg = time.time()
        tokens = line.rstrip('\n').split('\t')
        video_url = 'http://yutang.uczzd.cn/spider-open/api/video/download?itemid={}'.format(tokens[0])
        snapshot,frames = ffmpeg.video2tfrecord(tokens[0],tokens[2],tokens[3],tokens[1],video_url)
        if (snapshot is not None) and (len(frames) > 0):
          result= ffmpeg.create_tfrecord(tokens[0],tokens[2],tokens[3],snapshot,frames)
          writer.write(result.SerializeToString())
          end = time.time()
          index += 1
          print("vdo_id {0}, spend {1} ms,total record:{2}".format(tokens[1],(end-beg)*1000,index))
      except Exception as e:
        print(e)
