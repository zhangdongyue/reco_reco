import tensorflow as tf
import urllib.request
import time
import subprocess

dint = tf.flags.DEFINE_integer
dstring = tf.flags.DEFINE_string
dstring('raw_path','/home/wangfei01/data/ffmpeg/fp-train.txt','')
dstring('tfrecords_path','/home/wangfei01/data/ffmpeg/first_page_train.tfrecords','')

FLAGS = tf.flags.FLAGS

class ImageReader(object):
  def __init__(self,params):
    self.params = params

  def read_image(self,image_url):
    response = urllib.request.urlopen(image_url)
    return response.read()

  def read_key_frame(self):
    params = self.params
    path = params.raw_path
    with open(path,'r') as file:
      for line in file:
        tokens = line.strip().split('\t')
        try:
          if not tokens[1].endswith('.png'):
            image_data = self.read_image(tokens[1])
            yield (str.encode(tokens[0]),str.encode(tokens[2]),
                str.encode(tokens[3]),image_data)
        except Exception as e:
          print(e)

  def write_train_tfrecords(self):
    params = self.params
    path = params.tfrecords_path
    command = 'rm -f %s'.format(path)
    res = subprocess.call(command,shell=True)
    if res == 0:
      print('rm file {0}'.format(path))
    writer = tf.python_io.TFRecordWriter(path)
    key_frames = self.read_key_frame()
    for (index,(itemid,l1_category,l2_category,image_bytes)) in enumerate(key_frames):
      try:
        example = tf.train.Example(features=tf.train.Features(
              feature={
              "itemid":tf.train.Feature(bytes_list=tf.train.BytesList(value=[itemid])),
              "l1_category":tf.train.Feature(bytes_list=tf.train.BytesList(value=[l1_category])),
              "l2_category":tf.train.Feature(bytes_list=tf.train.BytesList(value=[l2_category])),
              "image_data":tf.train.Feature(bytes_list=tf.train.BytesList(value=[image_bytes]))
              }))
        print("process first page:%d" % (index))
        writer.write(example.SerializeToString())
      except Exception as e:
        print(e)
    writer.close()

if __name__ == "__main__":
  reader = ImageReader(FLAGS)
  reader.write_train_tfrecords()

