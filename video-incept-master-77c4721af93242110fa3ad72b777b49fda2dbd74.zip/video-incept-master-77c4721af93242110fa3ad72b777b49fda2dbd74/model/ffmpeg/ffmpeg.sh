#!/bin/bash
#url='http://yk-flv-sh.oss-cn-shanghai.aliyuncs.com/03002001005A2E6A91B275311F29883BFD39AA-B4E3-2740-C652-EA6A23F0BE96.mp4'
url='http://yutang.uczzd.cn/spider-open/api/video/download?itemid=10005755142911735165'
ffmpeg -i ${url} -f image2 -vf fps=fps=1 data/out%d.jpg
