import tensorflow as tf
import urllib.request
import time
import retrain

dint = tf.flags.DEFINE_integer
dstring = tf.flags.DEFINE_string
dstring('key_frame_path','whale.txt','')
dstring('train_tfrecords_path','train.tfrecords','')

FLAGS = tf.flags.FLAGS

class ImageReader(object):
  def __init__(self,params):
    self.params = params

  def read_image(self,image_url):
    response = urllib.request.urlopen(image_url)
    return response.read()

  def read_key_frame(self):
    params = self.params
    path = params.key_frame_path
    with open(path,'r') as file:
      for line in file:
        tokens = line.strip().split('\t')
        yield (str.encode(tokens[0]),str.encode(tokens[1]),self.read_image(tokens[5]))

  def write_train_tfrecords(self):
    params = self.params
    path = params.train_tfrecords_path
    writer = tf.python_io.TFRecordWriter(path)
    key_frames = self.read_key_frame()
    for (index,(vdo_id,shot_id,image_bytes)) in enumerate(key_frames):
      example = tf.train.Example(features=tf.train.Features(
            feature={
            "vdo_id":tf.train.Feature(bytes_list=tf.train.BytesList(value=[vdo_id])),
            "shot_id":tf.train.Feature(bytes_list=tf.train.BytesList(value=[shot_id])),
            "image_data":tf.train.Feature(bytes_list=tf.train.BytesList(value=[image_bytes]))
            }))
      print("process key frame:%d" % (index))
      writer.write(example.SerializeToString())
    writer.close()

if __name__ == "__main__":
  reader = ImageReader(FLAGS)
  reader.write_train_tfrecords()

