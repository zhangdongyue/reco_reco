# -*-coding:UTF-8-*-
import subprocess
import argparse
import time
import tensorflow as tf

class Ffmpeg(object):
  def __init__(self,params):
    self.params=params

  def key_frame(self,url,vdo_id):
    path = '%s/%s' % (params.ffmpeg_tmp_path,vdo_id)
    command = 'rm -rf %s' % (path)
    res = subprocess.call(command,shell=True)
    if res == 0:
      command = 'mkdir -p %s' % (path)
      res = subprocess.call(command,shell=True)
    if res == 0:
      command = "ffmpeg -i {0} -f image2 -vf fps=fps=1/3 {1}/{2}%d.jpg > /dev/null 2>&1".format(url,path,params.pic_prefix)
      res = subprocess.call(command,shell=True)
    return path


  def read_image(self,path):
    length = len(os.listdir(path))
    def _read_image(path):
      with open(path,'rb') as image_file:
        return image_file.read()
    for i in range(1,length+1):
      image_path = os.path.join(path,'{0}{1}.jpg'.format(params.pic_prefix,i))
      yield _read_image(image_path)

  def image2tfrecord(self,url,vdo_id,label,idst):
    path = self.key_frame(url,vdo_id)
    frames = self.read_image(path)
    example = tf.train.Example(
        features=tf.train.Features(
          feature={
          "vdo_id":tf.train.Feature(bytes_list=tf.train.BytesList(value=[vdo_id.encode('UTF-8')])),
          "label":tf.train.Feature(bytes_list=tf.train.BytesList(value=[label.encode('UTF-8')])),
          "idst":tf.train.Feature(bytes_list=tf.train.BytesList(value=[idst.encode('UTF-8')])),
          "image_data":tf.train.Feature(bytes_list=tf.train.BytesList(value=frames))}))
    return example




if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  parser.add_argument('--ffmpeg_tmp_path',
      type=str,
      default='/home/wangfei01/data/ffmpeg/tmp',
      help='ffmpeg tmp path')
  parser.add_argument('--pic_prefix',
      type=str,
      default='frame-',
      help='pic prefix')
  parser.add_argument('--video_info_path',
      type=str,
      default='/home/wangfei01/data/ffmpeg/test.txt',
      help='video info path')
  parser.add_argument('--tfrecord_path',
      type=str,
      default='/home/wangfei01/data/ffmpeg/test.tfrecords',
      help='video info path')
  params = parser.parse_args()
  ffmpeg = Ffmpeg(params)
  index = 0
  command = 'rm -f %s' % (params.tfrecord_path)
  res = subprocess.call(command,shell=True)
  if res == 0:
    print('rm file {0}'.format(params.tfrecord_path))
  writer = tf.python_io.TFRecordWriter(params.tfrecord_path)
  with open(params.video_info_path,'r') as read_file:
    for line in read_file:
      beg = time.time()
      tokens = line.rstrip('\n').split('\t')
      result = ffmpeg.image2tfrecord(tokens[5],tokens[1],tokens[3],tokens[6])
      writer.write(result.SerializeToString())
      end = time.time()
      index += 1
      print("vdo_id {0}, spend {1} ms,total record:{2}".format(tokens[1],(end-beg)*1000,index))
