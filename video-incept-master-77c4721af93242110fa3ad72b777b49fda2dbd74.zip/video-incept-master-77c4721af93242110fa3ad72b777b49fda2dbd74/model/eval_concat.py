# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
import sys
from nets import nets_factory

import image_incept
import video_incept
from utils import frame_utils
from utils import lookup_utils
from utils import train_utils

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dbool = tf.flags.DEFINE_bool

dint('batch_size',128,'')
dint('max_steps',30000,'')
dint('decay_step',100,'')
dfloat('learning_rate',0.00003,'')
dfloat('decay_rate',0.99,'')
dstring('label_set','体育,健身,动物,女生自拍,情景短剧,技能展示,搞笑,旅游,时尚,极限运动,汽车,生活服务,男生自拍,美食,舞蹈,萌娃,音乐,生活自拍','')

image_flags = image_incept.FLAGS
video_flags = video_incept.FLAGS

flags = tf.flags.FLAGS

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    # Create label lookup table
    label_size,lookup_table,index_table = lookup_utils.lookup_table(
        sess,flags.label_set)
    # Get the input frames iterator
    iterator = frame_utils.read_frame_tfrecords(
        sess,image_flags.incept_eval_data,1,is_training=False)
    itemid,label,snapshot,frames = iterator.get_next()

    # Create image inception model
    image_model = image_incept.ImageInceptModel(image_flags,graph,sess)
    image_endpoint = image_model.build_graph(frames,label_size,is_training=False)

    # Get the bottleneck layer
    bottleneck = tf.expand_dims(tf.squeeze(image_endpoint['PreLogits'],[1,2]),0)
    labels = lookup_table.lookup(label)
    image_model.restore()

    # Create video inception model
    seq_len = tf.shape(frames)
    video_model = video_incept.GruPoolModel(video_flags,graph,sess)
    video_endpoint = video_model.pooling(bottleneck,seq_len,label_size,is_training=False)
    logits = video_endpoint['Logits']

    # Build the evaluation operation
    predictions = tf.nn.softmax(logits)
    top = tf.argmax(logits,1)
    correct_prediction = tf.equal(top, labels)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    video_model.restore()
    sys.stdout.flush()

    step = 0
    acc = 0
    count = 0
    try:
      while True:
        res = sess.run([accuracy,top])
        num = res[1].shape[0]
        acc += res[0] * num
        count += num
        step += 1
        if step % 100 == 0:
          print('count:{},accuracy:{:.5f}'.format(count, acc / count))
          sys.stdout.flush()
    except Exception as e:
      print('count:{},accuracy:{:.5f}'.format(count, acc / count))

