# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
from nets import nets_factory
from preprocessing import inception_preprocessing as pp
from utils import train_utils
from utils import frame_utils

slim = tf.contrib.slim
dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dbool = tf.flags.DEFINE_bool

dint('image_width',299,'')
dint('image_height',299,'')
dfloat('batch_norm_decay',0.99,'')
dstring('model_name','inception_resnet_v2','')
dstring('model_scope','InceptionResnetV2','')
dstring('pretrain_version','r1600','')
dstring('pretrain_checkpoint_path','/home/wangfei01/checkpoint','')
dstring('retrain_checkpoint_path','/home/wangfei01/checkpoint','')
dstring('incept_train_data','/home/wangfei01/data/raw/fp-train.tfrecords','')
dstring('incept_eval_data','/home/wangfei01/data/raw/fp-test.tfrecords','')
dstring('incept_infer_data','/home/wangfei01/data/raw/fp-test.tfrecords','')
dstring('incept_infer_dir','/home/wangfei01/data/incept','')
dstring('restore_exclude_scopes','','')
dstring('train_include_scopes','','')
dstring('probe_scope','Conv2d_1a_3x3/BatchNorm/moving_mean','')
dstring('incept_infer_file_name','train','')

FLAGS = tf.flags.FLAGS

class ImageInceptModel(object):
  def __init__(self,flags,graph,sess):
    self.flags = flags
    self.graph = graph
    self.sess = sess

  def build_graph(self,bytes_frames,label_size,is_training):
    flags = self.flags
    # Create the input.
    images = tf.map_fn(lambda frame:frame_utils.preprocess(
      frame,flags.image_width,flags.image_height,is_training=is_training),
      bytes_frames,dtype=tf.float32)

    network_fn = nets_factory.get_network_fn(
        flags.model_name,
        num_classes=label_size,
        batch_norm_decay=flags.batch_norm_decay,
        is_training=is_training)
    logits,endpoint = network_fn(images)
    # Restore the Inception variables.
    return endpoint

  def restore(self):
    flags = self.flags
    variables_to_restore = train_utils.restore_variables(
        flags.restore_exclude_scopes, flags.model_scope)
    saver = tf.train.Saver(variables_to_restore)
    checkpoint_path = '{}/{}/pretrain/model.ckpt-{}'.format(
        flags.pretrain_checkpoint_path,flags.model_name,flags.pretrain_version)
    saver.restore(self.sess,checkpoint_path)
    print('restore model:{}'.format(checkpoint_path))

  def save(self,step):
    flags = self.flags
    checkpoint_path = '{}/{}/retrain/model.ckpt'.format(
        flags.retrain_checkpoint_path,flags.model_name)
    saver = tf.train.Saver()
    saver.save(self.sess,checkpoint_path,step)
    print('save model to {}-{}\n'.format(checkpoint_path,step))
