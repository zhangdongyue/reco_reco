# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
from nets import nets_factory
from preprocessing import inception_preprocessing as pp

import image_incept
from utils import frame_utils
from utils import lookup_utils
from utils import train_utils

dint = tf.flags.DEFINE_integer
dbool = tf.flags.DEFINE_boolean
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dint('batch_size',128,'')
dint('max_steps',3000,'')
dint('decay_step',30,'')
dfloat('learning_rate',0.0001,'')
dfloat('decay_rate',0.99,'')
dstring('label_set','体育,健身,动物,女生自拍,情景短剧,技能展示,搞笑,旅游,时尚,极限运动,汽车,生活服务,男生自拍,美食,舞蹈,萌娃,音乐,生活自拍','')
flags = tf.flags.FLAGS
image_flags = image_incept.FLAGS

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    # Create label lookup table
    label_size,lookup_table,index_table = lookup_utils.lookup_table(sess,flags.label_set)
    # Get the input frames iterator
    iterator = frame_utils.read_frame_tfrecords(
        sess,image_flags.incept_train_data,flags.batch_size,is_training=True)
    itemid,label,snapshot,blend = iterator.get_next()

    # Create image inception model
    model = image_incept.ImageInceptModel(image_flags,graph,sess)
    endpoint = model.build_graph(blend,label_size,is_training=True)

    # Get the output logits
    logits = endpoint['Logits']
    labels = lookup_table.lookup(label)

    global_step,learning_rate = train_utils.create_learning_rate(
        learning_rate=flags.learning_rate,
        decay_step = flags.decay_step,
        decay_rate = flags.decay_rate)
    # Build the optimizer
    mean_loss = tf.reduce_mean(
        tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labels,logits=logits))
    optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)

    variables_to_train = train_utils.retrain_variables(image_flags.train_include_scopes)
    update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
    with tf.control_dependencies(update_ops):
      train_op = optimizer.minimize(mean_loss,var_list=variables_to_train)

    # Build the evaluation operation
    top = tf.argmax(logits,1)
    correct_prediction = tf.equal(top, labels)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    # Probe the variable value
    with tf.variable_scope(image_flags.model_scope,reuse=True):
      probe = tf.get_variable(image_flags.probe_scope)
    sess.run(tf.global_variables_initializer())
    model.restore()
    saver_retrain = tf.train.Saver()

    step = 0
    loss = 0
    while step < flags.max_steps:
      res = sess.run([train_op,learning_rate,mean_loss,probe],feed_dict={global_step:step})
      step += 1
      loss += res[2]
      print('{}:{:.4f}'.format(step,res[3][1]), sep='', end=' ', flush=True)
      if step % 50 == 0:
        acc = 0.0
        count = 0
        while count < 10:
          result = sess.run(accuracy)
          acc += result
          count += 1
        print('\nstep:{},learning rate:{:.8f},loss:{:.4f},accuracy:{:.4f},count:{}'.\
            format(step,res[1],loss,acc / count,count))
        loss = 0
        if step % 200 == 0:
          model.save(step)
