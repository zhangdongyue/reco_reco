# -*-coding:UTF-8-*-
import tensorflow as tf
import urllib.request
import time
import os
import sys
import image_incept
from nets import nets_factory
from utils import tfrecord
from utils import frame_utils
from utils import lookup_utils

dint = tf.flags.DEFINE_integer
dfloat = tf.flags.DEFINE_float
dstring = tf.flags.DEFINE_string
dbool = tf.flags.DEFINE_bool

dint('max_steps',2000,'')
dint('decay_step',10,'')
dfloat('decay_rate',0.997,'')
dfloat('learning_rate',0.006,'')

flags = image_incept.FLAGS

if __name__ == '__main__':
  graph = tf.Graph()
  sess = tf.Session(graph=graph)
  tf.reset_default_graph()
  with graph.as_default():
    # Create label lookup table
    label_size,lookup_table,index_table = lookup_utils.lookup_table(sess,flags.label_set)
    # Get the input frames iterator
    iterator = frame_utils.read_frame_tfrecords(
        sess,flags.incept_infer_data,1,is_training=False)
    itemid,label,snapshot,frames = iterator.get_next()
    label_id = lookup_table.lookup(label)
    # Create image inception model
    model = image_incept.ImageInceptModel(flags,graph,sess)
    endpoint = model.build_graph(frames,label_size,is_training=False)

    # Get the bottleneck layer
    emb = tf.squeeze(endpoint['PreLogits'],[1,2])
    with tf.variable_scope(flags.model_scope,reuse=True):
      probe = tf.get_variable(flags.probe_scope)
    # Restore model variables
    model.restore()

    tfrecord_path = '{}/{}/{}.tfrecords'.format(
        flags.incept_infer_dir,flags.model_name,flags.incept_infer_file_name)
    if os.path.exists(tfrecord_path):
      os.remove(tfrecord_path)
      print('rm file: {}'.format(tfrecord_path))

    step = 0
    count = 0
    writer = tf.python_io.TFRecordWriter(tfrecord_path)
    try:
      while True:
        start = time.time()
        res = sess.run([itemid,label_id,emb,probe])
        example = tfrecord.create_inception_example(res[0],res[1],res[2])
        writer.write(example.SerializeToString())
        count += 1
        print('item count {}, spend {:.4f} ms, probe: {:.4f}'.format(
          count,(time.time() - start)*1000,res[3][1]))
        sys.stdout.flush()
    except Exception as e:
      print('\ninference {} video frame bottleneck'.format(count))
