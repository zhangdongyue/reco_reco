#include <grpc++/grpc++.h>
#include <gflags/gflags.h>

#include "server/video_label_server.h"
#include "frame/uc_extractor.h"
#include "frame/base_extractor.h"
#include "ffmpeg/cli_ffmpeg.h"

using grpc::ServerContext;
using extractor::UcExtractor;
using extractor::BaseExtractor;
using video::label::VideoLabelServer;
using ffmpeg::CliFfmpeg;
using ffmpeg::BaseFfmpeg;

DEFINE_string(ip,"0.0.0.0","serving ip");
DEFINE_int32(port,10000,"listening port");

DEFINE_string(tf_serving_ip,"0.0.0.0","serving ip");
DEFINE_int32(tf_serving_port,9000,"listening port");

DEFINE_string(category_model_name,"label_model","serving ip");
DEFINE_string(category_signature_name,"label_signature","serving ip");

void RunServer() {
  std::string address = FLAGS_ip + ":" + std::to_string(FLAGS_port);
  std::cout << "address is: "<< address << std::endl;
  std::shared_ptr<BaseFfmpeg> ptr_ffmpeg = std::make_shared<CliFfmpeg>();
  std::shared_ptr<BaseExtractor> ptr_extractor = std::make_shared<UcExtractor>(ptr_ffmpeg);

  std::shared_ptr<grpc::Channel> tf_serving_channel = grpc::CreateChannel(
      FLAGS_tf_serving_ip + ":" + std::to_string(FLAGS_tf_serving_port), 
      grpc::InsecureChannelCredentials());

  std::shared_ptr<tf_serving::CategoryServing> ptr_category_client
    = std::make_shared<tf_serving::CategoryServing>(
        FLAGS_category_model_name,
        FLAGS_category_signature_name,
        tf_serving_channel);

  VideoLabelServer service(ptr_extractor, ptr_category_client);

  grpc::ServerBuilder builder;
  builder.AddListeningPort(address, grpc::InsecureServerCredentials());
  builder.RegisterService(&service);
  std::shared_ptr<grpc::Server> server(builder.BuildAndStart());
  std::cout << "server listening on " << address << std::endl;
  server->Wait();
}

int main(int argc,char** argv){
  google::ParseCommandLineFlags(&argc,&argv,true);
  RunServer();
  return 0;
}
