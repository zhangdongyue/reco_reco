#include <string>
#include <map>

#include "server/video_label_server.h"

namespace video {
  namespace label {
    VideoLabelServer::~VideoLabelServer(){
      std::cout << "distroy video label server" << std::endl;
    }

    Status VideoLabelServer::GetVideoCategory(
        ServerContext* context, 
        const VideoInfoRequest* request, 
        VideoCategoryResponse* response) {
      proto::VideoMeta meta = request->video_info();
      std::string itemid = meta.video_id();
      std::cout << itemid << std::endl;

      std::vector<ffmpeg::Image> frames;
      frames.reserve(10);
      extractor_->Extract(meta,&frames);

      std::map<std::string,float> result_map;
      category_client_->Category(frames, &result_map);

      response->set_itemid(itemid);
      for (auto iter = result_map.begin();iter != result_map.end();++iter) {
        proto::Score* score = response->add_category();
        score->set_key(iter->first);
        score->set_value(iter->second);
      }
      return Status::OK;
    }
  }// End of namespace label
}// End of namespace video
