#pragma once
#include <memory>

#include "frame/base_extractor.h"
#include "proto/video_label.grpc.pb.h"
#include "proto/video_label.pb.h"
#include "tf_serving/category_serving.h"

using grpc::Status;
using grpc::ServerContext;
using proto::Score;
using proto::VideoCategoryResponse;
using proto::VideoInfoRequest;
using proto::VideoLabel;
using extractor::BaseExtractor;

namespace video {
  namespace label {
    class VideoLabelServer final : public VideoLabel::Service {
      public:
        explicit VideoLabelServer(
            std::shared_ptr<BaseExtractor> extractor,
            std::shared_ptr<tf_serving::CategoryServing> category_client):
          extractor_(extractor),
          category_client_(category_client) {};
        ~VideoLabelServer();
        Status GetVideoCategory(ServerContext* context, 
            const VideoInfoRequest* request, VideoCategoryResponse* response) override;
      private:
        std::shared_ptr<BaseExtractor> extractor_;
        std::shared_ptr<tf_serving::CategoryServing> category_client_;

    };
  }// End of namespace label
}// End of namespace video
