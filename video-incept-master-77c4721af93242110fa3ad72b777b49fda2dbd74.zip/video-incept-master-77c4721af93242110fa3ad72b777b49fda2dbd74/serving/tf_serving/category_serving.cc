#include "google/protobuf/map.h"
#include "tf_serving/category_serving.h"
#include "tensorflow/core/platform/types.h"

typedef google::protobuf::Map<tensorflow::string, tensorflow::TensorProto> OutMap;
namespace tf_serving {
  CategoryServing::CategoryServing(
      std::string model_name,
      std::string signature_name,
      std::shared_ptr<Channel> channel):
    model_name_(model_name),
    signature_name_(signature_name),
    stub_(PredictionService::NewStub(channel)) {}

  CategoryServing::~CategoryServing() {}

  void CategoryServing::Category(
      std::vector<ffmpeg::Image> frames,
      std::map<std::string,float>* result_map) {

    PredictRequest predictRequest;

    auto model_spec = predictRequest.mutable_model_spec();
    model_spec->set_name(model_name_);
    model_spec->set_signature_name(signature_name_);

    OutMap* input_frames = predictRequest.mutable_inputs();

    tensorflow::TensorProto frames_proto;
    frames_proto.set_dtype(tensorflow::DataType::DT_STRING);

    for (auto iter = frames.begin();iter != frames.end();iter++) {
      char* image_bytes = iter->get_bytes();
      size_t file_size = iter->get_length();
      frames_proto.add_string_val(image_bytes,file_size);
    }
    frames_proto.mutable_tensor_shape()->add_dim()->set_size(frames.size());

    (*input_frames)["input_frames"] = frames_proto;

    PredictResponse response;
    ClientContext context;
    Status status = stub_->Predict(&context, predictRequest, &response);

    if (status.ok()) {
      std::cout << "tf-serving outputs size is " << response.outputs_size() << std::endl;
      OutMap* map_outputs = response.mutable_outputs();
      for (auto iter = map_outputs->begin(); iter != map_outputs->end(); ++iter) {
        tensorflow::TensorProto& result_tensor_proto = iter->second;
        tensorflow::Tensor tensor;
        bool converted = tensor.FromProto(result_tensor_proto);
        if (converted && (iter->first) == "output_label") {
          std::cout << "the result tensor[" << iter->first << "] is:"
            << tensor.matrix<std::string>() << std::endl;
          auto result_matrix = tensor.matrix<std::string>();
          result_map->insert(std::pair<std::string,float>(result_matrix(0,0),1.0));
        }
        if (converted && (iter->first) == "output_score") {
          std::cout << "the result tensor[" << iter->first << "] is:"
            << tensor.matrix<float>()<< std::endl;
          auto result_matrix = tensor.matrix<float>();
          //result_map->insert(std::pair<std::string,float>(result_matrix(0,0),1.0));
        }
      }
    } else {
      std::cout << "gRPC call return code: " << status.error_code() << ": "
        << status.error_message() << std::endl;
    }
  }

}//End of namespace tf_serving
