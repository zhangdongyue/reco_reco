#pragma once
#include <vector>
#include <map>

#include "tensorflow_serving/apis/prediction_service.grpc.pb.h"
#include "tensorflow/core/framework/tensor.h"
#include "grpc++/create_channel.h"
#include "grpc++/security/credentials.h"

#include "ffmpeg/base_ffmpeg.h"

using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;

using tensorflow::serving::PredictRequest;
using tensorflow::serving::PredictResponse;
using tensorflow::serving::PredictionService;

namespace tf_serving{
  class CategoryServing {
    public:
      CategoryServing(
          std::string model_name,
          std::string signature_name,
          std::shared_ptr<Channel> channel);
      ~CategoryServing();
      void Category(
          std::vector<ffmpeg::Image> frames,
          std::map<std::string,float>* reslutMap);
    private:
      std::string model_name_;
      std::string signature_name_;
      std::unique_ptr<PredictionService::Stub> stub_;
  };//End of class CategoryServing
}//End of namespace tf_serving
