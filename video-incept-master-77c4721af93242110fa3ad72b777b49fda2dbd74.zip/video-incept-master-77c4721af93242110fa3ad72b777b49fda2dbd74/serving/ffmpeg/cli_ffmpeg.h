#pragma once
#include <string>
#include <vector>
#include "ffmpeg/base_ffmpeg.h"

namespace ffmpeg{
  bool _compare(std::string left,std::string right);
  int file_suffix(const std::string& file_name);
  class CliFfmpeg:public BaseFfmpeg{
    public:
      CliFfmpeg();
      ~CliFfmpeg();
      void ExtractFrames(std::string& url,
          std::string& file_name,
          std::vector<ffmpeg::Image>* frames);
  };
}
