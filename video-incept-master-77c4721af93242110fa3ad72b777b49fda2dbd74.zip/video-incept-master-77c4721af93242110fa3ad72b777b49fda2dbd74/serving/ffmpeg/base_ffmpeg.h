#pragma once
#include <iostream>
#include <string.h>
namespace ffmpeg {
  class Image {
    public:
      explicit Image(char* bytes,int length):
        bytes_(bytes),length_(length) {
      }

      explicit Image(const Image& image) {
        length_ = image.length_;
        bytes_ = new char[length_]();
        memcpy(bytes_,image.bytes_,length_);
      }

      ~Image(){
        delete[] bytes_; 
      }

      char* get_bytes() {
        return bytes_; 
      }

      int get_length() {
        return length_;
      }

      //Image& operator=(const Image& image) {
      //  std::cout << "operator=" << std::endl;
      //  size_t data_size = strlen(image.bytes_);
      //  bytes_ = new char[data_size]();
      //  strcpy(bytes_,image.bytes_);
      //  return *this;
      //}

    private:
      char* bytes_;
      size_t length_;
  };

  class BaseFfmpeg {
    public:
      BaseFfmpeg(){};
      virtual ~BaseFfmpeg(){};
      virtual void ExtractFrames(
          std::string& url,
          std::string& file_name,
          std::vector<Image>* frames) = 0;
  };

}
