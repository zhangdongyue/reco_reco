#include <iostream>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <cstdio>

#include <gflags/gflags.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "ffmpeg/cli_ffmpeg.h"
#include "utils/file/file.h"

DEFINE_int32(seconds, 3, "seconds for a frame.");
DEFINE_string(frames_tmp_dir, "/home/wangfei01/tmp/frames", "tmp dir that store frame images.");

namespace ffmpeg {
  CliFfmpeg::CliFfmpeg() {}

  CliFfmpeg::~CliFfmpeg() {}

  void CliFfmpeg::ExtractFrames(
      std::string& url, 
      std::string& file_name, 
      std::vector<ffmpeg::Image>* frames) {

    std::string dir = FLAGS_frames_tmp_dir + "/" + file_name;
    int dir_create_success = mkdir(dir.c_str(), S_IRWXU);
    std::cout << "create dir:"<< dir << " status:" << dir_create_success << std::endl;
    // create a dir that holds extracted images.
    std::string path = dir + "/" + std::to_string(rand()); 
    int rand_create_success = mkdir(path.c_str(), S_IRWXU);
    std::cout << "create dir:"<< path << " status:" << rand_create_success << std::endl;

    // use ffmpeg to extract file to local dir.
    std::string command_line = "ffmpeg -i " + url + " -f image2 -vf fps=fps=1/"
      + std::to_string(FLAGS_seconds) + " " 
      + path + "/%d.jpg > /dev/null 2>&1";
    int result = std::system(command_line.c_str());
    std::cout << command_line << " " << result << std::endl;
    // read all images that are extracted.
    std::vector<std::string> files;
    utils::get_all_files(path,&files);
    std::sort(files.begin(), files.end(), ffmpeg::_compare);

    for (std::string p:files) {
      std::ifstream image_file(p,std::ios::binary);
      if (!image_file.is_open()) {
        std::cout << "Failed to open " << p << std::endl;
      }else {
        std::filebuf* pbuf = image_file.rdbuf();
        int file_size = pbuf->pubseekoff(0, std::ios::end, std::ios::in);
        std::cout << p << " size is:" << file_size << std::endl;
        char* image = new char[file_size]();
        pbuf->pubseekpos(0, std::ios::in);
        pbuf->sgetn(image, file_size);
        image_file.close();
        frames->push_back(ffmpeg::Image(image,file_size));
      }
    }
    // remove tmp dir
    utils::remove_dir(path);
  }

  bool _compare(std::string left,std::string right) {
    return ffmpeg::file_suffix(left) < ffmpeg::file_suffix(right); 
  }

  int file_suffix(const std::string& file_name) {
    std::size_t beg = file_name.find_last_of("/");
    std::size_t end = file_name.find_last_of(".");
    std::string index = file_name.substr(beg + 1, end);
    return std::stoi(index);
  }
}
