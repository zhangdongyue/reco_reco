#include <string>
#include <chrono>

#include <grpc++/grpc++.h>
#include <gflags/gflags.h>
#include "proto/video_label.grpc.pb.h"
#include "proto/video_label.pb.h"

DEFINE_string(ip,"127.0.0.1","serving ip");
DEFINE_int32(port,10000,"listening port");
DEFINE_string(itemid,"10002650170017265330","test itemid");

void Request() {
  std::string address = FLAGS_ip + ":" + std::to_string(FLAGS_port);
  std::cout << address << std::endl;
  auto channel = grpc::CreateChannel(address, grpc::InsecureChannelCredentials());
  std::shared_ptr<grpc::ChannelInterface> ptr_channel(channel); 
  proto::VideoLabel::Stub stub(ptr_channel);

  auto beg = std::chrono::high_resolution_clock::now();
  for (int i = 0; i < 1; ++i) {
    proto::VideoMeta* meta = new proto::VideoMeta();
    meta->set_video_id(FLAGS_itemid);

    proto::VideoInfoRequest video_info;
    video_info.set_allocated_video_info(meta);

    grpc::ClientContext context;
    proto::VideoCategoryResponse video_category;
    stub.GetVideoCategory(&context,video_info,&video_category);
    std::cout << video_category.itemid() << "->" 
      << video_category.category(0).key() << std::endl;
  }
  auto end = std::chrono::high_resolution_clock::now();
  std::chrono::duration<double,std::milli> elapsed = end - beg;
  std::cout << "spend " << elapsed.count() << " ms." << std::endl;
}

int main(int argc,char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, true);
  Request();
  return 0;
}
