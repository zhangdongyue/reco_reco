#pragma once

#include <vector>
#include <string>
#include <memory>

#include "ffmpeg/base_ffmpeg.h"
#include "proto/video_meta.pb.h"

namespace extractor {
  class BaseExtractor {
    public:
      explicit BaseExtractor(std::shared_ptr<ffmpeg::BaseFfmpeg>& ffmpeg):ffmpeg_(ffmpeg) {};
      virtual ~BaseExtractor(){};
      virtual void Extract(const proto::VideoMeta& meta,std::vector<ffmpeg::Image>* frames) = 0;
    protected:
      std::shared_ptr<ffmpeg::BaseFfmpeg> ffmpeg_;
  };
}
