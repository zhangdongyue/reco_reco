#include <gflags/gflags.h>

#include "frame/uc_extractor.h"

DEFINE_string(uc_video_download_url,"http://yutang.uczzd.cn/spider-open/api/video/download?itemid=","uc video download url");

namespace extractor {
  const std::string UcExtractor::url_templete_ = FLAGS_uc_video_download_url;

  UcExtractor::UcExtractor(std::shared_ptr<ffmpeg::BaseFfmpeg> ffmpeg):BaseExtractor(ffmpeg) {}
  UcExtractor::~UcExtractor() {}

  void UcExtractor::Extract(
      const proto::VideoMeta& meta,
      std::vector<ffmpeg::Image>* frames) {
    std::string video_id = meta.video_id();
    std::string video_download_url = url_templete_ + video_id;
    std::cout << "video download url is:" << video_download_url << std::endl;
    ffmpeg_->ExtractFrames(video_download_url,video_id,frames);
  }
}//End of namespace extractor
