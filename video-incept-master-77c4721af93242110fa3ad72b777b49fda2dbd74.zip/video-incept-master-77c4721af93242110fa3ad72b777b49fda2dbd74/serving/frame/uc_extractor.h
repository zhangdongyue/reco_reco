#pragma once

#include "frame/base_extractor.h"

namespace extractor{
  class UcExtractor : public BaseExtractor{
    public:
      UcExtractor(std::shared_ptr<ffmpeg::BaseFfmpeg> ffmpeg);
      ~UcExtractor();
      void Extract(const proto::VideoMeta& meta,std::vector<ffmpeg::Image>* frames);
    private:
      static const std::string url_templete_;
  };// End of class UcExtractor

}//End of namespace extractor
