#include <string>
#include <cstring>
#include <vector>
#include <iostream>

#include <dirent.h>
#include <stdio.h>

namespace utils {
  void get_all_files(std::string& path, std::vector<std::string>* files);
  void remove_all_files(std::string& path);
  void remove_dir(std::string& dir);
}
