#include "utils/file/file.h"

namespace utils {
  void get_all_files(std::string& path, std::vector<std::string>* files) {
    DIR * ptr_dir = opendir(path.c_str());
    if (ptr_dir != nullptr) {
      struct dirent* ptr_ent;
      std::string tmp;
      while ((ptr_ent = readdir(ptr_dir)) != nullptr) {
        // If path is a subdir then recursively get files.
        if (ptr_ent->d_type == DT_DIR) {
          if (std::strcmp(ptr_ent->d_name, ".") != 0 &&
              std::strcmp(ptr_ent->d_name, "..") != 0) {
            std::string file_name = tmp.assign(path).append("/").append(ptr_ent->d_name);
            get_all_files(file_name, files);
          }
        }else {
          // Append file name to the vector.
          std::string file_name = tmp.assign(path).append("/").append(ptr_ent->d_name);
          files->push_back(file_name);
        }
      }
      // close file handler.
      closedir(ptr_dir);
    }
  }

  void remove_all_files(std::string& path) {
    std::vector<std::string> files;
    utils::get_all_files(path, &files);
    for (std::string file_name:files) {
      int result = remove(file_name.c_str());
      std::cout << "rm file:" << file_name <<" status:" << result << std::endl;
    }
  }

  void remove_dir(std::string& dir) {
    utils::remove_all_files(dir);
    int result = remove(dir.c_str());
    std::cout << "rm dir:" << dir <<" status:" << result << std::endl;
  }
}
